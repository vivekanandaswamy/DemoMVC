﻿INSERT [TCD].[AllenBradleyTags] ([AllenBradleyTagId], [TagAddress], [Active]) VALUES (1, N'N7:0', 1)
GO
INSERT [TCD].[AllenBradleyTags] ([AllenBradleyTagId], [TagAddress], [Active]) VALUES (2, N'N7:1', 1)
GO
INSERT [TCD].[AllenBradleyTags] ([AllenBradleyTagId], [TagAddress], [Active]) VALUES (3, N'N7:2', 1)
GO
INSERT [TCD].[AllenBradleyTags] ([AllenBradleyTagId], [TagAddress], [Active]) VALUES (4, N'N10:120', 1)
GO
INSERT [TCD].[AllenBradleyTags] ([AllenBradleyTagId], [TagAddress], [Active]) VALUES (5, N'N10:100', 1)
GO
INSERT [TCD].[AllenBradleyTags] ([AllenBradleyTagId], [TagAddress], [Active]) VALUES (6, N'N7:240', 1)
GO
INSERT [TCD].[AllenBradleyTags] ([AllenBradleyTagId], [TagAddress], [Active]) VALUES (7, N'C5:40', 1)
GO
INSERT [TCD].[AllenBradleyTags] ([AllenBradleyTagId], [TagAddress], [Active]) VALUES (8, N'N7:5', 1)
GO
INSERT [TCD].[AllenBradleyTags] ([AllenBradleyTagId], [TagAddress], [Active]) VALUES (9, N'N10:50', 1)
GO
INSERT [TCD].[AllenBradleyTags] ([AllenBradleyTagId], [TagAddress], [Active]) VALUES (10, N'O:6/0', 1)
GO
INSERT [TCD].[AllenBradleyTags] ([AllenBradleyTagId], [TagAddress], [Active]) VALUES (11, N'B3:17/1', 1)
GO
INSERT [TCD].[AllenBradleyTags] ([AllenBradleyTagId], [TagAddress], [Active]) VALUES (12, N'T4:130', 1)
GO
INSERT [TCD].[AllenBradleyTags] ([AllenBradleyTagId], [TagAddress], [Active]) VALUES (13, N'B3:10/1', 1)
GO
INSERT [TCD].[AllenBradleyTags] ([AllenBradleyTagId], [TagAddress], [Active]) VALUES (14, N'N10:80', 1)
GO
INSERT [TCD].[AllenBradleyTags] ([AllenBradleyTagId], [TagAddress], [Active]) VALUES (15, N'N148:1', 1)
GO
INSERT [TCD].[AllenBradleyTags] ([AllenBradleyTagId], [TagAddress], [Active]) VALUES (16, N'N10:211', 1)
GO
INSERT [TCD].[AllenBradleyTags] ([AllenBradleyTagId], [TagAddress], [Active]) VALUES (17, N'N10:192', 1)
GO
INSERT [TCD].[AllenBradleyTags] ([AllenBradleyTagId], [TagAddress], [Active]) VALUES (18, N'N10:241', 1)
GO
INSERT [TCD].[AllenBradleyTags] ([AllenBradleyTagId], [TagAddress], [Active]) VALUES (19, N'N10:212', 1)
GO
INSERT [TCD].[AllenBradleyTags] ([AllenBradleyTagId], [TagAddress], [Active]) VALUES (20, N'N10:193', 1)
GO
INSERT [TCD].[AllenBradleyTags] ([AllenBradleyTagId], [TagAddress], [Active]) VALUES (21, N'N10:242', 1)
GO
INSERT [TCD].[AllenBradleyTags] ([AllenBradleyTagId], [TagAddress], [Active]) VALUES (22, N'N10:213', 1)
GO
INSERT [TCD].[AllenBradleyTags] ([AllenBradleyTagId], [TagAddress], [Active]) VALUES (23, N'N10:194', 1)
GO
INSERT [TCD].[AllenBradleyTags] ([AllenBradleyTagId], [TagAddress], [Active]) VALUES (24, N'N10:243', 1)
GO
INSERT [TCD].[AllenBradleyTags] ([AllenBradleyTagId], [TagAddress], [Active]) VALUES (25, N'N10:214', 1)
GO
INSERT [TCD].[AllenBradleyTags] ([AllenBradleyTagId], [TagAddress], [Active]) VALUES (26, N'N10:195', 1)
GO
INSERT [TCD].[AllenBradleyTags] ([AllenBradleyTagId], [TagAddress], [Active]) VALUES (27, N'N10:244', 1)
GO
SET IDENTITY_INSERT [TCD].[BatchParameterTypes] ON 

GO
INSERT [TCD].[BatchParameterTypes] ([BatchParameterTypeId], [ParameterName], [CreatedDate]) VALUES (1, N'pH', CAST(0x0000A3E600000000 AS DateTime))
GO
INSERT [TCD].[BatchParameterTypes] ([BatchParameterTypeId], [ParameterName], [CreatedDate]) VALUES (2, N'Temperature', CAST(0x0000A3E600000000 AS DateTime))
GO
INSERT [TCD].[BatchParameterTypes] ([BatchParameterTypeId], [ParameterName], [CreatedDate]) VALUES (3, N'Conductivity', CAST(0x0000A3E600000000 AS DateTime))
GO
SET IDENTITY_INSERT [TCD].[BatchParameterTypes] OFF
GO
INSERT [TCD].[BeckhoffTagMapping] ([BeckhoffTagId], [WasherTagId], [Active]) VALUES (1, 16, 1)
GO
INSERT [TCD].[BeckhoffTagMapping] ([BeckhoffTagId], [WasherTagId], [Active]) VALUES (2, 17, 1)
GO
INSERT [TCD].[BeckhoffTagMapping] ([BeckhoffTagId], [WasherTagId], [Active]) VALUES (3, 18, 1)
GO
INSERT [TCD].[BeckhoffTagMapping] ([BeckhoffTagId], [WasherTagId], [Active]) VALUES (4, 19, 1)
GO
INSERT [TCD].[BeckhoffTagMapping] ([BeckhoffTagId], [WasherTagId], [Active]) VALUES (5, 20, 1)
GO
INSERT [TCD].[BeckhoffTagMapping] ([BeckhoffTagId], [WasherTagId], [Active]) VALUES (6, 21, 1)
GO
INSERT [TCD].[BeckhoffTagMapping] ([BeckhoffTagId], [WasherTagId], [Active]) VALUES (7, 22, 1)
GO
INSERT [TCD].[BeckhoffTagMapping] ([BeckhoffTagId], [WasherTagId], [Active]) VALUES (8, 23, 1)
GO
INSERT [TCD].[BeckhoffTagMapping] ([BeckhoffTagId], [WasherTagId], [Active]) VALUES (9, 24, 1)
GO
INSERT [TCD].[BeckhoffTagMapping] ([BeckhoffTagId], [WasherTagId], [Active]) VALUES (10, 25, 1)
GO
INSERT [TCD].[BeckhoffTagMapping] ([BeckhoffTagId], [WasherTagId], [Active]) VALUES (11, 26, 1)
GO
INSERT [TCD].[BeckhoffTagMapping] ([BeckhoffTagId], [WasherTagId], [Active]) VALUES (12, 27, 1)
GO
INSERT [TCD].[BeckhoffTagMapping] ([BeckhoffTagId], [WasherTagId], [Active]) VALUES (13, 28, 1)
GO
INSERT [TCD].[BeckhoffTagMapping] ([BeckhoffTagId], [WasherTagId], [Active]) VALUES (14, 29, 1)
GO
INSERT [TCD].[BeckhoffTagMapping] ([BeckhoffTagId], [WasherTagId], [Active]) VALUES (15, 30, 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (1, N'W1_FRM', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (2, N'W1_INJ', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (3, N'W1_OPC', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (4, N'W1_EOF', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (5, N'W1_MODE', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (6, N'W1_FLSHT', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (7, N'W1_ICLAS', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (8, N'W1_INJRO', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (9, N'W1_AWEF', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (10, N'W1_AWEW', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (11, N'W1_AWEA', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (12, N'W1_LDID', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (13, N'W1_HOLD', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (14, N'W1_HOLDD', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (15, N'W1_TILT', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (16, N'W1_RATA', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (17, N'W1_RATP', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (18, N'W1_WSNO', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (19, N'W2_FRM', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (20, N'W2_INJ', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (21, N'W2_OPC', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (22, N'W2_EOF', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (23, N'W2_MODE', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (24, N'W2_FLSHT', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (25, N'W2_ICLAS', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (26, N'W2_INJRO', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (27, N'W2_AWEF', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (28, N'W2_AWEW', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (29, N'W2_AWEA', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (30, N'W2_LDID', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (31, N'W2_HOLD', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (32, N'W2_HOLDD', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (33, N'W2_TILT', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (34, N'W2_RATA', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (35, N'W2_RATP', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (36, N'W2_WSNO', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (37, N'W3_FRM', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (38, N'W3_INJ', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (39, N'W3_OPC', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (40, N'W3_EOF', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (41, N'W3_MODE', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (42, N'W3_FLSHT', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (43, N'W3_ICLAS', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (44, N'W3_INJRO', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (45, N'W3_AWEF', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (46, N'W3_AWEW', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (47, N'W3_AWEA', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (48, N'W3_LDID', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (49, N'W3_HOLD', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (50, N'W3_HOLDD', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (51, N'W3_TILT', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (52, N'W3_RATA', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (53, N'W3_RATP', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (54, N'W3_WSNO', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (55, N'W4_FRM', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (56, N'W4_INJ', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (57, N'W4_OPC', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (58, N'W4_EOF', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (59, N'W4_MODE', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (60, N'W4_FLSHT', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (61, N'W4_ICLAS', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (62, N'W4_INJRO', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (63, N'W4_AWEF', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (64, N'W4_AWEW', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (65, N'W4_AWEA', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (66, N'W4_LDID', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (67, N'W4_HOLD', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (68, N'W4_HOLDD', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (69, N'W4_TILT', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (70, N'W4_RATA', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (71, N'W4_RATP', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (72, N'W4_WSNO', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (73, N'W5_FRM', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (74, N'W5_INJ', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (75, N'W5_OPC', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (76, N'W5_EOF', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (77, N'W5_MODE', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (78, N'W5_FLSHT', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (79, N'W5_ICLAS', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (80, N'W5_INJRO', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (81, N'W5_AWEF', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (82, N'W5_AWEW', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (83, N'W5_AWEA', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (84, N'W5_LDID', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (85, N'W5_HOLD', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (86, N'W5_HOLDD', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (87, N'W5_TILT', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (88, N'W5_RATA', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (89, N'W5_RATP', 1)
GO
INSERT [TCD].[BeckhoffTags] ([BeckhoffTagId], [TagAddress], [Active]) VALUES (90, N'W5_WSNO', 1)
GO


--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------

SET IDENTITY_INSERT [TCD].[ModuleType] ON
INSERT [TCD].[ModuleType] ([ModuleTypeId], [ModuleDescription]) VALUES (1, N'Tank')
INSERT [TCD].[ModuleType] ([ModuleTypeId], [ModuleDescription]) VALUES (2, N'Meter')
INSERT [TCD].[ModuleType] ([ModuleTypeId], [ModuleDescription]) VALUES (3, N'Sensor')
GO
INSERT [TCD].[ModuleType] ([ModuleTypeId], [ModuleDescription]) VALUES (4, N'Pumps/Valves')
GO
SET IDENTITY_INSERT [TCD].[ModuleType] OFF




INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (1, N'Tag_FRM', N'CurrentFormula', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (2, N'Tag_INJ', N'CurrentInjection', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (3, N'Tag_OPC', N'CurrentOperationCounter', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (4, N'Tag_AWEF', N'AutoWeightEntry(AWE)Formula', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (5, N'Tag_EOF', N'EOFSignal', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (6, N'Tag_MODE', N'Mode', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (7, N'Tag_FLSHT', N'FlushTime', N'CHAR', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (8, N'Tag_ICLAS', N'InjectionClass', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (9, N'Tag_INJRO', N'InjectionRatio', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (10, N'Tag_HOLD', N'OnHold', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (11, N'Tag_AWEA', N'AutoWeightEntry(AWE)Active', N'BIT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (12, N'Tag_HOLDD', N'HoldDelay', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (13, N'Tag_RATA', N'RatioDosingActive', N'BIT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (14, N'Tag_RATP', N'RatioDosingPercentage', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (15, N'Tag_WSNO', N'WasherNumber', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (16, N'Tag_EMSG', N'NowErrorMessage', N'STRING', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (17, N'Tag_NWSH', N'NowWasher', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (18, N'Tag_NFRM', N'NowFormula', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (19, N'Tag_NINJ', N'NowInjection', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (20, N'Tag_NVLV', N'NowValve', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (21, N'Tag_NLIC', N'NowIntegrityCheck', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (22, N'Tag_SIZ', N'TankSize', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (23, N'Tag_DEV', N'TankAllowableTankLevelDeviation', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (24, N'Tag_LVL', N'TankCurrentLevel', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (25, N'Tag_MWF', N'MaximumWasherFormula', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (26, N'Tag_MFI', N'MaximumFormulaInjections', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (27, N'Tag_MIC', N'LFSInjectionClasses', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (28, N'Tag_MVLV', N'LFSChemicalValves', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (29, N'Tag_SUBF', N'FormulaSubtractor', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (30, N'Tag_SC', N'SCDDELink', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (31, N'Tag_PREF', N'PreflushSeconds', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (32, N'Tag_POSF', N'PostflushSeconds', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (33, N'Tag_VALID', N'ValidLink', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (34, N'Tag_MNFD', N'MNFDLink', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (35, N'Tag_SSL', N'SlingScaleLink', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (36, N'Tag_SDL', N'SlingDropLink', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (37, N'Tag_SUL', N'SlingUsedLink', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (38, N'Tag_RATD', N'RatioActiveLink', N'BIT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (39, N'Tag_NAME', N'Name', N'STRING', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (40, N'Tag_MOD', N'TDIModuleLink', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (41, N'Tag_YEAR', N'Year', N'STRING', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (42, N'Tag_MNTH', N'Month', N'STRING', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (43, N'Tag_DAY', N'Day', N'STRING', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (44, N'Tag_HOUR', N'Hour', N'STRING', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (45, N'Tag_MIN', N'Minutes', N'STRING', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (46, N'Tag_SC', N'Seconds', N'STRING', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (47, N'Tag_NCL', N'NumChambersLink', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (48, N'Tag_SCL', N'SOFChambersLink', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (49, N'Tag_SFL', N'SOFFidLink', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (50, N'Tag_ECL', N'EOFChamberLink', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (51, N'Tag_EFL', N'EOFFidLink', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (52, N'Tag_PFL', N'PurgeFormulaLink', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (53, N'Tag_HOLDL', N'HoldLink', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (54, N'Tag_ONOFF', N'ONOFFLink', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (55, N'Tag_TILT', N'TiltLink', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (56, N'Tag_SLING', N'SlingLink', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (57, N'Tag_MPLC', N'MeterPlcAddress', N'FLOAT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (58, N'Tag_AWEW', N'AutoWeightEntry(AWE)Weight', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (59, N'Tag_LOAD', N'LoadIDLink', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (60, N'Tag_RMAL', N'RatioMetricActiveLink', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (61, N'Tag_RML', N'RatioMetricLink', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (62, N'Tag_MLVL', N'MeterLevel', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (63, N'Tag_SR', N'SensorReading', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (64, N'Tag_SC4', N'SensorCalibrationFor4mA', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (65, N'Tag_SC20', N'SensorCalibrationFor20mA', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (66, N'Tag_PPOL', N'PpoLink', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (67, N'Tag_SRFL', N'SrfLink', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (68, N'Tag_OPSL', N'OpsLink', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (69, N'Tag_NML', N'NameLink', N'STRING', 1)​
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (70, N'Tag_NCHVLV', N'NumberofChemical Valves', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (71, N'Tag_LIADD', N'LinkIntegrityAddress', N'STRING', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (72, N'Tag_RDE', N'RatioDosingEnabled', N'BIT', 1)​
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (73, N'Tag_NLNK', N'NameLink', N'STRING', 1)
GO
--INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (74, N'Tag_AWEW', N'AutoWeightEntry(AWE)Weight', N'STRING', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (74, N'Tag_PVLFS', N'Pump/Valve LFS Chemical Name', N'STRING', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (75, N'Tag_PVKFCTR', N'Pump/Valve K-Factor', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (76, N'Tag_PVCLB', N'Pump/Valve Calibration', N'INT', 1)
GO
INSERT [TCD].[TagType] ([TagTypeId], [TagType], [TagDescription], [DataType], [Active]) VALUES (77, N'Tag_STOP', N'STOP Signal', N'INT', 1)

GO
