﻿SET IDENTITY_INSERT [TCD].[ConduitParameters] ON 

GO
INSERT [TCD].[ConduitParameters] ([Id], [ParameterID], [Name], [Description], [default_col], [SortOrder]) VALUES (1, 17, N'pH', NULL, 1, 2)
GO
INSERT [TCD].[ConduitParameters] ([Id], [ParameterID], [Name], [Description], [default_col], [SortOrder]) VALUES (2, 15, N'Temperature', NULL, 1, 3)
GO
INSERT [TCD].[ConduitParameters] ([Id], [ParameterID], [Name], [Description], [default_col], [SortOrder]) VALUES (3, 16, N'Conductivity', NULL, 1, 4)
GO
INSERT [TCD].[ConduitParameters] ([Id], [ParameterID], [Name], [Description], [default_col], [SortOrder]) VALUES (4, 607, N'Customer', NULL, 0, 1)
GO
INSERT [TCD].[ConduitParameters] ([Id], [ParameterID], [Name], [Description], [default_col], [SortOrder]) VALUES (5, 16622, N'Formula Number', NULL, 0, 5)
GO
INSERT [TCD].[ConduitParameters] ([Id], [ParameterID], [Name], [Description], [default_col], [SortOrder]) VALUES (6, 16623, N'Transfer Signal', NULL, 0, 6)
GO
INSERT [TCD].[ConduitParameters] ([Id], [ParameterID], [Name], [Description], [default_col], [SortOrder]) VALUES (7, 16624, N'Weight', NULL, 0, 7)
GO
INSERT [TCD].[ConduitParameters] ([Id], [ParameterID], [Name], [Description], [default_col], [SortOrder]) VALUES (8, 16625, N'DosingAmount', NULL, 1, 8)
GO
SET IDENTITY_INSERT [TCD].[ConduitParameters] OFF
GO

INSERT [TCD].[MachineSetup] ([GroupId], [MachineInternalId], [EcoalabAccountNumber], [ShiftId], [MachineName], [NumberOfComp], [Ex_TimeStampEject], [TurnAroundTime], [Brand], [Size], [IsPony], [IsTunnel], [HasPress]) VALUES (2, 1, N'1', 1, N'Tunnel 1', 8, NULL, NULL, NULL, NULL, NULL, 1, 1)
GO
INSERT [TCD].[MachineSetup] ([GroupId], [MachineInternalId], [EcoalabAccountNumber], [ShiftId], [MachineName], [NumberOfComp], [Ex_TimeStampEject], [TurnAroundTime], [Brand], [Size], [IsPony], [IsTunnel], [HasPress]) VALUES (10, 1, N'1', 1, N'Tunnel 2', 4, NULL, NULL, NULL, NULL, NULL, 1, 1)
GO
INSERT [TCD].[MachineSetup] ([GroupId], [MachineInternalId], [EcoalabAccountNumber], [ShiftId], [MachineName], [NumberOfComp], [Ex_TimeStampEject], [TurnAroundTime], [Brand], [Size], [IsPony], [IsTunnel], [HasPress]) VALUES (11, 1, N'1', 1, N'Tunnel 3', 5, NULL, NULL, NULL, NULL, NULL, 1, NULL)
GO
INSERT [TCD].[MachineSetup] ([GroupId], [MachineInternalId], [EcoalabAccountNumber], [ShiftId], [MachineName], [NumberOfComp], [Ex_TimeStampEject], [TurnAroundTime], [Brand], [Size], [IsPony], [IsTunnel], [HasPress]) VALUES (1, 1, N'1', 1, N'Washer 1', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL)
GO
INSERT [TCD].[MachineSetup] ([GroupId], [MachineInternalId], [EcoalabAccountNumber], [ShiftId], [MachineName], [NumberOfComp], [Ex_TimeStampEject], [TurnAroundTime], [Brand], [Size], [IsPony], [IsTunnel], [HasPress]) VALUES (1, 2, N'1', 1, N'Washer 2', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL)
GO
INSERT [TCD].[MachineSetup] ([GroupId], [MachineInternalId], [EcoalabAccountNumber], [ShiftId], [MachineName], [NumberOfComp], [Ex_TimeStampEject], [TurnAroundTime], [Brand], [Size], [IsPony], [IsTunnel], [HasPress]) VALUES (1, 3, N'1', 1, N'Washer3', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL)
GO
INSERT [TCD].[MachineSetup] ([GroupId], [MachineInternalId], [EcoalabAccountNumber], [ShiftId], [MachineName], [NumberOfComp], [Ex_TimeStampEject], [TurnAroundTime], [Brand], [Size], [IsPony], [IsTunnel], [HasPress]) VALUES (12, 1, N'1', 1, N'Tunnel 4', 1, NULL, NULL, NULL, NULL, NULL, 1, NULL)
GO
INSERT [TCD].[MachineSetup] ([GroupId], [MachineInternalId], [EcoalabAccountNumber], [ShiftId], [MachineName], [NumberOfComp], [Ex_TimeStampEject], [TurnAroundTime], [Brand], [Size], [IsPony], [IsTunnel], [HasPress]) VALUES (13, 1, N'1', 1, N'Washer 4', 0, NULL, NULL, NULL, NULL, NULL, 0, NULL)
GO

SET IDENTITY_INSERT [TCD].[ConduitChartMaster] ON 

GO
INSERT [TCD].[ConduitChartMaster] ([ChartTypeId], [Name]) VALUES (1, N'Tunnel Chart')
GO
INSERT [TCD].[ConduitChartMaster] ([ChartTypeId], [Name]) VALUES (2, N'Chemical Injection Chart')
GO
SET IDENTITY_INSERT [TCD].[ConduitChartMaster] OFF
GO


INSERT [TCD].[ConduitChartparameterMapping] ([ChartTypeId], [ParameterID], [ParameterName], [Min_Value], [Max_Value]) VALUES (1, 15, N'Temperature', N'0', N'100')
GO
INSERT [TCD].[ConduitChartparameterMapping] ([ChartTypeId], [ParameterID], [ParameterName], [Min_Value], [Max_Value]) VALUES (1, 16, N'Conductivity', N'0', N'8')
GO
INSERT [TCD].[ConduitChartparameterMapping] ([ChartTypeId], [ParameterID], [ParameterName], [Min_Value], [Max_Value]) VALUES (1, 17, N'pH', N'0', N'8')
GO
INSERT [TCD].[ConduitChartparameterMapping] ([ChartTypeId], [ParameterID], [ParameterName], [Min_Value], [Max_Value]) VALUES (1, 607, N'Customer', NULL, NULL)
GO
INSERT [TCD].[ConduitChartparameterMapping] ([ChartTypeId], [ParameterID], [ParameterName], [Min_Value], [Max_Value]) VALUES (1, 16622, N'Formaula Number', N'10', N'50')
GO
INSERT [TCD].[ConduitChartparameterMapping] ([ChartTypeId], [ParameterID], [ParameterName], [Min_Value], [Max_Value]) VALUES (1, 16623, N'Transfer Signal', N'10', N'50')
GO
INSERT [TCD].[ConduitChartparameterMapping] ([ChartTypeId], [ParameterID], [ParameterName], [Min_Value], [Max_Value]) VALUES (1, 16624, N'Weight', N'50', N'300')
GO
INSERT [TCD].[ConduitChartparameterMapping] ([ChartTypeId], [ParameterID], [ParameterName], [Min_Value], [Max_Value]) VALUES (1, 16625, N'Dosingamount', N'10', N'100')
GO
INSERT [TCD].[ConduitChartparameterMapping] ([ChartTypeId], [ParameterID], [ParameterName], [Min_Value], [Max_Value]) VALUES (2, 16622, N'Formaula Number', N'10', N'50')
GO
INSERT [TCD].[ConduitChartparameterMapping] ([ChartTypeId], [ParameterID], [ParameterName], [Min_Value], [Max_Value]) VALUES (2, 16623, N'Transfer Signal', N'10', N'50')
GO
INSERT [TCD].[ConduitChartparameterMapping] ([ChartTypeId], [ParameterID], [ParameterName], [Min_Value], [Max_Value]) VALUES (2, 16624, N'Weight', N'50', N'300')
GO
INSERT [TCD].[ConduitChartparameterMapping] ([ChartTypeId], [ParameterID], [ParameterName], [Min_Value], [Max_Value]) VALUES (2, 16626, N'Step Number', N'0', N'0')
GO
INSERT [TCD].[ConduitChartparameterMapping] ([ChartTypeId], [ParameterID], [ParameterName], [Min_Value], [Max_Value]) VALUES (2, 1, N'Print Builder Plus            ', N'0', N'2.00')
GO
INSERT [TCD].[ConduitChartparameterMapping] ([ChartTypeId], [ParameterID], [ParameterName], [Min_Value], [Max_Value]) VALUES (2, 2, N'Challenge                     ', N'0', N'3.00')
GO
INSERT [TCD].[ConduitChartparameterMapping] ([ChartTypeId], [ParameterID], [ParameterName], [Min_Value], [Max_Value]) VALUES (2, 3, N'Drymet 59                     ', N'0', N'4.00')
GO
INSERT [TCD].[ConduitChartparameterMapping] ([ChartTypeId], [ParameterID], [ParameterName], [Min_Value], [Max_Value]) VALUES (2, 4, N'Salt                          ', N'0', N'3.00')
GO
INSERT [TCD].[ConduitChartparameterMapping] ([ChartTypeId], [ParameterID], [ParameterName], [Min_Value], [Max_Value]) VALUES (2, 5, N'Dober Starch                  ', N'0', N'5.00')
GO
INSERT [TCD].[ConduitChartparameterMapping] ([ChartTypeId], [ParameterID], [ParameterName], [Min_Value], [Max_Value]) VALUES (2, 6, N'Dober Sour                    ', N'0', N'4.00')
GO
INSERT [TCD].[ConduitChartparameterMapping] ([ChartTypeId], [ParameterID], [ParameterName], [Min_Value], [Max_Value]) VALUES (2, 7, N'Dober Softener                ', N'0', N'7.00')
GO
INSERT [TCD].[ConduitChartparameterMapping] ([ChartTypeId], [ParameterID], [ParameterName], [Min_Value], [Max_Value]) VALUES (2, 8, N'Liquid Complete               ', N'0', N'4.00')
GO
INSERT [TCD].[ConduitChartparameterMapping] ([ChartTypeId], [ParameterID], [ParameterName], [Min_Value], [Max_Value]) VALUES (2, 9, N'Liquid Soften-It              ', N'0', N'7.00')
GO
INSERT [TCD].[ConduitChartparameterMapping] ([ChartTypeId], [ParameterID], [ParameterName], [Min_Value], [Max_Value]) VALUES (2, 10, N'Alkalite II                   ', N'0', N'3.00')
GO
INSERT [TCD].[ConduitChartparameterMapping] ([ChartTypeId], [ParameterID], [ParameterName], [Min_Value], [Max_Value]) VALUES (2, 11, N'Print Builder                 ', N'0', N'4.00')
GO
INSERT [TCD].[ConduitChartparameterMapping] ([ChartTypeId], [ParameterID], [ParameterName], [Min_Value], [Max_Value]) VALUES (2, 12, N'Hy-Sil                        ', N'0', N'8.00')
GO
INSERT [TCD].[ConduitChartparameterMapping] ([ChartTypeId], [ParameterID], [ParameterName], [Min_Value], [Max_Value]) VALUES (2, 13, N'Citrasolve                    ', N'0', N'8.00')
GO
INSERT [TCD].[ConduitChartparameterMapping] ([ChartTypeId], [ParameterID], [ParameterName], [Min_Value], [Max_Value]) VALUES (2, 14, N'Fabristat                     ', N'0', N'5.00')
GO
INSERT [TCD].[ConduitChartparameterMapping] ([ChartTypeId], [ParameterID], [ParameterName], [Min_Value], [Max_Value]) VALUES (2, 15, N'Spectrum Dye                  ', N'0', N'6.00')
GO
