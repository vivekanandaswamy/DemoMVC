-- My Control Fields for General & Advance tabs
-----------------------FieldGroup Changes START-----------------------------------------------


BEGIN TRY
BEGIN TRANSACTION trans

DECLARE @MaxFieldGroupId		INT
DECLARE @TempConnexxId			INT
DECLARE @TempControllerModelId	INT
DECLARE @TempFieldGroupTypeId	INT
DECLARE @TempTabId				INT
DECLARE @TempControllerTypeId	INT

SELECT @TempConnexxId = Id FROM TCD.FieldGroup WHERE Name = 'Connexx' 
						     AND ControllerModelId = (SELECT Id FROM tcd.ControllerModel WHERE Name = N'myControl' AND Active = 1)
							 AND ResourceKey = N'FieldGroup_Connexx'

SELECT @TempControllerModelId = Id FROM tcd.ControllerModel WHERE Name = N'myControl' AND Active = 1	-- ControllerModelId - 7

SELECT @TempFieldGroupTypeId = Id FROM tcd.FieldGroupType WHERE Name = N'FORM'  -- FieldGroupTypeId  - 3

SELECT @TempControllerTypeId = Id FROM tcd.ControllerType WHERE Name = N'Beckhoff'   -- ControllerTypeId  - 2

SELECT @TempTabId = Id FROM tcd.ConduitTabType WHERE Name = N'Controller Setup Advance'  -- TabId             - 3


IF NOT EXISTS(SELECT * FROM TCD.FieldGroup WHERE Name = N'Connexx 2' AND ResourceKey = N'FieldGroup_Connexx2' 
											AND ControllerModelId = (SELECT Id FROM tcd.ControllerModel WHERE Name = 'myControl' AND Active = 1)) 
BEGIN

UPDATE TCD.FieldGroup SET DisplayOrder = DisplayOrder + 1 WHERE Id > @TempConnexxId

INSERT INTO TCD.FieldGroup (Id, Name, Image_Url, ControllerModelId, FieldGroupTypeId, DisplayOrder, HelpText, TabId, ResourceKey, ControllerTypeId)
	   VALUES	(56, N'Connexx 2', NULL, @TempControllerModelId, @TempFieldGroupTypeId, 20, NULL, @TempTabId, N'FieldGroup_Connexx2', @TempControllerTypeId)

UPDATE TCD.FieldGroup SET Name = N'Connexx 1' WHERE Id = @TempConnexxId

END

-----------------------FieldGroup Changes END-----------------------------------------------

SET IDENTITY_INSERT TCD.Field ON 
-----------------------Field Changes START-----------------------------------------------
-- 1 --
DECLARE @MaxFieldId			INT

SELECT @MaxFieldId = MAX(Id) FROM TCD.Field

IF NOT EXISTS(SELECT * FROM TCD.Field WHERE Label = N'Enable Connexx' AND ResourceKey = N'FieldEnable_Connexx2')
BEGIN

INSERT INTO TCD.Field (Id, TypeId, Label, [Min], [Max], FieldGroupId, DataSourceId, IsMandatory
								, HelpText, HelpTextURL, DataTypeId, DataCategoryId, CurrencyId, DisplayOrder, ResourceKey
								, DefaultValue, IsEditable, Name, HasFieldTag, DefaultFieldTag, ClassName)
VALUES (470, 2, N'Enable Connexx', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 1, N'FieldEnable_Connexx2', NULL, 1, NULL, NULL, NULL, NULL)

END

-- 2 --


SELECT @MaxFieldId = MAX(Id) FROM TCD.Field

IF NOT EXISTS(SELECT * FROM TCD.Field WHERE Label = N'Connexx Alarm delay' AND ResourceKey = N'FieldConnexx_Alarm_Delay2')
BEGIN


INSERT INTO TCD.Field (Id, TypeId, Label, [Min], [Max], FieldGroupId, DataSourceId, IsMandatory
								, HelpText, HelpTextURL, DataTypeId, DataCategoryId, CurrencyId, DisplayOrder, ResourceKey
								, DefaultValue, IsEditable, Name, HasFieldTag, DefaultFieldTag, ClassName)
VALUES (471, 10, N'Connexx Alarm delay', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 2, N'FieldConnexx_Alarm_Delay2', N'10', 1, NULL, NULL, NULL, NULL)

END


-- 3 --


SELECT @MaxFieldId = MAX(Id) FROM TCD.Field

IF NOT EXISTS(SELECT * FROM TCD.Field WHERE Label = N'Hysteresis on Connexx alarm level' AND ResourceKey = N'FieldHysteresis_on_Connexx_Alarm_Level2')
BEGIN

INSERT INTO TCD.Field (Id, TypeId, Label, [Min], [Max], FieldGroupId, DataSourceId, IsMandatory
								, HelpText, HelpTextURL, DataTypeId, DataCategoryId, CurrencyId, DisplayOrder, ResourceKey
								, DefaultValue, IsEditable, Name, HasFieldTag, DefaultFieldTag, ClassName)
VALUES (472, 10, N'Hysteresis on Connexx alarm level', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 3, N'FieldHysteresis_on_Connexx_Alarm_Level2', N'2', 1, NULL, NULL, NULL, NULL)

END

-- 4 --

DECLARE @TempDisplayOrder	INT

SELECT @MaxFieldId = MAX(Id) FROM TCD.Field

SELECT @TempDisplayOrder = DisplayOrder FROM TCD.Field WHERE Label = N'Alarm Deep tray enabled' AND ResourceKey  = N'Alarm_Deep_Tray_Enabled'

IF NOT EXISTS(SELECT * FROM TCD.Field WHERE Label = N'W&E Logger function enable' AND ResourceKey = N'FieldW&E_Logger_function_enable')
BEGIN

INSERT INTO TCD.Field (Id, TypeId, Label, [Min], [Max], FieldGroupId, DataSourceId, IsMandatory
								, HelpText, HelpTextURL, DataTypeId, DataCategoryId, CurrencyId, DisplayOrder, ResourceKey
								, DefaultValue, IsEditable, Name, HasFieldTag, DefaultFieldTag, ClassName)
VALUES (473, 2, N'W&E Logger function enable', NULL, NULL, NULL, NULL, NULL, N'W&E Logger function enable', NULL, 4, NULL, NULL, @TempDisplayOrder + 1, N'FieldW&E_Logger_function_enable', NULL, 1, NULL, NULL, NULL, NULL)

END

IF EXISTS(SELECT * 
		  FROM   tcd.field 
		  WHERE  label = N'Enable Connexx' 
				 AND resourcekey = N'FieldEnable_Connexx2') 
  BEGIN 
	  UPDATE [TCD].[field] 
	  SET    hasfieldtag = 'Tag_EC2', 
			 defaultfieldtag = 'x_Connex2_En' 
	  WHERE  label = N'Enable Connexx' 
			 AND resourcekey = N'FieldEnable_Connexx2' 
  END 

IF EXISTS(SELECT * 
		  FROM   tcd.field 
		  WHERE  label = N'Connexx Alarm delay' 
				 AND resourcekey = N'FieldConnexx_Alarm_Delay2') 
  BEGIN 
	  UPDATE [TCD].[field] 
	  SET    hasfieldtag = 'Tag_CAD2', 
			 defaultfieldtag = 'uint_Connex2_Alarm_Delay' 
	  WHERE  label = N'Connexx Alarm delay' 
			 AND resourcekey = N'FieldConnexx_Alarm_Delay2' 
  END 

IF EXISTS(SELECT * 
		  FROM   tcd.field 
		  WHERE  label = N'Hysteresis on Connexx alarm level' 
				 AND resourcekey = N'FieldHysteresis_on_Connexx_Alarm_Level2') 
  BEGIN 
	  UPDATE [TCD].[field] 
	  SET    hasfieldtag = 'Tag_HCAL2', 
			 defaultfieldtag = 'uint_Connex2_Level_Delay' 
	  WHERE  label = N'Hysteresis on Connexx alarm level' 
			 AND resourcekey = N'FieldHysteresis_on_Connexx_Alarm_Level2' 
  END 

IF EXISTS(SELECT * 
		  FROM   tcd.field 
		  WHERE  label = N'W&E Logger function enable' 
				 AND resourcekey = N'FieldW&E_Logger_function_enable') 
  BEGIN 
	  UPDATE [TCD].[field] 
	  SET    hasfieldtag = 'Tag_WELE', 
			 defaultfieldtag = 'x_WandE_Enable' 
	  WHERE  label = N'W&E Logger function enable' 
			 AND resourcekey = N'FieldW&E_Logger_function_enable' 
  END 

IF EXISTS(SELECT * 
		  FROM   tcd.field 
		  WHERE  label = N'Invert Machine Stop' 
				 AND resourcekey = N'InvertMachineStop') 
  BEGIN 
	  UPDATE [TCD].[field] 
	  SET    hasfieldtag = 'Tag_IMS', 
			 defaultfieldtag = 'x_invertMachineStop' 
	  WHERE  label = N'Invert Machine Stop' 
			 AND resourcekey = N'InvertMachineStop' 
  END 
  
-----------------------Field Changes END-----------------------------------------------
SET IDENTITY_INSERT TCD.Field OFF 
-----------------------FieldGroupFieldMapping Changes START---------------------------------------------

DECLARE @Connexx2FieldGroupId						INT
DECLARE @FieldEnableConnexx2						INT
DECLARE @FieldConnexxAlarmDelay2					INT
DECLARE @FieldHysteresisonConnexxAlarmLevel2		INT
DECLARE @FieldWELoggerfunctionenable				INT
DECLARE @MyControlParametersFieldGroupId						INT

SELECT @Connexx2FieldGroupId = Id FROM TCD.FieldGroup WHERE Name = N'Connexx 2' AND ResourceKey = N'FieldGroup_Connexx2' 
											AND ControllerModelId = (SELECT Id FROM tcd.ControllerModel WHERE Name = 'myControl' AND Active = 1)

SELECT @FieldEnableConnexx2 = Id FROM TCD.Field WHERE Label = N'Enable Connexx' AND ResourceKey = N'FieldEnable_Connexx2'

SELECT @FieldConnexxAlarmDelay2 = Id FROM TCD.Field WHERE Label = N'Connexx Alarm delay' AND ResourceKey = N'FieldConnexx_Alarm_Delay2'

SELECT @FieldHysteresisonConnexxAlarmLevel2 = Id FROM TCD.Field WHERE Label = N'Hysteresis on Connexx alarm level' AND ResourceKey = N'FieldHysteresis_on_Connexx_Alarm_Level2'

SELECT @FieldWELoggerfunctionenable = Id FROM TCD.Field WHERE Label = N'W&E Logger function enable' AND ResourceKey = N'FieldW&E_Logger_function_enable'

SELECT @MyControlParametersFieldGroupId = Id FROM TCD.FieldGroup WHERE Name = N'my Control Parameters' AND ResourceKey = N'FieldGroup_myControlParameters' 
											AND ControllerModelId = (SELECT Id FROM tcd.ControllerModel WHERE Name = 'myControl' AND Active = 1)


IF NOT EXISTS(SELECT * FROM tcd.FieldGroupFieldMapping WHERE FieldGroupId = @Connexx2FieldGroupId)
BEGIN

INSERT INTO TCD.FieldGroupFieldMapping (FieldGroupId, FieldId)
			VALUES (@Connexx2FieldGroupId, @FieldEnableConnexx2)
				,(@Connexx2FieldGroupId, @FieldConnexxAlarmDelay2)
				,(@Connexx2FieldGroupId, @FieldHysteresisonConnexxAlarmLevel2)
END

IF NOT EXISTS(SELECT * FROM tcd.FieldGroupFieldMapping WHERE FieldGroupId = @MyControlParametersFieldGroupId AND FieldId = @FieldWELoggerfunctionenable)
BEGIN

INSERT INTO TCD.FieldGroupFieldMapping (FieldGroupId, FieldId)
			VALUES (@MyControlParametersFieldGroupId, @FieldWELoggerfunctionenable)
END


 COMMIT TRANSACTION trans
 PRINT 'Records Inserted Successfully'
 
END TRY
BEGIN CATCH
 PRINT 'Error Occured'

ROLLBACK TRANSACTION trans 

END CATCH 
-----------------------FieldGroupFieldMapping Changes END-----------------------------------------------
GO
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetTunnelFormulaWashStep]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetTunnelFormulaWashStep
	END
GO

/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_GetTunnelFormulaWashStep]                                             

Purpose:				To get the tunnel formula wash step.

Parameters:				@EcoLabAccountNumber - holds ecolab account number.
						@ProgramSetupId - holds the program setup id.
						@DosingSetupId - holds the dosing setup id.
																
###################################################################################################                                           
*/

CREATE	PROCEDURE	[TCD].[GetTunnelFormulaWashStep]

					@EcoLabAccountNumber					NVARCHAR(1000)

				,	@ProgramSetupId							INT

				,	@DosingSetupId							INT				=	NULL			--Null for LIST
        
				,	@Is_Deleted								BIT				=  'FALSE'

AS

BEGIN

SET	NOCOUNT	ON
		
		DECLARE @WaterInletDrain VARCHAR(30) = NULL;
		SELECT @WaterInletDrain = NAME FROM [TCD].TunnelWaterInletDrainLookup TW WHERE TW.TunnelWaterInletDrainLookupId = 1;		

		SELECT		   TDS.[ProgramNumber]

			  ,TDS.[GroupId]

			  ,TDS.[EcolabAccountNumber]

			  ,ISNULL(TDS.StepTypeId, TC.WashStepId) AS StepTypeId

			  ,TDS.[StepRunTime]

			  ,TDS.[CompartmentNumber]

			  ,TDS.[Temperature]

			  ,TDS.[TunnelDosingSetupId]

			  ,TDS.[WaterType]

			  ,ISNULL(TDS.WaterLevel, TC.WaterLevel) AS WaterLevel

			  ,ISNULL(TWIDL.Name , @WaterInletDrain) AS WaterInletDrain

			  ,TDS.[Note]

			  ,TDS.[TunnelProgramSetupId]

			  ,(SELECT TunnelWaterFlowTypeName
				FROM TCD.TunnelWaterFlowType twft
				WHERE twft.TunnelWaterFlowTypeId = TC.WaterFlowId) AS WaterFlow
			  ,(SELECT WS.MyServiceWshOpId
				FROM TCD.WashStep ws
				WHERE ws.StepId	 = TC.WashStepId) AS MyServiceWshOpId
			  ,(SELECT WT.MyServiceUtilId
				FROM TCD.WaterType WT
				WHERE WT.Id	 = TDS.WaterType) AS MyServiceUtilId
			  ,(SELECT DD.MyServiceDrainTypeId
				FROM TCD.DrainDestination DD
				WHERE DD.DrainDestinationId = TDS.DrainDestinationId) AS MyServiceDrainTypId
			  ,TDS.Is_Deleted		As	IsDelete
			  ,TDS.MyServiceCustFrmulaStpGUID			  
			  ,(SELECT STUFF((SELECT ',' + CAST(S.SensorType AS VARCHAR(2))
					FROM TCD.Sensor S WHERE (S.MachineCompartment = TDS.CompartmentNumber OR S.MachineCompartment IS NULL)
						AND S.GroupId = MS.GroupId AND S.EcolabAccountNumber = @EcoLabAccountNumber AND S.Is_deleted = 0 GROUP BY S.SensorType
					FOR XML PATH('')) ,1,1,'')) AS SensorAttached
		FROM 
		[TCD].TunnelDosingSetup TDS
		INNER JOIN [TCD].MachineSetup MS ON MS.GroupId = TDS.GroupId
		AND MS.EcoalabAccountNumber = TDS.EcolabAccountNumber	
		LEFT JOIN [TCD].TunnelCompartment TC ON TC.WasherId = MS.WasherId AND TC.CompartmentNumber = TDS.CompartmentNumber AND TC.EcoLabAccountNumber = TDS.EcolabAccountNumber
		LEFT JOIN [TCD].TunnelWaterInletDrainLookup TWIDL ON TWIDL.TunnelWaterInletDrainLookupId = TC.WaterInletDrainId			
		WHERE 

		TDS.EcolabAccountNumber = @EcoLabAccountNumber 

		AND TDS.TunnelProgramSetupId = @ProgramSetupId

		AND	TDS.TunnelDosingSetupId	=	ISNULL(@DosingSetupId, TDS.TunnelDosingSetupId)

		AND (TDS.Is_Deleted						=			'False' OR TDS.Is_Deleted = @Is_Deleted)
    
		AND (MS.IsDeleted						  =			'False')

		ORDER BY TDS.[CompartmentNumber]

SET	NOCOUNT	OFF

END
GO
-------------------------------------
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[SavePlantSensorDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.SavePlantSensorDetails
	END
GO


CREATE PROCEDURE TCD.SavePlantSensorDetails(
      @SensorNumber NVARCHAR( 100) = NULL,
      @EcolabAccountNumber NVARCHAR( 25) = NULL,
      @ControllerID VARCHAR( 1000) = NULL,
      @SensorName NVARCHAR( 100) = NULL,
      @SensorType NVARCHAR( 100) = NULL,
      @SensorLocation NVARCHAR( 100) = NULL,
      @MachineCompartment NVARCHAR( 100) = NULL,
      @OutputType NVARCHAR( 100) = NULL,
      @ChemicalforChart NVARCHAR( 100)= NULL,
      @UOM NVARCHAR( 100) = NULL,
      @DashboardActualValue VARCHAR( 100) = NULL,
      @UserID INT,
      @AnalogueInputNumber NVARCHAR( 100) = NULL,
      @Calibration4mA DECIMAL( 18, 2) = NULL,
      @Calibration20mA DECIMAL( 18, 2) = NULL,
      @TagAddress4mA NVARCHAR( 100) = NULL,
      @TagAddress20mA NVARCHAR( 100) = NULL,
      @Scope VARCHAR( 100)OUTPUT,
      @OutputSensorId INT = NULL OUTPUT,
      @LastModifiedTimestampAtCentral DATETIME = NULL,
      @OutputLastModifiedTimestampAtLocal DATETIME = NULL OUTPUT)
AS
     BEGIN
         SET NOCOUNT ON;
         DECLARE @IsPlant BIT = NULL,
         @IsPress BIT = NULL,
         @IStunnel INT = '';
         DECLARE @TypeLimit INT = NULL,
         @TempLimit INT = NULL,
         @pHLimit INT = NULL,
         @ConductivityLimit INT = NULL,
         @WeightLimit INT = NULL,
         @ControllerModelID INT = NULL;
         DECLARE @ReturnValue INT = 0,
         @ErrorId INT = 0,
         @ErrorMessage NVARCHAR( 4000) = N'',
         @CurrentUTCTime DATETIME = GETUTCDATE();
         DECLARE @OutputList AS TABLE( SensorId INT,LastModifiedTimestamp DATETIME);
         SET @OutputLastModifiedTimestampAtLocal = ISNULL( @OutputLastModifiedTimestampAtLocal, NULL);

         --SQLEnlight

         SET @OutputSensorId = ISNULL( @OutputSensorId, NULL);

         /*Maximum one Sensor with the same type can be connected to one machine/Compartement */

         IF @LastModifiedTimestampAtCentral IS NOT NULL
            AND
            NOT EXISTS( SELECT 1
                        FROM TCD.Sensor AS S
                        WHERE S.EcolabAccountNumber = @EcolabAccountNumber
                              AND
                              S.SensorId = @SensorNumber
                              AND
                              S.LastModifiedTime = @LastModifiedTimestampAtCentral
                      )
             BEGIN
                 SET @ErrorId = 60000;
                 SET @ErrorMessage = N'' + CAST( @ErrorId AS NVARCHAR);
                 RAISERROR( @ErrorMessage, 16, 1);
                 SET @ReturnValue = -1;
                 RETURN @ReturnValue;
             END;
         SET @Scope = '';
         SELECT @TypeLimit = COUNT( 1)
         FROM TCD.Sensor AS S
         WHERE GroupId = @SensorLocation
               AND
               S.SensorType = @SensorType
               AND
               ISNULL( MachineCompartment, 0) = @MachineCompartment
               AND
               Is_deleted = 0
               AND
               ControllerID IN(
               SELECT ControllerId
               FROM TCD.ConduitController
               WHERE ControllerId = @ControllerID
                     AND
                     EcoalabAccountNumber = @EcolabAccountNumber
                              )
               AND
               EcolabAccountNumber = @EcolabAccountNumber;

         /*Maximum 6 Temperature sensor can be connected to the same Washter-Tunnel */

         SELECT @TempLimit = COUNT( 1)
         FROM TCD.Sensor AS S LEFT OUTER JOIN TCD.machinesetup AS MS ON S.GroupId = MS.groupId
                                                                        AND
                                                                        S.EcolabAccountNumber = MS.EcoalabAccountNumber
         WHERE S.SensorType = 1
               AND
               S.GroupID = @SensorLocation
               AND
               Ms.Istunnel = 1
               AND
    IS_deleted = 0
               AND
               S.ControllerID IN(
               SELECT ControllerId
               FROM TCD.ConduitController
               WHERE ControllerModelId = 7
                     AND
                     EcoalabAccountNumber = @EcolabAccountNumber
                                )
               AND
               S.EcolabAccountNumber = @EcolabAccountNumber;

         /* Maximum 2 pH sensor can be connected to the same Washter-Tunnel */

         SELECT @pHLimit = COUNT( 1
                                )
         FROM TCD.Sensor AS S LEFT OUTER JOIN TCD.machinesetup AS MS ON S.GroupId = MS.groupId
                                                                        AND
                                                                        S.EcolabAccountNumber = MS.EcoalabAccountNumber
         WHERE S.SensorType = 2
               AND
               S.GroupID = @SensorLocation
               AND
               Ms.Istunnel = 1
               AND
               IS_deleted = 0
               AND
               S.ControllerID IN(
               SELECT ControllerId
               FROM TCD.ConduitController
               WHERE ControllerModelId = 7
                     AND
                     EcoalabAccountNumber = @EcolabAccountNumber
                                )
               AND
               S.EcolabAccountNumber = @EcolabAccountNumber;

         /* Maximum 1 Conductivity sensor can be connected to the same Washter-Tunnel */

         SELECT @ConductivityLimit = COUNT( 1)
         FROM TCD.Sensor AS S LEFT OUTER JOIN TCD.machinesetup AS MS ON S.GroupId = MS.groupId
                                                                        AND
                                                                        S.EcolabAccountNumber = MS.EcoalabAccountNumber
         WHERE S.SensorType = 4
               AND
               S.GroupID = @SensorLocation
               AND
               Ms.Istunnel = 1
               AND
               IS_deleted = 0
               AND
               S.ControllerID IN(
               SELECT ControllerId
               FROM TCD.ConduitController
               WHERE ControllerModelId = 7
                     AND
                     EcoalabAccountNumber = @EcolabAccountNumber
                                )
               AND
               S.EcolabAccountNumber = @EcolabAccountNumber;

         /* Maximum 1 Weight sensor can be connected to the same Washter-Tunnel */

         SELECT @WeightLimit = COUNT( 1)
         FROM TCD.Sensor AS S LEFT OUTER JOIN TCD.machinesetup AS MS ON S.GroupId = MS.groupId
                                                                        AND
                                                                        S.EcolabAccountNumber = MS.EcoalabAccountNumber
         WHERE S.SensorType = 5
               AND
               S.GroupID = @SensorLocation
               AND
               Ms.Istunnel = 1
               AND
               IS_deleted = 0
               AND
               S.ControllerID IN(
               SELECT ControllerId
               FROM TCD.ConduitController
               WHERE ControllerModelId = 7
                     AND
                     EcoalabAccountNumber = @EcolabAccountNumber
                                )
               AND
               S.EcolabAccountNumber = @EcolabAccountNumber;
         SELECT @ControllerModelID = ControllerModelId
         FROM TCD.ConduitController
         WHERE ControllerId = @ControllerID
               AND
               EcoalabAccountNumber = @EcolabAccountNumber;
         SELECT @IStunnel = Istunnel
         FROM TCD.machinesetup AS MS
         WHERE Ms.GroupId = @SensorLocation
               AND
               MS.EcoalabAccountNumber = @EcolabAccountNumber;
         IF @IStunnel = 1
             BEGIN				
                 IF @MachineCompartment = 1
                     BEGIN
                         SET @IsPress = 1;
                     END;
				IF @MachineCompartment = 0
                 BEGIN
					SET @MachineCompartment = NULL;
				 END
             END;
         IF @SensorLocation = 1
             BEGIN
                 SET @IsPlant = 1;
                 SET @SensorLocation = NULL;
                 SET @MachineCompartment = NULL;
             END;
         IF @ControllerID = -1
             BEGIN
                 SELECT TOP ( 1
                            )@ControllerID = ControllerID
                 FROM TCD.ConduitController
                 WHERE ControllerModelId = @ControllerModelID
                       AND
                       EcoalabAccountNumber = @EcolabAccountNumber;
             END;
         ELSE
             BEGIN
                 SELECT @ControllerModelID = ControllerModelId
                 FROM TCD.ConduitController
                 WHERE ControllerId = @ControllerID
                       AND
                       EcoalabAccountNumber = @EcolabAccountNumber;
             END;
         IF @ControllerID != -1
             BEGIN

                 /* Inserting the values in to Sensor table if it is new Sensor */

                 DECLARE @NewSensorId INT,
                 @ModuleType INT = 3,
                 @DefaultFrequency INT = 60,
                 @TagType VARCHAR( 100) = 'Tag_MPLC',
                 @TagTypeSC4 VARCHAR( 100) = 'Tag_SC4',
                 @TagTypeSC20 VARCHAR( 100) = 'Tag_SC20',
                 @Result1 INT = NULL,
                 @Result2 INT = NULL,
                 @Result3 INT = NULL,
                 @Type INT = 3,
                 @AllowTagEdit BIT;
                 SELECT @AllowTagEdit = CASE
                                            WHEN COUNT( *) > 0
                                            THEN 'TRUE'
                                            ELSE 'FALSE'
                                        END
                 FROM TCD.UserMaster AS UM INNER JOIN TCD.UserInRole AS UIR
                 ON UM.UserId = UIR.UserId
                                           INNER JOIN TCD.UserRoles AS UR
                 ON UIR.RoleId = UR.RoleId
                 WHERE UM.UserId = @UserID
                       AND
                       UR.LevelId >= 8
                       AND
                       UM.EcolabAccountNumber = @EcolabAccountNumber;
                 IF NOT EXISTS( SELECT *
                                FROM TCD.Sensor
                                WHERE SensorID = @SensorNumber
                                      AND
                                      EcolabAccountNumber = @EcolabAccountNumber
                              )

                     -- Begin Create Sensor

                     BEGIN
                         BEGIN
                             DECLARE @AllowInsert BIT = 'FALSE';
                             IF @TypeLimit < 1
                                 BEGIN
                                     IF @ControllerModelID = 7
                                         BEGIN
                                             IF @SensorType = 1
                                                 BEGIN
                                                     IF @TempLimit < 6
                                                         BEGIN
                                                             SET @AllowInsert = 'TRUE';
                                                         END;
                                                     ELSE
                                                         BEGIN
                                                             SET @SCOPE = @SCOPE + '401,';
                                                         END;
                                                 END;
                                             ELSE
                                 BEGIN
                                                     IF @SensorType = 2
                                                         BEGIN
                                                             IF @pHLimit < 2
                                                                 BEGIN
                                                                     SET @AllowInsert = 'TRUE';
                                                                 END;
                                                             ELSE
                                                                 BEGIN
                                                                     SET @SCOPE = @SCOPE + '301,';
                                                                 END;
                                                         END;
                                                     ELSE
                                                         BEGIN
                                                             IF @SensorType = 4
                                                                 BEGIN
                                                                     IF @ConductivityLimit < 1
                                                                         BEGIN
                                                                             SET @AllowInsert = 'TRUE';
                                                                         END;
                                                                     BEGIN
                                                                         SET @SCOPE = @SCOPE + '201,';
                                                                     END;
                                                                 END;
                                                             ELSE
                                                                 BEGIN
                                                                     IF @SensorType = 5
                                                                         BEGIN
                                                                             IF @WeightLimit < 1
                                                                                 BEGIN
                                                                                     SET @AllowInsert = 'TRUE';
                                                                                 END;
                                                                             ELSE
                                                                                 BEGIN
                                                                                     SET @SCOPE = @SCOPE + '101,';
                                                                                 END;
                                                                         END;
                                                                 END;
                                                         END;
                                                 END;
                                         END;
                                     ELSE
                                         BEGIN
                                             SET @AllowInsert = 'TRUE';
                                         END;
                                 END;
                             ELSE
                                 BEGIN
                                     SET @Scope = @Scope + '501,';
                                 END;

                             -- End Business Validations
                             -- Begin Insert if Validation Succeeds

                             IF @AllowInsert = 'TRUE'
                                 BEGIN
                                     DECLARE @SensorCount INT;
                                     SELECT @SensorCount = MAX( s.SensorId)+1
                                     FROM TCD.Sensor AS s WITH ( NOLOCK);
                                 
                                     INSERT INTO TCD.Sensor( Description,
                                     SensorType,
                                     GroupId,
                                     MachineCompartment,
                                     EcolabAccountNumber,
                                     ControllerID,
                                     OutputType,
                                     ChemicalforChart,
                                     UOM,
                                     DashboardActualValue,
                                     LastModifiedByUserId,
                                     IsPlant,
                                     IsPress,
                                     Calibration4mA,
                                     Calibration20mA,
                                     Id
                                                           )
                                     OUTPUT inserted.SensorId AS SensorId,
                                     inserted.LastModifiedTime AS LastModifiedTimestamp
                                            INTO @OutputList( SensorId,
                                            LastModifiedTimestamp
                                                            )
                                     SELECT @SensorName,
                                     @SensorType,
                                     @SensorLocation,
                                     @MachineCompartment,
                                     @EcolabAccountNumber,
                                     @ControllerID,
                                     @OutputType,
                                     @ChemicalforChart,
                                     @UOM,
                                     @DashboardActualValue,
                                     @UserID,
                                     @IsPlant,
                                     @IsPress,
                                     @Calibration4mA,
                                     @Calibration20mA,
                                     @SensorCount;
                                     SET @NewSensorId = SCOPE_IDENTITY(
                                                                      );
                                 END;
                         END;
                     END;
                 ELSE

                     ------------------------------------------------------------------------------------------------------------------
                     -- Begin Update Sensor

                     BEGIN
                         DECLARE @PlantId INT = ( SELECT MG.Id
                                                  FROM TCD.MachineGroupType AS MGT INNER JOIN TCD.MachineGroup AS MG
                                                  ON MGT.Id = MG.GroupTypeId
                                                  WHERE MGT.Id = 1
                                                        AND
                                                        MG.Is_Deleted = 0
                                                );

                         -- Check RedFlag Association and Update Sensor

                         IF(( SELECT COALESCE( S.GroupId, ''
                                             )
                              FROM TCD.Sensor AS S
                              WHERE S.SensorId = @SensorNumber
                            ) != COALESCE( @SensorLocation, ''
                                         )
                            OR
                            ( SELECT COALESCE( S.MachineCompartment, ''
                                             )
                              FROM TCD.Sensor AS S
                              WHERE S.SensorId = @SensorNumber
                            ) != COALESCE( @MachineCompartment, ''
                                         ))
                           AND
                           EXISTS( SELECT 1
                                   FROM TCD.RedFlag AS RF INNER JOIN TCD.RedFlagMappingData AS RFM
                                   ON RF.Id = RFM.MappingId
                                      AND
                                      RF.Is_Deleted = 0
                                      AND
                                      RFM.Is_Deleted = 0
                                                          LEFT JOIN TCD.Sensor AS S
                                   ON RF.Location = CASE S.IsPlant
                                                        WHEN 'TRUE'
                                                        THEN COALESCE( S.GroupId, @PlantId
                                                                     )
                                                        ELSE S.GroupId
                                                    END
                                      AND
                                      COALESCE( S.MachineCompartment, 0
                                              ) = COALESCE( RFM.MachineId, 0
                                                          )
                                      AND
                                      S.Is_deleted = 0
                                   WHERE S.SensorId = @SensorNumber
                                 )
                             BEGIN
                                 SET @Scope = '405,';
                             END;
                         ELSE
                             BEGIN
                                 IF(@Result1 IS NULL
                                    OR
                                    @Result1 <> 0)
                                   AND
                                   (@Result2 IS NULL
                                    OR
                                    @Result2 <> 0)
                                   AND
                                   (@Result3 IS NULL
                                    OR
                                    @Result3 <> 0)
                                     BEGIN
                                         DECLARE @AllowUpdate BIT = 'FALSE';

                                         --Begin Get old Sensor Values

                                         BEGIN
                                             DECLARE @uty INT = ( SELECT sensortype
                                                                  FROM TCD.Sensor
                                                                  WHERE SensorID = @SensorNumber
                                                                        AND
                                                                        EcolabAccountNumber = @EcolabAccountNumber
                                                                );
                                             DECLARE @grpId INT = ( SELECT GroupId
                                                                    FROM TCD.Sensor
                                                                    WHERE SensorID = @SensorNumber
                                                                          AND
                                                                          EcolabAccountNumber = @EcolabAccountNumber
                                                                  );
                                             DECLARE @machId INT = ( SELECT MachineCompartment
                                                                     FROM TCD.Sensor
                                                                     WHERE SensorID = @SensorNumber
                                                                           AND
                                                                           EcolabAccountNumber = @EcolabAccountNumber
                                   );
                                         END;

                                         --Begin Get old Sensor Values

                                         IF @uty <> @SensorType
                                            OR
                                            @grpId <> @SensorLocation
                                            OR
                                            @machId <> @MachineCompartment
                                             BEGIN
                                                 IF @TypeLimit < 1
                                                     BEGIN
                                                         IF @ControllerModelID = 7
                                                             BEGIN
                                                                 IF @SensorType = 1
                                                                     BEGIN
                                                                         IF @TempLimit < 6
                                                                             BEGIN
                                                                                 SET @AllowUpdate = 'TRUE';
                                                                             END;
                                                                         ELSE
                                                                             BEGIN
                                                                                 SET @SCOPE = @SCOPE + '401,';
                                                                             END;
                                                                     END;
                                                                 ELSE
                                                                     BEGIN
                                                                         IF @SensorType = 2
                                                                             BEGIN
                                                                                 IF @pHLimit < 2
                                                                                     BEGIN
                                                                                         SET @AllowUpdate = 'TRUE';
                                                                                     END;
                                                                                 ELSE
                                                                                     BEGIN
                                                                                         SET @SCOPE = @SCOPE + '301,';
                                                                                     END;
                                                                             END;
                                                                         ELSE
                                                                             BEGIN
                                                                                 IF @SensorType = 4
                                                                                     BEGIN
                                                                                         IF @ConductivityLimit < 1
                                                                                             BEGIN
                                                                                                 SET @AllowUpdate = 'TRUE';
                                                                                             END;
                                                                                         ELSE
                                                                                             BEGIN
                                               SET @SCOPE = @SCOPE + '201,';
                                                                                             END;
                                                                                     END;
                                                                                 ELSE
                                                                                     BEGIN
                                                                                         IF @SensorType = 5
                                                                                             BEGIN
                                                                                                 IF @WeightLimit < 1
                                                                                                     BEGIN
                                                                                                         SET @AllowUpdate = 'TRUE';
                                                                                                     END;
                                                                                                 ELSE
                                                                                                     BEGIN
                                                                                                         SET @SCOPE = @SCOPE + '101,';
                                                                                                     END;
                                                                                             END;
                                                                                     END;
                                                                             END;
                                                                     END;
                                                             END;
                                                         ELSE
                                                             BEGIN
                                                                 BEGIN
                                                                     SET @AllowUpdate = 'TRUE';
                                                                 END;
                                                             END;
                                                     END;
                                                 ELSE
                                                     BEGIN
                                                         SET @SCOPE = @SCOPE + '501,';
                                                     END;
                                             END;
                                         ELSE
                                             BEGIN
                                                 SET @AllowUpdate = 'TRUE';
                                             END;
                                         IF @AllowUpdate = 'TRUE'
                                             BEGIN
                                                 IF @LastModifiedTimestampAtCentral IS NOT NULL
                                                    AND
                                                    NOT EXISTS( SELECT 1
                                                                FROM TCD.Sensor AS S
                                                                WHERE S.EcolabAccountNumber = @EcolabAccountNumber
                                                                      AND
                                                                      S.SensorId = @SensorNumber
                                                                      AND
                                                                      S.LastModifiedTime = @LastModifiedTimestampAtCentral
           )
                                                     BEGIN
                                                         SET @ErrorId = 60000;
                                                         SET @ErrorMessage = N'' + CAST( @ErrorId AS NVARCHAR
                                                                                       ) + N': Record not in-synch between plant and central.';
                                                         RAISERROR( @ErrorMessage, 16, 1
                                                                  );
                                                         SET @ReturnValue = -1;
                                                         RETURN @ReturnValue;
                                                     END;
                                                 UPDATE s
                                                        SET Description = @SensorName,
                                                 SensorType = @SensorType,
                                                 GroupId = @SensorLocation,
                                                 MachineCompartment = @MachineCompartment,
                                                 S.ControllerID = @ControllerID,
                                                 OutputType = @OutputType,
                                                 ChemicalforChart = @ChemicalforChart,
                                                 UOM = @UOM,
                                                 DashboardActualValue = @DashboardActualValue,
                                                 LastModifiedByUserId = @UserID,
                                                 Calibration4mA = @Calibration4mA,
                                                 Calibration20mA = @Calibration20mA,
                                                 LastModifiedTime = @CurrentUTCTime
                                                 OUTPUT inserted.SensorId AS SensorId,
                                                 inserted.LastModifiedTime AS LastModifiedTimestamp
                                                        INTO @OutputList( SensorId,
                                                        LastModifiedTimestamp
                                                                        )
                                                 FROM TCD.Sensor S
                                                 WHERE SensorID = @SensorNumber
                                                       AND
                                                       EcolabAccountNumber = @EcolabAccountNumber;
                                             END;
                                     END;
                             END;
                     END;

             -- End Update Sensor

             END;
         ELSE
             BEGIN
                 SELECT @Scope = '701,';
             END;
         SET NOCOUNT OFF;
         SELECT TOP 1 @OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp,
         @OutputSensorId = O.SensorId
         FROM @OutputList AS O;
         RETURN @ReturnValue;
     END;

	 GO
-----------------------------------
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetPlantMeterMachines]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetPlantMeterMachines
	END
GO

/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_GetPlantMetermachines]                                             

Purpose:				To get details of meter machines of a plant

Parameters:             @GroupTypeID - holds the value for group type Id.
						
###################################################################################################                                           
*/
CREATE PROCEDURE [TCD].[GetPlantMeterMachines] (@GroupTypeID int, @EcolabAccountNumber NVARCHAR(25))
AS 
    BEGIN 
      SET nocount ON; 
	  Declare @Istunnel int = NULL,@TypeId INT = NULL
	  select @IStunnel = Istunnel from [TCD].machinesetup where GroupId = @GroupTypeID 
		
	  SELECT @TypeId = GroupTypeId FROM  [TCD].MachineGroup WHERE Id = @GroupTypeID AND Is_Deleted = 0
	  IF(@TypeId = 1)
		BEGIN
			SELECT 0, 'ALL', NULL,0
		END
		ELSE
			IF(@TypeId = 2)
			BEGIN
				IF(@IStunnel = 1)
				Begin
					Declare @NoofComp Int, @Count int = 2,@HasPress BIT, @ControllerId INT
					SELECT @NoOfcomp = NumberOfComp, @ControllerId = ControllerId  FROM [TCD].MachineSetup where Groupid = @GroupTypeID and IsTunnel = 1
					Select @HasPress = HasPress from [TCD].machinesetup where GroupId = @GroupTypeID
					--IF((SELECT COUNT(1) FROM TCD.GROUPTYPE GT LEFT JOIN TCD.MachineSetup MS ON MS.GroupId = GT.Id WHERE GT.Id = @GroupTypeID AND MS.HasPress = 1)>0)
					--SET @HasPress = 1 ELSE SET @HasPress = 0
					CREATE TABLE #GET_COMPARTMENT
					(
					MachineID INT,
					CompartmentNumber VARCHAR(1000),
					ControllerId INT,
					PlantWasherNumber INT
					)
					While(@count <=  @NoOfcomp + 1) 
					begin
						Insert into #GET_COMPARTMENT(MachineID,CompartmentNumber,ControllerId,PlantWasherNumber)
						select @count-1,'Compartment'+ cast(@count - 1 as Varchar(1000))+'',@ControllerId,0
						Set @count = @count + 1
					End
					IF (@HasPress = 1)
					BEGIN 
						SELECT 0, 'ALL', @ControllerId,0 UNION Select 1,'Press', @ControllerId,0 Union all Select MachineID,CompartmentNumber,ControllerId,PlantWasherNumber from #GET_COMPARTMENT   END
					ELSE 
					BEGIN 
						SELECT 0, 'ALL', @ControllerId,0 UNION ALL Select MachineID,CompartmentNumber,ControllerId,PlantWasherNumber from #GET_COMPARTMENT END
					End
				Else 
				Begin 
					SELECT 0, 'ALL', NULL,0
					UNION 
					Select Distinct MS.WasherId,MS.MachineName,MS.ControllerId,WS.PlantWasherNumber from [TCD].machinesetup MS LEFT JOIN TCD.Washer WS ON MS.WasherId = WS.WasherId where GroupID = @GroupTypeID AND IsDeleted = 0 And EcoalabAccountNumber = @EcolabAccountNumber AND ISNULL(MS.ControllerId, 0) != 0
				End
			END
		 ELSE
			IF(@TypeId = 3)
		 Begin 
			SELECT 0, 'ALL', NULL,0 
			UNION 
			Select Distinct Id,Description,NULL,0 from [TCD].Dryers D where D.DryerGroupId = @GroupTypeID AND Is_deleted = 0 And EcolabAccountNumber = @EcolabAccountNumber
		End
	    ELSE
		 IF(@TypeId = 4)
		Begin 
			SELECT 0, 'ALL', NULL,0
			UNION 
			Select Distinct FinnisherId,Name, NULL,0 from [TCD].Finnishers F where F.FinnisherGroupId = @GroupTypeID AND Is_deleted = 0 And EcolabAccountNumber = @EcolabAccountNumber
		End		  
		 ELSE
		 IF(@TypeId = 5)
		 BEGIN
			SELECT 0, 'ALL', NULL,0
			UNION
			SELECT DISTINCT WE.DeviceNumber, WE.DeviceName,NULL,0 FROM TCD.WaterAndEnergy WE WHERE WE.Is_deleted  = 0  And EcolabAccountNumber = @EcolabAccountNumber
		 END

SET nocount OFF;
 END
 
 GO
 
 IF EXISTS(SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[GetPlantSensorDetails]')
			AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
			TCD.[GetPlantSensorDetails]
	END
GO

/*
March. 2016		mrayalla@allianceglobalservices.com		Fixed Issue
*/
   
CREATE PROCEDURE [TCD].[GetPlantSensorDetails] 
(
@SensorID int = NULL,
@EcolabAccountNumber nvarchar(25)
)  
AS   
  BEGIN   
      SET nocount ON;   

	  Declare @ControllerID int = NULL
	  Select @ControllerID = ControllerID from [TCD].Sensor where SensorId =  @SensorID
	  DECLARE @WaterandEnergyGroupId  INT = (SELECT TOP (1) MG.Id
									   FROM TCD.MachineGroup MG
										    INNER JOIN
										    TCD.MachineGroupType MGT ON MGT.Id = MG.GroupTypeId
									   WHERE MGT.Id = 5	  );
	  
	  	  If exists(Select 1 from [TCD].[ConduitController])
	  Begin
   Select  
S.SensorId,
S.Description,
S.SensorType,
(Select Name from [TCD].SensorTypemaster rm where rm.Resourceid = S.SensorType) as SensorTypeName,
S.EcolabAccountNumber,
					CASE 
						WHEN S.Machinecompartment IS NULL
							THEN 
								CASE 
									WHEN S.IsPress = 1 
										THEN 1 
										ELSE 0 END
ELSE S.Machinecompartment
END AS Machinecompartment,
CASE
			WHEN S.MachineCompartment IS NULL AND (S.IsPress = 0 OR S.IsPress IS NULL) THEN 'ALL'
			WHEN (SELECT DISTINCT  Istunnel FROM [TCD].machinesetup M WHERE M.groupId = S.GroupId )= 1 THEN CASE WHEN S.MachineCompartment IS NULL AND S.IsPress = 1 THEN 'Press' ELSE 'Compartment' + CAST( S.Machinecompartment -1 AS varchar( 100)) END
      WHEN (SELECT DISTINCT Istunnel FROM [TCD].machinesetup M WHERE M.groupId = S.GroupId)= 0 THEN (SELECT CAST (WS.PlantWasherNumber AS nvarchar) + ':' + MachineName FROM [TCD].MachineSetup M INNER JOIN TCD.Washer WS ON M.WasherId = WS.WasherId WHERE M.GroupId = S.GroupId AND M.WasherId	 = S.MachineCompartment)
			WHEN (SELECT DISTINCT GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.Id = S.GroupId ) = 3 THEN (SELECT D.Description FROM [TCD].Dryers D WHERE D.DryerGroupId = S.GroupId AND D.Id = S.MachineCompartment)
			WHEN (SELECT DISTINCT GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.Id = S.GroupId ) = 4 THEN (SELECT F.Name FROM [TCD].Finnishers F WHERE F.FinnisherGroupId = S.GroupId AND F.FinnisherId = S.MachineCompartment)
			WHEN (SELECT DISTINCT GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.Id = S.GroupId ) = 5 THEN (SELECT DeviceName FROM TCD.WaterAndEnergy WE WHERE S.GroupId = @WaterandEnergyGroupId AND WE.DeviceNumber = S.MachineCompartment  AND WE.Is_deleted	= 0)
			WHEN (SELECT MM.MachineCompartment FROM [TCD].Meter MM WHERE MM.GroupId = S.GroupId) = 0 THEN 'Press'
      END AS MachinecompartmentName ,
			CC.ControllerID,	
			CC.Name AS ControllerName,
			CC.ControllerModelId,
			CM.RegionId AS ControllerRegionId,	
			CT.Id AS ControllerTypeId,
			CT.Name AS ControllerType,
			S.OutputType,
			S.ChemicalforChart,
			(Select DISTINCT p.Name from [TCD].productmaster P where P.productId = S.ChemicalforChart) as ChemicalforChartName,
			s.UOM,
			'S.UOMName' as UOMName,
			S.DashboardActualValue,
			( CASE WHEN S.groupID IS NULL AND S.IsPlant = 1
			   THEN 1
			   ELSE
                   (SELECT G.Id
                     FROM [TCD].MachineGroup G
                     WHERE G.Id
                           = 
                           S.groupID AND G.EcolabAccountNumber = @EcolabAccountNumber)
			   END )AS GroupId , 
			(	CASE WHEN (S.groupID IS NULL AND S.MachineCompartment IS NULL AND S.IsPlant = 1) THEN 'Plant'
				ELSE
                     (SELECT GroupDescription
                       FROM [TCD].MachineGroup G
                       WHERE G.Id
                             = 
                             S.groupID AND G.EcolabAccountNumber = @EcolabAccountNumber) END
                   )AS SensorLocation,
			(SELECT MTS.TagAddress FROM TCD.ModuleTags MTS WHERE MTS.TagType = 'Tag_MPLC' AND MTS.ModuleID = SensorId AND MTS.ModuleTypeId = 3 AND MTS.Active = 1) AS AnalogueInputNumber,
			S.Calibration4mA,
			S.Calibration20mA,
			(SELECT MTS.TagAddress FROM TCD.ModuleTags MTS WHERE MTS.TagType = 'Tag_SC4' AND MTS.ModuleID = SensorId AND MTS.ModuleTypeId = 3 AND MTS.Active = 1) AS CalibrationTag4,
					(SELECT MTS.TagAddress FROM TCD.ModuleTags MTS WHERE MTS.TagType = 'Tag_SC20' AND MTS.ModuleID = SensorId AND MTS.ModuleTypeId = 3 AND MTS.Active = 1) AS CalibrationTag20,
					S.LastSyncTime,
					S.LastModifiedTime
			  from [TCD].Sensor S 
				LEFT JOIN [TCD].ConduitController CC
				ON CC.ControllerId = S.ControllerID
				LEFT JOIN [TCD].ControllerModel CM 
				ON CM.Id = CC.ControllerModelId
				LEFT JOIN [TCD].ControllerType CT
				ON CT.Id = CC.ControllerTypeId
			Where Is_Deleted = 0  
End

Else
   Select  
S.SensorId,
S.Description,
S.SensorType,
(Select Name from [TCD].SensorTypemaster rm where rm.Resourceid = S.SensorType) as SensorTypeName,
S.EcolabAccountNumber,
				CASE 
					WHEN S.Machinecompartment IS NULL
						THEN 
							CASE 
								WHEN S.IsPress = 1 
									THEN 1 
									ELSE 0 
								END
ELSE S.Machinecompartment
END AS Machinecompartment,
CASE
			WHEN S.MachineCompartment IS NULL AND (S.IsPress = 0 OR S.IsPress IS NULL) THEN 'ALL'
			WHEN (SELECT DISTINCT  Istunnel FROM [TCD].machinesetup M WHERE M.groupId = S.GroupId )= 1 THEN CASE WHEN S.MachineCompartment IS NULL AND S.IsPress = 1 THEN 'Press' ELSE 'Compartment' + CAST( S.Machinecompartment -1 AS varchar( 100)) END
      WHEN (SELECT DISTINCT Istunnel FROM [TCD].machinesetup M WHERE M.groupId = S.GroupId)= 0 THEN (SELECT MachineName FROM [TCD].MachineSetup M WHERE M.GroupId = S.GroupId AND M.WasherId = S.MachineCompartment)
			WHEN (SELECT DISTINCT GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.Id = S.GroupId ) = 3 THEN (SELECT Description FROM [TCD].Dryers WHERE DryerGroupId = S.GroupId AND DryerNo = S.MachineCompartment)
			WHEN (SELECT MM.MachineCompartment FROM [TCD].Meter MM WHERE MM.GroupId = S.GroupId) = 0 THEN 'Press'
      END AS MachinecompartmentName ,
			CC.ControllerID,	
			CC.Name AS ControllerName,
			CC.ControllerModelId,
			CM.RegionId AS ControllerRegionId,	
			CT.Id AS ControllerTypeId,
			CT.Name AS ControllerType,
			S.OutputType,
			S.ChemicalforChart,
			(Select DISTINCT p.Name from [TCD].productmaster P where P.productId = S.ChemicalforChart) as ChemicalforChartName,
			s.UOM,
			'S.UOMName' as UOMName,
			S.DashboardActualValue,
			S.GroupId,
			(select DISTINCT GroupDescription from [TCD].MachineGroup G where G.Id = s.GroupId) as SensorLocation,
			(SELECT MTS.TagAddress FROM TCD.ModuleTags MTS WHERE MTS.TagType = 'Tag_MPLC' AND ModuleID = SensorId) AS AnalogueInputNumber,
			S.Calibration4mA,
			S.Calibration20mA,
			(SELECT MTS.TagAddress FROM TCD.ModuleTags MTS WHERE MTS.TagType = 'Tag_SC4' AND ModuleID = SensorId) AS CalibrationTag4,
				(SELECT MTS.TagAddress FROM TCD.ModuleTags MTS WHERE MTS.TagType = 'Tag_SC20' AND ModuleID = SensorId) AS CalibrationTag20,
				S.LastSyncTime,
				S.LastModifiedTime
			  from [TCD].Sensor S 
				LEFT JOIN [TCD].ConduitController CC
				ON CC.ControllerId = S.ControllerID
				LEFT JOIN [TCD].ControllerModel CM 
				ON CM.Id = CC.ControllerModelId
				LEFT JOIN [TCD].ControllerType CT
				ON CT.Id = CC.ControllerTypeId
				Where 1=2
SET NOCOUNT OFF;
END
GO

IF EXISTS(SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].SavePlantSensorDetails')
			AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
			TCD.SavePlantSensorDetails
	END
GO

/*
March. 2016		mrayalla@allianceglobalservices.com		Fixed Issue
*/
   
CREATE PROCEDURE TCD.SavePlantSensorDetails(
      @SensorNumber NVARCHAR( 100) = NULL,
      @EcolabAccountNumber NVARCHAR( 25) = NULL,
      @ControllerID VARCHAR( 1000) = NULL,
      @SensorName NVARCHAR( 100) = NULL,
      @SensorType NVARCHAR( 100) = NULL,
      @SensorLocation NVARCHAR( 100) = NULL,
      @MachineCompartment NVARCHAR( 100) = NULL,
      @OutputType NVARCHAR( 100) = NULL,
      @ChemicalforChart NVARCHAR( 100)= NULL,
      @UOM NVARCHAR( 100) = NULL,
      @DashboardActualValue VARCHAR( 100) = NULL,
      @UserID INT,
      @AnalogueInputNumber NVARCHAR( 100) = NULL,
      @Calibration4mA DECIMAL( 18, 2) = NULL,
      @Calibration20mA DECIMAL( 18, 2) = NULL,
      @TagAddress4mA NVARCHAR( 100) = NULL,
      @TagAddress20mA NVARCHAR( 100) = NULL,
      @Scope VARCHAR( 100)OUTPUT,
      @OutputSensorId INT = NULL OUTPUT,
      @LastModifiedTimestampAtCentral DATETIME = NULL,
      @OutputLastModifiedTimestampAtLocal DATETIME = NULL OUTPUT)
AS
     BEGIN
         SET NOCOUNT ON;
         DECLARE @IsPlant BIT = NULL,
         @IsPress BIT = NULL,
         @IStunnel INT = '';
         DECLARE @TypeLimit INT = NULL,
         @TempLimit INT = NULL,
         @pHLimit INT = NULL,
         @ConductivityLimit INT = NULL,
         @WeightLimit INT = NULL,
         @ControllerModelID INT = NULL;
         DECLARE @ReturnValue INT = 0,
         @ErrorId INT = 0,
         @ErrorMessage NVARCHAR( 4000) = N'',
         @CurrentUTCTime DATETIME = GETUTCDATE();
         DECLARE @OutputList AS TABLE( SensorId INT,LastModifiedTimestamp DATETIME);
         SET @OutputLastModifiedTimestampAtLocal = ISNULL( @OutputLastModifiedTimestampAtLocal, NULL);

         --SQLEnlight

         SET @OutputSensorId = ISNULL( @OutputSensorId, NULL);

         /*Maximum one Sensor with the same type can be connected to one machine/Compartement */

         IF @LastModifiedTimestampAtCentral IS NOT NULL
            AND
            NOT EXISTS( SELECT 1
                        FROM TCD.Sensor AS S
                        WHERE S.EcolabAccountNumber = @EcolabAccountNumber
                              AND
                              S.SensorId = @SensorNumber
                              AND
                              S.LastModifiedTime = @LastModifiedTimestampAtCentral
                      )
             BEGIN
                 SET @ErrorId = 60000;
                 SET @ErrorMessage = N'' + CAST( @ErrorId AS NVARCHAR);
                 RAISERROR( @ErrorMessage, 16, 1);
                 SET @ReturnValue = -1;
                 RETURN @ReturnValue;
             END;
         SET @Scope = '';
         SELECT @TypeLimit = COUNT( 1)
         FROM TCD.Sensor AS S
         WHERE GroupId = @SensorLocation
               AND
               S.SensorType = @SensorType
               AND
               ISNULL( MachineCompartment, 0) = @MachineCompartment
               AND
               Is_deleted = 0
               AND
               ControllerID IN(
               SELECT ControllerId
               FROM TCD.ConduitController
               WHERE ControllerId = @ControllerID
                     AND
                     EcoalabAccountNumber = @EcolabAccountNumber
                              )
               AND
               EcolabAccountNumber = @EcolabAccountNumber;

         /*Maximum 6 Temperature sensor can be connected to the same Washter-Tunnel */

         SELECT @TempLimit = COUNT( 1)
         FROM TCD.Sensor AS S LEFT OUTER JOIN TCD.machinesetup AS MS ON S.GroupId = MS.groupId
                                                                        AND
                                                                        S.EcolabAccountNumber = MS.EcoalabAccountNumber
         WHERE S.SensorType = 1
               AND
               S.GroupID = @SensorLocation
               AND
               Ms.Istunnel = 1
               AND
    IS_deleted = 0
               AND
               S.ControllerID IN(
               SELECT ControllerId
               FROM TCD.ConduitController
               WHERE ControllerModelId = 7
                     AND
                     EcoalabAccountNumber = @EcolabAccountNumber
                                )
               AND
               S.EcolabAccountNumber = @EcolabAccountNumber;

         /* Maximum 2 pH sensor can be connected to the same Washter-Tunnel */

         SELECT @pHLimit = COUNT( 1
                                )
         FROM TCD.Sensor AS S LEFT OUTER JOIN TCD.machinesetup AS MS ON S.GroupId = MS.groupId
                                                                        AND
                                                                        S.EcolabAccountNumber = MS.EcoalabAccountNumber
         WHERE S.SensorType = 2
               AND
               S.GroupID = @SensorLocation
               AND
               Ms.Istunnel = 1
               AND
               IS_deleted = 0
               AND
               S.ControllerID IN(
               SELECT ControllerId
               FROM TCD.ConduitController
               WHERE ControllerModelId = 7
                     AND
                     EcoalabAccountNumber = @EcolabAccountNumber
                                )
               AND
               S.EcolabAccountNumber = @EcolabAccountNumber;

         /* Maximum 1 Conductivity sensor can be connected to the same Washter-Tunnel */

         SELECT @ConductivityLimit = COUNT( 1)
         FROM TCD.Sensor AS S LEFT OUTER JOIN TCD.machinesetup AS MS ON S.GroupId = MS.groupId
                                                                        AND
                                                                        S.EcolabAccountNumber = MS.EcoalabAccountNumber
         WHERE S.SensorType = 4
               AND
               S.GroupID = @SensorLocation
               AND
               Ms.Istunnel = 1
               AND
               IS_deleted = 0
               AND
               S.ControllerID IN(
               SELECT ControllerId
               FROM TCD.ConduitController
               WHERE ControllerModelId = 7
                     AND
                     EcoalabAccountNumber = @EcolabAccountNumber
                                )
               AND
               S.EcolabAccountNumber = @EcolabAccountNumber;

         /* Maximum 1 Weight sensor can be connected to the same Washter-Tunnel */

         SELECT @WeightLimit = COUNT( 1)
         FROM TCD.Sensor AS S LEFT OUTER JOIN TCD.machinesetup AS MS ON S.GroupId = MS.groupId
                                                                        AND
                                                                        S.EcolabAccountNumber = MS.EcoalabAccountNumber
         WHERE S.SensorType = 5
               AND
               S.GroupID = @SensorLocation
               AND
               Ms.Istunnel = 1
               AND
               IS_deleted = 0
               AND
               S.ControllerID IN(
               SELECT ControllerId
               FROM TCD.ConduitController
               WHERE ControllerModelId = 7
                     AND
                     EcoalabAccountNumber = @EcolabAccountNumber
                                )
               AND
               S.EcolabAccountNumber = @EcolabAccountNumber;
         SELECT @ControllerModelID = ControllerModelId
         FROM TCD.ConduitController
         WHERE ControllerId = @ControllerID
               AND
               EcoalabAccountNumber = @EcolabAccountNumber;
         SELECT @IStunnel = Istunnel
         FROM TCD.machinesetup AS MS
         WHERE Ms.GroupId = @SensorLocation
               AND
               MS.EcoalabAccountNumber = @EcolabAccountNumber;
         IF @IStunnel = 1
             BEGIN				
                 IF @MachineCompartment = 1
                     BEGIN
                         SET @IsPress = 1;
                     END;
				IF @MachineCompartment = 0
                 BEGIN
					SET @MachineCompartment = NULL;
				 END
             END;
         IF @SensorLocation = 1
             BEGIN
                 SET @IsPlant = 1;
                 SET @SensorLocation = NULL;
                 SET @MachineCompartment = NULL;
             END;
         IF @ControllerID = -1
             BEGIN
                 SELECT TOP ( 1
                            )@ControllerID = ControllerID
                 FROM TCD.ConduitController
                 WHERE ControllerModelId = @ControllerModelID
                       AND
                       EcoalabAccountNumber = @EcolabAccountNumber;
             END;
         ELSE
             BEGIN
                 SELECT @ControllerModelID = ControllerModelId
                 FROM TCD.ConduitController
                 WHERE ControllerId = @ControllerID
                       AND
                       EcoalabAccountNumber = @EcolabAccountNumber;
             END;
         IF @ControllerID != -1
             BEGIN

                 /* Inserting the values in to Sensor table if it is new Sensor */

                 DECLARE @NewSensorId INT,
                 @ModuleType INT = 3,
                 @DefaultFrequency INT = 60,
                 @TagType VARCHAR( 100) = 'Tag_MPLC',
                 @TagTypeSC4 VARCHAR( 100) = 'Tag_SC4',
                 @TagTypeSC20 VARCHAR( 100) = 'Tag_SC20',
                 @Result1 INT = NULL,
                 @Result2 INT = NULL,
                 @Result3 INT = NULL,
                 @Type INT = 3,
                 @AllowTagEdit BIT;
                 SELECT @AllowTagEdit = CASE
                                            WHEN COUNT( *) > 0
                                            THEN 'TRUE'
                                            ELSE 'FALSE'
                                        END
                 FROM TCD.UserMaster AS UM INNER JOIN TCD.UserInRole AS UIR
                 ON UM.UserId = UIR.UserId
                                           INNER JOIN TCD.UserRoles AS UR
                 ON UIR.RoleId = UR.RoleId
                 WHERE UM.UserId = @UserID
                       AND
                       UR.LevelId >= 8
                       AND
                       UM.EcolabAccountNumber = @EcolabAccountNumber;
                 IF NOT EXISTS( SELECT *
                                FROM TCD.Sensor
                                WHERE SensorID = @SensorNumber
                                      AND
                                      EcolabAccountNumber = @EcolabAccountNumber
                              )

                     -- Begin Create Sensor

                     BEGIN
                         BEGIN
                             DECLARE @AllowInsert BIT = 'FALSE';
                             IF @TypeLimit < 1
                                 BEGIN
                                     IF @ControllerModelID = 7
                                         BEGIN
                                             IF @SensorType = 1
                                                 BEGIN
                                                     IF @TempLimit < 6
                                                         BEGIN
                                                             SET @AllowInsert = 'TRUE';
                                                         END;
                                                     ELSE
                                                         BEGIN
                                                             SET @SCOPE = @SCOPE + '401,';
                                                         END;
                                                 END;
                                             ELSE
                                 BEGIN
                                                     IF @SensorType = 2
                                                         BEGIN
                                                             IF @pHLimit < 2
                                                                 BEGIN
                                                                     SET @AllowInsert = 'TRUE';
                                                                 END;
                                                             ELSE
                                                                 BEGIN
                                                                     SET @SCOPE = @SCOPE + '301,';
                                                                 END;
                                                         END;
                                                     ELSE
                                                         BEGIN
                                                             IF @SensorType = 4
                                                                 BEGIN
                                                                     IF @ConductivityLimit < 1
                                                                         BEGIN
                                                                             SET @AllowInsert = 'TRUE';
                                                                         END;
																	ELSE
                                                                     BEGIN
                                                                         SET @SCOPE = @SCOPE + '201,';
                                                                     END;
                                                                 END;
                                                             ELSE
                                                                 BEGIN
                                                                     IF @SensorType = 5
                                                                         BEGIN
                                                                             IF @WeightLimit < 1
                                                                                 BEGIN
                                                                                     SET @AllowInsert = 'TRUE';
                                                                                 END;
                                                                             ELSE
                                                                                 BEGIN
                                                                                     SET @SCOPE = @SCOPE + '101,';
                                                                                 END;
                                                                         END;
                                                                 END;
                                                         END;
                                                 END;
                                         END;
                                     ELSE
                                         BEGIN
                                             SET @AllowInsert = 'TRUE';
                                         END;
                                 END;
                             ELSE
                                 BEGIN
                                     SET @Scope = @Scope + '501,';
                                 END;

                             -- End Business Validations
                             -- Begin Insert if Validation Succeeds

                             IF @AllowInsert = 'TRUE'
                                 BEGIN
                                     DECLARE @SensorCount INT;
                                     SELECT @SensorCount = MAX( s.SensorId)+1
                                     FROM TCD.Sensor AS s WITH ( NOLOCK);
                                 
                                     INSERT INTO TCD.Sensor( Description,
                                     SensorType,
                                     GroupId,
                                     MachineCompartment,
                                     EcolabAccountNumber,
                                     ControllerID,
                                     OutputType,
                                     ChemicalforChart,
                                     UOM,
                                     DashboardActualValue,
                                     LastModifiedByUserId,
                                     IsPlant,
                                     IsPress,
                                     Calibration4mA,
                                     Calibration20mA,
                                     Id
                                                           )
                                     OUTPUT inserted.SensorId AS SensorId,
                                     inserted.LastModifiedTime AS LastModifiedTimestamp
                                            INTO @OutputList( SensorId,
                                            LastModifiedTimestamp
                                                            )
                                     SELECT @SensorName,
                                     @SensorType,
                                     @SensorLocation,
                                     @MachineCompartment,
                                     @EcolabAccountNumber,
                                     @ControllerID,
                                     @OutputType,
                                     @ChemicalforChart,
                                     @UOM,
                                     @DashboardActualValue,
                                     @UserID,
                                     @IsPlant,
                                     @IsPress,
                                     @Calibration4mA,
                                     @Calibration20mA,
                                     @SensorCount;
                                     SET @NewSensorId = SCOPE_IDENTITY(
                                                                      );
                                 END;
                         END;
                     END;
                 ELSE

                     ------------------------------------------------------------------------------------------------------------------
                     -- Begin Update Sensor

                     BEGIN
                         DECLARE @PlantId INT = ( SELECT MG.Id
                                                  FROM TCD.MachineGroupType AS MGT INNER JOIN TCD.MachineGroup AS MG
                                                  ON MGT.Id = MG.GroupTypeId
                                                  WHERE MGT.Id = 1
                                                        AND
                                                        MG.Is_Deleted = 0
                                                );

                         -- Check RedFlag Association and Update Sensor

                         IF(( SELECT COALESCE( S.GroupId, ''
                                             )
                              FROM TCD.Sensor AS S
                              WHERE S.SensorId = @SensorNumber
                            ) != COALESCE( @SensorLocation, ''
                                         )
                            OR
                            ( SELECT COALESCE( S.MachineCompartment, ''
                                             )
                              FROM TCD.Sensor AS S
                              WHERE S.SensorId = @SensorNumber
                            ) != COALESCE( @MachineCompartment, ''
                                         ))
                           AND
                           EXISTS( SELECT 1
                                   FROM TCD.RedFlag AS RF INNER JOIN TCD.RedFlagMappingData AS RFM
                                   ON RF.Id = RFM.MappingId
                                      AND
                                      RF.Is_Deleted = 0
                                      AND
                                      RFM.Is_Deleted = 0
                                                          LEFT JOIN TCD.Sensor AS S
                                   ON RF.Location = CASE S.IsPlant
                                                        WHEN 'TRUE'
                                                        THEN COALESCE( S.GroupId, @PlantId
                                                                     )
                                                        ELSE S.GroupId
                                                    END
                                      AND
                                      COALESCE( S.MachineCompartment, 0
                                              ) = COALESCE( RFM.MachineId, 0
                                                          )
                                      AND
                                      S.Is_deleted = 0
                                   WHERE S.SensorId = @SensorNumber
                                 )
                             BEGIN
                                 SET @Scope = '405,';
                             END;
                         ELSE
                             BEGIN
                                 IF(@Result1 IS NULL
                                    OR
                                    @Result1 <> 0)
                                   AND
                                   (@Result2 IS NULL
                                    OR
                                    @Result2 <> 0)
                                   AND
                                   (@Result3 IS NULL
                                    OR
                                    @Result3 <> 0)
                                     BEGIN
                                         DECLARE @AllowUpdate BIT = 'FALSE';

                                         --Begin Get old Sensor Values

                                         BEGIN
                                             DECLARE @uty INT = ( SELECT sensortype
                                                                  FROM TCD.Sensor
                                                                  WHERE SensorID = @SensorNumber
                                                                        AND
                                                                        EcolabAccountNumber = @EcolabAccountNumber
                                                                );
                                             DECLARE @grpId INT = ( SELECT GroupId
                                                                    FROM TCD.Sensor
                                                                    WHERE SensorID = @SensorNumber
                                                                          AND
                                                                          EcolabAccountNumber = @EcolabAccountNumber
                                                                  );
                                             DECLARE @machId INT = ( SELECT MachineCompartment
                                                                     FROM TCD.Sensor
                                                                     WHERE SensorID = @SensorNumber
                                                                           AND
                                                                           EcolabAccountNumber = @EcolabAccountNumber
                                   );
                                         END;

                                         --Begin Get old Sensor Values

                                         IF @uty <> @SensorType
                                            OR
                                            @grpId <> @SensorLocation
                                            OR
                                            @machId <> @MachineCompartment
                                             BEGIN
                                                 IF @TypeLimit < 1
                                                     BEGIN
                                                         IF @ControllerModelID = 7
                                                             BEGIN
                                                                 IF @SensorType = 1
                                                                     BEGIN
                                                                         IF @TempLimit < 6
                                                                             BEGIN
                                                                                 SET @AllowUpdate = 'TRUE';
                                                                             END;
                                                                         ELSE
                                                                             BEGIN
                                                                                 SET @SCOPE = @SCOPE + '401,';
                                                                             END;
                                                                     END;
                                                                 ELSE
                                                                     BEGIN
                                                                         IF @SensorType = 2
                                                                             BEGIN
                                                                                 IF @pHLimit < 2
                                                                                     BEGIN
                                                                                         SET @AllowUpdate = 'TRUE';
                                                                                     END;
                                                                                 ELSE
                                                                                     BEGIN
                                                                                         SET @SCOPE = @SCOPE + '301,';
                                                                                     END;
                                                                             END;
                                                                         ELSE
                                                                             BEGIN
                                                                                 IF @SensorType = 4
                                                                                     BEGIN
                                                                                         IF @ConductivityLimit < 1
                                                                                             BEGIN
                                                                                                 SET @AllowUpdate = 'TRUE';
                                                                                             END;
                                                                                         ELSE
                                                                                             BEGIN
                                               SET @SCOPE = @SCOPE + '201,';
                                                                                             END;
                                                                                     END;
                                                                                 ELSE
                                                                                     BEGIN
                                                                                         IF @SensorType = 5
                                                                                             BEGIN
                                                                                                 IF @WeightLimit < 1
                                                                                                     BEGIN
                                                                                                         SET @AllowUpdate = 'TRUE';
                                                                                                     END;
                                                                                                 ELSE
                                                                                                     BEGIN
                                                                                                         SET @SCOPE = @SCOPE + '101,';
                                                                                                     END;
                                                                                             END;
                                                                                     END;
                                                                             END;
                                                                     END;
                                                             END;
                                                         ELSE
                                                             BEGIN
                                                                 BEGIN
                                                                     SET @AllowUpdate = 'TRUE';
                                                                 END;
                                                             END;
                                                     END;
                                                 ELSE
                                                     BEGIN
                                                         SET @SCOPE = @SCOPE + '501,';
                                                     END;
                                             END;
                                         ELSE
                                             BEGIN
                                                 SET @AllowUpdate = 'TRUE';
                                             END;
                                         IF @AllowUpdate = 'TRUE'
                                             BEGIN
                                                 IF @LastModifiedTimestampAtCentral IS NOT NULL
                                                    AND
                                                    NOT EXISTS( SELECT 1
                                                                FROM TCD.Sensor AS S
                                                                WHERE S.EcolabAccountNumber = @EcolabAccountNumber
                                                                      AND
                                                                      S.SensorId = @SensorNumber
                                                                      AND
                                                                      S.LastModifiedTime = @LastModifiedTimestampAtCentral
           )
                                                     BEGIN
                                                         SET @ErrorId = 60000;
                                                         SET @ErrorMessage = N'' + CAST( @ErrorId AS NVARCHAR
                                                                                       ) + N': Record not in-synch between plant and central.';
                                                         RAISERROR( @ErrorMessage, 16, 1
                                                                  );
                                                         SET @ReturnValue = -1;
                                                         RETURN @ReturnValue;
                                                     END;
                                                 UPDATE s
                                                        SET Description = @SensorName,
                                                 SensorType = @SensorType,
                                                 GroupId = @SensorLocation,
                                                 MachineCompartment = @MachineCompartment,
                                                 S.ControllerID = @ControllerID,
                                                 OutputType = @OutputType,
                                                 ChemicalforChart = @ChemicalforChart,
                                                 UOM = @UOM,
                                                 DashboardActualValue = @DashboardActualValue,
                                                 LastModifiedByUserId = @UserID,
                                                 Calibration4mA = @Calibration4mA,
                                                 Calibration20mA = @Calibration20mA,
                                                 LastModifiedTime = @CurrentUTCTime
                                                 OUTPUT inserted.SensorId AS SensorId,
                                                 inserted.LastModifiedTime AS LastModifiedTimestamp
                                                        INTO @OutputList( SensorId,
                                                        LastModifiedTimestamp
                                                                        )
                                                 FROM TCD.Sensor S
                                                 WHERE SensorID = @SensorNumber
                                                       AND
                                                       EcolabAccountNumber = @EcolabAccountNumber;
                                             END;
                                     END;
                             END;
                     END;

             -- End Update Sensor

             END;
         ELSE
             BEGIN
                 SELECT @Scope = '701,';
             END;
         SET NOCOUNT OFF;
         SELECT TOP 1 @OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp,
         @OutputSensorId = O.SensorId
         FROM @OutputList AS O;
         RETURN @ReturnValue;
     END;

GO

IF NOT EXISTS (SELECT 1 FROM TCD.WasherFlushType WHERE WasherFlushType = N'Water')
BEGIN
INSERT INTO TCD.WasherFlushType
(
    TCD.WasherFlushType.WasherFlushTypeId,
    TCD.WasherFlushType.WasherFlushType
)
VALUES
(
    1, -- WasherFlushTypeId - int
    N'Water' -- WasherFlushType - nvarchar
)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.WasherFlushType WHERE WasherFlushType = N'Air')
BEGIN
INSERT INTO TCD.WasherFlushType
(
    TCD.WasherFlushType.WasherFlushTypeId,
    TCD.WasherFlushType.WasherFlushType
)
VALUES
(
    2, -- WasherFlushTypeId - int
    N'Air' -- WasherFlushType - nvarchar
)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.WasherFlushType WHERE WasherFlushType = N'Water(Valve)')
BEGIN
INSERT INTO TCD.WasherFlushType
(
    TCD.WasherFlushType.WasherFlushTypeId,
    TCD.WasherFlushType.WasherFlushType
)
VALUES
(
    3, -- WasherFlushTypeId - int
    N'Water(Valve)' -- WasherFlushType - nvarchar
)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.WasherFlushType WHERE WasherFlushType = N'Water(ME)')
BEGIN
INSERT INTO TCD.WasherFlushType
(
    TCD.WasherFlushType.WasherFlushTypeId,
    TCD.WasherFlushType.WasherFlushType
)
VALUES
(
    4, -- WasherFlushTypeId - int
    N'Water(ME)' -- WasherFlushType - nvarchar
)
END
GO
----------------------------------

IF EXISTS (SELECT * FROM sys.columns c WHERE c.name = 'DesiredTemperature' AND C.object_id = OBJECT_ID('[TCD].[TunnelTempSetup]'))
BEGIN
	ALTER TABLE [TCD].[TunnelTempSetup] ALTER COLUMN DesiredTemperature FLOAT NULL
END
GO
---------------------------
 IF EXISTS(SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].SaveTunnelAnalogueControl')
			AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
			TCD.SaveTunnelAnalogueControl
	END
GO
/*
Purpose					:	To Save Tunnel Analogue Control while saving tunnel Wash Step

--sp_helptext	'[TCD].[SaveTunnelAnalogueControl]'

*/

CREATE PROCEDURE	[TCD].[SaveTunnelAnalogueControl]
	@EcolabAccountNumber NVARCHAR(25),
	@TunnelProgramSetupId INT,	
	@TempSetPoint FLOAT,
	@MinTime INT,
	@StartDelay INT,
	@AcceptDelay INT,
	@CompartmentNumber INT,
	@ProductCheck BIT= NULL,
	@PhRegLevel INT = NULL,
	@MonLevel INT = NULL,
	@ConRegLevel INT = NULL
AS
BEGIN

	DECLARE @PlantId INT = ( SELECT p.PlantId FROM TCD.PLANT p WHERE p.EcolabAccountNumber = @EcolabAccountNumber);

	IF EXISTS (SELECT 1 FROM TCD.TunnelDosingSetup tds 
		WHERE tds.TunnelProgramSetupId = @TunnelProgramSetupId AND tds.CompartmentNumber = @CompartmentNumber AND EcolabAccountNumber = @EcolabAccountNumber)
		BEGIN
			UPDATE TCD.TunnelDosingSetup
			SET		    
			    TCD.TunnelDosingSetup.PhRegLevel = @PhRegLevel,
			    TCD.TunnelDosingSetup.MonLevel = @MonLevel, 
			    TCD.TunnelDosingSetup.ConRegLevel = @ConRegLevel				
			WHERE TunnelProgramSetupId = @TunnelProgramSetupId AND EcolabAccountNumber = @EcolabAccountNumber 
			AND CompartmentNumber = @CompartmentNumber
		END

	IF EXISTS (SELECT * FROM TCD.TunnelTempSetup tts WHERE tts.TunnelProgramSetupId = @TunnelProgramSetupId AND tts.PlantId = @PlantId AND CompartmentNumber = @CompartmentNumber)
	BEGIN
		UPDATE TCD.TunnelTempSetup
			SET		    
				TCD.TunnelTempSetup.DesiredTemperature = @TempSetPoint,
				TCD.TunnelTempSetup.MinTime = @MinTime, 
				TCD.TunnelTempSetup.StartDelay = @StartDelay,
				TCD.TunnelTempSetup.AcceptDelay = @AcceptDelay,					
				TCD.TunnelTempSetup.ProductCheck = @ProductCheck
			WHERE TunnelProgramSetupId = @TunnelProgramSetupId AND PlantId = @PlantId AND CompartmentNumber = @CompartmentNumber		
	END
	ELSE 
		BEGIN		
			INSERT INTO TCD.TunnelTempSetup
			(
				TunnelProgramSetupId,					    
				DesiredTemperature,
				MinTime,
				StartDelay,
				AcceptDelay,
				CompartmentNumber,
				ProductCheck ,
				PlantId
			)
			VALUES
			(
				@TunnelProgramSetupId, 				
				@TempSetPoint, 
				@MinTime, 
				@StartDelay, 
				@AcceptDelay, 
				@CompartmentNumber,
				@ProductCheck,
				@PlantId	    
			)
		END

END
GO
-------------------------------------------------
 IF EXISTS(SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].GetTunnelWashStepProducts')
			AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
			TCD.GetTunnelWashStepProducts
	END
GO

/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_GetTunnelWashStepProducts]                                             

Purpose:				To get the tunnel wash step products.

Parameters:				@EcoLabAccountNumber - holds ecolab account number.
						@CompartmentNumber - holds the compartment number.
						@GroupId - holds the group id.
																
###################################################################################################                                           
*/

CREATE	PROCEDURE	[TCD].[GetTunnelWashStepProducts]

					@EcoLabAccountNumber					NVARCHAR(1000)

				,	@CompartmentNumber							INT

				,	@GroupId									INT

				,	@DosingSetupId								INT

AS

BEGIN

SET	NOCOUNT	ON
DECLARE @TunnelProgramSetupId INT
,		@LastModifiedTime DATETIME  = NULL
,		@MyServiceFrmulaStpDsgDvcGuid UNIQUEIDENTIFIER = NULL

SELECT @TunnelProgramSetupId = tds.TunnelProgramSetupId FROM TCD.TunnelDosingSetup tds WHERE tds.TunnelDosingSetupId = @DosingSetupId AND tds.EcolabAccountNumber = @EcoLabAccountNumber

IF NOT EXISTS (SELECT 1 FROM TCD.TunnelDosingProductMapping tdpm WHERE tdpm.TunnelDosingSetupId = @DosingSetupId AND tdpm.EcoLabAccountNumber = @EcoLabAccountNumber)
 BEGIN
  SELECT 
		0											AS		TunnelDosingProductMappingId,
		TC.EcoLabAccountNumber						AS		EcoalabAccountNumber, 
		CES.ControllerEquipmentSetupId				AS		ControllerEquipmentSetupId, 
		PM.ProductId								AS		ProductId, 
		ISNULL(NULLIF(PM.EnvisionDisplayName, ' '),PM.Name) 	AS ProductName,
		0.0											AS		Quantity,
		0											AS		DelayTime,  
		CAST(TC.[CompartmentNumber] AS INT) 		AS		CompartmentNumber, 
		MS.GroupId									AS		GroupId,
		@LastModifiedTime							AS		LastModifiedTime,
		@MyServiceFrmulaStpDsgDvcGuid				AS		MyServiceFrmulaStpDsgDvcGuid,
		TCD.FnChemicalCostInOunce(PM.ProductId)		AS		Price,
		GETUTCDATE()								AS		MyServiceLastSynchTime,
		CAST(CES.ControllerEquipmentTypeId	AS INT)				AS		ControllerEquipmentSetupTypeId
FROM	TCD.TunnelCompartment TC 
JOIN	TCD.MachineSetup MS ON TC.WasherId = MS.WasherId AND TC.EcoLabAccountNumber = MS.EcoalabAccountNumber AND ms.IsDeleted = 'False'	
JOIN	TCD.TunnelCompartmentEquipmentMapping TCE ON TCE.TunnelCompartmentId = TC.TunnelCompartmentId AND TCE.EcoLabAccountNumber = TC.EcoLabAccountNumber AND TCE.Is_Deleted = 'False'
JOIN	TCD.ControllerEquipmentSetup CES on CES.ControllerEquipmentSetupId = TCE.ControllerEquipmentSetupId AND CES.EcoLabAccountNumber = TCE.EcoLabAccountNumber
JOIN	TCD.ProductMaster PM on PM.ProductId = CES.ProductId 
JOIN	TCD.TunnelProgramSetup TPS on TPS.WasherGroupId = MS.GroupId AND TPS.EcolabAccountNumber = MS.EcoalabAccountNumber
	WHERE TC.CompartmentNumber = @CompartmentNumber AND MS.GroupId = @GroupId 
	AND MS.EcoalabAccountNumber = @EcoLabAccountNumber 
	AND TPS.TunnelProgramSetupId = @TunnelProgramSetupId
END
ELSE
BEGIN
SELECT 
		ISNULL(TDPM.TunnelDosingProductMappingId,0)			AS		TunnelDosingProductMappingId,
		TC.EcoLabAccountNumber						AS		EcoalabAccountNumber, 
		CES.ControllerEquipmentSetupId				AS		ControllerEquipmentSetupId, 
		PM.ProductId								AS		ProductId, 
		ISNULL(NULLIF(PM.EnvisionDisplayName, ' '),PM.Name) 	AS ProductName,
		ISNULL(TDPM.Quantity,0.0) AS Quantity,
		ISNULL(TDPM.DelayTime,0) AS DelayTime,   
		CAST(TC.[CompartmentNumber] AS INT)			AS		CompartmentNumber, 
		MS.GroupId									AS		GroupId,
		TDPM.LastModifiedTime						AS		LastModifiedTime,
		TDPM.MyServiceFrmulaStpDsgDvcGuid			AS		MyServiceFrmulaStpDsgDvcGuid,
		TCD.FnChemicalCostInOunce(PM.ProductId)		AS		Price,
		TDPM.MyServiceLastSynchTime					AS		MyServiceLastSynchTime,
		CAST(CES.ControllerEquipmentTypeId	AS INT)					AS		ControllerEquipmentSetupTypeId
FROM	TCD.TunnelCompartment TC 
JOIN	TCD.MachineSetup MS ON TC.WasherId = MS.WasherId AND TC.EcoLabAccountNumber = MS.EcoalabAccountNumber AND ms.IsDeleted = 'False'	
JOIN	TCD.TunnelCompartmentEquipmentMapping TCE ON TCE.TunnelCompartmentId = TC.TunnelCompartmentId AND TCE.EcoLabAccountNumber = TC.EcoLabAccountNumber AND TCE.Is_Deleted = 'False'
JOIN	TCD.ControllerEquipmentSetup CES ON CES.ControllerEquipmentSetupId = TCE.ControllerEquipmentSetupId AND CES.EcoLabAccountNumber = TCE.EcoLabAccountNumber
JOIN	TCD.ProductMaster PM ON PM.ProductId = CES.ProductId 
JOIN	TCD.TunnelProgramSetup TPS ON TPS.WasherGroupId = MS.GroupId AND TPS.EcolabAccountNumber = MS.EcoalabAccountNumber
JOIN	TCD.TunnelDosingSetup TDS ON tds.EcolabAccountNumber = TPS.EcolabAccountNumber 
							AND TDS.TunnelProgramSetupId = TPS.TunnelProgramSetupId AND TDS.CompartmentNumber = TC.CompartmentNumber
LEFT JOIN TCD.TunnelDosingProductMapping TDPM ON TDPM.CompartmentNumber = TC.CompartmentNumber AND TDPM.EcoLabAccountNumber = TDS.EcoLabAccountNumber
							AND TDPM.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId AND TDPM.TunnelDosingSetupId = TDS.TunnelDosingSetupId
	WHERE TC.CompartmentNumber = @CompartmentNumber AND MS.GroupId = @GroupId AND TDS.TunnelDosingSetupId = @DosingSetupId	
	AND MS.EcoalabAccountNumber = @EcoLabAccountNumber 
	AND TPS.TunnelProgramSetupId = @TunnelProgramSetupId
END	
	
SET	NOCOUNT	OFF

END
GO

/****** Object:  StoredProcedure [TCD].[GetWasherGroupInjectionDetailsForMyControl]    Script Date: 14-03-2016 20:27:58 ******/ 
IF EXISTS (SELECT * 
			   FROM   sys.objects 
			   WHERE  object_id = Object_id(N'[TCD].[GetWasherGroupInjectionDetailsForMyControl]') 
					  AND type IN ( N'P', N'PC' )) 
  DROP PROCEDURE [TCD].[GetWasherGroupInjectionDetailsForMyControl] 

GO 

/****** Object:  StoredProcedure [TCD].[GetWasherGroupInjectionDetailsForMyControl]    Script Date: 14-03-2016 20:27:58 ******/ 
CREATE PROCEDURE [TCD].[GetWasherGroupInjectionDetailsForMyControl](@EcolabAccountNumber	VARCHAR(1000) = NULL, 
                                                                    @WasherGroupId			INT = NULL,
                                                                    @WasherProgramSetupId	INT = NULL,
																	@ControllerId			INT = NULL)
AS 
  BEGIN 
      DECLARE @WasherGroupTypeId TINYINT = NULL 

      SET @WasherGroupTypeId = (SELECT Washergrouptypeid 
                                FROM   TCD.washergroup 
                                WHERE  Washergroupid = @WasherGroupId 
                                       AND Ecolabaccountnumber = @EcolabAccountNumber) 

      IF( @WasherGroupTypeId = 1 ) 
        BEGIN 
            SELECT DISTINCT WPS.Programid, 
                            WDS.Washerdosingsetupid, 
                            WG.Washergroupnumber, 
                            WG.Washergroupname, 
                            WPS.Nominalload              AS NominalLoad, 
                            WPS.Loadspermonth            AS LoadsPerMonth, 
                            WPS.Totalruntime             AS TotalRunTime,
							WDS.StepRunTime				 AS RunTime,
							WDS.DrainDestinationId		 AS DrainDestination, 
                            WPS.Extratime                AS ExtraTime, 
                            WPS.Totalsteps               AS NoOfWashSteps, 
                            WPS.Cooldownstep             AS CooldownStep, 
                            PRGM.Ecolabtextilecategoryid AS EcolabTextileCategoryId, 
                            WDS.Stepnumber               AS WashStepNumber, 
                            WDP.Injectionnumber          AS InjectionNumber, 
                            WDS.Temperature              AS Temperature, 
							WDACM.MinimumTime            AS Mintime, 
                            WDACM.StartDelay             AS StartDelay, 
                            WDACM.AcceptedDelay          AS AcceptDelay, 
							WDACM.ProductId				 AS ProductCheck,
							WDACM.SetPointTemperature    AS SetPoint,
                            WDP.Quantity, 
                            WDP.Delay, 
                            WDACM.Phcontrolduringdrain   AS PHControlDuringDrain, 
                            WDACM.Phdelaytime            AS PHControlDelayTime, 
                            WDACM.Phmeasuringtime        AS PHControlMeasuringTime, 
                            WDACM.Phmaximum              AS PHControlMaximum, 
                            WDACM.Phmininum              AS PHControlMinimum, 
                            PM.Productid, 
                            PM.NAME, 
                            WPS.Programnumber, 
                            WPS.Washerprogramsetupid, 
                            WDS.Watertype, 
                            WDS.Waterlevel,
							WG.ControllerId,
							CES.ControllerEquipmentId,
							WDP.WasherDosingProductMappingId
            FROM   [TCD].[washerdosingsetup] WDS 
                   INNER JOIN [TCD].[washerprogramsetup] WPS 
                           ON WPS.[Washerprogramsetupid] = WDS.[Washerprogramsetupid] 
                              AND WDS.Is_deleted = 0 
                   INNER JOIN TCD.washergroup WG 
                           ON WG.Controllerid = WPS.Controllerid 
                              AND WPS.Is_deleted = 0 
                   INNER JOIN TCD.injection IJ 
                           ON WG.Washergroupnumber = IJ.Washergroupnumber 
                              AND IJ.Is_deleted = 0 
                   INNER JOIN TCD.conduitcontroller CC 
                           ON IJ.Controllerid = CC.Controllerid 
                              AND CC.Isdeleted = 0 
                              --AND CC.Active = 1 
                   INNER JOIN TCD.controllertype CT 
                           ON CC.Controllertypeid = CT.Id 
                   INNER JOIN TCD.programmaster PRGM 
                           ON PRGM.Programid = WPS.Programid 
                   LEFT OUTER JOIN TCD.[washerdosinganalogcontrollermapping] WDACM 
                                ON WDACM.Washerdosingsetupid = WDS.Washerdosingsetupid 
                   LEFT OUTER JOIN TCD.[washertempsetup] WTS 
                                ON WPS.Programnumber = WTS.Programnumber 
                   LEFT JOIN TCD.washerdosingproductmapping WDP 
                          ON WDS.Washerdosingsetupid = WDP.Washerdosingsetupid 
                             AND WDP.Isdeleted = 0 
                   LEFT JOIN TCD.productmaster PM 
                          ON WDP.Productid = PM.Productid 
                             AND pm.Is_deleted = 0 
                   INNER JOIN TCD.controllerequipmentsetup CES 
                           ON CES.Productid = PM.Productid 
                              AND CES.Isactive = 1 
                              AND CES.Controllerid = CC.Controllerid 
                   LEFT JOIN [TCD].washstep WS 
                          ON WS.Stepid = WDS.Steptypeid 
                             AND WS.Isactive = 1 
             WHERE  WG.washergroupid = @WasherGroupId 
				   AND WG.ecolabaccountnumber = @EcolabAccountNumber 
				   AND cc.controllerid = @ControllerId 
				   AND WPS.WasherProgramSetupId = ISNULL(@WasherProgramSetupId, WPS.WasherProgramSetupId)
				   AND WDP.injectionnumber IS NOT NULL 
        END 
      ELSE 
        BEGIN 
            SELECT DISTINCT TPS.Programid, 
                            TDS.Tunneldosingsetupid, 
                            WG.Washergroupnumber, 
                            WG.Washergroupname, 
                            TPS.Nominalload              AS NominalLoad, 
                            TPS.Loadspermonth            AS LoadsPerMonth, 
                            TPS.Totalruntime             AS TotalRunTime, 
                            TPS.Extratime                AS ExtraTime, 
                            PRGM.Ecolabtextilecategoryid AS EcolabTextileCategoryId, 
                            TDS.Compartmentnumber        AS CompartmentNumber, 
                            TDP.Injectionnumber          AS InjectionNumber, 
                            TDS.PhRegLevel,
							TDS.MonLevel				 AS PhMonLevel,
							TDS.ConRegLevel, 
                            TDS.Temperature              AS Temperature, 
                            TTS.Mintime                  AS Mintime, 
                            TTS.Startdelay               AS StartDelay, 
                            TTS.Acceptdelay              AS AcceptDelay, 
                            TTS.Productcheck             AS ProductCheck, 
							TTS.DesiredTemperature		 AS SetPoint,
                            TDP.Quantity, 
                            TDP.Delaytime, 
                            PM.Productid, 
                            PM.NAME, 
                            TPS.Programnumber, 
                            TPS.Tunnelprogramsetupid, 
                            TDS.Watertype, 
                            TDS.Waterlevel,
							WG.ControllerId,
							CES.ControllerEquipmentId,  
							WG.WasherDosingNumber,
							TCEVM.DosingPointNumber
            FROM   [TCD].[tunneldosingsetup] TDS 
                   INNER JOIN [TCD].[tunnelprogramsetup] TPS 
                           ON TPS.[Tunnelprogramsetupid] = TDS.[Tunnelprogramsetupid] 
                              AND TDS.Is_deleted = 0 
                   INNER JOIN TCD.washergroup WG 
                           ON WG.Washergroupid = TPS.Washergroupid 
                              AND TPS.Is_deleted = 0 
                   LEFT JOIN TCD.injection IJ 
                           ON WG.Washergroupnumber = IJ.Washergroupnumber 
                              AND IJ.Is_deleted = 0 
                   LEFT JOIN TCD.conduitcontroller CC 
                           ON IJ.ControllerId = WG.ControllerId
                              AND CC.Isdeleted = 0 
                              --AND CC.Active = 1 
                   LEFT JOIN TCD.controllertype CT 
                           ON CC.Controllertypeid = CT.Id 
                   INNER JOIN TCD.programmaster PRGM 
                           ON PRGM.Programid = TPS.Programid 
                   LEFT JOIN TCD.[tunneltempsetup] TTS 
                                ON TPS.Tunnelprogramsetupid = TTS.Tunnelprogramsetupid AND TTS.CompartmentNumber = TDS.CompartmentNumber
                   INNER JOIN TCD.tunneldosingproductmapping TDP 
                          ON TDS.Tunneldosingsetupid = TDP.Tunneldosingsetupid
				   INNER JOIN TCD.controllerequipmentsetup CES 
					        ON CES.ControllerEquipmentSetupId  = TDP.ControllerEquipmentSetupId
					           AND CES.Isactive = 1 
							   LEFT JOIN TCD.productmaster PM 
					       ON PM.Productid = CES.Productid 
					          AND pm.Is_deleted = 0 
					LEFT JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM
					     ON TCEVM.ControllerEquipmentSetupID = CES.ControllerEquipmentSetupId
							AND TCEVM.TunnelNumber = WG.WasherDosingNumber
							AND ((TCEVM.DosingPointNumber = 0) OR (TCEVM.compartmentnumber = TDS.compartmentnumber AND TCEVM.DosingPointNumber <> 0))
					LEFT JOIN [TCD].washstep WS 
					       ON WS.Stepid = TDS.Steptypeid 
					          AND WS.Isactive = 1 
            WHERE  WG.washergroupid = @WasherGroupId 
				   AND WG.ecolabaccountnumber = @EcolabAccountNumber 
				   AND WG.controllerid = @ControllerId 
        END 
  END 
GO

/****** Object:  StoredProcedure [TCD].[GetWasherGroupFromulaInjectionDetailsForMyControl]    Script Date: 15-03-2016 19:48:57 ******/
IF EXISTS (SELECT * 
			   FROM   sys.objects 
			   WHERE  object_id = Object_id(N'[TCD].[GetWasherGroupFromulaInjectionDetailsForMyControl]') 
					  AND type IN ( N'P', N'PC' )) 
  DROP PROCEDURE [TCD].[GetWasherGroupFromulaInjectionDetailsForMyControl] 

GO 

/****** Object:  StoredProcedure [TCD].[GetWasherGroupFromulaInjectionDetailsForMyControl]    Script Date: 15-03-2016 19:48:57 ******/ 
CREATE PROCEDURE [TCD].[GetWasherGroupFromulaInjectionDetailsForMyControl](@EcolabAccountNumber  VARCHAR(1000) = NULL, 
                                                                           @WasherGroupId        INT = NULL,
                                                                           @WasherProgramSetupId INT = NULL)
AS 
  BEGIN 
      DECLARE @WasherGroupTypeId TINYINT =NULL 

      SET @WasherGroupTypeId = (SELECT Washergrouptypeid 
                                FROM   TCD.washergroup 
                                WHERE  Washergroupid = @WasherGroupId 
                                       AND Ecolabaccountnumber = @EcolabAccountNumber) 

      IF( @WasherGroupTypeId = 1 ) 
        BEGIN 
            SELECT DISTINCT WPS.Programid, 
                            WDS.Washerdosingsetupid, 
                            WG.Washergroupnumber, 
                            WG.Washergroupname, 
                            WPS.Nominalload              AS NominalLoad, 
                            WPS.Loadspermonth            AS LoadsPerMonth, 
                            WPS.Totalruntime             AS TotalRunTime,
							WDS.StepRunTime				 AS RunTime,
							WDS.DrainDestinationId		 AS DrainDestination,  
                            WPS.Extratime                AS ExtraTime, 
                            WPS.Totalsteps               AS NoOfWashSteps, 
                            WPS.Cooldownstep             AS CooldownStep, 
                            PRGM.Ecolabtextilecategoryid AS EcolabTextileCategoryId, 
                            WDS.Stepnumber               AS WashStepNumber, 
                            WDP.Injectionnumber          AS InjectionNumber, 
                            WDS.Temperature              AS Temperature, 
                            WDACM.MinimumTime            AS Mintime, 
                            WDACM.StartDelay             AS StartDelay, 
                            WDACM.AcceptedDelay          AS AcceptDelay, 
							WDACM.ProductId				 AS ProductCheck,
							WDACM.SetPointTemperature    AS SetPoint, 
                            WDP.Quantity, 
                            WDP.Delay, 
                            WDACM.Phcontrolduringdrain   AS PHControlDuringDrain, 
                            WDACM.Phdelaytime            AS PHControlDelayTime, 
                            WDACM.Phmeasuringtime        AS PHControlMeasuringTime, 
                            WDACM.Phmaximum              AS PHControlMaximum, 
                            WDACM.Phmininum              AS PHControlMinimum, 
                            PM.Productid, 
                            PM.NAME, 
                            WPS.Programnumber, 
                            WPS.Washerprogramsetupid, 
                            WDS.Watertype, 
                            WDS.Waterlevel,
							WG.ControllerId,
							CES.ControllerEquipmentId,
							WDP.WasherDosingProductMappingId
            FROM   [TCD].[washerdosingsetup] WDS 
                   INNER JOIN [TCD].[washerprogramsetup] WPS 
                           ON WPS.[Washerprogramsetupid] = WDS.[Washerprogramsetupid] 
                              AND WDS.Is_deleted = 0 
                   INNER JOIN TCD.washergroup WG 
                           ON WG.Controllerid = WPS.Controllerid 
                              AND WPS.Is_deleted = 0 
                   INNER JOIN TCD.injection IJ 
                           ON WG.Washergroupnumber = IJ.Washergroupnumber 
                              AND IJ.Is_deleted = 0 
                   INNER JOIN TCD.conduitcontroller CC 
                           ON IJ.Controllerid = CC.Controllerid 
                              AND CC.Isdeleted = 0 
                              --AND CC.Active = 1 
                   INNER JOIN TCD.controllertype CT 
                           ON CC.Controllertypeid = CT.Id 
                   INNER JOIN TCD.programmaster PRGM 
                           ON PRGM.Programid = WPS.Programid 
                   LEFT OUTER JOIN TCD.[washerdosinganalogcontrollermapping] WDACM 
                                ON WDACM.Washerdosingsetupid = WDS.Washerdosingsetupid 
                   LEFT OUTER JOIN TCD.[washertempsetup] WTS 
                                ON WPS.Programnumber = WTS.Programnumber 
                   LEFT JOIN TCD.washerdosingproductmapping WDP 
                          ON WDS.Washerdosingsetupid = WDP.Washerdosingsetupid 
                             AND WDP.Isdeleted = 0 
                   LEFT JOIN TCD.productmaster PM 
                          ON WDP.Productid = PM.Productid 
                             AND pm.Is_deleted = 0 
                   INNER JOIN TCD.controllerequipmentsetup CES 
                           ON CES.Productid = PM.Productid 
                              AND CES.Isactive = 1 
                              AND CES.Controllerid = CC.Controllerid 
                   LEFT JOIN [TCD].washstep WS 
                          ON WS.Stepid = WDS.Steptypeid 
                             AND WS.Isactive = 1 
            WHERE  WG.Washergroupid = @WasherGroupId 
                   AND WPS.Washerprogramsetupid = @WasherProgramSetupId 
                   AND WPS.Ecolabaccountnumber = @EcolabAccountNumber 
        END 
      ELSE 
        BEGIN 
            SELECT DISTINCT TPS.Programid, 
                            TDS.Tunneldosingsetupid, 
                            WG.Washergroupnumber, 
                            WG.Washergroupname, 
                            TPS.Nominalload              AS NominalLoad, 
                            TPS.Loadspermonth            AS LoadsPerMonth, 
                            TPS.Totalruntime             AS TotalRunTime, 
                            TPS.Extratime                AS ExtraTime, 
                            PRGM.Ecolabtextilecategoryid AS EcolabTextileCategoryId, 
                            TDS.Compartmentnumber        AS CompartmentNumber, 
                            TDP.Injectionnumber          AS InjectionNumber, 
                            TDS.PhRegLevel,
							TDS.MonLevel				 AS PhMonLevel,
							TDS.ConRegLevel, 
                            TDS.Temperature              AS Temperature, 
                            TTS.Mintime                  AS Mintime, 
                            TTS.Startdelay               AS StartDelay, 
                            TTS.Acceptdelay              AS AcceptDelay, 
                            TTS.Productcheck             AS ProductCheck, 
							TTS.DesiredTemperature		 AS SetPoint,
                            TDP.Quantity, 
                            TDP.Delaytime, 
                            PM.Productid, 
                            PM.NAME, 
                            TPS.Programnumber, 
                            TPS.Tunnelprogramsetupid, 
                            TDS.Watertype, 
                            TDS.Waterlevel,
							WG.ControllerId,
							CES.ControllerEquipmentId,  
							WG.WasherDosingNumber,
							TCEVM.DosingPointNumber
            FROM   [TCD].[tunneldosingsetup] TDS 
                   INNER JOIN [TCD].[tunnelprogramsetup] TPS 
                           ON TPS.[Tunnelprogramsetupid] = TDS.[Tunnelprogramsetupid] 
                              AND TDS.Is_deleted = 0 
                   INNER JOIN TCD.washergroup WG 
                           ON WG.Washergroupid = TPS.Washergroupid 
                              AND TPS.Is_deleted = 0 
                   LEFT JOIN TCD.injection IJ 
                           ON WG.Washergroupnumber = IJ.Washergroupnumber 
                              AND IJ.Is_deleted = 0 
                   LEFT JOIN TCD.conduitcontroller CC 
                           ON IJ.ControllerId = WG.ControllerId
                              AND CC.Isdeleted = 0 
                              --AND CC.Active = 1 
                   LEFT JOIN TCD.controllertype CT 
                           ON CC.Controllertypeid = CT.Id 
                   INNER JOIN TCD.programmaster PRGM 
                           ON PRGM.Programid = TPS.Programid 
                   LEFT JOIN TCD.[tunneltempsetup] TTS 
                                ON TPS.Tunnelprogramsetupid = TTS.Tunnelprogramsetupid AND TTS.CompartmentNumber = TDS.CompartmentNumber
                   INNER JOIN TCD.tunneldosingproductmapping TDP 
                          ON TDS.Tunneldosingsetupid = TDP.Tunneldosingsetupid
				   INNER JOIN TCD.controllerequipmentsetup CES 
					        ON CES.ControllerEquipmentSetupId  = TDP.ControllerEquipmentSetupId
					           AND CES.Isactive = 1 
							   LEFT JOIN TCD.productmaster PM 
					       ON PM.Productid = CES.Productid 
					          AND pm.Is_deleted = 0 
					LEFT JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM
					     ON TCEVM.ControllerEquipmentSetupID = CES.ControllerEquipmentSetupId
							AND TCEVM.TunnelNumber = WG.WasherDosingNumber
							AND ((TCEVM.DosingPointNumber = 0) OR (TCEVM.compartmentnumber = TDS.compartmentnumber AND TCEVM.DosingPointNumber <> 0))
					LEFT JOIN [TCD].washstep WS 
					       ON WS.Stepid = TDS.Steptypeid 
					          AND WS.Isactive = 1 
            WHERE  WG.Washergroupid = @WasherGroupId 
                   AND TPS.Tunnelprogramsetupid = @WasherProgramSetupId 
                   AND WG.Ecolabaccountnumber = @EcolabAccountNumber 
        END 
  END 
GO


IF EXISTS (SELECT * 
			   FROM   sys.objects 
			   WHERE  object_id = Object_id(N'[TCD].[SavePlantMeterDetails]') 
					  AND type IN ( N'P', N'PC' )) 
  DROP PROCEDURE [TCD].[SavePlantMeterDetails] 

GO 

CREATE PROCEDURE [TCD].[SavePlantMeterDetails] (
@MeterNumber NVARCHAR(100) = NULL
, @EcolabAccountNumber NVARCHAR(25) = NULL
, @MeterName NVARCHAR(100) = NULL
, @Uitiliy NVARCHAR(100) = NULL
, @UtilityLocation NVARCHAR(100) = NULL
, @MachineCompartment NVARCHAR(100) = NULL
, @Parent NVARCHAR(100) = NULL
, @Calibration NVARCHAR(100) = NULL
, @UOFfoRCalibration NVARCHAR(100) = NULL
, @Usagefactor NVARCHAR(100) = NULL
, @ControllerID INT
, @ControllerModelID INT
, @DigitalInputNumber NVARCHAR(100) = NULL
, @AllowmanualEntry  NVARCHAR(100) = NULL
, @Meterrolloverpoint VARCHAR(100) = NULL
, @UserID INT
, @Scope VARCHAR(100) OUTPUT
, @OutputMeterId	INT = NULL	OUTPUT
, @LastModifiedTimestampAtCentral DATETIME = NULL
, @OutputLastModifiedTimestampAtLocal	DATETIME = NULL OUTPUT
)
AS
BEGIN
    SET NOCOUNT ON;
    SET @Scope = '';
    DECLARE
	    @IsPlant BIT = NULL,
	    @IsPress BIT = NULL;
    DECLARE
	    @ReturnValue					INT = 0
	    ,@ErrorId						INT = 0
	    ,@ErrorMessage					NVARCHAR(4000) = N''
	    ,@CurrentUTCTime					DATETIME = GETUTCDATE();
    DECLARE
	    @OutputList						AS	TABLE		(
	    MeterId							INT
	    ,LastModifiedTimestamp			DATETIME
	    );
    SET		@OutputLastModifiedTimestampAtLocal = ISNULL(@OutputLastModifiedTimestampAtLocal, NULL);
    SET		@OutputMeterId = ISNULL(@OutputMeterId, NULL);

    /* Business vaidations for setingup the meters to controllers */

    IF	@LastModifiedTimestampAtCentral   IS NOT NULL
	 AND NOT	EXISTS	(	SELECT	1
						  FROM	TCD.Meter		M
						  WHERE	M.EcolabAccountNumber = @EcolabAccountNumber
							 AND M.MeterId = @MeterNumber
							 AND M.LastModifiedTime = @LastModifiedTimestampAtCentral
		)
	   BEGIN
		  SET			@ErrorId = 60000;
		  SET			@ErrorMessage = N''
									 +
									 CAST(@ErrorId AS NVARCHAR);
		  RAISERROR	(@ErrorMessage, 16, 1);
		  SET			@ReturnValue = -1;
		  RETURN
		  @ReturnValue;
	   END;

    -- Begin Defining Limits

    BEGIN
	   DECLARE
		   @UtilityLimit INT = NULL,
		   @WasherLimit INT = NULL,
		   @TunnelLimit INT = NULL,
		   @IStunnel INT = '',
		   @MeterNameLimit INT = NULL;

	 SELECT @MeterNameLimit = COUNT(1)
		FROM TCD.Meter 
		WHERE [Description] = @MeterName 
		AND EcolabAccountNumber = @EcolabAccountNumber
		AND Is_deleted = 0

	 
	   SELECT @UtilityLimit = COUNT(1)
		FROM TCD.meter
		WHERE GroupId = @UtilityLocation
		  AND UtilityType = @Uitiliy
		  AND ISNULL(MachineCompartment, 0) = @MachineCompartment
		  AND Is_deleted = 0
		  AND EcolabAccountNumber = @EcolabAccountNumber
		  AND ControllerID IN (
			 SELECT ControllerId
			   FROM TCD.ConduitController
			   WHERE ControllerId = @ControllerID
				AND EcoalabAccountNumber = @EcolabAccountNumber);
	   SELECT @WasherLimit = COUNT(1)
		FROM TCD.Meter M
			LEFT OUTER JOIN
			TCD.machinesetup MS ON M.GroupId = MS.groupId
						    AND M.MachineCompartment = MS.MachineInternalID
		WHERE M.UtilityType = 2
		  AND M.GroupID = @UtilityLocation
		  AND Is_deleted = 0
		  AND EcolabAccountNumber = @EcolabAccountNumber
		  AND M.ControllerID IN (
			 SELECT ControllerId
			   FROM TCD.ConduitController
			   WHERE ControllerModelId = 7
				AND EcoalabAccountNumber = @EcolabAccountNumber);
	   SELECT @TunnelLimit = COUNT(1)
		FROM TCD.Meter M
			LEFT OUTER JOIN
			TCD.machinesetup MS ON M.GroupId = MS.groupId
		WHERE M.UtilityType = 2
		  AND M.GroupID = @UtilityLocation
		  AND Ms.Istunnel = 1
		  AND Is_deleted = 0
		  AND EcoalabAccountNumber = @EcolabAccountNumber
		  AND M.ControllerID IN (
			 SELECT ControllerId
			   FROM TCD.ConduitController
			   WHERE ControllerModelId = 7
				AND EcoalabAccountNumber = @EcolabAccountNumber);
	   SELECT @IStunnel = Istunnel
		FROM TCD.machinesetup MS
		WHERE Ms.GroupId = @UtilityLocation
		  AND EcoalabAccountNumber = @EcolabAccountNumber;
    END;

    -- End Defining Limits

    IF @IStunnel = 1
        BEGIN				
            IF @MachineCompartment = 1
                BEGIN
                    SET @IsPress = 1;
                END;
		IF @MachineCompartment = 0
            BEGIN
			SET @MachineCompartment = NULL;
			END
        END;

    IF @UtilityLocation = 1
	   BEGIN
		  SET @IsPlant = 1;
		  SET @UtilityLocation = NULL;
		  SET @MachineCompartment = NULL;
	   END;
    IF @ControllerID = -1
	   BEGIN
		  SELECT TOP (1) @ControllerID = ControllerID
		    FROM TCD.ConduitController
		    WHERE ControllerModelId = @ControllerModelID
			 AND EcoalabAccountNumber = @EcolabAccountNumber;
	   END;
    ELSE
	   BEGIN
		  SELECT @ControllerModelID = ControllerModelId
		    FROM TCD.ConduitController
		    WHERE ControllerId = @ControllerID
			 AND EcoalabAccountNumber = @EcolabAccountNumber;
	   END;
    IF @ControllerID != -1
	   BEGIN
		  DECLARE
			  @NewMeterId INT
			  ,@TagType VARCHAR(50) = 'Tag_MPLC'
			  ,@ModuleTypeId INT = 2
			  ,@Result INT = NULL
			  ,@Type INT = 2
			  ,@AllowTagEdit BIT;
		  SELECT @AllowTagEdit = CASE
							WHEN COUNT(*) > 0 THEN 'TRUE'
							    ELSE 'FALSE'
							END
		    FROM TCD.UserMaster UM
			    INNER JOIN
			    TCD.UserInRole UIR ON UM.UserId = UIR.UserId
			    INNER JOIN
			    TCD.UserRoles UR ON UIR.RoleId = UR.RoleId
		    WHERE UM.UserId = @UserID
			 AND UR.LevelId >= 8;
		  IF NOT EXISTS (SELECT 1
					    FROM   TCD.Meter
					    WHERE  MeterID = @MeterNumber
						  AND EcolabAccountNumber = @EcolabAccountNumber)

			 -- Begin Create Meter

			 BEGIN

					   DECLARE @AllowInsert BIT = 'FALSE';

					   -- Begin Business Validations
					   IF @MeterNameLimit < 1
					   	   BEGIN
							   IF @UtilityLimit < 1 OR @Uitiliy = 2
								  BEGIN
								 	 		 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 		 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 IF @ControllerModelID = 7
								BEGIN
													
								    IF @UtilityLimit >= 1 AND @Uitiliy != 2
									   BEGIN
										  SET @Scope = @Scope + '301,';										 
									   END;
								    IF @Uitiliy = 2 AND @IStunnel = 1
									   BEGIN   										
									IF @UtilityLimit >= 1
									   BEGIN
										  SET @Scope = @Scope + '301,';										  
									   END;									 
										ELSE IF @TunnelLimit < 6
											BEGIN											
												SET @AllowInsert = 'TRUE';
											END;
										ELSE
											BEGIN											
												SET @Scope = @Scope + '101,';
											END;
										END;
									ELSE IF @Uitiliy = 2 AND @IStunnel != 1
									   BEGIN		
										 IF @WasherLimit < 2
											BEGIN
												SET @AllowInsert = 'TRUE';												
											END;
										ELSE
											BEGIN
												SET @Scope = @Scope + '201,';												
											END;
										END;									   
								    ELSE
									   BEGIN
										  SET @AllowInsert = 'TRUE';										  
									   END;
								END;
							 ELSE
								BEGIN
								    SET @AllowInsert = 'TRUE';									
								END;
								  END;
							   ELSE
								  BEGIN
									 SET @Scope = @Scope + '301,';									 
							   END;
			               END;
						ELSE
							BEGIN
								SET @Scope = @Scope + '302,';								
							END;
						
						IF @Uitiliy = 12
						 BEGIN
							SET @AllowInsert = 'TRUE';
							SET @Scope = '';
						 END;						


					   -- End Business Validations
					   -- Begin Insert if Validation Succeeds

					   IF @AllowInsert = 'TRUE'
						  BEGIN
							 INSERT INTO TCD.Meter (EcolabAccountNumber,
											    Description,
											    UtilityType,
											    GroupId,
											    MachineCompartment,
											    MaxValueLimit,
											    MeterTickUnit,
											    UsageFactor,
											    ControllerID,
											    Parent,
											    Calibration,
											    AllowManualentry ,
											    LastModifiedByUserId,
											    IsPlant,
											    IsPress)
							 OUTPUT
							 inserted.MeterId				AS MeterId
							 ,inserted.LastModifiedTime		AS LastModifiedTimestamp
								   INTO
								   @OutputList	(
								   MeterId
								   ,LastModifiedTimestamp
								   )
							 SELECT
							 @EcolabAccountNumber,
							 @MeterName,
							 @Uitiliy,
							 @UtilityLocation,
							 @MachineCompartment,
							 @Meterrolloverpoint,
							 @UOFfoRCalibration,
							 @Usagefactor,
							 @ControllerID,
							 @Parent,
							 @Calibration,
							 @AllowmanualEntry,
							 @UserID,
							 @IsPlant,
							 @IsPress;
							 IF @AllowTagEdit = 'TRUE'
								BEGIN
								    IF @Result IS NOT NULL
									   BEGIN
										  SET @NewMeterId = SCOPE_IDENTITY();
										  INSERT INTO TCD.ModuleTags (EcolabAccountNumber,
																TagType,
																TagAddress,
																ModuleTypeId,
																ModuleID,
																DeadBand,
																Active)
										  VALUES(@EcolabAccountNumber,
											    @TagType,
											    @DigitalInputNumber,
											    @ModuleTypeId,
											    @NewMeterId,
											    20,
											    1);
									   END;
								END;
						  END;

				    -- End Insert if Validation Succeeds

				  --  END;
				ELSE
				    BEGIN
					   SET @Scope = @Scope + '802,';
				    END;
			 END;

		  --End Create Meter
		  ELSE

			 -- Begin Update Meter

			 BEGIN
				DECLARE
					@PlantId INT = (SELECT MG.Id
								   FROM TCD.MachineGroupType MGT
									   INNER JOIN
									   TCD.MachineGroup MG ON MGT.Id = MG.GroupTypeId
								   WHERE MGT.Id = 1
									AND MG.Is_Deleted = 0);

				-- Check RedFlag Association and Update Meter

				IF((SELECT COALESCE(  M.GroupId, '')
					 FROM TCD.Meter M
					 WHERE M.MeterId = @MeterNumber) != COALESCE(@UtilityLocation, '')
				OR (SELECT COALESCE(  M.MachineCompartment  , '')
					 FROM TCD.Meter M
					 WHERE M.MeterId = @MeterNumber) != COALESCE(@MachineCompartment, '')  )
			   AND EXISTS(SELECT 1
						 FROM TCD.RedFlag RF
							 INNER JOIN
							 TCD.RedFlagMappingData RFM ON RF.Id = RFM.MappingId
												  AND RF.Is_Deleted = 0
												  AND RFM.Is_Deleted = 0
							 LEFT JOIN
							 TCD.Meter M ON RF.Location = CASE M.IsPlant
													WHEN 'TRUE' THEN COALESCE(  M.GroupId , @PlantId)
													    ELSE M.GroupId
													END
									  AND COALESCE(  M.MachineCompartment , 0) = COALESCE(  RFM.MachineId , 0)
									  AND M.Is_deleted = 0
						 WHERE M.MeterId = @MeterNumber)
				    BEGIN
					   SET @Scope = '405,';
				    END;
				ELSE
				    BEGIN
					   DECLARE
						   @AllowUpdate BIT = 'FALSE';
							 --Begin Get old Meter Values 

							 BEGIN
								DECLARE
									@Uty INT = (SELECT UtilityType
											    FROM TCD.Meter
											    WHERE MeterID = @MeterNumber
												 AND EcolabAccountNumber = @EcolabAccountNumber);
								DECLARE
									@grpId INT = (SELECT GroupId
												 FROM TCD.Meter
												 WHERE MeterID = @MeterNumber
												   AND EcolabAccountNumber = @EcolabAccountNumber);
								DECLARE
									@machId INT = (SELECT MachineCompartment
												  FROM TCD.Meter
												  WHERE MeterID = @MeterNumber
												    AND EcolabAccountNumber = @EcolabAccountNumber);
								DECLARE
								    @Mname INT =(SELECT COUNT(1) 
													FROM TCD.Meter 
													WHERE [Description] = @MeterName
														AND MeterId <> @MeterNumber
														AND EcolabAccountNumber = @EcolabAccountNumber
														AND Is_deleted = 0);
							 END;

							 --End Get old Meter Values

							 IF @AllowTagEdit = 'TRUE'
								BEGIN
								    IF @DigitalInputNumber IS NOT NULL
									   BEGIN
										  EXEC @Result = TCD.CheckDuplicateTag @DigitalInputNumber, @ControllerID, @MeterNumber, @Type;
									   END;
								END;

							 -- Begin Business Validations
							
							IF @Mname < 1
							Begin
							  IF @uty <> @Uitiliy
							 OR @grpId <> @UtilityLocation
							 OR @machId <> @MachineCompartment
								BEGIN
								    IF @UtilityLimit < 1
									   BEGIN
										  IF @ControllerModelID = 7
											 BEGIN

												/* Inserting the Details of meter in to Meter table if it is new meter */

												IF @Uitiliy = 2
												    BEGIN
													   IF @IStunnel = 'TRUE'
														  BEGIN
															 IF @TunnelLimit < 6
															 OR @TunnelLimit < = 6
															AND @uty = @Uitiliy
															AND @grpId = @UtilityLocation
																BEGIN
																    SET @AllowUpdate = 'TRUE';
																END;
															 ELSE
																BEGIN
																    SET @Scope = @Scope + '101,';
																END;
														  END;
													   ELSE
														  BEGIN
															 IF @WasherLimit < 2
															 OR @WasherLimit < = 2
															AND @uty = @Uitiliy
															AND @grpId = @UtilityLocation
																BEGIN
																    SET @AllowUpdate = 'TRUE';
																END;
															 ELSE
																BEGIN
																    SET @AllowUpdate = 'FALSE';
																    SET @Scope = @Scope + '201,';
																END;
														  END;
												    END;
												ELSE
												    BEGIN
													   SET @AllowUpdate = 'TRUE';
												    END;
											 END;
										  ELSE
											 BEGIN
												SET @AllowUpdate = 'TRUE';
											 END;
									   END;
								    ELSE
									   BEGIN
										  SET @Scope = @Scope + '301,';
									   END;
								END;
							 ELSE
								BEGIN
								    SET @AllowUpdate = 'TRUE';
								END;
								END;
								ELSE
								BEGIN
								 SET @Scope = @Scope + '302,';
								END;

							 -- End Business Validations 
							 -- Begin Update if Validation Succeeds

							 IF @AllowUpdate = 'TRUE'
								BEGIN
								    UPDATE P
									 SET  Description = @MeterName,
										 UtilityType = @Uitiliy,
										 GroupId = @UtilityLocation,
										 MachineCompartment = @MachineCompartment,
										 Parent = @Parent,
										 Calibration = @Calibration,
										 ControllerID = @ControllerID,
										 MeterTickUnit = @UOFfoRCalibration,
										 UsageFactor = @Usagefactor,
										 AllowmanualEntry = @AllowmanualEntry,
										 Maxvaluelimit = @Meterrolloverpoint,
										 IsPlant = @IsPlant,
										 IsPress = @IsPress,
										 LastModifiedByUserId = @UserID,
										 LastModifiedTime = @CurrentUTCTime

								    OUTPUT
								    inserted.MeterId				AS MeterId
								    ,inserted.LastModifiedTime		AS LastModifiedTimestamp
										 INTO
										 @OutputList(
										 MeterId ,
										 LastModifiedTimestamp
										 )
									 FROM   TCD.Meter P
									 WHERE MeterID = @MeterNumber
									   AND EcolabAccountNumber = @EcolabAccountNumber;
								   
								--END;

						  -- End Update if Validation Succeeds 

						  END;
					
				    END;
			 END;

	   -- End Update Meter

	   END;
    ELSE
	   BEGIN
		  SET @Scope = '701,';
	   END;
    SET NOCOUNT OFF;
    SELECT	TOP 1
    @OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp
    ,@OutputMeterId = O.MeterId
	 FROM @OutputList O;
    RETURN @ReturnValue;
END;
GO

IF EXISTS (SELECT * 
			   FROM   sys.objects 
			   WHERE  object_id = Object_id(N'[TCD].[GetPlantSensorDetails]') 
					  AND type IN ( N'P', N'PC' )) 
  DROP PROCEDURE [TCD].[GetPlantSensorDetails] 

GO 
  
CREATE PROCEDURE [TCD].[GetPlantSensorDetails] 
(
@SensorID int = NULL,
@EcolabAccountNumber nvarchar(25)
)  
AS   
  BEGIN   
      SET nocount ON;   

	  Declare @ControllerID int = NULL
	  Select @ControllerID = ControllerID from [TCD].Sensor where SensorId =  @SensorID
	  DECLARE @WaterandEnergyGroupId  INT = (SELECT TOP (1) MG.Id
									   FROM TCD.MachineGroup MG
										    INNER JOIN
										    TCD.MachineGroupType MGT ON MGT.Id = MG.GroupTypeId
									   WHERE MGT.Id = 5	  );
	  
	  	  If exists(Select 1 from [TCD].[ConduitController])
	  Begin
   Select  
S.SensorId,
S.Description,
S.SensorType,
(Select Name from [TCD].SensorTypemaster rm where rm.Resourceid = S.SensorType) as SensorTypeName,
S.EcolabAccountNumber,
					CASE 
						WHEN S.Machinecompartment IS NULL
							THEN 
								CASE 
									WHEN S.IsPress = 1 
										THEN 1 
										ELSE 0 END
ELSE S.Machinecompartment
END AS Machinecompartment,
CASE
			WHEN S.MachineCompartment IS NULL AND (S.IsPress = 0 OR S.IsPress IS NULL) THEN 'ALL'
			WHEN (SELECT DISTINCT  Istunnel FROM [TCD].machinesetup M WHERE M.groupId = S.GroupId )= 1 THEN CASE WHEN S.MachineCompartment IS NULL AND S.IsPress = 1 THEN 'Press' ELSE 'Compartment' + CAST( S.Machinecompartment AS varchar( 100)) END
      WHEN (SELECT DISTINCT Istunnel FROM [TCD].machinesetup M WHERE M.groupId = S.GroupId)= 0 THEN (SELECT CAST (WS.PlantWasherNumber AS nvarchar) + ':' + MachineName FROM [TCD].MachineSetup M INNER JOIN TCD.Washer WS ON M.WasherId = WS.WasherId WHERE M.GroupId = S.GroupId AND M.WasherId	 = S.MachineCompartment)
			WHEN (SELECT DISTINCT GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.Id = S.GroupId ) = 3 THEN (SELECT D.Description FROM [TCD].Dryers D WHERE D.DryerGroupId = S.GroupId AND D.Id = S.MachineCompartment)
			WHEN (SELECT DISTINCT GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.Id = S.GroupId ) = 4 THEN (SELECT F.Name FROM [TCD].Finnishers F WHERE F.FinnisherGroupId = S.GroupId AND F.FinnisherId = S.MachineCompartment)
			WHEN (SELECT DISTINCT GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.Id = S.GroupId ) = 5 THEN (SELECT DeviceName FROM TCD.WaterAndEnergy WE WHERE S.GroupId = @WaterandEnergyGroupId AND WE.DeviceNumber = S.MachineCompartment  AND WE.Is_deleted	= 0)
			WHEN (SELECT MM.MachineCompartment FROM [TCD].Meter MM WHERE MM.GroupId = S.GroupId) = 0 THEN 'Press'
      END AS MachinecompartmentName ,
			CC.ControllerID,	
			CC.Name AS ControllerName,
			CC.ControllerModelId,
			CM.RegionId AS ControllerRegionId,	
			CT.Id AS ControllerTypeId,
			CT.Name AS ControllerType,
			S.OutputType,
			S.ChemicalforChart,
			(Select DISTINCT p.Name from [TCD].productmaster P where P.productId = S.ChemicalforChart) as ChemicalforChartName,
			s.UOM,
			'S.UOMName' as UOMName,
			S.DashboardActualValue,
			( CASE WHEN S.groupID IS NULL AND S.IsPlant = 1
			   THEN 1
			   ELSE
                   (SELECT G.Id
                     FROM [TCD].MachineGroup G
                     WHERE G.Id
                           = 
                           S.groupID AND G.EcolabAccountNumber = @EcolabAccountNumber)
			   END )AS GroupId , 
			(	CASE WHEN (S.groupID IS NULL AND S.MachineCompartment IS NULL AND S.IsPlant = 1) THEN 'Plant'
				ELSE
                     (SELECT GroupDescription
                       FROM [TCD].MachineGroup G
                       WHERE G.Id
                             = 
                             S.groupID AND G.EcolabAccountNumber = @EcolabAccountNumber) END
                   )AS SensorLocation,
			(SELECT MTS.TagAddress FROM TCD.ModuleTags MTS WHERE MTS.TagType = 'Tag_MPLC' AND MTS.ModuleID = SensorId AND MTS.ModuleTypeId = 3 AND MTS.Active = 1) AS AnalogueInputNumber,
			S.Calibration4mA,
			S.Calibration20mA,
			(SELECT MTS.TagAddress FROM TCD.ModuleTags MTS WHERE MTS.TagType = 'Tag_SC4' AND MTS.ModuleID = SensorId AND MTS.ModuleTypeId = 3 AND MTS.Active = 1) AS CalibrationTag4,
					(SELECT MTS.TagAddress FROM TCD.ModuleTags MTS WHERE MTS.TagType = 'Tag_SC20' AND MTS.ModuleID = SensorId AND MTS.ModuleTypeId = 3 AND MTS.Active = 1) AS CalibrationTag20,
					S.LastSyncTime,
					S.LastModifiedTime
			  from [TCD].Sensor S 
				LEFT JOIN [TCD].ConduitController CC
				ON CC.ControllerId = S.ControllerID
				LEFT JOIN [TCD].ControllerModel CM 
				ON CM.Id = CC.ControllerModelId
				LEFT JOIN [TCD].ControllerType CT
				ON CT.Id = CC.ControllerTypeId
			Where Is_Deleted = 0  
End

Else
   Select  
S.SensorId,
S.Description,
S.SensorType,
(Select Name from [TCD].SensorTypemaster rm where rm.Resourceid = S.SensorType) as SensorTypeName,
S.EcolabAccountNumber,
				CASE 
					WHEN S.Machinecompartment IS NULL
						THEN 
							CASE 
								WHEN S.IsPress = 1 
									THEN 1 
									ELSE 0 
								END
ELSE S.Machinecompartment
END AS Machinecompartment,
CASE
			WHEN S.MachineCompartment IS NULL AND (S.IsPress = 0 OR S.IsPress IS NULL) THEN 'ALL'
			WHEN (SELECT DISTINCT  Istunnel FROM [TCD].machinesetup M WHERE M.groupId = S.GroupId )= 1 THEN CASE WHEN S.MachineCompartment IS NULL AND S.IsPress = 1 THEN 'Press' ELSE 'Compartment' + CAST( S.Machinecompartment -1 AS varchar( 100)) END
      WHEN (SELECT DISTINCT Istunnel FROM [TCD].machinesetup M WHERE M.groupId = S.GroupId)= 0 THEN (SELECT MachineName FROM [TCD].MachineSetup M WHERE M.GroupId = S.GroupId AND M.WasherId = S.MachineCompartment)
			WHEN (SELECT DISTINCT GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.Id = S.GroupId ) = 3 THEN (SELECT Description FROM [TCD].Dryers WHERE DryerGroupId = S.GroupId AND DryerNo = S.MachineCompartment)
			WHEN (SELECT MM.MachineCompartment FROM [TCD].Meter MM WHERE MM.GroupId = S.GroupId) = 0 THEN 'Press'
      END AS MachinecompartmentName ,
			CC.ControllerID,	
			CC.Name AS ControllerName,
			CC.ControllerModelId,
			CM.RegionId AS ControllerRegionId,	
			CT.Id AS ControllerTypeId,
			CT.Name AS ControllerType,
			S.OutputType,
			S.ChemicalforChart,
			(Select DISTINCT p.Name from [TCD].productmaster P where P.productId = S.ChemicalforChart) as ChemicalforChartName,
			s.UOM,
			'S.UOMName' as UOMName,
			S.DashboardActualValue,
			S.GroupId,
			(select DISTINCT GroupDescription from [TCD].MachineGroup G where G.Id = s.GroupId) as SensorLocation,
			(SELECT MTS.TagAddress FROM TCD.ModuleTags MTS WHERE MTS.TagType = 'Tag_MPLC' AND ModuleID = SensorId) AS AnalogueInputNumber,
			S.Calibration4mA,
			S.Calibration20mA,
			(SELECT MTS.TagAddress FROM TCD.ModuleTags MTS WHERE MTS.TagType = 'Tag_SC4' AND ModuleID = SensorId) AS CalibrationTag4,
				(SELECT MTS.TagAddress FROM TCD.ModuleTags MTS WHERE MTS.TagType = 'Tag_SC20' AND ModuleID = SensorId) AS CalibrationTag20,
				S.LastSyncTime,
				S.LastModifiedTime
			  from [TCD].Sensor S 
				LEFT JOIN [TCD].ConduitController CC
				ON CC.ControllerId = S.ControllerID
				LEFT JOIN [TCD].ControllerModel CM 
				ON CM.Id = CC.ControllerModelId
				LEFT JOIN [TCD].ControllerType CT
				ON CT.Id = CC.ControllerTypeId
				Where 1=2
SET NOCOUNT OFF;
END
GO

IF EXISTS (SELECT * 
			   FROM   sys.objects 
			   WHERE  object_id = Object_id(N'[TCD].[GetPlantMeterDetails]') 
					  AND type IN ( N'P', N'PC' )) 
  DROP PROCEDURE [TCD].[GetPlantMeterDetails] 

GO                                     

CREATE PROCEDURE [TCD].[GetPlantMeterDetails](@MeterId INT = NULL, @EcolabAccountNumber NVARCHAR(25))
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE
       @EmptyHeader varchar( 100
                           );

    IF EXISTS( SELECT 1
                 FROM [TCD].ConduitController WHERE EcoalabAccountNumber = @EcolabAccountNumber
             )
        BEGIN
		    DECLARE @WaterandEnergyGroupId  INT = (SELECT TOP (1) MG.Id
									   FROM TCD.MachineGroup MG
										    INNER JOIN
										    TCD.MachineGroupType MGT ON MGT.Id = MG.GroupTypeId
									   WHERE MGT.Id = 5	  );
           SELECT M.MeterId , 
                  M.Description , 
                  M.UtilityType , 
                  CASE M.UtilityType WHEN 12 THEN 'Pieces'
				  ELSE (SELECT Name FROM [TCD].UtilityMaster rm WHERE rm.ResourceId = M.UtilityType )
				  END AS MeterTypeName , 
                  M.EcolabAccountNumber , 
                  M.MaxValueLimit , 
                  M.MeterTickUnit , 
                  M.UsageFactor , 
			   CASE WHEN M.Machinecompartment IS NULL  THEN 
					CASE  WHEN M.IsPress = 1 THEN 1
						WHEN M.GroupId IS NULL AND (M.IsPress = 0 OR M.IsPress IS NULL) AND (M.IsPlant = 0 OR M.IsPlant IS NULL) THEN NULL 
						ELSE 0 END 
					ELSE M.Machinecompartment 
				END AS Machinecompartment ,

                CASE WHEN M.MachineCompartment IS NULL AND (M.IsPress = 0 OR M.IsPress IS NULL) THEN
					CASE	WHEN M.GroupId IS NULL AND (M.IsPlant = 0 OR M.IsPlant IS NULL) THEN NULL	ELSE 'ALL' END	 
				WHEN( SELECT DISTINCT Istunnel FROM [TCD].machinesetup S WHERE S.groupId = M.GroupId AND S.IsDeleted = 0 AND S.EcoalabAccountNumber = @EcolabAccountNumber)= 1 THEN 
					CASE WHEN M.MachineCompartment IS NULL AND M.IsPress = 1 THEN 'Press' ELSE 'Compartment' + CAST( M.Machinecompartment AS varchar( 100)) END
				WHEN( SELECT DISTINCT Istunnel FROM [TCD].MachineSetup S WHERE S.groupId = M.GroupId  AND S.IsDeleted = 0)= 0 THEN 
			   			(SELECT CAST (WS.PlantWasherNumber AS nvarchar) +':' + S.MachineName FROM [TCD].MachineSetup S INNER JOIN TCD.Washer WS ON S.WasherId = WS.WasherId WHERE S.GroupId = M.GroupId AND S.WasherId	 = M.MachineCompartment AND S.IsDeleted = 0)
				WHEN (SELECT DISTINCT GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.Id = M.GroupId ) = 3 THEN 
			   			(SELECT Description FROM [TCD].Dryers D	 WHERE D.DryerGroupId = M.GroupId AND D.Id = M.MachineCompartment  AND D.Is_Deleted = 0)
				WHEN (SELECT DISTINCT GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.Id = M.GroupId ) = 4 THEN 
			   			(SELECT Name FROM [TCD].Finnishers F WHERE F.FinnisherGroupId = M.GroupId AND F.FinnisherId = M.MachineCompartment  AND F.Is_Deleted = 0)
				WHEN (SELECT DISTINCT GT.GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.Id = M.GroupId ) = 5 THEN 
			   			(SELECT WE.DeviceName FROM TCD.WaterAndEnergy WE WHERE M.GroupId = @WaterandEnergyGroupId AND WE.DeviceNumber = M.MachineCompartment  AND WE.Is_deleted = 0)
                 END AS MachinecompartmentName , 
                   CC.ControllerId , 
                   CC.Name AS ControllerName,
			    CC.ControllerModelId,
			    CM.RegionId AS ControllerRegionId,	
			    CT.Id AS ControllerTypeId,
			    CT.Name AS ControllerType,			     
                   CASE M.Parent
                   WHEN NULL THEN NULL
                       ELSE( 
                             SELECT MeterId
                               FROM [TCD].meter MM
                               WHERE MM.EcolabAccountNumber = @EcolabAccountNumber AND MM.MeterID IN( 
                             SELECT parent
                               FROM [TCD].Meter
                               WHERE parent
                                     = 
                                     M.parent
									 AND M.EcolabAccountNumber = @EcolabAccountNumber
                                                  )
                           )
                   END AS ParentId , 
                   CASE M.Parent
                   WHEN NULL THEN NULL
                       ELSE( 
                             SELECT Description
                               FROM [TCD].meter MM
                               WHERE MM.EcolabAccountNumber = @EcolabAccountNumber AND MM.MeterID IN(
                             SELECT parent
                               FROM [TCD].Meter
                               WHERE parent
                                     = 
                                     M.parent
									 AND M.EcolabAccountNumber = @EcolabAccountNumber
                                                  )
                           )
                   END AS Parent , 
                   M.Calibration , 
									 MT.TagAddress,
                   --M.DigitalInputNumber , 
                   M.AllowManualentry , 
                   ( 
									 CASE WHEN M.groupID IS NULL AND M.IsPlant = 1
									 THEN 1
									 ELSE
                     (SELECT G.Id
                       FROM [TCD].MachineGroup G
                       WHERE G.Id
                             = 
                             M.groupID AND COALESCE(G.EcolabAccountNumber, @EcolabAccountNumber ) = @EcolabAccountNumber)
										END
                   )AS UtilityId , 
                   ( 
									 CASE WHEN (M.groupID IS NULL AND M.MachineCompartment IS NULL AND M.IsPlant = 1) THEN 'Plant'
									 ELSE
                     (SELECT GroupDescription
                       FROM [TCD].MachineGroup G
                       WHERE G.Id
                             = 
                             M.groupID AND COALESCE(G.EcolabAccountNumber, @EcolabAccountNumber ) = @EcolabAccountNumber) END
                   )AS UtilityLocation,
									 M.LastSyncTime,
									 M.LastModifiedTime,
									 M.MyServiceMeterGuid
              FROM [TCD].Meter M
							LEFT JOIN [TCD].ConduitController CC
							ON CC.ControllerId = M.ControllerID
							LEFT JOIN [TCD].ControllerModel CM 
							ON CM.Id = CC.ControllerModelId
							LEFT JOIN [TCD].ModuleTags MT
							ON MT.ModuleID = M.MeterId
							AND MT.ModuleTypeId = 2 
							AND MT.Active = 1
							LEFT JOIN [TCD].ControllerType CT
							ON CT.Id = CC.ControllerTypeId
              WHERE Is_Deleted = 0 AND M.EcolabAccountNumber = @EcolabAccountNumber
							AND (M.MeterId = @MeterId OR @MeterId IS NULL);
        END;
    ELSE
        BEGIN
				SELECT M.MeterId , 
                   M.Description , 
                   M.UtilityType , 
                   ( 
                     SELECT Name
                       FROM [TCD].UtilityMaster rm
                       WHERE rm.ResourceId
                             = 
                             M.UtilityType
                   )AS MeterTypeName , 
                   M.EcolabAccountNumber , 
                   M.MaxValueLimit , 
                   M.MeterTickUnit , 
                   M.UsageFactor , 
									 CASE WHEN M.Machinecompartment IS NULL
											THEN CASE WHEN M.IsPress = 1 THEN 1 ELSE 0 END
										ELSE M.Machinecompartment 
										END AS Machinecompartment , 
                   CASE
									 WHEN M.MachineCompartment IS NULL AND (M.IsPress = 0 OR M.IsPress IS NULL) THEN 'ALL'
                   WHEN( SELECT DISTINCT Istunnel FROM [TCD].machinesetup S WHERE S.groupId = M.GroupId AND S.EcoalabAccountNumber = @EcolabAccountNumber)= 1 THEN 
									 CASE
									 WHEN M.MachineCompartment IS NULL AND M.IsPress = 1 THEN 'Press'									 
									 ELSE 'Compartment' + CAST( M.Machinecompartment AS varchar( 100))
									 END
                   WHEN( SELECT DISTINCT Istunnel FROM [TCD].machinesetup S WHERE S.groupId = M.GroupId)= 0 THEN 
									 (SELECT MachineName FROM [TCD].MachineSetup S WHERE S.GroupId = M.GroupId AND S.WasherId = M.MachineCompartment)
			    WHEN (SELECT DISTINCT GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.Id = M.GroupId ) = 3 THEN 
			    (SELECT Description FROM [TCD].Dryers WHERE DryerGroupId = M.GroupId AND DryerNo = M.MachineCompartment)
			        WHEN (SELECT MM.MachineCompartment FROM [TCD].Meter MM WHERE MM.GroupId = M.GroupId) = 1 THEN 'Press'
                   END AS MachinecompartmentName , 
                   CC.ControllerId , 
                   CC.Name AS ControllerName,
									 CC.ControllerModelId,
									 CM.RegionId AS ControllerRegionId,	
									 CT.Id AS ControllerTypeId,
									 CT.Name AS ControllerType,
                   CASE M.Parent
                   WHEN NULL THEN NULL
                       ELSE( 
                             SELECT MeterId
                               FROM [TCD].meter MM
                               WHERE MM.EcolabAccountNumber = @EcolabAccountNumber AND MM.MeterID IN( 
                             SELECT parent
                               FROM [TCD].Meter
                               WHERE parent
                                     = 
                                     M.parent
									 AND M.EcolabAccountNumber = @EcolabAccountNumber
                                                  )
                           )
                   END AS ParentId , 
                   CASE M.Parent
                   WHEN NULL THEN NULL
                       ELSE( 
                             SELECT Description
                               FROM [TCD].meter MM
                               WHERE MM.EcolabAccountNumber = @EcolabAccountNumber AND MM.MeterID IN( 
                             SELECT parent
                               FROM [TCD].Meter
                               WHERE parent
                                     = 
                                     M.parent
									 AND M.EcolabAccountNumber = @EcolabAccountNumber
                                                  )
                           )
                   END AS Parent , 
                   M.Calibration , 
									 MT.TagAddress,
                   --M.DigitalInputNumber , 
                   M.AllowManualentry , 
                   ( 
									 CASE WHEN M.groupID IS NULL AND M.IsPlant = 1
									 THEN 1
									 ELSE
                     (SELECT G.Id
                       FROM [TCD].MachineGroup G
                       WHERE G.Id
                             = 
                             M.groupID
							 AND G.EcolabAccountNumber = @EcolabAccountNumber)
										END
                   )AS UtilityId , 
                   ( 
									 CASE WHEN (M.groupID IS NULL AND M.MachineCompartment IS NULL AND M.IsPlant = 1) THEN 'Plant'
									 ELSE
                     (SELECT GroupDescription
                       FROM [TCD].MachineGroup G
                       WHERE G.Id
                             = 
                             M.groupID
							 AND G.EcolabAccountNumber = @EcolabAccountNumber) END
                   )AS UtilityLocation,
									 M.LastSyncTime,
									 M.LastModifiedTime,
									 M.MyServiceMeterGuid
              FROM [TCD].Meter M
							LEFT JOIN [TCD].ConduitController CC
							ON CC.ControllerId = M.ControllerID
							LEFT JOIN [TCD].ControllerModel CM 
							ON CM.Id = CC.ControllerModelId							
							LEFT JOIN [TCD].ModuleTags MT
							ON MT.ModuleID = M.MeterId
							AND MT.ModuleTypeId = 1
							LEFT JOIN [TCD].ControllerType CT
							ON CT.Id = CC.ControllerTypeId
              WHERE 1 = 2 AND M.EcolabAccountNumber = @EcolabAccountNumber;
        END;
END;
GO

IF EXISTS (SELECT * 
			   FROM   sys.objects 
			   WHERE  object_id = Object_id(N'[TCD].[GetAlarmCodesandNumbers]') 
					  AND type IN ( N'P', N'PC' )) 
  DROP PROCEDURE [TCD].[GetAlarmCodesandNumbers]
GO

/****** Object:  StoredProcedure [TCD].[GetAlarmCodesandNumbers]    Script Date: 16-03-2016 21:30:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [TCD].[GetAlarmCodesandNumbers](@AlarmMachineMappingIds VARCHAR(MAX)
                                                ,@IsBatchEjectCondition BIT
                                                ,@washerid INT
                                                ,@OutputIsTunnel BIT OUTPUT
                                                ,@OutputControllerId INT OUTPUT)
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE
       @sql NVARCHAR(500)
    SET @sql=''
    IF(@IsBatchEjectCondition=1)
        BEGIN
            SET @sql='SELECT AlarmNumber FROM tcd.BatchEjectCondition AS bec WHERE bec.BatchEjectConditionId IN ('+@AlarmMachineMappingIds+')'
        END
    ELSE
        BEGIN
            SET @sql='SELECT AlarmCode FROM tcd.AlarmGroupMsterVsControllerModelType agmvcmt WHERE agmvcmt.AlarmGroupMsterVsControllerModelTypeId in ('+@AlarmMachineMappingIds+')'
        END
    EXECUTE sp_executesql
            @sql


    SELECT
           @OutputIsTunnel=ms.IsTunnel,
           @OutputControllerId=ms.ControllerId
    FROM tcd.MachineSetup AS ms
    WHERE washerid=@washerid
      AND ms.IsDeleted=0


END;
GO
IF NOT EXISTS(SELECT * FROM sys.columns 
            WHERE Name = N'EcolabAccountNumber' AND Object_ID = Object_ID(N'[TCD].[WasherDosingAnalogControllerMapping]') )
ALTER TABLE [TCD].[WasherDosingAnalogControllerMapping]
ADD EcolabAccountNumber NVARCHAR(25)
GO
IF EXISTS (SELECT * 
			   FROM   sys.objects 
			   WHERE  object_id = Object_id(N'[TCD].[GetWasherDosingAnalogControl]') 
					  AND type IN ( N'P', N'PC' )) 
  DROP PROCEDURE [TCD].[GetWasherDosingAnalogControl]
GO

/****** Object:  StoredProcedure [TCD].[GetWasherDosingAnalogControl]   ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[GetWasherDosingAnalogControl]   
     
    @WasherProgramSetupId       INT      
   ,@StepNumber				INT
   ,@EcoLabAccountNumber     NVARCHAR(1000)      
AS    
BEGIN   
DECLARE  @WasherDosingSetupId INT;
SET @WasherDosingSetupId = (SELECT WasherDosingSetupId FROM [TCD].WasherDosingSetup 
WHERE  WasherProgramSetupId= @WasherProgramSetupId AND StepNumber=@StepNumber)
SELECT     
cast(ACM.WasherDosingAnalogControllerMappingId AS INT) ,    
cast(ACM.WasherDosingSetupId AS INT),    
CAST(ACM.SetPointTemperature AS INT),    
CAST(ACM.MinimumTime AS INT),    
CAST(ACM.StartDelay AS INT),    
CAST(ACM.AcceptedDelay AS INT),    
CAST(ACM.ProductId AS INT),    
ACM.PhControlDuringDrain,    
CAST(ACM.PhDelayTime AS INT),    
CAST(ACM.PhMeasuringTime AS INT),    
ACM.PhMininum,    
ACM.PhMaximum,    
CAST(WDS.StepNumber AS INT)    
 FROM [TCD].WasherDosingAnalogControllerMapping AS ACM    
 JOIN [TCD].WasherDosingSetup AS WDS ON WDS.WasherDosingSetupId = ACM.WasherDosingSetupId    
 WHERE ACM.EcoLabAccountNumber = @EcoLabAccountNumber    
 AND ACM.WasherDosingSetupId = @WasherDosingSetupId    
 END    
     
    
     
  
   
  
   

GO
IF EXISTS (SELECT * 
			   FROM   sys.objects 
			   WHERE  object_id = Object_id(N'[TCD].[SaveConventionalWasherAnalogControl]') 
					  AND type IN ( N'P', N'PC' )) 
  DROP PROCEDURE [TCD].[SaveConventionalWasherAnalogControl]
GO

/****** Object:  StoredProcedure [TCD].[GetAlarmCodesandNumbers]  ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
    
CREATE PROCEDURE [TCD].SaveConventionalWasherAnalogControl    
 @PlantId       INT      
    , @WasherDosingSetupId     INT    
    , @SetPointTemperature      SMALLINT    
    , @MinimumTime      SMALLINT      
    , @StartDelay      SMALLINT      
    , @AcceptedDelay     SMALLINT                
    , @ProductId         INT      
    , @PhControlDuringDrain  BIT    
    , @PhDelayTime     SMALLINT    
    , @PhMeasuringTime SMALLINT    
    , @PhMininum   DECIMAL(18,2)    
    , @PhMaximum   DECIMAL(18,2)    
    , @UserId INT  
    , @EcolabAccountNumber NVARCHAR(25)    
AS      
BEGIN    
IF NOT EXISTS(SELECT * FROM TCD.WasherDosingAnalogControllerMapping     
 WHERE EcolabAccountNumber=@EcolabAccountNumber    
  AND WasherDosingSetupId=@WasherDosingSetupId)    
BEGIN    
INSERT INTO TCD.WasherDosingAnalogControllerMapping     
VALUES (@PlantId,@WasherDosingSetupId,@SetPointTemperature,@MinimumTime,@StartDelay,@AcceptedDelay,@ProductId,    
@PhControlDuringDrain,@PhDelayTime,@PhMeasuringTime,@PhMininum,@PhMaximum,@UserId,GetUtcDate(),@EcolabAccountNumber)    
END    
ELSE    
BEGIN    
UPDATE TCD.WasherDosingAnalogControllerMapping     
SET SetPointTemperature =@SetPointTemperature,    
MinimumTime = @MinimumTime,    
StartDelay = @StartDelay,    
AcceptedDelay = @AcceptedDelay,    
ProductId = @ProductId,    
PhControlDuringDrain = @PhControlDuringDrain,    
PhDelayTime = @PhDelayTime,    
PhMeasuringTime = @PhMeasuringTime,    
PhMininum = @PhMininum,    
PhMaximum = @PhMaximum    

WHERE EcolabAccountNumber=@EcolabAccountNumber    
  AND WasherDosingSetupId=@WasherDosingSetupId    
END    
END    
GO


IF EXISTS (SELECT * 
			   FROM   sys.objects 
			   WHERE  object_id = Object_id(N'[TCD].[GetWasherGroupFormulaWashSteps]') 
					  AND type IN ( N'P', N'PC' )) 
  DROP PROCEDURE [TCD].[GetWasherGroupFormulaWashSteps]
GO

/****** Object:  StoredProcedure [TCD].[GetAlarmCodesandNumbers]  ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_GetWasherGroupFormulaWashSteps]                                        

Purpose:				To get the washer group formula wash steps.

Parameters:				@EcoLabAccountNumber - holds the ecolab account number.
						@WasherGroupId	- holds the washer group id.
						@ProgramSetupId - holds the program setup id.
						@DosingSetupId - holds the dosing setup id.
																						
###################################################################################################                                           
*/
CREATE	PROCEDURE	[TCD].[GetWasherGroupFormulaWashSteps]
					@EcoLabAccountNumber					NVARCHAR(1000)
				,	@WasherGroupId							INT
				,	@ProgramSetupId							INT
				,	@DosingSetupId							INT				=	NULL			--Null for LIST
				,   @Is_Deleted								BIT			    =	'FALSE'
AS
BEGIN

SET	NOCOUNT	ON

DECLARE
		@ControllerID							INT					=			NULL,
		@WasherGrIdForSensor INT = @WasherGroupId;

	SELECT	@WasherGroupId					=			WasherGroupId
		,	@ControllerID					=			ControllerID
	FROM [TCD].WasherProgramSetup 
	WHERE WasherProgramSetupId = @ProgramSetupId
	AND   EcolabAccountNumber = @EcoLabAccountNumber

	
				SELECT
				[WasherDosingSetupId] AS DosingSetupId
				,WPS.[ProgramNumber]
				,WPS.[WasherGroupId]
				,[StepNumber]
				,WS.[StepId] AS WashOperationId
				,WS.[StepName] AS WashOperation
				,[StepRunTime] AS RunTime
				,[Temperature]
				,[WaterType]
				,[WaterLevel]
				,DD.[DrainDestinationId] AS DrainDestinationId
				,DD.[DrainDestinationName] AS DrainDestination
				,[pHLevel]
				,[Note]
				,WS.MyServiceWshOpId
				,ISNULL((SELECT wt.MyServiceUtilId FROM TCD.WaterType wt WHERE  WDS.WaterType=WT.Id),NULL)
				,DD.DrainDestinationId	AS	MyServiceDrainTypId
				,WDS.Is_Deleted		As	IsDelete
				,WDS.MyserviceCustFrmulaStpGuid
				,WDS.MyServiceLastSynchTime
				,WDS.WasherProgramSetupId
				,(SELECT STUFF((SELECT ',' + CAST(S.SensorType AS VARCHAR(2))  
     FROM TCD.Sensor S WHERE  S.GroupId = @WasherGrIdForSensor   
     AND S.EcolabAccountNumber = @EcoLabAccountNumber   
     AND S.Is_deleted = 0 GROUP BY S.SensorType  
     FOR XML PATH('')) ,1,1,'')) AS SensorAttached  
			FROM	[TCD].[WasherDosingSetup]			WDS
			INNER JOIN [TCD].[WasherProgramSetup] WPS 
				ON WPS.[WasherProgramSetupId] = WDS.[WasherProgramSetupId]
			LEFT JOIN	[TCD].WashStep				WS
				ON	WS.StepId					=			WDS.StepTypeId
			LEFT JOIN	[TCD].DrainDestination		DD
				ON	DD.DrainDestinationId		=			WDS.DrainDestinationId
			WHERE	
				WDS.WasherProgramSetupId		=			@ProgramSetupId
				AND WDS.EcolabAccountNumber		=			@EcoLabAccountNumber
				AND	(CASE WHEN @WasherGroupId IS NOT NULL 
						  THEN WDS.GroupId
						  ELSE WDS.ControllerID
					END)									= (CASE WHEN @WasherGroupId IS NOT NULL 
																	THEN @WasherGroupId
																	ELSE @ControllerID
																	END)
				AND	WDS.WasherDosingSetupId		=			ISNULL(@DosingSetupId, WDS.WasherDosingSetupId)
				AND (WDS.Is_Deleted				=			'FALSE' OR WDS.Is_Deleted = @Is_Deleted)
SET	NOCOUNT	OFF

END

GO

----------------------TCD.METER Table ALTER Scripts--------------------------
IF NOT EXISTS(SELECT
					  *
				  FROM sys.key_constraints
				  WHERE parent_object_id = OBJECT_ID(N'[TCD].[WaterType]')
					AND type = N'PK')
	BEGIN
		ALTER TABLE TCD.WaterType
				
		ADD
				CONSTRAINT PK_WaterType_Id PRIMARY KEY(Id)
	END
GO

IF NOT EXISTS (SELECT * FROM SYS.columns c WHERE C.name = 'CounterNum' AND c.object_id = object_id('[TCD].[Meter]'))
BEGIN
	ALTER TABLE TCD.METER ADD CounterNum INT
END

IF NOT EXISTS (SELECT * FROM SYS.columns c WHERE C.name = 'CounterUsage' AND c.object_id = object_id('[TCD].[Meter]'))
BEGIN
	ALTER TABLE TCD.METER ADD CounterUsage	BIT DEFAULT 0
END

IF NOT EXISTS (SELECT * FROM SYS.columns c WHERE C.name = 'RunningTimeUsage' AND c.object_id = object_id('[TCD].[Meter]'))
BEGIN
	ALTER TABLE TCD.METER ADD RunningTimeUsage	BIT DEFAULT 0
END

IF NOT EXISTS (SELECT * FROM SYS.columns c WHERE C.name = 'CounterAlarmValue' AND c.object_id = object_id('[TCD].[Meter]'))
BEGIN
	ALTER TABLE TCD.METER ADD CounterAlarmValue	INT
END

IF NOT EXISTS (SELECT * FROM SYS.columns c WHERE C.name = 'WaterType' AND c.object_id = object_id('[TCD].[Meter]'))
BEGIN
	ALTER TABLE TCD.METER ADD WaterType	INT CONSTRAINT [FK_Meter_WaterType] FOREIGN KEY (WaterType) REFERENCES TCD.WATERTYPE(Id)
END

IF NOT EXISTS (SELECT * FROM SYS.columns c WHERE C.name = 'WaterTypeFromFormulaSetup' AND c.object_id = object_id('[TCD].[Meter]'))
BEGIN
	ALTER TABLE TCD.METER ADD WaterTypeFromFormulaSetup	BIT DEFAULT 0
END

IF NOT EXISTS (SELECT * FROM SYS.columns c WHERE C.name = 'RunningTimeAlarmValue' AND c.object_id = object_id('[TCD].[Meter]'))
BEGIN
	ALTER TABLE TCD.METER ADD RunningTimeAlarmValue	INT
END

--IF NOT EXISTS (SELECT * FROM SYS.columns c WHERE C.name = 'ExternalCounter' AND c.object_id = object_id('[TCD].[Meter]'))
--BEGIN
--	ALTER TABLE TCD.METER ADD ExternalCounter	INT
--END
-------------------TCD.Sensor Alter scripts------------------

IF NOT EXISTS (SELECT * FROM SYS.columns c WHERE C.name = 'SensorNum' AND c.object_id = object_id('[TCD].[Sensor]'))
BEGIN
	ALTER TABLE TCD.Sensor ADD SensorNum	INT
END

IF NOT EXISTS (SELECT * FROM SYS.columns c WHERE C.name = 'AlarmEnable' AND c.object_id = object_id('[TCD].[Sensor]'))
BEGIN
	ALTER TABLE TCD.Sensor ADD AlarmEnable		BIT DEFAULT 0
END

IF NOT EXISTS (SELECT * FROM SYS.columns c WHERE C.name = 'MinimumAlarmValue' AND c.object_id = object_id('[TCD].[Sensor]'))
BEGIN
	ALTER TABLE TCD.Sensor ADD MinimumAlarmValue	INT
END

IF NOT EXISTS (SELECT * FROM SYS.columns c WHERE C.name = 'MaximumAlarmValue' AND c.object_id = object_id('[TCD].[Sensor]'))
BEGIN
	ALTER TABLE TCD.Sensor ADD MaximumAlarmValue	INT
END

--IF NOT EXISTS (SELECT * FROM SYS.columns c WHERE C.name = 'ExternalSensor' AND c.object_id = object_id('[TCD].[Sensor]'))
--BEGIN
--	ALTER TABLE TCD.Sensor ADD ExternalSensor	INT
--EN
---------------------------------------------------------------
IF EXISTS (SELECT * 
			   FROM   sys.objects 
			   WHERE  object_id = Object_id(N'[TCD].[GetPlantControllers]') 
					  AND type IN ( N'P', N'PC' )) 
  DROP PROCEDURE [TCD].[GetPlantControllers]
GO
CREATE PROCEDURE TCD.GetPlantControllers (@LocationId INT
							    , @MachineId INT
							    , @EcolabAccountNumber NVARCHAR(25))
AS 
  BEGIN 
    SET NOCOUNT ON;
    IF @LocationId	 IS NULL
    OR @MachineId	IS  NULL
	   BEGIN
		  SELECT DISTINCT CC.ControllerID,
			    CC.Name,
			    CC.ControllerModelId	,
			    CM.Name AS ControllerModelName ,
			    CM.RegionId,
			    CC.ControllerTypeId,
			    CT.Name AS ControllerType,
				 CAST(ISNULL(csd.Value,0) AS BIT) AS ISWaterEnergyLogSel
		    FROM TCD.ConduitController CC
			    INNER JOIN
			    TCD.ControllerModel CM ON CC.ControllerModelId = CM.Id
			    LEFT JOIN
			    TCD.ControllerType CT ON CT.Id = CC.ControllerTypeId
				LEFT JOIN TCD.ControllerSetupData csd 
				ON csd.ControllerId = CC.ControllerID AND csd.FieldId = 473 AND csd.FieldGroupId = 20 AND csd.EcolabAccountNumber = CC.EcoalabAccountNumber
		    WHERE CC.IsDeleted = 0
			 AND CC.EcoalabAccountNumber = @EcolabAccountNumber
			 AND CC.ControllerModelId = 5
			 AND CC.ControllerId > 0;
	   END;
    ELSE
	   BEGIN
		  SELECT DISTINCT CC.ControllerID,
			    CC.Name,
			    CC.ControllerModelId	,
			    CM.Name AS ControllerModelName ,
			    CM.RegionId,
			    CC.ControllerTypeId,
			    CT.Name AS ControllerType,
				 CAST(ISNULL(csd.Value,0) AS BIT) AS ISWaterEnergyLogSel
		    FROM TCD.ConduitController CC
			    INNER JOIN
			    TCD.ControllerModel CM ON CC.ControllerModelId = CM.Id
			    LEFT JOIN
			    TCD.ControllerType CT ON CT.Id = CC.ControllerTypeId
			    LEFT JOIN
			    tcd.MachineSetup MS ON ms.ControllerId = CC.ControllerId AND MS.EcoalabAccountNumber = CC.EcoalabAccountNumber
				LEFT JOIN TCD.ControllerSetupData csd 
				ON csd.ControllerId = CC.ControllerID AND csd.FieldId = 473 AND csd.FieldGroupId = 20 AND csd.EcolabAccountNumber = CC.EcoalabAccountNumber
		    WHERE CC.IsDeleted = 0
			 AND CC.EcoalabAccountNumber = @EcolabAccountNumber
			 AND (CC.ControllerModelId = 5
			   OR ms.GroupId = @LocationId
			   --OR @LocationId = 1
			  AND (Ms.WasherId = CASE
									WHEN MS.IsTunnel = 0
									THEN  @MachineId
									    ELSE (SELECT WasherId FROM tcd.MachineSetup where GroupID = @LocationId)
	END
			    OR @MachineId = 0))
				AND CC.ControllerId > 0
				ORDER BY CC.ControllerModelId DESC;
	   END;
    SET NOCOUNT OFF;
END;
GO

IF EXISTS (SELECT * 
			   FROM   sys.objects 
			   WHERE  object_id = Object_id(N'[TCD].[GetPlantMeterDetails]') 
					  AND type IN ( N'P', N'PC' )) 
  DROP PROCEDURE [TCD].[GetPlantMeterDetails]
GO

CREATE PROCEDURE [TCD].[GetPlantMeterDetails](@MeterId INT = NULL, @EcolabAccountNumber NVARCHAR(25))
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE
       @EmptyHeader varchar( 100
                           );

    IF EXISTS( SELECT 1
                 FROM [TCD].ConduitController WHERE EcoalabAccountNumber = @EcolabAccountNumber
             )
        BEGIN
		    DECLARE @WaterandEnergyGroupId  INT = (SELECT TOP (1) MG.Id
									   FROM TCD.MachineGroup MG
										    INNER JOIN
										    TCD.MachineGroupType MGT ON MGT.Id = MG.GroupTypeId
									   WHERE MGT.Id = 5	  );
           SELECT M.MeterId , 
                  M.Description , 
                  M.UtilityType , 
                  CASE M.UtilityType WHEN 12 THEN 'Pieces'
				  ELSE (SELECT Name FROM [TCD].UtilityMaster rm WHERE rm.ResourceId = M.UtilityType )
				  END AS MeterTypeName , 
                  M.EcolabAccountNumber , 
                  M.MaxValueLimit , 
                  M.MeterTickUnit , 
                  M.UsageFactor , 
			   CASE WHEN M.Machinecompartment IS NULL  THEN 
					CASE  WHEN M.IsPress = 1 THEN 1
						WHEN M.GroupId IS NULL AND (M.IsPress = 0 OR M.IsPress IS NULL) AND (M.IsPlant = 0 OR M.IsPlant IS NULL) THEN NULL 
						ELSE 0 END 
					ELSE M.Machinecompartment 
				END AS Machinecompartment ,

                CASE WHEN M.MachineCompartment IS NULL AND (M.IsPress = 0 OR M.IsPress IS NULL) THEN
					CASE	WHEN M.GroupId IS NULL AND (M.IsPlant = 0 OR M.IsPlant IS NULL) THEN NULL	ELSE 'ALL' END	 
				WHEN( SELECT DISTINCT Istunnel FROM [TCD].machinesetup S WHERE S.groupId = M.GroupId AND S.IsDeleted = 0 AND S.EcoalabAccountNumber = @EcolabAccountNumber)= 1 THEN 
					CASE WHEN M.MachineCompartment IS NULL AND M.IsPress = 1 THEN 'Press' ELSE 'Compartment' + CAST( M.Machinecompartment AS varchar( 100)) END
				WHEN( SELECT DISTINCT Istunnel FROM [TCD].MachineSetup S WHERE S.groupId = M.GroupId  AND S.IsDeleted = 0)= 0 THEN 
			   			(SELECT CAST (WS.PlantWasherNumber AS nvarchar) +':' + S.MachineName FROM [TCD].MachineSetup S INNER JOIN TCD.Washer WS ON S.WasherId = WS.WasherId WHERE S.GroupId = M.GroupId AND S.WasherId	 = M.MachineCompartment AND S.IsDeleted = 0)
				WHEN (SELECT DISTINCT GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.Id = M.GroupId ) = 3 THEN 
			   			(SELECT Description FROM [TCD].Dryers D	 WHERE D.DryerGroupId = M.GroupId AND D.Id = M.MachineCompartment  AND D.Is_Deleted = 0)
				WHEN (SELECT DISTINCT GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.Id = M.GroupId ) = 4 THEN 
			   			(SELECT Name FROM [TCD].Finnishers F WHERE F.FinnisherGroupId = M.GroupId AND F.FinnisherId = M.MachineCompartment  AND F.Is_Deleted = 0)
				WHEN (SELECT DISTINCT GT.GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.Id = M.GroupId ) = 5 THEN 
			   			(SELECT WE.DeviceName FROM TCD.WaterAndEnergy WE WHERE M.GroupId = @WaterandEnergyGroupId AND WE.DeviceNumber = M.MachineCompartment  AND WE.Is_deleted = 0)
                 END AS MachinecompartmentName , 
                   CC.ControllerId , 
                   CC.Name AS ControllerName,
			    CC.ControllerModelId,
			    CM.RegionId AS ControllerRegionId,	
			    CT.Id AS ControllerTypeId,
			    CT.Name AS ControllerType,			     
                   CASE M.Parent
                   WHEN NULL THEN NULL
                       ELSE( 
                             SELECT MeterId
                               FROM [TCD].meter MM
                               WHERE MM.EcolabAccountNumber = @EcolabAccountNumber AND MM.MeterID IN( 
                             SELECT parent
                               FROM [TCD].Meter
                               WHERE parent
                                     = 
                                     M.parent
									 AND M.EcolabAccountNumber = @EcolabAccountNumber
                                                  )
                           )
                   END AS ParentId , 
                   CASE M.Parent
                   WHEN NULL THEN NULL
                       ELSE( 
                             SELECT Description
                               FROM [TCD].meter MM
                               WHERE MM.EcolabAccountNumber = @EcolabAccountNumber AND MM.MeterID IN(
                             SELECT parent
                               FROM [TCD].Meter
                               WHERE parent
                                     = 
                                     M.parent
									 AND M.EcolabAccountNumber = @EcolabAccountNumber
                                                  )
                           )
                   END AS Parent , 
                   M.Calibration , 
									 MT.TagAddress,
                   --M.DigitalInputNumber , 
                   M.AllowManualentry , 
                   ( 
									 CASE WHEN M.groupID IS NULL AND M.IsPlant = 1
									 THEN 1
									 ELSE
                     (SELECT G.Id
                       FROM [TCD].MachineGroup G
                       WHERE G.Id
                             = 
                             M.groupID AND COALESCE(G.EcolabAccountNumber, @EcolabAccountNumber ) = @EcolabAccountNumber)
										END
                   )AS UtilityId , 
                   ( 
									 CASE WHEN (M.groupID IS NULL AND M.MachineCompartment IS NULL AND M.IsPlant = 1) THEN 'Plant'
									 ELSE
                     (SELECT GroupDescription
                       FROM [TCD].MachineGroup G
                       WHERE G.Id
                             = 
                             M.groupID AND COALESCE(G.EcolabAccountNumber, @EcolabAccountNumber ) = @EcolabAccountNumber) END
                   )AS UtilityLocation,
									 M.LastSyncTime,
									 M.LastModifiedTime,
									 M.MyServiceMeterGuid,
									 M.CounterNum,
									 M.CounterUsage,
									 M.RunningTimeUsage,
									 M.CounterAlarmValue,
									 M.WaterType,
									 M.WaterTypeFromFormulaSetup,
									 M.RunningTimeAlarmValue,
									 CAST(ISNULL(csd.Value,0) AS BIT) AS ISWaterEnergyLogSel,
									 M.DigitalInputNumber
              FROM [TCD].Meter M
							LEFT JOIN [TCD].ConduitController CC
							ON CC.ControllerId = M.ControllerID
							LEFT JOIN [TCD].ControllerModel CM 
							ON CM.Id = CC.ControllerModelId
							LEFT JOIN [TCD].ModuleTags MT
							ON MT.ModuleID = M.MeterId
							AND MT.ModuleTypeId = 2 
							AND MT.Active = 1
							LEFT JOIN [TCD].ControllerType CT
							ON CT.Id = CC.ControllerTypeId
							LEFT JOIN TCD.ControllerSetupData csd 
							ON csd.ControllerId = M.ControllerID AND csd.FieldId = 473 AND csd.FieldGroupId = 20 AND csd.EcolabAccountNumber = M.EcolabAccountNumber
              WHERE Is_Deleted = 0 AND M.EcolabAccountNumber = @EcolabAccountNumber
							AND (M.MeterId = @MeterId OR @MeterId IS NULL);
        END;
    ELSE
        BEGIN
				SELECT M.MeterId , 
                   M.Description , 
                   M.UtilityType , 
                   ( 
                     SELECT Name
                       FROM [TCD].UtilityMaster rm
                       WHERE rm.ResourceId
                             = 
                             M.UtilityType
                   )AS MeterTypeName , 
                   M.EcolabAccountNumber , 
                   M.MaxValueLimit , 
                   M.MeterTickUnit , 
                   M.UsageFactor , 
									 CASE WHEN M.Machinecompartment IS NULL
											THEN CASE WHEN M.IsPress = 1 THEN 1 ELSE 0 END
										ELSE M.Machinecompartment 
										END AS Machinecompartment , 
                   CASE
									 WHEN M.MachineCompartment IS NULL AND (M.IsPress = 0 OR M.IsPress IS NULL) THEN 'ALL'
                   WHEN( SELECT DISTINCT Istunnel FROM [TCD].machinesetup S WHERE S.groupId = M.GroupId AND S.EcoalabAccountNumber = @EcolabAccountNumber)= 1 THEN 
									 CASE
									 WHEN M.MachineCompartment IS NULL AND M.IsPress = 1 THEN 'Press'									 
									 ELSE 'Compartment' + CAST( M.Machinecompartment AS varchar( 100))
									 END
                   WHEN( SELECT DISTINCT Istunnel FROM [TCD].machinesetup S WHERE S.groupId = M.GroupId)= 0 THEN 
									 (SELECT MachineName FROM [TCD].MachineSetup S WHERE S.GroupId = M.GroupId AND S.WasherId = M.MachineCompartment)
			    WHEN (SELECT DISTINCT GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.Id = M.GroupId ) = 3 THEN 
			    (SELECT Description FROM [TCD].Dryers WHERE DryerGroupId = M.GroupId AND DryerNo = M.MachineCompartment)
			        WHEN (SELECT MM.MachineCompartment FROM [TCD].Meter MM WHERE MM.GroupId = M.GroupId) = 1 THEN 'Press'
                   END AS MachinecompartmentName , 
                   CC.ControllerId , 
                   CC.Name AS ControllerName,
									 CC.ControllerModelId,
									 CM.RegionId AS ControllerRegionId,	
									 CT.Id AS ControllerTypeId,
									 CT.Name AS ControllerType,
                   CASE M.Parent
                   WHEN NULL THEN NULL
                       ELSE( 
                             SELECT MeterId
                               FROM [TCD].meter MM
                               WHERE MM.EcolabAccountNumber = @EcolabAccountNumber AND MM.MeterID IN( 
                             SELECT parent
                               FROM [TCD].Meter
                               WHERE parent
                                     = 
                                     M.parent
									 AND M.EcolabAccountNumber = @EcolabAccountNumber
                                                  )
                           )
                   END AS ParentId , 
                   CASE M.Parent
                   WHEN NULL THEN NULL
                       ELSE( 
                             SELECT Description
                               FROM [TCD].meter MM
                               WHERE MM.EcolabAccountNumber = @EcolabAccountNumber AND MM.MeterID IN( 
                             SELECT parent
                               FROM [TCD].Meter
                               WHERE parent
                                     = 
                                     M.parent
									 AND M.EcolabAccountNumber = @EcolabAccountNumber
                                                  )
                           )
                   END AS Parent , 
                   M.Calibration , 
									 MT.TagAddress,
                   --M.DigitalInputNumber , 
                   M.AllowManualentry , 
                   ( 
									 CASE WHEN M.groupID IS NULL AND M.IsPlant = 1
									 THEN 1
									 ELSE
                     (SELECT G.Id
                       FROM [TCD].MachineGroup G
                       WHERE G.Id
                             = 
                             M.groupID
							 AND G.EcolabAccountNumber = @EcolabAccountNumber)
										END
                   )AS UtilityId , 
                   ( 
									 CASE WHEN (M.groupID IS NULL AND M.MachineCompartment IS NULL AND M.IsPlant = 1) THEN 'Plant'
									 ELSE
                     (SELECT GroupDescription
                       FROM [TCD].MachineGroup G
                       WHERE G.Id
                             = 
                             M.groupID
							 AND G.EcolabAccountNumber = @EcolabAccountNumber) END
                   )AS UtilityLocation,
									 M.LastSyncTime,
									 M.LastModifiedTime,
									 M.MyServiceMeterGuid,
									 M.CounterNum,
									 M.CounterUsage,
									 M.RunningTimeUsage,
									 M.CounterAlarmValue,
									 M.WaterType,
									 M.WaterTypeFromFormulaSetup,
									 M.RunningTimeAlarmValue,
									 CAST(ISNULL(csd.Value,0) AS BIT) AS ISWaterEnergyLogSel,
									 M.DigitalInputNumber
              FROM [TCD].Meter M
							LEFT JOIN [TCD].ConduitController CC
							ON CC.ControllerId = M.ControllerID
							LEFT JOIN [TCD].ControllerModel CM 
							ON CM.Id = CC.ControllerModelId							
							LEFT JOIN [TCD].ModuleTags MT
							ON MT.ModuleID = M.MeterId
							AND MT.ModuleTypeId = 1
							LEFT JOIN [TCD].ControllerType CT
							ON CT.Id = CC.ControllerTypeId
							LEFT JOIN TCD.ControllerSetupData csd 
							ON csd.ControllerId = M.ControllerID AND csd.FieldId = 473 AND csd.FieldGroupId = 20 AND csd.EcolabAccountNumber = M.EcolabAccountNumber
              WHERE 1 = 2 AND M.EcolabAccountNumber = @EcolabAccountNumber;
        END;
END;
GO

IF EXISTS (SELECT * 
			   FROM   sys.objects 
			   WHERE  object_id = Object_id(N'[TCD].[GetPlantSensorDetails]') 
					  AND type IN ( N'P', N'PC' )) 
  DROP PROCEDURE [TCD].[GetPlantSensorDetails]
GO

CREATE PROCEDURE [TCD].[GetPlantSensorDetails] 
(
@SensorID int = NULL,
@EcolabAccountNumber nvarchar(25)
)  
AS   
  BEGIN   
      SET nocount ON;   

	  Declare @ControllerID int = NULL
	  Select @ControllerID = ControllerID from [TCD].Sensor where SensorId =  @SensorID
	  DECLARE @WaterandEnergyGroupId  INT = (SELECT TOP (1) MG.Id
									   FROM TCD.MachineGroup MG
										    INNER JOIN
										    TCD.MachineGroupType MGT ON MGT.Id = MG.GroupTypeId
									   WHERE MGT.Id = 5	  );
	  
	  	  If exists(Select 1 from [TCD].[ConduitController])
	  Begin
   Select  
S.SensorId,
S.Description,
S.SensorType,
(Select Name from [TCD].SensorTypemaster rm where rm.Resourceid = S.SensorType) as SensorTypeName,
S.EcolabAccountNumber,
					CASE 
						WHEN S.Machinecompartment IS NULL
							THEN 
								CASE 
									WHEN S.IsPress = 1 
										THEN 1 
										ELSE 0 END
ELSE S.Machinecompartment
END AS Machinecompartment,
CASE
			WHEN S.MachineCompartment IS NULL AND (S.IsPress = 0 OR S.IsPress IS NULL) THEN 'ALL'
			WHEN (SELECT DISTINCT  Istunnel FROM [TCD].machinesetup M WHERE M.groupId = S.GroupId )= 1 THEN CASE WHEN S.MachineCompartment IS NULL AND S.IsPress = 1 THEN 'Press' ELSE 'Compartment' + CAST( S.Machinecompartment AS varchar( 100)) END
      WHEN (SELECT DISTINCT Istunnel FROM [TCD].machinesetup M WHERE M.groupId = S.GroupId)= 0 THEN (SELECT CAST (WS.PlantWasherNumber AS nvarchar) + ':' + MachineName FROM [TCD].MachineSetup M INNER JOIN TCD.Washer WS ON M.WasherId = WS.WasherId WHERE M.GroupId = S.GroupId AND M.WasherId	 = S.MachineCompartment)
			WHEN (SELECT DISTINCT GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.Id = S.GroupId ) = 3 THEN (SELECT D.Description FROM [TCD].Dryers D WHERE D.DryerGroupId = S.GroupId AND D.Id = S.MachineCompartment)
			WHEN (SELECT DISTINCT GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.Id = S.GroupId ) = 4 THEN (SELECT F.Name FROM [TCD].Finnishers F WHERE F.FinnisherGroupId = S.GroupId AND F.FinnisherId = S.MachineCompartment)
			WHEN (SELECT DISTINCT GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.Id = S.GroupId ) = 5 THEN (SELECT DeviceName FROM TCD.WaterAndEnergy WE WHERE S.GroupId = @WaterandEnergyGroupId AND WE.DeviceNumber = S.MachineCompartment  AND WE.Is_deleted	= 0)
			WHEN (SELECT MM.MachineCompartment FROM [TCD].Meter MM WHERE MM.GroupId = S.GroupId) = 0 THEN 'Press'
      END AS MachinecompartmentName ,
			CC.ControllerID,	
			CC.Name AS ControllerName,
			CC.ControllerModelId,
			CM.RegionId AS ControllerRegionId,	
			CT.Id AS ControllerTypeId,
			CT.Name AS ControllerType,
			S.OutputType,
			S.ChemicalforChart,
			(Select DISTINCT p.Name from [TCD].productmaster P where P.productId = S.ChemicalforChart) as ChemicalforChartName,
			s.UOM,
			'S.UOMName' as UOMName,
			S.DashboardActualValue,
			( CASE WHEN S.groupID IS NULL AND S.IsPlant = 1
			   THEN 1
			   ELSE
                   (SELECT G.Id
                     FROM [TCD].MachineGroup G
                     WHERE G.Id
                           = 
                           S.groupID AND G.EcolabAccountNumber = @EcolabAccountNumber)
			   END )AS GroupId , 
			(	CASE WHEN (S.groupID IS NULL AND S.MachineCompartment IS NULL AND S.IsPlant = 1) THEN 'Plant'
				ELSE
                     (SELECT GroupDescription
                       FROM [TCD].MachineGroup G
                       WHERE G.Id
                             = 
                             S.groupID AND G.EcolabAccountNumber = @EcolabAccountNumber) END
                   )AS SensorLocation,
			(SELECT MTS.TagAddress FROM TCD.ModuleTags MTS WHERE MTS.TagType = 'Tag_MPLC' AND MTS.ModuleID = SensorId AND MTS.ModuleTypeId = 3 AND MTS.Active = 1) AS AnalogueInputNumber,
			S.Calibration4mA,
			S.Calibration20mA,
			(SELECT MTS.TagAddress FROM TCD.ModuleTags MTS WHERE MTS.TagType = 'Tag_SC4' AND MTS.ModuleID = SensorId AND MTS.ModuleTypeId = 3 AND MTS.Active = 1) AS CalibrationTag4,
					(SELECT MTS.TagAddress FROM TCD.ModuleTags MTS WHERE MTS.TagType = 'Tag_SC20' AND MTS.ModuleID = SensorId AND MTS.ModuleTypeId = 3 AND MTS.Active = 1) AS CalibrationTag20,
					S.LastSyncTime,
					S.LastModifiedTime,
					s.SensorNum,
					s.AlarmEnable,
					s.MinimumAlarmValue,
					s.MaximumAlarmValue,
					s.AnalogueInputNumber,
					CAST(ISNULL(csd.Value,0) AS BIT) AS ISWaterEnergyLogSel
			  from [TCD].Sensor S 
				LEFT JOIN [TCD].ConduitController CC
				ON CC.ControllerId = S.ControllerID
				LEFT JOIN [TCD].ControllerModel CM 
				ON CM.Id = CC.ControllerModelId
				LEFT JOIN [TCD].ControllerType CT
				ON CT.Id = CC.ControllerTypeId
				LEFT JOIN TCD.ControllerSetupData csd 
				ON csd.ControllerId = S.ControllerID AND csd.FieldId = 473 AND csd.FieldGroupId = 20 AND csd.EcolabAccountNumber = S.EcolabAccountNumber
			Where Is_Deleted = 0  
End

Else
   Select  
S.SensorId,
S.Description,
S.SensorType,
(Select Name from [TCD].SensorTypemaster rm where rm.Resourceid = S.SensorType) as SensorTypeName,
S.EcolabAccountNumber,
				CASE 
					WHEN S.Machinecompartment IS NULL
						THEN 
							CASE 
								WHEN S.IsPress = 1 
									THEN 1 
									ELSE 0 
								END
ELSE S.Machinecompartment
END AS Machinecompartment,
CASE
			WHEN S.MachineCompartment IS NULL AND (S.IsPress = 0 OR S.IsPress IS NULL) THEN 'ALL'
			WHEN (SELECT DISTINCT  Istunnel FROM [TCD].machinesetup M WHERE M.groupId = S.GroupId )= 1 THEN CASE WHEN S.MachineCompartment IS NULL AND S.IsPress = 1 THEN 'Press' ELSE 'Compartment' + CAST( S.Machinecompartment -1 AS varchar( 100)) END
      WHEN (SELECT DISTINCT Istunnel FROM [TCD].machinesetup M WHERE M.groupId = S.GroupId)= 0 THEN (SELECT MachineName FROM [TCD].MachineSetup M WHERE M.GroupId = S.GroupId AND M.WasherId = S.MachineCompartment)
			WHEN (SELECT DISTINCT GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.Id = S.GroupId ) = 3 THEN (SELECT Description FROM [TCD].Dryers WHERE DryerGroupId = S.GroupId AND DryerNo = S.MachineCompartment)
			WHEN (SELECT MM.MachineCompartment FROM [TCD].Meter MM WHERE MM.GroupId = S.GroupId) = 0 THEN 'Press'
      END AS MachinecompartmentName ,
			CC.ControllerID,	
			CC.Name AS ControllerName,
			CC.ControllerModelId,
			CM.RegionId AS ControllerRegionId,	
			CT.Id AS ControllerTypeId,
			CT.Name AS ControllerType,
			S.OutputType,
			S.ChemicalforChart,
			(Select DISTINCT p.Name from [TCD].productmaster P where P.productId = S.ChemicalforChart) as ChemicalforChartName,
			s.UOM,
			'S.UOMName' as UOMName,
			S.DashboardActualValue,
			S.GroupId,
			(select DISTINCT GroupDescription from [TCD].MachineGroup G where G.Id = s.GroupId) as SensorLocation,
			(SELECT MTS.TagAddress FROM TCD.ModuleTags MTS WHERE MTS.TagType = 'Tag_MPLC' AND ModuleID = SensorId) AS AnalogueInputNumber,
			S.Calibration4mA,
			S.Calibration20mA,
			(SELECT MTS.TagAddress FROM TCD.ModuleTags MTS WHERE MTS.TagType = 'Tag_SC4' AND ModuleID = SensorId) AS CalibrationTag4,
				(SELECT MTS.TagAddress FROM TCD.ModuleTags MTS WHERE MTS.TagType = 'Tag_SC20' AND ModuleID = SensorId) AS CalibrationTag20,
				S.LastSyncTime,
				S.LastModifiedTime,
				s.SensorNum,
				s.AlarmEnable,
				s.MinimumAlarmValue,
				s.MaximumAlarmValue,
				s.AnalogueInputNumber,
				CAST(ISNULL(csd.Value,0) AS BIT) AS ISWaterEnergyLogSel
			  from [TCD].Sensor S 
				LEFT JOIN [TCD].ConduitController CC
				ON CC.ControllerId = S.ControllerID
				LEFT JOIN [TCD].ControllerModel CM 
				ON CM.Id = CC.ControllerModelId
				LEFT JOIN [TCD].ControllerType CT
				ON CT.Id = CC.ControllerTypeId
				LEFT JOIN TCD.ControllerSetupData csd 
				ON csd.ControllerId = S.ControllerID AND csd.FieldId = 473 AND csd.FieldGroupId = 20 AND csd.EcolabAccountNumber = S.EcolabAccountNumber
				Where 1=2
SET NOCOUNT OFF;
END
GO

IF EXISTS (SELECT * 
			   FROM   sys.objects 
			   WHERE  object_id = Object_id(N'[TCD].[SavePlantMeterDetails]') 
					  AND type IN ( N'P', N'PC' )) 
  DROP PROCEDURE [TCD].[SavePlantMeterDetails]
GO

CREATE PROCEDURE [TCD].[SavePlantMeterDetails] (
@MeterNumber NVARCHAR(100) = NULL
, @EcolabAccountNumber NVARCHAR(25) = NULL
, @MeterName NVARCHAR(100) = NULL
, @Uitiliy NVARCHAR(100) = NULL
, @UtilityLocation NVARCHAR(100) = NULL
, @MachineCompartment NVARCHAR(100) = NULL
, @Parent NVARCHAR(100) = NULL
, @Calibration NVARCHAR(100) = NULL
, @UOFfoRCalibration NVARCHAR(100) = NULL
, @Usagefactor NVARCHAR(100) = NULL
, @ControllerID INT
, @ControllerModelID INT
, @DigitalInputNumber NVARCHAR(100) = NULL
, @AllowmanualEntry  NVARCHAR(100) = NULL
, @Meterrolloverpoint VARCHAR(100) = NULL
, @UserID INT
, @Scope VARCHAR(100) OUTPUT
, @OutputMeterId	INT = NULL	OUTPUT
, @LastModifiedTimestampAtCentral DATETIME = NULL
, @OutputLastModifiedTimestampAtLocal	DATETIME = NULL OUTPUT
, @WaterType INT
, @WaterTypeFromFormulaSetup BIT
, @CounterNum INT
, @CounterUsage BIT
, @RunningTimeUsage BIT
, @CounterAlarmValue INT
, @RunningTimeAlarmValue INT
, @ExternalCounter		INT
)
AS
BEGIN
    SET NOCOUNT ON;
    SET @Scope = '';
    DECLARE
	    @IsPlant BIT = NULL,
	    @IsPress BIT = NULL;
    DECLARE
	    @ReturnValue					INT = 0
	    ,@ErrorId						INT = 0
	    ,@ErrorMessage					NVARCHAR(4000) = N''
	    ,@CurrentUTCTime					DATETIME = GETUTCDATE();
    DECLARE
	    @OutputList						AS	TABLE		(
	    MeterId							INT
	    ,LastModifiedTimestamp			DATETIME
	    );
    SET		@OutputLastModifiedTimestampAtLocal = ISNULL(@OutputLastModifiedTimestampAtLocal, NULL);
    SET		@OutputMeterId = ISNULL(@OutputMeterId, NULL);

    /* Business vaidations for setingup the meters to controllers */

    IF	@LastModifiedTimestampAtCentral   IS NOT NULL
	 AND NOT	EXISTS	(	SELECT	1
						  FROM	TCD.Meter		M
						  WHERE	M.EcolabAccountNumber = @EcolabAccountNumber
							 AND M.MeterId = @MeterNumber
							 AND M.LastModifiedTime = @LastModifiedTimestampAtCentral
		)
	   BEGIN
		  SET			@ErrorId = 60000;
		  SET			@ErrorMessage = N''
									 +
									 CAST(@ErrorId AS NVARCHAR);
		  RAISERROR	(@ErrorMessage, 16, 1);
		  SET			@ReturnValue = -1;
		  RETURN
		  @ReturnValue;
	   END;

    -- Begin Defining Limits

    BEGIN
	   DECLARE
		   @UtilityLimit INT = NULL,
		   @WasherLimit INT = NULL,
		   @TunnelLimit INT = NULL,
		   @IStunnel INT = '',
		   @MeterNameLimit INT = NULL;

	 SELECT @MeterNameLimit = COUNT(1)
		FROM TCD.Meter 
		WHERE [Description] = @MeterName 
		AND EcolabAccountNumber = @EcolabAccountNumber
		AND Is_deleted = 0

	 
	   SELECT @UtilityLimit = COUNT(1)
		FROM TCD.meter
		WHERE GroupId = @UtilityLocation
		  AND UtilityType = @Uitiliy
		  AND ISNULL(MachineCompartment, 0) = @MachineCompartment
		  AND Is_deleted = 0
		  AND EcolabAccountNumber = @EcolabAccountNumber
		  AND ControllerID IN (
			 SELECT ControllerId
			   FROM TCD.ConduitController
			   WHERE ControllerId = @ControllerID
				AND EcoalabAccountNumber = @EcolabAccountNumber);
	   SELECT @WasherLimit = COUNT(1)
		FROM TCD.Meter M
			LEFT OUTER JOIN
			TCD.machinesetup MS ON M.GroupId = MS.groupId
						    AND M.MachineCompartment = MS.MachineInternalID
		WHERE M.UtilityType = 2
		  AND M.GroupID = @UtilityLocation
		  AND Is_deleted = 0
		  AND EcolabAccountNumber = @EcolabAccountNumber
		  AND M.ControllerID IN (
			 SELECT ControllerId
			   FROM TCD.ConduitController
			   WHERE ControllerModelId = 7
				AND EcoalabAccountNumber = @EcolabAccountNumber);
	   SELECT @TunnelLimit = COUNT(1)
		FROM TCD.Meter M
			LEFT OUTER JOIN
			TCD.machinesetup MS ON M.GroupId = MS.groupId
		WHERE M.UtilityType = 2
		  AND M.GroupID = @UtilityLocation
		  AND Ms.Istunnel = 1
		  AND Is_deleted = 0
		  AND EcoalabAccountNumber = @EcolabAccountNumber
		  AND M.ControllerID IN (
			 SELECT ControllerId
			   FROM TCD.ConduitController
			   WHERE ControllerModelId = 7
				AND EcoalabAccountNumber = @EcolabAccountNumber);
	   SELECT @IStunnel = Istunnel
		FROM TCD.machinesetup MS
		WHERE Ms.GroupId = @UtilityLocation
		  AND EcoalabAccountNumber = @EcolabAccountNumber;
    END;

    -- End Defining Limits

    IF @IStunnel = 1
        BEGIN				
            IF @MachineCompartment = 1
                BEGIN
                    SET @IsPress = 1;
                END;
		IF @MachineCompartment = 0
            BEGIN
			SET @MachineCompartment = NULL;
			END
        END;

    IF @UtilityLocation = 1
	   BEGIN
		  SET @IsPlant = 1;
		  SET @UtilityLocation = NULL;
		  SET @MachineCompartment = NULL;
	   END;
    IF @ControllerID = -1
	   BEGIN
		  SELECT TOP (1) @ControllerID = ControllerID
		    FROM TCD.ConduitController
		    WHERE ControllerModelId = @ControllerModelID
			 AND EcoalabAccountNumber = @EcolabAccountNumber;
	   END;
    ELSE
	   BEGIN
		  SELECT @ControllerModelID = ControllerModelId
		    FROM TCD.ConduitController
		    WHERE ControllerId = @ControllerID
			 AND EcoalabAccountNumber = @EcolabAccountNumber;
	   END;
    IF @ControllerID != -1
	   BEGIN
		  DECLARE
			  @NewMeterId INT
			  ,@TagType VARCHAR(50) = 'Tag_MPLC'
			  ,@ModuleTypeId INT = 2
			  ,@Result INT = NULL
			  ,@Type INT = 2
			  ,@AllowTagEdit BIT;
		  SELECT @AllowTagEdit = CASE
							WHEN COUNT(*) > 0 THEN 'TRUE'
							    ELSE 'FALSE'
							END
		    FROM TCD.UserMaster UM
			    INNER JOIN
			    TCD.UserInRole UIR ON UM.UserId = UIR.UserId
			    INNER JOIN
			    TCD.UserRoles UR ON UIR.RoleId = UR.RoleId
		    WHERE UM.UserId = @UserID
			 AND UR.LevelId >= 8;
		  IF NOT EXISTS (SELECT 1
					    FROM   TCD.Meter
					    WHERE  MeterID = @MeterNumber
						  AND EcolabAccountNumber = @EcolabAccountNumber)

			 -- Begin Create Meter

			 BEGIN

					   DECLARE @AllowInsert BIT = 'FALSE';

					   -- Begin Business Validations
					   IF @MeterNameLimit < 1
					   	   BEGIN
							   IF @UtilityLimit < 1 OR @Uitiliy = 2
								  BEGIN
								 	 		 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 		 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 IF @ControllerModelID = 7
								BEGIN
													
								    IF @UtilityLimit >= 1 AND @Uitiliy != 2
									   BEGIN
										  SET @Scope = @Scope + '301,';										 
									   END;
								    IF @Uitiliy = 2 AND @IStunnel = 1
									   BEGIN   										
									IF @UtilityLimit >= 1
									   BEGIN
										  SET @Scope = @Scope + '301,';										  
									   END;									 
										ELSE IF @TunnelLimit < 6
											BEGIN											
												SET @AllowInsert = 'TRUE';
											END;
										ELSE
											BEGIN											
												SET @Scope = @Scope + '101,';
											END;
										END;
									ELSE IF @Uitiliy = 2 AND @IStunnel != 1
									   BEGIN		
										 IF @WasherLimit < 2
											BEGIN
												SET @AllowInsert = 'TRUE';												
											END;
										ELSE
											BEGIN
												SET @Scope = @Scope + '201,';												
											END;
										END;									   
								    ELSE
									   BEGIN
										  SET @AllowInsert = 'TRUE';										  
									   END;
								END;
							 ELSE
								BEGIN
								    SET @AllowInsert = 'TRUE';									
								END;
								  END;
							   ELSE
								  BEGIN
									 SET @Scope = @Scope + '301,';									 
							   END;
			               END;
						ELSE
							BEGIN
								SET @Scope = @Scope + '302,';								
							END;
						
						IF @Uitiliy = 12
						 BEGIN
							SET @AllowInsert = 'TRUE';
							SET @Scope = '';
						 END;						


					   -- End Business Validations
					   -- Begin Insert if Validation Succeeds

					   IF @AllowInsert = 'TRUE'
						  BEGIN
							 INSERT INTO TCD.Meter (EcolabAccountNumber,
											    Description,
											    UtilityType,
											    GroupId,
											    MachineCompartment,
											    MaxValueLimit,
											    MeterTickUnit,
											    UsageFactor,
											    ControllerID,
											    Parent,
											    Calibration,
											    AllowManualentry ,
											    LastModifiedByUserId,
											    IsPlant,
											    IsPress,
												WaterType,
												WaterTypeFromFormulaSetup,
												CounterNum,
												CounterUsage,
												RunningTimeUsage,
												CounterAlarmValue,
												RunningTimeAlarmValue,
												DigitalInputNumber)
							 OUTPUT
							 inserted.MeterId				AS MeterId
							 ,inserted.LastModifiedTime		AS LastModifiedTimestamp
								   INTO
								   @OutputList	(
								   MeterId
								   ,LastModifiedTimestamp
								   )
							 SELECT
							 @EcolabAccountNumber,
							 @MeterName,
							 @Uitiliy,
							 @UtilityLocation,
							 @MachineCompartment,
							 @Meterrolloverpoint,
							 @UOFfoRCalibration,
							 @Usagefactor,
							 @ControllerID,
							 @Parent,
							 @Calibration,
							 @AllowmanualEntry,
							 @UserID,
							 @IsPlant,
							 @IsPress,
							 @WaterType,
							 @WaterTypeFromFormulaSetup,
							 @CounterNum,
							 @CounterUsage,
							 @RunningTimeUsage,
							 @CounterAlarmValue,
							 @RunningTimeAlarmValue,
							 @ExternalCounter;
							 IF @AllowTagEdit = 'TRUE'
								BEGIN
								    IF @Result IS NOT NULL
									   BEGIN
										  SET @NewMeterId = SCOPE_IDENTITY();
										  INSERT INTO TCD.ModuleTags (EcolabAccountNumber,
																TagType,
																TagAddress,
																ModuleTypeId,
																ModuleID,
																DeadBand,
																Active)
										  VALUES(@EcolabAccountNumber,
											    @TagType,
											    @DigitalInputNumber,
											    @ModuleTypeId,
											    @NewMeterId,
											    20,
											    1);
									   END;
								END;
						  END;

				    -- End Insert if Validation Succeeds

				  --  END;
				ELSE
				    BEGIN
					   SET @Scope = @Scope + '802,';
				    END;
			 END;

		  --End Create Meter
		  ELSE

			 -- Begin Update Meter

			 BEGIN
				DECLARE
					@PlantId INT = (SELECT MG.Id
								   FROM TCD.MachineGroupType MGT
									   INNER JOIN
									   TCD.MachineGroup MG ON MGT.Id = MG.GroupTypeId
								   WHERE MGT.Id = 1
									AND MG.Is_Deleted = 0);

				-- Check RedFlag Association and Update Meter

				IF((SELECT COALESCE(  M.GroupId, '')
					 FROM TCD.Meter M
					 WHERE M.MeterId = @MeterNumber) != COALESCE(@UtilityLocation, '')
				OR (SELECT COALESCE(  M.MachineCompartment  , '')
					 FROM TCD.Meter M
					 WHERE M.MeterId = @MeterNumber) != COALESCE(@MachineCompartment, '')  )
			   AND EXISTS(SELECT 1
						 FROM TCD.RedFlag RF
							 INNER JOIN
							 TCD.RedFlagMappingData RFM ON RF.Id = RFM.MappingId
												  AND RF.Is_Deleted = 0
												  AND RFM.Is_Deleted = 0
							 LEFT JOIN
							 TCD.Meter M ON RF.Location = CASE M.IsPlant
													WHEN 'TRUE' THEN COALESCE(  M.GroupId , @PlantId)
													    ELSE M.GroupId
													END
									  AND COALESCE(  M.MachineCompartment , 0) = COALESCE(  RFM.MachineId , 0)
									  AND M.Is_deleted = 0
						 WHERE M.MeterId = @MeterNumber)
				    BEGIN
					   SET @Scope = '405,';
				    END;
				ELSE
				    BEGIN
					   DECLARE
						   @AllowUpdate BIT = 'FALSE';
							 --Begin Get old Meter Values 

							 BEGIN
								DECLARE
									@Uty INT = (SELECT UtilityType
											    FROM TCD.Meter
											    WHERE MeterID = @MeterNumber
												 AND EcolabAccountNumber = @EcolabAccountNumber);
								DECLARE
									@grpId INT = (SELECT GroupId
												 FROM TCD.Meter
												 WHERE MeterID = @MeterNumber
												   AND EcolabAccountNumber = @EcolabAccountNumber);
								DECLARE
									@machId INT = (SELECT MachineCompartment
												  FROM TCD.Meter
												  WHERE MeterID = @MeterNumber
												    AND EcolabAccountNumber = @EcolabAccountNumber);
								DECLARE
								    @Mname INT =(SELECT COUNT(1) 
													FROM TCD.Meter 
													WHERE [Description] = @MeterName
														AND MeterId <> @MeterNumber
														AND EcolabAccountNumber = @EcolabAccountNumber
														AND Is_deleted = 0);
							 END;

							 --End Get old Meter Values

							 IF @AllowTagEdit = 'TRUE'
								BEGIN
								    IF @DigitalInputNumber IS NOT NULL
									   BEGIN
										  EXEC @Result = TCD.CheckDuplicateTag @DigitalInputNumber, @ControllerID, @MeterNumber, @Type;
									   END;
								END;

							 -- Begin Business Validations
							
							IF @Mname < 1
							Begin
							  IF @uty <> @Uitiliy
							 OR @grpId <> @UtilityLocation
							 OR @machId <> @MachineCompartment
								BEGIN
								    IF @UtilityLimit < 1
									   BEGIN
										  IF @ControllerModelID = 7
											 BEGIN

												/* Inserting the Details of meter in to Meter table if it is new meter */

												IF @Uitiliy = 2
												    BEGIN
													   IF @IStunnel = 'TRUE'
														  BEGIN
															 IF @TunnelLimit < 6
															 OR @TunnelLimit < = 6
															AND @uty = @Uitiliy
															AND @grpId = @UtilityLocation
																BEGIN
																    SET @AllowUpdate = 'TRUE';
																END;
															 ELSE
																BEGIN
																    SET @Scope = @Scope + '101,';
																END;
														  END;
													   ELSE
														  BEGIN
															 IF @WasherLimit < 2
															 OR @WasherLimit < = 2
															AND @uty = @Uitiliy
															AND @grpId = @UtilityLocation
																BEGIN
																    SET @AllowUpdate = 'TRUE';
																END;
															 ELSE
																BEGIN
																    SET @AllowUpdate = 'FALSE';
																    SET @Scope = @Scope + '201,';
																END;
														  END;
												    END;
												ELSE
												    BEGIN
													   SET @AllowUpdate = 'TRUE';
												    END;
											 END;
										  ELSE
											 BEGIN
												SET @AllowUpdate = 'TRUE';
											 END;
									   END;
								    ELSE
									   BEGIN
										  SET @Scope = @Scope + '301,';
									   END;
								END;
							 ELSE
								BEGIN
								    SET @AllowUpdate = 'TRUE';
								END;
								END;
								ELSE
								BEGIN
								 SET @Scope = @Scope + '302,';
								END;

							 -- End Business Validations 
							 -- Begin Update if Validation Succeeds

							 IF @AllowUpdate = 'TRUE'
								BEGIN
								    UPDATE P
									 SET  Description = @MeterName,
										 UtilityType = @Uitiliy,
										 GroupId = @UtilityLocation,
										 MachineCompartment = @MachineCompartment,
										 Parent = @Parent,
										 Calibration = @Calibration,
										 ControllerID = @ControllerID,
										 MeterTickUnit = @UOFfoRCalibration,
										 UsageFactor = @Usagefactor,
										 AllowmanualEntry = @AllowmanualEntry,
										 Maxvaluelimit = @Meterrolloverpoint,
										 IsPlant = @IsPlant,
										 IsPress = @IsPress,
										 LastModifiedByUserId = @UserID,
										 LastModifiedTime = @CurrentUTCTime,
										 WaterType = @WaterType,
										 WaterTypeFromFormulaSetup = @WaterTypeFromFormulaSetup,
										 CounterNum = @CounterNum,
										 CounterUsage = @CounterUsage,
										 RunningTimeUsage = @RunningTimeUsage,
										 CounterAlarmValue = @CounterAlarmValue,
										 RunningTimeAlarmValue = @RunningTimeAlarmValue,
										 DigitalInputNumber = @ExternalCounter
								    OUTPUT
								    inserted.MeterId				AS MeterId
								    ,inserted.LastModifiedTime		AS LastModifiedTimestamp
										 INTO
										 @OutputList(
										 MeterId ,
										 LastModifiedTimestamp
										 )
									 FROM   TCD.Meter P
									 WHERE MeterID = @MeterNumber
									   AND EcolabAccountNumber = @EcolabAccountNumber;
								   
								--END;

						  -- End Update if Validation Succeeds 

						  END;
					
				    END;
			 END;

	   -- End Update Meter

	   END;
    ELSE
	   BEGIN
		  SET @Scope = '701,';
	   END;
    SET NOCOUNT OFF;
    SELECT	TOP 1
    @OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp
    ,@OutputMeterId = O.MeterId
	 FROM @OutputList O;
    RETURN @ReturnValue;
END;
GO


IF EXISTS (SELECT * 
			   FROM   sys.objects 
			   WHERE  object_id = Object_id(N'[TCD].[SavePlantSensorDetails]') 
					  AND type IN ( N'P', N'PC' )) 
  DROP PROCEDURE [TCD].[SavePlantSensorDetails]
GO

CREATE PROCEDURE TCD.SavePlantSensorDetails(
      @SensorNumber NVARCHAR( 100) = NULL,
      @EcolabAccountNumber NVARCHAR( 25) = NULL,
      @ControllerID VARCHAR( 1000) = NULL,
      @SensorName NVARCHAR( 100) = NULL,
      @SensorType NVARCHAR( 100) = NULL,
      @SensorLocation NVARCHAR( 100) = NULL,
      @MachineCompartment NVARCHAR( 100) = NULL,
      @OutputType NVARCHAR( 100) = NULL,
      @ChemicalforChart NVARCHAR( 100)= NULL,
      @UOM NVARCHAR( 100) = NULL,
      @DashboardActualValue VARCHAR( 100) = NULL,
      @UserID INT,
      @AnalogueInputNumber NVARCHAR( 100) = NULL,
      @Calibration4mA DECIMAL( 18, 2) = NULL,
      @Calibration20mA DECIMAL( 18, 2) = NULL,
      @TagAddress4mA NVARCHAR( 100) = NULL,
      @TagAddress20mA NVARCHAR( 100) = NULL,
      @Scope VARCHAR( 100)OUTPUT,
      @OutputSensorId INT = NULL OUTPUT,
      @LastModifiedTimestampAtCentral DATETIME = NULL,
      @OutputLastModifiedTimestampAtLocal DATETIME = NULL OUTPUT,
	  @SensorNum INT,
	  @AlarmEnable BIT,
	  @MinimumAlarmValue INT,
	  @MaximumAlarmValue INT,
	  @ExternalSensor INT)
AS
     BEGIN
         SET NOCOUNT ON;
         DECLARE @IsPlant BIT = NULL,
         @IsPress BIT = NULL,
         @IStunnel INT = '';
         DECLARE @TypeLimit INT = NULL,
         @TempLimit INT = NULL,
         @pHLimit INT = NULL,
         @ConductivityLimit INT = NULL,
         @WeightLimit INT = NULL,
         @ControllerModelID INT = NULL;
         DECLARE @ReturnValue INT = 0,
         @ErrorId INT = 0,
         @ErrorMessage NVARCHAR( 4000) = N'',
         @CurrentUTCTime DATETIME = GETUTCDATE();
         DECLARE @OutputList AS TABLE( SensorId INT,LastModifiedTimestamp DATETIME);
         SET @OutputLastModifiedTimestampAtLocal = ISNULL( @OutputLastModifiedTimestampAtLocal, NULL);

         --SQLEnlight

         SET @OutputSensorId = ISNULL( @OutputSensorId, NULL);

         /*Maximum one Sensor with the same type can be connected to one machine/Compartement */

         IF @LastModifiedTimestampAtCentral IS NOT NULL
            AND
            NOT EXISTS( SELECT 1
                        FROM TCD.Sensor AS S
                        WHERE S.EcolabAccountNumber = @EcolabAccountNumber
                              AND
                              S.SensorId = @SensorNumber
                              AND
                              S.LastModifiedTime = @LastModifiedTimestampAtCentral
                      )
             BEGIN
                 SET @ErrorId = 60000;
                 SET @ErrorMessage = N'' + CAST( @ErrorId AS NVARCHAR);
                 RAISERROR( @ErrorMessage, 16, 1);
                 SET @ReturnValue = -1;
                 RETURN @ReturnValue;
             END;
         SET @Scope = '';
         SELECT @TypeLimit = COUNT( 1)
         FROM TCD.Sensor AS S
         WHERE GroupId = @SensorLocation
               AND
               S.SensorType = @SensorType
               AND
               ISNULL( MachineCompartment, 0) = @MachineCompartment
               AND
               Is_deleted = 0
               AND
               ControllerID IN(
               SELECT ControllerId
               FROM TCD.ConduitController
               WHERE ControllerId = @ControllerID
                     AND
                     EcoalabAccountNumber = @EcolabAccountNumber
                              )
               AND
               EcolabAccountNumber = @EcolabAccountNumber;

         /*Maximum 6 Temperature sensor can be connected to the same Washter-Tunnel */

         SELECT @TempLimit = COUNT( 1)
         FROM TCD.Sensor AS S LEFT OUTER JOIN TCD.machinesetup AS MS ON S.GroupId = MS.groupId
                                                                        AND
                                                                        S.EcolabAccountNumber = MS.EcoalabAccountNumber
         WHERE S.SensorType = 1
               AND
               S.GroupID = @SensorLocation
               AND
               Ms.Istunnel = 1
               AND
    IS_deleted = 0
               AND
               S.ControllerID IN(
               SELECT ControllerId
               FROM TCD.ConduitController
               WHERE ControllerModelId = 7
                     AND
                     EcoalabAccountNumber = @EcolabAccountNumber
                                )
               AND
               S.EcolabAccountNumber = @EcolabAccountNumber;

         /* Maximum 2 pH sensor can be connected to the same Washter-Tunnel */

         SELECT @pHLimit = COUNT( 1
                                )
         FROM TCD.Sensor AS S LEFT OUTER JOIN TCD.machinesetup AS MS ON S.GroupId = MS.groupId
                                                                        AND
                                                                        S.EcolabAccountNumber = MS.EcoalabAccountNumber
         WHERE S.SensorType = 2
               AND
               S.GroupID = @SensorLocation
               AND
               Ms.Istunnel = 1
               AND
               IS_deleted = 0
               AND
               S.ControllerID IN(
               SELECT ControllerId
               FROM TCD.ConduitController
               WHERE ControllerModelId = 7
                     AND
                     EcoalabAccountNumber = @EcolabAccountNumber
                                )
               AND
               S.EcolabAccountNumber = @EcolabAccountNumber;

         /* Maximum 1 Conductivity sensor can be connected to the same Washter-Tunnel */

         SELECT @ConductivityLimit = COUNT( 1)
         FROM TCD.Sensor AS S LEFT OUTER JOIN TCD.machinesetup AS MS ON S.GroupId = MS.groupId
                                                                        AND
                                                                        S.EcolabAccountNumber = MS.EcoalabAccountNumber
         WHERE S.SensorType = 4
               AND
               S.GroupID = @SensorLocation
               AND
               Ms.Istunnel = 1
               AND
               IS_deleted = 0
               AND
               S.ControllerID IN(
               SELECT ControllerId
               FROM TCD.ConduitController
               WHERE ControllerModelId = 7
                     AND
                     EcoalabAccountNumber = @EcolabAccountNumber
                                )
               AND
               S.EcolabAccountNumber = @EcolabAccountNumber;

         /* Maximum 1 Weight sensor can be connected to the same Washter-Tunnel */

         SELECT @WeightLimit = COUNT( 1)
         FROM TCD.Sensor AS S LEFT OUTER JOIN TCD.machinesetup AS MS ON S.GroupId = MS.groupId
                                                                        AND
                                                                        S.EcolabAccountNumber = MS.EcoalabAccountNumber
         WHERE S.SensorType = 5
               AND
               S.GroupID = @SensorLocation
               AND
               Ms.Istunnel = 1
               AND
               IS_deleted = 0
               AND
               S.ControllerID IN(
               SELECT ControllerId
               FROM TCD.ConduitController
               WHERE ControllerModelId = 7
                     AND
                     EcoalabAccountNumber = @EcolabAccountNumber
                                )
               AND
               S.EcolabAccountNumber = @EcolabAccountNumber;
         SELECT @ControllerModelID = ControllerModelId
         FROM TCD.ConduitController
         WHERE ControllerId = @ControllerID
               AND
               EcoalabAccountNumber = @EcolabAccountNumber;
         SELECT @IStunnel = Istunnel
         FROM TCD.machinesetup AS MS
         WHERE Ms.GroupId = @SensorLocation
               AND
               MS.EcoalabAccountNumber = @EcolabAccountNumber;
         IF @IStunnel = 1
             BEGIN				
                 IF @MachineCompartment = 1
                     BEGIN
                         SET @IsPress = 1;
                     END;
				IF @MachineCompartment = 0
                 BEGIN
					SET @MachineCompartment = NULL;
				 END
             END;
         IF @SensorLocation = 1
             BEGIN
                 SET @IsPlant = 1;
                 SET @SensorLocation = NULL;
                 SET @MachineCompartment = NULL;
             END;
         IF @ControllerID = -1
             BEGIN
                 SELECT TOP ( 1
                            )@ControllerID = ControllerID
                 FROM TCD.ConduitController
                 WHERE ControllerModelId = @ControllerModelID
                       AND
                       EcoalabAccountNumber = @EcolabAccountNumber;
             END;
         ELSE
             BEGIN
                 SELECT @ControllerModelID = ControllerModelId
                 FROM TCD.ConduitController
                 WHERE ControllerId = @ControllerID
                       AND
                       EcoalabAccountNumber = @EcolabAccountNumber;
             END;
         IF @ControllerID != -1
             BEGIN

                 /* Inserting the values in to Sensor table if it is new Sensor */

                 DECLARE @NewSensorId INT,
                 @ModuleType INT = 3,
                 @DefaultFrequency INT = 60,
                 @TagType VARCHAR( 100) = 'Tag_MPLC',
                 @TagTypeSC4 VARCHAR( 100) = 'Tag_SC4',
                 @TagTypeSC20 VARCHAR( 100) = 'Tag_SC20',
                 @Result1 INT = NULL,
                 @Result2 INT = NULL,
                 @Result3 INT = NULL,
                 @Type INT = 3,
                 @AllowTagEdit BIT;
                 SELECT @AllowTagEdit = CASE
                                            WHEN COUNT( *) > 0
                                            THEN 'TRUE'
                                            ELSE 'FALSE'
                                        END
                 FROM TCD.UserMaster AS UM INNER JOIN TCD.UserInRole AS UIR
                 ON UM.UserId = UIR.UserId
                                           INNER JOIN TCD.UserRoles AS UR
                 ON UIR.RoleId = UR.RoleId
                 WHERE UM.UserId = @UserID
                       AND
                       UR.LevelId >= 8
                       AND
                       UM.EcolabAccountNumber = @EcolabAccountNumber;
                 IF NOT EXISTS( SELECT *
                                FROM TCD.Sensor
                                WHERE SensorID = @SensorNumber
                                      AND
                                      EcolabAccountNumber = @EcolabAccountNumber
                              )

                     -- Begin Create Sensor

                     BEGIN
                         BEGIN
                             DECLARE @AllowInsert BIT = 'FALSE';
                             IF @TypeLimit < 1
                                 BEGIN
                                     IF @ControllerModelID = 7
                                         BEGIN
                                             IF @SensorType = 1
                                                 BEGIN
                                                     IF @TempLimit < 6
                                                         BEGIN
                                                             SET @AllowInsert = 'TRUE';
                                                         END;
                                                     ELSE
                                                         BEGIN
                                                             SET @SCOPE = @SCOPE + '401,';
                                                         END;
                                                 END;
                                             ELSE
                                 BEGIN
                                                     IF @SensorType = 2
                                                         BEGIN
                                                             IF @pHLimit < 2
                                                                 BEGIN
                                                                     SET @AllowInsert = 'TRUE';
                                                                 END;
                                                             ELSE
                                                                 BEGIN
                                                                     SET @SCOPE = @SCOPE + '301,';
                                                                 END;
                                                         END;
                                                     ELSE
                                                         BEGIN
                                                             IF @SensorType = 4
                                                                 BEGIN
                                                                     IF @ConductivityLimit < 1
                                                                         BEGIN
                                                                             SET @AllowInsert = 'TRUE';
                                                                         END;
																	ELSE
                                                                     BEGIN
                                                                         SET @SCOPE = @SCOPE + '201,';
                                                                     END;
                                                                 END;
                                                             ELSE
                                                                 BEGIN
                                                                     IF @SensorType = 5
                                                                         BEGIN
                                                                             IF @WeightLimit < 1
                                                                                 BEGIN
                                                                                     SET @AllowInsert = 'TRUE';
                                                                                 END;
                                                                             ELSE
                                                                                 BEGIN
                                                                                     SET @SCOPE = @SCOPE + '101,';
                                                                                 END;
                                                                         END;
                                                                 END;
                                                         END;
                                                 END;
                                         END;
                                     ELSE
                                         BEGIN
                                             SET @AllowInsert = 'TRUE';
                                         END;
                                 END;
                             ELSE
                                 BEGIN
                                     SET @Scope = @Scope + '501,';
                                 END;

                             -- End Business Validations
                             -- Begin Insert if Validation Succeeds

                             IF @AllowInsert = 'TRUE'
                                 BEGIN
                                     DECLARE @SensorCount INT;
                                     SELECT @SensorCount = MAX( s.SensorId)+1
                                     FROM TCD.Sensor AS s WITH ( NOLOCK);
                                 
                                     INSERT INTO TCD.Sensor( Description,
                                     SensorType,
                                     GroupId,
                                     MachineCompartment,
                                     EcolabAccountNumber,
                                     ControllerID,
                                     OutputType,
                                     ChemicalforChart,
                                     UOM,
                                     DashboardActualValue,
                                     LastModifiedByUserId,
                                     IsPlant,
                                     IsPress,
                                     Calibration4mA,
                                     Calibration20mA,
                                     Id,
									 SensorNum,
									 AlarmEnable,
									 MinimumAlarmValue,
									 MaximumAlarmValue,
									 AnalogueInputNumber )                                                         
                                     OUTPUT inserted.SensorId AS SensorId,
                                     inserted.LastModifiedTime AS LastModifiedTimestamp
                                            INTO @OutputList( SensorId,
                                            LastModifiedTimestamp
                                                            )
                                     SELECT @SensorName,
                                     @SensorType,
                                     @SensorLocation,
                                     @MachineCompartment,
                                     @EcolabAccountNumber,
                                     @ControllerID,
                                     @OutputType,
                                     @ChemicalforChart,
                                     @UOM,
                                     @DashboardActualValue,
                                     @UserID,
                                     @IsPlant,
                                     @IsPress,
                                     @Calibration4mA,
                                     @Calibration20mA,
                                     @SensorCount,
									 @SensorNum,
									 @AlarmEnable,
									 @MinimumAlarmValue,
									 @MaximumAlarmValue,
									 @ExternalSensor;
                                     SET @NewSensorId = SCOPE_IDENTITY(
                                                                      );
                                 END;
                         END;
                     END;
                 ELSE

                     ------------------------------------------------------------------------------------------------------------------
                     -- Begin Update Sensor

                     BEGIN
                         DECLARE @PlantId INT = ( SELECT MG.Id
                                                  FROM TCD.MachineGroupType AS MGT INNER JOIN TCD.MachineGroup AS MG
                                                  ON MGT.Id = MG.GroupTypeId
                                                  WHERE MGT.Id = 1
                                                        AND
                                                        MG.Is_Deleted = 0
                                                );

                         -- Check RedFlag Association and Update Sensor

                         IF(( SELECT COALESCE( S.GroupId, ''
                                             )
                              FROM TCD.Sensor AS S
                              WHERE S.SensorId = @SensorNumber
                            ) != COALESCE( @SensorLocation, ''
                                         )
                            OR
                            ( SELECT COALESCE( S.MachineCompartment, ''
                                             )
                              FROM TCD.Sensor AS S
                              WHERE S.SensorId = @SensorNumber
                            ) != COALESCE( @MachineCompartment, ''
                                         ))
                           AND
                           EXISTS( SELECT 1
                                   FROM TCD.RedFlag AS RF INNER JOIN TCD.RedFlagMappingData AS RFM
                                   ON RF.Id = RFM.MappingId
                                      AND
                                      RF.Is_Deleted = 0
                                      AND
                                      RFM.Is_Deleted = 0
                                                          LEFT JOIN TCD.Sensor AS S
                                   ON RF.Location = CASE S.IsPlant
                                                        WHEN 'TRUE'
                                                        THEN COALESCE( S.GroupId, @PlantId
                                                                     )
                                                        ELSE S.GroupId
                                                    END
                                      AND
                                      COALESCE( S.MachineCompartment, 0
                                              ) = COALESCE( RFM.MachineId, 0
                                                          )
                                      AND
                                      S.Is_deleted = 0
                                   WHERE S.SensorId = @SensorNumber
                                 )
                             BEGIN
                                 SET @Scope = '405,';
                             END;
                         ELSE
                             BEGIN
                                 IF(@Result1 IS NULL
                                    OR
                                    @Result1 <> 0)
                                   AND
                                   (@Result2 IS NULL
                                    OR
                                    @Result2 <> 0)
                                   AND
                                   (@Result3 IS NULL
                                    OR
                                    @Result3 <> 0)
                                     BEGIN
                                         DECLARE @AllowUpdate BIT = 'FALSE';

                                         --Begin Get old Sensor Values

                                         BEGIN
                                             DECLARE @uty INT = ( SELECT sensortype
                                                                  FROM TCD.Sensor
                                                                  WHERE SensorID = @SensorNumber
                                                                        AND
                                                                        EcolabAccountNumber = @EcolabAccountNumber
                                                                );
                                             DECLARE @grpId INT = ( SELECT GroupId
                                                                    FROM TCD.Sensor
                                                                    WHERE SensorID = @SensorNumber
                                                                          AND
                                                                          EcolabAccountNumber = @EcolabAccountNumber
                                                                  );
                                             DECLARE @machId INT = ( SELECT MachineCompartment
                                                                     FROM TCD.Sensor
                                                                     WHERE SensorID = @SensorNumber
                                                                           AND
                                                                           EcolabAccountNumber = @EcolabAccountNumber
                                   );
                                         END;

                                         --Begin Get old Sensor Values

                                         IF @uty <> @SensorType
                                            OR
                                            @grpId <> @SensorLocation
                                            OR
                                            @machId <> @MachineCompartment
                                             BEGIN
                                                 IF @TypeLimit < 1
                                                     BEGIN
                                                         IF @ControllerModelID = 7
                                                             BEGIN
                                                                 IF @SensorType = 1
                                                                     BEGIN
                                                                         IF @TempLimit < 6
                                                                             BEGIN
                                                                                 SET @AllowUpdate = 'TRUE';
                                                                             END;
                                                                         ELSE
                                                                             BEGIN
                                                                                 SET @SCOPE = @SCOPE + '401,';
                                                                             END;
                                                                     END;
                                                                 ELSE
                                                                     BEGIN
                                                                         IF @SensorType = 2
                                                                             BEGIN
                                                                                 IF @pHLimit < 2
                                                                                     BEGIN
                                                                                         SET @AllowUpdate = 'TRUE';
                                                                                     END;
                                                                                 ELSE
                                                                                     BEGIN
                                                                                         SET @SCOPE = @SCOPE + '301,';
                                                                                     END;
                                                                             END;
                                                                         ELSE
                                                                             BEGIN
                                                                                 IF @SensorType = 4
                                                                                     BEGIN
                                                                                         IF @ConductivityLimit < 1
                                                                                             BEGIN
                                                                                                 SET @AllowUpdate = 'TRUE';
                                                                                             END;
                                                                                         ELSE
                                                                                             BEGIN
                                               SET @SCOPE = @SCOPE + '201,';
                                                                                             END;
                                                                                     END;
                                                                                 ELSE
                                                                                     BEGIN
                                                                                         IF @SensorType = 5
                                                                                             BEGIN
                                                                                                 IF @WeightLimit < 1
                                                                                                     BEGIN
                                                                                                         SET @AllowUpdate = 'TRUE';
                                                                                                     END;
                                                                                                 ELSE
                                                                                                     BEGIN
                                                                                                         SET @SCOPE = @SCOPE + '101,';
                                                                                                     END;
                                                                                             END;
                                                                                     END;
                                                                             END;
                                                                     END;
                                                             END;
                                                         ELSE
                                                             BEGIN
                                                                 BEGIN
                                                                     SET @AllowUpdate = 'TRUE';
                                                                 END;
                                                             END;
                                                     END;
                                                 ELSE
                                                     BEGIN
                                                         SET @SCOPE = @SCOPE + '501,';
                                                     END;
                                             END;
                                         ELSE
                                             BEGIN
                                                 SET @AllowUpdate = 'TRUE';
                                             END;
                                         IF @AllowUpdate = 'TRUE'
                                             BEGIN
                                                 IF @LastModifiedTimestampAtCentral IS NOT NULL
                                                    AND
                                                    NOT EXISTS( SELECT 1
                                                                FROM TCD.Sensor AS S
                                                                WHERE S.EcolabAccountNumber = @EcolabAccountNumber
                                                                      AND
                                                                      S.SensorId = @SensorNumber
                                                                      AND
                                                                      S.LastModifiedTime = @LastModifiedTimestampAtCentral
           )
                                                     BEGIN
                                                         SET @ErrorId = 60000;
                                                         SET @ErrorMessage = N'' + CAST( @ErrorId AS NVARCHAR
                                                                                       ) + N': Record not in-synch between plant and central.';
                                                         RAISERROR( @ErrorMessage, 16, 1
                                                                  );
                                                         SET @ReturnValue = -1;
                                                         RETURN @ReturnValue;
                                                     END;
                                                 UPDATE s
                                                        SET Description = @SensorName,
                                                 SensorType = @SensorType,
                                                 GroupId = @SensorLocation,
                                                 MachineCompartment = @MachineCompartment,
                                                 S.ControllerID = @ControllerID,
                                                 OutputType = @OutputType,
                                                 ChemicalforChart = @ChemicalforChart,
                                                 UOM = @UOM,
                                                 DashboardActualValue = @DashboardActualValue,
                                                 LastModifiedByUserId = @UserID,
                                                 Calibration4mA = @Calibration4mA,
                                                 Calibration20mA = @Calibration20mA,
                                                 LastModifiedTime = @CurrentUTCTime,
												 SensorNum = @SensorNum,
												 AlarmEnable = @AlarmEnable,
												 MinimumAlarmValue = @MinimumAlarmValue,
												 MaximumAlarmValue = @MaximumAlarmValue,
												 AnalogueInputNumber = @ExternalSensor
                                                 OUTPUT inserted.SensorId AS SensorId,
                                                 inserted.LastModifiedTime AS LastModifiedTimestamp
                                                        INTO @OutputList( SensorId,
                                                        LastModifiedTimestamp
                                                                        )
                                                 FROM TCD.Sensor S
                                                 WHERE SensorID = @SensorNumber
                                                       AND
                                                       EcolabAccountNumber = @EcolabAccountNumber;
                                             END;
                                     END;
                             END;
                     END;

             -- End Update Sensor

             END;
         ELSE
             BEGIN
                 SELECT @Scope = '701,';
             END;
         SET NOCOUNT OFF;
         SELECT TOP 1 @OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp,
         @OutputSensorId = O.SensorId
         FROM @OutputList AS O;
         RETURN @ReturnValue;
     END;
GO
------------------------------------------------------
IF EXISTS (SELECT * 
			   FROM   sys.objects 
			   WHERE  object_id = Object_id(N'[TCD].[GetPlantSensorDetailsBySensorId]') 
					  AND type IN ( N'P', N'PC' )) 
BEGIN
  DROP PROCEDURE [TCD].[GetPlantSensorDetailsBySensorId]
END
GO

CREATE PROCEDURE [TCD].[GetPlantSensorDetailsBySensorId] 
	-- Add the parameters for the stored procedure here
				 @SensorId INT = NULL
				,@EcolabAccountNumber NVARCHAR(25)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

SELECT		S.SensorId				AS		SensorId
		,	S.[Description]			AS		[Description]
		,	S.SensorType			AS		SensorType
		,	S.GroupId				AS		GroupId
		,	S.MachineCompartment	AS		MachineCompartment
		,	S.EcolabAccountNumber	AS		EcolabAccountNumber
		,	S.ControllerID			AS		ControllerID
		,	S.OutputType			AS		OutputType
		,	S.Calibration4mA		AS		Calibration4mA
		,	S.AnalogueInputNumber	AS		AnalogueInputNumber
		,	S.ChemicalforChart		AS		ChemicalforChart
		,	S.UOM					AS		UOM
		,	S.DashboardActualValue	AS		DashboardActualValue
		,	S.Is_deleted			AS		Is_deleted
		,	S.Id					AS		Id
		,	S.LastModifiedByUserId	AS		LastModifiedByUserId
		,	S.IsPlant				AS		IsPlant
		,	S.IsPress				AS		IsPress
		,	S.Calibration20mA		AS		Calibration20mA
		,	S.LastSyncTime			AS		LastSyncTime
		,	S.LastModifiedTime		AS		LastModifiedTime,
		s.SensorNum,
		s.AlarmEnable,
		s.MinimumAlarmValue,
		s.MaximumAlarmValue,
		s.AnalogueInputNumber,
		CAST(ISNULL(csd.Value,0) AS BIT) AS ISWaterEnergyLogSel
FROM TCD.Sensor S 
LEFT JOIN TCD.ControllerSetupData csd 
ON csd.ControllerId = S.ControllerID AND csd.FieldId = 473 AND csd.FieldGroupId = 20 AND csd.EcolabAccountNumber = S.EcolabAccountNumber
WHERE S.SensorId	= ISNULL(@SensorId, S.SensorId)
AND S.EcolabAccountNumber = @EcolabAccountNumber

END
GO
----------------------------
IF EXISTS (SELECT * 
			   FROM   sys.objects 
			   WHERE  object_id = Object_id(N'[TCD].[GetPlantMeterDetailsByMeterId]') 
					  AND type IN ( N'P', N'PC' )) 
BEGIN
  DROP PROCEDURE [TCD].[GetPlantMeterDetailsByMeterId]
END
GO

CREATE PROCEDURE [TCD].[GetPlantMeterDetailsByMeterId] 
	-- Add the parameters for the stored procedure here
				 @MeterId INT = NULL
				,@EcolabAccountNumber NVARCHAR(25)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

SELECT		M.MeterId				AS		MeterId
		,	M.[Description]			AS		[Description]
		,	M.UtilityType			AS		MeterType
		,	M.GroupId				AS		GroupId
		,	M.EcolabAccountNumber	AS		EcolabAccountNumber
		,	M.MaxValueLimit			AS		MaxValueLimit
		,	M.MeterTickUnit			AS		MeterTickUnit
		,	M.UsageFactor			AS		UsageFactor
		,	M.ControllerID			AS		ControllerId
		,	M.Parent				AS		ParentId
		,	M.Calibration			AS		Calibration
		,	M.DigitalInputNumber	AS		DigitalInputNumber
		,	M.AllowManualentry		AS		AllowManualEntry
		,	M.Is_deleted			AS		IsDeleted
		,	M.MachineCompartment	AS		MachineId
		,	M.Id					AS		Id
		,	M.LastModifiedByUserId	AS		LastModifiedByUserId
		,	M.LastSyncTime			AS		LastSyncTime
		,	M.IsPlant				AS		IsPlant
		,	M.IsPress				AS		IsPress
		,	M.LastModifiedTime		AS		LastModifiedTime,
		M.CounterAlarmValue,
		M.WaterType,
		M.WaterTypeFromFormulaSetup,
		M.RunningTimeAlarmValue,
		CAST(ISNULL(csd.Value,0) AS BIT) AS ISWaterEnergyLogSel,
		M.DigitalInputNumber,
		M.CounterUsage,
		M.RunningTimeUsage
FROM TCD.Meter M 
LEFT JOIN TCD.ControllerSetupData csd 
ON csd.ControllerId = M.ControllerID AND csd.FieldId = 473 AND csd.FieldGroupId = 20 AND csd.EcolabAccountNumber = M.EcolabAccountNumber
WHERE M.MeterId	= ISNULL(@MeterId, M.MeterId)
AND M.EcolabAccountNumber = @EcolabAccountNumber

END
GO

IF EXISTS (SELECT * 
			   FROM   sys.objects 
			   WHERE  object_id = Object_id(N'[TCD].[GetPlantUtilityDetails]') 
					  AND type IN ( N'P', N'PC' )) 
BEGIN
  DROP PROCEDURE [TCD].[GetPlantUtilityDetails]
END
GO

CREATE PROCEDURE TCD.GetPlantUtilityDetails(
       @Ecolabaccountnumber NVARCHAR(25))
AS
BEGIN
    SET NOCOUNT ON
    IF EXISTS(SELECT
                      s.*
                  FROM tempdb.sys.sysobjects AS s
                  WHERE s.xtype IN('U')
                    AND (s.id = OBJECT_ID(N'tempdb..#tmpWaterTypesUsed')
                      OR s.id = OBJECT_ID(N'tempdb..#tmpGasOilTypes')))
        BEGIN
            DROP TABLE
                    #tmpGasOilTypes;
            DROP TABLE
                    #tmpWaterTypesUsed;

        END

    CREATE TABLE #tmpWaterTypesUsed(
            WaterType INT, 
            WasherMode VARCHAR(1000))
    INSERT INTO #tmpWaterTypesUsed(
            WaterType, 
            WasherMode)
    (SELECT
             wds.WaterType, 
             'Washer' AS WasherMode
         FROM TCD.WasherDosingSetup AS wds
         WHERE wds.WaterType > 0
           AND wds.Is_Deleted = 0
     UNION
     SELECT
             tds.WaterType, 
             'Tunnel' AS WasherMode
         FROM TCD.TunnelDosingSetup AS tds
         WHERE tds.WaterType > 0
           AND tds.Is_Deleted = 0)


    DECLARE @Regionid INT, 
            @Usagekey VARCHAR(100)
    SELECT
            @Regionid = P.RegionID
        FROM TCD.Plant AS P
        WHERE P.EcolabAccountNumber = @Ecolabaccountnumber

    CREATE TABLE #tmpGasOilTypes(
            GasOilType VARCHAR(100), 
            EnergyContent DECIMAL(18, 4), 
            UsageKey VARCHAR(100))
    INSERT INTO #tmpGasOilTypes(
            GasOilType, 
            EnergyContent, 
            UsageKey)
    (SELECT
             gtm.Name, 
             gotm.DefaultValue, 
             gtm.UsageKey
         FROM TCD.GasoilTypeMaster AS gtm
              INNER JOIN TCD.GasOilTypeMapping AS gotm ON gtm.GasoilId = gotm.GasOilId
         WHERE gtm.GasoilId = (SELECT
                                       eud.GasOilTypeId
                                   FROM TCD.EnergyUtilityDetails AS eud
                                   WHERE eud.EcolabAccountNumber = @Ecolabaccountnumber)
           AND gotm.RegionId = @Regionid)



    SELECT DISTINCT
            @Usagekey = rkv.[Value]
        FROM TCD.DimensionalSubunits AS ds
             INNER JOIN tcd.DimensionalUnits AS du ON du.Unit = ds.Unit
             INNER JOIN TCD.DimensionalUsageKey AS duk ON duk.Unit = ds.Unit
             INNER JOIN TCD.DimensionalUnitsDefaults AS dud ON dud.UsageKey = duk.UsageKey
             INNER JOIN TCD.ResourceKeyMaster AS rkm ON rkm.KeyName = dud.Subunit
             INNER JOIN tcd.ResourceKeyValue AS rkv ON rkv.KeyName = rkm.KeyName
        WHERE duk.UsageKey = (SELECT
                                      UsageKey FROM #tmpGasOilTypes AS tgot)COLLATE Latin1_General_CI_AI
          AND dud.UnitSystemId = (SELECT
                                          p.UOMId FROM TCD.Plant AS p WHERE p.EcolabAccountNumber = @Ecolabaccountnumber)




    SELECT
            wu.EcolabAccountNumber AS EcolabAccountNumber, 
            wu.WaterFactorTypeId AS WaterFactorTypeId, 
            CASE
                WHEN wu.WaterFactorTypeId <> 0 THEN(SELECT DISTINCT
                                                            wt.Name
                                                        FROM TCD.WaterUtilityDetails AS wud
                                                             INNER JOIN TCD.WaterType AS wt ON wt.Id = wud.WaterFactorTypeId
                                                        WHERE wt.Id = wu.WaterFactorTypeId)
                WHEN wu.WaterFactorTypeId = 0 THEN CONVERT(VARCHAR(350), wu.WaterFactorTypeId)
            END AS FactorType, 
            wu.Temperature AS Temperature, 
            wu.Price AS Price, 
            eu.GasOilTypeId AS GasOilTypeId, 
            (SELECT
                     GasOilType FROM #tmpGasOilTypes AS tgot)AS GasOilType, 
            (SELECT
                     EnergyContent FROM #tmpGasOilTypes AS tgot)AS EnergyContent, 
            @Usagekey AS EnergyContentUnit, 
            eu.EnergyPrice AS EnergyPrice, 
            eu.EnergySubUnit AS EnergyPriceUnit, 
            eu.ElectricPrice AS ElectricPrice, 
            eu.BolierSteam AS BoilerSteam, 
            eu.BolierType AS BoilerType, 
            eu.Steam AS Steam, 
            eu.Boiler AS Boiler, 
            eu.Stack AS Stack, 
            eu.RewashFactor AS RewashFactor, 
            eu.EvaporationFactor AS EvaporationFactor, 
            CASE
                WHEN wu.WaterFactorTypeId <> 0 THEN(SELECT DISTINCT
                                                            wt.MyServiceUtilTypeCode
                                                        FROM TCD.WaterUtilityDetails AS wud
                                                             INNER JOIN TCD.WaterType AS wt ON wt.Id = wud.WaterFactorTypeId
                                                        WHERE wt.Id = wu.WaterFactorTypeId)
                WHEN wu.WaterFactorTypeId = 0 THEN 'V'
            END AS FreeType, 
            CASE
                WHEN(SELECT
                             COUNT(*)
                         FROM #tmpWaterTypesUsed AS twtu
                              INNER JOIN TCD.Watertype AS wt ON twtu.WaterType = wt.Id
                                                            AND wt.MyServiceUtilTypeCode = 'V'
                         WHERE twtu.WaterType = wu.WaterFactorTypeId) > 0 THEN 'TRUE'
                WHEN(SELECT
                             COUNT(*)
                         FROM #tmpWaterTypesUsed AS twtu
                              INNER JOIN TCD.Watertype AS wt ON twtu.WaterType = wt.Id
                                                            AND wt.MyServiceUtilTypeCode = 'V'
                         WHERE twtu.WaterType = wu.WaterFactorTypeId) = 0 THEN 'FALSE'
            END AS IsFactorUsed, 
            eu.LastModifiedTime, 
            wu.MyServiceWtrFctrId, 
            wu.MyServiceLastSyncTime, 
            wu.WaterUtilityDetailsId
        FROM TCD.WaterUtilityDetails AS wu
             INNER JOIN TCD.EnergyUtilityDetails AS eu ON eu.EcolabAccountNumber = wu.EcolabAccountNumber
        WHERE wu.EcolabAccountNumber = @Ecolabaccountnumber
        ORDER BY
            wu.WaterUtilityDetailsId
    SET NOCOUNT OFF
END
GO
-------------------------------------------------
IF EXISTS (SELECT * 
			   FROM   sys.objects 
			   WHERE  object_id = Object_id(N'[TCD].[GetWasherGroups]') 
					  AND type IN ( N'P', N'PC' )) 
BEGIN
  DROP PROCEDURE [TCD].[GetWasherGroups]
END
GO

/*	
Purpose					:	To get washer group(s) for the Washer Group Setup screen

History					:
Sept. 2014		dfozdar@allianceglobalservice.com		initial version
Oct. 2014		dfozdar@allianceglobalservice.com		Removing paging/sorting as per the decision taken...



*/
CREATE	PROCEDURE	[TCD].[GetWasherGroups]
					@EcoLabAccountNumber					NVARCHAR(1000)
				,	@WasherGroupId							INT				--Null for LIST
				,   @IsDeleted								BIT				=   'FALSE'
AS
BEGIN

SET	NOCOUNT	ON
IF @Washergroupid = -1 
BEGIN
	SET @Washergroupid = NULL
END

SELECT	
		WG.WasherGroupId			AS			WasherGroupId
	,	WG.WasherGroupNumber		AS			WasherGroupNumber
	,	WG.WasherGroupName			AS			WasherGroupName
	,	WG.WasherGroupTypeId		AS			WasherGroupTypeId
	,	WGT.WasherGroupTypeName		AS			WasherGroupTypeName
	,	COUNT(*)	OVER()			AS			TotalCount
	,	GT.LastModifiedTime			AS			LastModifiedTime
	,	GT.LastSyncTime				AS			LastSyncTime
	,	WG.EcolabAccountNumber
	,	GT.Is_Deleted				AS			IsDeleted
	,	GT.MyServiceCustMchGrpGuid  AS			MyServiceWasherGroupGuid
	,    WG.ControllerId            AS          ControllerId
	,    cc.ControllerModelId       AS          ControllerModelId
	,    cc.ControllerTypeId        AS          ControllerTypeId
	,	WG.WasherDosingNumber		AS			WasherDosingNumber
	,	(SELECT COUNT(1) FROM TCD.MachineSetup ms WHERE ms.GroupId = WG.WasherGroupId AND EcoalabAccountNumber = @EcoLabAccountNumber AND ms.IsDeleted = 'False') AS WasherCount
FROM	[TCD].MachineGroup					GT
JOIN	[TCD].WasherGroup					WG
	ON	GT.Id						=			WG.WasherGroupId
	AND GT.EcolabAccountNumber		=			WG.EcolabAccountNumber
JOIN	[TCD].WasherGroupType				WGT
	ON	WG.WasherGroupTypeId		=			WGT.WasherGroupTypeId
LEFT JOIN TCD.ConduitController cc
	ON cc.ControllerId				=			WG.ControllerId
WHERE	GT.EcolabAccountNumber		=			@EcoLabAccountNumber
	AND	(GT.Is_Deleted				=			'FALSE' or GT.Is_Deleted				=			@IsDeleted)
	AND	WG.WasherGroupId			=			ISNULL(@WasherGroupId, WG.WasherGroupId)




SET	NOCOUNT	OFF

END
GO


IF NOT EXISTS(SELECT 1 FROM sys.columns
            WHERE Name = N'ETechWasherNumber' AND Object_ID = Object_ID(N'[TCD].[Washer]'))
BEGIN
ALTER TABLE TCD.Washer ADD ETechWasherNumber INT NULL
END
GO


BEGIN TRY
BEGIN TRANSACTION trans

-- Line1 --
IF EXISTS(SELECT * FROM TCD.Field WHERE Label = N'Enable Auxiliary pump1' AND ResourceKey = N'Enable_Auxiliary_pump1')
BEGIN
UPDATE TCD.Field SET DefaultValue = 1 WHERE Label = N'Enable Auxiliary pump1' AND ResourceKey = N'Enable_Auxiliary_pump1' 
END

IF EXISTS(SELECT * FROM TCD.Field WHERE Label = N'Flow-meter for Flow check1' AND ResourceKey = N'Flow-meter_for_Flow_check1')
BEGIN
UPDATE TCD.Field SET DefaultValue = 1 WHERE Label = N'Flow-meter for Flow check1' AND ResourceKey = N'Flow-meter_for_Flow_check1'
END

-- Line2 --
IF EXISTS(SELECT * FROM TCD.Field WHERE Label = N'Enable Auxiliary pump2' AND ResourceKey = N'Enable_Auxiliary_pump2')
BEGIN
UPDATE TCD.Field SET DefaultValue = 1 WHERE Label = N'Enable Auxiliary pump2' AND ResourceKey = N'Enable_Auxiliary_pump2'
END

IF EXISTS(SELECT * FROM TCD.Field WHERE Label = N'Flow-meter for Flow check2' AND ResourceKey = N'meter_for_Flow_check2')
BEGIN
UPDATE TCD.Field SET DefaultValue = 1 WHERE Label = N'Flow-meter for Flow check2' AND ResourceKey = N'meter_for_Flow_check2'
END

-- Line3 --
IF EXISTS(SELECT * FROM TCD.Field WHERE Label = N'Enable Auxiliary pump3' AND ResourceKey = N'Enable_Auxiliary_pump3')
BEGIN
UPDATE TCD.Field SET DefaultValue = 1 WHERE Label = N'Enable Auxiliary pump3' AND ResourceKey = N'Enable_Auxiliary_pump3' 
END

IF EXISTS(SELECT * FROM TCD.Field WHERE Label = N'Flow-meter for Flow check3' AND ResourceKey = N'meter_for_Flow_check3')
BEGIN
UPDATE TCD.Field SET DefaultValue = 1 WHERE Label = N'Flow-meter for Flow check3' AND ResourceKey = N'meter_for_Flow_check3'
END

IF EXISTS(SELECT * FROM TCD.Field WHERE Label = N'No of Pumps Connected to TCR3' AND ResourceKey = N'No_of_Pumps_Connected_to_TCR3')
BEGIN
UPDATE TCD.Field SET DefaultValue = 0 WHERE Label = N'No of Pumps Connected to TCR3' AND ResourceKey = N'No_of_Pumps_Connected_to_TCR3'
END

IF EXISTS(SELECT * FROM TCD.Field WHERE Label = N'enVisionEnable' AND ResourceKey = N'enVisionEnable')
BEGIN
UPDATE TCD.Field SET DefaultValue = 1 WHERE Label = N'enVisionEnable' AND ResourceKey = N'enVisionEnable'
END

IF EXISTS(SELECT * FROM TCD.Field WHERE Label = N'Check Water flow' AND ResourceKey = N'CheckWaterflow')
BEGIN
UPDATE TCD.Field SET DefaultValue = 1 WHERE Label = N'Check Water flow' AND ResourceKey = N'CheckWaterflow'
END

IF EXISTS(SELECT * FROM TCD.Field WHERE Label = N'enVision Time out Enable' AND ResourceKey = N'enVisionTimeoutEnable')
BEGIN
UPDATE TCD.Field SET DefaultValue = 1 WHERE Label = N'enVision Time out Enable' AND ResourceKey = N'enVisionTimeoutEnable'
END

IF EXISTS(SELECT * FROM TCD.Field WHERE Label = N'Check flow leakage alarm' AND ResourceKey = N'CheckFlowLeakageAlarm')
BEGIN
UPDATE TCD.Field SET DefaultValue = 1 WHERE Label = N'Check flow leakage alarm' AND ResourceKey = N'CheckFlowLeakageAlarm'
END

 COMMIT TRANSACTION trans
 PRINT 'Records Inserted/Updated Successfully'
 
END TRY
BEGIN CATCH
 PRINT 'Error Occured'

ROLLBACK TRANSACTION trans 

END CATCH
GO

-----------------------------------Delete Script---------------------


	BEGIN TRY
	BEGIN TRANSACTION TRANS
	DECLARE @FieldId INT
	DECLARE @FieldGroupId INT

	SELECT @FieldGroupId = Id  FROM tcd.FieldGroup where Name = 'Conduit Field Group4' AND ResourceKey = 'FieldGroup_ConduitFieldGroup4' AND ControllerModelId = 7

	
	SELECT @FieldId=F.Id FROM TCD.Field as F INNER JOIN TCD.FieldGroupFieldMapping AS FGFM on F.Id=FGFM.FieldId Inner join tcd.FieldGroup as FG
				 ON FGFM.FieldGroupId=FG.Id WHERE F.Label='Check Water Flow'  AND   FG.ControllerModelId=7 AND FG.Id = @FieldGroupId


	IF EXISTS(SELECT 1 FROM TCD.FieldGroupFieldMapping where FieldId = @FieldId)
	BEGIN
		DELETE FROM TCD.FieldGroupFieldMapping where FieldId = @FieldId
		PRINT 'Field Id :' + str(@FieldId) + ' deleted.'
	END

	PRINT @FieldId
	IF EXISTS(SELECT 1 FROM TCD.Field where Id = @FieldId)
	BEGIN
		DELETE from TCD.Field where Id = @FieldId
		PRINT 'Field Id :' + str(@FieldId) + ' deleted.'	
	END

	IF @@TRANCOUNT>0
	COMMIT TRANSACTION TRANS

	END TRY
	
	BEGIN CATCH
		
	IF @@TRANCOUNT>0
	ROLLBACK TRANSACTION TRANS

	END CATCH

	GO

	---------------------------------------------------------------------------------------------------------------------
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetControllerSetupAdvanceMetaDataWithValues]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetControllerSetupAdvanceMetaDataWithValues
	END
GO
	CREATE PROCEDURE [TCD].[GetControllerSetupAdvanceMetaDataWithValues]  
(  
  @TabId INT  
 , @ControllerId INT  
 , @EcolabAccountNumber NVARCHAR(25)  
 )  
AS  
BEGIN    
SET NOCOUNT ON  
 IF OBJECT_ID('tempdb..#tmpMetaDataAdvance') IS NOT NULL  
  DROP TABLE #tmpMetaDataAdvance  
 DECLARE @AllowDefaultTagAddress BIT,  
   @ControllerModelId NVARCHAR(50) = NULL;  
 SELECT   
   @ControllerModelId = ControllerModelId  
 FROM [TCD].ConduitController  
 WHERE ControllerId = @ControllerId  
  AND EcoalabAccountNumber = @EcolabAccountNumber  
 IF NOT EXISTS(SELECT   
    1  
   FROM TCD.ControllerTags  
   WHERE ControllerId = @ControllerId  
    AND EcolabAccountNumber = @EcolabAccountNumber)  
  BEGIN  
   SET @AllowDefaultTagAddress = 'TRUE';  
  END;  
 ELSE  
  BEGIN  
   SET @AllowDefaultTagAddress = 'FALSE';  
  END;  
 SELECT DISTINCT   
   FG.Id AS FieldGroupId  
   ,FG.[NAME] AS FieldGroupName  
   ,FG.[image_Url] as FieldGroupImageUrl  
   ,FG.[helpText] as FieldGroupHelpText  
   ,FG.[ControllerModelId]  
   ,FG.[ControllerTypeId]  
   ,FGT.NAME AS FieldGroupTypeName  
   ,F.Id AS FieldId  
   ,F.Name AS FieldName  
   ,FT.Name AS FieldType  
   ,F.Label AS FieldLabel  
   ,F.[Min] AS FieldMinValue  
   ,F.[Max] AS FieldMaxValue  
   ,F.IsMandatory AS FieldIsMandatory  
   ,F.IsEditable AS FieldIsEditable  
   ,F.HelpText AS FieldHelpText  
   , F.HelpTextUrl AS FieldHelpUrl  
   ,FG.TabId AS TabIndex  
   ,DT.Name AS ControlType  
   ,F.DataSourceId AS DataSourceId  
   ,(SELECT   
      FS.Value + ':' + FS.Name + ';'  
     FROM TCD.FieldSource FS  
     WHERE FS.DataSourceId = F.DataSourceId  
     FOR XML PATH( '' )  
   )AS DataSourceKeyValue   
   ,F.DataCategoryId AS DataCategoryId  
   ,F.DefaultValue  
   ,F.CurrencyId AS FieldCurrencyCode  
   ,F.ResourceKey AS FieldResourceKey  
   ,FG.ResourceKey AS FieldGroupResourceKey  
   ,FG.DisplayOrder AS FieldGroupDO  
   ,F.DisplayOrder AS FieldDO   
   ,CSD.ControllerId  
   ,FRM.RoleId AS AccessToRole  
   ,F.HasFieldTag AS HasFieldTag  
   , (  
    SELECT   
      TagAddress  
     FROM TCD.ControllerTags  
     WHERE TagType = F.HasFieldTag  
      AND ControllerId = @ControllerId  
      AND Active = 1  
      AND EcolabAccountNumber = @EcolabAccountNumber) AS TagDefaultValue  
   ,F.ClassName AS ClassName  
   ,CC.ControllerVersion  
   ,0 IsDosingLineConsumed  
 INTO #tmpMetaDataAdvance  
 FROM [TCD].[FieldGroup] FG  
 INNER JOIN [TCD].[FieldGroupFieldMapping] FGFM ON FG.Id = FGFM.FieldGroupId  
 INNER JOIN [TCD].[Field] F ON F.Id = FGFM.FieldId  
 LEFT JOIN [TCD].[FieldGroupType] FGT ON FGT.Id = FG.FieldGroupTypeId  
 LEFT JOIN [TCD].FieldType FT ON FT.Id = F.TypeId   
 LEFT JOIN [TCD].DataType DT ON DT.Id = F.DataTypeId  
 LEFT JOIN [TCD].[FieldRoleMapping] FRM ON FRM.FieldId = F.Id  
  
 INNER JOIN [TCD].[ConduitController] CC ON CC.ControllerModelId = FG.ControllerModelId AND CC.ControllerTypeId = FG.ControllerTypeId AND cc.EcoalabAccountNumber = @EcolabAccountNumber  
  
 INNER JOIN [TCD].[ControllerSetupData] CSD ON CSD.ControllerId = CC.ControllerId AND CSD.EcolabAccountNumber = @EcolabAccountNumber  
 WHERE   
 CC.ControllerId = @ControllerId  
 AND  
 FG.TabId = @TabId  
 AND   
 CC.EcoalabAccountNumber = @EcolabAccountNumber  
 AND F.Label NOT LIKE  
   CASE @ControllerModelId  
    WHEN 3 THEN 'Automatic Weight Enabled'  
    ELSE  ''  
   END  
  AND F.Label NOT LIKE  
   CASE @ControllerModelId  
    WHEN 3 THEN  'Ratio Dosing Enabled'  
    ELSE    ''  
   END  
   AND F.Label NOT LIKE  
   CASE @ControllerModelId  
    WHEN 3 THEN 'Preflush Time(sec)'  
    ELSE  ''  
   END 
   AND F.Label NOT LIKE  
   CASE @ControllerModelId  
    WHEN 3 THEN 'Postflush Time(sec)'  
    ELSE  ''
   END 
  
 UPDATE tmd SET DefaultValue = CSD.Value  
  FROM #tmpMetaDataAdvance tmd  
  INNER JOIN [TCD].ControllerSetupData CSD ON  tmd.ControllerId = CSD.ControllerId   
   AND CSD.EcolabAccountNumber = @EcolabAccountNumber  
   AND tmd.FieldGroupId = CSD.FieldGroupId   
   AND tmd.FieldId = CSD.FieldId   
  
  
update MDA set IsDosingLineConsumed =1  
FROM  #tmpMetaDataAdvance MDA  
inner join [TCD].[ControllerEquipmentSetUp] CES on MDA.ControllerId=CES.ControllerId  and IsActive=1  
where  LTRIM(rtrim( FieldResourceKey))='No_of_Pumps_Connected_to_TCR1'   
and CES.LineNumber >= 1 and CES.LineNumber <= (case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)  
and CES.ControllerEquipmentId >= 1 and CES.ControllerEquipmentId <= (case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)  
  
   
update MDA set IsDosingLineConsumed =1  
FROM  #tmpMetaDataAdvance MDA  
inner join [TCD].[ControllerEquipmentSetUp] CES on MDA.ControllerId=CES.ControllerId  and IsActive=1  
where  LTRIM(rtrim( FieldResourceKey))='No_of_Pumps_Connected_to_TCR2'   
and CES.LineNumber >= (case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end) and CES.LineNumber <= ((case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)*2)  
and CES.ControllerEquipmentId >= (case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end) and CES.ControllerEquipmentId <= ((case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)*2)  
  
update MDA set IsDosingLineConsumed =1  
FROM  #tmpMetaDataAdvance MDA  
inner join [TCD].[ControllerEquipmentSetUp] CES on MDA.ControllerId=CES.ControllerId  and IsActive=1  
where  LTRIM(rtrim( FieldResourceKey))='No_of_Pumps_Connected_to_TCR3'   
and CES.LineNumber >= ((case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)*2) and CES.LineNumber <= ((case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)*3)  
and CES.ControllerEquipmentId >=  ((case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)*2) and CES.ControllerEquipmentId <= ((case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)*3
)  
  
update MDA set IsDosingLineConsumed = (select IsDosingLineConsumed from #tmpMetaDataAdvance where  LTRIM(rtrim( FieldResourceKey))='No_of_Pumps_Connected_to_TCR1' )  
FROM  #tmpMetaDataAdvance MDA  
where  LTRIM(rtrim( FieldResourceKey)) in( 'Dosing_Line_Mode1' ,'Enable_Auxiliary_pump1','Flow-meter_for_Flow_check1')  
  
update MDA set IsDosingLineConsumed = (select IsDosingLineConsumed from #tmpMetaDataAdvance where  LTRIM(rtrim( FieldResourceKey))='No_of_Pumps_Connected_to_TCR2' )  
FROM  #tmpMetaDataAdvance MDA  
where  LTRIM(rtrim( FieldResourceKey)) in( 'Dosing_Line_Mode2','Enable_Auxiliary_pump2','meter_for_Flow_check2')  
  
update MDA set IsDosingLineConsumed = (select IsDosingLineConsumed from #tmpMetaDataAdvance where  LTRIM(rtrim( FieldResourceKey))='No_of_Pumps_Connected_to_TCR3' )  
FROM  #tmpMetaDataAdvance MDA  
where  LTRIM(rtrim( FieldResourceKey)) in( 'Dosing_Line_Mode3','Enable_Auxiliary_pump3','meter_for_Flow_check3')   
  
 SELECT   
  CC.Name AS ControllerName  
  ,FieldGroupId  
  ,FieldGroupName  
  ,FieldGroupImageUrl  
  ,FieldGroupHelpText  
  ,#tmpMetaDataAdvance.ControllerModelId  
  ,#tmpMetaDataAdvance.ControllerTypeId  
  ,FieldGroupTypeName  
  ,FieldId  
  ,FieldName  
  ,FieldType  
  ,FieldLabel  
  ,FieldMinValue  
  ,FieldMaxValue  
  ,FieldIsMandatory  
  ,FieldIsEditable  
  ,FieldHelpText  
  ,FieldHelpUrl  
  ,TabIndex  
  ,ControlType  
  ,DataSourceId  
  ,DataSourceKeyValue  
  ,DataCategoryId  
  ,#tmpMetaDataAdvance.DefaultValue As DefaultValue  
  ,FieldCurrencyCode  
  ,FieldResourceKey  
  ,FieldGroupResourceKey  
  ,FieldGroupDO  
  ,FieldDO   
  ,#tmpMetaDataAdvance.AccessToRole  
  ,'Edit' AS Mode  
  ,HasFieldTag  
  ,TagDefaultValue   
  ,ClassName  
  ,#tmpMetaDataAdvance.ControllerVersion  
  ,CAST (IsDosingLineConsumed as bit) IsDosingLineConsumed  
 FROM #tmpMetaDataAdvance  
 INNER JOIN [TCD].ConduitController CC on #tmpMetaDataAdvance.ControllerId = CC.ControllerId  AND CC.EcoalabAccountNumber = @EcolabAccountNumber  
 ORDER BY FieldGroupDO , FieldDO, FieldId   
SET NOCOUNT OFF  
END
GO
----------------------------
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[SavePlantMeterDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.SavePlantMeterDetails
	END
GO

CREATE PROCEDURE [TCD].[SavePlantMeterDetails] (
@MeterNumber NVARCHAR(100) = NULL
, @EcolabAccountNumber NVARCHAR(25) = NULL
, @MeterName NVARCHAR(100) = NULL
, @Uitiliy NVARCHAR(100) = NULL
, @UtilityLocation NVARCHAR(100) = NULL
, @MachineCompartment NVARCHAR(100) = NULL
, @Parent NVARCHAR(100) = NULL
, @Calibration NVARCHAR(100) = NULL
, @UOFfoRCalibration NVARCHAR(100) = NULL
, @Usagefactor NVARCHAR(100) = NULL
, @ControllerID INT
, @ControllerModelID INT
, @DigitalInputNumber NVARCHAR(100) = NULL
, @AllowmanualEntry  NVARCHAR(100) = NULL
, @Meterrolloverpoint VARCHAR(100) = NULL
, @UserID INT
, @Scope VARCHAR(100) OUTPUT
, @OutputMeterId	INT = NULL	OUTPUT
, @LastModifiedTimestampAtCentral DATETIME = NULL
, @OutputLastModifiedTimestampAtLocal	DATETIME = NULL OUTPUT
, @WaterType INT = NULL
, @WaterTypeFromFormulaSetup BIT
, @CounterNum INT
, @CounterUsage BIT
, @RunningTimeUsage BIT
, @CounterAlarmValue INT
, @RunningTimeAlarmValue INT
, @ExternalCounter		INT
)
AS
BEGIN
    SET NOCOUNT ON;
    SET @Scope = '';
    DECLARE
	    @IsPlant BIT = NULL,
	    @IsPress BIT = NULL;
    DECLARE
	    @ReturnValue					INT = 0
	    ,@ErrorId						INT = 0
	    ,@ErrorMessage					NVARCHAR(4000) = N''
	    ,@CurrentUTCTime					DATETIME = GETUTCDATE();
    DECLARE
	    @OutputList						AS	TABLE		(
	    MeterId							INT
	    ,LastModifiedTimestamp			DATETIME
	    );
    SET		@OutputLastModifiedTimestampAtLocal = ISNULL(@OutputLastModifiedTimestampAtLocal, NULL);
    SET		@OutputMeterId = ISNULL(@OutputMeterId, NULL);

    /* Business vaidations for setingup the meters to controllers */

    IF	@LastModifiedTimestampAtCentral   IS NOT NULL
	 AND NOT	EXISTS	(	SELECT	1
						  FROM	TCD.Meter		M
						  WHERE	M.EcolabAccountNumber = @EcolabAccountNumber
							 AND M.MeterId = @MeterNumber
							 AND M.LastModifiedTime = @LastModifiedTimestampAtCentral
		)
	   BEGIN
		  SET			@ErrorId = 60000;
		  SET			@ErrorMessage = N''
									 +
									 CAST(@ErrorId AS NVARCHAR);
		  RAISERROR	(@ErrorMessage, 16, 1);
		  SET			@ReturnValue = -1;
		  RETURN
		  @ReturnValue;
	   END;

    -- Begin Defining Limits

    BEGIN
	   DECLARE
		   @UtilityLimit INT = NULL,
		   @WasherLimit INT = NULL,
		   @TunnelLimit INT = NULL,
		   @IStunnel BIT,
		   @MeterNameLimit INT = NULL;

	 SELECT @MeterNameLimit = COUNT(1)
		FROM TCD.Meter 
		WHERE [Description] = @MeterName 
		AND EcolabAccountNumber = @EcolabAccountNumber
		AND Is_deleted = 0

	 
	   SELECT @UtilityLimit = COUNT(1)
		FROM TCD.meter
		WHERE GroupId = @UtilityLocation
		  AND UtilityType = @Uitiliy
		  AND ISNULL(MachineCompartment, 0) = @MachineCompartment
		  AND Is_deleted = 0
		  AND EcolabAccountNumber = @EcolabAccountNumber
		  AND ControllerID IN (
			 SELECT ControllerId
			   FROM TCD.ConduitController
			   WHERE ControllerId = @ControllerID
				AND EcoalabAccountNumber = @EcolabAccountNumber);
	   SELECT @WasherLimit = COUNT(1)
		FROM TCD.Meter M
			LEFT OUTER JOIN
			TCD.machinesetup MS ON M.GroupId = MS.groupId
						    AND M.MachineCompartment = MS.MachineInternalID
		WHERE M.UtilityType = 2
		  AND M.GroupID = @UtilityLocation
		  AND Is_deleted = 0
		  AND EcolabAccountNumber = @EcolabAccountNumber
		  AND M.ControllerID IN (
			 SELECT ControllerId
			   FROM TCD.ConduitController
			   WHERE ControllerModelId = 7
				AND EcoalabAccountNumber = @EcolabAccountNumber);
	   SELECT @TunnelLimit = COUNT(1)
		FROM TCD.Meter M
			LEFT OUTER JOIN
			TCD.machinesetup MS ON M.GroupId = MS.groupId
		WHERE M.UtilityType = 2
		  AND M.GroupID = @UtilityLocation
		  AND Ms.Istunnel = 1
		  AND Is_deleted = 0
		  AND EcoalabAccountNumber = @EcolabAccountNumber
		  AND M.ControllerID IN (
			 SELECT ControllerId
			   FROM TCD.ConduitController
			   WHERE ControllerModelId = 7
				AND EcoalabAccountNumber = @EcolabAccountNumber);
	   SELECT @IStunnel = Istunnel
		FROM TCD.machinesetup MS
		WHERE Ms.GroupId = @UtilityLocation
		  AND EcoalabAccountNumber = @EcolabAccountNumber;
    END;

    -- End Defining Limits

    IF @IStunnel = 1
        BEGIN				
            IF @MachineCompartment = 1
                BEGIN
                    SET @IsPress = 1;
                END;
		IF @MachineCompartment = 0
            BEGIN
			SET @MachineCompartment = NULL;
			END
        END;

    IF @UtilityLocation = 1
	   BEGIN
		  SET @IsPlant = 1;
		  SET @UtilityLocation = NULL;
		  SET @MachineCompartment = NULL;
	   END;
    IF @ControllerID = -1
	   BEGIN
		  SELECT TOP (1) @ControllerID = ControllerID
		    FROM TCD.ConduitController
		    WHERE ControllerModelId = @ControllerModelID
			 AND EcoalabAccountNumber = @EcolabAccountNumber;
	   END;
    ELSE
	   BEGIN
		  SELECT @ControllerModelID = ControllerModelId
		    FROM TCD.ConduitController
		    WHERE ControllerId = @ControllerID
			 AND EcoalabAccountNumber = @EcolabAccountNumber;
	   END;
    IF @ControllerID != -1
	   BEGIN
		  DECLARE
			  @NewMeterId INT
			  ,@TagType VARCHAR(50) = 'Tag_MPLC'
			  ,@ModuleTypeId INT = 2
			  ,@Result INT = NULL
			  ,@Type INT = 2
			  ,@AllowTagEdit BIT;
		  SELECT @AllowTagEdit = CASE
							WHEN COUNT(*) > 0 THEN 'TRUE'
							    ELSE 'FALSE'
							END
		    FROM TCD.UserMaster UM
			    INNER JOIN
			    TCD.UserInRole UIR ON UM.UserId = UIR.UserId
			    INNER JOIN
			    TCD.UserRoles UR ON UIR.RoleId = UR.RoleId
		    WHERE UM.UserId = @UserID
			 AND UR.LevelId >= 8;
		  IF NOT EXISTS (SELECT 1
					    FROM   TCD.Meter
					    WHERE  MeterID = @MeterNumber
						  AND EcolabAccountNumber = @EcolabAccountNumber)

			 -- Begin Create Meter

			 BEGIN

					   DECLARE @AllowInsert BIT = 'FALSE';

					   -- Begin Business Validations
					   IF @MeterNameLimit < 1
					   	   BEGIN
							   IF @UtilityLimit < 1 OR @Uitiliy = 2
								  BEGIN
								 	 		 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 		 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 IF @ControllerModelID = 7
								BEGIN
													
								    IF @UtilityLimit >= 1 AND @Uitiliy != 2
									   BEGIN
										  SET @Scope = @Scope + '301,';										 
									   END;
								    IF @Uitiliy = 2 AND @IStunnel = 1
									   BEGIN   										
									IF @UtilityLimit >= 1
									   BEGIN
										  SET @Scope = @Scope + '301,';										  
									   END;									 
										ELSE IF @TunnelLimit < 6
											BEGIN											
												SET @AllowInsert = 'TRUE';
											END;
										ELSE
											BEGIN											
												SET @Scope = @Scope + '101,';
											END;
										END;
									ELSE IF @Uitiliy = 2 AND @IStunnel != 1
									   BEGIN		
										 IF @WasherLimit < 2
											BEGIN
												SET @AllowInsert = 'TRUE';												
											END;
										ELSE
											BEGIN
												SET @Scope = @Scope + '201,';												
											END;
										END;									   
								    ELSE
									   BEGIN
										  SET @AllowInsert = 'TRUE';										  
									   END;
								END;
							 ELSE
								BEGIN
								    SET @AllowInsert = 'TRUE';									
								END;
								  END;
							   ELSE
								  BEGIN
									 SET @Scope = @Scope + '301,';									 
							   END;
			               END;
						ELSE
							BEGIN
								SET @Scope = @Scope + '302,';								
							END;
						
						IF @Uitiliy = 12
						 BEGIN
							SET @AllowInsert = 'TRUE';
							SET @Scope = '';
						 END;						


					   -- End Business Validations
					   -- Begin Insert if Validation Succeeds

					   IF @AllowInsert = 'TRUE'
						  BEGIN
							 INSERT INTO TCD.Meter (EcolabAccountNumber,
											    Description,
											    UtilityType,
											    GroupId,
											    MachineCompartment,
											    MaxValueLimit,
											    MeterTickUnit,
											    UsageFactor,
											    ControllerID,
											    Parent,
											    Calibration,
											    AllowManualentry ,
											    LastModifiedByUserId,
											    IsPlant,
											    IsPress,
												WaterType,
												WaterTypeFromFormulaSetup,
												CounterNum,
												CounterUsage,
												RunningTimeUsage,
												CounterAlarmValue,
												RunningTimeAlarmValue,
												DigitalInputNumber)
							 OUTPUT
							 inserted.MeterId				AS MeterId
							 ,inserted.LastModifiedTime		AS LastModifiedTimestamp
								   INTO
								   @OutputList	(
								   MeterId
								   ,LastModifiedTimestamp
								   )
							 SELECT
							 @EcolabAccountNumber,
							 @MeterName,
							 @Uitiliy,
							 @UtilityLocation,
							 @MachineCompartment,
							 @Meterrolloverpoint,
							 @UOFfoRCalibration,
							 @Usagefactor,
							 @ControllerID,
							 @Parent,
							 @Calibration,
							 @AllowmanualEntry,
							 @UserID,
							 @IsPlant,
							 @IsPress,
							 @WaterType,
							 @WaterTypeFromFormulaSetup,
							 @CounterNum,
							 @CounterUsage,
							 @RunningTimeUsage,
							 @CounterAlarmValue,
							 @RunningTimeAlarmValue,
							 @ExternalCounter;
							 IF @AllowTagEdit = 'TRUE'
								BEGIN
								    IF @Result IS NOT NULL
									   BEGIN
										  SET @NewMeterId = SCOPE_IDENTITY();
										  INSERT INTO TCD.ModuleTags (EcolabAccountNumber,
																TagType,
																TagAddress,
																ModuleTypeId,
																ModuleID,
																DeadBand,
																Active)
										  VALUES(@EcolabAccountNumber,
											    @TagType,
											    @DigitalInputNumber,
											    @ModuleTypeId,
											    @NewMeterId,
											    20,
											    1);
									   END;
								END;
						  END;

				    -- End Insert if Validation Succeeds

				  --  END;
				ELSE
				    BEGIN
					   SET @Scope = @Scope + '802,';
				    END;
			 END;

		  --End Create Meter
		  ELSE

			 -- Begin Update Meter

			 BEGIN
				DECLARE
					@PlantId INT = (SELECT MG.Id
								   FROM TCD.MachineGroupType MGT
									   INNER JOIN
									   TCD.MachineGroup MG ON MGT.Id = MG.GroupTypeId
								   WHERE MGT.Id = 1
									AND MG.Is_Deleted = 0);

				-- Check RedFlag Association and Update Meter

				IF((SELECT COALESCE(  M.GroupId, '')
					 FROM TCD.Meter M
					 WHERE M.MeterId = @MeterNumber) != COALESCE(@UtilityLocation, '')
				OR (SELECT COALESCE(  M.MachineCompartment  , '')
					 FROM TCD.Meter M
					 WHERE M.MeterId = @MeterNumber) != COALESCE(@MachineCompartment, '')  )
			   AND EXISTS(SELECT 1
						 FROM TCD.RedFlag RF
							 INNER JOIN
							 TCD.RedFlagMappingData RFM ON RF.Id = RFM.MappingId
												  AND RF.Is_Deleted = 0
												  AND RFM.Is_Deleted = 0
							 LEFT JOIN
							 TCD.Meter M ON RF.Location = CASE M.IsPlant
													WHEN 'TRUE' THEN COALESCE(  M.GroupId , @PlantId)
													    ELSE M.GroupId
													END
									  AND COALESCE(  M.MachineCompartment , 0) = COALESCE(  RFM.MachineId , 0)
									  AND M.Is_deleted = 0
						 WHERE M.MeterId = @MeterNumber)
				    BEGIN
					   SET @Scope = '405,';
				    END;
				ELSE
				    BEGIN
					   DECLARE
						   @AllowUpdate BIT = 'FALSE';
							 --Begin Get old Meter Values 

							 BEGIN
								DECLARE
									@Uty INT = (SELECT UtilityType
											    FROM TCD.Meter
											    WHERE MeterID = @MeterNumber
												 AND EcolabAccountNumber = @EcolabAccountNumber);
								DECLARE
									@grpId INT = (SELECT GroupId
												 FROM TCD.Meter
												 WHERE MeterID = @MeterNumber
												   AND EcolabAccountNumber = @EcolabAccountNumber);
								DECLARE
									@machId INT = (SELECT MachineCompartment
												  FROM TCD.Meter
												  WHERE MeterID = @MeterNumber
												    AND EcolabAccountNumber = @EcolabAccountNumber);
								DECLARE
								    @Mname INT =(SELECT COUNT(1) 
													FROM TCD.Meter 
													WHERE [Description] = @MeterName
														AND MeterId <> @MeterNumber
														AND EcolabAccountNumber = @EcolabAccountNumber
														AND Is_deleted = 0);
							 END;

							 --End Get old Meter Values

							 IF @AllowTagEdit = 'TRUE'
								BEGIN
								    IF @DigitalInputNumber IS NOT NULL
									   BEGIN
										  EXEC @Result = TCD.CheckDuplicateTag @DigitalInputNumber, @ControllerID, @MeterNumber, @Type;
									   END;
								END;

							 -- Begin Business Validations
							
							IF @Mname < 1
							Begin
							  IF @uty <> @Uitiliy
							 OR @grpId <> @UtilityLocation
							 OR @machId <> @MachineCompartment
								BEGIN
								    IF @UtilityLimit < 1
									   BEGIN
										  IF @ControllerModelID = 7
											 BEGIN

												/* Inserting the Details of meter in to Meter table if it is new meter */

												IF @Uitiliy = 2
												    BEGIN
													   IF @IStunnel = 'TRUE'
														  BEGIN
															 IF @TunnelLimit < 6
															 OR @TunnelLimit < = 6
															AND @uty = @Uitiliy
															AND @grpId = @UtilityLocation
																BEGIN
																    SET @AllowUpdate = 'TRUE';
																END;
															 ELSE
																BEGIN
																    SET @Scope = @Scope + '101,';
																END;
														  END;
													   ELSE
														  BEGIN
															 IF @WasherLimit < 2
															 OR @WasherLimit < = 2
															AND @uty = @Uitiliy
															AND @grpId = @UtilityLocation
																BEGIN
																    SET @AllowUpdate = 'TRUE';
																END;
															 ELSE
																BEGIN
																    SET @AllowUpdate = 'FALSE';
																    SET @Scope = @Scope + '201,';
																END;
														  END;
												    END;
												ELSE
												    BEGIN
													   SET @AllowUpdate = 'TRUE';
												    END;
											 END;
										  ELSE
											 BEGIN
												SET @AllowUpdate = 'TRUE';
											 END;
									   END;
								    ELSE
									   BEGIN
										  SET @Scope = @Scope + '301,';
									   END;
								END;
							 ELSE
								BEGIN
								    SET @AllowUpdate = 'TRUE';
								END;
								END;
								ELSE
								BEGIN
								 SET @Scope = @Scope + '302,';
								END;

							 -- End Business Validations 
							 -- Begin Update if Validation Succeeds

							 IF @AllowUpdate = 'TRUE'
								BEGIN
								    UPDATE P
									 SET  Description = @MeterName,
										 UtilityType = @Uitiliy,
										 GroupId = @UtilityLocation,
										 MachineCompartment = @MachineCompartment,
										 Parent = @Parent,
										 Calibration = @Calibration,
										 ControllerID = @ControllerID,
										 MeterTickUnit = @UOFfoRCalibration,
										 UsageFactor = @Usagefactor,
										 AllowmanualEntry = @AllowmanualEntry,
										 Maxvaluelimit = @Meterrolloverpoint,
										 IsPlant = @IsPlant,
										 IsPress = @IsPress,
										 LastModifiedByUserId = @UserID,
										 LastModifiedTime = @CurrentUTCTime,
										 WaterType = @WaterType,
										 WaterTypeFromFormulaSetup = @WaterTypeFromFormulaSetup,
										 CounterNum = @CounterNum,
										 CounterUsage = @CounterUsage,
										 RunningTimeUsage = @RunningTimeUsage,
										 CounterAlarmValue = @CounterAlarmValue,
										 RunningTimeAlarmValue = @RunningTimeAlarmValue,
										 DigitalInputNumber = @ExternalCounter
								    OUTPUT
								    inserted.MeterId				AS MeterId
								    ,inserted.LastModifiedTime		AS LastModifiedTimestamp
										 INTO
										 @OutputList(
										 MeterId ,
										 LastModifiedTimestamp
										 )
									 FROM   TCD.Meter P
									 WHERE MeterID = @MeterNumber
									   AND EcolabAccountNumber = @EcolabAccountNumber;
								   
								--END;

						  -- End Update if Validation Succeeds 

						  END;
					
				    END;
			 END;

	   -- End Update Meter

	   END;
    ELSE
	   BEGIN
		  SET @Scope = '701,';
	   END;
    SET NOCOUNT OFF;
    SELECT	TOP 1
    @OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp
    ,@OutputMeterId = O.MeterId
	 FROM @OutputList O;
    RETURN @ReturnValue;
END;
GO

-------------------------------------
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[SavePlantSensorDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.SavePlantSensorDetails
	END
GO

CREATE PROCEDURE TCD.SavePlantSensorDetails(
      @SensorNumber NVARCHAR( 100) = NULL,
      @EcolabAccountNumber NVARCHAR( 25) = NULL,
      @ControllerID VARCHAR( 1000) = NULL,
      @SensorName NVARCHAR( 100) = NULL,
      @SensorType NVARCHAR( 100) = NULL,
      @SensorLocation NVARCHAR( 100) = NULL,
      @MachineCompartment NVARCHAR( 100) = NULL,
      @OutputType NVARCHAR( 100) = NULL,
      @ChemicalforChart NVARCHAR( 100)= NULL,
      @UOM NVARCHAR( 100) = NULL,
      @DashboardActualValue VARCHAR( 100) = NULL,
      @UserID INT,
      @AnalogueInputNumber NVARCHAR( 100) = NULL,
      @Calibration4mA DECIMAL( 18, 2) = NULL,
      @Calibration20mA DECIMAL( 18, 2) = NULL,
      @TagAddress4mA NVARCHAR( 100) = NULL,
      @TagAddress20mA NVARCHAR( 100) = NULL,
      @Scope VARCHAR( 100)OUTPUT,
      @OutputSensorId INT = NULL OUTPUT,
      @LastModifiedTimestampAtCentral DATETIME = NULL,
      @OutputLastModifiedTimestampAtLocal DATETIME = NULL OUTPUT,
	  @SensorNum INT,
	  @AlarmEnable BIT,
	  @MinimumAlarmValue INT,
	  @MaximumAlarmValue INT,
	  @ExternalSensor INT)
AS
     BEGIN
         SET NOCOUNT ON;
         DECLARE @IsPlant BIT = NULL,
         @IsPress BIT = NULL,
         @IStunnel INT = '';
         DECLARE @TypeLimit INT = NULL,
         @TempLimit INT = NULL,
         @pHLimit INT = NULL,
         @ConductivityLimit INT = NULL,
         @WeightLimit INT = NULL,
		 @RedoxLimit INT = NULL,
         @ControllerModelID INT = NULL;
         DECLARE @ReturnValue INT = 0,
         @ErrorId INT = 0,
         @ErrorMessage NVARCHAR( 4000) = N'',
         @CurrentUTCTime DATETIME = GETUTCDATE();
         DECLARE @OutputList AS TABLE( SensorId INT,LastModifiedTimestamp DATETIME);
         SET @OutputLastModifiedTimestampAtLocal = ISNULL( @OutputLastModifiedTimestampAtLocal, NULL);

         --SQLEnlight

         SET @OutputSensorId = ISNULL( @OutputSensorId, NULL);

         /*Maximum one Sensor with the same type can be connected to one machine/Compartement */

         IF @LastModifiedTimestampAtCentral IS NOT NULL
            AND
            NOT EXISTS( SELECT 1
                        FROM TCD.Sensor AS S
                        WHERE S.EcolabAccountNumber = @EcolabAccountNumber
                              AND
                              S.SensorId = @SensorNumber
                              AND
                              S.LastModifiedTime = @LastModifiedTimestampAtCentral
                      )
             BEGIN
                 SET @ErrorId = 60000;
                 SET @ErrorMessage = N'' + CAST( @ErrorId AS NVARCHAR);
                 RAISERROR( @ErrorMessage, 16, 1);
                 SET @ReturnValue = -1;
                 RETURN @ReturnValue;
             END;
         SET @Scope = '';
         SELECT @TypeLimit = COUNT( 1)
         FROM TCD.Sensor AS S
         WHERE GroupId = @SensorLocation
               AND
               S.SensorType = @SensorType
               AND
               ISNULL( MachineCompartment, 0) = @MachineCompartment
               AND
               Is_deleted = 0
               AND
               ControllerID IN(
               SELECT ControllerId
               FROM TCD.ConduitController
               WHERE ControllerId = @ControllerID
                     AND
                     EcoalabAccountNumber = @EcolabAccountNumber
                              )
               AND
               EcolabAccountNumber = @EcolabAccountNumber;

         /*Maximum 6 Temperature sensor can be connected to the same Washter-Tunnel */

         SELECT @TempLimit = COUNT( 1)
         FROM TCD.Sensor AS S LEFT OUTER JOIN TCD.machinesetup AS MS ON S.GroupId = MS.groupId
                                                                        AND
                                                                        S.EcolabAccountNumber = MS.EcoalabAccountNumber
         WHERE S.SensorType = 1
               AND
               S.GroupID = @SensorLocation
               AND
               Ms.Istunnel = 1
               AND
    IS_deleted = 0
               AND
               S.ControllerID IN(
               SELECT ControllerId
               FROM TCD.ConduitController
               WHERE ControllerModelId = 7
                     AND
                     EcoalabAccountNumber = @EcolabAccountNumber
                                )
               AND
               S.EcolabAccountNumber = @EcolabAccountNumber;

         /* Maximum 2 pH sensor can be connected to the same Washter-Tunnel */

         SELECT @pHLimit = COUNT( 1
                                )
         FROM TCD.Sensor AS S LEFT OUTER JOIN TCD.machinesetup AS MS ON S.GroupId = MS.groupId
                                                                        AND
                                                                        S.EcolabAccountNumber = MS.EcoalabAccountNumber
         WHERE S.SensorType = 2
               AND
               S.GroupID = @SensorLocation
               AND
               Ms.Istunnel = 1
               AND
               IS_deleted = 0
               AND
               S.ControllerID IN(
               SELECT ControllerId
               FROM TCD.ConduitController
               WHERE ControllerModelId = 7
                     AND
                     EcoalabAccountNumber = @EcolabAccountNumber
                                )
               AND
               S.EcolabAccountNumber = @EcolabAccountNumber;

		/* Maximum 1 Redox sensor can be connected to the same Washter-Tunnel */

         SELECT @RedoxLimit = COUNT(1)
         FROM TCD.Sensor AS S LEFT OUTER JOIN TCD.machinesetup AS MS ON S.GroupId = MS.groupId
                                                                        AND
                                                                        S.EcolabAccountNumber = MS.EcoalabAccountNumber
         WHERE S.SensorType = 2
               AND
               S.GroupID = @SensorLocation
               AND
               Ms.Istunnel = 1
               AND
               IS_deleted = 0
               AND
               S.ControllerID IN(
               SELECT ControllerId
               FROM TCD.ConduitController
               WHERE ControllerModelId = 7
                     AND
                     EcoalabAccountNumber = @EcolabAccountNumber
                                )
               AND
               S.EcolabAccountNumber = @EcolabAccountNumber;
			   

         /* Maximum 1 Conductivity sensor can be connected to the same Washter-Tunnel */

         SELECT @ConductivityLimit = COUNT( 1)
         FROM TCD.Sensor AS S LEFT OUTER JOIN TCD.machinesetup AS MS ON S.GroupId = MS.groupId
                                                                        AND
                                                                        S.EcolabAccountNumber = MS.EcoalabAccountNumber
         WHERE S.SensorType = 4
               AND
               S.GroupID = @SensorLocation
               AND
               Ms.Istunnel = 1
               AND
               IS_deleted = 0
               AND
               S.ControllerID IN(
               SELECT ControllerId
               FROM TCD.ConduitController
               WHERE ControllerModelId = 7
                     AND
                     EcoalabAccountNumber = @EcolabAccountNumber
                                )
               AND
               S.EcolabAccountNumber = @EcolabAccountNumber;

         /* Maximum 1 Weight sensor can be connected to the same Washter-Tunnel */

         SELECT @WeightLimit = COUNT( 1)
         FROM TCD.Sensor AS S LEFT OUTER JOIN TCD.machinesetup AS MS ON S.GroupId = MS.groupId
                                                                        AND
                                                                        S.EcolabAccountNumber = MS.EcoalabAccountNumber
         WHERE S.SensorType = 5
               AND
               S.GroupID = @SensorLocation
               AND
               Ms.Istunnel = 1
               AND
               IS_deleted = 0
               AND
               S.ControllerID IN(
               SELECT ControllerId
               FROM TCD.ConduitController
               WHERE ControllerModelId = 7
                     AND
                     EcoalabAccountNumber = @EcolabAccountNumber
                                )
               AND
               S.EcolabAccountNumber = @EcolabAccountNumber;
         SELECT @ControllerModelID = ControllerModelId
         FROM TCD.ConduitController
         WHERE ControllerId = @ControllerID
               AND
               EcoalabAccountNumber = @EcolabAccountNumber;
         SELECT @IStunnel = Istunnel
         FROM TCD.machinesetup AS MS
         WHERE Ms.GroupId = @SensorLocation
               AND
               MS.EcoalabAccountNumber = @EcolabAccountNumber;
         IF @IStunnel = 1
             BEGIN				
                 IF @MachineCompartment = 1
                     BEGIN
                         SET @IsPress = 1;
                     END;
				IF @MachineCompartment = 0
                 BEGIN
					SET @MachineCompartment = NULL;
				 END
             END;
         IF @SensorLocation = 1
             BEGIN
                 SET @IsPlant = 1;
                 SET @SensorLocation = NULL;
                 SET @MachineCompartment = NULL;
             END;
         IF @ControllerID = -1
             BEGIN
                 SELECT TOP ( 1
                            )@ControllerID = ControllerID
                 FROM TCD.ConduitController
                 WHERE ControllerModelId = @ControllerModelID
                       AND
                       EcoalabAccountNumber = @EcolabAccountNumber;
             END;
         ELSE
             BEGIN
                 SELECT @ControllerModelID = ControllerModelId
                 FROM TCD.ConduitController
                 WHERE ControllerId = @ControllerID
                       AND
                       EcoalabAccountNumber = @EcolabAccountNumber;
             END;
         IF @ControllerID != -1
             BEGIN

                 /* Inserting the values in to Sensor table if it is new Sensor */

                 DECLARE @NewSensorId INT,
                 @ModuleType INT = 3,
                 @DefaultFrequency INT = 60,
                 @TagType VARCHAR( 100) = 'Tag_MPLC',
                 @TagTypeSC4 VARCHAR( 100) = 'Tag_SC4',
                 @TagTypeSC20 VARCHAR( 100) = 'Tag_SC20',
                 @Result1 INT = NULL,
                 @Result2 INT = NULL,
                 @Result3 INT = NULL,
                 @Type INT = 3,
                 @AllowTagEdit BIT;
                 SELECT @AllowTagEdit = CASE
                                            WHEN COUNT( *) > 0
                                            THEN 'TRUE'
                                            ELSE 'FALSE'
                                        END
                 FROM TCD.UserMaster AS UM INNER JOIN TCD.UserInRole AS UIR
                 ON UM.UserId = UIR.UserId
                                           INNER JOIN TCD.UserRoles AS UR
                 ON UIR.RoleId = UR.RoleId
                 WHERE UM.UserId = @UserID
                       AND
                       UR.LevelId >= 8
                       AND
                       UM.EcolabAccountNumber = @EcolabAccountNumber;
                 IF NOT EXISTS( SELECT *
                                FROM TCD.Sensor
                                WHERE SensorID = @SensorNumber
                                      AND
                                      EcolabAccountNumber = @EcolabAccountNumber
                              )

                     -- Begin Create Sensor

                     BEGIN
                         BEGIN
                             DECLARE @AllowInsert BIT = 'FALSE';
                             IF @TypeLimit < 1
                                 BEGIN
                                     IF @ControllerModelID = 7
                                         BEGIN
                                             IF @SensorType = 1
                                                 BEGIN
                                                     IF @TempLimit < 6
                                                         BEGIN
                                                             SET @AllowInsert = 'TRUE';
                                                         END;
                                                     ELSE
                                                         BEGIN
                                                             SET @SCOPE = @SCOPE + '401,';
                                                         END;
                                                 END;
                                             ELSE
                                 BEGIN
                                                     IF @SensorType = 2
                                                         BEGIN
                                                             IF @pHLimit < 2
                                                                 BEGIN
                                                                     SET @AllowInsert = 'TRUE';
                                                                 END;
                                                             ELSE
                                                                 BEGIN
                                                                     SET @SCOPE = @SCOPE + '301,';
                                                                 END;
                                                         END;
														 ELSE
														BEGIN
															IF @SensorType = 3
																BEGIN
																	IF @RedoxLimit < 1
																		BEGIN
																			SET @AllowInsert = 'TRUE';
																		END;
																	ELSE
																		BEGIN
																			SET @SCOPE = @SCOPE + '301,';
																		END;
																END;
                                                    
                                                     ELSE
                                                         BEGIN
                                                             IF @SensorType = 4
                                                                 BEGIN
                                                                     IF @ConductivityLimit < 1
                                                                         BEGIN
                                                                             SET @AllowInsert = 'TRUE';
                                                                         END;
																	ELSE
                                                                     BEGIN
                                                                         SET @SCOPE = @SCOPE + '201,';
                                                                     END;
                                                                 END;
                                                             ELSE
                                                                 BEGIN
                                                                     IF @SensorType = 5
                                                                         BEGIN
                                                                             IF @WeightLimit < 1
                                                                                 BEGIN
                                                                                     SET @AllowInsert = 'TRUE';
                                                                                 END;
                                                                             ELSE
                                                                                 BEGIN
                                                                                     SET @SCOPE = @SCOPE + '101,';
                                                                                 END;
                                                                         END;
                                                                 END;
                                                         END;
													END;
                                               END;
                                         END;
                                     ELSE
                                         BEGIN
                                             SET @AllowInsert = 'TRUE';
                                         END;
                                 END;
                             ELSE
                                 BEGIN
                                     SET @Scope = @Scope + '501,';
                                 END;

                             -- End Business Validations
                             -- Begin Insert if Validation Succeeds

                             IF @AllowInsert = 'TRUE'
                                 BEGIN
                                     DECLARE @SensorCount INT;
                                     SELECT @SensorCount = MAX( s.SensorId)+1
                                     FROM TCD.Sensor AS s WITH ( NOLOCK);
                                 
                                     INSERT INTO TCD.Sensor( Description,
                                     SensorType,
                                     GroupId,
                                     MachineCompartment,
                                     EcolabAccountNumber,
                                     ControllerID,
                                     OutputType,
                                     ChemicalforChart,
                                     UOM,
                                     DashboardActualValue,
                                     LastModifiedByUserId,
                                     IsPlant,
                                     IsPress,
                                     Calibration4mA,
                                     Calibration20mA,
                                     Id,
									 SensorNum,
									 AlarmEnable,
									 MinimumAlarmValue,
									 MaximumAlarmValue,
									 AnalogueInputNumber )                                                         
                                     OUTPUT inserted.SensorId AS SensorId,
                                     inserted.LastModifiedTime AS LastModifiedTimestamp
                                            INTO @OutputList( SensorId,
                                            LastModifiedTimestamp
                                                            )
                                     SELECT @SensorName,
                                     @SensorType,
                                     @SensorLocation,
                                     @MachineCompartment,
                                     @EcolabAccountNumber,
                                     @ControllerID,
                                     @OutputType,
                                     @ChemicalforChart,
                                     @UOM,
                                     @DashboardActualValue,
                                     @UserID,
                                     @IsPlant,
                                     @IsPress,
                                     @Calibration4mA,
                                     @Calibration20mA,
                                     @SensorCount,
									 @SensorNum,
									 @AlarmEnable,
									 @MinimumAlarmValue,
									 @MaximumAlarmValue,
									 @ExternalSensor;
                                     SET @NewSensorId = SCOPE_IDENTITY(
                                                                      );
                                 END;
                         END;
                     END;
                 ELSE

                     ------------------------------------------------------------------------------------------------------------------
                     -- Begin Update Sensor

                     BEGIN
                         DECLARE @PlantId INT = ( SELECT MG.Id
                                                  FROM TCD.MachineGroupType AS MGT INNER JOIN TCD.MachineGroup AS MG
                                                  ON MGT.Id = MG.GroupTypeId
                                                  WHERE MGT.Id = 1
                                                        AND
                                                        MG.Is_Deleted = 0
                                                );

                         -- Check RedFlag Association and Update Sensor

                         IF(( SELECT COALESCE( S.GroupId, ''
                                             )
                              FROM TCD.Sensor AS S
                              WHERE S.SensorId = @SensorNumber
                            ) != COALESCE( @SensorLocation, ''
                                         )
                            OR
                            ( SELECT COALESCE( S.MachineCompartment, ''
                                             )
                              FROM TCD.Sensor AS S
                              WHERE S.SensorId = @SensorNumber
                            ) != COALESCE( @MachineCompartment, ''
                                         ))
                           AND
                           EXISTS( SELECT 1
                                   FROM TCD.RedFlag AS RF INNER JOIN TCD.RedFlagMappingData AS RFM
                                   ON RF.Id = RFM.MappingId
                                      AND
                                      RF.Is_Deleted = 0
                                      AND
                                      RFM.Is_Deleted = 0
                                                          LEFT JOIN TCD.Sensor AS S
                                   ON RF.Location = CASE S.IsPlant
                                                        WHEN 'TRUE'
                                                        THEN COALESCE( S.GroupId, @PlantId
                                                                     )
                                                        ELSE S.GroupId
                                                    END
                                      AND
                                      COALESCE( S.MachineCompartment, 0
                                              ) = COALESCE( RFM.MachineId, 0
                                                          )
                                      AND
                                      S.Is_deleted = 0
                                   WHERE S.SensorId = @SensorNumber
                                 )
                             BEGIN
                                 SET @Scope = '405,';
                             END;
                         ELSE
                             BEGIN
                                 IF(@Result1 IS NULL
                                    OR
                                    @Result1 <> 0)
                                   AND
                                   (@Result2 IS NULL
                                    OR
                                    @Result2 <> 0)
                                   AND
                                   (@Result3 IS NULL
                                    OR
                                    @Result3 <> 0)
                                     BEGIN
                                         DECLARE @AllowUpdate BIT = 'FALSE';

                                         --Begin Get old Sensor Values

                                         BEGIN
                                             DECLARE @uty INT = ( SELECT sensortype
                                                                  FROM TCD.Sensor
                                                                  WHERE SensorID = @SensorNumber
                                                                        AND
                                                                        EcolabAccountNumber = @EcolabAccountNumber
                                                                );
                                             DECLARE @grpId INT = ( SELECT GroupId
                                                                    FROM TCD.Sensor
                                                                    WHERE SensorID = @SensorNumber
                                                                          AND
                                                                          EcolabAccountNumber = @EcolabAccountNumber
                                                                  );
                                             DECLARE @machId INT = ( SELECT MachineCompartment
                                                                     FROM TCD.Sensor
                                                                     WHERE SensorID = @SensorNumber
                                                                           AND
                                                                           EcolabAccountNumber = @EcolabAccountNumber
                                   );
                                         END;

                                         --Begin Get old Sensor Values

                                         IF @uty <> @SensorType
                                            OR
                                            @grpId <> @SensorLocation
                                            OR
                                            @machId <> @MachineCompartment
                                             BEGIN
                                                 IF @TypeLimit < 1
                                                     BEGIN
                                                         IF @ControllerModelID = 7
                                                             BEGIN
                                                                 IF @SensorType = 1
                                                                     BEGIN
                                                                         IF @TempLimit < 6
                                                                             BEGIN
                                                                                 SET @AllowUpdate = 'TRUE';
                                                                             END;
                                                                         ELSE
                                                                             BEGIN
                                                                                 SET @SCOPE = @SCOPE + '401,';
                                                                             END;
                                                                     END;
                                                                 ELSE
                                                                     BEGIN
                                                                         IF @SensorType = 2
                                                                             BEGIN
                                                                                 IF @pHLimit < 2
                                                                                     BEGIN
                                                                                         SET @AllowUpdate = 'TRUE';
                                                                                     END;
                                                                                 ELSE
                                                                                     BEGIN
                                                                                         SET @SCOPE = @SCOPE + '301,';
                                                                                     END;
                                                                             END;
																			 ELSE
																			BEGIN
																				IF @SensorType = 3
																					BEGIN
																						IF @RedoxLimit < 1
																							BEGIN
																								SET @AllowInsert = 'TRUE';
																							END;
																						ELSE
																							BEGIN
																								SET @SCOPE = @SCOPE + '301,';
																							END;
																					END;
                                                    
                                                                         ELSE
                                                                             BEGIN
                                                                                 IF @SensorType = 4
                                                                                     BEGIN
                                                                                         IF @ConductivityLimit < 1
                                                                                             BEGIN
                                                                                                 SET @AllowUpdate = 'TRUE';
                                                                                             END;
                                                                                         ELSE
                                                                                             BEGIN
																								SET @SCOPE = @SCOPE + '201,';
                                                                                             END;
                                                                                     END;
                                                                                 ELSE
                                                                                     BEGIN
                                                                                         IF @SensorType = 5
                                                                                             BEGIN
                                                                                                 IF @WeightLimit < 1
                                                                                                     BEGIN
                                                                                                         SET @AllowUpdate = 'TRUE';
                                                                                                     END;
                                                                                                 ELSE
                                                                                                     BEGIN
                                                                                                         SET @SCOPE = @SCOPE + '101,';
                                                                                                     END;
                                                                                             END;
                                                                                     END;
																				END;
                                                                           END;
                                                                     END;
                                                             END;
                                                         ELSE
                                                             BEGIN
                                                                 BEGIN
                                                                     SET @AllowUpdate = 'TRUE';
                                                                 END;
                                                             END;
                                                     END;
                                                 ELSE
                                                     BEGIN
                                                         SET @SCOPE = @SCOPE + '501,';
                                                     END;
                                             END;
                                         ELSE
                                             BEGIN
                                                 SET @AllowUpdate = 'TRUE';
                                             END;
                                         IF @AllowUpdate = 'TRUE'
                                             BEGIN
                                                 IF @LastModifiedTimestampAtCentral IS NOT NULL
                                                    AND
                                                    NOT EXISTS( SELECT 1
                                                                FROM TCD.Sensor AS S
                                                                WHERE S.EcolabAccountNumber = @EcolabAccountNumber
                                                                      AND
                                                                      S.SensorId = @SensorNumber
                                                                      AND
                                                                      S.LastModifiedTime = @LastModifiedTimestampAtCentral
           )
                                                     BEGIN
                                                         SET @ErrorId = 60000;
                                                         SET @ErrorMessage = N'' + CAST( @ErrorId AS NVARCHAR
                                                                                       ) + N': Record not in-synch between plant and central.';
                                                         RAISERROR( @ErrorMessage, 16, 1
                                                                  );
                                                         SET @ReturnValue = -1;
                                                         RETURN @ReturnValue;
                                                     END;
                                                 UPDATE s
                                                        SET Description = @SensorName,
                                                 SensorType = @SensorType,
                                                 GroupId = @SensorLocation,
                                                 MachineCompartment = @MachineCompartment,
                                                 S.ControllerID = @ControllerID,
                                                 OutputType = @OutputType,
                                                 ChemicalforChart = @ChemicalforChart,
                                                 UOM = @UOM,
                                                 DashboardActualValue = @DashboardActualValue,
                                                 LastModifiedByUserId = @UserID,
                                                 Calibration4mA = @Calibration4mA,
                                                 Calibration20mA = @Calibration20mA,
                                                 LastModifiedTime = @CurrentUTCTime,
												 SensorNum = @SensorNum,
												 AlarmEnable = @AlarmEnable,
												 MinimumAlarmValue = @MinimumAlarmValue,
												 MaximumAlarmValue = @MaximumAlarmValue,
												 AnalogueInputNumber = @ExternalSensor
                                                 OUTPUT inserted.SensorId AS SensorId,
                                                 inserted.LastModifiedTime AS LastModifiedTimestamp
                                                        INTO @OutputList( SensorId,
                                                        LastModifiedTimestamp
                                                                        )
                                                 FROM TCD.Sensor S
                                                 WHERE SensorID = @SensorNumber
                                                       AND
                                                       EcolabAccountNumber = @EcolabAccountNumber;
                                             END;
                                     END;
                             END;
                     END;

             -- End Update Sensor

             END;
         ELSE
             BEGIN
                 SELECT @Scope = '701,';
             END;
         SET NOCOUNT OFF;
         SELECT TOP 1 @OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp,
         @OutputSensorId = O.SensorId
         FROM @OutputList AS O;
         RETURN @ReturnValue;
END;
GO



IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[SaveControllerSetupData]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.SaveControllerSetupData
	END
GO

CREATE PROCEDURE [TCD].[SaveControllerSetupData] 
(
  @ControllerSetupData     XML
 , @UserId         INT
 , @ControllerId       INT      OUTPUT
 , @LastModifiedTimestampAtCentral   DATETIME = NULL
 , @OutputLastModifiedTimestampAtLocal  DATETIME = NULL OUTPUT
)
AS
BEGIN
      SET NOCOUNT ON
   
--DECLARE @ControllerId INT
DECLARE @ControllerNumber INT = NULL
DECLARE @ControllerModelId INT = NULL
DECLARE @ControllerModelName VARCHAR(50) = NULL
DECLARE @ControllerTypeId INT = NULL
DECLARE @ControllerTypeName VARCHAR(50) = NULL
DECLARE @EcolabAccountNumber NVARCHAR(25) = NULL
DECLARE @TopicName VARCHAR(1000) = NULL
DECLARE @Active BIT
DECLARE @ErrorMessage VARCHAR(200) = NULL
DECLARE @NumOfConvWasherGroups INT = NULL
DECLARE @NumOfTunnelWasherGroups INT = NULL
DECLARE @LoopCount INT = 0
DECLARE @WasherGroupName VARCHAR(100) = NULL
DECLARE @WasherGroupId INT = NULL
DECLARE @WasherGroupNumber VARCHAR(10) = NULL
DECLARE @OutputList AS TABLE (
ControllerId INT
,LastModifiedTimestamp DATETIME
  )

SET @ControllerId = ISNULL(@ControllerId, NULL) --SQLEnlight SA0121
SET @OutputLastModifiedTimestampAtLocal = ISNULL(@OutputLastModifiedTimestampAtLocal, NULL) --SQLEnlight SA0121

   SELECT @ControllerNumber = Tbl.col.value('@ControllerNumber', 'int')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)

   SELECT @ControllerModelId = Tbl.col.value('@ControllerModelId', 'int')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)

   SELECT @ControllerTypeId = Tbl.col.value('@ControllerTypeId', 'int')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)
   
   SELECT @EcolabAccountNumber = Tbl.col.value('@EcolabAccountNumber', 'varchar(1000)')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)

    SELECT @TopicName = Tbl.col.value('@TopicName', 'varchar(1000)')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)

    SELECT @Active = Tbl.col.value('@Active', 'bit')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)
   
IF EXISTS (
SELECT 1
FROM [TCD].ConduitController WITH (NOLOCK)
WHERE ControllerNumber = @ControllerNumber
AND IsDeleted = 0
AND EcoalabAccountNumber = @EcolabAccountNumber
)
   BEGIN
SET @ErrorMessage = '303 - Controller Number already exists.'

RAISERROR (
@ErrorMessage
,16
,1
)

   RETURN
   END

IF EXISTS (
SELECT 1
FROM [TCD].ConduitController WITH (NOLOCK)
WHERE TopicName = @TopicName
AND IsDeleted = 0
AND EcoalabAccountNumber = @EcolabAccountNumber
)
BEGIN
SET @ErrorMessage = '304 - Controller Name already exists.'

RAISERROR (
@ErrorMessage
,16
,1
        )

RETURN
END




SELECT @ControllerModelName = Name
FROM [TCD].ControllerModel WITH (NOLOCK)
WHERE Id = @ControllerModelId

SELECT @ControllerTypeName = Name
FROM [TCD].ControllerType WITH (NOLOCK)
WHERE Id = @ControllerTypeId

DECLARE @TempMaster TABLE (
EcolabAccountNumber NVARCHAR(25)
,NAME VARCHAR(100)
,ControllerModelId INT
,ControllerNumber INT
,ControllerTypeId INT
,ControllerVersion VARCHAR(10)
,InstallDate DATETIME
,UserId INT
,TopicName VARCHAR(1000)
,Active BIT
        )
DECLARE @TempDynamic TABLE (
EcolabAccountNumber NVARCHAR(25)
,ControllerId INT
,ControllerModelId INT
,FieldGroupId INT
,FieldId INT
,Value VARCHAR(1000)
,UserId INT
)


INSERT INTO @TempDynamic (
EcolabAccountNumber
,ControllerId
,ControllerModelId
,FieldGroupId
,FieldId
,Value
,UserId
)
SELECT @EcolabAccountNumber
,0
,Tbl.col.value('@ControllerModelId', 'int')
,Tbl.col.value('@FieldGroupId', 'int')
,Tbl.col.value('@FieldId', 'int')
,Tbl.col.value('@Value', 'varchar(1000)')
,@UserId
FROM @ControllerSetupData.nodes('/ControllerSetupData/DynamicSetupData/Data') AS Tbl(col)

DECLARE @TempFieldId INT
DECLARE @TempValue VARCHAR(1000)


SELECT @TempFieldId=FieldId,@TempValue=Value FROM @TempDynamic WHERE FieldId in (21,22,47,48,87,98,116,130,148,150,171,192,208,269,309,348,387,400,414,426,438,449,460)


IF EXISTS ( SELECT 1
            FROM  [TCD].ConduitController CC WITH (NOLOCK) 
			INNER JOIN [TCD].ControllerSetupData CSD ON cc.ControllerId=csd.ControllerId 
			AND CC.Active=1
			and CSD.FieldId=@TempFieldId
			and CSD.Value =@TempValue
			and CC.ControllerTypeId=@ControllerTypeId
			and CC.ControllerModelId=@ControllerModelId
			and CC.EcoalabAccountNumber=@EcolabAccountNumber)
BEGIN
SET @ErrorMessage = '305 -IP Address/AMS Net ID Address already exists.'

RAISERROR (
@ErrorMessage
,16
,1
)

RETURN
END

 BEGIN TRANSACTION

  BEGIN TRY
INSERT INTO @TempMaster (
      EcolabAccountNumber
,NAME
,ControllerModelId
,ControllerNumber
,ControllerTypeId
,ControllerVersion
,InstallDate
,UserId
,TopicName
,Active
     )
SELECT @EcolabAccountNumber
,CAST(Tbl.col.value('@ControllerNumber', 'int') AS VARCHAR(10)) + ' (' + Tbl.col.value('@TopicName', 'varchar(100)') + ')'
    ,Tbl.col.value('@ControllerModelId', 'int')
    ,Tbl.col.value('@ControllerNumber', 'int')
    ,Tbl.col.value('@ControllerTypeId', 'varchar(100)')
    ,Tbl.col.value('@ControllerVersion', 'varchar(10)')
    ,CAST(Tbl.col.value('@InstallDate', 'datetime') AS DATETIME)
    ,@UserId
    ,Tbl.col.value('@TopicName', 'varchar(100)')
,Tbl.col.value('@Active', 'bit')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)

INSERT INTO [TCD].ConduitController (
EcoalabAccountNumber
,Name
,ControllerModelId
,ControllerNumber
,ControllerTypeId
,ControllerVersion
,InstallDate
,TopicName
,Active
,LastModifiedByUserId
    )
OUTPUT inserted.ControllerId AS ControllerId
,inserted.LastModifiedTime AS LastModifiedTimestamp
INTO @OutputList(ControllerId, LastModifiedTimestamp)
SELECT EcolabAccountNumber
,NAME
,ControllerModelId
,ControllerNumber
,ControllerTypeId
,ControllerVersion
,InstallDate
,TopicName
,Active
,UserId
FROM @TempMaster
   
SELECT TOP 1 @ControllerId = O.ControllerId
FROM @OutputList O

update @TempDynamic set ControllerId=@ControllerId

INSERT INTO [TCD].ControllerSetupData (
       EcolabAccountNumber
,ControllerId
,FieldGroupId
,FieldId
,Value
,ControllerModelId
,LastModifiedByUserId
      )
SELECT EcolabAccountNumber
,ControllerId
,FieldGroupId
,FieldId
,Value
,ControllerModelId
,UserId
FROM @TempDynamic

IF @ControllerModelId = 7
OR @ControllerModelId = 8
OR @ControllerModelId = 9
OR @ControllerModelId = 11
OR @ControllerModelId = 10
OR @ControllerModelId = 14
BEGIN
EXEC TCD.SaveDefaultControllerEquipment @ControllerId = @ControllerId
,@EcolabAccountNumber = @EcolabAccountNumber
,@UserId = @UserId;
END;

SELECT @NumOfConvWasherGroups = NumOfConvWasherGroups
,@NumOfTunnelWasherGroups = NumOfTunnelWasherGroups
FROM TCD.ControllerModelControllerTypeMapping
WHERE ControllerModelId = @ControllerModelId
AND ControllerTypeId = @ControllerTypeId

DECLARE @TotalGroupCount INT = 0;
DECLARE @WasherDosingNumber INT = 0;

IF ISNULL(@NumOfConvWasherGroups, 0) > 0
BEGIN
WHILE @LoopCount < @NumOfConvWasherGroups
            BEGIN
                SET @WasherGroupName = @TopicName + ' Dosing Group ' + CAST(@TotalGroupCount + 1 AS VARCHAR(10));
                SET @WasherDosingNumber = @TotalGroupCount + 1;

                EXEC TCD.SaveMachineGroup @GroupDescription = @WasherGroupName
                    ,@GroupTypeId = 2
                    ,@EcolabAccountNumber = @EcolabAccountNumber;

                SELECT @WasherGroupId = Id
                FROM TCD.MachineGroup
                WHERE GroupDescription = @WasherGroupName

                SELECT @WasherGroupNumber = ISNULL(MAX(CAST(WasherGroupNumber AS INT)),0) + 1
                FROM TCD.WasherGroup

                EXEC TCD.SaveWasherGroup @EcolabAccountNumber = @EcolabAccountNumber
                    ,@WasherGroupId = @WasherGroupId
                    ,@ControllerId = @ControllerId
                    ,@WasherGroupTypeId = 1
                    ,@WasherGroupName = @WasherGroupName
                    ,@WasherGroupNumber = @WasherGroupNumber
                    ,@LastModifiedByUserId = 1
                    ,@WasherDosingNumber = @WasherDosingNumber ;

                SET @LoopCount += 1;
                SET @TotalGroupCount += 1;
            END
        END

        SET @LoopCount = 0;

        IF ISNULL(@NumOfTunnelWasherGroups, 0) > 0
        BEGIN
            WHILE @LoopCount < @NumOfTunnelWasherGroups
            BEGIN
                SET @WasherGroupName = @TopicName + ' Dosing Group ' + CAST(@TotalGroupCount + 1 AS VARCHAR(10));
                SET @WasherDosingNumber = @TotalGroupCount + 1;

                EXEC TCD.SaveMachineGroup @GroupDescription = @WasherGroupName
                    ,@GroupTypeId = 2
                    ,@EcolabAccountNumber = @EcolabAccountNumber;

                SELECT @WasherGroupId = Id
                FROM TCD.MachineGroup
                WHERE GroupDescription = @WasherGroupName

                SELECT @WasherGroupNumber = ISNULL(MAX(CAST(WasherGroupNumber AS INT)),0) + 1
                FROM TCD.WasherGroup

                EXEC TCD.SaveWasherGroup @EcolabAccountNumber = @EcolabAccountNumber
                    ,@WasherGroupId = @WasherGroupId
                    ,@ControllerId = @ControllerId
                    ,@WasherGroupTypeId = 2
                    ,@WasherGroupName = @WasherGroupName
                    ,@WasherGroupNumber = @WasherGroupNumber
                    ,@LastModifiedByUserId = 1
                    ,@WasherDosingNumber = @WasherDosingNumber;

                SET @LoopCount += 1;
                SET @TotalGroupCount += 1;
            END
        END

   DECLARE @TempControllerTypeId INT, 
		   @MaxInjectionClasses INT
   SELECT @TempControllerTypeId = ControllerTypeId FROM TCD.ConduitController WHERE ControllerId = @ControllerId

   IF (@TempControllerTypeId = 1)
   BEGIN
	SET @MaxInjectionClasses = 6
   END

    IF (@TempControllerTypeId = 2)
   BEGIN
	SET @MaxInjectionClasses = 8
   END
    
	UPDATE tcd.ConduitController SET LFSInjectionClasses = @MaxInjectionClasses where ControllerId = @ControllerId
 
   COMMIT TRANSACTION

        SELECT TOP 1 @OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp
        FROM @OutputList O
  END TRY

  BEGIN CATCH
        SELECT ERROR_NUMBER() AS ErrorNumber
            ,ERROR_SEVERITY() AS ErrorSeverity
            ,ERROR_STATE() AS ErrorState
            ,ERROR_PROCEDURE() AS ErrorProcedure
            ,ERROR_LINE() AS ErrorLine
            ,ERROR_MESSAGE() AS ErrorMessage

   ROLLBACK TRANSACTION
  END CATCH

SET NOCOUNT OFF
END
GO

IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyMaster  WHERE KeyName='FIELD_MAXIMUMMACHINELOAD')
BEGIN
	INSERT INTO TCD.ResourceKeyMaster
	(KeyName,KeyDescription)
	VALUES('FIELD_MAXIMUMMACHINELOAD',NULL)
END
GO

IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyMaster  WHERE KeyName='FIELD_MINIMUMMACHINELOAD')
BEGIN
	INSERT INTO TCD.ResourceKeyMaster
	(KeyName,KeyDescription)
	VALUES('FIELD_MINIMUMMACHINELOAD',NULL)
END
GO

IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyMaster  WHERE KeyName='FIELD_WASHERNAME')
BEGIN
	INSERT INTO TCD.ResourceKeyMaster
	(KeyName,KeyDescription)
	VALUES('FIELD_WASHERNAME',NULL)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyMaster  WHERE KeyName='FIELD_DOSINGLINEFLUSHTIMES')
BEGIN
	INSERT INTO TCD.ResourceKeyMaster
	(KeyName,KeyDescription)
	VALUES('FIELD_DOSINGLINEFLUSHTIMES',NULL)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyMaster  WHERE KeyName='FIELD_TUNINTOMMODE')
BEGIN
	INSERT INTO TCD.ResourceKeyMaster
	(KeyName,KeyDescription)
	VALUES('FIELD_TUNINTOMMODE',NULL)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyMaster  WHERE KeyName='FIELD_DELAYTIMEFORTUNINTOMMODE')
BEGIN
	INSERT INTO TCD.ResourceKeyMaster
	(KeyName,KeyDescription)
	VALUES('FIELD_DELAYTIMEFORTUNINTOMMODE',NULL)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyMaster  WHERE KeyName='FIELD_FLUSHTIMESANDSETUPTOM')
BEGIN
	INSERT INTO TCD.ResourceKeyMaster
	(KeyName,KeyDescription)
	VALUES('FIELD_FLUSHTIMESANDSETUPTOM',NULL)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyMaster  WHERE KeyName='FIELD_TIMEOUTMACHINE')
BEGIN
	INSERT INTO TCD.ResourceKeyMaster
	(KeyName,KeyDescription)
	VALUES('FIELD_TIMEOUTMACHINE',NULL)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyMaster  WHERE KeyName='FIELD_MINIMUMMACHINEVALUELESSTHENMAXIMUM')
BEGIN
	INSERT INTO TCD.ResourceKeyMaster
	(KeyName,KeyDescription)
	VALUES('FIELD_MINIMUMMACHINEVALUELESSTHENMAXIMUM',NULL)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyMaster  WHERE KeyName='FIELD_PLEASEENTERSIGNALACCEPTANCETIME')
BEGIN
	INSERT INTO TCD.ResourceKeyMaster
	(KeyName,KeyDescription)
	VALUES('FIELD_PLEASEENTERSIGNALACCEPTANCETIME',NULL)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyMaster  WHERE KeyName='FIELD_PLEASEENTERBETWEEN2TO10')
BEGIN
	INSERT INTO TCD.ResourceKeyMaster
	(KeyName,KeyDescription)
	VALUES('FIELD_PLEASEENTERBETWEEN2TO10',NULL)
END
GO

IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyPageMapping  WHERE KeyName='FIELD_MAXIMUMMACHINELOAD')
BEGIN
	INSERT INTO TCD.ResourceKeyPageMapping
	(KeyName,PageID)
	VALUES('FIELD_MAXIMUMMACHINELOAD',31)
END
GO

IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyPageMapping  WHERE KeyName='FIELD_MINIMUMMACHINELOAD')
BEGIN
	INSERT INTO TCD.ResourceKeyPageMapping
	(KeyName,PageID)
	VALUES('FIELD_MINIMUMMACHINELOAD',31)
END
GO

IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyPageMapping  WHERE KeyName='FIELD_WASHERNAME')
BEGIN
	INSERT INTO TCD.ResourceKeyPageMapping
	(KeyName,PageID)
	VALUES('FIELD_WASHERNAME',31)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyPageMapping  WHERE KeyName='FIELD_DOSINGLINEFLUSHTIMES')
BEGIN
	INSERT INTO TCD.ResourceKeyPageMapping
	(KeyName,PageID)
	VALUES('FIELD_DOSINGLINEFLUSHTIMES',46)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyPageMapping  WHERE KeyName='FIELD_TUNINTOMMODE')
BEGIN
	INSERT INTO TCD.ResourceKeyPageMapping
	(KeyName,PageID)
	VALUES('FIELD_TUNINTOMMODE',31)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyPageMapping  WHERE KeyName='FIELD_DELAYTIMEFORTUNINTOMMODE')
BEGIN
	INSERT INTO TCD.ResourceKeyPageMapping
	(KeyName,PageID)
	VALUES('FIELD_DELAYTIMEFORTUNINTOMMODE',31)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyPageMapping  WHERE KeyName='FIELD_FLUSHTIMESANDSETUPTOM')
BEGIN
	INSERT INTO TCD.ResourceKeyPageMapping
	(KeyName,PageID)
	VALUES('FIELD_FLUSHTIMESANDSETUPTOM',46)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyPageMapping  WHERE KeyName='FIELD_TIMEOUTMACHINE')
BEGIN
	INSERT INTO TCD.ResourceKeyPageMapping
	(KeyName,PageID)
	VALUES('FIELD_TIMEOUTMACHINE',46)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyPageMapping  WHERE KeyName='FIELD_MINIMUMMACHINEVALUELESSTHENMAXIMUM')
BEGIN
	INSERT INTO TCD.ResourceKeyPageMapping
	(KeyName,PageID)
	VALUES('FIELD_MINIMUMMACHINEVALUELESSTHENMAXIMUM',31)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyPageMapping  WHERE KeyName='FIELD_PLEASEENTERSIGNALACCEPTANCETIME')
BEGIN
	INSERT INTO TCD.ResourceKeyPageMapping
	(KeyName,PageID)
	VALUES('FIELD_PLEASEENTERSIGNALACCEPTANCETIME',31)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyPageMapping  WHERE KeyName='FIELD_PLEASEENTERBETWEEN2TO10')
BEGIN
	INSERT INTO TCD.ResourceKeyPageMapping
	(KeyName,PageID)
	VALUES('FIELD_PLEASEENTERBETWEEN2TO10',31)
END
GO


IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyValue  WHERE KeyName='FIELD_MAXIMUMMACHINELOAD')
BEGIN
	INSERT INTO TCD.ResourceKeyValue
	(KeyName, Value, languageID, LastModifiedTime)
	VALUES('FIELD_MAXIMUMMACHINELOAD',N'Maximum Machine Load', 1, GETUTCDATE())
END
GO

IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyValue  WHERE KeyName='FIELD_MINIMUMMACHINELOAD')
BEGIN
	INSERT INTO TCD.ResourceKeyValue
	(KeyName, Value, languageID, LastModifiedTime)
	VALUES('FIELD_MINIMUMMACHINELOAD',N'Minimum Machine Load', 1, GETUTCDATE())
END
GO

IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyValue  WHERE KeyName='FIELD_WASHERNAME')
BEGIN
	INSERT INTO TCD.ResourceKeyValue
	(KeyName, Value, languageID, LastModifiedTime)
	VALUES('FIELD_WASHERNAME',N'Washer Name', 1, GETUTCDATE())
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyValue  WHERE KeyName='FIELD_DOSINGLINEFLUSHTIMES')
BEGIN
	INSERT INTO TCD.ResourceKeyValue
	(KeyName, Value, languageID, LastModifiedTime)
	VALUES('FIELD_DOSINGLINEFLUSHTIMES', N'Dosing Line Flush Times', 1, GETUTCDATE())
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyValue  WHERE KeyName='FIELD_TUNINTOMMODE')
BEGIN
	INSERT INTO TCD.ResourceKeyValue
	(KeyName, Value, languageID, LastModifiedTime)
	VALUES('FIELD_TUNINTOMMODE', N'TUN in TOM Mode', 1, GETUTCDATE())
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyValue  WHERE KeyName='FIELD_DELAYTIMEFORTUNINTOMMODE')
BEGIN
	INSERT INTO TCD.ResourceKeyValue
	(KeyName, Value, languageID, LastModifiedTime)
	VALUES('FIELD_DELAYTIMEFORTUNINTOMMODE', N'Delay time for TUN washing programs X 10 Seconds', 1, GETUTCDATE())
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyValue  WHERE KeyName='FIELD_FLUSHTIMESANDSETUPTOM')
BEGIN
	INSERT INTO TCD.ResourceKeyValue
	(KeyName, Value, languageID, LastModifiedTime)
	VALUES('FIELD_FLUSHTIMESANDSETUPTOM',N'Flush Times & Setup TOM' , 1, GETUTCDATE())
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyValue  WHERE KeyName='FIELD_TIMEOUTMACHINE')
BEGIN
	INSERT INTO TCD.ResourceKeyValue
	(KeyName, Value, languageID, LastModifiedTime)
	VALUES('FIELD_TIMEOUTMACHINE',N'Time Out Machine' , 1, GETUTCDATE())
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyValue  WHERE KeyName='FIELD_MINIMUMMACHINEVALUELESSTHENMAXIMUM')
BEGIN
	INSERT INTO TCD.ResourceKeyValue
	(KeyName, Value, languageID, LastModifiedTime)
	VALUES('FIELD_MINIMUMMACHINEVALUELESSTHENMAXIMUM',N'Please enter value less then maximum machine load.', 1, GETUTCDATE())
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyValue  WHERE KeyName='FIELD_PLEASEENTERSIGNALACCEPTANCETIME')
BEGIN
	INSERT INTO TCD.ResourceKeyValue
	(KeyName, Value, languageID, LastModifiedTime)
	VALUES('FIELD_PLEASEENTERSIGNALACCEPTANCETIME',N'Please enter Signal Acceptance Time.', 1, GETUTCDATE())
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyValue  WHERE KeyName='FIELD_PLEASEENTERBETWEEN2TO10')
BEGIN
	INSERT INTO TCD.ResourceKeyValue
	(KeyName, Value, languageID, LastModifiedTime)
	VALUES('FIELD_PLEASEENTERBETWEEN2TO10',N'Please enter between 2 to 10.', 1, GETUTCDATE())
END
GO
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[SaveTunnelCompartmentEquipmentValveMapping]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.SaveTunnelCompartmentEquipmentValveMapping
	END
GO
CREATE PROC [TCD].[SaveTunnelCompartmentEquipmentValveMapping] (
  @lineCompartmentMappings TCD.TunnelCompartmentEquipmentValveMapping READONLY
    , @ControllerEquipmentId INT
    , @ControllerId INT
    , @LineNumber TINYINT
    , @EcolabAccountNumber NVARCHAR(25)
    , @UserId INT
)
AS
BEGIN
    DECLARE
     @ControllerModelId INT,
     @ControllerTypeId INT;
    (SELECT TOP 1 @ControllerModelId = CC.ControllerModelId
    , @ControllerTypeId = CC.ControllerTypeId
   FROM tcd.ConduitController CC
   WHERE ControllerId = @ControllerId);
    DECLARE
     @EquipmentSetupId INT = (SELECT TOP 1 CES.ControllerEquipmentSetupId
        FROM TCD.ControllerEquipmentSetup CES
        WHERE CES.ControllerId = @ControllerId
          AND CES.ControllerEquipmentId = @ControllerEquipmentId ),
     @PlantId INT = (SELECT TOP 1 PlantId
       FROM TCD.Plant P
       WHERE P.EcolabAccountNumber = @EcolabAccountNumber),
     @DDFlag BIT = CAST(
     CASE
     WHEN EXISTS(SELECT 1
       FROM @lineCompartmentMappings M
       WHERE M.DirectDosingFlag = 1) THEN 1
     ELSE 0
     END
     AS BIT);

    /* Delete the values if not necessary */

    IF @DDFlag = 'TRUE'
    BEGIN
    DELETE FROM TCD.TunnelCompartmentEquipmentValveMapping
      WHERE ControllerEquipmentSetupID = @EquipmentSetupId
    AND DirectDosingFlag = 'FALSE';
    END;
    ELSE
    BEGIN

    /* Validation of max 20 Valves per Tunnel */

    /* Looping for two Machine internal Ids*/

    DECLARE
     @TunnelCount INT = (SELECT TOP 1 CMCTM.NumOfTunnelWasherGroups
           FROM TCD.ControllerModelControllerTypeMapping CMCTM
           WHERE CMCTM.ControllerModelId = @ControllerModelId
         AND CMCTM.ControllerTypeId = @ControllerTypeId);
    DECLARE
     @MaxValveCount INT = CASE
          WHEN @ControllerModelId IN (7, 8) THEN 20
          WHEN @ControllerModelId = 9 THEN 12
          END;
 
    
    IF (SELECT  COUNT(*)
      FROM TCD.TunnelCompartmentEquipmentValveMapping TCEVM
       JOIN
       TCD.ControllerEquipmentSetup CES ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupID
      WHERE CES.ControllerId = @ControllerId
        AND TCEVM.DirectDosingFlag = 'FALSE'
        AND CES.ControllerEquipmentId != @ControllerEquipmentId
        )
       +
       (SELECT COUNT(*)
      FROM @lineCompartmentMappings LCM
      ) > @MaxValveCount
        BEGIN
        RAISERROR ('8014', 16, 1);
        DECLARE
         @ReturnValue INT = -1;
        RETURN @ReturnValue;
        END;
    
    
    DELETE T
      FROM TCD.TunnelCompartmentEquipmentValveMapping T
      WHERE T.ControllerEquipmentSetupID = @EquipmentSetupId
    AND T.PlantID = @PlantId
    AND T.TunnelCompartmentEquipmentValveMappingID NOT IN(
    SELECT TCEVM.TunnelCompartmentEquipmentValveMappingID
      FROM TCD.TunnelCompartmentEquipmentValveMapping TCEVM
       INNER JOIN
       @lineCompartmentMappings M ON TCEVM.TunnelNumber = M.TunnelNumber
             AND TCEVM.DosingPointNumber = M.DosingPointNumber
             AND TCEVM.ControllerEquipmentSetupID = @EquipmentSetupId
             AND TCEVM.PlantID = @PlantId);
    END;
    DECLARE
     @TempMapping TABLE(
     RowNumber INT NOT NULL
   , ControllerEquipmentId TINYINT NOT NULL
   , TunnelNumber INT NOT NULL
   , CompartmentNumber TINYINT NOT NULL
   , DosingPointNumber TINYINT NOT NULL
   , DirectDosingFlag BIT NOT NULL
   , VlaveNumber TINYINT NOT NULL
   , WasherNumber int NOT NULL);

    /* Create RowNumber inorder to increment and use row by row. */

    WITH CTE_LCM
    AS (
    SELECT ROW_NUMBER() OVER (ORDER BY LCM.TunnelNumber, LCM.DosingPointNumber) AS RowNumber
     , *
  FROM @lineCompartmentMappings LCM
    )
    INSERT INTO @TempMapping
    SELECT *
  FROM CTE_LCM CL;

    /* Loop */

    DECLARE
     @j INT = 1,
     @max INT = (SELECT MAX(TM.RowNumber)
       FROM @TempMapping TM);
    WHILE @j <= @max
    BEGIN

    /* Declare and Initialize the current row data */

    DECLARE
     @TunnelNumber INT,
     @CompartmentNumber TINYINT,
     @DosingpointNumber TINYINT;
    SELECT TOP 1 @TunnelNumber = TM.TunnelNumber
       , @DosingPointNumber = TM.DosingpointNumber
       , @CompartmentNumber = TM.CompartmentNumber
      FROM @TempMapping TM
      WHERE TM.RowNumber = @j;
    DECLARE
     @ValveNumber INT = 0;
    IF @DDFlag = 'FALSE'
    BEGIN

    /* Get Min Available Valve Number */

    SELECT @ValveNumber = MIN(CEV.ControllerEquipmentValveID)
      FROM TCD.ControllerEquipmentValves CEV
      WHERE ControllerEquipmentValveID <> 0
        AND CEV.ControllerEquipmentValveID  NOT IN (
        SELECT TCEVM.ValveNumber
      FROM TCD.TunnelCompartmentEquipmentValveMapping TCEVM
       JOIN
       TCD.ControllerEquipmentSetup CES ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupID
      WHERE CES.ControllerID = @ControllerId);
    END;

    /* Update If Exists else Insert */

    MERGE TCD.TunnelCompartmentEquipmentValveMapping T
    USING (SELECT TOP 1 *
     FROM @TempMapping TM
     WHERE TM.RowNumber = @j) S
    ON T.ControllerEquipmentSetupID = @EquipmentSetupId
   AND T.PlantID = @PlantId
   AND T.TunnelNumber = S.TunnelNumber
   AND T.DosingPointNumber = S.DosingPointNumber
   AND T.DirectDosingFlag = S.DirectDosingFlag
    WHEN MATCHED
      THEN
      UPDATE SET T.CompartmentNumber = S.CompartmentNumber
       , T.ValveNumber = CASE  @DDFlag
         WHEN 'TRUE' THEN 0
             ELSE T.ValveNumber
         END
       , T.WasherExtractorNumber = S.WasherNumber
       , T.LastModifiedByUserID = @UserId
    WHEN NOT MATCHED
      THEN
      INSERT (PlantID
        , ControllerEquipmentSetupID
        , TunnelNumber
        , DosingPointNumber
        , ValveNumber
        , CompartmentNumber
        , DirectDosingFlag
        , LastModifiedByUserID)
      VALUES (@PlantId,
      @EquipmentSetupId,
      S.TunnelNumber,
      S.DosingPointNumber,
      @ValveNumber,
      S.CompartmentNumber,
      S.DirectDosingFlag,
      @UserId);

    /* Increment the row */

    SET @j = @j + 1;
    END;
END;
GO

-------------------------------------
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[SavePlantSensorDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.SavePlantSensorDetails
	END
GO

CREATE PROCEDURE TCD.SavePlantSensorDetails(
      @SensorNumber NVARCHAR( 100) = NULL,
      @EcolabAccountNumber NVARCHAR( 25) = NULL,
      @ControllerID VARCHAR( 1000) = NULL,
      @SensorName NVARCHAR( 100) = NULL,
      @SensorType NVARCHAR( 100) = NULL,
      @SensorLocation NVARCHAR( 100) = NULL,
      @MachineCompartment NVARCHAR( 100) = NULL,
      @OutputType NVARCHAR( 100) = NULL,
      @ChemicalforChart NVARCHAR( 100)= NULL,
      @UOM NVARCHAR( 100) = NULL,
      @DashboardActualValue VARCHAR( 100) = NULL,
      @UserID INT,
      @AnalogueInputNumber NVARCHAR( 100) = NULL,
      @Calibration4mA DECIMAL( 18, 2) = NULL,
      @Calibration20mA DECIMAL( 18, 2) = NULL,
      @TagAddress4mA NVARCHAR( 100) = NULL,
      @TagAddress20mA NVARCHAR( 100) = NULL,
      @Scope VARCHAR( 100)OUTPUT,
      @OutputSensorId INT = NULL OUTPUT,
      @LastModifiedTimestampAtCentral DATETIME = NULL,
      @OutputLastModifiedTimestampAtLocal DATETIME = NULL OUTPUT,
	  @SensorNum INT,
	  @AlarmEnable BIT,
	  @MinimumAlarmValue INT,
	  @MaximumAlarmValue INT,
	  @ExternalSensor INT)
AS
     BEGIN
         SET NOCOUNT ON;
         DECLARE @IsPlant BIT = NULL,
         @IsPress BIT = NULL,
         @IStunnel INT = '';
         DECLARE @TypeLimit INT = NULL,
         @TempLimit INT = NULL,
         @pHLimit INT = NULL,
         @ConductivityLimit INT = NULL,
         @WeightLimit INT = NULL,
		 @RedoxLimit INT = NULL,
         @ControllerModelID INT = NULL;
         DECLARE @ReturnValue INT = 0,
         @ErrorId INT = 0,
         @ErrorMessage NVARCHAR( 4000) = N'',
         @CurrentUTCTime DATETIME = GETUTCDATE();
         DECLARE @OutputList AS TABLE( SensorId INT,LastModifiedTimestamp DATETIME);
         SET @OutputLastModifiedTimestampAtLocal = ISNULL( @OutputLastModifiedTimestampAtLocal, NULL);

         --SQLEnlight

         SET @OutputSensorId = ISNULL( @OutputSensorId, NULL);

         /*Maximum one Sensor with the same type can be connected to one machine/Compartement */

         IF @LastModifiedTimestampAtCentral IS NOT NULL
            AND
            NOT EXISTS( SELECT 1
                        FROM TCD.Sensor AS S
                        WHERE S.EcolabAccountNumber = @EcolabAccountNumber
                              AND
                              S.SensorId = @SensorNumber
                              AND
                              S.LastModifiedTime = @LastModifiedTimestampAtCentral
                      )
             BEGIN
                 SET @ErrorId = 60000;
                 SET @ErrorMessage = N'' + CAST( @ErrorId AS NVARCHAR);
                 RAISERROR( @ErrorMessage, 16, 1);
                 SET @ReturnValue = -1;
                 RETURN @ReturnValue;
             END;
         SET @Scope = '';
         SELECT @TypeLimit = COUNT( 1)
         FROM TCD.Sensor AS S
         WHERE GroupId = @SensorLocation
               AND
               S.SensorType = @SensorType
               AND
               ISNULL( MachineCompartment, 0) = @MachineCompartment
               AND
               Is_deleted = 0
               AND
               ControllerID IN(
               SELECT ControllerId
               FROM TCD.ConduitController
               WHERE ControllerId = @ControllerID
                     AND
                     EcoalabAccountNumber = @EcolabAccountNumber
                              )
               AND
               EcolabAccountNumber = @EcolabAccountNumber;

         /*Maximum 6 Temperature sensor can be connected to the same Washter-Tunnel */

         SELECT @TempLimit = COUNT( 1)
         FROM TCD.Sensor AS S LEFT OUTER JOIN TCD.machinesetup AS MS ON S.GroupId = MS.groupId
                                                                        AND
                                                                        S.EcolabAccountNumber = MS.EcoalabAccountNumber
         WHERE S.SensorType = 1
               AND
               S.GroupID = @SensorLocation
               AND
               Ms.Istunnel = 1
               AND
    IS_deleted = 0
               AND
               S.ControllerID IN(
               SELECT ControllerId
               FROM TCD.ConduitController
               WHERE ControllerModelId = 7
                     AND
                     EcoalabAccountNumber = @EcolabAccountNumber
                                )
               AND
               S.EcolabAccountNumber = @EcolabAccountNumber;

         /* Maximum 2 pH sensor can be connected to the same Washter-Tunnel */

         SELECT @pHLimit = COUNT( 1
                                )
         FROM TCD.Sensor AS S LEFT OUTER JOIN TCD.machinesetup AS MS ON S.GroupId = MS.groupId
                                                                        AND
                                                                        S.EcolabAccountNumber = MS.EcoalabAccountNumber
         WHERE S.SensorType = 2
               AND
               S.GroupID = @SensorLocation
               AND
               Ms.Istunnel = 1
               AND
               IS_deleted = 0
               AND
               S.ControllerID IN(
               SELECT ControllerId
               FROM TCD.ConduitController
               WHERE ControllerModelId = 7
                     AND
                     EcoalabAccountNumber = @EcolabAccountNumber
                                )
               AND
               S.EcolabAccountNumber = @EcolabAccountNumber;

		/* Maximum 1 Redox sensor can be connected to the same Washter-Tunnel */

         SELECT @RedoxLimit = COUNT(1)
         FROM TCD.Sensor AS S LEFT OUTER JOIN TCD.machinesetup AS MS ON S.GroupId = MS.groupId
                                                                        AND
                                                                        S.EcolabAccountNumber = MS.EcoalabAccountNumber
         WHERE S.SensorType = 2
               AND
               S.GroupID = @SensorLocation
               AND
               Ms.Istunnel = 1
               AND
               IS_deleted = 0
               AND
               S.ControllerID IN(
               SELECT ControllerId
               FROM TCD.ConduitController
               WHERE ControllerModelId = 7
                     AND
                     EcoalabAccountNumber = @EcolabAccountNumber
                                )
               AND
               S.EcolabAccountNumber = @EcolabAccountNumber;
			   

         /* Maximum 1 Conductivity sensor can be connected to the same Washter-Tunnel */

         SELECT @ConductivityLimit = COUNT( 1)
         FROM TCD.Sensor AS S LEFT OUTER JOIN TCD.machinesetup AS MS ON S.GroupId = MS.groupId
                                                                        AND
                                                                        S.EcolabAccountNumber = MS.EcoalabAccountNumber
         WHERE S.SensorType = 4
               AND
               S.GroupID = @SensorLocation
               AND
               Ms.Istunnel = 1
               AND
               IS_deleted = 0
               AND
               S.ControllerID IN(
               SELECT ControllerId
               FROM TCD.ConduitController
               WHERE ControllerModelId = 7
                     AND
                     EcoalabAccountNumber = @EcolabAccountNumber
                                )
               AND
               S.EcolabAccountNumber = @EcolabAccountNumber;

         /* Maximum 1 Weight sensor can be connected to the same Washter-Tunnel */

         SELECT @WeightLimit = COUNT( 1)
         FROM TCD.Sensor AS S LEFT OUTER JOIN TCD.machinesetup AS MS ON S.GroupId = MS.groupId
                                                                        AND
                                                                        S.EcolabAccountNumber = MS.EcoalabAccountNumber
         WHERE S.SensorType = 5
               AND
               S.GroupID = @SensorLocation
               AND
               Ms.Istunnel = 1
               AND
               IS_deleted = 0
               AND
               S.ControllerID IN(
               SELECT ControllerId
               FROM TCD.ConduitController
               WHERE ControllerModelId = 7
                     AND
                     EcoalabAccountNumber = @EcolabAccountNumber
                                )
               AND
               S.EcolabAccountNumber = @EcolabAccountNumber;
         SELECT @ControllerModelID = ControllerModelId
         FROM TCD.ConduitController
         WHERE ControllerId = @ControllerID
               AND
               EcoalabAccountNumber = @EcolabAccountNumber;
         SELECT @IStunnel = Istunnel
         FROM TCD.machinesetup AS MS
         WHERE Ms.GroupId = @SensorLocation
               AND
               MS.EcoalabAccountNumber = @EcolabAccountNumber;
			  
         IF @IStunnel = 1
             BEGIN				
                 IF @MachineCompartment = 1
                     BEGIN
                         SET @IsPress = 1;
                     END;				
             END;

		IF @MachineCompartment = 0
           BEGIN
			   SET @MachineCompartment = NULL;
		   END;

         IF @SensorLocation = 1
             BEGIN
                 SET @IsPlant = 1;
                 SET @SensorLocation = NULL;
                 SET @MachineCompartment = NULL;
             END;
         IF @ControllerID = -1
             BEGIN
                 SELECT TOP ( 1
                            )@ControllerID = ControllerID
                 FROM TCD.ConduitController
                 WHERE ControllerModelId = @ControllerModelID
                       AND
                       EcoalabAccountNumber = @EcolabAccountNumber;
             END;
         ELSE
             BEGIN
                 SELECT @ControllerModelID = ControllerModelId
                 FROM TCD.ConduitController
                 WHERE ControllerId = @ControllerID
                       AND
                       EcoalabAccountNumber = @EcolabAccountNumber;
             END;
         IF @ControllerID != -1
             BEGIN

                 /* Inserting the values in to Sensor table if it is new Sensor */

                 DECLARE @NewSensorId INT,
                 @ModuleType INT = 3,
                 @DefaultFrequency INT = 60,
                 @TagType VARCHAR( 100) = 'Tag_MPLC',
                 @TagTypeSC4 VARCHAR( 100) = 'Tag_SC4',
                 @TagTypeSC20 VARCHAR( 100) = 'Tag_SC20',
                 @Result1 INT = NULL,
                 @Result2 INT = NULL,
                 @Result3 INT = NULL,
                 @Type INT = 3,
                 @AllowTagEdit BIT;
                 SELECT @AllowTagEdit = CASE
                                            WHEN COUNT( *) > 0
                                            THEN 'TRUE'
                                            ELSE 'FALSE'
                                        END
                 FROM TCD.UserMaster AS UM INNER JOIN TCD.UserInRole AS UIR
                 ON UM.UserId = UIR.UserId
                                           INNER JOIN TCD.UserRoles AS UR
                 ON UIR.RoleId = UR.RoleId
                 WHERE UM.UserId = @UserID
                       AND
                       UR.LevelId >= 8
                       AND
                       UM.EcolabAccountNumber = @EcolabAccountNumber;
                 IF NOT EXISTS( SELECT *
                                FROM TCD.Sensor
                                WHERE SensorID = @SensorNumber
                                      AND
                                      EcolabAccountNumber = @EcolabAccountNumber
                              )

                     -- Begin Create Sensor

                     BEGIN
                         BEGIN
                             DECLARE @AllowInsert BIT = 'FALSE';
                             IF @TypeLimit < 1
                                 BEGIN
                                     IF @ControllerModelID = 7
                                         BEGIN
                                             IF @SensorType = 1
                                                 BEGIN
                                                     IF @TempLimit < 6
                                                         BEGIN
                                                             SET @AllowInsert = 'TRUE';
                                                         END;
                                                     ELSE
                                                         BEGIN
                                                             SET @SCOPE = @SCOPE + '401,';
                                                         END;
                                                 END;
                                             ELSE
                                 BEGIN
                                                     IF @SensorType = 2
                                                         BEGIN
                                                             IF @pHLimit < 2
                                                                 BEGIN
                                                                     SET @AllowInsert = 'TRUE';
                                                                 END;
                                                             ELSE
                                                                 BEGIN
                                                                     SET @SCOPE = @SCOPE + '301,';
                                                                 END;
                                                         END;
														 ELSE
														BEGIN
															IF @SensorType = 3
																BEGIN
																	IF @RedoxLimit < 1
																		BEGIN
																			SET @AllowInsert = 'TRUE';
																		END;
																	ELSE
																		BEGIN
																			SET @SCOPE = @SCOPE + '301,';
																		END;
																END;
                                                    
                                                     ELSE
                                                         BEGIN
                                                             IF @SensorType = 4
                                                                 BEGIN
                                                                     IF @ConductivityLimit < 1
                                                                         BEGIN
                                                                             SET @AllowInsert = 'TRUE';
                                                                         END;
																	ELSE
                                                                     BEGIN
                                                                         SET @SCOPE = @SCOPE + '201,';
                                                                     END;
                                                                 END;
                                                             ELSE
                                                                 BEGIN
                                                                     IF @SensorType = 5
                                                                         BEGIN
                                                                             IF @WeightLimit < 1
                                                                                 BEGIN
                                                                                     SET @AllowInsert = 'TRUE';
                                                                                 END;
                                                                             ELSE
                                                                                 BEGIN
                                                                                     SET @SCOPE = @SCOPE + '101,';
                                                                                 END;
                                                                         END;
                                                                 END;
                                                         END;
													END;
                                               END;
                                         END;
                                     ELSE
                                         BEGIN
                                             SET @AllowInsert = 'TRUE';
                                         END;
                                 END;
                             ELSE
                                 BEGIN
                                     SET @Scope = @Scope + '501,';
                                 END;

                             -- End Business Validations
                             -- Begin Insert if Validation Succeeds

                             IF @AllowInsert = 'TRUE'
                                 BEGIN
                                     DECLARE @SensorCount INT;
                                     SELECT @SensorCount = MAX( s.SensorId)+1
                                     FROM TCD.Sensor AS s WITH ( NOLOCK);
                                 
                                     INSERT INTO TCD.Sensor( Description,
                                     SensorType,
                                     GroupId,
                                     MachineCompartment,
                                     EcolabAccountNumber,
                                     ControllerID,
                                     OutputType,
                                     ChemicalforChart,
                                     UOM,
                                     DashboardActualValue,
                                     LastModifiedByUserId,
                                     IsPlant,
                                     IsPress,
                                     Calibration4mA,
                                     Calibration20mA,
                                     Id,
									 SensorNum,
									 AlarmEnable,
									 MinimumAlarmValue,
									 MaximumAlarmValue,
									 AnalogueInputNumber )                                                         
                                     OUTPUT inserted.SensorId AS SensorId,
                                     inserted.LastModifiedTime AS LastModifiedTimestamp
                                            INTO @OutputList( SensorId,
                                            LastModifiedTimestamp
                                                            )
                                     SELECT @SensorName,
                                     @SensorType,
                                     @SensorLocation,
                                     @MachineCompartment,
                                     @EcolabAccountNumber,
                                     @ControllerID,
                                     @OutputType,
                                     @ChemicalforChart,
                                     @UOM,
                                     @DashboardActualValue,
                                     @UserID,
                                     @IsPlant,
                                     @IsPress,
                                     @Calibration4mA,
                                     @Calibration20mA,
                                     @SensorCount,
									 @SensorNum,
									 @AlarmEnable,
									 @MinimumAlarmValue,
									 @MaximumAlarmValue,
									 @ExternalSensor;
                                     SET @NewSensorId = SCOPE_IDENTITY(
                                                                      );
                                 END;
                         END;
                     END;
                 ELSE

                     ------------------------------------------------------------------------------------------------------------------
                     -- Begin Update Sensor

                     BEGIN
                         DECLARE @PlantId INT = ( SELECT MG.Id
                                                  FROM TCD.MachineGroupType AS MGT INNER JOIN TCD.MachineGroup AS MG
                                                  ON MGT.Id = MG.GroupTypeId
                                                  WHERE MGT.Id = 1
                                                        AND
                                                        MG.Is_Deleted = 0
                                                );

                         -- Check RedFlag Association and Update Sensor

                         IF(( SELECT COALESCE( S.GroupId, ''
                                             )
                              FROM TCD.Sensor AS S
                              WHERE S.SensorId = @SensorNumber
                            ) != COALESCE( @SensorLocation, ''
                                         )
                            OR
                            ( SELECT COALESCE( S.MachineCompartment, ''
                                             )
                              FROM TCD.Sensor AS S
                              WHERE S.SensorId = @SensorNumber
                            ) != COALESCE( @MachineCompartment, ''
                                         ))
                           AND
                           EXISTS( SELECT 1
                                   FROM TCD.RedFlag AS RF INNER JOIN TCD.RedFlagMappingData AS RFM
                                   ON RF.Id = RFM.MappingId
                                      AND
                                      RF.Is_Deleted = 0
                                      AND
                                      RFM.Is_Deleted = 0
                                                          LEFT JOIN TCD.Sensor AS S
                                   ON RF.Location = CASE S.IsPlant
                                                        WHEN 'TRUE'
                                                        THEN COALESCE( S.GroupId, @PlantId
                                                                     )
                                                        ELSE S.GroupId
                                                    END
                                      AND
                                      COALESCE( S.MachineCompartment, 0
                                              ) = COALESCE( RFM.MachineId, 0
                                                          )
                                      AND
                                      S.Is_deleted = 0
                                   WHERE S.SensorId = @SensorNumber
                                 )
                             BEGIN
                                 SET @Scope = '405,';
                             END;
                         ELSE
                             BEGIN
                                 IF(@Result1 IS NULL
                                    OR
                                    @Result1 <> 0)
                                   AND
                                   (@Result2 IS NULL
                                    OR
                                    @Result2 <> 0)
                                   AND
                                   (@Result3 IS NULL
                                    OR
                                    @Result3 <> 0)
                                     BEGIN
                                         DECLARE @AllowUpdate BIT = 'FALSE';

                                         --Begin Get old Sensor Values

                                         BEGIN
                                             DECLARE @uty INT = ( SELECT sensortype
                                                                  FROM TCD.Sensor
                                                                  WHERE SensorID = @SensorNumber
                                                                        AND
                                                                        EcolabAccountNumber = @EcolabAccountNumber
                                                                );
                                             DECLARE @grpId INT = ( SELECT GroupId
                                                                    FROM TCD.Sensor
                                                                    WHERE SensorID = @SensorNumber
                                                                          AND
                                                                          EcolabAccountNumber = @EcolabAccountNumber
                                                                  );
                                             DECLARE @machId INT = ( SELECT MachineCompartment
                                                                     FROM TCD.Sensor
                                                                     WHERE SensorID = @SensorNumber
                                                                           AND
                                                                           EcolabAccountNumber = @EcolabAccountNumber
                                   );
                                         END;

                                         --Begin Get old Sensor Values

                                         IF @uty <> @SensorType
                                            OR
                                            @grpId <> @SensorLocation
                                            OR
                                            @machId <> @MachineCompartment
                                             BEGIN
                                                 IF @TypeLimit < 1
                                                     BEGIN
                                                         IF @ControllerModelID = 7
                                                             BEGIN
                                                                 IF @SensorType = 1
                                                                     BEGIN
                                                                         IF @TempLimit < 6
                                                                             BEGIN
                                                                                 SET @AllowUpdate = 'TRUE';
                                                                             END;
                                                                         ELSE
                                                                             BEGIN
                                                                                 SET @SCOPE = @SCOPE + '401,';
                                                                             END;
                                                                     END;
                                                                 ELSE
                                                                     BEGIN
                                                                         IF @SensorType = 2
                                                                             BEGIN
                                                                                 IF @pHLimit < 2
                                                                                     BEGIN
                                                                                         SET @AllowUpdate = 'TRUE';
                                                                                     END;
                                                                                 ELSE
                                                                                     BEGIN
                                                                                         SET @SCOPE = @SCOPE + '301,';
                                                                                     END;
                                                                             END;
																			 ELSE
																			BEGIN
																				IF @SensorType = 3
																					BEGIN
																						IF @RedoxLimit < 1
																							BEGIN
																								SET @AllowInsert = 'TRUE';
																							END;
																						ELSE
																							BEGIN
																								SET @SCOPE = @SCOPE + '301,';
																							END;
																					END;
                                                    
                                                                         ELSE
                                                                             BEGIN
                                                                                 IF @SensorType = 4
                                                                                     BEGIN
                                                                                         IF @ConductivityLimit < 1
                                                                                             BEGIN
                                                                                                 SET @AllowUpdate = 'TRUE';
                                                                                             END;
                                                                                         ELSE
                                                                                             BEGIN
																								SET @SCOPE = @SCOPE + '201,';
                                                                                             END;
                                                                                     END;
                                                                                 ELSE
                                                                                     BEGIN
                                                                                         IF @SensorType = 5
                                                                                             BEGIN
                                                                                                 IF @WeightLimit < 1
                                                                                                     BEGIN
                                                                                                         SET @AllowUpdate = 'TRUE';
                                                                                                     END;
                                                                                                 ELSE
                                                                                                     BEGIN
                                                                                                         SET @SCOPE = @SCOPE + '101,';
                                                                                                     END;
                                                                                             END;
                                                                                     END;
																				END;
                                                                           END;
                                                                     END;
                                                             END;
                                                         ELSE
                                                             BEGIN
                                                                 BEGIN
                                                                     SET @AllowUpdate = 'TRUE';
                                                                 END;
                                                             END;
                                                     END;
                                                 ELSE
                                                     BEGIN
                                                         SET @SCOPE = @SCOPE + '501,';
                                                     END;
                                             END;
                                         ELSE
                                             BEGIN
                                                 SET @AllowUpdate = 'TRUE';
                                             END;
                                         IF @AllowUpdate = 'TRUE'
                                             BEGIN
                                                 IF @LastModifiedTimestampAtCentral IS NOT NULL
                                                    AND
                                                    NOT EXISTS( SELECT 1
                                                                FROM TCD.Sensor AS S
                                                                WHERE S.EcolabAccountNumber = @EcolabAccountNumber
                                                                      AND
                                                                      S.SensorId = @SensorNumber
                                                                      AND
                                                                      S.LastModifiedTime = @LastModifiedTimestampAtCentral
           )
                                                     BEGIN
                                                         SET @ErrorId = 60000;
                                                         SET @ErrorMessage = N'' + CAST( @ErrorId AS NVARCHAR
                                                                                       ) + N': Record not in-synch between plant and central.';
                                                         RAISERROR( @ErrorMessage, 16, 1
                                                                  );
                                                         SET @ReturnValue = -1;
                                                         RETURN @ReturnValue;
                                                     END;
                                                 UPDATE s
                                                        SET Description = @SensorName,
                                                 SensorType = @SensorType,
                                                 GroupId = @SensorLocation,
                                                 MachineCompartment = @MachineCompartment,
                                                 S.ControllerID = @ControllerID,
                                                 OutputType = @OutputType,
                                                 ChemicalforChart = @ChemicalforChart,
                                                 UOM = @UOM,
                                                 DashboardActualValue = @DashboardActualValue,
                                                 LastModifiedByUserId = @UserID,
                                                 Calibration4mA = @Calibration4mA,
                                                 Calibration20mA = @Calibration20mA,
                                                 LastModifiedTime = @CurrentUTCTime,
												 SensorNum = @SensorNum,
												 AlarmEnable = @AlarmEnable,
												 MinimumAlarmValue = @MinimumAlarmValue,
												 MaximumAlarmValue = @MaximumAlarmValue,
												 AnalogueInputNumber = @ExternalSensor
                                                 OUTPUT inserted.SensorId AS SensorId,
                                                 inserted.LastModifiedTime AS LastModifiedTimestamp
                                                        INTO @OutputList( SensorId,
                                                        LastModifiedTimestamp
                                                                        )
                                                 FROM TCD.Sensor S
                                                 WHERE SensorID = @SensorNumber
                                                       AND
                                                       EcolabAccountNumber = @EcolabAccountNumber;
                                             END;
                                     END;
                             END;
                     END;

             -- End Update Sensor

             END;
         ELSE
             BEGIN
                 SELECT @Scope = '701,';
             END;
         SET NOCOUNT OFF;
         SELECT TOP 1 @OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp,
         @OutputSensorId = O.SensorId
         FROM @OutputList AS O;
         RETURN @ReturnValue;
     END;

GO

-------------------------------------
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[SavePlantMeterDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.SavePlantMeterDetails
	END
GO

CREATE PROCEDURE [TCD].[SavePlantMeterDetails] (
@MeterNumber NVARCHAR(100) = NULL
, @EcolabAccountNumber NVARCHAR(25) = NULL
, @MeterName NVARCHAR(100) = NULL
, @Uitiliy NVARCHAR(100) = NULL
, @UtilityLocation NVARCHAR(100) = NULL
, @MachineCompartment NVARCHAR(100) = NULL
, @Parent NVARCHAR(100) = NULL
, @Calibration NVARCHAR(100) = NULL
, @UOFfoRCalibration NVARCHAR(100) = NULL
, @Usagefactor NVARCHAR(100) = NULL
, @ControllerID INT
, @ControllerModelID INT
, @DigitalInputNumber NVARCHAR(100) = NULL
, @AllowmanualEntry  NVARCHAR(100) = NULL
, @Meterrolloverpoint VARCHAR(100) = NULL
, @UserID INT
, @Scope VARCHAR(100) OUTPUT
, @OutputMeterId	INT = NULL	OUTPUT
, @LastModifiedTimestampAtCentral DATETIME = NULL
, @OutputLastModifiedTimestampAtLocal	DATETIME = NULL OUTPUT
, @WaterType INT = NULL
, @WaterTypeFromFormulaSetup BIT
, @CounterNum INT
, @CounterUsage BIT
, @RunningTimeUsage BIT
, @CounterAlarmValue INT
, @RunningTimeAlarmValue INT
, @ExternalCounter		INT
)
AS
BEGIN
    SET NOCOUNT ON;
    SET @Scope = '';
    DECLARE
	    @IsPlant BIT = NULL,
	    @IsPress BIT = NULL;
    DECLARE
	    @ReturnValue					INT = 0
	    ,@ErrorId						INT = 0
	    ,@ErrorMessage					NVARCHAR(4000) = N''
	    ,@CurrentUTCTime					DATETIME = GETUTCDATE();
    DECLARE
	    @OutputList						AS	TABLE		(
	    MeterId							INT
	    ,LastModifiedTimestamp			DATETIME
	    );
    SET		@OutputLastModifiedTimestampAtLocal = ISNULL(@OutputLastModifiedTimestampAtLocal, NULL);
    SET		@OutputMeterId = ISNULL(@OutputMeterId, NULL);

    /* Business vaidations for setingup the meters to controllers */

    IF	@LastModifiedTimestampAtCentral   IS NOT NULL
	 AND NOT	EXISTS	(	SELECT	1
						  FROM	TCD.Meter		M
						  WHERE	M.EcolabAccountNumber = @EcolabAccountNumber
							 AND M.MeterId = @MeterNumber
							 AND M.LastModifiedTime = @LastModifiedTimestampAtCentral
		)
	   BEGIN
		  SET			@ErrorId = 60000;
		  SET			@ErrorMessage = N''
									 +
									 CAST(@ErrorId AS NVARCHAR);
		  RAISERROR	(@ErrorMessage, 16, 1);
		  SET			@ReturnValue = -1;
		  RETURN
		  @ReturnValue;
	   END;

    -- Begin Defining Limits

    BEGIN
	   DECLARE
		   @UtilityLimit INT = NULL,
		   @WasherLimit INT = NULL,
		   @TunnelLimit INT = NULL,
		   @IStunnel INT = '',
		   @MeterNameLimit INT = NULL;

	 SELECT @MeterNameLimit = COUNT(1)
		FROM TCD.Meter 
		WHERE [Description] = @MeterName 
		AND EcolabAccountNumber = @EcolabAccountNumber
		AND Is_deleted = 0

	 
	   SELECT @UtilityLimit = COUNT(1)
		FROM TCD.meter
		WHERE GroupId = @UtilityLocation
		  AND UtilityType = @Uitiliy
		  AND ISNULL(MachineCompartment, 0) = @MachineCompartment
		  AND Is_deleted = 0
		  AND EcolabAccountNumber = @EcolabAccountNumber
		  AND ControllerID IN (
			 SELECT ControllerId
			   FROM TCD.ConduitController
			   WHERE ControllerId = @ControllerID
				AND EcoalabAccountNumber = @EcolabAccountNumber);
	   SELECT @WasherLimit = COUNT(1)
		FROM TCD.Meter M
			LEFT OUTER JOIN
			TCD.machinesetup MS ON M.GroupId = MS.groupId
						    AND M.MachineCompartment = MS.MachineInternalID
		WHERE M.UtilityType = 2
		  AND M.GroupID = @UtilityLocation
		  AND Is_deleted = 0
		  AND EcolabAccountNumber = @EcolabAccountNumber
		  AND M.ControllerID IN (
			 SELECT ControllerId
			   FROM TCD.ConduitController
			   WHERE ControllerModelId = 7
				AND EcoalabAccountNumber = @EcolabAccountNumber);
	   SELECT @TunnelLimit = COUNT(1)
		FROM TCD.Meter M
			LEFT OUTER JOIN
			TCD.machinesetup MS ON M.GroupId = MS.groupId
		WHERE M.UtilityType = 2
		  AND M.GroupID = @UtilityLocation
		  AND Ms.Istunnel = 1
		  AND Is_deleted = 0
		  AND EcoalabAccountNumber = @EcolabAccountNumber
		  AND M.ControllerID IN (
			 SELECT ControllerId
			   FROM TCD.ConduitController
			   WHERE ControllerModelId = 7
				AND EcoalabAccountNumber = @EcolabAccountNumber);
	   SELECT @IStunnel = Istunnel
		FROM TCD.machinesetup MS
		WHERE Ms.GroupId = @UtilityLocation
		  AND EcoalabAccountNumber = @EcolabAccountNumber;
    END;

    -- End Defining Limits

    IF @IStunnel = 1
        BEGIN				
            IF @MachineCompartment = 1
                BEGIN
                    SET @IsPress = 1;
                END;		
        END;

	IF @MachineCompartment = 0
        BEGIN
			SET @MachineCompartment = NULL;
		END;

    IF @UtilityLocation = 1
	   BEGIN
		  SET @IsPlant = 1;
		  SET @UtilityLocation = NULL;
		  SET @MachineCompartment = NULL;
	   END;
    IF @ControllerID = -1
	   BEGIN
		  SELECT TOP (1) @ControllerID = ControllerID
		    FROM TCD.ConduitController
		    WHERE ControllerModelId = @ControllerModelID
			 AND EcoalabAccountNumber = @EcolabAccountNumber;
	   END;
    ELSE
	   BEGIN
		  SELECT @ControllerModelID = ControllerModelId
		    FROM TCD.ConduitController
		    WHERE ControllerId = @ControllerID
			 AND EcoalabAccountNumber = @EcolabAccountNumber;
	   END;
    IF @ControllerID != -1
	   BEGIN
		  DECLARE
			  @NewMeterId INT
			  ,@TagType VARCHAR(50) = 'Tag_MPLC'
			  ,@ModuleTypeId INT = 2
			  ,@Result INT = NULL
			  ,@Type INT = 2
			  ,@AllowTagEdit BIT;
		  SELECT @AllowTagEdit = CASE
							WHEN COUNT(*) > 0 THEN 'TRUE'
							    ELSE 'FALSE'
							END
		    FROM TCD.UserMaster UM
			    INNER JOIN
			    TCD.UserInRole UIR ON UM.UserId = UIR.UserId
			    INNER JOIN
			    TCD.UserRoles UR ON UIR.RoleId = UR.RoleId
		    WHERE UM.UserId = @UserID
			 AND UR.LevelId >= 8;
		  IF NOT EXISTS (SELECT 1
					    FROM   TCD.Meter
					    WHERE  MeterID = @MeterNumber
						  AND EcolabAccountNumber = @EcolabAccountNumber)

			 -- Begin Create Meter

			 BEGIN

					   DECLARE @AllowInsert BIT = 'FALSE';

					   -- Begin Business Validations
					   IF @MeterNameLimit < 1
					   	   BEGIN
							   IF @UtilityLimit < 1 OR @Uitiliy = 2
								  BEGIN
								 	 		 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 		 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 IF @ControllerModelID = 7
								BEGIN
													
								    IF @UtilityLimit >= 1 AND @Uitiliy != 2
									   BEGIN
										  SET @Scope = @Scope + '301,';										 
									   END;
								    IF @Uitiliy = 2 AND @IStunnel = 1
									   BEGIN   										
									IF @UtilityLimit >= 1
									   BEGIN
										  SET @Scope = @Scope + '301,';										  
									   END;									 
										ELSE IF @TunnelLimit < 6
											BEGIN											
												SET @AllowInsert = 'TRUE';
											END;
										ELSE
											BEGIN											
												SET @Scope = @Scope + '101,';
											END;
										END;
									ELSE IF @Uitiliy = 2 AND @IStunnel != 1
									   BEGIN		
										 IF @WasherLimit < 2
											BEGIN
												SET @AllowInsert = 'TRUE';												
											END;
										ELSE
											BEGIN
												SET @Scope = @Scope + '201,';												
											END;
										END;									   
								    ELSE
									   BEGIN
										  SET @AllowInsert = 'TRUE';										  
									   END;
								END;
							 ELSE
								BEGIN
								    SET @AllowInsert = 'TRUE';									
								END;
								  END;
							   ELSE
								  BEGIN
									 SET @Scope = @Scope + '301,';									 
							   END;
			               END;
						ELSE
							BEGIN
								SET @Scope = @Scope + '302,';								
							END;
						
						IF @Uitiliy = 12
						 BEGIN
							SET @AllowInsert = 'TRUE';
							SET @Scope = '';
						 END;						


					   -- End Business Validations
					   -- Begin Insert if Validation Succeeds

					   IF @AllowInsert = 'TRUE'
						  BEGIN
							 INSERT INTO TCD.Meter (EcolabAccountNumber,
											    Description,
											    UtilityType,
											    GroupId,
											    MachineCompartment,
											    MaxValueLimit,
											    MeterTickUnit,
											    UsageFactor,
											    ControllerID,
											    Parent,
											    Calibration,
											    AllowManualentry ,
											    LastModifiedByUserId,
											    IsPlant,
											    IsPress,
												WaterType,
												WaterTypeFromFormulaSetup,
												CounterNum,
												CounterUsage,
												RunningTimeUsage,
												CounterAlarmValue,
												RunningTimeAlarmValue,
												DigitalInputNumber)
							 OUTPUT
							 inserted.MeterId				AS MeterId
							 ,inserted.LastModifiedTime		AS LastModifiedTimestamp
								   INTO
								   @OutputList	(
								   MeterId
								   ,LastModifiedTimestamp
								   )
							 SELECT
							 @EcolabAccountNumber,
							 @MeterName,
							 @Uitiliy,
							 @UtilityLocation,
							 @MachineCompartment,
							 @Meterrolloverpoint,
							 @UOFfoRCalibration,
							 @Usagefactor,
							 @ControllerID,
							 @Parent,
							 @Calibration,
							 @AllowmanualEntry,
							 @UserID,
							 @IsPlant,
							 @IsPress,
							 @WaterType,
							 @WaterTypeFromFormulaSetup,
							 @CounterNum,
							 @CounterUsage,
							 @RunningTimeUsage,
							 @CounterAlarmValue,
							 @RunningTimeAlarmValue,
							 @ExternalCounter;
							 IF @AllowTagEdit = 'TRUE'
								BEGIN
								    IF @Result IS NOT NULL
									   BEGIN
										  SET @NewMeterId = SCOPE_IDENTITY();
										  INSERT INTO TCD.ModuleTags (EcolabAccountNumber,
																TagType,
																TagAddress,
																ModuleTypeId,
																ModuleID,
																DeadBand,
																Active)
										  VALUES(@EcolabAccountNumber,
											    @TagType,
											    @DigitalInputNumber,
											    @ModuleTypeId,
											    @NewMeterId,
											    20,
											    1);
									   END;
								END;
						  END;

				    -- End Insert if Validation Succeeds

				  --  END;
				ELSE
				    BEGIN
					   SET @Scope = @Scope + '802,';
				    END;
			 END;

		  --End Create Meter
		  ELSE

			 -- Begin Update Meter

			 BEGIN
				DECLARE
					@PlantId INT = (SELECT MG.Id
								   FROM TCD.MachineGroupType MGT
									   INNER JOIN
									   TCD.MachineGroup MG ON MGT.Id = MG.GroupTypeId
								   WHERE MGT.Id = 1
									AND MG.Is_Deleted = 0);

				-- Check RedFlag Association and Update Meter

				IF((SELECT COALESCE(  M.GroupId, '')
					 FROM TCD.Meter M
					 WHERE M.MeterId = @MeterNumber) != COALESCE(@UtilityLocation, '')
				OR (SELECT COALESCE(  M.MachineCompartment  , '')
					 FROM TCD.Meter M
					 WHERE M.MeterId = @MeterNumber) != COALESCE(@MachineCompartment, '')  )
			   AND EXISTS(SELECT 1
						 FROM TCD.RedFlag RF
							 INNER JOIN
							 TCD.RedFlagMappingData RFM ON RF.Id = RFM.MappingId
												  AND RF.Is_Deleted = 0
												  AND RFM.Is_Deleted = 0
							 LEFT JOIN
							 TCD.Meter M ON RF.Location = CASE M.IsPlant
													WHEN 'TRUE' THEN COALESCE(  M.GroupId , @PlantId)
													    ELSE M.GroupId
													END
									  AND COALESCE(  M.MachineCompartment , 0) = COALESCE(  RFM.MachineId , 0)
									  AND M.Is_deleted = 0
						 WHERE M.MeterId = @MeterNumber)
				    BEGIN
					   SET @Scope = '405,';
				    END;
				ELSE
				    BEGIN
					   DECLARE
						   @AllowUpdate BIT = 'FALSE';
							 --Begin Get old Meter Values 

							 BEGIN
								DECLARE
									@Uty INT = (SELECT UtilityType
											    FROM TCD.Meter
											    WHERE MeterID = @MeterNumber
												 AND EcolabAccountNumber = @EcolabAccountNumber);
								DECLARE
									@grpId INT = (SELECT GroupId
												 FROM TCD.Meter
												 WHERE MeterID = @MeterNumber
												   AND EcolabAccountNumber = @EcolabAccountNumber);
								DECLARE
									@machId INT = (SELECT MachineCompartment
												  FROM TCD.Meter
												  WHERE MeterID = @MeterNumber
												    AND EcolabAccountNumber = @EcolabAccountNumber);
								DECLARE
								    @Mname INT =(SELECT COUNT(1) 
													FROM TCD.Meter 
													WHERE [Description] = @MeterName
														AND MeterId <> @MeterNumber
														AND EcolabAccountNumber = @EcolabAccountNumber
														AND Is_deleted = 0);
							 END;

							 --End Get old Meter Values

							 IF @AllowTagEdit = 'TRUE'
								BEGIN
								    IF @DigitalInputNumber IS NOT NULL
									   BEGIN
										  EXEC @Result = TCD.CheckDuplicateTag @DigitalInputNumber, @ControllerID, @MeterNumber, @Type;
									   END;
								END;

							 -- Begin Business Validations
							
							IF @Mname < 1
							Begin
							  IF @uty <> @Uitiliy
							 OR @grpId <> @UtilityLocation
							 OR @machId <> @MachineCompartment
								BEGIN
								    IF @UtilityLimit < 1
									   BEGIN
										  IF @ControllerModelID = 7
											 BEGIN

												/* Inserting the Details of meter in to Meter table if it is new meter */

												IF @Uitiliy = 2
												    BEGIN
													   IF @IStunnel = 'TRUE'
														  BEGIN
															 IF @TunnelLimit < 6
															 OR @TunnelLimit < = 6
															AND @uty = @Uitiliy
															AND @grpId = @UtilityLocation
																BEGIN
																    SET @AllowUpdate = 'TRUE';
																END;
															 ELSE
																BEGIN
																    SET @Scope = @Scope + '101,';
																END;
														  END;
													   ELSE
														  BEGIN
															 IF @WasherLimit < 2
															 OR @WasherLimit < = 2
															AND @uty = @Uitiliy
															AND @grpId = @UtilityLocation
																BEGIN
																    SET @AllowUpdate = 'TRUE';
																END;
															 ELSE
																BEGIN
																    SET @AllowUpdate = 'FALSE';
																    SET @Scope = @Scope + '201,';
																END;
														  END;
												    END;
												ELSE
												    BEGIN
													   SET @AllowUpdate = 'TRUE';
												    END;
											 END;
										  ELSE
											 BEGIN
												SET @AllowUpdate = 'TRUE';
											 END;
									   END;
								    ELSE
									   BEGIN
										  SET @Scope = @Scope + '301,';
									   END;
								END;
							 ELSE
								BEGIN
								    SET @AllowUpdate = 'TRUE';
								END;
								END;
								ELSE
								BEGIN
								 SET @Scope = @Scope + '302,';
								END;

							 -- End Business Validations 
							 -- Begin Update if Validation Succeeds

							 IF @AllowUpdate = 'TRUE'
								BEGIN
								    UPDATE P
									 SET  Description = @MeterName,
										 UtilityType = @Uitiliy,
										 GroupId = @UtilityLocation,
										 MachineCompartment = @MachineCompartment,
										 Parent = @Parent,
										 Calibration = @Calibration,
										 ControllerID = @ControllerID,
										 MeterTickUnit = @UOFfoRCalibration,
										 UsageFactor = @Usagefactor,
										 AllowmanualEntry = @AllowmanualEntry,
										 Maxvaluelimit = @Meterrolloverpoint,
										 IsPlant = @IsPlant,
										 IsPress = @IsPress,
										 LastModifiedByUserId = @UserID,
										 LastModifiedTime = @CurrentUTCTime,
										 WaterType = @WaterType,
										 WaterTypeFromFormulaSetup = @WaterTypeFromFormulaSetup,
										 CounterNum = @CounterNum,
										 CounterUsage = @CounterUsage,
										 RunningTimeUsage = @RunningTimeUsage,
										 CounterAlarmValue = @CounterAlarmValue,
										 RunningTimeAlarmValue = @RunningTimeAlarmValue,
										 DigitalInputNumber = @ExternalCounter
								    OUTPUT
								    inserted.MeterId				AS MeterId
								    ,inserted.LastModifiedTime		AS LastModifiedTimestamp
										 INTO
										 @OutputList(
										 MeterId ,
										 LastModifiedTimestamp
										 )
									 FROM   TCD.Meter P
									 WHERE MeterID = @MeterNumber
									   AND EcolabAccountNumber = @EcolabAccountNumber;
								   
								--END;

						  -- End Update if Validation Succeeds 

						  END;
					
				    END;
			 END;

	   -- End Update Meter

	   END;
    ELSE
	   BEGIN
		  SET @Scope = '701,';
	   END;
    SET NOCOUNT OFF;
    SELECT	TOP 1
    @OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp
    ,@OutputMeterId = O.MeterId
	 FROM @OutputList O;
    RETURN @ReturnValue;
END;
GO
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetUsedChemicalName]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetUsedChemicalName
	END
GO
CREATE PROCEDURE [TCD].[GetUsedChemicalName]
    @ChemName Varchar(1000)
    ,@EcolabAccountNumber NVARCHAR(25)
    ,@WasherGroupId    INT = NULL
AS     

BEGIN     
    SET NOCOUNT ON    
    
    DECLARE @RegionId            INT =    NULL
        ,    @ControllerId        INT    =    NULL
        ,    @ControllerModelId    INT    =    NULL
        ,    @ControllerTypeId    INT    =    NULL
    
    SELECT 
    @RegionId = RegionID FROM Plant 
    WHERE 
    EcolabAccountNumber = @EcolabAccountNumber

    SELECT @ControllerId =  wg.ControllerId FROM TCD.WasherGroup wg WHERE wg.WasherGroupId = @WasherGroupId AND wg.EcolabAccountNumber = @EcolabAccountNumber

    IF @ControllerId IS NULL OR @Controllerid = 0
    BEGIN
    IF @WasherGroupId IS NULL
    BEGIN
        SELECT 
        Map.ProductId, RTRIM(Name) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name
        , M.Cost
        , M.IncludeinCI
        , TCD.FnChemicalCostInOunce(Map.ProductId) AS        Price
    , 0
        FROM ProductMaster M
        INNER JOIN ProductdataMapping Map ON M.ProductId = Map.ProductId AND Map.Is_Deleted=0
        WHERE 
        (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
        AND M.RegionId = @RegionId
        AND M.Is_Deleted =0
    END
    ELSE
    BEGIN
        SELECT DISTINCT
        Map.ProductId, RTRIM(Name) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name
        , M.Cost
        , M.IncludeinCI
        , TCD.FnChemicalCostInOunce(Map.ProductId) AS        Price
    , 0
        FROM TCD.ProductMaster M
        INNER JOIN TCD.ProductdataMapping Map ON M.ProductId = Map.ProductId AND Map.Is_Deleted=0
        LEFT JOIN TCD.ControllerEquipmentSetup ces ON ces.ProductId = Map.ProductId AND ces.EcoLabAccountNumber = Map.EcolabAccountNumber
        INNER JOIN TCD.MachineSetup ms ON ms.ControllerId = ces.ControllerId AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber AND ms.IsDeleted = 'False'
        INNER JOIN TCD.WasherGroup wg ON wg.WasherGroupId = ms.GroupId AND wg.EcolabAccountNumber = ms.EcoalabAccountNumber
        WHERE wg.WasherGroupId = ISNULL(@WasherGroupId, wg.WasherGroupId)
        AND (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
        AND M.RegionId = @RegionId
        AND M.Is_Deleted =0
        END
     END
    ELSE
    BEGIN
        SELECT @ControllerModelId = cc.ControllerModelId, @ControllerTypeId = cc.ControllerTypeId FROM TCD.ConduitController cc WHERE cc.ControllerId = @ControllerId

        IF @ControllerModelId = 11
        BEGIN
            SELECT DISTINCT
            Map.ProductId, RTRIM(CASE  
                        WHEN EnvisionDisplayName IS NULL THEN NAME 
                        ELSE EnvisionDisplayName 
                        END ) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name
            , M.Cost
            , M.IncludeinCI
            , CAST (ces.ControllerEquipmentTypeId AS int) AS ControllerEquipmentTypeId
            FROM ProductMaster M
            INNER JOIN ProductdataMapping Map ON M.ProductId = Map.ProductId AND Map.Is_Deleted=0  
            INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.EcoLabAccountNumber = Map.EcolabAccountNumber AND ces.ProductId = Map.ProductID
            LEFT JOIN TCD.TunnelCompartmentEquipmentValveMapping tcevm ON ces.ControllerEquipmentSetupID = tcevm.ControllerEquipmentSetupID AND tcevm.DirectDosingFlag = 1
            WHERE 
            (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
            AND tcevm.ControllerEquipmentSetupID IS NULL
            AND M.RegionId = @RegionId
            AND M.Is_Deleted =0
            AND ces.ControllerId = @ControllerId
            AND ces.WasherGroupNumber =  CASE WHEN @ControllerTypeId = 13 THEN 1 ELSE ces.WasherGroupNumber END
    END
        ELSE
        BEGIN
            SELECT DISTINCT
            Map.ProductId, RTRIM(CASE  
                        WHEN EnvisionDisplayName IS NULL THEN NAME 
                        ELSE EnvisionDisplayName 
                        END ) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name
    , M.Cost
    , M.IncludeinCI
    , TCD.FnChemicalCostInOunce(Map.ProductId) AS        Price
            , CAST (ces.ControllerEquipmentTypeId AS int) AS ControllerEquipmentTypeId
    FROM ProductMaster M
    INNER JOIN ProductdataMapping Map ON M.ProductId = Map.ProductId AND Map.Is_Deleted=0     
            INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.EcoLabAccountNumber = Map.EcolabAccountNumber AND ces.ProductId = Map.ProductID 
		  AND CASE WHEN @ControllerModelId = 7 THEN ces.ConventionalWasherGroupConnection ELSE ISNULL(ces.ConventionalWasherGroupConnection, 0) END = CASE WHEN @ControllerModelId = 7 THEN 1 ELSE 0 END
            LEFT JOIN TCD.TunnelCompartmentEquipmentValveMapping tcevm ON ces.ControllerEquipmentSetupID = tcevm.ControllerEquipmentSetupID AND tcevm.DirectDosingFlag = 1
    WHERE 
    (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
            AND tcevm.ControllerEquipmentSetupID IS NULL
    AND M.RegionId = @RegionId
    AND M.Is_Deleted =0
            AND ces.ControllerId = @ControllerId
        END
    END
        

    SET NOCOUNT OFF 
 
END
GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetCompartmentDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetCompartmentDetails
	END
GO
CREATE PROCEDURE [TCD].[GetCompartmentDetails] @EcoLabAccountNumber NVARCHAR(25)
 ,@WasherGroupId INT
 ,@TunnelId INT
 ,@CompartmentNumber TINYINT = 1
 ,@IsDelete BIT = 'False'
AS
BEGIN
 SET NOCOUNT ON

 DECLARE @RegionId INT,
 @ControllerModelId int

 SET @RegionId = (
   SELECT DISTINCT RegionId
   FROM TCD.Plant
   WHERE EcolabAccountNumber = @EcoLabAccountNumber
    AND Is_Deleted = 0
   )

 DECLARE @ReturnValue INT = 0
  ,@ErrorId INT = 0
  ,@ErrorMessage NVARCHAR(4000) = N''
  ,@ControllerId INT = NULL
  ,@NumberOfComp TINYINT = NULL
  ,@DosagePoint BIT = NULL

 SET @WasherGroupId = ISNULL(@WasherGroupId, NULL) --SQLEnlight SA0029

 --Get ControllerId, Number
 SELECT @ControllerId = ISNULL(MS.ControllerId, - 1)
  ,@NumberOfComp = ISNULL(MS.NumberOfComp, - 1)
 FROM [TCD].MachineSetup MS
 INNER JOIN [TCD].ConduitController CC ON MS.ControllerId = CC.ControllerId
  AND MS.EcoalabAccountNumber = CC.EcoalabAccountNumber
 WHERE MS.EcoalabAccountNumber = @EcoLabAccountNumber
  AND MS.WasherId = @TunnelId
  AND MS.IsTunnel = 'TRUE'
  AND MS.IsDeleted = 'FALSE'
  AND CC.IsDeleted = 'FALSE'

  SELECT @ControllerModelId = cc.ControllerModelId from tcd.ConduitController cc WHERE cc.ControllerId = @ControllerId

 --if we didn't get a valid Controller, error-out
 IF (@ControllerId = - 1)
 BEGIN
  SET @ErrorId = 51020
  SET @ErrorMessage = N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Could not determine the Controller for the specified tunnel.'

  RAISERROR (
    @ErrorMessage
    ,16
    ,1
    )

  SET @ReturnValue = - 1

  RETURN (@ReturnValue)
 END

 --CompartmentNumber
 IF (@CompartmentNumber > @NumberOfComp)
 BEGIN
  SET @ErrorId = 51021
  SET @ErrorMessage = N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Invalid Compartment Number specified for the tunnel.'

  RAISERROR (
    @ErrorMessage
    ,16
    ,1
    )

  SET @ReturnValue = - 1

  RETURN (@ReturnValue)
 END

 --Select the details of the compartment...
 ;WITH CTE_ComptNumbersForTunnel
AS (
    SELECT MS.GroupId, 'ALL' AS CompartmentNumber, MS.NumberOfComp
    FROM TCD.MachineSetup AS MS
    WHERE MS.IsTunnel = 1 AND MS.IsDeleted = 0
)

, CTE_ComptNumbersforEachWasherGroup 
AS (
    SELECT  C.GroupId
            , TunnelCompNumber = 1
            , CompartmentNumber
    , NumberOfComp
    FROM    CTE_ComptNumbersForTunnel C
    UNION ALL 
    SELECT  GroupId
            , TunnelCompNumber = TunnelCompNumber + 1
            , CompartmentNumber
    , NumberOfComp
    FROM    CTE_ComptNumbersforEachWasherGroup
    WHERE   NumberOfComp > TunnelCompNumber
)
, CTE_SensorsForEachCompartment 
AS (
    SELECT CASE 
        WHEN S.MachineCompartment IS NULL AND ISNULL(S.IsPress,0) = 0  
        THEN 'ALL'
        WHEN ( SELECT DISTINCT Istunnel
       FROM [TCD].machinesetup M
       WHERE M.groupId = S.GroupId ) = 1 
       AND S.MachineCompartment IS NOT NULL 
       AND ISNULL(S.IsPress,0) = 0 
        THEN CAST(S.Machinecompartment - 1 AS VARCHAR)
    END AS CompartmentNumber
    , CASE WHEN STM.Name = 'Temperature' THEN '1' ELSE '0' END AS Temperature
    , CASE WHEN STM.Name = 'pH' THEN '1' ELSE '0' END AS pH
    , CASE WHEN STM.Name = 'Conductivity' THEN '1' ELSE '0' END AS Conductivity
    , CASE WHEN STM.Name = 'Redox' THEN '1' ELSE '0' END AS Redox
    , S.GroupId
    , S.ControllerID
    FROM TCD.Sensor AS S 
    LEFT JOIN TCD.SensorTypeMaster AS STM ON S.SensorType = STM.ResourceId
 WHERE S.Is_Deleted = 0
    )
, CTE_TunnelSensors
AS (
    SELECT  Sensors.GroupId
    , Sensors.ControllerID
    , TunnelCompNumberForWG.TunnelCompNumber AS CompartmentNumber
    , MAX(Sensors.pH) AS pH
    , MAX(Sensors.Temperature) AS Temperature
    , MAX(Sensors.Conductivity) AS Conductivity
    , MAX(Sensors.Redox) AS Redox
    FROM CTE_SensorsForEachCompartment AS Sensors
    LEFT JOIN CTE_ComptNumbersforEachWasherGroup AS TunnelCompNumberForWG
    ON Sensors.GroupId = TunnelCompNumberForWG.GroupId 
    AND Sensors.CompartmentNumber = CASE WHEN Sensors.CompartmentNumber = 'ALL' 
            THEN TunnelCompNumberForWG.CompartmentNumber
         WHEN Sensors.CompartmentNumber <> 'ALL' 
            THEN CAST(TunnelCompNumberForWG.TunnelCompNumber AS VARCHAR)
        END
 GROUP BY Sensors.GroupId, Sensors.ControllerID, TunnelCompNumberForWG.TunnelCompNumber
 )
 SELECT TC.WashStepId AS WashStepId
  ,TC.WaterInletDrainId AS WaterInletDrainId
  ,TC.WaterFlowId AS WaterFlowId
  ,TC.WaterLevel AS WaterLevel
  ,TC.TemperatureControlByPMR AS TemperatureControlByPMR
  ,TC.UsePressExtractWater AS UsePressExtractWater
  ,TC.SplitCompartment AS SplitCompartment
  ,TC.RecycledWaterInlet AS RecycledWaterInlet
  ,TC.Steam AS Steam
  ,@CompartmentNumber AS CompartmentNumber
  ,TC.IterationPoint AS IterationPoint
  --Adding cols. for integration with Synch./Central
  ,TC.LastModifiedTime AS LastModifiedTime
  ,TC.LastSyncTime AS LastSyncTime
  ,TC.TunnelCompartmentId AS TunnelCompartmentId
  ,TC.WasherId AS WasherId
  ,TC.EcoLabAccountNumber AS EcoLabAccountNumber
  ,W.MyServiceCustMchGuid AS MyServiceWasherId
  ,TWIDL.MyServicePropId AS MyServiceDrainLookupId
  ,TWFT.MyServicePropId AS MyServiceWaterFlowTypeId
  ,CAST(ISNULL(CTE.Temperature, 0) as bit) AS Temperature
  ,CAST(ISNULL(CTE.pH, 0) as bit) AS PhProbe
  ,CAST(ISNULL(CTE.Conductivity, 0) as bit) AS Conductivity
  ,CAST(ISNULL(CTE.Redox, 0) as bit) AS Redox
 FROM [TCD].Washer W
 INNER JOIN [TCD].MachineSetup MS ON W.WasherId = MS.WasherId
  AND W.EcoLabAccountNumber = MS.EcoalabAccountNumber
 INNER JOIN [TCD].TunnelCompartment TC ON W.WasherId = TC.WasherId
  AND W.EcoLabAccountNumber = TC.EcoLabAccountNumber
 INNER JOIN [TCD].TunnelWaterInletDrainLookup TWIDL ON TC.WaterInletDrainId = TWIDL.TunnelWaterInletDrainLookupId
 INNER JOIN [TCD].TunnelWaterFlowType TWFT ON TC.WaterFlowId = TWFT.TunnelWaterFlowTypeId
 LEFT JOIN CTE_TunnelSensors CTE ON CTE.GroupId = MS.GroupId AND CTE.CompartmentNumber = @CompartmentNumber
 WHERE W.EcoLabAccountNumber = @EcoLabAccountNumber
  AND W.WasherId = @TunnelId
  AND MS.IsTunnel = 'TRUE'
  AND (
   W.Is_Deleted = 'FALSE'
   OR W.Is_Deleted = @IsDelete
   )
  AND (
   MS.IsDeleted = 'FALSE'
   OR MS.IsDeleted = @IsDelete
   )
  AND TC.CompartmentNumber = @CompartmentNumber
  
 --select the equipment association...
 IF (@RegionId = 1)
 BEGIN
 IF(@ControllerModelId = 7)
 BEGIN

 SELECT DISTINCT CES.ControllerEquipmentSetupId
   ,CES.ControllerEquipmentId
   ,CES.ControllerEquipmentTypeId
   ,ISNULL(NULLIF(PM.EnvisionDisplayName,''), PM.NAME) AS ProductName
   ,NEWID() AS MyServiceCmpmtDsgDvcguid
   ,CAST(0 AS BIT) AS IsDelete
   ,(
    SELECT Count(*)
    FROM [TCD].TunnelDosingSetup tds
    INNER JOIN [TCD].TunnelDosingProductMapping TDPM ON TDPM.GroupId = TDS.GroupId
    INNER JOIN [TCD].TunnelProgramSetup TPS ON TPS.TunnelProgramSetupId = TDS.TunnelProgramSetupId
     AND TPS.Is_Deleted = 'FALSE'
    WHERE TDPM.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
     AND TDPM.CompartmentNumber = TDS.CompartmentNumber
     AND TDPM.GroupId = MS.GroupId
    ) AS FormulaAssociated
  FROM TCD.TunnelCompartmentEquipmentValveMapping AS TCEVM
  INNER JOIN TCD.ControllerEquipmentSetup CES ON TCEVM.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId
  INNER JOIN TCD.MachineSetup AS MS ON TCEVM.TunnelNumber = MS.MachineInternalId
   AND CES.ControllerId = MS.ControllerId
  INNER JOIN tcd.ProductdataMapping PDM ON PDM.ProductID = CES.ProductId
   AND PDM.EcoLabAccountNumber = CES.EcoLabAccountNumber
  INNER JOIN tcd.productMaster PM ON PM.ProductId = PDM.ProductID
  WHERE MS.WASHERID = @TunnelId
   AND CES.EcolabAccountNumber = @EcoLabAccountNumber
   AND TCEVM.CompartmentNumber = @CompartmentNumber
   AND (
    MS.IsDeleted = 'FALSE'
    OR MS.IsDeleted = @IsDelete
    )
   AND PDM.Is_Deleted = 0
END
 ELSE
 BEGIN
 SELECT TCEM.ControllerEquipmentSetupId AS ControllerEquipmentSetupId
   ,CES.ControllerEquipmentId AS ControllerEquipmentId
   ,CES.ControllerEquipmentTypeId AS ControllerEquipmentTypeId
   ,ISNULL(NULLIF(PM.EnvisionDisplayName,''), PM.NAME) AS ProductName
   ,TCEM.MyServiceCmpmtDsgDvcguid AS MyServiceCmpmtDsgDvcguid
   ,TCEM.Is_Deleted AS IsDelete
   ,(
    SELECT Count(*)
    FROM [TCD].TunnelDosingSetup tds
    INNER JOIN [TCD].TunnelDosingProductMapping TDPM ON TDPM.GroupId = TDS.GroupId
    INNER JOIN [TCD].TunnelProgramSetup tps ON tps.TunnelProgramSetupId = tds.TunnelProgramSetupId
     AND tps.Is_Deleted = 'false'
    WHERE TDPM.ControllerEquipmentSetupId = TCEM.ControllerEquipmentSetupId
     AND TDPM.CompartmentNumber = TDS.CompartmentNumber
     AND TDPM.GroupId = MS.GroupId
    ) AS FormulaAssociated
  FROM [TCD].Washer W
  INNER JOIN [TCD].MachineSetup MS ON W.WasherId = MS.WasherId
   AND W.EcoLabAccountNumber = MS.EcoalabAccountNumber
  INNER JOIN [TCD].TunnelCompartment TC ON W.WasherId = TC.WasherId
   AND W.EcoLabAccountNumber = TC.EcoLabAccountNumber
  INNER JOIN [TCD].TunnelCompartmentEquipmentMapping TCEM ON TC.TunnelCompartmentId = TCEM.TunnelCompartmentId
   AND TC.EcoLabAccountNumber = TCEM.EcoLabAccountNumber
  INNER JOIN [TCD].ControllerEquipmentSetup CES ON TCEM.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId
   AND TCEM.EcoLabAccountNumber = CES.EcoLabAccountNumber
   AND CES.ControllerId = MS.ControllerId
  INNER JOIN [TCD].ProductMaster PM ON CES.ProductId = PM.ProductId
  WHERE W.EcoLabAccountNumber = @EcoLabAccountNumber
   AND W.WasherId = @TunnelId
   AND MS.IsTunnel = 'TRUE'
   AND (
    W.Is_Deleted = 'FALSE'
    OR W.Is_Deleted = @IsDelete
    )
   AND (
    MS.IsDeleted = 'FALSE'
    OR MS.IsDeleted = @IsDelete
    )
   AND TC.CompartmentNumber = @CompartmentNumber
   AND (
    TCEM.Is_Deleted = 'FALSE'
    OR TCEM.Is_Deleted = @IsDelete
    )
   AND (
    PM.Is_Deleted = 'FALSE'
    OR PM.Is_Deleted = @IsDelete
    )
 END

  
 END
 ELSE IF (@RegionId = 2)
 BEGIN
  SELECT DISTINCT CES.ControllerEquipmentSetupId
   ,CES.ControllerEquipmentId
   ,CES.ControllerEquipmentTypeId
   ,ISNULL(NULLIF(PM.EnvisionDisplayName,''), PM.NAME) AS ProductName
   ,NEWID() AS MyServiceCmpmtDsgDvcguid
   ,CAST(0 AS BIT) AS IsDelete
   ,(
    SELECT Count(*)
    FROM [TCD].TunnelDosingSetup tds
    INNER JOIN [TCD].TunnelDosingProductMapping TDPM ON TDPM.GroupId = TDS.GroupId
    INNER JOIN [TCD].TunnelProgramSetup TPS ON TPS.TunnelProgramSetupId = TDS.TunnelProgramSetupId
     AND TPS.Is_Deleted = 'FALSE'
    WHERE TDPM.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
     AND TDPM.CompartmentNumber = TDS.CompartmentNumber
     AND TDPM.GroupId = MS.GroupId
    ) AS FormulaAssociated
  FROM TCD.TunnelCompartmentEquipmentValveMapping AS TCEVM
  INNER JOIN TCD.ControllerEquipmentSetup CES ON TCEVM.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId
  INNER JOIN TCD.MachineSetup AS MS ON TCEVM.TunnelNumber = MS.MachineInternalId
   AND CES.ControllerId = MS.ControllerId
  INNER JOIN tcd.ProductdataMapping PDM ON PDM.ProductID = CES.ProductId
   AND PDM.EcoLabAccountNumber = CES.EcoLabAccountNumber
  INNER JOIN tcd.productMaster PM ON PM.ProductId = PDM.ProductID
  WHERE MS.WASHERID = @TunnelId
   AND CES.EcolabAccountNumber = @EcoLabAccountNumber
   AND TCEVM.CompartmentNumber = @CompartmentNumber
   AND (
    MS.IsDeleted = 'FALSE'
    OR MS.IsDeleted = @IsDelete
    )
   AND PDM.Is_Deleted = 0
 END

 SET NOCOUNT OFF
END
GO

IF Exists( SELECT 1 FROM tcd.ResourceKeyValue rkv WHERE rkv.KeyName='EURO' AND rkv.LanguageID=1)
BEGIN
	UPDATE tcd.ResourceKeyValue
	SET
	    TCD.ResourceKeyValue.[Value] = N'�'
		WHERE KeyName='EURO' AND LanguageID=1
END
GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetCompartmentDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetCompartmentDetails
	END
GO

CREATE PROCEDURE [TCD].[GetCompartmentDetails] @EcoLabAccountNumber NVARCHAR(25)
 ,@WasherGroupId INT
 ,@TunnelId INT
 ,@CompartmentNumber TINYINT = 1
 ,@IsDelete BIT = 'False'
AS
BEGIN
 SET NOCOUNT ON

 DECLARE @RegionId INT,
 @ControllerModelId int

 SET @RegionId = (
   SELECT DISTINCT RegionId
   FROM TCD.Plant
   WHERE EcolabAccountNumber = @EcoLabAccountNumber
    AND Is_Deleted = 0
   )

 DECLARE @ReturnValue INT = 0
  ,@ErrorId INT = 0
  ,@ErrorMessage NVARCHAR(4000) = N''
  ,@ControllerId INT = NULL
  ,@NumberOfComp TINYINT = NULL
  ,@DosagePoint BIT = NULL

 SET @WasherGroupId = ISNULL(@WasherGroupId, NULL) --SQLEnlight SA0029

 --Get ControllerId, Number
 SELECT @ControllerId = ISNULL(MS.ControllerId, - 1)
  ,@NumberOfComp = ISNULL(MS.NumberOfComp, - 1)
 FROM [TCD].MachineSetup MS
 INNER JOIN [TCD].ConduitController CC ON MS.ControllerId = CC.ControllerId
  AND MS.EcoalabAccountNumber = CC.EcoalabAccountNumber
 WHERE MS.EcoalabAccountNumber = @EcoLabAccountNumber
  AND MS.WasherId = @TunnelId
  AND MS.IsTunnel = 'TRUE'
  AND MS.IsDeleted = 'FALSE'
  AND CC.IsDeleted = 'FALSE'

  SELECT @ControllerModelId = cc.ControllerModelId from tcd.ConduitController cc WHERE cc.ControllerId = @ControllerId

 --if we didn't get a valid Controller, error-out
 IF (@ControllerId = - 1)
 BEGIN
  SET @ErrorId = 51020
  SET @ErrorMessage = N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Could not determine the Controller for the specified tunnel.'

  RAISERROR (
    @ErrorMessage
    ,16
    ,1
    )

  SET @ReturnValue = - 1

  RETURN (@ReturnValue)
 END

 --CompartmentNumber
 IF (@CompartmentNumber > @NumberOfComp)
 BEGIN
  SET @ErrorId = 51021
  SET @ErrorMessage = N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Invalid Compartment Number specified for the tunnel.'

  RAISERROR (
    @ErrorMessage
    ,16
    ,1
    )

  SET @ReturnValue = - 1

  RETURN (@ReturnValue)
 END

 --Select the details of the compartment...
 ;WITH CTE_ComptNumbersForTunnel
AS (
    SELECT MS.GroupId, 'ALL' AS CompartmentNumber, MS.NumberOfComp
    FROM TCD.MachineSetup AS MS
    WHERE MS.IsTunnel = 1 AND MS.IsDeleted = 0
)

, CTE_ComptNumbersforEachWasherGroup 
AS (
    SELECT  C.GroupId
            , TunnelCompNumber = 1
            , CompartmentNumber
    , NumberOfComp
    FROM    CTE_ComptNumbersForTunnel C
    UNION ALL 
    SELECT  GroupId
            , TunnelCompNumber = TunnelCompNumber + 1
            , CompartmentNumber
    , NumberOfComp
    FROM    CTE_ComptNumbersforEachWasherGroup
    WHERE   NumberOfComp > TunnelCompNumber
)
, CTE_SensorsForEachCompartment 
AS (
    SELECT CASE 
        WHEN S.MachineCompartment IS NULL AND ISNULL(S.IsPress,0) = 0  
        THEN 'ALL'
        WHEN 
		--( SELECT DISTINCT Istunnel
      -- FROM [TCD].machinesetup M
      -- WHERE M.groupId = S.GroupId ) = 1 
       --AND
	    S.MachineCompartment IS NOT NULL 
       --AND ISNULL(S.IsPress,0) = 0 
        THEN CAST(S.Machinecompartment AS VARCHAR)
    END AS CompartmentNumber
    , CASE WHEN STM.Name = 'Temperature' THEN '1' ELSE '0' END AS Temperature
    , CASE WHEN STM.Name = 'pH' THEN '1' ELSE '0' END AS pH
    , CASE WHEN STM.Name = 'Conductivity' THEN '1' ELSE '0' END AS Conductivity
    , CASE WHEN STM.Name = 'Redox' THEN '1' ELSE '0' END AS Redox
    , S.GroupId
    , S.ControllerID
    FROM TCD.Sensor AS S 
    LEFT JOIN TCD.SensorTypeMaster AS STM ON S.SensorType = STM.ResourceId
 WHERE S.Is_Deleted = 0
    )
, CTE_TunnelSensors
AS (
    SELECT  Sensors.GroupId
    , Sensors.ControllerID
    , TunnelCompNumberForWG.TunnelCompNumber AS CompartmentNumber
    , MAX(Sensors.pH) AS pH
    , MAX(Sensors.Temperature) AS Temperature
    , MAX(Sensors.Conductivity) AS Conductivity
    , MAX(Sensors.Redox) AS Redox
    FROM CTE_SensorsForEachCompartment AS Sensors
    LEFT JOIN CTE_ComptNumbersforEachWasherGroup AS TunnelCompNumberForWG
    ON Sensors.GroupId = TunnelCompNumberForWG.GroupId 
    AND Sensors.CompartmentNumber = CASE WHEN Sensors.CompartmentNumber = 'ALL' 
            THEN TunnelCompNumberForWG.CompartmentNumber
         WHEN Sensors.CompartmentNumber <> 'ALL' 
            THEN CAST(TunnelCompNumberForWG.TunnelCompNumber AS VARCHAR)
        END
 GROUP BY Sensors.GroupId, Sensors.ControllerID, TunnelCompNumberForWG.TunnelCompNumber
 )
 SELECT TC.WashStepId AS WashStepId
  ,TC.WaterInletDrainId AS WaterInletDrainId
  ,TC.WaterFlowId AS WaterFlowId
  ,TC.WaterLevel AS WaterLevel
  ,TC.TemperatureControlByPMR AS TemperatureControlByPMR
  ,TC.UsePressExtractWater AS UsePressExtractWater
  ,TC.SplitCompartment AS SplitCompartment
  ,TC.RecycledWaterInlet AS RecycledWaterInlet
  ,TC.Steam AS Steam
  ,@CompartmentNumber AS CompartmentNumber
  ,TC.IterationPoint AS IterationPoint
  --Adding cols. for integration with Synch./Central
  ,TC.LastModifiedTime AS LastModifiedTime
  ,TC.LastSyncTime AS LastSyncTime
  ,TC.TunnelCompartmentId AS TunnelCompartmentId
  ,TC.WasherId AS WasherId
  ,TC.EcoLabAccountNumber AS EcoLabAccountNumber
  ,W.MyServiceCustMchGuid AS MyServiceWasherId
  ,TWIDL.MyServicePropId AS MyServiceDrainLookupId
  ,TWFT.MyServicePropId AS MyServiceWaterFlowTypeId
  ,CAST(ISNULL(CTE.Temperature, 0) as bit) AS Temperature
  ,CAST(ISNULL(CTE.pH, 0) as bit) AS PhProbe
  ,CAST(ISNULL(CTE.Conductivity, 0) as bit) AS Conductivity
  ,CAST(ISNULL(CTE.Redox, 0) as bit) AS Redox
 FROM [TCD].Washer W
 INNER JOIN [TCD].MachineSetup MS ON W.WasherId = MS.WasherId
  AND W.EcoLabAccountNumber = MS.EcoalabAccountNumber
 INNER JOIN [TCD].TunnelCompartment TC ON W.WasherId = TC.WasherId
  AND W.EcoLabAccountNumber = TC.EcoLabAccountNumber
 INNER JOIN [TCD].TunnelWaterInletDrainLookup TWIDL ON TC.WaterInletDrainId = TWIDL.TunnelWaterInletDrainLookupId
 INNER JOIN [TCD].TunnelWaterFlowType TWFT ON TC.WaterFlowId = TWFT.TunnelWaterFlowTypeId
 LEFT JOIN CTE_TunnelSensors CTE ON CTE.GroupId = MS.GroupId AND CTE.CompartmentNumber = @CompartmentNumber
 WHERE W.EcoLabAccountNumber = @EcoLabAccountNumber
  AND W.WasherId = @TunnelId
  AND MS.IsTunnel = 'TRUE'
  AND (
   W.Is_Deleted = 'FALSE'
   OR W.Is_Deleted = @IsDelete
   )
  AND (
   MS.IsDeleted = 'FALSE'
   OR MS.IsDeleted = @IsDelete
   )
  AND TC.CompartmentNumber = @CompartmentNumber
  
 --select the equipment association...
 IF (@RegionId = 1)
 BEGIN
 IF(@ControllerModelId = 7)
 BEGIN

 SELECT DISTINCT CES.ControllerEquipmentSetupId
   ,CES.ControllerEquipmentId
   ,CES.ControllerEquipmentTypeId
   ,ISNULL(NULLIF(PM.EnvisionDisplayName,''), PM.NAME) AS ProductName
   ,NEWID() AS MyServiceCmpmtDsgDvcguid
   ,CAST(0 AS BIT) AS IsDelete
   ,(
    SELECT Count(*)
    FROM [TCD].TunnelDosingSetup tds
    INNER JOIN [TCD].TunnelDosingProductMapping TDPM ON TDPM.GroupId = TDS.GroupId
    INNER JOIN [TCD].TunnelProgramSetup TPS ON TPS.TunnelProgramSetupId = TDS.TunnelProgramSetupId
     AND TPS.Is_Deleted = 'FALSE'
    WHERE TDPM.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
     AND TDPM.CompartmentNumber = TDS.CompartmentNumber
     AND TDPM.GroupId = MS.GroupId
    ) AS FormulaAssociated
  FROM TCD.TunnelCompartmentEquipmentValveMapping AS TCEVM
  INNER JOIN TCD.ControllerEquipmentSetup CES ON TCEVM.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId
  INNER JOIN TCD.MachineSetup AS MS ON TCEVM.TunnelNumber = MS.MachineInternalId
   AND CES.ControllerId = MS.ControllerId
  INNER JOIN tcd.ProductdataMapping PDM ON PDM.ProductID = CES.ProductId
   AND PDM.EcoLabAccountNumber = CES.EcoLabAccountNumber
  INNER JOIN tcd.productMaster PM ON PM.ProductId = PDM.ProductID
  WHERE MS.WASHERID = @TunnelId
   AND CES.EcolabAccountNumber = @EcoLabAccountNumber
   AND TCEVM.CompartmentNumber = @CompartmentNumber
   AND (
    MS.IsDeleted = 'FALSE'
    OR MS.IsDeleted = @IsDelete
    )
   AND PDM.Is_Deleted = 0
END
 ELSE
 BEGIN
 SELECT TCEM.ControllerEquipmentSetupId AS ControllerEquipmentSetupId
   ,CES.ControllerEquipmentId AS ControllerEquipmentId
   ,CES.ControllerEquipmentTypeId AS ControllerEquipmentTypeId
   ,ISNULL(NULLIF(PM.EnvisionDisplayName,''), PM.NAME) AS ProductName
   ,TCEM.MyServiceCmpmtDsgDvcguid AS MyServiceCmpmtDsgDvcguid
   ,TCEM.Is_Deleted AS IsDelete
   ,(
    SELECT Count(*)
    FROM [TCD].TunnelDosingSetup tds
    INNER JOIN [TCD].TunnelDosingProductMapping TDPM ON TDPM.GroupId = TDS.GroupId
    INNER JOIN [TCD].TunnelProgramSetup tps ON tps.TunnelProgramSetupId = tds.TunnelProgramSetupId
     AND tps.Is_Deleted = 'false'
    WHERE TDPM.ControllerEquipmentSetupId = TCEM.ControllerEquipmentSetupId
     AND TDPM.CompartmentNumber = TDS.CompartmentNumber
     AND TDPM.GroupId = MS.GroupId
    ) AS FormulaAssociated
  FROM [TCD].Washer W
  INNER JOIN [TCD].MachineSetup MS ON W.WasherId = MS.WasherId
   AND W.EcoLabAccountNumber = MS.EcoalabAccountNumber
  INNER JOIN [TCD].TunnelCompartment TC ON W.WasherId = TC.WasherId
   AND W.EcoLabAccountNumber = TC.EcoLabAccountNumber
  INNER JOIN [TCD].TunnelCompartmentEquipmentMapping TCEM ON TC.TunnelCompartmentId = TCEM.TunnelCompartmentId
   AND TC.EcoLabAccountNumber = TCEM.EcoLabAccountNumber
  INNER JOIN [TCD].ControllerEquipmentSetup CES ON TCEM.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId
   AND TCEM.EcoLabAccountNumber = CES.EcoLabAccountNumber
   AND CES.ControllerId = MS.ControllerId
  INNER JOIN [TCD].ProductMaster PM ON CES.ProductId = PM.ProductId
  WHERE W.EcoLabAccountNumber = @EcoLabAccountNumber
   AND W.WasherId = @TunnelId
   AND MS.IsTunnel = 'TRUE'
   AND (
    W.Is_Deleted = 'FALSE'
    OR W.Is_Deleted = @IsDelete
    )
   AND (
    MS.IsDeleted = 'FALSE'
    OR MS.IsDeleted = @IsDelete
    )
   AND TC.CompartmentNumber = @CompartmentNumber
   AND (
    TCEM.Is_Deleted = 'FALSE'
    OR TCEM.Is_Deleted = @IsDelete
    )
   AND (
    PM.Is_Deleted = 'FALSE'
    OR PM.Is_Deleted = @IsDelete
    )
 END

  
 END
 ELSE IF (@RegionId = 2)
 BEGIN
  SELECT DISTINCT CES.ControllerEquipmentSetupId
   ,CES.ControllerEquipmentId
   ,CES.ControllerEquipmentTypeId
   ,ISNULL(NULLIF(PM.EnvisionDisplayName,''), PM.NAME) AS ProductName
   ,NEWID() AS MyServiceCmpmtDsgDvcguid
   ,CAST(0 AS BIT) AS IsDelete
   ,(
    SELECT Count(*)
    FROM [TCD].TunnelDosingSetup tds
    INNER JOIN [TCD].TunnelDosingProductMapping TDPM ON TDPM.GroupId = TDS.GroupId
    INNER JOIN [TCD].TunnelProgramSetup TPS ON TPS.TunnelProgramSetupId = TDS.TunnelProgramSetupId
     AND TPS.Is_Deleted = 'FALSE'
    WHERE TDPM.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
     AND TDPM.CompartmentNumber = TDS.CompartmentNumber
     AND TDPM.GroupId = MS.GroupId
    ) AS FormulaAssociated
  FROM TCD.TunnelCompartmentEquipmentValveMapping AS TCEVM
  INNER JOIN TCD.ControllerEquipmentSetup CES ON TCEVM.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId
  INNER JOIN TCD.MachineSetup AS MS ON TCEVM.TunnelNumber = MS.MachineInternalId
   AND CES.ControllerId = MS.ControllerId
  INNER JOIN tcd.ProductdataMapping PDM ON PDM.ProductID = CES.ProductId
   AND PDM.EcoLabAccountNumber = CES.EcoLabAccountNumber
  INNER JOIN tcd.productMaster PM ON PM.ProductId = PDM.ProductID
  WHERE MS.WASHERID = @TunnelId
   AND CES.EcolabAccountNumber = @EcoLabAccountNumber
   AND TCEVM.CompartmentNumber = @CompartmentNumber
   AND (
    MS.IsDeleted = 'FALSE'
    OR MS.IsDeleted = @IsDelete
    )
   AND PDM.Is_Deleted = 0
 END

 SET NOCOUNT OFF
END
GO
IF EXISTS(SELECT * FROM [TCD].[Field] f WHERE f.Id=228 and f.DefaultFieldTag	='x_invertMachineStop')
BEGIN	
	UPDATE	[TCD].[Field]  SET	HasFieldTag='Tag_IMS' where	Id=228 and DefaultFieldTag	='x_invertMachineStop'
END
GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetUsedChemicalName]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetUsedChemicalName
	END
GO
CREATE PROCEDURE [TCD].[GetUsedChemicalName]
    @ChemName Varchar(1000)
    ,@EcolabAccountNumber NVARCHAR(25)
    ,@WasherGroupId    INT = NULL
AS     

BEGIN     
    SET NOCOUNT ON    
    
    DECLARE @RegionId            INT =    NULL
        ,    @ControllerId        INT    =    NULL
        ,    @ControllerModelId    INT    =    NULL
        ,    @ControllerTypeId    INT    =    NULL
    
    SELECT 
    @RegionId = RegionID FROM Plant 
    WHERE 
    EcolabAccountNumber = @EcolabAccountNumber

    SELECT @ControllerId =  wg.ControllerId FROM TCD.WasherGroup wg WHERE wg.WasherGroupId = @WasherGroupId AND wg.EcolabAccountNumber = @EcolabAccountNumber

    IF @ControllerId IS NULL OR @Controllerid = 0
    BEGIN
    IF @WasherGroupId IS NULL
    BEGIN
        SELECT 
        Map.ProductId, RTRIM(ISNULL(NULLIF(M.EnvisionDisplayName, ' '), M.Name)) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name
        , M.Cost
        , M.IncludeinCI
        , TCD.FnChemicalCostInOunce(Map.ProductId) AS        Price
    , 0
        FROM ProductMaster M
        INNER JOIN ProductdataMapping Map ON M.ProductId = Map.ProductId AND Map.Is_Deleted=0
        WHERE 
        (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
        AND M.RegionId = @RegionId
        AND M.Is_Deleted =0
    END
    ELSE
    BEGIN
        SELECT DISTINCT
        Map.ProductId, RTRIM(ISNULL(NULLIF(M.EnvisionDisplayName, ' '), M.Name)) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name
        , M.Cost
        , M.IncludeinCI
        , TCD.FnChemicalCostInOunce(Map.ProductId) AS        Price
    , 0
        FROM TCD.ProductMaster M
        INNER JOIN TCD.ProductdataMapping Map ON M.ProductId = Map.ProductId AND Map.Is_Deleted=0
        LEFT JOIN TCD.ControllerEquipmentSetup ces ON ces.ProductId = Map.ProductId AND ces.EcoLabAccountNumber = Map.EcolabAccountNumber
        INNER JOIN TCD.MachineSetup ms ON ms.ControllerId = ces.ControllerId AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber AND ms.IsDeleted = 'False'
        INNER JOIN TCD.WasherGroup wg ON wg.WasherGroupId = ms.GroupId AND wg.EcolabAccountNumber = ms.EcoalabAccountNumber
        WHERE wg.WasherGroupId = ISNULL(@WasherGroupId, wg.WasherGroupId)
        AND (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
        AND M.RegionId = @RegionId
        AND M.Is_Deleted =0
        END
     END
    ELSE
    BEGIN
        SELECT @ControllerModelId = cc.ControllerModelId, @ControllerTypeId = cc.ControllerTypeId FROM TCD.ConduitController cc WHERE cc.ControllerId = @ControllerId

        IF @ControllerModelId = 11
        BEGIN
            SELECT DISTINCT
            Map.ProductId, 
			RTRIM(ISNULL(NULLIF(M.EnvisionDisplayName, ' '), M.Name)) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name
            , M.Cost
            , M.IncludeinCI
            , CAST (ces.ControllerEquipmentTypeId AS int) AS ControllerEquipmentTypeId
            FROM ProductMaster M
            INNER JOIN ProductdataMapping Map ON M.ProductId = Map.ProductId AND Map.Is_Deleted=0  
            INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.EcoLabAccountNumber = Map.EcolabAccountNumber AND ces.ProductId = Map.ProductID
            LEFT JOIN TCD.TunnelCompartmentEquipmentValveMapping tcevm ON ces.ControllerEquipmentSetupID = tcevm.ControllerEquipmentSetupID AND tcevm.DirectDosingFlag = 1
            WHERE 
            (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
            AND tcevm.ControllerEquipmentSetupID IS NULL
            AND M.RegionId = @RegionId
            AND M.Is_Deleted =0
            AND ces.ControllerId = @ControllerId
            AND ces.WasherGroupNumber =  CASE WHEN @ControllerTypeId = 13 THEN 1 ELSE ces.WasherGroupNumber END
    END
        ELSE
        BEGIN
            SELECT DISTINCT
            Map.ProductId, 
			RTRIM(ISNULL(NULLIF(M.EnvisionDisplayName, ' '), M.Name)) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name
    , M.Cost
    , M.IncludeinCI
    , TCD.FnChemicalCostInOunce(Map.ProductId) AS        Price
            , CAST (ces.ControllerEquipmentTypeId AS int) AS ControllerEquipmentTypeId
    FROM ProductMaster M
    INNER JOIN ProductdataMapping Map ON M.ProductId = Map.ProductId AND Map.Is_Deleted=0     
            INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.EcoLabAccountNumber = Map.EcolabAccountNumber AND ces.ProductId = Map.ProductID 
		  AND CASE WHEN @ControllerModelId = 7 THEN ces.ConventionalWasherGroupConnection ELSE ISNULL(ces.ConventionalWasherGroupConnection, 0) END = CASE WHEN @ControllerModelId = 7 THEN 1 ELSE 0 END
            LEFT JOIN TCD.TunnelCompartmentEquipmentValveMapping tcevm ON ces.ControllerEquipmentSetupID = tcevm.ControllerEquipmentSetupID AND tcevm.DirectDosingFlag = 1
    WHERE 
    (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
            AND tcevm.ControllerEquipmentSetupID IS NULL
    AND M.RegionId = @RegionId
    AND M.Is_Deleted =0
            AND ces.ControllerId = @ControllerId
        END
    END
        

    SET NOCOUNT OFF 
 
END
GO
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetPlantMeterDetailsByMeterId]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetPlantMeterDetailsByMeterId
	END
GO
CREATE PROCEDURE [TCD].[GetPlantMeterDetailsByMeterId] 
	-- Add the parameters for the stored procedure here
				 @MeterId INT = NULL
				,@EcolabAccountNumber NVARCHAR(25)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

SELECT		M.MeterId				AS		MeterId
		,	M.[Description]			AS		[Description]
		,	M.UtilityType			AS		MeterType
		,	M.GroupId				AS		GroupId
		,	M.EcolabAccountNumber	AS		EcolabAccountNumber
		,	M.MaxValueLimit			AS		MaxValueLimit
		,	M.MeterTickUnit			AS		MeterTickUnit
		,	M.UsageFactor			AS		UsageFactor
		,	M.ControllerID			AS		ControllerId
		,	M.Parent				AS		ParentId
		,	M.Calibration			AS		Calibration
		,	M.DigitalInputNumber	AS		DigitalInputNumber
		,	M.AllowManualentry		AS		AllowManualEntry
		,	M.Is_deleted			AS		IsDeleted
		,	M.MachineCompartment	AS		MachineId
		,	M.Id					AS		Id
		,	M.LastModifiedByUserId	AS		LastModifiedByUserId
		,	M.LastSyncTime			AS		LastSyncTime
		,	M.IsPlant				AS		IsPlant
		,	M.IsPress				AS		IsPress
		,	M.LastModifiedTime		AS		LastModifiedTime,
		M.CounterAlarmValue,
		M.WaterType,
		M.WaterTypeFromFormulaSetup,
		M.RunningTimeAlarmValue,
		CAST(ISNULL(csd.Value,0) AS BIT) AS ISWaterEnergyLogSel,
		M.DigitalInputNumber,
		M.CounterUsage,
		M.RunningTimeUsage,
		M.CounterNum
FROM TCD.Meter M 
LEFT JOIN TCD.ControllerSetupData csd 
ON csd.ControllerId = M.ControllerID AND csd.FieldId = 473 AND csd.FieldGroupId = 20 AND csd.EcolabAccountNumber = M.EcolabAccountNumber
WHERE M.MeterId	= ISNULL(@MeterId, M.MeterId)
AND M.EcolabAccountNumber = @EcolabAccountNumber

END
GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetBatchEjectConditionData]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetBatchEjectConditionData
	END
GO
CREATE PROCEDURE TCD.[GetBatchEjectConditionData]
(
	@ControllerModelId INT,
	@MachineId INT,
	@Userid INT,	
	@EcolabAccNo NVARCHAR(25)
)
AS
BEGIN
	
	DECLARE @PlantId INT;
	SET @PlantId =	(SELECT PlantId 
					FROM TCD.Plant 
					WHERE EcolabAccountNumber = @EcolabAccNo);

	SELECT 
	BEC.BatchEjectConditionId AS BatchEjectConditionId,	
	BEC.ControllerModelId AS [ControllerModelId],
	BEc.Description AS [Description],
	CASE WHEN BECS.BatchEjectConditionId IS NULL THEN CAST (0 AS BIT) ELSE CAST (1 AS BIT) END AS [Active], 	
	BECS.LastModifiedTime
	FROM TCD.BatchEjectCondition BEC
	LEFT JOIN TCD.BatchEjectConditionStatus BECS ON BEC.BatchEjectConditionId = BECS.BatchEjectConditionId AND BECS.MachineId = @MachineId AND PlantId = @PlantId
	WHERE BEC.ControllerModelId = @ControllerModelId;
END 	
GO
IF EXISTS(SELECT COUNT(1) FROM   TCD.Plant) 
  BEGIN 
	  UPDATE TCD.Plant SET TCD.Plant.ExportPath	= 'C:\Ecolab\enVision\backup' 
  END 

  GO

  IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetFormulasForProductionData]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetFormulasForProductionData
	END
GO
  /*    
 ==========================================================================================    
 Purpose:  Fecthing the Formulas by group id    
  
 Author:  Neetha Allati  
  
 --------------------------------------------------------------    
 Sep-25-2014 ENT: Initial version.    
 ==========================================================================================    
*/   
CREATE PROCEDURE [TCD].[GetFormulasForProductionData]   
(  
        @WasherGroupId NVARCHAR(1000),  
        @EcolabAccountNumber NVARCHAR(25)  
 )  
AS   
  BEGIN  
  SET NOCOUNT ON  
  --DECLARE @IsTunnel bit = (SELECT IsTunnel FROM TCD.MachineSetup WHERE GroupId IN ( SELECT cast(items as int) FROM [TCD].[CharacterListToTable] (@WasherGroupId, ',') ) AND EcoalabAccountNumber = @EcolabAccountNumber )  
  --IF @IsTunnel = 0  
  --BEGIN  
  DECLARE @GroupID INT;

	  SELECT @GroupID = ms.GroupId FROM tcd.Washer AS w
		INNER JOIN tcd.MachineSetup AS MS ON w.WasherId = ms.WasherId 
		WHERE  w.WasherId = @WasherGroupId
 DECLARE @Controllerid INT = (SELECT 
			ControllerId 
		FROM TCD.WasherGroup WHERE 
		WasherGroupId = @WasherGroupId)

        SELECT   
                    DISTINCT P.ProgramId,  
                    P.Name  
        FROM [TCD].WasherProgramSetup AS WP                  
                INNER JOIN [TCD].ProgramMaster AS P ON P.ProgramId = WP.ProgramId  
        WHERE WP.WasherGroupId = @WasherGroupId OR (WP.WasherGroupId IS NULL AND WP.Controllerid = @Controllerid)   
                AND WP.EcolabAccountNumber = @EcolabAccountNumber   
                AND WP.IS_DELETED = 0   
                AND P.IS_DELETED = 0  


				      
    --END  
    --ELSE  
    --BEGIN  
    UNION ALL  
     SELECT   
                    Distinct P.ProgramId,  
                    P.Name  
        FROM [TCD].TunnelProgramSetup  AS tps                  
                INNER JOIN [TCD].ProgramMaster AS P ON P.ProgramId = tps.ProgramId  
        WHERE tps.WasherGroupId = @GroupID                
                AND tps.EcolabAccountNumber = @EcolabAccountNumber   
                AND tps.IS_DELETED = 0   
                AND P.IS_DELETED = 0    
    --END                 
SET NOCOUNT OFF  
END
GO
---------------------------------------------
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetWasherProductDeviationData]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetWasherProductDeviationData
	END
GO
CREATE PROCEDURE [TCD].[GetWasherProductDeviationData](
	 @WasherId INT
	,@controllerId INT
    , @EcolabAccountNumber NVARCHAR(25))
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE
	    @plantId INT = (SELECT P.PlantId
					  FROM TCD.Plant P
					  WHERE P.EcolabAccountNumber = @EcolabAccountNumber);

	DECLARE @WasherProductDeviationCount INT = (Select COUNT(WasherProductDeviationID) from TCD.WasherProductDeviations where ControllerId = @controllerId AND WasherId = @WasherId)
	DECLARE @ControllerEquipmentSetupCount INT = (Select COUNT(ControllerEquipmentSetupId) from TCD.ControllerEquipmentSetup where ControllerId = @controllerId)

IF(@WasherProductDeviationCount = 0)
	BEGIN
		SELECT	WPD.WasherProductDeviationID,
				CES.ControllerEquipmentId,
				PM.Name,
				CASE CES.ConventionalWasherGroupConnection 
						WHEN 0 THEN 0
						WHEN 1 THEN CAST(ISNULL(wpd.ProductDeviation,100) AS int)
						END ProductDeviation,
				ISNULL(CES.ConventionalWasherGroupConnection,0)
				,PM.EnvisionDisplayName
		FROM
						TCD.ControllerEquipmentSetup CES 
			LEFT JOIN	TCD.WasherProductDeviations WPD	ON	WPD.ControllerId = CES.ControllerId
														AND WPD.ControllerEquipmentID = CES.ControllerEquipmentId
														AND wpd.WasherId = @WasherId
			LEFT JOIN	TCD.ProductMaster PM				ON	PM.ProductId = CES.ProductId
		WHERE CES.ControllerId = @controllerId

		ORDER BY WPD.ControllerEquipmentId

	END
ELSE
	BEGIN
		   SELECT 
					WPD.WasherProductDeviationID,
					WPD.ControllerEquipmentId,
					PM.Name,
					CASE CES.ConventionalWasherGroupConnection 
						WHEN 0 THEN 0
						WHEN 1 THEN CAST(ISNULL(wpd.ProductDeviation,100) AS int)
						END ProductDeviation,
					ISNULL(CES.ConventionalWasherGroupConnection,0),
					PM.EnvisionDisplayName
			FROM 
							TCD.WasherProductDeviations WPD
				INNER JOIN	TCD.ControllerEquipmentSetup CES	ON	WPD.ControllerId = CES.ControllerId
																AND WPD.ControllerEquipmentID = CES.ControllerEquipmentId 
																AND wpd.WasherId = @WasherId
				LEFT JOIN	TCD.ProductMaster PM				ON	PM.ProductId = CES.ProductId

		WHERE WPD.ControllerId = @controllerId AND PlantId = @plantId AND wpd.WasherId = @WasherId

		ORDER BY WPD.ControllerEquipmentId
	END
   SET NOCOUNT OFF;
END;
GO

IF EXISTS(SELECT * FROM TCD.ControllerEquipmentTypeModel WHERE ControllerEquipmentTypeModelID = 17 AND ControllerEquipmentTypeModelName = 'Washomix')
BEGIN
DELETE FROM tcd.ControllerEquipmentTypeModel WHERE ControllerEquipmentTypeModelID = 17 AND ControllerEquipmentTypeModelName = 'Washomix'
END
GO


IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[SaveSubstituteChemical]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.SaveSubstituteChemical
	END
GO

CREATE PROCEDURE [TCD].[SaveSubstituteChemical]
	@OldProductId            INT                =            NULL
,    @NewProductId            INT                =            NULL
,    @ScalarOption            INT                =            0
,    @ScalarAmountPercent    INT                =            NULL
,    @WasherGroupId            NVARCHAR(1000)    =            NULL
,    @EcolabAccountNumber    NVARCHAR(25)    =            NULL
AS
BEGIN
    DECLARE   
        @ReturnValue        INT                =   0  
     ,    @ErrorId            INT                =   0  
	 ,	@LfsChemicalName	NVARCHAR(4000)		=	NULL
	 ,	@CurrentUTC			DATETIME			=	GETUTCDATE()
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

	SELECT @LfsChemicalName = pm.Name FROM TCD.ProductMaster pm WHERE pm.ProductId = @NewProductId
    -- Update Pump/Product Mapping in ControllerEquipmentSetup table
    UPDATE ces
    SET
        ces.ProductId = @NewProductId
	,	ces.LastModifiedTime = @CurrentUTC
	,	ces.LfsChemicalName = @LfsChemicalName
    FROM TCD.WasherGroup wg
    INNER JOIN TCD.MachineSetup ms 
    ON ms.GroupId = wg.WasherGroupId AND ms.IsDeleted = 'False'
    AND ms.EcoalabAccountNumber = wg.EcolabAccountNumber
    INNER JOIN TCD.ConduitController cc 
    ON cc.ControllerId = ms.ControllerId
    AND cc.EcoalabAccountNumber = ms.EcoalabAccountNumber
    INNER JOIN TCD.ControllerEquipmentSetup ces 
    ON ces.EcoLabAccountNumber = cc.EcoalabAccountNumber 
    AND ces.ControllerId = cc.ControllerId
    WHERE ((@WasherGroupId != '-1' AND @WasherGroupId != '' AND  wg.WasherGroupId IN (SELECT cast(items AS INT) FROM [TCD].[CharacterListToTable] (@WasherGroupId, ','))) OR (@WasherGroupId = '-1' OR @WasherGroupId = ''))
    AND ces.ProductId = @OldProductId AND ces.EcoLabAccountNumber = @EcolabAccountNumber

    SET @ErrorId = @@ERROR  
   
    IF (@ErrorId <> 0)  
     BEGIN  
       IF @@TRANCOUNT > 0  
       BEGIN  
        ROLLBACK TRAN  
       END  
       RAISERROR (@ErrorId, 16, 1)  
       SET  @ReturnValue = -1  
       RETURN (@ReturnValue)  
     END 
    -- Update Formula\Product Mapping in WasherDosingProductMapping
    UPDATE wdpm
    SET 
        wdpm.ProductId    =    @NewProductId
    ,    wdpm.Quantity    =    CASE WHEN @ScalarOption = 1 
                            THEN CASE WHEN (wdpm.Quantity - ((wdpm.Quantity * @ScalarAmountPercent)/100)) < 0 
                                 THEN 0
                                 ELSE  (wdpm.Quantity - ((wdpm.Quantity * @ScalarAmountPercent)/100))
                                 END
                            WHEN @ScalarOption = 2 
                            THEN (wdpm.Quantity + ((wdpm.Quantity * @ScalarAmountPercent)/100)) 
                            ELSE wdpm.Quantity 
                            END
	,	wdpm.LastModifiedTime = @CurrentUTC
    FROM TCD.WasherDosingProductMapping wdpm
    INNER JOIN TCD.WasherDosingSetup wds 
    ON wds.WasherDosingSetupId = wdpm.WasherDosingSetupId
    AND wds.EcoLabAccountNumber = wdpm.EcoLabAccountNumber
    INNER JOIN TCD.WasherProgramSetup wps 
    ON wps.WasherProgramSetupId = wds.WasherProgramSetupId
    AND wps.EcolabAccountNumber = wds.EcoLabAccountNumber
    INNER JOIN TCD.WasherGroup wg 
    ON wg.WasherGroupId = wps.WasherGroupId
    AND wps.EcolabAccountNumber = wg.EcoLabAccountNumber
    WHERE ((@WasherGroupId != '-1' AND @WasherGroupId != '' AND  wg.WasherGroupId IN (SELECT cast(items AS INT) FROM [TCD].[CharacterListToTable] (@WasherGroupId, ','))) OR (@WasherGroupId = '-1' OR @WasherGroupId = ''))
    AND wdpm.ProductId = @OldProductId
    AND wdpm.EcoLabAccountNumber = @EcolabAccountNumber

    SET @ErrorId = @@ERROR  
   
    IF (@ErrorId <> 0)  
     BEGIN  
       IF @@TRANCOUNT > 0  
       BEGIN  
        ROLLBACK TRAN  
       END  
       RAISERROR (@ErrorId, 16, 1)  
       SET  @ReturnValue = -1  
       RETURN (@ReturnValue)  
     END 

         -- Update Formula\Product Mapping in WasherDosingProductMapping With ControllerId
    UPDATE wdpm
    SET 
        wdpm.ProductId    =    @NewProductId
    ,    wdpm.Quantity    =    CASE WHEN @ScalarOption = 1 
                            THEN CASE WHEN (wdpm.Quantity - ((wdpm.Quantity * @ScalarAmountPercent)/100)) < 0 
                                 THEN 0
                                 ELSE  (wdpm.Quantity - ((wdpm.Quantity * @ScalarAmountPercent)/100))
                                 END
                            WHEN @ScalarOption = 2 
                            THEN (wdpm.Quantity + ((wdpm.Quantity * @ScalarAmountPercent)/100)) 
                            ELSE wdpm.Quantity 
                            END
 , wdpm.LastModifiedTime = @CurrentUTC
    FROM TCD.WasherDosingProductMapping wdpm
    INNER JOIN TCD.WasherDosingSetup wds 
    ON wds.WasherDosingSetupId = wdpm.WasherDosingSetupId
    AND wds.EcoLabAccountNumber = wdpm.EcoLabAccountNumber
    INNER JOIN TCD.WasherProgramSetup wps 
    ON wps.WasherProgramSetupId = wds.WasherProgramSetupId
    AND wps.EcolabAccountNumber = wds.EcoLabAccountNumber
    INNER JOIN TCD.WasherGroup wg 
    ON wg.ControllerId = wps.ControllerID
    AND wps.EcolabAccountNumber = wg.EcoLabAccountNumber
    WHERE ((@WasherGroupId != '-1' AND @WasherGroupId != '' AND  wg.WasherGroupId IN (SELECT cast(items AS INT) FROM [TCD].[CharacterListToTable] (@WasherGroupId, ','))) OR (@WasherGroupId = '-1' OR @WasherGroupId = ''))
    AND wdpm.ProductId = @OldProductId
    AND wdpm.EcoLabAccountNumber = @EcolabAccountNumber

    SET @ErrorId = @@ERROR  
   
    IF (@ErrorId <> 0)  
     BEGIN  
       IF @@TRANCOUNT > 0  
       BEGIN  
        ROLLBACK TRAN  
       END  
       RAISERROR (@ErrorId, 16, 1)  
       SET  @ReturnValue = -1  
       RETURN (@ReturnValue)  
     END 

    -- Update Tunnel\Product Mapping
    UPDATE tdpm
    SET 
        tdpm.Quantity    =    CASE WHEN @ScalarOption = 1 
                            THEN CASE WHEN (tdpm.Quantity - ((tdpm.Quantity * @ScalarAmountPercent)/100)) < 0 
                                 THEN 0
                                 ELSE  (tdpm.Quantity - ((tdpm.Quantity * @ScalarAmountPercent)/100))
                                 END
                            WHEN @ScalarOption = 2 
                            THEN (tdpm.Quantity + ((tdpm.Quantity * @ScalarAmountPercent)/100)) 
                            ELSE tdpm.Quantity 
                            END
	,	tdpm.LastModifiedTime = @CurrentUTC
    FROM TCD.TunnelDosingProductMapping tdpm
    INNER JOIN TCD.TunnelDosingSetup tds
    ON tds.TunnelDosingSetupId = tdpm.TunnelDosingSetupId
    AND tds.CompartmentNumber = tdpm.CompartmentNumber
    AND tds.EcolabAccountNumber = tdpm.EcolabAccountNumber
    AND tds.GroupId = tdpm.GroupId
    INNER JOIN TCD.TunnelProgramSetup tps 
    ON tps.TunnelProgramSetupId = tds.TunnelProgramSetupId
    AND tps.EcolabAccountNumber = tds.EcolabAccountNumber
    AND tps.WasherGroupId = tds.GroupId
    INNER JOIN TCD.WasherGroup wg
    ON wg.EcolabAccountNumber = tps.EcolabAccountNumber
    AND wg.WasherGroupId = tps.WasherGroupId
    INNER JOIN TCD.MachineSetup ms
    ON ms.GroupId = wg.WasherGroupId
    AND ms.EcoalabAccountNumber = wg.EcolabAccountNumber
    INNER JOIN TCD.TunnelCompartment tc
    ON tc.EcoLabAccountNumber = tdpm.EcoLabAccountNumber
    AND tc.WasherId = ms.WasherId
    AND tc.EcoLabAccountNumber = ms.EcoalabAccountNumber
    INNER JOIN TCD.ConduitController cc 
    ON cc.ControllerId = ms.ControllerId
    AND cc.EcoalabAccountNumber = ms.EcoalabAccountNumber
    INNER JOIN TCD.ControllerEquipmentSetup ces 
    ON ces.EcoLabAccountNumber = cc.EcoalabAccountNumber 
    AND ces.ControllerId = cc.ControllerId
    WHERE ((@WasherGroupId != '-1' AND @WasherGroupId != '' AND  wg.WasherGroupId IN (SELECT cast(items AS INT) FROM [TCD].[CharacterListToTable] (@WasherGroupId, ','))) OR (@WasherGroupId = '-1' OR @WasherGroupId = ''))
    AND ces.ProductId = @NewProductId
    AND wg.EcolabAccountNumber = @EcolabAccountNumber

    SET @ErrorId = @@ERROR  
   
    IF (@ErrorId <> 0)  
     BEGIN  
           IF @@TRANCOUNT > 0  
           BEGIN  
            ROLLBACK TRAN  
           END  
           RAISERROR (@ErrorId, 16, 1)  
           SET  @ReturnValue = -1  
           RETURN (@ReturnValue)  
     END
    ELSE
    BEGIN
        IF @@TRANCOUNT > 0  
        BEGIN  
            COMMIT  
        END
        RETURN (@ReturnValue)  
    END

END
GO

------------TCD.WasherProductDeviations changes START------------
--Script to make the column ControllerId from smallint to int
IF EXISTS(SELECT
					*
				FROM sys.columns
				WHERE object_id = OBJECT_ID(N'TCD.WasherProductDeviations')
					AND name = 'ControllerId')
	BEGIN

		ALTER TABLE TCD.WasherProductDeviations ALTER COLUMN ControllerId INT NOT NULL;
	END;
GO
------------TCD.WasherProductDeviations changes END------------
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetCompartmentDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetCompartmentDetails
	END
GO
CREATE PROCEDURE [TCD].[GetCompartmentDetails] @EcoLabAccountNumber NVARCHAR(25)
 ,@WasherGroupId INT
 ,@TunnelId INT
 ,@CompartmentNumber TINYINT = 1
 ,@IsDelete BIT = 'False'
AS
BEGIN
 SET NOCOUNT ON

 DECLARE @RegionId INT,
 @PlantId int ,
 @ControllerModelId int

 SELECT @RegionId = RegionId, @PlantId = PlantId
   FROM TCD.Plant
   WHERE EcolabAccountNumber = @EcoLabAccountNumber
    AND Is_Deleted = 0

 DECLARE @ReturnValue INT = 0
  ,@ErrorId INT = 0
  ,@ErrorMessage NVARCHAR(4000) = N''
  ,@ControllerId INT = NULL
  ,@NumberOfComp TINYINT = NULL
  ,@DosagePoint BIT = NULL

 SET @WasherGroupId = ISNULL(@WasherGroupId, NULL) --SQLEnlight SA0029

 --Get ControllerId, Number
 SELECT @ControllerId = ISNULL(MS.ControllerId, - 1)
  ,@NumberOfComp = ISNULL(MS.NumberOfComp, - 1)
 FROM [TCD].MachineSetup MS
 INNER JOIN [TCD].ConduitController CC ON MS.ControllerId = CC.ControllerId
  AND MS.EcoalabAccountNumber = CC.EcoalabAccountNumber
 WHERE MS.EcoalabAccountNumber = @EcoLabAccountNumber
  AND MS.WasherId = @TunnelId
  AND MS.IsTunnel = 'TRUE'
  AND MS.IsDeleted = 'FALSE'
  AND CC.IsDeleted = 'FALSE'

  SELECT @ControllerModelId = cc.ControllerModelId from tcd.ConduitController cc WHERE cc.ControllerId = @ControllerId

 --if we didn't get a valid Controller, error-out
 IF (@ControllerId = - 1)
 BEGIN
  SET @ErrorId = 51020
  SET @ErrorMessage = N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Could not determine the Controller for the specified tunnel.'

  RAISERROR (
    @ErrorMessage
    ,16
    ,1
    )

  SET @ReturnValue = - 1

  RETURN (@ReturnValue)
 END

 --CompartmentNumber
 IF (@CompartmentNumber > @NumberOfComp)
 BEGIN
  SET @ErrorId = 51021
  SET @ErrorMessage = N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Invalid Compartment Number specified for the tunnel.'

  RAISERROR (
    @ErrorMessage
    ,16
    ,1
    )

  SET @ReturnValue = - 1

  RETURN (@ReturnValue)
 END

 --Select the details of the compartment...
 ;WITH CTE_ComptNumbersForTunnel
AS (
    SELECT MS.GroupId, 'ALL' AS CompartmentNumber, MS.NumberOfComp
    FROM TCD.MachineSetup AS MS
    WHERE MS.IsTunnel = 1 AND MS.IsDeleted = 0
)

, CTE_ComptNumbersforEachWasherGroup 
AS (
    SELECT  C.GroupId
            , TunnelCompNumber = 1
            , CompartmentNumber
    , NumberOfComp
    FROM    CTE_ComptNumbersForTunnel C
    UNION ALL 
    SELECT  GroupId
            , TunnelCompNumber = TunnelCompNumber + 1
            , CompartmentNumber
    , NumberOfComp
    FROM    CTE_ComptNumbersforEachWasherGroup
    WHERE   NumberOfComp > TunnelCompNumber
)
, CTE_SensorsForEachCompartment 
AS (
    SELECT CASE 
        WHEN S.MachineCompartment IS NULL AND ISNULL(S.IsPress,0) = 0  
        THEN 'ALL'
        WHEN 
		--( SELECT DISTINCT Istunnel
      -- FROM [TCD].machinesetup M
      -- WHERE M.groupId = S.GroupId ) = 1 
       --AND 
	   S.MachineCompartment IS NOT NULL 
       --AND ISNULL(S.IsPress,0) = 0 
        THEN CAST(S.Machinecompartment AS VARCHAR)
    END AS CompartmentNumber
    , CASE WHEN STM.Name = 'Temperature' THEN '1' ELSE '0' END AS Temperature
    , CASE WHEN STM.Name = 'pH' THEN '1' ELSE '0' END AS pH
    , CASE WHEN STM.Name = 'Conductivity' THEN '1' ELSE '0' END AS Conductivity
    , CASE WHEN STM.Name = 'Redox' THEN '1' ELSE '0' END AS Redox
    , S.GroupId
    , S.ControllerID
    FROM TCD.Sensor AS S 
    LEFT JOIN TCD.SensorTypeMaster AS STM ON S.SensorType = STM.ResourceId
 WHERE S.Is_Deleted = 0
    )
, CTE_TunnelSensors
AS (
    SELECT  Sensors.GroupId
    , Sensors.ControllerID
    , TunnelCompNumberForWG.TunnelCompNumber AS CompartmentNumber
    , MAX(Sensors.pH) AS pH
    , MAX(Sensors.Temperature) AS Temperature
    , MAX(Sensors.Conductivity) AS Conductivity
    , MAX(Sensors.Redox) AS Redox
    FROM CTE_SensorsForEachCompartment AS Sensors
    LEFT JOIN CTE_ComptNumbersforEachWasherGroup AS TunnelCompNumberForWG
    ON Sensors.GroupId = TunnelCompNumberForWG.GroupId 
    AND Sensors.CompartmentNumber = CASE WHEN Sensors.CompartmentNumber = 'ALL' 
            THEN TunnelCompNumberForWG.CompartmentNumber
         WHEN Sensors.CompartmentNumber <> 'ALL' 
            THEN CAST(TunnelCompNumberForWG.TunnelCompNumber AS VARCHAR)
        END
 GROUP BY Sensors.GroupId, Sensors.ControllerID, TunnelCompNumberForWG.TunnelCompNumber
 )
 SELECT TC.WashStepId AS WashStepId
  ,TC.WaterInletDrainId AS WaterInletDrainId
  ,TC.WaterFlowId AS WaterFlowId
  ,TC.WaterLevel AS WaterLevel
  ,TC.TemperatureControlByPMR AS TemperatureControlByPMR
  ,TC.UsePressExtractWater AS UsePressExtractWater
  ,TC.SplitCompartment AS SplitCompartment
  ,TC.RecycledWaterInlet AS RecycledWaterInlet
  ,TC.Steam AS Steam
  ,@CompartmentNumber AS CompartmentNumber
  ,TC.IterationPoint AS IterationPoint
  --Adding cols. for integration with Synch./Central
  ,TC.LastModifiedTime AS LastModifiedTime
  ,TC.LastSyncTime AS LastSyncTime
  ,TC.TunnelCompartmentId AS TunnelCompartmentId
  ,TC.WasherId AS WasherId
  ,TC.EcoLabAccountNumber AS EcoLabAccountNumber
  ,W.MyServiceCustMchGuid AS MyServiceWasherId
  ,TWIDL.MyServicePropId AS MyServiceDrainLookupId
  ,TWFT.MyServicePropId AS MyServiceWaterFlowTypeId
  ,CAST(ISNULL(CTE.Temperature, 0) as bit) AS Temperature
  ,CAST(ISNULL(CTE.pH, 0) as bit) AS PhProbe
  ,CAST(ISNULL(CTE.Conductivity, 0) as bit) AS Conductivity
  ,CAST(ISNULL(CTE.Redox, 0) as bit) AS Redox
 FROM [TCD].Washer W
 INNER JOIN [TCD].MachineSetup MS ON W.WasherId = MS.WasherId
  AND W.EcoLabAccountNumber = MS.EcoalabAccountNumber
 INNER JOIN [TCD].TunnelCompartment TC ON W.WasherId = TC.WasherId
  AND W.EcoLabAccountNumber = TC.EcoLabAccountNumber
 INNER JOIN [TCD].TunnelWaterInletDrainLookup TWIDL ON TC.WaterInletDrainId = TWIDL.TunnelWaterInletDrainLookupId
 INNER JOIN [TCD].TunnelWaterFlowType TWFT ON TC.WaterFlowId = TWFT.TunnelWaterFlowTypeId
 LEFT JOIN CTE_TunnelSensors CTE ON CTE.GroupId = MS.GroupId AND CTE.CompartmentNumber = @CompartmentNumber
 WHERE W.EcoLabAccountNumber = @EcoLabAccountNumber
  AND W.WasherId = @TunnelId
  AND MS.IsTunnel = 'TRUE'
  AND (
   W.Is_Deleted = 'FALSE'
   OR W.Is_Deleted = @IsDelete
   )
  AND (
   MS.IsDeleted = 'FALSE'
   OR MS.IsDeleted = @IsDelete
   )
  AND TC.CompartmentNumber = @CompartmentNumber
  
 --select the equipment association...
 IF (@RegionId = 1)
 BEGIN
 IF(@ControllerModelId = 7)
 BEGIN

  SELECT TCEM.ControllerEquipmentSetupId				    AS		 ControllerEquipmentSetupId
	   ,CES.ControllerEquipmentId						    AS		 ControllerEquipmentId
	   ,CES.ControllerEquipmentTypeId				 	    AS		 ControllerEquipmentTypeId
	   ,ISNULL(NULLIF(PM2.EnvisionDisplayName,''), PM2.NAME)	    AS		 ProductName
	   ,TCEM.MyServiceCmpmtDsgDvcguid					    AS		 MyServiceCmpmtDsgDvcguid
	   ,TCEM.Is_Deleted								    AS		 IsDelete
	   ,0										    AS		 FormulaAssociated 
	   FROM TCD.TunnelCompartmentEquipmentValveMapping tcevm
	   INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.ControllerEquipmentSetupId = tcevm.ControllerEquipmentSetupId 
	   AND tcevm.PlantID = @PlantId
	   INNER JOIN TCD.TunnelCompartment tc ON  tc.CompartmentNumber = tcevm.CompartmentNumber AND tc.EcoLabAccountNumber = ces.EcoLabAccountNumber
	   LEFT JOIN TCD.TunnelCompartmentEquipmentMapping tcem ON tcevm.ControllerEquipmentSetupID = tcem.ControllerEquipmentSetupId
	   AND tc.TunnelCompartmentId = tcem.TunnelCompartmentId AND (TCEM.Is_Deleted = 'FALSE' OR TCEM.Is_Deleted = @IsDelete)
	   AND tcem.EcoLabAccountNumber = tc.EcoLabAccountNumber AND tcem.EcoLabAccountNumber = ces.EcoLabAccountNumber
	   INNER JOIN TCD.MachineSetup ms ON ms.WasherId = tc.WasherId AND ms.ControllerId = ces.ControllerId AND ms.EcoalabAccountNumber = tc.EcoLabAccountNumber
	   AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber
	   INNER JOIN TCD.ProductdataMapping pm ON pm.EcolabAccountNumber = ces.EcoLabAccountNumber AND pm.ProductID = ces.ProductId 
	   INNER JOIN TCD.ProductMaster pm2 ON pm2.ProductId = pm.ProductID
	   WHERE ms.WasherId = @TunnelId AND tc.CompartmentNumber = @CompartmentNumber AND ms.EcoalabAccountNumber = @EcoLabAccountNumber
	   AND MS.IsTunnel = 'TRUE' AND (MS.IsDeleted = 'FALSE' OR MS.IsDeleted = @IsDelete)
	   AND (PM.Is_Deleted = 'FALSE' OR PM.Is_Deleted = @IsDelete)
END
 ELSE
 BEGIN
 SELECT TCEM.ControllerEquipmentSetupId AS ControllerEquipmentSetupId
   ,CES.ControllerEquipmentId AS ControllerEquipmentId
   ,CES.ControllerEquipmentTypeId AS ControllerEquipmentTypeId
   ,ISNULL(NULLIF(PM.EnvisionDisplayName,''), PM.NAME) AS ProductName
   ,TCEM.MyServiceCmpmtDsgDvcguid AS MyServiceCmpmtDsgDvcguid
   ,TCEM.Is_Deleted AS IsDelete
   ,(
    SELECT Count(*)
    FROM [TCD].TunnelDosingSetup tds
    INNER JOIN [TCD].TunnelDosingProductMapping TDPM ON TDPM.GroupId = TDS.GroupId
    INNER JOIN [TCD].TunnelProgramSetup tps ON tps.TunnelProgramSetupId = tds.TunnelProgramSetupId
     AND tps.Is_Deleted = 'false'
    WHERE TDPM.ControllerEquipmentSetupId = TCEM.ControllerEquipmentSetupId
     AND TDPM.CompartmentNumber = TDS.CompartmentNumber
     AND TDPM.GroupId = MS.GroupId
    ) AS FormulaAssociated
  FROM [TCD].Washer W
  INNER JOIN [TCD].MachineSetup MS ON W.WasherId = MS.WasherId
   AND W.EcoLabAccountNumber = MS.EcoalabAccountNumber
  INNER JOIN [TCD].TunnelCompartment TC ON W.WasherId = TC.WasherId
   AND W.EcoLabAccountNumber = TC.EcoLabAccountNumber
  INNER JOIN [TCD].TunnelCompartmentEquipmentMapping TCEM ON TC.TunnelCompartmentId = TCEM.TunnelCompartmentId
   AND TC.EcoLabAccountNumber = TCEM.EcoLabAccountNumber
  INNER JOIN [TCD].ControllerEquipmentSetup CES ON TCEM.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId
   AND TCEM.EcoLabAccountNumber = CES.EcoLabAccountNumber
   AND CES.ControllerId = MS.ControllerId
  INNER JOIN [TCD].ProductMaster PM ON CES.ProductId = PM.ProductId
  WHERE W.EcoLabAccountNumber = @EcoLabAccountNumber
   AND W.WasherId = @TunnelId
   AND MS.IsTunnel = 'TRUE'
   AND (
    W.Is_Deleted = 'FALSE'
    OR W.Is_Deleted = @IsDelete
    )
   AND (
    MS.IsDeleted = 'FALSE'
    OR MS.IsDeleted = @IsDelete
    )
   AND TC.CompartmentNumber = @CompartmentNumber
   AND (
    TCEM.Is_Deleted = 'FALSE'
    OR TCEM.Is_Deleted = @IsDelete
    )
   AND (
    PM.Is_Deleted = 'FALSE'
    OR PM.Is_Deleted = @IsDelete
    )
 END

  
 END
 ELSE IF (@RegionId = 2)
 BEGIN
   SELECT TCEM.ControllerEquipmentSetupId				    AS		 ControllerEquipmentSetupId
	   ,CES.ControllerEquipmentId						    AS		 ControllerEquipmentId
	   ,CES.ControllerEquipmentTypeId				 	    AS		 ControllerEquipmentTypeId
	   ,ISNULL(NULLIF(PM2.EnvisionDisplayName,''), PM2.NAME)	    AS		 ProductName
	   ,TCEM.MyServiceCmpmtDsgDvcguid					    AS		 MyServiceCmpmtDsgDvcguid
	   ,TCEM.Is_Deleted								    AS		 IsDelete
	   ,0										    AS		 FormulaAssociated 
	   FROM TCD.TunnelCompartmentEquipmentValveMapping tcevm
	   INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.ControllerEquipmentSetupId = tcevm.ControllerEquipmentSetupId 
	   AND tcevm.PlantID = @PlantId
	   INNER JOIN TCD.TunnelCompartment tc ON  tc.CompartmentNumber = tcevm.CompartmentNumber AND tc.EcoLabAccountNumber = ces.EcoLabAccountNumber
	   LEFT JOIN TCD.TunnelCompartmentEquipmentMapping tcem ON tcevm.ControllerEquipmentSetupID = tcem.ControllerEquipmentSetupId
	   AND tc.TunnelCompartmentId = tcem.TunnelCompartmentId AND (TCEM.Is_Deleted = 'FALSE' OR TCEM.Is_Deleted = @IsDelete)
	   AND tcem.EcoLabAccountNumber = tc.EcoLabAccountNumber AND tcem.EcoLabAccountNumber = ces.EcoLabAccountNumber
	   INNER JOIN TCD.MachineSetup ms ON ms.WasherId = tc.WasherId AND ms.ControllerId = ces.ControllerId AND ms.EcoalabAccountNumber = tc.EcoLabAccountNumber
	   AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber
	   INNER JOIN TCD.ProductdataMapping pm ON pm.EcolabAccountNumber = ces.EcoLabAccountNumber AND pm.ProductID = ces.ProductId 
	   INNER JOIN TCD.ProductMaster pm2 ON pm2.ProductId = pm.ProductID
	   WHERE ms.WasherId = @TunnelId AND tc.CompartmentNumber = @CompartmentNumber AND ms.EcoalabAccountNumber = @EcoLabAccountNumber
	   AND MS.IsTunnel = 'TRUE' AND (MS.IsDeleted = 'FALSE' OR MS.IsDeleted = @IsDelete)
	   AND (PM.Is_Deleted = 'FALSE' OR PM.Is_Deleted = @IsDelete)
 END

 SET NOCOUNT OFF
END
GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[UpdateTunnel]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.UpdateTunnel
	END
GO
CREATE	PROCEDURE    [TCD].[UpdateTunnel]
                    @EcoLabAccountNumber                    NVARCHAR(25)
                ,    @WasherId                                INT
                ,    @WasherGroupId                            INT                                    --Not updated, for reference only
                ,    @TunnelName                            NVARCHAR(50)
                ,    @WasherModelName                        NVARCHAR(50)
                ,    @RegionId                                SMALLINT
                --,    @Size                                INT
                ,    @ControllerId                            INT
                ,    @LFSWasherNumber                        INT            =            1        --For tunnels, it will be 1 until a diff. number is passed (as per the scenario)
                ,    @PlantWasherNumber                        SMALLINT
                ,    @WasherMode                            SMALLINT
                ,    @MaxLoad                                SMALLINT
                ,    @AWEActive                            BIT
                ,    @NumberOfTanks                            TINYINT
                ,    @NumberOfComp                            INT                                --though this is INT in the table, we should not require it to be so
                ,    @TransferType                            TINYINT
                ,    @PressExtractor                        TINYINT
                ,    @ProgramNumber                            TINYINT
                ,    @EndOfFormula                            TINYINT
                ,    @Description                            NVARCHAR(1024)    =            NULL
                ,    @UserId                                INT
				--Adding these 3 params as part of re-factoring for integration with Synch/Configurator
                ,    @OutputTunnelId                        INT            =            NULL    OUTPUT
                ,    @LastModifiedTimestampAtCentral            DATETIME    =            NULL            --Nullable for local call; Synch/Central call will have to pass this -
																									--else, it will be treated as a local call
                ,    @OutputLastModifiedTimestampAtLocal        DATETIME    =            NULL    OUTPUT
                ,   @RatioDosingActive                        BIT
                ,   @ControllerModelId                        INT        =        NULL
                ,   @NumberOfCompartmentsConveyorBelt            TINYINT    =        NULL
                ,   @MaxMachineLoad                            SMALLINT    =        NULL
                ,   @MinMachineLoad                            SMALLINT    =        NULL
                ,   @ProgramSelectionByTime                    BIT          =        NULL
                ,   @WeightSelectionByTime                    BIT          =        NULL
                ,   @WeightSelectionByAnalogInput                BIT          =        NULL
                ,   @TunInTomMode                            BIT          =        NULL
                ,   @SignalStopTunActive                        BIT          =        NULL
                ,   @SignalEjectionTunActive                      BIT          =        NULL
                ,   @DelayTimeForTunWashingPrograms            BIT          =        NULL
                ,   @KannegiesserPressSpecialMode                BIT          =        NULL
                ,   @ValveOutputsUsedAsTomSignal                BIT          =        NULL
                ,   @ExtendedClockOrDataProtocol                BIT          =        NULL
                ,   @WeightCorrectionFcc                        BIT          =        NULL
				,	@DateAndTimeWhenBatchEjects					BIT	  		=		NULL
				,	@AutoRinseDesamixAfter						SMALLINT	=		NULL
				,	@AutoRinseDesamix1For						SMALLINT	=		NULL
				,	@AutoRinseDesamix2For						SMALLINT	=		NULL
				,	@TemperatureAlarmProbe1						BIT			=		NULL
				,	@TemperatureAlarmProbe2						BIT			=		NULL
				,	@TemperatureAlarmProbe3						BIT			=		NULL
				,	@UseMe1OfGroup							tinyint					=	NULL
				,	@UseMe2OfGroup							tinyint					=	NULL
				,	@ETechWasherNumber						int					=	NULL
				,	@KannegiesserDosageInPreparationTankMode	bit			=		NULL
				,	@BatchOk									bit			=		NULL
AS
BEGIN

SET    NOCOUNT    ON


DECLARE	
        @ReturnValue                    INT                =            0
    ,    @ErrorId                        INT                =            0
    ,    @ErrorMessage                    NVARCHAR(4000)    =            N''

    ,    @WasherModelId                    SMALLINT        =            NULL

    ,    @CurrentUTCTime                    DATETIME        =            GETUTCDATE()
	,	@ControllerValidate				int				=										   0

--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
SET        @OutputLastModifiedTimestampAtLocal                =            @CurrentUTCTime
SET        @OutputTunnelId                                    =            ISNULL(@OutputTunnelId, NULL)            --SQLEnlight

--If the call is not local, check that the LastModifiedTime matches with the central
IF    (
        @LastModifiedTimestampAtCentral            IS NOT    NULL
    AND    NOT    EXISTS    (    SELECT    1
                        FROM    TCD.[Washer]            W
                        WHERE    W.EcolabAccountNumber    =    @EcolabAccountNumber
                            AND    W.WasherId                =    @WasherId
                            AND    W.LastModifiedTime        =    @LastModifiedTimestampAtCentral
					)
	)
	BEGIN
            SET            @ErrorId                    =    60000
            SET            @ErrorMessage                =    N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
            RAISERROR    (@ErrorMessage, 16, 1)
            SET            @ReturnValue                =    -1
            RETURN        (@ReturnValue)
	END

--Proceed, since it's either a local call or Synch. call with synch. time matching


--Valid Washer - based on Id...
IF    NOT    EXISTS    (    SELECT    1
                    FROM    [TCD].Washer                W
                    JOIN    [TCD].MachineSetup            MS
                        ON    W.WasherId                    =            MS.WasherId
                        AND    W.EcoLabAccountNumber        =            MS.EcoalabAccountNumber
                    WHERE    W.EcoLabAccountNumber        =            @EcoLabAccountNumber
                        AND    W.WasherId                    =            @WasherId
                        AND    MS.GroupId                    =            @WasherGroupId
                        AND    MS.IsTunnel                    =            'TRUE'
                        AND    W.Is_Deleted                =            'FALSE'
                        AND    MS.IsDeleted                =            'FALSE'
				)
			BEGIN
                SET        @ErrorId                        =            51006
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Washer-ID was provided for Updating.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET    @ReturnValue    =    -1
                RETURN    (@ReturnValue)
			END


--Check for uniqueness of PlantWasherNo. and Name
IF    EXISTS        (    SELECT    1
                    FROM    [TCD].Washer                W
                    JOIN    [TCD].MachineSetup            MS
                        ON    W.WasherId                    =            MS.WasherId
                        AND    W.EcoLabAccountNumber        =            MS.EcoalabAccountNumber
                    WHERE    W.EcoLabAccountNumber        =            @EcoLabAccountNumber
                        AND    W.WasherId                    <>            @WasherId
                        AND    (
                            W.PlantWasherNumber            =            @PlantWasherNumber
                            AND
                            MS.MachineName                =            @TunnelName
							)
                        AND    W.Is_Deleted                =            'FALSE'
                        AND    MS.IsDeleted                =            'FALSE'
				)
			BEGIN
                SET        @ErrorId                        =            51002
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Specified Plant Washer #/Name already exists.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET    @ReturnValue    =    -1
                RETURN    (@ReturnValue)
			END


--Check that it's a valid Controller type/model (one that can control a Tunnel)
IF	NOT	EXISTS	(	SELECT	1
					FROM	[TCD].ControllerModelControllerTypeMapping
														CMCTM
					JOIN	[TCD].ConduitController		CC
						ON	CC.ControllerTypeId			=			CMCTM.ControllerTypeId
						AND	CC.ControllerModelId		=			CMCTM.ControllerModelId
					WHERE	CC.EcoalabAccountNumber		=			@EcoLabAccountNumber
						AND	CC.ControllerId				=			@ControllerId
						AND	CC.IsDeleted				=			'FALSE'
						AND	CMCTM.CanControlTunnel		=			'TRUE'
				)
			BEGIN
				SET		@ErrorId						=			51003
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller was provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END

--IF  (  @ControllerValidate = 1)
--            BEGIN
--                SET        @ErrorId                        =            51003
--                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller was provided.'
--                --GOTO    ErrorHandler
--                RAISERROR    (@ErrorMessage, 16, 1)
--                SET    @ReturnValue    =    -1
--                RETURN    (@ReturnValue)
--            END


--EOF should not be an asocciated formula for the WG...
IF    EXISTS        (    SELECT    1
                    FROM    [TCD].TunnelProgramSetup    TPS
                    WHERE    TPS.EcolabAccountNumber        =            @EcoLabAccountNumber
                        AND    TPS.WasherGroupId            =            @WasherGroupId
                        AND    TPS.ProgramNumber            =            @ProgramNumber
                        AND    TPS.Is_Deleted                =            'FALSE'
				)
			BEGIN
                SET        @ErrorId                        =            51004
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An assoicated formula cannot be specified as End-Of-Formula.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET    @ReturnValue    =    -1
                RETURN    (@ReturnValue)
			END


--WasherMode check
IF    NOT    EXISTS    (    SELECT    1
                    FROM    [TCD].ControllerModelControllerTypeMapping
														CMCTM
                    JOIN    [TCD].ConduitController        CC
                        ON    CC.ControllerTypeId            =            CMCTM.ControllerTypeId
                        AND    CC.ControllerModelId        =            CMCTM.ControllerModelId
                    JOIN    [TCD].[WasherModeMapping]
														CTM2WM
                        ON    CMCTM.Id                    =            CTM2WM.ControllerModelControllerTypeMappingId
                    WHERE    CC.EcoalabAccountNumber        =            @EcoLabAccountNumber
                        AND    CC.ControllerId                =            @ControllerId
                        AND    CC.IsDeleted                =            'FALSE'
                        --AND    CMCTM.CanControlTunnel        =            'TRUE'
                        AND    CTM2WM.WasherModeId            =            @WasherMode
				)
			BEGIN
                SET        @ErrorId                        =            51005
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherMode was provided.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET    @ReturnValue    =    -1
                RETURN    (@ReturnValue)
			END


--select the WasherModelId based on name
SELECT    TOP    1
        @WasherModelId                        =            WMS.WasherModelId
FROM    [TCD].WasherModelSize                WMS
WHERE    WMS.RegionId                        =            @RegionId
    AND    WMS.WasherModelName                    =            @WasherModelName
    AND    WMS.ModelTypeId                    =            2                            --TypeId 2 for Tunnel
    AND    WMS.Is_Deleted                        =            'FALSE'

--LFSWasherNumber duplicate check...
IF    EXISTS    (    SELECT    1
                FROM    [TCD].MachineSetup                    MS
                WHERE    MS.ControllerId                    =            @ControllerId
                    AND    MS.MachineInternalId            =            @LFSWasherNumber
                    AND    MS.IsDeleted                    =            'FALSE'
                    AND    MS.WasherId                        <>            @WasherId
                    AND MS.EcoalabAccountNumber            =            @EcoLabAccountNumber
                    AND MS.IsTunnel                        =            'TRUE'
            )
            BEGIN
                SET        @ErrorId                        =            51010
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate LFSWasher# provided.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET        @ReturnValue    =    -1
                RETURN    (@ReturnValue)
            END
--ETechWasherNumber duplicate check...
IF(@ControllerModelId NOT IN (7,8,9,10,11,14))
BEGIN
IF EXISTS ( SELECT 1
    FROM [TCD].Washer  AS W
    JOIN [TCD].MachineSetup AS MS ON MS.WasherId = W.WasherId 
    where W.ETechWasherNumber = @ETechWasherNumber
	AND W.WasherId = @WasherId
	 AND  MS.IsTunnel                    =            'TRUE'
)  
BEGIN  

SET  @ErrorId      =   51012  
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate ETechWasherNumber# provided.'  
--GOTO ErrorHandler  
RAISERROR (@ErrorMessage, 16, 1)  
SET  @ReturnValue = -1  
RETURN (@ReturnValue)  
END
END

--Now attempt Update...
BEGIN    TRAN

UPDATE    MS
    SET    MS.MachineName                    =            @TunnelName
    ,    MS.ControllerId                =            @ControllerId
    ,    MS.MachineInternalId            =            @LFSWasherNumber
    ,    MS.NumberOfComp                =            @NumberOfComp
    ,    MS.LastModifiedByUserId            =            @UserId
FROM    [TCD].MachineSetup                MS
JOIN    [TCD].Washer                    W
    ON    MS.WasherId                    =            W.WasherId
    AND    MS.EcoalabAccountNumber            =            W.EcolabAccountNumber
WHERE    MS.WasherId                    =            @WasherId
    AND    MS.EcoalabAccountNumber            =            @EcoLabAccountNumber
    AND    MS.IsDeleted                    =            'FALSE'
    AND    W.Is_Deleted                    =            'FALSE'

--check for any error
SET    @ErrorId    =    @@ERROR

IF    (@ErrorId    <>    0)
BEGIN

        IF    @@TRANCOUNT    >    0
		BEGIN
            ROLLBACK    TRAN
		END
	
    SET        @ErrorMessage                =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating washer data.'
    --GOTO    Errorhandler
    RAISERROR    (@ErrorMessage, 16, 1)
    SET    @ReturnValue    =    -1
    RETURN    (@ReturnValue)
END

--else, continue with the rest of the update in the other table...
IF(@ControllerModelId IS NOT NULL AND @ControllerModelId = 7 )
BEGIN
UPDATE    W
    SET    W.ModelId                        =            @WasherModelId
    ,    W.PlantWasherNumber                =            @PlantWasherNumber
    ,    W.WasherMode                    =            @WasherMode
    ,    W.MaxLoad                        =            @MaxLoad
    ,    W.AWEActive                    =            'FALSE'
    ,    W.NumberOfTanks                =            @NumberOfTanks
    ,    W.TransferType                    =            @TransferType
    ,    W.PressExtractor                =            @PressExtractor
    ,    W.EmptyPocketNumber                =            @ProgramNumber
    ,    W.[Description]                =            @Description
    ,    W.LastModifiedByUserId            =            @UserId
    ,    W.LastModifiedTime                =            @CurrentUTCTime
    ,    W.RatioDosingActive                =              NULL    
    ,    W.EndOfFormula                    =            0
    ,    W.NumberOfCompartmentsConveyorBelt     =            @NumberOfCompartmentsConveyorBelt
    ,    W.MinMachineLoad                 =            @MinMachineLoad
    ,    W.MaxMachineLoad                 =            @MaxMachineLoad
    ,    W.ProgramSelectionByTime             =            @ProgramSelectionByTime
    ,    W.WeightSelectionByTime             =            @WeightSelectionByTime
    ,    W.WeightSelectionByAnalogInput     =            @WeightSelectionByAnalogInput
    ,    W.TunInTomMode                     =            @TunInTomMode
    ,    W.SignalStopTunActive             =            @SignalStopTunActive
    ,    W.SignalEjectionTunActive         =            @SignalEjectionTunActive
    ,    W.DelayTimeForTunWashingPrograms     =            @DelayTimeForTunWashingPrograms
    ,    W.KannegiesserPressSpecialMode     =            @KannegiesserPressSpecialMode
    ,    W.ValveOutputsUsedAsTomSignal         =            @ValveOutputsUsedAsTomSignal
    ,    W.ExtendedClockOrDataProtocol         =            @ExtendedClockOrDataProtocol
    ,    W.WeightCorrectionFcc             =            @WeightCorrectionFcc
	,	 W.ETechWasherNumber					=		@ETechWasherNumber
	,	W.KannegiesserDosageInPreparationTankMode = @KannegiesserDosageInPreparationTankMode
	,	W.BatchOk = @BatchOk
FROM    [TCD].Washer                    W
JOIN    [TCD].MachineSetup                MS
    ON    W.WasherId                    =            MS.WasherId
    AND    W.EcoLabAccountNumber            =            MS.EcoalabAccountNumber
WHERE    W.WasherId                    =            @WasherId
    AND    W.EcoLabAccountNumber            =            @EcoLabAccountNumber
    AND    W.Is_Deleted                    =            'FALSE'
    AND    MS.IsDeleted                    =            'FALSE'
END
ELSE IF(@ControllerModelId IS NOT NULL AND ( @ControllerModelId = 8	OR @ControllerModelId = 9	OR @ControllerModelId = 10 OR @ControllerModelId = 11 OR @ControllerModelId = 14))
BEGIN
UPDATE    W
    SET    W.ModelId                        =            @WasherModelId
    ,    W.PlantWasherNumber                =            @PlantWasherNumber
    ,    W.WasherMode                    =            @WasherMode
    ,    W.MaxLoad                        =            @MaxLoad
    ,    W.AWEActive                    =            'FALSE'
    ,    W.NumberOfTanks                =            @NumberOfTanks
    ,    W.TransferType                    =            @TransferType
    ,    W.PressExtractor                =            @PressExtractor
    ,    W.EmptyPocketNumber                =            @ProgramNumber
    ,    W.[Description]                =            @Description
    ,    W.LastModifiedByUserId            =            @UserId
    ,    W.LastModifiedTime                =            @CurrentUTCTime
    ,    W.RatioDosingActive                =              NULL    
    ,    W.EndOfFormula                    =            0
    ,    W.NumberOfCompartmentsConveyorBelt     =            @NumberOfCompartmentsConveyorBelt
    ,    W.MinMachineLoad                 =            @MinMachineLoad
    ,    W.MaxMachineLoad                 =            @MaxMachineLoad
    ,    W.TunInTomMode                     =            @TunInTomMode
    ,    W.DelayTimeForTunWashingPrograms     =            @DelayTimeForTunWashingPrograms
    ,    W.KannegiesserPressSpecialMode     =            @KannegiesserPressSpecialMode
    ,    W.WeightCorrectionFcc             =            @WeightCorrectionFcc
	,	 W.DateAndTimeWhenBatchEjects		=			@DateAndTimeWhenBatchEjects
	,	 W.AutoRinseDesamixAfter			=			@AutoRinseDesamixAfter
	,	 W.AutoRinseDesamix1For				=			@AutoRinseDesamix1For
	,	 W.AutoRinseDesamix2For				=			@AutoRinseDesamix2For
	,	 W.TemperatureAlarmProbe1			=			@TemperatureAlarmProbe1
	,	 W.TemperatureAlarmProbe2			=			@TemperatureAlarmProbe2
	,	 W.TemperatureAlarmProbe3			=			@TemperatureAlarmProbe3
	,	 W.UseMe1OfGroup					=			@UseMe1OfGroup
	,	 W.UseMe2OfGroup					=			@UseMe2OfGroup
	,	 W.ETechWasherNumber					=		@ETechWasherNumber

FROM    [TCD].Washer                    W
JOIN    [TCD].MachineSetup                MS
    ON    W.WasherId                    =            MS.WasherId
    AND    W.EcoLabAccountNumber            =            MS.EcoalabAccountNumber
WHERE    W.WasherId                    =            @WasherId
    AND    W.EcoLabAccountNumber            =            @EcoLabAccountNumber
    AND    W.Is_Deleted                    =            'FALSE'
    AND    MS.IsDeleted                    =            'FALSE'
END
ELSE
BEGIN
UPDATE    W
    SET    W.ModelId                        =            @WasherModelId
    ,    W.PlantWasherNumber                =            @PlantWasherNumber
    ,    W.WasherMode                    =            @WasherMode
    ,    W.MaxLoad                        =            @MaxLoad
    ,    W.AWEActive                    =            @AWEActive
    ,    W.NumberOfTanks                =            @NumberOfTanks
    ,    W.TransferType                    =            @TransferType
    ,    W.PressExtractor                =            @PressExtractor
    ,    W.EmptyPocketNumber                =            @ProgramNumber
    ,    W.[Description]                =            @Description
    ,    W.LastModifiedByUserId            =            @UserId
    ,    W.LastModifiedTime                =            @CurrentUTCTime
    ,   W.RatioDosingActive                =              @RatioDosingActive    
    ,   W.EndOfFormula                    =            @EndOfFormula
    ,    W.LfsWasher                     =            NULL
    ,    W.NumberOfCompartmentsConveyorBelt     =            NULL
    ,    W.MinMachineLoad                 =            NULL
    ,    W.MaxMachineLoad                 =            NULL
    ,    W.ProgramSelectionByTime             =            NULL
    ,    W.WeightSelectionByTime             =            NULL
    ,    W.WeightSelectionByAnalogInput     =            NULL
    ,    W.TunInTomMode                     =            NULL
    ,    W.SignalStopTunActive             =            NULL
    ,    W.SignalEjectionTunActive         =            NULL
    ,    W.DelayTimeForTunWashingPrograms     =            NULL
    ,    W.KannegiesserPressSpecialMode     =            NULL
    ,    W.ValveOutputsUsedAsTomSignal         =            NULL
    ,    W.ExtendedClockOrDataProtocol         =            NULL
    ,    W.WeightCorrectionFcc             =            NULL
	,	 W.ETechWasherNumber					=		@ETechWasherNumber
FROM    [TCD].Washer                    W
JOIN    [TCD].MachineSetup                MS
    ON    W.WasherId                    =            MS.WasherId
    AND    W.EcoLabAccountNumber            =            MS.EcoalabAccountNumber
WHERE    W.WasherId                    =            @WasherId
    AND    W.EcoLabAccountNumber            =            @EcoLabAccountNumber
    AND    W.Is_Deleted                    =            'FALSE'
    AND    MS.IsDeleted                    =            'FALSE'
END
--check for error, if none - commit the tran, else rollback
SET    @ErrorId    =    @@ERROR
IF    (@ErrorId    <>    0)
	BEGIN
        IF    (@@TRANCOUNT    >    0)
			BEGIN
				ROLLBACK
			END

        SET        @ErrorMessage                =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating washer data.'
        --GOTO    Errorhandler
        RAISERROR    (@ErrorMessage, 16, 1)
        SET    @ReturnValue    =    -1
        RETURN    (@ReturnValue)
	END
ELSE
	BEGIN
        IF    (@@TRANCOUNT    >    0)
			BEGIN
				COMMIT
			END

        SET    @OutputTunnelId    =    @WasherId
	END


--IF    (@ErrorId    =    0)
--    BEGIN
--        --GOTO    ExitModule
--        RETURN    (@ReturnValue)
--    END




--ErrorHandler:
--RAISERROR    (@ErrorMessage, 16, 1)
--SET    @ReturnValue    =    -1




--ExitModule:

SET    NOCOUNT    OFF
RETURN    (@ReturnValue)


END
GO
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[AddTunnel]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.AddTunnel
	END
GO
CREATE PROCEDURE	[TCD].[AddTunnel]	
					@MyServiceWasherId						UniqueIdentifier
				,	@EcoLabAccountNumber					NVARCHAR(25)
				,	@WasherGroupId							INT
				,	@TunnelName								NVARCHAR(50)
				,	@WasherModelName						NVARCHAR(50)
				,	@RegionId								SMALLINT
--				,	@Size									INT									--we don't need to save this; ModelId PK determines it
				,	@ControllerId							INT
				,	@LFSWasherNumber						TINYINT			=			1		--For tunnels, it will be 1 until a diff. number is passed (as per the scenario)
				,	@PlantWasherNumber						SMALLINT
				,	@WasherMode								TINYINT
				,	@MaxLoad								SMALLINT
				,	@AWEActive								BIT
				,	@NumberOfTanks							TINYINT
				,	@NumberOfComp							TINYINT								--though this is INT in the table, we should not require it to be so
				,	@TransferType							TINYINT         =			NULL
				,	@PressExtractor							TINYINT       =			NULL
				,	@ProgramNumber							TINYINT
				,	@EndOfFormula							TINYINT
				,	@Description							NVARCHAR(1024)	=			NULL
				,	@UserId									INT

				,	@OutputTunnelId							INT			OUTPUT
				--Adding as part of re-factoring for integration with Synch/Configurator... generated TunnelId (re-named) is already being OUTPUT above
				,	@OutputLastModifiedTimestampAtLocal		DATETIME		=			NULL	OUTPUT
				,   @RatioDosingActive						Bit = 'False'
				,   @ControllerModelId						INT		=		NULL
				,   @NumberOfCompartmentsConveyorBelt			TINYINT	=		NULL
				,   @MaxMachineLoad							TINYINT	=		NULL
				,   @MinMachineLoad							TINYINT	=		NULL
				,   @ProgramSelectionByTime					BIT	  	=		NULL
				,   @WeightSelectionByTime					BIT	  	=		NULL
				,   @WeightSelectionByAnalogInput				BIT	  	=		NULL
				,   @TunInTomMode							BIT	  	=		NULL
				,   @SignalStopTunActive						BIT	  	=		NULL
				,   @SignalEjectionTunActive	  				BIT	  	=		NULL
				,   @DelayTimeForTunWashingPrograms			BIT	  	=		NULL
				,   @KannegiesserPressSpecialMode				BIT	  	=		NULL
				,   @ValveOutputsUsedAsTomSignal				BIT	  	=		NULL
				,   @ExtendedClockOrDataProtocol				BIT	  	=		NULL
				,   @WeightCorrectionFcc						BIT	  	=		NULL
				,	@DateAndTimeWhenBatchEjects					BIT	  		=		NULL
				,	@AutoRinseDesamixAfter						SMALLINT	=		NULL
				,	@AutoRinseDesamix1For						SMALLINT	=		NULL
				,	@AutoRinseDesamix2For						SMALLINT	=		NULL
				,	@TemperatureAlarmProbe1						BIT			=		NULL
				,	@TemperatureAlarmProbe2						BIT			=		NULL
				,	@TemperatureAlarmProbe3						BIT			=		NULL
				,	@ETechWasherNumber						    INT			=		NULL
				,	@KannegiesserDosageInPreparationTankMode	bit			=		NULL
				,	@BatchOk									bit			=		NULL

AS
BEGIN

SET	NOCOUNT	ON


DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''

	,	@WasherId						INT				=			NULL
	,	@WasherModelId					SMALLINT		=			NULL
	--Adding for integration with Synch./Central
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()
	,	@ControllerValidate				int				=										   0

--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
SET		@OutputLastModifiedTimestampAtLocal				=			@CurrentUTCTime
SET		@OutputTunnelId									=			ISNULL(@OutputTunnelId, NULL)			--SQLEnlight

--Check that the WasherGroup being associated-to is a valid Tunnel-type WG...
IF	NOT	EXISTS	(	SELECT	1
					FROM	[TCD].WasherGroup			WG
					JOIN	[TCD].WasherGroupType		WGT
						ON	WG.WasherGroupTypeId		=			WGT.WasherGroupTypeId
					JOIN	[TCD].MachineGroup					GT									--this is actually the Groups table and NOT really a Group TYPE
						ON	WG.WasherGroupId			=			GT.Id			--GroupTypeId is actually the Id of the Group
					WHERE	WG.WasherGroupId			=			@WasherGroupId
						AND	GT.EcolabAccountNumber		=			@EcoLabAccountNumber
						AND	GT.GroupTypeId	  			=			2			--select	GroupMaintype	from	GroupType
						AND	WGT.WasherGroupTypeName		=			'Tunnel'				--select	WasherGroupTypeName	from	WasherGroupType
				)
			BEGIN
				SET		@ErrorId						=			51001
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherGroup provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--Check for only 1 tunnel for a WasherGroup
IF	EXISTS		(	SELECT	1
					FROM	[TCD].MachineSetup			MS
					JOIN	[TCD].Washer				W
						ON	MS.WasherId					=			W.WasherId
					WHERE	MS.GroupId					=			@WasherGroupId
						AND	MS.EcoalabAccountNumber		=			@EcoLabAccountNumber
						AND	MS.IsDeleted				=			'FALSE'
						AND	MS.IsTunnel					=			'TRUE'
						AND	W.Is_Deleted				=			'FALSE'
				)
			BEGIN
				SET		@ErrorId						=			51008
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': A Tunnel has already been added to this Washer Group.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--Check for unique PlantWasherNo.
IF	EXISTS		(	SELECT	1
					FROM	[TCD].Washer				W
					JOIN	[TCD].MachineSetup			MS
						ON	W.WasherId					=			MS.WasherId
						AND	W.EcoLabAccountNumber		=			MS.EcoalabAccountNumber
					WHERE	W.EcoLabAccountNumber		=			@EcoLabAccountNumber
						AND	(
							W.PlantWasherNumber			=			@PlantWasherNumber							
							)
						AND	W.Is_Deleted				=			'FALSE'
						AND	MS.IsDeleted				=			'FALSE'
				)
			BEGIN
				SET		@ErrorId						=			51002
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Specified Plant Washer #/ already exists.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--Check that it's a valid Controller type/model (one that can control a Tunnel)

EXEC @ControllerValidate = [TCD].[ValidateController] 2,@ControllerId,@EcoLabAccountNumber

IF(@ControllerValidate = 1)
				
			BEGIN
				SET		@ErrorId						=			51003
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller was provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--EOF should not be an asocciated formula for the WG...
IF	EXISTS		(	SELECT	1
					FROM	[TCD].TunnelProgramSetup	TPS
					WHERE	TPS.EcolabAccountNumber		=			@EcoLabAccountNumber
						AND	TPS.WasherGroupId			=			@WasherGroupId
						AND	TPS.ProgramNumber			=			@ProgramNumber
						AND	TPS.Is_Deleted				=			'FALSE'
				)
			BEGIN
				SET		@ErrorId						=			51004
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An associated formula cannot be specified as End-Of-Formula.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--WasherMode check
IF	NOT	EXISTS	(	SELECT	1
					FROM	[TCD].ControllerModelControllerTypeMapping
														CMCTM
					JOIN	[TCD].ConduitController		CC
						ON	CC.ControllerTypeId			=			CMCTM.ControllerTypeId
						AND	CC.ControllerModelId		=			CMCTM.ControllerModelId
					JOIN	[TCD].[WasherModeMapping]	CTM2WM
						ON	CMCTM.Id					=			CTM2WM.ControllerModelControllerTypeMappingId
					WHERE	CC.EcoalabAccountNumber		=			@EcoLabAccountNumber
						AND	CC.ControllerId				=			@ControllerId
						AND	CC.IsDeleted				=			'FALSE'
						AND	CMCTM.MaxtunnelCount > 0
						AND	CTM2WM.WasherModeId			=			@WasherMode
				)
			BEGIN
				SET		@ErrorId						=			51005
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherMode was provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--select the WasherModelId based on name
SELECT	TOP	1
		@WasherModelId						=			WMS.WasherModelId
FROM	[TCD].WasherModelSize				WMS
WHERE	WMS.RegionId						=			@RegionId
	AND	WMS.WasherModelName					=			@WasherModelName
	AND	WMS.ModelTypeId						=			2							--TypeId 2 for Tunnel
	AND	WMS.Is_Deleted						=			'FALSE'

--LFSWasherNumber duplicate check...
IF	EXISTS	(	SELECT	1
				FROM	[TCD].MachineSetup					MS
				WHERE	MS.ControllerId					=			@ControllerId
					AND	MS.MachineInternalId			=			@LFSWasherNumber
					AND MS.EcoalabAccountNumber			=			@EcoLabAccountNumber
					AND	MS.IsDeleted					=			'FALSE'
					AND MS.IsTunnel						=			'TRUE'
			)
			BEGIN
				SET		@ErrorId						=			51010
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate LFSWasher# provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET		@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END
--ETechWasherNumber duplicate check...
IF(@ControllerModelId NOT IN (7,8,9,10,11,14))
BEGIN
IF EXISTS ( SELECT 1
    FROM [TCD].Washer  AS W
    JOIN [TCD].MachineSetup AS MS ON MS.WasherId = W.WasherId 
    where W.ETechWasherNumber = @ETechWasherNumber
	 AND  MS.IsTunnel                    =            'TRUE'
)  
BEGIN  

SET  @ErrorId      =   51012  
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate ETechWasherNumber# provided.'  
--GOTO ErrorHandler  
RAISERROR (@ErrorMessage, 16, 1)  
SET  @ReturnValue = -1  
RETURN (@ReturnValue)  
END
END

--Now attempt to insert a new row for the tunnel record being created...
BEGIN	TRAN
IF(@ControllerModelId IS NOT NULL AND @ControllerModelId = 7 )
BEGIN
INSERT	[TCD].Washer	(
		 MyServiceCustMchGuid
		,EcoLabAccountNumber
		,PlantWasherNumber
		,ModelId
		,WasherMode
		,MaxLoad
		,[Description]
		,Is_Deleted
		,LastModifiedByUserId
		,NumberOfTanks
		,TransferType
		,PressExtractor
	--Adding for integration with Synch./Central
		,LastModifiedTime
		,EmptyPocketNumber
		,NumberOfCompartmentsConveyorBelt
		,MinMachineLoad
		,MaxMachineLoad
		,ProgramSelectionByTime
		,WeightSelectionByTime
		,WeightSelectionByAnalogInput
		,TunInTomMode
		,SignalStopTunActive
		,SignalEjectionTunActive
		,DelayTimeForTunWashingPrograms
		,KannegiesserPressSpecialMode
		,ValveOutputsUsedAsTomSignal
		,ExtendedClockOrDataProtocol
		,WeightCorrectionFcc
		,AWEActive
		,EndOfFormula
		,ETechWasherNumber
		,KannegiesserDosageInPreparationTankMode
		,BatchOk
	)
SELECT @MyServiceWasherId					AS			MyServiceWasherId	
	,	@EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	@PlantWasherNumber					AS			PlantWasherNumber
	,	@WasherModelId						AS			ModelId
	--,	@Size							AS			Size
	,	@WasherMode						AS			WasherMode
	,	@MaxLoad							AS			MaxLoad
	,	@Description						AS			[Description]
	,	'FALSE'							AS			Is_Deleted
	,	@UserId							AS			LastModifiedByUserId
	,	@NumberOfTanks						AS			NumberOfTanks
	,	@TransferType						AS			TransferType
	,	@PressExtractor					AS			PressExtractor
	,	@CurrentUTCTime					AS			LastModifiedTime
	,	@ProgramNumber						AS			ProgramNumber
	,   @NumberOfCompartmentsConveyorBelt		AS			NumberOfCompartmentsConveyorBelt
	,   @MinMachineLoad						AS			MinMachineLoad
	,   @MaxMachineLoad						AS			MaxMachineLoad
	,   @ProgramSelectionByTime				AS			ProgramSelectionByTime
	,   @WeightSelectionByTime				AS			WeightSelectionByTime
	,   @WeightSelectionByAnalogInput			AS			WeightSelectionByAnalogInput
	,   @TunInTomMode						AS			TunInTomMode
	,   @SignalStopTunActive					AS			SignalStopTunActive
	,   @SignalEjectionTunActive	  			AS			SignalEjectionTunActive
	,   @DelayTimeForTunWashingPrograms		AS			DelayTimeForTunWashingPrograms
	,   @KannegiesserPressSpecialMode			AS			KannegiesserPressSpecialMode
	,   @ValveOutputsUsedAsTomSignal			AS			ValveOutputsUsedAsTomSignal
	,   @ExtendedClockOrDataProtocol			AS			ExtendedClockOrDataProtocol
	,   @WeightCorrectionFcc					AS			WeightCorrectionFcc
	,	'FALSE'							AS			AWEActive
	,	0								AS			EndOfFormula
	,   @ETechWasherNumber			AS			ETechWasherNumber
	,	@KannegiesserDosageInPreparationTankMode	AS KannegiesserDosageInPreparationTankMode
	,	@BatchOk						AS		BatchOk
END
ELSE IF(@ControllerModelId IS NOT NULL AND ( @ControllerModelId = 8	OR @ControllerModelId = 9	OR @ControllerModelId = 10 OR @ControllerModelId = 11 OR @ControllerModelId = 14))
BEGIN
INSERT	[TCD].Washer	(
		 MyServiceCustMchGuid
		,EcoLabAccountNumber
		,PlantWasherNumber
		,ModelId
		,WasherMode
		,MaxLoad
		,[Description]
		,Is_Deleted
		,LastModifiedByUserId
		,NumberOfTanks
		,TransferType
		,PressExtractor
	--Adding for integration with Synch./Central
		,LastModifiedTime
		,EmptyPocketNumber
		,NumberOfCompartmentsConveyorBelt
		,MinMachineLoad
		,MaxMachineLoad
		,ProgramSelectionByTime
		,WeightSelectionByTime
		,WeightSelectionByAnalogInput
		,TunInTomMode
		,SignalStopTunActive
		,SignalEjectionTunActive
		,DelayTimeForTunWashingPrograms
		,KannegiesserPressSpecialMode
		,ValveOutputsUsedAsTomSignal
		,ExtendedClockOrDataProtocol
		,WeightCorrectionFcc
		,AWEActive
		,EndOfFormula
		,AutoRinseDesamixAfter
		,AutoRinseDesamix1For
		,AutoRinseDesamix2For
		,TemperatureAlarmProbe1
		,TemperatureAlarmProbe2
		,TemperatureAlarmProbe3
		,DateAndTimeWhenBatchEjects
		,ETechWasherNumber

	)
SELECT @MyServiceWasherId					AS			MyServiceWasherId	
	,	@EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	@PlantWasherNumber					AS			PlantWasherNumber
	,	@WasherModelId						AS			ModelId
	--,	@Size							AS			Size
	,	@WasherMode						AS			WasherMode
	,	@MaxLoad							AS			MaxLoad
	,	@Description						AS			[Description]
	,	'FALSE'							AS			Is_Deleted
	,	@UserId							AS			LastModifiedByUserId
	,	@NumberOfTanks						AS			NumberOfTanks
	,	@TransferType						AS			TransferType
	,	@PressExtractor					AS			PressExtractor
	,	@CurrentUTCTime					AS			LastModifiedTime
	,	@ProgramNumber						AS			ProgramNumber
	,   @NumberOfCompartmentsConveyorBelt		AS			NumberOfCompartmentsConveyorBelt
	,   @MinMachineLoad						AS			MinMachineLoad
	,   @MaxMachineLoad						AS			MaxMachineLoad
	,   @ProgramSelectionByTime				AS			ProgramSelectionByTime
	,   @WeightSelectionByTime				AS			WeightSelectionByTime
	,   @WeightSelectionByAnalogInput			AS			WeightSelectionByAnalogInput
	,   @TunInTomMode						AS			TunInTomMode
	,   @SignalStopTunActive					AS			SignalStopTunActive
	,   @SignalEjectionTunActive	  			AS			SignalEjectionTunActive
	,   @DelayTimeForTunWashingPrograms		AS			DelayTimeForTunWashingPrograms
	,   @KannegiesserPressSpecialMode			AS			KannegiesserPressSpecialMode
	,   @ValveOutputsUsedAsTomSignal			AS			ValveOutputsUsedAsTomSignal
	,   @ExtendedClockOrDataProtocol			AS			ExtendedClockOrDataProtocol
	,   @WeightCorrectionFcc					AS			WeightCorrectionFcc
	,	'FALSE'							AS			AWEActive
	,	0								AS			EndOfFormula
	,	@AutoRinseDesamixAfter
	,	@AutoRinseDesamix1For
	,	@AutoRinseDesamix2For
	,	@TemperatureAlarmProbe1
	,	@TemperatureAlarmProbe2
	,	@TemperatureAlarmProbe3
	,	@DateAndTimeWhenBatchEjects
	,   @ETechWasherNumber						AS			ETechWasherNumber
END
ELSE
BEGIN
INSERT	[TCD].Washer	(
		MyServiceCustMchGuid
		,EcoLabAccountNumber
		,PlantWasherNumber
		,ModelId
		,WasherMode
		,MaxLoad
		,AWEActive
		,EndOfFormula
		,[Description]
		,Is_Deleted
		,LastModifiedByUserId
		,NumberOfTanks
		,TransferType
		,PressExtractor
	--Adding for integration with Synch./Central
		,LastModifiedTime
		,RatioDosingActive
		,EmptyPocketNumber
	)
SELECT @MyServiceWasherId					AS			MyServiceWasherId	
	,	@EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	@PlantWasherNumber					AS			PlantWasherNumber
	,	@WasherModelId						AS			ModelId
	--,	@Size							AS			Size
	,	@WasherMode						AS			WasherMode
	,	@MaxLoad							AS			MaxLoad
	,	@AWEActive						AS			AWEActive
	,	@EndOfFormula						AS			EndOfFormula
	,	@Description						AS			[Description]
	,	'FALSE'							AS			Is_Deleted
	,	@UserId							AS			LastModifiedByUserId
	,	@NumberOfTanks						AS			NumberOfTanks
	,	@TransferType						AS			TransferType
	,	@PressExtractor					AS			PressExtractor
	,	@CurrentUTCTime					AS			LastModifiedTime
	,   @RatioDosingActive					AS			RatioDosingActive
	,	@ProgramNumber						AS			ProgramNumber 	
END

SET	@ErrorId	=	@@ERROR
	
IF	(@ErrorId	<>	0)
	BEGIN
			IF	@@TRANCOUNT	>	0
			BEGIN
				ROLLBACK	TRAN
			END

			SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred creating new record for tunnel.'
			--GOTO	ErrorHandler
			RAISERROR	(@ErrorMessage, 16, 1)
			SET	@ReturnValue	=	-1
			RETURN	(@ReturnValue)
	END

--if no error, collect the id of the newly generated row...
SELECT	@WasherId	=	SCOPE_IDENTITY()


--insert in MachineSetup
INSERT	[TCD].MachineSetup	(
		WasherId	,GroupId	,MachineInternalId	,EcoalabAccountNumber	,MachineName	,IsTunnel	,ControllerId	,NumberOfComp	,IsDeleted	,LastModifiedByUserId	)
SELECT	@WasherId					AS			WasherId
	,	@WasherGroupId				AS			GroupId
	,	@LFSWasherNumber			AS			MachineInternalId
	,	@EcoLabAccountNumber		AS			EcoalabAccountNumber
	,	@TunnelName					AS			MachineName
	,	'TRUE'						AS			IsTunnel
	,	@ControllerId				AS			ControllerId
	,	@NumberOfComp				AS			NumberOfComp
	,	'FALSE'						AS			IsDeleted
	,	@UserId						AS			LastModifiedByUserId

SET	@ErrorId	=	@@ERROR

IF	(@ErrorId	<>	0)
	BEGIN
			IF	@@TRANCOUNT	>	0
			BEGIN
				ROLLBACK	TRAN
			END

			SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred assoicating new record for tunnel.'
			--GOTO	ErrorHandler
			RAISERROR	(@ErrorMessage, 16, 1)
			SET	@ReturnValue	=	-1
			RETURN	(@ReturnValue)
	END
ELSE
	BEGIN
			IF	@@TRANCOUNT	>	0
			BEGIN
				COMMIT
			END

			--SET the output param to be communicated back...
			SET	@OutputTunnelId	=	@WasherId
	END



--IF	(	@ErrorId	=	0	)
--	BEGIN
--		--GOTO	ExitModule
--		RETURN	(@ReturnValue)
--	END




--ErrorHandler:
--RAISERROR	(@ErrorMessage, 16, 1)
--SET	@ReturnValue	=	-1




--ExitModule:

SET	NOCOUNT	OFF
RETURN	(@ReturnValue)


END
GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[AddConventional]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.AddConventional
	END
GO

CREATE PROCEDURE	[TCD].[AddConventional]
					@EcoLabAccountNumber					NVARCHAR(1000)
				,	@WasherGroupId							INT
				, @NewWasherGroupId		int				=	null
				,	@ConventionalName						NVARCHAR(50)
				,	@ModelId								INT						--(Washer)Model Id for Size
				,	@ControllerId							INT
				,	@LFSWasherNumber						TINYINT					=	NULL
				,	@PlantWasherNumber						SMALLINT
				,	@WasherMode								TINYINT
				,	@MaxLoad								SMALLINT
				,	@AWEActive								BIT
				,	@HoldSignal								BIT
				,	@HoldDelay								SMALLINT															
				,	@TargetTurnTime							SMALLINT
				,	@WaterFlushTime							SMALLINT
				,	@ProgramNumber							TINYINT					--EOF number
				,	@Description							NVARCHAR(1024)			=	NULL
				,	@UserId									INT
				,	@ConventionalWasherGuid					UniqueIdentifier
				,	@ConventionalWasherId					INT									OUTPUT
				,	@LastModifiedTimestampAtCentral			DATETIME				=	NULL
				,	@OutputLastModifiedTimestampAtLocal		DATETIME				=	NULL	OUTPUT
				,	@IsDeleted								BIT						=	'FALSE'
				,   @RatioDosingActive						BIT						=	'FALSE'
,   @IsPony      BIT      = 'FALSE'
				,	@MinMachineLoad							SMALLINT				=	NULL
				,	@MaxMachineLoad							smallint				=	NULL
				,	@ProgramSelectionByTime					bit						=	NULL
				,	@FlowSwitchNumber						int						=	NULL
				,	@WasherStopExternalSignal				bit						=	NULL
				,	@OnHoldWESignalActive					bit						=	NULL
				,	@WasherOnHoldSignalDelay				int						=	NULL
				,	@ValveOutputsUsedAsTomSignal			bit						=	NULL
				,	@WeInTomMode							bit						=	NULL
				,	@ManifoldFlushTime						int						=	NULL
				,	@L1										bit						=	NULL
				,	@L2										bit						=	NULL
				,	@L3										bit						=	NULL
				,	@L4										bit						=	NULL
				,	@L5										bit						=	NULL
				,	@L6										bit						=	NULL
				,	@L7										bit						=	NULL
				,	@L8										bit						=	NULL
				,	@L9										bit						=	NULL
				,	@L10									bit						=	NULL
				,	@L11									bit						=	NULL
				,	@L12									bit						=	NULL
				,	@MyServiceLastSyncTime					DATETIME				=	NULL
				,	@UseMe1OfGroup							tinyint					=	NULL
				,	@UseMe2OfGroup							tinyint					=	NULL
				,	@UsePumpOfGroup							tinyint					=	NULL
				,	@WasherStopUseFinalExtracting			bit						=	NULL
				,	@TemperatureAlarmYesNo					bit						=	NULL
				,   @DefaultIdleTime						INT						=   NULL
				,   @ETechWasherNumber						INT						=   NULL
				,	@SignalAcceptanceTime					int						=	NULL

AS
BEGIN

SET NOCOUNT ON


DECLARE
@ReturnValue     INT    =   0
, @ErrorId      INT    =   0
, @ErrorMessage     NVARCHAR(4000) =   N''

, @WasherId      INT    =   NULL
 , @PlantId		 INT	 =	 NULL
 , @ControllerModelId INT = NULL
--, @WasherModelId     SMALLINT  =   NULL
--, @CurrentUTCTime     DATETIME  =   GETUTCDATE()     --SQLEnlight SA0004

DECLARE
@OutputList      AS TABLE  (
WasherId      INT
, LastModifiedTimestamp   DATETIME
)

SET  @ConventionalWasherId = ISNULL(@ConventionalWasherId, NULL)   --SQLEnlight
SET  @OutputLastModifiedTimestampAtLocal   =   ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)   --SQLEnlight
SET  @LastModifiedTimestampAtCentral    =   ISNULL(@LastModifiedTimestampAtCentral, NULL)    --SQLEnlight SA0029
SELECT  @PlantId = PlantId From TCD.Plant WHERE EcolabAccountNumber = @EcoLabAccountNumber
SELECT @ControllerModelId = cmctm.ControllerModelId 
FROM TCD.ControllerModelControllerTypeMapping cmctm 
INNER JOIN TCD.ConduitController cc 
	ON cc.ControllerModelId = cmctm.ControllerModelId
WHERE cc.ControllerId = @ControllerId AND cc.EcoalabAccountNumber = @EcoLabAccountNumber

--Check that the WasherGroup being associated-to is a valid Conventional-type WG...
IF NOT EXISTS ( SELECT 1
FROM [TCD].WasherGroup     WG
JOIN [TCD].WasherGroupType    WGT
ON WG.WasherGroupTypeId  =   WGT.WasherGroupTypeId
JOIN [TCD].MachineGroup     GT         --this is actually the Groups table and NOT really a Group TYPE
ON WG.WasherGroupId   =   GT.Id   --Id is actually the Id of the Group
AND WG.EcolabAccountNumber  =   GT.EcolabAccountNumber
WHERE WG.WasherGroupId   =   @WasherGroupId
AND GT.EcolabAccountNumber  =   @EcoLabAccountNumber
AND GT.GroupTypeId      =   2   --select GroupMaintype from MachineGroup
AND WGT.WasherGroupTypeName  =   'Conventional'   --select WasherGroupTypeName from WasherGroupType
AND GT.Is_Deleted    =   'FALSE'
)
BEGIN
SET  @ErrorId      =   51001
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherGroup provided.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

--Check for unique PlantWasherNo.
IF EXISTS  ( SELECT 1
FROM [TCD].Washer      W
JOIN [TCD].MachineSetup     MS
ON W.WasherId     =   MS.WasherId
AND W.EcoLabAccountNumber  =   MS.EcoalabAccountNumber
WHERE W.EcoLabAccountNumber  =   @EcoLabAccountNumber
AND (
W.PlantWasherNumber   =   @PlantWasherNumber
)
AND W.Is_Deleted    =   'FALSE'
AND MS.IsDeleted    =   'FALSE'
)
BEGIN
SET  @ErrorId      =   51002
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Specified Plant Washer #/ already exists.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

IF @ControllerId > 0
BEGIN
--Check on valid LFSWasher#/Controller type/model...
IF @LFSWasherNumber IS NOT NULL
BEGIN
	IF NOT EXISTS ( SELECT 1
	FROM [TCD].ControllerModelControllerTypeMapping
	CMCTM
	JOIN [TCD].ConduitController   CC
	ON CC.ControllerTypeId   =   CMCTM.ControllerTypeId
	AND CC.ControllerModelId  =   CMCTM.ControllerModelId
	WHERE CC.EcoalabAccountNumber  =   @EcoLabAccountNumber
	AND CC.ControllerId    =   @ControllerId
	AND CC.IsDeleted    =   'FALSE'
	AND CMCTM.MaximumWasherExtractorCount
	>=   @LFSWasherNumber
	)
		BEGIN
			SET  @ErrorId      =   51003
			SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller/LFSWasher# was provided.'
			--GOTO ErrorHandler
			RAISERROR (@ErrorMessage, 16, 1)
			SET  @ReturnValue = -1
			RETURN (@ReturnValue)
		END
END
END
--EOF should not be an asocciated formula for the WG...
IF EXISTS  ( SELECT 1
FROM [TCD].WasherProgramSetup   WPS
WHERE WPS.EcolabAccountNumber  =   @EcoLabAccountNumber
AND WPS.WasherGroupId   =   @WasherGroupId
AND WPS.ProgramNumber   =   @ProgramNumber
AND WPS.Is_Deleted    =   'FALSE'
)
BEGIN
SET  @ErrorId      =   51004
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An assoicated formula cannot be specified as End-Of-Formula.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

IF @ControllerId > 0
BEGIN
--WasherMode check
IF NOT EXISTS ( SELECT 1
FROM [TCD].ControllerModelControllerTypeMapping
CMCTM
					JOIN	[TCD].ConduitController			CC
						ON	CC.ControllerTypeId			=			CMCTM.ControllerTypeId
						AND	CC.ControllerModelId		=			CMCTM.ControllerModelId
					JOIN	[TCD].[WasherModeMapping]			CTM2WM
						ON	CMCTM.Id					=			CTM2WM.ControllerModelControllerTypeMappingId
					WHERE	CC.EcoalabAccountNumber		=			@EcoLabAccountNumber
						AND	CC.ControllerId				=			@ControllerId
						AND	CC.IsDeleted				=			'FALSE'
						AND	CTM2WM.WasherModeId			=			@WasherMode
)
BEGIN
SET  @ErrorId      =   51005
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherMode was provided.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

--LFSWasherNumber duplicate check...
IF	EXISTS	(	SELECT	1
				FROM	[TCD].MachineSetup					MS
				WHERE	MS.ControllerId					=			@ControllerId
					AND	MS.MachineInternalId			=			@LFSWasherNumber
					AND MS.EcoalabAccountNumber			=			@EcoLabAccountNumber
					AND	MS.IsDeleted					=			'FALSE'
					AND MS.IsTunnel						=			'FALSE'

)
BEGIN
SET  @ErrorId      =   51010
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate LFSWasher# provided.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END
--ETechWasherNumber duplicate check...
IF(@ControllerModelId NOT IN (7,8,9,10,11,14))
BEGIN
IF @ETechWasherNumber > 0
BEGIN 
--ETechWasherNumber duplicate check...
IF EXISTS ( SELECT 1
    FROM [TCD].Washer  AS W
    JOIN [TCD].MachineSetup AS MS ON MS.WasherId = W.WasherId 
    where W.ETechWasherNumber = @ETechWasherNumber
   AND MS.IsTunnel                    =            'FALSE'
)  
BEGIN  

SET  @ErrorId      =   51012  
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate ETechWasherNumber# provided.'  
--GOTO ErrorHandler  
RAISERROR (@ErrorMessage, 16, 1)  
SET  @ReturnValue = -1  
RETURN (@ReturnValue)  
END
END
END

END
--Now attempt to insert a new row for the conventional washer being added...
BEGIN TRAN

INSERT	[TCD].Washer	(
	 EcoLabAccountNumber	,PlantWasherNumber			,ModelId				,WasherMode					,MaxLoad						,AWEActive				,EndOfFormula
	,[Description]			,Is_Deleted					,LastModifiedByUserId	,HoldSignal					,HoldDelay						,TargetTurnTime			,WaterFlushTime		
	,MyServiceCustMchGuid	,RatioDosingActive			,MyServiceLastSynchTime	,MinMachineLoad				,MaxMachineLoad					,ProgramSelectionByTime	,FlowSwitchNumber		
	,WasherStopExternalSignal	,OnHoldWESignalActive	, WasherOnHoldSignalDelay	,ValveOutputsUsedAsTomSignal			,WeInTomMode			,ManifoldFlushTime	
	,L1	,L2	,L3	,L4	,L5	,L6	,L7	,L8	,L9	 ,L10 ,L11	,L12 ,UseMe1OfGroup ,UseMe2OfGroup ,UsePumpOfGroup ,WasherStopUseFinalExtracting ,TemperatureAlarmYesNo ,PlantId, DefaultIdleTime, ETechWasherNumber,SignalAcceptanceTime
)
OUTPUT
inserted.WasherId      AS   Id
, inserted.LastModifiedTime  AS   LastModifiedTimestamp
INTO
@OutputList (
WasherId
, LastModifiedTimestamp
)

SELECT	@EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	@PlantWasherNumber					AS			PlantWasherNumber
	,	@ModelId							AS			ModelId
	,	@WasherMode							AS			WasherMode
	,	@MaxLoad							AS			MaxLoad
	,	@AWEActive							AS			AWEActive
	,	@ProgramNumber						AS			ProgramNumber
	,	@Description						AS			[Description]
	,	@IsDeleted							AS			Is_Deleted
	,	@UserId								AS			LastModifiedByUserId
	,	@HoldSignal							AS			HoldSignal
	,	@HoldDelay							AS			HoldDelay
	,	@TargetTurnTime						AS			TargetTurnTime
	,	@WaterFlushTime						AS			WaterFlushTime
	,	@ConventionalWasherGuid				AS			MyServiceCustMchGuid
	,	@RatioDosingActive					AS			RatioDosingActive
	,	@MyServiceLastSyncTime				AS			MyServiceLastSynchTime
	,	@MinMachineLoad						AS			MinimumMachineLoad
	,	@MaxMachineLoad						AS			MaximumMachineLoad
	,	@ProgramSelectionByTime				AS			ProgramSelectionByTime
	,	@FlowSwitchNumber					AS			FlowSwitchNumber
	,	@WasherStopExternalSignal			AS			WasherStopExternalSignal
	,	@OnHoldWESignalActive				AS			OnHoldWESignalActive
	,	@WasherOnHoldSignalDelay			AS			WasherOnHoldSignalDelay
	,	@ValveOutputsUsedAsTomSignal		AS			ValveOutputsUsedAsTomSignal
	,	@WeInTomMode						AS			WeInTomMode			
	,	@ManifoldFlushTime					AS			ManifoldFlushTime			
	,	@L1									AS			L1
	,	@L2									AS			L2
	,	@L3									AS			L3
	,	@L4									AS			L4
	,	@L5									AS			L5
	,	@L6									AS			L6
	,	@L7									AS			L7
	,	@L8									AS			L8
	,	@L9									AS			L9
	,	@L10								AS			L10
	,	@L11								AS			L11
	,	@L12								AS			L12
	,	@UseMe1OfGroup						AS			UseMe1OfGroup
	,	@UseMe2OfGroup						AS			UseMe2OfGroup
	,	@UsePumpOfGroup						AS			UsePumpOfGroup
	,	@WasherStopUseFinalExtracting		AS			WasherStopUseFinalExtracting
	,	@TemperatureAlarmYesNo				AS			TemperatureAlarmYesNo
	,	@PlantId							AS			PlantId
	,   @DefaultIdleTime AS   DefaultIdleTime 
	,   @ETechWasherNumber AS ETechWasherNumber
	,	@SignalAcceptanceTime				AS			SignalAcceptanceTime


SET @ErrorId = @@ERROR

IF (@ErrorId <> 0)
BEGIN
IF @@TRANCOUNT > 0
BEGIN
ROLLBACK TRAN
END

SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred creating new record for conventional.'
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

--if no error, collect the id of the newly generated row...
SELECT TOP 1 @WasherId = O.WasherId FROM @OutputList O

--insert in MachineSetup
INSERT [TCD].MachineSetup (
WasherId ,GroupId ,MachineInternalId ,EcoalabAccountNumber ,MachineName ,IsTunnel ,ControllerId , IsDeleted ,LastModifiedByUserId,IsPony )
SELECT @WasherId     AS   WasherId
, @WasherGroupId    AS   GroupId
, @LFSWasherNumber   AS   MachineInternalId
, @EcoLabAccountNumber  AS   EcoalabAccountNumber
, @ConventionalName   AS   MachineName
,@IsDeleted      AS   IsTunnel
, @ControllerId    AS   ControllerId
, 'FALSE'      AS   IsDeleted
, @UserId      AS   LastModifiedByUserId
,@IsPony As IsPony



 IF(ISNULL( @NewWasherGroupId,0)>0 AND (@WasherGroupId != @NewWasherGroupId))
 BEGIN
    UPDATE tcd.machinesetup 
    SET GroupId = @NewWasherGroupId
    WHERE WasherId = @WasherId
     
   EXEC TCD.SaveInjectionDetails @WasherGroupId,@NewWasherGroupId,@ControllerId,@WasherId,@EcolabAccountNumber
 END
 ELSE
 BEGIN
   EXEC TCD.SaveInjectionDetails @WasherGroupId,@WasherGroupId,@ControllerId,@WasherId,@EcolabAccountNumber
 END

SET @ErrorId = @@ERROR

IF (@ErrorId <> 0)
BEGIN
IF @@TRANCOUNT > 0
BEGIN
ROLLBACK TRAN
END

SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred assoicating new record for conventional.'
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END
ELSE
BEGIN
IF @@TRANCOUNT > 0
BEGIN
COMMIT
END

--SET the output param to be communicated back...

SELECT TOP 1
@OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp
, @ConventionalWasherId    = O.WasherId
FROM @OutputList       O

END




IF ( @ErrorId = 0 )
BEGIN
		IF (@ControllerModelId = 7)
			BEGIN
				UPDATE TCD.WasherGroup SET ControllerId = @ControllerId WHERE WasherGroupId = @WasherGroupId
			END
RETURN (@ReturnValue)
END



--ErrorHandler:
--RAISERROR (@ErrorMessage, 16, 1)
--SET @ReturnValue = -1


--ExitModule:

--RETURN (@ReturnValue)

--SET NOCOUNT OFF

END
GO
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetTunnelConnections]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetTunnelConnections
	END
GO


/*	

Purpose					:	To get the Tunnel Connections - Connections tab

*/

CREATE PROCEDURE	[TCD].[GetTunnelConnections]
					
	@Machineid INT,
	@Controllerid INT,
	@EcolabAccNumber NVARCHAR(100)= NULL
AS
BEGIN

SELECT 
CES.ControllerId AS ControllerId
,CAST(CES.LineNumber AS int) AS DosingLineNumber
,CAST(TCEVM.DosingPointNumber AS int) AS DosingPointNumber
,CAST(TCEVM.ValveNumber AS int) AS ValveNumber
,CAST(TCEVM.TunnelNumber AS int) AS MachineInternalId
,CAST(TCEVM.CompartmentNumber AS int) AS TunnelCompartmentNumber
,CAST(CC.ControllerModelId AS int) AS ControllerModelId
,CASE WHEN CES.ControllerEquipmentTypeId = 2 AND (CES.ControllerEquipmentId = 13 OR CES.ControllerEquipmentId = 27) THEN 'ME1'
		WHEN CES.ControllerEquipmentTypeId = 2 AND (CES.ControllerEquipmentId = 14 OR CES.ControllerEquipmentId = 28) THEN 'ME2'
		ELSE 'PUMP' END AS ControllerEquipmentType
FROM TCD.TunnelCompartmentEquipmentValveMapping AS TCEVM
INNER JOIN TCD.ControllerEquipmentSetup CES ON TCEVM.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId
INNER JOIN TCD.MachineSetup AS MS ON TCEVM.TunnelNumber = MS.MachineInternalId AND CES.ControllerId = MS.ControllerId
INNER JOIN TCD.ConduitController CC ON CC.ControllerId = CES.ControllerId
WHERE MS.WASHERID = @Machineid AND CES.CONTROLLERID = @Controllerid

END
GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetCompartmentDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetCompartmentDetails
	END
GO
/*

Purpose					:	To populate the form-view fields in the Tunnel setup --> Compartments tab



History					:

Oct. 2014		dfozdar@allianceglobalservice.com		initial version



*/
CREATE PROCEDURE [TCD].[GetCompartmentDetails] @EcoLabAccountNumber NVARCHAR(25)
 ,@WasherGroupId INT
 ,@TunnelId INT
 ,@CompartmentNumber TINYINT = 1
 ,@IsDelete BIT = 'False'
AS
BEGIN
 SET NOCOUNT ON

 DECLARE @RegionId INT,
 @PlantId int ,
 @ControllerModelId int

 SELECT @RegionId = RegionId, @PlantId = PlantId
   FROM TCD.Plant
   WHERE EcolabAccountNumber = @EcoLabAccountNumber
    AND Is_Deleted = 0

 DECLARE @ReturnValue INT = 0
  ,@ErrorId INT = 0
  ,@ErrorMessage NVARCHAR(4000) = N''
  ,@ControllerId INT = NULL
  ,@NumberOfComp TINYINT = NULL
  ,@DosagePoint BIT = NULL

 SET @WasherGroupId = ISNULL(@WasherGroupId, NULL) --SQLEnlight SA0029

 --Get ControllerId, Number
 SELECT @ControllerId = ISNULL(MS.ControllerId, - 1)
  ,@NumberOfComp = ISNULL(MS.NumberOfComp, - 1)
 FROM [TCD].MachineSetup MS
 INNER JOIN [TCD].ConduitController CC ON MS.ControllerId = CC.ControllerId
  AND MS.EcoalabAccountNumber = CC.EcoalabAccountNumber
 WHERE MS.EcoalabAccountNumber = @EcoLabAccountNumber
  AND MS.WasherId = @TunnelId
  AND MS.IsTunnel = 'TRUE'
  AND MS.IsDeleted = 'FALSE'
  AND CC.IsDeleted = 'FALSE'

  SELECT @ControllerModelId = cc.ControllerModelId from tcd.ConduitController cc WHERE cc.ControllerId = @ControllerId

 --if we didn't get a valid Controller, error-out
 IF (@ControllerId = - 1)
 BEGIN
  SET @ErrorId = 51020
  SET @ErrorMessage = N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Could not determine the Controller for the specified tunnel.'

  RAISERROR (
    @ErrorMessage
    ,16
    ,1
    )

  SET @ReturnValue = - 1

  RETURN (@ReturnValue)
 END

 --CompartmentNumber
 IF (@CompartmentNumber > @NumberOfComp)
 BEGIN
  SET @ErrorId = 51021
  SET @ErrorMessage = N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Invalid Compartment Number specified for the tunnel.'

  RAISERROR (
    @ErrorMessage
    ,16
    ,1
    )

  SET @ReturnValue = - 1

  RETURN (@ReturnValue)
 END

 --Select the details of the compartment...
 ;WITH CTE_ComptNumbersForTunnel
AS (
    SELECT MS.GroupId, 'ALL' AS CompartmentNumber, MS.NumberOfComp
    FROM TCD.MachineSetup AS MS
    WHERE MS.IsTunnel = 1 AND MS.IsDeleted = 0
)

, CTE_ComptNumbersforEachWasherGroup 
AS (
    SELECT  C.GroupId
            , TunnelCompNumber = 1
            , CompartmentNumber
    , NumberOfComp
    FROM    CTE_ComptNumbersForTunnel C
    UNION ALL 
    SELECT  GroupId
            , TunnelCompNumber = TunnelCompNumber + 1
            , CompartmentNumber
    , NumberOfComp
    FROM    CTE_ComptNumbersforEachWasherGroup
    WHERE   NumberOfComp > TunnelCompNumber
)
, CTE_SensorsForEachCompartment 
AS (
    SELECT CASE 
        WHEN S.MachineCompartment IS NULL AND ISNULL(S.IsPress,0) = 0  
        THEN 'ALL'
        WHEN 
  --( SELECT DISTINCT Istunnel
      -- FROM [TCD].machinesetup M
      -- WHERE M.groupId = S.GroupId ) = 1 
       --AND 
    S.MachineCompartment IS NOT NULL 
       --AND ISNULL(S.IsPress,0) = 0 
        THEN CAST(S.Machinecompartment AS VARCHAR)
    END AS CompartmentNumber
    , CASE WHEN STM.Name = 'Temperature' THEN '1' ELSE '0' END AS Temperature
    , CASE WHEN STM.Name = 'pH' THEN '1' ELSE '0' END AS pH
    , CASE WHEN STM.Name = 'Conductivity' THEN '1' ELSE '0' END AS Conductivity
    , CASE WHEN STM.Name = 'Redox' THEN '1' ELSE '0' END AS Redox
    , S.GroupId
    , S.ControllerID
    FROM TCD.Sensor AS S 
    LEFT JOIN TCD.SensorTypeMaster AS STM ON S.SensorType = STM.ResourceId
 WHERE S.Is_Deleted = 0
    )
, CTE_TunnelSensors
AS (
    SELECT  Sensors.GroupId
    , Sensors.ControllerID
    , TunnelCompNumberForWG.TunnelCompNumber AS CompartmentNumber
    , MAX(Sensors.pH) AS pH
    , MAX(Sensors.Temperature) AS Temperature
    , MAX(Sensors.Conductivity) AS Conductivity
    , MAX(Sensors.Redox) AS Redox
    FROM CTE_SensorsForEachCompartment AS Sensors
    LEFT JOIN CTE_ComptNumbersforEachWasherGroup AS TunnelCompNumberForWG
    ON Sensors.GroupId = TunnelCompNumberForWG.GroupId 
    AND Sensors.CompartmentNumber = CASE WHEN Sensors.CompartmentNumber = 'ALL' 
            THEN TunnelCompNumberForWG.CompartmentNumber
         WHEN Sensors.CompartmentNumber <> 'ALL' 
            THEN CAST(TunnelCompNumberForWG.TunnelCompNumber AS VARCHAR)
        END
 GROUP BY Sensors.GroupId, Sensors.ControllerID, TunnelCompNumberForWG.TunnelCompNumber
 )
 SELECT TC.WashStepId AS WashStepId
  ,TC.WaterInletDrainId AS WaterInletDrainId
  ,TC.WaterFlowId AS WaterFlowId
  ,TC.WaterLevel AS WaterLevel
  ,TC.TemperatureControlByPMR AS TemperatureControlByPMR
  ,TC.UsePressExtractWater AS UsePressExtractWater
  ,TC.SplitCompartment AS SplitCompartment
  ,TC.RecycledWaterInlet AS RecycledWaterInlet
  ,TC.Steam AS Steam
  ,@CompartmentNumber AS CompartmentNumber
  ,TC.IterationPoint AS IterationPoint
  --Adding cols. for integration with Synch./Central
  ,TC.LastModifiedTime AS LastModifiedTime
  ,TC.LastSyncTime AS LastSyncTime
  ,TC.TunnelCompartmentId AS TunnelCompartmentId
  ,TC.WasherId AS WasherId
  ,TC.EcoLabAccountNumber AS EcoLabAccountNumber
  ,W.MyServiceCustMchGuid AS MyServiceWasherId
  ,TWIDL.MyServicePropId AS MyServiceDrainLookupId
  ,TWFT.MyServicePropId AS MyServiceWaterFlowTypeId
  ,CAST(ISNULL(CTE.Temperature, 0) as bit) AS Temperature
  ,CAST(ISNULL(CTE.pH, 0) as bit) AS PhProbe
  ,CAST(ISNULL(CTE.Conductivity, 0) as bit) AS Conductivity
  ,CAST(ISNULL(CTE.Redox, 0) as bit) AS Redox
 FROM [TCD].Washer W
 INNER JOIN [TCD].MachineSetup MS ON W.WasherId = MS.WasherId
  AND W.EcoLabAccountNumber = MS.EcoalabAccountNumber
 INNER JOIN [TCD].TunnelCompartment TC ON W.WasherId = TC.WasherId
  AND W.EcoLabAccountNumber = TC.EcoLabAccountNumber
 INNER JOIN [TCD].TunnelWaterInletDrainLookup TWIDL ON TC.WaterInletDrainId = TWIDL.TunnelWaterInletDrainLookupId
 INNER JOIN [TCD].TunnelWaterFlowType TWFT ON TC.WaterFlowId = TWFT.TunnelWaterFlowTypeId
 LEFT JOIN CTE_TunnelSensors CTE ON CTE.GroupId = MS.GroupId AND CTE.CompartmentNumber = @CompartmentNumber
 WHERE W.EcoLabAccountNumber = @EcoLabAccountNumber
  AND W.WasherId = @TunnelId
  AND MS.IsTunnel = 'TRUE'
  AND (
   W.Is_Deleted = 'FALSE'
   OR W.Is_Deleted = @IsDelete
   )
  AND (
   MS.IsDeleted = 'FALSE'
   OR MS.IsDeleted = @IsDelete
   )
  AND TC.CompartmentNumber = @CompartmentNumber
  
 --select the equipment association...
 IF (@RegionId = 1)
 BEGIN
 IF(@ControllerModelId = 7)
 BEGIN
 IF EXISTS (SELECT 1 FROM TCD.TunnelCompartment tc WHERE tc.WasherId = @TunnelId AND tc.CompartmentNumber = @CompartmentNumber AND tc.EcoLabAccountNumber = @EcoLabAccountNumber)
 BEGIN
  SELECT ISNULL(TCEM.ControllerEquipmentSetupId, tcevm.ControllerEquipmentSetupID)       AS   ControllerEquipmentSetupId
    ,CES.ControllerEquipmentId          AS   ControllerEquipmentId
    ,CES.ControllerEquipmentTypeId          AS   ControllerEquipmentTypeId
    ,ISNULL(NULLIF(PM2.EnvisionDisplayName,''), PM2.NAME)     AS   ProductName
    ,TCEM.MyServiceCmpmtDsgDvcguid         AS   MyServiceCmpmtDsgDvcguid
    ,ISNULL(TCEM.Is_Deleted, 0)           AS   IsDelete
    ,0              AS   FormulaAssociated 
    FROM TCD.TunnelCompartmentEquipmentValveMapping tcevm
    INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.ControllerEquipmentSetupId = tcevm.ControllerEquipmentSetupId 
    AND tcevm.PlantID = @PlantId
    INNER JOIN TCD.TunnelCompartment tc ON  tc.CompartmentNumber = tcevm.CompartmentNumber AND tc.EcoLabAccountNumber = ces.EcoLabAccountNumber
    LEFT JOIN TCD.TunnelCompartmentEquipmentMapping tcem ON tcevm.ControllerEquipmentSetupID = tcem.ControllerEquipmentSetupId
    AND tc.TunnelCompartmentId = tcem.TunnelCompartmentId AND (TCEM.Is_Deleted = 'FALSE' OR TCEM.Is_Deleted = @IsDelete)
    AND tcem.EcoLabAccountNumber = tc.EcoLabAccountNumber AND tcem.EcoLabAccountNumber = ces.EcoLabAccountNumber
    INNER JOIN TCD.MachineSetup ms ON ms.WasherId = tc.WasherId AND ms.ControllerId = ces.ControllerId AND ms.EcoalabAccountNumber = tc.EcoLabAccountNumber
    AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber
    INNER JOIN TCD.ProductdataMapping pm ON pm.EcolabAccountNumber = ces.EcoLabAccountNumber AND pm.ProductID = ces.ProductId 
    INNER JOIN TCD.ProductMaster pm2 ON pm2.ProductId = pm.ProductID
    WHERE ms.WasherId = @TunnelId AND tc.CompartmentNumber = @CompartmentNumber AND ms.EcoalabAccountNumber = @EcoLabAccountNumber
    AND MS.IsTunnel = 'TRUE' AND (MS.IsDeleted = 'FALSE' OR MS.IsDeleted = @IsDelete)
    AND (PM.Is_Deleted = 'FALSE' OR PM.Is_Deleted = @IsDelete)
END
ELSE
BEGIN
	SELECT DISTINCT tcevm.ControllerEquipmentSetupID       AS   ControllerEquipmentSetupId
    ,CES.ControllerEquipmentId          AS   ControllerEquipmentId
    ,CES.ControllerEquipmentTypeId          AS   ControllerEquipmentTypeId
    ,ISNULL(NULLIF(PM2.EnvisionDisplayName,''), PM2.NAME)     AS   ProductName
    ,NULL         AS   MyServiceCmpmtDsgDvcguid
    ,0           AS   IsDelete
    ,0              AS   FormulaAssociated 
	FROM TCD.TunnelCompartmentEquipmentValveMapping tcevm
	INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.ControllerEquipmentSetupId = tcevm.ControllerEquipmentSetupID
	INNER JOIN TCD.MachineSetup ms ON ms.ControllerId = ces.ControllerId AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber
	INNER JOIN TCD.ProductdataMapping pm ON pm.EcolabAccountNumber = ces.EcoLabAccountNumber AND pm.ProductID = ces.ProductId
	INNER JOIN TCD.ProductMaster pm2 ON pm2.ProductId = pm.ProductId
	WHERE (PM.Is_Deleted = 'FALSE' OR PM.Is_Deleted = 0)
	AND tcevm.CompartmentNumber = @CompartmentNumber
    AND tcevm.PlantID = @PlantId
	AND ms.WasherId = @TunnelId  AND ms.EcoalabAccountNumber =  @EcoLabAccountNumber
    AND MS.IsTunnel = 'TRUE' AND (MS.IsDeleted = 'FALSE' OR MS.IsDeleted = 0) 
END
END
 ELSE
 BEGIN
 SELECT TCEM.ControllerEquipmentSetupId AS ControllerEquipmentSetupId
   ,CES.ControllerEquipmentId AS ControllerEquipmentId
   ,CES.ControllerEquipmentTypeId AS ControllerEquipmentTypeId
   ,ISNULL(NULLIF(PM.EnvisionDisplayName,''), PM.NAME) AS ProductName
   ,TCEM.MyServiceCmpmtDsgDvcguid AS MyServiceCmpmtDsgDvcguid
   ,TCEM.Is_Deleted AS IsDelete
   ,(
    SELECT Count(*)
    FROM [TCD].TunnelDosingSetup tds
    INNER JOIN [TCD].TunnelDosingProductMapping TDPM ON TDPM.GroupId = TDS.GroupId
    INNER JOIN [TCD].TunnelProgramSetup tps ON tps.TunnelProgramSetupId = tds.TunnelProgramSetupId
     AND tps.Is_Deleted = 'false'
    WHERE TDPM.ControllerEquipmentSetupId = TCEM.ControllerEquipmentSetupId
     AND TDPM.CompartmentNumber = TDS.CompartmentNumber
     AND TDPM.GroupId = MS.GroupId
    ) AS FormulaAssociated
  FROM [TCD].Washer W
  INNER JOIN [TCD].MachineSetup MS ON W.WasherId = MS.WasherId
   AND W.EcoLabAccountNumber = MS.EcoalabAccountNumber
  INNER JOIN [TCD].TunnelCompartment TC ON W.WasherId = TC.WasherId
   AND W.EcoLabAccountNumber = TC.EcoLabAccountNumber
  INNER JOIN [TCD].TunnelCompartmentEquipmentMapping TCEM ON TC.TunnelCompartmentId = TCEM.TunnelCompartmentId
   AND TC.EcoLabAccountNumber = TCEM.EcoLabAccountNumber
  INNER JOIN [TCD].ControllerEquipmentSetup CES ON TCEM.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId
   AND TCEM.EcoLabAccountNumber = CES.EcoLabAccountNumber
   AND CES.ControllerId = MS.ControllerId
  INNER JOIN [TCD].ProductMaster PM ON CES.ProductId = PM.ProductId
  WHERE W.EcoLabAccountNumber = @EcoLabAccountNumber
   AND W.WasherId = @TunnelId
   AND MS.IsTunnel = 'TRUE'
   AND (
    W.Is_Deleted = 'FALSE'
    OR W.Is_Deleted = @IsDelete
    )
   AND (
    MS.IsDeleted = 'FALSE'
    OR MS.IsDeleted = @IsDelete
    )
   AND TC.CompartmentNumber = @CompartmentNumber
   AND (
    TCEM.Is_Deleted = 'FALSE'
    OR TCEM.Is_Deleted = @IsDelete
    )
   AND (
    PM.Is_Deleted = 'FALSE'
    OR PM.Is_Deleted = @IsDelete
    )
 END

  
 END
 ELSE IF (@RegionId = 2)
 BEGIN
   IF EXISTS (SELECT 1 FROM TCD.TunnelCompartment tc WHERE tc.WasherId = @TunnelId AND tc.CompartmentNumber = @CompartmentNumber AND tc.EcoLabAccountNumber = @EcoLabAccountNumber)
 BEGIN
  SELECT ISNULL(TCEM.ControllerEquipmentSetupId, tcevm.ControllerEquipmentSetupID)       AS   ControllerEquipmentSetupId
    ,CES.ControllerEquipmentId          AS   ControllerEquipmentId
    ,CES.ControllerEquipmentTypeId          AS   ControllerEquipmentTypeId
    ,ISNULL(NULLIF(PM2.EnvisionDisplayName,''), PM2.NAME)     AS   ProductName
    ,TCEM.MyServiceCmpmtDsgDvcguid         AS   MyServiceCmpmtDsgDvcguid
    ,ISNULL(TCEM.Is_Deleted, 0)           AS   IsDelete
    ,0              AS   FormulaAssociated 
    FROM TCD.TunnelCompartmentEquipmentValveMapping tcevm
    INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.ControllerEquipmentSetupId = tcevm.ControllerEquipmentSetupId 
    AND tcevm.PlantID = @PlantId
    INNER JOIN TCD.TunnelCompartment tc ON  tc.CompartmentNumber = tcevm.CompartmentNumber AND tc.EcoLabAccountNumber = ces.EcoLabAccountNumber
    LEFT JOIN TCD.TunnelCompartmentEquipmentMapping tcem ON tcevm.ControllerEquipmentSetupID = tcem.ControllerEquipmentSetupId
    AND tc.TunnelCompartmentId = tcem.TunnelCompartmentId AND (TCEM.Is_Deleted = 'FALSE' OR TCEM.Is_Deleted = @IsDelete)
    AND tcem.EcoLabAccountNumber = tc.EcoLabAccountNumber AND tcem.EcoLabAccountNumber = ces.EcoLabAccountNumber
    INNER JOIN TCD.MachineSetup ms ON ms.WasherId = tc.WasherId AND ms.ControllerId = ces.ControllerId AND ms.EcoalabAccountNumber = tc.EcoLabAccountNumber
    AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber
    INNER JOIN TCD.ProductdataMapping pm ON pm.EcolabAccountNumber = ces.EcoLabAccountNumber AND pm.ProductID = ces.ProductId 
    INNER JOIN TCD.ProductMaster pm2 ON pm2.ProductId = pm.ProductID
    WHERE ms.WasherId = @TunnelId AND tc.CompartmentNumber = @CompartmentNumber AND ms.EcoalabAccountNumber = @EcoLabAccountNumber
    AND MS.IsTunnel = 'TRUE' AND (MS.IsDeleted = 'FALSE' OR MS.IsDeleted = @IsDelete)
    AND (PM.Is_Deleted = 'FALSE' OR PM.Is_Deleted = @IsDelete)
END
ELSE
BEGIN
	SELECT DISTINCT tcevm.ControllerEquipmentSetupID       AS   ControllerEquipmentSetupId
    ,CES.ControllerEquipmentId          AS   ControllerEquipmentId
    ,CES.ControllerEquipmentTypeId          AS   ControllerEquipmentTypeId
    ,ISNULL(NULLIF(PM2.EnvisionDisplayName,''), PM2.NAME)     AS   ProductName
    ,NULL         AS   MyServiceCmpmtDsgDvcguid
    ,0           AS   IsDelete
    ,0              AS   FormulaAssociated 
	FROM TCD.TunnelCompartmentEquipmentValveMapping tcevm
	INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.ControllerEquipmentSetupId = tcevm.ControllerEquipmentSetupID
	INNER JOIN TCD.MachineSetup ms ON ms.ControllerId = ces.ControllerId AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber
	INNER JOIN TCD.ProductdataMapping pm ON pm.EcolabAccountNumber = ces.EcoLabAccountNumber AND pm.ProductID = ces.ProductId
	INNER JOIN TCD.ProductMaster pm2 ON pm2.ProductId = pm.ProductId
	WHERE (PM.Is_Deleted = 'FALSE' OR PM.Is_Deleted = 0)
	AND tcevm.CompartmentNumber = @CompartmentNumber
    AND tcevm.PlantID = @PlantId
	AND ms.WasherId = @TunnelId  AND ms.EcoalabAccountNumber =  @EcoLabAccountNumber
    AND MS.IsTunnel = 'TRUE' AND (MS.IsDeleted = 'FALSE' OR MS.IsDeleted = 0) 
END
 END

 SET NOCOUNT OFF
END
GO

IF EXISTS(SELECT  * FROM sys.types WHERE name = N'ControllerEquipment')
BEGIN
DROP PROCEDURE tcd.SaveTunnelCompartment
DROP TYPE [TCD].[ControllerEquipment]
END
GO

CREATE	TYPE	[TCD].[ControllerEquipment]
AS	TABLE	(
				ControllerEquipmentSetupId			SMALLINT		NOT	NULL
			,	DeleteFlag							BIT				NOT	NULL
			,	MyServiceCmpmtDsgDvcguid				uniqueidentifier	    NOT NULL
			);
GO
CREATE	PROCEDURE	[TCD].[SaveTunnelCompartment]
					@EcoLabAccountNumber					NVARCHAR(25)
				,	@TunnelId								INT
				,	@CompartmentNumber						TINYINT

				,	@WashStepId								INT					=			NULL
				,	@WaterinletDrainId						TINYINT
				,	@WaterFlowId							SMALLINT
				,	@WaterLevel								NUMERIC(8, 2)
				,	@TemperatureControlByPMR				BIT
				,	@UsePressExtractWater					BIT
				,	@SplitCompartment						BIT
				,	@RecycledWaterInlet						BIT
				,	@Steam									BIT
				,	@IterationPoint							BIT

				,	@EquipmentAssociation					[TCD].ControllerEquipment			READONLY

				,	@UserId									INT
				--	Adding these 3 param as part of re-factoring for integration with Synch/Configurator
				,	@OutputTunnelCompartmentId				INT			=			NULL	OUTPUT
				,	@LastModifiedTimestampAtCentral			DATETIME	=			NULL		--Nullable for local call; Synch/Central call will have to pass this -
																								--else, it will be treated as a local call
				,	@OutputLastModifiedTimestampAtLocal		DATETIME	=			NULL	OUTPUT

AS
BEGIN

SET	NOCOUNT	ON


DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''

	,	@ControllerId					INT				=			NULL
	,	@NumberOfComp					TINYINT			=			NULL
	,	@TunnelCompartmentId			SMALLINT		=			NULL

	,	@CurrentUTCTime					DATETIME				=			GETUTCDATE()
--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
SET		@OutputLastModifiedTimestampAtLocal						=			@CurrentUTCTime
SET		@OutputTunnelCompartmentId								=			ISNULL(@OutputTunnelCompartmentId, NULL)			--SQLEnlight

DECLARE
		@OutputList						AS	TABLE		(
		TunnelCompartmentId					INT
	,	LastModifiedTimestamp				DATETIME
	)

--Get the ControllerId for the Tunnel...
SELECT	@ControllerId					=			ISNULL(MS.ControllerId, -1)
	,	@NumberOfComp					=			ISNULL(MS.NumberOfComp, -1)
FROM	[TCD].MachineSetup					MS
JOIN	[TCD].ConduitController				CC												--join on valid controller
	ON	MS.ControllerId					=			CC.ControllerId
	AND	MS.EcoalabAccountNumber			=			CC.EcoalabAccountNumber
WHERE	MS.EcoalabAccountNumber			=			@EcoLabAccountNumber
	AND	MS.WasherId						=			@TunnelId
	AND	MS.IsTunnel						=			'TRUE'
	AND	MS.IsDeleted					=			'FALSE'
	AND	CC.IsDeleted					=			'FALSE'

--if we didn't get a valid Controller, error-out
IF	(@ControllerId	=	-1)
	BEGIN
				SET		@ErrorId						=			51020
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Could not determine the Controller for the specified tunnel.'
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
	END


--CompartmentNumber
IF	(@CompartmentNumber	>	@NumberOfComp)
	BEGIN
				SET		@ErrorId						=			51021
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Invalid Compartment Number specified for the tunnel.'
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
	END


--Add, if not already defined
IF	NOT	EXISTS	(	SELECT	1	FROM	[TCD].TunnelCompartment	WHERE	WasherId	=	@TunnelId	AND	CompartmentNumber	=	@CompartmentNumber	)
	BEGIN
			BEGIN	TRAN

			BEGIN	TRY
						INSERT	[TCD].TunnelCompartment	(
								WasherId					,EcoLabAccountNumber	,CompartmentNumber	,WashStepId				,WaterInletDrainId	,WaterFlowId			,WaterLevel
							,	TemperatureControlByPMR		,UsePressExtractWater	,SplitCompartment	,RecycledWaterInlet		,Steam				,IterationPoint			,LastModifiedByUserId
						--**	Adding a part of integration with Synch./Central	-->
						,	LastModifiedTime, MyServiceLastSynchTime
						)
						OUTPUT	inserted.TunnelCompartmentId			AS			TunnelCompartmentId
							,	inserted.LastModifiedTime				AS			LastModifiedTime
						INTO	@OutputList	(
								TunnelCompartmentId
							,	LastModifiedTimestamp
							)
						--**	<--
						VALUES	(@TunnelId					,@EcoLabAccountNumber	,@CompartmentNumber	,@WashStepId			,@WaterinletDrainId	,@WaterFlowId	,@WaterLevel
							,	@TemperatureControlByPMR	,@UsePressExtractWater	,@SplitCompartment	,@RecycledWaterInlet	,@Steam				,@IterationPoint,@UserId
							--Synch./Central integration additions
							,	@CurrentUTCTime	, @CurrentUTCTime
							)

						--get the TCId of the newly generated record
						SET	@TunnelCompartmentId	=	SCOPE_IDENTITY()
			END	TRY
			BEGIN	CATCH
						SET	@ErrorId				=	ERROR_NUMBER()
						SET	@ErrorMessage			=	ERROR_MESSAGE()

						IF	(@@TRANCOUNT	>	0)
							BEGIN
								ROLLBACK
							END

						SET		@ErrorMessage		=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + ISNULL(@ErrorMessage,	N': Error occurred saving Compartment details .')
						RAISERROR	(@ErrorMessage, 16, 1)
						SET	@ReturnValue	=	-1
						RETURN	(@ReturnValue)
			END	CATCH

			--save Equipment association
			IF	EXISTS	(SELECT	1	FROM	@EquipmentAssociation)
				BEGIN
					BEGIN	TRY
								INSERT	[TCD].TunnelCompartmentEquipmentMapping	(
										EcoLabAccountNumber	,TunnelCompartmentId	,ControllerEquipmentSetupId	,Is_Deleted	,LastModifiedByUserId , MyServiceCmpmtDsgDvcguid	)
								SELECT	@EcoLabAccountNumber					AS			EcoLabAccountNumber
									,	@TunnelCompartmentId					AS			TunnelCompartmentId
									,	A.ControllerEquipmentSetupId			AS			ControllerEquipmentSetupId
									,	'FALSE'									AS			Is_Deleted
									,	@UserId									AS			LastModifiedByUserId
									,	A.MyServiceCmpmtDsgDvcguid				As			MyServiceCmpmtDsgDvcguid
								FROM	@EquipmentAssociation					A
								WHERE	A.DeleteFlag							=			'FALSE'

								--commit the tran now and exit module
								COMMIT

								SELECT	TOP	1
										@OutputTunnelCompartmentId			=			O.TunnelCompartmentId
								FROM	@OutputList							O

								RETURN	0
					END	TRY
					BEGIN	CATCH
								SET	@ErrorId				=	ERROR_NUMBER()
								SET	@ErrorMessage			=	ERROR_MESSAGE()

								IF	(@@TRANCOUNT	>	0)
									BEGIN
										ROLLBACK
									END

								SET		@ErrorMessage		=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + ISNULL(@ErrorMessage,	N': Error occurred saving Compartment-Equipment details .')
								RAISERROR	(@ErrorMessage, 16, 1)
								SET	@ReturnValue	=	-1
								RETURN	(@ReturnValue)
					END	CATCH
				END
			ELSE	--If no Equipment association to be saved, commit the INSERT above
				BEGIN
					IF	(@@TRANCOUNT	>	0)
						BEGIN
							COMMIT

							SELECT	TOP	1
									@OutputTunnelCompartmentId			=			O.TunnelCompartmentId
							FROM	@OutputList							O

							RETURN	0
						END
				END

	END
ELSE		--Update already defined Compartment details
	BEGIN
			--Get the TCId first...
			SELECT	@TunnelCompartmentId					=			TC.TunnelCompartmentId
			FROM	[TCD].TunnelCompartment					TC
			WHERE	TC.EcoLabAccountNumber					=			@EcoLabAccountNumber
				AND	TC.WasherId								=			@TunnelId
				AND	TC.CompartmentNumber					=			@CompartmentNumber

			IF	(@TunnelCompartmentId	IS	NULL)
				BEGIN
						SET		@ErrorId					=			51022
						SET		@ErrorMessage				=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Could not determine the Compartment provided for the specified tunnel.'
						RAISERROR	(@ErrorMessage, 16, 1)
						SET	@ReturnValue	=	-1
						RETURN	(@ReturnValue)
				END


			--If the call is not local, check that the LastModifiedTime matches with the central
			IF	(
					@LastModifiedTimestampAtCentral			IS NOT	NULL
				AND	NOT	EXISTS	(	SELECT	1
									FROM	TCD.[TunnelCompartment]	TC
									WHERE	TC.EcolabAccountNumber	=	@EcolabAccountNumber
										AND	TC.TunnelCompartmentId	=	@TunnelCompartmentId
										AND	TC.LastModifiedTime		=	@LastModifiedTimestampAtCentral
								)
				)
				BEGIN
						SET			@ErrorId						=	60000
						SET			@ErrorMessage					=	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
						RAISERROR	(@ErrorMessage, 16, 1)
						SET			@ReturnValue					=	-1
						RETURN		(@ReturnValue)
				END
				
			--Proceed, since it's either a local call or Synch. call with synch. time matching
			BEGIN	TRAN

			BEGIN	TRY
						UPDATE	TC
							SET	TC.WashStepId					=			@WashStepId
							,	TC.WaterInletDrainId			=			@WaterinletDrainId
							,	TC.WaterFlowId					=			@WaterFlowId
							,	TC.WaterLevel					=			@WaterLevel
							,	TC.TemperatureControlByPMR		=			@TemperatureControlByPMR
							,	TC.UsePressExtractWater			=			@UsePressExtractWater
							,	TC.SplitCompartment				=			@SplitCompartment
							,	TC.RecycledWaterInlet			=			@RecycledWaterInlet
							,	TC.Steam						=			@Steam
							,	TC.IterationPoint				=			@IterationPoint
							,	TC.LastModifiedByUserId			=			@UserId
						--**	Adding a part of integration with Synch./Central	-->
							,	TC.LastModifiedTime				=			@CurrentUTCTime
							,	TC.MyServiceLastSynchTime		=			@CurrentUTCTime
						OUTPUT	inserted.TunnelCompartmentId	AS			TunnelCompartmentId
							,	inserted.LastModifiedTime		AS			LastModifiedTime
						INTO	@OutputList	(
								TunnelCompartmentId
							,	LastModifiedTimestamp
							)
						--**	<--
						FROM	[TCD].TunnelCompartment			TC
            WHERE	TC.WasherId						=			@TunnelId
            AND	TC.CompartmentNumber			=			@CompartmentNumber
            END	TRY
            BEGIN	CATCH
            SET	@ErrorId						=			ERROR_NUMBER()
            SET	@ErrorMessage					=			ERROR_MESSAGE()

            IF	(@@TRANCOUNT	>	0)
            BEGIN
            ROLLBACK
            END

            SET		@ErrorMessage				=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + ISNULL(@ErrorMessage,	N': Error occurred saving Compartment details .')
            RAISERROR	(@ErrorMessage, 16, 1)
            SET	@ReturnValue	=	-1
            RETURN	(@ReturnValue)
            END	CATCH


            --save Equipment association
            IF	EXISTS	(SELECT	1	FROM	@EquipmentAssociation)
            BEGIN
            BEGIN	TRY
            --first soft-delete...
            --UPDATE	TCEM
            --	SET	TCEM.Is_Deleted							=			'TRUE'
            --	,	TCEM.LastModifiedByUserId				=			@UserId
            --FROM	[TCD].TunnelCompartmentEquipmentMapping		TCEM
            --JOIN	@EquipmentAssociation					EA
            --	ON	TCEM.ControllerEquipmentSetupId			=			EA.ControllerEquipmentSetupId
            --WHERE	TCEM.TunnelCompartmentId				=			@TunnelCompartmentId
            --	AND	TCEM.Is_Deleted							=			'FALSE'
            --	AND	EA.DeleteFlag							=			'TRUE'

            --INSERT	[TCD].TunnelCompartmentEquipmentMapping	(
            --		EcoLabAccountNumber	,TunnelCompartmentId	,ControllerEquipmentSetupId	,Is_Deleted	,LastModifiedByUserId	)
            --SELECT	@EcoLabAccountNumber					AS			EcoLabAccountNumber
            --	,	@TunnelCompartmentId					AS			TunnelCompartmentId
            --	,	EA.ControllerEquipmentSetupId			AS			ControllerEquipmentSetupId
            --	,	'FALSE'									AS			Is_Deleted
            --	,	@UserId									AS			LastModifiedByUserId
            --FROM	@EquipmentAssociation					EA
            --LEFT JOIN
            --		[TCD].TunnelCompartmentEquipmentMapping		TCEM
            --	ON	TCEM.TunnelCompartmentId				=			@TunnelCompartmentId
            --	AND	TCEM.Is_Deleted							=			'FALSE'
            --	AND	TCEM.ControllerEquipmentSetupId			=			EA.ControllerEquipmentSetupId
            --WHERE	EA.DeleteFlag							=			'FALSE'
            --	AND	TCEM.ControllerEquipmentSetupId			IS			NULL


            --commit the tran now and exit module

            ;
            MERGE	[TCD].TunnelCompartmentEquipmentMapping		AS			TARGET
            USING	@EquipmentAssociation						AS			SOURCE
            ON	TARGET.ControllerEquipmentSetupId			=			SOURCE.ControllerEquipmentSetupId
            AND	TARGET.TunnelCompartmentId					=			@TunnelCompartmentId
            AND	TARGET.EcolabAccountNumber					=			@EcolabAccountNumber
            WHEN	MATCHED	THEN
            UPDATE
            SET	TARGET.Is_Deleted					=			SOURCE.DeleteFlag,
				Target.MyServiceCmpmtDsgDvcguid		=			 SOURCE.MyServiceCmpmtDsgDvcguid
            WHEN	NOT MATCHED	BY	TARGET	THEN
            INSERT	(EcolabAccountNumber	,TunnelCompartmentId	,ControllerEquipmentSetupId			,Is_Deleted	,LastModifiedByUserId	,MyServiceCmpmtDsgDvcguid		)
            VALUES	(@EcolabAccountNumber	,@TunnelCompartmentId	,SOURCE.ControllerEquipmentSetupId	,'FALSE'	,@UserId		, SOURCE.MyServiceCmpmtDsgDvcguid				)
            ;


            UPDATE tdpm
            SET tdpm.Quantity = 0
            FROM TCD.TunnelDosingSetup tds
            INNER JOIN TCD.TunnelDosingProductMapping tdpm
            ON tdpm.TunnelDosingSetupId = tds.TunnelDosingSetupId
            AND tdpm.EcoLabAccountNumber = tds.EcolabAccountNumber
            INNER JOIN TCD.TunnelProgramSetup tps
            ON tps.TunnelProgramSetupId = tds.TunnelProgramSetupId
            AND tps.EcolabAccountNumber = tds.EcolabAccountNumber
            AND tps.WasherGroupId = tds.GroupId
            INNER JOIN TCD.WasherGroup wg
            ON wg.WasherGroupId = TPS.WasherGroupId
            AND wg.EcolabAccountNumber = TPS.EcolabAccountNumber
            INNER JOIN TCD.MachineSetup ms
            ON ms.GroupId = wg.WasherGroupId
            AND ms.EcoalabAccountNumber = wg.EcolabAccountNumber
            INNER JOIN TCD.TunnelCompartment tc
            ON tc.EcoLabAccountNumber = ms.EcoalabAccountNumber
            AND tc.WasherId = ms.WasherId
            INNER JOIN TCD.TunnelCompartmentEquipmentMapping tcem
            ON tcem.EcoLabAccountNumber = tc.EcoLabAccountNumber
            AND tcem.ControllerEquipmentSetupId = tdpm.ControllerEquipmentSetupId
            AND tc.TunnelCompartmentId = tcem.TunnelCompartmentId
            AND tcem.Is_Deleted = 'True'
            WHERE ms.WasherId = @TunnelId
            AND wg.EcolabAccountNumber = @EcoLabAccountNumber

            COMMIT

            SELECT	TOP	1
            @OutputTunnelCompartmentId			=			O.TunnelCompartmentId
            FROM	@OutputList							O

            RETURN	0
            END	TRY
            BEGIN	CATCH
            SET	@ErrorId				=	ERROR_NUMBER()
            SET	@ErrorMessage			=	ERROR_MESSAGE()

            IF	(@@TRANCOUNT	>	0)
            BEGIN
            ROLLBACK
            END

            SET		@ErrorMessage		=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + ISNULL(@ErrorMessage,	N': Error occurred saving Compartment-Equipment details .')
            RAISERROR	(@ErrorMessage, 16, 1)
            SET	@ReturnValue	=	-1
            RETURN	(@ReturnValue)
            END	CATCH
            END
            ELSE	--If no Equipment association to be saved, commit the INSERT above
            BEGIN
            IF	(@@TRANCOUNT	>	0)
            BEGIN
            COMMIT

            SELECT	TOP	1
            @OutputTunnelCompartmentId			=			O.TunnelCompartmentId
            FROM	@OutputList							O

            RETURN	0
            END
            END
            END



            RETURN	(@ReturnValue)

            END
            
		  
GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetCompartmentDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetCompartmentDetails
	END
GO
CREATE PROCEDURE [TCD].[GetCompartmentDetails] @EcoLabAccountNumber NVARCHAR(25)
 ,@WasherGroupId INT
 ,@TunnelId INT
 ,@CompartmentNumber TINYINT = 1
 ,@IsDelete BIT = 'False'
AS
BEGIN
 SET NOCOUNT ON

 DECLARE @RegionId INT,
 @PlantId int ,
 @ControllerModelId int

 SELECT @RegionId = RegionId, @PlantId = PlantId
   FROM TCD.Plant
   WHERE EcolabAccountNumber = @EcoLabAccountNumber
    AND Is_Deleted = 0

 DECLARE @ReturnValue INT = 0
  ,@ErrorId INT = 0
  ,@ErrorMessage NVARCHAR(4000) = N''
  ,@ControllerId INT = NULL
  ,@NumberOfComp TINYINT = NULL
  ,@DosagePoint BIT = NULL

 SET @WasherGroupId = ISNULL(@WasherGroupId, NULL) --SQLEnlight SA0029

 --Get ControllerId, Number
 SELECT @ControllerId = ISNULL(MS.ControllerId, - 1)
  ,@NumberOfComp = ISNULL(MS.NumberOfComp, - 1)
 FROM [TCD].MachineSetup MS
 INNER JOIN [TCD].ConduitController CC ON MS.ControllerId = CC.ControllerId
  AND MS.EcoalabAccountNumber = CC.EcoalabAccountNumber
 WHERE MS.EcoalabAccountNumber = @EcoLabAccountNumber
  AND MS.WasherId = @TunnelId
  AND MS.IsTunnel = 'TRUE'
  AND MS.IsDeleted = 'FALSE'
  AND CC.IsDeleted = 'FALSE'

  SELECT @ControllerModelId = cc.ControllerModelId from tcd.ConduitController cc WHERE cc.ControllerId = @ControllerId

 --if we didn't get a valid Controller, error-out
 IF (@ControllerId = - 1)
 BEGIN
  SET @ErrorId = 51020
  SET @ErrorMessage = N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Could not determine the Controller for the specified tunnel.'

  RAISERROR (
    @ErrorMessage
    ,16
    ,1
    )

  SET @ReturnValue = - 1

  RETURN (@ReturnValue)
 END

 --CompartmentNumber
 IF (@CompartmentNumber > @NumberOfComp)
 BEGIN
  SET @ErrorId = 51021
  SET @ErrorMessage = N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Invalid Compartment Number specified for the tunnel.'

  RAISERROR (
    @ErrorMessage
    ,16
    ,1
    )

  SET @ReturnValue = - 1

  RETURN (@ReturnValue)
 END

 --Select the details of the compartment...
 ;WITH CTE_ComptNumbersForTunnel
AS (
    SELECT MS.GroupId, 'ALL' AS CompartmentNumber, MS.NumberOfComp
    FROM TCD.MachineSetup AS MS
    WHERE MS.IsTunnel = 1 AND MS.IsDeleted = 0
)

, CTE_ComptNumbersforEachWasherGroup 
AS (
    SELECT  C.GroupId
            , TunnelCompNumber = 1
            , CompartmentNumber
    , NumberOfComp
    FROM    CTE_ComptNumbersForTunnel C
    UNION ALL 
    SELECT  GroupId
            , TunnelCompNumber = TunnelCompNumber + 1
            , CompartmentNumber
    , NumberOfComp
    FROM    CTE_ComptNumbersforEachWasherGroup
    WHERE   NumberOfComp > TunnelCompNumber
)
, CTE_SensorsForEachCompartment 
AS (
    SELECT CASE 
        WHEN S.MachineCompartment IS NULL AND ISNULL(S.IsPress,0) = 0  
        THEN 'ALL'
        WHEN 
  --( SELECT DISTINCT Istunnel
      -- FROM [TCD].machinesetup M
      -- WHERE M.groupId = S.GroupId ) = 1 
       --AND 
    S.MachineCompartment IS NOT NULL 
       --AND ISNULL(S.IsPress,0) = 0 
        THEN CAST(S.Machinecompartment AS VARCHAR)
    END AS CompartmentNumber
    , CASE WHEN STM.Name = 'Temperature' THEN '1' ELSE '0' END AS Temperature
    , CASE WHEN STM.Name = 'pH' THEN '1' ELSE '0' END AS pH
    , CASE WHEN STM.Name = 'Conductivity' THEN '1' ELSE '0' END AS Conductivity
    , CASE WHEN STM.Name = 'Redox' THEN '1' ELSE '0' END AS Redox
    , S.GroupId
    , S.ControllerID
    FROM TCD.Sensor AS S 
    LEFT JOIN TCD.SensorTypeMaster AS STM ON S.SensorType = STM.ResourceId
 WHERE S.Is_Deleted = 0
    )
, CTE_TunnelSensors
AS (
    SELECT  Sensors.GroupId
    , Sensors.ControllerID
    , TunnelCompNumberForWG.TunnelCompNumber AS CompartmentNumber
    , MAX(Sensors.pH) AS pH
    , MAX(Sensors.Temperature) AS Temperature
    , MAX(Sensors.Conductivity) AS Conductivity
    , MAX(Sensors.Redox) AS Redox
    FROM CTE_SensorsForEachCompartment AS Sensors
    LEFT JOIN CTE_ComptNumbersforEachWasherGroup AS TunnelCompNumberForWG
    ON Sensors.GroupId = TunnelCompNumberForWG.GroupId 
    AND Sensors.CompartmentNumber = CASE WHEN Sensors.CompartmentNumber = 'ALL' 
            THEN TunnelCompNumberForWG.CompartmentNumber
         WHEN Sensors.CompartmentNumber <> 'ALL' 
            THEN CAST(TunnelCompNumberForWG.TunnelCompNumber AS VARCHAR)
        END
 GROUP BY Sensors.GroupId, Sensors.ControllerID, TunnelCompNumberForWG.TunnelCompNumber
 )
 SELECT TC.WashStepId AS WashStepId
  ,TC.WaterInletDrainId AS WaterInletDrainId
  ,TC.WaterFlowId AS WaterFlowId
  ,TC.WaterLevel AS WaterLevel
  ,TC.TemperatureControlByPMR AS TemperatureControlByPMR
  ,TC.UsePressExtractWater AS UsePressExtractWater
  ,TC.SplitCompartment AS SplitCompartment
  ,TC.RecycledWaterInlet AS RecycledWaterInlet
  ,TC.Steam AS Steam
  ,@CompartmentNumber AS CompartmentNumber
  ,TC.IterationPoint AS IterationPoint
  --Adding cols. for integration with Synch./Central
  ,TC.LastModifiedTime AS LastModifiedTime
  ,TC.LastSyncTime AS LastSyncTime
  ,TC.TunnelCompartmentId AS TunnelCompartmentId
  ,TC.WasherId AS WasherId
  ,TC.EcoLabAccountNumber AS EcoLabAccountNumber
  ,W.MyServiceCustMchGuid AS MyServiceWasherId
  ,TWIDL.MyServicePropId AS MyServiceDrainLookupId
  ,TWFT.MyServicePropId AS MyServiceWaterFlowTypeId
  ,CAST(ISNULL(CTE.Temperature, 0) as bit) AS Temperature
  ,CAST(ISNULL(CTE.pH, 0) as bit) AS PhProbe
  ,CAST(ISNULL(CTE.Conductivity, 0) as bit) AS Conductivity
  ,CAST(ISNULL(CTE.Redox, 0) as bit) AS Redox
 FROM [TCD].Washer W
 INNER JOIN [TCD].MachineSetup MS ON W.WasherId = MS.WasherId
  AND W.EcoLabAccountNumber = MS.EcoalabAccountNumber
 INNER JOIN [TCD].TunnelCompartment TC ON W.WasherId = TC.WasherId
  AND W.EcoLabAccountNumber = TC.EcoLabAccountNumber
 INNER JOIN [TCD].TunnelWaterInletDrainLookup TWIDL ON TC.WaterInletDrainId = TWIDL.TunnelWaterInletDrainLookupId
 INNER JOIN [TCD].TunnelWaterFlowType TWFT ON TC.WaterFlowId = TWFT.TunnelWaterFlowTypeId
 LEFT JOIN CTE_TunnelSensors CTE ON CTE.GroupId = MS.GroupId AND CTE.CompartmentNumber = @CompartmentNumber
 WHERE W.EcoLabAccountNumber = @EcoLabAccountNumber
  AND W.WasherId = @TunnelId
  AND MS.IsTunnel = 'TRUE'
  AND (
   W.Is_Deleted = 'FALSE'
   OR W.Is_Deleted = @IsDelete
   )
  AND (
   MS.IsDeleted = 'FALSE'
   OR MS.IsDeleted = @IsDelete
   )
  AND TC.CompartmentNumber = @CompartmentNumber
  
 --select the equipment association...
 IF (@RegionId = 1)
 BEGIN
 IF(@ControllerModelId = 7)
 BEGIN
 IF EXISTS (SELECT 1 FROM TCD.TunnelCompartment tc WHERE tc.WasherId = @TunnelId AND tc.CompartmentNumber = @CompartmentNumber AND tc.EcoLabAccountNumber = @EcoLabAccountNumber)
 BEGIN
  SELECT ISNULL(TCEM.ControllerEquipmentSetupId, tcevm.ControllerEquipmentSetupID)       AS   ControllerEquipmentSetupId
    ,CES.ControllerEquipmentId          AS   ControllerEquipmentId
    ,CES.ControllerEquipmentTypeId          AS   ControllerEquipmentTypeId
    ,ISNULL(NULLIF(PM2.EnvisionDisplayName,''), PM2.NAME)     AS   ProductName
    ,TCEM.MyServiceCmpmtDsgDvcguid         AS   MyServiceCmpmtDsgDvcguid
    ,ISNULL(TCEM.Is_Deleted, 0)           AS   IsDelete
    ,0              AS   FormulaAssociated 
    FROM TCD.TunnelCompartmentEquipmentValveMapping tcevm
    INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.ControllerEquipmentSetupId = tcevm.ControllerEquipmentSetupId 
    AND tcevm.PlantID = @PlantId
    INNER JOIN TCD.TunnelCompartment tc ON  tc.CompartmentNumber = tcevm.CompartmentNumber AND tc.EcoLabAccountNumber = ces.EcoLabAccountNumber
    LEFT JOIN TCD.TunnelCompartmentEquipmentMapping tcem ON tcevm.ControllerEquipmentSetupID = tcem.ControllerEquipmentSetupId
    AND tc.TunnelCompartmentId = tcem.TunnelCompartmentId AND (TCEM.Is_Deleted = 'FALSE' OR TCEM.Is_Deleted = @IsDelete)
    AND tcem.EcoLabAccountNumber = tc.EcoLabAccountNumber AND tcem.EcoLabAccountNumber = ces.EcoLabAccountNumber
    INNER JOIN TCD.MachineSetup ms ON ms.WasherId = tc.WasherId AND ms.ControllerId = ces.ControllerId AND ms.EcoalabAccountNumber = tc.EcoLabAccountNumber
    AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber AND ms.MachineInternalId = tcevm.TunnelNumber
    INNER JOIN TCD.ProductdataMapping pm ON pm.EcolabAccountNumber = ces.EcoLabAccountNumber AND pm.ProductID = ces.ProductId 
    INNER JOIN TCD.ProductMaster pm2 ON pm2.ProductId = pm.ProductID
    WHERE ms.WasherId = @TunnelId AND tc.CompartmentNumber = @CompartmentNumber AND ms.EcoalabAccountNumber = @EcoLabAccountNumber
    AND MS.IsTunnel = 'TRUE' AND (MS.IsDeleted = 'FALSE' OR MS.IsDeleted = @IsDelete)
    AND (PM.Is_Deleted = 'FALSE' OR PM.Is_Deleted = @IsDelete)
END
ELSE
BEGIN
	SELECT DISTINCT tcevm.ControllerEquipmentSetupID       AS   ControllerEquipmentSetupId
    ,CES.ControllerEquipmentId          AS   ControllerEquipmentId
    ,CES.ControllerEquipmentTypeId          AS   ControllerEquipmentTypeId
    ,ISNULL(NULLIF(PM2.EnvisionDisplayName,''), PM2.NAME)     AS   ProductName
    ,NULL         AS   MyServiceCmpmtDsgDvcguid
    ,0           AS   IsDelete
    ,0              AS   FormulaAssociated 
	FROM TCD.TunnelCompartmentEquipmentValveMapping tcevm
	INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.ControllerEquipmentSetupId = tcevm.ControllerEquipmentSetupID
	INNER JOIN TCD.MachineSetup ms ON ms.ControllerId = ces.ControllerId AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber AND ms.MachineInternalId = tcevm.TunnelNumber
	INNER JOIN TCD.ProductdataMapping pm ON pm.EcolabAccountNumber = ces.EcoLabAccountNumber AND pm.ProductID = ces.ProductId
	INNER JOIN TCD.ProductMaster pm2 ON pm2.ProductId = pm.ProductId
	WHERE (PM.Is_Deleted = 'FALSE' OR PM.Is_Deleted = 0)
	AND tcevm.CompartmentNumber = @CompartmentNumber
    AND tcevm.PlantID = @PlantId
	AND ms.WasherId = @TunnelId  AND ms.EcoalabAccountNumber =  @EcoLabAccountNumber
    AND MS.IsTunnel = 'TRUE' AND (MS.IsDeleted = 'FALSE' OR MS.IsDeleted = 0) 
END
END
 ELSE
 BEGIN
 SELECT TCEM.ControllerEquipmentSetupId AS ControllerEquipmentSetupId
   ,CES.ControllerEquipmentId AS ControllerEquipmentId
   ,CES.ControllerEquipmentTypeId AS ControllerEquipmentTypeId
   ,ISNULL(NULLIF(PM.EnvisionDisplayName,''), PM.NAME) AS ProductName
   ,TCEM.MyServiceCmpmtDsgDvcguid AS MyServiceCmpmtDsgDvcguid
   ,TCEM.Is_Deleted AS IsDelete
   ,(
    SELECT Count(*)
    FROM [TCD].TunnelDosingSetup tds
    INNER JOIN [TCD].TunnelDosingProductMapping TDPM ON TDPM.GroupId = TDS.GroupId
    INNER JOIN [TCD].TunnelProgramSetup tps ON tps.TunnelProgramSetupId = tds.TunnelProgramSetupId
     AND tps.Is_Deleted = 'false'
    WHERE TDPM.ControllerEquipmentSetupId = TCEM.ControllerEquipmentSetupId
     AND TDPM.CompartmentNumber = TDS.CompartmentNumber
     AND TDPM.GroupId = MS.GroupId
    ) AS FormulaAssociated
  FROM [TCD].Washer W
  INNER JOIN [TCD].MachineSetup MS ON W.WasherId = MS.WasherId
   AND W.EcoLabAccountNumber = MS.EcoalabAccountNumber
  INNER JOIN [TCD].TunnelCompartment TC ON W.WasherId = TC.WasherId
   AND W.EcoLabAccountNumber = TC.EcoLabAccountNumber
  INNER JOIN [TCD].TunnelCompartmentEquipmentMapping TCEM ON TC.TunnelCompartmentId = TCEM.TunnelCompartmentId
   AND TC.EcoLabAccountNumber = TCEM.EcoLabAccountNumber
  INNER JOIN [TCD].ControllerEquipmentSetup CES ON TCEM.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId
   AND TCEM.EcoLabAccountNumber = CES.EcoLabAccountNumber
   AND CES.ControllerId = MS.ControllerId
  INNER JOIN [TCD].ProductMaster PM ON CES.ProductId = PM.ProductId
  WHERE W.EcoLabAccountNumber = @EcoLabAccountNumber
   AND W.WasherId = @TunnelId
   AND MS.IsTunnel = 'TRUE'
   AND (
    W.Is_Deleted = 'FALSE'
    OR W.Is_Deleted = @IsDelete
    )
   AND (
    MS.IsDeleted = 'FALSE'
    OR MS.IsDeleted = @IsDelete
    )
   AND TC.CompartmentNumber = @CompartmentNumber
   AND (
    TCEM.Is_Deleted = 'FALSE'
    OR TCEM.Is_Deleted = @IsDelete
    )
   AND (
    PM.Is_Deleted = 'FALSE'
    OR PM.Is_Deleted = @IsDelete
    )
 END

  
 END
 ELSE IF (@RegionId = 2)
 BEGIN
   IF EXISTS (SELECT 1 FROM TCD.TunnelCompartment tc WHERE tc.WasherId = @TunnelId AND tc.CompartmentNumber = @CompartmentNumber AND tc.EcoLabAccountNumber = @EcoLabAccountNumber)
 BEGIN
  SELECT DISTINCT ISNULL(TCEM.ControllerEquipmentSetupId, tcevm.ControllerEquipmentSetupID)       AS   ControllerEquipmentSetupId
    ,CES.ControllerEquipmentId          AS   ControllerEquipmentId
    ,CES.ControllerEquipmentTypeId          AS   ControllerEquipmentTypeId
    ,ISNULL(NULLIF(PM2.EnvisionDisplayName,''), PM2.NAME)     AS   ProductName
    ,TCEM.MyServiceCmpmtDsgDvcguid         AS   MyServiceCmpmtDsgDvcguid
    ,ISNULL(TCEM.Is_Deleted, 0)           AS   IsDelete
    ,0              AS   FormulaAssociated 
    FROM TCD.TunnelCompartmentEquipmentValveMapping tcevm
    INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.ControllerEquipmentSetupId = tcevm.ControllerEquipmentSetupId 
    AND tcevm.PlantID = @PlantId
    INNER JOIN TCD.TunnelCompartment tc ON  tc.CompartmentNumber = tcevm.CompartmentNumber AND tc.EcoLabAccountNumber = ces.EcoLabAccountNumber
    LEFT JOIN TCD.TunnelCompartmentEquipmentMapping tcem ON tcevm.ControllerEquipmentSetupID = tcem.ControllerEquipmentSetupId
    AND tc.TunnelCompartmentId = tcem.TunnelCompartmentId AND (TCEM.Is_Deleted = 'FALSE' OR TCEM.Is_Deleted = @IsDelete)
    AND tcem.EcoLabAccountNumber = tc.EcoLabAccountNumber AND tcem.EcoLabAccountNumber = ces.EcoLabAccountNumber
    INNER JOIN TCD.MachineSetup ms ON ms.WasherId = tc.WasherId AND ms.ControllerId = ces.ControllerId AND ms.EcoalabAccountNumber = tc.EcoLabAccountNumber
    AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber AND ms.MachineInternalId = tcevm.TunnelNumber
    INNER JOIN TCD.ProductdataMapping pm ON pm.EcolabAccountNumber = ces.EcoLabAccountNumber AND pm.ProductID = ces.ProductId 
    INNER JOIN TCD.ProductMaster pm2 ON pm2.ProductId = pm.ProductID
    WHERE ms.WasherId = @TunnelId AND tc.CompartmentNumber = @CompartmentNumber AND ms.EcoalabAccountNumber = @EcoLabAccountNumber
    AND MS.IsTunnel = 'TRUE' AND (MS.IsDeleted = 'FALSE' OR MS.IsDeleted = @IsDelete)
    AND (PM.Is_Deleted = 'FALSE' OR PM.Is_Deleted = @IsDelete)
END
ELSE
BEGIN
	SELECT DISTINCT tcevm.ControllerEquipmentSetupID       AS   ControllerEquipmentSetupId
    ,CES.ControllerEquipmentId          AS   ControllerEquipmentId
    ,CES.ControllerEquipmentTypeId          AS   ControllerEquipmentTypeId
    ,ISNULL(NULLIF(PM2.EnvisionDisplayName,''), PM2.NAME)     AS   ProductName
    ,NULL         AS   MyServiceCmpmtDsgDvcguid
    ,0           AS   IsDelete
    ,0              AS   FormulaAssociated 
	FROM TCD.TunnelCompartmentEquipmentValveMapping tcevm
	INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.ControllerEquipmentSetupId = tcevm.ControllerEquipmentSetupID
	INNER JOIN TCD.MachineSetup ms ON ms.ControllerId = ces.ControllerId AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber AND ms.MachineInternalId = tcevm.TunnelNumber
	INNER JOIN TCD.ProductdataMapping pm ON pm.EcolabAccountNumber = ces.EcoLabAccountNumber AND pm.ProductID = ces.ProductId
	INNER JOIN TCD.ProductMaster pm2 ON pm2.ProductId = pm.ProductId
	WHERE (PM.Is_Deleted = 'FALSE' OR PM.Is_Deleted = 0)
	AND tcevm.CompartmentNumber = @CompartmentNumber
    AND tcevm.PlantID = @PlantId
	AND ms.WasherId = @TunnelId  AND ms.EcoalabAccountNumber =  @EcoLabAccountNumber
    AND MS.IsTunnel = 'TRUE' AND (MS.IsDeleted = 'FALSE' OR MS.IsDeleted = 0) 
END
 END

 SET NOCOUNT OFF
END
GO

IF not EXISTS(SELECT 1 FROM TCD.Field f WHERE f.Id = 262 AND f.Label = 'Controller Version')
  BEGIN
	 SET	IDENTITY_INSERT	TCD.Field	ON
	 INSERT INTO tcd.Field
	 (
		Id ,TypeId, Label,Min,Max,FieldGroupId,DataSourceId,IsMandatory,HelpText,HelpTextUrl,DataTypeId,DataCategoryId,CurrencyId,DisplayOrder,ResourceKey,DefaultValue,
		IsEditable,Name,HasFieldTag,DefaultFieldTag,ClassName
	 )
	 VALUES
	 (
		262, 10, N'Controller Version',NULL, NULL, NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,7,N'Controller_Version',N'1.3.0',1,NULL,NULL,NULL,NULL
	 )
	 SET	IDENTITY_INSERT	TCD.Field	OFF
  END
  GO

  IF not EXISTS(SELECT 1 FROM TCD.FieldGroupFieldMapping fgfm WHERE fgfm.FieldId = 262 AND fgfm.FieldGroupId = 4)
  BEGIN
	 SET	IDENTITY_INSERT	TCD.FieldGroupFieldMapping	ON
	 INSERT INTO tcd.FieldGroupFieldMapping
	 (
		Id	,FieldGroupId	,FieldId
	 )
	 VALUES
	 (
		349, 4, 262
	 )
	 SET	IDENTITY_INSERT	TCD.FieldGroupFieldMapping	OFF
  END
  GO

IF  EXISTS (SELECT
			*
		FROM sys.objects 
		WHERE object_id = OBJECT_ID(N'[TCD].[GetRewashFormulasByGroupId]') 
			AND type IN (N'P', N'PC'))
BEGIN
	DROP PROCEDURE [TCD].[GetRewashFormulasByGroupId]
END
GO
CREATE PROCEDURE [TCD].[GetRewashFormulasByGroupId] 
(
  @WasherGroupId INT,
  @EcolabAccountNumber NVARCHAR(25)
 )
AS 
  BEGIN    
  SET NOCOUNT ON  
  DECLARE   @WasherGroupTypeName   VARCHAR(50)   =   NULL,
		  @ControllerID	  int	    =	  NULL,
		  @ControllerModelID       INT      =  NULL

  --Determine the WasherGroup type - Conventional/Tunnel
 SELECT @WasherGroupTypeName   =   WGT.WasherGroupTypeName
 FROM  [TCD].WasherGroup       WG
 JOIN  [TCD].WasherGroupType   WGT
 ON   WG.WasherGroupTypeId    =   WGT.WasherGroupTypeId
 JOIN  [TCD].MachineGroup      GT
 ON    WG.WasherGroupId        =   GT.Id
 WHERE GT.EcolabAccountNumber  =   @EcoLabAccountNumber
 AND   WG.WasherGroupId    =   @WasherGroupId

 SELECT		@ControllerID			=		wg.ControllerId 
	FROM	TCD.WasherGroup			wg
	WHERE   wg.WasherGroupId		=		@WasherGroupId
AND			wg.EcolabAccountNumber	=		@EcoLabAccountNumber

SELECT  @ControllerModelID  =  cc.ControllerModelId
 FROM TCD.ConduitController cc
 WHERE cc.ControllerId   =  @ControllerID
AND   cc.EcoalabAccountNumber =  @EcoLabAccountNumber

IF @ControllerModelID = 7 -- MyControl
   BEGIN
    SET @WasherGroupId = NULL
   END

 
 IF ( @WasherGroupTypeName = 'Tunnel' )
    BEGIN
   SELECT DISTINCT pm.ProgramId
   ,    pm.Name
   FROM TCD.TunnelProgramSetup tps
   INNER JOIN TCD.ProgramMaster pm 
   ON pm.ProgramId = tps.ProgramId
   AND pm.EcolabAccountNumber = tps.EcolabAccountNumber
   WHERE tps.WasherGroupId = @WasherGroupId
   AND   tps.EcolabAccountNumber = @EcolabAccountNumber
   AND tps.Is_Deleted <> 1
    END
 ELSE
  BEGIN
     SELECT pm.ProgramId
     ,   pm.Name 
     FROM TCD.WasherProgramSetup wps
     INNER JOIN TCD.ProgramMaster pm 
     ON pm.ProgramId = wps.ProgramId 
     AND pm.EcolabAccountNumber = wps.EcolabAccountNumber
     WHERE (CASE WHEN @WasherGroupId IS NOT NULL 
        THEN wps.WasherGroupId
        ELSE wps.ControllerID
     END)         = (CASE WHEN @WasherGroupId IS NOT NULL 
                 THEN @WasherGroupId
                 ELSE @ControllerID
                 END)
     AND   wps.EcolabAccountNumber = @EcolabAccountNumber
	AND wps.Is_Deleted <> 1
  END
 
  SET NOCOUNT OFF
  END
GO

IF  EXISTS (SELECT
			*
		FROM sys.objects 
		WHERE object_id = OBJECT_ID(N'[TCD].[GetProductWasherGroups]') 
			AND type IN (N'P', N'PC'))
BEGIN
	DROP PROCEDURE [TCD].[GetProductWasherGroups]
END
GO
CREATE PROCEDURE [TCD].[GetProductWasherGroups]
 (
	@EcolabAccountNumber NVARCHAR(25)
 )
AS 
  BEGIN      
	 SET NOCOUNT ON
	 -- SELECT MG.Id,Mg.GroupDescription
  --    FROM   [TCD].MachineGroup MG
	 -- INNER JOIN [TCD].MachineSetup  AS MS  ON MG.Id = Ms.GroupId
	 -- INNER JOIN TCD.Washer w ON w.WasherId = Ms.WasherId
	 --  WHERE MG.GroupTypeId = 2 AND MG.EcolabAccountNumber = @EcolabAccountNumber AND MG.Is_Deleted <> 1 
	 --  AND MS.IsDeleted = 0     		
		--AND MS.ControllerId = 0
		--AND W.WasherMode = 0
		--GROUP BY MG.Id,Mg.GroupDescription
		 SELECT MG.Id,MG.GroupDescription FROM   [TCD].MachineGroup MG
      INNER JOIN TCD.WasherGroup WG ON MG.Id = WG.WasherGroupId       
      WHERE  MG.GroupTypeId = 2 AND MG.EcolabAccountNumber = @EcolabAccountNumber AND Is_Deleted <> 1 
  SET NOCOUNT OFF
  END
GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetTagManamenetDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetTagManamenetDetails
	END
GO
CREATE PROCEDURE [TCD].[GetTagManamenetDetails] 
@ControllerId INT,
@EcolabAccountNumber NVARCHAR(25),
@UserId INT

AS
BEGIN 
DECLARE @Active INT = 1,
    @TankModuleTypeId INT,
    @SensorModuleTypeId INT,
    @PumpModuleTypeId INT,
    @LangunageId INT,
    @SplChars VARCHAR(50)   = ' # -',
    @LocaliseValue VARCHAR(200),
    @FactorMultiplier INT,
    @TimeVolumeMultipler INT,
	@ControllerModelId int,
	@ControllerTypeId INT


SELECT @TankModuleTypeId=mty.ModuleTypeId FROM TCD.ModuleType mty WHERE mty.ModuleDescription='Tank'
SELECT @SensorModuleTypeId=mty.ModuleTypeId FROM TCD.ModuleType mty WHERE mty.ModuleDescription='Sensor'
SELECT @PumpModuleTypeId=mty.ModuleTypeId FROM TCD.ModuleType mty WHERE mty.ModuleDescription='Pumps/Valves'
SELECT @LangunageId=p.languageID FROM TCD.Plant p WHERE p.EcolabAccountNumber=@EcolabAccountNumber


 SELECT @TimeVolumeMultipler= CAST(csd.[Value] AS decimal(18,0)) FROM TCD.ControllerSetupData csd 
 INNER JOIN TCD.Field f ON f.Id = csd.FieldId 
 WHERE csd.FieldId IN(SELECT f2.Id FROM TCD.Field f2 WHERE f2.Label LIKE '%OZ/Second Multiplier%') 
    AND csd.ControllerId=@ControllerId 
    AND csd.EcolabAccountNumber=@EcolabAccountNumber 
	AND ISNUMERIC(csd.[Value]) = 1

 SELECT @FactorMultiplier= CAST(csd.[Value] AS decimal(18,0)) FROM TCD.ControllerSetupData csd 
 INNER JOIN TCD.Field f ON f.Id = csd.FieldId 
 WHERE csd.FieldId IN(SELECT f2.Id FROM TCD.Field f2 WHERE f2.Label LIKE '%Factors Multiplier%') 
    AND csd.ControllerId=@ControllerId
    AND csd.EcolabAccountNumber=@EcolabAccountNumber 
	AND ISNUMERIC(csd.[Value]) = 1

SELECT @ControllerModelId=ControllerModelId,@ControllerTypeId=ControllerTypeId FROM tcd.ConduitController cc WHERE ControllerId=@ControllerId


CREATE TABLE #tmpTagManagementDetails
(
  Id INT
 ,TagAddress VARCHAR(100)
 ,[Description] VARCHAR(1000)
 ,Value VARCHAR(500)
 ,LastModifiedTime DATETIME 
 ,ColName VARCHAR(500)
 ,DataType varchar(100)
 ,RowNumber decimal(3,2)
 ,OriginalColumnName varchar(100)
 ,EntityType varchar(100)
 ,TagType varchar(100)
 ,ControllerEquipmentSetupId varchar(100)
 ,SortingOrder varchar(100)
)


--SELECT @LocaleValue=rkv.[Value] FROM TCD.ResourceKeyMaster rkm 
--    INNER JOIN TCD.ResourceKeyValue rkv on rkv.ResourceId = rkm.ResourceId 
--where rkm.[Key] ='FIELD_'+ UPPER(@KeyValue) 
--  AND 
--rkv.languageID=ISNULL((SELECT um.LanguageId FROM TCD.UserMaster um WHERE um.UserId=@UserId),(SELECT p.LanguageId FROM TCD.Plant p WHERE p.EcolabAccountNumber=@EcolabAccountNumber)) 


--------------------------------------
-- StorageTanks---
--------------------------------------

INSERT INTO #tmpTagManagementDetails(Id, TagAddress,    [Description],    [Value],    LastModifiedTime,colName,DataType,RowNumber,OriginalColumnName
	,EntityType,TagType,ControllerEquipmentSetupId,SortingOrder)

----------------------------------------------------------------
-- Conventional-AND-Tunnel(AWEA, EOF, MODE to be displayed)-----
----------------------------------------------------------------
SELECT ms.WasherId, wt.TagAddress,Convert(varchar(100),w.PlantWasherNumber)+' : '+ms.MachineName,Convert(varchar(100), CONVERT(int, w.EndOfFormula)),w.LastModifiedTime ,'EndofFormulaNumber',tt.DataType,1,
'EndOfFormula' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType,ms.MachineInternalId as ControllerEquipmentSetupId, 2 as SortingOrder 
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId) AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_EOF' AND ms.IsTunnel IN (0,1)
UNION

SELECT ms.WasherId, wt.TagAddress,Convert(varchar(100),w.PlantWasherNumber)+' : '+ms.MachineName,Convert(varchar(100), CONVERT(int, (
SELECT	wmm.WasherModeNumber FROM TCD.WasherModeMapping wmm	
				INNER JOIN	tcd.ControllerModelControllerTypeMapping cmctm	ON cmctm.Id	=wmm.ControllerModelControllerTypeMappingId	 
				AND cmctm.ControllerModelId=@ControllerModelId	 
				AND cmctm.ControllerTypeId=@ControllerTypeId 
				AND wmm.WasherModeId=w.WasherMode))),w.LastModifiedTime ,'WasherMode',tt.DataType,1,'WasherMode' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType,ms.MachineInternalId as ControllerEquipmentSetupId, 5 as SortingOrder  
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_MODE' AND ms.IsTunnel IN (0,1)
UNION

SELECT ms.WasherId, wt.TagAddress,Convert(varchar(100),w.PlantWasherNumber)+' : '+ms.MachineName,Convert(varchar(100), CONVERT(int, w.AWEActive)),w.LastModifiedTime ,'AWEActive',tt.DataType,1
,'AWEActive' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType,ms.MachineInternalId as ControllerEquipmentSetupId , 1 as SortingOrder 
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_AWEA' AND ms.IsTunnel IN (0,1)
UNION

SELECT ms.WasherId, wt.TagAddress,Convert(varchar(100),w.PlantWasherNumber)+' : '+ms.MachineName,Convert(varchar(100), CONVERT(int, w.HoldDelay)),w.LastModifiedTime ,'HoldDelay',tt.DataType,1
,'HoldDelay' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType, ms.MachineInternalId as ControllerEquipmentSetupId , 3 as SortingOrder

FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId  AND wt.Active=@Active  AND wt.TagType='Tag_HOLDD' AND ms.IsTunnel=0 
UNION

SELECT ms.WasherId, wt.TagAddress,Convert(varchar(100),w.PlantWasherNumber)+' : '+ms.MachineName,Convert(varchar(100), CONVERT(int, w.WaterFlushTime)),w.LastModifiedTime , 'WaterFlushTime' ,tt.DataType,1
,'WaterFlushTime' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType, ms.MachineInternalId as ControllerEquipmentSetupId, 6 as SortingOrder  
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_FLSHT' AND ms.IsTunnel=0
UNION

SELECT ms.WasherId, wt.TagAddress,Convert(varchar(100),w.PlantWasherNumber)+' : '+ms.MachineName,Convert(varchar(100), CONVERT(int, w.RatioDosingActive)),w.LastModifiedTime, 'RatioDosingActive',tt.DataType,1
,'RatioDosingActive' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType, ms.MachineInternalId as ControllerEquipmentSetupId, 4 as SortingOrder  
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_RATA' AND ms.IsTunnel=0

UNION
------------------------------------
---- Tanks---
------------------------------------
SELECT ts.TankId AS Id, mt.TagAddress AS TagAddress,   ts.TankName AS [Description],Convert(varchar(10),Convert(int,( ts.Size))) AS Value,   
ts.LastModifiedTime , 'Size',tt.DataType,1
,'Size-Size_Display' as OriginalColumnName,'[TCD].[TankSetup]' as EntityName,tt.TagType as TagType, 0 as ControllerEquipmentSetupId  , 0 as SortingOrder

FROM   TCD.ModuleTags mt INNER JOIN TCD.TankSetup ts ON ts.TankId=mt.ModuleId
Inner Join tcd.TagType tt on mt.TagType = tt.TagType

WHERE   mt.ModuleTypeId=@TankModuleTypeId    AND ts.ControllerId=@ControllerId     AND mt.Active=@Active    AND mt.TagType='Tag_SIZ' 
UNION

SELECT ts.TankId,mt.TagAddress,ts.TankName,Convert(varchar(100),Convert(int,( ts.LevelDeviation_Display))),ts.LastModifiedTime ,'Dead Band',tt.DataType,1
,'LevelDeviation-LevelDeviation_Display' as OriginalColumnName,'[TCD].[TankSetup]' as EntityName,tt.TagType as TagType, 0 as SortingOrder, 0 as ControllerEquipmentSetupId  

FROM    TCD.ModuleTags mt 
INNER JOIN  TCD.TankSetup ts ON ts.TankId=mt.ModuleId
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE   mt.ModuleTypeId=@TankModuleTypeId 
    AND ts.ControllerId=@ControllerId 
    AND mt.Active=@Active 
    AND mt.TagType='Tag_DEV' 
UNION


----------------------------------------
---- Meter---
----------------------------------------

----------------------------------------
---- Sensor---
----------------------------------------
SELECT s.SensorId,mt.TagAddress,s.[Description],CONVERT(VARCHAR(100),CAST(s.Calibration4mA as float)),s.LastModifiedTime ,'Calibration4mA',tt.DataType,3
,'Calibration4mA' as OriginalColumnName,'[TCD].[Sensor]' as EntityName,tt.TagType as TagType, 0 as ControllerEquipmentSetupId, 0 as SortingOrder  
from TCD.ModuleTags mt INNER JOIN TCD.Sensor s ON MT.ModuleId=s.SensorId 
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE mt.ModuleTypeId=@SensorModuleTypeId AND s.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_SC4'

UNION

SELECT s.SensorId,mt.TagAddress,s.[Description],CONVERT(VARCHAR(100),CAST(s.Calibration20mA as float)),s.LastModifiedTime , 'Calibration20mA',tt.DataType,3
,'Calibration20mA' as OriginalColumnName,'[TCD].[Sensor]' as EntityName,tt.TagType as TagType, 0 as ControllerEquipmentSetupId, 0 as SortingOrder  
from TCD.ModuleTags mt INNER JOIN TCD.Sensor s ON MT.ModuleId=s.SensorId 
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE mt.ModuleTypeId=@SensorModuleTypeId AND s.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_SC20' 
UNION
--------------------------------------
-- Pumps---
--------------------------------------



SELECT  Convert(int, ces.ControllerEquipmentSetupId), mt.TagAddress,'P/V'+Convert(varchar(100), ces.ControllerEquipmentId),
Convert(varchar(100),Convert(float, ces.KFactor * @FactorMultiplier)),ces.LastModifiedTime ,'K-Factor',tt.DataType,2
,'KFactor' as OriginalColumnName,'[TCD].[ControllerEquipmentSetup]' as EntityName,tt.TagType as TagType, ControllerEquipmentId as ControllerEquipmentSetupId, 1 as SortingOrder   

FROM TCD.ModuleTags mt INNER JOIN TCD.ControllerEquipmentSetup ces ON mt.ModuleId=ces.ControllerEquipmentSetupId 
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE mt.ModuleTypeId=@PumpModuleTypeId AND ces.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_PPOL'
UNION
SELECT  Convert(int, ces.ControllerEquipmentSetupId), mt.TagAddress,'P/V'+Convert(varchar(100), ces.ControllerEquipmentId),
Convert(varchar(100),Convert(float, ces.PumpCalibration *@TimeVolumeMultipler)),ces.LastModifiedTime, 'Time Volume Calibration',tt.DataType,2
,'PumpCalibration' as OriginalColumnName,'[TCD].[ControllerEquipmentSetup]' as EntityName,tt.TagType as TagType , ControllerEquipmentId as  ControllerEquipmentSetupId, 3 as SortingOrder 
FROM TCD.ModuleTags mt INNER JOIN TCD.ControllerEquipmentSetup ces ON mt.ModuleId=ces.ControllerEquipmentSetupId
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE mt.ModuleTypeId=@PumpModuleTypeId AND ces.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_OPSL'
UNION

SELECT Convert(int, ces.ControllerEquipmentSetupId), mt.TagAddress,'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
ces.LfsChemicalName,ces.LastModifiedTime ,'LFS Chemical Name',tt.DataType,2
,'LfsChemicalName' as OriginalColumnName,'[TCD].[ControllerEquipmentSetup]' as EntityName,tt.TagType as TagType, ControllerEquipmentId as ControllerEquipmentSetupId  , 2 as SortingOrder 

FROM TCD.ModuleTags mt INNER JOIN TCD.ControllerEquipmentSetup ces ON mt.ModuleId=ces.ControllerEquipmentSetupId
Inner Join tcd.TagType tt on mt.TagType = tt.TagType 
WHERE mt.ModuleTypeId=@PumpModuleTypeId AND ces.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_NML' 
UNION

SELECT csd.ControllerId ,ct.TagAddress,NULL,csd.[Value],cc.LastModifiedTime , f.Label,tt.DataType,6
,'Value-'+CAST(csd.FieldId as varchar) as OriginalColumnName,'[TCD].[ControllerSetupData]' as EntityName,tt.TagType as TagType, 0 as ControllerEquipmentSetupId  , 0 as SortingOrder
FROM TCD.ControllerTags ct 
INNER JOIN TCD.ControllerSetupData csd ON csd.ControllerId = ct.ControllerId
INNER JOIN tcd.Field f ON f.Id = csd.FieldId AND ct.TagType=f.HasFieldTag
INNER JOIN TCD.ConduitController cc ON cc.ControllerId = ct.ControllerId
Inner Join tcd.TagType tt on ct.TagType = tt.TagType
WHERE ct.ControllerId=@ControllerId AND ct.Active=@Active

UNION

SELECT ces.ControllerEquipmentSetupId,
	   'stMachineConfig.xFlowSwitchType['+cast(ControllerEquipmentId AS varchar(20))+']' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  cast( FlowDetectorType AS varchar(20)) AS Value, 
	   ces.LastModifiedTime,
	   'Flow Detector Type' AS Lable,
	   'BIT' As DataType ,
	   2.1,
	   'FlowDetectorType' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stMachineConfig.xFlowSwitchType' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 5 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3


UNION --Flow Switch Alarm
SELECT ces.ControllerEquipmentSetupId,
	   'stMachineConfig.xFlowAlarmOverride['+cast(ControllerEquipmentId AS varchar(20))+']' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  Cast( ces.FlowSwitchAlarm  AS varchar(20)) AS Value, 
	   ces.LastModifiedTime,
	   'Flow Switch Alarm' AS Lable,
	   'BIT' As DataType ,
	   2.2,
	   'FlowSwitchAlarm' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stMachineConfig.xFlowAlarmOverride' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId , 10 as SortingOrder 
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3
UNION --Flow Meter Alarm
SELECT ces.ControllerEquipmentSetupId,
	   'stMachineConfig.xFlowMeterAlarmOverride['+cast(ControllerEquipmentId AS varchar(20))+']' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	 cast(  ces.FlowMeterAlarm  AS varchar(20)) AS Value, 
	   ces.LastModifiedTime,
	   'Flow Meter Alarm' AS Lable,
	   'BIT' As DataType ,
	   2.3,
	   'FlowMeterAlarm' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stMachineConfig.xFlowMeterAlarmOverride' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 6 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3
UNION --Flow Meter Type
     
SELECT ces.ControllerEquipmentSetupId,
	   'stPumpConfig['+cast(ControllerEquipmentId AS varchar(20))+'].eFlowMeterMode' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  cast( ces.FlowMeterType  AS varchar(20))  AS Value, 
	   ces.LastModifiedTime,
	   'Flow Meter Type' AS Lable,
	   'INT' As DataType ,
	   2.4,
	   'FlowMeterType' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stPumpConfig.eFlowMeterMode' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 9 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3

UNION --Flow Alarm Delay Time
SELECT ces.ControllerEquipmentSetupId,
	   'stPumpConfig['+cast(ControllerEquipmentId AS varchar(20))+'].fLossOfFlowDuration' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  cast( ces.FlowAlarmDelay  AS varchar(20))  AS Value, 
	   ces.LastModifiedTime,
	   'Flow Alarm Delay Time' AS Lable,
	   'FLOAT' As DataType ,
	   2.5,
	   'FlowAlarmDelay' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stPumpConfig.fLossofFlowDuration' TagType, ces.ControllerEquipmentId  as ControllerEquipmentSetupId, 4 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3
UNION --Flow Meter Pump Delay
SELECT ces.ControllerEquipmentSetupId,
	   'stPumpConfig['+cast(ControllerEquipmentId AS varchar(20))+'].fTdFlowMeter' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  cast( ces.FlowMeterPumpDelay  AS varchar(20))  AS Value, 
	   ces.LastModifiedTime,
	   'Flow Meter Pump Delay' AS Lable,
	   'FLOAT' As DataType ,
	   2.6,
	   'FlowMeterPumpDelay' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stPumpConfig.fTdFlowMeter' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 8 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3

UNION -- Flow Meter Alarm Delay
SELECT ces.ControllerEquipmentSetupId,
	   'stPumpConfig['+cast(ControllerEquipmentId AS varchar(20))+'].fTAlarmDelayFlowMeter' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  cast( ces.FlowMeterAlarmDelay  AS varchar(20))  AS Value, 
	   ces.LastModifiedTime,
	   'Flow Meter Alarm Delay' AS Lable,
	   'FLOAT' As DataType ,
	   2.7,
	   'FlowMeterAlarmDelay' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stPumpConfig.fTAlarmDelayFlowMeter' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 7 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3



SELECT  ttmd.Id  
   ,ttmd.TagAddress  
   ,isnull(ttmd.[Description],'')
   ,ttmd.Value  
   ,ttmd.LastModifiedTime  
   ,ttmd.ColName
   ,ttmd.DataType
   ,ttmd.OriginalColumnName
	,ttmd.EntityType 
	,ttmd.TagType,ttmd.SortingOrder,ttmd.ControllerEquipmentSetupId  FROM dbo.#tmpTagManagementDetails ttmd WHERE ttmd.[Value] IS  NOT NULL AND ttmd.[Value]<> '' ORDER BY ttmd.RowNumber

END
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetBatchByGroupId]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetBatchByGroupId]
END
GO
CREATE PROCEDURE [TCD].[GetBatchByGroupId] 
(
    @GroupId        NVARCHAR(1000)        =   NULL
  , @MachineId        INT                 =   NULL
  --, @ProgramId        NVARCHAR(1000)        =   NULL
  , @ProgramId       INT                 =   NULL
  , @StartDate        DATETIME            =   NULL
  , @RowsPerPage INT =50
  , @PageNumber INT = 1
  ,	@EndDate	DATETIME            =   NULL
)
AS 
/*
-- Usage
EXEC [TCD].[GetBatchByGroupId] @GroupId =   NULL
  , @MachineId = 1
  , @ProgramId = 54
  , @StartDate = '2014-06-06'
  , @RowsPerPage = 50
  , @PageNumber = 3


*/

  BEGIN
  SET NOCOUNT ON

	if(@ProgramId = 0)      
    BEGIN      
    set @ProgramId = null      
    END    
    
   IF @PageNumber < 1 
    SET @PageNumber = 1 

   SELECT --TOP 10 
   bd.BatchId,
   CAST(StartDate AS datetime) AS StartDate,
   COALESCE(bd.ManualInputWeight,bd.ActualWeight), 
   bd.ProgramNumber,
   pm.Name,
  Count(*) Over() TotalRows ,  
  bd.EcolabWasherId
   FROM [TCD].BatchData bd
   INNER JOIN tcd.ProgramMaster pm ON pm.ProgramId = bd.ProgramMasterId
   WHERE 
 --   bd.GroupId           IN     (SELECT cast(items as int) FROM [TCD].[CharacterListToTable] (@GroupId, ','))
     bd.MachineId        =     @MachineId
   AND   bd.ProgramNumber   =    COALESCE(@ProgramId, bd.ProgramNumber ) -- (SELECT cast(items as int) FROM [TCD].[CharacterListToTable] (@ProgramId, ','))
   AND bd.[StartDate]       >=     @StartDate
   AND  bd.[StartDate]    <= ISNULL(@EndDate, GETUTCDATE())
   ORDER BY bd.BatchId
   OFFSET (@PageNumber-1)*@RowsPerPage ROWS
   FETCH NEXT @RowsPerPage ROWS ONLY

 SET NOCOUNT OFF
  END
GO
  IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[UpdateLastSyncTime]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[UpdateLastSyncTime]
END
GO
/*
###################################################################################################
Stored Procedure:       [TCD].[UpdateLastSyncTime]
Purpose:				To update the last Sync time for a particular table.
Parameters:				@Id: update the last sync time for a particular id.
@Tablename: update the last sync time in a particular table.
@ColumnName : update the last sync time in a particular table based on column
###################################################################################################
*/

CREATE PROCEDURE [TCD].[UpdateLastSyncTime]
(
@Id INT,
@TableName VARCHAR(100),
@ColumnName VARCHAR (100),
@EcolabAccountNumber NVARCHAR(25),
@LastSyncTime DATETIME
)
AS
BEGIN
SET NOCOUNT ON;
DECLARE    @SQLString    NVARCHAR(2000)    =    N''
--DECLARE	 @PlantId	     INT 
--        SET @PlantId =    (
--                    SELECT 
--                        PlantId 
--                    FROM 
--                        TCD.Plant 
--                    WHERE 
--                        EcolabAccountNumber = @EcolabAccountNumber);
IF(@TableName = 'Plant' OR @TableName = 'LaborCost' )
BEGIN
SET    @SQLString    =    'UPDATE  TCD.' + @TableName + ' ' + 'SET LastSyncTime = '''+ CONVERT(VARCHAR(23),@LastSyncTime,121) +''' WHERE  EcolabAccountNumber = ''' +  @EcolabAccountNumber + ''''
EXEC (@SQLString)
END

ELSE IF (@TableName = 'BatchData' OR @TableName = 'AlarmData' OR @TableName = 'RedFlagData')
BEGIN
SET    @SQLString    =    'UPDATE  TCD.' + @TableName + ' ' + 'SET LastSyncTime = '''+ CONVERT(VARCHAR(23),@LastSyncTime,121) +''' WHERE ' + @ColumnName + ' = ' +  CAST(@Id AS NVARCHAR)
EXEC (@SQLString)
END

ELSE IF(@TableName = 'ConduitController' OR  @TableName = 'TankSetup')
BEGIN
SET    @SQLString    =    'UPDATE  TCD.' + @TableName + ' ' + 'SET LastSyncTime = '''+ CONVERT(VARCHAR(23),@LastSyncTime,121) +''' WHERE  EcoalabAccountNumber = ''' +  @EcolabAccountNumber + ''' AND ' + @ColumnName + ' = ' +  CAST(@Id AS NVARCHAR)
EXEC (@SQLString)
END

ELSE IF(@TableName = 'ProductionShiftData')
BEGIN
SET    @SQLString    =    'UPDATE  TCD.' + @TableName + ' ' + 'SET LastSyncTime = '''+ CONVERT(VARCHAR(23),@LastSyncTime,121) +''' WHERE  EcolabAccountNumber = ''' +  @EcolabAccountNumber + ''' AND  LastSyncTime IS NULL AND ' + @ColumnName + ' <= ' +  CAST(@Id AS NVARCHAR) 
EXEC (@SQLString)
END

ELSE IF(@TableName = 'Tunnel' )
BEGIN
SET    @SQLString    =    'UPDATE  TCD.Washer' + ' SET LastSyncTime = '''+ CONVERT(VARCHAR(23),@LastSyncTime,121) +''' WHERE  EcolabAccountNumber = ''' +  @EcolabAccountNumber + ''' AND ' + @ColumnName + ' = ' +  CAST(@Id AS NVARCHAR)
EXEC (@SQLString)

SET    @SQLString    =    'UPDATE  TCD.TunnelCompartment' + ' SET LastSyncTime = '''+ CONVERT(VARCHAR(23),@LastSyncTime,121) +''' WHERE  EcolabAccountNumber = ''' +  @EcolabAccountNumber + ''' AND ' + @ColumnName + ' = ' +  CAST(@Id AS NVARCHAR)
EXEC (@SQLString)
END

ELSE IF (@TableName = 'ShiftData')
BEGIN
SET    @SQLString    =    'UPDATE  TCD.' + @TableName + ' ' + 'SET LastSyncTime = '''+ CONVERT(VARCHAR(23),@LastSyncTime,121) +''''
EXEC (@SQLString)
END

ELSE IF (@TableName = 'ShiftLaborData')
BEGIN
SET    @SQLString    =    'UPDATE  TCD.' + @TableName + ' ' + 'SET LastSyncTime = '''+ CONVERT(VARCHAR(23),@LastSyncTime,121) +''''
EXEC (@SQLString)
END

ELSE IF (@TableName = 'EnergyUtilityDetails')
BEGIN
SET    @SQLString    =    'UPDATE  TCD.' + @TableName + ' ' + 'SET LastSyncTime = '''+ CONVERT(VARCHAR(23),@LastSyncTime,121) +''''
EXEC (@SQLString)

SET    @SQLString    =    'UPDATE TCD.WaterUtilityDetails ' + 'SET LastSyncTime = '''+ CONVERT(VARCHAR(23),@LastSyncTime,121) +''''
EXEC (@SQLString)
END
ELSE IF (@TableName = 'WasherFlushTime')
BEGIN
SET    @SQLString    =    'UPDATE  TCD.' + @TableName + ' ' + 'SET LastSyncTime = '''+ CONVERT(VARCHAR(23),@LastSyncTime,121) +''' WHERE ' + @ColumnName + ' = ' +  CAST(@Id AS NVARCHAR) 
EXEC (@SQLString)

SET    @SQLString    =    'UPDATE  TCD.WasherTimeOutMachine' + ' SET LastSyncTime = '''+ CONVERT(VARCHAR(23),@LastSyncTime,121) +''' WHERE ' + @ColumnName + ' = ' +  CAST(@Id AS NVARCHAR) 
EXEC (@SQLString)
END
ELSE IF (@TableName = 'TunnelAnalogControlLevel')
BEGIN
SET    @SQLString    =    'UPDATE  TCD.' + @TableName + ' ' + 'SET LastSyncTime = '''+ CONVERT(VARCHAR(23),@LastSyncTime,121) +''' WHERE ' + @ColumnName + ' = ' +  CAST(@Id AS NVARCHAR) 
PRINT @SQLString
EXEC (@SQLString)
END
ELSE
BEGIN
SET    @SQLString    =    'UPDATE  TCD.' + @TableName + ' ' + 'SET LastSyncTime = '''+ CONVERT(VARCHAR(23),@LastSyncTime,121) +''' WHERE ' + @ColumnName + ' = ' +  CAST(@Id AS NVARCHAR) + ' AND EcolabAccountNumber = '''  + @EcolabAccountNumber + ''''
EXEC (@SQLString)
END

SET NOCOUNT OFF;
END
GO