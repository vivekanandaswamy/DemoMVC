﻿-- File Created Date : 24/06/2016 --
-- NAGoLiveI-UATFeb16.sql DML Scripts -- 

--Declare temp table variable to hold input data
		DECLARE	@tempLanguageMaster	TABLE	(
				TempId						INT				IDENTITY(1, 1)
			,	LanguageId					INT				NOT	NULL
			,	Name						NVARCHAR(50)
			,	MyServiceISOLangCD			CHAR(2)			NULL
			,	MyServiceDialectCD			CHAR(2)			NULL
			,	Locale						VARCHAR(50)		NULL
			,   IsActive					bit				NULL
			)
		--Populate temp table variable with the input data
		INSERT	@tempLanguageMaster	(
				LanguageId			,Name	,MyServiceISOLangCD	,MyServiceDialectCD, Locale,IsActive	)
		VALUES	
 (2, N'Deutsch', N'DE', N'  ', N'nl-BE', 1)
		MERGE	[TCD].LanguageMaster		AS TARGET
		USING	@tempLanguageMaster	AS SOURCE
			ON	TARGET.LanguageId		=			SOURCE.LanguageId
		WHEN	NOT MATCHED		THEN
				INSERT	(LanguageId			,Name			,MyServiceISOLangCD			,MyServiceDialectCD				, Locale	)
				VALUES	(SOURCE.LanguageId	,SOURCE.Name	,SOURCE.MyServiceISOLangCD	,SOURCE.MyServiceDialectCD		, Locale	)
				;
GO

IF NOT Exists(SELECT 1 FROM TCD.[ReportSubView] where ID = 20)
BEGIN
	INSERT INTO [TCD].[ReportSubView]
	(Id,Name,ViewModeId,UsageKey)
	VALUES(20,'Formula Segment',8,'FIELD_FORMULA_SEGMENT')
END
GO
IF NOT Exists(SELECT 1 FROM TCD.[ReportSubView] where ID = 21)
BEGIN
	INSERT INTO [TCD].[ReportSubView]
	(Id,Name,ViewModeId,UsageKey)
	VALUES(21,'Formula Category',8,'FIELD_FORMULA_CATEGORY')
END
GO
IF NOT Exists(SELECT 1 FROM TCD.[ReportSubView] where ID = 22)
BEGIN
	INSERT INTO [TCD].[ReportSubView]
	(Id,Name,ViewModeId,UsageKey)
	VALUES(22,'Formula',8,'FIELD_FORMULA')
END
GO
UPDATE [TCD].[ReportSubView]
SET DrilldownView = 21
WHERE Id= 20
GO
UPDATE [TCD].[ReportSubView]
SET DrilldownView = 22,
	DrillupView=20
WHERE Id= 21
GO

UPDATE [TCD].[ReportSubView]
SET DrillupView=21
WHERE Id= 22
GO


IF NOT Exists(SELECT 1 FROM [TCD].[ReportViewByModeMapping]  WHERE ViewModeId =8)
BEGIN
	INSERT INTO [TCD].[ReportViewByModeMapping]
	(ViewModeId,ReportId,ChartType,SubViewId,isDefault,HasGroupBy)
	VALUES(8,2,'pie',20,1,1)

	INSERT INTO [TCD].[ReportViewByModeMapping]
	(ViewModeId,ReportId,ChartType,SubViewId,isDefault,HasGroupBy)
	VALUES(8,7,'column',20,1,1)

	INSERT INTO [TCD].[ReportViewByModeMapping]
	(ViewModeId,ReportId,ChartType,SubViewId,isDefault,HasGroupBy)
	VALUES(8,20,'column',20,1,1)

	INSERT INTO [TCD].[ReportViewByModeMapping]
	(ViewModeId,ReportId,ChartType,SubViewId,isDefault,HasGroupBy)
	VALUES(8,10,'column',20,1,1)
END

--SELECT * FROM tcd.ReportViewModeRoleMapping where ViewModeId =3

IF NOT Exists(SELECT  * FROM tcd.ReportViewModeRoleMapping WHERE ViewModeId = 8)
BEGIN
	INSERT INTO tcd.ReportViewModeRoleMapping
	(ViewModeId,RoleID,SettingValue)
	VALUES(8,9,1)
	INSERT INTO tcd.ReportViewModeRoleMapping
	(ViewModeId,RoleID,SettingValue)
	VALUES(8,5,1)
	INSERT INTO tcd.ReportViewModeRoleMapping
	(ViewModeId,RoleID,SettingValue)
	VALUES(8,6,1)
	INSERT INTO tcd.ReportViewModeRoleMapping
	(ViewModeId,RoleID,SettingValue)
	VALUES(8,7,1)
	INSERT INTO tcd.ReportViewModeRoleMapping
	(ViewModeId,RoleID,SettingValue)
	VALUES(8,8,1)
END

INSERT INTO tcd.ReportColumnsMapping
(ColumnId,
ReportId,
IsChartDisplay,
DisplayOrder,
IsSortable,
ViewById,
SwitchModeId,
IsVisible,
[Precision])
SELECT  
ColumnId,
ReportId,
IsChartDisplay,
DisplayOrder,
IsSortable,
8 ViewById,
SwitchModeId,
IsVisible,
[Precision]
 FROM tcd.ReportColumnsMapping where ViewById =3 and ReportId = 2

 
INSERT INTO tcd.ReportColumnsMapping
	(ColumnId,
	ReportId,
	IsChartDisplay,
	DisplayOrder,
	IsSortable,
	ViewById,
	SwitchModeId,
	IsVisible,
	[Precision])
SELECT  
	ColumnId,
	ReportId,
	IsChartDisplay,
	DisplayOrder,
	IsSortable,
	8 ViewById,
	SwitchModeId,
	IsVisible,
	[Precision]
	 FROM tcd.ReportColumnsMapping where ViewById =3 and ReportId = 10

Go

DELETE  FROM tcd.ReportColumnsMapping
WHERE ReportId = 2 and ViewById = 8 and ColumnID= 244
Go

DELETE  FROM tcd.ReportColumnsMapping
WHERE ReportId = 10 and ViewById = 8 and ColumnID= 244
GO

UPDATE [TCD].ReportViewModeRoleMapping   
SET SettingValue= 0 ,IsDefault =null
WHERE ViewModeId in(3,4,5,7)

UPDATE tcd.ReportDefaultViewRoleMapping 
SET DefaultViewId =8 
WHERE DefaultViewId  in(3,4,5,7)

UPDATE TCD.ReportFilter
SET FilterName ='Formula Segment'--Ecolab Category
WHERE ReportFilterId=7


Go

UPDATE TCD.ReportFilter
SET FilterName ='Formula Segment'--Ecolab Category
WHERE ReportFilterId=7


UPDATE  TCD.ReportLocalizationFilterMapping
SET UsageKey ='FIELD_FORMULA_SEGMENT'
where ReportFilterId =7
Go

UPDATE  TCD.ReportFilter
SET FilterName ='Formula Category'
 where ReportFilterId  =23
 Go

UPDATE  TCD.ReportLocalizationFilterMapping
SET UsageKey ='FIELD_FORMULA_CATEGORY'
where ReportFilterId =23



 UPDATE TCD.ReportFilter SET FilterName ='Formula'
 where ReportFilterId = 10
 GO
UPDATE  TCD.ReportLocalizationFilterMapping
SET UsageKey ='FIELD_FORMULA'
where ReportFilterId =10
GO

IF NOT Exists(SELECT  1 FROM TCD.ReportFilterMApping WHERE ReportID = 5 and FilterID = 10)
BEGIN
INSERT INTO TCD.ReportFilterMApping(FilterId,ReportId,IsDefault,SortOrder)
VALUES(10,5,0,10)
END
Go

UPDATE TCD.ReportFilterRoleMapping
Set SettingValue=1  where ReportFilterId = 7---Segment Filter
Go

UPDATE TCD.ConfigSettings SET
		[Value] = 'False'
	WHERE
		KeyName = 'TimerAutoReset'
	AND Type = 'SyncBatchData'

IF EXISTS(SELECT
				  1
			  FROM TCD.ResourceKeyValue
			  WHERE KeyName = 'FIELD_MACHINENAME_DISPLAY_TYPE'
				AND languageID = 1)
	BEGIN
		UPDATE TCD.ResourceKeyValue SET
				Value = 'Machine Name Display As', 
				LastModifiedTime = GETDATE()
			WHERE
				KeyName = 'FIELD_MACHINENAME_DISPLAY_TYPE'
			AND languageID = 1
	END
GO
IF EXISTS(SELECT
				  1
			  FROM TCD.ResourceKeyValue
			  WHERE KeyName = 'FIELD_MACHINENAME_DISPLAY_TYPE_BOTH'
				AND languageID = 1)
	BEGIN
		UPDATE TCD.ResourceKeyValue SET
				Value = 'Both', 
				LastModifiedTime = GETDATE()
			WHERE
				KeyName = 'FIELD_MACHINENAME_DISPLAY_TYPE_BOTH'
			AND languageID = 1
	END



Go

IF EXISTS (SELECT * FROM [TCD].[ResourceKeyValue] WHERE KeyName='FIELD_PRODUCTIONDATA' and languageID=1)
	BEGIN
		 UPDATE tcd.ResourceKeyValue set Value='Manually Entered Loads', LastModifiedTime=GETDATE() 
		 WHERE KeyName='FIELD_PRODUCTIONDATA' and languageID=1
	END
ELSE
	BEGIN
		INSERT INTO [TCD].[ResourceKeyValue](KeyName, Value, languageID, LastModifiedTime) values('FIELD_PRODUCTIONDATA','Manually Entered Loads',1,GETDATE())
	END
GO
IF EXISTS (SELECT 1 FROM [TCD].[ResourceKeyValue] WHERE KeyName='FIELD_PRODUCTIONDATA' and languageID=2)
	BEGIN
		 UPDATE tcd.ResourceKeyValue set Value='Manuell Erfasste Posten', LastModifiedTime=GETDATE() 
		 WHERE KeyName='FIELD_PRODUCTIONDATA' and languageID=2
	END
ELSE
	BEGIN
		INSERT INTO [TCD].[ResourceKeyValue](KeyName, Value, languageID, LastModifiedTime) values('FIELD_PRODUCTIONDATA','Manuell Erfasste Posten',2,GETDATE())
	END
GO
IF EXISTS (SELECT 1 FROM [TCD].[ResourceKeyValue] WHERE KeyName='FIELD_PRODUCTIONDATA' and languageID=3)
	BEGIN
		 UPDATE tcd.ResourceKeyValue set Value='Cargas introducidas manualmente', LastModifiedTime=GETDATE() 
		 WHERE KeyName='FIELD_PRODUCTIONDATA' and languageID=3
	END
ELSE
	BEGIN
		INSERT INTO [TCD].[ResourceKeyValue](KeyName, Value, languageID, LastModifiedTime) values('FIELD_PRODUCTIONDATA','Cargas introducidas manualmente',3,GETDATE())
	END
GO
IF EXISTS (SELECT 1 FROM [TCD].[ResourceKeyValue] WHERE KeyName='FIELD_PRODUCTIONDATA' and languageID=13)
	BEGIN
		 UPDATE tcd.ResourceKeyValue set Value='Angitt manuelt Masse', LastModifiedTime=GETDATE() 
		 WHERE KeyName='FIELD_PRODUCTIONDATA' and languageID=13
	END
ELSE
	BEGIN
		INSERT INTO [TCD].[ResourceKeyValue](KeyName, Value, languageID, LastModifiedTime) values('FIELD_PRODUCTIONDATA','Angitt manuelt Masse',13,GETDATE())
	END
GO
IF EXISTS (SELECT 1 FROM [TCD].[ResourceKeyValue] where KeyName='FIELD_BATCHDATA' and languageID=1)
	BEGIN
		 UPDATE tcd.ResourceKeyValue set Value='Dispenser Recorded Loads', LastModifiedTime=GETDATE() 
		 WHERE KeyName='FIELD_BATCHDATA' and languageID=1
END
ELSE
	BEGIN
		INSERT INTO [TCD].[ResourceKeyValue](KeyName, Value, languageID, LastModifiedTime) values('FIELD_BATCHDATA','Dispenser Recorded Loads',1,GETDATE())
	END
GO
IF EXISTS (SELECT 1 FROM [TCD].[ResourceKeyValue] where KeyName='FIELD_BATCHDATA' and languageID=2)
	BEGIN
		 UPDATE tcd.ResourceKeyValue set Value='Automatisch Erfasste Posten', LastModifiedTime=GETDATE() 
		 WHERE KeyName='FIELD_BATCHDATA' and languageID=2
END
ELSE
	BEGIN
		INSERT INTO [TCD].[ResourceKeyValue](KeyName, Value, languageID, LastModifiedTime) values('FIELD_BATCHDATA','Automatisch Erfasste Posten',2,GETDATE())
	END
GO
IF EXISTS (SELECT 1 FROM [TCD].[ResourceKeyValue] where KeyName='FIELD_BATCHDATA' and languageID=3)
	BEGIN
		 UPDATE tcd.ResourceKeyValue set Value='Dispensador registró cargas', LastModifiedTime=GETDATE() 
		 WHERE KeyName='FIELD_BATCHDATA' and languageID=3
END
ELSE
	BEGIN
		INSERT INTO [TCD].[ResourceKeyValue](KeyName, Value, languageID, LastModifiedTime) values('FIELD_BATCHDATA','Dispensador registró cargas',3,GETDATE())
	END
GO
IF EXISTS (SELECT 1 FROM [TCD].[ResourceKeyValue] where KeyName='FIELD_BATCHDATA' and languageID=13)
	BEGIN
		 UPDATE tcd.ResourceKeyValue set Value='Dispenser Innspilt Masse', LastModifiedTime=GETDATE() 
		 WHERE KeyName='FIELD_BATCHDATA' and languageID=13
END
ELSE
	BEGIN
		INSERT INTO [TCD].[ResourceKeyValue](KeyName, Value, languageID, LastModifiedTime) values('FIELD_BATCHDATA','Dispenser Innspilt Masse',13,GETDATE())
	END
GO
IF NOT EXISTS (SELECT 1 FROM [TCD].[ResourceKeyMaster] where KeyName='FIELD_MANUALLYENTEREDWEIGHT')
	BEGIN
		 INSERT INTO TCD.ResourceKeyMaster(KeyName, KeyDescription) Values('FIELD_MANUALLYENTEREDWEIGHT', 'Manually entered weight')
END
ELSE
	BEGIN
		UPDATE TCD.ResourceKeyMaster SET KeyName='FIELD_MANUALLYENTEREDWEIGHT', KeyDescription='Manually entered weight' WHERE KeyName='FIELD_MANUALLYENTEREDWEIGHT'
	END
GO
IF NOT EXISTS (SELECT 1 FROM [TCD].[ResourceKeyMaster] where KeyName='FIELD_RECORDEDDATE')
	BEGIN
		 INSERT INTO TCD.ResourceKeyMaster(KeyName, KeyDescription) Values('FIELD_RECORDEDDATE', 'Manually entered recorded date')
	END
ELSE
	BEGIN
		UPDATE TCD.ResourceKeyMaster SET KeyName='FIELD_RECORDEDDATE', KeyDescription='Manually entered recorded date' WHERE KeyName='FIELD_RECORDEDDATE'
	END
GO
IF NOT EXISTS (SELECT 1 FROM [TCD].[ResourceKeyValue] where KeyName='FIELD_MANUALLYENTEREDWEIGHT' and languageID=1)
	BEGIN
		 INSERT INTO TCD.ResourceKeyValue(KeyName, Value, languageID, LastModifiedTime) Values('FIELD_MANUALLYENTEREDWEIGHT', 'Weight',1,GETDATE())
	END
ELSE
	BEGIN
		UPDATE TCD.ResourceKeyValue SET KeyName='FIELD_MANUALLYENTEREDWEIGHT', Value='Weight', languageID=1, LastModifiedTime=GETDATE() WHERE KeyName='FIELD_MANUALLYENTEREDWEIGHT' and languageID=1 
	END
GO
IF NOT EXISTS (SELECT 1 FROM [TCD].[ResourceKeyValue] where KeyName='FIELD_RECORDEDDATE' and languageID=1)
	BEGIN
		 INSERT INTO TCD.ResourceKeyValue(KeyName, Value, languageID, LastModifiedTime) Values('FIELD_RECORDEDDATE', 'Recorded Date',1,GETDATE())
END
ELSE
	BEGIN
		UPDATE TCD.ResourceKeyValue SET KeyName='FIELD_RECORDEDDATE', Value='Recorded Date', languageID=1, LastModifiedTime=GETDATE() WHERE KeyName='FIELD_RECORDEDDATE' and languageID=1 
	END
GO


IF EXISTS(SELECT
				  * FROM sys.views WHERE object_id = OBJECT_ID(N'[TCD].[Turntime]')
									 AND type = N'V')
	BEGIN
		DROP VIEW
				TCD.Turntime
	END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


   
   
Create VIEW [TCD].[Turntime]
AS
      
        
WITH CTE_TurnTime 
AS ( 
SELECT
     ROW_NUMBER() OVER(PARTITION BY BD.ECOLABWASHERID ORDER BY BD.GroupId,BD.MachineId, BD.STARTDATE) AS ROWNUMBER, 
     BD.ECOLABWASHERID,
     BD.BATCHID,
     STARTDATE,
     ENDDATE,
     BD.TARGETTURNTIME ,
     W.DEFAULTIDLETIME,
     BD.GROUPID,
    BD.MachineId
    FROM TCD.BATCHDATA AS BD WITH (NOLOCK)
    INNER JOIN TCD.WASHER AS W           ON BD.MachineId = W.WasherID 
                                                      AND isnull(BD.EcolabWasherId,0) = isnull(W.EcolabWasherId,0)  
     INNER JOIN TCD.WASHERGROUP AS WG     ON WG.WASHERGROUPID=BD.GROUPID 
                                                            AND W.ECOLABACCOUNTNUMBER = WG.ECOLABACCOUNTNUMBER 
     INNER JOIN TCD.MACHINESETUP AS MS    ON MS.GroupId = WG.WasherGroupId 
                                                            AND ms.WasherId = W.WasherId 
                                                            AND w.EcoLabAccountNumber = ms.EcoalabAccountNumber 
    WHERE BD.PROGRAMMASTERID <> 0
    AND WG.WASHERGROUPTYPEID=1
) 
   
SELECT CurBatch.BATCHID 
, CurBatch.ECOLABWASHERID 
,CurBatch.ENDDATE 
,nextBatch.STARTDATE
, CurBatch.MachineId
, CASE 
        WHEN nextBatch.STARTDATE IS NULL
              THEN CurBatch.TargetTurnTime
     WHEN ((DATEDIFF(SECOND,CurBatch.ENDDATE,ISNULL(nextBatch.STARTDATE, GETDATE())) <= 0 )or (DATEDIFF(SECOND,CurBatch.ENDDATE,ISNULL(nextBatch.STARTDATE, GETDATE())) > (CurBatch.defaultidletime * 60)) and CurBatch.DefaultIdleTime <>0)
      --OR DATEDIFF(hh,CurBatch.ENDDATE,ISNULL(nextBatch.STARTDATE, GETDATE())) > 2) 
      THEN nextBatch.TARGETTURNTIME 
      ELSE DATEDIFF(SECOND,CurBatch.ENDDATE, nextBatch.STARTDATE) 
         END AS ActualTurnTime
FROM CTE_TurnTime CurBatch 
LEFT JOIN CTE_TurnTime nextBatch ON isnull(CurBatch.ECOLABWASHERID,0) = isnull(nextBatch.ECOLABWASHERID,0)
AND CurBatch.MachineId = nextBatch.MachineId
    AND CurBatch.GROUPID = nextBatch.GROUPID 
AND CurBatch.ROWNUMBER + 1 = nextBatch.ROWNUMBER




GO




IF NOT EXISTS (SELECT name FROM sysindexes WHERE name = 'IX_BatchData_ProgramMasterID')
BEGIN
CREATE NONCLUSTERED INDEX IX_BatchData_ProgramMasterID
ON [TCD].[BatchData] ([ProgramMasterId])
INCLUDE ([BatchId],[EcolabWasherId],[GroupId],[StartDate],[EndDate],[MachineId],[TargetTurnTime])
END
GO
 

 IF NOT EXISTS (SELECT name FROM sysindexes WHERE name = 'IX_BatchData_GroupID_MachineID')
 BEGIN
CREATE NONCLUSTERED INDEX IX_BatchData_GroupID_MachineID
ON [TCD].[BatchData] ([GroupId],[MachineId])
INCLUDE ([EcolabWasherId],[StartDate],[ProgramMasterId],[TargetTurnTime])
END
GO


IF NOT EXISTS(SELECT 1 FROM TCD.ReportViewModeRoleMapping WHERE ViewModeId=8 AND RoleId=3)
BEGIN
INSERT INTO  TCD.ReportViewModeRoleMapping
(
    --Id - this column value is auto-generated
    ViewModeId,
    RoleId,
    SettingValue
)
VALUES
(
    -- Id - int
    8, -- ViewModeId - int
    3, -- RoleId - int
    1 -- SettingValue - bit   
)   

END
Go
IF NOT EXISTS(SELECT
				  *
			  FROM TCD.ReportFilterRoleMapping
			  WHERE RoleId = 8)
	BEGIN
		INSERT INTO [TCD].[ReportFilterRoleMapping] ([ReportFilterId],[SettingValue],[RoleId]) VALUES (1,1,8)
		INSERT INTO [TCD].[ReportFilterRoleMapping] ([ReportFilterId],[SettingValue],[RoleId]) VALUES (2,1,8)
		INSERT INTO [TCD].[ReportFilterRoleMapping] ([ReportFilterId],[SettingValue],[RoleId]) VALUES (3,1,8)
		INSERT INTO [TCD].[ReportFilterRoleMapping] ([ReportFilterId],[SettingValue],[RoleId]) VALUES (4,1,8)
		INSERT INTO [TCD].[ReportFilterRoleMapping] ([ReportFilterId],[SettingValue],[RoleId]) VALUES (5,1,8)
		INSERT INTO [TCD].[ReportFilterRoleMapping] ([ReportFilterId],[SettingValue],[RoleId]) VALUES (6,1,8)
		INSERT INTO [TCD].[ReportFilterRoleMapping] ([ReportFilterId],[SettingValue],[RoleId]) VALUES (7,1,8)
		INSERT INTO [TCD].[ReportFilterRoleMapping] ([ReportFilterId],[SettingValue],[RoleId]) VALUES (8,1,8)
		INSERT INTO [TCD].[ReportFilterRoleMapping] ([ReportFilterId],[SettingValue],[RoleId]) VALUES (9,1,8)
		INSERT INTO [TCD].[ReportFilterRoleMapping] ([ReportFilterId],[SettingValue],[RoleId]) VALUES (10,1,8)
		INSERT INTO [TCD].[ReportFilterRoleMapping] ([ReportFilterId],[SettingValue],[RoleId]) VALUES (11,1,8)
		INSERT INTO [TCD].[ReportFilterRoleMapping] ([ReportFilterId],[SettingValue],[RoleId]) VALUES (12,1,8)
		INSERT INTO [TCD].[ReportFilterRoleMapping] ([ReportFilterId],[SettingValue],[RoleId]) VALUES (13,1,8)
		INSERT INTO [TCD].[ReportFilterRoleMapping] ([ReportFilterId],[SettingValue],[RoleId]) VALUES (14,1,8)
		INSERT INTO [TCD].[ReportFilterRoleMapping] ([ReportFilterId],[SettingValue],[RoleId]) VALUES (95,1,8)
		INSERT INTO [TCD].[ReportFilterRoleMapping] ([ReportFilterId],[SettingValue],[RoleId]) VALUES (16,1,8)
		INSERT INTO [TCD].[ReportFilterRoleMapping] ([ReportFilterId],[SettingValue],[RoleId]) VALUES (17,1,8)
		INSERT INTO [TCD].[ReportFilterRoleMapping] ([ReportFilterId],[SettingValue],[RoleId]) VALUES (18,1,8)
		INSERT INTO [TCD].[ReportFilterRoleMapping] ([ReportFilterId],[SettingValue],[RoleId]) VALUES (19,1,8)
		INSERT INTO [TCD].[ReportFilterRoleMapping] ([ReportFilterId],[SettingValue],[RoleId]) VALUES (20,1,8)
		INSERT INTO [TCD].[ReportFilterRoleMapping] ([ReportFilterId],[SettingValue],[RoleId]) VALUES (21,1,8)
		INSERT INTO [TCD].[ReportFilterRoleMapping] ([ReportFilterId],[SettingValue],[RoleId]) VALUES (22,1,8)
		INSERT INTO [TCD].[ReportFilterRoleMapping] ([ReportFilterId],[SettingValue],[RoleId]) VALUES (23,1,8)
		INSERT INTO [TCD].[ReportFilterRoleMapping] ([ReportFilterId],[SettingValue],[RoleId]) VALUES (24,1,8)
		INSERT INTO [TCD].[ReportFilterRoleMapping] ([ReportFilterId],[SettingValue],[RoleId]) VALUES (25,1,8)
				
	END
	ELSE IF EXISTS(SELECT
				  *
			  FROM TCD.ReportFilterRoleMapping
			  WHERE RoleId = 8)
	BEGIN
		PRINT 'Mapping for RoleId 8 already Exits in ReportFilterRoleMapping'
	END
GO

IF NOT EXISTS(SELECT 1 FROM TCD.ReportViewModeRoleMapping WHERE ViewModeId=8 AND RoleId=4)
BEGIN
INSERT INTO  TCD.ReportViewModeRoleMapping
(
    --Id - this column value is auto-generated
    ViewModeId,
    RoleId,
    SettingValue
)
VALUES
(
    -- Id - int
    8, -- ViewModeId - int
    4, -- RoleId - int
    1 -- SettingValue - bit   
)   

END
GO

 /* START - AllenBradley Queue population and retrieval logic changes for Webport. Added TagOrder in the Queue. */


 IF NOT EXISTS(SELECT * FROM sys.columns WHERE  object_id = OBJECT_ID(N'TCD.AllenBradleyArrayQueue') AND name = 'TagOrder')
BEGIN
	ALTER TABLE TCD.AllenBradleyArrayQueue 
	ADD TagOrder INT NULL
END
GO

IF NOT EXISTS(SELECT * FROM sys.columns WHERE  object_id = OBJECT_ID(N'TCD.AllenBradleyArrayQueue_Shadow') AND name = 'TagOrder')
BEGIN
	ALTER TABLE TCD.AllenBradleyArrayQueue_Shadow 
	ADD TagOrder INT NULL
END
GO

IF OBJECT_ID('[TCD].[tr_AllenBradleyArrayQueue_Insert]') is not null
BEGIN
	DROP trigger [TCD].[tr_AllenBradleyArrayQueue_Insert]	
END

GO

CREATE TRIGGER [TCD].[tr_AllenBradleyArrayQueue_Insert] ON [TCD].[AllenBradleyArrayQueue] for INSERT AS
SET IDENTITY_INSERT tcd.AllenBradleyArrayQueue_Shadow ON
INSERT INTO tcd.AllenBradleyArrayQueue_Shadow([Controllerid] ,[Washerid],[Address],[Value],[Timestamp],[TagType],[IsTunnel],[LoadId], [TagOrder])
SELECT [Controllerid] ,[Washerid],[Address],[Value],[Timestamp],[TagType],[IsTunnel],[LoadId], [TagOrder] FROM Inserted
SET IDENTITY_INSERT tcd.AllenBradleyArrayQueue_Shadow OFF

GO

/* END - AllenBradley Queue population and retrieval logic changes for Webport. Added TagOrder in the Queue. */

/*Insert the new segment Industrial into formulasegments*/
IF NOT  EXISTS (SELECT * FROM tcd.FormulaSegments fs WHERE fs.SegmentName = 'Industrial')
BEGIN
INSERT INTO tcd.FormulaSegments
(
    --FormulaSegmentID - this column value is auto-generated
    TCD.FormulaSegments.SegmentName,
    TCD.FormulaSegments.LastModifiedTime,
    TCD.FormulaSegments.Is_Deleted
)
VALUES
(
    -- FormulaSegmentID - int
    'Industrial', -- SegmentName - varchar
    GETDATE(), -- LastModifiedTime - datetime
    0 -- Is_Deleted - bit
)
END 
GO
UPDATE rkv SET rkv.[Value]='Actual Consumption' FROM TCD.ResourceKeyValue rkv 
WHERE rkv.KeyName='FIELD_CONSUMPTIONPERLOAD' AND rkv.LanguageID=1

UPDATE rkv SET rkv.[Value]='Actual Cost' FROM TCD.ResourceKeyValue rkv 
WHERE rkv.KeyName='FIELD_COSTPERLOAD' AND rkv.LanguageID=1

UPDATE rkv SET rkv.[Value]='Actual Water Usage' FROM TCD.ResourceKeyValue rkv 
WHERE rkv.KeyName='FIELD_ACTUALWATERUSAGEPERLOAD' AND rkv.LanguageID=1

UPDATE rkv SET rkv.[Value]='Actual Chemical Cost' FROM TCD.ResourceKeyValue rkv 
WHERE rkv.KeyName='FIELD_ACTUALCHEMICALCOSTPERLOAD' AND rkv.LanguageID=1

UPDATE rkv SET rkv.[Value]='Actual Energy Cost' FROM TCD.ResourceKeyValue rkv 
WHERE rkv.KeyName='FIELD_ACTUALENERGYCOSTPERLOAD_REPORT' AND rkv.LanguageID=1

UPDATE rkv SET rkv.[Value]='Actual Water Cost' FROM TCD.ResourceKeyValue rkv 
WHERE rkv.KeyName='FIELD_ACTUALWATERCOSTPERLOAD' AND rkv.LanguageID=1

UPDATE rkv SET rkv.[Value]='Actual Energy' FROM TCD.ResourceKeyValue rkv 
WHERE rkv.KeyName='FIELD_ACTUALENERGYPERLOAD' AND rkv.LanguageID=1

UPDATE rkv SET rkv.[Value]='Energy Target' FROM TCD.ResourceKeyValue rkv 
WHERE rkv.KeyName='FIELD_ENERGYTARGETPERLOAD' AND rkv.LanguageID=1
GO

IF NOT EXISTS (SELECT 1 FROM tcd.ResourceKeyMaster rkm WHERE rkm.KeyName='View_Change')
BEGIN
INSERT INTO tcd.ResourceKeyMaster
(
    TCD.ResourceKeyMaster.KeyName,
    TCD.ResourceKeyMaster.KeyDescription
)
VALUES
(
    N'View_Change', -- KeyName - nvarchar
    NULL -- KeyDescription - nvarchar
)
END
GO

IF NOT EXISTS (SELECT 1 FROM tcd.ResourceKeyValue rkv WHERE rkv.LanguageID=1 AND rkv.KeyName='View_Change')
BEGIN
INSERT INTO tcd.ResourceKeyValue
(
    [Value],
    LanguageID,
    LastModifiedTime,
    KeyName
)
VALUES
(
    N'View Change',
    1, 
	GETDATE(),
    N'View_Change'
)
END
GO

IF NOT EXISTS (SELECT 1 FROM tcd.ResourceKeyMaster rkm WHERE rkm.KeyName='View_Injections')
BEGIN
INSERT INTO tcd.ResourceKeyMaster
(
    TCD.ResourceKeyMaster.KeyName,
    TCD.ResourceKeyMaster.KeyDescription
)
VALUES
(
    N'View_Injections', -- KeyName - nvarchar
    NULL -- KeyDescription - nvarchar
)
END
GO

IF NOT EXISTS (SELECT 1 FROM tcd.ResourceKeyValue rkv WHERE rkv.LanguageID=1 AND rkv.KeyName='View_Injections')
BEGIN
INSERT INTO tcd.ResourceKeyValue
(
    [Value],
    LanguageID,
    LastModifiedTime,
    KeyName
)
VALUES
(
    N'View Injections',
    1,
    GETDATE(),
    N'View_Injections'
)
END
GO

IF NOT EXISTS (SELECT 1 FROM tcd.ResourceKeyMaster rkm WHERE rkm.KeyName='Substitute_Chemical')
BEGIN
INSERT INTO tcd.ResourceKeyMaster
(
    TCD.ResourceKeyMaster.KeyName,
    TCD.ResourceKeyMaster.KeyDescription
)
VALUES
(
    N'Substitute_Chemical', -- KeyName - nvarchar
    NULL -- KeyDescription - nvarchar
)
END
GO

IF NOT EXISTS (SELECT 1 FROM tcd.ResourceKeyValue rkv WHERE rkv.LanguageID=1 AND rkv.KeyName='Substitute_Chemical')
BEGIN
INSERT INTO tcd.ResourceKeyValue
(
    [Value],
    LanguageID,
    LastModifiedTime,
    KeyName
)
VALUES
(
    N'Substitute Chemical',
    1,
    GETDATE(),
    N'Substitute_Chemical'
)
END
GO

UPDATE TCD.ConfigSettings
SET
    [Value] = N'20'
WHERE KeyName = N'NoOfRecordsToBeProcessed'
    AND [Type] = N'SyncBatchData'
GO


IF EXISTS(SELECT * FROM sys.columns WHERE  object_id = OBJECT_ID(N'TCD.ControllerModelRegionMapping') AND name = 'RegionId')
BEGIN
	ALTER TABLE TCD.ControllerModelRegionMapping ALTER COLUMN RegionId SMALLINT NOT NULL
END
GO

/*Config setting changes*/

DECLARE @temConfigSettings TABLE(KEYNAME NVARCHAR(100),VALUE NVARCHAR(100),[TYPE] NVARCHAR(100), Active BIT)

INSERT INTO @temConfigSettings (KEYNAME, VALUE, [TYPE], Active)
VALUES 
('HostName',	'stg-3dtrasarcontroller.nalco.com',	'SyncAlarmLog',	1),
('PortNumber',	'9340',	'SyncAlarmLog',	1),
('ReceiveTimeout',	'300000',	'SyncAlarmLog',	1),
('TimerEnabled',	'True',	'SyncAlarmLog',	1),
('TimerInterval','900000','SyncAlarmLog',	1),
('TimerAutoReset','True','SyncAlarmLog',	1),
('NoOfRecordsToBeProcessed','20','SyncAlarmLog',	1),
(
    N'FTPUrl', -- KeyName - nvarchar
    N'\\usnaptftp10\TFTP-Root', -- Value - nvarchar
    N'SoftWareUpdate', -- Type - nvarchar
    1 -- Active - bit
),
(
    N'FTPUserId', -- KeyName - nvarchar
    N'', -- Value - nvarchar
    N'SoftWareUpdate', -- Type - nvarchar
    1 -- Active - bit
),
(
    N'FTPPassword', -- KeyName - nvarchar
    N'', -- Value - nvarchar
    N'SoftWareUpdate', -- Type - nvarchar
    1 -- Active - bit
)


MERGE	TCD.ConfigSettings	AS	TARGET
USING	@temConfigSettings	AS	SOURCE
ON	TARGET.KEYNAME		=	SOURCE.KEYNAME
AND	TARGET.[TYPE]			=	SOURCE.[TYPE]
WHEN	NOT MATCHED		THEN
INSERT	(KEYNAME,VALUE,[TYPE],Active)
VALUES	(SOURCE.KEYNAME,SOURCE.VALUE,SOURCE.[TYPE],Source.Active)
WHEN MATCHED THEN
UPDATE SET VALUE = SOURCE.VALUE, Active = Source.Active;

GO

IF EXISTS(SELECT
				    *
			    FROM sys.objects AS o
			    WHERE o.object_id = OBJECT_ID(N'[TCD].[Turntime]')
				AND o.type = N'V')
	BEGIN
		DROP VIEW
				TCD.Turntime;
	END;
GO

CREATE VIEW [TCD].[Turntime]
AS

WITH CTE_TurnTime  
AS (  
SELECT
     ROW_NUMBER() OVER(PARTITION BY BD.ECOLABWASHERID ORDER BY BD.GroupId,BD.MachineId, BD.STARTDATE) AS ROWNUMBER,  
     BD.ECOLABWASHERID,
     BD.BATCHID,
     STARTDATE,
     ENDDATE,
     BD.TARGETTURNTIME , 
     W.DEFAULTIDLETIME,
     BD.GROUPID,
    BD.MachineId
    FROM TCD.BATCHDATA AS BD WITH (NOLOCK)
    INNER JOIN TCD.WASHER AS W           ON BD.MachineId = W.WasherID  
                                                      AND isnull(BD.EcolabWasherId,0) = isnull(W.EcolabWasherId,0)   
     INNER JOIN TCD.WASHERGROUP AS WG     ON WG.WASHERGROUPID=BD.GROUPID  
                                                            AND W.ECOLABACCOUNTNUMBER = WG.ECOLABACCOUNTNUMBER  
     INNER JOIN TCD.MACHINESETUP AS MS    ON MS.GroupId = WG.WasherGroupId  
                                                            AND ms.WasherId = W.WasherId  
                                                            AND w.EcoLabAccountNumber = ms.EcoalabAccountNumber  
    WHERE BD.PROGRAMMASTERID <> 0
    AND WG.WASHERGROUPTYPEID=1
    AND bd.shiftid in(SELECT TOP 3 shiftid FROM tcd.productionshiftdata ORDER BY TCD.productionshiftdata.ShiftId desc)
)  
   
SELECT CurBatch.BATCHID  
, CurBatch.ECOLABWASHERID  
,CurBatch.ENDDATE  
,nextBatch.STARTDATE 
, CurBatch.MachineId
, CASE  
     WHEN ((DATEDIFF(SECOND,CurBatch.ENDDATE,ISNULL(nextBatch.STARTDATE, GETDATE())) <= 0 )or (DATEDIFF(SECOND,CurBatch.ENDDATE,ISNULL(nextBatch.STARTDATE, GETDATE())) > (CurBatch.defaultidletime * 60)) and CurBatch.DefaultIdleTime <>0) 
      --OR DATEDIFF(hh,CurBatch.ENDDATE,ISNULL(nextBatch.STARTDATE, GETDATE())) > 2)  
      THEN nextBatch.TARGETTURNTIME  
      ELSE DATEDIFF(SECOND,CurBatch.ENDDATE, nextBatch.STARTDATE)  
      END AS ActualTurnTime 
FROM CTE_TurnTime CurBatch  
LEFT JOIN CTE_TurnTime nextBatch ON isnull(CurBatch.ECOLABWASHERID,0) = isnull(nextBatch.ECOLABWASHERID,0)
AND CurBatch.MachineId = nextBatch.MachineId
		  AND CurBatch.GROUPID = nextBatch.GROUPID  
AND CurBatch.ROWNUMBER + 1 = nextBatch.ROWNUMBER  

GO

UPDATE rkv SET rkv.[Value]='BTU/Cwt'
 FROM TCD.ResourceKeyValue rkv WHERE lower( rkv.[Value]) LIKE '%BTU/cwt%'
GO

/*Remove Dispenser Version*/
IF EXISTS (SELECT 1 FROM tcd.Field f JOIN tcd.FieldGroupFieldMapping fgfm ON f.Id = fgfm.FieldId AND f.Label = 'Controller Version')
BEGIN
	DELETE FROM tcd.FieldGroupFieldMapping WHERE tcd.FieldGroupFieldMapping.FieldId IN (select Id from tcd.Field WHERE tcd.Field.Label = 'Controller Version')
	DELETE FROM tcd.Field WHERE tcd.Field.Label = 'Controller Version'
END

/*End*/

/*Factor multiplier validation*/
IF NOT EXISTS (SELECT 1 FROM tcd.Field f WHERE f.ClassName= 'factmultiplier')
BEGIN
	UPDATE tcd.Field SET tcd.Field.Name = NULL, tcd.Field.ClassName= 'factmultiplier'  WHERE Label = 'Factors Multiplier'
END
GO
/*End*/


/*Start - Column name Period in time view must be replaced with Interval*/
IF EXISTS (Select 1 FROM TCD.ReportColumnsMapping where ColumnId = 242 and ReportId=10 and ViewById=1)
BEGIN
update TCD.ReportColumnsMapping set ColumnId=262 where ColumnId = 242 and ReportId=10 and ViewById=1
END
IF EXISTS (Select 1 FROM TCD.ReportColumnsMapping where ColumnId = 242 and ReportId=1 and ViewById=1)
BEGIN
update TCD.ReportColumnsMapping set ColumnId=262 where ColumnId = 242 and ReportId=1 and ViewById=1
END
IF NOT EXISTS (SELECT 1 FROM TCD.ReportColumnsRoleMapping where ReportColumnId in (262) and ReportId in (10))
BEGIN
INSERT INTO TCD.ReportColumnsRoleMapping (ReportColumnId, SettingValue, RoleId, ReportId)
SELECT 262, SettingValue, RoleId, ReportId FROM TCD.ReportColumnsRoleMapping where ReportColumnId in (242) and ReportId in (10)
END
IF NOT EXISTS (SELECT 1 FROM TCD.ReportColumnsRoleMapping where ReportColumnId in (262) and ReportId in (1))
BEGIN
INSERT INTO TCD.ReportColumnsRoleMapping (ReportColumnId, SettingValue, RoleId, ReportId)
SELECT 262, SettingValue, RoleId, ReportId FROM TCD.ReportColumnsRoleMapping where ReportColumnId in (242) and ReportId in (1)
END
/*END - Column name Period in time view must be replaced with Interval*/

/*Start - Total" should be replaced with Aggregates*/
IF EXISTS (Select 1 FROM TCD.ReportLocalizationColumnMapping where ReportColumnId=269)
BEGIN
update TCD.ReportLocalizationColumnMapping set UsageKey='FIELD_Aggregates' where ReportColumnId=269
END
IF NOT EXISTS (SELECT 1 FROM TCD.ReportLocalizationColumnMapping where ReportColumnId in (269) and ReportId in (1) and UsageKey='FIELD_Aggregates')
BEGIN
INSERT INTO TCD.ReportLocalizationColumnMapping(ReportColumnId, ReportId, UsageKey)
Values(269,1,'FIELD_Aggregates')
END
/* END - Total" should be replaced with Aggregates*/

/*Start - Language culture code updates  */
IF EXISTS (SELECT 1 FROM TCD.LanguageMaster WHERE  LanguageId=13)
BEGIN 
	UPDATE TCD.LanguageMaster SET Locale='nn-NO', LastModifiedTime=GETDATE() where LanguageId=13
END
IF EXISTS (SELECT 1 FROM TCD.LanguageMaster WHERE  LanguageId=14)
BEGIN 
	UPDATE TCD.LanguageMaster SET Locale='af-ZA', LastModifiedTime=GETDATE() where LanguageId=14
END
IF EXISTS (SELECT 1 FROM TCD.LanguageMaster WHERE  LanguageId=15)
BEGIN 
	UPDATE TCD.LanguageMaster SET Locale='ar-AE', LastModifiedTime=GETDATE() where LanguageId=15
END
IF EXISTS (SELECT 1 FROM TCD.LanguageMaster WHERE  LanguageId=17)
BEGIN 
	UPDATE TCD.LanguageMaster SET Locale='ca-ES', LastModifiedTime=GETDATE() where LanguageId=17
END
IF EXISTS (SELECT 1 FROM TCD.LanguageMaster WHERE  LanguageId=18)
BEGIN 
	UPDATE TCD.LanguageMaster SET Locale='zh-CHT', LastModifiedTime=GETDATE() where LanguageId=18
END
IF EXISTS (SELECT 1 FROM TCD.LanguageMaster WHERE  LanguageId=20)
BEGIN 
	UPDATE TCD.LanguageMaster SET Locale='ca-ES', LastModifiedTime=GETDATE() where LanguageId=20
END
IF EXISTS (SELECT 1 FROM TCD.LanguageMaster WHERE  LanguageId=21)
BEGIN 
	UPDATE TCD.LanguageMaster SET Locale='cs-CZ', LastModifiedTime=GETDATE() where LanguageId=21
END
IF EXISTS (SELECT 1 FROM TCD.LanguageMaster WHERE  LanguageId=22)
BEGIN 
	UPDATE TCD.LanguageMaster SET Locale='da-DK', LastModifiedTime=GETDATE() where LanguageId=22
END
IF EXISTS (SELECT 1 FROM TCD.LanguageMaster WHERE  LanguageId=23)
BEGIN 
	UPDATE TCD.LanguageMaster SET Locale='et-EE', LastModifiedTime=GETDATE() where LanguageId=23
END
IF EXISTS (SELECT 1 FROM TCD.LanguageMaster WHERE  LanguageId=25)
BEGIN 
	UPDATE TCD.LanguageMaster SET Locale='el-GR', LastModifiedTime=GETDATE() where LanguageId=25
END
IF EXISTS (SELECT 1 FROM TCD.LanguageMaster WHERE  LanguageId=26)
BEGIN 
	UPDATE TCD.LanguageMaster SET Locale='he-IL', LastModifiedTime=GETDATE() where LanguageId=26
END
IF EXISTS (SELECT 1 FROM TCD.LanguageMaster WHERE  LanguageId=32)
BEGIN 
	UPDATE TCD.LanguageMaster SET Locale='ms-MY', LastModifiedTime=GETDATE() where LanguageId=32
END
IF EXISTS (SELECT 1 FROM TCD.LanguageMaster WHERE  LanguageId=35)
BEGIN 
	UPDATE TCD.LanguageMaster SET Locale='sr-SP', LastModifiedTime=GETDATE() where LanguageId=35
END
IF EXISTS (SELECT 1 FROM TCD.LanguageMaster WHERE  LanguageId=36)
BEGIN 
	UPDATE TCD.LanguageMaster SET Locale='Lt-sr-SP', LastModifiedTime=GETDATE() where LanguageId=36
END
IF EXISTS (SELECT 1 FROM TCD.LanguageMaster WHERE  LanguageId=38)
BEGIN 
	UPDATE TCD.LanguageMaster SET Locale='sl-SI', LastModifiedTime=GETDATE() where LanguageId=38
END
IF EXISTS (SELECT 1 FROM TCD.LanguageMaster WHERE  LanguageId=39)
BEGIN 
	UPDATE TCD.LanguageMaster SET Locale='sv-FI', LastModifiedTime=GETDATE() where LanguageId=39
END
IF EXISTS (SELECT 1 FROM TCD.LanguageMaster WHERE  LanguageId=42)
BEGIN 
	UPDATE TCD.LanguageMaster SET Locale='uk-UA', LastModifiedTime=GETDATE() where LanguageId=42
END
IF EXISTS (SELECT 1 FROM TCD.LanguageMaster WHERE  LanguageId=43)
BEGIN 
	UPDATE TCD.LanguageMaster SET Locale='fr-CA', LastModifiedTime=GETDATE() where LanguageId=43
END
/*End - Language culture code updates  */

UPDATE cs SET cs.[Value]='stg-3dtrasarcontroller.nalco.com'
FROM TCD.ConfigSettings cs WHERE cs.Type='SyncAlarmLog' AND cs.KeyName='HostName'
UPDATE cs SET cs.[Value]='9340'
FROM TCD.ConfigSettings cs WHERE cs.Type='SyncAlarmLog' AND cs.KeyName='PortNumber'
GO

/*For Max formula injection*/
IF EXISTS (SELECT * FROM tcd.Field f WHERE f.ClassName = 'MaxFormulaInjection' AND Max = 8)
BEGIN
	UPDATE TCD.Field SET TCD.Field.Max = 10 WHERE TCD.Field.ClassName = 'MaxFormulaInjection' AND Max = 8
END
GO

IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='11')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='5' WHERE ID='11'
	END

	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='77')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='7' WHERE ID='77'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='72')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='8' WHERE ID='72'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='19')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='9' WHERE ID='19'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='73')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='10' WHERE ID='73'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='18')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='11' WHERE ID='18'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='74')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='13' WHERE ID='74'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='75')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='15' WHERE ID='75'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='170')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='7' WHERE ID='170'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='165')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='8' WHERE ID='165'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='161')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='9' WHERE ID='161'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='166')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='10' WHERE ID='166'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='160')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='11' WHERE ID='160'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='168')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='15' WHERE ID='168'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='115')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='7' WHERE ID='115'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='110')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='8' WHERE ID='110'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='106')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='9' WHERE ID='106'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='111')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='10' WHERE ID='111'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='105')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='11' WHERE ID='105'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='113')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='15' WHERE ID='113'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='142')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='2' WHERE ID='142'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='143')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='4' WHERE ID='143'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='11')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='5' WHERE ID='11'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='144')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='6' WHERE ID='144'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='147')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='7' WHERE ID='147'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='145')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='8' WHERE ID='145'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='138')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='9' WHERE ID='138'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='137')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='11' WHERE ID='137'
	END
	GO

IF NOT EXISTS(SELECT 1 FROM sys.columns 
            WHERE Name = N'PlantId' AND Object_ID = Object_ID(N'[TCD].[ModuleReading]'))
BEGIN
    ALTER TABLE [TCD].[ModuleReading]
	ADD PlantId INT NULL
END


GO

IF NOT EXISTS(SELECT 1 FROM sys.columns 
            WHERE Name = N'ShiftId' AND Object_ID = Object_ID(N'[TCD].[ModuleReading]'))
BEGIN
    ALTER TABLE [TCD].[ModuleReading]
	ADD ShiftId INT NULL
END

GO

IF NOT EXISTS(SELECT 1 FROM sys.columns 
            WHERE Name = N'PartitionOn' AND Object_ID = Object_ID(N'[TCD].[ModuleReading]'))
BEGIN
    ALTER TABLE [TCD].[ModuleReading]
	ADD PartitionOn SmallDATETIME NULL
END
GO

IF NOT EXISTS(SELECT 1 FROM sys.columns 
            WHERE Name = N'LastSyncTime' AND Object_ID = Object_ID(N'[TCD].[ModuleReading]'))
BEGIN
    ALTER TABLE [TCD].[ModuleReading]
	ADD LastSyncTime DATETIME2 NULL
END
GO

/*
IF  EXISTS(SELECT 1 FROM sys.columns 
            WHERE Name = N'TimeStamp' AND Object_ID = Object_ID(N'[TCD].[ModuleReading]'))
BEGIN
    ALTER TABLE [TCD].[ModuleReading]
	Drop column [TimeStamp]
END
*/
IF  NOT EXISTS(SELECT 1 FROM sys.columns 
            WHERE Name = N'TimeStamp' AND Object_ID = Object_ID(N'[TCD].[ModuleReading]'))
BEGIN
    ALTER TABLE [TCD].[ModuleReading]
	ADD [TimeStamp] [datetime] NULL
END
GO

IF NOT EXISTS (SELECT * FROM TCD.AlarmGroupMsterVsControllerModelType WHERE AlarmGroupMasterId = 156 AND ControllerModelTypeId = 1 AND AlarmCode = 219)
BEGIN
    DECLARE @AlarmGroupMsterVsControllerModelTypeId INT;
    SELECT @AlarmGroupMsterVsControllerModelTypeId = ISNULL(MAX(AlarmGroupMsterVsControllerModelTypeId),1) + 1 FROM TCd.AlarmGroupMsterVsControllerModelType   
 
    INSERT INTO TCD.AlarmGroupMsterVsControllerModelType
    (AlarmGroupMsterVsControllerModelTypeId,AlarmCode,ControllerModelTypeId,DisplayOrder,IsDefault,IsDelete,AlarmGroupMasterId,MachineNumber)
    VALUES 
    (@AlarmGroupMsterVsControllerModelTypeId,219,1,0,0,0,156,9)
END
GO


UPDATE rcm SET rcm.Precision=2
FROM TCD.ReportColumnsMapping rcm WHERE rcm.ReportId=10 AND rcm.ColumnId=146
GO

UPDATE rcm SET rcm.Precision=2
FROM TCD.ReportColumnsMapping rcm WHERE rcm.ReportId=2 AND rcm.ColumnId in( 119,146)
GO

DECLARE @dataType varchar(50)

SELECT @dataType= DATA_TYPE 
FROM INFORMATION_SCHEMA.COLUMNS
WHERE 
     TABLE_NAME = 'ShiftChemicalDataRollup' AND 
     COLUMN_NAME = 'ActualConsumption'

IF(@dataType='decimal')
BEGIN
	IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[TCD].[ShiftChemicalDataRollup]') AND name = N'ChemicalInventoryShift_productId')
  	BEGIN
		drop index [TCD].[ShiftChemicalDataRollup].[ChemicalInventoryShift_productId]
	END
	
	IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[TCD].[ShiftChemicalDataRollup]') AND name = N'IX_ShiftChemicalDataRollup_ShiftId')
	BEGIN
		DROP INDEX [IX_ShiftChemicalDataRollup_ShiftId] ON [TCD].[ShiftChemicalDataRollup]
	END
	
	IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[TCD].[ShiftChemicalDataRollup]') AND name = N'IX_ShiftChemicalDataRollup_ShiftId_MachineId_ProgramId')
	BEGIN
		DROP INDEX [IX_ShiftChemicalDataRollup_ShiftId_MachineId_ProgramId] ON [TCD].[ShiftChemicalDataRollup]
	END
	
	ALTER TABLE [TCD].[ShiftChemicalDataRollup] ALTER COLUMN ActualConsumption float
	ALTER TABLE [TCD].[ShiftChemicalDataRollup] ALTER COLUMN TargetConsumption float

    CREATE NONCLUSTERED INDEX [IX_ShiftChemicalDataRollup_ShiftId] ON [TCD].[ShiftChemicalDataRollup]
	(
		[ShiftId] ASC
	)
	INCLUDE ( 	[MachineId],
	[ProgramMasterId],
	[ProductId],
	[ActualConsumption],
	[TargetConsumption],
	[ActualCost],
	[EcolabTextileId],
	[ChainTextileId],
	[CustomerId]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

  CREATE NONCLUSTERED INDEX [IX_ShiftChemicalDataRollup_ShiftId_MachineId_ProgramId] ON [TCD].[ShiftChemicalDataRollup]
(
	[ShiftId] ASC,
	[MachineId] ASC,
	[ProgramMasterId] ASC
)
INCLUDE ( 	[ActualConsumption],
	[TargetConsumption],
	[ActualCost]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]


  CREATE NONCLUSTERED INDEX [ChemicalInventoryShift_productId] ON [TCD].[ShiftChemicalDataRollup]
(
	[ProductId] ASC
)
INCLUDE ( 	[ShiftId],
	[ActualConsumption]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

END
GO

IF EXISTS (SELECT * FROM tcd.ResourceKeyValue WHERE tcd.ResourceKeyValue.KeyName = 'FIELD_DAYBEFOREOUTOFSTOCK')
BEGIN

UPDATE tcd.ResourceKeyValue
SET
    tcd.ResourceKeyValue.[Value] = 'Inventory Days'
    WHERE tcd.ResourceKeyValue.KeyName = 'FIELD_DAYBEFOREOUTOFSTOCK' AND tcd.ResourceKeyValue.languageID =1

END;
GO

IF  EXISTS (SELECT 1 FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[TCD].[FnConsumptionOnMetrics]') AND type in (N'FN'))
BEGIN
DROP FUNCTION [TCD].[FnConsumptionOnMetrics]
END
GO
CREATE FUNCTION [TCD].[FnConsumptionOnMetrics]
(
	@ValueTobeConverted decimal(18,2) = NULL,
	@Unit  varchar(100) = NULL,
	@UserId int = NULL
)
RETURNS decimal(18,4)
AS
BEGIN
DECLARE @Result float,@UOMId int
SELECT @UOMId =  UM.UOMId FROM TCD.UserMaster AS UM WHERE UM.UserId = @UserId
SELECT @Result = CASE @Unit WHEN 'Volume' THEN CASE @UOMId 
		WHEN 1 THEN @ValueTobeConverted * 0.0078125  -- to be converted to gal as db saving in ounce
		WHEN 2 THEN @ValueTobeConverted * 0.0295735 END
		WHEN 'Weight' THEN CASE @UOMId WHEN 1 THEN @ValueTobeConverted  -- to be converted to gal as db saving in ounce
		WHEN 2 THEN @ValueTobeConverted * 0.453592 END
		END
	RETURN(@Result)
END
GO

--------------------------------------- START of Dynamic UOM Change Script ------------------------------------
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES 
           WHERE TABLE_NAME = N'CurrencySymbol')
BEGIN
	  CREATE TABLE [TCD].[CurrencySymbol](
		[CurrencyCode] [nvarchar](50) NOT NULL,
		[CurrencySymbol] [nvarchar](100) NULL,
		[IsActive] [bit] NULL,
	 CONSTRAINT [PK__CurrencySymbol_CurrencyCode] PRIMARY KEY CLUSTERED 
	(
		[CurrencyCode] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	) ON [PRIMARY]
END


DELETE from [tcd].[CurrencySymbol]
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'AFN', N'?.', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'ALL', N'Lek', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'ANG', N'ƒ', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'ARS', N'$', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'AUD', N'$', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'AWG', N'ƒ', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'BAM', N'KM', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'BBD', N'€', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'BGN', N'??', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'BMD', N'$', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'BND', N'$', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'BOB', N'$b', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'BRL', N'R$', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'BSD', N'$', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'BWP', N'P', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'BYR', N'p.', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'BZD', N'BZ$', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'CAD', N'$', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'CHF', N'CHF', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'CLP', N'$', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'CNY', N'¥', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'COP', N'$', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'CRC', N'¢', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'CUP', N'?', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'CZK', N'Kc', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'DKK', N'kr', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'DOP', N'RD$', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'EEK', N'kr', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'EGP', N'€', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'EUR', N'€', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'FJD', N'$', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'FKP', N'£', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'GBP', N'£', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'GEL', N'?', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'GGP', N'£', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'GHC', N'¢', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'GIP', N'£', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'GTQ', N'Q', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'GYD', N'$', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'HKD', N'$', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'HNL', N'L', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'HRK', N'kn', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'HUF', N'Ft', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'IDR', N'Rp', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'ILS', N'?', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'IMP', N'£', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'INR', N'?', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'IRR', N'?', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'ISK', N'kr', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'JEP', N'£', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'JMD', N'J$', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'JPY', N'¥', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'KGS', N'??', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'KHR', N'?', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'KPW', N'?', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'KRW', N'?', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'KYD', N'$', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'KZT', N'??', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'LAK', N'?', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'LBP', N'£', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'LKR', N'Rs', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'LRD', N'$', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'LTL', N'Lt', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'LVL', N'Ls', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'MKD', N'???', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'MNT', N'?', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'MUR', N'Rs', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'MXN', N'$', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'MYR', N'RM', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'MZN', N'MT', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'NAD', N'$', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'NGN', N'?', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'NIO', N'C$', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'NOK', N'kr', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'NPR', N'Rs', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'NZD', N'$', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'OMR', N'?', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'PAB', N'B/.', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'PEN', N'S/.', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'PHP', N'?', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'PKR', N'?', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'PLN', N'zl', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'PYG', N'Gs', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'QAR', N'?', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'RON', N'lei', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'RSD', N'???.', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'RUB', N'?', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'SAR', N'?', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'SBD', N'$', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'SCR', N'?', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'SEK', N'kr', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'SGD', N'$', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'SHP', N'£', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'SOS', N'S', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'SRD', N'$', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'SVC', N'$', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'SYP', N'£', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'THB', N'?', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'TRL', N'?', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'TTD', N'TT$', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'TVD', N'$', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'TWD', N'NT$', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'UAH', N'?', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'USD', N'$', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'UYU', N'$U', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'UZS', N'??', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'VEF', N'Bs', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'VND', N'?', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'XCD', N'$', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'YER', N'?', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'ZAR', N'S', 1)
INSERT [tcd].[CurrencySymbol] ([CurrencyCode], [CurrencySymbol], [IsActive]) VALUES (N'ZWD', N'Z$', 1)

GO

CREATE TABLE #ReportTranslations(
	[KeyName] [nvarchar](255) NULL,
	[Value in english] [nvarchar](255) NULL,
	[Value in German] [nvarchar](255) NULL,
	[Final German Translation] [nvarchar](255) NULL,
) ON [PRIMARY]
GO

BEGIN TRANSACTION;
INSERT INTO #ReportTranslations([KeyName], [Value in english], [Value in German], [Final German Translation])
SELECT N'FIELD_ACTIONDESCRIPTION', N'Action Description', N'Aktionsbeschreibung', N'Aktionsbeschreibung' UNION ALL
SELECT N'FIELD_ACTIONTYPE', N'Action Type', N'Aktion ', N'Aktion ' UNION ALL
SELECT N'FIELD_ACTUALCHEMICALCONSUMPTION', N'Actual Chemical Consumption', N'Tatsächliche den Chemikalienverbrauch ', N'Produktverbrauch - Ist' UNION ALL
SELECT N'FIELD_ACTUALCHEMICALCOST', N'Actual Chemical Cost', N'Tatsächlichen Kosten Chemical', N'Produktkosten - Ist' UNION ALL
SELECT N'FIELD_ACTUALCHEMICALUSAGE_REPORT', N'Actual Chemical Usage', N'Produktverbrauch - Ist', N'Produktverbrauch - Ist' UNION ALL
SELECT N'FIELD_ACTUALCOST', N'Actual Cost', N'Spezifische Kosten - Ist', N'Spezifische Kosten - Ist' UNION ALL
SELECT N'FIELD_ACTUALCOSTEXCESS', N'Actual Cost excess ', N'Tatsächliche Kosten Überschuss', N'Kostenüberschreitung - Ist' UNION ALL
SELECT N'FIELD_ACTUALENERGY', N'Actual Energy', N'Energieverbrauch - Ist', N'Energieverbrauch - Ist' UNION ALL
SELECT N'FIELD_ACTUALPRODUCTION_REPORTCOLUMN', N'Actual Production', N'Tatsächliche Produktion', N'Produktion - Ist' UNION ALL
SELECT N'FIELD_ACTUALPRODUCTIONPERHOUR_REPORTCOLUMN', N'Actual Production per hour', N'Produktion pro Stunde - Ist', N'Produktion pro Stunde - Ist' UNION ALL
SELECT N'FIELD_ACTUALSPECIFICCHEMICALCOST', N'Actual Chemical Cost', N'Tatsächlichen Kosten Chemical', N'Spezifische Produktkosten - Ist' UNION ALL
SELECT N'FIELD_ACTUALSPECIFICCHEMICALUSAGE', N'Actual Chemical Usage', N'Tatsächlichen Einsatz von Chemikalien', N'Produktverbrauch - Ist' UNION ALL
SELECT N'FIELD_ACTUALSPECIFICCOST', N'Actual Cost', N'Kosten - Ist', N'Kosten - Ist' UNION ALL
SELECT N'FIELD_ACTUALSPECIFICENERGYCOST', N'Actual Energy Cost', N'Spezifische Energiekosten', N'Spezifische Energiekosten' UNION ALL
SELECT N'FIELD_ACTUALSPECIFICENERGYUSAGE', N'Actual Energy Usage', N'Tatsächlichen Energienutzung ', N'Energieverbrauch - Ist' UNION ALL
SELECT N'FIELD_ACTUALSPECIFICLABORCOST', N'Actual Labor Cost ', N'Tatsächlichen Arbeitskosten ', N'Personalkosten - Ist' UNION ALL
SELECT N'FIELD_ACTUALSPECIFICREWASHCOST', N'Actual Rewash Cost ', N'Tatsächlichen Kosten Nachwässerungsschlitz', N'Rückwäschekosten - Ist' UNION ALL
SELECT N'FIELD_ACTUALSPECIFICTOTALCOST', N'Actual Total Cost', N'Tatsächlichen Gesamtkosten ', N'Gesamtkosten - Ist' UNION ALL
SELECT N'FIELD_ACTUALSPECIFICWATERCOST', N'Actual Water Cost', N'Spezifische Wasserkosten', N'Spezifische Wasserkosten' UNION ALL
SELECT N'FIELD_ACTUALSPECIFICWATERUSAGE', N'Actual Water Usage', N'Tatsächliche Wasserverbrauch ', N'Spezifischer Wasserverbrauch - Ist' UNION ALL
SELECT N'FIELD_ACTUALVALUECWT', N'Actual Value ', N'Tatsächlicher Wert', N'Istwert' UNION ALL
SELECT N'FIELD_ACTUALWATERUSAGE', N'Actual Water usage', N'Spezifischer Wasserverbrauch - Ist', N'Spezifischer Wasserverbrauch - Ist' UNION ALL
SELECT N'FIELD_ALARMDESCRIPTION', N'Alarm Description', N'Alarm Meldung', N'Alarm Meldung' UNION ALL
SELECT N'FIELD_ALARMNUMBER', N'Alarm Code', N'Alarm - ID', N'Alarm - ID' UNION ALL
SELECT N'FIELD_AVERAGECONSUMPTIONPERFORMULA', N'Average Consumption per formula', N'Durchschnittlicher Verbrauch pro Formel', N'Durchschnittlicher Verbrauch pro Programm' UNION ALL
SELECT N'FIELD_AVERAGEDAILYCONSUMPTION', N'Average Daily Consumption', N'Tagesverbrauch – Durchschnitt', N'Tagesverbrauch – Durchschnitt' UNION ALL
SELECT N'FIELD_AVGDAILYCOSTPERLOADYTD', N'Avg. Daily Cost Cwt YTD', N'Durchschn. Kosten/Posten YTD', N'Durchschn. Kosten/Posten YTD' UNION ALL
SELECT N'FIELD_AVGDAILYCOSTYTD', N'Avg. Daily Cost YTD', N'Durchschn. Tageskosten YTD', N'Durchschn. Kosten YTD' UNION ALL
SELECT N'FIELD_AVGDAILYNEEDSLY', N'Avg. Daily Needs LY', N'Durchschn. Täglichen Bedarfs LY', N'Durchschn. Tagesbedarf LY' UNION ALL
SELECT N'FIELD_AVGDAILYNEEDSYTD', N'Avg. Daily Needs YTD', N'Durchn. Tagesbedarf YTD', N'Durchn. Tagesbedarf YTD' UNION ALL
SELECT N'FIELD_AVGRUNTIME', N'Avg. Run Time', N'Durchschn. Laufzeit ', N'Durchschn. Laufzeit ' UNION ALL
SELECT N'FIELD_AVGSTANDARDTRANSFERHOUR', N'Avg.Standard Transfer/Hour', N'Avg.Standard Transfer / Stunde', N'Takte pro Stunde - Soll' UNION ALL
SELECT N'FIELD_AVGSTANDARDTURNTIME', N'Avg.Standard Turn Time', N'Avg.Standard Drehen Zeit', N'Rüstzeit - Soll' UNION ALL
SELECT N'FIELD_AVGTURNTIME', N'Avg. Turn Time', N'Durchschn. Drehen Sie Zeit', N'Rüstzeit - Ist' UNION ALL
SELECT N'FIELD_BATCHNUMBER', N'Batch Number', N'Chargennummer', N'Postennummer' UNION ALL
SELECT N'FIELD_CATEGORIES', N'Categories', N'Kategorien', N'Kategorien' UNION ALL
SELECT N'FIELD_CHAINCATEGORIES_REPORT', N'Formula Categories', N'Formel-Kategorien', N'Verfahrenskategorien' UNION ALL
SELECT N'FIELD_CHEMICALCOST_REPORT', N'Chemical Cost', N'Chemische Kosten', N'Chemiekosten' UNION ALL
SELECT N'FIELD_CHEMICALCOSTMIX_REPORT', N'Chemical Cost Mix', N'Chemische Kosten Mix', N'Chemiekosten Mix' UNION ALL
SELECT N'FIELD_CHEMICALCOSTPERPIECES', N'Chemical Cost per Pieces', N'Chemische Kosten pro Stück', N'Chemiekosten je Stück' UNION ALL
SELECT N'FIELD_CHEMICALNAME', N'Chemical Name', N'Chemischer Name', N'Produkt Name' UNION ALL
SELECT N'FIELD_CHEMICALS', N'Chemicals', N'Chemikalien', N'Produkte' UNION ALL
SELECT N'FIELD_COMMENTS', N'Comments', N'Bemerkungen', N'Bemerkungen' UNION ALL
SELECT N'FIELD_CONSUMPTION', N'Consumption', N'Verbrauch', N'Verbrauch' UNION ALL
SELECT N'FIELD_CORPORATE_ACCOUNT', N'Corporate', N'Firmen-', N'Kundengruppe' UNION ALL
SELECT N'FIELD_COSTEXCESS', N'Cost Excess', N'Kosten Excess', N'Kostenüberschreitung' UNION ALL
SELECT N'FIELD_COUNTRY', N'Country', N'Land', N'Land' UNION ALL
SELECT N'FIELD_CUSTOMERNAME', N'Customer Name', N'Kundenname', N'Kundenname' UNION ALL
SELECT N'FIELD_DAILYCONSUMPTIONSINCELASTINVENTORY', N'Daily Consumption since Last Inventory', N'Tagesverbrauch seit dem letzten Bestands', N'Tagesverbrauch seit der letzten Inventur' UNION ALL
SELECT N'FIELD_DATE', N'Date', N'Datum', N'Datum'
COMMIT;
RAISERROR (N'#ReportTranslations: Insert Batch: 1.....Done!', 10, 1) WITH NOWAIT;
GO

BEGIN TRANSACTION;
INSERT INTO #ReportTranslations([KeyName], [Value in english], [Value in German], [Final German Translation])
SELECT N'FIELD_DATEANDTIME', N'Date And Time', N'Datum & Uhrzeit', N'Datum & Uhrzeit' UNION ALL
SELECT N'FIELD_DATERANGE', N'Date Range', N'Zeitraum', N'Zeitraum' UNION ALL
SELECT N'FIELD_DAYBEFORENEWORDERREQUIRED', N'Days before new order required', N'Tage vor dem neuen Auftrag erforderlich', N'Tage vor neuer erforderlicher Bestellung' UNION ALL
SELECT N'FIELD_DAYBEFOREOUTOFSTOCK', N'Day before out of stock', N'Produktionstage bis Leer', N'Produktionstage bis Leer' UNION ALL
SELECT N'FIELD_DAYS_FROM_LAST_VISIT', N'Days From Last Visit', N'Tage Von Letzter Besuch', N'Tage vom letzten Besuch' UNION ALL
SELECT N'FIELD_DESCRIPTION', N'Description', N'Beschreibung', N'Beschreibung' UNION ALL
SELECT N'FIELD_DESIREDVALUE', N'Desired Value', N'Sollwert ', N'Sollwert ' UNION ALL
SELECT N'FIELD_DISPENCER', N'Dispenser', N'Spender', N'Dosiergerät' UNION ALL
SELECT N'FIELD_DISPENSERBASEDCONSUMPTION', N'Dispenser based Consumption', N'Dosieranlagen basierter Verbrauch', N'Dosieranlagen basierter Verbrauch' UNION ALL
SELECT N'FIELD_DOSAGE', N'Dosage', N'Dosierung', N'Dosierung' UNION ALL
SELECT N'FIELD_DURATION', N'Duration', N'Dauer', N'Dauer' UNION ALL
SELECT N'FIELD_ECOLABCATEGORIES_REPORT', N'Formula Segment', N'Programm-Segment', N'Programm-Segment' UNION ALL
SELECT N'FIELD_ENDDATETIME', N'End Date & Time', N'End Date & Time', N'Ende Datum & Zeit' UNION ALL
SELECT N'FIELD_ENERGYCOST', N'Energy Cost', N'Energiekosten', N'Energiekosten' UNION ALL
SELECT N'FIELD_ENERGYCOSTPERPIECES', N'Energy Cost per Pieces', N'Energiekosten pro Stück', N'Energiekosten pro Stück' UNION ALL
SELECT N'FIELD_ESTIMATEDINVENTORY', N'Estimated Inventory', N'Geschätzte Bestands', N'Geschätzter Bestand' UNION ALL
SELECT N'FIELD_EXCESSCHEMICALCOST', N'Excess Chemical Cost', N'Überschüssiges Chemical Kosten', N'Überschreitung Produktkosten' UNION ALL
SELECT N'FIELD_EXCESSRUNTIME', N'Excess Run Time', N'Überschüssiges Laufzeit ', N'Überschreitung Laufzeit' UNION ALL
SELECT N'FIELD_EXCESSTURNTIME', N'Excess Turn Time', N'Überschüssiges Wendezeit ', N'Überschreitung Rüstzeit' UNION ALL
SELECT N'FIELD_FLATFEE', N'Flat Fee', N'Pauschalgebühr', N'Flat Fee' UNION ALL
SELECT N'FIELD_FORMULA_CATEGORY', N'Formula Category', N'Formel-Kategorie', N'Programm Kategorie' UNION ALL
SELECT N'FIELD_FORMULA_NAME', N'Formula Name', N'Formelname ', N'Programmname' UNION ALL
SELECT N'FIELD_FORMULAMIX', N'Formula Mix', N'Formel-Mix', N'Programmmix' UNION ALL
SELECT N'FIELD_FORMULANUMBER', N'Formula Number', N'Formel-Nummer', N'Programmnummer' UNION ALL
SELECT N'FIELD_FORMULAS', N'Formulas', N'Formeln', N'Programme' UNION ALL
SELECT N'FIELD_HOLDTIME', N'Hold Time', N'Haltezeit', N'Haltezeit' UNION ALL
SELECT N'FIELD_HOLDTIME*', N'Hold Time *', N'Haltezeit *', N'Haltezeit *' UNION ALL
SELECT N'FIELD_HOLDTIMEINFLUENCE', N'Hold Time influence', N'Hold Time Einfluss', N'Einfluss der Haltezeit' UNION ALL
SELECT N'FIELD_INCHARGE', N'In Charge', N'Verantwortlich', N'Verantwortlich' UNION ALL
SELECT N'FIELD_INJECTION', N'Injection #', N'Injection #', N'Dosierstelle' UNION ALL
SELECT N'FIELD_INTERVAL_REPORT', N'Interval', N'Intervall', N'Zeitraum' UNION ALL
SELECT N'FIELD_INVENTORYBASEDCONSUMPTION', N'Inventory based Consumption', N'Inventar basierter Verbrauch', N'Inventar basierter Verbrauch' UNION ALL
SELECT N'FIELD_LABORCOST', N'Labor Cost', N'Stundenlohn', N'Stundenlohn' UNION ALL
SELECT N'FIELD_LABORCOSTPERPIECES', N'Labor Cost Per Pieces', N'Arbeitskosten pro Stück', N'Lohnkosten pro Stück' UNION ALL
SELECT N'FIELD_LASTACTUALINVENTORY', N'Last Actual Inventory', N'Letzte Ist-Bestand', N'Letzter Ist-Bestand' UNION ALL
SELECT N'FIELD_LASTINVENTORY', N'Last Inventory', N'Letzte Bestands', N'Letzte Inventur' UNION ALL
SELECT N'FIELD_LASTINVENTORYDATE', N'Last Inventory Date', N'Letzte Inventurdatum ', N'Letztes Inventurdatum ' UNION ALL
SELECT N'FIELD_LOADEFFICIENCY_REPORT', N'Load Efficiency', N'Beladungs Effizienz', N'Beladungs Effizienz' UNION ALL
SELECT N'FIELD_LOADNUMBER', N'Load #', N'Belastung #', N'Postennummer' UNION ALL
SELECT N'FIELD_LOCATION', N'Location', N'Verbraucher', N'Verbraucher' UNION ALL
SELECT N'FIELD_MEASUREDVALUE', N'Measured Value', N'Messwert', N'Messwert' UNION ALL
SELECT N'FIELD_METERNAME', N'Meter Name', N'Zähler Name', N'Zähler Name' UNION ALL
SELECT N'FIELD_MISSEDLOAD', N'Missed load', N'Verpasste Last', N'Entgangene Posten' UNION ALL
SELECT N'FIELD_MISSEDLOADCOST', N'Lost Poundage Cost', N'Verlorene poundage Kosten', N'Mehrkosten wg. entgangener Posten' UNION ALL
SELECT N'FIELD_MISSEDLOADS', N'Lost Poundage', N'Verlorene poundage', N'Entgangenes Gewicht' UNION ALL
SELECT N'FIELD_MISSEDLOADSNBR', N'Missed Loads (Nbr)', N'Verpasste Lasten (NBR)', N'Entgangene Posten' UNION ALL
SELECT N'FIELD_MONTHLYCONSUMPTIONSINCELASTINVENTORY', N'Monthly Consumption since last Inventory', N'Monatsverbrauch seit dem letzten Bestands', N'Monatsverbrauch seit der letzten Inventur' UNION ALL
SELECT N'FIELD_NEXT_VISIT', N'Next Visit', N'Weiter besuchen', N'Nächster Termin Service-Besuch' UNION ALL
SELECT N'FIELD_NOOFALARMS', N'No. of Alarms', N'Anzahl der Alarme', N'Anzahl der Alarme' UNION ALL
SELECT N'FIELD_NOOFLOADS_REPORTCOLUMN', N'No. of Loads', N'Anzahl der Posten', N'Anzahl der Posten'
COMMIT;
RAISERROR (N'#ReportTranslations: Insert Batch: 2.....Done!', 10, 1) WITH NOWAIT;
GO

BEGIN TRANSACTION;
INSERT INTO #ReportTranslations([KeyName], [Value in english], [Value in German], [Final German Translation])
SELECT N'FIELD_NOOFPIECES', N'No. of Pieces', N'Anzahl der Stücke', N'Anzahl der Stücke' UNION ALL
SELECT N'FIELD_NOOFREJECTEDLOADS', N'No. of Rejected Loads', N'Anzahl der Zurückgewiesen Lasten', N'Anzahl der aussortierten Posten' UNION ALL
SELECT N'FIELD_ORDERSRECEIVED', N'Orders Received', N'Auftragseingang', N'Auftragseingang' UNION ALL
SELECT N'FIELD_OTHERS', N'Others', N'Andere', N'Andere' UNION ALL
SELECT N'FIELD_PLANTNAME', N'Plant Name', N'Anlagenname ', N'Anlagenname ' UNION ALL
SELECT N'FIELD_PLANTOPERATIONALTIME', N'Plant Operational Time ', N'Anlagenbetriebszeit ', N'Anlagenbetriebszeit ' UNION ALL
SELECT N'FIELD_PRODUCTION', N'Production', N'Produktions Berichte', N'Produktions Berichte' UNION ALL
SELECT N'FIELD_PRODUCTIONLOADS/HR', N'Production Loads /hr', N'Die Produktion von Lasten / hr', N'Anzahl Posten je Stunde' UNION ALL
SELECT N'FIELD_PRODUCTIONMIX_REPORT', N'Production Mix', N'Produktions - Mix', N'Produktions - Mix' UNION ALL
SELECT N'FIELD_PUMPVALVENUMBER', N'Pump/Valve #', N'Pumpe / Ventil #', N'Pumpe-/Ventilnummer' UNION ALL
SELECT N'FIELD_RedFlags', N'Red Flags (Last Week)', N'Red Flags (letzte Woche)', N'Red Flag' UNION ALL
SELECT N'FIELD_REJECTEDLOADS', N'Rejected Loads', N'Abgelehnt Lasten', N'Aussortierte Posten' UNION ALL
SELECT N'FIELD_REWASH', N'Rewash', N'Rückwäsche', N'Rückwäsche' UNION ALL
SELECT N'FIELD_REWASHCOST', N'Rewash Cost', N'Nachwässerungsschlitz Kosten', N'Kosten Nachwäsche' UNION ALL
SELECT N'FIELD_REWASHCOSTPERPIECES', N'Rewash Cost Per Pieces', N'Nachwässerungsschlitz Kosten pro Stück', N'Kosten Nachwäsche pro Stück' UNION ALL
SELECT N'FIELD_REWASHLOAD', N'Rewash Load', N'Nachwässerungsschlitz Last', N'Nachwäsche Gewicht' UNION ALL
SELECT N'FIELD_RUNTIME', N'Run Time', N'Laufzeit ', N'Laufzeit ' UNION ALL
SELECT N'FIELD_RUNTIMEEFFICIENCY', N'Run Time Efficiency', N'Run Time Efficiency', N'Auslastung Laufzeit' UNION ALL
SELECT N'FIELD_STANDARDRUNTIME', N'Standard Run Time', N'Standard-Laufzeit ', N'Standard-Laufzeit ' UNION ALL
SELECT N'FIELD_STANDARDTRANSFER', N'Standard Transfer', N'Standard-Überweisung ', N'Standard-Transfer' UNION ALL
SELECT N'FIELD_STANDARDTRANSFERHOUR', N'Standard Transfer/Hour', N'Standard-Transfer / Stunde', N'Standard-Transfer je Stunde' UNION ALL
SELECT N'FIELD_STANDARDTURNTIME', N'Standard Turn Time', N'Standard-Wendezeit ', N'Standard Rüstzeit' UNION ALL
SELECT N'FIELD_STARTDATETIME', N'Start Date & Time', N'Starten Sie Datum und Uhrzeit', N'Start Datum und Uhrzeit' UNION ALL
SELECT N'FIELD_STATUS', N'Status', N'Status', N'Status' UNION ALL
SELECT N'FIELD_TARGETCHEMICALCONSUMPTION', N'Target Chemical Consumption', N'Ziel den Chemikalienverbrauch ', N'Produktverbrauch - Soll' UNION ALL
SELECT N'FIELD_TARGETCHEMICALCOST', N'Standard Chemical Cost', N'Norm Chemische Kosten', N'Produktkosten - Soll' UNION ALL
SELECT N'FIELD_TARGETCHEMICALUSAGE', N'Standard Chemical Usage', N'Standard-Chemikalienverbrauch ', N'Produktverbrauch - Soll' UNION ALL
SELECT N'FIELD_TARGETCONSUMPTION', N'Target Consumption', N'Ziel Verbrauch', N'Verbrauch - Soll' UNION ALL
SELECT N'FIELD_TARGETCOST', N'Standard Chemical Cost', N'Norm Chemische Kosten', N'Produktkosten - Soll' UNION ALL
SELECT N'FIELD_TARGETPRODUCTION', N'Standard Production', N'Produktion - Soll', N'Produktion - Soll' UNION ALL
SELECT N'FIELD_TARGETPRODUCTIONPERHOUR_REPORTCOLUMN', N'Standard Production per hour', N'Produktion pro Stunde - Soll', N'Produktion pro Stunde - Soll' UNION ALL
SELECT N'FIELD_TARGETSPECIFICCHEMICALCOST', N'Target Chemical Cost ', N'Ziel Chemical Kosten', N'Produktkosten - Soll' UNION ALL
SELECT N'FIELD_TARGETSPECIFICCHEMICALUSAGE', N'Standard Chemical Usage', N'Standard-Chemikalienverbrauch ', N'Produktverbrauch - Soll' UNION ALL
SELECT N'FIELD_TARGETSPECIFICENERGYCOST', N'Target Energy Cost ', N'Zielenergiekosten ', N'Energiekosten - Soll' UNION ALL
SELECT N'FIELD_TARGETSPECIFICENERGYUSAGE', N'Standard Energy Usage', N'Standard-Energie-Verbrauch', N'Energieverbaruch - Soll' UNION ALL
SELECT N'FIELD_TARGETSPECIFICLABORCOST', N'Target Labor Cost ', N'Zielarbeitskosten ', N'Arbeitskosten - Soll' UNION ALL
SELECT N'FIELD_TARGETSPECIFICTOTALCOST', N'Target Total Cost ', N'Zielgesamtkosten ', N'Gesamtkosten - Soll' UNION ALL
SELECT N'FIELD_TARGETSPECIFICWATERCOST', N'Target Water Cost ', N'Ziel Wasser Kosten', N'Wasserkosten - Soll' UNION ALL
SELECT N'FIELD_TARGETSPECIFICWATERUSAGE', N'Standard Water Usage', N'Standard-Wasserverbrauch ', N'Wasserverbrauch - Soll' UNION ALL
SELECT N'FIELD_TEXTILECATEGORIES_REPORT', N'Textile Categories', N'Textile Kategorien', N'Verfahrenskategorien' UNION ALL
SELECT N'FIELD_TIMEEFFICIENCY', N'Time Efficiency', N'Zeiteffizienz ', N'Zeiteffizienz ' UNION ALL
SELECT N'FIELD_TODAYESTIMATEINVENTORY', N'Today estimate inventory', N'Geschätztes Inventar - heute', N'Geschätztes Inventar - heute' UNION ALL
SELECT N'FIELD_TOTAL', N'TOTAL', N'TOTAL LBS', N'GESAMT PRODUKTION' UNION ALL
SELECT N'FIELD_TOTALCHEMICALCOST', N'Total Chemical Cost', N'Insgesamt Chemical Kosten', N'Produktkosten - Gesamt' UNION ALL
SELECT N'FIELD_TOTALCONSUMPTION', N'Total Consumption', N'Gesamt Verbrauch ', N'Gesamt Verbrauch' UNION ALL
SELECT N'FIELD_TOTALCOST', N'Total Cost', N'Gesamtkosten', N'Gesamtkosten' UNION ALL
SELECT N'FIELD_TOTALCOSTPERPIECE', N'Total Cost Per Piece', N'Gesamtkosten pro Stück', N'Gesamtkosten pro Stück' UNION ALL
SELECT N'FIELD_TOTALEFFICIENCY', N'Total Efficiency', N'Gesamteffizienz', N'Gesamteffizienz' UNION ALL
SELECT N'FIELD_TOTALWATERCOST', N'Total Water Cost', N'Gesamtwasserkosten ', N'Wasserkosten - Gesamt' UNION ALL
SELECT N'FIELD_TRANSFER/HOUR', N'Transfer / Hour', N'Transfer / Stunde', N'Transfer / Stunde'
COMMIT;
RAISERROR (N'#ReportTranslations: Insert Batch: 3.....Done!', 10, 1) WITH NOWAIT;
GO

BEGIN TRANSACTION;
INSERT INTO #ReportTranslations([KeyName], [Value in english], [Value in German], [Final German Translation])
SELECT N'FIELD_TURNTIME', N'Turn Time', N'Drehen Sie Zeit', N'Rüstzeit' UNION ALL
SELECT N'FIELD_TURNTIMEEFFICIENCY', N'Turn Time Efficiency', N'Drehen Zeiteffizienz ', N'Rüstzeit - Effizienz' UNION ALL
SELECT N'FIELD_UOM', N'UOM', N'UOM', N'Einheit' UNION ALL
SELECT N'FIELD_USERNAME', N'User Name', N'Benutzername', N'Benutzername' UNION ALL
SELECT N'FIELD_WASHERNUMBER', N'Washer Number', N'Waschmaschine Anzahl', N'Maschinenanzahl' UNION ALL
SELECT N'FIELD_WATERCOST', N'Water Cost', N'Wasser Kosten', N'Wasserkosten' UNION ALL
SELECT N'FIELD_WATERCOSTPERPIECES', N'Water Cost Per Pieces', N'Wasser Kosten pro Stück', N'Wasserkosten pro Stück' UNION ALL
SELECT N'FIELD_WEEKLYCONSUMPTIONSINCELASTINVENTORY', N'Weekly Consumption since last Inventory', N'Wochenverbrauch seit dem letzten Bestands', N'Wochenverbrauch seit der letzten Inventur' UNION ALL
SELECT N'ACCOUNT_SUMMARY_REPORT', N'Account Summary', N'Kontoübersicht', N'Zusammenfassung' UNION ALL
SELECT N'FIELD_ALARMDETAILS', N'Alarms Details', N'Alarme - Details', N'Alarme - Details' UNION ALL
SELECT N'FIELD_ALARMSSUMMARY', N'Alarms Summary', N'Alarme - Zusammenfassung', N'Alarme - Zusammenfassung' UNION ALL
SELECT N'FIELD_BOILERKPIS', N'Boilers KPIs', N'Kessel KPIs', N'Kessel - Leistungsdaten' UNION ALL
SELECT N'FIELD_CHEMICAL CONSUMPTION', N'Chemical Consumption', N'Produktverbräuche', N'Produktverbräuche' UNION ALL
SELECT N'FIELD_CHEMICALINVENTORY', N'Chemical Inventory', N'Produkte - Inventar', N'Produkte - Inventar' UNION ALL
SELECT N'FIELD_COSTBYFORMULA', N'Cost by Formula', N'Die Kosten durch die Formel', N'Verfahrenskosten' UNION ALL
SELECT N'FIELD_COSTSSUMMARY', N'Costs Summary', N'Kosten Zusammenfassung', N'Kostenzusammenfassung' UNION ALL
SELECT N'FIELD_DRYERSKPIS', N'Dryers KPIs', N'Trockner KPIs', N'Trockner - Leistungsdaten' UNION ALL
SELECT N'FIELD_EFFICIENCYBYFORMULA', N'Efficiency by Formula', N'Effizienz durch die Formel', N'Verfahrenseffizienz' UNION ALL
SELECT N'FIELD_EFFICIENCYBYMACHINE', N'Efficiency by Machine', N'Effizienz durch Maschinen', N'Maschinenauslastung' UNION ALL
SELECT N'FIELD_EFFICIENCYWASHINGEQUIPMENT', N'Efficiency Washing Equipment', N'Effizienz-Waschanlagen ', N'Maschinenauslastung' UNION ALL
SELECT N'FIELD_FFEVALUATION', N'FF evaluation', N'FF Auswertung', N'Flat Fee Auswertung' UNION ALL
SELECT N'FIELD_INITIATIVESTRACKING', N'Initiatives tracking', N'Initiativen Tracking', N'Projektnachverfolgung' UNION ALL
SELECT N'FIELD_MACHINEHOLDTIME', N'Machine Hold Time', N'Maschine Haltezeit ', N'Stillstandszeit' UNION ALL
SELECT N'FIELD_METERS', N'Meters', N'Meters', N'Zähler' UNION ALL
SELECT N'FIELD_MYSERVICEACTIONLIST', N'MyService Action List', N'MyService Aktionsliste ', N'myService-Aktionsliste' UNION ALL
SELECT N'FIELD_OPERATIONDETAIL', N'Operations Detail', N'Betriebsbeschreibung', N'Betriebsdetails' UNION ALL
SELECT N'FIELD_OPERATIONS SUMMARY', N'Operations Summary', N'Operationen Zusammenfassung', N'Kosten Zusammenfassung' UNION ALL
SELECT N'FIELD_PERIODPRODUCTION', N'Period Production', N'Zeitraum Produktion', N'Produktionszeitraum' UNION ALL
SELECT N'FIELD_PROCESSVALIDATIONDETAILS', N'Process Validation Details', N'Prozessvalidierung Einzelheiten', N'Prozessvalidierungsdetails' UNION ALL
SELECT N'FIELD_PRODUCTION DETAILS', N'Production Details', N'Produktion - Details', N'Produktion - Details' UNION ALL
SELECT N'FIELD_PRODUCTION SUMMARY', N'Production Summary', N'Produktion Zusammenfassung - Gruppe', N'Produktion Zusammenfassung - Gruppe' UNION ALL
SELECT N'FIELD_PRODUCTIONMIX_REPORT', N'Production Mix', N'Produktions - Mix', N'Produktions - Mix' UNION ALL
SELECT N'FIELD_REDFALGS', N'Red Flags', N'Rote Flaggen', N'Red Flag' UNION ALL
SELECT N'FIELD_REJECTEDBATCHES', N'Rejected Batches', N'Abgelehnt Batches', N'Fehlerhafte Posten' UNION ALL
SELECT N'FIELD_REWASH', N'Rewash', N'Nachwässerungsschlitz', N'Rückwäsche' UNION ALL
SELECT N'FIELD_TMSUMMARY', N'Service Preparation', N'Service-Vorbereitung', N'Service-Vorbereitung' UNION ALL
SELECT N'FIELD_USERLOG', N'User log', N'Benutzer Log ', N'Benutzer Log' UNION ALL
SELECT N'FIELD_W&ERECOVERY', N'W&E Recovery', N'W & E Erholung', N'W&E-Einsparungen' UNION ALL
SELECT N'FIELD_WASHINGPROGRAMDETAILS', N'Washing Programs Details', N'Spülprogramme Einzelheiten', N'Waschprogrammdetails' UNION ALL
SELECT N'FIELD_CHAINCATEGORIES_REPORT', N'Formula Categories', N'Formel-Kategorien', N'Verfahrenskategorien' UNION ALL
SELECT N'FIELD_CUSTOMER', N'Plant Customer', N'End Kunde', N'End Kunde' UNION ALL
SELECT N'FIELD_ECOLABCATEGORIES_REPORT', N'Formula Segment', N'Formel-Segment', N'Verfahrenssegment' UNION ALL
SELECT N'FIELD_FORMULA', N'Formula', N'Programm', N'Programm' UNION ALL
SELECT N'FIELD_FORMULAS', N'Formulas', N'Formeln', N'Verfahren' UNION ALL
SELECT N'FIELD_LOCATION', N'Location', N'Verbraucher', N'Verbraucher' UNION ALL
SELECT N'FIELD_TEXTILECATEGORIES_REPORT', N'Textile Categories', N'Textile Kategorien', N'Verfahrenskategorien' UNION ALL
SELECT N'FIELD_TIME', N'Time', N'Zeitraum', N'Zeitraum' UNION ALL
SELECT N'ACCOUNT_SUMMARY_REPORT', N'Account Summary', N'Kontoübersicht', N'Kundenzusammenfassung' UNION ALL
SELECT N'FIELD_ACCOUNTSUMMARY', N'Account Summary', N'Kontoübersicht', N'Kundenzusammenfassung' UNION ALL
SELECT N'FIELD_ACTUALPRODUCTIONPERDAY', N'Actual Production / Day', N'Die tatsächliche Produktion / Tag', N'Istproduktion je Tag'
COMMIT;
RAISERROR (N'#ReportTranslations: Insert Batch: 4.....Done!', 10, 1) WITH NOWAIT;
GO

BEGIN TRANSACTION;
INSERT INTO #ReportTranslations([KeyName], [Value in english], [Value in German], [Final German Translation])
SELECT N'FIELD_ADDMOREFILTERS', N'Add More Filters', N'Hinzufügen Mehr Filter', N'Filter hinzufügen' UNION ALL
SELECT N'FIELD_ADMIN', N'Admin', N'Administrator', N'Administrator' UNION ALL
SELECT N'FIELD_AGGREGATES', N'Aggregates', N'Gesamt', N'Gesamt' UNION ALL
SELECT N'FIELD_ALLRIGHTSRESERVED', N'Ecolab All rights reserved', N'Ecolab Alle Rechte vorbehalten', N'Ecolab Alle Rechte vorbehalten' UNION ALL
SELECT N'FIELD_APPLY', N'Apply', N'	Übernehmen', N'	Übernehmen' UNION ALL
SELECT N'FIELD_ASONTODAY', N'As on today', N'Wie heute', N'Wie heute' UNION ALL
SELECT N'FIELD_AVERAGE', N'Average', N'Durchschnittlich', N'Durchschnittlich' UNION ALL
SELECT N'FIELD_CANCEL', N'Cancel', N'Abbr.', N'Abbr.' UNION ALL
SELECT N'FIELD_CHANGE', N'Change', N'Veränderung', N'Veränderung' UNION ALL
SELECT N'FIELD_CHARTDISPLAYMODE', N'Chart Display Mode', N'Chart Display-Modus', N'Grafikmodus' UNION ALL
SELECT N'FIELD_COLUMNS', N'Columns', N'Spalten - Auswahl', N'Spalten - Auswahl' UNION ALL
SELECT N'FIELD_COMPARE', N'Compare', N'Vergleichen', N'Vergleichen' UNION ALL
SELECT N'FIELD_CORPORATE_ACCOUNT', N'Corporate', N'Firmen-', N'Kundengruppe' UNION ALL
SELECT N'FIELD_COUNTRY', N'Country', N'Land', N'Land' UNION ALL
SELECT N'FIELD_CURRENT', N'Current', N'Aktuell', N'Aktuell' UNION ALL
SELECT N'FIELD_CURRENTVIEW', N'Current View', N'Aktuelle Ansicht', N'Aktuelle Ansicht' UNION ALL
SELECT N'FIELD_CUSTOM', N'Custom', N'Frei Definiert', N'Frei Definiert' UNION ALL
SELECT N'FIELD_CUSTOMER', N'Plant Customer', N'End Kunde', N'End Kunde' UNION ALL
SELECT N'FIELD_DATERANGE', N'Date Range', N'Zeitraum', N'Zeitraum' UNION ALL
SELECT N'FIELD_DAY', N'Day', N'Tag', N'Tag' UNION ALL
SELECT N'FIELD_DAYS_FROM_LAST_VISIT', N'Days From Last Visit', N'Tage Von Letzter Besuch', N'Tage seit letztem Besuch' UNION ALL
SELECT N'FIELD_DRILLDOWNLEVEL', N'Drilldown level', N'aufreißen Ebene', N'Ebenen anzeigen' UNION ALL
SELECT N'FIELD_EDIT', N'Edit', N'Bearbeiten', N'Bearbeiten' UNION ALL
SELECT N'FIELD_EXPORTEDBY', N'Exported By', N'Exportierte von', N'Exportiert von' UNION ALL
SELECT N'FIELD_EXPORTEDDATE', N'Exported Date', N'Exportierte Datum', N'Exportdatum' UNION ALL
SELECT N'FIELD_EXPORTTOEXCEL', N'Export to Excel', N'Nach Excel exportieren', N'Nach Excel exportieren' UNION ALL
SELECT N'FIELD_EXPORTTOPDF', N'Export to PDF', N'Export in PDF', N'Export in PDF' UNION ALL
SELECT N'FIELD_FILTERS', N'Filters', N'Filter', N'Filter' UNION ALL
SELECT N'FIELD_FLATFEE', N'Flat Fee', N'Pauschalgebühr', N'Flat Fee' UNION ALL
SELECT N'FIELD_FORMULACATEGORY', N'Formula Category', N'Programm Kategorie', N'Programm Kategorie' UNION ALL
SELECT N'FIELD_FORMULASEGMENT', N'Formula Segment', N'Programm Segment', N'Programm Segment' UNION ALL
SELECT N'FIELD_GRAPH', N'Graph', N'Graph', N'Grafik' UNION ALL
SELECT N'FIELD_GROUPBY', N'Group By', N'Gruppieren pro', N'Gruppieren pro' UNION ALL
SELECT N'FIELD_INDICATESACTUALLESSTHAN90PERCENTOFTARGET', N'Indicates Actual < 90% of Target', N'Achtung: Rot bedeutet Ist < 90% unter Soll', N'Achtung: Rot bedeutet Ist < 90% unter Soll' UNION ALL
SELECT N'FIELD_ITEM', N'Item', N'Artikel', N'Artikel' UNION ALL
SELECT N'FIELD_ITEM_DESCRIPTION', N'Item Description', N'Artikelbeschreibung', N'Artikelbeschreibung' UNION ALL
SELECT N'FIELD_LAST4WEEKS', N'Last 4 Weeks', N'Letzte 4 Wochen', N'Letzte 4 Wochen' UNION ALL
SELECT N'FIELD_LASTINVENTORYDATE', N'Last Inventory Date', N'Letzte Inventurdatum ', N'Letztes Inventurdatum' UNION ALL
SELECT N'FIELD_MACHINES_AND_UTILITIES', N'Machines And Utilities', N'Maschinen Und Werkzeuge', N'Maschinen und Betriebsmittel' UNION ALL
SELECT N'FIELD_METERS', N'Meters', N'Meters', N'Zähler' UNION ALL
SELECT N'FIELD_MONTH', N'Month', N'Monat', N'Monat' UNION ALL
SELECT N'FIELD_MYSERVICE_OPEN_ITEMS', N'Myservice Open Items', N'Artikel myservice öffnen', N'myService offene Punkte' UNION ALL
SELECT N'FIELD_NEXT_VISIT', N'Next Visit', N'Weiter besuchen', N'Nächster Besuch' UNION ALL
SELECT N'FIELD_NO_OF_RED_FLAGS', N'No Of Red Flags', N'Anzahl Der Red Flags', N'Anzahl der Fehler' UNION ALL
SELECT N'FIELD_NODATATODISPLAYTHECHART', N'No Data To Display The Chart', N'Um Keine Daten anzeigen The Chart', N'Keine Daten anzuzeigen' UNION ALL
SELECT N'FIELD_NONESELECTED', N'None Selected', N'Nichts ausgewählt', N'Nichts ausgewählt' UNION ALL
SELECT N'FIELD_NORECORDSTODISPLAYTHETABLE', N'No Records To Display The Table', N'Keine Aufzeichnung zur Anzeige der Tabelle', N'Keine Aufzeichnungen anzuzeigen' UNION ALL
SELECT N'FIELD_NOTE', N'Note', N'Hinweis', N'Hinweis' UNION ALL
SELECT N'FIELD_ONELEVELUP', N'One Level Up', N'Ein Level Up', N'Eine Ebene höher' UNION ALL
SELECT N'FIELD_OTHERS', N'Others', N'Andere', N'Andere'
COMMIT;
RAISERROR (N'#ReportTranslations: Insert Batch: 5.....Done!', 10, 1) WITH NOWAIT;
GO

BEGIN TRANSACTION;
INSERT INTO #ReportTranslations([KeyName], [Value in english], [Value in German], [Final German Translation])
SELECT N'FIELD_PLANTNAME', N'Plant Name', N'Anlagenname ', N'Name Betrieb' UNION ALL
SELECT N'FIELD_PLANTOPERATIONTIME', N'Plant Operation Time', N'Anlagenbetrieb Zeit', N'Produktionszeitraum' UNION ALL
SELECT N'FIELD_PREV12WEEKS', N'Prev 12 Weeks', N'Zurück 12 Wochen', N'Letzte 12 Wochen' UNION ALL
SELECT N'FIELD_PREVIOUS', N'Previous', N'früher', N'früher' UNION ALL
SELECT N'FIELD_PROCESS_VALIDATION_SUMMARY', N'Process Validation Summary', N'Prozessvalidierung Zusammenfassung', N'Zusammenfassung Prozessvalidierung' UNION ALL
SELECT N'FIELD_PRODUCTION', N'Production', N'Produktions Berichte', N'Produktions Berichte' UNION ALL
SELECT N'FIELD_PRODUCTIONDAYS', N'Production Days', N'Produktionstage ', N'Produktionstage ' UNION ALL
SELECT N'FIELD_QUARTER', N'Quarter', N'Quartal', N'Quartal' UNION ALL
SELECT N'FIELD_RED', N'Red', N'Rot', N'Rot' UNION ALL
SELECT N'FIELD_RedFlags', N'Red Flags (Last Week)', N'Red Flags (letzte Woche)', N'Red Flag' UNION ALL
SELECT N'FIELD_REPORT', N'Report', N'Bericht', N'Bericht' UNION ALL
SELECT N'FIELD_RESET', N'Reset', N'Reset ', N'Reset' UNION ALL
SELECT N'FIELD_SELECT', N'Select', N'Wählen', N'Auswahl' UNION ALL
SELECT N'FIELD_SELECTED', N'Selected', N'Ausgewählt', N'Ausgewählt' UNION ALL
SELECT N'FIELD_SELECTMACHINE', N'Select Machine', N'Wählen Sie Maschine', N'Auswahl Maschine' UNION ALL
SELECT N'FIELD_SELECTMACHINEGROUP', N'Select Machine Group', N'Wählen Sie Machine Group', N'Auswahl Maschinengruppe' UNION ALL
SELECT N'FIELD_SELECTPLANT', N'Select Plant', N'Anlage wählen', N'Auswahl Betrieb' UNION ALL
SELECT N'FIELD_SERVICETOOLS', N'Service Tools', N'Service tools', N'Service tools' UNION ALL
SELECT N'FIELD_SETUP', N'Setup', N'Konfiguration', N'Konfiguration' UNION ALL
SELECT N'FIELD_STANDARD', N'Standard', N'Standard', N'Standard' UNION ALL
SELECT N'FIELD_SUMMARY', N'Summary', N'Zusammenfassung', N'Zusammenfassung' UNION ALL
SELECT N'FIELD_TOPLEVEL', N'Top Level', N'Höchststufe', N'Höchste Stufe' UNION ALL
SELECT N'FIELD_TOTAL', N'TOTAL', N'GESAMT PRODUKTION', N'GESAMT PRODUKTION' UNION ALL
SELECT N'FIELD_UNITS-WEIGHT', N'lbs', N'lbs', N'lbs' UNION ALL
SELECT N'FIELD_VALUE', N'Value', N'Gewicht', N'Gewicht' UNION ALL
SELECT N'FIELD_VIEWBY', N'View By', N'Gesehen von', N'Gesehen von' UNION ALL
SELECT N'FIELD_VIEWCATEGORY', N'View Category', N'Ansicht', N'Ansicht' UNION ALL
SELECT N'FIELD_WEEK', N'Week', N'Woche', N'Woche' UNION ALL
SELECT N'FIELD_XAXIS', N'X-Axis', N'X-Achse', N'X-Achse' UNION ALL
SELECT N'FIELD_YAXIS', N'Y-Axis', N'Y-Achse', N'Y-Achse' UNION ALL
SELECT N'FIELD_YEAR', N'Year', N'Jahr', N'Jahr' UNION ALL
SELECT N'FIELD_YOUAREAT', N'You are at', N'Du bist am', N'Sind sind bei….' UNION ALL
SELECT N'FIELD_YOUAREVIEWING', N'You are viewing', N'Sie betrachten', N'Sie betrachten' UNION ALL
SELECT N'kilogram_tons', N'tons', N'Tonnen', N'Tonnen' UNION ALL
SELECT N'FIELD_ACTIONTYPE', N'Action Type', N'Aktion', N'Aktion' UNION ALL
SELECT N'FIELD_ALARM', N'Alarm', N'Alarm', N'Alarm' UNION ALL
SELECT N'FIELD_CHAINCATEGORY', N'Chain Category', N'Ketten Kategorie', N'Kundengruppenkategorie' UNION ALL
SELECT N'FIELD_CONTROLLER', N'Dispenser', N'Spender', N'Dosiergerät' UNION ALL
SELECT N'FIELD_CORPORATE', N'Corporate', N'Firmen-', N'Kundengruppe' UNION ALL
SELECT N'FIELD_COUNTRY', N'Country', N'Land', N'Land' UNION ALL
SELECT N'FIELD_CUSTOMER', N'Plant Customer', N'End Kunde', N'End Kunde' UNION ALL
SELECT N'FIELD_FORMULA', N'Formula', N'Programm', N'Programm' UNION ALL
SELECT N'FIELD_FORMULACATEGORY', N'Formula Category', N'Formel-Kategorie', N'Programm Kategorie' UNION ALL
SELECT N'FIELD_FORMULASEGMENT', N'Formula Segment', N'Programm Segment', N'Programm Segment' UNION ALL
SELECT N'FIELD_MACHINEGROUP_REPORTFILTER', N'Machine Group', N'Maschinen-Gruppe', N'Maschinen-Gruppe' UNION ALL
SELECT N'FIELD_MACHINES', N'Machines', N'Maschinen', N'Maschinen' UNION ALL
SELECT N'FIELD_MACHINETYPE_REPORTFILTER', N'Machine Type', N'Maschinen Typ ', N'Maschinen Typ ' UNION ALL
SELECT N'FIELD_PLANT', N'Plant', N'Betrieb', N'Betrieb' UNION ALL
SELECT N'FIELD_REGION', N'Region', N'Region', N'Region' UNION ALL
SELECT N'FIELD_USER_REPORTFILTER', N'User', N'Benutzer', N'Benutzer'
COMMIT;
RAISERROR (N'#ReportTranslations: Insert Batch: 6.....Done!', 10, 1) WITH NOWAIT;
GO

-- English
SELECT DISTINCT KeyName, [Value in english] As Value, 
(select LanguageId from TCD.LanguageMaster where Name = 'English US') as LanguageId,
GETDATE() AS LastModifiedTime
INTO #ResourceKeyValue
FROM #ReportTranslations
UNION ALL 
-- German
SELECT DISTINCT  KeyName, [Final German Translation] As Value, 
(select LanguageId from TCD.LanguageMaster where Name = 'Deutsch') as LanguageId,
GETDATE() AS LastModifiedTime
FROM #ReportTranslations
GO

-- delete dup entries
DELETE FROM #ResourceKeyValue
WHERE KEYNAME ='ACCOUNT_SUMMARY_REPORT' and value = 'Zusammenfassung'
GO
DELETE FROM #ResourceKeyValue
WHERE KEYNAME ='FIELD_DATERANGE' and value = 'Datumsbereich'
GO
DELETE FROM #ResourceKeyValue
WHERE KEYNAME ='FIELD_DAYS_FROM_LAST_VISIT' and value = 'Tage vom letzten Besuch'
GO
DELETE FROM #ResourceKeyValue
WHERE KEYNAME ='FIELD_ECOLABCATEGORIES_REPORT' and value = 'Verfahrenssegment'
GO
DELETE FROM #ResourceKeyValue
WHERE KEYNAME ='FIELD_FORMULA' and value = 'Verfahren'
GO
DELETE FROM #ResourceKeyValue
WHERE KEYNAME = 'FIELD_FORMULACATEGORY' and value = 'Verfahrenskategorie'
GO
DELETE FROM #ResourceKeyValue
WHERE KEYNAME ='FIELD_FORMULASEGMENT' and value = 'Verfahrenssegment'
GO
DELETE FROM #ResourceKeyValue
WHERE KEYNAME ='FIELD_FORMULAS' and value = 'Verfahren'
GO
DELETE FROM #ResourceKeyValue
WHERE KEYNAME ='FIELD_NEXT_VISIT' and value = 'Nächster Termin Service-Besuch'
GO
DELETE FROM #ResourceKeyValue
WHERE KEYNAME ='FIELD_PLANTNAME' and value = 'Anlagenname'
GO
DELETE FROM #ResourceKeyValue
WHERE KEYNAME ='FIELD_REWASH' and value = 'Nachwäsche'
GO

-- ===================================================
-- Import Report Translations 
-- ===================================================

-- ADD Keys in Resource Key Master if they are not available
INSERT INTO TCD.ResourceKeyMaster (KeyName, KeyDescription)
SELECT DISTINCT Y.KeyName, NULL AS KeyDescription 
FROM TCD.ResourceKeyMaster as X
RIGHT JOIN #ResourceKeyValue AS Y ON X.KeyName collate Latin1_General_CI_AI = Y.keyname collate Latin1_General_CI_AI
WHERE X.KeyName IS NULL 
GO
-- Add the missing resource keys for Language
INSERT INTO TCD.ResourceKeyValue
(KeyName, Value, LanguageId, LastModifiedTime)
SELECT Y.KeyName, Y.Value, Y.LanguageId, Y.LastModifiedTime 
FROM TCD.ResourceKeyValue as X
RIGHT JOIN #ResourceKeyValue AS Y ON X.KeyName collate Latin1_General_CI_AI = Y.keyname collate Latin1_General_CI_AI AND X.LanguageId = Y.LanguageId
WHERE X.KeyName IS NULL 
GO
-- Update the Resource Key Value where translation is not aligned 
--SELECT Y.KeyName, Y.Value, Y.LanguageId, Y.LastModifiedTime 
UPDATE X
SET X.Value = Y.Value
FROM TCD.ResourceKeyValue as X
JOIN #ResourceKeyValue AS Y ON X.KeyName collate Latin1_General_CI_AI = Y.keyname collate Latin1_General_CI_AI AND X.LanguageId = Y.LanguageId
WHERE X.Value collate Latin1_General_CI_AI <> Y.Value collate Latin1_General_CI_AI
GO
-- ===================================================
-- Import Report Translations 
-- ===================================================


-- CleanUp 
DROP TABLE #ResourceKeyValue
DROP TABLE #ReportTranslations
GO

UPDATE rkv SET rkv.[Value]='#currency#'
 FROM tcd.ResourceKeyValue rkv  WHERE rkv.KeyName IN ('dollar','euro')

 GO
 
IF NOT EXISTS(
    SELECT TOP(1) 1
    FROM sys.columns 
    WHERE Name      = N'UsageKey'
      AND Object_ID = Object_ID(N'TCD.Report'))
BEGIN

 Alter TABLE TCD.Report
ADD [UsageKey] [nvarchar](100) 

END
GO

IF NOT EXISTS(
    SELECT TOP(1) 1
    FROM sys.columns 
    WHERE Name      = N'UsageKey'
      AND Object_ID = Object_ID(N'TCD.ReportCategory'))
BEGIN

Alter TABLE TCD.ReportCategory
ADD [UsageKey] [nvarchar](100)

END

GO


IF NOT EXISTS(
    SELECT TOP(1) 1
    FROM sys.columns 
    WHERE Name      = N'UsageKey'
      AND Object_ID = Object_ID(N'TCD.ReportSubCategory'))
BEGIN

Alter TABLE TCD.ReportSubCategory
ADD [UsageKey] [nvarchar](100) 

END

GO

IF NOT EXISTS(
    SELECT TOP(1) 1
    FROM sys.columns 
    WHERE Name      = N'UsageKey'
      AND Object_ID = Object_ID(N'TCD.ReportViewByMode'))
BEGIN

Alter TABLE TCD.ReportViewByMode
ADD [UsageKey] [nvarchar](100) 

END

GO



update tcd.ResourceKeyValue set value = '#currency#/Cwt' where value = '$/Cwt'
GO

update tcd.ResourceKeyValue set value = '#currency#/Kgs' where value = '€/Kgs'
GO

update tcd.ResourceKeyValue set value = '#currency#/Kg' where value = '€/Kg'
GO


UPDATE TCD.ReportCategory SET  [UsageKey] = 'FIELD_WASHINGPROCESSVALIDATION' Where ReportCategoryId = 1
GO
UPDATE TCD.ReportCategory SET  [UsageKey] = 'FIELD_PRODUCTIONEFFICIENCY' Where ReportCategoryId = 2
GO
UPDATE TCD.ReportCategory SET  [UsageKey] = 'FIELD_RESOURCESUTILIZATION' Where ReportCategoryId = 3
GO
UPDATE TCD.ReportCategory SET  [UsageKey] = 'FIELD_FINANCIALS' Where ReportCategoryId = 4
GO
UPDATE TCD.ReportCategory SET  [UsageKey] = 'FIELD_ECOLABINTERNAL' Where ReportCategoryId = 5
GO

UPDATE tcd.report set UsageKey = 'FIELD_PRODUCTION SUMMARY' Where ReportId = 1
GO
UPDATE tcd.report set UsageKey = 'FIELD_CHEMICAL CONSUMPTION' Where ReportId = 5
GO
UPDATE tcd.report set UsageKey = 'FIELD_ALARMSSUMMARY' Where ReportId = 12
GO
UPDATE tcd.report set UsageKey = 'FIELD_ALARMDETAILS' Where ReportId = 13
GO
UPDATE tcd.report set UsageKey = 'FIELD_CHEMICALINVENTORY' Where ReportId = 6
GO
UPDATE tcd.report set UsageKey = 'FIELD_OPERATIONS SUMMARY ' Where ReportId = 10
GO
UPDATE tcd.report set UsageKey = 'FIELD_USERLOG' Where ReportId = 30
GO


UPDATE TCD.ReportSubCategory  SET [UsageKey] = 'FIELD_PROCESSVALIDATION' Where SubCategoryId = 1
GO
UPDATE TCD.ReportSubCategory  SET [UsageKey] = 'FIELD_PRODUCTION' Where SubCategoryId = 2
GO
UPDATE TCD.ReportSubCategory  SET [UsageKey] = 'FIELD_EFFICIENCY' Where SubCategoryId = 3
GO
UPDATE TCD.ReportSubCategory  SET [UsageKey] = 'FIELD_MYSERVICE' Where SubCategoryId = 4
GO
UPDATE TCD.ReportSubCategory  SET [UsageKey] = 'FIELD_RESOURCES' Where SubCategoryId = 5
GO
UPDATE TCD.ReportSubCategory  SET [UsageKey] = 'FIELD_OPERATIONALCOSTS' Where SubCategoryId = 6
GO
UPDATE TCD.ReportSubCategory  SET [UsageKey] = 'FIELD_IMPROVEMENTINITIATIVES' Where SubCategoryId = 7
GO
UPDATE TCD.ReportSubCategory  SET [UsageKey] = 'FIELD_SERVICETOOLS' Where SubCategoryId = 8
GO
UPDATE TCD.ReportSubCategory  SET [UsageKey] = 'FIELD_ACCOUNTMANAGEMENT' Where SubCategoryId = 9
GO
UPDATE TCD.ReportSubCategory  SET [UsageKey] = 'FIELD_SYSTEMADMINISTRATION' Where SubCategoryId = 10

UPDATE TCD.ReportViewByMode SET [UsageKey] = 'FIELD_TIME' WHERE ID = 1 
GO
UPDATE TCD.ReportViewByMode SET [UsageKey] = 'FIELD_LOCATION' WHERE ID = 2 
GO
UPDATE TCD.ReportViewByMode SET [UsageKey] = 'FIELD_ECOLABCATEGORIES_REPORT' WHERE ID = 3 
GO
UPDATE TCD.ReportViewByMode SET [UsageKey] = 'FIELD_TEXTILECATEGORIES_REPORT' WHERE ID = 4 
GO
UPDATE TCD.ReportViewByMode SET [UsageKey] = 'FIELD_CHAINCATEGORIES_REPORT' WHERE ID = 5 
GO
UPDATE TCD.ReportViewByMode SET [UsageKey] = 'FIELD_CUSTOMER' WHERE ID = 6 
GO
UPDATE TCD.ReportViewByMode SET [UsageKey] = 'FIELD_FORMULAS' WHERE ID = 7 
GO
UPDATE TCD.ReportViewByMode SET [UsageKey] = 'FIELD_FORMULA' WHERE ID = 8 
GO
UPDATE TCD.Report SET UsageKey = 'FIELD_PRODUCTION DETAILS' wHERE ReportId = 2 
GO


IF NOT EXISTS (SELECT 1 FROM tcd.ResourceKeyValue rkv WHERE rkv.KeyName = 'FIELD_YOUAREVIEWING' AND rkv.languageID=2)
BEGIN
INSERT INTO tcd.ResourceKeyValue VALUES(N'FIELD_YOUAREVIEWING',N'Sie betrachten',2,GETDATE())
END
GO

---UOM for Water Usage---
If exists(Select 1 from tcd.ReportLocalizationColumnMapping where ReportId=10 and ReportColumnId=12)
Begin 
Update tcd.ReportLocalizationColumnMapping set UomKey='WaterUsage_RedFlag' where ReportId=10 and ReportColumnId=12
End
GO

IF NOT EXISTS (SELECT 1 FROM [TCD].[ResourceKeyMaster] where KeyName='FIELD_BACTTOORIGINAL')
	BEGIN
		 INSERT INTO TCD.ResourceKeyMaster(KeyName, KeyDescription) Values('FIELD_BACTTOORIGINAL', 'Back to Original')
END
ELSE
	BEGIN
		UPDATE TCD.ResourceKeyMaster SET  KeyDescription='Back to Original' WHERE KeyName='FIELD_BACTTOORIGINAL'
	END
GO
IF NOT EXISTS (SELECT 1 FROM [TCD].[ResourceKeyValue] where KeyName='FIELD_BACTTOORIGINAL' and languageID=1)
	BEGIN
		 INSERT INTO TCD.ResourceKeyValue(KeyName, Value, languageID, LastModifiedTime) Values('FIELD_BACTTOORIGINAL', 'Back to Original',1,GETDATE())
	END
ELSE
	BEGIN
		UPDATE TCD.ResourceKeyValue SET  Value='Back to Original', LastModifiedTime=GETDATE() WHERE KeyName='FIELD_BACTTOORIGINAL' and languageID=1 
	END
GO
IF NOT EXISTS (SELECT 1 FROM [TCD].[ResourceKeyValue] where KeyName='FIELD_BACTTOORIGINAL' and languageID=2)
	BEGIN
		 INSERT INTO TCD.ResourceKeyValue(KeyName, Value, languageID, LastModifiedTime) Values('FIELD_BACTTOORIGINAL', 'Terug naar Original',2,GETDATE())
	END
ELSE
	BEGIN
		UPDATE TCD.ResourceKeyValue SET  Value='Terug naar Original', LastModifiedTime=GETDATE() WHERE KeyName='FIELD_BACTTOORIGINAL' and languageID=2 
	END
GO


--- one level up

IF NOT EXISTS (SELECT 1 FROM [TCD].[ResourceKeyMaster] where KeyName='FIELD_ONELEVELUP')
	BEGIN
		 INSERT INTO TCD.ResourceKeyMaster(KeyName, KeyDescription) Values('FIELD_ONELEVELUP', 'One Level Up')
END
ELSE
	BEGIN
		UPDATE TCD.ResourceKeyMaster SET  KeyDescription='One Level Up' WHERE KeyName='FIELD_ONELEVELUP'
	END
GO
IF NOT EXISTS (SELECT 1 FROM [TCD].[ResourceKeyValue] where KeyName='FIELD_ONELEVELUP' and languageID=1)
	BEGIN
		 INSERT INTO TCD.ResourceKeyValue(KeyName, Value, languageID, LastModifiedTime) Values('FIELD_ONELEVELUP', 'One Level Up',1,GETDATE())
	END
ELSE
	BEGIN
		UPDATE TCD.ResourceKeyValue SET  Value='One Level Up', LastModifiedTime=GETDATE() WHERE KeyName='FIELD_ONELEVELUP' and languageID=1 
	END
GO
IF NOT EXISTS (SELECT 1 FROM [TCD].[ResourceKeyValue] where KeyName='FIELD_ONELEVELUP' and languageID=2)
	BEGIN
		 INSERT INTO TCD.ResourceKeyValue(KeyName, Value, languageID, LastModifiedTime) Values('FIELD_ONELEVELUP', 'Eine Ebene höher',2,GETDATE())
	END
ELSE
	BEGIN
		UPDATE TCD.ResourceKeyValue SET Value='Eine Ebene höher', LastModifiedTime=GETDATE() WHERE KeyName='FIELD_ONELEVELUP' and languageID=2 
	END
GO



--- end one level

IF NOT EXISTS (SELECT 1 FROM [TCD].[ResourceKeyMaster] where KeyName='FIELD_DATERANGE')
	BEGIN
		 INSERT INTO TCD.ResourceKeyMaster(KeyName, KeyDescription) Values('FIELD_DATERANGE', 'Date Range')
END
ELSE
	BEGIN
		UPDATE TCD.ResourceKeyMaster SET KeyDescription='Date Range' WHERE KeyName='FIELD_DATERANGE'
	END
GO

IF NOT EXISTS (SELECT 1 FROM [TCD].[ResourceKeyValue] where KeyName='FIELD_DATERANGE' and languageID=1)
	BEGIN
		 INSERT INTO TCD.ResourceKeyValue(KeyName, Value, languageID, LastModifiedTime) Values('FIELD_DATERANGE', 'Date Range',1,GETDATE())
	END
ELSE
	BEGIN
		UPDATE TCD.ResourceKeyValue SET  Value='Date Range',  LastModifiedTime=GETDATE() WHERE KeyName='FIELD_DATERANGE' and languageID=1 
	END
GO

IF NOT EXISTS (SELECT 1 FROM [TCD].[ResourceKeyValue] where KeyName='FIELD_DATERANGE' and languageID=2)
	BEGIN
		 INSERT INTO TCD.ResourceKeyValue(KeyName, Value, languageID, LastModifiedTime) Values('FIELD_DATERANGE', 'Zeitraum',2,GETDATE())
	END
ELSE
	BEGIN
		UPDATE TCD.ResourceKeyValue SET  Value='Auswahl Datum',  LastModifiedTime=GETDATE() WHERE KeyName='FIELD_DATERANGE' and languageID=2 
	END
GO

UPDATE rkv SET rkv.[Value] = replace(rkv.[Value],'kgs','kg')  FROM tcd.ResourceKeyValue rkv
WHERE rkv.[Value]LIKE '%/kgs' AND rkv.KeyName='EURO_PER_KILOGRAM'

GO
 
UPDATE rkv SET rkv.[Value]='kg' FROM tcd.ResourceKeyValue rkv WHERE  rkv.KeyName='kilogram'
 
GO
 
UPDATE rkv SET rkv.[Value] = replace(rkv.[Value],'kgs','kg')  FROM tcd.ResourceKeyValue rkv
WHERE rkv.[Value]LIKE 'kgs/%' AND rkv.KeyName='kilogram_per_hour'

GO

IF EXISTS(SELECT 1 FROM tcd.CurrencySymbol cs WHERE CurrencyCode = N'EUR')
BEGIN
	
UPDATE tcd.CurrencySymbol
SET
    TCD.CurrencySymbol.CurrencySymbol = N'€'
    WHERE TCD.CurrencySymbol.CurrencyCode = N'EUR'
END
GO


IF NOT EXISTS(SELECT
					1 FROM TCD.ResourceKeyMaster AS rkm WHERE rkm.KeyName = 'FIELD_CONTROLLER1')
	BEGIN
		INSERT INTO TCD.ResourceKeyMaster(
				TCD.ResourceKeyMaster.KeyName, 
				TCD.ResourceKeyMaster.KeyDescription)
		VALUES
			   (
				N'FIELD_CONTROLLER1', 
				N'NULL');
	END;
GO

IF NOT EXISTS(SELECT
					  1
				  FROM TCD.ResourceKeyValue AS rkv
				  WHERE rkv.KeyName = 'FIELD_CONTROLLER1'
					AND rkv.languageID = 2)
	BEGIN
		INSERT INTO tcd.ResourceKeyValue(
				TCD.ResourceKeyValue.KeyName, 
				TCD.ResourceKeyValue.[Value], 
				TCD.ResourceKeyValue.languageID, 
				TCD.ResourceKeyValue.LastModifiedTime)
		VALUES
			   (
				N'FIELD_CONTROLLER1', 
				N'Controller', 
				1, 
				GETDATE());
	END;
GO

IF NOT EXISTS(SELECT
					  1
				  FROM TCD.ResourceKeyValue AS rkv
				  WHERE rkv.KeyName = 'FIELD_CONTROLLER1'
					AND rkv.languageID = 2)
	BEGIN
		INSERT INTO tcd.ResourceKeyValue(
				TCD.ResourceKeyValue.KeyName, 
				TCD.ResourceKeyValue.[Value], 
				TCD.ResourceKeyValue.languageID, 
				TCD.ResourceKeyValue.LastModifiedTime)
		VALUES
			   (
				N'FIELD_CONTROLLER1', 
				N'Dosieranlage', 
				2, 
				GETDATE());
	END;
GO

IF EXISTS(SELECT
				  * FROM sys.views WHERE object_id = OBJECT_ID(N'[TCD].[Turntime]')
									 AND type = N'V')
	BEGIN
		DROP VIEW
				TCD.Turntime
	END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [TCD].[Turntime]
AS 

SELECT 	
	BD.BATCHID, 
	BD.ECOLABWASHERID, 
	BD.ENDDATE, 
	LEAD(BD.STARTDATE) OVER (PARTITION BY BD.ECOLABWASHERID ORDER BY BD.GroupId, BD.MachineId, BD.STARTDATE) AS STARTDATE,
	CASE
		WHEN (DATEDIFF(SECOND, BD.ENDDATE, LEAD(BD.STARTDATE) OVER (PARTITION BY BD.ECOLABWASHERID ORDER BY BD.GroupId, BD.MachineId, BD.STARTDATE)) <= 0
		    OR DATEDIFF(SECOND, BD.ENDDATE, LEAD(BD.STARTDATE) OVER (PARTITION BY BD.ECOLABWASHERID ORDER BY BD.GroupId, BD.MachineId, BD.STARTDATE)) > (W.defaultidletime * 60))
		AND ISNULL(W.DefaultIdleTime,0) <> 0 
		    THEN BD.TARGETTURNTIME
		WHEN LEAD(BD.STARTDATE) OVER (PARTITION BY BD.ECOLABWASHERID ORDER BY BD.GroupId, BD.MachineId, BD.STARTDATE) IS NULL 
		    THEN BD.TARGETTURNTIME
		ELSE CASE 
			WHEN DATEDIFF(SECOND, BD.ENDDATE, LEAD(BD.STARTDATE) OVER (PARTITION BY BD.ECOLABWASHERID ORDER BY BD.GroupId, BD.MachineId, BD.STARTDATE)) > 7200
			    THEN BD.TARGETTURNTIME
			ELSE DATEDIFF(SECOND, BD.ENDDATE, LEAD(BD.STARTDATE) OVER (PARTITION BY BD.ECOLABWASHERID ORDER BY BD.GroupId, BD.MachineId, BD.STARTDATE))
		     END
	END AS ActualTurnTime,
	BD.PROGRAMMASTERID,
	BD.MachineId

FROM TCD.BatchData bd
INNER JOIN TCD.WASHER AS W ON BD.MachineId = W.WasherID
			AND BD.EcolabWasherId = W.EcolabWasherId
INNER JOIN TCD.WASHERGROUP AS WG ON WG.WASHERGROUPID = BD.GROUPID
				AND W.ECOLABACCOUNTNUMBER = WG.ECOLABACCOUNTNUMBER
INNER JOIN TCD.MACHINESETUP AS MS ON MS.GroupId = WG.WasherGroupId
				AND ms.WasherId = W.WasherId
				AND w.EcoLabAccountNumber = ms.EcoalabAccountNumber
WHERE BD.PROGRAMMASTERID <> 0
	AND WG.WASHERGROUPTYPEID = 1


GO

--Chemical Cost per Load columns precision  to 3 for texcare
Update tcd.ReportColumnsMapping set Precision=3 where ColumnId=45
Update tcd.ReportColumnsMapping set Precision=3 where ColumnId=58
GO


IF NOT Exists(SELECT 1 FROM TCD.ResourceKeyValue where KeyName='FIELD_MACHINEGROUP_REPORTCOLUMN' and languageID=2 and Value='Maschinen Gruppe')
BEGIN
	UPdate tcd.ResourceKeyValue SET Value='MaschinenGruppe' where KeyName='FIELD_MACHINEGROUP_REPORTCOLUMN' and languageID=2
END
GO

Update tcd.ResourceKeyValue set Value='Produktions Effizienz'
where KeyName ='FIELD_PRODUCTIONEFFICIENCY' and LanguageID=2

Update tcd.ResourceKeyValue set Value='Effizienz'
where KeyName ='FIELD_EFFICIENCY' and LanguageID=2

Update tcd.ResourceKeyValue set Value='myService'
where KeyName ='FIELD_MYSERVICE' and LanguageID=2

--Washing Process Valication Category Changes
Update tcd.ResourceKeyValue set Value='Waschprozess Validierung'
where KeyName ='FIELD_WASHINGPROCESSVALIDATION' and LanguageID=2
--Resource Utilization Category Changes
Update tcd.ResourceKeyValue set Value='Betriebsmittel'
where KeyName ='FIELD_RESOURCESUTILIZATION' and LanguageID=2

Update tcd.ResourceKeyValue set Value='Betriebsmittel - Berichte'
where KeyName ='FIELD_RESOURCES' and LanguageID=2
--Financials Category Changes
Update tcd.ResourceKeyValue set Value='Kosten'
where KeyName ='FIELD_FINANCIALS' and LanguageID=2

Update tcd.ResourceKeyValue set Value='Operative Kosten'
where KeyName ='FIELD_OPERATIONALCOSTS' and LanguageID=2

--EcolabInternal  Category Changes
Update tcd.ResourceKeyValue set Value='Ecolab - Intern'
where KeyName ='FIELD_ECOLABINTERNAL' and LanguageID=2

Update tcd.ResourceKeyValue set Value='Maschinenstillstandszeit'
where KeyName ='FIELD_MACHINEHOLDTIME' and LanguageID=2

Update tcd.ResourceKeyValue set Value='Betriebs Management'
where KeyName ='FIELD_ACCOUNTMANAGEMENT' and LanguageID=2

Update tcd.ResourceKeyValue set Value='Administrative System Berichte'
where KeyName ='FIELD_SYSTEMADMINISTRATION' and LanguageID=2
GO

IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyValue WHERE KeyName='FIELD_REPORTS' AND languageID=2 and value='Berichte')
BEGIN
UPDATE tcd.ResourceKeyValue
SET
    TCD.ResourceKeyValue.[Value] = N'Berichte'
    WHERE KeyName='FIELD_REPORTS' AND languageID=2
END
GO

--Rewash column precision 2 in production details report
Update tcd.ReportColumnsMapping set Precision=2 where ReportId=2 and ColumnId=156
--Actual Prduction and Traget prodction  column precision 2 in production details report
Update tcd.ReportColumnsMapping set Precision=0 where ReportId=2 and ColumnId=200
Update tcd.ReportColumnsMapping set Precision=0 where ReportId=2 and ColumnId=181
GO

-- Added Resource Keys For Validation String "Please enter  between 3 to 19"
IF NOT EXISTS (SELECT
						1
					FROM [TCD].[ResourceKeyMaster] 
					WHERE KeyName = 'FIELD_PLEASEENTERBETWEEN3TO19') 
	BEGIN 
		INSERT INTO [TCD].ResourceKeyMaster 
					(KeyName, 
					 KeyDescription) 
		VALUES		('FIELD_PLEASEENTERBETWEEN3TO19', 
					 NULL) 
	END 
ELSE 
	BEGIN 
		UPDATE [TCD].ResourceKeyMaster
		SET 	KeyName = 'FIELD_PLEASEENTERBETWEEN3TO19', 
				KeyDescription = NULL
		WHERE KeyName = 'FIELD_PLEASEENTERBETWEEN3TO19'
	END
GO 

 IF EXISTS (SELECT
					* 
				FROM [TCD].[ResourceKeyValue]
				WHERE KeyName = 'FIELD_PLEASEENTERBETWEEN3TO19'
					AND LanguageID = 1)
	BEGIN 
		UPDATE [TCD].ResourceKeyValue
		SET Value = 'Please enter  between 3 to 19',
			LastModifiedTime = GETDATE()
		WHERE KeyName = 'FIELD_PLEASEENTERBETWEEN3TO19'
			AND LanguageID = 1
	END
ELSE
	BEGIN 
		INSERT INTO [TCD].[ResourceKeyValue] 
				(KeyName,
				 Value,
				 LanguageID,
				 LastModifiedTime)
		VALUES	('FIELD_PLEASEENTERBETWEEN3TO19',
				 'Please enter  between 3 to 19',
				 1,
				 GETDATE())
	END
GO 

IF EXISTS (SELECT
					* 
				FROM [TCD].[ResourceKeyValue]
				WHERE KeyName = 'FIELD_PLEASEENTERBETWEEN3TO19'
					AND LanguageID = 2)
	BEGIN 
		UPDATE [TCD].ResourceKeyValue
		SET Value = 'Vul tussen 3 tot 19',
			LastModifiedTime = GETDATE()
		WHERE KeyName = 'FIELD_PLEASEENTERBETWEEN3TO19'
			AND LanguageID = 2
	END
ELSE
	BEGIN 
		INSERT INTO [TCD].[ResourceKeyValue] 
				(KeyName,
				 Value,
				 LanguageID,
				 LastModifiedTime)
		VALUES	('FIELD_PLEASEENTERBETWEEN3TO19',
				 'Vul tussen 3 tot 19',
				 2,
				 GETDATE())
	END
GO 

IF EXISTS (SELECT
					* 
				FROM [TCD].[ResourceKeyValue]
				WHERE KeyName = 'FIELD_PLEASEENTERBETWEEN3TO19'
					AND LanguageID = 3)
	BEGIN 
		UPDATE [TCD].ResourceKeyValue
		SET Value = 'Por favor introduzca entre 3 y 19',
			LastModifiedTime = GETDATE()
		WHERE KeyName = 'FIELD_PLEASEENTERBETWEEN3TO19'
			AND LanguageID = 3
	END
ELSE
	BEGIN 
		INSERT INTO [TCD].[ResourceKeyValue] 
				(KeyName,
				 Value,
				 LanguageID,
				 LastModifiedTime)
		VALUES	('FIELD_PLEASEENTERBETWEEN3TO19',
				 'Por favor introduzca entre 3 y 19',
				 3,
				 GETDATE())
	END
GO 

IF EXISTS (SELECT
					* 
				FROM [TCD].[ResourceKeyValue]
				WHERE KeyName = 'FIELD_PLEASEENTERBETWEEN3TO19'
					AND LanguageID = 13)
	BEGIN 
		UPDATE [TCD].ResourceKeyValue
		SET Value = 'Fyll inn mellom 3-19',
			LastModifiedTime = GETDATE()
		WHERE KeyName = 'FIELD_PLEASEENTERBETWEEN3TO19'
			AND LanguageID = 13
	END
ELSE
	BEGIN 
		INSERT INTO [TCD].[ResourceKeyValue] 
				(KeyName,
				 Value,
				 LanguageID,
				 LastModifiedTime)
		VALUES	('FIELD_PLEASEENTERBETWEEN3TO19',
				 'Fyll inn mellom 3-19',
				 13,
				 GETDATE())
	END
GO  

update TCD.ReportColumnsMapping set DisplayOrder = 3 where ReportID = 13 and ColumnId = 247
update TCD.ReportColumnsMapping set DisplayOrder = 4 where ReportID = 13 and ColumnId = 168
update TCD.ReportColumnsMapping set DisplayOrder = 6 where ReportID = 13 and ColumnId = 69
GO

update TCD.ReportColumnsMapping set DisplayOrder = 6  where ColumnId = 249 and ReportId = 13
update TCD.ReportColumnsMapping set DisplayOrder = 7  where ColumnId = 250 and ReportId = 13
update TCD.ReportColumnsMapping set DisplayOrder = 8  where ColumnId = 251 and ReportId = 13
update TCD.ReportColumnsMapping set DisplayOrder = 9  where ColumnId = 252 and ReportId = 13
update TCD.ReportColumnsMapping set DisplayOrder = 10  where ColumnId = 253 and ReportId = 13
update TCD.ReportColumnsMapping set DisplayOrder = 11  where ColumnId = 254 and ReportId = 13
update TCD.ReportColumnsMapping set DisplayOrder = 12  where ColumnId = 255 and ReportId = 13
update TCD.ReportColumnsMapping set DisplayOrder = 13  where ColumnId = 257 and ReportId = 13
update TCD.ReportColumnsMapping set DisplayOrder = 15  where ColumnId = 258 and ReportId = 13
update TCD.ReportColumnsMapping set DisplayOrder = 16  where ColumnId = 69 and ReportId = 13
GO

------------------------------------------Chemical Consumption Report Label Changes as like CENTRAL---------------------------------
IF EXISTS(SELECT
				  1 FROM TCD.ReportLocalizationColumnMapping WHERE id = 74
															   AND ReportColumnId = 56)
	BEGIN
		UPDATE TCD.ReportLocalizationColumnMapping SET
				TCD.ReportLocalizationColumnMapping.UsageKey = 'FIELD_ACTUALCOST', 
				TCD.ReportLocalizationColumnMapping.UomKey = 'Price_Tcd'
			WHERE
				id = 74
			AND ReportColumnId = 56;
	END;
GO

IF EXISTS(SELECT
				  1 FROM TCD.ReportLocalizationColumnMapping WHERE id = 72
															   AND ReportColumnId = 274)
	BEGIN
		UPDATE TCD.ReportLocalizationColumnMapping SET
				TCD.ReportLocalizationColumnMapping.UsageKey = 'FIELD_AVERAGECONSUMPTIONPERFORMULA', 
				TCD.ReportLocalizationColumnMapping.UomKey = 'NULL'
			WHERE
				id = 70
			AND ReportColumnId = 16;
	END;
GO
IF EXISTS(SELECT
				  1 FROM TCD.ReportLocalizationColumnMapping WHERE id = 72
															   AND ReportColumnId = 274)
	BEGIN
		UPDATE TCD.ReportLocalizationColumnMapping SET
				TCD.ReportLocalizationColumnMapping.UsageKey = 'FIELD_ACTUALCHEMICALUSAGE_REPORT', 
				TCD.ReportLocalizationColumnMapping.UomKey = 'ChemicalConsumption_RedFlag'
			WHERE
				id = 72
			AND ReportColumnId = 274;
	END;
GO

IF EXISTS(SELECT
					1
				FROM tcd.ResourceKeyValue AS rkv
				WHERE rkv.KeyName = N'FIELD_UOM'
				AND rkv.LanguageID = 1)
	BEGIN
		UPDATE tcd.ResourceKeyValue SET
				TCD.ResourceKeyValue.[Value] = N'UOM', 				
				TCD.ResourceKeyValue.LastModifiedTime = GETDATE()
			WHERE
				TCD.ResourceKeyValue.KeyName = N'FIELD_UOM'
			AND TCD.ResourceKeyValue.LanguageID = 1;
	END;
	GO

---------------------------------------Report Labels Update Target To Standard ----------------------------------------------
IF EXISTS(SELECT 1 FROM tcd.ResourceKeyValue WHERE tcd.ResourceKeyValue.KeyName='FIELD_TARGETPRODUCTION' AND tcd.ResourceKeyValue.LanguageID=1)
BEGIN
	UPDATE tcd.ResourceKeyValue SET
			tcd.ResourceKeyValue.[Value] = 'Standard Production'
		WHERE
			tcd.ResourceKeyValue.KeyName = 'FIELD_TARGETPRODUCTION'
		AND tcd.ResourceKeyValue.LanguageID = 1;
END;
GO
IF EXISTS(SELECT
				  1
			  FROM tcd.ResourceKeyValue
			  WHERE tcd.ResourceKeyValue.KeyName = 'FIELD_TARGETPRODUCTIONPERHOUR_REPORTCOLUMN'
				AND tcd.ResourceKeyValue.LanguageID = 1)

	BEGIN
		UPDATE tcd.ResourceKeyValue SET
				tcd.ResourceKeyValue.[Value] = 'Standard Production per hour'
			WHERE
				tcd.ResourceKeyValue.KeyName = 'FIELD_TARGETPRODUCTIONPERHOUR_REPORTCOLUMN'
			AND tcd.ResourceKeyValue.LanguageID = 1;
	END;
GO
---------------------------------------END--Report Labels Update Target To Standard -- END----------------------------------------------

IF NOT EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME = 'TimeEfficiencyMaxCap' AND TABLE_NAME = 'PLANT')
BEGIN
	ALTER TABLE TCD.PLANT ADD TimeEfficiencyMaxCap FLOAT   
END
GO
	IF NOT EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME = 'LoadEfficiencyMaxCap' AND TABLE_NAME = 'PLANT')
BEGIN
	ALTER TABLE TCD.PLANT	ADD LoadEfficiencyMaxCap FLOAT   
END
GO
 
IF NOT EXISTS (SELECT 1 FROM SYS.ALL_COLUMNS C JOIN SYS.TABLES T ON T.OBJECT_ID = C.OBJECT_ID
      JOIN SYS.SCHEMAS S ON S.SCHEMA_ID = T.SCHEMA_ID 
	 JOIN SYS.DEFAULT_CONSTRAINTS D ON C.DEFAULT_OBJECT_ID = D.OBJECT_ID
    WHERE T.NAME = 'PLANT'
      AND C.NAME = 'TimeEfficiencyMaxCap'
      AND S.NAME = 'TCD')
	 BEGIN 

    ALTER TABLE TCD.PLANT ADD CONSTRAINT DFT_CN_PLANT_TimeEfficiencyMaxCap110 DEFAULT  100 FOR TimeEfficiencyMaxCap 
	 END

GO
IF NOT EXISTS (SELECT 1 FROM SYS.ALL_COLUMNS C JOIN SYS.TABLES T ON T.OBJECT_ID = C.OBJECT_ID
      JOIN SYS.SCHEMAS S ON S.SCHEMA_ID = T.SCHEMA_ID 
	 JOIN SYS.DEFAULT_CONSTRAINTS D ON C.DEFAULT_OBJECT_ID = D.OBJECT_ID
    WHERE T.NAME = 'PLANT'
      AND C.NAME = 'LoadEfficiencyMaxCap'
      AND S.NAME = 'TCD')
	 BEGIN 

    ALTER TABLE TCD.PLANT ADD CONSTRAINT DFT_CN_PLANT_LoadEfficiencyMaxCap110 DEFAULT  110 FOR LoadEfficiencyMaxCap 
	 END
GO
-----------------------------------Start UserManagement

IF EXISTS(SELECT 1 FROM TCD.USERINROLE WHERE ROLEID=1)
BEGIN
DELETE FROM TCD.USERINROLE WHERE ROLEID=1
END
GO

IF EXISTS(SELECT 1 FROM TCD.USERROLES WHERE ROLEID=1 AND CODE = 'TMB')
BEGIN
DELETE FROM TCD.USERROLES WHERE ROLEID=1 AND CODE = 'TMB'
END
GO

IF EXISTS(SELECT 1 FROM TCD.UserAudit WHERE USERID IN (SELECT USERID FROM TCD.USERINROLE UIN INNER JOIN TCD.USERROLES UR ON UIN.ROLEID = UR.ROLEID WHERE UIN.ROLEID=1)
)
BEGIN
DELETE FROM TCD.UserAudit WHERE USERID IN (SELECT USERID FROM TCD.USERINROLE UIN INNER JOIN TCD.USERROLES UR ON UIN.ROLEID = UR.ROLEID WHERE UIN.ROLEID=1)
END
GO

IF EXISTS(SELECT 1 FROM TCD.USERMASTER WHERE USERID IN (SELECT USERID FROM TCD.USERINROLE UIN INNER JOIN TCD.USERROLES UR ON UIN.ROLEID = UR.ROLEID WHERE UIN.ROLEID=1)
)
BEGIN
DELETE FROM TCD.USERMASTER WHERE USERID IN (SELECT USERID FROM TCD.USERINROLE UIN INNER JOIN TCD.USERROLES UR ON UIN.ROLEID = UR.ROLEID WHERE UIN.ROLEID=1)
END
GO

IF EXISTS(SELECT 1 FROM TCD.UserRoles WHERE ROLEID= 2 AND RoleName = 'Territory Manager : Advanced')
BEGIN
UPDATE TCD.USERROLES SET ROLENAME ='Territory Manager' WHERE ROLEID= 2
    END
GO
-----------------------------------End UserManagement

IF EXISTS(SELECT 1 FROM tcd.UserRoles ur WHERE ur.code='BDM' AND ur.RoleName='Business Development Manager')
BEGIN
UPDATE tcd.UserRoles
SET
    TCD.UserRoles.RoleName = N'Sales Management'
    WHERE tcd.UserRoles.code='BDM'
END
GO

IF NOT Exists(SELECT 1 FROM TCD.[ConduitMenuRoleMapping] where MappingID = 227)
BEGIN
SET IDENTITY_INSERT tcd.ConduitMenuRoleMapping ON
INSERT INTO TCD.ConduitMenuRoleMapping
(
    MappingID, SectionCode, SettingCode, SettingValue, UserRole, UserID, TagID, TagType, UsageUICode, UserRoleCode
)
VALUES
(
     227,'DASHBOARDS','IS_AVAILABLE', 'true',7,NULL,NULL,NULL,'TOOLSET','TRC'
)
SET IDENTITY_INSERT tcd.ConduitMenuRoleMapping OFF
END
GO

IF NOT Exists(SELECT 1 FROM TCD.[ConduitMenuRoleMapping] where MappingID = 228)
BEGIN
SET IDENTITY_INSERT tcd.ConduitMenuRoleMapping ON
INSERT INTO TCD.ConduitMenuRoleMapping
(
    MappingID, SectionCode, SettingCode, SettingValue, UserRole, UserID, TagID, TagType, UsageUICode, UserRoleCode
)
VALUES
(
     228,'DASHBOARDS','IS_AVAILABLE', 'true',4,NULL,NULL,NULL,'TOOLSET','PM'
)
SET IDENTITY_INSERT tcd.ConduitMenuRoleMapping OFF
END
GO

IF NOT Exists(SELECT 1 FROM TCD.[ConduitMenuRoleMapping] where MappingID = 229)
BEGIN
SET IDENTITY_INSERT tcd.ConduitMenuRoleMapping ON
INSERT INTO TCD.ConduitMenuRoleMapping
(
    MappingID, SectionCode, SettingCode, SettingValue, UserRole, UserID, TagID, TagType, UsageUICode, UserRoleCode
)
VALUES
(
     229,'DASHBOARDS','IS_AVAILABLE', 'true',3,NULL,NULL,NULL,'TOOLSET','PE'
)
SET IDENTITY_INSERT tcd.ConduitMenuRoleMapping OFF
END
GO

IF NOT Exists(SELECT 1 FROM TCD.[ConduitMenuRoleMapping] where MappingID = 230)
BEGIN
SET IDENTITY_INSERT tcd.ConduitMenuRoleMapping ON
INSERT INTO TCD.ConduitMenuRoleMapping
(
    MappingID, SectionCode, SettingCode, SettingValue, UserRole, UserID, TagID, TagType, UsageUICode, UserRoleCode
)
VALUES
(
     230,'DASHBOARDS','IS_AVAILABLE', 'true',2,NULL,NULL,NULL,'TOOLSET','OPE'
)
SET IDENTITY_INSERT tcd.ConduitMenuRoleMapping OFF
END
GO

IF NOT Exists(SELECT 1 FROM TCD.[ConduitMenuRoleMapping] where MappingID = 231)
BEGIN
SET IDENTITY_INSERT tcd.ConduitMenuRoleMapping ON
INSERT INTO TCD.ConduitMenuRoleMapping
(
    MappingID, SectionCode, SettingCode, SettingValue, UserRole, UserID, TagID, TagType, UsageUICode, UserRoleCode
)
VALUES
(
     231,'DASHBOARDS','IS_AVAILABLE', 'true',1,NULL,NULL,NULL,'TOOLSET','ALL'
)
SET IDENTITY_INSERT tcd.ConduitMenuRoleMapping OFF
END
GO

IF NOT Exists(SELECT 1 FROM TCD.[ConduitMenuRoleMapping] where MappingID = 240)
BEGIN
SET IDENTITY_INSERT tcd.ConduitMenuRoleMapping ON
INSERT INTO TCD.ConduitMenuRoleMapping
(
    MappingID, SectionCode, SettingCode, SettingValue, UserRole, UserID, TagID, TagType, UsageUICode, UserRoleCode
)
VALUES
(
     240,'DASHBOARDS','IS_AVAILABLE', 'true',5,NULL,NULL,NULL,'TOOLSET','CAM'
)
SET IDENTITY_INSERT tcd.ConduitMenuRoleMapping OFF
END
GO


----------------------REports----------------------

IF NOT Exists(SELECT 1 FROM TCD.[ConduitMenuRoleMapping] where MappingID = 232)
BEGIN
SET IDENTITY_INSERT tcd.ConduitMenuRoleMapping ON
INSERT INTO TCD.ConduitMenuRoleMapping
(
    MappingID, SectionCode, SettingCode, SettingValue, UserRole, UserID, TagID, TagType, UsageUICode, UserRoleCode
)
VALUES
(
     232,'REPORTS','IS_AVAILABLE', 'true',7,NULL,NULL,NULL,'TOOLSET','TRC'
)
SET IDENTITY_INSERT tcd.ConduitMenuRoleMapping OFF
END
GO

IF NOT Exists(SELECT 1 FROM TCD.[ConduitMenuRoleMapping] where MappingID = 233)
BEGIN
SET IDENTITY_INSERT tcd.ConduitMenuRoleMapping ON
INSERT INTO TCD.ConduitMenuRoleMapping
(
    MappingID, SectionCode, SettingCode, SettingValue, UserRole, UserID, TagID, TagType, UsageUICode, UserRoleCode
)
VALUES
(
     233,'REPORTS','IS_AVAILABLE', 'true',4,NULL,NULL,NULL,'TOOLSET','PM'
)
SET IDENTITY_INSERT tcd.ConduitMenuRoleMapping OFF
END
GO

IF NOT Exists(SELECT 1 FROM TCD.[ConduitMenuRoleMapping] where MappingID = 234)
BEGIN
SET IDENTITY_INSERT tcd.ConduitMenuRoleMapping ON
INSERT INTO TCD.ConduitMenuRoleMapping
(
    MappingID, SectionCode, SettingCode, SettingValue, UserRole, UserID, TagID, TagType, UsageUICode, UserRoleCode
)
VALUES
(
     234,'REPORTS','IS_AVAILABLE', 'true',3,NULL,NULL,NULL,'TOOLSET','PE'
)
SET IDENTITY_INSERT tcd.ConduitMenuRoleMapping OFF
END
GO

IF NOT Exists(SELECT 1 FROM TCD.[ConduitMenuRoleMapping] where MappingID = 235)
BEGIN
SET IDENTITY_INSERT tcd.ConduitMenuRoleMapping ON
INSERT INTO TCD.ConduitMenuRoleMapping
(
    MappingID, SectionCode, SettingCode, SettingValue, UserRole, UserID, TagID, TagType, UsageUICode, UserRoleCode
)
VALUES
(
     235,'REPORTS','IS_AVAILABLE', 'true',2,NULL,NULL,NULL,'TOOLSET','OPE'
)
SET IDENTITY_INSERT tcd.ConduitMenuRoleMapping OFF
END
GO

IF NOT Exists(SELECT 1 FROM TCD.[ConduitMenuRoleMapping] where MappingID = 236)
BEGIN
SET IDENTITY_INSERT tcd.ConduitMenuRoleMapping ON
INSERT INTO TCD.ConduitMenuRoleMapping
(
    MappingID, SectionCode, SettingCode, SettingValue, UserRole, UserID, TagID, TagType, UsageUICode, UserRoleCode
)
VALUES
(
     236,'REPORTS','IS_AVAILABLE', 'true',1,NULL,NULL,NULL,'TOOLSET','ALL'
)
SET IDENTITY_INSERT tcd.ConduitMenuRoleMapping OFF
END
GO

------------------------------------- Start:: Providing Report Access to All Roles  -----------------------------------------
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 1 and ReportId=1)
	BEGIN
		INSERT INTO TCD.ReportRoleMapping(ReportId,SettingValue,RoleId,RoleType) Values(1,1,1,'ALL')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 1 and ReportId=2)
	BEGIN
		INSERT INTO TCD.ReportRoleMapping(ReportId,SettingValue,RoleId,RoleType) Values(2,1,1,'ALL')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 1 and ReportId=5)
	BEGIN
		INSERT INTO TCD.ReportRoleMapping(ReportId,SettingValue,RoleId,RoleType) Values(5,1,1,'ALL')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 1 and ReportId=6)
	BEGIN
		INSERT INTO TCD.ReportRoleMapping(ReportId,SettingValue,RoleId,RoleType) Values(6,1,1,'ALL')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 1 and ReportId=10)
	BEGIN
		INSERT INTO TCD.ReportRoleMapping(ReportId,SettingValue,RoleId,RoleType) Values(10,1,1,'ALL')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 1 and ReportId=12)
	BEGIN
		INSERT INTO TCD.ReportRoleMapping(ReportId,SettingValue,RoleId,RoleType) Values(12,1,1,'ALL')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 1 and ReportId=13)
	BEGIN
		INSERT INTO TCD.ReportRoleMapping(ReportId,SettingValue,RoleId,RoleType) Values(13,1,1,'ALL')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 1 and ReportId=30)
	BEGIN
		INSERT INTO TCD.ReportRoleMapping(ReportId,SettingValue,RoleId,RoleType) Values(30,1,1,'ALL')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 4 and ReportId=1)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (1, 1, 4, N'ADM')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 4 and ReportId=2)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (2, 1, 4, N'ADM')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 4 and ReportId=5)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (5, 1, 4, N'ADM')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 4 and ReportId=6)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (6, 1, 4, N'ADM')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 4 and ReportId=10)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (10, 1, 4, N'ADM')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 4 and ReportId=12)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (12, 1, 4, N'ADM')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 4 and ReportId=13)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (13, 1, 4, N'ADM')
	END
GO


IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 9 and ReportId=1)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (1, 1, 9, N'PM')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 9 and ReportId=2)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (2, 1, 9, N'PM')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 9 and ReportId=5)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (5, 1, 9, N'PM')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 9 and ReportId=6)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (6, 1, 9, N'PM')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 9 and ReportId=10)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (10, 1, 9, N'PM')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 9 and ReportId=12)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (12, 1, 9, N'PM')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 9 and ReportId=13)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (13, 1, 9, N'PM')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 9 and ReportId=30)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (30, 1, 9, N'PM')
	END
GO


IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 5 and ReportId=1)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (1, 1, 5, N'TRE')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 5 and ReportId=2)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (2, 1, 5, N'TRE')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 5 and ReportId=5)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (5, 1, 5, N'TRE')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 5 and ReportId=6)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (6, 1, 5, N'TRE')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 5 and ReportId=10)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (10, 1, 5, N'TRE')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 5 and ReportId=12)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (12, 1, 5, N'TRE')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 5 and ReportId=13)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (13, 1, 5, N'TRE')
	END
GO


IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 6 and ReportId=1)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (1, 1, 6, N'BDM')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 6 and ReportId=2)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (2, 1, 6, N'BDM')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 6 and ReportId=5)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (5, 1, 6, N'BDM')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 6 and ReportId=6)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (6, 1, 6, N'BDM')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 6 and ReportId=10)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (10, 1, 6, N'BDM')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 6 and ReportId=12)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (12, 1, 6, N'BDM')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 6 and ReportId=13)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (13, 1, 6, N'BDM')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 6 and ReportId=30)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (30, 1, 6, N'BDM')
	END
GO


IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 7 and ReportId=1)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (1, 1, 7, N'CAM')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 7 and ReportId=2)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (2, 1, 7, N'CAM')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 7 and ReportId=5)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (5, 1, 7, N'CAM')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 7 and ReportId=6)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (6, 1, 7, N'CAM')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 7 and ReportId=10)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (10, 1, 7, N'CAM')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 7 and ReportId=12)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (12, 1, 7, N'CAM')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 7 and ReportId=13)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (13, 1, 7, N'CAM')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 7 and ReportId=30)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (30, 1, 7, N'CAM')
	END
GO


IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 8 and ReportId=1)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (1, 1, 8, N'TRC')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 8 and ReportId=2)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (2, 1, 8, N'TRC')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 8 and ReportId=5)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (5, 1, 8, N'TRC')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 8 and ReportId=6)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (6, 1, 8, N'TRC')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 8 and ReportId=10)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (10, 1, 8, N'TRC')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 8 and ReportId=12)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (12, 1, 8, N'TRC')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 8 and ReportId=13)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (13, 1, 8, N'TRC')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 8 and ReportId=30)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (30, 1, 8, N'TRC')
	END
GO


IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 2 and ReportId=12)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (12, 1, 2, N'TMA')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 2 and ReportId=13)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (13, 1, 2, N'TMA')
	END
GO


IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 3 and ReportId=12)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (12, 1, 3, N'ENG')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 3 and ReportId=13)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (13, 1, 3, N'ENG')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 3 and ReportId=1)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (1, 1, 3, N'ENG')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 3 and ReportId=2)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (2, 1, 3, N'ENG')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 3 and ReportId=5)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (5, 1, 3, N'ENG')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 3 and ReportId=6)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (6, 1, 3, N'ENG')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 3 and ReportId=10)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (10, 1, 3, N'ENG')
	END
GO

IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 2 and ReportId=1)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (1, 1, 2, N'TMA')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 10 and ReportId=1)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (1, 1, 10, N'PE')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 11 and ReportId=1)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (1, 1, 11, N'OPE')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 12 and ReportId=1)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (1, 1, 12, N'ALL')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 2 and ReportId=2)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (2, 1, 2, N'TMA')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 10 and ReportId=2)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (2, 1, 10, N'PE')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 11 and ReportId=2)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (2, 1, 11, N'OPE')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 12 and ReportId=2)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (2, 1, 12, N'ALL')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 2 and ReportId=5)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (5, 1, 2, N'TMA')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 10 and ReportId=5)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (5, 1, 10, N'PE')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 11 and ReportId=5)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (5, 1, 11, N'OPE')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 12 and ReportId=5)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (5, 1, 12, N'ALL')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 2 and ReportId=6)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (6, 1, 2, N'TMA')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 10 and ReportId=6)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (6, 1, 10, N'PE')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 11 and ReportId=6)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (6, 1, 11, N'OPE')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 12 and ReportId=6)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (6, 1, 12, N'ALL')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 2 and ReportId=10)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (10, 1, 2, N'TMA')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 10 and ReportId=10)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (10, 1, 10, N'PE')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 11 and ReportId=10)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (10, 1, 11, N'OPE')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 12 and ReportId=10)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (10, 1, 12, N'ALL')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 10 and ReportId=12)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (12, 1, 10, N'PE')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 11 and ReportId=12)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (12, 1, 11, N'OPE')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 12 and ReportId=12)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (12, 1, 12, N'ALL')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 10 and ReportId=13)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (13, 1, 10, N'PE')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 11 and ReportId=13)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (13, 1, 11, N'OPE')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 12 and ReportId=13)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (13, 1, 12, N'ALL')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 2 and ReportId=30)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (30, 1, 2, N'TMA')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 3 and ReportId=30)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (30, 1, 3, N'ENG')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 4 and ReportId=30)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (30, 1, 4, N'ADM')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 5 and ReportId=30)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (30, 1, 5, N'TRE')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 10 and ReportId=30)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (30, 1, 10, N'PE')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 11 and ReportId=30)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (30, 1, 11, N'OPE')
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportRoleMapping WHERE RoleId = 12 and ReportId=30)
	BEGIN
		INSERT [TCD].[ReportRoleMapping] ([ReportId], [SettingValue], [RoleId], [RoleType]) VALUES (30, 1, 12, N'ALL')
	END
GO

IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 10 and RoleId=11)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(10,1,11)
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 10 and RoleId=12)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(10,1,12)
	END
GO

IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 11 and RoleId=10)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(11,1,10)
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 11 and RoleId=11)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(11,1,11)
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 11 and RoleId=12)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(11,1,12)
	END
GO

IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 12 and RoleId=10)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(12,1,10)
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 12 and RoleId=11)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(12,1,11)
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 12 and RoleId=12)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(12,1,12)
	END
GO

IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 2 and RoleId=10)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(2,1,10)
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 2 and RoleId=11)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(2,1,11)
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 2 and RoleId=12)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(2,1,12)
	END
GO

IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 21 and RoleId=10)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(21,1,10)
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 21 and RoleId=11)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(21,1,11)
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 21 and RoleId=12)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(21,1,12)
	END
GO

IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 22 and RoleId=10)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(22,1,10)
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 22 and RoleId=11)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(22,1,11)
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 22 and RoleId=12)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(22,1,12)
	END
GO

IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 23 and RoleId=10)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(23,1,10)
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 23 and RoleId=11)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(23,1,11)
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 23 and RoleId=12)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(23,1,12)
	END
GO

IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 24 and RoleId=10)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(24,1,10)
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 24 and RoleId=11)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(24,1,11)
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 24 and RoleId=12)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(24,1,12)
	END
GO

IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 25 and RoleId=10)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(25,1,10)
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 25 and RoleId=11)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(25,1,11)
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 25 and RoleId=12)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(25,1,12)
	END
GO

IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 3 and RoleId=10)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(3,1,10)
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 3 and RoleId=11)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(3,1,11)
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 3 and RoleId=12)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(3,1,12)
	END
GO

IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 4 and RoleId=10)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(4,1,10)
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 4 and RoleId=11)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(4,1,11)
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 4 and RoleId=12)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(4,1,12)
	END
GO

IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 5 and RoleId=10)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(5,1,10)
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 5 and RoleId=11)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(5,1,11)
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 5 and RoleId=12)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(5,1,12)
	END
GO

IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 6 and RoleId=10)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(6,1,10)
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 6 and RoleId=11)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(6,1,11)
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 6 and RoleId=12)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(6,1,12)
	END
GO

IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 7 and RoleId=10)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(7,1,10)
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 7 and RoleId=11)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(7,1,11)
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 7 and RoleId=12)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(7,1,12)
	END
GO

IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 8 and RoleId=10)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(8,1,10)
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 8 and RoleId=11)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(8,1,11)
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 8 and RoleId=12)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(8,1,12)
	END
GO

IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 9 and RoleId=10)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(9,1,10)
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 9 and RoleId=11)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(9,1,11)
	END
GO
IF NOT EXISTS(SELECT * FROM TCD.ReportFilterRoleMapping WHERE ReportFilterId = 9 and RoleId=12)
	BEGIN
		INSERT INTO TCD.ReportFilterRoleMapping(ReportFilterId,SettingValue,RoleId) Values(9,1,12)
	END
GO

IF NOT EXISTS (SELECT 1 FROM TCD.ReportDefaultViewRoleMapping  WHERE ReportId=1 AND DefaultViewId=2 AND RoleId=1)
BEGIN
	INSERT INTO TCD.ReportDefaultViewRoleMapping(ReportId,DefaultViewId,RoleId) values(1,2,1)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportDefaultViewRoleMapping  WHERE ReportId=2 AND DefaultViewId=8 AND RoleId=1)
BEGIN
	INSERT INTO TCD.ReportDefaultViewRoleMapping(ReportId,DefaultViewId,RoleId) values(2,8,1)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportDefaultViewRoleMapping  WHERE ReportId=5 AND DefaultViewId=1 AND RoleId=1)
BEGIN
	INSERT INTO TCD.ReportDefaultViewRoleMapping(ReportId,DefaultViewId,RoleId) values(5,1,1)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportDefaultViewRoleMapping  WHERE ReportId=6 AND DefaultViewId=1 AND RoleId=1)
BEGIN
	INSERT INTO TCD.ReportDefaultViewRoleMapping(ReportId,DefaultViewId,RoleId) values(6,1,1)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportDefaultViewRoleMapping  WHERE ReportId=10 AND DefaultViewId=1 AND RoleId=1)
BEGIN
	INSERT INTO TCD.ReportDefaultViewRoleMapping(ReportId,DefaultViewId,RoleId) values(10,1,1)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportDefaultViewRoleMapping  WHERE ReportId=12 AND DefaultViewId=1 AND RoleId=1)
BEGIN
	INSERT INTO TCD.ReportDefaultViewRoleMapping(ReportId,DefaultViewId,RoleId) values(12,1,1)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportDefaultViewRoleMapping  WHERE ReportId=13 AND DefaultViewId=1 AND RoleId=1)
BEGIN
	INSERT INTO TCD.ReportDefaultViewRoleMapping(ReportId,DefaultViewId,RoleId) values(13,1,1)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportDefaultViewRoleMapping  WHERE ReportId=30 AND DefaultViewId=1 AND RoleId=1)
BEGIN
	INSERT INTO TCD.ReportDefaultViewRoleMapping(ReportId,DefaultViewId,RoleId) values(30,1,1)
END
GO

IF NOT EXISTS (SELECT 1 FROM TCD.ReportDefaultViewRoleMapping  WHERE ReportId=1 AND DefaultViewId=2 AND RoleId=2)
BEGIN
	INSERT INTO TCD.ReportDefaultViewRoleMapping(ReportId,DefaultViewId,RoleId) values(1,2,2)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportDefaultViewRoleMapping  WHERE ReportId=1 AND DefaultViewId=2 AND RoleId=10)
BEGIN
	INSERT INTO TCD.ReportDefaultViewRoleMapping(ReportId,DefaultViewId,RoleId) values(1,2,10)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportDefaultViewRoleMapping  WHERE ReportId=1 AND DefaultViewId=2 AND RoleId=11)
BEGIN
	INSERT INTO TCD.ReportDefaultViewRoleMapping(ReportId,DefaultViewId,RoleId) values(1,2,11)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportDefaultViewRoleMapping  WHERE ReportId=1 AND DefaultViewId=2 AND RoleId=12)
BEGIN
	INSERT INTO TCD.ReportDefaultViewRoleMapping(ReportId,DefaultViewId,RoleId) values(1,2,12)
END
GO


IF NOT EXISTS (SELECT 1 FROM TCD.ReportDefaultViewRoleMapping  WHERE ReportId=2 AND DefaultViewId=8 AND RoleId=2)
BEGIN
	INSERT INTO TCD.ReportDefaultViewRoleMapping(ReportId,DefaultViewId,RoleId) values(2,8,2)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportDefaultViewRoleMapping  WHERE ReportId=2 AND DefaultViewId=8 AND RoleId=10)
BEGIN
	INSERT INTO TCD.ReportDefaultViewRoleMapping(ReportId,DefaultViewId,RoleId) values(2,8,10)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportDefaultViewRoleMapping  WHERE ReportId=2 AND DefaultViewId=8 AND RoleId=11)
BEGIN
	INSERT INTO TCD.ReportDefaultViewRoleMapping(ReportId,DefaultViewId,RoleId) values(2,8,11)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportDefaultViewRoleMapping  WHERE ReportId=2 AND DefaultViewId=8 AND RoleId=12)
BEGIN
	INSERT INTO TCD.ReportDefaultViewRoleMapping(ReportId,DefaultViewId,RoleId) values(2,8,12)
END
GO


IF NOT EXISTS (SELECT 1 FROM TCD.ReportDefaultViewRoleMapping  WHERE ReportId=5 AND DefaultViewId=1 AND RoleId=2)
BEGIN
	INSERT INTO TCD.ReportDefaultViewRoleMapping(ReportId,DefaultViewId,RoleId) values(5,1,2)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportDefaultViewRoleMapping  WHERE ReportId=5 AND DefaultViewId=1 AND RoleId=10)
BEGIN
	INSERT INTO TCD.ReportDefaultViewRoleMapping(ReportId,DefaultViewId,RoleId) values(5,1,10)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportDefaultViewRoleMapping  WHERE ReportId=5 AND DefaultViewId=1 AND RoleId=11)
BEGIN
	INSERT INTO TCD.ReportDefaultViewRoleMapping(ReportId,DefaultViewId,RoleId) values(5,1,11)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportDefaultViewRoleMapping  WHERE ReportId=5 AND DefaultViewId=1 AND RoleId=12)
BEGIN
	INSERT INTO TCD.ReportDefaultViewRoleMapping(ReportId,DefaultViewId,RoleId) values(5,1,12)
END
GO

IF NOT EXISTS (SELECT 1 FROM TCD.ReportDefaultViewRoleMapping  WHERE ReportId=6 AND DefaultViewId=1 AND RoleId=2)
BEGIN
	INSERT INTO TCD.ReportDefaultViewRoleMapping(ReportId,DefaultViewId,RoleId) values(6,1,2)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportDefaultViewRoleMapping  WHERE ReportId=6 AND DefaultViewId=1 AND RoleId=10)
BEGIN
	INSERT INTO TCD.ReportDefaultViewRoleMapping(ReportId,DefaultViewId,RoleId) values(6,1,10)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportDefaultViewRoleMapping  WHERE ReportId=6 AND DefaultViewId=1 AND RoleId=11)
BEGIN
	INSERT INTO TCD.ReportDefaultViewRoleMapping(ReportId,DefaultViewId,RoleId) values(6,1,11)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportDefaultViewRoleMapping  WHERE ReportId=6 AND DefaultViewId=1 AND RoleId=12)
BEGIN
	INSERT INTO TCD.ReportDefaultViewRoleMapping(ReportId,DefaultViewId,RoleId) values(6,1,12)
END
GO


IF NOT EXISTS (SELECT 1 FROM TCD.ReportDefaultViewRoleMapping  WHERE ReportId=10 AND DefaultViewId=1 AND RoleId=2)
BEGIN
	INSERT INTO TCD.ReportDefaultViewRoleMapping(ReportId,DefaultViewId,RoleId) values(10,1,2)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportDefaultViewRoleMapping  WHERE ReportId=10 AND DefaultViewId=1 AND RoleId=10)
BEGIN
	INSERT INTO TCD.ReportDefaultViewRoleMapping(ReportId,DefaultViewId,RoleId) values(10,1,10)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportDefaultViewRoleMapping  WHERE ReportId=10 AND DefaultViewId=1 AND RoleId=11)
BEGIN
	INSERT INTO TCD.ReportDefaultViewRoleMapping(ReportId,DefaultViewId,RoleId) values(10,1,11)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportDefaultViewRoleMapping  WHERE ReportId=10 AND DefaultViewId=1 AND RoleId=12)
BEGIN
	INSERT INTO TCD.ReportDefaultViewRoleMapping(ReportId,DefaultViewId,RoleId) values(10,1,12)
END
GO


IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=1 AND RoleId=2)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(1,2,1,1)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=1 AND RoleId=10)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(1,10,1,1)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=1 AND RoleId=11)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(1,11,1,1)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=1 AND RoleId=12)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(1,12,1,1)
END
GO


IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=2 AND RoleId=2)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(2,2,1,null)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=2 AND RoleId=10)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(2,10,1,null)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=2 AND RoleId=11)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(2,11,1,null)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=2 AND RoleId=12)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(2,12,1,null)
END
GO


IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=3 AND RoleId=2)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(3,2,1,null)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=3 AND RoleId=10)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(3,10,1,null)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=3 AND RoleId=11)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(3,11,1,null)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=3 AND RoleId=12)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(3,12,1,null)
END
GO


IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=4 AND RoleId=2)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(4,2,1,null)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=4 AND RoleId=10)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(4,10,1,null)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=4 AND RoleId=11)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(4,11,1,null)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=4 AND RoleId=12)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(4,12,1,null)
END
GO


IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=5 AND RoleId=2)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(5,2,1,null)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=5 AND RoleId=10)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(5,10,1,null)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=5 AND RoleId=11)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(5,11,1,null)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=5 AND RoleId=12)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(5,12,1,null)
END
GO


IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=6 AND RoleId=2)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(6,2,1,null)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=6 AND RoleId=10)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(6,10,1,null)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=6 AND RoleId=11)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(6,11,1,null)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=6 AND RoleId=12)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(6,12,1,null)
END
GO


IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=7 AND RoleId=2)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(7,2,1,null)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=7 AND RoleId=10)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(7,10,1,null)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=7 AND RoleId=11)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(7,11,1,null)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=7 AND RoleId=12)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(7,12,1,null)
END
GO


IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=8 AND RoleId=2)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(8,2,1,null)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=8 AND RoleId=10)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(8,10,1,null)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=8 AND RoleId=11)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(8,11,1,null)
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ReportViewModeRoleMapping  WHERE ViewModeId=8 AND RoleId=12)
BEGIN
	INSERT INTO TCD.ReportViewModeRoleMapping(ViewModeId,RoleId,SettingValue,IsDefault) Values(8,12,1,null)
END
GO


IF NOT EXISTS (SELECT 1 FROM TCD.ConduitMenuRoleMapping  WHERE SectionCode='REPORTS' AND SettingCode='IS_AVAILABLE' AND UserRole=10 AND SettingValue='true')
BEGIN
	INSERT INTO TCD.ConduitMenuRoleMapping(SectionCode,SettingCode,SettingValue,UserRole,UsageUICode,UserRoleCode) Values('REPORTS','IS_AVAILABLE','true',10,'TOOLSET','PE')
END
GO

IF NOT EXISTS (SELECT 1 FROM TCD.ConduitMenuRoleMapping  WHERE SectionCode='REPORTS' AND SettingCode='IS_AVAILABLE' AND UserRole=11 AND SettingValue='true')
BEGIN
	INSERT INTO TCD.ConduitMenuRoleMapping(SectionCode,SettingCode,SettingValue,UserRole,UsageUICode,UserRoleCode) Values('REPORTS','IS_AVAILABLE','true',11,'TOOLSET','OPE')
END
GO

IF NOT EXISTS (SELECT 1 FROM TCD.ConduitMenuRoleMapping  WHERE SectionCode='REPORTS' AND SettingCode='IS_AVAILABLE' AND UserRole=12 AND SettingValue='true')
BEGIN
	INSERT INTO TCD.ConduitMenuRoleMapping(SectionCode,SettingCode,SettingValue,UserRole,UsageUICode,UserRoleCode) Values('REPORTS','IS_AVAILABLE','true',12,'TOOLSET','ALL')
END
GO

--IF EXISTS (SELECT 1 FROM tcd.ReportCategoriesRoleMapping where ReportCategoryId =5 and RoleId  IN (2,3,4))
--BEGIN
--	DELETE from tcd.ReportCategoriesRoleMapping where ReportCategoryId =5 and RoleId  IN (2,3,4)
--END
--GO

--IF EXISTS (SELECT 1 FROM tcd.ReportRoleMapping where ReportId IN (30) and RoleId IN (2,3,4))
--BEGIN
--	DELETE from tcd.ReportRoleMapping where ReportId  in (30) and RoleId IN (2,3,4)
--END
--GO

------------------------------------- End:: Providing Report Access to All Roles  -------------------------------------------

--IF EXISTS(SELECT 1 FROM tcd.LanguageMaster lm WHERE lm.Name = 'English UK')
--BEGIN
--DELETE FROM tcd.LanguageMaster WHERE tcd.LanguageMaster.LanguageId NOT IN (1,2,3,43)
--END
--GO

--DELETE from tcd.ReportCategoriesRoleMapping where ReportCategoryId =5 and RoleId not IN (2,3,5,6,7,4,12)
--DELETE from tcd.ReportRoleMapping where reportid in (30) and RoleId not IN (2,3,5,6,7,4,12)

DELETE from tcd.ReportCategoriesRoleMapping where ReportCategoryId =5 and RoleId  not in  (2,3,4,5,6,7,12)
DELETE from tcd.ReportRoleMapping where reportid  in (30) and RoleId  not in  (2,3,4,5,6,7,12)

--GO

-- NAGoLive II - Support2016.sql DML Scripts --


UPDATE TCD.ConfigSettings
SET
    [Value] = N'10.160.8.29'
WHERE
    [Value] = N'stg-3dtrasarcontroller.nalco.com'
GO
UPDATE TCD.ConfigSettings
SET
    [Value] = N'9343'
WHERE
    [Value] = N'9340'
GO

IF not EXISTS(SELECT 1 FROM TCD.Field f WHERE f.Id = 262 AND f.Label = 'Controller Version')
  BEGIN
	 SET	IDENTITY_INSERT	TCD.Field	ON
	 INSERT INTO tcd.Field
	 (
		Id ,TypeId, Label,Min,Max,FieldGroupId,DataSourceId,IsMandatory,HelpText,HelpTextUrl,DataTypeId,DataCategoryId,CurrencyId,DisplayOrder,ResourceKey,DefaultValue,
		IsEditable,Name,HasFieldTag,DefaultFieldTag,ClassName
	 )
	 VALUES
	 (
		262, 10, N'Controller Version',NULL, NULL, NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,7,N'Controller_Version',N'1.3.0',1,NULL,NULL,NULL,NULL
	 )
	 SET	IDENTITY_INSERT	TCD.Field	OFF
  END
  GO

  IF not EXISTS(SELECT 1 FROM TCD.FieldGroupFieldMapping fgfm WHERE fgfm.FieldId = 262 AND fgfm.FieldGroupId = 4)
  BEGIN
	 SET	IDENTITY_INSERT	TCD.FieldGroupFieldMapping	ON
	 INSERT INTO tcd.FieldGroupFieldMapping
	 (
		Id	,FieldGroupId	,FieldId
	 )
	 VALUES
	 (
		349, 4, 262
	 )
	 SET	IDENTITY_INSERT	TCD.FieldGroupFieldMapping	OFF
  END
  GO

 -- HoldTime Changes - DCS - END
IF EXISTS(SELECT 1 FROM TCD.FieldGroupFieldMapping  WHERE FieldId = 218 AND Id = 304)
BEGIN
UPDATE tcd.FieldGroupFieldMapping
SET

FieldGroupId = 20
WHERE FieldId = 218
AND Id = 304

END
GO

IF EXISTS(SELECT 1 FROM TCD.Field  WHERE Id = 218)
BEGIN
UPDATE tcd.Field
SET
    tcd.Field.DisplayOrder = 5

    WHERE tcd.Field.Id = 218
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.COLUMNS c WHERE c.TABLE_NAME = 'WasherDosingProductMapping' AND c.TABLE_SCHEMA = 'TCD' AND c.COLUMN_NAME = 'ControllerEquipmentSetupId')
BEGIN
    ALTER TABLE TCD.WasherDosingProductMapping ADD [ControllerEquipmentSetupId] smallint NULL 
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.COLUMNS c WHERE c.TABLE_NAME = 'WasherDosingProductMappingHistory' AND c.TABLE_SCHEMA = 'TCD' AND c.COLUMN_NAME = 'ControllerEquipmentSetupId')
BEGIN
    ALTER TABLE TCD.WasherDosingProductMappingHistory ADD [ControllerEquipmentSetupId] smallint NULL 
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.COLUMNS c WHERE c.TABLE_NAME = 'WasherDosingProductMappingHistory' AND c.TABLE_SCHEMA = 'TCD' AND c.COLUMN_NAME = 'IsDeleted')
BEGIN
	ALTER TABLE TCD.WasherDosingProductMappingHistory ADD [IsDeleted] [bit]  NULL
	ALTER TABLE TCD.WasherDosingProductMappingHistory ADD [Delay] [smallint] NULL 
END
GO
------------------------------------------------------------------------------------------------------------------------------------------------------
IF EXISTS(SELECT
			*
		FROM sys.triggers
		WHERE object_id = OBJECT_ID(N'[TCD].[WasherDosingProductMappingAuditTrigger]'))
	BEGIN
		DROP TRIGGER
			TCD.WasherDosingProductMappingAuditTrigger;
	END; 
	GO 

	CREATE	TRIGGER		[TCD].WasherDosingProductMappingAuditTrigger
ON					[TCD].WasherDosingProductMapping
FOR	INSERT, UPDATE
AS
BEGIN

SET	NOCOUNT	ON

DECLARE	@AuditOperation_SQLInsertId			TINYINT				=			NULL
	,	@AuditOperation_SQLUpdateId			TINYINT				=			NULL
	,	@AuditOperationId					TINYINT				=			NULL
	,	@ErrorNumber						INT					=			0
	,	@ErrorMessage						NVARCHAR(2048)		=			NULL
	,	@ErrorSeverity						INT					=			NULL
	,	@ErrorProcedure						SYSNAME				=			NULL
	,	@MessageString						NVARCHAR(2500)		=			NULL
	--,	@SoftDeleteFlag						BIT					=			NULL			--0 for FALSE/1 for TRUE			--SQLEnlight SA0004
	,	@CurrentTimeStamp					DATETIME			=			GETUTCDATE()	--CURRENT_TIMESTAMP

--select	*	from	AuditOperation
SELECT	@AuditOperation_SQLInsertId			=			AO.OperationId
FROM	[TCD].AuditOperation					AO
WHERE	AO.OperationCode					=			'SQLInsert'

SELECT	@AuditOperation_SQLUpdateId			=			AO.OperationId
FROM	[TCD].AuditOperation					AO
WHERE	AO.OperationCode					=			'SQLUpdate'

BEGIN	TRY
	SET @AuditOperationId = @AuditOperation_SQLInsertId;
	IF UPDATE(Quantity)
		SET @AuditOperationId = @AuditOperation_SQLUpdateId
	
		INSERT	[TCD].[WasherDosingProductMappingHistory]	(
				WasherDosingProductMappingId	,OperationTimestamp	,OperationId					,OperationByUserId		,[EcolabAccountNumber]	,WasherDosingSetupId
			,	InjectionNumber					,ProductId			,Quantity		
			--	Adding cols. for myService integration
			,	MyServiceFrmulaStpDsgDvcGuid
			,	MyServiceLastSynchTime
			,	[Delay]
			,	IsDeleted
			,	ControllerEquipmentSetupId
			)
		SELECT	WasherDosingProductMappingId	,@CurrentTimeStamp	,@AuditOperationId	,LastModifiedByUserId	,[EcolabAccountNumber]	,WasherDosingSetupId
			,	InjectionNumber					,ProductId			,Quantity
			--	Adding cols. for myService integration
			,	MyServiceFrmulaStpDsgDvcGuid
			,	MyServiceLastSynchTime
			,	[Delay]
			,	IsDeleted
			,	ControllerEquipmentSetupId
		FROM	[inserted]

END	TRY
BEGIN	CATCH

		SELECT	@ErrorNumber				=			ERROR_NUMBER()
			,	@ErrorMessage				=			ERROR_MESSAGE()
			,	@ErrorProcedure				=			ERROR_PROCEDURE()
			,	@ErrorSeverity				=			ERROR_SEVERITY()

		--GOTO	ErrorHandler
		SET		@MessageString				=	N'An error occured while updating Audit data for WasherDosingProductMapping table. The error is: '
											+	@ErrorMessage + '	'
											+	'Module: ' + @ErrorProcedure
		RAISERROR(@MessageString, @ErrorSeverity, 1)
		RETURN

END	CATCH


IF	@ErrorNumber	=	0
	--GOTO	ExitModule
	RETURN		


ErrorHandler:

SET		@MessageString						=	N'An error occured while updating Audit data for WasherDosingProductMapping table. The error is: '
											+	@ErrorMessage + '	'
											+	'Module: ' + @ErrorProcedure
RAISERROR(@MessageString, @ErrorSeverity, 1)

ExitModule:

SET	NOCOUNT	OFF

RETURN

END
GO
-- File Ended Date : 24/06/2016 --
----------------------------------------------------------------------------------------------

--------------Chemical Consumption and Chemical Inventory column name localization------------------

UPDATE tcd.ReportColumnsMapping SET
		tcd.ReportColumnsMapping.ColumnId = 252
	WHERE
		tcd.ReportColumnsMapping.ColumnId = 47
	AND tcd.ReportColumnsMapping.ReportId = 6;

UPDATE tcd.ReportLocalizationColumnMapping SET
		tcd.ReportLocalizationColumnMapping.ReportColumnId = 252, 
		tcd.ReportLocalizationColumnMapping.UsageKey = 'FIELD_CHEMICALNAME'
	WHERE
		tcd.ReportLocalizationColumnMapping.ReportColumnId = 252
	AND tcd.ReportLocalizationColumnMapping.ReportId = 6;

UPDATE tcd.ReportLocalizationColumnMapping SET
		tcd.ReportLocalizationColumnMapping.UsageKey = 'FIELD_CHEMICALNAME'
	WHERE
		tcd.ReportLocalizationColumnMapping.ReportColumnId = 252
	AND tcd.ReportLocalizationColumnMapping.ReportId = 13;
	
UPDATE tcd.ReportColumnsRoleMapping SET
		tcd.ReportColumnsRoleMapping.ReportColumnId = 252
	WHERE
		tcd.ReportColumnsRoleMapping.ReportId = 6
	AND tcd.ReportColumnsRoleMapping.ReportColumnId = 47;

UPDATE tcd.ReportLocalizationColumnMapping SET
		tcd.ReportLocalizationColumnMapping.UsageKey = 'FIELD_CHEMICALS'
	WHERE
		tcd.ReportLocalizationColumnMapping.ReportColumnId = 47
	AND tcd.ReportLocalizationColumnMapping.ReportId = 5;

-------------- END -- Chemical Consumption and Chemical Inventory column name localization-- END ----------------
---------------------------- Update to Local Report Columns as like in Central---------------------------- 
IF EXISTS(SELECT
				  1
			  FROM tcd.ReportLocalizationColumnMapping AS rlcm
			  WHERE rlcm.ReportColumnId = 243)
	BEGIN
		UPDATE tcd.ReportLocalizationColumnMapping SET
				tcd.ReportLocalizationColumnMapping.UsageKey = 'FIELD_LOCATION'
			WHERE
				tcd.ReportLocalizationColumnMapping.ReportColumnId = 243
			AND tcd.ReportLocalizationColumnMapping.ReportId = 1;
	END;
GO

IF EXISTS(SELECT
				  1
			  FROM tcd.ReportLocalizationColumnMapping AS rlcm
			  WHERE rlcm.ReportColumnId = 247)
	BEGIN
		UPDATE tcd.ReportLocalizationColumnMapping SET
				tcd.ReportLocalizationColumnMapping.UsageKey = 'FIELD_DISPENCER'
			WHERE
				tcd.ReportLocalizationColumnMapping.ReportColumnId = 247
			AND tcd.ReportLocalizationColumnMapping.ReportId = 12;
	END;	
GO
IF EXISTS(SELECT
				  1
			  FROM tcd.ResourceKeyValue
			  WHERE tcd.ResourceKeyValue.KeyName = 'FIELD_TARGETCONSUMPTION'
				AND tcd.ResourceKeyValue.LanguageID = 1)
	BEGIN
		UPDATE tcd.ResourceKeyValue SET
				tcd.ResourceKeyValue.[Value] = 'Standard Consumption'
			WHERE
				tcd.ResourceKeyValue.KeyName = 'FIELD_TARGETCONSUMPTION'
			AND tcd.ResourceKeyValue.LanguageID = 1;
	END;
GO
-------------END--------------- Update to Local Report Columns as like in Central-------------END--------------- 

------
--Column Localization Mapping for reports
if not exists(Select 1 from tcd.ReportLocalizationColumnMapping where ReportId=5 and ReportColumnId=269)
begin
insert into tcd.ReportLocalizationColumnMapping(ReportColumnId,ReportId,UsageKey,UomKey) Values(269,5,'FIELD_Aggregates',NULL)
end
if not exists(Select 1 from tcd.ReportLocalizationColumnMapping where ReportId=5 and ReportColumnId=268)
begin
insert into tcd.ReportLocalizationColumnMapping(ReportColumnId,ReportId,UsageKey,UomKey) Values(268,5,'FIELD_OTHERS',NULL)
end

if not exists(Select 1 from tcd.ReportLocalizationColumnMapping where ReportId=2 and ReportColumnId=269)
begin
insert into tcd.ReportLocalizationColumnMapping(ReportColumnId,ReportId,UsageKey,UomKey) Values(269,2,'FIELD_Aggregates',NULL)
end
if not exists(Select 1 from tcd.ReportLocalizationColumnMapping where ReportId=2 and ReportColumnId=268)
begin
insert into tcd.ReportLocalizationColumnMapping(ReportColumnId,ReportId,UsageKey,UomKey) Values(268,2,'FIELD_OTHERS',NULL)
end
if not exists(Select 1 from tcd.ReportLocalizationColumnMapping where ReportId=2 and ReportColumnId=120)
begin
insert into tcd.ReportLocalizationColumnMapping(ReportColumnId,ReportId,UsageKey,UomKey) Values(120,2,'FIELD_ACTUALPRODUCTIONPERHOUR_REPORTCOLUMN',NULL)
end

if not exists(Select 1 from tcd.ReportLocalizationColumnMapping where ReportId=2 and ReportColumnId=181)
begin
insert into tcd.ReportLocalizationColumnMapping(ReportColumnId,ReportId,UsageKey,UomKey) Values(181,2,'FIELD_TARGETPRODUCTION',NULL)
end

if not exists(Select 1 from tcd.ReportLocalizationColumnMapping where ReportId=2 and ReportColumnId=182)
begin
insert into tcd.ReportLocalizationColumnMapping(ReportColumnId,ReportId,UsageKey,UomKey) Values(182,2,'FIELD_TARGETPRODUCTIONPERHOUR_REPORTCOLUMN',NULL)
end

if not exists(Select 1 from tcd.ReportLocalizationColumnMapping where ReportId=10 and ReportColumnId=83)
begin
insert into tcd.ReportLocalizationColumnMapping(ReportColumnId,ReportId,UsageKey,UomKey) Values(83,10,'FIELD_FORMULAS',NULL)
end

if not exists(Select 1 from tcd.ReportLocalizationColumnMapping where ReportId=1 and ReportColumnId=262)
begin
insert into tcd.ReportLocalizationColumnMapping(ReportColumnId,ReportId,UsageKey,UomKey) Values(262,1,'FIELD_INTERVAL_REPORT',NULL)
end

if not exists(Select 1 from tcd.ReportLocalizationColumnMapping where ReportId=10 and ReportColumnId=262)
begin
insert into tcd.ReportLocalizationColumnMapping(ReportColumnId,ReportId,UsageKey,UomKey) Values(262,10,'FIELD_INTERVAL_REPORT',NULL)
end


if not exists(Select 1 from tcd.ReportLocalizationColumnMapping where ReportId=6 and ReportColumnId=252)
begin
insert into tcd.ReportLocalizationColumnMapping(ReportColumnId,ReportId,UsageKey,UomKey) Values(252,6,'FIELD_CHEMICALNAME',NULL)
end
GO