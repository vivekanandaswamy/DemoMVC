IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetManualUtilityDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetManualUtilityDetails
	END
GO 

CREATE PROCEDURE [TCD].[GetManualUtilityDetails]
(
		@EcolabAccountNumber NVARCHAR(25)
) 
AS
BEGIN
SET NOCOUNT ON
		;
		WITH    CTE
		AS    (
					 SELECT			
									UtilityId,MeterId,RecordedDate,Value,Usage, ROW_NUMBER()   
									OVER (
												 PARTITION
												 BY MeterId
												 ORDER BY UtilityId DESC 
											)AS  RowNumber
							FROM [TCD].ManualUtility
							WHERE IsDeleted <> 1
			  )

			SELECT
				M.MeterId,
				M.Description,
				M.MeterTickUnit,
				M.UtilityType,
				M.GroupId,
				UtilityTypeName = (SELECT
									Name
								FROM [TCD].UtilityMaster UM
								WHERE UM.ResourceId =  M.UtilityType
									),
				LocationName = ( CASE 
									WHEN (M.groupID IS NULL AND M.MachineCompartment IS NULL AND M.IsPlant = 1) THEN 'Plant'
								ELSE
									(SELECT 
										GroupDescription
								FROM [TCD].MachineGroup G
								WHERE G.Id = M.groupID) 
								END
								),
				CTE.UtilityId,
				CTE.RecordedDate,
				CTE.Value,
				CTE.Usage,
				M.MaxValueLimit,
				M.MyServiceMeterGuid
				FROM [TCD].Meter M
				LEFT JOIN CTE ON M.MeterId  =  CTE.MeterId
					AND RowNumber IN (1, 2)
				WHERE M.AllowManualentry = 'TRUE' 
					AND Is_deleted <> 1
					AND M.EcolabAccountNumber = @EcolabAccountNumber
SET NOCOUNT OFF
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[WasherWaterLevelReference]') AND type in (N'U'))
BEGIN
CREATE TABLE [TCD].[WasherWaterLevelReference](
	[Id] [int] NOT NULL,
	[WasherModelId] [smallint] NOT NULL,
	[WaterLevel] [int] NOT NULL,
	[WaterLevelVolume] [decimal](18, 0) NOT NULL,
	[UomCode] [nvarchar](100) NOT NULL,
	[UomDescription] [nvarchar](max) NOT NULL,
	[IsDelete] [bit] NOT NULL,
 CONSTRAINT [PK_WasherWaterLevelReference] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[TCD].[FK_WasherWaterLevelReference_WasherModelSize]') AND parent_object_id = OBJECT_ID(N'[TCD].[WasherWaterLevelReference]'))
ALTER TABLE [TCD].[WasherWaterLevelReference]  WITH CHECK ADD  CONSTRAINT [FK_WasherWaterLevelReference_WasherModelSize] FOREIGN KEY([WasherModelId])
REFERENCES [TCD].[WasherModelSize] ([WasherModelId])
GO

IF NOT EXISTS (SELECT * from sys.key_constraints Where type = N'UQ' AND object_id = OBJECT_ID(N'TCD.UQ_WasherWaterLevelReference')  AND parent_object_id = OBJECT_ID(N'[TCD].[WasherWaterLevelReference]'))
BEGIN
	ALTER TABLE [TCD].[WasherWaterLevelReference] ADD CONSTRAINT [UQ_WasherWaterLevelReference] UNIQUE (WaterLevel,WasherModelId)
END
GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[UpdateMyServiceWasherWaterReference]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.UpdateMyServiceWasherWaterReference
	END
GO 

CREATE PROCEDURE [TCD].[UpdateMyServiceWasherWaterReference]
@Id INT,
@WaterLevel INT,
@WaterLevelVolume DECIMAL(18,0),
@UomCode NVARCHAR(255),
@UomDescription NVARCHAR(Max),
@IsDelete BIT,
@OutputWasherWaterReferenceId INT =	NULL OUTPUT,
@MCH_ID INT

AS

BEGIN

		DECLARE @OutPutList AS TABLE(WaherWaterReferenceId INT)
		DECLARE @WasherModelId INT = 0
		SET @WasherModelId = (SELECT WasherModelId FROM TCD.WasherModelSize WHere MyServiceMCHId = @MCH_ID)
		IF NOT EXISTS(SELECT 1 FROM TCD.WasherWaterLevelReference Where WaterLevel= @WaterLevel AND WasherModelId = @WasherModelId)
			BEGIN
					INSERT INTO TCD.WasherWaterLevelReference
					(
						Id,
						WasherModelId,
						WaterLevel,
						WaterLevelVolume,
						UomCode,
						UomDescription,
						IsDelete
					)

					OUTPUT

					inserted.Id AS WaherWaterReferenceId

					INTO

					@OutPutList(WaherWaterReferenceId)

					SELECT
					@Id,
					@WasherModelId ,
					@WaterLevel,
					@WaterLevelVolume,
					@UomCode,
					@UomDescription,
					@IsDelete	
			END
		ELSE
		
			BEGIN

			UPDATE TCD.WasherWaterLevelReference
			SET
			WaterLevelVolume = @WaterLevelVolume,
			UomCode = @UomCode,
			UomDescription = @UomDescription,
			IsDelete = @IsDelete
			Where WaterLevel= @WaterLevel 
			AND WasherModelId = @WasherModelId

			INSERT INTO  @OutPutList(WaherWaterReferenceId) 
			SELECT Id FROM TCD.WasherWaterLevelReference WHERE WaterLevel= @WaterLevel AND WasherModelId = @WasherModelId

		END

		SELECT TOP 1

		@OutputWasherWaterReferenceId = O.WaherWaterReferenceId FROM @OutPutList O

END
GO

IF NOT EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[TCD].[DF_Plant_DayId]') AND parent_object_id = OBJECT_ID(N'[TCD].[Plant]') AND sys.default_constraints.type = 'D')
BEGIN
ALTER TABLE [TCD].[Plant] ADD  CONSTRAINT [DF_Plant_DayId]  DEFAULT ((1)) FOR [DayId]
END
GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetEcolabSaturation]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetEcolabSaturation
	END
GO

/*

Stored Procedure	:	[TCD].[GetEcolabSaturation]	in	TRASAR3 Db

Purpose				:	To populate values in ...Ecolab Saturation... drop down for Formula details at Configurator... As-is from ConduitLocalDB

Parameters			:	None
							
*/

CREATE PROCEDURE [TCD].[GetEcolabSaturation] 
@TextileId INT
AS 
  BEGIN 
      SET nocount ON; 
	 IF @TextileId > 0
	 BEGIN
		SELECT es.EcolabSaturationId,es.EcolabSaturationName, es.AbsorbancyFactor, es.SpeedAbsorbancyFactor, es.LowAbsorbancyFactor, es.IntermediateAborbancyFactor, es.HighAbsorbancyFactor, es.MyServiceMstrLnnTypId FROM TCD.EcolabSaturation es 
     END
	ELSE
	BEGIN
		SELECT es.EcolabSaturationId,es.EcolabSaturationName, es.AbsorbancyFactor, es.SpeedAbsorbancyFactor, es.LowAbsorbancyFactor, es.IntermediateAborbancyFactor, es.HighAbsorbancyFactor, es.MyServiceMstrLnnTypId FROM TCD.EcolabSaturation es 
	END
  END
GO

UPDATE 
	TCD.Field 
SET Name = 'FactorsMultiplier' 
WHERE 
	TCD.Field.Label = 'Factors Multiplier'
GO

IF NOT EXISTS (SELECT 1 FROM TCD.DimensionalSubunits ds WHERE ds.Unit = N'Energy' AND ds.Subunit = N'kg') 
BEGIN
  INSERT INTO TCD.DimensionalSubunits
  (
      Unit,
      Subunit
  )
  VALUES
  (
      N'Energy', -- Unit - nvarchar
      N'kg' -- Subunit - nvarchar
  )
END
GO

IF NOT EXISTS (SELECT 1 FROM TCD.DimensionalSubunits ds WHERE ds.Unit = N'Energy' AND ds.Subunit = N'kWh') 
BEGIN
  INSERT INTO TCD.DimensionalSubunits
  (
      Unit,
      Subunit
  )
  VALUES
  (
      N'Energy', -- Unit - nvarchar
      N'kWh' -- Subunit - nvarchar
  )
END
GO

IF NOT EXISTS (SELECT 1 FROM TCD.DimensionalSubunits ds WHERE ds.Unit = N'Energy' AND ds.Subunit = N'L') 
BEGIN
  INSERT INTO TCD.DimensionalSubunits
  (
      Unit,
      Subunit
  )
  VALUES
  (
      N'Energy', -- Unit - nvarchar
      N'L' -- Subunit - nvarchar
  )
END
GO


IF NOT EXISTS (SELECT 1 FROM TCD.DimensionalDisplayUnits ddu WHERE ddu.Unit = N'Energy' AND ddu.DisplayUnitID = 47 AND ddu.Subunit = N'kg') 
BEGIN
 INSERT INTO TCD.DimensionalDisplayUnits
 (
     DisplayUnitID,
     Unit,
     Subunit,
     OrderID
 )
 VALUES
 (
     47, -- DisplayUnitID - int
     N'Energy', -- Unit - nvarchar
     N'kg', -- Subunit - nvarchar
     1 -- OrderID - int
 )
END
GO

IF NOT EXISTS (SELECT 1 FROM TCD.DimensionalDisplayUnits ddu WHERE ddu.Unit = N'Energy' AND ddu.DisplayUnitID = 47 AND ddu.Subunit = N'kWh') 
BEGIN
 INSERT INTO TCD.DimensionalDisplayUnits
 (
     DisplayUnitID,
     Unit,
     Subunit,
     OrderID
 )
 VALUES
 (
     47, -- DisplayUnitID - int
     N'Energy', -- Unit - nvarchar
     N'kWh', -- Subunit - nvarchar
     2 -- OrderID - int
 )
END
GO

IF NOT EXISTS (SELECT 1 FROM TCD.DimensionalDisplayUnits ddu WHERE ddu.Unit = N'Energy' AND ddu.DisplayUnitID = 47 AND ddu.Subunit = N'L') 
BEGIN
 INSERT INTO TCD.DimensionalDisplayUnits
 (
     DisplayUnitID,
     Unit,
     Subunit,
     OrderID
 )
 VALUES
 (
     47, -- DisplayUnitID - int
     N'Energy', -- Unit - nvarchar
     N'L', -- Subunit - nvarchar
     3 -- OrderID - int
 )
END
GO

IF NOT EXISTS (SELECT 1 FROM TCD.DimensionalUsageKey duk WHERE duk.UsageKey = N'TCD_GasOil_Price_EMEA') 
BEGIN
 INSERT INTO TCD.DimensionalUsageKey
 (
     UsageKey,
     Unit,
     DisplayUnitID
 )
 VALUES
 (
     N'TCD_GasOil_Price_EMEA', -- UsageKey - nvarchar
     N'Energy', -- Unit - nvarchar
     47 -- DisplayUnitID - int
 )
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.DimensionalUnitsDefaults dud WHERE dud.UsageKey = N'TCD_GasOil_Price_EMEA')
BEGIN
  INSERT INTO TCD.DimensionalUnitsDefaults
  (
      UnitSystemId,
      UsageKey,
      Unit,
      Subunit
  )
  VALUES
  (
      1, 
      N'TCD_GasOil_Price_EMEA', 
      N'Energy',
      N'kWh' -- Subunit - nvarchar
  )
END
GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetWaterTypes]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetWaterTypes
	END
GO 

CREATE PROCEDURE [TCD].[GetWaterTypes] 
(
	@RegionId int
)
AS 
  BEGIN 
      SET nocount ON; 

     SELECT Id,Name,TCD.WaterType.RegionID,MyServiceUtilTypeCode 
	 FROM [TCD].WaterType 
	 WHERE RegionID= @RegionId AND (Name NOT IN ('Cold Soft', 'Hot Soft')) 
	 ORDER BY Id
     
  END
 GO
 
 IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetUtilityUnitDimensionsList]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetUtilityUnitDimensionsList
	END
GO 


CREATE PROCEDURE [TCD].[GetUtilityUnitDimensionsList]

	@EcolabAccountNumber					NVARCHAR(1000)
,	@UsageKey NVARCHAR(200)=NULL

AS
SET NOCOUNT ON
Declare @LanguageId INT=(select RegionId from [TCD].plant where EcolabAccountNumber=@EcolabAccountNumber) --Need to Remove the EcolabAccountNumber from here and pass it as parameter

BEGIN
	BEGIN
IF @UsageKey = 'TCD_GasOil_Price' OR @UsageKey = 'TCD_GasOil_Price_EMEA'
BEGIN
	   SELECT ds.Unit,
			ds.Subunit,
			ds.Subunit AS Value
		FROM TCD.DimensionalSubunits ds
			INNER JOIN
			tcd.DimensionalUnits du ON du.Unit = ds.Unit
			INNER JOIN
			TCD.DimensionalDisplayUnits ddu ON ddu.Unit = ds.Unit
									 AND ddu.Subunit = ds.Subunit
			INNER JOIN
			TCD.DimensionalUsageKey duk ON duk.DisplayUnitID = ddu.DisplayUnitID
			INNER JOIN
			TCD.DimensionalUnitsDefaults dud ON dud.UsageKey = duk.UsageKey
		WHERE duk.UsageKey = @UsageKey
END
ELSE
BEGIN
		 SELECT   DISTINCT Unit,
				 Subunit,
				 RV.Value
	   FROM TCD.DimensionalUnitsDefaults DU
		JOIN
		TCD.ResourceKeyMaster RM ON DU.Subunit = RM.[KeyName]
		JOIN
		TCD.ResourceKeyValue RV ON RM.[KeyName] = RV.[KeyName]
	   WHERE      UsageKey LIKE '%'
						+
						@UsageKey
						+
						'%'
		  AND RV.languageID = @LanguageId;
END
	   SET NOCOUNT OFF
	END

SET NOCOUNT OFF

END
GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[SaveControllerEquipment]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.SaveControllerEquipment
	END
GO

CREATE PROCEDURE [TCD].[SaveControllerEquipment]          
      @EcoLabAccountNumber    NVARCHAR(1000)          
    , @ControllerId     INT          
    , @ControllerEquipmentId    SMALLINT          
    , @ControllerEquipmentTypeId   TINYINT          
    , @ProductId      INT          
    , @PumpCalibration     DECIMAL(18, 3)          
    , @LfsChemicalName     NVARCHAR(200)          
    , @KFactor      DECIMAL(18,2)  = NULL          
    , @TunnelHold      BIT    = NULL          
    , @FlowDetectorType     INT    = NULL      
    , @FlowSwitchNumber        INT        = NULL      
    , @FlowSwitchAlarm     BIT    = NULL          
    , @FlowMeterAlarm     BIT    = NULL          
    , @FlowMeterType     INT    = NULL          
    , @FlowAlarmDelay     DECIMAL(18,2)    = NULL          
    , @FlowMeterPumpDelay    DECIMAL(18,2)    = NULL          
    , @FlowMeterAlarmDelay    DECIMAL(18,2)    = NULL          
    , @LfsChemicalNameTag    NVARCHAR(200)  = NULL          
    , @KfactorTag      NVARCHAR(200)  = NULL          
    , @CalibrationTag     NVARCHAR(200)  = NULL          
    , @ControllerEquipmentTypeModelId  INT = NULL          
    , @ConventionalWasherGroupConnection BIT           
    , @AxillaryPumpCalibration   SMALLINT          
    , @FlowmeterSwitchActivated   BIT          
    , @FlushWhileDosing      BIT          
    , @WeightControlledDosage    BIT          
    , @EquipmentDoseAlone       BIT          
    , @LowLevelAlarm          BIT          
    , @LeakageAlarm          BIT          
    , @FlushTime         SMALLINT          
    , @PumpingTime         SMALLINT          
    , @PreFlushTime        SMALLINT          
    , @NightFlushPauseTime       SMALLINT          
    , @NightFlushTime        SMALLINT          
    , @AcceptedDeviation       SMALLINT          
    , @LineNumber      TINYINT          
    , @MaximumDosingTime    SMALLINT          
    , @FlowSwitchTimeOut    decimal(18,1)          
    , @UserId       INT                 
    , @FlushValveNumber   TINYINT    = NULL      
    , @CalibrationConductSS_Tank DECIMAL(18,2)  = NULL      
    , @BackFlowControl    BIT        
    , @FactorFM_B_FM      SMALLINT = NULL      
    , @AcceptedDeviationRingLine SMALLINT   = NULL       
    , @UsePumpOfGroup1ForTunnel BIT   = NULL         
    , @pHSensorEnabled    BIT   = NULL    
 , @FlushTimeForFlushValve    INT   = NULL      
    , @Concentration      INT     = NULL      
    , @Deadband     BIT   = NULL     
 , @ValveOutputAsTom BIT = NULL   
    ,@MinimumFlowRate INT = NULL
    ,@ProductDensity DECIMAL(18,2) = NULL
    , @MaximumConcentration INT = NULL
				--Adding these 3 param as part of re-factoring for integration with Synch/Configurator
    , @OutputControllerEquipmentSetupId INT   =   NULL OUTPUT          
    , @LastModifiedTimestampAtCentral  DATETIME =   NULL   --Nullable for local call; Synch/Central call will have to pass this -          
																								--else, it will be treated as a local call
    , @OutputLastModifiedTimestampAtLocal DATETIME =   NULL OUTPUT          

AS
BEGIN

SET NOCOUNT ON          

DECLARE @Equipments TABLE (        
ProductId INT,        
EcoLabAccountNumber NVARCHAR(25),        
ControllerId INT        
)        
DECLARE @ReturnValue     INT      =   0          
 , @IsActive      BIT          
 , @ErrorId      INT      =   0          
 --, @ErrorMessage     NVARCHAR(4000)   =   N''          
 --, @ErrorNumber     INT     =   0          
 , @ErrorMessage     NVARCHAR(4000)   =   N''          
 , @ErrorSeverity     INT     =   NULL          
 , @ErrorProcedure     SYSNAME    =   NULL          
 , @MessageString     NVARCHAR(2500)  =   NULL          

 , @MaximumChemicalCount   TINYINT     =   NULL          
 , @DistinctChemicalCount   TINYINT     =   NULL          
 , @ControllerTypeId    INT          
 , @CurrentUTCTime     DATETIME    =   GETUTCDATE()          

--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
SET  @OutputLastModifiedTimestampAtLocal      =   @CurrentUTCTime          
SET  @OutputControllerEquipmentSetupId      =   ISNULL(@OutputControllerEquipmentSetupId, NULL)   --SQLEnlight SA0121          



SELECT @MaximumChemicalCount     =   CMCTM.MaximumChemicalCount          
  ,@ControllerTypeId      =   CC.ControllerTypeId          
FROM [TCD].ConduitController CC          
JOIN [TCD].ControllerModelControllerTypeMapping CMCTM          
 ON CC.ControllerModelId     =   CMCTM.ControllerModelId          
 AND CC.ControllerTypeId      =   CMCTM.ControllerTypeId          
WHERE CC.ControllerId       =   @ControllerId          

set @MaximumChemicalCount = 30 -- Added dummy value by srikanth, at times we are getting this value as 1, so that user is not able to add pumps more than 1. //Lemuel handled how many pumps should display based on the configuration so this check is useles 

    
     
       
         
          
SET  @IsActive        =   CASE WHEN @ProductId IS NULL THEN 'FALSE'          
                 ELSE 'TRUE'          
															END

 DECLARE @ModuleType INT = 4 --select MTy.ModuleTypeId from TCD.ModuleType MTy WHERE ModuleDescription like '%Pump%Valve%'          
					,@DefaultFrequency INT = 60
					,@TagTypeLfs VARCHAR(100) = 'Tag_NML'
					,@TagTypeKfactor VARCHAR(100) = 'Tag_PPOL'
					,@TagTypeCalibration VARCHAR(100) = 'Tag_OPSL'
					,@Result1 INT = NULL
					,@Result2 INT = NULL
					,@Result3 INT = NULL
     ,@Type INT = 4 --@ModuleType          
					,@RoleId INT = (SELECT UR.LevelId FROM TCD.UserMaster UM
														INNER JOIN TCD.UserInRole UIR ON UM.UserId = UIR.UserId
														INNER JOIN TCD.UserRoles UR ON UIR.RoleId = UR.RoleId
														WHERE UM.UserId = @UserId)

DECLARE
  @OutputList      AS TABLE  (          
  ControllerEquipmentSetupId   INT          
 , LastModifiedTimestamp    DATETIME          
	)

IF EXISTS ( SELECT 1          
    FROM [TCD].ControllerEquipmentSetup  CES          
    WHERE CES.ControllerId     =   @ControllerId          
     AND CES.ControllerEquipmentId   =   @ControllerEquipmentId          
     AND CES.EcoLabAccountNumber    =   @EcoLabAccountNumber          
			)
		BEGIN
				--If the call is not local, check that the LastModifiedTime matches with the central
    IF (          
      @LastModifiedTimestampAtCentral   IS NOT NULL          
     AND NOT EXISTS ( SELECT 1          
          FROM TCD.[ControllerEquipmentSetup]          
																		CES
          WHERE CES.EcolabAccountNumber = @EcolabAccountNumber        
           AND CES.ControllerId  = @ControllerId          
           AND CES.ControllerEquipmentId          
                  = @ControllerEquipmentId          
           AND CES.LastModifiedTime = @LastModifiedTimestampAtCentral          
									)
					)
					BEGIN
       SET   @ErrorId      = 60000          
       SET   @ErrorMessage     = N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'          
       RAISERROR (@ErrorMessage, 16, 1)          
       SET   @ReturnValue     = -1          
       RETURN  (@ReturnValue)          
					END
				
				--Proceed, since it's either a local call or Synch. call with synch. time matching
    SELECT @DistinctChemicalCount    =   COUNT(DISTINCT D.ProductId) --distinct count          
    FROM (          
      SELECT @ProductId     AS   ProductId     --being assigned          
						UNION
      SELECT DISTINCT ProductId  AS   ProductId     --already assigned          
      FROM [TCD].ControllerEquipmentSetup          
      WHERE ControllerId    =   @ControllerId          
       AND ControllerEquipmentId  <>   @ControllerEquipmentId          
       AND ProductId     <>   @ProductId          
      ) D          

    IF ( @DistinctChemicalCount > @MaximumChemicalCount )          
				BEGIN
      SET @ErrorId   = 51000          
      SET @ErrorMessage  = N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Maximum chemical count exceeded. Cannot assign new chemical'          
      --GOTO ErrorHandler          
      RAISERROR (@ErrorMessage, 16, 1)          
      SET @ReturnValue = -1          
      RETURN (@ReturnValue)          
				END
				
				--DECLARE @PumpId INT = (SELECT ControllerEquipmentSetupId
    --            FROM [TCD].ControllerEquipmentSetup          
    --            WHERE ControllerId  = @ControllerId           
    --            AND ControllerEquipmentId = @ControllerEquipmentId           
    --            AND EcoLabAccountNumber  = @EcoLabAccountNumber)          

				--IF(@RoleId =8)
    -- BEGIN          
    --   IF(@LfsChemicalNameTag IS NOT NULL AND @LfsChemicalNameTag <> '')          
    --    BEGIN          
    --     EXEC @Result1 = TCD.CheckDuplicateTag @LfsChemicalNameTag, @ControllerID, @PumpId, @Type          
    --     IF(@Result1 = 0)          
    --     BEGIN          
    --     SET @ErrorMessage = '801,'          
    --    END          
    --   END          
    --   IF(@KfactorTag IS NOT NULL AND @KfactorTag <> '')          
    --    BEGIN          
    --     EXEC @Result2 = TCD.CheckDuplicateTag @KfactorTag,@ControllerID, @PumpId, @Type          
    --     IF(@Result2 = 0)          
    --     BEGIN          
    --     SET @ErrorMessage = @ErrorMessage+'802,'          
    --     END          
    --    END          
    --   IF(@CalibrationTag IS NOT NULL AND @CalibrationTag <> '')          
    --   BEGIN          
    --    EXEC @Result3 = TCD.CheckDuplicateTag @CalibrationTag,@ControllerID, @PumpId, @Type          
    --    IF(@Result3 = 0)          
    --    BEGIN          
    --    SET @ErrorMessage = @ErrorMessage+'803,'          
    --    END          
    --   END          
    -- END          

				--SET @ErrorMessage = @ErrorMessage + CONVERT(VARCHAR(100),'')

				--IF(@ErrorMessage <> '')
    -- RAISERROR(@ErrorMessage, 16, 1)          
				--ELSE
					BEGIN
      BEGIN TRY          
        BEGIN TRAN          

 --       UPDATE [TCD].ControllerEquipmentSetup          
 --        SET ProductId      =   @ProductId          
 --        , IsActive      =   @IsActive          
 --        , LfsChemicalName    =   CASE @IsActive WHEN 'TRUE' THEN @LfsChemicalName   ELSE NULL END          
 --        , KFactor      =   CASE @IsActive WHEN 'TRUE' THEN @KFactor     ELSE NULL END          
 --        , PumpCalibration    =   CASE @IsActive WHEN 'TRUE' THEN @PumpCalibration   ELSE NULL END          
				
 --        , TunnelHold     =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @TunnelHold   ELSE NULL END ELSE NULL END          
 --        , FlowDetectorType    =   CASE @IsActive WHEN 'TRUE' THEN CASE WHEN @ControllerTypeId IN(2,6,7, 12,10, 14,8, 13,9,11) THEN @FlowDetectorType  ELSE NULL END ELSE NULL END   
 --        , FlowSwitchNumber    =    @FlowSwitchNumber  
 --        , FlowSwitchAlarm    =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowSwitchAlarm  ELSE NULL END ELSE NULL END          
 --        , FlowMeterAlarm     =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterAlarm  ELSE NULL END ELSE NULL END          
 --        , FlowMeterType     =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterType   ELSE NULL END ELSE NULL END          
 --        , FlowAlarmDelay     =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowAlarmDelay ELSE NULL END ELSE NULL END          
 --        , FlowMeterPumpDelay    =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterPumpDelay  ELSE NULL END ELSE NULL END          
 --        , FlowMeterAlarmDelay    =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterAlarmDelay ELSE NULL END ELSE NULL END          
 --        , ControllerEquipmentTypeModelId =   CASE @IsActive WHEN 'TRUE' THEN @ControllerEquipmentTypeModelId      ELSE NULL END          
 --            , ConventionalWasherGroupConnection =   CASE @IsActive WHEN 'TRUE' THEN @ConventionalWasherGroupConnection  ELSE 0 END          
 --            , AxillaryPumpCalibration   =   CASE @IsActive WHEN 'TRUE' THEN @AxillaryPumpCalibration    ELSE 0 END          
 --            , FlowmeterSwitchActivated   =   CASE @IsActive WHEN 'TRUE' THEN @FlowmeterSwitchActivated   ELSE 0 END          
 --            , FlushWhileDosing     =   CASE @IsActive WHEN 'TRUE' THEN @FlushWhileDosing      ELSE 0 END          
 --            , WeightControlledDosage    =   CASE @IsActive WHEN 'TRUE' THEN @WeightControlledDosage     ELSE 0 END          
 --            , EquipmentDoseAlone       =   CASE @IsActive WHEN 'TRUE' THEN @EquipmentDoseAlone        ELSE 0 END          
 --            , LowLevelAlarm          =   CASE @IsActive WHEN 'TRUE' THEN @LowLevelAlarm           ELSE 0 END          
 --            , LeakageAlarm          =   CASE @IsActive WHEN 'TRUE' THEN @LeakageAlarm           ELSE 0 END          
 --            , FlushTime         =   CASE @IsActive WHEN 'TRUE' THEN @FlushTime         ELSE NULL END          
 --            , PumpingTime        =   CASE @IsActive WHEN 'TRUE' THEN @PumpingTime         ELSE NULL END          
 --            , PreFlushTime        =   CASE @IsActive WHEN 'TRUE' THEN @PreFlushTime         ELSE NULL END          
 --            , NightFlushPauseTime       =   CASE @IsActive WHEN 'TRUE' THEN @NightFlushPauseTime       ELSE NULL END          
 --            , NightFlushTime        =   CASE @IsActive WHEN 'TRUE' THEN @NightFlushTime        ELSE NULL END          
 --            , AcceptedDeviation       =   CASE @IsActive WHEN 'TRUE' THEN @AcceptedDeviation        ELSE NULL END          
 --            , LineNumber        =   CASE @IsActive WHEN 'TRUE' THEN @LineNumber           ELSE 0 END          
 --            , MaximumDosingTime    =   CASE @IsActive WHEN 'TRUE' THEN @MaximumDosingTime     ELSE NULL END          
 --        , FlowSwitchTimeOut    =   CASE @IsActive WHEN 'TRUE' THEN @FlowSwitchTimeOut     ELSE NULL END       
 --       , ValveOutputAsTom               =   CASE @IsActive WHEN 'TRUE' THEN @ValveOutputAsTom           ELSE 0 END        

 --        , LastModifiedByUserId   =   @UserId          
 --       --** Adding a part of integration with Synch./Central -->          
 --        , LastModifiedTime    =   @CurrentUTCTime                  
 --      , FlushValveNumber  =   CASE @IsActive WHEN 'TRUE' THEN @FlushValveNumber     ELSE NULL END           
 --, CalibrationConductSS_Tank =   CASE @IsActive WHEN 'TRUE' THEN @CalibrationConductSS_Tank     ELSE NULL END         
 --      , BackFlowControl  =   CASE @IsActive WHEN 'TRUE' THEN @BackFlowControl     ELSE 'False' END            
 --      , FactorFM_B_FM   =   CASE @IsActive WHEN 'TRUE' THEN @FactorFM_B_FM     ELSE NULL END                
 --      , AcceptedDeviationRingLine =   CASE @IsActive WHEN 'TRUE' THEN @AcceptedDeviationRingLine     ELSE NULL END           
 --      , UsePumpOfGroup1ForTunnel =   CASE @IsActive WHEN 'TRUE' THEN @UsePumpOfGroup1ForTunnel     ELSE NULL END             
 --      , pHSensorEnabled    =   CASE @IsActive WHEN 'TRUE' THEN @pHSensorEnabled     ELSE NULL END        
 --   , FlushTimeForFlushValve = @FlushTimeForFlushValve   
 --      , Concentration =   CASE @IsActive WHEN 'TRUE' THEN @Concentration     ELSE NULL END             
 --      , Deadband    =   CASE @IsActive WHEN 'TRUE' THEN @Deadband     ELSE NULL END          
 --      , MinimumFlowRate = CASE @IsActive WHEN 'TRUE' THEN @MinimumFlowRate     ELSE NULL END  
 --      , ProductDensity = CASE @IsActive WHEN 'TRUE' THEN @ProductDensity     ELSE NULL END
 --      , MaximumConcentration = CASE @IsActive WHEN 'TRUE' THEN @MaximumConcentration     ELSE NULL END
 --       OUTPUT inserted.ControllerEquipmentSetupId   AS   ControllerEquipmentSetupId          
 --        , inserted.LastModifiedTime     AS   LastModifiedTime          
 --       INTO @OutputList (          
	--									ControllerEquipmentSetupId
 --        , LastModifiedTimestamp          
	--								)
 --       --** <--          
 --       WHERE ControllerId    =   @ControllerId          
 --       AND ControllerEquipmentId   =   @ControllerEquipmentId          
 --       AND EcoLabAccountNumber    =   @EcoLabAccountNumber           



       IF(@IsActive='TRUE' AND @ControllerTypeId IN(2,6,7, 12,10, 14,8, 13,9,11))
       BEGIN
       UPDATE [TCD].ControllerEquipmentSetup          
         SET ProductId      =   @ProductId          
         , IsActive      =   @IsActive          
         , LfsChemicalName    =    @LfsChemicalName             
         , KFactor      =    @KFactor               
         , PumpCalibration    =    @PumpCalibration             
				
         , TunnelHold     =     @TunnelHold             
         , FlowDetectorType    = @FlowDetectorType   
         , FlowSwitchNumber    =    @FlowSwitchNumber  
         , FlowSwitchAlarm    =   CASE @ControllerTypeId WHEN 2 THEN @FlowSwitchAlarm  ELSE NULL END          
         , FlowMeterAlarm     =  CASE @ControllerTypeId WHEN 2 THEN @FlowMeterAlarm  ELSE NULL END       
         , FlowMeterType     =   CASE @ControllerTypeId WHEN 2 THEN @FlowMeterType   ELSE NULL END      
         , FlowAlarmDelay     =   CASE @ControllerTypeId WHEN 2 THEN @FlowAlarmDelay ELSE NULL END       
         , FlowMeterPumpDelay    =  CASE @ControllerTypeId WHEN 2 THEN @FlowMeterPumpDelay  ELSE NULL END       
         , FlowMeterAlarmDelay    =   CASE @ControllerTypeId WHEN 2 THEN @FlowMeterAlarmDelay ELSE NULL END 
         , ControllerEquipmentTypeModelId =    @ControllerEquipmentTypeModelId                
             , ConventionalWasherGroupConnection =    @ConventionalWasherGroupConnection            
             , AxillaryPumpCalibration   =    @AxillaryPumpCalibration              
             , FlowmeterSwitchActivated   =    @FlowmeterSwitchActivated             
             , FlushWhileDosing     =    @FlushWhileDosing                
             , WeightControlledDosage    =    @WeightControlledDosage               
             , EquipmentDoseAlone       =    @EquipmentDoseAlone                  
             , LowLevelAlarm          =    @LowLevelAlarm                     
             , LeakageAlarm          =    @LeakageAlarm                     
             , FlushTime         =    @FlushTime                   
             , PumpingTime        =    @PumpingTime                   
             , PreFlushTime        =    @PreFlushTime                   
             , NightFlushPauseTime       =    @NightFlushPauseTime                 
             , NightFlushTime        =    @NightFlushTime                  
             , AcceptedDeviation       =    @AcceptedDeviation                  
             , LineNumber        =    @LineNumber                     
             , MaximumDosingTime    =    @MaximumDosingTime               
         , FlowSwitchTimeOut    =    @FlowSwitchTimeOut            
        , ValveOutputAsTom               =    @ValveOutputAsTom                   

         , LastModifiedByUserId   =   @UserId          
        --** Adding a part of integration with Synch./Central -->          
         , LastModifiedTime    =   @CurrentUTCTime                  
       , FlushValveNumber  =    @FlushValveNumber                
 , CalibrationConductSS_Tank =    @CalibrationConductSS_Tank              
       , BackFlowControl  =    @BackFlowControl      
       , FactorFM_B_FM   =    @FactorFM_B_FM                     
       , AcceptedDeviationRingLine =    @AcceptedDeviationRingLine                
       , UsePumpOfGroup1ForTunnel =    @UsePumpOfGroup1ForTunnel                  
       , pHSensorEnabled    =    @pHSensorEnabled             
    , FlushTimeForFlushValve = @FlushTimeForFlushValve   
       , Concentration =    @Concentration                  
       , Deadband    =    @Deadband               
       , MinimumFlowRate =  @MinimumFlowRate       
       , ProductDensity =  @ProductDensity     
       , MaximumConcentration =  @MaximumConcentration     
        OUTPUT inserted.ControllerEquipmentSetupId   AS   ControllerEquipmentSetupId          
         , inserted.LastModifiedTime     AS   LastModifiedTime          
        INTO @OutputList (          
										ControllerEquipmentSetupId
         , LastModifiedTimestamp          
									)
        --** <--          
        WHERE ControllerId    =   @ControllerId          
        AND ControllerEquipmentId   =   @ControllerEquipmentId          
        AND EcoLabAccountNumber    =   @EcoLabAccountNumber  
        
        END
        
        
         IF(@IsActive='FALSE' AND @ControllerTypeId IN(2,6,7, 12,10, 14,8, 13,9,11))
       BEGIN
       UPDATE [TCD].ControllerEquipmentSetup          
         SET ProductId      =   @ProductId          
         , IsActive      =   @IsActive          
         , LfsChemicalName    =   NULL         
         , KFactor      =   NULL   
         , PumpCalibration    =   NULL  
				
         , TunnelHold     =    NULL       
         , FlowDetectorType    = NULL   
         , FlowSwitchNumber    =    @FlowSwitchNumber  
         , FlowSwitchAlarm    =    NULL        
         , FlowMeterAlarm     =    NULL        
         , FlowMeterType     =   NULL           
         , FlowAlarmDelay     =  NULL          
         , FlowMeterPumpDelay    =    NULL          
         , FlowMeterAlarmDelay    =    NULL          
         , ControllerEquipmentTypeModelId =    NULL           
             , ConventionalWasherGroupConnection =   0      
             , AxillaryPumpCalibration   =    0           
             , FlowmeterSwitchActivated   =   0           
             , FlushWhileDosing     =    0           
             , WeightControlledDosage    =  0           
             , EquipmentDoseAlone       =   0           
             , LowLevelAlarm          =    0           
             , LeakageAlarm          =   0           
             , FlushTime         =  NULL           
             , PumpingTime        =    NULL           
             , PreFlushTime        =    NULL           
             , NightFlushPauseTime       =    NULL           
             , NightFlushTime        =     NULL           
             , AcceptedDeviation       =     NULL           
             , LineNumber        =  0           
             , MaximumDosingTime    =   NULL           
         , FlowSwitchTimeOut    =    NULL        
        , ValveOutputAsTom               =   0         

         , LastModifiedByUserId   =   @UserId          
        --** Adding a part of integration with Synch./Central -->          
         , LastModifiedTime    =   @CurrentUTCTime                  
       , FlushValveNumber  =    NULL           
 , CalibrationConductSS_Tank =    NULL         
       , BackFlowControl  =   'False'           
       , FactorFM_B_FM   =    NULL            
       , AcceptedDeviationRingLine =   NULL         
       , UsePumpOfGroup1ForTunnel =   NULL        
       , pHSensorEnabled    =  NULL      
    , FlushTimeForFlushValve = @FlushTimeForFlushValve   
       , Concentration =   NULL        
       , Deadband    =    NULL       
       , MinimumFlowRate =  NULL 
       , ProductDensity =  NULL 
       , MaximumConcentration =  NULL 
        OUTPUT inserted.ControllerEquipmentSetupId   AS   ControllerEquipmentSetupId          
         , inserted.LastModifiedTime     AS   LastModifiedTime          
        INTO @OutputList (          
										ControllerEquipmentSetupId
         , LastModifiedTimestamp          
									)
        --** <--          
        WHERE ControllerId    =   @ControllerId          
        AND ControllerEquipmentId   =   @ControllerEquipmentId          
        AND EcoLabAccountNumber    =   @EcoLabAccountNumber           
        END
        
        SET @ErrorId = @@ERROR          

        IF (@ErrorId <> 0)          
									BEGIN
          IF @@TRANCOUNT > 0          
											ROLLBACK

          SET  @ErrorMessage  = N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating Equipment data'          
          --GOTO Errorhandler          
          RAISERROR (@ErrorMessage, 16, 1)          
          SET @ReturnValue = -1          
          RETURN (@ReturnValue)          
									END

								---Tags---
								--IF(@RoleId =8)
								--BEGIN
        --  IF(@IsActive = 'TRUE')          
        --    BEGIN          
        --      --1st if-else...          
        --      IF NOT EXISTS(SELECT 1 FROM TCD.ModuleTags WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND Active = 1 AND TagType = @TagTypeLfs)          
        --        BEGIN          
        --          IF(@LfsChemicalNameTag IS NOT NULL AND @LfsChemicalNameTag <> '')           
        --           INSERT INTO [TCD].ModuleTags (EcolabAccountNumber ,TagType,TagAddress,ModuleTypeId,ModuleID,DeadBand,Active) VALUES(@EcoLabAccountNumber ,@TagTypeLfs,@LfsChemicalNameTag,@ModuleType,@PumpId,@DefaultFrequency,1)          
        --        END          
        --      ELSE          
        --      IF(@LfsChemicalNameTag IS NOT NULL AND @LfsChemicalNameTag <> '')          
        --        UPDATE [TCD].ModuleTags SET TagAddress = @LfsChemicalNameTag WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND TagType = @TagTypeLfs AND Active = 1          
        --      ELSE          
        --        UPDATE [TCD].ModuleTags SET Active = 0 WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND TagType = @TagTypeLfs AND Active = 1          

        --      --2nd if-else...          
        --      IF NOT EXISTS(SELECT 1 FROM TCD.ModuleTags WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND Active = 1 AND TagType = @TagTypeKfactor)          
        --        BEGIN          
        --          IF(@KfactorTag IS NOT NULL AND @KfactorTag <> '')          
        --           INSERT INTO [TCD].ModuleTags (EcolabAccountNumber ,TagType,TagAddress,ModuleTypeId,ModuleID,DeadBand,Active) VALUES(@EcoLabAccountNumber ,@TagTypeKfactor,@KfactorTag,@ModuleType,@PumpId,@DefaultFrequency,1)          
        --        END          
        --      ELSE           
        --      IF(@KfactorTag IS NOT NULL AND @KfactorTag <> '')          
        --        UPDATE [TCD].ModuleTags SET TagAddress = @KfactorTag WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND TagType = @TagTypeKfactor AND Active = 1          
        --      ELSE          
        --        UPDATE [TCD].ModuleTags SET Active = 0 WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND TagType = @TagTypeKfactor AND Active = 1          

        --      --3rd if-else...          
        --      IF NOT EXISTS(SELECT 1 FROM TCD.ModuleTags WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND Active = 1 AND TagType = @TagTypeCalibration)          
        --        BEGIN          
        --          IF(@CalibrationTag IS NOT NULL AND @CalibrationTag <> '')          
        --           INSERT INTO [TCD].ModuleTags (EcolabAccountNumber ,TagType,TagAddress,ModuleTypeId,ModuleID,DeadBand,Active) VALUES(@EcoLabAccountNumber ,@TagTypeCalibration,@CalibrationTag,@ModuleType,@PumpId,@DefaultFrequency,1)          
        --        END          
        --      ELSE           
        --      IF(@CalibrationTag IS NOT NULL AND @CalibrationTag <> '')          
        --        UPDATE [TCD].ModuleTags SET TagAddress = @CalibrationTag WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND TagType = @TagTypeCalibration AND Active = 1          
        --      ELSE          
        --        UPDATE [TCD].ModuleTags SET Active = 0 WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND TagType = @TagTypeCalibration AND Active = 1          
        --    END --@IsActive = 'TRUE'          
        --  ELSE          
        --    BEGIN --Can be combined into 1 update stmt. ...          
        --      UPDATE [TCD].ModuleTags SET Active = 0 WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND TagType = @TagTypeLfs AND Active = 1          
        --      UPDATE [TCD].ModuleTags SET Active = 0 WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND TagType = @TagTypeKfactor AND Active = 1          
        --      UPDATE [TCD].ModuleTags SET Active = 0 WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND TagType = @TagTypeCalibration AND Active = 1          
        --    END          
								--END
								-----Tags---			
							
        SELECT TOP 1          
          @OutputControllerEquipmentSetupId = O.ControllerEquipmentSetupId          
        FROM @OutputList   O          

        IF @@TRANCOUNT > 0          
									COMMIT
      END TRY          
      BEGIN CATCH          
        IF @@TRANCOUNT > 0          
									ROLLBACK
							
        SELECT /*@ErrorNumber    =  ERROR_NUMBER()          
         , */@ErrorMessage    =  ERROR_MESSAGE()          
         , @ErrorProcedure    =  ERROR_PROCEDURE()          
         , @ErrorSeverity    =  ERROR_SEVERITY()          
							
        SET  @OutputControllerEquipmentSetupId          
                 =  NULL          
        SET  @ReturnValue    =  -1          
        SET  @MessageString    =  N'An error occured while Updating Pump/Valve details. The error is: '          
                 +  @ErrorMessage + ' '          
                 +  'Module: ' + @ErrorProcedure          
							
								RAISERROR(@MessageString, @ErrorSeverity, 1)
      END CATCH          
					END
		END
ELSE
		BEGIN
				DECLARE @NewPumpId INT = NULL
    SELECT @DistinctChemicalCount    =   COUNT(DISTINCT D.ProductId) --distinct count          
    FROM (          
      SELECT @ProductId     AS   ProductId     --being assigned          
						UNION
      SELECT DISTINCT ProductId  AS   ProductId     --already assigned          
      FROM [TCD].ControllerEquipmentSetup          
      WHERE ControllerId    =   @ControllerId          
       AND ProductId     <>   @ProductId          
      ) D          

    IF ( @DistinctChemicalCount > @MaximumChemicalCount )          
				BEGIN
      SET @ErrorId   = 51000          
      SET @ErrorMessage  = N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Maximum chemical count exceeded. Cannot assign new chemical'          
      --GOTO ErrorHandler          
      RAISERROR (@ErrorMessage, 16, 1)          
      SET @ReturnValue = -1          
      RETURN (@ReturnValue)          
				END

				--IF(@RoleId =8)
				--BEGIN
    --  IF(@LfsChemicalNameTag IS NOT NULL AND @LfsChemicalNameTag <> '')          
    --   BEGIN          
    --   EXEC @Result1 = TCD.CheckDuplicateTag @LfsChemicalNameTag, @ControllerID          
    --   IF(@Result1 = 0)          
    --   BEGIN          
    --   SET @ErrorMessage = '801,'          
    --   END          
    --  END          
    --  IF(@KfactorTag IS NOT NULL AND @KfactorTag <> '')          
    --   BEGIN          
    --    EXEC @Result2 = TCD.CheckDuplicateTag @KfactorTag,@ControllerID          
    --    IF(@Result2 = 0)          
    --    BEGIN          
    --    SET @ErrorMessage = @ErrorMessage+'802,'          
    --    END       
    --   END          
    --  IF(@CalibrationTag IS NOT NULL AND @CalibrationTag <> '')          
    --   BEGIN          
    --    EXEC @Result3 = TCD.CheckDuplicateTag @CalibrationTag,@ControllerID          
    --    IF(@Result3 = 0)          
    --    BEGIN          
    --    SET @ErrorMessage = @ErrorMessage+'803,'          
    --    END          
    --   END          
				--END

				--SET @ErrorMessage = @ErrorMessage + CONVERT(VARCHAR(100),'')
				--IF(@ErrorMessage <> '')
    -- RAISERROR(@ErrorMessage, 16, 1)          
				ELSE
					BEGIN
      BEGIN TRY          
        BEGIN TRAN          

        INSERT [TCD].ControllerEquipmentSetup  (          
             EcoLabAccountNumber          
        ,    ControllerId          
        ,    ControllerEquipmentId          
        ,    ControllerEquipmentTypeId          
        ,    ProductId          
        ,    IsActive          
        ,    LfsChemicalName          
        ,    KFactor          
        ,    PumpCalibration          
        ,    TunnelHold          
        ,    FlowDetectorType     
        ,     FlowSwitchNumber       
        ,    FlowSwitchAlarm          
        ,    FlowMeterAlarm          
        ,    FlowMeterType          
        ,    FlowAlarmDelay          
        ,    FlowMeterPumpDelay          
        ,    FlowMeterAlarmDelay          
        , ControllerEquipmentTypeModelId           
        , ConventionalWasherGroupConnection           
        , AxillaryPumpCalibration             
        , FlowmeterSwitchActivated             
        , FlushWhileDosing               
        , WeightControlledDosage              
        , EquipmentDoseAlone                 
        , LowLevelAlarm                    
        , LeakageAlarm                    
        , FlushTime                   
        , PumpingTime                  
        , PreFlushTime                  
        , NightFlushPauseTime                 
        , NightFlushTime                  
        , AcceptedDeviation                 
        , LineNumber                 
        , MaximumDosingTime              
        , FlowSwitchTimeOut   
       , ValveOutputAsTom         
        , LastModifiedByUserId            
       --** Adding a part of integration with Synch./Central -->          
        , LastModifiedTime          
        , FlushValveNumber              
       , CalibrationConductSS_Tank           
       , BackFlowControl                
       , FactorFM_B_FM                    
       , AcceptedDeviationRingLine           
       , UsePumpOfGroup1ForTunnel             
       , pHSensorEnabled      
    , FlushTimeForFlushValve    
       , Concentration       
       , Deadband      
        , MinimumFlowRate 
  , ProductDensity 
  , MaximumConcentration
								)
       OUTPUT inserted.ControllerEquipmentSetupId   AS   ControllerEquipmentSetupId          
        , inserted.LastModifiedTime     AS   LastModifiedTime          
       INTO @OutputList (          
									ControllerEquipmentSetupId
        , LastModifiedTimestamp          
								)
       --** <--          
       SELECT @EcoLabAccountNumber    AS   EcoLabAccountNUmber          
        , @ControllerId      AS   ControllerEquipmentId          
        , @ControllerEquipmentId    AS   ControllerEquipmentId          
        , @ControllerEquipmentTypeId   AS   ControllerEquipmentTypeId          
        , @ProductId      AS   ProductId          
        , @IsActive       AS   IsActive          

        , LfsChemicalName     =   CASE @IsActive WHEN 'TRUE' THEN @LfsChemicalName   ELSE NULL END          
        , KFactor       =   CASE @IsActive WHEN 'TRUE' THEN @KFactor     ELSE NULL END          
        , PumpCalibration     =   CASE @IsActive WHEN 'TRUE' THEN @PumpCalibration   ELSE NULL END          
				
        , TunnelHold      =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @TunnelHold   ELSE NULL END ELSE NULL END          
        , FlowDetectorType     =   CASE @IsActive WHEN 'TRUE' THEN CASE WHEN @ControllerTypeId IN (2,6,7, 12,10, 14,8, 13,9,11) THEN @FlowDetectorType  ELSE NULL END ELSE NULL END          
        , FlowSwitchNumber        =    @FlowSwitchNumber  
        , FlowSwitchAlarm     =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowSwitchAlarm  ELSE NULL END ELSE NULL END          
      , FlowMeterAlarm      =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterAlarm  ELSE NULL END ELSE NULL END          
        , FlowMeterType      =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterType   ELSE NULL END ELSE NULL END          
        , FlowAlarmDelay      =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowAlarmDelay  ELSE NULL END ELSE NULL END          
        , FlowMeterPumpDelay     =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterPumpDelay  ELSE NULL END ELSE NULL END          
        , FlowMeterAlarmDelay     =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterAlarmDelay ELSE NULL END ELSE NULL END          
        , ControllerEquipmentTypeModelId  =   CASE @IsActive WHEN 'TRUE' THEN @ControllerEquipmentTypeModelId      ELSE NULL END          
        , ConventionalWasherGroupConnection      =   CASE @IsActive WHEN 'TRUE' THEN @ConventionalWasherGroupConnection  ELSE 0 END          
        , AxillaryPumpCalibration        =   CASE @IsActive WHEN 'TRUE' THEN @AxillaryPumpCalibration    ELSE 0 END          
        , FlowmeterSwitchActivated        =   CASE @IsActive WHEN 'TRUE' THEN @FlowmeterSwitchActivated   ELSE 0 END          
        , FlushWhileDosing          =   CASE @IsActive WHEN 'TRUE' THEN @FlushWhileDosing      ELSE 0 END          
        , WeightControlledDosage         =   CASE @IsActive WHEN 'TRUE' THEN @WeightControlledDosage     ELSE 0 END          
        , EquipmentDoseAlone            =   CASE @IsActive WHEN 'TRUE' THEN @EquipmentDoseAlone        ELSE 0 END          
        , LowLevelAlarm               =   CASE @IsActive WHEN 'TRUE' THEN @LowLevelAlarm           ELSE 0 END          
        , LeakageAlarm               =   CASE @IsActive WHEN 'TRUE' THEN @LeakageAlarm           ELSE 0 END          
        , FlushTime              =   CASE @IsActive WHEN 'TRUE' THEN @FlushTime         ELSE NULL END          
        , PumpingTime             =   CASE @IsActive WHEN 'TRUE' THEN @PumpingTime         ELSE NULL END          
        , PreFlushTime             =   CASE @IsActive WHEN 'TRUE' THEN @PreFlushTime         ELSE NULL END          
        , NightFlushPauseTime            =   CASE @IsActive WHEN 'TRUE' THEN @NightFlushPauseTime       ELSE NULL END          
        , NightFlushTime             =   CASE @IsActive WHEN 'TRUE' THEN @NightFlushTime  ELSE NULL END          
        , AcceptedDeviation            =   CASE @IsActive WHEN 'TRUE' THEN @AcceptedDeviation        ELSE NULL END          
        , LineNumber           =   CASE @IsActive WHEN 'TRUE' THEN @LineNumber           ELSE NULL END          
        , MaximumDosingTime         =   CASE @IsActive WHEN 'TRUE' THEN @MaximumDosingTime     ELSE NULL END          
        , FlowSwitchTimeOut     =   CASE @IsActive WHEN 'TRUE' THEN @FlowSwitchTimeOut     ELSE NULL END         
       , ValveOutputAsTom               =   CASE @IsActive WHEN 'TRUE' THEN @ValveOutputAsTom           ELSE 0 END     

        --, CASE @IsActive WHEN 'TRUE' THEN @FlowMeterSwitchFlag ELSE NULL END AS FlowMeterSwitchFlag           
        --, CASE @IsActive WHEN 'TRUE' THEN @FlowMeterCalibration ELSE NULL END AS FlowMeterCalibration          
        --, CASE @IsActive WHEN 'TRUE' THEN @MaximumDosingTime ELSE NULL END AS MaximumDosingTime          
        --, CASE @IsActive WHEN 'TRUE' THEN @FlowSwitchTimeOut ELSE NULL END AS FlowSwitchTimeOut          
        , @UserId        AS   LastModifiedByUserId          
								--Synch./Central integration additions
        , @CurrentUTCTime      AS   LastModifiedTime          
       , FlushValveNumber  =   CASE @IsActive WHEN 'TRUE' THEN @FlushValveNumber     ELSE NULL END           
       , CalibrationConductSS_Tank =   CASE @IsActive WHEN 'TRUE' THEN @CalibrationConductSS_Tank     ELSE NULL END         
       , BackFlowControl  =   CASE @IsActive WHEN 'TRUE' THEN @BackFlowControl     ELSE 'False' END            
       , FactorFM_B_FM   =   CASE @IsActive WHEN 'TRUE' THEN @FactorFM_B_FM     ELSE NULL END                
       , AcceptedDeviationRingLine =   CASE @IsActive WHEN 'TRUE' THEN @AcceptedDeviationRingLine     ELSE NULL END           
       , UsePumpOfGroup1ForTunnel =   CASE @IsActive WHEN 'TRUE' THEN @UsePumpOfGroup1ForTunnel     ELSE NULL END             
       , pHSensorEnabled    =   CASE @IsActive WHEN 'TRUE' THEN @pHSensorEnabled     ELSE NULL END    
    , FlushTimeForFlushValve = @FlushTimeForFlushValve     
       , Concentration =   CASE @IsActive WHEN 'TRUE' THEN @Concentration     ELSE NULL END             
       , Deadband    =   CASE @IsActive WHEN 'TRUE' THEN @Deadband     ELSE NULL END       
        , MinimumFlowRate = CASE @IsActive WHEN 'TRUE' THEN @MinimumFlowRate     ELSE NULL END  
       , ProductDensity = CASE @IsActive WHEN 'TRUE' THEN @ProductDensity     ELSE NULL END
       , MaximumConcentration = CASE @IsActive WHEN 'TRUE' THEN @MaximumConcentration     ELSE NULL END 
								SET @NewPumpId = SCOPE_IDENTITY() 
					
								---Tags---
								--IF(@RoleId =8)
        -- BEGIN          
        --   IF(@IsActive = 'TRUE')          
        --    BEGIN          
        --      IF(@LfsChemicalNameTag IS NOT NULL AND @LfsChemicalNameTag <> '')           
        --        INSERT INTO TCD.ModuleTags (EcolabAccountNumber ,TagType,TagAddress,ModuleTypeId,ModuleId,DeadBand,Active)          
        --        VALUES(@EcoLabAccountNumber ,@TagTypeLfs,@LfsChemicalNameTag,@ModuleType,@NewPumpId,@DefaultFrequency,1)          

        --      IF(@KfactorTag IS NOT NULL AND @KfactorTag <> '')           
        --        INSERT INTO TCD.ModuleTags (EcolabAccountNumber ,TagType,TagAddress,ModuleTypeId,ModuleId,DeadBand,Active)          
        --        VALUES(@EcoLabAccountNumber ,@TagTypeKfactor,@KfactorTag,@ModuleType,@NewPumpId,@DefaultFrequency,1)          

        --      IF(@CalibrationTag IS NOT NULL AND @CalibrationTag  <> '')           
        --        INSERT INTO TCD.ModuleTags (EcolabAccountNumber ,TagType,TagAddress,ModuleTypeId,ModuleId,DeadBand,Active)          
        --        VALUES(@EcoLabAccountNumber ,@TagTypeCalibration,@CalibrationTag,@ModuleType,@NewPumpId,@DefaultFrequency,1)          
        --    END          
        -- END          
								-----Tags---
        SET @ErrorId = @@ERROR          
        IF (@ErrorId <> 0)          
									BEGIN
          IF @@TRANCOUNT >0          
											ROLLBACK

          SET  @ErrorMessage  = N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred associating Equipment to Controller'          
          --GOTO Errorhandler          
          RAISERROR (@ErrorMessage, 16, 1)          
          SET @ReturnValue = -1      
         RETURN (@ReturnValue)          
							END

        SELECT TOP 1          
          @OutputControllerEquipmentSetupId = O.ControllerEquipmentSetupId          
        FROM @OutputList   O          

        IF @@TRANCOUNT > 0          
									COMMIT
      END TRY          
      BEGIN CATCH          
        IF @@TRANCOUNT > 0          
									ROLLBACK
							
        SELECT /*@ErrorNumber    =  ERROR_NUMBER()          
         , */@ErrorMessage    =  ERROR_MESSAGE()          
         , @ErrorProcedure    =  ERROR_PROCEDURE()          
         , @ErrorSeverity    =  ERROR_SEVERITY()          
							
        SET  @OutputControllerEquipmentSetupId          
                 =  NULL          
        SET  @ReturnValue    =  -1          
        SET  @MessageString    =  N'An error occured while Updating Pump/Valve details. The error is: '          
                 +  @ErrorMessage + ' '          
                 +  'Module: ' + @ErrorProcedure          
							
								RAISERROR(@MessageString, @ErrorSeverity, 1)
      END CATCH          
     END          
  END          
     
  -------------------------------------------
  IF((SELECT CONTROLLERMODELID FROM TCD.ConduitController WHERE ControllerId=@ControllerId)='11')
  BEGIN
	IF(@ControllerEquipmentTypeId=2 AND @ControllerEquipmentId IN(13,14,27,28))
	BEGIN

		UPDATE TCD.ControllerEquipmentSetup  SET CalibrationConductSS_Tank=@CalibrationConductSS_Tank
		WHERE EcoLabAccountNumber=@EcoLabAccountNumber AND	ControllerId=@ControllerId AND ControllerEquipmentTypeId=@ControllerEquipmentTypeId
		AND ControllerEquipmentId=CASE WHEN @ControllerEquipmentId=13 THEN 27 
								   WHEN @ControllerEquipmentId=27 THEN 13  	
								   WHEN @ControllerEquipmentId=14 THEN 28
								   WHEN @ControllerEquipmentId=28 THEN 14 END 
					END
		END
  -------------------------------------------

  IF ( @ErrorId = 0 )          
	BEGIN
  --GOTO ExitModule          
  RETURN (@ReturnValue)          
	END


		--ErrorHandler:
--RAISERROR (@ErrorMessage, 16, 1)          
--SET @ReturnValue = -1          




--ExitModule:

SET NOCOUNT OFF          
RETURN (@ReturnValue)          


END
GO
--drop proce
IF EXISTS(SELECT
					*
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'[TCD].[SaveTunnelCompartment]')
					AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.SaveTunnelCompartment
	END
GO
IF EXISTS (SELECT 
						* 
					FROM sys.types 
					where is_user_defined = 1 and name like 'udttControllerEquipment%')
BEGIN
    DROP TYPE	[TCD].[udttControllerEquipment]
END
GO
IF EXISTS (SELECT 
						* 
					FROM sys.types 
					where is_user_defined = 1 and name like 'ControllerEquipment%')
BEGIN
    DROP TYPE	[TCD].[ControllerEquipment]
END
GO
CREATE	TYPE	[TCD].[ControllerEquipment]
AS	TABLE	(
				ControllerEquipmentSetupId			SMALLINT		NOT	NULL
			,	DeleteFlag							BIT				NOT	NULL
			)

GO
IF EXISTS(SELECT
					*
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'[TCD].[SaveWasherProductDeviationData]')
					AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.SaveWasherProductDeviationData
	END
GO

IF EXISTS (SELECT 
						* 
					FROM sys.types 
					where is_user_defined = 1 and name like 'udttProductDeviationData%')
BEGIN
	DROP TYPE	[TCD].[udttProductDeviationData]
END
GO
IF EXISTS (SELECT 
					* 
					FROM sys.types 
					where is_user_defined = 1 and name like 'ProductDeviationData%') 
						
BEGIN
		DROP TYPE [TCD].[ProductDeviationData]
END
CREATE TYPE [TCD].[ProductDeviationData] AS TABLE(
	[WasherProductDeviationId] [int] NULL,
	[WasherId] [int] NOT NULL,
	[ControllerEquipmentID] [int] NOT NULL,
	[ControllerID] [int] NOT NULL,
	[Deviation] [int] NOT NULL
)
GO

IF EXISTS(SELECT
					*
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'[TCD].[CopyConventionalFormula]')
					AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.CopyConventionalFormula
	END
GO
IF EXISTS (SELECT 
						* 
					FROM sys.types 
					where is_user_defined = 1 and name like 'udttSubstituteMissingChemical%')
BEGIN
	DROP TYPE	[TCD].[udttSubstituteMissingChemical]
END
GO
IF EXISTS (SELECT 
						* 
					FROM sys.types 
					where is_user_defined = 1 and name like'SubstituteMissingChemical%') 
					
BEGIN
    DROP TYPE [TCD].[SubstituteMissingChemical]
END 
CREATE TYPE [TCD].[SubstituteMissingChemical] AS TABLE
(
	[WasherGroupId]				[int]	NOT NULL,
	[OldProductId]				[int]	NOT NULL,
	[NewProductId]				[int]	NOT NULL,
	[ScalarOption]				[int]	NOT NULL,
	[ScalarAmountPercent]		[int]	NOT NULL	
)

GO

IF EXISTS(SELECT
					*
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'[TCD].[SaveTunnelCompartmentEquipmentValveMapping]')
					AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.SaveTunnelCompartmentEquipmentValveMapping
	END
GO

IF EXISTS(SELECT
					*
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'[TCD].[SaveTunnelCompartmentEquipmentValveMapping_DECentral]')
					AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.SaveTunnelCompartmentEquipmentValveMapping_DECentral
	END
GO

IF EXISTS(SELECT
					*
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'[TCD].[SaveTunnelCompartmentEquipmentValveMapping_XL]')
					AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.SaveTunnelCompartmentEquipmentValveMapping_XL
	END
GO

IF EXISTS (SELECT 
						* 
					FROM sys.types 
					where is_user_defined = 1 and name like 'udttTunnelCompartmentEquipmentValveMapping%')
BEGIN
	DROP TYPE	[TCD].[udttTunnelCompartmentEquipmentValveMapping]
END
GO

IF EXISTS (SELECT 
						* 
					FROM sys.TYPES 
					where is_user_defined = 1 and name like 'TunnelCompartmentEquipmentValveMapping%') 
						
BEGIN
     DROP TYPE [TCD].[TunnelCompartmentEquipmentValveMapping]
END
CREATE TYPE [TCD].[TunnelCompartmentEquipmentValveMapping] AS TABLE(
	[ControllerEquipmentId] [tinyint] NOT NULL,
	[TunnelNumber] [int] NOT NULL,
	[CompartmentNumber] [tinyint] NOT NULL,
	[DosingPointNumber] [tinyint] NOT NULL,
	[DirectDosingFlag] [bit] NOT NULL,
	[ValveNumber] [tinyint] NOT NULL,
  [WasherNumber] int NOT NULL
)

GO

IF EXISTS(SELECT
					*
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'[TCD].[AuditUpdateWrapper]')
					AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.AuditUpdateWrapper
	END
GO
IF EXISTS (SELECT 
						* 
					FROM sys.types 
					where is_user_defined = 1 and name like 'udttUpdateSet%')
BEGIN
	DROP TYPE	[TCD].[udttUpdateSet]
END
GO
IF EXISTS (SELECT 
						* 
					FROM sys.TYPES 
					where is_user_defined = 1 and name like 'UpdateSet%') 
						
BEGIN
    DROP TYPE [TCD].[UpdateSet]
END 
CREATE TYPE [TCD].[UpdateSet] AS TABLE (
		[ReferenceID] INT NULL,
		[ColumnName]  [sysname] NOT NULL,
		[OldValue] NVARCHAR (1000) NULL,
		[NewValue] NVARCHAR (1000) NULL);

GO

IF EXISTS(SELECT
					*
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'[TCD].[SaveWasherFlushTime]')
					AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.SaveWasherFlushTime
	END
GO
IF EXISTS (SELECT 
						* 
					FROM sys.types 
					where is_user_defined = 1 and name like 'udttWasherFlushTime%')
BEGIN
	DROP TYPE	[TCD].[udttWasherFlushTime]
END
GO
IF EXISTS (SELECT 
						* 
					FROM sys.TYPES 
					where is_user_defined = 1 and name like 'WasherFlushTime%') 
						
BEGIN
    DROP TYPE [TCD].[WasherFlushTime]
END
CREATE TYPE [TCD].[WasherFlushTime] AS TABLE(
	[WasherId] [int] NOT NULL,
	[LineNumber] [int] NOT NULL,
	[WasherFlushTypeId] [tinyint] NOT NULL,
	[FlushTime] [int] NOT NULL
)

GO

IF EXISTS(SELECT
					*
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'[TCD].[SaveWasherTimeOutMachine]')
					AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.SaveWasherTimeOutMachine
	END
GO
IF EXISTS (SELECT 
						* 
					FROM sys.types 
					where is_user_defined = 1 and name like 'udttWasherTimeOutMachine%')
BEGIN
	DROP TYPE	[TCD].[udttWasherTimeOutMachine]
END
GO
IF  EXISTS (SELECT 
						* 
					FROM sys.TYPES 
					where is_user_defined = 1 and name like 'WasherTimeOutMachine%') 
						
BEGIN
    DROP TYPE [TCD].[WasherTimeOutMachine]
END
CREATE TYPE [TCD].[WasherTimeOutMachine] AS TABLE(
	[WasherId] [int] NOT NULL,
	[SignalNumber] [tinyint] NOT NULL,
	[EquipmentNumber] [int] NOT NULL,
	[DosingPointNumber] [int] NOT NULL
)

GO

IF EXISTS(SELECT
					*
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'[TCD].[AuditUpdateWrapper]')
					AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.AuditUpdateWrapper
	END
GO
--sp_who2	'active'
/*
CREATE	TYPE	udttUpdateSet
AS	TABLE	(	ReferenceID					INT
			,	ColumnName					SYSNAME
			,	OldValue					NVARCHAR(1000)
			,	NewValue					NVARCHAR(1000)
			)
GO

DROP	TYPE	udttUpdateSet

*/

CREATE	PROCEDURE	[TCD].AuditUpdateWrapper	(
					@TableName				SYSNAME
				,	@UpdateSetList			[TCD].UpdateSet	READONLY
				,	@UserId					INT
				)
AS
SET NOCOUNT ON
BEGIN

--Local variable declarations:
DECLARE			@ColumnName					SYSNAME
			,	@ReferenceId				INT
			,	@OldValue					NVARCHAR(1000)
			,	@NewValue					NVARCHAR(1000)
			,	@Id							INT

CREATE	TABLE	#UpdateList				(
				Id							INT					IDENTITY(1, 1)
			,	ReferenceID					INT
			,	ColumnName					SYSNAME
			,	OldValue					NVARCHAR(1000)
			,	NewValue					NVARCHAR(1000)
			)


INSERT	#UpdateList	(
		ReferenceID		,ColumnName		,OldValue	,NewValue	)
SELECT	L.ReferenceID	,L.ColumnName	,L.OldValue	,L.NewValue
FROM	@UpdateSetList	L
ORDER BY
		L.ReferenceID,	L.ColumnName

WHILE	EXISTS	(SELECT	1	FROM	#UpdateList)
BEGIN
	   SELECT	@Id							=				L.Id
			,	@ReferenceId				=				L.ReferenceID
			,	@ColumnName					=				L.ColumnName
			,	@OldValue					=				L.OldValue
			,	@NewValue					=				L.NewValue
	   FROM		#UpdateList					L
	   ORDER BY
				L.ReferenceID, L.ColumnName

	   --Call the existing Update-audit SP
	   EXEC		[TCD].[AuditingChangedDetails]
				@table_Name					=				@TableName
			,	@ReferenceID				=				@ReferenceId
			,	@Column_name				=				@ColumnName
			,	@OldValue					=				@OldValue
			,	@Newvalue					=				@NewValue
			,	@UserId						=				@UserId

		DELETE	#UpdateList
		WHERE	Id							=				@Id
END

RETURN	0

END
GO
IF EXISTS(SELECT
					*
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'[TCD].[CopyConventionalFormula]')
					AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.CopyConventionalFormula
	END
GO
CREATE PROCEDURE [TCD].[CopyConventionalFormula]
		 @SubstituteMissingChemical				 TCD.SubstituteMissingChemical	READONLY	
    ,    @ToWasherGroupId                            INT								=            NULL
    ,    @FromWasherGroupId                          INT								=            NULL
    ,    @ProgramNumber                              SMALLINT							=            NULL 
    ,    @WasherProgramSetupId                       INT								=            NULL
    ,    @ProgramId                                  INT								=            NULL
    ,    @EcoLabAccountNumber                        NVARCHAR(1000)						=            NULL
    ,    @UserId                                     INT								=            NULL
    ,    @ProgramSetupId                             INT								=            NULL   OUTPUT 
	

AS
BEGIN
    SET NOCOUNT ON;

    DECLARE      @TotalNumberOfPrograms      SMALLINT        =       NULL
    ,            @ReturnValue                INT             =       0
    ,            @ErrorId                    INT             =       0
    ,            @ErrorMessage               NVARCHAR(4000)  =       N''
    ,            @MaxNumberOfPrograms        SMALLINT        =       127

    DECLARE
                @OutputList                                AS    TABLE        (
                OutputProgramSetupId                       INT
        )

    --ProgramNumber check
    IF    (    @ProgramNumber                >            @MaxNumberOfPrograms)
    BEGIN
            SET        @ErrorId                        =            51002
            SET        @ErrorMessage                    =            N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Invalid ProgramNumber... Aborting.'
            --GOTO    ErrorHandler
            RAISERROR    (@ErrorMessage, 16, 1)
            SET    @ReturnValue    =    -1
            RETURN    (@ReturnValue)
    END

        IF    EXISTS    (        SELECT    1
                                FROM    [TCD].WasherProgramSetup            WPS
                                WHERE    WPS.EcolabAccountNumber        =            @EcoLabAccountNumber
                                    AND    WPS.WasherGroupId            =            @ToWasherGroupId
                                    AND    WPS.ProgramNumber            =            @ProgramNumber
                                    AND    WPS.Is_Deleted                =            'FALSE'
                        )
                    BEGIN
                            SET        @ErrorId                        =            51001
                            SET        @ErrorMessage                    =            N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Specified ProgramNumber for the WasherGroup already exists for the plant.'
                            --GOTO    ErrorHandler
                            RAISERROR    (@ErrorMessage, 16, 1)
                            SET    @ReturnValue    =    -1
                            RETURN    (@ReturnValue)
                    END

        SELECT @TotalNumberOfPrograms        =            COUNT(WPS.ProgramNumber)
        FROM   [TCD].WasherProgramSetup      AS           WPS
        WHERE  WPS.EcolabAccountNumber       =            @EcoLabAccountNumber
        AND    WPS.WasherGroupId             =            @ToWasherGroupId
        AND    WPS.Is_Deleted                =            'FALSE'
    
        IF (@TotalNumberOfPrograms           =            @MaxNumberOfPrograms)
            BEGIN
                    SET        @ErrorId        =            51000
                    SET        @ErrorMessage    =            N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Maximum Number of programs that can be associated to a WasherGroup already defined... Aborting.'
                    RAISERROR  (@ErrorMessage, 16, 1)
                    SET            @ReturnValue    =    -1
                    RETURN        (@ReturnValue)
            END

        INSERT INTO TCD.WasherProgramSetup
        (
            EcolabAccountNumber,
            WasherGroupId,
            ProgramNumber,
            ProgramId,
            NominalLoad,
            LoadsPerMonth,
            TotalRunTime,
            ExtraTime,
            TotalSteps,
            CoolDownStep,
            FinalExtractingTime,
            Category,
            CustomProgramName,
            PlantProgramNumber,
            NumberOfDrains,
            DrainTime,
            Rewash,
            CleanWt,
            CleanAw,
            CustomerId,
            Is_Deleted,
            LastModifiedByUserId,
            MyServiceCustFrmulaMchGrpGUID,
            LastModifiedTime
        )
        OUTPUT
            inserted.WasherProgramSetupId    AS    Id
        INTO
            @OutputList(
                    OutputProgramSetupId
                       )
        SELECT    wps.EcolabAccountNumber
        ,        @ToWasherGroupId
        ,        @ProgramNumber
        ,        @ProgramId
        ,        wps.NominalLoad
        ,        wps.LoadsPerMonth
        ,        wps.TotalRunTime
        ,        wps.ExtraTime
        ,        wps.TotalSteps
        ,        wps.CoolDownStep
        ,        wps.FinalExtractingTime
        ,        wps.Category
        ,        wps.CustomProgramName
        ,        wps.PlantProgramNumber
        ,        wps.NumberOfDrains
        ,        wps.DrainTime
        ,        wps.Rewash
        ,        wps.CleanWt
        ,        wps.CleanAw
        ,        wps.CustomerId
        ,        'False'
        ,        @UserId
        ,        NEWID()
        ,        GETUTCDATE()
        FROM TCD.WasherProgramSetup wps
        WHERE wps.EcolabAccountNumber    =    @EcoLabAccountNumber
        AND      wps.WasherGroupId            =    @FromWasherGroupId
        AND      wps.WasherProgramSetupId    =    @WasherProgramSetupId

        --check for any error
            SET    @ErrorId    =    @@ERROR
    
            IF    (@ErrorId    <>    0)
                BEGIN
                        SET    @ReturnValue    =    -1
                        RETURN    (@ReturnValue)
                END

        SELECT  TOP 1 @ProgramSetupId    =   O.OutputProgramSetupId FROM @OutputList O
        
        INSERT INTO TCD.WasherDosingSetup
        (
            --WasherDosingSetupId - this column value is auto-generated
            EcoLabAccountNumber,
            WasherProgramSetupId,
            GroupId,
            ProgramNumber,
            StepNumber,
            StepTypeId,
            ProductId,
            StepRunTime,
            Quantity,
            [Delay],
            ResourceDetailId,
            MENumber,
            Temperature,
            WaterType,
            WaterLevel,
            DrainDestinationId,
            pHLevel,
            Note,
            Is_Deleted,
            LastModifiedByUserId,
            StandardWeight,
            MyServiceCustFrmulaStpGUID,
            StandardWaterUsage
        )
        SELECT    wds.EcoLabAccountNumber
        ,        @ProgramSetupId
        ,        @ToWasherGroupId
        ,        wds.ProgramNumber
        ,        wds.StepNumber
        ,        wds.StepTypeId
        ,        wds.ProductId
        ,        wds.StepRunTime
        ,        wds.Quantity
        ,        wds.[Delay]
        ,        wds.ResourceDetailId
        ,        wds.MENumber
        ,        wds.Temperature
        ,        wds.WaterType
        ,        wds.WaterLevel
        ,        wds.DrainDestinationId
        ,        wds.pHLevel
        ,        wds.Note
        ,        wds.Is_Deleted
        ,        @UserId
        ,        wds.StandardWeight
        ,        NEWID()
        ,        wds.StandardWaterUsage
        FROM TCD.WasherDosingSetup wds
        WHERE wds.WasherProgramSetupId = @WasherProgramSetupId
        AND      wds.EcoLabAccountNumber  = @EcoLabAccountNumber
        AND      wds.Is_Deleted           = 'False'

        --check for any error
            SET    @ErrorId    =    @@ERROR
    
            IF    (@ErrorId    <>    0)
                BEGIN
                        SET    @ReturnValue    =    -1
                        RETURN    (@ReturnValue)
                END

		SELECT    wdpm.EcoLabAccountNumber
        ,        wds2.WasherDosingSetupId
        ,        wdpm.InjectionNumber
        ,        wdpm.ProductId
        ,        wdpm.Quantity
        ,        wdpm.IsDeleted
		INTO #tempWasherDosingProductMapping
        FROM TCD.WasherDosingProductMapping wdpm
        INNER JOIN TCD.WasherDosingSetup wds
        ON wds.EcoLabAccountNumber = wdpm.EcoLabAccountNumber
        AND wds.WasherDosingSetupId = wdpm.WasherDosingSetupId
        LEFT JOIN TCD.WasherDosingSetup wds2 
        ON wds.EcoLabAccountNumber = wds2.EcoLabAccountNumber
        AND wds.StepNumber = wds2.StepNumber
        AND wds2.WasherProgramSetupId = @ProgramSetupId
        WHERE wds.WasherProgramSetupId = @WasherProgramSetupId
        AND wds.Is_Deleted = 'False'
        ORDER BY wds.StepNumber 

		UPDATE twdpm
		SET twdpm.ProductId = CASE WHEN udd.NewProductId > 0 THEN udd.NewProductId ELSE twdpm.ProductId END
		,	twdpm.IsDeleted = CASE WHEN udd.NewProductId > 0 THEN 0 ELSE 1 END
		,   twdpm.Quantity  = CASE WHEN udd.ScalarOption = 1 
                              THEN CASE WHEN (twdpm.Quantity - ((twdpm.Quantity * udd.ScalarAmountPercent)/100)) < 0 
									THEN 0
									ELSE  (twdpm.Quantity - ((twdpm.Quantity * udd.ScalarAmountPercent)/100))
									END
								WHEN udd.ScalarOption = 2 
								THEN (twdpm.Quantity + ((twdpm.Quantity * udd.ScalarAmountPercent)/100)) 
								ELSE twdpm.Quantity 
								END
		FROM #tempWasherDosingProductMapping twdpm
		INNER JOIN @SubstituteMissingChemical udd
		ON twdpm.ProductId = udd.OldProductId
		
        INSERT INTO TCD.WasherDosingProductMapping
        (
            --WasherDosingProductMappingId - this column value is auto-generated
            EcoLabAccountNumber,
            WasherDosingSetupId,
            InjectionNumber,
            ProductId,
            Quantity,
            LastModifiedByUserId,
            MyServiceFrmulaStpDsgDvcGuid,
            LastModifiedTime,
            IsDeleted
        )
        SELECT   td.EcoLabAccountNumber
        ,        td.WasherDosingSetupId
        ,        td.InjectionNumber
        ,        td.ProductId
        ,        td.Quantity
        ,        @UserId
        ,        NEWID()
        ,        GETUTCDATE()
        ,        td.IsDeleted
        FROM #tempWasherDosingProductMapping td
        WHERE td.IsDeleted = 'False'
			
		DROP TABLE #tempWasherDosingProductMapping

		-- For Reording the washer injection based on the update or insert of the productdosing for the washer.
		EXEC [TCD].[WasherInjectionOrdering] @ProgramSetupId,@EcolabAccountNumber

        --check for any error
            SET    @ErrorId    =    @@ERROR
    
            IF    (@ErrorId    <>    0)
                BEGIN
                        SET    @ReturnValue    =    -1
                        RETURN    (@ReturnValue)
                END

    IF    (    @ErrorId    =    0    )
    BEGIN
        --GOTO    ExitModule
        RETURN    (@ReturnValue)
    END

    SET    NOCOUNT    OFF
    RETURN    (@ReturnValue)
END
GO

IF EXISTS(SELECT
					*
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'[TCD].[SaveTunnelCompartment]')
					AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.SaveTunnelCompartment
	END
GO

/*	
Purpose					:	To save details of a tunnel compartment from the Tunnel setup screen --> compartments tab...

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version

*/

CREATE	PROCEDURE	[TCD].[SaveTunnelCompartment]
					@EcoLabAccountNumber					NVARCHAR(1000)
				,	@TunnelId								INT
				,	@CompartmentNumber						TINYINT

				,	@WashStepId								INT					=			NULL
				,	@WaterinletDrainId						TINYINT
				,	@WaterFlowId							SMALLINT
				,	@WaterLevel								NUMERIC(8, 2)
				,	@TemperatureControlByPMR				BIT
				,	@UsePressExtractWater					BIT
				,	@SplitCompartment						BIT
				,	@RecycledWaterInlet						BIT
				,	@Steam									BIT
				,	@IterationPoint							BIT

				,	@EquipmentAssociation					[TCD].ControllerEquipment			READONLY

				,	@UserId									INT
				--	Adding these 3 param as part of re-factoring for integration with Synch/Configurator
				,	@OutputTunnelCompartmentId				INT			=			NULL	OUTPUT
				,	@LastModifiedTimestampAtCentral			DATETIME	=			NULL		--Nullable for local call; Synch/Central call will have to pass this -
																								--else, it will be treated as a local call
				,	@OutputLastModifiedTimestampAtLocal		DATETIME	=			NULL	OUTPUT

AS
BEGIN

SET	NOCOUNT	ON


DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''

	,	@ControllerId					INT				=			NULL
	,	@NumberOfComp					TINYINT			=			NULL
	,	@TunnelCompartmentId			SMALLINT		=			NULL

	,	@CurrentUTCTime					DATETIME				=			GETUTCDATE()
	,	@MyServiceCmpmtDsgDvcguid		UNIQUEIDENTIFIER	=			NEWID()
--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
SET		@OutputLastModifiedTimestampAtLocal						=			@CurrentUTCTime
SET		@OutputTunnelCompartmentId								=			ISNULL(@OutputTunnelCompartmentId, NULL)			--SQLEnlight

DECLARE
		@OutputList						AS	TABLE		(
		TunnelCompartmentId					INT
	,	LastModifiedTimestamp				DATETIME
	)

--Get the ControllerId for the Tunnel...
SELECT	@ControllerId					=			ISNULL(MS.ControllerId, -1)
	,	@NumberOfComp					=			ISNULL(MS.NumberOfComp, -1)
FROM	[TCD].MachineSetup					MS
JOIN	[TCD].ConduitController				CC												--join on valid controller
	ON	MS.ControllerId					=			CC.ControllerId
	AND	MS.EcoalabAccountNumber			=			CC.EcoalabAccountNumber
WHERE	MS.EcoalabAccountNumber			=			@EcoLabAccountNumber
	AND	MS.WasherId						=			@TunnelId
	AND	MS.IsTunnel						=			'TRUE'
	AND	MS.IsDeleted					=			'FALSE'
	AND	CC.IsDeleted					=			'FALSE'

--if we didn't get a valid Controller, error-out
IF	(@ControllerId	=	-1)
	BEGIN
				SET		@ErrorId						=			51020
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Could not determine the Controller for the specified tunnel.'
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
	END


--CompartmentNumber
IF	(@CompartmentNumber	>	@NumberOfComp)
	BEGIN
				SET		@ErrorId						=			51021
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Invalid Compartment Number specified for the tunnel.'
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
	END


--Add, if not already defined
IF	NOT	EXISTS	(	SELECT	1	FROM	[TCD].TunnelCompartment	WHERE	WasherId	=	@TunnelId	AND	CompartmentNumber	=	@CompartmentNumber	)
	BEGIN
			BEGIN	TRAN

			BEGIN	TRY
						INSERT	[TCD].TunnelCompartment	(
								WasherId					,EcoLabAccountNumber	,CompartmentNumber	,WashStepId				,WaterInletDrainId	,WaterFlowId			,WaterLevel
							,	TemperatureControlByPMR		,UsePressExtractWater	,SplitCompartment	,RecycledWaterInlet		,Steam				,IterationPoint			,LastModifiedByUserId
						--**	Adding a part of integration with Synch./Central	-->
						,	LastModifiedTime, MyServiceLastSynchTime
						)
						OUTPUT	inserted.TunnelCompartmentId			AS			TunnelCompartmentId
							,	inserted.LastModifiedTime				AS			LastModifiedTime
						INTO	@OutputList	(
								TunnelCompartmentId
							,	LastModifiedTimestamp
							)
						--**	<--
						VALUES	(@TunnelId					,@EcoLabAccountNumber	,@CompartmentNumber	,@WashStepId			,@WaterinletDrainId	,@WaterFlowId	,@WaterLevel
							,	@TemperatureControlByPMR	,@UsePressExtractWater	,@SplitCompartment	,@RecycledWaterInlet	,@Steam				,@IterationPoint,@UserId
							--Synch./Central integration additions
							,	@CurrentUTCTime	, @CurrentUTCTime
							)

						--get the TCId of the newly generated record
						SET	@TunnelCompartmentId	=	SCOPE_IDENTITY()
			END	TRY
			BEGIN	CATCH
						SET	@ErrorId				=	ERROR_NUMBER()
						SET	@ErrorMessage			=	ERROR_MESSAGE()

						IF	(@@TRANCOUNT	>	0)
							BEGIN
								ROLLBACK
							END

						SET		@ErrorMessage		=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + ISNULL(@ErrorMessage,	N': Error occurred saving Compartment details .')
						RAISERROR	(@ErrorMessage, 16, 1)
						SET	@ReturnValue	=	-1
						RETURN	(@ReturnValue)
			END	CATCH

			--save Equipment association
			IF	EXISTS	(SELECT	1	FROM	@EquipmentAssociation)
				BEGIN
					BEGIN	TRY
								INSERT	[TCD].TunnelCompartmentEquipmentMapping	(
										EcoLabAccountNumber	,TunnelCompartmentId	,ControllerEquipmentSetupId	,Is_Deleted	,LastModifiedByUserId , MyServiceCmpmtDsgDvcguid	)
								SELECT	@EcoLabAccountNumber					AS			EcoLabAccountNumber
									,	@TunnelCompartmentId					AS			TunnelCompartmentId
									,	A.ControllerEquipmentSetupId			AS			ControllerEquipmentSetupId
									,	'FALSE'									AS			Is_Deleted
									,	@UserId									AS			LastModifiedByUserId
									,	@MyServiceCmpmtDsgDvcguid				As			MyServiceCmpmtDsgDvcguid
								FROM	@EquipmentAssociation					A
								WHERE	A.DeleteFlag							=			'FALSE'

								--commit the tran now and exit module
								COMMIT

								SELECT	TOP	1
										@OutputTunnelCompartmentId			=			O.TunnelCompartmentId
								FROM	@OutputList							O

								RETURN	0
					END	TRY
					BEGIN	CATCH
								SET	@ErrorId				=	ERROR_NUMBER()
								SET	@ErrorMessage			=	ERROR_MESSAGE()

								IF	(@@TRANCOUNT	>	0)
									BEGIN
										ROLLBACK
									END

								SET		@ErrorMessage		=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + ISNULL(@ErrorMessage,	N': Error occurred saving Compartment-Equipment details .')
								RAISERROR	(@ErrorMessage, 16, 1)
								SET	@ReturnValue	=	-1
								RETURN	(@ReturnValue)
					END	CATCH
				END
			ELSE	--If no Equipment association to be saved, commit the INSERT above
				BEGIN
					IF	(@@TRANCOUNT	>	0)
						BEGIN
							COMMIT

							SELECT	TOP	1
									@OutputTunnelCompartmentId			=			O.TunnelCompartmentId
							FROM	@OutputList							O

							RETURN	0
						END
				END

	END
ELSE		--Update already defined Compartment details
	BEGIN
			--Get the TCId first...
			SELECT	@TunnelCompartmentId					=			TC.TunnelCompartmentId
			FROM	[TCD].TunnelCompartment					TC
			WHERE	TC.EcoLabAccountNumber					=			@EcoLabAccountNumber
				AND	TC.WasherId								=			@TunnelId
				AND	TC.CompartmentNumber					=			@CompartmentNumber

			IF	(@TunnelCompartmentId	IS	NULL)
				BEGIN
						SET		@ErrorId					=			51022
						SET		@ErrorMessage				=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Could not determine the Compartment provided for the specified tunnel.'
						RAISERROR	(@ErrorMessage, 16, 1)
						SET	@ReturnValue	=	-1
						RETURN	(@ReturnValue)
				END


			--If the call is not local, check that the LastModifiedTime matches with the central
			IF	(
					@LastModifiedTimestampAtCentral			IS NOT	NULL
				AND	NOT	EXISTS	(	SELECT	1
									FROM	TCD.[TunnelCompartment]	TC
									WHERE	TC.EcolabAccountNumber	=	@EcolabAccountNumber
										AND	TC.TunnelCompartmentId	=	@TunnelCompartmentId
										AND	TC.LastModifiedTime		=	@LastModifiedTimestampAtCentral
								)
				)
				BEGIN
						SET			@ErrorId						=	60000
						SET			@ErrorMessage					=	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
						RAISERROR	(@ErrorMessage, 16, 1)
						SET			@ReturnValue					=	-1
						RETURN		(@ReturnValue)
				END
				
			--Proceed, since it's either a local call or Synch. call with synch. time matching
			BEGIN	TRAN

			BEGIN	TRY
						UPDATE	TC
							SET	TC.WashStepId					=			@WashStepId
							,	TC.WaterInletDrainId			=			@WaterinletDrainId
							,	TC.WaterFlowId					=			@WaterFlowId
							,	TC.WaterLevel					=			@WaterLevel
							,	TC.TemperatureControlByPMR		=			@TemperatureControlByPMR
							,	TC.UsePressExtractWater			=			@UsePressExtractWater
							,	TC.SplitCompartment				=			@SplitCompartment
							,	TC.RecycledWaterInlet			=			@RecycledWaterInlet
							,	TC.Steam						=			@Steam
							,	TC.IterationPoint				=			@IterationPoint
							,	TC.LastModifiedByUserId			=			@UserId
						--**	Adding a part of integration with Synch./Central	-->
							,	TC.LastModifiedTime				=			@CurrentUTCTime
							,	TC.MyServiceLastSynchTime		=			@CurrentUTCTime
						OUTPUT	inserted.TunnelCompartmentId	AS			TunnelCompartmentId
							,	inserted.LastModifiedTime		AS			LastModifiedTime
						INTO	@OutputList	(
								TunnelCompartmentId
							,	LastModifiedTimestamp
							)
						--**	<--
						FROM	[TCD].TunnelCompartment			TC
            WHERE	TC.WasherId						=			@TunnelId
            AND	TC.CompartmentNumber			=			@CompartmentNumber
            END	TRY
            BEGIN	CATCH
            SET	@ErrorId						=			ERROR_NUMBER()
            SET	@ErrorMessage					=			ERROR_MESSAGE()

            IF	(@@TRANCOUNT	>	0)
            BEGIN
            ROLLBACK
            END

            SET		@ErrorMessage				=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + ISNULL(@ErrorMessage,	N': Error occurred saving Compartment details .')
            RAISERROR	(@ErrorMessage, 16, 1)
            SET	@ReturnValue	=	-1
            RETURN	(@ReturnValue)
            END	CATCH


            --save Equipment association
            IF	EXISTS	(SELECT	1	FROM	@EquipmentAssociation)
            BEGIN
            BEGIN	TRY
            --first soft-delete...
            --UPDATE	TCEM
            --	SET	TCEM.Is_Deleted							=			'TRUE'
            --	,	TCEM.LastModifiedByUserId				=			@UserId
            --FROM	[TCD].TunnelCompartmentEquipmentMapping		TCEM
            --JOIN	@EquipmentAssociation					EA
            --	ON	TCEM.ControllerEquipmentSetupId			=			EA.ControllerEquipmentSetupId
            --WHERE	TCEM.TunnelCompartmentId				=			@TunnelCompartmentId
            --	AND	TCEM.Is_Deleted							=			'FALSE'
            --	AND	EA.DeleteFlag							=			'TRUE'

            --INSERT	[TCD].TunnelCompartmentEquipmentMapping	(
            --		EcoLabAccountNumber	,TunnelCompartmentId	,ControllerEquipmentSetupId	,Is_Deleted	,LastModifiedByUserId	)
            --SELECT	@EcoLabAccountNumber					AS			EcoLabAccountNumber
            --	,	@TunnelCompartmentId					AS			TunnelCompartmentId
            --	,	EA.ControllerEquipmentSetupId			AS			ControllerEquipmentSetupId
            --	,	'FALSE'									AS			Is_Deleted
            --	,	@UserId									AS			LastModifiedByUserId
            --FROM	@EquipmentAssociation					EA
            --LEFT JOIN
            --		[TCD].TunnelCompartmentEquipmentMapping		TCEM
            --	ON	TCEM.TunnelCompartmentId				=			@TunnelCompartmentId
            --	AND	TCEM.Is_Deleted							=			'FALSE'
            --	AND	TCEM.ControllerEquipmentSetupId			=			EA.ControllerEquipmentSetupId
            --WHERE	EA.DeleteFlag							=			'FALSE'
            --	AND	TCEM.ControllerEquipmentSetupId			IS			NULL


            --commit the tran now and exit module

            ;
            MERGE	[TCD].TunnelCompartmentEquipmentMapping		AS			TARGET
            USING	@EquipmentAssociation						AS			SOURCE
            ON	TARGET.ControllerEquipmentSetupId			=			SOURCE.ControllerEquipmentSetupId
            AND	TARGET.TunnelCompartmentId					=			@TunnelCompartmentId
            AND	TARGET.EcolabAccountNumber					=			@EcolabAccountNumber
            WHEN	MATCHED	THEN
            UPDATE
            SET	TARGET.Is_Deleted					=			SOURCE.DeleteFlag
            WHEN	NOT MATCHED	BY	TARGET	THEN
            INSERT	(EcolabAccountNumber	,TunnelCompartmentId	,ControllerEquipmentSetupId			,Is_Deleted	,LastModifiedByUserId	,MyServiceCmpmtDsgDvcguid		)
            VALUES	(@EcolabAccountNumber	,@TunnelCompartmentId	,SOURCE.ControllerEquipmentSetupId	,'FALSE'	,@UserId		, @MyServiceCmpmtDsgDvcguid				)
            ;


            UPDATE tdpm
            SET tdpm.Quantity = 0
            FROM TCD.TunnelDosingSetup tds
            INNER JOIN TCD.TunnelDosingProductMapping tdpm
            ON tdpm.TunnelDosingSetupId = tds.TunnelDosingSetupId
            AND tdpm.EcoLabAccountNumber = tds.EcolabAccountNumber
            INNER JOIN TCD.TunnelProgramSetup tps
            ON tps.TunnelProgramSetupId = tds.TunnelProgramSetupId
            AND tps.EcolabAccountNumber = tds.EcolabAccountNumber
            AND tps.WasherGroupId = tds.GroupId
            INNER JOIN TCD.WasherGroup wg
            ON wg.WasherGroupId = TPS.WasherGroupId
            AND wg.EcolabAccountNumber = TPS.EcolabAccountNumber
            INNER JOIN TCD.MachineSetup ms
            ON ms.GroupId = wg.WasherGroupId
            AND ms.EcoalabAccountNumber = wg.EcolabAccountNumber
            INNER JOIN TCD.TunnelCompartment tc
            ON tc.EcoLabAccountNumber = ms.EcoalabAccountNumber
            AND tc.WasherId = ms.WasherId
            INNER JOIN TCD.TunnelCompartmentEquipmentMapping tcem
            ON tcem.EcoLabAccountNumber = tc.EcoLabAccountNumber
            AND tcem.ControllerEquipmentSetupId = tdpm.ControllerEquipmentSetupId
            AND tc.TunnelCompartmentId = tcem.TunnelCompartmentId
            AND tcem.Is_Deleted = 'True'
            WHERE ms.WasherId = @TunnelId
            AND wg.EcolabAccountNumber = @EcoLabAccountNumber

            COMMIT

            SELECT	TOP	1
            @OutputTunnelCompartmentId			=			O.TunnelCompartmentId
            FROM	@OutputList							O

            RETURN	0
            END	TRY
            BEGIN	CATCH
            SET	@ErrorId				=	ERROR_NUMBER()
            SET	@ErrorMessage			=	ERROR_MESSAGE()

            IF	(@@TRANCOUNT	>	0)
            BEGIN
            ROLLBACK
            END

            SET		@ErrorMessage		=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + ISNULL(@ErrorMessage,	N': Error occurred saving Compartment-Equipment details .')
            RAISERROR	(@ErrorMessage, 16, 1)
            SET	@ReturnValue	=	-1
            RETURN	(@ReturnValue)
            END	CATCH
            END
            ELSE	--If no Equipment association to be saved, commit the INSERT above
            BEGIN
            IF	(@@TRANCOUNT	>	0)
            BEGIN
            COMMIT

            SELECT	TOP	1
            @OutputTunnelCompartmentId			=			O.TunnelCompartmentId
            FROM	@OutputList							O

            RETURN	0
            END
            END
            END



            RETURN	(@ReturnValue)

            END
GO
			IF EXISTS(SELECT
					*
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'[TCD].[SaveTunnelCompartmentEquipmentValveMapping]')
					AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.SaveTunnelCompartmentEquipmentValveMapping
	END
GO

CREATE PROC [TCD].[SaveTunnelCompartmentEquipmentValveMapping] (
	 @lineCompartmentMappings TCD.TunnelCompartmentEquipmentValveMapping READONLY
    , @ControllerEquipmentId INT
    , @ControllerId INT
    , @LineNumber TINYINT
    , @EcolabAccountNumber NVARCHAR(25)
    , @UserId INT
)
AS
BEGIN
    DECLARE
	    @ControllerModelId INT,
	    @ControllerTypeId INT;
    (SELECT TOP 1 @ControllerModelId = CC.ControllerModelId
			 , @ControllerTypeId = CC.ControllerTypeId
	  FROM tcd.ConduitController CC
	  WHERE ControllerId = @ControllerId);
    DECLARE
	    @EquipmentSetupId INT = (SELECT TOP 1 CES.ControllerEquipmentSetupId
							 FROM TCD.ControllerEquipmentSetup CES
							 WHERE CES.ControllerId = @ControllerId
							   AND CES.ControllerEquipmentId = @ControllerEquipmentId ),
	    @PlantId INT = (SELECT TOP 1 PlantId
					  FROM TCD.Plant P
					  WHERE P.EcolabAccountNumber = @EcolabAccountNumber),
	    @DDFlag BIT = CAST(
	    CASE
	    WHEN EXISTS(SELECT 1
				   FROM @lineCompartmentMappings M
				   WHERE M.DirectDosingFlag = 1) THEN 1
		   ELSE 0
	    END
	    AS BIT);

    /* Delete the values if not necessary */

    IF @DDFlag = 'TRUE'
	   BEGIN
		  DELETE FROM TCD.TunnelCompartmentEquipmentValveMapping
		    WHERE ControllerEquipmentSetupID = @EquipmentSetupId
			 AND DirectDosingFlag = 'FALSE';
	   END;
    ELSE
	   BEGIN

		  /* Validation of max 20 Valves per Tunnel */

		  /* Looping for two Machine internal Ids*/

		  DECLARE
			  @TunnelCount INT = (SELECT TOP 1 CMCTM.NumOfTunnelWasherGroups
							    FROM TCD.ControllerModelControllerTypeMapping CMCTM
							    WHERE CMCTM.ControllerModelId = @ControllerModelId
								 AND CMCTM.ControllerTypeId = @ControllerTypeId);
		  DECLARE
			  @MaxValveCount INT = CASE
							   WHEN @ControllerModelId IN (7, 8) THEN 20
							   WHEN @ControllerModelId = 9 THEN 12
							   END;
		  DECLARE
			  @i INT = 1;
		  WHILE @i <= @TunnelCount
			 BEGIN
				IF (SELECT  COUNT(*)
					 FROM TCD.TunnelCompartmentEquipmentValveMapping TCEVM
						 JOIN
						 TCD.ControllerEquipmentSetup CES ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupID
					 WHERE CES.ControllerId = @ControllerId
					   AND TCEVM.DirectDosingFlag = 'FALSE'
					   AND CES.ControllerEquipmentId != @ControllerEquipmentId
					   AND TCEVM.TunnelNumber = @i)
				   +
				   (SELECT COUNT(*)
					 FROM @lineCompartmentMappings LCM
					 WHERE LCM.TunnelNumber = @i) > @MaxValveCount
				    BEGIN
					   RAISERROR ('807', 16, 1);
					   DECLARE
						   @ReturnValue INT = -1;
					   RETURN @ReturnValue;
				    END;
				SET @i = @i + 1;
			 END;
		  DELETE T
		    FROM TCD.TunnelCompartmentEquipmentValveMapping T
		    WHERE T.ControllerEquipmentSetupID = @EquipmentSetupId
			 AND T.PlantID = @PlantId
			 AND T.TunnelCompartmentEquipmentValveMappingID NOT IN(
				SELECT TCEVM.TunnelCompartmentEquipmentValveMappingID
				  FROM TCD.TunnelCompartmentEquipmentValveMapping TCEVM
					  INNER JOIN
					  @lineCompartmentMappings M ON TCEVM.TunnelNumber = M.TunnelNumber
										   AND TCEVM.DosingPointNumber = M.DosingPointNumber
										   AND TCEVM.ControllerEquipmentSetupID = @EquipmentSetupId
										   AND TCEVM.PlantID = @PlantId);
	   END;
    DECLARE
	    @TempMapping TABLE(
	    RowNumber INT NOT NULL
	  , ControllerEquipmentId TINYINT NOT NULL
	  , TunnelNumber INT NOT NULL
	  , CompartmentNumber TINYINT NOT NULL
	  , DosingPointNumber TINYINT NOT NULL
	  , DirectDosingFlag BIT NOT NULL
	  , VlaveNumber TINYINT NOT NULL
	  ,	WasherNumber int NOT NULL);

    /* Create RowNumber inorder to increment and use row by row. */

    WITH CTE_LCM
	   AS (
	   SELECT ROW_NUMBER() OVER (ORDER BY LCM.TunnelNumber, LCM.DosingPointNumber) AS RowNumber
		   , *
		FROM @lineCompartmentMappings LCM
	   )
	   INSERT INTO @TempMapping
	   SELECT *
		FROM CTE_LCM CL;

    /* Loop */

    DECLARE
	    @j INT = 1,
	    @max INT = (SELECT MAX(TM.RowNumber)
				   FROM @TempMapping TM);
    WHILE @j <= @max
	   BEGIN

		  /* Declare and Initialize the current row data */

		  DECLARE
			  @TunnelNumber INT,
			  @CompartmentNumber TINYINT,
			  @DosingpointNumber TINYINT;
		  SELECT TOP 1 @TunnelNumber = TM.TunnelNumber
				   , @DosingPointNumber = TM.DosingpointNumber
				   , @CompartmentNumber = TM.CompartmentNumber
		    FROM @TempMapping TM
		    WHERE TM.RowNumber = @j;
		  DECLARE
			  @ValveNumber INT = 0;
		  IF @DDFlag = 'FALSE'
			 BEGIN

				/* Get Min Available Valve Number */

				SELECT @ValveNumber = MIN(CEV.ControllerEquipmentValveID)
				  FROM TCD.ControllerEquipmentValves CEV
				  WHERE ControllerEquipmentValveID <> 0
				    AND CEV.ControllerEquipmentValveID  NOT IN (
					   SELECT TCEVM.ValveNumber
						FROM TCD.TunnelCompartmentEquipmentValveMapping TCEVM
							JOIN
							TCD.ControllerEquipmentSetup CES ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupID
						WHERE CES.ControllerID = @ControllerId
						  AND TCEVM.TunnelNumber = @TunnelNumber);
			 END;

		  /* Update If Exists else Insert */

		  MERGE TCD.TunnelCompartmentEquipmentValveMapping T
		  USING (SELECT TOP 1 *
				 FROM @TempMapping TM
				 WHERE TM.RowNumber = @j) S
		  ON T.ControllerEquipmentSetupID = @EquipmentSetupId
		 AND T.PlantID = @PlantId
		 AND T.TunnelNumber = S.TunnelNumber
		 AND T.DosingPointNumber = S.DosingPointNumber
		 AND T.DirectDosingFlag = S.DirectDosingFlag
		  WHEN MATCHED
			   THEN
			   UPDATE SET T.CompartmentNumber = S.CompartmentNumber
					  , T.ValveNumber = CASE  @DDFlag
									WHEN 'TRUE' THEN 0
									    ELSE T.ValveNumber
									END
					  , T.WasherExtractorNumber = S.WasherNumber
					  , T.LastModifiedByUserID = @UserId
		  WHEN NOT MATCHED
			   THEN
			   INSERT (PlantID
				    , ControllerEquipmentSetupID
				    , TunnelNumber
				    , DosingPointNumber
				    , ValveNumber
				    , CompartmentNumber
				    , DirectDosingFlag
				    , LastModifiedByUserID)
			   VALUES (@PlantId,
					 @EquipmentSetupId,
					 S.TunnelNumber,
					 S.DosingPointNumber,
					 @ValveNumber,
					 S.CompartmentNumber,
					 S.DirectDosingFlag,
					 @UserId);

		  /* Increment the row */

		  SET @j = @j + 1;
	   END;
END;
GO
IF EXISTS(SELECT
					*
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'[TCD].[SaveWasherFlushTime]')
					AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.SaveWasherFlushTime
	END
GO

CREATE PROCEDURE [TCD].[SaveWasherFlushTime] (
      @WasherFlushTime TCD.WasherFlushTime READONLY 
    , @EcolabAccountNumber NVARCHAR(25)
    , @UserId INT)
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @CurrentUTC DATETIME = GETUTCDATE(),
			@PlantId INT = (SELECT P.PlantId 
							FROM TCD.Plant P 
							WHERE P.EcolabAccountNumber = @EcolabAccountNumber),
			@IsExistingRecord INT = (SELECT COUNT(*) FROM TCD.WasherFlushTime wft
														INNER JOIN @WasherFlushTime uwft
																	ON wft.WasherId = uwft.WasherId
																		AND wft.PlantId = (SELECT P.PlantId FROM TCD.Plant P WHERE P.EcolabAccountNumber = @EcolabAccountNumber)
																		AND wft.LineNumber = uwft.LineNumber
																		AND wft.WasherFlushTypeId = uwft.WasherFlushTypeId )

	IF @IsExistingRecord = 0
		BEGIN
			INSERT INTO TCD.WasherFlushTime
			(
				WasherId,
				PlantId,
				LineNumber,
				WasherFlushTypeId,
				FlushTime,
				LastModifiedByUserId,
				LastModifiedTime
			)
			SELECT uwft.WasherId,
					@PlantId,
					uwft.LineNumber,
					uwft.WasherFlushTypeId,
					uwft.FlushTime,
					@UserId,
					@CurrentUTC
			FROM @WasherFlushTime uwft 
			LEFT JOIN  TCD.WasherFlushTime as wft ON wft.WasherId = uwft.washerId AND wft.LineNumber = uwft.LineNumber AND wft.WasherFlushTypeId = uwft.WasherFlushTypeId AND wft.PlantId = @PlantId
			WHERE wft.washerId IS NULL 
		END

	ELSE
		BEGIN
			UPDATE wft
			SET
				wft.FlushTime = uwft.FlushTime, -- int
				wft.LastModifiedByUserId = @UserId,
				wft.LastModifiedTime = @CurrentUTC
			FROM @WasherFlushTime  uwft
			INNER JOIN TCD.WasherFlushTime wft
			ON wft.WasherId = uwft.WasherId
			AND wft.PlantId = @PlantId
			AND wft.LineNumber = uwft.LineNumber
			AND wft.WasherFlushTypeId = uwft.WasherFlushTypeId
			
		END	
			
END
GO
IF EXISTS(SELECT
					*
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'[TCD].[SaveWasherProductDeviationData]')
					AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.SaveWasherProductDeviationData
	END
GO

CREATE PROCEDURE [TCD].[SaveWasherProductDeviationData](
		@ProductDeviationData TCD.ProductDeviationData READONLY,
		@isNewRecord int,
		@EcolabAccountNumber NVARCHAR(25))
AS
BEGIN

DECLARE @PlantId INT = (SELECT P.PlantId 
                       FROM TCD.Plant P 
                       WHERE P.EcolabAccountNumber = @EcolabAccountNumber),
		@ExistingRecords INT = (SELECT count(*) FROM TCD.WasherProductDeviations WHERE TCD.WasherProductDeviations.WasherId=(SELECT TOP 1 (WasherId) FROM @ProductDeviationData) and TCD.WasherProductDeviations.ControllerID=(SELECT TOP 1 (ControllerID) FROM @ProductDeviationData))

	If(@ExistingRecords = 0)
		BEGIN
			INSERT INTO TCD.WasherProductDeviations
			(
				WasherId,
				ControllerEquipmentID,
				ControllerID,
				ProductDeviation,
				PlantId
			)
			SELECT 
				udtt.WasherId, 
				udtt.ControllerEquipmentID,
				udtt.ControllerID,
				udtt.Deviation,
				@PlantId
				FROM
				@ProductDeviationData udtt 
		END
	ELSE
		BEGIN
	
	UPDATE WPD 
		SET	WPD.ProductDeviation = udtt.Deviation
	FROM TCD.WasherProductDeviations WPD
	
	INNER JOIN @ProductDeviationData udtt 
			ON WPD.WasherProductDeviationID = udtt.WasherProductDeviationId
		END
END
GO
IF EXISTS(SELECT
					*
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'[TCD].[SaveWasherTimeOutMachine]')
					AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.SaveWasherTimeOutMachine
	END
GO

CREATE PROCEDURE TCD.SaveWasherTimeOutMachine (
		@WasherTimeOutMachine TCD.WasherTimeOutMachine READONLY ,
		@EcolabAccountNumber NVARCHAR(25),
		@UserId INT)
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @CurrentUTC DATETIME = GETUTCDATE(),
						@PlantId INT = (SELECT P.PlantId 
											FROM TCD.Plant P 
											WHERE P.EcolabAccountNumber = @EcolabAccountNumber)

INSERT INTO TCD.WasherTimeOutMachine
		(WasherId,
		PlantId,
		SignalNumber,
		EquipmentNumber,
		DosingPointNumber,
		LastModifiedByUserId,
		LastModifiedTime
		)
SELECT uwtom.WasherId,
		@PlantId,
		uwtom.SignalNumber,
		uwtom.EquipmentNumber,
		uwtom.DosingPointNumber,
		@UserId,
		@CurrentUTC
	FROM @WasherTimeOutMachine AS uwtom 
	LEFT JOIN  TCD.WasherTimeOutMachine AS wtom ON wtom.WasherId = uwtom.washerId 
		AND wtom.SignalNumber = uwtom.SignalNumber 
		AND wtom.PlantId = @PlantId
	WHERE wtom.washerId IS NULL  



UPDATE wtom SET wtom.EquipmentNumber = uwtom.EquipmentNumber, -- int
		wtom.DosingPointNumber = uwtom.DosingPointNumber,
		wtom.LastModifiedByUserId = @UserId,
		wtom.LastModifiedTime = @CurrentUTC
	FROM TCD.WasherTimeOutMachine wtom
	INNER JOIN @WasherTimeOutMachine uwtom ON wtom.WasherId = uwtom.WasherId
		AND wtom.PlantId = @PlantId
		AND wtom.SignalNumber = uwtom.SignalNumber
END
GO

IF EXISTS(SELECT
					*
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'[TCD].[SaveTunnelCompartmentEquipmentValveMapping_DECentral]')
					AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.[SaveTunnelCompartmentEquipmentValveMapping_DECentral]
	END
GO

CREATE PROC [TCD].[SaveTunnelCompartmentEquipmentValveMapping_DECentral] (    
	  @WasherCompartmentMappings TCD.TunnelCompartmentEquipmentValveMapping READONLY    
    , @ControllerEquipmentId INT    
    , @ControllerId INT      
    , @EcolabAccountNumber NVARCHAR(25)    
    , @UserId INT    
)    
AS    
BEGIN    
    DECLARE    
     @EquipmentSetupId INT = (SELECT TOP 1 CES.ControllerEquipmentSetupId    
        FROM TCD.ControllerEquipmentSetup CES    
        WHERE CES.ControllerId = @ControllerId    
          AND CES.ControllerEquipmentId = @ControllerEquipmentId ),    

	@EquipmentTypeId INT = (SELECT TOP 1 CES.ControllerEquipmentTypeId    
        FROM TCD.ControllerEquipmentSetup CES    
        WHERE CES.ControllerId = @ControllerId    
          AND CES.ControllerEquipmentId = @ControllerEquipmentId ),    


     @PlantId INT = (SELECT TOP 1 PlantId    
  FROM TCD.Plant P    
       WHERE P.EcolabAccountNumber = @EcolabAccountNumber);  
    
    DECLARE    
     @TempMapping TABLE(    
     RowNumber INT NOT NULL    
   , ControllerEquipmentId TINYINT NOT NULL    
   , TunnelNumber INT NOT NULL    
   , CompartmentNumber TINYINT NOT NULL    
   , DosingPointNumber TINYINT NOT NULL    
   , DirectDosingFlag BIT NOT NULL  
   , ValveNumber TINYINT NOT NULL
   , WasherNumber int NOT NULL);    
    
    /* Create RowNumber inorder to increment and use row by row. */    
    
    WITH CTE_LCM    
    AS (    
    SELECT ROW_NUMBER() OVER (ORDER BY LCM.TunnelNumber, LCM.DosingPointNumber) AS RowNumber    
     , LCM.ControllerEquipmentId  
     , LCM.TunnelNumber  
     , LCM.CompartmentNumber  
     , LCM.DosingPointNumber  
     , LCM.DirectDosingFlag  
     , LCM.ValveNumber  
	 , LCM.WasherNumber
  FROM @WasherCompartmentMappings LCM    
    )    
    INSERT INTO @TempMapping    
    SELECT *    
  FROM CTE_LCM CL;    
    
    /* Loop */    
    
    DECLARE    
     @i INT = 1,    
     @max INT = (SELECT MAX(TM.RowNumber)    
       FROM @TempMapping TM);    
    WHILE @i <= @max    
    BEGIN    
    
    /* Declare and Initialize the current row data */    
    
    DECLARE    
     @TunnelNumber INT,   
	 @CompartmentNumber tinyint, 
     @DosingPointNumber TINYINT,  
     @WasherNumber INT;  
    SELECT TOP 1 @TunnelNumber = TM.TunnelNumber   
		, @CompartmentNumber = TM.CompartmentNumber 
       , @DosingPointNumber = TM.DosingPointNumber    
       , @WasherNumber       = TM.WasherNumber  
      FROM @TempMapping TM    
      WHERE TM.RowNumber = @i;   

    /* Update If Exists else Insert */    
    IF(@EquipmentTypeId = 1)
	BEGIN
	 MERGE TCD.TunnelCompartmentEquipmentValveMapping T    
    USING (SELECT TOP 1 *    
     FROM @TempMapping TM    
     WHERE TM.RowNumber = @i) S    
    ON T.ControllerEquipmentSetupID = @EquipmentSetupId  
    WHEN MATCHED    
      THEN    
      UPDATE SET             
        T.CompartmentNumber = S.CompartmentNumber  
       , T.DosingPointNumber = S.DosingPointNumber
	   , T.TunnelNumber = S.TunnelNumber
	   , T.WasherExtractorNumber = S.WasherNumber
          
    WHEN NOT MATCHED    
      THEN    
      INSERT (PlantID    
        , ControllerEquipmentSetupID    
        , TunnelNumber  
		, WasherExtractorNumber  
        , DosingPointNumber    
        , ValveNumber    
        , CompartmentNumber    
        , DirectDosingFlag    
        , LastModifiedByUserID)    
      VALUES (@PlantId,    
      @EquipmentSetupId,    
      S.TunnelNumber,  
	  S.WasherNumber,  
      S.DosingPointNumber,    
      S.ValveNumber,    
      S.CompartmentNumber,    
      S.DirectDosingFlag,    
      @UserId); 
	END
	ELSE

	BEGIN
	 MERGE TCD.TunnelCompartmentEquipmentValveMapping T    
    USING (SELECT TOP 1 *    
     FROM @TempMapping TM    
     WHERE TM.RowNumber = @i) S    
    ON T.ControllerEquipmentSetupID = @EquipmentSetupId  
	AND T.DosingPointNumber = @DosingPointNumber
    WHEN MATCHED    
      THEN    
      UPDATE SET             
        T.CompartmentNumber = S.CompartmentNumber  
       , T.DosingPointNumber = S.DosingPointNumber
	   , T.TunnelNumber = S.TunnelNumber
	   , T.WasherExtractorNumber = S.WasherNumber
          
    WHEN NOT MATCHED    
      THEN    
      INSERT (PlantID    
        , ControllerEquipmentSetupID    
        , TunnelNumber  
		, WasherExtractorNumber  
        , DosingPointNumber    
        , ValveNumber    
        , CompartmentNumber    
        , DirectDosingFlag    
        , LastModifiedByUserID)    
      VALUES (@PlantId,    
      @EquipmentSetupId,    
      S.TunnelNumber,  
	  S.WasherNumber,  
      S.DosingPointNumber,    
      S.ValveNumber,    
      S.CompartmentNumber,    
      S.DirectDosingFlag,    
      @UserId); 
	END
	
      
    
    /* Increment the row */    
    
    SET @i = @i + 1;    
    END;    
END;


IF EXISTS(SELECT
					*
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'[TCD].[SaveTunnelCompartmentEquipmentValveMapping_XL]')
					AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.SaveTunnelCompartmentEquipmentValveMapping_XL
	END
GO


CREATE PROC [TCD].[SaveTunnelCompartmentEquipmentValveMapping_XL] (    
  @ValveCompartmentMappings TCD.TunnelCompartmentEquipmentValveMapping READONLY    
    , @ControllerEquipmentId INT    
    , @ControllerId INT      
    , @EcolabAccountNumber NVARCHAR(25)    
    , @UserId INT    
)    
AS    
BEGIN    
    DECLARE    
     @EquipmentSetupId INT = (SELECT TOP 1 CES.ControllerEquipmentSetupId    
        FROM TCD.ControllerEquipmentSetup CES    
        WHERE CES.ControllerId = @ControllerId    
          AND CES.ControllerEquipmentId = @ControllerEquipmentId ),    
     @PlantId INT = (SELECT TOP 1 PlantId    
  FROM TCD.Plant P    
       WHERE P.EcolabAccountNumber = @EcolabAccountNumber),  
     @DDFlag BIT = CAST(    
     CASE    
     WHEN EXISTS(SELECT 1    
       FROM @ValveCompartmentMappings M    
       WHERE M.DirectDosingFlag = 1) THEN 1    
     ELSE 0    
     END    
     AS BIT);    
    
    /* Delete the values if not necessary */    
    
    IF @DDFlag = 'TRUE'    
    BEGIN    
    DELETE FROM TCD.TunnelCompartmentEquipmentValveMapping    
      WHERE ControllerEquipmentSetupID = @EquipmentSetupId    
    AND DirectDosingFlag = 'FALSE';    
    END;    
    ELSE    
    BEGIN    
    DELETE T    
      FROM TCD.TunnelCompartmentEquipmentValveMapping T    
      WHERE ControllerEquipmentSetupID = @EquipmentSetupId    
    AND T.PlantID = @PlantId    
    AND T.TunnelCompartmentEquipmentValveMappingID NOT IN(    
    SELECT TCEVM.TunnelCompartmentEquipmentValveMappingID    
      FROM TCD.TunnelCompartmentEquipmentValveMapping TCEVM    
       INNER JOIN    
       @ValveCompartmentMappings M ON TCEVM.TunnelNumber = M.TunnelNumber    
             AND TCEVM.DosingPointNumber = M.DosingPointNumber  
			 AND TCEVM.ValveNumber = M.ValveNumber    
             AND TCEVM.ControllerEquipmentSetupID = @EquipmentSetupId    
             AND TCEVM.PlantID = @PlantId);    
    END;   
       
    DECLARE    
     @TempMapping TABLE(    
     RowNumber INT NOT NULL    
   , ControllerEquipmentId TINYINT NOT NULL    
   , TunnelNumber INT NOT NULL    
   , CompartmentNumber TINYINT NOT NULL    
   , DosingPointNumber TINYINT NOT NULL    
   , DirectDosingFlag BIT NOT NULL  
   , ValveNumber TINYINT NOT NULL
   , WasherNumber int NOT NULL);    
    
    /* Create RowNumber inorder to increment and use row by row. */    
    
    WITH CTE_LCM    
    AS (    
    SELECT ROW_NUMBER() OVER (ORDER BY LCM.TunnelNumber, LCM.DosingPointNumber) AS RowNumber    
     , LCM.ControllerEquipmentId  
     , LCM.TunnelNumber  
     , LCM.CompartmentNumber  
     , LCM.DosingPointNumber  
     , LCM.DirectDosingFlag  
     , LCM.ValveNumber  
	 , LCM.WasherNumber
  FROM @ValveCompartmentMappings LCM    
    )    
    INSERT INTO @TempMapping    
    SELECT *    
  FROM CTE_LCM CL;    
    
    /* Loop */    
    
    DECLARE    
     @i INT = 1,    
     @max INT = (SELECT MAX(TM.RowNumber)    
       FROM @TempMapping TM);    
    WHILE @i <= @max    
    BEGIN    
    
    /* Declare and Initialize the current row data */    
    
    DECLARE    
     @TunnelNumber INT,    
     @CompartmentNumber TINYINT,    
     --@DosingpointNumber TINYINT,   
     @ValveNumber TINYINT;  
    SELECT TOP 1 @TunnelNumber = TM.TunnelNumber    
       --, @DosingPointNumber = TM.DosingpointNumber    
       , @CompartmentNumber = TM.CompartmentNumber    
       , @ValveNumber       = TM.ValveNumber  
      FROM @TempMapping TM    
      WHERE TM.RowNumber = @i;    
    --DECLARE    
    -- @ValveNumber INT = 0;    
    --IF @DDFlag = 'FALSE'    
    --BEGIN    
    
    --/* Get Min Available Valve Number */    
    
    --SELECT @ValveNumber = MIN(CEV.ControllerEquipmentValveID)    
    --  FROM TCD.ControllerEquipmentValves CEV    
    --  WHERE ControllerEquipmentValveID <> 0    
    --    AND CEV.ControllerEquipmentValveID  NOT IN (    
    --    SELECT TCEVM.ValveNumber    
    --  FROM TCD.TunnelCompartmentEquipmentValveMapping TCEVM    
    --   JOIN    
    --   TCD.ControllerEquipmentSetup CES ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupID    
    --  WHERE CES.ControllerID = @ControllerId    
    --    AND TCEVM.TunnelNumber = @TunnelNumber);    
    --END;    
    --PRINT @ValveNumber;    
    
    /* Update If Exists else Insert */    
    
    MERGE TCD.TunnelCompartmentEquipmentValveMapping T    
    USING (SELECT TOP 1 *    
     FROM @TempMapping TM    
     WHERE TM.RowNumber = @i) S    
    ON T.ControllerEquipmentSetupID = @EquipmentSetupId    
   --AND T.CompartmentNumber = S.CompartmentNumber    
   AND T.ValveNumber = S.ValveNumber    
    WHEN MATCHED    
      THEN    
      UPDATE SET --T.TunnelNumber = S.TunnelNumber             
        T.CompartmentNumber = S.CompartmentNumber  
       , T.DirectDosingFlag = S.DirectDosingFlag  
       --, T.ValveNumber =  S.ValveNumber  
          
    WHEN NOT MATCHED    
      THEN    
      INSERT (PlantID    
        , ControllerEquipmentSetupID    
        , TunnelNumber    
        , DosingPointNumber    
        , ValveNumber    
        , CompartmentNumber    
        , DirectDosingFlag    
        , LastModifiedByUserID)    
      VALUES (@PlantId,    
      @EquipmentSetupId,    
      S.TunnelNumber,    
      S.DosingPointNumber,    
      S.ValveNumber,    
      S.CompartmentNumber,    
      S.DirectDosingFlag,    
      @UserId);    
    
    /* Increment the row */    
    
    SET @i = @i + 1;    
    END;    
END;


/****** Object:  Table [TCD].[ModuleReading]    Script Date: 02/24/2016 14:13:47 ******/
/**
Added Three coloumns to ModuleReading Table
**/

IF NOT EXISTS(SELECT * FROM sys.columns
WHERE Name = N'PlantId' AND OBJECT_ID = OBJECT_ID(N'[TCD].[ModuleReading]'))
BEGIN 
ALTER TABLE [TCD].[ModuleReading] 
ADD [PlantId] [int]  NULL
END
GO


IF NOT EXISTS(SELECT * FROM sys.columns
WHERE Name = N'PartitionOn' AND OBJECT_ID = OBJECT_ID(N'[TCD].[ModuleReading]'))
BEGIN
ALTER TABLE [TCD].[ModuleReading] 
ADD [PartitionOn] [smalldatetime] NULL
END
GO

IF NOT EXISTS(SELECT * FROM sys.columns
WHERE Name = N'LastSyncTime' AND OBJECT_ID = OBJECT_ID(N'[TCD].[ModuleReading]'))
BEGIN
ALTER TABLE [TCD].[ModuleReading] 
ADD [LastSyncTime][datetime] NULL
END
GO

/** Create a New Procedure to Update ModuleRead Last Synch Time**/

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[UpdateModuleReadLastSyncTime]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.UpdateModuleReadLastSyncTime
	END
GO 

CREATE PROCEDURE [TCD].[UpdateModuleReadLastSyncTime]

(
@ShiftId INT,
@LastSyncTime DATETIME)
AS
BEGIN
UPDATE MR 
SET LastSyncTime = @LastSyncTime  FROM TCD.ModuleReading MR, TCD.ProductionShiftData PD
WHERE(TimeStamp BETWEEN Cast(PD.StartDateTime as datetime) and Cast(PD.EndDateTime as datetime))
AND PD.ShiftId = @ShiftId
END
GO


IF EXISTS (SELECT * 
			   FROM   sys.objects 
			   WHERE  object_id = Object_id(N'[TCD].[GetPlantUtilityDetails]') 
					  AND type IN ( N'P', N'PC' )) 
BEGIN
  DROP PROCEDURE [TCD].[GetPlantUtilityDetails]
END
GO

CREATE PROCEDURE TCD.GetPlantUtilityDetails(
       @Ecolabaccountnumber VARCHAR(100))
AS
BEGIN
    SET NOCOUNT ON
    IF EXISTS(SELECT
                      s.*
                  FROM tempdb.sys.sysobjects AS s
                  WHERE s.xtype IN('U')
                    AND (s.id = OBJECT_ID(N'tempdb..#tmpWaterTypesUsed')
                      OR s.id = OBJECT_ID(N'tempdb..#tmpGasOilTypes')))
        BEGIN
            DROP TABLE
                    #tmpGasOilTypes;
            DROP TABLE
                    #tmpWaterTypesUsed;

        END

    CREATE TABLE #tmpWaterTypesUsed(
            WaterType INT, 
            WasherMode VARCHAR(1000))
    INSERT INTO #tmpWaterTypesUsed(
            WaterType, 
            WasherMode)
    (SELECT
             wds.WaterType, 
             'Washer' AS WasherMode
         FROM TCD.WasherDosingSetup AS wds
         WHERE wds.WaterType > 0
           AND wds.Is_Deleted = 0
     UNION
     SELECT
             tds.WaterType, 
             'Tunnel' AS WasherMode
         FROM TCD.TunnelDosingSetup AS tds
         WHERE tds.WaterType > 0
           AND tds.Is_Deleted = 0)


    DECLARE @Regionid INT, 
            @Usagekey VARCHAR(100)
    SELECT
            @Regionid = P.RegionID
        FROM TCD.Plant AS P
        WHERE P.EcolabAccountNumber = @Ecolabaccountnumber

    CREATE TABLE #tmpGasOilTypes(
            GasOilType VARCHAR(100), 
            EnergyContent DECIMAL(18, 4), 
            UsageKey VARCHAR(100))
    INSERT INTO #tmpGasOilTypes(
            GasOilType, 
            EnergyContent, 
            UsageKey)
    (SELECT
             gtm.Name, 
             gotm.DefaultValue, 
             gtm.UsageKey
         FROM TCD.GasoilTypeMaster AS gtm
              INNER JOIN TCD.GasOilTypeMapping AS gotm ON gtm.GasoilId = gotm.GasOilId
         WHERE gtm.GasoilId = (SELECT
                                       eud.GasOilTypeId
                                   FROM TCD.EnergyUtilityDetails AS eud
                                   WHERE eud.EcolabAccountNumber = @Ecolabaccountnumber)
           AND gotm.RegionId = @Regionid)



    SELECT DISTINCT
            @Usagekey = rkv.[Value]
        FROM TCD.DimensionalSubunits AS ds
             INNER JOIN tcd.DimensionalUnits AS du ON du.Unit = ds.Unit
             INNER JOIN TCD.DimensionalUsageKey AS duk ON duk.Unit = ds.Unit
             INNER JOIN TCD.DimensionalUnitsDefaults AS dud ON dud.UsageKey = duk.UsageKey
             INNER JOIN TCD.ResourceKeyMaster AS rkm ON rkm.KeyName = dud.Subunit
             INNER JOIN tcd.ResourceKeyValue AS rkv ON rkv.KeyName = rkm.KeyName
        WHERE duk.UsageKey = (SELECT
                                      UsageKey FROM #tmpGasOilTypes AS tgot)COLLATE Latin1_General_CI_AI
          AND dud.UnitSystemId = (SELECT
                                          p.UOMId FROM TCD.Plant AS p WHERE p.EcolabAccountNumber = @Ecolabaccountnumber)




    SELECT
            wu.EcolabAccountNumber AS EcolabAccountNumber, 
            wu.WaterFactorTypeId AS WaterFactorTypeId, 
            CASE
                WHEN wu.WaterFactorTypeId <> 0 THEN(SELECT DISTINCT
                                                            wt.Name
                                                        FROM TCD.WaterUtilityDetails AS wud
                                                             INNER JOIN TCD.WaterType AS wt ON wt.Id = wud.WaterFactorTypeId
                                                        WHERE wt.Id = wu.WaterFactorTypeId)
                WHEN wu.WaterFactorTypeId = 0 THEN CONVERT(VARCHAR(350), wu.WaterFactorTypeId)
            END AS FactorType, 
            wu.Temperature AS Temperature, 
            wu.Price AS Price, 
            eu.GasOilTypeId AS GasOilTypeId, 
            (SELECT
                     GasOilType FROM #tmpGasOilTypes AS tgot)AS GasOilType, 
            (SELECT
                     EnergyContent FROM #tmpGasOilTypes AS tgot)AS EnergyContent, 
            @Usagekey AS EnergyContentUnit, 
            eu.EnergyPrice AS EnergyPrice, 
            eu.EnergySubUnit AS EnergyPriceUnit, 
            eu.ElectricPrice AS ElectricPrice, 
            eu.BolierSteam AS BoilerSteam, 
            eu.BolierType AS BoilerType, 
            eu.Steam AS Steam, 
            eu.Boiler AS Boiler, 
            eu.Stack AS Stack, 
            eu.RewashFactor AS RewashFactor, 
            eu.EvaporationFactor AS EvaporationFactor, 
            CASE
                WHEN wu.WaterFactorTypeId <> 0 THEN(SELECT DISTINCT
                                                            wt.MyServiceUtilTypeCode
                                                        FROM TCD.WaterUtilityDetails AS wud
                                                             INNER JOIN TCD.WaterType AS wt ON wt.Id = wud.WaterFactorTypeId
                                                        WHERE wt.Id = wu.WaterFactorTypeId)
                WHEN wu.WaterFactorTypeId = 0 THEN 'V'
            END AS FreeType, 
            CASE
                WHEN(SELECT
                             COUNT(*)
                         FROM #tmpWaterTypesUsed AS twtu
                              INNER JOIN TCD.Watertype AS wt ON twtu.WaterType = wt.Id
                                                            AND wt.MyServiceUtilTypeCode = 'V'
                         WHERE twtu.WaterType = wu.WaterFactorTypeId) > 0 THEN 'TRUE'
                WHEN(SELECT
                             COUNT(*)
                         FROM #tmpWaterTypesUsed AS twtu
                              INNER JOIN TCD.Watertype AS wt ON twtu.WaterType = wt.Id
                                                            AND wt.MyServiceUtilTypeCode = 'V'
                         WHERE twtu.WaterType = wu.WaterFactorTypeId) = 0 THEN 'FALSE'
            END AS IsFactorUsed, 
            eu.LastModifiedTime, 
            wu.MyServiceWtrFctrId, 
            wu.MyServiceLastSyncTime, 
            wu.WaterUtilityDetailsId
        FROM TCD.WaterUtilityDetails AS wu
             INNER JOIN TCD.EnergyUtilityDetails AS eu ON eu.EcolabAccountNumber = wu.EcolabAccountNumber
        WHERE wu.EcolabAccountNumber = @Ecolabaccountnumber
        ORDER BY
            wu.WaterUtilityDetailsId
    SET NOCOUNT OFF
END
GO

IF EXISTS (SELECT * 
			   FROM   sys.objects 
			   WHERE  object_id = Object_id(N'[TCD].[GetWasherGroups]') 
					  AND type IN ( N'P', N'PC' )) 
BEGIN
  DROP PROCEDURE [TCD].[GetWasherGroups]
END
GO

/*	
Purpose					:	To get washer group(s) for the Washer Group Setup screen

History					:
Sept. 2014		dfozdar@allianceglobalservice.com		initial version
Oct. 2014		dfozdar@allianceglobalservice.com		Removing paging/sorting as per the decision taken...



*/
CREATE	PROCEDURE	[TCD].[GetWasherGroups]
					@EcoLabAccountNumber					NVARCHAR(1000)
				,	@WasherGroupId							INT				--Null for LIST
				,   @IsDeleted								BIT				=   'FALSE'
AS
BEGIN

SET	NOCOUNT	ON
IF @Washergroupid = -1
BEGIN
	SET @Washergroupid = NULL
END

SELECT	
		WG.WasherGroupId			AS			WasherGroupId
	,	WG.WasherGroupNumber		AS			WasherGroupNumber
	,	WG.WasherGroupName			AS			WasherGroupName
	,	WG.WasherGroupTypeId		AS			WasherGroupTypeId
	,	WGT.WasherGroupTypeName		AS			WasherGroupTypeName
	,	COUNT(*)	OVER()			AS			TotalCount
	,	GT.LastModifiedTime			AS			LastModifiedTime
	,	GT.LastSyncTime				AS			LastSyncTime
	,	WG.EcolabAccountNumber
	,	GT.Is_Deleted				AS			IsDeleted
	,	GT.MyServiceCustMchGrpGuid  AS			MyServiceWasherGroupGuid
	,    WG.ControllerId            AS          ControllerId
	,    cc.ControllerModelId       AS          ControllerModelId
	,    cc.ControllerTypeId        AS          ControllerTypeId
	,	WG.WasherDosingNumber		AS			WasherDosingNumber
	,	(SELECT COUNT(1) FROM TCD.MachineSetup ms WHERE ms.GroupId = WG.WasherGroupId AND EcoalabAccountNumber = @EcoLabAccountNumber AND ms.IsDeleted = 'False') AS WasherCount
FROM	[TCD].MachineGroup					GT
JOIN	[TCD].WasherGroup					WG
	ON	GT.Id						=			WG.WasherGroupId
	AND GT.EcolabAccountNumber		=			WG.EcolabAccountNumber
JOIN	[TCD].WasherGroupType				WGT
	ON	WG.WasherGroupTypeId		=			WGT.WasherGroupTypeId
LEFT JOIN TCD.ConduitController cc
	ON cc.ControllerId				=			WG.ControllerId
WHERE	GT.EcolabAccountNumber		=			@EcoLabAccountNumber
	AND	(GT.Is_Deleted				=			'FALSE' or GT.Is_Deleted				=			@IsDeleted)
	AND	WG.WasherGroupId			=			ISNULL(@WasherGroupId, WG.WasherGroupId)




SET	NOCOUNT	OFF

END
GO

/*For Max formula injection*/
IF EXISTS (SELECT * FROM tcd.Field f WHERE f.ClassName = 'MaxFormulaInjection' AND Max = 8)
BEGIN
	UPDATE TCD.Field SET TCD.Field.Max = 10 WHERE TCD.Field.ClassName = 'MaxFormulaInjection' AND Max = 8
END
GO

IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='11')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='5' WHERE ID='11'
	END

	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='77')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='7' WHERE ID='77'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='72')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='8' WHERE ID='72'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='19')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='9' WHERE ID='19'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='73')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='10' WHERE ID='73'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='18')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='11' WHERE ID='18'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='74')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='13' WHERE ID='74'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='75')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='15' WHERE ID='75'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='170')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='7' WHERE ID='170'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='165')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='8' WHERE ID='165'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='161')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='9' WHERE ID='161'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='166')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='10' WHERE ID='166'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='160')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='11' WHERE ID='160'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='168')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='15' WHERE ID='168'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='115')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='7' WHERE ID='115'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='110')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='8' WHERE ID='110'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='106')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='9' WHERE ID='106'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='111')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='10' WHERE ID='111'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='105')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='11' WHERE ID='105'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='113')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='15' WHERE ID='113'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='142')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='2' WHERE ID='142'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='143')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='4' WHERE ID='143'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='11')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='5' WHERE ID='11'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='144')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='6' WHERE ID='144'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='147')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='7' WHERE ID='147'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='145')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='8' WHERE ID='145'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='138')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='9' WHERE ID='138'
	END
	IF EXISTS (SELECT 1 FROM [TCD].[Field] WHERE ID='137')
	BEGIN
		 UPDATE TCD.Field SET DisplayOrder='11' WHERE ID='137'
	END
	GO

	IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[SaveTunnelCompartmentEquipmentValveMapping]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.SaveTunnelCompartmentEquipmentValveMapping
	END
GO

CREATE PROC [TCD].[SaveTunnelCompartmentEquipmentValveMapping] (
  @lineCompartmentMappings TCD.TunnelCompartmentEquipmentValveMapping READONLY
    , @ControllerEquipmentId INT
    , @ControllerId INT
    , @LineNumber TINYINT
    , @EcolabAccountNumber NVARCHAR(25)
    , @UserId INT
)
AS
BEGIN
    DECLARE
     @ControllerModelId INT,
     @ControllerTypeId INT;
    (SELECT TOP 1 @ControllerModelId = CC.ControllerModelId
    , @ControllerTypeId = CC.ControllerTypeId
   FROM tcd.ConduitController CC
   WHERE ControllerId = @ControllerId);
    DECLARE
     @EquipmentSetupId INT = (SELECT TOP 1 CES.ControllerEquipmentSetupId
        FROM TCD.ControllerEquipmentSetup CES
        WHERE CES.ControllerId = @ControllerId
          AND CES.ControllerEquipmentId = @ControllerEquipmentId ),
     @PlantId INT = (SELECT TOP 1 PlantId
       FROM TCD.Plant P
       WHERE P.EcolabAccountNumber = @EcolabAccountNumber),
     @DDFlag BIT = CAST(
     CASE
     WHEN EXISTS(SELECT 1
       FROM @lineCompartmentMappings M
       WHERE M.DirectDosingFlag = 1) THEN 1
     ELSE 0
     END
     AS BIT);

    /* Delete the values if not necessary */

    IF @DDFlag = 'TRUE'
    BEGIN
    DELETE FROM TCD.TunnelCompartmentEquipmentValveMapping
      WHERE ControllerEquipmentSetupID = @EquipmentSetupId
    AND DirectDosingFlag = 'FALSE';
    END;
    ELSE
    BEGIN

    /* Validation of max 20 Valves per Tunnel */

    /* Looping for two Machine internal Ids*/

    DECLARE
     @TunnelCount INT = (SELECT TOP 1 CMCTM.NumOfTunnelWasherGroups
           FROM TCD.ControllerModelControllerTypeMapping CMCTM
           WHERE CMCTM.ControllerModelId = @ControllerModelId
         AND CMCTM.ControllerTypeId = @ControllerTypeId);
    DECLARE
     @MaxValveCount INT = CASE
          WHEN @ControllerModelId IN (7, 8) THEN 20
          WHEN @ControllerModelId = 9 THEN 12
          END;
 
    
    IF (SELECT  COUNT(*)
      FROM TCD.TunnelCompartmentEquipmentValveMapping TCEVM
       JOIN
       TCD.ControllerEquipmentSetup CES ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupID
      WHERE CES.ControllerId = @ControllerId
        AND TCEVM.DirectDosingFlag = 'FALSE'
        AND CES.ControllerEquipmentId != @ControllerEquipmentId
        )
       +
       (SELECT COUNT(*)
      FROM @lineCompartmentMappings LCM
      ) > @MaxValveCount
        BEGIN
        RAISERROR ('8014', 16, 1);
        DECLARE
         @ReturnValue INT = -1;
        RETURN @ReturnValue;
        END;
    
    
    DELETE T
      FROM TCD.TunnelCompartmentEquipmentValveMapping T
      WHERE T.ControllerEquipmentSetupID = @EquipmentSetupId
    AND T.PlantID = @PlantId
    AND T.TunnelCompartmentEquipmentValveMappingID NOT IN(
    SELECT TCEVM.TunnelCompartmentEquipmentValveMappingID
      FROM TCD.TunnelCompartmentEquipmentValveMapping TCEVM
       INNER JOIN
       @lineCompartmentMappings M ON TCEVM.TunnelNumber = M.TunnelNumber
             AND TCEVM.DosingPointNumber = M.DosingPointNumber
             AND TCEVM.ControllerEquipmentSetupID = @EquipmentSetupId
             AND TCEVM.PlantID = @PlantId);
    END;
    DECLARE
     @TempMapping TABLE(
     RowNumber INT NOT NULL
   , ControllerEquipmentId TINYINT NOT NULL
   , TunnelNumber INT NOT NULL
   , CompartmentNumber TINYINT NOT NULL
   , DosingPointNumber TINYINT NOT NULL
   , DirectDosingFlag BIT NOT NULL
   , VlaveNumber TINYINT NOT NULL
   , WasherNumber int NOT NULL);

    /* Create RowNumber inorder to increment and use row by row. */

    WITH CTE_LCM
    AS (
    SELECT ROW_NUMBER() OVER (ORDER BY LCM.TunnelNumber, LCM.DosingPointNumber) AS RowNumber
     , *
  FROM @lineCompartmentMappings LCM
    )
    INSERT INTO @TempMapping
    SELECT *
  FROM CTE_LCM CL;

    /* Loop */

    DECLARE
     @j INT = 1,
     @max INT = (SELECT MAX(TM.RowNumber)
       FROM @TempMapping TM);
    WHILE @j <= @max
    BEGIN

    /* Declare and Initialize the current row data */

    DECLARE
     @TunnelNumber INT,
     @CompartmentNumber TINYINT,
     @DosingpointNumber TINYINT;
    SELECT TOP 1 @TunnelNumber = TM.TunnelNumber
       , @DosingPointNumber = TM.DosingpointNumber
       , @CompartmentNumber = TM.CompartmentNumber
      FROM @TempMapping TM
      WHERE TM.RowNumber = @j;
    DECLARE
     @ValveNumber INT = 0;
    IF @DDFlag = 'FALSE'
    BEGIN

    /* Get Min Available Valve Number */

    SELECT @ValveNumber = MIN(CEV.ControllerEquipmentValveID)
      FROM TCD.ControllerEquipmentValves CEV
      WHERE ControllerEquipmentValveID <> 0
        AND CEV.ControllerEquipmentValveID  NOT IN (
        SELECT TCEVM.ValveNumber
      FROM TCD.TunnelCompartmentEquipmentValveMapping TCEVM
       JOIN
       TCD.ControllerEquipmentSetup CES ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupID
      WHERE CES.ControllerID = @ControllerId);
    END;

    /* Update If Exists else Insert */

    MERGE TCD.TunnelCompartmentEquipmentValveMapping T
    USING (SELECT TOP 1 *
     FROM @TempMapping TM
     WHERE TM.RowNumber = @j) S
    ON T.ControllerEquipmentSetupID = @EquipmentSetupId
   AND T.PlantID = @PlantId
   AND T.TunnelNumber = S.TunnelNumber
   AND T.DosingPointNumber = S.DosingPointNumber
   AND T.DirectDosingFlag = S.DirectDosingFlag
    WHEN MATCHED
      THEN
      UPDATE SET T.CompartmentNumber = S.CompartmentNumber
       , T.ValveNumber = CASE  @DDFlag
         WHEN 'TRUE' THEN 0
             ELSE T.ValveNumber
         END
       , T.WasherExtractorNumber = S.WasherNumber
       , T.LastModifiedByUserID = @UserId
    WHEN NOT MATCHED
      THEN
      INSERT (PlantID
        , ControllerEquipmentSetupID
        , TunnelNumber
        , DosingPointNumber
        , ValveNumber
        , CompartmentNumber
        , DirectDosingFlag
        , LastModifiedByUserID)
      VALUES (@PlantId,
      @EquipmentSetupId,
      S.TunnelNumber,
      S.DosingPointNumber,
      @ValveNumber,
      S.CompartmentNumber,
      S.DirectDosingFlag,
      @UserId);

    /* Increment the row */

    SET @j = @j + 1;
    END;
END;

GO
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetTagManamenetDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetTagManamenetDetails
	END
GO
CREATE PROCEDURE [TCD].[GetTagManamenetDetails] 
@ControllerId INT,
@EcolabAccountNumber VARCHAR(100),
@UserId INT

AS
BEGIN 
DECLARE @Active INT = 1,
    @TankModuleTypeId INT,
    @SensorModuleTypeId INT,
    @PumpModuleTypeId INT,
    @LangunageId INT,
    @SplChars VARCHAR(50)   = ' # -',
    @LocaliseValue VARCHAR(200),
    @FactorMultiplier INT,
    @TimeVolumeMultipler INT,
	@ControllerModelId int,
	@ControllerTypeId INT


SELECT @TankModuleTypeId=mty.ModuleTypeId FROM TCD.ModuleType mty WHERE mty.ModuleDescription='Tank'
SELECT @SensorModuleTypeId=mty.ModuleTypeId FROM TCD.ModuleType mty WHERE mty.ModuleDescription='Sensor'
SELECT @PumpModuleTypeId=mty.ModuleTypeId FROM TCD.ModuleType mty WHERE mty.ModuleDescription='Pumps/Valves'
SELECT @LangunageId=p.languageID FROM TCD.Plant p WHERE p.EcolabAccountNumber=@EcolabAccountNumber


 SELECT @TimeVolumeMultipler= CAST(csd.[Value] AS decimal(18,0)) FROM TCD.ControllerSetupData csd 
 INNER JOIN TCD.Field f ON f.Id = csd.FieldId 
 WHERE csd.FieldId IN(SELECT f2.Id FROM TCD.Field f2 WHERE f2.Label LIKE '%OZ/Second Multiplier%') 
    AND csd.ControllerId=@ControllerId 
    AND csd.EcolabAccountNumber=@EcolabAccountNumber 
	AND ISNUMERIC(csd.[Value]) = 1

 SELECT @FactorMultiplier= CAST(csd.[Value] AS decimal(18,0)) FROM TCD.ControllerSetupData csd 
 INNER JOIN TCD.Field f ON f.Id = csd.FieldId 
 WHERE csd.FieldId IN(SELECT f2.Id FROM TCD.Field f2 WHERE f2.Label LIKE '%Factors Multiplier%') 
    AND csd.ControllerId=@ControllerId
    AND csd.EcolabAccountNumber=@EcolabAccountNumber 
	AND ISNUMERIC(csd.[Value]) = 1

SELECT @ControllerModelId=ControllerModelId,@ControllerTypeId=ControllerTypeId FROM tcd.ConduitController cc WHERE ControllerId=@ControllerId


CREATE TABLE #tmpTagManagementDetails
(
  Id INT
 ,TagAddress VARCHAR(100)
 ,[Description] VARCHAR(1000)
 ,Value VARCHAR(500)
 ,LastModifiedTime DATETIME 
 ,ColName VARCHAR(500)
 ,DataType varchar(100)
 ,RowNumber decimal(3,2)
 ,OriginalColumnName varchar(100)
 ,EntityType varchar(100)
 ,TagType varchar(100)
 ,ControllerEquipmentSetupId varchar(100)
 ,SortingOrder varchar(100)
)


--SELECT @LocaleValue=rkv.[Value] FROM TCD.ResourceKeyMaster rkm 
--    INNER JOIN TCD.ResourceKeyValue rkv on rkv.ResourceId = rkm.ResourceId 
--where rkm.[Key] ='FIELD_'+ UPPER(@KeyValue) 
--  AND 
--rkv.languageID=ISNULL((SELECT um.LanguageId FROM TCD.UserMaster um WHERE um.UserId=@UserId),(SELECT p.LanguageId FROM TCD.Plant p WHERE p.EcolabAccountNumber=@EcolabAccountNumber)) 


--------------------------------------
-- StorageTanks---
--------------------------------------

INSERT INTO #tmpTagManagementDetails(Id, TagAddress,    [Description],    [Value],    LastModifiedTime,colName,DataType,RowNumber,OriginalColumnName
	,EntityType,TagType,ControllerEquipmentSetupId,SortingOrder)

----------------------------------------------------------------
-- Conventional-AND-Tunnel(AWEA, EOF, MODE to be displayed)-----
----------------------------------------------------------------
SELECT ms.WasherId, wt.TagAddress,Convert(varchar(100),w.PlantWasherNumber)+' : '+ms.MachineName,Convert(varchar(100), CONVERT(int, w.EndOfFormula)),w.LastModifiedTime ,'EndofFormulaNumber',tt.DataType,1,
'EndOfFormula' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType,ms.MachineInternalId as ControllerEquipmentSetupId, 2 as SortingOrder 
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId) AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_EOF' AND ms.IsTunnel IN (0,1)
UNION

SELECT ms.WasherId, wt.TagAddress,Convert(varchar(100),w.PlantWasherNumber)+' : '+ms.MachineName,Convert(varchar(100), CONVERT(int, (
SELECT	wmm.WasherModeNumber FROM TCD.WasherModeMapping wmm	
				INNER JOIN	tcd.ControllerModelControllerTypeMapping cmctm	ON cmctm.Id	=wmm.ControllerModelControllerTypeMappingId	 
				AND cmctm.ControllerModelId=@ControllerModelId	 
				AND cmctm.ControllerTypeId=@ControllerTypeId 
				AND wmm.WasherModeId=w.WasherMode))),w.LastModifiedTime ,'WasherMode',tt.DataType,1,'WasherMode' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType,ms.MachineInternalId as ControllerEquipmentSetupId, 5 as SortingOrder  
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_MODE' AND ms.IsTunnel IN (0,1)
UNION

SELECT ms.WasherId, wt.TagAddress,Convert(varchar(100),w.PlantWasherNumber)+' : '+ms.MachineName,Convert(varchar(100), CONVERT(int, w.AWEActive)),w.LastModifiedTime ,'AWEActive',tt.DataType,1
,'AWEActive' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType,ms.MachineInternalId as ControllerEquipmentSetupId , 1 as SortingOrder 
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_AWEA' AND ms.IsTunnel IN (0,1)
UNION

SELECT ms.WasherId, wt.TagAddress,Convert(varchar(100),w.PlantWasherNumber)+' : '+ms.MachineName,Convert(varchar(100), CONVERT(int, w.HoldDelay)),w.LastModifiedTime ,'HoldDelay',tt.DataType,1
,'HoldDelay' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType, ms.MachineInternalId as ControllerEquipmentSetupId , 3 as SortingOrder

FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId  AND wt.Active=@Active  AND wt.TagType='Tag_HOLDD' AND ms.IsTunnel=0 
UNION

SELECT ms.WasherId, wt.TagAddress,Convert(varchar(100),w.PlantWasherNumber)+' : '+ms.MachineName,Convert(varchar(100), CONVERT(int, w.WaterFlushTime)),w.LastModifiedTime , 'WaterFlushTime' ,tt.DataType,1
,'WaterFlushTime' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType, ms.MachineInternalId as ControllerEquipmentSetupId, 6 as SortingOrder  
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_FLSHT' AND ms.IsTunnel=0
UNION

SELECT ms.WasherId, wt.TagAddress,Convert(varchar(100),w.PlantWasherNumber)+' : '+ms.MachineName,Convert(varchar(100), CONVERT(int, w.RatioDosingActive)),w.LastModifiedTime, 'RatioDosingActive',tt.DataType,1
,'RatioDosingActive' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType, ms.MachineInternalId as ControllerEquipmentSetupId, 4 as SortingOrder  
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_RATA' AND ms.IsTunnel=0

UNION
------------------------------------
---- Tanks---
------------------------------------
SELECT ts.TankId AS Id, mt.TagAddress AS TagAddress,   ts.TankName AS [Description],Convert(varchar(10),Convert(int,( ts.Size))) AS Value,   
ts.LastModifiedTime , 'Size',tt.DataType,1
,'Size-Size_Display' as OriginalColumnName,'[TCD].[TankSetup]' as EntityName,tt.TagType as TagType, 0 as ControllerEquipmentSetupId  , 0 as SortingOrder

FROM   TCD.ModuleTags mt INNER JOIN TCD.TankSetup ts ON ts.TankId=mt.ModuleId
Inner Join tcd.TagType tt on mt.TagType = tt.TagType

WHERE   mt.ModuleTypeId=@TankModuleTypeId    AND ts.ControllerId=@ControllerId     AND mt.Active=@Active    AND mt.TagType='Tag_SIZ' 
UNION

SELECT ts.TankId,mt.TagAddress,ts.TankName,Convert(varchar(100),Convert(int,( ts.LevelDeviation_Display))),ts.LastModifiedTime ,'Dead Band',tt.DataType,1
,'LevelDeviation-LevelDeviation_Display' as OriginalColumnName,'[TCD].[TankSetup]' as EntityName,tt.TagType as TagType, 0 as SortingOrder, 0 as ControllerEquipmentSetupId  

FROM    TCD.ModuleTags mt 
INNER JOIN  TCD.TankSetup ts ON ts.TankId=mt.ModuleId
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE   mt.ModuleTypeId=@TankModuleTypeId 
    AND ts.ControllerId=@ControllerId 
    AND mt.Active=@Active 
    AND mt.TagType='Tag_DEV' 
UNION

SELECT ts.TankId,mt.TagAddress,ts.TankName,Convert(varchar(100),Convert(int,( ts.CurrentLevel_Display))),ts.LastModifiedTime ,'Current Level',tt.DataType,1
,'CurrentLevel-CurrentLevel_Display' as OriginalColumnName,'[TCD].[TankSetup]' as EntityName,tt.TagType as TagType, 0 as SortingOrder, 0 as ControllerEquipmentSetupId  

FROM    TCD.ModuleTags mt 
INNER JOIN  TCD.TankSetup ts ON ts.TankId=mt.ModuleId
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE   mt.ModuleTypeId=@TankModuleTypeId 
    AND ts.ControllerId=@ControllerId 
    AND mt.Active=@Active 
    AND mt.TagType='Tag_LVL' 
UNION
----------------------------------------
---- Meter---
----------------------------------------

----------------------------------------
---- Sensor---
----------------------------------------
SELECT s.SensorId,mt.TagAddress,s.[Description],CONVERT(VARCHAR(100),CAST(s.Calibration4mA as float)),s.LastModifiedTime ,'Calibration4mA',tt.DataType,3
,'Calibration4mA' as OriginalColumnName,'[TCD].[Sensor]' as EntityName,tt.TagType as TagType, 0 as ControllerEquipmentSetupId, 0 as SortingOrder  
from TCD.ModuleTags mt INNER JOIN TCD.Sensor s ON MT.ModuleId=s.SensorId 
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE mt.ModuleTypeId=@SensorModuleTypeId AND s.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_SC4'

UNION

SELECT s.SensorId,mt.TagAddress,s.[Description],CONVERT(VARCHAR(100),CAST(s.Calibration20mA as float)),s.LastModifiedTime , 'Calibration20mA',tt.DataType,3
,'Calibration20mA' as OriginalColumnName,'[TCD].[Sensor]' as EntityName,tt.TagType as TagType, 0 as ControllerEquipmentSetupId, 0 as SortingOrder  
from TCD.ModuleTags mt INNER JOIN TCD.Sensor s ON MT.ModuleId=s.SensorId 
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE mt.ModuleTypeId=@SensorModuleTypeId AND s.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_SC20' 
UNION
--------------------------------------
-- Pumps---
--------------------------------------



SELECT  Convert(int, ces.ControllerEquipmentSetupId), mt.TagAddress,'P/V'+Convert(varchar(100), ces.ControllerEquipmentId),
Convert(varchar(100),Convert(float, ces.KFactor * @FactorMultiplier)),ces.LastModifiedTime ,'K-Factor',tt.DataType,2
,'KFactor' as OriginalColumnName,'[TCD].[ControllerEquipmentSetup]' as EntityName,tt.TagType as TagType, ControllerEquipmentId as ControllerEquipmentSetupId, 1 as SortingOrder   

FROM TCD.ModuleTags mt INNER JOIN TCD.ControllerEquipmentSetup ces ON mt.ModuleId=ces.ControllerEquipmentSetupId 
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE mt.ModuleTypeId=@PumpModuleTypeId AND ces.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_PPOL'
UNION
SELECT  Convert(int, ces.ControllerEquipmentSetupId), mt.TagAddress,'P/V'+Convert(varchar(100), ces.ControllerEquipmentId),
Convert(varchar(100),Convert(float, ces.PumpCalibration *@TimeVolumeMultipler)),ces.LastModifiedTime, 'Time Volume Calibration',tt.DataType,2
,'PumpCalibration' as OriginalColumnName,'[TCD].[ControllerEquipmentSetup]' as EntityName,tt.TagType as TagType , ControllerEquipmentId as  ControllerEquipmentSetupId, 3 as SortingOrder 
FROM TCD.ModuleTags mt INNER JOIN TCD.ControllerEquipmentSetup ces ON mt.ModuleId=ces.ControllerEquipmentSetupId
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE mt.ModuleTypeId=@PumpModuleTypeId AND ces.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_OPSL'
UNION

SELECT Convert(int, ces.ControllerEquipmentSetupId), mt.TagAddress,'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
ces.LfsChemicalName,ces.LastModifiedTime ,'LFS Chemical Name',tt.DataType,2
,'LfsChemicalName' as OriginalColumnName,'[TCD].[ControllerEquipmentSetup]' as EntityName,tt.TagType as TagType, ControllerEquipmentId as ControllerEquipmentSetupId  , 2 as SortingOrder 

FROM TCD.ModuleTags mt INNER JOIN TCD.ControllerEquipmentSetup ces ON mt.ModuleId=ces.ControllerEquipmentSetupId
Inner Join tcd.TagType tt on mt.TagType = tt.TagType 
WHERE mt.ModuleTypeId=@PumpModuleTypeId AND ces.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_NML' 
UNION

SELECT csd.ControllerId ,ct.TagAddress,NULL,csd.[Value],cc.LastModifiedTime , f.Label,tt.DataType,6
,'Value-'+CAST(csd.FieldId as varchar) as OriginalColumnName,'[TCD].[ControllerSetupData]' as EntityName,tt.TagType as TagType, 0 as ControllerEquipmentSetupId  , 0 as SortingOrder
FROM TCD.ControllerTags ct 
INNER JOIN TCD.ControllerSetupData csd ON csd.ControllerId = ct.ControllerId
INNER JOIN tcd.Field f ON f.Id = csd.FieldId AND ct.TagType=f.HasFieldTag
INNER JOIN TCD.ConduitController cc ON cc.ControllerId = ct.ControllerId
Inner Join tcd.TagType tt on ct.TagType = tt.TagType
WHERE ct.ControllerId=@ControllerId AND ct.Active=@Active

UNION

SELECT ces.ControllerEquipmentSetupId,
	   'stMachineConfig.xFlowSwitchType['+cast(ControllerEquipmentId AS varchar(20))+']' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  cast( FlowDetectorType AS varchar(20)) AS Value, 
	   ces.LastModifiedTime,
	   'Flow Detector Type' AS Lable,
	   'BIT' As DataType ,
	   2.1,
	   'FlowDetectorType' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stMachineConfig.xFlowSwitchType' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 5 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3


UNION --Flow Switch Alarm
SELECT ces.ControllerEquipmentSetupId,
	   'stMachineConfig.xFlowAlarmOverride['+cast(ControllerEquipmentId AS varchar(20))+']' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  Cast( ces.FlowSwitchAlarm  AS varchar(20)) AS Value, 
	   ces.LastModifiedTime,
	   'Flow Switch Alarm' AS Lable,
	   'BIT' As DataType ,
	   2.2,
	   'FlowSwitchAlarm' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stMachineConfig.xFlowAlarmOverride' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId , 10 as SortingOrder 
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3
UNION --Flow Meter Alarm
SELECT ces.ControllerEquipmentSetupId,
	   'stMachineConfig.xFlowMeterAlarmOverride['+cast(ControllerEquipmentId AS varchar(20))+']' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	 cast(  ces.FlowMeterAlarm  AS varchar(20)) AS Value, 
	   ces.LastModifiedTime,
	   'Flow Meter Alarm' AS Lable,
	   'BIT' As DataType ,
	   2.3,
	   'FlowMeterAlarm' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stMachineConfig.xFlowMeterAlarmOverride' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 6 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3
UNION --Flow Meter Type
     
SELECT ces.ControllerEquipmentSetupId,
	   'stPumpConfig['+cast(ControllerEquipmentId AS varchar(20))+'].eFlowMeterMode' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  cast( ces.FlowMeterType  AS varchar(20))  AS Value, 
	   ces.LastModifiedTime,
	   'Flow Meter Type' AS Lable,
	   'INT' As DataType ,
	   2.4,
	   'FlowMeterType' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stPumpConfig.eFlowMeterMode' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 9 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3

UNION --Flow Alarm Delay Time
SELECT ces.ControllerEquipmentSetupId,
	   'stPumpConfig['+cast(ControllerEquipmentId AS varchar(20))+'].fLossOfFlowDuration' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  cast( ces.FlowAlarmDelay  AS varchar(20))  AS Value, 
	   ces.LastModifiedTime,
	   'Flow Alarm Delay Time' AS Lable,
	   'FLOAT' As DataType ,
	   2.5,
	   'FlowAlarmDelay' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stPumpConfig.fLossofFlowDuration' TagType, ces.ControllerEquipmentId  as ControllerEquipmentSetupId, 4 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3
UNION --Flow Meter Pump Delay
SELECT ces.ControllerEquipmentSetupId,
	   'stPumpConfig['+cast(ControllerEquipmentId AS varchar(20))+'].fTdFlowMeter' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  cast( ces.FlowMeterPumpDelay  AS varchar(20))  AS Value, 
	   ces.LastModifiedTime,
	   'Flow Meter Pump Delay' AS Lable,
	   'FLOAT' As DataType ,
	   2.6,
	   'FlowMeterPumpDelay' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stPumpConfig.fTdFlowMeter' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 8 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3

UNION -- Flow Meter Alarm Delay
SELECT ces.ControllerEquipmentSetupId,
	   'stPumpConfig['+cast(ControllerEquipmentId AS varchar(20))+'].fTAlarmDelayFlowMeter' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  cast( ces.FlowMeterAlarmDelay  AS varchar(20))  AS Value, 
	   ces.LastModifiedTime,
	   'Flow Meter Alarm Delay' AS Lable,
	   'FLOAT' As DataType ,
	   2.7,
	   'FlowMeterAlarmDelay' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stPumpConfig.fTAlarmDelayFlowMeter' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 7 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3



SELECT  ttmd.Id  
   ,ttmd.TagAddress  
   ,isnull(ttmd.[Description],'')
   ,ttmd.Value  
   ,ttmd.LastModifiedTime  
   ,ttmd.ColName
   ,ttmd.DataType
   ,ttmd.OriginalColumnName
	,ttmd.EntityType 
	,ttmd.TagType,ttmd.SortingOrder,ttmd.ControllerEquipmentSetupId  FROM dbo.#tmpTagManagementDetails ttmd WHERE ttmd.[Value] IS  NOT NULL AND ttmd.[Value]<> '' ORDER BY ttmd.RowNumber

END
GO
