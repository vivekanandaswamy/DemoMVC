-- Alter Usage Factor Column in Meter table

IF EXISTS(SELECT
				  *
			  FROM sys.columns
			  WHERE object_id = OBJECT_ID(N'TCD.Meter')
				AND name = 'UsageFactor')
	BEGIN
		ALTER TABLE TCD.Meter ALTER COLUMN UsageFactor DECIMAL(18, 4)NULL;
	END;
	GO


IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetControllerSetupAdvanceMetaData]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetControllerSetupAdvanceMetaData
	END
GO 
CREATE PROCEDURE [TCD].[GetControllerSetupAdvanceMetaData]
(
		@TabId INT
	,	@ControllerId INT
	,	@EcolabAccountNumber NVARCHAR(25)
 )
AS
SET NOCOUNT ON
BEGIN
	DECLARE @ControllerModelId INT = NULL, 
		@ControllerTypeId INT = NULL, 
		@ControllerVersion NVARCHAR(10) = NULL,
		@ControllerName NVARCHAR(50) = NULL
	SELECT 
			@ControllerModelId = ControllerModelId
		,	@ControllerTypeId = ControllerTypeId
		,	@ControllerName = Name
		,	@ControllerVersion = ControllerVersion 
	FROM 
		[TCD].ConduitController
	WHERE ControllerId = @ControllerId
		AND EcoalabAccountNumber = @EcolabAccountNumber
	SELECT DISTINCT
			@ControllerName AS ControllerName 
		,	FG.Id AS FieldGroupId
		,	FG.[NAME] AS FieldGroupName
		,	FG.[image_Url] as FieldGroupImageUrl
		,	FG.[helpText] as FieldGroupHelpText
		,	FG.[ControllerModelId]
		,	FG.[ControllerTypeId]
		,	FGT.NAME AS FieldGroupTypeName
		,	F.Id AS FieldId
		,	F.Name AS FieldName
		,	FT.Name AS FieldType
		,	F.Label AS FieldLabel
		,	F.[Min] AS FieldMinValue
		,	F.[Max] AS FieldMaxValue
		,	F.IsMandatory AS FieldIsMandatory
		,	F.IsEditable AS FieldIsEditable
		,	F.HelpText AS FieldHelpText
		,	F.HelpTextUrl AS FieldHelpUrl
		,	FG.TabId AS TabIndex
		,	DT.Name AS ControlType
		,	F.DataSourceId AS DataSourceId
		,	(Select 
					FS.Value + ':' + FS.Name + ';' 
				FROM [TCD].FieldSource FS 
				WHERE FS.DataSourceId = F.DataSourceId for xml path('')) AS DataSourceKeyValue
		,	F.DataCategoryId AS DataCategoryId
		,	F.DefaultValue As FieldDefaultValue
		,	F.CurrencyId AS FieldCurrencyCode
		,	F.ResourceKey AS FieldResourceKey
		,	FG.ResourceKey AS FieldGroupResourceKey
		,	FG.DisplayOrder AS FieldGroupDO
		,	F.DisplayOrder AS FieldDO
		,	FRM.RoleId AS AccessToRole
		,	'Add' AS Mode
		,	F.HasFieldTag AS HasFieldTag
		,	F.DefaultFieldTag As TagDefaultValue
		,	F.ClassName As ClassName
		,	@ControllerVersion
		,CAST (0 as bit) IsDosingLineConsumed
	 FROM [TCD].[FieldGroup] FG
		INNER JOIN [TCD].[FieldGroupFieldMapping] AS FGFM ON FG.Id = FGFM.FieldGroupId
		INNER JOIN [TCD].[Field] AS F ON F.Id = FGFM.FieldId
		LEFT JOIN [TCD].[FieldGroupType] AS FGT ON FGT.Id = FG.FieldGroupTypeId
		LEFT JOIN [TCD].FieldType AS FT ON FT.Id = F.TypeId 
		LEFT JOIN [TCD].DataType  AS DT ON DT.Id = F.DataTypeId
		LEFT JOIN [TCD].[FieldRoleMapping] AS FRM ON FRM.FieldId = F.Id
	WHERE FG.TabId = @TabId 
		AND FG.[ControllerModelId] = @ControllerModelId
		AND FG.[ControllerTypeId] = @ControllerTypeId 
		AND F.Label NOT LIKE
			CASE @ControllerModelId
				WHEN 3 THEN 'Automatic Weight Enabled'
				ELSE  ''
			END
		AND F.Label NOT LIKE
			CASE @ControllerModelId
				WHEN 3 THEN  'Ratio Dosing Enabled'
				ELSE    ''
			END
		ORDER BY FG.DisplayOrder , F.DisplayOrder, F.Id 
SET NOCOUNT OFF  
END
GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetBatchWashersByGroupId]') AND type in (N'P', N'PC'))
DROP PROCEDURE [TCD].[GetBatchWashersByGroupId]
GO

CREATE PROCEDURE [TCD].[GetBatchWashersByGroupId] 
(
  @GroupId NVARCHAR(1000) = NULL,
  @EcolabAccountNumber VARCHAR(100) 
)
AS 
  BEGIN      
 SET NOCOUNT ON
  IF @GroupId IS NULL
  BEGIN
  SELECT 
   ms.WasherId
 , (CAST(W.PlantWasherNumber AS nvarchar(50)) + N': ' + ms.MachineName) AS machineName
 , ms.GroupId 
 FROM TCD.MachineSetup ms
 INNER JOIN TCD.Washer w ON w.WasherId = ms.WasherId
 WHERE w.WasherMode != 0 AND MS.ControllerId != 0 AND ms.WasherId IN (SELECT DISTINCT ms.WasherId
         FROM [TCD].MachineSetup MS
         )
  END
  ELSE
  BEGIN
  
 SELECT 
   ms.WasherId
, (CAST(W.PlantWasherNumber AS nvarchar(50)) + N': ' + ms.MachineName) AS machineName
 , ms.GroupId 
 FROM TCD.MachineSetup ms 
 INNER JOIN TCD.Washer w ON w.WasherId = ms.WasherId
 WHERE w.WasherMode != 0 AND MS.ControllerId != 0 AND ms.WasherId IN (SELECT DISTINCT ms.WasherId
         FROM [TCD].MachineSetup MS
         WHERE ms.GroupId IN ((SELECT cast(items as int) FROM [TCD].[CharacterListToTable] (@GroupId, ','))))
        END
 SET NOCOUNT OFF

 END
 GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetWashersForManualProduction]') AND type in (N'P', N'PC'))
DROP PROCEDURE [TCD].[GetWashersForManualProduction]
GO

CREATE PROCEDURE [TCD].[GetWashersForManualProduction]     
(    
     @WasherGroupId Nvarchar(1000) ,    
     @EcolabAccountNumber VARCHAR(100)     
)    
AS     
  BEGIN          
     SET NOCOUNT ON    
      SELECT     
                  DISTINCT MS.WasherId,    
                  (CAST(W.PlantWasherNumber AS NVARCHAR(50)) + N': ' + MS.MachineName) AS machineName,    
                  MS.GroupId    
      FROM       
                [TCD].MachineSetup  AS MS  
                JOIN TCD.Washer AS W ON w.WasherId = MS.WasherId  
      WHERE     w.WasherMode = 0 
                AND MS.GroupId IN (SELECT cast(items AS INT) FROM [TCD].[CharacterListToTable] (@WasherGroupId, ',')  )    
                AND MS.IsDeleted = 0     
				AND MS.EcoalabAccountNumber = @EcolabAccountNumber
				
    SET NOCOUNT OFF    
  END
  GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetProductWasherGroups]') AND type in (N'P', N'PC'))
DROP PROCEDURE [TCD].[GetProductWasherGroups]
GO

CREATE PROCEDURE [TCD].[GetProductWasherGroups]
 (
 @EcolabAccountNumber VARCHAR(100)
 )
AS 
  BEGIN      
  SET NOCOUNT ON
   SELECT MG.Id,MG.GroupDescription FROM   [TCD].MachineGroup MG
      INNER JOIN TCD.WasherGroup WG ON MG.Id = WG.WasherGroupId       
      WHERE  MG.GroupTypeId = 2 AND MG.EcolabAccountNumber = @EcolabAccountNumber AND Is_Deleted <> 1 AND WG.WasherGroupTypeId  = 1
  SET NOCOUNT OFF
  END
  GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetBatchByGroupId]') AND type in (N'P', N'PC'))
DROP PROCEDURE [TCD].[GetBatchByGroupId]
GO

CREATE PROCEDURE [TCD].[GetBatchByGroupId] 
(
    @GroupId        NVARCHAR(1000)        =   NULL
  , @MachineId        INT                 =   NULL
  --, @ProgramId        NVARCHAR(1000)        =   NULL
  , @ProgramId       INT                 =   NULL
  , @StartDate        DATETIME            =   NULL
  , @RowsPerPage INT =50
  , @PageNumber INT = 1
)
AS 
/*
-- Usage
EXEC [TCD].[GetBatchByGroupId] @GroupId =   NULL
  , @MachineId = 1
  , @ProgramId = 54
  , @StartDate = '2014-06-06'
  , @RowsPerPage = 50
  , @PageNumber = 3


*/

  BEGIN
  SET NOCOUNT ON

	if(@ProgramId = 0)      
    BEGIN      
    set @ProgramId = null      
    END    
    
   IF @PageNumber < 1 
    SET @PageNumber = 1 

   SELECT --TOP 10 
   bd.BatchId,
   CAST(StartDate AS datetime) AS StartDate,
   COALESCE(bd.ManualInputWeight,bd.ActualWeight), 
   bd.ProgramNumber,
   pm.Name,
  Count(*) Over() TotalRows ,  
  bd.EcolabWasherId
   FROM [TCD].BatchData bd
   INNER JOIN tcd.ProgramMaster pm ON pm.ProgramId = bd.ProgramMasterId
   WHERE 
 --   bd.GroupId           IN     (SELECT cast(items as int) FROM [TCD].[CharacterListToTable] (@GroupId, ','))
     bd.MachineId        =     @MachineId
   AND   bd.ProgramNumber   =    COALESCE(@ProgramId, bd.ProgramNumber ) -- (SELECT cast(items as int) FROM [TCD].[CharacterListToTable] (@ProgramId, ','))
   AND bd.[StartDate]       >=     @StartDate
   AND  bd.[StartDate]    <= GETUTCDATE()
   ORDER BY bd.BatchId
   OFFSET (@PageNumber-1)*@RowsPerPage ROWS
   FETCH NEXT @RowsPerPage ROWS ONLY

 SET NOCOUNT OFF
  END
  GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetUserLogReportData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetUserLogReportData]
END
GO
/*

Stored Procedure	:	TCD.GetUserLogReportData

Purpose				:	To fetch data for UserLog report
Parameters			:	@EcolabAccountNumber					--	EcoLab Plant Id
						@FromDate								--	Start date from which the log is to be retrieved
						@ToDate									--	End date from which the log is to be retrieved
						@UserIDListCSV							--	Comma separated list of UserId as a filter

exec [TCD].[GetUserLogReportData] @EcolabAccountNumber=N'1',@FromDate='2015-01-01 00:00:00',@ToDate='2015-02-19 14:47:59.020',@UserIdListCSV=NULL,
							 @SortColumnID = 0,@SortDirection = 'Desc',@UserId = 3,@ActionTypeListCSV = '1',@PageNo = 1,@RecordsPerPage = 100
							
*/

CREATE PROCEDURE	[TCD].[GetUserLogReportData]	(
					@EcolabAccountNumber					NVARCHAR(1000)
				,	@FromDate								DATETIME
				,	@ToDate									DATETIME
				,	@UserIdListCSV							VARCHAR(50)			=			NULL
				,    @SortColumnID							INT				     =		     NULL
				,	@SortDirection							  Varchar(100)           =			  'desc'
				,    @UserId								INT				     =			NULL
				,    @ActionTypeListCSV						VARCHAR(50)			=			''
				,    @PageNo								INT					 =			NULL,
					@RecordsPerPage						INT					  =			NULL

)	
AS
BEGIN
SET @FromDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@FromDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@FromDate AS time)) AS DateTime))
SET @ToDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@ToDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@ToDate AS time)) AS DateTime))



SET	NOCOUNT	ON
DECLARE @ReportGenerated INT = 6
DECLARE @ManualEntry INT = 7
DECLARE @LanguageId INT

SELECT @LanguageId = ISNULL(UM.LanguageId,(SELECT TOP 1 P.LanguageId FROM TCD.Plant P)) FROM TCD.UserMaster UM WHERE UM.UserId = @UserId


/* Inserting the record into Report History */

INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)
SELECT @EcolabAccountNumber,UM.UserId,
	  UM.FullName,
	  GETUTCDATE(),
	  @ReportGenerated,
	  CASE WHEN @ReportGenerated = 6
		THEN 'Generated Report :UserLogReport' END
	  FROM TCD.UserMaster UM
		WHERE	UM.EcolabAccountNumber =	@EcolabAccountNumber AND UM.UserId = @UserId

/* Completed the record insertion into Report History */


DECLARE		@FromDateAndTime DATETIME
		,	@ToDateAndTime					DATETIME
		,	@SortField Varchar(100) = ''
		,    @SQLStatement varchar(max)

 SELECT @SortField =  CASE WHEN @SortColumnID = 1 THEN 'ActionDescription'
						WHEN @SortColumnID = 239 THEN 'DateAndTime'
						WHEN @SortColumnID = 240 THEN 'UserName'
						WHEN @SortColumnID = 241 THEN 'ActionType'
						WHEN @SortColumnID = 0 THEN 'DateAndTime' END

--table to store UserIds passed as CSList
CREATE	TABLE	#UserIdList	(
				UserId			INT			NOT	NULL
				)
--table to store UserIds passed as CSList
CREATE	TABLE	#ActionTypeList	(
				ActionType			INT			NOT	NULL
				)

SET			@FromDateAndTime				=			@FromDate
--Adjust ToDate...
SET			@ToDateAndTime					=			DATEADD(d, 1, @ToDate)


IF	@UserIdListCSV	IS NOT	NULL
	BEGIN
			INSERT	#UserIdList	(
					UserId	)
			SELECT	DISTINCT
					CAST(items AS INT)
			FROM	[TCD].[CharacterListToTable](@UserIdListCSV, ',')
	END
ELSE
	BEGIN
			INSERT	#UserIdList	(
					UserId	)
			SELECT	UM.UserId
			FROM	TCD.UserMaster			UM
	END
------------------------------------------------------------------------------
IF	@ActionTypeListCSV	IS NOT	NULL
	BEGIN
			INSERT	#ActionTypeList	(
					ActionType	)
			SELECT	DISTINCT
					CAST(items AS INT)
			FROM	[TCD].[CharacterListToTable](@ActionTypeListCSV, ',')
	END





CREATE	TABLE	#tempOutput	(
				UserId						INT
			,	UserName					NVARCHAR(200)
			,	DateAndTime					DATETIME
			,	ActionTypeId				TINYINT
			,	ActionDescription			VARCHAR(1000)
			)


--Start collecting data in the temp table...

--UserAudit
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.ActivityTime					AS			DateAndTime
	,	AT.UserActivityId				AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'UserLogon'
			THEN	UM.FullName 
			WHEN	'UserLogoff'
			THEN	UM.FullName 
		END								AS			ActionDescription
FROM	TCD.UserAudit					AT
JOIN	#UserIdList						UL
	ON	AT.UserId						=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.UserActivityId				=			AO.OperationId
WHERE	AT.EcoLabAccountNumber			=			@EcolabAccountNumber
	AND	AT.ActivityTime					BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime 



--AlarmStatusHistory
--MachineNumber is defined NULLable -- should change

INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Alarm status Created' + ' ' + ISNULL(CAST(AT.MachineNumber AS VARCHAR(5)), '')
			WHEN	'SQLUpdate'
			THEN	'Alarm status Updated' + ' ' + ISNULL(CAST(AT.MachineNumber AS VARCHAR(5)), '')
			WHEN	'AppDelete'
			THEN	'Alarm status Deleted' + ' ' + ISNULL(CAST(AT.MachineNumber AS VARCHAR(5)), '')
		END								AS			ActionDescription
FROM	TCD.AlarmStatusHistory			AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime
/*

--BatchStatusHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Batch Added - BatchId: ' + CAST(AT.BatchId	AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Batch updated - BatchId: ' + CAST(AT.BatchId	AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Batch deleted - BatchId: '  + CAST(AT.BatchId	AS VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.BatchHistory				AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcoalabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime
*/

--ConduitControllerHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Controller Created' + ' ' + CAST(AT.ControllerNumber	AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Controller Updated' + ' ' + CAST(AT.ControllerNumber	AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Controller Deleted' + ' ' + CAST(AT.ControllerNumber	AS VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.ConduitControllerHistory	AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcoalabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--ControllerEquipmentSetupHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Equipment details Created' + ' ' + CAST(CC.ControllerNumber AS VARCHAR(5)) + '/' + CAST(AT.ControllerEquipmentId AS VARCHAR(3))
			WHEN	'SQLUpdate'
			THEN	'Equipment details Updated' + ' ' + CAST(CC.ControllerNumber AS VARCHAR(5)) + '/' + CAST(AT.ControllerEquipmentId AS VARCHAR(3))
			WHEN	'AppDelete'
			THEN	'Equipment details Deleted' + ' ' + CAST(CC.ControllerNumber AS VARCHAR(5)) + '/' + CAST(AT.ControllerEquipmentId AS VARCHAR(3))
		END								AS			ActionDescription
FROM	TCD.ControllerEquipmentSetupHistory
										AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.ConduitController			CC
	ON	AT.ControllerId					=			CC.ControllerId
WHERE	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime



--ControllerSetupDataHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Controller setup data Created' + ' ' + CAST(CC.ControllerNumber AS VARCHAR(5)) + '/' + F.Label
			WHEN	'SQLUpdate'
			THEN	'Controller setup data Updated' + ' ' + CAST(CC.ControllerNumber AS VARCHAR(5)) + '/' + F.Label
			WHEN	'AppDelete'
			THEN	'Controller setup data Deleted' + ' ' + CAST(CC.ControllerNumber AS VARCHAR(5)) + '/' + F.Label
		END								AS			ActionDescription
FROM	TCD.ControllerSetupDataHistory	AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.Field						F
	ON	AT.FieldId						=			F.Id
JOIN	TCD.ConduitController			CC
	ON	AT.ControllerId					=			CC.ControllerId
WHERE	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--DashboardHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Dashboard Created' + ' ' + AT.DashBoardName
			WHEN	'SQLUpdate'
			THEN	'Dashboard Updated' + ' ' + AT.DashBoardName
			WHEN	'AppDelete'
			THEN	'Dashboard Deleted' + ' ' + AT.DashBoardName
		END								AS			ActionDescription
FROM	TCD.DashboardHistory			AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--DryersHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Dryer Created' + ' ' + CAST(AT.DryerNo AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Dryer Updated' + ' ' + CAST(AT.DryerNo AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Dryer Deleted' + ' ' + CAST(AT.DryerNo AS VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.DryersHistory				AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--FinnishersHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Finnisher Created' + ' ' + CAST(AT.FinnisherNo AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Finnisher Updated' + ' ' + CAST(AT.FinnisherNo AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Finnisher Deleted' + ' ' + CAST(AT.FinnisherNo AS VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.FinnishersHistory			AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--GroupTypeHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Group Created' + ' - ' + AT.GroupDescription
			WHEN	'SQLUpdate'
			THEN	'Group Updated' + ' - ' + AT.GroupDescription
			WHEN	'AppDelete'
			THEN	'Group Deleted' + ' - ' + AT.GroupDescription
		END								AS			ActionDescription
FROM	TCD.MachineGroupHistory			AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--LaborCostHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Labor Cost Created' + ' ' + LT.[Description]
			WHEN	'SQLUpdate'
			THEN	'Labor Cost Updated' + ' ' + LT.[Description]
			WHEN	'AppDelete'
			THEN	'Labor Cost Deleted' + ' ' + LT.[Description]
		END								AS			ActionDescription
FROM	TCD.LaborCostHistory			AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.LaborType					LT
	ON	AT.LaborTypeId					=			LT.LaborTypeId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--MachineSetupHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Machine' + ' ' + WG.WasherGroupName + '/' +	CAST(W.PlantWasherNumber AS	VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Machine' + ' ' + CAST(W.PlantWasherNumber AS	VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Machine' + ' ' + WG.WasherGroupName + '/' +	CAST(W.PlantWasherNumber AS	VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.MachineSetupHistory			AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.Washer						W
	ON	AT.WasherId						=			W.WasherId
JOIN	TCD.WasherGroup					WG
	ON	AT.GroupId						=			WG.WasherGroupId
WHERE	AT.EcoalabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime
/*

--ManualLaborHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Manual Labour Entry Created' + WG.WasherGroupName + ', Type: ' + LT.[Description]
			WHEN	'SQLUpdate'
			THEN	'Manual Labour Entry Updated' + WG.WasherGroupName + ', Type: ' + LT.[Description]
			WHEN	'AppDelete'
			THEN	'Manual Labour Entry Deleted' + WG.WasherGroupName + ', Type: ' + LT.[Description]
		END								AS			ActionDescription
FROM	TCD.ManualLaborHistory			AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.WasherGroup					WG
	ON	AT.LocationId					=			WG.WasherGroupId
JOIN	LaborType						LT
	ON	AT.ManHourTypeId				=			LT.LaborTypeId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--ManualProductionHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Added Manual Production entry - Record Date: ' + CAST(CAST(AT.RecordedDate AS DATE) AS VARCHAR(30)) + ', Value: ' + CAST(AT.Value AS	VARCHAR(30))
			WHEN	'SQLUpdate'
			THEN	'Updated Manual Production entry - Record Date: ' + CAST(CAST(AT.RecordedDate AS DATE) AS VARCHAR(30)) + ', Value: ' + CAST(AT.Value AS	VARCHAR(30))
			WHEN	'AppDelete'
			THEN	'Deleted Manual Production entry - Record Date: ' + CAST(CAST(AT.RecordedDate AS DATE) AS VARCHAR(30)) + ', Value: ' + CAST(AT.Value AS	VARCHAR(30))
		END								AS			ActionDescription
FROM	TCD.ManualProductionHistory		AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--ManualRewashHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Added Manual Rewash entry - - Record Date: ' + CAST(CAST(AT.RecordedDate AS DATE) AS VARCHAR(30)) + ', Value: ' + CAST(AT.Value AS	VARCHAR(30))
			WHEN	'SQLUpdate'
			THEN	'Updated Manual Rewash entry - - Record Date: ' + CAST(CAST(AT.RecordedDate AS DATE) AS VARCHAR(30)) + ', Value: ' + CAST(AT.Value AS	VARCHAR(30))
			WHEN	'AppDelete'
			THEN	'Deleted Manual Rewash entry - - Record Date: ' + CAST(CAST(AT.RecordedDate AS DATE) AS VARCHAR(30)) + ', Value: ' + CAST(AT.Value AS	VARCHAR(30))
		END								AS			ActionDescription
FROM	TCD.ManualRewashHistory			AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--ManualUtilityHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Added Manual Utility entry - - Record Date: ' + CAST(CAST(AT.RecordedDate AS DATE) AS VARCHAR(30)) + ', Value: ' + CAST(AT.Value AS	VARCHAR(30))
			WHEN	'SQLUpdate'
			THEN	'Updated Manual Utility entry - - Record Date: ' + CAST(CAST(AT.RecordedDate AS DATE) AS VARCHAR(30)) + ', Value: ' + CAST(AT.Value AS	VARCHAR(30))
			WHEN	'AppDelete'
			THEN	'Deleted Manual Utility entry - - Record Date: ' + CAST(CAST(AT.RecordedDate AS DATE) AS VARCHAR(30)) + ', Value: ' + CAST(AT.Value AS	VARCHAR(30))
		END								AS			ActionDescription
FROM	TCD.ManualUtilityHistory		AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime

*/

--MeterHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Meter Created' + ' ' + ISNULL(AT.[Description], '')
			WHEN	'SQLUpdate'
			THEN	'Meter Updated' + ' ' + ISNULL(AT.[Description], '')
			WHEN	'AppDelete'
			THEN	'Meter Deleted' + ' ' + ISNULL(AT.[Description], '')
		END								AS			ActionDescription
FROM	TCD.MeterHistory				AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--MonitorSetUpMappingHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Monitor setup mapping Created' + D.DashBoardName + ', Monitor : ' + ISNULL(AT.MonitorId, '')
			WHEN	'SQLUpdate'
			THEN	'Monitor setup mapping Updated' + D.DashBoardName + ', Monitor : ' + ISNULL(AT.MonitorId, '')
			WHEN	'AppDelete'
			THEN	'Monitor setup mapping Deleted' + D.DashBoardName + ', Monitor : ' + ISNULL(AT.MonitorId, '')
		END								AS			ActionDescription
FROM	TCD.MonitorSetUpMappingHistory	AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.Dashboard					D
	ON	AT.DashboardId					=			D.DashboardId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--PlantHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLUpdate'
			THEN	'Plant Updated' + ' ' + AT.EcolabAccountNumber
		END								AS			ActionDescription
FROM	TCD.PlantHistory				AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime
	AND	AO.OperationCode				=			'SQLUpdate'


--PlantContactHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Plant Contact Created' + ' ' + ISNULL(PCP.Position_Name, '') + ' , ' + AT.ContactFirstName + AT.ContactLastName
			WHEN	'SQLUpdate'
			THEN	'Plant Contact Updated' + ' ' + ISNULL(PCP.Position_Name, '') + ' , ' + AT.ContactFirstName + AT.ContactLastName
			WHEN	'AppDelete'
			THEN	'Plant Contact Deleted' + ' ' + ISNULL(PCP.Position_Name, '') + ' , ' + AT.ContactFirstName + AT.ContactLastName
		END								AS			ActionDescription
FROM	TCD.PlantContactHistory			AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	PlantContactPosition			PCP
	ON	AT.ContactPositionId			=			PCP.Id
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--PlantCustomerHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Plant Customer Created' + ' ' + AT.CustomerName
			WHEN	'SQLUpdate'
			THEN	'Plant Customer Updated' + ' ' + AT.CustomerName
			WHEN	'AppDelete'
			THEN	'Plant Customer Deleted' + ' ' + AT.CustomerName
		END								AS			ActionDescription
FROM	TCD.PlantCustomerHistory		AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--PlantUtilityEnergyPropertiesHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Plant Energy properties details updated'
		END								AS			ActionDescription
FROM	TCD.PlantUtilityEnergyPropertiesHistory
										AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime
	AND	AO.OperationCode				=			'SQLInsert'


--[TCD].PlantUtilityFactorHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Plant Utility factor details Updated: ' + ISNULL(AT.FactorType, '')
		END								AS			ActionDescription
FROM	TCD.PlantUtilityFactorHistory	AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime
	AND	AO.OperationCode				=			'SQLInsert'


--TCD.ProductDataMappingHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Product Mapping Created' + ' ' + PdM.Name
			WHEN	'SQLUpdate'
			THEN	'Product Mapping Updated' + ' ' + PdM.Name
			WHEN	'AppDelete'
			THEN	'Product Mapping Deleted' + ' ' + PdM.Name
		END								AS			ActionDescription
FROM	TCD.ProductDataMappingHistory	AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.ProductMaster				PdM
	ON	AT.ProductID					=			PdM.ProductId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--TCD.ProgramMasterHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Formula Created' + ' ' + AT.Name
			WHEN	'SQLUpdate'
			THEN	'Formula Updated' + ' ' + AT.Name
			WHEN	'AppDelete'
			THEN	'Formula Deleted' + ' ' + AT.Name
		END								AS			ActionDescription
FROM	TCD.ProgramMasterHistory		AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--TCD.RedFlagHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Red Flag Created' + ' ' + CAST(AT.Item AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Red flag Updated' + ' ' + CAST(AT.Item AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Red flag Deleted' + ' ' + CAST(AT.Item AS VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.RedFlagHistory				AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--TCD.RedFlagMappingDataHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Red flag mapping Created' + ' ' + CAST(ISNULL(AT.MachineId, 0) AS VARCHAR(5)) + ', Item :' + CAST(RF.Item AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Red flag mapping Updated' + ' ' + CAST(ISNULL(AT.MachineId, 0) AS VARCHAR(5)) + ', Item :' + CAST(RF.Item AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Red flag mapping Deleted' + ' ' + CAST(ISNULL(AT.MachineId, 0) AS VARCHAR(5)) + ', Item :' + CAST(RF.Item AS VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.RedFlagMappingDataHistory	AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.RedFlag						RF
	ON	AT.MappingId					=			RF.Id
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--TCD.SensorHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Sensor Created' + ' ' + CAST(AT.SensorId AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Sensor Updated' + ' ' + CAST(AT.SensorId AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Sensor Deleted' + ' ' + CAST(AT.SensorId AS VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.SensorHistory				AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime

/*
--TCD.ShiftHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Shift Created' + ' ' + CAST(ISNULL(AT.ShiftName, '') AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Shift Updated' + ' ' + CAST(ISNULL(AT.ShiftName, '') AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Shift Deleted' + ' ' + CAST(ISNULL(AT.ShiftName, '') AS VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.ShiftHistory				AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime

*/

--TCD.ShiftBreakDataHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Shift break Created' --+ ' ' + CAST(ISNULL(S.ShiftName, '') AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Shift break Updated' --+ ' ' + CAST(ISNULL(S.ShiftName, '') AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Shift break Deleted' --+ ' ' + CAST(ISNULL(S.ShiftName, '') AS VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.ShiftHistory				AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
--JOIN	TCD.[Shift]						S
--	ON	AT.ShiftId						=			S.ShiftId	
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--TCD.ShiftDataHistory
--ShiftId is missing from the history table...
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Shift Data Created'	--+ CAST(ISNULL(S.ShiftName, '') AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Shift Data Updated' --+ CAST(ISNULL(S.ShiftName, '') AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Shift Data Deleted' --+ CAST(ISNULL(S.ShiftName, '') AS VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.ShiftDataHistory			AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
--JOIN	TCD.[Shift]						S
--	ON	AT.ShiftId						=			S.ShiftId	
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--TCD.ShiftLaborDataHistory
--EcoLabAccountNumber is going as NULL in the History table...
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Shift Labour Created' --+ ' ' + CAST(ISNULL(S.ShiftName, '') AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Shift Labour Updated' --+ ' ' + CAST(ISNULL(S.ShiftName, '') AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Shift Labour Deleted' --+ ' ' + CAST(ISNULL(S.ShiftName, '') AS VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.ShiftLaborDataHistory		AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
--JOIN	TCD.[Shift]						S
--	ON	AT.ShiftId						=			S.ShiftId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--TCD.TankSetupHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Tank Created'	+ ' ' + ISNULL(AT.TankName, '')
			WHEN	'SQLUpdate'
			THEN	'Tank Updated'	+ ' ' + ISNULL(AT.TankName, '')
			WHEN	'AppDelete'
			THEN	'Tank Deleted'	+ ' ' + ISNULL(AT.TankName, '')
		END								AS			ActionDescription
FROM	TCD.TankSetupHistory			AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcoalabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--TCD.TunnelCompartmentHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Tunnel compartment Created'	+ ' ' + CAST(W.PlantWasherNumber AS VARCHAR(5)) + ', Compartment# : ' + CAST(AT.CompartmentNumber AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Tunnel compartment Updated'	+ ' ' + CAST(W.PlantWasherNumber AS VARCHAR(5)) + ', Compartment# : ' + CAST(AT.CompartmentNumber AS VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.TunnelCompartmentHistory	AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	Washer							W
	ON	AT.WasherId						=			W.WasherId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime
	AND	AO.OperationCode				IN			('SQLInsert', 'SQLUpdate')


--TCD.TunnelCompartmentEquipmentMappingHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Tunnel Compartment Equipment Created' + ' ' + CAST(W.PlantWasherNumber AS VARCHAR(5)) + '/' + CAST(TC.CompartmentNumber AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Tunnel Compartment Equipment Updated' + ' ' + CAST(W.PlantWasherNumber AS VARCHAR(5)) + '/' + CAST(TC.CompartmentNumber AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Tunnel Compartment Equipment Deleted' + ' ' + CAST(W.PlantWasherNumber AS VARCHAR(5)) + '/' + CAST(TC.CompartmentNumber AS VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.TunnelCompartmentEquipmentMappingHistory
										AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.TunnelCompartment			TC
	ON	AT.TunnelCompartmentId			=			TC.TunnelCompartmentId
JOIN	Washer							W
	ON	TC.WasherId						=			W.WasherId
WHERE	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--TCD.TunnelDosingProductMappingHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Tunnel Dosing Product Created' + ' ' + WG.WasherGroupName + '/' + CAST(AT.CompartmentNumber AS VARCHAR(5)) + '/' + PdM.Name
			WHEN	'SQLUpdate'
			THEN	'Tunnel Dosing Product Updated' + ' ' + WG.WasherGroupName + '/' + CAST(AT.CompartmentNumber AS VARCHAR(5)) + '/' + PdM.Name
			WHEN	'AppDelete'
			THEN	'Tunnel Dosing Product Deleted' + ' ' + WG.WasherGroupName + '/' + CAST(AT.CompartmentNumber AS VARCHAR(5)) + '/' + PdM.Name
		END								AS			ActionDescription
FROM	TCD.TunnelDosingProductMappingHistory
										AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.WasherGroup					WG
	ON	AT.GroupId						=			WG.WasherGroupId
JOIN	TCD.ProductMaster				PdM
	ON	AT.ProductId					=			PdM.ProductId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--[TCD].TunnelDosingSetupHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Tunnel Dosing Created' + ' ' + WG.WasherGroupName + '/' + CAST(AT.CompartmentNumber AS VARCHAR(5)) + '/' + CAST(TPS.ProgramNumber AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Tunnel Dosing Updated' + ' ' + WG.WasherGroupName + '/' + CAST(AT.CompartmentNumber AS VARCHAR(5)) + '/' + CAST(TPS.ProgramNumber AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Tunnel Dosing Deleted' + ' ' + WG.WasherGroupName + '/' + CAST(AT.CompartmentNumber AS VARCHAR(5)) + '/' + CAST(TPS.ProgramNumber AS VARCHAR(5))
		END								AS			ActionDescription
FROM	[TCD].TunnelDosingSetupHistory	AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.TunnelProgramSetup			TPS
	ON	AT.TunnelProgramSetupId			=			TPS.TunnelProgramSetupId
JOIN	TCD.WasherGroup					WG
	ON	TPS.WasherGroupId				=			WG.WasherGroupId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--[TCD].[TunnelProgramSetupHistory]
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Tunnel Program Created' + ' ' + WG.WasherGroupName + '/' + CAST(AT.ProgramNumber AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Tunnel Program Updated' + ' ' + WG.WasherGroupName + '/' + CAST(AT.ProgramNumber AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Tunnel Program Deleted' + ' ' + WG.WasherGroupName + '/' + CAST(AT.ProgramNumber AS VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.TunnelProgramSetupHistory	AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.WasherGroup					WG
	ON	AT.WasherGroupId				=			WG.WasherGroupId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--[TCD].UserInRoleHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'User Role Created' + ' ' + UM1.LoginName + '/' + URs.RoleName
			WHEN	'SQLUpdate'
			THEN	'User Role Updated' + ' ' + UM1.LoginName + '/' + URs.RoleName
			WHEN	'AppDelete'
			THEN	'User Role Deleted' + ' ' + UM1.LoginName + '/' + URs.RoleName
		END								AS			ActionDescription
FROM	[TCD].UserInRoleHistory			AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.UserMaster					UM1
	ON	AT.UserId						=			UM1.UserId
JOIN	TCD.UserRoles					URs
	ON	AT.RoleId						=			URs.RoleId
WHERE	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--[TCD].UserMasterHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'User Created' + ' ' + UM1.LoginName
			WHEN	'SQLUpdate'
			THEN	'User Updated' + ' ' + UM1.LoginName
			WHEN	'AppDelete'
			THEN	'User Deleted' + ' ' + UM1.LoginName
		END								AS			ActionDescription
FROM	[TCD].UserMasterHistory			AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.UserMaster					UM1
	ON	AT.UserId						=			UM1.UserId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--[TCD].WasherHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Washer Created' + ' ' + CAST(AT.PlantWasherNumber AS	VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Washer Updated' + ' ' + CAST(AT.PlantWasherNumber AS	VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Washer Deleted' + ' ' + CAST(AT.PlantWasherNumber AS	VARCHAR(5))
		END								AS			ActionDescription
FROM	[TCD].WasherHistory				AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--[TCD].[WasherDosingProductMappingHistory]
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Washer Dosing Product Created' + ' ' + WG.WasherGroupName + '/' + CAST(WDS.StepNumber AS VARCHAR(5)) + '/' + PdM.Name
			WHEN	'SQLUpdate'
			THEN	'Washer Dosing Product Updated' + ' ' + WG.WasherGroupName + '/' + CAST(WDS.StepNumber AS VARCHAR(5)) + '/' + PdM.Name
			WHEN	'AppDelete'
			THEN	'Washer Dosing Product Deleted' + ' ' + WG.WasherGroupName + '/' + CAST(WDS.StepNumber AS VARCHAR(5)) + '/' + PdM.Name
		END								AS			ActionDescription
FROM	[TCD].[WasherDosingProductMappingHistory]
										AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.WasherDosingSetup			WDS
	ON	AT.WasherDosingSetupId			=			WDS.WasherDosingSetupId
JOIN	TCD.WasherProgramSetup			WPS
	ON	WDS.WasherProgramSetupId		=			WPS.WasherProgramSetupId
JOIN	TCD.WasherGroup					WG
	ON	WPS.WasherGroupId				=			WG.WasherGroupId
JOIN	TCD.ProductMaster				PdM
	ON	AT.ProductId					=			PdM.ProductId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--[TCD].WasherDosingSetupHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Conventional Washer Dosing Created' + ' ' + WG.WasherGroupName + '/' + CAST(AT.StepNumber AS VARCHAR(5)) + '/' + CAST(WPS.ProgramNumber AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Conventional Washer Dosing Updated' + ' ' + WG.WasherGroupName + '/' + CAST(AT.StepNumber AS VARCHAR(5)) + '/' + CAST(WPS.ProgramNumber AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Conventional Washer Dosing Deleted' + ' ' + WG.WasherGroupName + '/' + CAST(AT.StepNumber AS VARCHAR(5)) + '/' + CAST(WPS.ProgramNumber AS VARCHAR(5))
		END								AS			ActionDescription
FROM	[TCD].WasherDosingSetupHistory	AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.WasherProgramSetup			WPS
	ON	AT.WasherProgramSetupId			=			WPS.WasherProgramSetupId
JOIN	TCD.WasherGroup					WG
	ON	WPS.WasherGroupId				=			WG.WasherGroupId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--[TCD].WasherGroupHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Washer Group Created' + ' ' + AT.WasherGroupName
			WHEN	'SQLUpdate'
			THEN	'Washer Group Updated' + ' ' + AT.WasherGroupName
			WHEN	'AppDelete'
			THEN	'Washer Group Deleted' + ' ' + AT.WasherGroupName
		END								AS			ActionDescription
FROM	[TCD].WasherGroupHistory		AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--[TCD].[WasherProgramSetupHistory]
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Conventional Washer Program Created' + ' ' + WG.WasherGroupName + '/' + CAST(AT.ProgramNumber AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Conventional Washer Program Updated' + ' ' + WG.WasherGroupName + '/' + CAST(AT.ProgramNumber AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Conventional Washer Program Deleted' + ' ' + WG.WasherGroupName + '/' + CAST(AT.ProgramNumber AS VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.WasherProgramSetupHistory	AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.WasherGroup					WG
	ON	AT.WasherGroupId				=			WG.WasherGroupId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--'[TCD].WaterAndEnergyHistory'
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Water & Energy Device Created' + ' ' + AT.DeviceName
			WHEN	'SQLUpdate'
			THEN	'Water & Energy Device Updated' + ' ' + AT.DeviceName
			WHEN	'AppDelete'
			THEN	'Water & Energy Device Deleted' + ' ' + AT.DeviceName
		END								AS			ActionDescription
FROM	[TCD].WaterAndEnergyHistory		AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime

--'[TCD].ReportHistory'
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.DateAndTime			AS			DateAndTime
	,	AT.ActionTypeId					AS			ActionTypeId
	,	ActionDescription	AS			ActionDescription
FROM	[TCD].ReportHistory		AT
JOIN	#UserIdList						UL
	ON	AT.UserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.ActionTypeId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.DateAndTime			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime
--Manual Entry Rewash

INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	@ManualEntry				AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Manual Rewash Created'
			WHEN	'SQLUpdate'
			THEN	'Manual Rewash Updated'
			WHEN	'AppDelete'
			THEN	'Manual Rewash Deleted'
		END								AS			ActionDescription
FROM	[TCD].ManualRewashHistory		AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime

--Manual Entry Production

INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	@ManualEntry				AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Manual Production Created'
			WHEN	'SQLUpdate'
			THEN	'Manual Production Updated'
			WHEN	'AppDelete'
			THEN	'Manual Production Deleted'
		END								AS			ActionDescription
FROM	[TCD].ManualProductionHistory		AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime
--Manual Entry Labour

INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	@ManualEntry				AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Manual Labour Created'
			WHEN	'SQLUpdate'
			THEN	'Manual Labour Updated'
			WHEN	'AppDelete'
			THEN	'Manual Labour Deleted'
		END								AS			ActionDescription
FROM	[TCD].ManualLaborHistory		AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime		
											
--Manual Entry Utility

INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	@ManualEntry				AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Manual Utility Created'
			WHEN	'SQLUpdate'
			THEN	'Manual Utility Updated'
			WHEN	'AppDelete'
			THEN	'Manual Utility Deleted'
		END								AS			ActionDescription
FROM	[TCD].ManualUtilityHistory		AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime	
											
--Manual Entry Batch data

INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	@ManualEntry				AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Manual Batch Created'
			WHEN	'SQLUpdate'
			THEN	'Manual Batch Updated'
			WHEN	'AppDelete'
			THEN	'Manual Batch Deleted'
		END								AS			ActionDescription
FROM	[TCD].BatchDataHistory		AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	--AT.EcolabAccountNumber			=			@EcolabAccountNumber AND
		AT.OperationTimestamp			BETWEEN		@FromDateAndTime
					
					
											AND		@ToDateAndTime									

--Output the collected data

SELECT	T.UserName						AS			UserName
	,	T.DateAndTime					AS			DateAndTime
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Create'
			WHEN	'SQLUpdate'
			THEN	'Updated'
			WHEN	'AppDelete'
			THEN	'Deleted'
			WHEN	'UserLogon'
			THEN	'Logged In'
			WHEN	'UserLogoff'
			THEN	'Logged Out'
			WHEN 'ReportGenerated'
			THEN	'ReportGenerated'
			WHEN 'Manual Entry' 
			THEN 'Manual Entry' 
			--WHEN 'Manual Entry' THEN CASE WHEN T.ActionDescription LIKE 'Added Manual%' THEN 'Manual Entry - Inserted'
			--					     WHEN T.ActionDescription LIKE 'Updated Manual%' THEN 'Manual Entry - Updated'
			--						WHEN T.ActionDescription LIKE 'Deleted Manual%' THEN 'Manual Entry - Deleted' END
			ELSE	AO.OperationCode
		END								AS			ActionType
	,	T.ActionDescription				AS			ActionDescription
		 ,COUNT(*) OVER() as TotalCount
		 ,1 AS ROWNO
	 INTO #UserLogTableOrder
FROM	#tempOutput						T
JOIN	TCD.AuditOperation				AO
	ON	T.ActionTypeId					=			AO.OperationId
	AND
	CASE @ActionTypeListCSV   
				 WHEN '' THEN 'TRUE'         
				 ELSE                                                      
				  CASE WHEN AO.OperationId IN (SELECT * FROM #ActionTypeList) THEN 'TRUE' END                                                      
				END='TRUE' 
	   
	   SELECT * INTO #UserLogTablePaging FROM #UserLogTableOrder WHERE 1=2



		  SET @SQLStatement 
					   ='INSERT INTO #UserLogTablePaging(UserName,DateAndTime,ActionType,ActionDescription,TotalCount,ROWNO) SELECT UserName,
							 DateAndTime,
							 ActionType,
							 ActionDescription,
							 TotalCount,
							 ROW_NUMBER() OVER (ORDER BY ' + @SortField + ' ' + @SortDirection +')
							  FROM #UserLogTableOrder ORDER BY ' + @SortField + ' ' + @SortDirection

			 --PRINT @SQLStatement
			--INSERT INTO #UserLogTablePaging(UserName,DateAndTime,ActionType,ActionDescription,TotalCount,ROWNO)
			EXEC(@SQLStatement)

	IF((@PageNo IS NULL) OR (@RecordsPerPage IS NULL))
	BEGIN
		  SELECT 
				UserName,
				DateAndTime,
				ActionType,
				ActionDescription,
				TotalCount,
				ROWNO
		   FROM #UserLogTablePaging
	 END
	  ELSE
	  BEGIN
		SET @PageNo = @PageNo-1
		  SELECT 
				UserName,
				DateAndTime,
				ActionType,
				ActionDescription,
				TotalCount,
				ROWNO
		   FROM #UserLogTablePaging
		   WHERE ROWNO BETWEEN @PageNo * @RecordsPerPage + 1 AND (@PageNo + 1) *  @RecordsPerPage  
	  END

DROP TABLE #UserLogTableOrder
DROP TABLE #UserLogTablePaging
SET NOCOUNT OFF;
END
GO
UPDATE rkv SET rkv.[Value]='Actual Consumption' FROM TCD.ResourceKeyValue rkv 
WHERE rkv.KeyName='FIELD_CONSUMPTIONPERLOAD' AND rkv.LanguageID=1

UPDATE rkv SET rkv.[Value]='Actual Cost' FROM TCD.ResourceKeyValue rkv 
WHERE rkv.KeyName='FIELD_COSTPERLOAD' AND rkv.LanguageID=1

UPDATE rkv SET rkv.[Value]='Actual water usage' FROM TCD.ResourceKeyValue rkv 
WHERE rkv.KeyName='FIELD_ACTUALWATERUSAGEPERLOAD' AND rkv.LanguageID=1

UPDATE rkv SET rkv.[Value]='Actual Chemical cost' FROM TCD.ResourceKeyValue rkv 
WHERE rkv.KeyName='FIELD_ACTUALCHEMICALCOSTPERLOAD' AND rkv.LanguageID=1

UPDATE rkv SET rkv.[Value]='Actual Energy cost' FROM TCD.ResourceKeyValue rkv 
WHERE rkv.KeyName='FIELD_ACTUALENERGYCOSTPERLOAD_REPORT' AND rkv.LanguageID=1

UPDATE rkv SET rkv.[Value]='Actual Water cost' FROM TCD.ResourceKeyValue rkv 
WHERE rkv.KeyName='FIELD_ACTUALWATERCOSTPERLOAD' AND rkv.LanguageID=1

UPDATE rkv SET rkv.[Value]='Actual Energy' FROM TCD.ResourceKeyValue rkv 
WHERE rkv.KeyName='FIELD_ACTUALENERGYPERLOAD' AND rkv.LanguageID=1

UPDATE rkv SET rkv.[Value]='Energy Target' FROM TCD.ResourceKeyValue rkv 
WHERE rkv.KeyName='FIELD_ENERGYTARGETPERLOAD' AND rkv.LanguageID=1
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetTagManamenetDetails]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetTagManamenetDetails]
END
GO
CREATE PROCEDURE [TCD].[GetTagManamenetDetails] 
@ControllerId INT,
@EcolabAccountNumber VARCHAR(100),
@UserId INT

AS
BEGIN 
DECLARE @Active INT = 1,
	@TankModuleTypeId INT,
	@SensorModuleTypeId INT,
	@PumpModuleTypeId INT,
	@LangunageId INT,
	@SplChars VARCHAR(50)   = ' # -',
	@LocaliseValue VARCHAR(200),
	@FactorMultiplier INT,
	@TimeVolumeMultipler INT,
	@ControllerModelId int


SELECT @TankModuleTypeId=mty.ModuleTypeId FROM TCD.ModuleType mty WHERE mty.ModuleDescription='Tank'
SELECT @SensorModuleTypeId=mty.ModuleTypeId FROM TCD.ModuleType mty WHERE mty.ModuleDescription='Sensor'
SELECT @PumpModuleTypeId=mty.ModuleTypeId FROM TCD.ModuleType mty WHERE mty.ModuleDescription='Pumps/Valves'
SELECT @LangunageId=p.languageID FROM TCD.Plant p WHERE p.EcolabAccountNumber=@EcolabAccountNumber


 SELECT @TimeVolumeMultipler= CAST(csd.[Value] AS decimal(18,0)) FROM TCD.ControllerSetupData csd 
 INNER JOIN TCD.Field f ON f.Id = csd.FieldId 
 WHERE csd.FieldId IN(SELECT f2.Id FROM TCD.Field f2 WHERE f2.Label LIKE '%OZ/Second Multiplier%') 
	AND csd.ControllerId=@ControllerId 
	AND csd.EcolabAccountNumber=@EcolabAccountNumber 
	AND ISNUMERIC(csd.[Value]) = 1

 SELECT @FactorMultiplier= CAST(csd.[Value] AS decimal(18,0)) FROM TCD.ControllerSetupData csd 
 INNER JOIN TCD.Field f ON f.Id = csd.FieldId 
 WHERE csd.FieldId IN(SELECT f2.Id FROM TCD.Field f2 WHERE f2.Label LIKE '%Factors Multiplier%') 
	AND csd.ControllerId=@ControllerId
	AND csd.EcolabAccountNumber=@EcolabAccountNumber 
	AND ISNUMERIC(csd.[Value]) = 1

SELECT @ControllerModelId=ControllerModelId FROM tcd.ConduitController cc WHERE ControllerId=@ControllerId


CREATE TABLE #tmpTagManagementDetails
(
  Id INT
 ,TagAddress VARCHAR(100)
 ,[Description] VARCHAR(1000)
 ,Value VARCHAR(500)
 ,LastModifiedTime DATETIME 
 ,ColName VARCHAR(500)
 ,DataType varchar(100)
 ,RowNumber decimal(3,2)
 ,OriginalColumnName varchar(100)
 ,EntityType varchar(100)
 ,TagType varchar(100)
 ,ControllerEquipmentSetupId varchar(100)
 ,SortingOrder varchar(100)
)


--SELECT @LocaleValue=rkv.[Value] FROM TCD.ResourceKeyMaster rkm 
--    INNER JOIN TCD.ResourceKeyValue rkv on rkv.ResourceId = rkm.ResourceId 
--where rkm.[Key] ='FIELD_'+ UPPER(@KeyValue) 
--  AND 
--rkv.languageID=ISNULL((SELECT um.LanguageId FROM TCD.UserMaster um WHERE um.UserId=@UserId),(SELECT p.LanguageId FROM TCD.Plant p WHERE p.EcolabAccountNumber=@EcolabAccountNumber)) 


--------------------------------------
-- StorageTanks---
--------------------------------------

INSERT INTO #tmpTagManagementDetails(Id, TagAddress,    [Description],    [Value],    LastModifiedTime,colName,DataType,RowNumber,OriginalColumnName
	,EntityType,TagType,ControllerEquipmentSetupId,SortingOrder)

----------------------------------------------------------------
-- Conventional-AND-Tunnel(AWEA, EOF, MODE to be displayed)-----
----------------------------------------------------------------
SELECT ms.WasherId, wt.TagAddress,Convert(varchar(100),w.PlantWasherNumber)+' : '+ms.MachineName,Convert(varchar(100), CONVERT(int, w.EndOfFormula)),w.LastModifiedTime ,'EndofFormulaNumber',tt.DataType,1,
'EndOfFormula' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType,ms.MachineInternalId as ControllerEquipmentSetupId, 2 as SortingOrder 
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId) AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_EOF' AND ms.IsTunnel IN (0,1)
UNION

SELECT ms.WasherId, wt.TagAddress,Convert(varchar(100),w.PlantWasherNumber)+' : '+ms.MachineName,Convert(varchar(100), CONVERT(int, w.WasherMode)),w.LastModifiedTime ,'WasherMode',tt.DataType,1
,'WasherMode' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType,ms.MachineInternalId as ControllerEquipmentSetupId, 5 as SortingOrder  
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_MODE' AND ms.IsTunnel IN (0,1)
UNION

SELECT ms.WasherId, wt.TagAddress,Convert(varchar(100),w.PlantWasherNumber)+' : '+ms.MachineName,Convert(varchar(100), CONVERT(int, w.AWEActive)),w.LastModifiedTime ,'AWEActive',tt.DataType,1
,'AWEActive' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType,ms.MachineInternalId as ControllerEquipmentSetupId , 1 as SortingOrder 
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_AWEA' AND ms.IsTunnel IN (0,1)
UNION

SELECT ms.WasherId, wt.TagAddress,Convert(varchar(100),w.PlantWasherNumber)+' : '+ms.MachineName,Convert(varchar(100), CONVERT(int, w.HoldDelay)),w.LastModifiedTime ,'HoldDelay',tt.DataType,1
,'HoldDelay' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType, ms.MachineInternalId as ControllerEquipmentSetupId , 3 as SortingOrder

FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId  AND wt.Active=@Active  AND wt.TagType='Tag_HOLDD' AND ms.IsTunnel=0 
UNION

SELECT ms.WasherId, wt.TagAddress,Convert(varchar(100),w.PlantWasherNumber)+' : '+ms.MachineName,Convert(varchar(100), CONVERT(int, w.WaterFlushTime)),w.LastModifiedTime , 'WaterFlushTime' ,tt.DataType,1
,'WaterFlushTime' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType, ms.MachineInternalId as ControllerEquipmentSetupId, 6 as SortingOrder  
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_FLSHT' AND ms.IsTunnel=0
UNION

SELECT ms.WasherId, wt.TagAddress,Convert(varchar(100),w.PlantWasherNumber)+' : '+ms.MachineName,Convert(varchar(100), CONVERT(int, w.RatioDosingActive)),w.LastModifiedTime, 'RatioDosingActive',tt.DataType,1
,'RatioDosingActive' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType, ms.MachineInternalId as ControllerEquipmentSetupId, 4 as SortingOrder  
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_RATA' AND ms.IsTunnel=0

UNION
------------------------------------
---- Tanks---
------------------------------------
SELECT ts.TankId AS Id, mt.TagAddress AS TagAddress,   ts.TankName AS [Description],Convert(varchar(10),Convert(int,( ts.Size))) AS Value,   
ts.LastModifiedTime , 'Size',tt.DataType,1
,'Size-Size_Display' as OriginalColumnName,'[TCD].[TankSetup]' as EntityName,tt.TagType as TagType, 0 as ControllerEquipmentSetupId  , 0 as SortingOrder

FROM   TCD.ModuleTags mt INNER JOIN TCD.TankSetup ts ON ts.TankId=mt.ModuleId
Inner Join tcd.TagType tt on mt.TagType = tt.TagType

WHERE   mt.ModuleTypeId=@TankModuleTypeId    AND ts.ControllerId=@ControllerId     AND mt.Active=@Active    AND mt.TagType='Tag_SIZ' 
UNION

SELECT ts.TankId,mt.TagAddress,ts.TankName,Convert(varchar(100),Convert(int,( ts.LevelDeviation_Display))),ts.LastModifiedTime ,'Dead Band',tt.DataType,1
,'LevelDeviation-LevelDeviation_Display' as OriginalColumnName,'[TCD].[TankSetup]' as EntityName,tt.TagType as TagType, 0 as SortingOrder, 0 as ControllerEquipmentSetupId  

FROM    TCD.ModuleTags mt 
INNER JOIN  TCD.TankSetup ts ON ts.TankId=mt.ModuleId
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE   mt.ModuleTypeId=@TankModuleTypeId 
	AND ts.ControllerId=@ControllerId 
	AND mt.Active=@Active 
	AND mt.TagType='Tag_DEV' 
UNION
----------------------------------------
---- Meter---
----------------------------------------

----------------------------------------
---- Sensor---
----------------------------------------
SELECT s.SensorId,mt.TagAddress,s.[Description],CONVERT(VARCHAR(100),CAST(s.Calibration4mA as float)),s.LastModifiedTime ,'Calibration4mA',tt.DataType,3
,'Calibration4mA' as OriginalColumnName,'[TCD].[Sensor]' as EntityName,tt.TagType as TagType, 0 as ControllerEquipmentSetupId, 0 as SortingOrder  
from TCD.ModuleTags mt INNER JOIN TCD.Sensor s ON MT.ModuleId=s.SensorId 
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE mt.ModuleTypeId=@SensorModuleTypeId AND s.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_SC4'

UNION

SELECT s.SensorId,mt.TagAddress,s.[Description],CONVERT(VARCHAR(100),CAST(s.Calibration20mA as float)),s.LastModifiedTime , 'Calibration20mA',tt.DataType,3
,'Calibration20mA' as OriginalColumnName,'[TCD].[Sensor]' as EntityName,tt.TagType as TagType, 0 as ControllerEquipmentSetupId, 0 as SortingOrder  
from TCD.ModuleTags mt INNER JOIN TCD.Sensor s ON MT.ModuleId=s.SensorId 
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE mt.ModuleTypeId=@SensorModuleTypeId AND s.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_SC20' 
UNION
--------------------------------------
-- Pumps---
--------------------------------------



SELECT  Convert(int, ces.ControllerEquipmentSetupId), mt.TagAddress,'P/V'+Convert(varchar(100), ces.ControllerEquipmentId),
Convert(varchar(100),Convert(float, ces.KFactor * @FactorMultiplier)),ces.LastModifiedTime ,'K-Factor',tt.DataType,2
,'KFactor' as OriginalColumnName,'[TCD].[ControllerEquipmentSetup]' as EntityName,tt.TagType as TagType, ControllerEquipmentId as ControllerEquipmentSetupId, 1 as SortingOrder   

FROM TCD.ModuleTags mt INNER JOIN TCD.ControllerEquipmentSetup ces ON mt.ModuleId=ces.ControllerEquipmentSetupId 
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE mt.ModuleTypeId=@PumpModuleTypeId AND ces.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_PPOL'
UNION
SELECT  Convert(int, ces.ControllerEquipmentSetupId), mt.TagAddress,'P/V'+Convert(varchar(100), ces.ControllerEquipmentId),
Convert(varchar(100),Convert(float, ces.PumpCalibration *@TimeVolumeMultipler)),ces.LastModifiedTime, 'Time Volume Calibration',tt.DataType,2
,'PumpCalibration' as OriginalColumnName,'[TCD].[ControllerEquipmentSetup]' as EntityName,tt.TagType as TagType , ControllerEquipmentId as  ControllerEquipmentSetupId, 3 as SortingOrder 
FROM TCD.ModuleTags mt INNER JOIN TCD.ControllerEquipmentSetup ces ON mt.ModuleId=ces.ControllerEquipmentSetupId
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE mt.ModuleTypeId=@PumpModuleTypeId AND ces.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_OPSL'
UNION

SELECT Convert(int, ces.ControllerEquipmentSetupId), mt.TagAddress,'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
ces.LfsChemicalName,ces.LastModifiedTime ,'LFS Chemical Name',tt.DataType,2
,'LfsChemicalName' as OriginalColumnName,'[TCD].[ControllerEquipmentSetup]' as EntityName,tt.TagType as TagType, ControllerEquipmentId as ControllerEquipmentSetupId  , 2 as SortingOrder 

FROM TCD.ModuleTags mt INNER JOIN TCD.ControllerEquipmentSetup ces ON mt.ModuleId=ces.ControllerEquipmentSetupId
Inner Join tcd.TagType tt on mt.TagType = tt.TagType 
WHERE mt.ModuleTypeId=@PumpModuleTypeId AND ces.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_NML' 
UNION

SELECT csd.ControllerId ,ct.TagAddress,NULL,csd.[Value],cc.LastModifiedTime , f.Label,tt.DataType,6
,'Value-'+CAST(csd.FieldId as varchar) as OriginalColumnName,'[TCD].[ControllerSetupData]' as EntityName,tt.TagType as TagType, 0 as ControllerEquipmentSetupId  , 0 as SortingOrder
FROM TCD.ControllerTags ct 
INNER JOIN TCD.ControllerSetupData csd ON csd.ControllerId = ct.ControllerId
INNER JOIN tcd.Field f ON f.Id = csd.FieldId AND ct.TagType=f.HasFieldTag
INNER JOIN TCD.ConduitController cc ON cc.ControllerId = ct.ControllerId
Inner Join tcd.TagType tt on ct.TagType = tt.TagType
WHERE ct.ControllerId=@ControllerId AND ct.Active=@Active

UNION

SELECT ces.ControllerEquipmentSetupId,
	   'stMachineConfig.xFlowSwitchType['+cast(ControllerEquipmentId AS varchar(20))+']' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  cast( FlowDetectorType AS varchar(20)) AS Value, 
	   ces.LastModifiedTime,
	   'Flow Detector Type' AS Lable,
	   'BIT' As DataType ,
	   2.1,
	   'FlowDetectorType' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
	'stMachineConfig.xFlowSwitchType' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 5 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3


UNION --Flow Switch Alarm
SELECT ces.ControllerEquipmentSetupId,
	   'stMachineConfig.xFlowAlarmOverride['+cast(ControllerEquipmentId AS varchar(20))+']' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  Cast( ces.FlowSwitchAlarm  AS varchar(20)) AS Value, 
	   ces.LastModifiedTime,
	   'Flow Switch Alarm' AS Lable,
	   'BIT' As DataType ,
	   2.2,
	   'FlowSwitchAlarm' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
	'stMachineConfig.xFlowAlarmOverride' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId , 10 as SortingOrder 
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3
UNION --Flow Meter Alarm
SELECT ces.ControllerEquipmentSetupId,
	   'stMachineConfig.xFlowMeterAlarmOverride['+cast(ControllerEquipmentId AS varchar(20))+']' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	 cast(  ces.FlowMeterAlarm  AS varchar(20)) AS Value, 
	   ces.LastModifiedTime,
	   'Flow Meter Alarm' AS Lable,
	   'BIT' As DataType ,
	   2.3,
	   'FlowMeterAlarm' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
	'stMachineConfig.xFlowMeterAlarmOverride' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 6 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3
UNION --Flow Meter Type
	 
SELECT ces.ControllerEquipmentSetupId,
	   'stPumpConfig['+cast(ControllerEquipmentId AS varchar(20))+'].eFlowMeterMode' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  cast( ces.FlowMeterType  AS varchar(20))  AS Value, 
	   ces.LastModifiedTime,
	   'Flow Meter Type' AS Lable,
	   'INT' As DataType ,
	   2.4,
	   'FlowMeterType' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
	'stPumpConfig.eFlowMeterMode' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 9 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3

UNION --Flow Alarm Delay Time
SELECT ces.ControllerEquipmentSetupId,
	   'stPumpConfig['+cast(ControllerEquipmentId AS varchar(20))+'].fLossOfFlowDuration' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  cast( ces.FlowAlarmDelay  AS varchar(20))  AS Value, 
	   ces.LastModifiedTime,
	   'Flow Alarm Delay Time' AS Lable,
	   'FLOAT' As DataType ,
	   2.5,
	   'FlowAlarmDelay' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
	'stPumpConfig.fLossofFlowDuration' TagType, ces.ControllerEquipmentId  as ControllerEquipmentSetupId, 4 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3
UNION --Flow Meter Pump Delay
SELECT ces.ControllerEquipmentSetupId,
	   'stPumpConfig['+cast(ControllerEquipmentId AS varchar(20))+'].fTdFlowMeter' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  cast( ces.FlowMeterPumpDelay  AS varchar(20))  AS Value, 
	   ces.LastModifiedTime,
	   'Flow Meter Pump Delay' AS Lable,
	   'FLOAT' As DataType ,
	   2.6,
	   'FlowMeterPumpDelay' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
	'stPumpConfig.fTdFlowMeter' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 8 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3

UNION -- Flow Meter Alarm Delay
SELECT ces.ControllerEquipmentSetupId,
	   'stPumpConfig['+cast(ControllerEquipmentId AS varchar(20))+'].fTAlarmDelayFlowMeter' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  cast( ces.FlowMeterAlarmDelay  AS varchar(20))  AS Value, 
	   ces.LastModifiedTime,
	   'Flow Meter Alarm Delay' AS Lable,
	   'FLOAT' As DataType ,
	   2.7,
	   'FlowMeterAlarmDelay' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
	'stPumpConfig.fTAlarmDelayFlowMeter' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 7 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3



SELECT  ttmd.Id  
   ,ttmd.TagAddress  
   ,isnull(ttmd.[Description],'')
   ,ttmd.Value  
   ,ttmd.LastModifiedTime  
   ,ttmd.ColName
   ,ttmd.DataType
   ,ttmd.OriginalColumnName
	,ttmd.EntityType 
	,ttmd.TagType,ttmd.SortingOrder,ttmd.ControllerEquipmentSetupId  FROM dbo.#tmpTagManagementDetails ttmd WHERE ttmd.[Value] IS  NOT NULL AND ttmd.[Value]<> '' ORDER BY ttmd.RowNumber

END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetRedFlagDetails]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetRedFlagDetails]
END
GO 

CREATE PROCEDURE [TCD].[GetRedFlagDetails]
(
		@Id INT = NULL
	,	@EcolabAccountNumber VARCHAR(1000) 
)
AS
BEGIN
SET NOCOUNT ON;

DECLARE @PlantId INT,@RegionId int ,@LanguageId int,@UOMEndPart varchar(100),@UOM7 nvarchar(1000), @UOM8 nvarchar(1000)
 SELECT @PlantId=PlantId ,@RegionId=RegionId,@LanguageId=LanguageId
		FROM TCD.Plant 
		WHERE EcolabAccountNumber=@EcolabAccountNumber
IF(@RegionId=1)
BEGIN
	SET @UOMEndPart='CWT'
END
ELSE
BEGIN
	SET @UOMEndPart='kg'
END

SELECT @UOM7 = rkv.[Value]
FROM TCD.Meter m 
LEFT JOIN tcd.ResourceKeyValue rkv on m.MeterTickUnit=rkv.KeyName and LanguageId=@LanguageId
WHERE m.GroupId IS NULL AND m.UtilityType in (1,2)

SELECT @UOM8 = rkv.[Value]
FROM TCD.Meter m 
LEFT JOIN tcd.ResourceKeyValue rkv on m.MeterTickUnit=rkv.KeyName and LanguageId=@LanguageId
WHERE m.GroupId IS NULL AND m.UtilityType IN(1)

SELECT
		PR.Id
	,	ItemID = PR.Item
	,	IL.ItemName 
	,	PR.MinimumRange
	,	PR.MaximumRange
	,	
		(CASE WHEN PR.Item IN (7,8) THEN (CASE WHEN isnull( PR.MeterId,0) !=0 then   rkv.[Value] +'/'+@UOMEndPart 
												WHEN PR.Item =7 THEN @UOM7 +'/'+@UOMEndPart 
												WHEN PR.Item =8 THEN @UOM8 +'/'+@UOMEndPart 
											END )
				ELSE (CASE @RegionId WHEN 1 THEN IL.UOMNA WHEN 2 THEN IL.UOMEurope END) 
			END) AS UOM
	,	LocationID = PR.Location
	,	CASE WHEN GT.Is_Deleted = 0 THEN GT.GroupDescription ELSE CAST('' AS NVARCHAR) END  AS LocationName
	,	PR.EcolabAccountNumber
	,	(SELECT STUFF((select DISTINCT ','+ CAST(IsNull(MachineId,-1) AS VARCHAR(1000)) from [TCD].RedFlagMappingData MD WHERE MD.MappingID = PR.ID AND MD.Is_Deleted = 0 FOR XML PATH('')  ) ,1,1,'')) as MachineID
	,	(SELECT LTRIM(ISNULL(STUFF((select DISTINCT ', '+
			(SELECT
				CASE WHEN( SELECT DISTINCT Istunnel FROM [TCD].machinesetup S WHERE S.groupId = PR.Location AND S.Washerid = MD.MachineId)= 1 THEN
					CASE WHEN (SELECT RD.MachineId FROM [TCD].RedFlag MM INNER JOIN [TCD].RedFlagMappingData RD ON MM.Id = RD.MappingId WHERE RD.MachineId = MD.MachineId AND RD.MachineId = 0 AND RD.Is_Deleted = 0) = 0 THEN 'Press'
					ELSE
						CASE WHEN(SELECT TOP 1 MS.IsDeleted FROM TCD.MachineSetup MS WHERE MS.GroupId = PR.Location AND MS.WasherId = MD.MachineId AND  MS.IsDeleted=0 ) IS NOT NULL THEN (SELECT TOP(1) CAST(WS.PlantWasherNumber AS nvarchar)+':'+MS.MachineName FROM TCD.MachineSetup MS INNER JOIN TCD.Washer WS ON MS.WasherId = WS.WasherId WHERE MS.GroupId = PR.Location AND MS.WasherId = MD.MachineId) ELSE '0' END
					END
				WHEN( SELECT DISTINCT Istunnel FROM [TCD].machinesetup S WHERE S.groupId = PR.Location AND S.Washerid = MD.MachineId)= 0 THEN ISNULL((SELECT TOP(1) CAST(WS.PlantWasherNumber AS nvarchar)+':'+MS.MachineName FROM TCD.MachineSetup MS INNER JOIN TCD.Washer WS ON MS.WasherId = WS.WasherId WHERE MS.GroupId = PR.Location AND MS.WasherId = MD.MachineId AND  MS.IsDeleted =0),'0')
				WHEN (SELECT DISTINCT GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.Id = PR.Location ) = 3 THEN
				(SELECT Description FROM [TCD].Dryers D WHERE D.DryerGroupId = PR.Location AND D.DryerNo =  MD.MachineId AND D.Is_deleted = 0)
				WHEN (SELECT DISTINCT GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.Id = PR.Location ) = 4 THEN
				(SELECT Name FROM [TCD].Finnishers F WHERE F.FinnisherGroupId = PR.Location AND F.FinnisherNo =  MD.MachineId AND F.Is_deleted = 0)
			END)
		FROM 
		[TCD].RedFlagMappingData MD  
	WHERE 
	MD.MappingID = PR.ID 
	AND 
	MD.Is_Deleted = 0
		FOR XML PATH('')  ) ,1,1,''),'ALL'))) as MachineName
 , PR.RedFlagCategoryId AS CategoryId  
, PR.FormulaId AS FormulaId  
, PM.Name AS FormulaName     
, PR.ProductId   
, PRM.Name AS ProductName  
, isnull( PR.MeterId  ,s.SensorId) MeterId
, (CASE WHEN isnull( PR.MeterId,0)!=0 THEN ME.Description ELSE s.Description END)AS MeterName  
,PR.LastModifiedTime
,PR.LastSyncTime
,PR.Is_Deleted
,Pr.SensorId
FROM  
[TCD].RedFlag PR
INNER JOIN [TCD].RedFlagItemList IL ON PR.Item = IL.Id
LEFT JOIN TCD.WasherProgramSetup WPS ON WPS.WasherGroupId = PR.Location AND WPS.WasherProgramSetupId = PR.FormulaId AND WPS.Ecolabaccountnumber = @Ecolabaccountnumber
LEFT JOIN TCD.TunnelProgramSetup TPS ON TPS.WasherGroupId = PR.Location AND TPS.TunnelProgramSetupId = PR.FormulaId AND TPS.Ecolabaccountnumber = @Ecolabaccountnumber
LEFT JOIN tcd.ProgramMaster AS PM ON PM.ProgramId = (CASE WHEN WPS.WasherProgramSetupId IS NOT NULL THEN WPS.ProgramId ELSE TPS.ProgramId END) --Identify whether its tunnel or washer formula
LEFT JOIN TCD.ProductMaster AS PRM ON PRM.ProductId = PR.ProductId   
LEFT JOIN TCD.Meter AS ME ON ME.MeterId = PR.MeterId AND ME.EcolabAccountNumber = @Ecolabaccountnumber 
LEFT JOIN TCD.RedFlagCategory AS RFC ON RFC.RedFlagCategoryId = PR.RedFlagCategoryId   
INNER JOIN [TCD].MachineGroup GT ON PR.Location = GT.Id  
LEFT JOIN tcd.ResourceKeyValue rkv on ME.MeterTickUnit=rkv.KeyName and LanguageId=@LanguageId
LEFT JOIN TCD.Sensor s ON s.SensorId = PR.SensorId
WHERE 
PR.PlantId = @PlantId
AND 
PR.Is_Deleted=0 
--AND GT.Is_Deleted = 0
AND 
CASE ISNULL(@Id,'') WHEN '' THEN 'TRUE' ELSE CASE WHEN PR.Id = @Id THEN 'TRUE' END END = 'TRUE'
SET NOCOUNT OFF;
END
GO


IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetControllerSetupAdvanceMetaDataWithValues]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetControllerSetupAdvanceMetaDataWithValues
	END
GO 
CREATE PROCEDURE [TCD].[GetControllerSetupAdvanceMetaDataWithValues]
(
		@TabId INT
	,	@ControllerId INT
	,	@EcolabAccountNumber VARCHAR(1000)
 )
AS
BEGIN  
SET NOCOUNT ON
	IF OBJECT_ID('tempdb..#tmpMetaDataAdvance') IS NOT NULL
		DROP TABLE #tmpMetaDataAdvance
	DECLARE @AllowDefaultTagAddress BIT,
			@ControllerModelId NVARCHAR(50) = NULL;
	SELECT 
			@ControllerModelId = ControllerModelId
	FROM [TCD].ConduitController
	WHERE ControllerId = @ControllerId
		AND EcoalabAccountNumber = @EcolabAccountNumber
	IF NOT EXISTS(SELECT 
				1
			FROM TCD.ControllerTags
			WHERE ControllerId = @ControllerId
				AND EcolabAccountNumber = @EcolabAccountNumber)
		BEGIN
			SET @AllowDefaultTagAddress = 'TRUE';
		END;
	ELSE
		BEGIN
			SET @AllowDefaultTagAddress = 'FALSE';
		END;
	SELECT DISTINCT 
			FG.Id AS FieldGroupId
			,FG.[NAME] AS FieldGroupName
			,FG.[image_Url] as FieldGroupImageUrl
			,FG.[helpText] as FieldGroupHelpText
			,FG.[ControllerModelId]
			,FG.[ControllerTypeId]
			,FGT.NAME AS FieldGroupTypeName
			,F.Id AS FieldId
			,F.Name AS FieldName
			,FT.Name AS FieldType
			,F.Label AS FieldLabel
			,F.[Min] AS FieldMinValue
			,F.[Max] AS FieldMaxValue
			,F.IsMandatory AS FieldIsMandatory
			,F.IsEditable AS FieldIsEditable
			,F.HelpText AS FieldHelpText
			, F.HelpTextUrl AS FieldHelpUrl
			,FG.TabId AS TabIndex
			,DT.Name AS ControlType
			,F.DataSourceId AS DataSourceId
			,(SELECT 
						FS.Value + ':' + FS.Name + ';'
					FROM TCD.FieldSource FS
					WHERE FS.DataSourceId = F.DataSourceId
					FOR XML PATH( '' )
			)AS DataSourceKeyValue 
			,F.DataCategoryId AS DataCategoryId
			,F.DefaultValue
			,F.CurrencyId AS FieldCurrencyCode
			,F.ResourceKey AS FieldResourceKey
			,FG.ResourceKey AS FieldGroupResourceKey
			,FG.DisplayOrder AS FieldGroupDO
			,F.DisplayOrder AS FieldDO 
			,CSD.ControllerId
			,FRM.RoleId AS AccessToRole
			,F.HasFieldTag AS HasFieldTag
			, (
				SELECT 
						TagAddress
					FROM TCD.ControllerTags
					WHERE TagType = F.HasFieldTag
						AND ControllerId = @ControllerId
						AND Active = 1
						AND EcolabAccountNumber = @EcolabAccountNumber) AS TagDefaultValue
			,F.ClassName AS ClassName
			,CC.ControllerVersion
			,0 IsDosingLineConsumed
	INTO #tmpMetaDataAdvance
	FROM [TCD].[FieldGroup] FG
	INNER JOIN [TCD].[FieldGroupFieldMapping] FGFM ON FG.Id = FGFM.FieldGroupId
	INNER JOIN [TCD].[Field] F ON F.Id = FGFM.FieldId
	LEFT JOIN [TCD].[FieldGroupType] FGT ON FGT.Id = FG.FieldGroupTypeId
	LEFT JOIN [TCD].FieldType FT ON FT.Id = F.TypeId 
	LEFT JOIN [TCD].DataType DT ON DT.Id = F.DataTypeId
	LEFT JOIN [TCD].[FieldRoleMapping] FRM ON FRM.FieldId = F.Id

	INNER JOIN [TCD].[ConduitController] CC ON CC.ControllerModelId = FG.ControllerModelId AND CC.ControllerTypeId = FG.ControllerTypeId AND cc.EcoalabAccountNumber = @EcolabAccountNumber

	INNER JOIN [TCD].[ControllerSetupData] CSD ON CSD.ControllerId = CC.ControllerId AND CSD.EcolabAccountNumber = @EcolabAccountNumber
	WHERE 
	CC.ControllerId = @ControllerId
	AND
	FG.TabId = @TabId
	AND 
	CC.EcoalabAccountNumber = @EcolabAccountNumber
	AND F.Label NOT LIKE
			CASE @ControllerModelId
				WHEN 3 THEN 'Automatic Weight Enabled'
				ELSE  ''
			END
		AND F.Label NOT LIKE
			CASE @ControllerModelId
				WHEN 3 THEN  'Ratio Dosing Enabled'
				ELSE    ''
			END

	UPDATE tmd SET DefaultValue = CSD.Value
	 FROM #tmpMetaDataAdvance tmd
		INNER JOIN [TCD].ControllerSetupData CSD ON  tmd.ControllerId = CSD.ControllerId 
			AND CSD.EcolabAccountNumber = @EcolabAccountNumber
			AND tmd.FieldGroupId = CSD.FieldGroupId 
			AND tmd.FieldId = CSD.FieldId 


update MDA set IsDosingLineConsumed =1
FROM  #tmpMetaDataAdvance MDA
inner join [TCD].[ControllerEquipmentSetUp] CES on MDA.ControllerId=CES.ControllerId  and IsActive=1
where  LTRIM(rtrim( FieldResourceKey))='No_of_Pumps_Connected_to_TCR1' 
and CES.LineNumber >= 1 and CES.LineNumber <= (case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)
and CES.ControllerEquipmentId >= 1 and CES.ControllerEquipmentId <= (case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)

	
update MDA set IsDosingLineConsumed =1
FROM  #tmpMetaDataAdvance MDA
inner join [TCD].[ControllerEquipmentSetUp] CES on MDA.ControllerId=CES.ControllerId  and IsActive=1
where  LTRIM(rtrim( FieldResourceKey))='No_of_Pumps_Connected_to_TCR2' 
and CES.LineNumber >= (case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end) and CES.LineNumber <= ((case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)*2)
and CES.ControllerEquipmentId >= (case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end) and CES.ControllerEquipmentId <= ((case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)*2)

update MDA set IsDosingLineConsumed =1
FROM  #tmpMetaDataAdvance MDA
inner join [TCD].[ControllerEquipmentSetUp] CES on MDA.ControllerId=CES.ControllerId  and IsActive=1
where  LTRIM(rtrim( FieldResourceKey))='No_of_Pumps_Connected_to_TCR3' 
and CES.LineNumber >= ((case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)*2) and CES.LineNumber <= ((case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)*3)
and CES.ControllerEquipmentId >=  ((case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)*2) and CES.ControllerEquipmentId <= ((case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)*3)

update MDA set IsDosingLineConsumed = (select IsDosingLineConsumed from #tmpMetaDataAdvance where  LTRIM(rtrim( FieldResourceKey))='No_of_Pumps_Connected_to_TCR1' )
FROM  #tmpMetaDataAdvance MDA
where  LTRIM(rtrim( FieldResourceKey)) in( 'Dosing_Line_Mode1' ,'Enable_Auxiliary_pump1','Flow-meter_for_Flow_check1')

update MDA set IsDosingLineConsumed = (select IsDosingLineConsumed from #tmpMetaDataAdvance where  LTRIM(rtrim( FieldResourceKey))='No_of_Pumps_Connected_to_TCR2' )
FROM  #tmpMetaDataAdvance MDA
where  LTRIM(rtrim( FieldResourceKey)) in( 'Dosing_Line_Mode2','Enable_Auxiliary_pump2','meter_for_Flow_check2')

update MDA set IsDosingLineConsumed = (select IsDosingLineConsumed from #tmpMetaDataAdvance where  LTRIM(rtrim( FieldResourceKey))='No_of_Pumps_Connected_to_TCR3' )
FROM  #tmpMetaDataAdvance MDA
where  LTRIM(rtrim( FieldResourceKey)) in( 'Dosing_Line_Mode3','Enable_Auxiliary_pump3','meter_for_Flow_check3') 

	SELECT 
		CC.Name AS ControllerName
		,FieldGroupId
		,FieldGroupName
		,FieldGroupImageUrl
		,FieldGroupHelpText
		,#tmpMetaDataAdvance.ControllerModelId
		,#tmpMetaDataAdvance.ControllerTypeId
		,FieldGroupTypeName
		,FieldId
		,FieldName
		,FieldType
		,FieldLabel
		,FieldMinValue
		,FieldMaxValue
		,FieldIsMandatory
		,FieldIsEditable
		,FieldHelpText
		,FieldHelpUrl
		,TabIndex
		,ControlType
		,DataSourceId
		,DataSourceKeyValue
		,DataCategoryId
		,#tmpMetaDataAdvance.DefaultValue As DefaultValue
		,FieldCurrencyCode
		,FieldResourceKey
		,FieldGroupResourceKey
		,FieldGroupDO
		,FieldDO 
		,#tmpMetaDataAdvance.AccessToRole
		,'Edit' AS Mode
		,HasFieldTag
		,TagDefaultValue	
		,ClassName
		,#tmpMetaDataAdvance.ControllerVersion
		,CAST (IsDosingLineConsumed as bit) IsDosingLineConsumed
	FROM #tmpMetaDataAdvance
	INNER JOIN [TCD].ConduitController CC on #tmpMetaDataAdvance.ControllerId = CC.ControllerId  AND CC.EcoalabAccountNumber = @EcolabAccountNumber
	ORDER BY FieldGroupDO , FieldDO, FieldId 
SET NOCOUNT OFF
END
GO

IF EXISTS(SELECT
				  1
			  FROM sys.columns
			  WHERE Name = N'LastModifiedByUserId'
				AND Object_ID = OBJECT_ID(N'[TCD].[FormulaSegments]'))
	BEGIN
		ALTER TABLE TCD.FormulaSegments DROP COLUMN LastModifiedByUserId
	END

	Go


/*Insert the new segment Industrial into formulasegments*/
IF NOT  EXISTS (SELECT * FROM tcd.FormulaSegments fs WHERE fs.SegmentName = 'Industrial')
BEGIN
INSERT INTO tcd.FormulaSegments
(
	--FormulaSegmentID - this column value is auto-generated
	TCD.FormulaSegments.SegmentName,
	TCD.FormulaSegments.LastModifiedTime,
	TCD.FormulaSegments.Is_Deleted
)
VALUES
(
	-- FormulaSegmentID - int
	'Industrial', -- SegmentName - varchar
	GETDATE(), -- LastModifiedTime - datetime
	0 -- Is_Deleted - bit
)
END 
GO


			--Declare temp table variable to hold input data
		DECLARE	@tempWasherMode									TABLE	(
				TempId											INT				IDENTITY(1, 1)
			,	WasherModeId									TINYINT			NOT	NULL
			,	WasherModeName									NVARCHAR(200)	NOT	NULL
			,	ResourceKey										NVARCHAR(200)	NULL

			,	UNIQUE	(WasherModeId)
			)

			--Populate temp table variable with the input data
		INSERT	@tempWasherMode	(WasherModeId	,WasherModeName,	ResourceKey	)
		VALUES
		 (0, N'Off', N'FIELD_OFF')
		,(1, N'Binary', N'FIELD_BINARY')
		,(2, N'Timed', N'FIELD_TIMED')
		,(3, N'Timed & Binary', N'FIELD_TIMED&BINARY')
		,(4, N'Timed & Timed', N'FIELD_TIMED&TIMED')	
		,(5, N'10''s and 1''s T & T', N'FIELD_10SAND1STANDT')
		,(6, N'Prg = Binary , Step = One Signal , Start generated by first Step', N'FIELD_PRGBINARYSTEPONESIGNALSTARTGENERATEDBYFIRSTSTEP')
		,(7, N'Prg and Start = Miniterminal , Step = One Signal', N'FIELD_PRGANDSTARTMINITERMINALSTEPONESIGNAL')
		,(8, N'Prg = Miniterminal , Step = One Signal , Start generated by first Step', N'FIELD_PRGMINITERMINALSTEPONESIGNALSTARTGENERATEDBYFIRSTSTEP')
		,(9, N'Prg = Miniterminal , Step = Binary , Start generated by first Step', N'FIELD_PRGMINITERMINALSTEPBINARYSTARTGENERATEDBYFIRSTSTEP')
		,(10, N'Prg and Start = Binary , Step = One Signal , Start not generated by first Step', N'FIELD_PRGANDSTARTBINARYSTEPONESIGNALSTARTNOTGENERATEDBYFIRSTSTEP')
		,(11, N'TOM mode only', N'FIELD_TOMMODEONLY')
		,(12, N'Prg = Binary, Step = Binary', N'FIELD_PRGBINARYSTEPBINARY')
		,(13, N'Prg = Miniterminal , Step = One Signal', N'FIELD_PRGMINITERMINALSTEPONESIGNAL')
		,(14, N'Prg = Miniterminal , Step = Binary', N'FIELD_PRGMINITERMINALSTEPBINARY')	
		,(15, N'Prg and Start = Binary , Step = One Signal , Start generate first Step', N'FIELD_PRGANDSTARTBINARYSTEPONESIGNALSTARTGENERATEDBYFIRSTSTEP')
		,(16, N'Prg = Binary , Step = One Signal , Start generated by first Step', N'FIELD_PRGBINARYSTEPONESIGNALSTARTGENERATEDBYFIRSTSTEP')
		,(17, N'Prg = WTC-Selector , Step = One Signal , Start generated by first Step', N'FIELD_PRGWTCSELECTORSTEPONESIGNALSTARTGENERATEDBYFIRSTSTEP')
		,(18, N'Prg and Start = WTC-Selector , Step = One Signal', N'FIELD_PRGANDSTARTWTCSELECTORSTEPONESIGNAL')
		,(19, N'Prg = WTC-Selector , Step = Binary , Start generated by firs Step', N'FIELD_PRGWTCSELECTORSTEPBINARYSTARTGENERATEDBYFIRSTSTEP')
		,(20, N'Program = Binary, Transfer conveyor = Transfer Tunnel', N'FIELD_PROGRAMBINARYTRANSFERCONVEYORTRANSFERTUNNEL')
		,(21, N'Program = Miniterminal, Transfer conveyor = Miniterminal', N'FIELD_PROGRAMMINITERMINALTRANSFERCONVEYORMINITERMINAL')
		,(22, N'Program = Binary, Transfer conveyor = Dedicated input', N'FIELD_PROGRAMBINARYTRANSFERCONVEYORDEDICATEDINPUT')
		,(23, N'Program = Miniterminal, Transfer conveyor = Transfer Tunnel', N'FIELD_PROGRAMMINITERMINALTRANSFERCONVEYORTRANSFERTUNNEL')
		,(24, N'Program = Miniterminal, Transfer conveyor = Dedicated input', N'FIELD_PROGRAMMINITERMINALTRANSFERCONVEYORDEDICATEDINPUT')
		,(25, N'Carbonell', N'FIELD_CARBONELL')
		,(26, N'Kannegiesser Ethernet communication', N'FIELD_KANNEGIESSERETHERNETCOMMUNICATION')
		,(27, N'Senking Ethernet communication', N'FIELD_SENKINGETHERNETCOMMUNICATION')
		,(28, N'Program = Miniterminal (including program 0), Transfer conveyor = Miniterminal', N'FIELD_PROGRAMMINITERMINALINCLUDINGPROGRAM0TRANSFERCONVEYORMINITERMINAL')
		,(29, N'10''s 1''s and 100''s', N'FIELD_10S1SAND100S');
		MERGE	TCD.[WasherMode]				AS			TARGET
		USING	@tempWasherMode					AS			SOURCE
			ON	TARGET.WasherModeId								=			SOURCE.WasherModeId
		WHEN	NOT MATCHED		THEN
				INSERT	(WasherModeId			,WasherModeName			,ResourceKey		)
				VALUES	(SOURCE.WasherModeId	,SOURCE.WasherModeName	,SOURCE.ResourceKey	)
		WHEN MATCHED THEN
		    UPDATE SET WasherModeId = SOURCE.WasherModeId
			      ,WasherModeName = SOURCE.WasherModeName
			      ,ResourceKey = SOURCE.ResourceKey;
				  
DECLARE	@TableName	nvarchar(100)			=			'WasherModeMapping'
		PRINT @TableName

		--Declare temp table variable to hold input data
		DECLARE	@tempWasherModeMapping									TABLE	(
				TempId											INT				IDENTITY(1, 1)
			,	ControllerTypeModelToWasherModeId				SMALLINT		NOT	NULL
			,	ControllerModelControllerTypeMappingId			int				NOT	NULL
			,	WasherModeId									int				NULL
			,	WasherModeNumber								TINYINT			NULL
			,	WasherType										nchar(20)		NULL
			,	UNIQUE	(ControllerTypeModelToWasherModeId)
			)

		--Populate temp table variable with the input data
		INSERT	@tempWasherModeMapping	(ControllerTypeModelToWasherModeId	,ControllerModelControllerTypeMappingId	,WasherModeId ,WasherModeNumber ,WasherType)
		VALUES
		 (1, 1, 0, 0, 'C')
		,(2, 1, 1, 1, 'C')
		,(3, 1, 2, 2, 'C')
		,(4, 1, 3, 3, 'C')
		,(5, 1, 4, 4, 'C')
		,(6, 2, 0, 0, 'C')
		,(7, 2, 1, 1, 'C')
		,(8, 2, 2, 2, 'C')
		,(9, 2, 3, 3, 'C')
		,(10, 2, 4, 4, 'C')
		,(11, 2, 5, 5, 'C')
		,(12, 3, 0, 0, 'C')
		,(13, 3, 1, 1, 'C')
		,(14, 3, 2, 2, 'C')
		,(15, 3, 3, 3, 'C')
		,(16, 3, 4, 4, 'C')
		,(17, 4, 0, 0, 'C')
		,(18, 4, 1, 1, 'C')
		,(19, 4, 2, 2, 'C')
		,(20, 4, 3, 3, 'C')
		,(21, 4, 4, 4, 'C')
		,(22, 4, 5, 5, 'C')
		,(23, 5, 0, 0, 'T')
		,(24, 5, 1, 1, 'T')
		,(25, 5, 2, 2, 'T')
		,(26, 5, 29, 4, 'T')
		,(27, 5, 4, 5, 'T')
		,(28, 10, 0, 0, 'C')
		,(29, 10, 6, 1, 'C')
		,(30, 10, 7, 2, 'C')
		,(31, 10, 8, 3, 'C')
		,(32, 10, 9, 4, 'C')
		,(33, 10, 10, 5, 'C')
		,(34, 10, 11, 6, 'C')
		,(35, 10, 0, 0, 'T')
		,(36, 10, 20, 1, 'T')
		,(37, 10, 21, 2, 'T')
		,(38, 10, 22, 3, 'T')
		,(39, 10, 23, 4, 'T')
		,(40, 10, 24, 5, 'T')
		,(41, 10, 25, 6, 'T')
		,(42, 10, 26, 7, 'T')
		,(43, 11, 0, 0, 'C')
		,(44, 11, 15, 1, 'C')
		,(45, 11, 7, 2, 'C')
		,(46, 11, 8, 3, 'C')
		,(47, 11, 9, 4, 'C')
		,(48, 11, 16, 5, 'C')
		,(49, 11, 17, 6, 'C')
		,(50, 11, 18, 7, 'C')
		,(51, 11, 10, 8, 'C')
		,(52, 11, 11, 9, 'C')
		,(53, 12, 0, 0, 'C')
		,(54, 12, 15, 1, 'C')
		,(55, 12, 7, 2, 'C')
		,(56, 12, 8, 3, 'C')
		,(57, 12, 9, 4, 'C')
		,(58, 12, 16, 5, 'C')
		,(59, 12, 17, 6, 'C')
		,(60, 12, 18, 7, 'C')
		,(61, 12, 10, 8, 'C')
		,(62, 12, 11, 9, 'C')
		,(63, 12, 19, 0, 'T')
		,(64, 12, 20, 1, 'T')
		,(65, 12, 21, 2, 'T')
		,(66, 12, 22, 3, 'T')
		,(67, 12, 23, 4, 'T')
		,(68, 13, 0, 0, 'C')
		,(69, 13, 15, 1, 'C')
		,(70, 13, 7, 2, 'C')
		,(71, 13, 8, 3, 'C')
		,(72, 13, 9, 4, 'C')
		,(73, 13, 16, 5, 'C')
		,(74, 13, 17, 6, 'C')
		,(75, 13, 18, 7, 'C')
		,(76, 13, 10, 8, 'C')
		,(77, 13, 11, 9, 'C')
		,(78, 14, 0, 0, 'C')
		,(79, 14, 15, 1, 'C')
		,(80, 14, 7, 2, 'C')
		,(81, 14, 8, 3, 'C')
		,(82, 14, 9, 4, 'C')
		,(83, 14, 16, 5, 'C')
		,(84, 14, 17, 6, 'C')
		,(85, 14, 18, 7, 'C')
		,(86, 14, 10, 8, 'C')
		,(87, 14, 11, 9, 'C')
		,(88, 15, 0, 0, 'C')
		,(89, 15, 15, 1, 'C')
		,(90, 15, 7, 2, 'C')
		,(91, 15, 8, 3, 'C')
		,(92, 15, 9, 4, 'C')
		,(93, 15, 16, 5, 'C')
		,(94, 15, 17, 6, 'C')
		,(95, 15, 18, 7, 'C')
		,(96, 15, 10, 8, 'C')
		,(97, 15, 11, 9, 'C')
		,(98, 15, 19, 0, 'T')
		,(99, 15, 20, 1, 'T')
		,(100, 15, 21, 2, 'T')
		,(101, 15, 22, 3, 'T')
		,(102, 15, 23, 4, 'T')
		,(103, 16, 0, 0, 'C')
		,(104, 16, 15, 1, 'C')
		,(105, 16, 7, 2, 'C')
		,(106, 16, 8, 3, 'C')
		,(107, 16, 9, 4, 'C')
		,(108, 16, 16, 5, 'C')
		,(109, 16, 17, 6, 'C')
		,(110, 16, 18, 7, 'C')
		,(111, 16, 10, 8, 'C')
		,(112, 16, 11, 9, 'C')
		,(113, 16, 19, 0, 'T')
		,(114, 16, 20, 1, 'T')
		,(115, 16, 21, 2, 'T')
		,(116, 16, 22, 3, 'T')
		,(117, 16, 23, 4, 'T')
		,(118, 17, 0, 0, 'C')
		,(119, 17, 15, 1, 'C')
		,(120, 17, 7, 2, 'C')
		,(121, 17, 8, 3, 'C')
		,(122, 17, 9, 4, 'C')
		,(123, 17, 16, 5, 'C')
		,(124, 17, 17, 6, 'C')
		,(125, 17, 18, 7, 'C')
		,(126, 17, 10, 8, 'C')
		,(127, 18, 10, 0, 'C')
		,(128, 18, 12, 1, 'C')
		,(129, 18, 13, 2, 'C')
		,(130, 18, 14, 3, 'C')
		,(131, 18, 7, 4, 'C')
		,(132, 19, 10, 0, 'C')
		,(133, 19, 12, 1, 'C')
		,(134, 19, 13, 2, 'C')
		,(135, 19, 14, 3, 'C')
		,(136, 19, 7, 4, 'C')
		,(137, 19, 19, 0, 'T')
		,(138, 19, 20, 1, 'T')
		,(139, 19, 21, 2, 'T')
		,(140, 19, 22, 3, 'T')
		,(141, 19, 23, 4, 'T')
		,(142, 19, 25, 5, 'T')
		,(143, 19, 26, 6, 'T')
		,(144, 19, 27, 7, 'T')
		,(145, 19, 24, 8, 'T')
		,(146, 20, 19, 0, 'T')
		,(147, 20, 20, 1, 'T')
		,(148, 20, 21, 2, 'T')
		,(149, 20, 22, 3, 'T')
		,(150, 20, 23, 4, 'T')
		,(151, 20, 25, 5, 'T')
		,(152, 20, 26, 6, 'T')
		,(153, 20, 27, 7, 'T')
		,(154, 20, 24, 8, 'T')
		,(155, 22, 0, 0, 'T')
		,(156, 22, 1, 1, 'T')
		,(157, 22, 2, 2, 'T')
		,(158, 22, 3, 3, 'T')
		,(159, 22, 29, 4, 'T')
		MERGE	TCD.[WasherModeMapping]				AS			TARGET
		USING	@tempWasherModeMapping					AS			SOURCE
			ON	TARGET.ControllerTypeModelToWasherModeId			=			SOURCE.ControllerTypeModelToWasherModeId
		WHEN	NOT MATCHED		THEN
				INSERT	(ControllerTypeModelToWasherModeId			,ControllerModelControllerTypeMappingId			,WasherModeId, 		WasherModeNumber, WasherType)
				VALUES	(SOURCE.ControllerTypeModelToWasherModeId	,SOURCE.ControllerModelControllerTypeMappingId	,SOURCE.WasherModeId, SOURCE.WasherModeNumber, 	SOURCE.WasherType)
		WHEN	MATCHED	    THEN
				UPDATE SET
					ControllerTypeModelToWasherModeId = SOURCE.ControllerTypeModelToWasherModeId
					,	ControllerModelControllerTypeMappingId = SOURCE.ControllerModelControllerTypeMappingId
				,	WasherModeId = SOURCE.WasherModeId
				,	WasherModeNumber = SOURCE.WasherModeNumber
				,	WasherType = SOURCE.WasherType;
GO

DELETE FROM TCD.WasherModeMapping WHERE ControllerTypeModelToWasherModeId = 27
GO


/****** Object:  Table [TCD].[ModuleReading]    Script Date: 02/24/2016 14:13:47 ******/
/**
Added Three coloumns to ModuleReading Table
**/

IF NOT EXISTS(SELECT * FROM sys.columns
WHERE Name = N'PlantId' AND OBJECT_ID = OBJECT_ID(N'[TCD].[ModuleReading]'))
BEGIN 
ALTER TABLE [TCD].[ModuleReading] 
ADD [PlantId] [int]  NULL
END
GO


IF NOT EXISTS(SELECT * FROM sys.columns
WHERE Name = N'PartitionOn' AND OBJECT_ID = OBJECT_ID(N'[TCD].[ModuleReading]'))
BEGIN
ALTER TABLE [TCD].[ModuleReading] 
ADD [PartitionOn] [smalldatetime] NULL
END
GO

IF NOT EXISTS(SELECT * FROM sys.columns
WHERE Name = N'LastSyncTime' AND OBJECT_ID = OBJECT_ID(N'[TCD].[ModuleReading]'))
BEGIN
ALTER TABLE [TCD].[ModuleReading] 
ADD [LastSyncTime][datetime] NULL
END
GO



/*
###################################################################################################
Stored Procedure:       [TCD].[UpdateLastSyncTime]
Purpose:				Added Module Reading table to Update LastSynchTime
###################################################################################################
*/

ALTER PROCEDURE [TCD].[UpdateLastSyncTime]
(
@Id INT,
@TableName VARCHAR(100),
@ColumnName VARCHAR (100),
@EcolabAccountNumber VARCHAR(100),
@LastSyncTime DATETIME
)
AS
BEGIN
SET NOCOUNT ON;
DECLARE    @SQLString    NVARCHAR(2000)    =    N''

IF(@TableName = 'Plant' OR @TableName = 'LaborCost' )
BEGIN
SET    @SQLString    =    'UPDATE  TCD.' + @TableName + ' ' + 'SET LastSyncTime = '''+ CONVERT(VARCHAR(23),@LastSyncTime,121) +''' WHERE  EcolabAccountNumber = ' +  @EcolabAccountNumber
EXEC (@SQLString)
END

ELSE IF (@TableName = 'BatchData' OR @TableName = 'AlarmData' OR @TableName = 'RedFlagData')
BEGIN
SET    @SQLString    =    'UPDATE  TCD.' + @TableName + ' ' + 'SET LastSyncTime = '''+ CONVERT(VARCHAR(23),@LastSyncTime,121) +''' WHERE ' + @ColumnName + ' = ' +  CAST(@Id AS NVARCHAR)
EXEC (@SQLString)
END

ELSE IF(@TableName = 'ConduitController' OR  @TableName = 'TankSetup')
BEGIN
SET    @SQLString    =    'UPDATE  TCD.' + @TableName + ' ' + 'SET LastSyncTime = '''+ CONVERT(VARCHAR(23),@LastSyncTime,121) +''' WHERE  EcoalabAccountNumber = ' +  @EcolabAccountNumber + ' AND ' + @ColumnName + ' = ' +  CAST(@Id AS NVARCHAR)
EXEC (@SQLString)
END

ELSE IF(@TableName = 'ProductionShiftData')
BEGIN
SET    @SQLString    =    'UPDATE  TCD.' + @TableName + ' ' + 'SET LastSyncTime = '''+ CONVERT(VARCHAR(23),@LastSyncTime,121) +''' WHERE  EcolabAccountNumber = ' +  @EcolabAccountNumber + ' AND  LastSyncTime IS NULL AND ' + @ColumnName + ' <= ' +  CAST(@Id AS NVARCHAR) 
EXEC (@SQLString)
END

ELSE IF(@TableName = 'Tunnel' )
BEGIN
SET    @SQLString    =    'UPDATE  TCD.Washer' + ' SET LastSyncTime = '''+ CONVERT(VARCHAR(23),@LastSyncTime,121) +''' WHERE  EcolabAccountNumber = ' +  @EcolabAccountNumber + ' AND ' + @ColumnName + ' = ' +  CAST(@Id AS NVARCHAR)
EXEC (@SQLString)

SET    @SQLString    =    'UPDATE  TCD.TunnelCompartment' + ' SET LastSyncTime = '''+ CONVERT(VARCHAR(23),@LastSyncTime,121) +''' WHERE  EcolabAccountNumber = ' +  @EcolabAccountNumber + ' AND ' + @ColumnName + ' = ' +  CAST(@Id AS NVARCHAR)
EXEC (@SQLString)
END

ELSE IF (@TableName = 'ShiftData')
BEGIN
SET    @SQLString    =    'UPDATE  TCD.' + @TableName + ' ' + 'SET LastSyncTime = '''+ CONVERT(VARCHAR(23),@LastSyncTime,121) +''''
EXEC (@SQLString)
END

ELSE IF (@TableName = 'ShiftLaborData')
BEGIN
SET    @SQLString    =    'UPDATE  TCD.' + @TableName + ' ' + 'SET LastSyncTime = '''+ CONVERT(VARCHAR(23),@LastSyncTime,121) +''''
EXEC (@SQLString)
END

ELSE IF (@TableName = 'EnergyUtilityDetails')
BEGIN
SET    @SQLString    =    'UPDATE  TCD.' + @TableName + ' ' + 'SET LastSyncTime = '''+ CONVERT(VARCHAR(23),@LastSyncTime,121) +''''
EXEC (@SQLString)

SET    @SQLString    =    'UPDATE TCD.WaterUtilityDetails ' + 'SET LastSyncTime = '''+ CONVERT(VARCHAR(23),@LastSyncTime,121) +''''
EXEC (@SQLString)
END
ELSE IF (@TableName = 'WasherFlushTime')
BEGIN
SET    @SQLString    =    'UPDATE  TCD.' + @TableName + ' ' + 'SET LastSyncTime = '''+ CONVERT(VARCHAR(23),@LastSyncTime,121) +''' WHERE ' + @ColumnName + ' = ' +  CAST(@Id AS NVARCHAR) 
EXEC (@SQLString)

SET    @SQLString    =    'UPDATE  TCD.WasherTimeOutMachine' + ' SET LastSyncTime = '''+ CONVERT(VARCHAR(23),@LastSyncTime,121) +''' WHERE ' + @ColumnName + ' = ' +  CAST(@Id AS NVARCHAR) 
EXEC (@SQLString)
END
ELSE IF (@TableName = 'TunnelAnalogControlLevel')
BEGIN
SET    @SQLString    =    'UPDATE  TCD.' + @TableName + ' ' + 'SET LastSyncTime = '''+ CONVERT(VARCHAR(23),@LastSyncTime,121) +''' WHERE ' + @ColumnName + ' = ' +  CAST(@Id AS NVARCHAR) 
PRINT @SQLString
EXEC (@SQLString)
END
ELSE IF (@TableName = 'ModuleReading')
BEGIN
SET @SQLString = 'UPDATE TCD.'+ @TableName + ' ' + 'SET LastSyncTime = '''+ CONVERT(VARCHAR(23),@LastSyncTime,121) +''' WHERE ' + @ColumnName + ' = ' +  CAST(@Id AS NVARCHAR) 
EXEC (@SQLString)
END
ELSE
BEGIN
SET    @SQLString    =    'UPDATE  TCD.' + @TableName + ' ' + 'SET LastSyncTime = '''+ CONVERT(VARCHAR(23),@LastSyncTime,121) +''' WHERE ' + @ColumnName + ' = ' +  CAST(@Id AS NVARCHAR) + ' AND EcolabAccountNumber = '  + (@EcolabAccountNumber)
EXEC (@SQLString)
END


SET NOCOUNT OFF;
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetTagManamenetDetails]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetTagManamenetDetails]
END
GO
CREATE PROCEDURE [TCD].[GetTagManamenetDetails] 
@ControllerId INT,
@EcolabAccountNumber VARCHAR(100),
@UserId INT

AS
BEGIN 
DECLARE @Active INT = 1,
    @TankModuleTypeId INT,
    @SensorModuleTypeId INT,
    @PumpModuleTypeId INT,
    @LangunageId INT,
    @SplChars VARCHAR(50)   = ' # -',
    @LocaliseValue VARCHAR(200),
    @FactorMultiplier INT,
    @TimeVolumeMultipler INT,
	@ControllerModelId int,
	@ControllerTypeId INT


SELECT @TankModuleTypeId=mty.ModuleTypeId FROM TCD.ModuleType mty WHERE mty.ModuleDescription='Tank'
SELECT @SensorModuleTypeId=mty.ModuleTypeId FROM TCD.ModuleType mty WHERE mty.ModuleDescription='Sensor'
SELECT @PumpModuleTypeId=mty.ModuleTypeId FROM TCD.ModuleType mty WHERE mty.ModuleDescription='Pumps/Valves'
SELECT @LangunageId=p.languageID FROM TCD.Plant p WHERE p.EcolabAccountNumber=@EcolabAccountNumber


 SELECT @TimeVolumeMultipler= CAST(csd.[Value] AS decimal(18,0)) FROM TCD.ControllerSetupData csd 
 INNER JOIN TCD.Field f ON f.Id = csd.FieldId 
 WHERE csd.FieldId IN(SELECT f2.Id FROM TCD.Field f2 WHERE f2.Label LIKE '%OZ/Second Multiplier%') 
    AND csd.ControllerId=@ControllerId 
    AND csd.EcolabAccountNumber=@EcolabAccountNumber 
	AND ISNUMERIC(csd.[Value]) = 1

 SELECT @FactorMultiplier= CAST(csd.[Value] AS decimal(18,0)) FROM TCD.ControllerSetupData csd 
 INNER JOIN TCD.Field f ON f.Id = csd.FieldId 
 WHERE csd.FieldId IN(SELECT f2.Id FROM TCD.Field f2 WHERE f2.Label LIKE '%Factors Multiplier%') 
    AND csd.ControllerId=@ControllerId
    AND csd.EcolabAccountNumber=@EcolabAccountNumber 
	AND ISNUMERIC(csd.[Value]) = 1

SELECT @ControllerModelId=ControllerModelId,@ControllerTypeId=ControllerTypeId FROM tcd.ConduitController cc WHERE ControllerId=@ControllerId


CREATE TABLE #tmpTagManagementDetails
(
  Id INT
 ,TagAddress VARCHAR(100)
 ,[Description] VARCHAR(1000)
 ,Value VARCHAR(500)
 ,LastModifiedTime DATETIME 
 ,ColName VARCHAR(500)
 ,DataType varchar(100)
 ,RowNumber decimal(3,2)
 ,OriginalColumnName varchar(100)
 ,EntityType varchar(100)
 ,TagType varchar(100)
 ,ControllerEquipmentSetupId varchar(100)
 ,SortingOrder varchar(100)
)


--SELECT @LocaleValue=rkv.[Value] FROM TCD.ResourceKeyMaster rkm 
--    INNER JOIN TCD.ResourceKeyValue rkv on rkv.ResourceId = rkm.ResourceId 
--where rkm.[Key] ='FIELD_'+ UPPER(@KeyValue) 
--  AND 
--rkv.languageID=ISNULL((SELECT um.LanguageId FROM TCD.UserMaster um WHERE um.UserId=@UserId),(SELECT p.LanguageId FROM TCD.Plant p WHERE p.EcolabAccountNumber=@EcolabAccountNumber)) 


--------------------------------------
-- StorageTanks---
--------------------------------------

INSERT INTO #tmpTagManagementDetails(Id, TagAddress,    [Description],    [Value],    LastModifiedTime,colName,DataType,RowNumber,OriginalColumnName
	,EntityType,TagType,ControllerEquipmentSetupId,SortingOrder)

----------------------------------------------------------------
-- Conventional-AND-Tunnel(AWEA, EOF, MODE to be displayed)-----
----------------------------------------------------------------
SELECT ms.WasherId, wt.TagAddress,Convert(varchar(100),w.PlantWasherNumber)+' : '+ms.MachineName,Convert(varchar(100), CONVERT(int, w.EndOfFormula)),w.LastModifiedTime ,'EndofFormulaNumber',tt.DataType,1,
'EndOfFormula' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType,ms.MachineInternalId as ControllerEquipmentSetupId, 2 as SortingOrder 
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId) AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_EOF' AND ms.IsTunnel IN (0,1)
UNION

SELECT ms.WasherId, wt.TagAddress,Convert(varchar(100),w.PlantWasherNumber)+' : '+ms.MachineName,Convert(varchar(100), CONVERT(int, (
SELECT	wmm.WasherModeNumber FROM TCD.WasherModeMapping wmm	
				INNER JOIN	tcd.ControllerModelControllerTypeMapping cmctm	ON cmctm.Id	=wmm.ControllerModelControllerTypeMappingId	 
				AND cmctm.ControllerModelId=@ControllerModelId	 
				AND cmctm.ControllerTypeId=@ControllerTypeId 
				AND wmm.WasherModeId=w.WasherMode))),w.LastModifiedTime ,'WasherMode',tt.DataType,1,'WasherMode' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType,ms.MachineInternalId as ControllerEquipmentSetupId, 5 as SortingOrder  
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_MODE' AND ms.IsTunnel IN (0,1)
UNION

SELECT ms.WasherId, wt.TagAddress,Convert(varchar(100),w.PlantWasherNumber)+' : '+ms.MachineName,Convert(varchar(100), CONVERT(int, w.AWEActive)),w.LastModifiedTime ,'AWEActive',tt.DataType,1
,'AWEActive' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType,ms.MachineInternalId as ControllerEquipmentSetupId , 1 as SortingOrder 
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_AWEA' AND ms.IsTunnel IN (0,1)
UNION

SELECT ms.WasherId, wt.TagAddress,Convert(varchar(100),w.PlantWasherNumber)+' : '+ms.MachineName,Convert(varchar(100), CONVERT(int, w.HoldDelay)),w.LastModifiedTime ,'HoldDelay',tt.DataType,1
,'HoldDelay' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType, ms.MachineInternalId as ControllerEquipmentSetupId , 3 as SortingOrder

FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId  AND wt.Active=@Active  AND wt.TagType='Tag_HOLDD' AND ms.IsTunnel=0 
UNION

SELECT ms.WasherId, wt.TagAddress,Convert(varchar(100),w.PlantWasherNumber)+' : '+ms.MachineName,Convert(varchar(100), CONVERT(int, w.WaterFlushTime)),w.LastModifiedTime , 'WaterFlushTime' ,tt.DataType,1
,'WaterFlushTime' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType, ms.MachineInternalId as ControllerEquipmentSetupId, 6 as SortingOrder  
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_FLSHT' AND ms.IsTunnel=0
UNION

SELECT ms.WasherId, wt.TagAddress,Convert(varchar(100),w.PlantWasherNumber)+' : '+ms.MachineName,Convert(varchar(100), CONVERT(int, w.RatioDosingActive)),w.LastModifiedTime, 'RatioDosingActive',tt.DataType,1
,'RatioDosingActive' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType, ms.MachineInternalId as ControllerEquipmentSetupId, 4 as SortingOrder  
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_RATA' AND ms.IsTunnel=0

UNION
------------------------------------
---- Tanks---
------------------------------------
SELECT ts.TankId AS Id, mt.TagAddress AS TagAddress,   ts.TankName AS [Description],Convert(varchar(10),Convert(int,( ts.Size))) AS Value,   
ts.LastModifiedTime , 'Size',tt.DataType,1
,'Size-Size_Display' as OriginalColumnName,'[TCD].[TankSetup]' as EntityName,tt.TagType as TagType, 0 as ControllerEquipmentSetupId  , 0 as SortingOrder

FROM   TCD.ModuleTags mt INNER JOIN TCD.TankSetup ts ON ts.TankId=mt.ModuleId
Inner Join tcd.TagType tt on mt.TagType = tt.TagType

WHERE   mt.ModuleTypeId=@TankModuleTypeId    AND ts.ControllerId=@ControllerId     AND mt.Active=@Active    AND mt.TagType='Tag_SIZ' 
UNION

SELECT ts.TankId,mt.TagAddress,ts.TankName,Convert(varchar(100),Convert(int,( ts.LevelDeviation_Display))),ts.LastModifiedTime ,'Dead Band',tt.DataType,1
,'LevelDeviation-LevelDeviation_Display' as OriginalColumnName,'[TCD].[TankSetup]' as EntityName,tt.TagType as TagType, 0 as SortingOrder, 0 as ControllerEquipmentSetupId  

FROM    TCD.ModuleTags mt 
INNER JOIN  TCD.TankSetup ts ON ts.TankId=mt.ModuleId
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE   mt.ModuleTypeId=@TankModuleTypeId 
    AND ts.ControllerId=@ControllerId 
    AND mt.Active=@Active 
    AND mt.TagType='Tag_DEV' 
UNION
----------------------------------------
---- Meter---
----------------------------------------

----------------------------------------
---- Sensor---
----------------------------------------
SELECT s.SensorId,mt.TagAddress,s.[Description],CONVERT(VARCHAR(100),CAST(s.Calibration4mA as float)),s.LastModifiedTime ,'Calibration4mA',tt.DataType,3
,'Calibration4mA' as OriginalColumnName,'[TCD].[Sensor]' as EntityName,tt.TagType as TagType, 0 as ControllerEquipmentSetupId, 0 as SortingOrder  
from TCD.ModuleTags mt INNER JOIN TCD.Sensor s ON MT.ModuleId=s.SensorId 
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE mt.ModuleTypeId=@SensorModuleTypeId AND s.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_SC4'

UNION

SELECT s.SensorId,mt.TagAddress,s.[Description],CONVERT(VARCHAR(100),CAST(s.Calibration20mA as float)),s.LastModifiedTime , 'Calibration20mA',tt.DataType,3
,'Calibration20mA' as OriginalColumnName,'[TCD].[Sensor]' as EntityName,tt.TagType as TagType, 0 as ControllerEquipmentSetupId, 0 as SortingOrder  
from TCD.ModuleTags mt INNER JOIN TCD.Sensor s ON MT.ModuleId=s.SensorId 
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE mt.ModuleTypeId=@SensorModuleTypeId AND s.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_SC20' 
UNION
--------------------------------------
-- Pumps---
--------------------------------------



SELECT  Convert(int, ces.ControllerEquipmentSetupId), mt.TagAddress,'P/V'+Convert(varchar(100), ces.ControllerEquipmentId),
Convert(varchar(100),Convert(float, ces.KFactor * @FactorMultiplier)),ces.LastModifiedTime ,'K-Factor',tt.DataType,2
,'KFactor' as OriginalColumnName,'[TCD].[ControllerEquipmentSetup]' as EntityName,tt.TagType as TagType, ControllerEquipmentId as ControllerEquipmentSetupId, 1 as SortingOrder   

FROM TCD.ModuleTags mt INNER JOIN TCD.ControllerEquipmentSetup ces ON mt.ModuleId=ces.ControllerEquipmentSetupId 
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE mt.ModuleTypeId=@PumpModuleTypeId AND ces.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_PPOL'
UNION
SELECT  Convert(int, ces.ControllerEquipmentSetupId), mt.TagAddress,'P/V'+Convert(varchar(100), ces.ControllerEquipmentId),
Convert(varchar(100),Convert(float, ces.PumpCalibration *@TimeVolumeMultipler)),ces.LastModifiedTime, 'Time Volume Calibration',tt.DataType,2
,'PumpCalibration' as OriginalColumnName,'[TCD].[ControllerEquipmentSetup]' as EntityName,tt.TagType as TagType , ControllerEquipmentId as  ControllerEquipmentSetupId, 3 as SortingOrder 
FROM TCD.ModuleTags mt INNER JOIN TCD.ControllerEquipmentSetup ces ON mt.ModuleId=ces.ControllerEquipmentSetupId
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE mt.ModuleTypeId=@PumpModuleTypeId AND ces.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_OPSL'
UNION

SELECT Convert(int, ces.ControllerEquipmentSetupId), mt.TagAddress,'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
ces.LfsChemicalName,ces.LastModifiedTime ,'LFS Chemical Name',tt.DataType,2
,'LfsChemicalName' as OriginalColumnName,'[TCD].[ControllerEquipmentSetup]' as EntityName,tt.TagType as TagType, ControllerEquipmentId as ControllerEquipmentSetupId  , 2 as SortingOrder 

FROM TCD.ModuleTags mt INNER JOIN TCD.ControllerEquipmentSetup ces ON mt.ModuleId=ces.ControllerEquipmentSetupId
Inner Join tcd.TagType tt on mt.TagType = tt.TagType 
WHERE mt.ModuleTypeId=@PumpModuleTypeId AND ces.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_NML' 
UNION

SELECT csd.ControllerId ,ct.TagAddress,NULL,csd.[Value],cc.LastModifiedTime , f.Label,tt.DataType,6
,'Value-'+CAST(csd.FieldId as varchar) as OriginalColumnName,'[TCD].[ControllerSetupData]' as EntityName,tt.TagType as TagType, 0 as ControllerEquipmentSetupId  , 0 as SortingOrder
FROM TCD.ControllerTags ct 
INNER JOIN TCD.ControllerSetupData csd ON csd.ControllerId = ct.ControllerId
INNER JOIN tcd.Field f ON f.Id = csd.FieldId AND ct.TagType=f.HasFieldTag
INNER JOIN TCD.ConduitController cc ON cc.ControllerId = ct.ControllerId
Inner Join tcd.TagType tt on ct.TagType = tt.TagType
WHERE ct.ControllerId=@ControllerId AND ct.Active=@Active

UNION

SELECT ces.ControllerEquipmentSetupId,
	   'stMachineConfig.xFlowSwitchType['+cast(ControllerEquipmentId AS varchar(20))+']' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  cast( FlowDetectorType AS varchar(20)) AS Value, 
	   ces.LastModifiedTime,
	   'Flow Detector Type' AS Lable,
	   'BIT' As DataType ,
	   2.1,
	   'FlowDetectorType' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stMachineConfig.xFlowSwitchType' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 5 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3


UNION --Flow Switch Alarm
SELECT ces.ControllerEquipmentSetupId,
	   'stMachineConfig.xFlowAlarmOverride['+cast(ControllerEquipmentId AS varchar(20))+']' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  Cast( ces.FlowSwitchAlarm  AS varchar(20)) AS Value, 
	   ces.LastModifiedTime,
	   'Flow Switch Alarm' AS Lable,
	   'BIT' As DataType ,
	   2.2,
	   'FlowSwitchAlarm' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stMachineConfig.xFlowAlarmOverride' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId , 10 as SortingOrder 
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3
UNION --Flow Meter Alarm
SELECT ces.ControllerEquipmentSetupId,
	   'stMachineConfig.xFlowMeterAlarmOverride['+cast(ControllerEquipmentId AS varchar(20))+']' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	 cast(  ces.FlowMeterAlarm  AS varchar(20)) AS Value, 
	   ces.LastModifiedTime,
	   'Flow Meter Alarm' AS Lable,
	   'BIT' As DataType ,
	   2.3,
	   'FlowMeterAlarm' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stMachineConfig.xFlowMeterAlarmOverride' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 6 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3
UNION --Flow Meter Type
     
SELECT ces.ControllerEquipmentSetupId,
	   'stPumpConfig['+cast(ControllerEquipmentId AS varchar(20))+'].eFlowMeterMode' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  cast( ces.FlowMeterType  AS varchar(20))  AS Value, 
	   ces.LastModifiedTime,
	   'Flow Meter Type' AS Lable,
	   'INT' As DataType ,
	   2.4,
	   'FlowMeterType' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stPumpConfig.eFlowMeterMode' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 9 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3

UNION --Flow Alarm Delay Time
SELECT ces.ControllerEquipmentSetupId,
	   'stPumpConfig['+cast(ControllerEquipmentId AS varchar(20))+'].fLossOfFlowDuration' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  cast( ces.FlowAlarmDelay  AS varchar(20))  AS Value, 
	   ces.LastModifiedTime,
	   'Flow Alarm Delay Time' AS Lable,
	   'FLOAT' As DataType ,
	   2.5,
	   'FlowAlarmDelay' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stPumpConfig.fLossofFlowDuration' TagType, ces.ControllerEquipmentId  as ControllerEquipmentSetupId, 4 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3
UNION --Flow Meter Pump Delay
SELECT ces.ControllerEquipmentSetupId,
	   'stPumpConfig['+cast(ControllerEquipmentId AS varchar(20))+'].fTdFlowMeter' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  cast( ces.FlowMeterPumpDelay  AS varchar(20))  AS Value, 
	   ces.LastModifiedTime,
	   'Flow Meter Pump Delay' AS Lable,
	   'FLOAT' As DataType ,
	   2.6,
	   'FlowMeterPumpDelay' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stPumpConfig.fTdFlowMeter' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 8 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3

UNION -- Flow Meter Alarm Delay
SELECT ces.ControllerEquipmentSetupId,
	   'stPumpConfig['+cast(ControllerEquipmentId AS varchar(20))+'].fTAlarmDelayFlowMeter' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  cast( ces.FlowMeterAlarmDelay  AS varchar(20))  AS Value, 
	   ces.LastModifiedTime,
	   'Flow Meter Alarm Delay' AS Lable,
	   'FLOAT' As DataType ,
	   2.7,
	   'FlowMeterAlarmDelay' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stPumpConfig.fTAlarmDelayFlowMeter' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 7 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3



SELECT  ttmd.Id  
   ,ttmd.TagAddress  
   ,isnull(ttmd.[Description],'')
   ,ttmd.Value  
   ,ttmd.LastModifiedTime  
   ,ttmd.ColName
   ,ttmd.DataType
   ,ttmd.OriginalColumnName
	,ttmd.EntityType 
	,ttmd.TagType,ttmd.SortingOrder,ttmd.ControllerEquipmentSetupId  FROM dbo.#tmpTagManagementDetails ttmd WHERE ttmd.[Value] IS  NOT NULL AND ttmd.[Value]<> '' ORDER BY ttmd.RowNumber

END
GO

UPDATE TCD.ConfigSettings
SET
    [Value] = N'20'
WHERE KeyName = N'NoOfRecordsToBeProcessed'
    AND [Type] = N'SyncBatchData'
GO


IF  EXISTS (SELECT * FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[TCD].[GetReportDataByFilterId]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetReportDataByFilterId]
END
GO

CREATE PROCEDURE [TCD].[GetReportDataByFilterId]

(

@UserId INT = NULL

, @RoleId INT = NULL

, @IsLocal BIT = NULL

, @MachineTye NVARCHAR(1000) = NULL

, @Machinegroup NVARCHAR(1000) = NULL

, @ReportId INT = NULL

, @FilterId INT = NULL

)

AS

SET NOCOUNT ON;

BEGIN

    DECLARE

     @LanguageId INT = (SELECT UM.LanguageId

      FROM TCD.UserMaster UM

      WHERE UserId = @UserId );

    DECLARE

     @MachineTypeTable TABLE(MachineType VARCHAR(100));

    INSERT INTO @MachineTypeTable

    EXEC TCD.CharlistToTable @MachineTye, ',';

    DECLARE

     @MachineGroupTable TABLE(MachineGroup VARCHAR(100));

    INSERT INTO @MachineGroupTable

    EXEC TCD.CharlistToTable @machineGroup, ',';

    DECLARE

     @TypeId INT,

     @FilterTargetId INT;



    DECLARE

     @ResultTable TABLE

     (

     Id NVARCHAR(2000),

     Name NVARCHAR(300),

     TypeId INT

     );
	 

    SELECT @FilterTargetId = RFM.TargetDropDown

  FROM TCD.ReportFilterMapping RFM

  WHERE RFM.FilterId = @FilterId

    AND RFM.ReportId = @ReportId;

    IF @FilterId IS NULL



    --Filter Options for Region and Country filter  



    BEGIN

    SELECT @FilterTargetId = RF.ReportFilterId

      FROM TCD.ReportFilter RF

      WHERE RF.FilterName = 'Machine Types';

    END;

    IF @FilterTargetId = 8



    --Filter Options for machine Types  



    BEGIN

    SELECT @TypeId = RF.ReportFilterId

      FROM TCD.ReportFilter RF

      WHERE RF.FilterName = 'Machine Types';

    INSERT INTO @ResultTable (

    Id,

    Name,

    TypeId

    )

    SELECT DISTINCT

    WGT.WasherGroupTypeId AS Id,

    WGT.WasherGroupTypeName AS Name,

    @TypeId AS TypeId

      FROM

    TCD.WasherGroupType WGT

  END;

    ELSE

    BEGIN IF @FilterTargetId = 5



      --Filter Options for Machine groups based on plant  



      BEGIN

      SELECT @TypeId = RF.ReportFilterId

        FROM TCD.ReportFilter RF

        WHERE RF.FilterName = 'Machine group';

      SELECT @MachineTye = CASE @MachineTye WHEN 3 THEN '' ELSE @MachineTye END;



      --INSERT INTO @ResultTable (

      --Id,

      --Name,

      --TypeId

      --)

      SELECT 
     CAST( WG.WasherGroupId AS VARCHAR(1000)) AS Id ,

      WG.WasherGroupName AS Name,

      @TypeId AS TypeId

      FROM TCD.WasherGroup WG

      WHERE CASE WHEN ISNULL( @MachineTye,'')='' THEN 'TRUE'

       WHEN  @MachineTye='0' THEN 'False'

        ELSE

        CASE

        WHEN WG.WasherGroupTypeId  IN (SELECT MachineType

      FROM @MachineTypeTable) THEN 'TRUE'

        END

        END = 'TRUE'
		ORDER By CAST( WG.WasherGroupNumber as int);

		RETURN

      END;

      ELSE

      BEGIN IF @FilterTargetId = 6



        --Filter Options for Machines based on Group  



        BEGIN

        SELECT @TypeId = RF.ReportFilterId

          FROM TCD.ReportFilter RF

          WHERE RF.FilterName = 'Machine';

        --INSERT INTO @ResultTable (

        --Id,

        --Name,

        --TypeId

        --)



        SELECT 

       cast( W.WasherId AS varchar(2000)) AS Id,

       CAST( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName AS Name,

        @TypeId AS TypeId

          FROM

        TCD.MachineSetup MS

        INNER JOIN TCD.Washer W ON MS.WasherId = W.WasherId

         WHERE  IsNULL(MS.IsPony,0) = 0

         AND (MS.GroupId IN (SELECT MachineGroup

        FROM @MachineGroupTable) or ISNULL(@machineGroup,'')='' )



       ORDER BY cast( W.PlantWasherNumber AS int)

       RETURN;

        END;

      END;

    END;

    IF @FilterId = 21

   AND @ReportId = 30



    --Filter Options for User



    BEGIN

    SELECT @TypeId = RF.ReportFilterId

      FROM TCD.ReportFilter RF

      WHERE RF.FilterName = 'User';

    INSERT INTO @ResultTable (

    Id,

    Name,

    TypeId

    )

    SELECT DISTINCT

    UserId AS Id,

   FirstName +' ' + LastName AS name,

    NULL AS TypeId

      FROM tcd.usermaster;

    END;

    ELSE

    BEGIN

    IF @FilterId = 22

    BEGIN

    SELECT @TypeId = RF.ReportFilterId

      FROM TCD.ReportFilter RF

      WHERE RF.FilterName = 'ActionType';

 INSERT INTO @ResultTable (

    Id,

    Name,

    TypeId

    )

    SELECT DISTINCT

    CAST(AO.OperationId AS INT) AS OperationId,

    RKV.Value AS OperationCode,

    NULL  AS TypeId

      FROM TCD.AuditOperation AO

       LEFT JOIN

       TCD.ResourceKeyMaster RKM

    ON AO.UsageKey = RKM.[KeyName]

       LEFT JOIN

       TCD.ResourceKeyValue RKV

    ON RKV.KeyName = RKM.KeyName

      WHERE RKV.languageID = @LanguageId

      ORDER BY OperationId;

    END;

    END;



    SELECT

    

    Id,

    Name,

    TypeId

  FROM @ResultTable;

END;
GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetPlantChainProgramByPlantChainId]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetPlantChainProgramByPlantChainId
	END
GO

/*

Stored Procedure	:	[TCD].[GetPlantChainProgramByPlantChainId]	in	TRASAR3 Db

Purpose				:	To get plant chain program details for particular palnt chain

Parameters			:	None
							
*/

CREATE PROCEDURE TCD.GetPlantChainProgramByPlantChainId
	   @Plantchainid INT = NULL
AS
BEGIN
	SET NOCOUNT ON;

	SELECT	DISTINCT pcp.PlantProgramId, 
			pcp.PlantProgramName, 
			pcp.ChainTextileCategoryId AS ChainTextileId,
			ctc.Name AS ChainTextileName, 
			etc.TextileId AS EcolabTextileCategoryId, 
			etc.CategoryName AS EcolabTextileCategoryName, 	  
			fs.FormulaSegmentID, 
			fs.SegmentName,
			pcp.LastModifiedTime, 
			pcp.Is_Deleted, 
			pcp.PlantChainId,
			es.EcolabSaturationId, 
			es.EcolabSaturationName
	FROM TCD.PlantChainProgram AS pcp
	INNER JOIN TCD.Plant p ON p.PlantChainId = pcp.PlantChainId 
  LEFT JOIN TCD.ChainTextileCategory ctc
  ON pcp.ChainTextileCategoryId = ctc.TextileId AND ctc.PlantChainId = pcp.PlantChainId
  LEFT JOIN TCD.EcolabTextileCategory etc
  ON pcp.EcolabTextileCategoryId = etc.TextileId
  LEFT JOIN TCD.EcolabSaturation es
  ON pcp.EcolabSaturationId = es.EcolabSaturationId
  LEFT JOIN TCD.FormulaSegments fs
  ON pcp.FormulaSegmentId = fs.FormulaSegmentID
  WHERE pcp.PlantChainId = @Plantchainid

END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetPlantUtilityDetails]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetPlantUtilityDetails]
END
GO

CREATE PROCEDURE [TCD].[GetPlantUtilityDetails] 
(
@EcolabAccountNumber VARCHAR(100)
)
AS
BEGIN
    SET NOCOUNT ON
IF EXISTS (

SELECT s.* FROM tempdb.sys.sysobjects s WHERE s.xtype IN ('U') AND(s.id=object_id(N'tempdb..#tmpWaterTypesUsed') OR s.id=object_id(N'tempdb..#tmpGasOilTypes'))
)
BEGIN
DROP TABLE #tmpGasOilTypes;
DROP TABLE #tmpWaterTypesUsed;

END

CREATE TABLE #tmpWaterTypesUsed
(
  WaterType INT
 ,WasherMode VARCHAR(1000)
 
)
INSERT INTO #tmpWaterTypesUsed(WaterType,WasherMode)

(SELECT wds.WaterType,'Washer'AS WasherMode FROM TCD.WasherDosingSetup wds WHERE wds.WaterType>0 AND wds.Is_Deleted=0
UNION
SELECT tds.WaterType,'Tunnel'AS WasherMode FROM TCD.TunnelDosingSetup tds WHERE tds.WaterType>0 AND tds.Is_Deleted=0)


    DECLARE @RegionId INT,
    @UsageKey VARCHAR(100)
    SELECT @RegionId=P.RegionID FROM TCD.Plant P WHERE P.EcolabAccountNumber=@EcolabAccountNumber

	CREATE TABLE #tmpGasOilTypes
(
  GasOilType  VARCHAR(100)
 ,EnergyContent DECIMAL(18,4)
 ,UsageKey VARCHAR(100)
 
)
INSERT INTO #tmpGasOilTypes(GasOilType,EnergyContent,UsageKey)
(SELECT gtm.Name,gotm.DefaultValue,gtm.UsageKey	FROM TCD.GasoilTypeMaster gtm 
		INNER JOIN TCD.GasOilTypeMapping gotm	ON gtm.GasoilId=gotm.GasOilId
		WHERE gtm.GasoilId=(SELECT eud.GasOilTypeId FROM TCD.EnergyUtilityDetails eud WHERE eud.EcolabAccountNumber=@EcolabAccountNumber) AND gotm.RegionId=@RegionId)



SELECT distinct @UsageKey=rkv.[Value]
			FROM TCD.DimensionalSubunits ds
			INNER JOIN 			tcd.DimensionalUnits du ON du.Unit = ds.Unit
			INNER JOIN 			TCD.DimensionalUsageKey duk ON duk.Unit = ds.Unit
			INNER JOIN			TCD.DimensionalUnitsDefaults dud ON dud.UsageKey = duk.UsageKey
			INNER JOIN			TCD.ResourceKeyMaster rkm ON rkm.[KeyName]	= dud.Subunit
			INNER JOIN			tcd.ResourceKeyValue rkv ON rkv.[KeyName]=rkm.[KeyName]
			WHERE				duk.UsageKey = (SELECT UsageKey FROM #tmpGasOilTypes tgot)collate Latin1_General_CI_AI
							AND dud.UnitSystemId=(SELECT p.UOMId FROM TCD.Plant p WHERE p.EcolabAccountNumber=@EcolabAccountNumber)




    SELECT  wu.EcolabAccountNumber		AS	   EcolabAccountNumber,
		 wu.WaterFactorTypeId		AS	   WaterFactorTypeId,

		 CASE
		  WHEN wu.WaterFactorTypeId<>0    THEN (SELECT wt.Name FROM TCD.WaterType wt WHERE wt.Id=wu.WaterFactorTypeId) 
		  WHEN wu.WaterFactorTypeId=0	    THEN CONVERT(varchar(350), wu.WaterFactorTypeId) END AS FactorType,
		 					
		 wu.Temperature			AS	   Temperature,
		 wu.Price					AS	   Price,
		 eu.GasOilTypeId			AS	   GasOilTypeId,
		 (SELECT GasOilType FROM #tmpGasOilTypes tgot) AS GasOilType,
		 (SELECT EnergyContent FROM #tmpGasOilTypes tgot) AS EnergyContent,
		 @UsageKey				AS	   EnergyContentUnit,
		 eu.EnergyPrice			AS	   EnergyPrice,
		 eu.EnergySubUnit			AS	   EnergyPriceUnit,
		 eu.ElectricPrice			AS	   ElectricPrice,
		 eu.BolierSteam			AS	   BoilerSteam,
		 eu.BolierType				AS	   BoilerType,
		 eu.Steam					AS	   Steam,
		 eu.Boiler				AS	   Boiler,
		 eu.Stack					AS	   Stack,
		 eu.RewashFactor			AS	   RewashFactor,
		 eu.EvaporationFactor		AS	   EvaporationFactor,
		 
		 CASE 
		  WHEN wu.WaterFactorTypeId<>0 THEN (SELECT wt.MyServiceUtilTypeCode from TCD.WaterType wt WHERE wt.Id=wu.WaterFactorTypeId) 
		  WHEN wu.WaterFactorTypeId=0	 THEN 'V' END AS FreeType,
		  CASE 	
		  WHEN (SELECT COUNT(*) FROM #tmpWaterTypesUsed twtu INNER JOIN TCD.Watertype wt ON twtu.WaterType=wt.Id AND wt.MyServiceUtilTypeCode='V' WHERE twtu.WaterType=wu.WaterFactorTypeId)>0 THEN  'TRUE'

		  WHEN (SELECT COUNT(*) FROM #tmpWaterTypesUsed twtu INNER JOIN TCD.Watertype wt ON twtu.WaterType=wt.Id AND wt.MyServiceUtilTypeCode='V' WHERE twtu.WaterType=wu.WaterFactorTypeId)=0 THEN 'FALSE' END AS IsFactorUsed,
		  eu.LastModifiedTime,
		  wu.MyServiceWtrFctrId,
		  wu.MyServiceLastSyncTime,
		  wu.WaterUtilityDetailsId

	 FROM TCD.WaterUtilityDetails wu
		 INNER JOIN
		 TCD.EnergyUtilityDetails eu ON eu.EcolabAccountNumber = wu.EcolabAccountNumber
	 WHERE wu.EcolabAccountNumber = @EcolabAccountNumber 
	 ORDER BY wu.WaterUtilityDetailsId
    SET NOCOUNT OFF
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetAWEandRatioDosing]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetAWEandRatioDosing]
END
GO

CREATE PROCEDURE [TCD].[GetAWEandRatioDosing]
@ControllerId INT,
@EcolabAccountNumber VARCHAR(50)
AS
BEGIN
DECLARE @tempResult TABLE(
RatioDosingActive int, AWEActive INT,ControllerTypeId INT
)
DECLARE @RatioDosingActive INT, @AWEActive INT,@ControllerTypeId INT

SET @RatioDosingActive = (SELECT count(w.RatioDosingActive) FROM tcd.Washer w join
tcd.MachineSetup ms ON w.WasherId= ms.WasherId and ms.ControllerId = @ControllerId and w.RatioDosingActive = 1 and w.Is_Deleted = 0
and w.EcoLabAccountNumber = @EcolabAccountNumber AND    ms.EcoalabAccountNumber =  @EcolabAccountNumber)

SET @AWEActive = (SELECT count(w.AWEActive) FROM tcd.Washer w join
tcd.MachineSetup ms ON w.WasherId= ms.WasherId and ms.ControllerId = @ControllerId and w.AWEActive = 1 and w.Is_Deleted = 0
and w.EcoLabAccountNumber = @EcolabAccountNumber AND    ms.EcoalabAccountNumber =  @EcolabAccountNumber)

SET @ControllerTypeId =(SELECT  ControllerTypeId FROM tcd.ConduitController WHERE ControllerId=@ControllerId AND EcoalabAccountNumber = @EcolabAccountNumber)

INSERT INTO @tempResult VALUES(@RatioDosingActive,@AWEActive,@ControllerTypeId)

SELECT * FROM @tempResult
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[SaveControllerSetupData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[SaveControllerSetupData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[SaveControllerSetupData] 
(
  @ControllerSetupData     XML
 , @UserId         INT
 , @ControllerId       INT      OUTPUT
 , @LastModifiedTimestampAtCentral   DATETIME = NULL
 , @OutputLastModifiedTimestampAtLocal  DATETIME = NULL OUTPUT
)
AS
BEGIN
      SET NOCOUNT ON
   
--DECLARE @ControllerId INT
DECLARE @ControllerNumber INT = NULL
DECLARE @ControllerModelId INT = NULL
DECLARE @ControllerModelName VARCHAR(50) = NULL
DECLARE @ControllerTypeId INT = NULL
DECLARE @ControllerTypeName VARCHAR(50) = NULL
DECLARE @EcolabAccountNumber VARCHAR(1000) = NULL
DECLARE @TopicName VARCHAR(1000) = NULL
DECLARE @Active BIT
DECLARE @ErrorMessage VARCHAR(200) = NULL
DECLARE @NumOfConvWasherGroups INT = NULL
DECLARE @NumOfTunnelWasherGroups INT = NULL
DECLARE @LoopCount INT = 0
DECLARE @WasherGroupName VARCHAR(100) = NULL
DECLARE @WasherGroupId INT = NULL
DECLARE @WasherGroupNumber VARCHAR(10) = NULL
DECLARE @OutputList AS TABLE (
ControllerId INT
,LastModifiedTimestamp DATETIME
  )

SET @ControllerId = ISNULL(@ControllerId, NULL) --SQLEnlight SA0121
SET @OutputLastModifiedTimestampAtLocal = ISNULL(@OutputLastModifiedTimestampAtLocal, NULL) --SQLEnlight SA0121

   SELECT @ControllerNumber = Tbl.col.value('@ControllerNumber', 'int')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)

   SELECT @ControllerModelId = Tbl.col.value('@ControllerModelId', 'int')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)

   SELECT @ControllerTypeId = Tbl.col.value('@ControllerTypeId', 'int')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)
   
   SELECT @EcolabAccountNumber = Tbl.col.value('@EcolabAccountNumber', 'varchar(1000)')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)

    SELECT @TopicName = Tbl.col.value('@TopicName', 'varchar(1000)')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)

    SELECT @Active = Tbl.col.value('@Active', 'bit')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)
   
IF EXISTS (
SELECT 1
FROM [TCD].ConduitController WITH (NOLOCK)
WHERE ControllerNumber = @ControllerNumber
AND IsDeleted = 0
AND EcoalabAccountNumber = @EcolabAccountNumber
)
   BEGIN
SET @ErrorMessage = '303 - Controller Number already exists.'

RAISERROR (
@ErrorMessage
,16
,1
)

   RETURN
   END

IF EXISTS (
SELECT 1
FROM [TCD].ConduitController WITH (NOLOCK)
WHERE TopicName = @TopicName
AND IsDeleted = 0
AND EcoalabAccountNumber = @EcolabAccountNumber
)
BEGIN
SET @ErrorMessage = '304 - Controller Name already exists.'

RAISERROR (
@ErrorMessage
,16
,1
        )

RETURN
END




SELECT @ControllerModelName = Name
FROM [TCD].ControllerModel WITH (NOLOCK)
WHERE Id = @ControllerModelId

SELECT @ControllerTypeName = Name
FROM [TCD].ControllerType WITH (NOLOCK)
WHERE Id = @ControllerTypeId

DECLARE @TempMaster TABLE (
EcolabAccountNumber NVARCHAR(25)
,NAME VARCHAR(100)
,ControllerModelId INT
,ControllerNumber INT
,ControllerTypeId INT
,ControllerVersion VARCHAR(10)
,InstallDate DATETIME
,UserId INT
,TopicName VARCHAR(1000)
,Active BIT
        )
DECLARE @TempDynamic TABLE (
EcolabAccountNumber NVARCHAR(25)
,ControllerId INT
,ControllerModelId INT
,FieldGroupId INT
,FieldId INT
,Value VARCHAR(1000)
,UserId INT
)


INSERT INTO @TempDynamic (
EcolabAccountNumber
,ControllerId
,ControllerModelId
,FieldGroupId
,FieldId
,Value
,UserId
)
SELECT @EcolabAccountNumber
,0
,Tbl.col.value('@ControllerModelId', 'int')
,Tbl.col.value('@FieldGroupId', 'int')
,Tbl.col.value('@FieldId', 'int')
,Tbl.col.value('@Value', 'varchar(1000)')
,@UserId
FROM @ControllerSetupData.nodes('/ControllerSetupData/DynamicSetupData/Data') AS Tbl(col)

DECLARE @TempFieldId INT
DECLARE @TempValue VARCHAR(1000)


SELECT @TempFieldId=FieldId,@TempValue=Value FROM @TempDynamic WHERE FieldId in (21,22,47,48,87,98,116,130,148,150,171,192,208,269,309,348,387,400,414,426,438,449,460)


IF EXISTS ( SELECT 1
            FROM  [TCD].ConduitController CC WITH (NOLOCK) 
			INNER JOIN [TCD].ControllerSetupData CSD ON cc.ControllerId=csd.ControllerId 
			AND CC.Active=1
			and CSD.FieldId=@TempFieldId
			and CSD.Value =@TempValue
			and CC.ControllerTypeId=@ControllerTypeId
			and CC.ControllerModelId=@ControllerModelId
			and CC.EcoalabAccountNumber=@EcolabAccountNumber)
BEGIN
SET @ErrorMessage = '305 -IP Address/AMS Net ID Address already exists.'

RAISERROR (
@ErrorMessage
,16
,1
)

RETURN
END

 BEGIN TRANSACTION

  BEGIN TRY
INSERT INTO @TempMaster (
      EcolabAccountNumber
,NAME
,ControllerModelId
,ControllerNumber
,ControllerTypeId
,ControllerVersion
,InstallDate
,UserId
,TopicName
,Active
     )
SELECT @EcolabAccountNumber
,CAST(Tbl.col.value('@ControllerNumber', 'int') AS VARCHAR(10)) + ' (' + Tbl.col.value('@TopicName', 'varchar(100)') + ')'
    ,Tbl.col.value('@ControllerModelId', 'int')
    ,Tbl.col.value('@ControllerNumber', 'int')
    ,Tbl.col.value('@ControllerTypeId', 'varchar(100)')
    ,Tbl.col.value('@ControllerVersion', 'varchar(10)')
    ,CAST(Tbl.col.value('@InstallDate', 'datetime') AS DATETIME)
    ,@UserId
    ,Tbl.col.value('@TopicName', 'varchar(100)')
,Tbl.col.value('@Active', 'bit')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)

INSERT INTO [TCD].ConduitController (
EcoalabAccountNumber
,Name
,ControllerModelId
,ControllerNumber
,ControllerTypeId
,ControllerVersion
,InstallDate
,TopicName
,Active
,LastModifiedByUserId
    )
OUTPUT inserted.ControllerId AS ControllerId
,inserted.LastModifiedTime AS LastModifiedTimestamp
INTO @OutputList(ControllerId, LastModifiedTimestamp)
SELECT EcolabAccountNumber
,NAME
,ControllerModelId
,ControllerNumber
,ControllerTypeId
,ControllerVersion
,InstallDate
,TopicName
,Active
,UserId
FROM @TempMaster
   
SELECT TOP 1 @ControllerId = O.ControllerId
FROM @OutputList O

update @TempDynamic set ControllerId=@ControllerId

INSERT INTO [TCD].ControllerSetupData (
       EcolabAccountNumber
,ControllerId
,FieldGroupId
,FieldId
,Value
,ControllerModelId
,LastModifiedByUserId
      )
SELECT EcolabAccountNumber
,ControllerId
,FieldGroupId
,FieldId
,Value
,ControllerModelId
,UserId
FROM @TempDynamic

IF @ControllerModelId = 7
OR @ControllerModelId = 8
OR @ControllerModelId = 9
OR @ControllerModelId = 11
OR @ControllerModelId = 10
OR @ControllerModelId = 14
BEGIN
EXEC TCD.SaveDefaultControllerEquipment @ControllerId = @ControllerId
,@EcolabAccountNumber = @EcolabAccountNumber
,@UserId = @UserId;
END;

SELECT @NumOfConvWasherGroups = NumOfConvWasherGroups
,@NumOfTunnelWasherGroups = NumOfTunnelWasherGroups
FROM TCD.ControllerModelControllerTypeMapping
WHERE ControllerModelId = @ControllerModelId
AND ControllerTypeId = @ControllerTypeId

DECLARE @TotalGroupCount INT = 0;
DECLARE @WasherDosingNumber INT = 0;

IF ISNULL(@NumOfConvWasherGroups, 0) > 0
BEGIN
WHILE @LoopCount < @NumOfConvWasherGroups
            BEGIN
                SET @WasherGroupName = @TopicName + ' Dosing Group ' + CAST(@TotalGroupCount + 1 AS VARCHAR(10));
                SET @WasherDosingNumber = @TotalGroupCount + 1;

                EXEC TCD.SaveMachineGroup @GroupDescription = @WasherGroupName
                    ,@GroupTypeId = 2
                    ,@EcolabAccountNumber = @EcolabAccountNumber;

                SELECT @WasherGroupId = Id
                FROM TCD.MachineGroup
                WHERE GroupDescription = @WasherGroupName

                SELECT @WasherGroupNumber = ISNULL(MAX(CAST(WasherGroupNumber AS INT)),0) + 1
                FROM TCD.WasherGroup

                EXEC TCD.SaveWasherGroup @EcolabAccountNumber = @EcolabAccountNumber
                    ,@WasherGroupId = @WasherGroupId
                    ,@ControllerId = @ControllerId
                    ,@WasherGroupTypeId = 1
                    ,@WasherGroupName = @WasherGroupName
                    ,@WasherGroupNumber = @WasherGroupNumber
                    ,@LastModifiedByUserId = 1
                    ,@WasherDosingNumber = @WasherDosingNumber ;

                SET @LoopCount += 1;
                SET @TotalGroupCount += 1;
            END
        END

        SET @LoopCount = 0;

        IF ISNULL(@NumOfTunnelWasherGroups, 0) > 0
        BEGIN
            WHILE @LoopCount < @NumOfTunnelWasherGroups
            BEGIN
                SET @WasherGroupName = @TopicName + ' Dosing Group ' + CAST(@TotalGroupCount + 1 AS VARCHAR(10));
                SET @WasherDosingNumber = @TotalGroupCount + 1;

                EXEC TCD.SaveMachineGroup @GroupDescription = @WasherGroupName
                    ,@GroupTypeId = 2
                    ,@EcolabAccountNumber = @EcolabAccountNumber;

                SELECT @WasherGroupId = Id
                FROM TCD.MachineGroup
                WHERE GroupDescription = @WasherGroupName

                SELECT @WasherGroupNumber = ISNULL(MAX(CAST(WasherGroupNumber AS INT)),0) + 1
                FROM TCD.WasherGroup

                EXEC TCD.SaveWasherGroup @EcolabAccountNumber = @EcolabAccountNumber
                    ,@WasherGroupId = @WasherGroupId
                    ,@ControllerId = @ControllerId
                    ,@WasherGroupTypeId = 2
                    ,@WasherGroupName = @WasherGroupName
                    ,@WasherGroupNumber = @WasherGroupNumber
                    ,@LastModifiedByUserId = 1
                    ,@WasherDosingNumber = @WasherDosingNumber;

                SET @LoopCount += 1;
                SET @TotalGroupCount += 1;
            END
        END

   DECLARE @TempControllerTypeId INT, 
		   @MaxInjectionClasses INT
   SELECT @TempControllerTypeId = ControllerTypeId FROM TCD.ConduitController WHERE ControllerId = @ControllerId

   IF (@TempControllerTypeId = 1)
   BEGIN
	SET @MaxInjectionClasses = 6
   END

    IF (@TempControllerTypeId = 2)
   BEGIN
	SET @MaxInjectionClasses = 8
   END
    
	UPDATE tcd.ConduitController SET LFSInjectionClasses = @MaxInjectionClasses where ControllerId = @ControllerId
 
   COMMIT TRANSACTION

        SELECT TOP 1 @OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp
        FROM @OutputList O
  END TRY

  BEGIN CATCH
        SELECT ERROR_NUMBER() AS ErrorNumber
            ,ERROR_SEVERITY() AS ErrorSeverity
            ,ERROR_STATE() AS ErrorState
            ,ERROR_PROCEDURE() AS ErrorProcedure
            ,ERROR_LINE() AS ErrorLine
            ,ERROR_MESSAGE() AS ErrorMessage

   ROLLBACK TRANSACTION
  END CATCH

SET NOCOUNT OFF
END
GO

------------------
IF EXISTS (SELECT  * FROM TCD.Field WHERE id=414 AND label='IP Address' AND DefaultValue='10.225.134.1')
      BEGIN
      UPDATE TCD.FIELD SET DEFAULTVALUE='10.225.134.10' WHERE id=414 AND label='IP Address'
     END
GO

	 
IF EXISTS (SELECT  * FROM TCD.Field WHERE id=387 AND label='IP Address' AND DefaultValue='10.225.134.1')
      BEGIN
      UPDATE TCD.FIELD SET DEFAULTVALUE='10.225.134.10' WHERE id=387 AND label='IP Address'
     END
Go

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetRewashFormulasByGroupId]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetRewashFormulasByGroupId]
END
GO
CREATE PROCEDURE [TCD].[GetRewashFormulasByGroupId] 
(
  @WasherGroupId INT,
  @EcolabAccountNumber VARCHAR(100)
 )
AS 
  BEGIN    
  SET NOCOUNT ON  
  DECLARE   @WasherGroupTypeName   VARCHAR(50)   =   NULL
  --Determine the WasherGroup type - Conventional/Tunnel
	SELECT @WasherGroupTypeName   =   WGT.WasherGroupTypeName
	FROM  [TCD].WasherGroup       WG
	JOIN  [TCD].WasherGroupType   WGT
	ON	  WG.WasherGroupTypeId    =   WGT.WasherGroupTypeId
	JOIN  [TCD].MachineGroup      GT
	ON    WG.WasherGroupId        =   GT.Id
	WHERE GT.EcolabAccountNumber  =   @EcoLabAccountNumber
	AND   WG.WasherGroupId		  =   @WasherGroupId
	
	IF ( @WasherGroupTypeName = 'Tunnel' )
	   BEGIN
			SELECT DISTINCT pm.ProgramId
			,	   pm.Name
			FROM TCD.TunnelProgramSetup tps
			INNER JOIN TCD.ProgramMaster pm 
			ON pm.ProgramId = tps.ProgramId
			AND pm.EcolabAccountNumber = tps.EcolabAccountNumber
			WHERE tps.WasherGroupId = @WasherGroupId
			AND   tps.EcolabAccountNumber = @EcolabAccountNumber
	   END
	ELSE
		BEGIN
			  SELECT pm.ProgramId
			  ,		 pm.Name 
			  FROM TCD.WasherProgramSetup wps
			  INNER JOIN TCD.ProgramMaster pm 
			  ON pm.ProgramId = wps.ProgramId 
			  AND pm.EcolabAccountNumber = wps.EcolabAccountNumber
			  WHERE wps.WasherGroupId = @WasherGroupId
			  AND   wps.EcolabAccountNumber = @EcolabAccountNumber
		END
 
  SET NOCOUNT OFF
  END
GO
-------------------------------------

IF EXISTS(SELECT * FROM sys.columns
            WHERE Name = N'ProgramNumber' AND Object_ID = Object_ID(N'[TCD].[TunnelTempSetup]'))
BEGIN
	EXEC sp_rename 'TCD.TunnelTempSetup.ProgramNumber', 'TunnelProgramSetupId', 'COLUMN';
END
GO

IF EXISTS (SELECT * FROM sys.columns
            WHERE Name = N'TunnelProgramSetupId' AND Object_ID = Object_ID(N'[TCD].[TunnelTempSetup]'))
BEGIN
	IF NOT EXISTS(SELECT * FROM SYS.foreign_keys fk 
		WHERE fk.name = 'Fk_TunnelTempSetup_TunnelProgramSetupId' AND fk.parent_object_id = Object_ID(N'[TCD].[TunnelTempSetup]'))
	
			ALTER TABLE [TCD].[TunnelTempSetup] 
			ADD CONSTRAINT Fk_TunnelTempSetup_TunnelProgramSetupId FOREIGN KEY (TunnelProgramSetupId)
			REFERENCES TCD.TunnelProgramSetup(TunnelProgramSetupId)	

END


IF EXISTS(SELECT * FROM sys.columns
            WHERE Name = N'GroupId' AND Object_ID = Object_ID(N'[TCD].[TunnelTempSetup]'))
BEGIN
	EXEC sp_rename 'TCD.TunnelTempSetup.GroupId', 'TunnelWasherId', 'COLUMN';
END
GO

IF NOT EXISTS (SELECT * FROM sys.columns
            WHERE Name = N'PlantId' AND Object_ID = Object_ID(N'[TCD].[TunnelTempSetup]'))
BEGIN
	ALTER TABLE [TCD].[TunnelTempSetup] ADD PlantId INT 
END

IF NOT EXISTS (SELECT * FROM sys.columns
            WHERE Name = N'ProductCheck' AND Object_ID = Object_ID(N'[TCD].[TunnelTempSetup]'))
BEGIN
	ALTER TABLE [TCD].[TunnelTempSetup] ADD ProductCheck BIT NULL
END

IF NOT EXISTS (SELECT * FROM sys.columns
            WHERE Name = N'PhRegLevel' AND Object_ID = Object_ID(N'[TCD].[TunnelDosingSetup]'))
BEGIN
	ALTER TABLE [TCD].[TunnelDosingSetup] ADD PhRegLevel INT NULL
END

IF NOT EXISTS (SELECT * FROM sys.columns
            WHERE Name = N'MonLevel' AND Object_ID = Object_ID(N'[TCD].[TunnelDosingSetup]'))
BEGIN
	ALTER TABLE [TCD].[TunnelDosingSetup] ADD MonLevel INT NULL
END

IF NOT EXISTS (SELECT * FROM sys.columns
            WHERE Name = N'ConRegLevel' AND Object_ID = Object_ID(N'[TCD].[TunnelDosingSetup]'))
BEGIN
	ALTER TABLE [TCD].[TunnelDosingSetup] ADD ConRegLevel INT NULL
END
-------------------------------------
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[FetchTunnelAnalogueControl]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.FetchTunnelAnalogueControl
	END
GO

 
/*
Purpose					:	To add a new Conventional Washer from the Washer setup UI - General tab

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version

--sp_helptext	usp_AddConventional

*/
CREATE PROCEDURE TCD.FetchTunnelAnalogueControl
(
	@EcolabAccountNumber VARCHAR(1000),	
	@TunnelProgramSetupId INT,
	@CompartmentNumber INT
)
AS 
BEGIN
	DECLARE @PlantId INT = (SELECT p.PlantId FROM tcd.Plant p WHERE EcolabAccountNumber = @EcolabAccountNumber)
	SELECT 
		tts.DesiredTemperature,
		tts.MinTime,
		tts.StartDelay,
		tts.AcceptDelay,
		tts.ProductCheck,
		tds.PhRegLevel,
		tds.MonLevel,
		tds.ConRegLevel,
		@TunnelProgramSetupId,
		@CompartmentNumber,
		@EcolabAccountNumber
		FROM  TCD.TunnelDosingSetup tds 
		INNER JOIN TCD.TunnelTempSetup tts 
		ON tds.TunnelProgramSetupId = tts.TunnelProgramSetupId
		AND tds.CompartmentNumber = tts.CompartmentNumber		
		WHERE 
		tts.PlantId = @PlantId		
		AND tds.EcolabAccountNumber = @EcolabAccountNumber 
		AND tds.TunnelProgramSetupId = @TunnelProgramSetupId
		AND tds.CompartmentNumber = @CompartmentNumber
END
GO
--------------------------------------
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetTunnelFormulaWashStep]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetTunnelFormulaWashStep
	END
GO
/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_GetTunnelFormulaWashStep]                                             

Purpose:				To get the tunnel formula wash step.

Parameters:				@EcoLabAccountNumber - holds ecolab account number.
						@ProgramSetupId - holds the program setup id.
						@DosingSetupId - holds the dosing setup id.
																
###################################################################################################                                           
*/

CREATE	PROCEDURE	[TCD].[GetTunnelFormulaWashStep]

					@EcoLabAccountNumber					NVARCHAR(1000)

				,	@ProgramSetupId							INT

				,	@DosingSetupId							INT				=	NULL			--Null for LIST
        
				,	@Is_Deleted								BIT				=  'FALSE'

AS

BEGIN

SET	NOCOUNT	ON
		
		DECLARE @WaterInletDrain VARCHAR(30) = NULL;
		SELECT @WaterInletDrain = NAME FROM [TCD].TunnelWaterInletDrainLookup TW WHERE TW.TunnelWaterInletDrainLookupId = 1;		

		SELECT		   TDS.[ProgramNumber]

			  ,TDS.[GroupId]

			  ,TDS.[EcolabAccountNumber]

			  ,ISNULL(TDS.StepTypeId, TC.WashStepId) AS StepTypeId

			  ,TDS.[StepRunTime]

			  ,TDS.[CompartmentNumber]

			  ,TDS.[Temperature]

			  ,TDS.[TunnelDosingSetupId]

			  ,TDS.[WaterType]

			  ,ISNULL(TDS.WaterLevel, TC.WaterLevel) AS WaterLevel

			  ,ISNULL(TWIDL.Name , @WaterInletDrain) AS WaterInletDrain

			  ,TDS.[Note]

			  ,TDS.[TunnelProgramSetupId]

			  ,(SELECT TunnelWaterFlowTypeName
				FROM TCD.TunnelWaterFlowType twft
				WHERE twft.TunnelWaterFlowTypeId = TC.WaterFlowId) AS WaterFlow
			  ,(SELECT WS.MyServiceWshOpId
				FROM TCD.WashStep ws
				WHERE ws.StepId	 = TC.WashStepId) AS MyServiceWshOpId
			  ,(SELECT WT.MyServiceUtilId
				FROM TCD.WaterType WT
				WHERE WT.Id	 = TDS.WaterType) AS MyServiceUtilId
			  ,(SELECT DD.MyServiceDrainTypeId
				FROM TCD.DrainDestination DD
				WHERE DD.DrainDestinationId = TDS.DrainDestinationId) AS MyServiceDrainTypId
			  ,TDS.Is_Deleted		As	IsDelete
			  ,TDS.MyServiceCustFrmulaStpGUID			  
			  ,(SELECT STUFF((SELECT ',' + CAST(S.SensorType AS VARCHAR(2))
					FROM TCD.Sensor S WHERE (S.MachineCompartment = TDS.CompartmentNumber OR S.MachineCompartment IS NULL)
						AND S.GroupId = MS.GroupId AND S.EcolabAccountNumber = @EcoLabAccountNumber GROUP BY S.SensorType
					FOR XML PATH('')) ,1,1,'')) AS SensorAttached
		FROM 
		[TCD].TunnelDosingSetup TDS
		INNER JOIN [TCD].MachineSetup MS ON MS.GroupId = TDS.GroupId
		AND MS.EcoalabAccountNumber = TDS.EcolabAccountNumber	
		LEFT JOIN [TCD].TunnelCompartment TC ON TC.WasherId = MS.WasherId AND TC.CompartmentNumber = TDS.CompartmentNumber AND TC.EcoLabAccountNumber = TDS.EcolabAccountNumber
		LEFT JOIN [TCD].TunnelWaterInletDrainLookup TWIDL ON TWIDL.TunnelWaterInletDrainLookupId = TC.WaterInletDrainId			
		WHERE 

		TDS.EcolabAccountNumber = @EcoLabAccountNumber 

		AND TDS.TunnelProgramSetupId = @ProgramSetupId

		AND	TDS.TunnelDosingSetupId	=	ISNULL(@DosingSetupId, TDS.TunnelDosingSetupId)

		AND (TDS.Is_Deleted						=			'False' OR TDS.Is_Deleted = @Is_Deleted)
    
		AND (MS.IsDeleted						  =			'False')

		ORDER BY TDS.[CompartmentNumber]

SET	NOCOUNT	OFF

END
GO
--------------------------------------------------------------------
 IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[SaveTunnelAnalogueControl]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.SaveTunnelAnalogueControl
	END
GO

/*
Purpose					:	To Save Tunnel Analogue Control while saving tunnel Wash Step

--sp_helptext	'[TCD].[SaveTunnelAnalogueControl]'

*/

CREATE PROCEDURE	[TCD].[SaveTunnelAnalogueControl]
	@EcolabAccountNumber NVARCHAR(25),
	@TunnelProgramSetupId INT,	
	@TempSetPoint INT,
	@MinTime INT,
	@StartDelay INT,
	@AcceptDelay INT,
	@CompartmentNumber INT,
	@ProductCheck BIT= NULL,
	@PhRegLevel INT = NULL,
	@MonLevel INT = NULL,
	@ConRegLevel INT = NULL
AS
BEGIN

	DECLARE @PlantId INT = ( SELECT p.PlantId FROM TCD.PLANT p WHERE p.EcolabAccountNumber = @EcolabAccountNumber);

	IF EXISTS (SELECT 1 FROM TCD.TunnelDosingSetup tds 
		WHERE tds.TunnelProgramSetupId = @TunnelProgramSetupId AND tds.CompartmentNumber = @CompartmentNumber AND EcolabAccountNumber = @EcolabAccountNumber)
		BEGIN
			UPDATE TCD.TunnelDosingSetup
			SET		    
			    TCD.TunnelDosingSetup.PhRegLevel = @PhRegLevel,
			    TCD.TunnelDosingSetup.MonLevel = @MonLevel, 
			    TCD.TunnelDosingSetup.ConRegLevel = @ConRegLevel				
			WHERE TunnelProgramSetupId = @TunnelProgramSetupId AND EcolabAccountNumber = @EcolabAccountNumber 
			AND CompartmentNumber = @CompartmentNumber
		END

	IF EXISTS (SELECT * FROM TCD.TunnelTempSetup tts WHERE tts.TunnelProgramSetupId = @TunnelProgramSetupId AND tts.PlantId = @PlantId AND CompartmentNumber = @CompartmentNumber)
	BEGIN
		UPDATE TCD.TunnelTempSetup
			SET		    
				TCD.TunnelTempSetup.DesiredTemperature = @TempSetPoint,
				TCD.TunnelTempSetup.MinTime = @MinTime, 
				TCD.TunnelTempSetup.StartDelay = @StartDelay,
				TCD.TunnelTempSetup.AcceptDelay = @AcceptDelay,					
				TCD.TunnelTempSetup.ProductCheck = @ProductCheck
			WHERE TunnelProgramSetupId = @TunnelProgramSetupId AND PlantId = @PlantId AND CompartmentNumber = @CompartmentNumber		
	END
	ELSE 
		BEGIN		
			INSERT INTO TCD.TunnelTempSetup
			(
				TunnelProgramSetupId,					    
				DesiredTemperature,
				MinTime,
				StartDelay,
				AcceptDelay,
				CompartmentNumber,
				ProductCheck,
				PlantId
			)
			VALUES
			(
				@TunnelProgramSetupId, 				
				@TempSetPoint, 
				@MinTime, 
				@StartDelay, 
				@AcceptDelay, 
				@CompartmentNumber,
				@ProductCheck,
				@PlantId	    
			)
		END

END
GO
---------------------------------------
 IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[SaveTunnelDosingProduct]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.SaveTunnelDosingProduct
	END
GO

/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_SaveTunnelDosingProduct]                                             

Purpose:				To add the tunnel group wash steps formula.

Parameters:				@EcoLabAccountNumber - holds ecolab account number.
						@ControllerEquipmentSetupId - holds the controller equipment setup id.
						@TunnelDosingSetupId - holds the tunnel dosing setup id.
						@WasherGroupId - holds the washer group id.
						@CompartmentNumber - holds the compartment number.
						@Quantity - holds the quantity.
						@DelayTime - holds the delay time.
						@UserId - holds the user id.
						@DeleteFlag	- holds the boolean value weather it is deleted or not
																
###################################################################################################                                           
*/
CREATE	PROCEDURE	[TCD].[SaveTunnelDosingProduct]	(
					@EcoLabAccountNumber					NVARCHAR(1000)
				,	@ControllerEquipmentSetupId				INT			= NULL		
				,	@TunnelProgramSetupId					INT	
				,	@TunnelDosingSetupId					INT			= NULL						
				,	@WasherGroupId							INT						--WasherGroupId to which the formula is associated
				,	@CompartmentNumber						INT						--Compartment no. of the tunnel to which the formula will/is(?) associated
				,	@Quantity								DECIMAL(18,3)	= NULL
				,	@DelayTime								INT				= NULL
				,	@UserId									INT
				,	@DeleteFlag								BIT			=			'FALSE'	--DO NOT SET THIS (to TRUE) UNLESS DELETE IS INTENDED
				,	@LastModifiedTimestampAtCentral			DATETIME					=	NULL
				,	@OutputLastModifiedTimestampAtLocal		DATETIME					=	NULL	OUTPUT
				)
AS 
BEGIN 
DECLARE 
@CurrentUTCTime					DATETIME		=			GETUTCDATE(),
@MyServiceFrmulaStpDsgDvcGuid	UNIQUEIDENTIFIER	=			NEWID(),
@ReturnValue					INT				=			0,
@IsDrain						NVARCHAR(100)	=			N''

DECLARE
			@OutputList								AS	TABLE		(
			LastModifiedTimestamp					DATETIME
		)

SELECT @IsDrain	= StepName FROM tcd.WashStep WHERE StepId=(SELECT StepTypeId FROM tcd.TunnelDosingSetup 
		WHERE TunnelDosingSetupId=@TunnelDosingSetupId AND GroupId=@WasherGroupId AND CompartmentNumber= @CompartmentNumber)

IF @IsDrain = 'Drain'
BEGIN
	SET @Quantity = 0
END

IF	(	@DeleteFlag	<>	'TRUE'	)
BEGIN
IF EXISTS(select * from TCD.TunnelDosingProductMapping where TunnelDosingSetupId = @TunnelDosingSetupId AND ControllerEquipmentSetupId = @ControllerEquipmentSetupId)
BEGIN
	UPDATE TCD.TunnelDosingProductMapping
	SET Quantity = @Quantity, DelayTime = @DelayTime where TunnelDosingSetupId = @TunnelDosingSetupId AND ControllerEquipmentSetupId = @ControllerEquipmentSetupId
END
ELSE
BEGIN
	INSERT INTO	[TCD].TunnelDosingProductMapping (
									EcoLabAccountNumber
								,	TunnelDosingSetupId
								,	Quantity
								,	DelayTime
								,	CompartmentNumber
								,	GroupId
								,	ControllerEquipmentSetupId
								,	LastModifiedByuserId
								,	MyServiceFrmulaStpDsgDvcGuid
								)
							SELECT
									@EcoLabAccountNumber			AS			EcoLabAccountNumber
								,	@TunnelDosingSetupId			AS			TunnelDosingSetupId
								,	@Quantity						AS			Quantity
								,	@DelayTime						AS			DelayTime
								,	@CompartmentNumber				AS			CompartmentNumber
								,	@WasherGroupId					AS			GroupId
								,	@ControllerEquipmentSetupId		AS			ControllerEquipmentSetupId
								,	@UserId							AS			UserId
								,	@MyServiceFrmulaStpDsgDvcGuid	AS			MyServiceFrmulaStpDsgDvcGuid

								UPDATE TCD.TunnelProgramSetup
								SET
								LastModifiedTime = @CurrentUTCTime
								OUTPUT
									inserted.LastModifiedTime		AS			LastModifiedTimestamp
								INTO
									@OutputList	(
									LastModifiedTimestamp
								)
								WHERE 
								TunnelProgramSetupId = @TunnelProgramSetupId
								AND
								EcolabAccountNumber = @EcolabAccountNumber
END

SET		@OutputLastModifiedTimestampAtLocal			=			ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight SA0121
SET		@LastModifiedTimestampAtCentral				=			ISNULL(@LastModifiedTimestampAtCentral, NULL)				--SQLEnlight SA0029

SELECT	TOP 1	
		@OutputLastModifiedTimestampAtLocal		=	O.LastModifiedTimestamp
FROM	@OutputList	O

END
RETURN	(@ReturnValue)
END
GO
---------------------------------------
 IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[CopyTunnelFormula]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.[CopyTunnelFormula]
	END
GO
CREATE PROCEDURE [TCD].[CopyTunnelFormula]
		 @ToWasherGroupId                            INT								=            NULL
    ,    @FromWasherGroupId                          INT								=            NULL
    ,    @ProgramNumber                              SMALLINT							=            NULL 
    ,    @WasherProgramSetupId                       INT								=            NULL
    ,    @ProgramId                                  INT								=            NULL
    ,    @EcoLabAccountNumber                        NVARCHAR(1000)						=            NULL
    ,    @UserId                                     INT								=            NULL
    ,    @ProgramSetupId                             INT								=            NULL   OUTPUT 
	

AS
BEGIN
    SET NOCOUNT ON;

    DECLARE      @TotalNumberOfPrograms      SMALLINT        =       NULL
    ,            @ReturnValue                INT             =       0
    ,            @ErrorId                    INT             =       0
    ,            @ErrorMessage               NVARCHAR(4000)  =       N''
    ,            @MaxNumberOfPrograms        SMALLINT        =       127
	,			 @PlantId INT

	SET @PlantId = (SELECT p.PlantId FROM tcd.Plant p WHERE EcolabAccountNumber = @EcolabAccountNumber)

    DECLARE
                @OutputList                                AS    TABLE        (
                OutputProgramSetupId                       INT
        )

    --ProgramNumber check
    IF    (    @ProgramNumber                >            @MaxNumberOfPrograms)
    BEGIN
            SET        @ErrorId                        =            51002
            SET        @ErrorMessage                    =            N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Invalid ProgramNumber... Aborting.'
            --GOTO    ErrorHandler
            RAISERROR    (@ErrorMessage, 16, 1)
            SET    @ReturnValue    =    -1
            RETURN    (@ReturnValue)
    END

        --Check for unique ProgramNumber
        IF    EXISTS    (        SELECT    1
                            FROM    [TCD].TunnelProgramSetup            TPS
                            WHERE    TPS.EcolabAccountNumber        =            @EcoLabAccountNumber
                                AND    TPS.WasherGroupId            =            @ToWasherGroupId
                                AND    TPS.ProgramNumber            =            @ProgramNumber
                                AND    TPS.Is_Deleted                =            'FALSE'
                    )
                BEGIN
                        SET        @ErrorId            =            51001
                        SET        @ErrorMessage        =            N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Specified ProgramNumber for the WasherGroup already exists for the plant.'
                        --GOTO    ErrorHandler
                        RAISERROR    (@ErrorMessage, 16, 1)
                        SET    @ReturnValue    =    -1
                        RETURN    (@ReturnValue)
                END

        --Check for total number of programs/formulae associated
        SELECT    @TotalNumberOfPrograms        =            COUNT(TPS.ProgramNumber)
        FROM    [TCD].TunnelProgramSetup                        TPS
        WHERE    TPS.EcolabAccountNumber        =            @EcoLabAccountNumber
            AND    TPS.WasherGroupId            =            @ToWasherGroupId
            AND    TPS.Is_Deleted                =            'FALSE'
        
        IF    (    @TotalNumberOfPrograms        =            @MaxNumberOfPrograms    )
            BEGIN
                    SET        @ErrorId        =            51000
                    SET        @ErrorMessage    =            N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Maximum Number of programs that can be associated to a WasherGroup already defined... Aborting.'
                    --GOTO    ErrorHandler
                    RAISERROR    (@ErrorMessage, 16, 1)
                    SET    @ReturnValue    =    -1
                    RETURN    (@ReturnValue)
            END

        INSERT INTO TCD.TunnelProgramSetup
        (
            --TunnelProgramSetupId - this column value is auto-generated
            EcolabAccountNumber,
            WasherGroupId,
            ProgramNumber,
            [Description],
            ProgramId,
            NominalLoad,
            LoadsPerMonth,
            TotalRunTime,
            ExtraTime,
            NumberOfDrains,
            DrainTime,
            Category,
            CleanWt,
            CleanAw,
            CustomerId,
            Rewash,
            Is_Deleted,
            LastModifiedByUserId,
            MyServiceCustFrmulaMchGrpGUID,
            LastModifiedTime
        )
        OUTPUT
            INSERTED.TunnelProgramSetupId    AS    Id
        INTO
            @OutputList(
                    OutputProgramSetupId
                       )
        SELECT    tps.EcolabAccountNumber
        ,        @ToWasherGroupId
        ,        @ProgramNumber
        ,        tps.[Description]
        ,        @ProgramId
        ,        tps.NominalLoad
        ,        tps.LoadsPerMonth
        ,        tps.TotalRunTime
        ,        tps.ExtraTime
        ,        tps.NumberOfDrains
        ,        tps.DrainTime
        ,        tps.Category
        ,        tps.CleanWt
        ,        tps.CleanAw
        ,        tps.CustomerId
        ,        tps.Rewash
        ,        tps.Is_Deleted
        ,        @UserId
        ,        NEWID()
        ,        GETUTCDATE()
        FROM TCD.TunnelProgramSetup tps
        WHERE tps.EcolabAccountNumber    =    @EcoLabAccountNumber
        AND      tps.TunnelProgramSetupId  =    @WasherProgramSetupId
        AND   tps.WasherGroupId            =    @FromWasherGroupId

         --check for any error
            SET    @ErrorId    =    @@ERROR
    
            IF    (@ErrorId    <>    0)
                BEGIN
                        SET        @ErrorMessage    =            N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred associating formula to the conventional washer group.'
                        --GOTO    ErrorHandler
                        RAISERROR    (@ErrorMessage, 16, 1)
                        SET    @ReturnValue    =    -1
                        RETURN    (@ReturnValue)
                END

        SELECT  TOP 1 @ProgramSetupId    =   O.OutputProgramSetupId FROM @OutputList O

        INSERT INTO TCD.TunnelDosingSetup
        (
            --TunnelDosingSetupId - this column value is auto-generated
            EcolabAccountNumber,
            TunnelProgramSetupId,
            GroupId,
            ProgramNumber,
            StepNumber,
            StepTypeId,
            ProductId,
            StepRunTime,
            CompartmentNumber,
            MachineNumber,
            Quantity,
            [Delay],
            DosingNumber,
            Temperature,
            WaterType,
            WaterLevel,
            DrainDestinationId,
            pHLevel,
            WaterInletDrain,
            Note,
            Is_Deleted,
            LastModifiedByUserId,
            MyServiceCustFrmulaStpGUID,
            StandardWaterUsage,
			PhRegLevel,
			MonLevel,
			ConRegLevel
        )
        SELECT tds.EcolabAccountNumber
        , @ProgramSetupId
        , @ToWasherGroupId
        , tds.ProgramNumber
        , tds.StepNumber
        , tds.StepTypeId
        , tds.ProductId
        , tds.StepRunTime
        , tds.CompartmentNumber
        , tds.MachineNumber
        , tds.Quantity
        , tds.[Delay]
        , tds.DosingNumber
        , tds.Temperature
        , tds.WaterType
        , tds.WaterLevel
        , tds.DrainDestinationId
        , tds.pHLevel
        , tds.WaterInletDrain
        , tds.Note
        , 'False'
        , @UserId
        , NEWID()
        , tds.StandardWaterUsage
		, tds.PhRegLevel
		, tds.MonLevel
		, tds.ConRegLevel
        FROM TCD.TunnelDosingSetup tds
        WHERE tds.TunnelProgramSetupId = @WasherProgramSetupId
        AND        tds.EcolabAccountNumber = @EcoLabAccountNumber
        AND        tds.Is_Deleted    = 'False'

        --check for any error
            SET    @ErrorId    =    @@ERROR
    
            IF    (@ErrorId    <>    0)
                BEGIN
                        SET        @ErrorMessage    =            N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred associating formula to the conventional washer group.'
                        --GOTO    ErrorHandler
                        RAISERROR    (@ErrorMessage, 16, 1)
                        SET    @ReturnValue    =    -1
                        RETURN    (@ReturnValue)
                END
        
        SELECT tc.CompartmentNumber, ces.ProductId, tcem.ControllerEquipmentSetupId INTO #Tunnel1 FROM TCD.TunnelCompartmentEquipmentMapping tcem
        INNER JOIN TCD.TunnelCompartment tc
        ON tc.TunnelCompartmentId = tcem.TunnelCompartmentId AND tc.EcoLabAccountNumber = tcem.EcoLabAccountNumber AND tcem.Is_Deleted = 0
        INNER JOIN TCD.MachineSetup ms
        ON ms.WasherId = tc.WasherId AND ms.EcoalabAccountNumber = tc.EcoLabAccountNumber AND ms.IsDeleted = 0
        INNER JOIN TCD.WasherGroup wg
        ON wg.WasherGroupId = ms.GroupId
        LEFT JOIN TCD.ControllerEquipmentSetup ces 
        ON ces.ControllerEquipmentSetupId = tcem.ControllerEquipmentSetupId
        WHERE wg.WasherGroupId = @ToWasherGroupId


        INSERT TCD.TunnelDosingProductMapping
        (
            --TunnelDosingProductMappingId - this column value is auto-generated
            EcoLabAccountNumber,
            TunnelDosingSetupId,
            GroupId,
            CompartmentNumber,
            ControllerEquipmentSetupId,
            InjectionNumber,
            ProductId,
            Quantity,
            LastModifiedByUserId,
            LastModifiedTime,
            MyServiceFrmulaStpDsgDvcGuid,
            DelayTime
        )
        SELECT tdpm.EcoLabAccountNumber
        , tds2.TunnelDosingSetupId
        , @ToWasherGroupId
        , tdpm.CompartmentNumber
        , t.ControllerEquipmentSetupId
        , tdpm.InjectionNumber
        , tdpm.ProductId
        , tdpm.Quantity
        , @UserId
        , GETUTCDATE()
        , NEWID()
        , tdpm.DelayTime 
        FROM TCD.TunnelDosingProductMapping tdpm
        INNER JOIN TCD.TunnelDosingSetup tds
        ON tds.TunnelDosingSetupId = tdpm.TunnelDosingSetupId
        AND tds.EcolabAccountNumber = tdpm.EcoLabAccountNumber
        LEFT JOIN TCD.TunnelDosingSetup tds2
        ON tds2.CompartmentNumber = tds.CompartmentNumber
        AND tds2.EcolabAccountNumber = tds.EcolabAccountNumber
        AND tds2.TunnelProgramSetupId = @ProgramSetupId
        INNER JOIN TCD.ControllerEquipmentSetup ces 
        ON ces.ControllerEquipmentSetupId = tdpm.ControllerEquipmentSetupId
        INNER JOIN #Tunnel1 t
        ON t.CompartmentNumber = tdpm.CompartmentNumber
        AND t.ProductId = ces.ProductId
        WHERE tds.TunnelProgramSetupId = @WasherProgramSetupId
        AND tds.Is_Deleted = 'False'
        ORDER BY tds.CompartmentNumber	


		INSERT INTO TCD.TunnelTempSetup
			(
				TunnelProgramSetupId,					    
				DesiredTemperature,
				MinTime,
				StartDelay,
				AcceptDelay,
				CompartmentNumber,
				ProductCheck,
				PlantId
			)
			SELECT 
			@ProgramSetupId,
			tts.DesiredTemperature,
			tts.MinTime,
			tts.StartDelay,
			tts.AcceptDelay,
			tts.CompartmentNumber,
			tts.ProductCheck,
			tts.PlantId
			FROM  TCD.TunnelDosingSetup tds 
			INNER JOIN TCD.TunnelTempSetup tts 
			ON tds.TunnelProgramSetupId = tts.TunnelProgramSetupId
			AND tds.CompartmentNumber = tts.CompartmentNumber		
			WHERE 
			tts.PlantId = @PlantId		
			AND tds.EcolabAccountNumber = @EcolabAccountNumber 
			AND tds.TunnelProgramSetupId = @WasherProgramSetupId			

-- CleanUp
        DROP TABLE #Tunnel1

    IF    (    @ErrorId    =    0    )
    BEGIN
        --GOTO    ExitModule
        RETURN    (@ReturnValue)
    END

    SET    NOCOUNT    OFF
    RETURN    (@ReturnValue)
END
GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[UpdateMyServicePlantDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.UpdateMyServicePlantDetails
	END
GO

CREATE PROCEDURE [TCD].[UpdateMyServicePlantDetails]
					@EcolabAccountNumber					NVARCHAR(1000)
				,	@Name									NVARCHAR(150)
				,	@DataLiveTime							INT					=	NULL
				,	@BudgetCustomer							BIT					=	NULL
				,	@ExportPath								NVARCHAR(250)		=	NULL
				,	@LanguageId								INT					=	NULL
				,	@CurrencyCode							NVARCHAR(255)		=	NULL
				,	@PlantCategoryId						INT					=	NULL
				,	@AcutalIsTarget							BIT					=	NULL
				,	@PlantChainId							INT					=	NULL
				,	@TMName									NVARCHAR(1000)		=	NULL
				,	@TMPhoneNumber							NVARCHAR(100)		=	NULL
				,	@DMName									NVARCHAR(1000)		=	NULL
				,	@DMPhoneNumber							NVARCHAR(100)		=	NULL
				,	@ChainUnitNumber						NVARCHAR(100)		=	NULL
				,	@CensusPriceKg							NUMERIC(12, 4)		=	NULL
				,	@Remarks								NVARCHAR(1000)		=	NULL
				,	@Rate									INT					=	NULL
				,	@UserID									INT					=	NULL
				,	@AllowManualRewash						BIT					=	NULL
				,	@MyServiceCustGuid						UNIQUEIDENTIFIER	=	NULL
				,	@RegionCode								NVARCHAR(100)		=	NULL
				,	@RegionId								INT					=	NULL
				,	@IsDelete								BIT					=	NULL
				,	@UOMDesc								NVARCHAR(100)		=	NULL
				,	@UOMId									INT					=	NULL
				,	@PlantContractNumber					NVARCHAR(10)		=	NULL
				,	@PlantId								INT					=	NULL
				,	@DayId									INT					=	NULL
				,	@StartTime								TIME(7)				=	NULL
				,	@IsEtechEnable							BIT					=	NULL
				,	@EtechIpAddress							NVARCHAR(25)		=	NULL
				,	@LastServiceVisitDate					datetime			=	NULL
				,	@NextServiceVisitDate					datetime			=	NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

DECLARE		@CurrentUtcTime DATETIME	=	GETUTCDATE()
		,	@ErrorId		INT			=	0

IF NOT	EXISTS (SELECT 1 FROM TCD.Plant WHERE EcolabAccountNumber = @EcolabAccountNumber)
	BEGIN
	SET  Identity_Insert tcd.USERMASTER  On
		IF NOT EXISTS (SELECT 1 FROM TCD.UserMaster WHERE UserId = 0)
			
			BEGIN
				
				INSERT INTO [TCD].[UserMaster] ([UserId], [FirstName], [LastName], [FullName], [LoginName], [Password], [Phone], [LanguageId], [UOMId], [Email], [IsActive],
				[LastLoggedIn],[LastModifiedByUserId],[EcolabAccountNumber])
				VALUES (0, N'Default', N'User', N'Default Test', N'Default', N'baloce', N'123456789', 1, 1, N'default@ecolab.com', 0,
				CAST(0x0000A3AB00263AAB AS DateTime),0,@EcolabAccountNumber)
				
				SET @ErrorId = @@ERROR

				IF @ErrorId = 0
					BEGIN
						INSERT INTO [TCD].[UserInRole] ([EcoLabAccountNumber],[UserId],[RoleId],IsDeleted,[LastModifiedByUserId]) 
						VALUES  (@EcolabAccountNumber,0,4,1,0)

						INSERT INTO [TCD].[UserProfile] ([UserId],[EcolabAccountNumber],[LastModifiedByUserId])
						VALUES (0,@EcolabAccountNumber,0)

					SET @ErrorId = @@ERROR
					END
			END
			
		ELSE
			BEGIN
				UPDATE [TCD].[UserMaster]
					SET [Password] = N'baloce',
					EcolabAccountNumber = @EcolabAccountNumber 
				WHERE UserId = 0
			END

		IF NOT EXISTS (SELECT 1 FROM TCD.UserMaster WHERE UserId = 1)
			BEGIN
				INSERT INTO [TCD].[UserMaster] ([UserId], [FirstName], [LastName], [FullName], [LoginName], [Password], [Phone], [LanguageId], [UOMId], [Email], [IsActive],
				[LastLoggedIn],[LastModifiedByUserId],[EcolabAccountNumber])
				VALUES (1, N'Adminstrator', N'User', N'Adminstrator User', N'Admin', N'baloce', N'123456789', 1, 1, N'Admin@ecolab.com', 1,
						CAST(0x0000A3AB00263AAB AS DateTime),0,@EcolabAccountNumber)
				
				SET @ErrorId = @@ERROR

				IF @ErrorId = 0
					BEGIN
						INSERT INTO [TCD].[UserInRole] ([EcoLabAccountNumber],[UserId],[RoleId],IsDeleted,[LastModifiedByUserId]) 
						VALUES  (@EcolabAccountNumber,1,4,0,0)

						INSERT INTO [TCD].[UserProfile] ([UserId],[EcolabAccountNumber],[LastModifiedByUserId])
						VALUES (1,@EcolabAccountNumber,0)
					SET @ErrorId = @@ERROR
					END
			END
		ELSE
			BEGIN
				UPDATE [TCD].[UserMaster]
					SET [Password] = N'baloce',
					EcolabAccountNumber = @EcolabAccountNumber
				WHERE UserId = 1
			END
SET  Identity_Insert tcd.UserMaster Off

			INSERT INTO [TCD].[Plant]
				   ([PlantId]
				   ,[EcolabAccountNumber]
				   ,[Name]
				   ,[DataLiveTime]
				   ,[BudgetCustomer]
				   ,[ExportPath]
				   ,[LanguageId]
				   ,[UOMId]
				   ,[CurrencyCode]
				   ,[PlantCategoryId]
				   ,[AcutalIsTarget]
				   ,[RegionId]
				   ,[PlantChainId]
				   ,[CreatedOn]
				   ,[CreatedBy]
				   ,[ModifiedOn]
				   ,[ModifiedBy]
				   ,[TMName]
				   ,[TMPhoneNumber]
				   ,[DMName]
				   ,[DMPhoneNumber]
				   ,[ChainUnitNumber]
				   ,[CensusPriceKg]
				   ,[Remarks]
				   ,[Rate]
				   ,[Is_Deleted]
				   ,[LastModifiedByUserId]
				   ,[AllowManualRewash]
				   ,[LastModifiedTime]
				   ,[MyServiceCustGuid]
				   ,[MyServiceLastSynchTime]
				   ,[PlantContractNumber]
				   ,[ConStdTurnTime]
				   ,[DayId]
				   ,[StartTime]
				   ,[IsETechEnable]
				   ,[ETechIpAddress] 
				   ,[LastServiceVisitDate]
				   ,[NextServiceVisitDate])
		 VALUES
			   (@PlantId
			   ,@EcolabAccountNumber
			   ,@Name
			   ,@DataLiveTime
			   ,@BudgetCustomer
			   ,@ExportPath
			   ,@LanguageId
			   ,@UOMId
			   ,@CurrencyCode
			   ,@PlantCategoryId
			   ,@AcutalIsTarget
			   ,@RegionId
			   ,@PlantChainId
			   ,@CurrentUtcTime
			   ,@UserId
			   ,@CurrentUtcTime
			   ,@UserId
			   ,@TMName
			   ,@TMPhoneNumber
			   ,@DMName
			   ,@DMPhoneNumber
			   ,@ChainUnitNumber
			   ,@CensusPriceKg
			   ,@Remarks
			   ,@Rate
			   ,@IsDelete
			   ,@UserId
			   ,@AllowManualRewash
			   ,@CurrentUtcTime
			   ,@MyServiceCustGuid
			   ,@CurrentUtcTime
			   ,@PlantContractNumber
			   ,30
			   ,@DayId 
               ,@StartTime
               ,@IsEtechEnable
               ,@EtechIpAddress
			   ,@LastServiceVisitDate
			   ,@NextServiceVisitDate
			   )

		SET @ErrorId = @@ERROR
	END
ELSE
	BEGIN 
		UPDATE [TCD].[Plant]
		SET 
		   [Name]					=	@Name
		  ,[TMName]					=	@TMName
		  ,[TMPhoneNumber]			=	@TMPhoneNumber
		  ,[DMName]					=	@DMName
		  ,[DMPhoneNumber]			=	@DMPhoneNumber
		  ,[ChainUnitNumber]		=	@ChainUnitNumber
		  ,[CensusPriceKg]			=	@CensusPriceKg
		  ,[Remarks]				=	@Remarks
		  ,[LanguageId]				=	@LanguageId
		  ,[CurrencyCode]			=	@CurrencyCode
		  ,[RegionId]				=	@RegionId
		  ,[UOMId]					=	@UOMId
		  ,[PlantChainId]			=	@PlantChainId
		  ,[Is_Deleted]				=	@IsDelete
		  ,[MyServiceCustGuid]		=	@MyServiceCustGuid
		  ,[MyServiceLastSynchTime]	=	@CurrentUtcTime
		  ,[PlantContractNumber]	=	@PlantContractNumber
		  ,[DayId]					=	@DayId
          ,[StartTime]				=	@StartTime
          ,[IsETechEnable]			=	@IsEtechEnable
          ,[ETechIpAddress]			=	@EtechIpAddress
		  ,[LastServiceVisitDate]	=	@LastServiceVisitDate
		  ,[NextServiceVisitDate]	=	@NextServiceVisitDate
		WHERE 
		   [EcolabAccountNumber]	=	@EcolabAccountNumber

		SET @ErrorId = @@ERROR
	END

SELECT @ErrorId
END
GO
----------------------------------------
IF NOT EXISTS(SELECT
				  *
			  FROM sys.columns
			  WHERE object_id = OBJECT_ID(N'TCD.Washer')
				AND name = 'SignalAcceptanceTime')
	BEGIN
		ALTER TABLE TCD.Washer ADD SignalAcceptanceTime INT NULL;
	END;
GO

-----------------------------------------
IF NOT EXISTS(SELECT
				  *
			  FROM sys.columns
			  WHERE object_id = OBJECT_ID(N'TCD.Washer')
				AND name = 'KannegiesserDosageInPreparationTankMode')
	BEGIN
		ALTER TABLE TCD.Washer ADD KannegiesserDosageInPreparationTankMode bit NULL;
	END;
GO
----------------------------------------------
IF NOT EXISTS(SELECT
				  *
			  FROM sys.columns
			  WHERE object_id = OBJECT_ID(N'TCD.Washer')
				AND name = 'BatchOk')
	BEGIN
		ALTER TABLE TCD.Washer ADD BatchOk bit NULL;
	END;
GO

------------------------------------------------
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[AddConventional]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.AddConventional
	END
GO

CREATE PROCEDURE	[TCD].[AddConventional]
					@EcoLabAccountNumber					NVARCHAR(1000)
				,	@WasherGroupId							INT
				, @NewWasherGroupId		int				=	null
				,	@ConventionalName						NVARCHAR(50)
				,	@ModelId								INT						--(Washer)Model Id for Size
				,	@ControllerId							INT
				,	@LFSWasherNumber						TINYINT					=	NULL
				,	@PlantWasherNumber						SMALLINT
				,	@WasherMode								TINYINT
				,	@MaxLoad								SMALLINT
				,	@AWEActive								BIT
				,	@HoldSignal								BIT
				,	@HoldDelay								SMALLINT															
				,	@TargetTurnTime							SMALLINT
				,	@WaterFlushTime							SMALLINT
				,	@ProgramNumber							TINYINT					--EOF number
				,	@Description							NVARCHAR(1024)			=	NULL
				,	@UserId									INT
				,	@ConventionalWasherGuid					UniqueIdentifier
				,	@ConventionalWasherId					INT									OUTPUT
				,	@LastModifiedTimestampAtCentral			DATETIME				=	NULL
				,	@OutputLastModifiedTimestampAtLocal		DATETIME				=	NULL	OUTPUT
				,	@IsDeleted								BIT						=	'FALSE'
				,   @RatioDosingActive						BIT						=	'FALSE'
,   @IsPony      BIT      = 'FALSE'
				,	@MinMachineLoad							SMALLINT				=	NULL
				,	@MaxMachineLoad							smallint				=	NULL
				,	@ProgramSelectionByTime					bit						=	NULL
				,	@FlowSwitchNumber						int						=	NULL
				,	@WasherStopExternalSignal				bit						=	NULL
				,	@OnHoldWESignalActive					bit						=	NULL
				,	@WasherOnHoldSignalDelay				int						=	NULL
				,	@ValveOutputsUsedAsTomSignal			bit						=	NULL
				,	@WeInTomMode							bit						=	NULL
				,	@ManifoldFlushTime						int						=	NULL
				,	@L1										bit						=	NULL
				,	@L2										bit						=	NULL
				,	@L3										bit						=	NULL
				,	@L4										bit						=	NULL
				,	@L5										bit						=	NULL
				,	@L6										bit						=	NULL
				,	@L7										bit						=	NULL
				,	@L8										bit						=	NULL
				,	@L9										bit						=	NULL
				,	@L10									bit						=	NULL
				,	@L11									bit						=	NULL
				,	@L12									bit						=	NULL
				,	@MyServiceLastSyncTime					DATETIME				=	NULL
				,	@UseMe1OfGroup							tinyint					=	NULL
				,	@UseMe2OfGroup							tinyint					=	NULL
				,	@UsePumpOfGroup							tinyint					=	NULL
				,	@WasherStopUseFinalExtracting			bit						=	NULL
				,	@TemperatureAlarmYesNo					bit						=	NULL
				,   @DefaultIdleTime						INT						=   NULL
				,   @ETechWasherNumber						INT						=   NULL
				,	@SignalAcceptanceTime					int						=	NULL

AS
BEGIN

SET NOCOUNT ON


DECLARE
@ReturnValue     INT    =   0
, @ErrorId      INT    =   0
, @ErrorMessage     NVARCHAR(4000) =   N''

, @WasherId      INT    =   NULL
 , @PlantId		 INT	 =	 NULL
 , @ControllerModelId INT = NULL
--, @WasherModelId     SMALLINT  =   NULL
--, @CurrentUTCTime     DATETIME  =   GETUTCDATE()     --SQLEnlight SA0004

DECLARE
@OutputList      AS TABLE  (
WasherId      INT
, LastModifiedTimestamp   DATETIME
)

SET  @ConventionalWasherId = ISNULL(@ConventionalWasherId, NULL)   --SQLEnlight
SET  @OutputLastModifiedTimestampAtLocal   =   ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)   --SQLEnlight
SET  @LastModifiedTimestampAtCentral    =   ISNULL(@LastModifiedTimestampAtCentral, NULL)    --SQLEnlight SA0029
SELECT  @PlantId = PlantId From TCD.Plant WHERE EcolabAccountNumber = @EcoLabAccountNumber
SELECT @ControllerModelId = cmctm.ControllerModelId 
FROM TCD.ControllerModelControllerTypeMapping cmctm 
INNER JOIN TCD.ConduitController cc 
	ON cc.ControllerModelId = cmctm.ControllerModelId
WHERE cc.ControllerId = @ControllerId AND cc.EcoalabAccountNumber = @EcoLabAccountNumber

--Check that the WasherGroup being associated-to is a valid Conventional-type WG...
IF NOT EXISTS ( SELECT 1
FROM [TCD].WasherGroup     WG
JOIN [TCD].WasherGroupType    WGT
ON WG.WasherGroupTypeId  =   WGT.WasherGroupTypeId
JOIN [TCD].MachineGroup     GT         --this is actually the Groups table and NOT really a Group TYPE
ON WG.WasherGroupId   =   GT.Id   --Id is actually the Id of the Group
AND WG.EcolabAccountNumber  =   GT.EcolabAccountNumber
WHERE WG.WasherGroupId   =   @WasherGroupId
AND GT.EcolabAccountNumber  =   @EcoLabAccountNumber
AND GT.GroupTypeId      =   2   --select GroupMaintype from MachineGroup
AND WGT.WasherGroupTypeName  =   'Conventional'   --select WasherGroupTypeName from WasherGroupType
AND GT.Is_Deleted    =   'FALSE'
)
BEGIN
SET  @ErrorId      =   51001
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherGroup provided.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

--Check for unique PlantWasherNo.
IF EXISTS  ( SELECT 1
FROM [TCD].Washer      W
JOIN [TCD].MachineSetup     MS
ON W.WasherId     =   MS.WasherId
AND W.EcoLabAccountNumber  =   MS.EcoalabAccountNumber
WHERE W.EcoLabAccountNumber  =   @EcoLabAccountNumber
AND (
W.PlantWasherNumber   =   @PlantWasherNumber
)
AND W.Is_Deleted    =   'FALSE'
AND MS.IsDeleted    =   'FALSE'
)
BEGIN
SET  @ErrorId      =   51002
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Specified Plant Washer #/ already exists.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

IF @ControllerId > 0
BEGIN
--Check on valid LFSWasher#/Controller type/model...
IF @LFSWasherNumber IS NOT NULL
BEGIN
	IF NOT EXISTS ( SELECT 1
	FROM [TCD].ControllerModelControllerTypeMapping
	CMCTM
	JOIN [TCD].ConduitController   CC
	ON CC.ControllerTypeId   =   CMCTM.ControllerTypeId
	AND CC.ControllerModelId  =   CMCTM.ControllerModelId
	WHERE CC.EcoalabAccountNumber  =   @EcoLabAccountNumber
	AND CC.ControllerId    =   @ControllerId
	AND CC.IsDeleted    =   'FALSE'
	AND CMCTM.MaximumWasherExtractorCount
	>=   @LFSWasherNumber
	)
		BEGIN
			SET  @ErrorId      =   51003
			SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller/LFSWasher# was provided.'
			--GOTO ErrorHandler
			RAISERROR (@ErrorMessage, 16, 1)
			SET  @ReturnValue = -1
			RETURN (@ReturnValue)
		END
END
END
--EOF should not be an asocciated formula for the WG...
IF EXISTS  ( SELECT 1
FROM [TCD].WasherProgramSetup   WPS
WHERE WPS.EcolabAccountNumber  =   @EcoLabAccountNumber
AND WPS.WasherGroupId   =   @WasherGroupId
AND WPS.ProgramNumber   =   @ProgramNumber
AND WPS.Is_Deleted    =   'FALSE'
)
BEGIN
SET  @ErrorId      =   51004
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An assoicated formula cannot be specified as End-Of-Formula.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

IF @ControllerId > 0
BEGIN
--WasherMode check
IF NOT EXISTS ( SELECT 1
FROM [TCD].ControllerModelControllerTypeMapping
CMCTM
					JOIN	[TCD].ConduitController			CC
						ON	CC.ControllerTypeId			=			CMCTM.ControllerTypeId
						AND	CC.ControllerModelId		=			CMCTM.ControllerModelId
					JOIN	[TCD].[WasherModeMapping]			CTM2WM
						ON	CMCTM.Id					=			CTM2WM.ControllerModelControllerTypeMappingId
					WHERE	CC.EcoalabAccountNumber		=			@EcoLabAccountNumber
						AND	CC.ControllerId				=			@ControllerId
						AND	CC.IsDeleted				=			'FALSE'
						AND	CTM2WM.WasherModeId			=			@WasherMode
)
BEGIN
SET  @ErrorId      =   51005
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherMode was provided.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

--LFSWasherNumber duplicate check...
IF	EXISTS	(	SELECT	1
				FROM	[TCD].MachineSetup					MS
				WHERE	MS.ControllerId					=			@ControllerId
					AND	MS.MachineInternalId			=			@LFSWasherNumber
					AND MS.EcoalabAccountNumber			=			@EcoLabAccountNumber
					AND	MS.IsDeleted					=			'FALSE'
					AND MS.IsTunnel						=			'FALSE'

)
BEGIN
SET  @ErrorId      =   51010
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate LFSWasher# provided.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END
--ETechWasherNumber duplicate check...
IF(@ControllerModelId NOT IN (7,8,9,10,11,14))
BEGIN 
--ETechWasherNumber duplicate check...
IF EXISTS ( SELECT 1
    FROM [TCD].Washer  AS W
    JOIN [TCD].MachineSetup AS MS ON MS.WasherId = W.WasherId 
    where W.ETechWasherNumber = @ETechWasherNumber
   AND MS.IsTunnel                    =            'FALSE'
)  
BEGIN  

SET  @ErrorId      =   51012  
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate ETechWasherNumber# provided.'  
--GOTO ErrorHandler  
RAISERROR (@ErrorMessage, 16, 1)  
SET  @ReturnValue = -1  
RETURN (@ReturnValue)  

END
END

END
--Now attempt to insert a new row for the conventional washer being added...
BEGIN TRAN

INSERT	[TCD].Washer	(
	 EcoLabAccountNumber	,PlantWasherNumber			,ModelId				,WasherMode					,MaxLoad						,AWEActive				,EndOfFormula
	,[Description]			,Is_Deleted					,LastModifiedByUserId	,HoldSignal					,HoldDelay						,TargetTurnTime			,WaterFlushTime		
	,MyServiceCustMchGuid	,RatioDosingActive			,MyServiceLastSynchTime	,MinMachineLoad				,MaxMachineLoad					,ProgramSelectionByTime	,FlowSwitchNumber		
	,WasherStopExternalSignal	,OnHoldWESignalActive	, WasherOnHoldSignalDelay	,ValveOutputsUsedAsTomSignal			,WeInTomMode			,ManifoldFlushTime	
	,L1	,L2	,L3	,L4	,L5	,L6	,L7	,L8	,L9	 ,L10 ,L11	,L12 ,UseMe1OfGroup ,UseMe2OfGroup ,UsePumpOfGroup ,WasherStopUseFinalExtracting ,TemperatureAlarmYesNo ,PlantId, DefaultIdleTime, ETechWasherNumber,SignalAcceptanceTime
)
OUTPUT
inserted.WasherId      AS   Id
, inserted.LastModifiedTime  AS   LastModifiedTimestamp
INTO
@OutputList (
WasherId
, LastModifiedTimestamp
)

SELECT	@EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	@PlantWasherNumber					AS			PlantWasherNumber
	,	@ModelId							AS			ModelId
	,	@WasherMode							AS			WasherMode
	,	@MaxLoad							AS			MaxLoad
	,	@AWEActive							AS			AWEActive
	,	@ProgramNumber						AS			ProgramNumber
	,	@Description						AS			[Description]
	,	@IsDeleted							AS			Is_Deleted
	,	@UserId								AS			LastModifiedByUserId
	,	@HoldSignal							AS			HoldSignal
	,	@HoldDelay							AS			HoldDelay
	,	@TargetTurnTime						AS			TargetTurnTime
	,	@WaterFlushTime						AS			WaterFlushTime
	,	@ConventionalWasherGuid				AS			MyServiceCustMchGuid
	,	@RatioDosingActive					AS			RatioDosingActive
	,	@MyServiceLastSyncTime				AS			MyServiceLastSynchTime
	,	@MinMachineLoad						AS			MinimumMachineLoad
	,	@MaxMachineLoad						AS			MaximumMachineLoad
	,	@ProgramSelectionByTime				AS			ProgramSelectionByTime
	,	@FlowSwitchNumber					AS			FlowSwitchNumber
	,	@WasherStopExternalSignal			AS			WasherStopExternalSignal
	,	@OnHoldWESignalActive				AS			OnHoldWESignalActive
	,	@WasherOnHoldSignalDelay			AS			WasherOnHoldSignalDelay
	,	@ValveOutputsUsedAsTomSignal		AS			ValveOutputsUsedAsTomSignal
	,	@WeInTomMode						AS			WeInTomMode			
	,	@ManifoldFlushTime					AS			ManifoldFlushTime			
	,	@L1									AS			L1
	,	@L2									AS			L2
	,	@L3									AS			L3
	,	@L4									AS			L4
	,	@L5									AS			L5
	,	@L6									AS			L6
	,	@L7									AS			L7
	,	@L8									AS			L8
	,	@L9									AS			L9
	,	@L10								AS			L10
	,	@L11								AS			L11
	,	@L12								AS			L12
	,	@UseMe1OfGroup						AS			UseMe1OfGroup
	,	@UseMe2OfGroup						AS			UseMe2OfGroup
	,	@UsePumpOfGroup						AS			UsePumpOfGroup
	,	@WasherStopUseFinalExtracting		AS			WasherStopUseFinalExtracting
	,	@TemperatureAlarmYesNo				AS			TemperatureAlarmYesNo
	,	@PlantId							AS			PlantId
	,   @DefaultIdleTime AS   DefaultIdleTime 
	,   @ETechWasherNumber AS ETechWasherNumber
	,	@SignalAcceptanceTime				AS			SignalAcceptanceTime


SET @ErrorId = @@ERROR

IF (@ErrorId <> 0)
BEGIN
IF @@TRANCOUNT > 0
BEGIN
ROLLBACK TRAN
END

SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred creating new record for conventional.'
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

--if no error, collect the id of the newly generated row...
SELECT TOP 1 @WasherId = O.WasherId FROM @OutputList O

--insert in MachineSetup
INSERT [TCD].MachineSetup (
WasherId ,GroupId ,MachineInternalId ,EcoalabAccountNumber ,MachineName ,IsTunnel ,ControllerId , IsDeleted ,LastModifiedByUserId,IsPony )
SELECT @WasherId     AS   WasherId
, @WasherGroupId    AS   GroupId
, @LFSWasherNumber   AS   MachineInternalId
, @EcoLabAccountNumber  AS   EcoalabAccountNumber
, @ConventionalName   AS   MachineName
,@IsDeleted      AS   IsTunnel
, @ControllerId    AS   ControllerId
, 'FALSE'      AS   IsDeleted
, @UserId      AS   LastModifiedByUserId
,@IsPony As IsPony



 IF(ISNULL( @NewWasherGroupId,0)>0 AND (@WasherGroupId != @NewWasherGroupId))
 BEGIN
    UPDATE tcd.machinesetup 
    SET GroupId = @NewWasherGroupId
    WHERE WasherId = @WasherId
     
   EXEC TCD.SaveInjectionDetails @WasherGroupId,@NewWasherGroupId,@ControllerId,@WasherId,@EcolabAccountNumber
 END
 ELSE
 BEGIN
   EXEC TCD.SaveInjectionDetails @WasherGroupId,@WasherGroupId,@ControllerId,@WasherId,@EcolabAccountNumber
 END

SET @ErrorId = @@ERROR

IF (@ErrorId <> 0)
BEGIN
IF @@TRANCOUNT > 0
BEGIN
ROLLBACK TRAN
END

SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred assoicating new record for conventional.'
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END
ELSE
BEGIN
IF @@TRANCOUNT > 0
BEGIN
COMMIT
END

--SET the output param to be communicated back...

SELECT TOP 1
@OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp
, @ConventionalWasherId    = O.WasherId
FROM @OutputList       O

END




IF ( @ErrorId = 0 )
BEGIN
		IF (@ControllerModelId = 7)
			BEGIN
				UPDATE TCD.WasherGroup SET ControllerId = @ControllerId WHERE WasherGroupId = @WasherGroupId
			END
RETURN (@ReturnValue)
END



--ErrorHandler:
--RAISERROR (@ErrorMessage, 16, 1)
--SET @ReturnValue = -1


--ExitModule:

--RETURN (@ReturnValue)

--SET NOCOUNT OFF

END
GO
-----------------------------------------------
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[AddTunnel]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.AddTunnel
	END
GO

CREATE PROCEDURE	[TCD].[AddTunnel]	
					@MyServiceWasherId						UniqueIdentifier
				,	@EcoLabAccountNumber					NVARCHAR(1000)
				,	@WasherGroupId							INT
				,	@TunnelName								NVARCHAR(50)
				,	@WasherModelName						NVARCHAR(50)
				,	@RegionId								SMALLINT
--				,	@Size									INT									--we don't need to save this; ModelId PK determines it
				,	@ControllerId							INT
				,	@LFSWasherNumber						TINYINT			=			1		--For tunnels, it will be 1 until a diff. number is passed (as per the scenario)
				,	@PlantWasherNumber						SMALLINT
				,	@WasherMode								TINYINT
				,	@MaxLoad								SMALLINT
				,	@AWEActive								BIT
				,	@NumberOfTanks							TINYINT
				,	@NumberOfComp							TINYINT								--though this is INT in the table, we should not require it to be so
				,	@TransferType							TINYINT         =			NULL
				,	@PressExtractor							TINYINT       =			NULL
				,	@ProgramNumber							TINYINT
				,	@EndOfFormula							TINYINT
				,	@Description							NVARCHAR(1024)	=			NULL
				,	@UserId									INT

				,	@OutputTunnelId							INT			OUTPUT
				--Adding as part of re-factoring for integration with Synch/Configurator... generated TunnelId (re-named) is already being OUTPUT above
				,	@OutputLastModifiedTimestampAtLocal		DATETIME		=			NULL	OUTPUT
				,   @RatioDosingActive						Bit = 'False'
				,   @ControllerModelId						INT		=		NULL
				,   @NumberOfCompartmentsConveyorBelt			TINYINT	=		NULL
				,   @MaxMachineLoad							TINYINT	=		NULL
				,   @MinMachineLoad							TINYINT	=		NULL
				,   @ProgramSelectionByTime					BIT	  	=		NULL
				,   @WeightSelectionByTime					BIT	  	=		NULL
				,   @WeightSelectionByAnalogInput				BIT	  	=		NULL
				,   @TunInTomMode							BIT	  	=		NULL
				,   @SignalStopTunActive						BIT	  	=		NULL
				,   @SignalEjectionTunActive	  				BIT	  	=		NULL
				,   @DelayTimeForTunWashingPrograms			BIT	  	=		NULL
				,   @KannegiesserPressSpecialMode				BIT	  	=		NULL
				,   @ValveOutputsUsedAsTomSignal				BIT	  	=		NULL
				,   @ExtendedClockOrDataProtocol				BIT	  	=		NULL
				,   @WeightCorrectionFcc						BIT	  	=		NULL
				,	@DateAndTimeWhenBatchEjects					BIT	  		=		NULL
				,	@AutoRinseDesamixAfter						SMALLINT	=		NULL
				,	@AutoRinseDesamix1For						SMALLINT	=		NULL
				,	@AutoRinseDesamix2For						SMALLINT	=		NULL
				,	@TemperatureAlarmProbe1						BIT			=		NULL
				,	@TemperatureAlarmProbe2						BIT			=		NULL
				,	@TemperatureAlarmProbe3						BIT			=		NULL
				,	@ETechWasherNumber						    INT			=		NULL
				,	@KannegiesserDosageInPreparationTankMode	bit			=		NULL
				,	@BatchOk									bit			=		NULL

AS
BEGIN

SET	NOCOUNT	ON


DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''

	,	@WasherId						INT				=			NULL
	,	@WasherModelId					SMALLINT		=			NULL
	--Adding for integration with Synch./Central
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()
	,	@ControllerValidate				int				=										   0

--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
SET		@OutputLastModifiedTimestampAtLocal				=			@CurrentUTCTime
SET		@OutputTunnelId									=			ISNULL(@OutputTunnelId, NULL)			--SQLEnlight

--Check that the WasherGroup being associated-to is a valid Tunnel-type WG...
IF	NOT	EXISTS	(	SELECT	1
					FROM	[TCD].WasherGroup			WG
					JOIN	[TCD].WasherGroupType		WGT
						ON	WG.WasherGroupTypeId		=			WGT.WasherGroupTypeId
					JOIN	[TCD].MachineGroup					GT									--this is actually the Groups table and NOT really a Group TYPE
						ON	WG.WasherGroupId			=			GT.Id			--GroupTypeId is actually the Id of the Group
					WHERE	WG.WasherGroupId			=			@WasherGroupId
						AND	GT.EcolabAccountNumber		=			@EcoLabAccountNumber
						AND	GT.GroupTypeId	  			=			2			--select	GroupMaintype	from	GroupType
						AND	WGT.WasherGroupTypeName		=			'Tunnel'				--select	WasherGroupTypeName	from	WasherGroupType
				)
			BEGIN
				SET		@ErrorId						=			51001
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherGroup provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--Check for only 1 tunnel for a WasherGroup
IF	EXISTS		(	SELECT	1
					FROM	[TCD].MachineSetup			MS
					JOIN	[TCD].Washer				W
						ON	MS.WasherId					=			W.WasherId
					WHERE	MS.GroupId					=			@WasherGroupId
						AND	MS.EcoalabAccountNumber		=			@EcoLabAccountNumber
						AND	MS.IsDeleted				=			'FALSE'
						AND	MS.IsTunnel					=			'TRUE'
						AND	W.Is_Deleted				=			'FALSE'
				)
			BEGIN
				SET		@ErrorId						=			51008
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': A Tunnel has already been added to this Washer Group.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--Check for unique PlantWasherNo.
IF	EXISTS		(	SELECT	1
					FROM	[TCD].Washer				W
					JOIN	[TCD].MachineSetup			MS
						ON	W.WasherId					=			MS.WasherId
						AND	W.EcoLabAccountNumber		=			MS.EcoalabAccountNumber
					WHERE	W.EcoLabAccountNumber		=			@EcoLabAccountNumber
						AND	(
							W.PlantWasherNumber			=			@PlantWasherNumber							
							)
						AND	W.Is_Deleted				=			'FALSE'
						AND	MS.IsDeleted				=			'FALSE'
				)
			BEGIN
				SET		@ErrorId						=			51002
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Specified Plant Washer #/ already exists.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--Check that it's a valid Controller type/model (one that can control a Tunnel)

EXEC @ControllerValidate = [TCD].[ValidateController] 2,@ControllerId,@EcoLabAccountNumber

IF(@ControllerValidate = 1)
				
			BEGIN
				SET		@ErrorId						=			51003
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller was provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--EOF should not be an asocciated formula for the WG...
IF	EXISTS		(	SELECT	1
					FROM	[TCD].TunnelProgramSetup	TPS
					WHERE	TPS.EcolabAccountNumber		=			@EcoLabAccountNumber
						AND	TPS.WasherGroupId			=			@WasherGroupId
						AND	TPS.ProgramNumber			=			@ProgramNumber
						AND	TPS.Is_Deleted				=			'FALSE'
				)
			BEGIN
				SET		@ErrorId						=			51004
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An associated formula cannot be specified as End-Of-Formula.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--WasherMode check
IF	NOT	EXISTS	(	SELECT	1
					FROM	[TCD].ControllerModelControllerTypeMapping
														CMCTM
					JOIN	[TCD].ConduitController		CC
						ON	CC.ControllerTypeId			=			CMCTM.ControllerTypeId
						AND	CC.ControllerModelId		=			CMCTM.ControllerModelId
					JOIN	[TCD].[WasherModeMapping]	CTM2WM
						ON	CMCTM.Id					=			CTM2WM.ControllerModelControllerTypeMappingId
					WHERE	CC.EcoalabAccountNumber		=			@EcoLabAccountNumber
						AND	CC.ControllerId				=			@ControllerId
						AND	CC.IsDeleted				=			'FALSE'
						AND	CMCTM.MaxtunnelCount > 0
						AND	CTM2WM.WasherModeId			=			@WasherMode
				)
			BEGIN
				SET		@ErrorId						=			51005
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherMode was provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--select the WasherModelId based on name
SELECT	TOP	1
		@WasherModelId						=			WMS.WasherModelId
FROM	[TCD].WasherModelSize				WMS
WHERE	WMS.RegionId						=			@RegionId
	AND	WMS.WasherModelName					=			@WasherModelName
	AND	WMS.ModelTypeId						=			2							--TypeId 2 for Tunnel
	AND	WMS.Is_Deleted						=			'FALSE'

--LFSWasherNumber duplicate check...
IF	EXISTS	(	SELECT	1
				FROM	[TCD].MachineSetup					MS
				WHERE	MS.ControllerId					=			@ControllerId
					AND	MS.MachineInternalId			=			@LFSWasherNumber
					AND MS.EcoalabAccountNumber			=			@EcoLabAccountNumber
					AND	MS.IsDeleted					=			'FALSE'
					AND MS.IsTunnel						=			'TRUE'
			)
			BEGIN
				SET		@ErrorId						=			51010
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate LFSWasher# provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET		@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END
--ETechWasherNumber duplicate check...
IF(@ControllerModelId NOT IN (7,8,9,10,11,14))
BEGIN
IF EXISTS ( SELECT 1
    FROM [TCD].Washer  AS W
    JOIN [TCD].MachineSetup AS MS ON MS.WasherId = W.WasherId 
    where W.ETechWasherNumber = @ETechWasherNumber
	 AND  MS.IsTunnel                    =            'TRUE'
)  
BEGIN  

SET  @ErrorId      =   51012  
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate ETechWasherNumber# provided.'  
--GOTO ErrorHandler  
RAISERROR (@ErrorMessage, 16, 1)  
SET  @ReturnValue = -1  
RETURN (@ReturnValue)  
END
END

--Now attempt to insert a new row for the tunnel record being created...
BEGIN	TRAN
IF(@ControllerModelId IS NOT NULL AND @ControllerModelId = 7 )
BEGIN
INSERT	[TCD].Washer	(
		 MyServiceCustMchGuid
		,EcoLabAccountNumber
		,PlantWasherNumber
		,ModelId
		,WasherMode
		,MaxLoad
		,[Description]
		,Is_Deleted
		,LastModifiedByUserId
		,NumberOfTanks
		,TransferType
		,PressExtractor
	--Adding for integration with Synch./Central
		,LastModifiedTime
		,EmptyPocketNumber
		,NumberOfCompartmentsConveyorBelt
		,MinMachineLoad
		,MaxMachineLoad
		,ProgramSelectionByTime
		,WeightSelectionByTime
		,WeightSelectionByAnalogInput
		,TunInTomMode
		,SignalStopTunActive
		,SignalEjectionTunActive
		,DelayTimeForTunWashingPrograms
		,KannegiesserPressSpecialMode
		,ValveOutputsUsedAsTomSignal
		,ExtendedClockOrDataProtocol
		,WeightCorrectionFcc
		,AWEActive
		,EndOfFormula
		,ETechWasherNumber
		,KannegiesserDosageInPreparationTankMode
		,BatchOk
	)
SELECT @MyServiceWasherId					AS			MyServiceWasherId	
	,	@EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	@PlantWasherNumber					AS			PlantWasherNumber
	,	@WasherModelId						AS			ModelId
	--,	@Size							AS			Size
	,	@WasherMode						AS			WasherMode
	,	@MaxLoad							AS			MaxLoad
	,	@Description						AS			[Description]
	,	'FALSE'							AS			Is_Deleted
	,	@UserId							AS			LastModifiedByUserId
	,	@NumberOfTanks						AS			NumberOfTanks
	,	@TransferType						AS			TransferType
	,	@PressExtractor					AS			PressExtractor
	,	@CurrentUTCTime					AS			LastModifiedTime
	,	@ProgramNumber						AS			ProgramNumber
	,   @NumberOfCompartmentsConveyorBelt		AS			NumberOfCompartmentsConveyorBelt
	,   @MinMachineLoad						AS			MinMachineLoad
	,   @MaxMachineLoad						AS			MaxMachineLoad
	,   @ProgramSelectionByTime				AS			ProgramSelectionByTime
	,   @WeightSelectionByTime				AS			WeightSelectionByTime
	,   @WeightSelectionByAnalogInput			AS			WeightSelectionByAnalogInput
	,   @TunInTomMode						AS			TunInTomMode
	,   @SignalStopTunActive					AS			SignalStopTunActive
	,   @SignalEjectionTunActive	  			AS			SignalEjectionTunActive
	,   @DelayTimeForTunWashingPrograms		AS			DelayTimeForTunWashingPrograms
	,   @KannegiesserPressSpecialMode			AS			KannegiesserPressSpecialMode
	,   @ValveOutputsUsedAsTomSignal			AS			ValveOutputsUsedAsTomSignal
	,   @ExtendedClockOrDataProtocol			AS			ExtendedClockOrDataProtocol
	,   @WeightCorrectionFcc					AS			WeightCorrectionFcc
	,	'FALSE'							AS			AWEActive
	,	0								AS			EndOfFormula
	,   @ETechWasherNumber			AS			ETechWasherNumber
	,	@KannegiesserDosageInPreparationTankMode	AS KannegiesserDosageInPreparationTankMode
	,	@BatchOk						AS		BatchOk
END
ELSE IF(@ControllerModelId IS NOT NULL AND ( @ControllerModelId = 8	OR @ControllerModelId = 9	OR @ControllerModelId = 10 OR @ControllerModelId = 11 OR @ControllerModelId = 14))
BEGIN
INSERT	[TCD].Washer	(
		 MyServiceCustMchGuid
		,EcoLabAccountNumber
		,PlantWasherNumber
		,ModelId
		,WasherMode
		,MaxLoad
		,[Description]
		,Is_Deleted
		,LastModifiedByUserId
		,NumberOfTanks
		,TransferType
		,PressExtractor
	--Adding for integration with Synch./Central
		,LastModifiedTime
		,EmptyPocketNumber
		,NumberOfCompartmentsConveyorBelt
		,MinMachineLoad
		,MaxMachineLoad
		,ProgramSelectionByTime
		,WeightSelectionByTime
		,WeightSelectionByAnalogInput
		,TunInTomMode
		,SignalStopTunActive
		,SignalEjectionTunActive
		,DelayTimeForTunWashingPrograms
		,KannegiesserPressSpecialMode
		,ValveOutputsUsedAsTomSignal
		,ExtendedClockOrDataProtocol
		,WeightCorrectionFcc
		,AWEActive
		,EndOfFormula
		,AutoRinseDesamixAfter
		,AutoRinseDesamix1For
		,AutoRinseDesamix2For
		,TemperatureAlarmProbe1
		,TemperatureAlarmProbe2
		,TemperatureAlarmProbe3
		,DateAndTimeWhenBatchEjects
		,ETechWasherNumber

	)
SELECT @MyServiceWasherId					AS			MyServiceWasherId	
	,	@EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	@PlantWasherNumber					AS			PlantWasherNumber
	,	@WasherModelId						AS			ModelId
	--,	@Size							AS			Size
	,	@WasherMode						AS			WasherMode
	,	@MaxLoad							AS			MaxLoad
	,	@Description						AS			[Description]
	,	'FALSE'							AS			Is_Deleted
	,	@UserId							AS			LastModifiedByUserId
	,	@NumberOfTanks						AS			NumberOfTanks
	,	@TransferType						AS			TransferType
	,	@PressExtractor					AS			PressExtractor
	,	@CurrentUTCTime					AS			LastModifiedTime
	,	@ProgramNumber						AS			ProgramNumber
	,   @NumberOfCompartmentsConveyorBelt		AS			NumberOfCompartmentsConveyorBelt
	,   @MinMachineLoad						AS			MinMachineLoad
	,   @MaxMachineLoad						AS			MaxMachineLoad
	,   @ProgramSelectionByTime				AS			ProgramSelectionByTime
	,   @WeightSelectionByTime				AS			WeightSelectionByTime
	,   @WeightSelectionByAnalogInput			AS			WeightSelectionByAnalogInput
	,   @TunInTomMode						AS			TunInTomMode
	,   @SignalStopTunActive					AS			SignalStopTunActive
	,   @SignalEjectionTunActive	  			AS			SignalEjectionTunActive
	,   @DelayTimeForTunWashingPrograms		AS			DelayTimeForTunWashingPrograms
	,   @KannegiesserPressSpecialMode			AS			KannegiesserPressSpecialMode
	,   @ValveOutputsUsedAsTomSignal			AS			ValveOutputsUsedAsTomSignal
	,   @ExtendedClockOrDataProtocol			AS			ExtendedClockOrDataProtocol
	,   @WeightCorrectionFcc					AS			WeightCorrectionFcc
	,	'FALSE'							AS			AWEActive
	,	0								AS			EndOfFormula
	,	@AutoRinseDesamixAfter
	,	@AutoRinseDesamix1For
	,	@AutoRinseDesamix2For
	,	@TemperatureAlarmProbe1
	,	@TemperatureAlarmProbe2
	,	@TemperatureAlarmProbe3
	,	@DateAndTimeWhenBatchEjects
	,   @ETechWasherNumber						AS			ETechWasherNumber
END
ELSE
BEGIN
INSERT	[TCD].Washer	(
		MyServiceCustMchGuid
		,EcoLabAccountNumber
		,PlantWasherNumber
		,ModelId
		,WasherMode
		,MaxLoad
		,AWEActive
		,EndOfFormula
		,[Description]
		,Is_Deleted
		,LastModifiedByUserId
		,NumberOfTanks
		,TransferType
		,PressExtractor
	--Adding for integration with Synch./Central
		,LastModifiedTime
		,RatioDosingActive
		,EmptyPocketNumber
	)
SELECT @MyServiceWasherId					AS			MyServiceWasherId	
	,	@EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	@PlantWasherNumber					AS			PlantWasherNumber
	,	@WasherModelId						AS			ModelId
	--,	@Size							AS			Size
	,	@WasherMode						AS			WasherMode
	,	@MaxLoad							AS			MaxLoad
	,	@AWEActive						AS			AWEActive
	,	@EndOfFormula						AS			EndOfFormula
	,	@Description						AS			[Description]
	,	'FALSE'							AS			Is_Deleted
	,	@UserId							AS			LastModifiedByUserId
	,	@NumberOfTanks						AS			NumberOfTanks
	,	@TransferType						AS			TransferType
	,	@PressExtractor					AS			PressExtractor
	,	@CurrentUTCTime					AS			LastModifiedTime
	,   @RatioDosingActive					AS			RatioDosingActive
	,	@ProgramNumber						AS			ProgramNumber 	
END

SET	@ErrorId	=	@@ERROR
	
IF	(@ErrorId	<>	0)
	BEGIN
			IF	@@TRANCOUNT	>	0
			BEGIN
				ROLLBACK	TRAN
			END

			SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred creating new record for tunnel.'
			--GOTO	ErrorHandler
			RAISERROR	(@ErrorMessage, 16, 1)
			SET	@ReturnValue	=	-1
			RETURN	(@ReturnValue)
	END

--if no error, collect the id of the newly generated row...
SELECT	@WasherId	=	SCOPE_IDENTITY()


--insert in MachineSetup
INSERT	[TCD].MachineSetup	(
		WasherId	,GroupId	,MachineInternalId	,EcoalabAccountNumber	,MachineName	,IsTunnel	,ControllerId	,NumberOfComp	,IsDeleted	,LastModifiedByUserId	)
SELECT	@WasherId					AS			WasherId
	,	@WasherGroupId				AS			GroupId
	,	@LFSWasherNumber			AS			MachineInternalId
	,	@EcoLabAccountNumber		AS			EcoalabAccountNumber
	,	@TunnelName					AS			MachineName
	,	'TRUE'						AS			IsTunnel
	,	@ControllerId				AS			ControllerId
	,	@NumberOfComp				AS			NumberOfComp
	,	'FALSE'						AS			IsDeleted
	,	@UserId						AS			LastModifiedByUserId

SET	@ErrorId	=	@@ERROR

IF	(@ErrorId	<>	0)
	BEGIN
			IF	@@TRANCOUNT	>	0
			BEGIN
				ROLLBACK	TRAN
			END

			SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred assoicating new record for tunnel.'
			--GOTO	ErrorHandler
			RAISERROR	(@ErrorMessage, 16, 1)
			SET	@ReturnValue	=	-1
			RETURN	(@ReturnValue)
	END
ELSE
	BEGIN
			IF	@@TRANCOUNT	>	0
			BEGIN
				COMMIT
			END

			--SET the output param to be communicated back...
			SET	@OutputTunnelId	=	@WasherId
	END



--IF	(	@ErrorId	=	0	)
--	BEGIN
--		--GOTO	ExitModule
--		RETURN	(@ReturnValue)
--	END




--ErrorHandler:
--RAISERROR	(@ErrorMessage, 16, 1)
--SET	@ReturnValue	=	-1




--ExitModule:

SET	NOCOUNT	OFF
RETURN	(@ReturnValue)


END
GO
-------------------------------------------

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[UpdateConventional]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.UpdateConventional
	END
GO

CREATE	PROCEDURE	[TCD].[UpdateConventional]
					@EcoLabAccountNumber					NVARCHAR(1000)
				,	@WasherId								INT
				,	@WasherGroupId							INT
				, @NewWasherGroupId							int		=	null
				,	@ConventionalName						NVARCHAR(50)
				,	@ModelId								INT						--(Washer)Model Id for Size
				,	@ControllerId							INT
				,	@LFSWasherNumber						TINYINT
				,	@PlantWasherNumber						SMALLINT
				,	@WasherMode								TINYINT
				,	@MaxLoad								SMALLINT
				,	@AWEActive								BIT
				,	@HoldSignal								BIT
				,	@HoldDelay								SMALLINT															
				,	@TargetTurnTime							SMALLINT
				,	@WaterFlushTime							SMALLINT
				,	@ProgramNumber							TINYINT					--EOF number
				,	@Description							NVARCHAR(1024)	=			NULL
				,	@UserId									INT
				,	@LastModifiedTimestampAtCentral			DATETIME				=	NULL
				,	@OutputLastModifiedTimestampAtLocal		DATETIME				=	NULL	OUTPUT
				,	@RatioDosingActive						BIT			
				,	@IsPony BIT  
				,	@MinMachineLoad							SMALLINT				=	NULL
				,	@MaxMachineLoad							smallint				=	NULL
				,	@ProgramSelectionByTime					bit						=	NULL
				,	@FlowSwitchNumber						int						=	NULL
				,	@WasherStopExternalSignal				bit						=	NULL
				,	@OnHoldWESignalActive					bit						=	NULL
				,	@WasherOnHoldSignalDelay				int						=	NULL
				,	@ValveOutputsUsedAsTomSignal			bit						=	NULL
				,	@WeInTomMode							bit						=	NULL
				,	@ManifoldFlushTime						int						=	NULL
				,	@L1										bit						=	NULL
				,	@L2										bit						=	NULL
				,	@L3										bit						=	NULL
				,	@L4										bit						=	NULL
				,	@L5										bit						=	NULL
				,	@L6										bit						=	NULL
				,	@L7										bit						=	NULL
				,	@L8										bit						=	NULL
				,	@L9										bit						=	NULL
				,	@L10									bit						=	NULL
				,	@L11									bit						=	NULL
				,	@L12									bit						=	NULL
				,	@UseMe1OfGroup							tinyint					=	NULL
				,	@UseMe2OfGroup							tinyint					=	NULL
				,	@UsePumpOfGroup							tinyint					=	NULL
				,	@WasherStopUseFinalExtracting			bit						=	NULL
				,	@TemperatureAlarmYesNo					bit						=	NULL
				, @DefaultIdleTime							INT						=   NULL
				, @ETechWasherNumber						INT						=   NULL
				,	@SignalAcceptanceTime					int						=	NULL
AS
BEGIN

SET NOCOUNT ON


DECLARE 
  @ReturnValue     INT    =   0
 , @ErrorId      INT    =   0
 , @ErrorMessage     NVARCHAR(4000) =   N''
 , @CurrentUTCTime     DATETIME  =   GETUTCDATE()
 , @PlantId		INT			=	NULL
 , @ControllerModelId INT = NULL

DECLARE
   @OutputList      AS TABLE  (
   LastModifiedTimestamp   DATETIME
  )

SET  @OutputLastModifiedTimestampAtLocal    =   ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)   --SQLEnlight
SELECT  @PlantId = PlantId From TCD.Plant WHERE EcolabAccountNumber = @EcoLabAccountNumber
SELECT @ControllerModelId = cmctm.ControllerModelId 
FROM TCD.ControllerModelControllerTypeMapping cmctm 
INNER JOIN TCD.ConduitController cc 
	ON cc.ControllerModelId = cmctm.ControllerModelId
WHERE cc.ControllerId = @ControllerId AND cc.EcoalabAccountNumber = @EcoLabAccountNumber

--Valid Washer-Id check...
IF NOT EXISTS ( SELECT 1
     FROM [TCD].Washer      W
     JOIN [TCD].MachineSetup    MS
      ON W.WasherId     =   MS.WasherId
      AND W.EcoLabAccountNumber  =   MS.EcoalabAccountNumber
     WHERE W.EcoLabAccountNumber  =   @EcoLabAccountNumber
      AND W.WasherId     =   @WasherId
      AND MS.GroupId     =   @WasherGroupId
      AND W.Is_Deleted    =   'FALSE'
      AND MS.IsDeleted    =   'FALSE'
    )
   BEGIN
    SET  @ErrorId      =   51006
    SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Washer-ID was provided for Updating.'
    --GOTO ErrorHandler
    RAISERROR (@ErrorMessage, 16, 1)
    SET  @ReturnValue = -1
    RETURN (@ReturnValue)
   END

--Check for uniqueness of PlantWasherNo. and Name
IF EXISTS  ( SELECT 1
     FROM [TCD].Washer      W
     JOIN [TCD].MachineSetup    MS
      ON W.WasherId     =   MS.WasherId
      AND W.EcoLabAccountNumber  =   MS.EcoalabAccountNumber
     WHERE W.EcoLabAccountNumber  =   @EcoLabAccountNumber
      AND W.WasherId     <>   @WasherId AND W.PlantWasherNumber   =   @PlantWasherNumber
      AND (
       W.PlantWasherNumber   =   @PlantWasherNumber       
       OR
       MS.MachineName    =   @ConventionalName
       )
      AND W.Is_Deleted    =   'FALSE'
      AND MS.IsDeleted    =   'FALSE'
    )
   BEGIN
    SET  @ErrorId      =   51002
    SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Specified Plant Washer #/ already exists.'
    --GOTO ErrorHandler
    RAISERROR (@ErrorMessage, 16, 1)
    SET  @ReturnValue = -1
    RETURN (@ReturnValue)
   END

IF @ControllerId > 0
BEGIN
--Check Max LFSWasher No.
IF NOT EXISTS ( SELECT 1
     FROM [TCD].ControllerModelControllerTypeMapping
              CMCTM
     JOIN [TCD].ConduitController   CC
      ON CC.ControllerTypeId   =   CMCTM.ControllerTypeId
      AND CC.ControllerModelId  =   CMCTM.ControllerModelId
     WHERE CC.EcoalabAccountNumber  =   @EcoLabAccountNumber
      AND CC.ControllerId    =   @ControllerId
      AND CC.IsDeleted    =   'FALSE'
      AND CMCTM.MaximumWasherExtractorCount
              >=   @LFSWasherNumber
    )
   BEGIN
    SET  @ErrorId      =   51003
    SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller/LFSWasher# was provided.'
    --GOTO ErrorHandler
    RAISERROR (@ErrorMessage, 16, 1)
    SET  @ReturnValue = -1
    RETURN (@ReturnValue)
   END
END
--EOF should not be an asocciated formula for the WG...
IF EXISTS  ( SELECT 1
     FROM [TCD].WasherProgramSetup   WPS
     WHERE WPS.EcolabAccountNumber  =   @EcoLabAccountNumber
      AND WPS.WasherGroupId   =   @WasherGroupId
      AND WPS.ProgramNumber   =   @ProgramNumber
      AND WPS.Is_Deleted    =   'FALSE'
    )
   BEGIN
    SET  @ErrorId      =   51004
    SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An assoicated formula cannot be specified as End-Of-Formula.'
    --GOTO ErrorHandler
    RAISERROR (@ErrorMessage, 16, 1)
    SET  @ReturnValue = -1
    RETURN (@ReturnValue)
   END

IF @ControllerId > 0
BEGIN
--WasherMode check
IF NOT EXISTS ( SELECT 1
     FROM [TCD].ControllerModelControllerTypeMapping
              CMCTM
					JOIN	[TCD].ConduitController			CC
						ON	CC.ControllerTypeId			=			CMCTM.ControllerTypeId
						AND	CC.ControllerModelId		=			CMCTM.ControllerModelId
					JOIN	[TCD].[WasherModeMapping]
              CTM2WM
      ON CMCTM.Id     =   CTM2WM.ControllerModelControllerTypeMappingId
     WHERE CC.EcoalabAccountNumber  =   @EcoLabAccountNumber
      AND CC.ControllerId    =   @ControllerId
      AND CC.IsDeleted    =   'FALSE'
      AND CTM2WM.WasherModeId   =   @WasherMode
    )
   BEGIN
    SET  @ErrorId      =   51005
    SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherMode was provided.'
    --GOTO ErrorHandler
    RAISERROR (@ErrorMessage, 16, 1)
    SET  @ReturnValue = -1
    RETURN (@ReturnValue)
   END

--LFSWasherNumber duplicate check...
IF	EXISTS	(	SELECT	1
				FROM	[TCD].MachineSetup					MS
				WHERE	MS.ControllerId					=			@ControllerId
					AND	MS.MachineInternalId			=			@LFSWasherNumber
					AND	MS.IsDeleted					=			'FALSE'
					AND	MS.WasherId						<>			@WasherId
					AND MS.EcoalabAccountNumber			=			@EcoLabAccountNumber
					AND MS.IsTunnel						=			'FALSE'
   )
   BEGIN
    SET  @ErrorId      =   51010
    SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate LFSWasher# provided.'
    --GOTO ErrorHandler
    RAISERROR (@ErrorMessage, 16, 1)
    SET  @ReturnValue = -1
    RETURN (@ReturnValue)
   END
   --ETechWasherNumber duplicate check...
IF(@ControllerModelId NOT IN (7,8,9,10,11,14))
BEGIN 
--ETechWasherNumber duplicate check...
IF EXISTS ( SELECT 1
    FROM [TCD].Washer  AS W
    JOIN [TCD].MachineSetup AS MS ON MS.WasherId = W.WasherId 
    where W.ETechWasherNumber = @ETechWasherNumber
	AND W.WasherId = @WasherId
   AND MS.IsTunnel                    =            'FALSE'
)  
BEGIN  

SET  @ErrorId      =   51012  
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate ETechWasherNumber# provided.'  
--GOTO ErrorHandler  
RAISERROR (@ErrorMessage, 16, 1)  
SET  @ReturnValue = -1  
RETURN (@ReturnValue)  
END
END

END

IF (
   @LastModifiedTimestampAtCentral    IS NOT NULL
   AND
   NOT EXISTS ( SELECT 1
     FROM TCD.Washer  W
     WHERE W.EcolabAccountNumber = @EcolabAccountNumber
      AND W.WasherId    = @WasherId
      AND W.LastModifiedTime  = @LastModifiedTimestampAtCentral
    )
 )
  BEGIN
    SET   @ErrorId    = 60000
    SET   @ErrorMessage   = N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
    RAISERROR (@ErrorMessage, 16, 1)
    SET   @ReturnValue   = -1
    RETURN  (@ReturnValue)
  END


--Now attempt Update...
BEGIN TRAN

UPDATE MS
 SET MS.MachineName     =   @ConventionalName
 , MS.ControllerId     =   @ControllerId
 , MS.MachineInternalId   =   @LFSWasherNumber
 , MS.LastModifiedByUserId   =   @UserId
 ,MS.IsPony = @IsPony
FROM [TCD].MachineSetup     MS
JOIN [TCD].Washer       W
 ON MS.WasherId      =   W.WasherId
 AND MS.EcoalabAccountNumber   =   W.EcolabAccountNumber
WHERE MS.WasherId      =   @WasherId
 AND MS.EcoalabAccountNumber   =   @EcoLabAccountNumber
 AND MS.IsDeleted     =   'FALSE'
 AND W.Is_Deleted     =   'FALSE'

--check for any error
SET @ErrorId = @@ERROR

IF (@ErrorId <> 0)
BEGIN

  IF @@TRANCOUNT > 0
  BEGIN
   ROLLBACK TRAN
  END
 
  SET  @ErrorMessage    =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating washer data.'
  --GOTO ErrorHandler
  RAISERROR (@ErrorMessage, 16, 1)
  SET  @ReturnValue = -1
  RETURN (@ReturnValue)
END

--else, continue with the rest of the update in the other table...
UPDATE	W
	SET	W.ModelId						=			@ModelId
	,	W.PlantWasherNumber				=			@PlantWasherNumber
	,	W.WasherMode					=			@WasherMode
	,	W.MaxLoad						=			@MaxLoad
	,	W.AWEActive						=			@AWEActive
	,	W.HoldSignal					=			@HoldSignal
	,	W.HoldDelay						=			@HoldDelay
	,	W.TargetTurnTime				=			@TargetTurnTime
	,	W.WaterFlushTime				=			@WaterFlushTime
	,	W.EndOfFormula					=			@ProgramNumber
	,	W.[Description]					=			@Description
	,	W.LastModifiedByUserId			=			@UserId
	,	W.LastModifiedTime				=			@CurrentUTCTime
	,   W.RatioDosingActive				=			@RatioDosingActive
	,	W.MinMachineLoad				=			@MinMachineLoad				
	,	W.MaxMachineLoad				=			@MaxMachineLoad				
	,	W.ProgramSelectionByTime		=			@ProgramSelectionByTime		
	,	W.FlowSwitchNumber				=			@FlowSwitchNumber			
	,	W.WasherStopExternalSignal		=			@WasherStopExternalSignal	
	,	W.OnHoldWESignalActive			=			@OnHoldWESignalActive		
	,	W.WasherOnHoldSignalDelay		=			@WasherOnHoldSignalDelay	
	,	W.ValveOutputsUsedAsTomSignal	=			@ValveOutputsUsedAsTomSignal
	,	W.WEInTOMMode					=			@WeInTomMode				
	,	W.ManifoldFlushTime				=			@ManifoldFlushTime			
	,	W.L1							=			@L1
	,	W.L2							=			@L2
	,	W.L3							=			@L3
	,	W.L4							=			@L4
	,	W.L5							=			@L5
	,	W.L6							=			@L6
	,	W.L7							=			@L7
	,	W.L8							=			@L8
	,	W.L9							=			@L9
	,	W.L10							=			@L10
	,	W.L11							=			@L11
	,	W.L12							=			@L12
	,	W.UseMe1OfGroup					=			@UseMe1OfGroup
	,	W.UseMe2OfGroup					=			@UseMe2OfGroup
	,	W.UsePumpOfGroup				=			@UsePumpOfGroup
	,	W.WasherStopUseFinalExtracting	=			@WasherStopUseFinalExtracting
	,	W.TemperatureAlarmYesNo			=			@TemperatureAlarmYesNo
	,	W.PlantId						=			@PlantId
	,   W.DefaultIdleTime               =           @DefaultIdleTime
	,   W.ETechWasherNumber               =         @ETechWasherNumber
	,	W.SignalAcceptanceTime			=			@SignalAcceptanceTime

OUTPUT
 inserted.LastModifiedTime  AS   LastModifiedTimestamp
INTO
 @OutputList (
 LastModifiedTimestamp
)
FROM [TCD].Washer      W
JOIN [TCD].MachineSetup     MS
 ON W.WasherId      =   MS.WasherId
 AND W.EcoLabAccountNumber   =   MS.EcoalabAccountNumber
WHERE W.WasherId      =   @WasherId
 AND W.EcoLabAccountNumber   =   @EcoLabAccountNumber
 AND W.Is_Deleted     =   'FALSE'
 AND MS.IsDeleted     =   'FALSE'


 IF(@NewWasherGroupId IS NOT NULL AND (@WasherGroupId != @NewWasherGroupId))
 BEGIN
    UPDATE tcd.machinesetup 
    SET GroupId = @NewWasherGroupId
    WHERE WasherId = @WasherId
     
   EXEC TCD.SaveInjectionDetails @WasherGroupId,@NewWasherGroupId,@ControllerId,@WasherId,@EcolabAccountNumber
 END
 ELSE
 BEGIN
   EXEC TCD.SaveInjectionDetails @WasherGroupId,@WasherGroupId,@ControllerId,@WasherId,@EcolabAccountNumber
 END

--check for error, if none - commit the tran, else rollback
SET @ErrorId = @@ERROR
IF (@ErrorId <> 0)
 BEGIN
  IF (@@TRANCOUNT > 0)
   BEGIN
    ROLLBACK
   END

  SET  @ErrorMessage    =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating washer data.'
  --GOTO ErrorHandler
  RAISERROR (@ErrorMessage, 16, 1)
  SET  @ReturnValue = -1
  RETURN (@ReturnValue)
 END
ELSE
 BEGIN
  IF (@@TRANCOUNT > 0)
   BEGIN
				IF (@ControllerModelId = 7)
				BEGIN
					UPDATE TCD.WasherGroup SET ControllerId = @ControllerId WHERE WasherGroupId = @WasherGroupId
				END
    COMMIT
   END
   
   SELECT TOP 1 @OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp FROM @OutputList O
 END


SET NOCOUNT OFF
RETURN (@ReturnValue)


END
GO
-----------------------------------------------
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[UpdateTunnel]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.UpdateTunnel
	END
GO

CREATE	PROCEDURE    [TCD].[UpdateTunnel]
                    @EcoLabAccountNumber                    NVARCHAR(1000)
                ,    @WasherId                                INT
                ,    @WasherGroupId                            INT                                    --Not updated, for reference only
                ,    @TunnelName                            NVARCHAR(50)
                ,    @WasherModelName                        NVARCHAR(50)
                ,    @RegionId                                SMALLINT
                --,    @Size                                INT
                ,    @ControllerId                            INT
                ,    @LFSWasherNumber                        INT            =            1        --For tunnels, it will be 1 until a diff. number is passed (as per the scenario)
                ,    @PlantWasherNumber                        SMALLINT
                ,    @WasherMode                            SMALLINT
                ,    @MaxLoad                                SMALLINT
                ,    @AWEActive                            BIT
                ,    @NumberOfTanks                            TINYINT
                ,    @NumberOfComp                            INT                                --though this is INT in the table, we should not require it to be so
                ,    @TransferType                            TINYINT
                ,    @PressExtractor                        TINYINT
                ,    @ProgramNumber                            TINYINT
                ,    @EndOfFormula                            TINYINT
                ,    @Description                            NVARCHAR(1024)    =            NULL
                ,    @UserId                                INT
				--Adding these 3 params as part of re-factoring for integration with Synch/Configurator
                ,    @OutputTunnelId                        INT            =            NULL    OUTPUT
                ,    @LastModifiedTimestampAtCentral            DATETIME    =            NULL            --Nullable for local call; Synch/Central call will have to pass this -
																									--else, it will be treated as a local call
                ,    @OutputLastModifiedTimestampAtLocal        DATETIME    =            NULL    OUTPUT
                ,   @RatioDosingActive                        BIT
                ,   @ControllerModelId                        INT        =        NULL
                ,   @NumberOfCompartmentsConveyorBelt            TINYINT    =        NULL
                ,   @MaxMachineLoad                            SMALLINT    =        NULL
                ,   @MinMachineLoad                            SMALLINT    =        NULL
                ,   @ProgramSelectionByTime                    BIT          =        NULL
                ,   @WeightSelectionByTime                    BIT          =        NULL
                ,   @WeightSelectionByAnalogInput                BIT          =        NULL
                ,   @TunInTomMode                            BIT          =        NULL
                ,   @SignalStopTunActive                        BIT          =        NULL
                ,   @SignalEjectionTunActive                      BIT          =        NULL
                ,   @DelayTimeForTunWashingPrograms            BIT          =        NULL
                ,   @KannegiesserPressSpecialMode                BIT          =        NULL
                ,   @ValveOutputsUsedAsTomSignal                BIT          =        NULL
                ,   @ExtendedClockOrDataProtocol                BIT          =        NULL
                ,   @WeightCorrectionFcc                        BIT          =        NULL
				,	@DateAndTimeWhenBatchEjects					BIT	  		=		NULL
				,	@AutoRinseDesamixAfter						SMALLINT	=		NULL
				,	@AutoRinseDesamix1For						SMALLINT	=		NULL
				,	@AutoRinseDesamix2For						SMALLINT	=		NULL
				,	@TemperatureAlarmProbe1						BIT			=		NULL
				,	@TemperatureAlarmProbe2						BIT			=		NULL
				,	@TemperatureAlarmProbe3						BIT			=		NULL
				,	@UseMe1OfGroup							tinyint					=	NULL
				,	@UseMe2OfGroup							tinyint					=	NULL
				,	@ETechWasherNumber						int					=	NULL
				,	@KannegiesserDosageInPreparationTankMode	bit			=		NULL
				,	@BatchOk									bit			=		NULL
AS
BEGIN

SET    NOCOUNT    ON


DECLARE	
        @ReturnValue                    INT                =            0
    ,    @ErrorId                        INT                =            0
    ,    @ErrorMessage                    NVARCHAR(4000)    =            N''

    ,    @WasherModelId                    SMALLINT        =            NULL

    ,    @CurrentUTCTime                    DATETIME        =            GETUTCDATE()
	,	@ControllerValidate				int				=										   0

--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
SET        @OutputLastModifiedTimestampAtLocal                =            @CurrentUTCTime
SET        @OutputTunnelId                                    =            ISNULL(@OutputTunnelId, NULL)            --SQLEnlight

--If the call is not local, check that the LastModifiedTime matches with the central
IF    (
        @LastModifiedTimestampAtCentral            IS NOT    NULL
    AND    NOT    EXISTS    (    SELECT    1
                        FROM    TCD.[Washer]            W
                        WHERE    W.EcolabAccountNumber    =    @EcolabAccountNumber
                            AND    W.WasherId                =    @WasherId
                            AND    W.LastModifiedTime        =    @LastModifiedTimestampAtCentral
					)
	)
	BEGIN
            SET            @ErrorId                    =    60000
            SET            @ErrorMessage                =    N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
            RAISERROR    (@ErrorMessage, 16, 1)
            SET            @ReturnValue                =    -1
            RETURN        (@ReturnValue)
	END

--Proceed, since it's either a local call or Synch. call with synch. time matching


--Valid Washer - based on Id...
IF    NOT    EXISTS    (    SELECT    1
                    FROM    [TCD].Washer                W
                    JOIN    [TCD].MachineSetup            MS
                        ON    W.WasherId                    =            MS.WasherId
                        AND    W.EcoLabAccountNumber        =            MS.EcoalabAccountNumber
                    WHERE    W.EcoLabAccountNumber        =            @EcoLabAccountNumber
                        AND    W.WasherId                    =            @WasherId
                        AND    MS.GroupId                    =            @WasherGroupId
                        AND    MS.IsTunnel                    =            'TRUE'
                        AND    W.Is_Deleted                =            'FALSE'
                        AND    MS.IsDeleted                =            'FALSE'
				)
			BEGIN
                SET        @ErrorId                        =            51006
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Washer-ID was provided for Updating.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET    @ReturnValue    =    -1
                RETURN    (@ReturnValue)
			END


--Check for uniqueness of PlantWasherNo. and Name
IF    EXISTS        (    SELECT    1
                    FROM    [TCD].Washer                W
                    JOIN    [TCD].MachineSetup            MS
                        ON    W.WasherId                    =            MS.WasherId
                        AND    W.EcoLabAccountNumber        =            MS.EcoalabAccountNumber
                    WHERE    W.EcoLabAccountNumber        =            @EcoLabAccountNumber
                        AND    W.WasherId                    <>            @WasherId
                        AND    (
                            W.PlantWasherNumber            =            @PlantWasherNumber
                            OR
                            MS.MachineName                =            @TunnelName
							)
                        AND    W.Is_Deleted                =            'FALSE'
                        AND    MS.IsDeleted                =            'FALSE'
				)
			BEGIN
                SET        @ErrorId                        =            51002
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Specified Plant Washer #/Name already exists.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET    @ReturnValue    =    -1
                RETURN    (@ReturnValue)
			END


--Check that it's a valid Controller type/model (one that can control a Tunnel)
IF	NOT	EXISTS	(	SELECT	1
					FROM	[TCD].ControllerModelControllerTypeMapping
														CMCTM
					JOIN	[TCD].ConduitController		CC
						ON	CC.ControllerTypeId			=			CMCTM.ControllerTypeId
						AND	CC.ControllerModelId		=			CMCTM.ControllerModelId
					WHERE	CC.EcoalabAccountNumber		=			@EcoLabAccountNumber
						AND	CC.ControllerId				=			@ControllerId
						AND	CC.IsDeleted				=			'FALSE'
						AND	CMCTM.CanControlTunnel		=			'TRUE'
				)
			BEGIN
				SET		@ErrorId						=			51003
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller was provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END

--IF  (  @ControllerValidate = 1)
--            BEGIN
--                SET        @ErrorId                        =            51003
--                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller was provided.'
--                --GOTO    ErrorHandler
--                RAISERROR    (@ErrorMessage, 16, 1)
--                SET    @ReturnValue    =    -1
--                RETURN    (@ReturnValue)
--            END


--EOF should not be an asocciated formula for the WG...
IF    EXISTS        (    SELECT    1
                    FROM    [TCD].TunnelProgramSetup    TPS
                    WHERE    TPS.EcolabAccountNumber        =            @EcoLabAccountNumber
                        AND    TPS.WasherGroupId            =            @WasherGroupId
                        AND    TPS.ProgramNumber            =            @ProgramNumber
                        AND    TPS.Is_Deleted                =            'FALSE'
				)
			BEGIN
                SET        @ErrorId                        =            51004
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An assoicated formula cannot be specified as End-Of-Formula.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET    @ReturnValue    =    -1
                RETURN    (@ReturnValue)
			END


--WasherMode check
IF    NOT    EXISTS    (    SELECT    1
                    FROM    [TCD].ControllerModelControllerTypeMapping
														CMCTM
                    JOIN    [TCD].ConduitController        CC
                        ON    CC.ControllerTypeId            =            CMCTM.ControllerTypeId
                        AND    CC.ControllerModelId        =            CMCTM.ControllerModelId
                    JOIN    [TCD].[WasherModeMapping]
														CTM2WM
                        ON    CMCTM.Id                    =            CTM2WM.ControllerModelControllerTypeMappingId
                    WHERE    CC.EcoalabAccountNumber        =            @EcoLabAccountNumber
                        AND    CC.ControllerId                =            @ControllerId
                        AND    CC.IsDeleted                =            'FALSE'
                        --AND    CMCTM.CanControlTunnel        =            'TRUE'
                        AND    CTM2WM.WasherModeId            =            @WasherMode
				)
			BEGIN
                SET        @ErrorId                        =            51005
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherMode was provided.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET    @ReturnValue    =    -1
                RETURN    (@ReturnValue)
			END


--select the WasherModelId based on name
SELECT    TOP    1
        @WasherModelId                        =            WMS.WasherModelId
FROM    [TCD].WasherModelSize                WMS
WHERE    WMS.RegionId                        =            @RegionId
    AND    WMS.WasherModelName                    =            @WasherModelName
    AND    WMS.ModelTypeId                    =            2                            --TypeId 2 for Tunnel
    AND    WMS.Is_Deleted                        =            'FALSE'

--LFSWasherNumber duplicate check...
IF    EXISTS    (    SELECT    1
                FROM    [TCD].MachineSetup                    MS
                WHERE    MS.ControllerId                    =            @ControllerId
                    AND    MS.MachineInternalId            =            @LFSWasherNumber
                    AND    MS.IsDeleted                    =            'FALSE'
                    AND    MS.WasherId                        <>            @WasherId
                    AND MS.EcoalabAccountNumber            =            @EcoLabAccountNumber
                    AND MS.IsTunnel                        =            'TRUE'
            )
            BEGIN
                SET        @ErrorId                        =            51010
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate LFSWasher# provided.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET        @ReturnValue    =    -1
                RETURN    (@ReturnValue)
            END
--ETechWasherNumber duplicate check...
IF(@ControllerModelId NOT IN (7,8,9,10,11,14))
BEGIN
IF EXISTS ( SELECT 1
    FROM [TCD].Washer  AS W
    JOIN [TCD].MachineSetup AS MS ON MS.WasherId = W.WasherId 
    where W.ETechWasherNumber = @ETechWasherNumber
	AND W.WasherId = @WasherId
	 AND  MS.IsTunnel                    =            'TRUE'
)  
BEGIN  

SET  @ErrorId      =   51012  
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate ETechWasherNumber# provided.'  
--GOTO ErrorHandler  
RAISERROR (@ErrorMessage, 16, 1)  
SET  @ReturnValue = -1  
RETURN (@ReturnValue)  
END
END

--Now attempt Update...
BEGIN    TRAN

UPDATE    MS
    SET    MS.MachineName                    =            @TunnelName
    ,    MS.ControllerId                =            @ControllerId
    ,    MS.MachineInternalId            =            @LFSWasherNumber
    ,    MS.NumberOfComp                =            @NumberOfComp
    ,    MS.LastModifiedByUserId            =            @UserId
FROM    [TCD].MachineSetup                MS
JOIN    [TCD].Washer                    W
    ON    MS.WasherId                    =            W.WasherId
    AND    MS.EcoalabAccountNumber            =            W.EcolabAccountNumber
WHERE    MS.WasherId                    =            @WasherId
    AND    MS.EcoalabAccountNumber            =            @EcoLabAccountNumber
    AND    MS.IsDeleted                    =            'FALSE'
    AND    W.Is_Deleted                    =            'FALSE'

--check for any error
SET    @ErrorId    =    @@ERROR

IF    (@ErrorId    <>    0)
BEGIN

        IF    @@TRANCOUNT    >    0
		BEGIN
            ROLLBACK    TRAN
		END
	
    SET        @ErrorMessage                =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating washer data.'
    --GOTO    Errorhandler
    RAISERROR    (@ErrorMessage, 16, 1)
    SET    @ReturnValue    =    -1
    RETURN    (@ReturnValue)
END

--else, continue with the rest of the update in the other table...
IF(@ControllerModelId IS NOT NULL AND @ControllerModelId = 7 )
BEGIN
UPDATE    W
    SET    W.ModelId                        =            @WasherModelId
    ,    W.PlantWasherNumber                =            @PlantWasherNumber
    ,    W.WasherMode                    =            @WasherMode
    ,    W.MaxLoad                        =            @MaxLoad
    ,    W.AWEActive                    =            'FALSE'
    ,    W.NumberOfTanks                =            @NumberOfTanks
    ,    W.TransferType                    =            @TransferType
    ,    W.PressExtractor                =            @PressExtractor
    ,    W.EmptyPocketNumber                =            @ProgramNumber
    ,    W.[Description]                =            @Description
    ,    W.LastModifiedByUserId            =            @UserId
    ,    W.LastModifiedTime                =            @CurrentUTCTime
    ,    W.RatioDosingActive                =              NULL    
    ,    W.EndOfFormula                    =            0
    ,    W.NumberOfCompartmentsConveyorBelt     =            @NumberOfCompartmentsConveyorBelt
    ,    W.MinMachineLoad                 =            @MinMachineLoad
    ,    W.MaxMachineLoad                 =            @MaxMachineLoad
    ,    W.ProgramSelectionByTime             =            @ProgramSelectionByTime
    ,    W.WeightSelectionByTime             =            @WeightSelectionByTime
    ,    W.WeightSelectionByAnalogInput     =            @WeightSelectionByAnalogInput
    ,    W.TunInTomMode                     =            @TunInTomMode
    ,    W.SignalStopTunActive             =            @SignalStopTunActive
    ,    W.SignalEjectionTunActive         =            @SignalEjectionTunActive
    ,    W.DelayTimeForTunWashingPrograms     =            @DelayTimeForTunWashingPrograms
    ,    W.KannegiesserPressSpecialMode     =            @KannegiesserPressSpecialMode
    ,    W.ValveOutputsUsedAsTomSignal         =            @ValveOutputsUsedAsTomSignal
    ,    W.ExtendedClockOrDataProtocol         =            @ExtendedClockOrDataProtocol
    ,    W.WeightCorrectionFcc             =            @WeightCorrectionFcc
	,	 W.ETechWasherNumber					=		@ETechWasherNumber
	,	W.KannegiesserDosageInPreparationTankMode = @KannegiesserDosageInPreparationTankMode
	,	W.BatchOk = @BatchOk
FROM    [TCD].Washer                    W
JOIN    [TCD].MachineSetup                MS
    ON    W.WasherId                    =            MS.WasherId
    AND    W.EcoLabAccountNumber            =            MS.EcoalabAccountNumber
WHERE    W.WasherId                    =            @WasherId
    AND    W.EcoLabAccountNumber            =            @EcoLabAccountNumber
    AND    W.Is_Deleted                    =            'FALSE'
    AND    MS.IsDeleted                    =            'FALSE'
END
ELSE IF(@ControllerModelId IS NOT NULL AND ( @ControllerModelId = 8	OR @ControllerModelId = 9	OR @ControllerModelId = 10 OR @ControllerModelId = 11 OR @ControllerModelId = 14))
BEGIN
UPDATE    W
    SET    W.ModelId                        =            @WasherModelId
    ,    W.PlantWasherNumber                =            @PlantWasherNumber
    ,    W.WasherMode                    =            @WasherMode
    ,    W.MaxLoad                        =            @MaxLoad
    ,    W.AWEActive                    =            'FALSE'
    ,    W.NumberOfTanks                =            @NumberOfTanks
    ,    W.TransferType                    =            @TransferType
    ,    W.PressExtractor                =            @PressExtractor
    ,    W.EmptyPocketNumber                =            @ProgramNumber
    ,    W.[Description]                =            @Description
    ,    W.LastModifiedByUserId            =            @UserId
    ,    W.LastModifiedTime                =            @CurrentUTCTime
    ,    W.RatioDosingActive                =              NULL    
    ,    W.EndOfFormula                    =            0
    ,    W.NumberOfCompartmentsConveyorBelt     =            @NumberOfCompartmentsConveyorBelt
    ,    W.MinMachineLoad                 =            @MinMachineLoad
    ,    W.MaxMachineLoad                 =            @MaxMachineLoad
    ,    W.TunInTomMode                     =            @TunInTomMode
    ,    W.DelayTimeForTunWashingPrograms     =            @DelayTimeForTunWashingPrograms
    ,    W.KannegiesserPressSpecialMode     =            @KannegiesserPressSpecialMode
    ,    W.WeightCorrectionFcc             =            @WeightCorrectionFcc
	,	 W.DateAndTimeWhenBatchEjects		=			@DateAndTimeWhenBatchEjects
	,	 W.AutoRinseDesamixAfter			=			@AutoRinseDesamixAfter
	,	 W.AutoRinseDesamix1For				=			@AutoRinseDesamix1For
	,	 W.AutoRinseDesamix2For				=			@AutoRinseDesamix2For
	,	 W.TemperatureAlarmProbe1			=			@TemperatureAlarmProbe1
	,	 W.TemperatureAlarmProbe2			=			@TemperatureAlarmProbe2
	,	 W.TemperatureAlarmProbe3			=			@TemperatureAlarmProbe3
	,	 W.UseMe1OfGroup					=			@UseMe1OfGroup
	,	 W.UseMe2OfGroup					=			@UseMe2OfGroup
	,	 W.ETechWasherNumber					=		@ETechWasherNumber

FROM    [TCD].Washer                    W
JOIN    [TCD].MachineSetup                MS
    ON    W.WasherId                    =            MS.WasherId
    AND    W.EcoLabAccountNumber            =            MS.EcoalabAccountNumber
WHERE    W.WasherId                    =            @WasherId
    AND    W.EcoLabAccountNumber            =            @EcoLabAccountNumber
    AND    W.Is_Deleted                    =            'FALSE'
    AND    MS.IsDeleted                    =            'FALSE'
END
ELSE
BEGIN
UPDATE    W
    SET    W.ModelId                        =            @WasherModelId
    ,    W.PlantWasherNumber                =            @PlantWasherNumber
    ,    W.WasherMode                    =            @WasherMode
    ,    W.MaxLoad                        =            @MaxLoad
    ,    W.AWEActive                    =            @AWEActive
    ,    W.NumberOfTanks                =            @NumberOfTanks
    ,    W.TransferType                    =            @TransferType
    ,    W.PressExtractor                =            @PressExtractor
    ,    W.EmptyPocketNumber                =            @ProgramNumber
    ,    W.[Description]                =            @Description
    ,    W.LastModifiedByUserId            =            @UserId
    ,    W.LastModifiedTime                =            @CurrentUTCTime
    ,   W.RatioDosingActive                =              @RatioDosingActive    
    ,   W.EndOfFormula                    =            @EndOfFormula
    ,    W.LfsWasher                     =            NULL
    ,    W.NumberOfCompartmentsConveyorBelt     =            NULL
    ,    W.MinMachineLoad                 =            NULL
    ,    W.MaxMachineLoad                 =            NULL
    ,    W.ProgramSelectionByTime             =            NULL
    ,    W.WeightSelectionByTime             =            NULL
    ,    W.WeightSelectionByAnalogInput     =            NULL
    ,    W.TunInTomMode                     =            NULL
    ,    W.SignalStopTunActive             =            NULL
    ,    W.SignalEjectionTunActive         =            NULL
    ,    W.DelayTimeForTunWashingPrograms     =            NULL
    ,    W.KannegiesserPressSpecialMode     =            NULL
    ,    W.ValveOutputsUsedAsTomSignal         =            NULL
    ,    W.ExtendedClockOrDataProtocol         =            NULL
    ,    W.WeightCorrectionFcc             =            NULL
	,	 W.ETechWasherNumber					=		@ETechWasherNumber
FROM    [TCD].Washer                    W
JOIN    [TCD].MachineSetup                MS
    ON    W.WasherId                    =            MS.WasherId
    AND    W.EcoLabAccountNumber            =            MS.EcoalabAccountNumber
WHERE    W.WasherId                    =            @WasherId
    AND    W.EcoLabAccountNumber            =            @EcoLabAccountNumber
    AND    W.Is_Deleted                    =            'FALSE'
    AND    MS.IsDeleted                    =            'FALSE'
END
--check for error, if none - commit the tran, else rollback
SET    @ErrorId    =    @@ERROR
IF    (@ErrorId    <>    0)
	BEGIN
        IF    (@@TRANCOUNT    >    0)
			BEGIN
				ROLLBACK
			END

        SET        @ErrorMessage                =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating washer data.'
        --GOTO    Errorhandler
        RAISERROR    (@ErrorMessage, 16, 1)
        SET    @ReturnValue    =    -1
        RETURN    (@ReturnValue)
	END
ELSE
	BEGIN
        IF    (@@TRANCOUNT    >    0)
			BEGIN
				COMMIT
			END

        SET    @OutputTunnelId    =    @WasherId
	END


--IF    (@ErrorId    =    0)
--    BEGIN
--        --GOTO    ExitModule
--        RETURN    (@ReturnValue)
--    END




--ErrorHandler:
--RAISERROR    (@ErrorMessage, 16, 1)
--SET    @ReturnValue    =    -1




--ExitModule:

SET    NOCOUNT    OFF
RETURN    (@ReturnValue)


END
GO
-------------------------------------------------------
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetWasherList]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetWasherList
	END
GO

CREATE	PROCEDURE    [TCD].[GetWasherList] -- '040242802', 4,2
     @EcoLabAccountNumber     NVARCHAR(1000)

    , @WasherGroupId       INT   =   NULL
    , @WasherId        INT   =   NULL
    , @Is_Deleted        bit   =   'FALSE'
AS
BEGIN

SET NOCOUNT ON


SELECT --*
  W.PlantWasherNumber    AS   WasherNumber
 , MS.MachineName     AS   WasherName
 , CASE MS.IsTunnel
   WHEN 'TRUE' THEN 'Tunnel'
   WHEN 'FALSE' THEN 'WasherExtractor'
  END        AS   WasherType
 , MS.IsTunnel      AS   WasherTypeFlag
 , WMS.WasherModelName    AS   WasherModel
 , WMS.WasherModelId    AS   WasherModelId
 , WMS.WasherSize     AS   WasherSize
 , CASE WHEN CC.ControllerId = 0 THEN '' ELSE CC.Name END AS   WasherControllerName
 , W.WasherId      AS   WasherId
 , WG.WasherGroupId    AS   WasherGroupId
 , WG.WasherGroupName    AS   WasherGroupName
 , CC.ControllerId     AS   WasherControllerId

 , W.[Description]     AS   WasherDescription
 , W.MaxLoad      AS   WashermaxLoad

 , W.WasherMode     AS   WasherModeId

 , W.AWEActive      AS   WasherAWEActive
 , MS.NumberOfComp     AS   WasherNumberOfCompartments

 , CAST(W.NumberOfTanks AS SMALLINT)
          AS   WasherNumberOfTanks
 , CAST(W.PressExtractor AS SMALLINT)
          AS   WasherPressExtractorId
 , CAST(W.TransferType  AS SMALLINT)
          AS   WasherTransferTypeId
 , CASE MS.IsTunnel WHEN 1 THEN CAST(W.EmptyPocketNumber AS SMALLINT) ELSE CAST(W.EndOfFormula AS SMALLINT) END AS WasherProgramNumber

 -- Columns for conventionals
 , W.HoldSignal     AS   HoldDelay
 , CAST(W.HoldDelay AS INT)  AS   HoldSignal
 , CAST(W.TargetTurnTime AS INT) AS   TargetTurnTime
 , CAST(W.WaterFlushTime AS INT) AS   WaterFlushTime
 , MS.MachineInternalId   AS   LFSWasherNumber

    --    Cols. for integration with Synch./Central
    ,    W.LastModifiedTime                AS            LastModifiedTime
    ,    W.LastSyncTime                    AS            LastSyncTime
    ,    W.Is_Deleted                    AS            Is_Deleted
    ,    W.EcoLabAccountNumber            AS            EcolabAccountNumber
    ,    (SELECT Count(*) FROM tcd.TunnelProgramSetup wps WHERE wps.WasherGroupId=@WasherGroupId AND wps.Is_Deleted=0) AS FormulaCount
    ,    GT.MyServiceCustMchGrpGuid
    ,    W.MyServiceCustMchGuid
    ,    WMS.MyServiceMCHId
    ,    TPE.Name                        AS            PressExtractorName
    ,    TTT.Name                        AS            TransferTypeName
    ,   W.RatioDosingActive                AS            RatioDosingActive
    ,    W.EcolabWasherId                AS            EcolabWasherNumber
    ,    CAST(W.EndOfFormula AS SMALLINT)     AS            EndOfFormula
    ,    W.MyServiceLastSynchTime             AS            MyServiceLastSynchTime
    ,    CC.ControllerTypeId                 AS            ControllerTypeId
    ,    CT.Name                         AS            ControllerType
    ,    CC.ControllerModelId             AS            ControllerModelId
    ,    CM.Name                         AS            ControllerModel
    ,    W.NumberOfCompartmentsConveyorBelt
    ,    W.MinMachineLoad
    ,    W.MaxMachineLoad
    ,    W.ProgramSelectionByTime
    ,    W.WeightSelectionByTime
    ,    W.WeightSelectionByAnalogInput
    ,    W.TunInTomMode
    ,    COALESCE(W.SignalStopTunActive,'TRUE')        AS          SignalStopTunActive
    ,    COALESCE(W.SignalEjectionTunActive,'TRUE')    AS          SignalEjectionTunActive
    ,    W.DelayTimeForTunWashingPrograms
    ,    W.KannegiesserPressSpecialMode
    ,    W.ValveOutputsUsedAsTomSignal
    ,    W.ExtendedClockOrDataProtocol
    ,    W.WeightCorrectionFcc
    ,    W.FlowSwitchNumber            
    ,    W.WasherStopExternalSignal    
    ,    COALESCE(W.OnHoldWESignalActive,'TRUE')         AS           OnHoldWESignalActive        
    ,    W.WasherOnHoldSignalDelay    
    ,    W.WEInTOMMode                
    ,    W.ManifoldFlushTime            
    ,    W.L1                        
    ,    W.L2                        
    ,    W.L3                        
    ,    W.L4                        
    ,    W.L5                        
    ,    W.L6                        
    ,    W.L7                        
    ,    W.L8                        
    ,    W.L9                        
    ,    W.L10                        
    ,    W.L11                        
    ,    W.L12
    ,   MS.IsPony AS IsPony
    ,    W.PlantId
    ,    W.UseMe1OfGroup
    ,    W.UseMe2OfGroup
    ,    W.UsePumpOfGroup
    ,    W.WasherStopUseFinalExtracting
    ,    W.TemperatureAlarmYesNo
    ,    W.PhProbe
    ,    w.WeightCell
    ,    W.Temperature
    ,    W.WaterCounter    
    ,    W.DateAndTimeWhenBatchEjects            
    ,    W.AutoRinseDesamixAfter            
    ,    W.AutoRinseDesamix1For
    ,    W.AutoRinseDesamix2For
    ,    W.TemperatureAlarmProbe1
    ,    W.TemperatureAlarmProbe2
    ,    W.TemperatureAlarmProbe3
	,   CAST(W.DefaultIdleTime AS INT) AS   DefaultIdleTime
	,   W.ETechWasherNumber AS    ETechWasherNumber 
	,	W.SignalAcceptanceTime AS SignalAcceptanceTime
	,	W.KannegiesserDosageInPreparationTankMode	AS KannegiesserDosageInPreparationTankMode
	,	W.BatchOk AS BatchOk

FROM    [TCD].WasherGroup                    WG
JOIN    [TCD].MachineGroup                    GT
    ON    WG.WasherGroupId                =            GT.Id
    AND    WG.EcolabAccountNumber            =            GT.EcolabAccountNumber
JOIN    [TCD].MachineSetup                    MS
    ON    WG.WasherGroupId                =            MS.GroupId
    AND    WG.EcolabAccountNumber            =            MS.EcoalabAccountNumber
JOIN    [TCD].Washer                        W
    ON    MS.WasherId                        =            W.WasherId
    AND    MS.EcoalabAccountNumber            =            W.EcoLabAccountNumber
JOIN    [TCD].WasherModelSize                WMS
    ON    W.ModelId                        =            WMS.WasherModelId
JOIN    [TCD].ConduitController                CC
    ON    MS.ControllerId                    =            CC.ControllerId
    AND    MS.EcoalabAccountNumber            =            CC.EcoalabAccountNumber
LEFT JOIN TCD.ControllerType CT  ON CT.Id = CC.ControllerTypeId  
LEFT JOIN TCD.ControllerModel CM ON CM.Id = CC.ControllerModelId
LEFT JOIN    [TCD].TunnelPressExtractor            TPE
    ON    W.PressExtractor                =            TPE.TunnelPressExtractorId        
LEFT JOIN    [TCD].TunnelTransferType            TTT
    ON    W.TransferType                    =            TTT.TunnelTransferTypeId
WHERE    GT.EcolabAccountNumber            =            @EcoLabAccountNumber
    AND    GT.GroupTypeId                       =            2
 
 AND (GT.Is_Deleted     =   'FALSE' OR GT.Is_Deleted = @Is_Deleted)
 AND WG.WasherGroupId    =   ISNULL(@WasherGroupId, WG.WasherGroupId)
 AND WG.EcolabAccountNumber   =   @EcoLabAccountNumber
 AND MS.EcoalabAccountNumber   =   @EcoLabAccountNumber
 AND (MS.IsDeleted     =   'FALSE' OR MS.IsDeleted = @Is_Deleted)
 AND (W.Is_Deleted     =   'FALSE' OR W.Is_Deleted = @Is_Deleted)
 AND W.WasherId      =   ISNULL(@WasherId, W.WasherId)
 AND W.EcoLabAccountNumber   =   @EcoLabAccountNumber




SET NOCOUNT OFF

END
GO
--------------------------------------------------------





IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[TunnelAnalogControlLevelTrigger]')
				AND type IN(N'TR'))
	BEGIN
		DROP TRIGGER
				[TCD].[TunnelAnalogControlLevelTrigger]
	END
GO

CREATE TRIGGER [TCD].[TunnelAnalogControlLevelTrigger] ON [TCD].[TunnelAnalogControlLevel]
    FOR INSERT,UPDATE
AS
     BEGIN
         SET NOCOUNT ON;
         DECLARE @AuditOperation_SQLInsertId TINYINT = NULL,
                 @AuditOperation_SQLUpdateId TINYINT = NULL,
                 @AuditOperation_AppDeleteId TINYINT = NULL,
                 @ErrorNumber INT = 0,
                 @ErrorMessage NVARCHAR( 2048 ) = NULL,
                 @ErrorSeverity INT = NULL,
                 @ErrorProcedure SYSNAME = NULL,
                 @MessageString NVARCHAR( 2500 ) = NULL,
                 @SoftDeleteFlag BIT = NULL	,			--0 for FALSE/1 for TRUE
                 @CurrentTimeStamp DATETIME = GETUTCDATE();	--CURRENT_TIMESTAMP
         --select	*	from	AuditOperation
         SELECT @AuditOperation_SQLInsertId = AO.OperationId
           FROM [TCD].AuditOperation AO
           WHERE AO.OperationCode = 'SQLInsert';
         SELECT @AuditOperation_SQLUpdateId = AO.OperationId
           FROM [TCD].AuditOperation AO
           WHERE AO.OperationCode = 'SQLUpdate';
         SELECT @AuditOperation_AppDeleteId = AO.OperationId
           FROM [TCD].AuditOperation AO
           WHERE AO.OperationCode = 'AppDelete';
         IF NOT EXISTS( SELECT 1
                          FROM [deleted] )
             BEGIN
                 BEGIN TRY
                     INSERT INTO [TCD].TunnelAnalogControlLevelHistory( TunnelAnalogControlLevelID,
                                                                        PlantID,
                                                                        TunnelAnalogControlLevelTypeID,
                                                                        WasherId,
                                                                        OperationTimestamp,
                                                                        OperationId,
                                                                        OperationByUserId,
                                                                        Level,
                                                                        Setpoint,
                                                                        FirstDose,
                                                                        FirstPause,
                                                                        Pulse,
                                                                        Pause,
                                                                        MaxTime,
                                                                        MinVal,
                                                                        MaxVal,
                                                                        CtrlDelay,
                                                                        DelayTrsf,
                                                                        LastModifiedTime,
                                                                        LastModifiedUserID )
                     SELECT TunnelAnalogControlLevelID,
                            PlantID,
                            TunnelAnalogControlLevelTypeID,
                            WasherId,
                            @CurrentTimeStamp,
                            @AuditOperation_SQLInsertId,
                            LastModifiedUserID,
                            Level,
                            Setpoint,
                            FirstDose,
                            FirstPause,
                            Pulse,
                            Pause,
                            MaxTime,
                            MinVal,
                            MaxVal,
                            CtrlDelay,
                            DelayTrsf,
                            LastModifiedTime,
                            LastModifiedUserID
                       FROM [inserted];
                 END TRY
                 BEGIN CATCH
                     SELECT @ErrorNumber = ERROR_NUMBER(),
                            @ErrorMessage = ERROR_MESSAGE(),
                            @ErrorProcedure = ERROR_PROCEDURE(),
                            @ErrorSeverity = ERROR_SEVERITY();

                     --GOTO	ErrorHandler
                     SET @MessageString = N'An error occured while updating Audit data for TunnelAnalogControlLevel table. The error is: ' + @ErrorMessage + '	' + 'Module: ' + @ErrorProcedure;
                     RAISERROR( @MessageString,@ErrorSeverity,1 );
                     RETURN;
                 END CATCH;
             END;

         ELSE	IF	EXISTS	(SELECT	1	FROM	[inserted])
         	BEGIN
         			--IF	UPDATE(Is_Deleted)
         			--	SET	@SoftDeleteFlag	=	'TRUE'
         			--ELSE
         			--	SET	@SoftDeleteFlag	=	'FALSE'
         			BEGIN
         					BEGIN	TRY
         							INSERT	[TCD].TunnelAnalogControlLevelHistory(
         							TunnelAnalogControlLevelID,		PlantID,				TunnelAnalogControlLevelTypeID,	
         							WasherId,						OperationTimestamp,		OperationId,			
         							OperationByUserId,				Level,	                Setpoint,
         							FirstDose,						FirstPause,             Pulse,
         							Pause,			                MaxTime,                MinVal,
         							MaxVal,			                CtrlDelay,              DelayTrsf,
         							LastModifiedTime,				LastModifiedUserID)
         					SELECT	
         							TunnelAnalogControlLevelID,		PlantID,				TunnelAnalogControlLevelTypeID,
         							WasherId,						@CurrentTimeStamp,		@AuditOperation_SQLUpdateId,
         							LastModifiedUserID,			Level,	                Setpoint,
         							FirstDose,						FirstPause,             Pulse,
         							Pause,			                MaxTime,                MinVal,
         							MaxVal,			                CtrlDelay,              DelayTrsf,
         							LastModifiedTime,				LastModifiedUserID
         					FROM	[inserted]
         					END	TRY
         					BEGIN	CATCH
         							SELECT	@ErrorNumber				=			ERROR_NUMBER()
         								,	@ErrorMessage				=			ERROR_MESSAGE()
         								,	@ErrorProcedure				=			ERROR_PROCEDURE()
         								,	@ErrorSeverity				=			ERROR_SEVERITY()
         							--GOTO	ErrorHandler
         							SET		@MessageString				=	N'An error occured while updating Audit data forTunnelAnalogControlLevel table. The error is: '
         																+	@ErrorMessage + '	'
         																+	'Module: ' + @ErrorProcedure
         							RAISERROR(@MessageString, @ErrorSeverity, 1)
         							RETURN
         					END	CATCH
         			END
         	END


         IF @ErrorNumber = 0
             --GOTO	ExitModule
             RETURN;
         ErrorHandler:
         SET @MessageString = N'An error occured while updating Audit data for TunnelAnalogControlLevel table. The error is: ' + @ErrorMessage + '	' + 'Module: ' + @ErrorProcedure;
         RAISERROR( @MessageString,@ErrorSeverity,1 );
         ExitModule:
         SET NOCOUNT OFF;
         RETURN;
     END;

GO

/*Remove Dispenser Version*/
IF EXISTS (SELECT 1 FROM tcd.Field f JOIN tcd.FieldGroupFieldMapping fgfm ON f.Id = fgfm.FieldId AND f.Label = 'Controller Version')
BEGIN
	DELETE FROM tcd.FieldGroupFieldMapping WHERE tcd.FieldGroupFieldMapping.FieldId IN (select Id from tcd.Field WHERE tcd.Field.Label = 'Controller Version')
	DELETE FROM tcd.Field WHERE tcd.Field.Label = 'Controller Version'
END
GO
/*End*/

/*Factor multiplier validation*/
IF NOT EXISTS (SELECT 1 FROM tcd.Field f WHERE f.ClassName= 'factmultiplier')
BEGIN
	UPDATE tcd.Field SET tcd.Field.Name = NULL, tcd.Field.ClassName= 'factmultiplier'  WHERE Label = 'Factors Multiplier'
END
GO
/*End*/

/*Second multiplier validation*/
IF NOT EXISTS (SELECT 1 FROM tcd.Field f WHERE f.ClassName= 'OZSecondMultiplier')
BEGIN
	UPDATE tcd.Field SET tcd.Field.Name = NULL, tcd.Field.ClassName= 'OZSecondMultiplier'  WHERE Label = 'OZ/Second Multiplier'
END
GO

/*Injection Quality multiplier validation*/
IF NOT EXISTS (SELECT 1 FROM tcd.Field f WHERE f.ClassName= 'QuantityMultiplier')
BEGIN
	UPDATE tcd.Field SET tcd.Field.Name = NULL, tcd.Field.ClassName= 'QuantityMultiplier'  WHERE Label = 'Injection Quantity Multiplier'
END
GO
/*End*/

