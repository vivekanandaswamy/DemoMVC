IF NOT EXISTS(SELECT
                      1 FROM TCD.ResourceKeyMaster WHERE KeyName = 'FIELD_TARGETTRANSFERPERHOUR')
	BEGIN
        INSERT INTO TCD.ResourceKeyMaster(
                KeyName, 
                KeyDescription)
        VALUES
               (
                'FIELD_TARGETTRANSFERPERHOUR', 
                'NULL');
    END;
GO
IF NOT EXISTS(SELECT
                      1
                  FROM TCD.ResourceKeyValue
                  WHERE KeyName = 'FIELD_TARGETTRANSFERPERHOUR'
                    AND languageID = 1)
	BEGIN
        INSERT INTO TCD.ResourceKeyValue(
                KeyName, 
                Value, 
                languageID, 
                LastModifiedTime)
        VALUES
               (
                'FIELD_TARGETTRANSFERPERHOUR', 
                'Target Transfer/Hour', 
                1, 
                GETDATE());
    END;
GO
IF NOT EXISTS(SELECT
                      1 FROM TCD.ResourceKeyPageMapping WHERE KeyName = 'FIELD_TARGETTRANSFERPERHOUR')
	BEGIN
        INSERT INTO TCD.ResourceKeyPageMapping(
                KeyName, 
                PageId)
        VALUES
               (
                'FIELD_TARGETTRANSFERPERHOUR', 
                31);
    END;
GO

IF NOT EXISTS(SELECT
                      1 FROM TCD.ResourceKeyMaster WHERE KeyName = 'FIELD_TARGETTRANSFERPERHOURMIN1')
	BEGIN
        INSERT INTO TCD.ResourceKeyMaster(
                KeyName, 
                KeyDescription)
        VALUES
               (
                'FIELD_TARGETTRANSFERPERHOURMIN1', 
                'NULL');
    END;
GO
IF NOT EXISTS(SELECT
                      1
                  FROM TCD.ResourceKeyValue
                  WHERE KeyName = 'FIELD_TARGETTRANSFERPERHOURMIN1'
                    AND languageID = 1)
	BEGIN
        INSERT INTO TCD.ResourceKeyValue(
                KeyName, 
                Value, 
                languageID, 
                LastModifiedTime)
        VALUES
               (
                'FIELD_TARGETTRANSFERPERHOURMIN1', 
                'Please enter greater than Zero.', 
                1, 
                GETDATE());
    END;
GO
IF NOT EXISTS(SELECT
                      1
                  FROM TCD.ResourceKeyPageMapping
                  WHERE KeyName = 'FIELD_TARGETTRANSFERPERHOURMIN1')
	BEGIN
        INSERT INTO TCD.ResourceKeyPageMapping(
                KeyName, 
                PageId)
        VALUES
               (
                'FIELD_TARGETTRANSFERPERHOURMIN1', 
                31);
    END;
GO

IF NOT EXISTS(SELECT
                      1
                  FROM TCD.ResourceKeyMaster
                  WHERE KeyName = 'FIELD_PLEASEENTERTARGETTRANSFERPERHOUR')
	BEGIN
        INSERT INTO TCD.ResourceKeyMaster(
                KeyName, 
                KeyDescription)
        VALUES
               (
                'FIELD_PLEASEENTERTARGETTRANSFERPERHOUR', 
                'NULL');
    END;
GO
IF NOT EXISTS(SELECT
                      1
                  FROM TCD.ResourceKeyValue
                  WHERE KeyName = 'FIELD_PLEASEENTERTARGETTRANSFERPERHOUR'
                    AND languageID = 1)
	BEGIN
        INSERT INTO TCD.ResourceKeyValue(
                KeyName, 
                Value, 
                languageID, 
                LastModifiedTime)
        VALUES
               (
                'FIELD_PLEASEENTERTARGETTRANSFERPERHOUR', 
                'Please enter Target Transfer/Hour.', 
                1, 
                GETDATE());
    END;
GO
IF NOT EXISTS(SELECT
                      1
                  FROM TCD.ResourceKeyPageMapping
                  WHERE KeyName = 'FIELD_PLEASEENTERTARGETTRANSFERPERHOUR')
	BEGIN
        INSERT INTO TCD.ResourceKeyPageMapping(
                KeyName, 
                PageId)
        VALUES
               (
                'FIELD_PLEASEENTERTARGETTRANSFERPERHOUR', 
                31);
    END;
GO


IF NOT EXISTS(SELECT
                      1
                  FROM sys.columns
                  WHERE Name = N'TargetTransferPerHour'
                    AND Object_ID = OBJECT_ID(N'[TCD].[Washer]'))
BEGIN
        ALTER TABLE TCD.Washer
        ADD
                TargetTransferPerHour INT NULL;
    END;
GO
 
IF NOT EXISTS(SELECT
                      *
                  FROM sys.default_constraints
                  WHERE object_id = OBJECT_ID(N'[TCD].[DF_Washer_TargetTransferPerHour]')
                    AND parent_object_id = OBJECT_ID(N'[TCD].[Washer]'))
BEGIN
        IF NOT EXISTS(SELECT
                              *
                          FROM dbo.sysobjects
                          WHERE id = OBJECT_ID(N'[DF_Washer_TargetTransferPerHour]')
                            AND type = 'D')
BEGIN 
                ALTER TABLE TCD.Washer
                ADD
                        CONSTRAINT DF_Washer_TargetTransferPerHour DEFAULT 0 FOR TargetTransferPerHour;
            END;
    END;
GO

IF NOT EXISTS(SELECT
                      1
                  FROM sys.columns
                  WHERE Name = N'TargetTransferPerHour'
                    AND Object_ID = OBJECT_ID(N'[TCD].[WasherHistory]'))
BEGIN
        ALTER TABLE TCD.WasherHistory
        ADD
                TargetTransferPerHour INT NULL;
    END;
GO
 
IF EXISTS(SELECT
                  * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[TCD].[WasherAuditTrigger]'))
	BEGIN
		DROP TRIGGER
			TCD.WasherAuditTrigger;
	END; 
	GO 

CREATE TRIGGER TCD.WasherAuditTrigger ON TCD.Washer
    FOR INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Auditoperation_Sqlinsertid TINYINT = NULL, 
            @Auditoperation_Sqlupdateid TINYINT = NULL, 
            @Auditoperation_Appdeleteid TINYINT = NULL, 
            @Errormessage NVARCHAR(2048) = NULL, 
            @Errorseverity INT = NULL, 
            @Errorprocedure SYSNAME = NULL, 
            @Messagestring NVARCHAR(2500) = NULL, 
            @Softdeleteflag BIT = NULL, 
            @Currenttimestamp DATETIME = GETUTCDATE();

    SELECT
            @Auditoperation_Sqlinsertid = AO.OperationId
        FROM TCD.AuditOperation AS AO
        WHERE AO.OperationCode = 'SQLInsert';
    SELECT
            @Auditoperation_Sqlupdateid = AO.OperationId
        FROM TCD.AuditOperation AS AO
        WHERE AO.OperationCode = 'SQLUpdate';
    SELECT
            @Auditoperation_Appdeleteid = AO.OperationId
        FROM TCD.AuditOperation AS AO
        WHERE AO.OperationCode = 'AppDelete';
    IF NOT EXISTS(SELECT
                          1 FROM deleted)
	   BEGIN
            BEGIN TRY
                INSERT INTO TCD.WasherHistory(
                        WasherId, 
                        OperationTimestamp, 
                        OperationId, 
                        OperationByUserId, 
                        EcoLabAccountNumber, 
                        PlantWasherNumber, 
                        ModelId, 
                        WasherMode, 
                        MaxLoad, 
                        AWEActive, 
                        EndOfFormula, 
                        Description, 
                        NumberOfTanks, 
                        TransferType, 
                        PressExtractor, 
                        HoldSignal, 
                        HoldDelay, 
                        TargetTurnTime, 
                        WaterFlushTime, 
                        Is_Deleted, 
                        LastModifiedTime, 
                        LastSyncTime, 
                        MyServiceCustMchGuid, 
                        MyServiceLastSynchTime, 
                        RatioDosingActive, 
                        EmptyPocketNumber, 
                        LfsWasher, 
                        NumberOfCompartmentsConveyorBelt, 
                        MinMachineLoad, 
                        MaxMachineLoad, 
                        ProgramSelectionByTime, 
                        WeightSelectionByTime, 
                        WeightSelectionByAnalogInput, 
                        TunInTomMode, 
                        SignalStopTunActive, 
                        SignalEjectionTunActive, 
                        DelayTimeForTunWashingPrograms, 
                        KannegiesserPressSpecialMode, 
                        ValveOutputsUsedAsTomSignal, 
                        ExtendedClockOrDataProtocol, 
                        WeightCorrectionFcc, 
                        FlowSwitchNumber, 
                        WasherStopExternalSignal, 
                        OnHoldWESignalActive, 
                        WasherOnHoldSignalDelay, 
                        WEInTOMMode, 
                        ManifoldFlushTime, 
                        L1, 
                        L2, 
                        L3, 
                        L4, 
                        L5, 
                        L6, 
                        L7, 
                        L8, 
                        L9, 
                        L10, 
                        L11, 
                        L12, 
                        UseMe1OfGroup, 
                        UseMe2OfGroup, 
                        UsePumpOfGroup, 
                        WasherStopUseFinalExtracting, 
                        TemperatureAlarmYesNo, 
                        PhProbe, 
                        WeightCell, 
                        Temperature, 
                        WaterCounter, 
                        AutoRinseDesamixAfter, 
                        AutoRinseDesamix1For, 
                        AutoRinseDesamix2For, 
                        DateAndTimeWhenBatchEjects, 
                        TemperatureAlarmProbe1, 
                        TemperatureAlarmProbe2, 
                        TemperatureAlarmProbe3, 
                        ExtractTimeForEOFSignal, 
                        TargetTransferPerHour)
                SELECT
                        WasherId, 
                        @Currenttimestamp, 
                        @Auditoperation_Sqlinsertid, 
                        LastModifiedByUserId, 
                        EcoLabAccountNumber, 
                        PlantWasherNumber, 
                        ModelId, 
                        WasherMode, 
                        MaxLoad, 
                        AWEActive, 
                        EndOfFormula, 
                        Description, 
                        NumberOfTanks, 
                        TransferType, 
                        PressExtractor, 
                        HoldSignal, 
                        HoldDelay, 
                        TargetTurnTime, 
                        WaterFlushTime, 
                        Is_Deleted, 
                        LastModifiedTime, 
                        LastSyncTime, 
                        MyServiceCustMchGuid, 
                        MyServiceLastSynchTime, 
                        RatioDosingActive, 
                        EmptyPocketNumber, 
                        LfsWasher, 
                        NumberOfCompartmentsConveyorBelt, 
                        MinMachineLoad, 
                        MaxMachineLoad, 
                        ProgramSelectionByTime, 
                        WeightSelectionByTime, 
                        WeightSelectionByAnalogInput, 
                        TunInTomMode, 
                        SignalStopTunActive, 
                        SignalEjectionTunActive, 
                        DelayTimeForTunWashingPrograms, 
                        KannegiesserPressSpecialMode, 
                        ValveOutputsUsedAsTomSignal, 
                        ExtendedClockOrDataProtocol, 
                        WeightCorrectionFcc, 
                        FlowSwitchNumber, 
                        WasherStopExternalSignal, 
                        OnHoldWESignalActive, 
                        WasherOnHoldSignalDelay, 
                        WEInTOMMode, 
                        ManifoldFlushTime, 
                        L1, 
                        L2, 
                        L3, 
                        L4, 
                        L5, 
                        L6, 
                        L7, 
                        L8, 
                        L9, 
                        L10, 
                        L11, 
                        L12, 
                        UseMe1OfGroup, 
                        UseMe2OfGroup, 
                        UsePumpOfGroup, 
                        WasherStopUseFinalExtracting, 
                        TemperatureAlarmYesNo, 
                        PhProbe, 
                        WeightCell, 
                        Temperature, 
                        WaterCounter, 
                        AutoRinseDesamixAfter, 
                        AutoRinseDesamix1For, 
                        AutoRinseDesamix2For, 
                        DateAndTimeWhenBatchEjects, 
                        TemperatureAlarmProbe1, 
                        TemperatureAlarmProbe2, 
                        TemperatureAlarmProbe3, 
                        ExtractTimeForEOFSignal, 
                        TargetTransferPerHour
			   FROM inserted;
            END TRY
            BEGIN CATCH
			 SELECT

/*@ErrorNumber				=			ERROR_NUMBER()
						,	*/

                        @Errormessage = ERROR_MESSAGE(), 
                        @Errorprocedure = ERROR_PROCEDURE(), 
                        @Errorseverity = ERROR_SEVERITY();

			 --GOTO	ErrorHandler

                SET @Messagestring = N'An error occured while updating Audit data for Washer table. The error is: ' + @Errormessage + '	' +
'Module: ' + @Errorprocedure;
                RAISERROR(@Messagestring, @Errorseverity, 1);
			 RETURN;
            END CATCH;
	   END;
    ELSE
			    BEGIN
            IF EXISTS(SELECT
                              1 FROM inserted)
					  BEGIN
                    IF UPDATE(Is_Deleted)
                        BEGIN
                            SET @Softdeleteflag = 'TRUE';
					  END;
				   ELSE
					  BEGIN
                            SET @Softdeleteflag = 'FALSE';
					  END;
				   BEGIN
                        BEGIN TRY
                            INSERT INTO TCD.WasherHistory(
                                    WasherId, 
                                    OperationTimestamp, 
                                    OperationId, 
                                    OperationByUserId, 
                                    EcoLabAccountNumber, 
                                    PlantWasherNumber, 
                                    ModelId, 
                                    WasherMode, 
                                    MaxLoad, 
                                    AWEActive, 
                                    EndOfFormula, 
                                    Description, 
                                    NumberOfTanks, 
                                    TransferType, 
                                    PressExtractor, 
                                    HoldSignal, 
                                    HoldDelay, 
                                    TargetTurnTime, 
                                    WaterFlushTime, 
                                    Is_Deleted, 
                                    LastModifiedTime, 
                                    LastSyncTime, 
                                    MyServiceCustMchGuid, 
                                    MyServiceLastSynchTime, 
                                    RatioDosingActive, 
                                    EmptyPocketNumber, 
                                    LfsWasher, 
                                    NumberOfCompartmentsConveyorBelt, 
                                    MinMachineLoad, 
                                    MaxMachineLoad, 
                                    ProgramSelectionByTime, 
                                    WeightSelectionByTime, 
                                    WeightSelectionByAnalogInput, 
                                    TunInTomMode, 
                                    SignalStopTunActive, 
                                    SignalEjectionTunActive, 
                                    DelayTimeForTunWashingPrograms, 
                                    KannegiesserPressSpecialMode, 
                                    ValveOutputsUsedAsTomSignal, 
                                    ExtendedClockOrDataProtocol, 
                                    WeightCorrectionFcc, 
                                    FlowSwitchNumber, 
                                    WasherStopExternalSignal, 
                                    OnHoldWESignalActive, 
                                    WasherOnHoldSignalDelay, 
                                    WEInTOMMode, 
                                    ManifoldFlushTime, 
                                    L1, 
                                    L2, 
                                    L3, 
                                    L4, 
                                    L5, 
                                    L6, 
                                    L7, 
                                    L8, 
                                    L9, 
                                    L10, 
                                    L11, 
                                    L12, 
                                    UseMe1OfGroup, 
                                    UseMe2OfGroup, 
                                    UsePumpOfGroup, 
                                    WasherStopUseFinalExtracting, 
                                    TemperatureAlarmYesNo, 
                                    PhProbe, 
                                    WeightCell, 
                                    Temperature, 
                                    WaterCounter, 
                                    AutoRinseDesamixAfter, 
                                    AutoRinseDesamix1For, 
                                    AutoRinseDesamix2For, 
                                    DateAndTimeWhenBatchEjects, 
                                    TemperatureAlarmProbe1, 
                                    TemperatureAlarmProbe2, 
                                    TemperatureAlarmProbe3, 
                                    ExtractTimeForEOFSignal, 
                                    TargetTransferPerHour)
						 SELECT
                                    WasherId, 
                                    @Currenttimestamp, 
                                    CASE
                                        WHEN @Softdeleteflag = 'FALSE' THEN @Auditoperation_Sqlupdateid
                                        WHEN @Softdeleteflag = 'TRUE' THEN @Auditoperation_Appdeleteid
                                    END, 
                                    LastModifiedByUserId, 
                                    EcoLabAccountNumber, 
                                    PlantWasherNumber, 
                                    ModelId, 
                                    WasherMode, 
                                    MaxLoad, 
                                    AWEActive, 
                                    EndOfFormula, 
                                    Description, 
                                    NumberOfTanks, 
                                    TransferType, 
                                    PressExtractor, 
                                    HoldSignal, 
                                    HoldDelay, 
                                    TargetTurnTime, 
                                    WaterFlushTime, 
                                    Is_Deleted, 
                                    LastModifiedTime, 
                                    LastSyncTime, 
                                    MyServiceCustMchGuid, 
                                    MyServiceLastSynchTime, 
                                    RatioDosingActive, 
                                    EmptyPocketNumber, 
                                    LfsWasher, 
                                    NumberOfCompartmentsConveyorBelt, 
                                    MinMachineLoad, 
                                    MaxMachineLoad, 
                                    ProgramSelectionByTime, 
                                    WeightSelectionByTime, 
                                    WeightSelectionByAnalogInput, 
                                    TunInTomMode, 
                                    SignalStopTunActive, 
                                    SignalEjectionTunActive, 
                                    DelayTimeForTunWashingPrograms, 
                                    KannegiesserPressSpecialMode, 
                                    ValveOutputsUsedAsTomSignal, 
                                    ExtendedClockOrDataProtocol, 
                                    WeightCorrectionFcc, 
                                    FlowSwitchNumber, 
                                    WasherStopExternalSignal, 
                                    OnHoldWESignalActive, 
                                    WasherOnHoldSignalDelay, 
                                    WEInTOMMode, 
                                    ManifoldFlushTime, 
                                    L1, 
                                    L2, 
                                    L3, 
                                    L4, 
                                    L5, 
                                    L6, 
                                    L7, 
                                    L8, 
                                    L9, 
                                    L10, 
                                    L11, 
                                    L12, 
                                    UseMe1OfGroup, 
                                    UseMe2OfGroup, 
                                    UsePumpOfGroup, 
                                    WasherStopUseFinalExtracting, 
                                    TemperatureAlarmYesNo, 
                                    PhProbe, 
                                    WeightCell, 
                                    Temperature, 
                                    WaterCounter, 
                                    AutoRinseDesamixAfter, 
                                    AutoRinseDesamix1For, 
                                    AutoRinseDesamix2For, 
                                    DateAndTimeWhenBatchEjects, 
                                    TemperatureAlarmProbe1, 
                                    TemperatureAlarmProbe2, 
                                    TemperatureAlarmProbe3, 
                                    ExtractTimeForEOFSignal, 
                                    TargetTransferPerHour
                                FROM inserted;
                        END TRY
                        BEGIN CATCH
                            SELECT

/*@ErrorNumber				=			ERROR_NUMBER()
								,	*/

                                    @Errormessage = ERROR_MESSAGE(), 
                                    @Errorprocedure = ERROR_PROCEDURE(), 
                                    @Errorseverity = ERROR_SEVERITY();

						 --GOTO	ErrorHandler

                            SET @Messagestring = N'An error occured while updating Audit data for Washer table. The error is: ' + @Errormessage + '	'
+ 'Module: ' + @Errorprocedure;
                            RAISERROR(@Messagestring, @Errorseverity, 1);
						 RETURN;
                        END CATCH;
				   END;
			    END;
	   END;
    SET NOCOUNT OFF;
    RETURN;
END;
GO

 IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[AddTunnel]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
                TCD.AddTunnel;
	END;
GO

/*	
Purpose					:	To add a new Tunnel from the Washer-Tunnel (General) setup screen

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version

*/

CREATE PROCEDURE TCD.AddTunnel
       @Myservicewasherid UNIQUEIDENTIFIER, 
       @Ecolabaccountnumber NVARCHAR(25), 
       @Washergroupid INT, 
       @Tunnelname NVARCHAR(50), 
       @Washermodelname NVARCHAR(50), 
       @Regionid SMALLINT,
       --				,	@Size									INT									--we don't need to save this; ModelId PK determines it
       @Controllerid INT, 
       @Lfswashernumber TINYINT = 1, --For tunnels, it will be 1 until a diff. number is passed (as per the scenario)
       @Plantwashernumber SMALLINT, 
       @Washermode TINYINT, 
       @Maxload SMALLINT, 
       @Aweactive BIT, 
       @Numberoftanks TINYINT, 
       @Numberofcomp TINYINT, --though this is INT in the table, we should not require it to be so
       @Transfertype TINYINT = NULL, 
       @Pressextractor TINYINT = NULL, 
       @Programnumber TINYINT, 
       @Endofformula TINYINT, 
       @Description NVARCHAR(1024) = NULL, 
       @Userid INT, 
       @Outputtunnelid INT OUTPUT,
				--Adding as part of re-factoring for integration with Synch/Configurator... generated TunnelId (re-named) is already being OUTPUT above
       @Outputlastmodifiedtimestampatlocal DATETIME = NULL OUTPUT, 
       @Ratiodosingactive BIT = 'False', 
       @Controllermodelid INT = NULL, 
       @Numberofcompartmentsconveyorbelt TINYINT = NULL, 
       @Maxmachineload TINYINT = NULL, 
       @Minmachineload TINYINT = NULL, 
       @Programselectionbytime BIT = NULL, 
       @Weightselectionbytime BIT = NULL, 
       @Weightselectionbyanaloginput BIT = NULL, 
       @Tunintommode BIT = NULL, 
       @Signalstoptunactive BIT = NULL, 
       @Signalejectiontunactive BIT = NULL, 
       @Delaytimefortunwashingprograms BIT = NULL, 
       @Kannegiesserpressspecialmode BIT = NULL, 
       @Valveoutputsusedastomsignal BIT = NULL, 
       @Extendedclockordataprotocol BIT = NULL, 
       @Weightcorrectionfcc BIT = NULL, 
       @Dateandtimewhenbatchejects BIT = NULL, 
       @Autorinsedesamixafter SMALLINT = NULL, 
       @Autorinsedesamix1for SMALLINT = NULL, 
       @Autorinsedesamix2for SMALLINT = NULL, 
       @Temperaturealarmprobe1 BIT = NULL, 
       @Temperaturealarmprobe2 BIT = NULL, 
       @Temperaturealarmprobe3 BIT = NULL, 
       @Useme1ofgroup TINYINT = NULL, 
       @Useme2ofgroup TINYINT = NULL, 
       @Etechwashernumber INT = NULL, 
       @Kannegiesserdosageinpreparationtankmode BIT = NULL, 
       @Batchok BIT = NULL, 
       @Transferperhour INT = NULL
AS
BEGIN

    SET NOCOUNT ON;


    DECLARE @Returnvalue INT = 0, 
            @Errorid INT = 0, 
            @Errormessage NVARCHAR(4000) = N'', 
            @Washerid INT = NULL, 
            @Washermodelid SMALLINT = NULL,
	--Adding for integration with Synch./Central
            @Currentutctime DATETIME = GETUTCDATE(), 
            @Controllervalidate INT = 0;

--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
    SET @Outputlastmodifiedtimestampatlocal = @Currentutctime;
    SET @Outputtunnelid = ISNULL(@Outputtunnelid, NULL);			--SQLEnlight

--Check that the WasherGroup being associated-to is a valid Tunnel-type WG...
    IF NOT EXISTS(SELECT
                          1
                      FROM TCD.WasherGroup AS WG
                           JOIN TCD.WasherGroupType AS WGT ON WG.WasherGroupTypeId = WGT.WasherGroupTypeId
                           JOIN TCD.MachineGroup AS GT									--this is actually the Groups table and NOT really a Group TYPE
                  ON WG.WasherGroupId = GT.Id			--GroupTypeId is actually the Id of the Group
                      WHERE WG.WasherGroupId = @Washergroupid
                        AND GT.EcolabAccountNumber = @Ecolabaccountnumber
                        AND GT.GroupTypeId = 2			--select	GroupMaintype	from	GroupType
                        AND WGT.WasherGroupTypeName = 'Tunnel'				--select	WasherGroupTypeName	from	WasherGroupType
				)
			BEGIN
            SET @Errorid = 51001;
            SET @Errormessage = N'' + CAST(@Errorid AS NVARCHAR(10)) + N': An invalid WasherGroup provided.';
				--GOTO	ErrorHandler
            RAISERROR(@Errormessage, 16, 1);
            SET @Returnvalue = -1;
            RETURN @Returnvalue;
        END;


--Check for only 1 tunnel for a WasherGroup
    IF EXISTS(SELECT
                      1
                  FROM TCD.MachineSetup AS MS
                       JOIN TCD.Washer AS W ON MS.WasherId = W.WasherId
                  WHERE MS.GroupId = @Washergroupid
                    AND MS.EcoalabAccountNumber = @Ecolabaccountnumber
                    AND MS.IsDeleted = 'FALSE'
                    AND MS.IsTunnel = 'TRUE'
                    AND W.Is_Deleted = 'FALSE')
			BEGIN
            SET @Errorid = 51008;
            SET @Errormessage = N'' + CAST(@Errorid AS NVARCHAR(10)) + N': A Tunnel has already been added to this Washer Group.';
				--GOTO	ErrorHandler
            RAISERROR(@Errormessage, 16, 1);
            SET @Returnvalue = -1;
            RETURN @Returnvalue;
        END;


--Check for unique PlantWasherNo.
    IF EXISTS(SELECT
                      1
                  FROM TCD.Washer AS W
                       JOIN TCD.MachineSetup AS MS ON W.WasherId = MS.WasherId
                                                  AND W.EcoLabAccountNumber = MS.EcoalabAccountNumber
                  WHERE W.EcoLabAccountNumber = @Ecolabaccountnumber
                    AND W.PlantWasherNumber = @Plantwashernumber
                    AND W.Is_Deleted = 'FALSE'
                    AND MS.IsDeleted = 'FALSE')
			BEGIN
            SET @Errorid = 51002;
            SET @Errormessage = N'' + CAST(@Errorid AS NVARCHAR(10)) + N': Specified Plant Washer #/ already exists.';
				--GOTO	ErrorHandler
            RAISERROR(@Errormessage, 16, 1);
            SET @Returnvalue = -1;
            RETURN @Returnvalue;
        END;


--Check that it's a valid Controller type/model (one that can control a Tunnel)

    EXEC @Controllervalidate = TCD.ValidateController 2, @Controllerid, @Ecolabaccountnumber;

    IF @Controllervalidate = 1
				
			BEGIN
            SET @Errorid = 51003;
            SET @Errormessage = N'' + CAST(@Errorid AS NVARCHAR(10)) + N': An invalid Controller was provided.';
				--GOTO	ErrorHandler
            RAISERROR(@Errormessage, 16, 1);
            SET @Returnvalue = -1;
            RETURN @Returnvalue;
        END;


--EOF should not be an asocciated formula for the WG...
    IF EXISTS(SELECT
                      1
                  FROM TCD.TunnelProgramSetup AS TPS
                  WHERE TPS.EcolabAccountNumber = @Ecolabaccountnumber
                    AND TPS.WasherGroupId = @Washergroupid
                    AND TPS.ProgramNumber = @Programnumber
                    AND TPS.Is_Deleted = 'FALSE')
			BEGIN
            SET @Errorid = 51004;
            SET @Errormessage = N'' + CAST(@Errorid AS NVARCHAR(10)) + N': An associated formula cannot be specified as End-Of-Formula.';
				--GOTO	ErrorHandler
            RAISERROR(@Errormessage, 16, 1);
            SET @Returnvalue = -1;
            RETURN @Returnvalue;
        END;


--WasherMode check
    IF NOT EXISTS(SELECT
                          1
                      FROM TCD.ControllerModelControllerTypeMapping AS CMCTM
                           JOIN TCD.ConduitController AS CC ON CC.ControllerTypeId = CMCTM.ControllerTypeId
                                                           AND CC.ControllerModelId = CMCTM.ControllerModelId
                           JOIN TCD.WasherModeMapping AS CTM2WM ON CMCTM.Id = CTM2WM.ControllerModelControllerTypeMappingId
                      WHERE CC.EcoalabAccountNumber = @Ecolabaccountnumber
                        AND CC.ControllerId = @Controllerid
                        AND CC.IsDeleted = 'FALSE'
                        AND CMCTM.MaxtunnelCount > 0
                        AND CTM2WM.WasherModeId = @Washermode)
			BEGIN
            SET @Errorid = 51005;
            SET @Errormessage = N'' + CAST(@Errorid AS NVARCHAR(10)) + N': An invalid WasherMode was provided.';
				--GOTO	ErrorHandler
            RAISERROR(@Errormessage, 16, 1);
            SET @Returnvalue = -1;
            RETURN @Returnvalue;
        END;


--select the WasherModelId based on name
    SELECT TOP 1
            @Washermodelid = WMS.WasherModelId
        FROM TCD.WasherModelSize AS WMS
        WHERE WMS.RegionId = @Regionid
          AND WMS.WasherModelName = @Washermodelname
          AND WMS.ModelTypeId = 2							--TypeId 2 for Tunnel
          AND WMS.Is_Deleted = 'FALSE';

--LFSWasherNumber duplicate check...
    IF EXISTS(SELECT
                      1
                  FROM TCD.MachineSetup AS MS
                  WHERE MS.ControllerId = @Controllerid
                    AND MS.MachineInternalId = @Lfswashernumber
                    AND MS.EcoalabAccountNumber = @Ecolabaccountnumber
                    AND MS.IsDeleted = 'FALSE'
                    AND MS.IsTunnel = 'TRUE')
			BEGIN
            SET @Errorid = 51010;
            SET @Errormessage = N'' + CAST(@Errorid AS NVARCHAR(10)) + N': Duplicate LFSWasher# provided.';
				--GOTO	ErrorHandler
            RAISERROR(@Errormessage, 16, 1);
            SET @Returnvalue = -1;
            RETURN @Returnvalue;
        END;
--ETechWasherNumber duplicate check...
    IF @Controllermodelid NOT IN(8, 9, 10, 11, 14)
BEGIN
            IF EXISTS(SELECT
                              1
                          FROM TCD.Washer AS W
                               JOIN TCD.MachineSetup AS MS ON MS.WasherId = W.WasherId
                          WHERE W.ETechWasherNumber = @Etechwashernumber
	 AND W.Is_Deleted = 0
                            AND W.ETechWasherNumber <> 0)
BEGIN  

                    SET @Errorid = 51012;
                    SET @Errormessage = N'' + CAST(@Errorid AS NVARCHAR(10)) + N': Duplicate ETechWasherNumber# provided.';  
--GOTO ErrorHandler  
                    RAISERROR(@Errormessage, 16, 1);
                    SET @Returnvalue = -1;
                    RETURN @Returnvalue;
                END;
        END;

--Now attempt to insert a new row for the tunnel record being created...
    BEGIN TRAN;
    IF @Controllermodelid IS NOT NULL
   AND @Controllermodelid = 7
BEGIN
            INSERT TCD.Washer(
                    MyServiceCustMchGuid, 
                    EcoLabAccountNumber, 
                    PlantWasherNumber, 
                    ModelId, 
                    WasherMode, 
                    MaxLoad, 
                    Description, 
                    Is_Deleted, 
                    LastModifiedByUserId, 
                    NumberOfTanks, 
                    TransferType, 
                    PressExtractor,
	--Adding for integration with Synch./Central
                    LastModifiedTime, 
                    EmptyPocketNumber, 
                    NumberOfCompartmentsConveyorBelt, 
                    MinMachineLoad, 
                    MaxMachineLoad, 
                    ProgramSelectionByTime, 
                    WeightSelectionByTime, 
                    WeightSelectionByAnalogInput, 
                    TunInTomMode, 
                    SignalStopTunActive, 
                    SignalEjectionTunActive, 
                    DelayTimeForTunWashingPrograms, 
                    KannegiesserPressSpecialMode, 
                    ValveOutputsUsedAsTomSignal, 
                    ExtendedClockOrDataProtocol, 
                    WeightCorrectionFcc, 
                    AWEActive, 
                    EndOfFormula, 
                    ETechWasherNumber, 
                    KannegiesserDosageInPreparationTankMode, 
                    BatchOk, 
                    TargetTransferPerHour)
            SELECT
                    @Myservicewasherid AS MyServiceWasherId, 
                    @Ecolabaccountnumber AS EcoLabAccountNumber, 
                    @Plantwashernumber AS PlantWasherNumber, 
                    @Washermodelid AS ModelId,
	--,	@Size							AS			Size
                    @Washermode AS WasherMode, 
                    @Maxload AS MaxLoad, 
                    @Description AS Description, 
                    'FALSE' AS Is_Deleted, 
                    @Userid AS LastModifiedByUserId, 
                    @Numberoftanks AS NumberOfTanks, 
                    @Transfertype AS TransferType, 
                    @Pressextractor AS PressExtractor, 
                    @Currentutctime AS LastModifiedTime, 
                    @Programnumber AS ProgramNumber, 
                    @Numberofcompartmentsconveyorbelt AS NumberOfCompartmentsConveyorBelt, 
                    @Minmachineload AS MinMachineLoad, 
                    @Maxmachineload AS MaxMachineLoad, 
                    @Programselectionbytime AS ProgramSelectionByTime, 
                    @Weightselectionbytime AS WeightSelectionByTime, 
                    @Weightselectionbyanaloginput AS WeightSelectionByAnalogInput, 
                    @Tunintommode AS TunInTomMode, 
                    @Signalstoptunactive AS SignalStopTunActive, 
                    @Signalejectiontunactive AS SignalEjectionTunActive, 
                    @Delaytimefortunwashingprograms AS DelayTimeForTunWashingPrograms, 
                    @Kannegiesserpressspecialmode AS KannegiesserPressSpecialMode, 
                    @Valveoutputsusedastomsignal AS ValveOutputsUsedAsTomSignal, 
                    @Extendedclockordataprotocol AS ExtendedClockOrDataProtocol, 
                    @Weightcorrectionfcc AS WeightCorrectionFcc, 
                    'FALSE' AS AWEActive, 
                    0 AS EndOfFormula, 
                    @Etechwashernumber AS ETechWasherNumber, 
                    @Kannegiesserdosageinpreparationtankmode AS KannegiesserDosageInPreparationTankMode, 
                    @Batchok AS BatchOk, 
                    @Transferperhour AS TargetTransferPerHour;
        END;
    ELSE
        BEGIN
            IF @Controllermodelid IS NOT NULL
           AND (@Controllermodelid = 8
             OR @Controllermodelid = 9
             OR @Controllermodelid = 10
             OR @Controllermodelid = 11
             OR @Controllermodelid = 14)
BEGIN
                    INSERT TCD.Washer(
                            MyServiceCustMchGuid, 
                            EcoLabAccountNumber, 
                            PlantWasherNumber, 
                            ModelId, 
                            WasherMode, 
                            MaxLoad, 
                            Description, 
                            Is_Deleted, 
                            LastModifiedByUserId, 
                            NumberOfTanks, 
                            TransferType, 
                            PressExtractor,
	--Adding for integration with Synch./Central
                            LastModifiedTime, 
                            EmptyPocketNumber, 
                            NumberOfCompartmentsConveyorBelt, 
                            MinMachineLoad, 
                            MaxMachineLoad, 
                            ProgramSelectionByTime, 
                            WeightSelectionByTime, 
                            WeightSelectionByAnalogInput, 
                            TunInTomMode, 
                            SignalStopTunActive, 
                            SignalEjectionTunActive, 
                            DelayTimeForTunWashingPrograms, 
                            KannegiesserPressSpecialMode, 
                            ValveOutputsUsedAsTomSignal, 
                            ExtendedClockOrDataProtocol, 
                            WeightCorrectionFcc, 
                            AWEActive, 
                            EndOfFormula, 
                            AutoRinseDesamixAfter, 
                            AutoRinseDesamix1For, 
                            AutoRinseDesamix2For, 
                            TemperatureAlarmProbe1, 
                            TemperatureAlarmProbe2, 
                            TemperatureAlarmProbe3, 
                            DateAndTimeWhenBatchEjects, 
                            ETechWasherNumber, 
                            UseMe1OfGroup, 
                            UseMe2OfGroup, 
                            TargetTransferPerHour)
                    SELECT
                            @Myservicewasherid AS MyServiceWasherId, 
                            @Ecolabaccountnumber AS EcoLabAccountNumber, 
                            @Plantwashernumber AS PlantWasherNumber, 
                            @Washermodelid AS ModelId,
	--,	@Size							AS			Size
                            @Washermode AS WasherMode, 
                            @Maxload AS MaxLoad, 
                            @Description AS Description, 
                            'FALSE' AS Is_Deleted, 
                            @Userid AS LastModifiedByUserId, 
                            @Numberoftanks AS NumberOfTanks, 
                            @Transfertype AS TransferType, 
                            @Pressextractor AS PressExtractor, 
                            @Currentutctime AS LastModifiedTime, 
                            @Programnumber AS ProgramNumber, 
                            @Numberofcompartmentsconveyorbelt AS NumberOfCompartmentsConveyorBelt, 
                            @Minmachineload AS MinMachineLoad, 
                            @Maxmachineload AS MaxMachineLoad, 
                            @Programselectionbytime AS ProgramSelectionByTime, 
                            @Weightselectionbytime AS WeightSelectionByTime, 
                            @Weightselectionbyanaloginput AS WeightSelectionByAnalogInput, 
                            @Tunintommode AS TunInTomMode, 
                            @Signalstoptunactive AS SignalStopTunActive, 
                            @Signalejectiontunactive AS SignalEjectionTunActive, 
                            @Delaytimefortunwashingprograms AS DelayTimeForTunWashingPrograms, 
                            @Kannegiesserpressspecialmode AS KannegiesserPressSpecialMode, 
                            @Valveoutputsusedastomsignal AS ValveOutputsUsedAsTomSignal, 
                            @Extendedclockordataprotocol AS ExtendedClockOrDataProtocol, 
                            @Weightcorrectionfcc AS WeightCorrectionFcc, 
                            'FALSE' AS AWEActive, 
                            0 AS EndOfFormula, 
                            @Autorinsedesamixafter, 
                            @Autorinsedesamix1for, 
                            @Autorinsedesamix2for, 
                            @Temperaturealarmprobe1, 
                            @Temperaturealarmprobe2, 
                            @Temperaturealarmprobe3, 
                            @Dateandtimewhenbatchejects, 
                            @Etechwashernumber AS ETechWasherNumber, 
                            @Useme1ofgroup AS UseMe1OfGroup, 
                            @Useme2ofgroup AS UseMe2OfGroup, 
                            @Transferperhour AS TargetTransferPerHour;
                END;
ELSE
BEGIN
                    INSERT TCD.Washer(
                            MyServiceCustMchGuid, 
                            EcoLabAccountNumber, 
                            PlantWasherNumber, 
                            ModelId, 
                            WasherMode, 
                            MaxLoad, 
                            AWEActive, 
                            EndOfFormula, 
                            Description, 
                            Is_Deleted, 
                            LastModifiedByUserId, 
                            NumberOfTanks, 
                            TransferType, 
                            PressExtractor,
	--Adding for integration with Synch./Central
                            LastModifiedTime, 
                            RatioDosingActive, 
                            EmptyPocketNumber, 
                            ETechWasherNumber, 
                            TargetTransferPerHour)
                    SELECT
                            @Myservicewasherid AS MyServiceWasherId, 
                            @Ecolabaccountnumber AS EcoLabAccountNumber, 
                            @Plantwashernumber AS PlantWasherNumber, 
                            @Washermodelid AS ModelId,
	--,	@Size							AS			Size
                            @Washermode AS WasherMode, 
                            @Maxload AS MaxLoad, 
                            @Aweactive AS AWEActive, 
                            @Endofformula AS EndOfFormula, 
                            @Description AS Description, 
                            'FALSE' AS Is_Deleted, 
                            @Userid AS LastModifiedByUserId, 
                            @Numberoftanks AS NumberOfTanks, 
                            @Transfertype AS TransferType, 
                            @Pressextractor AS PressExtractor, 
                            @Currentutctime AS LastModifiedTime, 
                            @Ratiodosingactive AS RatioDosingActive, 
                            @Programnumber AS ProgramNumber, 
                            @Etechwashernumber AS ETechWasherNumber, 
                            @Transferperhour AS TargetTransferPerHour;
                END;
        END;

    SET @Errorid = @@Error;
	
    IF @Errorid <> 0
	BEGIN
            IF @@Trancount > 0
			BEGIN
                    ROLLBACK TRAN;
                END;

            SET @Errormessage = N'' + CAST(@Errorid AS NVARCHAR(10)) + N': Error occurred creating new record for tunnel.';
			--GOTO	ErrorHandler
            RAISERROR(@Errormessage, 16, 1);
            SET @Returnvalue = -1;
            RETURN @Returnvalue;
        END;

--if no error, collect the id of the newly generated row...
    SELECT
            @Washerid = SCOPE_IDENTITY();


--insert in MachineSetup
    INSERT TCD.MachineSetup(
            WasherId, 
            GroupId, 
            MachineInternalId, 
            EcoalabAccountNumber, 
            MachineName, 
            IsTunnel, 
            ControllerId, 
            NumberOfComp, 
            IsDeleted, 
            LastModifiedByUserId)
    SELECT
            @Washerid AS WasherId, 
            @Washergroupid AS GroupId, 
            @Lfswashernumber AS MachineInternalId, 
            @Ecolabaccountnumber AS EcoalabAccountNumber, 
            @Tunnelname AS MachineName, 
            'TRUE' AS IsTunnel, 
            @Controllerid AS ControllerId, 
            @Numberofcomp AS NumberOfComp, 
            'FALSE' AS IsDeleted, 
            @Userid AS LastModifiedByUserId;

    SET @Errorid = @@Error;

    IF @Errorid <> 0
	BEGIN
            IF @@Trancount > 0
			BEGIN
                    ROLLBACK TRAN;
                END;

            SET @Errormessage = N'' + CAST(@Errorid AS NVARCHAR(10)) + N': Error occurred assoicating new record for tunnel.';
			--GOTO	ErrorHandler
            RAISERROR(@Errormessage, 16, 1);
            SET @Returnvalue = -1;
            RETURN @Returnvalue;
        END;
ELSE
	BEGIN
            IF @@Trancount > 0
			BEGIN
                    IF @Controllermodelid = 7
				BEGIN
                            UPDATE TCD.WasherGroup SET
                                    ControllerId = @Controllerid, 
                                    WasherDosingNumber = @Lfswashernumber
                                WHERE
                                    WasherGroupId = @Washergroupid;
                        END;
                    COMMIT;
                END;

			--SET the output param to be communicated back...
            SET @Outputtunnelid = @Washerid;
        END;



--IF	(	@ErrorId	=	0	)
--	BEGIN
--		--GOTO	ExitModule
--		RETURN	(@ReturnValue)
--	END




--ErrorHandler:
--RAISERROR	(@ErrorMessage, 16, 1)
--SET	@ReturnValue	=	-1




--ExitModule:

    SET NOCOUNT OFF;
    RETURN @Returnvalue;


END;
GO

 IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[UpdateTunnel]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
                TCD.UpdateTunnel;
	END;
GO


/*	
Purpose					:	To edit details of a new Tunnel from the Washer-Tunnel (General) setup screen

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version

*/


CREATE PROCEDURE TCD.UpdateTunnel
       @Ecolabaccountnumber NVARCHAR(25), 
       @Washerid INT, 
       @Washergroupid INT, --Not updated, for reference only
       @Tunnelname NVARCHAR(50), 
       @Washermodelname NVARCHAR(50), 
       @Regionid SMALLINT,
                --,    @Size                                INT
       @Controllerid INT, 
       @Lfswashernumber INT = 1, --For tunnels, it will be 1 until a diff. number is passed (as per the scenario)
       @Plantwashernumber SMALLINT, 
       @Washermode SMALLINT, 
       @Maxload SMALLINT, 
       @Aweactive BIT, 
       @Numberoftanks TINYINT, 
       @Numberofcomp INT, --though this is INT in the table, we should not require it to be so
       @Transfertype TINYINT, 
       @Pressextractor TINYINT, 
       @Programnumber TINYINT, 
       @Endofformula TINYINT, 
       @Description NVARCHAR(1024) = NULL, 
       @Userid INT,
				--Adding these 3 params as part of re-factoring for integration with Synch/Configurator
       @Outputtunnelid INT = NULL OUTPUT, 
       @Lastmodifiedtimestampatcentral DATETIME = NULL, --Nullable for local call; Synch/Central call will have to pass this -
																									--else, it will be treated as a local call
       @Outputlastmodifiedtimestampatlocal DATETIME = NULL OUTPUT, 
       @Ratiodosingactive BIT, 
       @Controllermodelid INT = NULL, 
       @Numberofcompartmentsconveyorbelt TINYINT = NULL, 
       @Maxmachineload SMALLINT = NULL, 
       @Minmachineload SMALLINT = NULL, 
       @Programselectionbytime BIT = NULL, 
       @Weightselectionbytime BIT = NULL, 
       @Weightselectionbyanaloginput BIT = NULL, 
       @Tunintommode BIT = NULL, 
       @Signalstoptunactive BIT = NULL, 
       @Signalejectiontunactive BIT = NULL, 
       @Delaytimefortunwashingprograms BIT = NULL, 
       @Kannegiesserpressspecialmode BIT = NULL, 
       @Valveoutputsusedastomsignal BIT = NULL, 
       @Extendedclockordataprotocol BIT = NULL, 
       @Weightcorrectionfcc BIT = NULL, 
       @Dateandtimewhenbatchejects BIT = NULL, 
       @Autorinsedesamixafter SMALLINT = NULL, 
       @Autorinsedesamix1for SMALLINT = NULL, 
       @Autorinsedesamix2for SMALLINT = NULL, 
       @Temperaturealarmprobe1 BIT = NULL, 
       @Temperaturealarmprobe2 BIT = NULL, 
       @Temperaturealarmprobe3 BIT = NULL, 
       @Useme1ofgroup TINYINT = NULL, 
       @Useme2ofgroup TINYINT = NULL, 
       @Etechwashernumber INT = NULL, 
       @Kannegiesserdosageinpreparationtankmode BIT = NULL, 
       @Batchok BIT = NULL, 
       @Transferperhour INT = NULL
AS
BEGIN

    SET NOCOUNT ON;


    DECLARE @Returnvalue INT = 0, 
            @Errorid INT = 0, 
            @Errormessage NVARCHAR(4000) = N'', 
            @Washermodelid SMALLINT = NULL, 
            @Currentutctime DATETIME = GETUTCDATE(), 
            @Controllervalidate INT = 0;

--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
    SET @Outputlastmodifiedtimestampatlocal = @Currentutctime;
    SET @Outputtunnelid = ISNULL(@Outputtunnelid, NULL);            --SQLEnlight

--If the call is not local, check that the LastModifiedTime matches with the central
    IF @Lastmodifiedtimestampatcentral IS NOT NULL
   AND NOT EXISTS(SELECT
                          1
                      FROM TCD.Washer AS W
                      WHERE W.EcolabAccountNumber = @Ecolabaccountnumber
                        AND W.WasherId = @Washerid
                        AND W.LastModifiedTime = @Lastmodifiedtimestampatcentral)
	BEGIN
            SET @Errorid = 60000;
            SET @Errormessage = N'' + CAST(@Errorid AS NVARCHAR(10)) + N': Record not in-synch between plant and central.';
            RAISERROR(@Errormessage, 16, 1);
            SET @Returnvalue = -1;
            RETURN @Returnvalue;
        END;

--Proceed, since it's either a local call or Synch. call with synch. time matching


--Valid Washer - based on Id...
    IF NOT EXISTS(SELECT
                          1
                      FROM TCD.Washer AS W
                           JOIN TCD.MachineSetup AS MS ON W.WasherId = MS.WasherId
                                                      AND W.EcoLabAccountNumber = MS.EcoalabAccountNumber
                      WHERE W.EcoLabAccountNumber = @Ecolabaccountnumber
                        AND W.WasherId = @Washerid
                        AND MS.GroupId = @Washergroupid
                        AND MS.IsTunnel = 'TRUE'
                        AND W.Is_Deleted = 'FALSE'
                        AND MS.IsDeleted = 'FALSE')
			BEGIN
            SET @Errorid = 51006;
            SET @Errormessage = N'' + CAST(@Errorid AS NVARCHAR(10)) + N': An invalid Washer-ID was provided for Updating.';
                --GOTO    ErrorHandler
            RAISERROR(@Errormessage, 16, 1);
            SET @Returnvalue = -1;
            RETURN @Returnvalue;
        END;


--Check for uniqueness of PlantWasherNo. and Name
    IF EXISTS(SELECT
                      1
                  FROM TCD.Washer AS W
                       JOIN TCD.MachineSetup AS MS ON W.WasherId = MS.WasherId
                                                  AND W.EcoLabAccountNumber = MS.EcoalabAccountNumber
                  WHERE W.EcoLabAccountNumber = @Ecolabaccountnumber
                    AND W.WasherId <> @Washerid
                    AND W.PlantWasherNumber = @Plantwashernumber
                    AND MS.MachineName = @Tunnelname
                    AND W.Is_Deleted = 'FALSE'
                    AND MS.IsDeleted = 'FALSE')
			BEGIN
            SET @Errorid = 51002;
            SET @Errormessage = N'' + CAST(@Errorid AS NVARCHAR(10)) + N': Specified Plant Washer #/Name already exists.';
                --GOTO    ErrorHandler
            RAISERROR(@Errormessage, 16, 1);
            SET @Returnvalue = -1;
            RETURN @Returnvalue;
        END;


--Check that it's a valid Controller type/model (one that can control a Tunnel)
    IF NOT EXISTS(SELECT
                          1
                      FROM TCD.ControllerModelControllerTypeMapping AS CMCTM
                           JOIN TCD.ConduitController AS CC ON CC.ControllerTypeId = CMCTM.ControllerTypeId
                                                           AND CC.ControllerModelId = CMCTM.ControllerModelId
                      WHERE CC.EcoalabAccountNumber = @Ecolabaccountnumber
                        AND CC.ControllerId = @Controllerid
                        AND CC.IsDeleted = 'FALSE'
						--AND	CMCTM.CanControlTunnel		=			'TRUE'
				)
			BEGIN
            SET @Errorid = 51003;
            SET @Errormessage = N'' + CAST(@Errorid AS NVARCHAR(10)) + N': An invalid Controller was provided.';
				--GOTO	ErrorHandler
            RAISERROR(@Errormessage, 16, 1);
            SET @Returnvalue = -1;
            RETURN @Returnvalue;
        END;

--IF  (  @ControllerValidate = 1)
--            BEGIN
--                SET        @ErrorId                        =            51003
--                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller was provided.'
--                --GOTO    ErrorHandler
--                RAISERROR    (@ErrorMessage, 16, 1)
--                SET    @ReturnValue    =    -1
--                RETURN    (@ReturnValue)
--            END


--EOF should not be an asocciated formula for the WG...
    IF EXISTS(SELECT
                      1
                  FROM TCD.TunnelProgramSetup AS TPS
                  WHERE TPS.EcolabAccountNumber = @Ecolabaccountnumber
                    AND TPS.WasherGroupId = @Washergroupid
                    AND TPS.ProgramNumber = @Endofformula
                    AND TPS.Is_Deleted = 'FALSE')
			BEGIN
            SET @Errorid = 51004;
            SET @Errormessage = N'' + CAST(@Errorid AS NVARCHAR(10)) + N': An assoicated formula cannot be specified as End-Of-Formula.';
                --GOTO    ErrorHandler
            RAISERROR(@Errormessage, 16, 1);
            SET @Returnvalue = -1;
            RETURN @Returnvalue;
        END;


--WasherMode check
    IF NOT EXISTS(SELECT
                          1
                      FROM TCD.ControllerModelControllerTypeMapping AS CMCTM
                           JOIN TCD.ConduitController AS CC ON CC.ControllerTypeId = CMCTM.ControllerTypeId
                                                           AND CC.ControllerModelId = CMCTM.ControllerModelId
                           JOIN TCD.WasherModeMapping AS CTM2WM ON CMCTM.Id = CTM2WM.ControllerModelControllerTypeMappingId
                      WHERE CC.EcoalabAccountNumber = @Ecolabaccountnumber
                        AND CC.ControllerId = @Controllerid
                        AND CC.IsDeleted = 'FALSE'
                        --AND    CMCTM.CanControlTunnel        =            'TRUE'
                        AND CTM2WM.WasherModeId = @Washermode)
			BEGIN
            SET @Errorid = 51005;
            SET @Errormessage = N'' + CAST(@Errorid AS NVARCHAR(10)) + N': An invalid WasherMode was provided.';
                --GOTO    ErrorHandler
            RAISERROR(@Errormessage, 16, 1);
            SET @Returnvalue = -1;
            RETURN @Returnvalue;
        END;


--select the WasherModelId based on name
    SELECT TOP 1
            @Washermodelid = WMS.WasherModelId
        FROM TCD.WasherModelSize AS WMS
        WHERE WMS.RegionId = @Regionid
          AND WMS.WasherModelName = @Washermodelname
          AND WMS.ModelTypeId = 2                            --TypeId 2 for Tunnel
          AND WMS.Is_Deleted = 'FALSE';

--LFSWasherNumber duplicate check...
    IF EXISTS(SELECT
                      1
                  FROM TCD.MachineSetup AS MS
                  WHERE MS.ControllerId = @Controllerid
                    AND MS.MachineInternalId = @Lfswashernumber
                    AND MS.IsDeleted = 'FALSE'
                    AND MS.WasherId <> @Washerid
                    AND MS.EcoalabAccountNumber = @Ecolabaccountnumber
                    AND MS.IsTunnel = 'TRUE')
            BEGIN
            SET @Errorid = 51010;
            SET @Errormessage = N'' + CAST(@Errorid AS NVARCHAR(10)) + N': Duplicate LFSWasher# provided.';
                --GOTO    ErrorHandler
            RAISERROR(@Errormessage, 16, 1);
            SET @Returnvalue = -1;
            RETURN @Returnvalue;
        END;
--ETechWasherNumber duplicate check...
    IF @Controllermodelid NOT IN(8, 9, 10, 11, 14)
BEGIN
            IF EXISTS(SELECT
                              1
                          FROM TCD.Washer AS W
                               JOIN TCD.MachineSetup AS MS ON MS.WasherId = W.WasherId
                          WHERE W.ETechWasherNumber = @Etechwashernumber
                            AND W.WasherId != @Washerid
	AND w.Is_Deleted = 0
                            AND W.ETechWasherNumber <> 0)
BEGIN  

                    SET @Errorid = 51012;
                    SET @Errormessage = N'' + CAST(@Errorid AS NVARCHAR(10)) + N': Duplicate ETechWasherNumber# provided.';  
--GOTO ErrorHandler  
                    RAISERROR(@Errormessage, 16, 1);
                    SET @Returnvalue = -1;
                    RETURN @Returnvalue;
                END;
        END;

--Now attempt Update...
    BEGIN TRAN;

    UPDATE MS SET
            MS.MachineName = @Tunnelname, 
            MS.ControllerId = @Controllerid, 
            MS.MachineInternalId = @Lfswashernumber, 
            MS.NumberOfComp = @Numberofcomp, 
            MS.LastModifiedByUserId = @Userid
        FROM TCD.MachineSetup MS
             JOIN TCD.Washer W ON MS.WasherId = W.WasherId
                              AND MS.EcoalabAccountNumber = W.EcolabAccountNumber
        WHERE
            MS.WasherId = @Washerid
        AND MS.EcoalabAccountNumber = @Ecolabaccountnumber
        AND MS.IsDeleted = 'FALSE'
        AND W.Is_Deleted = 'FALSE';

--check for any error
    SET @Errorid = @@Error;

    IF @Errorid <> 0
BEGIN

            IF @@Trancount > 0
		BEGIN
                    ROLLBACK TRAN;
                END;
	
            SET @Errormessage = N'' + CAST(@Errorid AS NVARCHAR(10)) + N' Error occurred updating washer data.';
    --GOTO    Errorhandler
            RAISERROR(@Errormessage, 16, 1);
            SET @Returnvalue = -1;
            RETURN @Returnvalue;
        END;

--else, continue with the rest of the update in the other table...
    IF @Controllermodelid IS NOT NULL
   AND @Controllermodelid = 7
        BEGIN
            UPDATE W SET
                    W.ModelId = @Washermodelid, 
                    W.PlantWasherNumber = @Plantwashernumber, 
                    W.WasherMode = @Washermode, 
                    W.MaxLoad = @Maxload, 
                    W.AWEActive = 'FALSE', 
                    W.NumberOfTanks = @Numberoftanks, 
                    W.TransferType = @Transfertype, 
                    W.PressExtractor = @Pressextractor, 
                    W.EmptyPocketNumber = @Programnumber, 
                    W.Description = @Description, 
                    W.LastModifiedByUserId = @Userid, 
                    W.LastModifiedTime = @Currentutctime, 
                    W.RatioDosingActive = NULL, 
                    W.EndOfFormula = 0, 
                    W.NumberOfCompartmentsConveyorBelt = @Numberofcompartmentsconveyorbelt, 
                    W.MinMachineLoad = @Minmachineload, 
                    W.MaxMachineLoad = @Maxmachineload, 
                    W.ProgramSelectionByTime = @Programselectionbytime, 
                    W.WeightSelectionByTime = @Weightselectionbytime, 
                    W.WeightSelectionByAnalogInput = @Weightselectionbyanaloginput, 
                    W.TunInTomMode = @Tunintommode, 
                    W.SignalStopTunActive = @Signalstoptunactive, 
                    W.SignalEjectionTunActive = @Signalejectiontunactive, 
                    W.DelayTimeForTunWashingPrograms = @Delaytimefortunwashingprograms, 
                    W.KannegiesserPressSpecialMode = @Kannegiesserpressspecialmode, 
                    W.ValveOutputsUsedAsTomSignal = @Valveoutputsusedastomsignal, 
                    W.ExtendedClockOrDataProtocol = @Extendedclockordataprotocol, 
                    W.WeightCorrectionFcc = @Weightcorrectionfcc, 
                    W.ETechWasherNumber = @Etechwashernumber, 
                    W.KannegiesserDosageInPreparationTankMode = @Kannegiesserdosageinpreparationtankmode, 
                    W.BatchOk = @Batchok, 
                    W.TargetTransferPerHour = @Transferperhour
                FROM TCD.Washer W
                     JOIN TCD.MachineSetup MS ON W.WasherId = MS.WasherId
                                             AND W.EcoLabAccountNumber = MS.EcoalabAccountNumber
                WHERE
                    W.WasherId = @Washerid
                AND W.EcoLabAccountNumber = @Ecolabaccountnumber
                AND W.Is_Deleted = 'FALSE'
                AND MS.IsDeleted = 'FALSE';
        END;
    ELSE
BEGIN
            IF @Controllermodelid IS NOT NULL
           AND (@Controllermodelid = 8
             OR @Controllermodelid = 9
             OR @Controllermodelid = 10
             OR @Controllermodelid = 11
             OR @Controllermodelid = 14)
BEGIN
                    UPDATE W SET
                            W.ModelId = @Washermodelid, 
                            W.PlantWasherNumber = @Plantwashernumber, 
                            W.WasherMode = @Washermode, 
                            W.MaxLoad = @Maxload, 
                            W.AWEActive = 'FALSE', 
                            W.NumberOfTanks = @Numberoftanks, 
                            W.TransferType = @Transfertype, 
                            W.PressExtractor = @Pressextractor, 
                            W.EmptyPocketNumber = @Programnumber, 
                            W.Description = @Description, 
                            W.LastModifiedByUserId = @Userid, 
                            W.LastModifiedTime = @Currentutctime, 
                            W.RatioDosingActive = NULL, 
                            W.EndOfFormula = 0, 
                            W.NumberOfCompartmentsConveyorBelt = @Numberofcompartmentsconveyorbelt, 
                            W.MinMachineLoad = @Minmachineload, 
                            W.MaxMachineLoad = @Maxmachineload, 
                            W.TunInTomMode = @Tunintommode, 
                            W.DelayTimeForTunWashingPrograms = @Delaytimefortunwashingprograms, 
                            W.KannegiesserPressSpecialMode = @Kannegiesserpressspecialmode, 
                            W.WeightCorrectionFcc = @Weightcorrectionfcc, 
                            W.DateAndTimeWhenBatchEjects = @Dateandtimewhenbatchejects, 
                            W.AutoRinseDesamixAfter = @Autorinsedesamixafter, 
                            W.AutoRinseDesamix1For = @Autorinsedesamix1for, 
                            W.AutoRinseDesamix2For = @Autorinsedesamix2for, 
                            W.TemperatureAlarmProbe1 = @Temperaturealarmprobe1, 
                            W.TemperatureAlarmProbe2 = @Temperaturealarmprobe2, 
                            W.TemperatureAlarmProbe3 = @Temperaturealarmprobe3, 
                            W.UseMe1OfGroup = @Useme1ofgroup, 
                            W.UseMe2OfGroup = @Useme2ofgroup, 
                            W.ETechWasherNumber = @Etechwashernumber, 
                            W.TargetTransferPerHour = @Transferperhour
                        FROM TCD.Washer W
                             JOIN TCD.MachineSetup MS ON W.WasherId = MS.WasherId
                                                     AND W.EcoLabAccountNumber = MS.EcoalabAccountNumber
                        WHERE
                            W.WasherId = @Washerid
                        AND W.EcoLabAccountNumber = @Ecolabaccountnumber
                        AND W.Is_Deleted = 'FALSE'
                        AND MS.IsDeleted = 'FALSE';
                END;
ELSE
BEGIN
                    UPDATE W SET
                            W.ModelId = @Washermodelid, 
                            W.PlantWasherNumber = @Plantwashernumber, 
                            W.WasherMode = @Washermode, 
                            W.MaxLoad = @Maxload, 
                            W.AWEActive = @Aweactive, 
                            W.NumberOfTanks = @Numberoftanks, 
                            W.TransferType = @Transfertype, 
                            W.PressExtractor = @Pressextractor, 
                            W.EmptyPocketNumber = @Programnumber, 
                            W.Description = @Description, 
                            W.LastModifiedByUserId = @Userid, 
                            W.LastModifiedTime = @Currentutctime, 
                            W.RatioDosingActive = @Ratiodosingactive, 
                            W.EndOfFormula = @Endofformula, 
                            W.LfsWasher = NULL, 
                            W.NumberOfCompartmentsConveyorBelt = NULL, 
                            W.MinMachineLoad = NULL, 
                            W.MaxMachineLoad = NULL, 
                            W.ProgramSelectionByTime = NULL, 
                            W.WeightSelectionByTime = NULL, 
                            W.WeightSelectionByAnalogInput = NULL, 
                            W.TunInTomMode = NULL, 
                            W.SignalStopTunActive = NULL, 
                            W.SignalEjectionTunActive = NULL, 
                            W.DelayTimeForTunWashingPrograms = NULL, 
                            W.KannegiesserPressSpecialMode = NULL, 
                            W.ValveOutputsUsedAsTomSignal = NULL, 
                            W.ExtendedClockOrDataProtocol = NULL, 
                            W.WeightCorrectionFcc = NULL, 
                            W.ETechWasherNumber = @Etechwashernumber, 
                            W.TargetTransferPerHour = @Transferperhour
                        FROM TCD.Washer W
                             JOIN TCD.MachineSetup MS ON W.WasherId = MS.WasherId
                                                     AND W.EcoLabAccountNumber = MS.EcoalabAccountNumber
                        WHERE
                            W.WasherId = @Washerid
                        AND W.EcoLabAccountNumber = @Ecolabaccountnumber
                        AND W.Is_Deleted = 'FALSE'
                        AND MS.IsDeleted = 'FALSE';
                END;
        END;
--check for error, if none - commit the tran, else rollback
    SET @Errorid = @@Error;
    IF @Errorid <> 0
	BEGIN
            IF @@Trancount > 0
			BEGIN
                    ROLLBACK;
                END;

            SET @Errormessage = N'' + CAST(@Errorid AS NVARCHAR(10)) + N' Error occurred updating washer data.';
        --GOTO    Errorhandler
            RAISERROR(@Errormessage, 16, 1);
            SET @Returnvalue = -1;
            RETURN @Returnvalue;
        END;
ELSE
	BEGIN
            IF @@Trancount > 0
			BEGIN
                    IF @Controllermodelid = 7
				BEGIN
                            UPDATE TCD.WasherGroup SET
                                    ControllerId = @Controllerid, 
                                    WasherDosingNumber = @Lfswashernumber
                                WHERE
                                    WasherGroupId = @Washergroupid;
                        END;
                    COMMIT;
                END;

            SET @Outputtunnelid = @Washerid;
        END;


--IF    (@ErrorId    =    0)
--    BEGIN
--        --GOTO    ExitModule
--        RETURN    (@ReturnValue)
--    END




--ErrorHandler:
--RAISERROR    (@ErrorMessage, 16, 1)
--SET    @ReturnValue    =    -1




--ExitModule:

    SET NOCOUNT OFF;
    RETURN @Returnvalue;


END;

GO

 IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetWasherList]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
                TCD.GetWasherList;
	END;
GO


/*	
Purpose					:	To populate the grid in the Washer setup --> Washers listing

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version

*/

CREATE PROCEDURE TCD.GetWasherList -- '040242802', 4,2
       @Ecolabaccountnumber NVARCHAR(25), 
       @Washergroupid INT = NULL, 
       @Washerid INT = NULL, 
       @Is_Deleted BIT = 'FALSE'
AS
BEGIN

    SET NOCOUNT ON;


SELECT --*
            W.PlantWasherNumber AS WasherNumber, 
            MS.MachineName AS WasherName, 
            CASE MS.IsTunnel
   WHEN 'TRUE' THEN 'Tunnel'
   WHEN 'FALSE' THEN 'WasherExtractor'
            END AS WasherType, 
            MS.IsTunnel AS WasherTypeFlag, 
            WMS.WasherModelName AS WasherModel, 
            WMS.WasherModelId AS WasherModelId, 
            WMS.WasherSize AS WasherSize, 
            CASE
                WHEN CC.ControllerId = 0 THEN ''
                ELSE CC.Name
            END AS WasherControllerName, 
            W.WasherId AS WasherId, 
            WG.WasherGroupId AS WasherGroupId, 
            WG.WasherGroupName AS WasherGroupName, 
            CC.ControllerId AS WasherControllerId, 
            W.Description AS WasherDescription, 
            W.MaxLoad AS WashermaxLoad, 
            W.WasherMode AS WasherModeId, 
            W.AWEActive AS WasherAWEActive, 
            MS.NumberOfComp AS WasherNumberOfCompartments, 
            CAST(W.NumberOfTanks AS SMALLINT) AS WasherNumberOfTanks, 
            CAST(W.PressExtractor AS SMALLINT) AS WasherPressExtractorId, 
            CAST(W.TransferType AS SMALLINT) AS WasherTransferTypeId, 
            CASE MS.IsTunnel
                WHEN 1 THEN CAST(W.EmptyPocketNumber AS SMALLINT)
                ELSE CAST(W.EndOfFormula AS SMALLINT)
            END AS WasherProgramNumber,

 -- Columns for conventionals
            W.HoldSignal AS HoldDelay, 
            CAST(W.HoldDelay AS INT) AS HoldSignal, 
            CAST(W.TargetTurnTime AS INT) AS TargetTurnTime, 
            CAST(W.WaterFlushTime AS INT) AS WaterFlushTime, 
            MS.MachineInternalId AS LFSWasherNumber,

    --    Cols. for integration with Synch./Central
            W.LastModifiedTime AS LastModifiedTime, 
            W.LastSyncTime AS LastSyncTime, 
            W.Is_Deleted AS Is_Deleted, 
            W.EcoLabAccountNumber AS EcolabAccountNumber, 
            (SELECT
                     COUNT(*)
                 FROM tcd.TunnelProgramSetup AS wps
                 WHERE wps.WasherGroupId = @Washergroupid
                   AND wps.Is_Deleted = 0) AS FormulaCount, 
            GT.MyServiceCustMchGrpGuid, 
            W.MyServiceCustMchGuid, 
            WMS.MyServiceMCHId, 
            TPE.Name AS PressExtractorName, 
            TTT.Name AS TransferTypeName, 
            W.RatioDosingActive AS RatioDosingActive, 
            W.EcolabWasherId AS EcolabWasherNumber, 
            CAST(W.EndOfFormula AS SMALLINT) AS EndOfFormula, 
            W.MyServiceLastSynchTime AS MyServiceLastSynchTime, 
            CC.ControllerTypeId AS ControllerTypeId, 
            CT.Name AS ControllerType, 
            CC.ControllerModelId AS ControllerModelId, 
            CM.Name AS ControllerModel, 
            W.NumberOfCompartmentsConveyorBelt, 
            W.MinMachineLoad, 
            W.MaxMachineLoad, 
            W.ProgramSelectionByTime, 
            W.WeightSelectionByTime, 
            W.WeightSelectionByAnalogInput, 
            W.TunInTomMode, 
            COALESCE(W.SignalStopTunActive, 'TRUE') AS SignalStopTunActive, 
            COALESCE(W.SignalEjectionTunActive, 'TRUE') AS SignalEjectionTunActive, 
            W.DelayTimeForTunWashingPrograms, 
            W.KannegiesserPressSpecialMode, 
            W.ValveOutputsUsedAsTomSignal, 
            W.ExtendedClockOrDataProtocol, 
            W.WeightCorrectionFcc, 
            W.FlowSwitchNumber, 
            W.WasherStopExternalSignal, 
            COALESCE(W.OnHoldWESignalActive, 'TRUE') AS OnHoldWESignalActive, 
            W.WasherOnHoldSignalDelay, 
            W.WEInTOMMode, 
            W.ManifoldFlushTime, 
            W.L1, 
            W.L2, 
            W.L3, 
            W.L4, 
            W.L5, 
            W.L6, 
            W.L7, 
            W.L8, 
            W.L9, 
            W.L10, 
            W.L11, 
            W.L12, 
            MS.IsPony AS IsPony, 
            W.PlantId, 
            W.UseMe1OfGroup, 
            W.UseMe2OfGroup, 
            W.UsePumpOfGroup, 
            W.WasherStopUseFinalExtracting, 
            W.TemperatureAlarmYesNo, 
            W.PhProbe, 
            w.WeightCell, 
            W.Temperature, 
            W.WaterCounter, 
            W.DateAndTimeWhenBatchEjects, 
            W.AutoRinseDesamixAfter, 
            W.AutoRinseDesamix1For, 
            W.AutoRinseDesamix2For, 
            W.TemperatureAlarmProbe1, 
            W.TemperatureAlarmProbe2, 
            W.TemperatureAlarmProbe3, 
            CAST(W.DefaultIdleTime AS INT) AS DefaultIdleTime, 
            W.ETechWasherNumber AS ETechWasherNumber, 
            W.SignalAcceptanceTime AS SignalAcceptanceTime, 
            W.KannegiesserDosageInPreparationTankMode AS KannegiesserDosageInPreparationTankMode, 
            W.BatchOk AS BatchOk, 
            W.ExtractTimeForEOFSignal AS ExtractTimeForEOFSignal, 
            W.TargetTransferPerHour AS TransferPerHour
        FROM TCD.WasherGroup AS WG
             JOIN TCD.MachineGroup AS GT ON WG.WasherGroupId = GT.Id
                                        AND WG.EcolabAccountNumber = GT.EcolabAccountNumber
             JOIN TCD.MachineSetup AS MS ON WG.WasherGroupId = MS.GroupId
                                        AND WG.EcolabAccountNumber = MS.EcoalabAccountNumber
             JOIN TCD.Washer AS W ON MS.WasherId = W.WasherId
                                 AND MS.EcoalabAccountNumber = W.EcoLabAccountNumber
             JOIN TCD.WasherModelSize AS WMS ON W.ModelId = WMS.WasherModelId
             JOIN TCD.ConduitController AS CC ON MS.ControllerId = CC.ControllerId
                                             AND MS.EcoalabAccountNumber = CC.EcoalabAccountNumber
             LEFT JOIN TCD.ControllerType AS CT ON CT.Id = CC.ControllerTypeId
             LEFT JOIN TCD.ControllerModel AS CM ON CM.Id = CC.ControllerModelId
             LEFT JOIN TCD.TunnelPressExtractor AS TPE ON W.PressExtractor = TPE.TunnelPressExtractorId
             LEFT JOIN TCD.TunnelTransferType AS TTT ON W.TransferType = TTT.TunnelTransferTypeId
        WHERE GT.EcolabAccountNumber = @Ecolabaccountnumber
          AND GT.GroupTypeId = 2
          AND (GT.Is_Deleted = 'FALSE'
            OR GT.Is_Deleted = @Is_Deleted)
          AND WG.WasherGroupId = ISNULL(@Washergroupid, WG.WasherGroupId)
          AND WG.EcolabAccountNumber = @Ecolabaccountnumber
          AND MS.EcoalabAccountNumber = @Ecolabaccountnumber
          AND (MS.IsDeleted = 'FALSE'
            OR MS.IsDeleted = @Is_Deleted)
          AND (W.Is_Deleted = 'FALSE'
            OR W.Is_Deleted = @Is_Deleted)
          AND W.WasherId = ISNULL(@Washerid, W.WasherId)
          AND W.EcoLabAccountNumber = @Ecolabaccountnumber;

 


    SET NOCOUNT OFF;

END;
GO

----------------------Start [TCD].[SaveSyncLoggingRequestDetails] procedure-------------------------------
IF NOT EXISTS(SELECT
                      *
                  FROM sys.objects
                  WHERE object_id = OBJECT_ID(N'[TCD].[SyncLogParameters]')
                    AND type IN(N'U'))
BEGIN
        CREATE TABLE TCD.SyncLogParameters(
                SyncLogParameterId TINYINT NOT NULL
                                           PRIMARY KEY, 
                SyncLogParameterName NVARCHAR(100) NULL);
    END;
GO

IF EXISTS(SELECT
                  *
              FROM sys.objects
              WHERE object_id = OBJECT_ID(N'[TCD].[SyncLogParameters]')
                AND type IN(N'U'))
BEGIN
        IF NOT EXISTS(SELECT
                              1 FROM TCD.SyncLogParameters WHERE SyncLogParameterId IN(1, 2, 3, 4, 5, 6, 7))
BEGIN
                INSERT INTO TCD.SyncLogParameters(
   SyncLogParameterId,
                        SyncLogParameterName)
VALUES
                       (
                        1, 
                        N'RequestType'), 
                       (
                        2, 
                        N'NoOfRecords'), 
                       (
                        3, 
                        N'Status'), 
                       (
                        4, 
                        N'FailureCount'), 
                       (
                        5, 
                        N'ExceptionMessage'), 
                       (
                        6, 
                        N'ExceptionType'), 
                       (
                        7, 
                        N'TCPServerName'), 
                       (
                        8, 
                        N'RequestData');
            END;
    END;
GO

IF NOT EXISTS(SELECT
                      *
                  FROM sys.objects
                  WHERE object_id = OBJECT_ID(N'[TCD].[SyncLogRequests]')
                    AND type IN(N'U'))
BEGIN
CREATE TABLE TCD.SyncLogRequests(
                SyncLogRequestId INT IDENTITY(1, 1)
                                     NOT NULL, 
				PlantId INT NOT NULL, 
				RequestLabel NVARCHAR(100) NOT NULL, 
                SyncLogParameterId TINYINT NOT NULL
                                           CONSTRAINT FK_SyncLogRequests_SyncLogParameterId FOREIGN KEY(SyncLogParameterId) REFERENCES TCD.
SyncLogParameters(
                SyncLogParameterId), 
				SyncLogParameterValue NVARCHAR(1000) NULL,
				CreatedDate DATETIME2 NOT NULL
									 CONSTRAINT DF_SyncLogRequests_CreatedDate DEFAULT GETUTCDATE(),
                CONSTRAINT UC_SyncLogRequests UNIQUE(PlantId, RequestLabel, SyncLogParameterId, CreatedDate));
    END;
GO

 IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[SaveSyncLoggingRequestDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
                TCD.SaveSyncLoggingRequestDetails;
	END;
GO

CREATE PROCEDURE TCD.SaveSyncLoggingRequestDetails(
       @Requestdata NVARCHAR(250), 
       @Requestlabel NVARCHAR(100), 
       @Requesttype NVARCHAR(100), 
       @Noofrecords INT, 
       @Plantid INT)
AS
BEGIN
    INSERT INTO TCD.SyncLogRequests(
            PlantId, 
            RequestLabel, 
            SyncLogParameterId, 
            SyncLogParameterValue)
    VALUES
           (
            @Plantid, 
            @Requestlabel, 
            1, 
            @Requesttype);

    INSERT INTO TCD.SyncLogRequests(
            PlantId, 
            RequestLabel, 
            SyncLogParameterId, 
            SyncLogParameterValue)
    VALUES
           (
            @Plantid, 
            @Requestlabel, 
            2, 
            @Noofrecords);

    INSERT INTO TCD.SyncLogRequests(
            PlantId, 
            RequestLabel, 
            SyncLogParameterId, 
            SyncLogParameterValue)
    VALUES
           (
            @Plantid, 
            @Requestlabel, 
            8, 
            @Requestdata);
END;
GO
---------------------End [TCD].[SaveSyncLoggingRequestDetails] procedure------------------------------

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetRewashFormulasByGroupId]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
                TCD.GetRewashFormulasByGroupId;
	END;
GO
CREATE PROCEDURE TCD.GetRewashFormulasByGroupId(
       @Washergroupid INT, 
       @Ecolabaccountnumber VARCHAR(100), 
       @Recordeddate DATETIME)
 AS 
   BEGIN    
    SET NOCOUNT ON;
    DECLARE @Washergrouptypename VARCHAR(50) = NULL, 
            @Controllerid INT = NULL, 
            @Controllermodelid INT = NULL;

   --Determine the WasherGroup type - Conventional/Tunnel
    SELECT
            @Washergrouptypename = WGT.WasherGroupTypeName
        FROM TCD.WasherGroup AS WG
             JOIN TCD.WasherGroupType AS WGT ON WG.WasherGroupTypeId = WGT.WasherGroupTypeId
             JOIN TCD.MachineGroup AS GT ON WG.WasherGroupId = GT.Id
        WHERE GT.EcolabAccountNumber = @Ecolabaccountnumber
          AND WG.WasherGroupId = @Washergroupid;

    SELECT
            @Controllerid = wg.ControllerId
        FROM TCD.WasherGroup AS wg
        WHERE wg.WasherGroupId = @Washergroupid
          AND wg.EcolabAccountNumber = @Ecolabaccountnumber;

    SELECT
            @Controllermodelid = cc.ControllerModelId
        FROM TCD.ConduitController AS cc
        WHERE cc.ControllerId = @Controllerid
          AND cc.EcoalabAccountNumber = @Ecolabaccountnumber;

    IF @Controllermodelid = 7
   AND @Washergrouptypename != 'Tunnel' -- MyControl
    BEGIN
            SET @Washergroupid = NULL;
        END;

 
    IF @Washergrouptypename = 'Tunnel'
  BEGIN
            SELECT DISTINCT
                    bd.ProgramMasterId, 
                    pm.Name
                FROM TCD.BatchData AS bd
                     INNER JOIN TCD.ProgramMaster AS pm ON bd.ProgramMasterId = pm.ProgramId
                     INNER JOIN TCD.TunnelProgramSetup AS wps ON pm.ProgramId = wps.ProgramId
                WHERE pm.EcolabAccountNumber = @Ecolabaccountnumber
                  AND wps.WasherGroupId = @Washergroupid
                  AND bd.GroupId = @Washergroupid
                  AND CAST(bd.StartDate AS DATE) = CAST(@Recordeddate AS DATE)
                  AND wps.Is_Deleted <> 1;
        END;
  ELSE
   BEGIN
   
            SELECT DISTINCT
                    bd.ProgramMasterId, 
                    pm.Name
                FROM TCD.BatchData AS bd
                     INNER JOIN TCD.ProgramMaster AS pm ON bd.ProgramMasterId = pm.ProgramId
                     INNER JOIN TCD.WasherProgramSetup AS wps ON pm.ProgramId = wps.ProgramId
                WHERE CASE
                          WHEN @Washergroupid IS NOT NULL THEN wps.WasherGroupId
	ELSE wps.ControllerID
                      END = CASE
                                WHEN @Washergroupid IS NOT NULL THEN @Washergroupid
                                ELSE @Controllerid
   END
                  AND wps.EcolabAccountNumber = @Ecolabaccountnumber
                  AND CAST(bd.StartDate AS DATE) = CAST(@Recordeddate AS DATE)
                  AND wps.Is_Deleted <> 1;
        END;
 
    SET NOCOUNT OFF;
END;
   GO
---------------------End [TCD].[GetRewashFormulasByGroupId] procedure------------------------------

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetManualRewashDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
                TCD.GetManualRewashDetails;
	END;
GO
CREATE PROCEDURE TCD.GetManualRewashDetails(
       @Washergroupid INT, 
       @Formulaid INT, 
       @Rewashreasonid INT, 
       @Ecolabaccountnumber NVARCHAR(25), 
       @Recordeddate DATETIME)
AS 
  BEGIN 
    SET NOCOUNT ON;
  
   SELECT TOP 1 
      RewashId, 
      RecordedDate, 
      Value
        FROM TCD.ManualRewash
        WHERE WasherGroupId = @Washergroupid
          AND FormulaId = @Formulaid
          AND RewashReasonId = @Rewashreasonid
          AND EcolabAccountNumber = @Ecolabaccountnumber
      AND IsDeleted <> 1
          AND CAST(RecordedDate AS DATE) = CAST(@Recordeddate AS DATE)
        ORDER BY
            RewashId DESC;
    SET NOCOUNT OFF;
END;
GO
---------------------End [TCD].[GetManualRewashDetails] procedure------------------------------
 IF NOT EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'TCD.PLCDiscrepancyData')
				AND type IN(N'U'))
	BEGIN
        CREATE TABLE TCD.PLCDiscrepancyData(
                PLCDiscrepancyDataId INT IDENTITY(1, 1)
                                         CONSTRAINT PK_PLCDiscrepancyData_PLCDiscrepancyDataId PRIMARY KEY, 
                ParentEntityType SMALLINT NOT NULL, 
                EntityType SMALLINT NOT NULL, 
                ParentEntityId INT NOT NULL
                                   CONSTRAINT DF_PLCDiscrepancyData_ParentEntityId DEFAULT 0, 
                EntityId INT NOT NULL
                             CONSTRAINT DF_PLCDiscrepancyData_EntityId DEFAULT 0, 
                SyncFromCentral BIT NOT NULL
                                    CONSTRAINT DF_PLCDiscrepancyData_IsCentral DEFAULT 0, 
                ControllerId INT NOT NULL
                                 CONSTRAINT FK_PLCDiscrepancyData_Controllerid FOREIGN KEY REFERENCES TCD.ConduitController(
                ControllerId), 
                SyncToPlc BIT NOT NULL
                              CONSTRAINT DF_PLCDiscrepancyData_SyncToPlc DEFAULT 0, 
                CreatedUserId INT NOT NULL
                                  CONSTRAINT DF_PLCDiscrepancyData_CreatedUserId DEFAULT 0, 
                LastModifiedUserId INT NULL, 
                LastModifiedTime DATETIME NOT NULL, 
                CONSTRAINT UK_PLCDiscrepancyData UNIQUE(ParentEntityType, EntityType, ParentEntityId, EntityId, ControllerId));
	END;
GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'TCD.SavePLCDiscrepancy')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.SavePLCDiscrepancy;
	END;
GO

IF NOT EXISTS(SELECT
                      1
                  FROM TCD.ConfigSettings AS cs
                  WHERE cs.KeyName = N'TransferPerHourRedLevel'
                    AND cs.Active = 1)
    BEGIN
        INSERT INTO TCD.ConfigSettings(
                KeyName, 
                Value, 
                Type, 
                Active)
        VALUES
               (
                'TransferPerHourRedLevel', 
                '75', 
                'DashBoardTransferPerHour', 
                1);
    END;
GO

IF NOT EXISTS(SELECT
                      1
                  FROM TCD.ConfigSettings AS cs
                  WHERE cs.KeyName = N'TransferPerHourGreenLevel'
                    AND cs.Active = 1)
 BEGIN
        INSERT INTO TCD.ConfigSettings(
                KeyName, 
                Value, 
                Type, 
                Active)
        VALUES
               (
                'TransferPerHourGreenLevel', 
                '90', 
                'DashBoardTransferPerHour', 
                1);
    END;
 GO

 IF EXISTS(SELECT
                  *
              FROM sys.objects
              WHERE object_id = OBJECT_ID(N'TCD.ReportChemicalConsumption')
                AND type IN(N'P', N'PC'))
    BEGIN
        DROP PROCEDURE
                TCD.ReportChemicalConsumption;
    END;
GO
CREATE PROCEDURE TCD.ReportChemicalConsumption
       @Startdate DATETIME = '', 
       @Enddate DATETIME = '', 
       @Ecolabaccountnumber NVARCHAR(25) = '', 
       @Machinetype VARCHAR(20) = '', 
       @Machinegroup VARCHAR(MAX) = '', 
       @Machine VARCHAR(MAX) = '', 
       @Ecolabcategory VARCHAR(MAX) = '', 
       @Chaincategory VARCHAR(MAX) = '', 
       @Plantformula VARCHAR(MAX) = '', 
       @Chainformula VARCHAR(MAX) = '', 
       @Customer VARCHAR(MAX) = '', 
       @Currencycode VARCHAR(3) = NULL, 
       @Userid INT = NULL, 
       @Formulasegement VARCHAR(MAX) = '', 
       --Formula segment,
       @Formulacategory VARCHAR(MAX) = '', 
       --Formula category
       @Formula VARCHAR(MAX) = '' --Formula
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Uomid INT;

    SELECT
            @Currencycode = ISNULL(um.CurrencyCode, 0)
        FROM TCD.UserMaster AS um
        WHERE um.UserId = @Userid;
    IF COUNT(@Currencycode) <> 1
        BEGIN
            SELECT
                    @Currencycode = p.CurrencyCode
                FROM TCD.Plant AS P
                WHERE P.EcolabAccountNumber = @Ecolabaccountnumber;
        END;

    SELECT
            @Uomid = ISNULL(um.UOMId, 0) FROM TCD.UserMaster AS um WHERE um.UserId = @Userid;
    IF @Uomid < 1
        BEGIN
            SELECT
                    @Uomid = p.UOMId
                FROM TCD.Plant AS P
                WHERE P.EcolabAccountNumber = @Ecolabaccountnumber;
        END;
    PRINT @Uomid;
    DECLARE @Reportgenerated INT = 6, 
            @Month INT = MONTH(GETDATE()), 
            @Noofloads INT, 
            @Noofprograms INT;

    -- Inserting the record into Report History
    INSERT INTO TCD.ReportHistory(
            EcolabAccountNumber, 
            UserId, 
            UserName, 
            DateAndTime, 
            ActionTypeId, 
            ActionDescription)
    SELECT
            @Ecolabaccountnumber, 
            UM.UserId, 
            UM.LoginName, 
            GETUTCDATE(), 
            @Reportgenerated, 
            CASE
                WHEN @Reportgenerated = 6 THEN 'Generated Report : Chemical Consumption Report'
            END
        FROM TCD.UserMaster AS UM
        WHERE UM.EcolabAccountNumber = @Ecolabaccountnumber
          AND UM.UserId = @Userid;
 
    --Declaraion of table variables
    DECLARE @Machinetypetable TABLE(
            MachineType VARCHAR(100));
    INSERT INTO @Machinetypetable
    EXEC TCD.CharlistToTable @Machinetype, ',';

    DECLARE @Washergrouptable TABLE(
            MachineGroup VARCHAR(100));
    INSERT INTO @Washergrouptable
    EXEC TCD.CharlistToTable @Machinegroup, ',';

    DECLARE @Machinetable TABLE(
            Machine VARCHAR(100));
    INSERT INTO @Machinetable
    EXEC TCD.CharlistToTable @Machine, ',';

    DECLARE @Ecolabcategorytable TABLE(
            EcolabCategory VARCHAR(100));
    INSERT INTO @Ecolabcategorytable
    EXEC TCD.CharlistToTable @Ecolabcategory, ',';

    DECLARE @Chaincategorytable TABLE(
            ChainCategory VARCHAR(100));
    INSERT INTO @Chaincategorytable
    EXEC TCD.CharlistToTable @Chaincategory, ',';

    DECLARE @Plantformulatable TABLE(
            PlantFormula VARCHAR(100));
    INSERT INTO @Plantformulatable
    EXEC TCD.CharlistToTable @Plantformula, ',';

    DECLARE @Chainformulatable TABLE(
            ChainFormula VARCHAR(100));
    INSERT INTO @Chainformulatable
    EXEC TCD.CharlistToTable @Chainformula, ',';

    DECLARE @Customertable TABLE(
            Customer VARCHAR(100));
    INSERT INTO @Customertable
    EXEC TCD.CharlistToTable @Customer, ',';

    --Formula Segment 
    DECLARE @Formulasegmenttable TABLE(
            FormulaSegment VARCHAR(1000));
    INSERT INTO @Formulasegmenttable
    EXEC TCD.CharlistToTable @Formulasegement, ',';

    --Formula category
    DECLARE @Formulacategorytable TABLE(
            FormulaCategory VARCHAR(1000), 
            Type CHAR(1));
    INSERT INTO @Formulacategorytable(
            FormulaCategory)
    EXEC TCD.CharlistToTable @Formulacategory, ','; 
  
    --Assuming Below 1000 Ecolab category --Drop down also they have to listed same way
    UPDATE @Formulacategorytable SET
            TYPE = 'E' WHERE
            FormulaCategory < 1000;
    --Above 1000 consider as Chain category--for chain category they need to Append in Drop down filters
    UPDATE @Formulacategorytable SET
            TYPE = 'C' WHERE
            FormulaCategory >= 1000;

    --Rollbacking to actual ID
    UPDATE @Formulacategorytable SET
            FormulaCategory = FormulaCategory - 1000 WHERE
            TYPE = 'C';
   
    --SELECT * FROM @FormulaCategoryTable

    INSERT INTO @Ecolabcategorytable(
            EcolabCategory)
    SELECT
            FormulaCategory FROM @Formulacategorytable WHERE Type = 'E';

    INSERT INTO @Chaincategorytable(
            ChainCategory)
    SELECT
            FormulaCategory FROM @Formulacategorytable WHERE Type = 'C';

    --Value Assigning
    IF EXISTS(SELECT
                      * FROM @Ecolabcategorytable)
   AND @Formulacategory != ''
        BEGIN
            SET @Ecolabcategory = @Formulacategory;
        END;
    IF EXISTS(SELECT
                      * FROM @Chaincategorytable)
   AND @Formulacategory != ''
        BEGIN
            SET @Chaincategory = @Formulacategory;
        END;

 
    --Formula Ecolab/Chain categories
    DECLARE @Formulatable TABLE(
            Formula VARCHAR(1000), 
            Type CHAR(1));
    INSERT INTO @Formulatable(
            Formula)
    EXEC TCD.CharlistToTable @Formula, ',';
  
    --Select * from @FormulaTable
    --Plant fomula   
    INSERT INTO @Plantformulatable(
            PlantFormula)
    SELECT
            Formula FROM @Formulatable; 
    --chain formula   
    INSERT INTO @Chainformulatable(
            ChainFormula)
    SELECT
            Formula FROM @Formulatable;  

    --Value Assigning
    IF EXISTS(SELECT
                      * FROM @Plantformulatable)
   AND @Formula != ''
        BEGIN
            SET @Plantformula = @Formula;
        END;
    IF EXISTS(SELECT
                      * FROM @Chainformulatable)
   AND @Formula != ''
        BEGIN
            SET @Chainformula = @Formula;
        END;
    --SELECT @PlantFormula,@ChainFormula

    DECLARE @Actualproduction DECIMAL(18, 2), 
            @Uom INT;
    SELECT
            @Uom = UM.UOMId FROM TCD.UserMaster AS UM WHERE UM.UserId = @Userid;
 
    --FInding Actual Production
    SELECT
            @Actualproduction = CASE @Uom
                                    WHEN 1 THEN SUM(ISNULL(spdr.ActualProduction, 0)) / 100.00
                                    WHEN 2 THEN ISNULL(TCD.FnConsumptionOnMetrics(SUM(ISNULL(spdr.ActualProduction, 0)), 'Weight', @Userid), 0)
                                END
        FROM tcd.ShiftProductionDataRollup AS spdr
             INNER JOIN TCD.ProductionShiftData AS PS ON PS.ShiftId = spdr.ShiftId
             INNER JOIN tcd.machinesetup AS ms ON ms.WasherId = spdr.MachineId --Added by Kiran For Formula Hierarchy
             INNER JOIN TCD.ProgramMaster AS PM ON SPDR.ProgramMasterId = PM.ProgramId
             LEFT OUTER JOIN(
                            --IF Chain Plant
                            SELECT
                                    PCP.PlantProgramId, 
                                    PCP.PlantChainId, 
                                    PCP.ChainTextileCategoryId, 
                                    PCP.EcolabTextileCategoryId, 
                                    PCP.FormulaSegmentId, 
                                    PCP.EcolabSaturationId
                                FROM TCD.PlantChainProgram AS PCP
                                     LEFT OUTER JOIN TCD.ChainTextileCategory AS CTC ON CTC.TextileId = PCP.ChainTextileCategoryId
                                     LEFT OUTER JOIN TCD.EcolabTextileCategory AS ETC ON ETC.TextileId = PCP.EcolabTextileCategoryId
                                     LEFT OUTER JOIN TCD.FormulaSegments AS FS ON FS.FormulaSegmentID = PCP.FormulaSegmentId
                                     LEFT OUTER JOIN TCD.EcolabSaturation AS ES ON ES.EcolabSaturationId = PCP.EcolabSaturationId) AS ChainPlant ON
PM.PlantProgramId = ChainPlant.PlantProgramId
             LEFT OUTER JOIN TCD.EcolabTextileCategory AS ETC1 ON ETC1.TextileId = PM.EcolabTextileCategoryId
             LEFT OUTER JOIN TCD.FormulaSegments AS FS1 ON FS1.FormulaSegmentID = PM.FormulaSegmentId
             LEFT OUTER JOIN TCD.EcolabSaturation AS ES1 ON ES1.EcolabSaturationId = PM.EcolabSaturationId
        ----End

        WHERE ISNULL(ms.IsPony, 0) = 0
          AND CASE @Startdate
                  WHEN '' THEN CASE
                                   WHEN MONTH(CAST(PS.StartDateTime AS DATE)) = @Month THEN 'TRUE'
                               END
                  ELSE CASE
                           WHEN PS.StartDateTime >= @Startdate
                            AND PS.StartDateTime <= @Enddate THEN 'TRUE'
                       END
              END = 'TRUE'
          AND CASE @Machinetype
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN spdr.MachineId IN(SELECT
                                                          MS.WasherId
                                                      FROM TCD.MachineSetup AS MS
                                                      WHERE MS.GroupId IN(
                                                  SELECT
                                                          WG.WasherGroupId
                                                      FROM TCD.WasherGroup AS WG
                                                      WHERE WG.WasherGroupTypeId IN(
                                                  SELECT
                                                          MachineType FROM @Machinetypetable))) THEN 'TRUE'
                       END
              END = 'TRUE'
          AND CASE @Machinegroup
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN spdr.MachineId IN(SELECT
                                                          MS.WasherId
                                                      FROM TCD.MachineSetup AS MS
                                                      WHERE MS.GroupId IN(
                                                  SELECT
                                                          MachineGroup FROM @Washergrouptable)) THEN 'TRUE'
                       END
              END = 'TRUE'
          AND CASE @Machine
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN spdr.MachineId IN(SELECT
                                                          Machine FROM @Machinetable) THEN 'TRUE'
                       END
              END = 'TRUE'
          AND CASE @Customer
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN spdr.CustomerId IN(SELECT
                                                           Customer FROM @Customertable) THEN 'TRUE'
                       END
              END = 'TRUE' 
              --Added by Kiran
          AND CASE @Ecolabcategory
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN PM.PlantProgramId IS NOT NULL THEN CASE
                                                                       WHEN ChainPlant.EcolabTextileCategoryId IN(SELECT
                                                                                                                          EcolabCategory FROM
@Ecolabcategorytable) THEN 'TRUE'
                                                                   END
                           ELSE CASE
                                    WHEN ETC1.TextileId IN(SELECT
                                                                   EcolabCategory FROM @Ecolabcategorytable) THEN 'TRUE'
                                END
                       END
              END = 'TRUE'
          AND CASE @Chaincategory
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN PM.PlantProgramId IS NOT NULL THEN CASE
                                                                       WHEN ChainPlant.ChainTextileCategoryId IN(SELECT
                                                                                                                         ChainCategory FROM
@Chaincategorytable) THEN 'TRUE'
                                                                   END
                           ELSE 'TRUE'
                       END
              END = 'TRUE'
          AND CASE @Plantformula
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN spdr.ProgramMasterId IN(SELECT
                                                                PlantFormula FROM @Plantformulatable) THEN 'TRUE'
                       END
              END = 'TRUE'
          AND CASE @Chainformula
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN PM.PlantProgramId IS NOT NULL THEN CASE
                                                                       WHEN ChainPlant.ChainTextileCategoryId IN(SELECT
                                                                                                                         ChainFormula FROM
@Chainformulatable) THEN 'TRUE'
                                                                   END
                           ELSE 'TRUE'
                       END
              END = 'TRUE'
          AND CASE @Formulasegement
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN PM.PlantProgramId IS NOT NULL THEN CASE
                                                                       WHEN ChainPlant.FormulaSegmentId IN(SELECT
                                                                                                                   FormulaSegment FROM
@Formulasegmenttable) THEN 'TRUE'
                                                                   END
                           ELSE CASE
                                    WHEN FS1.FormulaSegmentID IN(SELECT
                                                                         FormulaSegment FROM @Formulasegmenttable) THEN 'TRUE'
                                END
                       END
              END = 'TRUE';

    /**/

    DECLARE @Batchcount INT;

    SELECT
            @Batchcount = COUNT(DISTINCT bd.batchid)
        FROM tcd.BatchData AS bd
             INNER JOIN TCD.ProductionShiftData AS PS ON PS.ShiftId = bd.ShiftId
             INNER JOIN tcd.machinesetup AS ms ON ms.WasherId = bd.MachineId --Added by Kiran For Formula Hierarchy
             INNER JOIN TCD.ProgramMaster AS PM ON bd.ProgramMasterId = PM.ProgramId
             LEFT OUTER JOIN(
                            --IF Chain Plant
                            SELECT
                                    PCP.PlantProgramId, 
                                    PCP.PlantChainId, 
                                    PCP.ChainTextileCategoryId, 
                                    PCP.EcolabTextileCategoryId, 
                                    PCP.FormulaSegmentId, 
                                    PCP.EcolabSaturationId
                                FROM TCD.PlantChainProgram AS PCP
                                     LEFT OUTER JOIN TCD.ChainTextileCategory AS CTC ON CTC.TextileId = PCP.ChainTextileCategoryId
                                     LEFT OUTER JOIN TCD.EcolabTextileCategory AS ETC ON ETC.TextileId = PCP.EcolabTextileCategoryId
                                     LEFT OUTER JOIN TCD.FormulaSegments AS FS ON FS.FormulaSegmentID = PCP.FormulaSegmentId
                                     LEFT OUTER JOIN TCD.EcolabSaturation AS ES ON ES.EcolabSaturationId = PCP.EcolabSaturationId) AS ChainPlant ON
PM.PlantProgramId = ChainPlant.PlantProgramId
             LEFT OUTER JOIN TCD.EcolabTextileCategory AS ETC1 ON ETC1.TextileId = PM.EcolabTextileCategoryId
             LEFT OUTER JOIN TCD.FormulaSegments AS FS1 ON FS1.FormulaSegmentID = PM.FormulaSegmentId
             LEFT OUTER JOIN TCD.EcolabSaturation AS ES1 ON ES1.EcolabSaturationId = PM.EcolabSaturationId
        ----End

        WHERE ISNULL(ms.IsPony, 0) = 0
          AND CASE @Startdate
                  WHEN '' THEN CASE
                                   WHEN MONTH(CAST(PS.StartDateTime AS DATE)) = @Month THEN 'TRUE'
                               END
                  ELSE CASE
                           WHEN PS.StartDateTime >= @Startdate
                            AND PS.StartDateTime <= @Enddate THEN 'TRUE'
                       END
              END = 'TRUE'
          AND CASE @Machinetype
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN bd.MachineId IN(SELECT
                                                        MS.WasherId
                                                    FROM TCD.MachineSetup AS MS
                                                    WHERE MS.GroupId IN(
                                                SELECT
                                                        WG.WasherGroupId
                                                    FROM TCD.WasherGroup AS WG
                                                    WHERE WG.WasherGroupTypeId IN(
                                                SELECT
                                                        MachineType FROM @Machinetypetable))) THEN 'TRUE'
                       END
              END = 'TRUE'
          AND CASE @Machinegroup
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN bd.MachineId IN(SELECT
                                                        MS.WasherId
                                                    FROM TCD.MachineSetup AS MS
                                                    WHERE MS.GroupId IN(
                                                SELECT
                                                        MachineGroup FROM @Washergrouptable)) THEN 'TRUE'
                       END
              END = 'TRUE'
          AND CASE @Machine
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN bd.MachineId IN(SELECT
                                                        Machine FROM @Machinetable) THEN 'TRUE'
                       END
              END = 'TRUE' 
   
    
              --Added by Kiran
          AND CASE @Ecolabcategory
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN PM.PlantProgramId IS NOT NULL THEN CASE
                                                                       WHEN ChainPlant.EcolabTextileCategoryId IN(SELECT
                                                                                                                          EcolabCategory FROM
@Ecolabcategorytable) THEN 'TRUE'
                                                                   END
                           ELSE CASE
                                    WHEN ETC1.TextileId IN(SELECT
                                                                   EcolabCategory FROM @Ecolabcategorytable) THEN 'TRUE'
                                END
                       END
              END = 'TRUE'
          AND CASE @Chaincategory
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN PM.PlantProgramId IS NOT NULL THEN CASE
                                                                       WHEN ChainPlant.ChainTextileCategoryId IN(SELECT
                                                                                                                         ChainCategory FROM
@Chaincategorytable) THEN 'TRUE'
                                                                   END
                           ELSE 'TRUE'
                       END
              END = 'TRUE'
          AND CASE @Plantformula
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN bd.ProgramMasterId IN(SELECT
                                                              PlantFormula FROM @Plantformulatable) THEN 'TRUE'
                       END
              END = 'TRUE'
          AND CASE @Chainformula
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN PM.PlantProgramId IS NOT NULL THEN CASE
                                                                       WHEN ChainPlant.ChainTextileCategoryId IN(SELECT
                                                                                                                         ChainFormula FROM
@Chainformulatable) THEN 'TRUE'
                                                                   END
                           ELSE 'TRUE'
                       END
              END = 'TRUE'
          AND CASE @Formulasegement
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN PM.PlantProgramId IS NOT NULL THEN CASE
                                                                       WHEN ChainPlant.FormulaSegmentId IN(SELECT
                                                                                                                   FormulaSegment FROM
@Formulasegmenttable) THEN 'TRUE'
                                                                   END
                           ELSE CASE
                                    WHEN FS1.FormulaSegmentID IN(SELECT
                                                                         FormulaSegment FROM @Formulasegmenttable) THEN 'TRUE'
                                END
                       END
              END = 'TRUE';

    --Result Table
    DECLARE @Resultset TABLE(
            ChemicalName VARCHAR(100), 
            ActualConsumption DECIMAL(18, 5), 
            TargetConsumption DECIMAL(18, 5), 
            --MachineId INT,
            ProgramMasterId INT, 
            NoOfDays INT, 
            NoOfLoads DECIMAL(18, 2), 
            Cost DECIMAL(18, 5), 
            StartDateTime DATE, 
            PackageSizeId INT, 
            UnitWeightVolumeUOMId INT, 
            packagesizeweightuomcode VARCHAR(100));
    INSERT INTO @Resultset(
            ChemicalName, 
            ActualConsumption, 
            TargetConsumption, 
            --MachineId ,
            ProgramMasterId, 
            NoOfDays, 
            NoOfLoads, 
            Cost, 
            StartDateTime, 
            PackageSizeId, 
            UnitWeightVolumeUOMId, 
            packagesizeweightuomcode)
    SELECT
            TCD.RemoveMultipleSpaces(COALESCE(PM.EnvisionDisplayName, PM.Name)), 
            SUM(SCD.ActualConsumption), 
            SUM(SCD.TargetConsumption), 
            --SCD.MachineId,
            SCD.ProgramMasterId, 
            COUNT(DISTINCT CAST(DATEADD(SECOND, DATEDIFF(SECOND, GETUTCDATE(), GETDATE()), PS.StartDateTime) AS DATE)), 
            @Actualproduction, 
            SUM(SCD.ActualCost), 
            PS.StartDateTime, 
            PM.PackageSizeId, 
            CASE
                WHEN pm.PackageSizeId IS NULL
                 AND type = 'Liquid' THEN ISNULL(psi.UnitWeightVolumeUOMId, 6)
                WHEN pm.PackageSizeId IS NULL
                 AND type = 'Powder' THEN ISNULL(psi.UnitWeightVolumeUOMId, 12)
                ELSE psi.UnitWeightVolumeUOMId
            END AS UnitWeightVolumeUOMId, 
            CASE
                WHEN pm.PackageSizeId IS NULL
                 AND type = 'Liquid'
                 AND @Uomid = 1 THEN ISNULL(psi.packagesizeweightuomcode, 'gal')
                WHEN pm.PackageSizeId IS NULL
                 AND type = 'solid'
                 AND @Uomid = 1 THEN ISNULL(psi.packagesizeweightuomcode, 'lbs')
                WHEN type = 'Liquid'
                 AND @Uomid = 2 THEN 'L'
                WHEN pm.PackageSizeId IS NULL
                 AND type = 'solid'
                 AND @Uomid = 2 THEN ISNULL(psi.packagesizeweightuomcode, 'kg')
                WHEN pm.PackageSizeId IS NULL
                 AND type IS NOT NULL
                 AND @Uomid = 1 THEN ISNULL(psi.packagesizeweightuomcode, 'gal')
                WHEN pm.PackageSizeId IS NULL
                 AND type IS NOT NULL
                 AND @Uomid = 2 THEN ISNULL(psi.packagesizeweightuomcode, 'lbs')
                WHEN pm.PackageSizeId IS NULL
                 AND type IS NULL
                 AND @Uomid = 1 THEN 'gal'
                WHEN pm.PackageSizeId IS NULL
                 AND type IS NULL
                 AND @Uomid = 2 THEN 'L'
                WHEN type = 'UNKNOWN'
                 AND @Uomid = 1 THEN 'gal'
                WHEN type = 'UNKNOWN'
                 AND @Uomid = 2 THEN 'L'
                WHEN type = 'UNCLASSIFIED'
                 AND @Uomid = 1 THEN 'gal'
                WHEN type = 'UNCLASSIFIED'
                 AND @Uomid = 2 THEN 'L'
                WHEN psi.packagesizeweightuomcode = 'gal'
                 AND @Uomid = 2 THEN 'L'
                WHEN psi.packagesizeweightuomcode = 'lbs'
                 AND @Uomid = 2 THEN 'kg'
                WHEN psi.packagesizeweightuomcode = 'L'
                 AND @Uomid = 1 THEN 'gal'
                WHEN psi.packagesizeweightuomcode = 'kg'
                 AND @Uomid = 1 THEN 'lbs'
                ELSE psi.packagesizeweightuomcode
            END AS packagesizeweightuomcode
        FROM TCD.ShiftChemicalDataRollup AS SCD --inner join tcd.ShiftProductionDataRollup spd on spd.ShiftId=scd.ShiftId and spd.MachineId=scd.MachineId
             INNER JOIN TCD.ProductionShiftData AS PS ON SCD.SHIFTID = PS.ShiftId
             INNER JOIN TCD.ProgramMaster AS PRM ON SCD.ProgramMasterId = PRM.ProgramId
             LEFT OUTER JOIN TCD.ProductMaster AS PM ON SCD.ProductId = PM.ProductId
             INNER JOIN TCD.ProductdataMapping AS PDM ON PDM.ProductId = PM.ProductId
             LEFT OUTER JOIN TCD.PackageSize AS PSi ON PM.PackageSizeId = PSi.PackageSizeId --Added by Kiran For Formula Hierarchy 
             LEFT OUTER JOIN(
                            --IF Chain Plant
                            SELECT
                                    PCP.PlantProgramId, 
                                    PCP.PlantChainId, 
                                    PCP.ChainTextileCategoryId, 
                                    PCP.EcolabTextileCategoryId, 
                                    PCP.FormulaSegmentId, 
                                    PCP.EcolabSaturationId
                                FROM TCD.PlantChainProgram AS PCP
                                     LEFT OUTER JOIN TCD.ChainTextileCategory AS CTC ON CTC.TextileId = PCP.ChainTextileCategoryId
                                     LEFT OUTER JOIN TCD.EcolabTextileCategory AS ETC ON ETC.TextileId = PCP.EcolabTextileCategoryId
                                     LEFT OUTER JOIN TCD.FormulaSegments AS FS ON FS.FormulaSegmentID = PCP.FormulaSegmentId
                                     LEFT OUTER JOIN TCD.EcolabSaturation AS ES ON ES.EcolabSaturationId = PCP.EcolabSaturationId) AS ChainPlant ON
PRM.PlantProgramId = ChainPlant.PlantProgramId
             LEFT OUTER JOIN TCD.EcolabTextileCategory AS ETC1 ON ETC1.TextileId = PRM.EcolabTextileCategoryId
             LEFT OUTER JOIN TCD.FormulaSegments AS FS1 ON FS1.FormulaSegmentID = PRM.FormulaSegmentId
             LEFT OUTER JOIN TCD.EcolabSaturation AS ES1 ON ES1.EcolabSaturationId = PRM.EcolabSaturationId
        ----End
        WHERE SCD.machineID IN(SELECT
                                       ms.WasherId FROM TCD.MachineSetup AS ms WHERE ISNULL(ms.IsPony, 0) = 0) -- Exclude pony washers
          AND CASE @Startdate
                  WHEN '' THEN CASE
                                   WHEN MONTH(CAST(PS.StartDateTime AS DATE)) = @Month THEN 'TRUE'
                               END
                  ELSE CASE
                           WHEN PS.StartDateTime >= @Startdate
                            AND PS.StartDateTime <= @Enddate THEN 'TRUE'
                       END
              END = 'TRUE'
          AND CASE @Machinetype
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN SCD.MachineId IN(SELECT
                                                         MS.WasherId
                                                     FROM TCD.MachineSetup AS MS
                                                     WHERE MS.GroupId IN(
                                                 SELECT
                                                         WG.WasherGroupId
                                                     FROM TCD.WasherGroup AS WG
                                                     WHERE WG.WasherGroupTypeId IN(
                                                 SELECT
                                                         MachineType FROM @Machinetypetable))) THEN 'TRUE'
                       END
              END = 'TRUE'
          AND CASE @Machinegroup
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN SCD.MachineId IN(SELECT
                                                         MS.WasherId
                                                     FROM TCD.MachineSetup AS MS
                                                     WHERE MS.GroupId IN(
                                                 SELECT
                                                         MachineGroup FROM @Washergrouptable)) THEN 'TRUE'
                       END
              END = 'TRUE'
          AND CASE @Machine
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN SCD.MachineId IN(SELECT
                                                         Machine FROM @Machinetable) THEN 'TRUE'
                       END
              END = 'TRUE'
          AND CASE @Ecolabcategory
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN SCD.EcolabTextileId IN(SELECT
                                                               EcolabCategory FROM @Ecolabcategorytable) THEN 'TRUE'
                       END
              END = 'TRUE'
          AND CASE @Chaincategory
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN SCD.ChainTextileId IN(SELECT
                                                              ChainCategory FROM @Chaincategorytable) THEN 'TRUE'
                       END
              END = 'TRUE'
          AND CASE @Plantformula
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN SCD.ProgramMasterId IN(SELECT
                                                               PlantFormula FROM @Plantformulatable) THEN 'TRUE'
                       END
              END = 'TRUE'
          AND CASE @Chainformula
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN SCD.ProgramMasterId IN(SELECT
                                                               ChainFormula FROM @Chainformulatable) THEN 'TRUE'
                       END
              END = 'TRUE'
          AND CASE @Customer
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN SCD.CustomerId IN(SELECT
                                                          Customer FROM @Customertable) THEN 'TRUE'
                       END
              END = 'TRUE'
          AND CASE @Formulasegement
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN PRM.PlantProgramId IS NOT NULL THEN CASE
                                                                        WHEN ChainPlant.FormulaSegmentId IN(SELECT
                                                                                                                    FormulaSegment FROM
@Formulasegmenttable) THEN 'TRUE'
                                                                    END
                           ELSE CASE
                                    WHEN FS1.FormulaSegmentID IN(SELECT
                                                                         FormulaSegment FROM @Formulasegmenttable) THEN 'TRUE'
                                END
                       END
              END = 'TRUE'
        GROUP BY
            COALESCE(PM.EnvisionDisplayName, PM.Name), 
            SCD.ProgramMasterId, 
            PS.StartDateTime, 
            pm.PackageSizeId, 
            psi.UnitWeightVolumeUOMId, 
            psi.packagesizeweightuomcode, 
            pm.type;


    DECLARE @Exchangerate TABLE(
            ChemicalName VARCHAR(100), 
            Cost DECIMAL(18, 2));

    INSERT INTO @Exchangerate(
            ChemicalName, 
            Cost)
    SELECT
            ChemicalName, 
            SUM(Cost)
        FROM(SELECT
                     ChemicalName AS ChemicalName, 
                     SUM(ISNULL(Cost, 0)) * ISNULL(TCD.FnCurrencyExchangeRate(@Currencycode, StartDateTime), 1) AS Cost
                 FROM @Resultset
                 GROUP BY
                     ChemicalName, 
                     StartDateTime) AS A
        GROUP BY
            A.ChemicalName;


    SELECT
            ChemicalName, 
            CAST(ISNULL(TCD.UnitConversionbyUserUOM(ActualConsumption, ISNULL(packagesizeweightuomcode, 'gal'), @Userid), 0) AS DECIMAL(18, 2)),
            --ActualConsumption * 0.0078125 AS ActualConsumption,--gal
            CAST(ISNULL(TCD.UnitConversionbyUserUOM(TargetConsumption, ISNULL(packagesizeweightuomcode, 'gal'), @Userid), 0) AS DECIMAL(18, 2)),
            --TargetConsumption * 0.0078125 AS TargetConsumption,--gal
            @Batchcount AS ProgramCount, 
            NoOfLoads, 
            NoOfDays, 
            Cost, 
            CAST(CAST(Cost AS DECIMAL(18, 2)) / CASE
                                                    WHEN ActualConsumption = 0 THEN 1
                                                    ELSE ActualConsumption
                                                END * ISNULL(TargetConsumption, 0) AS DECIMAL(18, 2)) AS TargetCost, 
            CASE
                WHEN @Uom = 2
                 AND packagesizeweightuomcode = 'L' THEN CAST(ISNULL(TCD.UnitConversionbyUserUOM(ActualConsumption, ISNULL('mL', 'L'), @Userid), 0)
AS DECIMAL(18, 2))
                WHEN @Uom = 2
                 AND packagesizeweightuomcode = 'kg' THEN CAST(ISNULL(TCD.UnitConversionbyUserUOM(ActualConsumption, ISNULL('g', 'kg'), @Userid), 0)
AS DECIMAL(18, 2))
                ELSE ActualConsumption
            END AS ActualConsumptionMetrics, 

            --isnull(packagesizeweightuomcode,'gal') as UOM
            packagesizeweightuomcode AS UOM
        FROM(SELECT
                     r.ChemicalName, 
                     SUM(ActualConsumption) AS ActualConsumption, 
                     SUM(TargetConsumption) AS TargetConsumption, 
                     COUNT(ProgramMasterId) AS ProgramCount, 
                     COUNT(DISTINCT r.StartDateTime) AS NoOfDays, 
                     MAX(NoOfLoads) AS NoOfLoads, 
                     e.Cost AS Cost, 
                     PackageSizeId, 
                     UnitWeightVolumeUOMId, 
                     packagesizeweightuomcode
             --* ISNULL([TCD].[FnCurrencyExchangeRate](@CurrencyCode,MONTH(StartDateTime),YEAR(StartDateTime)),1) AS Cost

                 FROM @Resultset AS r
                      INNER JOIN @Exchangerate AS e ON r.ChemicalName = e.ChemicalName
                 GROUP BY
                     r.ChemicalName, 
                     e.Cost, 
                     r.PackageSizeId, 
                     r.UnitWeightVolumeUOMId, 
                     r.packagesizeweightuomcode) AS A;

    SET NOCOUNT OFF;
END;
GO


-----------------Manual input --Manual utility ---------
 IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetManualUtilityDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
                TCD.GetManualUtilityDetails;
	END;
GO

CREATE PROCEDURE TCD.GetManualUtilityDetails(
       @Ecolabaccountnumber NVARCHAR(25))
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Min_Recoredate DATETIME;

    WITH CTE
        AS (SELECT
                    UtilityId, 
                    MeterId, 
                    RecordedDate, 
                    Value, 
                    Usage, 
                    (SELECT
                             MAX(RecordedDate)
                         FROM TCD.ManualUtility AS MU1
                         WHERE IsDeleted <> 1
                           AND MU1.Meterid = MU2.Meterid) AS Max_RecoreDate, 
                    ROW_NUMBER() OVER(PARTITION BY MeterId ORDER BY UtilityId DESC) AS RowNumber
                FROM TCD.ManualUtility AS MU2
                WHERE IsDeleted <> 1)
			SELECT
				M.MeterId,
				M.Description,
				M.MeterTickUnit,
				M.UtilityType,
				M.GroupId,
				UtilityTypeName = (SELECT
                                           Name FROM TCD.UtilityMaster AS UM WHERE UM.ResourceId = M.UtilityType), 
                LocationName = CASE
                                   WHEN M.groupID IS NULL
                                    AND M.MachineCompartment IS NULL
                                    AND M.IsPlant = 1 THEN 'Plant'
                                   ELSE(SELECT
                                                GroupDescription FROM TCD.MachineGroup AS G WHERE G.Id = M.groupID)
                               END, 
				CTE.UtilityId,
				CTE.RecordedDate,
				CTE.Value,
				CTE.Usage,
				M.MaxValueLimit,
				M.MyServiceMeterGuid
            FROM TCD.Meter AS M
                 LEFT JOIN CTE ON M.MeterId = CTE.MeterId
				WHERE M.AllowManualentry = 'TRUE' 
					AND Is_deleted <> 1
              AND M.EcolabAccountNumber = @Ecolabaccountnumber
              AND (RecordedDate IS NOT NULL
               AND RecordedDate BETWEEN(SELECT
                                                DATEADD(DAY, -59, CTE.Max_RecoreDate)) AND CTE.Max_RecoreDate
                OR RecordedDate IS NULL);
    SET NOCOUNT OFF;
END;
GO

 IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[UpdateManualUtility]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
                TCD.UpdateManualUtility;
	END;
GO

CREATE PROCEDURE TCD.UpdateManualUtility(
       @Utilityid INT, 
       @Recordeddate DATETIME, 
       @Value DECIMAL(18, 0), 
       @Usage DECIMAL(18, 0), 
       @Ecolabaccountnumber NVARCHAR(25), 
       @Userid INT, 
       @Scope VARCHAR(100) OUTPUT)
AS
	BEGIN
    SET NOCOUNT ON;

    SET @Scope = ISNULL(@Scope, NULL);			--SQLEnlight SA0121

    IF EXISTS(SELECT
                      1 FROM TCD.ManualUtility WHERE UtilityId = @Utilityid
                                                 AND IsDeleted <> 1)
		BEGIN 
            UPDATE TCD.ManualUtility SET
                    RecordedDate = @Recordeddate, 
							Value = @Value,
							Usage = @Usage,
                    LastModifiedByUserId = @Userid
					WHERE 
                    UtilityId = @Utilityid
                AND EcolabAccountNumber = @Ecolabaccountnumber;
	   
            SET @Scope = '201';
        END;
		ELSE
		BEGIN
            SET @Scope = '501';
        END;
    SET NOCOUNT OFF;
END; 
 GO
	          
-----------------End Manual input --Manual utility ---------
-------------146350:Local Reports: Operations Summary Need to have separate columns for UOM for Energy to display in Btu and in Therm------------
BEGIN
DECLARE @Actual_Energy_Therm_Cwt INT;
DECLARE @Actual_Energy_Therm INT;
DECLARE @Standard_Energy_Therm_Cwt INT;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.DimensionalSubunits AS ds
    WHERE ds.Unit = 'Energy'
                        AND ds.Subunit = 'Therm')
    BEGIN
            INSERT INTO TCD.DimensionalSubunits(
			Unit,
                    Subunit)
	   VALUES
	   (
			N'Energy', -- Unit - nvarchar
			N'Therm' -- Subunit - nvarchar
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.DimensionalSubunits AS ds
    WHERE ds.Unit = 'EnergyConsumption'
                        AND ds.Subunit = 'Therm_Cwt')
    BEGIN
            INSERT INTO TCD.DimensionalSubunits(
			Unit,
                    Subunit)
	   VALUES
	   (
			N'EnergyConsumption', -- Unit - nvarchar
			N'Therm_Cwt' -- Subunit - nvarchar
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.DimensionalUnitsDefaults AS dud
    WHERE dud.UnitSystemId = 1
		AND dud.UsageKey = 'ActualEnergyUsage_Therm'
		AND dud.Unit = 'Energy'
                        AND dud.Subunit = 'Therm')
    BEGIN
            INSERT INTO TCD.DimensionalUnitsDefaults(
			UnitSystemId,
			UsageKey,
			Unit,
                    Subunit)
	   VALUES
	   (
			1, -- UnitSystemId - int
			N'ActualEnergyUsage_Therm', -- UsageKey - nvarchar
			N'Energy', -- Unit - nvarchar
			N'Therm' -- Subunit - nvarchar
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.DimensionalUnitsDefaults AS dud
    WHERE dud.UnitSystemId = 1
		AND dud.UsageKey = 'ActualEnergyUsage_Therm'
		AND dud.Unit = 'Energy'
                        AND dud.Subunit = 'Therm')
    BEGIN
            INSERT INTO TCD.DimensionalUnitsDefaults(
			UnitSystemId,
			UsageKey,
			Unit,
                    Subunit)
	   VALUES
	   (
			2, -- UnitSystemId - int
			N'ActualEnergyUsage_Therm', -- UsageKey - nvarchar
			N'Energy', -- Unit - nvarchar
			N'Therm' -- Subunit - nvarchar
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.DimensionalUnitsDefaults AS dud
    WHERE dud.UnitSystemId = 1
		AND dud.UsageKey = 'EnergyConsumptionUsage_Therm/Cwt'
		AND dud.Unit = 'EnergyConsumption'
                        AND dud.Subunit = 'Therm_Cwt')
    BEGIN
            INSERT INTO TCD.DimensionalUnitsDefaults(
			UnitSystemId,
			UsageKey,
			Unit,
                    Subunit)
	   VALUES
	   (
			1, -- UnitSystemId - int
			N'EnergyConsumptionUsage_Therm/Cwt', -- UsageKey - nvarchar
			N'EnergyConsumption', -- Unit - nvarchar
			N'Therm_Cwt' -- Subunit - nvarchar
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.DimensionalUnitsDefaults AS dud
    WHERE dud.UnitSystemId = 2
		AND dud.UsageKey = 'EnergyConsumptionUsage_Therm/Cwt'
		AND dud.Unit = 'EnergyConsumption'
                        AND dud.Subunit = 'Therm_Cwt')
    BEGIN
            INSERT INTO TCD.DimensionalUnitsDefaults(
			UnitSystemId,
			UsageKey,
			Unit,
                    Subunit)
	   VALUES
	   (
			2, -- UnitSystemId - int
			N'EnergyConsumptionUsage_Therm/Cwt', -- UsageKey - nvarchar
			N'EnergyConsumption', -- Unit - nvarchar
			N'Therm_Cwt' -- Subunit - nvarchar
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
                          * FROM TCD.ReportColumns AS rc WHERE rc.Name = 'Actual Energy Usage Therm')
    BEGIN
	   
            INSERT INTO TCD.ReportColumns(
			--Id - this column value is auto-generated
                    Name)
	   VALUES
	   (
			-- Id - int
			N'Actual Energy Usage Therm' -- Name - nvarchar
	   );
	   SET @Actual_Energy_Therm = SCOPE_IDENTITY();
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumns AS rc
                      WHERE rc.Name = 'Actual Energy Usage Therm/Cwt')
    BEGIN
	   
            INSERT INTO TCD.ReportColumns(
			--Id - this column value is auto-generated
                    Name)
	   VALUES
	   (
			-- Id - int
			N'Actual Energy Usage Therm/Cwt' -- Name - nvarchar
	   );
	   SET @Actual_Energy_Therm_Cwt = SCOPE_IDENTITY();
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportLocalizationColumnMapping AS rlcm
    WHERE rlcm.ReportColumnId = CASE 
							 WHEN @Actual_Energy_Therm IS NOT NULL THEN @Actual_Energy_Therm
                                                      ELSE(SELECT
                                                                   rc.Id FROM TCD.ReportColumns AS rc WHERE rc.Name = 'Actual Energy Usage Therm')
						  END
		AND rlcm.ReportId = 10
		AND rlcm.UsageKey = 'FIELD_ACTUALSPECIFICENERGYUSAGE'
                        AND rlcm.UomKey = 'ActualEnergyUsage_Therm')
    BEGIN
            INSERT INTO TCD.ReportLocalizationColumnMapping(
			--Id - this column value is auto-generated
			ReportColumnId,
			ReportId,
			UsageKey,
                    UomKey)
	   VALUES
	   (
			-- Id - int
			@Actual_Energy_Therm, -- ReportColumnId - int
			10, -- ReportId - int
			'FIELD_ACTUALSPECIFICENERGYUSAGE', -- UsageKey - varchar
			'ActualEnergyUsage_Therm' -- UomKey - varchar
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportLocalizationColumnMapping AS rlcm
    WHERE rlcm.ReportColumnId = CASE 
							 WHEN @Actual_Energy_Therm_Cwt IS NOT NULL THEN @Actual_Energy_Therm_Cwt
                                                      ELSE(SELECT
                                                                   rc.Id
                                                               FROM TCD.ReportColumns AS rc
                                                               WHERE rc.Name = 'Actual Energy Usage Therm/Cwt')
						  END
		AND rlcm.ReportId = 10
		AND rlcm.UsageKey = 'FIELD_ACTUALSPECIFICENERGYUSAGE'
                        AND rlcm.UomKey = 'EnergyConsumptionUsage_Therm/Cwt')
    BEGIN
            INSERT INTO TCD.ReportLocalizationColumnMapping(
			--Id - this column value is auto-generated
			ReportColumnId,
			ReportId,
			UsageKey,
                    UomKey)
	   VALUES
	   (
			-- Id - int
			@Actual_Energy_Therm_Cwt, -- ReportColumnId - int
			10, -- ReportId - int
			'FIELD_ACTUALSPECIFICENERGYUSAGE', -- UsageKey - varchar
			'EnergyConsumptionUsage_Therm/Cwt' -- UomKey - varchar
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsMapping AS rcm
    WHERE rcm.ColumnId = CASE 
					   WHEN @Actual_Energy_Therm IS NOT NULL THEN @Actual_Energy_Therm
                                               ELSE(SELECT
                                                            rc.Id FROM TCD.ReportColumns AS rc WHERE rc.Name = 'Actual Energy Usage Therm')
					END
		AND rcm.ReportId = 10
                        AND rcm.ViewById = 1)
    BEGIN
            INSERT INTO TCD.ReportColumnsMapping(
	       --Id - this column value is auto-generated
	       ColumnId,
	       ReportId,
	       IsChartDisplay,
	       DisplayOrder,
	       IsSortable,
	       ViewById,
	       SwitchModeId,
	       IsVisible,
                    Precision)
	   VALUES
	   (
	       -- Id - int
	       @Actual_Energy_Therm, -- ColumnId - int
	       10, -- ReportId - int
	       0, -- IsChartDisplay - bit
	       18, -- DisplayOrder - int
	       1, -- IsSortable - bit
	       1, -- ViewById - int
	       0, -- SwitchModeId - int
	       0, -- IsVisible - bit
	       2 -- Precision - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsMapping AS rcm
    WHERE rcm.ColumnId = CASE 
					   WHEN @Actual_Energy_Therm IS NOT NULL THEN @Actual_Energy_Therm
                                               ELSE(SELECT
                                                            rc.Id FROM TCD.ReportColumns AS rc WHERE rc.Name = 'Actual Energy Usage Therm')
					END
		AND rcm.ReportId = 10
                        AND rcm.ViewById = 2)
    BEGIN
            INSERT INTO TCD.ReportColumnsMapping(
	       --Id - this column value is auto-generated
	       ColumnId,
	       ReportId,
	       IsChartDisplay,
	       DisplayOrder,
	       IsSortable,
	       ViewById,
	       SwitchModeId,
	       IsVisible,
                    Precision)
	   VALUES
	   (
	       -- Id - int
	       @Actual_Energy_Therm, -- ColumnId - int
	       10, -- ReportId - int
	       0, -- IsChartDisplay - bit
	       18, -- DisplayOrder - int
	       1, -- IsSortable - bit
	       2, -- ViewById - int
	       0, -- SwitchModeId - int
	       0, -- IsVisible - bit
	       2 -- Precision - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsMapping AS rcm
    WHERE rcm.ColumnId = CASE 
					   WHEN @Actual_Energy_Therm IS NOT NULL THEN @Actual_Energy_Therm
                                               ELSE(SELECT
                                                            rc.Id FROM TCD.ReportColumns AS rc WHERE rc.Name = 'Actual Energy Usage Therm')
					END
		AND rcm.ReportId = 10
                        AND rcm.ViewById = 3)
    BEGIN
            INSERT INTO TCD.ReportColumnsMapping(
	       --Id - this column value is auto-generated
	       ColumnId,
	       ReportId,
	       IsChartDisplay,
	       DisplayOrder,
	       IsSortable,
	       ViewById,
	       SwitchModeId,
	       IsVisible,
                    Precision)
	   VALUES
	   (
	       -- Id - int
	       @Actual_Energy_Therm, -- ColumnId - int
	       10, -- ReportId - int
	       0, -- IsChartDisplay - bit
	       18, -- DisplayOrder - int
	       1, -- IsSortable - bit
	       3, -- ViewById - int
	       0, -- SwitchModeId - int
	       0, -- IsVisible - bit
	       2 -- Precision - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsMapping AS rcm
    WHERE rcm.ColumnId = CASE 
					   WHEN @Actual_Energy_Therm IS NOT NULL THEN @Actual_Energy_Therm
                                               ELSE(SELECT
                                                            rc.Id FROM TCD.ReportColumns AS rc WHERE rc.Name = 'Actual Energy Usage Therm')
					END
		AND rcm.ReportId = 10
                        AND rcm.ViewById = 4)
    BEGIN
            INSERT INTO TCD.ReportColumnsMapping(
	       --Id - this column value is auto-generated
	       ColumnId,
	       ReportId,
	       IsChartDisplay,
	       DisplayOrder,
	       IsSortable,
	       ViewById,
	       SwitchModeId,
	       IsVisible,
                    Precision)
	   VALUES
	   (
	       -- Id - int
	       @Actual_Energy_Therm, -- ColumnId - int
	       10, -- ReportId - int
	       0, -- IsChartDisplay - bit
	       18, -- DisplayOrder - int
	       1, -- IsSortable - bit
	       4, -- ViewById - int
	       0, -- SwitchModeId - int
	       0, -- IsVisible - bit
	       2 -- Precision - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsMapping AS rcm
    WHERE rcm.ColumnId = CASE 
					   WHEN @Actual_Energy_Therm IS NOT NULL THEN @Actual_Energy_Therm
                                               ELSE(SELECT
                                                            rc.Id FROM TCD.ReportColumns AS rc WHERE rc.Name = 'Actual Energy Usage Therm')
					END
		AND rcm.ReportId = 10
                        AND rcm.ViewById = 5)
    BEGIN
            INSERT INTO TCD.ReportColumnsMapping(
	       --Id - this column value is auto-generated
	       ColumnId,
	       ReportId,
	       IsChartDisplay,
	       DisplayOrder,
	       IsSortable,
	       ViewById,
	       SwitchModeId,
	       IsVisible,
                    Precision)
	   VALUES
	   (
	       -- Id - int
	       @Actual_Energy_Therm, -- ColumnId - int
	       10, -- ReportId - int
	       0, -- IsChartDisplay - bit
	       18, -- DisplayOrder - int
	       1, -- IsSortable - bit
	       5, -- ViewById - int
	       0, -- SwitchModeId - int
	       0, -- IsVisible - bit
	       2 -- Precision - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsMapping AS rcm
    WHERE rcm.ColumnId = CASE 
					   WHEN @Actual_Energy_Therm IS NOT NULL THEN @Actual_Energy_Therm
                                               ELSE(SELECT
                                                            rc.Id FROM TCD.ReportColumns AS rc WHERE rc.Name = 'Actual Energy Usage Therm')
					END
		AND rcm.ReportId = 10
                        AND rcm.ViewById = 8)
    BEGIN
            INSERT INTO TCD.ReportColumnsMapping(
	       --Id - this column value is auto-generated
	       ColumnId,
	       ReportId,
	       IsChartDisplay,
	       DisplayOrder,
	       IsSortable,
	       ViewById,
	       SwitchModeId,
	       IsVisible,
                    Precision)
	   VALUES
	   (
	       -- Id - int
	       @Actual_Energy_Therm, -- ColumnId - int
	       10, -- ReportId - int
	       0, -- IsChartDisplay - bit
	       18, -- DisplayOrder - int
	       1, -- IsSortable - bit
	       8, -- ViewById - int
	       0, -- SwitchModeId - int
	       0, -- IsVisible - bit
	       2 -- Precision - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsMapping AS rcm
    WHERE rcm.ColumnId = CASE 
					   WHEN @Actual_Energy_Therm_Cwt IS NOT NULL THEN @Actual_Energy_Therm_Cwt
                                               ELSE(SELECT
                                                            rc.Id
                                                        FROM TCD.ReportColumns AS rc
                                                        WHERE rc.Name = 'Actual Energy Usage Therm/Cwt')
					END
		AND rcm.ReportId = 10
                        AND rcm.ViewById = 1)
    BEGIN
            INSERT INTO TCD.ReportColumnsMapping(
	       --Id - this column value is auto-generated
	       ColumnId,
	       ReportId,
	       IsChartDisplay,
	       DisplayOrder,
	       IsSortable,
	       ViewById,
	       SwitchModeId,
	       IsVisible,
                    Precision)
	   VALUES
	   (
	       -- Id - int
	       @Actual_Energy_Therm_Cwt, -- ColumnId - int
	       10, -- ReportId - int
	       0, -- IsChartDisplay - bit
	       19, -- DisplayOrder - int
	       1, -- IsSortable - bit
	       1, -- ViewById - int
	       0, -- SwitchModeId - int
	       0, -- IsVisible - bit
	       2 -- Precision - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsMapping AS rcm
    WHERE rcm.ColumnId = CASE 
					   WHEN @Actual_Energy_Therm_Cwt IS NOT NULL THEN @Actual_Energy_Therm_Cwt
                                               ELSE(SELECT
                                                            rc.Id
                                                        FROM TCD.ReportColumns AS rc
                                                        WHERE rc.Name = 'Actual Energy Usage Therm/Cwt')
					END
		AND rcm.ReportId = 10
                        AND rcm.ViewById = 2)
    BEGIN
            INSERT INTO TCD.ReportColumnsMapping(
	       --Id - this column value is auto-generated
	       ColumnId,
	       ReportId,
	       IsChartDisplay,
	       DisplayOrder,
	       IsSortable,
	       ViewById,
	       SwitchModeId,
	       IsVisible,
                    Precision)
	   VALUES
	   (
	       -- Id - int
	       @Actual_Energy_Therm_Cwt, -- ColumnId - int
	       10, -- ReportId - int
	       0, -- IsChartDisplay - bit
	       19, -- DisplayOrder - int
	       1, -- IsSortable - bit
	       2, -- ViewById - int
	       0, -- SwitchModeId - int
	       0, -- IsVisible - bit
	       2 -- Precision - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsMapping AS rcm
    WHERE rcm.ColumnId = CASE 
					   WHEN @Actual_Energy_Therm_Cwt IS NOT NULL THEN @Actual_Energy_Therm_Cwt
                                               ELSE(SELECT
                                                            rc.Id
                                                        FROM TCD.ReportColumns AS rc
                                                        WHERE rc.Name = 'Actual Energy Usage Therm/Cwt')
					END
		AND rcm.ReportId = 10
                        AND rcm.ViewById = 3)
    BEGIN
            INSERT INTO TCD.ReportColumnsMapping(
	       --Id - this column value is auto-generated
	       ColumnId,
	       ReportId,
	       IsChartDisplay,
	       DisplayOrder,
	       IsSortable,
	       ViewById,
	       SwitchModeId,
	       IsVisible,
                    Precision)
	   VALUES
	   (
	       -- Id - int
	       @Actual_Energy_Therm_Cwt, -- ColumnId - int
	       10, -- ReportId - int
	       0, -- IsChartDisplay - bit
	       19, -- DisplayOrder - int
	       1, -- IsSortable - bit
	       3, -- ViewById - int
	       0, -- SwitchModeId - int
	       0, -- IsVisible - bit
	       2 -- Precision - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsMapping AS rcm
    WHERE rcm.ColumnId = CASE 
					   WHEN @Actual_Energy_Therm_Cwt IS NOT NULL THEN @Actual_Energy_Therm_Cwt
                                               ELSE(SELECT
                                                            rc.Id
                                                        FROM TCD.ReportColumns AS rc
                                                        WHERE rc.Name = 'Actual Energy Usage Therm/Cwt')
					END
		AND rcm.ReportId = 10
                        AND rcm.ViewById = 4)
    BEGIN
            INSERT INTO TCD.ReportColumnsMapping(
	       --Id - this column value is auto-generated
	       ColumnId,
	       ReportId,
	       IsChartDisplay,
	       DisplayOrder,
	       IsSortable,
	       ViewById,
	       SwitchModeId,
	       IsVisible,
                    Precision)
	   VALUES
	   (
	       -- Id - int
	       @Actual_Energy_Therm_Cwt, -- ColumnId - int
	       10, -- ReportId - int
	       0, -- IsChartDisplay - bit
	       19, -- DisplayOrder - int
	       1, -- IsSortable - bit
	       4, -- ViewById - int
	       0, -- SwitchModeId - int
	       0, -- IsVisible - bit
	       2 -- Precision - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsMapping AS rcm
    WHERE rcm.ColumnId = CASE 
					   WHEN @Actual_Energy_Therm_Cwt IS NOT NULL THEN @Actual_Energy_Therm_Cwt
                                               ELSE(SELECT
                                                            rc.Id
                                                        FROM TCD.ReportColumns AS rc
                                                        WHERE rc.Name = 'Actual Energy Usage Therm/Cwt')
					END
		AND rcm.ReportId = 10
                        AND rcm.ViewById = 5)
    BEGIN
            INSERT INTO TCD.ReportColumnsMapping(
	       --Id - this column value is auto-generated
	       ColumnId,
	       ReportId,
	       IsChartDisplay,
	       DisplayOrder,
	       IsSortable,
	       ViewById,
	       SwitchModeId,
	       IsVisible,
                    Precision)
	   VALUES
	   (
	       -- Id - int
	       @Actual_Energy_Therm_Cwt, -- ColumnId - int
	       10, -- ReportId - int
	       0, -- IsChartDisplay - bit
	       19, -- DisplayOrder - int
	       1, -- IsSortable - bit
	       5, -- ViewById - int
	       0, -- SwitchModeId - int
	       0, -- IsVisible - bit
	       2 -- Precision - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsMapping AS rcm
    WHERE rcm.ColumnId = CASE 
					   WHEN @Actual_Energy_Therm_Cwt IS NOT NULL THEN @Actual_Energy_Therm_Cwt
                                               ELSE(SELECT
                                                            rc.Id
                                                        FROM TCD.ReportColumns AS rc
                                                        WHERE rc.Name = 'Actual Energy Usage Therm/Cwt')
					END
		AND rcm.ReportId = 10
                        AND rcm.ViewById = 8)
    BEGIN
            INSERT INTO TCD.ReportColumnsMapping(
	       --Id - this column value is auto-generated
	       ColumnId,
	       ReportId,
	       IsChartDisplay,
	       DisplayOrder,
	       IsSortable,
	       ViewById,
	       SwitchModeId,
	       IsVisible,
                    Precision)
	   VALUES
	   (
	       -- Id - int
	       @Actual_Energy_Therm_Cwt, -- ColumnId - int
	       10, -- ReportId - int
	       0, -- IsChartDisplay - bit
	       19, -- DisplayOrder - int
	       1, -- IsSortable - bit
	       8, -- ViewById - int
	       0, -- SwitchModeId - int
	       0, -- IsVisible - bit
	       2 -- Precision - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsRoleMapping AS rcrm
    WHERE rcrm.ReportColumnId = CASE 
					   WHEN @Actual_Energy_Therm IS NOT NULL THEN @Actual_Energy_Therm
                                                      ELSE(SELECT
                                                                   rc.Id FROM TCD.ReportColumns AS rc WHERE rc.Name = 'Actual Energy Usage Therm')
					END
		AND rcrm.ReportId = 10
                        AND rcrm.RoleId = 9)
    BEGIN
            INSERT INTO tcd.ReportColumnsRoleMapping(
	       --Id - this column value is auto-generated
	       ReportColumnId,
	       SettingValue,
	       RoleId,
                    ReportId)
	   VALUES
	   (
	       -- Id - int
	       @Actual_Energy_Therm, -- ReportColumnId - int
	       1, -- SettingValue - bit
	       9, -- RoleId - int
	       10 -- ReportId - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsRoleMapping AS rcrm
    WHERE rcrm.ReportColumnId = CASE 
					   WHEN @Actual_Energy_Therm IS NOT NULL THEN @Actual_Energy_Therm
                                                      ELSE(SELECT
                                                                   rc.Id FROM TCD.ReportColumns AS rc WHERE rc.Name = 'Actual Energy Usage Therm')
					END
		AND rcrm.ReportId = 10
                        AND rcrm.RoleId = 3)
    BEGIN
            INSERT INTO tcd.ReportColumnsRoleMapping(
	       --Id - this column value is auto-generated
	       ReportColumnId,
	       SettingValue,
	       RoleId,
                    ReportId)
	   VALUES
	   (
	       -- Id - int
	       @Actual_Energy_Therm, -- ReportColumnId - int
	       1, -- SettingValue - bit
	       3, -- RoleId - int
	       10 -- ReportId - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsRoleMapping AS rcrm
    WHERE rcrm.ReportColumnId = CASE 
					   WHEN @Actual_Energy_Therm IS NOT NULL THEN @Actual_Energy_Therm
                                                      ELSE(SELECT
                                                                   rc.Id FROM TCD.ReportColumns AS rc WHERE rc.Name = 'Actual Energy Usage Therm')
					END
		AND rcrm.ReportId = 10
                        AND rcrm.RoleId = 4)
    BEGIN
            INSERT INTO tcd.ReportColumnsRoleMapping(
	       --Id - this column value is auto-generated
	       ReportColumnId,
	       SettingValue,
	       RoleId,
                    ReportId)
	   VALUES
	   (
	       -- Id - int
	       @Actual_Energy_Therm, -- ReportColumnId - int
	       1, -- SettingValue - bit
	       4, -- RoleId - int
	       10 -- ReportId - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsRoleMapping AS rcrm
    WHERE rcrm.ReportColumnId = CASE 
					   WHEN @Actual_Energy_Therm IS NOT NULL THEN @Actual_Energy_Therm
                                                      ELSE(SELECT
                                                                   rc.Id FROM TCD.ReportColumns AS rc WHERE rc.Name = 'Actual Energy Usage Therm')
					END
		AND rcrm.ReportId = 10
                        AND rcrm.RoleId = 5)
    BEGIN
            INSERT INTO tcd.ReportColumnsRoleMapping(
	       --Id - this column value is auto-generated
	       ReportColumnId,
	       SettingValue,
	       RoleId,
                    ReportId)
	   VALUES
	   (
	       -- Id - int
	       @Actual_Energy_Therm, -- ReportColumnId - int
	       1, -- SettingValue - bit
	       5, -- RoleId - int
	       10 -- ReportId - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsRoleMapping AS rcrm
    WHERE rcrm.ReportColumnId = CASE 
					   WHEN @Actual_Energy_Therm IS NOT NULL THEN @Actual_Energy_Therm
                                                      ELSE(SELECT
                                                                   rc.Id FROM TCD.ReportColumns AS rc WHERE rc.Name = 'Actual Energy Usage Therm')
					END
		AND rcrm.ReportId = 10
                        AND rcrm.RoleId = 6)
    BEGIN
            INSERT INTO tcd.ReportColumnsRoleMapping(
	       --Id - this column value is auto-generated
	       ReportColumnId,
	       SettingValue,
	       RoleId,
                    ReportId)
	   VALUES
	   (
	       -- Id - int
	       @Actual_Energy_Therm, -- ReportColumnId - int
	       1, -- SettingValue - bit
	       6, -- RoleId - int
	       10 -- ReportId - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsRoleMapping AS rcrm
    WHERE rcrm.ReportColumnId = CASE 
					   WHEN @Actual_Energy_Therm IS NOT NULL THEN @Actual_Energy_Therm
                                                      ELSE(SELECT
                                                                   rc.Id FROM TCD.ReportColumns AS rc WHERE rc.Name = 'Actual Energy Usage Therm')
					END
		AND rcrm.ReportId = 10
                        AND rcrm.RoleId = 7)
    BEGIN
            INSERT INTO tcd.ReportColumnsRoleMapping(
	       --Id - this column value is auto-generated
	       ReportColumnId,
	       SettingValue,
	       RoleId,
                    ReportId)
	   VALUES
	   (
	       -- Id - int
	       @Actual_Energy_Therm, -- ReportColumnId - int
	       1, -- SettingValue - bit
	       7, -- RoleId - int
	       10 -- ReportId - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsRoleMapping AS rcrm
    WHERE rcrm.ReportColumnId = CASE 
					   WHEN @Actual_Energy_Therm IS NOT NULL THEN @Actual_Energy_Therm
                                                      ELSE(SELECT
                                                                   rc.Id FROM TCD.ReportColumns AS rc WHERE rc.Name = 'Actual Energy Usage Therm')
					END
		AND rcrm.ReportId = 10
                        AND rcrm.RoleId = 8)
    BEGIN
            INSERT INTO tcd.ReportColumnsRoleMapping(
	       --Id - this column value is auto-generated
	       ReportColumnId,
	       SettingValue,
	       RoleId,
                    ReportId)
	   VALUES
	   (
	       -- Id - int
	       @Actual_Energy_Therm, -- ReportColumnId - int
	       1, -- SettingValue - bit
	       8, -- RoleId - int
	       10 -- ReportId - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsRoleMapping AS rcrm
    WHERE rcrm.ReportColumnId = CASE 
					   WHEN @Actual_Energy_Therm_Cwt IS NOT NULL THEN @Actual_Energy_Therm_Cwt
                                                      ELSE(SELECT
                                                                   rc.Id
                                                               FROM TCD.ReportColumns AS rc
                                                               WHERE rc.Name = 'Actual Energy Usage Therm/Cwt')
					END
		AND rcrm.ReportId = 10
                        AND rcrm.RoleId = 9)
    BEGIN
            INSERT INTO tcd.ReportColumnsRoleMapping(
	       --Id - this column value is auto-generated
	       ReportColumnId,
	       SettingValue,
	       RoleId,
                    ReportId)
	   VALUES
	   (
	       -- Id - int
	       @Actual_Energy_Therm_Cwt, -- ReportColumnId - int
	       1, -- SettingValue - bit
	       9, -- RoleId - int
	       10 -- ReportId - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsRoleMapping AS rcrm
    WHERE rcrm.ReportColumnId = CASE 
					   WHEN @Actual_Energy_Therm_Cwt IS NOT NULL THEN @Actual_Energy_Therm_Cwt
                                                      ELSE(SELECT
                                                                   rc.Id
                                                               FROM TCD.ReportColumns AS rc
                                                               WHERE rc.Name = 'Actual Energy Usage Therm/Cwt')
					END
		AND rcrm.ReportId = 10
                        AND rcrm.RoleId = 3)
    BEGIN
            INSERT INTO tcd.ReportColumnsRoleMapping(
	       --Id - this column value is auto-generated
	       ReportColumnId,
	       SettingValue,
	       RoleId,
                    ReportId)
	   VALUES
	   (
	       -- Id - int
	       @Actual_Energy_Therm_Cwt, -- ReportColumnId - int
	       1, -- SettingValue - bit
	       3, -- RoleId - int
	       10 -- ReportId - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsRoleMapping AS rcrm
    WHERE rcrm.ReportColumnId = CASE 
					   WHEN @Actual_Energy_Therm_Cwt IS NOT NULL THEN @Actual_Energy_Therm_Cwt
                                                      ELSE(SELECT
                                                                   rc.Id
                                                               FROM TCD.ReportColumns AS rc
                                                               WHERE rc.Name = 'Actual Energy Usage Therm/Cwt')
					END
		AND rcrm.ReportId = 10
                        AND rcrm.RoleId = 4)
    BEGIN
            INSERT INTO tcd.ReportColumnsRoleMapping(
	       --Id - this column value is auto-generated
	       ReportColumnId,
	       SettingValue,
	       RoleId,
                    ReportId)
	   VALUES
	   (
	       -- Id - int
	       @Actual_Energy_Therm_Cwt, -- ReportColumnId - int
	       1, -- SettingValue - bit
	       4, -- RoleId - int
	       10 -- ReportId - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsRoleMapping AS rcrm
    WHERE rcrm.ReportColumnId = CASE 
					   WHEN @Actual_Energy_Therm_Cwt IS NOT NULL THEN @Actual_Energy_Therm_Cwt
                                                      ELSE(SELECT
                                                                   rc.Id
                                                               FROM TCD.ReportColumns AS rc
                                                               WHERE rc.Name = 'Actual Energy Usage Therm/Cwt')
					END
		AND rcrm.ReportId = 10
                        AND rcrm.RoleId = 5)
    BEGIN
            INSERT INTO tcd.ReportColumnsRoleMapping(
	       --Id - this column value is auto-generated
	       ReportColumnId,
	       SettingValue,
	       RoleId,
                    ReportId)
	   VALUES
	   (
	       -- Id - int
	       @Actual_Energy_Therm_Cwt, -- ReportColumnId - int
	       1, -- SettingValue - bit
	       5, -- RoleId - int
	       10 -- ReportId - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsRoleMapping AS rcrm
    WHERE rcrm.ReportColumnId = CASE 
					   WHEN @Actual_Energy_Therm_Cwt IS NOT NULL THEN @Actual_Energy_Therm_Cwt
                                                      ELSE(SELECT
                                                                   rc.Id
                                                               FROM TCD.ReportColumns AS rc
                                                               WHERE rc.Name = 'Actual Energy Usage Therm/Cwt')
					END
		AND rcrm.ReportId = 10
                        AND rcrm.RoleId = 6)
    BEGIN
            INSERT INTO tcd.ReportColumnsRoleMapping(
	       --Id - this column value is auto-generated
	       ReportColumnId,
	       SettingValue,
	       RoleId,
                    ReportId)
	   VALUES
	   (
	       -- Id - int
	       @Actual_Energy_Therm_Cwt, -- ReportColumnId - int
	       1, -- SettingValue - bit
	       6, -- RoleId - int
	       10 -- ReportId - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsRoleMapping AS rcrm
    WHERE rcrm.ReportColumnId = CASE 
					   WHEN @Actual_Energy_Therm_Cwt IS NOT NULL THEN @Actual_Energy_Therm_Cwt
                                                      ELSE(SELECT
                                                                   rc.Id
                                                               FROM TCD.ReportColumns AS rc
                                                               WHERE rc.Name = 'Actual Energy Usage Therm/Cwt')
					END
		AND rcrm.ReportId = 10
                        AND rcrm.RoleId = 7)
    BEGIN
            INSERT INTO tcd.ReportColumnsRoleMapping(
	       --Id - this column value is auto-generated
	       ReportColumnId,
	       SettingValue,
	       RoleId,
                    ReportId)
	   VALUES
	   (
	       -- Id - int
	       @Actual_Energy_Therm_Cwt, -- ReportColumnId - int
	       1, -- SettingValue - bit
	       7, -- RoleId - int
	       10 -- ReportId - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsRoleMapping AS rcrm
    WHERE rcrm.ReportColumnId = CASE 
					   WHEN @Actual_Energy_Therm_Cwt IS NOT NULL THEN @Actual_Energy_Therm_Cwt
                                                      ELSE(SELECT
                                                                   rc.Id
                                                               FROM TCD.ReportColumns AS rc
                                                               WHERE rc.Name = 'Actual Energy Usage Therm/Cwt')
					END
		AND rcrm.ReportId = 10
                        AND rcrm.RoleId = 8)
    BEGIN
            INSERT INTO tcd.ReportColumnsRoleMapping(
	       --Id - this column value is auto-generated
	       ReportColumnId,
	       SettingValue,
	       RoleId,
                    ReportId)
	   VALUES
	   (
	       -- Id - int
	       @Actual_Energy_Therm_Cwt, -- ReportColumnId - int
	       1, -- SettingValue - bit
	       8, -- RoleId - int
	       10 -- ReportId - int
	   );
    END;



----------------------------------
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumns AS rc
                      WHERE rc.Name = 'Standard Energy Usage Therm/Cwt')
    BEGIN
	  
            INSERT INTO TCD.ReportColumns(
			--Id - this column value is auto-generated
                    Name)
	   VALUES
	   (
			-- Id - int
			N'Standard Energy Usage Therm/Cwt' -- Name - nvarchar
	   );
	   SET @Standard_Energy_Therm_Cwt = SCOPE_IDENTITY();
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportLocalizationColumnMapping AS rlcm
    WHERE rlcm.ReportColumnId = CASE 
							 WHEN @Standard_Energy_Therm_Cwt IS NOT NULL THEN @Standard_Energy_Therm_Cwt
                                                      ELSE(SELECT
                                                                   rc.Id
                                                               FROM TCD.ReportColumns AS rc
                                                               WHERE rc.Name = 'Standard Energy Usage Therm/Cwt')
						  END
		AND rlcm.ReportId = 10
		AND rlcm.UsageKey = 'FIELD_TARGETSPECIFICENERGYUSAGE'
                        AND rlcm.UomKey = 'EnergyConsumptionUsage_Therm/Cwt')
    BEGIN
            INSERT INTO TCD.ReportLocalizationColumnMapping(
			--Id - this column value is auto-generated
			ReportColumnId,
			ReportId,
			UsageKey,
                    UomKey)
	   VALUES
	   (
			-- Id - int
			@Standard_Energy_Therm_Cwt, -- ReportColumnId - int
			10, -- ReportId - int
			'FIELD_TARGETSPECIFICENERGYUSAGE', -- UsageKey - varchar
			'EnergyConsumptionUsage_Therm/Cwt' -- UomKey - varchar
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsMapping AS rcm
    WHERE rcm.ColumnId = CASE 
					   WHEN @Standard_Energy_Therm_Cwt IS NOT NULL THEN @Standard_Energy_Therm_Cwt
                                               ELSE(SELECT
                                                            rc.Id
                                                        FROM TCD.ReportColumns AS rc
                                                        WHERE rc.Name = 'Standard Energy Usage Therm/Cwt')
					END
		AND rcm.ReportId = 10
                        AND rcm.ViewById = 1)
    BEGIN
            INSERT INTO TCD.ReportColumnsMapping(
	       --Id - this column value is auto-generated
	       ColumnId,
	       ReportId,
	       IsChartDisplay,
	       DisplayOrder,
	       IsSortable,
	       ViewById,
	       SwitchModeId,
	       IsVisible,
                    Precision)
	   VALUES
	   (
	       -- Id - int
	       @Standard_Energy_Therm_Cwt, -- ColumnId - int
	       10, -- ReportId - int
	       0, -- IsChartDisplay - bit
	       20, -- DisplayOrder - int
	       1, -- IsSortable - bit
	       1, -- ViewById - int
	       0, -- SwitchModeId - int
	       0, -- IsVisible - bit
	       2 -- Precision - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsMapping AS rcm
    WHERE rcm.ColumnId = CASE 
					   WHEN @Standard_Energy_Therm_Cwt IS NOT NULL THEN @Standard_Energy_Therm_Cwt
                                               ELSE(SELECT
                                                            rc.Id
                                                        FROM TCD.ReportColumns AS rc
                                                        WHERE rc.Name = 'Standard Energy Usage Therm/Cwt')
					END
		AND rcm.ReportId = 10
                        AND rcm.ViewById = 2)
    BEGIN
            INSERT INTO TCD.ReportColumnsMapping(
	       --Id - this column value is auto-generated
	       ColumnId,
	       ReportId,
	       IsChartDisplay,
	       DisplayOrder,
	       IsSortable,
	       ViewById,
	       SwitchModeId,
	       IsVisible,
                    Precision)
	   VALUES
	   (
	       -- Id - int
	       @Standard_Energy_Therm_Cwt, -- ColumnId - int
	       10, -- ReportId - int
	       0, -- IsChartDisplay - bit
	       20, -- DisplayOrder - int
	       1, -- IsSortable - bit
	       2, -- ViewById - int
	       0, -- SwitchModeId - int
	       0, -- IsVisible - bit
	       2 -- Precision - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsMapping AS rcm
    WHERE rcm.ColumnId = CASE 
					   WHEN @Standard_Energy_Therm_Cwt IS NOT NULL THEN @Standard_Energy_Therm_Cwt
                                               ELSE(SELECT
                                                            rc.Id
                                                        FROM TCD.ReportColumns AS rc
                                                        WHERE rc.Name = 'Standard Energy Usage Therm/Cwt')
					END
		AND rcm.ReportId = 10
                        AND rcm.ViewById = 3)
    BEGIN
            INSERT INTO TCD.ReportColumnsMapping(
	       --Id - this column value is auto-generated
	       ColumnId,
	       ReportId,
	       IsChartDisplay,
	       DisplayOrder,
	       IsSortable,
	       ViewById,
	       SwitchModeId,
	       IsVisible,
                    Precision)
	   VALUES
	   (
	       -- Id - int
	       @Standard_Energy_Therm_Cwt, -- ColumnId - int
	       10, -- ReportId - int
	       0, -- IsChartDisplay - bit
	       20, -- DisplayOrder - int
	       1, -- IsSortable - bit
	       3, -- ViewById - int
	       0, -- SwitchModeId - int
	       0, -- IsVisible - bit
	       2 -- Precision - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsMapping AS rcm
    WHERE rcm.ColumnId = CASE 
					   WHEN @Standard_Energy_Therm_Cwt IS NOT NULL THEN @Standard_Energy_Therm_Cwt
                                               ELSE(SELECT
                                                            rc.Id
                                                        FROM TCD.ReportColumns AS rc
                                                        WHERE rc.Name = 'Standard Energy Usage Therm/Cwt')
					END
		AND rcm.ReportId = 10
                        AND rcm.ViewById = 4)
    BEGIN
            INSERT INTO TCD.ReportColumnsMapping(
	       --Id - this column value is auto-generated
	       ColumnId,
	       ReportId,
	       IsChartDisplay,
	       DisplayOrder,
	       IsSortable,
	       ViewById,
	       SwitchModeId,
	       IsVisible,
                    Precision)
	   VALUES
	   (
	       -- Id - int
	       @Standard_Energy_Therm_Cwt, -- ColumnId - int
	       10, -- ReportId - int
	       0, -- IsChartDisplay - bit
	       20, -- DisplayOrder - int
	       1, -- IsSortable - bit
	       4, -- ViewById - int
	       0, -- SwitchModeId - int
	       0, -- IsVisible - bit
	       2 -- Precision - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsMapping AS rcm
    WHERE rcm.ColumnId = CASE 
					   WHEN @Standard_Energy_Therm_Cwt IS NOT NULL THEN @Standard_Energy_Therm_Cwt
                                               ELSE(SELECT
                                                            rc.Id
                                                        FROM TCD.ReportColumns AS rc
                                                        WHERE rc.Name = 'Standard Energy Usage Therm/Cwt')
					END
		AND rcm.ReportId = 10
                        AND rcm.ViewById = 5)
    BEGIN
            INSERT INTO TCD.ReportColumnsMapping(
	       --Id - this column value is auto-generated
	       ColumnId,
	       ReportId,
	       IsChartDisplay,
	       DisplayOrder,
	       IsSortable,
	       ViewById,
	       SwitchModeId,
	       IsVisible,
                    Precision)
	   VALUES
	   (
	       -- Id - int
	       @Standard_Energy_Therm_Cwt, -- ColumnId - int
	       10, -- ReportId - int
	       0, -- IsChartDisplay - bit
	       20, -- DisplayOrder - int
	       1, -- IsSortable - bit
	       5, -- ViewById - int
	       0, -- SwitchModeId - int
	       0, -- IsVisible - bit
	       2 -- Precision - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsMapping AS rcm
    WHERE rcm.ColumnId = CASE 
					   WHEN @Standard_Energy_Therm_Cwt IS NOT NULL THEN @Standard_Energy_Therm_Cwt
                                               ELSE(SELECT
                                                            rc.Id
                                                        FROM TCD.ReportColumns AS rc
                                                        WHERE rc.Name = 'Standard Energy Usage Therm/Cwt')
					END
		AND rcm.ReportId = 10
                        AND rcm.ViewById = 8)
    BEGIN
            INSERT INTO TCD.ReportColumnsMapping(
	       --Id - this column value is auto-generated
	       ColumnId,
	       ReportId,
	       IsChartDisplay,
	       DisplayOrder,
	       IsSortable,
	       ViewById,
	       SwitchModeId,
	       IsVisible,
                    Precision)
	   VALUES
	   (
	       -- Id - int
	       @Standard_Energy_Therm_Cwt, -- ColumnId - int
	       10, -- ReportId - int
	       0, -- IsChartDisplay - bit
	       20, -- DisplayOrder - int
	       1, -- IsSortable - bit
	       8, -- ViewById - int
	       0, -- SwitchModeId - int
	       0, -- IsVisible - bit
	       2 -- Precision - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsRoleMapping AS rcrm
    WHERE rcrm.ReportColumnId = CASE 
					   WHEN @Standard_Energy_Therm_Cwt IS NOT NULL THEN @Standard_Energy_Therm_Cwt
                                                      ELSE(SELECT
                                                                   rc.Id
                                                               FROM TCD.ReportColumns AS rc
                                                               WHERE rc.Name = 'Standard Energy Usage Therm/Cwt')
					END
		AND rcrm.ReportId = 10
                        AND rcrm.RoleId = 9)
    BEGIN
            INSERT INTO tcd.ReportColumnsRoleMapping(
	       --Id - this column value is auto-generated
	       ReportColumnId,
	       SettingValue,
	       RoleId,
                    ReportId)
	   VALUES
	   (
	       -- Id - int
	       @Standard_Energy_Therm_Cwt, -- ReportColumnId - int
	       1, -- SettingValue - bit
	       9, -- RoleId - int
	       10 -- ReportId - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsRoleMapping AS rcrm
    WHERE rcrm.ReportColumnId = CASE 
					   WHEN @Standard_Energy_Therm_Cwt IS NOT NULL THEN @Standard_Energy_Therm_Cwt
                                                      ELSE(SELECT
                                                                   rc.Id
                                                               FROM TCD.ReportColumns AS rc
                                                               WHERE rc.Name = 'Standard Energy Usage Therm/Cwt')
					END
		AND rcrm.ReportId = 10
                        AND rcrm.RoleId = 3)
    BEGIN
            INSERT INTO tcd.ReportColumnsRoleMapping(
	       --Id - this column value is auto-generated
	       ReportColumnId,
	       SettingValue,
	       RoleId,
                    ReportId)
	   VALUES
	   (
	       -- Id - int
	       @Standard_Energy_Therm_Cwt, -- ReportColumnId - int
	       1, -- SettingValue - bit
	       3, -- RoleId - int
	       10 -- ReportId - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsRoleMapping AS rcrm
    WHERE rcrm.ReportColumnId = CASE 
					   WHEN @Standard_Energy_Therm_Cwt IS NOT NULL THEN @Standard_Energy_Therm_Cwt
                                                      ELSE(SELECT
                                                                   rc.Id
                                                               FROM TCD.ReportColumns AS rc
                                                               WHERE rc.Name = 'Standard Energy Usage Therm/Cwt')
					END
		AND rcrm.ReportId = 10
                        AND rcrm.RoleId = 4)
    BEGIN
            INSERT INTO tcd.ReportColumnsRoleMapping(
	       --Id - this column value is auto-generated
	       ReportColumnId,
	       SettingValue,
	       RoleId,
                    ReportId)
	   VALUES
	   (
	       -- Id - int
	       @Standard_Energy_Therm_Cwt, -- ReportColumnId - int
	       1, -- SettingValue - bit
	       4, -- RoleId - int
	       10 -- ReportId - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsRoleMapping AS rcrm
    WHERE rcrm.ReportColumnId = CASE 
					   WHEN @Standard_Energy_Therm_Cwt IS NOT NULL THEN @Standard_Energy_Therm_Cwt
                                                      ELSE(SELECT
                                                                   rc.Id
                                                               FROM TCD.ReportColumns AS rc
                                                               WHERE rc.Name = 'Standard Energy Usage Therm/Cwt')
					END
		AND rcrm.ReportId = 10
                        AND rcrm.RoleId = 5)
    BEGIN
            INSERT INTO tcd.ReportColumnsRoleMapping(
	       --Id - this column value is auto-generated
	       ReportColumnId,
	       SettingValue,
	       RoleId,
                    ReportId)
	   VALUES
	   (
	       -- Id - int
	       @Standard_Energy_Therm_Cwt, -- ReportColumnId - int
	       1, -- SettingValue - bit
	       5, -- RoleId - int
	       10 -- ReportId - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsRoleMapping AS rcrm
    WHERE rcrm.ReportColumnId = CASE 
					   WHEN @Standard_Energy_Therm_Cwt IS NOT NULL THEN @Standard_Energy_Therm_Cwt
                                                      ELSE(SELECT
                                                                   rc.Id
                                                               FROM TCD.ReportColumns AS rc
                                                               WHERE rc.Name = 'Standard Energy Usage Therm/Cwt')
					END
		AND rcrm.ReportId = 10
                        AND rcrm.RoleId = 6)
    BEGIN
            INSERT INTO tcd.ReportColumnsRoleMapping(
	       --Id - this column value is auto-generated
	       ReportColumnId,
	       SettingValue,
	       RoleId,
                    ReportId)
	   VALUES
	   (
	       -- Id - int
	       @Standard_Energy_Therm_Cwt, -- ReportColumnId - int
	       1, -- SettingValue - bit
	       6, -- RoleId - int
	       10 -- ReportId - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsRoleMapping AS rcrm
    WHERE rcrm.ReportColumnId = CASE 
					   WHEN @Standard_Energy_Therm_Cwt IS NOT NULL THEN @Standard_Energy_Therm_Cwt
                                                      ELSE(SELECT
                                                                   rc.Id
                                                               FROM TCD.ReportColumns AS rc
                                                               WHERE rc.Name = 'Standard Energy Usage Therm/Cwt')
					END
		AND rcrm.ReportId = 10
                        AND rcrm.RoleId = 7)
    BEGIN
            INSERT INTO tcd.ReportColumnsRoleMapping(
	       --Id - this column value is auto-generated
	       ReportColumnId,
	       SettingValue,
	       RoleId,
                    ReportId)
	   VALUES
	   (
	       -- Id - int
	       @Standard_Energy_Therm_Cwt, -- ReportColumnId - int
	       1, -- SettingValue - bit
	       7, -- RoleId - int
	       10 -- ReportId - int
	   );
    END;
    IF NOT EXISTS(SELECT TOP 1
		 *
                      FROM TCD.ReportColumnsRoleMapping AS rcrm
    WHERE rcrm.ReportColumnId = CASE 
					   WHEN @Standard_Energy_Therm_Cwt IS NOT NULL THEN @Standard_Energy_Therm_Cwt
                                                      ELSE(SELECT
                                                                   rc.Id
                                                               FROM TCD.ReportColumns AS rc
                                                               WHERE rc.Name = 'Standard Energy Usage Therm/Cwt')
					END
		AND rcrm.ReportId = 10
                        AND rcrm.RoleId = 8)
    BEGIN
            INSERT INTO tcd.ReportColumnsRoleMapping(
	       --Id - this column value is auto-generated
	       ReportColumnId,
	       SettingValue,
	       RoleId,
                    ReportId)
	   VALUES
	   (
	       -- Id - int
	       @Standard_Energy_Therm_Cwt, -- ReportColumnId - int
	       1, -- SettingValue - bit
	       8, -- RoleId - int
	       10 -- ReportId - int
	   );
    END;
    UPDATE tcd.ReportColumns SET
    --Id - this column value is auto-generated
    TCD.ReportColumns.Name = N'Actual Energy Usage Btu/Cwt' -- nvarchar
        WHERE
            tcd.ReportColumns.Id = 76;
END;
GO

-------------146350:Local Reports: Operations Summary Need to have separate columns for UOM for Energy to display in Btu and in Therm------------

--------------START :: 164626:::Reports --> Reports to include Manual Input Rewash Loads------------------------------------------------------
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[ReportProductionDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
			TCD.ReportProductionDetails;
	END; 
	GO 

CREATE PROCEDURE TCD.ReportProductionDetails   

/******************************************************************  
DESCRIPTION		: 
  
  
MODIFICATION HISTORY DETAILS:   
 21st Jan 2015 -  Kiran     -  Added Formula hierarchy -->Formula segment-->Formula category-->formula  
  
  
REFERENC TABLES :  
  Select * from TCD.Plant --Plant master  
  Select * FROM TCD.PlantChain  --Master Plants  
  Select * FROM TCD.PlantChainProgram  
  Select * FROM TCD.ChainTextileCategory  
  Select * FROM TCD.ProgramMaster  
  Select * FROM TCD.EcolabTextileCategory  --Masters  
  Select * FROM TCD.EcolabSaturation --Masters  
  Select * FROM TCD.FormulaSegments --Masters  
  
EXECUTION STATEMENT :  
  
	EXEC [TCD].[ReportProductionDetails] @startdate = '2015-01-01 00:0:00',@enddate = '2016-01-01 11:59:59',@Viewtype  = '8',@Subview = '21',
          @Drillvalue = '',@EcolabAccountNumber = '040242802',@MachineType = '', @MachineGroup  = '',@Machine  = '',   
          @EcolabCategory  = '',@ChainCategory  = '', @PlantFormula  = '', @ChainFormula = '', @Customer  = '',  
          @SortColumnId  = 0,@SortDirection  = 'Desc',@CurrencyCode = '', @UserId = 1, @FormulaSegement ='',  
          @FormulaCategory='',@Formula=''
	
    
*******************************************************************/ 
  
       @Startdate DATETIME = '', 
       @Enddate DATETIME = '', 
       @Viewtype INT = '', 
       @Subview INT = '', 
       @Drillvalue VARCHAR(100) = '', 
       @Ecolabaccountnumber NVARCHAR(25) = '', 
       @Machinetype VARCHAR(20) = '', 
       @Machinegroup VARCHAR(MAX) = '', 
	@Machine VARCHAR(MAX) = '',  
       @Ecolabcategory VARCHAR(MAX) = '', 
       @Chaincategory VARCHAR(MAX) = '', 
       @Plantformula VARCHAR(MAX) = '', 
       @Chainformula VARCHAR(MAX) = '', 
	@Customer VARCHAR(MAX) = '',  
       @Sortcolumnid INT = 0, 
       @Sortdirection VARCHAR(4) = '', 
       @Currencycode VARCHAR(3) = '', 
       @Userid INT = NULL, 
       @Formulasegement VARCHAR(MAX) = '', --Formula segment,  
       @Formulacategory VARCHAR(MAX) = '', --Formula category  
       @Formula VARCHAR(MAX) = '' --Formula  
AS     
BEGIN     
    SET NOCOUNT ON;
    
    DECLARE @Inputstartdate DATETIME = DATEADD(SECOND, DATEDIFF(SECOND, GETUTCDATE(), GETDATE()), @Startdate), 
            @Inputenddate DATETIME = DATEADD(SECOND, DATEDIFF(SECOND, GETUTCDATE(), GETDATE()), @Enddate);  
    
	 --SET @startdate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@startdate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@startdate AS time)) AS DateTime))  
	 --SET @EndDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndDate AS time)) AS DateTime))  

	 --SELECT @startdate,@EndDate 
    DECLARE @Reportgenerated INT = 6, 
            @Month INT = MONTH(GETDATE()), 
            @Correctionvariable DECIMAL(18, 2), 
            @Planttargetproduction DECIMAL(18, 2), 
            @Regionid INT;
        
    SELECT
            @Regionid = p.PlantId FROM TCD.Plant AS p; 

	 /* Inserting the record into Report History */  

    INSERT INTO TCD.ReportHistory(
            EcolabAccountNumber, 
            UserId, 
            UserName, 
            DateAndTime, 
            ActionTypeId, 
            ActionDescription)
    SELECT
            @Ecolabaccountnumber, 
            UM.UserId, 
            UM.LoginName, 
            GETUTCDATE(), 
            @Reportgenerated, 
            CASE
                WHEN @Reportgenerated = 6 THEN 'Generated Report : Production Details Report'
            END
        FROM TCD.UserMaster AS UM
        WHERE UM.EcolabAccountNumber = @Ecolabaccountnumber
          AND UM.UserId = @Userid;  
       
	-- Return Table set  
    DECLARE @Resultset TABLE(
            ShiftId INT, 
            DateRange VARCHAR(100), 
            TotalLoad DECIMAL(18, 2), 
            WasherEfficiency DECIMAL(18, 2), 
            PlantTargetLoad DECIMAL(18, 2), 
            StandardLoad DECIMAL(18, 2), 
		Numberofbatches INT,  
            ActualRunTime DECIMAL(30, 10) NULL, 
            TargetRunTime DECIMAL(30, 10) NULL, 
            NumberofPieces INT NULL, 
		Rewash FLOAT NULL,  
            Viewtype VARCHAR(100) NULL, 
            Subview VARCHAR(100) NULL, 
            Id INT NULL, 
            SortOrder INT NULL);
	
    DECLARE @Shifttargetproduction TABLE(
            ShiftId INT NULL, 
            TargetProduction INT NULL);

    INSERT INTO @Shifttargetproduction(
            ShiftId, 
            TargetProduction)
    SELECT
            ShiftId, 
            CASE
                WHEN @Regionid = 1 THEN ISNULL(PS.TargetProduction * 1000, 0)
                ELSE ISNULL(PS.TargetProduction, 0)
            END
        FROM TCD.ProductionShiftData AS PS
        WHERE PS.StartDateTime >= @Startdate
          AND PS.StartDateTime < @Enddate; 
	-- Correction factor
    DECLARE @Correctionfactor TABLE(
            ShiftId INT NULL, 
		MachineId INT NULL,  
            ActualProduction INT NULL, 
            StandardProduction INT NULL, 
            PlantTargetProd INT NULL, 
            ActualRunTime INT NULL, 
            TargetRunTime INT NULL, 
		ManualInputWeight INT,  
            ManulainputsNoofloads INT);  
      
	--Machine type  
    DECLARE @Machinetypetable TABLE(
            MachineType VARCHAR(100));
    INSERT INTO @Machinetypetable
    EXEC TCD.CharlistToTable @Machinetype, ',';  
  
	--washer Group  
    DECLARE @Washergrouptable TABLE(
            MachineGroup VARCHAR(100));
    INSERT INTO @Washergrouptable
    EXEC TCD.CharlistToTable @Machinegroup, ',';    
  
	--Machine list  
    DECLARE @Machinetable TABLE(
            Machine VARCHAR(100));
    INSERT INTO @Machinetable
    EXEC TCD.CharlistToTable @Machine, ',';  
  
	--Ecolab category  
    DECLARE @Ecolabcategorytable TABLE(
            EcolabCategory VARCHAR(100));
    INSERT INTO @Ecolabcategorytable
    EXEC TCD.CharlistToTable @Ecolabcategory, ',';  
  
	--Chain category  
    DECLARE @Chaincategorytable TABLE(
            ChainCategory VARCHAR(100));
    INSERT INTO @Chaincategorytable
    EXEC TCD.CharlistToTable @Chaincategory, ',';  
  
	--Plant formula  
    DECLARE @Plantformulatable TABLE(
            PlantFormula VARCHAR(100));
    INSERT INTO @Plantformulatable
    EXEC TCD.CharlistToTable @Plantformula, ',';  
  
	--Chain Formula  
    DECLARE @Chainformulatable TABLE(
            ChainFormula VARCHAR(100));
    INSERT INTO @Chainformulatable
    EXEC TCD.CharlistToTable @Chainformula, ',';  
  
	 --Customer Table  
    DECLARE @Customertable TABLE(
            Customer VARCHAR(100));
    INSERT INTO @Customertable
    EXEC TCD.CharlistToTable @Customer, ',';  
  
	 --Formula Segment --added by Kiran  
    DECLARE @Formulasegmenttable TABLE(
            FormulaSegment VARCHAR(1000));
    INSERT INTO @Formulasegmenttable
    EXEC TCD.CharlistToTable @Formulasegement, ',';  
  
	-----Formula category--------Start  
    DECLARE @Formulacategorytable TABLE(
            FormulaCategory VARCHAR(1000), 
            Type CHAR(1));
    INSERT INTO @Formulacategorytable(
            FormulaCategory)
    EXEC TCD.CharlistToTable @Formulacategory, ',';
	    	   
    DECLARE @Timeefficiencymaxcap INT, 
            @Loadefficiencymaxcap FLOAT;
    SELECT
            @Timeefficiencymaxcap = TimeEfficiencyMaxCap, 
            @Loadefficiencymaxcap = LoadEfficiencyMaxCap
        FROM TCD.Plant
        WHERE EcolabAccountNumber = @Ecolabaccountnumber;

		--Below 1000 Ecolab category  
    UPDATE @Formulacategorytable SET
            TYPE = 'E' WHERE
            FormulaCategory < 1000;  
		--Above 1000 consider as Chain category  
    UPDATE @Formulacategorytable SET
            TYPE = 'C' WHERE
            FormulaCategory >= 1000;  
  
		--Rollbacking to actual ID  
    UPDATE @Formulacategorytable SET
            FormulaCategory = FormulaCategory - 1000 WHERE
            TYPE = 'C';
		  
    INSERT INTO @Ecolabcategorytable(
            EcolabCategory)
    SELECT
            FormulaCategory FROM @Formulacategorytable WHERE Type = 'E';
  
    INSERT INTO @Chaincategorytable(
            ChainCategory)
    SELECT
            FormulaCategory FROM @Formulacategorytable WHERE Type = 'C';  
  
		--Value Assigning  
    IF EXISTS(SELECT
                      * FROM @Ecolabcategorytable)
   AND @Formulacategory != ''
		BEGIN  
            SET @Ecolabcategory = @Formulacategory;
        END;
    IF EXISTS(SELECT
                      * FROM @Chaincategorytable)
   AND @Formulacategory != ''
		BEGIN  
            SET @Chaincategory = @Formulacategory;
        END;  
	
  
	-----Formula Ecolab/Chain formulas  
    DECLARE @Formulatable TABLE(
            Formula VARCHAR(1000), 
            Type CHAR(1));
    INSERT INTO @Formulatable(
            Formula)
    EXEC TCD.CharlistToTable @Formula, ',';  
   	 
		--Plant fomula     
    INSERT INTO @Plantformulatable(
            PlantFormula)
    SELECT
            Formula FROM @Formulatable; --WHERE Type='E'  
		--chain formula     
    INSERT INTO @Chainformulatable(
            ChainFormula)
    SELECT
            Formula FROM @Formulatable; --WHERE Type='C'  
		   
		 --Value Assigning  
    IF EXISTS(SELECT
                      * FROM @Plantformulatable)
   AND @Formula != ''
		 BEGIN  
            SET @Plantformula = @Formula;
        END;
    IF EXISTS(SELECT
                      * FROM @Chainformulatable)
   AND @Formula != ''
		 BEGIN  
            SET @Chainformula = @Formula;
        END;  
		
  
	 --Insert Into @CorrectionFactor table  
    INSERT INTO @Correctionfactor(
            ShiftId, 
            MachineId, 
            ActualProduction, 
            StandardProduction, 
            PlantTargetProd, 
            ActualRunTime, 
            TargetRunTime, 
		  ManualInputWeight,  
            ManulainputsNoofloads)
	 SELECT   
            PS.ShiftId, 
            SPD.MachineId, 
            ISNULL(SUM(ISNULL(SPD.ActualProduction, 0)) + SUM(ISNULL(MIP.ActualWeight, 0)), 0), 
            ISNULL(SUM(SPD.StandardProduction), 0), 
            ISNULL(MAX(PS.TargetProduction), 0), 
            SUM(SPD.ActualRunTime + ISNULL(SPD.ActualTurnTime, 0)), 
            SUM(SPD.TargetRunTime + ISNULL(SPD.TargetTurnTime, 0)), 
            SUM(ISNULL(MIP.ActualWeight, 0)), 
            SUM(ISNULL(MIP.NoofLoads, 0))
        FROM TCD.ShiftProductionDataRollup AS SPD
             INNER JOIN TCD.MachineSetup AS ms ON SPD.MachineId = ms.WasherId
             INNER JOIN TCD.ProductionShiftData AS PS ON SPD.ShiftId = PS.ShiftId
             INNER JOIN TCD.ProgramMaster AS PM ON SPD.ProgramMasterId = PM.ProgramId
	LEFT OUTER JOIN --Manual Production Details appending  
             (SELECT
                      WasherId, 
                      FormulaId, 
                      CONVERT(DATE, RecordedDate) AS LoadDate, 
                      SUM(ISNULL(Value, 0)) AS ActualWeight, 
                      ISNULL(COUNT(CONVERT(DATE, RecordedDate)), 0) AS NoofLoads
                  FROM TCD.ManualProduction AS MP
                  GROUP BY
                      WasherId, 
                      FormulaId, 
                      CONVERT(DATE, RecordedDate)) AS MIP ON MIP.WasherId = SPD.EcolabWasherId
                                                         AND MIP.FormulaId = SPD.ProgramMasterId
                                                         AND MIP.LoadDate = CONVERT(DATE, PS.StartDateTime)
        WHERE ISNULL(ms.IsPony, 0) = 0
          AND CASE @Startdate
                  WHEN '' THEN CASE
                                   WHEN MONTH(CAST(PS.StartDateTime AS DATE)) = @Month THEN 'TRUE'
                               END
                  ELSE CASE
                           WHEN PS.StartDateTime >= @Startdate
                            AND PS.StartDateTime < @Enddate THEN 'TRUE'
                       END
              END = 'TRUE'
        GROUP BY
            MachineId, 
            PS.ShiftId;   
  
	 --WITH CTE (PlantTargetProd) AS  
	 --(  
	 --SELECT SUM(DISTINCT SPD.[PlantTargetProd]) FROM @CorrectionFactor SPD GROUP BY ShiftId  
	 --)  
	 --SELECT @PlantTargetProduction = SUM(PlantTargetProd) FROM CTE;  
  
    DECLARE @Factor TABLE(
            MachineId INT, 
            ShiftId INT, 
            TargetProduction DECIMAL(18, 5), 
            CorrectionFactor DECIMAL(18, 5), 
            PlantEfficiency DECIMAL(18, 5), 
            PlantTargetProduction DECIMAL(18, 5));
    WITH CTE(
            MachineId, 
            ShiftId, 
            PlantEfficiency)
        AS (SELECT
                    MachineId, 
                    ShiftId, 
                    CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18, 4)) / NULLIF(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18, 4))
/ NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18, 4)), 0), 1) * COALESCE(CAST(SUM(SPD.TargetRunTime) AS DECIMAL(18, 4)) / NULLIF(CAST(SUM(SPD.
ActualRunTime) AS DECIMAL(18, 4)), 0), 0), 0), 1) AS DECIMAL(18, 4))
                FROM @Correctionfactor AS SPD
                GROUP BY
		MachineId,  
                    ShiftId), ShiftWiseEfficiencyCTE(
            ShiftId, 
            TargetProductionShift)
        AS (SELECT
		ShiftId,
                    SUM(PlantEfficiency) FROM CTE GROUP BY
                    ShiftId)
	
        INSERT INTO @Factor(
                MachineId, 
                ShiftId, 
                TargetProduction, 
                CorrectionFactor, 
                PlantEfficiency, 
                PlantTargetProduction)
        SELECT
                c.MachineId, 
                stp.ShiftId, 
                c.PlantEfficiency * ISNULL(stp.TargetProduction, 0) / CAST(ISNULL(sfc.TargetProductionShift, 1) AS DECIMAL), 
                ISNULL(stp.TargetProduction, 0) / CAST(ISNULL(sfc.TargetProductionShift, 1) AS DECIMAL), 
                c.PlantEfficiency, 
                stp.TargetProduction
            FROM CTE AS c
                 INNER JOIN @Shifttargetproduction AS stp ON c.ShiftId = stp.ShiftId
                 INNER JOIN ShiftWiseEfficiencyCTE AS sfc ON c.ShiftId = sfc.ShiftId;

  	
    DECLARE @Productionsummarytable TABLE(
            ShiftId INT NULL, 
            ShiftName VARCHAR(100) NULL, 
            RecordDate DATE, 
            MachineId INT NULL, 
            ProgramMasterId INT NULL, 
            EcolabWasherId INT NULL, 
            ActualProduction INT NULL, 
            StandardProduction INT NULL, 
            NoOfLoads INT NULL, 
            LoadEfficiency DECIMAL(18, 2) NULL, 
            TimeEfficiency DECIMAL(18, 2) NULL, 
            TotalEfficiency DECIMAL(18, 2) NULL, 
            PlantTargetProd INT NULL, 
            ActualRunTime INT NULL, 
            TargetRunTime INT NULL, 
            EcolabTextileId INT, 
            ChainTextileId INT, 
            ChainProgaramId INT, 
            CustomerId INT, 
            NoOfPieces INT, 
	  Rewash FLOAT,  
            ShiftRunTime DECIMAL(30, 10) NULL, 
	  FormulaSegmentID INT,  
	  RowNumberID INT,
            IndividualShiftRunTime DECIMAL(30, 10), 
            ShiftRownumber INT);
  
    INSERT INTO @Productionsummarytable
    SELECT
            PS.ShiftId, 
            PS.ShiftName, 
            CAST(DATEADD(SECOND, DATEDIFF(SECOND, GETUTCDATE(), GETDATE()), PS.StartDateTime) AS DATE), 
            SPD.MachineId, 
            SPD.ProgramMasterId, 
            SPD.EcolabWasherId, 
            ISNULL(SPD.ActualProduction, 0), 
            ISNULL(SPD.StandardProduction, 0), 
            ISNULL(SPD.NoOfLoads, 0), 
            CASE
                WHEN ISNULL(SPD.LoadEfficiency, 0) * 100 >= @Loadefficiencymaxcap THEN @Loadefficiencymaxcap
                ELSE ISNULL(SPD.LoadEfficiency, 0)
            END, 
            CASE
                WHEN ISNULL(SPD.TimeEfficiency, 0) * 100 >= @Timeefficiencymaxcap THEN @Timeefficiencymaxcap
                ELSE ISNULL(SPD.TimeEfficiency, 0)
            END, 
            ISNULL(SPD.LoadEfficiency, 0) * ISNULL(SPD.TimeEfficiency, 0), 
            ISNULL(SPD.PlantTargetProd, 0), 
            ISNULL(SPD.ActualRunTime, 0) + ISNULL(SPD.ActualTurnTime, 0), 
            ISNULL(SPD.TargetRunTime, 0) + ISNULL(SPD.TargetTurnTime, 0), 
            SPD.EcolabTextileId, 
            SPD.ChainTextileId, 
            SPD.ChainProgaramId, 
            SPD.CustomerId, 
            ISNULL(SPD.NoOfPieces, 0), 
            ISNULL(CAST((SELECT
                                 SUM(spdr.ActualProduction)
                             FROM TCD.ShiftProductionDataRollup AS spdr
                             WHERE spdr.ShiftId = SPD.ShiftId
                               AND spdr.MachineId = SPD.MachineId
                               AND spdr.ProgramMasterId = SPD.ProgramMasterId
                               AND spdr.ProgramMasterId IN(
	SELECT   
                                 pm.ProgramId FROM TCD.ProgramMaster AS pm WHERE pm.Rewash = 1)) AS DECIMAL(18, 2)), 0)

			-- append ManualRewashLoad to Rewash
            + ISNULL(CASE
                         WHEN SUM(SPD.ActualProduction) OVER(PARTITION BY MS.EcoalabAccountNumber, 
                                                                          MS.GroupId, 
                                                                          SPD.ProgramMasterId, 
                                                                          CAST(DATEADD(SECOND, DATEDIFF(SECOND, GETUTCDATE(), GETDATE()), PS.
StartDateTime) AS DATE)) <> 0 THEN Mr.Value * CAST(SPD.ActualProduction AS FLOAT) / SUM(SPD.ActualProduction) OVER(PARTITION BY MS.
EcoalabAccountNumber, 
                                                                                                                                MS.GroupId, 
                                                                                                                                SPD.ProgramMasterId, 
                                                                                                                                CAST(DATEADD(SECOND,
DATEDIFF(SECOND, GETUTCDATE(), GETDATE()), PS.StartDateTime) AS DATE))
					ELSE 0
                     END, 0) AS Rewash, 
            DATEDIFF(Second, ps.StartDateTime, PS.EndDateTime) + ISNULL((SELECT
                                                                                 SUM(SPD.ActualRunTime + ISNULL(SPD.ActualTurnTime, 0))
                                                                             FROM TCD.ShiftProductionDataRollup AS SPD
                                                                                  INNER JOIN TCD.ProductionShiftData AS PSD ON SPD.ShiftId = PSD.
ShiftId
                                                                             WHERE PSD.StartDateTime = PS.StartDateTime
                                                                               AND PSD.StartDateTime = PS.EndDateTime
                                                                               AND PS.ShiftName = 'No Shift'), 0), 
            CASE
                WHEN SPD.ChainProgaramId IS NOT NULL
                 AND SPD.ChainProgaramId > 0 THEN ChainPlant.FormulaSegmentId
					ELSE FS1.FormulaSegmentID 
            END AS Formulasegment, 
            ROW_NUMBER() OVER(PARTITION BY SPD.ProgramMasterId, 
                                           SPD.EcolabWasherId, 
                                           CAST(DATEADD(SECOND, DATEDIFF(SECOND, GETUTCDATE(), GETDATE()), PS.StartDateTime) AS DATE) ORDER BY SPD.
ProgramMasterId, SPD.EcolabWasherId), 
            0, --IndividualShiftruntime
            ROW_NUMBER() OVER(PARTITION BY SPD.ShiftID ORDER BY SPD.ShiftID)
  
			--CAST(((SELECT SUM(MR.VALUE) FROM TCD.ManualRewash MR WHERE SPD.ProgramMasterId = MR.FormulaId AND CAST(PS.StartDateTime AS date) = CAST(MR.RecordedDate AS date) GROUP BY CAST(MR.RecordedDate AS date),MR.FormulaId)) AS decimal(18,2))  

        FROM TCD.ShiftProductionDataRollup AS SPD
             INNER JOIN TCD.ProductionShiftData AS PS ON SPD.ShiftId = PS.ShiftId
             INNER JOIN TCD.ProgramMaster AS PM ON SPD.ProgramMasterId = PM.ProgramId
             INNER JOIN TCD.MachineSetup AS ms ON SPD.MachineId = ms.WasherId
             LEFT OUTER JOIN(  
				--IF Chain Plant  
                            SELECT
                                    PCP.PlantProgramId, 
                                    PCP.PlantChainId, 
                                    PCP.ChainTextileCategoryId, 
                                    PCP.EcolabTextileCategoryId, 
                                    PCP.FormulaSegmentId, 
                                    PCP.EcolabSaturationId
                                FROM TCD.PlantChainProgram AS PCP
                                     LEFT OUTER JOIN TCD.FormulaSegments AS FS ON FS.FormulaSegmentID = PCP.FormulaSegmentId) AS ChainPlant ON SPD.
ChainProgaramId = ChainPlant.PlantProgramId
             LEFT OUTER JOIN TCD.FormulaSegments AS FS1 ON FS1.FormulaSegmentID = PM.FormulaSegmentId
             LEFT OUTER JOIN(SELECT
                                     MR.EcolabAccountNumber, 
                                     MR.WasherGroupId, 
                                     MR.FormulaId, 
                                     MR.RecordedDate, 
                                     RWS.ShiftId, 
                                     SUM(MR.Value) AS Value
                                 FROM TCD.ManualRewash AS MR
                                      OUTER APPLY(
                             SELECT
                                     PSD.ShiftId
                                 FROM TCD.ProductionShiftData AS PSD
                                 WHERE CAST(PSD.StartDateTime AS DATE) = MR.RecordedDate) AS RWS
				GROUP BY
                                     MR.EcolabAccountNumber, 
                                     MR.WasherGroupId, 
                                     MR.FormulaId, 
                                     MR.RecordedDate, 
                                     RWS.ShiftId) AS MR ON MR.FormulaId = SPD.ProgramMasterId
					AND MR.WasherGroupId = MS.GroupId
					AND MR.EcolabAccountNumber = MS.EcoalabAccountNumber
					AND MR.ShiftID = PS.ShiftID
        WHERE ISNULL(ms.IsPony, 0) = 0
          AND CASE @Startdate
                  WHEN '' THEN CASE
                                   WHEN MONTH(CAST(PS.StartDateTime AS DATE)) = @Month THEN 'TRUE'
                               END
                  ELSE CASE
                           WHEN PS.StartDateTime >= @Startdate
                            AND PS.StartDateTime <= @Enddate THEN 'TRUE'
                       END
              END = 'TRUE'
          AND CASE @Machinetype
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN SPD.MachineId IN(SELECT
                                                         MS.WasherId
                                                     FROM TCD.MachineSetup AS MS
                                                     WHERE MS.GroupId IN(
                                                 SELECT
                                                         WG.WasherGroupId
                                                     FROM TCD.WasherGroup AS WG
                                                     WHERE WG.WasherGroupTypeId IN(
                                                 SELECT
                                                         MachineType FROM @Machinetypetable))) THEN 'TRUE'
                       END
              END = 'TRUE'
          AND CASE @Machinegroup
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN SPD.MachineId IN(SELECT
                                                         MS.WasherId
                                                     FROM TCD.MachineSetup AS MS
                                                     WHERE MS.GroupId IN(
                                                 SELECT
                                                         MachineGroup FROM @Washergrouptable)) THEN 'TRUE'
                       END
              END = 'TRUE'
          AND CASE @Machine
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN SPD.MachineId IN(SELECT
                                                         Machine FROM @Machinetable) THEN 'TRUE'
                       END
              END = 'TRUE'
          AND (CASE @Ecolabcategory
                   WHEN '' THEN 'TRUE'
                   ELSE CASE
                            WHEN SPD.EcolabTextileId IN(SELECT
                                                                EcolabCategory FROM @Ecolabcategorytable) THEN 'TRUE'
                        END
               END = 'TRUE'
            OR CASE @Chaincategory
                   WHEN '' THEN 'TRUE'
                   ELSE CASE
                            WHEN SPD.ChainTextileId IN(SELECT
                                                               ChainCategory FROM @Chaincategorytable) THEN 'TRUE'
                        END
               END = 'TRUE')
          AND CASE @Plantformula
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN SPD.ProgramMasterId IN(SELECT
                                                               PlantFormula FROM @Plantformulatable) THEN 'TRUE'
                       END
              END = 'TRUE'
          AND CASE @Chainformula
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN SPD.ProgramMasterId IN(SELECT
                                                               ChainFormula FROM @Chainformulatable) THEN 'TRUE'
                       END
              END = 'TRUE'
          AND CASE @Customer
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN SPD.CustomerId IN(SELECT
                                                          Customer FROM @Customertable) THEN 'TRUE'
                       END
              END = 'TRUE'  

			--Added by Kiran   
          AND CASE @Formulasegement
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN SPD.ChainProgaramId IS NOT NULL
                            AND SPD.ChainProgaramId > 0 THEN CASE
                                                                 WHEN ChainPlant.FormulaSegmentId IN(SELECT
                                                                                                             FormulaSegment FROM @Formulasegmenttable)
THEN 'TRUE'
                                                             END
                           ELSE CASE
                                    WHEN FS1.FormulaSegmentID IN(SELECT
                                                                         FormulaSegment FROM @Formulasegmenttable) THEN 'TRUE'
                                END
		END                                                       
              END = 'TRUE';

	
    DECLARE @Filterproductionsummerycount INT, 
            @Correctionfactorcount INT, 
            @Isfiltersappliled BIT = 0;

    SELECT
            @Correctionfactorcount = COUNT(1) FROM @Factor;

    WITH cte
        AS (SELECT DISTINCT
                    pst.ShiftId, 
                    pst.MachineId FROM @Productionsummarytable AS pst)
        SELECT
                @Filterproductionsummerycount = COUNT(1) FROM cte;

    IF @Correctionfactorcount > @Filterproductionsummerycount
	BEGIN
            SET @Isfiltersappliled = 1;
        END;

    UPDATE @Productionsummarytable SET
            PlantTargetProd = 0;

    IF @Viewtype = 1
   AND @Isfiltersappliled = 0
	BEGIN
            WITH cte(
                    ShiftId, 
                    PlantTargetProd, 
                    rownum)
                AS(SELECT
                           ShiftId, 
                           PlantTargetProd, 
                           ROW_NUMBER() OVER(PARTITION BY ShiftId ORDER BY ShiftId) AS rownum
                       FROM @Productionsummarytable)
                UPDATE c SET
                        c.PlantTargetProd = f.PlantTargetProduction
                    FROM cte c
                         INNER JOIN @Factor f ON c.ShiftId = f.ShiftId
                                             AND c.rownum = 1;
        END;
	ELSE
	BEGIN
            WITH cte(
                    ShiftId, 
                    MachineId, 
                    PlantTargetProd, 
                    rownum)
                AS(SELECT
                           ShiftId, 
                           MachineId, 
                           PlantTargetProd, 
                           ROW_NUMBER() OVER(PARTITION BY ShiftId, 
                                                          MachineId ORDER BY ShiftId, MachineId) AS rownum
                       FROM @Productionsummarytable)
                UPDATE c SET
                        c.PlantTargetProd = f.TargetProduction
                    FROM cte c
                         INNER JOIN @Factor f ON c.ShiftId = f.ShiftId
                                             AND c.MachineId = f.MachineId
                                             AND c.rownum = 1;
        END;
	--------------------------------  
   	 --For top 1 record combination updating the manual input data.  
    UPDATE S SET
            ActualProduction = ISNULL(S.ActualProduction, 0) + ISNULL(MIP.ManualIPActualWeight, 0), 
            S.NoOfLoads = ISNULL(S.NoOfLoads, 0) + ISNULL(MIP.NoofLoads, 0)
        FROM @Productionsummarytable S
             INNER JOIN(SELECT
                                WasherId, 
                                FormulaId, 
                                CONVERT(DATE, RecordedDate) AS LoadDate, 
                                SUM(Value) AS ManualIPActualWeight, 
                                COUNT(CONVERT(DATE, RecordedDate)) AS NoofLoads
                            FROM TCD.ManualProduction AS MP
                            GROUP BY
                                WasherId, 
                                FormulaId, 
                                CONVERT(DATE, RecordedDate)) MIP ON MIP.WasherId = S.MachineId
                                                                AND MIP.FormulaId = S.ProgramMasterId
                                                                AND MIP.LoadDate = S.RecordDate
        WHERE
            S.RowNumberID = 1;
	
	
    DECLARE @Tableshiftruntime TABLE(
            ShiftID INT, 
            ShiftRuntime DECIMAL(20, 10), 
            ID INT, 
            Name VARCHAR(1000));
    DECLARE @Maxshiftruntime1 DECIMAL(30, 10), 
            @Noofshifts INT;
	--FInding  total shiftruntime irrespective of Ecolab AccountnNumber
	--SELECT @MaxShiftruntime1=ISNULL(SUM(A.Shiftruntime),0) ,@noofShifts=COUNT(A.Shiftruntime)  FROM 
	--	(SELECT DISTINCT SHIFTID, ShiftRuntime Shiftruntime,RecordDATE FROM @ProductionSummaryTable1)A	
    
    IF @Viewtype = 3 --Ecolab Categorie View 
	 BEGIN  
            IF @Subview = 12
	  BEGIN  
                    WITH CTE(
                            DateRange, 
                            TotalLoad, 
                            WasherEfficiency, 
                            PlantTargetLoad, 
                            StandardLoad, 
                            Numberofbatches, 
                            ActualRunTime, 
                            TargetRuntime, 
                            NumberofPieces, 
                            Rewash, 
                            TextileId)
                        AS(SELECT
		EC.CategoryName,  
		SUM(SPD.ActualProduction),  
                                   COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(LoadEfficiency) * SUM(SPD.TimeEfficiency), 0), 0), 
		SUM(SPD.PlantTargetProd),  
		SUM(SPD.StandardProduction),  
                                   SUM(NoOfLoads), 
                                   SUM(SPD.ShiftRunTime), 
                                   SUM(SPD.ShiftRunTime), 
		SUM(SPD.NoOfPieces),  
		SUM(SPD.Rewash),  
		EC.TextileId  
                               FROM @Productionsummarytable AS SPD
                                    LEFT JOIN TCD.EcolabTextileCategory AS EC ON EC.TextileId = SPD.EcolabTextileId
		WHERE EC.CategoryName IS NOT NULL  
		GROUP BY   
                                   EC.CategoryName, 
                                   EC.TextileId, 
                                   SPD.ShiftId)
                        INSERT INTO @Resultset
		  SELECT DISTINCT  
		0,  
		DateRange,  
		SUM(TotalLoad),  
		SUM(WasherEfficiency),  
		SUM(PlantTargetLoad),  
		SUM(StandardLoad),  
		SUM(Numberofbatches),  
		SUM(ActualRunTime),  
		SUM(TargetRuntime),  
		SUM(NumberofPieces),  
                                SUM(Rewash), 
                                @Viewtype, 
                                @Subview, 
                                TextileId, 
                                0
		FROM CTE  
		WHERE TotalLoad IS NOT NULL  
                            GROUP BY
                                DateRange, 
                                TextileId;
                END;
            IF @Subview = 17
	  BEGIN  
                    WITH CTE(
                            DateRange, 
                            TotalLoad, 
                            WasherEfficiency, 
                            PlantTargetLoad, 
                            StandardLoad, 
                            Numberofbatches, 
                            ActualRunTime, 
                            TargetRuntime, 
                            NumberofPieces, 
                            Rewash)
                        AS(SELECT
	   PM.Name,  
	   SUM(SPD.ActualProduction),  
                                   COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(LoadEfficiency) * SUM(SPD.TimeEfficiency), 0), 0), 
	   SUM(SPD.PlantTargetProd),  
	   SUM(SPD.StandardProduction),  
                                   SUM(NoOfLoads), 
                                   SUM(SPD.ShiftRunTime), 
                                   SUM(SPD.ShiftRunTime), 
	   SUM(SPD.NoOfPieces),  
	   SUM(SPD.Rewash)  
                               FROM @Productionsummarytable AS SPD
                                    INNER JOIN TCD.EcolabTextileCategory AS EC ON EC.TextileId = SPD.EcolabTextileId
                                    INNER JOIN TCD.ProgramMaster AS PM ON EC.TextileId = PM.EcolabTextileCategoryId
                                                                      AND SPD.ProgramMasterId = PM.ProgramId
                               WHERE CASE
                                         WHEN @Drillvalue = '' THEN 'TRUE'
                                         WHEN @Drillvalue IS NULL THEN 'TRUE'
                                         ELSE CASE
                                                  WHEN EC.TextileId IN(@Drillvalue) THEN 'TRUE'
                                              END
                                     END = 'TRUE'
                                 AND PM.NAME IS NOT NULL
	   GROUP BY   
                                   PM.Name, 
                                   SPD.ShiftId)
                        INSERT INTO @Resultset
		 SELECT DISTINCT  
	   0,  
		  DateRange,  
		  SUM(TotalLoad),  
		  SUM(WasherEfficiency),  
		  SUM(PlantTargetLoad),  
		  SUM(StandardLoad),  
		  SUM(Numberofbatches),  
		  SUM(ActualRunTime),  
		  SUM(TargetRuntime),  
		  SUM(NumberofPieces),  
                                SUM(Rewash), 
                                @Viewtype, 
                                @Subview, 
                                0, 
                                0
		   FROM CTE  
		 WHERE TotalLoad IS NOT NULL  
                            GROUP BY
                                DateRange;
                END;
        END;
	
    IF @Viewtype = 4 --Textile Category View  
	 BEGIN   
            IF @Subview = 15
	  BEGIN  
                    WITH CTE(
                            DateRange, 
                            TotalLoad, 
                            WasherEfficiency, 
                            PlantTargetLoad, 
                            StandardLoad, 
                            Numberofbatches, 
                            ActualRunTime, 
                            TargetRuntime, 
                            NumberofPieces, 
                            Rewash)
                        AS(SELECT
		CC.Name,  
		SUM(SPD.ActualProduction),  
                                   COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(LoadEfficiency) * SUM(SPD.TimeEfficiency), 0), 0), 
		SUM(SPD.PlantTargetProd),  
		SUM(SPD.StandardProduction),  
                                   SUM(NoOfLoads), 
                                   SUM(SPD.ShiftRunTime), 
                                   SUM(SPD.ShiftRunTime), 
		SUM(SPD.NoOfPieces),  
		SUM(SPD.Rewash)  
                               FROM @Productionsummarytable AS SPD
                                    LEFT JOIN TCD.ChainTextileCategory AS CC ON CC.TextileId = SPD.ChainTextileId
		WHERE CC.Name IS NOT NULL   
		GROUP BY   
                                   CC.Name, 
                                   CC.TextileId, 
                                   SPD.ShiftId)
                        INSERT INTO @Resultset
		  SELECT DISTINCT  
		0,  
		   DateRange,  
		   SUM(TotalLoad),  
		   SUM(WasherEfficiency),  
		   SUM(PlantTargetLoad),  
		   SUM(StandardLoad),  
		   SUM(Numberofbatches),  
		   SUM(ActualRunTime),  
		   SUM(TargetRuntime),  
		   SUM(NumberofPieces),  
                                SUM(Rewash), 
                                @Viewtype, 
                                @Subview, 
                                0, 
                                0
		 FROM CTE  
		 WHERE TotalLoad IS NOT NULL  
                            GROUP BY
                                DateRange;
                END;
            IF @Subview = 18
	  BEGIN  
                    WITH CTE(
                            DateRange, 
                            TotalLoad, 
                            WasherEfficiency, 
                            PlantTargetLoad, 
                            StandardLoad, 
                            Numberofbatches, 
                            ActualRunTime, 
                            TargetRuntime, 
                            NumberofPieces, 
                            Rewash)
                        AS(SELECT
		PM.Name,  
		SUM(SPD.ActualProduction),  
                                   COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(LoadEfficiency) * SUM(SPD.TimeEfficiency), 0), 0), 
		SUM(SPD.PlantTargetProd),  
		SUM(SPD.StandardProduction),  
                                   SUM(NoOfLoads), 
                                   SUM(SPD.ShiftRunTime), 
                                   SUM(SPD.ShiftRunTime), 
		SUM(SPD.NoOfPieces),  
		SUM(SPD.Rewash)  
                               FROM @Productionsummarytable AS SPD
                                    INNER JOIN TCD.ChainTextileCategory AS CC ON CC.TextileId = SPD.ChainTextileId
                                    INNER JOIN TCD.ProgramMaster AS PM ON CC.TextileId = PM.ChainTextileId
                                                                      AND SPD.ProgramMasterId = PM.ProgramId
                               WHERE CASE
                                         WHEN @Drillvalue = '' THEN 'TRUE'
                                         WHEN @Drillvalue IS NULL THEN 'TRUE'
                                         ELSE CASE
                                                  WHEN CC.TextileId IN(@Drillvalue) THEN 'TRUE'
                                              END
                                     END = 'TRUE'
	   GROUP BY   
                                   PM.Name, 
                                   SPD.ShiftId)
                        INSERT INTO @Resultset
		  SELECT DISTINCT  
		0,  
		   DateRange,  
		   SUM(TotalLoad),  
		   SUM(WasherEfficiency),  
		   SUM(PlantTargetLoad),  
		   SUM(StandardLoad),  
		   SUM(Numberofbatches),  
		   SUM(ActualRunTime),  
		   SUM(TargetRuntime),  
		   SUM(NumberofPieces),  
                                SUM(Rewash), 
                                @Viewtype, 
                                @Subview, 
                                0, 
                                0
			FROM CTE  
		  WHERE TotalLoad IS NOT NULL  
                            GROUP BY
                                DateRange;
                END;
        END;
  	  
    IF @Viewtype = 1 --Timeline View 
	 BEGIN  
		
            IF @Subview = 5 -- Day view  
		BEGIN 
                    INSERT INTO @Tableshiftruntime(
                            ShiftID, 
                            ShiftRuntime, 
                            Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			SPD.ShiftName  
                        FROM @Productionsummarytable AS SPD;
		 
                    INSERT INTO @Resultset
			SELECT DISTINCT  
			0,  
			SPD.ShiftName,  
			SUM(SPD.ActualProduction),  
                            COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(LoadEfficiency) * SUM(SPD.TimeEfficiency), 0), 0), 
			SUM(SPD.PlantTargetProd),  
			SUM(SPD.StandardProduction),  
                            SUM(NoOfLoads), 
                            SUM(SPD.ShiftRunTime), 
                            SUM(SPD.ShiftRunTime), 
			SUM(SPD.NoOfPieces),  
                            SUM(SPD.Rewash), 
                            @Viewtype, 
                            @Subview, 
                            0, 
                            0
                        FROM @Productionsummarytable AS SPD
			GROUP BY   
			SPD.ShiftName;

			WITH CTE1
                        AS(SELECT
                                   SUM(ShiftRuntime) AS Shiftruntime, 
                                   Name FROM @Tableshiftruntime GROUP BY
                                   Name)

					--Update Shiftruntime in Temp table
                        UPDATE RS SET
                                RS.ActualRunTime = TS.Shiftruntime, 
                                RS.TargetRunTime = TS.Shiftruntime
                            FROM @Resultset RS
                                 LEFT OUTER JOIN CTE1 TS ON RS.DateRange = TS.Name;
		  
                END;
  		  
            IF @Subview = 4 --Week View  
		BEGIN  
			
                    INSERT INTO @Tableshiftruntime(
                            ShiftID, 
                            ShiftRuntime, 
                            Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
                            CAST(RecordDate AS NVARCHAR(100))
                        FROM @Productionsummarytable AS SPD;

                    WITH CTE(
                            DateRange, 
                            TotalLoad, 
                            WasherEfficiency, 
                            PlantTargetLoad, 
                            StandardLoad, 
                            Numberofbatches, 
                            ActualRunTime, 
                            TargetRuntime, 
                            NumberofPieces, 
                            Rewash, 
                            SortOrder)
                        AS(SELECT
                                   CAST(RecordDate AS NVARCHAR(100)), 
				SUM(SPD.ActualProduction),  
                                   COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(LoadEfficiency) * SUM(SPD.TimeEfficiency), 0), 0), 
				SUM(SPD.PlantTargetProd),  
				SUM(SPD.StandardProduction),  
                                   SUM(NoOfLoads), 
                                   SUM(SPD.ShiftRunTime), 
                                   SUM(SPD.ShiftRunTime), 
				SUM(SPD.NoOfPieces),  
                                   SUM(SPD.Rewash), 
                                   ROW_NUMBER() OVER(ORDER BY RecordDate)
                               FROM @Productionsummarytable AS SPD
                               GROUP BY
                                   DATEPART(weekday, RecordDate), 
                                   CAST(RecordDate AS DATE)--,SPD.ShiftId
			)  
                        INSERT INTO @Resultset
			SELECT DISTINCT  
			0,  
			DateRange,  
			SUM(TotalLoad),  
			SUM(WasherEfficiency),  
			SUM(PlantTargetLoad),  
			SUM(StandardLoad),  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime),  
			SUM(NumberofPieces),  
                                SUM(Rewash), 
                                @Viewtype, 
                                @Subview, 
                                0, 
                                SortOrder
			FROM CTE  
			WHERE TotalLoad IS NOT NULL  
                            GROUP BY
                                DateRange, 
                                SortOrder;

			WITH CTE1
                        AS(SELECT
                                   SUM(ShiftRuntime) AS Shiftruntime, 
                                   Name FROM @Tableshiftruntime GROUP BY
                                   Name)

					--Update Shiftruntime in Temp table
                        UPDATE RS SET
                                RS.ActualRunTime = TS.Shiftruntime, 
                                RS.TargetRunTime = TS.Shiftruntime, 
                                DateRange = CONVERT(VARCHAR(11), CONVERT(DATE, DateRange), 113) + ' (' + LEFT(DATENAME(dw, DateRange), 3) + ')' --Appending DayName in Output	
                            FROM @Resultset RS
                                 LEFT OUTER JOIN CTE1 TS ON RS.DateRange = TS.Name;
				
                END;
				
            IF @Subview = 3 --MonthView  
		BEGIN  
		 
		  
                    INSERT INTO @Tableshiftruntime(
                            ShiftID, 
                            ShiftRuntime, 
                            Name)
                    SELECT DISTINCT
                            SPD.ShiftId, 
                            SPD.ShiftRunTime AS ShiftRuntime, 
                            CASE
                                WHEN DATEADD(dd, -(DATEPART(dw, RecordDate) - 1), RecordDate) > @Inputstartdate THEN CAST(CONVERT(VARCHAR, DATEADD(dd,
-(DATEPART(dw, RecordDate) - 1), RecordDate), 101) AS NVARCHAR(100))
                                ELSE CAST(CONVERT(VARCHAR, @Inputstartdate, 101) AS NVARCHAR(100))
                            END + '-' + CASE
                                            WHEN DATEADD(dd, 7 - DATEPART(dw, RecordDate), RecordDate) < @Inputenddate THEN CAST(CONVERT(VARCHAR,
DATEADD(dd, 7 - DATEPART(dw, RecordDate), RecordDate), 101) AS NVARCHAR(100))
                                            ELSE CAST(CONVERT(VARCHAR, @Inputenddate, 101) AS NVARCHAR(100))
				END AS DateRange    
                        FROM @Productionsummarytable AS SPD;

                    WITH CTE1(
                            DateRange, 
                            TotalLoad, 
                            LoadEfficiency, 
				TimeEfficiency,
                            PlantTargetLoad, 
                            StandardLoad, 
                            Numberofbatches, 
                            ActualRunTime, 
                            TargetRuntime, 
                            NumberofPieces, 
                            Rewash, 
                            rowno)
                        AS(SELECT
                                   CASE
                                       WHEN DATEADD(dd, -(DATEPART(dw, RecordDate) - 1), RecordDate) > @Inputstartdate THEN CAST(CONVERT(VARCHAR,
DATEADD(dd, -(DATEPART(dw, RecordDate) - 1), RecordDate), 101) AS NVARCHAR(100))
                                       ELSE CAST(CONVERT(VARCHAR, @Inputstartdate, 101) AS NVARCHAR(100))
                                   END + '-' + CASE
                                                   WHEN DATEADD(dd, 7 - DATEPART(dw, RecordDate), RecordDate) < @Inputenddate THEN CAST(CONVERT(
VARCHAR, DATEADD(dd, 7 - DATEPART(dw, RecordDate), RecordDate), 101) AS NVARCHAR(100))
                                                   ELSE CAST(CONVERT(VARCHAR, @Inputenddate, 101) AS NVARCHAR(100))
                                               END AS DateRange, 
                                   SPD.ActualProduction, 
                                   LoadEfficiency, 
                                   TimeEfficiency, 
                                   SPD.PlantTargetProd, 
                                   SPD.StandardProduction, 
                                   NoOfLoads, 
                                   SPD.ShiftRunTime, 
                                   SPD.ShiftRunTime, 
                                   SPD.NoOfPieces, 
                                   SPD.Rewash, 
                                   DENSE_RANK() OVER(ORDER BY DATEADD(dd, -(DATEPART(dw, RecordDate) - 1), RecordDate)) AS rowno
                               FROM @Productionsummarytable AS SPD)
			
                        INSERT INTO @Resultset
		   SELECT DISTINCT  
		   0,  
		   DateRange,  
		   SUM(TotalLoad),  
                                COALESCE(SUM(TotalLoad) / NULLIF(SUM(LoadEfficiency) * SUM(TimeEfficiency), 0), 0), 
		   SUM(PlantTargetLoad),  
		   SUM(StandardLoad),  
		   SUM(Numberofbatches),  
		   SUM(ActualRunTime),  
		   SUM(TargetRuntime),  
		   SUM(NumberofPieces),  
                                SUM(Rewash), 
                                @Viewtype, 
                                @Subview, 
                                0, 
                                rowno
			FROM CTE1 
			WHERE TotalLoad IS NOT NULL  
                            GROUP BY
                                DateRange, 
                                rowno;
		  
		   WITH CTE1
                        AS(SELECT
                                   SUM(ShiftRuntime) AS Shiftruntime, 
                                   Name FROM @Tableshiftruntime GROUP BY
                                   Name)

					--Update Shiftruntime in Temp table
                        UPDATE RS SET
                                RS.ActualRunTime = TS.Shiftruntime, 
                                RS.TargetRunTime = TS.Shiftruntime
                            FROM @Resultset RS
                                 LEFT OUTER JOIN CTE1 TS ON RS.DateRange = TS.Name;
                END;
  
            IF @Subview = 2 --Year view 
		BEGIN  
                    DECLARE @Quarteryear VARCHAR(100) = YEAR(@Enddate);

                    INSERT INTO @Tableshiftruntime(
                            ShiftID, 
                            ShiftRuntime, 
                            Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
                            DATENAME(MONTH, RecordDate) + ' ' + CAST(YEAR(RecordDate) AS VARCHAR)
                        FROM @Productionsummarytable AS SPD;

                    WITH CTE(
                            DateRange, 
                            TotalLoad, 
                            WasherEfficiency, 
                            PlantTargetLoad, 
                            StandardLoad, 
                            Numberofbatches, 
                            ActualRunTime, 
                            TargetRuntime, 
                            NumberofPieces, 
                            Rewash, 
                            MonthOrder, 
                            YearOrder)
                        AS(SELECT
                                   DATENAME(MONTH, RecordDate) + ' ' + CAST(YEAR(RecordDate) AS VARCHAR) AS DateRange, 
				SUM(SPD.ActualProduction),  
                                   COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(LoadEfficiency) * SUM(SPD.TimeEfficiency), 0), 0), 
				SUM(SPD.PlantTargetProd),  
				SUM(SPD.StandardProduction),  
                                   SUM(NoOfLoads), 
                                   SUM(SPD.ShiftRunTime), 
                                   SUM(SPD.ShiftRunTime), 
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash),
                                   DATEPART(MONTH, RecordDate), 
				YEAR(RecordDate) 
                               FROM @Productionsummarytable AS SPD
                               GROUP BY
                                   DATEPART(MONTH, RecordDate), 
                                   DATENAME(MONTH, RecordDate), 
                                   SPD.ShiftId, 
                                   YEAR(RecordDate))
                        INSERT INTO @Resultset
			SELECT DISTINCT  
			0,  
			DateRange,  
			SUM(TotalLoad),  
			SUM(WasherEfficiency),  
			SUM(PlantTargetLoad),  
			SUM(StandardLoad),  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime),  
			SUM(NumberofPieces),  
                                SUM(Rewash), 
                                @Viewtype, 
                                @Subview, 
                                0, 
                                ROW_NUMBER() OVER(ORDER BY YearOrder, MonthOrder)
			FROM CTE  
			WHERE TotalLoad IS NOT NULL  
                            GROUP BY
                                DateRange, 
                                MonthOrder, 
                                YearOrder;
			
			WITH CTE1
                        AS(SELECT
                                   SUM(ShiftRuntime) AS Shiftruntime, 
                                   Name FROM @Tableshiftruntime GROUP BY
                                   Name)

					--Update Shiftruntime in Temp table
                        UPDATE RS SET
                                RS.ActualRunTime = TS.Shiftruntime, 
                                RS.TargetRunTime = TS.Shiftruntime
                            FROM @Resultset RS
                                 LEFT OUTER JOIN CTE1 TS ON RS.DateRange = TS.Name;
			 
                END;
  
            IF @Subview = 1 --Quarter View  
		BEGIN  
                    DECLARE @Year VARCHAR(100) = RIGHT(YEAR(@Enddate), 2);
			
                    INSERT INTO @Tableshiftruntime(
                            ShiftID, 
                            ShiftRuntime, 
                            Name, 
                            ID)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
                            CASE 'Q' + CAST(DATEPART(QUARTER, RecordDate) AS VARCHAR(10))
                                WHEN 'Q1' THEN 'Jan' + RIGHT(YEAR(RecordDate), 2) + '- Mar' + RIGHT(YEAR(RecordDate), 2)
                                WHEN 'Q2' THEN 'Apr' + RIGHT(YEAR(RecordDate), 2) + '- Jun' + RIGHT(YEAR(RecordDate), 2)
                                WHEN 'Q3' THEN 'Jul' + RIGHT(YEAR(RecordDate), 2) + '-Sep' + RIGHT(YEAR(RecordDate), 2)
                                WHEN 'Q4' THEN 'Oct' + RIGHT(YEAR(RecordDate), 2) + '- Dec' + RIGHT(YEAR(RecordDate), 2)
				END, 
                            CAST(CAST(RIGHT(YEAR(RecordDate), 2) AS VARCHAR) + CAST(DATEPART(QUARTER, RecordDate) AS VARCHAR) AS INT)
                        FROM @Productionsummarytable AS SPD;
			
                    WITH CTE(
                            DateRange, 
                            TotalLoad, 
                            WasherEfficiency, 
                            PlantTargetLoad, 
                            StandardLoad, 
                            Numberofbatches, 
                            ActualRunTime, 
                            TargetRuntime, 
                            NumberofPieces, 
                            Rewash, 
                            RowNo)
                        AS(SELECT
                                   CASE 'Q' + CAST(DATEPART(QUARTER, RecordDate) AS VARCHAR(10))
                                       WHEN 'Q1' THEN 'Jan' + RIGHT(YEAR(RecordDate), 2) + '- Mar' + RIGHT(YEAR(RecordDate), 2)
                                       WHEN 'Q2' THEN 'Apr' + RIGHT(YEAR(RecordDate), 2) + '- Jun' + RIGHT(YEAR(RecordDate), 2)
                                       WHEN 'Q3' THEN 'Jul' + RIGHT(YEAR(RecordDate), 2) + '-Sep' + RIGHT(YEAR(RecordDate), 2)
                                       WHEN 'Q4' THEN 'Oct' + RIGHT(YEAR(RecordDate), 2) + '- Dec' + RIGHT(YEAR(RecordDate), 2)
				END AS DateRange,  
				SUM(SPD.ActualProduction),  
                                   COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(LoadEfficiency) * SUM(SPD.TimeEfficiency), 0), 0), 
                                   SUM(SPD.PlantTargetProd), 
				SUM(SPD.StandardProduction),  
                                   SUM(NoOfLoads), 
                                   SUM(SPD.ShiftRunTime), 
                                   SUM(SPD.ShiftRunTime), 
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash),
                                   CAST(CAST(RIGHT(YEAR(RecordDate), 2) AS VARCHAR) + CAST(DATEPART(QUARTER, RecordDate) AS VARCHAR) AS INT) AS RowNo
                               FROM @Productionsummarytable AS SPD
                               GROUP BY
                                   DATEPART(QUARTER, RecordDate), 
                                   SPD.ShiftId, 
                                   RIGHT(YEAR(RecordDate), 2))
  
                        INSERT INTO @Resultset
			SELECT   
			0,  
			DateRange,  
			SUM(TotalLoad),  
			SUM(WasherEfficiency),  
			SUM(PlantTargetLoad),  
			SUM(StandardLoad),  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime),  
			SUM(NumberofPieces),  
                                SUM(Rewash), 
                                @Viewtype, 
                                @Subview, 
                                0, 
                                RowNo
			FROM CTE  
			WHERE TotalLoad IS NOT NULL  
                            GROUP BY
                                DateRange, 
                                RowNo
                            ORDER BY
                                RowNo;


			WITH CTE1
                        AS(SELECT
                                   SUM(ShiftRuntime) AS Shiftruntime, 
                                   Name FROM @Tableshiftruntime GROUP BY
                                   Name)

					--Update Shiftruntime in Temp table
                        UPDATE RS SET
                                RS.ActualRunTime = TS.Shiftruntime, 
                                RS.TargetRunTime = TS.Shiftruntime
                            FROM @Resultset RS
                                 LEFT OUTER JOIN CTE1 TS ON RS.DateRange = TS.Name;
  
                END;
        END;
  	 
    IF @Viewtype = 2 	--Location View		 					
	 BEGIN 				   		
            IF @Subview = 9  --Washer group view 
		BEGIN  
                    INSERT INTO @Tableshiftruntime(
                            ShiftID, 
                            ShiftRuntime, 
                            ID)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			WG.WasherGroupId  
                        FROM @Productionsummarytable AS SPD
                             INNER JOIN TCD.MachineSetup AS MS ON SPD.MachineId = MS.WasherId
                             INNER JOIN TCD.WasherGroup AS WG ON MS.GroupId = WG.WasherGroupId;
				
                    WITH CTE(
                            DateRange, 
                            TotalLoad, 
                            WasherEfficiency, 
                            PlantTargetLoad, 
                            StandardLoad, 
                            Numberofbatches, 
                            ActualRunTime, 
                            TargetRuntime, 
                            NumberofPieces, 
                            Rewash, 
                            WasherGroupId)
                        AS(SELECT   
				--SPD.MachineId,  
				WG.WasherGroupName,  
				SUM(SPD.ActualProduction),  
                                   CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18, 2)) / NULLIF(COALESCE(CAST(SUM(SPD.ActualProduction)
AS DECIMAL(18, 2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18, 2)), 0), 0) * COALESCE(CAST(SUM(SPD.TargetRunTime) AS DECIMAL(18, 2)) /
NULLIF(CAST(SUM(SPD.ActualRunTime) AS DECIMAL(18, 2)), 0), 0), 0), 0) AS DECIMAL(18, 2)), 
				SUM(SPD.PlantTargetProd),  
				SUM(SPD.StandardProduction),  
                                   SUM(NoOfLoads), 
                                   SUM(SPD.ShiftRunTime), 
                                   SUM(SPD.ShiftRunTime), 
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash),  
				WG.WasherGroupId  
                               FROM @Productionsummarytable AS SPD
                                    INNER JOIN TCD.MachineSetup AS MS ON SPD.MachineId = MS.WasherId
                                    INNER JOIN TCD.WasherGroup AS WG ON MS.GroupId = WG.WasherGroupId
                               GROUP BY
                                   WG.WasherGroupName, 
                                   WG.WasherGroupId, 
                                   SPD.ShiftId--,SPD.MachineId    
				)  
                        INSERT INTO @Resultset
				SELECT DISTINCT  
					0,  
					DateRange,  
					SUM(TotalLoad),  
					SUM(WasherEfficiency),  
                                SUM(PlantTargetLoad), 
					SUM(StandardLoad),  
					SUM(Numberofbatches),  
                                SUM(ActualRunTime), 
                                SUM(TargetRuntime), 
					SUM(NumberofPieces),  
                                SUM(Rewash), 
                                @Viewtype, 
                                @Subview, 
                                WasherGroupId, 
					0  
				FROM CTE  
					WHERE TotalLoad IS NOT NULL  
                            GROUP BY
                                DateRange, 
                                WasherGroupId;

			WITH CTE1
                        AS(SELECT
                                   SUM(ShiftRuntime) AS Shiftruntime, 
                                   ID FROM @Tableshiftruntime GROUP BY
                                   ID)

			--Update Shiftruntime in Temp table
                        UPDATE RS SET
                                RS.ActualRunTime = TS.Shiftruntime, 
                                RS.TargetRunTime = TS.Shiftruntime
                            FROM @Resultset RS
                                 LEFT OUTER JOIN CTE1 TS ON RS.Id = TS.ID;
						
                END;
  
            IF @Subview = 10 --Washer/machine view  
		BEGIN 
				
                    INSERT INTO @Tableshiftruntime(
                            ShiftID, 
                            ShiftRuntime, 
                            Name)
                    SELECT DISTINCT
                            SPD.ShiftId, 
			SPD.ShiftRunTime AS ShiftRuntime,         
                            CAST(W.PlantWasherNumber AS VARCHAR(20)) + ':' + MS.MachineName AS MachineName
                        FROM @Productionsummarytable AS SPD
                             INNER JOIN TCD.MachineSetup AS MS ON SPD.MachineId = MS.WasherId
                             INNER JOIN TCD.Washer AS w ON MS.WasherId = w.WasherId
                             INNER JOIN TCD.WasherGroup AS WG ON MS.GroupId = WG.WasherGroupId
                        WHERE CASE @Drillvalue
				WHEN '' THEN 'TRUE'           
                                  ELSE CASE
                                           WHEN WG.WasherGroupId IN(@Drillvalue) THEN 'TRUE'
                                       END
                              END = 'TRUE';				 
			  

			--SELECT * FROM @TableShiftruntime;
				 
                    WITH CTE(
                            DateRange, 
                            TotalLoad, 
                            WasherEfficiency, 
                            PlantTargetLoad, 
                            StandardLoad, 
                            Numberofbatches, 
                            ActualRunTime, 
                            TargetRuntime, 
                            NumberofPieces, 
                            Rewash)
                        AS(SELECT
                                   CAST(W.PlantWasherNumber AS VARCHAR(20)) + ':' + MS.MachineName AS MachineName, 
			SUM(SPD.ActualProduction),  
                                   CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18, 2)) / NULLIF(COALESCE(CAST(SUM(SPD.ActualProduction)
AS DECIMAL(18, 2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18, 2)), 0), 0) * COALESCE(CAST(SUM(SPD.TargetRunTime) AS DECIMAL(18, 2)) /
NULLIF(CAST(SUM(SPD.ActualRunTime) AS DECIMAL(18, 2)), 0), 0), 0), 0) AS DECIMAL(18, 2)), 
			SUM(SPD.PlantTargetProd),  
			SUM(SPD.StandardProduction),  
                                   SUM(NoOfLoads), 
                                   SUM(SPD.ShiftRunTime), 
                                   SUM(SPD.ShiftRunTime), 
			SUM(SPD.NoOfPieces),  
			SUM(SPD.Rewash)  
                               FROM @Productionsummarytable AS SPD
                                    INNER JOIN TCD.MachineSetup AS MS ON SPD.MachineId = MS.WasherId
                                    INNER JOIN TCD.Washer AS w ON MS.WasherId = w.WasherId
                                    INNER JOIN TCD.WasherGroup AS WG ON MS.GroupId = WG.WasherGroupId
                               WHERE CASE @Drillvalue
				WHEN '' THEN 'TRUE'           
                                         ELSE CASE
                                                  WHEN WG.WasherGroupId IN(@Drillvalue) THEN 'TRUE'
                                              END
                                     END = 'TRUE'
                               GROUP BY
                                   CAST(W.PlantWasherNumber AS VARCHAR(20)) + ':' + MS.MachineName, 
                                   SPD.ShiftId)
  
                        INSERT INTO @Resultset
				SELECT DISTINCT  
				0,  
				DateRange,  
				SUM(TotalLoad),  
				SUM(WasherEfficiency),  
				SUM(PlantTargetLoad),  
				SUM(StandardLoad),  
                                SUM(Numberofbatches), 
                                SUM(ActualRunTime), 
                                SUM(TargetRuntime), 
				SUM(NumberofPieces),  
                                SUM(Rewash), 
                                @Viewtype, 
                                @Subview, 
                                0, 
                                0
			FROM CTE  
				WHERE TotalLoad IS NOT NULL  
                            GROUP BY
                                DateRange;

			WITH CTE1
                        AS(SELECT
                                   SUM(ShiftRuntime) AS Shiftruntime, 
                                   Name FROM @Tableshiftruntime GROUP BY
                                   Name)				
			--Update Shiftruntime in Temp table
                        UPDATE RS SET
                                RS.ActualRunTime = TS.Shiftruntime, 
                                RS.TargetRunTime = TS.Shiftruntime
                            FROM @Resultset RS
                                 LEFT OUTER JOIN CTE1 TS ON RS.DateRange = TS.Name;
				   
                END;
        END;
  		 
    IF @Viewtype = 5 --ChainCategory View  
	 BEGIN  
            IF @Subview = 16
	  BEGIN  
		 -- ToDo : Change this part for chaincategory  
                    WITH CTE(
                            DateRange, 
                            TotalLoad, 
                            WasherEfficiency, 
                            PlantTargetLoad, 
                            StandardLoad, 
                            Numberofbatches, 
                            ActualRunTime, 
                            TargetRuntime, 
                            NumberofPieces, 
                            Rewash, 
                            textileId)
                        AS(SELECT
	   CC.NAME,  
	   SUM(SPD.ActualProduction),  
                                   COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(LoadEfficiency) * SUM(SPD.TimeEfficiency), 0), 0), 
                                   SUM(SPD.PlantTargetProd), 
	   SUM(SPD.StandardProduction),  
                                   SUM(NoOfLoads), 
                                   SUM(SPD.ShiftRunTime), 
                                   SUM(SPD.ShiftRunTime), 
	   SUM(SPD.NoOfPieces),  
	   SUM(SPD.Rewash),  
	   cc.TextileId  
                               FROM @Productionsummarytable AS SPD
                                    INNER JOIN TCD.ProgramMaster AS PM ON SPD.ProgramMasterId = PM.ProgramId
                                    INNER JOIN TCD.PlantChainProgram AS PCP ON PCP.PlantProgramId = PM.PlantProgramId
                                    INNER JOIN TCD.ChainTextileCategory AS CC ON CC.TextileId = PM.ChainTextileId
                               GROUP BY
                                   CC.Name, 
                                   cc.TextileId, 
                                   SPD.ShiftId)
                        INSERT INTO @Resultset
		 SELECT DISTINCT  
		  0,  
		  DateRange,  
		  SUM(TotalLoad),  
		  SUM(WasherEfficiency),  
		  SUM(PlantTargetLoad),  
		  SUM(StandardLoad),  
		  SUM(Numberofbatches),  
		  SUM(ActualRunTime),  
		  SUM(TargetRuntime),  
		  SUM(NumberofPieces),  
                                SUM(Rewash), 
                                @Viewtype, 
                                @Subview, 
                                textileId, 
                                0
		FROM CTE  
		 WHERE TotalLoad IS NOT NULL  
                            GROUP BY
                                DateRange, 
                                textileId;
                END;
      
            IF @Subview = 19
	  BEGIN  
	   -- ToDo : Change this part for chaincategory  
                    WITH CTE(
                            DateRange, 
                            TotalLoad, 
                            WasherEfficiency, 
                            PlantTargetLoad, 
                            StandardLoad, 
                            Numberofbatches, 
                            ActualRunTime, 
                            TargetRuntime, 
                            NumberofPieces, 
                            Rewash)
                        AS(SELECT
	   PCP.PlantProgramName,  
	   SUM(SPD.ActualProduction),  
                                   COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(LoadEfficiency) * SUM(SPD.TimeEfficiency), 0), 0), 
	   SUM(SPD.PlantTargetProd),  
	   SUM(SPD.StandardProduction),  
                                   SUM(NoOfLoads), 
                                   SUM(SPD.ShiftRunTime), 
                                   SUM(SPD.ShiftRunTime), 
	   SUM(SPD.NoOfPieces),  
	   SUM(SPD.Rewash)  
                               FROM @Productionsummarytable AS SPD
                                    INNER JOIN TCD.ProgramMaster AS PM ON SPD.ProgramMasterId = PM.ProgramId
                                    INNER JOIN TCD.PlantChainProgram AS PCP ON PCP.PlantProgramId = PM.PlantProgramId
                                    INNER JOIN TCD.ChainTextileCategory AS CC ON CC.TextileId = PM.ChainTextileId
                               WHERE CASE @Drillvalue
		  WHEN '' THEN 'TRUE'           
                                         ELSE CASE
                                                  WHEN CC.TextileId IN(@Drillvalue) THEN 'TRUE'
                                              END
                                     END = 'TRUE'
                               GROUP BY
                                   PCP.PlantProgramName, 
                                   PCP.PlantProgramId, 
                                   SPD.ShiftId)
                        INSERT INTO @Resultset
		 SELECT DISTINCT  
		  0,  
		  DateRange,  
		  SUM(TotalLoad),  
		  SUM(WasherEfficiency),  
		  SUM(PlantTargetLoad),  
		  SUM(StandardLoad),  
		  SUM(Numberofbatches),  
		  SUM(ActualRunTime),  
		  SUM(TargetRuntime),  
		  SUM(NumberofPieces),  
                                SUM(Rewash), 
                                @Viewtype, 
                                @Subview, 
                                0, 
                                0
		FROM CTE  
		 WHERE TotalLoad IS NOT NULL  
                            GROUP BY
                                DateRange;
                END;
  
        END;
  		
    IF @Viewtype = 6 --Customer View  
		 BEGIN 
            INSERT INTO @Tableshiftruntime(
                    ShiftID, 
                    ShiftRuntime, 
                    Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			PC.CustomerName  
                FROM @Productionsummarytable AS SPD
                     INNER JOIN TCD.PlantCustomer AS PC ON PC.CustomerId = SPD.CustomerId;

            WITH CTE(
                    DateRange, 
                    TotalLoad, 
                    WasherEfficiency, 
                    PlantTargetLoad, 
                    StandardLoad, 
                    Numberofbatches, 
                    ActualRunTime, 
                    TargetRuntime, 
                    NumberofPieces, 
                    Rewash)
                AS(SELECT
				PC.CustomerName,  
				SUM(SPD.ActualProduction),  
                           COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(LoadEfficiency) * SUM(SPD.TimeEfficiency), 0), 0), 
                           SUM(SPD.PlantTargetProd), 
				SUM(SPD.StandardProduction),  
                           SUM(NoOfLoads), 
                           SUM(SPD.ShiftRunTime), 
                           SUM(SPD.ShiftRunTime), 
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash)  
                       FROM @Productionsummarytable AS SPD
                            INNER JOIN TCD.PlantCustomer AS PC ON PC.CustomerId = SPD.CustomerId
				GROUP BY   
                           PC.CustomerName, 
                           SPD.ShiftId)
                INSERT INTO @Resultset
			SELECT DISTINCT  
			0,  
			DateRange,  
			SUM(TotalLoad),  
			SUM(WasherEfficiency),  
			SUM(PlantTargetLoad),  
			SUM(StandardLoad),  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime),  
			SUM(NumberofPieces),  
                        SUM(Rewash), 
                        @Viewtype, 
                        @Subview, 
                        0, 
                        0
			FROM CTE  
			WHERE TotalLoad IS NOT NULL  
                    GROUP BY
                        DateRange;
			
			WITH CTE1
                AS(SELECT
                           SUM(ShiftRuntime) AS Shiftruntime, 
                           Name FROM @Tableshiftruntime GROUP BY
                           Name)

					--Update Shiftruntime in Temp table
                UPDATE RS SET
                        RS.ActualRunTime = TS.Shiftruntime, 
                        RS.TargetRunTime = TS.Shiftruntime
                    FROM @Resultset RS
                         LEFT OUTER JOIN CTE1 TS ON RS.DateRange = TS.Name;

        END;
  	  
    IF @Viewtype = 7 --Formula View 
	 BEGIN  
            WITH CTE(
                    DateRange, 
                    TotalLoad, 
                    WasherEfficiency, 
                    PlantTargetLoad, 
                    StandardLoad, 
                    Numberofbatches, 
                    ActualRunTime, 
                    TargetRuntime, 
                    NumberofPieces, 
                    Rewash)
                AS(SELECT
	   PM.Name,  
	   SUM(SPD.ActualProduction),  
                           COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(LoadEfficiency) * SUM(SPD.TimeEfficiency), 0), 0), 
	   SUM(SPD.PlantTargetProd),  
	   SUM(SPD.StandardProduction),  
                           SUM(NoOfLoads), 
                           SUM(SPD.ShiftRunTime), 
                           SUM(SPD.ShiftRunTime), 
	   SUM(SPD.NoOfPieces),  
	   SUM(SPD.Rewash)  
                       FROM @Productionsummarytable AS SPD
                            INNER JOIN TCD.ProgramMaster AS PM ON SPD.ProgramMasterId = PM.ProgramId
                       GROUP BY
                           PM.Name, 
                           SPD.ShiftId)
                INSERT INTO @Resultset
		 SELECT DISTINCT  
		  0,  
		  DateRange,  
		  SUM(TotalLoad),  
		  SUM(WasherEfficiency),  
		  SUM(PlantTargetLoad),  
		  SUM(StandardLoad),  
		  SUM(Numberofbatches),  
		  SUM(ActualRunTime),  
		  SUM(TargetRuntime),  
		  SUM(NumberofPieces),  
                        SUM(Rewash), 
                        @Viewtype, 
                        @Subview, 
                        0, 
                        0
		FROM CTE  
		 WHERE TotalLoad IS NOT NULL  
                    GROUP BY
                        DateRange;
        END;
  	  	
    IF @Viewtype = 8 --Formula segmentView 
	 BEGIN  
            IF @Subview = 20-- Formula Segment  
		BEGIN 
					
                    INSERT INTO @Tableshiftruntime(
                            ShiftID, 
                            ShiftRuntime, 
                            Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			FS.SegmentName    
                        FROM @Productionsummarytable AS SPD
                             INNER JOIN TCD.ProgramMaster AS PM ON SPD.ProgramMasterId = PM.ProgramId
                             INNER JOIN TCD.FormulaSegments AS FS ON FS.FormulaSegmentID = SPD.FormulaSegmentID;
					
                    WITH CTE(
                            DateRange, 
                            TotalLoad, 
                            WasherEfficiency, 
                            PlantTargetLoad, 
                            StandardLoad, 
                            Numberofbatches, 
                            ActualRunTime, 
                            TargetRuntime, 
                            NumberofPieces, 
                            Rewash, 
                            FormulaSegmentID)
                        AS(SELECT
				FS.SegmentName,  
				SUM(SPD.ActualProduction),  
                                   COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(LoadEfficiency) * SUM(SPD.TimeEfficiency), 0), 0), 
                                   SUM(SPD.PlantTargetProd), 
				SUM(SPD.StandardProduction),  
                                   SUM(NoOfLoads), 
				SUM(SPD.ShiftRunTime),  
                                   SUM(SPD.ShiftRunTime),  
				--SUM(SPD.IndividualShiftRunTime),
				--SUM(SPD.IndividualShiftRunTime),
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash),  
				SPD.FormulaSegmentID  
                               FROM @Productionsummarytable AS SPD
                                    INNER JOIN TCD.ProgramMaster AS PM ON SPD.ProgramMasterId = PM.ProgramId
                                    INNER JOIN TCD.FormulaSegments AS FS ON FS.FormulaSegmentID = SPD.FormulaSegmentID
                               GROUP BY
                                   SPD.FormulaSegmentID, 
                                   FS.SegmentName, 
                                   SPD.ShiftId)
                        INSERT INTO @Resultset(
			ShiftId,  
                                DateRange, 
                                TotalLoad, 
                                WasherEfficiency, 
                                PlantTargetLoad, 
                                StandardLoad, 
                                Numberofbatches, 
                                ActualRunTime, 
                                TargetRunTime, 
                                NumberofPieces, 
                                Rewash, 
                                Viewtype, 
                                Subview, 
                                Id, 
                                SortOrder)
			SELECT DISTINCT  
			0,  
			DateRange,  
			SUM(TotalLoad),  
			SUM(WasherEfficiency),  
			SUM(PlantTargetLoad),  
			SUM(StandardLoad),  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime),  
			SUM(NumberofPieces),  
                                SUM(Rewash), 
                                @Viewtype, 
                                @Subview, 
                                FormulaSegmentID, 
                                0
			FROM CTE  
			WHERE TotalLoad IS NOT NULL  
                            GROUP BY
                                DateRange, 
                                FormulaSegmentID;
			
			WITH CTE1
                        AS(SELECT
                                   SUM(ShiftRuntime) AS Shiftruntime, 
                                   Name FROM @Tableshiftruntime GROUP BY
                                   Name)

					--Update Shiftruntime in Temp table
                        UPDATE RS SET
                                RS.ActualRunTime = TS.Shiftruntime, 
                                RS.TargetRunTime = TS.Shiftruntime
                            FROM @Resultset RS
                                 LEFT OUTER JOIN CTE1 TS ON RS.DateRange = TS.Name;
			 
                END;
		
            IF @Subview = 21-- Formula Categories  
		BEGIN 
		  
                    INSERT INTO @Tableshiftruntime(
                            ShiftID, 
                            ShiftRuntime, 
                            Name)
                    SELECT DISTINCT
                            SPD.ShiftId, 
                            SPD.ShiftRunTime AS ShiftRuntime, 
                            EC.CategoryName
                        FROM @Productionsummarytable AS SPD
                             INNER JOIN TCD.EcolabTextileCategory AS EC ON EC.TextileId = SPD.EcolabTextileId
                        WHERE CASE
                                  WHEN @Drillvalue = '' THEN 'TRUE'
                                  WHEN @Drillvalue IS NULL THEN 'TRUE'
                                  ELSE CASE
                                           WHEN SPD.FormulaSegmentID IN(@Drillvalue) THEN 'TRUE'
                                       END
                              END = 'TRUE' --AND EC.CategoryName IS NOT NULL
			UNION ALL
                    SELECT DISTINCT
                            SPD.ShiftId, 
                            SPD.ShiftRunTime AS ShiftRuntime, 
                            CC.NAME
                        FROM @Productionsummarytable AS SPD --INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
			--INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = SPD.ChainProgaramId  
                             INNER JOIN TCD.ChainTextileCategory AS CC ON CC.TextileId = SPD.ChainTextileId
                        WHERE CASE
                                  WHEN @Drillvalue = '' THEN 'TRUE'
                                  WHEN @Drillvalue IS NULL THEN 'TRUE'
                                  ELSE CASE
                                           WHEN SPD.FormulaSegmentID IN(@Drillvalue) THEN 'TRUE'
                                       END
                              END = 'TRUE';
			  
                    WITH CTE(
                            DateRange, 
                            TotalLoad, 
                            WasherEfficiency, 
                            PlantTargetLoad, 
                            StandardLoad, 
                            Numberofbatches, 
                            ActualRunTime, 
                            TargetRuntime, 
                            NumberofPieces, 
                            Rewash, 
                            TextileId)
                        AS(
                        SELECT
                                EC.CategoryName, 
                                SUM(SPD.ActualProduction), 
                                COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(LoadEfficiency) * SUM(SPD.TimeEfficiency), 0), 0), 
                                SUM(SPD.PlantTargetProd), 
                                SUM(SPD.StandardProduction), 
                                SUM(NoOfLoads), 
                                SUM(SPD.ShiftRunTime), 
                                SUM(SPD.ShiftRunTime), 
                                SUM(SPD.NoOfPieces), 
                                SUM(SPD.Rewash), 
                                EC.TextileId--, SUM(SPD.ManualRewashLoad)
                            FROM @Productionsummarytable AS SPD
                                 INNER JOIN TCD.EcolabTextileCategory AS EC ON EC.TextileId = SPD.EcolabTextileId
                            WHERE CASE
                                      WHEN @Drillvalue = '' THEN 'TRUE'
                                      WHEN @Drillvalue IS NULL THEN 'TRUE'
                                      ELSE CASE
                                               WHEN SPD.FormulaSegmentID IN(@Drillvalue) THEN 'TRUE'
                                           END
                                  END = 'TRUE' --AND EC.CategoryName IS NOT NULL  
                            GROUP BY
                                EC.CategoryName, 
                                EC.TextileId, 
                                SPD.ShiftId
                        UNION ALL
                        SELECT
                                CC.NAME, 
                                SUM(SPD.ActualProduction), 
                                COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(LoadEfficiency) * SUM(SPD.TimeEfficiency), 0), 0), 
                                SUM(SPD.PlantTargetProd), 
                                SUM(SPD.StandardProduction), 
                                SUM(NoOfLoads), 
                                SUM(SPD.ShiftRunTime), 
                                SUM(SPD.ShiftRunTime), 
                                SUM(SPD.NoOfPieces), 
                                SUM(SPD.Rewash), 
                                1000 + cc.TextileId AS TextileId
                            FROM @Productionsummarytable AS SPD --INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
				--INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = SPD.ChainProgaramId  
                                 INNER JOIN TCD.ChainTextileCategory AS CC ON CC.TextileId = SPD.ChainTextileId
                            WHERE CASE
                                      WHEN @Drillvalue = '' THEN 'TRUE'
                                      WHEN @Drillvalue IS NULL THEN 'TRUE'
                                      ELSE CASE
                                               WHEN SPD.FormulaSegmentID IN(@Drillvalue) THEN 'TRUE'
                                           END
                                  END = 'TRUE'
                            GROUP BY
                                CC.Name, 
                                cc.TextileId, 
                                SPD.ShiftId)
                        INSERT INTO @Resultset(
				ShiftId,  
                                DateRange, 
                                TotalLoad, 
                                WasherEfficiency, 
                                PlantTargetLoad, 
                                StandardLoad, 
                                Numberofbatches, 
                                ActualRunTime, 
                                TargetRunTime, 
                                NumberofPieces, 
                                Rewash, 
                                Viewtype, 
                                Subview, 
                                Id, 
                                SortOrder)
				SELECT DISTINCT  
				0,  
				DateRange,  
				SUM(TotalLoad),  
				SUM(WasherEfficiency),  
				SUM(PlantTargetLoad),  
				SUM(StandardLoad),  
				SUM(Numberofbatches),  
				SUM(ActualRunTime),  
				SUM(TargetRuntime),  
				SUM(NumberofPieces),  
                                SUM(Rewash), 
                                @Viewtype, 
                                @Subview, 
                                TextileId, 
                                0
				FROM CTE  
				WHERE TotalLoad IS NOT NULL  
                            GROUP BY
                                DateRange, 
                                TextileId;
			
			WITH CTE1
                        AS(SELECT
                                   SUM(ShiftRuntime) AS Shiftruntime, 
                                   Name FROM @Tableshiftruntime GROUP BY
                                   Name)

					--Update Shiftruntime in Temp table
                        UPDATE RS SET
                                RS.ActualRunTime = TS.Shiftruntime, 
                                RS.TargetRunTime = TS.Shiftruntime
                            FROM @Resultset RS
                                 LEFT OUTER JOIN CTE1 TS ON RS.DateRange = TS.Name;

                END;
		
            IF @Subview = 22 --Formula  
		BEGIN  
			---Checking Drill value Ecolb/chain category
                    DECLARE @Chaincategorydrillvalue INT;
                    IF @Drillvalue > 1000
                        BEGIN
                            SET @Chaincategorydrillvalue = @Drillvalue - 1000;
                        END;
                    ELSE
                        BEGIN
                            IF @Drillvalue < 1000
                                BEGIN
                                    SET @Chaincategorydrillvalue = @Drillvalue + 1000;
                                END;
                        END;
			---End

                    INSERT INTO @Tableshiftruntime(
                            ShiftID, 
                            ShiftRuntime, 
                            Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			PM.Name    
                        FROM @Productionsummarytable AS SPD --INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId  
                             INNER JOIN TCD.ProgramMaster AS PM ON SPD.ProgramMasterId = PM.ProgramId
                        WHERE SPD.FormulaSegmentID IN(SELECT
                                                              FormulaSegment FROM @Formulasegmenttable)
                          AND CASE
                                  WHEN @Drillvalue = '' THEN 'TRUE'
                                  WHEN @Drillvalue IS NULL THEN 'TRUE'
                                  ELSE CASE
                                           WHEN SPD.EcolabTextileId IN(@Drillvalue) THEN 'TRUE'
                                       END
                              END = 'TRUE' --AND PM.NAME IS NOT NULL
			
			UNION
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			PM.Name    
                        FROM @Productionsummarytable AS SPD --INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId  
                             INNER JOIN TCD.ProgramMaster AS PM ON SPD.ProgramMasterId = PM.ProgramId
                        WHERE SPD.FormulaSegmentID IN(SELECT
                                                              FormulaSegment FROM @Formulasegmenttable)
                          AND CASE
                                  WHEN @Drillvalue = '' THEN 'TRUE'
                                  WHEN @Drillvalue IS NULL THEN 'TRUE'
                                  ELSE CASE
                                           WHEN SPD.ChainTextileId IN(@Chaincategorydrillvalue) THEN 'TRUE'
                                       END
                              END = 'TRUE';

                    WITH CTE(
                            DateRange, 
                            TotalLoad, 
                            WasherEfficiency, 
                            PlantTargetLoad, 
                            StandardLoad, 
                            Numberofbatches, 
                            ActualRunTime, 
                            TargetRuntime, 
                            NumberofPieces, 
                            Rewash, 
                            ID)
                        AS(
                        SELECT
                                PM.Name, 
                                SUM(SPD.ActualProduction), 
                                COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(LoadEfficiency) * SUM(SPD.TimeEfficiency), 0), 0), 
                                SUM(SPD.PlantTargetProd), 
                                SUM(SPD.StandardProduction), 
                                SUM(NoOfLoads), 
                                SUM(SPD.ShiftRunTime), 
                                SUM(SPD.ShiftRunTime), 
                                SUM(SPD.NoOfPieces), 
                                SUM(SPD.Rewash), 
                                PM.ProgramId
                            FROM @Productionsummarytable AS SPD --INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId  
                                 INNER JOIN TCD.ProgramMaster AS PM ON SPD.ProgramMasterId = PM.ProgramId
                            WHERE SPD.FormulaSegmentID IN(SELECT
                                                                  FormulaSegment FROM @Formulasegmenttable)
                              AND CASE
                                      WHEN @Drillvalue = '' THEN 'TRUE'
                                      WHEN @Drillvalue IS NULL THEN 'TRUE'
                                      ELSE CASE
                                               WHEN SPD.EcolabTextileId IN(@Drillvalue) THEN 'TRUE'
                                           END
                                  END = 'TRUE' --AND PM.NAME IS NOT NULL 
                            GROUP BY
                                PM.Name, 
                                PM.ProgramId--,SPD.ShiftId 
  
				UNION   
                        SELECT
                                PM.Name, 
                                SUM(SPD.ActualProduction), 
                                COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(LoadEfficiency) * SUM(SPD.TimeEfficiency), 0), 0), 
                                SUM(SPD.PlantTargetProd), 
                                SUM(SPD.StandardProduction), 
                                SUM(NoOfLoads), 
                                SUM(SPD.ShiftRunTime), 
                                SUM(SPD.ShiftRunTime), 
                                SUM(SPD.NoOfPieces), 
                                SUM(SPD.Rewash), 
                                PM.ProgramId
                            FROM @Productionsummarytable AS SPD --INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId  
                                 INNER JOIN TCD.ProgramMaster AS PM ON SPD.ProgramMasterId = PM.ProgramId
                            WHERE SPD.FormulaSegmentID IN(SELECT
                                                                  FormulaSegment FROM @Formulasegmenttable)
                              AND CASE
                                      WHEN @Drillvalue = '' THEN 'TRUE'
                                      WHEN @Drillvalue IS NULL THEN 'TRUE'
                                      ELSE CASE
                                               WHEN SPD.ChainTextileId IN(@Chaincategorydrillvalue) THEN 'TRUE'
                                           END
                                  END = 'TRUE'
                            GROUP BY
                                PM.Name, 
                                PM.ProgramId--,SPD.ShiftId    
			)  
  
                        INSERT INTO @Resultset(
                                ShiftId, 
                                DateRange, 
                                TotalLoad, 
                                WasherEfficiency, 
                                PlantTargetLoad, 
                                StandardLoad, 
                                Numberofbatches, 
                                ActualRunTime, 
                                TargetRunTime, 
                                NumberofPieces, 
                                Rewash, 
                                Viewtype, 
                                Subview, 
                                Id)
                        SELECT DISTINCT
                                0, 
                                DateRange, 
                                SUM(TotalLoad), 
                                SUM(WasherEfficiency), 
                                SUM(PlantTargetLoad), 
                                SUM(StandardLoad), 
                                SUM(Numberofbatches), 
                                SUM(ActualRunTime), 
                                SUM(TargetRuntime), 
                                SUM(NumberofPieces), 
                                SUM(Rewash), 
                                @Viewtype, 
                                @Subview, 
                                ID
			FROM CTE  
			WHERE TotalLoad IS NOT NULL  
                            GROUP BY
                                DateRange, 
                                ID;
			
			WITH CTE1
                        AS(SELECT
                                   SUM(ShiftRuntime) AS Shiftruntime, 
                                   Name FROM @Tableshiftruntime GROUP BY
                                   Name)

					--Update Shiftruntime in Temp table
                        UPDATE RS SET
                                RS.ActualRunTime = TS.Shiftruntime, 
                                RS.TargetRunTime = TS.Shiftruntime
                            FROM @Resultset RS
                                 LEFT OUTER JOIN CTE1 TS ON RS.DateRange = TS.Name;

                END;
        END;


    DECLARE @Maxshiftruntime DECIMAL(30, 10) = NULL;
    IF @Viewtype IN(2, 8) --for Location and Formula, shift hours will be total shifthours for particular duration
        BEGIN
            IF @Subview IN(9, 10, 20, 21, 22)
	BEGIN		
                    SELECT
                            @Maxshiftruntime = SUM(A.Shiftruntime)
                        FROM(SELECT DISTINCT
                                     ShiftID AS ShiftID, 
                                     MAX(ShiftRuntime) AS Shiftruntime
                                 FROM @Tableshiftruntime
                                 GROUP BY
                                     ShiftID) AS A;
                END;
        END;
    ELSE
		 BEGIN
            IF @Viewtype IN(1)
	BEGIN
                    SELECT
                            @Maxshiftruntime = (SELECT
                                                        SUM(ShiftRuntime) AS Shiftruntime FROM @Tableshiftruntime);
                END;
        END;
	

	--- ********* Return result ********************  
  
    SELECT DISTINCT
            ShiftId, 
            DateRange, 
            ISNULL(TCD.FnConsumptionOnMetrics(TotalLoad, 'Weight', @Userid), 0) AS TotalLoad, 
            ISNULL(TCD.FnConsumptionOnMetrics(WasherEfficiency, 'Weight', @Userid), 0) AS Washerefficiency, 
            ISNULL(TCD.FnConsumptionOnMetrics(PlantTargetLoad, 'Weight', @Userid), 0) AS PlantTargetLoad, 
            ISNULL(TCD.FnConsumptionOnMetrics(StandardLoad, 'Weight', @Userid), 0) AS StandardLoad, 
            ISNULL(Numberofbatches, 0) AS NumberofBatches, 
            ISNULL(ActualRunTime, 0) AS ShiftRuntime, 
            ISNULL(TargetRunTime, 0) AS TargetRuntime, 
            ISNULL(NumberofPieces, 0) AS NoofPieces,  
		  --ISNULL(Rewash,0) AS Rewash,
            ISNULL(TCD.FnConsumptionOnMetrics(Rewash, 'Weight', @Userid), 0) AS Rewash, 
            Viewtype, 
            Subview, 
            Id, 
            @Correctionvariable AS CorrectionVariable, 
            @Maxshiftruntime AS Maxshiftruntime, 
            SortOrder, 
            @Loadefficiencymaxcap AS LoadEfficiencyMaxCap--, 
		--  @MaxShiftruntime1 AS MaxShiftruntime1, @noofShifts AS NoOfshifts  
        FROM @Resultset;
  
  
   
    SET NOCOUNT OFF;
END;  
GO
--------------END :: 164626:::Reports --> Reports to include Manual Input Rewash Loads------------------------------------------------------
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[ConduitControllerAuditTrigger]')
				AND type IN(N'TR'))
	BEGIN
		DROP TRIGGER
                TCD.ConduitControllerAuditTrigger;
	END;
GO
CREATE TRIGGER TCD.ConduitControllerAuditTrigger ON TCD.ConduitController
    FOR INSERT, UPDATE
AS
BEGIN

    SET NOCOUNT ON;

    DECLARE @Auditoperation_Sqlinsertid TINYINT = NULL, 
            @Auditoperation_Sqlupdateid TINYINT = NULL, 
            @Auditoperation_Appdeleteid TINYINT = NULL,                        
            @Softdeleteflag BIT = NULL, 
            @Currenttimestamp DATETIME = GETUTCDATE(), 
            @Controllermodelid INT = NULL;

    SELECT
            @Auditoperation_Sqlinsertid = AO.OperationId
        FROM TCD.AuditOperation AS AO
        WHERE AO.OperationCode = 'SQLInsert';

    SELECT
            @Auditoperation_Sqlupdateid = AO.OperationId
        FROM TCD.AuditOperation AS AO
        WHERE AO.OperationCode = 'SQLUpdate';

    SELECT
            @Auditoperation_Appdeleteid = AO.OperationId
        FROM TCD.AuditOperation AS AO
        WHERE AO.OperationCode = 'AppDelete';

    IF NOT EXISTS(SELECT
                          1 FROM deleted)
        BEGIN
                INSERT TCD.ConduitControllerHistory(
                        ControllerId, 
                        OperationTimestamp, 
                        OperationId, 
                        OperationByUserId, 
                        EcoalabAccountNumber, 
                        ControllerModelId, 
                        Name, 
                        Description, 
                        LastConnectedTime, 
                        Active, 
                        ControllerNumber, 
                        ControllerTypeId, 
                        ControllerVersion, 
                        InstallDate, 
                        TopicName, 
                        IsDeleted, 
                        LastModifiedTime, 
                        LastSyncTime)
                SELECT
                        ControllerId, 
                        @Currenttimestamp, 
                        @Auditoperation_Sqlinsertid, 
                        LastModifiedByUserId, 
                        EcoalabAccountNumber, 
                        ControllerModelId, 
                        Name, 
                        Description, 
                        LastConnectedTime, 
                        Active, 
                        ControllerNumber, 
                        ControllerTypeId, 
                        ControllerVersion, 
                        InstallDate, 
                        TopicName, 
                        IsDeleted, 
                        LastModifiedTime, 
                        LastSyncTime
                    FROM inserted;            
        END;
    ELSE
        BEGIN
            IF EXISTS(SELECT
                              1 FROM inserted)
                BEGIN
                    IF UPDATE(IsDeleted)
                        BEGIN
                            SET @Softdeleteflag = 'TRUE';
                        END;
                    ELSE
                        BEGIN
                            SET @Softdeleteflag = 'FALSE';
                        END;

                    BEGIN
                            IF EXISTS(
                            SELECT
                                    ControllerId, 
                                    EcoalabAccountNumber, 
                                    ControllerModelId, 
                                    Name, 
                                    Description, 
                                    Active, 
                                    ControllerNumber, 
                                    ControllerTypeId, 
                                    ControllerVersion, 
                                    InstallDate, 
                                    TopicName, 
                                    IsDeleted, 
                                    LastModifiedTime, 
                                    LastSyncTime
                                FROM inserted
                            EXCEPT
                            SELECT
                                    ControllerId, 
                                    EcoalabAccountNumber, 
                                    ControllerModelId, 
                                    Name, 
                                    Description, 
                                    Active, 
                                    ControllerNumber, 
                                    ControllerTypeId, 
                                    ControllerVersion, 
                                    InstallDate, 
                                    TopicName, 
                                    IsDeleted, 
                                    LastModifiedTime, 
                                    LastSyncTime
                                FROM deleted)
                                BEGIN
                                    INSERT TCD.ConduitControllerHistory(
                                            ControllerId, 
                                            OperationTimestamp, 
                                            OperationId, 
                                            OperationByUserId, 
                                            EcoalabAccountNumber, 
                                            ControllerModelId, 
                                            Name, 
                                            Description, 
                                            LastConnectedTime, 
                                            Active, 
                                            ControllerNumber, 
                                            ControllerTypeId, 
                                            ControllerVersion, 
                                            InstallDate, 
                                            TopicName, 
                                            IsDeleted, 
                                            LastModifiedTime, 
                                            LastSyncTime)
                                    SELECT
                                            ControllerId, 
                                            @Currenttimestamp, 
                                            CASE
                                                WHEN @Softdeleteflag = 'FALSE' THEN @Auditoperation_Sqlupdateid
                                                WHEN @Softdeleteflag = 'TRUE' THEN @Auditoperation_Appdeleteid
                                            END, 
                                            LastModifiedByUserId, 
                                            EcoalabAccountNumber, 
                                            ControllerModelId, 
                                            Name, 
                                            Description, 
                                            LastConnectedTime, 
                                            Active, 
                                            ControllerNumber, 
                                            ControllerTypeId, 
                                            ControllerVersion, 
                                            InstallDate, 
                                            TopicName, 
                                            IsDeleted, 
                                            LastModifiedTime, 
                                            LastSyncTime
                                        FROM inserted;
                                END;                       
                    END;
                END;
        END;       
END;
GO
--------------------------------------------
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[ControllerEquipmentSetupAuditTrigger]')
				AND type IN(N'TR'))
	BEGIN
		DROP TRIGGER
                TCD.ControllerEquipmentSetupAuditTrigger;
	END;
GO

CREATE TRIGGER TCD.ControllerEquipmentSetupAuditTrigger ON TCD.ControllerEquipmentSetup
    FOR INSERT, UPDATE
AS
BEGIN

    SET NOCOUNT ON;

    DECLARE @Auditoperation_Sqlinsertid TINYINT = NULL, 
            @Auditoperation_Sqlupdateid TINYINT = NULL,                       
            @Currenttimestamp DATETIME = GETUTCDATE();	--CURRENT_TIMESTAMP
    SELECT
            @Auditoperation_Sqlinsertid = AO.OperationId
        FROM TCD.AuditOperation AS AO
        WHERE AO.OperationCode = 'SQLInsert';

    SELECT
            @Auditoperation_Sqlupdateid = AO.OperationId
        FROM TCD.AuditOperation AS AO
        WHERE AO.OperationCode = 'SQLUpdate';

    IF NOT EXISTS(SELECT
                          1 FROM deleted)
        BEGIN
                INSERT TCD.ControllerEquipmentSetupHistory(
                        ControllerEquipmentSetupId, 
                        OperationTimestamp, 
                        OperationId, 
                        OperationByUserId, 
                        EcoLabAccountNumber, 
                        ControllerId, 
                        ControllerEquipmentId, 
                        ControllerEquipmentTypeId, 
                        IsActive, 
                        ProductId, 
                        PumpCalibration, 
                        FlowMeterSwitchFlag, 
                        MaximumDosingTime, 
                        FlowSwitchTimeOut, 
                        KFactor, 
                        TunnelHold, 
                        FlowSwitchAlarm, 
                        FlowMeterAlarm, 
                        FlowMeterType, 
                        FlowAlarmDelay, 
                        FlowMeterPumpDelay, 
                        FlowMeterAlarmDelay, 
                        LfsChemicalName, 
                        ValveOutputAsTom, 
                        Concentration, 
                        Deadband, 
                        FlowSwitchnumber, 
                        FlowDetectorType, 
                        LastModifiedTime, 
                        LastSyncTime)
                SELECT
                        ControllerEquipmentSetupId, 
                        @Currenttimestamp, 
                        @Auditoperation_Sqlinsertid, 
                        LastModifiedByUserId, 
                        EcoLabAccountNumber, 
                        ControllerId, 
                        ControllerEquipmentId, 
                        ControllerEquipmentTypeId, 
                        IsActive, 
                        ProductId, 
                        PumpCalibration, 
                        FlowMeterSwitchFlag, 
                        MaximumDosingTime, 
                        FlowSwitchTimeOut, 
                        KFactor, 
                        TunnelHold, 
                        FlowSwitchAlarm, 
                        FlowMeterAlarm, 
                        FlowMeterType, 
                        FlowAlarmDelay, 
                        FlowMeterPumpDelay, 
                        FlowMeterAlarmDelay, 
                        LfsChemicalName, 
                        ValveOutputAsTom, 
                        Concentration, 
                        Deadband, 
                        FlowSwitchnumber, 
                        FlowDetectorType, 
                        LastModifiedTime, 
                        LastSyncTime
                    FROM inserted;

                IF NOT EXISTS(SELECT
                                      *
                                  FROM TCD.PLCDiscrepancyData AS PD
                                       INNER JOIN inserted AS I ON ParentEntityType = 1
                                                               AND EntityType = 2
                                                               AND PD.ParentEntityId = I.ControllerId
                                                               AND PD.EntityId = I.ControllerEquipmentSetupId)
                    BEGIN
                        INSERT TCD.PLCDiscrepancyData(
                                ParentEntityType, 
                                EntityType, 
                                ParentEntityId, 
                                EntityId, 
                                SyncFromCentral, 
                                ControllerId, 
                                SyncToPlc, 
                                CreatedUserId, 
                                LastModifiedUserId, 
                                LastModifiedTime)
                        SELECT
                                1, 
                                2, 
                                I.ControllerId, 
                                I.ControllerEquipmentSetupId, 
                                CASE
                                    WHEN I.LastModifiedByUserId = 0 THEN 1
                                    ELSE 0
                                END, 
                                I.ControllerId, 
                                0, 
                                I.LastModifiedByUserId, 
                                NULL, 
                                I.LastModifiedTime
                            FROM inserted AS I;
                    END;            
        END;
    ELSE
        BEGIN
            IF EXISTS(SELECT
                              1 FROM inserted)
                BEGIN
                    BEGIN
                            INSERT TCD.ControllerEquipmentSetupHistory(
                                    ControllerEquipmentSetupId, 
                                    OperationTimestamp, 
                                    OperationId, 
                                    OperationByUserId, 
                                    EcoLabAccountNumber, 
                                    ControllerId, 
                                    ControllerEquipmentId, 
                                    ControllerEquipmentTypeId, 
                                    IsActive, 
                                    ProductId, 
                                    PumpCalibration, 
                                    FlowMeterSwitchFlag, 
                                    MaximumDosingTime, 
                                    FlowSwitchTimeOut, 
                                    KFactor, 
                                    TunnelHold, 
                                    FlowSwitchAlarm, 
                                    FlowMeterAlarm, 
                                    FlowMeterType, 
                                    FlowAlarmDelay, 
                                    FlowMeterPumpDelay, 
                                    FlowMeterAlarmDelay, 
                                    LfsChemicalName, 
                                    FlowDetectorType, 
                                    ValveOutputAsTom, 
                                    Concentration, 
                                    Deadband, 
                                    FlowSwitchnumber, 
                                    LastModifiedTime, 
                                    LastSyncTime)
                            SELECT
                                    ControllerEquipmentSetupId, 
                                    @Currenttimestamp, 
                                    @Auditoperation_Sqlupdateid, 
                                    LastModifiedByUserId, 
                                    EcoLabAccountNumber, 
                                    ControllerId, 
                                    ControllerEquipmentId, 
                                    ControllerEquipmentTypeId, 
                                    IsActive, 
                                    ProductId, 
                                    PumpCalibration, 
                                    FlowMeterSwitchFlag, 
                                    MaximumDosingTime, 
                                    FlowSwitchTimeOut, 
                                    KFactor, 
                                    TunnelHold, 
                                    FlowSwitchAlarm, 
                                    FlowMeterAlarm, 
                                    FlowMeterType, 
                                    FlowAlarmDelay, 
                                    FlowMeterPumpDelay, 
                                    FlowMeterAlarmDelay, 
                                    LfsChemicalName, 
                                    FlowDetectorType, 
                                    ValveOutputAsTom, 
                                    Concentration, 
                                    Deadband, 
                                    FlowSwitchnumber, 
                                    LastModifiedTime, 
                                    LastSyncTime
                                FROM inserted;

                            IF NOT EXISTS(SELECT
                                                  *
                                              FROM TCD.PLCDiscrepancyData AS PD
                                                   INNER JOIN inserted AS I ON ParentEntityType = 1
                                                                           AND EntityType = 2
                                                                           AND PD.ParentEntityId = I.ControllerId
                                                                           AND PD.EntityId = I.ControllerEquipmentSetupId)
                                BEGIN
                                    INSERT TCD.PLCDiscrepancyData(
                                            ParentEntityType, 
                                            EntityType, 
                                            ParentEntityId, 
                                            EntityId, 
                                            SyncFromCentral, 
                                            ControllerId, 
                                            SyncToPlc, 
                                            CreatedUserId, 
                                            LastModifiedUserId, 
                                            LastModifiedTime)
                                    SELECT
                                            1, 
                                            2, 
                                            I.ControllerId, 
                                            I.ControllerEquipmentSetupId, 
                                            CASE
                                                WHEN I.LastModifiedByUserId = 0 THEN 1
                                                ELSE 0
                                            END, 
                                            I.ControllerId, 
                                            0, 
                                            I.LastModifiedByUserId, 
                                            NULL, 
                                            I.LastModifiedTime
                                        FROM inserted AS I;
                                END;
                            ELSE
                                BEGIN
                                    UPDATE TCD.PLCDiscrepancyData SET
                                            SyncFromCentral = CASE
                                                                  WHEN I.LastModifiedByUserId = 0 THEN 1
                                                                  ELSE 0
                                                              END, 
                                            LastModifiedUserId = I.LastModifiedByUserId, 
                                            LastModifiedTime = I.LastModifiedTime
                                        FROM(SELECT
                                                     * FROM inserted) AS I
                                        WHERE
                                            ParentEntityType = 1
                                        AND EntityType = 2
                                        AND ParentEntityId = I.ControllerId
                                        AND EntityId = I.ControllerEquipmentSetupId;
                                END;                        
                    END;
                END;
        END;
END;
GO
----------------------------------
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[MachineSetupAuditTrigger]')
				AND type IN(N'TR'))
	BEGIN
		DROP TRIGGER
                TCD.MachineSetupAuditTrigger;
	END;
GO
CREATE TRIGGER TCD.MachineSetupAuditTrigger ON TCD.MachineSetup
    FOR INSERT, UPDATE
AS
BEGIN

    SET NOCOUNT ON;

    DECLARE @Auditoperation_Sqlinsertid TINYINT = NULL, 
            @Auditoperation_Sqlupdateid TINYINT = NULL, 
            @Auditoperation_Appdeleteid TINYINT = NULL,             
            @Softdeleteflag BIT = NULL, --0 for FALSE/1 for TRUE
            @Currenttimestamp DATETIME = GETUTCDATE(), --CURRENT_TIMESTAMP
            @Controllerid INT = NULL;

    SELECT
            @Auditoperation_Sqlinsertid = AO.OperationId
        FROM TCD.AuditOperation AS AO
        WHERE AO.OperationCode = 'SQLInsert';

    SELECT
            @Auditoperation_Sqlupdateid = AO.OperationId
        FROM TCD.AuditOperation AS AO
        WHERE AO.OperationCode = 'SQLUpdate';

    SELECT
            @Auditoperation_Appdeleteid = AO.OperationId
        FROM TCD.AuditOperation AS AO
        WHERE AO.OperationCode = 'AppDelete';

    SELECT
            @Controllerid = ISNULL(ControllerId, 0) FROM INSERTED AS I;

    IF NOT EXISTS(SELECT
                          1 FROM deleted)
        BEGIN
                INSERT TCD.MachineSetupHistory(
                        WasherId, 
                        OperationTimestamp, 
                        OperationId, 
                        OperationByUserId, 
                        GroupId, 
                        MachineInternalId, 
                        EcoalabAccountNumber, 
                        ControllerId, 
                        ShiftId, 
                        MachineName, 
                        NumberOfComp, 
                        Ex_TimeStampEject, 
                        TurnAroundTime, 
                        Brand, 
                        Size, 
                        IsPony, 
                        IsTunnel, 
                        HasPress, 
                        IsDeleted)
                SELECT
                        WasherId, 
                        @Currenttimestamp, 
                        @Auditoperation_Sqlinsertid, 
                        LastModifiedByUserId, 
                        GroupId, 
                        MachineInternalId, 
                        EcoalabAccountNumber, 
                        ControllerId, 
                        ShiftId, 
                        MachineName, 
                        NumberOfComp, 
                        Ex_TimeStampEject, 
                        TurnAroundTime, 
                        Brand, 
                        Size, 
                        IsPony, 
                        IsTunnel, 
                        HasPress, 
                        IsDeleted
                    FROM inserted;

                IF NOT EXISTS(SELECT
                                      *
                                  FROM TCD.PLCDiscrepancyData AS PD
                                       INNER JOIN inserted AS I ON ParentEntityType = 3
                                                               AND EntityType = 4
                                                               AND PD.ParentEntityId = I.GroupId
                                                               AND PD.EntityId = I.WasherId)
               AND @Controllerid <> 0
                    BEGIN
                        INSERT TCD.PLCDiscrepancyData(
                                ParentEntityType, 
                                EntityType, 
                                ParentEntityId, 
                                EntityId, 
                                SyncFromCentral, 
                                ControllerId, 
                                SyncToPlc, 
                                CreatedUserId, 
                                LastModifiedUserId, 
                                LastModifiedTime)
                        SELECT
                                3, 
                                4, 
                                I.GroupId, 
                                I.WasherId, 
                                CASE
                                    WHEN I.LastModifiedByUserId = 0 THEN 1
                                    ELSE 0
                                END, 
                                I.ControllerId, 
                                0, 
                                I.LastModifiedByUserId, 
                                NULL, 
                                GETUTCDATE()
                            FROM inserted AS I;
                    END;            
        END;
    ELSE
        BEGIN
            IF EXISTS(SELECT
                              1 FROM inserted)
                BEGIN
                    IF UPDATE(IsDeleted)
                        BEGIN
                            SET @Softdeleteflag = 'TRUE';
                        END;
                    ELSE
                        BEGIN
                            SET @Softdeleteflag = 'FALSE';
                        END;

                    BEGIN
                            INSERT TCD.MachineSetupHistory(
                                    WasherId, 
                                    OperationTimestamp, 
                                    OperationId, 
                                    OperationByUserId, 
                                    GroupId, 
                                    MachineInternalId, 
                                    EcoalabAccountNumber, 
                                    ControllerId, 
                                    ShiftId, 
                                    MachineName, 
                                    NumberOfComp, 
                                    Ex_TimeStampEject, 
                                    TurnAroundTime, 
                                    Brand, 
                                    Size, 
                                    IsPony, 
                                    IsTunnel, 
                                    HasPress, 
                                    IsDeleted)
                            SELECT
                                    WasherId, 
                                    @Currenttimestamp, 
                                    CASE
                                        WHEN @Softdeleteflag = 'FALSE' THEN @Auditoperation_Sqlupdateid
                                        WHEN @Softdeleteflag = 'TRUE' THEN @Auditoperation_Appdeleteid
                                    END, 
                                    LastModifiedByUserId, 
                                    GroupId, 
                                    MachineInternalId, 
                                    EcoalabAccountNumber, 
                                    ControllerId, 
                                    ShiftId, 
                                    MachineName, 
                                    NumberOfComp, 
                                    Ex_TimeStampEject, 
                                    TurnAroundTime, 
                                    Brand, 
                                    Size, 
                                    IsPony, 
                                    IsTunnel, 
                                    HasPress, 
                                    IsDeleted
                                FROM inserted;

                            IF @Softdeleteflag = 'FALSE'
                                BEGIN

                                    IF NOT EXISTS(SELECT
                                                          *
                                                      FROM TCD.PLCDiscrepancyData AS PD
                                                           INNER JOIN inserted AS I ON ParentEntityType = 3
                                                                                   AND EntityType = 4
                                                                                   AND PD.ParentEntityId = I.GroupId
                                                                                   AND PD.EntityId = I.WasherId)
                                   AND @Controllerid <> 0
                                        BEGIN
                                            INSERT TCD.PLCDiscrepancyData(
                                                    ParentEntityType, 
                                                    EntityType, 
                                                    ParentEntityId, 
                                                    EntityId, 
                                                    SyncFromCentral, 
                                                    ControllerId, 
                                                    SyncToPlc, 
                                                    CreatedUserId, 
                                                    LastModifiedUserId, 
                                                    LastModifiedTime)
                                            SELECT
                                                    3, 
                                                    4, 
                                                    I.GroupId, 
                                                    I.WasherId, 
                                                    CASE
                                                        WHEN I.LastModifiedByUserId = 0 THEN 1
                                                        ELSE 0
                                                    END, 
                                                    I.ControllerId, 
                                                    0, 
                                                    I.LastModifiedByUserId, 
                                                    NULL, 
                                                    GETUTCDATE()
                                                FROM inserted AS I;
                                        END;
                                    ELSE
                                        BEGIN
                                            UPDATE TCD.PLCDiscrepancyData SET
                                                    SyncFromCentral = CASE
                                                                          WHEN I.LastModifiedByUserId = 0 THEN 1
                                                                          ELSE 0
                                                                      END, 
                                                    LastModifiedUserId = I.LastModifiedByUserId, 
                                                    LastModifiedTime = GETUTCDATE()
                                                FROM(SELECT
                                                             * FROM inserted) AS I
                                                WHERE
                                                    ParentEntityType = 3
                                                AND EntityType = 4
                                                AND ParentEntityId = I.GroupId
                                                AND EntityId = I.WasherId
                                                AND @Controllerid <> 0;
                                        END;
                                END;
                            ELSE
                                BEGIN
                                    DELETE TCD.PLCDiscrepancyData
                                        FROM TCD.PLCDiscrepancyData PD
                                             INNER JOIN(SELECT
                                                                * FROM inserted AS ins) AS I ON PD.ParentEntityType = 3
                                                                                            AND PD.EntityType = 4
                                                                                            AND PD.ParentEntityId = I.GroupId
                                                                                            AND PD.EntityId = I.WasherId;
                                END;                       
                    END;
                END;
        END;

    SET NOCOUNT OFF;

    RETURN;

END;
GO
------------------------------
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[MeterAuditTrigger]')
				AND type IN(N'TR'))
	BEGIN
		DROP TRIGGER
                TCD.MeterAuditTrigger;
	END;
GO
CREATE TRIGGER TCD.MeterAuditTrigger ON TCD.Meter
    FOR INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Auditoperation_Sqlinsertid TINYINT = NULL, 
            @Auditoperation_Sqlupdateid TINYINT = NULL, 
            @Auditoperation_Appdeleteid TINYINT = NULL,                        
            @Softdeleteflag BIT = NULL, --0 for FALSE/1 for TRUE
            @Currenttimestamp DATETIME = GETUTCDATE();	--CURRENT_TIMESTAMP    
    SELECT
            @Auditoperation_Sqlinsertid = AO.OperationId
        FROM TCD.AuditOperation AS AO
        WHERE AO.OperationCode = 'SQLInsert';
    SELECT
            @Auditoperation_Sqlupdateid = AO.OperationId
        FROM TCD.AuditOperation AS AO
        WHERE AO.OperationCode = 'SQLUpdate';
    SELECT
            @Auditoperation_Appdeleteid = AO.OperationId
        FROM TCD.AuditOperation AS AO
        WHERE AO.OperationCode = 'AppDelete';
    IF NOT EXISTS(SELECT
                          1 FROM deleted)
        BEGIN            
                INSERT INTO TCD.MeterHistory(
                        MeterId, 
                        OperationTimestamp, 
                        OperationId, 
                        OperationByUserId, 
                        Description, 
                        UtilityType, 
                        GroupId, 
                        EcolabAccountNumber, 
                        MaxValueLimit, 
                        MeterTickUnit, 
                        UsageFactor, 
                        ControllerID, 
                        Parent, 
                        Calibration, 
                        DigitalInputNumber, 
                        AllowManualentry, 
                        Is_deleted, 
                        MachineCompartment, 
                        Id, 
                        CWMeterId, 
                        LastSyncTime, 
                        IsPlant, 
                        IsPress, 
                        LastModifiedTime)
                SELECT
                        MeterId, 
                        @Currenttimestamp, 
                        @Auditoperation_Sqlinsertid, 
                        LastModifiedByUserId, 
                        Description, 
                        UtilityType, 
                        GroupId, 
                        EcolabAccountNumber, 
                        MaxValueLimit, 
                        MeterTickUnit, 
                        UsageFactor, 
                        ControllerID, 
                        Parent, 
                        Calibration, 
                        DigitalInputNumber, 
                        AllowManualentry, 
                        Is_deleted, 
                        MachineCompartment, 
                        Id, 
                        CWMeterId, 
                        LastSyncTime, 
                        IsPlant, 
                        IsPress, 
                        LastModifiedTime
                    FROM inserted;
                IF NOT EXISTS(SELECT
                                      *
                                  FROM TCD.PLCDiscrepancyData AS PD
                                       INNER JOIN inserted AS I ON ParentEntityType = 7
                                                               AND EntityType = 7
                                                               AND PD.ParentEntityId = I.MeterId
                                                               AND PD.EntityId = I.MeterId)
                    BEGIN
                        INSERT INTO TCD.PLCDiscrepancyData(
                                --PLCDiscrepancyDataId - this column value is auto-generated
                                ParentEntityType, 
                                EntityType, 
                                ParentEntityId, 
                                EntityId, 
                                SyncFromCentral, 
                                ControllerId, 
                                SyncToPlc, 
                                CreatedUserId, 
                                LastModifiedUserId, 
                                LastModifiedTime)
                        SELECT
                                7, 
                                7, 
                                I.MeterId, 
                                I.MeterId, 
                                CASE
                                    WHEN I.LastModifiedByUserId = 0 THEN 1
                                    ELSE 0
                                END, 
                                I.ControllerID, 
                                0, 
                                I.LastModifiedByUserId, 
                                NULL, 
                                I.LastModifiedTime
                            FROM inserted AS I;
                    END;            
        END;
    ELSE
        BEGIN
            IF EXISTS(SELECT
                              1 FROM inserted)
                BEGIN
                    IF UPDATE(Is_Deleted)
                        BEGIN
                            SET @Softdeleteflag = 'TRUE';
                        END;
                    ELSE
                        BEGIN
                            SET @Softdeleteflag = 'FALSE';
                        END;
                    BEGIN                        
                            INSERT INTO TCD.MeterHistory(
                                    MeterId, 
                                    OperationTimestamp, 
                                    OperationId, 
                                    OperationByUserId, 
                                    Description, 
                                    UtilityType, 
                                    GroupId, 
                                    EcolabAccountNumber, 
                                    MaxValueLimit, 
                                    MeterTickUnit, 
                                    UsageFactor, 
                                    ControllerID, 
                                    Parent, 
                                    Calibration, 
                                    DigitalInputNumber, 
                                    AllowManualentry, 
                                    Is_deleted, 
                                    MachineCompartment, 
                                    Id, 
                                    CWMeterId, 
                                    LastSyncTime, 
                                    IsPlant, 
                                    IsPress, 
                                    LastModifiedTime)
                            SELECT
                                    MeterId, 
                                    @Currenttimestamp, 
                                    CASE
                                        WHEN @Softdeleteflag = 'FALSE' THEN @Auditoperation_Sqlupdateid
                                        WHEN @Softdeleteflag = 'TRUE' THEN @Auditoperation_Appdeleteid
                                    END, 
                                    LastModifiedByUserId, 
                                    Description, 
                                    UtilityType, 
                                    GroupId, 
                                    EcolabAccountNumber, 
                                    MaxValueLimit, 
                                    MeterTickUnit, 
                                    UsageFactor, 
                                    ControllerID, 
                                    Parent, 
                                    Calibration, 
                                    DigitalInputNumber, 
                                    AllowManualentry, 
                                    Is_deleted, 
                                    MachineCompartment, 
                                    Id, 
                                    CWMeterId, 
                                    LastSyncTime, 
                                    IsPlant, 
                                    IsPress, 
                                    LastModifiedTime
                                FROM inserted;
                            IF @Softdeleteflag = 'FALSE'
                                BEGIN
                                    IF NOT EXISTS(SELECT
                                                          *
                                                      FROM TCD.PLCDiscrepancyData AS PD
                                                           INNER JOIN inserted AS I ON ParentEntityType = 7
                                                                                   AND EntityType = 7
                                                                                   AND PD.ParentEntityId = I.MeterId
                                                                                   AND PD.EntityId = I.MeterId)
                                        BEGIN
                                            INSERT INTO TCD.PLCDiscrepancyData(
                                                    --PLCDiscrepancyDataId - this column value is auto-generated
                                                    ParentEntityType, 
                                                    EntityType, 
                                                    ParentEntityId, 
                                                    EntityId, 
                                                    SyncFromCentral, 
                                                    ControllerId, 
                                                    SyncToPlc, 
                                                    CreatedUserId, 
                                                    LastModifiedUserId, 
                                                    LastModifiedTime)
                                            SELECT
                                                    7, 
                                                    7, 
                                                    I.MeterId, 
                                                    I.MeterId, 
                                                    CASE
                                                        WHEN I.LastModifiedByUserId = 0 THEN 1
                                                        ELSE 0
                                                    END, 
                                                    I.ControllerID, 
                                                    0, 
                                                    I.LastModifiedByUserId, 
                                                    NULL, 
                                                    I.LastModifiedTime
                                                FROM inserted AS I;
                                        END;
                                    ELSE
                                        BEGIN
                                            UPDATE TCD.PLCDiscrepancyData SET
                                                    SyncFromCentral = CASE
                                                                          WHEN I.LastModifiedByUserId = 0 THEN 1
                                                                          ELSE 0
                                                                      END, 
                                                    LastModifiedUserId = I.LastModifiedByUserId, 
                                                    LastModifiedTime = I.LastModifiedTime
                                                FROM(SELECT
                                                             * FROM inserted) AS I
                                                WHERE
                                                    ParentEntityType = 7
                                                AND EntityType = 7
                                                AND ParentEntityId = I.MeterId
                                                AND EntityId = I.MeterId;
                                        END;
                                END;
                            ELSE
                                BEGIN
                                    DELETE TCD.PLCDiscrepancyData
                                        FROM TCD.PLCDiscrepancyData PD
                                             INNER JOIN(SELECT
                                                                * FROM inserted AS ins) AS I ON PD.ParentEntityType = 7
                                                                                            AND PD.EntityType = 7
                                                                                            AND PD.ParentEntityId = I.MeterId
                                                                                            AND PD.EntityId = I.MeterId;
                                END;                        
                    END;
                END;
        END;    
END;
GO
--------------------------------------
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[SensorAuditTrigger]')
				AND type IN(N'TR'))
	BEGIN
		DROP TRIGGER
                TCD.SensorAuditTrigger;
	END;
GO
CREATE TRIGGER TCD.SensorAuditTrigger ON TCD.Sensor
    FOR INSERT, UPDATE
AS
BEGIN

    SET NOCOUNT ON;

    DECLARE @Auditoperation_Sqlinsertid TINYINT = NULL, 
            @Auditoperation_Sqlupdateid TINYINT = NULL, 
            @Auditoperation_Appdeleteid TINYINT = NULL,                         
            @Softdeleteflag BIT = NULL, --0 for FALSE/1 for TRUE
            @Currenttimestamp DATETIME = GETUTCDATE();
    SELECT
            @Auditoperation_Sqlinsertid = AO.OperationId
        FROM TCD.AuditOperation AS AO
        WHERE AO.OperationCode = 'SQLInsert';

    SELECT
            @Auditoperation_Sqlupdateid = AO.OperationId
        FROM TCD.AuditOperation AS AO
        WHERE AO.OperationCode = 'SQLUpdate';

    SELECT
            @Auditoperation_Appdeleteid = AO.OperationId
        FROM TCD.AuditOperation AS AO
        WHERE AO.OperationCode = 'AppDelete';

    IF NOT EXISTS(SELECT
                          1 FROM deleted)
        BEGIN            
                INSERT TCD.SensorHistory(
                        SensorId, 
                        OperationTimestamp, 
                        OperationId, 
                        OperationByUserId, 
                        Description, 
                        SensorType, 
                        GroupId, 
                        MachineCompartment, 
                        EcolabAccountNumber, 
                        ControllerID, 
                        OutputType, 
                        AnalogueInputNumber, 
                        ChemicalforChart, 
                        UOM, 
                        DashboardActualValue, 
                        Is_deleted, 
                        Id, 
                        Calibration20mA, 
                        LastModifiedTime, 
                        LastSyncTime)
                SELECT
                        SensorId, 
                        @Currenttimestamp, 
                        @Auditoperation_Sqlinsertid, 
                        LastModifiedByUserId, 
                        Description, 
                        SensorType, 
                        GroupId, 
                        MachineCompartment, 
                        EcolabAccountNumber, 
                        ControllerID, 
                        OutputType, 
                        AnalogueInputNumber, 
                        ChemicalforChart, 
                        UOM, 
                        DashboardActualValue, 
                        Is_deleted, 
                        Id, 
                        Calibration20mA, 
                        LastModifiedTime, 
                        LastSyncTime
                    FROM inserted;

                IF NOT EXISTS(SELECT
                                      *
                                  FROM TCD.PLCDiscrepancyData AS PD
                                       INNER JOIN inserted AS I ON ParentEntityType = 8
                                                               AND EntityType = 8
                                                               AND PD.ParentEntityId = I.SensorId
                                                               AND PD.EntityId = I.SensorId)
                    BEGIN
                        INSERT TCD.PLCDiscrepancyData(
                                ParentEntityType, 
                                EntityType, 
                                ParentEntityId, 
                                EntityId, 
                                SyncFromCentral, 
                                ControllerId, 
                                SyncToPlc, 
                                CreatedUserId, 
                                LastModifiedUserId, 
                                LastModifiedTime)
                        SELECT
                                8, 
                                8, 
                                I.SensorId, 
                                I.SensorId, 
                                CASE
                                    WHEN I.LastModifiedByUserId = 0 THEN 1
                                    ELSE 0
                                END, 
                                I.ControllerId, 
                                0, 
                                I.LastModifiedByUserId, 
                                NULL, 
                                I.LastModifiedTime
                            FROM inserted AS I;
                    END;            
        END;
    ELSE
        BEGIN
            IF EXISTS(SELECT
                              1 FROM inserted)
                BEGIN
                    IF UPDATE(Is_Deleted)
                        BEGIN
                            SET @Softdeleteflag = 'TRUE';
                        END;
                    ELSE
                        BEGIN
                            SET @Softdeleteflag = 'FALSE';
                        END;

                    BEGIN
                            INSERT TCD.SensorHistory(
                                    SensorId, 
                                    OperationTimestamp, 
                                    OperationId, 
                                    OperationByUserId, 
                                    Description, 
                                    SensorType, 
                                    GroupId, 
                                    MachineCompartment, 
                                    EcolabAccountNumber, 
                                    ControllerID, 
                                    OutputType, 
                                    AnalogueInputNumber, 
                                    ChemicalforChart, 
                                    UOM, 
                                    DashboardActualValue, 
                                    Is_deleted, 
                                    Id, 
                                    Calibration20mA, 
                                    LastModifiedTime, 
                                    LastSyncTime)
                            SELECT
                                    SensorId, 
                                    @Currenttimestamp, 
                                    CASE
                                        WHEN @Softdeleteflag = 'FALSE' THEN @Auditoperation_Sqlupdateid
                                        WHEN @Softdeleteflag = 'TRUE' THEN @Auditoperation_Appdeleteid
                                    END, 
                                    LastModifiedByUserId, 
                                    Description, 
                                    SensorType, 
                                    GroupId, 
                                    MachineCompartment, 
                                    EcolabAccountNumber, 
                                    ControllerID, 
                                    OutputType, 
                                    AnalogueInputNumber, 
                                    ChemicalforChart, 
                                    UOM, 
                                    DashboardActualValue, 
                                    Is_deleted, 
                                    Id, 
                                    Calibration20mA, 
                                    LastModifiedTime, 
                                    LastSyncTime
                                FROM inserted;

                            IF @Softdeleteflag = 'FALSE'
                                BEGIN
                                    IF NOT EXISTS(SELECT
                                                          *
                                                      FROM TCD.PLCDiscrepancyData AS PD
                                                           INNER JOIN inserted AS I ON ParentEntityType = 8
                                                                                   AND EntityType = 8
                                                                                   AND PD.ParentEntityId = I.SensorId
                                                                                   AND PD.EntityId = I.SensorId)
                                        BEGIN
                                            INSERT TCD.PLCDiscrepancyData(
                                                    ParentEntityType, 
                                                    EntityType, 
                                                    ParentEntityId, 
                                                    EntityId, 
                                                    SyncFromCentral, 
                                                    ControllerId, 
                                                    SyncToPlc, 
                                                    CreatedUserId, 
                                                    LastModifiedUserId, 
                                                    LastModifiedTime)
                                            SELECT
                                                    8, 
                                                    8, 
                                                    I.SensorId, 
                                                    I.SensorId, 
                                                    CASE
                                                        WHEN I.LastModifiedByUserId = 0 THEN 1
                                                        ELSE 0
                                                    END, 
                                                    I.ControllerId, 
                                                    0, 
                                                    I.LastModifiedByUserId, 
                                                    NULL, 
                                                    I.LastModifiedTime
                                                FROM inserted AS I;
                                        END;
                                    ELSE
                                        BEGIN
                                            UPDATE TCD.PLCDiscrepancyData SET
                                                    SyncFromCentral = CASE
                                                                          WHEN I.LastModifiedByUserId = 0 THEN 1
                                                                          ELSE 0
                                                                      END, 
                                                    LastModifiedUserId = I.LastModifiedByUserId, 
                                                    LastModifiedTime = I.LastModifiedTime
                                                FROM(SELECT
                                                             * FROM inserted) AS I
                                                WHERE
                                                    ParentEntityType = 8
                                                AND EntityType = 8
                                                AND ParentEntityId = I.SensorId
                                                AND EntityId = I.SensorId;
                                        END;
                                END;
                            ELSE
                                BEGIN
                                    DELETE TCD.PLCDiscrepancyData
                                        FROM TCD.PLCDiscrepancyData PD
                                             INNER JOIN(SELECT
                                                                * FROM inserted AS ins) AS I ON PD.ParentEntityType = 8
                                                                                            AND PD.EntityType = 8
                                                                                            AND PD.ParentEntityId = I.SensorId
                                                                                            AND PD.EntityId = I.SensorId;
                                END;                        
                    END;
                END;
        END;
END;
GO
--------------------------------------
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[WasherProgramSetupAuditTrigger]')
				AND type IN(N'TR'))
	BEGIN
		DROP TRIGGER
                TCD.WasherProgramSetupAuditTrigger;
	END;
GO
CREATE TRIGGER TCD.WasherProgramSetupAuditTrigger ON TCD.WasherProgramSetup
    FOR INSERT, UPDATE
AS
BEGIN

    SET NOCOUNT ON;

    DECLARE @Auditoperation_Sqlinsertid TINYINT = NULL, 
            @Auditoperation_Sqlupdateid TINYINT = NULL, 
            @Auditoperation_Appdeleteid TINYINT = NULL,             
            @Softdeleteflag BIT = NULL, --0 for FALSE/1 for TRUE
            @Currenttimestamp DATETIME = GETUTCDATE(), --CURRENT_TIMESTAMP
            @Washergroupid INT = NULL, 
            @Controllermodelid INT = NULL;
    SELECT
            @Auditoperation_Sqlinsertid = AO.OperationId
        FROM TCD.AuditOperation AS AO
        WHERE AO.OperationCode = 'SQLInsert';

    SELECT
            @Auditoperation_Sqlupdateid = AO.OperationId
        FROM TCD.AuditOperation AS AO
        WHERE AO.OperationCode = 'SQLUpdate';

    SELECT
            @Auditoperation_Appdeleteid = AO.OperationId
        FROM TCD.AuditOperation AS AO
        WHERE AO.OperationCode = 'AppDelete';

    SELECT TOP 1
            @Washergroupid = ISNULL(I.WasherGroupId, 0) FROM inserted AS I;

    SELECT
            @Controllermodelid = ControllerModelId
        FROM TCD.ConduitController AS cc
             INNER JOIN INSERTED AS I ON cc.ControllerId = I.ControllerID;

    IF NOT EXISTS(SELECT
                          1 FROM deleted)
        BEGIN
                INSERT TCD.WasherProgramSetupHistory(
                        WasherProgramSetupId, 
                        OperationTimestamp, 
                        OperationId, 
                        OperationByUserId, 
                        EcolabAccountNumber, 
                        WasherGroupId, 
                        ProgramNumber, 
                        ProgramId, 
                        NominalLoad, 
                        LoadsPerMonth, 
                        TotalRunTime, 
                        ExtraTime, 
                        Is_Deleted, 
                        TotalSteps, 
                        CoolDownStep, 
                        FinalExtractingTime, 
                        Category, 
                        CustomProgramName, 
                        PlantProgramNumber, 
                        NumberOfDrains, 
                        DrainTime, 
                        Rewash, 
                        MyServiceCustFrmulaMchGrpGUID, 
                        MyServiceLastSynchTime, 
                        ControllerID)
                SELECT
                        WasherProgramSetupId, 
                        @Currenttimestamp, 
                        @Auditoperation_Sqlinsertid, 
                        LastModifiedByUserId, 
                        EcolabAccountNumber, 
                        WasherGroupId, 
                        ProgramNumber, 
                        ProgramId, 
                        NominalLoad, 
                        LoadsPerMonth, 
                        TotalRunTime, 
                        ExtraTime, 
                        Is_Deleted, 
                        TotalSteps, 
                        CoolDownStep, 
                        FinalExtractingTime, 
                        Category, 
                        CustomProgramName, 
                        PlantProgramNumber, 
                        NumberOfDrains, 
                        DrainTime, 
                        Rewash, 
                        MyServiceCustFrmulaMchGrpGUID, 
                        MyServiceLastSynchTime, 
                        ControllerID
                    FROM inserted;

                IF EXISTS(SELECT
                                      1
                                  FROM INSERTED AS I
                                       INNER JOIN(SELECT
                                                          GroupId, 
                                                          Controllerid
                                                      FROM tcd.MachineSetup AS ms
                                                      WHERE groupid = @Washergroupid
                                                      GROUP BY
                                                          groupid, 
                                                          controllerid) AS A ON I.WasherGroupId = A.GroupId
                                       LEFT JOIN TCD.PLCDiscrepancyData AS pd ON pd.ParentEntityType = 3
                                                                             AND EntityType = 6
                                                                             AND PD.ParentEntityId = I.WasherGroupId
                                                                             AND PD.EntityId = I.WasherProgramSetupId
															  AND PD.ControllerId = A.ControllerId
                                  WHERE PD.ControllerId IS NULL)
               AND (@Controllermodelid IS NULL
                 OR @Controllermodelid != 7)
                    BEGIN
                        INSERT TCD.PLCDiscrepancyData(
                                ParentEntityType, 
                                EntityType, 
                                ParentEntityId, 
                                EntityId, 
                                SyncFromCentral, 
                                ControllerId, 
                                SyncToPlc, 
                                CreatedUserId, 
                                LastModifiedUserId, 
                                LastModifiedTime)
                        SELECT TOP 1
                                3, 
                                6, 
                                I.WasherGroupId, 
                                I.WasherProgramSetupId, 
                                CASE
                                    WHEN LastModifiedByUserId = 0 THEN 1
                                    ELSE 0
                                END, 
                                A.ControllerID, 
                                0, 
                                I.LastModifiedByUserId, 
                                NULL, 
                                I.LastModifiedTime
                            FROM INSERTED AS I
                                 INNER JOIN(SELECT
                                                    GroupId, 
                                                    Controllerid
                                                FROM tcd.MachineSetup AS ms
                                                WHERE groupid = @Washergroupid
                                                GROUP BY
                                                    groupid, 
                                                    controllerid) AS A ON I.WasherGroupId = A.GroupId
                                 LEFT JOIN TCD.PLCDiscrepancyData AS pd ON pd.ParentEntityType = 3
                                                                       AND EntityType = 6
                                                                       AND PD.ParentEntityId = I.WasherGroupId
                                                                       AND PD.EntityId = I.WasherProgramSetupId
														 AND PD.ControllerId = A.ControllerId
                            WHERE PD.ControllerId IS NULL;

                    END;            
        END;
    ELSE
        BEGIN
            IF EXISTS(SELECT
                              1 FROM inserted)
                BEGIN
                    IF UPDATE(Is_Deleted)
                        BEGIN
                            SET @Softdeleteflag = 'TRUE';
                        END;
                    ELSE
                        BEGIN
                            SET @Softdeleteflag = 'FALSE';
                        END;

                    BEGIN
                            INSERT TCD.WasherProgramSetupHistory(
                                    WasherProgramSetupId, 
                                    OperationTimestamp, 
                                    OperationId, 
                                    OperationByUserId, 
                                    EcolabAccountNumber, 
                                    WasherGroupId, 
                                    ProgramNumber, 
                                    ProgramId, 
                                    NominalLoad, 
                                    LoadsPerMonth, 
                                    TotalRunTime, 
                                    ExtraTime, 
                                    Is_Deleted, 
                                    TotalSteps, 
                                    CoolDownStep, 
                                    FinalExtractingTime, 
                                    Category, 
                                    CustomProgramName, 
                                    PlantProgramNumber, 
                                    NumberOfDrains, 
                                    DrainTime, 
                                    Rewash, 
                                    MyServiceCustFrmulaMchGrpGUID, 
                                    MyServiceLastSynchTime, 
                                    ControllerID)
                            SELECT
                                    WasherProgramSetupId, 
                                    @Currenttimestamp, 
                                    CASE
                                        WHEN @Softdeleteflag = 'FALSE' THEN @Auditoperation_Sqlupdateid
                                        WHEN @Softdeleteflag = 'TRUE' THEN @Auditoperation_Appdeleteid
                                    END, 
                                    LastModifiedByUserId, 
                                    EcolabAccountNumber, 
                                    WasherGroupId, 
                                    ProgramNumber, 
                                    ProgramId, 
                                    NominalLoad, 
                                    LoadsPerMonth, 
                                    TotalRunTime, 
                                    ExtraTime, 
                                    Is_Deleted, 
                                    TotalSteps, 
                                    CoolDownStep, 
                                    FinalExtractingTime, 
                                    Category, 
                                    CustomProgramName, 
                                    PlantProgramNumber, 
                                    NumberOfDrains, 
                                    DrainTime, 
                                    Rewash, 
                                    MyServiceCustFrmulaMchGrpGUID, 
                                    MyServiceLastSynchTime, 
                                    ControllerID
                                FROM inserted;

                            IF @Softdeleteflag = 'FALSE'
                                BEGIN
                                    IF EXISTS(SELECT
                                                          1
                                                      FROM INSERTED AS I
                                                           LEFT JOIN(SELECT
                                                                             GroupId, 
                                                                             Controllerid
                                                                         FROM tcd.MachineSetup AS ms
                                                                         WHERE groupid = @Washergroupid
                                                                         GROUP BY
                                                                             groupid, 
                                                                             controllerid) AS A ON I.WasherGroupId = A.GroupId
                                                           LEFT JOIN TCD.PLCDiscrepancyData AS pd ON pd.ParentEntityType = 3
                                                                                                 AND EntityType = 6
                                                                                                 AND PD.ParentEntityId = I.WasherGroupId
                                                                                                 AND PD.EntityId = I.WasherProgramSetupId
																			  AND PD.ControllerId = A.ControllerId
                                                      WHERE PD.ControllerId IS NULL)
                                   AND (@Controllermodelid IS NULL
                                     OR @Controllermodelid != 7)
                                        BEGIN
                                            INSERT TCD.PLCDiscrepancyData(
                                                    ParentEntityType, 
                                                    EntityType, 
                                                    ParentEntityId, 
                                                    EntityId, 
                                                    SyncFromCentral, 
                                                    ControllerId, 
                                                    SyncToPlc, 
                                                    CreatedUserId, 
                                                    LastModifiedUserId, 
                                                    LastModifiedTime)
                                            SELECT TOP 1
                                                    3, 
                                                    6, 
                                                    I.WasherGroupId, 
                                                    I.WasherProgramSetupId, 
                                                    CASE
                                                        WHEN LastModifiedByUserId = 0 THEN 1
                                                        ELSE 0
                                                    END, 
                                                    A.ControllerID, 
                                                    0, 
                                                    I.LastModifiedByUserId, 
                                                    NULL, 
                                                    I.LastModifiedTime
                                                FROM INSERTED AS I
                                                     LEFT JOIN(SELECT
                                                                       GroupId, 
                                                                       Controllerid
                                                                   FROM tcd.MachineSetup AS ms
                                                                   WHERE groupid = @Washergroupid
                                                                   GROUP BY
                                                                       groupid, 
                                                                       controllerid) AS A ON I.WasherGroupId = A.GroupId
                                                     LEFT JOIN TCD.PLCDiscrepancyData AS pd ON pd.ParentEntityType = 3
                                                                                           AND EntityType = 6
                                                                                           AND PD.ParentEntityId = I.WasherGroupId
                                                                                           AND PD.EntityId = I.WasherProgramSetupId
																		 AND PD.ControllerId = A.ControllerId
                                                WHERE PD.ControllerId IS NULL;

                                        END;
                                    ELSE
                                        BEGIN
                                            UPDATE TCD.PLCDiscrepancyData SET
                                                    SyncFromCentral = CASE
                                                                          WHEN I.LastModifiedByUserId = 0 THEN 1
                                                                          ELSE 0
                                                                      END, 
                                                    LastModifiedUserId = I.LastModifiedByUserId, 
                                                    LastModifiedTime = I.LastModifiedTime
                                                FROM(SELECT
                                                             * FROM inserted) AS I
                                                WHERE
                                                    ParentEntityType = 3
                                                AND EntityType = 6
                                                AND ParentEntityId = I.WasherGroupId
                                                AND EntityId = I.WasherProgramSetupId
                                                AND (@Controllermodelid IS NULL
                                                  OR @Controllermodelid != 7);
                                        END;
                                END;
                            ELSE
                                BEGIN
                                    DELETE TCD.PLCDiscrepancyData
                                        FROM TCD.PLCDiscrepancyData PD
                                             INNER JOIN(SELECT
                                                                * FROM inserted) AS I ON PD.ParentEntityType = 3
                                                                                     AND PD.EntityType = 6
                                                                                     AND PD.ParentEntityId = I.WasherGroupId
                                                                                     AND PD.EntityId = I.WasherProgramSetupId
                                                                                     AND PD.ControllerId = I.ControllerID;
                                END;                        
                    END;
                END;
        END;
END;
GO
--------------------------
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[TunnelProgramSetupAuditTrigger]')
				AND type IN(N'TR'))
	BEGIN
		DROP TRIGGER
                TCD.TunnelProgramSetupAuditTrigger;
	END;
GO
CREATE TRIGGER TCD.TunnelProgramSetupAuditTrigger ON TCD.TunnelProgramSetup
    FOR INSERT, UPDATE
AS
BEGIN

    SET NOCOUNT ON;

    DECLARE @Auditoperation_Sqlinsertid TINYINT = NULL, 
            @Auditoperation_Sqlupdateid TINYINT = NULL, 
            @Auditoperation_Appdeleteid TINYINT = NULL,                         
            @Softdeleteflag BIT = NULL, --0 for FALSE/1 for TRUE
            @Currenttimestamp DATETIME = GETUTCDATE(), --CURRENT_TIMESTAMP
            @Washergroupid INT,
		  @ControllerModelId INT,
		  @RegionId INT;
    SELECT
            @Auditoperation_Sqlinsertid = AO.OperationId
        FROM TCD.AuditOperation AS AO
        WHERE AO.OperationCode = 'SQLInsert';

    SELECT
            @Auditoperation_Sqlupdateid = AO.OperationId
        FROM TCD.AuditOperation AS AO
        WHERE AO.OperationCode = 'SQLUpdate';

    SELECT
            @Auditoperation_Appdeleteid = AO.OperationId
        FROM TCD.AuditOperation AS AO
        WHERE AO.OperationCode = 'AppDelete';
    SELECT TOP 1 @RegionId = p.RegionId FROM TCD.Plant p

    SELECT TOP 1
            @Washergroupid = I.WasherGroupId FROM inserted AS I;
    SELECT @ControllerModelId = cc.ControllerModelId FROM INSERTED AS I
                                 INNER JOIN(SELECT
                                                   GroupId, 
                                                   Controllerid
                                               FROM tcd.MachineSetup AS ms
                                               WHERE groupid = @Washergroupid
                                               GROUP BY
                                                   groupid, 
                                                   controllerid) AS A ON I.WasherGroupId = A.GroupId
						   INNER JOIN TCD.ConduitController cc ON cc.ControllerId = A.Controllerid
    IF NOT EXISTS(SELECT
                          1 FROM deleted)
        BEGIN
                INSERT TCD.TunnelProgramSetupHistory(
                        TunnelProgramSetupId, 
                        OperationTimestamp, 
                        OperationId, 
                        OperationByUserId, 
                        EcolabAccountNumber, 
                        WasherGroupId, 
                        ProgramNumber, 
                        Description, 
                        ProgramId, 
                        NominalLoad, 
                        LoadsPerMonth, 
                        TotalRunTime, 
                        ExtraTime, 
                        Is_Deleted, 
                        NumberOfDrains, 
                        DrainTime, 
                        MyServiceCustFrmulaMchGrpGUID, 
                        MyServiceLastSynchTime)
                SELECT
                        TunnelProgramSetupId, 
                        @Currenttimestamp, 
                        @Auditoperation_Sqlinsertid, 
                        LastModifiedByUserId, 
                        EcolabAccountNumber, 
                        WasherGroupId, 
                        ProgramNumber, 
                        Description, 
                        ProgramId, 
                        NominalLoad, 
                        LoadsPerMonth, 
                        TotalRunTime, 
                        ExtraTime, 
                        Is_Deleted, 
                        NumberOfDrains, 
                        DrainTime, 
                        MyServiceCustFrmulaMchGrpGUID, 
                        MyServiceLastSynchTime
                    FROM inserted;

                IF NOT EXISTS(SELECT
                                      *
                                  FROM TCD.PLCDiscrepancyData AS PD
                                       INNER JOIN inserted AS I ON ParentEntityType = 3
                                                               AND EntityType = 5
                                                               AND PD.ParentEntityId = I.WasherGroupId
                                                               AND PD.EntityId = I.TunnelProgramSetupId) AND (@RegionId = 2 OR @ControllerModelId = 7)
                    BEGIN
                        INSERT TCD.PLCDiscrepancyData(
                                ParentEntityType, 
                                EntityType, 
                                ParentEntityId, 
                                EntityId, 
                                SyncFromCentral, 
                                ControllerId, 
                                SyncToPlc, 
                                CreatedUserId, 
                                LastModifiedUserId, 
                                LastModifiedTime)
                        SELECT
                                3, 
                                5, 
                                I.WasherGroupId, 
                                I.TunnelProgramSetupId, 
                                CASE
                                    WHEN LastModifiedByUserId = 0 THEN 1
                                    ELSE 0
                                END, 
                                A.ControllerID, 
                                0, 
                                I.LastModifiedByUserId, 
                                NULL, 
                                I.LastModifiedTime
                            FROM INSERTED AS I
                                 LEFT JOIN(SELECT
                                                   GroupId, 
                                                   Controllerid
                                               FROM tcd.MachineSetup AS ms
                                               WHERE groupid = @Washergroupid
                                               GROUP BY
                                                   groupid, 
                                                   controllerid) AS A ON I.WasherGroupId = A.GroupId;

                    END;            
        END;
    ELSE
        BEGIN
            IF EXISTS(SELECT
                              1 FROM inserted)
                BEGIN
                    IF UPDATE(Is_Deleted)
                        BEGIN
                            SET @Softdeleteflag = 'TRUE';
                        END;
                    ELSE
                        BEGIN
                            SET @Softdeleteflag = 'FALSE';
                        END;

                    BEGIN
                            INSERT TCD.TunnelProgramSetupHistory(
                                    TunnelProgramSetupId, 
                                    OperationTimestamp, 
                                    OperationId, 
                                    OperationByUserId, 
                                    EcolabAccountNumber, 
                                    WasherGroupId, 
                                    ProgramNumber, 
                                    Description, 
                                    ProgramId, 
                                    NominalLoad, 
                                    LoadsPerMonth, 
                                    TotalRunTime, 
                                    ExtraTime, 
                                    Is_Deleted, 
                                    NumberOfDrains, 
                                    DrainTime, 
                                    MyServiceCustFrmulaMchGrpGUID, 
                                    MyServiceLastSynchTime)
                            SELECT
                                    TunnelProgramSetupId, 
                                    @Currenttimestamp, 
                                    CASE
                                        WHEN @Softdeleteflag = 'FALSE' THEN @Auditoperation_Sqlupdateid
                                        WHEN @Softdeleteflag = 'TRUE' THEN @Auditoperation_Appdeleteid
                                    END, 
                                    LastModifiedByUserId, 
                                    EcolabAccountNumber, 
                                    WasherGroupId, 
                                    ProgramNumber, 
                                    Description, 
                                    ProgramId, 
                                    NominalLoad, 
                                    LoadsPerMonth, 
                                    TotalRunTime, 
                                    ExtraTime, 
                                    Is_Deleted, 
                                    NumberOfDrains, 
                                    DrainTime, 
                                    MyServiceCustFrmulaMchGrpGUID, 
                                    MyServiceLastSynchTime
                                FROM inserted;

                            IF @Softdeleteflag = 'FALSE'
                                BEGIN
                                    IF NOT EXISTS(SELECT
                                                          *
                                                      FROM TCD.PLCDiscrepancyData AS PD
                                                           INNER JOIN inserted AS I ON ParentEntityType = 3
                                                                                   AND EntityType = 5
                                                                                   AND PD.ParentEntityId = I.WasherGroupId
                                                                                   AND PD.EntityId = I.TunnelProgramSetupId) AND (@RegionId = 2 OR @ControllerModelId = 7)
                                        BEGIN
                                            INSERT TCD.PLCDiscrepancyData(
                                                    ParentEntityType, 
                                                    EntityType, 
                                                    ParentEntityId, 
                                                    EntityId, 
                                                    SyncFromCentral, 
                                                    ControllerId, 
                                                    SyncToPlc, 
                                                    CreatedUserId, 
                                                    LastModifiedUserId, 
                                                    LastModifiedTime)
                                            SELECT
                                                    3, 
                                                    5, 
                                                    I.WasherGroupId, 
                                                    I.TunnelProgramSetupId, 
                                                    CASE
                                                        WHEN LastModifiedByUserId = 0 THEN 1
                                                        ELSE 0
                                                    END, 
                                                    A.ControllerID, 
                                                    0, 
                                                    I.LastModifiedByUserId, 
                                                    NULL, 
                                                    I.LastModifiedTime
                                                FROM INSERTED AS I
                                                     LEFT JOIN(SELECT
                                                                       GroupId, 
                                                                       Controllerid
                                                                   FROM tcd.MachineSetup AS ms
                                                                   WHERE groupid = @Washergroupid
                                                                   GROUP BY
                                                                       groupid, 
                                                                       controllerid) AS A ON I.WasherGroupId = A.GroupId;

                                        END;
                                    ELSE
                                        BEGIN
								    IF(@RegionId = 2 OR @ControllerModelId = 7)
								    BEGIN
									   UPDATE TCD.PLCDiscrepancyData SET
											 SyncFromCentral = CASE
															   WHEN I.LastModifiedByUserId = 0 THEN 1
															   ELSE 0
														    END, 
											 LastModifiedUserId = I.LastModifiedByUserId, 
											 LastModifiedTime = I.LastModifiedTime
										  FROM(SELECT
													* FROM inserted) AS I
										  WHERE
											 ParentEntityType = 3
										  AND EntityType = 5
										  AND ParentEntityId = I.WasherGroupId
										  AND EntityId = I.TunnelProgramSetupId;
								    END
                                        END;
                                END;
                            ELSE
                                BEGIN
                                    DELETE TCD.PLCDiscrepancyData
                                        FROM TCD.PLCDiscrepancyData PD
                                             INNER JOIN(SELECT
                                                                * FROM inserted) AS I ON PD.ParentEntityType = 3
                                                                                     AND PD.EntityType = 5
                                                                                     AND PD.ParentEntityId = I.WasherGroupId
                                                                                     AND PD.EntityId = I.TunnelProgramSetupId;
                                END;                        
                    END;
                END;
        END;
END;
GO
----------------------------------------------------
IF EXISTS(SELECT
				  *
			  FROM sys.objects
              WHERE object_id = OBJECT_ID(N'[TCD].[WasherAuditTrigger]')
				AND type IN(N'TR'))
	BEGIN
		DROP TRIGGER
                TCD.WasherAuditTrigger;
	END;
GO
CREATE TRIGGER TCD.WasherAuditTrigger ON TCD.Washer
    FOR INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Auditoperation_Sqlinsertid TINYINT = NULL, 
            @Auditoperation_Sqlupdateid TINYINT = NULL, 
            @Auditoperation_Appdeleteid TINYINT = NULL,             
            @Softdeleteflag BIT = NULL, 
            @Currenttimestamp DATETIME = GETUTCDATE(), 
            @Controllerid INT = NULL;

    --CURRENT_TIMESTAMP

    SELECT
            @Auditoperation_Sqlinsertid = AO.OperationId
        FROM TCD.AuditOperation AS AO
        WHERE AO.OperationCode = 'SQLInsert';
    SELECT
            @Auditoperation_Sqlupdateid = AO.OperationId
        FROM TCD.AuditOperation AS AO
        WHERE AO.OperationCode = 'SQLUpdate';
    SELECT
            @Auditoperation_Appdeleteid = AO.OperationId
        FROM TCD.AuditOperation AS AO
        WHERE AO.OperationCode = 'AppDelete';
    SELECT
            @Controllerid = ISNULL(ControllerId, 0)
        FROM INSERTED AS I
             INNER JOIN TCD.MachineSetup AS ms ON ms.WasherId = I.WasherId;
    IF NOT EXISTS(SELECT
                          1 FROM deleted)
        BEGIN            
                INSERT INTO TCD.WasherHistory(
                        WasherId, 
                        OperationTimestamp, 
                        OperationId, 
                        OperationByUserId, 
                        EcoLabAccountNumber, 
                        PlantWasherNumber, 
                        ModelId, 
                        WasherMode, 
                        MaxLoad, 
                        AWEActive, 
                        EndOfFormula, 
                        Description, 
                        NumberOfTanks, 
                        TransferType, 
                        PressExtractor, 
                        HoldSignal, 
                        HoldDelay, 
                        TargetTurnTime, 
                        WaterFlushTime, 
                        Is_Deleted, 
                        LastModifiedTime, 
                        LastSyncTime, 
                        MyServiceCustMchGuid, 
                        MyServiceLastSynchTime, 
                        RatioDosingActive, 
                        EmptyPocketNumber, 
                        LfsWasher, 
                        NumberOfCompartmentsConveyorBelt, 
                        MinMachineLoad, 
                        MaxMachineLoad, 
                        ProgramSelectionByTime, 
                        WeightSelectionByTime, 
                        WeightSelectionByAnalogInput, 
                        TunInTomMode, 
                        SignalStopTunActive, 
                        SignalEjectionTunActive, 
                        DelayTimeForTunWashingPrograms, 
                        KannegiesserPressSpecialMode, 
                        ValveOutputsUsedAsTomSignal, 
                        ExtendedClockOrDataProtocol, 
                        WeightCorrectionFcc, 
                        FlowSwitchNumber, 
                        WasherStopExternalSignal, 
                        OnHoldWESignalActive, 
                        WasherOnHoldSignalDelay, 
                        WEInTOMMode, 
                        ManifoldFlushTime, 
                        L1, 
                        L2, 
                        L3, 
                        L4, 
                        L5, 
                        L6, 
                        L7, 
                        L8, 
                        L9, 
                        L10, 
                        L11, 
                        L12, 
                        UseMe1OfGroup, 
                        UseMe2OfGroup, 
                        UsePumpOfGroup, 
                        WasherStopUseFinalExtracting, 
                        TemperatureAlarmYesNo, 
                        PhProbe, 
                        WeightCell, 
                        Temperature, 
                        WaterCounter, 
                        AutoRinseDesamixAfter, 
                        AutoRinseDesamix1For, 
                        AutoRinseDesamix2For, 
                        DateAndTimeWhenBatchEjects, 
                        TemperatureAlarmProbe1, 
                        TemperatureAlarmProbe2, 
                        TemperatureAlarmProbe3, 
                        ExtractTimeForEOFSignal, 
                        TargetTransferPerHour)
                SELECT
                        WasherId, 
                        @Currenttimestamp, 
                        @Auditoperation_Sqlinsertid, 
                        LastModifiedByUserId, 
                        EcoLabAccountNumber, 
                        PlantWasherNumber, 
                        ModelId, 
                        WasherMode, 
                        MaxLoad, 
                        AWEActive, 
                        EndOfFormula, 
                        Description, 
                        NumberOfTanks, 
                        TransferType, 
                        PressExtractor, 
                        HoldSignal, 
                        HoldDelay, 
                        TargetTurnTime, 
                        WaterFlushTime, 
                        Is_Deleted, 
                        LastModifiedTime, 
                        LastSyncTime, 
                        MyServiceCustMchGuid, 
                        MyServiceLastSynchTime, 
                        RatioDosingActive, 
                        EmptyPocketNumber, 
                        LfsWasher, 
                        NumberOfCompartmentsConveyorBelt, 
                        MinMachineLoad, 
                        MaxMachineLoad, 
                        ProgramSelectionByTime, 
                        WeightSelectionByTime, 
                        WeightSelectionByAnalogInput, 
                        TunInTomMode, 
                        SignalStopTunActive, 
                        SignalEjectionTunActive, 
                        DelayTimeForTunWashingPrograms, 
                        KannegiesserPressSpecialMode, 
                        ValveOutputsUsedAsTomSignal, 
                        ExtendedClockOrDataProtocol, 
                        WeightCorrectionFcc, 
                        FlowSwitchNumber, 
                        WasherStopExternalSignal, 
                        OnHoldWESignalActive, 
                        WasherOnHoldSignalDelay, 
                        WEInTOMMode, 
                        ManifoldFlushTime, 
                        L1, 
                        L2, 
                        L3, 
                        L4, 
                        L5, 
                        L6, 
                        L7, 
                        L8, 
                        L9, 
                        L10, 
                        L11, 
                        L12, 
                        UseMe1OfGroup, 
                        UseMe2OfGroup, 
                        UsePumpOfGroup, 
                        WasherStopUseFinalExtracting, 
                        TemperatureAlarmYesNo, 
                        PhProbe, 
                        WeightCell, 
                        Temperature, 
                        WaterCounter, 
                        AutoRinseDesamixAfter, 
                        AutoRinseDesamix1For, 
                        AutoRinseDesamix2For, 
                        DateAndTimeWhenBatchEjects, 
                        TemperatureAlarmProbe1, 
                        TemperatureAlarmProbe2, 
                        TemperatureAlarmProbe3, 
                        ExtractTimeForEOFSignal, 
                        TargetTransferPerHour
                    FROM inserted;            
        END;
    ELSE
        BEGIN
            IF EXISTS(SELECT
                              1 FROM inserted)
                BEGIN
                    IF UPDATE(Is_Deleted)
                        BEGIN
                            SET @Softdeleteflag = 'TRUE';
                        END;
                    ELSE
                        BEGIN
                            SET @Softdeleteflag = 'FALSE';
                        END;
                    BEGIN                        
                            INSERT INTO TCD.WasherHistory(
                                    WasherId, 
                                    OperationTimestamp, 
                                    OperationId, 
                                    OperationByUserId, 
                                    EcoLabAccountNumber, 
                                    PlantWasherNumber, 
                                    ModelId, 
                                    WasherMode, 
                                    MaxLoad, 
                                    AWEActive, 
                                    EndOfFormula, 
                                    Description, 
                                    NumberOfTanks, 
                                    TransferType, 
                                    PressExtractor, 
                                    HoldSignal, 
                                    HoldDelay, 
                                    TargetTurnTime, 
                                    WaterFlushTime, 
                                    Is_Deleted, 
                                    LastModifiedTime, 
                                    LastSyncTime, 
                                    MyServiceCustMchGuid, 
                                    MyServiceLastSynchTime, 
                                    RatioDosingActive, 
                                    EmptyPocketNumber, 
                                    LfsWasher, 
                                    NumberOfCompartmentsConveyorBelt, 
                                    MinMachineLoad, 
                                    MaxMachineLoad, 
                                    ProgramSelectionByTime, 
                                    WeightSelectionByTime, 
                                    WeightSelectionByAnalogInput, 
                                    TunInTomMode, 
                                    SignalStopTunActive, 
                                    SignalEjectionTunActive, 
                                    DelayTimeForTunWashingPrograms, 
                                    KannegiesserPressSpecialMode, 
                                    ValveOutputsUsedAsTomSignal, 
                                    ExtendedClockOrDataProtocol, 
                                    WeightCorrectionFcc, 
                                    FlowSwitchNumber, 
                                    WasherStopExternalSignal, 
                                    OnHoldWESignalActive, 
                                    WasherOnHoldSignalDelay, 
                                    WEInTOMMode, 
                                    ManifoldFlushTime, 
                                    L1, 
                                    L2, 
                                    L3, 
                                    L4, 
                                    L5, 
                                    L6, 
                                    L7, 
                                    L8, 
                                    L9, 
                                    L10, 
                                    L11, 
                                    L12, 
                                    UseMe1OfGroup, 
                                    UseMe2OfGroup, 
                                    UsePumpOfGroup, 
                                    WasherStopUseFinalExtracting, 
                                    TemperatureAlarmYesNo, 
                                    PhProbe, 
                                    WeightCell, 
                                    Temperature, 
                                    WaterCounter, 
                                    AutoRinseDesamixAfter, 
                                    AutoRinseDesamix1For, 
                                    AutoRinseDesamix2For, 
                                    DateAndTimeWhenBatchEjects, 
                                    TemperatureAlarmProbe1, 
                                    TemperatureAlarmProbe2, 
                                    TemperatureAlarmProbe3, 
                                    ExtractTimeForEOFSignal, 
                                    TargetTransferPerHour)
                            SELECT
                                    WasherId, 
                                    @Currenttimestamp, 
                                    CASE
                                        WHEN @Softdeleteflag = 'FALSE' THEN @Auditoperation_Sqlupdateid
                                        WHEN @Softdeleteflag = 'TRUE' THEN @Auditoperation_Appdeleteid
                                    END, 
                                    LastModifiedByUserId, 
                                    EcoLabAccountNumber, 
                                    PlantWasherNumber, 
                                    ModelId, 
                                    WasherMode, 
                                    MaxLoad, 
                                    AWEActive, 
                                    EndOfFormula, 
                                    Description, 
                                    NumberOfTanks, 
                                    TransferType, 
                                    PressExtractor, 
                                    HoldSignal, 
                                    HoldDelay, 
                                    TargetTurnTime, 
                                    WaterFlushTime, 
                                    Is_Deleted, 
                                    LastModifiedTime, 
                                    LastSyncTime, 
                                    MyServiceCustMchGuid, 
                                    MyServiceLastSynchTime, 
                                    RatioDosingActive, 
                                    EmptyPocketNumber, 
                                    LfsWasher, 
                                    NumberOfCompartmentsConveyorBelt, 
                                    MinMachineLoad, 
                                    MaxMachineLoad, 
                                    ProgramSelectionByTime, 
                                    WeightSelectionByTime, 
                                    WeightSelectionByAnalogInput, 
                                    TunInTomMode, 
                                    SignalStopTunActive, 
                                    SignalEjectionTunActive, 
                                    DelayTimeForTunWashingPrograms, 
                                    KannegiesserPressSpecialMode, 
                                    ValveOutputsUsedAsTomSignal, 
                                    ExtendedClockOrDataProtocol, 
                                    WeightCorrectionFcc, 
                                    FlowSwitchNumber, 
                                    WasherStopExternalSignal, 
                                    OnHoldWESignalActive, 
                                    WasherOnHoldSignalDelay, 
                                    WEInTOMMode, 
                                    ManifoldFlushTime, 
                                    L1, 
                                    L2, 
                                    L3, 
                                    L4, 
                                    L5, 
                                    L6, 
                                    L7, 
                                    L8, 
                                    L9, 
                                    L10, 
                                    L11, 
                                    L12, 
                                    UseMe1OfGroup, 
                                    UseMe2OfGroup, 
                                    UsePumpOfGroup, 
                                    WasherStopUseFinalExtracting, 
                                    TemperatureAlarmYesNo, 
                                    PhProbe, 
                                    WeightCell, 
                                    Temperature, 
                                    WaterCounter, 
                                    AutoRinseDesamixAfter, 
                                    AutoRinseDesamix1For, 
                                    AutoRinseDesamix2For, 
                                    DateAndTimeWhenBatchEjects, 
                                    TemperatureAlarmProbe1, 
                                    TemperatureAlarmProbe2, 
                                    TemperatureAlarmProbe3, 
                                    ExtractTimeForEOFSignal, 
                                    TargetTransferPerHour
                                FROM inserted;
                            IF @Softdeleteflag = 'FALSE'
                                BEGIN
                                    IF NOT EXISTS(SELECT
                                                          *
                                                      FROM TCD.PLCDiscrepancyData AS PD
                                                           INNER JOIN TCD.MachineSetup AS ms ON ParentEntityType = 3
                                                                                            AND EntityType = 4
                                                                                            AND PD.ParentEntityId = ms.GroupId
                                                                                            AND PD.EntityId = ms.WasherId
                                                           INNER JOIN inserted AS I ON PD.EntityId = I.WasherId)
                                   AND @Controllerid <> 0
                                        BEGIN
                                            INSERT TCD.PLCDiscrepancyData(
                                                    ParentEntityType, 
                                                    EntityType, 
                                                    ParentEntityId, 
                                                    EntityId, 
                                                    SyncFromCentral, 
                                                    ControllerId, 
                                                    SyncToPlc, 
                                                    CreatedUserId, 
                                                    LastModifiedUserId, 
                                                    LastModifiedTime)
                                            SELECT
                                                    3, 
                                                    4, 
                                                    ms.GroupId, 
                                                    I.WasherId, 
                                                    CASE
                                                        WHEN I.LastModifiedByUserId = 0 THEN 1
                                                        ELSE 0
                                                    END, 
                                                    ms.ControllerId, 
                                                    0, 
                                                    I.LastModifiedByUserId, 
                                                    NULL, 
                                                    GETUTCDATE()
                                                FROM inserted AS I
                                                     INNER JOIN TCD.MachineSetup AS ms ON I.WasherId = ms.WasherId;
                                        END;
                                    ELSE
                                        BEGIN
                                            UPDATE TCD.PLCDiscrepancyData SET
                                                    SyncFromCentral = CASE
                                                                          WHEN I.LastModifiedByUserId = 0 THEN 1
                                                                          ELSE 0
                                                                      END, 
                                                    LastModifiedUserId = I.LastModifiedByUserId, 
                                                    LastModifiedTime = GETUTCDATE()
                                                FROM(SELECT
                                                             * FROM inserted) AS I
                                                    INNER JOIN TCD.MachineSetup ms ON I.WasherId = ms.WasherId
                                                WHERE
                                                    ParentEntityType = 3
                                                AND EntityType = 4
                                                AND ParentEntityId = ms.GroupId
                                                AND EntityId = I.WasherId
                                                AND @Controllerid <> 0;
                                        END;
                                END;                        
                    END;
                END;
        END;
    SET NOCOUNT OFF;
    RETURN;
END;
GO
--------------------------------
IF EXISTS(SELECT
                  *
              FROM sys.objects
              WHERE object_id = OBJECT_ID(N'[TCD].[ControllerSetupDataAuditTrigger]')
                AND type IN(N'TR'))
    BEGIN
        DROP TRIGGER
                TCD.ControllerSetupDataAuditTrigger;
    END;
GO
CREATE TRIGGER TCD.ControllerSetupDataAuditTrigger ON TCD.ControllerSetupData
    FOR INSERT, UPDATE
AS
BEGIN

    SET NOCOUNT ON;

    DECLARE @Auditoperation_Sqlinsertid TINYINT = NULL, 
            @Auditoperation_Sqlupdateid TINYINT = NULL,                         
            @Currenttimestamp DATETIME = GETUTCDATE(), --CURRENT_TIMESTAMP
            @Controllermodelid INT = NULL, 
            @Tabid INT = NULL;

    SELECT
            @Auditoperation_Sqlinsertid = AO.OperationId
        FROM TCD.AuditOperation AS AO
        WHERE AO.OperationCode = 'SQLInsert';

    SELECT
            @Auditoperation_Sqlupdateid = AO.OperationId
        FROM TCD.AuditOperation AS AO
        WHERE AO.OperationCode = 'SQLUpdate';

    SELECT
            @Controllermodelid = ControllerModelId FROM inserted;
    SELECT
            @Tabid = ISNULL(fg.TabId, 0)
        FROM inserted AS I
             INNER JOIN TCD.FieldGroup AS fg ON I.FieldGroupId = fg.Id
                                            AND I.ControllerModelId = fg.ControllerModelId;
    IF NOT EXISTS(SELECT
                          1 FROM deleted)
        BEGIN
                INSERT TCD.ControllerSetupDataHistory(
                        Id, 
                        OperationTimestamp, 
                        OperationId, 
                        OperationByUserId, 
                        ControllerId, 
                        FieldGroupId, 
                        FieldId, 
                        [Value], 
                        ControllerModelId, 
                        FieldTagValue, 
                        EcolabAccountNumber)
                SELECT
                        Id, 
                        @Currenttimestamp, 
                        @Auditoperation_Sqlinsertid, 
                        LastModifiedByUserId, 
                        ControllerId, 
                        FieldGroupId, 
                        FieldId, 
                        [Value], 
                        ControllerModelId, 
                        FieldTagValue, 
                        EcolabAccountNumber
                    FROM inserted;

                IF NOT EXISTS(SELECT
                                      *
                                  FROM TCD.PLCDiscrepancyData AS PD
                                       INNER JOIN inserted AS I ON ParentEntityType = 1
                                                               AND EntityType = CASE
                                                                                    WHEN @Tabid = 1 THEN 1
                                                                                    ELSE 9
                                                                                END
                                                               AND PD.ParentEntityId = I.ControllerId
                                                               AND PD.EntityId = I.ControllerId)
               AND (@Controllermodelid = 7
                 OR @Controllermodelid <> 7
                AND @Tabid = 3)
                    BEGIN
                        INSERT TCD.PLCDiscrepancyData(
                                ParentEntityType, 
                                EntityType, 
                                ParentEntityId, 
                                EntityId, 
                                SyncFromCentral, 
                                ControllerId, 
                                SyncToPlc, 
                                CreatedUserId, 
                                LastModifiedUserId, 
                                LastModifiedTime)
                        SELECT TOP 1
                                1, 
                                CASE
                                    WHEN @Tabid = 1 THEN 1
                                    ELSE 9
                                END, 
                                I.ControllerId, 
                                I.ControllerId, 
                                CASE
                                    WHEN I.LastModifiedByUserId = 0 THEN 1
                                    ELSE 0
                                END, 
                                I.ControllerId, 
                                0, 
                                I.LastModifiedByUserId, 
                                NULL, 
                                GETUTCDATE()
                            FROM inserted AS I;
                    END;            
        END;
    ELSE
        BEGIN
            IF EXISTS(SELECT
                              1 FROM inserted)
                BEGIN
                        INSERT TCD.ControllerSetupDataHistory(
                                Id, 
                                OperationTimestamp, 
                                OperationId, 
                                OperationByUserId, 
                                ControllerId, 
                                FieldGroupId, 
                                FieldId, 
                                [Value], 
                                ControllerModelId, 
                                FieldTagValue, 
                                EcolabAccountNumber)
                        SELECT
                                Id, 
                                @Currenttimestamp, 
                                @Auditoperation_Sqlupdateid, 
                                LastModifiedByUserId, 
                                ControllerId, 
                                FieldGroupId, 
                                FieldId, 
                                [Value], 
                                ControllerModelId, 
                                FieldTagValue, 
                                EcolabAccountNumber
                            FROM inserted;

                        IF NOT EXISTS(SELECT
                                              *
                                          FROM TCD.PLCDiscrepancyData AS PD
                                               INNER JOIN inserted AS I ON ParentEntityType = 1
                                                                       AND EntityType = CASE
                                                                                            WHEN @Tabid = 1 THEN 1
                                                                                            ELSE 9
                                                                                        END
                                                                       AND PD.ParentEntityId = I.ControllerId
                                                                       AND PD.EntityId = I.ControllerId)
                       AND (@Controllermodelid = 7
                         OR @Controllermodelid <> 7
                        AND @Tabid = 3)
                            BEGIN
                                INSERT TCD.PLCDiscrepancyData(
                                        ParentEntityType, 
                                        EntityType, 
                                        ParentEntityId, 
                                        EntityId, 
                                        SyncFromCentral, 
                                        ControllerId, 
                                        SyncToPlc, 
                                        CreatedUserId, 
                                        LastModifiedUserId, 
                                        LastModifiedTime)
                                SELECT TOP 1
                                        1, 
                                        CASE
                                            WHEN @Tabid = 1 THEN 1
                                            ELSE 9
                                        END, 
                                        I.ControllerId, 
                                        I.ControllerId, -- EntityId - int
                                        CASE
                                            WHEN I.LastModifiedByUserId = 0 THEN 1
                                            ELSE 0
                                        END, 
                                        I.ControllerId, 
                                        0, 
                                        I.LastModifiedByUserId, 
                                        NULL, 
                                        GETUTCDATE()
                                    FROM inserted AS I;
                            END;
                        ELSE
                            BEGIN
                                UPDATE TCD.PLCDiscrepancyData SET
                                        SyncFromCentral = CASE
                                                              WHEN I.LastModifiedByUserId = 0 THEN 1
                                                              ELSE 0
                                                          END, 
                                        LastModifiedUserId = I.LastModifiedByUserId, 
                                        LastModifiedTime = GETUTCDATE()
                                    FROM(SELECT
                                                 * FROM inserted) AS I
                                    WHERE
                                        ParentEntityType = 1
                                    AND EntityType = CASE
                                                         WHEN @Tabid = 1 THEN 1
                                                         ELSE 9
                                                     END
                                    AND ParentEntityId = I.ControllerId
                                    AND EntityId = I.ControllerId;
                            END;                   
                END;
        END;
END;
GO
/*	
Purpose					:	Converting Stored Procedure to Prepared Statement
*/
 IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetTagManamenetDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				[TCD].[GetTagManamenetDetails];
	END;
GO
IF EXISTS (SELECT 1 FROM [TCD].[ReportColumnsMapping] WHERE reportid = 1  and ViewById = 1  and ColumnId = 133)
BEGIN
UPDATE [TCD].[ReportColumnsMapping] SET DisplayOrder = 2 WHERE reportid = 1  and ViewById = 1  and ColumnId = 133
END

IF EXISTS (SELECT 1 FROM [TCD].[ReportColumnsMapping] WHERE reportid = 1  and ViewById = 1  and ColumnId = 181)
BEGIN
UPDATE [TCD].[ReportColumnsMapping] SET DisplayOrder = 3 WHERE reportid = 1  and ViewById = 1  and ColumnId = 181
END

IF EXISTS (SELECT 1 FROM [TCD].[ReportColumnsMapping] WHERE reportid = 1  and ViewById = 1  and ColumnId = 200)
BEGIN
UPDATE [TCD].[ReportColumnsMapping] SET DisplayOrder = 4 WHERE reportid = 1  and ViewById = 1  and ColumnId = 200
END

IF EXISTS (SELECT 1 FROM [TCD].[ReportColumnsMapping] WHERE reportid = 1  and ViewById = 1  and ColumnId = 120)
BEGIN
UPDATE [TCD].[ReportColumnsMapping] SET DisplayOrder = 5 WHERE reportid = 1  and ViewById = 1  and ColumnId = 120
END

IF EXISTS (SELECT 1 FROM [TCD].[ReportColumnsMapping] WHERE reportid = 1  and ViewById = 1  and ColumnId = 182)
BEGIN
UPDATE [TCD].[ReportColumnsMapping] SET DisplayOrder = 6 WHERE reportid = 1  and ViewById = 1  and ColumnId = 182
END




IF EXISTS (SELECT 1 FROM [TCD].[ReportColumnsMapping] WHERE reportid = 1  and ViewById = 2  and ColumnId = 133)
BEGIN
UPDATE [TCD].[ReportColumnsMapping] SET DisplayOrder = 2 WHERE reportid = 1  and ViewById = 2  and ColumnId = 133
END

IF EXISTS (SELECT 1 FROM [TCD].[ReportColumnsMapping] WHERE reportid = 1  and ViewById = 2  and ColumnId = 181)
BEGIN
UPDATE [TCD].[ReportColumnsMapping] SET DisplayOrder = 3 WHERE reportid = 1  and ViewById = 2  and ColumnId = 181
END

IF EXISTS (SELECT 1 FROM [TCD].[ReportColumnsMapping] WHERE reportid = 1  and ViewById = 2  and ColumnId = 200)
BEGIN
UPDATE [TCD].[ReportColumnsMapping] SET DisplayOrder = 4 WHERE reportid = 1  and ViewById = 2  and ColumnId = 200
END

IF EXISTS (SELECT 1 FROM [TCD].[ReportColumnsMapping] WHERE reportid = 1  and ViewById = 2  and ColumnId = 120)
BEGIN
UPDATE [TCD].[ReportColumnsMapping] SET DisplayOrder = 5 WHERE reportid = 1  and ViewById = 2  and ColumnId = 120
END

IF EXISTS (SELECT 1 FROM [TCD].[ReportColumnsMapping] WHERE reportid = 1  and ViewById = 2  and ColumnId = 182)
BEGIN
UPDATE [TCD].[ReportColumnsMapping] SET DisplayOrder = 6 WHERE reportid = 1  and ViewById = 2  and ColumnId = 182
END

GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetRedFlagDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE [TCD].[GetRedFlagDetails];
	END;
GO

CREATE PROCEDURE [TCD].[GetRedFlagDetails](
      @Id INT = NULL, 
      @Ecolabaccountnumber nvarchar(25))
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Plantid INT, 
            @Regionid INT, 
            @Languageid INT, 
            @Uomendpart VARCHAR(100), 
            @Uom7 NVARCHAR(1000), 
            @Uom8 NVARCHAR(1000);
    SELECT
            @Plantid = PlantId, 
            @Regionid = RegionId, 
            @Languageid = LanguageId
        FROM TCD.Plant
        WHERE EcolabAccountNumber = @Ecolabaccountnumber;
    IF @Regionid = 1
        BEGIN
            SET @Uomendpart = 'CWT';
        END;
    ELSE
        BEGIN
            SET @Uomendpart = 'kg';
        END;

    SELECT
            @Uom7 = rkv.[Value]
        FROM TCD.Meter AS m
             LEFT JOIN tcd.ResourceKeyValue AS rkv ON m.MeterTickUnit = rkv.KeyName
                                                  AND LanguageId = @Languageid
        WHERE m.GroupId IS NULL
          AND m.UtilityType IN(1, 2);

    SELECT
            @Uom8 = rkv.[Value]
        FROM TCD.Meter AS m
             LEFT JOIN tcd.ResourceKeyValue AS rkv ON m.MeterTickUnit = rkv.KeyName
                                                  AND LanguageId = @Languageid
        WHERE m.GroupId IS NULL
          AND m.UtilityType IN(1);

    SELECT Distinct 
            PR.Id, 
            ItemID = PR.Item, 
            IL.ItemName, 
            PR.MinimumRange, 
            PR.MaximumRange, 
            CASE
                WHEN PR.Item IN(7, 8)THEN CASE
                                              WHEN ISNULL(PR.MeterId, 0) != 0 THEN rkv.[Value] + '/' + @Uomendpart
                                              WHEN PR.Item = 7 THEN @Uom7 + '/' + @Uomendpart
                                              WHEN PR.Item = 8 THEN @Uom8 + '/' + @Uomendpart
                                          END
                ELSE CASE @Regionid
                         WHEN 1 THEN IL.UOMNA
                         WHEN 2 THEN IL.UOMEurope
                     END
            END AS UOM, 
            LocationID = PR.Location, 
            CASE
                WHEN GT.Is_Deleted = 0 THEN GT.GroupDescription
                ELSE CAST('' AS NVARCHAR)
            END AS LocationName, 
            PR.EcolabAccountNumber, 
            (SELECT
                     STUFF((
             SELECT DISTINCT
                     ',' + CAST(ISNULL(MachineId, -1)AS VARCHAR(1000))
                 FROM TCD.RedFlagMappingData AS MD
                 WHERE MD.MappingID = PR.ID
                   AND MD.Is_Deleted = 0
                 FOR
                 XML PATH('')), 1, 1, ''))AS MachineID, 
            (SELECT
                     LTRIM(ISNULL(STUFF((
             SELECT DISTINCT
                     ', ' + (
             SELECT
                     CASE
                         WHEN(
             SELECT DISTINCT
                     Istunnel
                 FROM TCD.machinesetup AS S
                 WHERE S.groupId = PR.Location
                   AND S.Washerid = MD.MachineId) = 1 THEN CASE
                                                               WHEN(
             SELECT
                     RD.MachineId
                 FROM TCD.RedFlag AS MM
                      INNER JOIN TCD.RedFlagMappingData AS RD ON MM.Id = RD.MappingId
                 WHERE RD.MachineId = MD.MachineId
                   AND RD.MachineId = 0
                   AND RD.Is_Deleted = 0) = 0 THEN 'Press'
                                                               ELSE CASE
                                                                        WHEN(
             SELECT TOP 1
                     MS.IsDeleted
                 FROM TCD.MachineSetup AS MS
                 WHERE MS.GroupId = PR.Location
                   AND MS.WasherId = MD.MachineId
                   AND MS.IsDeleted = 0)IS NOT NULL THEN (SELECT TOP(1) CAST(WS.PlantWasherNumber AS nvarchar)+':'+MS.MachineName FROM TCD.MachineSetup MS INNER JOIN TCD.Washer WS ON MS.WasherId = WS.WasherId WHERE MS.GroupId = PR.Location AND MS.WasherId = MD.MachineId) ELSE '0'
                                                                    END
      
                                                           END
                         WHEN(
             SELECT DISTINCT
                     Istunnel
                 FROM TCD.machinesetup AS S
                 WHERE S.groupId = PR.Location
                   AND S.Washerid = MD.MachineId) = 0 THEN ISNULL((
             SELECT TOP (1)
                     CAST(WS.PlantWasherNumber AS NVARCHAR) + ':' + MS.MachineName
                 FROM TCD.MachineSetup AS MS
                      INNER JOIN TCD.Washer AS WS ON MS.WasherId = WS.WasherId
                 WHERE MS.GroupId = PR.Location
                   AND MS.WasherId = MD.MachineId
                   AND MS.IsDeleted = 0), '0')
                         WHEN(
             SELECT DISTINCT
                     GroupTypeId FROM TCD.MachineGroup AS GT WHERE GT.Id = PR.Location) = 3 THEN(
             SELECT
                     Description
                 FROM TCD.Dryers AS D
                 WHERE D.DryerGroupId = PR.Location
                   AND D.DryerNo = MD.MachineId
                   AND D.Is_deleted = 0)
                         WHEN(
             SELECT DISTINCT
                     GroupTypeId FROM TCD.MachineGroup AS GT WHERE GT.Id = PR.Location) = 4 THEN(
             SELECT
                     Name
                 FROM TCD.Finnishers AS F
                 WHERE F.FinnisherGroupId = PR.Location
                   AND F.FinnisherNo = MD.MachineId
                   AND F.Is_deleted = 0)
                     END)
                 FROM TCD.RedFlagMappingData AS MD
                      LEFT OUTER JOIN TCD.Machinesetup AS MSP ON MSP.WasherId = MD.MachineId
                 WHERE MD.MappingID = PR.ID
                   AND MD.Is_Deleted = 0
                 FOR
                 XML PATH('')), 1, 1, ''), 'ALL')))AS MachineName, 
            PR.RedFlagCategoryId AS CategoryId, 
            PR.FormulaId AS FormulaId, 
            PM.Name AS FormulaName, 
            PR.ProductId, 
            PRM.Name AS ProductName, 
            ISNULL(PR.MeterId, s.SensorId)AS MeterId, 
            CASE
                WHEN ISNULL(PR.MeterId, 0) != 0 THEN ME.Description
                ELSE s.Description
            END AS MeterName, 
            PR.LastModifiedTime, 
            PR.LastSyncTime, 
            PR.Is_Deleted, 
            Pr.SensorId
        FROM TCD.RedFlag AS PR
             INNER JOIN TCD.RedFlagItemList AS IL ON PR.Item = IL.Id
             LEFT JOIN TCD.WasherProgramSetup AS WPS ON CASE PR.Location WHEN 1 THEN 1 ELSE PR.Location END  =  CASE PR.Location WHEN 1 THEN 1 ELSE WPS.WasherGroupId END 
                                                    AND WPS.ProgramID = PR.FormulaId
                                                    AND WPS.Ecolabaccountnumber = @Ecolabaccountnumber
             LEFT JOIN TCD.TunnelProgramSetup AS TPS ON CASE PR.Location WHEN 1 THEN 1 ELSE PR.Location END  =  CASE PR.Location WHEN 1 THEN 1 ELSE TPS.WasherGroupId END 
                                                    AND TPS.ProgramID = PR.FormulaId
                                                    AND TPS.Ecolabaccountnumber = @Ecolabaccountnumber
             LEFT JOIN tcd.ProgramMaster AS PM ON PM.ProgramId = CASE
                                                                     WHEN WPS.WasherProgramSetupId IS NOT NULL THEN WPS.ProgramId
                                                                     ELSE TPS.ProgramId
                                                                 END --Identify whether its tunnel or washer formula
             LEFT JOIN TCD.ProductMaster AS PRM ON PRM.ProductId = PR.ProductId
             LEFT JOIN TCD.Meter AS ME ON ME.MeterId = PR.MeterId
                                      AND ME.EcolabAccountNumber = @Ecolabaccountnumber
             LEFT JOIN TCD.RedFlagCategory AS RFC ON RFC.RedFlagCategoryId = PR.RedFlagCategoryId
             INNER JOIN TCD.MachineGroup AS GT ON PR.Location = GT.Id
             LEFT JOIN tcd.ResourceKeyValue AS rkv ON ME.MeterTickUnit = rkv.KeyName
                                                  AND LanguageId = @Languageid
             LEFT JOIN TCD.Sensor AS s ON s.SensorId = PR.SensorId
        WHERE PR.PlantId = @Plantid
          AND PR.Is_Deleted = 0 
              --AND GT.Is_Deleted = 0
          AND CASE ISNULL(@Id, '')
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN PR.Id = @Id THEN 'TRUE'
                       END
              END = 'TRUE';
    SET NOCOUNT OFF;
END;

GO

 IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[RedFlagGenerationFinancials]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE [TCD].[RedFlagGenerationFinancials];
	END;
GO

CREATE PROCEDURE [TCD].[RedFlagGenerationFinancials]
( @ShiftId int , 
                                                       @PartitionOn smalldatetime , 
                                                       @EcolabAccountNumber nvarchar( 25)
                                                     )
AS
BEGIN
 DECLARE
       @Value decimal( 18 , 3) , 
	   @UOMId int,
	   @RegionId int,
       @PlantId int;
	   declare @ActualWeight decimal (18,2);

 SELECT
            @PlantId = PlantId
			,@UOMId=UOMId
			,@RegionId=RegionId
      FROM TCD.Plant p
      WHERE p.EcolabAccountNumber = @EcolabAccountNumber;

    DECLARE
       @Redflag TABLE(
            CounterId int IDENTITY( 1 , 1) , 
            Id int , 
            Item int
                     );

    DECLARE
       @MaxId int , 
       @Counter int , 
       @Item int , 
       @ShiftHrs int , 
       @Id int;


    INSERT INTO @Redflag(Id,
            Item
                        )
    SELECT
            rf.Id , 
            rf.Item
      FROM TCD.RedFlag rf
      WHERE rf.Is_Deleted = 0
        AND rf.RedFlagCategoryId = 4;

    SELECT
            @MaxId = ISNULL( MAX( CounterId) , 0)
      FROM @Redflag r;

SELECT bd.*   
	INTO #BatchData  
	FROM tcd.BatchData bd (NOLOCK) 
	INNER JOIN TCD.MachineSetup ms  (NOLOCK)  on bd.MachineId=ms.WasherId AND   isnull(ms.IsPony,0)=0
	WHERE bd.ShiftId =@ShiftId 
	--AND bd.StandardWeight > 0  
	--and bd.ActualWeight > 0   
	and bd.EndDate IS NOT NULL





    SET @Counter = 1;

    WHILE @Counter <= @MaxId 
        BEGIN
            SELECT
                    @Id = Id , 
                    @Item = Item
              FROM @Redflag r
              WHERE CounterId = @Counter;

			   IF @Item = 22
                BEGIN
				--Water Cost (per CWT/Kg)
				 SELECT   @ActualWeight=  sum( isnull( bd.ActualWeight,0) + isnull( bd.ManualInputWeight,0)) 
						  FROM #BatchData bd
						   INNER JOIN TCD.[BatchStepWaterUsageData] bswud ON bswud.BatchId=bd.BatchId and bswud.EcolabWasherId=bd.EcolabWasherId
							INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
										AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0) AND rf.Is_Deleted = 0
							 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0
						  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
							AND bd.ShiftId = @ShiftId
							--AND BD.PartitionOn = @PartitionOn
							AND rf.Id = @Id

                     SELECT  @Value= ( sum( bswud.[Price])/ @ActualWeight) * (case @RegionId when 1 then 100 else 1 end) * (case @RegionId when 1 then 1 else 3.78541178 end )
						  FROM #BatchData bd
						   INNER JOIN TCD.[BatchStepWaterUsageData] bswud ON bswud.BatchId=bd.BatchId and bswud.EcolabWasherId=bd.EcolabWasherId
							INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
										AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0) AND rf.Is_Deleted = 0
							 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0
						  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
							AND bd.ShiftId = @ShiftId
							--AND BD.PartitionOn = @PartitionOn
							AND rf.Id = @Id
                END
				ELSE   IF @Item = 23
                BEGIN
				--Energy Cost (per CWT/Kg)
				  SELECT  @ActualWeight=  sum( isnull( bd.ActualWeight,0) + isnull( bd.ManualInputWeight,0)) 
					  FROM #BatchData bd
					   INNER JOIN TCD.[BatchEnergyUsageData] beua ON beua.BatchId=bd.BatchId and beua.EcolabWasherId=bd.EcolabWasherId
						INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
									AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0) AND rf.Is_Deleted = 0
						 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0
					  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
						AND bd.ShiftId = @ShiftId
						--AND BD.PartitionOn = @PartitionOn
						AND rf.Id = @Id

				   SELECT  @Value=  sum( beua.Price)/ @ActualWeight * (case @RegionId when 1 then 100 else 1 end) * (case @RegionId when 1 then 1 else 3.78541178 end )
					  FROM #BatchData bd
					   INNER JOIN TCD.[BatchEnergyUsageData] beua ON beua.BatchId=bd.BatchId and beua.EcolabWasherId=bd.EcolabWasherId
						INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
									AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0) AND rf.Is_Deleted = 0
						 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0
					  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
						AND bd.ShiftId = @ShiftId
						--AND BD.PartitionOn = @PartitionOn
						AND rf.Id = @Id

				END
				ELSE   IF @Item = 24
                BEGIN
				--Gas Cost (per CWT/Kg)
				 SELECT  @ActualWeight=  sum( isnull( bd.ActualWeight,0) + isnull( bd.ManualInputWeight,0)) 
					  FROM #BatchData bd
						INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
									AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0) AND rf.Is_Deleted = 0
						 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0
					  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
						AND bd.ShiftId = @ShiftId
					--	AND BD.PartitionOn = @PartitionOn
						AND rf.Id = @Id



				    SELECT  @Value=( sum( beua.Price)/@ActualWeight)* (case @RegionId when 1 then 100 else 1 end) * (case @RegionId when 1 then 1 else 3.78541178 end ) 
					  FROM #BatchData bd
					  INNER JOIN TCD.[BatchEnergyUsageData] beua ON beua.BatchId=bd.BatchId and beua.EcolabWasherId=bd.EcolabWasherId AND beua.GasOilTypeId IN (1,2)
						INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
									AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0) AND rf.Is_Deleted = 0
						 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0
					  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
						AND bd.ShiftId = @ShiftId
					--	AND BD.PartitionOn = @PartitionOn
						AND rf.Id = @Id


				END
				ELSE   IF @Item = 26
                BEGIN
					--Chemical Cost (per CWT/Kg)
				 SELECT  @ActualWeight=  sum( isnull( bd.ActualWeight,0) + isnull( bd.ManualInputWeight,0)) 
					  FROM #BatchData bd					 
						INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
									AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0) AND rf.Is_Deleted = 0
						 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0
					  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
						AND bd.ShiftId = @ShiftId
						--AND BD.PartitionOn = @PartitionOn
						AND rf.Id = @Id
			
				  SELECT  @Value=  (sum( bp.Price)/ @ActualWeight ) * (case @RegionId when 1 then 100 else 1 end) * (case @RegionId when 1 then 1 else 3.78541178 end ) 
					  FROM #BatchData bd
					   INNER JOIN TCD.[BatchProductData] bp  ON bp.BatchId=bd.BatchId and bp.EcolabWasherId=bd.EcolabWasherId --and bp.InjectionNumber=bd.ProgramMasterId
						INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
									AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0) AND rf.Is_Deleted = 0
						 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0
					  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
						AND bd.ShiftId = @ShiftId
						--AND BD.PartitionOn = @PartitionOn
						AND rf.Id = @Id

				END
				ELSE   IF @Item = 28
                BEGIN
				--Total Cost (WEC per CWT/Kg)
				

				 SELECT @ActualWeight=sum( isnull( bd.ActualWeight,0) + isnull( bd.ManualInputWeight,0)) 

				 FROM #BatchData bd
				  INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
								AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0) AND rf.Is_Deleted = 0
					 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0		
	
				  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
					AND bd.ShiftId = @ShiftId				
					AND rf.Id = @Id
					--AND bd.ActualWeight>0 AND bd.StandardWeight>0 

				
				  SELECT  @Value= (sum(ISNULL( bswud.[Price],0)) +sum(ISNULL( beua.Price,0))+sum(ISNULL( bp.Price,0))/ @ActualWeight)
				  *(case @RegionId when 1 then 100 else 1 end) *(case @RegionId when 1 then 1 else 3.78541178 end )
				 

				  FROM #BatchData bd
				  INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
								AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0) AND rf.Is_Deleted = 0
					 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0
				  LEFT JOIN TCD.[BatchEnergyUsageData] beua ON beua.BatchId=bd.BatchId and beua.EcolabWasherId=bd.EcolabWasherId 
				    LEFT JOIN TCD.[BatchProductData] bp  ON bp.BatchId=bd.BatchId and bp.EcolabWasherId=bd.EcolabWasherId --and bp.InjectionNumber=bd.ProgramMasterId
					 LEFT JOIN TCD.[BatchStepWaterUsageData] bswud ON bswud.BatchId=bd.BatchId and bswud.EcolabWasherId=bd.EcolabWasherId
	
				  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
					AND bd.ShiftId = @ShiftId				
					AND rf.Id = @Id

				END				


			IF @Value IS NOT NULL 
			BEGIN
            IF NOT EXISTS( SELECT
                                   1
                             FROM TCD.RedFlag rf
                             WHERE Id = @Id
                               AND rf.Is_Deleted = 0
                               AND rf.MinimumRange <= @Value
                               AND rf.MaximumRange >= @Value
                         )
                BEGIN

                    IF NOT EXISTS( SELECT
                                           1
                                     FROM TCD.RedFlagData rfd
                                     WHERE rfd.RedFlagId = @Id
                                       AND rfd.ShiftId = @ShiftId
                                       AND PartitionOn = @PartitionOn
                                 )
                        BEGIN
                            INSERT INTO TCD.RedFlagData(
                                    RedFlagId , 
                                    PlantId , 
                                    ShiftId , 
                                    RedFlagValue , 
                                    RedFlagMinSetPoint , 
                                    RedFlagMaxSetPoint , 
                                    PartitionOn
                                                       )
                            SELECT
                                    rf.Id , 
                                    @PlantId , 
                                    @ShiftId , 
                                    @Value , 
									 rf.MinimumRange , 
                                    rf.MaximumRange ,                                    
                                    @PartitionOn
                              FROM TCD.RedFlag rf
                              WHERE rf.Id = @Id;

                        END;

                END;
			END

            SET @Counter = @Counter + 1;
		END
END
GO

 IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[RedFlagGenerationProcessValidation]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE [TCD].[RedFlagGenerationProcessValidation];
	END;
GO

CREATE PROCEDURE [TCD].[RedFlagGenerationProcessValidation]
( @ShiftId int , 
                                                       @PartitionOn smalldatetime , 
                                                       @EcolabAccountNumber nvarchar( 25)
                                                     )
AS
BEGIN
 DECLARE
       @Value decimal( 18 , 3) , 
       @PlantId int;

    SELECT
            @PlantId = PlantId
      FROM TCD.Plant p
      WHERE p.EcolabAccountNumber = @EcolabAccountNumber;

    DECLARE
       @Redflag TABLE(
            CounterId int IDENTITY( 1 , 1) , 
            Id int , 
            Item int,
			MinimumRange decimal(18,2),
			MaximumRange decimal(18,2)
                     );

    DECLARE
       @MaxId int , 
       @Counter int , 
       @Item int , 
       @ShiftHrs int , 
       @Id int;

declare @MinValue decimal(18,2),@MaxValue decimal (18,2)

	

    INSERT INTO @Redflag(Id,
            Item,
			MinimumRange,
			MaximumRange
                        )
    SELECT
            rf.Id , 
            rf.Item,
			MinimumRange,
			MaximumRange
      FROM TCD.RedFlag rf
      WHERE rf.Is_Deleted = 0
        AND rf.RedFlagCategoryId in( 2,5);

    SELECT
            @MaxId = ISNULL( MAX( CounterId) , 0)
      FROM @Redflag r;

	
SELECT bd.*   
	INTO #BatchData  
	FROM tcd.BatchData bd (NOLOCK) 
	INNER JOIN TCD.MachineSetup ms  (NOLOCK)  on bd.MachineId=ms.WasherId AND   isnull(ms.IsPony,0)=0
	WHERE bd.ShiftId =@ShiftId 
	--AND bd.StandardWeight > 0  
	--and bd.ActualWeight > 0   
	and bd.EndDate IS NOT NULL

	declare @ActualWeight int

    SET @Counter = 1;

    WHILE @Counter   <= @MaxId
        BEGIN
            SELECT
                    @Id = Id , 
                    @Item = Item,
					@MinValue =MinimumRange, @MaxValue =MaximumRange
              FROM @Redflag r
              WHERE CounterId = @Counter;
		
			   IF @Item = 5
                BEGIN
				--Rewash Rate (% per shift) 
					
				  SELECT @ActualWeight = sum(bd.ActualWeight)
				  FROM  #BatchData bd 
						INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1) 
														AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0)AND rf.Is_Deleted = 0							
					   LEFT JOIN tcd.RedFlagMappingData rfmd
					   ON rf.Id = rfmd.MappingId
					  AND rfmd.Is_Deleted = 0
				  WHERE (bd.MachineId = rfmd.MachineId OR rfmd.MachineId IS NULL )
					AND bd.ShiftId = @ShiftId
				--	AND bd.PartitionOn = @PartitionOn
					AND rf.Id = 2;

                      SELECT @Value =( sum(cr.TotalRewashLoad)/@ActualWeight)*100.00
				  FROM  TCD.CustomRewash cr 
						INNER JOIN TCD.RedFlag rf ON(rf.Location = cr.GroupId OR rf.Location = 1) 
														AND (cr.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0)AND rf.Is_Deleted = 0						
					   LEFT JOIN tcd.RedFlagMappingData rfmd
					   ON rf.Id = rfmd.MappingId
					  AND rfmd.Is_Deleted = 0
				  WHERE ( cr.EcolabWasherId = rfmd.MachineId  OR rfmd.MachineId IS NULL)
					AND cr.ShiftId = @ShiftId
					--AND cr.PartitionOn = @PartitionOn
					AND rf.Id = @Id;
                END
				ELSE IF @Item = 20
                BEGIN
				--Number Rejected Batches (# per shift)
                    SELECT @Value = count(DISTINCT bp.BatchId)
				  FROM  #BatchData bd 
						INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1) 
														AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0)AND rf.Is_Deleted = 0	
						INNER JOIN TCD.BatchParameters	bp ON bp.BatchId = bd.BatchId 
																AND BP.ParameterId = 18 AND BP.ParameterValue IN(2, 3)
					   LEFT JOIN tcd.RedFlagMappingData rfmd
					   ON rf.Id = rfmd.MappingId
					  AND rfmd.Is_Deleted = 0
				  WHERE ( bd.MachineId = rfmd.MachineId OR rfmd.MachineId IS NULL )
					AND bd.ShiftId = @ShiftId
					--AND bd.PartitionOn = @PartitionOn
					AND rf.Id = @Id;


                END		
				ELSE IF @Item = 21
                BEGIN
				----Number Rejecte Batches (% per shift)
				declare @TotalBatches int=1
				  SELECT
					@TotalBatches = count(DISTINCT bd.BatchId)
				  FROM  #BatchData bd 
						INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1) 
														AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0)AND rf.Is_Deleted = 0							
					   LEFT JOIN tcd.RedFlagMappingData rfmd
					   ON rf.Id = rfmd.MappingId
					  AND rfmd.Is_Deleted = 0
				  WHERE (bd.MachineId = rfmd.MachineId OR rfmd.MachineId IS NULL )
					AND bd.ShiftId = @ShiftId
				--	AND bd.PartitionOn = @PartitionOn
					AND rf.Id = @Id;

                    SELECT
					@Value = (count(DISTINCT bp.BatchId)*1.0000/@TotalBatches)*100.00
				  FROM  #BatchData bd 
						INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1) 
														AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0)AND rf.Is_Deleted = 0	
						INNER JOIN TCD.BatchParameters	bp ON bp.BatchId = bd.BatchId AND bp.PartitionOn = bd.PartitionOn  
																AND BP.ParameterId = 18 AND BP.ParameterValue IN(2, 3)
					   LEFT JOIN tcd.RedFlagMappingData rfmd
					   ON rf.Id = rfmd.MappingId
					  AND rfmd.Is_Deleted = 0
				  WHERE (bd.MachineId = rfmd.MachineId OR rfmd.MachineId IS NULL )
					AND bd.ShiftId = @ShiftId
				--	AND bd.PartitionOn = @PartitionOn
					AND rf.Id = @Id;


                END	
				ELSE IF @Item = 30
                BEGIN
				--pH							 

					SELECT @Value = MAX( sr.Reading )
					FROM TCD.SensorReading sr 
					INNER JOIN TCD.Sensor s ON s.SensorId = sr.SensorId AND s.SensorType=2 
						AND s.Is_deleted=0 AND  (sr.Reading <@MinValue OR sr.Reading>@MaxValue)
						and  CONVERT (DATE, sr.[TimeStamp])  =@PartitionOn				


				END	
				ELSE IF @Item = 31
                BEGIN
				--Conductivity							 

					SELECT @Value = MAX( sr.Reading )
					FROM TCD.SensorReading sr 
					INNER JOIN TCD.Sensor s ON s.SensorId = sr.SensorId AND s.SensorType=4 
						AND s.Is_deleted=0 AND (sr.Reading <@MinValue OR sr.Reading>@MaxValue)
						and  CONVERT (DATE, sr.[TimeStamp])  =@PartitionOn				

				END	
				ELSE IF @Item = 32
                BEGIN
				--Redox
				 SELECT @Value = MAX( sr.Reading )
					FROM TCD.SensorReading sr 
					INNER JOIN TCD.Sensor s ON s.SensorId = sr.SensorId AND s.SensorType=3 
						AND s.Is_deleted=0 AND  (sr.Reading <@MinValue OR sr.Reading>@MaxValue)
						and  CONVERT (DATE, sr.[TimeStamp])  =@PartitionOn	

				END	
				ELSE IF @Item = 33
                BEGIN
				--Temperature
				SELECT @Value = MAX( sr.Reading )
					FROM TCD.SensorReading sr 
					INNER JOIN TCD.Sensor s ON s.SensorId = sr.SensorId AND s.SensorType=1 
						AND s.Is_deleted=0 AND  (sr.Reading <@MinValue OR sr.Reading>@MaxValue)
						and  CONVERT (DATE, sr.[TimeStamp])  =@PartitionOn	

				END	
				ELSE IF @Item = 29
                BEGIN
				--FF Cost Excess
				SELECT  @Value = sum ((bpd.Price/bd.ActualWeight)*100 -
					((CASE WHEN bpd.StandardQuantity=0 THEN 0
					ELSE (bpd.ActualQuantity/bpd.StandardQuantity)*bpd.Price END)/bd.ActualWeight)*100)

					FROM #BatchData bd
					INNER JOIN TCD.BatchProductData bpd ON bpd.BatchId = bd.BatchId AND bpd.EcolabWasherId = bd.EcolabWasherId 
								--AND bpd.PartitionOn = bd.PartitionOn
								AND bd.ActualWeight>0
					INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1) 
														AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0)AND rf.Is_Deleted = 0	
					LEFT JOIN tcd.RedFlagMappingData rfmd
					   ON rf.Id = rfmd.MappingId
					  AND rfmd.Is_Deleted = 0
					 WHERE (bd.MachineId = rfmd.MachineId OR rfmd.MachineId IS NULL)
					AND bd.ShiftId = @ShiftId
					--AND bd.PartitionOn = @PartitionOn
					AND rf.Id = @Id;				

				END	

			IF @Value IS NOT NULL 
			BEGIN
            IF (@MinValue <@Value or @MaxValue >@Value  )
                BEGIN

                    IF NOT EXISTS( SELECT
                                           1
                                     FROM TCD.RedFlagData rfd
                                     WHERE rfd.RedFlagId = @Id
                                       AND rfd.ShiftId = @ShiftId
                                      -- AND PartitionOn = @PartitionOn
                                 )
                        BEGIN
                            INSERT INTO TCD.RedFlagData(
                                    RedFlagId , 
                                    PlantId , 
                                    ShiftId , 
                                    RedFlagValue , 
                                    RedFlagMinSetPoint , 
                                    RedFlagMaxSetPoint , 
                                    PartitionOn
                                                       )
                            SELECT
                                    rf.Id , 
                                    @PlantId , 
                                    @ShiftId , 
                                    @Value , 
									rf.MinimumRange , 
                                    rf.MaximumRange ,                                  
                                    @PartitionOn
                              FROM TCD.RedFlag rf
                              WHERE rf.Id = @Id;

                        END;

                END;
			END

            SET @Counter = @Counter + 1;
		END
END
GO

 IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[RedFlagGenerationProductionEfficiency]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE [TCD].[RedFlagGenerationProductionEfficiency];
	END;
GO

CREATE PROCEDURE [TCD].[RedFlagGenerationProductionEfficiency]( @ShiftId int , 
                                                       @PartitionOn smalldatetime , 
                                                            @EcolabAccountNumber varchar( 1000))
AS
BEGIN

  DECLARE
       @Value decimal( 18 , 3) , 
    @UOMId int,
    @RegionId int,
       @PlantId int;

    SELECT
            @PlantId = PlantId
   ,@UOMId=UOMId
   ,@RegionId=RegionId
      FROM TCD.Plant p
      WHERE p.EcolabAccountNumber = @EcolabAccountNumber;

    DECLARE
       @Redflag TABLE(
            CounterId int IDENTITY( 1 , 1) , 
            Id int , 
            Item int
                     );

    DECLARE
       @MaxId int , 
       @Counter int , 
       @Item int , 
       @ShiftHrs float , 
       @Id int;

    
     DECLARE   --@DashBoardId INT = 2,
        @Efficiencytype INT,
 @OvernightBatchThreshold INT = 7200 -- mins


declare @RedflagTemp TABLE (Id INT,
Item INT,
MaximumRange decimal(18,3),
MinimumRange decimal(18,3),
Location INT,
RedFlagCategoryId INT,
FormulaId INT,
ProductId INT,
MeterId INT,
SensorId INT,
PlantId INT ,
MachineId INT)

INSERT INTO @RedflagTemp (Id ,
 Item ,
 MaximumRange ,
 MinimumRange ,
 Location ,
 RedFlagCategoryId ,
 FormulaId ,
 ProductId ,
 MeterId ,
 SensorId ,
 PlantId  ,
 MachineId )

SELECT rf.Id,
 Item,
 MaximumRange,
 MinimumRange,
 Location,
 RedFlagCategoryId,
 rf.FormulaId,
 ProductId,
 MeterId,
 SensorId,
 PlantId ,
 rfmd.MachineId
 
FROM TCD.RedFlag rf
LEFT JOIN tcd.RedFlagMappingData rfmd ON rfmd.MappingId = rf.Id
LEFT JOIN TCD.MachineSetup ms ON rfmd.MachineId=ms.WasherId
LEFT JOIN TCD.WasherGroup wg ON ms.GroupId= wg.WasherGroupId
LEFT JOIN TCD.ProgramMaster PM ON rf.FormulaId=PM.ProgramID
WHERE rf.Is_Deleted=0 and rfmd.Is_Deleted = 0 



    INSERT INTO @Redflag(Id, Item )
    SELECT
            rf.Id , 
            rf.Item
      FROM TCD.RedFlag rf
      WHERE rf.Is_Deleted = 0
        AND rf.RedFlagCategoryId in (1);

    SELECT
            @MaxId = ISNULL( MAX( CounterId) , 0)
      FROM @Redflag r;

    SET @Counter = 1;

 SELECT bd.*   
 INTO #BatchData  
 FROM tcd.BatchData bd (NOLOCK) 
 INNER JOIN TCD.MachineSetup ms  (NOLOCK)  on bd.MachineId=ms.WasherId AND isnull(ms.IsPony,0)=0
 WHERE bd.ShiftId =@ShiftId 
 --AND bd.StandardWeight > 0  
 --and bd.ActualWeight > 0   
 and bd.EndDate IS NOT NULL

 
 SELECT ms.EcoalabAccountNumber,    
                        ms.WasherId,    
                        ms.GroupId AS WasherGroupID,    
                        mg.WasherGroupTypeId AS WasherGroupTypeID,    
                        w.EcolabWasherId,    
                        ISNULL(ms.NumberOfComp,0) AS NumberOfComp,    
                        CASE    
                        WHEN MG.WASHERGROUPTYPEID = 1 THEN WSP.ProgramNumber    
                            ELSE TPS.ProgramNumber    
                        END AS ProgramNumber,    
                        CASE    
                        WHEN MG.WASHERGROUPTYPEID = 1 THEN WSP.ProgramId    
       ELSE TPS.ProgramId    
                        END AS ProgramId,    
                        CASE    
       WHEN MG.WASHERGROUPTYPEID = 1 
    THEN WSP.TotalRunTime    
                            ELSE TPS.TotalRunTime    
    
   END AS Standardruntime,
   w.PlantWasherNumber AS WasherNumber,
   ms.MachineName AS WasherName,
   mg.WasherGroupName AS MachineGroup,
   ms.IsTunnel
Into #BatchDataTurntime
                    FROM TCD.MachineSetup AS ms (NOLOCK)    
                        INNER JOIN TCD.Washer AS w (NOLOCK) ON w.EcoLabAccountNumber = ms.EcoalabAccountNumber    
                                                    AND w.WasherId = ms.WasherId    
                        INNER JOIN TCD.WasherGroup AS mg (NOLOCK) ON ms.GroupId = mg.WasherGroupId    
                                                        AND w.EcoLabAccountNumber = mg.EcolabAccountNumber    
                        LEFT OUTER JOIN TCD.WasherProgramSetup AS WSP (NOLOCK) ON WSP.WasherGroupId = mg.WasherGroupId    
                                                                    AND WSP.EcolabAccountNumber = mg.EcolabAccountNumber    
                                                                    --AND WSP.WasherGroupId = ms.GroupId    
                 AND WSP.Is_Deleted = 0
                        LEFT OUTER JOIN TCD.TunnelProgramSetup AS TPS (NOLOCK) ON TPS.WasherGroupId = mg.WasherGroupId    
                                                                    AND TPS.EcolabAccountNumber = mg.EcolabAccountNumber    
                                                                    --AND TPS.WasherGroupId = ms.GroupId 
                 AND TPS.Is_Deleted = 0 
   --WHERE ms.IsTunnel = 1
  
  
  SELECT TT.* INTO #Turntime
  FROM #BatchData BD
  LEFT JOIN TCD.Turntime TT
      ON BD.EcolabwasherID = TT.EcolabWasherId
      AND BD.batchid = TT.BatchID 

 SELECT  bd.BatchId,  
  bd.GroupID,
  bd.MachineID,
  bd.ShiftId,
  W_1.WasherNumber,
  W_1.WasherName,
  bd.ProgramNumber,
  bd.EcolabwasherID,
  bd.PartitionOn,
  BD.ProgramMasterId,

  (bd.ActualWeight + ISNULL(BD.ManualInputWeight,0)) AS ActualProduction,
  bd.StandardWeight AS StandardProduction,
  bd.StartDate,
  bd.EndDate,
  W_1.NumberOfComp,
  W_1.WasherGroupTypeID,
  --DATEDIFF(ss,bd.StartDate, bd.EndDate) AS ActualRunTime,
  --CASE WHEN DATEDIFF(mi,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OvernightBatchThreshold 
  CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OvernightBatchThreshold 
   THEN W_1.Standardruntime 
       ELSE DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
  END AS ActualRunTime,
  W_1.StandardRunTime StandardRunTime,
  TT.ACTUALTURNTIME AS ActualTurnTime,  
  (CASE WHEN W_1.WasherGroupTypeID = 1 THEN bd.TargetTurnTime ELSE 0 END) AS TargetTurnTime, 
  
    0 AS TimeEfficiency,
  ((CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS FLOAT)/CAST(NULLIF(bd.StandardWeight,0) AS FLOAT)) * 100) AS LoadEfficiency,
  
  0 TransferPerHr,

  0 AS MissedLoads,

  ((CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS decimal(18,6))/  nullif((nullif(CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS FLOAT)
        /nullif(CASE   CAST(NULLIF(bd.StandardWeight,0) AS FLOAT) WHEN 0 THEN 1 ELSE  CAST(NULLIF(bd.StandardWeight,0) AS FLOAT) END,0),0) * 100)   
  * (  CASE WHEN W_1.WasherGroupTypeID = 1   
      -- Conventional  
      THEN (CAST((W_1.Standardruntime + bd.TargetTurnTime)AS FLOAT) / nullif(CAST(CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > 7200  
                   THEN W_1.StandardRunTime  
                   ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
                  END + TT.ACTUALTURNTIME AS FLOAT),0) )  
      -- Tunnel  
      ELSE   
   0
                  
    END),0) ) *100 ) - CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS decimal(18,6)) AS LostLoadsDueToTurnTime,


  0 AS TotalEfficiency


INTO #BatchEfficiency
FROM #BatchData bd  
--FROM TCD.BatchData bd   
LEFT JOIN #BatchDataTurntime AS W_1 ON BD.GroupId = W_1.WasherGroupID    
       AND BD.MachineId = W_1.WasherId    
       AND BD.ProgramMasterId = W_1.ProgramId    
       AND BD.ProgramNumber = W_1.ProgramNumber
LEFT JOIN #Turntime TT
      ON BD.EcolabwasherID = TT.EcolabWasherId
      AND BD.batchid = TT.BatchID
--WHERE bd.ProgramNumber <> 0
  WHERE ISNULL(bd.ProgramMasterId,0) <> 0



/*  looping started*/
    WHILE  @Counter <=  @MaxId
        BEGIN
            SELECT
                    @Id = Id , 
                    @Item = Item
              FROM @Redflag r
              WHERE CounterId = @Counter;
          
            
            
           
              IF @Item = 1
                       BEGIN
    --Overall Efficiency (% per shift) (tatal efficeency)

   
      SELECT @Value = (( ( SUM(bd.ActualProduction) * 1.00 / SUM(ISNULL( bd.StandardProduction,0)) ) * 100 ) * SUM(ISNULL( bd.StandardRunTime, 0) + ISNULL( bd.TargetTurnTime, 0)) * 1.00 / SUM(ISNULL( bd.ActualRunTime, 0) + ISNULL( bd.ActualTurnTime, 0)))
           
      FROM #BatchEfficiency bd 
       LEFT JOIN @RedflagTemp rf ON(rf.Location = bd.GroupId OR rf.Location = 1) AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0 ) = 0)       
      WHERE(bd.MachineId = rf.MachineId  OR rf.MachineId IS NULL)
       AND bd.ShiftId = @ShiftId
          AND rf.Id = @Id;
     
     if (@Value=0)
     BEGIN
      SET @Value = NULL
     END

   END
            ELSE IF @Item = 2
      BEGIN
                --Run Time Efficiency (% per shift)--TimeEfficiency

                SELECT
                      --  @Value = SUM(isnull( TimeEfficiency,0))/100.00
       --@Value=sum(StandardRunTime)/cast( sum(ActualRunTime) as decimal(18,2))*100
	   @Value = SUM(bd.StandardRunTime + bd.TargetTurnTime) / CAST(SUM(bd.ActualRunTime + ISNULL(bd.ActualTurnTime,0)) AS decimal(18,2)) *100
                    FROM
                        #BatchEfficiency  bd 
      INNER JOIN @RedflagTemp rf ON(rf.Location = bd.GroupId  OR rf.Location = 1) AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0 ) = 0)  
                    WHERE(bd.MachineId = rf.MachineId  OR rf.MachineId IS NULL)
                    AND bd.ShiftId = @ShiftId
                   -- AND PartitionOn = @PartitionOn
                    AND rf.Id = @Id;

            END
   
            ELSE IF @Item = 3
                   BEGIN
                    --Turn Time Efficiency (% per shift) -- Turn time only avilble for Conventional
      SELECT
         @Value = sum(TargetTurnTime)/cast( sum(ActualTurnTime) as decimal(18,2)) *100
         FROM
           #BatchEfficiency bd           
           INNER JOIN @RedflagTemp rf ON(rf.Location = bd.GroupId OR rf.Location = 1) 
         WHERE ( bd.MachineId = rf.MachineId or rf.MachineId IS NULL)
        AND bd.ShiftId = @ShiftId
        --AND PartitionOn = @PartitionOn
        AND rf.Id = @Id;
     END
    ELSE IF @Item = 4
                    BEGIN
                    --Transfers / Hour (# per shift) --TransferPerHr
                    SELECT
                            @Value =round( 3600.00/(sum( ActualRunTime)/sum(NumberOfComp)),0)
                        FROM
                            #BatchEfficiency bd 
       INNER JOIN @RedflagTemp rf  ON(rf.Location = bd.GroupId  OR rf.Location = 1)  AND (bd.ProgramMasterId = rf.FormulaId
          OR ISNULL( rf.FormulaId , 0 ) = 0) 
                        WHERE ( bd.MachineId = rf.MachineId or rf.MachineId IS NULL)
                        AND bd.ShiftId = @ShiftId
      and bd.WasherGroupTypeID=2
                       -- AND PartitionOn = @PartitionOn
                        AND rf.Id = @Id;

                END
   IF @Item = 11
                BEGIN
      --Production vs Target (% per shift)
     declare @TargetProduction decimal(18,2) 
     select @TargetProduction=TargetProduction from TCD.ProductionShiftData where ShiftId =@ShiftId

                     SELECT   @Value = (SUM( bd.ActualProduction) /(case @TargetProduction when 0 then 1 else @TargetProduction end))/100.00
                              FROM
                                  #BatchEfficiency bd 
          INNER JOIN @RedflagTemp rf ON(rf.Location = bd.GroupId OR rf.Location = 1)  
                              WHERE bd.ShiftId = @ShiftId
                             --  AND PartitionOn = @PartitionOn
                               AND rf.Id = @Id;

                END
            ELSE IF @Item = 12
                        BEGIN
                            --Lost Capacity (CWT/Kg per shift) --MissedLoads

                            SELECT
                                    @Value = ( sum(bd.ActualProduction) / 
           (((sum(bd.ActualProduction)/sum( bd.StandardProduction))*100 )
           * sum(isnull( bd.StandardRunTime,0) +isnull( bd.TargetTurnTime,0))*1.00/sum(isnull( bd.ActualRunTime,0) +isnull( bd.ActualTurnTime,0) )))*100
           - sum(bd.ActualProduction)
                              FROM
                                  #BatchEfficiency bd 
          INNER JOIN @RedflagTemp rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
            AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0)                                                   
                              WHERE(bd.MachineId = rf.MachineId OR rf.MachineId IS NULL)
                               AND bd.ShiftId = @ShiftId
                             --  AND PartitionOn = @PartitionOn
                               AND rf.Id = @Id;
                        END
            ELSE IF @Item = 13
                        BEGIN
                                    --Production (CWT/Kg per hour)
                                    --SELECT
                                    --        @ShiftHrs = DATEDIFF( ss , sd.StartDateTime , sd.EndDateTime)/360.00
                                    --  FROM TCD.ProductionShiftData sd
                                    --  WHERE sd.ShiftId = @ShiftId;
           -- if EU Convert to lbs to kg
                                    SELECT
                                            @Value =   SUM( bd.ActualProduction) * (case @UOMId when 1 then 1 else 0.453592 end) --/ (case when @ShiftHrs =0 then 1 else @ShiftHrs end)
                                      FROM
                                           #BatchEfficiency bd 
             INNER JOIN @RedflagTemp rf ON(rf.Location = bd.GroupId OR rf.Location = 1)AND (bd.ProgramMasterId = rf.FormulaId
                 OR ISNULL( rf.FormulaId , 0) = 0) 
                                      WHERE(bd.MachineId = rf.MachineId OR rf.MachineId IS NULL)
                                       AND bd.ShiftId = @ShiftId
                                      -- AND PartitionOn = @PartitionOn
                                       AND rf.Id = @Id;
          

                                END
   ELSE IF @Item = 14
                        BEGIN
                        --Production Mix (% per shift)
                       
      SELECT
                            @Value =  convert( float,  sum(CASE  WHEN bd.ProgramMasterId = rf.FormulaId OR  ISNULL( rf.FormulaId , 0) = 0 THEN  bd.ActualProduction end)/convert(float,nullif(sum(sum(bd.ActualProduction))over(),0)))*100.00 
                        FROM
                            #BatchEfficiency bd 
       INNER JOIN @RedflagTemp rf ON(rf.Location = bd.GroupId OR rf.Location = 1) 
                        WHERE(bd.MachineId = rf.MachineId OR rf.MachineId IS NULL)
                        AND bd.ShiftId = @ShiftId
                       -- AND PartitionOn = @PartitionOn
                        AND rf.Id = @Id;
                    END
    ELSE IF @Item = 15
                        BEGIN
                    --Number of Loads (# per shift) (Count of bach ids)
                    --TODO

                    SELECT
                            @Value = COUNT( DISTINCT bd.BatchId )
                        FROM
                            #BatchEfficiency bd 
       INNER JOIN @RedflagTemp rf ON(rf.Location = bd.GroupId OR rf.Location = 1) AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0)
             
                        WHERE(bd.MachineId = rf.MachineId OR rf.MachineId IS NULL)
                        AND bd.ShiftId = @ShiftId
                        --AND PartitionOn = @PartitionOn
                        AND rf.Id = @Id;
                END
    ELSE IF @Item = 16
                        BEGIN
                  -- Load Efficiency (% per shift)

                    SELECT
                            @Value = (SUM(bd.ActualProduction)/cast( SUM(bd.StandardProduction) AS float)) *100.00

                        FROM
                            #BatchEfficiency bd 
       INNER JOIN @RedflagTemp rf ON(rf.Location = bd.GroupId OR rf.Location = 1) AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0)
             
                        WHERE(bd.MachineId = rf.MachineId OR rf.MachineId IS NULL)
                        AND bd.ShiftId = @ShiftId
                      --  AND PartitionOn = @PartitionOn
                        AND rf.Id = @Id;
                END
   ELSE IF @Item = 17
       BEGIN
                           --Average Run Time (time, avg per shift)--RunTime
        SELECT
         @Value = sum ( DATEDIFF(Minute,bd.StartDate, bd.EndDate) )/cast( COUNT(distinct bd.BatchId) as float)
         FROM
           #BatchEfficiency bd 
           INNER JOIN @RedflagTemp rf ON(rf.Location = bd.GroupId OR rf.Location = 1) 
                 AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0) 
         WHERE ( bd.MachineId = rf.MachineId or rf.MachineId IS NULL)
        AND bd.ShiftId = @ShiftId
       -- AND PartitionOn = @PartitionOn
        AND rf.Id = @Id;
                END
             ELSE IF @Item = 18
                  BEGIN
     --Lost Loads due to Turn Time (# per shift)-- Only convetional missed loads
     SELECT
       @Value = SUM(LostLoadsDueToTurnTime)
      FROM
       #BatchEfficiency bd 
       INNER JOIN @RedflagTemp rf  ON(rf.Location = bd.GroupId  OR rf.Location = 1)
             AND (bd.ProgramMasterId = rf.FormulaId  OR ISNULL( rf.FormulaId , 0  ) = 0)        
      WHERE(bd.MachineId = rf.MachineId  OR rf.MachineId IS NULL)
      AND bd.ShiftId = @ShiftId
      --AND PartitionOn = @PartitionOn
      AND rf.Id = @Id;
              END;
              ELSE IF @Item = 19
                   BEGIN
                        --Average Turn Time (time, avg per shift) 
                       SELECT
         @Value = (SUM ( bd.ActualTurnTime )/60)/cast( COUNT(DISTINCT bd.BATCHID) as float)
         FROM
            #BatchEfficiency bd           
           INNER JOIN @RedflagTemp rf ON(rf.Location = bd.GroupId OR rf.Location = 1) 
         WHERE (bd.MachineId = rf.MachineId or rf.MachineId IS NULL)
        AND bd.ShiftId = @ShiftId
       -- AND PartitionOn = @PartitionOn
        AND rf.Id = @Id;
                    END
             
               ELSE  IF @Item = 10
                  BEGIN
                    --Drying Efficiency
                    SET @Value = 0;
     END;
             
            IF @Value IS NOT NULL 
   BEGIN
            IF NOT EXISTS( SELECT
                                   1
                             FROM TCD.RedFlag rf
                             WHERE Id = @Id
                               AND rf.Is_Deleted = 0
                               AND rf.MinimumRange <= @Value
                               AND rf.MaximumRange >= @Value
                         )
                BEGIN

                    IF NOT EXISTS( SELECT
                                           1
                                     FROM TCD.RedFlagData rfd
                                     WHERE rfd.RedFlagId = @Id
                                       AND rfd.ShiftId = @ShiftId
                                             -- AND PartitionOn = @PartitionOn
                                 )
                        BEGIN
                            INSERT INTO TCD.RedFlagData(
                                    RedFlagId , 
                                    PlantId , 
                                    ShiftId , 
                                    RedFlagValue , 
                                    RedFlagMinSetPoint , 
                                    RedFlagMaxSetPoint , 
                                    PartitionOn
                                                       )
                            SELECT
                                    rf.Id , 
                                    @PlantId , 
                                    @ShiftId , 
                                    @Value , 
         rf.MinimumRange , 
                                    rf.MaximumRange ,                                     
                                    @PartitionOn
                              FROM TCD.RedFlag rf
                              WHERE rf.Id = @Id;

                        END;

                END;
   END

            SET @Counter = @Counter + 1;
        END;

DROP TABLE #BatchData
DROP TABLE #BatchEfficiency
DROP TABLE #BatchDataTurntime
DROP TABLE #Turntime
END;
GO

 IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[RedFlagGenerationResources]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE [TCD].[RedFlagGenerationResources];
	END;
GO

CREATE PROCEDURE [TCD].[RedFlagGenerationResources]
( @ShiftId int , 
                                                       @PartitionOn smalldatetime , 
                                                       @EcolabAccountNumber nvarchar( 25)
                                                     )
AS
BEGIN
 DECLARE
       @Value decimal( 18 , 3) , 
	   @UOMId int,
	   @RegionId int,
	   @PlantUOM varchar(100),
       @PlantId int;
 
    SELECT
            @PlantId = PlantId
			,@UOMId=UOMId
			,@RegionId=RegionId
      FROM TCD.Plant p
      WHERE p.EcolabAccountNumber = @EcolabAccountNumber;

    DECLARE
       @Redflag TABLE(
            CounterId int IDENTITY( 1 , 1) , 
            Id int , 
            Item int
                     );

    DECLARE
       @MaxId int , 
       @Counter int , 
       @Item int , 
       @ShiftHrs int , 
       @Id int;


    INSERT INTO @Redflag(Id,
            Item
                        )
    SELECT
            rf.Id , 
            rf.Item
      FROM TCD.RedFlag rf
      WHERE rf.Is_Deleted = 0
        AND rf.RedFlagCategoryId = 3;

    SELECT
            @MaxId = ISNULL( MAX( CounterId) , 0)
      FROM @Redflag r;

SELECT bd.*   
	INTO #BatchData  
	FROM tcd.BatchData bd (NOLOCK) 
	INNER JOIN TCD.MachineSetup ms  (NOLOCK)  on bd.MachineId=ms.WasherId AND   isnull(ms.IsPony,0)=0
	WHERE bd.ShiftId =@ShiftId 
	--AND bd.StandardWeight > 0  
	--and bd.ActualWeight > 0   
	and bd.EndDate IS NOT NULL



    SET @Counter = 1;

    WHILE @Counter  <= @MaxId
        BEGIN
            SELECT
                    @Id = Id , 
                    @Item = Item
              FROM @Redflag r
              WHERE CounterId = @Counter;

			   IF @Item = 6
                BEGIN
				--Water Usage (per CWT/Kg)
				-- if EU region convert gal to Liter 1 gal =3.78541178
				-- if EU region covert CWT to Kg( 1 cwt == 50.8023 KG)
                    SELECT  @Value=  sum( (bwe.ActualQuantity/(case bd.ActualWeight when 0 then 1 else bd.ActualWeight end))* (case @RegionId when 2 then 50.8023 else 1 end) * (case @RegionId when 2 then 1 else 3.78541178 end ))
					  FROM #BatchData bd
					   INNER JOIN TCD.[BatchStepWaterUsageData] bwe ON bd.BatchId=bwe.BatchId and bwe.EcolabWasherId=bd.EcolabWasherId
						INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
									--AND (bd.ProgramNumber = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0) AND rf.Is_Deleted = 0
						 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0
					  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
						AND bd.ShiftId = @ShiftId
						AND BD.PartitionOn = @PartitionOn
						AND rf.Id = @Id
                END
				ELSE   IF @Item = 7
                BEGIN
				--Energy Consumption (per CWT/Kg)
				/* utility type 1: gas 4: oil*/
				/* atual weight stored in data base is btu/cwt
				Oil:-(gallon(0.000008007), kilo_gallon, cubic_foot, cubic_meter,	liter(0.0000413))

				GAS:-(therm :therm(1.0002e-5),deca_therm:DTH(1.00024e-6),cubic_foot:ft�(0.001),btu:btu,cubic_meter:m�(0.00002746573))
				 */
				
				select @PlantUOM = m.AllowManualentry from TCD.Meter m where m.UtilityType in (1,4)

				   SELECT  @Value=  sum( ( case isnull(m.AllowManualentry,@PlantUOM) 
											when 'gallon' then (beud.ActualQuantity/(case ISNULL( bd.ActualWeight,0) when 0 then 1 else bd.ActualWeight end)) * 0.000008007
											when 'kilo_gallon' then (beud.ActualQuantity/(case ISNULL( bd.ActualWeight,0) when 0 then 1 else bd.ActualWeight end)) * 0.008007
											when 'cubic_foot' then (beud.ActualQuantity/(case ISNULL( bd.ActualWeight,0) when 0 then 1 else bd.ActualWeight end)) * 0.001
											when 'cubic_meter' then (beud.ActualQuantity/(case ISNULL( bd.ActualWeight,0) when 0 then 1 else bd.ActualWeight end)) * 0.00002746573
											when 'therm' then (beud.ActualQuantity/(case ISNULL( bd.ActualWeight,0) when 0 then 1 else bd.ActualWeight end)) * 1.0002e-5
											when 'deca_therm' then (beud.ActualQuantity/(case ISNULL( bd.ActualWeight,0) when 0 then 1 else bd.ActualWeight end)) * 1.00024e-6	
											else	(beud.ActualQuantity/(case ISNULL( bd.ActualWeight,0) when 0 then 1 else bd.ActualWeight end))									
											end)
				   
									* (case @RegionId when 1 then 100 else 1 end))
					  FROM #BatchData bd
					   INNER JOIN TCD.[BatchEnergyUsageData] beud ON beud.BatchId=bd.BatchId and beud.EcolabWasherId=bd.EcolabWasherId 
						INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
									--AND (bd.ProgramNumber = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0) AND rf.Is_Deleted = 0
						 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0
						 LEFT JOIN TCD.Meter m ON m.MeterId = RF.MeterId
					  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
						AND bd.ShiftId = @ShiftId
						AND BD.PartitionOn = @PartitionOn
						AND rf.Id = @Id

				END
				ELSE   IF @Item = 8
                BEGIN
				--Gas consumption
				--GasOilTypeId=1:Natural Gas,2:Propane
				/*
				GAS:-(therm :therm(1.0002e-5),deca_therm:DTH(1.00024e-6),cubic_foot:ft�(0.001),btu:btu,cubic_meter:m�(0.00002746573))
				*/
			
				select @PlantUOM = m.AllowManualentry from TCD.Meter m where m.UtilityType in (1)

				   SELECT  @Value=  sum( ( case isnull(m.AllowManualentry,@PlantUOM) 
											when 'gallon' then (beud.ActualQuantity/(case ISNULL( bd.ActualWeight,0) when 0 then 1 else bd.ActualWeight end)) * 0.000008007
											when 'kilo_gallon' then (beud.ActualQuantity/(case ISNULL( bd.ActualWeight,0) when 0 then 1 else bd.ActualWeight end)) * 0.008007
											when 'cubic_foot' then (beud.ActualQuantity/(case ISNULL( bd.ActualWeight,0) when 0 then 1 else bd.ActualWeight end)) * 0.001
											when 'cubic_meter' then (beud.ActualQuantity/(case ISNULL( bd.ActualWeight,0) when 0 then 1 else bd.ActualWeight end)) * 0.00002746573
											when 'therm' then (beud.ActualQuantity/(case ISNULL( bd.ActualWeight,0) when 0 then 1 else bd.ActualWeight end)) * 1.0002e-5
											when 'deca_therm' then (beud.ActualQuantity/(case ISNULL( bd.ActualWeight,0) when 0 then 1 else bd.ActualWeight end)) * 1.00024e-6	
											else	(beud.ActualQuantity/(case ISNULL( bd.ActualWeight,0) when 0 then 1 else bd.ActualWeight end))									
											end)
				   
									* (case @RegionId when 1 then 100 else 1 end))
						  FROM #BatchData bd
						   INNER JOIN TCD.[BatchEnergyUsageData] beud ON beud.BatchId=bd.BatchId and beud.EcolabWasherId=bd.EcolabWasherId  AND beud.GasOilTypeId IN (1,2)
							INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
										--AND (bd.ProgramNumber = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0) AND rf.Is_Deleted = 0
							 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0
							 LEFT JOIN TCD.Meter m ON m.MeterId = RF.MeterId
						  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
							AND bd.ShiftId = @ShiftId
							--AND BD.PartitionOn = @PartitionOn
							AND rf.Id = @Id

				END
				ELSE   IF @Item = 9
                BEGIN
				--Chemical Consumption (per CWT/Kg)
				DECLARE @actualproduction  decimal(18,2)
				 SELECT  @actualproduction= CASE @UOMId 
				 WHEN 1 THEN sum(ISNULL(BD.ActualWeight,0) )/100.00 
				 WHEN 2 THEN ISNULL([TCD].[FnConsumptionOnMetrics](sum(ISNULL(BD.ActualWeight,0)),'Weight',1),0) 
				END  
					  FROM #BatchData bd
					 
						INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
									AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0)									
									 AND rf.Is_Deleted = 0
						 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0
					  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
						AND bd.ShiftId = @ShiftId
						AND rf.Id = @Id

				   SELECT  @Value= sum (bpd.ActualQuantity)/@actualproduction
					  FROM #BatchData bd
					   INNER JOIN TCD.[BatchProductData] bpd ON bpd.BatchId=bd.BatchId and bpd.EcolabWasherId=bd.EcolabWasherId --and bpd.InjectionNumber=bd.ProgramMasterId
						INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
									AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0)
									AND (bpd.ProductId = rf.ProductId OR ISNULL( rf.ProductId , 0) = 0)
									 AND rf.Is_Deleted = 0
						 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0
					  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
						AND bd.ShiftId = @ShiftId
						--AND BD.PartitionOn = @PartitionOn
						AND rf.Id = @Id

				END
				ELSE   IF @Item = 25
                BEGIN
				--Chemical Consumption deviation  (%) measured >< standard
				 SELECT  @Value=  sum (bpd.ActualQuantity-bpd.StandardQuantity)/100.00
					  FROM #BatchData bd
					   INNER JOIN TCD.[BatchProductData] bpd ON bpd.BatchId=bd.BatchId and bpd.EcolabWasherId=bd.EcolabWasherId --and bpd.InjectionNumber=bd.ProgramMasterId
						INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
									--AND (bd.ProgramNumber = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0) AND rf.Is_Deleted = 0
						 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0
					  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
						AND bd.ShiftId = @ShiftId
						--AND BD.PartitionOn = @PartitionOn
						AND rf.Id = @Id

					IF @Value=0
					BEGIN
						SET @Value= null
					END

				END
				ELSE   IF @Item = 27
                BEGIN
				--Chemicals C&I
				    SELECT  @Value=  CI.DayBeforeOutOfStock
				  FROM [TCD].[ChemicalInventoryRollUp] CI 
					INNER JOIN TCD.RedFlag rf ON CI.ProductID = rf.ProductId
				  WHERE  rf.Id = @Id

				END


			IF @Value IS NOT NULL 
			BEGIN
            IF NOT EXISTS( SELECT
                                   1
                             FROM TCD.RedFlag rf
                             WHERE Id = @Id
                               AND rf.Is_Deleted = 0
                               AND rf.MinimumRange <= @Value
                               AND rf.MaximumRange >= @Value
                         )
                BEGIN

                    IF NOT EXISTS( SELECT
                                           1
                                     FROM TCD.RedFlagData rfd
                                     WHERE rfd.RedFlagId = @Id
                                       AND rfd.ShiftId = @ShiftId
                                       AND PartitionOn = @PartitionOn
                                 )
                        BEGIN
                            INSERT INTO TCD.RedFlagData(
                                    RedFlagId , 
                                    PlantId , 
                                    ShiftId , 
                                    RedFlagValue , 
                                    RedFlagMinSetPoint , 
                                    RedFlagMaxSetPoint , 
                                    PartitionOn
                                                       )
                            SELECT
                                    rf.Id , 
                                    @PlantId , 
                                    @ShiftId , 
                                    @Value , 
									rf.MinimumRange , 
                                    rf.MaximumRange ,                                    
                                    @PartitionOn
                              FROM TCD.RedFlag rf
                              WHERE rf.Id = @Id;

                        END;

                END;
			END

            SET @Counter = @Counter + 1;
		END
END
GO