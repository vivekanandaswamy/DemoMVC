﻿IF EXISTS(SELECT 1 FROM TCD.ControllerModelControllerTypeMapping cmctm WHERE cmctm.ControllerModelId = (SELECT id FROM TCD.ControllerModel WHERE name='myControl'))
BEGIN
UPDATE TCD.ControllerModelControllerTypeMapping 
SET NumOfConvWasherGroups = 0, NumOfTunnelWasherGroups = 0
WHERE ControllerModelId = (SELECT id FROM TCD.ControllerModel WHERE name='myControl')
END
GO


IF NOT EXISTS(SELECT * FROM sys.columns WHERE  object_id = OBJECT_ID(N'TCD.AlarmGroupMaster') AND name = 'AlarmNumber')
BEGIN
	ALTER TABLE TCD.AlarmGroupMaster 
	ADD AlarmNumber INT NULL
END

----Temp Table for Batch eject Seed data---
BEGIN 
DECLARE @tempBatchEjectCondition TABLE
(
	AlarmNumber INT NOT NULL,
	ControllerModelId INT NOT NULL,
	Description NVARCHAR(500) NOT NULL
)

INSERT INTO @tempBatchEjectCondition (AlarmNumber, ControllerModelId, Description)
VALUES
(1,11,'Error pH (Max-Time)'			  )						,
(2,11,'Error Conductivity (Max-Time)'  )						,
(3,11,'Error Temperature 1'			  )						,
(4,11,'Error Temperature 2'			  )						,
(5,11,'Error Temperature 3'			  )						,
(6,11,'Main-Equipment 1 V1 low-dose'	  )						,
(7,11,'Main-Equipment 1 V2 low-dose'	  )						,
(8,11,'Main-Equipment 1 V3 low-dose'	  )						,
(9,11,'Main-Equipment 1 V4 low-dose'	  )						,
(10,11,'Main-Equipment 1 V5 low-dose'	  )					,
(11,11,'Main-Equipment 1 V6 low-dose'	  )					,
(12,11,'Chemical Pump 1 low-dose'		  )					,
(13,11,'Chemical Pump 2 low-dose'		  )					,
(14,11,'Chemical Pump 3 low-dose'		  )					,
(15,11,'Chemical Pump 4 low-dose'		  )					,
(16,11,'Chemical Pump 5 low-dose'		  )					,
(17,11,'Chemical Pump 6 low-dose'		  )					,
(18,11,'Chemical Pump 7 low-dose'		  )					,
(19,11,'Chemical Pump 8 low-dose'		  )					,
(20,11,'Chemical Pump 9 low-dose'		  )					,
(21,11,'Chemical Pump 10 low-dose'	  )						,
(22,11,'Chemical Pump 11 low-dose'	  )						,
(23,11,'Chemical Pump 12 low-dose'	  )						,
(24,11,'Main-Equipment 2 V1 low-dose'	  )					,
(25,11,'Main-Equipment 2 V2 low-dose'	  )					,
(26,11,'Main-Equipment 2 V3 low-dose'	  )					,
(27,11,'Main-Equipment 2 V4 low-dose'	  )					,
(28,11,'Main-Equipment 2 V5 low-dose'	  )					,
(29,11,'Main-Equipment 2 V6 low-dose'	  )					,
(30,11,'Chemical Pump V1 low-dose'	  )						,
(31,11,'Chemical Pump V2 low-dose'	  )						,
(32,11,'Chemical Pump V3 low-dose'	  )						,
(33,11,'Chemical Pump V4 low-dose'	  )						,
(34,11,'Chemical Pump V5 low-dose'	  )						,
(35,11,'Chemical Pump V6 low-dose'	  )						,
(36,11,'Chemical Pump V7 low-dose'	  )						,
(37,11,'Chemical Pump V8 low-dose'	  )						,
---MyControl--												
(1,7,'Emergency / Air pressure / Low voltage alarm')		,
(2,7,'Flush water alarm'							)		,
(3,7,'Flush leak alarm'							)		,
(4,7,'Helms communication timout'					)		,
(5,7,'Connex Alarm'								)		,
(6,7,'Flush system max time alarm'					)		,
(7,7,'Flush system low level alarm'				)		,
(8,7,'Air pressure alarm'							)		,
(9,7,'Emergency stop alarm'						)		,
(10,7,'Low level P1'								)		,
(11,7,'Low level P2'								)		,
(12,7,'Low level P3'								)		,
(13,7,'Low level P4'								)		,
(14,7,'Low level P5'								)		,
(15,7,'Low level P6'								)		,
(16,7,'Low level P7'								)		,
(17,7,'Low level P8'								)		,
(18,7,'Low level P9'								)		,
(19,7,'Low level P10'								)		,
(20,7,'Low level P11'								)		,
(21,7,'Low level P12'								)		,
(22,7,'Low level P13'								)		,
(23,7,'Low level P14'								)		,
(24,7,'Low level ME1'								)		,
(25,7,'Low level ME2'								)		,
(26,7,'Maximum dosing time P1'						)		,
(27,7,'Maximum dosing time P2'						)		,
(28,7,'Maximum dosing time P3'						)		,
(29,7,'Maximum dosing time P4'						)		,
(30,7,'Maximum dosing time P5'						)		,
(31,7,'Maximum dosing time P6'						)		,
(32,7,'Maximum dosing time P7'						)		,
(33,7,'Maximum dosing time P8'						)		,
(34,7,'Maximum dosing time P9'						)		,
(35,7,'Maximum dosing time P10'						)	,
(36,7,'Maximum dosing time P11'						)	,
(37,7,'Maximum dosing time P12'						)	,
(38,7,'Maximum dosing time P13'						)	,
(39,7,'Maximum dosing time P14'						)	,
(40,7,'Maximum dosing time P15'						)	,
(41,7,'Maximum dosing time P16'						)	,
(42,7,'Maximum dosing time P17'						)	,
(43,7,'Maximum dosing time P18'						)	,
(44,7,'Maximum dosing time P19'						)	,
(45,7,'Maximum dosing time P20'						)	,
(46,7,'Maximum dosing time P21'						)	,
(47,7,'Maximum dosing time P22'						)	,
(48,7,'Maximum dosing time P23'						)	,
(49,7,'Maximum dosing time P24'						)	,
(50,7,'Maximum dosing time ME1'						)	,
(51,7,'Maximum dosing time ME2'						)	,
(52,7,'Flowswitch alarm P1'							)	,
(53,7,'Flowswitch alarm P2'							)	,
(54,7,'Flowswitch alarm P3'							)	,
(55,7,'Flowswitch alarm P4'							)	,
(56,7,'Flowswitch alarm P5'							)	,
(57,7,'Flowswitch alarm P6'							)	,
(58,7,'Flowswitch alarm P7'							)	,
(59,7,'Flowswitch alarm P8'							)	,
(60,7,'Flowswitch alarm P9'							)	,
(61,7,'Flowswitch alarm P10'						)		,
(62,7,'Flowswitch alarm P11'						)		,
(63,7,'Flowswitch alarm P12'						)		,
(64,7,'Flowswitch alarm P13'						)		,
(65,7,'Flowswitch alarm P14'						)		,
(66,7,'Flowswitch alarm P15'						)		,
(67,7,'Flowswitch alarm P16'						)		,
(68,7,'Flowswitch alarm P17'						)		,
(69,7,'Flowswitch alarm P18'						)		,
(70,7,'Flowswitch alarm P19'						)		,
(71,7,'Flowswitch alarm P20'						)		,
(72,7,'Flowswitch alarm P21'						)		,
(73,7,'Flowswitch alarm P22'						)		,
(74,7,'Flowswitch alarm P23'						)		,
(75,7,'Flowswitch alarm P24'						)		,
(76,7,'Flowswitch alarm ME1'						)		,
(77,7,'Flowswitch alarm ME2'						)		,
(78,7,'Leakage alarm P1'							)		,
(79,7,'Leakage alarm P2'							)		,
(80,7,'Leakage alarm P3'							)		,
(81,7,'Leakage alarm P4'							)		,
(82,7,'Leakage alarm P5'							)		,
(83,7,'Leakage alarm P6'							)		,
(84,7,'Leakage alarm P7'							)		,
(85,7,'Leakage alarm P8'							)		,
(86,7,'Leakage alarm P9'							)		,
(87,7,'Leakage alarm P10'							)		,
(88,7,'Leakage alarm P11'							)		,
(89,7,'Leakage alarm P12'							)		,
(90,7,'Leakage alarm P13'							)		,
(91,7,'Leakage alarm P14'							)		,
(92,7,'Leakage alarm P15'							)		,
(93,7,'Leakage alarm P16'							)		,
(94,7,'Leakage alarm P17'							)		,
(95,7,'Leakage alarm P18'							)		,
(96,7,'Leakage alarm P19'							)		,
(97,7,'Leakage alarm P20'							)		,
(98,7,'Leakage alarm P21'							)		,
(99,7,'Leakage alarm P22'							)		,
(100,7,'Leakage alarm P23'							)		,
(101,7,'Leakage alarm P24'							)		,
(102,7,'Leakage alarm ME1'							)		,
(103,7,'Leakage alarm ME2'							)		,
(104,7,'ME1 main switch off'							)	,
(105,7,'ME1 Pump / Agitator alarm'					)		,
(106,7,'ME1 Water pressure alarm'					)		,
(107,7,'ME1 Overflow'								)		,
(108,7,'ME1 Need to fill'							)		,
(109,7,'ME2 main switch off'							)	,
(110,7,'ME2 Pump / Agitator alarm'					)		,
(111,7,'ME2 Water pressure alarm'					)		,
(112,7,'ME2 Overflow'								)		,
(113,7,'ME2 Need to fill'							)		,
(114,7,'Low level alarm on analog level P1'			)	,
(115,7,'Low level alarm on analog level P2'			)	,
(116,7,'Low level alarm on analog level P3'			)	,
(117,7,'Low level alarm on analog level P4'			)	,
(118,7,'Low level alarm on analog level P5'			)	,
(119,7,'Low level alarm on analog level P6'			)	,
(120,7,'Low level alarm on analog level P7'			)	,
(121,7,'Low level alarm on analog level P8'			)	,
(122,7,'Low level alarm on analog level P9'			)	,
(123,7,'Low level alarm on analog level P10'			)	,
(124,7,'Low level alarm on analog level P11'			)	,
(125,7,'Low level alarm on analog level P12'			)	,
(126,7,'Low level alarm on analog level P13'			)	,
(127,7,'Low level alarm on analog level P14'			)	,
(128,7,'Low level alarm on analog level ME1'			)	,
(129,7,'Low level alarm on analog level ME2'			)	,
(130,7,'High level alarm on analog level P1'			)	,
(131,7,'High level alarm on analog level P2'			)	,
(132,7,'High level alarm on analog level P3'			)	,
(133,7,'High level alarm on analog level P4'			)	,
(134,7,'High level alarm on analog level P5'			)	,
(135,7,'High level alarm on analog level P6'			)	,
(136,7,'High level alarm on analog level P7'			)	,
(137,7,'High level alarm on analog level P8'			)	,
(138,7,'High level alarm on analog level P9'			)	,
(139,7,'High level alarm on analog level P10'		)		,
(140,7,'High level alarm on analog level P11'		)		,
(141,7,'High level alarm on analog level P12'		)		,
(142,7,'High level alarm on analog level P13'		)		,
(143,7,'High level alarm on analog level P14'		)		,
(144,7,'High level alarm on analog level ME1'		)		,
(145,7,'High level alarm on analog level ME2'		)		,
(146,7,'Smtp function error'							)	,
(147,7,'Level dip tray alarm'						)		,
(148,7,'No program detection'						)		,
(149,7,'TOM signal alarm'							)		,
(150,7,'pH too low alarm'							)		,
(151,7,'pH too high alarm'							)		,
(152,7,'pH maximum time alarm'						)		,
(153,7,'Temperature 1 too low alarm'					)	,
(154,7,'Temperature 2 too low alarm'					)	,
(155,7,'Temperature 3 too low alarm'					)	,
(156,7,'Temperature 4 too low alarm'					)	,
(157,7,'Temperature 5 too low alarm'					)	,
(158,7,'Temperature 6 too low alarm'					)	,
(159,7,'LF too low alarm'							)		,
(160,7,'LF too high alarm'							)		,
(161,7,'LF maximum time alarm'						)		,
(162,7,'ORP too low alarm'							)


MERGE	TCD.BatchEjectCondition			AS			TARGET
USING	@tempBatchEjectCondition		AS			SOURCE
ON	TARGET.AlarmNumber		=	SOURCE.AlarmNumber AND TARGET.ControllerModelId = SOURCE.ControllerModelId AND TARGET.DESCRIPTION = SOURCE.DESCRIPTION
WHEN	NOT MATCHED		THEN
INSERT	(AlarmNumber, ControllerModelId,DESCRIPTION)
VALUES	(SOURCE.AlarmNumber	,SOURCE.ControllerModelId	 ,SOURCE.DESCRIPTION	);

END
GO

/*for issue 115763  RW: REG: User Role Access : User Level Roles below 6 should not be able to access Washer Group and Wash formula*/

update A set settingvalue='false' 
from [TCD].conduitmenurolemapping A where userrole <6 and settingvalue='true' 
and SectionCode in ('WASHERGROUPS','WASHER') 

/*Issue 106160:RW: Rename label "Max Load" to Washer Capacity" in conventional washer*/
IF EXISTS(SELECT * FROM TCD.ResourceKeyValue rkv WHERE rkv.KeyName='FIELD_PLEASEENTERMAXIMUMLOAD' AND rkv.[Value]='Please enter Max Load')
BEGIN
UPDATE TCD.ResourceKeyValue
SET  
   [Value] = 'Please enter Washer Capacity',   
    LastModifiedTime = getutcdate()  WHERE KeyName='FIELD_PLEASEENTERMAXIMUMLOAD' AND [Value]='Please enter Max Load'
END
GO

IF EXISTS(SELECT 1 FROM TCD.FIELD WHERE LABEL = 'ControllerName')
BEGIN
UPDATE TCD.FIELD SET LABEL = 'Controller Name' WHERE LABEL = 'ControllerName'
END
GO

UPDATE TCD.Field	SET HasFieldTag='Tag_EC', DefaultFieldTag = 'x_Connex_En'		WHERE Id = 214
UPDATE TCD.Field	SET HasFieldTag='Tag_CAD', DefaultFieldTag = 'uint_Connex_Alarm_Delay'		WHERE Id = 215
UPDATE TCD.Field	SET HasFieldTag='Tag_HCAL', DefaultFieldTag = 'uint_Connex_Level_Delay'		WHERE Id = 216
UPDATE TCD.Field	SET HasFieldTag='Tag_EnvEnbl', DefaultFieldTag = 'x_PMREn'		WHERE Id = 217
UPDATE TCD.Field	SET HasFieldTag='Tag_CWF', DefaultFieldTag = 'x_FlushControlEn'	WHERE Id = 218
UPDATE TCD.Field	SET HasFieldTag='Tag_EnvTOE', DefaultFieldTag = 'x_HelmsTimoutEn'	WHERE Id = 219
UPDATE TCD.Field	SET HasFieldTag='Tag_CFLA', DefaultFieldTag = 'x_FlushLeakEn'	WHERE Id = 220
UPDATE TCD.Field	SET HasFieldTag='Tag_EnvTA', DefaultFieldTag = 'uint_HelmsTimout'	WHERE Id = 221
UPDATE TCD.Field	SET HasFieldTag='Tag_ERB', DefaultFieldTag = 'x_Reset_Button_En'	WHERE Id = 222
UPDATE TCD.Field	SET HasFieldTag='Tag_DPNFA', DefaultFieldTag = 'x_AlmPrgNotFinishDis'	WHERE Id = 223
UPDATE TCD.Field	SET HasFieldTag='Tag_ART', DefaultFieldTag = 'uint_ResetAlrmTime'	WHERE Id = 224
UPDATE TCD.Field	SET HasFieldTag='Tag_STB', DefaultFieldTag = 'uint_StopDubixTime'	WHERE Id = 225
UPDATE TCD.Field	SET HasFieldTag='Tag_SAPESA', DefaultFieldTag = 'x_SeparateAirStopAlarm'	WHERE Id = 226
UPDATE TCD.Field	SET HasFieldTag='Tag_IRT', DefaultFieldTag = 'uint_IntermRinseTime'	WHERE Id = 227
UPDATE TCD.Field	SET HasFieldTag='Tag_IMS', DefaultFieldTag = 'x_invertMachineStop'	WHERE Id = 228
UPDATE TCD.Field	SET HasFieldTag='Tag_FGAAV', DefaultFieldTag = 'uint_AlarmAnalogFilter'	WHERE Id = 229
UPDATE TCD.Field	SET HasFieldTag='Tag_ADTE', DefaultFieldTag = 'x_AlarmRackLeakageEnable'	WHERE Id = 230
UPDATE TCD.Field	SET HasFieldTag='Tag_L1', DefaultFieldTag = 'uint_LinetoWaterFS[1]'	WHERE Id = 231
UPDATE TCD.Field	SET HasFieldTag='Tag_L2', DefaultFieldTag = 'uint_LinetoWaterFS[2]'	WHERE Id = 232
UPDATE TCD.Field	SET HasFieldTag='Tag_L3', DefaultFieldTag = 'uint_LinetoWaterFS[3]'	WHERE Id = 233
UPDATE TCD.Field	SET HasFieldTag='Tag_L4', DefaultFieldTag = 'uint_LinetoWaterFS[4]'	WHERE Id = 234
UPDATE TCD.Field	SET HasFieldTag='Tag_L5', DefaultFieldTag = 'uint_LinetoWaterFS[5]'	WHERE Id = 235
UPDATE TCD.Field	SET HasFieldTag='Tag_L6', DefaultFieldTag = 'uint_LinetoWaterFS[6]'	WHERE Id = 236
UPDATE TCD.Field	SET HasFieldTag='Tag_L7', DefaultFieldTag = 'uint_LinetoWaterFS[7]'	WHERE Id = 237
UPDATE TCD.Field	SET HasFieldTag='Tag_L8', DefaultFieldTag = 'uint_LinetoWaterFS[8]'	WHERE Id = 238
UPDATE TCD.Field	SET HasFieldTag='Tag_L9', DefaultFieldTag = 'uint_LinetoWaterFS[9]'	WHERE Id = 239
UPDATE TCD.Field	SET HasFieldTag='Tag_L10', DefaultFieldTag = 'uint_LinetoWaterFS[10]'	WHERE Id = 240
UPDATE TCD.Field	SET HasFieldTag='Tag_L11', DefaultFieldTag = 'uint_LinetoWaterFS[11]'	WHERE Id = 241
UPDATE TCD.Field	SET HasFieldTag='Tag_L12', DefaultFieldTag = 'uint_LinetoWaterFS[12]'	WHERE Id = 242
UPDATE TCD.Field	SET HasFieldTag='Tag_L13', DefaultFieldTag = 'uint_LinetoWaterFS[13]'	WHERE Id = 243
UPDATE TCD.Field	SET HasFieldTag='Tag_L14', DefaultFieldTag = 'uint_LinetoWaterFS[14]'	WHERE Id = 244
UPDATE TCD.Field	SET HasFieldTag='Tag_L15', DefaultFieldTag = 'uint_LinetoWaterFS[15]'	WHERE Id = 245
UPDATE TCD.Field	SET HasFieldTag='Tag_L16', DefaultFieldTag = 'uint_LinetoWaterFS[16]'	WHERE Id = 246
UPDATE TCD.Field	SET HasFieldTag='Tag_Line1', DefaultFieldTag = 'x_LineDosingMode[1]'	WHERE Id = 247
UPDATE TCD.Field	SET HasFieldTag='Tag_DLM1', DefaultFieldTag = 'x_LineDosingMode[1]'	WHERE Id = 248
UPDATE TCD.Field	SET HasFieldTag='Tag_EAP1', DefaultFieldTag = 'x_AuxiliaryPumpUsed[1]'	WHERE Id = 249
UPDATE TCD.Field	SET HasFieldTag='Tag_FMFC1', DefaultFieldTag = 'x_UseFlowMeter_for_FlowCheck[1]'	WHERE Id = 250
UPDATE TCD.Field	SET HasFieldTag='Tag_NPCT1', DefaultFieldTag = 'uint_TCR_PumpNb[1]'	WHERE Id = 251
UPDATE TCD.Field	SET HasFieldTag='Tag_Line2', DefaultFieldTag = 'x_LineDosingMode[2]'	WHERE Id = 252
UPDATE TCD.Field	SET HasFieldTag='Tag_DLM2', DefaultFieldTag = 'x_LineDosingMode[2]'	WHERE Id = 253
UPDATE TCD.Field	SET HasFieldTag='Tag_EAP2', DefaultFieldTag = 'x_AuxiliaryPumpUsed[2]'	WHERE Id = 254
UPDATE TCD.Field	SET HasFieldTag='Tag_FMFC2', DefaultFieldTag = 'x_UseFlowMeter_for_FlowCheck[2]'	WHERE Id = 255
UPDATE TCD.Field	SET HasFieldTag='Tag_NPCT2', DefaultFieldTag = 'uint_TCR_PumpNb[2]'	WHERE Id = 256
UPDATE TCD.Field	SET HasFieldTag='Tag_Line3', DefaultFieldTag = 'x_LineDosingMode[3]'	WHERE Id = 257
UPDATE TCD.Field	SET HasFieldTag='Tag_DLM3', DefaultFieldTag = 'x_LineDosingMode[3]'	WHERE Id = 258
UPDATE TCD.Field	SET HasFieldTag='Tag_EAP3', DefaultFieldTag = 'x_AuxiliaryPumpUsed[3]'	WHERE Id = 259
UPDATE TCD.Field	SET HasFieldTag='Tag_FMFC3', DefaultFieldTag = 'x_UseFlowMeter_for_FlowCheck[3]'	WHERE Id = 260
UPDATE TCD.Field	SET HasFieldTag='Tag_NPCT3', DefaultFieldTag = 'uint_TCR_PumpNb[3]'	WHERE Id = 261
GO