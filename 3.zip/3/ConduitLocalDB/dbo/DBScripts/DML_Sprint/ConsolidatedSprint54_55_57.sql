DECLARE @ControllerModelControllerTypeMappingId INT
DECLARE @id TinyINT


DECLARE UpdateWasherModeNumber CURSOR FOR
	 SELECT DISTINCT ControllerModelControllerTypeMappingId FROM TCD.WasherModeMapping

OPEN UpdateWasherModeNumber

FETCH NEXT FROM UpdateWasherModeNumber INTO @ControllerModelControllerTypeMappingId
	WHILE @@FETCH_STATUS = 0
BEGIN    
	SET @id = 0 
	UPDATE TCD.WasherModeMapping SET @id = WasherModeNumber = @id + 1 WHERE ControllerModelControllerTypeMappingId = @ControllerModelControllerTypeMappingId
	FETCH NEXT FROM UpdateWasherModeNumber INTO @ControllerModelControllerTypeMappingId 
END

CLOSE UpdateWasherModeNumber 
DEALLOCATE UpdateWasherModeNumber
Go

IF NOT EXISTS (SELECT 1 FROM TCD.WasherFlushType where WasherFlushTypeId IN (3,4))
BEGIN
INSERT INTO TCD.WasherFlushType
(
    TCD.WasherFlushType.WasherFlushTypeId,
    TCD.WasherFlushType.WasherFlushType
)
VALUES
(
    3, -- WasherFlushTypeId - int
    N'Water(Valve)' -- WasherFlushType - nvarchar
)

INSERT INTO TCD.WasherFlushType
(
    TCD.WasherFlushType.WasherFlushTypeId,
    TCD.WasherFlushType.WasherFlushType
)
VALUES
(
    4, -- WasherFlushTypeId - int
    N'Water(ME)' -- WasherFlushType - nvarchar
)
END
GO


IF EXISTS (SELECT 1 FROM tcd.controllertype where name='5 Washers 1 Tunnel')
BEGIN
Update tcd.controllertype set name='1 Tunnel 5 Washers' where name='5 Washers 1 Tunnel';
END
GO

IF EXISTS(SELECT 1 FROM TCD.ControllerModelControllerTypeMapping cmctm WHERE cmctm.ControllerModelId IN (7,8,11))
BEGIN
-- MyControl id = 7
UPDATE TCD.ControllerModelControllerTypeMapping 
SET 
	NumOfTunnelDosingLines					=	16
,	NumOfConvDosingLines					=	12
,	MaxNumOfTOMEquipmentForTunnel			=	22
,	MaxNumOfTOMDosingPointForTunnel			=	22
,	MaxNumOfTOMEquipmentForConventional		=	12
,	MaxNumOfTOMDosingPointForConventional	=	0 
WHERE
	ControllerModelId						=	7

-- E-Control plus id=8
UPDATE TCD.ControllerModelControllerTypeMapping 
SET 
	MaxNumOfValvesForConventional			=	8
,	MaxNumOfValvesForTunnel					=	8
,	MaxNumOfMEForConventional				=	2
,	MaxNumOfMEForTunnel						=	2 
,	MaxNumOfTOMEquipmentForTunnel			=	22
,	MaxNumOfTOMDosingPointForTunnel			=	22
,	MaxNumOfTOMEquipmentForConventional		=	0
,	MaxNumOfTOMDosingPointForConventional	=	0 
WHERE
	ControllerModelId						=	8 

--plc xl id=11
UPDATE TCD.ControllerModelControllerTypeMapping 
SET 
	MaxNumOfValvesForConventional	=	1
,	MaxNumOfValvesForTunnel			=	5
,	MaxNumOfMEForConventional		=	2
,	MaxNumOfMEForTunnel				=	2
WHERE
	ControllerModelId				=	11
END
GO

Update TCD.ControllerModelControllerTypeMapping SET PumpValveCount = 8, MECount = 2 WHERE ControllerModelId = 8
Update TCD.ControllerModelControllerTypeMapping SET PumpValveCount = 12, MECount = 2 WHERE ControllerModelId = 11
GO

IF EXISTS(SELECT 1 FROM TCD.ControllerModelControllerTypeMapping cmctm WHERE cmctm.ControllerModelId IN (9,10,14))
BEGIN
-- E-Control Decentral id=14
UPDATE TCD.ControllerModelControllerTypeMapping 
SET 
	MaxNumOfValvesForConventional	=	0
,	MaxNumOfValvesForTunnel			=	0
,	MaxNumOfMEForConventional		=	1
,	MaxNumOfMEForTunnel				=	1 
,	MaxNumOfTOMEquipmentForTunnel	=	12
WHERE
	ControllerModelId				=	14 

-- E-Control Central id=9
UPDATE TCD.ControllerModelControllerTypeMapping 
SET 
	MaxNumOfValvesForConventional	=	6
,	MaxNumOfValvesForTunnel			=	6
,	MaxNumOfMEForConventional		=	1
,	MaxNumOfMEForTunnel				=	1 
,	MaxNumOfTOMEquipmentForTunnel	=	12
,	MaxNumOfTOMDosingPointForTunnel	=	12

WHERE
	ControllerModelId				=	9 

--ecodose id=10
UPDATE TCD.ControllerModelControllerTypeMapping 
SET 
	MaxNumOfValvesForConventional	=	3
,	MaxNumOfValvesForTunnel			=	0
,	MaxNumOfMEForConventional		=	0
,	MaxNumOfMEForTunnel				=	0
WHERE
	ControllerModelId				=	10 
END
GO

	--Declare temp table variable to hold input data
	DECLARE	@tempResourceKeyMaster	TABLE	(
	TempId					INT				IDENTITY(1, 1)
,	ResourceId				INT				PRIMARY	KEY
,	[Key]					NVARCHAR(100)
)

GO

IF NOT EXISTS (SELECT 1 FROM TCD.TunnelAnalogControlLevelType taclt WHERE taclt.TunnelAnalogControlLevelTypeID IN (1,2))
BEGIN
INSERT INTO TCD.TunnelAnalogControlLevelType
(
    TCD.TunnelAnalogControlLevelType.TunnelAnalogControlLevelTypeName
)
VALUES
(
    'PH' 
)
INSERT INTO TCD.TunnelAnalogControlLevelType
(
    TCD.TunnelAnalogControlLevelType.TunnelAnalogControlLevelTypeName
)
VALUES
(
    'Conductivity' 
)
END
ELSE
BEGIN
UPDATE TCD.TunnelAnalogControlLevelType
SET
    TCD.TunnelAnalogControlLevelType.TunnelAnalogControlLevelTypeName = 'PH' WHERE TCD.TunnelAnalogControlLevelType.TunnelAnalogControlLevelTypeID = 1
UPDATE TCD.TunnelAnalogControlLevelType
SET
    TCD.TunnelAnalogControlLevelType.TunnelAnalogControlLevelTypeName = 'Conductivity' WHERE TCD.TunnelAnalogControlLevelType.TunnelAnalogControlLevelTypeID = 2
END
GO

DECLARE	@tempControllerModel	TABLE	(
		TempId						INT				IDENTITY(1, 1)
	,	Id							INT				NOT	NULL
	,	Name						NVARCHAR(50)
	,	RegionId					INT
	,	Active						BIT
	,	[Version]					INT
	,	DisplayOrder				INT
	)

--Populate temp table variable with the input data
INSERT	@tempControllerModel	(
		Id,Name,RegionId,Active,[Version],DisplayOrder)
VALUES	(14,'E-Control Decentral',1,1,1,14 )

MERGE	[TCD].ControllerModel	AS TARGET
USING	@tempControllerModel	AS SOURCE
	ON	TARGET.Id				=			SOURCE.Id
WHEN	NOT MATCHED		THEN
		INSERT	(Id,Name,RegionId,Active,[Version],DisplayOrder)
		VALUES	(SOURCE.Id,SOURCE.Name,SOURCE.RegionId,SOURCE.Active,SOURCE.[Version],SOURCE.DisplayOrder	);
IF NOT EXISTS (SELECT CMRM.* FROM TCD.ControllerModelRegionMapping AS CMRM 
			 WHERE CMRM.ControllerModelId = 13 AND CMRM.RegionId = 2 AND CMRM.DisplayOrder =13)
BEGIN
    INSERT INTO [TCD].ControllerModelRegionMapping (ControllerModelId, RegionId, DisplayOrder) 
    VALUES (13, 2,13)
END
GO

IF NOT EXISTS (SELECT CMRM.* FROM TCD.ControllerModelRegionMapping AS CMRM 
			 WHERE CMRM.ControllerModelId = 14 AND CMRM.RegionId = 2 AND CMRM.DisplayOrder = 7)
BEGIN
    INSERT INTO [TCD].ControllerModelRegionMapping (ControllerModelId, RegionId, DisplayOrder) 
    VALUES (14, 2, 7)
END
GO

IF NOT EXISTS (SELECT CMRM.* FROM TCD.ControllerModelRegionMapping AS CMRM 
			 WHERE CMRM.ControllerModelId = 14 AND CMRM.RegionId = 1 AND CMRM.DisplayOrder = 14)
BEGIN
    INSERT INTO [TCD].ControllerModelRegionMapping (ControllerModelId, RegionId, DisplayOrder) 
    VALUES (14, 1, 14)
END
GO

UPDATE tcd.controllermodel SET name='E-Control Central' WHERE id=9

UPDATE tcd.ControllerModelControllerTypeMapping 
SET controllermodelid=14 WHERE ControllerModelId=9 and ControllerTypeId in (9,11)

UPDATE TCD.ControllerModelControllerTypeMapping 
SET ControllerTypeId = 6, NumOfConvWasherGroups = 1, NumOfTunnelWasherGroups = 0 WHERE ControllerModelId = 10

UPDATE tcd.ControllerType set name='6 Washers' where id=8
UPDATE tcd.ControllerType set name='4 Washers' where id=9
UPDATE tcd.ControllerType set name='1 Tunnel 4 Washers' where id=10
UPDATE tcd.ControllerType set name='1 Tunnel 2 Washers' where id=11

GO


DECLARE	@tempFieldGroup			TABLE	(
TempId					INT				IDENTITY(1, 1)
,	Id						INT				NOT	NULL
,	Name					NVARCHAR(250)	NOT	NULL
,	Image_Url				NVARCHAR(250)
,	ControllerModelId		SMALLINT
,	FieldGroupTypeId		INT
,	DisplayOrder			INT
,	HelpText				NVARCHAR(250)
,	TabId					INT
,	ResourceKey				NVARCHAR(250)
,	ControllerTypeId		INT
)


--Populate temp table variable with the input data
INSERT	@tempFieldGroup	(
Id			,Name				,Image_Url		,ControllerModelId	,FieldGroupTypeId		,DisplayOrder
,	HelpText	,TabId				,ResourceKey	,ControllerTypeId)
VALUES	(1	,N'Conduit Field Group1',	NULL	,0	,1	,1,	NULL	,2	,N'FieldGroup_ConduitFieldGroup1'	,NULL	)
,	(2	,N'Conduit Field Group2',	NULL	,0	,1	,2,	NULL	,2	,N'FieldGroup_ConduitFieldGroup2'	,NULL	)
,	(3	,N'Conduit Field Group3',	NULL	,0	,4	,3,	NULL	,2	,N'FieldGroup_ConduitFieldGroup3'	,NULL	)
,	(4	,N'Conduit Field Group4',	NULL	,7	,1	,4,	NULL	,1	,N'FieldGroup_ConduitFieldGroup4'	,2	)
,	(5	,N'Conduit Field Group5',	NULL	,1	,1	,5,	NULL	,1	,N'FieldGroup_ConduitFieldGroup5'	,1	)
,	(6	,N'Conduit Field Group6',	NULL	,1	,1	,6,	NULL	,1	,N'FieldGroup_ConduitFieldGroup6'	,2	)
--Sprint9 additions
,	(7	,N'Conduit Field Group7',	NULL	,1	,1	,7,	null	,3	,N'FieldGroup_ConduitFieldGroup7'	,1	)
,	(8	,N'Conduit Field Group8',	NULL	,1	,1	,8,	null	,3	,N'FieldGroup_ConduitFieldGroup8'	,2	)
,	(9	,N'Conduit Field Group9',	NULL	,3	,1	,9,	NULL	,1	,N'FieldGroup_ConduitFieldGroup9'	,2	)
,	(10	,N'Conduit Field Group10',	NULL	,3	,1	,10,NULL	,3	,N'FieldGroup_ConduitFieldGroup10'	,2	)
,	(11 ,N'Conduit Field Group11',	NULL	,13	,1	,11,NULL	,1	,N'FieldGroup_ConduitFieldGroup11'	,1	)
,	(12 ,N'Conduit Field Group12',	NULL	,13	,1	,12,NULL	,3	,N'FieldGroup_ConduitFieldGroup12'	,1	)
,	(13 ,N'Conduit Field Group13',	NULL	,5	,1	,13,NULL	,1	,N'FieldGroup_ConduitFieldGroup11'	,1	)
,	(14 ,N'Conduit Field Group14',	NULL	,5	,1	,14,NULL	,1	,N'FieldGroup_ConduitFieldGroup12'	,2	)
,    (15,'Conduit Field Group15',NULL,2,1,15,NULL,1,'FieldGroup_ConduitFieldGroup15',1)
,    (16,'Conduit Field Group16',NULL,2,1,16,NULL,1,'FieldGroup_ConduitFieldGroup16',2)
,    (17,'Conduit Field Group17',NULL,2,1,17,NULL,3,'FieldGroup_ConduitFieldGroup17',1)
,    (18,'Conduit Field Group18',NULL,2,1,18,NULL,3,'FieldGroup_ConduitFieldGroup18',2)
-- For My Control Field Groups
,	(19, N'Connexx', NULL, 7, 3, 19, NULL, 3, N'FieldGroup_Connexx', 2)
,	(20, N'my Control Parameters', NULL, 7, 3, 20, NULL, 3, N'FieldGroup_myControlParameters', 2)
,	(21, N'Water flow switches for dosing lines', NULL, 7, 3, 21, NULL, 3, N'FieldGroup_Waterflowswitchesfordosinglines', 2)
,	(22, N'Dosing Line Modes', NULL, 7, 2, 22, NULL, 3, N'FieldGroup_DosingLineModes', 2)
 -- PLC XL
,	(23, N'PLC XL 2T General', NULL, 11, 1, 23, NULL, 1, N'FieldGroup_PLC_XL_2T_General', 14)
,    (24, N'Connexx', NULL, 11, 3, 24, N'Field Group in PLC XL 2T Advance Tab', 3, N'FieldGroup_Connex', 14)
,    (25, N'PLC XL Parameters', NULL, 11, 3, 25, NULL, 3, N'FieldGroup_PLC_XL_Parameters', 14 )
,    (26, N'Input PLC Card Configuration', NULL, 11, 3, 26, NULL, 3, N'FieldGroup_Input_PLC_Card_Configuration', 14 )
,    (27, N'PLC XL 1 T 5 W General', NULL, 11, 1, 27, NULL, 1, N'FieldGroup_PLC_XL_1T_5W_General', 13 )
,    (28, N'Connexx', NULL, 11, 3, 28, N'Field Group in PLC XL 1 T 5 W Advance Tab', 3, N'FieldGroup_Connexx', 13 )
,    (29, N'PLC XL Parameters', NULL, 11, 3, 29, NULL, 3, N'FieldGroup_PLC_XL_Parameters', 13 )
,    (30, N'Input PLC Card Configuration', NULL, 11, 3, 30, NULL, 3, N'FieldGroup_Input_PLC_Card_Configuration', 13 )
,    (31, N'PLC XL 10 W General', NULL, 11, 1, 31, NULL, 1, N'FieldGroup_PLC_XL_10W_General', 12 )
,    (32, N'Connexx', NULL, 11, 3, 32, N'Field Group in PLC XL 10 W Advance Tab', 3, N'FieldGroup_Connexx', 12 )
,    (33, N'PLC XL Parameters', NULL, 11, 3, 33, NULL, 3, N'FieldGroup_PLC_XL_Parameters', 12 )
,    (34, N'Input PLC Card Configuration', NULL, 11, 3, 34, NULL, 3, N'FieldGroup_Input_PLC_Card_Configuration', 12 )
-- EControl Plus
,    (35, N'E Control Plus 8 Washer General', NULL, 8, 1, 35, NULL, 1, N'FieldGroup_E_Control_Plus_8_Washer_General', 6 )
,    (36, N'Connexx', NULL, 8, 3, 36, N'Field Group in E Control Plus Advance Tab', 3, N'FieldGroup_Connexx', 6 )
,    (37, N'E Control Plus Parameters', NULL, 8, 3, 37, NULL, 3, N'FieldGroup_E_Control_Plus_8_Washer_Parameters', 6 )
,    (38, N'E Control Plus 1 Tunnel 6 Washer General', NULL, 8, 1, 38, NULL, 1, N'FieldGroup_E_Control_Plus_1_Tunnel_6_Washer_General', 7 )
,    (39, N'Connexx', NULL, 8, 3, 39, N'Field Group in E Control Plus Advance Tab', 3, N'FieldGroup_Connexx', 7 )
,    (40, N'E Control Plus Parameters', NULL, 8, 3, 40, NULL, 3, N'FieldGroup_E_Control_Plus_1_Tunnel_6_Washer_Parameters', 7 )
-- EControl Central
,    (41, N'EControl Central 6 Washer General', NULL, 9, 1, 41, N'EControl Central 6 Washer General Tab', 1, N'FieldGroup_EControl_Central_6_Washer_General', 8 )
,    (42, N'Connexx', NULL, 9, 3, 42, N'EControl Central 6 Washer Advanced Tab Connex', 3, N'FieldGroup_Connexx', 8 )
,    (43, N'EControl Central Parameters', NULL, 9, 3, 43, N'EControl Central 6 Washer Advanced Tab Parameters', 3, N'FieldGroup_EControl_Central_Parameters', 8 )
,    (44, N'EControl Central 1 Tunnel 4 Washer General', NULL, 9, 1, 44, N'EControl Central 1 Tunnel 4 Washer General Tab', 1, N'FieldGroup_EControl_Central_1_Tunnel_4_Washer_General', 10 )
,    (45, N'Connexx', NULL, 9, 3, 45, N'EControl Central 1 Tunnel 4 Washer Advanced Tab Connex', 3, N'FieldGroup_Connexx', 10 )
,    (46, N'EControl Central Parameters', NULL, 9, 3, 46, N'EControl Central 1 Tunnel 4 Washer Advanced Tab Parameters', 3, N'FieldGroup_EControl_Central_Parameters', 10 )
-- EControl Decentral
,    (47, N'EControl Decentral 4 Washer General', NULL, 14, 1, 47, N'EControl Decentral 4 Washer General Tab', 1, N'FieldGroup_EControl_Decentral_4_Washer_General', 9 )
,    (48, N'Connexx', NULL, 14, 3, 48, N'EControl Decentral 4 Washer Advanced Tab Connex', 3, N'FieldGroup_Connexx', 9 )
,    (49, N'EControl Decentral Parameters', NULL, 14, 3, 49, N'EControl Decentral 4 Washer Advanced Tab Parameters', 3, N'FieldGroup_EControl_Decentral_Parameters', 9 )
,    (50, N'EControl Decentral 1 Tunnel 2 Washer General', NULL, 14, 1, 50, N'EControl Decentral 1 Tunnel 2 Washer General Tab', 1, N'FieldGroup_EControl_Decentral_1_Tunnel_2_Washer_General', 11 )
,    (51, N'Connexx', NULL, 14, 3, 51, N'EControl Central 1 Tunnel 2 Washer Advanced Tab Connex', 3, N'FieldGroup_Connexx', 11 )
,    (52, N'EControl Decentral Parameters', NULL, 14, 3, 52, N'EControl Decentral 1 Tunnel 2 Washer Advanced Tab Parameters', 3, N'FieldGroup_EControl_Decentral_Parameters', 11 )
-- Ecodose
,    (53, N'Ecodose 8 Washers General', NULL, 10, 1, 53, N'Ecodose 8 Washers General Tab', 1, N'FieldGroup_Ecodose_8_Washers_General', 6 )
,    (54, N'Connexx', NULL, 10, 3, 54, N'Ecodose 8 Washers Advanced Tab Connex', 3, N'FieldGroup_Connexx', 6 )
,    (55, N'Ecodose Parameters', NULL, 10, 3, 55, N'Ecodose 8 Washers Advanced Tab Parameters', 3, N'FieldGroup_Ecodose_Parameters', 6)


MERGE	TCD.FieldGroup			AS			TARGET
USING	@tempFieldGroup		AS			SOURCE
ON	TARGET.Id			=			SOURCE.Id
WHEN	NOT MATCHED		THEN
INSERT	(Id,Name,Image_Url,ControllerModelId,FieldGroupTypeId,DisplayOrder
,HelpText,TabId,ResourceKey,ControllerTypeId	)
VALUES	(SOURCE.Id,SOURCE.Name,SOURCE.Image_Url,SOURCE.ControllerModelId,SOURCE.FieldGroupTypeId,SOURCE.DisplayOrder
,SOURCE.HelpText,SOURCE.TabId,SOURCE.ResourceKey,SOURCE.ControllerTypeId);
-- =======================


--Declare temp table variable to hold input data
DECLARE @Tempfield TABLE( TempId INT IDENTITY( 1,1 ),
                          Id INT NOT NULL,
                          TypeId INT NOT NULL,
                          Label NVARCHAR( 100 ) NOT NULL,
                          Min NVARCHAR( 50 ),
                          Max NVARCHAR( 50 ),
                          FieldGroupId INT,
                          DataSourceId INT,
                          IsMandatory BIT,
                          HelpText NVARCHAR( 450 ),
                          HelpTextURL NVARCHAR( 250 ),
                          DataTypeId INT,
                          DataCategoryId INT,
                          CurrencyId INT,
                          DisplayOrder INT,
                          ResourceKey NVARCHAR( 250 ),
                          DefaultValue NVARCHAR( 150 ),
                          IsEditable BIT,
                          Name VARCHAR( 100 ),
                          HasFieldTag VARCHAR( 250 ) NULL,
                          DefaultFieldTag VARCHAR( 250 ) NULL,
                          ClassName VARCHAR( 250 ) NULL );

--Populate temp table variable with the input data
INSERT INTO @tempField( Id,TypeId,Label,[Min],[Max],FieldGroupId,DataSourceId,IsMandatory,HelpText,
                        HelpTextURL,DataTypeId,DataCategoryId,CurrencyId,DisplayOrder,ResourceKey,DefaultValue,IsEditable,
                        Name,HasFieldTag,DefaultFieldTag,ClassName )
VALUES( 1,7,N'ConduitFieldLabel1',NULL,NULL,NULL,1,1,NULL,NULL,2,NULL,NULL,1,N'Field_ConduitFieldLabel1',NULL,1,NULL,NULL,NULL,NULL )
,(2, 10, N'ConduitFieldLabel2', NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 2, N'Field_ConduitFieldLabel2 ', NULL, 1, NULL, NULL, NULL, NULL)
,(3, 10, N'ConduitFieldLabel3', NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Field_ConduitFieldLabel3', NULL, 1, NULL, NULL, NULL, NULL)
,(4, 10, N'ConduitFieldLabel4', NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 2, N'Field_ConduitFieldLabel4', NULL, 1, NULL, NULL, NULL, NULL)
,(5, 10, N'ConduitFieldLabel5', NULL, NULL,  NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 1, N'Field_ConduitFieldLabel5', NULL, 1, NULL, NULL, NULL, NULL)
,(6, 10, N'ConduitFieldLabel6', NULL, NULL,  NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 1, N'Field_ConduitFieldLabel6', NULL, 1, NULL, NULL, NULL, NULL)
,(11, 10, N'OPC Server', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 7, N'OPC Server', N'RSLinx OPC Server', 1, NULL, NULL, NULL, NULL)
,(12, 10, N'Preflush Time(sec)', N'0', NULL,  NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 4, N'Preflush Time(sec)', N'10', 1, NULL, 'Tag_PREF', N'C5:16.PRE', NULL)
,(13, 10, N'Controller Number', N'0', NULL,  NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', NULL, 0, N'ControllerNumber', NULL, NULL, 'dispNumber')
,(14, 10, N'OPC Object', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 5, N'OPC Object', NULL, 1, NULL, NULL, NULL, NULL)
,(15, 10, N'Postflush Time(sec)', N'0', NULL,  NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 5, N'Postflush Time(sec)',  N'30', 1, NULL, 'Tag_POSF', N'C5:20.PRE', NULL)
,(16, 11, N'Controller Version', NULL, NULL,  NULL, 3, 1, NULL, NULL, 2, NULL, NULL, 5, N'Controller Version', N'1', 1, N'ControllerVersion', NULL, NULL, NULL)
,(17, 10, N'DDE Driver', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 8, N'DDE Driver', NULL, 1, NULL, NULL, NULL, NULL)
,(18, 2, N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 10, N'Active', N'false', 1, N'Active', NULL, NULL, NULL)
,(19, 12, N'Install Date', NULL, NULL,  NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 8, N'Install Date', NULL, 1, N'InstallDate', NULL, NULL, NULL)
,(20, 2, N'Check Water Flow', NULL, NULL,  NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 16, N'Check Water Flow', N'true', 1, NULL, NULL, NULL, NULL)
,(21, 10, N'AMS Net ID Address', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 5, N'AMS Net ID Address', N'10.225.134.21.1.1', 1, NULL, NULL, NULL, NULL)
,(22, 10, N'IP Address', NULL, NULL,  NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 15, N'IP Address', NULL, 1, NULL, NULL, NULL, NULL)
,(23, 10, N'Com port Number', N'0', NULL,  NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 17, N'Com port Number', NULL, 1, NULL, NULL, NULL, NULL)
,(27, 10, N'Preflush Time(sec)', N'0', NULL,  NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 4, N'Preflush Time(sec)', N'5', 1, NULL, 'Tag_PREF', N'L_PREF', NULL)
,(28, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', NULL, 0, N'ControllerNumber', NULL, NULL, 'dispNumber')
,(30, 10, N'Postflush Time(sec)', N'0', NULL,  NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 5, N'Postflush Time(sec)',  N'30', 1, NULL, 'Tag_POSF', N'L_POSF', NULL)
,(31, 11, N'Controller Version', NULL, NULL,  NULL, 3, 1, NULL, NULL, 2, NULL, NULL, 7, N'Controller Version', NULL, 1, N'ControllerVersion', NULL, NULL, NULL)
,(33, 2,  N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 18,  N'Active', N'false', 1, N'Active', NULL, NULL, NULL)
,(34, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 10, N'Install Date', NULL, 1, N'InstallDate', NULL, NULL, NULL)
,(35, 2, N'Check Water Flow', NULL, NULL,  NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 11, N'Check Water Flow', N'true', 1, NULL, NULL, NULL, NULL)
,(47, 10, N'AMS Net ID Address', NULL, NULL,NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 2, N'AMS Net ID Address', N'10.225.134.21.1.1', 1, NULL, NULL, NULL, NULL)
,(48, 10, N'IP Address', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 5, N'IP Address', NULL, 1, NULL, NULL, NULL, NULL)
,(49, 10, N'Com port Number', N'0', NULL,  NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 8, N'Com port Number', NULL, 1, NULL, NULL, NULL, NULL)
,(51, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 4, N'Controller Number', NULL, 0, N'ControllerNumber', NULL, NULL, 'dispNumber')
,(53, 2,  N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 9,  N'Active', N'false', 1, N'Active', NULL, NULL, NULL)
,(54, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 10, N'Install Date', NULL, 1, N'InstallDate', NULL, NULL, NULL)
,(55, 2, N'Check Water Flow', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 11, N'Check Water Flow', N'true', 1, NULL, NULL, NULL, NULL)
--Sprint9 additions
,(56, 10, N'Factors Multiplier', N'0', NULL,  NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 2, N'Factors_Multiplier', N'10', 0, NULL, NULL, NULL, NULL)
,(57, 10, N'OZ/Second Multiplier', N'0', NULL,  NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 4, N'OZ/Second_Multiplier', N'10', 0, NULL, NULL, NULL, NULL)
,(58, 10, N'Injection Quantity Multiplier', N'0', NULL, NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 6, N'Injection_Quantity_Multiplier', N'10', 0, NULL, NULL, NULL, NULL)
,(59, 10, N'Max Wash Formulas', N'0', N'127', NULL, NULL, 1, N'Max number of wash formulas due to space restrictions', NULL, 1, NULL, NULL, 1, N'Max_Wash_Formulas', N'127', 1, NULL, 'Tag_MWF', N'L_MWF','WashFormula')
,(60, 10, N'Max Formula Injections', N'0', N'10',  NULL, NULL, 1, N'Max number of injections due to space restrictions', NULL, 1, NULL, NULL, 2, N'Max_Formula_Injections', N'8', 1, NULL, 'Tag_MFI', N'L_MFI','MaxFormulaInjection')
,(61, 10, N'No. of Chemical Valves', N'0', N'16',  NULL, NULL, 1, N'number of chemical valves', NULL, 1, NULL, NULL, 3, N'No._of_Chemical_Valves', N'16', 1, NULL, 'Tag_NCHVLV', N'L_MVLV','ChemicalValves')
,(62, 2, N'Webport Ftp Enabled', NULL, NULL, NULL, 4, 1, N'Is a Webport being used for data buffering', NULL, 4, NULL, NULL, 7, N'Webport_Ftp_Enabled', N'False', 1, NULL, NULL, NULL, 'webportEnable')
,(63, 10, N'Webport IP', N'0', NULL,  NULL, NULL, 1, N'ip address of webport (ex:ftp://192.168.0.240/)', NULL, 2, NULL, NULL, 8, N'Webport_IP', NULL, 1, NULL, NULL, NULL, 'webport')
,(64, 10, N'Webport Login', NULL, NULL, NULL, NULL, 1, N'Login for webport communication', NULL, 2, NULL, NULL, 8, N'Webport_Login', NULL, 1, NULL, NULL, NULL, 'webport')
,(65, 10, N'Webport Password', NULL, NULL,  NULL, NULL, 1, N'Password for webport communication', NULL, 2, NULL, NULL, 9, N'Webport_Password', NULL, 1, NULL, NULL, NULL, 'webport')
,(66, 10, N'Factors Multiplier', N'0', NULL, NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 2, N'Factors_MultiplieR', N'1', 1, NULL, NULL, NULL, NULL)
,(67, 10, N'OZ/Second Multiplier', N'0', NULL,  NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 4, N'OZ/Second_Multiplier', N'1', 1, NULL, NULL, NULL, NULL)
,(68, 10, N'Injection Quantity Multiplier', N'0', NULL, NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 6, N'Injection_Quantity_Multiplier', N'1', 1, NULL, NULL, NULL, NULL)
,(69, 10, N'Max Wash Formulas', N'0', N'99',  NULL, NULL, 1, N'Max number of wash formulas due to space restrictions', NULL, 1, NULL, NULL, 1, N'Max_Wash_Formulas', N'99', 1, NULL, 'Tag_MWF', N'N7:130','WashFormula')
,(70, 10, N'Max Formula Injections', N'0', N'6', NULL, NULL, 1, N'Max number of injections due to space restrictions', NULL, 1, NULL, NULL, 2, N'Max_Formula_Injections', N'6', 1, NULL, 'Tag_MFI', N'N7:131','MaxFormulaInjection')
,(71, 10, N'No. of Chemical Valves', N'0', N'12',  NULL, NULL, 1, N'number of chemical valves', NULL, 1, NULL, NULL, 3, N'No._of_Chemical_Valves', N'10', 1, NULL, 'Tag_NCHVLV', N'','ChemicalValves')
,(72, 2, N'Webport Ftp Enabled', NULL, NULL,  NULL, 4, 1, N'Is a Webport being used for data buffering', NULL, 4, NULL, NULL, 11, N'Webport_Ftp_Enabled', N'False', 1, NULL, NULL, NULL, 'webportEnable')
,(73, 10, N'Webport IP', N'0', NULL,  NULL, NULL, 1, N'ip address of webport (ex:ftp://192.168.0.240/)', NULL, 2, NULL, NULL, 12, N'Webport_IP', NULL, 1, NULL, NULL, NULL, 'webport')
,(74, 10, N'Webport Login', NULL, NULL,  NULL, NULL, 1, N'Login for webport communication', NULL, 2, NULL, NULL, 13, N'Webport_Login', NULL, 1, NULL, NULL, NULL, 'webport')
,(75, 6, N'Webport Password', NULL, NULL,  NULL, NULL, 1, N'Password for webport communication', NULL, 2, NULL, NULL, 14, N'Webport_Password', NULL, 1, NULL, NULL, NULL, 'webport')
,(76, 10, N'ControllerName', NULL, NULL,  NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL)
,(77, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 9, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL)
,(78, 10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL)
,(79, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 10, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL)
,(80, 2, N'Set PLC Time', NULL, NULL, NULL, 4, 1, N'SetPLCTime', NULL, 4, NULL, NULL, 9, N'Set_PLC_Time', NULL, 1, NULL, NULL, NULL, N'PLCTime')
,(81, 13, N'Year', NULL, NULL,  NULL, NULL, 0, N'Year', NULL, 2, NULL, NULL, 10, N'Year', NULL, 1, NULL, 'Tag_YEAR', N'S:37', N'PLCTimeStamp')
,(82, 13, N'Month', NULL, NULL,  NULL, NULL, 0, N'Month', NULL, 2, NULL, NULL, 11, N'Month', NULL, 1, NULL, 'Tag_MNTH', N'S:38', N'PLCTimeStamp')
,(83, 13, N'Day', NULL, NULL,  NULL, NULL, 0, N'Day', NULL, 2, NULL, NULL, 12, N'Day', NULL, 1, NULL,'Tag_DAY', N'S:39', N'PLCTimeStamp')
,(84, 13, N'Hour', NULL, NULL, NULL, NULL, 0, N'Hour', NULL, 2, NULL, NULL, 13, N'Hour', NULL, 1, NULL, 'Tag_HOUR', N'S:40', N'PLCTimeStamp')
,(85, 13, N'Minute', NULL, NULL,  NULL, NULL, 0, N'Minute', NULL, 2, NULL, NULL, 14, N'Minute', NULL, 1, NULL, 'Tag_MIN', N'S:41', N'PLCTimeStamp')
,(86, 13, N'Second', NULL, NULL,  NULL, NULL, 0, N'Second', NULL, 2, NULL, NULL, 15, N'Second', NULL, 1, NULL, 'Tag_SC', N'S:42', N'PLCTimeStamp')
,(87, 13, N'Link Integrity Address', NULL, NULL,  NULL, NULL, 0, NULL, NULL, 2, NULL, NULL, 5, N'Link_Integrity_Address', NULL, 1, NULL, 'Tag_LIADD', N'N9:3', NULL)
,(88, 13, N'Name Link', NULL, NULL,  NULL, NULL, 0, NULL, NULL, 2, NULL, NULL, 6, N'Name_Link', NULL, 1, NULL, 'Tag_NLNK', N'ST149:0', NULL)
,(89, 13, N'Automatic Weight Enabled', NULL, NULL,  NULL, NULL, 0, NULL, NULL, 4, NULL, NULL, 7, N'Automatic_weight_Enabled', NULL, 1, NULL, 'Tag_AWEA', N'B3:9/0', NULL)
,(90, 13, N'Ratio Dosing Enabled', NULL, NULL,  NULL, NULL, 0, NULL, NULL, 4, NULL, NULL, 8, N'Ratio_Dosing_Enabled', NULL, 1, NULL, 'Tag_RDE', N'B3:10/0', NULL)
,(91, 2, N'Set PLC Time', NULL, NULL,  NULL, NULL, 1, N'SetPLCTime', NULL, 4, NULL, NULL, 10, N'Set_PLC_Time', NULL, 1, NULL, NULL, NULL, N'PLCTime')
,(92, 13, N'Year', NULL, NULL,  NULL, NULL, 1, N'Year', NULL, 2, NULL, NULL, 11, N'Year', NULL, 1, NULL, 'Tag_YEAR', N'L_YEAR', N'PLCTimeStamp')
,(93, 13, N'Month', NULL, NULL,  NULL, NULL, 0, N'Month', NULL, 2, NULL, NULL, 12, N'Month', NULL, 1, NULL, 'Tag_MNTH', N'L_MNTH', N'PLCTimeStamp')
,(94, 13, N'Day', NULL, NULL, NULL, NULL, 0, N'Day', NULL, 2, NULL, NULL, 13, N'Day', NULL, 1, NULL, 'Tag_DAY', N'L_DAY', N'PLCTimeStamp')
,(95, 13, N'Hour', NULL, NULL,  NULL, NULL, 0, N'Hour', NULL, 2, NULL, NULL, 14, N'Hour', NULL, 1, NULL, 'Tag_HOUR', N'L_HOUR', N'PLCTimeStamp')
,(96, 13, N'Minute', NULL, NULL,  NULL, NULL, 0, N'Minute', NULL, 2, NULL, NULL, 15, N'Minute', NULL, 1, NULL, 'Tag_MIN', N'L_MIN', N'PLCTimeStamp')
,(97, 13, N'Second', NULL, NULL, NULL, NULL, 0, N'Second', NULL, 2, NULL, NULL, 16, N'Second', NULL, 1, NULL, 'Tag_SC', N'L_SEC', N'PLCTimeStamp')
,(98, 13, N'Link Integrity Address', NULL, NULL, NULL, NULL, 0, NULL, NULL, 2, NULL, NULL, 6, N'Link_Integrity_Address', NULL, 1, NULL, 'Tag_LIADD', N'L_LIC', NULL)
,(99, 13, N'Name Link', NULL, NULL, NULL, NULL, 0, NULL, NULL, 2, NULL, NULL, 7, N'Name_Link', NULL, 1, NULL, 'Tag_NLNK', N'L_NAME', NULL)
,(100, 13, N'Automatic Weight Enabled', NULL, NULL, NULL, NULL, 0, NULL, NULL, 4, NULL, NULL, 8, N'Automatic_Weight_Enabled', NULL, 1, NULL, 'Tag_AWEA', N'L_AWEE', NULL)
,(101, 13, N'Ratio Dosing Enabled', NULL, NULL,  NULL, NULL, 0, NULL, NULL, 4, NULL, NULL, 9, N'Ratio_Dosing_Enabled', NULL, 1, NULL, 'Tag_RDE', N'L_RATD', NULL)
-- TDI COntroller
,(102,10, N'OPC Server', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 7, N'OPC Server',  N'RSLinx OPC Server', 1, NULL, NULL, NULL, NULL)
,(103,10, N'Controller Number', N'0', NULL,  NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', NULL, 0, N'ControllerNumber', NULL, NULL, 'dispNumber')
,(104,11, N'Controller Version', NULL, NULL,  NULL, 3, 1, NULL, NULL, 2, NULL, NULL, 5, N'Controller Version', N'1', 1, N'ControllerVersion', NULL, NULL, NULL)
,(105,2, N'Active', NULL, NULL,  NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 10, N'Active', N'false', 1, N'Active', NULL, NULL, NULL)
,(106,12, N'Install Date', NULL, NULL,  NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 8, N'Install Date', NULL, 1, N'InstallDate', NULL, NULL, NULL)
,(107,10, N'Factors Multiplier', N'0', NULL,NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 2, N'Factors_MultiplieR', N'1', 1, NULL, NULL, NULL, NULL)
,(108,10, N'OZ/Second Multiplier', N'0', NULL,  NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 4, N'OZ/Second_Multiplier', N'1', 1, NULL, NULL, NULL, NULL)
,(109,10, N'Injection Quantity Multiplier', N'0', NULL, NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 6, N'Injection_Quantity_Multiplier', N'1', 1, NULL, NULL, NULL, NULL)
,(110,2, N'Webport Ftp Enabled', NULL, NULL, NULL, 4, 1, N'Is a Webport being used for data buffering', NULL, 4, NULL, NULL, 11, N'Webport_Ftp_Enabled', N'False', 1, NULL, NULL, NULL, 'webportEnable')
,(111,10, N'Webport IP', N'0', NULL, NULL, NULL, 1, N'ip address of webport (ex:ftp://192.168.0.240/)', NULL, 2, NULL, NULL, 12, N'Webport_IP', NULL, 1, NULL, NULL, NULL, 'webport')
,(112,10, N'Webport Login', NULL, NULL,  NULL, NULL, 1, N'Login for webport communication', NULL, 2, NULL, NULL, 13, N'Webport_Login', NULL, 1, NULL, NULL, NULL, 'webport')
,(113,6, N'Webport Password', NULL, NULL, NULL, NULL, 1, N'Password for webport communication', NULL, 2, NULL, NULL, 14, N'Webport_Password', NULL, 1, NULL, NULL, NULL, 'webport')
,(114,10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL)
,(115,10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 9, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL)
,(116,10, N'IP Address', NULL, NULL,  NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 5, N'IP Address', NULL, 1, NULL, NULL, NULL, NULL)
,(117,10, N'Com port Number', N'0', NULL,  NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 8, N'Com port Number', NULL, 1, NULL, NULL, NULL, NULL)
,(118,10, N'Preflush Time(sec)', N'0', NULL,  NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 4, N'Preflush Time(sec)', N'10', 1, NULL, 'Tag_PREF', N'C5:16.PRE', NULL)
,(119,10, N'Postflush Time(sec)', N'0', NULL,  NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 5, N'Postflush Time(sec)', N'30', 1, NULL, 'Tag_POSF', N'C5:20.PRE', NULL)
,(120,10, N'Max Wash Formulas', N'0', N'99',  NULL, NULL, 1, N'Max number of wash formulas due to space restrictions', NULL, 1, NULL, NULL, 1, N'Max_Wash_Formulas', N'99', 1, NULL, 'Tag_MWF', N'N7:130','WashFormula')
,(121,10, N'Max Formula Injections', N'0', N'6', NULL, NULL, 1, N'Max number of injections due to space restrictions', NULL, 1, NULL, NULL, 2, N'Max_Formula_Injections', N'6', 1, NULL, 'Tag_MFI', N'N7:131','MaxFormulaInjection')
,(122,10, N'No. of Chemical Valves', N'0', N'16',  NULL, NULL, 1, N'number of chemical valves', NULL, 1, NULL, NULL, 3, N'No._of_Chemical_Valves', N'10', 1, NULL, 'Tag_NCHVLV', N'','ChemicalValves')
,(123,2, N'Set PLC Time', NULL, NULL, NULL, 4, 1, N'SetPLCTime', NULL, 4, NULL, NULL, 9, N'Set_PLC_Time', NULL, 1, NULL, NULL, NULL, N'PLCTime')
,(124,13, N'Year', NULL, NULL,  NULL, NULL, 0, N'Year', NULL, 2, NULL, NULL, 10, N'Year', NULL, 1, NULL, 'Tag_YEAR', N'S:37', N'PLCTimeStamp')
,(125,13, N'Month', NULL, NULL,  NULL, NULL, 0, N'Month', NULL, 2, NULL, NULL, 11, N'Month', NULL, 1, NULL, 'Tag_MNTH', N'S:38', N'PLCTimeStamp')
,(126,13, N'Day', NULL, NULL,  NULL, NULL, 0, N'Day', NULL, 2, NULL, NULL, 12, N'Day', NULL, 1, NULL,'Tag_DAY', N'S:39', N'PLCTimeStamp')
,(127,13, N'Hour', NULL, NULL, NULL, NULL, 0, N'Hour', NULL, 2, NULL, NULL, 13, N'Hour', NULL, 1, NULL, 'Tag_HOUR', N'S:40', N'PLCTimeStamp')
,(128,13, N'Minute', NULL, NULL,  NULL, NULL, 0, N'Minute', NULL, 2, NULL, NULL, 14, N'Minute', NULL, 1, NULL, 'Tag_MIN', N'S:41', N'PLCTimeStamp')
,(129,13, N'Second', NULL, NULL,  NULL, NULL, 0, N'Second', NULL, 2, NULL, NULL, 15, N'Second', NULL, 1, NULL, 'Tag_SC', N'S:42', N'PLCTimeStamp')
,(130,13, N'Link Integrity Address', NULL, NULL,  NULL, NULL, 0, NULL, NULL, 2, NULL, NULL, 5, N'Link_Integrity_Address', NULL, 1, NULL, 'Tag_LIADD', N'N9:3', NULL)
,(131,13, N'Name Link', NULL, NULL,  NULL, NULL, 0, NULL, NULL, 2, NULL, NULL, 6, N'Name_Link', NULL, 1, NULL, 'Tag_NLNK', N'ST149:0', NULL)
,(132,13, N'Automatic Weight Enabled', NULL, NULL,  NULL, NULL, 0, NULL, NULL, 4, NULL, NULL, 7, N'Automatic_weight_Enabled', NULL, 1, NULL, 'Tag_AWEA', N'B3:9/0', NULL)
,(133,13, N'Ratio Dosing Enabled', NULL, NULL,  NULL, NULL, 0, NULL, NULL, 4, NULL, NULL, 8, N'Ratio_Dosing_Enabled', NULL, 1, NULL, 'Tag_RDE', N'B3:10/0', NULL)
-- UTILITY LOGGER
,(134, 10, N'OPC Server', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 7, N'OPC Server',  N'RSLinx OPC Server', 1, NULL, NULL, NULL, NULL)
,(135, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', NULL, 0, N'ControllerNumber', NULL, NULL, 'dispNumber')
,(136, 11, N'Controller Version', NULL, NULL, NULL, 3, 1, NULL, NULL, 2, NULL, NULL, 5, N'Controller Version', N'1', 1, N'ControllerVersion', NULL, NULL, NULL)
,(137, 2, N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 9, N'Active', N'false', 1, N'Active', NULL, NULL, NULL)
,(138, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 8, N'Install Date', NULL, 1, N'InstallDate', NULL, NULL, NULL)
,(139, 10, N'Factors Multiplier', N'0', NULL, NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 2, N'Factors_Multiplier', N'1', 1, NULL, NULL, NULL, NULL)
,(140, 10, N'OZ/Second Multiplier', N'0', NULL, NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 4, N'OZ/Second_Multiplier ', N'1', 1, NULL, NULL, NULL, NULL)
,(141, 10, N'Injection Quantity Multiplier', N'0', NULL, NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 6, N'Injection_Quantity_Multiplier', N'1', 1, NULL, NULL, NULL, NULL)
,(142, 2, N'Webport Ftp Enabled', NULL, NULL, NULL, 4, 1, N'Is a Webport being used for data buffering', NULL, 4, NULL, NULL, 11, N'Webport_Ftp_Enabled', N'False', 1, NULL, NULL, NULL, 'webportEnable')
,(143, 10, N'Webport IP', N'0', NULL, NULL, NULL, 1, N'ip address of webport (ex:ftp://192.168.0.240/)', NULL, 2, NULL, NULL, 12, N'Webport_IP ', NULL, 1, NULL, NULL, NULL, 'webport')
,(144, 10, N'Webport Login', NULL, NULL, NULL, NULL, 1, N'Login for webport communication', NULL, 2, NULL, NULL, 13, N'Webport_Login', NULL, 1, NULL, NULL, NULL, 'webport')
,(145, 6, N'Webport Password', NULL, NULL, NULL, NULL, 1, N'Password for webport communication', NULL, 2, NULL, NULL, 14, N'Webport_Password', NULL, 1, NULL, NULL, NULL, 'webport')
,(146, 10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL)
,(147, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 10, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL)
,(148, 10, N'IP Address', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 5, N'IP Address', NULL, 1, NULL, NULL, NULL, NULL)
,(149, 10, N'Com port Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 8, N'Com port Number', NULL, 1, NULL, NULL, NULL, NULL)
,(150, 10, N'AMS Net ID Address', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 5, N'AMS Net ID Address', N'10.225.134.21.1.1', 1, NULL, NULL, NULL, NULL)
,(151, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', NULL, 0, N'ControllerNumber', NULL, NULL, 'dispNumber')
,(152, 11, N'Controller Version', NULL, NULL, NULL, 3, 1, NULL, NULL, 2, NULL, NULL, 5, N'Controller Version', N'1', 1, N'ControllerVersion', NULL, NULL, NULL)
,(153, 2,  N'Active', NULL, NULL, NULL, 4, 0, NULL, NULL, 4, NULL, NULL, 9, N'ConduitEnable', N'false', 1, N'Active', NULL, NULL, NULL)
,(154, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 8, N'Install Date', NULL, 1, N'InstallDate', NULL, NULL, NULL)
,(155, 10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name ', NULL, 1, N'TopicName', NULL, NULL, NULL)
,(156, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 10, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL)
,(157, 10, N'OPC Server', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 7, N'OPC Server', N'RSLinx OPC Server', 1, NULL, NULL, NULL, NULL)
,(158, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', NULL, 0, N'ControllerNumber', NULL, NULL, 'dispNumber')
,(159, 11, N'Controller Version', NULL, NULL, NULL, 3, 1, NULL, NULL, 2, NULL, NULL, 5, N'Controller Version', N'1', 1, N'ControllerVersion', NULL, NULL, NULL)
,(160, 2, N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 10, N'Active', N'false', 1, N'Active', NULL, NULL, NULL)
,(161, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 8, N'Install Date', NULL, 1, N'InstallDate', NULL, NULL, NULL)
,(162, 10, N'Factors Multiplier', N'0', NULL, NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 2, N'Factors_MultiplieR', N'1', 1, NULL, NULL, NULL, NULL)
,(163, 10, N'OZ/Second Multiplier', N'0', NULL, NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 4, N'OZ/Second_Multiplier', N'1', 1, NULL, NULL, NULL, NULL)
,(164, 10, N'Injection Quantity Multiplier', N'0', NULL, NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 6, N'Injection_Quantity_Multiplier', N'1', 1, NULL, NULL, NULL, NULL)
,(165, 2, N'Webport Ftp Enabled', NULL, NULL, NULL, 4, 1, N'Is a Webport being used for data buffering', NULL, 4, NULL, NULL, 11, N'Webport_Ftp_Enabled', N'False', 1, NULL, NULL, NULL, 'webportEnable')
,(166, 10, N'Webport IP', N'0', NULL, NULL, NULL, 1, N'ip address of webport (ex:ftp://192.168.0.240/)', NULL, 2, NULL, NULL, 12, N'Webport_IP', NULL, 1, NULL, NULL, NULL, 'webport')
,(167, 10, N'Webport Login', NULL, NULL, NULL, NULL, 1, N'Login for webport communication', NULL, 2, NULL, NULL, 13, N'Webport_Login', NULL, 1, NULL, NULL, NULL, 'webport')
,(168, 6, N'Webport Password', NULL, NULL, NULL, NULL, 1, N'Password for webport communication', NULL, 2, NULL, NULL, 14, N'Webport_Password', NULL, 1, NULL, NULL, NULL, 'webport')
,(169, 10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name  ', NULL, 1, N'TopicName', NULL, NULL, NULL)
,(170, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 9, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL)
---16
,(171, 10, N'AMS Net ID Address', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 5, N'AMS Net ID Address', N'10.225.134.21.1.1', 1, NULL, NULL, NULL, NULL)
,(172, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', NULL, 0, N'ControllerNumber', NULL, NULL, 'dispNumber')
,(173, 2, N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 18, N'Active', N'false', 1, N'Active', NULL, NULL, NULL)
,(174, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 10, N'Install Date', NULL, 1, N'InstallDate', NULL, NULL, NULL)
,(175, 10, N'Factors Multiplier', N'0', NULL, NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 2, N'Factors_Multiplier', N'10', 0, NULL, NULL, NULL, NULL)
,(176, 10, N'OZ/Second Multiplier', N'0', NULL, NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 4, N'OZ/Second_Multiplier', N'10', 0, NULL, NULL, NULL, NULL)
,(177, 10, N'Injection Quantity Multiplier', N'0', NULL, NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 6, N'Injection_Quantity_Multiplier', N'10', 0, NULL, NULL, NULL, NULL)
,(178, 10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL)
,(179, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 10, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL)
--17
,(180, 10, N'Preflush Time(sec)', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 4, N'Preflush Time(sec)', N'10', 1, NULL, N'Tag_PREF', N'C5:16.PRE', NULL)
,(181, 10, N'Postflush Time(sec)', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 5, N'Postflush Time(sec)', N'30', 1, NULL, N'Tag_POSF', N'C5:20.PRE', NULL)
,(182, 10, N'Max Wash Formulas', N'0', N'99', NULL, NULL, 1, N'Max number of wash formulas due to space restrictions', NULL, 1, NULL, NULL, 1, N'Max_Wash_Formulas', N'99', 1, NULL, N'Tag_MWF', N'N7:130', N'WashFormula')
,(183, 10, N'Max Formula Injections', N'0', N'6', NULL, NULL, 1, N'Max number of injections due to space restrictions', NULL, 1, NULL, NULL, 2, N'Max_Formula_Injections', N'6', 1, NULL, N'Tag_MFI', N'N7:131', N'MaxFormulaInjection')
,(184, 10, N'No. of Chemical Valves', N'0', N'12', NULL, NULL, 1, N'number of chemical valves', NULL, 1, NULL, NULL, 3, N'No._of_Chemical_Valves', N'10', 1, NULL, N'Tag_NCHVLV', N'', N'ChemicalValves')
,(185, 2, N'Set PLC Time', NULL, NULL, NULL, 4, 1, N'SetPLCTime', NULL, 4, NULL, NULL, 9, N'Set_PLC_Time', NULL, 1, NULL, NULL, NULL, N'PLCTime')
,(186, 13, N'Year', NULL, NULL, NULL, NULL, 0, N'Year', NULL, 2, NULL, NULL, 10, N'Year', NULL, 1, NULL, N'Tag_YEAR', N'S:37', N'PLCTimeStamp')
,(187, 13, N'Month', NULL, NULL, NULL, NULL, 0, N'Month', NULL, 2, NULL, NULL, 11, N'Month', NULL, 1, NULL, N'Tag_MNTH', N'S:38', N'PLCTimeStamp')
,(188, 13, N'Day', NULL, NULL, NULL, NULL, 0, N'Day', NULL, 2, NULL, NULL, 12, N'Day', NULL, 1, NULL, N'Tag_DAY', N'S:39', N'PLCTimeStamp')
,(189, 13, N'Hour', NULL, NULL, NULL, NULL, 0, N'Hour', NULL, 2, NULL, NULL, 13, N'Hour', NULL, 1, NULL, N'Tag_HOUR', N'S:40', N'PLCTimeStamp')
,(190, 13, N'Minute', NULL, NULL, NULL, NULL, 0, N'Minute', NULL, 2, NULL, NULL, 14, N'Minute', NULL, 1, NULL, N'Tag_MIN', N'S:41', N'PLCTimeStamp')
,(191, 13, N'Second', NULL, NULL, NULL, NULL, 0, N'Second', NULL, 2, NULL, NULL, 15, N'Second', NULL, 1, NULL, N'Tag_SC', N'S:42', N'PLCTimeStamp')
,(192, 13, N'Link Integrity Address', NULL, NULL, NULL, NULL, 0, NULL, NULL, 2, NULL, NULL, 5, N'Link_Integrity_Address', NULL, 1, NULL, N'Tag_LIADD', N'N9:3', NULL)
,(193, 13, N'Name Link', NULL, NULL, NULL, NULL, 0, NULL, NULL, 2, NULL, NULL, 6, N'Name_Link', NULL, 1, NULL, N'Tag_NLNK', N'ST149:0', NULL)
,(194, 13, N'Automatic Weight Enabled', NULL, NULL, NULL, NULL, 0, NULL, NULL, 4, NULL, NULL, 7, N'Automatic_weight_Enabled', NULL, 1, NULL, N'Tag_AWEA', N'B3:9/0', NULL)
,(195, 13, N'Ratio Dosing Enabled', NULL, NULL, NULL, NULL, 0, NULL, NULL, 4, NULL, NULL, 8, N'Ratio_Dosing_Enabled', NULL, 1, NULL, N'Tag_RDE', N'B3:10/0', NULL)
--18
,(196, 10, N'Preflush Time(sec)', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 4, N'Preflush Time(sec)', N'5', 1, NULL, N'Tag_PREF', N'L_PREF', NULL)
,(197, 10, N'Postflush Time(sec)', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 5, N'Postflush Time(sec)', N'30', 1, NULL, N'Tag_POSF', N'L_POSF', NULL)
,(198, 10, N'Max Wash Formulas', N'0', N'127', NULL, NULL, 1, N'Max number of wash formulas due to space restrictions', NULL, 1, NULL, NULL, 1, N'Max_Wash_Formulas', N'127', 1, NULL, N'Tag_MWF', N'L_MWF', N'WashFormula')
,(199, 10, N'Max Formula Injections', N'0', N'10', NULL, NULL, 1, N'Max number of injections due to space restrictions', NULL, 1, NULL, NULL, 2, N'Max_Formula_Injections ', N'8', 1, NULL, N'Tag_MFI', N'L_MFI', N'MaxFormulaInjection')
,(200, 10, N'No. of Chemical Valves', N'0', N'16', NULL, NULL, 1, N'number of chemical valves', NULL, 1, NULL, NULL, 3, N'No._of_Chemical_Valves', N'16', 1, NULL, N'Tag_NCHVLV', N'L_MVLV', N'ChemicalValves')
,(201, 2, N'SetPLCTime', NULL, NULL, NULL, NULL, 1, N'SetPLCTime', NULL, 4, NULL, NULL, 10, N'Set_PLC_Time', NULL, 1, NULL, NULL, NULL, N'PLCTime')
,(202, 13, N'Year', NULL, NULL, NULL, NULL, 1, N'Year', NULL, 2, NULL, NULL, 11, N'Year', NULL, 1, NULL, N'Tag_YEAR', N'L_YEAR', N'PLCTimeStamp')
,(203, 13, N'Month', NULL, NULL, NULL, NULL, 0, N'Month', NULL, 2, NULL, NULL, 12, N'Month', NULL, 1, NULL, N'Tag_MNTH', N'L_MNTH', N'PLCTimeStamp')
,(204, 13, N'Day', NULL, NULL, NULL, NULL, 0, N'Day', NULL, 2, NULL, NULL, 13, N'Day', NULL, 1, NULL, N'Tag_DAY', N'L_DAY', N'PLCTimeStamp')
,(205, 13, N'Hour', NULL, NULL, NULL, NULL, 0, N'Hour', NULL, 2, NULL, NULL, 14, N'Hour', NULL, 1, NULL, N'Tag_HOUR', N'L_HOUR', N'PLCTimeStamp')
,(206, 13, N'Minute', NULL, NULL, NULL, NULL, 0, N'Minute', NULL, 2, NULL, NULL, 15, N'Minute', NULL, 1, NULL, N'Tag_MIN', N'L_MIN', N'PLCTimeStamp')
,(207, 13, N'Second', NULL, NULL, NULL, NULL, 0, N'Second', NULL, 2, NULL, NULL, 16, N'Second', NULL, 1, NULL, N'Tag_SC', N'L_SEC', N'PLCTimeStamp')
,(208, 13, N'Link Integrity Address', NULL, NULL, NULL, NULL, 0, NULL, NULL, 2, NULL, NULL, 6, N'Link_Integrity_Address', NULL, 1, NULL, N'Tag_LIADD', N'L_LIC', NULL)
,(209, 13, N'Name Link', NULL, NULL, NULL, NULL, 0, NULL, NULL, 2, NULL, NULL, 7, N'Name_Link', NULL, 1, NULL, N'Tag_NLNK', N'L_NAME', NULL)
,(210, 13, N'Automatic Weight Enabled', NULL, NULL, NULL, NULL, 0, NULL, NULL, 4, NULL, NULL, 8, N'Automatic_Weight_Enabled', NULL, 1, NULL, N'Tag_AWEA', N'L_AWEE', NULL)
,(211, 13, N'Ratio Dosing Enabled', NULL, NULL, NULL, NULL, 0, NULL, NULL, 4, NULL, NULL, 9, N'Ratio_Dosing_Enabled', NULL, 1, NULL, N'Tag_RDE', N'L_RATD', NULL)

-- My Control Fields for General & Advance tabs
,(212, 10, N'Controller Name', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL)
,(213, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 7, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL)
,(214, 2, N'Enable Connexx', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 1, N'Enable_Connexx', NULL, 1, NULL, NULL, NULL, NULL)
,(215, 10, N'Connexx Alarm delay', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 2, N'Connexx_Alarm_Delay', N'10', 1, NULL, NULL, NULL, NULL)
,(216, 10, N'Hysteresis on Connexx alarm level', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 3, N'Hysteresis on Connexx_Alarm_Level', N'2', 1, NULL, NULL, NULL, NULL)
,(217, 2, N'enVisionEnable', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 4, N'enVisionEnable', N'True', 1, NULL, NULL, NULL, N'mycontrolparams')
,(218, 2, N'Check Water flow', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 5, N'CheckWaterflow', N'True', 1, NULL, NULL, NULL, NULL)
,(219, 2, N'enVision Time out Enable', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 6, N'enVisionTimeoutEnable', N'0', 1, NULL, NULL, NULL, NULL)
,(220, 2, N'Check flow leakage alarm', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 7, N'CheckFlowLeakageAlarm', N'0', 1, NULL, NULL, NULL, NULL)
,(221, 10, N'enVision Timeout Alarm', N'1', N' 65535', NULL, NULL, 1, N'enVision Timeout Alarm', NULL, 2, NULL, NULL, 8, N'enVision Timeout Alarm', N'10', 1, NULL, NULL, NULL, NULL)
,(222, 2, N'Enable reset button', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 9, N'EnableResetButton', N'1', 1, NULL, NULL, NULL, NULL)
,(223, 2, N'Disable Program not finished alarm', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 10, N'Disable Program not finished alarm', N'false', 0, NULL, NULL, NULL, NULL)
--,(224, 10, N'Alarm Reset Time', N'60', 1, NULL, NULL, NULL, NULL)
,(224, 10, N'Alarm Reset Time', N'0', N'65535', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, 11, N'Alarm_Reset_Time', N'60', 1, NULL, NULL, NULL, NULL )
,(225, 10, N'Stop Time Dubix', N'0', N'99', NULL, NULL, NULL, N'Stop Time Dubix', NULL, 2, NULL, NULL, 12, N'StopTimeDubix', N'0', 1, NULL, NULL, NULL, NULL)
,(226, 2, N'Separate Air Pressure and Emergency stop Alarm', NULL, NULL, NULL, NULL, NULL, N'Separate Air Pressure and Emergency stop Alarm', NULL, 4, NULL, NULL, 13, N'SeparateAirPressureandEmergencystopAlarm', N'True', 1, NULL, NULL, NULL, NULL)
,(227, 10, N'Intermediary Rinse Time', N'0', N'999', NULL, NULL, NULL, N'Intermediary Rinse Time', NULL, 2, NULL, NULL, 14, N'IntermediaryRinseTime', N'3', 1, NULL, NULL, NULL, NULL)
,(228, 2, N'Invert Machine Stop', NULL, NULL, NULL, NULL, NULL, N'Invert Machine Stop', NULL, 2, NULL, NULL, 15, N'InvertMachineStop', NULL, 1, NULL, NULL, NULL, NULL)
,(229, 10, N'Filter to generate alarm on analogue values', N'0', N'999', NULL, NULL, NULL, N'Filter to generate alarm on analogue values', NULL, 2, NULL, NULL, 16, N'FiltertogeneratealarmonAnalogue values', N'2', 1, NULL, NULL, NULL, NULL)
,(230, 2, N'Alarm Deep tray enabled', NULL, NULL, NULL, NULL, NULL, N'Alarm Deep tray enabled', NULL, 2, NULL, NULL, 17, N'Alarm_Deep_Tray_Enabled', NULL, 1, NULL, NULL, NULL, NULL)
,(231, 11, N'L1 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 33, N'L1_Switch', NULL, 1, NULL, NULL, NULL, N'DosingLines')
,(232, 11, N'L2 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 34, N'L2_Switch', NULL, 1, NULL, NULL, NULL, N'DosingLines')
,(233, 11, N'L3 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 35, N'L3_Switch', NULL, 1, NULL, NULL, NULL, N'DosingLines')
,(234, 11, N'L4 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 36, N'L4_Switch', NULL, 1, NULL, NULL, NULL, N'DosingLines')
,(235, 11, N'L5 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 37, N'L5_Switch ', NULL, 1, NULL, NULL, NULL, N'DosingLines')
,(236, 11, N'L6 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 38, N'L6_Switch ', NULL, 1, NULL, NULL, NULL, N'DosingLines')
,(237, 11, N'L7 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 39, N'L7_Switch ', NULL, 1, NULL, NULL, NULL, N'DosingLines')
,(238, 11, N'L8 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 40, N'L8_Switch ', NULL, 1, NULL, NULL, NULL, N'DosingLines')
,(239, 11, N'L9 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 41, N'L9_Switch ', NULL, 1, NULL, NULL, NULL, N'DosingLines')
,(240, 11, N'L10 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 42, N'L10_Switch', NULL, 1, NULL, NULL, NULL, N'DosingLines')
,(241, 11, N'L11 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 43, N'L11_Switch', NULL, 1, NULL, NULL, NULL, N'DosingLines')
,(242, 11, N'L12 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 44, N'L12_Switch', NULL, 1, NULL, NULL, NULL, N'DosingLines')
,(243, 11, N'L13 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 45, N'L13_Switch', NULL, 1, NULL, NULL, NULL, N'DosingLines')
,(244, 11, N'L14 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 46, N'L14_Switch', NULL, 1, NULL, NULL, NULL, N'DosingLines')
,(245, 11, N'L15 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 47, N'L15_Switch', NULL, 1, NULL, NULL, NULL, N'DosingLines')
,(246, 11, N'L16 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 48, N'L16_Switch', NULL, 1, NULL, NULL, NULL, N'DosingLines')
,(247, 10, N'Line1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 18, N'Line1', NULL, 1, NULL, NULL, NULL, N'LableDosingLines')
,(248, 11, N'Dosing Line Mode1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 19, N'Dosing_Line_Mode1', NULL, 1, NULL, NULL, NULL, NULL)
,(249, 2, N'Enable Auxiliary pump1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 20, N'Enable_Auxiliary_pump1', NULL, 1, NULL, NULL, NULL, NULL)
,(250, 2, N'Flow-meter for Flow check1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 21, N'Flow-meter_for_Flow_check1', NULL, 1, NULL, NULL, NULL, NULL)
,(251, 10, N'No of Pumps Connected to TCR1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 22, N'No_of_Pumps_Connected_to_TCR1', N'8', 1, NULL, NULL, NULL, NULL)
,(252, 10, N'Line2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 23, N'Line2', NULL, 1, NULL, NULL, NULL, N'LableDosingLines')
,(253, 11, N'Dosing Line Mode2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 24, N'Dosing_Line_Mode2', NULL, 1, NULL, NULL, NULL, NULL)
,(254, 2, N'Enable Auxiliary pump2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 25, N'Enable_Auxiliary_pump2', NULL, 1, NULL, NULL, NULL, NULL)
,(255, 2, N'Flow-meter for Flow check2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 26, N'meter_for_Flow_check2', NULL, 1, NULL, NULL, NULL, NULL)
,(256, 10, N'No of Pumps Connected to TCR2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 27, N'No_of_Pumps_Connected_to_TCR2', N'8', 1, NULL, NULL, NULL, NULL)
,(257, 10, N'Line3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 28, N'Line3', NULL, 1, NULL, NULL, NULL, N'LableDosingLines')
,(258, 11, N'Dosing Line Mode3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 29, N'Dosing_Line_Mode3', NULL, 1, NULL, NULL, NULL, NULL)
,(259, 2, N'Enable Auxiliary pump3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 30, N'Enable_Auxiliary_pump3', NULL, 1, NULL, NULL, NULL, NULL)
,(260, 2, N'Flow-meter for Flow check3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 31, N'meter_for_Flow_check3', NULL, 1, NULL, NULL, NULL, NULL)
,(261, 10, N'No of Pumps Connected to TCR3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 32, N'No_of_Pumps_Connected_to_TCR3', N'8', 1, NULL, NULL, NULL, NULL)
,(262, 11, N'Controller Version', NULL, NULL, NULL, 3, 1, NULL, NULL, 2, NULL, NULL, 8, N'Controller_Version', N'1.3.0', 0, NULL, NULL, NULL, NULL)
--,(262, 10, N'Controller Version',			 NULL, NULL, NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,7,N'Controller_Version',N'1.3.0',1,NULL,NULL,NULL,NULL)

-- PLC XL
,(263, 10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL )
,(264, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 2, N'Install_Date', NULL, 1, N'InstallDate', NULL, NULL, NULL )
,(265, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', N'1', 0, N'ControllerNumber', NULL, NULL, N'dispNumber' )
,(266, 2, N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 4, N'Active', N'false', 1, N'Active', NULL, NULL, NULL )
,(267, 11, N'Controller Version', NULL, NULL, NULL, 3, 1, NULL, NULL, 2, NULL, NULL, 5, N'Controller Version', N'5', 0, N'ControllerVersion', NULL, NULL, NULL )
,(268, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 6, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL )
,(269, 10, N'IP Address', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 7, N'IP_Address', N'10.225.134.1', 1, NULL, NULL, NULL, NULL )
,(270, 2, N'PMR Enabled', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 4, N'PMR_Enabled', N'true', 1, NULL, NULL, NULL, NULL )
,(271, 2, N'Check Water flow Group1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 5, N'Check_Water_flow_Group1', N'true', 1, NULL, NULL, NULL, NULL )
,(272, 2, N'enVision Time out Enable', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 6, N'enVision_Time_out_Enable', N'true', 1, NULL, NULL, NULL, NULL )
,(273, 2, N'Check Water flow Group2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 7, N'Check_Water_flow_Group2', N'true', 1, NULL, NULL, NULL, NULL )
,(274, 10, N'enVision Timeout Alarm', N'1', N'999', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 8, N'enVision_Timeout_Alarm', N'10', 1, NULL, NULL, NULL, NULL )
,(275, 2, N'Check flow leakage alarm Group1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 9, N'Check_flow_leakage_Alarm_Group1', N'true', 1, NULL, NULL, NULL, NULL )
,(276, 10, N'Stop Time Dubix', N'0', N'99', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL )
,(277, 10, N'Stop Time Dubix', N'0', N'99', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 10, N'Stop_Time_Dubix', N'0', 1, NULL, NULL, NULL, NULL )
,(278, 2, N'Check flow leakage alarm Group2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 11, N'Check_Flow_Leakage_Alarm_Group2', N'true', 1, NULL, NULL, NULL, NULL )
,(279, 2, N'Disable Program not finished Alarm', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 12, N'Disable_Program_Not_Finished_Alarm', N'false', 1, NULL, NULL, NULL, NULL )
,(280, 2, N'Start do not generate First Step', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 13, N'Start_Do_Not_Generate_First_Step', N'false', 1, NULL, NULL, NULL, NULL )
,(281, 2, N'Conductivity Compensation Stock Solution Tank 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 14, N'Conductivity_Compensation_Stock_Solution_Tank_1', N'false', 1, NULL, NULL, NULL, NULL )
,(282, 10, N'Alarm Reset Time', N'0', N'32767', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 15, N'Alarm_Reset_Time', N'60', 1, NULL, NULL, NULL, NULL )
,(283, 2, N'Conductivity Compensation Stock Solution Tank 2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 16, N'Conductivity_Compensation_Stock_Solution_Tank_2', N'false', 1, NULL, NULL, NULL, NULL )
,(284, 2, N'Enable Reset button', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 17, N'Enable_Reset_Button', N'true', 1, NULL, NULL, NULL, NULL )
,(285, 2, N'Internal Take-Over Main Equipment No. 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 18, N'Internal_Take-Over_Main_Equipment_No._1', N'false', 1, NULL, NULL, NULL, NULL )
,(286, 2, N'Switch Over from Stock Solution Tank 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 19, N'Switch_Over_from_Stock_Solution_Tank_1', N'false', 1, NULL, NULL, NULL, NULL )
,(287, 2, N'Internal Take-Over Main Equipment No. 2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 20, N'Internal_Take-Over_Main_Equipment_No._2', N'false', 1, NULL, NULL, NULL, NULL )
,(288, 2, N'Switch Over from Stock Solution Tank 2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 21, N'Switch_Over_from_Stock_Solution_Tank_2', N'false', 1, NULL, NULL, NULL, NULL )
,(289, 11, N'Group Number used for external take over ME 1', NULL, NULL, NULL, 9, NULL, NULL, NULL, 2, NULL, NULL, 22, N'Group_Number_Used_For_External_Take_Over_ME_1', NULL, 1, NULL, NULL, NULL, NULL )
,(290, 10, N'External extra flush time ME1 ', N'0', N'999', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 23, N'External_Extra_Flush_Time_ME1', N'0', 1, NULL, NULL, NULL, NULL )
,(291, 11, N'Group Number used for external take over ME 2', NULL, NULL, NULL, 9, NULL, NULL, NULL, 2, NULL, NULL, 24, N'Group_Number_Used_For_External_Take_Over_ME_2', NULL, 1, NULL, NULL, NULL, NULL )
,(292, 10, N'External extra flush time ME2', N'0', N'999', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 25, N'External_Extra_Flush_Time_ME2', N'0', 1, NULL, NULL, NULL, NULL )
,(293, 2, N'Digital Input Card 1 (Signal Machines) Position 0 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 26, N'Digital_Input_Card_1_Signal_Machines_Position_0_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(294, 2, N'Digital Input Card 6 (ME2 + P 10,11,12) Position 0 Rack 2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 27, N'Digital_Input_Card_6_(ME2 + P 10,11,12)_Position_0_Rack_2', N'false', 1, NULL, NULL, NULL, NULL )
,(295, 2, N'Digital Input Card 2 (Signal Machines) Position 1 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 28, N'Digital_Input_Card_2_(Signal_Machines)_Position_1_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(296, 2, N'Analogue Input Card 1 Position 5 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 29, N'Analogue_Input_Card_1_Position_5_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(297, 2, N'Digital Input Card 3 (Dosing Group 1) Position 2 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 30, N'Digital_Input_Card_3_(Dosing_Group_1)_Position_2_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(298, 2, N'Analogue Input Card 2 Position 6 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 31, N'Analogue_Input_Card_2_Position_6_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(299, 2, N'Digital Input Card 4 (Dosing Group 2) Position 3 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 32, N'Digital_Input_Card_4_(Dosing_Group_2)_Position_3_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(300, 2, N'Analogue Input Card 3 Position 1 Rack 3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 33, N'Analogue_Input_Card_3_Position_1_Rack_3', N'false', 1, NULL, NULL, NULL, NULL )
,(301, 2, N'Digital Input Card 5 (Miniterminal) Position 4 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 34, N'Digital_Input_Card_5_(Miniterminal)_Position_4_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(302, 2, N'Digital Input Card 7 (Transfer Carbonell) Position 7 Rack 3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 35, N'Digital_Input_Card_7_(Transfer_Carbonell)_Position_7_Rack_3', N'false', 1, NULL, NULL, NULL, NULL )
,(303, 10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL )
,(304, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 2, N'Install_Date', NULL, 1, N'InstallDate', NULL, NULL, NULL )
,(305, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', N'1', 0, N'ControllerNumber', NULL, NULL, N'dispNumber' )
,(306, 2, N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 4, N'Active', N'false', 1, N'Active', NULL, NULL, NULL )
,(307, 11, N'Controller Version', NULL, NULL, NULL, 3, 1, NULL, NULL, 2, NULL, NULL, 5, N'Controller Version', N'5', 0, N'ControllerVersion', NULL, NULL, NULL )
,(308, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 6, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL )
,(309, 10, N'IP Address', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 7, N'IP_Address', N'10.225.134.1', 1, NULL, NULL, NULL, NULL )
,(310, 2, N'PMR Enabled', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 4, N'PMR_Enabled', N'true', 1, NULL, NULL, NULL, NULL )
,(311, 2, N'Check Water flow Group1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 5, N'Check_Water_flow_Group1', N'true', 1, NULL, NULL, NULL, NULL )
,(312, 2, N'enVision Time out Enable', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 6, N'enVision_Time_out_Enable', N'true', 1, NULL, NULL, NULL, NULL)
,(313, 2, N'Check Water flow Group2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 7, N'Check_Water_flow_Group2', N'true', 1, NULL, NULL, NULL, NULL )
,(314, 10, N'enVision Timeout Alarm', N'1', N'999', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 8, N'enVision_Timeout_Alarm', N'10', 1, NULL, NULL, NULL, NULL )
,(315, 2, N'Check flow leakage alarm Group1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 9, N'Check_flow_leakage_Alarm_Group1', N'true', 1, NULL, NULL, NULL, NULL )
,(316, 10, N'Stop Time Dubix', N'0', N'99', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 10, N'Stop_Time_Dubix', N'0', 1, NULL, NULL, NULL, NULL )
,(317, 2, N'Check flow leakage alarm Group2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 11, N'Check_Flow_Leakage_Alarm_Group2', N'true', 1, NULL, NULL, NULL, NULL )
,(318, 2, N'Disable Program not finished Alarm', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 12, N'Disable_Program_Not_Finished_Alarm', N'false', 1, NULL, NULL, NULL, NULL )
,(319, 2, N'Start do not generate First Step', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 13, N'Start_Do_Not_Generate_First_Step', N'false', 1, NULL, NULL, NULL, NULL )
,(320, 2, N'Conductivity Compensation Stock Solution Tank 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 14, N'Conductivity_Compensation_Stock_Solution_Tank_1', N'false', 1, NULL, NULL, NULL, NULL )
,(321, 10, N'Alarm Reset Time', N'0', N'32767', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 15, N'Alarm_Reset_Time', N'60', 1, NULL, NULL, NULL, NULL )
,(322, 2, N'Conductivity Compensation Stock Solution Tank 2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 16, N'Conductivity_Compensation_Stock_Solution_Tank_2', N'false', 1, NULL, NULL, NULL, NULL )
,(323, 2, N'Enable Reset button', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 17, N'Enable_Reset_Button', N'false', 1, NULL, NULL, NULL, NULL )
,(324, 2, N'Internal Take-Over Main Equipment No. 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 18, N'Internal_Take-Over_Main_Equipment_No._1', N'false', 1, NULL, NULL, NULL, NULL )
,(325, 2, N'Switch Over from Stock Solution Tank 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 19, N'Switch_Over_from_Stock_Solution_Tank_1', N'false', 1, NULL, NULL, NULL, NULL )
,(326, 2, N'Internal Take-Over Main Equipment No. 2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 20, N'Internal_Take-Over_Main_Equipment_No._2', N'false', 1, NULL, NULL, NULL, NULL )
,(327, 2, N'Switch Over from Stock Solution Tank 2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 21, N'Switch_Over_from_Stock_Solution_Tank_2', N'false', 1, NULL, NULL, NULL, NULL )
,(328, 11, N'Group Number used for external take over ME 1', NULL, NULL, NULL, 9, NULL, NULL, NULL, 2, NULL, NULL, 22, N'Group_Number_Used_For_External_Take_Over_ME_1', NULL, 1, NULL, NULL, NULL, NULL )
,(329, 10, N'External extra flush time ME1 ', N'0', N'999', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 23, N'External_Extra_Flush_Time_ME1', N'0', 1, NULL, NULL, NULL, NULL )
,(330, 11, N'Group Number used for external take over ME 2', NULL, NULL, NULL, 9, NULL, NULL, NULL, 2, NULL, NULL, 24, N'Group_Number_Used_For_External_Take_Over_ME_2', NULL, 1, NULL, NULL, NULL, NULL )
,(331, 10, N'External extra flush time ME2', N'0', N'999', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 25, N'External_Extra_Flush_Time_ME2', N'0', 1, NULL, NULL, NULL, NULL )
,(332, 2, N'Digital Input Card 1 (Signal Machines) Position 0 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 26, N'Digital_Input_Card_1_Signal_Machines_Position_0_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(333, 2, N'Digital Input Card 6 (ME2 + P 10,11,12) Position 0 Rack 2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 27, N'Digital_Input_Card_6_(ME2 + P 10,11,12)_Position_0_Rack_2', N'false', 1, NULL, NULL, NULL, NULL )
,(334, 2, N'Digital Input Card 2 (Signal Machines) Position 1 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 28, N'Digital_Input_Card_2_(Signal_Machines)_Position_1_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(335, 2, N'Analogue Input Card 1 Position 5 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 29, N'Analogue_Input_Card_1_Position_5_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(336, 2, N'Digital Input Card 3 (Dosing Group 1) Position 2 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 30, N'Digital_Input_Card_3_(Dosing_Group_1)_Position_2_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(337, 2, N'Analogue Input Card 2 Position 6 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 31, N'Analogue_Input_Card_2_Position_6_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(338, 2, N'Digital Input Card 4 (Dosing Group 2) Position 3 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 32, N'Digital_Input_Card_4_(Dosing_Group_2)_Position_3_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(339, 2, N'Analogue Input Card 3 Position 1 Rack 3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 33, N'Analogue_Input_Card_3_Position_1_Rack_3', N'false', 1, NULL, NULL, NULL, NULL )
,(340, 2, N'Digital Input Card 5 (Miniterminal) Position 4 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 34, N'Digital_Input_Card_5_(Miniterminal)_Position_4_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(341, 2, N'Digital Input Card 7 (Transfer Carbonell) Position 7 Rack 3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 35, N'Digital_Input_Card_7_(Transfer_Carbonell)_Position_7_Rack_3', N'false', 1, NULL, NULL, NULL, NULL )
,(342, 10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL )
,(343, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 2, N'Install_Date', NULL, 1, N'InstallDate', NULL, NULL, NULL )
,(344, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', N'1', 0, N'ControllerNumber', NULL, NULL, N'dispNumber' )
,(345, 2, N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 4, N'Active', N'false', 1, N'Active', NULL, NULL, NULL )
,(346, 11, N'Controller Version', NULL, NULL, NULL, 3, 1, NULL, NULL, 2, NULL, NULL, 5, N'Controller Version', N'5', 0, N'ControllerVersion', NULL, NULL, NULL )
,(347, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 6, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL )
,(348, 10, N'IP Address', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 7, N'IP_Address', N'10.225.134.1', 1, NULL, NULL, NULL, NULL )
,(349, 2, N'PMR Enabled', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 4, N'PMR_Enabled', N'true', 1, NULL, NULL, NULL, NULL )
,(350, 2, N'Check Water flow Group1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 5, N'Check_Water_flow_Group1', N'true', 1, NULL, NULL, NULL, NULL )
,(351, 2, N'enVision Time out Enable', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 6, N'enVision_Time_out_Enable', N'true', 1, NULL, NULL, NULL, NULL )
,(352, 2, N'Check Water flow Group2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 7, N'Check_Water_flow_Group2', N'true', 1, NULL, NULL, NULL, NULL )
,(353, 10, N'enVision Timeout Alarm', N'1', N'999', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 8, N'enVision_Timeout_Alarm', N'10', 1, NULL, NULL, NULL, NULL )
,(354, 2, N'Check flow leakage alarm Group1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 9, N'Check_flow_leakage_Alarm_Group1', N'true', 1, NULL, NULL, NULL, NULL )
,(355, 10, N'Stop Time Dubix', N'0', N'99', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 10, N'Stop_Time_Dubix', N'0', 1, NULL, NULL, NULL, NULL )
,(356, 2, N'Check flow leakage alarm Group2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 11, N'Check_Flow_Leakage_Alarm_Group2', N'true', 1, NULL, NULL, NULL, NULL )
,(357, 2, N'Disable Program not finished Alarm', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 12, N'Disable_Program_Not_Finished_Alarm', N'false', 1, NULL, NULL, NULL, NULL )
,(358, 2, N'Start do not generate First Step', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 13, N'Start_Do_Not_Generate_First_Step', N'false', 1, NULL, NULL, NULL, NULL )
,(359, 2, N'Conductivity Compensation Stock Solution Tank 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 14, N'Conductivity_Compensation_Stock_Solution_Tank_1', N'false', 1, NULL, NULL, NULL, NULL )
,(360, 10, N'Alarm Reset Time', N'0', N'32767', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 15, N'Alarm_Reset_Time', N'60', 1, NULL, NULL, NULL, NULL)
,(361, 2, N'Conductivity Compensation Stock Solution Tank 2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 16, N'Conductivity_Compensation_Stock_Solution_Tank_2', N'false', 1, NULL, NULL, NULL, NULL )
,(362, 2, N'Enable Reset button', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 17, N'Enable_Reset_Button', N'false', 1, NULL, NULL, NULL, NULL )
,(363, 2, N'Internal Take-Over Main Equipment No. 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 18, N'Internal_Take-Over_Main_Equipment_No._1', N'false', 1, NULL, NULL, NULL, NULL )
,(364, 2, N'Switch Over from Stock Solution Tank 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 19, N'Switch_Over_from_Stock_Solution_Tank_1', N'false', 1, NULL, NULL, NULL, NULL )
,(365, 2, N'Internal Take-Over Main Equipment No. 2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 20, N'Internal_Take-Over_Main_Equipment_No._2', N'false', 1, NULL, NULL, NULL, NULL )
,(366, 2, N'Switch Over from Stock Solution Tank 2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 21, N'Switch_Over_from_Stock_Solution_Tank_2', N'false', 1, NULL, NULL, NULL, NULL )
,(367, 11, N'Group Number used for external take over ME 1', NULL, NULL, NULL, 9, NULL, NULL, NULL, 2, NULL, NULL, 22, N'Group_Number_Used_For_External_Take_Over_ME_1', NULL, 1, NULL, NULL, NULL, NULL )
,(368, 10, N'External extra flush time ME1 ', N'0', N'999', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 23, N'External_Extra_Flush_Time_ME1', N'0', 1, NULL, NULL, NULL, NULL )
,(369, 11, N'Group Number used for external take over ME 2', NULL, NULL, NULL, 9, NULL, NULL, NULL, 2, NULL, NULL, 24, N'Group_Number_Used_For_External_Take_Over_ME_2', NULL, 1, NULL, NULL, NULL, NULL )
,(370, 10, N'External extra flush time ME2', N'0', N'999', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 25, N'External_Extra_Flush_Time_ME2', N'0', 1, NULL, NULL, NULL, NULL )
,(371, 2, N'Digital Input Card 1 Signal Machines Position 0 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 26, N'Digital_Input_Card_1_Signal_Machines_Position_0_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(372, 2, N'Digital Input Card 6 (ME2 + P 10,11,12) Position 0 Rack 2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 27, N'Digital_Input_Card_6_(ME2 + P 10,11,12)_Position_0_Rack_2', N'false', 1, NULL, NULL, NULL, NULL )
,(373, 2, N'Digital Input Card 2 (Signal Machines) Position 1 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 28, N'Digital_Input_Card_2_(Signal_Machines)_Position_1_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(374, 2, N'Analogue Input Card 1 Position 5 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 29, N'Analogue_Input_Card_1_Position_5_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(375, 2, N'Digital Input Card 3 (Dosing Group 1) Position 2 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 30, N'Digital_Input_Card_3_(Dosing_Group_1)_Position_2_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(376, 2, N'Analogue Input Card 2 Position 6 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 31, N'Analogue_Input_Card_2_Position_6_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(377, 2, N'Digital Input Card 4 (Dosing Group 2) Position 3 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 32, N'Digital_Input_Card_4_(Dosing_Group_2)_Position_3_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(378, 2, N'Analogue Input Card 3 Position 1 Rack 3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 33, N'Analogue_Input_Card_3_Position_1_Rack_3', N'false', 1, NULL, NULL, NULL, NULL )
,(379, 2, N'Digital Input Card 5 (Miniterminal) Position 4 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 34, N'Digital_Input_Card_5_(Miniterminal)_Position_4_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(380, 2, N'Digital Input Card 7 (Transfer Carbonell) Position 7 Rack 3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 35, N'Digital_Input_Card_7_(Transfer_Carbonell)_Position_7_Rack_3', N'false', 1, NULL, NULL, NULL, NULL )

-- EControl Plus
,(381, 10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL )
,(382, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 2, N'Install_Date', NULL, 1, N'InstallDate', NULL, NULL, NULL )
,(383, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', N'1', 0, N'ControllerNumber', NULL, NULL, N'dispNumber' )
,(384, 2, N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 4, N'Active', N'false', 1, N'Active', NULL, NULL, NULL )
,(385, 11, N'Controller Version', NULL, NULL, NULL, 3, 1, NULL, NULL, 2, NULL, NULL, 5, N'Controller Version', N'4', 0, N'ControllerVersion', NULL, NULL, NULL )
,(386, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 6, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL )
,(387, 10, N'IP Address', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 7, N'IP_Address', N'10.225.134.1', 1, NULL, NULL, NULL, NULL )
,(388, 2, N'Analog Monitoring Enable', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 4, N'Analog_Monitoring_Enable', N'false', 1, NULL, NULL, NULL, NULL )
,(389, 2, N'Check Water Flow', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 5, N'Check_Water_Flow', N'true', 1, NULL, NULL, NULL, NULL )
,(390, 10, N'Stop Time Dubix', N'0', N'9.9', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 6, N'Stop_Time_Dubix', N'0', 1, NULL, NULL, NULL, NULL )
,(391, 2, N'Check Flow Leakage Alarm', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 7, N'Check_Flow_Leakage_Alarm', N'true', 1, NULL, NULL, NULL, NULL )
,(392, 2, N'Enable Reset button', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 8, N'Enable_Reset_Button', N'true', 1, NULL, NULL, NULL, NULL )
,(393, 2, N'Alarm Reverse', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 9, N'Alarm_Reverse', N'false', 1, NULL, NULL, NULL, NULL )
,(394, 10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL )
,(395, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 2, N'Install_Date', NULL, 1, N'InstallDate', NULL, NULL, NULL )
,(396, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', N'1', 0, N'ControllerNumber', NULL, NULL, N'dispNumber' )
,(397, 2, N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 4, N'Active', N'false', 1, N'Active', NULL, NULL, NULL )
,(398, 11, N'Controller Version', NULL, NULL, NULL, 3, 1, NULL, NULL, 2, NULL, NULL, 5, N'Controller Version', N'4', 0, N'ControllerVersion', NULL, NULL, NULL )
,(399, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 6, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL )
,(400, 10, N'IP Address', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 7, N'IP_Address', N'10.225.134.1', 1, NULL, NULL, NULL, NULL )
,(401, 2, N'Analog Monitoring Enable', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 4, N'Analog_Monitoring_Enable', N'false', 1, NULL, NULL, NULL, NULL )
,(402, 2, N'Check Water Flow', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 5, N'Check_Water_Flow', N'true', 1, NULL, NULL, NULL, NULL )
,(403, 10, N'Stop Time Dubix', N'0', N'9.9', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 6, N'Stop_Time_Dubix', N'0', 1, NULL, NULL, NULL, NULL )
,(404, 2, N'Check Flow Leakage Alarm', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 7, N'Check_Flow_Leakage_Alarm', N'true', 1, NULL, NULL, NULL, NULL )
,(405, 2, N'Enable Reset button', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 8, N'Enable_Reset_Button', N'true', 1, NULL, NULL, NULL, NULL )
,(406, 2, N'Alarm Reverse', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 9, N'Alarm_Reverse', N'false', 1, NULL, NULL, NULL, NULL )
,(407, 10, N'Hysteresis on Connexx Alarm Level', N'0', N'9', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Hysteresis_on_Connexx_Alarm_Level', N'2', 1, NULL, NULL, NULL, NULL )

-- EControl Central
,(408, 10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL )
,(409, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 2, N'Install_Date', NULL, 1, N'InstallDate', NULL, NULL, NULL )
,(410, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', N'1', 1, N'ControllerNumber', NULL, NULL, N'dispNumber')
,(411, 2, N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 4, N'Active', N'false', 1, N'Active', NULL, NULL, NULL )
,(412, 11, N'Controller Version', NULL, NULL, NULL, 10, 1, NULL, NULL, 2, NULL, NULL, 5, N'Controller Version', N'3', 1, N'ControllerVersion', NULL, NULL, N'ControllerVersion' )
,(413, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 6, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL )
,(414, 10, N'IP Address', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 7, N'IP_Address', N'10.225.134.1', 1, NULL, NULL, NULL, N'IPAddress' )
,(415, 11, N'Com Port Number', NULL, NULL, NULL, 11, 1, NULL, NULL, 2, NULL, NULL, 8, N'Com_Port_Number', N'0', 1, NULL, NULL, NULL, N'ComPortNumber' )
,(416, 2, N'Skip extension I/O module 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 4, N'Skip_extension_I/O_module_1', N'false', 1, NULL, NULL, NULL, NULL )
,(417, 2, N'Check Water Flow', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 5, N'Check_Water_Flow', N'true', 1, NULL, NULL, NULL, NULL )
,(418, 10, N'Stop Time Dubix', N'0', N'9.9', NULL, NULL, 1, NULL, NULL, 5, NULL, NULL, 6, N'Stop_Time_Dubix', N'0', 1, NULL, NULL, NULL, NULL )
,(419, 2, N'Alarm Reverse', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 7, N'Alarm_Reverse', N'false', 1, NULL, NULL, NULL, NULL )
,(420, 10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL )
,(421, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 2, N'Install_Date', NULL, 1, N'InstallDate', NULL, NULL, NULL )
,(422, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', N'1', 1, N'ControllerNumber', NULL, NULL, N'dispNumber' )
,(423, 2, N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 4, N'Active', N'false', 1, N'Active', NULL, NULL, NULL )
,(424, 11, N'Controller Version', NULL, NULL, NULL, 10, 1, NULL, NULL, 2, NULL, NULL, 5, N'Controller Version', N'3', 1, N'ControllerVersion', NULL, NULL, N'ControllerVersion' )
,(425, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 6, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL )
,(426, 10, N'IP Address', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 7, N'IP_Address', N'10.225.134.1', 1, NULL, NULL, NULL, N'IPAddress' )
,(427, 11, N'Com Port Number', NULL, NULL, NULL, 11, 1, NULL, NULL, 2, NULL, NULL, 8, N'Com_Port_Number', N'0', 1, NULL, NULL, NULL, N'ComPortNumber' )
,(428, 2, N'Skip extension I/O module 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 4, N'Skip_extension_I/O_module_1', N'false', 1, NULL, NULL, NULL, NULL )
,(429, 2, N'Check Water Flow', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 5, N'Check_Water_Flow', N'true', 1, NULL, NULL, NULL, NULL )
,(430, 10, N'Stop Time Dubix', N'0', N'9.9', NULL, NULL, 1, NULL, NULL, 5, NULL, NULL, 6, N'Stop_Time_Dubix', N'0', 1, NULL, NULL, NULL, NULL )
,(431, 2, N'Alarm Reverse', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 7, N'Alarm_Reverse', N'false', 1, NULL, NULL, NULL, NULL )
-- EControl Decentral
,(432, 10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL )
,(433, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 2, N'Install_Date', NULL, 1, N'InstallDate', NULL, NULL, NULL )
,(434, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', N'1', 1, N'ControllerNumber', NULL, NULL, N'dispNumber' )
,(435, 2, N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 4, N'Active', N'false', 1, N'Active', NULL, NULL, NULL )
,(436, 11, N'Controller Version', NULL, NULL, NULL, 10, 1, NULL, NULL, 2, NULL, NULL, 5, N'Controller Version', N'3', 1, N'ControllerVersion', NULL, NULL, N'ControllerVersion' )
,(437, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 6, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL )
,(438, 10, N'IP Address', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 7, N'IP_Address', N'10.225.134.1', 1, NULL, NULL, NULL, N'IPAddress' )
,(439, 11, N'Com Port Number', NULL, NULL, NULL, 11, 1, NULL, NULL, 2, NULL, NULL, 8, N'Com_Port_Number', N'0', 1, NULL, NULL, NULL, N'ComPortNumber' )
,(440, 2, N'Skip extension I/O module 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 4, N'Skip_extension_I/O_module_1', N'false', 1, NULL, NULL, NULL, NULL )
,(441, 2, N'Check Water Flow', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 5, N'Check_Water_Flow', N'true', 1, NULL, NULL, NULL, NULL )
,(442, 2, N'Alarm Reverse', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 6, N'Alarm_Reverse', N'false', 1, NULL, NULL, NULL, NULL )
,(443, 10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL )
,(444, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 2, N'Install_Date', NULL, 1, N'InstallDate', NULL, NULL, NULL )
,(445, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', N'1', 1, N'ControllerNumber', NULL, NULL, N'dispNumber' )
,(446, 2, N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 4, N'Active', N'false', 1, N'Active', NULL, NULL, NULL )
,(447, 11, N'Controller Version', NULL, NULL, NULL, 10, 1, NULL, NULL, 2, NULL, NULL, 5, N'Controller Version', N'3', 1, N'ControllerVersion', NULL, NULL, N'ControllerVersion' )
,(448, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 6, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL )
,(449, 10, N'IP Address', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 7, N'IP_Address', N'10.225.134.1', 1, NULL, NULL, NULL, N'IPAddress' )
,(450, 11, N'Com Port Number', NULL, NULL, NULL, 11, 1, NULL, NULL, 2, NULL, NULL, 8, N'Com_Port_Number', N'0', 1, NULL, NULL, NULL, N'ComPortNumber' )
,(451, 2, N'Skip extension I/O module 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 4, N'Skip_extension_I/O_module_1', N'false', 1, NULL, NULL, NULL, NULL )
,(452, 2, N'Check Water Flow', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 5, N'Check_Water_Flow', N'true', 1, NULL, NULL, NULL, NULL )
,(453, 2, N'Alarm Reverse', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 6, N'Alarm_Reverse', N'false', 1, NULL, NULL, NULL, NULL )
-- Ecodose
,(454, 10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL )
,(455, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 2, N'Install_Date', NULL, 1, N'InstallDate', NULL, NULL, NULL )
,(456, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', N'1', 1, N'ControllerNumber', NULL, NULL, N'dispNumber' )
,(457, 2, N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 4, N'Active', N'false', 1, N'Active', NULL, NULL, NULL )
,(458, 11, N'Controller Version', NULL, NULL, NULL, 10, 1, NULL, NULL, 2, NULL, NULL, 5, N'Controller Version', N'3', 1, N'ControllerVersion', NULL, NULL, N'ControllerVersion' )
,(459, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 6, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL )
,(460, 10, N'IP Address', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 7, N'IP_Address', N'10.225.134.07', 1, NULL, NULL, NULL, N'IPAddress')
,(461, 11, N'Com Port Number', NULL, NULL, NULL, 11, 1, NULL, NULL, 2, NULL, NULL, 8, N'Com_Port_Number', N'0', 1, NULL, NULL, NULL, N'ComPortNumber' )
,(462, 2, N'FX2N COM-ET-10 Used', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 4, N'FX2N_COM-ET-10_Used', N'false', 1, NULL, NULL, NULL, NULL )
,(463, 2, N'Check Water Flow', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 5, N'Check_Water_Flow', N'true', 1, NULL, NULL, NULL, NULL )
,(464, 2, N'Disable Program not finished alarm', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 6, N'Disable_Program_not_finished_alarm', N'false', 1, NULL, NULL, NULL, NULL )
,(465, 2, N'Disable not valid program alarm', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 7, N'Disable_not_valid_program_alarm', N'false', 1, NULL, NULL, NULL, NULL)

SET	IDENTITY_INSERT    TCD.Field	ON

MERGE	TCD.Field				AS			TARGET
USING	@tempField			AS			SOURCE
ON	TARGET.Id			=			SOURCE.Id
WHEN	NOT MATCHED		THEN
INSERT	(Id,TypeId,Label,[Min],[Max],FieldGroupId,DataSourceId, IsMandatory,HelpText,HelpTextURL,DataTypeId,DataCategoryId,CurrencyId
,DisplayOrder,ResourceKey,DefaultValue,IsEditable,Name,HasFieldTag,DefaultFieldTag,ClassName)
VALUES	(SOURCE.Id,SOURCE.TypeId,SOURCE.Label,SOURCE.[Min],SOURCE.[Max],SOURCE.FieldGroupId
,SOURCE.DataSourceId,SOURCE.IsMandatory,SOURCE.HelpText,SOURCE.HelpTextURL,SOURCE.DataTypeId,SOURCE.DataCategoryId,SOURCE.CurrencyId
,SOURCE.DisplayOrder,SOURCE.ResourceKey,SOURCE.DefaultValue,SOURCE.IsEditable,SOURCE.Name,SOURCE.HasFieldTag,SOURCE.DefaultFieldTag,SOURCE.ClassName);

SET	IDENTITY_INSERT	[TCD].Field	OFF
-- =============================




--Declare temp table variable to hold input data
DECLARE	@tempFieldGroupFieldMapping				TABLE	(
TempId					INT				IDENTITY(1, 1)
,	Id						INT				NOT	NULL
,	FieldGroupId			INT				NOT	NULL
,	FieldId					INT				NOT	NULL
)

--Populate temp table variable with the input data
INSERT	@tempFieldGroupFieldMapping	(
Id	,FieldGroupId	,FieldId)
VALUES (348, 4, 213)
,(349, 4, 262)
,(355, 25, 270 )
,(356, 25, 271 )
,(357, 25, 272 )
,(358, 25, 273 )
,(359, 25, 274 )
,(360, 25, 275 )
,(361, 25, 277 )
,(362, 25, 278 )
,(363, 25, 279 )
,(364, 25, 280 )
,(365, 25, 281 )
,(366, 25, 282 )
,(367, 25, 283 )
,(368, 25, 284 )
,(369, 25, 285 )
,(370, 25, 286 )
,(371, 25, 287 )
,(372, 25, 288 )
,(373, 25, 289 )
,(374, 25, 290 )
,(375, 25, 291 )
,(376, 25, 292 )
,(377, 26, 293 )
,(378, 26, 294 )
,(379, 26, 295 )
,(380, 26, 296 )
,(381, 26, 297 )
,(382, 26, 298 )
,(383, 26, 299 )
,(384, 26, 300 )
,(385, 26, 301 )
,(387, 23, 263 )
,(388, 23, 264 )
,(389, 23, 265 )
,(390, 23, 266 )
,(391, 23, 267 )
,(392, 23, 268 )
,(393, 23, 269 )
,(394, 24, 214 )
,(395, 24, 215 )
,(396, 24, 216 )
,(397, 27, 303 )
,(398, 27, 304 )
,(399, 27, 305 )
,(400, 27, 306 )
,(401, 27, 307 )
,(402, 27, 308 )
,(403, 27, 309 )
,(404, 28, 214 )
,(405, 28, 215 )
,(406, 28, 216 )
,(407, 29, 310 )
,(408, 29, 311 )
,(409, 29, 312 )
,(410, 29, 313 )
,(411, 29, 314 )
,(412, 29, 315 )
,(413, 29, 316 )
,(414, 29, 317 )
,(415, 29, 318 )
,(416, 29, 319 )
,(417, 29, 320 )
,(418, 29, 321 )
,(419, 29, 322 )
,(420, 29, 323 )
,(421, 29, 324 )
,(422, 29, 325 )
,(423, 29, 326 )
,(424, 29, 327 )
,(425, 29, 328 )
,(426, 29, 329 )
,(427, 29, 330 )
,(428, 29, 331 )
,(429, 30, 332 )
,(430, 30, 333 )
,(431, 30, 334 )
,(432, 30, 335 )
,(433, 30, 336 )
,(434, 30, 337 )
,(435, 30, 338 )
,(436, 30, 339 )
,(437, 30, 340 )
,(439, 31, 342 )
,(440, 31, 343 )
,(441, 31, 344 )
,(442, 31, 345 )
,(443, 31, 346 )
,(444, 31, 347 )
,(445, 31, 348 )
,(446, 32, 214 )
,(447, 32, 215 )
,(448, 32, 216 )
,(449, 33, 349 )
,(450, 33, 350 )
,(451, 33, 351 )
,(452, 33, 352 )
,(453, 33, 353 )
,(454, 33, 354 )
,(455, 33, 355 )
,(456, 33, 356 )
,(457, 33, 357 )
,(458, 33, 358 )
,(459, 33, 359 )
,(460, 33, 360 )
,(461, 33, 361 )
,(462, 33, 362 )
,(463, 33, 363 )
,(464, 33, 364 )
,(465, 33, 365 )
,(466, 33, 366 )
,(467, 33, 367 )
,(468, 33, 368 )
,(469, 33, 369 )
,(470, 33, 370 )
,(471, 34, 371 )
,(472, 34, 372 )
,(473, 34, 373 )
,(474, 34, 374 )
,(475, 34, 375 )
,(476, 34, 376 )
,(477, 34, 377 )
,(478, 34, 378 )
,(479, 34, 379 )
,(481, 35, 381 )
,(482, 35, 382 )
,(483, 35, 383 )
,(484, 35, 384 )
,(485, 35, 385 )
,(486, 35, 386 )
,(487, 35, 387 )
,(488, 36, 214 )
,(489, 36, 215 )
,(490, 36, 407 )
,(491, 37, 388 )
,(492, 37, 389 )
,(493, 37, 390 )
,(494, 37, 391 )
,(495, 37, 392 )
,(496, 37, 393 )
,(497, 38, 394 )
,(498, 38, 395 )
,(499, 38, 396 )
,(500, 38, 397 )
,(501, 38, 398 )
,(502, 38, 399 )
,(503, 38, 400 )
,(504, 39, 214 )
,(505, 39, 215 )
,(506, 39, 407 )
,(507, 40, 401 )
,(508, 40, 402 )
,(509, 40, 403 )
,(510, 40, 404 )
,(511, 40, 405 )
,(512, 40, 406 )
,(513, 41, 408 )
,(514, 41, 409 )
,(515, 41, 410 )
,(516, 41, 411 )
,(517, 41, 412 )
,(518, 41, 413 )
,(519, 41, 414 )
,(520, 41, 415 )
,(521, 42, 214 )
,(522, 42, 215 )
,(523, 42, 407 )
,(524, 43, 416 )
,(525, 43, 417 )
,(526, 43, 418 )
,(527, 43, 419 )
,(528, 44, 420 )
,(529, 44, 421 )
,(530, 44, 422 )
,(531, 44, 423 )
,(532, 44, 424 )
,(533, 44, 425 )
,(534, 44, 426 )
,(535, 44, 427 )
,(536, 45, 214 )
,(537, 45, 215 )
,(538, 45, 407 )
,(539, 46, 428 )
,(540, 46, 429 )
,(541, 46, 430 )
,(542, 46, 431 )
,(543, 47, 432 )
,(544, 47, 433 )
,(545, 47, 434 )
,(546, 47, 435 )
,(547, 47, 436 )
,(548, 47, 437 )
,(549, 47, 438 )
,(550, 47, 439 )
,(551, 48, 214 )
,(552, 48, 215 )
,(553, 48, 407 )
,(554, 49, 440 )
,(555, 49, 441 )
,(556, 49, 442 )
,(557, 50, 443 )
,(558, 50, 444 )
,(559, 50, 445 )
,(560, 50, 446 )
,(561, 50, 447 )
,(562, 50, 448 )
,(563, 50, 449 )
,(564, 50, 450 )
,(565, 51, 214 )
,(566, 51, 215 )
,(567, 51, 407 )
,(568, 52, 451 )
,(569, 52, 452 )
,(570, 52, 453 )
,(571, 53, 454 )
,(572, 53, 455 )
,(573, 53, 456 )
,(574, 53, 457 )
,(575, 53, 458 )
,(576, 53, 459 )
,(577, 53, 460 )
,(578, 53, 461 )
,(579, 54, 214 )
,(580, 54, 215 )
,(581, 54, 407 )
,(582, 55, 462 )
,(583, 55, 463 )
,(584, 55, 464 )
,(585, 55, 465 )

SET	IDENTITY_INSERT	TCD.FieldGroupFieldMapping	ON

MERGE	TCD.FieldGroupFieldMapping	AS	TARGET
USING	@tempFieldGroupFieldMapping	AS	SOURCE
ON	TARGET.Id			=			SOURCE.Id
WHEN	NOT MATCHED		THEN
INSERT	(Id,FieldGroupId,FieldId)
VALUES	(SOURCE.Id,SOURCE.FieldGroupId,SOURCE.FieldId);

SET	IDENTITY_INSERT	[TCD].FieldGroupFieldMapping	OFF
-- ==========================
GO


--Declare temp table variable to hold input data
DECLARE	@tempDataSource		TABLE	(
TempId					INT				IDENTITY(1, 1)
,	Id						INT				NOT	NULL
,	Name					NVARCHAR(50)
,	[Description]			NVARCHAR(250)
)

--Populate temp table variable with the input data
INSERT	@tempDataSource	(
Id	,Name	,[Description]	)
VALUES	 (8, N'Dosing Line Mode', N'Dosing Line Mode')
,(9, N'External Take Over ME', N'Group Number used for external take over ME in PLC XL 2T')
,(10, N'Controller Version', N'Controller Version for Central and Decentral General tab')
,(11, N'Com Ports', N'Com Ports for Central and Decentral General tab');

SET	IDENTITY_INSERT	TCD.DataSource	ON

MERGE	TCD.DataSource					AS			TARGET
USING	@tempDataSource				AS			SOURCE
ON	TARGET.Id					=			SOURCE.Id
WHEN	NOT MATCHED		THEN
INSERT	(Id			,Name			,[Description]			)
VALUES	(SOURCE.Id	,SOURCE.Name	,SOURCE.[Description]	);

SET	IDENTITY_INSERT	[TCD].DataSource	OFF


-- =============================

--Declare temp table variable to hold input data
DECLARE	@tempFieldSource		TABLE	(
TempId					INT				IDENTITY(1, 1)
,	DataSourceId			INT				NOT	NULL
,	Name					NVARCHAR(50)	NOT	NULL
,	Value					NVARCHAR(50)	NOT	NULL
)

--Populate temp table variable with the input data
INSERT	@tempFieldSource	(
DataSourceId,Name,Value)
VALUES	
(8, N'Standard Mode', N'1' )
,(8, N'Turbo Compact Rack', N'2' )
,(9, N'0', N'0' )
,(9, N'1', N'1' )
,(9, N'2', N'2' )
,(10, N'1', N'1' )
,(10, N'3', N'2' )
,(11, N'none', N'0' )
,(11, N'Com 1', N'1' )
,(11, N'Com 2', N'2' )
,(11, N'Com 3', N'3' )
,(11, N'Com 4', N'4' )
,(11, N'Com 5', N'5' )
,(11, N'Com 6', N'6' )
,(11, N'Com 7', N'7' )
,(11, N'Com 8', N'8' )
,(11, N'Com 9', N'9' )
,(11, N'Com 10', N'10' )
,(11, N'Com 11', N'11' )
,(11, N'Com 12', N'12' )
,(11, N'Com 13', N'13' )
,(11, N'Com 14', N'14' )
,(11, N'Com 15', N'15' )
,(11, N'Com 16', N'16' )


MERGE	TCD.FieldSource	AS	TARGET
USING	@tempFieldSource	AS	SOURCE
ON	TARGET.DataSourceId		=	SOURCE.DataSourceId
AND	TARGET.Name			=	SOURCE.Name
AND	TARGET.Value			=	SOURCE.Value
WHEN	NOT MATCHED		THEN
INSERT	(DataSourceId,Name,Value	)
VALUES	(SOURCE.DataSourceId,SOURCE.Name,SOURCE.Value);

GO

UPDATE tcd.field
	SET DefaultValue = '10.225.134.07'
	WHERE id = 460 and Label = 'IP Address'

	DELETE FROM tcd.fieldgroupfieldmapping  WHERE FieldGroupId=54 AND fieldid IN (214,215,407)
	DELETE FROM tcd.fieldgroup WHERE id=54 AND Name='Connexx'

GO

BEGIN
---============
--DECLARE Temp Table for INSERTING RESOURCE KEYS OF CONNECTIONS, COMPARTMENT AND ANALOGUE DOSING
--==========
DECLARE @PAGEID INT = 47, @PAGEID1 INT = 48, @PageIdAnalog INT = 49;

IF NOT EXISTS(SELECT * FROM [TCD].[Page] WHERE [PAGENAME] = 'Connections')
BEGIN
	INSERT INTO [TCD].[Page]
	(
	PAGEID,
	PAGENAME,
	PAGEDESCRIPTION
	)
	VALUES
	(
	@PAGEID,
	'Connections',
	'Connections tab'
	)	
END
ELSE
	SELECT @PAGEID = PAGEID FROM [TCD].[Page] WHERE PAGENAME = 'Connections';

IF NOT EXISTS(SELECT 1 FROM [TCD].[Page] WHERE [PAGENAME] = 'Compartment')
BEGIN
	INSERT INTO [TCD].[Page]
	(
	PAGEID,
	PAGENAME,
	PAGEDESCRIPTION
	)
	VALUES
	(
	@PAGEID1,
	'Compartment',
	'Compartment Tab'
	)	
END
ELSE
	SELECT @PAGEID1 = PAGEID FROM [TCD].[Page] WHERE PAGENAME = 'Compartment';

IF NOT EXISTS(SELECT 1 FROM [TCD].[Page] WHERE [PAGENAME] = 'AnalogueDosing')
BEGIN
	INSERT INTO [TCD].[Page]
	(
	PAGEID,
	PAGENAME,
	PAGEDESCRIPTION
	)
	VALUES
	(
	@PageIdAnalog,
	'AnalogueDosing',
	'Analogue Dosing Control'
	)	
END
ELSE
	SELECT @PageIdAnalog = PAGEID FROM [TCD].[Page] WHERE PAGENAME = 'AnalogueDosing';


DECLARE	@tempResourceKeys			TABLE	(
ResourceKey					NVARCHAR(100) NOT NULL
,	ResourceValue						NVARCHAR(150)				NOT	NULL
,	PageId			INT				NOT	NULL
,	LanguageId    INT NOT NULL
)

INSERT INTO @tempResourceKeys (ResourceKey,ResourceValue,PageId,LanguageId)
VALUES
('FIELD_CONNECTIONS','Connections',@PAGEID,CAST(1 AS INT)),
('FIELD_VALVENOFOR','Valve No. for',@PAGEID,1),
('FIELD_CONNDOSINGPOINT','Dosing Point',@PAGEID,1),
('FIELD_DosingLine','Dosing Line',@PAGEID,1),
('FIELD_VALVE','Valve',@PAGEID,1),
('FIELD_ME','Main Equipment',@PAGEID,1),
('FIELD_PUMPS','Pumps',@PAGEID,1),
('FIELD_DEVICES','Devices',@PAGEID1,1),
('FIELD_REDOX','Redox',@PAGEID1,1),
('FIELD_CONDUCTIVITY','Conductivity',@PAGEID1,1),
('FIELD_FLUSHTIMES','Flush Times',@PAGEID1,1),

('FIELD_Level','Level',@PageIdAnalog,1),
('FIELD_SetPoint','Set Point',@PageIdAnalog,1),
('FIELD_DelayAfterTransfer','Delay After Transfer',@PageIdAnalog,1),
('FIELD_PreQuantity','Pre Quantity',@PageIdAnalog,1),
('FIELD_PrePause','Pre Pause',@PageIdAnalog,1),
('FIELD_Quantity','Quantity',@PageIdAnalog,1),
('FIELD_PauseTime','Pause Time',@PageIdAnalog,1),
('FIELD_MaxTime','Max. Time',@PageIdAnalog,1),
('FIELD_MinValue','Min. Value',@PageIdAnalog,1),
('FIELD_MaxValue','Max. Value',@PageIdAnalog,1),
('FIELD_ControlDelay','Control Delay',@PageIdAnalog,1),
('FIELD_pHControlSetup','pH Control Setup',@PageIdAnalog,1),
('FIELD_ConductivityControlSetup','Conductivity Control Setup',@PageIdAnalog,1),
('FIELD_ANALOGDOSINGSAVEDSUCCESSFULLY','Analogue Dosing Control data saved successfully.',@PageIdAnalog,1)

MERGE	TCD.ResourceKeyMaster	AS	TARGET
USING	@tempResourceKeys	AS	SOURCE
ON	TARGET.KeyName		=	SOURCE.ResourceKey
WHEN	NOT MATCHED		THEN
INSERT	(KeyName)
VALUES	(SOURCE.ResourceKey);

MERGE	TCD.ResourceKeyValue	AS	TARGET
USING	@tempResourceKeys	AS	SOURCE
ON	TARGET.KeyName		=	SOURCE.ResourceKey
AND TARGET.Value		=	SOURCE.ResourceValue
AND TARGET.languageID		=	SOURCE.languageID
WHEN	NOT MATCHED		THEN
INSERT	(KeyName,Value,languageID,LastModifiedTime)
VALUES	(SOURCE.ResourceKey,SOURCE.ResourceValue,SOURCE.languageID, GETUTCDATE());

MERGE	TCD.ResourceKeyPageMapping	AS	TARGET
USING	@tempResourceKeys	AS	SOURCE
ON	TARGET.KeyName		=	SOURCE.ResourceKey
AND TARGET.PageID		=	SOURCE.PageId
WHEN	NOT MATCHED		THEN
INSERT	(KeyName,PageID)
VALUES	(SOURCE.ResourceKey,PageID);

END
GO


