/* [TCD].[Washer] */
IF NOT EXISTS(SELECT 1 FROM sys.columns 
            WHERE Name = N'DefaultIdleTime' AND Object_ID = Object_ID(N'[TCD].[Washer]'))
BEGIN
    ALTER TABLE [TCD].[Washer]
	ADD DefaultIdleTime SMALLINT NULL
END

IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[GetWasherList]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[GetWasherList] 
END 
GO 
/*	
Purpose					:	To populate the grid in the Washer setup --> Washers listing

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version

*/

CREATE	PROCEDURE	[TCD].[GetWasherList] -- '040242802', 4,2
     @EcoLabAccountNumber     NVARCHAR(1000)

    , @WasherGroupId       INT   =   NULL
    , @WasherId        INT   =   NULL
    , @Is_Deleted        bit   =   'FALSE'
AS
BEGIN

SET NOCOUNT ON


SELECT --*
  W.PlantWasherNumber    AS   WasherNumber
 , MS.MachineName     AS   WasherName
 , CASE MS.IsTunnel
   WHEN 'TRUE' THEN 'Tunnel'
   WHEN 'FALSE' THEN 'WasherExtractor'
  END        AS   WasherType
 , MS.IsTunnel      AS   WasherTypeFlag
 , WMS.WasherModelName    AS   WasherModel
 , WMS.WasherModelId    AS   WasherModelId
 , WMS.WasherSize     AS   WasherSize
 , CC.Name       AS   WasherControllerName
 , W.WasherId      AS   WasherId
 , WG.WasherGroupId    AS   WasherGroupId
 , WG.WasherGroupName    AS   WasherGroupName
 , CC.ControllerId     AS   WasherControllerId

 , W.[Description]     AS   WasherDescription
 , W.MaxLoad      AS   WashermaxLoad

 , W.WasherMode     AS   WasherModeId

 , W.AWEActive      AS   WasherAWEActive
 , MS.NumberOfComp     AS   WasherNumberOfCompartments

 , CAST(W.NumberOfTanks AS SMALLINT)
          AS   WasherNumberOfTanks
 , CAST(W.PressExtractor AS SMALLINT)
          AS   WasherPressExtractorId
 , CAST(W.TransferType  AS SMALLINT)
          AS   WasherTransferTypeId
    , CASE MS.IsTunnel WHEN 1 THEN CAST(W.EmptyPocketNumber AS SMALLINT) ELSE CAST(W.EndOfFormula AS SMALLINT) END AS WasherProgramNumber

 -- Columns for conventionals
 , W.HoldSignal     AS   HoldDelay
 , CAST(W.HoldDelay AS INT)  AS   HoldSignal
 , CAST(W.TargetTurnTime AS INT) AS   TargetTurnTime
 , CAST(W.WaterFlushTime AS INT) AS   WaterFlushTime
 , MS.MachineInternalId   AS   LFSWasherNumber

 -- Cols. for integration with Synch./Central
 , W.LastModifiedTime    AS   LastModifiedTime
 , W.LastSyncTime     AS   LastSyncTime
 , W.Is_Deleted     AS   Is_Deleted
 , W.EcoLabAccountNumber   AS   EcolabAccountNumber
 , (SELECT Count(*) FROM tcd.TunnelProgramSetup wps WHERE wps.WasherGroupId=@WasherGroupId AND wps.Is_Deleted=0) AS FormulaCount
 , GT.MyServiceCustMchGrpGuid
 , W.MyServiceCustMchGuid
 , WMS.MyServiceMCHId
 , TPE.Name      AS   PressExtractorName
 , TTT.Name      AS   TransferTypeName
 ,   W.RatioDosingActive    AS   RatioDosingActive
 , W.EcolabWasherId    AS   EcolabWasherNumber
 , CAST(W.EndOfFormula AS SMALLINT)AS   EndOfFormula
 , W.MyServiceLastSynchTime  AS   MyServiceLastSynchTime
 ,MS.IsPony AS IsPony
	,   CAST(W.DefaultIdleTime AS INT) AS   DefaultIdleTime 
FROM [TCD].WasherGroup     WG
JOIN [TCD].MachineGroup     GT
 ON WG.WasherGroupId    =   GT.Id
 AND WG.EcolabAccountNumber   =   GT.EcolabAccountNumber
JOIN [TCD].MachineSetup     MS
 ON WG.WasherGroupId    =   MS.GroupId
 AND WG.EcolabAccountNumber   =   MS.EcoalabAccountNumber
JOIN [TCD].Washer      W
 ON MS.WasherId      =   W.WasherId
 AND MS.EcoalabAccountNumber   =   W.EcoLabAccountNumber
JOIN [TCD].WasherModelSize    WMS
 ON W.ModelId      =   WMS.WasherModelId
JOIN [TCD].ConduitController    CC
 ON MS.ControllerId     =   CC.ControllerId
 AND MS.EcoalabAccountNumber   =   CC.EcoalabAccountNumber
LEFT JOIN [TCD].TunnelPressExtractor   TPE
 ON W.PressExtractor                =   TPE.TunnelPressExtractorId  
LEFT JOIN [TCD].TunnelTransferType   TTT
 ON W.TransferType     =   TTT.TunnelTransferTypeId
WHERE GT.EcolabAccountNumber   =   @EcoLabAccountNumber
 AND GT.GroupTypeId        =   2

 AND (GT.Is_Deleted     =   'FALSE' OR GT.Is_Deleted = @Is_Deleted)
 AND WG.WasherGroupId    =   ISNULL(@WasherGroupId, WG.WasherGroupId)
 AND WG.EcolabAccountNumber   =   @EcoLabAccountNumber
 AND MS.EcoalabAccountNumber   =   @EcoLabAccountNumber
 AND (MS.IsDeleted     =   'FALSE' OR MS.IsDeleted = @Is_Deleted)
 AND (W.Is_Deleted     =   'FALSE' OR W.Is_Deleted = @Is_Deleted)
 AND W.WasherId      =   ISNULL(@WasherId, W.WasherId)
 AND W.EcoLabAccountNumber   =   @EcoLabAccountNumber




SET NOCOUNT OFF

END

GO
IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[AddConventional]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[AddConventional] 
END 
GO 
/*	
Purpose					:	To add a new Conventional Washer from the Washer setup UI - General tab

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version

--sp_helptext	usp_AddConventional

*/

CREATE PROCEDURE [TCD].[AddConventional]
@EcoLabAccountNumber     NVARCHAR(1000)
, @WasherGroupId       INT
, @NewWasherGroupId		int
, @ConventionalName      NVARCHAR(50)
, @ModelId        INT      --(Washer)Model Id for Size
, @ControllerId       INT
, @LFSWasherNumber      TINYINT     = NULL
, @PlantWasherNumber      SMALLINT
, @WasherMode        TINYINT
, @MaxLoad        SMALLINT
, @AWEActive        BIT
, @HoldSignal        BIT
, @HoldDelay        SMALLINT
, @TargetTurnTime       SMALLINT
, @WaterFlushTime       SMALLINT
, @ProgramNumber       TINYINT     --EOF number
, @Description       NVARCHAR(1024)   = NULL
, @UserId         INT
, @ConventionalWasherGuid     UniqueIdentifier
, @ConventionalWasherId     INT         OUTPUT
, @LastModifiedTimestampAtCentral   DATETIME    = NULL
, @OutputLastModifiedTimestampAtLocal  DATETIME    = NULL OUTPUT
, @IsDeleted        BIT      = 'FALSE'
,   @RatioDosingActive      BIT      = 'FALSE'
				,   @IsPony      BIT      = 'FALSE'
, @DefaultIdleTime SMALLINT
, @MyServiceLastSyncTime     DATETIME    = NULL


AS
BEGIN

SET NOCOUNT ON


DECLARE	
  @ReturnValue     INT    =   0
 , @ErrorId      INT    =   0
 , @ErrorMessage     NVARCHAR(4000) =   N''

 , @WasherId      INT    =   NULL
 --, @WasherModelId     SMALLINT  =   NULL
 --, @CurrentUTCTime     DATETIME  =   GETUTCDATE()     --SQLEnlight SA0004

DECLARE
   @OutputList      AS TABLE  (
   WasherId      INT
  , LastModifiedTimestamp   DATETIME
		)

SET  @ConventionalWasherId = ISNULL(@ConventionalWasherId, NULL)   --SQLEnlight
SET  @OutputLastModifiedTimestampAtLocal   =   ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)   --SQLEnlight
SET  @LastModifiedTimestampAtCentral    =   ISNULL(@LastModifiedTimestampAtCentral, NULL)    --SQLEnlight SA0029

--Check that the WasherGroup being associated-to is a valid Conventional-type WG...
IF NOT EXISTS ( SELECT 1
	 FROM [TCD].WasherGroup     WG
	 JOIN [TCD].WasherGroupType    WGT
	  ON WG.WasherGroupTypeId  =   WGT.WasherGroupTypeId
	 JOIN [TCD].MachineGroup     GT         --this is actually the Groups table and NOT really a Group TYPE
	  ON WG.WasherGroupId   =   GT.Id   --Id is actually the Id of the Group
	  AND WG.EcolabAccountNumber  =   GT.EcolabAccountNumber 
	 WHERE WG.WasherGroupId   =   @WasherGroupId
	  AND GT.EcolabAccountNumber  =   @EcoLabAccountNumber
	  AND GT.GroupTypeId      =   2   --select GroupMaintype from MachineGroup
	  AND WGT.WasherGroupTypeName  =   'Conventional'   --select WasherGroupTypeName from WasherGroupType
	  AND GT.Is_Deleted    =   'FALSE'
				)
			BEGIN
	SET  @ErrorId      =   51001
	SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherGroup provided.'
	--GOTO ErrorHandler
	RAISERROR (@ErrorMessage, 16, 1)
	SET  @ReturnValue = -1
	RETURN (@ReturnValue)
			END

--Check for unique PlantWasherNo.
IF EXISTS  ( SELECT 1
	 FROM [TCD].Washer      W
	 JOIN [TCD].MachineSetup     MS
	  ON W.WasherId     =   MS.WasherId
	  AND W.EcoLabAccountNumber  =   MS.EcoalabAccountNumber
	 WHERE W.EcoLabAccountNumber  =   @EcoLabAccountNumber
	  AND (
	   W.PlantWasherNumber   =   @PlantWasherNumber
							)
	  AND W.Is_Deleted    =   'FALSE'
	  AND MS.IsDeleted    =   'FALSE'
				)
			BEGIN
	SET  @ErrorId      =   51002
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Specified Plant Washer #/ already exists.'
	--GOTO ErrorHandler
	RAISERROR (@ErrorMessage, 16, 1)
	SET  @ReturnValue = -1
	RETURN (@ReturnValue)
			END

--Check on valid LFSWasher#/Controller type/model...
IF @LFSWasherNumber IS NOT NULL
BEGIN
IF NOT EXISTS ( SELECT 1
	 FROM [TCD].ControllerModelControllerTypeMapping
														CMCTM
	 JOIN [TCD].ConduitController   CC
	  ON CC.ControllerTypeId   =   CMCTM.ControllerTypeId
	  AND CC.ControllerModelId  =   CMCTM.ControllerModelId
	 WHERE CC.EcoalabAccountNumber  =   @EcoLabAccountNumber
	  AND CC.ControllerId    =   @ControllerId
	  AND CC.IsDeleted    =   'FALSE'
	  AND CMCTM.MaximumWasherExtractorCount
			  >=   @LFSWasherNumber
				)
			BEGIN
	SET  @ErrorId      =   51003
	SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller/LFSWasher# was provided.'
	--GOTO ErrorHandler
	RAISERROR (@ErrorMessage, 16, 1)
	SET  @ReturnValue = -1
	RETURN (@ReturnValue)
			END
END
--EOF should not be an asocciated formula for the WG...
IF EXISTS  ( SELECT 1
	 FROM [TCD].WasherProgramSetup   WPS
	 WHERE WPS.EcolabAccountNumber  =   @EcoLabAccountNumber
	  AND WPS.WasherGroupId   =   @WasherGroupId
	  AND WPS.ProgramNumber   =   @ProgramNumber
	  AND WPS.Is_Deleted    =   'FALSE'
				)
			BEGIN
	SET  @ErrorId      =   51004
	SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An assoicated formula cannot be specified as End-Of-Formula.'
	--GOTO ErrorHandler
	RAISERROR (@ErrorMessage, 16, 1)
	SET  @ReturnValue = -1
	RETURN (@ReturnValue)
			END

--WasherMode check
IF NOT EXISTS ( SELECT 1
	 FROM [TCD].ControllerModelControllerTypeMapping
														CMCTM
JOIN [TCD].ConduitController   CC
ON CC.ControllerTypeId   =   CMCTM.ControllerTypeId
AND CC.ControllerModelId  =   CMCTM.ControllerModelId
JOIN [TCD].[WasherMode]
CTM2WM
ON CMCTM.Id     =   CTM2WM.ControllerModelControllerTypeMappingId
WHERE CC.EcoalabAccountNumber  =   @EcoLabAccountNumber
AND CC.ControllerId    =   @ControllerId
AND CC.IsDeleted    =   'FALSE'
AND CTM2WM.WasherModeId   =   @WasherMode
				)
			BEGIN
	SET  @ErrorId      =   51005
	SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherMode was provided.'
	--GOTO ErrorHandler
	RAISERROR (@ErrorMessage, 16, 1)
	SET  @ReturnValue = -1
	RETURN (@ReturnValue)
			END

--LFSWasherNumber duplicate check...
IF EXISTS ( SELECT 1
FROM [TCD].MachineSetup     MS
WHERE MS.ControllerId     =   @ControllerId
AND MS.MachineInternalId   =   @LFSWasherNumber
AND MS.EcoalabAccountNumber   =   @EcoLabAccountNumber
AND MS.IsDeleted     =   'FALSE'
			)
			BEGIN
	SET  @ErrorId      =   51010
	SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate LFSWasher# provided.'
	--GOTO ErrorHandler
	RAISERROR (@ErrorMessage, 16, 1)
	SET  @ReturnValue = -1
	RETURN (@ReturnValue)
			END

--Now attempt to insert a new row for the conventional washer being added...
BEGIN TRAN

INSERT [TCD].Washer (
EcoLabAccountNumber ,PlantWasherNumber ,ModelId    ,WasherMode  ,MaxLoad  ,AWEActive  ,EndOfFormula
, [Description]  ,Is_Deleted   ,LastModifiedByUserId ,HoldSignal  ,HoldDelay  ,TargetTurnTime ,WaterFlushTime, MyServiceCustMchGuid
, RatioDosingActive ,DefaultIdleTime, MyServiceLastSynchTime
	)
OUTPUT
 inserted.WasherId      AS   Id
, inserted.LastModifiedTime  AS   LastModifiedTimestamp
INTO
 @OutputList (
	WasherId
, LastModifiedTimestamp
)

SELECT @EcoLabAccountNumber    AS   EcoLabAccountNumber
, @PlantWasherNumber     AS   PlantWasherNumber
, @ModelId       AS   ModelId
, @WasherMode       AS   WasherMode
, @MaxLoad       AS   MaxLoad
, @AWEActive       AS   AWEActive
, @ProgramNumber      AS   ProgramNumber
, @Description      AS   [Description]
, @IsDeleted       AS   Is_Deleted
, @UserId        AS   LastModifiedByUserId
, @HoldSignal       AS   HoldSignal
, @HoldDelay    AS   HoldDelay
, @TargetTurnTime      AS   TargetTurnTime
, @WaterFlushTime      AS   WaterFlushTime
, @ConventionalWasherGuid    AS   MyServiceCustMchGuid
, @RatioDosingActive     AS   RatioDosingActive
, @DefaultIdleTime    AS DefaultIdleTime
, @MyServiceLastSyncTime    AS   MyServiceLastSynchTime


SET @ErrorId = @@ERROR
	
IF (@ErrorId <> 0)
	BEGIN
   IF @@TRANCOUNT > 0
			BEGIN
	ROLLBACK TRAN
			END

   SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred creating new record for conventional.'
   RAISERROR (@ErrorMessage, 16, 1)
   SET  @ReturnValue = -1
   RETURN (@ReturnValue)
	END

--if no error, collect the id of the newly generated row...
SELECT TOP 1 @WasherId = O.WasherId FROM @OutputList O

--insert in MachineSetup
INSERT [TCD].MachineSetup (
  WasherId ,GroupId ,MachineInternalId ,EcoalabAccountNumber ,MachineName ,IsTunnel ,ControllerId , IsDeleted ,LastModifiedByUserId,IsPony )
SELECT @WasherId     AS   WasherId
 , @WasherGroupId    AS   GroupId
 , @LFSWasherNumber   AS   MachineInternalId
 , @EcoLabAccountNumber  AS   EcoalabAccountNumber
 , @ConventionalName   AS   MachineName
 ,@IsDeleted      AS   IsTunnel
 , @ControllerId    AS   ControllerId
 , 'FALSE'      AS   IsDeleted
 , @UserId      AS   LastModifiedByUserId
 ,@IsPony As IsPony

 EXEC TCD.SaveInjectionDetails @WasherGroupId,@ControllerId,@WasherId, @EcoLabAccountNumber

IF(@WasherGroupId != @NewWasherGroupId)
BEGIN
UPDATE tcd.machinesetup
SET GroupId = @NewWasherGroupId
WHERE WasherId = @WasherId

UPDATE tcd.Injection
SET
WasherGroupNumber = (SELECT	wg.WasherGroupNumber
FROM	tcd.WasherGroup			wg
WHERE	wg.WasherGroupId		=		@NewWasherGroupId)
WHERE WasherId		=	@WasherId
END
SET @ErrorId = @@ERROR

IF (@ErrorId <> 0)
	BEGIN
   IF @@TRANCOUNT > 0
			BEGIN
	ROLLBACK TRAN
			END

   SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred assoicating new record for conventional.'
   RAISERROR (@ErrorMessage, 16, 1)
   SET  @ReturnValue = -1
   RETURN (@ReturnValue)
	END
ELSE
	BEGIN
   IF @@TRANCOUNT > 0
			BEGIN
				COMMIT
			END

			--SET the output param to be communicated back...

   SELECT TOP 1 
	 @OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp
	, @ConventionalWasherId    = O.WasherId
   FROM @OutputList       O

	END

	
	  

IF ( @ErrorId = 0 )
	BEGIN


	  RETURN (@ReturnValue)
	END



--ErrorHandler:
--RAISERROR (@ErrorMessage, 16, 1)
--SET @ReturnValue = -1


--ExitModule:

--RETURN (@ReturnValue)

--SET NOCOUNT OFF

END
GO


IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[UpdateConventional]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[UpdateConventional] 
END 
go
/*	
Purpose					:	To update Conventional Washer details from the Washer setup UI - General tab

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version

--sp_helptext	usp_UpdateConventional

*/

CREATE		PROCEDURE	[TCD].[UpdateConventional]
     @EcoLabAccountNumber     NVARCHAR(1000)
    , @WasherId        INT
    , @WasherGroupId       INT
	, @NewWasherGroupId		int
    , @ConventionalName      NVARCHAR(50)
    , @ModelId        INT      --(Washer)Model Id for Size
    , @ControllerId       INT
    , @LFSWasherNumber      TINYINT
    , @PlantWasherNumber      SMALLINT
    , @WasherMode        TINYINT
    , @MaxLoad        SMALLINT
    , @AWEActive        BIT
    , @HoldSignal        BIT
    , @HoldDelay        SMALLINT               
    , @TargetTurnTime       SMALLINT
    , @WaterFlushTime       SMALLINT
    , @ProgramNumber       TINYINT     --EOF number
    , @Description       NVARCHAR(1024) =   NULL
    , @UserId         INT
    , @LastModifiedTimestampAtCentral   DATETIME    = NULL
    , @OutputLastModifiedTimestampAtLocal  DATETIME    = NULL OUTPUT
    , @RatioDosingActive      BIT 
    , @IsPony BIT  
				, @DefaultIdleTime							INT						=   NULL
AS
BEGIN

SET NOCOUNT ON


DECLARE	
  @ReturnValue     INT    =   0
 , @ErrorId      INT    =   0
 , @ErrorMessage     NVARCHAR(4000) =   N''
 , @CurrentUTCTime     DATETIME  =   GETUTCDATE()

DECLARE
   @OutputList      AS TABLE  (
   LastModifiedTimestamp   DATETIME
		)

SET  @OutputLastModifiedTimestampAtLocal    =   ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)   --SQLEnlight

--Valid Washer-Id check...
IF NOT EXISTS ( SELECT 1
	 FROM [TCD].Washer      W
	 JOIN [TCD].MachineSetup    MS
	  ON W.WasherId     =   MS.WasherId
	  AND W.EcoLabAccountNumber  =   MS.EcoalabAccountNumber
	 WHERE W.EcoLabAccountNumber  =   @EcoLabAccountNumber
	  AND W.WasherId     =   @WasherId
	  AND MS.GroupId     =   @WasherGroupId
	  AND W.Is_Deleted    =   'FALSE'
	  AND MS.IsDeleted    =   'FALSE'
				)
			BEGIN
	SET  @ErrorId      =   51006
	SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Washer-ID was provided for Updating.'
	--GOTO ErrorHandler
	RAISERROR (@ErrorMessage, 16, 1)
	SET  @ReturnValue = -1
	RETURN (@ReturnValue)
			END

--Check for uniqueness of PlantWasherNo. and Name
IF EXISTS  ( SELECT 1
	 FROM [TCD].Washer      W
	 JOIN [TCD].MachineSetup    MS
	  ON W.WasherId     =   MS.WasherId
	  AND W.EcoLabAccountNumber  =   MS.EcoalabAccountNumber
	 WHERE W.EcoLabAccountNumber  =   @EcoLabAccountNumber
	  AND W.WasherId     <>   @WasherId
	  AND (
	   W.PlantWasherNumber   =   @PlantWasherNumber
							)
	  AND W.Is_Deleted    =   'FALSE'
	  AND MS.IsDeleted    =   'FALSE'
				)
			BEGIN
	SET  @ErrorId      =   51002
    SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Specified Plant Washer #/ already exists.'
	--GOTO ErrorHandler
	RAISERROR (@ErrorMessage, 16, 1)
	SET  @ReturnValue = -1
	RETURN (@ReturnValue)
			END

--Check Max LFSWasher No.
IF NOT EXISTS ( SELECT 1
	 FROM [TCD].ControllerModelControllerTypeMapping
														CMCTM
	 JOIN [TCD].ConduitController   CC
	  ON CC.ControllerTypeId   =   CMCTM.ControllerTypeId
	  AND CC.ControllerModelId  =   CMCTM.ControllerModelId
	 WHERE CC.EcoalabAccountNumber  =   @EcoLabAccountNumber
	  AND CC.ControllerId    =   @ControllerId
	  AND CC.IsDeleted    =   'FALSE'
	  AND CMCTM.MaximumWasherExtractorCount
			  >=   @LFSWasherNumber
				)
			BEGIN
	SET  @ErrorId      =   51003
	SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller/LFSWasher# was provided.'
	--GOTO ErrorHandler
	RAISERROR (@ErrorMessage, 16, 1)
	SET  @ReturnValue = -1
	RETURN (@ReturnValue)
			END

--EOF should not be an asocciated formula for the WG...
IF EXISTS  ( SELECT 1
	 FROM [TCD].WasherProgramSetup   WPS
	 WHERE WPS.EcolabAccountNumber  =   @EcoLabAccountNumber
	  AND WPS.WasherGroupId   =   @WasherGroupId
	  AND WPS.ProgramNumber   =   @ProgramNumber
	  AND WPS.Is_Deleted    =   'FALSE'
				)
			BEGIN
	SET  @ErrorId      =   51004
	SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An assoicated formula cannot be specified as End-Of-Formula.'
	--GOTO ErrorHandler
	RAISERROR (@ErrorMessage, 16, 1)
	SET  @ReturnValue = -1
	RETURN (@ReturnValue)
			END

--WasherMode check
IF NOT EXISTS ( SELECT 1
	 FROM [TCD].ControllerModelControllerTypeMapping
														CMCTM
     JOIN [TCD].ConduitController   CC
      ON CC.ControllerTypeId   =   CMCTM.ControllerTypeId
      AND CC.ControllerModelId  =   CMCTM.ControllerModelId
     JOIN [TCD].[WasherMode]
														CTM2WM
	  ON CMCTM.Id     =   CTM2WM.ControllerModelControllerTypeMappingId
	 WHERE CC.EcoalabAccountNumber  =   @EcoLabAccountNumber
	  AND CC.ControllerId    =   @ControllerId
	  AND CC.IsDeleted    =   'FALSE'
	  AND CTM2WM.WasherModeId   =   @WasherMode
				)
			BEGIN
	SET  @ErrorId      =   51005
	SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherMode was provided.'
	--GOTO ErrorHandler
	RAISERROR (@ErrorMessage, 16, 1)
	SET  @ReturnValue = -1
	RETURN (@ReturnValue)
			END

--LFSWasherNumber duplicate check...
IF EXISTS ( SELECT 1
    FROM [TCD].MachineSetup     MS
    WHERE MS.ControllerId     =   @ControllerId
     AND MS.MachineInternalId   =   @LFSWasherNumber
     AND MS.IsDeleted     =   'FALSE'
     AND MS.WasherId      <>   @WasherId
     AND MS.EcoalabAccountNumber   =   @EcoLabAccountNumber
			)
			BEGIN
	SET  @ErrorId      =   51010
	SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate LFSWasher# provided.'
	--GOTO ErrorHandler
	RAISERROR (@ErrorMessage, 16, 1)
	SET  @ReturnValue = -1
	RETURN (@ReturnValue)
			END


IF (
   @LastModifiedTimestampAtCentral    IS NOT NULL
			AND
   NOT EXISTS ( SELECT 1
	 FROM TCD.Washer  W
	 WHERE W.EcolabAccountNumber = @EcolabAccountNumber
	  AND W.WasherId    = @WasherId
	  AND W.LastModifiedTime  = @LastModifiedTimestampAtCentral
				)
	)
		BEGIN
	SET   @ErrorId    = 60000
	SET   @ErrorMessage   = N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
	RAISERROR (@ErrorMessage, 16, 1)
	SET   @ReturnValue   = -1
	RETURN  (@ReturnValue)
		END


--Now attempt Update...
BEGIN TRAN

UPDATE MS
 SET MS.MachineName     =   @ConventionalName
 , MS.ControllerId     =   @ControllerId
 , MS.MachineInternalId   =   @LFSWasherNumber
 , MS.LastModifiedByUserId   =   @UserId
 ,MS.IsPony = @IsPony
FROM [TCD].MachineSetup     MS
JOIN [TCD].Washer       W
 ON MS.WasherId      =   W.WasherId
 AND MS.EcoalabAccountNumber   =   W.EcolabAccountNumber
WHERE MS.WasherId      =   @WasherId
 AND MS.EcoalabAccountNumber   =   @EcoLabAccountNumber
 AND MS.IsDeleted     =   'FALSE'
 AND W.Is_Deleted     =   'FALSE'

--check for any error
SET @ErrorId = @@ERROR

IF (@ErrorId <> 0)
BEGIN

  IF @@TRANCOUNT > 0
		BEGIN
   ROLLBACK TRAN
		END
	
  SET  @ErrorMessage    =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating washer data.'
  --GOTO ErrorHandler
  RAISERROR (@ErrorMessage, 16, 1)
  SET  @ReturnValue = -1
  RETURN (@ReturnValue)
END

--else, continue with the rest of the update in the other table...
UPDATE W
 SET W.ModelId      =   @ModelId
 , W.PlantWasherNumber    =   @PlantWasherNumber
 , W.WasherMode     =   @WasherMode
 , W.MaxLoad      =   @MaxLoad
 , W.AWEActive      =   @AWEActive
 , W.HoldSignal     =   @HoldSignal
 , W.HoldDelay      =   @HoldDelay
 , W.TargetTurnTime    =   @TargetTurnTime
 , W.WaterFlushTime    =   @WaterFlushTime
 , W.EndOfFormula     =   @ProgramNumber
 , W.[Description]     =   @Description
 , W.LastModifiedByUserId   =   @UserId
 , W.LastModifiedTime    =   @CurrentUTCTime
 ,   W.RatioDosingActive    =   @RatioDosingActive
  , W.DefaultIdleTime      = @DefaultIdleTime
OUTPUT
 inserted.LastModifiedTime  AS   LastModifiedTimestamp
INTO
 @OutputList (
	LastModifiedTimestamp
)
FROM [TCD].Washer      W
JOIN [TCD].MachineSetup     MS
 ON W.WasherId      =   MS.WasherId
 AND W.EcoLabAccountNumber   =   MS.EcoalabAccountNumber
WHERE W.WasherId      =   @WasherId
 AND W.EcoLabAccountNumber   =   @EcoLabAccountNumber
 AND W.Is_Deleted     =   'FALSE'
 AND MS.IsDeleted     =   'FALSE'


 EXEC TCD.SaveInjectionDetails @WasherGroupId,@ControllerId,@WasherId,@EcolabAccountNumber

  IF(@WasherGroupId != @NewWasherGroupId)
 BEGIN
	UPDATE tcd.machinesetup 
	SET GroupId = @NewWasherGroupId
	WHERE WasherId = @WasherId

	UPDATE tcd.Injection
	SET	   
	   WasherGroupNumber = (SELECT	wg.WasherGroupNumber
							 FROM	tcd.WasherGroup			wg
							 WHERE	wg.WasherGroupId		=		@NewWasherGroupId)
	WHERE WasherId		=	@WasherId
 END

--check for error, if none - commit the tran, else rollback
SET @ErrorId = @@ERROR
IF (@ErrorId <> 0)
	BEGIN
  IF (@@TRANCOUNT > 0)
			BEGIN
				ROLLBACK
			END

  SET  @ErrorMessage    =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating washer data.'
  --GOTO ErrorHandler
  RAISERROR (@ErrorMessage, 16, 1)
  SET  @ReturnValue = -1
  RETURN (@ReturnValue)
	END
ELSE
	BEGIN
  IF (@@TRANCOUNT > 0)
			BEGIN
				COMMIT
			END
			
   SELECT TOP 1 @OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp FROM @OutputList O
	END


SET NOCOUNT OFF
RETURN (@ReturnValue)


END
GO
/* [TCD].[Washer] */
IF NOT EXISTS(SELECT 1 FROM sys.columns 
            WHERE Name = N'MachineNameDispalyType' AND Object_ID = Object_ID(N'[TCD].[Dashboard]'))
BEGIN
    ALTER TABLE [TCD].Dashboard
	ADD MachineNameDispalyType SMALLINT NULL
END
GO
/* [TCD].[Washer] */
IF NOT EXISTS(SELECT 1 FROM sys.columns 
            WHERE Name = N'MachineNameDispalyType' AND Object_ID = Object_ID(N'[TCD].[DashboardHistory]'))
BEGIN
    ALTER TABLE [TCD].DashboardHistory
	ADD MachineNameDispalyType SMALLINT NULL
END



--Context : In Controller Setup General Label is Displayed as ControllerName instead of Dispenser Name.
BEGIN
	UPDATE TCD.Field SET Label='Dispenser Name' , Helptext='Name for Dispenser' WHERE ID in('76','78','114','146','155','169','178') 
END

 /* [TCD].[Plant] */
IF NOT EXISTS(SELECT 1 FROM sys.columns 
            WHERE Name = N'LastServiceVisitDate' AND Object_ID = Object_ID(N'[TCD].[Plant]'))
BEGIN
    ALTER TABLE [TCD].[Plant]
	ADD LastServiceVisitDate DATETIME NULL
END


IF NOT EXISTS(SELECT 1 FROM sys.columns 
            WHERE Name = N'NextServiceVisitDate' AND Object_ID = Object_ID(N'[TCD].[Plant]'))
BEGIN
    ALTER TABLE [TCD].[Plant]
	ADD NextServiceVisitDate DATETIME NULL
END


/* To Update the Export Path into Plant */

Update TCD.Plant Set ExportPath = 'C:\Ecolab\envision\backup'
GO

IF  EXISTS (SELECT
			1
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[GetWashersForManualProduction]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[GetWashersForManualProduction] 
END 
go


CREATE PROCEDURE [TCD].[GetWashersForManualProduction]     
(    
     @WasherGroupId Nvarchar(1000) ,    
     @EcolabAccountNumber NVARCHAR(25)     
)    
AS     
  BEGIN          
     SET NOCOUNT ON    
      SELECT     
                  DISTINCT MS.WasherId,    
                  (CAST(W.PlantWasherNumber AS NVARCHAR(50)) + N': ' + MS.MachineName) AS machineName,    
                  MS.GroupId    
      FROM       
                [TCD].MachineSetup  AS MS  
                JOIN TCD.Washer AS W ON w.WasherId = MS.WasherId  
      WHERE     
                MS.GroupId IN (SELECT cast(items as int) FROM [TCD].[CharacterListToTable] (@WasherGroupId, ',')  )    
                AND MS.EcoalabAccountNumber = @EcolabAccountNumber    
                AND MS.IsDeleted = 0     
    SET NOCOUNT OFF    
  END 
  GO
  IF  EXISTS (SELECT
			1
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[GetMissingFields]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[GetMissingFields] 
END 
go
  CREATE PROCEDURE TCD.GetMissingFields
(
@EcolabAccNumber NVARCHAR(250)
)
AS
BEGIN
	SELECT
	'Home->Setup->Dispenser Setup->' + CC.TopicName AS [PathName]
	,F.Label AS [FieldName]
	FROM 
	TCD.ControllerSetupData CSD
	INNER JOIN TCD.Field F ON F.Id = CSD.FieldId AND F.Label = 'SerialNumber'
	INNER JOIN TCD.ConduitController CC ON CC.ControllerId = CSD.ControllerId
	WHERE 
	CSD.Value IS NULL OR CSD.Value = ''
	AND CSD.EcolabAccountNumber = @EcolabAccNumber;
END

GO
     IF  EXISTS (SELECT
			1
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[GetManualProductionDetails]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[GetManualProductionDetails] 
END 
go  
CREATE PROCEDURE [TCD].[GetManualProductionDetails]      
 (      
 @WasherGroupId NVARCHAR(1000),       
 @WasherId INT,      
 @FormulaId INT,      
 @EcolabAccountNumber NVARCHAR(25)  ,
  @RecordedDate DATETIME     
 )      
AS       
  BEGIN       
     SET NOCOUNT ON       
    if(@FormulaId = 0)    
    BEGIN    
    set @FormulaId = null    
    END    
   SELECT     
      MP.ProductionId,     
      MP.FormulaId,    
      MP.RecordedDate,       
      MP.Value    ,  
      PM.Name  
      FROM  [TCD].ManualProduction  AS MP  
  JOIN [TCD].[ProgramMaster]  AS PM ON MP.FormulaId = PM.ProgramId  
   WHERE       
      MP.WasherGroupId IN( SELECT cast(items as int) FROM [TCD].[CharacterListToTable](@WasherGroupId,','))    
      AND MP.WasherId = @WasherId       
      AND MP.FormulaId = COALESCE(@FormulaId,  FormulaId)     
      AND MP.EcolabAccountNumber = @EcolabAccountNumber  
	  AND MP.RecordedDate = @RecordedDate    
      AND MP.IsDeleted <> 1      
   ORDER BY ProductionId DESC       
  SET NOCOUNT OFF      
  END  

GO

  IF  EXISTS (SELECT
			1
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[GetBatchByGroupId]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[GetBatchByGroupId] 
END 
go  
CREATE PROCEDURE [TCD].[GetBatchByGroupId]         
(        
    @GroupId        NVARCHAR(1000)        =   NULL        
  , @MachineId        INT                 =   NULL        
  , @ProgramId        NVARCHAR(1000)        =   NULL        
  , @StartDate        DATETIME            =   NULL        
  , @RowsPerPage INT  = 50
  , @PageNumber INT         
)        
AS         
/*        
-- Usage        
EXEC [TCD].[GetBatchByGroupId] @GroupId =   NULL        
  , @MachineId = 1        
  , @ProgramId = 54        
  , @StartDate = '2014-06-06'        
  , @RowsPerPage = 50        
  , @PageNumber = 3        
        
        
*/        
        
  BEGIN        
  SET NOCOUNT ON        
        
   IF @PageNumber < 1         
    SET @PageNumber = 1         
        
   SELECT --TOP 10         
   bd.BatchId,        
   CAST(StartDate AS datetime) AS StartDate,        
   COALESCE(bd.ManualInputWeight,bd.ActualWeight),        
   bd.ProgramNumber,        
   pm.Name ,
    Count(*) Over() TotalRows ,  
  bd.EcolabWasherId
   FROM [TCD].BatchData bd        
   INNER JOIN tcd.ProgramMaster pm ON pm.ProgramId = bd.ProgramMasterId        
   WHERE         
 --   bd.GroupId           IN     (SELECT cast(items as int) FROM [TCD].[CharacterListToTable] (@GroupId, ','))        
     bd.MachineId        =     @MachineId        
   AND   bd.ProgramNumber   IN     (SELECT cast(items as int) FROM [TCD].[CharacterListToTable] (@ProgramId, ','))        
   AND bd.[StartDate]       >=      @StartDate      
   AND  bd.[StartDate]    <= GETUTCDATE()      
   ORDER BY bd.BatchId        
   --OFFSET (@PageNumber-1)*@RowsPerPage ROWS        
  -- FETCH NEXT @RowsPerPage ROWS ONLY        
        
 SET NOCOUNT OFF        
  END 
  GO
 IF  EXISTS (SELECT
			1
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[GetFormulasForProductionData]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[GetFormulasForProductionData] 
END 
go  
CREATE PROCEDURE [TCD].[GetFormulasForProductionData]   
(  
        @WasherGroupId NVARCHAR(1000),  
        @EcolabAccountNumber NVARCHAR(25)  
 )  
AS   
  BEGIN  
  SET NOCOUNT ON  
  --DECLARE @IsTunnel bit = (SELECT IsTunnel FROM TCD.MachineSetup WHERE GroupId IN ( SELECT cast(items as int) FROM [TCD].[CharacterListToTable] (@WasherGroupId, ',') ) AND EcoalabAccountNumber = @EcolabAccountNumber )  
  --IF @IsTunnel = 0  
  --BEGIN  
        SELECT   
                    Distinct P.ProgramId,  
                    P.Name  
        FROM [TCD].WasherProgramSetup AS WP                  
                INNER JOIN [TCD].ProgramMaster AS P ON P.ProgramId = WP.ProgramId  
        WHERE WP.WasherGroupId IN ( SELECT cast(items as int) FROM [TCD].[CharacterListToTable] (@WasherGroupId, ','))   
                AND WP.EcolabAccountNumber = @EcolabAccountNumber   
                AND WP.IS_DELETED = 0   
                AND P.IS_DELETED = 0        
    --END  
    --ELSE  
    --BEGIN  
    UNION ALL  
     SELECT   
                    Distinct P.ProgramId,  
                    P.Name  
        FROM [TCD].TunnelProgramSetup  AS tps                  
                INNER JOIN [TCD].ProgramMaster AS P ON P.ProgramId = tps.ProgramId  
        WHERE tps.WasherGroupId IN (SELECT cast(items as int) FROM [TCD].[CharacterListToTable] (@WasherGroupId, ','))               
                AND tps.EcolabAccountNumber = @EcolabAccountNumber   
                AND tps.IS_DELETED = 0   
                AND P.IS_DELETED = 0    
    --END                 
SET NOCOUNT OFF  
  END  
    
GO
 IF  EXISTS (SELECT
			1
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[GetReportDataByFilterId]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[GetReportDataByFilterId] 
END 
GO

CREATE PROCEDURE [TCD].[GetReportDataByFilterId]
(
@UserId INT = NULL
, @RoleId INT = NULL
, @IsLocal BIT = NULL
, @MachineTye NVARCHAR(1000) = NULL
, @Machinegroup NVARCHAR(1000) = NULL
, @ReportId INT = NULL
, @FilterId INT = NULL
)
AS
SET NOCOUNT ON;
BEGIN
    DECLARE
	    @LanguageId INT = (SELECT UM.LanguageId
						FROM TCD.UserMaster UM
						WHERE UserId = @UserId );
    DECLARE
	    @MachineTypeTable TABLE(MachineType VARCHAR(100));
    INSERT INTO @MachineTypeTable
    EXEC TCD.CharlistToTable @MachineTye, ',';
    DECLARE
	    @MachineGroupTable TABLE(MachineGroup VARCHAR(100));
    INSERT INTO @MachineGroupTable
    EXEC TCD.CharlistToTable @machineGroup, ',';
    DECLARE
	    @TypeId INT,
	    @FilterTargetId INT;

    DECLARE
	    @ResultTable TABLE
	    (
	    Id NVARCHAR(2000),
	    Name NVARCHAR(300),
	    TypeId INT
	    );
    SELECT @FilterTargetId = RFM.TargetDropDown
	 FROM TCD.ReportFilterMapping RFM
	 WHERE RFM.FilterId = @FilterId
	   AND RFM.ReportId = @ReportId;
    IF @FilterId IS NULL

	   --Filter Options for Region and Country filter  

	   BEGIN
		  SELECT @FilterTargetId = RF.ReportFilterId
		    FROM TCD.ReportFilter RF
		    WHERE RF.FilterName = 'Machine Types';
	   END;
    IF @FilterTargetId = 8

	   --Filter Options for machine Types  

	   BEGIN
		  SELECT @TypeId = RF.ReportFilterId
		    FROM TCD.ReportFilter RF
		    WHERE RF.FilterName = 'Machine Types';
		  INSERT INTO @ResultTable (
		  Id,
		  Name,
		  TypeId
		  )
		  SELECT DISTINCT
		  WGT.WasherGroupTypeId AS Id,
		  WGT.WasherGroupTypeName AS Name,
		  @TypeId AS TypeId
		    FROM
		  TCD.WasherGroupType WGT
		END;
    ELSE
	   BEGIN IF @FilterTargetId = 5

			   --Filter Options for Machine groups based on plant  

			   BEGIN
				  SELECT @TypeId = RF.ReportFilterId
				    FROM TCD.ReportFilter RF
				    WHERE RF.FilterName = 'Machine group';
				  SELECT @MachineTye = CASE @MachineTye WHEN 3 THEN '' ELSE @MachineTye END;

				  INSERT INTO @ResultTable (
				  Id,
				  Name,
				  TypeId
				  )
				  SELECT DISTINCT
				  WG.WasherGroupId AS Id,
				  WG.WasherGroupName AS Name,
				  @TypeId AS TypeId
				  FROM TCD.WasherGroup WG
				  WHERE CASE WHEN ISNULL( @MachineTye,'')='' THEN 'TRUE'
							WHEN  @MachineTye='0' THEN 'False'
					   ELSE
				    CASE
				    WHEN WG.WasherGroupTypeId  IN (SELECT MachineType
					 FROM @MachineTypeTable) THEN 'TRUE'
				    END
				    END = 'TRUE';
			   END;
		    ELSE
			   BEGIN IF @FilterTargetId = 6

					   --Filter Options for Machines based on Group  

					   BEGIN
						  SELECT @TypeId = RF.ReportFilterId
						    FROM TCD.ReportFilter RF
						    WHERE RF.FilterName = 'Machine';
						  --INSERT INTO @ResultTable (
						  --Id,
						  --Name,
						  --TypeId
						  --)

						  SELECT 
						 cast( W.WasherId AS varchar(2000)) AS Id,
						 CAST( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName AS Name,
						  @TypeId AS TypeId
						    FROM
						  TCD.MachineSetup MS
						  INNER JOIN TCD.Washer W ON MS.WasherId = W.WasherId
						   WHERE MS.GroupId IN (SELECT MachineGroup
								FROM @MachineGroupTable) or ISNULL(@machineGroup,'')='' 
						 ORDER BY cast( W.PlantWasherNumber AS int)
						 RETURN;
					   END;
			   END;
	   END;
    IF @FilterId = 21
   AND @ReportId = 30

	   --Filter Options for User

	   BEGIN
		  SELECT @TypeId = RF.ReportFilterId
		    FROM TCD.ReportFilter RF
		    WHERE RF.FilterName = 'User';
		  INSERT INTO @ResultTable (
		  Id,
		  Name,
		  TypeId
		  )
		  SELECT DISTINCT
		  UserId AS Id,
		  LoginName AS name,
		  NULL AS TypeId
		    FROM tcd.usermaster;
	   END;
    ELSE
	   BEGIN
		  IF @FilterId = 22
			 BEGIN
				SELECT @TypeId = RF.ReportFilterId
				  FROM TCD.ReportFilter RF
				  WHERE RF.FilterName = 'ActionType';
				INSERT INTO @ResultTable (
				Id,
				Name,
				TypeId
				)
				SELECT DISTINCT
				CAST(AO.OperationId AS INT) AS OperationId,
				RKV.Value AS OperationCode,
				NULL	 AS TypeId
				  FROM TCD.AuditOperation AO
					  LEFT JOIN
					  TCD.ResourceKeyMaster RKM
				ON AO.UsageKey = RKM.[KeyName]
					  LEFT JOIN
					  TCD.ResourceKeyValue RKV
				ON RKV.KeyName = RKM.KeyName
				  WHERE RKV.languageID = @LanguageId
				  ORDER BY OperationId;
			 END;
	   END;

    SELECT
    
    Id,
    Name,
    TypeId
	 FROM @ResultTable;
END;


DECLARE	@tempConduitParameters	TABLE	(
	TempId					INT				IDENTITY(1, 1)
,	Id						INT				NOT	NULL
,	Name					NVARCHAR(50)	NULL
,	DESCRIPTION				NVARCHAR(50)	NULL
,	MANDATORYCOL			INT				NULL
,	ISACTIVE				INT				NULL
,	SORTORDER				INT				NULL	
,    IsTrending			 BIT				  NULL
)

--Populate temp table variable with the input data
INSERT	@tempConduitParameters		(
Id,Name,Description,MandatoryCol,IsActive,SortOrder,IsTrending	)
VALUES	(1,  N'pH', NULL, 1,1, 2,1)
,(2,N'Temperature', NULL, 1,1, 3,1)
,(3,N'Conductivity', NULL, 1,1, 4,1)
,(4,N'Customer', NULL, 0,0, 1,1)
,(5,N'Formula Number', NULL, 0,1, 5,1)
,(6,N'Transfer Signal', NULL, 0,0, 6,1)
,(7, N'Weight', NULL, 0,1, 7,1)
,(8, N'DosingAmount', NULL, 0,1, 8,1)
,(9, N'HoldSignal', NULL, 0,1, 9,0)
,(10, N'Injection ', NULL, 0,1, 10,0)
,(11, N'Operation Counter ', NULL, 0,1, 11,0)
,(12, N'StopSignal', NULL,	0,1, 12,0)
,(13, N'Water Meter Start',	NULL,	0,1, 13,0)
,(14, N'Water Meter End',	NULL,	0,1, 14,0)
,(15, N'Energy Meter Start',NULL,	0,1, 15,0)
,(16, N'Energy Meter End',	NULL,	0,1, 16,0)
,(17, N'HoldTime',NULL,	0,1, 17,0)
,(18, N'BatchStatus',	NULL,	0,1, 18,0)
,(19, N'EndOfSignal',	NULL,	0,1, 19,0)
,(25,'Mimum Temperature','My Control mimum Temprature',0,1,10,0)
,(26,'Maximum Temperature','My Control Maximum Temprature',0,1,10,0)
,(27,'Minimum Temperature Status','My Control Mimum Temprature',0,1,10,0)
,(28,'Max Temperature Status','My Control Max Temprature Status',0,1,10,0)
,(29,'PH Status','My Control PHStatus',0,1,10,0)
,(30, 'StepCompartment No', 'Step or Compartment No', 0, 1, 30, 1)
,(31, 'LF Status', 'LF Status', 0, 1, 31, 1)
,(32, 'Average Temperature', 'Average Temperature', 0, 1, 32, 1)
,(33, 'Temperature Status', 'Temperature Status', 0, 1, 33, 1)
,(34, 'Maximum Conductivity', 'Maximum Conductivity', 0, 1, 34, 1)
,(35, 'Minimum Conductivity', 'Minimum Conductivity', 0, 1, 35, 1)
,(36, 'Average Conductivity', 'Average Conductivity', 0, 1, 36, 1)
--SET		IDENTITY_INSERT		TCD.ConduitParameters		ON

MERGE	TCD.ConduitParameters					AS			TARGET
USING	@tempConduitParameters			AS			SOURCE
ON	TARGET.Id		=			SOURCE.Id
WHEN	NOT MATCHED		THEN
INSERT	(Id,Name,Description,MandatoryCol,IsActive,SortOrder,IsTrending)
VALUES	(SOURCE.Id	,SOURCE.Name ,SOURCE.Description,SOURCE.MandatoryCol,SOURCE.IsActive,SOURCE.SortOrder,Source.IsTrending);

    

GO
   IF  EXISTS (SELECT
			1
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[SaveManualProduction]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[SaveManualProduction] 
END 
GO  

--SET		IDENTITY_INSERT		[TCD].ConduitParameters		OFF

--Update Save Manual Production
/*          
 ==========================================================================================        
 Purpose:  Insert or Update Production details .          
      
 Author:  Neetha Allati         
      
 --------------------------------------------------------------          
 Sep-26-2014 ENT: Initial version.          
 ==========================================================================================        
*/  
CREATE PROCEDURE [TCD].[SaveManualProduction]    
 (   
    @WasherId  INT,      
    @FormulaId  INT,      
    @RecordedDate DATETIME,    
    @Value DECIMAL(18, 0),    
    @EcolabAccountNumber NVARCHAR(25),       
    @UserId  INT,    
    @Scope VARCHAR(100) OUTPUT,    
    @OutputProductionId      INT     =   NULL OUTPUT    
)       
AS      
     
  BEGIN         
  SET NOCOUNT ON    
  DECLARE @WasherGroupId INT;  
  SET @WasherGroupId =  (SELECT GroupID FROM TCD.MACHINESETUP WHERE WasherId = @WasherId)  
  DECLARE    
  @OutputList     AS TABLE  (    
  ProductionId       INT    
 )    
        INSERT INTO [TCD].ManualProduction(    
                WasherGroupId,    
                WasherId,    
                FormulaId,    
                RecordedDate,    
                Value,    
                EcolabAccountNumber,    
                LastModifiedByUserId    
               )    
      OUTPUT    
         inserted.ProductionId      AS   ProductionId    
      INTO @OutputList    
         (ProductionId)    
            VALUES(    
                @WasherGroupId,    
                @WasherId,     
                @FormulaId,    
                @RecordedDate,    
                @Value,    
                @EcolabAccountNumber,    
                @UserID    
             )          
      
       SET @Scope = '101'        
 SELECT TOP 1     
    @OutputProductionId      = O.ProductionId    
  FROM @OutputList         O    
 SET NOCOUNT OFF      
END

GO
IF  EXISTS (SELECT
			1
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[GetCompareFormulaPumpsList]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[GetCompareFormulaPumpsList] 
END 
GO  


/*	
Purpose					:	To populate the grid in the ControllerSetup-->Pumps/Valves tab

History					:
Sept. 2014		dfozdar@allianceglobalservice.com		initial version



*/

CREATE	PROCEDURE [TCD].[GetCompareFormulaPumpsList]
       @EcoLabAccountNumber					NVARCHAR( 1000)
       ,@ControllerId							INT	
       ,@WasherProgramSetupId					int 
	  ,@ControllerEquipmentId					  int = null
       ,@IsActive								BIT = NULL
AS
     BEGIN
         SET	NOCOUNT	ON;
         DECLARE	@ErrorMessage										NVARCHAR( 4000
                                                                                        )
                    ,@PumpValveCount										TINYINT
                    ,@MECount											TINYINT
                    ,@ControllerEquipmentTypeId_PumpValve				TINYINT
                    ,@ControllerEquipmentTypeId_ME						TINYINT
                    ,@ReturnValue										INT = 0
                    ,@TagTypeLfs VARCHAR( 100) = 'Tag_NML'
                    ,@TagTypeKfactor VARCHAR( 100) = 'Tag_PPOL'
                    ,@TagTypeCalibration VARCHAR( 100) = 'Tag_OPSL';


         CREATE	TABLE #Equipment	(
         ControllerEquipmentId					INT				IDENTITY( 1, 1)
         ,ControllerEquipmentTypeId				TINYINT			NOT	NULL
         ,IsActive								BIT				NOT	NULL DEFAULT('FALSE')
         ,ProductId								INT				NULL
         ,ProductName								NVARCHAR( 255)	NULL
         --ProductMaster
         ,PumpCalibration							DECIMAL( 18, 3)	NULL
         ,FlowMeterSwitchFlag						BIT				NULL
         --NULL (not set), 0 for Meter, 1 for Switch
         ,FlowMeterCalibration					INT				NULL
         ,MaximumDosingTime						SMALLINT		NULL
         ,FlowSwitchTimeOut						SMALLINT		NULL
         ,ControllerEquipmentSetupId				SMALLINT		NULL
         ,LfsChemicalName							NVARCHAR( 200)	NULL
         ,KFactor									DECIMAL( 18, 2)	NULL
         ,TunnelHold								BIT				NULL
         ,FlowDetectorType							INT				NULL
         ,FlowSwitchAlarm							BIT				NULL
         ,FlowMeterAlarm							BIT				NULL
         ,FlowMeterType							INT				NULL
         ,FlowAlarmDelay							DECIMAL( 18, 2)	NULL
         ,FlowMeterPumpDelay						DECIMAL( 18, 2)				NULL
         ,FlowMeterAlarmDelay						DECIMAL( 18, 2)				NULL

         --Synch./Central integration additions

         ,LastModifiedTime						DATETIME		NULL
         ,LastSyncTime							DATETIME		NULL
                                        );


         IF	NOT	EXISTS	( SELECT	1
                                FROM	[TCD].ConduitController			CC
                                WHERE	CC.EcoalabAccountNumber = @EcoLabAccountNumber
                                    AND CC.ControllerId = @ControllerId
                              )
             BEGIN
                 SET			@ErrorMessage = 'Invalid Plant/Controller combination specified';

                 --GOTO		ErrorHandler

                 RAISERROR	( @ErrorMessage, 16, 1);
                 SET		@ReturnValue = -1;
                 RETURN	(@ReturnValue);
             END;


         SELECT	@ControllerEquipmentTypeId_PumpValve = CASE
                                                               WHEN	CET.ControllerEquipmentTypeName = 'Pump/Valve'
                                                               THEN	CET.ControllerEquipmentTypeId
                                                               ELSE	@ControllerEquipmentTypeId_PumpValve
                                                           END
                    ,@ControllerEquipmentTypeId_ME = CASE
                                                         WHEN	CET.ControllerEquipmentTypeName = 'ME'
                                                         THEN	CET.ControllerEquipmentTypeId
                                                         ELSE	@ControllerEquipmentTypeId_ME
                                                     END
         FROM [TCD].ControllerEquipmentType CET
         WHERE	CET.ControllerEquipmentTypeName			IN			( 'Pump/Valve', 'ME');


         SELECT	@PumpValveCount = ISNULL( CSD.Value, 0)
         FROM [TCD].ConduitController CC JOIN [TCD].ControllerModelControllerTypeMapping CMCTM ON CC.ControllerModelId = CMCTM.ControllerModelId
                                         JOIN [TCD].ControllerSetupData CSD ON CSD.ControllerId = CC.ControllerId
                                                                           AND CC.ControllerTypeId = CMCTM.ControllerTypeId
                                         JOIN [TCD].FieldGroup FG ON FG.ControllerModelId = CC.ControllerModelId
                                                                 AND FG.ControllerTypeId = CC.ControllerTypeId
                                                                 AND FG.TabId = 3
                                         INNER JOIN [TCD].FieldGroupFieldMapping FGM ON FGM.FieldGroupId = FG.Id
                                         INNER JOIN [TCD].Field F ON F.Id = FGM.FieldId
                                                                 AND CSD.FieldId = f.Id
         WHERE	CC.ControllerId = @ControllerId
           AND F.ResourceKey = 'No._of_Chemical_Valves'
           AND CSD.EcolabAccountNumber = @EcoLabAccountNumber;
         SELECT	@MECount = ISNULL( CMCTM.MECount, 0
                                     )
         FROM [TCD].ConduitController CC JOIN [TCD].ControllerModelControllerTypeMapping CMCTM ON CC.ControllerModelId = CMCTM.ControllerModelId
                                                                                              AND CC.ControllerTypeId = CMCTM.ControllerTypeId
         WHERE	CC.ControllerId = @ControllerId;



         IF	(	( SELECT	ISNULL( @PumpValveCount, 0) + ISNULL( @MECount, 0)) = 0)
             BEGIN

                 --GOTO		ExitModule
                 --Return EMPTY result set

                 SELECT

                 --*	--Change this

                 T.ControllerEquipmentId		AS			ControllerEquipmentId
                 ,T.ControllerEquipmentTypeId	AS			ControllerEquipmentTypeId
                 ,T.IsActive					AS			IsActive
                 ,T.ProductId					AS			ProductId
                 ,T.ProductName				AS			ProductName
                 ,T.PumpCalibration			AS			PumpCalibration
                 ,T.FlowMeterSwitchFlag		AS			FlowMeterSwitchFlag
                 ,T.FlowMeterCalibration		AS			FlowMeterCalibration
                 ,T.MaximumDosingTime			AS			MaximumDosingTime
                 ,T.FlowSwitchTimeOut			AS			FlowSwitchTimeOut
                 ,T.ControllerEquipmentSetupId AS			ControllerEquipmentSetupId

                 --	required in the RS for the service layer...

                 ,@EcoLabAccountNumber		AS			EcoLabAccountNumber
                 ,@ControllerId				AS			ControllerId
                 ,CC.TopicName					AS			ControllerName
                 ,CC.ControllerTypeId			AS			ControllerTypeId
                 ,T.LfsChemicalName				AS			LfsChemicalName
                 ,T.KFactor						AS			KFactor
                 ,T.TunnelHold					AS			TunnelHold
                 ,T.FlowDetectorType			AS			FlowDetectorType
                 ,T.FlowSwitchAlarm				AS			FlowSwitchAlarm
                 ,T.FlowMeterAlarm			AS			FlowMeterAlarm
                 ,T.FlowMeterType				AS			FlowMeterType
                 ,T.FlowAlarmDelay			AS			FlowAlarmDelay
                 ,T.FlowMeterPumpDelay			AS			FlowMeterPumpDelay
                 ,T.FlowMeterAlarmDelay		AS			FlowMeterAlarmDelay
                 ,( 
                    SELECT MTS.TagAddress
                    FROM TCD.ModuleTags MTS
                    WHERE MTS.TagType = @TagTypeLfs
                      AND MTS.ModuleID = ControllerEquipmentSetupId
                      AND MTS.ModuleTypeId = 4
                      AND MTS.Active = 1
                  ) AS LfsChemicalNameTag
                 ,( 
                    SELECT MTS.TagAddress
                    FROM TCD.ModuleTags MTS
                    WHERE MTS.TagType = @TagTypeKfactor
                      AND MTS.ModuleID = ControllerEquipmentSetupId
                      AND MTS.ModuleTypeId = 4
                      AND MTS.Active = 1
                  ) AS KfactorTag
                 ,( 
                    SELECT MTS.TagAddress
                    FROM TCD.ModuleTags MTS
                    WHERE MTS.TagType = @TagTypeCalibration
                      AND MTS.ModuleID = ControllerEquipmentSetupId
                      AND MTS.ModuleTypeId = 4
                      AND MTS.Active = 1
                  ) AS CalibrationTag

                 --Synch./Central integration additions

                 ,T.LastModifiedTime			AS			LastModifiedTime
                 ,T.LastSyncTime				AS			LastSyncTime
                 FROM	#Equipment					T JOIN TCD.ConduitController CC
                 ON CC.ControllerId = @ControllerId
                 WHERE	T.IsActive = ISNULL( @IsActive, T.IsActive
                                            )
                     AND T.ControllerEquipmentId = ISNULL( @ControllerEquipmentId, T.ControllerEquipmentId);
                 RETURN	(@ReturnValue);
             END;



         IF	(ISNULL( @PumpValveCount, 0) <> 0)
             BEGIN
                 WITH NumCTE	( N)
                     AS	( SELECT	'*'	AS	N
                           UNION ALL
                           SELECT	'*'	AS	N
                         )
                     INSERT INTO	#Equipment	(ControllerEquipmentTypeId)
                     SELECT	TOP ( @PumpValveCount)
                     @ControllerEquipmentTypeId_PumpValve
                     FROM	NumCTE N1	, NumCTE N2	, NumCTE N3	, NumCTE N4	, NumCTE N5;
             END;
         IF	(ISNULL( @MECount, 0) <> 0)
             BEGIN
                 WITH	NumCTE	( N)
                     AS	( SELECT	'*'	AS	N
                           UNION ALL
                           SELECT	'*'	AS	N
                         )
                     INSERT INTO	#Equipment	(ControllerEquipmentTypeId)
                     SELECT	TOP ( @MECount)
                     @ControllerEquipmentTypeId_ME
                     FROM	NumCTE N1	, NumCTE N2	, NumCTE N3	, NumCTE N4	, NumCTE N5;
             END;
         UPDATE	U
           SET	U.IsActive = CES.IsActive
               ,U.ProductId = CES.ProductId
               ,U.ProductName = PM.Name
               ,U.PumpCalibration = CES.PumpCalibration
               ,U.FlowMeterSwitchFlag = CES.FlowMeterSwitchFlag
               ,U.FlowMeterCalibration = CES.FlowMeterCalibration
               ,U.MaximumDosingTime = CES.MaximumDosingTime
               ,U.FlowSwitchTimeOut = CES.FlowSwitchTimeOut

               --update CESId here; though we are not using this as of now...

               ,U.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId
               ,U.LfsChemicalName = CES.LfsChemicalName
               ,U.KFactor = CES.KFactor
               ,U.TunnelHold = CES.TunnelHold
               ,U.FlowDetectorType = CES.FlowDetectorType
               ,U.FlowSwitchAlarm = CES.FlowSwitchAlarm
               ,U.FlowMeterAlarm = CES.FlowMeterAlarm
               ,U.FlowMeterType = CES.FlowMeterType
               ,U.FlowAlarmDelay = CES.FlowAlarmDelay
               ,U.FlowMeterPumpDelay = CES.FlowMeterPumpDelay
               ,U.FlowMeterAlarmDelay = CES.FlowMeterAlarmDelay

               --Synch./Central integration additions

               ,U.LastModifiedTime = CES.LastModifiedTime
               ,U.LastSyncTime = CES.LastSyncTime
         FROM	#Equipment U 
	    JOIN	[TCD].ControllerEquipmentSetup	CES ON	U.ControllerEquipmentId = CES.ControllerEquipmentId AND U.ControllerEquipmentTypeId = CES.ControllerEquipmentTypeId
          JOIN	[TCD].ProductMaster				PM ON	CES.ProductId = PM.ProductId
		INNER JOIN TCD.MachineSetup MS ON CES.ControllerId =MS.ControllerId AND MS.IsDeleted=0
		INNER JOIN TCD.[WasherProgramSetup] wps ON MS.GroupID =wps.WasherGroupId AND wps.Is_Deleted=0 AND wps.WasherProgramSetupId=@WasherProgramSetupId
		INNER JOIN [TCD].[WasherDosingSetup] wds ON wps.WasherProgramSetupId =wds.WasherProgramSetupId AND wds.Is_Deleted=0
		INNER JOIN TCD.WasherDosingProductMapping wspm ON wds.WasherDosingSetupId =wspm.WasherDosingSetupId AND PM.ProductId=wspm.ProductId AND wspm.IsDeleted=0
         WHERE	CES.EcoLabAccountNumber = @EcoLabAccountNumber
           AND CES.ControllerId = @ControllerId;
         GOTO	ExitModule;

         --ErrorHandler:
         --RAISERROR	(@ErrorMessage, 16, 1)
         --SET	@ReturnValue	=	-1

         ExitModule:

         --Return result set

         SELECT

         --*	--Change this

         T.ControllerEquipmentId			AS ControllerEquipmentId
         ,T.ControllerEquipmentTypeId		AS ControllerEquipmentTypeId
         ,T.IsActive						AS IsActive
         ,T.ProductId						AS ProductId
         ,T.ProductName					AS ProductName
         ,T.PumpCalibration				AS PumpCalibration
         ,T.FlowMeterSwitchFlag			AS FlowMeterSwitchFlag
         ,T.FlowMeterCalibration			AS FlowMeterCalibration
         ,T.MaximumDosingTime				AS MaximumDosingTime
         ,T.FlowSwitchTimeOut				AS FlowSwitchTimeOut
         ,T.ControllerEquipmentSetupId	AS ControllerEquipmentSetupId

         --	required in the RS for the service layer...

         ,@EcoLabAccountNumber			AS EcoLabAccountNumber
         ,@ControllerId					AS ControllerId
         ,CC.TopicName						AS ControllerName
         ,CC.ControllerTypeId				AS ControllerTypeId
         ,T.LfsChemicalName					AS LfsChemicalName
         ,T.KFactor							AS KFactor
         ,T.TunnelHold						AS TunnelHold
         ,T.FlowDetectorType				AS FlowDetectorType
         ,T.FlowSwitchAlarm					AS FlowSwitchAlarm
         ,T.FlowMeterAlarm				AS FlowMeterAlarm
         ,T.FlowMeterType					AS FlowMeterType
         ,T.FlowAlarmDelay				AS FlowAlarmDelay
         ,T.FlowMeterPumpDelay				AS FlowMeterPumpDelay
         ,T.FlowMeterAlarmDelay			AS FlowMeterAlarmDelay
         ,( 
            SELECT MTS.TagAddress
            FROM TCD.ModuleTags MTS
            WHERE MTS.TagType = @TagTypeLfs
              AND MTS.ModuleID = ControllerEquipmentSetupId
              AND MTS.ModuleTypeId = 4
              AND MTS.Active = 1
          ) AS LfsChemicalNameTag
         ,( 
            SELECT MTS.TagAddress
            FROM TCD.ModuleTags MTS
            WHERE MTS.TagType = @TagTypeKfactor
              AND MTS.ModuleID = ControllerEquipmentSetupId
              AND MTS.ModuleTypeId = 4
              AND MTS.Active = 1
          ) AS KfactorTag
         ,( 
            SELECT MTS.TagAddress
            FROM TCD.ModuleTags MTS
            WHERE MTS.TagType = @TagTypeCalibration
              AND MTS.ModuleID = ControllerEquipmentSetupId
              AND MTS.ModuleTypeId = 4
              AND MTS.Active = 1
          ) AS CalibrationTag

         --Synch./Central integration additions

         ,T.LastModifiedTime				AS LastModifiedTime
         ,T.LastSyncTime					AS LastSyncTime
         FROM #Equipment T JOIN TCD.ConduitController CC ON CC.ControllerId = @ControllerId
         WHERE	T.IsActive = ISNULL( @IsActive, T.IsActive
                                  )
           AND T.ControllerEquipmentId = ISNULL( @ControllerEquipmentId, T.ControllerEquipmentId);

         --exit

         SET	NOCOUNT	OFF;
         RETURN	(@ReturnValue);
     END;

GO


IF  EXISTS (SELECT
			1
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[GetDispenserDetailsByGroupId]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[GetDispenserDetailsByGroupId] 
END 
GO  

/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[GetDispenserDetailsByGroupId]              
Parameters:				@EcolabAccountNumber - holds the ecolab account number.
																																		
###################################################################################################                                           
*/

CREATE PROCEDURE [TCD].[GetDispenserDetailsByGroupId]
(
	@WasherGroupId INT
,	@EcolabAccountNumber NVARCHAR(25) = NULL
)
AS
BEGIN
    SET NOCOUNT ON;

		SELECT		cc.ControllerId, cast(ControllerNumber AS varchar(20)) +'('+ cc.TopicName +')' TopicName
		FROM		tcd.ConduitController cc 
		WHERE		cc.ControllerId 
		IN			(
						SELECT	DISTINCT(ms.ControllerId) 
						FROM	tcd.MachineSetup ms 
						WHERE	ms.GroupId				=			@WasherGroupId
						AND		ms.EcoalabAccountNumber	=			@EcolabAccountNumber
					)
		AND			cc.EcoalabAccountNumber				=			@EcolabAccountNumber	
    SET NOCOUNT OFF;
END;


GO
IF  EXISTS (SELECT
			1
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[GetWasherGroupInjectionDetails]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[GetWasherGroupInjectionDetails] 
END 
GO  

CREATE  PROCEDURE [TCD].[GetWasherGroupInjectionDetails]
            (
            @EcolabAccountNumber nvarchar(25) = NULL,
            @WasherGroupId Int = NULL,
			@ControllerId Int = NULL
            )
AS
SET NOCOUNT ON
BEGIN

SELECT  
    DISTINCT
    WDS.WasherDosingSetupId
    ,WPS.ProgramNumber
    ,WG.WasherGroupNumber
    ,WDP.InjectionNumber
    ,CES.ControllerEquipmentId
    ,WDP.ProductId
    ,PM.Name
    ,WDP.Quantity
    ,IJ.ReferenceLoad
    ,WDS.StepNumber
    ,WS.[StepId] AS WashOperationId
    ,WS.[StepName] AS WashOperation
    ,IJ.InjectionClass
    ,IJ.ControllerId
    ,CT.Id AS ControllerType
	,WPS.NominalLoad
   FROM [TCD].[WasherDosingSetup]   WDS

   INNER JOIN [TCD].[WasherProgramSetup] WPS 
    ON WPS.[WasherProgramSetupId] = WDS.[WasherProgramSetupId] AND WDS.Is_Deleted = 0
   INNER JOIN TCD.WasherGroup WG ON WG.WasherGroupId = WPS.WasherGroupId AND WPS.Is_Deleted =0
   INNER JOIN TCD.Injection IJ ON WG.WasherGroupNumber = IJ.WasherGroupNumber AND IJ.Is_Deleted =0
   INNER JOIN TCD.ConduitController CC ON IJ.ControllerId = CC.ControllerId AND CC.IsDeleted = 0 AND CC.Active = 1
   INNER JOIN TCD.ControllerType CT ON CC.ControllerTypeId = CT.Id  
   LEFT JOIN TCD.WasherDosingProductMapping WDP ON WDS.WasherDosingSetupId = WDP.WasherDosingSetupId AND WDP.IsDeleted = 0

   LEFT JOIN TCD.ProductMaster PM ON WDP.ProductId = PM.ProductId and pm.Is_Deleted =0
   INNER JOIN TCD.ControllerEquipmentSetup CES ON CES.ProductId = PM.ProductId and CES.IsActive = 1 and CES.CONTROLLERID=CC.ControllerId

   LEFT JOIN [TCD].WashStep    WS
    ON WS.StepId     =   WDS.StepTypeId AND WS.IsActive =1

    WHERE WG.WasherGroupId = @WasherGroupId AND WG.EcolabAccountNumber = @EcolabAccountNumber AND cc.ControllerId = @ControllerId 
    AND WDP.InjectionNumber IS NOT NULL
 END


 IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[ReportChemicalConsumption]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[ReportChemicalConsumption] 
END 
GO 
create PROCEDURE [TCD].[ReportChemicalConsumption] 

         @startdate datetime = '',
         @enddate datetime = '',
     @EcolabAccountNumber Nvarchar(25) = '',
     @MachineType VARCHAR(20)= '',
     @MachineGroup VARCHAR(MAX) = '',
     @Machine VARCHAR(MAX) = '',
     @EcolabCategory VARCHAR(MAX) = '',
     @ChainCategory VARCHAR(MAX) = '',
     @PlantFormula  VARCHAR(MAX) = '',
     @ChainFormula VARCHAR(MAX) = '',
     @Customer VARCHAR(MAX) = '',
     @CurrencyCode varchar(3) = NULL,
     @UserId INT = NULL
    AS   
    BEGIN   
    SET NOCOUNT ON; 

     SET @startdate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@startdate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@startdate AS time)) AS DateTime))
    SET @EndDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndDate AS time)) AS DateTime))

    SELECT @CurrencyCode = um.CurrencyCode FROM TCD.UserMaster um WHERE um.UserId = @UserId
    IF (COUNT(@CurrencyCode) <> 1)
    BEGIN
    SELECT @CurrencyCode = p.CurrencyCode FROM TCD.Plant p
    END

    DECLARE @ReportGenerated INT = 6,
    @Month INT = MONTH(GETDATE()),@NoOfLoads INT,@NoOfPrograms INT

/* Inserting the record into Report History */

    INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)
    SELECT @EcolabAccountNumber,UM.UserId,
   UM.LoginName,
   GETUTCDATE(),
   @ReportGenerated,
   CASE WHEN @ReportGenerated = 6
  THEN 'Generated Report : Chemical Consumption Report' END
   FROM TCD.UserMaster UM
     WHERE UM.EcolabAccountNumber = @EcolabAccountNumber AND UM.UserId = @UserId

/* Completed the record insertion into Report History */

 
    DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))
    INSERT INTO @MachineTypeTable EXEC [TCD].[CharlistToTable] @MachineType,','

    DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))
    INSERT INTO @WasherGroupTable EXEC [TCD].[CharlistToTable] @machineGroup,','  

    DECLARE @MachineTable TABLE(Machine Varchar(100))
    INSERT INTO @MachineTable EXEC [TCD].[CharlistToTable] @Machine,','

    DECLARE @EcolabCategoryTable TABLE(EcolabCategory Varchar(100))
    INSERT INTO @EcolabCategoryTable EXEC [TCD].[CharlistToTable] @EcolabCategory,','

    DECLARE @ChainCategoryTable TABLE(ChainCategory Varchar(100))
    INSERT INTO @ChainCategoryTable EXEC [TCD].[CharlistToTable] @ChainCategory,','

    DECLARE @PlantFormulaTable TABLE(PlantFormula Varchar(100))
    INSERT INTO @PlantFormulaTable EXEC [TCD].[CharlistToTable] @PlantFormula,','

    DECLARE @ChainFormulaTable TABLE(ChainFormula Varchar(100))
    INSERT INTO @ChainFormulaTable EXEC [TCD].[CharlistToTable] @ChainFormula,','

    DECLARE @CustomerTable TABLE(Customer Varchar(100))
    INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','



    DECLARE @actualproduction int,@uom int
    SELECT @uom =UM.UOMId FROM TCD.UserMaster AS UM WHERE UM.UserId = @UserId

   SELECT @actualproduction = CASE @uom WHEN 1 THEN sum(spdr.ActualProduction)/100 
        WHEN 2 THEN ISNULL([TCD].[FnConsumptionOnMetrics](sum(spdr.ActualProduction),'Weight',@UserId),0) END   
   
            FROM tcd.ShiftProductionDataRollup spdr
              INNER JOIN TCD.ProductionShiftData AS PS ON PS.ShiftId = spdr.ShiftId 
    WHERE
        CASE @StartDate                                                                                
       WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
       ELSE CASE WHEN PS.[StartDateTime] >= @startdate AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
       END='TRUE'

     AND
       CASE @MachineType   
       WHEN '' THEN 'TRUE'         
       ELSE                                                      
       CASE WHEN spdr.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
       MS.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable))) THEN 'TRUE' END                                                      
       END='TRUE' 
    
    AND       

        CASE @machineGroup   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN spdr.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
        MS.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable)) THEN 'TRUE' END                                                      
        END='TRUE' 
    AND

        CASE @Machine   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN spdr.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
        END='TRUE' 
    AND
    
        CASE @EcolabCategory   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN spdr.EcolabTextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                      
        END='TRUE' 
     AND
    
        CASE @ChainCategory   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN spdr.ChainTextileId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END                                                      
        END='TRUE'
    AND

        CASE @PlantFormula   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN spdr.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                      
        END='TRUE'  
    AND
    
        CASE @ChainFormula   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN spdr.ChainTextileId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END                                                      
        END='TRUE'
    AND
    
        CASE @Customer   
        WHEN '' THEN 'TRUE'         
           ELSE                                                      
           CASE WHEN spdr.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                      
        END='TRUE' 

    DECLARE @resultSet TABLE
        (
          
          ChemicalName VARCHAR(100),
          ActualConsumption DECIMAL(18,2),
          TargetConsumption DECIMAL(18,2),
          --MachineId INT,
          ProgramMasterId INT,
          NoOfDays INT,
          NoOfLoads INT,
          Cost DECIMAL(18,2),
          StartDateTime date,
          PackageSizeId int,
          UnitWeightVolumeUOMId int,
          packagesizeweightuomcode varchar(100)
        )
 INSERT INTO @resultSet
    SELECT 
    PM.Name,
    SUM(SCD.ActualConsumption),
    SUM(SCD.TargetConsumption),
    --SCD.MachineId,
    SCD.ProgramMasterId,
    COUNT(DISTINCT CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date)),
    @actualproduction,
    SUM(SCD.ActualCost),
    PS.StartDateTime,
    PM.PackageSizeId, 
    CASE WHEN pm.PackageSizeId IS NULL AND type = 'Liquid' THEN isnull(psi.UnitWeightVolumeUOMId, 6) 
                         WHEN pm.PackageSizeId IS NULL AND type = 'solid' THEN isnull(psi.UnitWeightVolumeUOMId, 12) 
                         ELSE psi.UnitWeightVolumeUOMId END AS UnitWeightVolumeUOMId, 
                         CASE WHEN pm.PackageSizeId IS NULL AND 
                         type = 'Liquid' THEN isnull(psi.packagesizeweightuomcode, 'Pounds') WHEN pm.PackageSizeId IS NULL AND 
                         type = 'solid' THEN isnull(psi.packagesizeweightuomcode, 'gal')
                         when pm.PackageSizeId IS NULL and type is null then 'gal'
                          ELSE psi.packagesizeweightuomcode END AS packagesizeweightuomcode

    FROM 
        TCD.ShiftChemicalDataRollup SCD INNER JOIN TCD.ProductionShiftData PS ON SCD.SHIFTID = PS.ShiftId
		INNER JOIN TCD.ProgramMaster PRM on SCD.ProgramMasterId = PRM.ProgramId
        LEFT JOIN 
        TCD.ProductMaster PM ON SCD.ProductId = PM.ProductId 
         INNER JOIN
                         TCD.ProductdataMapping AS PDM ON PDM.ProductId = PM.ProductId LEFT OUTER JOIN
                         TCD.PackageSize AS PSi ON PM.PackageSizeId = PSi.PackageSizeId
        WHERE 
		-- Exclude pony and Phoney washers
		SCD.machineID NOT IN (SELECT
					     w.WasherId
					 FROM TCD.MachineSetup AS ms
					      INNER JOIN TCD.Washer AS w ON w.WasherId = ms.WasherId
									AND ms.EcoalabAccountNumber = w.EcoLabAccountNumber
					 WHERE (NULLIF(ms.ControllerId, 0)IS NULL
					   AND w.WasherMode = 0)
					   OR MS.IsPony = 1
					   )
     AND
	  CASE @StartDate                                                                                
       WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
       ELSE CASE WHEN PS.[StartDateTime] >= @startdate AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
       END='TRUE'

     AND
       CASE @MachineType   
       WHEN '' THEN 'TRUE'         
       ELSE                                                      
       CASE WHEN SCD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE     
       MS.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable))) THEN 'TRUE' END                                                      
       END='TRUE' 
    
    AND       

    CASE @machineGroup   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SCD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE   
    MS.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable)) THEN 'TRUE' END                                                      
    END='TRUE' 
    AND

    CASE @Machine   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SCD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
    END='TRUE' 
    AND
    
    CASE @EcolabCategory   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SCD.EcolabTextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                      
    END='TRUE' 
     AND
    
    CASE @ChainCategory   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SCD.ChainTextileId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END                                                      
    END='TRUE'
    AND

    CASE @PlantFormula   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SCD.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                      
    END='TRUE'  
    AND
    
    CASE @ChainFormula   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SCD.ChainTextileId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END                                                      
    END='TRUE'
    AND
    
    CASE @Customer   
    WHEN '' THEN 'TRUE'         
       ELSE                                                      
       CASE WHEN SCD.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                      
    END='TRUE' 
    GROUP BY PM.Name,SCD.ProgramMasterId,PS.StartDateTime,pm.PackageSizeId,psi.UnitWeightVolumeUOMId,psi.packagesizeweightuomcode,pm.type


    DECLARE @Exchangerate TABLE
        (
        ChemicalName VARCHAR(100),
        Cost DECIMAL(18,2)        
        )  

    INSERT INTO @Exchangerate
        (
        ChemicalName,
        Cost
        )
        
        SELECT
        ChemicalName,
        SUM(Cost)
        FROM
        (
        SELECT  ChemicalName AS ChemicalName,
        SUM(Cost) * ISNULL([TCD].[FnCurrencyExchangeRate](@CurrencyCode,MONTH(StartDateTime),YEAR(StartDateTime)),1) AS Cost
         FROM @resultSet
        GROUP BY ChemicalName,StartDateTime

        ) A
         GROUP BY A.ChemicalName

   
    SELECT
    ChemicalName,
     cast (ISNULL([TCD].[UnitConversionbyUserUOM](ActualConsumption,packagesizeweightuomcode,@UserId),0)as decimal(18,2)),
    --ActualConsumption * 0.0078125 AS ActualConsumption,--gal
    cast(ISNULL([TCD].[UnitConversionbyUserUOM](TargetConsumption,packagesizeweightuomcode,@UserId),0) as decimal(18,2)),
    --TargetConsumption * 0.0078125 AS TargetConsumption,--gal
    ProgramCount,
    NoOfLoads,
    NoOfDays,
    Cost,
     CAST((COALESCE(Cost/ NULLIF(ISNULL([TCD].[UnitConversionbyUserUOM](ActualConsumption,packagesizeweightuomcode,@UserId),1),0), 0) * ISNULL([TCD].[UnitConversionbyUserUOM](TargetConsumption,packagesizeweightuomcode,@UserId),0)) AS DECIMAL(18,2)) AS TargetCost,

    --CAST(((Cost / ISNULL([TCD].[FnConsumptionOnMetrics](ActualConsumption,'Volume',@UserId),0)) * ISNULL([TCD].[FnConsumptionOnMetrics](TargetConsumption,'Volume',@UserId),0))AS DECIMAL(18,2)) AS TargetCost
    --CAST(((Cost / (ActualConsumption * 0.0078125)) * (TargetConsumption* 0.0078125))AS DECIMAL(18,2)) AS TargetCost
    CASE @uom WHEN 1 THEN ActualConsumption 
      WHEN 2 THEN ActualConsumption * 28.3495 END AS ActualConsumptionMetrics,
     
          packagesizeweightuomcode as UOM
    FROM
    (
         SELECT
      r.ChemicalName,
      SUM(ActualConsumption) AS ActualConsumption,
      SUM(TargetConsumption) AS TargetConsumption,
      COUNT( DISTINCT ProgramMasterId) AS ProgramCount,
      COUNT(DISTINCT r.StartDateTime) AS NoOfDays,
      MAX(NoOfLoads) AS NoOfLoads,
      e.Cost AS Cost,
       PackageSizeId ,
          UnitWeightVolumeUOMId ,
          packagesizeweightuomcode

      --* ISNULL([TCD].[FnCurrencyExchangeRate](@CurrencyCode,MONTH(StartDateTime),YEAR(StartDateTime)),1) AS Cost

        FROM @resultSet r INNER JOIN @Exchangerate e ON r.ChemicalName = e.ChemicalName
        GROUP BY r.ChemicalName,e.Cost,r.PackageSizeId,r.UnitWeightVolumeUOMId,r.packagesizeweightuomcode
    ) A
    END

    go

	
	IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[ShiftDataAuditTrigger]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[ShiftDataAuditTrigger] 
END 
GO 
/*											 
###################################################################################################											  

Trigger		:		ShiftDataAuditTrigger

Purpose		:		Trigger	for auditing changes on ShiftData table

Parameter	:		NA

###################################################################################################											  
*/

CREATE TRIGGER TCD.ShiftDataAuditTrigger ON TCD.ShiftData
	FOR INSERT, UPDATE
AS
BEGIN

	SET NOCOUNT ON

	DECLARE @Auditoperation_Sqlinsertid TINYINT = NULL, 
			@Auditoperation_Sqlupdateid TINYINT = NULL, 
			@Auditoperation_Appdeleteid TINYINT = NULL,
			@Softdeleteflag BIT = NULL, 
			@Currenttimestamp DATETIME = GETUTCDATE()

	SELECT
			@Auditoperation_Sqlinsertid = AO.OperationId
		FROM TCD.AuditOperation AS AO
		WHERE AO.OperationCode = 'SQLInsert'

	SELECT
			@Auditoperation_Sqlupdateid = AO.OperationId
		FROM TCD.AuditOperation AS AO
		WHERE AO.OperationCode = 'SQLUpdate'

	SELECT
			@Auditoperation_Appdeleteid = AO.OperationId
		FROM TCD.AuditOperation AS AO
		WHERE AO.OperationCode = 'AppDelete'

	IF NOT EXISTS(SELECT
				1 
			FROM DELETED)
		BEGIN

			BEGIN 
				INSERT TCD.ShiftDataHistory(
						ShiftId, 
						OperationTimestamp, 
						OperationId, 
						OperationByUserId, 
						DayId, 
						StartTime, 
						EndTime, 
						EcolabAccountNumber, 
						Is_Deleted, 
						TargetProduction)
					SELECT
							ShiftId, 
							@Currenttimestamp, 
							@Auditoperation_Sqlinsertid, 
							LastModifiedByUserId, 
							DayId, 
							StartTime, 
							EndTime, 
							EcolabAccountNumber, 
							Is_Deleted, 
							TargetProduction
					FROM INSERTED
			END
		END
	ELSE
		BEGIN
			IF EXISTS(SELECT
					1 
				FROM INSERTED)
				BEGIN
					IF UPDATE(Is_Deleted)
						BEGIN
							SELECT @Softdeleteflag =  CASE 
														WHEN i.is_deleted = 1 THEN 'TRUE' 
														ELSE 'FALSE' 
													END
													FROM INSERTED AS i 
														INNER JOIN DELETED AS d ON i.ShiftId = d.ShiftId
															AND i.EcolabAccountNumber = d.EcolabAccountNumber
						END
					ELSE
						BEGIN
							SET @Softdeleteflag = 'FALSE'
						END

					BEGIN
						BEGIN 
							IF UPDATE(TargetProduction)
								BEGIN
									INSERT TCD.ShiftDataHistory(
											ShiftId, 
											OperationTimestamp, 
											OperationId, 
											OperationByUserId, 
											DayId, 
											StartTime, 
											EndTime, 
											EcolabAccountNumber, 
											Is_Deleted, 
											TargetProduction)
										SELECT
												ShiftId, 
												@Currenttimestamp, 
												CASE
													WHEN @Softdeleteflag = 'FALSE' THEN @Auditoperation_Sqlupdateid
													WHEN @Softdeleteflag = 'TRUE' THEN @Auditoperation_Appdeleteid
												END, 
												LastModifiedByUserId, 
												DayId, 
												StartTime, 
												EndTime, 
												EcolabAccountNumber, 
												Is_Deleted, 
												TargetProduction
										FROM INSERTED
								END
						END 
					END
				END
		END
	
	SET NOCOUNT OFF
	RETURN
END



IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[ReportChemicalConsumption]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[ReportChemicalConsumption] 
END 
GO 
create PROCEDURE [TCD].[ReportChemicalConsumption] 

         @startdate datetime = '',
         @enddate datetime = '',
     @EcolabAccountNumber Nvarchar(25) = '',
     @MachineType VARCHAR(20)= '',
     @MachineGroup VARCHAR(MAX) = '',
     @Machine VARCHAR(MAX) = '',
     @EcolabCategory VARCHAR(MAX) = '',
     @ChainCategory VARCHAR(MAX) = '',
     @PlantFormula  VARCHAR(MAX) = '',
     @ChainFormula VARCHAR(MAX) = '',
     @Customer VARCHAR(MAX) = '',
     @CurrencyCode varchar(3) = NULL,
     @UserId INT = NULL
    AS   
    BEGIN   
    SET NOCOUNT ON; 

     SET @startdate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@startdate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@startdate AS time)) AS DateTime))
    SET @EndDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndDate AS time)) AS DateTime))

    SELECT @CurrencyCode = um.CurrencyCode FROM TCD.UserMaster um WHERE um.UserId = @UserId
    IF (COUNT(@CurrencyCode) <> 1)
    BEGIN
    SELECT @CurrencyCode = p.CurrencyCode FROM TCD.Plant p
    END

    DECLARE @ReportGenerated INT = 6,
    @Month INT = MONTH(GETDATE()),@NoOfLoads INT,@NoOfPrograms INT

/* Inserting the record into Report History */

    INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)
    SELECT @EcolabAccountNumber,UM.UserId,
   UM.LoginName,
   GETUTCDATE(),
   @ReportGenerated,
   CASE WHEN @ReportGenerated = 6
  THEN 'Generated Report : Chemical Consumption Report' END
   FROM TCD.UserMaster UM
     WHERE UM.EcolabAccountNumber = @EcolabAccountNumber AND UM.UserId = @UserId

/* Completed the record insertion into Report History */

 
    DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))
    INSERT INTO @MachineTypeTable EXEC [TCD].[CharlistToTable] @MachineType,','

    DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))
    INSERT INTO @WasherGroupTable EXEC [TCD].[CharlistToTable] @machineGroup,','  

    DECLARE @MachineTable TABLE(Machine Varchar(100))
    INSERT INTO @MachineTable EXEC [TCD].[CharlistToTable] @Machine,','

    DECLARE @EcolabCategoryTable TABLE(EcolabCategory Varchar(100))
    INSERT INTO @EcolabCategoryTable EXEC [TCD].[CharlistToTable] @EcolabCategory,','

    DECLARE @ChainCategoryTable TABLE(ChainCategory Varchar(100))
    INSERT INTO @ChainCategoryTable EXEC [TCD].[CharlistToTable] @ChainCategory,','

    DECLARE @PlantFormulaTable TABLE(PlantFormula Varchar(100))
    INSERT INTO @PlantFormulaTable EXEC [TCD].[CharlistToTable] @PlantFormula,','

    DECLARE @ChainFormulaTable TABLE(ChainFormula Varchar(100))
    INSERT INTO @ChainFormulaTable EXEC [TCD].[CharlistToTable] @ChainFormula,','

    DECLARE @CustomerTable TABLE(Customer Varchar(100))
    INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','



    DECLARE @actualproduction int,@uom int
    SELECT @uom =UM.UOMId FROM TCD.UserMaster AS UM WHERE UM.UserId = @UserId

   SELECT @actualproduction = CASE @uom WHEN 1 THEN sum(spdr.ActualProduction)/100 
        WHEN 2 THEN ISNULL([TCD].[FnConsumptionOnMetrics](sum(spdr.ActualProduction),'Weight',@UserId),0) END   
   
            FROM tcd.ShiftProductionDataRollup spdr
              INNER JOIN TCD.ProductionShiftData AS PS ON PS.ShiftId = spdr.ShiftId 
    WHERE
        CASE @StartDate                                                                                
       WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
       ELSE CASE WHEN PS.[StartDateTime] >= @startdate AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
       END='TRUE'

     AND
       CASE @MachineType   
       WHEN '' THEN 'TRUE'         
       ELSE                                                      
       CASE WHEN spdr.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
       MS.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable))) THEN 'TRUE' END                                                      
       END='TRUE' 
    
    AND       

        CASE @machineGroup   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN spdr.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
        MS.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable)) THEN 'TRUE' END                                                      
        END='TRUE' 
    AND

        CASE @Machine   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN spdr.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
        END='TRUE' 
    AND
    
        CASE @EcolabCategory   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN spdr.EcolabTextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                      
        END='TRUE' 
     AND
    
        CASE @ChainCategory   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN spdr.ChainTextileId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END                                                      
        END='TRUE'
    AND

        CASE @PlantFormula   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN spdr.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                      
        END='TRUE'  
    AND
    
        CASE @ChainFormula   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN spdr.ChainTextileId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END                                                      
        END='TRUE'
    AND
    
        CASE @Customer   
        WHEN '' THEN 'TRUE'         
           ELSE                                                      
           CASE WHEN spdr.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                      
        END='TRUE' 

    DECLARE @resultSet TABLE
        (
          
          ChemicalName VARCHAR(100),
          ActualConsumption DECIMAL(18,2),
          TargetConsumption DECIMAL(18,2),
          --MachineId INT,
          ProgramMasterId INT,
          NoOfDays INT,
          NoOfLoads INT,
          Cost DECIMAL(18,2),
          StartDateTime date,
          PackageSizeId int,
          UnitWeightVolumeUOMId int,
          packagesizeweightuomcode varchar(100)
        )
 INSERT INTO @resultSet
    SELECT 
    PM.Name,
    SUM(SCD.ActualConsumption),
    SUM(SCD.TargetConsumption),
    --SCD.MachineId,
    SCD.ProgramMasterId,
    COUNT(DISTINCT CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date)),
    @actualproduction,
    SUM(SCD.ActualCost),
    PS.StartDateTime,
    PM.PackageSizeId, 
    CASE WHEN pm.PackageSizeId IS NULL AND type = 'Liquid' THEN isnull(psi.UnitWeightVolumeUOMId, 6) 
                         WHEN pm.PackageSizeId IS NULL AND type = 'solid' THEN isnull(psi.UnitWeightVolumeUOMId, 12) 
                         ELSE psi.UnitWeightVolumeUOMId END AS UnitWeightVolumeUOMId, 
                         CASE WHEN pm.PackageSizeId IS NULL AND 
                         type = 'Liquid' THEN isnull(psi.packagesizeweightuomcode, 'Pounds') WHEN pm.PackageSizeId IS NULL AND 
                         type = 'solid' THEN isnull(psi.packagesizeweightuomcode, 'gal')
                         when pm.PackageSizeId IS NULL and type is null then 'gal'
                          ELSE psi.packagesizeweightuomcode END AS packagesizeweightuomcode

    FROM 
        TCD.ShiftChemicalDataRollup SCD INNER JOIN TCD.ProductionShiftData PS ON SCD.SHIFTID = PS.ShiftId
		INNER JOIN TCD.ProgramMaster PRM on SCD.ProgramMasterId = PRM.ProgramId
        LEFT JOIN 
        TCD.ProductMaster PM ON SCD.ProductId = PM.ProductId 
         INNER JOIN
                         TCD.ProductdataMapping AS PDM ON PDM.ProductId = PM.ProductId LEFT OUTER JOIN
                         TCD.PackageSize AS PSi ON PM.PackageSizeId = PSi.PackageSizeId
        WHERE 
      CASE @StartDate                                                                                
       WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
       ELSE CASE WHEN PS.[StartDateTime] >= @startdate AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
       END='TRUE'

     AND
       CASE @MachineType   
       WHEN '' THEN 'TRUE'         
       ELSE                                                      
       CASE WHEN SCD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE   ispony=0 and    
       MS.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable))) THEN 'TRUE' END                                                      
       END='TRUE' 
    
    AND       

    CASE @machineGroup   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SCD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE  ispony=0 and     
    MS.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable)) THEN 'TRUE' END                                                      
    END='TRUE' 
    AND

    CASE @Machine   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SCD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
    END='TRUE' 
    AND
    
    CASE @EcolabCategory   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SCD.EcolabTextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                      
    END='TRUE' 
     AND
    
    CASE @ChainCategory   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SCD.ChainTextileId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END                                                      
    END='TRUE'
    AND

    CASE @PlantFormula   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SCD.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                      
    END='TRUE'  
    AND
    
    CASE @ChainFormula   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SCD.ChainTextileId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END                                                      
    END='TRUE'
    AND
    
    CASE @Customer   
    WHEN '' THEN 'TRUE'         
       ELSE                                                      
       CASE WHEN SCD.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                      
    END='TRUE' 
    GROUP BY PM.Name,SCD.ProgramMasterId,PS.StartDateTime,pm.PackageSizeId,psi.UnitWeightVolumeUOMId,psi.packagesizeweightuomcode,pm.type


    DECLARE @Exchangerate TABLE
        (
        ChemicalName VARCHAR(100),
        Cost DECIMAL(18,2)        
        )  

    INSERT INTO @Exchangerate
        (
        ChemicalName,
        Cost
        )
        
        SELECT
        ChemicalName,
        SUM(Cost)
        FROM
        (
        SELECT  ChemicalName AS ChemicalName,
        SUM(Cost) * ISNULL([TCD].[FnCurrencyExchangeRate](@CurrencyCode,MONTH(StartDateTime),YEAR(StartDateTime)),1) AS Cost
         FROM @resultSet
        GROUP BY ChemicalName,StartDateTime

        ) A
         GROUP BY A.ChemicalName

   
    SELECT
    ChemicalName,
     cast (ISNULL([TCD].[UnitConversionbyUserUOM](ActualConsumption,packagesizeweightuomcode,@UserId),0)as decimal(18,2)),
    --ActualConsumption * 0.0078125 AS ActualConsumption,--gal
    cast(ISNULL([TCD].[UnitConversionbyUserUOM](TargetConsumption,packagesizeweightuomcode,@UserId),0) as decimal(18,2)),
    --TargetConsumption * 0.0078125 AS TargetConsumption,--gal
    ProgramCount,
    NoOfLoads,
    NoOfDays,
    Cost,
     CAST((COALESCE(Cost/ NULLIF(ISNULL([TCD].[UnitConversionbyUserUOM](ActualConsumption,packagesizeweightuomcode,@UserId),1),0), 0) * ISNULL([TCD].[UnitConversionbyUserUOM](TargetConsumption,packagesizeweightuomcode,@UserId),0)) AS DECIMAL(18,2)) AS TargetCost,

    --CAST(((Cost / ISNULL([TCD].[FnConsumptionOnMetrics](ActualConsumption,'Volume',@UserId),0)) * ISNULL([TCD].[FnConsumptionOnMetrics](TargetConsumption,'Volume',@UserId),0))AS DECIMAL(18,2)) AS TargetCost
    --CAST(((Cost / (ActualConsumption * 0.0078125)) * (TargetConsumption* 0.0078125))AS DECIMAL(18,2)) AS TargetCost
    CASE @uom WHEN 1 THEN ActualConsumption 
      WHEN 2 THEN ActualConsumption * 28.3495 END AS ActualConsumptionMetrics,
     
          packagesizeweightuomcode as UOM
    FROM
    (
         SELECT
      r.ChemicalName,
      SUM(ActualConsumption) AS ActualConsumption,
      SUM(TargetConsumption) AS TargetConsumption,
      COUNT( DISTINCT ProgramMasterId) AS ProgramCount,
      COUNT(DISTINCT r.StartDateTime) AS NoOfDays,
      MAX(NoOfLoads) AS NoOfLoads,
      e.Cost AS Cost,
       PackageSizeId ,
          UnitWeightVolumeUOMId ,
          packagesizeweightuomcode

      --* ISNULL([TCD].[FnCurrencyExchangeRate](@CurrencyCode,MONTH(StartDateTime),YEAR(StartDateTime)),1) AS Cost

        FROM @resultSet r INNER JOIN @Exchangerate e ON r.ChemicalName = e.ChemicalName
        GROUP BY r.ChemicalName,e.Cost,r.PackageSizeId,r.UnitWeightVolumeUOMId,r.packagesizeweightuomcode
    ) A
    END

    go


    IF EXISTS (
    SELECT * FROM sysobjects WHERE id = object_id(N'[TCD].[UnitConversionbyUserUOM]') 
    AND xtype IN (N'FN', N'IF', N'TF')
)
    DROP FUNCTION [TCD].[UnitConversionbyUserUOM]
GO

Create FUNCTION TCD.UnitConversionbyUserUOM(
               
                @Valuetobeconverted DECIMAL(18, 2) = NULL, 
                @Uomcode VARCHAR(100) = NULL, 
                @Userid INT = NULL)
RETURNS DECIMAL(18, 2)
AS
BEGIN
    DECLARE @Result FLOAT, 
            @Uomid INT;




    SELECT
            @Uomid = UM.UOMId FROM TCD.UserMaster AS UM WHERE UM.UserId = @Userid;

    SELECT
            @Result = @Valuetobeconverted * CASE
                                                WHEN @Uomid = 1 THEN CASE @Uomcode
                                                                         WHEN 'gal' THEN 0.0078125
                                                                         WHEN 'lbs' THEN 0.0625
                                                                         WHEN 'kg' THEN 0.0283495
                                                                         WHEN 'mL' THEN 29.5735
                                                                         WHEN 'qt' THEN 0.03125
                                                                         WHEN 'CAN' THEN 0.033814
                                                                         WHEN 'impgal' THEN 0.00650527
                                                                         WHEN 'L' THEN 0.0295735
                                                                         WHEN 'g' THEN 28.3495
                                                                     END
                                                WHEN @Uomid = 2 THEN CASE @Uomcode
                                                                         WHEN 'gal' THEN 0.0295735
                                                                         WHEN 'lbs' THEN 0.0283495
                                                                         WHEN 'kg' THEN 0.0283495
                                                                         WHEN 'mL' THEN 29.5735
                                                                         WHEN 'qt' THEN 0.03125
                                                                         WHEN 'CAN' THEN 0.033814
                                                                         WHEN 'impgal' THEN 0.00650527
                                                                         WHEN 'L' THEN 0.0295735
                                                                         WHEN 'g' THEN 28.3495
                                                                     END
                                            END;
  	  


    RETURN @Result;

END;



IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[GetReportFiltersByFilterId]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[GetReportFiltersByFilterId]
END 
GO 


CREATE PROCEDURE [TCD].[GetReportFiltersByFilterId] 

(
			@FilterId INT,			
			@EcolabAccountNumber NVARCHAR(25),
			@LanguageId Int = 1
 )
AS
BEGIN
SET	NOCOUNT	ON
			  --Machinegroup
			  IF(@FilterId = 5)
			  BEGIN
						 SELECT CAST(WG.WasherGroupId AS int),
								WG.WasherGroupName
						 FROM TCD.MachineGroup GT 
								INNER JOIN TCD.WasherGroup WG ON GT.Id = WG.WasherGroupId
						 WHERE 
						 --GT.GroupDescription LIKE '%' + @SearchParameter + '%' AND 
						 GT.EcolabAccountNumber = @EcolabAccountNumber
			  END

			  -- Machine
			  ELSE IF(@FilterId = 6)
			  BEGIN
		  		   SELECT MS.WasherId,
							   MS.MachineName  
						FROM TCD.MachineSetup MS  
								INNER JOIN TCD.Washer WS ON MS.WasherId = WS.WasherId
						WHERE MS.IsDeleted = 0
							 -- AND MS.MachineName LIKE '%' + @SearchParameter + '%'  
			  END

			  --Category
			  ELSE IF(@FilterId = 7)
			  BEGIN
						SELECT CAST(TextileId AS int),
							   CategoryName  
						FROM TCD.EcolabTextileCategory
						--WHERE CategoryName LIKE '%' + @SearchParameter + '%'
			  END 

			  --MachineTypes
			  ELSE IF(@FilterId = 8)
			  BEGIN
						SELECT CAST(WasherGroupTypeId AS int),
							   WasherGroupTypeName 
						FROM TCD.WasherGroupType
					--	WHERE WasherGroupTypeName LIKE '%' + @SearchParameter + '%'			      
			  END 
			  --Customer
			  ELSE IF(@FilterId = 9)
			  BEGIN
						SELECT CAST(CustomerId AS int),
							   CustomerName 
						FROM TCD.PlantCustomer
						--WHERE 
						--CustomerName LIKE '%' + @SearchParameter + '%' AND
						 --Is_Deleted <> 0	
			  END 

			  --Formula
			  ELSE IF(@FilterId = 10)
			  BEGIN
						SELECT CAST(ProgramId AS int),
							   Name
	   	    				FROM TCD.ProgramMaster
						--WHERE 
						--Name LIKE '%' + @SearchParameter + '%' AND 
						--Is_Deleted <> 0 AND
	   					  -- EcolabAccountNumber = @EcolabAccountNumber
	   		  END 
			  --Controller/Dispencer
			  ELSE IF(@FilterId = 11)
			  BEGIN
						SELECT CAST(ControllerId AS int),
							   Name
	     				FROM TCD.conduitController
						WHERE
						 --Name LIKE '%' + @SearchParameter + '%' AND 
						 --IsDeleted <> 0 AND
						   EcoalabAccountNumber = @EcolabAccountNumber
	   		  END

			  --Alarm 
			  ELSE IF(@FilterId = 12)
			  BEGIN
					SELECT CAST(AlarmCode AS int),
							   [Description]
   				FROM TCD.ALARMMASTER
				--WHERE 
				--	[Description] LIKE '%' + @SearchParameter + '%' AND 
				--Active <> 0				  
	   			  END 
			  --DryerGroup
			  ELSE IF(@FilterId = 13)
			  BEGIN
						SELECT CAST(GT.Id AS int),
							   GT.GroupDescription
						FROM TCD.MachineGroup GT 
							INNER JOIN	TCD.DRYERS DR ON GT.Id = DR.DryerGroupId
						WHERE 
						--[Description] LIKE '%' + @SearchParameter + '%' AND 
						--DR.Is_deleted <> 0 AND
							   DR.EcolabAccountNumber = @EcolabAccountNumber
						  AND GT.GroupDescription = 'DryerGroup'
		  END 
			  --Dryer
			  ELSE IF(@FilterId = 14)
			  BEGIN
						SELECT CAST(DR.DryerNo AS int),
							   DR.[Description]
	     				FROM TCD.Dryers DR
						WHERE
						 --[Description] LIKE '%' + @SearchParameter + '%' AND 
						 --DR.Is_deleted <> 0 AND
						   DR.EcolabAccountNumber = @EcolabAccountNumber				 
			  END
		  --Finisher
			  ELSE IF(@FilterId = 15)
			  BEGIN
						SELECT CAST(FR.FinnisherNo AS int),
							   FR.Name
	   	    				FROM TCD.MachineGroup GT 
		  				INNER JOIN TCD.Finnishers FR ON GT.Id = FR.FinnisherGroupId
						WHERe
						-- FR.Name LIKE '%' + @SearchParameter + '%' AND 
						--FR.Is_deleted <> 0 AND
						   FR.EcolabAccountNumber = @EcolabAccountNumber
	   		  END 
			  --FinisherGroup
			  ELSE IF(@FilterId = 16)
			  BEGIN
						SELECT CAST(GT.Id AS int),
							   GT.GroupDescription
						FROM TCD.MachineGroup GT 
							INNER JOIN TCD.Finnishers FR ON GT.Id = FR.FinnisherGroupId
						WHERE 
						--GT.GroupDescription LIKE '%' + @SearchParameter + '%' AND 
						--GT.Is_deleted <> 0 AND
							 GT.EcolabAccountNumber = @EcolabAccountNumber
							AND GT.GroupDescription = 'FinnisherGroup'
			  END 
			  --Water and Energy recoveringUnit
			  --ELSE IF(@FilterId = 17)
			  --BEGIN
			  --END
			  --Meter 
			  ELSE IF(@FilterId = 18)
			  BEGIN
						SELECT CAST(MeterId AS int),
							   [Description]	
						FROM TCD.METER
						WHERE 
						--[Description] LIKE '%' + @SearchParameter + '%' AND 
						EcolabAccountNumber = @EcolabAccountNumber
							  --AND Is_deleted <> 0	
	   		  END 
			  ELSE IF(@FilterId = 21)
			  BEGIN
			   SELECT 
					   UM.UserId,
					   UM.LoginName
						FROM TCD.UserMaster UM
			  END

			  ELSE IF(@FilterId = 22)
			  BEGIN
			    SELECT 
					   CAST(AO.OperationId AS int) AS OperationId,
					   CASE	AO.OperationCode 
							WHEN	'SQLInsert'
							THEN	RKV.Value
							WHEN	'SQLUpdate'
							THEN	RKV.Value
							WHEN	'AppDelete'
							THEN	RKV.Value
							WHEN	'UserLogon'
							THEN	RKV.Value
							WHEN	'UserLogoff'
							THEN	RKV.Value
							WHEN 'ReportGenerated'
							THEN	RKV.Value
							WHEN 'Manual Entry' 
							THEN RKV.Value END AS OperationCode
					   	FROM TCD.AuditOperation AO INNER JOIN TCD.ResourceKeyMaster RKM ON AO.UsageKey = RKM.KeyName
											  INNER JOIN TCD.ResourceKeyValue RKV ON RKM.KeyName = RKV.KeyName
						WHERE RKV.languageID = @languageId
						ORDER BY OperationId
			  END
  END
GO


IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[ReportOperationsSummary]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[ReportOperationsSummary] 
END 
GO 


CREATE PROCEDURE [TCD].[ReportOperationsSummary] 

     @startdate datetime = '',
     @enddate datetime = '',
     @Viewtype Int = '',
     @Subview Int= '',
     @Drillvalue varchar(100)= '',
     @EcolabAccountNumber Nvarchar(25) = '',
     @MachineType VARCHAR(20)= '',
     @MachineGroup VARCHAR(MAX) = '',
     @Machine VARCHAR(MAX) = '',
     @EcolabCategory VARCHAR(MAX) = '',
     @ChainCategory VARCHAR(MAX) = '',
     @PlantFormula  VARCHAR(MAX) = '',
     @ChainFormula VARCHAR(MAX) = '',
     @Customer VARCHAR(MAX) = '',
     @SortColumnId int = 0,
     @SortDirection varchar(4) = '',
     @CurrencyCode varchar(3) = '',
     @UserId INT = NULL
AS   
BEGIN   
SET NOCOUNT ON; 

    SET @startdate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@startdate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@startdate AS time)) AS DateTime))
    SET @EndDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndDate AS time)) AS DateTime))


    DECLARE @ReportGenerated INT = 6,
    @Month INT = MONTH(GETDATE()),
    @NoOfLoads int

    /* Inserting the record into Report History */

    INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)
    SELECT @EcolabAccountNumber,UM.UserId,
   UM.LoginName,
   GETUTCDATE(),
   @ReportGenerated,
   CASE WHEN @ReportGenerated = 6
      THEN 'Generated Report : Operations Summary Report' END
   FROM TCD.UserMaster UM
     WHERE UM.EcolabAccountNumber = @EcolabAccountNumber AND UM.UserId = @UserId

    /* Completed the record insertion into Report History */

  -- Return Table set
    DECLARE @resultSet Table
    (
      ShiftId Int,
      DateRange varchar(100),
      TotalLoad Decimal(18,2),
      Numberofbatches INT,
      ActualChemicalConsumption Decimal(18,2),
      TargetChemicalConsumption Decimal(18,2),
      ActualEnergyConsumption  Decimal(18,2),
      TargetEnergyConsumption Decimal(18,2),
      ActualWaterConsumption  Decimal(18,2),
      TargetWaterConsumption Decimal(18,2),
      ActualChemicalCost Decimal(18,2),
      ActualWaterCost Decimal(18,2),
      ActualEnergyCost Decimal(18,2),
      Viewtype varchar(100) ,
      Subview varchar(100) ,
      Id int
        
    )

    DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))
    INSERT INTO @MachineTypeTable EXEC [TCD].[CharlistToTable] @MachineType,','

    DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))
    INSERT INTO @WasherGroupTable EXEC [TCD].[CharlistToTable] @machineGroup,','  

    DECLARE @MachineTable TABLE(Machine Varchar(100))
    INSERT INTO @MachineTable EXEC [TCD].[CharlistToTable] @Machine,','

    DECLARE @EcolabCategoryTable TABLE(EcolabCategory Varchar(100))
    INSERT INTO @EcolabCategoryTable EXEC [TCD].[CharlistToTable] @EcolabCategory,','

    DECLARE @ChainCategoryTable TABLE(ChainCategory Varchar(100))
    INSERT INTO @ChainCategoryTable EXEC [TCD].[CharlistToTable] @ChainCategory,','

    DECLARE @PlantFormulaTable TABLE(PlantFormula Varchar(100))
    INSERT INTO @PlantFormulaTable EXEC [TCD].[CharlistToTable] @PlantFormula,','

    DECLARE @ChainFormulaTable TABLE(ChainFormula Varchar(100))
    INSERT INTO @ChainFormulaTable EXEC [TCD].[CharlistToTable] @ChainFormula,','

    DECLARE @CustomerTable TABLE(Customer Varchar(100))
    INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','

    DECLARE @actualproduction int,@uom int
    SELECT @uom =UM.UOMId FROM TCD.UserMaster AS UM WHERE UM.UserId = @UserId
    /*
     

   SELECT @actualproduction = CASE @uom WHEN 1 THEN sum(spdr.ActualProduction)/100 
        WHEN 2 THEN ISNULL([TCD].[FnConsumptionOnMetrics](sum(spdr.ActualProduction),'Weight',@UserId),0) END   
   
            FROM tcd.ShiftProductionDataRollup spdr
              INNER JOIN TCD.ProductionShiftData AS PS ON PS.ShiftId = spdr.ShiftId 
    WHERE
        CASE @StartDate                                                                                
       WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
       ELSE CASE WHEN PS.[StartDateTime] >= @startdate AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
       END='TRUE'

     AND
       CASE @MachineType   
       WHEN '' THEN 'TRUE'         
       ELSE                                                      
       CASE WHEN spdr.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
       MS.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable))) THEN 'TRUE' END                                                      
       END='TRUE' 
    
    AND       

        CASE @machineGroup   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN spdr.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
        MS.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable)) THEN 'TRUE' END                                                      
        END='TRUE' 
    AND

        CASE @Machine   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN spdr.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
        END='TRUE' 
    AND
    
        CASE @EcolabCategory   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN spdr.EcolabTextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                      
        END='TRUE' 
     AND
    
        CASE @ChainCategory   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN spdr.ChainTextileId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END                                                      
        END='TRUE'
    AND

        CASE @PlantFormula   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN spdr.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                      
        END='TRUE'  
    AND
    
        CASE @ChainFormula   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN spdr.ChainTextileId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END                                                      
        END='TRUE'
    AND
    
        CASE @Customer   
        WHEN '' THEN 'TRUE'         
           ELSE                                                      
           CASE WHEN spdr.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                      
        END='TRUE' 

    */
    DECLARE @OperationSummaryTable TABLE(
          [ShiftId] [int] NULL,
         [ShiftName] Varchar(100) NULL,
         RecordDate date, 
         [MachineId] [int] NULL,
         [ProgramMasterId] [int] NULL,
         [EcolabWasherId] [int] NULL,
         ActualProduction [int] NULL,
         [NoOfLoads] [int] NULL,
         ActualChemicalConsumption Decimal(18,2),
         TargetChemicalConsumption Decimal(18,2),
         ActualEnergyConsumption  Decimal(18,2),
         TargetEnergyConsumption Decimal(18,2),
         ActualWaterConsumption  Decimal(18,2),
         TargetwaterConsumption Decimal(18,2),

         ActualChemicalCost decimal(18,2),
         ActualWaterCost decimal(18,2),
         ActualEnergyCost decimal(18,2),         
         EcolabTextileId int,
         ChainTextileId int,
         ChainProgaramId int,
         CustomerId int
        
        )
    INSERT INTO @OperationSummaryTable
        SELECT 
        DISTINCT
         SPD.[ShiftId],
         PS.ShiftName,
         CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date),
         --CAST(PS.StartDateTime AS date),
         SPD.[MachineId] ,
         SPD.[ProgramMasterId],
         SPD.[EcolabWasherId],
         CASE @uom WHEN 1 THEN SUM( DISTINCT spd.ActualProduction)
             WHEN 2 THEN ISNULL([TCD].[FnConsumptionOnMetrics](SUM( DISTINCT spd.ActualProduction),'Weight',@UserId),0) END,
         --SUM(DISTINCT SPD.ActualProduction),
         SUM(DISTINCT SPD.NoOfLoads),
         SUM(SCD.ActualConsumption),
         SUM(SCD.TargetConsumption),
         SUM(SED.ActualConsumption),
         SUM(SED.TargetConsumption),
         SUM(SWD.ActualConsumption),
         SUM(SWD.TargetConsumption),

         SUM(SCD.ActualCost),
         SUM(SED.ActualCost),
         SUM(SWD.ActualCost),
                  
         SPD.EcolabTextileId,
         SPD.ChainTextileId,
         SPD.ChainProgaramId,
         SPD.CustomerId
         
        FROM 
			TCD.ShiftProductionDataRollup SPD INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId
            LEFT JOIN 
            TCD.ShiftChemicalDataRollup SCD  ON SPD.ShiftId = SCD.ShiftId 
            AND SPD.MachineId = SCD.MachineId AND SPD.ProgramMasterId = SCD.ProgramMasterId
            LEFT JOIN 
            TCD.ShiftEnergyDataRollup SED ON SED.ShiftId = SPD.ShiftId
            AND SED.MachineId = SPD.MachineId AND SED.ProgramMasterId = SPD.ProgramMasterId
            LEFT JOIN 
            TCD.[ShiftWaterDataRollup] SWD ON SED.ShiftId = SPD.ShiftId
            AND SWD.MachineId = SPD.MachineId AND SWD.ProgramMasterId = SPD.ProgramMasterId
			INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId 
        WHERE SPD.MachineId NOT IN (SELECT
					     w.WasherId
					 FROM TCD.MachineSetup AS ms
					      INNER JOIN TCD.Washer AS w ON w.WasherId = ms.WasherId
									AND ms.EcoalabAccountNumber = w.EcoLabAccountNumber
					 WHERE (NULLIF(ms.ControllerId, 0)IS NULL
					   AND w.WasherMode = 0)
					   OR MS.IsPony = 1
					   )
	AND 
       CASE @StartDate                                                                                
       WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
       ELSE CASE WHEN PS.[StartDateTime]  >= @startdate AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
       END='TRUE'

        AND
       CASE @MachineType   
       WHEN '' THEN 'TRUE'         
       ELSE                                                      
       CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
       MS.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable))) THEN 'TRUE' END                                                      
       END='TRUE' 
    
        AND       

    CASE @machineGroup   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
    MS.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable)) THEN 'TRUE' END                                                      
    END='TRUE' 
        AND

    CASE @Machine   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
    END='TRUE' 
        AND
    
    CASE @EcolabCategory   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.EcolabTextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                      
    END='TRUE' 
        AND
    
    CASE @ChainCategory   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.ChainTextileId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END                                                      
    END='TRUE'
        AND

    CASE @PlantFormula   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                      
    END='TRUE'  
        AND
    
    CASE @ChainFormula   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.ChainTextileId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END                                                      
    END='TRUE'
        AND
    
    CASE @Customer   
    WHEN '' THEN 'TRUE'         
       ELSE                                                      
       CASE WHEN SPD.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                      
    END='TRUE' 
            
    GROUP BY SPD.[ShiftId],PS.ShiftName,SPD.[MachineId] ,SPD.[ProgramMasterId],SPD.[EcolabWasherId],SPD.EcolabTextileId,         SPD.ChainTextileId,
    SPD.ChainProgaramId,
    SPD.CustomerId,CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date)

    --SELECT * FROM @OperationSummaryTable
    SELECT @NoOfLoads =  SUM(NoOfLoads) 
        FROM (
            SELECT SUM(DISTINCT OST.NoOfLoads) AS NoOfLoads FROM @OperationSummaryTable AS OST GROUP BY OST.ShiftId )  NoOfLoads
      
    --SELECT DISTINCT
    --    0,
    --    CC.Name
    --    ,SUM(SPD.ActualProduction)
    --    ,sum(DISTINCT NoOfLoads)
    --    ,SUM(ActualChemicalConsumption)
    --    ,SUM(TargetChemicalConsumption) 
    --    ,@Viewtype 
    --    ,@Subview
    --    ,0
    --    FROM @OperationSummaryTable SPD LEFT JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
    -- GROUP BY 
    --   CC.Name,CC.TextileId        

    IF(@Viewtype = 3)
    BEGIN

    IF(@Subview = 12)
    BEGIN
     INSERT INTO @resultSet
     SELECT DISTINCT
        0
        ,EC.CategoryName
        ,SUM(SPD.ActualProduction)
        ,sum(DISTINCT NoOfLoads)
        ,SUM(ActualChemicalConsumption)
        ,SUM(TargetChemicalConsumption) 
        ,SUM(ActualEnergyConsumption)
        ,SUM(TargetEnergyConsumption)
        ,SUM(ActualWaterConsumption)
        ,SUM(TargetWaterConsumption)
        ,SUM(ActualChemicalCost)
        ,SUM(ActualWaterCost)
        ,SUM(ActualEnergyCost)
        ,@Viewtype 
        ,@Subview
        ,EC.TextileId
    FROM @OperationSummaryTable SPD LEFT JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId

    GROUP BY 
   EC.CategoryName,EC.TextileId
        END
    IF(@Subview = 17)

BEGIN
 INSERT INTO @resultSet
 SELECT 
   DISTINCT
    0, 
    PM.Name
    ,SUM(SPD.ActualProduction)
    ,sum(DISTINCT NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,0
    FROM @OperationSummaryTable SPD INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
         INNER JOIN TCD.ProgramMaster PM ON EC.TextileId = PM.EcolabTextileCategoryId AND SPD.ProgramMasterId = PM.ProgramId
    
WHERE
    (
    CASE    
     WHEN @drillvalue='' THEN 'TRUE' 
     WHEN @drillvalue IS NULL THEN 'TRUE'  
     ELSE                                                    
      CASE WHEN EC.TextileId IN (@drillvalue) THEN 'TRUE' END            
     END='TRUE'
    )
GROUP BY 
   PM.Name
END
END
  -- ************************ By Textile Category View ************************************************
IF(@Viewtype = 4)

BEGIN 

IF(@Subview = 15)
BEGIN
 INSERT INTO @resultSet
 SELECT DISTINCT
    0,
    CC.Name
    ,SUM(SPD.ActualProduction)
    ,sum(DISTINCT NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,CC.TextileId
    FROM @OperationSummaryTable SPD LEFT JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
 GROUP BY 
   CC.Name,CC.TextileId
END
  
IF(@Subview = 18)
BEGIN
 INSERT INTO @resultSet
 SELECT DISTINCT       
    0, 
    PM.Name
    ,SUM(SPD.ActualProduction)
    ,sum(DISTINCT NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,0
    FROM @OperationSummaryTable SPD INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
         INNER JOIN TCD.ProgramMaster PM ON CC.TextileId = PM.ChainTextileId AND SPD.ProgramMasterId = PM.ProgramId
    
WHERE
    (
    CASE    
     WHEN @drillvalue='' THEN 'TRUE' 
     WHEN @drillvalue IS NULL THEN 'TRUE'  
     ELSE                                                    
      CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END            
     END='TRUE'
    )
GROUP BY 
   PM.Name
END

END

-- ******************************** Timeline View ***************************************************
IF(@Viewtype = 1)

BEGIN

    ---- By TimeLine - Day View
    IF(@Subview = 5)
    BEGIN 
    INSERT INTO @resultSet
    SELECT DISTINCT
    0,
    SPD.ShiftName
     ,SUM(SPD.ActualProduction)
    ,sum(DISTINCT NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,0
     FROM @OperationSummaryTable SPD
    GROUP BY 
    SPD.ShiftName
    END

     ---- By TimeLine - Week View
  IF (@Subview = 4)
   BEGIN
   INSERT INTO @resultSet
   SELECT DISTINCT
    0,
    CAST(RecordDate AS nvarchar(100))
    ,SUM(SPD.ActualProduction)
    ,sum(DISTINCT NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,0
     FROM @OperationSummaryTable SPD
    GROUP BY DATEPART(weekday,RecordDate),RecordDate
  END

 ---- By TimeLine - Month View
    IF(@Subview = 3)
    BEGIN
    DECLARE @FirstDay date = (SELECT TOP 1 RecordDate FROM @OperationSummaryTable ORDER BY RecordDate)
    DECLARE @LastDay date = (SELECT TOP 1 RecordDate FROM @OperationSummaryTable ORDER BY RecordDate DESC)
    DECLARE @FirstSunday date = NULL,
    @LastSaturday date = NULL

    
    SELECT 
    @FirstSunday = CAST(DateAdd(dd, (8-DatePart(WEEKDAY, 
       DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)))%7, 
       DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)) AS DATE) 

     SELECT
      @LastSaturday = 
        DATEADD(dd,
            -DATEPART(WEEKDAY,
              DATEADD(dd, -DAY(DATEADD(month, 1, @LastDay)),
              DATEADD(month, 1, @LastDay))) ,
            DATEADD(dd, -DAY(DATEADD(MONTH, 1, @LastDay)), DATEADD(MONTH, 1, @LastDay)));

    WITH CTE(DateRange ,TotalLoad,Numberofbatches,ActualChemicalConsumption,TargetChemicalConsumption,
    ActualEnergyConsumption,TargetEnergyConsumption,ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,ActualEnergyCost)
    AS
    (
    SELECT 
       
        CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,-1,@FirstSunday)) = 7 
       AND (SELECT COUNT(1) FROM @OperationSummaryTable WHERE RecordDate < DATEADD(DD,-1,@FirstSunday)) = 0)
       THEN CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100))
       WHEN DATEADD(DD,-1,@FirstSunday) > CAST(GETDATE() AS DATE) 
       THEN
       CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @enddate, 101) AS nvarchar(100))
       ELSE
       CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) END As DateRange,
       SUM(SPD.ActualProduction)
        ,sum(DISTINCT NoOfLoads)
        ,SUM(ActualChemicalConsumption)
        ,SUM(TargetChemicalConsumption) 
        ,SUM(ActualEnergyConsumption)
        ,SUM(TargetEnergyConsumption)
        ,SUM(ActualWaterConsumption)
        ,SUM(TargetWaterConsumption)
        ,SUM(ActualChemicalCost)
        ,SUM(ActualWaterCost)
        ,SUM(ActualEnergyCost)

         FROM @OperationSummaryTable SPD
        WHERE RecordDate < @FirstSunday AND RecordDate >= @FirstDay

        
        UNION ALL

  
        SELECT
        
        --CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100)) AS StartDate,
        --CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) AS EndDate,
          CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100))  + CHAR(13) + '-' +
         CASE WHEN CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) >
         CAST(Convert(varchar, DateAdd(dd, (1 - DatePart(dw, @enddate) + 1), @enddate), 101) AS nvarchar(100))
         THEN  CAST(Convert(varchar, DateAdd(dd, 1-1, @enddate), 101) AS nvarchar(100))
         ELSE CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) END
         As DateRange,
         SUM(SPD.ActualProduction)
        ,sum(DISTINCT NoOfLoads)
        ,SUM(ActualChemicalConsumption)
        ,SUM(TargetChemicalConsumption) 
        ,SUM(ActualEnergyConsumption)
        ,SUM(TargetEnergyConsumption)
        ,SUM(ActualWaterConsumption)
        ,SUM(TargetWaterConsumption)
         ,SUM(ActualChemicalCost)
        ,SUM(ActualWaterCost)
        ,SUM(ActualEnergyCost)
        FROM @OperationSummaryTable SPD
           WHERE RecordDate BETWEEN @FirstSunday AND @LastSaturday
        GROUP BY Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101),
         Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101)
       
       UNION ALL

        SELECT 
         CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,1,@LastSaturday)) = 1 
        AND (SELECT COUNT(1) FROM @OperationSummaryTable WHERE RecordDate > DATEADD(DD,1,@LastSaturday)) = 0)
        THEN 
        CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) 
        ELSE
       CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @LastDay, 101) AS nvarchar(100)) END   As DateRange,
        SUM(SPD.ActualProduction)
        ,sum(DISTINCT NoOfLoads)
        ,SUM(ActualChemicalConsumption)
        ,SUM(TargetChemicalConsumption) 
        ,SUM(ActualEnergyConsumption)
        ,SUM(TargetEnergyConsumption)
        ,SUM(ActualWaterConsumption)
        ,SUM(TargetWaterConsumption)
         ,SUM(ActualChemicalCost)
        ,SUM(ActualWaterCost)
        ,SUM(ActualEnergyCost)
        FROM @OperationSummaryTable SPD
        WHERE RecordDate > @LastSaturday AND RecordDate <= @LastDay
        )
        INSERT INTO @resultSet
        SELECT DISTINCT
        0,
        DateRange,
        TotalLoad,
        Numberofbatches,
        ActualChemicalConsumption,
        TargetChemicalConsumption,
        ActualEnergyConsumption,
        TargetEnergyConsumption,
        ActualWaterConsumption,
        TargetWaterConsumption,
        ActualChemicalCost,
        ActualWaterCost,
        ActualEnergyCost       
        ,@Viewtype 
        ,@Subview
         ,0
            FROM CTE
            WHERE TotalLoad IS NOT NULL

        END

    IF(@Subview = 2)
    BEGIN
    DECLARE @QuarterYear VARCHAR(100) = YEAR(@enddate);
    INSERT INTO @resultSet
    SELECT  DISTINCT
       0,
        DATENAME(MONTH, RecordDate) + ' ' + @QuarterYear As DateRange,
        SUM(SPD.ActualProduction)
       ,sum(DISTINCT NoOfLoads)
      ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption) 
     ,SUM(ActualChemicalCost)
        ,SUM(ActualWaterCost)
        ,SUM(ActualEnergyCost)
        ,@Viewtype 
        ,@Subview
        ,0
         FROM @OperationSummaryTable SPD
        GROUP BY  DATEPART(MONTH, RecordDate),DATENAME(MONTH, RecordDate)
    END   

    IF(@Subview = 1)
    BEGIN
    DECLARE @Year VARCHAR(100) = RIGHT(YEAR(@enddate),2)
    INSERT INTO @resultSet
    SELECT DISTINCT
        0,
         CASE 'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10))
           WHEN 'Q1' THEN 'Jan' + @Year + '- Mar' + @Year
           WHEN 'Q2' THEN 'Apr' + @Year + '- Jun' + @Year
           WHEN 'Q3' THEN 'Jul' + @Year + '-Sep' + @Year
           WHEN 'Q4' THEN 'Oct' + @Year + '- Dec'+ @Year
       END AS DateRange,
        SUM(SPD.ActualProduction)
       ,sum(DISTINCT NoOfLoads)
       ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
     ,SUM(ActualChemicalCost)
        ,SUM(ActualWaterCost)
        ,SUM(ActualEnergyCost)
        ,@Viewtype 
        ,@Subview
        ,0
         FROM @OperationSummaryTable SPD
    GROUP BY DATEPART(QUARTER, RecordDate)

    END
    END

     -- ******************************** Location View ***************************************************
    IF(@Viewtype = 2)
    BEGIN

    IF(@Subview = 9)
    BEGIN

    WITH CTE(DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption,TargetChemicalConsumption,ActualEnergyConsumption,
    TargetEnergyConsumption,ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,ActualEnergyCost,WasherGroupId)
    AS
    (
    SELECT 
        WG.WasherGroupName,
        SUM(SPD.ActualProduction)
       ,sum(DISTINCT NoOfLoads)
       ,SUM(ActualChemicalConsumption)
        ,SUM(TargetChemicalConsumption) 
        ,SUM(ActualEnergyConsumption)
        ,SUM(TargetEnergyConsumption)
        ,SUM(ActualWaterConsumption)
        ,SUM(TargetWaterConsumption)
         ,SUM(ActualChemicalCost)
     ,SUM(ActualWaterCost)
     ,SUM(ActualEnergyCost)
       ,WG.WasherGroupId

    FROM @OperationSummaryTable SPD LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId
             LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId 
    GROUP BY WG.WasherGroupName,WG.WasherGroupId--,SPD.ShiftId
    )
    

     INSERT INTO @resultSet
     SELECT 0, 
      DateRange,
      SUM(TotalLoad),
      SUM(Numberofbatches),
      SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
     ,SUM(ActualChemicalCost)
        ,SUM(ActualWaterCost)
        ,SUM(ActualEnergyCost)
     ,@Viewtype 
      ,@Subview
       ,WasherGroupId
         FROM CTE 
            WHERE TotalLoad IS NOT NULL
       
        GROUP BY DateRange,WasherGroupId
     END

     IF(@Subview = 10)
    BEGIN

     WITH CTE(DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption,TargetChemicalConsumption,ActualEnergyConsumption,
     TargetEnergyConsumption,ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,ActualEnergyCost)
    AS
    (
    SELECT 
        CAST( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName as MachineName,
        SUM(SPD.ActualProduction)
       ,sum(DISTINCT NoOfLoads)
       ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
        ,SUM(ActualWaterCost)
        ,SUM(ActualEnergyCost)     
    FROM @OperationSummaryTable SPD 
	LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId
	LEFT JOIN TCD.Washer w on MS.WasherId=w.WasherId
    LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId 
    WHERE 
      (
       CASE @drillvalue   
           WHEN '' THEN 'TRUE'         
           ELSE                                                    
            CASE WHEN WG.WasherGroupId IN (@drillvalue) THEN 'TRUE' END            
           END='TRUE'
      )
     GROUP BY CAST( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName--,SPD.ShiftId
     )

     INSERT INTO @resultSet
     SELECT  0, 
        DateRange,
        SUM(TotalLoad),
        SUM(Numberofbatches),
        SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
        ,SUM(ActualWaterCost)
        ,SUM(ActualEnergyCost)
        ,@Viewtype 
        ,@Subview
        ,0
         FROM CTE 
            WHERE TotalLoad IS NOT NULL
        GROUP BY DateRange
    END
    END

       -- ******************************** ChainCategory View **********************************************
   IF(@Viewtype = 5)
    BEGIN
    IF(@Subview = 16)
    BEGIN
 -- ToDo : Change this part for chaincategory
     INSERT INTO @resultSet
     SELECT DISTINCT
    0,  
    CC.NAME,
    SUM(SPD.ActualProduction)
    ,sum(DISTINCT NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
        ,SUM(ActualWaterCost)
        ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,CC.TextileId
    FROM
     @OperationSummaryTable SPD
    INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
     INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = PM.PlantProgramId
     INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId 
    Group by 
   CC.Name,CC.TextileId
    END

    
   IF(@Subview = 19)
    BEGIN
 -- ToDo : Change this part for chaincategory
     INSERT INTO @resultSet
     SELECT  DISTINCT
    0,
    PCP.PlantProgramName,
    SUM(SPD.ActualProduction)
    ,sum(DISTINCT NoOfLoads)
   ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
        ,SUM(ActualWaterCost)
        ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,0
    FROM @OperationSummaryTable SPD
    INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
     INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = PM.PlantProgramId
     INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId 
     WHERE
    (
   CASE @drillvalue   
       WHEN '' THEN 'TRUE'         
       ELSE                                                    
       CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END            
       END='TRUE'
  )
 Group by 
   PCP.PlantProgramName,PCP.PlantProgramId
END

END

   -- ******************************** Customer View ***************************************************
IF(@Viewtype = 6)
BEGIN
 INSERT INTO @resultSet
 SELECT DISTINCT
    0,
    PC.CustomerName,
    SUM(SPD.ActualProduction)
    ,sum(DISTINCT NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
        ,SUM(ActualWaterCost)
        ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,0
    FROM @OperationSummaryTable SPD  INNER JOIN TCD.PlantCustomer PC on PC.CustomerId = SPD.CustomerId
    GROUP BY 
   PC.CustomerName
END

-- ******************************** Formula View ****************************************************
IF(@Viewtype = 7)
BEGIN
 INSERT INTO @resultSet
 SELECT DISTINCT
    0,
    PM.Name,
    SUM(SPD.ActualProduction)
    ,sum(DISTINCT NoOfLoads)
   ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
        ,SUM(ActualWaterCost)
        ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,0
    FROM @OperationSummaryTable SPD 
    INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
    Group by 
    PM.Name
    END


   
   --- ********* Return result ********************

    SELECT DISTINCT
     ShiftId,
      DateRange,
     CASE @uom WHEN 1 THEN TotalLoad
            WHEN 2 THEN ISNULL([TCD].[FnConsumptionOnMetrics](TotalLoad,'Weight',@UserId),0) END AS ActualProduction,
      --CAST(TotalLoad AS int) AS ActualProduction,
      Numberofbatches AS NoOfLoads,
      ISNULL([TCD].[FnConsumptionOnMetrics](ActualChemicalConsumption,'Volume',@UserId),0) ActualChemicalConsumption,
      --ActualChemicalConsumption ,
      ISNULL([TCD].[FnConsumptionOnMetrics](TargetChemicalConsumption,'Volume',@UserId),0) TargetChemicalConsumption,
      --TargetChemicalConsumption,
      ActualEnergyConsumption,
      TargetEnergyConsumption,
      ActualWaterConsumption,
      TargetWaterConsumption,
      ActualChemicalCost,
      ActualWaterCost,
      ActualEnergyCost,
      Viewtype,
      Subview ,
      Id,
      --CASE @uom WHEN 1 THEN ActualChemicalConsumption 
      --WHEN 2 THEN ActualChemicalConsumption * 28.3495 END AS ActualChemicalConsumptionMetrics ,
      --CASE @uom WHEN 1 THEN TargetChemicalConsumption 
      --WHEN 2 THEN TargetChemicalConsumption * 28.3495 END AS TargetChemicalConsumption,
     CASE @uom WHEN 1 THEN TotalLoad/100 
            WHEN 2 THEN ISNULL([TCD].[FnConsumptionOnMetrics](TotalLoad,'Weight',@UserId),0) END AS ActualProductionMetrics      
      FROM 
        @resultSet
        WHERE [@resultSet].DateRange IS NOT NULL

END
GO



IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[GetAlarmDetailsReport]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[GetAlarmDetailsReport] 
END 
GO 


--EXEC [TCD].[GetAlarmDetailsReport] '','','','','','','','','1,','','2015-01-01','2015-01-31','','',249,'asC',1,1 ,50 -- Alarm Details Report

CREATE PROCEDURE [TCD].[GetAlarmDetailsReport] (
										  @Corporate Varchar(max) = '',
										  @Country Varchar(max) = '',
										  @Region Varchar(max) = '',
										  @EcolabAccountNumber Nvarchar(25) = '',
										  @Controller Varchar(max) = '',
										  @Machine Varchar(max) = '', 
										  @machineGroup Varchar(max) = '',
										  @Formula Varchar(max) = '',
										  @MachineType Varchar(20)= '',
										  @Alarm Varchar(max) = '',
										  @FromDate Datetime = '',
										  @ToDate Datetime = '',
										  @GroupId Varchar(max) = '',
										  @MachineInternalId Varchar(max) = '',
										  @SortColumnID INT = NULL,
										  @SortDirection Varchar(100) = '',
										  @UserId INT = NULL,
										  @PageNo	INT	 = NULL,
										  @RecordsPerPage INT = NULL
									   )
AS   
BEGIN   
SET NOCOUNT ON;   

SET @FromDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@FromDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@FromDate AS time)) AS DateTime))
SET @ToDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@ToDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@ToDate AS time)) AS DateTime))


DECLARE @ReportGenerated INT = 6
/* Inserting the record into Report History */
SET @PageNo = @PageNo-1
INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)
SELECT @EcolabAccountNumber,UM.UserId,
	  UM.LoginName,
	  GETUTCDATE(),
	  @ReportGenerated,
	  CASE WHEN @ReportGenerated = 6
		THEN 'Generated Report : AlarmDetailsReport' END
	  FROM TCD.UserMaster UM
	    WHERE	UM.EcolabAccountNumber =	@EcolabAccountNumber AND UM.UserId = @UserId

/* Completed the record insertion into Report History */

DECLARE @Month INT = MONTH(GETDATE()),
	   @SortField Varchar(100) = '',
	   @SummationInMin Int = NULL,
	   @SQLStatement varchar(max)

	     SELECT @SortField =  CASE WHEN @SortColumnID = 13 THEN 'AlarmDescription'
						WHEN @SortColumnID = 14 THEN 'AlarmCode'
						WHEN @SortColumnID = 69 THEN 'EndDate'
						WHEN @SortColumnID = 168 THEN 'StartDate'
						WHEN @SortColumnID = 247 THEN 'Controller'
						WHEN @SortColumnID = 248 THEN 'AlarmCode'
						WHEN @SortColumnID = 249 THEN 'WasherNumber'
						WHEN @SortColumnID = 250 THEN 'BatchId'
						WHEN @SortColumnID = 251 THEN 'ValveNumber'
						WHEN @SortColumnID = 252 THEN 'ChemicalName'
						WHEN @SortColumnID = 253 THEN 'InjectionNo'
						WHEN @SortColumnID = 254 THEN 'FormulaNo'
						WHEN @SortColumnID = 255 THEN 'FormulaName'
						WHEN @SortColumnID = 256 THEN 'DesiredValue'
						WHEN @SortColumnID = 257 THEN 'MeasuredValue'
						WHEN @SortColumnID = 258 THEN 'IsActiveStatus'
						WHEN @SortColumnID = 0 THEN 'StartDate'
						 END



DECLARE @ControllerTable TABLE(Controller Varchar(100))
INSERT INTO @ControllerTable(Controller) EXEC [TCD].[charlistToTable] @Controller,','

DECLARE @MachineTable TABLE(Machine Varchar(100))
INSERT INTO @MachineTable(Machine) EXEC [TCD].[charlistToTable] @Machine,','

DECLARE @GroupMachineTable TABLE(GroupId INT,MachineInternalId INT)  
INSERT INTO @GroupMachineTable(GroupId,MachineInternalId) 
SELECT GroupId,MachineInternalId FROM TCD.MachineSetup MS 
									INNER JOIN TCD.Washer WS ON MS.WasherId = WS.WasherId WHERE WS.PlantWasherNumber IN (SELECT Machine FROM @MachineTable);

DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))
INSERT INTO @WasherGroupTable(MachineGroup) EXEC [TCD].[charlistToTable] @machineGroup,','

DECLARE @FormulaTable TABLE(Formula Varchar(100))
INSERT INTO @FormulaTable(Formula) EXEC [TCD].[charlistToTable] @Formula,','

DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))
INSERT INTO @MachineTypeTable(MachineType) EXEC [TCD].[charlistToTable] @MachineType,','

DECLARE @AlarmsTable TABLE(Alarm Varchar(100))
INSERT INTO @AlarmsTable(Alarm) EXEC [TCD].[charlistToTable] @Alarm,','

DECLARE @GroupTable TABLE(GroupId Varchar(100))
INSERT INTO @GroupTable(GroupId) EXEC [TCD].[CharlistToTable] @GroupId,','

DECLARE @MachineInternalTable TABLE(MachineInternalId Varchar(100))
INSERT INTO @MachineInternalTable(MachineInternalId) EXEC [TCD].[CharlistToTable] @MachineInternalId,','

	  DECLARE @AlarmTable TABLE(
							 AlarmCode Int,
							 AlarmDescription NVarchar(2000),
							 Controller Nvarchar(100),
							 StartDate Datetime,
							 EndDate Datetime,
							 SecDuration INT,
							 WasherNumber INT,
							 BatchID INT,
							 ValveNumber INT,
							 ChemicalName Nvarchar(1000),
							 InjectionNo INT,
							 FormulaNo INT,
							 FormulaName Nvarchar(1000),
							 DesiredValue decimal(10,2),
							 MeasuredValue decimal(10,2),
							 IsActiveStatus BIT
    						  )


INSERT INTO @AlarmTable(
							 AlarmCode ,
							 AlarmDescription ,
							 Controller ,
							 StartDate ,
							 EndDate ,
							 SecDuration ,
							 WasherNumber ,
							 BatchID ,
							 ValveNumber ,
							 ChemicalName,
							 InjectionNo ,
							 FormulaNo ,
							 FormulaName ,
							 DesiredValue ,
							 MeasuredValue ,
							 IsActiveStatus 
    						  )
SELECT 
		  DISTINCT
			  AD.AlarmCode,	
	   		  AM.Description,	
			  (SELECT cc.Name FROM [TCD].ConduitController CC  WHERE cc.ControllerId = AD.ControllerId) AS Controller,	 
			  AD.StartDate,
			  AD.EndDate,
			  DATEDIFF(SECOND,AD.StartDate,AD.EndDate),
			  MS.WasherId,
			  AD.BatchId,
			  AD.Valve,
			  PM.Name,
			  AD.InjectionNumber,
			  AD.ProgramId,
			  PP.Name,
			  AD.DesiredQuatity,
			  AD.MeasuredQuantity,
			  AD.IsActive
	FROM [TCD].AlarmData AS AD
		   INNER JOIN [TCD].AlarmMaster AM ON AD.AlarmCode = AM.AlarmCode
		   LEFT JOIN [TCD].MachineSetup MS ON MS.WasherId = AD.MachineId
		   LEFT JOIN [TCD].ControllerEquipmentSetup CES ON AD.Valve = CES.ControllerEquipmentId AND AD.ControllerId = CES.ControllerId
		   LEFT JOIN [TCD].ProductMaster PM ON CES.ProductId = PM.ProductId
		   LEFT JOIN [TCD].ProgramMaster PP ON AD.ProgramId = PP.ProgramId

		    WHERE MS.WasherId NOT IN (SELECT
					     w.WasherId
					 FROM TCD.MachineSetup AS ms1
					      INNER JOIN TCD.Washer AS w ON w.WasherId = ms1.WasherId
									AND ms1.EcoalabAccountNumber = w.EcoLabAccountNumber
					 WHERE (NULLIF(ms1.ControllerId, 0)IS NULL
					   AND w.WasherMode = 0)
					   OR MS1.IsPony = 1
					   )
				AND 
				CASE @Controller   
				 WHEN '' THEN 'TRUE'         
				 ELSE                                                      
				  CASE WHEN AD.ControllerId IN (SELECT Controller FROM @ControllerTable) THEN 'TRUE' END                                                      
				END='TRUE' 

				AND       
				CASE @Machine   
				WHEN '' THEN 'TRUE'         
				ELSE                                                      
				CASE WHEN AD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
				END='TRUE' 
				AND       

				CASE @machineGroup   
	   			WHEN '' THEN 'TRUE'         
				ELSE                                                      
				CASE WHEN AD.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable) THEN 'TRUE' END                                    
				END='TRUE' 
				AND    

				CASE @Formula   
	     		WHEN '' THEN 'TRUE'         
				ELSE                                                      
				CASE WHEN AD.ProgramId IN (SELECT Formula FROM @FormulaTable) AND AD.AlarmCode NOT IN (9000) THEN 'TRUE' END                                                      
				END='TRUE' 
				AND       

				CASE @MachineType   
				WHEN '' THEN 'TRUE'         
				ELSE                                                      
				cASE WHEN AD.GroupId IN (SELECT WG.WasherGroupId FROM [TCD].WasherGroup WG WHERE WG.WasherGroupTypeId IN (select MachineType from @MachineTypeTable)) THEN 'TRUE' END                                                      
				END='TRUE' 

				AND       
				CASE @FromDate                                                                                
				WHEN '' THEN Case WHEN MONTH(AD.StartDate) = @Month Then  'true' END                                                                                
				ELSE CASE WHEN AD.StartDate >= @FromDate and AD.StartDate<= @ToDate THEN 'true'END                                                        
				END='true'

				AND
				CASE @Alarm   
				WHEN '' THEN 'TRUE'         
				ELSE                                                      
				CASE WHEN AD.AlarmCode IN (SELECT Alarm FROM @AlarmsTable) THEN 'TRUE' END                                                      
				END='TRUE' 

				AND
				CASE @GroupId 
	   			WHEN '' THEN 'TRUE' 
				ELSE        
				CASE WHEN (AD.GroupId IN (@GroupId) AND 
				AD.MachineInternalId  IN (@MachineInternalId)) THEN 'TRUE' END                                                   
				END='TRUE' 
				AND

				CASE @MachineInternalId 
                    WHEN '' THEN 'TRUE' 
				ELSE        
				CASE WHEN (AD.GroupId IN (@GroupId) AND 
				AD.MachineInternalId  IN (@MachineInternalId)) THEN 'TRUE' END                                                   
				END='TRUE' 
				
			SELECT  
						AlarmCode,
						AlarmDescription,
						Controller,
						StartDate,  
						EndDate,
						SecDuration, 
						WasherNumber,  
						BatchId, 
						ValveNumber, 
						ChemicalName,
						InjectionNo,
						FormulaNo, 
						FormulaName, 
						DesiredValue, 
						MeasuredValue, 
						IsActiveStatus,
						COUNT(*) OVER() as TotalCount,
						ROW_NUMBER() OVER (ORDER BY  + @SortField + ' ' + @SortDirection) AS ROWNO
			INTO #AlarmRowTable
			FROM @AlarmTable

  			SELECT 		   	    
					C.AlarmCode,
	   				C.AlarmDescription,
    						C.StartDate,
						C.EndDate,
					(SELECT RIGHT('0' + CAST(DATEDIFF(SECOND,C.StartDate,C.EndDate) / 3600 AS VARCHAR),4) + ':' +
							RIGHT('0' + CAST((DATEDIFF(SECOND,C.StartDate,C.EndDate) / 60) % 60 AS VARCHAR),2)  + ':' +
							RIGHT('0' + CAST(DATEDIFF(SECOND,C.StartDate,C.EndDate) % 60 AS VARCHAR),2)) AS AlarmDuration,
						--SecDuration	AS AlarmDuration,
					C.Controller,
					C.WasherNumber,
					C.BatchID,
					C.ValveNumber,
					C.ChemicalName,
					C.InjectionNo,
					C.FormulaNo,
					C.FormulaName,
					C.DesiredValue,
					C.MeasuredValue, 
					C.IsActiveStatus,
					C.TotalCount,
					C.ROWNO
						INTO #AlarmTableOrder
			FROM #AlarmRowTable C 
			WHERE ROWNO BETWEEN @PageNo * @RecordsPerPage + 1 AND (@PageNo + 1) *  @RecordsPerPage  
			ORDER BY  @SortField + ' ' + @SortDirection

			SET @SQLStatement = 'SELECT * FROM #AlarmTableOrder ORDER BY ' + @SortField + ' ' + @SortDirection							   
	   		EXEC(@SQLStatement)

SET nocount OFF;
END
GO


IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[GetAlarmSummaryReport]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[GetAlarmSummaryReport] 
END 
GO 

--exec [TCD].[GetAlarmSummaryReport] @Corporate=N'',@Country=N'',@Region=N'',@EcolabAccountNumber=N'',@Controller=N'',@Machine=N'',
--@machineGroup=N'',@Formula=N'',@MachineType=N'',@Alarm=N'',@FromDate='2015-03-01 00:00:00',
--@ToDate='2015-03-31 12:00:00',@GroupId=N'',@MachineInternalId=N'',@SortColumnID=0,@SortDirection=N'aSC',@UserId=1,@PageNo=1 ,@RecordsPerPage=50



--exec [TCD].[GetAlarmSummaryReport] @Corporate=N'',@Country=N'',@Region=N'',@EcolabAccountNumber=N'',@Controller=N'',@Machine=N'',
--@machineGroup=N'',@Formula=N'',@MachineType=N'',@Alarm=N'',@FromDate='2015-03-01 00:00:00',
--@ToDate='2015-03-31 12:00:00',@GroupId=N'',@MachineInternalId=N'',@SortColumnID=0,@SortDirection=N'aSC',@UserId=1,@PageNo=1 ,@RecordsPerPage=50


CREATE PROCEDURE [TCD].[GetAlarmSummaryReport] (
										  @Corporate Varchar(max) = '',
										  @Country Varchar(max) = '',
										  @Region Varchar(max) = '',
										  @EcolabAccountNumber Nvarchar(25) = '',
										  @Controller Varchar(max) = '',
										  @Machine Varchar(max) = '', 
										  @machineGroup Varchar(max) = '',
										  @Formula Varchar(max) = '',
										  @MachineType Varchar(20)= '',
										  @Alarm Varchar(max) = '',
										  @FromDate Datetime = '',
										  @ToDate Datetime = '',
										  @GroupId Varchar(max) = '',
										  @MachineInternalId Varchar(max) = '',
										  @SortColumnID INT = NULL,
										  @SortDirection Varchar(100) = '',
										  @UserId INT = NULL,
										  @PageNo	INT	 = NULL,
										  @RecordsPerPage INT = NULL
										  
									   )
AS   
BEGIN   
SET nocount ON;   
DECLARE @ReportGenerated INT = 6

SET @FromDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@FromDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@FromDate AS time)) AS DateTime))
SET @ToDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@ToDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@ToDate AS time)) AS DateTime))

/* Inserting the record into Report History */
SET @PageNo = @PageNo-1
INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)
SELECT @EcolabAccountNumber,UM.UserId,
	  UM.LoginName,
	  GETUTCDATE(),
	  @ReportGenerated,
	  CASE WHEN @ReportGenerated = 6
		THEN 'Generated Report : AlarmSummaryReport' END
	  FROM TCD.UserMaster UM
	    WHERE	UM.EcolabAccountNumber =	@EcolabAccountNumber AND UM.UserId = @UserId

/* Completed the record insertion into Report History */


DECLARE @Month INT = MONTH(GETDATE()),
	   @SortField Varchar(100) = '',
	   @SummationInMin Int = NULL,
	   @SQLStatement varchar(max)

    SELECT @SortField =  CASE WHEN @SortColumnID = 13 THEN 'AlarmDescription'
						WHEN @SortColumnID = 131 THEN 'NumberOfAlarms'
						WHEN @SortColumnID = 247 THEN 'Controller'
						WHEN @SortColumnID = 248 THEN 'AlarmCode'
						WHEN @SortColumnID = 0 THEN 'AlarmCode' END


DECLARE @ControllerTable TABLE(Controller Varchar(100))
INSERT INTO @ControllerTable(Controller) EXEC [TCD].[charlistToTable] @Controller,','

DECLARE @MachineTable TABLE(Machine Varchar(100))
INSERT INTO @MachineTable(Machine) EXEC [TCD].[charlistToTable] @Machine,','

DECLARE @GroupMachineTable TABLE(GroupId INT,MachineInternalId INT)  
INSERT INTO @GroupMachineTable(GroupId,MachineInternalId)  
SELECT GroupId,MachineInternalId FROM TCD.MachineSetup MS 
									INNER JOIN TCD.Washer WS ON MS.WasherId = WS.WasherId WHERE WS.PlantWasherNumber IN (SELECT Machine FROM @MachineTable);

DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))
INSERT INTO @WasherGroupTable(MachineGroup) EXEC [TCD].[charlistToTable] @machineGroup,','

DECLARE @FormulaTable TABLE(Formula Varchar(100))
INSERT INTO @FormulaTable(Formula) EXEC [TCD].[charlistToTable] @Formula,','

DECLARE @AlarmsTable TABLE(Alarm Varchar(100))
INSERT INTO @AlarmsTable(Alarm) EXEC [TCD].[charlistToTable] @Alarm,','

DECLARE @GroupTable TABLE(GroupId Varchar(100))
INSERT INTO @GroupTable(GroupId) EXEC [TCD].[CharlistToTable] @GroupId,','

DECLARE @MachineInternalTable TABLE(MachineInternalId Varchar(100))
INSERT INTO @MachineInternalTable(MachineInternalId) EXEC [TCD].[CharlistToTable] @MachineInternalId,','

DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))
INSERT INTO @MachineTypeTable EXEC [TCD].[CharlistToTable] @MachineType,','

	  DECLARE @AlarmTable TABLE(
							 AlarmCode INT,
							 AlarmDescription NVarchar(2000),
							 Controller Nvarchar(100),
							 StartDate Datetime,
							 EndDate Datetime,
							 SecDuration INT
    						  )

INSERT INTO @AlarmTable (
							 AlarmCode ,
							 AlarmDescription ,
							 Controller ,
							 StartDate ,
							 EndDate ,
							 SecDuration 
    						  )
SELECT 
		  DISTINCT
			  AM.AlarmCode,
	   		  AM.Description,	
			  (SELECT cc.Name FROM [TCD].ConduitController CC  WHERE cc.ControllerId = AD.ControllerId) AS Controller,	 
			  AD.StartDate,
			  AD.EndDate,
			  DATEDIFF(SECOND,AD.StartDate,AD.EndDate)
	FROM [TCD].AlarmData AS AD
		   INNER JOIN [TCD].AlarmMaster AM ON AD.AlarmCode = AM.AlarmCode
		   LEFT JOIN [TCD].MachineSetup MS ON MS.WasherId = AD.MachineId
		   LEFT JOIN [TCD].ControllerEquipmentSetup CES ON AD.Valve = CES.ControllerEquipmentId AND AD.ControllerId = CES.ControllerId
		   LEFT JOIN [TCD].ProductMaster PM ON CES.ProductId = PM.ProductId
		   LEFT JOIN [TCD].ProgramMaster PP ON AD.ProgramId = PP.ProgramId

		   WHERE MS.WasherId NOT IN (SELECT
					     w.WasherId
					 FROM TCD.MachineSetup AS ms
					      INNER JOIN TCD.Washer AS w ON w.WasherId = ms.WasherId
									AND ms.EcoalabAccountNumber = w.EcoLabAccountNumber
					 WHERE (NULLIF(ms.ControllerId, 0)IS NULL
					   AND w.WasherMode = 0)
					   OR ms.IsPony = 1
					   ) 
				AND 
				CASE @Controller   
				 WHEN '' THEN 'TRUE'         
				 ELSE                                                      
				  CASE WHEN AD.ControllerId IN (SELECT Controller FROM @ControllerTable) THEN 'TRUE' END                                                      
				END='TRUE' 

				AND       
				CASE @Machine   
				WHEN '' THEN 'TRUE'         
				ELSE                                                      
				CASE WHEN AD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
				END='TRUE' 
				AND       

				CASE @machineGroup   
	   			WHEN '' THEN 'TRUE'         
				ELSE                                                      
				CASE WHEN AD.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable) THEN 'TRUE' END                                    
				END='TRUE' 
				AND    

				CASE @Formula   
	     		WHEN '' THEN 'TRUE'         
				ELSE                                                      
				CASE WHEN AD.ProgramId IN (SELECT Formula FROM @FormulaTable) THEN 'TRUE' END                                                      
				END='TRUE' 
				AND       

				CASE @MachineType   
				WHEN '' THEN 'TRUE'         
				ELSE                                                      
				CASE WHEN AD.GroupId IN (SELECT WG.WasherGroupId FROM [TCD].WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable)) THEN 'TRUE' END                                                      
				END='TRUE' 

				AND       
				CASE @FromDate                                                                                
				WHEN '' THEN Case WHEN MONTH(AD.StartDate) = @Month Then  'true' END                                                                                
				ELSE CASE WHEN AD.StartDate >= @FromDate and AD.StartDate<= @ToDate THEN 'true'END                                                        
				END='true'

				AND
				CASE @Alarm   
				WHEN '' THEN 'TRUE'         
				ELSE                                                      
				CASE WHEN AD.AlarmCode IN (SELECT Alarm FROM @AlarmsTable) THEN 'TRUE' END                                                      
				END='TRUE' 

				AND
				CASE @GroupId 
	   			WHEN '' THEN 'TRUE' 
				ELSE        
				CASE WHEN (AD.GroupId IN (@GroupId) AND 
				AD.MachineInternalId  IN (@MachineInternalId)) THEN 'TRUE' END                                                   
				END='TRUE' 
				AND

				CASE @MachineInternalId 
                    WHEN '' THEN 'TRUE' 
				ELSE        
				CASE WHEN (AD.GroupId IN (@GroupId) AND 
				AD.MachineInternalId  IN (@MachineInternalId)) THEN 'TRUE' END                                                   
				END='TRUE'; 
				
				SELECT  
						AlarmCode,
						AlarmDescription,
						Controller,  
						COUNT(1) AS NumberOfAlarms,
					     (SELECT RIGHT('0' + CAST(SUM(SecDuration) / 3600 AS VARCHAR),2) + ':' +
						  RIGHT('0' + CAST((SUM(SecDuration) / 60) % 60 AS VARCHAR),2)  + ':' +
						  RIGHT('0' + CAST(SUM(SecDuration) % 60 AS VARCHAR),2)) AS AlarmDuration,
						--StartDate,  
						--EndDate,
						--SecDuration,
						COUNT(*) OVER() as TotalCount,
						ROW_NUMBER() OVER (ORDER BY  + @SortField + ' ' + @SortDirection) AS ROWNO
			INTO #AlarmRowTable
			FROM @AlarmTable
			GROUP BY AlarmCode,AlarmDescription,Controller

		  SELECT	
			         C.AlarmCode,
				    C.AlarmDescription,
				    C.NumberOfAlarms,
				    C.AlarmDuration,
				    C.Controller,
				    C.TotalCount,
				    C.ROWNO 
				    INTO #AlarmTableOrder
			FROM #AlarmRowTable C 
			    WHERE ROWNO BETWEEN @PageNo * @RecordsPerPage + 1 AND (@PageNo + 1) *  @RecordsPerPage  
			    --GROUP BY C.AlarmCode,C.alarmDescription,
					  -- C.Controller,C.TotalCount,C.ROWNO
			
			SET @SQLStatement 
					   ='SELECT * FROM #AlarmTableOrder ORDER BY ' + @SortField + ' ' + @SortDirection

	   		EXEC(@SQLStatement)

DROP TABLE #AlarmTableOrder
SET nocount OFF;

END
GO


IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[ReportProductionDetails]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[ReportProductionDetails] 
END 
GO 

CREATE PROCEDURE [TCD].[ReportProductionDetails] 
--DECLARE
     @startdate datetime = '',
         @enddate datetime = '',
     @Viewtype Int = '',
     @Subview Int= '',
     @Drillvalue varchar(100)= '',
     @EcolabAccountNumber Nvarchar(25) = '',
     @MachineType VARCHAR(20)= '',
     @MachineGroup VARCHAR(MAX) = '',
     @Machine VARCHAR(MAX) = '',
     @EcolabCategory VARCHAR(MAX) = '',
     @ChainCategory VARCHAR(MAX) = '',
     @PlantFormula  VARCHAR(MAX) = '',
     @ChainFormula VARCHAR(MAX) = '',
     @Customer VARCHAR(MAX) = '',
     @SortColumnId int = 0,
     @SortDirection varchar(4) = '',
     @CurrencyCode varchar(3) = '',
     @UserId INT = NULL
AS   
BEGIN   
SET NOCOUNT ON; 

SET @startdate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@startdate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@startdate AS time)) AS DateTime))
SET @EndDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndDate AS time)) AS DateTime))

DECLARE @ReportGenerated INT = 6,
    @Month INT = MONTH(GETDATE()),@CorrectionVariable Decimal(18,2),@PlantTargetProduction decimal(18,2)
      --,@ShiftRuntime int,@NoShiftTotalRuntime INT,@TotaRuntime int

/* Inserting the record into Report History */

INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)
SELECT @EcolabAccountNumber,UM.UserId,
   UM.LoginName,
   GETUTCDATE(),
   @ReportGenerated,
   CASE WHEN @ReportGenerated = 6
  THEN 'Generated Report : Production Details Report' END
   FROM TCD.UserMaster UM
     WHERE UM.EcolabAccountNumber = @EcolabAccountNumber AND UM.UserId = @UserId

/* Completed the record insertion into Report History */ 

    -- Return Table set
    DECLARE @resultSet Table
    (
      ShiftId Int,
      DateRange varchar(100),
      TotalLoad Decimal(18,2) ,
      WasherEfficiency Decimal(18,2),
      PlantTargetLoad Decimal(18,2) ,
      StandardLoad Decimal(18,2) ,
      Numberofbatches INT,
      [ActualRunTime] [int] NULL,
      [TargetRunTime] [int] NULL,
      NumberofPieces  [int] NULL,
      Rewash [int] NULL,
      Viewtype varchar(100) NULL,
      Subview varchar(100) NULL,
      Id int NULL      
    )

    DECLARE @CorrectionFactor TABLE 
   (
    [ShiftId] [int] NULL,
    MachineId INT NULL,
    [ActualProduction] [int] NULL,
    [StandardProduction] [int] NULL,
    [PlantTargetProd] [int] NULL,
    [ActualRunTime] [int] NULL,
    [TargetRunTime] [int] NULL
   )
    
DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))
INSERT INTO @MachineTypeTable EXEC [TCD].[CharlistToTable] @MachineType,','

DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))
INSERT INTO @WasherGroupTable EXEC [TCD].[CharlistToTable] @machineGroup,','  

DECLARE @MachineTable TABLE(Machine Varchar(100))
INSERT INTO @MachineTable EXEC [TCD].[CharlistToTable] @Machine,','

DECLARE @EcolabCategoryTable TABLE(EcolabCategory Varchar(100))
INSERT INTO @EcolabCategoryTable EXEC [TCD].[CharlistToTable] @EcolabCategory,','

DECLARE @ChainCategoryTable TABLE(ChainCategory Varchar(100))
INSERT INTO @ChainCategoryTable EXEC [TCD].[CharlistToTable] @ChainCategory,','

DECLARE @PlantFormulaTable TABLE(PlantFormula Varchar(100))
INSERT INTO @PlantFormulaTable EXEC [TCD].[CharlistToTable] @PlantFormula,','

DECLARE @ChainFormulaTable TABLE(ChainFormula Varchar(100))
INSERT INTO @ChainFormulaTable EXEC [TCD].[CharlistToTable] @ChainFormula,','

DECLARE @CustomerTable TABLE(Customer Varchar(100))
INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','

INSERT INTO @CorrectionFactor
SELECT 
    PS.[ShiftId],
    SPD.[MachineId],
    ISNULL([TCD].[FnConsumptionOnMetrics](SUM(SPD.[ActualProduction]),'Weight',@UserId),0),
    --SUM(SPD.[ActualProduction]),
    ISNULL([TCD].[FnConsumptionOnMetrics](SUM(SPD.StandardProduction),'Weight',@UserId),0),
    --SUM(SPD.StandardProduction),
    ISNULL([TCD].[FnConsumptionOnMetrics](SUM(DISTINCT SPD.[PlantTargetProd]),'Weight',@UserId),0),
    --SUM(DISTINCT SPD.[PlantTargetProd]),
    SUM(SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0)),
    SUM(SPD.[TargetRunTime] + ISNULL(SPD.TargetTurnTime,0))
     FROM  TCD.ShiftProductionDataRollup SPD INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId
    WHERE 
       CASE @StartDate                                                                                
       WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
       ELSE CASE WHEN PS.[StartDateTime] >= @startdate  AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
       END='TRUE'
 
        GROUP BY MachineId,PS.ShiftId;

WITH CTE (PlantTargetProd) AS
(
SELECT SUM(DISTINCT SPD.[PlantTargetProd]) FROM @CorrectionFactor SPD GROUP BY ShiftId
)
SELECT @PlantTargetProduction = SUM(PlantTargetProd) FROM CTE;

WITH CTE (MachineId,PlantEfficiency)
AS
(
SELECT 
    MachineId,
    CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
        NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
        COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2))   
     FROM @CorrectionFactor SPD GROUP BY MachineId
)
    SELECT @CorrectionVariable = @PlantTargetProduction/SUM(PlantEfficiency) FROM CTE


  --  SELECT  @ShiftRuntime = SUM(A.ShiftTime)
  --   FROM
  --   (
  --  SELECT  SUM( DISTINCT DATEDIFF(Second,psd.StartDateTime,PSd.EndDateTime)) AS ShiftTime FROM TCD.ShiftProductionDataRollup spdr 
  --      INNER JOIN TCD.ProductionShiftData psd ON psd.ShiftId = spdr.ShiftId
  --   WHERE 
  -- CASE @StartDate                                                                                
  -- WHEN '' THEN Case WHEN MONTH(CAST(psd.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
  -- ELSE CASE WHEN psd.[StartDateTime] >= @startdate AND psd.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
  -- END='TRUE'
  -- AND psd.ShiftName <> 'No Shift'
  --  GROUP BY spdr.ShiftId
  --   ) A


  -- SELECT
  --@NoShiftTotalRuntime = SUM(SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0))
  --   FROM TCD.ShiftProductionDataRollup SPD INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId
  --  WHERE 
  --     CASE @StartDate                                                                                
  --     WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
  --     ELSE CASE WHEN PS.[StartDateTime] >= @startdate AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
  --     END='TRUE'
  -- AND PS.ShiftName = 'No Shift'

  --  SELECT @TotaRuntime = ISNULL(@ShiftRuntime,0) + ISNULL(@NoShiftTotalRuntime,0)

DECLARE @ProductionSummaryTable TABLE(
          [ShiftId] [int] NULL,
         [ShiftName] Varchar(100) NULL,
         RecordDate date, 
         [MachineId] [int] NULL,
         [ProgramMasterId] [int] NULL,
         [EcolabWasherId] [int] NULL,
         [ActualProduction] [int] NULL,
         [StandardProduction] [int] NULL,
         [NoOfLoads] [int] NULL,
         [LoadEfficiency] [decimal](18, 2) NULL,
         [TimeEfficiency] [decimal](18, 2) NULL,
         TotalEfficiency [decimal](18, 2) NULL,
         [PlantTargetProd] [int] NULL,
         [ActualRunTime] [int] NULL,
         [TargetRunTime] [int] NULL,
         EcolabTextileId int,
         ChainTextileId int,
         ChainProgaramId int,
         CustomerId int,
         NoOfPieces int,
         Rewash Int,
     [ShiftRunTime] [int] NULL
             )

    INSERT INTO @ProductionSummaryTable
    SELECT 
        PS.[ShiftId],
        PS.ShiftName,
        CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date),
        --CAST(PS.[StartDateTime] AS date),
        SPD.[MachineId],
        SPD.[ProgramMasterId],
        SPD.[EcolabWasherId],
        SPD.[ActualProduction],
        SPD.StandardProduction,
        SPD.[NoOfLoads],
        SPD.[LoadEfficiency],
        SPD.[TimeEfficiency],
        (SPD.[LoadEfficiency] * SPD.TimeEfficiency),
        SPD.[PlantTargetProd],
        SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0),
        SPD.[TargetRunTime] + ISNULL(SPD.TargetTurnTime,0),
        SPD.EcolabTextileId,
        SPD.ChainTextileId,
        SPD.ChainProgaramId,
        SPD.CustomerId,
        SPD.NoOfPieces,
        CAST((
        SELECT spdr.ActualProduction FROM TCD.ShiftProductionDataRollup spdr WHERE spdr.ShiftId = SPD.ShiftId AND spdr.MachineId = SPD.MachineId
        AND spdr.ProgramMasterId = SPD.ProgramMasterId AND spdr.ProgramMasterId IN (SELECT pm.ProgramId FROM TCD.ProgramMaster pm WHERE pm.Rewash = 1)
        ) AS decimal(18,2)),
    DATEDIFF(Second,ps.StartDateTime,PS.EndDateTime) +
    ISNULL((
    SELECT
   SUM(SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0))
     FROM TCD.ShiftProductionDataRollup SPD INNER JOIN TCD.ProductionShiftData PSD ON SPD.ShiftId = PSD.ShiftId
    WHERE 
   PSD.[StartDateTime] = PS.StartDateTime AND PSD.[StartDateTime] = PS.EndDateTime AND PS.ShiftName = 'No Shift'
    ),0)

        --CAST(((SELECT SUM(MR.VALUE) FROM TCD.ManualRewash MR WHERE SPD.ProgramMasterId = MR.FormulaId AND CAST(PS.StartDateTime AS date) = CAST(MR.RecordedDate AS date) GROUP BY CAST(MR.RecordedDate AS date),MR.FormulaId)) AS decimal(18,2))
    FROM  TCD.ShiftProductionDataRollup SPD INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId
	INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId 
    WHERE spd.MachineId NOT IN (SELECT SPD.MachineId FROM TCD.MachineSetup WHERE TCD.MachineSetup.IsPony = 1)
    AND
       CASE @StartDate                                                                                
       WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
       ELSE CASE WHEN PS.[StartDateTime] >= @startdate  AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
       END='TRUE'

     AND
       CASE @MachineType   
       WHEN '' THEN 'TRUE'         
       ELSE                                                      
       CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
       MS.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable))) THEN 'TRUE' END                                                      
       END='TRUE' 
    
    AND       

    CASE @machineGroup   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
    MS.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable)) THEN 'TRUE' END                                                      
    END='TRUE' 
    AND

    CASE @Machine   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
    END='TRUE' 
    AND
    
    CASE @EcolabCategory   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.EcolabTextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                      
    END='TRUE' 
     AND
    
    CASE @ChainCategory   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.ChainTextileId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END                                                      
    END='TRUE'
    AND

    CASE @PlantFormula   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                      
    END='TRUE'  
    AND
    
    CASE @ChainFormula   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.ChainTextileId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END                                                      
    END='TRUE'
    AND
    
    CASE @Customer   
    WHEN '' THEN 'TRUE'         
       ELSE                                                      
       CASE WHEN SPD.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                      
    END='TRUE' 

IF(@Viewtype = 3)
BEGIN

IF(@Subview = 12)
BEGIN

WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,TextileId)
    AS
    (
  SELECT 
    EC.CategoryName,
    SUM(SPD.ActualProduction),
    COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
    SUM(DISTINCT SPD.PlantTargetProd),
    SUM(SPD.StandardProduction),
    SUM([NoOfLoads]),
    SUM(DISTINCT SPD.ShiftRunTime),
    SUM(DISTINCT SPD.ShiftRunTime),
    SUM(SPD.NoOfPieces),
    SUM(SPD.Rewash),
    EC.TextileId
      FROM @ProductionSummaryTable SPD LEFT JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
    WHERE EC.CategoryName IS NOT NULL
    GROUP BY 
   EC.CategoryName,EC.TextileId,SPD.ShiftId
   )
   INSERT INTO @resultSet
   SELECT DISTINCT
	   0,
       DateRange,
       SUM(TotalLoad),
       SUM(WasherEfficiency),
       SUM(PlantTargetLoad),
       SUM(StandardLoad),
       SUM(Numberofbatches),
       SUM(ActualRunTime),
       SUM(TargetRuntime),
       SUM(NumberofPieces),
       SUM(Rewash)
       ,@Viewtype 
       ,@Subview
        ,TextileId
           FROM CTE
            WHERE TotalLoad IS NOT NULL
            GROUP BY DateRange,TextileId
   
END

    IF(@Subview = 17)

BEGIN
WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
    AS
    (
 SELECT 
   
    PM.Name,
    SUM(SPD.ActualProduction),
    COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
    SUM(DISTINCT SPD.PlantTargetProd),
    SUM(SPD.StandardProduction),
    SUM([NoOfLoads]),
    SUM(DISTINCT SPD.ShiftRunTime),
    SUM(DISTINCT SPD.ShiftRunTime),
    SUM(SPD.NoOfPieces),
    SUM(SPD.Rewash)
       FROM @ProductionSummaryTable SPD INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
         INNER JOIN TCD.ProgramMaster PM ON EC.TextileId = PM.EcolabTextileCategoryId AND SPD.ProgramMasterId = PM.ProgramId    
WHERE
    (
    CASE    
     WHEN @drillvalue='' THEN 'TRUE' 
     WHEN @drillvalue IS NULL THEN 'TRUE'  
     ELSE                                                    
      CASE WHEN EC.TextileId IN (@drillvalue) THEN 'TRUE' END            
     END='TRUE'
    ) AND PM.NAME IS NOT NULL
GROUP BY 
   PM.Name,SPD.ShiftId
   )
    INSERT INTO @resultSet
   SELECT DISTINCT
	   0,
       DateRange,
       SUM(TotalLoad),
       SUM(WasherEfficiency),
       SUM(PlantTargetLoad),
       SUM(StandardLoad),
       SUM(Numberofbatches),
       SUM(ActualRunTime),
       SUM(TargetRuntime),
       SUM(NumberofPieces),
       SUM(Rewash)
       ,@Viewtype 
       ,@Subview
        ,0
           FROM CTE
            WHERE TotalLoad IS NOT NULL
            GROUP BY DateRange
END

END

    -- ************************ By Textile Category View ************************************************
IF(@Viewtype = 4)

BEGIN 

IF(@Subview = 15)
BEGIN
WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
    AS
    (
 SELECT 
   
    CC.Name,
    SUM(SPD.ActualProduction),
    COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
    SUM(DISTINCT SPD.PlantTargetProd),
    SUM(SPD.StandardProduction),
    SUM([NoOfLoads]),
    SUM(DISTINCT SPD.ShiftRunTime),
    SUM(DISTINCT SPD.ShiftRunTime),
    SUM(SPD.NoOfPieces),
    SUM(SPD.Rewash)
        FROM @ProductionSummaryTable SPD LEFT JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
    WHERE CC.Name IS NOT NULL 
 GROUP BY 
   CC.Name,CC.TextileId,SPD.ShiftId
   )
    INSERT INTO @resultSet
   SELECT DISTINCT
	   0,
       DateRange,
       SUM(TotalLoad),
       SUM(WasherEfficiency),
       SUM(PlantTargetLoad),
       SUM(StandardLoad),
       SUM(Numberofbatches),
       SUM(ActualRunTime),
       SUM(TargetRuntime),
       SUM(NumberofPieces),
       SUM(Rewash)
       ,@Viewtype 
       ,@Subview
        ,0
           FROM CTE
            WHERE TotalLoad IS NOT NULL
            GROUP BY DateRange
END
  
IF(@Subview = 18)
BEGIN
WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
    AS
    (
 SELECT        
    PM.Name,
    SUM(SPD.ActualProduction),
    COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
    SUM(DISTINCT SPD.PlantTargetProd),
    SUM(SPD.StandardProduction),
    SUM([NoOfLoads]),
    SUM(DISTINCT SPD.ShiftRunTime),
    SUM(DISTINCT SPD.ShiftRunTime),
    SUM(SPD.NoOfPieces),
    SUM(SPD.Rewash)
       FROM @ProductionSummaryTable SPD INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
         INNER JOIN TCD.ProgramMaster PM ON CC.TextileId = PM.ChainTextileId AND SPD.ProgramMasterId = PM.ProgramId
    
WHERE
    (
    CASE    
     WHEN @drillvalue='' THEN 'TRUE' 
     WHEN @drillvalue IS NULL THEN 'TRUE'  
     ELSE                                                    
      CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END            
     END='TRUE'
    )
GROUP BY 
   PM.Name,SPD.ShiftId
   )
    INSERT INTO @resultSet
   SELECT DISTINCT
	   0,
       DateRange,
       SUM(TotalLoad),
       SUM(WasherEfficiency),
       SUM(PlantTargetLoad),
       SUM(StandardLoad),
       SUM(Numberofbatches),
       SUM(ActualRunTime),
       SUM(TargetRuntime),
       SUM(NumberofPieces),
       SUM(Rewash)
       ,@Viewtype 
       ,@Subview
        ,0
           FROM CTE
            WHERE TotalLoad IS NOT NULL
            GROUP BY DateRange
END

END

  -- ******************************** Timeline View ***************************************************
IF(@Viewtype = 1)

BEGIN

    ---- By TimeLine - Day View
    IF(@Subview = 5)
    BEGIN 
    INSERT INTO @resultSet
    SELECT DISTINCT
    0,
    SPD.ShiftName,
    SUM(SPD.ActualProduction),
    COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
    SUM(DISTINCT SPD.PlantTargetProd),
    SUM(SPD.StandardProduction),
    SUM([NoOfLoads]),
    SUM(DISTINCT SPD.ShiftRunTime),
    SUM(DISTINCT SPD.ShiftRunTime),
    SUM(SPD.NoOfPieces),
    SUM(SPD.Rewash)
    ,@Viewtype 
    ,@Subview
    ,0
     FROM @ProductionSummaryTable SPD
    GROUP BY 
    SPD.ShiftName
    END

     ---- By TimeLine - Week View
   IF (@Subview = 4)
   BEGIN
    WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
    AS
    (
    SELECT 
       CAST(RecordDate AS nvarchar(100)),
        SUM(SPD.ActualProduction),
        COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
        SUM(DISTINCT SPD.PlantTargetProd),
        SUM(SPD.StandardProduction),
        SUM([NoOfLoads]),
        SUM(DISTINCT SPD.ShiftRunTime),
        SUM(DISTINCT SPD.ShiftRunTime),
        SUM(SPD.NoOfPieces),
        SUM(SPD.Rewash)
      FROM @ProductionSummaryTable SPD
        GROUP BY DATEPART(weekday,RecordDate),RecordDate,SPD.ShiftId

    )
   INSERT INTO @resultSet
   SELECT DISTINCT
       0,
       DateRange,
      SUM(TotalLoad),
      SUM(WasherEfficiency),
       SUM(PlantTargetLoad),
       SUM(StandardLoad),
       SUM(Numberofbatches),
       SUM(ActualRunTime),
       SUM(TargetRuntime),
       SUM(NumberofPieces),
       SUM(Rewash)
       ,@Viewtype 
       ,@Subview
        ,0
           FROM CTE
            WHERE TotalLoad IS NOT NULL
            GROUP BY DateRange
  END
   ---- By TimeLine - Month View
    IF(@Subview = 3)
    BEGIN
    DECLARE @FirstDay date = (SELECT TOP 1 RecordDate FROM @ProductionSummaryTable ORDER BY RecordDate)
    DECLARE @LastDay date = (SELECT TOP 1 RecordDate FROM @ProductionSummaryTable ORDER BY RecordDate DESC)
    DECLARE @FirstSunday date = NULL,
    @LastSaturday date = NULL

    
    SELECT 
    @FirstSunday = CAST(DateAdd(dd, (8-DatePart(WEEKDAY, 
       DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)))%7, 
       DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)) AS DATE) 

     SELECT
      @LastSaturday = 
        DATEADD(dd,
            -DATEPART(WEEKDAY,
              DATEADD(dd, -DAY(DATEADD(month, 1, @LastDay)),
              DATEADD(month, 1, @LastDay))) ,
            DATEADD(dd, -DAY(DATEADD(MONTH, 1, @LastDay)), DATEADD(MONTH, 1, @LastDay)));

    WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
    AS
    (
    SELECT 
       
        CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,-1,@FirstSunday)) = 7 
       AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate < DATEADD(DD,-1,@FirstSunday)) = 0)
       THEN CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100))
       WHEN DATEADD(DD,-1,@FirstSunday) > CAST(GETDATE() AS DATE) 
       THEN
       CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @enddate, 101) AS nvarchar(100))
       ELSE
       CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) END As DateRange,
       SUM(SPD.ActualProduction),
          COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
           SUM(DISTINCT SPD.PlantTargetProd),
           SUM(SPD.StandardProduction),
           SUM([NoOfLoads]),
           SUM(DISTINCT SPD.ShiftRunTime),
           SUM(DISTINCT SPD.ShiftRunTime),
           SUM(SPD.NoOfPieces),
           SUM(SPD.Rewash)

         FROM @ProductionSummaryTable SPD
        WHERE RecordDate < @FirstSunday AND RecordDate >= @FirstDay
        GROUP BY SPD.ShiftId

        
        UNION ALL

  
        SELECT
        
        --CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100)) AS StartDate,
        --CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) AS EndDate,
          CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100))  + CHAR(13) + '-' +
         CASE WHEN CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) >
         CAST(Convert(varchar, DateAdd(dd, (1 - DatePart(dw, @enddate) + 1), @enddate), 101) AS nvarchar(100))
         THEN  CAST(Convert(varchar, DateAdd(dd, 1-1, @enddate), 101) AS nvarchar(100))
         ELSE CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) END
         As DateRange,
         SUM(SPD.ActualProduction),
           COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
           SUM(DISTINCT SPD.PlantTargetProd),
           SUM(SPD.StandardProduction),
           SUM([NoOfLoads]),
           SUM(DISTINCT SPD.ShiftRunTime),
           SUM(DISTINCT SPD.ShiftRunTime),
           SUM(SPD.NoOfPieces),
           SUM(SPD.Rewash)
        FROM @ProductionSummaryTable SPD
           WHERE RecordDate BETWEEN @FirstSunday AND @LastSaturday
        GROUP BY Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101),
         Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101),SPD.ShiftId
       
       UNION ALL

        SELECT 
         CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,1,@LastSaturday)) = 1 
        AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate > DATEADD(DD,1,@LastSaturday)) = 0)
        THEN 
        CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) 
        ELSE
       CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @LastDay, 101) AS nvarchar(100)) END   As DateRange,
       SUM(SPD.ActualProduction),
           COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
           SUM(DISTINCT SPD.PlantTargetProd),
           SUM(SPD.StandardProduction),
           SUM([NoOfLoads]),
           SUM(DISTINCT SPD.ShiftRunTime),
           SUM(DISTINCT SPD.ShiftRunTime),
           SUM(SPD.NoOfPieces),
           SUM(SPD.Rewash)
        FROM @ProductionSummaryTable SPD
        WHERE RecordDate > @LastSaturday AND RecordDate <= @LastDay 
        GROUP BY SPD.ShiftId
        )
        INSERT INTO @resultSet
        SELECT DISTINCT
        0,
        DateRange,
       SUM(TotalLoad),
       SUM(WasherEfficiency),
        SUM(PlantTargetLoad),
        SUM(StandardLoad),
        SUM(Numberofbatches),
        SUM(ActualRunTime),
        SUM(TargetRuntime),
        SUM(NumberofPieces),
        SUM(Rewash)
        ,@Viewtype 
        ,@Subview
         ,0
            FROM CTE
            WHERE TotalLoad IS NOT NULL
            GROUP BY DateRange

        END

    IF(@Subview = 2)
    BEGIN
    DECLARE @QuarterYear VARCHAR(100) = YEAR(@enddate);
    WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
    AS
    (
      SELECT 
        DATENAME(MONTH, RecordDate) + ' ' + @QuarterYear As DateRange,
        SUM(SPD.ActualProduction),
        COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
        SUM(DISTINCT SPD.PlantTargetProd),
        SUM(SPD.StandardProduction),
        SUM([NoOfLoads]),
        SUM(DISTINCT SPD.ShiftRunTime),
        SUM(DISTINCT SPD.ShiftRunTime),
        SUM(SPD.NoOfPieces),
        SUM(SPD.Rewash)
        FROM @ProductionSummaryTable SPD
        GROUP BY  DATEPART(MONTH, RecordDate),DATENAME(MONTH, RecordDate),SPD.ShiftId
    )
    INSERT INTO @resultSet
     SELECT DISTINCT
        0,
        DateRange,
       SUM(TotalLoad),
       SUM(WasherEfficiency),
        SUM(PlantTargetLoad),
        SUM(StandardLoad),
        SUM(Numberofbatches),
        SUM(ActualRunTime),
        SUM(TargetRuntime),
        SUM(NumberofPieces),
        SUM(Rewash)
        ,@Viewtype 
        ,@Subview
         ,0
            FROM CTE
            WHERE TotalLoad IS NOT NULL
            GROUP BY DateRange
    END   

    IF(@Subview = 1)
    BEGIN
    DECLARE @Year VARCHAR(100) = RIGHT(YEAR(@enddate),2);
    WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
    AS
    (
        SELECT 
        CASE 'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10))
           WHEN 'Q1' THEN 'Jan' + @Year + '- Mar' + @Year
           WHEN 'Q2' THEN 'Apr' + @Year + '- Jun' + @Year
           WHEN 'Q3' THEN 'Jul' + @Year + '-Sep' + @Year
           WHEN 'Q4' THEN 'Oct' + @Year + '- Dec'+ @Year
        END AS DateRange,
        SUM(SPD.ActualProduction),
        COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
        SUM(DISTINCT SPD.PlantTargetProd),
        SUM(SPD.StandardProduction),
        SUM([NoOfLoads]),
        SUM(DISTINCT SPD.ShiftRunTime),
        SUM(DISTINCT SPD.ShiftRunTime),
        SUM(SPD.NoOfPieces),
        SUM(SPD.Rewash)
         FROM @ProductionSummaryTable SPD
         GROUP BY DATEPART(QUARTER, RecordDate),SPD.ShiftId

    )

    INSERT INTO @resultSet
    SELECT DISTINCT
        0,
        DateRange,
       SUM(TotalLoad),
       SUM(WasherEfficiency),
        SUM(PlantTargetLoad),
        SUM(StandardLoad),
        SUM(Numberofbatches),
        SUM(ActualRunTime),
        SUM(TargetRuntime),
        SUM(NumberofPieces),
        SUM(Rewash)
        ,@Viewtype 
        ,@Subview
         ,0
            FROM CTE
            WHERE TotalLoad IS NOT NULL
            GROUP BY DateRange

    END
    END

    -- ******************************** Location View ***************************************************
    IF(@Viewtype = 2)
    BEGIN

    IF(@Subview = 9)
    BEGIN

     WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,WasherGroupId)
    AS
    (
     SELECT 
        --SPD.MachineId,
        WG.WasherGroupName,
        SUM(SPD.ActualProduction),
        CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
        NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
        COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
        SUM(DISTINCT SPD.PlantTargetProd),
        SUM(SPD.StandardProduction),
        SUM([NoOfLoads]),
        SUM(DISTINCT SPD.ShiftRunTime),
        SUM(DISTINCT SPD.ShiftRunTime),
        SUM(SPD.NoOfPieces),
        SUM(SPD.Rewash),
        WG.WasherGroupId
      FROM @ProductionSummaryTable SPD LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId
             LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId 
        GROUP BY WG.WasherGroupName,WG.WasherGroupId,SPD.ShiftId--,SPD.MachineId

    )

     INSERT INTO @resultSet
     SELECT DISTINCT
                0,
                DateRange,
                SUM(TotalLoad),
                SUM(WasherEfficiency),
			 @PlantTargetProduction,
                SUM(StandardLoad),
                SUM(Numberofbatches),
                SUM(ActualRunTime),
                SUM(TargetRuntime),
                SUM(NumberofPieces),
                SUM(Rewash)
                ,@Viewtype 
                ,@Subview
                ,WasherGroupId
        FROM CTE
            WHERE TotalLoad IS NOT NULL
            GROUP BY DateRange,WasherGroupId
     END

       IF(@Subview = 10)
    BEGIN

     WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
    AS
    (
    SELECT         
        cast( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName MachineName,
        SUM(SPD.ActualProduction),
        CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
        NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
        COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)) ,
        SUM(DISTINCT SPD.PlantTargetProd),
        SUM(SPD.StandardProduction),
        SUM([NoOfLoads]),
        SUM(DISTINCT SPD.ShiftRunTime),
        SUM(DISTINCT SPD.ShiftRunTime),
        SUM(SPD.NoOfPieces),
        SUM(SPD.Rewash)
        
     FROM @ProductionSummaryTable SPD 
	 LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId
	 LEFT JOIN TCD.Washer w on MS.WasherId=w.WasherId
     LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId 
    WHERE 
      (
       CASE @drillvalue   
           WHEN '' THEN 'TRUE'         
           ELSE                                                    
            CASE WHEN WG.WasherGroupId IN (@drillvalue) THEN 'TRUE' END            
           END='TRUE'
      )
     GROUP BY cast( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName,SPD.ShiftId

    )

     INSERT INTO @resultSet
      SELECT DISTINCT
                0,
                DateRange,
                SUM(TotalLoad),
                SUM(WasherEfficiency),
                @PlantTargetProduction,
                SUM(StandardLoad),
                SUM(Numberofbatches),
                SUM(ActualRunTime),
                SUM(TargetRuntime),
                SUM(NumberofPieces),
                SUM(Rewash)
                ,@Viewtype 
                ,@Subview
                ,0
        FROM CTE
            WHERE TotalLoad IS NOT NULL
            GROUP BY DateRange
    END
    END

    -- ******************************** ChainCategory View **********************************************
    IF(@Viewtype = 5)
    BEGIN
    IF(@Subview = 16)
    BEGIN
 -- ToDo : Change this part for chaincategory
      WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,textileId)
	   AS
	   (
     SELECT    
    CC.NAME,
    SUM(SPD.ActualProduction),
    COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
    SUM(DISTINCT SPD.PlantTargetProd),
    SUM(SPD.StandardProduction),
    SUM([NoOfLoads]),
    SUM(DISTINCT SPD.ShiftRunTime),
    SUM(DISTINCT SPD.ShiftRunTime),
    SUM(SPD.NoOfPieces),
    SUM(SPD.Rewash),
	cc.TextileId
       FROM
     @ProductionSummaryTable SPD
    INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
     INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = PM.PlantProgramId
     INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId 
    Group by 
   CC.Name,cc.TextileId,SPD.ShiftId
   )
    INSERT INTO @resultSet
      SELECT DISTINCT
                0,
                DateRange,
                SUM(TotalLoad),
                SUM(WasherEfficiency),
                @PlantTargetProduction,
                SUM(StandardLoad),
                SUM(Numberofbatches),
                SUM(ActualRunTime),
                SUM(TargetRuntime),
                SUM(NumberofPieces),
                SUM(Rewash)
                ,@Viewtype 
                ,@Subview
                ,textileId
        FROM CTE
            WHERE TotalLoad IS NOT NULL
            GROUP BY DateRange,textileId
    END

    
    IF(@Subview = 19)
    BEGIN
 -- ToDo : Change this part for chaincategory
     WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
	   AS
	   (
     SELECT  
    PCP.PlantProgramName,
    SUM(SPD.ActualProduction),
    COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
    SUM(DISTINCT SPD.PlantTargetProd),
    SUM(SPD.StandardProduction),
    SUM([NoOfLoads]),
    SUM(DISTINCT SPD.ShiftRunTime),
    SUM(DISTINCT SPD.ShiftRunTime),
    SUM(SPD.NoOfPieces),
    SUM(SPD.Rewash)
      FROM @ProductionSummaryTable SPD
    INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
     INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = PM.PlantProgramId
     INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId 
     WHERE
    (
   CASE @drillvalue   
       WHEN '' THEN 'TRUE'         
       ELSE                                                    
       CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END            
       END='TRUE'
  )
 Group by 
   PCP.PlantProgramName,PCP.PlantProgramId,SPD.ShiftId
   )
   INSERT INTO @resultSet
      SELECT DISTINCT
                0,
                DateRange,
                SUM(TotalLoad),
                SUM(WasherEfficiency),
                @PlantTargetProduction,
                SUM(StandardLoad),
                SUM(Numberofbatches),
                SUM(ActualRunTime),
                SUM(TargetRuntime),
                SUM(NumberofPieces),
                SUM(Rewash)
                ,@Viewtype 
                ,@Subview
                ,0
        FROM CTE
            WHERE TotalLoad IS NOT NULL
            GROUP BY DateRange
END

END

    -- ******************************** Customer View ***************************************************
IF(@Viewtype = 6)
BEGIN
 WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
	   AS
	   (
    SELECT 
    PC.CustomerName,
    SUM(SPD.ActualProduction),
    COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
    SUM(DISTINCT SPD.PlantTargetProd),
    SUM(SPD.StandardProduction),
    SUM([NoOfLoads]),
    SUM(DISTINCT SPD.ShiftRunTime),
    SUM(DISTINCT SPD.ShiftRunTime),
    SUM(SPD.NoOfPieces),
    SUM(SPD.Rewash)
    FROM @ProductionSummaryTable SPD  INNER JOIN TCD.PlantCustomer PC on PC.CustomerId = SPD.CustomerId
    GROUP BY 
   PC.CustomerName,SPD.ShiftId
   )
   INSERT INTO @resultSet
      SELECT DISTINCT
                0,
                DateRange,
                SUM(TotalLoad),
                SUM(WasherEfficiency),
                @PlantTargetProduction,
                SUM(StandardLoad),
                SUM(Numberofbatches),
                SUM(ActualRunTime),
                SUM(TargetRuntime),
                SUM(NumberofPieces),
                SUM(Rewash)
                ,@Viewtype 
                ,@Subview
                ,0
        FROM CTE
            WHERE TotalLoad IS NOT NULL
            GROUP BY DateRange
END

-- ******************************** Formula View ****************************************************
IF(@Viewtype = 7)
BEGIN
 WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
	   AS
	   (
 SELECT 
    PM.Name,
    SUM(SPD.ActualProduction),
   COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
    SUM(DISTINCT SPD.PlantTargetProd),
    SUM(SPD.StandardProduction),
    SUM([NoOfLoads]),
    SUM(DISTINCT SPD.ShiftRunTime),
    SUM(DISTINCT SPD.ShiftRunTime),
    SUM(SPD.NoOfPieces),
    SUM(SPD.Rewash)
    FROM @ProductionSummaryTable SPD 
    INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
    Group by 
    PM.Name,SPD.ShiftId
    )
    INSERT INTO @resultSet
      SELECT DISTINCT
                0,
                DateRange,
                SUM(TotalLoad),
                SUM(WasherEfficiency),
                @PlantTargetProduction,
                SUM(StandardLoad),
                SUM(Numberofbatches),
                SUM(ActualRunTime),
                SUM(TargetRuntime),
                SUM(NumberofPieces),
                SUM(Rewash)
                ,@Viewtype 
                ,@Subview
                ,0
        FROM CTE
            WHERE TotalLoad IS NOT NULL
            GROUP BY DateRange
    END


--- ********* Return result ********************

    SELECT DISTINCT
      ShiftId,
      DateRange,
      ISNULL([TCD].[FnConsumptionOnMetrics](TotalLoad,'Weight',@UserId),0),
      --ISNULL(TotalLoad,0),
      ISNULL([TCD].[FnConsumptionOnMetrics](WasherEfficiency,'Weight',@UserId),0),
      --ISNULL(WasherEfficiency,0),
      ISNULL([TCD].[FnConsumptionOnMetrics](PlantTargetLoad,'Weight',@UserId),0),
      --ISNULL(PlantTargetLoad,0),
       ISNULL([TCD].[FnConsumptionOnMetrics](StandardLoad,'Weight',@UserId),0),
      --ISNULL(StandardLoad,0),
      ISNULL(Numberofbatches,0),
      ISNULL(ActualRunTime,0),
      ISNULL(TargetRunTime,0),
      ISNULL(NumberofPieces,0),
      ISNULL(Rewash,0),
      Viewtype,
      Subview ,
      Id,
      @CorrectionVariable
      FROM 
        @resultSet 
    
END
GO



IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[ReportProductionSummary]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[ReportProductionSummary] 
END 
GO 

CREATE PROCEDURE [TCD].[ReportProductionSummary] 
--DECLARE 
     @startdate datetime = '',
         @enddate datetime = '',
     @Viewtype varchar(30) = '',
     @Subview varchar(30)= '',
     @Drillvalue varchar(100)= '',
     @EcolabAccountNumber Nvarchar(25) = '',
     @MachineType VARCHAR(20)= '',
     @MachineGroup VARCHAR(MAX) = '',
     @Machine VARCHAR(MAX) = '',
     @EcolabCategory VARCHAR(MAX) = '',
     @ChainCategory VARCHAR(MAX) = '',
     @PlantFormula  VARCHAR(MAX) = '',
     @ChainFormula VARCHAR(MAX) = '',
     @Customer VARCHAR(MAX) = '',
     @SortColumnId int = 0,
     @SortDirection varchar(4) = '',
     @CurrencyCode varchar(3) = '',
     @UserId INT = NULL
AS   
BEGIN   
SET NOCOUNT ON;  

SET @startdate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@startdate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@startdate AS time)) AS DateTime))
SET @EndDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndDate AS time)) AS DateTime))
 
DECLARE @ReportGenerated INT = 6,
    @Month INT = MONTH(GETDATE()),@CorrectionVariable Decimal(18,2),@PlantTargetProduction decimal(18,2)
    --,@ShiftRuntime int,@NoShiftTotalRuntime INT,@TotaRuntime int

/* Inserting the record into Report History */

INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)
SELECT @EcolabAccountNumber,UM.UserId,
   UM.LoginName,
   GETUTCDATE(),
   @ReportGenerated,
   CASE WHEN @ReportGenerated = 6
  THEN 'Generated Report : Production Summary Report' END
   FROM TCD.UserMaster UM
     WHERE UM.EcolabAccountNumber = @EcolabAccountNumber AND UM.UserId = @UserId

/* Completed the record insertion into Report History */ 

    -- Return Table set
    DECLARE @resultSet Table
    (
      ShiftId Int,
      DateRange varchar(100),
      TotalLoad Decimal(18,2) ,
      WasherEfficiency Decimal(18,2),
      PlantTargetLoad Decimal(18,2) ,
      Numberofbatches INT,
      [ActualRunTime] [int] NULL,
      [TargetRunTime] [int] NULL,
      Viewtype varchar(100) NULL,
      Subview varchar(100) NULL,
      Id int NULL      
    )
    DECLARE @CorrectionFactor TABLE 
   (
    [ShiftId] [int] NULL,
    MachineId INT NULL,
    [ActualProduction] [int] NULL,
    [StandardProduction] [int] NULL,
    [PlantTargetProd] [int] NULL,
    [ActualRunTime] [int] NULL,
    [TargetRunTime] [int] NULL
   )

DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))
INSERT INTO @MachineTypeTable EXEC [TCD].[CharlistToTable] @MachineType,','

DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))
INSERT INTO @WasherGroupTable EXEC [TCD].[CharlistToTable] @machineGroup,','  

DECLARE @MachineTable TABLE(Machine Varchar(100))
INSERT INTO @MachineTable EXEC [TCD].[CharlistToTable] @Machine,','

DECLARE @EcolabCategoryTable TABLE(EcolabCategory Varchar(100))
INSERT INTO @EcolabCategoryTable EXEC [TCD].[CharlistToTable] @EcolabCategory,','

DECLARE @ChainCategoryTable TABLE(ChainCategory Varchar(100))
INSERT INTO @ChainCategoryTable EXEC [TCD].[CharlistToTable] @ChainCategory,','

DECLARE @PlantFormulaTable TABLE(PlantFormula Varchar(100))
INSERT INTO @PlantFormulaTable EXEC [TCD].[CharlistToTable] @PlantFormula,','

DECLARE @ChainFormulaTable TABLE(ChainFormula Varchar(100))
INSERT INTO @ChainFormulaTable EXEC [TCD].[CharlistToTable] @ChainFormula,','

DECLARE @CustomerTable TABLE(Customer Varchar(100))
INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','

INSERT INTO @CorrectionFactor
SELECT 
    PS.[ShiftId],
    SPD.[MachineId],
    ISNULL([TCD].[FnConsumptionOnMetrics](SUM(SPD.[ActualProduction]),'Weight',@UserId),0),
    --SUM(SPD.[ActualProduction]),
    ISNULL([TCD].[FnConsumptionOnMetrics](SUM(SPD.StandardProduction),'Weight',@UserId),0),
    --SUM(SPD.StandardProduction),
    ISNULL([TCD].[FnConsumptionOnMetrics](SUM(DISTINCT SPD.[PlantTargetProd]),'Weight',@UserId),0),
    --SUM(DISTINCT SPD.[PlantTargetProd]),
    SUM(SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0)),
    SUM(SPD.[TargetRunTime] + ISNULL(SPD.TargetTurnTime,0))
     FROM  TCD.ShiftProductionDataRollup SPD INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId
	 INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId 
    WHERE 
       CASE @StartDate                                                                                
       WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
       ELSE CASE WHEN PS.[StartDateTime] >= @startdate  AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
       END='TRUE'
 
        GROUP BY MachineId,PS.ShiftId;

WITH CTE (PlantTargetProd) AS
(
SELECT SUM(DISTINCT SPD.[PlantTargetProd]) FROM @CorrectionFactor SPD GROUP BY ShiftId
)
SELECT @PlantTargetProduction = SUM(PlantTargetProd) FROM CTE;


WITH CTE (MachineId,PlantEfficiency)
AS
(
SELECT 
    MachineId,
    CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
        NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
        COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2))   
     FROM @CorrectionFactor SPD GROUP BY MachineId
)
    SELECT @CorrectionVariable = @PlantTargetProduction/SUM(PlantEfficiency) FROM CTE

   -- SELECT  @ShiftRuntime = SUM(A.ShiftTime)
   --  FROM
   --  (
   -- SELECT  SUM( DISTINCT DATEDIFF(Second,psd.StartDateTime,PSd.EndDateTime)) AS ShiftTime FROM TCD.ShiftProductionDataRollup spdr 
   --     INNER JOIN TCD.ProductionShiftData psd ON psd.ShiftId = spdr.ShiftId
   --  WHERE 
   --CASE @StartDate                                                                                
   --WHEN '' THEN Case WHEN MONTH(CAST(psd.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
   --ELSE CASE WHEN psd.[StartDateTime] >= @startdate AND psd.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
   --END='TRUE'
   --AND psd.ShiftName <> 'No Shift'
   -- GROUP BY spdr.ShiftId
   --  ) A

  --  SELECT
  --@NoShiftTotalRuntime = SUM(SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0))
  --   FROM TCD.ShiftProductionDataRollup SPD INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId
  --  WHERE 
  --     CASE @StartDate                                                                                
  --     WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
  --     ELSE CASE WHEN PS.[StartDateTime] >= @startdate AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
  --     END='TRUE'
  -- AND PS.ShiftName = 'No Shift'

  --  SELECT @TotaRuntime = ISNULL(@ShiftRuntime,0) + ISNULL(@NoShiftTotalRuntime,0)
    

DECLARE @ProductionSummaryTable TABLE(
          [ShiftId] [int] NULL,
         [ShiftName] Varchar(100) NULL,
         RecordDate date, 
         [StartDateTime] [datetime] NULL,
         [EndDateTime] [datetime] NULL,
         [MachineId] [int] NULL,
         [EcolabWasherId] [int] NULL,
         [ActualProduction] [int] NULL,
         [StandardProduction] [int] NULL,
         [NoOfLoads] [int] NULL,
         [LoadEfficiency] [decimal](18, 2) NULL,
         [TimeEfficiency] [decimal](18, 2) NULL,
         TotalEfficiency [decimal](18, 2) NULL,
         [PlantTargetProd] [int] NULL,
         [ActualRunTime] [int] NULL,
         [TargetRunTime] [int] NULL,
     [ShiftRunTime] [int] NULL
             )
INSERT INTO @ProductionSummaryTable
    SELECT 
        SPD.[ShiftId],
        PS.ShiftName,
        CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date),
        DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]),
        DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[EndDateTime]),
        --CAST(PS.[StartDateTime] AS date),
        --PS.[StartDateTime],
        --PS.[EndDateTime],
        SPD.[MachineId],
        SPD.[EcolabWasherId],
        SPD.[ActualProduction],
        SPD.StandardProduction,
        SPD.[NoOfLoads],
        SPD.[LoadEfficiency],
        SPD.[TimeEfficiency],
        (SPD.[LoadEfficiency] * SPD.TimeEfficiency),
        SPD.[PlantTargetProd],
        SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0),
        SPD.[TargetRunTime] + ISNULL(SPD.TargetTurnTime,0),
    DATEDIFF(Second,ps.StartDateTime,PS.EndDateTime) +
    ISNULL((
    SELECT
   SUM(SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0))
     FROM TCD.ShiftProductionDataRollup SPD INNER JOIN TCD.ProductionShiftData PSD ON SPD.ShiftId = PSD.ShiftId
	 INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId 
    WHERE 
   PSD.[StartDateTime] = PS.StartDateTime AND PSD.[StartDateTime] = PS.EndDateTime AND PS.ShiftName = 'No Shift'
    ),0)
    

    FROM TCD.ShiftProductionDataRollup SPD INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId
	INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
    WHERE spd.MachineId NOT IN (SELECT SPD.MachineId FROM TCD.MachineSetup WHERE TCD.MachineSetup.IsPony = 1)
    AND
       CASE @StartDate                                                                                
       WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
       ELSE CASE WHEN PS.[StartDateTime] >= @startdate AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
       END='TRUE'

     AND
       CASE @MachineType   
       WHEN '' THEN 'TRUE'         
       ELSE                                                      
       CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
       MS.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable))) THEN 'TRUE' END                                                      
       END='TRUE' 
    
    AND       

    CASE @machineGroup   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
    MS.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable)) THEN 'TRUE' END                                                      
    END='TRUE' 
    AND

    CASE @Machine   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
    END='TRUE' 
    AND
    
    CASE @EcolabCategory   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.EcolabTextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                      
    END='TRUE' 
     AND
    
    CASE @ChainCategory   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.ChainTextileId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END                                                      
    END='TRUE'
    AND

    CASE @PlantFormula   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                      
    END='TRUE'  
    AND
    
    CASE @ChainFormula   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.ChainTextileId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END                                                      
    END='TRUE'
    AND
    
    CASE @Customer   
    WHEN '' THEN 'TRUE'         
       ELSE                                                      
       CASE WHEN SPD.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                      
    END='TRUE' 

    IF(@Viewtype = 1)
    BEGIN
       ---- By TimeLine - Day View-------------

    IF(@Subview = 5)
    BEGIN
    INSERT INTO @resultSet
    SELECT 
        0,
        SPD.ShiftName,
        SUM(SPD.ActualProduction),
        COALESCE(SUM(SPD.ActualProduction)/ 
        NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),
        SUM(DISTINCT SPD.PlantTargetProd),
        SUM([NoOfLoads]),
        SUM(DISTINCT SPD.ShiftRunTime),
        SUM(DISTINCT SPD.ShiftRunTime)
        ,@Viewtype 
        ,@Subview
     ,0
        FROM @ProductionSummaryTable SPD
    GROUP BY 
    SPD.ShiftName
    END

    ---- By TimeLine - Week View
    IF (@Subview = 4)
    BEGIN
    WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime)
    AS
    (
      SELECT 
         CAST(RecordDate AS nvarchar(100)),
        SUM(SPD.ActualProduction),
       COALESCE(SUM(SPD.ActualProduction)/ 
        NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),
        SUM(DISTINCT SPD.PlantTargetProd),
        SUM([NoOfLoads]),
        SUM(DISTINCT SPD.ShiftRunTime),
        SUM(DISTINCT SPD.ShiftRunTime)
            FROM @ProductionSummaryTable SPD
         GROUP BY DATEPART(weekday,RecordDate),RecordDate,SPD.ShiftId  
    )

    INSERT INTO @resultSet
        SELECT  
             0, 
             DateRange,
             SUM(TotalLoad),
             SUM(TotalEfficiency),
             SUM(PlantTargetLoad),
             SUM(Numberofbatches),
             SUM(ActualRunTime),
             SUM(TargetRuntime)
             ,@Viewtype 
             ,@Subview
              ,0
         FROM CTE 
            WHERE TotalLoad IS NOT NULL
        GROUP BY DateRange
    END

    ---- By TimeLine - Month View
    IF(@Subview = 3)
    BEGIN
     

    DECLARE @FirstDay date = (SELECT TOP 1 RecordDate FROM @ProductionSummaryTable ORDER BY RecordDate)
    DECLARE @LastDay date = (SELECT TOP 1 RecordDate FROM @ProductionSummaryTable ORDER BY RecordDate DESC)
    DECLARE @FirstSunday date = NULL,
    @LastSaturday date = NULL

    
    SELECT 
    @FirstSunday = CAST(DateAdd(dd, (8-DatePart(WEEKDAY, 
       DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)))%7, 
       DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)) AS DATE) 

     SELECT
      @LastSaturday = 
        DATEADD(dd,
            -DATEPART(WEEKDAY,
              DATEADD(dd, -DAY(DATEADD(month, 1, @LastDay)),
              DATEADD(month, 1, @LastDay))) ,
            DATEADD(dd, -DAY(DATEADD(MONTH, 1, @LastDay)), DATEADD(MONTH, 1, @LastDay)));
    
    WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime)
    AS
    (
    SELECT 
       
       CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,-1,@FirstSunday)) = 7 
       AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate < DATEADD(DD,-1,@FirstSunday)) = 0)
       THEN CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100))
       WHEN DATEADD(DD,-1,@FirstSunday) > CAST(GETDATE() AS DATE) 
       THEN
       CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @enddate, 101) AS nvarchar(100))
       ELSE
       CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) END As DateRange,
       SUM(SPD.ActualProduction),
        COALESCE(SUM(SPD.ActualProduction)/ 
        NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),
        SUM(DISTINCT SPD.PlantTargetProd),
        SUM([NoOfLoads]),
        SUM(DISTINCT SPD.ShiftRunTime),
        SUM(DISTINCT SPD.ShiftRunTime)
        FROM @ProductionSummaryTable SPD
        WHERE RecordDate < @FirstSunday AND RecordDate >= @FirstDay 
        GROUP BY SPD.ShiftId

        
        UNION ALL

  
        SELECT 
       
        --CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100)) AS StartDate,
        --CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) AS EndDate,
          CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100))  + CHAR(13) + '-' +
         CASE WHEN CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) >
         CAST(Convert(varchar, DateAdd(dd, (1 - DatePart(dw, @enddate) + 1), @enddate), 101) AS nvarchar(100))
         THEN  CAST(Convert(varchar, DateAdd(dd, 1-1, @enddate), 101) AS nvarchar(100))
         ELSE CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) END
         As DateRange,
        SUM(SPD.ActualProduction),
        COALESCE(SUM(SPD.ActualProduction)/ 
        NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),
        SUM(DISTINCT SPD.PlantTargetProd),
        SUM([NoOfLoads]),
        SUM(DISTINCT SPD.ShiftRunTime),
        SUM(DISTINCT SPD.ShiftRunTime)
        FROM @ProductionSummaryTable SPD
           WHERE RecordDate BETWEEN @FirstSunday AND @LastSaturday
        GROUP BY Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101),
         Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101),SPD.ShiftId
       
       UNION ALL

        SELECT 
       
        CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,1,@LastSaturday)) = 1 
        AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate > DATEADD(DD,1,@LastSaturday)) = 0)
        THEN 
        CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) 
        ELSE
       CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @LastDay, 101) AS nvarchar(100)) END   As DateRange,
        SUM(SPD.ActualProduction),
        COALESCE(SUM(SPD.ActualProduction)/ 
        NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),
        SUM(DISTINCT SPD.PlantTargetProd),
        SUM([NoOfLoads]),
        SUM(DISTINCT SPD.ShiftRunTime),
        SUM(DISTINCT SPD.ShiftRunTime)
        FROM @ProductionSummaryTable SPD
        WHERE RecordDate > @LastSaturday AND RecordDate <= @LastDay GROUP BY SPD.ShiftId
        )
        INSERT INTO @resultSet
         SELECT  
         0, 
         DateRange,
         SUM(TotalLoad),
         SUM(TotalEfficiency),
         SUM(PlantTargetLoad),
         SUM(Numberofbatches),
         SUM(ActualRunTime),
         SUM(TargetRuntime)
         ,@Viewtype 
         ,@Subview
          ,0
         FROM CTE 
            WHERE TotalLoad IS NOT NULL
        GROUP BY DateRange

        END

    IF(@Subview = 2)
    BEGIN
    DECLARE @QuarterYear VARCHAR(100) = YEAR(@enddate);
    WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime)
    AS
    (
        SELECT        
        DATENAME(MONTH, RecordDate) + ' ' + @QuarterYear As DateRange,
        SUM(SPD.ActualProduction),
        COALESCE(SUM(SPD.ActualProduction)/ 
        NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),
        SUM(DISTINCT SPD.PlantTargetProd),
        SUM([NoOfLoads]),
        SUM(DISTINCT SPD.ShiftRunTime),
        SUM(DISTINCT SPD.ShiftRunTime)
        FROM @ProductionSummaryTable SPD
        GROUP BY  DATEPART(MONTH, RecordDate),DATENAME(MONTH, RecordDate),SPD.ShiftId

    )
    INSERT INTO @resultSet
    SELECT  
              0, 
              DateRange,
              SUM(TotalLoad),
              SUM(TotalEfficiency),
              SUM(PlantTargetLoad),
              SUM(Numberofbatches),
              SUM(ActualRunTime),
              SUM(TargetRuntime)
              ,@Viewtype 
              ,@Subview
               ,0
         FROM CTE 
            WHERE TotalLoad IS NOT NULL
        GROUP BY DateRange
    END   

    IF(@Subview = 1)
    BEGIN
    DECLARE @Year VARCHAR(100) = RIGHT(YEAR(@enddate),2);
    WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime)
    AS
    (
        SELECT 
       CASE 'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10))
               WHEN 'Q1' THEN 'Jan' + @Year + '- Mar' + @Year
               WHEN 'Q2' THEN 'Apr' + @Year + '- Jun' + @Year
               WHEN 'Q3' THEN 'Jul' + @Year + '-Sep' + @Year
               WHEN 'Q4' THEN 'Oct' + @Year + '- Dec'+ @Year
        END AS DateRange,
        SUM(SPD.ActualProduction),
        COALESCE(SUM(SPD.ActualProduction)/ 
        NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),
        SUM(DISTINCT SPD.PlantTargetProd),
        SUM([NoOfLoads]),
        SUM(DISTINCT SPD.ShiftRunTime),
        SUM(DISTINCT SPD.ShiftRunTime)
        FROM @ProductionSummaryTable SPD
        GROUP BY DATEPART(QUARTER, RecordDate),SPD.ShiftId
    )

    INSERT INTO @resultSet
    SELECT  
              0, 
              DateRange,
              SUM(TotalLoad),
              SUM(TotalEfficiency),
              SUM(PlantTargetLoad),
              SUM(Numberofbatches),
              SUM(ActualRunTime),
              SUM(TargetRuntime)
              ,@Viewtype 
              ,@Subview
               ,0
         FROM CTE 
            WHERE TotalLoad IS NOT NULL
        GROUP BY DateRange

    END
    END
    
    -- ******************************** Location View ***************************************************
    IF(@Viewtype = 2)
    BEGIN

    IF(@Subview = 9)
    BEGIN

    WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,WasherGroupId)
    AS
    (
        SELECT  
        --SPD.MachineId,    
      WG.WasherGroupName,
    SUM(SPD.ActualProduction),
    CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
    NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
    COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
    SUM(DISTINCT SPD.PlantTargetProd),
    SUM([NoOfLoads]),
    SUM(DISTINCT SPD.ShiftRunTime),
    SUM(DISTINCT SPD.ShiftRunTime),
    WG.WasherGroupId
    FROM @ProductionSummaryTable SPD LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId
             LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId 
    GROUP BY WG.WasherGroupName,WG.WasherGroupId,SPD.ShiftId--,SPD.MachineId
    )

     INSERT INTO @resultSet
     SELECT  
       0, 
      DateRange,
      SUM(TotalLoad),
      SUM(TotalEfficiency),
      @PlantTargetProduction,
      SUM(Numberofbatches),
      SUM(ActualRunTime),
      SUM(TargetRuntime)
      ,@Viewtype 
      ,@Subview
       ,WasherGroupId
         FROM CTE 
            WHERE TotalLoad IS NOT NULL       
        GROUP BY DateRange,WasherGroupId
     END

     IF(@Subview = 10)
    BEGIN

     WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime)
    AS
    (
        SELECT         
        cast( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName as MachineName,
        SUM(SPD.ActualProduction),
        CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
        NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
        COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
        SUM(DISTINCT SPD.PlantTargetProd),
        SUM([NoOfLoads]),
        SUM(DISTINCT SPD.ShiftRunTime),
        SUM(DISTINCT SPD.ShiftRunTime)        
        FROM @ProductionSummaryTable SPD 
		LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId
		LEFT JOIN TCD.Washer w on MS.WasherId=w.WasherId
             LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId 
        WHERE 
      (
       CASE @drillvalue   
           WHEN '' THEN 'TRUE'         
           ELSE                                                    
            CASE WHEN WG.WasherGroupId IN (@drillvalue) THEN 'TRUE' END            
           END='TRUE'
      )
     GROUP BY cast( W.PlantWasherNumber as varchar(20))+':'+MS.MachineName,SPD.ShiftId 
        
    )

     INSERT INTO @resultSet
     SELECT 
        0, 
      DateRange,
      SUM(TotalLoad),
      SUM(TotalEfficiency),
      @PlantTargetProduction,
      SUM(Numberofbatches),
      SUM(ActualRunTime),
      SUM(TargetRuntime)
      ,@Viewtype 
      ,@Subview
       ,0
         FROM CTE 
            WHERE TotalLoad IS NOT NULL
        GROUP BY DateRange
    END

    END

      SELECT       
      DateRange,
      ISNULL([TCD].[FnConsumptionOnMetrics](TotalLoad,'Weight',@UserId),0),
      --ISNULL(TotalLoad,0),
      ISNULL([TCD].[FnConsumptionOnMetrics](WasherEfficiency,'Weight',@UserId),0),
      --ISNULL(WasherEfficiency,0),
      ISNULL([TCD].[FnConsumptionOnMetrics](PlantTargetLoad,'Weight',@UserId),0),
      --ISNULL(PlantTargetLoad,0),
      ISNULL(Numberofbatches,0),
      ISNULL([ActualRunTime],0) [ActualRunTime],
      ISNULL([TargetRunTime],0) [TargetRunTime],
      Viewtype,
      Subview,
      Id,
      ShiftId,
      @CorrectionVariable
      FROM @resultSet 
END
GO

IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[GetWasherBatchSummarizedData]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[GetWasherBatchSummarizedData] 
END 
GO 

CREATE PROCEDURE [TCD].[GetWasherBatchSummarizedData](
    @DashBoardId int = NULL
) 
AS 
SET NOCOUNT ON
BEGIN 

 
DECLARE 
        @Washerid INT = NULL, 
        @Standardturntime INT = NULL, 
        @Machinenamedispalytype SMALLINT = 0,
	@OverNightBatchThreshold int = 120, -- mins 
	@EfficiencyType int

	SELECT @EfficiencyType = ISNULL(EfficiencyCalcType,1) from tcd.Dashboard where DashboardId = @DashBoardId

	DECLARE @Dashboardmachinemapping TABLE(
		Id INT, 
		GroupID INT,
		WasherId INT,
		WasherName NVARCHAR(100), 
		WasherNumber INT)

	DECLARE @AlarmByMachine TABLE(
		GroupID INT,
		WasherID INT, 
		Alarm BIT NULL,
		AlarmDescription NVARCHAR(250))

	DECLARE @BatchEndtimes TABLE(
		GroupID INT,
		WasherID INT, 
		CurrentBatchEndTime INT NULL,
		BatchEndTime time)

	Declare @ShiftIds table(
			 ShiftId int,
			 ShiftStartDate DATETIME,
			 ShiftEndDate	datetime)

	DECLARE @Summarizeddata TABLE(
		GroupId INT, 
		MachineId INT, 
		WasherName NVARCHAR(100), 
		WasherNumber INT, 
		TargetLoad float, 
		ActualLoad float, 
		LoadEfficiency float, 
		TimeEfficiency float, 
		LostLoad float, 
		Alarm BIT, 
		AlarmDescription NVARCHAR(250), 
		WasherStatus INT, 
		MachineNameDispalyType SMALLINT,
		TargetTurnTime INT,
		DefaultIdleTime INT)

	INSERT INTO @Dashboardmachinemapping(
		Id, 
		GroupID,
		WasherId,
		WasherName,
		WasherNumber)
	SELECT
		ROW_NUMBER()OVER(ORDER BY MS.GroupID)AS Id, 
		MS.GroupId,
		MS.WasherID,
		MS.MachineName,
		W.PlantWasherNumber AS WasherNumber
	    FROM(SELECT DISTINCT
			 MachineId, 
			 DashboardId
		FROM TCD.MonitorSetUpMapping)AS DM
		INNER JOIN TCD.MachineSetup AS MS ON DM.MachineId = MS.WasherID
		INNER JOIN tcd.Washer AS W ON MS.WasherId = W.WasherId
		INNER JOIN TCD.Dashboard AS D ON DM.DashBoardId = D.DashBoardId
	    WHERE DM.DashboardId = @Dashboardid
	      AND MS.IsDeleted = 0
	      AND w.Is_Deleted = 0
		  -- Exclude Phony Washers from Efficiency calculation 
	      AND ms.WasherId NOT IN(SELECT
					     w.WasherId
					 FROM TCD.MachineSetup AS ms
					      INNER JOIN TCD.Washer AS w ON w.WasherId = ms.WasherId
									AND ms.EcoalabAccountNumber = w.EcoLabAccountNumber
					 WHERE (NULLIF(ms.ControllerId, 0)IS NULL
					   AND w.WasherMode = 0)
					   OR MS.IsPony = 1
					   )


	-- For efficiency calculations on shift wise
	IF(@EfficiencyType = 1)
		BEGIN
		    INSERT @ShiftIds(ShiftId,ShiftStartDate,ShiftEndDate)
		    SELECT DISTINCT ShiftId,StartDateTime, EndDateTime FROM TCD.ProductionShiftData
			WHERE GETUTCDATE() BETWEEN StartDateTime AND EndDateTime 
			--WHERE ShiftId = 1090
	     END
	     
	ELSE -- For efficiency calculations on Day wise
		BEGIN
			INSERT @ShiftIds(ShiftId,ShiftStartDate,ShiftEndDate)
			SELECT ShiftId, StartDateTime, EndDateTime  
			FROM [TCD].ProductionShiftData  
			WHERE   startdatetime > CAST(GETUTCDATE()AS DATE ) and startdatetime < dateadd(dd,1,CAST(GETUTCDATE()AS DATE )) 
			ORDER BY startdatetime 
			
		END


-- Efficiency for each batch 
SELECT		bd.BatchId,
		W_1.WasherGroupID AS GroupID,
		W_1.WasherId AS MachineID,
		bd.ShiftId,
		W_1.WasherNumber,
		W_1.WasherName,
		(bd.ActualWeight + ISNULL(BD.ManualInputWeight,0)) AS ActualProduction,
		bd.StandardWeight AS StandardProduction,
		CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold
			THEN W_1.StandardRunTime
		     ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
		END AS ActualRunTime,
		W_1.StandardRunTime,
		TT.ActualTurnTime,
		bd.TargetTurnTime AS StandardTurnTime,
		CASE WHEN W_1.WasherGroupTypeID = 1 
				-- Conventional
				THEN (CAST((W_1.Standardruntime + bd.TargetTurnTime)AS FLOAT) / (CAST(CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold
														THEN W_1.StandardRunTime
														ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
													END 
				+ CASE WHEN TT.ACTUALTURNTIME = 0 THEN bd.TargetTurnTime 
					ELSE TT.ACTUALTURNTIME
				  END  AS FLOAT)))
				-- Tunnel
			ELSE 
			(CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT) + (3600.00/(CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT)/W_1.NumberOfComp)))
				/ (CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0 
										THEN W_1.Standardruntime 
										ELSE CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold
												THEN W_1.StandardRunTime
											     ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
											END
									END AS FLOAT) + (3600.00/(CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0 
													    THEN W_1.Standardruntime 
													    ELSE CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold
															THEN W_1.StandardRunTime
															ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
														END
												    END AS FLOAT)/W_1.NumberOfComp))
												    )
		END AS TimeEfficiency,
		((CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS FLOAT)/CAST(NULLIF(bd.StandardWeight,0) AS FLOAT)) * 100) AS LoadEfficiency,
		CASE WHEN W_1.WasherGroupTypeID = 2 
						THEN
		(100 * ((3600.00/(CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0 
							THEN NULLIF(W_1.Standardruntime,0)
							ELSE DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
							END AS FLOAT)/W_1.NumberOfComp)) /
							(3600.00/(CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT)/W_1.NumberOfComp))))
			ELSE NULL
		END AS TransferPerHr,
		((bd.StandardWeight - bd.ActualWeight) +
		(CASE WHEN W_1.WasherGroupTypeID = 1 
				THEN
					((CAST((CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold
							THEN W_1.StandardRunTime
						     ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
						END + TT.ACTUALTURNTIME) AS FLOAT) - W_1.Standardruntime - bd.TargetTurnTime) 
					* CAST((CAST(bd.StandardWeight AS FLOAT)/NULLIF((W_1.Standardruntime + bd.TargetTurnTime),0)) AS FLOAT)) 
				ELSE ((CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold
						THEN W_1.StandardRunTime
					     ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
					END - W_1.Standardruntime) * (CAST(bd.StandardWeight AS FLOAT)/ NULLIF(W_1.Standardruntime,0)))
		END)) AS MissedLoads,
		(((CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS FLOAT)/CAST(NULLIF(bd.StandardWeight,0) AS FLOAT)) * 100) 
		* (		CASE WHEN W_1.WasherGroupTypeID = 1 
						-- Conventional
						THEN (CAST((W_1.Standardruntime + bd.TargetTurnTime)AS FLOAT) / (CAST(CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold
															    THEN W_1.StandardRunTime
															    ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
														    END + TT.ACTUALTURNTIME AS FLOAT)))
						-- Tunnel
					 ELSE 
						(CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT) + (3600.00/(CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT)/W_1.NumberOfComp)))
							/ (CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0 
													THEN W_1.Standardruntime 
													ELSE CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold
														    THEN W_1.StandardRunTime
														    ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
													    END
												END AS FLOAT) + (3600.00/(CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0 
																    THEN W_1.Standardruntime 
																    ELSE CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold
																		    THEN W_1.StandardRunTime
																		 ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
																	    END
															    END AS FLOAT)/W_1.NumberOfComp))
															    )
				END)) AS TotalEfficiency


INTO #BatchEfficiency
FROM TCD.BatchData bd 
RIGHT OUTER JOIN(     
                SELECT ms.EcoalabAccountNumber,    
                        ms.WasherId,    
                        ms.GroupId AS WasherGroupID,    
                        mg.WasherGroupTypeId AS WasherGroupTypeID,    
                        w.EcolabWasherId,    
                        ISNULL(ms.NumberOfComp,0) AS NumberOfComp,    
                        CASE    
                        WHEN MG.WASHERGROUPTYPEID = 1 THEN WSP.ProgramNumber    
                            ELSE TPS.ProgramNumber    
                        END AS ProgramNumber,    
                        CASE    
                        WHEN MG.WASHERGROUPTYPEID = 1 THEN WSP.ProgramId    
							ELSE TPS.ProgramId    
                        END AS ProgramId,    
                        CASE    
			    WHEN MG.WASHERGROUPTYPEID = 1 
				THEN WSP.TotalRunTime    
                            ELSE TPS.TotalRunTime    
			END AS Standardruntime,
			w.PlantWasherNumber AS WasherNumber,
			ms.MachineName AS WasherName,
			mg.WasherGroupName AS MachineGroup
			--mg.WasherGroupId AS MachineGroupID
                    FROM TCD.MachineSetup AS ms (NOLOCK)    
                        INNER JOIN TCD.Washer AS w (NOLOCK) ON w.EcoLabAccountNumber = ms.EcoalabAccountNumber    
                                                    AND w.WasherId = ms.WasherId    
                        INNER JOIN TCD.WasherGroup AS mg (NOLOCK) ON ms.GroupId = mg.WasherGroupId    
                                                        AND w.EcoLabAccountNumber = mg.EcolabAccountNumber    
                        LEFT OUTER JOIN TCD.WasherProgramSetup AS WSP (NOLOCK) ON WSP.WasherGroupId = mg.WasherGroupId    
                                                                    AND WSP.EcolabAccountNumber = mg.EcolabAccountNumber    
                                                                    AND WSP.WasherGroupId = ms.GroupId    
                        LEFT OUTER JOIN TCD.TunnelProgramSetup AS TPS (NOLOCK) ON TPS.WasherGroupId = mg.WasherGroupId    
                                                                    AND TPS.EcolabAccountNumber = mg.EcolabAccountNumber    
                                                                    AND TPS.WasherGroupId = ms.GroupId 
			RIGHT JOIN @Dashboardmachinemapping DM1	ON DM1.GroupID = ms.GroupId 
						AND DM1.WasherId = ms.WasherId
			WHERE ms.IsTunnel = 0 
			AND ms.IsDeleted = 0
			) AS W_1 ON BD.GroupId = W_1.WasherGroupID    
                                    AND BD.EcolabWasherId = W_1.EcolabWasherId    
                                    AND BD.ProgramMasterId = W_1.ProgramId    
                                    AND BD.ProgramNumber = W_1.ProgramNumber
LEFT JOIN [TCD].[Turntime] TT ON BD.EcolabwasherID = TT.EcolabWasherId AND BD.batchid = TT.BatchID
WHERE bd.ShiftId IN (SELECT si.ShiftId FROM @ShiftIds si)
--AND bd.EndDate IS NOT NULL 
AND bd.ActualWeight > 0 
AND bd.StandardWeight > 0
AND DATEDIFF(ss, bd.StartDate, bd.EndDate) > (W_1.Standardruntime * 10/100)

	-- Efficiency by Machine calculation 
	SELECT	DM.GroupID, 
		DM.WasherId AS MachineID,
		DM.WasherNumber,
		DM.WasherName,
		CAST(sum(t.ActualProduction) AS FLOAT) AS ActualProduction,
		CAST(sum(t.StandardProduction) AS FLOAT) AS StandardProduction,
		SUM(t.ActualRunTime) AS ActualRuntime,
		SUM(t.StandardRunTime) AS StandardRunTime,
		(SUM(t.MissedLoads)/count(DISTINCT t.BatchId)) AS MissedLoads,
		(CAST(sum(t.LoadEfficiency) AS FLOAT) / count(DISTINCT t.BatchId)) AS LoadEfficiency,
		((CAST(sum(t.TimeEfficiency) AS FLOAT) / count(DISTINCT t.BatchId))*100)  AS TimeEfficiency,
		((CAST(sum(t.LoadEfficiency) AS FLOAT) / count(DISTINCT t.BatchId)) * (CAST(sum(t.TimeEfficiency) AS FLOAT) / count(DISTINCT t.BatchId))) AS TotalEfficiency
	INTO #MachineEfficiency
	FROM @Dashboardmachinemapping DM 
	LEFT JOIN #BatchEfficiency t ON DM.GroupID = t.GroupId AND dm.WasherId = t.MachineId
	--AND t.ActualRunTime > (t.StandardRunTime * 10/100)
	GROUP BY DM.GroupID, 
	DM.WasherId,
	DM.WasherNumber,
	DM.WasherName

/*
	-- Efficiency by Machine calculation 
	SELECT	t.GroupID, 
		t.MachineId,
		t.WasherNumber,
		t.WasherName,
		CAST(sum(t.ActualProduction) AS FLOAT) AS ActualProduction,
		CAST(sum(t.StandardProduction) AS FLOAT) AS StandardProduction,
		SUM(t.ActualRunTime) AS ActualRuntime,
		SUM(t.StandardRunTime) AS StandardRunTime,
		(SUM(t.MissedLoads)/count(DISTINCT t.BatchId)) AS MissedLoads,
		(CAST(sum(t.LoadEfficiency) AS FLOAT) / count(DISTINCT t.BatchId)) AS LoadEfficiency,
		((CAST(sum(t.TimeEfficiency) AS FLOAT) / count(DISTINCT t.BatchId))*100)  AS TimeEfficiency,
		((CAST(sum(t.LoadEfficiency) AS FLOAT) / count(DISTINCT t.BatchId)) * (CAST(sum(t.TimeEfficiency) AS FLOAT) / count(DISTINCT t.BatchId))) AS TotalEfficiency
	INTO #MachineEfficiency
	FROM #BatchEfficiency t
	RIGHT JOIN @Dashboardmachinemapping DM	ON DM.GroupID = t.GroupId 
						AND dm.WasherId = t.MachineId
	WHERE ActualRunTime > (t.StandardRunTime * 10/100)
	GROUP BY t.GroupID, 
	t.MachineId,
	t.WasherNumber,
	t.WasherName
*/
  

	INSERT @AlarmByMachine
	(
	    GroupID,
	    WasherID,
	    Alarm,
	    AlarmDescription
	)
	SELECT AlarmByMachine.GroupID, AlarmByMachine.WasherID, AlarmByMachine.Alarm, AlarmByMachine.AlarmDescription 
	FROM (
	    SELECT ROW_NUMBER() OVER (PARTITION BY AD.MachineId ORDER BY AD.StartDate DESC) AS rownum
	    , AD.IsActive AS Alarm, AM.[Description] AS AlarmDescription
	    , AD.MachineId AS WasherID
	    , d.GroupID
	    FROM TCD.AlarmData AD 
	    INNER JOIN TCD.AlarmMaster AM on AM.AlarmCode = AD.AlarmCode
	    INNER JOIN @Dashboardmachinemapping d ON AD.MachineId = D.WasherId
	    ) AS AlarmByMachine
	WHERE rownum = 1

	INSERT @BatchEndtimes
	(
	    GroupID,
	    WasherID,
	    CurrentBatchEndTime,
	    BatchEndTime
	)
	SELECT d.GroupID, d.WasherId, 
	COUNT(CASE WHEN bd.EndDate IS NULL THEN 1 ELSE NULL END) AS CurrentBatchEndTime,
	CAST(MAX(bd.EndDate) AS TIME) AS BatchEndTime
	FROM @DashboardMachineMapping d
	INNER JOIN TCD.BatchData bd ON d.GroupID = bd.GroupId AND d.WasherId = bd.MachineId
	WHERE bd.ShiftId IN (
	SELECT ShiftId FROM @ShiftIds)
	GROUP BY d.GroupID, d.WasherId


	SELECT @StandardTurnTime = ISNULL(ConStdTurnTime,30)  From tcd.Plant
	SELECT @StandardTurnTime = @StandardTurnTime + ISNULL(TargetTurnTime,0)  From tcd.Washer Where WasherId = @WasherId

	SELECT @MachineNameDispalyType=ISNULL( MachineNameDispalyType,0) FROM TCD.Dashboard D
		    INNER JOIN TCD.[MonitorSetUpMapping] MSM on D.DashboardId=MSM.DashboardId and MSM.MachineId=@WasherId and D.DashboardId=@DashBoardId


	INSERT INTO @Summarizeddata(
		GroupId,
		MachineId,
		WasherName ,
		WasherNumber,
		TargetLoad,
		ActualLoad,
		LoadEfficiency,
		TimeEfficiency,
		LostLoad,
		Alarm,
		AlarmDescription,
		WasherStatus,
		MachineNameDispalyType,
		TargetTurnTime,
		DefaultIdleTime
		)
	 SELECT me.GroupID,
		me.MachineID,
		me.WasherName,
		me.WasherNumber,
		me.StandardProduction AS TargetLoad,
		me.ActualProduction AS ActulaLoad,
		me.LoadEfficiency,
		me.TimeEfficiency,
		me.MissedLoads AS LostLoad,
		ISNULL(abm.Alarm,0) AS Alarm,
		abm.AlarmDescription,
		CASE 
		    WHEN be.CurrentBatchEndTime = 1 THEN 1
		    WHEN CAST(GETUTCDATE() AS TIME) BETWEEN be.BatchEndTime AND DateAdd(Minute,@StandardTurnTime,be.BatchEndTime) THEN 2
		    WHEN abm.Alarm = 1 THEN 3
		    ELSE 3
		END AS WasherStatus,
		@MachineNameDispalyType,
		( SELECT TargetTurnTime FROM TCD.WASHER W WHERE W.WasherId=ME.MachineID),
		  ( SELECT DefaultIdleTime FROM TCD.WASHER W WHERE W.WasherId=ME.MachineID)
	 FROM #MachineEfficiency me
	 LEFT JOIN @AlarmByMachine abm on ME.GroupID = abm.GroupID AND ME.MachineID = ABM.WasherID
	 LEFT JOIN @BatchEndtimes be ON me.GroupID = be.GroupID AND me.MachineID = be.WasherID

	SELECT
		GroupId, 
		MachineId, 
		CASE @Machinenamedispalytype
		    WHEN 0 THEN CAST(WasherNumber AS VARCHAR(20)) + ' ' + WasherName
		    WHEN 1 THEN WasherName
		    WHEN 2 THEN CAST(WasherNumber AS VARCHAR(20))
		END AS WasherName, 
		WasherNumber, 
		TargetLoad, 
		ActualLoad, 
		LoadEfficiency, 
		TimeEfficiency, 
		LostLoad, 
		Alarm, 
		AlarmDescription, 
		WasherStatus,
		TargetTurnTime,
		DefaultIdleTime
	    FROM @Summarizeddata
	    ORDER BY
		WasherNumber


---- CleanUp
DROP TABLE #MachineEfficiency
DROP TABLE #BatchEfficiency

END
GO


IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[GetBatchSummarizedData]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[GetBatchSummarizedData] 
END 
GO 

CREATE PROCEDURE [TCD].[GetBatchSummarizedData] (
            @DashBoardId INT = NULL 
            ) 

AS 
BEGIN 

    SET NOCOUNT ON


     DECLARE 
        @Efficiencytype INT,
	@OvernightBatchThreshold INT = 120 -- mins
    
     DECLARE @DashboardMachineMapping TABLE(
         Id INT,
         GroupId INT,
         WasherId INT,
         DisplayCustomer BIT,
	 WasherName NVARCHAR(100), 
	 WasherNumber INT)

      DECLARE @Summarizeddata TABLE(
        GroupId INT,
        TunnelName Nvarchar(100),
        TargetLoad FLOAT,
        ActualLoad FLOAT,
	LoadEfficiency FLOAT,
        TimeEfficiency FLOAT,
        LostLBS FLOAT,
        TransferPerHr FLOAT,
        SignalStatus INT,        
        EmptyPockets INT,
        Alarm Bit,
        TransferPercent DECIMAL(10,2),
        EndOfFormula INT,
        DisplayCustomer BIT,
        WasherNumber INT
        )
        
	DECLARE @ShiftIds TABLE(
	ShiftId INT,
	ShiftStartDate DATETIME,
	ShiftEndDate DATETIME
	)

	SELECT
		@Efficiencytype = ISNULL(EfficiencyCalcType, 1)
	    FROM tcd.Dashboard
	    WHERE DashboardId = @Dashboardid

      INSERT INTO @DashboardMachineMapping
        (
            Id,
            GroupId,
            WasherId,
	    DisplayCustomer,
	    WasherName,
	    WasherNumber
        )
    SELECT 
    ROW_NUMBER() OVER(ORDER BY GroupID) AS Id,
    A.GroupId,
    A.WasherId,
    A.Customer,
    A.WasherName,
    A.WasherNumber
    FROM
    (SELECT DISTINCT
       MS.GroupId,MS.WasherId,D.Customer,MS.MachineName AS WasherName, w.PlantWasherNumber AS WasherNumber
     FROM TCD.MonitorSetUpMapping DM 
        INNER JOIN TCD.MachineSetup MS ON DM.MachineId = MS.WasherID
        INNER JOIN TCD.Dashboard D on DM.DashBoardId = D.DashBoardId
	INNER JOIN TCD.Washer w ON ms.WasherId = w.WasherId
    WHERE DM.DashboardId = @DashBoardId
    AND ms.IsDeleted = 0
    AND w.Is_Deleted = 0 
    )A;
	


	-- For efficiency calculations on shift wise
	IF @Efficiencytype = 1
	    BEGIN

		INSERT INTO @Shiftids(shiftId,ShiftStartDate, ShiftEndDate)
		SELECT DISTINCT ShiftId, StartDateTime, EndDateTime
		FROM TCD.ProductionShiftData
		--WHERE ShiftId = 1105
		WHERE GETUTCDATE() BETWEEN StartDateTime AND EndDateTime 

	    END
	ELSE -- For efficiency calculations on Day wise
	    BEGIN

		INSERT @Shiftids(ShiftId, ShiftStartDate, ShiftEndDate)
		SELECT DISTINCT ShiftId, StartDateTime, EndDateTime
		FROM TCD.ProductionShiftData
		WHERE startdatetime > CAST(GETUTCDATE()AS DATE)
		AND startdatetime < DATEADD(dd, 1, CAST(GETUTCDATE()AS DATE))

	    END		


-- Efficiency for each batch 
SELECT		bd.BatchId,
		bd.GroupID,
		bd.MachineID,
		bd.ShiftId,
		W_1.WasherNumber,
		W_1.WasherName,
		(bd.ActualWeight + ISNULL(BD.ManualInputWeight,0)) AS ActualProduction,
		bd.StandardWeight AS StandardProduction,
		--DATEDIFF(ss,bd.StartDate, bd.EndDate) AS ActualRunTime,
		CASE WHEN DATEDIFF(mi,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OvernightBatchThreshold 
			THEN W_1.Standardruntime 
		     ELSE DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
		END AS ActualRunTime,
		W_1.StandardRunTime,
		TT.ActualTurnTime,
		bd.TargetTurnTime AS StandardTurnTime,
		CASE WHEN W_1.WasherGroupTypeID = 1 
				-- Conventional
				THEN (CAST((W_1.Standardruntime + bd.TargetTurnTime)AS FLOAT) / (CAST(CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold
														THEN W_1.StandardRunTime
														ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
													END 
				+ CASE WHEN TT.ACTUALTURNTIME = 0 THEN bd.TargetTurnTime 
					ELSE TT.ACTUALTURNTIME
				  END  AS FLOAT)))
				-- Tunnel
			ELSE 
			(CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT) + (3600.00/(CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT)/W_1.NumberOfComp)))
				/ (CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0 
										THEN W_1.Standardruntime 
										ELSE CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold
												THEN W_1.StandardRunTime
											     ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
											END
									END AS FLOAT) + (3600.00/(CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0 
													    THEN W_1.Standardruntime 
													    ELSE CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold
															THEN W_1.StandardRunTime
															ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
														END
												    END AS FLOAT)/W_1.NumberOfComp))
												    )
		END AS TimeEfficiency,
		((CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS FLOAT)/CAST(NULLIF(bd.StandardWeight,0) AS FLOAT)) * 100) AS LoadEfficiency,
		CASE WHEN W_1.WasherGroupTypeID = 2 
						THEN
		(100 * ((3600.00/(CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0 
							THEN NULLIF(W_1.Standardruntime,0)
							ELSE DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
							END AS FLOAT)/W_1.NumberOfComp)) /
							(3600.00/(CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT)/W_1.NumberOfComp))))
			ELSE NULL
		END AS TransferPerHr,
		((bd.StandardWeight - bd.ActualWeight) +
		(CASE WHEN W_1.WasherGroupTypeID = 1 
				THEN
					((CAST((CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold
							THEN W_1.StandardRunTime
						     ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
						END + TT.ACTUALTURNTIME) AS FLOAT) - W_1.Standardruntime - bd.TargetTurnTime) 
					* CAST((CAST(bd.StandardWeight AS FLOAT)/NULLIF((W_1.Standardruntime + bd.TargetTurnTime),0)) AS FLOAT)) 
				ELSE ((CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold
						THEN W_1.StandardRunTime
					     ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
					END - W_1.Standardruntime) * (CAST(bd.StandardWeight AS FLOAT)/ NULLIF(W_1.Standardruntime,0)))
		END)) AS MissedLoads,
		(((CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS FLOAT)/CAST(NULLIF(bd.StandardWeight,0) AS FLOAT)) * 100) 
		* (		CASE WHEN W_1.WasherGroupTypeID = 1 
						-- Conventional
						THEN (CAST((W_1.Standardruntime + bd.TargetTurnTime)AS FLOAT) / (CAST(CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold
															    THEN W_1.StandardRunTime
															    ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
														    END + TT.ACTUALTURNTIME AS FLOAT)))
						-- Tunnel
					 ELSE 
						(CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT) + (3600.00/(CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT)/W_1.NumberOfComp)))
							/ (CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0 
													THEN W_1.Standardruntime 
													ELSE CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold
														    THEN W_1.StandardRunTime
														    ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
													    END
												END AS FLOAT) + (3600.00/(CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0 
																    THEN W_1.Standardruntime 
																    ELSE CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold
																		    THEN W_1.StandardRunTime
																		 ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
																	    END
															    END AS FLOAT)/W_1.NumberOfComp))
															    )
				END)) AS TotalEfficiency

INTO #BatchEfficiency
FROM TCD.BatchData bd 
INNER JOIN(     
                SELECT ms.EcoalabAccountNumber,    
                        ms.WasherId,    
                        ms.GroupId AS WasherGroupID,    
                        mg.WasherGroupTypeId AS WasherGroupTypeID,    
                        w.EcolabWasherId,    
                        ISNULL(ms.NumberOfComp,0) AS NumberOfComp,    
                        CASE    
                        WHEN MG.WASHERGROUPTYPEID = 1 THEN WSP.ProgramNumber    
                            ELSE TPS.ProgramNumber    
                        END AS ProgramNumber,    
                        CASE    
                        WHEN MG.WASHERGROUPTYPEID = 1 THEN WSP.ProgramId    
							ELSE TPS.ProgramId    
                        END AS ProgramId,    
                        CASE    
			    WHEN MG.WASHERGROUPTYPEID = 1 
				THEN WSP.TotalRunTime    
                            ELSE TPS.TotalRunTime    
			END AS Standardruntime,
			w.PlantWasherNumber AS WasherNumber,
			ms.MachineName AS WasherName,
			mg.WasherGroupName AS MachineGroup,
			ms.IsTunnel
			--mg.WasherGroupId AS MachineGroupID
                    FROM TCD.MachineSetup AS ms (NOLOCK)    
                        INNER JOIN TCD.Washer AS w (NOLOCK) ON w.EcoLabAccountNumber = ms.EcoalabAccountNumber    
                                                    AND w.WasherId = ms.WasherId    
                        INNER JOIN TCD.WasherGroup AS mg (NOLOCK) ON ms.GroupId = mg.WasherGroupId    
                                                        AND w.EcoLabAccountNumber = mg.EcolabAccountNumber    
                        LEFT OUTER JOIN TCD.WasherProgramSetup AS WSP (NOLOCK) ON WSP.WasherGroupId = mg.WasherGroupId    
                                                                    AND WSP.EcolabAccountNumber = mg.EcolabAccountNumber    
                                                                    AND WSP.WasherGroupId = ms.GroupId    
                        LEFT OUTER JOIN TCD.TunnelProgramSetup AS TPS (NOLOCK) ON TPS.WasherGroupId = mg.WasherGroupId    
                                                                    AND TPS.EcolabAccountNumber = mg.EcolabAccountNumber    
                                                                    AND TPS.WasherGroupId = ms.GroupId 
			WHERE ms.IsTunnel = 1
			) AS W_1 ON BD.GroupId = W_1.WasherGroupID    
			    AND BD.MachineId = W_1.WasherId    
			    AND BD.ProgramMasterId = W_1.ProgramId    
			    AND BD.ProgramNumber = W_1.ProgramNumber
LEFT JOIN [TCD].[Turntime] TT ON BD.EcolabwasherID = TT.EcolabWasherId 
				AND BD.batchid = TT.BatchID 
				AND bd.MachineId = tt.MachineId
WHERE bd.ShiftId IN (SELECT si.ShiftId FROM @ShiftIds si)
AND bd.ActualWeight > 0 
AND bd.StandardWeight > 0
AND DATEDIFF(ss, bd.StartDate, bd.EndDate) > (W_1.Standardruntime * 10/100)
--AND bd.EndDate IS NOT NULL


	-- Efficiency by Machine calculation 
	SELECT	DM.GroupID, 
		DM.WasherId AS MachineID,
		DM.WasherNumber,
		DM.WasherName,
		CAST(sum(t.ActualProduction) AS FLOAT) AS ActualProduction,
		CAST(sum(t.StandardProduction) AS FLOAT) AS StandardProduction,
		SUM(t.ActualRunTime) AS ActualRuntime,
		SUM(t.StandardRunTime) AS StandardRunTime,
		(SUM(t.MissedLoads)/count(DISTINCT t.BatchId)) AS MissedLoads,
		(CAST(sum(t.LoadEfficiency) AS FLOAT) / count(DISTINCT t.BatchId)) AS LoadEfficiency,
		(CAST(sum(t.TimeEfficiency) AS FLOAT) / count(DISTINCT t.BatchId)) AS TimeEfficiency,
		(CAST(SUM(t.TransferPerHr) AS FLOAT)/ count(DISTINCT t.BatchId)) AS TransferPerHour,
		((CAST(sum(t.LoadEfficiency) AS FLOAT) / count(DISTINCT t.BatchId)) * (CAST(sum(t.TimeEfficiency) AS FLOAT) / count(DISTINCT t.BatchId))) AS TotalEfficiency
	INTO #MachineEfficiency
	FROM @Dashboardmachinemapping DM	
	LEFT JOIN #BatchEfficiency t ON DM.GroupID = t.GroupId AND dm.WasherId = t.MachineId
	GROUP BY DM.GroupID, 
		DM.WasherId,
		DM.WasherNumber,
		DM.WasherName


      DECLARE @EmptyPocketNAlarmddata TABLE(
	    GroupId INT,
	    WasherID INT,
	    EndOfFormula  INT,
	    DisplayCustomer	Decimal(18,2),
	    EmptyPockets INT,
	    MachineNameDispalyType INT,
	    EmptyPocketLoad Decimal(18,2),
	    Alarm bit,
	    WasherStatus bit
	)

    INSERT @EmptyPocketNAlarmddata    (GroupId,WasherID,EndOfFormula,DisplayCustomer,EmptyPockets,MachineNameDispalyType, EmptyPocketLoad,Alarm,WasherStatus)
    SELECT  D.GroupId, 
	    D.WasherId, 
	    w.EmptyPocketNumber AS EndOfFormula, 
	    D.DisplayCustomer, 
	    A.EmptyPockets, 
	    (SELECT SUM(ISNULL(MachineNameDispalyType,0)) FROM TCD.Dashboard D1
		INNER JOIN TCD.[MonitorSetUpMapping] MSM ON D1.DashboardId=MSM.DashboardId  
		WHERE MSM.MachineId=D.WasherId and D1.DashboardId=@DashBoardId
		) as MachineNameDispalyType,
	    sum(w.MaxLoad) AS EmptyPocketLoad,
	    NULL AS alarm,
	    sum(CASE WHEN B.WasherStatus > 0 THEN 1 ELSE 0 END) AS WasherStatus
    FROM TCD.Washer AS w 
    INNER JOIN @DashboardMachineMapping AS D ON w.WasherId = d.WasherId
    CROSS APPLY  (
	SELECT COUNT(*) As EmptyPockets from TCD.BatchData AS b JOIN @ShiftIds AS s ON b.ShiftId = s.ShiftId 
	WHERE b.StartDate >= s.ShiftStartDate 
	AND b.GroupId = d.GroupId 
	AND b.ProgramNumber = w.EmptyPocketNumber
       ) AS A
    CROSS APPLY (
	SELECT Count(*) as WasherStatus
	from tcd.BatchData where MachineId = d.WasherId AND GroupId= D.GroupId and (EndDate >= DATEADD(mi,-30,GETUTCDATE()) OR EndDate is NULL)
	) AS B
    GROUP BY D.GroupId, D.WasherId, w.EmptyPocketNumber, D.DisplayCustomer, A.EmptyPockets


    UPDATE X 
    SET X.Alarm = ISNULL(Alarm.IsActive,0)
    FROM @EmptyPocketNAlarmddata X
    CROSS APPLY ( 
	SELECT TOP 1 AD.IsActive
	    FROM [TCD].AlarmData AD 
	    WHERE GroupId = X.GroupId
	    ORDER BY StartDate DESC
		) AS Alarm



INSERT INTO @Summarizeddata(GroupId,TunnelName,TargetLoad,ActualLoad,LoadEfficiency, TimeEfficiency,
        LostLBS,TransferPerHr,SignalStatus,EmptyPockets,Alarm,TransferPercent,EndOfFormula,DisplayCustomer,WasherNumber)
 SELECT  me.GroupID, 
	 CASE epn.MachineNameDispalyType 
	    WHEN 0 THEN CAST( me.WasherNumber AS varchar(20))+' '+  me.WasherName
	    WHEN 1 THEN me.WasherName
	    WHEN 2 THEN CAST( me.WasherNumber AS varchar(20))								
	 END AS TunnelName,
	 me.StandardProduction, 
	 me.ActualProduction, 
	 me.LoadEfficiency,
	 me.TimeEfficiency, 
	 me.MissedLoads,
	 me.TransferPerHour,
	 epn.WasherStatus,
	 epn.EmptyPockets,
	 ISNULL(epn.Alarm,0) AS Alarm,
	 0 AS TransferPercent,
	 epn.EndOfFormula,
	 epn.DisplayCustomer,
	 me.WasherNumber
 from #MachineEfficiency me
 LEFT JOIN @EmptyPocketNAlarmddata epn ON me.GroupID = epn.GroupId AND me.MachineID = epn.WasherID
 
     SELECT  GroupId,
	    TunnelName,
	    TargetLoad,
	    ActualLoad,
	    LoadEfficiency,
	    TimeEfficiency,
	    LostLBS,
	    TransferPerHr,
	    SignalStatus,        
	    EmptyPockets,
	    Alarm,
	    TransferPercent,
	    EndOfFormula,
	    DisplayCustomer,
	    WasherNumber
    FROM @Summarizeddata  
    ORDER BY WasherNumber

-- CleanUp
DROP TABLE #BatchEfficiency
DROP TABLE #MachineEfficiency

END
GO



IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[GetShiftSummaryDetails]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].GetShiftSummaryDetails 
END 
GO 

CREATE PROCEDURE TCD.GetShiftSummaryDetails
AS
    BEGIN
        SET NOCOUNT ON;
            DECLARE @Washerdashboardid INT, 
                    @Tunneldashboardid INT, 
                    @Shiftname         NVARCHAR(1000) = NULL,
		    @Actualloads           FLOAT, 
                    @Lostloads             FLOAT, 
                    @Efficiency            FLOAT, 
                    @Cummulativeefficiency FLOAT;

            DECLARE @Washershiftdata TABLE(
                    GroupId          INT, 
                    MachineId        INT, 
                    WasherName       NVARCHAR(100), 
                    WasherNumber     INT, 
                    TargetLoad       FLOAT, 
                    ActualLoad       FLOAT, 
                    LoadEfficiency   FLOAT, 
                    TimeEfficiency   FLOAT, 
                    LostLoad         FLOAT, 
                    Alarm            BIT, 
                    AlarmDescription NVARCHAR(250), 
                    WasherStatus     INT,
				TargetTurnTime INT,
				DefaultIdleTime INT);

            DECLARE @Tunnelshiftdata TABLE(
                    GroupId         INT, 
                    TunnelName      NVARCHAR(100), 
                    TargetLoad      FLOAT, 
                    ActualLoad      FLOAT, 
                    LoadEfficiency  FLOAT, 
                    TimeEfficiency  FLOAT, 
                    LostLBS         FLOAT, 
                    TransferPerHr   FLOAT, 
                    SignalStatus    INT, 
                    EmptyPockets    INT, 
                    Alarm           BIT, 
                    TransferPercent DECIMAL(10, 2), 
                    EndOfFormula    INT, 
                    DisplayCustomer BIT, 
                    WasherNumber    INT);

            SET @Washerdashboardid = (SELECT TOP 1
                                              D.DashboardId
                                          FROM TCD.Dashboard AS D
                                               INNER JOIN
                                               TCD.WasherGroupType AS wgt ON wgt.WasherGroupTypeId = D.TypeId
                                          WHERE wgt.WasherGroupTypeName = 'Conventional'
                                          ORDER BY
                                              D.DashboardId);
            SET @Tunneldashboardid = (SELECT TOP 1
                                              D.DashboardId
                                          FROM TCD.Dashboard AS D
                                               INNER JOIN
                                               TCD.WasherGroupType AS wgt ON wgt.WasherGroupTypeId = D.TypeId
                                          WHERE wgt.WasherGroupTypeName = 'Tunnel'
                                          ORDER BY
                                              D.DashboardId);
            SELECT DISTINCT
                    @Shiftname = ShiftName
                FROM TCD.ProductionShiftData
                WHERE GETUTCDATE() BETWEEN StartDateTime AND EndDateTime;

            INSERT INTO @Washershiftdata
                   (
                    GroupId, 
                    MachineId, 
                    WasherName, 
                    WasherNumber, 
                    TargetLoad, 
                    ActualLoad, 
                    LoadEfficiency, 
                    TimeEfficiency, 
                    LostLoad, 
                    Alarm, 
                    AlarmDescription, 
                    WasherStatus,
				TargetTurnTime ,
				DefaultIdleTime 
                   )
            EXEC TCD.GetWasherBatchSummarizedData
                 @Dashboardid = @Washerdashboardid;

            INSERT INTO @Tunnelshiftdata
                   (
                    GroupId, 
                    TunnelName, 
                    TargetLoad, 
                    ActualLoad, 
                    LoadEfficiency, 
                    TimeEfficiency, 
                    LostLBS, 
                    TransferPerHr, 
                    SignalStatus, 
                    EmptyPockets, 
                    Alarm, 
                    TransferPercent, 
                    EndOfFormula, 
                    DisplayCustomer, 
                    WasherNumber
                   )
            EXEC TCD.GetBatchSummarizedData
                 @Dashboardid = @Tunneldashboardid;


	    -- Calculate Actual Production and Lost Loads 
            SELECT
                    @Actualloads = SUM(CD.ActualLoad), 
                    @Lostloads = SUM(CD.LostLoad)
                FROM(
                    SELECT
                            w.ActualLoad, 
                            w.LostLoad FROM @Washershiftdata AS w
                    UNION ALL
                    SELECT
                            t.ActualLoad, 
                            t.LostLBS AS LostLoad FROM @Tunnelshiftdata AS t) AS CD;
            
	    -- Calculate Efficiency for conventional and tunnel
	    SELECT
                    @Cummulativeefficiency = SUM(T.Efficiency)
                FROM(
                    SELECT
                            ActualLoad, 
                            TimeEfficiency, 
                            CAST(ActualLoad / TimeEfficiency AS FLOAT) AS Efficiency
                        FROM @Washershiftdata
                    UNION ALL
                    SELECT
                            ActualLoad, 
                            LoadEfficiency * TimeEfficiency AS TimeEfficiency, 
                            CAST(ActualLoad / (LoadEfficiency * TimeEfficiency) AS FLOAT)
                        FROM @Tunnelshiftdata) AS T;
            -- Calculate Overall Efficiency
	    SET @Efficiency = @Actualloads / @Cummulativeefficiency;

            SELECT
                    ISNULL(@Actualloads, 0.00) AS TotalLoad, 
                    ISNULL(@Efficiency, 0.00) AS Efficiency, 
                    ISNULL(@Lostloads, 0.00) AS LostLoads, 
                    ISNULL(@Shiftname, 'No Shift Available') AS ShiftName;
    END;
GO

/* Update No of chemical valves in Field Table*/
UPDATE TCD.Field
SET
    TCD.Field.Max = 16,
    TCD.Field.DefaultValue = 12
WHERE TCD.Field.Id = 61

UPDATE TCD.Field
SET
    TCD.Field.Max = 12,
    TCD.Field.DefaultValue = 10
WHERE TCD.Field.Id = 71

UPDATE TCD.Field
SET
    TCD.Field.Max = 16,
    TCD.Field.DefaultValue = 10
WHERE TCD.Field.Id = 122

UPDATE TCD.Field
SET
    TCD.Field.Max = 12,
    TCD.Field.DefaultValue = 10
WHERE TCD.Field.Id = 184

UPDATE TCD.Field
SET
    TCD.Field.Max = 16,
    TCD.Field.DefaultValue = 16
WHERE TCD.Field.Id = 200

UPDATE TCD.FieldGroupFieldMapping
SET
    FieldId = 200
WHERE Id = 122

UPDATE TCD.FieldGroupFieldMapping
SET
    FieldId = 61
WHERE Id = 287