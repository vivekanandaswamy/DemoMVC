﻿UPDATE CMCTM 
SET
    CMCTM.MaxConvProgramCount = 99, -- tinyint
    CMCTM.MaxTunnelProgramCount = 99 -- tinyint
FROM TCD.ControllerModelControllerTypeMapping CMCTM
INNER JOIN TCD.ControllerModel cm
ON CMCTM.ControllerModelId = CM.Id
INNER JOIN TCD.ControllerType ct
ON ct.Id = CMCTM.ControllerTypeId
WHERE CMCTM.ControllerModelId = 7

UPDATE CMCTM 
SET
    CMCTM.MaxConvProgramCount = 50, -- tinyint
    CMCTM.MaxTunnelProgramCount = 0 -- tinyint
FROM TCD.ControllerModelControllerTypeMapping CMCTM
INNER JOIN TCD.ControllerModel cm
ON CMCTM.ControllerModelId = CM.Id
INNER JOIN TCD.ControllerType ct
ON ct.Id = CMCTM.ControllerTypeId
WHERE CMCTM.ControllerModelId = 8
AND CMCTM.ControllerTypeId = 6

UPDATE CMCTM 
SET
    CMCTM.MaxConvProgramCount = 50, -- tinyint
    CMCTM.MaxTunnelProgramCount = 50 -- tinyint
FROM TCD.ControllerModelControllerTypeMapping CMCTM
INNER JOIN TCD.ControllerModel cm
ON CMCTM.ControllerModelId = CM.Id
INNER JOIN TCD.ControllerType ct
ON ct.Id = CMCTM.ControllerTypeId
WHERE CMCTM.ControllerModelId = 8
AND CMCTM.ControllerTypeId = 7

UPDATE CMCTM 
SET
    CMCTM.MaxConvProgramCount = 50, -- tinyint
    CMCTM.MaxTunnelProgramCount = 0 -- tinyint
FROM TCD.ControllerModelControllerTypeMapping CMCTM
INNER JOIN TCD.ControllerModel cm
ON CMCTM.ControllerModelId = CM.Id
INNER JOIN TCD.ControllerType ct
ON ct.Id = CMCTM.ControllerTypeId
WHERE CMCTM.ControllerModelId = 10

UPDATE CMCTM 
SET
    CMCTM.MaxConvProgramCount = 50, -- tinyint
    CMCTM.MaxTunnelProgramCount = 0 -- tinyint
FROM TCD.ControllerModelControllerTypeMapping CMCTM
INNER JOIN TCD.ControllerModel cm
ON CMCTM.ControllerModelId = CM.Id
INNER JOIN TCD.ControllerType ct
ON ct.Id = CMCTM.ControllerTypeId
WHERE CMCTM.ControllerModelId = 9
AND CMCTM.ControllerTypeId = 8

UPDATE CMCTM 
SET
    CMCTM.MaxConvProgramCount = 30, -- tinyint
    CMCTM.MaxTunnelProgramCount = 80 -- tinyint
FROM TCD.ControllerModelControllerTypeMapping CMCTM
INNER JOIN TCD.ControllerModel cm
ON CMCTM.ControllerModelId = CM.Id
INNER JOIN TCD.ControllerType ct
ON ct.Id = CMCTM.ControllerTypeId
WHERE CMCTM.ControllerModelId = 9
AND CMCTM.ControllerTypeId = 10

UPDATE CMCTM 
SET
    CMCTM.MaxConvProgramCount = 50, -- tinyint
    CMCTM.MaxTunnelProgramCount = 0 -- tinyint
FROM TCD.ControllerModelControllerTypeMapping CMCTM
INNER JOIN TCD.ControllerModel cm
ON CMCTM.ControllerModelId = CM.Id
INNER JOIN TCD.ControllerType ct
ON ct.Id = CMCTM.ControllerTypeId
WHERE CMCTM.ControllerModelId = 14
AND CMCTM.ControllerTypeId = 9

UPDATE CMCTM 
SET
    CMCTM.MaxConvProgramCount = 30, -- tinyint
    CMCTM.MaxTunnelProgramCount = 129 -- tinyint
FROM TCD.ControllerModelControllerTypeMapping CMCTM
INNER JOIN TCD.ControllerModel cm
ON CMCTM.ControllerModelId = CM.Id
INNER JOIN TCD.ControllerType ct
ON ct.Id = CMCTM.ControllerTypeId
WHERE CMCTM.ControllerModelId = 14
AND CMCTM.ControllerTypeId = 11

UPDATE CMCTM 
SET
    CMCTM.MaxConvProgramCount = 99, -- tinyint
    CMCTM.MaxTunnelProgramCount = 0 -- tinyint
FROM TCD.ControllerModelControllerTypeMapping CMCTM
INNER JOIN TCD.ControllerModel cm
ON CMCTM.ControllerModelId = CM.Id
INNER JOIN TCD.ControllerType ct
ON ct.Id = CMCTM.ControllerTypeId
WHERE CMCTM.ControllerModelId = 11
AND CMCTM.ControllerTypeId = 12

UPDATE CMCTM 
SET
    CMCTM.MaxConvProgramCount = 99, -- tinyint
    CMCTM.MaxTunnelProgramCount = 99 -- tinyint
FROM TCD.ControllerModelControllerTypeMapping CMCTM
INNER JOIN TCD.ControllerModel cm
ON CMCTM.ControllerModelId = CM.Id
INNER JOIN TCD.ControllerType ct
ON ct.Id = CMCTM.ControllerTypeId
WHERE CMCTM.ControllerModelId = 11
AND CMCTM.ControllerTypeId = 13

UPDATE CMCTM 
SET
    CMCTM.MaxConvProgramCount = 0, -- tinyint
    CMCTM.MaxTunnelProgramCount = 99 -- tinyint
FROM TCD.ControllerModelControllerTypeMapping CMCTM
INNER JOIN TCD.ControllerModel cm
ON CMCTM.ControllerModelId = CM.Id
INNER JOIN TCD.ControllerType ct
ON ct.Id = CMCTM.ControllerTypeId
WHERE CMCTM.ControllerModelId = 11
AND CMCTM.ControllerTypeId = 14

UPDATE CMCTM 
SET
    CMCTM.MaxConvProgramCount = 127, -- tinyint
    CMCTM.MaxTunnelProgramCount = 127 -- tinyint
FROM TCD.ControllerModelControllerTypeMapping CMCTM
INNER JOIN TCD.ControllerModel cm
ON CMCTM.ControllerModelId = CM.Id
INNER JOIN TCD.ControllerType ct
ON ct.Id = CMCTM.ControllerTypeId
WHERE CMCTM.ControllerModelId < 7
OR CMCTM.ControllerModelId IN (12,13)


IF (NOT EXISTS(SELECT 
			1 
		FROM [TCD].[ControllerEquipmentTypeModel] 
		WHERE ControllerEquipmentTypeModelName = 'Pump') )
   
BEGIN 
	INSERT INTO [TCD].[ControllerEquipmentTypeModel] (
			ControllerEquipmentTypeModelName, 
			ArtNumberLang, 
			TeoreticalCalibration,
			IsMEType
			) 
		VALUES (
				'Pump', 
				Null, 
				Null,
				1
			) 
END 

IF (NOT EXISTS(SELECT 
			1 
		FROM [TCD].[ControllerEquipmentTypeModel] 
		WHERE ControllerEquipmentTypeModelName = 'Washomix') )
   
BEGIN 
	INSERT INTO [TCD].[ControllerEquipmentTypeModel] (
			ControllerEquipmentTypeModelName, 
			ArtNumberLang, 
			TeoreticalCalibration,
			IsMEType
			) 
		VALUES (
				'Washomix', 
				Null, 
				Null,
				1
			) 
END 