IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[GetWasherBatchSummarizedData]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[GetWasherBatchSummarizedData] 
END 
GO 
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [TCD].[GetWasherBatchSummarizedData](  
    @DashBoardId int = NULL  
)   
AS   
BEGIN   
  
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED  
SET NOCOUNT ON  
  
   
DECLARE   --@DashBoardId int = 1, 
        @Washerid INT = NULL,   
        @Standardturntime INT = NULL,   
        @Machinenamedispalytype SMALLINT = 0,  
 @OverNightBatchThreshold int = 7200, -- Seconds  
 @EfficiencyType int  
  
 SELECT @EfficiencyType = ISNULL(EfficiencyCalcType,1) from tcd.Dashboard where DashboardId = @DashBoardId  
  
 DECLARE @Dashboardmachinemapping TABLE(  
  Id INT,   
  GroupID INT,  
  WasherId INT,  
  WasherName NVARCHAR(100),   
  WasherNumber INT)  
  
 DECLARE @AlarmByMachine TABLE(  
  GroupID INT,  
  WasherID INT,   
  Alarm BIT NULL,  
  AlarmDescription NVARCHAR(250))  
  
 DECLARE @BatchEndtimes TABLE(  
  GroupID INT,  
  WasherID INT,   
  CurrentBatchEndTime INT NULL,  
  BatchEndTime time)  
  
 Declare @ShiftIds table(  
    ShiftId int,  
    ShiftStartDate DATETIME,  
    ShiftEndDate datetime)  
  
 DECLARE @Summarizeddata TABLE(  
  GroupId INT,   
  MachineId INT,   
  WasherName NVARCHAR(100),   
  WasherNumber INT,   
  TargetLoad float,   
  ActualLoad float,   
  LoadEfficiency float,   
  TimeEfficiency float,   
  LostLoad float,   
  Alarm BIT,   
  AlarmDescription NVARCHAR(250),   
  WasherStatus INT,   
  MachineNameDispalyType SMALLINT,  
  TargetTurnTime INT,  
  DefaultIdleTime INT)  
  
 INSERT INTO @Dashboardmachinemapping(  
  Id,   
  GroupID,  
  WasherId,  
  WasherName,  
  WasherNumber)  
 SELECT  
  ROW_NUMBER()OVER(ORDER BY MS.GroupID)AS Id,   
  MS.GroupId,  
  MS.WasherID,  
  MS.MachineName,  
  W.PlantWasherNumber AS WasherNumber  
     FROM(SELECT DISTINCT  
    MachineId,   
    DashboardId  
  FROM TCD.MonitorSetUpMapping)AS DM  
  INNER JOIN TCD.MachineSetup AS MS ON DM.MachineId = MS.WasherID  
  INNER JOIN tcd.Washer AS W ON MS.WasherId = W.WasherId  
  INNER JOIN TCD.Dashboard AS D ON DM.DashBoardId = D.DashBoardId  
     WHERE DM.DashboardId = @Dashboardid  
       AND MS.IsDeleted = 0  
       AND w.Is_Deleted = 0  
    -- Exclude Phony Washers from Efficiency calculation   
       AND ms.WasherId NOT IN(SELECT  
          w.WasherId  
      FROM TCD.MachineSetup AS ms  
           INNER JOIN TCD.Washer AS w ON w.WasherId = ms.WasherId  
         AND ms.EcoalabAccountNumber = w.EcoLabAccountNumber  
      WHERE (NULLIF(ms.ControllerId, 0)IS NULL  
        AND w.WasherMode = 0)  
        OR MS.IsPony = 1  
        )  
  
  
 -- For efficiency calculations on shift wise  
 IF(@EfficiencyType = 1)  
  BEGIN  
      INSERT @ShiftIds(ShiftId,ShiftStartDate,ShiftEndDate)  
      SELECT DISTINCT ShiftId,StartDateTime, EndDateTime FROM TCD.ProductionShiftData  
   WHERE GETUTCDATE() BETWEEN StartDateTime AND EndDateTime   
  -- WHERE ShiftId = 1103  
      END  
        
 ELSE -- For efficiency calculations on Day wise  
  BEGIN  
   INSERT @ShiftIds(ShiftId,ShiftStartDate,ShiftEndDate)  
   SELECT ShiftId, StartDateTime, EndDateTime    
   FROM [TCD].ProductionShiftData    
   WHERE   startdatetime > CAST(GETUTCDATE()AS DATE ) and startdatetime < dateadd(dd,1,CAST(GETUTCDATE()AS DATE ))   
   ORDER BY startdatetime   
     
  END  



  
SELECT *   
INTO #BatchData  
FROM tcd.BatchData bd (NOLOCK) WHERE bd.ShiftId in (SELECT si.ShiftId FROM @ShiftIds si)  
AND bd.StandardWeight > 0  
and bd.ActualWeight > 0  
AND bd.EndDate IS NOT null

--select * from @ShiftIds
--select * from @Dashboardmachinemapping
--select * from #BatchData
  
-- Efficiency for each batch   
SELECT  bd.BatchId,  
  W_1.WasherGroupID AS GroupID,  
  W_1.WasherId AS MachineID,  
  bd.ShiftId,  
  W_1.WasherNumber,  
  W_1.WasherName,  
  (bd.ActualWeight + ISNULL(BD.ManualInputWeight,0)) AS ActualProduction,  
  bd.StandardWeight AS StandardProduction,  
  CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
   THEN W_1.StandardRunTime  
       ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
  END AS ActualRunTime,  
  W_1.StandardRunTime,  
  TT.ActualTurnTime,  
  bd.TargetTurnTime AS StandardTurnTime,  
  CASE WHEN W_1.WasherGroupTypeID = 1   
    -- Conventional  
    THEN (CAST((W_1.Standardruntime + bd.TargetTurnTime)AS FLOAT) / (CAST(CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
              THEN W_1.StandardRunTime  
              ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
             END   
    + CASE WHEN TT.ACTUALTURNTIME = 0 THEN bd.TargetTurnTime   
     ELSE TT.ACTUALTURNTIME  
      END  AS FLOAT)))  
    -- Tunnel  
   ELSE   
   (CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT) )  
    / (CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0   
          THEN W_1.Standardruntime   
          ELSE CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
            THEN W_1.StandardRunTime  
                ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
           END  
         END AS FLOAT)   
                )  
  END AS TimeEfficiency,  
  ((CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS FLOAT)/CAST(NULLIF(bd.StandardWeight,0) AS FLOAT)) * 100) AS LoadEfficiency,  
  CASE WHEN W_1.WasherGroupTypeID = 2   
      THEN  
  (100 * ((3600.00/(CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0   
       THEN NULLIF(W_1.Standardruntime,0)  
       ELSE DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
       END AS FLOAT)/W_1.NumberOfComp)) /  
       (3600.00/(CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT)/W_1.NumberOfComp))))  
   ELSE NULL  
  END AS TransferPerHr,  
  --missedloads formulae
		--------(((Actual Production/totalefficiency)*100)-actualproduction)
		
		(cast(cast(bd.ActualWeight AS decimal(18,6))/(((CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS decimal(18,6))/CAST(NULLIF(bd.StandardWeight,0) AS decimal(18,6))) * 100.0) 
  * (  CASE WHEN W_1.WasherGroupTypeID = 1   
      -- Conventional  
      THEN (CAST((W_1.Standardruntime + bd.TargetTurnTime)AS decimal(18,6)) / (CAST(CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
                   THEN W_1.StandardRunTime  
                   ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
                  END + TT.ACTUALTURNTIME AS FLOAT)))  
      -- Tunnel  
      ELSE   
						(CAST(NULLIF(W_1.Standardruntime,0) AS decimal(18,6)) )
							/ (CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0 
													THEN W_1.Standardruntime 
													ELSE CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold
														    THEN W_1.StandardRunTime
														    ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
													    END
												END AS decimal(18,6)) 
															    )
				END)) AS decimal(18,6))*100.0)-cast(bd.ActualWeight AS decimal(18,6)) AS MissedLoads,
  --((bd.StandardWeight - bd.ActualWeight) +  
  --(CASE WHEN W_1.WasherGroupTypeID = 1   
  --  THEN  
  --   ((CAST((CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
  --     THEN W_1.StandardRunTime  
  --         ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
  --    END + TT.ACTUALTURNTIME) AS FLOAT) - W_1.Standardruntime - bd.TargetTurnTime)   
  --   * CAST((CAST(bd.StandardWeight AS FLOAT)/NULLIF((W_1.Standardruntime + bd.TargetTurnTime),0)) AS FLOAT))   
  --  ELSE ((CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
  --    THEN W_1.StandardRunTime  
  --        ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
  --   END - W_1.Standardruntime) * (CAST(bd.StandardWeight AS FLOAT)/ NULLIF(W_1.Standardruntime,0)))  
  --END)) AS MissedLoads,  
  (((CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS FLOAT)/CAST(NULLIF(bd.StandardWeight,0) AS FLOAT)) * 100)   
  * (  CASE WHEN W_1.WasherGroupTypeID = 1   
      -- Conventional  
      THEN (CAST((W_1.Standardruntime + bd.TargetTurnTime)AS FLOAT) / (CAST(CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
                   THEN W_1.StandardRunTime  
                   ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
                  END + TT.ACTUALTURNTIME AS FLOAT)))  
      -- Tunnel  
      ELSE   
      (CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT))  
       / (CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0   
             THEN W_1.Standardruntime   
             ELSE CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
                  THEN W_1.StandardRunTime  
                  ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
                 END  
            END AS FLOAT)  
                   )  
    END)) AS TotalEfficiency  
  
  
INTO #BatchEfficiency  
FROM #BatchData bd
--FROM TCD.BatchData bd   
RIGHT OUTER JOIN(       
                SELECT ms.EcoalabAccountNumber,      
                        ms.WasherId,      
                        ms.GroupId AS WasherGroupID,      
                        mg.WasherGroupTypeId AS WasherGroupTypeID,      
                        w.EcolabWasherId,      
                        ISNULL(ms.NumberOfComp,0) AS NumberOfComp,      
                        CASE      
                        WHEN MG.WASHERGROUPTYPEID = 1 THEN WSP.ProgramNumber      
                            ELSE TPS.ProgramNumber      
                        END AS ProgramNumber,      
                        CASE      
                        WHEN MG.WASHERGROUPTYPEID = 1 THEN WSP.ProgramId      
       ELSE TPS.ProgramId      
                        END AS ProgramId,      
                        CASE      
       WHEN MG.WASHERGROUPTYPEID = 1   
    THEN WSP.TotalRunTime      
                            ELSE TPS.TotalRunTime      
   END AS Standardruntime,  
   w.PlantWasherNumber AS WasherNumber,  
   ms.MachineName AS WasherName,  
   mg.WasherGroupName AS MachineGroup  
   --mg.WasherGroupId AS MachineGroupID  
                    FROM TCD.MachineSetup AS ms (NOLOCK)      
                        INNER JOIN TCD.Washer AS w (NOLOCK) ON w.EcoLabAccountNumber = ms.EcoalabAccountNumber      
                                                    AND w.WasherId = ms.WasherId      
                        INNER JOIN TCD.WasherGroup AS mg (NOLOCK) ON ms.GroupId = mg.WasherGroupId      
                                                        AND w.EcoLabAccountNumber = mg.EcolabAccountNumber      
                        LEFT OUTER JOIN TCD.WasherProgramSetup AS WSP (NOLOCK) ON WSP.WasherGroupId = mg.WasherGroupId      
                                                                    AND WSP.EcolabAccountNumber = mg.EcolabAccountNumber      
                 AND WSP.Is_Deleted = 0  
                                                                    --AND WSP.WasherGroupId = ms.GroupId      
                        LEFT OUTER JOIN TCD.TunnelProgramSetup AS TPS (NOLOCK) ON TPS.WasherGroupId = mg.WasherGroupId      
                                                                    AND TPS.EcolabAccountNumber = mg.EcolabAccountNumber      
                 AND TPS.Is_Deleted = 0   
                                                                    --AND TPS.WasherGroupId = ms.GroupId   
   RIGHT JOIN @Dashboardmachinemapping DM1 ON DM1.GroupID = ms.GroupId   
      AND DM1.WasherId = ms.WasherId  
   WHERE ms.IsTunnel = 0   
   AND ms.IsDeleted = 0  
   ) AS W_1 ON BD.GroupId = W_1.WasherGroupID      
                                    AND ISNULL(BD.EcolabWasherId,0) = ISNULL(W_1.EcolabWasherId,0)  
        AND bd.MachineID = W_1.WasherId  
                                    AND BD.ProgramMasterId = W_1.ProgramId      
                                    AND BD.ProgramNumber = W_1.ProgramNumber  
LEFT JOIN [TCD].[Turntime] TT ON ISNULL(BD.EcolabwasherID,0) = ISNULL(TT.EcolabWasherId,0) AND BD.batchid = TT.BatchID  
WHERE DATEDIFF(ss, bd.StartDate, bd.EndDate) > (W_1.Standardruntime * 10/100)  
--bd.ShiftId IN (SELECT si.ShiftId FROM @ShiftIds si)  
--AND bd.ActualWeight > 0   
--AND bd.StandardWeight > 0  
--AND DATEDIFF(ss, bd.StartDate, bd.EndDate) > (W_1.Standardruntime * 10/100)  
--AND bd.EndDate IS NOT NULL   
  
  
 -- Efficiency by Machine calculation   
 SELECT DM.GroupID,   
  DM.WasherId AS MachineID,  
  DM.WasherNumber,  
  DM.WasherName,  
  CAST(sum(t.ActualProduction) AS FLOAT) AS ActualProduction,  
  CAST(sum(t.StandardProduction) AS FLOAT) AS StandardProduction,  
  SUM(t.ActualRunTime) AS ActualRuntime,  
  SUM(t.StandardRunTime) AS StandardRunTime,  
  (SUM(t.MissedLoads)/count(DISTINCT t.BatchId)) AS MissedLoads,  
  (CAST(sum(t.LoadEfficiency) AS FLOAT) / count(DISTINCT t.BatchId)) AS LoadEfficiency,  
  ((CAST(sum(t.TimeEfficiency) AS FLOAT) / count(DISTINCT t.BatchId))*100)  AS TimeEfficiency,  
  ((CAST(sum(t.LoadEfficiency) AS FLOAT) / count(DISTINCT t.BatchId)) * (CAST(sum(t.TimeEfficiency) AS FLOAT) / count(DISTINCT t.BatchId))) AS TotalEfficiency  
 INTO #MachineEfficiency  
 FROM @Dashboardmachinemapping DM   
 LEFT JOIN #BatchEfficiency t ON DM.GroupID = t.GroupId AND dm.WasherId = t.MachineId  
 --AND t.ActualRunTime > (t.StandardRunTime * 10/100)  
 GROUP BY DM.GroupID,   
 DM.WasherId,  
 DM.WasherNumber,  
 DM.WasherName  

--SELECT * FROM #BatchEfficiency
--SELECT * FROM #MachineEfficiency
  
/*  
 -- Efficiency by Machine calculation   
 SELECT t.GroupID,   
  t.MachineId,  
  t.WasherNumber,  
  t.WasherName,  
  CAST(sum(t.ActualProduction) AS FLOAT) AS ActualProduction,  
  CAST(sum(t.StandardProduction) AS FLOAT) AS StandardProduction,  
  SUM(t.ActualRunTime) AS ActualRuntime,  
  SUM(t.StandardRunTime) AS StandardRunTime,  
  (SUM(t.MissedLoads)/count(DISTINCT t.BatchId)) AS MissedLoads,  
  (CAST(sum(t.LoadEfficiency) AS FLOAT) / count(DISTINCT t.BatchId)) AS LoadEfficiency,  
  ((CAST(sum(t.TimeEfficiency) AS FLOAT) / count(DISTINCT t.BatchId))*100)  AS TimeEfficiency,  
  ((CAST(sum(t.LoadEfficiency) AS FLOAT) / count(DISTINCT t.BatchId)) * (CAST(sum(t.TimeEfficiency) AS FLOAT) / count(DISTINCT t.BatchId))) AS TotalEfficiency  
 INTO #MachineEfficiency  
 FROM #BatchEfficiency t  
 RIGHT JOIN @Dashboardmachinemapping DM ON DM.GroupID = t.GroupId   
      AND dm.WasherId = t.MachineId  
 WHERE ActualRunTime > (t.StandardRunTime * 10/100)  
 GROUP BY t.GroupID,   
 t.MachineId,  
 t.WasherNumber,  
 t.WasherName  
*/  
    
  
 INSERT @AlarmByMachine  
 (  
     GroupID,  
     WasherID,  
     Alarm,  
     AlarmDescription  
 )  
 SELECT AlarmByMachine.GroupID, AlarmByMachine.WasherID, AlarmByMachine.Alarm, AlarmByMachine.AlarmDescription   
 FROM (  
     SELECT ROW_NUMBER() OVER (PARTITION BY AD.MachineId ORDER BY AD.StartDate DESC) AS rownum  
     , AD.IsActive AS Alarm, AM.[Description] AS AlarmDescription  
     , AD.MachineId AS WasherID  
     , d.GroupID  
     FROM TCD.AlarmData AD   
     INNER JOIN TCD.AlarmMaster AM on AM.AlarmCode = AD.AlarmCode  
     INNER JOIN @Dashboardmachinemapping d ON AD.MachineId = D.WasherId  
     ) AS AlarmByMachine  
 WHERE rownum = 1  
  
 INSERT @BatchEndtimes  
 (  
     GroupID,  
     WasherID,  
     CurrentBatchEndTime,  
     BatchEndTime  
 )  
 SELECT d.GroupID, d.WasherId,   
 COUNT(CASE WHEN bd.EndDate IS NULL THEN 1 ELSE NULL END) AS CurrentBatchEndTime,  
 CAST(MAX(bd.EndDate) AS TIME) AS BatchEndTime  
 FROM @DashboardMachineMapping d  
 INNER JOIN TCD.BatchData bd ON d.GroupID = bd.GroupId AND d.WasherId = bd.MachineId  
 WHERE bd.ShiftId IN (  
 SELECT ShiftId FROM @ShiftIds)  
 GROUP BY d.GroupID, d.WasherId  
  
  
 SELECT @StandardTurnTime = ISNULL(ConStdTurnTime,30)  From tcd.Plant  
 SELECT @StandardTurnTime = @StandardTurnTime + ISNULL(TargetTurnTime,0)  From tcd.Washer Where WasherId = @WasherId  
  
 SELECT @MachineNameDispalyType=ISNULL( MachineNameDispalyType,0) FROM TCD.Dashboard D WHERE D.DashboardId=@DashBoardId  
  
  
 INSERT INTO @Summarizeddata(  
  GroupId,  
  MachineId,  
  WasherName ,  
  WasherNumber,  
  TargetLoad,  
  ActualLoad,  
  LoadEfficiency,  
  TimeEfficiency,  
  LostLoad,  
  Alarm,  
  AlarmDescription,  
  WasherStatus,  
  MachineNameDispalyType,  
  TargetTurnTime,  
  DefaultIdleTime  
  )  
  SELECT me.GroupID,  
  me.MachineID,  
  me.WasherName,  
  me.WasherNumber,  
  me.StandardProduction AS TargetLoad,  
  me.ActualProduction AS ActulaLoad,  
  me.LoadEfficiency,  
  me.TimeEfficiency,  
  me.MissedLoads AS LostLoad,  
  ISNULL(abm.Alarm,0) AS Alarm,  
  abm.AlarmDescription,  
  CASE   
      WHEN be.CurrentBatchEndTime = 1 THEN 1  
      WHEN CAST(GETUTCDATE() AS TIME) BETWEEN be.BatchEndTime AND DateAdd(Minute,@StandardTurnTime,be.BatchEndTime) THEN 2  
      WHEN abm.Alarm = 1 THEN 3  
      ELSE 3  
  END AS WasherStatus,  
  @MachineNameDispalyType,  
  ( SELECT TargetTurnTime FROM TCD.WASHER W WHERE W.WasherId=ME.MachineID),  
    ( SELECT DefaultIdleTime FROM TCD.WASHER W WHERE W.WasherId=ME.MachineID)  
  FROM #MachineEfficiency me  
  LEFT JOIN @AlarmByMachine abm on ME.GroupID = abm.GroupID AND ME.MachineID = ABM.WasherID  
  LEFT JOIN @BatchEndtimes be ON me.GroupID = be.GroupID AND me.MachineID = be.WasherID  
  
 SELECT  
  GroupId,   
  MachineId,   
  CASE @Machinenamedispalytype  
      WHEN 0 THEN CAST(WasherNumber AS VARCHAR(20)) + ' ' + WasherName  
      WHEN 1 THEN WasherName  
      WHEN 2 THEN CAST(WasherNumber AS VARCHAR(20))  
  END AS WasherName,   
  WasherNumber,   
  TargetLoad,   
  ActualLoad,   
  LoadEfficiency,   
  TimeEfficiency,   
  LostLoad,   
  Alarm,   
  AlarmDescription,   
  WasherStatus,  
  TargetTurnTime,  
  DefaultIdleTime  
     FROM @Summarizeddata  
     ORDER BY  
  WasherNumber  
  
  
---- CleanUp  
DROP TABLE #BatchData
DROP TABLE #BatchEfficiency  
DROP TABLE #MachineEfficiency  
  
END
GO




IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[GetBatchSummarizedData]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[GetBatchSummarizedData] 
END 
GO 
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[GetBatchSummarizedData] (  
            @DashBoardId INT = NULL   
            )   
  
AS   
BEGIN   
  
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED  
    SET NOCOUNT ON  
  
  
     DECLARE   --@DashBoardId INT = 2,
        @Efficiencytype INT,  
 @OvernightBatchThreshold INT = 7200 -- mins  
      
     DECLARE @DashboardMachineMapping TABLE(  
         Id INT,  
         GroupId INT,  
         WasherId INT,  
         DisplayCustomer BIT,  
  WasherName NVARCHAR(100),   
  WasherNumber INT)  
  
      DECLARE @Summarizeddata TABLE(  
        GroupId INT,  
        TunnelName Nvarchar(100),  
        TargetLoad FLOAT,  
        ActualLoad FLOAT,  
 LoadEfficiency FLOAT,  
        TimeEfficiency FLOAT,  
        LostLBS FLOAT,  
        TransferPerHr FLOAT,  
        SignalStatus INT,          
        EmptyPockets INT,  
        Alarm Bit,  
        TransferPercent DECIMAL(10,2),  
        EndOfFormula INT,  
        DisplayCustomer BIT,  
        WasherNumber INT  
        )  
          
 DECLARE @ShiftIds TABLE(  
 ShiftId INT,  
 ShiftStartDate DATETIME,  
 ShiftEndDate DATETIME  
 )  
  
 SELECT  
  @Efficiencytype = ISNULL(EfficiencyCalcType, 1)  
     FROM tcd.Dashboard  
     WHERE DashboardId = @Dashboardid  
  
      INSERT INTO @DashboardMachineMapping  
        (  
            Id,  
            GroupId,  
            WasherId,  
     DisplayCustomer,  
     WasherName,  
     WasherNumber  
        )  
    SELECT   
    ROW_NUMBER() OVER(ORDER BY GroupID) AS Id,  
    A.GroupId,  
    A.WasherId,  
    A.Customer,  
    A.WasherName,  
    A.WasherNumber  
    FROM  
    (SELECT DISTINCT  
       MS.GroupId,MS.WasherId,D.Customer,MS.MachineName AS WasherName, w.PlantWasherNumber AS WasherNumber  
     FROM TCD.MonitorSetUpMapping DM   
        INNER JOIN TCD.MachineSetup MS ON DM.MachineId = MS.WasherID  
        INNER JOIN TCD.Dashboard D on DM.DashBoardId = D.DashBoardId  
 INNER JOIN TCD.Washer w ON ms.WasherId = w.WasherId  
    WHERE DM.DashboardId = @DashBoardId  
    AND ms.IsDeleted = 0  
    AND w.Is_Deleted = 0   
    )A;  
   
  
  
 -- For efficiency calculations on shift wise  
 IF @Efficiencytype = 1  
     BEGIN  
  
  INSERT INTO @Shiftids(shiftId,ShiftStartDate, ShiftEndDate)  
  SELECT DISTINCT ShiftId, StartDateTime, EndDateTime  
  FROM TCD.ProductionShiftData  
  --WHERE ShiftId = 1103  
  WHERE GETUTCDATE() BETWEEN StartDateTime AND EndDateTime   
  
     END  
 ELSE -- For efficiency calculations on Day wise  
     BEGIN  
  
  INSERT @Shiftids(ShiftId, ShiftStartDate, ShiftEndDate)  
  SELECT DISTINCT ShiftId, StartDateTime, EndDateTime  
  FROM TCD.ProductionShiftData  
  WHERE startdatetime > CAST(GETUTCDATE()AS DATE)  
  AND startdatetime < DATEADD(dd, 1, CAST(GETUTCDATE()AS DATE))  
  
     END    

--select * from @ShiftIds
--select * from @DashboardMachineMapping
  
  
SELECT *   
INTO #BatchData  
FROM tcd.BatchData bd (NOLOCK) WHERE bd.ShiftId in (SELECT si.ShiftId FROM @ShiftIds si)  
AND bd.StandardWeight > 0  
and bd.ActualWeight > 0   
AND bd.EndDate IS NOT null


--select * from #BatchData  
  
-- Efficiency for each batch   
SELECT  bd.BatchId,  
  bd.GroupID,  
  bd.MachineID,  
  bd.ShiftId,  
  W_1.WasherNumber,  
  W_1.WasherName,  
  (bd.ActualWeight + ISNULL(BD.ManualInputWeight,0)) AS ActualProduction,  
  bd.StandardWeight AS StandardProduction,  
  --DATEDIFF(ss,bd.StartDate, bd.EndDate) AS ActualRunTime,  
  CASE WHEN DATEDIFF(mi,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OvernightBatchThreshold   
   THEN W_1.Standardruntime   
       ELSE DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
  END AS ActualRunTime,  
  W_1.StandardRunTime,  
  NULL AS ActualTurnTime,  
  bd.TargetTurnTime AS StandardTurnTime,  
  CASE WHEN W_1.WasherGroupTypeID = 2   THEN
    ---- Conventional  
    --THEN (CAST((W_1.Standardruntime + bd.TargetTurnTime)AS FLOAT) / (CAST(CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
    --          THEN W_1.StandardRunTime  
    --          ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
    --         END   
    --+ CASE WHEN TT.ACTUALTURNTIME = 0 THEN bd.TargetTurnTime   
    -- ELSE TT.ACTUALTURNTIME  
    --  END  AS FLOAT)))  
    ---- Tunnel  
   --ELSE   
   (CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT) )  
    / (CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0   
          THEN W_1.Standardruntime   
          ELSE CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
            THEN W_1.StandardRunTime  
                ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
           END  
         END AS FLOAT)   
                )  
  END AS TimeEfficiency,  
  ((CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS FLOAT)/CAST(NULLIF(bd.StandardWeight,0) AS FLOAT)) * 100) AS LoadEfficiency,  
  CASE WHEN W_1.WasherGroupTypeID = 2   
      THEN  
  (3600.00/(CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0   
       THEN NULLIF(W_1.Standardruntime,0)  
       ELSE DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
       END AS FLOAT)/W_1.NumberOfComp))   
   ELSE NULL  
  END AS TransferPerHr,  
  
  --missedloads formulae
		--------(((Actual Production/totalefficiency)*100)-actualproduction)
		
		(cast((cast(bd.ActualWeight AS decimal(18,6))/(((CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS decimal(18,6))/CAST(NULLIF(bd.StandardWeight,0) AS decimal(18,2))) * 100.0) 
  * (  CASE WHEN W_1.WasherGroupTypeID = 2   THEN
      ---- Conventional  
      --THEN (CAST((W_1.Standardruntime + bd.TargetTurnTime)AS FLOAT) / (CAST(CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
      --             THEN W_1.StandardRunTime  
      --             ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
      --            END + TT.ACTUALTURNTIME AS FLOAT)))  
      ---- Tunnel  
      --ELSE   
						(CAST(NULLIF(W_1.Standardruntime,0) AS decimal(18,6)) )
							/ (CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0 
													THEN W_1.Standardruntime 
													ELSE CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold
														    THEN W_1.StandardRunTime
														    ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
													    END
												END AS decimal(18,6)) 
															    )
				END))) AS decimal(18,6))*100.0)-cast(bd.ActualWeight AS decimal(18,6)) AS MissedLoads,
 -- ((bd.StandardWeight - bd.ActualWeight) +  
 -- (CASE WHEN W_1.WasherGroupTypeID = 2 THEN   
 --   --THEN  
 --   -- ((CAST((CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
 --   --   THEN W_1.StandardRunTime  
 --   --       ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
 --   --  END + TT.ACTUALTURNTIME) AS FLOAT) - W_1.Standardruntime - bd.TargetTurnTime)   
 --   -- * CAST((CAST(bd.StandardWeight AS FLOAT)/NULLIF((W_1.Standardruntime + bd.TargetTurnTime),0)) AS FLOAT))   
 --   --ELSE 
	--((CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
 --     THEN W_1.StandardRunTime  
 --         ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
 --    END - W_1.Standardruntime) * (CAST(bd.StandardWeight AS FLOAT)/ NULLIF(W_1.Standardruntime,0)))  
 -- END)) AS MissedLoads,  
  (((CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS FLOAT)/CAST(NULLIF(bd.StandardWeight,0) AS FLOAT)) * 100)   
  * (  CASE WHEN W_1.WasherGroupTypeID = 2   THEN
      ---- Conventional  
      --THEN (CAST((W_1.Standardruntime + bd.TargetTurnTime)AS FLOAT) / (CAST(CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
      --             THEN W_1.StandardRunTime  
      --             ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
      --            END + TT.ACTUALTURNTIME AS FLOAT)))  
      ---- Tunnel  
      --ELSE   
      (CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT) )  
       / (CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0   
             THEN W_1.Standardruntime   
             ELSE CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
                  THEN W_1.StandardRunTime  
                  ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
                 END  
            END AS FLOAT)   
                   )  
    END)) AS TotalEfficiency  
  
INTO #BatchEfficiency  
FROM #BatchData bd  
--FROM TCD.BatchData bd   
INNER JOIN(       
                SELECT ms.EcoalabAccountNumber,      
                        ms.WasherId,      
                        ms.GroupId AS WasherGroupID,      
                        mg.WasherGroupTypeId AS WasherGroupTypeID,      
                        w.EcolabWasherId,      
                        ISNULL(ms.NumberOfComp,0) AS NumberOfComp,      
                        CASE      
                        WHEN MG.WASHERGROUPTYPEID = 1 THEN WSP.ProgramNumber      
                            ELSE TPS.ProgramNumber      
                        END AS ProgramNumber,      
                        CASE      
                        WHEN MG.WASHERGROUPTYPEID = 1 THEN WSP.ProgramId      
       ELSE TPS.ProgramId      
                        END AS ProgramId,      
                        CASE      
       WHEN MG.WASHERGROUPTYPEID = 1   
    THEN WSP.TotalRunTime      
                            ELSE TPS.TotalRunTime      
   END AS Standardruntime,  
   w.PlantWasherNumber AS WasherNumber,  
   ms.MachineName AS WasherName,  
   mg.WasherGroupName AS MachineGroup,  
   ms.IsTunnel  
   --mg.WasherGroupId AS MachineGroupID  
                    FROM TCD.MachineSetup AS ms (NOLOCK)      
                        INNER JOIN TCD.Washer AS w (NOLOCK) ON w.EcoLabAccountNumber = ms.EcoalabAccountNumber      
                                                    AND w.WasherId = ms.WasherId      
                        INNER JOIN TCD.WasherGroup AS mg (NOLOCK) ON ms.GroupId = mg.WasherGroupId      
                                                        AND w.EcoLabAccountNumber = mg.EcolabAccountNumber      
                        LEFT OUTER JOIN TCD.WasherProgramSetup AS WSP (NOLOCK) ON WSP.WasherGroupId = mg.WasherGroupId      
                                                                    AND WSP.EcolabAccountNumber = mg.EcolabAccountNumber      
                                                                    --AND WSP.WasherGroupId = ms.GroupId      
                 AND WSP.Is_Deleted = 0  
                        LEFT OUTER JOIN TCD.TunnelProgramSetup AS TPS (NOLOCK) ON TPS.WasherGroupId = mg.WasherGroupId      
                                                                    AND TPS.EcolabAccountNumber = mg.EcolabAccountNumber      
                                                                    --AND TPS.WasherGroupId = ms.GroupId   
                 AND TPS.Is_Deleted = 0   
   WHERE ms.IsTunnel = 1  
   ) AS W_1 ON BD.GroupId = W_1.WasherGroupID      
       AND BD.MachineId = W_1.WasherId      
       AND BD.ProgramMasterId = W_1.ProgramId      
       AND BD.ProgramNumber = W_1.ProgramNumber  
--LEFT JOIN [TCD].[Turntime] TT (NOLOCK) ON --ISNULL(BD.EcolabwasherID,0) = ISNULL(TT.EcolabWasherId,0)   
--    BD.batchid = TT.BatchID   
    --AND bd.MachineId = tt.MachineId  
--WHERE bd.ShiftId IN (SELECT si.ShiftId FROM @ShiftIds si)  
--AND bd.ActualWeight > 0   
--AND bd.StandardWeight > 0  
--AND DATEDIFF(ss, bd.StartDate, bd.EndDate) > (W_1.Standardruntime * 10/100)  
--AND bd.EndDate IS NOT NULL  
  
  
  
 -- Efficiency by Machine calculation   
 SELECT DM.GroupID,   
  DM.WasherId AS MachineID,  
  DM.WasherNumber,  
  DM.WasherName,  
  CAST(sum(t.ActualProduction) AS FLOAT) AS ActualProduction,  
  CAST(sum(t.StandardProduction) AS FLOAT) AS StandardProduction,  
  SUM(t.ActualRunTime) AS ActualRuntime,  
  SUM(t.StandardRunTime) AS StandardRunTime,  
  (SUM(t.MissedLoads)) AS MissedLoads,  
  (CAST(sum(t.LoadEfficiency) AS FLOAT) / count(DISTINCT t.BatchId)) AS LoadEfficiency,  
  (CAST(sum(t.TimeEfficiency) AS FLOAT) / count(DISTINCT t.BatchId)) AS TimeEfficiency,  
  (CAST(SUM(t.TransferPerHr) AS FLOAT)/ count(DISTINCT t.BatchId)) AS TransferPerHour,  
  ((CAST(sum(t.LoadEfficiency) AS FLOAT) / count(DISTINCT t.BatchId)) * (CAST(sum(t.TimeEfficiency) AS FLOAT) / count(DISTINCT t.BatchId))) AS TotalEfficiency  
 INTO #MachineEfficiency  
 FROM @Dashboardmachinemapping DM   
 LEFT JOIN #BatchEfficiency t ON DM.GroupID = t.GroupId AND dm.WasherId = t.MachineId  
 GROUP BY DM.GroupID,   
  DM.WasherId,  
  DM.WasherNumber,  
  DM.WasherName  
  
  
      DECLARE @EmptyPocketNAlarmddata TABLE(  
     GroupId INT,  
     WasherID INT,  
     EndOfFormula  INT,  
     DisplayCustomer Decimal(18,2),  
     EmptyPockets INT,  
     MachineNameDispalyType INT,  
     EmptyPocketLoad Decimal(18,2),  
     Alarm bit,  
     WasherStatus bit  
 )  
  
    INSERT @EmptyPocketNAlarmddata    (GroupId,WasherID,EndOfFormula,DisplayCustomer,EmptyPockets,MachineNameDispalyType, EmptyPocketLoad,Alarm,WasherStatus)  
    SELECT  D.GroupId,   
     D.WasherId,   
     w.EmptyPocketNumber AS EndOfFormula,   
     D.DisplayCustomer,   
     A.EmptyPockets,   
     (SELECT SUM(ISNULL(MachineNameDispalyType,0)) FROM TCD.Dashboard D1  
  INNER JOIN TCD.[MonitorSetUpMapping] MSM ON D1.DashboardId=MSM.DashboardId    
  WHERE MSM.MachineId=D.WasherId and D1.DashboardId=@DashBoardId  
  ) as MachineNameDispalyType,  
     sum(w.MaxLoad) AS EmptyPocketLoad,  
     NULL AS alarm,  
     sum(CASE WHEN B.WasherStatus > 0 THEN 1 ELSE 0 END) AS WasherStatus  
    FROM TCD.Washer AS w   
    INNER JOIN @DashboardMachineMapping AS D ON w.WasherId = d.WasherId  
    CROSS APPLY  (  
 SELECT COUNT(*) As EmptyPockets from TCD.BatchData AS b JOIN @ShiftIds AS s ON b.ShiftId = s.ShiftId   
 WHERE b.StartDate >= s.ShiftStartDate   
 AND b.GroupId = d.GroupId   
 AND b.ProgramNumber = w.EmptyPocketNumber  
       ) AS A  
    CROSS APPLY (  
 SELECT Count(*) as WasherStatus  
 from tcd.BatchData where MachineId = d.WasherId AND GroupId= D.GroupId and (EndDate >= DATEADD(mi,-30,GETUTCDATE()) OR EndDate is NULL)  
 ) AS B  
    GROUP BY D.GroupId, D.WasherId, w.EmptyPocketNumber, D.DisplayCustomer, A.EmptyPockets  
  
  
    UPDATE X   
    SET X.Alarm = ISNULL(Alarm.IsActive,0)  
    FROM @EmptyPocketNAlarmddata X  
    CROSS APPLY (   
 SELECT TOP 1 AD.IsActive  
     FROM [TCD].AlarmData AD   
     WHERE GroupId = X.GroupId  
     ORDER BY StartDate DESC  
  ) AS Alarm  
  
  
  
INSERT INTO @Summarizeddata(GroupId,TunnelName,TargetLoad,ActualLoad,LoadEfficiency, TimeEfficiency,  
        LostLBS,TransferPerHr,SignalStatus,EmptyPockets,Alarm,TransferPercent,EndOfFormula,DisplayCustomer,WasherNumber)  
 SELECT  me.GroupID,   
  CASE epn.MachineNameDispalyType   
     WHEN 0 THEN CAST( me.WasherNumber AS varchar(20))+' '+  me.WasherName  
     WHEN 1 THEN me.WasherName  
     WHEN 2 THEN CAST( me.WasherNumber AS varchar(20))          
  END AS TunnelName,  
  me.StandardProduction,   
  me.ActualProduction,   
  me.LoadEfficiency,  
  me.TimeEfficiency,   
  me.MissedLoads,  
  me.TransferPerHour,  
  epn.WasherStatus,  
  epn.EmptyPockets,  
  ISNULL(epn.Alarm,0) AS Alarm,  
  0 AS TransferPercent,  
  epn.EndOfFormula,  
  epn.DisplayCustomer,  
  me.WasherNumber  
 from #MachineEfficiency me  
 LEFT JOIN @EmptyPocketNAlarmddata epn ON me.GroupID = epn.GroupId AND me.MachineID = epn.WasherID  
   
     SELECT  GroupId,  
     TunnelName,  
     TargetLoad,  
     ActualLoad,  
     LoadEfficiency,  
     TimeEfficiency,  
     LostLBS,  
     TransferPerHr,  
     SignalStatus,          
     EmptyPockets,  
     Alarm,  
     TransferPercent,  
     EndOfFormula,  
     DisplayCustomer,  
     WasherNumber  
    FROM @Summarizeddata    
    ORDER BY WasherNumber  
  
-- CleanUp  
DROP TABLE #BatchData
DROP TABLE #BatchEfficiency  
DROP TABLE #MachineEfficiency  
  
END
GO



IF EXISTS(SELECT
				  * FROM sys.views WHERE object_id = OBJECT_ID(N'[TCD].[Turntime]')
									 AND type = N'V')
	BEGIN
		DROP VIEW
				TCD.Turntime
	END
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

   
   
CREATE VIEW [TCD].[Turntime]
AS
       
        
WITH CTE_TurnTime  
AS (  
SELECT
     ROW_NUMBER() OVER(PARTITION BY BD.ECOLABWASHERID ORDER BY BD.STARTDATE) AS ROWNUMBER,  
     BD.ECOLABWASHERID,
     BD.BATCHID,
     STARTDATE,
     ENDDATE,
     BD.TARGETTURNTIME , 
     W.DEFAULTIDLETIME,
     BD.GROUPID,
    BD.MachineId
    FROM TCD.BATCHDATA AS BD WITH (NOLOCK)
     INNER JOIN TCD.WASHER AS W           ON BD.MachineId = W.WasherID  
                                                      AND isnull(BD.EcolabWasherId,0) = isnull(W.EcolabWasherId,0)  
     INNER JOIN TCD.WASHERGROUP AS WG     ON WG.WASHERGROUPID=BD.GROUPID  
                                                            AND W.ECOLABACCOUNTNUMBER = WG.ECOLABACCOUNTNUMBER  
     INNER JOIN TCD.MACHINESETUP AS MS    ON MS.GroupId = WG.WasherGroupId  
                                                            AND ms.WasherId = W.WasherId  
                                                            AND w.EcoLabAccountNumber = ms.EcoalabAccountNumber  
    WHERE BD.PROGRAMMASTERID <> 0
    AND WG.WASHERGROUPTYPEID=1
)  
   
SELECT CurBatch.BATCHID  
, CurBatch.ECOLABWASHERID  
,CurBatch.ENDDATE  
,nextBatch.STARTDATE 
, CurBatch.MachineId
, CASE  
      WHEN (DATEDIFF(SECOND,CurBatch.ENDDATE,ISNULL(nextBatch.STARTDATE, GETDATE())) <= 0 or DATEDIFF(minute,CurBatch.ENDDATE,ISNULL(nextBatch.STARTDATE, GETDATE())) > CurBatch. defaultidletime)  
      --OR DATEDIFF(hh,CurBatch.ENDDATE,ISNULL(nextBatch.STARTDATE, GETDATE())) > 2)  
      THEN nextBatch.TARGETTURNTIME  
      ELSE DATEDIFF(SECOND,CurBatch.ENDDATE, nextBatch.STARTDATE)  
      END AS ActualTurnTime  
FROM CTE_TurnTime CurBatch  
LEFT JOIN CTE_TurnTime nextBatch ON isnull(CurBatch.ECOLABWASHERID,0) = isnull(nextBatch.ECOLABWASHERID,0)
AND CurBatch.MachineId = nextBatch.MachineId
		  AND CurBatch.GROUPID = nextBatch.GROUPID  
AND CurBatch.ROWNUMBER + 1 = nextBatch.ROWNUMBER  





GO



IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[GetTagManamenetDetails]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[GetTagManamenetDetails] 
END 
GO 
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[GetTagManamenetDetails] 
@ControllerId INT,
@EcolabAccountNumber NVARCHAR(25),
@UserId INT

AS
BEGIN 
DECLARE @Active INT = 1,
    @TankModuleTypeId INT,
    @SensorModuleTypeId INT,
    @PumpModuleTypeId INT,
    @LangunageId INT,
    @SplChars VARCHAR(50)   = ' # -',
    @LocaliseValue VARCHAR(200),
    @FactorMultiplier INT,
    @TimeVolumeMultipler INT,
 @ControllerModelId int


SELECT @TankModuleTypeId=mty.ModuleTypeId FROM TCD.ModuleType mty WHERE mty.ModuleDescription='Tank'
SELECT @SensorModuleTypeId=mty.ModuleTypeId FROM TCD.ModuleType mty WHERE mty.ModuleDescription='Sensor'
SELECT @PumpModuleTypeId=mty.ModuleTypeId FROM TCD.ModuleType mty WHERE mty.ModuleDescription='Pumps/Valves'
SELECT @LangunageId=p.languageID FROM TCD.Plant p WHERE p.EcolabAccountNumber=@EcolabAccountNumber


 SELECT @TimeVolumeMultipler= CAST(csd.[Value] AS decimal(18,0)) FROM TCD.ControllerSetupData csd 
 INNER JOIN TCD.Field f ON f.Id = csd.FieldId 
 WHERE csd.FieldId IN(SELECT f2.Id FROM TCD.Field f2 WHERE f2.Label LIKE '%OZ/Second Multiplier%') 
    AND csd.ControllerId=@ControllerId 
    AND csd.EcolabAccountNumber=@EcolabAccountNumber 
 AND ISNUMERIC(csd.[Value]) = 1

 SELECT @FactorMultiplier= CAST(csd.[Value] AS decimal(18,0)) FROM TCD.ControllerSetupData csd 
 INNER JOIN TCD.Field f ON f.Id = csd.FieldId 
 WHERE csd.FieldId IN(SELECT f2.Id FROM TCD.Field f2 WHERE f2.Label LIKE '%Factors Multiplier%') 
    AND csd.ControllerId=@ControllerId
    AND csd.EcolabAccountNumber=@EcolabAccountNumber 
 AND ISNUMERIC(csd.[Value]) = 1

SELECT @ControllerModelId=ControllerModelId FROM tcd.ConduitController cc WHERE ControllerId=@ControllerId


CREATE TABLE #tmpTagManagementDetails
(
  Id INT
 ,TagAddress VARCHAR(100)
 ,[Description] VARCHAR(1000)
 ,Value VARCHAR(500)
 ,LastModifiedTime DATETIME 
 ,ColName VARCHAR(500)
 ,DataType varchar(100)
 ,RowNumber decimal(3,2)
 ,OriginalColumnName varchar(100)
 ,EntityType varchar(100)
 ,TagType varchar(100)
 ,ControllerEquipmentSetupId varchar(100)
 ,SortingOrder varchar(100)
)


--SELECT @LocaleValue=rkv.[Value] FROM TCD.ResourceKeyMaster rkm 
--    INNER JOIN TCD.ResourceKeyValue rkv on rkv.ResourceId = rkm.ResourceId 
--where rkm.[Key] ='FIELD_'+ UPPER(@KeyValue) 
--  AND 
--rkv.languageID=ISNULL((SELECT um.LanguageId FROM TCD.UserMaster um WHERE um.UserId=@UserId),(SELECT p.LanguageId FROM TCD.Plant p WHERE p.EcolabAccountNumber=@EcolabAccountNumber)) 


--------------------------------------
-- StorageTanks---
--------------------------------------

INSERT INTO #tmpTagManagementDetails(Id, TagAddress,    [Description],    [Value],    LastModifiedTime,colName,DataType,RowNumber,OriginalColumnName
 ,EntityType,TagType,ControllerEquipmentSetupId,SortingOrder)

----------------------------------------------------------------
-- Conventional-AND-Tunnel(AWEA, EOF, MODE to be displayed)-----
----------------------------------------------------------------
SELECT ms.WasherId, wt.TagAddress,ms.MachineName,Convert(varchar(100), CONVERT(int, w.EndOfFormula)),w.LastModifiedTime ,'EndofFormulaNumber',tt.DataType,1,
'EndOfFormula' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType,ms.MachineInternalId as ControllerEquipmentSetupId, 0 as SortingOrder 
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId) AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_EOF' AND ms.IsTunnel IN (0,1)
UNION

SELECT ms.WasherId, wt.TagAddress,ms.MachineName,Convert(varchar(100), CONVERT(int, w.WasherMode)),w.LastModifiedTime ,'WasherMode',tt.DataType,1
,'WasherMode' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType,ms.MachineInternalId as ControllerEquipmentSetupId, 0 as SortingOrder  
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_MODE' AND ms.IsTunnel IN (0,1)
UNION

SELECT ms.WasherId, wt.TagAddress,ms.MachineName,Convert(varchar(100), CONVERT(int, w.AWEActive)),w.LastModifiedTime ,'AWEActive',tt.DataType,1
,'AWEActive' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType,ms.MachineInternalId as ControllerEquipmentSetupId , 0 as SortingOrder 
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_AWEA' AND ms.IsTunnel IN (0,1)
UNION

SELECT ms.WasherId, wt.TagAddress,ms.MachineName,Convert(varchar(100), CONVERT(int, w.HoldDelay)),w.LastModifiedTime ,'HoldDelay',tt.DataType,1
,'HoldDelay' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType, ms.MachineInternalId as ControllerEquipmentSetupId , 0 as SortingOrder

FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId  AND wt.Active=@Active  AND wt.TagType='Tag_HOLDD' AND ms.IsTunnel=0 
UNION

SELECT ms.WasherId, wt.TagAddress,ms.MachineName,Convert(varchar(100), CONVERT(int, w.WaterFlushTime)),w.LastModifiedTime , 'WaterFlushTime' ,tt.DataType,1
,'WaterFlushTime' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType, ms.MachineInternalId as ControllerEquipmentSetupId, 0 as SortingOrder  
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_FLSHT' AND ms.IsTunnel=0
UNION

SELECT ms.WasherId, wt.TagAddress,ms.MachineName,Convert(varchar(100), CONVERT(int, w.RatioDosingActive)),w.LastModifiedTime, 'RatioDosingActive',tt.DataType,1
,'RatioDosingActive' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType, ms.MachineInternalId as ControllerEquipmentSetupId, 0 as SortingOrder  
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_RATA' AND ms.IsTunnel=0
UNION

------------------------------------
---- Tanks---
------------------------------------
SELECT ts.TankId AS Id, mt.TagAddress AS TagAddress,   ts.TankName AS [Description],Convert(varchar(10),Convert(int,( ts.Size))) AS Value,   
ts.LastModifiedTime , 'Size',tt.DataType,1
,'Size-Size_Display' as OriginalColumnName,'[TCD].[TankSetup]' as EntityName,tt.TagType as TagType, 0 as ControllerEquipmentSetupId  , 0 as SortingOrder

FROM   TCD.ModuleTags mt INNER JOIN TCD.TankSetup ts ON ts.TankId=mt.ModuleId
Inner Join tcd.TagType tt on mt.TagType = tt.TagType

WHERE   mt.ModuleTypeId=@TankModuleTypeId    AND ts.ControllerId=@ControllerId     AND mt.Active=@Active    AND mt.TagType='Tag_SIZ' 
UNION

SELECT ts.TankId,mt.TagAddress,ts.TankName,Convert(varchar(100),Convert(int,( ts.LevelDeviation_Display))),ts.LastModifiedTime ,'Dead Band',tt.DataType,1
,'LevelDeviation-LevelDeviation_Display' as OriginalColumnName,'[TCD].[TankSetup]' as EntityName,tt.TagType as TagType, 0 as SortingOrder, 0 as ControllerEquipmentSetupId  

FROM    TCD.ModuleTags mt 
INNER JOIN  TCD.TankSetup ts ON ts.TankId=mt.ModuleId
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE   mt.ModuleTypeId=@TankModuleTypeId 
    AND ts.ControllerId=@ControllerId 
    AND mt.Active=@Active 
    AND mt.TagType='Tag_DEV' 
UNION
----------------------------------------
---- Meter---
----------------------------------------

----------------------------------------
---- Sensor---
----------------------------------------
SELECT s.SensorId,mt.TagAddress,s.[Description],CONVERT(VARCHAR(100),CAST(s.Calibration4mA as float)),s.LastModifiedTime ,'Calibration4mA',tt.DataType,3
,'Calibration4mA' as OriginalColumnName,'[TCD].[Sensor]' as EntityName,tt.TagType as TagType, 0 as ControllerEquipmentSetupId, 0 as SortingOrder  
from TCD.ModuleTags mt INNER JOIN TCD.Sensor s ON MT.ModuleId=s.SensorId 
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE mt.ModuleTypeId=@SensorModuleTypeId AND s.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_SC4'

UNION

SELECT s.SensorId,mt.TagAddress,s.[Description],CONVERT(VARCHAR(100),CAST(s.Calibration20mA as float)),s.LastModifiedTime , 'Calibration20mA',tt.DataType,3
,'Calibration20mA' as OriginalColumnName,'[TCD].[Sensor]' as EntityName,tt.TagType as TagType, 0 as ControllerEquipmentSetupId, 0 as SortingOrder  
from TCD.ModuleTags mt INNER JOIN TCD.Sensor s ON MT.ModuleId=s.SensorId 
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE mt.ModuleTypeId=@SensorModuleTypeId AND s.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_SC20' 
UNION
--------------------------------------
-- Pumps---
--------------------------------------



SELECT  Convert(int, ces.ControllerEquipmentSetupId), mt.TagAddress,'P/V'+Convert(varchar(100), ces.ControllerEquipmentId),
Convert(varchar(100),Convert(float, ces.KFactor * @FactorMultiplier)),ces.LastModifiedTime ,'K-Factor',tt.DataType,2
,'KFactor' as OriginalColumnName,'[TCD].[ControllerEquipmentSetup]' as EntityName,tt.TagType as TagType, ControllerEquipmentId as ControllerEquipmentSetupId, 1 as SortingOrder   

FROM TCD.ModuleTags mt INNER JOIN TCD.ControllerEquipmentSetup ces ON mt.ModuleId=ces.ControllerEquipmentSetupId 
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE mt.ModuleTypeId=@PumpModuleTypeId AND ces.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_PPOL'
UNION
SELECT  Convert(int, ces.ControllerEquipmentSetupId), mt.TagAddress,'P/V'+Convert(varchar(100), ces.ControllerEquipmentId),
Convert(varchar(100),Convert(float, ces.PumpCalibration *@TimeVolumeMultipler)),ces.LastModifiedTime, 'Time Volume Calibration',tt.DataType,2
,'PumpCalibration' as OriginalColumnName,'[TCD].[ControllerEquipmentSetup]' as EntityName,tt.TagType as TagType , ControllerEquipmentId as  ControllerEquipmentSetupId, 3 as SortingOrder 
FROM TCD.ModuleTags mt INNER JOIN TCD.ControllerEquipmentSetup ces ON mt.ModuleId=ces.ControllerEquipmentSetupId
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE mt.ModuleTypeId=@PumpModuleTypeId AND ces.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_OPSL'
UNION

SELECT Convert(int, ces.ControllerEquipmentSetupId), mt.TagAddress,'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
ces.LfsChemicalName,ces.LastModifiedTime ,'LFS Chemical Name',tt.DataType,2
,'LfsChemicalName' as OriginalColumnName,'[TCD].[ControllerEquipmentSetup]' as EntityName,tt.TagType as TagType, ControllerEquipmentId as ControllerEquipmentSetupId  , 2 as SortingOrder 

FROM TCD.ModuleTags mt INNER JOIN TCD.ControllerEquipmentSetup ces ON mt.ModuleId=ces.ControllerEquipmentSetupId
Inner Join tcd.TagType tt on mt.TagType = tt.TagType 
WHERE mt.ModuleTypeId=@PumpModuleTypeId AND ces.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_NML' 
UNION

SELECT csd.ControllerId ,ct.TagAddress,NULL,csd.[Value],cc.LastModifiedTime , f.Label,tt.DataType,6
,'Value-'+CAST(csd.FieldId as varchar) as OriginalColumnName,'[TCD].[ControllerSetupData]' as EntityName,tt.TagType as TagType, 0 as ControllerEquipmentSetupId  , 0 as SortingOrder
FROM TCD.ControllerTags ct 
INNER JOIN TCD.ControllerSetupData csd ON csd.ControllerId = ct.ControllerId
INNER JOIN tcd.Field f ON f.Id = csd.FieldId AND ct.TagType=f.HasFieldTag
INNER JOIN TCD.ConduitController cc ON cc.ControllerId = ct.ControllerId
Inner Join tcd.TagType tt on ct.TagType = tt.TagType
WHERE ct.ControllerId=@ControllerId AND ct.Active=@Active

UNION

SELECT ces.ControllerEquipmentSetupId,
    'stMachineConfig.xFlowSwitchType['+cast(ControllerEquipmentId AS varchar(20))+']' as TagAddress,
    'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
   cast( FlowDetectorType AS varchar(20)) AS Value, 
    ces.LastModifiedTime,
    'Flow Detector Type' AS Lable,
    'BIT' As DataType ,
    2.1,
    'FlowDetectorType' AS OriginalColumnName ,
    '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stMachineConfig.xFlowSwitchType' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 5 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3


UNION --Flow Switch Alarm
SELECT ces.ControllerEquipmentSetupId,
    'stMachineConfig.xFlowAlarmOverride['+cast(ControllerEquipmentId AS varchar(20))+']' as TagAddress,
    'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
   Cast( ces.FlowSwitchAlarm  AS varchar(20)) AS Value, 
    ces.LastModifiedTime,
    'Flow Switch Alarm' AS Lable,
    'BIT' As DataType ,
    2.2,
    'FlowSwitchAlarm' AS OriginalColumnName ,
    '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stMachineConfig.xFlowAlarmOverride' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId , 10 as SortingOrder 
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3
UNION --Flow Meter Alarm
SELECT ces.ControllerEquipmentSetupId,
    'stMachineConfig.xFlowMeterAlarmOverride['+cast(ControllerEquipmentId AS varchar(20))+']' as TagAddress,
    'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
  cast(  ces.FlowMeterAlarm  AS varchar(20)) AS Value, 
    ces.LastModifiedTime,
    'Flow Meter Alarm' AS Lable,
    'BIT' As DataType ,
    2.3,
    'FlowMeterAlarm' AS OriginalColumnName ,
    '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stMachineConfig.xFlowMeterAlarmOverride' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 6 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3
UNION --Flow Meter Type
     
SELECT ces.ControllerEquipmentSetupId,
    'stPumpConfig['+cast(ControllerEquipmentId AS varchar(20))+'].eFlowMeterMode' as TagAddress,
    'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
   cast( ces.FlowMeterType  AS varchar(20))  AS Value, 
    ces.LastModifiedTime,
    'Flow Meter Type' AS Lable,
    'INT' As DataType ,
    2.4,
    'FlowMeterType' AS OriginalColumnName ,
    '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stPumpConfig.eFlowMeterMode' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 9 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3

UNION --Flow Alarm Delay Time
SELECT ces.ControllerEquipmentSetupId,
    'stPumpConfig['+cast(ControllerEquipmentId AS varchar(20))+'].fLossOfFlowDuration' as TagAddress,
    'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
   cast( ces.FlowAlarmDelay  AS varchar(20))  AS Value, 
    ces.LastModifiedTime,
    'Flow Alarm Delay Time' AS Lable,
    'FLOAT' As DataType ,
    2.5,
    'FlowAlarmDelay' AS OriginalColumnName ,
    '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stPumpConfig.fLossofFlowDuration' TagType, ces.ControllerEquipmentId  as ControllerEquipmentSetupId, 4 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3
UNION --Flow Meter Pump Delay
SELECT ces.ControllerEquipmentSetupId,
    'stPumpConfig['+cast(ControllerEquipmentId AS varchar(20))+'].fTdFlowMeter' as TagAddress,
    'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
   cast( ces.FlowMeterPumpDelay  AS varchar(20))  AS Value, 
    ces.LastModifiedTime,
    'Flow Meter Pump Delay' AS Lable,
    'FLOAT' As DataType ,
    2.6,
    'FlowMeterPumpDelay' AS OriginalColumnName ,
    '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stPumpConfig.fTdFlowMeter' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 8 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3

UNION -- Flow Meter Alarm Delay
SELECT ces.ControllerEquipmentSetupId,
    'stPumpConfig['+cast(ControllerEquipmentId AS varchar(20))+'].fTAlarmDelayFlowMeter' as TagAddress,
    'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
   cast( ces.FlowMeterAlarmDelay  AS varchar(20))  AS Value, 
    ces.LastModifiedTime,
    'Flow Meter Alarm Delay' AS Lable,
    'FLOAT' As DataType ,
    2.7,
    'FlowMeterAlarmDelay' AS OriginalColumnName ,
    '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stPumpConfig.fTAlarmDelayFlowMeter' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 7 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3



SELECT  ttmd.Id  
   ,ttmd.TagAddress  
   ,isnull(ttmd.[Description],'')
   ,ttmd.Value  
   ,ttmd.LastModifiedTime  
   ,ttmd.ColName
   ,ttmd.DataType
   ,ttmd.OriginalColumnName
 ,ttmd.EntityType 
 ,ttmd.TagType,ttmd.SortingOrder,ttmd.ControllerEquipmentSetupId  FROM dbo.#tmpTagManagementDetails ttmd WHERE ttmd.[Value] IS  NOT NULL AND ttmd.[Value]<> '' ORDER BY ttmd.RowNumber

END
GO

IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyValue rkv WHERE rkv.KeyName = N'FIELD_SWITCH')
BEGIN
        INSERT INTO TCD.ResourceKeyValue
    (
        [KeyName],
		[Value],
        languageID,
		LastModifiedTime
    )
    VALUES
    (
        N'FIELD_SWITCH', 
        N'Switch', 
        1,
		GETUTCDATE() 
    )
END
GO
IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyMaster rkm WHERE rkm.[KeyName] = 'FIELD_PADDLE')
BEGIN
    INSERT INTO TCD.ResourceKeyMaster
    (
         [KeyName]
    )
    VALUES
    (
        N'FIELD_PADDLE'
    )
   
    INSERT INTO TCD.ResourceKeyValue
    (
        [KeyName],
		[Value],
        languageID,
		LastModifiedTime
    )
    VALUES
    (
        N'FIELD_PADDLE', 
        N'Paddle', 
        1,
		GETUTCDATE() 
    )
END



GO

IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[ProcessTunnelWasherData]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[ProcessTunnelWasherData] 
END 
GO 
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessTunnelWasherData]
	(	
	@WasherId INT,	
	@xmlTags XML
)
AS
BEGIN
		DECLARE @BatchID						INT,
				@EcolabWasherId					INT,								
				@CurrencyCode					VARCHAR(50),		
				@MachineInternalId				INT ,
				@GroupId						INT,		
				@Prveformula					INT,
				@Quantity						INT,
				@MaxWashertGroupCapacity		INT,
				@PrevBatchId					INT,
				@PrevLoadId						INT,
				@ExistedLoadId					INT,
				@NumberOfCompartments			INT,

				@ProgramMasterId				INT,
				@NominalLoad					Decimal(10,2),
				@MaxLoad						Decimal(10,2),
				@StandardWeight					Decimal(10,2) , 				
				@PlantWasherNumber				INT,
											
				@CurrentDay						DATE=CAST(GETUTCDATE() as date),
				@TempTunnelTimeStamp			DATETIME2,

				@ControllerId					INT ,
				@CurrentHoldSignal				INT,
				
				@TotalRunTime					INT,
				@BatchGroupId					INT,
				@BatchFormula					INT,
				@BatchStartDate					DATETIME2,
				@BatchEndDate					DATETIME2,
				@HoldTime						INT,
				@CteTempBatchTunnelWashSteps	INT,
				@CteTemTunnelWashSetps			INT,
				@PrevFormula					INT,
				@PrevStepCompartment			INT,
				@BatchStandardWaterUsage		INT,
				@BatchActualWaterUsage			INT,
				@BatchWaterUsagePrice			Decimal(10,2),
				@BatchUtilityPrice				Decimal(10,2),
				@BatchWaterType					INT,
				@ExtraTime						INT,
				@TargetTurnTime					INT,
				@EcolabAccountNumber NVARCHAR(25) = NULL,
				@PartitionOn					SMALLDATETIME
				                              							
		SELECT @ExtraTime = 0

		SELECT DISTINCT 					
					@NumberOfCompartments=MST.NumberOfComp,
					@EcolabWasherId=Ws.EcolabWasherId
			FROM		TCD.Washer Ws
			INNER JOIN 
						TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId					
		WHERE Ws.WasherId=@WasherId and Ws.Is_Deleted=0
		
				
		IF EXISTS (SELECT  * FROM TEMPDB.DBO.SYSOBJECTS o where o.xtype in ('U') AND o.id = OBJECT_ID(N'tempdb..#XmlTagsTable'))
			BEGIN
					DROP TABLE #XmlTagsTable
			END
		CREATE TABLE  #XmlTagsTable (	CurrentFormula				INT,
										CurretnInjection			INT,
										CurrentOperationCounter		INT,
										Eof							INT,
										TunnelTimeStamp				DATETIME2,
										OnHold						BIT,										
										CompartmentId				INT, 
										CompartmentLoadId			INT, 
										CompartmentFormulaId		INT,										
										ReceivedTime				DATETIME2,
										AutoWeightEntryActive		VARCHAR(10),
										AutoWeightEntryWeight		INT,
										IsFormulaModified			BIT,
										IsHoldSignalModified		BIT	,
										IsStopSinalModified			BIT,
										StopSignal					INT,
										RatioDosingEnabled			INT						
									)
		INSERT INTO #XmlTagsTable	(
										CurrentFormula	,
										CurretnInjection,										
										CurrentOperationCounter,
										Eof,
										TunnelTimeStamp	,
										OnHold,
										CompartmentId, 
										CompartmentLoadId, 
										CompartmentFormulaId,
										ReceivedTime,
										AutoWeightEntryActive,
										AutoWeightEntryWeight,
										IsFormulaModified,
										IsHoldSignalModified,
										IsStopSinalModified,
										StopSignal,
										RatioDosingEnabled
									)			
		
		-- Populate tempdata from xml
		SELECT	T.c.value('../@CurrentFormula', 'INT') AS CurrentFormula, 
				T.c.value('../@CurrentInjection', 'INT') AS CurretnInjection, 				
				T.c.value('../@CurrentOperationCounter', 'INT') AS CurrentOperationCounter, 						
				T.c.value('../@Eof', 'INT') AS EndofFormula, 
				T.c.value('../@TimeStamp', 'VARCHAR(100)') AS TunnelTimeStamp, 
				T.c.value('../@OnHold', 'VARCHAR(100)') AS OnHold, 
				T.c.value('@CompartmentId', 'INT') AS CompartmentId, 
				T.c.value('@LoadId', 'INT') AS CompartmentLoadId, 
				T.c.value('@FormulaId', 'INT') AS CompartmentFormulaId, 				
				T.c.value('@TimeStamp', 'VARCHAR(100)') DateTimeStamp,
				T.c.value('../@Awea', 'VARCHAR(10)') AS AutoWeightEntryActive, 				
				T.c.value('../@Awew', 'INT') AS AutoWeightEntryWeight,	
				T.c.value('../@IsFormulaModified', 'BIT') AS IsFormulaModified,
				T.c.value('../@IsHoldSignalModified', 'BIT') AS IsHoldSignalModified,
				T.c.value('../@IsStopSinalModified', 'BIT') AS IsStopSinalModified,
				T.c.value('../@StopSignal', 'INT') AS StopSignal,
				T.c.value('../@RATA', 'INT') AS RatioDosingEnabled
				
				
		
		FROM @xmlTags.nodes('/Tunnel/Compartment')  T(c)

		
		WHERE	
		T.c.value('@LoadId', 'VARCHAR(100)')  != 0
		AND
		T.c.value('@CompartmentId', 'INT')    <= @NumberOfCompartments
		
		IF EXISTS (SELECT 1 FROM #XmlTagsTable where IsHoldSignalModified = 1)	 
			BEGIN			
				SELECT	@CurrentHoldSignal = Id  FROM TCD.ConduitParameters where Name='HoldSignal'
				INSERT INTO TCD.WasherReading(
								WasherId,
								ParameterId,
								ParameterValue,
								DateTimeStamp,
								EcolabWasherId)
					SELECT		@WasherId,
								@CurrentHoldSignal,
								OnHold,
								ReceivedTime,
								@EcolabWasherId	
					FROM #XmlTagsTable
			END	
		IF EXISTS (SELECT 1 FROM #XmlTagsTable where IsStopSinalModified = 1)	 
			BEGIN	
				INSERT INTO TCD.WasherReading(
							WasherId,
							ParameterId,
							ParameterValue,
							DateTimeStamp,
							EcolabWasherId)
				SELECT		@WasherId,
							12,
							StopSignal,
							ReceivedTime,
							@EcolabWasherId
				FROM #XmlTagsTable
			END	
		IF EXISTS (SELECT 1 FROM #XmlTagsTable where IsFormulaModified = 1)	 
			BEGIN
		
			-- Start find missing load id form xml  and set end date for corresponding enddates in the database
			DECLARE @TempExisitingLoadIds table(ExstingLoadId INT,ExistsBatchId int)
			INSERT INTO @TempExisitingLoadIds(ExstingLoadId,ExistsBatchId)
				SELECT Bd.ControllerBatchId,Bd.BatchId FROM TCD.BatchData Bd					
					--INNER JOIN TCD.BatchWashStepData Bwsd on Bwsd.BatchId=Bd.BatchId
				WHERE Bd.MachineId=@WasherId AND Bd.EndDate IS NULL ORDER BY Bd.StartDate DESC			
		
			SELECT @TempTunnelTimeStamp =(SELECT T.c.value('./@TimeStamp', 'VARCHAR(100)') AS TunnelTimeStamp	FROM @xmlTags.nodes('/Tunnel')  T(c))
			
			DECLARE @TempBatchStepIs TABLE(StepBatchId INT)
			INSERT INTO @TempBatchStepIs (StepBatchId)
			SELECT ExistsBatchId 
				FROM @TempExisitingLoadIds 
				WHERE ExstingLoadId NOT IN (SELECT CompartmentLoadId FROM #XmlTagsTable)
		
		SELECT @PrevStepCompartment=StepCompartment,@PrevBatchId =BatchID 
		FROM TCD.BatchWashStepData  
		WHERE BatchId in (select StepBatchId from @TempBatchStepIs) AND EndTime IS NULL

		UPDATE 
		TCD.BatchWashStepData 
		SET EndTime = @TempTunnelTimeStamp
		WHERE BatchId in (select StepBatchId from @TempBatchStepIs) AND EndTime IS NULL

		DECLARE @BatchShiftId int
		DECLARE @ShiftStartDateTemp table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
		INSERT INTO @ShiftStartDateTemp(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @TempTunnelTimeStamp,1
		SELECT @BatchShiftId = ssdt.ShiftId FROM @ShiftStartDateTemp ssdt ORDER BY ssdt.ShiftStartdate

		-- Updating Batches moved out of the tunnel
		UPDATE TCD.BatchData 
		SET		
				EndDate=@TempTunnelTimeStamp
			,	EndDateFormula=@TempTunnelTimeStamp,
			ShiftId = @BatchShiftId
		WHERE BatchId in (select StepBatchId from @TempBatchStepIs)

		--End find missing load id form xml  and set end date for corresponding enddates in the database
		 
		--Start HoldTime Calculation
			SELECT 
					@BatchGroupId=GroupId
				,	@BatchFormula=ProgramNumber
				,	@BatchStartDate=StartDate
				,	@BatchEndDate=EndDate 
			FROM TCD.BatchData 
			WHERE BatchId IN (select		StepBatchId from @TempBatchStepIs)

			SELECT @TotalRunTime=TotalRunTime 
			FROM TCD.TunnelProgramSetup 
			WHERE	WasherGroupId =@BatchGroupId 
				AND ProgramNumber=@BatchFormula

			INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) 
			SELECT StepBatchId,@EcolabWasherId,17,(DATEDIFF(SECOND, @BatchStartDate, @BatchEndDate))-@TotalRunTime,bd.partitionon
            FROM @TempBatchStepIs,TCD.BatchData bd WHERE bd.BatchId= [@TempBatchStepIs].StepBatchId  and [@TempBatchStepIs].StepBatchId NOT IN (SELECT BATCHID FROM TCD.BatchParameters AS BP WHERE BP.ParameterId = 17)
 
		--End HoldTime Calculation

			 --Start Good or Bad Injection in BatchDataTable
					IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@PrevBatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
						BEGIN
					
							;WITH CteTempBatchTunnelStepData  (	
								InjectionsCount,BatchId,ProgramNumber
							) AS  
							(
								SELECT DISTINCT Bws.StepCompartment,
												BD.BatchId,												
												Bd.ProgramNumber
												FROM TCD. BatchData Bd
								INNER JOIN 
										TCD.BatchWashStepData Bws 
															ON Bws.BatchId			=		Bd.BatchId 
								WHERE    
														
														Bd.BatchId					=		@PrevBatchId ) 
								SELECT @CteTemTunnelWashSetps=COUNT(CTE1.InjectionsCount)
								FROM CteTempBatchTunnelStepData CTE1 
								INNER JOIN TCD.BatchData Bd ON Bd.BatchId=CTE1.BatchId
								WHERE Bd.BatchId=@BatchId

								;WITH CteTempBatchInjections (	
								InjectionsCount,ProgramNumber
							) AS  
							(
								SELECT  DISTINCT 
												
												Tds.CompartmentNumber,
												Tps.ProgramNumber
									 	FROM TCD.TunnelProgramSetup Tps 
										INNER JOIN 
													TCD.TunnelDosingSetup Tds ON 
														Tds.TunnelProgramSetupId	=		Tps.TunnelProgramSetupId
										INNER JOIN 
													TCD.TunnelDosingProductMapping Tdpm ON 
													Tdpm.TunnelDosingSetupId		=		Tds.TunnelDosingSetupId
										INNER JOIN 
													TCD.ControllerEquipmentSetup Ces ON 
													Ces.ControllerEquipmentSetupId	=		Tdpm.ControllerEquipmentSetupId
													WHERE 																		 								
													Tps.ProgramNumber				=		@PrevFormula )
								SELECT @CteTempBatchTunnelWashSteps=COUNT(CTE2.InjectionsCount)
								FROM CteTempBatchInjections CTE2 

										Insert Tcd.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @PrevBatchId,@EcolabWasherId,18,
										CASE	WHEN @CteTempBatchTunnelWashSteps	=	@CteTemTunnelWashSetps THEN 1
												WHEN @CteTempBatchTunnelWashSteps	!=	@CteTemTunnelWashSetps THEN 3 END,
												(SELECT PartitionOn FROM TCD.BatchData where BatchId=@PrevBatchId and MachineId=@WasherId)
												--(SELECT Top 1 ShiftStartdate from @ShiftStartTemp)		
														
																
				END

			-- End Good or Bad Injection in BatchDataTable


	-- Fetching data from cursor
			DECLARE @MYCURSOR CURSOR
			SET @MYCURSOR = CURSOR FAST_FORWARD
			FOR
			SELECT		CurrentFormula	,
						CurretnInjection,										
						CurrentOperationCounter,
						Eof,
						TunnelTimeStamp	,
						OnHold,
						CompartmentId, 
						CompartmentLoadId, 
						CompartmentFormulaId,
						ReceivedTime,
						AutoWeightEntryActive,
						AutoWeightEntryWeight,
						IsFormulaModified,
						IsHoldSignalModified,
						IsStopSinalModified,
						StopSignal,
						RatioDosingEnabled

				FROM #XmlTagsTable ORDER BY CompartmentId ASC
			DECLARE			@CurCurrentFormula					INT,
							@CurCurretnInjection			INT,
							@CurCurrentOperationCounter		INT,
							@CurEof							INT,
							@CurTunnelTimeStamp				DATETIME2,
							@CurOnHold						BIT,
							@CurCompartmentId				INT, 
							@CurCompartmentLoadId			INT, 
							@CurCompartmentFormulaId		INT,
							@CurReceivedTime				DATETIME2,
							@AutoWeightEntryActive			VARCHAR(10),
							@AutoWeightEntryWeight			INT,
							@IsFormulaModified				BIT,
							@IsHoldSignalModified			BIT,
							@IsStopSinalModified			BIT,
							@StopSignal						INT,
							@RatioDosingEnabled				INT	

			OPEN @MYCURSOR
			FETCH NEXT FROM @MYCURSOR
							INTO @CurCurrentFormula			,
							@CurCurretnInjection			,
							@CurCurrentOperationCounter		,
							@CurEof							,
							@CurTunnelTimeStamp				,
							@CurOnHold						,
							@CurCompartmentId				, 
							@CurCompartmentLoadId			, 
							@CurCompartmentFormulaId		,
							@CurReceivedTime				,
							@AutoWeightEntryActive			,
							@AutoWeightEntryWeight			,
							@IsFormulaModified				,
							@IsHoldSignalModified			,
							@IsStopSinalModified			,
							@StopSignal						,
							@RatioDosingEnabled
			WHILE @@FETCH_STATUS = 0
			BEGIN
				

			IF(@IsFormulaModified !=0)	
			BEGIN
				IF(@CurCurrentFormula != @CurEof and @CurCurretnInjection = 0 and @CurCurrentOperationCounter = 0)
					BEGIN

			SELECT DISTINCT 							
							@MachineInternalId			=	Mst.MachineInternalId,
							@GroupId					=	Mst.GroupId,
							@ControllerId				=	Ctrl.ControllerId				
					FROM TCD.Washer Ws
						INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
						INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
						INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
						INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId	=	Mst.ControllerId
					WHERE Ws.WasherId=@WasherId 	

				SELECT DISTINCT 
							@ProgramMasterId			=	Wps.ProgramId,
							@NominalLoad				=	Wps.NominalLoad,
							@MaxLoad					=	Ws.MaxLoad,
							@CurrencyCode				=	Pl.CurrencyCode, 
							@TargetTurnTime				=   (3600/(Wps.TotalRunTime/Mst.NumberofComp))

				FROM TCD.Washer Ws
						INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
						INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
						INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
						INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
						INNER JOIN TCD.Plant Pl ON Pl.EcolabAccountNumber	=		Ws.EcoLabAccountNumber
						
				WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@CurCurrentFormula and Wps.Is_Deleted=0

				select @PlantWasherNumber = plantwashernumber from tcd.washer where washerid = @WasherId
	
				SELECT  @MaxWashertGroupCapacity		=	Max(ws.MaxLoad)
				FROM TCD.Washer WS
					INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
					INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId		
				WHERE Mst.GroupId=@GroupId

				SELECT @StandardWeight					=	@NominalLoad  								
				SELECT @AutoWeightEntryWeight=Case @AutoWeightEntryActive WHEN 'False' THEN @StandardWeight ELSE  @AutoWeightEntryWeight END 
				
				SELECT @MachineInternalId,@GroupId,@ProgramMasterId,@NominalLoad,@WasherId,@CurCurrentFormula,@PrevBatchId
				SELECT @CurCurrentFormula				AS CurCurrentFormula			,
							@CurCurretnInjection		AS CurCurretnInjection		,
							@CurCurrentOperationCounter	AS CurCurrentOperationCounter	,
							@CurEof						AS CurEof 		,
							@CurTunnelTimeStamp			AS CurTunnelTimeStamp		,
							@CurOnHold					AS CurOnHold			,
							@CurCompartmentId			AS CurCompartmentId			, 
							@CurCompartmentLoadId		AS CurCompartmentLoadId 		, 
							@CurCompartmentFormulaId	AS CurCompartmentFormulaId		,
							@CurReceivedTime			AS CurReceivedTime,
							@AutoWeightEntryActive		AS AutoWeightEntryActive,
							@AutoWeightEntryWeight		AS AutoWeightEntryWeight,
							@IsFormulaModified			AS IsFormulaModified
		
		IF(@CurCompartmentFormulaId > 0)
		BEGIN
					UPDATE TCD.ConduitController
					SET LastConnectedTime		=	GETUTCDATE()
					WHERE ControllerId			=	@ControllerId
		END
		
		IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchData WHERE MachineId=@WasherId AND StartDate =@CurTunnelTimeStamp)
		BEGIN

			DECLARE @ShiftStartDate table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
			INSERT INTO @ShiftStartDate(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurTunnelTimeStamp,0
				-- New Batch Creation
							INSERT INTO TCD.BatchData(
											ControllerBatchId ,
											EcolabWasherId,
											GroupId ,
											MachineInternalId,
											PlantWasherNumber,
											StartDate ,
											EndDate ,
											ProgramNumber,
											ProgramMasterId,
											MachineId,
											ActualWeight,
											StandardWeight,
											CurrencyCode,
											ShiftId,
											PartitionOn,
											TargetTurnTime
											)


										SELECT DISTINCT @CurCompartmentLoadId
											,@EcolabWasherId
											,@GroupId
											,@MachineInternalId
											,@PlantWasherNumber
											--,@CurReceivedTime
											,@CurTunnelTimeStamp
											,NULL
											,@CurCurrentFormula
											,@ProgramMasterId
											,@WasherId
											,@AutoWeightEntryWeight
											,@StandardWeight 
											,@CurrencyCode
											,(SELECT Top 1 ShiftId from @ShiftStartDate)
											,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
											,@TargetTurnTime

								
			
								SET @BatchID=SCOPE_IDENTITY()	

								--If the received formula is not configured in enVision then create an alarm 
							IF(@ProgramMasterId is NULL)
							BEGIN
							SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant
								INSERT INTO [TCD].[AlarmData] 
								   (EcoalabAccountNumber,
								   AlarmCode,
								   BatchId,
								   controllerID,
								   StartDate,
								   GroupId,
								   MachineInternalId,
								   ProgramId,   
								   IsActive,
								   EndDate,
								   MachineId)
									  SELECT
									   @ECOLABAccountNumber,
									   9000,
									   @BatchID,
									   @ControllerId,
									   @CurTunnelTimeStamp,
									   @GroupId,
									   @MachineInternalId,
									   @CurCurrentFormula,
									   0,
									   @CurTunnelTimeStamp,
									   @WasherId
							END


						-- Wash Step Information		
						INSERT INTO TCD.BatchWashStepData(
											BatchId
											,StepCompartment
											,StartTime
											,EndTime
											,PartitionOn
											,EcolabWasherId) 				
						SELECT	
											@BatchID,
											@CurCompartmentId,
											@CurTunnelTimeStamp,
											--@CurReceivedTime,
											NULL,
											(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
											@EcolabWasherId
						-- Product Usage
				IF (@RatioDosingEnabled = 1)
					BEGIN
						INSERT INTO TCD.BatchProductData(
									BatchId,
									StepCompartment,
									ActualQuantity,
									StandardQuantity,
									Price,
									[TimeStamp],
									PartitionOn,
									EcolabWasherId,
									ProductId
						)					
						SELECT DISTINCT @BatchID	
										,@CurCompartmentId
										,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * (@AutoWeightEntryWeight/@StandardWeight) AS ActualQuantity						
										,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * (@AutoWeightEntryWeight/@StandardWeight) AS StandardQuantity										
										,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price	
										,@CurTunnelTimeStamp								
										--,@CurReceivedTime
										,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
										,@EcolabWasherId
										,Pdm.ProductID
							FROM TCD.Washer WS
							INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
							INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
							INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
							INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
							INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
							INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
							INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId=Wdpm.ControllerEquipmentSetupId
							INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Ces.ProductId
							--INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
						WHERE 
								Ws.WasherId=@WasherId AND 
								Wps.ProgramNumber=@CurCurrentFormula AND 
								Wds.CompartmentNumber=@CurCompartmentId	AND
								Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
					END
				ELSE
					BEGIN
						INSERT INTO TCD.BatchProductData(
									BatchId,
									StepCompartment,
									ActualQuantity,
									StandardQuantity,
									Price,
									[TimeStamp],
									PartitionOn,
									EcolabWasherId,
									ProductId
						)					
						SELECT DISTINCT @BatchID	
										,@CurCompartmentId
										,((Wps.NominalLoad * Wdpm.Quantity)/ 100) AS ActualQuantity						
										,((Wps.NominalLoad * Wdpm.Quantity)/ 100) AS StandardQuantity										
										,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price
										,@CurTunnelTimeStamp									
										--,@CurReceivedTime
										,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
										,@EcolabWasherId
										,Pdm.ProductID
							FROM TCD.Washer WS
							INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
							INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
							INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
							INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
							INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
							INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
							INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId=Wdpm.ControllerEquipmentSetupId
							INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Ces.ProductId
							--INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
						WHERE 
								Ws.WasherId=@WasherId AND 
								Wps.ProgramNumber=@CurCurrentFormula AND 
								Wds.CompartmentNumber=@CurCompartmentId	AND
								Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
					END			
								
								
						-- Transfer Signal		
								INSERT INTO TCD.WasherReading(
															WasherId,
															ParameterId,
															ParameterValue,
															DateTimeStamp,
															PartitionOn,
															EcolabWasherId)
									SELECT @WasherId,
											6,
											1,
											@TempTunnelTimeStamp,
											(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
											@EcolabWasherId
									UNION ALL
									SELECT @WasherId,
											6,
											0,
											GETUTCDATE(),
											(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
											@EcolabWasherId
			
						-- Insert Customer Data
						INSERT INTO TCD.BatchCustomerData(
										BatchId,
										CustomerId,
										Weight,
										PiecesCount,
										PartitionOn,
										EcolabWasherId
										)
						SELECT DISTINCT	
										Bd.BatchId,		
										Pc.ID,
										@AutoWeightEntryWeight,
										ROUND(COALESCE((@AutoWeightEntryWeight * Pm.Pieces) / NULLIF(Pm.Weight,0), 0),0),
										(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
										@EcolabWasherId
						
						FROM TCD.Washer WS
							INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
							INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId							
							INNER JOIN TCD.TunnelProgramSetup Tps ON Tps.WasherGroupId = Wg.WasherGroupId
							INNER JOIN TCD.ProgramMaster Pm ON Pm.ProgramId=Tps.ProgramId
							INNER JOIN TCD.PlantCustomer Pc ON Pc.ID=Pm.CustomerId
							INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
						WHERE 
							Ws.WasherId=@WasherId AND 
							Tps.ProgramNumber=@CurCompartmentFormulaId AND 
							Bd.BatchId=@BatchID	  AND 
							Pm.CustomerId != -1
							AND Pm.[Weight] > 0
		END

		ELSE
		BEGIN
			SELECT @BatchID=BatchId, @PartitionOn=PartitionOn
			FROM TCD.BatchData 
			WHERE MachineId=@WasherId 
			AND ControllerBatchId=@CurCompartmentLoadId
			
			IF(@BatchID IS NOT NULL)
			BEGIN
				UPDATE TCD.BatchWashStepData 
					SET EndTime=@CurTunnelTimeStamp
				WHERE BatchId=@BatchId 
					AND StepCompartment=@CurCompartmentId-1

				IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchWashStepData WHERE StartTime=@CurTunnelTimeStamp and BatchId=@BatchID)
				BEGIN
					INSERT INTO TCD.BatchWashStepData(
											BatchId
											,StepCompartment
											,StartTime
											,EndTime
											,PartitionOn
											,EcolabWasherId) 				
						SELECT	
											@BatchID,
											@CurCompartmentId,
											@CurTunnelTimeStamp,
											--@CurReceivedTime,
											NULL,
											@PartitionOn,
											@EcolabWasherId
				END							
				IF (@RatioDosingEnabled = 1)
				BEGIN
					IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurTunnelTimeStamp and BatchId=@BatchID)
					BEGIN
						INSERT INTO TCD.BatchProductData(
									BatchId,
									StepCompartment,
									ActualQuantity,
									StandardQuantity,
									Price,
									[TimeStamp],
									PartitionOn,
									EcolabWasherId,
									ProductId
									)
						SELECT DISTINCT 
									@BatchID	
									,@CurCompartmentId
									,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * (@AutoWeightEntryWeight/@StandardWeight) AS ActualQuantity							
									,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * (@AutoWeightEntryWeight/@StandardWeight) AS StandardQuantity	
									,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price
									,@CurTunnelTimeStamp									
									--,@CurReceivedTime
									,@PartitionOn
									,@EcolabWasherId
									,Pdm.ProductID
						FROM TCD.Washer WS
						INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
						INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
						INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
						INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
						INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
						INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
						INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId=Wdpm.ControllerEquipmentSetupId
						INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Ces.ProductId
						--INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
						WHERE 
							Ws.WasherId=@WasherId 
							AND Wps.ProgramNumber=@CurCompartmentFormulaId 
							AND Wds.CompartmentNumber=@CurCompartmentId	AND
							Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
					END
				END -- end of ratio dosing if
				ELSE
					BEGIN
						IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurTunnelTimeStamp and BatchId=@BatchID)
						BEGIN
							INSERT INTO TCD.BatchProductData(
											BatchId,
											StepCompartment,
											ActualQuantity,
											StandardQuantity,
											Price,
											[TimeStamp],
											PartitionOn,
											EcolabWasherId,
											ProductId
											)
							SELECT DISTINCT 
											@BatchID	
											,@CurCompartmentId
											,((Wps.NominalLoad * Wdpm.Quantity)/ 100) AS ActualQuantity							
											,((Wps.NominalLoad * Wdpm.Quantity)/ 100) AS StandardQuantity	
											,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price
											,@CurTunnelTimeStamp									
											,@PartitionOn
											,@EcolabWasherId
											,Pdm.ProductID
								FROM TCD.Washer WS
								INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
								INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
								INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
								INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
								INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
								INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
								INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId=Wdpm.ControllerEquipmentSetupId
								INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Ces.ProductId
								
							WHERE 
									Ws.WasherId=@WasherId 
									AND Wps.ProgramNumber=@CurCompartmentFormulaId 
									AND Wds.CompartmentNumber=@CurCompartmentId	AND
										Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0	
						END
					END			
				END -- end of BatchId NULL if
			END -- end of else
		END		-- end of IF(@CurCurrentFormula != @CurEof and @CurCurretnInjection = 0 and @CurCurrentOperationCounter = 0)							
	END		-- end of IF(@IsFormulaModified !=0)												
			FETCH NEXT FROM @MYCURSOR
			INTO @CurCurrentFormula			,
							@CurCurretnInjection			,
							@CurCurrentOperationCounter		,
							@CurEof							,
							@CurTunnelTimeStamp				,
							@CurOnHold						,
							@CurCompartmentId				, 
							@CurCompartmentLoadId			, 
							@CurCompartmentFormulaId		,
							@CurReceivedTime				,
							@AutoWeightEntryActive			,
							@AutoWeightEntryWeight			,
							@IsFormulaModified				,
							@IsHoldSignalModified			,
							@IsStopSinalModified			,
							@StopSignal						,
							@RatioDosingEnabled
			END
			CLOSE @MYCURSOR
			DEALLOCATE @MYCURSOR	
			
		
		END
END

GO

IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[ProcessConventionalWasherData]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[ProcessConventionalWasherData] 
END 
GO 
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessConventionalWasherData]
	(	
	@WasherId INT,	
	@xmlTags XML
)

AS
BEGIN
  DECLARE @BatchID        INT,
    @EcolabWasherId       INT,        
    @CurrencyCode       VARCHAR(50),  
    @MachineInternalId      INT,
    @GroupId        INT,  
    @Prveformula       INT,
    @Quantity        INT,
    @MaxWashertGroupCapacity    INT,

    @ProgramMasterId      INT,
    @NominalLoad       DECIMAL(10,2),
    @MaxLoad        DECIMAL(10,2),
    @StandardWeight       DECIMAL(10,2) ,     

    @CurrentFormula       INT,  
    @CurrentFormulaDate      DATETIME2,
    @FormulaIsModified      BIT,

    @CurrentInjection      INT,
    @CurrentInjectionDate     DATETIME2,
    @InjectionIsModified     BIT,

    @OperationalCount      INT,
    @OperationalIsModified     BIT, 
				
    @CurrentHoldSignal      INT,
    @CurrentHoldSignalDate     DATETIME2,
    @HoldSignalIsModified     BIT,  
													
    @EndofFormula       INT, 
    @EndofFormulaDate      DATETIME2,
				
    @AutoWeightEntryActive     BIT,
    @AutoWeightEntryWeight     DECIMAL(10,2),                                                                                                                              
    @ControllerId       INT,
    @CurrentHoldSignalValue     INT ,
				
    @MeterPlcAddress      INT,
    @MeterPlcAddressIsModified    INT,
    @BatchGroupId       INT,
    @BatchFormula       INT,    
    @HoldTime        INT,
    @CteTempBatchInjections     INT,
    @CteTempWaherReadingInjections   INT,
    @BatchStandardWaterUsage    INT,
    @BatchActualWaterUsage     INT,
    @BatchWaterUsagePrice     Decimal(10,2),
    @BatchUtilityPrice      Decimal(10,2),
    @BatchWaterType       INT,
    @PrevGroupId       INT,
    @WasherMeterExists      BIT,
    @ExtraTime        INT,
    @TargetTurnTime       INT,
    @RatioDosingEnabled      BIT,
	@EcolabAccountNumber NVARCHAR(25) = NULL,
	@PreviousFormulaDate      DATETIME2,
	@PreviousInjectionStep	INT,
	@PreviousInjectionStartDate DATETIME2,
	@CurrentInjectionStep INT,
	@WashStepBatchId INT,
	@PrevFormulaExtraTime INT      
				                                                                                                    							

						
		IF EXISTS (SELECT  * FROM [TEMPDB].[DBO].[SYSOBJECTS] o where o.xtype in ('U') AND o.id = OBJECT_ID(N'tempdb..#XmlTagsTable'))
			BEGIN
					DROP TABLE #XmlTagsTable
			END


  CREATE TABLE  #XmlTagsTable ( TagId INT, 
										TagValue NVARCHAR(100), 
										ReceivedTime DATETIME2,
										TagType NVARCHAR(50),
										IsModified BIT
									)

	
  INSERT INTO #XmlTagsTable (
										TagId,
										TagValue,
										ReceivedTime,
										TagType,
										IsModified
									)			
		
		SELECT 		
					T.c.value('@TagId', 'INT') as TagId,
     T.c.value('@Value', 'NVARCHAR(100)') TagValue,
					T.c.value('@TimeStamp', 'VARCHAR(100)') DateTimeStamp,
					T.c.value('@TagType', 'VARCHAR(50)') TagType,
					T.c.value('@IsModified', 'BIT') TagType
  FROM  @xmlTags.nodes('Tags/Tag') T(c)
		WHERE	
					T.c.value('@TagId', 'varchar(100)')  IS NOT NULL
					
		--DECLARE @ShiftStartDate table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
		--INSERT INTO @ShiftStartDate(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate
		
		
  SELECT @CurrentFormula     =  TagValue,  
    @CurrentFormulaDate    =  ReceivedTime,
    @FormulaIsModified     =  IsModified
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_FRM'   
					
  SELECT @CurrentInjection    =  TagValue,
    @CurrentInjectionDate   =  ReceivedTime,
    @InjectionIsModified   =  IsModified   
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_INJ'

  SELECT @OperationalCount    =  TagValue,
    @OperationalIsModified   =  IsModified  
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_OPC'  
			
  SELECT @EndofFormula     =  TagValue,
    @EndofFormulaDate    =  ReceivedTime  
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_EOF' 
		
  SELECT @AutoWeightEntryActive   =  TagValue     
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_AWEA'                 

  SELECT @CurrentHoldSignal    =  TagValue, 
    @HoldSignalIsModified   =  IsModified,  
    @CurrentHoldSignalDate   =  ReceivedTime 
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_HOLDL'

  SELECT @AutoWeightEntryWeight   =  TagValue     
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_AWEW'

  SELECT @MeterPlcAddress    =  TagValue,
    @MeterPlcAddressIsModified  =       IsModified       
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_MPLC'
		
  SELECT @RatioDosingEnabled    =  TagValue      
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_RATA'
		
		SELECT * FROM #XmlTagsTable
		
  SELECT @ExtraTime      =  0

  SELECT TOP 1 @BatchID=BatchId, @Prveformula=ProgramNumber,@PrevGroupId=GroupId, @PreviousFormulaDate=StartDate FROM TCD.BatchData WHERE MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC

  IF(@CurrentFormula != @EndofFormula AND
     @CurrentFormula = @Prveformula AND 
	 @CurrentInjection = 0 AND
	 @OperationalCount = 0 AND
	 @CurrentFormulaDate <= @PreviousFormulaDate AND
	 @CurrentInjectionDate > @PreviousFormulaDate)
	BEGIN
	--Here means, If the same formula is received without EOF then the timestamp of the formula
	--will be still the old timestamp because value is not changed.
	--In this case assign injection=0 timestamp to formula timestamp
	 SELECT @CurrentFormulaDate = @CurrentInjectionDate	
	END

		DECLARE @ShiftStartDate table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
		INSERT INTO @ShiftStartDate(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate,1

		SELECT DISTINCT 
     @EcolabWasherId    =  Ws.EcolabWasherId,
     @StandardWeight    =  Wps.NominalLoad,
     @CurrencyCode    =  Pl.CurrencyCode,
     @ControllerId    =  Ctrl.ControllerId,
     @TargetTurnTime    =  Ws.TargetTurnTime * 60     
		FROM 
					TCD.Washer Ws		
		INNER JOIN 
					TCD.MachineSetup Mst ON
     Mst.WasherId    =  Ws.WasherId
		INNER JOIN 
					TCD.WasherGroup Wg ON 
     Wg.WasherGroupId   =  Mst.GroupId    
		INNER JOIN 
					TCD.WasherProgramSetup Wps ON 
     Wps.WasherGroupId   =  Wg.WasherGroupId
		LEFT JOIN 
					TCD.WasherDosingSetup Wds ON 
     Wds.WasherProgramSetupId =  Wps.WasherProgramSetupId
		LEFT JOIN 
					TCD.WasherDosingProductMapping Wdpm ON 
     Wdpm.WasherDosingSetupId =  Wds.WasherDosingSetupId
		INNER JOIN 
					TCD.Plant Pl ON 
     Pl.EcolabAccountNumber  =  Ws.EcoLabAccountNumber
		INNER JOIN 
				TCD.ConduitController Ctrl 
    ON Ctrl.ControllerId   =  Mst.ControllerId 
		WHERE Ws.WasherId= @WasherId

		SELECT DISTINCT 
					@MachineInternalId=Mst.MachineInternalId,
					@GroupId=Mst.GroupId					
		FROM TCD.Washer Ws
						INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
						INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
						INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
			WHERE Ws.WasherId=@WasherId 	

			SELECT DISTINCT 					
					@ProgramMasterId=Wps.ProgramId,
					@NominalLoad=Wps.NominalLoad, --Wps.NominalLoad/CONVERT(decimal(10,2), 100) old code
					@MaxLoad =Ws.MaxLoad,
					@ExtraTime =Wps.ExtraTime
		FROM TCD.Washer Ws
						INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
						INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
						INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
						INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
			WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@CurrentFormula and Wps.Is_Deleted=0

		if(@ExtraTime IS NULL)
		BEGIN
			SELECT @ExtraTime      =  0
		END

		SELECT  @MaxWashertGroupCapacity=Max(ws.MaxLoad)
		FROM TCD.Washer WS
			INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
			INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId		
		WHERE Mst.GroupId=@GroupId

		SELECT @WasherMeterExists = M.MachineCompartment FROM Tcd.MachineSetup Ms
		INNER JOIN Tcd.Meter M ON M.GroupId= Ms.GroupId AND  M.MachineCompartment=Ms.MachineInternalId
		WHERE Ms.WasherId=@WasherId

		if(@AutoWeightEntryActive IS NULL)
		BEGIN
			SELECT @AutoWeightEntryActive = 0
		END

		--SELECT @StandardWeight=(@NominalLoad * @MaxLoad) /CONVERT(decimal(10,2), 100) 	
		SELECT @StandardWeight=(@NominalLoad * @MaxWashertGroupCapacity) /CONVERT(decimal(10,2), 100)			
		select @AutoWeightEntryActive,@StandardWeight
		SELECT @AutoWeightEntryWeight=Case @AutoWeightEntryActive WHEN 0 THEN @StandardWeight ELSE  @AutoWeightEntryWeight END 	
		--if(@AutoWeightEntryWeight Is NULL OR @AutoWeightEntryWeight = 0)
		--BEGIN
		--SELECT @AutoWeightEntryWeight = @StandardWeight
		--END			
			
		--SELECT TOP 1 @BatchID=BatchId, @Prveformula=ProgramNumber,@PrevGroupId=GroupId FROM TCD.BatchData WHERE MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC	
		--SELECT @BatchID as BatchID,@EndofFormula as EndofFormula,@CurrentFormula as CurrentFormula,@Prveformula as Prveformula

		SELECT @CurrentHoldSignalValue=Id  FROM TCD.ConduitParameters where Name='HoldSignal'
		
		--SELECT @BatchGroupId=GroupId,@BatchFormula=ProgramNumber,@BatchActualReading=(EndReading - StartReading) FROM TCD.BatchData WHERE BatchId=@BatchID
		--SELECT @BatchStandardReading=SUM(StandardWeight) FROM TCD.WasherDosingSetup WHERE GroupId =@BatchGroupId and ProgramNumber=@BatchFormula
	
		 SELECT  * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC
		IF(@HoldSignalIsModified !=0)	 
		BEGIN
		IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp =@CurrentHoldSignalDate)
			BEGIN
				INSERT INTO TCD.WasherReading(
									WasherId,
									ParameterId,
									ParameterValue,
									DateTimeStamp,
									PartitionOn,
									EcolabWasherId)
    SELECT    @WasherId,
									@CurrentHoldSignalValue,
									@CurrentHoldSignal,
									@CurrentHoldSignalDate,
									(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
									@EcolabWasherId
			END			
		END
		IF(@FormulaIsModified =1  OR @InjectionIsModified = 1 OR @OperationalIsModified = 1)
		BEGIN
			SELECT 'IsModified',@FormulaIsModified AS FormulaIsModified, 
								@InjectionIsModified AS InjectionIsModified,
								@OperationalIsModified AS OperationalIsModified
			IF(@CurrentFormula != 0)
			BEGIN
							DECLARE @BatchShiftId int,@BatchShiftStartDate datetime
							--DECLARE @ShiftStartDateTemp table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
							--INSERT INTO @ShiftStartDateTemp(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate,1		

							SELECT @BatchShiftStartDate = bd.StartDate FROM TCD.BatchData bd WHERE bd.BatchId = @BatchId

							IF(@BatchShiftStartDate > (SELECT TOP 1 [@ShiftStartDate].ShiftStartdate FROM @ShiftStartDate ORDER BY [@ShiftStartDate].ShiftStartdate ASC)
							AND DATEADD(second,@ExtraTime,@CurrentFormulaDate) > (SELECT TOP 1 [@ShiftStartDate].ShiftStartdate FROM @ShiftStartDate ORDER BY [@ShiftStartDate].ShiftStartdate DESC)
							)
							BEGIN 
								 
         SELECT TOP 1  @BatchShiftId = ssdt.ShiftId FROM @ShiftStartDate ssdt ORDER BY ssdt.ShiftStartdate DESC
							END
							ELSE
							BEGIN
        SELECT TOP 1  @BatchShiftId = ssdt.ShiftId FROM @ShiftStartDate ssdt ORDER BY ssdt.ShiftStartdate ASC
							END
							

		SELECT DISTINCT      
			@PrevFormulaExtraTime =Wps.ExtraTime
			FROM TCD.Washer Ws
				INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
				INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
				INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
				INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
				WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@Prveformula and Wps.Is_Deleted=0

		IF(@PrevFormulaExtraTime IS NULL)
		BEGIN
			SELECT @PrevFormulaExtraTime      =  0
		END

					IF(@CurrentFormula = @EndofFormula)
					BEGIN			
					SELECT * FROM #XmlTagsTable
						IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData 
								   WHERE 
											BatchId=@BatchId AND 
											MachineId=@WasherId AND 
											EndDate IS NULL 
											ORDER BY StartDate DESC  )
							BEGIN
																																							
								UPDATE TCD.BatchData 
         SET EndDate = DATEADD(second,@PrevFormulaExtraTime,@CurrentFormulaDate),EndDateFormula = @CurrentFormulaDate,ShiftId = @BatchShiftId 
       WHERE  BatchId = @BatchId AND MachineId=@WasherId   
	   
	   DECLARE @ShiftMapping1 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
	   INSERT INTO @ShiftMapping1(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate,1

	   SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
						IF(@PreviousInjectionStep IS NOT NULL)
						BEGIN
							UPDATE TCD.BatchWashStepData SET EndTime=DATEADD(second,@ExtraTime,@CurrentFormulaDate) WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate
						END
	                                                                  
							END 
					END 
					ELSE IF((@CurrentFormula != @Prveformula) AND (@BatchID IS NOT NULL))
					BEGIN		
					IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC  )
								BEGIN																										
									UPDATE TCD.BatchData
          SET EndDate = @CurrentFormulaDate,EndDateFormula = @CurrentFormulaDate,ShiftId = @BatchShiftId 
         WHERE  BatchId = @BatchId AND MachineId=@WasherId  
		 
		   INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,19,1,(SELECT Top 1 ShiftStartdate from @ShiftStartDate) 
		   
		   DECLARE @ShiftMapping2 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
			INSERT INTO @ShiftMapping2(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate,1
			 
			 SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
					IF(@PreviousInjectionStep IS NOT NULL)
					BEGIN
						UPDATE TCD.BatchWashStepData SET EndTime=@CurrentFormulaDate WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate
					END
			    
								END 
						END
					ELSE IF((@CurrentInjection = 0) AND(@OperationalCount = 0) AND (@CurrentFormulaDate != @PreviousFormulaDate))
					BEGIN		
					IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC)
								BEGIN																											
									UPDATE TCD.BatchData
          SET EndDate = @CurrentInjectionDate,ShiftId = @BatchShiftId,EndDateFormula = @CurrentInjectionDate
         WHERE  BatchId = @BatchId AND MachineId=@WasherId  
		 
		  INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,19,1,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)

		  DECLARE @ShiftMapping3 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
			INSERT INTO @ShiftMapping3(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentInjectionDate,1
		    
			SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
					IF(@PreviousInjectionStep IS NOT NULL)
					BEGIN
						UPDATE TCD.BatchWashStepData SET EndTime=@CurrentInjectionDate WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate
					END

								END 
						END
			
				-- Hold Time
					IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
						BEGIN

						
						SELECT   @HoldTime=SUM(Wr.ParameterValue) FROM TCD. BatchData Bd
						INNER JOIN TCD.WasherReading Wr ON Wr.WasherId=Bd.MachineId
						WHERE Bd.BatchId=@BatchId  AND Wr.DateTimeStamp BETWEEN Bd.StartDate AND  Bd.EndDate and   Wr.ParameterId=9 -- Hold Signal value

						INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,17,@HoldTime,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)


					END
					
					-- CapturingMeter Plc Address EndRedaing 
					IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
						BEGIN
						IF(@WasherMeterExists IS NOT NULL AND @MeterPlcAddress > 0)
						BEGIN
							IF(@MeterPlcAddressIsModified !=0)	 
							BEGIN
							IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp =@CurrentFormulaDate)
							BEGIN
								INSERT INTO TCD.WasherReading(
									WasherId,
									ParameterId,
									ParameterValue,
									DateTimeStamp,
									PartitionOn,
									EcolabWasherId)
								SELECT	
									@WasherId,
									14, --MeterPlcAddress for EndSReading
									@MeterPlcAddress,
									@CurrentFormulaDate,
									(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
									@EcolabWasherId
							END

						END
						END
					END
									
					--Start Good or Bad Injection in BatchDataTable
					IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
						BEGIN
								;WITH CteTempWaherReadingInjections  (	
								InjectionsCount,BatchId,WasherId,ProgramNumber,Injectons
							) AS  
							(
								SELECT DISTINCT Wr.ParameterValue,
												BD.BatchId,
												Wr.WasherId,
												Bd.ProgramNumber,
												Wr.ParameterValue FROM TCD. BatchData Bd
								INNER JOIN 
          TCD.WasherReading Wr ON Wr.WasherId   =  Bd.MachineId 
								WHERE    
              Wr.ParameterId    =  10    AND 
              Wr.ParameterValue   <>  0    AND 
              Bd.BatchId     =  @BatchID AND WR.DateTimeStamp BETWEEN BD.StartDate AND BD.EndDate) 
								SELECT @CteTempWaherReadingInjections=COUNT(CTE1.InjectionsCount)
								FROM CteTempWaherReadingInjections CTE1 
								INNER JOIN TCD.BatchData Bd ON Bd.BatchId=CTE1.BatchId
								WHERE Bd.BatchId=@BatchId

								;WITH CteTempBatchInjections (	
								InjectionsCount,BatchId,WasherId,ProgramNumber,Injectons
							) AS  
							(
								SELECT  DISTINCT Wdpm.InjectionNumber,
												Bd.BatchId,
												Wps.ProgramNumber,
												Ws.WasherId,Wdpm.
												InjectionNumber
									FROM TCD.Washer WS
										INNER JOIN 
													TCD.MachineSetup Mst ON 
             Mst.WasherId     =  WS.WasherId
										INNER JOIN 
													TCD.WasherGroup Wg ON 
             Wg.WasherGroupId    =  Mst.GroupId       
										INNER JOIN 
													TCD.WasherProgramSetup Wps ON 
             Wps.WasherGroupId    =  Wg.WasherGroupId
										INNER JOIN 
													TCD.WasherDosingSetup Wds ON 
             Wds.WasherProgramSetupId  =  Wps.WasherProgramSetupId
										INNER JOIN 
													TCD.WasherDosingProductMapping Wdpm ON 
             Wdpm.WasherDosingSetupId  =  Wds.WasherDosingSetupID
										INNER JOIN 
													TCD.ProductdataMapping Pdm ON 
             Pdm.ProductId     =  Wdpm.ProductId
										INNER JOIN 
													TCD.BatchData Bd ON 
             Bd.MachineId     =  Ws.WasherId 
										INNER JOIN 
													TCD.WasherReading Wr ON 
             Wr.WasherId      =  Bd.MachineId
								WHERE 
								
             Wps.ProgramNumber    =  @Prveformula  AND 
             Bd.BatchId      =  @BatchID   AND 
             Ws.WasherId      =  @WasherId    )
								SELECT @CteTempBatchInjections=COUNT(CTE2.InjectionsCount)
								FROM CteTempBatchInjections CTE2 
								INNER JOIN TCD.BatchData Bd ON Bd.BatchId=CTE2.BatchId 
								WHERE Bd.BatchId=@BatchID


								Insert Tcd.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchID,@EcolabWasherId,18,
          CASE WHEN @CteTempBatchInjections = @CteTempWaherReadingInjections THEN 1
            WHEN @CteTempBatchInjections != @CteTempWaherReadingInjections THEN 3 END,
												(SELECT Top 1 ShiftStartdate from @ShiftStartDate)	
																											
				END
					--End Good or Bad Injection in BatchDataTable	
					IF(@OperationalCount = 0 AND @CurrentInjection = 0) AND (@CurrentFormula != @EndofFormula)
					--IF(@OperationalCount = 0 AND @CurrentInjection = 0) 
					BEGIN	
						IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchData WHERE MachineId=@WasherId AND StartDate =@CurrentFormulaDate)
						BEGIN					
       
							INSERT INTO TCD.BatchData(
										ControllerBatchId ,
										EcolabWasherId,
										GroupId ,
										MachineInternalId,
										PlantWasherNumber,
										StartDate ,
										EndDate ,
										ProgramNumber,
										ProgramMasterId,
										MachineId,
										ActualWeight,
										StandardWeight,
										CurrencyCode,
										ShiftId,									
										PartitionOn,
										TargetTurnTime										
										)


									SELECT DISTINCT 0
										,@EcolabWasherId
										,@GroupId
										,@MachineInternalId
										,Ws.PlantWasherNumber
										,@CurrentFormulaDate
										,NULL
										,@CurrentFormula
										,@ProgramMasterId
										,@WasherId
										,@AutoWeightEntryWeight
										,@StandardWeight 
										,@CurrencyCode
										,(SELECT Top 1 ShiftId from @ShiftStartDate)									
										,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
										,@TargetTurnTime
										

							FROM TCD.Washer Ws
										INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
										INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
										INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
							WHERE Ws.WasherId=@WasherId 
			
							SET @BatchID=SCOPE_IDENTITY()	
									
							--If the received formula is not configured in enVision then create an alarm 
							IF(@ProgramMasterId is NULL)
							BEGIN
							SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant
								INSERT INTO [TCD].[AlarmData] 
								   (EcoalabAccountNumber,
								   AlarmCode,
								   BatchId,
								   controllerID,
								   StartDate,
								   GroupId,
								   MachineInternalId,
								   ProgramId,   
								   IsActive,
								   EndDate,
								   MachineId)
									  SELECT
									   @ECOLABAccountNumber,
									   9000,
									   @BatchID,
									   @ControllerId,
									   @CurrentFormulaDate,
									   @GroupId,
									   @MachineInternalId,
									   @CurrentFormula,
									   0,
									   @CurrentFormulaDate,
									   @WasherId
							END

									
									INSERT INTO TCD.BatchCustomerData
									(
									BatchId,
									CustomerId,
									Weight,
									PiecesCount,
									PartitionOn,
									EcolabWasherId
									)
								SELECT Bd.BatchId,  
								--SELECT @BatchID,
									Pc.ID,
									@AutoWeightEntryWeight,
									ROUND(COALESCE((@AutoWeightEntryWeight * Pm.Pieces) / NULLIF(Pm.Weight,0), 0),0),
									(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
									@EcolabWasherId
								
						
							FROM TCD.Washer WS
								INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
								INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId							
								INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
								INNER JOIN TCD.ProgramMaster Pm ON Pm.ProgramId=Wps.ProgramId
								INNER JOIN TCD.PlantCustomer Pc ON Pc.ID=Pm.CustomerId
								INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
							WHERE 
								Ws.WasherId=@WasherId AND 
								Wps.ProgramNumber=@CurrentFormula AND 
								Bd.BatchId=@BatchID  AND 
								Pm.CustomerId != -1 

							IF(@WasherMeterExists IS NOT NULL AND @MeterPlcAddress > 0)
							BEGIN								
								IF(@MeterPlcAddressIsModified !=0)	 
								BEGIN
										INSERT INTO TCD.WasherReading(
											WasherId,
											ParameterId,
											ParameterValue,
											DateTimeStamp,
											PartitionOn,
											EcolabWasherId)
										SELECT	
											@WasherId,
											13, --MeterPlcAddress for StartReading
											@MeterPlcAddress,
											@CurrentFormulaDate,
											(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
											@EcolabWasherId
								END
							END	
						END														
					END	 				
					IF(@BatchID IS NOT NULL)					
					BEGIN
					IF(@CurrentInjection <= 0)
						BEGIN
							SET @CurrentInjectionDate=@CurrentFormulaDate
						END	
						IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp =@CurrentInjectionDate)
						BEGIN						
						INSERT INTO TCD.WasherReading(
										WasherId,
										ParameterId,
										ParameterValue,
										DateTimeStamp,
										PartitionOn,
										EcolabWasherId)
      SELECT   @WasherId,
										CASE TagType 
										WHEN 'Tag_FRM' THEN  5  
										WHEN 'Tag_INJ' THEN  10 
										WHEN 'Tag_OPC' THEN  11 
										END,
										TagValue,										
										@CurrentInjectionDate,
										(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
										@EcolabWasherId
       FROM  #XmlTagsTable 
       WHERE  Tagtype in ('Tag_FRM','Tag_INJ','Tag_OPC')         
					END
					END
				IF(@CurrentInjection > 0)					
					BEGIN
						IF (@RatioDosingEnabled = 1)
							BEGIN
							IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurrentInjectionDate and batchid=@BatchID)
							BEGIN
								INSERT INTO TCD.BatchProductData(BatchId,StepCompartment,ActualQuantity,StandardQuantity,Price,TimeStamp,PartitionOn,EcolabWasherId,ProductId)
								SELECT Bd.BatchId	
								--SELECT @BatchID	
									,Wds.StepNumber
         ,(((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100)) * (@AutoWeightEntryWeight/@StandardWeight) AS ActualQuantity  
         ,(((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100)) * (@AutoWeightEntryWeight/@StandardWeight) AS StandardQuantity      
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * @MaxWashertGroupCapacity)/CONVERT(decimal(10,2), 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price         
									,@CurrentInjectionDate
									,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
									,@EcolabWasherId
									,Pdm.ProductID
								FROM TCD.Washer WS
									INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
									INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
									INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
									INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
									INNER JOIN TCD.WasherDosingSetup Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
									INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
									INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Wdpm.ProductId
									INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
								WHERE 
          Ws.WasherId=@WasherId     AND 
          Wps.ProgramNumber=@CurrentFormula  AND 
          Wdpm.InjectionNumber=@CurrentInjection AND
										Bd.BatchId=@BatchID AND
		  Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
							END
							END
						ELSE
							BEGIN
							IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurrentInjectionDate and batchid=@BatchID)
							BEGIN
								INSERT INTO TCD.BatchProductData(BatchId,StepCompartment,ActualQuantity,StandardQuantity,Price,TimeStamp,PartitionOn,EcolabWasherId,ProductId)
								SELECT Bd.BatchId		
								--SELECT @BatchID
									,Wds.StepNumber
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100) AS ActualQuantity  
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100) AS StandardQuantity      
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * @MaxWashertGroupCapacity)/CONVERT(decimal(10,2), 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price         
									,@CurrentInjectionDate
									,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
									,@EcolabWasherId
									,Pdm.ProductID
								FROM TCD.Washer WS
									INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
									INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
									INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
									INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
									INNER JOIN TCD.WasherDosingSetup Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
									INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
									INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Wdpm.ProductId
									INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
								WHERE 
          Ws.WasherId=@WasherId     AND 
          Wps.ProgramNumber=@CurrentFormula  AND 
          Wdpm.InjectionNumber=@CurrentInjection AND
										Bd.BatchId=@BatchID AND
		  Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
							END		
							END	
							
		--Populating BatchWashstepdata
						SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
						
						IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchWashStepData WHERE StartTime =@CurrentInjectionDate and batchid=@BatchID)
						BEGIN
									SELECT @CurrentInjectionStep=Wds.StepNumber,
										   @WashStepBatchId=Bd.BatchId
         								
									FROM TCD.Washer WS
										INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
										INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
										INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
										INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
										INNER JOIN TCD.WasherDosingSetup Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
										INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
										INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Wdpm.ProductId
										INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
									WHERE 
										Ws.WasherId=@WasherId     AND 
										Wps.ProgramNumber=@CurrentFormula  AND 
										Wdpm.InjectionNumber=@CurrentInjection AND
										Bd.BatchId=@BatchID AND
										Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0

									IF(@CurrentInjectionStep IS NOT NULL)
									BEGIN
										INSERT INTO TCD.BatchWashStepData(BatchId,StepCompartment,StartTime,PartitionOn,EcolabWasherId)
										VALUES (@WashStepBatchId,  @CurrentInjectionStep, @CurrentInjectionDate, (SELECT Top 1 ShiftStartdate from @ShiftStartDate), @EcolabWasherId)																
									
										UPDATE TCD.BatchWashStepData SET EndTime=@CurrentInjectionDate WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate									
									END

						END
						--End Populating BatchWashstepdata
										
					END

					UPDATE TCD.ConduitController
      SET LastConnectedTime  = GETUTCDATE()
      WHERE ControllerId   = @ControllerId
			END
		END
	END


	GO

IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[SaveWaterAndEnergyDetails]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[SaveWaterAndEnergyDetails] 
END 
GO 
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[SaveWaterAndEnergyDetails] (
									   @ID INT = NULL
									 , @DeviceNumber INT = NULL
									 , @DeviceName NVARCHAR(200) = NULL
									 , @DeviceTypeId INT = NULL
									 , @DeviceModelId INT = NULL
									 , @DeviceNote NVARCHAR(1000) = NULL
									 , @EcolabAccountNumber NVARCHAR(25) = NULL
									 , @Comment NVARCHAR(1000) = NULL
									 , @InstallDate DATETIME = NULL
									 , @Is_deleted BIT = NULL
									 , @UserID INT = NULL
									 , @Scope INT = NULL OUTPUT
									 , @OutputDeviceNumber						INT = NULL	OUTPUT
									 , @LastModifiedTimestampAtCentral			DATETIME = NULL
									 , @MyServiceCustWtrEnrgDvcGuid			UNIQUEIDENTIFIER
									 , @OutputLastModifiedTimestampAtLocal		DATETIME = NULL	OUTPUT
									 , @MyServiceLastSyncTime					DATETIME				=	NULL
) 
AS 
  BEGIN 
      SET NOCOUNT ON; 
	  	DECLARE	
	    @ReturnValue					INT = 0
	    ,@ErrorId						INT = 0
	    ,@ErrorMessage					NVARCHAR(4000) = N''
	    ,@CurrentUTCTime					DATETIME = GETUTCDATE();
	DECLARE
			@OutputList						AS	TABLE		(
			OutputDeviceNumber					INT
	    ,LastModifiedTimestamp			DATETIME
	    );

		/* Inserting the values in to WaterAndEnergy table if it is new meter */

	SET	@OutputDeviceNumber			=			ISNULL(@OutputDeviceNumber, NULL)			--SQLEnlight SA0121
	SET	@Scope						=			ISNULL(@Scope, NULL)						--SQLEnlight SA0121


      IF NOT EXISTS (SELECT * 
				 FROM   TCD.WaterAndEnergy
                 WHERE  Id = @ID) 
			 BEGIN 
			 IF NOT EXISTS (SELECT 1 
					    FROM   TCD.WaterAndEnergy
                 WHERE  DeviceName = @DeviceName 
						AND DeviceTypeId = @DeviceTypeId 
						AND DeviceModelId = @DeviceModelId
						  AND Is_deleted = 'FALSE'
						) 
			 BEGIN 

			 /* Inserting the Details of Water and Energy  in to WaterAndEnergy table if it is new device */

				INSERT INTO TCD.WaterAndEnergy
												(DeviceNumber,
												 DeviceName,
												DeviceTypeId, 
												DeviceModelId, 
												DeviceNote, 
												EcolabAccountNumber, 
												Comment, 
												InstallDate, 
												Is_deleted,
												LastModifiedByUserId,
												MyServiceCustWtrEnrgDvcGuid,
												MyServiceLastSynchTime
												) 
							OUTPUT
								inserted.Id						AS			OutputDeviceNumber
				,inserted.LastModifiedTime					AS			LastModifiedTimestamp
							INTO
								@OutputList	(
								OutputDeviceNumber
					  ,LastModifiedTimestamp
							)   
				SELECT
												@DeviceNumber,
												@DeviceName,
												@DeviceTypeId,
												@DeviceModelId, 
												@DeviceNote, 
												@EcolabAccountNumber,
												@Comment,
												@InstallDate, 
												@Is_deleted,
												@UserID,
												@MyServiceCustWtrEnrgDvcGuid,
												@MyServiceLastSyncTime	
			 END;
			  ELSE
			  BEGIN 
				SET @ErrorMessage = '401';
				RAISERROR(@ErrorMessage, 16, 1);
				RETURN;
			 END;
	   END;
    ELSE
		  BEGIN 
		  IF	@LastModifiedTimestampAtCentral				IS NOT	NULL
		 AND NOT	EXISTS	(	SELECT	1
									FROM	TCD.WaterAndEnergy		WE
							  WHERE	WE.EcolabAccountNumber = @EcolabAccountNumber
								 AND WE.Id = @ID
								 AND WE.LastModifiedTime = @LastModifiedTimestampAtCentral
					)
								BEGIN
				SET			@ErrorId = 60000;
				SET			@ErrorMessage = N''
										 +
										 CAST(@ErrorId AS NVARCHAR)
										 +
										 N': Record not in-synch between plant and central.';
				RAISERROR	(@ErrorMessage, 16, 1);
				SET			@ReturnValue = -1;
				RETURN @ReturnValue;
			 END;
				 IF NOT EXISTS (SELECT 1 
					    FROM   TCD.WaterAndEnergy
                 WHERE  DeviceName = @DeviceName 
						AND DeviceTypeId = @DeviceTypeId 
						  AND DeviceModelId = @DeviceModelId
						  AND Id != @ID 
						  AND Is_deleted = 'FALSE')
				BEGIN 

            /* Updating the value of Water And Energy details */              

                UPDATE WE 
                SET    
				DeviceNumber = @DeviceNumber,
				DeviceName = @DeviceName,
				DeviceTypeId = @DeviceTypeId ,
				DeviceModelId = @DeviceModelId ,
									Comment = @Comment , 
									InstallDate = @InstallDate,
									DeviceNote = @DeviceNote,
				LastModifiedByUserId = @UserID	,
				LastModifiedTime = @CurrentUTCTime
				OUTPUT
						inserted.Id						AS			OutputDeviceNumber
				,inserted.LastModifiedTime					AS			LastModifiedTimestamp
				INTO
						@OutputList	(
						OutputDeviceNumber
					  ,LastModifiedTimestamp
				)   
				  FROM   TCD.WaterAndEnergy WE
				  WHERE Id = @ID;
				SELECT @Scope = @DeviceNumber;
			 END;
				 ELSE
				 BEGIN 
				SET @ErrorMessage = '401';
				RAISERROR(@ErrorMessage, 16, 1);
				RETURN;
			 END;
	   END;
	SELECT	TOP 1	

		@OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp

	,	@OutputDeviceNumber				=		O.OutputDeviceNumber

	FROM	@OutputList							O





	RETURN	(@ReturnValue)

--SET NOCOUNT OFF;

END
GO

IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[SaveControllerSetupData]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[SaveControllerSetupData] 
END 
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[SaveControllerSetupData] 
(
  @ControllerSetupData     XML
 , @UserId         INT
 , @ControllerId       INT      OUTPUT
 , @LastModifiedTimestampAtCentral   DATETIME = NULL
 , @OutputLastModifiedTimestampAtLocal  DATETIME = NULL OUTPUT
)
AS
BEGIN
      SET NOCOUNT ON
   --DECLARE @ControllerId INT
   DECLARE @ControllerNumber    INT     = NULL
   DECLARE @ControllerModelId   INT     = NULL
   DECLARE @ControllerModelName   VARCHAR(50)   = NULL
   DECLARE @ControllerTypeId    INT     = NULL
   DECLARE @ControllerTypeName   VARCHAR(50)   = NULL
   DECLARE @EcolabAccountNumber   VARCHAR(1000)  = NULL
   DECLARE @TopicName     VARCHAR(1000)  = NULL
   DECLARE @Active      BIT
   DECLARE @ErrorMessage     VARCHAR(200)  = NULL
   
   DECLARE
   @OutputList      AS TABLE  (
   ControllerId     INT
  , LastModifiedTimestamp   DATETIME
  )

  SET @ControllerId       =   ISNULL(@ControllerId, NULL)       --SQLEnlight SA0121
  SET @OutputLastModifiedTimestampAtLocal  =   ISNULL(@OutputLastModifiedTimestampAtLocal, NULL) --SQLEnlight SA0121


   SELECT @ControllerNumber = Tbl.col.value('@ControllerNumber', 'int')
     FROM   @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl (col)

   SELECT @ControllerModelId = Tbl.col.value('@ControllerModelId', 'int')
     FROM   @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl (col)

   SELECT @ControllerTypeId = Tbl.col.value('@ControllerTypeId', 'int')
     FROM   @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl (col)
   
   SELECT @EcolabAccountNumber = Tbl.col.value('@EcolabAccountNumber', 'varchar(1000)')
     FROM   @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl (col)

    SELECT @TopicName = Tbl.col.value('@TopicName', 'varchar(1000)')
     FROM   @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl (col)

    SELECT @Active = Tbl.col.value('@Active', 'bit')
     FROM   @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl (col)
   
   IF EXISTS(SELECT 1 FROM [TCD].ConduitController WITH(NOLOCK) WHERE ControllerNumber = @ControllerNumber AND IsDeleted = 0 AND EcoalabAccountNumber = @EcolabAccountNumber)
   BEGIN
  SET @ErrorMessage ='303 - Controller Number already exists.'
   RAISERROR(@ErrorMessage, 16, 1)
   RETURN
   END

   IF EXISTS (SELECT 1 FROM [TCD].ConduitController WITH (NOLOCK) WHERE TopicName = @TopicName AND IsDeleted = 0 AND EcoalabAccountNumber = @EcolabAccountNumber)
	BEGIN
		SET @ErrorMessage = '304 - Controller Name already exists.'
		RAISERROR (@ErrorMessage ,16 ,1)
		RETURN
	END

   SELECT @ControllerModelName = Name FROM [TCD].ControllerModel WITH(NOLOCK) WHERE Id = @ControllerModelId
   SELECT @ControllerTypeName = Name FROM [TCD].ControllerType WITH(NOLOCK) WHERE Id = @ControllerTypeId

   DECLARE @TempMaster TABLE
        (
    EcolabAccountNumber  NVARCHAR(1000)
     , Name     VARCHAR(100)
           , ControllerModelId  INT
           , ControllerNumber  INT
           , ControllerTypeId  INT
           , ControllerVersion  VARCHAR(10)
           , InstallDate    DATETIME
     , UserId     INT
     , TopicName    VARCHAR(1000)
     , Active     BIT
        )

  DECLARE @TempDynamic TABLE
        (
    EcolabAccountNumber  NVARCHAR(1000)
     , ControllerId   INT
           , ControllerModelId  INT
           , FieldGroupId   INT
           , FieldId     INT
           , Value     VARCHAR(1000)
     , UserId     INT
        )

 BEGIN TRANSACTION
  BEGIN TRY
   INSERT INTO @TempMaster
                  (
      EcolabAccountNumber
     , Name
     , ControllerModelId
     , ControllerNumber
     , ControllerTypeId
     , ControllerVersion
     , InstallDate
     , UserId
     , TopicName
     , Active
     )
     SELECT 
    @EcolabAccountNumber
    ,CAST(Tbl.col.value('@ControllerNumber', 'int') AS VARCHAR(10)) + ' (' + Tbl.col.value('@TopicName', 'varchar(100)')+ ')'
    ,Tbl.col.value('@ControllerModelId', 'int')
    ,Tbl.col.value('@ControllerNumber', 'int')
    ,Tbl.col.value('@ControllerTypeId', 'varchar(100)')
    ,Tbl.col.value('@ControllerVersion', 'varchar(10)')
    ,CAST(Tbl.col.value('@InstallDate', 'datetime') AS DATETIME)
    ,@UserId
    ,Tbl.col.value('@TopicName', 'varchar(100)')
    ,Tbl.col.value('@Active','bit')
     FROM   @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl (col)

   INSERT INTO [TCD].ConduitController(EcoalabAccountNumber,Name,ControllerModelId,ControllerNumber,ControllerTypeId,ControllerVersion,InstallDate, TopicName,Active,LastModifiedByUserId)
   OUTPUT
     inserted.ControllerId   AS   ControllerId
    , inserted.LastModifiedTime  AS   LastModifiedTimestamp
    INTO
     @OutputList (
     ControllerId
    , LastModifiedTimestamp
    )
   
   SELECT EcolabAccountNumber,Name,ControllerModelId,ControllerNumber,ControllerTypeId,ControllerVersion,InstallDate,TopicName, Active,UserId FROM @TempMaster

   SELECT TOP 1 @ControllerId = O.ControllerId FROM @OutputList O

   INSERT INTO @TempDynamic
      (
       EcolabAccountNumber
      , ControllerId
      , ControllerModelId
      , FieldGroupId
      , FieldId
      , Value
      , UserId
      )
   SELECT 
     @EcolabAccountNumber
    , @ControllerId
    , Tbl.col.value('@ControllerModelId', 'int')
    , Tbl.col.value('@FieldGroupId', 'int')
    , Tbl.col.value('@FieldId', 'int')
    , Tbl.col.value('@Value', 'varchar(1000)')
    , @UserId
   FROM   @ControllerSetupData.nodes('/ControllerSetupData/DynamicSetupData/Data') AS Tbl (col)

   INSERT INTO [TCD].ControllerSetupData(EcolabAccountNumber, ControllerId,FieldGroupId,FieldId,Value,ControllerModelId,LastModifiedByUserId)
   SELECT EcolabAccountNumber, ControllerId,FieldGroupId,FieldId,Value,ControllerModelId,UserId FROM @TempDynamic

   DECLARE @TempControllerTypeId INT, 
		   @MaxInjectionClasses INT
   SELECT @TempControllerTypeId = ControllerTypeId FROM TCD.ConduitController WHERE ControllerId = @ControllerId

   IF (@TempControllerTypeId = 1)
   BEGIN
	SET @MaxInjectionClasses = 6
   END

    IF (@TempControllerTypeId = 2)
   BEGIN
	SET @MaxInjectionClasses = 8
   END
    
	UPDATE tcd.ConduitController SET LFSInjectionClasses = @MaxInjectionClasses where ControllerId = @ControllerId
 
   COMMIT TRANSACTION

   SELECT TOP 1 @OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp FROM @OutputList O

  END TRY
  BEGIN CATCH
   SELECT 
    ERROR_NUMBER() AS ErrorNumber,
    ERROR_SEVERITY() AS ErrorSeverity,
    ERROR_STATE() AS ErrorState,
    ERROR_PROCEDURE() AS ErrorProcedure,
    ERROR_LINE() AS ErrorLine,
    ERROR_MESSAGE() AS ErrorMessage

   ROLLBACK TRANSACTION
  END CATCH
SET NOCOUNT OFF
END
GO

IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[UpdateControllerSetupData]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[UpdateControllerSetupData] 
END 
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[UpdateControllerSetupData] 

(
		@ControllerSetupData					XML
	,	@UserId									INT
	,	@LastModifiedTimestampAtCentral			DATETIME					=	NULL
	,	@OutputLastModifiedTimestampAtLocal		DATETIME					=	NULL	OUTPUT
)

AS

BEGIN

      SET NOCOUNT ON

	  DECLARE @EcolabAccountNumber	VARCHAR(1000)	=		NULL
	  DECLARE @ControllerId			INT				=		NULL

	  DECLARE
			@OutputList						AS	TABLE		(
			LastModifiedTimestamp			DATETIME
		)


	  DECLARE	
		@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()
	,	@TopicName						VARCHAR(1000)	=			NULL

	  
	  
	  DECLARE @TempMaster TABLE

        (

				ControllerId			INT

		   ,	EcolabAccountNumber		VARCHAR(1000)

		   ,	Name					VARCHAR(100)

           ,	ControllerModelId		INT

           ,	ControllerNumber		INT

           ,	ControllerTypeId		INT

           ,	ControllerVersion		VARCHAR(10)

           ,	InstallDate				DATETIME

		   ,	TopicName				VARCHAR(1000)

		   ,	Active					BIT

        )

		DECLARE @TempDynamic TABLE

        (

				ControllerId			INT

			,	EcolabAccountNumber		VARCHAR(1000)

			,	ControllerModelId		INT

           ,	FieldGroupId			INT

           ,	FieldId					INT

           ,	Value					VARCHAR(1000)

        )

	SET		@OutputLastModifiedTimestampAtLocal			=			ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight

	SELECT @EcolabAccountNumber = Tbl.col.value('@EcolabAccountNumber', 'varchar(1000)')

			  FROM   @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl (col)

	SELECT @ControllerId = Tbl.col.value('@ControllerId', 'int')

			  FROM   @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl (col)

	SELECT @TopicName = Tbl.col.value('@TopicName', 'varchar(1000)')
		FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)

    IF	(
									@LastModifiedTimestampAtCentral				IS NOT	NULL
									AND
									NOT	EXISTS	(	SELECT	1
											FROM	TCD.ConduitController		CC
											WHERE	CC.EcoalabAccountNumber		=	@EcolabAccountNumber
												AND	CC.ControllerId				=	@ControllerId
												AND	CC.LastModifiedTime			=	@LastModifiedTimestampAtCentral
										)
				)
			BEGIN
					SET			@ErrorId				=	60000
					SET			@ErrorMessage			=	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
					RAISERROR	(@ErrorMessage, 16, 1)
					RETURN
			END

			/*Validating Controle name duplicate*/
			IF EXISTS ( SELECT 1 FROM [TCD].ConduitController WITH (NOLOCK) WHERE TopicName = @TopicName AND IsDeleted = 0 AND ControllerId != @ControllerId AND EcoalabAccountNumber = @EcolabAccountNumber)
			BEGIN
				SET @ErrorMessage = '304 - Controller Name already exists.'
				RAISERROR ( @ErrorMessage,16,1)	
			RETURN
			END


	BEGIN TRANSACTION

		BEGIN TRY

			INSERT INTO @TempMaster

                  (
				    ControllerId

					,	EcolabAccountNumber

					,	ControllerModelId

					,	ControllerNumber

					,	ControllerTypeId

					,	ControllerVersion

					,	InstallDate

					,	TopicName

					,	Active
					)

			  SELECT 

					@ControllerId

				,	@EcolabAccountNumber

				,	Tbl.col.value('@ControllerModelId', 'int')

				,	Tbl.col.value('@ControllerNumber', 'int')

				,	Tbl.col.value('@ControllerTypeId', 'int')

				,	Tbl.col.value('@ControllerVersion', 'varchar(10)')

				,	CAST(Tbl.col.value('@InstallDate', 'datetime') AS DATETIME)

				,	Tbl.col.value('@TopicName', 'varchar(1000)')

				,	Tbl.col.value('@Active', 'bit')

			  FROM   @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl (col)


			
			UPDATE [TCD].ConduitController

			SET 
				ControllerVersion		=	tm.ControllerVersion
			,	InstallDate				=	tm.InstallDate
			,	TopicName				=	tm.TopicName
			,	Active					=	tm.Active
			,	LastModifiedByUserId	=	@UserId
			,	LastModifiedTime		=	@CurrentUTCTime
			,	Name					=	CAST(tm.ControllerNumber AS varchar(10))+'('+tm.TopicName+')'
			OUTPUT
				inserted.LastModifiedTime		AS			LastModifiedTimestamp
			INTO
				@OutputList	(
				LastModifiedTimestamp
			)

			FROM 

			[TCD].ConduitController CC

			INNER JOIN @TempMaster tm ON tm.ControllerId = CC.ControllerId AND tm.EcolabAccountNumber = CC.EcoalabAccountNumber


			INSERT INTO @TempDynamic

						(

						ControllerId

						,	EcolabAccountNumber
						
						,	ControllerModelId

						,	FieldGroupId

						,	FieldId

						,	Value

						)

			SELECT 

				Tbl.col.value('@ControllerId', 'int')

				,	@EcolabAccountNumber

				,	Tbl.col.value('@ControllerModelId', 'int')

				,	Tbl.col.value('@FieldGroupId', 'int')

				,	Tbl.col.value('@FieldId', 'int')

				,	Tbl.col.value('@Value', 'varchar(1000)')

			FROM   @ControllerSetupData.nodes('/ControllerSetupData/DynamicSetupData/Data') AS Tbl (col)


			UPDATE [TCD].ControllerSetupData 

			SET 
				Value = td.Value

			,	LastModifiedByUserId	=	@UserId

			FROM 

			[TCD].ControllerSetupData CSD

			INNER JOIN @TempDynamic td 

			ON 

			td.ControllerId = CSD.ControllerId

			AND 

			td.FieldGroupId = CSD.FieldGroupId

			AND

			td.FieldId = CSD.FieldId

			AND

			td.ControllerModelId = CSD.ControllerModelId

			AND

			td.EcolabAccountNumber = CSD.EcolabAccountNumber
	
			SELECT	TOP 1 @OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp FROM	@OutputList	O

			COMMIT TRANSACTION

		END TRY

		BEGIN CATCH

			SELECT 

				ERROR_NUMBER() AS ErrorNumber,

				ERROR_SEVERITY() AS ErrorSeverity,

				ERROR_STATE() AS ErrorState,

				ERROR_PROCEDURE() AS ErrorProcedure,

				ERROR_LINE() AS ErrorLine,

				ERROR_MESSAGE() AS ErrorMessage



			ROLLBACK TRANSACTION

		END CATCH

END
GO

IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[GetReportDynamicDataByFilterId]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[GetReportDynamicDataByFilterId] 
END 
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[GetReportDynamicDataByFilterId]
								(
								    @UserId INT = NULL,
								    @RoleId INT = NULL,
								    @RegionId Nvarchar(1000) = NULL,
								    @CountryId Nvarchar(1000) = NULL,
								    @IsLocal BIT = NULL,
								    @PlantID Nvarchar(1000) = NULL,
								    @IsCountry BIT = 0,
								    @FilterId INT = NULL
								)   
AS 
SET NOCOUNT ON
BEGIN

    SELECT @PlantID = P.EcolabAccountNumber FROM TCD.Plant P

	   DECLARE @PlantTable TABLE(PlantID Varchar(100))
	   INSERT INTO @PlantTable EXEC [TCD].[CharlistToTable] @PlantID,','
	   
	     DECLARE @ResultTable TABLE
						  (
							 Id nvarchar(2000),
							 Name nvarchar(300),
							 TypeId Int
						  )

	   IF(@FilterId = 7)    --Filter Options for Ecolab Category
		  BEGIN
		  
		  INSERT INTO @ResultTable (
									   Id,
									   Name,
									   TypeId
								     )
		  SELECT 
				TextileId AS Id,
				CategoryName AS Name,
				@FilterId 
			 FROM [TCD].[EcolabTextileCategory]
				
		  END

		  IF(@FilterId = 9)   --Filter Options for Customers
		  BEGIN
		  INSERT INTO @ResultTable (
									   Id,
									   Name,
									   TypeId
								     )			
		  SELECT 
				PC.CustomerId AS Id,
				PC.CustomerName AS Name,
				@FilterId
			 FROM [TCD].[PlantCustomer] PC 
				WHERE PC.EcolabAccountNumber IN (SELECT PlantID FROM @PlantTable)
				
		  END


	    IF(@FilterId = 10)   --Filter Options for plant formulas
		  BEGIN
			
			 INSERT INTO @ResultTable (
									   Id,
									   Name,
									   TypeId
								     )		
		  SELECT 
				PM.ProgramId AS Id,
				PM.Name AS Name,
				@FilterId
			 FROM [TCD].ProgramMaster PM
				WHERE PM.EcolabAccountNumber IN (SELECT PlantID FROM @PlantTable)
				
		  END
    
	   IF(@FilterId = 23)   --Filter Options for Plant chain categories
		    BEGIN

			 INSERT INTO @ResultTable (
									   Id,
									   Name,
									   TypeId
								     )		
		  SELECT 
				CT.TextileId AS Id,
				CT.Name AS Name,
				@FilterId
			 FROM [TCD].[ChainTextileCategory] CT
				WHERE CT.PlantChainId IN (SELECT P.PlantChainId FROM TCD.PLANT P WHERE P.EcolabAccountNumber IN (SELECT PlantID FROM @PlantTable))
				OR CT.PlantChainId IS NULL
		    END

	    IF(@FilterId = 24)   --Filter Options for plant chain programs
		    BEGIN
		
		INSERT INTO @ResultTable (
									   Id,
									   Name,
									   TypeId
								     )		
		  SELECT 
				PC.PlantProgramId AS Id,
				PC.PlantProgramName AS Name,
				@FilterId
			 FROM [TCD].[PlantChainProgram] PC
				    WHERE PC.PlantChainId IN (SELECT P.PlantChainId FROM TCD.PLANT P WHERE P.EcolabAccountNumber IN (SELECT PlantID FROM @PlantTable))     
					OR PC.PlantChainId IS NULL
		    END

		    IF(@FilterId = 11)   --Filter Options for dispencer
		    BEGIN
		
		    INSERT INTO @ResultTable (
										  Id,
										  Name,
										  TypeId
									    )
			SELECT 
				    PC.ControllerId AS Id,
				    PC.Name AS Name,
				    @FilterId
				FROM TCD.ConduitController PC
					   WHERE PC.EcoalabAccountNumber IN (SELECT PlantID FROM @PlantTable)
		   END		

		   IF(@FilterId = 12)   --Filter Options for ALARM
		    BEGIN
		
		    INSERT INTO @ResultTable (
										  Id,
										  Name,
										  TypeId
									    )
			SELECT 
				    PC.AlarmCode AS Id,
				    PC.Description AS Name,
				    @FilterId
				FROM TCD.AlarmMaster PC
					   
		   END		


    		 SELECT
				    DISTINCT
						Id,
						Name,
						TypeId
						 FROM @ResultTable


END
GO

UPDATE TCD.Field
SET
    TCD.Field.Max = 16,
    TCD.Field.DefaultValue = 12
WHERE TCD.Field.Id = 61
GO
UPDATE TCD.Field
SET
    TCD.Field.Max = 12,
    TCD.Field.DefaultValue = 10
WHERE TCD.Field.Id = 71
GO
UPDATE TCD.Field
SET
    TCD.Field.Max = 16,
    TCD.Field.DefaultValue = 10
WHERE TCD.Field.Id = 122
GO
UPDATE TCD.Field
SET
    TCD.Field.Max = 12,
    TCD.Field.DefaultValue = 10
WHERE TCD.Field.Id = 184
GO
UPDATE TCD.Field
SET
    TCD.Field.Max = 16,
    TCD.Field.DefaultValue = 16
WHERE TCD.Field.Id = 200
GO
UPDATE TCD.FieldGroupFieldMapping
SET
    FieldId = 200
WHERE Id = 122
GO
UPDATE TCD.FieldGroupFieldMapping
SET
    FieldId = 61
WHERE Id = 287
GO
UPDATE TCD.ResourceKeyValue
SET
    [Value] = N'Electricity Tariff'
WHERE KeyName = N'FIELD_ELECTRICITYTARIFF' AND languageID = 1
GO
UPDATE TCD.ResourceKeyValue
SET
    [Value] = N'$/CwT'
WHERE KeyName = N'dollar_per_centrum_weight' AND languageID = 1
GO
UPDATE TCD.ChainTextileCategory
SET
    PlantChainId = NULL
WHERE TextileId = 0
GO
UPDATE TCD.PlantChainProgram
SET
    PlantChainId = NULL
WHERE PlantProgramId = 0
GO



 

