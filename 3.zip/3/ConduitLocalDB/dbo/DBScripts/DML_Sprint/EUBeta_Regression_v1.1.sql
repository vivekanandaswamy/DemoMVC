/*
Upgrade script from NAGOLive 1 to NAGoLive 
*/

--- START- SCRIPT TO DROP OF ALL FOREIGN KEY CONSTRAINTS
DECLARE @ForeignKeyName VARCHAR(4000)
DECLARE @ParentTableName VARCHAR(4000)
DECLARE @ParentTableSchema VARCHAR(4000)

DECLARE @TSQLDropFK VARCHAR(MAX)
DECLARE @SCHEMAID INT;

---Custom code which will make sures for TCD schema only.
SELECT  @SCHEMAID=schema_id  FROM SYS.schemas WHERE name='TCD';

DECLARE CursorFK CURSOR FOR 
SELECT fk.name ForeignKeyName, schema_name(t.schema_id) ParentTableSchema, t.name ParentTableName
FROM sys.foreign_keys fk  
INNER JOIN sys.tables t 
    ON fk.parent_object_id=t.object_id 
    AND fk.schema_id=@SCHEMAID

OPEN CursorFK

FETCH NEXT FROM CursorFK 
    INTO  @ForeignKeyName, @ParentTableSchema, @ParentTableName
WHILE (@@FETCH_STATUS=0)
BEGIN
    
    SET @TSQLDropFK ='ALTER TABLE '+quotename(@ParentTableSchema)+'.'+quotename(@ParentTableName)+' DROP CONSTRAINT '+quotename(@ForeignKeyName) -- + CHAR(13) + CHAR(10) + 'GO'+ CHAR(13) + CHAR(10)
 
    EXEC(@TSQLDropFK)
    IF @@ERROR <> 0 
    PRINT 'Error: failed to drop foreign key constraint ' + @ForeignKeyName

FETCH NEXT FROM CursorFK 
    INTO  @ForeignKeyName, @ParentTableSchema, @ParentTableName
END
CLOSE CursorFK
DEALLOCATE CursorFK
GO
--- END- SCRIPT TO DROP OF ALL FOREIGN KEY CONSTRAINTS


-- START - Script to Drop all Indexes


DECLARE @SchemaName VARCHAR(256)DECLARE @TableName VARCHAR(256)
DECLARE @IndexName VARCHAR(256)
DECLARE @TSQLDropIndex VARCHAR(MAX)

DECLARE CursorIndexes CURSOR FOR
 SELECT schema_name(t.schema_id), t.name,  i.name 
 FROM sys.indexes i
 INNER JOIN sys.tables t ON t.object_id= i.object_id
 WHERE i.type>0 and t.is_ms_shipped=0 and t.name<>'sysdiagrams'
 and (is_primary_key=0 and is_unique_constraint=0)
 and schema_name(t.schema_id) = 'TCD'

OPEN CursorIndexes
FETCH NEXT FROM CursorIndexes INTO @SchemaName,@TableName,@IndexName

WHILE @@fetch_status = 0
BEGIN
 SET @TSQLDropIndex = 'DROP INDEX '+QUOTENAME(@SchemaName)+ '.' + QUOTENAME(@TableName) + '.' +QUOTENAME(@IndexName)
 EXEC(@TSQLDropIndex)
 
 IF @@ERROR <> 0 
    PRINT 'Error: failed to drop index ' + @TSQLDropIndex

 FETCH NEXT FROM CursorIndexes INTO @SchemaName,@TableName,@IndexName
END

CLOSE CursorIndexes
DEALLOCATE CursorIndexes 
GO

-- END - Script to Drop all Indexes

--- START - SCRIPT TO DROP SCRIPT OF ALL PK AND UNIQUE CONSTRAINTS.
DECLARE @SchemaName VARCHAR(256)
DECLARE @TableName VARCHAR(256)
DECLARE @IndexName VARCHAR(256)
DECLARE @TSQLDropIndex VARCHAR(MAX)
DECLARE @SCHEMAID INT;


---Custom code which will make sures for TCD schema only.
SELECT  @SCHEMAID=schema_id  FROM SYS.schemas WHERE name='TCD';

DECLARE CursorIndexes CURSOR FOR
SELECT  schema_name(t.schema_id), t.name,  i.name 
FROM sys.indexes i
INNER JOIN sys.tables t ON t.object_id= i.object_id
WHERE i.type>0 and t.is_ms_shipped=0 and t.name<>'sysdiagrams'
and (is_primary_key=1 or is_unique_constraint=1) 
AND schema_id=@SCHEMAID

OPEN CursorIndexes
FETCH NEXT FROM CursorIndexes INTO @SchemaName,@TableName,@IndexName
WHILE @@fetch_status = 0
BEGIN
  SET @TSQLDropIndex = 'ALTER TABLE '+QUOTENAME(@SchemaName)+ '.' + QUOTENAME(@TableName) + ' DROP CONSTRAINT ' +QUOTENAME(@IndexName)
  --PRINT @TSQLDropIndex
  EXEC(@TSQLDropIndex)

  IF @@ERROR <> 0 
    PRINT 'Error: failed to pk/uq drop constraint :' + @TSQLDropIndex

  FETCH NEXT FROM CursorIndexes INTO @SchemaName,@TableName,@IndexName
END

CLOSE CursorIndexes
DEALLOCATE CursorIndexes
GO
--- END - SCRIPT TO DROP SCRIPT OF ALL PK AND UNIQUE CONSTRAINTS.

--- START - ALTER EcolabAccountNumber to 25 characters
ALTER TABLE TCD.TunnelProgramReading ALTER COLUMN EcoalabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.TunnelProgramSetup ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.RedFlagHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.TunnelProgramSetupHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.Injection ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.RedFlagMappingData ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.LaborCost ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.LaborCostHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.RedFlagMappingDataHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ControllerParameters ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ControllerProductMapping ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.MachineGroup ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ControllerSetupData ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ControllerSetupDataHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.MachineGroupHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ControllerTagMapping ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.UserAudit ALTER COLUMN EcoLabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ReportDailyData ALTER COLUMN EcoalabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ControllerTags ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.UserInRole ALTER COLUMN EcoLabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.UserInRoleHistory ALTER COLUMN EcoLabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.MachineSetup ALTER COLUMN EcoalabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ConveyorCustomerDetails ALTER COLUMN EcoalabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.UserMaster ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.MachineSetupHistory ALTER COLUMN EcoalabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ConveyorDetails ALTER COLUMN EcoalabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ReportHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ManualLabor ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.UserMasterHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ManualLaborHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.UserProfile ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.AlarmData ALTER COLUMN EcoalabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ManualProduction ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ManualProductionHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ManualRewash ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.Washer ALTER COLUMN EcoLabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ManualRewashHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.WasherDosingAnalogControllerMapping ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ManualUtility ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.WasherDosingProductMapping ALTER COLUMN EcoLabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ManualUtilityHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.AlarmStatus ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.WasherDosingProductMappingHistory ALTER COLUMN EcoLabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.Meter ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.AlarmStatusHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.WasherDosingSetup ALTER COLUMN EcoLabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.MeterHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.WasherDosingSetupHistory ALTER COLUMN EcoLabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.MixingVessels ALTER COLUMN EcoLabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ModuleTags ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.Dashboard ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.WasherGroup ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.RewashData ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.Monitor ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.DashboardHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.WasherGroupHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.RewashProductData ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.MonitorSetUpMapping ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.Sensor ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.MonitorSetUpMappingHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.BatchHistory ALTER COLUMN EcoalabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.WasherHistory ALTER COLUMN EcoLabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.SensorHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.DashboardUserPortletMapping ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.OpenActionItems ALTER COLUMN EcoLabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.Shift ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ShiftBreakData ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ShiftBreakDataHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ShiftData ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.Plant ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ShiftDataHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ChemicalInventory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.WasherProgramSetup ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ShiftHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.WasherProgramSetupHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ShiftLaborData ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ShiftLaborDataHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.PlantContact ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.PlantContactHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.WasherTags ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ConduitController ALTER COLUMN EcoalabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.SolumixReading ALTER COLUMN EcoalabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.PlantCustAddress ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ConduitControllerHistory ALTER COLUMN EcoalabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.Dryers ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.PlantCustomer ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.DryersHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.TankReading ALTER COLUMN EcoalabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.PlantCustomerHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.TankSetup ALTER COLUMN EcoalabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.WaterAndEnergy ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.TankSetupHistory ALTER COLUMN EcoalabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.PlantHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.TARGETPRODUCTIONDETAILS ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.TcpMessageQueue ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.WaterAndEnergyHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.PlantUtilityFactor ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.EnergyUtilityDetails ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.WaterUtilityDetails ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ControllerEquipmentSetup ALTER COLUMN EcoLabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.TunnelCompartment ALTER COLUMN EcoLabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ControllerEquipmentSetupHistory ALTER COLUMN EcoLabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.PortletMaster ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.TunnelCompartmentEquipmentMapping ALTER COLUMN EcoLabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.TunnelCompartmentEquipmentMappingHistory ALTER COLUMN EcoLabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ProductdataMapping ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ProductDataMappingHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.TunnelCompartmentHistory ALTER COLUMN EcoLabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.TunnelConductivitySetup ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ProductionShiftData ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.Finnishers ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.TunnelConductivitySetupHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.FinnishersHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.TunnelDosingProductMapping ALTER COLUMN EcoLabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.TunnelDosingProductMappingHistory ALTER COLUMN EcoLabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.TunnelDosingSetup ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ProductStandardPrice ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.TunnelDosingSetupHistory ALTER COLUMN EcoLabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ProgramMaster ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.TunnelpHSetup ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.ProgramMasterHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.TunnelpHSetupHistory ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.RedFlag ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
ALTER TABLE TCD.RedFlag ALTER COLUMN EcolabAccountNumber NVARCHAR(25)
GO
--- END - ALTER EcolabAccountNumber to 25 characters

--- START - Primary Key and Unique Key Creation
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'UniqueKey_AlarmGroupMaster' AND parent_object_id = OBJECT_ID(N'[TCD].[AlarmGroupMaster]'))
BEGIN
ALTER TABLE [TCD].[AlarmGroupMaster]
 ADD CONSTRAINT [UniqueKey_AlarmGroupMaster] UNIQUE NONCLUSTERED(AlarmGroupMasterId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'UniqueKey_AlarmGroupMsterVsControllerModelType' AND parent_object_id = OBJECT_ID(N'[TCD].[AlarmGroupMsterVsControllerModelType]'))
BEGIN
ALTER TABLE [TCD].[AlarmGroupMsterVsControllerModelType]
 ADD CONSTRAINT [UniqueKey_AlarmGroupMsterVsControllerModelType] UNIQUE NONCLUSTERED(AlarmGroupMsterVsControllerModelTypeId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_AlarmMachineMapping_ID' AND parent_object_id = OBJECT_ID(N'[TCD].[AlarmMachineMapping]'))
BEGIN
ALTER TABLE [TCD].[AlarmMachineMapping]
 ADD CONSTRAINT [PK_AlarmMachineMapping_ID] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_AlarmMaster' AND parent_object_id = OBJECT_ID(N'[TCD].[AlarmMaster]'))
BEGIN
ALTER TABLE [TCD].[AlarmMaster]
 ADD CONSTRAINT [PK_AlarmMaster] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK__AlarmSta__3214EC076A462AE0' AND parent_object_id = OBJECT_ID(N'[TCD].[AlarmStatus]'))
BEGIN
ALTER TABLE [TCD].[AlarmStatus]
 ADD CONSTRAINT [PK__AlarmSta__3214EC076A462AE0] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK__AlarmSta__DE2260ED71A1ED33' AND parent_object_id = OBJECT_ID(N'[TCD].[AlarmStatusHistory]'))
BEGIN
ALTER TABLE [TCD].[AlarmStatusHistory]
 ADD CONSTRAINT [PK__AlarmSta__DE2260ED71A1ED33] PRIMARY KEY CLUSTERED(AlarmStatusHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_AuditOperation' AND parent_object_id = OBJECT_ID(N'[TCD].[AuditOperation]'))
BEGIN
ALTER TABLE [TCD].[AuditOperation]
 ADD CONSTRAINT [PK_AuditOperation] PRIMARY KEY CLUSTERED(OperationId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'UQ_AuditOperation' AND parent_object_id = OBJECT_ID(N'[TCD].[AuditOperation]'))
BEGIN
ALTER TABLE [TCD].[AuditOperation]
 ADD CONSTRAINT [UQ_AuditOperation] UNIQUE NONCLUSTERED(OperationCode ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_BatchData' AND parent_object_id = OBJECT_ID(N'[TCD].[BatchData]'))
BEGIN
ALTER TABLE [TCD].[BatchData]
 ADD CONSTRAINT [PK_BatchData] PRIMARY KEY CLUSTERED(BatchId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_BatchDataHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[BatchDataHistory]'))
BEGIN
ALTER TABLE [TCD].[BatchDataHistory]
 ADD CONSTRAINT [PK_BatchDataHistory] PRIMARY KEY CLUSTERED(BatchHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'Pk_BatchEjectConditionId_BatchEjectCondition' AND parent_object_id = OBJECT_ID(N'[TCD].[BatchEjectCondition]'))
BEGIN
ALTER TABLE [TCD].[BatchEjectCondition]
 ADD CONSTRAINT [Pk_BatchEjectConditionId_BatchEjectCondition] PRIMARY KEY CLUSTERED(BatchEjectConditionId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_BatchHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[BatchHistory]'))
BEGIN
ALTER TABLE [TCD].[BatchHistory]
 ADD CONSTRAINT [PK_BatchHistory] PRIMARY KEY CLUSTERED(BatchHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_BatchParameterTypes' AND parent_object_id = OBJECT_ID(N'[TCD].[BatchParameterTypes]'))
BEGIN
ALTER TABLE [TCD].[BatchParameterTypes]
 ADD CONSTRAINT [PK_BatchParameterTypes] PRIMARY KEY CLUSTERED(BatchParameterTypeId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK__BatchSta__7FF0F5F61E4E95C1' AND parent_object_id = OBJECT_ID(N'[TCD].[BatchStatus]'))
BEGIN
ALTER TABLE [TCD].[BatchStatus]
 ADD CONSTRAINT [PK__BatchSta__7FF0F5F61E4E95C1] PRIMARY KEY CLUSTERED(BatchStatusId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_PlantTextileCategory' AND parent_object_id = OBJECT_ID(N'[TCD].[ChainTextileCategory]'))
BEGIN
ALTER TABLE [TCD].[ChainTextileCategory]
 ADD CONSTRAINT [PK_PlantTextileCategory] PRIMARY KEY CLUSTERED(TextileId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ChemicalInventory' AND parent_object_id = OBJECT_ID(N'[TCD].[ChemicalInventory]'))
BEGIN
ALTER TABLE [TCD].[ChemicalInventory]
 ADD CONSTRAINT [PK_ChemicalInventory] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ChemicalInventoryRollUp_ProductID' AND parent_object_id = OBJECT_ID(N'[TCD].[ChemicalInventoryRollUp]'))
BEGIN
ALTER TABLE [TCD].[ChemicalInventoryRollUp]
 ADD CONSTRAINT [PK_ChemicalInventoryRollUp_ProductID] PRIMARY KEY CLUSTERED(ProductID ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_Conduitchart' AND parent_object_id = OBJECT_ID(N'[TCD].[ConduitChartMaster]'))
BEGIN
ALTER TABLE [TCD].[ConduitChartMaster]
 ADD CONSTRAINT [PK_Conduitchart] PRIMARY KEY CLUSTERED(ChartTypeId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_Controller_1' AND parent_object_id = OBJECT_ID(N'[TCD].[ConduitController]'))
BEGIN
ALTER TABLE [TCD].[ConduitController]
 ADD CONSTRAINT [PK_Controller_1] PRIMARY KEY CLUSTERED(ControllerId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'UQ_ConduitController_EcoLabAccountNumberControllerId' AND parent_object_id = OBJECT_ID(N'[TCD].[ConduitController]'))
BEGIN
ALTER TABLE [TCD].[ConduitController]
 ADD CONSTRAINT [UQ_ConduitController_EcoLabAccountNumberControllerId] UNIQUE NONCLUSTERED(EcoalabAccountNumber ASC, ControllerId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ConduitControllerHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[ConduitControllerHistory]'))
BEGIN
ALTER TABLE [TCD].[ConduitControllerHistory]
 ADD CONSTRAINT [PK_ConduitControllerHistory] PRIMARY KEY CLUSTERED(ConduitControllerHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_conduitDashboard' AND parent_object_id = OBJECT_ID(N'[TCD].[ConduitDashboard]'))
BEGIN
ALTER TABLE [TCD].[ConduitDashboard]
 ADD CONSTRAINT [PK_conduitDashboard] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_UISectionMaster' AND parent_object_id = OBJECT_ID(N'[TCD].[ConduitMenu]'))
BEGIN
ALTER TABLE [TCD].[ConduitMenu]
 ADD CONSTRAINT [PK_UISectionMaster] PRIMARY KEY CLUSTERED(SectionID ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'UQ__ConduitM__08F874B9112CC65B' AND parent_object_id = OBJECT_ID(N'[TCD].[ConduitMenu]'))
BEGIN
ALTER TABLE [TCD].[ConduitMenu]
 ADD CONSTRAINT [UQ__ConduitM__08F874B9112CC65B] UNIQUE NONCLUSTERED(SectionCode ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_UISectionSettingsMapping' AND parent_object_id = OBJECT_ID(N'[TCD].[ConduitMenuRoleMapping]'))
BEGIN
ALTER TABLE [TCD].[ConduitMenuRoleMapping]
 ADD CONSTRAINT [PK_UISectionSettingsMapping] PRIMARY KEY CLUSTERED(MappingID ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ConduitParameters' AND parent_object_id = OBJECT_ID(N'[TCD].[ConduitParameters]'))
BEGIN
ALTER TABLE [TCD].[ConduitParameters]
 ADD CONSTRAINT [PK_ConduitParameters] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_UISectionType' AND parent_object_id = OBJECT_ID(N'[TCD].[ConduitSectionType]'))
BEGIN
ALTER TABLE [TCD].[ConduitSectionType]
 ADD CONSTRAINT [PK_UISectionType] PRIMARY KEY CLUSTERED(SectionType ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_TabType' AND parent_object_id = OBJECT_ID(N'[TCD].[ConduitTabType]'))
BEGIN
ALTER TABLE [TCD].[ConduitTabType]
 ADD CONSTRAINT [PK_TabType] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ControllerEquipmentSetup' AND parent_object_id = OBJECT_ID(N'[TCD].[ControllerEquipmentSetup]'))
BEGIN
ALTER TABLE [TCD].[ControllerEquipmentSetup]
 ADD CONSTRAINT [PK_ControllerEquipmentSetup] PRIMARY KEY CLUSTERED(ControllerEquipmentSetupId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'UQ_ControllerEquipmentSetup_EcoLabAccountNumberControllerIdControllerEquipmentId' AND parent_object_id = OBJECT_ID(N'[TCD].[ControllerEquipmentSetup]'))
BEGIN
ALTER TABLE [TCD].[ControllerEquipmentSetup]
 ADD CONSTRAINT [UQ_ControllerEquipmentSetup_EcoLabAccountNumberControllerIdControllerEquipmentId] UNIQUE NONCLUSTERED(EcoLabAccountNumber ASC, ControllerId ASC, ControllerEquipmentId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ControllerEquipmentSetupHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[ControllerEquipmentSetupHistory]'))
BEGIN
ALTER TABLE [TCD].[ControllerEquipmentSetupHistory]
 ADD CONSTRAINT [PK_ControllerEquipmentSetupHistory] PRIMARY KEY CLUSTERED(ControllerEquipmentSetupHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ControllerEquipmentType' AND parent_object_id = OBJECT_ID(N'[TCD].[ControllerEquipmentType]'))
BEGIN
ALTER TABLE [TCD].[ControllerEquipmentType]
 ADD CONSTRAINT [PK_ControllerEquipmentType] PRIMARY KEY CLUSTERED(ControllerEquipmentTypeId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ControllerEquipmentTypeModel_ControllerEquipmentTypeModelID' AND parent_object_id = OBJECT_ID(N'[TCD].[ControllerEquipmentTypeModel]'))
BEGIN
ALTER TABLE [TCD].[ControllerEquipmentTypeModel]
 ADD CONSTRAINT [PK_ControllerEquipmentTypeModel_ControllerEquipmentTypeModelID] PRIMARY KEY CLUSTERED(ControllerEquipmentTypeModelID ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ControllerEquipmentValves_ControllerEquipmentValveID' AND parent_object_id = OBJECT_ID(N'[TCD].[ControllerEquipmentValves]'))
BEGIN
ALTER TABLE [TCD].[ControllerEquipmentValves]
 ADD CONSTRAINT [PK_ControllerEquipmentValves_ControllerEquipmentValveID] PRIMARY KEY CLUSTERED(ControllerEquipmentValveID ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK__Controll__D7E7E30197E476A9' AND parent_object_id = OBJECT_ID(N'[TCD].[ControllerGroups]'))
BEGIN
ALTER TABLE [TCD].[ControllerGroups]
 ADD CONSTRAINT [PK__Controll__D7E7E30197E476A9] PRIMARY KEY CLUSTERED(ControllerGroupID ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ControllerModel' AND parent_object_id = OBJECT_ID(N'[TCD].[ControllerModel]'))
BEGIN
ALTER TABLE [TCD].[ControllerModel]
 ADD CONSTRAINT [PK_ControllerModel] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ControllerModelControllerTypeMapping' AND parent_object_id = OBJECT_ID(N'[TCD].[ControllerModelControllerTypeMapping]'))
BEGIN
ALTER TABLE [TCD].[ControllerModelControllerTypeMapping]
 ADD CONSTRAINT [PK_ControllerModelControllerTypeMapping] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK__Controll__6205F9DF364A205C' AND parent_object_id = OBJECT_ID(N'[TCD].[ControllerParameterNode]'))
BEGIN
ALTER TABLE [TCD].[ControllerParameterNode]
 ADD CONSTRAINT [PK__Controll__6205F9DF364A205C] PRIMARY KEY CLUSTERED(ControllerParameterNodeID ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ControllerProductMapping' AND parent_object_id = OBJECT_ID(N'[TCD].[ControllerProductMapping]'))
BEGIN
ALTER TABLE [TCD].[ControllerProductMapping]
 ADD CONSTRAINT [PK_ControllerProductMapping] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ControllerSetupDataHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[ControllerSetupDataHistory]'))
BEGIN
ALTER TABLE [TCD].[ControllerSetupDataHistory]
 ADD CONSTRAINT [PK_ControllerSetupDataHistory] PRIMARY KEY CLUSTERED(ControllerSetupDataHistory ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ControllerTagNode' AND parent_object_id = OBJECT_ID(N'[TCD].[ControllerTagNode]'))
BEGIN
ALTER TABLE [TCD].[ControllerTagNode]
 ADD CONSTRAINT [PK_ControllerTagNode] PRIMARY KEY CLUSTERED(ControllerTagNodeId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ControllerType' AND parent_object_id = OBJECT_ID(N'[TCD].[ControllerType]'))
BEGIN
ALTER TABLE [TCD].[ControllerType]
 ADD CONSTRAINT [PK_ControllerType] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK__CurrencySymbol_CurrencyCode' AND parent_object_id = OBJECT_ID(N'[TCD].[CurrencySymbol]'))
BEGIN
ALTER TABLE [TCD].[CurrencySymbol]
 ADD CONSTRAINT [PK__CurrencySymbol_CurrencyCode] PRIMARY KEY CLUSTERED(CurrencyCode ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_DashBoard' AND parent_object_id = OBJECT_ID(N'[TCD].[Dashboard]'))
BEGIN
ALTER TABLE [TCD].[Dashboard]
 ADD CONSTRAINT [PK_DashBoard] PRIMARY KEY CLUSTERED(DashboardId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_DashBoardHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[DashboardHistory]'))
BEGIN
ALTER TABLE [TCD].[DashboardHistory]
 ADD CONSTRAINT [PK_DashBoardHistory] PRIMARY KEY CLUSTERED(DashboardHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_DashboardType' AND parent_object_id = OBJECT_ID(N'[TCD].[DashboardType]'))
BEGIN
ALTER TABLE [TCD].[DashboardType]
 ADD CONSTRAINT [PK_DashboardType] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_DataSource' AND parent_object_id = OBJECT_ID(N'[TCD].[DataSource]'))
BEGIN
ALTER TABLE [TCD].[DataSource]
 ADD CONSTRAINT [PK_DataSource] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_DataType' AND parent_object_id = OBJECT_ID(N'[TCD].[DataType]'))
BEGIN
ALTER TABLE [TCD].[DataType]
 ADD CONSTRAINT [PK_DataType] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_DeviceTypeId' AND parent_object_id = OBJECT_ID(N'[TCD].[DeviceType]'))
BEGIN
ALTER TABLE [TCD].[DeviceType]
 ADD CONSTRAINT [PK_DeviceTypeId] PRIMARY KEY CLUSTERED(DeviceTypeId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_DimensionalDisplayUnits' AND parent_object_id = OBJECT_ID(N'[TCD].[DimensionalDisplayUnits]'))
BEGIN
ALTER TABLE [TCD].[DimensionalDisplayUnits]
 ADD CONSTRAINT [PK_DimensionalDisplayUnits] PRIMARY KEY CLUSTERED(DisplayUnitID ASC, Unit ASC, Subunit ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_DimensionalSubunits' AND parent_object_id = OBJECT_ID(N'[TCD].[DimensionalSubunits]'))
BEGIN
ALTER TABLE [TCD].[DimensionalSubunits]
 ADD CONSTRAINT [PK_DimensionalSubunits] PRIMARY KEY CLUSTERED(Unit ASC, Subunit ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_DimensionalUnits_1' AND parent_object_id = OBJECT_ID(N'[TCD].[DimensionalUnits]'))
BEGIN
ALTER TABLE [TCD].[DimensionalUnits]
 ADD CONSTRAINT [PK_DimensionalUnits_1] PRIMARY KEY CLUSTERED(Unit ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_DimensionalUnitsDefaults' AND parent_object_id = OBJECT_ID(N'[TCD].[DimensionalUnitsDefaults]'))
BEGIN
ALTER TABLE [TCD].[DimensionalUnitsDefaults]
 ADD CONSTRAINT [PK_DimensionalUnitsDefaults] PRIMARY KEY CLUSTERED(UnitSystemId ASC, UsageKey ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_DimensionalUnitSystems' AND parent_object_id = OBJECT_ID(N'[TCD].[DimensionalUnitSystems]'))
BEGIN
ALTER TABLE [TCD].[DimensionalUnitSystems]
 ADD CONSTRAINT [PK_DimensionalUnitSystems] PRIMARY KEY CLUSTERED(UnitSystemId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_DimensionalUsageKey' AND parent_object_id = OBJECT_ID(N'[TCD].[DimensionalUsageKey]'))
BEGIN
ALTER TABLE [TCD].[DimensionalUsageKey]
 ADD CONSTRAINT [PK_DimensionalUsageKey] PRIMARY KEY CLUSTERED(UsageKey ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_DrainDestination' AND parent_object_id = OBJECT_ID(N'[TCD].[DrainDestination]'))
BEGIN
ALTER TABLE [TCD].[DrainDestination]
 ADD CONSTRAINT [PK_DrainDestination] PRIMARY KEY CLUSTERED(DrainDestinationId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_DryersHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[DryersHistory]'))
BEGIN
ALTER TABLE [TCD].[DryersHistory]
 ADD CONSTRAINT [PK_DryersHistory] PRIMARY KEY CLUSTERED(DryersHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_DryerType' AND parent_object_id = OBJECT_ID(N'[TCD].[DryerType]'))
BEGIN
ALTER TABLE [TCD].[DryerType]
 ADD CONSTRAINT [PK_DryerType] PRIMARY KEY CLUSTERED(DryerTypeId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_EcolabSaturation' AND parent_object_id = OBJECT_ID(N'[TCD].[EcolabSaturation]'))
BEGIN
ALTER TABLE [TCD].[EcolabSaturation]
 ADD CONSTRAINT [PK_EcolabSaturation] PRIMARY KEY CLUSTERED(EcolabSaturationId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_TextileCategory' AND parent_object_id = OBJECT_ID(N'[TCD].[EcolabTextileCategory]'))
BEGIN
ALTER TABLE [TCD].[EcolabTextileCategory]
 ADD CONSTRAINT [PK_TextileCategory] PRIMARY KEY CLUSTERED(TextileId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_Field' AND parent_object_id = OBJECT_ID(N'[TCD].[Field]'))
BEGIN
ALTER TABLE [TCD].[Field]
 ADD CONSTRAINT [PK_Field] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_FieldGroup' AND parent_object_id = OBJECT_ID(N'[TCD].[FieldGroup]'))
BEGIN
ALTER TABLE [TCD].[FieldGroup]
 ADD CONSTRAINT [PK_FieldGroup] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_FieldGroupFieldMapping' AND parent_object_id = OBJECT_ID(N'[TCD].[FieldGroupFieldMapping]'))
BEGIN
ALTER TABLE [TCD].[FieldGroupFieldMapping]
 ADD CONSTRAINT [PK_FieldGroupFieldMapping] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_FieldGroupType' AND parent_object_id = OBJECT_ID(N'[TCD].[FieldGroupType]'))
BEGIN
ALTER TABLE [TCD].[FieldGroupType]
 ADD CONSTRAINT [PK_FieldGroupType] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK__FieldRol__3214EC07B6FD1F0E' AND parent_object_id = OBJECT_ID(N'[TCD].[FieldRoleMapping]'))
BEGIN
ALTER TABLE [TCD].[FieldRoleMapping]
 ADD CONSTRAINT [PK__FieldRol__3214EC07B6FD1F0E] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_FieldType' AND parent_object_id = OBJECT_ID(N'[TCD].[FieldType]'))
BEGIN
ALTER TABLE [TCD].[FieldType]
 ADD CONSTRAINT [PK_FieldType] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_FormulaSegments_FormulaSegmentID' AND parent_object_id = OBJECT_ID(N'[TCD].[FormulaSegments]'))
BEGIN
ALTER TABLE [TCD].[FormulaSegments]
 ADD CONSTRAINT [PK_FormulaSegments_FormulaSegmentID] PRIMARY KEY CLUSTERED(FormulaSegmentID ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_Injection' AND parent_object_id = OBJECT_ID(N'[TCD].[Injection]'))
BEGIN
ALTER TABLE [TCD].[Injection]
 ADD CONSTRAINT [PK_Injection] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_LaborType' AND parent_object_id = OBJECT_ID(N'[TCD].[LaborType]'))
BEGIN
ALTER TABLE [TCD].[LaborType]
 ADD CONSTRAINT [PK_LaborType] PRIMARY KEY CLUSTERED(LaborTypeId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_LanguageMaster' AND parent_object_id = OBJECT_ID(N'[TCD].[LanguageMaster]'))
BEGIN
ALTER TABLE [TCD].[LanguageMaster]
 ADD CONSTRAINT [PK_LanguageMaster] PRIMARY KEY CLUSTERED(LanguageId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_Log' AND parent_object_id = OBJECT_ID(N'[TCD].[Logs]'))
BEGIN
ALTER TABLE [TCD].[Logs]
 ADD CONSTRAINT [PK_Log] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_MachineGroup' AND parent_object_id = OBJECT_ID(N'[TCD].[MachineGroup]'))
BEGIN
ALTER TABLE [TCD].[MachineGroup]
 ADD CONSTRAINT [PK_MachineGroup] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_MachineGroupHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[MachineGroupHistory]'))
BEGIN
ALTER TABLE [TCD].[MachineGroupHistory]
 ADD CONSTRAINT [PK_MachineGroupHistory] PRIMARY KEY CLUSTERED(MachineGroupHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_MachineGroupType' AND parent_object_id = OBJECT_ID(N'[TCD].[MachineGroupType]'))
BEGIN
ALTER TABLE [TCD].[MachineGroupType]
 ADD CONSTRAINT [PK_MachineGroupType] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_MachineSetup' AND parent_object_id = OBJECT_ID(N'[TCD].[MachineSetup]'))
BEGIN
ALTER TABLE [TCD].[MachineSetup]
 ADD CONSTRAINT [PK_MachineSetup] PRIMARY KEY CLUSTERED(WasherId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_MachineSetupHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[MachineSetupHistory]'))
BEGIN
ALTER TABLE [TCD].[MachineSetupHistory]
 ADD CONSTRAINT [PK_MachineSetupHistory] PRIMARY KEY CLUSTERED(MachineSetupHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ManualLabor' AND parent_object_id = OBJECT_ID(N'[TCD].[ManualLabor]'))
BEGIN
ALTER TABLE [TCD].[ManualLabor]
 ADD CONSTRAINT [PK_ManualLabor] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ManualLaborHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[ManualLaborHistory]'))
BEGIN
ALTER TABLE [TCD].[ManualLaborHistory]
 ADD CONSTRAINT [PK_ManualLaborHistory] PRIMARY KEY CLUSTERED(ManualLaborHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ProductionId' AND parent_object_id = OBJECT_ID(N'[TCD].[ManualProduction]'))
BEGIN
ALTER TABLE [TCD].[ManualProduction]
 ADD CONSTRAINT [PK_ProductionId] PRIMARY KEY CLUSTERED(ProductionId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ManualProductionHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[ManualProductionHistory]'))
BEGIN
ALTER TABLE [TCD].[ManualProductionHistory]
 ADD CONSTRAINT [PK_ManualProductionHistory] PRIMARY KEY CLUSTERED(ProductionHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_RewashId' AND parent_object_id = OBJECT_ID(N'[TCD].[ManualRewash]'))
BEGIN
ALTER TABLE [TCD].[ManualRewash]
 ADD CONSTRAINT [PK_RewashId] PRIMARY KEY CLUSTERED(RewashId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_RewashIdHistoryId' AND parent_object_id = OBJECT_ID(N'[TCD].[ManualRewashHistory]'))
BEGIN
ALTER TABLE [TCD].[ManualRewashHistory]
 ADD CONSTRAINT [PK_RewashIdHistoryId] PRIMARY KEY CLUSTERED(RewashIdHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ManualUtility' AND parent_object_id = OBJECT_ID(N'[TCD].[ManualUtility]'))
BEGIN
ALTER TABLE [TCD].[ManualUtility]
 ADD CONSTRAINT [PK_ManualUtility] PRIMARY KEY CLUSTERED(UtilityId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_UtilityHistoryId' AND parent_object_id = OBJECT_ID(N'[TCD].[ManualUtilityHistory]'))
BEGIN
ALTER TABLE [TCD].[ManualUtilityHistory]
 ADD CONSTRAINT [PK_UtilityHistoryId] PRIMARY KEY CLUSTERED(UtilityHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_Meter' AND parent_object_id = OBJECT_ID(N'[TCD].[Meter]'))
BEGIN
ALTER TABLE [TCD].[Meter]
 ADD CONSTRAINT [PK_Meter] PRIMARY KEY CLUSTERED(MeterId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_MeterHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[MeterHistory]'))
BEGIN
ALTER TABLE [TCD].[MeterHistory]
 ADD CONSTRAINT [PK_MeterHistory] PRIMARY KEY CLUSTERED(MeterHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_MixingVesselsId' AND parent_object_id = OBJECT_ID(N'[TCD].[MixingVessels]'))
BEGIN
ALTER TABLE [TCD].[MixingVessels]
 ADD CONSTRAINT [PK_MixingVesselsId] PRIMARY KEY CLUSTERED(MixingVesselsId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ModuleTags' AND parent_object_id = OBJECT_ID(N'[TCD].[ModuleTags]'))
BEGIN
ALTER TABLE [TCD].[ModuleTags]
 ADD CONSTRAINT [PK_ModuleTags] PRIMARY KEY CLUSTERED(ModuleTagId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ModuleType' AND parent_object_id = OBJECT_ID(N'[TCD].[ModuleType]'))
BEGIN
ALTER TABLE [TCD].[ModuleType]
 ADD CONSTRAINT [PK_ModuleType] PRIMARY KEY CLUSTERED(ModuleTypeId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_DashboardMapping' AND parent_object_id = OBJECT_ID(N'[TCD].[MonitorSetUpMapping]'))
BEGIN
ALTER TABLE [TCD].[MonitorSetUpMapping]
 ADD CONSTRAINT [PK_DashboardMapping] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_DashboardMappingHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[MonitorSetUpMappingHistory]'))
BEGIN
ALTER TABLE [TCD].[MonitorSetUpMappingHistory]
 ADD CONSTRAINT [PK_DashboardMappingHistory] PRIMARY KEY CLUSTERED(MonitorSetUpMappingHistory ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_MyServiceUOMRefToUnitOfMeasureMapping' AND parent_object_id = OBJECT_ID(N'[TCD].[MyServiceUOMRefToUnitOfMeasureMapping]'))
BEGIN
ALTER TABLE [TCD].[MyServiceUOMRefToUnitOfMeasureMapping]
 ADD CONSTRAINT [PK_MyServiceUOMRefToUnitOfMeasureMapping] PRIMARY KEY CLUSTERED(ConduitUOMId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_OnlineBatchData' AND parent_object_id = OBJECT_ID(N'[TCD].[OnlineBatchData]'))
BEGIN
ALTER TABLE [TCD].[OnlineBatchData]
 ADD CONSTRAINT [PK_OnlineBatchData] PRIMARY KEY CLUSTERED(OnlineBatchID ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_PackageSize' AND parent_object_id = OBJECT_ID(N'[TCD].[PackageSize]'))
BEGIN
ALTER TABLE [TCD].[PackageSize]
 ADD CONSTRAINT [PK_PackageSize] PRIMARY KEY CLUSTERED(PackageSizeId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_Page' AND parent_object_id = OBJECT_ID(N'[TCD].[Page]'))
BEGIN
ALTER TABLE [TCD].[Page]
 ADD CONSTRAINT [PK_Page] PRIMARY KEY CLUSTERED(PageId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ParameterMaster' AND parent_object_id = OBJECT_ID(N'[TCD].[ParameterMaster]'))
BEGIN
ALTER TABLE [TCD].[ParameterMaster]
 ADD CONSTRAINT [PK_ParameterMaster] PRIMARY KEY CLUSTERED(ParameterID ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =90) ON [PRIMARY];
END
GO

ALTER TABLE [TCD].[Plant] ALTER COLUMN EcolabAccountNumber NVARCHAR(25) NOT NULL
GO

IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_Plant' AND parent_object_id = OBJECT_ID(N'[TCD].[Plant]'))
BEGIN
ALTER TABLE [TCD].[Plant]
 ADD CONSTRAINT [PK_Plant] PRIMARY KEY CLUSTERED(EcolabAccountNumber ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_PlantCategory' AND parent_object_id = OBJECT_ID(N'[TCD].[PlantCategory]'))
BEGIN
ALTER TABLE [TCD].[PlantCategory]
 ADD CONSTRAINT [PK_PlantCategory] PRIMARY KEY CLUSTERED(PlantCategoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_PlantChain' AND parent_object_id = OBJECT_ID(N'[TCD].[PlantChain]'))
BEGIN
ALTER TABLE [TCD].[PlantChain]
 ADD CONSTRAINT [PK_PlantChain] PRIMARY KEY CLUSTERED(PlantChainId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_PlantProgram' AND parent_object_id = OBJECT_ID(N'[TCD].[PlantChainProgram]'))
BEGIN
ALTER TABLE [TCD].[PlantChainProgram]
 ADD CONSTRAINT [PK_PlantProgram] PRIMARY KEY CLUSTERED(PlantProgramId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_PlantContactHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[PlantContactHistory]'))
BEGIN
ALTER TABLE [TCD].[PlantContactHistory]
 ADD CONSTRAINT [PK_PlantContactHistory] PRIMARY KEY CLUSTERED(PlantContactHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_PlantContactPosition' AND parent_object_id = OBJECT_ID(N'[TCD].[PlantContactPosition]'))
BEGIN
ALTER TABLE [TCD].[PlantContactPosition]
 ADD CONSTRAINT [PK_PlantContactPosition] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
ALTER TABLE [TCD].[PlantCustAddress] ALTER COLUMN EcolabAccountNumber NVARCHAR(25) NOT NULL
GO

IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_Plant_CustAddr' AND parent_object_id = OBJECT_ID(N'[TCD].[PlantCustAddress]'))
BEGIN
ALTER TABLE [TCD].[PlantCustAddress]
 ADD CONSTRAINT [PK_Plant_CustAddr] PRIMARY KEY CLUSTERED(EcolabAccountNumber ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_PlantCustomer' AND parent_object_id = OBJECT_ID(N'[TCD].[PlantCustomer]'))
BEGIN
ALTER TABLE [TCD].[PlantCustomer]
 ADD CONSTRAINT [PK_PlantCustomer] PRIMARY KEY CLUSTERED(ID ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_PlantCustomerHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[PlantCustomerHistory]'))
BEGIN
ALTER TABLE [TCD].[PlantCustomerHistory]
 ADD CONSTRAINT [PK_PlantCustomerHistory] PRIMARY KEY CLUSTERED(PlantCustomerHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK__PlantExt__98FE395C880609EF' AND parent_object_id = OBJECT_ID(N'[TCD].[PlantExtension]'))
BEGIN
ALTER TABLE [TCD].[PlantExtension]
 ADD CONSTRAINT [PK__PlantExt__98FE395C880609EF] PRIMARY KEY CLUSTERED(PlantId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_PlantHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[PlantHistory]'))
BEGIN
ALTER TABLE [TCD].[PlantHistory]
 ADD CONSTRAINT [PK_PlantHistory] PRIMARY KEY CLUSTERED(PlantHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_PlantUtilityEnergyPropertiesHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[PlantUtilityEnergyPropertiesHistory]'))
BEGIN
ALTER TABLE [TCD].[PlantUtilityEnergyPropertiesHistory]
 ADD CONSTRAINT [PK_PlantUtilityEnergyPropertiesHistory] PRIMARY KEY CLUSTERED(PlantUtilityEnergyPropertiesHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_PlantUtilityFactorHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[PlantUtilityFactorHistory]'))
BEGIN
ALTER TABLE [TCD].[PlantUtilityFactorHistory]
 ADD CONSTRAINT [PK_PlantUtilityFactorHistory] PRIMARY KEY CLUSTERED(PlantUtilityFactorHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ PLCXMLData' AND parent_object_id = OBJECT_ID(N'[TCD].[PLCXMLData]'))
BEGIN
ALTER TABLE [TCD].[PLCXMLData]
 ADD CONSTRAINT [PK_ PLCXMLData] PRIMARY KEY CLUSTERED(PLCXMLDataId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_TCD.PortletMaster' AND parent_object_id = OBJECT_ID(N'[TCD].[PortletMaster]'))
BEGIN
ALTER TABLE [TCD].[PortletMaster]
 ADD CONSTRAINT [PK_TCD.PortletMaster] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ProductCategory' AND parent_object_id = OBJECT_ID(N'[TCD].[ProductCategory]'))
BEGIN
ALTER TABLE [TCD].[ProductCategory]
 ADD CONSTRAINT [PK_ProductCategory] PRIMARY KEY CLUSTERED(CategoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'UQ_ProductDataMapping_EcoLabAccountNumberProductId' AND parent_object_id = OBJECT_ID(N'[TCD].[ProductdataMapping]'))
BEGIN
ALTER TABLE [TCD].[ProductdataMapping]
 ADD CONSTRAINT [UQ_ProductDataMapping_EcoLabAccountNumberProductId] UNIQUE NONCLUSTERED(EcolabAccountNumber ASC, ProductID ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ProductDataMappingHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[ProductDataMappingHistory]'))
BEGIN
ALTER TABLE [TCD].[ProductDataMappingHistory]
 ADD CONSTRAINT [PK_ProductDataMappingHistory] PRIMARY KEY CLUSTERED(ProductDataMappingHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ProductMaster' AND parent_object_id = OBJECT_ID(N'[TCD].[ProductMaster]'))
BEGIN
ALTER TABLE [TCD].[ProductMaster]
 ADD CONSTRAINT [PK_ProductMaster] PRIMARY KEY CLUSTERED(ProductId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK__ProductS__3214EC070658523E' AND parent_object_id = OBJECT_ID(N'[TCD].[ProductStandardPrice]'))
BEGIN
ALTER TABLE [TCD].[ProductStandardPrice]
 ADD CONSTRAINT [PK__ProductS__3214EC070658523E] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ProgramMaster' AND parent_object_id = OBJECT_ID(N'[TCD].[ProgramMaster]'))
BEGIN
ALTER TABLE [TCD].[ProgramMaster]
 ADD CONSTRAINT [PK_ProgramMaster] PRIMARY KEY CLUSTERED(ProgramId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ProgramMasterHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[ProgramMasterHistory]'))
BEGIN
ALTER TABLE [TCD].[ProgramMasterHistory]
 ADD CONSTRAINT [PK_ProgramMasterHistory] PRIMARY KEY CLUSTERED(ProgramMasterHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK__RedFlag__3214EC070954367D' AND parent_object_id = OBJECT_ID(N'[TCD].[RedFlag]'))
BEGIN
ALTER TABLE [TCD].[RedFlag]
 ADD CONSTRAINT [PK__RedFlag__3214EC070954367D] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK__RedFlagC__D1086B7053D5CBEC' AND parent_object_id = OBJECT_ID(N'[TCD].[RedFlagCategory]'))
BEGIN
ALTER TABLE [TCD].[RedFlagCategory]
 ADD CONSTRAINT [PK__RedFlagC__D1086B7053D5CBEC] PRIMARY KEY CLUSTERED(RedFlagCategoryID ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK__RedFlagH__8AA9AFC9AB24FB93' AND parent_object_id = OBJECT_ID(N'[TCD].[RedFlagHistory]'))
BEGIN
ALTER TABLE [TCD].[RedFlagHistory]
 ADD CONSTRAINT [PK__RedFlagH__8AA9AFC9AB24FB93] PRIMARY KEY CLUSTERED(RedFlagHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK__RedFlagI__3214EC0788CC4415' AND parent_object_id = OBJECT_ID(N'[TCD].[RedFlagItemList]'))
BEGIN
ALTER TABLE [TCD].[RedFlagItemList]
 ADD CONSTRAINT [PK__RedFlagI__3214EC0788CC4415] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK__RedFlagM__3214EC0764F12D6B' AND parent_object_id = OBJECT_ID(N'[TCD].[RedFlagMappingData]'))
BEGIN
ALTER TABLE [TCD].[RedFlagMappingData]
 ADD CONSTRAINT [PK__RedFlagM__3214EC0764F12D6B] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK__RedFlagM__8AA9AFC93BF49C7F' AND parent_object_id = OBJECT_ID(N'[TCD].[RedFlagMappingDataHistory]'))
BEGIN
ALTER TABLE [TCD].[RedFlagMappingDataHistory]
 ADD CONSTRAINT [PK__RedFlagM__8AA9AFC93BF49C7F] PRIMARY KEY CLUSTERED(RedFlagHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_RegionMaster' AND parent_object_id = OBJECT_ID(N'[TCD].[RegionMaster]'))
BEGIN
ALTER TABLE [TCD].[RegionMaster]
 ADD CONSTRAINT [PK_RegionMaster] PRIMARY KEY CLUSTERED(RegionId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_Report' AND parent_object_id = OBJECT_ID(N'[TCD].[Report]'))
BEGIN
ALTER TABLE [TCD].[Report]
 ADD CONSTRAINT [PK_Report] PRIMARY KEY CLUSTERED(ReportId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ReportCaregory' AND parent_object_id = OBJECT_ID(N'[TCD].[ReportCategory]'))
BEGIN
ALTER TABLE [TCD].[ReportCategory]
 ADD CONSTRAINT [PK_ReportCaregory] PRIMARY KEY CLUSTERED(ReportCategoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ReportAllColumns' AND parent_object_id = OBJECT_ID(N'[TCD].[ReportColumns]'))
BEGIN
ALTER TABLE [TCD].[ReportColumns]
 ADD CONSTRAINT [PK_ReportAllColumns] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ReportAllColumnsMapping' AND parent_object_id = OBJECT_ID(N'[TCD].[ReportColumnsMapping]'))
BEGIN
ALTER TABLE [TCD].[ReportColumnsMapping]
 ADD CONSTRAINT [PK_ReportAllColumnsMapping] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ReportFilter' AND parent_object_id = OBJECT_ID(N'[TCD].[ReportFilter]'))
BEGIN
ALTER TABLE [TCD].[ReportFilter]
 ADD CONSTRAINT [PK_ReportFilter] PRIMARY KEY CLUSTERED(ReportFilterId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ReportFilterMapping' AND parent_object_id = OBJECT_ID(N'[TCD].[ReportFilterMapping]'))
BEGIN
ALTER TABLE [TCD].[ReportFilterMapping]
 ADD CONSTRAINT [PK_ReportFilterMapping] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ReportHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[ReportHistory]'))
BEGIN
ALTER TABLE [TCD].[ReportHistory]
 ADD CONSTRAINT [PK_ReportHistory] PRIMARY KEY CLUSTERED(ReportGeneratedHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ReportLabelLocalization_ID' AND parent_object_id = OBJECT_ID(N'[TCD].[ReportLabelLocalization]'))
BEGIN
ALTER TABLE [TCD].[ReportLabelLocalization]
 ADD CONSTRAINT [PK_ReportLabelLocalization_ID] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'UQ_ReportLabelLocalization_UsageKey' AND parent_object_id = OBJECT_ID(N'[TCD].[ReportLabelLocalization]'))
BEGIN
ALTER TABLE [TCD].[ReportLabelLocalization]
 ADD CONSTRAINT [UQ_ReportLabelLocalization_UsageKey] UNIQUE NONCLUSTERED(UsageKey ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ReportSubCategory' AND parent_object_id = OBJECT_ID(N'[TCD].[ReportSubCategory]'))
BEGIN
ALTER TABLE [TCD].[ReportSubCategory]
 ADD CONSTRAINT [PK_ReportSubCategory] PRIMARY KEY CLUSTERED(SubCategoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_SwitchCategory' AND parent_object_id = OBJECT_ID(N'[TCD].[ReportSwitchMode]'))
BEGIN
ALTER TABLE [TCD].[ReportSwitchMode]
 ADD CONSTRAINT [PK_SwitchCategory] PRIMARY KEY CLUSTERED(SwitchModeId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ReportSwitchModeMapping' AND parent_object_id = OBJECT_ID(N'[TCD].[ReportSwitchModeMapping]'))
BEGIN
ALTER TABLE [TCD].[ReportSwitchModeMapping]
 ADD CONSTRAINT [PK_ReportSwitchModeMapping] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ReportTracking' AND parent_object_id = OBJECT_ID(N'[TCD].[ReportTracking]'))
BEGIN
ALTER TABLE [TCD].[ReportTracking]
 ADD CONSTRAINT [PK_ReportTracking] PRIMARY KEY CLUSTERED(TrackingId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ResourceKeyMaster' AND parent_object_id = OBJECT_ID(N'[TCD].[ResourceKeyMaster]'))
BEGIN
ALTER TABLE [TCD].[ResourceKeyMaster]
 ADD CONSTRAINT [PK_ResourceKeyMaster] PRIMARY KEY CLUSTERED(KeyName ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ResourceKeyPageMapping' AND parent_object_id = OBJECT_ID(N'[TCD].[ResourceKeyPageMapping]'))
BEGIN
ALTER TABLE [TCD].[ResourceKeyPageMapping]
 ADD CONSTRAINT [PK_ResourceKeyPageMapping] PRIMARY KEY CLUSTERED(KeyName ASC, PageId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ResourceKeyValue' AND parent_object_id = OBJECT_ID(N'[TCD].[ResourceKeyValue]'))
BEGIN
ALTER TABLE [TCD].[ResourceKeyValue]
 ADD CONSTRAINT [PK_ResourceKeyValue] PRIMARY KEY CLUSTERED(KeyName ASC, languageID ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_RewashData' AND parent_object_id = OBJECT_ID(N'[TCD].[RewashData]'))
BEGIN
ALTER TABLE [TCD].[RewashData]
 ADD CONSTRAINT [PK_RewashData] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
ALTER TABLE [TCD].[Sensor] ALTER COLUMN EcolabAccountNumber NVARCHAR(25) NOT NULL
GO

IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_Sensor' AND parent_object_id = OBJECT_ID(N'[TCD].[Sensor]'))
BEGIN
ALTER TABLE [TCD].[Sensor]
 ADD CONSTRAINT [PK_Sensor] PRIMARY KEY CLUSTERED(SensorId ASC, EcolabAccountNumber ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_SensorHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[SensorHistory]'))
BEGIN
ALTER TABLE [TCD].[SensorHistory]
 ADD CONSTRAINT [PK_SensorHistory] PRIMARY KEY CLUSTERED(SensorHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_SensorTypeMaster' AND parent_object_id = OBJECT_ID(N'[TCD].[SensorTypeMaster]'))
BEGIN
ALTER TABLE [TCD].[SensorTypeMaster]
 ADD CONSTRAINT [PK_SensorTypeMaster] PRIMARY KEY CLUSTERED(ResourceId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_Shift' AND parent_object_id = OBJECT_ID(N'[TCD].[Shift]'))
BEGIN
ALTER TABLE [TCD].[Shift]
 ADD CONSTRAINT [PK_Shift] PRIMARY KEY CLUSTERED(ShiftId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ShiftBreakData' AND parent_object_id = OBJECT_ID(N'[TCD].[ShiftBreakData]'))
BEGIN
ALTER TABLE [TCD].[ShiftBreakData]
 ADD CONSTRAINT [PK_ShiftBreakData] PRIMARY KEY CLUSTERED(BreakId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ShiftBreakDataHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[ShiftBreakDataHistory]'))
BEGIN
ALTER TABLE [TCD].[ShiftBreakDataHistory]
 ADD CONSTRAINT [PK_ShiftBreakDataHistory] PRIMARY KEY CLUSTERED(ShiftBreakDataHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ShiftData' AND parent_object_id = OBJECT_ID(N'[TCD].[ShiftData]'))
BEGIN
ALTER TABLE [TCD].[ShiftData]
 ADD CONSTRAINT [PK_ShiftData] PRIMARY KEY CLUSTERED(ShiftId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ShiftDataHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[ShiftDataHistory]'))
BEGIN
ALTER TABLE [TCD].[ShiftDataHistory]
 ADD CONSTRAINT [PK_ShiftDataHistory] PRIMARY KEY CLUSTERED(ShiftDataHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ShiftHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[ShiftHistory]'))
BEGIN
ALTER TABLE [TCD].[ShiftHistory]
 ADD CONSTRAINT [PK_ShiftHistory] PRIMARY KEY CLUSTERED(ShiftHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ShiftLaborDataHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[ShiftLaborDataHistory]'))
BEGIN
ALTER TABLE [TCD].[ShiftLaborDataHistory]
 ADD CONSTRAINT [PK_ShiftLaborDataHistory] PRIMARY KEY CLUSTERED(ShiftLaborDataHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK__SourceSy__3214EC0717ECAE2C' AND parent_object_id = OBJECT_ID(N'[TCD].[SourceSystem]'))
BEGIN
ALTER TABLE [TCD].[SourceSystem]
 ADD CONSTRAINT [PK__SourceSy__3214EC0717ECAE2C] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_TankSetup' AND parent_object_id = OBJECT_ID(N'[TCD].[TankSetup]'))
BEGIN
ALTER TABLE [TCD].[TankSetup]
 ADD CONSTRAINT [PK_TankSetup] PRIMARY KEY CLUSTERED(TankId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_TankSetupHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[TankSetupHistory]'))
BEGIN
ALTER TABLE [TCD].[TankSetupHistory]
 ADD CONSTRAINT [PK_TankSetupHistory] PRIMARY KEY CLUSTERED(TankSetupHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK__TcpMessa__3214EC07AF13E194' AND parent_object_id = OBJECT_ID(N'[TCD].[TcpMessageQueue]'))
BEGIN
ALTER TABLE [TCD].[TcpMessageQueue]
 ADD CONSTRAINT [PK__TcpMessa__3214EC07AF13E194] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_TunnelAnalogControlLevel_TunnelAnalogControlLevelID' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelAnalogControlLevel]'))
BEGIN
ALTER TABLE [TCD].[TunnelAnalogControlLevel]
 ADD CONSTRAINT [PK_TunnelAnalogControlLevel_TunnelAnalogControlLevelID] PRIMARY KEY CLUSTERED(TunnelAnalogControlLevelID ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_TunnelAnalogControlLevelHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelAnalogControlLevelHistory]'))
BEGIN
ALTER TABLE [TCD].[TunnelAnalogControlLevelHistory]
 ADD CONSTRAINT [PK_TunnelAnalogControlLevelHistory] PRIMARY KEY CLUSTERED(TunnelAnalogControlLevelHistoryID ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_TunnelAnalogControlLevelType_TunnelAnalogControlLevelTypeID' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelAnalogControlLevelType]'))
BEGIN
ALTER TABLE [TCD].[TunnelAnalogControlLevelType]
 ADD CONSTRAINT [PK_TunnelAnalogControlLevelType_TunnelAnalogControlLevelTypeID] PRIMARY KEY CLUSTERED(TunnelAnalogControlLevelTypeID ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_TunnelCompartment' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelCompartment]'))
BEGIN
ALTER TABLE [TCD].[TunnelCompartment]
 ADD CONSTRAINT [PK_TunnelCompartment] PRIMARY KEY CLUSTERED(TunnelCompartmentId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'UQ_TunnelCompartment' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelCompartment]'))
BEGIN
ALTER TABLE [TCD].[TunnelCompartment]
 ADD CONSTRAINT [UQ_TunnelCompartment] UNIQUE NONCLUSTERED(WasherId ASC, CompartmentNumber ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_TunnelCompartmentEquipmentMappingHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelCompartmentEquipmentMappingHistory]'))
BEGIN
ALTER TABLE [TCD].[TunnelCompartmentEquipmentMappingHistory]
 ADD CONSTRAINT [PK_TunnelCompartmentEquipmentMappingHistory] PRIMARY KEY CLUSTERED(TunnelCompartmentEquipmentMappingHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_TunnelCompartmentEquipmentValveMapping' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelCompartmentEquipmentValveMapping]'))
BEGIN
ALTER TABLE [TCD].[TunnelCompartmentEquipmentValveMapping]
 ADD CONSTRAINT [PK_TunnelCompartmentEquipmentValveMapping] PRIMARY KEY CLUSTERED(TunnelCompartmentEquipmentValveMappingID ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'UQ_TunnelCompartmentEquipmentValveMapping' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelCompartmentEquipmentValveMapping]'))
BEGIN
ALTER TABLE [TCD].[TunnelCompartmentEquipmentValveMapping]
 ADD CONSTRAINT [UQ_TunnelCompartmentEquipmentValveMapping] UNIQUE NONCLUSTERED(ControllerEquipmentSetupID ASC, TunnelNumber ASC, DosingPointNumber ASC, ValveNumber ASC, CompartmentNumber ASC, DirectDosingFlag ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_TunnelCompartmentHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelCompartmentHistory]'))
BEGIN
ALTER TABLE [TCD].[TunnelCompartmentHistory]
 ADD CONSTRAINT [PK_TunnelCompartmentHistory] PRIMARY KEY CLUSTERED(TunnelCompartmentHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
ALTER TABLE [TCD].[TunnelConductivitySetup] ALTER COLUMN EcolabAccountNumber NVARCHAR(25) NOT NULL
GO

IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_TunnelConductivitySetup' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelConductivitySetup]'))
BEGIN
ALTER TABLE [TCD].[TunnelConductivitySetup]
 ADD CONSTRAINT [PK_TunnelConductivitySetup] PRIMARY KEY CLUSTERED(TunnelProgramSetupId ASC, CompartmentNumber ASC, EcolabAccountNumber ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_TunnelDosingProductMapping' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelDosingProductMapping]'))
BEGIN
ALTER TABLE [TCD].[TunnelDosingProductMapping]
 ADD CONSTRAINT [PK_TunnelDosingProductMapping] PRIMARY KEY CLUSTERED(TunnelDosingProductMappingId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_TunnelDosingProductMappingHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelDosingProductMappingHistory]'))
BEGIN
ALTER TABLE [TCD].[TunnelDosingProductMappingHistory]
 ADD CONSTRAINT [PK_TunnelDosingProductMappingHistory] PRIMARY KEY CLUSTERED(TunnelDosingProductMappingHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_TunnelDosingSetup' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelDosingSetup]'))
BEGIN
ALTER TABLE [TCD].[TunnelDosingSetup]
 ADD CONSTRAINT [PK_TunnelDosingSetup] PRIMARY KEY CLUSTERED(TunnelDosingSetupId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_TunnelDosingSetupHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelDosingSetupHistory]'))
BEGIN
ALTER TABLE [TCD].[TunnelDosingSetupHistory]
 ADD CONSTRAINT [PK_TunnelDosingSetupHistory] PRIMARY KEY CLUSTERED(TunnelDosingSetupHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
ALTER TABLE [TCD].[TunnelpHSetup] ALTER COLUMN EcolabAccountNumber NVARCHAR(25) NOT NULL
GO

IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_TunnelpHSetup' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelpHSetup]'))
BEGIN
ALTER TABLE [TCD].[TunnelpHSetup]
 ADD CONSTRAINT [PK_TunnelpHSetup] PRIMARY KEY CLUSTERED(TunnelProgramSetupId ASC, CompartmentNumber ASC, EcolabAccountNumber ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_TunnelPressExtractor' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelPressExtractor]'))
BEGIN
ALTER TABLE [TCD].[TunnelPressExtractor]
 ADD CONSTRAINT [PK_TunnelPressExtractor] PRIMARY KEY CLUSTERED(TunnelPressExtractorId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_TunnelProgramSetup' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelProgramSetup]'))
BEGIN
ALTER TABLE [TCD].[TunnelProgramSetup]
 ADD CONSTRAINT [PK_TunnelProgramSetup] PRIMARY KEY CLUSTERED(TunnelProgramSetupId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_TunnelProgramSetupHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelProgramSetupHistory]'))
BEGIN
ALTER TABLE [TCD].[TunnelProgramSetupHistory]
 ADD CONSTRAINT [PK_TunnelProgramSetupHistory] PRIMARY KEY CLUSTERED(TunnelProgramSetupHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_TunnelTransferType' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelTransferType]'))
BEGIN
ALTER TABLE [TCD].[TunnelTransferType]
 ADD CONSTRAINT [PK_TunnelTransferType] PRIMARY KEY CLUSTERED(TunnelTransferTypeId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_TunnelWaterFlowType' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelWaterFlowType]'))
BEGIN
ALTER TABLE [TCD].[TunnelWaterFlowType]
 ADD CONSTRAINT [PK_TunnelWaterFlowType] PRIMARY KEY CLUSTERED(TunnelWaterFlowTypeId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_TunnelWaterInletDrainLookup' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelWaterInletDrainLookup]'))
BEGIN
ALTER TABLE [TCD].[TunnelWaterInletDrainLookup]
 ADD CONSTRAINT [PK_TunnelWaterInletDrainLookup] PRIMARY KEY CLUSTERED(TunnelWaterInletDrainLookupId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_UnitOfMeasure' AND parent_object_id = OBJECT_ID(N'[TCD].[UnitOfMeasure]'))
BEGIN
ALTER TABLE [TCD].[UnitOfMeasure]
 ADD CONSTRAINT [PK_UnitOfMeasure] PRIMARY KEY CLUSTERED(UOMId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_UserAudit' AND parent_object_id = OBJECT_ID(N'[TCD].[UserAudit]'))
BEGIN
ALTER TABLE [TCD].[UserAudit]
 ADD CONSTRAINT [PK_UserAudit] PRIMARY KEY CLUSTERED(UserAuditId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_UserInRoleHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[UserInRoleHistory]'))
BEGIN
ALTER TABLE [TCD].[UserInRoleHistory]
 ADD CONSTRAINT [PK_UserInRoleHistory] PRIMARY KEY CLUSTERED(UserRoleHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_UserMaster' AND parent_object_id = OBJECT_ID(N'[TCD].[UserMaster]'))
BEGIN
ALTER TABLE [TCD].[UserMaster]
 ADD CONSTRAINT [PK_UserMaster] PRIMARY KEY CLUSTERED(UserId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_UserMasterHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[UserMasterHistory]'))
BEGIN
ALTER TABLE [TCD].[UserMasterHistory]
 ADD CONSTRAINT [PK_UserMasterHistory] PRIMARY KEY CLUSTERED(UserHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK__UserProfile' AND parent_object_id = OBJECT_ID(N'[TCD].[UserProfile]'))
BEGIN
ALTER TABLE [TCD].[UserProfile]
 ADD CONSTRAINT [PK__UserProfile] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_UserRoles' AND parent_object_id = OBJECT_ID(N'[TCD].[UserRoles]'))
BEGIN
ALTER TABLE [TCD].[UserRoles]
 ADD CONSTRAINT [PK_UserRoles] PRIMARY KEY CLUSTERED(RoleId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ResourceMaster' AND parent_object_id = OBJECT_ID(N'[TCD].[UtilityMaster]'))
BEGIN
ALTER TABLE [TCD].[UtilityMaster]
 ADD CONSTRAINT [PK_ResourceMaster] PRIMARY KEY CLUSTERED(ResourceId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_Washer' AND parent_object_id = OBJECT_ID(N'[TCD].[Washer]'))
BEGIN
ALTER TABLE [TCD].[Washer]
 ADD CONSTRAINT [PK_Washer] PRIMARY KEY CLUSTERED(WasherId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_WasherDosingAnalogControllerMapping' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherDosingAnalogControllerMapping]'))
BEGIN
ALTER TABLE [TCD].[WasherDosingAnalogControllerMapping]
 ADD CONSTRAINT [PK_WasherDosingAnalogControllerMapping] PRIMARY KEY CLUSTERED(WasherDosingAnalogControllerMappingId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_WasherDosingProductMapping' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherDosingProductMapping]'))
BEGIN
ALTER TABLE [TCD].[WasherDosingProductMapping]
 ADD CONSTRAINT [PK_WasherDosingProductMapping] PRIMARY KEY CLUSTERED(WasherDosingProductMappingId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_WasherDosingProductMappingHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherDosingProductMappingHistory]'))
BEGIN
ALTER TABLE [TCD].[WasherDosingProductMappingHistory]
 ADD CONSTRAINT [PK_WasherDosingProductMappingHistory] PRIMARY KEY CLUSTERED(WasherDosingProductMappingHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_WasherDosingSetup' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherDosingSetup]'))
BEGIN
ALTER TABLE [TCD].[WasherDosingSetup]
 ADD CONSTRAINT [PK_WasherDosingSetup] PRIMARY KEY CLUSTERED(WasherDosingSetupId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_WasherDosingSetupHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherDosingSetupHistory]'))
BEGIN
ALTER TABLE [TCD].[WasherDosingSetupHistory]
 ADD CONSTRAINT [PK_WasherDosingSetupHistory] PRIMARY KEY CLUSTERED(WasherDosingSetupHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_WasherFlushTime' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherFlushTime]'))
BEGIN
ALTER TABLE [TCD].[WasherFlushTime]
 ADD CONSTRAINT [PK_WasherFlushTime] PRIMARY KEY CLUSTERED(WasherId ASC, PlantId ASC, LineNumber ASC, WasherFlushTypeId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_WasherFlushTimeHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherFlushTimeHistory]'))
BEGIN
ALTER TABLE [TCD].[WasherFlushTimeHistory]
 ADD CONSTRAINT [PK_WasherFlushTimeHistory] PRIMARY KEY CLUSTERED(WasherFlushTimeHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_FlushType_FlushTypeId' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherFlushType]'))
BEGIN
ALTER TABLE [TCD].[WasherFlushType]
 ADD CONSTRAINT [PK_FlushType_FlushTypeId] PRIMARY KEY CLUSTERED(WasherFlushTypeId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_WasherGroup' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherGroup]'))
BEGIN
ALTER TABLE [TCD].[WasherGroup]
 ADD CONSTRAINT [PK_WasherGroup] PRIMARY KEY CLUSTERED(WasherGroupId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_WasherGroupHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherGroupHistory]'))
BEGIN
ALTER TABLE [TCD].[WasherGroupHistory]
 ADD CONSTRAINT [PK_WasherGroupHistory] PRIMARY KEY CLUSTERED(WasherGroupHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_WasherGroupType' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherGroupType]'))
BEGIN
ALTER TABLE [TCD].[WasherGroupType]
 ADD CONSTRAINT [PK_WasherGroupType] PRIMARY KEY CLUSTERED(WasherGroupTypeId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'UQ_WasherGroupType' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherGroupType]'))
BEGIN
ALTER TABLE [TCD].[WasherGroupType]
 ADD CONSTRAINT [UQ_WasherGroupType] UNIQUE NONCLUSTERED(WasherGroupTypeName ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_WasherHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherHistory]'))
BEGIN
ALTER TABLE [TCD].[WasherHistory]
 ADD CONSTRAINT [PK_WasherHistory] PRIMARY KEY CLUSTERED(WasherHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_WasherMode' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherMode]'))
BEGIN
ALTER TABLE [TCD].[WasherMode]
 ADD CONSTRAINT [PK_WasherMode] PRIMARY KEY CLUSTERED(WasherModeId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_WasherModelSize' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherModelSize]'))
BEGIN
ALTER TABLE [TCD].[WasherModelSize]
 ADD CONSTRAINT [PK_WasherModelSize] PRIMARY KEY CLUSTERED(WasherModelId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_ControllerTypeModelToWasherMode' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherModeMapping]'))
BEGIN
ALTER TABLE [TCD].[WasherModeMapping]
 ADD CONSTRAINT [PK_ControllerTypeModelToWasherMode] PRIMARY KEY CLUSTERED(ControllerTypeModelToWasherModeId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'UQ_ControllerTypeModelToWasherMode' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherModeMapping]'))
BEGIN
ALTER TABLE [TCD].[WasherModeMapping]
 ADD CONSTRAINT [UQ_ControllerTypeModelToWasherMode] UNIQUE NONCLUSTERED(ControllerModelControllerTypeMappingId ASC, WasherModeId ASC, WasherType ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_WasherModuleOnlineUsageData' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherModuleOnlineUsageData]'))
BEGIN
ALTER TABLE [TCD].[WasherModuleOnlineUsageData]
 ADD CONSTRAINT [PK_WasherModuleOnlineUsageData] PRIMARY KEY CLUSTERED(WasherModuleOnlineUsageDataId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_WasherProductDeviations_WasherProductDeviationID' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherProductDeviations]'))
BEGIN
ALTER TABLE [TCD].[WasherProductDeviations]
 ADD CONSTRAINT [PK_WasherProductDeviations_WasherProductDeviationID] PRIMARY KEY CLUSTERED(WasherProductDeviationID ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_WasherProductDeviationsHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherProductDeviationsHistory]'))
BEGIN
ALTER TABLE [TCD].[WasherProductDeviationsHistory]
 ADD CONSTRAINT [PK_WasherProductDeviationsHistory] PRIMARY KEY CLUSTERED(WasherProductDeviationsHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_WasherProgramSetup' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherProgramSetup]'))
BEGIN
ALTER TABLE [TCD].[WasherProgramSetup]
 ADD CONSTRAINT [PK_WasherProgramSetup] PRIMARY KEY CLUSTERED(WasherProgramSetupId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_WasherProgramSetupHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherProgramSetupHistory]'))
BEGIN
ALTER TABLE [TCD].[WasherProgramSetupHistory]
 ADD CONSTRAINT [PK_WasherProgramSetupHistory] PRIMARY KEY CLUSTERED(WasherProgramSetupHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK__WasherTi__3617461B5D88FD93' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherTimeOutMachine]'))
BEGIN
ALTER TABLE [TCD].[WasherTimeOutMachine]
 ADD CONSTRAINT [PK__WasherTi__3617461B5D88FD93] PRIMARY KEY CLUSTERED(WasherId ASC, PlantId ASC, SignalNumber ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_WasherTimeOutMachineHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherTimeOutMachineHistory]'))
BEGIN
ALTER TABLE [TCD].[WasherTimeOutMachineHistory]
 ADD CONSTRAINT [PK_WasherTimeOutMachineHistory] PRIMARY KEY CLUSTERED(WasherTimeOutMachineHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_WasherWaterLevelReference' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherWaterLevelReference]'))
BEGIN
ALTER TABLE [TCD].[WasherWaterLevelReference]
 ADD CONSTRAINT [PK_WasherWaterLevelReference] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'UQ_WasherWaterLevelReference' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherWaterLevelReference]'))
BEGIN
ALTER TABLE [TCD].[WasherWaterLevelReference]
 ADD CONSTRAINT [UQ_WasherWaterLevelReference] UNIQUE NONCLUSTERED(WaterLevel ASC, WasherModelId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_WashStep' AND parent_object_id = OBJECT_ID(N'[TCD].[WashStep]'))
BEGIN
ALTER TABLE [TCD].[WashStep]
 ADD CONSTRAINT [PK_WashStep] PRIMARY KEY CLUSTERED(StepId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_WaterAndEnergy' AND parent_object_id = OBJECT_ID(N'[TCD].[WaterAndEnergy]'))
BEGIN
ALTER TABLE [TCD].[WaterAndEnergy]
 ADD CONSTRAINT [PK_WaterAndEnergy] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_WaterAndEnergyConsumptionLog' AND parent_object_id = OBJECT_ID(N'[TCD].[WaterAndEnergyConsumptionLog]'))
BEGIN
ALTER TABLE [TCD].[WaterAndEnergyConsumptionLog]
 ADD CONSTRAINT [PK_WaterAndEnergyConsumptionLog] PRIMARY KEY CLUSTERED(WaterAndEnergyConsumptionLogId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_WaterAndEnergyHistory' AND parent_object_id = OBJECT_ID(N'[TCD].[WaterAndEnergyHistory]'))
BEGIN
ALTER TABLE [TCD].[WaterAndEnergyHistory]
 ADD CONSTRAINT [PK_WaterAndEnergyHistory] PRIMARY KEY CLUSTERED(WaterAndEnergyHistoryId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_WaterType_Id' AND parent_object_id = OBJECT_ID(N'[TCD].[WaterType]'))
BEGIN
ALTER TABLE [TCD].[WaterType]
 ADD CONSTRAINT [PK_WaterType_Id] PRIMARY KEY CLUSTERED(Id ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
IF NOT EXISTS(SELECT * FROM sys.key_constraints kc WHERE name = 'PK_WeekDay' AND parent_object_id = OBJECT_ID(N'[TCD].[WeekDay]'))
BEGIN
ALTER TABLE [TCD].[WeekDay]
 ADD CONSTRAINT [PK_WeekDay] PRIMARY KEY CLUSTERED(DayId ASC) 
WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
--- END - Primary Key and Unique Key Creation

--- START - Foreign Key Creation
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TunnelCompartment_WashStepId' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelCompartment]'))
BEGIN
ALTER TABLE [TCD].[TunnelCompartment] WITH CHECK ADD CONSTRAINT [FK_TunnelCompartment_WashStepId] FOREIGN KEY([WashStepId]) REFERENCES [TCD].[WashStep] ([StepId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TunnelCompartment_WaterFlow' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelCompartment]'))
BEGIN
ALTER TABLE [TCD].[TunnelCompartment] WITH CHECK ADD CONSTRAINT [FK_TunnelCompartment_WaterFlow] FOREIGN KEY([WaterFlowId]) REFERENCES [TCD].[TunnelWaterFlowType] ([TunnelWaterFlowTypeId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TunnelCompartment_WaterInletDrain' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelCompartment]'))
BEGIN
ALTER TABLE [TCD].[TunnelCompartment] WITH CHECK ADD CONSTRAINT [FK_TunnelCompartment_WaterInletDrain] FOREIGN KEY([WaterInletDrainId]) REFERENCES [TCD].[TunnelWaterInletDrainLookup] ([TunnelWaterInletDrainLookupId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TunnelCompartmentEquipmentMapping_ControllerEquipmentSetupId' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelCompartmentEquipmentMapping]'))
BEGIN
ALTER TABLE [TCD].[TunnelCompartmentEquipmentMapping] WITH CHECK ADD CONSTRAINT [FK_TunnelCompartmentEquipmentMapping_ControllerEquipmentSetupId] FOREIGN KEY([ControllerEquipmentSetupId]) REFERENCES [TCD].[ControllerEquipmentSetup] ([ControllerEquipmentSetupId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TunnelCompartmentEquipmentMapping_TunnelCompartmentid' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelCompartmentEquipmentMapping]'))
BEGIN
ALTER TABLE [TCD].[TunnelCompartmentEquipmentMapping] WITH CHECK ADD CONSTRAINT [FK_TunnelCompartmentEquipmentMapping_TunnelCompartmentid] FOREIGN KEY([TunnelCompartmentId]) REFERENCES [TCD].[TunnelCompartment] ([TunnelCompartmentId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TunnelCompartmentEquipmentMapping_UserId' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelCompartmentEquipmentMapping]'))
BEGIN
ALTER TABLE [TCD].[TunnelCompartmentEquipmentMapping] WITH CHECK ADD CONSTRAINT [FK_TunnelCompartmentEquipmentMapping_UserId] FOREIGN KEY([LastModifiedByUserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TunnelCompartmentEquipmentMappingHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelCompartmentEquipmentMappingHistory]'))
BEGIN
ALTER TABLE [TCD].[TunnelCompartmentEquipmentMappingHistory] WITH CHECK ADD CONSTRAINT [FK_TunnelCompartmentEquipmentMappingHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_AlarmData_AlarmGroupMasterId' AND parent_object_id = OBJECT_ID(N'[TCD].[AlarmData]'))
BEGIN
ALTER TABLE [TCD].[AlarmData] WITH CHECK ADD CONSTRAINT [FK_AlarmData_AlarmGroupMasterId] FOREIGN KEY([AlarmGroupMasterId]) REFERENCES [TCD].[AlarmGroupMaster] ([AlarmGroupMasterId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TunnelCompartmentEquipmentValveMapping_ControllerEquipmentSetupID_ControllerEquipmentSetup_ControllerEquipmentSetupID' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelCompartmentEquipmentValveMapping]'))
BEGIN
ALTER TABLE [TCD].[TunnelCompartmentEquipmentValveMapping] WITH CHECK ADD CONSTRAINT [FK_TunnelCompartmentEquipmentValveMapping_ControllerEquipmentSetupID_ControllerEquipmentSetup_ControllerEquipmentSetupID] FOREIGN KEY([ControllerEquipmentSetupID]) REFERENCES [TCD].[ControllerEquipmentSetup] ([ControllerEquipmentSetupId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_AlarmData_Plant' AND parent_object_id = OBJECT_ID(N'[TCD].[AlarmData]'))
BEGIN
ALTER TABLE [TCD].[AlarmData] WITH CHECK ADD CONSTRAINT [FK_AlarmData_Plant] FOREIGN KEY([EcoalabAccountNumber]) REFERENCES [TCD].[Plant] ([EcolabAccountNumber]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TunnelCompartmentHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelCompartmentHistory]'))
BEGIN
ALTER TABLE [TCD].[TunnelCompartmentHistory] WITH CHECK ADD CONSTRAINT [FK_TunnelCompartmentHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_AlarmGroupMsterVsControllerModelType_AlarmGroupMasterId' AND parent_object_id = OBJECT_ID(N'[TCD].[AlarmGroupMsterVsControllerModelType]'))
BEGIN
ALTER TABLE [TCD].[AlarmGroupMsterVsControllerModelType] WITH CHECK ADD CONSTRAINT [FK_AlarmGroupMsterVsControllerModelType_AlarmGroupMasterId] FOREIGN KEY([AlarmGroupMasterId]) REFERENCES [TCD].[AlarmGroupMaster] ([AlarmGroupMasterId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TunnelConductivitySetup' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelConductivitySetup]'))
BEGIN
ALTER TABLE [TCD].[TunnelConductivitySetup] WITH CHECK ADD CONSTRAINT [FK_TunnelConductivitySetup] FOREIGN KEY([TunnelProgramSetupId]) REFERENCES [TCD].[TunnelProgramSetup] ([TunnelProgramSetupId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_AlarmStatus_AlarmGroupMsterVsControllerModelTypeId' AND parent_object_id = OBJECT_ID(N'[TCD].[AlarmStatus]'))
BEGIN
ALTER TABLE [TCD].[AlarmStatus] WITH CHECK ADD CONSTRAINT [FK_AlarmStatus_AlarmGroupMsterVsControllerModelTypeId] FOREIGN KEY([AlarmGroupMsterVsControllerModelTypeId]) REFERENCES [TCD].[AlarmGroupMsterVsControllerModelType] ([AlarmGroupMsterVsControllerModelTypeId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TunnelDosingProductMapping_ProductId' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelDosingProductMapping]'))
BEGIN
ALTER TABLE [TCD].[TunnelDosingProductMapping] WITH CHECK ADD CONSTRAINT [FK_TunnelDosingProductMapping_ProductId] FOREIGN KEY([EcoLabAccountNumber], [ProductId]) REFERENCES [TCD].[ProductdataMapping] ([EcolabAccountNumber], [ProductID]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_AlarmStatus_EcolabAccountNumber' AND parent_object_id = OBJECT_ID(N'[TCD].[AlarmStatus]'))
BEGIN
ALTER TABLE [TCD].[AlarmStatus] WITH CHECK ADD CONSTRAINT [FK_AlarmStatus_EcolabAccountNumber] FOREIGN KEY([EcolabAccountNumber]) REFERENCES [TCD].[Plant] ([EcolabAccountNumber]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TunnelDosingProductMapping_UserId' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelDosingProductMapping]'))
BEGIN
ALTER TABLE [TCD].[TunnelDosingProductMapping] WITH CHECK ADD CONSTRAINT [FK_TunnelDosingProductMapping_UserId] FOREIGN KEY([LastModifiedByUserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_AlarmStatus_LastModifiedByUserId' AND parent_object_id = OBJECT_ID(N'[TCD].[AlarmStatus]'))
BEGIN
ALTER TABLE [TCD].[AlarmStatus] WITH CHECK ADD CONSTRAINT [FK_AlarmStatus_LastModifiedByUserId] FOREIGN KEY([LastModifiedByuserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TunnelDosingProductMappingHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelDosingProductMappingHistory]'))
BEGIN
ALTER TABLE [TCD].[TunnelDosingProductMappingHistory] WITH CHECK ADD CONSTRAINT [FK_TunnelDosingProductMappingHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_BatchCustomerData_BatchData' AND parent_object_id = OBJECT_ID(N'[TCD].[BatchCustomerData]'))
BEGIN
ALTER TABLE [TCD].[BatchCustomerData] WITH CHECK ADD CONSTRAINT [FK_BatchCustomerData_BatchData] FOREIGN KEY([BatchId]) REFERENCES [TCD].[BatchData] ([BatchId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TunnelDosingSetup_DrainDestination' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelDosingSetup]'))
BEGIN
ALTER TABLE [TCD].[TunnelDosingSetup] WITH CHECK ADD CONSTRAINT [FK_TunnelDosingSetup_DrainDestination] FOREIGN KEY([DrainDestinationId]) REFERENCES [TCD].[DrainDestination] ([DrainDestinationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'Fk_BatchEjectConditionId_BatchEjectConditionStatus' AND parent_object_id = OBJECT_ID(N'[TCD].[BatchEjectConditionStatus]'))
BEGIN
ALTER TABLE [TCD].[BatchEjectConditionStatus] WITH CHECK ADD CONSTRAINT [Fk_BatchEjectConditionId_BatchEjectConditionStatus] FOREIGN KEY([BatchEjectConditionId]) REFERENCES [TCD].[BatchEjectCondition] ([BatchEjectConditionId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TunnelDosingSetup_Plant' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelDosingSetup]'))
BEGIN
ALTER TABLE [TCD].[TunnelDosingSetup] WITH CHECK ADD CONSTRAINT [FK_TunnelDosingSetup_Plant] FOREIGN KEY([EcolabAccountNumber]) REFERENCES [TCD].[Plant] ([EcolabAccountNumber]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_BatchEnergyUsageData_BatchData' AND parent_object_id = OBJECT_ID(N'[TCD].[BatchEnergyUsageData]'))
BEGIN
ALTER TABLE [TCD].[BatchEnergyUsageData] WITH CHECK ADD CONSTRAINT [FK_BatchEnergyUsageData_BatchData] FOREIGN KEY([BatchId]) REFERENCES [TCD].[BatchData] ([BatchId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TunnelDosingSetup_TunnelProgramSetupId' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelDosingSetup]'))
BEGIN
ALTER TABLE [TCD].[TunnelDosingSetup] WITH CHECK ADD CONSTRAINT [FK_TunnelDosingSetup_TunnelProgramSetupId] FOREIGN KEY([TunnelProgramSetupId]) REFERENCES [TCD].[TunnelProgramSetup] ([TunnelProgramSetupId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_BatchProductData_BatchData' AND parent_object_id = OBJECT_ID(N'[TCD].[BatchProductData]'))
BEGIN
ALTER TABLE [TCD].[BatchProductData] WITH CHECK ADD CONSTRAINT [FK_BatchProductData_BatchData] FOREIGN KEY([BatchId]) REFERENCES [TCD].[BatchData] ([BatchId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TunnelDosingSetup_UserId' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelDosingSetup]'))
BEGIN
ALTER TABLE [TCD].[TunnelDosingSetup] WITH CHECK ADD CONSTRAINT [FK_TunnelDosingSetup_UserId] FOREIGN KEY([LastModifiedByUserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_BatchStepWaterUsageData_BatchData' AND parent_object_id = OBJECT_ID(N'[TCD].[BatchStepWaterUsageData]'))
BEGIN
ALTER TABLE [TCD].[BatchStepWaterUsageData] WITH CHECK ADD CONSTRAINT [FK_BatchStepWaterUsageData_BatchData] FOREIGN KEY([BatchId]) REFERENCES [TCD].[BatchData] ([BatchId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TunnelDosingSetupHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelDosingSetupHistory]'))
BEGIN
ALTER TABLE [TCD].[TunnelDosingSetupHistory] WITH CHECK ADD CONSTRAINT [FK_TunnelDosingSetupHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_BatchWashStepData_BatchData' AND parent_object_id = OBJECT_ID(N'[TCD].[BatchWashStepData]'))
BEGIN
ALTER TABLE [TCD].[BatchWashStepData] WITH CHECK ADD CONSTRAINT [FK_BatchWashStepData_BatchData] FOREIGN KEY([BatchId]) REFERENCES [TCD].[BatchData] ([BatchId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK__TunnelpHS__Tunne__11F49EE0' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelpHSetup]'))
BEGIN
ALTER TABLE [TCD].[TunnelpHSetup] WITH CHECK ADD CONSTRAINT [FK__TunnelpHS__Tunne__11F49EE0] FOREIGN KEY([TunnelProgramSetupId]) REFERENCES [TCD].[TunnelProgramSetup] ([TunnelProgramSetupId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Chart_ChartTypeID' AND parent_object_id = OBJECT_ID(N'[TCD].[ConduitChartparameterMapping]'))
BEGIN
ALTER TABLE [TCD].[ConduitChartparameterMapping] WITH CHECK ADD CONSTRAINT [FK_Chart_ChartTypeID] FOREIGN KEY([ChartTypeId]) REFERENCES [TCD].[ConduitChartMaster] ([ChartTypeId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TunnelProgramReading_Plant' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelProgramReading]'))
BEGIN
ALTER TABLE [TCD].[TunnelProgramReading] WITH CHECK ADD CONSTRAINT [FK_TunnelProgramReading_Plant] FOREIGN KEY([EcoalabAccountNumber]) REFERENCES [TCD].[Plant] ([EcolabAccountNumber]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ConduitController_LastModifiedByUserId' AND parent_object_id = OBJECT_ID(N'[TCD].[ConduitController]'))
BEGIN
ALTER TABLE [TCD].[ConduitController] WITH CHECK ADD CONSTRAINT [FK_ConduitController_LastModifiedByUserId] FOREIGN KEY([LastModifiedByUserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TunnelProgramReading_PlantCustomer' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelProgramReading]'))
BEGIN
ALTER TABLE [TCD].[TunnelProgramReading] WITH CHECK ADD CONSTRAINT [FK_TunnelProgramReading_PlantCustomer] FOREIGN KEY([CustomerId]) REFERENCES [TCD].[PlantCustomer] ([ID]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ConduitController_Plant' AND parent_object_id = OBJECT_ID(N'[TCD].[ConduitController]'))
BEGIN
ALTER TABLE [TCD].[ConduitController] WITH CHECK ADD CONSTRAINT [FK_ConduitController_Plant] FOREIGN KEY([EcoalabAccountNumber]) REFERENCES [TCD].[Plant] ([EcolabAccountNumber]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TunnelProgramSetup_EcoLabAccountNumber' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelProgramSetup]'))
BEGIN
ALTER TABLE [TCD].[TunnelProgramSetup] WITH CHECK ADD CONSTRAINT [FK_TunnelProgramSetup_EcoLabAccountNumber] FOREIGN KEY([EcolabAccountNumber]) REFERENCES [TCD].[Plant] ([EcolabAccountNumber]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ConduitControllerHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[ConduitControllerHistory]'))
BEGIN
ALTER TABLE [TCD].[ConduitControllerHistory] WITH CHECK ADD CONSTRAINT [FK_ConduitControllerHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TunnelProgramSetup_Plant' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelProgramSetup]'))
BEGIN
ALTER TABLE [TCD].[TunnelProgramSetup] WITH CHECK ADD CONSTRAINT [FK_TunnelProgramSetup_Plant] FOREIGN KEY([EcolabAccountNumber]) REFERENCES [TCD].[Plant] ([EcolabAccountNumber]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Dashboard_DashboardType' AND parent_object_id = OBJECT_ID(N'[TCD].[ConduitDashboard]'))
BEGIN
ALTER TABLE [TCD].[ConduitDashboard] WITH CHECK ADD CONSTRAINT [FK_Dashboard_DashboardType] FOREIGN KEY([DashboardTypeId]) REFERENCES [TCD].[DashboardType] ([Id]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TunnelProgramSetup_ProgramId' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelProgramSetup]'))
BEGIN
ALTER TABLE [TCD].[TunnelProgramSetup] WITH CHECK ADD CONSTRAINT [FK_TunnelProgramSetup_ProgramId] FOREIGN KEY([ProgramId]) REFERENCES [TCD].[ProgramMaster] ([ProgramId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_DashboardDetail_Dashboard' AND parent_object_id = OBJECT_ID(N'[TCD].[ConduitDashboardDetail]'))
BEGIN
ALTER TABLE [TCD].[ConduitDashboardDetail] WITH CHECK ADD CONSTRAINT [FK_DashboardDetail_Dashboard] FOREIGN KEY([DashboardId]) REFERENCES [TCD].[ConduitDashboard] ([Id]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TunnelProgramSetup_UserId' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelProgramSetup]'))
BEGIN
ALTER TABLE [TCD].[TunnelProgramSetup] WITH CHECK ADD CONSTRAINT [FK_TunnelProgramSetup_UserId] FOREIGN KEY([LastModifiedByUserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_DashboardDetail_PortletMaster' AND parent_object_id = OBJECT_ID(N'[TCD].[ConduitDashboardDetail]'))
BEGIN
ALTER TABLE [TCD].[ConduitDashboardDetail] WITH CHECK ADD CONSTRAINT [FK_DashboardDetail_PortletMaster] FOREIGN KEY([PortletId]) REFERENCES [TCD].[PortletMaster] ([Id]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TunnelProgramSetup_WasherGroupId' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelProgramSetup]'))
BEGIN
ALTER TABLE [TCD].[TunnelProgramSetup] WITH CHECK ADD CONSTRAINT [FK_TunnelProgramSetup_WasherGroupId] FOREIGN KEY([WasherGroupId]) REFERENCES [TCD].[WasherGroup] ([WasherGroupId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_UISectionType_UISectionMaster' AND parent_object_id = OBJECT_ID(N'[TCD].[ConduitMenu]'))
BEGIN
ALTER TABLE [TCD].[ConduitMenu] WITH CHECK ADD CONSTRAINT [FK_UISectionType_UISectionMaster] FOREIGN KEY([SectionType]) REFERENCES [TCD].[ConduitSectionType] ([SectionType]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TunnelProgramSetupHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelProgramSetupHistory]'))
BEGIN
ALTER TABLE [TCD].[TunnelProgramSetupHistory] WITH CHECK ADD CONSTRAINT [FK_TunnelProgramSetupHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_UISectionMaster_UISectionSettingsMapping' AND parent_object_id = OBJECT_ID(N'[TCD].[ConduitMenuRoleMapping]'))
BEGIN
ALTER TABLE [TCD].[ConduitMenuRoleMapping] WITH CHECK ADD CONSTRAINT [FK_UISectionMaster_UISectionSettingsMapping] FOREIGN KEY([SectionCode]) REFERENCES [TCD].[ConduitMenu] ([SectionCode]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'Fk_TunnelTempSetup_TunnelProgramSetupId' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelTempSetup]'))
BEGIN
ALTER TABLE [TCD].[TunnelTempSetup] WITH CHECK ADD CONSTRAINT [Fk_TunnelTempSetup_TunnelProgramSetupId] FOREIGN KEY([TunnelProgramSetupId]) REFERENCES [TCD].[TunnelProgramSetup] ([TunnelProgramSetupId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ControllerEquipmentSetup_ControllerEquipmentTypeId' AND parent_object_id = OBJECT_ID(N'[TCD].[ControllerEquipmentSetup]'))
BEGIN
ALTER TABLE [TCD].[ControllerEquipmentSetup] WITH CHECK ADD CONSTRAINT [FK_ControllerEquipmentSetup_ControllerEquipmentTypeId] FOREIGN KEY([ControllerEquipmentTypeId]) REFERENCES [TCD].[ControllerEquipmentType] ([ControllerEquipmentTypeId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_UserAudit_Activity' AND parent_object_id = OBJECT_ID(N'[TCD].[UserAudit]'))
BEGIN
ALTER TABLE [TCD].[UserAudit] WITH CHECK ADD CONSTRAINT [FK_UserAudit_Activity] FOREIGN KEY([UserActivityId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ControllerEquipmentSetup_ControllerId' AND parent_object_id = OBJECT_ID(N'[TCD].[ControllerEquipmentSetup]'))
BEGIN
ALTER TABLE [TCD].[ControllerEquipmentSetup] WITH CHECK ADD CONSTRAINT [FK_ControllerEquipmentSetup_ControllerId] FOREIGN KEY([EcoLabAccountNumber], [ControllerId]) REFERENCES [TCD].[ConduitController] ([EcoalabAccountNumber], [ControllerId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_UserAudit_Plant' AND parent_object_id = OBJECT_ID(N'[TCD].[UserAudit]'))
BEGIN
ALTER TABLE [TCD].[UserAudit] WITH CHECK ADD CONSTRAINT [FK_UserAudit_Plant] FOREIGN KEY([EcoLabAccountNumber]) REFERENCES [TCD].[Plant] ([EcolabAccountNumber]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ControllerEquipmentSetup_LastModifiedByUserId' AND parent_object_id = OBJECT_ID(N'[TCD].[ControllerEquipmentSetup]'))
BEGIN
ALTER TABLE [TCD].[ControllerEquipmentSetup] WITH CHECK ADD CONSTRAINT [FK_ControllerEquipmentSetup_LastModifiedByUserId] FOREIGN KEY([LastModifiedByUserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_UserAudit_UserId' AND parent_object_id = OBJECT_ID(N'[TCD].[UserAudit]'))
BEGIN
ALTER TABLE [TCD].[UserAudit] WITH CHECK ADD CONSTRAINT [FK_UserAudit_UserId] FOREIGN KEY([UserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ControllerEquipmentSetup_ProductId' AND parent_object_id = OBJECT_ID(N'[TCD].[ControllerEquipmentSetup]'))
BEGIN
ALTER TABLE [TCD].[ControllerEquipmentSetup] WITH CHECK ADD CONSTRAINT [FK_ControllerEquipmentSetup_ProductId] FOREIGN KEY([EcoLabAccountNumber], [ProductId]) REFERENCES [TCD].[ProductdataMapping] ([EcolabAccountNumber], [ProductID]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_UserInRole_UserMaster' AND parent_object_id = OBJECT_ID(N'[TCD].[UserInRole]'))
BEGIN
ALTER TABLE [TCD].[UserInRole] WITH CHECK ADD CONSTRAINT [FK_UserInRole_UserMaster] FOREIGN KEY([UserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ControllerEquipmentSetupHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[ControllerEquipmentSetupHistory]'))
BEGIN
ALTER TABLE [TCD].[ControllerEquipmentSetupHistory] WITH CHECK ADD CONSTRAINT [FK_ControllerEquipmentSetupHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_UserInRole_UserRoles' AND parent_object_id = OBJECT_ID(N'[TCD].[UserInRole]'))
BEGIN
ALTER TABLE [TCD].[UserInRole] WITH CHECK ADD CONSTRAINT [FK_UserInRole_UserRoles] FOREIGN KEY([RoleId]) REFERENCES [TCD].[UserRoles] ([RoleId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ControllerSetupData_LastModifiedByUserId' AND parent_object_id = OBJECT_ID(N'[TCD].[ControllerSetupData]'))
BEGIN
ALTER TABLE [TCD].[ControllerSetupData] WITH CHECK ADD CONSTRAINT [FK_ControllerSetupData_LastModifiedByUserId] FOREIGN KEY([LastModifiedByUserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_UserMaster_LanguageMaster' AND parent_object_id = OBJECT_ID(N'[TCD].[UserMaster]'))
BEGIN
ALTER TABLE [TCD].[UserMaster] WITH CHECK ADD CONSTRAINT [FK_UserMaster_LanguageMaster] FOREIGN KEY([LanguageId]) REFERENCES [TCD].[LanguageMaster] ([LanguageId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ControllerSetupDataHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[ControllerSetupDataHistory]'))
BEGIN
ALTER TABLE [TCD].[ControllerSetupDataHistory] WITH CHECK ADD CONSTRAINT [FK_ControllerSetupDataHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_UserMaster_UnitOfMeasure' AND parent_object_id = OBJECT_ID(N'[TCD].[UserMaster]'))
BEGIN
ALTER TABLE [TCD].[UserMaster] WITH CHECK ADD CONSTRAINT [FK_UserMaster_UnitOfMeasure] FOREIGN KEY([UOMId]) REFERENCES [TCD].[UnitOfMeasure] ([UOMId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Dashboard_Plant' AND parent_object_id = OBJECT_ID(N'[TCD].[Dashboard]'))
BEGIN
ALTER TABLE [TCD].[Dashboard] WITH CHECK ADD CONSTRAINT [FK_Dashboard_Plant] FOREIGN KEY([EcolabAccountNumber]) REFERENCES [TCD].[Plant] ([EcolabAccountNumber]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_UserProfile_UserMaster' AND parent_object_id = OBJECT_ID(N'[TCD].[UserProfile]'))
BEGIN
ALTER TABLE [TCD].[UserProfile] WITH CHECK ADD CONSTRAINT [FK_UserProfile_UserMaster] FOREIGN KEY([UserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Dashboard_WasherGroupType' AND parent_object_id = OBJECT_ID(N'[TCD].[Dashboard]'))
BEGIN
ALTER TABLE [TCD].[Dashboard] WITH CHECK ADD CONSTRAINT [FK_Dashboard_WasherGroupType] FOREIGN KEY([TypeId]) REFERENCES [TCD].[WasherGroupType] ([WasherGroupTypeId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Washer_EcoLabAccountNumber' AND parent_object_id = OBJECT_ID(N'[TCD].[Washer]'))
BEGIN
ALTER TABLE [TCD].[Washer] WITH CHECK ADD CONSTRAINT [FK_Washer_EcoLabAccountNumber] FOREIGN KEY([EcoLabAccountNumber]) REFERENCES [TCD].[Plant] ([EcolabAccountNumber]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TCD.DashboardUserPortletMapping_PortletMaster' AND parent_object_id = OBJECT_ID(N'[TCD].[DashboardUserPortletMapping]'))
BEGIN
ALTER TABLE [TCD].[DashboardUserPortletMapping] WITH CHECK ADD CONSTRAINT [FK_TCD.DashboardUserPortletMapping_PortletMaster] FOREIGN KEY([PortletId]) REFERENCES [TCD].[PortletMaster] ([Id]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Washer_LastModifiedByUserId' AND parent_object_id = OBJECT_ID(N'[TCD].[Washer]'))
BEGIN
ALTER TABLE [TCD].[Washer] WITH CHECK ADD CONSTRAINT [FK_Washer_LastModifiedByUserId] FOREIGN KEY([LastModifiedByUserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TCD.DashboardUserPortletMapping_UserMaster' AND parent_object_id = OBJECT_ID(N'[TCD].[DashboardUserPortletMapping]'))
BEGIN
ALTER TABLE [TCD].[DashboardUserPortletMapping] WITH CHECK ADD CONSTRAINT [FK_TCD.DashboardUserPortletMapping_UserMaster] FOREIGN KEY([UserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Washer_ModelId' AND parent_object_id = OBJECT_ID(N'[TCD].[Washer]'))
BEGIN
ALTER TABLE [TCD].[Washer] WITH CHECK ADD CONSTRAINT [FK_Washer_ModelId] FOREIGN KEY([ModelId]) REFERENCES [TCD].[WasherModelSize] ([WasherModelId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_DeviceModel_DeviceType' AND parent_object_id = OBJECT_ID(N'[TCD].[DeviceModel]'))
BEGIN
ALTER TABLE [TCD].[DeviceModel] WITH CHECK ADD CONSTRAINT [FK_DeviceModel_DeviceType] FOREIGN KEY([DeviceTypeId]) REFERENCES [TCD].[DeviceType] ([DeviceTypeId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Washer_TransferType' AND parent_object_id = OBJECT_ID(N'[TCD].[Washer]'))
BEGIN
ALTER TABLE [TCD].[Washer] WITH CHECK ADD CONSTRAINT [FK_Washer_TransferType] FOREIGN KEY([TransferType]) REFERENCES [TCD].[TunnelTransferType] ([TunnelTransferTypeId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_DimensionalDisplayUnits_DimensionalSubunits' AND parent_object_id = OBJECT_ID(N'[TCD].[DimensionalDisplayUnits]'))
BEGIN
ALTER TABLE [TCD].[DimensionalDisplayUnits] WITH CHECK ADD CONSTRAINT [FK_DimensionalDisplayUnits_DimensionalSubunits] FOREIGN KEY([Unit], [Subunit]) REFERENCES [TCD].[DimensionalSubunits] ([Unit], [Subunit]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Washer_TunnelPressExtractor' AND parent_object_id = OBJECT_ID(N'[TCD].[Washer]'))
BEGIN
ALTER TABLE [TCD].[Washer] WITH CHECK ADD CONSTRAINT [FK_Washer_TunnelPressExtractor] FOREIGN KEY([PressExtractor]) REFERENCES [TCD].[TunnelPressExtractor] ([TunnelPressExtractorId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_DimensionalSubunits_DimensionalUnits' AND parent_object_id = OBJECT_ID(N'[TCD].[DimensionalSubunits]'))
BEGIN
ALTER TABLE [TCD].[DimensionalSubunits] WITH CHECK ADD CONSTRAINT [FK_DimensionalSubunits_DimensionalUnits] FOREIGN KEY([Unit]) REFERENCES [TCD].[DimensionalUnits] ([Unit]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherDosingAnalogControllerMapping_WasherDosingSetupId' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherDosingAnalogControllerMapping]'))
BEGIN
ALTER TABLE [TCD].[WasherDosingAnalogControllerMapping] WITH CHECK ADD CONSTRAINT [FK_WasherDosingAnalogControllerMapping_WasherDosingSetupId] FOREIGN KEY([WasherDosingSetupId]) REFERENCES [TCD].[WasherDosingSetup] ([WasherDosingSetupId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_DimensionalUnitsDefaults_DimensionalSubunits' AND parent_object_id = OBJECT_ID(N'[TCD].[DimensionalUnitsDefaults]'))
BEGIN
ALTER TABLE [TCD].[DimensionalUnitsDefaults] WITH CHECK ADD CONSTRAINT [FK_DimensionalUnitsDefaults_DimensionalSubunits] FOREIGN KEY([Unit], [Subunit]) REFERENCES [TCD].[DimensionalSubunits] ([Unit], [Subunit]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherDosingProductMapping_ProductId' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherDosingProductMapping]'))
BEGIN
ALTER TABLE [TCD].[WasherDosingProductMapping] WITH CHECK ADD CONSTRAINT [FK_WasherDosingProductMapping_ProductId] FOREIGN KEY([EcoLabAccountNumber], [ProductId]) REFERENCES [TCD].[ProductdataMapping] ([EcolabAccountNumber], [ProductID]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_DimensionalUnitsDefaults_DimensionalUnitSystems' AND parent_object_id = OBJECT_ID(N'[TCD].[DimensionalUnitsDefaults]'))
BEGIN
ALTER TABLE [TCD].[DimensionalUnitsDefaults] WITH CHECK ADD CONSTRAINT [FK_DimensionalUnitsDefaults_DimensionalUnitSystems] FOREIGN KEY([UnitSystemId]) REFERENCES [TCD].[DimensionalUnitSystems] ([UnitSystemId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherDosingProductMapping_UserId' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherDosingProductMapping]'))
BEGIN
ALTER TABLE [TCD].[WasherDosingProductMapping] WITH CHECK ADD CONSTRAINT [FK_WasherDosingProductMapping_UserId] FOREIGN KEY([LastModifiedByUserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_DimensionalUsageKey_DimensionalUnits' AND parent_object_id = OBJECT_ID(N'[TCD].[DimensionalUsageKey]'))
BEGIN
ALTER TABLE [TCD].[DimensionalUsageKey] WITH CHECK ADD CONSTRAINT [FK_DimensionalUsageKey_DimensionalUnits] FOREIGN KEY([Unit]) REFERENCES [TCD].[DimensionalUnits] ([Unit]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherDosingProductMapping_WasherDosingSetupId' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherDosingProductMapping]'))
BEGIN
ALTER TABLE [TCD].[WasherDosingProductMapping] WITH CHECK ADD CONSTRAINT [FK_WasherDosingProductMapping_WasherDosingSetupId] FOREIGN KEY([WasherDosingSetupId]) REFERENCES [TCD].[WasherDosingSetup] ([WasherDosingSetupId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_DryersHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[DryersHistory]'))
BEGIN
ALTER TABLE [TCD].[DryersHistory] WITH CHECK ADD CONSTRAINT [FK_DryersHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherDosingProductMappingHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherDosingProductMappingHistory]'))
BEGIN
ALTER TABLE [TCD].[WasherDosingProductMappingHistory] WITH CHECK ADD CONSTRAINT [FK_WasherDosingProductMappingHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_EcolabTextileCategory_RegionId' AND parent_object_id = OBJECT_ID(N'[TCD].[EcolabTextileCategory]'))
BEGIN
ALTER TABLE [TCD].[EcolabTextileCategory] WITH CHECK ADD CONSTRAINT [FK_EcolabTextileCategory_RegionId] FOREIGN KEY([RegionId]) REFERENCES [TCD].[RegionMaster] ([RegionId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_DosingSetup_WashStep' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherDosingSetup]'))
BEGIN
ALTER TABLE [TCD].[WasherDosingSetup] WITH CHECK ADD CONSTRAINT [FK_DosingSetup_WashStep] FOREIGN KEY([StepTypeId]) REFERENCES [TCD].[WashStep] ([StepId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_EnergyUtilityDetails_LastModifiedByUserId' AND parent_object_id = OBJECT_ID(N'[TCD].[EnergyUtilityDetails]'))
BEGIN
ALTER TABLE [TCD].[EnergyUtilityDetails] WITH CHECK ADD CONSTRAINT [FK_EnergyUtilityDetails_LastModifiedByUserId] FOREIGN KEY([LastModifiedByUserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherDosingSetup_ControllerID_ConduitController_ControllerID' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherDosingSetup]'))
BEGIN
ALTER TABLE [TCD].[WasherDosingSetup] WITH CHECK ADD CONSTRAINT [FK_WasherDosingSetup_ControllerID_ConduitController_ControllerID] FOREIGN KEY([ControllerID]) REFERENCES [TCD].[ConduitController] ([ControllerId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Field_DataSource' AND parent_object_id = OBJECT_ID(N'[TCD].[Field]'))
BEGIN
ALTER TABLE [TCD].[Field] WITH CHECK ADD CONSTRAINT [FK_Field_DataSource] FOREIGN KEY([DataSourceId]) REFERENCES [TCD].[DataSource] ([Id]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherDosingSetup_DrainDestination' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherDosingSetup]'))
BEGIN
ALTER TABLE [TCD].[WasherDosingSetup] WITH CHECK ADD CONSTRAINT [FK_WasherDosingSetup_DrainDestination] FOREIGN KEY([DrainDestinationId]) REFERENCES [TCD].[DrainDestination] ([DrainDestinationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Field_DataType' AND parent_object_id = OBJECT_ID(N'[TCD].[Field]'))
BEGIN
ALTER TABLE [TCD].[Field] WITH CHECK ADD CONSTRAINT [FK_Field_DataType] FOREIGN KEY([DataTypeId]) REFERENCES [TCD].[DataType] ([Id]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherDosingSetup_UserId' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherDosingSetup]'))
BEGIN
ALTER TABLE [TCD].[WasherDosingSetup] WITH CHECK ADD CONSTRAINT [FK_WasherDosingSetup_UserId] FOREIGN KEY([LastModifiedByUserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Field_FieldGroup' AND parent_object_id = OBJECT_ID(N'[TCD].[Field]'))
BEGIN
ALTER TABLE [TCD].[Field] WITH CHECK ADD CONSTRAINT [FK_Field_FieldGroup] FOREIGN KEY([FieldGroupId]) REFERENCES [TCD].[FieldGroup] ([Id]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherDosingSetup_WasherProgramSetupId' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherDosingSetup]'))
BEGIN
ALTER TABLE [TCD].[WasherDosingSetup] WITH CHECK ADD CONSTRAINT [FK_WasherDosingSetup_WasherProgramSetupId] FOREIGN KEY([WasherProgramSetupId]) REFERENCES [TCD].[WasherProgramSetup] ([WasherProgramSetupId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Field_FieldType' AND parent_object_id = OBJECT_ID(N'[TCD].[Field]'))
BEGIN
ALTER TABLE [TCD].[Field] WITH CHECK ADD CONSTRAINT [FK_Field_FieldType] FOREIGN KEY([TypeId]) REFERENCES [TCD].[FieldType] ([Id]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherDosingSetupHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherDosingSetupHistory]'))
BEGIN
ALTER TABLE [TCD].[WasherDosingSetupHistory] WITH CHECK ADD CONSTRAINT [FK_WasherDosingSetupHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_FieldGroup_FieldGroupType' AND parent_object_id = OBJECT_ID(N'[TCD].[FieldGroup]'))
BEGIN
ALTER TABLE [TCD].[FieldGroup] WITH CHECK ADD CONSTRAINT [FK_FieldGroup_FieldGroupType] FOREIGN KEY([FieldGroupTypeId]) REFERENCES [TCD].[FieldGroupType] ([Id]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherFlushTime_FlushType' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherFlushTime]'))
BEGIN
ALTER TABLE [TCD].[WasherFlushTime] WITH CHECK ADD CONSTRAINT [FK_WasherFlushTime_FlushType] FOREIGN KEY([WasherFlushTypeId]) REFERENCES [TCD].[WasherFlushType] ([WasherFlushTypeId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_FieldGroup_TabType' AND parent_object_id = OBJECT_ID(N'[TCD].[FieldGroup]'))
BEGIN
ALTER TABLE [TCD].[FieldGroup] WITH CHECK ADD CONSTRAINT [FK_FieldGroup_TabType] FOREIGN KEY([TabId]) REFERENCES [TCD].[ConduitTabType] ([Id]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherFlushTime_Washer' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherFlushTime]'))
BEGIN
ALTER TABLE [TCD].[WasherFlushTime] WITH CHECK ADD CONSTRAINT [FK_WasherFlushTime_Washer] FOREIGN KEY([WasherId]) REFERENCES [TCD].[Washer] ([WasherId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_FieldGroupFieldMapping_Field' AND parent_object_id = OBJECT_ID(N'[TCD].[FieldGroupFieldMapping]'))
BEGIN
ALTER TABLE [TCD].[FieldGroupFieldMapping] WITH CHECK ADD CONSTRAINT [FK_FieldGroupFieldMapping_Field] FOREIGN KEY([FieldId]) REFERENCES [TCD].[Field] ([Id]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherGroup_LastModifiedByUserId' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherGroup]'))
BEGIN
ALTER TABLE [TCD].[WasherGroup] WITH CHECK ADD CONSTRAINT [FK_WasherGroup_LastModifiedByUserId] FOREIGN KEY([LastModifiedByUserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_FieldGroupFieldMapping_FieldGroup' AND parent_object_id = OBJECT_ID(N'[TCD].[FieldGroupFieldMapping]'))
BEGIN
ALTER TABLE [TCD].[FieldGroupFieldMapping] WITH CHECK ADD CONSTRAINT [FK_FieldGroupFieldMapping_FieldGroup] FOREIGN KEY([FieldGroupId]) REFERENCES [TCD].[FieldGroup] ([Id]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherGroup_WasherGroupId' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherGroup]'))
BEGIN
ALTER TABLE [TCD].[WasherGroup] WITH CHECK ADD CONSTRAINT [FK_WasherGroup_WasherGroupId] FOREIGN KEY([WasherGroupId]) REFERENCES [TCD].[MachineGroup] ([Id]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_FieldRoleMapping_Field' AND parent_object_id = OBJECT_ID(N'[TCD].[FieldRoleMapping]'))
BEGIN
ALTER TABLE [TCD].[FieldRoleMapping] WITH CHECK ADD CONSTRAINT [FK_FieldRoleMapping_Field] FOREIGN KEY([FieldId]) REFERENCES [TCD].[Field] ([Id]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherGroup_WasherGroupTypeId' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherGroup]'))
BEGIN
ALTER TABLE [TCD].[WasherGroup] WITH CHECK ADD CONSTRAINT [FK_WasherGroup_WasherGroupTypeId] FOREIGN KEY([WasherGroupTypeId]) REFERENCES [TCD].[WasherGroupType] ([WasherGroupTypeId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_FieldSource_DataSource' AND parent_object_id = OBJECT_ID(N'[TCD].[FieldSource]'))
BEGIN
ALTER TABLE [TCD].[FieldSource] WITH CHECK ADD CONSTRAINT [FK_FieldSource_DataSource] FOREIGN KEY([DataSourceId]) REFERENCES [TCD].[DataSource] ([Id]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherGroupHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherGroupHistory]'))
BEGIN
ALTER TABLE [TCD].[WasherGroupHistory] WITH CHECK ADD CONSTRAINT [FK_WasherGroupHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_MachineGroup_EcoLabAccountNumber' AND parent_object_id = OBJECT_ID(N'[TCD].[MachineGroup]'))
BEGIN
ALTER TABLE [TCD].[MachineGroup] WITH CHECK ADD CONSTRAINT [FK_MachineGroup_EcoLabAccountNumber] FOREIGN KEY([EcolabAccountNumber]) REFERENCES [TCD].[Plant] ([EcolabAccountNumber]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherHistory]'))
BEGIN
ALTER TABLE [TCD].[WasherHistory] WITH CHECK ADD CONSTRAINT [FK_WasherHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_MachineGroup_GroupTypeId' AND parent_object_id = OBJECT_ID(N'[TCD].[MachineGroup]'))
BEGIN
ALTER TABLE [TCD].[MachineGroup] WITH CHECK ADD CONSTRAINT [FK_MachineGroup_GroupTypeId] FOREIGN KEY([GroupTypeId]) REFERENCES [TCD].[MachineGroupType] ([Id]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherModelSize_RegionId' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherModelSize]'))
BEGIN
ALTER TABLE [TCD].[WasherModelSize] WITH CHECK ADD CONSTRAINT [FK_WasherModelSize_RegionId] FOREIGN KEY([RegionId]) REFERENCES [TCD].[RegionMaster] ([RegionId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_MachineGroup_UserMaster' AND parent_object_id = OBJECT_ID(N'[TCD].[MachineGroup]'))
BEGIN
ALTER TABLE [TCD].[MachineGroup] WITH CHECK ADD CONSTRAINT [FK_MachineGroup_UserMaster] FOREIGN KEY([LastModifiedByUserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ControllerTypeModelToWasherMode_ControllerTypeModel' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherModeMapping]'))
BEGIN
ALTER TABLE [TCD].[WasherModeMapping] WITH CHECK ADD CONSTRAINT [FK_ControllerTypeModelToWasherMode_ControllerTypeModel] FOREIGN KEY([ControllerModelControllerTypeMappingId]) REFERENCES [TCD].[ControllerModelControllerTypeMapping] ([Id]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_MachineSetup_ControllerId' AND parent_object_id = OBJECT_ID(N'[TCD].[MachineSetup]'))
BEGIN
ALTER TABLE [TCD].[MachineSetup] WITH CHECK ADD CONSTRAINT [FK_MachineSetup_ControllerId] FOREIGN KEY([ControllerId]) REFERENCES [TCD].[ConduitController] ([ControllerId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherModeMapping_WasherMode' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherModeMapping]'))
BEGIN
ALTER TABLE [TCD].[WasherModeMapping] WITH CHECK ADD CONSTRAINT [FK_WasherModeMapping_WasherMode] FOREIGN KEY([WasherModeId]) REFERENCES [TCD].[WasherMode] ([WasherModeId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_MachineSetup_Plant' AND parent_object_id = OBJECT_ID(N'[TCD].[MachineSetup]'))
BEGIN
ALTER TABLE [TCD].[MachineSetup] WITH CHECK ADD CONSTRAINT [FK_MachineSetup_Plant] FOREIGN KEY([EcoalabAccountNumber]) REFERENCES [TCD].[Plant] ([EcolabAccountNumber]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherModuleOnlineUsageData_Meter' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherModuleOnlineUsageData]'))
BEGIN
ALTER TABLE [TCD].[WasherModuleOnlineUsageData] WITH CHECK ADD CONSTRAINT [FK_WasherModuleOnlineUsageData_Meter] FOREIGN KEY([ModuleId]) REFERENCES [TCD].[Meter] ([MeterId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_MachineSetup_UserId' AND parent_object_id = OBJECT_ID(N'[TCD].[MachineSetup]'))
BEGIN
ALTER TABLE [TCD].[MachineSetup] WITH CHECK ADD CONSTRAINT [FK_MachineSetup_UserId] FOREIGN KEY([LastModifiedByUserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherModuleOnlineUsageData_Washer' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherModuleOnlineUsageData]'))
BEGIN
ALTER TABLE [TCD].[WasherModuleOnlineUsageData] WITH CHECK ADD CONSTRAINT [FK_WasherModuleOnlineUsageData_Washer] FOREIGN KEY([WasherId]) REFERENCES [TCD].[Washer] ([WasherId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_MachineSetup_WasherId' AND parent_object_id = OBJECT_ID(N'[TCD].[MachineSetup]'))
BEGIN
ALTER TABLE [TCD].[MachineSetup] WITH CHECK ADD CONSTRAINT [FK_MachineSetup_WasherId] FOREIGN KEY([WasherId]) REFERENCES [TCD].[Washer] ([WasherId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherProductDeviations_WasherID_Washer_WasherID' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherProductDeviations]'))
BEGIN
ALTER TABLE [TCD].[WasherProductDeviations] WITH CHECK ADD CONSTRAINT [FK_WasherProductDeviations_WasherID_Washer_WasherID] FOREIGN KEY([WasherId]) REFERENCES [TCD].[Washer] ([WasherId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_MachineSetupHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[MachineSetupHistory]'))
BEGIN
ALTER TABLE [TCD].[MachineSetupHistory] WITH CHECK ADD CONSTRAINT [FK_MachineSetupHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherProgramTrending_PlantCustomer' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherProgramReading]'))
BEGIN
ALTER TABLE [TCD].[WasherProgramReading] WITH CHECK ADD CONSTRAINT [FK_WasherProgramTrending_PlantCustomer] FOREIGN KEY([CustomerId]) REFERENCES [TCD].[PlantCustomer] ([ID]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ManualLabor_GroupType' AND parent_object_id = OBJECT_ID(N'[TCD].[ManualLabor]'))
BEGIN
ALTER TABLE [TCD].[ManualLabor] WITH CHECK ADD CONSTRAINT [FK_ManualLabor_GroupType] FOREIGN KEY([LocationId]) REFERENCES [TCD].[MachineGroup] ([Id]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherProgramTrending_WashStep' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherProgramReading]'))
BEGIN
ALTER TABLE [TCD].[WasherProgramReading] WITH CHECK ADD CONSTRAINT [FK_WasherProgramTrending_WashStep] FOREIGN KEY([StepId]) REFERENCES [TCD].[WashStep] ([StepId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ManualLabor_LaborType' AND parent_object_id = OBJECT_ID(N'[TCD].[ManualLabor]'))
BEGIN
ALTER TABLE [TCD].[ManualLabor] WITH CHECK ADD CONSTRAINT [FK_ManualLabor_LaborType] FOREIGN KEY([ManHourTypeId]) REFERENCES [TCD].[LaborType] ([LaborTypeId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherProgramSetup_ControllerID_ConduitController_ControllerID' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherProgramSetup]'))
BEGIN
ALTER TABLE [TCD].[WasherProgramSetup] WITH CHECK ADD CONSTRAINT [FK_WasherProgramSetup_ControllerID_ConduitController_ControllerID] FOREIGN KEY([ControllerID]) REFERENCES [TCD].[ConduitController] ([ControllerId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ManualLaborHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[ManualLaborHistory]'))
BEGIN
ALTER TABLE [TCD].[ManualLaborHistory] WITH CHECK ADD CONSTRAINT [FK_ManualLaborHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherProgramSetup_EcoLabAccountNumber' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherProgramSetup]'))
BEGIN
ALTER TABLE [TCD].[WasherProgramSetup] WITH CHECK ADD CONSTRAINT [FK_WasherProgramSetup_EcoLabAccountNumber] FOREIGN KEY([EcolabAccountNumber]) REFERENCES [TCD].[Plant] ([EcolabAccountNumber]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ManualProductionHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[ManualProductionHistory]'))
BEGIN
ALTER TABLE [TCD].[ManualProductionHistory] WITH CHECK ADD CONSTRAINT [FK_ManualProductionHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherProgramSetup_ProgramId' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherProgramSetup]'))
BEGIN
ALTER TABLE [TCD].[WasherProgramSetup] WITH CHECK ADD CONSTRAINT [FK_WasherProgramSetup_ProgramId] FOREIGN KEY([ProgramId]) REFERENCES [TCD].[ProgramMaster] ([ProgramId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Meter_LastModifiedByUserId' AND parent_object_id = OBJECT_ID(N'[TCD].[Meter]'))
BEGIN
ALTER TABLE [TCD].[Meter] WITH CHECK ADD CONSTRAINT [FK_Meter_LastModifiedByUserId] FOREIGN KEY([LastModifiedByUserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherProgramSetup_UserId' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherProgramSetup]'))
BEGIN
ALTER TABLE [TCD].[WasherProgramSetup] WITH CHECK ADD CONSTRAINT [FK_WasherProgramSetup_UserId] FOREIGN KEY([LastModifiedByUserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Meter_Plant' AND parent_object_id = OBJECT_ID(N'[TCD].[Meter]'))
BEGIN
ALTER TABLE [TCD].[Meter] WITH CHECK ADD CONSTRAINT [FK_Meter_Plant] FOREIGN KEY([EcolabAccountNumber]) REFERENCES [TCD].[Plant] ([EcolabAccountNumber]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherProgramSetup_WasherGroupId' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherProgramSetup]'))
BEGIN
ALTER TABLE [TCD].[WasherProgramSetup] WITH CHECK ADD CONSTRAINT [FK_WasherProgramSetup_WasherGroupId] FOREIGN KEY([WasherGroupId]) REFERENCES [TCD].[WasherGroup] ([WasherGroupId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Meter_WaterType' AND parent_object_id = OBJECT_ID(N'[TCD].[Meter]'))
BEGIN
ALTER TABLE [TCD].[Meter] WITH CHECK ADD CONSTRAINT [FK_Meter_WaterType] FOREIGN KEY([WaterType]) REFERENCES [TCD].[WaterType] ([Id]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherProgramSetupHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherProgramSetupHistory]'))
BEGIN
ALTER TABLE [TCD].[WasherProgramSetupHistory] WITH CHECK ADD CONSTRAINT [FK_WasherProgramSetupHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_MeterHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[MeterHistory]'))
BEGIN
ALTER TABLE [TCD].[MeterHistory] WITH CHECK ADD CONSTRAINT [FK_MeterHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherTempSetup_ProductMaster' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherTempSetup]'))
BEGIN
ALTER TABLE [TCD].[WasherTempSetup] WITH CHECK ADD CONSTRAINT [FK_WasherTempSetup_ProductMaster] FOREIGN KEY([ProductId]) REFERENCES [TCD].[ProductMaster] ([ProductId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ModuleReading_ModuleType' AND parent_object_id = OBJECT_ID(N'[TCD].[ModuleReading]'))
BEGIN
ALTER TABLE [TCD].[ModuleReading] WITH CHECK ADD CONSTRAINT [FK_ModuleReading_ModuleType] FOREIGN KEY([ModuleTypeId]) REFERENCES [TCD].[ModuleType] ([ModuleTypeId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherTimeOutMachine_Washer' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherTimeOutMachine]'))
BEGIN
ALTER TABLE [TCD].[WasherTimeOutMachine] WITH CHECK ADD CONSTRAINT [FK_WasherTimeOutMachine_Washer] FOREIGN KEY([WasherId]) REFERENCES [TCD].[Washer] ([WasherId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_DashboardMapping_DashboardId' AND parent_object_id = OBJECT_ID(N'[TCD].[MonitorSetUpMapping]'))
BEGIN
ALTER TABLE [TCD].[MonitorSetUpMapping] WITH CHECK ADD CONSTRAINT [FK_DashboardMapping_DashboardId] FOREIGN KEY([DashboardId]) REFERENCES [TCD].[Dashboard] ([DashboardId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WasherWaterLevelReference_WasherModelSize' AND parent_object_id = OBJECT_ID(N'[TCD].[WasherWaterLevelReference]'))
BEGIN
ALTER TABLE [TCD].[WasherWaterLevelReference] WITH CHECK ADD CONSTRAINT [FK_WasherWaterLevelReference_WasherModelSize] FOREIGN KEY([WasherModelId]) REFERENCES [TCD].[WasherModelSize] ([WasherModelId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_MyServiceUOMRefToUnitOfMeasureMapping_ConduitUOMId' AND parent_object_id = OBJECT_ID(N'[TCD].[MyServiceUOMRefToUnitOfMeasureMapping]'))
BEGIN
ALTER TABLE [TCD].[MyServiceUOMRefToUnitOfMeasureMapping] WITH CHECK ADD CONSTRAINT [FK_MyServiceUOMRefToUnitOfMeasureMapping_ConduitUOMId] FOREIGN KEY([ConduitUOMId]) REFERENCES [TCD].[UnitOfMeasure] ([UOMId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WashStep_RegionId' AND parent_object_id = OBJECT_ID(N'[TCD].[WashStep]'))
BEGIN
ALTER TABLE [TCD].[WashStep] WITH CHECK ADD CONSTRAINT [FK_WashStep_RegionId] FOREIGN KEY([RegionId]) REFERENCES [TCD].[RegionMaster] ([RegionId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Plant_Language' AND parent_object_id = OBJECT_ID(N'[TCD].[Plant]'))
BEGIN
ALTER TABLE [TCD].[Plant] WITH CHECK ADD CONSTRAINT [FK_Plant_Language] FOREIGN KEY([LanguageId]) REFERENCES [TCD].[LanguageMaster] ([LanguageId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WaterAndEnergy_LastModifiedByUserId' AND parent_object_id = OBJECT_ID(N'[TCD].[WaterAndEnergy]'))
BEGIN
ALTER TABLE [TCD].[WaterAndEnergy] WITH CHECK ADD CONSTRAINT [FK_WaterAndEnergy_LastModifiedByUserId] FOREIGN KEY([LastModifiedByUserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Plant_LastModifiedByUserId' AND parent_object_id = OBJECT_ID(N'[TCD].[Plant]'))
BEGIN
ALTER TABLE [TCD].[Plant] WITH CHECK ADD CONSTRAINT [FK_Plant_LastModifiedByUserId] FOREIGN KEY([LastModifiedByUserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WaterAndEnergy_Plant' AND parent_object_id = OBJECT_ID(N'[TCD].[WaterAndEnergy]'))
BEGIN
ALTER TABLE [TCD].[WaterAndEnergy] WITH CHECK ADD CONSTRAINT [FK_WaterAndEnergy_Plant] FOREIGN KEY([EcolabAccountNumber]) REFERENCES [TCD].[Plant] ([EcolabAccountNumber]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Plant_PlantCategory' AND parent_object_id = OBJECT_ID(N'[TCD].[Plant]'))
BEGIN
ALTER TABLE [TCD].[Plant] WITH CHECK ADD CONSTRAINT [FK_Plant_PlantCategory] FOREIGN KEY([PlantCategoryId]) REFERENCES [TCD].[PlantCategory] ([PlantCategoryId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WaterAndEnergyHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[WaterAndEnergyHistory]'))
BEGIN
ALTER TABLE [TCD].[WaterAndEnergyHistory] WITH CHECK ADD CONSTRAINT [FK_WaterAndEnergyHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Plant_RegionMaster' AND parent_object_id = OBJECT_ID(N'[TCD].[Plant]'))
BEGIN
ALTER TABLE [TCD].[Plant] WITH CHECK ADD CONSTRAINT [FK_Plant_RegionMaster] FOREIGN KEY([RegionId]) REFERENCES [TCD].[RegionMaster] ([RegionId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WaterUtilityDetails_LastModifiedByUserId' AND parent_object_id = OBJECT_ID(N'[TCD].[WaterUtilityDetails]'))
BEGIN
ALTER TABLE [TCD].[WaterUtilityDetails] WITH CHECK ADD CONSTRAINT [FK_WaterUtilityDetails_LastModifiedByUserId] FOREIGN KEY([LastModifiedByUserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Plant_SourceSystemId' AND parent_object_id = OBJECT_ID(N'[TCD].[Plant]'))
BEGIN
ALTER TABLE [TCD].[Plant] WITH CHECK ADD CONSTRAINT [FK_Plant_SourceSystemId] FOREIGN KEY([SourceSystemId]) REFERENCES [TCD].[SourceSystem] ([Id]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_PlantChain_Region' AND parent_object_id = OBJECT_ID(N'[TCD].[PlantChain]'))
BEGIN
ALTER TABLE [TCD].[PlantChain] WITH CHECK ADD CONSTRAINT [FK_PlantChain_Region] FOREIGN KEY([RegionId]) REFERENCES [TCD].[RegionMaster] ([RegionId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_PlantChainProgram_ChainTextileCategoryId' AND parent_object_id = OBJECT_ID(N'[TCD].[PlantChainProgram]'))
BEGIN
ALTER TABLE [TCD].[PlantChainProgram] WITH CHECK ADD CONSTRAINT [FK_PlantChainProgram_ChainTextileCategoryId] FOREIGN KEY([ChainTextileCategoryId]) REFERENCES [TCD].[ChainTextileCategory] ([TextileId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_PlantChainProgram_EcolabSaturationId' AND parent_object_id = OBJECT_ID(N'[TCD].[PlantChainProgram]'))
BEGIN
ALTER TABLE [TCD].[PlantChainProgram] WITH CHECK ADD CONSTRAINT [FK_PlantChainProgram_EcolabSaturationId] FOREIGN KEY([EcolabSaturationId]) REFERENCES [TCD].[EcolabSaturation] ([EcolabSaturationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_PlantChainProgram_EcolabTextileCategoryId' AND parent_object_id = OBJECT_ID(N'[TCD].[PlantChainProgram]'))
BEGIN
ALTER TABLE [TCD].[PlantChainProgram] WITH CHECK ADD CONSTRAINT [FK_PlantChainProgram_EcolabTextileCategoryId] FOREIGN KEY([EcolabTextileCategoryId]) REFERENCES [TCD].[EcolabTextileCategory] ([TextileId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_PlantChainProgram_FormulaSegmentId' AND parent_object_id = OBJECT_ID(N'[TCD].[PlantChainProgram]'))
BEGIN
ALTER TABLE [TCD].[PlantChainProgram] WITH CHECK ADD CONSTRAINT [FK_PlantChainProgram_FormulaSegmentId] FOREIGN KEY([FormulaSegmentId]) REFERENCES [TCD].[FormulaSegments] ([FormulaSegmentID]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_PlantContact_ContactPositionId' AND parent_object_id = OBJECT_ID(N'[TCD].[PlantContact]'))
BEGIN
ALTER TABLE [TCD].[PlantContact] WITH CHECK ADD CONSTRAINT [FK_PlantContact_ContactPositionId] FOREIGN KEY([ContactPositionId]) REFERENCES [TCD].[PlantContactPosition] ([Id]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_PlantContact_EcolabAccountNumber' AND parent_object_id = OBJECT_ID(N'[TCD].[PlantContact]'))
BEGIN
ALTER TABLE [TCD].[PlantContact] WITH CHECK ADD CONSTRAINT [FK_PlantContact_EcolabAccountNumber] FOREIGN KEY([EcolabAccountNumber]) REFERENCES [TCD].[Plant] ([EcolabAccountNumber]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_PlantContact_LastModifiedByUserId' AND parent_object_id = OBJECT_ID(N'[TCD].[PlantContact]'))
BEGIN
ALTER TABLE [TCD].[PlantContact] WITH CHECK ADD CONSTRAINT [FK_PlantContact_LastModifiedByUserId] FOREIGN KEY([LastModifiedByUserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_PlantContactHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[PlantContactHistory]'))
BEGIN
ALTER TABLE [TCD].[PlantContactHistory] WITH CHECK ADD CONSTRAINT [FK_PlantContactHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK__PlantCust__Ecola__56D3D912' AND parent_object_id = OBJECT_ID(N'[TCD].[PlantCustAddress]'))
BEGIN
ALTER TABLE [TCD].[PlantCustAddress] WITH CHECK ADD CONSTRAINT [FK__PlantCust__Ecola__56D3D912] FOREIGN KEY([EcolabAccountNumber]) REFERENCES [TCD].[Plant] ([EcolabAccountNumber]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_PlantCustomer_LastModifiedByUserId' AND parent_object_id = OBJECT_ID(N'[TCD].[PlantCustomer]'))
BEGIN
ALTER TABLE [TCD].[PlantCustomer] WITH CHECK ADD CONSTRAINT [FK_PlantCustomer_LastModifiedByUserId] FOREIGN KEY([LastModifiedByUserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_PlantCustomerHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[PlantCustomerHistory]'))
BEGIN
ALTER TABLE [TCD].[PlantCustomerHistory] WITH CHECK ADD CONSTRAINT [FK_PlantCustomerHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_PlantHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[PlantHistory]'))
BEGIN
ALTER TABLE [TCD].[PlantHistory] WITH CHECK ADD CONSTRAINT [FK_PlantHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_PlantUtilityEnergyProperties_LastModifiedByUserId' AND parent_object_id = OBJECT_ID(N'[TCD].[PlantUtilityEnergyProperties]'))
BEGIN
ALTER TABLE [TCD].[PlantUtilityEnergyProperties] WITH CHECK ADD CONSTRAINT [FK_PlantUtilityEnergyProperties_LastModifiedByUserId] FOREIGN KEY([LastModifiedByUserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_PlantUtilityEnergyPropertiesHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[PlantUtilityEnergyPropertiesHistory]'))
BEGIN
ALTER TABLE [TCD].[PlantUtilityEnergyPropertiesHistory] WITH CHECK ADD CONSTRAINT [FK_PlantUtilityEnergyPropertiesHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_PlantUtilityFactor_LastModifiedByUserId' AND parent_object_id = OBJECT_ID(N'[TCD].[PlantUtilityFactor]'))
BEGIN
ALTER TABLE [TCD].[PlantUtilityFactor] WITH CHECK ADD CONSTRAINT [FK_PlantUtilityFactor_LastModifiedByUserId] FOREIGN KEY([LastModifiedByUserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_PlantUtilityFactorHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[PlantUtilityFactorHistory]'))
BEGIN
ALTER TABLE [TCD].[PlantUtilityFactorHistory] WITH CHECK ADD CONSTRAINT [FK_PlantUtilityFactorHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TCD.PortletMaster_Report' AND parent_object_id = OBJECT_ID(N'[TCD].[PortletMaster]'))
BEGIN
ALTER TABLE [TCD].[PortletMaster] WITH CHECK ADD CONSTRAINT [FK_TCD.PortletMaster_Report] FOREIGN KEY([ReportId]) REFERENCES [TCD].[Report] ([ReportId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ProductdataMapping_LastModifiedByUserId' AND parent_object_id = OBJECT_ID(N'[TCD].[ProductdataMapping]'))
BEGIN
ALTER TABLE [TCD].[ProductdataMapping] WITH CHECK ADD CONSTRAINT [FK_ProductdataMapping_LastModifiedByUserId] FOREIGN KEY([LastModifiedByUserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ProductDataMappingHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[ProductDataMappingHistory]'))
BEGIN
ALTER TABLE [TCD].[ProductDataMappingHistory] WITH CHECK ADD CONSTRAINT [FK_ProductDataMappingHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ProductMaster_ProductCategory' AND parent_object_id = OBJECT_ID(N'[TCD].[ProductMaster]'))
BEGIN
ALTER TABLE [TCD].[ProductMaster] WITH CHECK ADD CONSTRAINT [FK_ProductMaster_ProductCategory] FOREIGN KEY([ProductCategoryId]) REFERENCES [TCD].[ProductCategory] ([CategoryId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ProgramMaster_LastModifiedByUserId' AND parent_object_id = OBJECT_ID(N'[TCD].[ProgramMaster]'))
BEGIN
ALTER TABLE [TCD].[ProgramMaster] WITH CHECK ADD CONSTRAINT [FK_ProgramMaster_LastModifiedByUserId] FOREIGN KEY([LastModifiedByUserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ProgramMaster_PlantProgram' AND parent_object_id = OBJECT_ID(N'[TCD].[ProgramMaster]'))
BEGIN
ALTER TABLE [TCD].[ProgramMaster] WITH CHECK ADD CONSTRAINT [FK_ProgramMaster_PlantProgram] FOREIGN KEY([PlantProgramId]) REFERENCES [TCD].[PlantChainProgram] ([PlantProgramId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ProgramMasterHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[ProgramMasterHistory]'))
BEGIN
ALTER TABLE [TCD].[ProgramMasterHistory] WITH CHECK ADD CONSTRAINT [FK_ProgramMasterHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_RedFlag_MeterId_Meter_MeterId' AND parent_object_id = OBJECT_ID(N'[TCD].[RedFlag]'))
BEGIN
ALTER TABLE [TCD].[RedFlag] WITH CHECK ADD CONSTRAINT [FK_RedFlag_MeterId_Meter_MeterId] FOREIGN KEY([MeterId]) REFERENCES [TCD].[Meter] ([MeterId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_RedFlag_ProductId_ProductMaster_ProductId' AND parent_object_id = OBJECT_ID(N'[TCD].[RedFlag]'))
BEGIN
ALTER TABLE [TCD].[RedFlag] WITH CHECK ADD CONSTRAINT [FK_RedFlag_ProductId_ProductMaster_ProductId] FOREIGN KEY([ProductId]) REFERENCES [TCD].[ProductMaster] ([ProductId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_RedFlag_RedFlagCategoryId_RedFlagCategory_RedFlagCategoryId' AND parent_object_id = OBJECT_ID(N'[TCD].[RedFlag]'))
BEGIN
ALTER TABLE [TCD].[RedFlag] WITH CHECK ADD CONSTRAINT [FK_RedFlag_RedFlagCategoryId_RedFlagCategory_RedFlagCategoryId] FOREIGN KEY([RedFlagCategoryId]) REFERENCES [TCD].[RedFlagCategory] ([RedFlagCategoryID]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_RedFlag_SensorId_EAN_Sensor_SensorId_EAN' AND parent_object_id = OBJECT_ID(N'[TCD].[RedFlag]'))
BEGIN
ALTER TABLE [TCD].[RedFlag] WITH CHECK ADD CONSTRAINT [FK_RedFlag_SensorId_EAN_Sensor_SensorId_EAN] FOREIGN KEY([SensorId], [EcolabAccountNumber]) REFERENCES [TCD].[Sensor] ([SensorId], [EcolabAccountNumber]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_RedFlagItemList_CategoryId_RedFlagCategory_RedFlagCategoryID' AND parent_object_id = OBJECT_ID(N'[TCD].[RedFlagItemList]'))
BEGIN
ALTER TABLE [TCD].[RedFlagItemList] WITH CHECK ADD CONSTRAINT [FK_RedFlagItemList_CategoryId_RedFlagCategory_RedFlagCategoryID] FOREIGN KEY([CategoryId]) REFERENCES [TCD].[RedFlagCategory] ([RedFlagCategoryID]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_DailyData_Plant' AND parent_object_id = OBJECT_ID(N'[TCD].[ReportDailyData]'))
BEGIN
ALTER TABLE [TCD].[ReportDailyData] WITH CHECK ADD CONSTRAINT [FK_DailyData_Plant] FOREIGN KEY([BatchId]) REFERENCES [TCD].[BatchData] ([BatchId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ResourceKeyPageMapping_Key_ResourceKeyMaster_Key' AND parent_object_id = OBJECT_ID(N'[TCD].[ResourceKeyPageMapping]'))
BEGIN
ALTER TABLE [TCD].[ResourceKeyPageMapping] WITH CHECK ADD CONSTRAINT [FK_ResourceKeyPageMapping_Key_ResourceKeyMaster_Key] FOREIGN KEY([KeyName]) REFERENCES [TCD].[ResourceKeyMaster] ([KeyName]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ResourceKeyValue_Key_ResourceKeyMaster_Key' AND parent_object_id = OBJECT_ID(N'[TCD].[ResourceKeyValue]'))
BEGIN
ALTER TABLE [TCD].[ResourceKeyValue] WITH CHECK ADD CONSTRAINT [FK_ResourceKeyValue_Key_ResourceKeyMaster_Key] FOREIGN KEY([KeyName]) REFERENCES [TCD].[ResourceKeyMaster] ([KeyName]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_RewashData_Plant' AND parent_object_id = OBJECT_ID(N'[TCD].[RewashData]'))
BEGIN
ALTER TABLE [TCD].[RewashData] WITH CHECK ADD CONSTRAINT [FK_RewashData_Plant] FOREIGN KEY([EcolabAccountNumber]) REFERENCES [TCD].[Plant] ([EcolabAccountNumber]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_RewashData_ProgramMaster' AND parent_object_id = OBJECT_ID(N'[TCD].[RewashData]'))
BEGIN
ALTER TABLE [TCD].[RewashData] WITH CHECK ADD CONSTRAINT [FK_RewashData_ProgramMaster] FOREIGN KEY([ProgramId]) REFERENCES [TCD].[ProgramMaster] ([ProgramId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Sensor_LastModifiedByUserId' AND parent_object_id = OBJECT_ID(N'[TCD].[Sensor]'))
BEGIN
ALTER TABLE [TCD].[Sensor] WITH CHECK ADD CONSTRAINT [FK_Sensor_LastModifiedByUserId] FOREIGN KEY([LastModifiedByUserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Sensor_Plant' AND parent_object_id = OBJECT_ID(N'[TCD].[Sensor]'))
BEGIN
ALTER TABLE [TCD].[Sensor] WITH CHECK ADD CONSTRAINT [FK_Sensor_Plant] FOREIGN KEY([EcolabAccountNumber]) REFERENCES [TCD].[Plant] ([EcolabAccountNumber]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_SensorHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[SensorHistory]'))
BEGIN
ALTER TABLE [TCD].[SensorHistory] WITH CHECK ADD CONSTRAINT [FK_SensorHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Shift_LastModifiedByUserId' AND parent_object_id = OBJECT_ID(N'[TCD].[Shift]'))
BEGIN
ALTER TABLE [TCD].[Shift] WITH CHECK ADD CONSTRAINT [FK_Shift_LastModifiedByUserId] FOREIGN KEY([LastModifiedByUserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ShiftBreakData_WeekDay' AND parent_object_id = OBJECT_ID(N'[TCD].[ShiftBreakData]'))
BEGIN
ALTER TABLE [TCD].[ShiftBreakData] WITH CHECK ADD CONSTRAINT [FK_ShiftBreakData_WeekDay] FOREIGN KEY([DayId]) REFERENCES [TCD].[WeekDay] ([DayId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ShiftBreakDataHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[ShiftBreakDataHistory]'))
BEGIN
ALTER TABLE [TCD].[ShiftBreakDataHistory] WITH CHECK ADD CONSTRAINT [FK_ShiftBreakDataHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ShiftData_WeekDay' AND parent_object_id = OBJECT_ID(N'[TCD].[ShiftData]'))
BEGIN
ALTER TABLE [TCD].[ShiftData] WITH CHECK ADD CONSTRAINT [FK_ShiftData_WeekDay] FOREIGN KEY([DayId]) REFERENCES [TCD].[WeekDay] ([DayId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ShiftDataHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[ShiftDataHistory]'))
BEGIN
ALTER TABLE [TCD].[ShiftDataHistory] WITH CHECK ADD CONSTRAINT [FK_ShiftDataHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ShiftHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[ShiftHistory]'))
BEGIN
ALTER TABLE [TCD].[ShiftHistory] WITH CHECK ADD CONSTRAINT [FK_ShiftHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ShiftLaborData_LastModifiedByUserId' AND parent_object_id = OBJECT_ID(N'[TCD].[ShiftLaborData]'))
BEGIN
ALTER TABLE [TCD].[ShiftLaborData] WITH CHECK ADD CONSTRAINT [FK_ShiftLaborData_LastModifiedByUserId] FOREIGN KEY([LastModifiedByUserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ShiftLaborDataHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[ShiftLaborDataHistory]'))
BEGIN
ALTER TABLE [TCD].[ShiftLaborDataHistory] WITH CHECK ADD CONSTRAINT [FK_ShiftLaborDataHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_SolumixReading_Plant' AND parent_object_id = OBJECT_ID(N'[TCD].[SolumixReading]'))
BEGIN
ALTER TABLE [TCD].[SolumixReading] WITH CHECK ADD CONSTRAINT [FK_SolumixReading_Plant] FOREIGN KEY([EcoalabAccountNumber]) REFERENCES [TCD].[Plant] ([EcolabAccountNumber]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TankReading_Plant' AND parent_object_id = OBJECT_ID(N'[TCD].[TankReading]'))
BEGIN
ALTER TABLE [TCD].[TankReading] WITH CHECK ADD CONSTRAINT [FK_TankReading_Plant] FOREIGN KEY([EcoalabAccountNumber]) REFERENCES [TCD].[Plant] ([EcolabAccountNumber]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TankSetup_Plant' AND parent_object_id = OBJECT_ID(N'[TCD].[TankSetup]'))
BEGIN
ALTER TABLE [TCD].[TankSetup] WITH CHECK ADD CONSTRAINT [FK_TankSetup_Plant] FOREIGN KEY([EcoalabAccountNumber]) REFERENCES [TCD].[Plant] ([EcolabAccountNumber]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TankSetupHistory_OperationId' AND parent_object_id = OBJECT_ID(N'[TCD].[TankSetupHistory]'))
BEGIN
ALTER TABLE [TCD].[TankSetupHistory] WITH CHECK ADD CONSTRAINT [FK_TankSetupHistory_OperationId] FOREIGN KEY([OperationId]) REFERENCES [TCD].[AuditOperation] ([OperationId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TunnelAnalogControlLevel_TunnelAnalogControlLevelTypeID_TunnelAnalogControlLevelType_TunnelAnalogControlLevelTypeID' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelAnalogControlLevel]'))
BEGIN
ALTER TABLE [TCD].[TunnelAnalogControlLevel] WITH CHECK ADD CONSTRAINT [FK_TunnelAnalogControlLevel_TunnelAnalogControlLevelTypeID_TunnelAnalogControlLevelType_TunnelAnalogControlLevelTypeID] FOREIGN KEY([TunnelAnalogControlLevelTypeID]) REFERENCES [TCD].[TunnelAnalogControlLevelType] ([TunnelAnalogControlLevelTypeID]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TunnelCompartment_PlantId' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelCompartment]'))
BEGIN
ALTER TABLE [TCD].[TunnelCompartment] WITH CHECK ADD CONSTRAINT [FK_TunnelCompartment_PlantId] FOREIGN KEY([EcoLabAccountNumber]) REFERENCES [TCD].[Plant] ([EcolabAccountNumber]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TunnelCompartment_UserId' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelCompartment]'))
BEGIN
ALTER TABLE [TCD].[TunnelCompartment] WITH CHECK ADD CONSTRAINT [FK_TunnelCompartment_UserId] FOREIGN KEY([LastModifiedByUserId]) REFERENCES [TCD].[UserMaster] ([UserId]) 
END
GO
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TunnelCompartment_WasherId' AND parent_object_id = OBJECT_ID(N'[TCD].[TunnelCompartment]'))
BEGIN
ALTER TABLE [TCD].[TunnelCompartment] WITH CHECK ADD CONSTRAINT [FK_TunnelCompartment_WasherId] FOREIGN KEY([WasherId]) REFERENCES [TCD].[Washer] ([WasherId]) 
END
GO
--- END - Foreign Key Creation

--- START - Index Key Creation
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[AlarmData]') AND name = N'IX_AlarmData_ID')
BEGIN
CREATE CLUSTERED INDEX [IX_AlarmData_ID] ON [TCD].[AlarmData](Id ASC) WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[BatchCustomerData]') AND name = N'ix_batchcustomerdata_batchid')
BEGIN
CREATE NONCLUSTERED INDEX [ix_batchcustomerdata_batchid] ON [TCD].[BatchCustomerData](BatchId ASC) INCLUDE (CustomerId, PiecesCount)WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[BatchCustomerData]') AND name = N'NonClusteredIndex-PiecesCount')
BEGIN
CREATE NONCLUSTERED INDEX [NonClusteredIndex-PiecesCount] ON [TCD].[BatchCustomerData](PiecesCount ASC) WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[BatchData]') AND name = N'ChemicalInventory_Batch')
BEGIN
CREATE NONCLUSTERED INDEX [ChemicalInventory_Batch] ON [TCD].[BatchData](StartDate ASC) INCLUDE (BatchId)WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[BatchData]') AND name = N'IX_BatchData_EndDate')
BEGIN
CREATE NONCLUSTERED INDEX [IX_BatchData_EndDate] ON [TCD].[BatchData](EndDate ASC) WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[BatchData]') AND name = N'IX_BatchData_GroupID_MachineID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_BatchData_GroupID_MachineID] ON [TCD].[BatchData](GroupId ASC, MachineId ASC) INCLUDE (EcolabWasherId, StartDate, ProgramMasterId, TargetTurnTime)WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[BatchData]') AND name = N'IX_BatchData_MachineID_ControllerBatchID_StartDate')
BEGIN
CREATE NONCLUSTERED INDEX [IX_BatchData_MachineID_ControllerBatchID_StartDate] ON [TCD].[BatchData](MachineId ASC, ControllerBatchId ASC, StartDate ASC) INCLUDE (BatchId)WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[BatchData]') AND name = N'IX_BatchData_MachineInternalId_GroupId')
BEGIN
CREATE NONCLUSTERED INDEX [IX_BatchData_MachineInternalId_GroupId] ON [TCD].[BatchData](MachineInternalId ASC, GroupId ASC) WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[BatchData]') AND name = N'IX_BatchData_ProgramMasterID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_BatchData_ProgramMasterID] ON [TCD].[BatchData](ProgramMasterId ASC) INCLUDE (BatchId, EcolabWasherId, GroupId, StartDate, EndDate, MachineId, TargetTurnTime)WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[BatchData]') AND name = N'IX_BatchData_ShiftID_Actual_Std_Weight')
BEGIN
CREATE NONCLUSTERED INDEX [IX_BatchData_ShiftID_Actual_Std_Weight] ON [TCD].[BatchData](ShiftId ASC, ActualWeight ASC, StandardWeight ASC) INCLUDE (BatchId, ControllerBatchId, EcolabWasherId, GroupId, MachineInternalId, PlantWasherNumber, StartDate, EndDate, ProgramNumber, ProgramMasterId, MachineId, CurrencyCode, LastSyncTime, ManualInputWeight, LastModifiedByUserId, PartitionOn, EndDateFormula, TargetTurnTime)WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[BatchData]') AND name = N'IX_BatchData_ShiftId_EndDate')
BEGIN
CREATE NONCLUSTERED INDEX [IX_BatchData_ShiftId_EndDate] ON [TCD].[BatchData](MachineId ASC, ShiftId ASC, EndDate ASC) INCLUDE (BatchId, EcolabWasherId, StartDate, ProgramNumber, ProgramMasterId, ActualWeight, StandardWeight, ManualInputWeight, TargetTurnTime, EcolabTextileCategoryId, ChainTextileCategoryId, PlantProgramId)WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[BatchData]') AND name = N'NonClusteredIndex-ActualWeight')
BEGIN
CREATE NONCLUSTERED INDEX [NonClusteredIndex-ActualWeight] ON [TCD].[BatchData](ActualWeight ASC) WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[BatchData]') AND name = N'NonClusteredIndex-StandardWeight')
BEGIN
CREATE NONCLUSTERED INDEX [NonClusteredIndex-StandardWeight] ON [TCD].[BatchData](StandardWeight ASC) WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[BatchEnergyUsageData]') AND name = N'NonClusteredIndex-ActualQuantity')
BEGIN
CREATE NONCLUSTERED INDEX [NonClusteredIndex-ActualQuantity] ON [TCD].[BatchEnergyUsageData](ActualQuantity ASC) WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[BatchEnergyUsageData]') AND name = N'NonClusteredIndex-Price')
BEGIN
CREATE NONCLUSTERED INDEX [NonClusteredIndex-Price] ON [TCD].[BatchEnergyUsageData](Price ASC) WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[BatchEnergyUsageData]') AND name = N'NonClusteredIndex-StandardQuantity')
BEGIN
CREATE NONCLUSTERED INDEX [NonClusteredIndex-StandardQuantity] ON [TCD].[BatchEnergyUsageData](StandardQuantity ASC) WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[BatchParameters]') AND name = N'IX_BatchParameters_ParameterID_BatchID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_BatchParameters_ParameterID_BatchID] ON [TCD].[BatchParameters](ParameterId ASC) INCLUDE (BatchId)WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[BatchProductData]') AND name = N'ChemicalInventory_BatchId')
BEGIN
CREATE NONCLUSTERED INDEX [ChemicalInventory_BatchId] ON [TCD].[BatchProductData](BatchId ASC) INCLUDE (ProductId)WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[BatchProductData]') AND name = N'IX_BatchProductData_BatchID_ActQty_StdQty_Price')
BEGIN
CREATE NONCLUSTERED INDEX [IX_BatchProductData_BatchID_ActQty_StdQty_Price] ON [TCD].[BatchProductData](BatchId ASC) INCLUDE (ProductId, ActualQuantity, StandardQuantity, Price)WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[BatchProductData]') AND name = N'NonClusteredIndex-ActualQuantity')
BEGIN
CREATE NONCLUSTERED INDEX [NonClusteredIndex-ActualQuantity] ON [TCD].[BatchProductData](ActualQuantity ASC) WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[BatchProductData]') AND name = N'NonClusteredIndex-Price')
BEGIN
CREATE NONCLUSTERED INDEX [NonClusteredIndex-Price] ON [TCD].[BatchProductData](Price ASC) WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[BatchProductData]') AND name = N'NonClusteredIndex-StandardQuantity')
BEGIN
CREATE NONCLUSTERED INDEX [NonClusteredIndex-StandardQuantity] ON [TCD].[BatchProductData](StandardQuantity ASC) WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[BatchStepWaterUsageData]') AND name = N'NonClusteredIndex-ActualQuantity')
BEGIN
CREATE NONCLUSTERED INDEX [NonClusteredIndex-ActualQuantity] ON [TCD].[BatchStepWaterUsageData](ActualQuantity ASC) WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[BatchStepWaterUsageData]') AND name = N'NonClusteredIndex-Price')
BEGIN
CREATE NONCLUSTERED INDEX [NonClusteredIndex-Price] ON [TCD].[BatchStepWaterUsageData](Price ASC) WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[BatchStepWaterUsageData]') AND name = N'NonClusteredIndex-StandardQuantity')
BEGIN
CREATE NONCLUSTERED INDEX [NonClusteredIndex-StandardQuantity] ON [TCD].[BatchStepWaterUsageData](StandardQuantity ASC) WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[ChemicalInventory]') AND name = N'IX_ChemicalInventory_ID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_ChemicalInventory_ID] ON [TCD].[ChemicalInventory](Id ASC) INCLUDE (UnitSize, ClosingQuantity, ProductId)WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[ChemicalInventory]') AND name = N'IX_ChemicalInventory_ProductID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_ChemicalInventory_ProductID] ON [TCD].[ChemicalInventory](ProductId ASC) INCLUDE (InventoryDate, UsedQuantity)WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[ConduitControllerHistory]') AND name = N'IX_ConduitControllerHistory_ControllerID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_ConduitControllerHistory_ControllerID] ON [TCD].[ConduitControllerHistory](ControllerId ASC) INCLUDE (OperationTimestamp)WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[ProductionShiftData]') AND name = N'IX_ProductionShiftData_ShiftID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_ProductionShiftData_ShiftID] ON [TCD].[ProductionShiftData](ShiftId ASC) INCLUDE (StartDateTime, ShiftName, EndDateTime)WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[ProductionShiftData]') AND name = N'IX_ProductionShiftData_ShiftID_StartDateTime')
BEGIN
CREATE NONCLUSTERED INDEX [IX_ProductionShiftData_ShiftID_StartDateTime] ON [TCD].[ProductionShiftData](StartDateTime ASC, ShiftId ASC) WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[ProductionShiftData]') AND name = N'IX_ProductionShiftData_StartDateTime')
BEGIN
CREATE NONCLUSTERED INDEX [IX_ProductionShiftData_StartDateTime] ON [TCD].[ProductionShiftData](StartDateTime ASC) INCLUDE (ShiftId)WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[ShiftChemicalDataRollup]') AND name = N'ChemicalInventory_ProductId')
BEGIN
CREATE NONCLUSTERED INDEX [ChemicalInventory_ProductId] ON [TCD].[ShiftChemicalDataRollup](ProductId ASC) INCLUDE (ShiftId, ActualCost, NoOfLoads)WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[ShiftChemicalDataRollup]') AND name = N'ChemicalInventory_ShiftId')
BEGIN
CREATE NONCLUSTERED INDEX [ChemicalInventory_ShiftId] ON [TCD].[ShiftChemicalDataRollup](ShiftId ASC) INCLUDE (ProductId, ActualCost, NoOfLoads)WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[ShiftChemicalDataRollup]') AND name = N'ChemicalInventoryShift_productId')
BEGIN
CREATE NONCLUSTERED INDEX [ChemicalInventoryShift_productId] ON [TCD].[ShiftChemicalDataRollup](ProductId ASC) INCLUDE (ShiftId, ActualConsumption)WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[ShiftData]') AND name = N'IX_ShiftData_DayId_Endtime_Is_Deleted')
BEGIN
CREATE NONCLUSTERED INDEX [IX_ShiftData_DayId_Endtime_Is_Deleted] ON [TCD].[ShiftData](DayId ASC, EndTime ASC, Is_Deleted ASC) INCLUDE (ShiftId, StartTime)WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[ShiftProductionDataRollup]') AND name = N'_dta_index_ShiftProductionDataRollup_9_432720594__K1_2_4_5_6_7_8_9_10_11_12_18_19')
BEGIN
CREATE NONCLUSTERED INDEX [_dta_index_ShiftProductionDataRollup_9_432720594__K1_2_4_5_6_7_8_9_10_11_12_18_19] ON [TCD].[ShiftProductionDataRollup](ShiftId ASC) INCLUDE (MachineId, EcolabWasherId, NoOfLoads, ActualProduction, StandardProduction, LoadEfficiency, TimeEfficiency, PlantTargetProd, ActualRunTime, TargetRunTime, ActualTurnTime, TargetTurnTime)WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[ShiftProductionDataRollup]') AND name = N'_dta_index_ShiftProductionDataRollup_9_432720594__K1_K3_2_6')
BEGIN
CREATE NONCLUSTERED INDEX [_dta_index_ShiftProductionDataRollup_9_432720594__K1_K3_2_6] ON [TCD].[ShiftProductionDataRollup](ShiftId ASC, ProgramMasterId ASC) INCLUDE (MachineId, ActualProduction)WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[ShiftProductionDataRollup]') AND name = N'IX_ShiftProductionDataRollup_ShiftID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_ShiftProductionDataRollup_ShiftID] ON [TCD].[ShiftProductionDataRollup](ShiftId ASC) WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[ShiftProductionDataRollup]') AND name = N'NonClusteredIndex-20150318-184142')
BEGIN
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20150318-184142] ON [TCD].[ShiftProductionDataRollup](ActualProduction ASC) WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[ShiftProductionDataRollup]') AND name = N'NonClusteredIndex-20150318-184412')
BEGIN
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20150318-184412] ON [TCD].[ShiftProductionDataRollup](StandardProduction ASC) WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[ShiftProductionDataRollup]') AND name = N'NonClusteredIndex-20150318-184710')
BEGIN
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20150318-184710] ON [TCD].[ShiftProductionDataRollup](ActualRunTime ASC, TargetRunTime ASC) WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[ShiftProductionDataRollup]') AND name = N'NonClusteredIndex-20150318-184742')
BEGIN
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20150318-184742] ON [TCD].[ShiftProductionDataRollup](MachineId ASC, ProgramMasterId ASC) INCLUDE (EcolabTextileId, ChainTextileId, ChainProgaramId, CustomerId)WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[WasherDosingProductMapping]') AND name = N'IX_WasherDosingProductMapping_WasherDosingSetupId_InjectionNumber')
BEGIN
CREATE NONCLUSTERED INDEX [IX_WasherDosingProductMapping_WasherDosingSetupId_InjectionNumber] ON [TCD].[WasherDosingProductMapping](WasherDosingSetupId ASC, InjectionNumber ASC) INCLUDE (ProductId, Quantity)WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[WasherDosingProductMapping]') AND name = N'IX_WasherDosingProductMapping_WasherDosingSetupId_ProductID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_WasherDosingProductMapping_WasherDosingSetupId_ProductID] ON [TCD].[WasherDosingProductMapping](WasherDosingSetupId ASC, ProductId ASC) INCLUDE (InjectionNumber)WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[WasherDosingSetup]') AND name = N'IX_WasherDosingSetup_WasherProgramSetupId')
BEGIN
CREATE NONCLUSTERED INDEX [IX_WasherDosingSetup_WasherProgramSetupId] ON [TCD].[WasherDosingSetup](WasherProgramSetupId ASC) INCLUDE (WasherDosingSetupId)WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[WasherProgramSetup]') AND name = N'IX_WasherProgramSetup_ProgramNumber')
BEGIN
CREATE NONCLUSTERED INDEX [IX_WasherProgramSetup_ProgramNumber] ON [TCD].[WasherProgramSetup](ProgramNumber ASC) INCLUDE (WasherGroupId, ProgramId, NominalLoad, ExtraTime)WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[WasherReading]') AND name = N'IX_WasherReading_ParameterId_ParameterValue')
BEGIN
CREATE NONCLUSTERED INDEX [IX_WasherReading_ParameterId_ParameterValue] ON [TCD].[WasherReading](ParameterId ASC, ParameterValue ASC) INCLUDE (WasherId, DateTimeStamp)WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[WasherReading]') AND name = N'IX_WasherReading_WasherID_DateTimeStamp')
BEGIN
CREATE NONCLUSTERED INDEX [IX_WasherReading_WasherID_DateTimeStamp] ON [TCD].[WasherReading](WasherId ASC, DateTimeStamp ASC) WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
IF  NOT EXISTS (SELECT * FROM sys.indexes  WHERE object_id = OBJECT_ID(N'[TCD].[WasherReading]') AND name = N'IX_WasherReading_WasherID_ParameterID_DateTimeStamp')
BEGIN
CREATE NONCLUSTERED INDEX [IX_WasherReading_WasherID_ParameterID_DateTimeStamp] ON [TCD].[WasherReading](WasherId ASC, ParameterId ASC, DateTimeStamp ASC) INCLUDE (ParameterValue)WITH (PAD_INDEX = OFF, ALLOW_PAGE_LOCKS = ON, ALLOW_ROW_LOCKS = ON, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, SORT_IN_TEMPDB = OFF, FILLFACTOR =80) ON [PRIMARY];
END
GO
 
--- END - Index Key Creation
IF EXISTS(SELECT
                  1 FROM TCD.ResourceKeyValue AS rkv WHERE rkv.KeyName = 'EURO')
    BEGIN
        UPDATE tcd.ResourceKeyValue SET
                TCD.ResourceKeyValue.[Value] = N'#currency#'
            WHERE
                tcd.ResourceKeyValue.KeyName = 'EURO';
    END;
GO