﻿IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[PlantExtension]') AND type in (N'U'))
BEGIN
CREATE TABLE [TCD].[PlantExtension]
(
	[PlantId] INT NOT NULL PRIMARY KEY, 
    [MigrationStep] INT NULL, 
    [LastMigratedBatch] INT NULL, 
    [LastMigratedBatchTime] DATETIME NULL
)
END
GO
IF NOT EXISTS (SELECT 1 FROM dbo.sysobjects WHERE NAME = 'DF_PlantExtension_MigrationStep' AND type = 'D')
BEGIN
ALTER TABLE [TCD].[PlantExtension] ADD  CONSTRAINT [DF_PlantExtension_MigrationStep]  DEFAULT (1) for MigrationStep
END
GO

IF EXISTS(select [name] from sys.objects where type = 'D' and parent_object_id = object_id('TCD.Plant') AND sys.objects.name LIKE '%Migration%')
BEGIN
DECLARE @Name NVARCHAR(100)
select @Name = [name] from sys.objects where type = 'D' and parent_object_id = object_id('TCD.Plant') AND sys.objects.name LIKE '%Migration%'
exec ('alter table TCD.Plant drop constraint ' + @name)
END
GO

IF EXISTS(SELECT 1 FROM sys.columns 
            WHERE Name = N'MigrationStep' AND Object_ID = Object_ID(N'[TCD].[Plant]'))
BEGIN
DECLARE @Name NVARCHAR(100)
select @Name = [name] from sys.objects where type = 'D' and parent_object_id = object_id('TCD.Plant') AND sys.objects.name LIKE '%Migration%'
ALTER TABLE TCD.Plant DROP COLUMN MigrationStep
END
GO

IF EXISTS(SELECT 1 FROM sys.columns 
            WHERE Name = N'LastMigratedBatch' AND Object_ID = Object_ID(N'[TCD].[Plant]'))
BEGIN
ALTER TABLE TCD.Plant DROP COLUMN LastMigratedBatch
END
GO

IF EXISTS(SELECT 1 FROM sys.columns 
            WHERE Name = N'LastMigratedBatchTime' AND Object_ID = Object_ID(N'[TCD].[Plant]'))
BEGIN
ALTER TABLE TCD.Plant DROP COLUMN LastMigratedBatchTime
END
GO




IF OBJECT_ID('[TCD].[FormulaSegments]') is null
BEGIN
	
CREATE TABLE TCD.FormulaSegments 
(
FormulaSegmentID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_FormulaSegments_FormulaSegmentID PRIMARY KEY,
 SegmentName	    VARCHAR(128) NOT NULL,
 LastModifiedTime   DATETIME NOT NULL,
 LastModifiedByUserId INT NOT NULL,
 Is_Deleted	BIT NOT NULL CONSTRAINT DF_FormulaSegments_Is_Deleted DEFAULT(0)
 )
 
	
END
GO

IF NOT EXISTS(SELECT * FROM sys.columns WHERE  object_id = OBJECT_ID(N'TCD.PlantChainProgram') AND name = 'ChainTextileCategoryId')
BEGIN
	ALTER TABLE TCD.PlantChainProgram
	ADD ChainTextileCategoryId INT NULL
END

GO

IF NOT EXISTS(SELECT * FROM sys.columns WHERE  object_id = OBJECT_ID(N'TCD.PlantChainProgram') AND name = 'EcolabTextileCategoryId')
BEGIN
	ALTER TABLE TCD.PlantChainProgram
	ADD EcolabTextileCategoryId INT NULL
END

GO
IF NOT EXISTS(SELECT * FROM sys.columns WHERE  object_id = OBJECT_ID(N'TCD.PlantChainProgram') AND name = 'FormulaSegmentId')
BEGIN
	ALTER TABLE TCD.PlantChainProgram
	ADD FormulaSegmentId INT NULL
END

GO
IF NOT EXISTS(SELECT * FROM sys.columns WHERE  object_id = OBJECT_ID(N'TCD.PlantChainProgram') AND name = 'LastModifiedTime')
BEGIN
	ALTER TABLE TCD.PlantChainProgram
	ADD LastModifiedTime datetime NOT NULL CONSTRAINT df_PlantChainProgram_LastModifiedTime DEFAULT getdate()
END

GO
IF NOT EXISTS(SELECT * FROM sys.columns WHERE  object_id = OBJECT_ID(N'TCD.PlantChainProgram') AND name = 'LastModifiedByUserId')
BEGIN
	ALTER TABLE TCD.PlantChainProgram
	ADD LastModifiedByUserId INT NULL
END

GO
IF NOT EXISTS(SELECT * FROM sys.columns WHERE  object_id = OBJECT_ID(N'TCD.PlantChainProgram') AND name = 'Is_Deleted')
BEGIN
	ALTER TABLE TCD.PlantChainProgram
	ADD Is_Deleted bit NOT NULL CONSTRAINT df_PlantChainProgram_Is_Deleted DEFAULT (0)
END

GO


IF NOT EXISTS(SELECT * FROM sys.columns WHERE  object_id = OBJECT_ID(N'TCD.ProgramMaster') AND name = 'FormulaSegmentId')
BEGIN
	ALTER TABLE TCD.ProgramMaster
	ADD FormulaSegmentId INT NULL
END

GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[TCD].[FK_PlantChainProgram_ChainTextileCategoryId]') AND parent_object_id = OBJECT_ID(N'[TCD].[PlantChainProgram]'))
ALTER TABLE [TCD].[PlantChainProgram]  WITH CHECK ADD  CONSTRAINT [FK_PlantChainProgram_ChainTextileCategoryId] FOREIGN KEY([ChainTextileCategoryId])
REFERENCES [TCD].[ChainTextileCategory] ([TextileId])
GO


IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[TCD].[FK_PlantChainProgram_EcolabTextileCategoryId]') AND parent_object_id = OBJECT_ID(N'[TCD].[PlantChainProgram]'))
ALTER TABLE [TCD].[PlantChainProgram]  WITH CHECK ADD  CONSTRAINT [FK_PlantChainProgram_EcolabTextileCategoryId] FOREIGN KEY([EcolabTextileCategoryId])
REFERENCES [TCD].[EcolabTextileCategory] ([TextileId])
GO


IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[TCD].[FK_PlantChainProgram_FormulaSegmentId]') AND parent_object_id = OBJECT_ID(N'[TCD].[PlantChainProgram]'))
ALTER TABLE [TCD].[PlantChainProgram]  WITH CHECK ADD  CONSTRAINT [FK_PlantChainProgram_FormulaSegmentId] FOREIGN KEY([FormulaSegmentId])
REFERENCES [TCD].[FormulaSegments] ([FormulaSegmentId])
GO


IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE NAME = 'DF_FormulaSegments_LastModifiedTime' AND type = 'D')
BEGIN
ALTER TABLE [TCD].[FormulaSegments] ADD  CONSTRAINT [DF_FormulaSegments_LastModifiedTime]  DEFAULT (getutcdate()) for LastModifiedTime
END
go

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[TCD].[FK_PlantChainProgram_FormulaSegmentId]') AND parent_object_id = OBJECT_ID(N'[TCD].[PlantChainProgram]'))
ALTER TABLE [TCD].[PlantChainProgram]  WITH CHECK ADD  CONSTRAINT [FK_PlantChainProgram_FormulaSegmentId] FOREIGN KEY([FormulaSegmentId])
REFERENCES [TCD].[FormulaSegments] ([FormulaSegmentId])
GO



IF EXISTS(SELECT
				  * FROM sys.views WHERE object_id = OBJECT_ID(N'[TCD].[Turntime]')
									 AND type = N'V')
	BEGIN
		DROP VIEW
				TCD.Turntime
	END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [TCD].[Turntime]
AS
       
        
WITH CTE_TurnTime  
AS (  
SELECT
     ROW_NUMBER() OVER(PARTITION BY BD.ECOLABWASHERID ORDER BY BD.STARTDATE) AS ROWNUMBER,  
     BD.ECOLABWASHERID,
     BD.BATCHID,
     STARTDATE,
     ENDDATE,
     BD.TARGETTURNTIME , 
     W.DEFAULTIDLETIME,
     BD.GROUPID,
    BD.MachineId
    FROM TCD.BATCHDATA AS BD WITH (NOLOCK)
     INNER JOIN TCD.WASHER AS W           ON BD.MachineId = W.WasherID  
                                                      AND isnull(BD.EcolabWasherId,0) = isnull(W.EcolabWasherId,0)  
     INNER JOIN TCD.WASHERGROUP AS WG     ON WG.WASHERGROUPID=BD.GROUPID  
                                                            AND W.ECOLABACCOUNTNUMBER = WG.ECOLABACCOUNTNUMBER  
     INNER JOIN TCD.MACHINESETUP AS MS    ON MS.GroupId = WG.WasherGroupId  
                                                            AND ms.WasherId = W.WasherId  
                                                            AND w.EcoLabAccountNumber = ms.EcoalabAccountNumber  
    WHERE BD.PROGRAMMASTERID <> 0
    AND WG.WASHERGROUPTYPEID=1
)  
   
SELECT CurBatch.BATCHID  
, CurBatch.ECOLABWASHERID  
,CurBatch.ENDDATE  
,nextBatch.STARTDATE 
, CurBatch.MachineId
, CASE  
      WHEN (DATEDIFF(SECOND,CurBatch.ENDDATE,ISNULL(nextBatch.STARTDATE, GETDATE())) <= 0 or DATEDIFF(second,CurBatch.ENDDATE,ISNULL(nextBatch.STARTDATE, GETDATE())) > (CurBatch. defaultidletime*60))  
      --OR DATEDIFF(hh,CurBatch.ENDDATE,ISNULL(nextBatch.STARTDATE, GETDATE())) > 2)  
      THEN nextBatch.TARGETTURNTIME  
      ELSE DATEDIFF(SECOND,CurBatch.ENDDATE, nextBatch.STARTDATE)  
      END AS ActualTurnTime  
FROM CTE_TurnTime CurBatch  
LEFT JOIN CTE_TurnTime nextBatch ON isnull(CurBatch.ECOLABWASHERID,0) = isnull(nextBatch.ECOLABWASHERID,0)
AND CurBatch.MachineId = nextBatch.MachineId
		  AND CurBatch.GROUPID = nextBatch.GROUPID  
AND CurBatch.ROWNUMBER + 1 = nextBatch.ROWNUMBER  
GO



IF NOT EXISTS(SELECT * FROM sys.columns WHERE  object_id = OBJECT_ID(N'TCD.PlantChainProgram') AND name = 'EcolabSaturationId')
BEGIN
	ALTER TABLE TCD.PlantChainProgram
	ADD EcolabSaturationId INT NULL
END


IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[TCD].[FK_PlantChainProgram_EcolabSaturationId]') AND parent_object_id = OBJECT_ID(N'[TCD].[PlantChainProgram]'))
ALTER TABLE [TCD].[PlantChainProgram]  WITH CHECK ADD  CONSTRAINT [FK_PlantChainProgram_EcolabSaturationId] FOREIGN KEY([EcolabSaturationId])
REFERENCES [TCD].[EcolabSaturation] ([EcolabSaturationId])
GO



IF  EXISTS(SELECT * FROM sys.columns WHERE  object_id = OBJECT_ID(N'TCD.ChainTextileCategory') AND name = 'EcolabSaturationId')
BEGIN
	ALTER TABLE TCD.ChainTextileCategory
	drop column  EcolabSaturationId 
END

IF NOT EXISTS (SELECT 
			1 
		FROM TCD.FIELD
		WHERE DefaultFieldTag = 'N7:132')
BEGIN
INSERT	INTO TCD.FIELD	(
		TypeId,
		Label,
		[Min],
		[Max],
		FieldGroupId,
		DataSourceId,
		IsMandatory,
		HelpText,
		HelpTextURL	,
		DataTypeId	,
		DataCategoryId	,
		CurrencyId	,
		DisplayOrder	,
		ResourceKey,
		DefaultValue	,
		IsEditable	,
		Name		,
		HasFieldTag	,
		DefaultFieldTag,
		ClassName
	)
	VALUES (
		10, 
		N'LFS Injection Classes', 
		N'0', 
		N'6',
		NULL, 
		NULL, 
		1,
		NULL,
		NULL,
		1,
		NULL,
		NULL,
		10,
		N'LFSInjection_Classes',
		N'6',
		1,
		NULL,
		N'TAG_MIC',
		N'N7:132',
		N'InjectionClasses'
	)
INSERT INTO tcd.FieldGroupFieldMapping (
		FieldGroupId,
		FieldId
	)
	VALUES (
		7,
		SCOPE_IDENTITY()
	)
INSERT	INTO TCD.FIELD	(
		TypeId,
		Label,
		[Min],
		[Max],
		FieldGroupId,
		DataSourceId,
		IsMandatory,
		HelpText,
		HelpTextURL	,
		DataTypeId	,
		DataCategoryId	,
		CurrencyId	,
		DisplayOrder	,
		ResourceKey,
		DefaultValue	,
		IsEditable	,
		Name		,
		HasFieldTag	,
		DefaultFieldTag,
		ClassName
	)
	VALUES (
		10, 
		N'LFS Injection Classes', 
		N'0', 
		N'6',
		NULL, 
		NULL, 
		1,
		NULL,
		NULL,
		1,
		NULL,
		NULL,
		10,
		N'LFSInjection_Classes',
		N'6',
		1,
		NULL,
		N'TAG_MIC',
		N'N7:132',
		N'InjectionClasses'
	)
INSERT INTO tcd.FieldGroupFieldMapping (
		FieldGroupId,
		FieldId
	)
	VALUES (
		8,
		SCOPE_IDENTITY()
	)
END
IF NOT EXISTS (SELECT 
			1 
		FROM TCD.FIELD
		WHERE DefaultFieldTag = 'L_MIC')
BEGIN
INSERT	INTO TCD.FIELD	(
		TypeId,
		Label,
		[Min],
		[Max],
		FieldGroupId,
		DataSourceId,
		IsMandatory,
		HelpText,
		HelpTextURL	,
		DataTypeId	,
		DataCategoryId	,
		CurrencyId	,
		DisplayOrder	,
		ResourceKey,
		DefaultValue	,
		IsEditable	,
		Name		,
		HasFieldTag	,
		DefaultFieldTag,
		ClassName
	)
	VALUES (
		10, 
		N'LFS Injection Classes', 
		N'0', 
		N'8',
		NULL, 
		NULL, 
		1,
		NULL,
		NULL,
		1,
		NULL,
		NULL,
		10,
		N'LFSInjection_Classes',
		N'8',
		1,
		NULL,
		N'TAG_MIC',
		N'L_MIC',
		N'InjectionClasses'
	)
INSERT INTO tcd.FieldGroupFieldMapping (
		FieldGroupId,
		FieldId
	)
	VALUES (
		17,
		SCOPE_IDENTITY()
	)
INSERT	INTO TCD.FIELD	(
		TypeId,
		Label,
		[Min],
		[Max],
		FieldGroupId,
		DataSourceId,
		IsMandatory,
		HelpText,
		HelpTextURL	,
		DataTypeId	,
		DataCategoryId	,
		CurrencyId	,
		DisplayOrder	,
		ResourceKey,
		DefaultValue	,
		IsEditable	,
		Name		,
		HasFieldTag	,
		DefaultFieldTag,
		ClassName
	)
	VALUES (
		10, 
		N'LFS Injection Classes', 
		N'0', 
		N'8',
		NULL, 
		NULL, 
		1,
		NULL,
		NULL,
		1,
		NULL,
		NULL,
		10,
		N'LFSInjection_Classes',
		N'8',
		1,
		NULL,
		N'TAG_MIC',
		N'L_MIC',
		N'InjectionClasses'
	)
INSERT INTO tcd.FieldGroupFieldMapping (
		FieldGroupId,
		FieldId
	)
	VALUES (
		18,
		SCOPE_IDENTITY()
	)
END
GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[UpdateConventional]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.UpdateConventional
	END
GO  
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*   
Purpose     : To update Conventional Washer details from the Washer setup UI - General tab  
  
History     :  
Oct. 2014  dfozdar@allianceglobalservice.com  initial version  
  
--sp_helptext usp_UpdateConventional  
  
*/  
  
CREATE PROCEDURE [TCD].[UpdateConventional]  
     @EcoLabAccountNumber     NVARCHAR(1000)  
    , @WasherId        INT  
    , @WasherGroupId       INT  
    , @NewWasherGroupId       int  = null  
    , @ConventionalName      NVARCHAR(50)  
    , @ModelId        INT      --(Washer)Model Id for Size  
    , @ControllerId       INT  
    , @LFSWasherNumber      TINYINT  
    , @PlantWasherNumber      SMALLINT  
    , @WasherMode        TINYINT  
    , @MaxLoad        SMALLINT  
    , @AWEActive        BIT  
    , @HoldSignal        BIT  
    , @HoldDelay        SMALLINT                 
    , @TargetTurnTime       SMALLINT  
    , @WaterFlushTime       SMALLINT  
    , @ProgramNumber       TINYINT     --EOF number  
    , @Description       NVARCHAR(1024) =   NULL  
    , @UserId         INT  
    , @LastModifiedTimestampAtCentral   DATETIME    = NULL  
    , @OutputLastModifiedTimestampAtLocal  DATETIME    = NULL OUTPUT  
    , @RatioDosingActive      BIT     
    , @IsPony BIT    
    , @MinMachineLoad       SMALLINT    = NULL  
    , @MaxMachineLoad       smallint    = NULL  
    , @ProgramSelectionByTime     bit      = NULL  
    , @FlowSwitchNumber      int      = NULL  
    , @WasherStopExternalSignal    bit      = NULL  
    , @OnHoldWESignalActive     bit      = NULL  
    , @WasherOnHoldSignalDelay    int      = NULL  
    , @ValveOutputsUsedAsTomSignal   bit      = NULL  
    , @WeInTomMode       bit      = NULL  
    , @ManifoldFlushTime      int      = NULL  
    , @L1          bit      = NULL  
    , @L2          bit      = NULL  
    , @L3          bit      = NULL  
    , @L4          bit      = NULL  
    , @L5          bit      = NULL  
    , @L6          bit      = NULL  
    , @L7          bit      = NULL  
    , @L8          bit      = NULL  
    , @L9          bit      = NULL  
    , @L10         bit      = NULL  
    , @L11         bit      = NULL  
    , @L12         bit      = NULL  
    , @UseMe1OfGroup       tinyint     = NULL  
    , @UseMe2OfGroup       tinyint     = NULL  
    , @UsePumpOfGroup       tinyint     = NULL  
    , @WasherStopUseFinalExtracting   bit      = NULL  
    , @TemperatureAlarmYesNo     bit      = NULL  
    , @DefaultIdleTime       INT      =   NULL  
AS  
BEGIN  
  
SET NOCOUNT ON  
  
  
DECLARE   
  @ReturnValue     INT    =   0  
 , @ErrorId      INT    =   0  
 , @ErrorMessage     NVARCHAR(4000) =   N''  
 , @CurrentUTCTime     DATETIME  =   GETUTCDATE()  
 , @PlantId  INT   = NULL  
 , @ControllerModelId INT = NULL  
  
DECLARE  
   @OutputList      AS TABLE  (  
   LastModifiedTimestamp   DATETIME  
  )  
  
SET  @OutputLastModifiedTimestampAtLocal    =   ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)   --SQLEnlight  
SELECT  @PlantId = PlantId From TCD.Plant WHERE EcolabAccountNumber = @EcoLabAccountNumber  
SELECT @ControllerModelId = cmctm.ControllerModelId   
FROM TCD.ControllerModelControllerTypeMapping cmctm   
INNER JOIN TCD.ConduitController cc   
 ON cc.ControllerModelId = cmctm.ControllerModelId  
WHERE cc.ControllerId = @ControllerId AND cc.EcoalabAccountNumber = @EcoLabAccountNumber  

--Valid Washer-Id check...  
IF NOT EXISTS ( SELECT 1  
     FROM [TCD].Washer      W  
     JOIN [TCD].MachineSetup    MS  
      ON W.WasherId     =   MS.WasherId  
      AND W.EcoLabAccountNumber  =   MS.EcoalabAccountNumber  
     WHERE W.EcoLabAccountNumber  =   @EcoLabAccountNumber  
      AND W.WasherId     =   @WasherId  
      AND MS.GroupId     =   @WasherGroupId  
      AND W.Is_Deleted    =   'FALSE'  
      AND MS.IsDeleted    =   'FALSE'  
    )  
   BEGIN  
    SET  @ErrorId      =   51006  
    SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Washer-ID was provided for Updating.'  
    --GOTO ErrorHandler  
    RAISERROR (@ErrorMessage, 16, 1)  
    SET  @ReturnValue = -1  
    RETURN (@ReturnValue)  
   END  
  
--Check for uniqueness of PlantWasherNo. and Name  
IF EXISTS  ( SELECT 1  
     FROM [TCD].Washer      W  
     JOIN [TCD].MachineSetup    MS  
      ON W.WasherId     =   MS.WasherId  
      AND W.EcoLabAccountNumber  =   MS.EcoalabAccountNumber  
     WHERE W.EcoLabAccountNumber  =   '040242802'  
      AND W.WasherId     <>   2045  AND W.PlantWasherNumber   =   @PlantWasherNumber
      AND (  
       W.PlantWasherNumber   =   @PlantWasherNumber       
       OR  
       MS.MachineName    =   'AMERICAN 200'  
       )  
      AND W.Is_Deleted    =   'FALSE'  
      AND MS.IsDeleted    =   'FALSE'  
    )  
   BEGIN  
    SET  @ErrorId      =   51002  
    SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Specified Plant Washer #/ already exists.'  
    --GOTO ErrorHandler  
    RAISERROR (@ErrorMessage, 16, 1)  
    SET  @ReturnValue = -1  
    RETURN (@ReturnValue)  
   END  
  
IF @ControllerId > 0  
BEGIN  
--Check Max LFSWasher No.  
IF NOT EXISTS ( SELECT 1  
     FROM [TCD].ControllerModelControllerTypeMapping  
              CMCTM  
     JOIN [TCD].ConduitController   CC  
      ON CC.ControllerTypeId   =   CMCTM.ControllerTypeId  
      AND CC.ControllerModelId  =   CMCTM.ControllerModelId  
     WHERE CC.EcoalabAccountNumber  =   @EcoLabAccountNumber  
      AND CC.ControllerId    =   @ControllerId  
      AND CC.IsDeleted    =   'FALSE'  
      AND CMCTM.MaximumWasherExtractorCount  
              >=   @LFSWasherNumber  
    )  
   BEGIN  
    SET  @ErrorId      =   51003  
    SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller/LFSWasher# was provided.'  
    --GOTO ErrorHandler  
    RAISERROR (@ErrorMessage, 16, 1)  
    SET  @ReturnValue = -1  
    RETURN (@ReturnValue)  
   END  
END  
--EOF should not be an asocciated formula for the WG...  
IF EXISTS  ( SELECT 1  
     FROM [TCD].WasherProgramSetup   WPS  
     WHERE WPS.EcolabAccountNumber  =   @EcoLabAccountNumber  
      AND WPS.WasherGroupId   =   @WasherGroupId  
      AND WPS.ProgramNumber   =   @ProgramNumber  
      AND WPS.Is_Deleted    =   'FALSE'  
    )  
   BEGIN  
    SET  @ErrorId      =   51004  
    SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An assoicated formula cannot be specified as End-Of-Formula.'  
    --GOTO ErrorHandler  
    RAISERROR (@ErrorMessage, 16, 1)  
    SET  @ReturnValue = -1  
    RETURN (@ReturnValue)  
   END  
  
IF @ControllerId > 0  
BEGIN  
--WasherMode check  
IF NOT EXISTS ( SELECT 1  
     FROM [TCD].ControllerModelControllerTypeMapping  
              CMCTM  
     JOIN [TCD].ConduitController   CC  
      ON CC.ControllerTypeId   =   CMCTM.ControllerTypeId  
      AND CC.ControllerModelId  =   CMCTM.ControllerModelId  
     JOIN [TCD].[WasherModeMapping]  
              CTM2WM  
      ON CMCTM.Id     =   CTM2WM.ControllerModelControllerTypeMappingId  
     WHERE CC.EcoalabAccountNumber  =   @EcoLabAccountNumber  
      AND CC.ControllerId    =   @ControllerId  
      AND CC.IsDeleted    =   'FALSE'  
      AND CTM2WM.WasherModeId   =   @WasherMode  
    )  
   BEGIN  
    SET  @ErrorId      =   51005  
    SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherMode was provided.'  
    --GOTO ErrorHandler  
    RAISERROR (@ErrorMessage, 16, 1)  
    SET  @ReturnValue = -1  
    RETURN (@ReturnValue)  
   END  
  
--LFSWasherNumber duplicate check...  
IF EXISTS ( SELECT 1  
    FROM [TCD].MachineSetup     MS  
    WHERE MS.ControllerId     =   @ControllerId  
     AND MS.MachineInternalId   =   @LFSWasherNumber  
     AND MS.IsDeleted     =   'FALSE'  
     AND MS.WasherId      <>   @WasherId  
     AND MS.EcoalabAccountNumber   =   @EcoLabAccountNumber  
     AND MS.IsTunnel      =   'FALSE'  
   )  
   BEGIN  
    SET  @ErrorId      =   51010  
    SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate LFSWasher# provided.'  
    --GOTO ErrorHandler  
    RAISERROR (@ErrorMessage, 16, 1)  
    SET  @ReturnValue = -1  
    RETURN (@ReturnValue)  
   END  
END  
  
IF (  
   @LastModifiedTimestampAtCentral    IS NOT NULL  
   AND  
   NOT EXISTS ( SELECT 1  
     FROM TCD.Washer  W  
     WHERE W.EcolabAccountNumber = @EcolabAccountNumber  
      AND W.WasherId    = @WasherId  
      AND W.LastModifiedTime  = @LastModifiedTimestampAtCentral  
    )  
 )  
  BEGIN  
    SET   @ErrorId    = 60000  
    SET   @ErrorMessage   = N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'  
    RAISERROR (@ErrorMessage, 16, 1)  
    SET   @ReturnValue   = -1  
    RETURN  (@ReturnValue)  
  END  
  
  
--Now attempt Update...  
BEGIN TRAN  
  
UPDATE MS  
 SET MS.MachineName     =   @ConventionalName  
 , MS.ControllerId     =   @ControllerId  
 , MS.MachineInternalId   =   @LFSWasherNumber  
 , MS.LastModifiedByUserId   =   @UserId  
 ,MS.IsPony = @IsPony  
FROM [TCD].MachineSetup     MS  
JOIN [TCD].Washer       W  
 ON MS.WasherId      =   W.WasherId  
 AND MS.EcoalabAccountNumber   =   W.EcolabAccountNumber  
WHERE MS.WasherId      =   @WasherId  
 AND MS.EcoalabAccountNumber   =   @EcoLabAccountNumber  
 AND MS.IsDeleted     =   'FALSE'  
 AND W.Is_Deleted     =   'FALSE'  
  
--check for any error  
SET @ErrorId = @@ERROR  
  
IF (@ErrorId <> 0)  
BEGIN  
  
  IF @@TRANCOUNT > 0  
  BEGIN  
   ROLLBACK TRAN  
  END  
   
  SET  @ErrorMessage    =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating washer data.'  
  --GOTO ErrorHandler  
  RAISERROR (@ErrorMessage, 16, 1)  
  SET  @ReturnValue = -1  
  RETURN (@ReturnValue)  
END  
  
--else, continue with the rest of the update in the other table...  
UPDATE W  
 SET W.ModelId      =   @ModelId  
 , W.PlantWasherNumber    =   @PlantWasherNumber  
 , W.WasherMode     =   @WasherMode  
 , W.MaxLoad      =   @MaxLoad  
 , W.AWEActive      =   @AWEActive  
 , W.HoldSignal     =   @HoldSignal  
 , W.HoldDelay      =   @HoldDelay  
 , W.TargetTurnTime    =   @TargetTurnTime  
 , W.WaterFlushTime    =   @WaterFlushTime  
 , W.EndOfFormula     =   @ProgramNumber  
 , W.[Description]     =   @Description  
 , W.LastModifiedByUserId   =   @UserId  
 , W.LastModifiedTime    =   @CurrentUTCTime  
 ,   W.RatioDosingActive    =   @RatioDosingActive  
 , W.MinMachineLoad    =   @MinMachineLoad      
 , W.MaxMachineLoad    =   @MaxMachineLoad      
 , W.ProgramSelectionByTime  =   @ProgramSelectionByTime    
 , W.FlowSwitchNumber    =   @FlowSwitchNumber     
 , W.WasherStopExternalSignal  =   @WasherStopExternalSignal   
 , W.OnHoldWESignalActive   =   @OnHoldWESignalActive    
 , W.WasherOnHoldSignalDelay  =   @WasherOnHoldSignalDelay   
 , W.ValveOutputsUsedAsTomSignal =   @ValveOutputsUsedAsTomSignal  
 , W.WEInTOMMode     =   @WeInTomMode      
 , W.ManifoldFlushTime    =   @ManifoldFlushTime     
 , W.L1       =   @L1  
 , W.L2       =   @L2  
 , W.L3       =   @L3  
 , W.L4       =   @L4  
 , W.L5       =   @L5  
 , W.L6       =   @L6  
 , W.L7       =   @L7  
 , W.L8       =   @L8  
 , W.L9       =   @L9  
 , W.L10       =   @L10  
 , W.L11       =   @L11  
 , W.L12       =   @L12  
 , W.UseMe1OfGroup     =   @UseMe1OfGroup  
 , W.UseMe2OfGroup     =   @UseMe2OfGroup  
 , W.UsePumpOfGroup    =   @UsePumpOfGroup  
 , W.WasherStopUseFinalExtracting =   @WasherStopUseFinalExtracting  
 , W.TemperatureAlarmYesNo   =   @TemperatureAlarmYesNo  
 , W.PlantId      =   @PlantId  
 ,   W.DefaultIdleTime               =           @DefaultIdleTime  
  
OUTPUT  
 inserted.LastModifiedTime  AS   LastModifiedTimestamp  
INTO  
 @OutputList (  
 LastModifiedTimestamp  
)  
FROM [TCD].Washer      W  
JOIN [TCD].MachineSetup     MS  
 ON W.WasherId      =   MS.WasherId  
 AND W.EcoLabAccountNumber   =   MS.EcoalabAccountNumber  
WHERE W.WasherId      =   @WasherId  
 AND W.EcoLabAccountNumber   =   @EcoLabAccountNumber  
 AND W.Is_Deleted     =   'FALSE'  
 AND MS.IsDeleted     =   'FALSE'  
  
  
 IF(@NewWasherGroupId IS NOT NULL AND (@WasherGroupId != @NewWasherGroupId))  
 BEGIN  
    UPDATE tcd.machinesetup   
    SET GroupId = @NewWasherGroupId  
    WHERE WasherId = @WasherId  
       
   EXEC TCD.SaveInjectionDetails @WasherGroupId,@NewWasherGroupId,@ControllerId,@WasherId,@EcolabAccountNumber  
 END  
 ELSE  
 BEGIN  
   EXEC TCD.SaveInjectionDetails @WasherGroupId,@WasherGroupId,@ControllerId,@WasherId,@EcolabAccountNumber  
 END  
  
--check for error, if none - commit the tran, else rollback  
SET @ErrorId = @@ERROR  
IF (@ErrorId <> 0)  
 BEGIN  
  IF (@@TRANCOUNT > 0)  
   BEGIN  
    ROLLBACK  
   END  
  
  SET  @ErrorMessage    =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating washer data.'  
  --GOTO ErrorHandler  
  RAISERROR (@ErrorMessage, 16, 1)  
  SET  @ReturnValue = -1  
  RETURN (@ReturnValue)  
 END  
ELSE  
 BEGIN  
  IF (@@TRANCOUNT > 0)  
   BEGIN  
    IF (@ControllerModelId = 7)  
    BEGIN  
     UPDATE TCD.WasherGroup SET ControllerId = @ControllerId WHERE WasherGroupId = @WasherGroupId  
    END  
    COMMIT  
   END  
     
   SELECT TOP 1 @OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp FROM @OutputList O  
 END  
  
  
SET NOCOUNT OFF  
RETURN (@ReturnValue)  

  
END
GO


IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetEcolabSaturation]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.[GetEcolabSaturation]
	END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[GetEcolabSaturation] 
@TextileId INT
AS 
  BEGIN 
      SET nocount ON; 
	 IF @TextileId>0
	 BEGIN
		SELECT es.EcolabSaturationId,es.EcolabSaturationName FROM TCD.EcolabSaturation es 
		
     END
	ELSE
	BEGIN
		SELECT es.EcolabSaturationId,es.EcolabSaturationName FROM  TCD.EcolabSaturation es 
	END
  END
  GO
  
 IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetPrograms]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.[GetPrograms]
	END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE  PROCEDURE [TCD].[GetPrograms]
@EcolabAccountNumber                    NVARCHAR(1000)    ,
@IsResync Bit = 'False',
@ProgramId INT
AS 
  BEGIN 
    SET NOCOUNT ON; 

    SET            @EcolabAccountNumber            =            ISNULL(@EcolabAccountNumber, NULL)            --SQLEnlight SA0029
    IF @ProgramId = 0 
       BEGIN 
          SET @ProgramId = NULL
       END


    SELECT	     pm.ProgramId
            ,pm.Name
            ,pm.Pieces
            ,(CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN etc.TextileId 
        ELSE cp.EcolabTextileCategoryId END) AS TextileId
            ,(CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN etc.CategoryName 
        ELSE cp.EcolabTextileCategoryName END) AS CategoryName
            ,(CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN es.EcolabSaturationId 
        ELSE cp.EcolabSaturationId END) AS EcolabSaturationId
            ,(CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN es.EcolabSaturationName 
        ELSE cp.EcolabSaturationName END) AS EcolabSaturationName    
            ,cp.PlantProgramId
            ,cp.PlantProgramName
            ,cp.ChainTextileId
            ,cp.ChainTextileName
            ,(CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN fs.FormulaSegmentId
        ELSE cp.FormulaSegmentId END) AS FormulaSegmentId
            ,(CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN fs.SegmentName
        ELSE cp.SegmentName END) AS FormulaSegmentName
            ,pm.Rewash
            ,pm.[Weight]
            ,COUNT(*) OVER() as TotalCount            
            ,pm.CustomerId
            ,pm.LastModifiedTime 
            ,pm.EcolabAccountNumber
            ,pm.Is_Deleted
            ,pm.Weight_Display
	    FROM TCD.ProgramMaster pm
	LEFT JOIN TCD.ChainPrograms cp
	ON cp.PlantProgramId = pm.PlantProgramId AND pm.EcolabAccountNumber = cp.EcolabAccountNumber
	    LEFT JOIN TCD.EcolabTextileCategory etc
        ON pm.EcolabTextileCategoryId = etc.TextileId
	    LEFT JOIN TCD.EcolabSaturation es
	    ON pm.EcolabSaturationId = es.EcolabSaturationId
	    LEFT JOIN TCD.FormulaSegments fs
	    ON pm.FormulaSegmentId = fs.FormulaSegmentID
	    WHERE pm.ProgramId = ISNULL(@ProgramId, pm.ProgramId)
	    AND (pm.Is_Deleted = 0 OR pm.Is_Deleted = @IsResync)
        AND pm.EcolabAccountNumber = @EcolabAccountNumber
	    ORDER BY pm.Name
    
         
SET NOCOUNT OFF;
 END
 GO

 IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[SaveProgramDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.[SaveProgramDetails]
	END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[SaveProgramDetails] (
              @ProgramId INT
		    ,@PlantProgramId INT
		    ,@FormulaCategoryId int 
		    ,@EcolabSaturationId INT = NULL
		    ,@CustomerId INT
		    ,@Rewash BIT = NULL
		    ,@Pieces INT = NULL
		    ,@Weight_Display DECIMAL = NULL    
		    ,@Name NVARCHAR(100)
		    ,@FormulaSegmentId INT
            ,@Weight DECIMAL = NULL
            ,@UserID INT       
		    ,@PlantChainId INT
              --Adding these 3 param as part of re-factoring for integration with Synch/Configurator
            ,@OutputProgramId                    INT                    =            NULL    OUTPUT
            ,@LastModifiedTimestampAtCentral        DATETIME            =            NULL            --Nullable for local call; Synch/Central call will have to pass this -
            ,@OutputLastModifiedTimestampAtLocal    DATETIME            =            NULL    OUTPUT
            ,@EcolabAccountNumber                NVARCHAR(1000)
            ) 
AS 
  BEGIN 
      SET nocount ON;  --Commented old Audit Technique-- 

DECLARE    
        @ReturnValue                    INT                =            0
    ,    @ErrorId                        INT                =            0
    ,    @ErrorMessage                    NVARCHAR(4000)    =            N''
    ,    @CurrentUTCTime                    DATETIME        =            GETUTCDATE()

DECLARE
        @OutputList                        AS    TABLE        (
        ProgramMasterId                    INT
    ,    LastModifiedTimestamp            DATETIME
    )

    SET        @OutputProgramId                            =            ISNULL(@OutputProgramId, NULL)                        --SQLEnlight SA0121
    SET        @OutputLastModifiedTimestampAtLocal            =            ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)    --SQLEnlight SA0121

      IF NOT EXISTS (SELECT 1 FROM [TCD].ProgramMaster WHERE ProgramId = @ProgramId)
      BEGIN

        IF EXISTS(SELECT 1 FROM [TCD].ProgramMaster Where Name = @Name AND Is_Deleted = 0)
        BEGIN
            SET @ErrorMessage ='303 - Formula Name already exists.'
            RAISERROR(@ErrorMessage, 16, 1)
            RETURN
        END 
        
        SELECT @ProgramId = ISNULL(MAX(ProgramId), 0) + 1 FROM [TCD].ProgramMaster 
      
	   IF(@PlantChainId > 0)
		  BEGIN
			 INSERT INTO TCD.ProgramMaster
			 (
				ProgramId,
				Name,
				Pieces,
				Rewash,
				[Weight],
				EcolabSaturationId,
				EcolabAccountNumber,
				FormulaSegmentId,
				PlantProgramId,
				CustomerId,
				LastModifiedByUserId,
				Weight_Display
			 )
			 OUTPUT
				inserted.ProgramId                AS            ProgramMasterId
			 ,   inserted.LastModifiedTime        AS            LastModifiedTimestamp
			 INTO
				@OutputList    (
				    ProgramMasterId
				,   LastModifiedTimestamp
			 ) 
			 VALUES
			 (
			 @ProgramId,
			 @Name,
			 @Pieces,
			 @Rewash,
			 @Weight,
			 @EcolabSaturationId,
			 @EcolabAccountNumber,
			 @FormulaSegmentId,
			 @PlantProgramId,
			 @CustomerId,
			 @UserId,
			 @Weight_Display
			 )

		  END
	   ELSE
		  BEGIN
			 INSERT INTO TCD.ProgramMaster
			 (
			     ProgramId,
			     Name,
			     Pieces,
			     EcolabTextileCategoryId,
			     FormulaSegmentId,
			     Rewash,
			     [Weight],
			     EcolabSaturationId,
			     EcolabAccountNumber,
			     CustomerId,
			     LastModifiedByUserId,
			     Weight_Display
			 )
			 OUTPUT
				inserted.ProgramId                AS            ProgramMasterId
			 ,   inserted.LastModifiedTime        AS            LastModifiedTimestamp
			 INTO
				@OutputList    (
				    ProgramMasterId
				,   LastModifiedTimestamp
			 ) 
			 VALUES
			 (
			      @ProgramId,
				 @Name,
				 @Pieces,
				 @FormulaCategoryId,
				 @FormulaSegmentId,
				 @Rewash,
				 @Weight,
				 @EcolabSaturationId,
				 @EcolabAccountNumber,
				 @CustomerId,
				 @UserID,
				 @Weight_Display
			 )
		  END
      END
    
      ELSE
      BEGIN
      /*Update record if program exists */
      IF EXISTS(SELECT 1 FROM [TCD].ProgramMaster Where Name = @Name AND ProgramId != @ProgramId AND Is_Deleted = 0)
        BEGIN
            SET @ErrorMessage ='303 - Formula Name already exists.'
            RAISERROR(@ErrorMessage, 16, 1)
            RETURN
        END 

            --If the call is not local, check that the LastModifiedTime matches with the central
            IF    (
                    @LastModifiedTimestampAtCentral                IS NOT    NULL
                AND
                NOT    EXISTS    (    SELECT    1
                                FROM    TCD.ProgramMaster        PM
                                WHERE    PM.EcolabAccountNumber    =    @EcolabAccountNumber
                                    AND    PM.ProgramId            =    @ProgramId
                                    AND    PM.LastModifiedTime        =    @LastModifiedTimestampAtCentral
                            )
                )
                    BEGIN
                            SET            @ErrorId                =    60000
                            SET            @ErrorMessage            =    N'' + CAST(@ErrorId AS NVARCHAR) + N': Record not in-synch between plant and central.'
                            RAISERROR    (@ErrorMessage, 16, 1)
                            SET            @ReturnValue            =    -1
                            RETURN        (@ReturnValue)
                    END

				IF (@PlantChainId > 0)
				    BEGIN
				    UPDATE TCD.ProgramMaster
				    SET
				        Name = @Name, 
				        Pieces = @Pieces,
				        Rewash = @Rewash, 
				        [Weight] = @Weight,
				        PlantProgramId = @PlantProgramId,
					    FormulaSegmentId = @FormulaSegmentId,
					    EcolabSaturationId = @EcolabSaturationId,
				        CustomerId = @CustomerId, 
				        LastModifiedByUserId = @UserID, 
				        Weight_Display = @Weight_Display 
					   OUTPUT
							 inserted.ProgramId                AS            ProgramMasterId
						  ,    inserted.LastModifiedTime        AS            LastModifiedTimestamp
					   INTO
							 @OutputList    (
							 ProgramMasterId
						  ,    LastModifiedTimestamp
						  )    
				    WHERE 
					   ProgramId  = @ProgramId 
					  AND 
					   EcolabAccountNumber  = @EcolabAccountNumber
				    END
				ELSE
				    BEGIN
					   UPDATE TCD.ProgramMaster
					   SET
					       Name = @Name,
					       Pieces = @Pieces, 
					       EcolabTextileCategoryId = @FormulaCategoryId, 
					       FormulaSegmentId = @FormulaSegmentId, 
					       Rewash = @Rewash, 
					       [Weight] = @Weight, 
					       EcolabSaturationId = @EcolabSaturationId, 
					       CustomerId = @CustomerId,
					       LastModifiedByUserId = @UserID, 
					       Weight_Display = @Weight 
						   OUTPUT
							 inserted.ProgramId                AS            ProgramMasterId
						  ,    inserted.LastModifiedTime        AS            LastModifiedTimestamp
						  INTO
							 @OutputList    (
							 ProgramMasterId
						  ,    LastModifiedTimestamp
						  )    
					   WHERE 
						  ProgramId = @ProgramId
					   AND
						  EcolabAccountNumber = @EcolabAccountNumber
				    END
      END
    
SELECT    TOP 1    
        @OutputLastModifiedTimestampAtLocal    =    O.LastModifiedTimestamp
    ,    @OutputProgramId                    =    O.ProgramMasterId
FROM    @OutputList                            O

  END
  GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[SaveChainTextileCategoryDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.[SaveChainTextileCategoryDetails]
	END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[SavePlantChainProgramDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.[SavePlantChainProgramDetails]
	END
GO
  
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[SaveProductionShiftManualDataRollup]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.[SaveProductionShiftManualDataRollup]
	END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [TCD].[SaveProductionShiftManualDataRollup](
--DECLARE
												@Date datetime = NULL,    --'2015-05-26'
												@ManualData int = NULL,  --1000
												@WasherId int = NULL,	   --4
												@ProgramMasterId int =NULL	   --21
												
												
											 )
AS
SET NOCOUNT ON
BEGIN

    DECLARE 
		  @ShiftId Int = NULL,   		  
		  @BatchUTCStart DATETIME= NULL,
		  @BatchUTCEnd DATETIME= NULL,
		  @ShiftTargetProd Decimal(18,2) = NULL,
		  @ShiftCount Int = 1,
		  @validateShiftName varchar(100),
		  @Fromdate datetime,
		  @ToDate datetime

    SET @Fromdate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@Date AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@Date AS time)) AS DateTime))
	SET @ToDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(DATEADD(d,1,@Date) AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(DATEADD(d,1,@Date) AS time)) AS DateTime))

    DECLARE @ShiftProductionDataRollup TABLE
				 (
					[ShiftId] [int] NOT NULL,
					[MachineId] [int] NULL,
					[ProgramMasterId] [int] NULL,
					[EcolabWasherId] [int] NULL,
					[NoOfLoads] [int] NULL,
					[ActualProduction] [int] NULL,
					[StandardProduction] [int] NULL,
					[LoadEfficiency] [decimal](18, 2) NULL,
					[TimeEfficiency] [decimal](18, 2) NULL,
					[PlantTargetProd] [int] NULL,
					[ActualRunTime] [int] NULL,
					[TargetRunTime] [int] NULL,
					[EcolabTextileId] [int] NULL,
					[ChainTextileId] [int] NULL,
					[ChainProgaramId] [int] NULL,
					[CustomerId] [int] NULL,
					[NoOfPieces] [int] NULL,
					[ActualTurnTime] [int] NULL,
					[TargetTurnTime] [int] NULL
				)
	   
    DECLARE @BatchShiftTable TABLE
						(
						  RowNumber int IDENTITY(1,1),
						  BatchUTCStartDate datetime,
						  BatchUTCEndDate datetime,
						  ShiftId int,
						  ShiftName varchar(100)
						)
  		  
	 INSERT INTO @BatchShiftTable
	 (
	    BatchUTCStartDate,
	    BatchUTCEndDate,
	    ShiftId,
	    ShiftName
	 )
	 SELECT 
			StartDateTime,
			EndDateTime,
			ShiftID,
			ShiftName		   
					FROM [TCD].ProductionShiftData SD WITH (NOLOCK) 
					WHERE sd.StartDateTime >= @Fromdate AND  SD.StartDateTime < @ToDate
					   ORDER BY SD.ShiftId



    DECLARE @ManualInputData TABLE
			 (
				ManualInput int,
				WasherId int,
				ProgramMasterId int
			 )
			 INSERT @ManualInputData
			 (
			     ManualInput,
				WasherId,
			     ProgramMasterId
			 )
			
			 SELECT @ManualData/NULLIF((SELECT COUNT(1) FROM @BatchShiftTable bst WHERE bst.ShiftName <> 'No Shift'),0),
				    @WasherId,
				   @ProgramMasterId


    			
	   ------------------******// Inserting the Data into Batch Summary Temp table based on UTC shift timings //******-----------------------
    WHILE (@ShiftCount <= (SELECT COUNT(1) FROM @BatchShiftTable bst))
    BEGIN

    SELECT  @BatchUTCStart = 
				    bst.BatchUTCStartDate,
			   @BatchUTCEnd = 
				    bst.BatchUTCEndDate,
			   @ShiftId = bst.ShiftId,
			   @validateShiftName = bst.ShiftName
				FROM @BatchShiftTable bst WHERE bst.RowNumber = @ShiftCount
    
    INSERT INTO @ShiftProductionDataRollup
		  ([ShiftId]
           ,[MachineId]
           ,[ProgramMasterId]
           ,[EcolabWasherId]
           ,[NoOfLoads]
           ,[ActualProduction]
           ,[StandardProduction]
           ,[LoadEfficiency]
           ,[TimeEfficiency]
           ,[PlantTargetProd]
           ,[ActualRunTime]
           ,[TargetRunTime]
           ,[EcolabTextileId]
           ,[ChainTextileId]
           ,[ChainProgaramId]
           ,[CustomerId]
           ,[NoOfPieces]
           ,[ActualTurnTime]
           ,[TargetTurnTime])
    SELECT 
		  [ShiftId]
           ,[MachineId]
           ,[ProgramMasterId]
           ,[EcolabWasherId]
           ,[NoOfLoads]
           ,[ActualProduction]
           ,[StandardProduction]
           ,[LoadEfficiency]
           ,[TimeEfficiency]
           ,[PlantTargetProd]
           ,[ActualRunTime]
           ,[TargetRunTime]
           ,[EcolabTextileId]
           ,[ChainTextileId]
           ,[ChainProgaramId]
           ,[CustomerId]
           ,[NoOfPieces]
           ,[ActualTurnTime]
           ,[TargetTurnTime] FROM TCD.ShiftProductionDataRollup spdr WHERE spdr.ShiftId = @ShiftId
	  
	  --SELECT spdr.* FROM @ShiftProductionDataRollup spdr

	    --------------------------******// Inserting the Data into production Shift Rollup Data Table //******-------------------
	      		  
		 DELETE FROM [TCD].ShiftProductionDataRollup WHERE ShiftId = @ShiftId 
		 
			 INSERT INTO [TCD].ShiftProductionDataRollup
								(
								    ShiftId,
								    MachineId,
								    ProgramMasterId,
								    EcolabWasherId,
								    NoOfLoads,
								    ActualProduction ,
								    StandardProduction,
								    LoadEfficiency,
								    TimeEfficiency,
								    PlantTargetProd ,
								    ActualRunTime,
								    TargetRunTime,
								    EcolabTextileId,
								    ChainTextileId,
								    ChainProgaramId,
								    CustomerId,
								    NoOfPieces,
								    ActualTurnTime,
								    TargetTurnTime
								)	


			 SELECT 
				    spdr.[ShiftId]
				   ,spdr.[MachineId]
				   ,spdr.[ProgramMasterId]
				   ,spdr.[EcolabWasherId]
				   ,spdr.[NoOfLoads]
				   ,spdr.[ActualProduction]  + ISNULL(mid.ManualInput,0)
				   ,spdr.[StandardProduction]
				   ,spdr.[LoadEfficiency]
				   ,spdr.[TimeEfficiency]
				   ,spdr.[PlantTargetProd]
				   ,spdr.[ActualRunTime]
				   ,spdr.[TargetRunTime]
				   ,spdr.[EcolabTextileId]
				   ,spdr.[ChainTextileId]
				   ,spdr.[ChainProgaramId]
				   ,spdr.[CustomerId]
				   ,spdr.[NoOfPieces]
				   ,spdr.[ActualTurnTime]
				   ,spdr.[TargetTurnTime] 
						  FROM @ShiftProductionDataRollup spdr
							 LEFT JOIN
								    @ManualInputData mid ON spdr.ProgramMasterId = mid.ProgramMasterId AND spdr.MachineId = mid.WasherId

					--SELECT spdr.* FROM TCD.ShiftProductionDataRollup spdr WHERE spdr.ShiftId = @ShiftId 

		  IF(@validateShiftName <> 'No Shift')
		  BEGIN
		  IF NOT EXISTS(SELECT DISTINCT spdr.ProgramMasterId,spdr.MachineId FROM TCD.ShiftProductionDataRollup spdr WHERE spdr.ShiftId = @ShiftId
																   AND spdr.ProgramMasterId IN (SELECT mid.ProgramMasterId FROM @ManualInputData mid)
																   AND spdr.MachineId IN (SELECT mid.WasherId FROM @ManualInputData mid))
				BEGIN
				   INSERT INTO [TCD].ShiftProductionDataRollup
								(
								    ShiftId,
								    MachineId,
								    ProgramMasterId,
								    EcolabWasherId,
								    NoOfLoads,
								    ActualProduction ,												
								    PlantTargetProd ,
								    ActualRunTime,
								    TargetRunTime,						
								    ActualTurnTime,
								    TargetTurnTime
								)	


				SELECT TOP 1 
					   spdr.[ShiftId]
					  ,(SELECT mid.WasherId FROM @ManualInputData mid)
					  ,(SELECT mid.ProgramMasterId FROM @ManualInputData mid)
					  ,(SELECT w.EcolabWasherId FROM TCD.Washer w WHERE W.WasherId IN (SELECT mid.WasherId FROM @ManualInputData mid))
					  ,1
					  ,(SELECT mid.ManualInput FROM @ManualInputData mid)
					  ,spdr.[PlantTargetProd]
					  ,ISNULL(NULL,0)
					  ,ISNULL(NULL,0)
					  ,ISNULL(NULL,0)
					  ,ISNULL(NULL,0)
							 FROM TCD.ShiftProductionDataRollup spdr WHERE spdr.ShiftId = @ShiftId
								
								    
				END
			END
	  	   DELETE FROM @ShiftProductionDataRollup		 
		  SET @ShiftCount = @ShiftCount + 1
	    END	   
	  
END
Go

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[SaveProgramDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.[SaveProgramDetails]
	END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[SaveProgramDetails] (
              @ProgramId INT
		    ,@PlantProgramId INT
		    ,@FormulaCategoryId int 
		    ,@EcolabSaturationId INT = NULL
		    ,@CustomerId INT
		    ,@Rewash BIT = NULL
		    ,@Pieces INT = NULL
		    ,@Weight_Display DECIMAL = NULL    
		    ,@Name NVARCHAR(100)
		    ,@FormulaSegmentId INT
            ,@Weight DECIMAL = NULL
            ,@UserID INT       
		    ,@PlantChainId INT
              --Adding these 3 param as part of re-factoring for integration with Synch/Configurator
            ,@OutputProgramId                    INT                    =            NULL    OUTPUT
            ,@LastModifiedTimestampAtCentral        DATETIME            =            NULL            --Nullable for local call; Synch/Central call will have to pass this -
            ,@OutputLastModifiedTimestampAtLocal    DATETIME            =            NULL    OUTPUT
            ,@EcolabAccountNumber                NVARCHAR(1000)
            ) 
AS 
  BEGIN 
      SET nocount ON;  --Commented old Audit Technique-- 

DECLARE    
        @ReturnValue                    INT                =            0
    ,    @ErrorId                        INT                =            0
    ,    @ErrorMessage                    NVARCHAR(4000)    =            N''
    ,    @CurrentUTCTime                    DATETIME        =            GETUTCDATE()

DECLARE
        @OutputList                        AS    TABLE        (
        ProgramMasterId                    INT
    ,    LastModifiedTimestamp            DATETIME
    )

    SET        @OutputProgramId                            =            ISNULL(@OutputProgramId, NULL)                        --SQLEnlight SA0121
    SET        @OutputLastModifiedTimestampAtLocal            =            ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)    --SQLEnlight SA0121

      IF NOT EXISTS (SELECT 1 FROM [TCD].ProgramMaster WHERE ProgramId = @ProgramId)
      BEGIN

        IF EXISTS(SELECT 1 FROM [TCD].ProgramMaster Where Name = @Name AND Is_Deleted = 0)
        BEGIN
            SET @ErrorMessage ='303 - Formula Name already exists.'
            RAISERROR(@ErrorMessage, 16, 1)
            RETURN
        END 
        
        SELECT @ProgramId = ISNULL(MAX(ProgramId), 0) + 1 FROM [TCD].ProgramMaster 
      
	  SELECT @PlantChainId = (SELECT PlantChainId FROM tcd.plant WHERE EcolabAccountNumber = @EcolabAccountNumber)

	   IF(@PlantChainId > 0)
		  BEGIN
			 INSERT INTO TCD.ProgramMaster
			 (
				ProgramId,
				Name,
				Pieces,
				Rewash,
				[Weight],
				EcolabSaturationId,
				EcolabAccountNumber,
				FormulaSegmentId,
				PlantProgramId,
				CustomerId,
				LastModifiedByUserId,
				Weight_Display
			 )
			 OUTPUT
				inserted.ProgramId                AS            ProgramMasterId
			 ,   inserted.LastModifiedTime        AS            LastModifiedTimestamp
			 INTO
				@OutputList    (
				    ProgramMasterId
				,   LastModifiedTimestamp
			 ) 
			 VALUES
			 (
			 @ProgramId,
			 @Name,
			 @Pieces,
			 @Rewash,
			 @Weight,
			 @EcolabSaturationId,
			 @EcolabAccountNumber,
			 @FormulaSegmentId,
			 @PlantProgramId,
			 @CustomerId,
			 @UserId,
			 @Weight_Display
			 )

		  END
	   ELSE
		  BEGIN
			 INSERT INTO TCD.ProgramMaster
			 (
			     ProgramId,
			     Name,
			     Pieces,
			     EcolabTextileCategoryId,
			     FormulaSegmentId,
			     Rewash,
			     [Weight],
			     EcolabSaturationId,
			     EcolabAccountNumber,
			     CustomerId,
			     LastModifiedByUserId,
			     Weight_Display
			 )
			 OUTPUT
				inserted.ProgramId                AS            ProgramMasterId
			 ,   inserted.LastModifiedTime        AS            LastModifiedTimestamp
			 INTO
				@OutputList    (
				    ProgramMasterId
				,   LastModifiedTimestamp
			 ) 
			 VALUES
			 (
			      @ProgramId,
				 @Name,
				 @Pieces,
				 @FormulaCategoryId,
				 @FormulaSegmentId,
				 @Rewash,
				 @Weight,
				 @EcolabSaturationId,
				 @EcolabAccountNumber,
				 @CustomerId,
				 @UserID,
				 @Weight_Display
			 )
		  END
      END
    
      ELSE
      BEGIN
      /*Update record if program exists */
      IF EXISTS(SELECT 1 FROM [TCD].ProgramMaster Where Name = @Name AND ProgramId != @ProgramId AND Is_Deleted = 0)
        BEGIN
            SET @ErrorMessage ='303 - Formula Name already exists.'
            RAISERROR(@ErrorMessage, 16, 1)
            RETURN
        END 

            --If the call is not local, check that the LastModifiedTime matches with the central
            IF    (
                    @LastModifiedTimestampAtCentral                IS NOT    NULL
                AND
                NOT    EXISTS    (    SELECT    1
                                FROM    TCD.ProgramMaster        PM
                                WHERE    PM.EcolabAccountNumber    =    @EcolabAccountNumber
                                    AND    PM.ProgramId            =    @ProgramId
                                    AND    PM.LastModifiedTime        =    @LastModifiedTimestampAtCentral
                            )
                )
                    BEGIN
                            SET            @ErrorId                =    60000
                            SET            @ErrorMessage            =    N'' + CAST(@ErrorId AS NVARCHAR) + N': Record not in-synch between plant and central.'
                            RAISERROR    (@ErrorMessage, 16, 1)
                            SET            @ReturnValue            =    -1
                            RETURN        (@ReturnValue)
                    END

				IF (@PlantChainId > 0)
				    BEGIN
				    UPDATE TCD.ProgramMaster
				    SET
				        Name = @Name, 
				        Pieces = @Pieces,
				        Rewash = @Rewash, 
				        [Weight] = @Weight,
				        PlantProgramId = @PlantProgramId,
					    FormulaSegmentId = @FormulaSegmentId,
					    EcolabSaturationId = @EcolabSaturationId,
				        CustomerId = @CustomerId, 
				        LastModifiedByUserId = @UserID, 
				        Weight_Display = @Weight_Display 
					   OUTPUT
							 inserted.ProgramId                AS            ProgramMasterId
						  ,    inserted.LastModifiedTime        AS            LastModifiedTimestamp
					   INTO
							 @OutputList    (
							 ProgramMasterId
						  ,    LastModifiedTimestamp
						  )    
				    WHERE 
					   ProgramId  = @ProgramId 
					  AND 
					   EcolabAccountNumber  = @EcolabAccountNumber
				    END
				ELSE
				    BEGIN
					   UPDATE TCD.ProgramMaster
					   SET
					       Name = @Name,
					       Pieces = @Pieces, 
					       EcolabTextileCategoryId = @FormulaCategoryId, 
					       FormulaSegmentId = @FormulaSegmentId, 
					       Rewash = @Rewash, 
					       [Weight] = @Weight, 
					       EcolabSaturationId = @EcolabSaturationId, 
					       CustomerId = @CustomerId,
					       LastModifiedByUserId = @UserID, 
					       Weight_Display = @Weight 
						   OUTPUT
							 inserted.ProgramId                AS            ProgramMasterId
						  ,    inserted.LastModifiedTime        AS            LastModifiedTimestamp
						  INTO
							 @OutputList    (
							 ProgramMasterId
						  ,    LastModifiedTimestamp
						  )    
					   WHERE 
						  ProgramId = @ProgramId
					   AND
						  EcolabAccountNumber = @EcolabAccountNumber
				    END
      END
    
SELECT    TOP 1    
        @OutputLastModifiedTimestampAtLocal    =    O.LastModifiedTimestamp
    ,    @OutputProgramId                    =    O.ProgramMasterId
FROM    @OutputList                            O

  END
Go

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetPrograms]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.[GetPrograms]
	END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE  PROCEDURE [TCD].[GetPrograms]
@EcolabAccountNumber                    NVARCHAR(1000)    ,
@IsResync Bit = 'False',
@ProgramId INT
AS 
  BEGIN 
    SET NOCOUNT ON; 

    SET            @EcolabAccountNumber            =            ISNULL(@EcolabAccountNumber, NULL)            --SQLEnlight SA0029
    IF @ProgramId = 0 
       BEGIN 
          SET @ProgramId = NULL
       END


    SELECT  pm.ProgramId
            ,pm.Name
            ,pm.Pieces
            ,(CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN etc2.TextileId 
	    ELSE etc.TextileId END) AS TextileId
			,(CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN etc2.CategoryName 
	    ELSE etc.CategoryName END) AS CategoryName
			,(CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN es.EcolabSaturationId 
	    ELSE es2.EcolabSaturationId END) AS EcolabSaturationId
			,(CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN es.EcolabSaturationName 
	    ELSE es2.EcolabSaturationName END) AS EcolabSaturationName	
            ,pcp.PlantProgramId
            ,pcp.PlantProgramName
            ,ctc.TextileId ChainTextileId
            ,ctc.Name ChainTextileCategory
			,(CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN fs.FormulaSegmentId
	    ELSE fs2.FormulaSegmentId END) AS FormulaSegmentId
			,(CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN fs.SegmentName
	    ELSE fs2.SegmentName END) AS FormulaSegmentName
            ,pm.Rewash
            ,pm.[Weight]
            ,COUNT(*) OVER() as TotalCount            
            ,pm.CustomerId
            ,pm.LastModifiedTime                    AS            LastModifiedTime
            ,pm.EcolabAccountNumber
            ,pm.Is_Deleted
            ,pm.Weight_Display
	    FROM TCD.ProgramMaster pm
	    LEFT JOIN TCD.PlantChainProgram pcp 
	    ON pcp.PlantProgramId = pm.PlantProgramId
	    LEFT JOIN TCD.ChainTextileCategory ctc
	    ON pcp.ChainTextileCategoryId = ctc.TextileId
	    LEFT JOIN TCD.EcolabTextileCategory etc
	    ON pcp.EcolabTextileCategoryId = etc.TextileId
	    LEFT JOIN TCD.EcolabTextileCategory etc2
	    ON pm.EcolabTextileCategoryId = etc2.TextileId
	    LEFT JOIN TCD.EcolabSaturation es
	    ON pm.EcolabSaturationId = es.EcolabSaturationId
	    LEFT JOIN TCD.FormulaSegments fs
	    ON pm.FormulaSegmentId = fs.FormulaSegmentID
		LEFT JOIN TCD.EcolabSaturation es2
		ON pcp.EcolabSaturationId = es2.EcolabSaturationId
		LEFT JOIN TCD.FormulaSegments fs2
		ON pcp.FormulaSegmentId = fs2.FormulaSegmentID
	    WHERE pm.ProgramId = ISNULL(@ProgramId, pm.ProgramId)
	    AND (pm.Is_Deleted = 0 OR pm.Is_Deleted = @IsResync)
	    ORDER BY pm.Name
    
         
SET NOCOUNT OFF;
 END
Go

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetBatchWashersByGroupId]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.[GetBatchWashersByGroupId]
	END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[GetBatchWashersByGroupId] 
(
  @GroupId NVARCHAR(1000) = NULL,
  @EcolabAccountNumber nvarchar(25) 
)
AS 
  BEGIN      
 SET NOCOUNT ON
  IF @GroupId IS NULL
  BEGIN
  SELECT 
   ms.WasherId
 , (CAST(W.PlantWasherNumber AS nvarchar(50)) + N': ' + ms.MachineName) AS machineName
 , ms.GroupId 
 FROM TCD.MachineSetup ms
 INNER JOIN TCD.Washer w ON w.WasherId = ms.WasherId
 WHERE ms.WasherId IN (SELECT DISTINCT ms.WasherId
         FROM [TCD].MachineSetup MS
         )
  END
  ELSE
  BEGIN
  
 SELECT 
   ms.WasherId
, (CAST(W.PlantWasherNumber AS nvarchar(50)) + N': ' + ms.MachineName) AS machineName
 , ms.GroupId 
 FROM TCD.MachineSetup ms 
 INNER JOIN TCD.Washer w ON w.WasherId = ms.WasherId
 WHERE ms.WasherId IN (SELECT DISTINCT ms.WasherId
         FROM [TCD].MachineSetup MS
         WHERE ms.GroupId IN ((SELECT cast(items as int) FROM [TCD].[CharacterListToTable] (@GroupId, ','))))
        END
 SET NOCOUNT OFF

 END
 GO
 -----------------------------

 IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[UpdateRedFlagDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				[TCD].[UpdateRedFlagDetails]
	END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[UpdateRedFlagDetails] (
@Id INT ,
@ItemID int,
@MinRange Decimal(18,3) ,
@MaxRange Decimal(18,3),
@LocationID int,
@MachineCompartmentId Int,
@IsSelected Bit,
@IsDirty Bit,
@EcolabAccountNumber nvarchar(25),
@UserID INT = NULL,
@Scope varchar(100) OUTPUT,
@OutputRedFlagId INT =	NULL	OUTPUT,
@LastModifiedTimestampAtCentral	DATETIME	=	NULL,
@OutputLastModifiedTimestampAtLocal	DATETIME	=	NULL	OUTPUT,
@CategoryId INT,
@FormulaId INT,
@ProductId INT, 
@MeterId INT,
@SensorId INT    
)
AS 

BEGIN
SET NOCOUNT ON

DECLARE 
		@OutPut							VARCHAR(100)	=			''
	,	@Min							Decimal(18,3)	=			NULL
	,	@Max							Decimal(18,3)	=			NULL
	,	@ExistingLoc					INT				=			NULL
	,	@ExistingItem					INT				=			NULL
	,	@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	--,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()

DECLARE
			@OutputList						AS	TABLE		(
			RedFlagId						INT
		,	LastModifiedTimestamp			DATETIME
		)

SET		@OutputLastModifiedTimestampAtLocal			=			ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight SA0121
SET		@OutputRedFlagId							=			ISNULL(@OutputRedFlagId, NULL)								--SQLEnlight SA0121
SET		@Scope										=			ISNULL(@Scope, NULL)										--SQLEnlight SA0121


    SELECT @Min = RM.MinimumRange FROM [TCD].RedFlag RM WHERE Item = @ItemID AND Id = @Id
    SELECT @Max = RM.MaximumRange FROM [TCD].RedFlag RM WHERE Item = @ItemID AND Id = @Id
	SELECT @ExistingLoc = Location FROM  [TCD].RedFlag WHERE  Id = @Id AND Is_Deleted=0 
	SELECT @ExistingItem = Item FROM  [TCD].RedFlag WHERE  Id = @Id AND Is_Deleted=0 
    DECLARE @PlantId INT = (SELECT MG.Id
				   FROM TCD.MachineGroupType MGT
					   INNER JOIN
					   TCD.MachineGroup MG ON MGT.Id = MG.GroupTypeId
				   WHERE MGT.Id = 1
					AND MG.Is_Deleted = 0);
  IF(@MeterId IS NOT NULL AND @SensorId IS NOT NULL AND @LocationID > 1 AND @MachineCompartmentId IS NULL AND NOT EXISTS (SELECT * FROM tcd.MachineGroup MG
      LEFT JOIN TCD.Meter M ON MG.Id = CASE M.IsPlant WHEN 'TRUE' THEN COALESCE(  M.GroupId ,@PlantId) ELSE M.GroupId END
      LEFT JOIN TCD.Sensor S ON MG.Id = CASE S.IsPlant WHEN 'TRUE' THEN COALESCE(  S.GroupId ,@PlantId) ELSE S.GroupId END
      WHERE ((S.SensorId	IS NOT NULL
          AND S.Is_deleted = 0
          AND S.MachineCompartment	IS NULL)
      	OR (M.MeterId	IS NOT NULL
          AND M.Is_deleted = 0
          AND M.MachineCompartment	IS NULL))
      	AND MG.Id = @LocationID))
		BEGIN
		  SET @Scope  = '301'
		END
		ELSE
		BEGIN
		   IF(@IsDirty = 1)
		   BEGIN
				IF	(
									@LastModifiedTimestampAtCentral				IS NOT	NULL
									AND
									NOT	EXISTS	(	SELECT	1
											FROM	TCD.RedFlag		RF
											WHERE	RF.EcolabAccountNumber	=	@EcolabAccountNumber
												AND	RF.ID					=	@Id
												AND	RF.LastModifiedTime		=	@LastModifiedTimestampAtCentral
										)
							)
								BEGIN
										SET			@ErrorId				=	60000
										SET			@ErrorMessage			=	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
										RAISERROR	(@ErrorMessage, 16, 1)
										SET			@ReturnValue			=	-1
										RETURN		(@ReturnValue)
								END
				UPDATE [TCD].RedFlag SET MinimumRange = @MinRange,MaximumRange = @MaxRange,LastModifiedByUserId = @UserID, FormulaId = @FormulaId, RedFlagCategoryId = @CategoryId 
					OUTPUT
						inserted.ID						AS			Id
					,	inserted.LastModifiedTime		AS			LastModifiedTimestamp
					INTO
						@OutputList	(
						RedFlagId
					,	LastModifiedTimestamp
					)	  
						  FROM [TCD].RedFlag WHERE Item = @ItemID AND Id = @Id
			SET @OutPut = '201'   
  		SET @Scope = @OutPut --SELECT @Scope 
   END
   ELSE
   BEGIN

    IF(NOT EXISTS (SELECT 1 FROM  [TCD].RedFlag WHERE  Item = @ItemID AND Location = @LocationID AND Id <> @Id AND Is_Deleted=0) AND @IsSelected = 1)  
      BEGIN

		  IF((@ExistingLoc <> @LocationID) OR (@ExistingItem <> @ItemID) OR 
			EXISTS(SELECT 1 FROM [TCD].RedFlagMappingData WHERE MappingId = @Id AND MachineId IS NOT NULL AND @MachineCompartmentId IS NULL AND Is_Deleted=0) OR
			EXISTS(SELECT 1 FROM [TCD].RedFlagMappingData WHERE MappingId = @Id AND MachineId IS NULL AND @MachineCompartmentId IS NOT NULL AND Is_Deleted=0)
		  )
			 BEGIN
			  UPDATE [TCD].RedFlagMappingData SET
								    Is_Deleted = 1,LastModifiedByUserId = @UserID  WHERE MappingId = @Id
			 END
		 IF	(
									@LastModifiedTimestampAtCentral				IS NOT	NULL
									AND
									NOT	EXISTS	(	SELECT	1
											FROM	TCD.RedFlag		RF
											WHERE	RF.EcolabAccountNumber	=	@EcolabAccountNumber
												AND	RF.ID					=	@Id
												AND	RF.LastModifiedTime		=	@LastModifiedTimestampAtCentral
										)
							)
								BEGIN
										SET			@ErrorId				=	60000
										SET			@ErrorMessage			=	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
										RAISERROR	(@ErrorMessage, 16, 1)
										SET			@ReturnValue			=	-1
										RETURN		(@ReturnValue)
								END   
		UPDATE [TCD].RedFlag SET
		Item = @ItemID,
		MaximumRange = @MaxRange,
		MinimumRange = @MinRange,
		Location = @LocationID,
		LastModifiedByUserId = @UserID,
		FormulaId = @FormulaId 	
		OUTPUT
				inserted.ID						AS			Id
			,	inserted.LastModifiedTime		AS			LastModifiedTimestamp
		INTO
				@OutputList	(
				RedFlagId
			,	LastModifiedTimestamp
		)	  
		WHERE ID = @Id AND EcolabAccountNumber = @EcolabAccountNumber

		INSERT INTO [TCD].RedFlagMappingData(MappingId,MachineId,EcolabAccountNumber,LastModifiedByUserId) VALUES(@Id,@MachineCompartmentId,@EcolabAccountNumber,@UserID)
		SET @OutPut = '201'   
  		SET @Scope = @OutPut --SELECT @Scope  
     END
  ELSE 
  BEGIN
   IF NOT EXISTS(SELECT 1 FROM [TCD].RedFlagMappingData RM INNER JOIN [TCD].RedFlag RF ON RM.MappingId = RF.Id 
	   WHERE ISNULL(RM.MachineId,'') = ISNULL(@MachineCompartmentId,'') AND RF.Item = @ItemID AND RF.Location = @LocationID AND RF.Is_Deleted = 0 AND RM.Is_Deleted = 0 AND @IsSelected = 1)

  BEGIN

		  /* Machine level Update and adding for already existing redflag details */

		    IF(@IsSelected = 1)
			 BEGIN
			 IF EXISTS (SELECT 1 FROM [TCD].RedFlagMappingData WHERE MachineId is NULL AND MappingId = @Id AND Is_Deleted = 0)
			 BEGIN
			 UPDATE [TCD].RedFlagMappingData SET
								    Is_Deleted = 1,LastModifiedByUserId = @UserID  WHERE MappingId = @Id

			IF	(
									@LastModifiedTimestampAtCentral				IS NOT	NULL
									AND
									NOT	EXISTS	(	SELECT	1
											FROM	TCD.RedFlag		RF
											WHERE	RF.EcolabAccountNumber	=	@EcolabAccountNumber
												AND	RF.ID					=	@Id
												AND	RF.LastModifiedTime		=	@LastModifiedTimestampAtCentral
										)
							)
								BEGIN
										SET			@ErrorId				=	60000
										SET			@ErrorMessage			=	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
										RAISERROR	(@ErrorMessage, 16, 1)
										SET			@ReturnValue			=	-1
										RETURN		(@ReturnValue)
								END   
			UPDATE [TCD].RedFlag SET
						Item = @ItemID,
						MaximumRange = @MaxRange,
						MinimumRange = @MinRange,
						Location = @LocationID,
						LastModifiedByUserId = @UserID ,
						RedFlagCategoryId = @CategoryId,
						FormulaId = @FormulaId,
						ProductId = @ProductId,
						MeterId = @MeterId,
						SensorId = @SensorId
						OUTPUT
							inserted.ID						AS			Id
						,	inserted.LastModifiedTime		AS			LastModifiedTimestamp
						INTO
							@OutputList	(
							RedFlagId
						,	LastModifiedTimestamp
						)		  
						WHERE ID = @Id AND EcolabAccountNumber = @EcolabAccountNumber
		 
			INSERT INTO [TCD].RedFlagMappingData(MappingId,MachineId,EcolabAccountNumber,LastModifiedByUserId) 
					   VALUES(@Id,@MachineCompartmentId,@EcolabAccountNumber,@UserID)
			 END
			 ELSE
			 BEGIN
			 
									
			INSERT INTO [TCD].RedFlagMappingData(MappingId,MachineId,EcolabAccountNumber,LastModifiedByUserId) 
					   VALUES(@Id,@MachineCompartmentId,@EcolabAccountNumber,@UserID)
			  END
			  END
			  ELSE
			  BEGIN
			 UPDATE [TCD].RedFlagMappingData SET
								    Is_Deleted = CASE WHEN @IsSelected = 0 THEN 1 WHEN @IsSelected = 1 THEN 0 END,
								    LastModifiedByUserId = @UserID  WHERE MachineId = @MachineCompartmentId AND MappingId = @Id

			IF(@IsSelected = 1)
			INSERT INTO [TCD].RedFlagMappingData(MappingId,MachineId,EcolabAccountNumber,LastModifiedByUserId) 
					   VALUES(@Id,@MachineCompartmentId,@EcolabAccountNumber,@UserID)
			  END

			 /* End of the Machine Level logic */

			 /*  Group level Update and adding for already existing redflag details */

			 IF(@MachineCompartmentId IS NULL AND @IsSelected = 1)
			 BEGIN
			 UPDATE [TCD].RedFlagMappingData SET
								    Is_Deleted = 1 WHERE MappingId = @Id

			 INSERT INTO [TCD].RedFlagMappingData(MappingId,MachineId,EcolabAccountNumber,LastModifiedByUserId) 
					   VALUES(@Id,@MachineCompartmentId,@EcolabAccountNumber,@UserID)
			 END

			 /* End of the Group Level logic */
			 SET @OutPut = '201'   
  			 SET @Scope = @OutPut --SELECT @Scope  
			 
			 IF(@Min <> @MinRange OR @Max <> @MaxRange)
			BEGIN
			IF	(
									@LastModifiedTimestampAtCentral				IS NOT	NULL
									AND
									NOT	EXISTS	(	SELECT	1
											FROM	TCD.RedFlag		RF
											WHERE	RF.EcolabAccountNumber	=	@EcolabAccountNumber
												AND	RF.ID					=	@Id
												AND	RF.LastModifiedTime		=	@LastModifiedTimestampAtCentral
										)
							)
								BEGIN
										SET			@ErrorId				=	60000
										SET			@ErrorMessage			=	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
										RAISERROR	(@ErrorMessage, 16, 1)
										SET			@ReturnValue			=	-1
										RETURN		(@ReturnValue)
								END   
		  UPDATE [TCD].RedFlag 
			SET MinimumRange = @MinRange,MaximumRange = @MaxRange,
				LastModifiedByUserId = @UserID  ,
				RedFlagCategoryId = @CategoryId,
						FormulaId = @FormulaId,
						ProductId = @ProductId,
						MeterId = @MeterId,
						SensorId = @SensorId
						  OUTPUT
							inserted.ID						AS			Id
						,	inserted.LastModifiedTime		AS			LastModifiedTimestamp
						INTO
							@OutputList	(
							RedFlagId
						,	LastModifiedTimestamp
						)	
						  FROM [TCD].RedFlag 
					    
						  WHERE Item = @ItemID AND Id = @Id
			SET @OutPut = '201'   
  		SET @Scope = @OutPut --SELECT @Scope  
	   END

	  END   
	  ELSE
		  BEGIN
	 	  SET @OutPut = '401'   
  		  SET @Scope = @OutPut SELECT @Scope  
		  END 
  END
END	
		END
	SELECT	TOP 1	
		@OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp
	,	@OutputRedFlagId				=	O.RedFlagId
FROM	@OutputList							O		  

RETURN	(@ReturnValue)

--SET NOCOUNT OFF																--SQLEnlight SA0144
END
GO
------------------------------------

IF EXISTS(SELECT * FROM tcd.RedFlagItemList rfil WHERE id=33 AND rfil.ItemName='Temperature' AND rfil.UOMNA = 'F')
BEGIN
    UPDATE TCD.RedFlagItemList SET UOMNA = N'°F' WHERE id=33
END
GO


IF NOT EXISTS(SELECT * FROM sys.columns
WHERE Name = N'FlowMeterCalibration' AND OBJECT_ID = OBJECT_ID(N'TCD.ControllerEquipmentSetup'))
BEGIN
	ALTER TABLE TCD.ControllerEquipmentSetup ADD FlowMeterCalibration INT;
END

-----------------------------

 IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetPlantChainProgramByPlantChainId]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				[TCD].[GetPlantChainProgramByPlantChainId]
	END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[GetPlantChainProgramByPlantChainId]
	   @Plantchainid INT = NULL
AS
BEGIN
	SET NOCOUNT ON;

	SELECT pcp.PlantProgramId, 
		   pcp.PlantProgramName, 
		   pcp.ChainTextileCategoryId, 
		   pcp.EcolabTextileCategoryId, 
		   pcp.FormulaSegmentId, 
		   pcp.LastModifiedTime, 
		   pcp.Is_Deleted, 
		   pcp.PlantChainId, 
		   pcp.EcolabSaturationId 
	FROM TCD.PlantChainProgram AS pcp
	WHERE pcp.plantchainid = @Plantchainid

END
GO
-----------------------------



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetWasherBatchSummarizedData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetWasherBatchSummarizedData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [TCD].[GetWasherBatchSummarizedData](  
    @DashBoardId int = NULL  
)   
AS   
BEGIN   
  
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED  
SET NOCOUNT ON  
  
   
DECLARE   --@DashBoardId int = 1, 
        @Washerid INT = NULL,   
        @Standardturntime INT = NULL,   
        @Machinenamedispalytype SMALLINT = 0,  
 @OverNightBatchThreshold int = 7200, -- Seconds  
 @EfficiencyType int  
  
 SELECT @EfficiencyType = ISNULL(EfficiencyCalcType,1) from tcd.Dashboard where DashboardId = @DashBoardId  
  
 DECLARE @Dashboardmachinemapping TABLE(  
  Id INT,   
  GroupID INT,  
  WasherId INT,  
  WasherName NVARCHAR(100),   
		WasherNumber INT,
		IsPLCConnected BIT,
		DispenserName VARCHAR(250))
  
 DECLARE @AlarmByMachine TABLE(  
  GroupID INT,  
  WasherID INT,   
  Alarm BIT NULL,  
  AlarmDescription NVARCHAR(250))  
  
 DECLARE @BatchEndtimes TABLE(  
  GroupID INT,  
  WasherID INT,   
  CurrentBatchEndTime INT NULL,  
  BatchEndTime time)  
  
 Declare @ShiftIds table(  
    ShiftId int,  
    ShiftStartDate DATETIME,  
    ShiftEndDate datetime)  
  
 DECLARE @Summarizeddata TABLE(  
  GroupId INT,   
  MachineId INT,   
  WasherName NVARCHAR(100),   
  WasherNumber INT,   
  TargetLoad float,   
  ActualLoad float,   
  LoadEfficiency float,   
  TimeEfficiency float,   
  LostLoad float,   
  Alarm BIT,   
  AlarmDescription NVARCHAR(250),   
  WasherStatus INT,   
  MachineNameDispalyType SMALLINT,  
  TargetTurnTime INT,  
		DefaultIdleTime INT,
		IsPLCConnected BIT,
	 DispenserName VARCHAR(250),
	 LostBatches Decimal(18,6))
  
 INSERT INTO @Dashboardmachinemapping(  
  Id,   
  GroupID,  
  WasherId,  
  WasherName,  
		WasherNumber,
		IsPLCConnected,
		DispenserName
		)
 SELECT  
  ROW_NUMBER()OVER(ORDER BY MS.GroupID)AS Id,   
  MS.GroupId,  
  MS.WasherID,  
  MS.MachineName,  
		W.PlantWasherNumber AS WasherNumber,		
		(CASE WHEN ISNULL(AD.IsActive,0) = 0 THEN CAST( 1 AS BIT)
		 WHEN ISNULL(AD.IsActive,0) = 1 THEN CAST( 0 AS BIT)
		 END) AS IsPLCConnected,
		CAST(CC.ControllerNumber AS NVARCHAR) + ' ('+CC.TopicName + ')' AS DispenserName
     FROM(SELECT DISTINCT  
    MachineId,   
    DashboardId  
  FROM TCD.MonitorSetUpMapping)AS DM  
  INNER JOIN TCD.MachineSetup AS MS ON DM.MachineId = MS.WasherID  
  INNER JOIN tcd.Washer AS W ON MS.WasherId = W.WasherId  
  INNER JOIN TCD.Dashboard AS D ON DM.DashBoardId = D.DashBoardId  
		INNER JOIN TCD.ConduitController CC ON CC.ControllerId = MS.ControllerId
		LEFT JOIN TCD.AlarmData AD ON AD.ControllerId = MS.ControllerId AND IsActive = 1 AND AD.AlarmCode = 
		(CASE WHEN (SELECT VALUE FROM  TCD.controllerSetupData CSD LEFT JOIN TCD.Field F ON F.Id = CSD.FieldId  WHERE  F.Label = 'Webport Ftp Enabled' AND CSD.ControllerId = AD.ControllerId AND CC.ControllerTypeId = 1) = 'true'
			THEN 9002
			ELSE 9001
		END) 
     WHERE DM.DashboardId = @Dashboardid  
       AND MS.IsDeleted = 0  
       AND w.Is_Deleted = 0  
    -- Exclude Phony Washers from Efficiency calculation   
       AND ms.WasherId NOT IN(SELECT  
          w.WasherId  
      FROM TCD.MachineSetup AS ms  
           INNER JOIN TCD.Washer AS w ON w.WasherId = ms.WasherId  
         AND ms.EcoalabAccountNumber = w.EcoLabAccountNumber  
      WHERE (NULLIF(ms.ControllerId, 0)IS NULL  
        AND w.WasherMode = 0)  
        OR MS.IsPony = 1  
        )  
  
  
 -- For efficiency calculations on shift wise  
 IF(@EfficiencyType = 1)  
  BEGIN  
      INSERT @ShiftIds(ShiftId,ShiftStartDate,ShiftEndDate)  
      SELECT DISTINCT ShiftId,StartDateTime, EndDateTime FROM TCD.ProductionShiftData  
   WHERE GETUTCDATE() BETWEEN StartDateTime AND EndDateTime   
  -- WHERE ShiftId = 33 
      END  
        
 ELSE -- For efficiency calculations on Day wise  
  BEGIN  
   INSERT @ShiftIds(ShiftId,ShiftStartDate,ShiftEndDate)  
   SELECT ShiftId, StartDateTime, EndDateTime    
   FROM [TCD].ProductionShiftData    
   WHERE   startdatetime > CAST(GETUTCDATE()AS DATE ) and startdatetime < dateadd(dd,1,CAST(GETUTCDATE()AS DATE ))   
   ORDER BY startdatetime   
     
  END  



  
SELECT *   
INTO #BatchData  
FROM tcd.BatchData bd (NOLOCK) WHERE bd.ShiftId in (SELECT si.ShiftId FROM @ShiftIds si)  
AND bd.StandardWeight > 0  
and bd.ActualWeight > 0   
AND bd.EndDate IS NOT null

--select * from @ShiftIds
--select * from @Dashboardmachinemapping
--select * from #BatchData
  
-- Efficiency for each batch   
SELECT  bd.BatchId,  
  W_1.WasherGroupID AS GroupID,  
  W_1.WasherId AS MachineID,  
  bd.ShiftId,  
  W_1.WasherNumber,  
  W_1.WasherName,  
  (bd.ActualWeight + ISNULL(BD.ManualInputWeight,0)) AS ActualProduction,  
  bd.StandardWeight AS StandardProduction,  
  CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
   THEN W_1.StandardRunTime  
       ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
  END AS ActualRunTime,  
  W_1.StandardRunTime,  
  TT.ActualTurnTime,  
  bd.TargetTurnTime AS StandardTurnTime,  
  CASE WHEN W_1.WasherGroupTypeID = 1   
    -- Conventional  
    THEN (CAST((W_1.Standardruntime + bd.TargetTurnTime)AS FLOAT) / (CAST(CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
              THEN W_1.StandardRunTime  
              ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
             END   
    + CASE WHEN TT.ACTUALTURNTIME = 0 THEN bd.TargetTurnTime   
     ELSE TT.ACTUALTURNTIME  
      END  AS FLOAT)))  
    -- Tunnel  
   ELSE   
   (CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT) )  
    / (CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0   
          THEN W_1.Standardruntime   
          ELSE CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
            THEN W_1.StandardRunTime  
                ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
           END  
         END AS FLOAT)   
                )  
  END AS TimeEfficiency,  
  ((CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS FLOAT)/CAST(NULLIF(bd.StandardWeight,0) AS FLOAT)) * 100) AS LoadEfficiency,  
  CASE WHEN W_1.WasherGroupTypeID = 2   
      THEN  
  (100 * ((3600.00/(CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0   
       THEN NULLIF(W_1.Standardruntime,0)  
       ELSE DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
       END AS FLOAT)/W_1.NumberOfComp)) /  
       (3600.00/(CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT)/W_1.NumberOfComp))))  
   ELSE NULL  
  END AS TransferPerHr,  
  --missedloads formulae
		--------(((Actual Production/totalefficiency)*100)-actualproduction)
		
		(cast(cast(bd.ActualWeight AS decimal(18,6))/(((CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS decimal(18,6))/CAST(NULLIF(bd.StandardWeight,0) AS decimal(18,6))) * 100.0) 
  * (  CASE WHEN W_1.WasherGroupTypeID = 1   
      -- Conventional  
      THEN (CAST((W_1.Standardruntime + bd.TargetTurnTime)AS decimal(18,6)) / (CAST(CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
       THEN W_1.StandardRunTime  
           ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
                  END + TT.ACTUALTURNTIME AS FLOAT)))  
      -- Tunnel  
      ELSE   
						(CAST(NULLIF(W_1.Standardruntime,0) AS decimal(18,6)) )
							/ (CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0 
													THEN W_1.Standardruntime 
													ELSE CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold
      THEN W_1.StandardRunTime  
          ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
													    END
												END AS decimal(18,6)) 
															    )
				END)) AS decimal(18,6))*100.0)-cast(bd.ActualWeight AS decimal(18,6)) AS MissedLoads,
  --((bd.StandardWeight - bd.ActualWeight) +  
  --(CASE WHEN W_1.WasherGroupTypeID = 1   
  --  THEN  
  --   ((CAST((CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
  --     THEN W_1.StandardRunTime  
  --         ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
  --    END + TT.ACTUALTURNTIME) AS FLOAT) - W_1.Standardruntime - bd.TargetTurnTime)   
  --   * CAST((CAST(bd.StandardWeight AS FLOAT)/NULLIF((W_1.Standardruntime + bd.TargetTurnTime),0)) AS FLOAT))   
  --  ELSE ((CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
  --    THEN W_1.StandardRunTime  
  --        ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
  --   END - W_1.Standardruntime) * (CAST(bd.StandardWeight AS FLOAT)/ NULLIF(W_1.Standardruntime,0)))  
  --END)) AS MissedLoads,  
  (((CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS FLOAT)/CAST(NULLIF(bd.StandardWeight,0) AS FLOAT)) * 100)   
  * (  CASE WHEN W_1.WasherGroupTypeID = 1   
      -- Conventional  
      THEN (CAST((W_1.Standardruntime + bd.TargetTurnTime)AS FLOAT) / (CAST(CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
                   THEN W_1.StandardRunTime  
                   ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
                  END + TT.ACTUALTURNTIME AS FLOAT)))  
      -- Tunnel  
      ELSE   
      (CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT))  
       / (CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0   
             THEN W_1.Standardruntime   
             ELSE CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
                  THEN W_1.StandardRunTime  
                  ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
                 END  
            END AS FLOAT)  
                   )  
    END)) AS TotalEfficiency  ,
    W_1.MaxLoad
  
  
INTO #BatchEfficiency  
FROM #BatchData bd
--FROM TCD.BatchData bd   
RIGHT OUTER JOIN(       
                SELECT ms.EcoalabAccountNumber,      
                        ms.WasherId,      
                        ms.GroupId AS WasherGroupID,      
                        mg.WasherGroupTypeId AS WasherGroupTypeID,      
                        w.EcolabWasherId, 
                        w.MaxLoad,     
                        ISNULL(ms.NumberOfComp,0) AS NumberOfComp,      
                        CASE      
                        WHEN MG.WASHERGROUPTYPEID = 1 THEN WSP.ProgramNumber      
                            ELSE TPS.ProgramNumber      
                        END AS ProgramNumber,      
                        CASE      
                        WHEN MG.WASHERGROUPTYPEID = 1 THEN WSP.ProgramId      
       ELSE TPS.ProgramId      
                        END AS ProgramId,      
                        CASE      
       WHEN MG.WASHERGROUPTYPEID = 1   
    THEN WSP.TotalRunTime      
                            ELSE TPS.TotalRunTime      
   END AS Standardruntime,  
   w.PlantWasherNumber AS WasherNumber,  
   ms.MachineName AS WasherName,  
   mg.WasherGroupName AS MachineGroup  
   --mg.WasherGroupId AS MachineGroupID  
                    FROM TCD.MachineSetup AS ms (NOLOCK)      
                        INNER JOIN TCD.Washer AS w (NOLOCK) ON w.EcoLabAccountNumber = ms.EcoalabAccountNumber      
                                                    AND w.WasherId = ms.WasherId      
                        INNER JOIN TCD.WasherGroup AS mg (NOLOCK) ON ms.GroupId = mg.WasherGroupId      
                                                        AND w.EcoLabAccountNumber = mg.EcolabAccountNumber      
                        LEFT OUTER JOIN TCD.WasherProgramSetup AS WSP (NOLOCK) ON WSP.WasherGroupId = mg.WasherGroupId      
                                                                    AND WSP.EcolabAccountNumber = mg.EcolabAccountNumber      
                 AND WSP.Is_Deleted = 0  
                                                                    --AND WSP.WasherGroupId = ms.GroupId      
                        LEFT OUTER JOIN TCD.TunnelProgramSetup AS TPS (NOLOCK) ON TPS.WasherGroupId = mg.WasherGroupId      
                                                                    AND TPS.EcolabAccountNumber = mg.EcolabAccountNumber      
                 AND TPS.Is_Deleted = 0   
                                                                    --AND TPS.WasherGroupId = ms.GroupId   
   RIGHT JOIN @Dashboardmachinemapping DM1 ON DM1.GroupID = ms.GroupId   
      AND DM1.WasherId = ms.WasherId  
   WHERE ms.IsTunnel = 0   
   AND ms.IsDeleted = 0  
   ) AS W_1 ON BD.GroupId = W_1.WasherGroupID      
                                    AND ISNULL(BD.EcolabWasherId,0) = ISNULL(W_1.EcolabWasherId,0)  
        AND bd.MachineID = W_1.WasherId  
                                    AND BD.ProgramMasterId = W_1.ProgramId      
                                    AND BD.ProgramNumber = W_1.ProgramNumber  
LEFT JOIN [TCD].[Turntime] TT ON ISNULL(BD.EcolabwasherID,0) = ISNULL(TT.EcolabWasherId,0) AND BD.batchid = TT.BatchID  
WHERE DATEDIFF(ss, bd.StartDate, bd.EndDate) > (W_1.Standardruntime * 10/100)  
--bd.ShiftId IN (SELECT si.ShiftId FROM @ShiftIds si)  
--AND bd.ActualWeight > 0   
--AND bd.StandardWeight > 0  
--AND DATEDIFF(ss, bd.StartDate, bd.EndDate) > (W_1.Standardruntime * 10/100)  
--AND bd.EndDate IS NOT NULL   
  
  
 -- Efficiency by Machine calculation   
 SELECT DM.GroupID,   
  DM.WasherId AS MachineID,  
  DM.WasherNumber,  
  DM.WasherName,  
  CAST(sum(t.ActualProduction) AS FLOAT) AS ActualProduction,  
  CAST(sum(t.StandardProduction) AS FLOAT) AS StandardProduction,  
  SUM(t.ActualRunTime) AS ActualRuntime,  
  SUM(t.StandardRunTime) AS StandardRunTime,  
  (SUM(t.MissedLoads)/count(DISTINCT t.BatchId)) AS MissedLoads,  
  (CAST(sum(t.LoadEfficiency) AS FLOAT) / count(DISTINCT t.BatchId)) AS LoadEfficiency,  
  ((CAST(sum(t.TimeEfficiency) AS FLOAT) / count(DISTINCT t.BatchId))*100)  AS TimeEfficiency,  
		((CAST(sum(t.LoadEfficiency) AS FLOAT) / count(DISTINCT t.BatchId)) * (CAST(sum(t.TimeEfficiency) AS FLOAT) / count(DISTINCT t.BatchId))) AS TotalEfficiency,
		DM.IsPLCConnected AS IsPLCConnected,
		DM.DispenserName,
	(SUM(t.MissedLoads)/count(DISTINCT t.BatchId))/max(t.MaxLoad) AS LostBatches	
 INTO #MachineEfficiency  
 FROM @Dashboardmachinemapping DM   
 LEFT JOIN #BatchEfficiency t ON DM.GroupID = t.GroupId AND dm.WasherId = t.MachineId  
 --AND t.ActualRunTime > (t.StandardRunTime * 10/100)  
 GROUP BY DM.GroupID,   
 DM.WasherId,  
 DM.WasherNumber,  
	DM.WasherName,
	DM.IsPLCConnected,
	DM.DispenserName
	

--SELECT * FROM #BatchEfficiency
--SELECT * FROM #MachineEfficiency
  
/*  
 -- Efficiency by Machine calculation   
 SELECT t.GroupID,   
  t.MachineId,  
  t.WasherNumber,  
  t.WasherName,  
  CAST(sum(t.ActualProduction) AS FLOAT) AS ActualProduction,  
  CAST(sum(t.StandardProduction) AS FLOAT) AS StandardProduction,  
  SUM(t.ActualRunTime) AS ActualRuntime,  
  SUM(t.StandardRunTime) AS StandardRunTime,  
  (SUM(t.MissedLoads)/count(DISTINCT t.BatchId)) AS MissedLoads,  
  (CAST(sum(t.LoadEfficiency) AS FLOAT) / count(DISTINCT t.BatchId)) AS LoadEfficiency,  
  ((CAST(sum(t.TimeEfficiency) AS FLOAT) / count(DISTINCT t.BatchId))*100)  AS TimeEfficiency,  
  ((CAST(sum(t.LoadEfficiency) AS FLOAT) / count(DISTINCT t.BatchId)) * (CAST(sum(t.TimeEfficiency) AS FLOAT) / count(DISTINCT t.BatchId))) AS TotalEfficiency  
 INTO #MachineEfficiency  
 FROM #BatchEfficiency t  
 RIGHT JOIN @Dashboardmachinemapping DM ON DM.GroupID = t.GroupId   
      AND dm.WasherId = t.MachineId  
 WHERE ActualRunTime > (t.StandardRunTime * 10/100)  
 GROUP BY t.GroupID,   
 t.MachineId,  
 t.WasherNumber,  
 t.WasherName  
*/  
    
  
 INSERT @AlarmByMachine  
 (  
     GroupID,  
     WasherID,  
     Alarm,  
     AlarmDescription  
 )  
 SELECT AlarmByMachine.GroupID, AlarmByMachine.WasherID, AlarmByMachine.Alarm, AlarmByMachine.AlarmDescription   
 FROM (  
     SELECT ROW_NUMBER() OVER (PARTITION BY AD.MachineId ORDER BY AD.StartDate DESC) AS rownum  
     , AD.IsActive AS Alarm, AM.[Description] AS AlarmDescription  
     , AD.MachineId AS WasherID  
     , d.GroupID  
     FROM TCD.AlarmData AD   
	    INNER JOIN TCD.AlarmGroupMaster AM on AM.AlarmGroupMasterId = AD.AlarmGroupMasterId
     INNER JOIN @Dashboardmachinemapping d ON AD.MachineId = D.WasherId  
     ) AS AlarmByMachine  
 WHERE rownum = 1  
  
 INSERT @BatchEndtimes  
 (  
     GroupID,  
     WasherID,  
     CurrentBatchEndTime,  
     BatchEndTime  
 )  
 SELECT d.GroupID, d.WasherId,   
 COUNT(CASE WHEN bd.EndDate IS NULL THEN 1 ELSE NULL END) AS CurrentBatchEndTime,  
 CAST(MAX(bd.EndDate) AS TIME) AS BatchEndTime  
 FROM @DashboardMachineMapping d  
 INNER JOIN TCD.BatchData bd ON d.GroupID = bd.GroupId AND d.WasherId = bd.MachineId  
 WHERE bd.ShiftId IN (  
 SELECT ShiftId FROM @ShiftIds)  
 GROUP BY d.GroupID, d.WasherId  
  
  
 SELECT @StandardTurnTime = ISNULL(ConStdTurnTime,30)  From tcd.Plant  
 SELECT @StandardTurnTime = @StandardTurnTime + ISNULL(TargetTurnTime,0)  From tcd.Washer Where WasherId = @WasherId  
  
 SELECT @MachineNameDispalyType=ISNULL( MachineNameDispalyType,0) FROM TCD.Dashboard D WHERE D.DashboardId=@DashBoardId  
  
  
 INSERT INTO @Summarizeddata(  
  GroupId,  
  MachineId,  
  WasherName ,  
  WasherNumber,  
  TargetLoad,  
  ActualLoad,  
  LoadEfficiency,  
  TimeEfficiency,  
  LostLoad,  
  Alarm,  
  AlarmDescription,  
  WasherStatus,  
  MachineNameDispalyType,  
  TargetTurnTime,  
		DefaultIdleTime,
		IsPLCConnected,
		DispenserName,
		LostBatches
  )  
  SELECT me.GroupID,  
  me.MachineID,  
  me.WasherName,  
  me.WasherNumber,  
  me.StandardProduction AS TargetLoad,  
  me.ActualProduction AS ActulaLoad,  
  me.LoadEfficiency,  
  me.TimeEfficiency,  
  me.MissedLoads AS LostLoad,  
  ISNULL(abm.Alarm,0) AS Alarm,  
  abm.AlarmDescription,  
  CASE   
      WHEN be.CurrentBatchEndTime = 1 THEN 1  
      WHEN CAST(GETUTCDATE() AS TIME) BETWEEN be.BatchEndTime AND DateAdd(Minute,@StandardTurnTime,be.BatchEndTime) THEN 2  
      WHEN abm.Alarm = 1 THEN 3  
      ELSE 3  
  END AS WasherStatus,  
  @MachineNameDispalyType,  
  ( SELECT TargetTurnTime FROM TCD.WASHER W WHERE W.WasherId=ME.MachineID),  
		  ( SELECT DefaultIdleTime FROM TCD.WASHER W WHERE W.WasherId=ME.MachineID),
		  me.IsPLCConnected,
		me.DispenserName,
		me.LostBatches
  FROM #MachineEfficiency me  
  LEFT JOIN @AlarmByMachine abm on ME.GroupID = abm.GroupID AND ME.MachineID = ABM.WasherID  
  LEFT JOIN @BatchEndtimes be ON me.GroupID = be.GroupID AND me.MachineID = be.WasherID  
  
 SELECT  
  GroupId,   
  MachineId,   
  CASE @Machinenamedispalytype  
      WHEN 0 THEN CAST(WasherNumber AS VARCHAR(20)) + ' ' + WasherName  
      WHEN 1 THEN WasherName  
      WHEN 2 THEN CAST(WasherNumber AS VARCHAR(20))  
  END AS WasherName,   
  WasherNumber,   
  TargetLoad,   
  ActualLoad,   
  LoadEfficiency,   
  TimeEfficiency,   
  LostLoad,   
  Alarm,   
  AlarmDescription,   
  WasherStatus,  
  TargetTurnTime,  
		DefaultIdleTime,
		IsPLCConnected,
		DispenserName,
		LostBatches
     FROM @Summarizeddata  
     ORDER BY  
  WasherNumber  
  
  
---- CleanUp  
DROP TABLE #BatchData
DROP TABLE #BatchEfficiency  
DROP TABLE #MachineEfficiency  
  
END
GO





IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetBatchSummarizedData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetBatchSummarizedData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


Create PROCEDURE [TCD].[GetBatchSummarizedData] (  
            @DashBoardId INT = NULL   
            )   
  
AS   
BEGIN   
  
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED  
    SET NOCOUNT ON  
  
  
     DECLARE   --@DashBoardId INT = 2,
        @Efficiencytype INT,  
 @OvernightBatchThreshold INT = 7200 -- mins  
      
     DECLARE @DashboardMachineMapping TABLE(  
         Id INT,  
         GroupId INT,  
         WasherId INT,  
         DisplayCustomer BIT,  
  WasherName NVARCHAR(100),   
	 WasherNumber INT,
	 IsPLCConnected BIT,
	 DispenserName VARCHAR(250))
  
      DECLARE @Summarizeddata TABLE(  
        GroupId INT,  
        TunnelName Nvarchar(100),  
        TargetLoad FLOAT,  
        ActualLoad FLOAT,  
 LoadEfficiency FLOAT,  
        TimeEfficiency FLOAT,  
        LostLBS FLOAT,  
        TransferPerHr FLOAT,  
        SignalStatus INT,          
        EmptyPockets INT,  
        Alarm Bit,  
        TransferPercent DECIMAL(10,2),  
        EndOfFormula INT,  
        DisplayCustomer BIT,  
        WasherNumber INT,
		IsPLCConnected BIT,
		DispenserName VARCHAR(250),
		LostBatches Decimal(18,6)
        )  
          
 DECLARE @ShiftIds TABLE(  
 ShiftId INT,  
 ShiftStartDate DATETIME,  
 ShiftEndDate DATETIME  
 )  
  
 SELECT  
  @Efficiencytype = ISNULL(EfficiencyCalcType, 1)  
     FROM tcd.Dashboard  
     WHERE DashboardId = @Dashboardid  
  
      INSERT INTO @DashboardMachineMapping  
        (  
            Id,  
            GroupId,  
            WasherId,  
     DisplayCustomer,  
     WasherName,  
	    WasherNumber,
		IsPLCConnected,
		DispenserName
        )  
    SELECT   
    ROW_NUMBER() OVER(ORDER BY GroupID) AS Id,  
    A.GroupId,  
    A.WasherId,  
    A.Customer,  
    A.WasherName,  
    A.WasherNumber,
	A.IsPLCConnected,
	DispenserName
    FROM  
    (SELECT DISTINCT  
     MS.GroupId,MS.WasherId,D.Customer,MS.MachineName AS WasherName, w.PlantWasherNumber AS WasherNumber,
	 (CASE WHEN ISNULL(IsActive,0) = 0 THEN CAST( 1 AS BIT)
	 WHEN ISNULL(IsActive,0) = 1 THEN CAST( 0 AS BIT)
	 END) AS IsPLCConnected,
	  CAST(CC.ControllerNumber AS NVARCHAR) + ' ('+CC.TopicName + ')' AS DispenserName
     FROM TCD.MonitorSetUpMapping DM   
        INNER JOIN TCD.MachineSetup MS ON DM.MachineId = MS.WasherID  
        INNER JOIN TCD.Dashboard D on DM.DashBoardId = D.DashBoardId  
 INNER JOIN TCD.Washer w ON ms.WasherId = w.WasherId  
		INNER JOIN TCD.ConduitController CC ON CC.ControllerId = MS.ControllerId
		LEFT JOIN TCD.AlarmData AD ON AD.ControllerId = MS.ControllerId AND IsActive = 1 AND AD.AlarmCode = 
		(CASE WHEN (SELECT VALUE FROM  TCD.controllerSetupData CSD LEFT JOIN TCD.Field F ON F.Id = CSD.FieldId  WHERE  F.Label = 'Webport Ftp Enabled' AND CSD.ControllerId = AD.ControllerId AND CC.ControllerTypeId = 1) = 'true'
			THEN 9002
			ELSE 9001
		END) 
    WHERE DM.DashboardId = @DashBoardId  
    AND ms.IsDeleted = 0  
    AND w.Is_Deleted = 0   
    )A;  
   
  
  
 -- For efficiency calculations on shift wise  
 IF @Efficiencytype = 1  
     BEGIN  
  
  INSERT INTO @Shiftids(shiftId,ShiftStartDate, ShiftEndDate)  
  SELECT DISTINCT ShiftId, StartDateTime, EndDateTime  
  FROM TCD.ProductionShiftData  
 -- WHERE ShiftId = 1103 
  WHERE GETUTCDATE() BETWEEN StartDateTime AND EndDateTime   
  
     END  
 ELSE -- For efficiency calculations on Day wise  
     BEGIN  
  
  INSERT @Shiftids(ShiftId, ShiftStartDate, ShiftEndDate)  
  SELECT DISTINCT ShiftId, StartDateTime, EndDateTime  
  FROM TCD.ProductionShiftData  
  WHERE startdatetime > CAST(GETUTCDATE()AS DATE)  
  AND startdatetime < DATEADD(dd, 1, CAST(GETUTCDATE()AS DATE))  
  
     END    

--select * from @ShiftIds
--select * from @DashboardMachineMapping
  
  
SELECT *   
INTO #BatchData  
FROM tcd.BatchData bd (NOLOCK) WHERE bd.ShiftId in (SELECT si.ShiftId FROM @ShiftIds si)  
AND bd.StandardWeight > 0  
and bd.ActualWeight > 0   
AND bd.EndDate IS NOT null


--select * from #BatchData  
  
-- Efficiency for each batch   
SELECT  bd.BatchId,  
  bd.GroupID,  
  bd.MachineID,  
  bd.ShiftId,  
  W_1.WasherNumber,  
  W_1.WasherName,  
  (bd.ActualWeight + ISNULL(BD.ManualInputWeight,0)) AS ActualProduction,  
  bd.StandardWeight AS StandardProduction,  
  --DATEDIFF(ss,bd.StartDate, bd.EndDate) AS ActualRunTime,  
  CASE WHEN DATEDIFF(mi,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OvernightBatchThreshold   
   THEN W_1.Standardruntime   
       ELSE DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
  END AS ActualRunTime,  
  W_1.StandardRunTime,  
  NULL AS ActualTurnTime,  
  bd.TargetTurnTime AS StandardTurnTime,  
  CASE WHEN W_1.WasherGroupTypeID = 2   THEN
    ---- Conventional  
    --THEN (CAST((W_1.Standardruntime + bd.TargetTurnTime)AS FLOAT) / (CAST(CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
    --          THEN W_1.StandardRunTime  
    --          ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
    --         END   
    --+ CASE WHEN TT.ACTUALTURNTIME = 0 THEN bd.TargetTurnTime   
    -- ELSE TT.ACTUALTURNTIME  
    --  END  AS FLOAT)))  
    ---- Tunnel  
   --ELSE   
   (CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT) )  
    / (CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0   
          THEN W_1.Standardruntime   
          ELSE CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
            THEN W_1.StandardRunTime  
                ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
           END  
         END AS FLOAT)   
                )  
  END AS TimeEfficiency,  
  ((CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS FLOAT)/CAST(NULLIF(bd.StandardWeight,0) AS FLOAT)) * 100) AS LoadEfficiency,  
  CASE WHEN W_1.WasherGroupTypeID = 2   
      THEN  
  (3600.00/(CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0   
       THEN NULLIF(W_1.Standardruntime,0)  
       ELSE DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
       END AS FLOAT)/W_1.NumberOfComp))   
   ELSE NULL  
  END AS TransferPerHr,  
  
  --missedloads formulae
		--------(((Actual Production/totalefficiency)*100)-actualproduction)
		
		(cast((cast(bd.ActualWeight AS decimal(18,6))/(((CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS decimal(18,6))/CAST(NULLIF(bd.StandardWeight,0) AS decimal(18,2))) * 100.0) 
  * (  CASE WHEN W_1.WasherGroupTypeID = 2   THEN
      ---- Conventional  
      --THEN (CAST((W_1.Standardruntime + bd.TargetTurnTime)AS FLOAT) / (CAST(CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
      --             THEN W_1.StandardRunTime  
      --             ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
      --            END + TT.ACTUALTURNTIME AS FLOAT)))  
      ---- Tunnel  
      --ELSE   
						(CAST(NULLIF(W_1.Standardruntime,0) AS decimal(18,6)) )
       / (CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0   
             THEN W_1.Standardruntime   
             ELSE CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
                  THEN W_1.StandardRunTime  
                  ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
                 END  
												END AS decimal(18,6)) 
															    )
				END))) AS decimal(18,6))*100.0)-cast(bd.ActualWeight AS decimal(18,6)) AS MissedLoads,
 -- ((bd.StandardWeight - bd.ActualWeight) +  
 -- (CASE WHEN W_1.WasherGroupTypeID = 2 THEN   
 --   --THEN  
 --   -- ((CAST((CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
 --   --   THEN W_1.StandardRunTime  
 --   --       ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
 --   --  END + TT.ACTUALTURNTIME) AS FLOAT) - W_1.Standardruntime - bd.TargetTurnTime)   
 --   -- * CAST((CAST(bd.StandardWeight AS FLOAT)/NULLIF((W_1.Standardruntime + bd.TargetTurnTime),0)) AS FLOAT))   
 --   --ELSE 
	--((CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
 --     THEN W_1.StandardRunTime  
 --         ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
 --    END - W_1.Standardruntime) * (CAST(bd.StandardWeight AS FLOAT)/ NULLIF(W_1.Standardruntime,0)))  
 -- END)) AS MissedLoads,  
  (((CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS FLOAT)/CAST(NULLIF(bd.StandardWeight,0) AS FLOAT)) * 100)   
  * (  CASE WHEN W_1.WasherGroupTypeID = 2   THEN
      ---- Conventional  
      --THEN (CAST((W_1.Standardruntime + bd.TargetTurnTime)AS FLOAT) / (CAST(CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
      --             THEN W_1.StandardRunTime  
      --             ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
      --            END + TT.ACTUALTURNTIME AS FLOAT)))  
      ---- Tunnel  
      --ELSE   
      (CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT) )  
       / (CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0   
                    THEN W_1.Standardruntime   
                    ELSE CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
                      THEN W_1.StandardRunTime  
                   ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
                     END  
            END AS FLOAT)   
                   )  
    END)) AS TotalEfficiency  ,
    w_1.maxload
  
INTO #BatchEfficiency  
FROM #BatchData bd  
--FROM TCD.BatchData bd   
INNER JOIN(       
                SELECT ms.EcoalabAccountNumber,      
                        ms.WasherId,      
                        ms.GroupId AS WasherGroupID,      
                        mg.WasherGroupTypeId AS WasherGroupTypeID,      
                        w.EcolabWasherId,      
                        ISNULL(ms.NumberOfComp,0) AS NumberOfComp,      
                        CASE      
                        WHEN MG.WASHERGROUPTYPEID = 1 THEN WSP.ProgramNumber      
                            ELSE TPS.ProgramNumber      
                        END AS ProgramNumber,      
                        CASE      
                        WHEN MG.WASHERGROUPTYPEID = 1 THEN WSP.ProgramId      
       ELSE TPS.ProgramId      
                        END AS ProgramId,      
                        CASE      
       WHEN MG.WASHERGROUPTYPEID = 1   
    THEN WSP.TotalRunTime      
                            ELSE TPS.TotalRunTime      
   END AS Standardruntime,  
   w.PlantWasherNumber AS WasherNumber,  
   ms.MachineName AS WasherName,  
   mg.WasherGroupName AS MachineGroup,  
   ms.IsTunnel , 
   w.maxload
   --mg.WasherGroupId AS MachineGroupID  
                    FROM TCD.MachineSetup AS ms (NOLOCK)      
                        INNER JOIN TCD.Washer AS w (NOLOCK) ON w.EcoLabAccountNumber = ms.EcoalabAccountNumber      
                                                    AND w.WasherId = ms.WasherId      
                        INNER JOIN TCD.WasherGroup AS mg (NOLOCK) ON ms.GroupId = mg.WasherGroupId      
                                                        AND w.EcoLabAccountNumber = mg.EcolabAccountNumber      
                        LEFT OUTER JOIN TCD.WasherProgramSetup AS WSP (NOLOCK) ON WSP.WasherGroupId = mg.WasherGroupId      
                                                                    AND WSP.EcolabAccountNumber = mg.EcolabAccountNumber      
                                                                    --AND WSP.WasherGroupId = ms.GroupId      
                 AND WSP.Is_Deleted = 0  
                        LEFT OUTER JOIN TCD.TunnelProgramSetup AS TPS (NOLOCK) ON TPS.WasherGroupId = mg.WasherGroupId      
                                                                    AND TPS.EcolabAccountNumber = mg.EcolabAccountNumber      
                                                                    --AND TPS.WasherGroupId = ms.GroupId   
                 AND TPS.Is_Deleted = 0   
   WHERE ms.IsTunnel = 1  
   ) AS W_1 ON BD.GroupId = W_1.WasherGroupID      
       AND BD.MachineId = W_1.WasherId      
       AND BD.ProgramMasterId = W_1.ProgramId      
       AND BD.ProgramNumber = W_1.ProgramNumber  
--LEFT JOIN [TCD].[Turntime] TT (NOLOCK) ON --ISNULL(BD.EcolabwasherID,0) = ISNULL(TT.EcolabWasherId,0)   
--    BD.batchid = TT.BatchID   
    --AND bd.MachineId = tt.MachineId  
--WHERE bd.ShiftId IN (SELECT si.ShiftId FROM @ShiftIds si)  
--AND bd.ActualWeight > 0   
--AND bd.StandardWeight > 0  
--AND DATEDIFF(ss, bd.StartDate, bd.EndDate) > (W_1.Standardruntime * 10/100)  
--AND bd.EndDate IS NOT NULL  
  
 
  
 -- Efficiency by Machine calculation   
 SELECT DM.GroupID,   
  DM.WasherId AS MachineID,  
  DM.WasherNumber,  
  DM.WasherName,  
  CAST(sum(t.ActualProduction) AS FLOAT) AS ActualProduction,  
  CAST(sum(t.StandardProduction) AS FLOAT) AS StandardProduction,  
  SUM(t.ActualRunTime) AS ActualRuntime,  
  SUM(t.StandardRunTime) AS StandardRunTime,  
  (SUM(t.MissedLoads)) AS MissedLoads,  
  (CAST(sum(t.LoadEfficiency) AS FLOAT) / count(DISTINCT t.BatchId)) AS LoadEfficiency,  
  (CAST(sum(t.TimeEfficiency) AS FLOAT) / count(DISTINCT t.BatchId)) AS TimeEfficiency,  
  (CAST(SUM(t.TransferPerHr) AS FLOAT)/ count(DISTINCT t.BatchId)) AS TransferPerHour,  
		((CAST(sum(t.LoadEfficiency) AS FLOAT) / count(DISTINCT t.BatchId)) * (CAST(sum(t.TimeEfficiency) AS FLOAT) / count(DISTINCT t.BatchId))) AS TotalEfficiency,
		DM.IsPLCConnected AS IsPLCConnected,
		DM.DispenserName,
	 (SUM(t.MissedLoads))/max(t.maxload) AS LostBatches	
 INTO #MachineEfficiency  
 FROM @Dashboardmachinemapping DM   
 LEFT JOIN #BatchEfficiency t ON DM.GroupID = t.GroupId AND dm.WasherId = t.MachineId  
 GROUP BY DM.GroupID,   
  DM.WasherId,  
  DM.WasherNumber,  
		DM.WasherName,
		DM.IsPLCConnected,
		DM.DispenserName
		
  
  
      DECLARE @EmptyPocketNAlarmddata TABLE(  
     GroupId INT,  
     WasherID INT,  
     EndOfFormula  INT,  
     DisplayCustomer Decimal(18,2),  
     EmptyPockets INT,  
     MachineNameDispalyType INT,  
     EmptyPocketLoad Decimal(18,2),  
     Alarm bit,  
     WasherStatus bit  
 )  
  
    INSERT @EmptyPocketNAlarmddata    (GroupId,WasherID,EndOfFormula,DisplayCustomer,EmptyPockets,MachineNameDispalyType, EmptyPocketLoad,Alarm,WasherStatus)  
    SELECT  D.GroupId,   
     D.WasherId,   
     w.EmptyPocketNumber AS EndOfFormula,   
     D.DisplayCustomer,   
     A.EmptyPockets,   
     (SELECT SUM(ISNULL(MachineNameDispalyType,0)) FROM TCD.Dashboard D1  
  INNER JOIN TCD.[MonitorSetUpMapping] MSM ON D1.DashboardId=MSM.DashboardId    
  WHERE MSM.MachineId=D.WasherId and D1.DashboardId=@DashBoardId  
  ) as MachineNameDispalyType,  
     sum(w.MaxLoad) AS EmptyPocketLoad,  
     NULL AS alarm,  
     sum(CASE WHEN B.WasherStatus > 0 THEN 1 ELSE 0 END) AS WasherStatus  
    FROM TCD.Washer AS w   
    INNER JOIN @DashboardMachineMapping AS D ON w.WasherId = d.WasherId  
    CROSS APPLY  (  
 SELECT COUNT(*) As EmptyPockets from TCD.BatchData AS b JOIN @ShiftIds AS s ON b.ShiftId = s.ShiftId   
 WHERE b.StartDate >= s.ShiftStartDate   
 AND b.GroupId = d.GroupId   
 AND b.ProgramNumber = w.EmptyPocketNumber  
       ) AS A  
    CROSS APPLY (  
 SELECT Count(*) as WasherStatus  
 from tcd.BatchData where MachineId = d.WasherId AND GroupId= D.GroupId and (EndDate >= DATEADD(mi,-30,GETUTCDATE()) OR EndDate is NULL)  
 ) AS B  
    GROUP BY D.GroupId, D.WasherId, w.EmptyPocketNumber, D.DisplayCustomer, A.EmptyPockets  
  
  
    UPDATE X   
    SET X.Alarm = ISNULL(Alarm.IsActive,0)  
    FROM @EmptyPocketNAlarmddata X  
    CROSS APPLY (   
 SELECT TOP 1 AD.IsActive  
     FROM [TCD].AlarmData AD   
     WHERE GroupId = X.GroupId  
     ORDER BY StartDate DESC  
  ) AS Alarm  
  
  
  
INSERT INTO @Summarizeddata(GroupId,TunnelName,TargetLoad,ActualLoad,LoadEfficiency, TimeEfficiency,  
        LostLBS,TransferPerHr,SignalStatus,EmptyPockets,Alarm,TransferPercent,EndOfFormula,DisplayCustomer,WasherNumber,IsPLCConnected, DispenserName,lostbatches)
 SELECT  me.GroupID,   
  CASE epn.MachineNameDispalyType   
     WHEN 0 THEN CAST( me.WasherNumber AS varchar(20))+' '+  me.WasherName  
     WHEN 1 THEN me.WasherName  
     WHEN 2 THEN CAST( me.WasherNumber AS varchar(20))          
  END AS TunnelName,  
  me.StandardProduction,   
  me.ActualProduction,   
  me.LoadEfficiency,  
  me.TimeEfficiency,   
  me.MissedLoads,  
  me.TransferPerHour,  
  epn.WasherStatus,  
  epn.EmptyPockets,  
  ISNULL(epn.Alarm,0) AS Alarm,  
  0 AS TransferPercent,  
  epn.EndOfFormula,  
  epn.DisplayCustomer,  
	 me.WasherNumber,
	 me.IsPLCConnected AS IsPLCConnected,
	 me.DispenserName AS DispenserName,
	 me.LostBatches
 from #MachineEfficiency me  
 LEFT JOIN @EmptyPocketNAlarmddata epn ON me.GroupID = epn.GroupId AND me.MachineID = epn.WasherID  
   
     SELECT  GroupId,  
     TunnelName,  
     TargetLoad,  
     ActualLoad,  
     LoadEfficiency,  
     TimeEfficiency,  
     LostLBS,  
     TransferPerHr,  
     SignalStatus,          
     EmptyPockets,  
     Alarm,  
     TransferPercent,  
     EndOfFormula,  
     DisplayCustomer,  
	    WasherNumber,
		IsPLCConnected,
		DispenserName,
		LostBatches
    FROM @Summarizeddata    
    ORDER BY WasherNumber  
  
-- CleanUp  
DROP TABLE #BatchData
DROP TABLE #BatchEfficiency  
DROP TABLE #MachineEfficiency  
  
END
GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetShiftSummaryDetails]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetShiftSummaryDetails]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE TCD.GetShiftSummaryDetails 
AS
    BEGIN
        SET NOCOUNT ON;
            DECLARE @Washerdashboardid INT, 
                    @Tunneldashboardid INT, 
                    @Shiftname         NVARCHAR(1000) = NULL,
		    @Actualloads           FLOAT, 
                    @Lostloads             FLOAT, 
                    @Efficiency            FLOAT, 
                    @Cummulativeefficiency FLOAT;

            DECLARE @Washershiftdata TABLE(
                    GroupId          INT, 
                    MachineId        INT, 
                    WasherName       NVARCHAR(100), 
                    WasherNumber     INT, 
                    TargetLoad       FLOAT, 
                    ActualLoad       FLOAT, 
                    LoadEfficiency   FLOAT, 
                    TimeEfficiency   FLOAT, 
                    LostLoad         FLOAT, 
                    Alarm            BIT, 
                    AlarmDescription NVARCHAR(250), 
                    WasherStatus     INT,
				TargetTurnTime INT,
				DefaultIdleTime INT,
				IsPLCConnected BIT,
		DispenserName VARCHAR(250),
		Lostbatches Decimal(18,6));

            DECLARE @Tunnelshiftdata TABLE(
                    GroupId         INT, 
                    TunnelName      NVARCHAR(100), 
                    TargetLoad      FLOAT, 
                    ActualLoad      FLOAT, 
                    LoadEfficiency  FLOAT, 
                    TimeEfficiency  FLOAT, 
                    LostLBS         FLOAT, 
                    TransferPerHr   FLOAT, 
                    SignalStatus    INT, 
                    EmptyPockets    INT, 
                    Alarm           BIT, 
                    TransferPercent DECIMAL(10, 2), 
                    EndOfFormula    INT, 
                    DisplayCustomer BIT, 
                    WasherNumber    INT,
					IsPLCConnected BIT,
		DispenserName VARCHAR(250),
		Lostbatches Decimal(18,6));

            SET @Washerdashboardid = (SELECT TOP 1
                                              D.DashboardId
                                          FROM TCD.Dashboard AS D
                                               INNER JOIN
                                               TCD.WasherGroupType AS wgt ON wgt.WasherGroupTypeId = D.TypeId
                                          WHERE wgt.WasherGroupTypeName = 'Conventional'
                                          ORDER BY
                                              D.DashboardId);
            SET @Tunneldashboardid = (SELECT TOP 1
                                              D.DashboardId
                                          FROM TCD.Dashboard AS D
                                               INNER JOIN
                                               TCD.WasherGroupType AS wgt ON wgt.WasherGroupTypeId = D.TypeId
                                          WHERE wgt.WasherGroupTypeName = 'Tunnel'
                                          ORDER BY
                                              D.DashboardId);
            SELECT DISTINCT
                    @Shiftname = ShiftName
                FROM TCD.ProductionShiftData
                WHERE GETUTCDATE() BETWEEN StartDateTime AND EndDateTime;

            INSERT INTO @Washershiftdata
                   (
                    GroupId, 
                    MachineId, 
                    WasherName, 
                    WasherNumber, 
                    TargetLoad, 
                    ActualLoad, 
                    LoadEfficiency, 
                    TimeEfficiency, 
                    LostLoad, 
                    Alarm, 
                    AlarmDescription, 
                    WasherStatus,
				TargetTurnTime ,
				DefaultIdleTime,
				IsPLCConnected,
				DispenserName,
				Lostbatches 
                   )
            EXEC TCD.GetWasherBatchSummarizedData
                 @Dashboardid = @Washerdashboardid;

            INSERT INTO @Tunnelshiftdata
                   (
                    GroupId, 
                    TunnelName, 
                    TargetLoad, 
                    ActualLoad, 
                    LoadEfficiency, 
                    TimeEfficiency, 
                    LostLBS, 
                    TransferPerHr, 
                    SignalStatus, 
                    EmptyPockets, 
                    Alarm, 
                    TransferPercent, 
                    EndOfFormula, 
                    DisplayCustomer, 
                    WasherNumber,
					IsPLCConnected,
					DispenserName,
					Lostbatches
                   )
            EXEC TCD.GetBatchSummarizedData
                 @Dashboardid = @Tunneldashboardid;


	    -- Calculate Actual Production and Lost Loads 
            SELECT
                    @Actualloads = SUM(CD.ActualLoad), 
                    @Lostloads = SUM(CD.LostLoad)
                FROM(
                    SELECT
                            w.ActualLoad, 
                            w.LostLoad FROM @Washershiftdata AS w
                    UNION ALL
                    SELECT
                            t.ActualLoad, 
                            t.LostLBS AS LostLoad FROM @Tunnelshiftdata AS t) AS CD;
            
	    -- Calculate Efficiency for conventional and tunnel
	    SELECT
                    @Cummulativeefficiency = SUM(T.Efficiency)
                FROM(
                    SELECT
                            ActualLoad, 
                            TimeEfficiency, 
                            CAST(ActualLoad / TimeEfficiency AS FLOAT) AS Efficiency
                        FROM @Washershiftdata
                    UNION ALL
                    SELECT
                            ActualLoad, 
                            LoadEfficiency * TimeEfficiency AS TimeEfficiency, 
                            CAST(ActualLoad / (LoadEfficiency * TimeEfficiency) AS FLOAT)
                        FROM @Tunnelshiftdata) AS T;
            -- Calculate Overall Efficiency
	    SET @Efficiency = @Actualloads / @Cummulativeefficiency;

            SELECT
                    ISNULL(@Actualloads, 0.00) AS TotalLoad, 
                    ISNULL(@Efficiency, 0.00) AS Efficiency, 
                    ISNULL(@Lostloads, 0.00) AS LostLoads, 
                    ISNULL(@Shiftname, 'No Shift Available') AS ShiftName;
    END;
GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[DeleteConventional]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[DeleteConventional]
END
GO

/*	
Purpose					:	To delete a Conventional Washer from the Washers grid UI
History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version
*/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE	PROCEDURE	[TCD].[DeleteConventional](
@EcoLabAccountNumber	NVARCHAR(1000)
,@WasherId	INT
,@UserId	INT
,@LastModifiedTimestampAtCentral DATETIME =	NULL
,@OutputLastModifiedTimestampAtLocal DATETIME =	NULL OUTPUT)
AS
BEGIN
SET	NOCOUNT	ON
DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()
	,	@WashgroupId					INT				=			NULL
	,	@ControllerId					INT				=			NULL
	,	@ControllerModelId				INT				=			NULL

DECLARE @OutputList AS	TABLE ( LastModifiedTimestamp DATETIME )

SET		@OutputLastModifiedTimestampAtLocal	 =	 ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight


--Valid Washer - Id & Type...
IF	NOT	EXISTS	(	SELECT	1
					FROM	[TCD].Washer						W
					JOIN	[TCD].MachineSetup					MS
						ON	W.WasherId					=			MS.WasherId
						AND	W.EcoLabAccountNumber		=			MS.EcoalabAccountNumber
					WHERE	W.EcoLabAccountNumber		=			@EcoLabAccountNumber
						AND	W.WasherId					=			@WasherId
						AND	W.Is_Deleted				=			'FALSE'
						AND	MS.IsDeleted				=			'FALSE'
				)
			BEGIN
				SET		@ErrorId						=			51007
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Washer-ID or Type was provided.'
				RAISERROR	(@ErrorMessage, 16, 1)
				SET		@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


IF	( @LastModifiedTimestampAtCentral IS NOT NULL
			AND NOT	EXISTS	( SELECT	1 FROM	TCD.Washer W
								WHERE	W.EcolabAccountNumber	=	@EcolabAccountNumber AND	W.WasherId	 =	@WasherId
								AND	W.LastModifiedTime = @LastModifiedTimestampAtCentral )
				)
		BEGIN
				SET			@ErrorId				=	60000
				SET			@ErrorMessage			=	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
				RAISERROR	(@ErrorMessage, 16, 1)
				SET			@ReturnValue			=	-1
				RETURN		(@ReturnValue)
		END


--if valid, attempt to delete now...

--we will need tran, b'coz the data is spread across 2 tables...
BEGIN	TRAN

UPDATE	W
	SET	W.Is_Deleted			=			'TRUE'
	,	W.LastModifiedByUserId	=			@UserId
	,	W.LastModifiedTime		=			@CurrentUTCTime
OUTPUT 	inserted.LastModifiedTime AS LastModifiedTimestamp INTO	@OutputList	(LastModifiedTimestamp)
FROM	[TCD].Washer W
		JOIN [TCD].MachineSetup	MS ON W.WasherId = MS.WasherId 	AND	W.EcoLabAccountNumber	=	MS.EcoalabAccountNumber
WHERE	W.EcoLabAccountNumber	=	@EcoLabAccountNumber
		AND	W.WasherId	=	@WasherId
		AND	W.Is_Deleted = 'FALSE'
		AND	MS.IsDeleted = 'FALSE'
--check for any error
SET		@ErrorId				=			@@ERROR

--if any error, abort...
IF	(@ErrorId	<>	0)
	BEGIN
		--Rollback, if in tran
		IF	(@@TRANCOUNT	>	0)
			BEGIN
				ROLLBACK	TRAN
			END

		--Error-out...
		SET		@ErrorMessage=N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred deleting washer data.'
		RAISERROR	(@ErrorMessage, 16, 1)
		SET		@ReturnValue	=	-1
		RETURN	(@ReturnValue)
	END
--else, continue with the deletion in the 2nd table...

UPDATE	MS 	SET	MS.IsDeleted = 'TRUE'
	,	MS.LastModifiedByUserId	= @UserId
FROM	[TCD].MachineSetup	 MS
JOIN	[TCD].Washer W  ON	MS.WasherId	= W.WasherId AND MS.EcoalabAccountNumber	=	W.EcoLabAccountNumber
WHERE	MS.WasherId = @WasherId
	AND	MS.EcoalabAccountNumber	= @EcoLabAccountNumber
	AND	MS.IsDeleted = 'FALSE'
	AND	W.Is_Deleted = 'TRUE'

SELECT @WashgroupId = MS.GroupId,@ControllerId = MS.ControllerId FROM TCD.MachineSetup AS MS WHERE MS.WasherId = @WasherId AND MS.EcoalabAccountNumber = @EcoLabAccountNumber
EXEC [TCD].[SaveInjectionDetails] @WashgroupId,@WashgroupId,@ControllerId,@WasherId, @EcoLabAccountNumber

SELECT @ControllerModelId = cmctm.ControllerModelId 
FROM TCD.ControllerModelControllerTypeMapping cmctm 
INNER JOIN TCD.ConduitController cc 
	ON cc.ControllerModelId = cmctm.ControllerModelId
WHERE cc.ControllerId = @ControllerId AND cc.EcoalabAccountNumber = @EcoLabAccountNumber

-- Removing Tags Associated to it
UPDATE TCD.WasherTags SET  Active =	0 WHERE  WasherId =	@WasherId

UPDATE A SET Is_Deleted =1
			,LastModifiedByUserId=@UserId
			,LastModifiedTime=@CurrentUTCTime
 FROM tcd.WasherFlushTime A
 WHERE WasherId=@WasherId

 --Update Reference Load

 UPDATE TCD.Injection
SET Is_Deleted = 1 -- bit
WHERE WasherId=@WasherId AND Is_Deleted=0

DECLARE @MaxLoad int ,@WasherGroupNumber varchar(10)

SELECT @MaxLoad= max( w.MaxLoad)
FROM TCD.Washer w
join tcd.MachineSetup ms ON ms.WasherId = w.WasherId AND w.Is_Deleted=0
JOIN tcd.MachineSetup ms1 ON ms1.GroupId = ms.GroupId 
			AND  ms1.WasherId=@WasherId 
			AND ms.IsDeleted=0
			--AND ms1.IsDeleted=0

SELECT @WasherGroupNumber=wg.WasherGroupNumber FROM TCD.WasherGroup wg 
JOIN TCD.MachineSetup ms ON ms.GroupId=wg.WasherGroupId AND ms.WasherId=@WasherId 
--AND ms.IsDeleted=0

UPDATE TCD.Injection
SET ReferenceLoad = @MaxLoad -- bit
WHERE WasherGroupNumber=@WasherGroupNumber AND Is_Deleted=0

--check for any error
SET @ErrorId = @@ERROR

--if any error, abort, else COMMIT the work...
IF	(@ErrorId	<>	0)
	BEGIN
		--Rollback, if in tran
		IF	(@@TRANCOUNT	>	0)
			BEGIN
				ROLLBACK	TRAN
			END

		--Error-out...
		SET		@ErrorMessage =			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred deleting washer data.'
		RAISERROR	(@ErrorMessage, 16, 1)
		SET		@ReturnValue	=	-1
		RETURN	(@ReturnValue)
	END
--else, continue with the deletion in the 2nd table...
ELSE
	BEGIN
		--COMMIT, if in tran
		IF	(@@TRANCOUNT	>	0)
			BEGIN
				COMMIT
			END

			SELECT	TOP 1 @OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp FROM @OutputList O
	END

IF	(@ErrorId	=	0)
	BEGIN
		IF (@ControllerModelId = 7)
			BEGIN
				UPDATE TCD.WasherGroup SET ControllerId = NULL WHERE WasherGroupId = @WashgroupId
			END 
		RETURN	(@ReturnValue)
		
	END

SET	NOCOUNT	OFF
RETURN	(@ReturnValue)
END
GO



IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE  CONSTRAINT_TYPE = 'FOREIGN KEY'
    AND TABLE_NAME = 'TunnelProgramReading' AND CONSTRAINT_NAME='FK_TunnelProgramReading_PlantCustomer'
    AND TABLE_SCHEMA ='TCD' )
BEGIN
	ALTER TABLE TCD.TunnelProgramReading DROP CONSTRAINT FK_TunnelProgramReading_PlantCustomer;
END
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE  CONSTRAINT_TYPE = 'FOREIGN KEY'
    AND TABLE_NAME = 'WasherProgramReading' AND CONSTRAINT_NAME='FK_WasherProgramTrending_PlantCustomer'
    AND TABLE_SCHEMA ='TCD' )
BEGIN
	ALTER TABLE TCD.WasherProgramReading DROP CONSTRAINT FK_WasherProgramTrending_PlantCustomer;
END
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE  CONSTRAINT_TYPE = 'PRIMARY KEY'
    AND TABLE_NAME = 'PlantCustomer' AND CONSTRAINT_NAME='PK_PlantCustomer'
    AND TABLE_SCHEMA ='TCD' )
BEGIN
	ALTER TABLE TCD.PlantCustomer DROP CONSTRAINT PK_PlantCustomer;
END
GO
 
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE  CONSTRAINT_TYPE = 'PRIMARY KEY'
    AND TABLE_NAME = 'PlantCustomer' AND CONSTRAINT_NAME='PK_PlantCustomer'
    AND TABLE_SCHEMA ='TCD' )
BEGIN
	ALTER TABLE TCD.PlantCustomer ADD CONSTRAINT PK_PlantCustomer PRIMARY KEY CLUSTERED ([ID] ASC);
END
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE  CONSTRAINT_TYPE = 'FOREIGN KEY'
    AND TABLE_NAME = 'TunnelProgramReading' AND CONSTRAINT_NAME='FK_TunnelProgramReading_PlantCustomer'
    AND TABLE_SCHEMA ='TCD' )
BEGIN
	ALTER TABLE TCD.TunnelProgramReading ADD CONSTRAINT [FK_TunnelProgramReading_PlantCustomer] FOREIGN KEY ([CustomerId]) REFERENCES [TCD].[PlantCustomer] ([ID]);
END
GO

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE  CONSTRAINT_TYPE = 'FOREIGN KEY'
    AND TABLE_NAME = 'WasherProgramReading' AND CONSTRAINT_NAME='FK_WasherProgramTrending_PlantCustomer'
    AND TABLE_SCHEMA ='TCD' )
BEGIN
	ALTER TABLE TCD.WasherProgramReading ADD CONSTRAINT [FK_WasherProgramTrending_PlantCustomer] FOREIGN KEY ([CustomerId]) REFERENCES [TCD].[PlantCustomer] ([ID]);
END
GO
----------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetRedFlagLocations]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetRedFlagLocations]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[GetRedFlagLocations](@ItemId INT, @EcolabAccountNumber nvarchar(25))
AS

BEGIN
SET nocount ON;

SET			@EcolabAccountNumber			=			ISNULL(@EcolabAccountNumber, NULL)			--SQLEnlight SA0029

Declare @LocationTable Table(
Id INT,
GroupDescription nvarchar(100),
GroupTypeId INT
)


If (@ItemId IN (1,2,5,12,13,14,15,16,17,20,21,22,23,24,25,26,27,28,29,30,31,32,33))
begin
	INSERT INTO @LocationTable	(Id,GroupDescription,GroupTypeId)

	SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.GroupTypeId = 1 AND GT.Is_Deleted = 0
	UNION ALL
		SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT INNER JOIN [TCD].MachineSetup MS
		ON GT.Id = MS.GroupId WHERE GT.Is_Deleted = 0
		
		
END
ELSE IF (@ItemId IN (11))
BEGIN
	INSERT INTO @LocationTable	(Id,GroupDescription,GroupTypeId)
	SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.GroupTypeId = 1 AND GT.Is_Deleted = 0
END
ELSE IF(@ItemId IN (3,18,19))
BEGIN
	INSERT INTO @LocationTable	(Id,GroupDescription,GroupTypeId)
	SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.GroupTypeId = 1 AND GT.Is_Deleted = 0
	UNION ALL
	SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT INNER JOIN [TCD].MachineSetup MS
	ON GT.Id = MS.GroupId WHERE GT.Is_Deleted = 0 AND MS.IsTunnel = 0
	
END
ELSE IF(@ItemId = 4)
BEGIN
	INSERT INTO @LocationTable	(Id,GroupDescription,GroupTypeId)
		
	SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.GroupTypeId = 1 AND GT.Is_Deleted = 0
	UNION ALL
	SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT INNER JOIN [TCD].MachineSetup MS
	ON GT.Id = MS.GroupId WHERE GT.Is_Deleted = 0 AND MS.IsTunnel = 1

END


ELSE IF(@ItemId = 6)
BEGIN
INSERT INTO @LocationTable	(Id,GroupDescription,GroupTypeId)
SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.GroupTypeId = 1 AND GT.Is_Deleted = 0
UNION ALL
SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT INNER JOIN [TCD].Meter M ON GT.Id = M.GroupId AND M.utilityType = 2 AND GT.Is_deleted = 0 AND M.Is_deleted = 0


END

ELSE IF(@ItemId = 7)
BEGIN
INSERT INTO @LocationTable	(Id,GroupDescription,GroupTypeId)
SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.GroupTypeId = 1 AND GT.Is_Deleted = 0
UNION ALL
SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT INNER JOIN [TCD].Meter M ON GT.Id = M.GroupId AND M.utilityType in (1,3,4) AND GT.Is_deleted = 0 AND M.Is_deleted = 0


END

ELSE IF(@ItemId = 8)
BEGIN
INSERT INTO @LocationTable	(Id,GroupDescription,GroupTypeId)
SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.GroupTypeId = 1 AND GT.Is_Deleted = 0
UNION ALL
SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT INNER JOIN [TCD].Meter M ON GT.Id = M.GroupId AND M.utilityType in (1) AND GT.Is_deleted = 0 AND M.Is_deleted = 0


END

ELSE IF(@ItemId = 9)
BEGIN
	INSERT INTO @LocationTable	(Id,GroupDescription,GroupTypeId)
	SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.GroupTypeId = 1 AND GT.Is_Deleted = 0
	UNION ALL
	SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT WHERE (GroupTypeId = 2 OR gt.Id = 0) AND GT.Is_Deleted = 0
	
	
END

ELSE IF(@ItemId = 10)
BEGIN
	INSERT INTO @LocationTable	(Id,GroupDescription,GroupTypeId)
	SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.GroupTypeId = 1 AND GT.Is_Deleted = 0
	UNION ALL
	SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT INNER JOIN [TCD].Dryers D ON GT.Id = D.DryerGroupId
	WHERE (GroupTypeId = 3 OR gt.Id = 0) AND GT.Is_Deleted = 0
	
	
END

--DECLARE
--	@PlantId INT = (SELECT MG.Id
--				   FROM TCD.MachineGroupType MGT
--					   INNER JOIN
--					   TCD.MachineGroup MG ON MGT.Id = MG.GroupTypeId
--				   WHERE MGT.Id = 1
--					AND MG.Is_Deleted = 0);
--/*For The following Items, The Machine Dropdown should not be displayed. 
--  So for others we need not display locations which are pointing to Location Level*/
--IF(@ItemId = 2 OR @ItemId = 6 OR @ItemId = 7 OR @ItemId = 8 OR @ItemId = 9)
--BEGIN
--SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.Is_Deleted = 0 AND GT.Id=1 
--UNION
--SELECT DISTINCT L.Id,L.GroupDescription,L.GroupTypeId FROM @LocationTable L
--LEFT JOIN	TCD.Meter M ON L.Id = CASE M.IsPlant WHEN 'TRUE' THEN COALESCE(  M.GroupId ,@PlantId) ELSE M.GroupId END
--LEFT JOIN	TCD.Sensor S ON L.Id = CASE S.IsPlant WHEN 'TRUE' THEN COALESCE(  S.GroupId ,@PlantId) ELSE S.GroupId END
--WHERE ((S.SensorId	IS NOT NULL
--    AND S.Is_deleted = 0)
--	OR (M.MeterId	IS NOT NULL
--    AND M.Is_deleted = 0))
--END 
--ELSE
--BEGIN
----SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.Is_Deleted = 0 AND GT.Id=1 
----UNION
--SELECT DISTINCT L.Id,L.GroupDescription,L.GroupTypeId FROM @LocationTable L
----LEFT JOIN	TCD.Meter M ON L.Id = CASE M.IsPlant WHEN 'TRUE' THEN COALESCE(  M.GroupId ,@PlantId) ELSE M.GroupId END
----LEFT JOIN	TCD.Sensor S ON L.Id = CASE S.IsPlant WHEN 'TRUE' THEN COALESCE(  S.GroupId ,@PlantId) ELSE S.GroupId END
----WHERE ((S.SensorId	IS NOT NULL
----    AND S.Is_deleted = 0
----    AND S.MachineCompartment	IS NULL)
----	OR (M.MeterId	IS NOT NULL
----    AND M.Is_deleted = 0
----    AND M.MachineCompartment	IS NULL))
--END
SELECT DISTINCT L.Id,L.GroupDescription,L.GroupTypeId FROM @LocationTable L
SET nocount OFF;
END
GO

--BatchData
GO
IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'EcolabTextileCategoryId' AND Object_ID = Object_ID(N'[TCD].[BatchData]'))
BEGIN
	ALTER TABLE TCD.BatchData ADD [EcolabTextileCategoryId] INT NULL 
END
Go
IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'ChainTextileCategoryId' AND Object_ID = Object_ID(N'[TCD].[BatchData]'))
BEGIN
	ALTER TABLE TCD.BatchData ADD [ChainTextileCategoryId] INT NULL 
END

GO
IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'FormulaSegmentId' AND Object_ID = Object_ID(N'[TCD].[BatchData]'))
BEGIN
	ALTER TABLE TCD.BatchData ADD [FormulaSegmentId] INT NULL 
END

GO
IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'EcolabSaturationId' AND Object_ID = Object_ID(N'[TCD].[BatchData]'))
BEGIN
	ALTER TABLE TCD.BatchData ADD [EcolabSaturationId] INT NULL 
END

GO
IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'PlantProgramId' AND Object_ID = Object_ID(N'[TCD].[BatchData]'))
BEGIN
	ALTER TABLE TCD.BatchData ADD [PlantProgramId] INT NULL 
END

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessConventionalWasherData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessConventionalWasherData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessConventionalWasherData]
	(	
	@WasherId INT,	
	@xmlTags XML,
	@RedFlagShiftId INT OUTPUT
)

AS
BEGIN
  DECLARE @BatchID        INT,
    @EcolabWasherId       INT,        
    @CurrencyCode       VARCHAR(50),  
    @MachineInternalId      INT,
    @GroupId        INT,  
    @Prveformula       INT,
    @Quantity        INT,
    @MaxWashertGroupCapacity    INT,

    @ProgramMasterId      INT,
    @NominalLoad       DECIMAL(10,2),
    @MaxLoad        DECIMAL(10,2),
    @StandardWeight       DECIMAL(10,2) ,     

    @CurrentFormula       INT,  
    @CurrentFormulaDate      DATETIME2,
    @FormulaIsModified      BIT,

    @CurrentInjection      INT,
    @CurrentInjectionDate     DATETIME2,
    @InjectionIsModified     BIT,

    @OperationalCount      INT,
    @OperationalIsModified     BIT, 
				
    @CurrentHoldSignal      INT,
    @CurrentHoldSignalDate     DATETIME2,
    @HoldSignalIsModified     BIT,  
													
    @EndofFormula       INT, 
    @EndofFormulaDate      DATETIME2,
				
    @AutoWeightEntryActive     BIT,
    @AutoWeightEntryWeight     DECIMAL(10,2),                                                                                                                              
    @ControllerId       INT,
    @CurrentHoldSignalValue     INT ,
				
    @MeterPlcAddress      INT,
    @MeterPlcAddressIsModified    INT,
    @BatchGroupId       INT,
    @BatchFormula       INT,    
    @HoldTime        INT,
    @CteTempBatchInjections     INT,
    @CteTempWaherReadingInjections   INT,
    @BatchStandardWaterUsage    INT,
    @BatchActualWaterUsage     INT,
    @BatchWaterUsagePrice     Decimal(10,2),
    @BatchUtilityPrice      Decimal(10,2),
    @BatchWaterType       INT,
    @PrevGroupId       INT,
    @WasherMeterExists      BIT,
    @ExtraTime        INT,
    @TargetTurnTime       INT,
    @RatioDosingEnabled      BIT,
	@EcolabAccountNumber NVARCHAR(25) = NULL,
	@PreviousFormulaDate      DATETIME2,
	@PreviousInjectionStep	INT,
	@PreviousInjectionStartDate DATETIME2,
	@CurrentInjectionStep INT,
	@WashStepBatchId INT,
	@PrevFormulaExtraTime INT      ,
	@AlarmGroupMasterId INT,
	@StdWashSteps INT,
    @StdInjectionSteps INT,
	@EcolabTextileCategoryId INT,
	@ChainTextileCategoryId INT,
	@FormulaSegmentId INT,
	@EcolabSaturationId INT,
	@PlantProgramId INT			                                                                                                    							

						
		IF EXISTS (SELECT  * FROM [TEMPDB].[DBO].[SYSOBJECTS] o where o.xtype in ('U') AND o.id = OBJECT_ID(N'tempdb..#XmlTagsTable'))
			BEGIN
					DROP TABLE #XmlTagsTable
			END


  CREATE TABLE  #XmlTagsTable ( TagId INT, 
										TagValue NVARCHAR(100), 
										ReceivedTime DATETIME2,
										TagType NVARCHAR(50),
										IsModified BIT
									)

	
  INSERT INTO #XmlTagsTable (
										TagId,
										TagValue,
										ReceivedTime,
										TagType,
										IsModified
									)			
		
		SELECT 		
					T.c.value('@TagId', 'INT') as TagId,
     T.c.value('@Value', 'NVARCHAR(100)') TagValue,
					T.c.value('@TimeStamp', 'VARCHAR(100)') DateTimeStamp,
					T.c.value('@TagType', 'VARCHAR(50)') TagType,
					T.c.value('@IsModified', 'BIT') TagType
  FROM  @xmlTags.nodes('Tags/Tag') T(c)
		WHERE	
					T.c.value('@TagId', 'varchar(100)')  IS NOT NULL
	
  SELECT @CurrentFormula     =  TagValue,  
    @CurrentFormulaDate    =  ReceivedTime,
    @FormulaIsModified     =  IsModified
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_FRM'   
					
  SELECT @CurrentInjection    =  TagValue,
    @CurrentInjectionDate   =  ReceivedTime,
    @InjectionIsModified   =  IsModified   
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_INJ'

  SELECT @OperationalCount    =  TagValue,
    @OperationalIsModified   =  IsModified  
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_OPC'  
			
  SELECT @EndofFormula     =  TagValue,
    @EndofFormulaDate    =  ReceivedTime  
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_EOF' 
		
  SELECT @AutoWeightEntryActive   =  TagValue     
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_AWEA'                 

  SELECT @CurrentHoldSignal    =  TagValue, 
    @HoldSignalIsModified   =  IsModified,  
    @CurrentHoldSignalDate   =  ReceivedTime 
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_HOLDL'

  SELECT @AutoWeightEntryWeight   =  TagValue     
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_AWEW'

  SELECT @MeterPlcAddress    =  TagValue,
    @MeterPlcAddressIsModified  =       IsModified       
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_MPLC'
		
  SELECT @RatioDosingEnabled    =  TagValue      
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_RATA'
		
		SELECT * FROM #XmlTagsTable
		
  SELECT @ExtraTime      =  0

  SELECT TOP 1 @BatchID=BatchId, @Prveformula=ProgramNumber,@PrevGroupId=GroupId, @PreviousFormulaDate=StartDate FROM TCD.BatchData WHERE MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC

  IF(@CurrentFormula != @EndofFormula AND
     @CurrentFormula = @Prveformula AND 
	 @CurrentInjection = 0 AND
	 @OperationalCount = 0 AND
	 @CurrentFormulaDate <= @PreviousFormulaDate AND
	 @CurrentInjectionDate > @PreviousFormulaDate)
	BEGIN
	--Here means, If the same formula is received without EOF then the timestamp of the formula
	--will be still the old timestamp because value is not changed.
	--In this case assign injection=0 timestamp to formula timestamp
	 SELECT @CurrentFormulaDate = @CurrentInjectionDate	
	END

		DECLARE @ShiftStartDate table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
		INSERT INTO @ShiftStartDate(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate,1, @RedFlagShiftId OUTPUT

		SELECT DISTINCT 
     @EcolabWasherId    =  Ws.EcolabWasherId,
     @StandardWeight    =  Wps.NominalLoad,
     @CurrencyCode    =  Pl.CurrencyCode,
     @ControllerId    =  Ctrl.ControllerId,
     @TargetTurnTime    =  Ws.TargetTurnTime * 60     
		FROM 
					TCD.Washer Ws		
		INNER JOIN 
					TCD.MachineSetup Mst ON
     Mst.WasherId    =  Ws.WasherId
		INNER JOIN 
					TCD.WasherGroup Wg ON 
     Wg.WasherGroupId   =  Mst.GroupId    
		INNER JOIN 
					TCD.WasherProgramSetup Wps ON 
     Wps.WasherGroupId   =  Wg.WasherGroupId
		LEFT JOIN 
					TCD.WasherDosingSetup Wds ON 
     Wds.WasherProgramSetupId =  Wps.WasherProgramSetupId
		LEFT JOIN 
					TCD.WasherDosingProductMapping Wdpm ON 
     Wdpm.WasherDosingSetupId =  Wds.WasherDosingSetupId
		INNER JOIN 
					TCD.Plant Pl ON 
     Pl.EcolabAccountNumber  =  Ws.EcoLabAccountNumber
		INNER JOIN 
				TCD.ConduitController Ctrl 
    ON Ctrl.ControllerId   =  Mst.ControllerId 
		WHERE Ws.WasherId= @WasherId

		SELECT DISTINCT 
					@MachineInternalId=Mst.MachineInternalId,
					@GroupId=Mst.GroupId					
		FROM TCD.Washer Ws
						INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
						INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
						INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
			WHERE Ws.WasherId=@WasherId 	

			SELECT DISTINCT 					
					@ProgramMasterId=Wps.ProgramId,
					@NominalLoad=Wps.NominalLoad, --Wps.NominalLoad/CONVERT(decimal(10,2), 100) old code
					@MaxLoad =Ws.MaxLoad,
					@ExtraTime =Wps.ExtraTime
		FROM TCD.Washer Ws
						INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
						INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
						INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
						INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
			WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@CurrentFormula and Wps.Is_Deleted=0

		if(@ExtraTime IS NULL)
		BEGIN
			SELECT @ExtraTime      =  0
		END

		SELECT  @MaxWashertGroupCapacity=Max(ws.MaxLoad)
		FROM TCD.Washer WS
			INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
			INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId		
		WHERE Mst.GroupId=@GroupId

		SELECT @WasherMeterExists = M.MachineCompartment FROM Tcd.MachineSetup Ms
		INNER JOIN Tcd.Meter M ON M.GroupId= Ms.GroupId AND  M.MachineCompartment=Ms.MachineInternalId
		WHERE Ms.WasherId=@WasherId

		if(@AutoWeightEntryActive IS NULL)
		BEGIN
			SELECT @AutoWeightEntryActive = 0
		END

		SELECT @StandardWeight=(@NominalLoad * @MaxWashertGroupCapacity) /CONVERT(decimal(10,2), 100)			
		select @AutoWeightEntryActive,@StandardWeight
		SELECT @AutoWeightEntryWeight=Case @AutoWeightEntryActive WHEN 0 THEN @StandardWeight ELSE  @AutoWeightEntryWeight END 	
		
		SELECT @CurrentHoldSignalValue=Id  FROM TCD.ConduitParameters where Name='HoldSignal'
		
		 SELECT  * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC
		IF(@HoldSignalIsModified !=0)	 
		BEGIN
		IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp =@CurrentHoldSignalDate)
			BEGIN
				INSERT INTO TCD.WasherReading(
									WasherId,
									ParameterId,
									ParameterValue,
									DateTimeStamp,
									PartitionOn,
									EcolabWasherId)
    SELECT    @WasherId,
									@CurrentHoldSignalValue,
									@CurrentHoldSignal,
									@CurrentHoldSignalDate,
									(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
									@EcolabWasherId
			END			
		END
		IF(@FormulaIsModified =1  OR @InjectionIsModified = 1 OR @OperationalIsModified = 1)
		BEGIN
			SELECT 'IsModified',@FormulaIsModified AS FormulaIsModified, 
								@InjectionIsModified AS InjectionIsModified,
								@OperationalIsModified AS OperationalIsModified
			IF(@CurrentFormula != 0)
			BEGIN
							DECLARE @BatchShiftId int,@BatchShiftStartDate datetime
							
							SELECT @BatchShiftStartDate = bd.StartDate FROM TCD.BatchData bd WHERE bd.BatchId = @BatchId

							IF(@BatchShiftStartDate > (SELECT TOP 1 [@ShiftStartDate].ShiftStartdate FROM @ShiftStartDate ORDER BY [@ShiftStartDate].ShiftStartdate ASC)
							AND DATEADD(second,@ExtraTime,@CurrentFormulaDate) > (SELECT TOP 1 [@ShiftStartDate].ShiftStartdate FROM @ShiftStartDate ORDER BY [@ShiftStartDate].ShiftStartdate DESC)
							)
							BEGIN 
								 
         SELECT TOP 1  @BatchShiftId = ssdt.ShiftId FROM @ShiftStartDate ssdt ORDER BY ssdt.ShiftStartdate DESC
							END
							ELSE
							BEGIN
        SELECT TOP 1  @BatchShiftId = ssdt.ShiftId FROM @ShiftStartDate ssdt ORDER BY ssdt.ShiftStartdate ASC
							END
							

		SELECT DISTINCT      
			@PrevFormulaExtraTime =Wps.ExtraTime
			FROM TCD.Washer Ws
				INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
				INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
				INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
				INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
				WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@Prveformula and Wps.Is_Deleted=0

		IF(@PrevFormulaExtraTime IS NULL)
		BEGIN
			SELECT @PrevFormulaExtraTime      =  0
		END

					IF(@CurrentFormula = @EndofFormula)
					BEGIN			
					SELECT * FROM #XmlTagsTable
						IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData 
								   WHERE 
											BatchId=@BatchId AND 
											MachineId=@WasherId AND 
											EndDate IS NULL 
											ORDER BY StartDate DESC  )
							BEGIN
																																							
								UPDATE TCD.BatchData 
         SET EndDate = DATEADD(second,@PrevFormulaExtraTime,@CurrentFormulaDate),EndDateFormula = @CurrentFormulaDate,ShiftId = @BatchShiftId 
       WHERE  BatchId = @BatchId AND MachineId=@WasherId   
	   
	   DECLARE @ShiftMapping1 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
	   INSERT INTO @ShiftMapping1(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate,1, @RedFlagShiftId OUTPUT

	   SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
						IF(@PreviousInjectionStep IS NOT NULL)
						BEGIN
							UPDATE TCD.BatchWashStepData SET EndTime=DATEADD(second,@ExtraTime,@CurrentFormulaDate) WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate
						END
	                                                                  
							END 
					END 
					ELSE IF((@CurrentFormula != @Prveformula) AND (@BatchID IS NOT NULL))
					BEGIN		
					IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC  )
								BEGIN																										
									UPDATE TCD.BatchData
          SET EndDate = @CurrentFormulaDate,EndDateFormula = @CurrentFormulaDate,ShiftId = @BatchShiftId 
         WHERE  BatchId = @BatchId AND MachineId=@WasherId  
		 
		   INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,19,1,(SELECT Top 1 ShiftStartdate from @ShiftStartDate) 
		   
		   DECLARE @ShiftMapping2 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
			INSERT INTO @ShiftMapping2(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate,1, @RedFlagShiftId OUTPUT
			 
			 SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
					IF(@PreviousInjectionStep IS NOT NULL)
					BEGIN
						UPDATE TCD.BatchWashStepData SET EndTime=@CurrentFormulaDate WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate
					END
			    
								END 
						END
					ELSE IF((@CurrentInjection = 0) AND(@OperationalCount = 0) AND (@CurrentFormulaDate != @PreviousFormulaDate))
					BEGIN		
					IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC)
								BEGIN																											
									UPDATE TCD.BatchData
          SET EndDate = @CurrentInjectionDate,ShiftId = @BatchShiftId,EndDateFormula = @CurrentInjectionDate
         WHERE  BatchId = @BatchId AND MachineId=@WasherId  
		 
		  INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,19,1,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)

		  DECLARE @ShiftMapping3 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
			INSERT INTO @ShiftMapping3(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentInjectionDate,1, @RedFlagShiftId OUTPUT
		    
			SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
					IF(@PreviousInjectionStep IS NOT NULL)
					BEGIN
						UPDATE TCD.BatchWashStepData SET EndTime=@CurrentInjectionDate WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate
					END

								END 
						END
			
				-- Hold Time
					IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
						BEGIN

						
						SELECT   @HoldTime=SUM(Wr.ParameterValue) FROM TCD. BatchData Bd
						INNER JOIN TCD.WasherReading Wr ON Wr.WasherId=Bd.MachineId
						WHERE Bd.BatchId=@BatchId  AND Wr.DateTimeStamp BETWEEN Bd.StartDate AND  Bd.EndDate and   Wr.ParameterId=9 -- Hold Signal value

						INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,17,@HoldTime,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)


					END
					
					-- CapturingMeter Plc Address EndRedaing 
					IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
						BEGIN
						IF(@WasherMeterExists IS NOT NULL AND @MeterPlcAddress > 0)
						BEGIN
							IF(@MeterPlcAddressIsModified !=0)	 
							BEGIN
							IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp =@CurrentFormulaDate)
							BEGIN
								INSERT INTO TCD.WasherReading(
									WasherId,
									ParameterId,
									ParameterValue,
									DateTimeStamp,
									PartitionOn,
									EcolabWasherId)
								SELECT	
									@WasherId,
									14, --MeterPlcAddress for EndSReading
									@MeterPlcAddress,
									@CurrentFormulaDate,
									(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
									@EcolabWasherId
							END

						END
						END
					END
									
					--Start Good or Bad Injection in BatchDataTable
					IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
						BEGIN
								;WITH CteTempWaherReadingInjections  (	
								InjectionsCount,BatchId,WasherId,ProgramNumber,Injectons
							) AS  
							(
								SELECT DISTINCT Wr.ParameterValue,
												BD.BatchId,
												Wr.WasherId,
												Bd.ProgramNumber,
												Wr.ParameterValue FROM TCD. BatchData Bd
								INNER JOIN 
          TCD.WasherReading Wr ON Wr.WasherId   =  Bd.MachineId 
								WHERE    
              Wr.ParameterId    =  10    AND 
              Wr.ParameterValue   <>  0    AND 
              Bd.BatchId     =  @BatchID AND WR.DateTimeStamp BETWEEN BD.StartDate AND BD.EndDate) 
								SELECT @CteTempWaherReadingInjections=COUNT(CTE1.InjectionsCount)
								FROM CteTempWaherReadingInjections CTE1 
								INNER JOIN TCD.BatchData Bd ON Bd.BatchId=CTE1.BatchId
								WHERE Bd.BatchId=@BatchId

								;WITH CteTempBatchInjections (	
								InjectionsCount,BatchId,WasherId,ProgramNumber,Injectons
							) AS  
							(
								SELECT  DISTINCT Wdpm.InjectionNumber,
												Bd.BatchId,
												Wps.ProgramNumber,
												Ws.WasherId,Wdpm.
												InjectionNumber
									FROM TCD.Washer WS
										INNER JOIN 
													TCD.MachineSetup Mst ON 
             Mst.WasherId     =  WS.WasherId
										INNER JOIN 
													TCD.WasherGroup Wg ON 
             Wg.WasherGroupId    =  Mst.GroupId       
										INNER JOIN 
													TCD.WasherProgramSetup Wps ON 
             Wps.WasherGroupId    =  Wg.WasherGroupId
										INNER JOIN 
													TCD.WasherDosingSetup Wds ON 
             Wds.WasherProgramSetupId  =  Wps.WasherProgramSetupId
										INNER JOIN 
													TCD.WasherDosingProductMapping Wdpm ON 
             Wdpm.WasherDosingSetupId  =  Wds.WasherDosingSetupID
										INNER JOIN 
													TCD.ProductdataMapping Pdm ON 
             Pdm.ProductId     =  Wdpm.ProductId
										INNER JOIN 
													TCD.BatchData Bd ON 
             Bd.MachineId     =  Ws.WasherId 
										INNER JOIN 
													TCD.WasherReading Wr ON 
             Wr.WasherId      =  Bd.MachineId
								WHERE 
								
             Wps.ProgramNumber    =  @Prveformula  AND 
             Bd.BatchId      =  @BatchID   AND 
             Ws.WasherId      =  @WasherId    )
								SELECT @CteTempBatchInjections=COUNT(CTE2.InjectionsCount)
								FROM CteTempBatchInjections CTE2 
								INNER JOIN TCD.BatchData Bd ON Bd.BatchId=CTE2.BatchId 
								WHERE Bd.BatchId=@BatchID


								Insert Tcd.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchID,@EcolabWasherId,18,
          CASE WHEN @CteTempBatchInjections = @CteTempWaherReadingInjections THEN 1
            WHEN @CteTempBatchInjections != @CteTempWaherReadingInjections THEN 3 END,
												(SELECT Top 1 ShiftStartdate from @ShiftStartDate)	
																											
				END
					--End Good or Bad Injection in BatchDataTable	
					IF(@OperationalCount = 0 AND @CurrentInjection = 0) AND (@CurrentFormula != @EndofFormula)
					BEGIN	
						IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchData WHERE MachineId=@WasherId AND StartDate =@CurrentFormulaDate)
						BEGIN					
       
							--Start Getting InjectionCount and StepCount
							SELECT 
							@StdInjectionSteps=count(DISTINCT wdpm.WasherDosingSetupId),
							@StdWashSteps= count(DISTINCT wds.WasherDosingSetupId)-count(DISTINCT wdpm.WasherDosingSetupId)
							FROM TCD.WasherDosingProductMapping wdpm
							RIGHT JOIN tcd.WasherDosingSetup wds on wdpm.WasherDosingSetupId=wds.WasherDosingSetupId
							WHERE wds.GroupId=@GroupId AND wds.ProgramNumber=@CurrentFormula
							--End Getting InjectionCount and StepCount
							--Start-----ProgramMasterID logic for PlantChainProgram
								SELECT 
								@PlantProgramId=pm.PlantProgramId,
								@EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
								@ChainTextileCategoryId = pm.ChainTextileId,
								@FormulaSegmentId = pm.FormulaSegmentId,
								@EcolabSaturationId = pm.EcolabSaturationId 
								FROM TCD.ProgramMaster pm WHERE pm.ProgramId=@ProgramMasterId AND pm.Is_Deleted=0
								IF(@PlantProgramId <> 0  AND @PlantProgramId IS NOT NULL)
									BEGIN
									   --Assign value from plantchainprogram table based on plantprogramId
									   SELECT
										   @EcolabTextileCategoryId = pcp.EcolabTextileCategoryId,
										   @ChainTextileCategoryId = pcp.ChainTextileCategoryId,
										   @FormulaSegmentId = pcp.FormulaSegmentId,
										   @EcolabSaturationId = pcp.EcolabSaturationId
										   FROM tcd.PlantChainProgram pcp
										   WHERE pcp.PlantProgramId=@PlantProgramId AND pcp.Is_Deleted=0
									END
							--End-----ProgramMasterID logic for PlantChainProgram

							INSERT INTO TCD.BatchData(
										ControllerBatchId ,
										EcolabWasherId,
										GroupId ,
										MachineInternalId,
										PlantWasherNumber,
										StartDate ,
										EndDate ,
										ProgramNumber,
										ProgramMasterId,
										MachineId,
										ActualWeight,
										StandardWeight,
										CurrencyCode,
										ShiftId,									
										PartitionOn,
										TargetTurnTime,
										StdInjectionSteps,
										StdWashSteps,
										EcolabTextileCategoryId,
										ChainTextileCategoryId,
										FormulaSegmentId,
										EcolabSaturationId,
										PlantProgramId										
										)


									SELECT DISTINCT 0
										,@EcolabWasherId
										,@GroupId
										,@MachineInternalId
										,Ws.PlantWasherNumber
										,@CurrentFormulaDate
										,NULL
										,@CurrentFormula
										,@ProgramMasterId
										,@WasherId
										,@AutoWeightEntryWeight
										,@StandardWeight 
										,@CurrencyCode
										,(SELECT Top 1 ShiftId from @ShiftStartDate)									
										,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
										,@TargetTurnTime
										,@StdInjectionSteps
										,@StdWashSteps
										,@EcolabTextileCategoryId
										,@ChainTextileCategoryId
										,@FormulaSegmentId
										,@EcolabSaturationId
										,@PlantProgramId											

							FROM TCD.Washer Ws
										INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
										INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
										INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
							WHERE Ws.WasherId=@WasherId 
			
							SET @BatchID=SCOPE_IDENTITY()	
									
							INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,38,@StdWashSteps,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)

							--If the received formula is not configured in enVision then create an alarm 
							IF(@ProgramMasterId is NULL)
							BEGIN
							SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant;
							SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.AlarmGroupMsterVsControllerModelType AGMVCMT
							INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
							WHERE AGMVCMT.AlarmCode = 9000
								INSERT INTO [TCD].[AlarmData] 
								   (EcoalabAccountNumber,
								   AlarmCode,
								   BatchId,
								   controllerID,
								   StartDate,
								   GroupId,
								   MachineInternalId,
								   ProgramId,   
								   IsActive,
								   EndDate,
								   MachineId,
								   AlarmGroupMasterId)
									  SELECT
									   @ECOLABAccountNumber,
									   9000,
									   @BatchID,
									   @ControllerId,
									   @CurrentFormulaDate,
									   @GroupId,
									   @MachineInternalId,
									   @CurrentFormula,
									   0,
									   @CurrentFormulaDate,
									   @WasherId,
									   @AlarmGroupMasterId
							END

									
									INSERT INTO TCD.BatchCustomerData
									(
									BatchId,
									CustomerId,
									Weight,
									PiecesCount,
									PartitionOn,
									EcolabWasherId
									)
								SELECT Bd.BatchId,  
								--SELECT @BatchID,
									Pc.ID,
									@AutoWeightEntryWeight,
									ROUND(COALESCE((@AutoWeightEntryWeight * Pm.Pieces) / NULLIF(Pm.Weight,0), 0),0),
									(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
									@EcolabWasherId
								
						
							FROM TCD.Washer WS
								INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
								INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId							
								INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
								INNER JOIN TCD.ProgramMaster Pm ON Pm.ProgramId=Wps.ProgramId
								INNER JOIN TCD.PlantCustomer Pc ON Pc.ID=Pm.CustomerId
								INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
							WHERE 
								Ws.WasherId=@WasherId AND 
								Wps.ProgramNumber=@CurrentFormula AND 
								Bd.BatchId=@BatchID  AND 
								Pm.CustomerId != -1 

							IF(@WasherMeterExists IS NOT NULL AND @MeterPlcAddress > 0)
							BEGIN								
								IF(@MeterPlcAddressIsModified !=0)	 
								BEGIN
										INSERT INTO TCD.WasherReading(
											WasherId,
											ParameterId,
											ParameterValue,
											DateTimeStamp,
											PartitionOn,
											EcolabWasherId)
										SELECT	
											@WasherId,
											13, --MeterPlcAddress for StartReading
											@MeterPlcAddress,
											@CurrentFormulaDate,
											(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
											@EcolabWasherId
								END
							END	
						END														
					END	 				
					IF(@BatchID IS NOT NULL)					
					BEGIN
					IF(@CurrentInjection <= 0)
						BEGIN
							SET @CurrentInjectionDate=@CurrentFormulaDate
						END	
						IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp =@CurrentInjectionDate)
						BEGIN						
						INSERT INTO TCD.WasherReading(
										WasherId,
										ParameterId,
										ParameterValue,
										DateTimeStamp,
										PartitionOn,
										EcolabWasherId)
      SELECT   @WasherId,
										CASE TagType 
										WHEN 'Tag_FRM' THEN  5  
										WHEN 'Tag_INJ' THEN  10 
										WHEN 'Tag_OPC' THEN  11 
										END,
										TagValue,										
										@CurrentInjectionDate,
										(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
										@EcolabWasherId
       FROM  #XmlTagsTable 
       WHERE  Tagtype in ('Tag_FRM','Tag_INJ','Tag_OPC')         
					END
					END
				IF(@CurrentInjection > 0)					
					BEGIN
						IF (@RatioDosingEnabled = 1)
							BEGIN
							IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurrentInjectionDate and batchid=@BatchID)
							BEGIN
								INSERT INTO TCD.BatchProductData(BatchId,StepCompartment,ActualQuantity,StandardQuantity,Price,TimeStamp,PartitionOn,EcolabWasherId,ProductId)
								SELECT Bd.BatchId	
								--SELECT @BatchID	
									,Wds.StepNumber
         ,(((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100)) * (@AutoWeightEntryWeight/@StandardWeight) AS ActualQuantity  
         ,(((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100)) * (@AutoWeightEntryWeight/@StandardWeight) AS StandardQuantity      
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * @MaxWashertGroupCapacity)/CONVERT(decimal(10,2), 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price         
									,@CurrentInjectionDate
									,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
									,@EcolabWasherId
									,Pdm.ProductID
								FROM TCD.Washer WS
									INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
									INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
									INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
									INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
									INNER JOIN TCD.WasherDosingSetup Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
									INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
									INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Wdpm.ProductId
									INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
								WHERE 
          Ws.WasherId=@WasherId     AND 
          Wps.ProgramNumber=@CurrentFormula  AND 
          Wdpm.InjectionNumber=@CurrentInjection AND
										Bd.BatchId=@BatchID AND
		  Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
							END
							END
						ELSE
							BEGIN
							IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurrentInjectionDate and batchid=@BatchID)
							BEGIN
								INSERT INTO TCD.BatchProductData(BatchId,StepCompartment,ActualQuantity,StandardQuantity,Price,TimeStamp,PartitionOn,EcolabWasherId,ProductId)
								SELECT Bd.BatchId		
								--SELECT @BatchID
									,Wds.StepNumber
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100) AS ActualQuantity  
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100) AS StandardQuantity      
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * @MaxWashertGroupCapacity)/CONVERT(decimal(10,2), 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price         
									,@CurrentInjectionDate
									,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
									,@EcolabWasherId
									,Pdm.ProductID
								FROM TCD.Washer WS
									INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
									INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
									INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
									INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
									INNER JOIN TCD.WasherDosingSetup Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
									INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
									INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Wdpm.ProductId
									INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
								WHERE 
          Ws.WasherId=@WasherId     AND 
          Wps.ProgramNumber=@CurrentFormula  AND 
          Wdpm.InjectionNumber=@CurrentInjection AND
										Bd.BatchId=@BatchID AND
		  Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
							END		
							END	
							
		--Populating BatchWashstepdata
						SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
						
						IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchWashStepData WHERE StartTime =@CurrentInjectionDate and batchid=@BatchID)
						BEGIN
									SELECT @CurrentInjectionStep=Wds.StepNumber,
										   @WashStepBatchId=Bd.BatchId
         								
									FROM TCD.Washer WS
										INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
										INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
										INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
										INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
										INNER JOIN TCD.WasherDosingSetup Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
										INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
										INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Wdpm.ProductId
										INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
									WHERE 
										Ws.WasherId=@WasherId     AND 
										Wps.ProgramNumber=@CurrentFormula  AND 
										Wdpm.InjectionNumber=@CurrentInjection AND
										Bd.BatchId=@BatchID AND
										Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0

									IF(@CurrentInjectionStep IS NOT NULL)
									BEGIN
										INSERT INTO TCD.BatchWashStepData(BatchId,StepCompartment,StartTime,PartitionOn,EcolabWasherId)
										VALUES (@WashStepBatchId,  @CurrentInjectionStep, @CurrentInjectionDate, (SELECT Top 1 ShiftStartdate from @ShiftStartDate), @EcolabWasherId)																
									
										UPDATE TCD.BatchWashStepData SET EndTime=@CurrentInjectionDate WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate									
									END

						END
						--End Populating BatchWashstepdata

						--Start Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
						IF NOT EXISTS(SELECT * FROM TCD.BatchParameters WHERE ParameterId =37 and batchid=@BatchID)
						BEGIN
							INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,37,1,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)							
						END
						ELSE
						BEGIN
							Update TCD.BatchParameters SET ParameterValue=@CurrentInjection WHERE ParameterId =37 and batchid=@BatchID
						END
	  					--End Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record

											
					END

					UPDATE TCD.ConduitController
      SET LastConnectedTime  = GETUTCDATE()
      WHERE ControllerId   = @ControllerId
			END
		END
	END

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessTunnelWasherData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessTunnelWasherData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessTunnelWasherData]
	(	
	@WasherId INT,	
	@xmlTags XML,
	@RedFlagShiftId INT OUTPUT
)
AS
BEGIN
		DECLARE @BatchID						INT,
				@EcolabWasherId					INT,								
				@CurrencyCode					VARCHAR(50),		
				@MachineInternalId				INT ,
				@GroupId						INT,		
				@Prveformula					INT,
				@Quantity						INT,
				@MaxWashertGroupCapacity		INT,
				@PrevBatchId					INT,
				@PrevLoadId						INT,
				@ExistedLoadId					INT,
				@NumberOfCompartments			INT,

				@ProgramMasterId				INT,
				@NominalLoad					Decimal(10,2),
				@MaxLoad						Decimal(10,2),
				@StandardWeight					Decimal(10,2) , 				
				@PlantWasherNumber				INT,
											
				@CurrentDay						DATE=CAST(GETUTCDATE() as date),
				@TempTunnelTimeStamp			DATETIME2,

				@ControllerId					INT ,
				@CurrentHoldSignal				INT,
				
				@TotalRunTime					INT,
				@BatchGroupId					INT,
				@BatchFormula					INT,
				@BatchStartDate					DATETIME2,
				@BatchEndDate					DATETIME2,
				@HoldTime						INT,
				@CteTempBatchTunnelWashSteps	INT,
				@CteTemTunnelWashSetps			INT,
				@PrevFormula					INT,
				@PrevStepCompartment			INT,
				@BatchStandardWaterUsage		INT,
				@BatchActualWaterUsage			INT,
				@BatchWaterUsagePrice			Decimal(10,2),
				@BatchUtilityPrice				Decimal(10,2),
				@BatchWaterType					INT,
				@ExtraTime						INT,
				@TargetTurnTime					INT,
				@EcolabAccountNumber NVARCHAR(25) = NULL,
				@AlarmGroupMasterId INT,
				@PartitionOn SMALLDATETIME,
				@StdInjectionSteps INT,
				@StdWashSteps INT,
				@EcolabTextileCategoryId INT,
				@ChainTextileCategoryId INT,
				@FormulaSegmentId INT,
				@EcolabSaturationId INT,
				@PlantProgramId INT
	                              							
		SELECT @ExtraTime = 0

		SELECT DISTINCT 					
					@NumberOfCompartments=MST.NumberOfComp,
					@EcolabWasherId=Ws.EcolabWasherId
			FROM		TCD.Washer Ws
			INNER JOIN 
						TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId					
		WHERE Ws.WasherId=@WasherId and Ws.Is_Deleted=0
		
				
		IF EXISTS (SELECT  * FROM TEMPDB.DBO.SYSOBJECTS o where o.xtype in ('U') AND o.id = OBJECT_ID(N'tempdb..#XmlTagsTable'))
			BEGIN
					DROP TABLE #XmlTagsTable
			END
		CREATE TABLE  #XmlTagsTable (	CurrentFormula				INT,
										CurretnInjection			INT,
										CurrentOperationCounter		INT,
										Eof							INT,
										TunnelTimeStamp				DATETIME2,
										OnHold						BIT,										
										CompartmentId				INT, 
										CompartmentLoadId			INT, 
										CompartmentFormulaId		INT,										
										ReceivedTime				DATETIME2,
										AutoWeightEntryActive		VARCHAR(10),
										AutoWeightEntryWeight		INT,
										IsFormulaModified			BIT,
										IsHoldSignalModified		BIT	,
										IsStopSinalModified			BIT,
										StopSignal					INT,
										RatioDosingEnabled			INT						
									)
		INSERT INTO #XmlTagsTable	(
										CurrentFormula	,
										CurretnInjection,										
										CurrentOperationCounter,
										Eof,
										TunnelTimeStamp	,
										OnHold,
										CompartmentId, 
										CompartmentLoadId, 
										CompartmentFormulaId,
										ReceivedTime,
										AutoWeightEntryActive,
										AutoWeightEntryWeight,
										IsFormulaModified,
										IsHoldSignalModified,
										IsStopSinalModified,
										StopSignal,
										RatioDosingEnabled
									)			
		
		-- Populate tempdata from xml
		SELECT	T.c.value('../@CurrentFormula', 'INT') AS CurrentFormula, 
				T.c.value('../@CurrentInjection', 'INT') AS CurretnInjection, 				
				T.c.value('../@CurrentOperationCounter', 'INT') AS CurrentOperationCounter, 						
				T.c.value('../@Eof', 'INT') AS EndofFormula, 
				T.c.value('../@TimeStamp', 'VARCHAR(100)') AS TunnelTimeStamp, 
				T.c.value('../@OnHold', 'VARCHAR(100)') AS OnHold, 
				T.c.value('@CompartmentId', 'INT') AS CompartmentId, 
				T.c.value('@LoadId', 'INT') AS CompartmentLoadId, 
				T.c.value('@FormulaId', 'INT') AS CompartmentFormulaId, 				
				T.c.value('@TimeStamp', 'VARCHAR(100)') DateTimeStamp,
				T.c.value('../@Awea', 'VARCHAR(10)') AS AutoWeightEntryActive, 				
				T.c.value('../@Awew', 'INT') AS AutoWeightEntryWeight,	
				T.c.value('../@IsFormulaModified', 'BIT') AS IsFormulaModified,
				T.c.value('../@IsHoldSignalModified', 'BIT') AS IsHoldSignalModified,
				T.c.value('../@IsStopSinalModified', 'BIT') AS IsStopSinalModified,
				T.c.value('../@StopSignal', 'INT') AS StopSignal,
				T.c.value('../@RATA', 'INT') AS RatioDosingEnabled
				
				
		
		FROM @xmlTags.nodes('/Tunnel/Compartment')  T(c)

		
		WHERE	
		T.c.value('@LoadId', 'VARCHAR(100)')  != 0
		AND
		T.c.value('@CompartmentId', 'INT')    <= @NumberOfCompartments
		
		IF EXISTS (SELECT 1 FROM #XmlTagsTable where IsHoldSignalModified = 1)	 
			BEGIN			
				SELECT	@CurrentHoldSignal = Id  FROM TCD.ConduitParameters where Name='HoldSignal'
				INSERT INTO TCD.WasherReading(
								WasherId,
								ParameterId,
								ParameterValue,
								DateTimeStamp,
								EcolabWasherId)
					SELECT		@WasherId,
								@CurrentHoldSignal,
								OnHold,
								ReceivedTime,
								@EcolabWasherId	
					FROM #XmlTagsTable
			END	
		IF EXISTS (SELECT 1 FROM #XmlTagsTable where IsStopSinalModified = 1)	 
			BEGIN	
				INSERT INTO TCD.WasherReading(
							WasherId,
							ParameterId,
							ParameterValue,
							DateTimeStamp,
							EcolabWasherId)
				SELECT		@WasherId,
							12,
							StopSignal,
							ReceivedTime,
							@EcolabWasherId
				FROM #XmlTagsTable
			END	
		IF EXISTS (SELECT 1 FROM #XmlTagsTable where IsFormulaModified = 1)	 
			BEGIN
		
			-- Start find missing load id form xml  and set end date for corresponding enddates in the database
			DECLARE @TempExisitingLoadIds table(ExstingLoadId INT,ExistsBatchId int)
			INSERT INTO @TempExisitingLoadIds(ExstingLoadId,ExistsBatchId)
				SELECT Bd.ControllerBatchId,Bd.BatchId FROM TCD.BatchData Bd					
					--INNER JOIN TCD.BatchWashStepData Bwsd on Bwsd.BatchId=Bd.BatchId
				WHERE Bd.MachineId=@WasherId AND Bd.EndDate IS NULL ORDER BY Bd.StartDate DESC			
		
			SELECT @TempTunnelTimeStamp =(SELECT T.c.value('./@TimeStamp', 'VARCHAR(100)') AS TunnelTimeStamp	FROM @xmlTags.nodes('/Tunnel')  T(c))
			
			DECLARE @TempBatchStepIs TABLE(StepBatchId INT)
			INSERT INTO @TempBatchStepIs (StepBatchId)
			SELECT ExistsBatchId 
				FROM @TempExisitingLoadIds 
				WHERE ExstingLoadId NOT IN (SELECT CompartmentLoadId FROM #XmlTagsTable)
		
		SELECT @PrevStepCompartment=StepCompartment,@PrevBatchId =BatchID 
		FROM TCD.BatchWashStepData  
		WHERE BatchId in (select StepBatchId from @TempBatchStepIs) AND EndTime IS NULL

		UPDATE 
		TCD.BatchWashStepData 
		SET EndTime = @TempTunnelTimeStamp
		WHERE BatchId in (select StepBatchId from @TempBatchStepIs) AND EndTime IS NULL

		DECLARE @BatchShiftId int
		DECLARE @ShiftStartDateTemp table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
		INSERT INTO @ShiftStartDateTemp(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @TempTunnelTimeStamp,1, @RedFlagShiftId OUTPUT
		SELECT @BatchShiftId = ssdt.ShiftId FROM @ShiftStartDateTemp ssdt ORDER BY ssdt.ShiftStartdate

		-- Updating Batches moved out of the tunnel
		UPDATE TCD.BatchData 
		SET		
				EndDate=@TempTunnelTimeStamp
			,	EndDateFormula=@TempTunnelTimeStamp,
			ShiftId = @BatchShiftId
		WHERE BatchId in (select StepBatchId from @TempBatchStepIs)

		--End find missing load id form xml  and set end date for corresponding enddates in the database
		 
		--Start HoldTime Calculation
			SELECT 
					@BatchGroupId=GroupId
				,	@BatchFormula=ProgramNumber
				,	@BatchStartDate=StartDate
				,	@BatchEndDate=EndDate 
			FROM TCD.BatchData 
			WHERE BatchId IN (select		StepBatchId from @TempBatchStepIs)

			SELECT @TotalRunTime=TotalRunTime 
			FROM TCD.TunnelProgramSetup 
			WHERE	WasherGroupId =@BatchGroupId 
				AND ProgramNumber=@BatchFormula

			
			INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) 
			SELECT StepBatchId,@EcolabWasherId,17,(DATEDIFF(SECOND, @BatchStartDate, @BatchEndDate))-@TotalRunTime,bd.partitionon
            FROM @TempBatchStepIs,TCD.BatchData bd WHERE bd.BatchId= [@TempBatchStepIs].StepBatchId  and [@TempBatchStepIs].StepBatchId NOT IN (SELECT BATCHID FROM TCD.BatchParameters AS BP WHERE BP.ParameterId = 17)
 
		--End HoldTime Calculation

			 --Start Good or Bad Injection in BatchDataTable
					IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@PrevBatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
						BEGIN
					
							;WITH CteTempBatchTunnelStepData  (	
								InjectionsCount,BatchId,ProgramNumber
							) AS  
							(
								SELECT DISTINCT Bws.StepCompartment,
												BD.BatchId,												
												Bd.ProgramNumber
												FROM TCD. BatchData Bd
								INNER JOIN 
										TCD.BatchWashStepData Bws 
															ON Bws.BatchId			=		Bd.BatchId 
								WHERE    
														
														Bd.BatchId					=		@PrevBatchId ) 
								SELECT @CteTemTunnelWashSetps=COUNT(CTE1.InjectionsCount)
								FROM CteTempBatchTunnelStepData CTE1 
								INNER JOIN TCD.BatchData Bd ON Bd.BatchId=CTE1.BatchId
								WHERE Bd.BatchId=@BatchId

								;WITH CteTempBatchInjections (	
								InjectionsCount,ProgramNumber
							) AS  
							(
								SELECT  DISTINCT 
												
												Tds.CompartmentNumber,
												Tps.ProgramNumber
									 	FROM TCD.TunnelProgramSetup Tps 
										INNER JOIN 
													TCD.TunnelDosingSetup Tds ON 
														Tds.TunnelProgramSetupId	=		Tps.TunnelProgramSetupId
										INNER JOIN 
													TCD.TunnelDosingProductMapping Tdpm ON 
													Tdpm.TunnelDosingSetupId		=		Tds.TunnelDosingSetupId
										INNER JOIN 
													TCD.ControllerEquipmentSetup Ces ON 
													Ces.ControllerEquipmentSetupId	=		Tdpm.ControllerEquipmentSetupId
													WHERE 																		 								
													Tps.ProgramNumber				=		@PrevFormula )
								SELECT @CteTempBatchTunnelWashSteps=COUNT(CTE2.InjectionsCount)
								FROM CteTempBatchInjections CTE2 

										Insert Tcd.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @PrevBatchId,@EcolabWasherId,18,
										CASE	WHEN @CteTempBatchTunnelWashSteps	=	@CteTemTunnelWashSetps THEN 1
												WHEN @CteTempBatchTunnelWashSteps	!=	@CteTemTunnelWashSetps THEN 3 END,
												(SELECT PartitionOn FROM TCD.BatchData where BatchId=@PrevBatchId and MachineId=@WasherId)
														
														
																
				END

			-- End Good or Bad Injection in BatchDataTable


	-- Fetching data from cursor
			DECLARE @MYCURSOR CURSOR
			SET @MYCURSOR = CURSOR FAST_FORWARD
			FOR
			SELECT		CurrentFormula	,
						CurretnInjection,										
						CurrentOperationCounter,
						Eof,
						TunnelTimeStamp	,
						OnHold,
						CompartmentId, 
						CompartmentLoadId, 
						CompartmentFormulaId,
						ReceivedTime,
						AutoWeightEntryActive,
						AutoWeightEntryWeight,
						IsFormulaModified,
						IsHoldSignalModified,
						IsStopSinalModified,
						StopSignal,
						RatioDosingEnabled

				FROM #XmlTagsTable ORDER BY CompartmentId ASC
			DECLARE			@CurCurrentFormula					INT,
							@CurCurretnInjection			INT,
							@CurCurrentOperationCounter		INT,
							@CurEof							INT,
							@CurTunnelTimeStamp				DATETIME2,
							@CurOnHold						BIT,
							@CurCompartmentId				INT, 
							@CurCompartmentLoadId			INT, 
							@CurCompartmentFormulaId		INT,
							@CurReceivedTime				DATETIME2,
							@AutoWeightEntryActive			VARCHAR(10),
							@AutoWeightEntryWeight			INT,
							@IsFormulaModified				BIT,
							@IsHoldSignalModified			BIT,
							@IsStopSinalModified			BIT,
							@StopSignal						INT,
							@RatioDosingEnabled				INT	

			OPEN @MYCURSOR
			FETCH NEXT FROM @MYCURSOR
							INTO @CurCurrentFormula			,
							@CurCurretnInjection			,
							@CurCurrentOperationCounter		,
							@CurEof							,
							@CurTunnelTimeStamp				,
							@CurOnHold						,
							@CurCompartmentId				, 
							@CurCompartmentLoadId			, 
							@CurCompartmentFormulaId		,
							@CurReceivedTime				,
							@AutoWeightEntryActive			,
							@AutoWeightEntryWeight			,
							@IsFormulaModified				,
							@IsHoldSignalModified			,
							@IsStopSinalModified			,
							@StopSignal						,
							@RatioDosingEnabled
			WHILE @@FETCH_STATUS = 0
			BEGIN
				

			IF(@IsFormulaModified !=0)	
			BEGIN
				IF(@CurCurrentFormula != @CurEof and @CurCurretnInjection = 0 and @CurCurrentOperationCounter = 0)
					BEGIN

			SELECT DISTINCT 							
							@MachineInternalId			=	Mst.MachineInternalId,
							@GroupId					=	Mst.GroupId,
							@ControllerId				=	Ctrl.ControllerId				
					FROM TCD.Washer Ws
						INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
						INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
						INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
						INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId	=	Mst.ControllerId
					WHERE Ws.WasherId=@WasherId 	

				SELECT DISTINCT 
							@ProgramMasterId			=	Wps.ProgramId,
							@NominalLoad				=	Wps.NominalLoad,
							@MaxLoad					=	Ws.MaxLoad,
							@CurrencyCode				=	Pl.CurrencyCode, 
							@TargetTurnTime				=   (3600/(Wps.TotalRunTime/Mst.NumberofComp))

				FROM TCD.Washer Ws
						INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
						INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
						INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
						INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
						INNER JOIN TCD.Plant Pl ON Pl.EcolabAccountNumber	=		Ws.EcoLabAccountNumber
						
				WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@CurCurrentFormula and Wps.Is_Deleted=0

				select @PlantWasherNumber = plantwashernumber from tcd.washer where washerid = @WasherId
	
				SELECT  @MaxWashertGroupCapacity		=	Max(ws.MaxLoad)
				FROM TCD.Washer WS
					INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
					INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId		
				WHERE Mst.GroupId=@GroupId

				SELECT @StandardWeight					=	@NominalLoad  								
				SELECT @AutoWeightEntryWeight=Case @AutoWeightEntryActive WHEN 'False' THEN @StandardWeight ELSE  @AutoWeightEntryWeight END 
				
						
				SELECT @MachineInternalId,@GroupId,@ProgramMasterId,@NominalLoad,@WasherId,@CurCurrentFormula,@PrevBatchId
				SELECT @CurCurrentFormula				AS CurCurrentFormula			,
							@CurCurretnInjection		AS CurCurretnInjection		,
							@CurCurrentOperationCounter	AS CurCurrentOperationCounter	,
							@CurEof						AS CurEof 		,
							@CurTunnelTimeStamp			AS CurTunnelTimeStamp		,
							@CurOnHold					AS CurOnHold			,
							@CurCompartmentId			AS CurCompartmentId			, 
							@CurCompartmentLoadId		AS CurCompartmentLoadId 		, 
							@CurCompartmentFormulaId	AS CurCompartmentFormulaId		,
							@CurReceivedTime			AS CurReceivedTime,
							@AutoWeightEntryActive		AS AutoWeightEntryActive,
							@AutoWeightEntryWeight		AS AutoWeightEntryWeight,
							@IsFormulaModified			AS IsFormulaModified
		
		IF(@CurCompartmentFormulaId > 0)
		BEGIN
					UPDATE TCD.ConduitController
					SET LastConnectedTime		=	GETUTCDATE()
					WHERE ControllerId			=	@ControllerId
		END
		
		
		IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchData WHERE MachineId=@WasherId AND StartDate =@CurTunnelTimeStamp)
		BEGIN

			DECLARE @ShiftStartDate table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
			INSERT INTO @ShiftStartDate(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurTunnelTimeStamp,0, @RedFlagShiftId OUTPUT

				--Start Getting InjectionCount,StepCount And ProductCount
					SELECT @StdInjectionSteps= count(tdpm.TunnelDosingSetupId) ,
					@StdWashSteps= count(DISTINCT tds.TunnelDosingSetupId)-count(tdpm.TunnelDosingSetupId) 
					FROM TCD.TunnelDosingProductMapping tdpm
					RIGHT JOIN tcd.TunnelDosingSetup tds on tdpm.TunnelDosingSetupId=tds.TunnelDosingSetupId
					WHERE tds.GroupId=@GroupId AND tds.ProgramNumber=@CurCurrentFormula
			    --Start-----ProgramMasterID logic for PlantChainProgram
					SELECT 
					@PlantProgramId=pm.PlantProgramId,
					@EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
					@ChainTextileCategoryId = pm.ChainTextileId,
					@FormulaSegmentId = pm.FormulaSegmentId,
					@EcolabSaturationId = pm.EcolabSaturationId 
					FROM TCD.ProgramMaster pm WHERE pm.ProgramId=@ProgramMasterId AND pm.Is_Deleted=0
					IF(@PlantProgramId <> 0  AND @PlantProgramId IS NOT NULL)
						BEGIN
							--Assign value from plantchainprogram table based on plantprogramId
							SELECT
								@EcolabTextileCategoryId = pcp.EcolabTextileCategoryId,
								@ChainTextileCategoryId = pcp.ChainTextileCategoryId,
								@FormulaSegmentId = pcp.FormulaSegmentId,
								@EcolabSaturationId = pcp.EcolabSaturationId
								FROM tcd.PlantChainProgram pcp
								WHERE pcp.PlantProgramId=@PlantProgramId AND pcp.Is_Deleted=0
						END
				--End-----ProgramMasterID logic for PlantChainProgram
				-- New Batch Creation
							INSERT INTO TCD.BatchData(
											ControllerBatchId ,
											EcolabWasherId,
											GroupId ,
											MachineInternalId,
											PlantWasherNumber,
											StartDate ,
											EndDate ,
											ProgramNumber,
											ProgramMasterId,
											MachineId,
											ActualWeight,
											StandardWeight,
											CurrencyCode,
											ShiftId,
											PartitionOn,
											TargetTurnTime,
											StdInjectionSteps,
											StdWashSteps,
											EcolabTextileCategoryId,
											ChainTextileCategoryId,
											FormulaSegmentId,
											EcolabSaturationId,
											PlantProgramId
											)


										SELECT DISTINCT @CurCompartmentLoadId
											,@EcolabWasherId
											,@GroupId
											,@MachineInternalId
											,@PlantWasherNumber
											--,@CurReceivedTime
											,@CurTunnelTimeStamp
											,NULL
											,@CurCurrentFormula
											,@ProgramMasterId
											,@WasherId
											,@AutoWeightEntryWeight
											,@StandardWeight 
											,@CurrencyCode
											,(SELECT Top 1 ShiftId from @ShiftStartDate)
											,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
											,@TargetTurnTime
											,@StdInjectionSteps
											,@StdWashSteps
											,@EcolabTextileCategoryId
											,@ChainTextileCategoryId
											,@FormulaSegmentId
											,@EcolabSaturationId
											,@PlantProgramId	
								
			
								SET @BatchID=SCOPE_IDENTITY()	

								--Start insert InjectionActualCount and StepActualCount in TCD.BatchParameters
								INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchID,@EcolabWasherId,37,@StdInjectionSteps,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
								INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchID,@EcolabWasherId,38,@StdWashSteps,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)  
								--End insert InjectionActualCount and StepActualCount in TCD.BatchParameters

								--If the received formula is not configured in enVision then create an alarm 
							IF(@ProgramMasterId is NULL)
							BEGIN
							SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant
							SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.AlarmGroupMsterVsControllerModelType AGMVCMT
							INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
							WHERE AGMVCMT.AlarmCode = 9000
								INSERT INTO [TCD].[AlarmData] 
								   (EcoalabAccountNumber,
								   AlarmCode,
								   BatchId,
								   controllerID,
								   StartDate,
								   GroupId,
								   MachineInternalId,
								   ProgramId,   
								   IsActive,
								   EndDate,
								   MachineId,
								   AlarmGroupMasterId)
									  SELECT
									   @ECOLABAccountNumber,
									   9000,
									   @BatchID,
									   @ControllerId,
									   @CurTunnelTimeStamp,
									   @GroupId,
									   @MachineInternalId,
									   @CurCurrentFormula,
									   0,
									   @CurTunnelTimeStamp,
									   @WasherId,
									   @AlarmGroupMasterId
							END


						-- Wash Step Information		
						INSERT INTO TCD.BatchWashStepData(
											BatchId
											,StepCompartment
											,StartTime
											,EndTime
											,PartitionOn
											,EcolabWasherId) 				
						SELECT	
											@BatchID,
											@CurCompartmentId,
											@CurTunnelTimeStamp,
											--@CurReceivedTime,
											NULL,
											(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
											@EcolabWasherId
						-- Product Usage
				IF (@RatioDosingEnabled = 1)
					BEGIN
						INSERT INTO TCD.BatchProductData(
									BatchId,
									StepCompartment,
									ActualQuantity,
									StandardQuantity,
									Price,
									[TimeStamp],
									PartitionOn,
									EcolabWasherId,
									ProductId
						)					
						SELECT DISTINCT @BatchID	
										,@CurCompartmentId
										,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * (@AutoWeightEntryWeight/@StandardWeight) AS ActualQuantity						
										,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * (@AutoWeightEntryWeight/@StandardWeight) AS StandardQuantity										
										,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price	
										,@CurTunnelTimeStamp								
										--,@CurReceivedTime
										,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
										,@EcolabWasherId
										,Pdm.ProductID
							FROM TCD.Washer WS
							INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
							INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
							INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
							INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
							INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
							INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
							INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId=Wdpm.ControllerEquipmentSetupId
							INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Ces.ProductId
							--INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
						WHERE 
								Ws.WasherId=@WasherId AND 
								Wps.ProgramNumber=@CurCurrentFormula AND 
								Wds.CompartmentNumber=@CurCompartmentId	AND
								Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
					END
				ELSE
					BEGIN
						INSERT INTO TCD.BatchProductData(
									BatchId,
									StepCompartment,
									ActualQuantity,
									StandardQuantity,
									Price,
									[TimeStamp],
									PartitionOn,
									EcolabWasherId,
									ProductId
						)					
						SELECT DISTINCT @BatchID	
										,@CurCompartmentId
										,((Wps.NominalLoad * Wdpm.Quantity)/ 100) AS ActualQuantity						
										,((Wps.NominalLoad * Wdpm.Quantity)/ 100) AS StandardQuantity										
										,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price
										,@CurTunnelTimeStamp									
										--,@CurReceivedTime
										,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
										,@EcolabWasherId
										,Pdm.ProductID
							FROM TCD.Washer WS
							INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
							INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
							INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
							INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
							INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
							INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
							INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId=Wdpm.ControllerEquipmentSetupId
							INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Ces.ProductId
							--INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
						WHERE 
								Ws.WasherId=@WasherId AND 
								Wps.ProgramNumber=@CurCurrentFormula AND 
								Wds.CompartmentNumber=@CurCompartmentId	AND
								Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
					END			
								
								
						-- Transfer Signal		
								INSERT INTO TCD.WasherReading(
															WasherId,
															ParameterId,
															ParameterValue,
															DateTimeStamp,
															PartitionOn,
															EcolabWasherId)
									SELECT @WasherId,
											6,
											1,
											@TempTunnelTimeStamp,
											(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
											@EcolabWasherId
									UNION ALL
									SELECT @WasherId,
											6,
											0,
											GETUTCDATE(),
											(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
											@EcolabWasherId
			
						-- Insert Customer Data
						INSERT INTO TCD.BatchCustomerData(
										BatchId,
										CustomerId,
										Weight,
										PiecesCount,
										PartitionOn,
										EcolabWasherId
										)
						SELECT DISTINCT	
										Bd.BatchId,		
										Pc.ID,
										@AutoWeightEntryWeight,
										ROUND(COALESCE((@AutoWeightEntryWeight * Pm.Pieces) / NULLIF(Pm.Weight,0), 0),0),
										(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
										@EcolabWasherId
						
						FROM TCD.Washer WS
							INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
							INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId							
							INNER JOIN TCD.TunnelProgramSetup Tps ON Tps.WasherGroupId = Wg.WasherGroupId
							INNER JOIN TCD.ProgramMaster Pm ON Pm.ProgramId=Tps.ProgramId
							INNER JOIN TCD.PlantCustomer Pc ON Pc.ID=Pm.CustomerId
							INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
						WHERE 
							Ws.WasherId=@WasherId AND 
							Tps.ProgramNumber=@CurCompartmentFormulaId AND 
							Bd.BatchId=@BatchID	  AND 
							Pm.CustomerId != -1
							AND Pm.[Weight] > 0
		END

		ELSE
		BEGIN
			SELECT @BatchID=BatchId, @PartitionOn=PartitionOn
			FROM TCD.BatchData 
			WHERE MachineId=@WasherId 
			AND ControllerBatchId=@CurCompartmentLoadId
			
			IF(@BatchID IS NOT NULL)
			BEGIN
			UPDATE TCD.BatchWashStepData 
				SET EndTime=@CurTunnelTimeStamp
			WHERE BatchId=@BatchId 
				AND StepCompartment=@CurCompartmentId-1

				IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchWashStepData WHERE StartTime=@CurTunnelTimeStamp and BatchId=@BatchID)
				BEGIN
					INSERT INTO TCD.BatchWashStepData(
											BatchId
											,StepCompartment
											,StartTime
											,EndTime
											,PartitionOn
											,EcolabWasherId) 				
						SELECT	
											@BatchID,
											@CurCompartmentId,
											@CurTunnelTimeStamp,
											--@CurReceivedTime,
											NULL,
											@PartitionOn,
											@EcolabWasherId
				END							
				IF (@RatioDosingEnabled = 1)
					BEGIN
					IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurTunnelTimeStamp and BatchId=@BatchID)
					BEGIN
						INSERT INTO TCD.BatchProductData(
									BatchId,
									StepCompartment,
									ActualQuantity,
									StandardQuantity,
									Price,
									[TimeStamp],
									PartitionOn,
									EcolabWasherId,
									ProductId
									)
						SELECT DISTINCT 
									@BatchID	
									,@CurCompartmentId
									,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * (@AutoWeightEntryWeight/@StandardWeight) AS ActualQuantity							
									,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * (@AutoWeightEntryWeight/@StandardWeight) AS StandardQuantity	
									,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price
									,@CurTunnelTimeStamp									
									--,@CurReceivedTime
									,@PartitionOn
									,@EcolabWasherId
									,Pdm.ProductID
						FROM TCD.Washer WS
						INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
						INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
						INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
						INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
						INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
						INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
						INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId=Wdpm.ControllerEquipmentSetupId
						INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Ces.ProductId
						--INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
						WHERE 
							Ws.WasherId=@WasherId 
							AND Wps.ProgramNumber=@CurCompartmentFormulaId 
							AND Wds.CompartmentNumber=@CurCompartmentId	AND
							Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
					END
				END -- end of ratio dosing if
				ELSE
					BEGIN
					IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurTunnelTimeStamp and BatchId=@BatchID)
					BEGIN
					INSERT INTO TCD.BatchProductData(
									BatchId,
									StepCompartment,
									ActualQuantity,
									StandardQuantity,
									Price,
									[TimeStamp],
									PartitionOn,
									EcolabWasherId,
									ProductId
									)
					SELECT DISTINCT 
									@BatchID	
									,@CurCompartmentId
									,((Wps.NominalLoad * Wdpm.Quantity)/ 100) AS ActualQuantity							
									,((Wps.NominalLoad * Wdpm.Quantity)/ 100) AS StandardQuantity	
									,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price
									,@CurTunnelTimeStamp									
									--,@CurReceivedTime
									,@PartitionOn
									,@EcolabWasherId
									,Pdm.ProductID
						FROM TCD.Washer WS
						INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
						INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
						INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
						INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
						INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
						INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
						INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId=Wdpm.ControllerEquipmentSetupId
						INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Ces.ProductId
								
					WHERE 
							Ws.WasherId=@WasherId 
							AND Wps.ProgramNumber=@CurCompartmentFormulaId 
							AND Wds.CompartmentNumber=@CurCompartmentId	AND
								Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0	
			END
			END								
				END -- end of BatchId NULL if
			END -- end of else
		END		-- end of IF(@CurCurrentFormula != @CurEof and @CurCurretnInjection = 0 and @CurCurrentOperationCounter = 0)							
	END		-- end of IF(@IsFormulaModified !=0)	
															
			FETCH NEXT FROM @MYCURSOR
			INTO @CurCurrentFormula			,
							@CurCurretnInjection			,
							@CurCurrentOperationCounter		,
							@CurEof							,
							@CurTunnelTimeStamp				,
							@CurOnHold						,
							@CurCompartmentId				, 
							@CurCompartmentLoadId			, 
							@CurCompartmentFormulaId		,
							@CurReceivedTime				,
							@AutoWeightEntryActive			,
							@AutoWeightEntryWeight			,
							@IsFormulaModified				,
							@IsHoldSignalModified			,
							@IsStopSinalModified			,
							@StopSignal						,
							@RatioDosingEnabled
			END
			CLOSE @MYCURSOR
			DEALLOCATE @MYCURSOR	
			
		
		END
END

GO

IF EXISTS (SELECT * FROM sys.columns WHERE Name = N'ActualWeight' AND Object_ID = Object_ID(N'TCD.BatchData'))
BEGIN
    ALTER TABLE TCD.BatchData ALTER COLUMN ActualWeight int NULL
END
Go

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetControllerDetails]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetControllerDetails]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[GetControllerDetails] @CanControlTunnel BIT = NULL
	,@IsDelete BIT = 'False'
	,@EcolabAccountNumber nvarchar(25)
AS
BEGIN
	SET NOCOUNT ON

	IF @CanControlTunnel IS NOT NULL OR @CanControlTunnel = 0
	BEGIN
		SET @CanControlTunnel = 0
	END

	SELECT C.ControllerId
		,C.ControllerModelId
		,CM.NAME ControllerModelName
		,C.NAME ControllerName
		,C.ControllerNumber
		,C.ControllerTypeId
		,CT.NAME AS ControllerType
		,C.ControllerVersion
		,C.InstallDate
		,C.EcoalabAccountNumber
		,C.LastModifiedTime
		,C.LastSyncTime
		,C.IsDeleted
		,C.TopicName
		,CMCTM.MaximumWasherExtractorCount WasherExtractorCount
		,CMCTM.MaxTunnelCount tunnelCount
	FROM [TCD].ConduitController C
	INNER JOIN [TCD].ControllerModel CM ON CM.Id = C.ControllerModelId
	INNER JOIN [TCD].ControllerType CT ON CT.Id = C.ControllerTypeId
	INNER JOIN [TCD].ControllerModelControllerTypeMapping CMCTM ON C.ControllerTypeId = CMCTM.ControllerTypeId
		AND C.ControllerModelId = CMCTM.ControllerModelId
	WHERE C.EcoalabAccountNumber = @EcolabAccountNumber
		AND (
			C.IsDeleted = 'False'
			OR C.IsDeleted = @IsDelete
			)
		AND c.ControllerId <> 0
		

	SET NOCOUNT OFF
END
GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetManualProductionDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.[GetManualProductionDetails]
	END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[GetManualProductionDetails]        
 (        
 @WasherGroupId NVARCHAR(1000),         
 @WasherId INT,        
 @FormulaId INT,        
 @EcolabAccountNumber nvarchar(25)    ,
 @RecordedDate DATETIME
   , @RowsPerPage INT =50
  , @PageNumber INT = 1     
 )        
AS         
  BEGIN         
     SET NOCOUNT ON
	  IF @PageNumber < 1 
	   SET @PageNumber = 1 
	            
    if(@FormulaId = 0)      
    BEGIN      
    set @FormulaId = null      
    END      
   SELECT       
      MP.ProductionId,       
      MP.FormulaId,      
      MP.RecordedDate,         
      MP.Value    ,    
      PM.Name,
	  Count(*) Over() TotalRows    
    FROM  [TCD].ManualProduction  AS MP    
  JOIN [TCD].[ProgramMaster]  AS PM ON MP.FormulaId = PM.ProgramId    
   WHERE         
      MP.WasherGroupId IN( SELECT cast(items as int) FROM [TCD].[CharacterListToTable](@WasherGroupId,','))      
      AND MP.WasherId = @WasherId         
      AND MP.FormulaId = COALESCE(@FormulaId,  FormulaId)       
      AND MP.EcolabAccountNumber = @EcolabAccountNumber      
      AND MP.RecordedDate >= @RecordedDate
      AND MP.IsDeleted <> 1        
   ORDER BY ProductionId DESC
   
   OFFSET (@PageNumber-1)*@RowsPerPage ROWS
   FETCH NEXT @RowsPerPage ROWS ONLY         
  SET NOCOUNT OFF        
  END
GO

IF NOT EXISTS (SELECT 1 FROM TCD.FormulaSegments fs WHERE fs.FormulaSegmentID IN (1,2,3)) 
BEGIN
SET IDENTITY_INSERT [TCD].[FormulaSegments] ON 
INSERT [TCD].[FormulaSegments] ([FormulaSegmentID], [SegmentName], [LastModifiedTime], [LastModifiedByUserId], [Is_Deleted]) VALUES (1, N'Health Care', CAST(0x0000A58A009FE3B7 AS DateTime), 0, 0)
INSERT [TCD].[FormulaSegments] ([FormulaSegmentID], [SegmentName], [LastModifiedTime], [LastModifiedByUserId], [Is_Deleted]) VALUES (2, N'Hospitality', CAST(0x0000A58A009FED45 AS DateTime), 0, 0)
INSERT [TCD].[FormulaSegments] ([FormulaSegmentID], [SegmentName], [LastModifiedTime], [LastModifiedByUserId], [Is_Deleted]) VALUES (3, N'Food & Beverage', CAST(0x0000A58A009FF819 AS DateTime), 0, 0)
SET IDENTITY_INSERT [TCD].[FormulaSegments] OFF
END
GO



IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[GetWasherGroupFromulaInjectionDetails]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[GetWasherGroupFromulaInjectionDetails] 
END 
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE  PROCEDURE [TCD].[GetWasherGroupFromulaInjectionDetails]

            (

            @EcolabAccountNumber nvarchar(25) = NULL,

            @WasherGroupId INT = NULL,

            @WasherProgramSetupId INT = NULL

            )

AS

SET NOCOUNT ON

BEGIN

   

 SELECT  

 DISTINCT

  WDS.WasherDosingSetupId

  ,CAST(WPS.ProgramNumber AS INT) AS ProgramId

  ,WG.WasherGroupNumber

  ,WDP.InjectionNumber

  ,CES.ControllerEquipmentId

  ,WDP.ProductId

  -- ,PM.Name

  ,WDP.Quantity

  ,IJ.ReferenceLoad

  --,WDS.StepNumber

  --,WS.[StepId] AS WashOperationId

  --,WS.[StepName] AS WashOperation   

  ,IJ.InjectionClass

  ,IJ.ControllerId

  ,CT.Id AS ControllerType

  ,WPS.NominalLoad

 FROM [TCD].[WasherProgramSetup] WPS



  INNER JOIN  [TCD].[WasherDosingSetup] WDS ON WPS.[WasherProgramSetupId] = WDS.[WasherProgramSetupId]

  INNER JOIN TCD.WasherDosingProductMapping WDP ON WDS.WasherDosingSetupId = WDP.WasherDosingSetupId AND WDP.IsDeleted = 0

  INNER JOIN TCD.WasherGroup WG ON WG.WasherGroupId = WPS.WasherGroupId

  INNER JOIN TCD.Injection IJ ON WG.WasherGroupNumber = IJ.WasherGroupNumber

  INNER JOIN TCD.ConduitController CC ON IJ.ControllerId = CC.ControllerId AND cc.Active = 1 AND cc.IsDeleted =0

  INNER JOIN TCD.ControllerType CT ON CC.ControllerTypeId = CT.Id

  INNER JOIN TCD.ProductMaster PM ON WDP.ProductId = PM.ProductId

  INNER JOIN TCD.ControllerEquipmentSetup CES ON CES.ProductId = PM.ProductId AND CES.ControllerId = CC.ControllerId

  --LEFT JOIN [TCD].WashStep WS  ON WS.StepId     =   WDS.StepTypeId

 WHERE  

  WG.WasherGroupId=@WasherGroupId

  AND WPS.WasherProgramSetupId = @WasherProgramSetupId  

  AND WPS.EcolabAccountNumber = @EcolabAccountNumber
     

 END
GO

IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[ReportProductionSummary]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[ReportProductionSummary] 
END 
GO 
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ReportProductionSummary]   
	
     @startdate datetime = '',  
     @enddate datetime = '',  
     @Viewtype varchar(30) = '',  
     @Subview varchar(30)= '',  
     @Drillvalue varchar(100)= '',  
     @EcolabAccountNumber Nvarchar(25) = '',  
     @MachineType VARCHAR(20)= '',  
     @MachineGroup VARCHAR(MAX) = '',  
     @Machine VARCHAR(MAX) = '',  
     @EcolabCategory VARCHAR(MAX) = '',  
     @ChainCategory VARCHAR(MAX) = '',  
     @PlantFormula  VARCHAR(MAX) = '',  
     @ChainFormula VARCHAR(MAX) = '',  
     @Customer VARCHAR(MAX) = '',  
     @SortColumnId int = 0,  
     @SortDirection varchar(4) = '',  
     @CurrencyCode varchar(3) = '',  
     @UserId INT = NULL,
	 @FormulaSegement VARCHAR(MAX)='', --Formula segment,
	 @FormulaCategory VARCHAR(MAX)='', --Formula category
	 @Formula VARCHAR(MAX)='' --Formula
AS     
BEGIN     
SET NOCOUNT ON   
  
 SET @startdate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@startdate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@startdate AS time)) AS DateTime))  
 SET @EndDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndDate AS time)) AS DateTime))  
   
 DECLARE @ReportGenerated INT = 6,  
    @Month INT = MONTH(GETDATE()),@CorrectionVariable Decimal(18,2),@PlantTargetProduction decimal(18,2)  
    --,@ShiftRuntime int,@NoShiftTotalRuntime INT,@TotaRuntime int  
  
 -- Inserting the record into Report History   
 INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)  
 SELECT @EcolabAccountNumber,UM.UserId,UM.LoginName,GETUTCDATE(),@ReportGenerated,  
 CASE WHEN @ReportGenerated = 6  
  THEN 'Generated Report : Production Summary Report' END  
 FROM TCD.UserMaster UM  
 WHERE UM.EcolabAccountNumber = @EcolabAccountNumber AND UM.UserId = @UserId  
 /* Completed the record insertion into Report History */   
  
    -- Return Table set  
    DECLARE @resultSet Table  
    (  
      ShiftId Int,  
      DateRange varchar(100),  
      TotalLoad Decimal(18,2) ,  
      WasherEfficiency Decimal(18,2),  
      PlantTargetLoad Decimal(18,2) ,  
      Numberofbatches INT,  
      [ActualRunTime] [int] NULL,  
      [TargetRunTime] [int] NULL,  
      Viewtype varchar(100) NULL,  
      Subview varchar(100) NULL,  
      Id int NULL        
    )  
    DECLARE @CorrectionFactor TABLE   
 (  
 [ShiftId] [int] NULL,  
 MachineId INT NULL,  
 [ActualProduction] [int] NULL,  
 [StandardProduction] [int] NULL,  
 [PlantTargetProd] [int] NULL,  
 [ActualRunTime] [int] NULL,  
 [TargetRunTime] [int] NULL,  
 ManualInputWeight INT,  
 ManulainputsNoofloads INT  
 )  
  
 DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))  
 INSERT INTO @MachineTypeTable EXEC [TCD].[CharlistToTable] @MachineType,','  
  
 DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))  
 INSERT INTO @WasherGroupTable EXEC [TCD].[CharlistToTable] @machineGroup,','    
  
 DECLARE @MachineTable TABLE(Machine Varchar(100))  
 INSERT INTO @MachineTable EXEC [TCD].[CharlistToTable] @Machine,','  
  
 DECLARE @EcolabCategoryTable TABLE(EcolabCategory Varchar(100))  
 INSERT INTO @EcolabCategoryTable EXEC [TCD].[CharlistToTable] @EcolabCategory,','  
  
 DECLARE @ChainCategoryTable TABLE(ChainCategory Varchar(100))  
 INSERT INTO @ChainCategoryTable EXEC [TCD].[CharlistToTable] @ChainCategory,','  
  
 DECLARE @PlantFormulaTable TABLE(PlantFormula Varchar(100))  
 INSERT INTO @PlantFormulaTable EXEC [TCD].[CharlistToTable] @PlantFormula,','  
  
 DECLARE @ChainFormulaTable TABLE(ChainFormula Varchar(100))  
 INSERT INTO @ChainFormulaTable EXEC [TCD].[CharlistToTable] @ChainFormula,','  
  
 DECLARE @CustomerTable TABLE(Customer Varchar(100))  
 INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','  
  
	--Formula Segment --added by Kiran
	DECLARE @FormulaSegmentTable TABLE(FormulaSegment Varchar(1000))
    INSERT INTO @FormulaSegmentTable EXEC [TCD].[CharlistToTable] @FormulaSegement,','

	--Formula category
	DECLARE @FormulaCategoryTable TABLE(FormulaCategory Varchar(1000),Type CHAR(1))
    INSERT INTO @FormulaCategoryTable(FormulaCategory) EXEC [TCD].[CharlistToTable] @Formulacategory,','	
		
		--Below 1000 Ecolab category
		UPDATE @FormulaCategoryTable SET TYPE='E' WHERE FormulaCategory<1000
		--Above 1000 consider as Chain category
		UPDATE @FormulaCategoryTable SET TYPE='C' WHERE FormulaCategory>=1000

		--Rollbacking to actual ID
		UPDATE @FormulaCategoryTable SET FormulaCategory=FormulaCategory-1000 WHERE TYPE='C'
	
		--SELECT * FROM @FormulaCategoryTable

		INSERT INTO @EcolabCategoryTable(EcolabCategory)
		SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='E'	

		INSERT INTO @ChainCategoryTable(ChainCategory)
		SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='C'

		--Value Assigning
		IF (EXISTS(SELECT * FROM @EcolabCategoryTable) AND @FormulaCategory!='')
		BEGIN
			SET @EcolabCategory=@FormulaCategory
		END
		IF (EXISTS(SELECT * FROM @ChainCategoryTable) AND @FormulaCategory!='')
		BEGIN
			SET @ChainCategory=@FormulaCategory
		END

	-----Formula Ecolab/Chain categories
	DECLARE @FormulaTable TABLE(Formula Varchar(1000),Type CHAR(1))
    INSERT INTO @FormulaTable(Formula) EXEC [TCD].[CharlistToTable] @Formula,','	
						
		--Plant fomula   
		INSERT INTO @PlantFormulaTable(PlantFormula) 
		SELECT Formula FROM @FormulaTable 
		--chain formula   
		INSERT INTO @ChainFormulaTable(ChainFormula) 
		SELECT Formula FROM @FormulaTable 
		--SELECT * FROM @PlantFormulaTable
		--SELECT * FROM @ChainFormulaTable

		--Value Assigning
		IF (EXISTS(SELECT * FROM @PlantFormulaTable) AND @Formula!='')
		BEGIN
			SET @PlantFormula=@Formula
		END
		IF (EXISTS(SELECT * FROM @ChainFormulaTable) AND @Formula!='')
		BEGIN
			SET @ChainFormula=@Formula
		END
	--Formula end

 INSERT INTO @CorrectionFactor  
 (  
   [ShiftId],  
   [MachineId] ,  
   [ActualProduction] ,  
   [StandardProduction] ,  
   [PlantTargetProd] ,  
   [ActualRunTime] ,  
   [TargetRunTime],  
   ManualInputWeight,  
   ManulainputsNoofloads     
 )  
 SELECT   
  PS.[ShiftId],  
  SPD.[MachineId],  
  ISNULL([TCD].[FnConsumptionOnMetrics](SUM(ISNULL(SPD.[ActualProduction],0))+SUM(ISNULL(MIP.ActualWeight,0)),'Weight',@UserId),0),  
  --ISNULL([TCD].[FnConsumptionOnMetrics](SUM(SPD.[ActualProduction]),'Weight',@UserId),0),  
  --SUM(SPD.[ActualProduction]),  
  ISNULL([TCD].[FnConsumptionOnMetrics](SUM(SPD.StandardProduction),'Weight',@UserId),0),  
  --SUM(SPD.StandardProduction),  
  ISNULL([TCD].[FnConsumptionOnMetrics](SUM(DISTINCT SPD.[PlantTargetProd]),'Weight',@UserId),0),  
  --SUM(DISTINCT SPD.[PlantTargetProd]),  
  SUM(SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0)),  
  SUM(SPD.[TargetRunTime] + ISNULL(SPD.TargetTurnTime,0)),  
  SUM(ISNULL(MIP.ActualWeight,0)),SUM(ISNULL(MIP.NoofLoads,0))  
 FROM  TCD.ShiftProductionDataRollup SPD   
 INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId  
 INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId   
 LEFT OUTER JOIN --Manual Production Details appending  
  (  
  SELECT WasherId,FormulaId,CONVERT(DATE,RecordedDate) AS LoadDate,SUM(ISNULL(Value,0)) AS ActualWeight,  
  ISNULL(COUNT(CONVERT(DATE,RecordedDate)),0) AS NoofLoads FROM  
  TCD.ManualProduction MP  
  GROUP BY WasherId,FormulaId,CONVERT(DATE,RecordedDate)  
  )MIP ON MIP.WasherId=SPD.EcolabWasherId AND MIP.FormulaId=SPD.ProgramMasterId AND MIP.LoadDate=CONVERT(DATE,PS.StartDateTime)  
 WHERE   
 CASE @StartDate                                                                                  
 WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                  
 ELSE CASE WHEN PS.[StartDateTime] >= @startdate  AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                          
 END='TRUE'   
 GROUP BY MachineId,PS.ShiftId;  
  
	--SELECT * FROM 	@CorrectionFactor;
  
  
 WITH CTE (PlantTargetProd) AS  
 (  
 SELECT SUM(DISTINCT SPD.[PlantTargetProd]) FROM @CorrectionFactor SPD GROUP BY ShiftId  
 )  
 SELECT @PlantTargetProduction = SUM(PlantTargetProd) FROM CTE;  
  
  
 WITH CTE (MachineId,PlantEfficiency)  
 AS  
 (  
 SELECT   
  MachineId,  
  CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/   
   NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) *   
   COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2))     
   FROM @CorrectionFactor SPD GROUP BY MachineId  
 )  
    SELECT @CorrectionVariable = @PlantTargetProduction/NULLIF(SUM(PlantEfficiency),0) FROM CTE  
  
      
 DECLARE @ProductionSummaryTable TABLE(  
         [ShiftId] [int] NULL,  
         [ShiftName] Varchar(100) NULL,  
         RecordDate date,   
         [StartDateTime] [datetime] NULL,  
         [EndDateTime] [datetime] NULL,  
         [MachineId] [int] NULL,  
         [EcolabWasherId] [int] NULL,  
         [ActualProduction] [int] NULL,  
         [StandardProduction] [int] NULL,  
         [NoOfLoads] [int] NULL,  
         [LoadEfficiency] [decimal](18, 2) NULL,  
         [TimeEfficiency] [decimal](18, 2) NULL,  
         TotalEfficiency [decimal](18, 2) NULL,  
         [PlantTargetProd] [int] NULL,  
         [ActualRunTime] [int] NULL,  
         [TargetRunTime] [int] NULL,  
         [ShiftRunTime] [int] NULL,  
   RowNumberID INT NULL,  
		 ProgramMasterID INT NULL,
		 EcolabTextileId int,
		 ChainTextileId int,
		 ChainProgaramId int,
		 FormulaSegmentID INT,
		 CustomerId int 
             )  
 INSERT INTO @ProductionSummaryTable  
 (  
 [ShiftId] ,[ShiftName] ,RecordDate, [StartDateTime] ,[EndDateTime] ,[MachineId]  ,[EcolabWasherId]  ,  
 [ActualProduction] ,[StandardProduction] ,[NoOfLoads] ,[LoadEfficiency],[TimeEfficiency] ,TotalEfficiency ,  
	[PlantTargetProd],[ActualRunTime] ,[TargetRunTime] ,[ShiftRunTime] ,RowNumberID ,ProgramMasterID,
	EcolabTextileId,ChainTextileId,ChainProgaramId,FormulaSegmentID,CustomerId
 )  
    SELECT   
 SPD.[ShiftId],  
 PS.ShiftName,  
 CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date),  
 DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]),  
 DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[EndDateTime]),          
 SPD.[MachineId],  
 SPD.[EcolabWasherId],  
 SPD.[ActualProduction],  
 SPD.StandardProduction,  
 SPD.[NoOfLoads],  
 SPD.[LoadEfficiency],  
 SPD.[TimeEfficiency],  
 (SPD.[LoadEfficiency] * SPD.TimeEfficiency),  
 SPD.[PlantTargetProd],  
 SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0),  
 SPD.[TargetRunTime] + ISNULL(SPD.TargetTurnTime,0),  
 DATEDIFF(Second,ps.StartDateTime,PS.EndDateTime) +  
 ISNULL(  
 (  
 SELECT  
 SUM(SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0))  
  FROM TCD.ShiftProductionDataRollup SPD   
 INNER JOIN TCD.ProductionShiftData PSD ON SPD.ShiftId = PSD.ShiftId  
 INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId   
 WHERE   
 PSD.[StartDateTime] = PS.StartDateTime AND PSD.[StartDateTime] = PS.EndDateTime AND PS.ShiftName = 'No Shift'  
 ),0),  
 ROW_NUMBER() OVER(Partition BY SPD.ProgramMasterId, SPD.[EcolabWasherId], CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date)  
 ORDER BY SPD.ProgramMasterId, SPD.[EcolabWasherId] ),  
	SPD.ProgramMasterId,
	SPD.EcolabTextileId,SPD.ChainTextileId,SPD.ChainProgaramId,
    CASE WHEN SPD.ChainProgaramId IS NOT NULL THEN ChainPlant.FormulaSegmentId
	ELSE FS1.FormulaSegmentID END AS Formulasegment,
	SPD.CustomerId
      
 FROM TCD.ShiftProductionDataRollup SPD   
 INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId  
 INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
 INNER JOIN TCD.MachineSetup ms ON SPD.MachineId = ms.WasherId  
	LEFT OUTER JOIN
		 (
			--IF Chain Plant
			SELECT PCP.PlantProgramId,PCP.PlantChainId,PCP.ChainTextileCategoryId,PCP.EcolabTextileCategoryId,
			PCP.FormulaSegmentId,PCP.EcolabSaturationId
			FROM TCD.PlantChainProgram PCP 
			LEFT OUTER JOIN TCD.ChainTextileCategory CTC ON CTC.TextileId=PCP.ChainTextileCategoryId
			LEFT OUTER JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId=PCP.EcolabTextileCategoryId
			LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=PCP.FormulaSegmentId
			LEFT OUTER JOIN TCD.EcolabSaturation ES ON ES.EcolabSaturationId=PCP.EcolabSaturationId
		 )ChainPlant ON SPD.ChainProgaramId=ChainPlant.PlantProgramId

	LEFT OUTER JOIN TCD.EcolabTextileCategory ETC1 ON ETC1.TextileId=PM.EcolabTextileCategoryId
	LEFT OUTER JOIN TCD.FormulaSegments FS1 ON FS1.FormulaSegmentID=PM.FormulaSegmentId
	LEFT OUTER JOIN TCD.EcolabSaturation ES1 ON ES1.EcolabSaturationId=PM.EcolabSaturationId
    WHERE isNull(ms.IsPony,0) = 0  
    AND   
       CASE @StartDate                                                                                  
       WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                  
       ELSE CASE WHEN PS.[StartDateTime] >= @startdate AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                          
       END='TRUE'  
  
     AND  
       CASE @MachineType     
       WHEN '' THEN 'TRUE'           
       ELSE                                                        
       CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE        
       MS.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable))) THEN 'TRUE' END                                                        
       END='TRUE'       
     AND         
  
  CASE @machineGroup     
  WHEN '' THEN 'TRUE'           
  ELSE                                                        
  CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE        
  MS.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable)) THEN 'TRUE' END                                                        
  END='TRUE'   
  AND  
  
  CASE @Machine     
  WHEN '' THEN 'TRUE'           
  ELSE                                                        
  CASE WHEN SPD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                   
  END='TRUE'   
  AND  
      
  CASE @EcolabCategory     
  WHEN '' THEN 'TRUE'           
  ELSE                                                        
  CASE WHEN SPD.EcolabTextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                        
  END='TRUE'   
  AND  
      
  CASE @ChainCategory     
  WHEN '' THEN 'TRUE'           
  ELSE                                                        
  CASE WHEN SPD.ChainTextileId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END                                                        
  END='TRUE'  
  AND  
  
  CASE @PlantFormula     
  WHEN '' THEN 'TRUE'           
  ELSE                                                        
  CASE WHEN SPD.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                        
  END='TRUE'    
  AND  
      
  CASE @ChainFormula     
  WHEN '' THEN 'TRUE'           
  ELSE                                                        
		CASE WHEN SPD.ProgramMasterId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END                                                      
  END='TRUE'  
  AND  
      
  CASE @Customer     
  WHEN '' THEN 'TRUE'           
   ELSE                                                        
   CASE WHEN SPD.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                        
  END='TRUE'   
	--Added by Kiran	
    AND 
		CASE @FormulaSegement                                                                                
		WHEN '' THEN  'TRUE'
		ELSE
			CASE WHEN SPD.ChainProgaramId  IS NOT NULL THEN
				CASE WHEN ChainPlant.FormulaSegmentId IN (SELECT FormulaSegment FROM @FormulaSegmentTable) THEN 'TRUE' END						                                                                               
			ELSE 
				CASE WHEN FS1.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)  THEN 'TRUE'END   
			END                                                     
		END='TRUE'
  
 --Updating Actual Production based Manual Production  
 UPDATE S SET ActualProduction=ISNULL(S.ActualProduction,0)+ISNULL(MIP.ManualIPActualWeight,0),S.NoOfLoads=ISNULL(S.NoOfLoads,0)+ISNULL(MIP.NoofLoads,0)  
 FROM  @ProductionSummaryTable S  
 INNER JOIN   
  (  
  SELECT WasherId,FormulaId,CONVERT(DATE,RecordedDate) AS LoadDate,SUM(Value) AS ManualIPActualWeight,  
  COUNT(CONVERT(DATE,RecordedDate)) AS NoofLoads FROM  
  TCD.ManualProduction MP  
  GROUP BY WasherId,FormulaId,CONVERT(DATE,RecordedDate)  
  )MIP ON MIP.WasherId=S.MachineId AND MIP.FormulaId=S.ProgramMasterId AND MIP.LoadDate=S.RecordDate  
  WHERE S.RowNumberID=1  
  
  
  
    IF(@Viewtype = 1)  
    BEGIN  
        ---- By TimeLine - Day View-------------  
  IF(@Subview = 5)  
  BEGIN  
   INSERT INTO @resultSet  
   SELECT   
    0,  
    SPD.ShiftName,  
    SUM(SPD.ActualProduction),  
    COALESCE(SUM(SPD.ActualProduction)/   
    NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),  
    SUM(DISTINCT SPD.PlantTargetProd),  
    SUM([NoOfLoads]),  
    SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(DISTINCT SPD.ShiftRunTime)  
    ,@Viewtype   
    ,@Subview  
    ,0  
    FROM @ProductionSummaryTable SPD  
   GROUP BY   
   SPD.ShiftName  
  END  
  
  ---- By TimeLine - Week View  
  IF (@Subview = 4)  
  BEGIN  
   WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime)  
   AS  
   (  
     SELECT   
     CAST(RecordDate AS nvarchar(100)),  
    SUM(SPD.ActualProduction),  
      COALESCE(SUM(SPD.ActualProduction)/   
    NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),  
    SUM(DISTINCT SPD.PlantTargetProd),  
    SUM([NoOfLoads]),  
    SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(DISTINCT SPD.ShiftRunTime)  
     FROM @ProductionSummaryTable SPD  
     GROUP BY DATEPART(weekday,RecordDate),RecordDate,SPD.ShiftId    
   )  
  
   INSERT INTO @resultSet  
    SELECT    
      0,   
      DateRange,  
      SUM(TotalLoad),  
      SUM(TotalEfficiency),  
      SUM(PlantTargetLoad),  
      SUM(Numberofbatches),  
      SUM(ActualRunTime),  
      SUM(TargetRuntime)  
      ,@Viewtype   
      ,@Subview  
       ,0  
     FROM CTE   
     WHERE TotalLoad IS NOT NULL  
    GROUP BY DateRange  
  END  
  
        ---- By TimeLine - Month View  
  IF(@Subview = 3)  
  BEGIN  
   DECLARE @FirstDay date = (SELECT TOP 1 RecordDate FROM @ProductionSummaryTable ORDER BY RecordDate)  
   DECLARE @LastDay date = (SELECT TOP 1 RecordDate FROM @ProductionSummaryTable ORDER BY RecordDate DESC)  
   DECLARE @FirstSunday date = NULL,  
   @LastSaturday date = NULL  
  
      
   SELECT   
   @FirstSunday = CAST(DateAdd(dd, (8-DatePart(WEEKDAY,   
      DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)))%7,   
      DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)) AS DATE)   
  
    SELECT  
     @LastSaturday =   
    DATEADD(dd,  
     -DATEPART(WEEKDAY,  
       DATEADD(dd, -DAY(DATEADD(month, 1, @LastDay)),  
       DATEADD(month, 1, @LastDay))) ,  
     DATEADD(dd, -DAY(DATEADD(MONTH, 1, @LastDay)), DATEADD(MONTH, 1, @LastDay)));  
      
   WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime)  
   AS  
   (  
   SELECT   
         
      CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,-1,@FirstSunday)) = 7   
      AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate < DATEADD(DD,-1,@FirstSunday)) = 0)  
      THEN CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100))  
      WHEN DATEADD(DD,-1,@FirstSunday) > CAST(GETDATE() AS DATE)   
      THEN  
      CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @enddate, 101) AS nvarchar(100))  
      ELSE  
      CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) END As DateRange,  
      SUM(SPD.ActualProduction),  
    COALESCE(SUM(SPD.ActualProduction)/   
    NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),  
    SUM(DISTINCT SPD.PlantTargetProd),  
    SUM([NoOfLoads]),  
    SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(DISTINCT SPD.ShiftRunTime)  
    FROM @ProductionSummaryTable SPD  
    WHERE RecordDate < @FirstSunday AND RecordDate >= @FirstDay   
    GROUP BY SPD.ShiftId  
  
          
    UNION ALL  
  
    
    SELECT   
         
    --CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100)) AS StartDate,  
    --CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) AS EndDate,  
      CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100))  + CHAR(13) + '-' +  
     CASE WHEN CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) >  
     CAST(Convert(varchar, DateAdd(dd, (1 - DatePart(dw, @enddate) + 1), @enddate), 101) AS nvarchar(100))  
     THEN  CAST(Convert(varchar, DateAdd(dd, 1-1, @enddate), 101) AS nvarchar(100))  
     ELSE CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) END  
     As DateRange,  
    SUM(SPD.ActualProduction),  
    COALESCE(SUM(SPD.ActualProduction)/   
    NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),  
    SUM(DISTINCT SPD.PlantTargetProd),  
    SUM([NoOfLoads]),  
    SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(DISTINCT SPD.ShiftRunTime)  
    FROM @ProductionSummaryTable SPD  
       WHERE RecordDate BETWEEN @FirstSunday AND @LastSaturday  
    GROUP BY Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101),  
     Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101),SPD.ShiftId  
         
      UNION ALL  
  
    SELECT   
         
    CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,1,@LastSaturday)) = 1   
    AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate > DATEADD(DD,1,@LastSaturday)) = 0)  
    THEN   
    CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100))   
    ELSE  
      CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @LastDay, 101) AS nvarchar(100)) END   As DateRange,  
    SUM(SPD.ActualProduction),  
    COALESCE(SUM(SPD.ActualProduction)/   
    NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),  
    SUM(DISTINCT SPD.PlantTargetProd),  
    SUM([NoOfLoads]),  
    SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(DISTINCT SPD.ShiftRunTime)  
    FROM @ProductionSummaryTable SPD  
    WHERE RecordDate > @LastSaturday AND RecordDate <= @LastDay GROUP BY SPD.ShiftId  
    )  
    INSERT INTO @resultSet  
     SELECT    
     0,   
     DateRange,  
     SUM(TotalLoad),  
     SUM(TotalEfficiency),  
     SUM(PlantTargetLoad),  
     SUM(Numberofbatches),  
     SUM(ActualRunTime),  
     SUM(TargetRuntime)  
     ,@Viewtype   
     ,@Subview  
      ,0  
     FROM CTE   
     WHERE TotalLoad IS NOT NULL  
    GROUP BY DateRange  
  
        END  
  
  IF(@Subview = 2)  
  BEGIN  
   DECLARE @QuarterYear VARCHAR(100) = YEAR(@enddate);  
   WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime)  
   AS  
   (  
    SELECT          
    DATENAME(MONTH, RecordDate) + ' ' + @QuarterYear As DateRange,  
    SUM(SPD.ActualProduction),  
    COALESCE(SUM(SPD.ActualProduction)/   
    NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),  
    SUM(DISTINCT SPD.PlantTargetProd),  
    SUM([NoOfLoads]),  
    SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(DISTINCT SPD.ShiftRunTime)  
    FROM @ProductionSummaryTable SPD  
    GROUP BY  DATEPART(MONTH, RecordDate),DATENAME(MONTH, RecordDate),SPD.ShiftId  
  
   )  
   INSERT INTO @resultSet  
   SELECT    
       0,   
       DateRange,  
       SUM(TotalLoad),  
       SUM(TotalEfficiency),  
       SUM(PlantTargetLoad),  
       SUM(Numberofbatches),  
       SUM(ActualRunTime),  
       SUM(TargetRuntime)  
       ,@Viewtype   
       ,@Subview  
        ,0  
     FROM CTE   
     WHERE TotalLoad IS NOT NULL  
    GROUP BY DateRange  
  END     
  
  IF(@Subview = 1)  
  BEGIN  
   DECLARE @Year VARCHAR(100) = RIGHT(YEAR(@enddate),2);  
   WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,RowNo)  
   AS  
   (  
    SELECT   
      CASE 'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10))  
        WHEN 'Q1' THEN 'Jan' + @Year + '- Mar' + @Year  
        WHEN 'Q2' THEN 'Apr' + @Year + '- Jun' + @Year  
        WHEN 'Q3' THEN 'Jul' + @Year + '-Sep' + @Year  
        WHEN 'Q4' THEN 'Oct' + @Year + '- Dec'+ @Year  
    END AS DateRange,  
    SUM(SPD.ActualProduction),  
    COALESCE(SUM(SPD.ActualProduction)/   
    NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),  
    SUM(DISTINCT SPD.PlantTargetProd),  
    SUM([NoOfLoads]),  
    SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(DISTINCT SPD.ShiftRunTime)  ,
	 DATEPART(QUARTER, RecordDate) RowNo
    FROM @ProductionSummaryTable SPD  
    GROUP BY DATEPART(QUARTER, RecordDate),SPD.ShiftId  
   )  
  
   INSERT INTO @resultSet  
   SELECT    
       0,   
       DateRange,  
       SUM(TotalLoad),  
       SUM(TotalEfficiency),  
       SUM(PlantTargetLoad),  
       SUM(Numberofbatches),  
       SUM(ActualRunTime),  
       SUM(TargetRuntime)  
       ,@Viewtype   
       ,@Subview  
        ,0  
     FROM CTE   
     WHERE TotalLoad IS NOT NULL  
    GROUP BY DateRange  ,RowNo
	ORDER BY RowNo
  END  
    END  
      
    -- ******************************** Location View ***************************************************  
    IF(@Viewtype = 2)  
    BEGIN  
  
  IF(@Subview = 9)  
  BEGIN  
  
   WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,WasherGroupId)  
   AS  
   (  
    SELECT    
    --SPD.MachineId,      
     WG.WasherGroupName,  
   SUM(SPD.ActualProduction),  
   CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/   
   NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) *   
   COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),  
   SUM(DISTINCT SPD.PlantTargetProd),  
   SUM([NoOfLoads]),  
   SUM(DISTINCT SPD.ShiftRunTime),  
   SUM(DISTINCT SPD.ShiftRunTime),  
   WG.WasherGroupId  
   FROM @ProductionSummaryTable SPD LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId  
      LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId   
   GROUP BY WG.WasherGroupName,WG.WasherGroupId,SPD.ShiftId--,SPD.MachineId  
   )  
  
    INSERT INTO @resultSet  
    SELECT    
      0,   
     DateRange,  
     SUM(TotalLoad),  
     SUM(TotalEfficiency),  
     @PlantTargetProduction,  
     SUM(Numberofbatches),  
     SUM(ActualRunTime),  
     SUM(TargetRuntime)  
     ,@Viewtype   
     ,@Subview  
      ,WasherGroupId  
     FROM CTE   
     WHERE TotalLoad IS NOT NULL         
    GROUP BY DateRange,WasherGroupId  
  END  
  
  IF(@Subview = 10)  
  BEGIN  
    WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime)  
   AS  
   (  
    SELECT           
    cast( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName as MachineName,  
    SUM(SPD.ActualProduction),  
    CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/   
    NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) *   
    COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),  
    SUM(DISTINCT SPD.PlantTargetProd),  
    SUM([NoOfLoads]),  
    SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(DISTINCT SPD.ShiftRunTime)          
    FROM @ProductionSummaryTable SPD   
    LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId  
    LEFT JOIN TCD.Washer w on MS.WasherId=w.WasherId  
      LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId   
    WHERE   
     (  
      CASE @drillvalue     
       WHEN '' THEN 'TRUE'           
       ELSE                                                      
     CASE WHEN WG.WasherGroupId IN (@drillvalue) THEN 'TRUE' END              
       END='TRUE'  
     )  
    GROUP BY cast( W.PlantWasherNumber as varchar(20))+':'+MS.MachineName,SPD.ShiftId   
          
   )  
  
    INSERT INTO @resultSet  
    SELECT   
    0,   
     DateRange,  
     SUM(TotalLoad),  
     SUM(TotalEfficiency),  
     @PlantTargetProduction,  
     SUM(Numberofbatches),  
     SUM(ActualRunTime),  
     SUM(TargetRuntime)  
     ,@Viewtype   
     ,@Subview  
      ,0  
     FROM CTE   
     WHERE TotalLoad IS NOT NULL  
    GROUP BY DateRange  
  END  
  
    END  
	 --******************************** Formula View ****************************************************
	IF(@Viewtype = 7)
	BEGIN
		 WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,WasherGroupId)
			AS
			(
			SELECT  				    
			PM.Name,
			SUM(SPD.ActualProduction),
			CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
			NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
			COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
			SUM(DISTINCT SPD.PlantTargetProd),
			SUM([NoOfLoads]),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(DISTINCT SPD.ShiftRunTime),
			PM.ProgramId
			FROM @ProductionSummaryTable SPD
			INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
			Group by PM.Name,PM.ProgramId
			)
			 INSERT INTO @resultSet
			 SELECT  
			   0, 
			  DateRange,
			  SUM(TotalLoad),
			  SUM(TotalEfficiency),
			  @PlantTargetProduction,
			  SUM(Numberofbatches),
			  SUM(ActualRunTime),
			  SUM(TargetRuntime)
			  ,@Viewtype 
			  ,@Subview
			   ,WasherGroupId
				FROM CTE 
				WHERE TotalLoad IS NOT NULL       
				GROUP BY DateRange,WasherGroupId
    END

-- ******************************** Formula segmentView ****************************************************
	IF(@Viewtype = 8)
	BEGIN
		IF(@Subview =20)-- Formula Segment
		BEGIN	
			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,FormulaSegmentID)
			AS
			(
			SELECT  				    
			FS.SegmentName,
			SUM(SPD.ActualProduction),
			CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
			NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
			COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
			SUM(DISTINCT SPD.PlantTargetProd),
			SUM([NoOfLoads]),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(DISTINCT SPD.ShiftRunTime),
			SPD.FormulaSegmentID
			FROM @ProductionSummaryTable SPD
			INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
			LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=SPD.FormulaSegmentID
			Group by SPD.FormulaSegmentID,FS.SegmentName			
			)
			 INSERT INTO @resultSet
			 SELECT  
			   0, 
			  DateRange,
			  SUM(TotalLoad),
			  SUM(TotalEfficiency),
			  @PlantTargetProduction,
			  SUM(Numberofbatches),
			  SUM(ActualRunTime),
			  SUM(TargetRuntime)
			  ,@Viewtype 
			  ,@Subview
			   ,FormulaSegmentID
				FROM CTE 
				WHERE TotalLoad IS NOT NULL       
				GROUP BY DateRange,FormulaSegmentID
		END
		IF(@Subview =21)-- Formula Categories
		BEGIN		
			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,TextileId)
			AS
			(
				SELECT EC.CategoryName,SUM(SPD.ActualProduction),
				CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
				NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
				COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
				SUM(DISTINCT SPD.PlantTargetProd),SUM([NoOfLoads]),SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime),EC.TextileId
				FROM @ProductionSummaryTable SPD
				LEFT JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
				WHERE EC.CategoryName IS NOT NULL
				GROUP BY EC.CategoryName,EC.TextileId	
				
				UNION

				SELECT CC.Name,SUM(SPD.ActualProduction),
				CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
				NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
				COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
				SUM(DISTINCT SPD.PlantTargetProd),SUM([NoOfLoads]),SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime),CC.TextileId
				FROM @ProductionSummaryTable SPD
				INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
				INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = SPD.ChainProgaramId
				INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId 
				Group by CC.Name,cc.TextileId
  
			)
			 INSERT INTO @resultSet
      SELECT         
			   0, 
      DateRange,  
			  SUM(TotalLoad),
			  SUM(TotalEfficiency),
			  @PlantTargetProduction,
			  SUM(Numberofbatches),
			  SUM(ActualRunTime),
			  SUM(TargetRuntime)
			  ,@Viewtype 
			  ,@Subview
			  ,TextileId
				FROM CTE 
				WHERE TotalLoad IS NOT NULL       
				GROUP BY DateRange,TextileId
		END
		IF(@Subview=22) --Formula
		BEGIN
			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,WasherGroupId)
			AS
			(
				SELECT PM.Name,SUM(SPD.ActualProduction),
				CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
				NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
				COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
				SUM(DISTINCT SPD.PlantTargetProd),SUM([NoOfLoads]),SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime),PM.ProgramId
				FROM @ProductionSummaryTable SPD
				INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
				INNER JOIN TCD.ProgramMaster PM ON EC.TextileId = PM.EcolabTextileCategoryId AND SPD.ProgramMasterId = PM.ProgramId    
				WHERE
					(
					CASE    
						WHEN @drillvalue='' THEN 'TRUE' 
						WHEN @drillvalue IS NULL THEN 'TRUE'  
						ELSE                                                    
						CASE WHEN EC.TextileId IN (@drillvalue) THEN 'TRUE' END            
						END='TRUE'
					) AND PM.NAME IS NOT NULL
				GROUP BY PM.Name,PM.ProgramId	
				
				UNION

				SELECT PM.Name,SUM(SPD.ActualProduction),
				CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
				NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
				COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
				SUM(DISTINCT SPD.PlantTargetProd),SUM([NoOfLoads]),SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime),PM.ProgramId
				FROM @ProductionSummaryTable SPD 
				INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
				INNER JOIN TCD.ProgramMaster PM ON  SPD.ProgramMasterId = PM.ProgramId		
				WHERE
					(
					 CASE    
					 WHEN @drillvalue='' THEN 'TRUE' 
					 WHEN @drillvalue IS NULL THEN 'TRUE'  
					 ELSE                                                    
					 CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END            
					 END='TRUE'
					)
				GROUP BY PM.Name,PM.ProgramId
						
			)
			 INSERT INTO @resultSet
			 SELECT  
			   0, 
			  DateRange,
			  SUM(TotalLoad),
			  SUM(TotalEfficiency),
			  @PlantTargetProduction,
			  SUM(Numberofbatches),
			  SUM(ActualRunTime),
			  SUM(TargetRuntime)
			  ,@Viewtype 
			  ,@Subview
			  ,WasherGroupId
				FROM CTE 
				WHERE TotalLoad IS NOT NULL       
				GROUP BY DateRange,WasherGroupId
			
		END
	END

      SELECT       
      DateRange,
      ISNULL([TCD].[FnConsumptionOnMetrics](TotalLoad,'Weight',@UserId),0),  
      --ISNULL(TotalLoad,0),  
      ISNULL([TCD].[FnConsumptionOnMetrics](WasherEfficiency,'Weight',@UserId),0),  
      --ISNULL(WasherEfficiency,0),  
      ISNULL([TCD].[FnConsumptionOnMetrics](PlantTargetLoad,'Weight',@UserId),0),  
      --ISNULL(PlantTargetLoad,0),  
      ISNULL(Numberofbatches,0),  
      ISNULL([ActualRunTime],0) [ActualRunTime],  
      ISNULL([TargetRunTime],0) [TargetRunTime],  
      Viewtype,  
      Subview,  
      Id,  
      ShiftId,  
      @CorrectionVariable  
      FROM @resultSet   

SET NOCOUNT OFF
END  
GO 

IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[ReportProductionDetails]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[ReportProductionDetails] 
END 
GO 
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ReportProductionDetails] 
/******************************************************************
DESCRIPTION		: 


MODIFICATION HISTORY DETAILS:	
	21st Jan 2015 -  Kiran     -  Added Formula hierarchy -->Formula segment-->Formula category-->formula


REFERENC TABLES :
		Select * from TCD.Plant --Plant master
		Select * FROM TCD.PlantChain  --Master Plants
		Select * FROM TCD.PlantChainProgram
		Select * FROM TCD.ChainTextileCategory
		Select * FROM TCD.ProgramMaster
		Select * FROM TCD.EcolabTextileCategory  --Masters
		Select * FROM TCD.EcolabSaturation --Masters
		Select * FROM TCD.FormulaSegments --Masters

EXECUTION STATEMENT :

	EXEC [TCD].[ReportProductionDetails1] @startdate = '2015-01-11',@enddate = '2016-01-30',@Viewtype  = '7',@Subview = '',
										@Drillvalue = '',@EcolabAccountNumber = '040242802',@MachineType = '', @MachineGroup  = '',@Machine  = '', 
										@EcolabCategory  = '',@ChainCategory  = '', @PlantFormula  = '', @ChainFormula = '', @Customer  = '',
										@SortColumnId  = 0,@SortDirection  = '',@CurrencyCode = '', @UserId = 1, @FormulaSegement ='',
										@FormulaCategory='',@Formula=''


*******************************************************************/

     @startdate datetime = '',
     @enddate datetime = '',
     @Viewtype Int = '',
     @Subview Int= '',
     @Drillvalue varchar(100)= '',
     @EcolabAccountNumber Nvarchar(25) = '',
     @MachineType VARCHAR(20)= '',
     @MachineGroup VARCHAR(MAX) = '',
     @Machine VARCHAR(MAX) = '',
     @EcolabCategory VARCHAR(MAX) = '',
     @ChainCategory VARCHAR(MAX) = '',
     @PlantFormula  VARCHAR(MAX) = '',
     @ChainFormula VARCHAR(MAX) = '',
     @Customer VARCHAR(MAX) = '',
     @SortColumnId int = 0,
     @SortDirection varchar(4) = '',
     @CurrencyCode varchar(3) = '',
     @UserId INT = NULL,
	 @FormulaSegement VARCHAR(MAX)='', --Formula segment,
	 @FormulaCategory VARCHAR(MAX)='', --Formula category
	 @Formula VARCHAR(MAX)='' --Formula
AS   
BEGIN   
SET NOCOUNT ON 
	SET @startdate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@startdate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@startdate AS time)) AS DateTime))
	SET @EndDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndDate AS time)) AS DateTime))

	
	DECLARE @ReportGenerated INT = 6, @Month INT = MONTH(GETDATE()),@CorrectionVariable Decimal(18,2),@PlantTargetProduction decimal(18,2)
      --,@ShiftRuntime int,@NoShiftTotalRuntime INT,@TotaRuntime int

	/* Inserting the record into Report History */
	INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)
	SELECT @EcolabAccountNumber,UM.UserId,UM.LoginName,GETUTCDATE(),@ReportGenerated,
	CASE WHEN @ReportGenerated = 6
		THEN 'Generated Report : Production Details Report' END
	FROM TCD.UserMaster UM
	WHERE UM.EcolabAccountNumber = @EcolabAccountNumber AND UM.UserId = @UserId

    /* Completed the record insertion into Report History */ 

    -- Return Table set
    DECLARE @resultSet Table
    (
      ShiftId Int,
      DateRange varchar(100),
      TotalLoad Decimal(18,2) ,
      WasherEfficiency Decimal(18,2),
      PlantTargetLoad Decimal(18,2) ,
      StandardLoad Decimal(18,2) ,
      Numberofbatches INT,
      [ActualRunTime] [int] NULL,
      [TargetRunTime] [int] NULL,
      NumberofPieces  [int] NULL,
      Rewash [int] NULL,
      Viewtype varchar(100) NULL,
      Subview varchar(100) NULL,
      Id int NULL      
    )

    DECLARE @CorrectionFactor TABLE 
   (
    [ShiftId] [int] NULL,
    MachineId INT NULL,
    [ActualProduction] [int] NULL,
    [StandardProduction] [int] NULL,
    [PlantTargetProd] [int] NULL,
    [ActualRunTime] [int] NULL,
    [TargetRunTime] [int] NULL,
	ManualInputWeight INT,
	ManulainputsNoofloads INT
   )
    
	--Machine type
	DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))
	INSERT INTO @MachineTypeTable EXEC [TCD].[CharlistToTable] @MachineType,','

	--washer Group
	DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))
	INSERT INTO @WasherGroupTable EXEC [TCD].[CharlistToTable] @machineGroup,','  

	--Machine list
	DECLARE @MachineTable TABLE(Machine Varchar(100))
	INSERT INTO @MachineTable EXEC [TCD].[CharlistToTable] @Machine,','

	--Ecolab category
	DECLARE @EcolabCategoryTable TABLE(EcolabCategory Varchar(100))
	INSERT INTO @EcolabCategoryTable EXEC [TCD].[CharlistToTable] @EcolabCategory,','

	--Chain category
	DECLARE @ChainCategoryTable TABLE(ChainCategory Varchar(100))
	INSERT INTO @ChainCategoryTable EXEC [TCD].[CharlistToTable] @ChainCategory,','

	--Plant formula
	DECLARE @PlantFormulaTable TABLE(PlantFormula Varchar(100))
	INSERT INTO @PlantFormulaTable EXEC [TCD].[CharlistToTable] @PlantFormula,','

	--Chain Formula
	DECLARE @ChainFormulaTable TABLE(ChainFormula Varchar(100))
	INSERT INTO @ChainFormulaTable EXEC [TCD].[CharlistToTable] @ChainFormula,','

	--Customer Table
	DECLARE @CustomerTable TABLE(Customer Varchar(100))
	INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','

	--Formula Segment --added by Kiran
	DECLARE @FormulaSegmentTable TABLE(FormulaSegment Varchar(1000))
    INSERT INTO @FormulaSegmentTable EXEC [TCD].[CharlistToTable] @FormulaSegement,','

	-----Formula category--------Start
	DECLARE @FormulaCategoryTable TABLE(FormulaCategory Varchar(1000),Type CHAR(1))
    INSERT INTO @FormulaCategoryTable(FormulaCategory) EXEC [TCD].[CharlistToTable] @Formulacategory,','
	
	--segregating Ecolab/Chain categories
	--UPDATE @FormulaCategoryTable SET TYPE=RIGHT(FormulaCategory,1),FormulaCategory=LEFT(FormulaCategory,LEN(FormulaCategory)-2)

	--Below 1000 Ecolab category
	UPDATE @FormulaCategoryTable SET TYPE='E' WHERE FormulaCategory<1000
	--Above 1000 consider as Chain category
	UPDATE @FormulaCategoryTable SET TYPE='C' WHERE FormulaCategory>=1000

	--Rollbacking to actual ID
	UPDATE @FormulaCategoryTable SET FormulaCategory=FormulaCategory-1000 WHERE TYPE='C'
	--SELECT * FROM @FormulaCategoryTable

	INSERT INTO @EcolabCategoryTable(EcolabCategory)
	SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='E'	

	INSERT INTO @ChainCategoryTable(ChainCategory)
	SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='C'

	--Value Assigning
	IF (EXISTS(SELECT * FROM @EcolabCategoryTable) AND @FormulaCategory!='')
	BEGIN
		SET @EcolabCategory=@FormulaCategory
	END
	IF (EXISTS(SELECT * FROM @ChainCategoryTable) AND @FormulaCategory!='')
	BEGIN
		SET @ChainCategory=@FormulaCategory
	END
	---Formula category-------------------------End

	-----Formula Ecolab/Chain categories
	DECLARE @FormulaTable TABLE(Formula Varchar(1000),Type CHAR(1))
    INSERT INTO @FormulaTable(Formula) EXEC [TCD].[CharlistToTable] @Formula,','

	--segregating Ecolab/Chain categories
	--UPDATE @FormulaTable SET TYPE=RIGHT(Formula,1),Formula=LEFT(Formula,LEN(Formula)-2)
	/*
	--Below 1000 Ecolab category
	UPDATE @FormulaTable SET TYPE='E' WHERE Formula<1000
	--Above 1000 consider as Chain category
	UPDATE @FormulaTable SET TYPE='C' WHERE Formula>=1000

	--Rollbacking to actual ID
	UPDATE @FormulaTable SET Formula=Formula-1000 WHERE TYPE='C'
	*/
	--Select * from @FormulaTable
	--Plant fomula   
    INSERT INTO @PlantFormulaTable(PlantFormula) 
	SELECT Formula FROM @FormulaTable --WHERE Type='E'
	--chain formula   
    INSERT INTO @ChainFormulaTable(ChainFormula) 
	SELECT Formula FROM @FormulaTable --WHERE Type='C'
	--SELECT * FROM @PlantFormulaTable
	--SELECT * FROM @ChainFormulaTable

	--Value Assigning
	IF (EXISTS(SELECT * FROM @PlantFormulaTable) AND @Formula!='')
	BEGIN
		SET @PlantFormula=@Formula
	END
	IF (EXISTS(SELECT * FROM @ChainFormulaTable) AND @Formula!='')
	BEGIN
		SET @ChainFormula=@Formula
	END
	--SELECT @PlantFormula,@ChainFormula
	-----Formula Segregation end

	--Insert Into @CorrectionFactor table
	INSERT INTO @CorrectionFactor
	(
		[ShiftId],
		[MachineId] ,
		[ActualProduction] ,
		[StandardProduction] ,
		[PlantTargetProd] ,
		[ActualRunTime] ,
		[TargetRunTime],
		ManualInputWeight,
		ManulainputsNoofloads		 
	)
	SELECT 
		PS.[ShiftId],
		SPD.[MachineId],
		ISNULL([TCD].[FnConsumptionOnMetrics](SUM(ISNULL(SPD.[ActualProduction],0))+SUM(ISNULL(MIP.ActualWeight,0)),'Weight',@UserId),0),
		--ISNULL([TCD].[FnConsumptionOnMetrics](SUM(ISNULL(SPD.[ActualProduction],0)),'Weight',@UserId),0),		
		--SUM(SPD.[ActualProduction]),
		ISNULL([TCD].[FnConsumptionOnMetrics](SUM(ISNULL(SPD.StandardProduction,0)),'Weight',@UserId),0),
		--SUM(SPD.StandardProduction),
		ISNULL([TCD].[FnConsumptionOnMetrics](SUM(DISTINCT ISNULL(SPD.[PlantTargetProd],0)),'Weight',@UserId),0),
		--SUM(DISTINCT SPD.[PlantTargetProd]),
		SUM(ISNULL(SPD.[ActualRunTime],0) + ISNULL(SPD.ActualTurnTime,0)),
		SUM(ISNULL(SPD.[TargetRunTime],0) + ISNULL(SPD.TargetTurnTime,0)),
		SUM(ISNULL(MIP.ActualWeight,0)),SUM(ISNULL(MIP.NoofLoads,0))
	FROM  TCD.ShiftProductionDataRollup SPD 
	INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId
	LEFT OUTER JOIN --Manual Production Details appending
		(
			SELECT WasherId,FormulaId,CONVERT(DATE,RecordedDate) AS LoadDate,SUM(ISNULL(Value,0)) AS ActualWeight,
			ISNULL(COUNT(CONVERT(DATE,RecordedDate)),0) AS NoofLoads FROM
			TCD.ManualProduction MP
			GROUP BY WasherId,FormulaId,CONVERT(DATE,RecordedDate)
		)MIP ON MIP.WasherId=SPD.EcolabWasherId AND MIP.FormulaId=SPD.ProgramMasterId AND MIP.LoadDate=CONVERT(DATE,PS.StartDateTime)
	WHERE 
		CASE @StartDate                                                                                
		WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
		ELSE CASE WHEN PS.[StartDateTime] >= @startdate  AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
		END='TRUE' 
	GROUP BY MachineId,PS.ShiftId;

	WITH CTE (PlantTargetProd) AS
	(
	SELECT SUM(DISTINCT SPD.[PlantTargetProd]) FROM @CorrectionFactor SPD GROUP BY ShiftId
	)
	SELECT @PlantTargetProduction = SUM(PlantTargetProd) FROM CTE;

	WITH CTE (MachineId,PlantEfficiency)
	AS
	(
	SELECT 
		MachineId,
		CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
			NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
			COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2))   
		 FROM @CorrectionFactor SPD GROUP BY MachineId
	)
    SELECT @CorrectionVariable = @PlantTargetProduction/NULLIF(SUM(PlantEfficiency),0) FROM CTE


	--  SELECT  @ShiftRuntime = SUM(A.ShiftTime)
	--   FROM
	--   (
	--  SELECT  SUM( DISTINCT DATEDIFF(Second,psd.StartDateTime,PSd.EndDateTime)) AS ShiftTime FROM TCD.ShiftProductionDataRollup spdr 
	--      INNER JOIN TCD.ProductionShiftData psd ON psd.ShiftId = spdr.ShiftId
	--   WHERE 
	-- CASE @StartDate                                                                                
	-- WHEN '' THEN Case WHEN MONTH(CAST(psd.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
	-- ELSE CASE WHEN psd.[StartDateTime] >= @startdate AND psd.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
	-- END='TRUE'
	-- AND psd.ShiftName <> 'No Shift'
	--  GROUP BY spdr.ShiftId
	--   ) A

	-- SELECT
	--@NoShiftTotalRuntime = SUM(SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0))
	--   FROM TCD.ShiftProductionDataRollup SPD INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId
	--  WHERE 
	--     CASE @StartDate                                                                                
	--     WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
	--     ELSE CASE WHEN PS.[StartDateTime] >= @startdate AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
	--     END='TRUE'
	-- AND PS.ShiftName = 'No Shift'

	--  SELECT @TotaRuntime = ISNULL(@ShiftRuntime,0) + ISNULL(@NoShiftTotalRuntime,0)

	DECLARE @ProductionSummaryTable TABLE
	(
		[ShiftId] [int] NULL,
		[ShiftName] Varchar(100) NULL,
		RecordDate date, 
		[MachineId] [int] NULL,
		[ProgramMasterId] [int] NULL,
		[EcolabWasherId] [int] NULL,
		[ActualProduction] [int] NULL,
		[StandardProduction] [int] NULL,
		[NoOfLoads] [int] NULL,
		[LoadEfficiency] [decimal](18, 2) NULL,
		[TimeEfficiency] [decimal](18, 2) NULL,
		TotalEfficiency [decimal](18, 2) NULL,
		[PlantTargetProd] [int] NULL,
		[ActualRunTime] [int] NULL,
		[TargetRunTime] [int] NULL,
		EcolabTextileId int,
		ChainTextileId int,
		ChainProgaramId int,
		CustomerId int,
		NoOfPieces int,
		Rewash Int,
		[ShiftRunTime] [int] NULL,
		FormulaSegmentID INT,
		RowNumberID INT
	)

    INSERT INTO @ProductionSummaryTable
    SELECT 
        PS.[ShiftId],
        PS.ShiftName,
        CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date),
        --CAST(PS.[StartDateTime] AS date),
        SPD.[MachineId],
        SPD.[ProgramMasterId],
        SPD.[EcolabWasherId],
        ISNULL(SPD.[ActualProduction],0),
        ISNULL(SPD.StandardProduction,0),
        ISNULL(SPD.[NoOfLoads],0),
        ISNULL(SPD.[LoadEfficiency],0),
        ISNULL(SPD.[TimeEfficiency],0),
        (ISNULL(SPD.[LoadEfficiency],0) * ISNULL(SPD.TimeEfficiency,0)),
        ISNULL(SPD.[PlantTargetProd],0),
        ISNULL(SPD.[ActualRunTime],0) + ISNULL(SPD.ActualTurnTime,0),
        ISNULL(SPD.[TargetRunTime],0) + ISNULL(SPD.TargetTurnTime,0),
        SPD.EcolabTextileId,
		SPD.ChainTextileId,
        SPD.ChainProgaramId,
        SPD.CustomerId,
        ISNULL(SPD.NoOfPieces,0),
        CAST((
			SELECT spdr.ActualProduction FROM TCD.ShiftProductionDataRollup spdr WHERE spdr.ShiftId = SPD.ShiftId AND spdr.MachineId = SPD.MachineId
			AND spdr.ProgramMasterId = SPD.ProgramMasterId AND spdr.ProgramMasterId IN (SELECT pm.ProgramId FROM TCD.ProgramMaster pm WHERE pm.Rewash = 1)
			) AS decimal(18,2)),
		DATEDIFF(Second,ps.StartDateTime,PS.EndDateTime) +
			ISNULL(
					(
					SELECT
					SUM(SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0))
					FROM TCD.ShiftProductionDataRollup SPD INNER JOIN TCD.ProductionShiftData PSD ON SPD.ShiftId = PSD.ShiftId
					WHERE PSD.[StartDateTime] = PS.StartDateTime AND PSD.[StartDateTime] = PS.EndDateTime AND PS.ShiftName = 'No Shift'
					) ,0),
		CASE WHEN SPD.ChainProgaramId IS NOT NULL THEN ChainPlant.FormulaSegmentId
		ELSE FS1.FormulaSegmentID END AS Formulasegment,

		ROW_NUMBER() OVER(Partition BY SPD.ProgramMasterId, SPD.[EcolabWasherId], CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date)
		 ORDER BY SPD.ProgramMasterId, SPD.[EcolabWasherId] )

        --CAST(((SELECT SUM(MR.VALUE) FROM TCD.ManualRewash MR WHERE SPD.ProgramMasterId = MR.FormulaId AND CAST(PS.StartDateTime AS date) = CAST(MR.RecordedDate AS date) GROUP BY CAST(MR.RecordedDate AS date),MR.FormulaId)) AS decimal(18,2))
	FROM  TCD.ShiftProductionDataRollup SPD 
	INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId
	INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId 
	INNER JOIN TCD.MachineSetup ms ON SPD.MachineId = ms.WasherId
	LEFT OUTER JOIN
		 (
			--IF Chain Plant
			SELECT PCP.PlantProgramId,PCP.PlantChainId,PCP.ChainTextileCategoryId,PCP.EcolabTextileCategoryId,
			PCP.FormulaSegmentId,PCP.EcolabSaturationId
			FROM TCD.PlantChainProgram PCP 
			LEFT OUTER JOIN TCD.ChainTextileCategory CTC ON CTC.TextileId=PCP.ChainTextileCategoryId
			LEFT OUTER JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId=PCP.EcolabTextileCategoryId
			LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=PCP.FormulaSegmentId
			LEFT OUTER JOIN TCD.EcolabSaturation ES ON ES.EcolabSaturationId=PCP.EcolabSaturationId
		 )ChainPlant ON SPD.ChainProgaramId=ChainPlant.PlantProgramId

	LEFT OUTER JOIN TCD.EcolabTextileCategory ETC1 ON ETC1.TextileId=PM.EcolabTextileCategoryId
	LEFT OUTER JOIN TCD.FormulaSegments FS1 ON FS1.FormulaSegmentID=PM.FormulaSegmentId
	LEFT OUTER JOIN TCD.EcolabSaturation ES1 ON ES1.EcolabSaturationId=PM.EcolabSaturationId
	
    WHERE isNull(ms.IsPony,0) = 0
    AND 
       CASE @StartDate                                                                                
       WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
       ELSE CASE WHEN PS.[StartDateTime] >= @startdate  AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
       END='TRUE'

     AND
       CASE @MachineType   
       WHEN '' THEN 'TRUE'         
       ELSE                                                      
       CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
       MS.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable))) THEN 'TRUE' END                                                      
       END='TRUE' 
    
    AND       

    CASE @machineGroup   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
    MS.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable)) THEN 'TRUE' END                                                      
    END='TRUE' 
    AND

    CASE @Machine   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
    END='TRUE' 
    AND
    
    CASE @EcolabCategory   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.EcolabTextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                      
    END='TRUE' 
     AND
    
    CASE @ChainCategory   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.ChainTextileId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END                                                      
    END='TRUE'
    AND

    CASE @PlantFormula   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                      
    END='TRUE'  
    AND
    
    CASE @ChainFormula   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.ProgramMasterId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END                                                      
    END='TRUE'
    AND
    
    CASE @Customer   
    WHEN '' THEN 'TRUE'         
       ELSE                                                      
       CASE WHEN SPD.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                      
    END='TRUE'
	--Added by Kiran	
    AND 
		CASE @FormulaSegement                                                                                
		WHEN '' THEN  'TRUE'
		ELSE
			CASE WHEN SPD.ChainProgaramId  IS NOT NULL THEN
				CASE WHEN ChainPlant.FormulaSegmentId IN (SELECT FormulaSegment FROM @FormulaSegmentTable) THEN 'TRUE' END						                                                                               
			ELSE 
				CASE WHEN FS1.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)  THEN 'TRUE'END   
			END                                                     
		END='TRUE'
	 -----ENd

	 /*
	SELECT S.ActualProduction AS Actual,MIP.ManualIPActualWeight AS Manual, 
	ISNULL(S.ActualProduction,0)+ISNULL(MIP.ManualIPActualWeight,0),
	S.NoOfLoads AS Actualloads,MIP.NoofLoads AS Manualloads,
	ISNULL(S.NoOfLoads,0)+ISNULL(MIP.NoofLoads,0)
	FROM  @ProductionSummaryTable S
	INNER JOIN 
		(
		SELECT WasherId,FormulaId,CONVERT(DATE,RecordedDate) AS LoadDate,SUM(Value) AS ManualIPActualWeight,
		COUNT(CONVERT(DATE,RecordedDate)) AS NoofLoads FROM
		TCD.ManualProduction MP
		GROUP BY WasherId,FormulaId,CONVERT(DATE,RecordedDate)
		)MIP ON MIP.WasherId=S.EcolabWasherId AND MIP.FormulaId=S.ProgramMasterId AND MIP.LoadDate=S.RecordDate
		WHERE S.RowNumberID=1
	*/

	--For top 1 record combination updating the manual input data.
	UPDATE S SET ActualProduction=ISNULL(S.ActualProduction,0)+ISNULL(MIP.ManualIPActualWeight,0),S.NoOfLoads=ISNULL(S.NoOfLoads,0)+ISNULL(MIP.NoofLoads,0)
	FROM  @ProductionSummaryTable S
	INNER JOIN 
		(
		SELECT WasherId,FormulaId,CONVERT(DATE,RecordedDate) AS LoadDate,SUM(Value) AS ManualIPActualWeight,
		COUNT(CONVERT(DATE,RecordedDate)) AS NoofLoads FROM
		TCD.ManualProduction MP
		GROUP BY WasherId,FormulaId,CONVERT(DATE,RecordedDate)
		)MIP ON MIP.WasherId=S.MachineId AND MIP.FormulaId=S.ProgramMasterId AND MIP.LoadDate=S.RecordDate
		WHERE S.RowNumberID=1

	--SELECT * FROM @ProductionSummaryTable


	IF(@Viewtype = 3)
	BEGIN
		IF(@Subview = 12)
		BEGIN
			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,TextileId)
				AS
				(
			  SELECT 
				EC.CategoryName,
				SUM(SPD.ActualProduction),
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
				SUM(DISTINCT SPD.PlantTargetProd),
				SUM(SPD.StandardProduction),
				SUM([NoOfLoads]),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(SPD.NoOfPieces),
				SUM(SPD.Rewash),
				EC.TextileId
				  FROM @ProductionSummaryTable SPD LEFT JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
				WHERE EC.CategoryName IS NOT NULL
				GROUP BY 
			   EC.CategoryName,EC.TextileId,SPD.ShiftId
			   )
			   INSERT INTO @resultSet
			   SELECT DISTINCT
				0,
				DateRange,
				SUM(TotalLoad),
				SUM(WasherEfficiency),
				SUM(PlantTargetLoad),
				SUM(StandardLoad),
				SUM(Numberofbatches),
				SUM(ActualRunTime),
				SUM(TargetRuntime),
				SUM(NumberofPieces),
				SUM(Rewash)
				,@Viewtype 
				,@Subview
				,TextileId
				FROM CTE
				WHERE TotalLoad IS NOT NULL
				GROUP BY DateRange,TextileId   
	    END
		IF(@Subview = 17)
		BEGIN
			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
			AS
			(
			SELECT 
   
			PM.Name,
			SUM(SPD.ActualProduction),
			COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
			SUM(DISTINCT SPD.PlantTargetProd),
			SUM(SPD.StandardProduction),
			SUM([NoOfLoads]),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(SPD.NoOfPieces),
			SUM(SPD.Rewash)
			   FROM @ProductionSummaryTable SPD INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
				 INNER JOIN TCD.ProgramMaster PM ON EC.TextileId = PM.EcolabTextileCategoryId AND SPD.ProgramMasterId = PM.ProgramId    
			WHERE
				(
				CASE    
				 WHEN @drillvalue='' THEN 'TRUE' 
				 WHEN @drillvalue IS NULL THEN 'TRUE'  
				 ELSE                                                    
				  CASE WHEN EC.TextileId IN (@drillvalue) THEN 'TRUE' END            
				 END='TRUE'
				) AND PM.NAME IS NOT NULL
			GROUP BY 
			   PM.Name,SPD.ShiftId
		   )
			INSERT INTO @resultSet
		   SELECT DISTINCT
			0,
			   DateRange,
			   SUM(TotalLoad),
			   SUM(WasherEfficiency),
			   SUM(PlantTargetLoad),
			   SUM(StandardLoad),
			   SUM(Numberofbatches),
			   SUM(ActualRunTime),
			   SUM(TargetRuntime),
			   SUM(NumberofPieces),
			   SUM(Rewash)
			   ,@Viewtype 
			   ,@Subview
				,0
				   FROM CTE
					WHERE TotalLoad IS NOT NULL
					GROUP BY DateRange
		END

	END

    -- ************************ By Textile Category View ************************************************
	IF(@Viewtype = 4)
	BEGIN 
		IF(@Subview = 15)
		BEGIN
			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
				AS
				(
			 SELECT    
				CC.Name,
				SUM(SPD.ActualProduction),
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
				SUM(DISTINCT SPD.PlantTargetProd),
				SUM(SPD.StandardProduction),
				SUM([NoOfLoads]),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(SPD.NoOfPieces),
				SUM(SPD.Rewash)
				FROM @ProductionSummaryTable SPD LEFT JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
				WHERE CC.Name IS NOT NULL 
			 GROUP BY 
			   CC.Name,CC.TextileId,SPD.ShiftId
			   )
				INSERT INTO @resultSet
			   SELECT DISTINCT
				0,
				   DateRange,
				   SUM(TotalLoad),
				   SUM(WasherEfficiency),
				   SUM(PlantTargetLoad),
				   SUM(StandardLoad),
				   SUM(Numberofbatches),
				   SUM(ActualRunTime),
				   SUM(TargetRuntime),
				   SUM(NumberofPieces),
				   SUM(Rewash)
				   ,@Viewtype 
				   ,@Subview
					,0
					FROM CTE
					WHERE TotalLoad IS NOT NULL
					GROUP BY DateRange
        END  
		IF(@Subview = 18)
		BEGIN
			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
				AS
				(
			 SELECT        
				PM.Name,
				SUM(SPD.ActualProduction),
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
				SUM(DISTINCT SPD.PlantTargetProd),
				SUM(SPD.StandardProduction),
				SUM([NoOfLoads]),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(SPD.NoOfPieces),
				SUM(SPD.Rewash)
				   FROM @ProductionSummaryTable SPD INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
					 INNER JOIN TCD.ProgramMaster PM ON CC.TextileId = PM.ChainTextileId AND SPD.ProgramMasterId = PM.ProgramId
    
			WHERE
				(
				CASE    
				 WHEN @drillvalue='' THEN 'TRUE' 
				 WHEN @drillvalue IS NULL THEN 'TRUE'  
				 ELSE                                                    
				  CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END            
				 END='TRUE'
				)
			GROUP BY 
			   PM.Name,SPD.ShiftId
			   )
				INSERT INTO @resultSet
			   SELECT DISTINCT
				0,
				   DateRange,
				   SUM(TotalLoad),
				   SUM(WasherEfficiency),
				   SUM(PlantTargetLoad),
				   SUM(StandardLoad),
				   SUM(Numberofbatches),
				   SUM(ActualRunTime),
				   SUM(TargetRuntime),
				   SUM(NumberofPieces),
				   SUM(Rewash)
				   ,@Viewtype 
				   ,@Subview
					,0
					   FROM CTE
						WHERE TotalLoad IS NOT NULL
						GROUP BY DateRange
		END
	END

  -- ******************************** Timeline View ***************************************************
	IF(@Viewtype = 1)
	BEGIN
		---- By TimeLine - Day View
	   IF(@Subview = 5)
		BEGIN 
			INSERT INTO @resultSet
			SELECT DISTINCT
			0,
			SPD.ShiftName,
			SUM(SPD.ActualProduction),
			COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
			SUM(DISTINCT SPD.PlantTargetProd),
			SUM(SPD.StandardProduction),
			SUM([NoOfLoads]),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(SPD.NoOfPieces),
			SUM(SPD.Rewash)
			,@Viewtype 
			,@Subview
			,0
			 FROM @ProductionSummaryTable SPD
			GROUP BY 
			SPD.ShiftName
		END

       ---- By TimeLine - Week View
	   IF (@Subview = 4)
	   BEGIN
			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
			AS
			(
			SELECT 
			   CAST(RecordDate AS nvarchar(100)),
				SUM(SPD.ActualProduction),
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
				SUM(DISTINCT SPD.PlantTargetProd),
				SUM(SPD.StandardProduction),
				SUM([NoOfLoads]),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(SPD.NoOfPieces),
				SUM(SPD.Rewash)
			  FROM @ProductionSummaryTable SPD
				GROUP BY DATEPART(weekday,RecordDate),RecordDate,SPD.ShiftId

			)
		   INSERT INTO @resultSet
		   SELECT DISTINCT
			   0,
			   DateRange,
			  SUM(TotalLoad),
			  SUM(WasherEfficiency),
			   SUM(PlantTargetLoad),
			   SUM(StandardLoad),
			   SUM(Numberofbatches),
			   SUM(ActualRunTime),
			   SUM(TargetRuntime),
			   SUM(NumberofPieces),
			   SUM(Rewash)
			   ,@Viewtype 
			   ,@Subview
				,0
				   FROM CTE
					WHERE TotalLoad IS NOT NULL
					GROUP BY DateRange
	   END
		---- By TimeLine - Month View
	   IF(@Subview = 3)
	   BEGIN
			DECLARE @FirstDay date = (SELECT TOP 1 RecordDate FROM @ProductionSummaryTable ORDER BY RecordDate)
			DECLARE @LastDay date = (SELECT TOP 1 RecordDate FROM @ProductionSummaryTable ORDER BY RecordDate DESC)
			DECLARE @FirstSunday date = NULL,
			@LastSaturday date = NULL

    
			SELECT 
			@FirstSunday = CAST(DateAdd(dd, (8-DatePart(WEEKDAY, 
			DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)))%7, 
			DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)) AS DATE) 

			SELECT
			@LastSaturday = 
			DATEADD(dd,
				-DATEPART(WEEKDAY,
					DATEADD(dd, -DAY(DATEADD(month, 1, @LastDay)),
					DATEADD(month, 1, @LastDay))) ,
				DATEADD(dd, -DAY(DATEADD(MONTH, 1, @LastDay)), DATEADD(MONTH, 1, @LastDay)));

			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
			AS
			(
			SELECT 
       
			CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,-1,@FirstSunday)) = 7 
			AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate < DATEADD(DD,-1,@FirstSunday)) = 0)
			THEN CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100))
			WHEN DATEADD(DD,-1,@FirstSunday) > CAST(GETDATE() AS DATE) 
			THEN
			CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @enddate, 101) AS nvarchar(100))
			ELSE
			CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) END As DateRange,
			SUM(SPD.ActualProduction),
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
				SUM(DISTINCT SPD.PlantTargetProd),
				SUM(SPD.StandardProduction),
				SUM([NoOfLoads]),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(SPD.NoOfPieces),
				SUM(SPD.Rewash)

				FROM @ProductionSummaryTable SPD
			WHERE RecordDate < @FirstSunday AND RecordDate >= @FirstDay
			GROUP BY SPD.ShiftId

        
			UNION ALL

  
			SELECT
        
			--CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100)) AS StartDate,
			--CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) AS EndDate,
				CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100))  + CHAR(13) + '-' +
				CASE WHEN CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) >
				CAST(Convert(varchar, DateAdd(dd, (1 - DatePart(dw, @enddate) + 1), @enddate), 101) AS nvarchar(100))
				THEN  CAST(Convert(varchar, DateAdd(dd, 1-1, @enddate), 101) AS nvarchar(100))
				ELSE CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) END
				As DateRange,
				SUM(SPD.ActualProduction),
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
				SUM(DISTINCT SPD.PlantTargetProd),
				SUM(SPD.StandardProduction),
				SUM([NoOfLoads]),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(SPD.NoOfPieces),
				SUM(SPD.Rewash)
			FROM @ProductionSummaryTable SPD
				WHERE RecordDate BETWEEN @FirstSunday AND @LastSaturday
			GROUP BY Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101),
				Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101),SPD.ShiftId
       
			UNION ALL

			SELECT 
				CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,1,@LastSaturday)) = 1 
			AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate > DATEADD(DD,1,@LastSaturday)) = 0)
			THEN 
			CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) 
			ELSE
			CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @LastDay, 101) AS nvarchar(100)) END   As DateRange,
			SUM(SPD.ActualProduction),
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
				SUM(DISTINCT SPD.PlantTargetProd),
				SUM(SPD.StandardProduction),
				SUM([NoOfLoads]),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(SPD.NoOfPieces),
				SUM(SPD.Rewash)
			FROM @ProductionSummaryTable SPD
			WHERE RecordDate > @LastSaturday AND RecordDate <= @LastDay 
			GROUP BY SPD.ShiftId
			)
			INSERT INTO @resultSet
			SELECT DISTINCT
			0,
			DateRange,
			SUM(TotalLoad),
			SUM(WasherEfficiency),
			SUM(PlantTargetLoad),
			SUM(StandardLoad),
			SUM(Numberofbatches),
			SUM(ActualRunTime),
			SUM(TargetRuntime),
			SUM(NumberofPieces),
			SUM(Rewash)
			,@Viewtype 
			,@Subview
				,0
				FROM CTE
				WHERE TotalLoad IS NOT NULL
				GROUP BY DateRange

	   END

       IF(@Subview = 2)
	   BEGIN
			DECLARE @QuarterYear VARCHAR(100) = YEAR(@enddate);
			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
			AS
			(
			  SELECT 
				DATENAME(MONTH, RecordDate) + ' ' + @QuarterYear As DateRange,
				SUM(SPD.ActualProduction),
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
				SUM(DISTINCT SPD.PlantTargetProd),
				SUM(SPD.StandardProduction),
				SUM([NoOfLoads]),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(SPD.NoOfPieces),
				SUM(SPD.Rewash)
				FROM @ProductionSummaryTable SPD
				GROUP BY  DATEPART(MONTH, RecordDate),DATENAME(MONTH, RecordDate),SPD.ShiftId
			)
			INSERT INTO @resultSet
			 SELECT DISTINCT
				0,
				DateRange,
			   SUM(TotalLoad),
			   SUM(WasherEfficiency),
				SUM(PlantTargetLoad),
				SUM(StandardLoad),
				SUM(Numberofbatches),
				SUM(ActualRunTime),
				SUM(TargetRuntime),
				SUM(NumberofPieces),
				SUM(Rewash)
				,@Viewtype 
				,@Subview
				 ,0
					FROM CTE
					WHERE TotalLoad IS NOT NULL
					GROUP BY DateRange
	   END   

      IF(@Subview = 1)
      BEGIN
		 DECLARE @Year VARCHAR(100) = RIGHT(YEAR(@enddate),2);
		 WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
			AS
			(
				SELECT 
				CASE 'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10))
				   WHEN 'Q1' THEN 'Jan' + @Year + '- Mar' + @Year
				   WHEN 'Q2' THEN 'Apr' + @Year + '- Jun' + @Year
				   WHEN 'Q3' THEN 'Jul' + @Year + '-Sep' + @Year
				   WHEN 'Q4' THEN 'Oct' + @Year + '- Dec'+ @Year
				END AS DateRange,
				SUM(SPD.ActualProduction),
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
				SUM(DISTINCT SPD.PlantTargetProd),
				SUM(SPD.StandardProduction),
				SUM([NoOfLoads]),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(SPD.NoOfPieces),
				SUM(SPD.Rewash)
				 FROM @ProductionSummaryTable SPD
				 GROUP BY DATEPART(QUARTER, RecordDate),SPD.ShiftId

			)

			INSERT INTO @resultSet
			SELECT DISTINCT
				0,
				DateRange,
			   SUM(TotalLoad),
			   SUM(WasherEfficiency),
				SUM(PlantTargetLoad),
				SUM(StandardLoad),
				SUM(Numberofbatches),
				SUM(ActualRunTime),
				SUM(TargetRuntime),
				SUM(NumberofPieces),
				SUM(Rewash)
				,@Viewtype 
				,@Subview
				 ,0
					FROM CTE
					WHERE TotalLoad IS NOT NULL
					GROUP BY DateRange

	  END
    END

    -- ******************************** Location View ***************************************************
    IF(@Viewtype = 2)
    BEGIN

		IF(@Subview = 9)
        BEGIN
			 WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,WasherGroupId)
			AS
			(
			 SELECT 
				--SPD.MachineId,
				WG.WasherGroupName,
				SUM(SPD.ActualProduction),
				CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
				NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
				COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
				SUM(DISTINCT SPD.PlantTargetProd),
				SUM(SPD.StandardProduction),
				SUM([NoOfLoads]),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(SPD.NoOfPieces),
				SUM(SPD.Rewash),
				WG.WasherGroupId
			  FROM @ProductionSummaryTable SPD LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId
					 LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId 
				GROUP BY WG.WasherGroupName,WG.WasherGroupId,SPD.ShiftId--,SPD.MachineId

			)

			 INSERT INTO @resultSet
			 SELECT DISTINCT
						0,
						DateRange,
						SUM(TotalLoad),
						SUM(WasherEfficiency),
			@PlantTargetProduction,
						SUM(StandardLoad),
						SUM(Numberofbatches),
						SUM(ActualRunTime),
						SUM(TargetRuntime),
						SUM(NumberofPieces),
						SUM(Rewash)
						,@Viewtype 
						,@Subview
						,WasherGroupId
				FROM CTE
					WHERE TotalLoad IS NOT NULL
					GROUP BY DateRange,WasherGroupId
        END

       IF(@Subview = 10)
       BEGIN
			 WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
			AS
			(
			SELECT         
				cast( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName MachineName,
				SUM(SPD.ActualProduction),
				CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
				NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
				COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)) ,
				SUM(DISTINCT SPD.PlantTargetProd),
				SUM(SPD.StandardProduction),
				SUM([NoOfLoads]),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(SPD.NoOfPieces),
				SUM(SPD.Rewash)
        
			 FROM @ProductionSummaryTable SPD 
		  LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId
		  LEFT JOIN TCD.Washer w on MS.WasherId=w.WasherId
			 LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId 
			WHERE 
			  (
			   CASE @drillvalue   
				   WHEN '' THEN 'TRUE'         
				   ELSE                                                    
					CASE WHEN WG.WasherGroupId IN (@drillvalue) THEN 'TRUE' END            
				   END='TRUE'
			  )
			 GROUP BY cast( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName,SPD.ShiftId

			)

			 INSERT INTO @resultSet
			  SELECT DISTINCT
						0,
						DateRange,
						SUM(TotalLoad),
						SUM(WasherEfficiency),
						@PlantTargetProduction,
						SUM(StandardLoad),
						SUM(Numberofbatches),
						SUM(ActualRunTime),
						SUM(TargetRuntime),
						SUM(NumberofPieces),
						SUM(Rewash)
						,@Viewtype 
						,@Subview
						,0
				FROM CTE
					WHERE TotalLoad IS NOT NULL
					GROUP BY DateRange
       END
    END

    -- ******************************** ChainCategory View **********************************************
    IF(@Viewtype = 5)
    BEGIN
		IF(@Subview = 16)
		BEGIN
		   -- ToDo : Change this part for chaincategory
			  WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,textileId)
			AS
			(
			 SELECT    
			CC.NAME,
			SUM(SPD.ActualProduction),
			COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
			SUM(DISTINCT SPD.PlantTargetProd),
			SUM(SPD.StandardProduction),
			SUM([NoOfLoads]),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(SPD.NoOfPieces),
			SUM(SPD.Rewash),
		 cc.TextileId
			   FROM
			 @ProductionSummaryTable SPD
			INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
			 INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = PM.PlantProgramId
			 INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId 
			Group by 
		   CC.Name,cc.TextileId,SPD.ShiftId
		   )
			INSERT INTO @resultSet
			  SELECT DISTINCT
						0,
						DateRange,
						SUM(TotalLoad),
						SUM(WasherEfficiency),
						@PlantTargetProduction,
						SUM(StandardLoad),
						SUM(Numberofbatches),
						SUM(ActualRunTime),
						SUM(TargetRuntime),
						SUM(NumberofPieces),
						SUM(Rewash)
						,@Viewtype 
						,@Subview
						,textileId
				FROM CTE
					WHERE TotalLoad IS NOT NULL
					GROUP BY DateRange,textileId
		END
    
		IF(@Subview = 19)
		BEGIN
		 -- ToDo : Change this part for chaincategory
			 WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
			AS
			(
			 SELECT  
			PCP.PlantProgramName,
			SUM(SPD.ActualProduction),
			COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
			SUM(DISTINCT SPD.PlantTargetProd),
			SUM(SPD.StandardProduction),
			SUM([NoOfLoads]),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(SPD.NoOfPieces),
			SUM(SPD.Rewash)
			  FROM @ProductionSummaryTable SPD
			INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
			 INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = PM.PlantProgramId
			 INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId 
			 WHERE
			(
		   CASE @drillvalue   
			   WHEN '' THEN 'TRUE'         
			   ELSE                                                    
			   CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END            
			   END='TRUE'
		  )
		 Group by 
		   PCP.PlantProgramName,PCP.PlantProgramId,SPD.ShiftId
		   )
		   INSERT INTO @resultSet
			  SELECT DISTINCT
						0,
						DateRange,
						SUM(TotalLoad),
						SUM(WasherEfficiency),
						@PlantTargetProduction,
						SUM(StandardLoad),
						SUM(Numberofbatches),
						SUM(ActualRunTime),
						SUM(TargetRuntime),
						SUM(NumberofPieces),
						SUM(Rewash)
						,@Viewtype 
						,@Subview
						,0
				FROM CTE
					WHERE TotalLoad IS NOT NULL
					GROUP BY DateRange
		END

	END

    -- ******************************** Customer View ***************************************************
	IF(@Viewtype = 6)
	BEGIN
		 WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
			AS
			(
			SELECT 
			PC.CustomerName,
			SUM(SPD.ActualProduction),
			COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
			SUM(DISTINCT SPD.PlantTargetProd),
			SUM(SPD.StandardProduction),
			SUM([NoOfLoads]),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(SPD.NoOfPieces),
			SUM(SPD.Rewash)
			FROM @ProductionSummaryTable SPD  INNER JOIN TCD.PlantCustomer PC on PC.CustomerId = SPD.CustomerId
			GROUP BY 
		   PC.CustomerName,SPD.ShiftId
		   )
		   INSERT INTO @resultSet
			  SELECT DISTINCT
						0,
						DateRange,
						SUM(TotalLoad),
						SUM(WasherEfficiency),
						@PlantTargetProduction,
						SUM(StandardLoad),
						SUM(Numberofbatches),
						SUM(ActualRunTime),
						SUM(TargetRuntime),
						SUM(NumberofPieces),
						SUM(Rewash)
						,@Viewtype 
						,@Subview
						,0
				FROM CTE
					WHERE TotalLoad IS NOT NULL
					GROUP BY DateRange
	END

-- ******************************** Formula View ****************************************************
	IF(@Viewtype = 7)
	BEGIN
		 WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
			AS
			(
		 SELECT 
			PM.Name,
			SUM(SPD.ActualProduction),
		   COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
			SUM(DISTINCT SPD.PlantTargetProd),
			SUM(SPD.StandardProduction),
			SUM([NoOfLoads]),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(SPD.NoOfPieces),
			SUM(SPD.Rewash)
			FROM @ProductionSummaryTable SPD 
			INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
			Group by 
			PM.Name,SPD.ShiftId
			)
			INSERT INTO @resultSet
			  SELECT DISTINCT
						0,
						DateRange,
						SUM(TotalLoad),
						SUM(WasherEfficiency),
						@PlantTargetProduction,
						SUM(StandardLoad),
						SUM(Numberofbatches),
						SUM(ActualRunTime),
						SUM(TargetRuntime),
						SUM(NumberofPieces),
						SUM(Rewash)
						,@Viewtype 
						,@Subview
						,0
				FROM CTE
					WHERE TotalLoad IS NOT NULL
					GROUP BY DateRange
    END

-- ******************************** Formula segmentView ****************************************************
	IF(@Viewtype = 8)
	BEGIN
		IF(@Subview =20)-- Formula Segment
		BEGIN
			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,FormulaSegmentID)
			AS
			(
			SELECT 
			FS.SegmentName,
			SUM(SPD.ActualProduction),
			COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
			SUM(DISTINCT SPD.PlantTargetProd),
			SUM(SPD.StandardProduction),
			SUM([NoOfLoads]),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(SPD.NoOfPieces),
			SUM(SPD.Rewash),
			SPD.FormulaSegmentID
			FROM @ProductionSummaryTable SPD 
			INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
			LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=SPD.FormulaSegmentID
			Group by SPD.FormulaSegmentID,FS.SegmentName	
			)
			INSERT INTO @resultSet
			(
			  ShiftId,
			  DateRange ,
			  TotalLoad  ,
			  WasherEfficiency ,
			  PlantTargetLoad  ,
			  StandardLoad ,
			  Numberofbatches ,
			  [ActualRunTime], 
			  [TargetRunTime],
			  NumberofPieces  ,
			  Rewash ,
			  Viewtype ,
			  Subview ,
			  Id
			)
				SELECT DISTINCT
						0,
						DateRange,
						SUM(TotalLoad),
						SUM(WasherEfficiency),
						@PlantTargetProduction,
						SUM(StandardLoad),
						SUM(Numberofbatches),
						SUM(ActualRunTime),
						SUM(TargetRuntime),
						SUM(NumberofPieces),
						SUM(Rewash)
						,@Viewtype 
						,@Subview
						,0
				FROM CTE
					WHERE TotalLoad IS NOT NULL
					GROUP BY DateRange
		END
		IF(@Subview =21)-- Formula Categories
		BEGIN		
			 WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,TextileId)
			 AS
				(
				SELECT EC.CategoryName,	SUM(SPD.ActualProduction),COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
				SUM(DISTINCT SPD.PlantTargetProd),SUM(SPD.StandardProduction),SUM([NoOfLoads]),SUM(DISTINCT SPD.ShiftRunTime),SUM(DISTINCT SPD.ShiftRunTime),
				SUM(SPD.NoOfPieces),SUM(SPD.Rewash),EC.TextileId
				FROM @ProductionSummaryTable SPD 
				LEFT JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
				WHERE EC.CategoryName IS NOT NULL
				GROUP BY EC.CategoryName,EC.TextileId,SPD.ShiftId

				UNION

				SELECT CC.NAME,SUM(SPD.ActualProduction),COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
				SUM(DISTINCT SPD.PlantTargetProd),SUM(SPD.StandardProduction),SUM([NoOfLoads]),SUM(DISTINCT SPD.ShiftRunTime),SUM(DISTINCT SPD.ShiftRunTime),
				SUM(SPD.NoOfPieces),SUM(SPD.Rewash),cc.TextileId
				FROM @ProductionSummaryTable SPD
				INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
				INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = SPD.ChainProgaramId
				INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId 
				Group by CC.Name,cc.TextileId,SPD.ShiftId
				)
				INSERT INTO @resultSet
				(
				  ShiftId,
				  DateRange ,
				  TotalLoad  ,
				  WasherEfficiency ,
				  PlantTargetLoad  ,
				  StandardLoad ,
				  Numberofbatches ,
				  [ActualRunTime], 
				  [TargetRunTime],
				  NumberofPieces  ,
				  Rewash ,
				  Viewtype ,
				  Subview ,
				  Id
				)
				SELECT DISTINCT
				0,
				DateRange,
				SUM(TotalLoad),
				SUM(WasherEfficiency),
				SUM(PlantTargetLoad),
				SUM(StandardLoad),
				SUM(Numberofbatches),
				SUM(ActualRunTime),
				SUM(TargetRuntime),
				SUM(NumberofPieces),
				SUM(Rewash)
				,@Viewtype 
				,@Subview
				,TextileId
				FROM CTE
				WHERE TotalLoad IS NOT NULL
				GROUP BY DateRange,TextileId
		END
		IF(@Subview=22) --Formula
		BEGIN
			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
			AS
			(
				SELECT PM.Name,SUM(SPD.ActualProduction),COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
				SUM(DISTINCT SPD.PlantTargetProd),SUM(SPD.StandardProduction),SUM([NoOfLoads]),SUM(DISTINCT SPD.ShiftRunTime),SUM(DISTINCT SPD.ShiftRunTime),
				SUM(SPD.NoOfPieces),SUM(SPD.Rewash)
				FROM @ProductionSummaryTable SPD 
				INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
				INNER JOIN TCD.ProgramMaster PM ON EC.TextileId = PM.EcolabTextileCategoryId AND SPD.ProgramMasterId = PM.ProgramId    
				WHERE
					(
					CASE    
						WHEN @drillvalue='' THEN 'TRUE' 
						WHEN @drillvalue IS NULL THEN 'TRUE'  
						ELSE                                                    
						CASE WHEN EC.TextileId IN (@drillvalue) THEN 'TRUE' END            
						END='TRUE'
					) AND PM.NAME IS NOT NULL
				GROUP BY PM.Name,SPD.ShiftId

				UNION 

				SELECT PM.Name,SUM(SPD.ActualProduction),COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
				SUM(DISTINCT SPD.PlantTargetProd),SUM(SPD.StandardProduction),SUM([NoOfLoads]),SUM(DISTINCT SPD.ShiftRunTime),SUM(DISTINCT SPD.ShiftRunTime),
				SUM(SPD.NoOfPieces),SUM(SPD.Rewash)
				FROM @ProductionSummaryTable SPD 
				INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
				INNER JOIN TCD.ProgramMaster PM ON  SPD.ProgramMasterId = PM.ProgramId		
				WHERE
					(
					 CASE    
					 WHEN @drillvalue='' THEN 'TRUE' 
					 WHEN @drillvalue IS NULL THEN 'TRUE'  
					 ELSE                                                    
					 CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END            
					 END='TRUE'
					)
				GROUP BY PM.Name,SPD.ShiftId			
			)
			INSERT INTO @resultSet(ShiftId,DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,
				  StandardLoad,Numberofbatches,[ActualRunTime],[TargetRunTime],NumberofPieces  ,
				  Rewash,Viewtype,Subview,Id
			)
			SELECT DISTINCT 0,DateRange,SUM(TotalLoad),	SUM(WasherEfficiency),SUM(PlantTargetLoad),
				SUM(StandardLoad),SUM(Numberofbatches),	SUM(ActualRunTime),	SUM(TargetRuntime),	SUM(NumberofPieces),
				SUM(Rewash),@Viewtype ,@Subview,0
			FROM CTE
			WHERE TotalLoad IS NOT NULL
			GROUP BY DateRange
		END
	END
	
--- ********* Return result ********************

    SELECT DISTINCT  ShiftId, DateRange,ISNULL([TCD].[FnConsumptionOnMetrics](TotalLoad,'Weight',@UserId),0),      
      ISNULL([TCD].[FnConsumptionOnMetrics](WasherEfficiency,'Weight',@UserId),0), --ISNULL(WasherEfficiency,0),
      ISNULL([TCD].[FnConsumptionOnMetrics](PlantTargetLoad,'Weight',@UserId),0),--ISNULL(PlantTargetLoad,0),
      ISNULL([TCD].[FnConsumptionOnMetrics](StandardLoad,'Weight',@UserId),0),--ISNULL(StandardLoad,0),
      ISNULL(Numberofbatches,0),ISNULL(ActualRunTime,0),ISNULL(TargetRunTime,0),ISNULL(NumberofPieces,0),
      ISNULL(Rewash,0),Viewtype,Subview ,Id,@CorrectionVariable
      FROM @resultSet 


 
SET NOCOUNT OFF   
END
Go



IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[ReportOperationsSummary]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[ReportOperationsSummary] 
END 
GO 
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ReportOperationsSummary] 
/******************************************************************

DESCRIPTION		: Populating Operation Summary Report  data based on filters and views,sub views.


MODIFICATION HISTORY DETAILS:	
	21st Jan 2015 -  Kiran     -  Added Formula hierarchy -->Formula segment-->Formula category-->formula


REFERENC TABLES :
		Select * from TCD.Plant --Plant master
		Select * FROM TCD.PlantChain  --Master Plants
		Select * FROM TCD.PlantChainProgram
		Select * FROM TCD.ChainTextileCategory
		Select * FROM TCD.ProgramMaster
		Select * FROM TCD.EcolabTextileCategory  --Masters
		Select * FROM TCD.EcolabSaturation --Masters
		Select * FROM TCD.FormulaSegments --Masters

EXECUTION STATEMENT :

	EXEC [TCD].[ReportOperationsSummary1] @startdate = '2015-01-11',@enddate = '2016-01-30',@Viewtype  = '8',@Subview = '22',
										@Drillvalue = '',@EcolabAccountNumber = '040242802',@MachineType = '', @MachineGroup  = '',@Machine  = '', 
										@EcolabCategory  = '',@ChainCategory  = '', @PlantFormula  = '', @ChainFormula = '', @Customer  = '',
										@SortColumnId  = 0,@SortDirection  = '',@CurrencyCode = '', @UserId = 1, @FormulaSegement ='',
										@FormulaCategory='',@Formula=''


*******************************************************************/
     @startdate datetime = '',
     @enddate datetime = '',
     @Viewtype Int = '',
     @Subview Int= '',
     @Drillvalue varchar(100)= '',
     @EcolabAccountNumber Nvarchar(25) = '',
     @MachineType VARCHAR(20)= '',		--Washer Group type
     @MachineGroup VARCHAR(MAX) = '',  --washer Group
     @Machine VARCHAR(MAX) = '',
     @EcolabCategory VARCHAR(MAX) = '', --EcolabcategoritextileID
     @ChainCategory VARCHAR(MAX) = '',  --Chain Texttilecategori ID
     @PlantFormula  VARCHAR(MAX) = '',
     @ChainFormula VARCHAR(MAX) = '',
     @Customer VARCHAR(MAX) = '',
     @SortColumnId int = 0,
     @SortDirection varchar(4) = '',
     @CurrencyCode varchar(3) = '',
     @UserId INT = NULL,
	 @FormulaSegement VARCHAR(MAX)='', --Formula segment,
	 @FormulaCategory VARCHAR(MAX)='', --Formula category
	 @Formula VARCHAR(MAX)='' --Formula
AS   
BEGIN   
SET NOCOUNT ON
	SET @startdate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@startdate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@startdate AS time)) AS DateTime))
    SET @EndDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndDate AS time)) AS DateTime))
	--SELECT @startdate,@enddate

    DECLARE @ReportGenerated INT = 6, @Month INT = MONTH(GETDATE()),@NoOfLoads int
	--SELECT @Month

    --Inserting the record into Report History 
	INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)
	SELECT @EcolabAccountNumber,UM.UserId, UM.LoginName, GETUTCDATE(), @ReportGenerated,
	CASE WHEN @ReportGenerated = 6 THEN 'Generated Report : Operations Summary Report' END
	FROM TCD.UserMaster UM
	WHERE UM.EcolabAccountNumber = @EcolabAccountNumber AND UM.UserId = @UserId
    --Completed the record insertion into Report History */

	-- Return Table set
    DECLARE @resultSet Table
    (
      ShiftId Int,DateRange varchar(100),TotalLoad Decimal(18,2),Numberofbatches INT,ActualChemicalConsumption Decimal(18,2),
      TargetChemicalConsumption Decimal(18,2),ActualEnergyConsumption  Decimal(18,2),TargetEnergyConsumption Decimal(18,2),
      ActualWaterConsumption  Decimal(18,2),TargetWaterConsumption Decimal(18,2),ActualChemicalCost Decimal(18,2),ActualWaterCost Decimal(18,2),
      ActualEnergyCost Decimal(18,2),Viewtype varchar(100) , Subview varchar(100) , Id int        
    )

	--Machine types 
    DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))
    INSERT INTO @MachineTypeTable EXEC [TCD].[CharlistToTable] @MachineType,','

	--Washergroups 
    DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))
    INSERT INTO @WasherGroupTable EXEC [TCD].[CharlistToTable] @machineGroup,','  

	--Machine list
    DECLARE @MachineTable TABLE(Machine Varchar(100))
    INSERT INTO @MachineTable EXEC [TCD].[CharlistToTable] @Machine,','

	--Ecolab category
    DECLARE @EcolabCategoryTable TABLE(EcolabCategory Varchar(100))
    INSERT INTO @EcolabCategoryTable EXEC [TCD].[CharlistToTable] @EcolabCategory,','

	--Chain category
    DECLARE @ChainCategoryTable TABLE(ChainCategory Varchar(100))
    INSERT INTO @ChainCategoryTable EXEC [TCD].[CharlistToTable] @ChainCategory,','

	--Plant fomula
    DECLARE @PlantFormulaTable TABLE(PlantFormula Varchar(100))
    INSERT INTO @PlantFormulaTable EXEC [TCD].[CharlistToTable] @PlantFormula,','

	--chain formula
    DECLARE @ChainFormulaTable TABLE(ChainFormula Varchar(100))
    INSERT INTO @ChainFormulaTable EXEC [TCD].[CharlistToTable] @ChainFormula,','
	
	--customer 
    DECLARE @CustomerTable TABLE(Customer Varchar(100))
    INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','

	--Formula Segment --added by Kiran
	DECLARE @FormulaSegmentTable TABLE(FormulaSegment Varchar(1000))
    INSERT INTO @FormulaSegmentTable EXEC [TCD].[CharlistToTable] @FormulaSegement,','

	-----Formula category--------Start
	DECLARE @FormulaCategoryTable TABLE(FormulaCategory Varchar(1000),Type CHAR(1))
    INSERT INTO @FormulaCategoryTable(FormulaCategory) EXEC [TCD].[CharlistToTable] @Formulacategory,','	
	
	--segregating Ecolab/Chain categories
	--UPDATE @FormulaCategoryTable SET TYPE=RIGHT(FormulaCategory,1),FormulaCategory=LEFT(FormulaCategory,LEN(FormulaCategory)-2)
	
	--Below 1000 Ecolab category
	UPDATE @FormulaCategoryTable SET TYPE='E' WHERE FormulaCategory<1000
	--Above 1000 consider as Chain category
	UPDATE @FormulaCategoryTable SET TYPE='C' WHERE FormulaCategory>=1000

	--Rollbacking to actual ID
	UPDATE @FormulaCategoryTable SET FormulaCategory=FormulaCategory-1000 WHERE TYPE='C'
	--SELECT * FROM @FormulaCategoryTable
	
	--SELECT * FROM @FormulaCategoryTable

	INSERT INTO @EcolabCategoryTable(EcolabCategory)
	SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='E'	

	INSERT INTO @ChainCategoryTable(ChainCategory)
	SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='C'

	--Value Assigning
	IF (EXISTS(SELECT * FROM @EcolabCategoryTable) AND @FormulaCategory!='')
	BEGIN
		SET @EcolabCategory=@FormulaCategory
	END
	IF (EXISTS(SELECT * FROM @ChainCategoryTable) AND @FormulaCategory!='')
	BEGIN
		SET @ChainCategory=@FormulaCategory
	END
	---Formula category-------------------------End

	-----Formula Ecolab/Chain categories
	DECLARE @FormulaTable TABLE(Formula Varchar(1000),Type CHAR(1))
    INSERT INTO @FormulaTable(Formula) EXEC [TCD].[CharlistToTable] @Formula,','

	--segregating Ecolab/Chain categories
	--UPDATE @FormulaTable SET TYPE=RIGHT(Formula,1),Formula=LEFT(Formula,LEN(Formula)-2)
	/*
	--Below 1000 Ecolab category
	UPDATE @FormulaTable SET TYPE='E' WHERE Formula<1000
	--Above 1000 consider as Chain category
	UPDATE @FormulaTable SET TYPE='C' WHERE Formula>=1000

	--Rollbacking to actual ID
	UPDATE @FormulaTable SET Formula=Formula-1000 WHERE TYPE='C'
	*/
	--Select * from @FormulaTable
	--Plant fomula   
    INSERT INTO @PlantFormulaTable(PlantFormula) 
	SELECT Formula FROM @FormulaTable --WHERE Type='E'
	--chain formula   
    INSERT INTO @ChainFormulaTable(ChainFormula) 
	SELECT Formula FROM @FormulaTable --WHERE Type='C'
	--SELECT * FROM @PlantFormulaTable
	--SELECT * FROM @ChainFormulaTable

	--Value Assigning
	IF (EXISTS(SELECT * FROM @PlantFormulaTable) AND @Formula!='')
	BEGIN
		SET @PlantFormula=@Formula
	END
	IF (EXISTS(SELECT * FROM @ChainFormulaTable) AND @Formula!='')
	BEGIN
		SET @ChainFormula=@Formula
	END
	--SELECT @PlantFormula,@ChainFormula
	-----Formula Segregation end

    DECLARE @actualproduction int,@uom int
    SELECT @uom =UM.UOMId FROM TCD.UserMaster AS UM WHERE UM.UserId = @UserId

   	--Operation summary Table Declaration
    DECLARE @OperationSummaryTable TABLE 
	 ( 
		[ShiftId] [int] NULL,[ShiftName] Varchar(100) NULL,RecordDate date,
		[MachineId] [int] NULL,[ProgramMasterId] [int] NULL,[EcolabWasherId] [int] NULL,
		ActualProduction [int] NULL,
		[NoOfLoads] [int] NULL,ActualChemicalConsumption Decimal(18,2),
		TargetChemicalConsumption Decimal(18,2),ActualEnergyConsumption  Decimal(18,2),TargetEnergyConsumption Decimal(18,2),
		ActualWaterConsumption  Decimal(18,2),TargetwaterConsumption Decimal(18,2),
		ActualChemicalCost decimal(18,2),ActualWaterCost decimal(18,2),ActualEnergyCost decimal(18,2),
		EcolabTextileId int,ChainTextileId int,ChainProgaramId int,CustomerId int,FormulaSegmentID INT        
        )

	--Operation summary Table Insertion
    INSERT INTO @OperationSummaryTable
		(
		[ShiftId] ,[ShiftName] ,RecordDate ,
		[MachineId] ,[ProgramMasterId],[EcolabWasherId],
		ActualProduction,
		[NoOfLoads],ActualChemicalConsumption,
		TargetChemicalConsumption,ActualEnergyConsumption ,TargetEnergyConsumption ,
		ActualWaterConsumption  ,TargetwaterConsumption ,
		ActualChemicalCost ,ActualWaterCost ,ActualEnergyCost ,
		EcolabTextileId ,ChainTextileId ,ChainProgaramId ,FormulaSegmentID,CustomerId
		)
		SELECT DISTINCT SPD.[ShiftId],PS.ShiftName, CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date),         
		SPD.[MachineId] ,SPD.[ProgramMasterId],SPD.[EcolabWasherId],
		
		CASE @uom WHEN 1 THEN SUM( DISTINCT ISNULL(spd.ActualProduction,0))
			WHEN 2 THEN ISNULL([TCD].[FnConsumptionOnMetrics](SUM( DISTINCT ISNULL(spd.ActualProduction,0)),'Weight',@UserId),0) END,         
		SUM(DISTINCT ISNULL(SPD.NoOfLoads,0)),SUM(ISNULL(SCD.ActualConsumption,0)),
		SUM(ISNULL(SCD.TargetConsumption,0)),SUM(ISNULL(SED.ActualConsumption,0)),SUM(ISNULL(SED.TargetConsumption,0)),
		SUM(ISNULL(SWD.ActualConsumption,0)),SUM(ISNULL(SWD.TargetConsumption,0)),
		SUM(ISNULL(SCD.ActualCost,0)),SUM(ISNULL(SED.ActualCost,0)),SUM(ISNULL(SWD.ActualCost,0)),  		  
		              
		--SPD.EcolabTextileId,SPD.ChainTextileId,SPD.ChainProgaramId,
				 
		CASE WHEN PM.PlantProgramId IS NOT NULL THEN ChainPlant.EcolabTextileCategoryId
		ELSE ETC1.TextileId END AS EcolabTextileCategory,
		CASE WHEN PM.PlantProgramId IS NOT NULL THEN ChainPlant.ChainTextileCategoryId
		ELSE NULL END AS ChainTextilecategory,	
		PM.PlantProgramId,
		CASE WHEN PM.PlantProgramId IS NOT NULL THEN ChainPlant.FormulaSegmentId
		ELSE FS1.FormulaSegmentID END AS Formulasegment,
		SPD.CustomerId
		         
		FROM 
		TCD.ShiftProductionDataRollup SPD 
		INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId 
		LEFT JOIN  TCD.ShiftChemicalDataRollup SCD  ON SPD.ShiftId = SCD.ShiftId AND SPD.MachineId = SCD.MachineId AND SPD.ProgramMasterId = SCD.ProgramMasterId
		LEFT JOIN TCD.ShiftEnergyDataRollup SED ON SED.ShiftId = SPD.ShiftId AND SED.MachineId = SPD.MachineId AND SED.ProgramMasterId = SPD.ProgramMasterId
		LEFT JOIN TCD.[ShiftWaterDataRollup] SWD ON SED.ShiftId = SPD.ShiftId AND SWD.MachineId = SPD.MachineId AND SWD.ProgramMasterId = SPD.ProgramMasterId
		INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId 
		--Added by Kiran
		LEFT OUTER JOIN
		 (
			--IF Chain Plant
			SELECT PCP.PlantProgramId,PCP.PlantChainId,PCP.ChainTextileCategoryId,PCP.EcolabTextileCategoryId,
			PCP.FormulaSegmentId,PCP.EcolabSaturationId
			FROM TCD.PlantChainProgram PCP 
			LEFT OUTER JOIN TCD.ChainTextileCategory CTC ON CTC.TextileId=PCP.ChainTextileCategoryId
			LEFT OUTER JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId=PCP.EcolabTextileCategoryId
			LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=PCP.FormulaSegmentId
			LEFT OUTER JOIN TCD.EcolabSaturation ES ON ES.EcolabSaturationId=PCP.EcolabSaturationId
		 )ChainPlant ON PM.PlantProgramId=ChainPlant.PlantProgramId

		LEFT OUTER JOIN TCD.EcolabTextileCategory ETC1 ON ETC1.TextileId=PM.EcolabTextileCategoryId
		LEFT OUTER JOIN TCD.FormulaSegments FS1 ON FS1.FormulaSegmentID=PM.FormulaSegmentId
		LEFT OUTER JOIN TCD.EcolabSaturation ES1 ON ES1.EcolabSaturationId=PM.EcolabSaturationId
		----End

        WHERE SPD.MachineId NOT IN (SELECT ms.WasherId FROM TCD.MachineSetup AS ms WHERE ms.IsPony = 1)
		AND 
			CASE @StartDate                                                                                
			WHEN '' THEN 
				CASE WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
			ELSE 
				CASE WHEN PS.[StartDateTime]  >= @startdate AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
			END='TRUE'		
		AND
			CASE @MachineType   
			WHEN '' THEN 'TRUE'         
			ELSE                                                      
			CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
			MS.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable))) THEN 'TRUE' END                                                      
			END='TRUE'	
		AND
			CASE @machineGroup   
			WHEN '' THEN 'TRUE'         
			ELSE                                                      
			CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
			MS.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable)) THEN 'TRUE' END                                                      
			END='TRUE' 
		AND
			CASE @Machine   
			WHEN '' THEN 'TRUE'         
			ELSE                                                      
			CASE WHEN SPD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
			END='TRUE'		 
		AND 
		/*   
			CASE @EcolabCategory   
			WHEN '' THEN 'TRUE'         
			ELSE                                                      
			CASE WHEN SPD.EcolabTextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                      
			END='TRUE' 
		AND 		   
			CASE @ChainCategory   
			WHEN '' THEN 'TRUE'         
			ELSE                                                      
			CASE WHEN SPD.ChainTextileId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END                                                      
			END='TRUE'
        AND
		   
			CASE @PlantFormula   
			WHEN '' THEN 'TRUE'         
			ELSE                                                      
			CASE WHEN SPD.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                      
			END='TRUE'  
        AND    
			CASE @ChainFormula   
			WHEN '' THEN 'TRUE'         
			ELSE                                                      
			CASE WHEN SPD.ChainTextileId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END                                                      
			END='TRUE'
        AND 
		*/		
			CASE @Customer   
			WHEN '' THEN 'TRUE'         
				ELSE                                                      
				CASE WHEN SPD.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                      
			END='TRUE'	

		--Added by Kiran
		AND 
			CASE @EcolabCategory   
			WHEN '' THEN 'TRUE' 
			ELSE
				CASE WHEN PM.PlantProgramId IS NOT NULL THEN
						CASE WHEN ChainPlant.EcolabTextileCategoryId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END					                                                                              
				ELSE 
				CASE WHEN ETC1.TextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable)  THEN 'TRUE'END 
			END  
			END='TRUE'                            
		AND 
			CASE @ChainCategory    
			WHEN '' THEN 'TRUE' 
				ELSE 
					CASE WHEN PM.PlantProgramId IS NOT NULL THEN
						CASE WHEN ChainPlant.ChainTextileCategoryId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END	
					ELSE 'TRUE' END                                                                                			                                                  
			END='TRUE'
		AND 			
			CASE @PlantFormula   
			WHEN '' THEN 'TRUE'         
			ELSE                                                      
			CASE WHEN SPD.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                      
			END='TRUE'
        AND    
			CASE @ChainFormula   
			WHEN '' THEN 'TRUE'         
			ELSE                                                      
				CASE WHEN PM.PlantProgramId IS NOT NULL THEN
						CASE WHEN ChainPlant.ChainTextileCategoryId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END	
				ELSE 'TRUE' END                                                        
			END='TRUE'
        AND 
			CASE @FormulaSegement                                                                                
			WHEN '' THEN  'TRUE'
			ELSE
				CASE WHEN PM.PlantProgramId IS NOT NULL THEN
					CASE WHEN ChainPlant.FormulaSegmentId IN (SELECT FormulaSegment FROM @FormulaSegmentTable) THEN 'TRUE' END						                                                                               
				ELSE 
					CASE WHEN FS1.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)  THEN 'TRUE'END   
				END                                                     
			END='TRUE'

		GROUP BY SPD.[ShiftId],PS.ShiftName,SPD.[MachineId] ,SPD.[ProgramMasterId],SPD.[EcolabWasherId],
		ChainPlant.ChainTextileCategoryId,ChainPlant.EcolabTextileCategoryId,
		SPD.ChainProgaramId,
		SPD.CustomerId,CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date),
		ChainPlant.FormulaSegmentId,PM.PlantProgramId,ETC1.TextileId,FS1.FormulaSegmentID
		
		--Kiran Added end
			
        /*    
		GROUP BY SPD.[ShiftId],PS.ShiftName,SPD.[MachineId] ,SPD.[ProgramMasterId],SPD.[EcolabWasherId],SPD.EcolabTextileId,         SPD.ChainTextileId,
		SPD.ChainProgaramId,
		SPD.CustomerId,CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date)--,PM.FormulaSegmentId
		*/
		--UPDATE     @OperationSummaryTable SET FormulaSegmentID=1 WHERE ShiftId=4
		--UPDATE     @OperationSummaryTable SET FormulaSegmentID=2 WHERE ShiftId in(7,1027)
		--UPDATE     @OperationSummaryTable SET FormulaSegmentID=3 WHERE ShiftId=1026

    --SELECT * FROM @OperationSummaryTable
    SELECT @NoOfLoads =  SUM(NoOfLoads) 
		FROM ( SELECT SUM(OST.NoOfLoads) AS NoOfLoads FROM @OperationSummaryTable AS OST GROUP BY OST.ShiftId )  NoOfLoads
	
    IF(@Viewtype = 3) ---Ecolab Categories

    BEGIN
		---EcoLabCategory
		IF(@Subview = 12)
		BEGIN
			 INSERT INTO @resultSet
			 (
				ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
				TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
				ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
				ActualEnergyCost ,Viewtype, Subview,Id 
			 )
			 SELECT DISTINCT
				0
				,EC.CategoryName
				,SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
				,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				,@Viewtype 
				,@Subview
				,EC.TextileId
			FROM @OperationSummaryTable SPD LEFT JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
			GROUP BY EC.CategoryName,EC.TextileId
        END
		---EcoLabFormula
		IF(@Subview = 17)
		BEGIN
			INSERT INTO @resultSet
			 (
				ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
				TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
				ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
				ActualEnergyCost ,Viewtype, Subview,Id 
			 )
			 SELECT 
			   DISTINCT
				0, 
				PM.Name
				,SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
				,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				,@Viewtype 
				,@Subview
				,0
				FROM @OperationSummaryTable SPD INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
					 INNER JOIN TCD.ProgramMaster PM ON EC.TextileId = PM.EcolabTextileCategoryId AND SPD.ProgramMasterId = PM.ProgramId
    
			WHERE
				(
				CASE    
				 WHEN @drillvalue='' THEN 'TRUE' 
				 WHEN @drillvalue IS NULL THEN 'TRUE'  
				 ELSE                                                    
				  CASE WHEN EC.TextileId IN (@drillvalue) THEN 'TRUE' END            
				 END='TRUE'
				)
			GROUP BY  PM.Name
		END
	END

	-- ************************ By Textile Category View ************************************************
	IF(@Viewtype = 4)
	BEGIN 
		--TextileCategory
		IF(@Subview = 15)
		BEGIN
			 INSERT INTO @resultSet
			 (
				ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
				TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
				ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
				ActualEnergyCost ,Viewtype, Subview,Id 
			 )
			 SELECT DISTINCT
				0,
				CC.Name
				,SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
				,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				,@Viewtype 
				,@Subview
				,CC.TextileId
				FROM @OperationSummaryTable SPD LEFT JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
			 GROUP BY CC.Name,CC.TextileId
		END  
		--TextileFormula
		IF(@Subview = 18)
		BEGIN
			 INSERT INTO @resultSet
			 (
				ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
				TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
				ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
				ActualEnergyCost ,Viewtype, Subview,Id 
			 )
			 SELECT DISTINCT       
				0, 
				PM.Name
				,SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
				,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				,@Viewtype 
				,@Subview
				,0
				FROM @OperationSummaryTable SPD INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
					 INNER JOIN TCD.ProgramMaster PM ON CC.TextileId = PM.ChainTextileId AND SPD.ProgramMasterId = PM.ProgramId
    
			WHERE
				(
				CASE    
				 WHEN @drillvalue='' THEN 'TRUE' 
				 WHEN @drillvalue IS NULL THEN 'TRUE'  
				 ELSE                                                    
				  CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END            
				 END='TRUE'
				)
			GROUP BY PM.Name
		END
	END

	-- ******************************** Timeline View ***************************************************
	IF(@Viewtype = 1)
	BEGIN
		---- By TimeLine - Day View
		IF(@Subview = 5)
		BEGIN 
			INSERT INTO @resultSet
			 (
				ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
				TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
				ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
				ActualEnergyCost ,Viewtype, Subview,Id 
			 )
				SELECT DISTINCT
				0,
				SPD.ShiftName
				 ,SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
				,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				,@Viewtype 
				,@Subview
				,0
				 FROM @OperationSummaryTable SPD
				GROUP BY SPD.ShiftName
		END		
		---- By TimeLine - Week View
		IF (@Subview = 4)
		BEGIN
			INSERT INTO @resultSet
			 (
				ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
				TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
				ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
				ActualEnergyCost ,Viewtype, Subview,Id 
			 )
			SELECT DISTINCT
			0,
			CAST(RecordDate AS nvarchar(100))
			,SUM(SPD.ActualProduction)
			,sum(DISTINCT NoOfLoads)
			,SUM(ActualChemicalConsumption)
			,SUM(TargetChemicalConsumption) 
			,SUM(ActualEnergyConsumption)
			,SUM(TargetEnergyConsumption)
			,SUM(ActualWaterConsumption)
			,SUM(TargetWaterConsumption)
			,SUM(ActualChemicalCost)
			,SUM(ActualWaterCost)
			,SUM(ActualEnergyCost)
			,@Viewtype 
			,@Subview
			,0
				FROM @OperationSummaryTable SPD
			GROUP BY DATEPART(weekday,RecordDate),RecordDate
		END
		
		---- By TimeLine - Month View
		IF(@Subview = 3)
		 BEGIN
			DECLARE @FirstDay date = (SELECT TOP 1 RecordDate FROM @OperationSummaryTable ORDER BY RecordDate)
			DECLARE @LastDay date = (SELECT TOP 1 RecordDate FROM @OperationSummaryTable ORDER BY RecordDate DESC)
			DECLARE @FirstSunday date = NULL,
			@LastSaturday date = NULL
						    
			SELECT 
			@FirstSunday = CAST(DateAdd(dd, (8-DatePart(WEEKDAY, 
			   DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)))%7, 
			   DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)) AS DATE) 

			 SELECT
			  @LastSaturday = 
				DATEADD(dd,
					-DATEPART(WEEKDAY,
					  DATEADD(dd, -DAY(DATEADD(month, 1, @LastDay)),
					  DATEADD(month, 1, @LastDay))) ,
					DATEADD(dd, -DAY(DATEADD(MONTH, 1, @LastDay)), DATEADD(MONTH, 1, @LastDay)));

			WITH CTE(DateRange ,TotalLoad,Numberofbatches,ActualChemicalConsumption,TargetChemicalConsumption,
			ActualEnergyConsumption,TargetEnergyConsumption,ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,ActualEnergyCost)
			AS
			(
			SELECT        
				CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,-1,@FirstSunday)) = 7 
			   AND (SELECT COUNT(1) FROM @OperationSummaryTable WHERE RecordDate < DATEADD(DD,-1,@FirstSunday)) = 0)
			   THEN CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100))
			   WHEN DATEADD(DD,-1,@FirstSunday) > CAST(GETDATE() AS DATE) 
			   THEN
			   CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @enddate, 101) AS nvarchar(100))
			   ELSE
			   CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) END As DateRange,
			   SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
				,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)

				 FROM @OperationSummaryTable SPD
				WHERE RecordDate < @FirstSunday AND RecordDate >= @FirstDay

        
				UNION ALL

  
				SELECT
        
				--CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100)) AS StartDate,
				--CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) AS EndDate,
				  CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100))  + CHAR(13) + '-' +
				 CASE WHEN CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) >
				 CAST(Convert(varchar, DateAdd(dd, (1 - DatePart(dw, @enddate) + 1), @enddate), 101) AS nvarchar(100))
				 THEN  CAST(Convert(varchar, DateAdd(dd, 1-1, @enddate), 101) AS nvarchar(100))
				 ELSE CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) END
				 As DateRange,
				 SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
				,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				 ,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				FROM @OperationSummaryTable SPD
				   WHERE RecordDate BETWEEN @FirstSunday AND @LastSaturday
				GROUP BY Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101),
				 Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101)
       
			   UNION ALL

				SELECT 
				 CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,1,@LastSaturday)) = 1 
				AND (SELECT COUNT(1) FROM @OperationSummaryTable WHERE RecordDate > DATEADD(DD,1,@LastSaturday)) = 0)
				THEN 
				CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) 
				ELSE
			   CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @LastDay, 101) AS nvarchar(100)) END   As DateRange,
				SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
				,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				 ,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				FROM @OperationSummaryTable SPD
				WHERE RecordDate > @LastSaturday AND RecordDate <= @LastDay
				)
				INSERT INTO @resultSet
				 (
					ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
					TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
					ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
					ActualEnergyCost ,Viewtype, Subview,Id 
				)
				SELECT DISTINCT
				0,
				DateRange,
				TotalLoad,
				Numberofbatches,
				ActualChemicalConsumption,
				TargetChemicalConsumption,
				ActualEnergyConsumption,
				TargetEnergyConsumption,
				ActualWaterConsumption,
				TargetWaterConsumption,
				ActualChemicalCost,
				ActualWaterCost,
				ActualEnergyCost       
				,@Viewtype 
				,@Subview
				 ,0
				FROM CTE
				WHERE TotalLoad IS NOT NULL

        END
		---- By TimeLine - Quarter View
		IF(@Subview = 2)
		BEGIN
			DECLARE @QuarterYear VARCHAR(100) = YEAR(@enddate);
			INSERT INTO @resultSet
			 (
				ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
				TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
				ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
				ActualEnergyCost ,Viewtype, Subview,Id 
			 )
			SELECT  DISTINCT
			    0,
				DATENAME(MONTH, RecordDate) + ' ' + @QuarterYear As DateRange,
				SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
				,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption) 
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				,@Viewtype 
				,@Subview
				,0
			FROM @OperationSummaryTable SPD
			GROUP BY  DATEPART(MONTH, RecordDate),DATENAME(MONTH, RecordDate)
		END   
		---- By TimeLine - Year View
		IF(@Subview = 1)
		BEGIN
			DECLARE @Year VARCHAR(100) = RIGHT(YEAR(@enddate),2)
			INSERT INTO @resultSet
			 (
				ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
				TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
				ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
				ActualEnergyCost ,Viewtype, Subview,Id 
			 )
			SELECT DISTINCT
				0,
				CASE 'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10))
				WHEN 'Q1' THEN 'Jan' + @Year + '- Mar' + @Year
				WHEN 'Q2' THEN 'Apr' + @Year + '- Jun' + @Year
				WHEN 'Q3' THEN 'Jul' + @Year + '-Sep' + @Year
				WHEN 'Q4' THEN 'Oct' + @Year + '- Dec'+ @Year
				END AS DateRange,
				SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
				,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				,@Viewtype 
				,@Subview
				,0
			FROM @OperationSummaryTable SPD
			GROUP BY DATEPART(QUARTER, RecordDate)
		END
    END

    -- ******************************** Location View ***************************************************
    IF(@Viewtype = 2)
    BEGIN
		--Plant
		IF(@Subview = 9)
		BEGIN
			WITH CTE(DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption,TargetChemicalConsumption,ActualEnergyConsumption,
			TargetEnergyConsumption,ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,ActualEnergyCost,WasherGroupId)
			AS
			(
			SELECT 
				WG.WasherGroupName,
				SUM(SPD.ActualProduction)
			   ,sum(NoOfLoads)
			   ,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				 ,SUM(ActualChemicalCost)
			 ,SUM(ActualWaterCost)
			 ,SUM(ActualEnergyCost)
			   ,WG.WasherGroupId

			FROM @OperationSummaryTable SPD LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId
					 LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId 
			GROUP BY WG.WasherGroupName,WG.WasherGroupId--,SPD.ShiftId
			) 

			 INSERT INTO @resultSet
			 (
				ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
				TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
				ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
				ActualEnergyCost ,Viewtype, Subview,Id 
			 )
			SELECT 0, 
			DateRange,
			SUM(TotalLoad),
			SUM(Numberofbatches),
			SUM(ActualChemicalConsumption)
			,SUM(TargetChemicalConsumption) 
			,SUM(ActualEnergyConsumption)
			,SUM(TargetEnergyConsumption)
			,SUM(ActualWaterConsumption)
			,SUM(TargetWaterConsumption)
			,SUM(ActualChemicalCost)
			,SUM(ActualWaterCost)
			,SUM(ActualEnergyCost)
			,@Viewtype 
			,@Subview
			,WasherGroupId
			FROM CTE 
			WHERE TotalLoad IS NOT NULL       
			GROUP BY DateRange,WasherGroupId
		 END
		--WasherGroup
		IF(@Subview = 10)
		BEGIN
			 WITH CTE(DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption,TargetChemicalConsumption,ActualEnergyConsumption,
			 TargetEnergyConsumption,ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,ActualEnergyCost)
			AS
			(
			SELECT 
				CAST( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName as MachineName,
				SUM(SPD.ActualProduction)
			   ,sum(NoOfLoads)
			   ,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)     
			FROM @OperationSummaryTable SPD 
			LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId
			LEFT JOIN TCD.Washer w on MS.WasherId=w.WasherId
			LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId 
			WHERE 
			  (
			   CASE @drillvalue   
				   WHEN '' THEN 'TRUE'         
				   ELSE                                                    
					CASE WHEN WG.WasherGroupId IN (@drillvalue) THEN 'TRUE' END            
				   END='TRUE'
			  )
			 GROUP BY CAST( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName--,SPD.ShiftId
			 )

			 INSERT INTO @resultSet
			 (
				ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
				TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
				ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
				ActualEnergyCost ,Viewtype, Subview,Id 
			 )
			 SELECT  0, 
				DateRange,
				SUM(TotalLoad),
				SUM(Numberofbatches),
				SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				,@Viewtype 
				,@Subview
				,0
				 FROM CTE 
				WHERE TotalLoad IS NOT NULL
				GROUP BY DateRange
		END
    END

    -- ******************************** ChainCategory View **********************************************
    IF(@Viewtype = 5)
    BEGIN
		--ChainCategory
		IF(@Subview = 16)
		BEGIN
			-- ToDo : Change this part for chaincategory
			 INSERT INTO @resultSet
			 (
				ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
				TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
				ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
				ActualEnergyCost ,Viewtype, Subview,Id 
			 )
				SELECT DISTINCT
				0,  
				CC.NAME,
				SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
				,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				,@Viewtype 
				,@Subview
				,CC.TextileId
				FROM
				@OperationSummaryTable SPD
				INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
				INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = PM.PlantProgramId
				INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId 
				Group by  CC.Name,CC.TextileId
		END
	    --ChainFormula
		IF(@Subview = 19)
		BEGIN
			-- ToDo : Change this part for chaincategory
			 INSERT INTO @resultSet
			 (
				ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
				TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
				ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
				ActualEnergyCost ,Viewtype, Subview,Id 
			 )
			 SELECT  DISTINCT
				0,
				PCP.PlantProgramName,
				SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
			    ,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				,@Viewtype 
				,@Subview
				,0
				FROM @OperationSummaryTable SPD
				INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
				INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = PM.PlantProgramId
				INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId 
				 WHERE
				(
			   CASE @drillvalue   
				   WHEN '' THEN 'TRUE'         
				   ELSE                                                    
				   CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END            
				   END='TRUE'
			  )
			 Group by  PCP.PlantProgramName,PCP.PlantProgramId
		END
	END

    -- ******************************** Customer View ***************************************************
	IF(@Viewtype = 6)
	BEGIN
		INSERT INTO @resultSet
		(
		ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
		TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
		ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
		ActualEnergyCost ,Viewtype, Subview,Id 
		)
		SELECT DISTINCT
		0,
		PC.CustomerName,
		SUM(SPD.ActualProduction)
		,sum(DISTINCT NoOfLoads)
		,SUM(ActualChemicalConsumption)
		,SUM(TargetChemicalConsumption) 
		,SUM(ActualEnergyConsumption)
		,SUM(TargetEnergyConsumption)
		,SUM(ActualWaterConsumption)
		,SUM(TargetWaterConsumption)
		,SUM(ActualChemicalCost)
		,SUM(ActualWaterCost)
		,SUM(ActualEnergyCost)
		,@Viewtype 
		,@Subview
		,0
		FROM @OperationSummaryTable SPD  INNER JOIN TCD.PlantCustomer PC on PC.CustomerId = SPD.CustomerId
		GROUP BY PC.CustomerName
	END

	-- ******************************** Formula View ****************************************************	
	IF(@Viewtype = 7)
	BEGIN
		INSERT INTO @resultSet
		(
		ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
		TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
		ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
		ActualEnergyCost ,Viewtype, Subview,Id 
		)
		SELECT DISTINCT
		0,
		PM.Name,
		SUM(SPD.ActualProduction)
		,sum(DISTINCT NoOfLoads)
		,SUM(ActualChemicalConsumption)
		,SUM(TargetChemicalConsumption) 
		,SUM(ActualEnergyConsumption)
		,SUM(TargetEnergyConsumption)
		,SUM(ActualWaterConsumption)
		,SUM(TargetWaterConsumption)
		,SUM(ActualChemicalCost)
		,SUM(ActualWaterCost)
		,SUM(ActualEnergyCost)
		,@Viewtype 
		,@Subview
		,0
		FROM @OperationSummaryTable SPD 
		INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
		Group by 
		PM.Name
   END
  
   -- ******************************** Formula Hierarchy****************************************************	
	IF(@Viewtype = 8) --Formula Hierarchy
	BEGIN
		 PRINT 'IN View'
		 IF(@Subview =20)-- Formula Segment
		 BEGIN
				PRINT 'IN subView'
				INSERT INTO @resultSet
				(
				ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
				TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
				ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
				ActualEnergyCost ,Viewtype, Subview,Id 
				)
				SELECT DISTINCT
				0,
				FS.SegmentName,
				SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
			    ,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				,@Viewtype 
				,@Subview
				,SPD.FormulaSegmentID
				FROM @OperationSummaryTable SPD 
				INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
				LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=SPD.FormulaSegmentID
				Group by SPD.FormulaSegmentID,FS.SegmentName
		END
		 IF(@Subview =21)-- Formula Categories
		 BEGIN
			 INSERT INTO @resultSet
			 (
				ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
				TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
				ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
				ActualEnergyCost ,Viewtype, Subview,Id 
			 )
			 --Chain Textile category
			 SELECT DISTINCT
				0,
				CC.Name
				,SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
				,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				,@Viewtype 
				,@Subview
				,CC.TextileId
				FROM @OperationSummaryTable SPD LEFT JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
				--WHERE SPD.ChainProgaramId IS NOT NULL --CHain Textilecategory
			 GROUP BY CC.Name,CC.TextileId

			 UNION 
			 --Ecolab Textile category
			 SELECT DISTINCT
				0
				,EC.CategoryName
				,SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
				,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				,@Viewtype 
				,@Subview
				,EC.TextileId
			FROM @OperationSummaryTable SPD LEFT JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
			--WHERE SPD.ChainProgaramId IS NULL ---Ecolab Textile categoriy
			GROUP BY EC.CategoryName,EC.TextileId

		  END
		 IF(@Subview=22) -- Formula
		 BEGIN				
			 INSERT INTO @resultSet
			 (
				ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
				TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
				ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
				ActualEnergyCost ,Viewtype, Subview,Id 
			 )
			 --chain TextileFormula
			 SELECT DISTINCT       
				0, 
				PM.Name
				,SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
				,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				,@Viewtype 
				,@Subview
				,0
				FROM @OperationSummaryTable SPD INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
					 INNER JOIN TCD.ProgramMaster PM ON CC.TextileId = PM.ChainTextileId AND SPD.ProgramMasterId = PM.ProgramId
    
			WHERE
				(
				CASE    
				 WHEN @drillvalue='' THEN 'TRUE' 
				 WHEN @drillvalue IS NULL THEN 'TRUE'  
				 ELSE                                                    
				  CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END            
				 END='TRUE'
				)
			GROUP BY PM.Name
			UNION
			---EcoLabFormula
			SELECT 
			   DISTINCT
				0, 
				PM.Name
				,SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
				,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				,@Viewtype 
				,@Subview
				,0
				FROM @OperationSummaryTable SPD INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
					 INNER JOIN TCD.ProgramMaster PM ON EC.TextileId = PM.EcolabTextileCategoryId AND SPD.ProgramMasterId = PM.ProgramId
    
			WHERE
				(
				CASE    
				 WHEN @drillvalue='' THEN 'TRUE' 
				 WHEN @drillvalue IS NULL THEN 'TRUE'  
				 ELSE                                                    
				  CASE WHEN EC.TextileId IN (@drillvalue) THEN 'TRUE' END            
				 END='TRUE'
				)
			GROUP BY  PM.Name
		  END
	END

   
   --- ********* Return result ********************

   --SELECT * FROM @resultSet

    SELECT DISTINCT
     ShiftId,
      DateRange,
     CASE @uom WHEN 1 THEN TotalLoad
            WHEN 2 THEN ISNULL([TCD].[FnConsumptionOnMetrics](TotalLoad,'Weight',@UserId),0) END AS ActualProduction,
      --CAST(TotalLoad AS int) AS ActualProduction,
      Numberofbatches AS NoOfLoads,
      ISNULL([TCD].[FnConsumptionOnMetrics](ActualChemicalConsumption,'Volume',@UserId),0) ActualChemicalConsumption,
      --ActualChemicalConsumption ,
      ISNULL([TCD].[FnConsumptionOnMetrics](TargetChemicalConsumption,'Volume',@UserId),0) TargetChemicalConsumption,
      --TargetChemicalConsumption,
      ActualEnergyConsumption,
      TargetEnergyConsumption,
      ActualWaterConsumption,
      TargetWaterConsumption,
      ActualChemicalCost,
      ActualWaterCost,
      ActualEnergyCost,
      Viewtype,
      Subview ,
      Id,
      --CASE @uom WHEN 1 THEN ActualChemicalConsumption 
      --WHEN 2 THEN ActualChemicalConsumption * 28.3495 END AS ActualChemicalConsumptionMetrics ,
      --CASE @uom WHEN 1 THEN TargetChemicalConsumption 
      --WHEN 2 THEN TargetChemicalConsumption * 28.3495 END AS TargetChemicalConsumption,
     CASE @uom WHEN 1 THEN TotalLoad/100 
            WHEN 2 THEN ISNULL([TCD].[FnConsumptionOnMetrics](TotalLoad,'Weight',@UserId),0) END AS ActualProductionMetrics      
      FROM 
        @resultSet
        WHERE [@resultSet].DateRange IS NOT NULL
    

SET NOCOUNT OFF
END
Go

IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[ReportChemicalConsumption]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[ReportChemicalConsumption] 
END 
GO 
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ReportChemicalConsumption]
/********************************************************************************************************


Execution Statement:
	EXECUTE [TCD].[ReportChemicalConsumption1]
			@startdate  = '2010-12-01',@enddate  = '2016-12-01',@EcolabAccountNumber = '',
			@MachineType = '',@MachineGroup  = '',@Machine  = '',
			@EcolabCategory = '',@ChainCategory  = '',@PlantFormula   = '',@ChainFormula  = '',
			@Customer  = '',@CurrencyCode='',@UserId  = 1,
			@FormulaSegement ='1',@FormulaCategory ='',@Formula ='' 



********************************************************************************************************/ 

	@startdate datetime = '',
	@enddate datetime = '',
	@EcolabAccountNumber Nvarchar(25) = '',
	@MachineType VARCHAR(20)= '',
	@MachineGroup VARCHAR(MAX) = '',
	@Machine VARCHAR(MAX) = '',
	@EcolabCategory VARCHAR(MAX) = '',
	@ChainCategory VARCHAR(MAX) = '',
	@PlantFormula  VARCHAR(MAX) = '',
	@ChainFormula VARCHAR(MAX) = '',
	@Customer VARCHAR(MAX) = '',
	@CurrencyCode varchar(3) = NULL,
	@UserId INT = NULL,
	@FormulaSegement VARCHAR(MAX)='', --Formula segment,
	@FormulaCategory VARCHAR(MAX)='', --Formula category
	@Formula VARCHAR(MAX)='' --Formula
AS   
BEGIN   
SET NOCOUNT ON 

	SET @startdate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@startdate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@startdate AS time)) AS DateTime))
    SET @EndDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndDate AS time)) AS DateTime))

    SELECT @CurrencyCode = ISNULL(um.CurrencyCode,0) FROM TCD.UserMaster um WHERE um.UserId = @UserId
    IF (COUNT(@CurrencyCode) <> 1)
    BEGIN
		SELECT @CurrencyCode = p.CurrencyCode FROM TCD.Plant P WHERE P.EcolabAccountNumber=@EcolabAccountNumber
    END

    DECLARE @ReportGenerated INT = 6,@Month INT = MONTH(GETDATE()),@NoOfLoads INT,@NoOfPrograms INT

	-- Inserting the record into Report History
	INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)
	SELECT @EcolabAccountNumber,UM.UserId,UM.LoginName,	GETUTCDATE(),@ReportGenerated,
			CASE WHEN @ReportGenerated = 6
				 THEN 'Generated Report : Chemical Consumption Report' 
			END
	FROM TCD.UserMaster UM
	WHERE UM.EcolabAccountNumber = @EcolabAccountNumber AND UM.UserId = @UserId
	
	--Declaraion of table variables
    DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))
    INSERT INTO @MachineTypeTable EXEC [TCD].[CharlistToTable] @MachineType,','

    DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))
    INSERT INTO @WasherGroupTable EXEC [TCD].[CharlistToTable] @machineGroup,','  

    DECLARE @MachineTable TABLE(Machine Varchar(100))
    INSERT INTO @MachineTable EXEC [TCD].[CharlistToTable] @Machine,','

    DECLARE @EcolabCategoryTable TABLE(EcolabCategory Varchar(100))
    INSERT INTO @EcolabCategoryTable EXEC [TCD].[CharlistToTable] @EcolabCategory,','

    DECLARE @ChainCategoryTable TABLE(ChainCategory Varchar(100))
    INSERT INTO @ChainCategoryTable EXEC [TCD].[CharlistToTable] @ChainCategory,','

    DECLARE @PlantFormulaTable TABLE(PlantFormula Varchar(100))
    INSERT INTO @PlantFormulaTable EXEC [TCD].[CharlistToTable] @PlantFormula,','

    DECLARE @ChainFormulaTable TABLE(ChainFormula Varchar(100))
    INSERT INTO @ChainFormulaTable EXEC [TCD].[CharlistToTable] @ChainFormula,','

    DECLARE @CustomerTable TABLE(Customer Varchar(100))
    INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','

	--Formula Segment 
	DECLARE @FormulaSegmentTable TABLE(FormulaSegment Varchar(1000))
    INSERT INTO @FormulaSegmentTable EXEC [TCD].[CharlistToTable] @FormulaSegement,','

	--Formula category
	DECLARE @FormulaCategoryTable TABLE(FormulaCategory Varchar(1000),Type CHAR(1))
    INSERT INTO @FormulaCategoryTable(FormulaCategory) EXEC [TCD].[CharlistToTable] @Formulacategory,','	
		
		--Assuming Below 1000 Ecolab category --Drop down also they have to listed same way
		UPDATE @FormulaCategoryTable SET TYPE='E' WHERE FormulaCategory<1000
		--Above 1000 consider as Chain category--for chain category they need to Append in Drop down filters
		UPDATE @FormulaCategoryTable SET TYPE='C' WHERE FormulaCategory>=1000

		--Rollbacking to actual ID
		UPDATE @FormulaCategoryTable SET FormulaCategory=FormulaCategory-1000 WHERE TYPE='C'
			
		--SELECT * FROM @FormulaCategoryTable

		INSERT INTO @EcolabCategoryTable(EcolabCategory)
		SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='E'	

		INSERT INTO @ChainCategoryTable(ChainCategory)
		SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='C'

		--Value Assigning
		IF (EXISTS(SELECT * FROM @EcolabCategoryTable) AND @FormulaCategory!='')
		BEGIN
			SET @EcolabCategory=@FormulaCategory
		END
		IF (EXISTS(SELECT * FROM @ChainCategoryTable) AND @FormulaCategory!='')
		BEGIN
			SET @ChainCategory=@FormulaCategory
		END

	
	--Formula Ecolab/Chain categories
	DECLARE @FormulaTable TABLE(Formula Varchar(1000),Type CHAR(1))
    INSERT INTO @FormulaTable(Formula) EXEC [TCD].[CharlistToTable] @Formula,','
		
		--Select * from @FormulaTable
		--Plant fomula   
		INSERT INTO @PlantFormulaTable(PlantFormula) 
		SELECT Formula FROM @FormulaTable 
		--chain formula   
		INSERT INTO @ChainFormulaTable(ChainFormula) 
		SELECT Formula FROM @FormulaTable 	

		--Value Assigning
		IF (EXISTS(SELECT * FROM @PlantFormulaTable) AND @Formula!='')
		BEGIN
			SET @PlantFormula=@Formula
		END
		IF (EXISTS(SELECT * FROM @ChainFormulaTable) AND @Formula!='')
		BEGIN
			SET @ChainFormula=@Formula
		END
		--SELECT @PlantFormula,@ChainFormula
	
	DECLARE @actualproduction int,@uom int
    SELECT @uom =UM.UOMId FROM TCD.UserMaster AS UM WHERE UM.UserId = @UserId
	
	--FInding Actual Production
	SELECT @actualproduction =
			 CASE @uom 
				 WHEN 1 THEN sum(ISNULL(spdr.ActualProduction,0))/100 
				 WHEN 2 THEN ISNULL([TCD].[FnConsumptionOnMetrics](sum(ISNULL(spdr.ActualProduction,0)),'Weight',@UserId),0) 
			 END    
	FROM tcd.ShiftProductionDataRollup spdr
	INNER JOIN TCD.ProductionShiftData AS PS ON PS.ShiftId = spdr.ShiftId 
	--Added by Kiran For Formula Hierarchy
	INNER JOIN TCD.ProgramMaster PM on SPDR.ProgramMasterId = PM.ProgramId 
	LEFT OUTER JOIN
		 (
			--IF Chain Plant
			SELECT PCP.PlantProgramId,PCP.PlantChainId,PCP.ChainTextileCategoryId,PCP.EcolabTextileCategoryId,
			PCP.FormulaSegmentId,PCP.EcolabSaturationId
			FROM TCD.PlantChainProgram PCP 
			LEFT OUTER JOIN TCD.ChainTextileCategory CTC ON CTC.TextileId=PCP.ChainTextileCategoryId
			LEFT OUTER JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId=PCP.EcolabTextileCategoryId
			LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=PCP.FormulaSegmentId
			LEFT OUTER JOIN TCD.EcolabSaturation ES ON ES.EcolabSaturationId=PCP.EcolabSaturationId
		 )ChainPlant ON PM.PlantProgramId=ChainPlant.PlantProgramId

	LEFT OUTER JOIN TCD.EcolabTextileCategory ETC1 ON ETC1.TextileId=PM.EcolabTextileCategoryId
	LEFT OUTER JOIN TCD.FormulaSegments FS1 ON FS1.FormulaSegmentID=PM.FormulaSegmentId
	LEFT OUTER JOIN TCD.EcolabSaturation ES1 ON ES1.EcolabSaturationId=PM.EcolabSaturationId
	----End

    WHERE
       CASE @StartDate                                                                                
       WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
       ELSE CASE WHEN PS.[StartDateTime] >= @startdate AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
       END='TRUE'
     AND
       CASE @MachineType   
       WHEN '' THEN 'TRUE'         
       ELSE                                                      
       CASE WHEN spdr.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
       MS.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable))) THEN 'TRUE' END                                                      
       END='TRUE'    
    AND    
        CASE @machineGroup   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN spdr.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
        MS.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable)) THEN 'TRUE' END                                                      
        END='TRUE' 
    AND
        CASE @Machine   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN spdr.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
        END='TRUE' 
    AND
		/*
        CASE @EcolabCategory   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN spdr.EcolabTextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                      
        END='TRUE' 
     AND
    
        CASE @ChainCategory   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN spdr.ChainTextileId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END                                                      
        END='TRUE'
    AND

        CASE @PlantFormula   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN spdr.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                      
        END='TRUE'  
    AND
    
        CASE @ChainFormula   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN spdr.ChainTextileId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END                                                      
        END='TRUE'
    AND
		*/
    
        CASE @Customer   
        WHEN '' THEN 'TRUE'         
           ELSE                                                      
           CASE WHEN spdr.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                      
        END='TRUE' 
		--Added by Kiran
	AND 
		CASE @EcolabCategory   
		WHEN '' THEN 'TRUE' 
		ELSE
			CASE WHEN PM.PlantProgramId IS NOT NULL THEN
					CASE WHEN ChainPlant.EcolabTextileCategoryId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END					                                                                              
			ELSE 
			CASE WHEN ETC1.TextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable)  THEN 'TRUE'END 
		END  
		END='TRUE'                            
	AND 
		CASE @ChainCategory    
		WHEN '' THEN 'TRUE' 
			ELSE 
				CASE WHEN PM.PlantProgramId IS NOT NULL THEN
					CASE WHEN ChainPlant.ChainTextileCategoryId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END	
				ELSE 'TRUE' END                                                                                			                                                  
		END='TRUE'
	AND 			
		CASE @PlantFormula   
		WHEN '' THEN 'TRUE'         
		ELSE                                                      
		CASE WHEN spdr.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                      
		END='TRUE'
    AND    
		CASE @ChainFormula   
		WHEN '' THEN 'TRUE'         
		ELSE                                                      
			CASE WHEN PM.PlantProgramId IS NOT NULL THEN
					CASE WHEN ChainPlant.ChainTextileCategoryId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END	
			ELSE 'TRUE' END                                                        
		END='TRUE'
    AND 
		CASE @FormulaSegement                                                                                
		WHEN '' THEN  'TRUE'
		ELSE
			CASE WHEN PM.PlantProgramId IS NOT NULL THEN
				CASE WHEN ChainPlant.FormulaSegmentId IN (SELECT FormulaSegment FROM @FormulaSegmentTable) THEN 'TRUE' END						                                                                               
			ELSE 
				CASE WHEN FS1.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)  THEN 'TRUE'END   
			END                                                     
		END='TRUE'


	--Result Table
    DECLARE @resultSet TABLE
    (          
        ChemicalName VARCHAR(100),ActualConsumption DECIMAL(18,2),TargetConsumption DECIMAL(18,2),--MachineId INT,
        ProgramMasterId INT,NoOfDays INT,NoOfLoads INT,
		Cost DECIMAL(18,2),StartDateTime date,PackageSizeId int,
		UnitWeightVolumeUOMId int,packagesizeweightuomcode varchar(100)
    )
	INSERT INTO @resultSet
	(
		ChemicalName ,ActualConsumption ,TargetConsumption ,--MachineId ,
		ProgramMasterId ,NoOfDays ,NoOfLoads ,
		Cost,StartDateTime ,PackageSizeId ,
		UnitWeightVolumeUOMId,
		packagesizeweightuomcode	
	)
	SELECT PM.Name,SUM(SCD.ActualConsumption),	SUM(SCD.TargetConsumption),--SCD.MachineId,
		SCD.ProgramMasterId,COUNT(DISTINCT CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date)),@actualproduction,
		SUM(SCD.ActualCost),PS.StartDateTime,PM.PackageSizeId, 
		CASE WHEN pm.PackageSizeId IS NULL AND type = 'Liquid' THEN isnull(psi.UnitWeightVolumeUOMId, 6) 
			 WHEN pm.PackageSizeId IS NULL AND type = 'solid' THEN isnull(psi.UnitWeightVolumeUOMId, 12) 
			 ELSE psi.UnitWeightVolumeUOMId END AS UnitWeightVolumeUOMId, 
		CASE WHEN pm.PackageSizeId IS NULL AND type = 'Liquid' THEN isnull(psi.packagesizeweightuomcode, 'Pounds') 
			 WHEN pm.PackageSizeId IS NULL AND type = 'solid' THEN isnull(psi.packagesizeweightuomcode, 'gal')
			 WHEN pm.PackageSizeId IS NULL and type is null then 'gal'
			 ELSE psi.packagesizeweightuomcode END AS packagesizeweightuomcode
	FROM 
	TCD.ShiftChemicalDataRollup SCD 
	INNER JOIN TCD.ProductionShiftData PS ON SCD.SHIFTID = PS.ShiftId
	INNER JOIN TCD.ProgramMaster PRM on SCD.ProgramMasterId = PRM.ProgramId
	LEFT OUTER JOIN TCD.ProductMaster PM ON SCD.ProductId = PM.ProductId 
	INNER JOIN TCD.ProductdataMapping AS PDM ON PDM.ProductId = PM.ProductId 
	LEFT OUTER JOIN TCD.PackageSize AS PSi ON PM.PackageSizeId = PSi.PackageSizeId
	--Added by Kiran For Formula Hierarchy	
	LEFT OUTER JOIN
		 (
			--IF Chain Plant
			SELECT PCP.PlantProgramId,PCP.PlantChainId,PCP.ChainTextileCategoryId,PCP.EcolabTextileCategoryId,
			PCP.FormulaSegmentId,PCP.EcolabSaturationId
			FROM TCD.PlantChainProgram PCP 
			LEFT OUTER JOIN TCD.ChainTextileCategory CTC ON CTC.TextileId=PCP.ChainTextileCategoryId
			LEFT OUTER JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId=PCP.EcolabTextileCategoryId
			LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=PCP.FormulaSegmentId
			LEFT OUTER JOIN TCD.EcolabSaturation ES ON ES.EcolabSaturationId=PCP.EcolabSaturationId
		 )ChainPlant ON PRM.PlantProgramId=ChainPlant.PlantProgramId

	LEFT OUTER JOIN TCD.EcolabTextileCategory ETC1 ON ETC1.TextileId=PRM.EcolabTextileCategoryId
	LEFT OUTER JOIN TCD.FormulaSegments FS1 ON FS1.FormulaSegmentID=PRM.FormulaSegmentId
	LEFT OUTER JOIN TCD.EcolabSaturation ES1 ON ES1.EcolabSaturationId=PRM.EcolabSaturationId
	----End
	WHERE 	  
		SCD.machineID IN (SELECT ms.WasherId FROM TCD.MachineSetup AS ms WHERE isNull(ms.IsPony,0) = 0) -- Exclude pony washers
		AND
			CASE @StartDate                                                                                
			   WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
			   ELSE CASE WHEN PS.[StartDateTime] >= @startdate AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
			   END='TRUE'
		AND
			CASE @MachineType   
				WHEN '' THEN 'TRUE'         
				ELSE                                                      
				CASE WHEN SCD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE     
				MS.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable))) THEN 'TRUE' END                                                      
				END='TRUE'     
		AND   
			CASE @machineGroup   
				WHEN '' THEN 'TRUE'         
				ELSE                                                      
				CASE WHEN SCD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE   
				MS.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable)) THEN 'TRUE' END                                                      
				END='TRUE' 
		AND
			CASE @Machine   
				WHEN '' THEN 'TRUE'         
				ELSE                                                      
				CASE WHEN SCD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
				END='TRUE' 
		AND		
			CASE @EcolabCategory   
			WHEN '' THEN 'TRUE'         
			ELSE                                                      
			CASE WHEN SCD.EcolabTextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                      
			END='TRUE' 
		AND
    
			CASE @ChainCategory   
			WHEN '' THEN 'TRUE'         
			ELSE                                                      
			CASE WHEN SCD.ChainTextileId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END                                                      
			END='TRUE'
		AND

			CASE @PlantFormula   
			WHEN '' THEN 'TRUE'         
			ELSE                                                      
			CASE WHEN SCD.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                      
			END='TRUE'  
		AND
    
			CASE @ChainFormula   
			WHEN '' THEN 'TRUE'         
			ELSE                                                      
			CASE WHEN SCD.ProgramMasterId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END                                                      
			END='TRUE'
		AND
		
			CASE @Customer   
			WHEN '' THEN 'TRUE'         
				ELSE                                                      
				CASE WHEN SCD.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                      
			END='TRUE'
		AND 
			CASE @FormulaSegement                                                                                
			WHEN '' THEN  'TRUE'
			ELSE
				CASE WHEN PRM.PlantProgramId IS NOT NULL THEN
					CASE WHEN ChainPlant.FormulaSegmentId IN (SELECT FormulaSegment FROM @FormulaSegmentTable) THEN 'TRUE' END						                                                                               
				ELSE 
					CASE WHEN FS1.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)  THEN 'TRUE'END   
				END                                                     
			END='TRUE'

	GROUP BY PM.Name,SCD.ProgramMasterId,PS.StartDateTime,pm.PackageSizeId,psi.UnitWeightVolumeUOMId,psi.packagesizeweightuomcode,pm.type


    DECLARE @Exchangerate TABLE (ChemicalName VARCHAR(100), Cost DECIMAL(18,2))  

    INSERT INTO @Exchangerate(ChemicalName,Cost)        
    SELECT ChemicalName,SUM(Cost)
    FROM
        (
			SELECT  ChemicalName AS ChemicalName,
			SUM(ISNULL(Cost,0)) * ISNULL([TCD].[FnCurrencyExchangeRate](@CurrencyCode,MONTH(StartDateTime),YEAR(StartDateTime)),1) AS Cost
			FROM @resultSet
			GROUP BY ChemicalName,StartDateTime
        ) A
         GROUP BY A.ChemicalName

   
    SELECT
    ChemicalName,
     cast (ISNULL([TCD].[UnitConversionbyUserUOM](ActualConsumption,packagesizeweightuomcode,@UserId),0)as decimal(18,2)),
    --ActualConsumption * 0.0078125 AS ActualConsumption,--gal
    cast(ISNULL([TCD].[UnitConversionbyUserUOM](TargetConsumption,packagesizeweightuomcode,@UserId),0) as decimal(18,2)),
    --TargetConsumption * 0.0078125 AS TargetConsumption,--gal
    ProgramCount,
    NoOfLoads,
    NoOfDays,
    Cost,
    CAST((COALESCE(Cost/ NULLIF(ISNULL([TCD].[UnitConversionbyUserUOM](ActualConsumption,packagesizeweightuomcode,@UserId),1),0), 0) * ISNULL([TCD].[UnitConversionbyUserUOM](TargetConsumption,packagesizeweightuomcode,@UserId),0)) AS DECIMAL(18,2)) AS TargetCost,

    --CAST(((Cost / ISNULL([TCD].[FnConsumptionOnMetrics](ActualConsumption,'Volume',@UserId),0)) * ISNULL([TCD].[FnConsumptionOnMetrics](TargetConsumption,'Volume',@UserId),0))AS DECIMAL(18,2)) AS TargetCost
    --CAST(((Cost / (ActualConsumption * 0.0078125)) * (TargetConsumption* 0.0078125))AS DECIMAL(18,2)) AS TargetCost
    CASE @uom WHEN 1 THEN ActualConsumption 
			  WHEN 2 THEN ActualConsumption * 28.3495 END AS ActualConsumptionMetrics,     
    packagesizeweightuomcode as UOM
    FROM
		(
		  SELECT
		  r.ChemicalName,
		  SUM(ActualConsumption) AS ActualConsumption,
		  SUM(TargetConsumption) AS TargetConsumption,
		  COUNT( DISTINCT ProgramMasterId) AS ProgramCount,
		  COUNT(DISTINCT r.StartDateTime) AS NoOfDays,
		  MAX(NoOfLoads) AS NoOfLoads,
		  e.Cost AS Cost,
		  PackageSizeId ,
		  UnitWeightVolumeUOMId ,
		  packagesizeweightuomcode
		  --* ISNULL([TCD].[FnCurrencyExchangeRate](@CurrencyCode,MONTH(StartDateTime),YEAR(StartDateTime)),1) AS Cost

		  FROM @resultSet r INNER JOIN @Exchangerate e ON r.ChemicalName = e.ChemicalName
		  GROUP BY r.ChemicalName,e.Cost,r.PackageSizeId,r.UnitWeightVolumeUOMId,r.packagesizeweightuomcode
		) A
SET NOCOUNT OFF
END
GO

IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[GetReportDataByFilterId]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[GetReportDataByFilterId] 
END 
GO 
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[GetReportDataByFilterId]

(

@UserId INT = NULL

, @RoleId INT = NULL

, @IsLocal BIT = NULL

, @MachineTye NVARCHAR(1000) = NULL

, @Machinegroup NVARCHAR(1000) = NULL

, @ReportId INT = NULL

, @FilterId INT = NULL

)

AS

SET NOCOUNT ON;

BEGIN

    DECLARE

     @LanguageId INT = (SELECT UM.LanguageId

      FROM TCD.UserMaster UM

      WHERE UserId = @UserId );

    DECLARE

     @MachineTypeTable TABLE(MachineType VARCHAR(100));

    INSERT INTO @MachineTypeTable

    EXEC TCD.CharlistToTable @MachineTye, ',';

    DECLARE

     @MachineGroupTable TABLE(MachineGroup VARCHAR(100));

    INSERT INTO @MachineGroupTable

    EXEC TCD.CharlistToTable @machineGroup, ',';

    DECLARE

     @TypeId INT,

     @FilterTargetId INT;



    DECLARE

     @ResultTable TABLE

     (

     Id NVARCHAR(2000),

     Name NVARCHAR(300),

     TypeId INT

     );
	 

    SELECT @FilterTargetId = RFM.TargetDropDown

  FROM TCD.ReportFilterMapping RFM

  WHERE RFM.FilterId = @FilterId

    AND RFM.ReportId = @ReportId;

    IF @FilterId IS NULL



    --Filter Options for Region and Country filter  



    BEGIN

    SELECT @FilterTargetId = RF.ReportFilterId

      FROM TCD.ReportFilter RF

      WHERE RF.FilterName = 'Machine Types';

    END;

    IF @FilterTargetId = 8



    --Filter Options for machine Types  



    BEGIN

    SELECT @TypeId = RF.ReportFilterId

      FROM TCD.ReportFilter RF

      WHERE RF.FilterName = 'Machine Types';

    INSERT INTO @ResultTable (

    Id,

    Name,

    TypeId

    )

    SELECT DISTINCT

    WGT.WasherGroupTypeId AS Id,

    WGT.WasherGroupTypeName AS Name,

    @TypeId AS TypeId

      FROM

    TCD.WasherGroupType WGT

  END;

    ELSE

    BEGIN IF @FilterTargetId = 5



      --Filter Options for Machine groups based on plant  



      BEGIN

      SELECT @TypeId = RF.ReportFilterId

        FROM TCD.ReportFilter RF

        WHERE RF.FilterName = 'Machine group';

      SELECT @MachineTye = CASE @MachineTye WHEN 3 THEN '' ELSE @MachineTye END;



      INSERT INTO @ResultTable (

      Id,

      Name,

      TypeId

      )

      SELECT DISTINCT

      WG.WasherGroupId AS Id,

      WG.WasherGroupName AS Name,

      @TypeId AS TypeId

      FROM TCD.WasherGroup WG

      WHERE CASE WHEN ISNULL( @MachineTye,'')='' THEN 'TRUE'

       WHEN  @MachineTye='0' THEN 'False'

        ELSE

        CASE

        WHEN WG.WasherGroupTypeId  IN (SELECT MachineType

      FROM @MachineTypeTable) THEN 'TRUE'

        END

        END = 'TRUE';

      END;

      ELSE

      BEGIN IF @FilterTargetId = 6



        --Filter Options for Machines based on Group  



        BEGIN

        SELECT @TypeId = RF.ReportFilterId

          FROM TCD.ReportFilter RF

          WHERE RF.FilterName = 'Machine';

        --INSERT INTO @ResultTable (

        --Id,

        --Name,

        --TypeId

        --)



        SELECT 

       cast( W.WasherId AS varchar(2000)) AS Id,

       CAST( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName AS Name,

        @TypeId AS TypeId

          FROM

        TCD.MachineSetup MS

        INNER JOIN TCD.Washer W ON MS.WasherId = W.WasherId

         WHERE  IsNULL(MS.IsPony,0) = 0

         AND (MS.GroupId IN (SELECT MachineGroup

        FROM @MachineGroupTable) or ISNULL(@machineGroup,'')='' )



       ORDER BY cast( W.PlantWasherNumber AS int)

       RETURN;

        END;

      END;

    END;

    IF @FilterId = 21

   AND @ReportId = 30



    --Filter Options for User



    BEGIN

    SELECT @TypeId = RF.ReportFilterId

      FROM TCD.ReportFilter RF

      WHERE RF.FilterName = 'User';

    INSERT INTO @ResultTable (

    Id,

    Name,

    TypeId

    )

    SELECT DISTINCT

    UserId AS Id,

    LoginName AS name,

    NULL AS TypeId

      FROM tcd.usermaster;

    END;

    ELSE

    BEGIN

    IF @FilterId = 22

    BEGIN

    SELECT @TypeId = RF.ReportFilterId

      FROM TCD.ReportFilter RF

      WHERE RF.FilterName = 'ActionType';

 INSERT INTO @ResultTable (

    Id,

    Name,

    TypeId

    )

    SELECT DISTINCT

    CAST(AO.OperationId AS INT) AS OperationId,

    RKV.Value AS OperationCode,

    NULL  AS TypeId

      FROM TCD.AuditOperation AO

       LEFT JOIN

       TCD.ResourceKeyMaster RKM

    ON AO.UsageKey = RKM.[KeyName]

       LEFT JOIN

       TCD.ResourceKeyValue RKV

    ON RKV.KeyName = RKM.KeyName

      WHERE RKV.languageID = @LanguageId

      ORDER BY OperationId;

    END;

    END;



    SELECT

    

    Id,

    Name,

    TypeId

  FROM @ResultTable;

END;
GO

IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[AddConventional]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[AddConventional] 
END 
GO 
 
/*
Purpose					:	To add a new Conventional Washer from the Washer setup UI - General tab

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version

--sp_helptext	usp_AddConventional

*/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE	[TCD].[AddConventional]
					@EcoLabAccountNumber					NVARCHAR(1000)
				,	@WasherGroupId							INT
				, @NewWasherGroupId		int				=	null
				,	@ConventionalName						NVARCHAR(50)
				,	@ModelId								INT						--(Washer)Model Id for Size
				,	@ControllerId							INT
				,	@LFSWasherNumber						TINYINT					=	NULL
				,	@PlantWasherNumber						SMALLINT
				,	@WasherMode								TINYINT
				,	@MaxLoad								SMALLINT
				,	@AWEActive								BIT
				,	@HoldSignal								BIT
				,	@HoldDelay								SMALLINT															
				,	@TargetTurnTime							SMALLINT
				,	@WaterFlushTime							SMALLINT
				,	@ProgramNumber							TINYINT					--EOF number
				,	@Description							NVARCHAR(1024)			=	NULL
				,	@UserId									INT
				,	@ConventionalWasherGuid					UniqueIdentifier
				,	@ConventionalWasherId					INT									OUTPUT
				,	@LastModifiedTimestampAtCentral			DATETIME				=	NULL
				,	@OutputLastModifiedTimestampAtLocal		DATETIME				=	NULL	OUTPUT
				,	@IsDeleted								BIT						=	'FALSE'
				,   @RatioDosingActive						BIT						=	'FALSE'
,   @IsPony      BIT      = 'FALSE'
				,	@MinMachineLoad							SMALLINT				=	NULL
				,	@MaxMachineLoad							smallint				=	NULL
				,	@ProgramSelectionByTime					bit						=	NULL
				,	@FlowSwitchNumber						int						=	NULL
				,	@WasherStopExternalSignal				bit						=	NULL
				,	@OnHoldWESignalActive					bit						=	NULL
				,	@WasherOnHoldSignalDelay				int						=	NULL
				,	@ValveOutputsUsedAsTomSignal			bit						=	NULL
				,	@WeInTomMode							bit						=	NULL
				,	@ManifoldFlushTime						int						=	NULL
				,	@L1										bit						=	NULL
				,	@L2										bit						=	NULL
				,	@L3										bit						=	NULL
				,	@L4										bit						=	NULL
				,	@L5										bit						=	NULL
				,	@L6										bit						=	NULL
				,	@L7										bit						=	NULL
				,	@L8										bit						=	NULL
				,	@L9										bit						=	NULL
				,	@L10									bit						=	NULL
				,	@L11									bit						=	NULL
				,	@L12									bit						=	NULL
				,	@MyServiceLastSyncTime					DATETIME				=	NULL
				,	@UseMe1OfGroup							tinyint					=	NULL
				,	@UseMe2OfGroup							tinyint					=	NULL
				,	@UsePumpOfGroup							tinyint					=	NULL
				,	@WasherStopUseFinalExtracting			bit						=	NULL
				,	@TemperatureAlarmYesNo					bit						=	NULL
				,   @DefaultIdleTime						INT						=   NULL


AS
BEGIN

SET NOCOUNT ON


DECLARE
@ReturnValue     INT    =   0
, @ErrorId      INT    =   0
, @ErrorMessage     NVARCHAR(4000) =   N''

, @WasherId      INT    =   NULL
 , @PlantId		 INT	 =	 NULL
 , @ControllerModelId INT = NULL
--, @WasherModelId     SMALLINT  =   NULL
--, @CurrentUTCTime     DATETIME  =   GETUTCDATE()     --SQLEnlight SA0004

DECLARE
@OutputList      AS TABLE  (
WasherId      INT
, LastModifiedTimestamp   DATETIME
)

SET  @ConventionalWasherId = ISNULL(@ConventionalWasherId, NULL)   --SQLEnlight
SET  @OutputLastModifiedTimestampAtLocal   =   ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)   --SQLEnlight
SET  @LastModifiedTimestampAtCentral    =   ISNULL(@LastModifiedTimestampAtCentral, NULL)    --SQLEnlight SA0029
SELECT  @PlantId = PlantId From TCD.Plant WHERE EcolabAccountNumber = @EcoLabAccountNumber
SELECT @ControllerModelId = cmctm.ControllerModelId 
FROM TCD.ControllerModelControllerTypeMapping cmctm 
INNER JOIN TCD.ConduitController cc 
	ON cc.ControllerModelId = cmctm.ControllerModelId
WHERE cc.ControllerId = @ControllerId AND cc.EcoalabAccountNumber = @EcoLabAccountNumber

--Check that the WasherGroup being associated-to is a valid Conventional-type WG...
IF NOT EXISTS ( SELECT 1
FROM [TCD].WasherGroup     WG
JOIN [TCD].WasherGroupType    WGT
ON WG.WasherGroupTypeId  =   WGT.WasherGroupTypeId
JOIN [TCD].MachineGroup     GT         --this is actually the Groups table and NOT really a Group TYPE
ON WG.WasherGroupId   =   GT.Id   --Id is actually the Id of the Group
AND WG.EcolabAccountNumber  =   GT.EcolabAccountNumber
WHERE WG.WasherGroupId   =   @WasherGroupId
AND GT.EcolabAccountNumber  =   @EcoLabAccountNumber
AND GT.GroupTypeId      =   2   --select GroupMaintype from MachineGroup
AND WGT.WasherGroupTypeName  =   'Conventional'   --select WasherGroupTypeName from WasherGroupType
AND GT.Is_Deleted    =   'FALSE'
)
BEGIN
SET  @ErrorId      =   51001
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherGroup provided.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

--Check for unique PlantWasherNo.
IF EXISTS  ( SELECT 1
FROM [TCD].Washer      W
JOIN [TCD].MachineSetup     MS
ON W.WasherId     =   MS.WasherId
AND W.EcoLabAccountNumber  =   MS.EcoalabAccountNumber
WHERE W.EcoLabAccountNumber  =   @EcoLabAccountNumber
AND (
W.PlantWasherNumber   =   @PlantWasherNumber
)
AND W.Is_Deleted    =   'FALSE'
AND MS.IsDeleted    =   'FALSE'
)
BEGIN
SET  @ErrorId      =   51002
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Specified Plant Washer #/ already exists.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

IF @ControllerId > 0
BEGIN
--Check on valid LFSWasher#/Controller type/model...
IF @LFSWasherNumber IS NOT NULL
BEGIN
	IF NOT EXISTS ( SELECT 1
	FROM [TCD].ControllerModelControllerTypeMapping
	CMCTM
	JOIN [TCD].ConduitController   CC
	ON CC.ControllerTypeId   =   CMCTM.ControllerTypeId
	AND CC.ControllerModelId  =   CMCTM.ControllerModelId
	WHERE CC.EcoalabAccountNumber  =   @EcoLabAccountNumber
	AND CC.ControllerId    =   @ControllerId
	AND CC.IsDeleted    =   'FALSE'
	AND CMCTM.MaximumWasherExtractorCount
	>=   @LFSWasherNumber
	)
		BEGIN
			SET  @ErrorId      =   51003
			SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller/LFSWasher# was provided.'
			--GOTO ErrorHandler
			RAISERROR (@ErrorMessage, 16, 1)
			SET  @ReturnValue = -1
			RETURN (@ReturnValue)
		END
END
END
--EOF should not be an asocciated formula for the WG...
IF EXISTS  ( SELECT 1
FROM [TCD].WasherProgramSetup   WPS
WHERE WPS.EcolabAccountNumber  =   @EcoLabAccountNumber
AND WPS.WasherGroupId   =   @WasherGroupId
AND WPS.ProgramNumber   =   @ProgramNumber
AND WPS.Is_Deleted    =   'FALSE'
)
BEGIN
SET  @ErrorId      =   51004
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An assoicated formula cannot be specified as End-Of-Formula.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

IF @ControllerId > 0
BEGIN
--WasherMode check
IF NOT EXISTS ( SELECT 1
FROM [TCD].ControllerModelControllerTypeMapping
CMCTM
					JOIN	[TCD].ConduitController			CC
						ON	CC.ControllerTypeId			=			CMCTM.ControllerTypeId
						AND	CC.ControllerModelId		=			CMCTM.ControllerModelId
					JOIN	[TCD].[WasherModeMapping]			CTM2WM
						ON	CMCTM.Id					=			CTM2WM.ControllerModelControllerTypeMappingId
					WHERE	CC.EcoalabAccountNumber		=			@EcoLabAccountNumber
						AND	CC.ControllerId				=			@ControllerId
						AND	CC.IsDeleted				=			'FALSE'
						AND	CTM2WM.WasherModeId			=			@WasherMode
)
BEGIN
SET  @ErrorId      =   51005
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherMode was provided.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

--LFSWasherNumber duplicate check...
IF	EXISTS	(	SELECT	1
				FROM	[TCD].MachineSetup					MS
				WHERE	MS.ControllerId					=			@ControllerId
					AND	MS.MachineInternalId			=			@LFSWasherNumber
					AND MS.EcoalabAccountNumber			=			@EcoLabAccountNumber
					AND	MS.IsDeleted					=			'FALSE'
					AND MS.IsTunnel						=			'FALSE'

)
BEGIN
SET  @ErrorId      =   51010
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate LFSWasher# provided.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END
END
--Now attempt to insert a new row for the conventional washer being added...
BEGIN TRAN

INSERT	[TCD].Washer	(
	 EcoLabAccountNumber	,PlantWasherNumber			,ModelId				,WasherMode					,MaxLoad						,AWEActive				,EndOfFormula
	,[Description]			,Is_Deleted					,LastModifiedByUserId	,HoldSignal					,HoldDelay						,TargetTurnTime			,WaterFlushTime		
	,MyServiceCustMchGuid	,RatioDosingActive			,MyServiceLastSynchTime	,MinMachineLoad				,MaxMachineLoad					,ProgramSelectionByTime	,FlowSwitchNumber		
	,WasherStopExternalSignal	,OnHoldWESignalActive	, WasherOnHoldSignalDelay	,ValveOutputsUsedAsTomSignal			,WeInTomMode			,ManifoldFlushTime	
	,L1	,L2	,L3	,L4	,L5	,L6	,L7	,L8	,L9	 ,L10 ,L11	,L12 ,UseMe1OfGroup ,UseMe2OfGroup ,UsePumpOfGroup ,WasherStopUseFinalExtracting ,TemperatureAlarmYesNo ,PlantId, DefaultIdleTime
)
OUTPUT
inserted.WasherId      AS   Id
, inserted.LastModifiedTime  AS   LastModifiedTimestamp
INTO
@OutputList (
WasherId
, LastModifiedTimestamp
)

SELECT	@EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	@PlantWasherNumber					AS			PlantWasherNumber
	,	@ModelId							AS			ModelId
	,	@WasherMode							AS			WasherMode
	,	@MaxLoad							AS			MaxLoad
	,	@AWEActive							AS			AWEActive
	,	@ProgramNumber						AS			ProgramNumber
	,	@Description						AS			[Description]
	,	@IsDeleted							AS			Is_Deleted
	,	@UserId								AS			LastModifiedByUserId
	,	@HoldSignal							AS			HoldSignal
	,	@HoldDelay							AS			HoldDelay
	,	@TargetTurnTime						AS			TargetTurnTime
	,	@WaterFlushTime						AS			WaterFlushTime
	,	@ConventionalWasherGuid				AS			MyServiceCustMchGuid
	,	@RatioDosingActive					AS			RatioDosingActive
	,	@MyServiceLastSyncTime				AS			MyServiceLastSynchTime
	,	@MinMachineLoad						AS			MinimumMachineLoad
	,	@MaxMachineLoad						AS			MaximumMachineLoad
	,	@ProgramSelectionByTime				AS			ProgramSelectionByTime
	,	@FlowSwitchNumber					AS			FlowSwitchNumber
	,	@WasherStopExternalSignal			AS			WasherStopExternalSignal
	,	@OnHoldWESignalActive				AS			OnHoldWESignalActive
	,	@WasherOnHoldSignalDelay			AS			WasherOnHoldSignalDelay
	,	@ValveOutputsUsedAsTomSignal		AS			ValveOutputsUsedAsTomSignal
	,	@WeInTomMode						AS			WeInTomMode			
	,	@ManifoldFlushTime					AS			ManifoldFlushTime			
	,	@L1									AS			L1
	,	@L2									AS			L2
	,	@L3									AS			L3
	,	@L4									AS			L4
	,	@L5									AS			L5
	,	@L6									AS			L6
	,	@L7									AS			L7
	,	@L8									AS			L8
	,	@L9									AS			L9
	,	@L10								AS			L10
	,	@L11								AS			L11
	,	@L12								AS			L12
	,	@UseMe1OfGroup						AS			UseMe1OfGroup
	,	@UseMe2OfGroup						AS			UseMe2OfGroup
	,	@UsePumpOfGroup						AS			UsePumpOfGroup
	,	@WasherStopUseFinalExtracting		AS			WasherStopUseFinalExtracting
	,	@TemperatureAlarmYesNo				AS			TemperatureAlarmYesNo
	,	@PlantId							AS			PlantId
	,   @DefaultIdleTime AS   DefaultIdleTime 


SET @ErrorId = @@ERROR

IF (@ErrorId <> 0)
BEGIN
IF @@TRANCOUNT > 0
BEGIN
ROLLBACK TRAN
END

SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred creating new record for conventional.'
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

--if no error, collect the id of the newly generated row...
SELECT TOP 1 @WasherId = O.WasherId FROM @OutputList O

--insert in MachineSetup
INSERT [TCD].MachineSetup (
WasherId ,GroupId ,MachineInternalId ,EcoalabAccountNumber ,MachineName ,IsTunnel ,ControllerId , IsDeleted ,LastModifiedByUserId,IsPony )
SELECT @WasherId     AS   WasherId
, @WasherGroupId    AS   GroupId
, @LFSWasherNumber   AS   MachineInternalId
, @EcoLabAccountNumber  AS   EcoalabAccountNumber
, @ConventionalName   AS   MachineName
,@IsDeleted      AS   IsTunnel
, @ControllerId    AS   ControllerId
, 'FALSE'      AS   IsDeleted
, @UserId      AS   LastModifiedByUserId
,@IsPony As IsPony



 IF(ISNULL( @NewWasherGroupId,0)>0 AND (@WasherGroupId != @NewWasherGroupId))
 BEGIN
    UPDATE tcd.machinesetup 
    SET GroupId = @NewWasherGroupId
    WHERE WasherId = @WasherId
     
   EXEC TCD.SaveInjectionDetails @WasherGroupId,@NewWasherGroupId,@ControllerId,@WasherId,@EcolabAccountNumber
 END
 ELSE
 BEGIN
   EXEC TCD.SaveInjectionDetails @WasherGroupId,@WasherGroupId,@ControllerId,@WasherId,@EcolabAccountNumber
 END

SET @ErrorId = @@ERROR

IF (@ErrorId <> 0)
BEGIN
IF @@TRANCOUNT > 0
BEGIN
ROLLBACK TRAN
END

SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred assoicating new record for conventional.'
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END
ELSE
BEGIN
IF @@TRANCOUNT > 0
BEGIN
COMMIT
END

--SET the output param to be communicated back...

SELECT TOP 1
@OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp
, @ConventionalWasherId    = O.WasherId
FROM @OutputList       O

END




IF ( @ErrorId = 0 )
BEGIN
		IF (@ControllerModelId = 7)
			BEGIN
				UPDATE TCD.WasherGroup SET ControllerId = @ControllerId WHERE WasherGroupId = @WasherGroupId
			END
RETURN (@ReturnValue)
END



--ErrorHandler:
--RAISERROR (@ErrorMessage, 16, 1)
--SET @ReturnValue = -1


--ExitModule:

--RETURN (@ReturnValue)

--SET NOCOUNT OFF

END
Go

IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[GetWasherList]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[GetWasherList] 
END 
GO 

/*	
Purpose					:	To populate the grid in the Washer setup --> Washers listing

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version

*/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE	PROCEDURE    [TCD].[GetWasherList] -- '040242802', 4,2
     @EcoLabAccountNumber     NVARCHAR(1000)

    , @WasherGroupId       INT   =   NULL
    , @WasherId        INT   =   NULL
    , @Is_Deleted        bit   =   'FALSE'
AS
BEGIN

SET NOCOUNT ON


SELECT --*
  W.PlantWasherNumber    AS   WasherNumber
 , MS.MachineName     AS   WasherName
 , CASE MS.IsTunnel
   WHEN 'TRUE' THEN 'Tunnel'
   WHEN 'FALSE' THEN 'WasherExtractor'
  END        AS   WasherType
 , MS.IsTunnel      AS   WasherTypeFlag
 , WMS.WasherModelName    AS   WasherModel
 , WMS.WasherModelId    AS   WasherModelId
 , WMS.WasherSize     AS   WasherSize
 , CASE WHEN CC.ControllerId = 0 THEN '' ELSE CC.Name END AS   WasherControllerName
 , W.WasherId      AS   WasherId
 , WG.WasherGroupId    AS   WasherGroupId
 , WG.WasherGroupName    AS   WasherGroupName
 , CC.ControllerId     AS   WasherControllerId

 , W.[Description]     AS   WasherDescription
 , W.MaxLoad      AS   WashermaxLoad

 , W.WasherMode     AS   WasherModeId

 , W.AWEActive      AS   WasherAWEActive
 , MS.NumberOfComp     AS   WasherNumberOfCompartments

 , CAST(W.NumberOfTanks AS SMALLINT)
          AS   WasherNumberOfTanks
 , CAST(W.PressExtractor AS SMALLINT)
          AS   WasherPressExtractorId
 , CAST(W.TransferType  AS SMALLINT)
          AS   WasherTransferTypeId
 , CASE MS.IsTunnel WHEN 1 THEN CAST(W.EmptyPocketNumber AS SMALLINT) ELSE CAST(W.EndOfFormula AS SMALLINT) END AS WasherProgramNumber

 -- Columns for conventionals
 , W.HoldSignal     AS   HoldDelay
 , CAST(W.HoldDelay AS INT)  AS   HoldSignal
 , CAST(W.TargetTurnTime AS INT) AS   TargetTurnTime
 , CAST(W.WaterFlushTime AS INT) AS   WaterFlushTime
 , MS.MachineInternalId   AS   LFSWasherNumber

    --    Cols. for integration with Synch./Central
    ,    W.LastModifiedTime                AS            LastModifiedTime
    ,    W.LastSyncTime                    AS            LastSyncTime
    ,    W.Is_Deleted                    AS            Is_Deleted
    ,    W.EcoLabAccountNumber            AS            EcolabAccountNumber
    ,    (SELECT Count(*) FROM tcd.TunnelProgramSetup wps WHERE wps.WasherGroupId=@WasherGroupId AND wps.Is_Deleted=0) AS FormulaCount
    ,    GT.MyServiceCustMchGrpGuid
    ,    W.MyServiceCustMchGuid
    ,    WMS.MyServiceMCHId
    ,    TPE.Name                        AS            PressExtractorName
    ,    TTT.Name                        AS            TransferTypeName
    ,   W.RatioDosingActive                AS            RatioDosingActive
    ,    W.EcolabWasherId                AS            EcolabWasherNumber
    ,    CAST(W.EndOfFormula AS SMALLINT)     AS            EndOfFormula
    ,    W.MyServiceLastSynchTime             AS            MyServiceLastSynchTime
    ,    CC.ControllerTypeId                 AS            ControllerTypeId
    ,    CT.Name                         AS            ControllerType
    ,    CC.ControllerModelId             AS            ControllerModelId
    ,    CM.Name                         AS            ControllerModel
    ,    W.NumberOfCompartmentsConveyorBelt
    ,    W.MinMachineLoad
    ,    W.MaxMachineLoad
    ,    W.ProgramSelectionByTime
    ,    W.WeightSelectionByTime
    ,    W.WeightSelectionByAnalogInput
    ,    W.TunInTomMode
    ,    COALESCE(W.SignalStopTunActive,'TRUE')        AS          SignalStopTunActive
    ,    COALESCE(W.SignalEjectionTunActive,'TRUE')    AS          SignalEjectionTunActive
    ,    W.DelayTimeForTunWashingPrograms
    ,    W.KannegiesserPressSpecialMode
    ,    W.ValveOutputsUsedAsTomSignal
    ,    W.ExtendedClockOrDataProtocol
    ,    W.WeightCorrectionFcc
    ,    W.FlowSwitchNumber            
    ,    W.WasherStopExternalSignal    
    ,    COALESCE(W.OnHoldWESignalActive,'TRUE')         AS           OnHoldWESignalActive        
    ,    W.WasherOnHoldSignalDelay    
    ,    W.WEInTOMMode                
    ,    W.ManifoldFlushTime            
    ,    W.L1                        
    ,    W.L2                        
    ,    W.L3                        
    ,    W.L4                        
    ,    W.L5                        
    ,    W.L6                        
    ,    W.L7                        
    ,    W.L8                        
    ,    W.L9                        
    ,    W.L10                        
    ,    W.L11                        
    ,    W.L12
    ,   MS.IsPony AS IsPony
    ,    W.PlantId
    ,    W.UseMe1OfGroup
    ,    W.UseMe2OfGroup
    ,    W.UsePumpOfGroup
    ,    W.WasherStopUseFinalExtracting
    ,    W.TemperatureAlarmYesNo
    ,    W.PhProbe
    ,    w.WeightCell
    ,    W.Temperature
    ,    W.WaterCounter    
    ,    W.DateAndTimeWhenBatchEjects            
    ,    W.AutoRinseDesamixAfter            
    ,    W.AutoRinseDesamix1For
    ,    W.AutoRinseDesamix2For
    ,    W.TemperatureAlarmProbe1
    ,    W.TemperatureAlarmProbe2
    ,    W.TemperatureAlarmProbe3
	,   CAST(W.DefaultIdleTime AS INT) AS   DefaultIdleTime 

FROM    [TCD].WasherGroup                    WG
JOIN    [TCD].MachineGroup                    GT
    ON    WG.WasherGroupId                =            GT.Id
    AND    WG.EcolabAccountNumber            =            GT.EcolabAccountNumber
JOIN    [TCD].MachineSetup                    MS
    ON    WG.WasherGroupId                =            MS.GroupId
    AND    WG.EcolabAccountNumber            =            MS.EcoalabAccountNumber
JOIN    [TCD].Washer                        W
    ON    MS.WasherId                        =            W.WasherId
    AND    MS.EcoalabAccountNumber            =            W.EcoLabAccountNumber
JOIN    [TCD].WasherModelSize                WMS
    ON    W.ModelId                        =            WMS.WasherModelId
JOIN    [TCD].ConduitController                CC
    ON    MS.ControllerId                    =            CC.ControllerId
    AND    MS.EcoalabAccountNumber            =            CC.EcoalabAccountNumber
LEFT JOIN TCD.ControllerType CT  ON CT.Id = CC.ControllerTypeId  
LEFT JOIN TCD.ControllerModel CM ON CM.Id = CC.ControllerModelId
LEFT JOIN    [TCD].TunnelPressExtractor            TPE
    ON    W.PressExtractor                =            TPE.TunnelPressExtractorId        
LEFT JOIN    [TCD].TunnelTransferType            TTT
    ON    W.TransferType                    =            TTT.TunnelTransferTypeId
WHERE    GT.EcolabAccountNumber            =            @EcoLabAccountNumber
    AND    GT.GroupTypeId                       =            2
 
 AND (GT.Is_Deleted     =   'FALSE' OR GT.Is_Deleted = @Is_Deleted)
 AND WG.WasherGroupId    =   ISNULL(@WasherGroupId, WG.WasherGroupId)
 AND WG.EcolabAccountNumber   =   @EcoLabAccountNumber
 AND MS.EcoalabAccountNumber   =   @EcoLabAccountNumber
 AND (MS.IsDeleted     =   'FALSE' OR MS.IsDeleted = @Is_Deleted)
 AND (W.Is_Deleted     =   'FALSE' OR W.Is_Deleted = @Is_Deleted)
 AND W.WasherId      =   ISNULL(@WasherId, W.WasherId)
 AND W.EcoLabAccountNumber   =   @EcoLabAccountNumber




SET NOCOUNT OFF

END
Go

IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[UpdateConventional]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[UpdateConventional] 
END 
GO 


/*	
Purpose					:	To update Conventional Washer details from the Washer setup UI - General tab

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version

--sp_helptext	usp_UpdateConventional

*/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE	PROCEDURE	[TCD].[UpdateConventional]
					@EcoLabAccountNumber					NVARCHAR(1000)
				,	@WasherId								INT
				,	@WasherGroupId							INT
				, @NewWasherGroupId							int		=	null
				,	@ConventionalName						NVARCHAR(50)
				,	@ModelId								INT						--(Washer)Model Id for Size
				,	@ControllerId							INT
				,	@LFSWasherNumber						TINYINT
				,	@PlantWasherNumber						SMALLINT
				,	@WasherMode								TINYINT
				,	@MaxLoad								SMALLINT
				,	@AWEActive								BIT
				,	@HoldSignal								BIT
				,	@HoldDelay								SMALLINT															
				,	@TargetTurnTime							SMALLINT
				,	@WaterFlushTime							SMALLINT
				,	@ProgramNumber							TINYINT					--EOF number
				,	@Description							NVARCHAR(1024)	=			NULL
				,	@UserId									INT
				,	@LastModifiedTimestampAtCentral			DATETIME				=	NULL
				,	@OutputLastModifiedTimestampAtLocal		DATETIME				=	NULL	OUTPUT
				,	@RatioDosingActive						BIT			
				,	@IsPony BIT  
				,	@MinMachineLoad							SMALLINT				=	NULL
				,	@MaxMachineLoad							smallint				=	NULL
				,	@ProgramSelectionByTime					bit						=	NULL
				,	@FlowSwitchNumber						int						=	NULL
				,	@WasherStopExternalSignal				bit						=	NULL
				,	@OnHoldWESignalActive					bit						=	NULL
				,	@WasherOnHoldSignalDelay				int						=	NULL
				,	@ValveOutputsUsedAsTomSignal			bit						=	NULL
				,	@WeInTomMode							bit						=	NULL
				,	@ManifoldFlushTime						int						=	NULL
				,	@L1										bit						=	NULL
				,	@L2										bit						=	NULL
				,	@L3										bit						=	NULL
				,	@L4										bit						=	NULL
				,	@L5										bit						=	NULL
				,	@L6										bit						=	NULL
				,	@L7										bit						=	NULL
				,	@L8										bit						=	NULL
				,	@L9										bit						=	NULL
				,	@L10									bit						=	NULL
				,	@L11									bit						=	NULL
				,	@L12									bit						=	NULL
				,	@UseMe1OfGroup							tinyint					=	NULL
				,	@UseMe2OfGroup							tinyint					=	NULL
				,	@UsePumpOfGroup							tinyint					=	NULL
				,	@WasherStopUseFinalExtracting			bit						=	NULL
				,	@TemperatureAlarmYesNo					bit						=	NULL
				, @DefaultIdleTime							INT						=   NULL
AS
BEGIN

SET NOCOUNT ON


DECLARE 
  @ReturnValue     INT    =   0
 , @ErrorId      INT    =   0
 , @ErrorMessage     NVARCHAR(4000) =   N''
 , @CurrentUTCTime     DATETIME  =   GETUTCDATE()
 , @PlantId		INT			=	NULL
 , @ControllerModelId INT = NULL

DECLARE
   @OutputList      AS TABLE  (
   LastModifiedTimestamp   DATETIME
  )

SET  @OutputLastModifiedTimestampAtLocal    =   ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)   --SQLEnlight
SELECT  @PlantId = PlantId From TCD.Plant WHERE EcolabAccountNumber = @EcoLabAccountNumber
SELECT @ControllerModelId = cmctm.ControllerModelId 
FROM TCD.ControllerModelControllerTypeMapping cmctm 
INNER JOIN TCD.ConduitController cc 
	ON cc.ControllerModelId = cmctm.ControllerModelId
WHERE cc.ControllerId = @ControllerId AND cc.EcoalabAccountNumber = @EcoLabAccountNumber

--Valid Washer-Id check...
IF NOT EXISTS ( SELECT 1
     FROM [TCD].Washer      W
     JOIN [TCD].MachineSetup    MS
      ON W.WasherId     =   MS.WasherId
      AND W.EcoLabAccountNumber  =   MS.EcoalabAccountNumber
     WHERE W.EcoLabAccountNumber  =   @EcoLabAccountNumber
      AND W.WasherId     =   @WasherId
      AND MS.GroupId     =   @WasherGroupId
      AND W.Is_Deleted    =   'FALSE'
      AND MS.IsDeleted    =   'FALSE'
    )
   BEGIN
    SET  @ErrorId      =   51006
    SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Washer-ID was provided for Updating.'
    --GOTO ErrorHandler
    RAISERROR (@ErrorMessage, 16, 1)
    SET  @ReturnValue = -1
    RETURN (@ReturnValue)
   END

--Check for uniqueness of PlantWasherNo. and Name
IF EXISTS  ( SELECT 1
     FROM [TCD].Washer      W
     JOIN [TCD].MachineSetup    MS
      ON W.WasherId     =   MS.WasherId
      AND W.EcoLabAccountNumber  =   MS.EcoalabAccountNumber
     WHERE W.EcoLabAccountNumber  =   @EcoLabAccountNumber
      AND W.WasherId     <>   @WasherId AND W.PlantWasherNumber   =   @PlantWasherNumber
      AND (
       W.PlantWasherNumber   =   @PlantWasherNumber       
       OR
       MS.MachineName    =   @ConventionalName
       )
      AND W.Is_Deleted    =   'FALSE'
      AND MS.IsDeleted    =   'FALSE'
    )
   BEGIN
    SET  @ErrorId      =   51002
    SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Specified Plant Washer #/ already exists.'
    --GOTO ErrorHandler
    RAISERROR (@ErrorMessage, 16, 1)
    SET  @ReturnValue = -1
    RETURN (@ReturnValue)
   END

IF @ControllerId > 0
BEGIN
--Check Max LFSWasher No.
IF NOT EXISTS ( SELECT 1
     FROM [TCD].ControllerModelControllerTypeMapping
              CMCTM
     JOIN [TCD].ConduitController   CC
      ON CC.ControllerTypeId   =   CMCTM.ControllerTypeId
      AND CC.ControllerModelId  =   CMCTM.ControllerModelId
     WHERE CC.EcoalabAccountNumber  =   @EcoLabAccountNumber
      AND CC.ControllerId    =   @ControllerId
      AND CC.IsDeleted    =   'FALSE'
      AND CMCTM.MaximumWasherExtractorCount
              >=   @LFSWasherNumber
    )
   BEGIN
    SET  @ErrorId      =   51003
    SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller/LFSWasher# was provided.'
    --GOTO ErrorHandler
    RAISERROR (@ErrorMessage, 16, 1)
    SET  @ReturnValue = -1
    RETURN (@ReturnValue)
   END
END
--EOF should not be an asocciated formula for the WG...
IF EXISTS  ( SELECT 1
     FROM [TCD].WasherProgramSetup   WPS
     WHERE WPS.EcolabAccountNumber  =   @EcoLabAccountNumber
      AND WPS.WasherGroupId   =   @WasherGroupId
      AND WPS.ProgramNumber   =   @ProgramNumber
      AND WPS.Is_Deleted    =   'FALSE'
    )
   BEGIN
    SET  @ErrorId      =   51004
    SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An assoicated formula cannot be specified as End-Of-Formula.'
    --GOTO ErrorHandler
    RAISERROR (@ErrorMessage, 16, 1)
    SET  @ReturnValue = -1
    RETURN (@ReturnValue)
   END

IF @ControllerId > 0
BEGIN
--WasherMode check
IF NOT EXISTS ( SELECT 1
     FROM [TCD].ControllerModelControllerTypeMapping
              CMCTM
					JOIN	[TCD].ConduitController			CC
						ON	CC.ControllerTypeId			=			CMCTM.ControllerTypeId
						AND	CC.ControllerModelId		=			CMCTM.ControllerModelId
					JOIN	[TCD].[WasherModeMapping]
              CTM2WM
      ON CMCTM.Id     =   CTM2WM.ControllerModelControllerTypeMappingId
     WHERE CC.EcoalabAccountNumber  =   @EcoLabAccountNumber
      AND CC.ControllerId    =   @ControllerId
      AND CC.IsDeleted    =   'FALSE'
      AND CTM2WM.WasherModeId   =   @WasherMode
    )
   BEGIN
    SET  @ErrorId      =   51005
    SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherMode was provided.'
    --GOTO ErrorHandler
    RAISERROR (@ErrorMessage, 16, 1)
    SET  @ReturnValue = -1
    RETURN (@ReturnValue)
   END

--LFSWasherNumber duplicate check...
IF	EXISTS	(	SELECT	1
				FROM	[TCD].MachineSetup					MS
				WHERE	MS.ControllerId					=			@ControllerId
					AND	MS.MachineInternalId			=			@LFSWasherNumber
					AND	MS.IsDeleted					=			'FALSE'
					AND	MS.WasherId						<>			@WasherId
					AND MS.EcoalabAccountNumber			=			@EcoLabAccountNumber
					AND MS.IsTunnel						=			'FALSE'
   )
   BEGIN
    SET  @ErrorId      =   51010
    SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate LFSWasher# provided.'
    --GOTO ErrorHandler
    RAISERROR (@ErrorMessage, 16, 1)
    SET  @ReturnValue = -1
    RETURN (@ReturnValue)
   END
END

IF (
   @LastModifiedTimestampAtCentral    IS NOT NULL
   AND
   NOT EXISTS ( SELECT 1
     FROM TCD.Washer  W
     WHERE W.EcolabAccountNumber = @EcolabAccountNumber
      AND W.WasherId    = @WasherId
      AND W.LastModifiedTime  = @LastModifiedTimestampAtCentral
    )
 )
  BEGIN
    SET   @ErrorId    = 60000
    SET   @ErrorMessage   = N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
    RAISERROR (@ErrorMessage, 16, 1)
    SET   @ReturnValue   = -1
    RETURN  (@ReturnValue)
  END


--Now attempt Update...
BEGIN TRAN

UPDATE MS
 SET MS.MachineName     =   @ConventionalName
 , MS.ControllerId     =   @ControllerId
 , MS.MachineInternalId   =   @LFSWasherNumber
 , MS.LastModifiedByUserId   =   @UserId
 ,MS.IsPony = @IsPony
FROM [TCD].MachineSetup     MS
JOIN [TCD].Washer       W
 ON MS.WasherId      =   W.WasherId
 AND MS.EcoalabAccountNumber   =   W.EcolabAccountNumber
WHERE MS.WasherId      =   @WasherId
 AND MS.EcoalabAccountNumber   =   @EcoLabAccountNumber
 AND MS.IsDeleted     =   'FALSE'
 AND W.Is_Deleted     =   'FALSE'

--check for any error
SET @ErrorId = @@ERROR

IF (@ErrorId <> 0)
BEGIN

  IF @@TRANCOUNT > 0
  BEGIN
   ROLLBACK TRAN
  END
 
  SET  @ErrorMessage    =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating washer data.'
  --GOTO ErrorHandler
  RAISERROR (@ErrorMessage, 16, 1)
  SET  @ReturnValue = -1
  RETURN (@ReturnValue)
END

--else, continue with the rest of the update in the other table...
UPDATE	W
	SET	W.ModelId						=			@ModelId
	,	W.PlantWasherNumber				=			@PlantWasherNumber
	,	W.WasherMode					=			@WasherMode
	,	W.MaxLoad						=			@MaxLoad
	,	W.AWEActive						=			@AWEActive
	,	W.HoldSignal					=			@HoldSignal
	,	W.HoldDelay						=			@HoldDelay
	,	W.TargetTurnTime				=			@TargetTurnTime
	,	W.WaterFlushTime				=			@WaterFlushTime
	,	W.EndOfFormula					=			@ProgramNumber
	,	W.[Description]					=			@Description
	,	W.LastModifiedByUserId			=			@UserId
	,	W.LastModifiedTime				=			@CurrentUTCTime
	,   W.RatioDosingActive				=			@RatioDosingActive
	,	W.MinMachineLoad				=			@MinMachineLoad				
	,	W.MaxMachineLoad				=			@MaxMachineLoad				
	,	W.ProgramSelectionByTime		=			@ProgramSelectionByTime		
	,	W.FlowSwitchNumber				=			@FlowSwitchNumber			
	,	W.WasherStopExternalSignal		=			@WasherStopExternalSignal	
	,	W.OnHoldWESignalActive			=			@OnHoldWESignalActive		
	,	W.WasherOnHoldSignalDelay		=			@WasherOnHoldSignalDelay	
	,	W.ValveOutputsUsedAsTomSignal	=			@ValveOutputsUsedAsTomSignal
	,	W.WEInTOMMode					=			@WeInTomMode				
	,	W.ManifoldFlushTime				=			@ManifoldFlushTime			
	,	W.L1							=			@L1
	,	W.L2							=			@L2
	,	W.L3							=			@L3
	,	W.L4							=			@L4
	,	W.L5							=			@L5
	,	W.L6							=			@L6
	,	W.L7							=			@L7
	,	W.L8							=			@L8
	,	W.L9							=			@L9
	,	W.L10							=			@L10
	,	W.L11							=			@L11
	,	W.L12							=			@L12
	,	W.UseMe1OfGroup					=			@UseMe1OfGroup
	,	W.UseMe2OfGroup					=			@UseMe2OfGroup
	,	W.UsePumpOfGroup				=			@UsePumpOfGroup
	,	W.WasherStopUseFinalExtracting	=			@WasherStopUseFinalExtracting
	,	W.TemperatureAlarmYesNo			=			@TemperatureAlarmYesNo
	,	W.PlantId						=			@PlantId
	,   W.DefaultIdleTime               =           @DefaultIdleTime

OUTPUT
 inserted.LastModifiedTime  AS   LastModifiedTimestamp
INTO
 @OutputList (
 LastModifiedTimestamp
)
FROM [TCD].Washer      W
JOIN [TCD].MachineSetup     MS
 ON W.WasherId      =   MS.WasherId
 AND W.EcoLabAccountNumber   =   MS.EcoalabAccountNumber
WHERE W.WasherId      =   @WasherId
 AND W.EcoLabAccountNumber   =   @EcoLabAccountNumber
 AND W.Is_Deleted     =   'FALSE'
 AND MS.IsDeleted     =   'FALSE'


 IF(@NewWasherGroupId IS NOT NULL AND (@WasherGroupId != @NewWasherGroupId))
 BEGIN
    UPDATE tcd.machinesetup 
    SET GroupId = @NewWasherGroupId
    WHERE WasherId = @WasherId
     
   EXEC TCD.SaveInjectionDetails @WasherGroupId,@NewWasherGroupId,@ControllerId,@WasherId,@EcolabAccountNumber
 END
 ELSE
 BEGIN
   EXEC TCD.SaveInjectionDetails @WasherGroupId,@WasherGroupId,@ControllerId,@WasherId,@EcolabAccountNumber
 END

--check for error, if none - commit the tran, else rollback
SET @ErrorId = @@ERROR
IF (@ErrorId <> 0)
 BEGIN
  IF (@@TRANCOUNT > 0)
   BEGIN
    ROLLBACK
   END

  SET  @ErrorMessage    =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating washer data.'
  --GOTO ErrorHandler
  RAISERROR (@ErrorMessage, 16, 1)
  SET  @ReturnValue = -1
  RETURN (@ReturnValue)
 END
ELSE
 BEGIN
  IF (@@TRANCOUNT > 0)
   BEGIN
				IF (@ControllerModelId = 7)
				BEGIN
					UPDATE TCD.WasherGroup SET ControllerId = @ControllerId WHERE WasherGroupId = @WasherGroupId
				END
    COMMIT
   END
   
   SELECT TOP 1 @OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp FROM @OutputList O
 END


SET NOCOUNT OFF
RETURN (@ReturnValue)


END
Go

IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[GetManualProductionDetails]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[GetManualProductionDetails] 
END 
GO 

/*                                            
###################################################################################################                                                   
        
Stored Procedure:       [dbo].[usp_GetManualProductionDetails]                                                   
        
Purpose:    To get the manual production details.        
        
Parameters:    @WasherGroupId - holds the washer group id.        
      @WasherId - holds the washer id.        
      @FormulaId - holds the formula id.        
      @EcoLabAccountNumber - holds the ecolab account number.        
                        
###################################################################################################                                                   
*/      
/*
-- Usage
EXEC [TCD].[GetManualProductionDetails] '3'
,1, 1,'040000361','2015-10-01', 50, 1    


*/  
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[GetManualProductionDetails]        
 (        
 @WasherGroupId NVARCHAR(1000),         
 @WasherId INT,        
 @FormulaId INT,        
 @EcolabAccountNumber nvarchar(25)    ,
 @RecordedDate DATETIME
   , @RowsPerPage INT =50
  , @PageNumber INT = 1     
 )        
AS         
  BEGIN         
     SET NOCOUNT ON
	  IF @PageNumber < 1 
	   SET @PageNumber = 1 
	            
    if(@FormulaId = 0)      
    BEGIN      
    set @FormulaId = null      
    END      
   SELECT       
      MP.ProductionId,       
      MP.FormulaId,      
      MP.RecordedDate,         
      MP.Value    ,    
      PM.Name,
	  Count(*) Over() TotalRows    
    FROM  [TCD].ManualProduction  AS MP    
  JOIN [TCD].[ProgramMaster]  AS PM ON MP.FormulaId = PM.ProgramId    
   WHERE         
      MP.WasherGroupId IN( SELECT cast(items as int) FROM [TCD].[CharacterListToTable](@WasherGroupId,','))      
      AND MP.WasherId = @WasherId         
      AND MP.FormulaId = COALESCE(@FormulaId,  FormulaId)       
      AND MP.EcolabAccountNumber = @EcolabAccountNumber      
      AND MP.RecordedDate >= @RecordedDate
      AND MP.IsDeleted <> 1        
   ORDER BY ProductionId DESC
   
   OFFSET (@PageNumber-1)*@RowsPerPage ROWS
   FETCH NEXT @RowsPerPage ROWS ONLY         
  SET NOCOUNT OFF        
  END      
    
Go	

IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[SaveProductionShiftManualLabourRollup]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[SaveProductionShiftManualLabourRollup] 
END 
GO 
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[SaveProductionShiftManualLabourRollup](
--DECLARE
												@FromDate datetime = NULL,--'2015-05-13',
												@Todate datetime = NULL,-- '2015-05-13',
												@LabourType int = NULL,-- 1,
												@ManualHours int = NULL-- 100 							
																				
												
											 )
AS
SET NOCOUNT ON
BEGIN

    DECLARE 
		  @ShiftId Int = NULL,   		  
		  @BatchUTCStart DATETIME= NULL,
		  @BatchUTCEnd DATETIME= NULL,
		  @ShiftTargetProd Decimal(18,2) = NULL,
		  @ShiftCount Int = 1,
		  @validateShiftName varchar(100)

    DECLARE @ProductionShiftLaborData TABLE
				 (
					[ShiftId] [int] NULL,
					[LaborType] [int] NULL,
					[LaborHours] [int] NULL,
					[LaborCost] [decimal](18, 2) 
				)
	   
    DECLARE @BatchShiftTable TABLE
						(
						  RowNumber int IDENTITY(1,1),
						  BatchUTCStartDate datetime,
						  BatchUTCEndDate datetime,
						  ShiftId int,
						  ShiftName varchar(100)
						)

    IF(@FromDate = @Todate)
    BEGIN
     INSERT INTO @BatchShiftTable
	 (
	    BatchUTCStartDate,
	    BatchUTCEndDate,
	    ShiftId,
	    ShiftName
	 )
	 SELECT 
		  DISTINCT
			StartDateTime,
			EndDateTime,
			sd.ShiftID,
			ShiftName		   
					FROM [TCD].ProductionShiftData SD WITH (NOLOCK) 
						 WHERE CAST(SD.StartDateTime AS date) = CAST( DATEADD(hh, DATEDIFF(hh, GETDATE(), GETUTCDATE()), @FromDate) AS date)  AND SD.ShiftName <> 'No Shift'
					   ORDER BY SD.ShiftId
    END
    ELSE
    BEGIN  		  
	 INSERT INTO @BatchShiftTable
	 (
	    BatchUTCStartDate,
	    BatchUTCEndDate,
	    ShiftId,
	    ShiftName
	 )
	 SELECT 
		  DISTINCT
			StartDateTime,
			EndDateTime,
			sd.ShiftID,
			ShiftName		   
					FROM [TCD].ProductionShiftData SD WITH (NOLOCK) 
						 WHERE CAST(SD.StartDateTime AS date) >= CAST( DATEADD(hh, DATEDIFF(hh, GETDATE(), GETUTCDATE()), @FromDate) AS date)
						 AND CAST(sd.StartDateTime AS date) <= CAST( DATEADD(hh, DATEDIFF(hh, GETDATE(), GETUTCDATE()), @Todate) as date) AND SD.ShiftName <> 'No Shift'
					   ORDER BY SD.ShiftId
	END




	  --SELECT bst.* FROM @BatchShiftTable bst

    DECLARE @ManualInputData TABLE
			 (
				ManualHours int,
				LabourType int
			)
			 INSERT @ManualInputData
			 (
			     ManualHours,
				LabourType
			)
			
			 SELECT @ManualHours/NULLIF((SELECT COUNT(1) FROM @BatchShiftTable bst WHERE bst.ShiftName <> 'No Shift'),0),
				   @LabourType
				   
			   
   			--SELECT mid.* FROM @ManualInputData mid
	   ------------------******// Inserting the Data into Batch Summary Temp table based on UTC shift timings //******-----------------------
    WHILE (@ShiftCount <= (SELECT COUNT(1) FROM @BatchShiftTable bst))
    BEGIN

    SELECT  @BatchUTCStart = 
				    bst.BatchUTCStartDate,
			   @BatchUTCEnd = 
				    bst.BatchUTCEndDate,
			   @ShiftId = bst.ShiftId,
			   @validateShiftName = bst.ShiftName
				FROM @BatchShiftTable bst WHERE bst.RowNumber = @ShiftCount
    
    INSERT INTO @ProductionShiftLaborData
		  (
			 [ShiftId],
			 [LaborType],
			 [LaborHours],
			 [LaborCost]
			 )
    SELECT 
		   [ShiftId],
			 [LaborType],
			 [LaborHours],
			 [LaborCost] FROM TCD.ProductionShiftLaborData spdr WHERE spdr.ShiftId = @ShiftId
	  
	    --------------------------******// Inserting the Data into production Shift Rollup Data Table //******-------------------
	      		  
		 DELETE FROM [TCD].ProductionShiftLaborData WHERE ShiftId = @ShiftId 
		 
			 INSERT INTO [TCD].ProductionShiftLaborData
								  (
								    [ShiftId],
								    [LaborType],
								    [LaborHours],
								    [LaborCost]
								  )

			 SELECT 
				    
				    [ShiftId],
				    [LaborType],
				    [LaborHours] + ISNULL((SELECT mid.ManualHours FROM @ManualInputData mid WHERE mid.LabourType = spdr.LaborType),0),
				    [LaborCost] + ISNULL((SELECT mid.ManualHours * lc.Cost FROM @ManualInputData mid INNER JOIN TCD.LaborCost lc ON mid.LabourType = lc.LaborTypeId
				     WHERE mid.LabourType = spdr.LaborType),0)		 
						  FROM @ProductionShiftLaborData spdr
				
		  IF(@validateShiftName <> 'No Shift')
		  BEGIN
		  IF NOT EXISTS(SELECT DISTINCT * FROM TCD.ProductionShiftLaborData spdr WHERE spdr.ShiftId = @ShiftId
																   AND spdr.LaborType IN (SELECT mid.LabourType FROM @ManualInputData mid)
																   )
				BEGIN
				   INSERT INTO [TCD].ProductionShiftLaborData
								 (
								    [ShiftId],
								    [LaborType],
								    [LaborHours],
								    [LaborCost]
								  )


				SELECT TOP 1 
					   @ShiftId
					  ,(SELECT mid.LabourType FROM @ManualInputData mid)
					  ,(SELECT mid.ManualHours FROM @ManualInputData mid)
					  ,(SELECT mid.ManualHours * lc.Cost FROM @ManualInputData mid INNER JOIN TCD.LaborCost lc ON mid.LabourType = lc.LaborTypeId)
					  		-- FROM TCD.ShiftProductionDataRollup spdr WHERE spdr.ShiftId = @ShiftId
								
		    
				END
			END
	  	   DELETE FROM @ProductionShiftLaborData		 
		  SET @ShiftCount = @ShiftCount + 1
	    END	   
	  
END

GO

IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[UpdateProductionShiftManualLabourRollup]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[UpdateProductionShiftManualLabourRollup] 
END 
GO 
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[UpdateProductionShiftManualLabourRollup](
--DECLARE
												@FromDate datetime = NULL,--'2015-05-13',
												@Todate datetime = NULL,--'2015-05-13',
												@LabourType int = NULL,--1,
												@ManualHours int = NULL---50  --1000									
																				
												
											 )
AS
SET NOCOUNT ON
BEGIN

    DECLARE 
		  @ShiftId Int = NULL,   		  
		  @BatchUTCStart DATETIME= NULL,
		  @BatchUTCEnd DATETIME= NULL,
		  @ShiftTargetProd Decimal(18,2) = NULL,
		  @ShiftCount Int = 1,
		  @validateShiftName varchar(100)

    DECLARE @ProductionShiftLaborData TABLE
				 (
					[ShiftId] [int] NULL,
					[LaborType] [int] NULL,
					[LaborHours] [int] NULL,
					[LaborCost] [decimal](18, 2) 
				)
	   
    DECLARE @BatchShiftTable TABLE
						(
						  RowNumber int IDENTITY(1,1),
						  BatchUTCStartDate datetime,
						  BatchUTCEndDate datetime,
						  ShiftId int,
						  ShiftName varchar(100)
						)
  		  
	 IF(@FromDate = @Todate)
    BEGIN
     INSERT INTO @BatchShiftTable
	 (
	    BatchUTCStartDate,
	    BatchUTCEndDate,
	    ShiftId,
	    ShiftName
	 )
	 SELECT 
		  DISTINCT
			StartDateTime,
			EndDateTime,
			sd.ShiftID,
			ShiftName		   
					FROM [TCD].ProductionShiftData SD WITH (NOLOCK) 
						 WHERE CAST(SD.StartDateTime AS date) = CAST( DATEADD(hh, DATEDIFF(hh, GETDATE(), GETUTCDATE()), @FromDate) AS date)  AND SD.ShiftName <> 'No Shift'
					   ORDER BY SD.ShiftId
    END
    ELSE
    BEGIN  		  
	 INSERT INTO @BatchShiftTable
	 (
	    BatchUTCStartDate,
	    BatchUTCEndDate,
	    ShiftId,
	    ShiftName
	 )
	 SELECT 
		  DISTINCT
			StartDateTime,
			EndDateTime,
			sd.ShiftID,
			ShiftName		   
					FROM [TCD].ProductionShiftData SD WITH (NOLOCK) 
						 WHERE CAST(SD.StartDateTime AS date) >= CAST( DATEADD(hh, DATEDIFF(hh, GETDATE(), GETUTCDATE()), @FromDate) AS date)
						 AND CAST(sd.StartDateTime AS date) <= CAST( DATEADD(hh, DATEDIFF(hh, GETDATE(), GETUTCDATE()), @Todate) as date) AND SD.ShiftName <> 'No Shift'
					   ORDER BY SD.ShiftId
	END


    DECLARE @ManualInputData TABLE
			 (
				ManualHours int,
				LabourType int
			)
			 INSERT @ManualInputData
			 (
			     ManualHours,
				LabourType
			)
			
			 SELECT @ManualHours/NULLIF((SELECT COUNT(1) FROM @BatchShiftTable bst WHERE bst.ShiftName <> 'No Shift'),0),
				   @LabourType
				   
		
			
	   ------------------******// Inserting the Data into Batch Summary Temp table based on UTC shift timings //******-----------------------
    WHILE (@ShiftCount <= (SELECT COUNT(1) FROM @BatchShiftTable bst))
    BEGIN

    SELECT  @BatchUTCStart = 
				    bst.BatchUTCStartDate,
			   @BatchUTCEnd = 
				    bst.BatchUTCEndDate,
			   @ShiftId = bst.ShiftId,
			   @validateShiftName = bst.ShiftName
				FROM @BatchShiftTable bst WHERE bst.RowNumber = @ShiftCount
    
    INSERT INTO @ProductionShiftLaborData
		  (
			 [ShiftId],
			 [LaborType],
			 [LaborHours],
			 [LaborCost]
			 )
    SELECT 
		   [ShiftId],
			 [LaborType],
			 [LaborHours],
			 [LaborCost] FROM TCD.ProductionShiftLaborData spdr WHERE spdr.ShiftId = @ShiftId

    UPDATE spdr
    SET
        [LaborHours] = [LaborHours] + ISNULL((SELECT mid.ManualHours FROM @ManualInputData mid WHERE mid.LabourType = spdr.LaborType),0),
	   [LaborCost] = [LaborCost] + ISNULL((SELECT mid.ManualHours * lc.Cost FROM @ManualInputData mid INNER JOIN TCD.LaborCost lc ON mid.LabourType = lc.LaborTypeId WHERE mid.LabourType = spdr.LaborType),0)
	   FROM @ProductionShiftLaborData spdr

	  
	    --------------------------******// Inserting the Data into production Shift Rollup Data Table //******-------------------
	      		  
		 DELETE FROM [TCD].ProductionShiftLaborData WHERE ShiftId = @ShiftId 
		 
			 INSERT INTO [TCD].ProductionShiftLaborData
								  (
								    [ShiftId],
								    [LaborType],
								    [LaborHours],
								    [LaborCost]
								  )

			 SELECT 
				    
				    [ShiftId],
				    [LaborType],
				    [LaborHours], 
				    [LaborCost] 
						  FROM @ProductionShiftLaborData spdr
				
		
	  	   DELETE FROM @ProductionShiftLaborData		 
		  SET @ShiftCount = @ShiftCount + 1
	    END	   
	  
END
GO

IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[UpdateControllerSetupAdvanceData]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[UpdateControllerSetupAdvanceData] 
END 
GO 
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[UpdateControllerSetupAdvanceData] 

(

  @ControllerSetupData XML
 , @UserId INT
 , @LastModifiedTimestampAtCentral   DATETIME = NULL
 , @OutputLastModifiedTimestampAtLocal  DATETIME = NULL OUTPUT

)

AS

BEGIN

      SET NOCOUNT ON

  DECLARE 
   @ControllerId     INT     = NULL
   ,  @EcolabAccountNumber   VARCHAR(1000)  = NULL
   ,  @LFSInjectionClasses nvarchar(50) = NULL
   ,  @ErrorId      INT     = 0
   ,  @ErrorMessage     VARCHAR(200)  = NULL
   ,  @CurrentUTCTime     DATETIME   = GETUTCDATE()


  DECLARE
   @OutputList      AS TABLE  (
   LastModifiedTimestamp   DATETIME
  )

  DECLARE @TempDynamic TABLE

        (
 
    EcolabAccountNumber   VARCHAR(1000)   

     , ControllerId    INT

           , ControllerModelId   INT

           , FieldGroupId    INT

           , FieldId      INT

           , Value      VARCHAR(1000)

     , FieldTagValue    VARCHAR(1000)

        )

 SET @OutputLastModifiedTimestampAtLocal   =   ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)   --SQLEnlight SA0121

 SELECT @EcolabAccountNumber = Tbl.col.value('@EcolabAccountNumber', 'varchar(1000)')

     FROM   @ControllerSetupData.nodes('/ControllerSetupData/DynamicSetupData/Data') AS Tbl (col)

 SELECT @ControllerId =  tbl.col.value('@ControllerId', 'int')
     FROM   @ControllerSetupData.nodes('/ControllerSetupData/DynamicSetupData/Data') AS Tbl (col) 

	 
 SELECT @LFSInjectionClasses = Tbl.col.value('@Value', 'int')
     FROM   @ControllerSetupData.nodes('/ControllerSetupData/DynamicSetupData/Data') AS Tbl (col) 
	 WHERE  Tbl.col.value('@FieldId', 'int') IN (219, 220, 221,222,223,224) 


 IF (
         @LastModifiedTimestampAtCentral    IS NOT NULL
         AND
         NOT EXISTS ( SELECT 1
           FROM TCD.ConduitController  CC
           WHERE CC.EcoalabAccountNumber  = @EcolabAccountNumber
            AND CC.ControllerId    = @ControllerId
            AND CC.LastModifiedTime   = @LastModifiedTimestampAtCentral
          )
    )
   BEGIN
     SET   @ErrorId    = 60000
     SET   @ErrorMessage   = N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
     RAISERROR (@ErrorMessage, 16, 1)
     RETURN
   END
   

 BEGIN TRANSACTION

  BEGIN TRY

   INSERT INTO @TempDynamic

      (

       EcolabAccountNumber
      
      , ControllerId

      , ControllerModelId

      , FieldGroupId

      , FieldId

      , Value

      , FieldTagValue
      )

   SELECT 

     @EcolabAccountNumber

    , @ControllerId

    , Tbl.col.value('@ControllerModelId', 'int')

    , Tbl.col.value('@FieldGroupId', 'int')

    , Tbl.col.value('@FieldId', 'int')

    , Tbl.col.value('@Value', 'varchar(1000)')

    , Tbl.col.value('@FieldTagValue','varchar(1000)')

   FROM   @ControllerSetupData.nodes('/ControllerSetupData/DynamicSetupData/Data') AS Tbl (col)

   
   UPDATE [TCD].ControllerSetupData 
   SET 
    Value = td.Value
    
   , FieldTagValue=td.FieldTagValue

   , LastModifiedByUserId = @UserId

   FROM 

   [TCD].ControllerSetupData CSD

   INNER JOIN @TempDynamic td 

   ON 

   td.ControllerId = CSD.ControllerId

   AND 

   td.FieldGroupId = CSD.FieldGroupId

   AND

   td.FieldId = CSD.FieldId

   AND

   td.ControllerModelId = CSD.ControllerModelId

   AND

   td.EcolabAccountNumber = CSD.EcolabAccountNumber
 
   UPDATE TCD.ConduitController
   SET
   
   LFSInjectionClasses = (Select TOP 1 [Value] from @TempDynamic where FieldTagValue='TAG_MIC'),
    
   LastModifiedTime = @CurrentUTCTime
   OUTPUT
    inserted.LastModifiedTime  AS   LastModifiedTimestamp
   INTO
    @OutputList (
    LastModifiedTimestamp
   )
   WHERE 
   ControllerId = @ControllerId
   AND
   EcoalabAccountNumber = @EcolabAccountNumber

   COMMIT TRANSACTION

  END TRY

  BEGIN CATCH

   SELECT 

    ERROR_NUMBER() AS ErrorNumber,

    ERROR_SEVERITY() AS ErrorSeverity,

    ERROR_STATE() AS ErrorState,

    ERROR_PROCEDURE() AS ErrorProcedure,

    ERROR_LINE() AS ErrorLine,

    ERROR_MESSAGE() AS ErrorMessage



   ROLLBACK TRANSACTION

  END CATCH

SET NOCOUNT OFF

END

GO

UPDATE TCD.LanguageMaster SET TCD.LanguageMaster.IsActive = 1
GO


IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[ReportProductionDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.ReportProductionDetails
	END
GO 
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ReportProductionDetails] 
/******************************************************************
DESCRIPTION		: 


MODIFICATION HISTORY DETAILS:	
	21st Jan 2015 -  Kiran     -  Added Formula hierarchy -->Formula segment-->Formula category-->formula


REFERENC TABLES :
		Select * from TCD.Plant --Plant master
		Select * FROM TCD.PlantChain  --Master Plants
		Select * FROM TCD.PlantChainProgram
		Select * FROM TCD.ChainTextileCategory
		Select * FROM TCD.ProgramMaster
		Select * FROM TCD.EcolabTextileCategory  --Masters
		Select * FROM TCD.EcolabSaturation --Masters
		Select * FROM TCD.FormulaSegments --Masters

EXECUTION STATEMENT :

	EXEC [TCD].[ReportProductionDetails1] @startdate = '2015-01-11',@enddate = '2016-01-30',@Viewtype  = '7',@Subview = '',
										@Drillvalue = '',@EcolabAccountNumber = '040242802',@MachineType = '', @MachineGroup  = '',@Machine  = '', 
										@EcolabCategory  = '',@ChainCategory  = '', @PlantFormula  = '', @ChainFormula = '', @Customer  = '',
										@SortColumnId  = 0,@SortDirection  = '',@CurrencyCode = '', @UserId = 1, @FormulaSegement ='',
										@FormulaCategory='',@Formula=''


*******************************************************************/

     @startdate datetime = '',
     @enddate datetime = '',
     @Viewtype Int = '',
     @Subview Int= '',
     @Drillvalue varchar(100)= '',
     @EcolabAccountNumber Nvarchar(25) = '',
     @MachineType VARCHAR(20)= '',
     @MachineGroup VARCHAR(MAX) = '',
     @Machine VARCHAR(MAX) = '',
     @EcolabCategory VARCHAR(MAX) = '',
     @ChainCategory VARCHAR(MAX) = '',
     @PlantFormula  VARCHAR(MAX) = '',
     @ChainFormula VARCHAR(MAX) = '',
     @Customer VARCHAR(MAX) = '',
     @SortColumnId int = 0,
     @SortDirection varchar(4) = '',
     @CurrencyCode varchar(3) = '',
     @UserId INT = NULL,
	 @FormulaSegement VARCHAR(MAX)='', --Formula segment,
	 @FormulaCategory VARCHAR(MAX)='', --Formula category
	 @Formula VARCHAR(MAX)='' --Formula
AS   
BEGIN   
SET NOCOUNT ON 
	SET @startdate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@startdate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@startdate AS time)) AS DateTime))
	SET @EndDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndDate AS time)) AS DateTime))

	
	DECLARE @ReportGenerated INT = 6, @Month INT = MONTH(GETDATE()),@CorrectionVariable Decimal(18,2),@PlantTargetProduction decimal(18,2)
      --,@ShiftRuntime int,@NoShiftTotalRuntime INT,@TotaRuntime int

	/* Inserting the record into Report History */
	INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)
	SELECT @EcolabAccountNumber,UM.UserId,UM.LoginName,GETUTCDATE(),@ReportGenerated,
	CASE WHEN @ReportGenerated = 6
		THEN 'Generated Report : Production Details Report' END
	FROM TCD.UserMaster UM
	WHERE UM.EcolabAccountNumber = @EcolabAccountNumber AND UM.UserId = @UserId

    /* Completed the record insertion into Report History */ 

    -- Return Table set
    DECLARE @resultSet Table
    (
      ShiftId Int,
      DateRange varchar(100),
      TotalLoad Decimal(18,2) ,
      WasherEfficiency Decimal(18,2),
      PlantTargetLoad Decimal(18,2) ,
      StandardLoad Decimal(18,2) ,
      Numberofbatches INT,
      [ActualRunTime] [int] NULL,
      [TargetRunTime] [int] NULL,
      NumberofPieces  [int] NULL,
      Rewash [int] NULL,
      Viewtype varchar(100) NULL,
      Subview varchar(100) NULL,
      Id int NULL      
    )

    DECLARE @CorrectionFactor TABLE 
   (
    [ShiftId] [int] NULL,
    MachineId INT NULL,
    [ActualProduction] [int] NULL,
    [StandardProduction] [int] NULL,
    [PlantTargetProd] [int] NULL,
    [ActualRunTime] [int] NULL,
    [TargetRunTime] [int] NULL,
	ManualInputWeight INT,
	ManulainputsNoofloads INT
   )
    
	--Machine type
	DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))
	INSERT INTO @MachineTypeTable EXEC [TCD].[CharlistToTable] @MachineType,','

	--washer Group
	DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))
	INSERT INTO @WasherGroupTable EXEC [TCD].[CharlistToTable] @machineGroup,','  

	--Machine list
	DECLARE @MachineTable TABLE(Machine Varchar(100))
	INSERT INTO @MachineTable EXEC [TCD].[CharlistToTable] @Machine,','

	--Ecolab category
	DECLARE @EcolabCategoryTable TABLE(EcolabCategory Varchar(100))
	INSERT INTO @EcolabCategoryTable EXEC [TCD].[CharlistToTable] @EcolabCategory,','

	--Chain category
	DECLARE @ChainCategoryTable TABLE(ChainCategory Varchar(100))
	INSERT INTO @ChainCategoryTable EXEC [TCD].[CharlistToTable] @ChainCategory,','

	--Plant formula
	DECLARE @PlantFormulaTable TABLE(PlantFormula Varchar(100))
	INSERT INTO @PlantFormulaTable EXEC [TCD].[CharlistToTable] @PlantFormula,','

	--Chain Formula
	DECLARE @ChainFormulaTable TABLE(ChainFormula Varchar(100))
	INSERT INTO @ChainFormulaTable EXEC [TCD].[CharlistToTable] @ChainFormula,','

	--Customer Table
	DECLARE @CustomerTable TABLE(Customer Varchar(100))
	INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','

	--Formula Segment --added by Kiran
	DECLARE @FormulaSegmentTable TABLE(FormulaSegment Varchar(1000))
    INSERT INTO @FormulaSegmentTable EXEC [TCD].[CharlistToTable] @FormulaSegement,','

	-----Formula category--------Start
	DECLARE @FormulaCategoryTable TABLE(FormulaCategory Varchar(1000),Type CHAR(1))
    INSERT INTO @FormulaCategoryTable(FormulaCategory) EXEC [TCD].[CharlistToTable] @Formulacategory,','
	
	--segregating Ecolab/Chain categories
	--UPDATE @FormulaCategoryTable SET TYPE=RIGHT(FormulaCategory,1),FormulaCategory=LEFT(FormulaCategory,LEN(FormulaCategory)-2)

	--Below 1000 Ecolab category
	UPDATE @FormulaCategoryTable SET TYPE='E' WHERE FormulaCategory<1000
	--Above 1000 consider as Chain category
	UPDATE @FormulaCategoryTable SET TYPE='C' WHERE FormulaCategory>=1000

	--Rollbacking to actual ID
	UPDATE @FormulaCategoryTable SET FormulaCategory=FormulaCategory-1000 WHERE TYPE='C'
	--SELECT * FROM @FormulaCategoryTable

	INSERT INTO @EcolabCategoryTable(EcolabCategory)
	SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='E'	

	INSERT INTO @ChainCategoryTable(ChainCategory)
	SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='C'

	--Value Assigning
	IF (EXISTS(SELECT * FROM @EcolabCategoryTable) AND @FormulaCategory!='')
	BEGIN
		SET @EcolabCategory=@FormulaCategory
	END
	IF (EXISTS(SELECT * FROM @ChainCategoryTable) AND @FormulaCategory!='')
	BEGIN
		SET @ChainCategory=@FormulaCategory
	END
	---Formula category-------------------------End

	-----Formula Ecolab/Chain categories
	DECLARE @FormulaTable TABLE(Formula Varchar(1000),Type CHAR(1))
    INSERT INTO @FormulaTable(Formula) EXEC [TCD].[CharlistToTable] @Formula,','

	--segregating Ecolab/Chain categories
	--UPDATE @FormulaTable SET TYPE=RIGHT(Formula,1),Formula=LEFT(Formula,LEN(Formula)-2)
	/*
	--Below 1000 Ecolab category
	UPDATE @FormulaTable SET TYPE='E' WHERE Formula<1000
	--Above 1000 consider as Chain category
	UPDATE @FormulaTable SET TYPE='C' WHERE Formula>=1000

	--Rollbacking to actual ID
	UPDATE @FormulaTable SET Formula=Formula-1000 WHERE TYPE='C'
	*/
	--Select * from @FormulaTable
	--Plant fomula   
    INSERT INTO @PlantFormulaTable(PlantFormula) 
	SELECT Formula FROM @FormulaTable --WHERE Type='E'
	--chain formula   
    INSERT INTO @ChainFormulaTable(ChainFormula) 
	SELECT Formula FROM @FormulaTable --WHERE Type='C'
	--SELECT * FROM @PlantFormulaTable
	--SELECT * FROM @ChainFormulaTable

	--Value Assigning
	IF (EXISTS(SELECT * FROM @PlantFormulaTable) AND @Formula!='')
	BEGIN
		SET @PlantFormula=@Formula
	END
	IF (EXISTS(SELECT * FROM @ChainFormulaTable) AND @Formula!='')
	BEGIN
		SET @ChainFormula=@Formula
	END
	--SELECT @PlantFormula,@ChainFormula
	-----Formula Segregation end

	--Insert Into @CorrectionFactor table
	INSERT INTO @CorrectionFactor
	(
		[ShiftId],
		[MachineId] ,
		[ActualProduction] ,
		[StandardProduction] ,
		[PlantTargetProd] ,
		[ActualRunTime] ,
		[TargetRunTime],
		ManualInputWeight,
		ManulainputsNoofloads		 
	)
	SELECT 
		PS.[ShiftId],
		SPD.[MachineId],
		ISNULL([TCD].[FnConsumptionOnMetrics](SUM(ISNULL(SPD.[ActualProduction],0))+SUM(ISNULL(MIP.ActualWeight,0)),'Weight',@UserId),0),
		--ISNULL([TCD].[FnConsumptionOnMetrics](SUM(ISNULL(SPD.[ActualProduction],0)),'Weight',@UserId),0),		
		--SUM(SPD.[ActualProduction]),
		ISNULL([TCD].[FnConsumptionOnMetrics](SUM(ISNULL(SPD.StandardProduction,0)),'Weight',@UserId),0),
		--SUM(SPD.StandardProduction),
		ISNULL([TCD].[FnConsumptionOnMetrics](SUM(DISTINCT ISNULL(SPD.[PlantTargetProd],0)),'Weight',@UserId),0),
		--SUM(DISTINCT SPD.[PlantTargetProd]),
		SUM(ISNULL(SPD.[ActualRunTime],0) + ISNULL(SPD.ActualTurnTime,0)),
		SUM(ISNULL(SPD.[TargetRunTime],0) + ISNULL(SPD.TargetTurnTime,0)),
		SUM(ISNULL(MIP.ActualWeight,0)),SUM(ISNULL(MIP.NoofLoads,0))
	FROM  TCD.ShiftProductionDataRollup SPD 
	INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId
	LEFT OUTER JOIN --Manual Production Details appending
		(
			SELECT WasherId,FormulaId,CONVERT(DATE,RecordedDate) AS LoadDate,SUM(ISNULL(Value,0)) AS ActualWeight,
			ISNULL(COUNT(CONVERT(DATE,RecordedDate)),0) AS NoofLoads FROM
			TCD.ManualProduction MP
			GROUP BY WasherId,FormulaId,CONVERT(DATE,RecordedDate)
		)MIP ON MIP.WasherId=SPD.EcolabWasherId AND MIP.FormulaId=SPD.ProgramMasterId AND MIP.LoadDate=CONVERT(DATE,PS.StartDateTime)
	WHERE 
		CASE @StartDate                                                                                
		WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
		ELSE CASE WHEN PS.[StartDateTime] >= @startdate  AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
		END='TRUE' 
	GROUP BY MachineId,PS.ShiftId;

	WITH CTE (PlantTargetProd) AS
	(
	SELECT SUM(DISTINCT SPD.[PlantTargetProd]) FROM @CorrectionFactor SPD GROUP BY ShiftId
	)
	SELECT @PlantTargetProduction = SUM(PlantTargetProd) FROM CTE;

	WITH CTE (MachineId,PlantEfficiency)
	AS
	(
	SELECT 
		MachineId,
		CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
			NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
			COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2))   
		 FROM @CorrectionFactor SPD GROUP BY MachineId
	)
    SELECT @CorrectionVariable = @PlantTargetProduction/NULLIF(SUM(PlantEfficiency),0) FROM CTE


	--  SELECT  @ShiftRuntime = SUM(A.ShiftTime)
	--   FROM
	--   (
	--  SELECT  SUM( DISTINCT DATEDIFF(Second,psd.StartDateTime,PSd.EndDateTime)) AS ShiftTime FROM TCD.ShiftProductionDataRollup spdr 
	--      INNER JOIN TCD.ProductionShiftData psd ON psd.ShiftId = spdr.ShiftId
	--   WHERE 
	-- CASE @StartDate                                                                                
	-- WHEN '' THEN Case WHEN MONTH(CAST(psd.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
	-- ELSE CASE WHEN psd.[StartDateTime] >= @startdate AND psd.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
	-- END='TRUE'
	-- AND psd.ShiftName <> 'No Shift'
	--  GROUP BY spdr.ShiftId
	--   ) A

	-- SELECT
	--@NoShiftTotalRuntime = SUM(SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0))
	--   FROM TCD.ShiftProductionDataRollup SPD INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId
	--  WHERE 
	--     CASE @StartDate                                                                                
	--     WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
	--     ELSE CASE WHEN PS.[StartDateTime] >= @startdate AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
	--     END='TRUE'
	-- AND PS.ShiftName = 'No Shift'

	--  SELECT @TotaRuntime = ISNULL(@ShiftRuntime,0) + ISNULL(@NoShiftTotalRuntime,0)

	DECLARE @ProductionSummaryTable TABLE
	(
		[ShiftId] [int] NULL,
		[ShiftName] Varchar(100) NULL,
		RecordDate date, 
		[MachineId] [int] NULL,
		[ProgramMasterId] [int] NULL,
		[EcolabWasherId] [int] NULL,
		[ActualProduction] [int] NULL,
		[StandardProduction] [int] NULL,
		[NoOfLoads] [int] NULL,
		[LoadEfficiency] [decimal](18, 2) NULL,
		[TimeEfficiency] [decimal](18, 2) NULL,
		TotalEfficiency [decimal](18, 2) NULL,
		[PlantTargetProd] [int] NULL,
		[ActualRunTime] [int] NULL,
		[TargetRunTime] [int] NULL,
		EcolabTextileId int,
		ChainTextileId int,
		ChainProgaramId int,
		CustomerId int,
		NoOfPieces int,
		Rewash Int,
		[ShiftRunTime] [int] NULL,
		FormulaSegmentID INT,
		RowNumberID INT
	)

    INSERT INTO @ProductionSummaryTable
    SELECT 
        PS.[ShiftId],
        PS.ShiftName,
        CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date),
        --CAST(PS.[StartDateTime] AS date),
        SPD.[MachineId],
        SPD.[ProgramMasterId],
        SPD.[EcolabWasherId],
        ISNULL(SPD.[ActualProduction],0),
        ISNULL(SPD.StandardProduction,0),
        ISNULL(SPD.[NoOfLoads],0),
        ISNULL(SPD.[LoadEfficiency],0),
        ISNULL(SPD.[TimeEfficiency],0),
        (ISNULL(SPD.[LoadEfficiency],0) * ISNULL(SPD.TimeEfficiency,0)),
        ISNULL(SPD.[PlantTargetProd],0),
        ISNULL(SPD.[ActualRunTime],0) + ISNULL(SPD.ActualTurnTime,0),
        ISNULL(SPD.[TargetRunTime],0) + ISNULL(SPD.TargetTurnTime,0),
        SPD.EcolabTextileId,
		SPD.ChainTextileId,
        SPD.ChainProgaramId,
        SPD.CustomerId,
        ISNULL(SPD.NoOfPieces,0),
        CAST((
			SELECT spdr.ActualProduction FROM TCD.ShiftProductionDataRollup spdr WHERE spdr.ShiftId = SPD.ShiftId AND spdr.MachineId = SPD.MachineId
			AND spdr.ProgramMasterId = SPD.ProgramMasterId AND spdr.ProgramMasterId IN (SELECT pm.ProgramId FROM TCD.ProgramMaster pm WHERE pm.Rewash = 1)
			) AS decimal(18,2)),
		DATEDIFF(Second,ps.StartDateTime,PS.EndDateTime) +
			ISNULL(
					(
					SELECT
					SUM(SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0))
					FROM TCD.ShiftProductionDataRollup SPD INNER JOIN TCD.ProductionShiftData PSD ON SPD.ShiftId = PSD.ShiftId
					WHERE PSD.[StartDateTime] = PS.StartDateTime AND PSD.[StartDateTime] = PS.EndDateTime AND PS.ShiftName = 'No Shift'
					) ,0),
		CASE WHEN SPD.ChainProgaramId IS NOT NULL THEN ChainPlant.FormulaSegmentId
		ELSE FS1.FormulaSegmentID END AS Formulasegment,

		ROW_NUMBER() OVER(Partition BY SPD.ProgramMasterId, SPD.[EcolabWasherId], CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date)
		 ORDER BY SPD.ProgramMasterId, SPD.[EcolabWasherId] )

        --CAST(((SELECT SUM(MR.VALUE) FROM TCD.ManualRewash MR WHERE SPD.ProgramMasterId = MR.FormulaId AND CAST(PS.StartDateTime AS date) = CAST(MR.RecordedDate AS date) GROUP BY CAST(MR.RecordedDate AS date),MR.FormulaId)) AS decimal(18,2))
	FROM  TCD.ShiftProductionDataRollup SPD 
	INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId
	INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId 
	INNER JOIN TCD.MachineSetup ms ON SPD.MachineId = ms.WasherId
	LEFT OUTER JOIN
		 (
			--IF Chain Plant
			SELECT PCP.PlantProgramId,PCP.PlantChainId,PCP.ChainTextileCategoryId,PCP.EcolabTextileCategoryId,
			PCP.FormulaSegmentId,PCP.EcolabSaturationId
			FROM TCD.PlantChainProgram PCP 
			LEFT OUTER JOIN TCD.ChainTextileCategory CTC ON CTC.TextileId=PCP.ChainTextileCategoryId
			LEFT OUTER JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId=PCP.EcolabTextileCategoryId
			LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=PCP.FormulaSegmentId
			LEFT OUTER JOIN TCD.EcolabSaturation ES ON ES.EcolabSaturationId=PCP.EcolabSaturationId
		 )ChainPlant ON SPD.ChainProgaramId=ChainPlant.PlantProgramId

	LEFT OUTER JOIN TCD.EcolabTextileCategory ETC1 ON ETC1.TextileId=PM.EcolabTextileCategoryId
	LEFT OUTER JOIN TCD.FormulaSegments FS1 ON FS1.FormulaSegmentID=PM.FormulaSegmentId
	LEFT OUTER JOIN TCD.EcolabSaturation ES1 ON ES1.EcolabSaturationId=PM.EcolabSaturationId
	
    WHERE isNull(ms.IsPony,0) = 0
    AND 
       CASE @StartDate                                                                                
       WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
       ELSE CASE WHEN PS.[StartDateTime] >= @startdate  AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
       END='TRUE'

     AND
       CASE @MachineType   
       WHEN '' THEN 'TRUE'         
       ELSE                                                      
       CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
       MS.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable))) THEN 'TRUE' END                                                      
       END='TRUE' 
    
    AND       

    CASE @machineGroup   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
    MS.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable)) THEN 'TRUE' END                                                      
    END='TRUE' 
    AND

    CASE @Machine   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
    END='TRUE' 
    AND
    
    CASE @EcolabCategory   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.EcolabTextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                      
    END='TRUE' 
     AND
    
    CASE @ChainCategory   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.ChainTextileId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END                                                      
    END='TRUE'
    AND

    CASE @PlantFormula   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                      
    END='TRUE'  
    AND
    
    CASE @ChainFormula   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.ProgramMasterId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END                                                      
    END='TRUE'
    AND
    
    CASE @Customer   
    WHEN '' THEN 'TRUE'         
       ELSE                                                      
       CASE WHEN SPD.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                      
    END='TRUE'
	--Added by Kiran	
    AND 
		CASE @FormulaSegement                                                                                
		WHEN '' THEN  'TRUE'
		ELSE
			CASE WHEN SPD.ChainProgaramId  IS NOT NULL THEN
				CASE WHEN ChainPlant.FormulaSegmentId IN (SELECT FormulaSegment FROM @FormulaSegmentTable) THEN 'TRUE' END						                                                                               
			ELSE 
				CASE WHEN FS1.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)  THEN 'TRUE'END   
			END                                                     
		END='TRUE'
	 -----ENd

	 /*
	SELECT S.ActualProduction AS Actual,MIP.ManualIPActualWeight AS Manual, 
	ISNULL(S.ActualProduction,0)+ISNULL(MIP.ManualIPActualWeight,0),
	S.NoOfLoads AS Actualloads,MIP.NoofLoads AS Manualloads,
	ISNULL(S.NoOfLoads,0)+ISNULL(MIP.NoofLoads,0)
	FROM  @ProductionSummaryTable S
	INNER JOIN 
		(
		SELECT WasherId,FormulaId,CONVERT(DATE,RecordedDate) AS LoadDate,SUM(Value) AS ManualIPActualWeight,
		COUNT(CONVERT(DATE,RecordedDate)) AS NoofLoads FROM
		TCD.ManualProduction MP
		GROUP BY WasherId,FormulaId,CONVERT(DATE,RecordedDate)
		)MIP ON MIP.WasherId=S.EcolabWasherId AND MIP.FormulaId=S.ProgramMasterId AND MIP.LoadDate=S.RecordDate
		WHERE S.RowNumberID=1
	*/

	--For top 1 record combination updating the manual input data.
	UPDATE S SET ActualProduction=ISNULL(S.ActualProduction,0)+ISNULL(MIP.ManualIPActualWeight,0),S.NoOfLoads=ISNULL(S.NoOfLoads,0)+ISNULL(MIP.NoofLoads,0)
	FROM  @ProductionSummaryTable S
	INNER JOIN 
		(
		SELECT WasherId,FormulaId,CONVERT(DATE,RecordedDate) AS LoadDate,SUM(Value) AS ManualIPActualWeight,
		COUNT(CONVERT(DATE,RecordedDate)) AS NoofLoads FROM
		TCD.ManualProduction MP
		GROUP BY WasherId,FormulaId,CONVERT(DATE,RecordedDate)
		)MIP ON MIP.WasherId=S.MachineId AND MIP.FormulaId=S.ProgramMasterId AND MIP.LoadDate=S.RecordDate
		WHERE S.RowNumberID=1

	--SELECT * FROM @ProductionSummaryTable


	IF(@Viewtype = 3)
	BEGIN
		IF(@Subview = 12)
		BEGIN
			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,TextileId)
				AS
				(
			  SELECT 
				EC.CategoryName,
				SUM(SPD.ActualProduction),
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
				SUM(DISTINCT SPD.PlantTargetProd),
				SUM(SPD.StandardProduction),
				SUM([NoOfLoads]),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(SPD.NoOfPieces),
				SUM(SPD.Rewash),
				EC.TextileId
				  FROM @ProductionSummaryTable SPD LEFT JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
				WHERE EC.CategoryName IS NOT NULL
				GROUP BY 
			   EC.CategoryName,EC.TextileId,SPD.ShiftId
			   )
			   INSERT INTO @resultSet
			   SELECT DISTINCT
				0,
				DateRange,
				SUM(TotalLoad),
				SUM(WasherEfficiency),
				SUM(PlantTargetLoad),
				SUM(StandardLoad),
				SUM(Numberofbatches),
				SUM(ActualRunTime),
				SUM(TargetRuntime),
				SUM(NumberofPieces),
				SUM(Rewash)
				,@Viewtype 
				,@Subview
				,TextileId
				FROM CTE
				WHERE TotalLoad IS NOT NULL
				GROUP BY DateRange,TextileId   
	    END
		IF(@Subview = 17)
		BEGIN
			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
			AS
			(
			SELECT 
   
			PM.Name,
			SUM(SPD.ActualProduction),
			COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
			SUM(DISTINCT SPD.PlantTargetProd),
			SUM(SPD.StandardProduction),
			SUM([NoOfLoads]),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(SPD.NoOfPieces),
			SUM(SPD.Rewash)
			   FROM @ProductionSummaryTable SPD INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
				 INNER JOIN TCD.ProgramMaster PM ON EC.TextileId = PM.EcolabTextileCategoryId AND SPD.ProgramMasterId = PM.ProgramId    
			WHERE
				(
				CASE    
				 WHEN @drillvalue='' THEN 'TRUE' 
				 WHEN @drillvalue IS NULL THEN 'TRUE'  
				 ELSE                                                    
				  CASE WHEN EC.TextileId IN (@drillvalue) THEN 'TRUE' END            
				 END='TRUE'
				) AND PM.NAME IS NOT NULL
			GROUP BY 
			   PM.Name,SPD.ShiftId
		   )
			INSERT INTO @resultSet
		   SELECT DISTINCT
			0,
			   DateRange,
			   SUM(TotalLoad),
			   SUM(WasherEfficiency),
			   SUM(PlantTargetLoad),
			   SUM(StandardLoad),
			   SUM(Numberofbatches),
			   SUM(ActualRunTime),
			   SUM(TargetRuntime),
			   SUM(NumberofPieces),
			   SUM(Rewash)
			   ,@Viewtype 
			   ,@Subview
				,0
				   FROM CTE
					WHERE TotalLoad IS NOT NULL
					GROUP BY DateRange
		END

	END

    -- ************************ By Textile Category View ************************************************
	IF(@Viewtype = 4)
	BEGIN 
		IF(@Subview = 15)
		BEGIN
			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
				AS
				(
			 SELECT    
				CC.Name,
				SUM(SPD.ActualProduction),
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
				SUM(DISTINCT SPD.PlantTargetProd),
				SUM(SPD.StandardProduction),
				SUM([NoOfLoads]),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(SPD.NoOfPieces),
				SUM(SPD.Rewash)
				FROM @ProductionSummaryTable SPD LEFT JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
				WHERE CC.Name IS NOT NULL 
			 GROUP BY 
			   CC.Name,CC.TextileId,SPD.ShiftId
			   )
				INSERT INTO @resultSet
			   SELECT DISTINCT
				0,
				   DateRange,
				   SUM(TotalLoad),
				   SUM(WasherEfficiency),
				   SUM(PlantTargetLoad),
				   SUM(StandardLoad),
				   SUM(Numberofbatches),
				   SUM(ActualRunTime),
				   SUM(TargetRuntime),
				   SUM(NumberofPieces),
				   SUM(Rewash)
				   ,@Viewtype 
				   ,@Subview
					,0
					FROM CTE
					WHERE TotalLoad IS NOT NULL
					GROUP BY DateRange
        END  
		IF(@Subview = 18)
		BEGIN
			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
				AS
				(
			 SELECT        
				PM.Name,
				SUM(SPD.ActualProduction),
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
				SUM(DISTINCT SPD.PlantTargetProd),
				SUM(SPD.StandardProduction),
				SUM([NoOfLoads]),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(SPD.NoOfPieces),
				SUM(SPD.Rewash)
				   FROM @ProductionSummaryTable SPD INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
					 INNER JOIN TCD.ProgramMaster PM ON CC.TextileId = PM.ChainTextileId AND SPD.ProgramMasterId = PM.ProgramId
    
			WHERE
				(
				CASE    
				 WHEN @drillvalue='' THEN 'TRUE' 
				 WHEN @drillvalue IS NULL THEN 'TRUE'  
				 ELSE                                                    
				  CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END            
				 END='TRUE'
				)
			GROUP BY 
			   PM.Name,SPD.ShiftId
			   )
				INSERT INTO @resultSet
			   SELECT DISTINCT
				0,
				   DateRange,
				   SUM(TotalLoad),
				   SUM(WasherEfficiency),
				   SUM(PlantTargetLoad),
				   SUM(StandardLoad),
				   SUM(Numberofbatches),
				   SUM(ActualRunTime),
				   SUM(TargetRuntime),
				   SUM(NumberofPieces),
				   SUM(Rewash)
				   ,@Viewtype 
				   ,@Subview
					,0
					   FROM CTE
						WHERE TotalLoad IS NOT NULL
						GROUP BY DateRange
		END
	END

  -- ******************************** Timeline View ***************************************************
	IF(@Viewtype = 1)
	BEGIN
		---- By TimeLine - Day View
	   IF(@Subview = 5)
		BEGIN 
			INSERT INTO @resultSet
			SELECT DISTINCT
			0,
			SPD.ShiftName,
			SUM(SPD.ActualProduction),
			COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
			SUM(DISTINCT SPD.PlantTargetProd),
			SUM(SPD.StandardProduction),
			SUM([NoOfLoads]),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(SPD.NoOfPieces),
			SUM(SPD.Rewash)
			,@Viewtype 
			,@Subview
			,0
			 FROM @ProductionSummaryTable SPD
			GROUP BY 
			SPD.ShiftName
		END

       ---- By TimeLine - Week View
	   IF (@Subview = 4)
	   BEGIN
			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
			AS
			(
			SELECT 
			   CAST(RecordDate AS nvarchar(100)),
				SUM(SPD.ActualProduction),
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
				SUM(DISTINCT SPD.PlantTargetProd),
				SUM(SPD.StandardProduction),
				SUM([NoOfLoads]),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(SPD.NoOfPieces),
				SUM(SPD.Rewash)
			  FROM @ProductionSummaryTable SPD
				GROUP BY DATEPART(weekday,RecordDate),RecordDate,SPD.ShiftId

			)
		   INSERT INTO @resultSet
		   SELECT DISTINCT
			   0,
			   DateRange,
			  SUM(TotalLoad),
			  SUM(WasherEfficiency),
			   SUM(PlantTargetLoad),
			   SUM(StandardLoad),
			   SUM(Numberofbatches),
			   SUM(ActualRunTime),
			   SUM(TargetRuntime),
			   SUM(NumberofPieces),
			   SUM(Rewash)
			   ,@Viewtype 
			   ,@Subview
				,0
				   FROM CTE
					WHERE TotalLoad IS NOT NULL
					GROUP BY DateRange
	   END
		---- By TimeLine - Month View
	   IF(@Subview = 3)
	   BEGIN
			DECLARE @FirstDay date = (SELECT TOP 1 RecordDate FROM @ProductionSummaryTable ORDER BY RecordDate)
			DECLARE @LastDay date = (SELECT TOP 1 RecordDate FROM @ProductionSummaryTable ORDER BY RecordDate DESC)
			DECLARE @FirstSunday date = NULL,
			@LastSaturday date = NULL

    
			SELECT 
			@FirstSunday = CAST(DateAdd(dd, (8-DatePart(WEEKDAY, 
			DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)))%7, 
			DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)) AS DATE) 

			SELECT
			@LastSaturday = 
			DATEADD(dd,
				-DATEPART(WEEKDAY,
					DATEADD(dd, -DAY(DATEADD(month, 1, @LastDay)),
					DATEADD(month, 1, @LastDay))) ,
				DATEADD(dd, -DAY(DATEADD(MONTH, 1, @LastDay)), DATEADD(MONTH, 1, @LastDay)));

			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
			AS
			(
			SELECT 
       
			CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,-1,@FirstSunday)) = 7 
			AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate < DATEADD(DD,-1,@FirstSunday)) = 0)
			THEN CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100))
			WHEN DATEADD(DD,-1,@FirstSunday) > CAST(GETDATE() AS DATE) 
			THEN
			CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @enddate, 101) AS nvarchar(100))
			ELSE
			CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) END As DateRange,
			SUM(SPD.ActualProduction),
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
				SUM(DISTINCT SPD.PlantTargetProd),
				SUM(SPD.StandardProduction),
				SUM([NoOfLoads]),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(SPD.NoOfPieces),
				SUM(SPD.Rewash)

				FROM @ProductionSummaryTable SPD
			WHERE RecordDate < @FirstSunday AND RecordDate >= @FirstDay
			GROUP BY SPD.ShiftId

        
			UNION ALL

  
			SELECT
        
			--CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100)) AS StartDate,
			--CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) AS EndDate,
				CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100))  + CHAR(13) + '-' +
				CASE WHEN CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) >
				CAST(Convert(varchar, DateAdd(dd, (1 - DatePart(dw, @enddate) + 1), @enddate), 101) AS nvarchar(100))
				THEN  CAST(Convert(varchar, DateAdd(dd, 1-1, @enddate), 101) AS nvarchar(100))
				ELSE CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) END
				As DateRange,
				SUM(SPD.ActualProduction),
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
				SUM(DISTINCT SPD.PlantTargetProd),
				SUM(SPD.StandardProduction),
				SUM([NoOfLoads]),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(SPD.NoOfPieces),
				SUM(SPD.Rewash)
			FROM @ProductionSummaryTable SPD
				WHERE RecordDate BETWEEN @FirstSunday AND @LastSaturday
			GROUP BY Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101),
				Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101),SPD.ShiftId
       
			UNION ALL

			SELECT 
				CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,1,@LastSaturday)) = 1 
			AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate > DATEADD(DD,1,@LastSaturday)) = 0)
			THEN 
			CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) 
			ELSE
			CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @LastDay, 101) AS nvarchar(100)) END   As DateRange,
			SUM(SPD.ActualProduction),
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
				SUM(DISTINCT SPD.PlantTargetProd),
				SUM(SPD.StandardProduction),
				SUM([NoOfLoads]),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(SPD.NoOfPieces),
				SUM(SPD.Rewash)
			FROM @ProductionSummaryTable SPD
			WHERE RecordDate > @LastSaturday AND RecordDate <= @LastDay 
			GROUP BY SPD.ShiftId
			)
			INSERT INTO @resultSet
			SELECT DISTINCT
			0,
			DateRange,
			SUM(TotalLoad),
			SUM(WasherEfficiency),
			SUM(PlantTargetLoad),
			SUM(StandardLoad),
			SUM(Numberofbatches),
			SUM(ActualRunTime),
			SUM(TargetRuntime),
			SUM(NumberofPieces),
			SUM(Rewash)
			,@Viewtype 
			,@Subview
				,0
				FROM CTE
				WHERE TotalLoad IS NOT NULL
				GROUP BY DateRange

	   END

       IF(@Subview = 2)
	   BEGIN
			DECLARE @QuarterYear VARCHAR(100) = YEAR(@enddate);
			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
			AS
			(
			  SELECT 
				DATENAME(MONTH, RecordDate) + ' ' + @QuarterYear As DateRange,
				SUM(SPD.ActualProduction),
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
				SUM(DISTINCT SPD.PlantTargetProd),
				SUM(SPD.StandardProduction),
				SUM([NoOfLoads]),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(SPD.NoOfPieces),
				SUM(SPD.Rewash)
				FROM @ProductionSummaryTable SPD
				GROUP BY  DATEPART(MONTH, RecordDate),DATENAME(MONTH, RecordDate),SPD.ShiftId
			)
			INSERT INTO @resultSet
			 SELECT DISTINCT
				0,
				DateRange,
			   SUM(TotalLoad),
			   SUM(WasherEfficiency),
				SUM(PlantTargetLoad),
				SUM(StandardLoad),
				SUM(Numberofbatches),
				SUM(ActualRunTime),
				SUM(TargetRuntime),
				SUM(NumberofPieces),
				SUM(Rewash)
				,@Viewtype 
				,@Subview
				 ,0
					FROM CTE
					WHERE TotalLoad IS NOT NULL
					GROUP BY DateRange
	   END   

      IF(@Subview = 1)
      BEGIN
		 DECLARE @Year VARCHAR(100) = RIGHT(YEAR(@enddate),2);
		 WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
			AS
			(
				SELECT 
				CASE 'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10))
				   WHEN 'Q1' THEN 'Jan' + @Year + '- Mar' + @Year
				   WHEN 'Q2' THEN 'Apr' + @Year + '- Jun' + @Year
				   WHEN 'Q3' THEN 'Jul' + @Year + '-Sep' + @Year
				   WHEN 'Q4' THEN 'Oct' + @Year + '- Dec'+ @Year
				END AS DateRange,
				SUM(SPD.ActualProduction),
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
				SUM(DISTINCT SPD.PlantTargetProd),
				SUM(SPD.StandardProduction),
				SUM([NoOfLoads]),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(SPD.NoOfPieces),
				SUM(SPD.Rewash)
				 FROM @ProductionSummaryTable SPD
				 GROUP BY DATEPART(QUARTER, RecordDate),SPD.ShiftId

			)

			INSERT INTO @resultSet
			SELECT DISTINCT
				0,
				DateRange,
			   SUM(TotalLoad),
			   SUM(WasherEfficiency),
				SUM(PlantTargetLoad),
				SUM(StandardLoad),
				SUM(Numberofbatches),
				SUM(ActualRunTime),
				SUM(TargetRuntime),
				SUM(NumberofPieces),
				SUM(Rewash)
				,@Viewtype 
				,@Subview
				 ,0
					FROM CTE
					WHERE TotalLoad IS NOT NULL
					GROUP BY DateRange

	  END
    END

    -- ******************************** Location View ***************************************************
    IF(@Viewtype = 2)
    BEGIN

		IF(@Subview = 9)
        BEGIN
			 WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,WasherGroupId)
			AS
			(
			 SELECT 
				--SPD.MachineId,
				WG.WasherGroupName,
				SUM(SPD.ActualProduction),
				CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
				NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
				COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
				SUM(DISTINCT SPD.PlantTargetProd),
				SUM(SPD.StandardProduction),
				SUM([NoOfLoads]),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(SPD.NoOfPieces),
				SUM(SPD.Rewash),
				WG.WasherGroupId
			  FROM @ProductionSummaryTable SPD LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId
					 LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId 
				GROUP BY WG.WasherGroupName,WG.WasherGroupId,SPD.ShiftId--,SPD.MachineId

			)

			 INSERT INTO @resultSet
			 SELECT DISTINCT
						0,
						DateRange,
						SUM(TotalLoad),
						SUM(WasherEfficiency),
			@PlantTargetProduction,
						SUM(StandardLoad),
						SUM(Numberofbatches),
						SUM(ActualRunTime),
						SUM(TargetRuntime),
						SUM(NumberofPieces),
						SUM(Rewash)
						,@Viewtype 
						,@Subview
						,WasherGroupId
				FROM CTE
					WHERE TotalLoad IS NOT NULL
					GROUP BY DateRange,WasherGroupId
        END

       IF(@Subview = 10)
       BEGIN
			 WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
			AS
			(
			SELECT         
				cast( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName MachineName,
				SUM(SPD.ActualProduction),
				CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
				NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
				COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)) ,
				SUM(DISTINCT SPD.PlantTargetProd),
				SUM(SPD.StandardProduction),
				SUM([NoOfLoads]),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(SPD.NoOfPieces),
				SUM(SPD.Rewash)
        
			 FROM @ProductionSummaryTable SPD 
		  LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId
		  LEFT JOIN TCD.Washer w on MS.WasherId=w.WasherId
			 LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId 
			WHERE 
			  (
			   CASE @drillvalue   
				   WHEN '' THEN 'TRUE'         
				   ELSE                                                    
					CASE WHEN WG.WasherGroupId IN (@drillvalue) THEN 'TRUE' END            
				   END='TRUE'
			  )
			 GROUP BY cast( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName,SPD.ShiftId

			)

			 INSERT INTO @resultSet
			  SELECT DISTINCT
						0,
						DateRange,
						SUM(TotalLoad),
						SUM(WasherEfficiency),
						@PlantTargetProduction,
						SUM(StandardLoad),
						SUM(Numberofbatches),
						SUM(ActualRunTime),
						SUM(TargetRuntime),
						SUM(NumberofPieces),
						SUM(Rewash)
						,@Viewtype 
						,@Subview
						,0
				FROM CTE
					WHERE TotalLoad IS NOT NULL
					GROUP BY DateRange
       END
    END

    -- ******************************** ChainCategory View **********************************************
    IF(@Viewtype = 5)
    BEGIN
		IF(@Subview = 16)
		BEGIN
		   -- ToDo : Change this part for chaincategory
			  WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,textileId)
			AS
			(
			 SELECT    
			CC.NAME,
			SUM(SPD.ActualProduction),
			COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
			SUM(DISTINCT SPD.PlantTargetProd),
			SUM(SPD.StandardProduction),
			SUM([NoOfLoads]),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(SPD.NoOfPieces),
			SUM(SPD.Rewash),
		 cc.TextileId
			   FROM
			 @ProductionSummaryTable SPD
			INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
			 INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = PM.PlantProgramId
			 INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId 
			Group by 
		   CC.Name,cc.TextileId,SPD.ShiftId
		   )
			INSERT INTO @resultSet
			  SELECT DISTINCT
						0,
						DateRange,
						SUM(TotalLoad),
						SUM(WasherEfficiency),
						@PlantTargetProduction,
						SUM(StandardLoad),
						SUM(Numberofbatches),
						SUM(ActualRunTime),
						SUM(TargetRuntime),
						SUM(NumberofPieces),
						SUM(Rewash)
						,@Viewtype 
						,@Subview
						,textileId
				FROM CTE
					WHERE TotalLoad IS NOT NULL
					GROUP BY DateRange,textileId
		END
    
		IF(@Subview = 19)
		BEGIN
		 -- ToDo : Change this part for chaincategory
			 WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
			AS
			(
			 SELECT  
			PCP.PlantProgramName,
			SUM(SPD.ActualProduction),
			COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
			SUM(DISTINCT SPD.PlantTargetProd),
			SUM(SPD.StandardProduction),
			SUM([NoOfLoads]),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(SPD.NoOfPieces),
			SUM(SPD.Rewash)
			  FROM @ProductionSummaryTable SPD
			INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
			 INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = PM.PlantProgramId
			 INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId 
			 WHERE
			(
		   CASE @drillvalue   
			   WHEN '' THEN 'TRUE'         
			   ELSE                                                    
			   CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END            
			   END='TRUE'
		  )
		 Group by 
		   PCP.PlantProgramName,PCP.PlantProgramId,SPD.ShiftId
		   )
		   INSERT INTO @resultSet
			  SELECT DISTINCT
						0,
						DateRange,
						SUM(TotalLoad),
						SUM(WasherEfficiency),
						@PlantTargetProduction,
						SUM(StandardLoad),
						SUM(Numberofbatches),
						SUM(ActualRunTime),
						SUM(TargetRuntime),
						SUM(NumberofPieces),
						SUM(Rewash)
						,@Viewtype 
						,@Subview
						,0
				FROM CTE
					WHERE TotalLoad IS NOT NULL
					GROUP BY DateRange
		END

	END

    -- ******************************** Customer View ***************************************************
	IF(@Viewtype = 6)
	BEGIN
		 WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
			AS
			(
			SELECT 
			PC.CustomerName,
			SUM(SPD.ActualProduction),
			COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
			SUM(DISTINCT SPD.PlantTargetProd),
			SUM(SPD.StandardProduction),
			SUM([NoOfLoads]),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(SPD.NoOfPieces),
			SUM(SPD.Rewash)
			FROM @ProductionSummaryTable SPD  INNER JOIN TCD.PlantCustomer PC on PC.CustomerId = SPD.CustomerId
			GROUP BY 
		   PC.CustomerName,SPD.ShiftId
		   )
		   INSERT INTO @resultSet
			  SELECT DISTINCT
						0,
						DateRange,
						SUM(TotalLoad),
						SUM(WasherEfficiency),
						@PlantTargetProduction,
						SUM(StandardLoad),
						SUM(Numberofbatches),
						SUM(ActualRunTime),
						SUM(TargetRuntime),
						SUM(NumberofPieces),
						SUM(Rewash)
						,@Viewtype 
						,@Subview
						,0
				FROM CTE
					WHERE TotalLoad IS NOT NULL
					GROUP BY DateRange
	END

-- ******************************** Formula View ****************************************************
	IF(@Viewtype = 7)
	BEGIN
		 WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
			AS
			(
		 SELECT 
			PM.Name,
			SUM(SPD.ActualProduction),
		   COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
			SUM(DISTINCT SPD.PlantTargetProd),
			SUM(SPD.StandardProduction),
			SUM([NoOfLoads]),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(SPD.NoOfPieces),
			SUM(SPD.Rewash)
			FROM @ProductionSummaryTable SPD 
			INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
			Group by 
			PM.Name,SPD.ShiftId
			)
			INSERT INTO @resultSet
			  SELECT DISTINCT
						0,
						DateRange,
						SUM(TotalLoad),
						SUM(WasherEfficiency),
						@PlantTargetProduction,
						SUM(StandardLoad),
						SUM(Numberofbatches),
						SUM(ActualRunTime),
						SUM(TargetRuntime),
						SUM(NumberofPieces),
						SUM(Rewash)
						,@Viewtype 
						,@Subview
						,0
				FROM CTE
					WHERE TotalLoad IS NOT NULL
					GROUP BY DateRange
    END

-- ******************************** Formula segmentView ****************************************************
	IF(@Viewtype = 8)
	BEGIN
		IF(@Subview =20)-- Formula Segment
		BEGIN
			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,FormulaSegmentID)
			AS
			(
			SELECT 
			FS.SegmentName,
			SUM(SPD.ActualProduction),
			COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
			SUM(DISTINCT SPD.PlantTargetProd),
			SUM(SPD.StandardProduction),
			SUM([NoOfLoads]),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(SPD.NoOfPieces),
			SUM(SPD.Rewash),
			SPD.FormulaSegmentID
			FROM @ProductionSummaryTable SPD 
			INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
			LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=SPD.FormulaSegmentID
			Group by SPD.FormulaSegmentID,FS.SegmentName	
			)
			INSERT INTO @resultSet
			(
			  ShiftId,
			  DateRange ,
			  TotalLoad  ,
			  WasherEfficiency ,
			  PlantTargetLoad  ,
			  StandardLoad ,
			  Numberofbatches ,
			  [ActualRunTime], 
			  [TargetRunTime],
			  NumberofPieces  ,
			  Rewash ,
			  Viewtype ,
			  Subview ,
			  Id
			)
				SELECT DISTINCT
						0,
						DateRange,
						SUM(TotalLoad),
						SUM(WasherEfficiency),
						@PlantTargetProduction,
						SUM(StandardLoad),
						SUM(Numberofbatches),
						SUM(ActualRunTime),
						SUM(TargetRuntime),
						SUM(NumberofPieces),
						SUM(Rewash)
						,@Viewtype 
						,@Subview
						,0
				FROM CTE
					WHERE TotalLoad IS NOT NULL
					GROUP BY DateRange
		END
		IF(@Subview =21)-- Formula Categories
		BEGIN		
			 WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,TextileId)
			 AS
				(
				SELECT EC.CategoryName,	SUM(SPD.ActualProduction),COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
				SUM(DISTINCT SPD.PlantTargetProd),SUM(SPD.StandardProduction),SUM([NoOfLoads]),SUM(DISTINCT SPD.ShiftRunTime),SUM(DISTINCT SPD.ShiftRunTime),
				SUM(SPD.NoOfPieces),SUM(SPD.Rewash),EC.TextileId
				FROM @ProductionSummaryTable SPD 
				LEFT JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
				WHERE EC.CategoryName IS NOT NULL
				GROUP BY EC.CategoryName,EC.TextileId,SPD.ShiftId

				UNION

				SELECT CC.NAME,SUM(SPD.ActualProduction),COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
				SUM(DISTINCT SPD.PlantTargetProd),SUM(SPD.StandardProduction),SUM([NoOfLoads]),SUM(DISTINCT SPD.ShiftRunTime),SUM(DISTINCT SPD.ShiftRunTime),
				SUM(SPD.NoOfPieces),SUM(SPD.Rewash),cc.TextileId
				FROM @ProductionSummaryTable SPD
				INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
				INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = SPD.ChainProgaramId
				INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId 
				Group by CC.Name,cc.TextileId,SPD.ShiftId
				)
				INSERT INTO @resultSet
				(
				  ShiftId,
				  DateRange ,
				  TotalLoad  ,
				  WasherEfficiency ,
				  PlantTargetLoad  ,
				  StandardLoad ,
				  Numberofbatches ,
				  [ActualRunTime], 
				  [TargetRunTime],
				  NumberofPieces  ,
				  Rewash ,
				  Viewtype ,
				  Subview ,
				  Id
				)
				SELECT DISTINCT
				0,
				DateRange,
				SUM(TotalLoad),
				SUM(WasherEfficiency),
				SUM(PlantTargetLoad),
				SUM(StandardLoad),
				SUM(Numberofbatches),
				SUM(ActualRunTime),
				SUM(TargetRuntime),
				SUM(NumberofPieces),
				SUM(Rewash)
				,@Viewtype 
				,@Subview
				,TextileId
				FROM CTE
				WHERE TotalLoad IS NOT NULL
				GROUP BY DateRange,TextileId
		END
		IF(@Subview=22) --Formula
		BEGIN
			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)
			AS
			(
				SELECT PM.Name,SUM(SPD.ActualProduction),COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
				SUM(DISTINCT SPD.PlantTargetProd),SUM(SPD.StandardProduction),SUM([NoOfLoads]),SUM(DISTINCT SPD.ShiftRunTime),SUM(DISTINCT SPD.ShiftRunTime),
				SUM(SPD.NoOfPieces),SUM(SPD.Rewash)
				FROM @ProductionSummaryTable SPD 
				INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
				INNER JOIN TCD.ProgramMaster PM ON EC.TextileId = PM.EcolabTextileCategoryId AND SPD.ProgramMasterId = PM.ProgramId    
				WHERE
					(
					CASE    
						WHEN @drillvalue='' THEN 'TRUE' 
						WHEN @drillvalue IS NULL THEN 'TRUE'  
						ELSE                                                    
						CASE WHEN EC.TextileId IN (@drillvalue) THEN 'TRUE' END            
						END='TRUE'
					) AND PM.NAME IS NOT NULL
				GROUP BY PM.Name,SPD.ShiftId

				UNION 

				SELECT PM.Name,SUM(SPD.ActualProduction),COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
				SUM(DISTINCT SPD.PlantTargetProd),SUM(SPD.StandardProduction),SUM([NoOfLoads]),SUM(DISTINCT SPD.ShiftRunTime),SUM(DISTINCT SPD.ShiftRunTime),
				SUM(SPD.NoOfPieces),SUM(SPD.Rewash)
				FROM @ProductionSummaryTable SPD 
				INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
				INNER JOIN TCD.ProgramMaster PM ON  SPD.ProgramMasterId = PM.ProgramId		
				WHERE
					(
					 CASE    
					 WHEN @drillvalue='' THEN 'TRUE' 
					 WHEN @drillvalue IS NULL THEN 'TRUE'  
					 ELSE                                                    
					 CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END            
					 END='TRUE'
					)
				GROUP BY PM.Name,SPD.ShiftId			
			)
			INSERT INTO @resultSet(ShiftId,DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,
				  StandardLoad,Numberofbatches,[ActualRunTime],[TargetRunTime],NumberofPieces  ,
				  Rewash,Viewtype,Subview,Id
			)
			SELECT DISTINCT 0,DateRange,SUM(TotalLoad),	SUM(WasherEfficiency),SUM(PlantTargetLoad),
				SUM(StandardLoad),SUM(Numberofbatches),	SUM(ActualRunTime),	SUM(TargetRuntime),	SUM(NumberofPieces),
				SUM(Rewash),@Viewtype ,@Subview,0
			FROM CTE
			WHERE TotalLoad IS NOT NULL
			GROUP BY DateRange
		END
	END
	
--- ********* Return result ********************

    SELECT DISTINCT  ShiftId, DateRange,ISNULL([TCD].[FnConsumptionOnMetrics](TotalLoad,'Weight',@UserId),0),      
      ISNULL([TCD].[FnConsumptionOnMetrics](WasherEfficiency,'Weight',@UserId),0), --ISNULL(WasherEfficiency,0),
      ISNULL([TCD].[FnConsumptionOnMetrics](PlantTargetLoad,'Weight',@UserId),0),--ISNULL(PlantTargetLoad,0),
      ISNULL([TCD].[FnConsumptionOnMetrics](StandardLoad,'Weight',@UserId),0),--ISNULL(StandardLoad,0),
      ISNULL(Numberofbatches,0),ISNULL(ActualRunTime,0),ISNULL(TargetRunTime,0),ISNULL(NumberofPieces,0),
      ISNULL(Rewash,0),Viewtype,Subview ,Id,@CorrectionVariable
      FROM @resultSet 


 
SET NOCOUNT OFF   
END
Go


GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetPlantRedFlagMachines]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetPlantRedFlagMachines
	END
GO 
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[GetPlantRedFlagMachines] (@GroupId INT, @EcolabAccountNumber nvarchar(25))
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE
     @Istunnel INT = NULL,
     @GroupTypeId INT = NULL;
	SELECT @IStunnel = Istunnel
	FROM TCD.machinesetup
	WHERE GroupId = @GroupId AND EcoalabAccountNumber = @EcolabAccountNumber;

    SELECT @GroupTypeId = GroupTypeId
	FROM TCD.MachineGroup
	WHERE Id = @GroupId
    AND Is_Deleted = 0
    AND EcolabAccountNumber = @EcolabAccountNumber;

    IF @GroupTypeId = 2
    BEGIN
		IF @IStunnel = 1
		BEGIN
		  SELECT DISTINCT MS.WasherId,  
				CAST( WS.PlantWasherNumber AS NVARCHAR)+ ':'+ MS.MachineName ,      
				MS.ControllerId  
			FROM TCD.machinesetup MS  
			LEFT JOIN TCD.Meter M ON MS.GroupId = M.GroupId  
				AND M.MachineCompartment = MS.WasherId  
			LEFT JOIN TCD.Sensor S ON MS.GroupId = S.GroupId  
				AND S.MachineCompartment = MS.WasherId  
			LEFT JOIN  TCD.Washer WS ON WS.WasherId = MS.WasherId  AND WS.EcoLabAccountNumber = @EcolabAccountNumber
			WHERE  MS.IsDeleted = 0  
				AND MS.GroupId = @GroupId  
				AND MS.EcoalabAccountNumber = @EcolabAccountNumber
				AND MS.IStunnel =1			
		END;
		ELSE
		BEGIN
			SELECT DISTINCT MS.WasherId,
				CAST( WS.PlantWasherNumber AS NVARCHAR)+ ':'+ MS.MachineName ,				
				MS.ControllerId
			  FROM TCD.machinesetup MS
			   LEFT JOIN
			   TCD.Meter M ON MS.GroupId = M.GroupId
				  AND M.MachineCompartment = MS.WasherId
			   LEFT JOIN
			   TCD.Sensor S ON MS.GroupId = S.GroupId
				   AND S.MachineCompartment = MS.WasherId
				LEFT JOIN  TCD.Washer WS ON WS.WasherId = MS.WasherId  AND WS.EcoLabAccountNumber = @EcolabAccountNumber
			  WHERE 
			 -- ( S.SensorId IS NOT NULL
			 -- AND S.Is_deleted = 0
			 -- AND S.EcolabAccountNumber = @EcolabAccountNumber
			 --  OR M.MeterId IS NOT NULL
			 -- AND M.Is_deleted = 0
			 -- AND M.EcolabAccountNumber = @EcolabAccountNumber)
				--AND 
				MS.IsDeleted = 0
				AND MS.GroupId = @GroupId
			 AND MS.EcoalabAccountNumber = @EcolabAccountNumber
			 AND MS.IStunnel =0;
		END;
    END;
    ELSE
    BEGIN 
		IF @GroupTypeId = 3
		BEGIN
		  SELECT DISTINCT D.DryerNo,
			  D.Description,
			  NULL
			FROM TCD.Dryers D			
			WHERE D.Is_deleted = 0
		  AND D.DryerGroupId = @GroupId
		  AND D.EcolabAccountNumber = @EcolabAccountNumber;
		END;
      ELSE
      BEGIN 
		IF @GroupTypeId = 4
        BEGIN
			SELECT DISTINCT F.FinnisherNo,
				F.Name,
				NULL
			  FROM TCD.Finnishers F
			   LEFT JOIN
			   TCD.Meter M ON F.FinnisherGroupId = M.GroupId
			  AND M.MachineCompartment = F.FinnisherId
			   LEFT JOIN
			   TCD.Sensor S ON F.FinnisherGroupId = S.GroupId
			   AND S.MachineCompartment = F.FinnisherId
			  WHERE ( S.SensorId IS NOT NULL
			  AND S.Is_deleted = 0
			  AND S.EcolabAccountNumber = @EcolabAccountNumber
			   OR M.MeterId IS NOT NULL
			  AND M.Is_deleted = 0
			  AND M.EcolabAccountNumber = @EcolabAccountNumber)
			AND F.Is_deleted = 0
			AND F.FinnisherGroupId = @GroupId
			AND F.EcolabAccountNumber =@EcolabAccountNumber;
        END;
        ELSE
        BEGIN 
			IF @GroupTypeId = 5
			BEGIN

			  DECLARE
			   @WaterandEnergyGroupId  INT = (SELECT TOP (1) MG.Id
					FROM TCD.MachineGroup MG
					 INNER JOIN
					 TCD.MachineGroupType MGT ON MGT.Id = MG.GroupTypeId
					WHERE MGT.Id = @GroupTypeId   );

			  SELECT DISTINCT WE.DeviceNumber,
				  WE.DeviceName,
				  NULL
				FROM TCD.WaterAndEnergy WE
				 LEFT JOIN
				 TCD.Meter M ON M.GroupId = @WaterandEnergyGroupId
				AND M.MachineCompartment = WE.DeviceNumber
				 LEFT JOIN
				 TCD.Sensor S ON S.GroupId = @WaterandEnergyGroupId
				 AND S.MachineCompartment = WE.DeviceNumber
				WHERE ( S.SensorId IS NOT NULL
				AND S.Is_deleted = 0
				AND S.EcolabAccountNumber = @EcolabAccountNumber
				 OR M.MeterId IS NOT NULL
				AND M.Is_deleted = 0
				AND M.EcolabAccountNumber = @EcolabAccountNumber)
			  AND WE.Is_deleted = 0
			  AND WE.EcolabAccountNumber = @EcolabAccountNumber;
			END;
        END;
      END;
    END;
    SET NOCOUNT OFF;
END;
GO

IF EXISTS (select 1 FROM sys.views where name = 'ChainPrograms')
BEGIN
    DROP VIEW TCD.ChainPrograms
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [TCD].[ChainPrograms]      
AS      
  
  SELECT  pcp.PlantProgramId, 
	  pcp.PlantProgramName, 
	  pcp.PlantChainId, 
	  ctc.TextileId AS ChainTextileId, 
	  ctc.Name AS ChainTextileName, 
	  etc.TextileId AS EcolabTextileCategoryId, 
	  etc.CategoryName AS EcolabTextileCategoryName, 
	  es.EcolabSaturationId, 
	  es.EcolabSaturationName, 
	  fs.FormulaSegmentID, 
	  fs.SegmentName,
	  p.EcolabAccountNumber,
	  es.MyServiceMstrLnnTypId AS MyServiceEcolabSaturationId,
	  etc.MyServiceMstrLnnTypId AS  MyServiceEcolabTextileCategoryId
  FROM TCD.PlantChainProgram pcp
  INNER JOIN TCD.Plant p ON p.PlantChainId = pcp.PlantChainId 
  LEFT JOIN TCD.ChainTextileCategory ctc
  ON pcp.ChainTextileCategoryId = ctc.TextileId AND ctc.PlantChainId = pcp.PlantChainId
  LEFT JOIN TCD.EcolabTextileCategory etc
  ON pcp.EcolabTextileCategoryId = etc.TextileId
  LEFT JOIN TCD.EcolabSaturation es
  ON pcp.EcolabSaturationId = es.EcolabSaturationId
  LEFT JOIN TCD.FormulaSegments fs
  ON pcp.FormulaSegmentId = fs.FormulaSegmentID
GO


 IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetWasherGroupFormula]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.[GetWasherGroupFormula]
	END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE	PROCEDURE    [TCD].[GetWasherGroupFormula]
                     @EcoLabAccountNumber						NVARCHAR(1000)
                ,    @WasherGroupId								INT
                ,    @ProgramSetupId                            INT                =		NULL            --Null for LIST
                ,    @Is_Deleted                                BIT                =		'FALSE'
AS
BEGIN

SET    NOCOUNT    ON

DECLARE
         @WasherGroupNumber							VARCHAR(10)				=    NULL
    ,    @WasherGroupName							NVARCHAR(50)			=    NULL
    ,    @WasherGroupTypeName						VARCHAR(30)				=    NULL
    ,    @NextAvailableStepNo						INT						=    NULL
    ,    @NextAvailableFormulaNo                    INT						=    NULL
    ,    @MyServiceMchGrpGuid						UNIQUEIDENTIFIER		=	 NULL
    ,    @MaxInjectionsCount                        INT						=	 0
    ,    @CanAddInjections							BIT						=	 0
    ,    @ReferenceLoad								INT						=	 0
    ,	 @ControllerID								INT						=	 NULL
    ,	 @ControllerModelID							INT						=	 NULL


CREATE TABLE #SetupDataTemp
(
     val varchar(32) not null
);

SELECT	
			@WasherGroupTypeName			=            WGT.WasherGroupTypeName
    ,		@WasherGroupNumber				=            WG.WasherGroupNumber
    ,		@WasherGroupName				=            WG.WasherGroupName
    ,		@MyServiceMchGrpGuid			=            GT.MyServiceCustMchGrpGuid
	FROM	[TCD].WasherGroup						WG (NOLOCK)
JOIN		[TCD].WasherGroupType					WGT (NOLOCK)
    ON		WG.WasherGroupTypeId			=			 WGT.WasherGroupTypeId
JOIN		[TCD].MachineGroup						GT (NOLOCK)
    ON		WG.WasherGroupId				=			 GT.Id
AND			WG.EcolabAccountNumber			=			 GT.EcolabAccountNumber
	WHERE   GT.EcolabAccountNumber			=            @EcoLabAccountNumber
AND			WG.WasherGroupId				=            @WasherGroupId

SELECT		@ControllerID			=		wg.ControllerId 
	FROM	TCD.WasherGroup			wg
	WHERE   wg.WasherGroupId		=		@WasherGroupId
AND			wg.EcolabAccountNumber	=		@EcoLabAccountNumber

SELECT		@ControllerModelID		=		cc.ControllerModelId
	FROM	TCD.ConduitController	cc
	WHERE	cc.ControllerId			=		@ControllerID
AND			cc.EcoalabAccountNumber =		@EcoLabAccountNumber

IF    (@WasherGroupTypeName			=	    'Tunnel')  --Tunnel/Washer Formula
	BEGIN
                     
			SELECT @NextAvailableFormulaNo = ISNULL(MAX(ProgramNumber), 0) + 1 FROM [TCD].TunnelProgramSetup 
			WHERE 
			WasherGroupId=@WasherGroupId 
			AND 
			Is_Deleted=0
			AND 
            EcolabAccountNumber    = @EcoLabAccountNumber        
		
			SELECT
					@WasherGroupNumber					AS			WasherGroupNumber
				,	@WasherGroupName					AS			WasherGroupName
				,	@WasherGroupTypeName				AS			WasherGroupTypeName
				,	TPS.TunnelProgramSetupId			AS			ProgramSetupId
				,	TPS.ProgramNumber					AS			ProgramNumber
				,	TPS.ProgramId						AS			ProductId
				,	PM.Name								AS			ProductName
				,	TPS.NominalLoad						AS			NominalLoad
				,	SUM(TDS.StepRunTime)				AS			TotalRunTime
				,	TPS.ExtraTime						AS			ExtraTime
				,	TPS.LoadsPerMonth					AS			LoadsPerMonth
				,	0									AS			NextAvailableStepNo
				,	TPS.LastModifiedTime				AS			LastModifiedTime
				,	TPS.LastSyncTime					AS			LastSyncTime
				,   TPS.EcolabAccountNumber				AS			EcolabAccountNumber 
				,	TPS.WasherGroupId					AS			WasherGroupId
				,	@NextAvailableFormulaNo				AS			NextAvailableFormulaNo
				,	TPS.MyServiceCustFrmulaMchGrpGUID	AS			MyServiceCustFrmulaMchGrpGUID
				,	TPS.Is_Deleted						AS			Is_Deleted
				,	(CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN ETC.MyServiceMstrLnnTypId 
					   ELSE cp.MyServiceEcolabTextileCategoryId END) AS MyServiceMstrLnnTypId
				,	@MyServiceMchGrpGuid				AS			MyServiceMchGrpGuid
				,	@MaxInjectionsCount					AS			MaxInjectionsCount
				,	@CanAddInjections					AS			CanAddInjections
				,	TPS.MyServiceLastSynchTime			AS			MyServiceLastSynchTime
				,	@ReferenceLoad						AS			ReferenceLoad
				,	(SELECT COUNT(DISTINCT tds.TunnelDosingSetupId) FROM TCD.TunnelDosingSetup tds
							INNER JOIN TCD.TunnelDosingProductMapping tdpm
							ON tdpm.TunnelDosingSetupId = tds.TunnelDosingSetupId
							AND tdpm.EcoLabAccountNumber = tds.EcolabAccountNumber
							INNER JOIN TCD.WasherGroup wg 
							ON wg.WasherGroupId = TPS.WasherGroupId
							AND wg.EcolabAccountNumber = TPS.EcolabAccountNumber
							INNER JOIN TCD.MachineSetup ms
							ON ms.GroupId = wg.WasherGroupId
							AND ms.EcoalabAccountNumber = wg.EcolabAccountNumber
							INNER JOIN TCD.TunnelCompartment tc
							ON tc.EcoLabAccountNumber = ms.EcoalabAccountNumber
							AND tc.WasherId = ms.WasherId
							INNER JOIN TCD.TunnelCompartmentEquipmentMapping tcem
							ON tcem.EcoLabAccountNumber = tc.EcoLabAccountNumber
							AND tcem.ControllerEquipmentSetupId = tdpm.ControllerEquipmentSetupId
							AND tc.TunnelCompartmentId = tcem.TunnelCompartmentId
							AND tcem.Is_Deleted = 'False'
							WHERE wg.WasherGroupId = @WasherGroupId
							AND wg.EcolabAccountNumber = @EcoLabAccountNumber
							AND tds.TunnelProgramSetupId = TPS.TunnelProgramSetupId) AS WashStepCount ,
					@ControllerID as ControllerID
					,@ControllerModelID as ControllerModelID
				,   (CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN ES.MyServiceMstrLnnTypId
					   ELSE cp.MyServiceEcolabSaturationId END) AS MyServiceSaturationTypeId
			FROM	[TCD].TunnelProgramSetup			TPS (NOLOCK)
			JOIN	[TCD].ProgramMaster					PM (NOLOCK)
				ON	TPS.ProgramId						=			PM.ProgramId
				AND PM.EcolabAccountNumber				=			TPS.EcolabAccountNumber
			LEFT JOIN TCD.EcolabTextileCategory		ETC  (NOLOCK)
				ON	PM.EcolabTextileCategoryId			=			ETC.TextileId
			LEFT JOIN TCD.EcolabSaturation			ES (NOLOCK)
				ON	PM.EcolabSaturationId				=			ES.EcolabSaturationId
		     LEFT JOIN TCD.ChainPrograms cp
				ON cp.PlantProgramId = pm.PlantProgramId AND pm.EcolabAccountNumber = cp.EcolabAccountNumber 
			LEFT JOIN [TCD].TunnelDosingSetup TDS (NOLOCK) 
                ON    TDS.TunnelProgramSetupId				=            TPS.TunnelProgramSetupId
                AND   TDS.EcolabAccountNumber               =            TPS.EcolabAccountNumber
                AND   (TDS.Is_Deleted						=            'FALSE' OR TDS.Is_Deleted = @Is_Deleted)
            WHERE     TPS.EcolabAccountNumber				=            @EcoLabAccountNumber
                AND   TPS.WasherGroupId						=            @WasherGroupId
                AND   TPS.TunnelProgramSetupId				=            ISNULL(@ProgramSetupId, TPS.TunnelProgramSetupId)
                AND   (TPS.Is_Deleted						=            'FALSE' OR TPS.Is_Deleted = @Is_Deleted)

			GROUP BY 
				TPS.TunnelProgramSetupId
				,TPS.ProgramNumber
				,TPS.ProgramId
				,PM.Name
				,TPS.NominalLoad
				,TPS.ExtraTime
				,TPS.LoadsPerMonth
				,TPS.LastModifiedTime
				,TPS.LastSyncTime
				,TPS.EcolabAccountNumber
				,TPS.WasherGroupId
				,TPS.MyServiceCustFrmulaMchGrpGUID
				,TPS.Is_Deleted
				,ETC.MyServiceMstrLnnTypId
				,TPS.MyServiceLastSynchTime
				,pm.PlantProgramId
				,cp.MyServiceEcolabSaturationId
				,ES.MyServiceMstrLnnTypId
				,cp.MyServiceEcolabTextileCategoryId


	END
ELSE    --Conventional/Washer Formula
	BEGIN

    IF @ControllerModelID < 7 OR @ControllerModelID IN( 12, 13) 
    BEGIN
		;
WITH InjectValues (Value)
AS
(
		SELECT
			csd.[Value]
		    FROM TCD.ControllerSetupData			AS		csd
			 INNER JOIN TCD.ConduitController		AS		cc(NOLOCK)ON cc.ControllerId = csd.ControllerId
					AND cc.EcoalabAccountNumber		=		csd.EcolabAccountNumber
			 INNER JOIN TCD.FieldGroup				AS		fg ON fg.ControllerModelId = cc.ControllerModelId
					AND fg.ControllerTypeId			=		cc.ControllerTypeId
			 INNER JOIN TCD.FieldGroupFieldMapping	AS		fgfm ON fgfm.FieldGroupId = fg.Id
			 INNER JOIN TCD.Field					AS		f ON f.Id = fgfm.FieldId
					AND f.ResourceKey				=		'Max_Formula_Injections'
					AND csd.FieldId					=		f.Id
			 INNER JOIN TCD.MachineSetup			AS		ms(NOLOCK)ON ms.ControllerId = cc.ControllerId
					AND cc.EcoalabAccountNumber		=		ms.EcoalabAccountNumber
			 INNER JOIN TCD.WasherGroup				AS		wg(NOLOCK)ON wg.WasherGroupId = ms.GroupId
					AND wg.EcolabAccountNumber		=		ms.EcoalabAccountNumber
		    WHERE wg.WasherGroupId					=		@Washergroupid
		      AND ms.IsDeleted						=		'False'
		      AND wg.EcolabAccountNumber			=		@Ecolabaccountnumber
)
		INSERT INTO #SetupDataTemp  SELECT iv.[Value] FROM InjectValues iv
		
SELECT @MaxInjectionsCount = MIN(CAST(t.val AS INT)) FROM #SetupDataTemp t 

DROP TABLE #SetupDataTemp   
    END
    ELSE
    BEGIN
		SET @MaxInjectionsCount = 20
    END
			
			DECLARE @MaxInjectionsNumber INT = 0
			
			SELECT  @MaxInjectionsNumber =  ISNULL(MAX(wdpm.InjectionNumber),0) FROM TCD.WasherDosingProductMapping wdpm (NOLOCK) 
                INNER JOIN TCD.WasherDosingSetup wds (NOLOCK) ON wds.WasherDosingSetupId = wdpm.WasherDosingSetupId 
				AND wds.EcoLabAccountNumber = wdpm.EcoLabAccountNumber
							WHERE wds.WasherProgramSetupId = @ProgramSetupId AND wds.EcoLabAccountNumber = @EcoLabAccountNumber
								AND wds.Is_Deleted = 0 AND wdpm.IsDeleted=0

			IF @MaxInjectionsNumber < @MaxInjectionsCount
			BEGIN
                SET @CanAddInjections    =    1
			END


			SELECT @NextAvailableStepNo = ISNULL(MAX(StepNumber), 0) + 1 FROM [TCD].WasherDosingSetup WDS (NOLOCK)
			WHERE 
            WDS.EcolabAccountNumber    = @EcoLabAccountNumber
			AND
			WDS.WasherProgramSetupId = @ProgramSetupId
			AND 
			Is_Deleted = 'FALSE'
            
			IF @ControllerModelID = 7 -- MyControl
			BEGIN
				SET @WasherGroupId = NULL
			END
			
			SELECT @NextAvailableFormulaNo = ISNULL(MAX(ProgramNumber), 0) + 1 FROM [TCD].WasherProgramSetup (NOLOCK) 
			WHERE 
            (CASE WHEN @WasherGroupId IS NOT NULL 
						  THEN WasherGroupId
						  ELSE ControllerID
					END)									= (CASE WHEN @WasherGroupId IS NOT NULL 
																	THEN @WasherGroupId
																	ELSE @ControllerID
																	END)
			AND 
			Is_Deleted=0
			AND EcolabAccountNumber = @EcoLabAccountNumber

			--SELECT @ReferenceLoad = MAX(I.ReferenceLoad) FROM [TCD].Injection I JOIN [TCD].MachineSetup MS 
			--	ON I.WasherGroupNumber = ms.GroupId
			--	JOIN [TCD].Washer W ON MS.WasherId = W.WasherId
			--		WHERE I.WasherGroupNumber = @WasherGroupId
			--			AND MS.IsDeleted = 0
			--			AND W.Is_Deleted = 0
			 SELECT @ReferenceLoad = MAX(i.ReferenceLoad) FROM	 TCD.Injection i (NOLOCK) 
				    INNER JOIN TCD.WasherGroup wg (NOLOCK) ON wg.WasherGroupNumber = i.WasherGroupNumber AND wg.EcolabAccountNumber = i.EcolabAccountNumber 
				    INNER JOIN TCD.MachineSetup ms (NOLOCK) ON ms.GroupId=wg.WasherGroupId AND ms.EcoalabAccountNumber=wg.EcolabAccountNumber AND ms.IsDeleted=0
				    INNER JOIN TCD.Washer w (NOLOCK) ON w.WasherId = ms.WasherId AND w.EcoLabAccountNumber=ms.EcoalabAccountNumber AND w.Is_Deleted=0
				    WHERE I.WasherGroupNumber = (SELECT WasherGroupNumber FROM TCD.WasherGroup wg WHERE wg.WasherGroupId=@WasherGroupId 
					AND wg.EcolabAccountNumber = @EcoLabAccountNumber) 
					    AND i.EcolabAccountNumber=@EcoLabAccountNumber

			SELECT
                     @WasherGroupNumber						AS            WasherGroupNumber
                ,    @WasherGroupName						AS            WasherGroupName
                ,    @WasherGroupTypeName					AS            WasherGroupTypeName
                ,    WPS.WasherProgramSetupId				AS            ProgramSetupId
                ,    WPS.ProgramNumber						AS            ProgramNumber
                ,    WPS.ProgramId							AS            ProductId
                ,    PM.Name                                AS            ProductName
                ,    WPS.NominalLoad                        AS            NominalLoad
                ,    SUM(WDS.StepRunTime)					AS            TotalRunTime
                ,    WPS.ExtraTime							AS            ExtraTime
                ,    WPS.LoadsPerMonth						AS            LoadsPerMonth
                ,    @NextAvailableStepNo					AS            NextAvailableStepNo
                ,    WPS.LastModifiedTime					AS            LastModifiedTime
                ,    WPS.LastSyncTime						AS            LastSyncTime
                ,    WPS.EcolabAccountNumber                AS            EcolabAccountNumber 
                ,    WPS.WasherGroupId						AS            WasherGroupId
                ,    @NextAvailableFormulaNo                AS            NextAvailableFormulaNo
                ,    WPS.MyServiceCustFrmulaMchGrpGUID		AS            MyServiceCustFrmulaMchGrpGUID
                ,    WPS.Is_Deleted							AS            Is_Deleted
                ,	(CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN ETC.MyServiceMstrLnnTypId 
				ELSE cp.MyServiceEcolabTextileCategoryId END) AS MyServiceMstrLnnTypId
                ,    @MyServiceMchGrpGuid					AS            MyServiceMchGrpGuid
                ,    @MaxInjectionsCount                    AS            MaxInjectionsCount
                ,    @CanAddInjections						AS            CanAddInjections
                ,    WPS.MyServiceLastSynchTime				AS            MyServiceLastSynchTime
                ,    @ReferenceLoad							AS            ReferenceLoad
                ,    (Select Count(DISTINCT WDS.WasherDosingSetupId) FROM [TCD].WasherDosingSetup WDS
                      INNER JOIN TCD.WasherDosingProductMapping WDPM
                      ON WDS.WasherDosingSetupId = WDPM.WasherDosingSetupId 
                      AND WDS.EcoLabAccountNumber = WDPM.EcoLabAccountNumber
                      AND WDPM.IsDeleted = 'FALSE'
                      WHERE WDS.WasherProgramSetupId = WPS.WasherProgramSetupId AND WDS.Is_Deleted = 'FALSE' AND WDS.EcoLabAccountNumber = @EcoLabAccountNumber) AS WashStepCount
			,	@ControllerID as ControllerID
			,	@ControllerModelID as ControllerModelID
			,	(CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN ES.MyServiceMstrLnnTypId
				ELSE cp.MyServiceEcolabSaturationId END) AS MyServiceSaturationTypeId
			FROM	[TCD].WasherProgramSetup			WPS (NOLOCK)
			JOIN	[TCD].ProgramMaster					PM (NOLOCK)			
				ON	WPS.ProgramId						=			PM.ProgramId
			LEFT JOIN TCD.EcolabTextileCategory		ETC (NOLOCK)
				ON	PM.EcolabTextileCategoryId			=			ETC.TextileId
		     LEFT JOIN TCD.EcolabSaturation			ES (NOLOCK)
				ON	PM.EcolabSaturationId				=			ES.EcolabSaturationId
		     LEFT JOIN TCD.ChainPrograms cp
				ON cp.PlantProgramId = pm.PlantProgramId AND pm.EcolabAccountNumber = cp.EcolabAccountNumber 
			LEFT JOIN [TCD].WasherDosingSetup WDS (NOLOCK) ON WDS.WasherProgramSetupId = WPS.WasherProgramSetupId
			AND (WDS.Is_Deleted					=			'FALSE' OR WDS.Is_Deleted = @Is_Deleted)
			WHERE	
			WPS.EcolabAccountNumber			=			@EcoLabAccountNumber
			 AND		(CASE WHEN @WasherGroupId IS NOT NULL 
						  THEN WPS.WasherGroupId
						  ELSE WPS.ControllerID
					END)									= (CASE WHEN @WasherGroupId IS NOT NULL 
																	THEN @WasherGroupId
																	ELSE @ControllerID
																	END)
			AND	
			WPS.WasherProgramSetupId		=			ISNULL(@ProgramSetupId, WPS.WasherProgramSetupId)
			AND	
			(WPS.Is_Deleted					=			'FALSE' OR WPS.Is_Deleted = @Is_Deleted)
			
			GROUP BY 
				WPS.WasherProgramSetupId
				,WPS.ProgramNumber
				,WPS.ProgramId
				,PM.Name
				,WPS.NominalLoad
				,WPS.ExtraTime
				,WPS.LoadsPerMonth
				,WPS.LastModifiedTime
				,WPS.LastSyncTime
				,WPS.EcolabAccountNumber
				,WPS.WasherGroupId
				,WPS.MyServiceCustFrmulaMchGrpGUID
				,WPS.Is_Deleted
				,ETC.MyServiceMstrLnnTypId
				,WPS.MyServiceLastSynchTime
				,pm.PlantProgramId
				,cp.MyServiceEcolabSaturationId
				,ES.MyServiceMstrLnnTypId
				,cp.MyServiceEcolabTextileCategoryId
	END

SET    NOCOUNT    OFF

END
GO

IF OBJECT_ID('[TCD].[DashboardHistoryAuditTrigger]') is not null
BEGIN
	DROP trigger [TCD].[DashboardHistoryAuditTrigger]	
END

GO

/*                                           
###################################################################################################                                           

Trigger		:		DashboardHistoryAuditTrigger

Purpose		:		Trigger	for auditing changes on DashboardHistory table

Parameter	:		NA

###################################################################################################                                           
*/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE	TRIGGER	[TCD].[DashboardHistoryAuditTrigger]
ON					[TCD].[Dashboard]
FOR	INSERT, UPDATE
AS
BEGIN

SET	NOCOUNT	ON

DECLARE	@AuditOperation_SQLInsertId			TINYINT				=			NULL
	,	@AuditOperation_SQLUpdateId			TINYINT				=			NULL
	,	@AuditOperation_AppDeleteId			TINYINT				=			NULL
	,	@ErrorNumber						INT					=			0
	,	@ErrorMessage						NVARCHAR(2048)		=			NULL
	,	@ErrorSeverity						INT					=			NULL
	,	@ErrorProcedure						SYSNAME				=			NULL
	,	@MessageString						NVARCHAR(2500)		=			NULL
	,	@SoftDeleteFlag						BIT					=			NULL			--0 for FALSE/1 for TRUE
	,	@CurrentTimeStamp					DATETIME			=			GETUTCDATE()	--CURRENT_TIMESTAMP

--select	*	from	AuditOperation
SELECT	@AuditOperation_SQLInsertId			=			AO.OperationId
FROM	[TCD].AuditOperation					AO
WHERE	AO.OperationCode					=			'SQLInsert'

SELECT	@AuditOperation_SQLUpdateId			=			AO.OperationId
FROM	[TCD].AuditOperation					AO
WHERE	AO.OperationCode					=			'SQLUpdate'

SELECT	@AuditOperation_AppDeleteId			=			AO.OperationId
FROM	[TCD].AuditOperation					AO
WHERE	AO.OperationCode					=			'AppDelete'

IF	NOT	EXISTS	(SELECT	1	FROM	[deleted])
	BEGIN

			BEGIN	TRY

				INSERT	[TCD].DashboardHistory
				(
				    [DashboardId]
				   ,[OperationTimestamp]
				   ,[OperationId]
				   ,[OperationByUserId]
				   ,[DashBoardName]
				   ,[Description]
				   ,[TypeId]
				   ,[EcolabAccountNumber]
				   ,[IsEnableParameters]
				   ,[IsDeleted]
				   ,[MachineNameDispalyType]
				   
				)
										

				SELECT	[DashboardId],@CurrentTimeStamp	,@AuditOperation_SQLInsertId,LastModifiedByUser
					   ,[DashBoardName]
						,[Description]
						,[TypeId]
						,[EcolabAccountNumber]
						,[IsEnableParameters]
						,[IsDeleted]
						,[MachineNameDispalyType]
						 
						FROM	[inserted]

			END	TRY
			BEGIN	CATCH

					SELECT	@ErrorNumber				=			ERROR_NUMBER()
						,	@ErrorMessage				=			ERROR_MESSAGE()
						,	@ErrorProcedure				=			ERROR_PROCEDURE()
						,	@ErrorSeverity				=			ERROR_SEVERITY()

					--GOTO	ErrorHandler
					SET		@MessageString				=	N'An error occured while updating Audit data for Dashboard table. The error is: '
														+	@ErrorMessage + '	'
														+	'Module: ' + @ErrorProcedure
					RAISERROR(@MessageString, @ErrorSeverity, 1)
					RETURN

			END	CATCH

	END
ELSE	IF	EXISTS	(SELECT	1	FROM	[inserted])
	BEGIN
			IF	UPDATE(IsDeleted)
				SET	@SoftDeleteFlag	=	'TRUE'
			ELSE
				SET	@SoftDeleteFlag	=	'FALSE'

			BEGIN
					BEGIN	TRY
					IF (UPDATE (MachineNameDispalyType))
					BEGIN
					INSERT	[TCD].DashboardHistory
							 (
								[DashboardId]
							    ,[OperationTimestamp]
							    ,[OperationId]
							    ,[OperationByUserId]
							    ,[DashBoardName]
							    ,[Description]
							    ,[TypeId]
							    ,[EcolabAccountNumber]
							    ,[IsEnableParameters]
							    ,[IsDeleted]
								,[MachineNameDispalyType]
							   
							 )
					    SELECT	[DashboardId]	,@CurrentTimeStamp
							    ,CASE	WHEN	@SoftDeleteFlag	=	'FALSE'	THEN	@AuditOperation_SQLUpdateId
											    WHEN	@SoftDeleteFlag	=	'TRUE'	THEN	@AuditOperation_AppDeleteId
									    END
							    ,LastModifiedByUser
							    ,[DashBoardName]
							    ,[Description]
							    ,[TypeId]
							    ,[EcolabAccountNumber]
							    ,[IsEnableParameters]
							    ,[IsDeleted]
							    ,[MachineNameDispalyType]
							
							
							 FROM	[inserted]
						END
					END	TRY
					BEGIN	CATCH

							SELECT	@ErrorNumber				=			ERROR_NUMBER()
								,	@ErrorMessage				=			ERROR_MESSAGE()
								,	@ErrorProcedure				=			ERROR_PROCEDURE()
								,	@ErrorSeverity				=			ERROR_SEVERITY()

							--GOTO	ErrorHandler
							SET		@MessageString				=	N'An error occured while updating Audit data for Dashboard table. The error is: '
																+	@ErrorMessage + '	'
																+	'Module: ' + @ErrorProcedure
							RAISERROR(@MessageString, @ErrorSeverity, 1)
							RETURN

					END	CATCH
			END
	END

IF	@ErrorNumber	=	0
	--GOTO	ExitModule
	RETURN
		


ErrorHandler:

SET		@MessageString						=	N'An error occured while updating Audit data for Dashboard table. The error is: '
											+	@ErrorMessage + '	'
											+	'Module: ' + @ErrorProcedure
RAISERROR(@MessageString, @ErrorSeverity, 1)



ExitModule:

SET	NOCOUNT	OFF

RETURN


END

GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetTagManamenetDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetTagManamenetDetails
	END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[GetTagManamenetDetails] 
@ControllerId INT,
@EcolabAccountNumber nvarchar(25),
@UserId INT

AS
BEGIN 
DECLARE @Active INT = 1,
    @TankModuleTypeId INT,
    @SensorModuleTypeId INT,
    @PumpModuleTypeId INT,
    @LangunageId INT,
    @SplChars VARCHAR(50)   = ' # -',
    @LocaliseValue VARCHAR(200),
    @FactorMultiplier INT,
    @TimeVolumeMultipler INT,
	@ControllerModelId int


SELECT @TankModuleTypeId=mty.ModuleTypeId FROM TCD.ModuleType mty WHERE mty.ModuleDescription='Tank'
SELECT @SensorModuleTypeId=mty.ModuleTypeId FROM TCD.ModuleType mty WHERE mty.ModuleDescription='Sensor'
SELECT @PumpModuleTypeId=mty.ModuleTypeId FROM TCD.ModuleType mty WHERE mty.ModuleDescription='Pumps/Valves'
SELECT @LangunageId=p.languageID FROM TCD.Plant p WHERE p.EcolabAccountNumber=@EcolabAccountNumber


 SELECT @TimeVolumeMultipler= CAST(csd.[Value] AS decimal(18,0)) FROM TCD.ControllerSetupData csd 
 INNER JOIN TCD.Field f ON f.Id = csd.FieldId 
 WHERE csd.FieldId IN(SELECT f2.Id FROM TCD.Field f2 WHERE f2.Label LIKE '%OZ/Second Multiplier%') 
    AND csd.ControllerId=@ControllerId 
    AND csd.EcolabAccountNumber=@EcolabAccountNumber 
	AND ISNUMERIC(csd.[Value]) = 1

 SELECT @FactorMultiplier= CAST(csd.[Value] AS decimal(18,0)) FROM TCD.ControllerSetupData csd 
 INNER JOIN TCD.Field f ON f.Id = csd.FieldId 
 WHERE csd.FieldId IN(SELECT f2.Id FROM TCD.Field f2 WHERE f2.Label LIKE '%Factors Multiplier%') 
    AND csd.ControllerId=@ControllerId
    AND csd.EcolabAccountNumber=@EcolabAccountNumber 
	AND ISNUMERIC(csd.[Value]) = 1

SELECT @ControllerModelId=ControllerModelId FROM tcd.ConduitController cc WHERE ControllerId=@ControllerId


CREATE TABLE #tmpTagManagementDetails
(
  Id INT
 ,TagAddress VARCHAR(100)
 ,[Description] VARCHAR(1000)
 ,Value VARCHAR(500)
 ,LastModifiedTime DATETIME 
 ,ColName VARCHAR(500)
 ,DataType varchar(100)
 ,RowNumber decimal(3,2)
 ,OriginalColumnName varchar(100)
 ,EntityType varchar(100)
 ,TagType varchar(100)
 ,ControllerEquipmentSetupId varchar(100)
 ,SortingOrder varchar(100)
)


--SELECT @LocaleValue=rkv.[Value] FROM TCD.ResourceKeyMaster rkm 
--    INNER JOIN TCD.ResourceKeyValue rkv on rkv.ResourceId = rkm.ResourceId 
--where rkm.[Key] ='FIELD_'+ UPPER(@KeyValue) 
--  AND 
--rkv.languageID=ISNULL((SELECT um.LanguageId FROM TCD.UserMaster um WHERE um.UserId=@UserId),(SELECT p.LanguageId FROM TCD.Plant p WHERE p.EcolabAccountNumber=@EcolabAccountNumber)) 


--------------------------------------
-- StorageTanks---
--------------------------------------

INSERT INTO #tmpTagManagementDetails(Id, TagAddress,    [Description],    [Value],    LastModifiedTime,colName,DataType,RowNumber,OriginalColumnName
	,EntityType,TagType,ControllerEquipmentSetupId,SortingOrder)

----------------------------------------------------------------
-- Conventional-AND-Tunnel(AWEA, EOF, MODE to be displayed)-----
----------------------------------------------------------------
SELECT ms.WasherId, wt.TagAddress,ms.MachineName,Convert(varchar(100), CONVERT(int, w.EndOfFormula)),w.LastModifiedTime ,'EndofFormulaNumber',tt.DataType,1,
'EndOfFormula' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType,ms.MachineInternalId as ControllerEquipmentSetupId, 0 as SortingOrder 
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId) AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_EOF' AND ms.IsTunnel IN (0,1)
UNION

SELECT ms.WasherId, wt.TagAddress,ms.MachineName,Convert(varchar(100), CONVERT(int, w.WasherMode)),w.LastModifiedTime ,'WasherMode',tt.DataType,1
,'WasherMode' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType,ms.MachineInternalId as ControllerEquipmentSetupId, 0 as SortingOrder  
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_MODE' AND ms.IsTunnel IN (0,1)
UNION

SELECT ms.WasherId, wt.TagAddress,ms.MachineName,Convert(varchar(100), CONVERT(int, w.AWEActive)),w.LastModifiedTime ,'AWEActive',tt.DataType,1
,'AWEActive' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType,ms.MachineInternalId as ControllerEquipmentSetupId , 0 as SortingOrder 
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_AWEA' AND ms.IsTunnel IN (0,1)
UNION

SELECT ms.WasherId, wt.TagAddress,ms.MachineName,Convert(varchar(100), CONVERT(int, w.HoldDelay)),w.LastModifiedTime ,'HoldDelay',tt.DataType,1
,'HoldDelay' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType, ms.MachineInternalId as ControllerEquipmentSetupId , 0 as SortingOrder

FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId  AND wt.Active=@Active  AND wt.TagType='Tag_HOLDD' AND ms.IsTunnel=0 
UNION

SELECT ms.WasherId, wt.TagAddress,ms.MachineName,Convert(varchar(100), CONVERT(int, w.WaterFlushTime)),w.LastModifiedTime , 'WaterFlushTime' ,tt.DataType,1
,'WaterFlushTime' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType, ms.MachineInternalId as ControllerEquipmentSetupId, 0 as SortingOrder  
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_FLSHT' AND ms.IsTunnel=0
UNION

SELECT ms.WasherId, wt.TagAddress,ms.MachineName,Convert(varchar(100), CONVERT(int, w.RatioDosingActive)),w.LastModifiedTime, 'RatioDosingActive',tt.DataType,1
,'RatioDosingActive' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType, ms.MachineInternalId as ControllerEquipmentSetupId, 0 as SortingOrder  
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_RATA' AND ms.IsTunnel=0

UNION
------------------------------------
---- Tanks---
------------------------------------
SELECT ts.TankId AS Id, mt.TagAddress AS TagAddress,   ts.TankName AS [Description],Convert(varchar(10),Convert(int,( ts.Size))) AS Value,   
ts.LastModifiedTime , 'Size',tt.DataType,1
,'Size-Size_Display' as OriginalColumnName,'[TCD].[TankSetup]' as EntityName,tt.TagType as TagType, 0 as ControllerEquipmentSetupId  , 0 as SortingOrder

FROM   TCD.ModuleTags mt INNER JOIN TCD.TankSetup ts ON ts.TankId=mt.ModuleId
Inner Join tcd.TagType tt on mt.TagType = tt.TagType

WHERE   mt.ModuleTypeId=@TankModuleTypeId    AND ts.ControllerId=@ControllerId     AND mt.Active=@Active    AND mt.TagType='Tag_SIZ' 
UNION

SELECT ts.TankId,mt.TagAddress,ts.TankName,Convert(varchar(100),Convert(int,( ts.LevelDeviation_Display))),ts.LastModifiedTime ,'Dead Band',tt.DataType,1
,'LevelDeviation-LevelDeviation_Display' as OriginalColumnName,'[TCD].[TankSetup]' as EntityName,tt.TagType as TagType, 0 as SortingOrder, 0 as ControllerEquipmentSetupId  

FROM    TCD.ModuleTags mt 
INNER JOIN  TCD.TankSetup ts ON ts.TankId=mt.ModuleId
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE   mt.ModuleTypeId=@TankModuleTypeId 
    AND ts.ControllerId=@ControllerId 
    AND mt.Active=@Active 
    AND mt.TagType='Tag_DEV' 
UNION
----------------------------------------
---- Meter---
----------------------------------------

----------------------------------------
---- Sensor---
----------------------------------------
SELECT s.SensorId,mt.TagAddress,s.[Description],CONVERT(VARCHAR(100),CAST(s.Calibration4mA as float)),s.LastModifiedTime ,'Calibration4mA',tt.DataType,3
,'Calibration4mA' as OriginalColumnName,'[TCD].[Sensor]' as EntityName,tt.TagType as TagType, 0 as ControllerEquipmentSetupId, 0 as SortingOrder  
from TCD.ModuleTags mt INNER JOIN TCD.Sensor s ON MT.ModuleId=s.SensorId 
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE mt.ModuleTypeId=@SensorModuleTypeId AND s.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_SC4'

UNION

SELECT s.SensorId,mt.TagAddress,s.[Description],CONVERT(VARCHAR(100),CAST(s.Calibration20mA as float)),s.LastModifiedTime , 'Calibration20mA',tt.DataType,3
,'Calibration20mA' as OriginalColumnName,'[TCD].[Sensor]' as EntityName,tt.TagType as TagType, 0 as ControllerEquipmentSetupId, 0 as SortingOrder  
from TCD.ModuleTags mt INNER JOIN TCD.Sensor s ON MT.ModuleId=s.SensorId 
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE mt.ModuleTypeId=@SensorModuleTypeId AND s.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_SC20' 
UNION
--------------------------------------
-- Pumps---
--------------------------------------



SELECT  Convert(int, ces.ControllerEquipmentSetupId), mt.TagAddress,'P/V'+Convert(varchar(100), ces.ControllerEquipmentId),
Convert(varchar(100),Convert(float, ces.KFactor * @FactorMultiplier)),ces.LastModifiedTime ,'K-Factor',tt.DataType,2
,'KFactor' as OriginalColumnName,'[TCD].[ControllerEquipmentSetup]' as EntityName,tt.TagType as TagType, ControllerEquipmentId as ControllerEquipmentSetupId, 1 as SortingOrder   

FROM TCD.ModuleTags mt INNER JOIN TCD.ControllerEquipmentSetup ces ON mt.ModuleId=ces.ControllerEquipmentSetupId 
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE mt.ModuleTypeId=@PumpModuleTypeId AND ces.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_PPOL'
UNION
SELECT  Convert(int, ces.ControllerEquipmentSetupId), mt.TagAddress,'P/V'+Convert(varchar(100), ces.ControllerEquipmentId),
Convert(varchar(100),Convert(float, ces.PumpCalibration *@TimeVolumeMultipler)),ces.LastModifiedTime, 'Time Volume Calibration',tt.DataType,2
,'PumpCalibration' as OriginalColumnName,'[TCD].[ControllerEquipmentSetup]' as EntityName,tt.TagType as TagType , ControllerEquipmentId as  ControllerEquipmentSetupId, 3 as SortingOrder 
FROM TCD.ModuleTags mt INNER JOIN TCD.ControllerEquipmentSetup ces ON mt.ModuleId=ces.ControllerEquipmentSetupId
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE mt.ModuleTypeId=@PumpModuleTypeId AND ces.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_OPSL'
UNION

SELECT Convert(int, ces.ControllerEquipmentSetupId), mt.TagAddress,'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
ces.LfsChemicalName,ces.LastModifiedTime ,'LFS Chemical Name',tt.DataType,2
,'LfsChemicalName' as OriginalColumnName,'[TCD].[ControllerEquipmentSetup]' as EntityName,tt.TagType as TagType, ControllerEquipmentId as ControllerEquipmentSetupId  , 2 as SortingOrder 

FROM TCD.ModuleTags mt INNER JOIN TCD.ControllerEquipmentSetup ces ON mt.ModuleId=ces.ControllerEquipmentSetupId
Inner Join tcd.TagType tt on mt.TagType = tt.TagType 
WHERE mt.ModuleTypeId=@PumpModuleTypeId AND ces.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_NML' 
UNION

SELECT csd.ControllerId ,ct.TagAddress,NULL,csd.[Value],cc.LastModifiedTime , f.Label,tt.DataType,6
,'Value-'+CAST(csd.FieldId as varchar) as OriginalColumnName,'[TCD].[ControllerSetupData]' as EntityName,tt.TagType as TagType, 0 as ControllerEquipmentSetupId  , 0 as SortingOrder
FROM TCD.ControllerTags ct 
INNER JOIN TCD.ControllerSetupData csd ON csd.ControllerId = ct.ControllerId
INNER JOIN tcd.Field f ON f.Id = csd.FieldId AND ct.TagType=f.HasFieldTag
INNER JOIN TCD.ConduitController cc ON cc.ControllerId = ct.ControllerId
Inner Join tcd.TagType tt on ct.TagType = tt.TagType
WHERE ct.ControllerId=@ControllerId AND ct.Active=@Active

UNION

SELECT ces.ControllerEquipmentSetupId,
	   'stMachineConfig.xFlowSwitchType['+cast(ControllerEquipmentId AS varchar(20))+']' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  cast( FlowDetectorType AS varchar(20)) AS Value, 
	   ces.LastModifiedTime,
	   'Flow Detector Type' AS Lable,
	   'BIT' As DataType ,
	   2.1,
	   'FlowDetectorType' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stMachineConfig.xFlowSwitchType' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 5 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3


UNION --Flow Switch Alarm
SELECT ces.ControllerEquipmentSetupId,
	   'stMachineConfig.xFlowAlarmOverride['+cast(ControllerEquipmentId AS varchar(20))+']' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  Cast( ces.FlowSwitchAlarm  AS varchar(20)) AS Value, 
	   ces.LastModifiedTime,
	   'Flow Switch Alarm' AS Lable,
	   'BIT' As DataType ,
	   2.2,
	   'FlowSwitchAlarm' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stMachineConfig.xFlowAlarmOverride' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId , 10 as SortingOrder 
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3
UNION --Flow Meter Alarm
SELECT ces.ControllerEquipmentSetupId,
	   'stMachineConfig.xFlowMeterAlarmOverride['+cast(ControllerEquipmentId AS varchar(20))+']' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	 cast(  ces.FlowMeterAlarm  AS varchar(20)) AS Value, 
	   ces.LastModifiedTime,
	   'Flow Meter Alarm' AS Lable,
	   'BIT' As DataType ,
	   2.3,
	   'FlowMeterAlarm' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stMachineConfig.xFlowMeterAlarmOverride' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 6 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3
UNION --Flow Meter Type
     
SELECT ces.ControllerEquipmentSetupId,
	   'stPumpConfig['+cast(ControllerEquipmentId AS varchar(20))+'].eFlowMeterMode' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  cast( ces.FlowMeterType  AS varchar(20))  AS Value, 
	   ces.LastModifiedTime,
	   'Flow Meter Type' AS Lable,
	   'INT' As DataType ,
	   2.4,
	   'FlowMeterType' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stPumpConfig.eFlowMeterMode' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 9 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3

UNION --Flow Alarm Delay Time
SELECT ces.ControllerEquipmentSetupId,
	   'stPumpConfig['+cast(ControllerEquipmentId AS varchar(20))+'].fLossOfFlowDuration' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  cast( ces.FlowAlarmDelay  AS varchar(20))  AS Value, 
	   ces.LastModifiedTime,
	   'Flow Alarm Delay Time' AS Lable,
	   'FLOAT' As DataType ,
	   2.5,
	   'FlowAlarmDelay' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stPumpConfig.fLossofFlowDuration' TagType, ces.ControllerEquipmentId  as ControllerEquipmentSetupId, 4 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3
UNION --Flow Meter Pump Delay
SELECT ces.ControllerEquipmentSetupId,
	   'stPumpConfig['+cast(ControllerEquipmentId AS varchar(20))+'].fTdFlowMeter' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  cast( ces.FlowMeterPumpDelay  AS varchar(20))  AS Value, 
	   ces.LastModifiedTime,
	   'Flow Meter Pump Delay' AS Lable,
	   'FLOAT' As DataType ,
	   2.6,
	   'FlowMeterPumpDelay' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stPumpConfig.fTdFlowMeter' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 8 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3

UNION -- Flow Meter Alarm Delay
SELECT ces.ControllerEquipmentSetupId,
	   'stPumpConfig['+cast(ControllerEquipmentId AS varchar(20))+'].fTAlarmDelayFlowMeter' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  cast( ces.FlowMeterAlarmDelay  AS varchar(20))  AS Value, 
	   ces.LastModifiedTime,
	   'Flow Meter Alarm Delay' AS Lable,
	   'FLOAT' As DataType ,
	   2.7,
	   'FlowMeterAlarmDelay' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stPumpConfig.fTAlarmDelayFlowMeter' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 7 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3



SELECT  ttmd.Id  
   ,ttmd.TagAddress  
   ,isnull(ttmd.[Description],'')
   ,ttmd.Value  
   ,ttmd.LastModifiedTime  
   ,ttmd.ColName
   ,ttmd.DataType
   ,ttmd.OriginalColumnName
	,ttmd.EntityType 
	,ttmd.TagType,ttmd.SortingOrder,ttmd.ControllerEquipmentSetupId  FROM dbo.#tmpTagManagementDetails ttmd WHERE ttmd.[Value] IS  NOT NULL AND ttmd.[Value]<> '' ORDER BY ttmd.RowNumber

END
GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[SaveWasherTags]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.SaveWasherTags
	END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[SaveWasherTags]	
					@EcolabAccountNumber	NVARCHAR(1000)
				,	@WasherId			INT
				 ,	@TagDescription		NVARCHAR(100)
				 ,	@TagAddress			NVARCHAR(50)
				 ,	@Count				INT
				 ,	@ConventionalTagId	VARCHAR(100) OUTPUT
				 

AS
BEGIN
SET	NOCOUNT	ON


DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''

	,	@WasherTagId					INT
	,	@TagType						NVARCHAR(50)

SET		@ConventionalTagId			=			ISNULL(@ConventionalTagId, NULL)			--SQLEnlight SA0121
SET		@Count						=			ISNULL(@Count, NULL)						--SQLEnlight SA0029

-- getting the tagtype based on the tag description
SELECT @TagType=(SELECT TagType FROM [TCD].TagType WHERE TagDescription =@TagDescription)
IF(@TagType!='Tag_WSNO')
	BEGIN
		IF EXISTS (SELECT 1 FROM [TCD].WasherTags WT WHERE WT.WasherId=@WasherId AND WT.TagType=@TagType AND WT.EcolabAccountNumber = @EcolabAccountNumber)
			BEGIN
			UPDATE [TCD].WasherTags SET		TagAddress=@TagAddress	WHERE		WasherId=@WasherId		 AND		TagType=@TagType AND EcolabAccountNumber=@EcolabAccountNumber
			
			END
		ELSE
			BEGIN
				IF (SELECT COUNT(*) FROM [TCD].[WasherTags] WHERE EcolabAccountNumber=@EcolabAccountNumber) >0
					SELECT @WasherTagId=(SELECT MAX(WasherTagId)+1 FROM [TCD].WasherTags WHERE EcolabAccountNumber=@EcolabAccountNumber)
				ELSE
					SELECT @WasherTagId=1

				INSERT [TCD].WasherTags (EcolabAccountNumber	,WasherTagId		,WasherId		,TagType		,TagAddress		,Active) 
				VALUES					(@EcolabAccountNumber	,@WasherTagId		,@WasherId		,@TagType		,@TagAddress	,1)
			END
	END

SET	@ErrorId	=	@@ERROR
	
IF	(@ErrorId	<>	0)
	BEGIN
			IF	@@TRANCOUNT	>	0
			BEGIN
				ROLLBACK	TRAN
			END

			SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred creating new washer tags. '
			RAISERROR	(@ErrorMessage, 16, 1)
			SET		@ReturnValue	=	-1
			RETURN	(@ReturnValue)
	END
ELSE
	BEGIN
			SET @ConventionalTagId = '101'         
	END
END
GO
-------------

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetRedFlagDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetRedFlagDetails
	END
GO
CREATE PROCEDURE [TCD].[GetRedFlagDetails]
(
		@Id INT = NULL
	,	@EcolabAccountNumber nvarchar(25) 
)
AS
BEGIN
SET NOCOUNT ON;

DECLARE @PlantId INT,@RegionId int ,@LanguageId int,@UOMEndPart varchar(100),@UOM7 nvarchar(1000), @UOM8 nvarchar(1000)
 SELECT @PlantId=PlantId ,@RegionId=RegionId,@LanguageId=LanguageId
		FROM TCD.Plant 
		WHERE EcolabAccountNumber=@EcolabAccountNumber
IF(@RegionId=1)
BEGIN
	SET @UOMEndPart='CWT'
END
ELSE
BEGIN
	SET @UOMEndPart='kg'
END

SELECT @UOM7 = rkv.[Value]
FROM TCD.Meter m 
LEFT JOIN tcd.ResourceKeyValue rkv on m.MeterTickUnit=rkv.KeyName and LanguageId=@LanguageId
WHERE m.GroupId IS NULL AND m.UtilityType in (1,2)

SELECT @UOM8 = rkv.[Value]
FROM TCD.Meter m 
LEFT JOIN tcd.ResourceKeyValue rkv on m.MeterTickUnit=rkv.KeyName and LanguageId=@LanguageId
WHERE m.GroupId IS NULL AND m.UtilityType IN(1)

SELECT
		PR.Id
	,	ItemID = PR.Item
	,	IL.ItemName 
	,	PR.MinimumRange
	,	PR.MaximumRange
	,	
		(CASE WHEN PR.Item IN (7,8) THEN (CASE WHEN isnull( PR.MeterId,0) !=0 then   rkv.[Value] +'/'+@UOMEndPart 
												WHEN PR.Item =7 THEN @UOM7 +'/'+@UOMEndPart 
												WHEN PR.Item =8 THEN @UOM8 +'/'+@UOMEndPart 
											END )
				ELSE (CASE @RegionId WHEN 1 THEN IL.UOMNA WHEN 2 THEN IL.UOMEurope END) 
			END) AS UOM
	,	LocationID = PR.Location
	,	GT.GroupDescription LocationName 
	,	PR.EcolabAccountNumber
	,	(SELECT STUFF((select DISTINCT ','+ CAST(IsNull(MachineId,-1) AS VARCHAR(1000)) from [TCD].RedFlagMappingData MD WHERE MD.MappingID = PR.ID AND MD.Is_Deleted = 0 FOR XML PATH('')  ) ,1,1,'')) as MachineID
	,	(SELECT LTRIM(ISNULL(STUFF((select DISTINCT ', '+
			(SELECT
				CASE WHEN( SELECT DISTINCT Istunnel FROM [TCD].machinesetup S WHERE S.groupId = PR.Location)= 1 THEN
				CASE WHEN (SELECT RD.MachineId FROM [TCD].RedFlag MM INNER JOIN [TCD].RedFlagMappingData RD ON MM.Id = RD.MappingId WHERE RD.MachineId = MD.MachineId AND RD.MachineId = 0 AND RD.Is_Deleted = 0) = 0 THEN 'Press'
				ELSE
				'Compartment' + CAST( MD.MachineId -1 AS varchar( 100)) END
				WHEN( SELECT DISTINCT Istunnel FROM [TCD].machinesetup S WHERE S.groupId = PR.Location)= 0 THEN (SELECT TOP(1) CAST(WS.PlantWasherNumber AS nvarchar)+':'+MS.MachineName FROM TCD.MachineSetup MS INNER JOIN TCD.Washer WS ON MS.WasherId = WS.WasherId WHERE MS.GroupId = PR.Location AND MS.WasherId = MD.MachineId)
				WHEN (SELECT DISTINCT GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.Id = PR.Location ) = 3 THEN
				(SELECT Description FROM [TCD].Dryers D WHERE D.DryerGroupId = PR.Location AND D.DryerNo =  MD.MachineId AND D.Is_deleted = 0)
				WHEN (SELECT DISTINCT GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.Id = PR.Location ) = 4 THEN
				(SELECT Name FROM [TCD].Finnishers F WHERE F.FinnisherGroupId = PR.Location AND F.FinnisherNo =  MD.MachineId AND F.Is_deleted = 0)
			END)
		FROM 
		[TCD].RedFlagMappingData MD  
	WHERE 
	MD.MappingID = PR.ID 
	AND 
	MD.Is_Deleted = 0
		FOR XML PATH('')  ) ,1,1,''),'ALL'))) as MachineName
 , PR.RedFlagCategoryId AS CategoryId  
, PR.FormulaId AS FormulaId  
, PM.Name AS FormulaName     
, PR.ProductId   
, PRM.Name AS ProductName  
, isnull( PR.MeterId  ,s.SensorId) MeterId
, (CASE WHEN isnull( PR.MeterId,0)!=0 THEN ME.Description ELSE s.Description END)AS MeterName  
,PR.LastModifiedTime
,PR.LastSyncTime
,PR.Is_Deleted
FROM  
[TCD].RedFlag PR
INNER JOIN [TCD].RedFlagItemList IL ON PR.Item = IL.Id
LEFT JOIN TCD.WasherProgramSetup WPS ON WPS.WasherGroupId = PR.Location AND WPS.WasherProgramSetupId = PR.FormulaId AND WPS.Ecolabaccountnumber = @Ecolabaccountnumber
LEFT JOIN TCD.TunnelProgramSetup TPS ON TPS.WasherGroupId = PR.Location AND TPS.TunnelProgramSetupId = PR.FormulaId AND TPS.Ecolabaccountnumber = @Ecolabaccountnumber
LEFT JOIN tcd.ProgramMaster AS PM ON PM.ProgramId = (CASE WHEN WPS.WasherProgramSetupId IS NOT NULL THEN WPS.ProgramId ELSE TPS.ProgramId END) --Identify whether its tunnel or washer formula
LEFT JOIN TCD.ProductMaster AS PRM ON PRM.ProductId = PR.ProductId   
LEFT JOIN TCD.Meter AS ME ON ME.MeterId = PR.MeterId  AND ME.EcolabAccountNumber = @Ecolabaccountnumber      
LEFT JOIN TCD.RedFlagCategory AS RFC ON RFC.RedFlagCategoryId = PR.RedFlagCategoryId   
INNER JOIN [TCD].MachineGroup GT ON PR.Location = GT.Id  
LEFT JOIN tcd.ResourceKeyValue rkv on ME.MeterTickUnit=rkv.KeyName and LanguageId=@LanguageId
LEFT JOIN TCD.Sensor s ON s.SensorId = PR.SensorId
WHERE 
PR.PlantId = @PlantId
AND 
PR.Is_Deleted=0 
AND GT.Is_Deleted = 0
AND 
CASE ISNULL(@Id,'') WHEN '' THEN 'TRUE' ELSE CASE WHEN PR.Id = @Id THEN 'TRUE' END END = 'TRUE'
SET NOCOUNT OFF;
END
GO

UPDATE tcd.LanguageMaster
	SET Name = N'中文'
	WHERE LanguageId = 6
	
UPDATE tcd.LanguageMaster
	SET Name = N'한국어'
	WHERE LanguageId = 9
	
UPDATE tcd.LanguageMaster
	SET Name = N'日本語'
	WHERE LanguageId = 12
	
UPDATE tcd.LanguageMaster
	SET Name = N'Русский язык'
	WHERE LanguageId = 11
GO


IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[ReportProductionSummary]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[ReportProductionSummary] 
END 
GO 

CREATE PROCEDURE [TCD].[ReportProductionSummary]
	
     @startdate datetime = '',
     @enddate datetime = '',
     @Viewtype varchar(30) = '',
     @Subview varchar(30)= '',
     @Drillvalue varchar(100)= '',
     @EcolabAccountNumber Nvarchar(25) = '',
     @MachineType VARCHAR(20)= '',
     @MachineGroup VARCHAR(MAX) = '',
     @Machine VARCHAR(MAX) = '',
     @EcolabCategory VARCHAR(MAX) = '',
     @ChainCategory VARCHAR(MAX) = '',
     @PlantFormula  VARCHAR(MAX) = '',
     @ChainFormula VARCHAR(MAX) = '',
     @Customer VARCHAR(MAX) = '',
     @SortColumnId int = 0,
     @SortDirection varchar(4) = '',
     @CurrencyCode varchar(3) = '',
     @UserId INT = NULL,
	 @FormulaSegement VARCHAR(MAX)='', --Formula segment,
	 @FormulaCategory VARCHAR(MAX)='', --Formula category
	 @Formula VARCHAR(MAX)='' --Formula
AS   
BEGIN   
SET NOCOUNT ON 

	SET @startdate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@startdate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@startdate AS time)) AS DateTime))
	SET @EndDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndDate AS time)) AS DateTime))
 
	DECLARE @ReportGenerated INT = 6,
    @Month INT = MONTH(GETDATE()),@CorrectionVariable Decimal(18,2),@PlantTargetProduction decimal(18,2)
    --,@ShiftRuntime int,@NoShiftTotalRuntime INT,@TotaRuntime int

	-- Inserting the record into Report History 
	INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)
	SELECT @EcolabAccountNumber,UM.UserId,UM.LoginName,GETUTCDATE(),@ReportGenerated,
	CASE WHEN @ReportGenerated = 6
		THEN 'Generated Report : Production Summary Report' END
	FROM TCD.UserMaster UM
	WHERE UM.EcolabAccountNumber = @EcolabAccountNumber AND UM.UserId = @UserId
	/* Completed the record insertion into Report History */ 

    -- Return Table set
    DECLARE @resultSet Table
    (
      ShiftId Int,
      DateRange varchar(100),
      TotalLoad Decimal(18,2) ,
      WasherEfficiency Decimal(18,2),
      PlantTargetLoad Decimal(18,2) ,
      Numberofbatches INT,
      [ActualRunTime] [int] NULL,
      [TargetRunTime] [int] NULL,
      Viewtype varchar(100) NULL,
      Subview varchar(100) NULL,
      Id int NULL      
    )
    DECLARE @CorrectionFactor TABLE 
	(
	[ShiftId] [int] NULL,
	MachineId INT NULL,
	[ActualProduction] [int] NULL,
	[StandardProduction] [int] NULL,
	[PlantTargetProd] [int] NULL,
	[ActualRunTime] [int] NULL,
	[TargetRunTime] [int] NULL,
	ManualInputWeight INT,
	ManulainputsNoofloads INT
	)

	DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))
	INSERT INTO @MachineTypeTable EXEC [TCD].[CharlistToTable] @MachineType,','

	DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))
	INSERT INTO @WasherGroupTable EXEC [TCD].[CharlistToTable] @machineGroup,','  

	DECLARE @MachineTable TABLE(Machine Varchar(100))
	INSERT INTO @MachineTable EXEC [TCD].[CharlistToTable] @Machine,','

	DECLARE @EcolabCategoryTable TABLE(EcolabCategory Varchar(100))
	INSERT INTO @EcolabCategoryTable EXEC [TCD].[CharlistToTable] @EcolabCategory,','

	DECLARE @ChainCategoryTable TABLE(ChainCategory Varchar(100))
	INSERT INTO @ChainCategoryTable EXEC [TCD].[CharlistToTable] @ChainCategory,','

	DECLARE @PlantFormulaTable TABLE(PlantFormula Varchar(100))
	INSERT INTO @PlantFormulaTable EXEC [TCD].[CharlistToTable] @PlantFormula,','

	DECLARE @ChainFormulaTable TABLE(ChainFormula Varchar(100))
	INSERT INTO @ChainFormulaTable EXEC [TCD].[CharlistToTable] @ChainFormula,','

	DECLARE @CustomerTable TABLE(Customer Varchar(100))
	INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','

	--Formula Segment --added by Kiran
	DECLARE @FormulaSegmentTable TABLE(FormulaSegment Varchar(1000))
    INSERT INTO @FormulaSegmentTable EXEC [TCD].[CharlistToTable] @FormulaSegement,','

	--Formula category
	DECLARE @FormulaCategoryTable TABLE(FormulaCategory Varchar(1000),Type CHAR(1))
    INSERT INTO @FormulaCategoryTable(FormulaCategory) EXEC [TCD].[CharlistToTable] @Formulacategory,','	
		
		--Below 1000 Ecolab category
		UPDATE @FormulaCategoryTable SET TYPE='E' WHERE FormulaCategory<1000
		--Above 1000 consider as Chain category
		UPDATE @FormulaCategoryTable SET TYPE='C' WHERE FormulaCategory>=1000

		--Rollbacking to actual ID
		UPDATE @FormulaCategoryTable SET FormulaCategory=FormulaCategory-1000 WHERE TYPE='C'
	
		--SELECT * FROM @FormulaCategoryTable

		INSERT INTO @EcolabCategoryTable(EcolabCategory)
		SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='E'	

		INSERT INTO @ChainCategoryTable(ChainCategory)
		SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='C'

		--Value Assigning
		IF (EXISTS(SELECT * FROM @EcolabCategoryTable) AND @FormulaCategory!='')
		BEGIN
			SET @EcolabCategory=@FormulaCategory
		END
		IF (EXISTS(SELECT * FROM @ChainCategoryTable) AND @FormulaCategory!='')
		BEGIN
			SET @ChainCategory=@FormulaCategory
		END

	-----Formula Ecolab/Chain categories
	DECLARE @FormulaTable TABLE(Formula Varchar(1000),Type CHAR(1))
    INSERT INTO @FormulaTable(Formula) EXEC [TCD].[CharlistToTable] @Formula,','	
						
		--Plant fomula   
		INSERT INTO @PlantFormulaTable(PlantFormula) 
		SELECT Formula FROM @FormulaTable 
		--chain formula   
		INSERT INTO @ChainFormulaTable(ChainFormula) 
		SELECT Formula FROM @FormulaTable 
		--SELECT * FROM @PlantFormulaTable
		--SELECT * FROM @ChainFormulaTable

		--Value Assigning
		IF (EXISTS(SELECT * FROM @PlantFormulaTable) AND @Formula!='')
		BEGIN
			SET @PlantFormula=@Formula
		END
		IF (EXISTS(SELECT * FROM @ChainFormulaTable) AND @Formula!='')
		BEGIN
			SET @ChainFormula=@Formula
		END
	--Formula end

	INSERT INTO @CorrectionFactor
	(
			[ShiftId],
			[MachineId] ,
			[ActualProduction] ,
			[StandardProduction] ,
			[PlantTargetProd] ,
			[ActualRunTime] ,
			[TargetRunTime],
			ManualInputWeight,
			ManulainputsNoofloads		 
	)
	SELECT 
		PS.[ShiftId],
		SPD.[MachineId],
		ISNULL([TCD].[FnConsumptionOnMetrics](SUM(ISNULL(SPD.[ActualProduction],0))+SUM(ISNULL(MIP.ActualWeight,0)),'Weight',@UserId),0),
		--ISNULL([TCD].[FnConsumptionOnMetrics](SUM(SPD.[ActualProduction]),'Weight',@UserId),0),
		--SUM(SPD.[ActualProduction]),
		ISNULL([TCD].[FnConsumptionOnMetrics](SUM(SPD.StandardProduction),'Weight',@UserId),0),
		--SUM(SPD.StandardProduction),
		ISNULL([TCD].[FnConsumptionOnMetrics](SUM(DISTINCT SPD.[PlantTargetProd]),'Weight',@UserId),0),
		--SUM(DISTINCT SPD.[PlantTargetProd]),
		SUM(SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0)),
		SUM(SPD.[TargetRunTime] + ISNULL(SPD.TargetTurnTime,0)),
		SUM(ISNULL(MIP.ActualWeight,0)),SUM(ISNULL(MIP.NoofLoads,0))
	FROM  TCD.ShiftProductionDataRollup SPD 
	INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId
	INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId 
	LEFT OUTER JOIN --Manual Production Details appending
		(
		SELECT WasherId,FormulaId,CONVERT(DATE,RecordedDate) AS LoadDate,SUM(ISNULL(Value,0)) AS ActualWeight,
		ISNULL(COUNT(CONVERT(DATE,RecordedDate)),0) AS NoofLoads FROM
		TCD.ManualProduction MP
		GROUP BY WasherId,FormulaId,CONVERT(DATE,RecordedDate)
		)MIP ON MIP.WasherId=SPD.EcolabWasherId AND MIP.FormulaId=SPD.ProgramMasterId AND MIP.LoadDate=CONVERT(DATE,PS.StartDateTime)
	WHERE 
	CASE @StartDate                                                                                
	WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
	ELSE CASE WHEN PS.[StartDateTime] >= @startdate  AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
	END='TRUE' 
	GROUP BY MachineId,PS.ShiftId;

	--SELECT * FROM 	@CorrectionFactor;
	

	WITH CTE (PlantTargetProd) AS
	(
	SELECT SUM(DISTINCT SPD.[PlantTargetProd]) FROM @CorrectionFactor SPD GROUP BY ShiftId
	)
	SELECT @PlantTargetProduction = SUM(PlantTargetProd) FROM CTE;


	WITH CTE (MachineId,PlantEfficiency)
	AS
	(
	SELECT 
		MachineId,
		CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
			NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
			COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2))   
		 FROM @CorrectionFactor SPD GROUP BY MachineId
	)
    SELECT @CorrectionVariable = @PlantTargetProduction/NULLIF(SUM(PlantEfficiency),0) FROM CTE

	
	DECLARE @ProductionSummaryTable TABLE(
         [ShiftId] [int] NULL,
         [ShiftName] Varchar(100) NULL,
         RecordDate date, 
         [StartDateTime] [datetime] NULL,
         [EndDateTime] [datetime] NULL,
         [MachineId] [int] NULL,
         [EcolabWasherId] [int] NULL,
         [ActualProduction] [int] NULL,
         [StandardProduction] [int] NULL,
         [NoOfLoads] [int] NULL,
         [LoadEfficiency] [decimal](18, 2) NULL,
         [TimeEfficiency] [decimal](18, 2) NULL,
         TotalEfficiency [decimal](18, 2) NULL,
         [PlantTargetProd] [int] NULL,
         [ActualRunTime] [int] NULL,
         [TargetRunTime] [int] NULL,
         [ShiftRunTime] [int] NULL,
		 RowNumberID INT NULL,
		 ProgramMasterID INT NULL,
		 EcolabTextileId int,
		 ChainTextileId int,
		 ChainProgaramId int,
		 FormulaSegmentID INT,
		 CustomerId int 
             )
	INSERT INTO @ProductionSummaryTable
	(
	[ShiftId] ,[ShiftName] ,RecordDate, [StartDateTime] ,[EndDateTime] ,[MachineId]  ,[EcolabWasherId]  ,
	[ActualProduction] ,[StandardProduction] ,[NoOfLoads] ,[LoadEfficiency],[TimeEfficiency] ,TotalEfficiency ,
	[PlantTargetProd],[ActualRunTime] ,[TargetRunTime] ,[ShiftRunTime] ,RowNumberID ,ProgramMasterID,
	EcolabTextileId,ChainTextileId,ChainProgaramId,FormulaSegmentID,CustomerId
	)
    SELECT 
	SPD.[ShiftId],
	PS.ShiftName,
	CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date),
	DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]),
	DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[EndDateTime]),        
	SPD.[MachineId],
	SPD.[EcolabWasherId],
	SPD.[ActualProduction],
	SPD.StandardProduction,
	SPD.[NoOfLoads],
	SPD.[LoadEfficiency],
	SPD.[TimeEfficiency],
	(SPD.[LoadEfficiency] * SPD.TimeEfficiency),
	SPD.[PlantTargetProd],
	SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0),
	SPD.[TargetRunTime] + ISNULL(SPD.TargetTurnTime,0),
	DATEDIFF(Second,ps.StartDateTime,PS.EndDateTime) +
	ISNULL(
	(
	SELECT
	SUM(SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0))
		FROM TCD.ShiftProductionDataRollup SPD 
	INNER JOIN TCD.ProductionShiftData PSD ON SPD.ShiftId = PSD.ShiftId
	INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId 
	WHERE 
	PSD.[StartDateTime] = PS.StartDateTime AND PSD.[StartDateTime] = PS.EndDateTime AND PS.ShiftName = 'No Shift'
	),0),
	ROW_NUMBER() OVER(Partition BY SPD.ProgramMasterId, SPD.[EcolabWasherId], CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date)
	ORDER BY SPD.ProgramMasterId, SPD.[EcolabWasherId] ),
	SPD.ProgramMasterId,
	SPD.EcolabTextileId,SPD.ChainTextileId,SPD.ChainProgaramId,
    CASE WHEN SPD.ChainProgaramId IS NOT NULL THEN ChainPlant.FormulaSegmentId
	ELSE FS1.FormulaSegmentID END AS Formulasegment,
	SPD.CustomerId

	FROM TCD.ShiftProductionDataRollup SPD 
	INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId
	INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
	INNER JOIN TCD.MachineSetup ms ON SPD.MachineId = ms.WasherId
	LEFT OUTER JOIN
		 (
			--IF Chain Plant
			SELECT PCP.PlantProgramId,PCP.PlantChainId,PCP.ChainTextileCategoryId,PCP.EcolabTextileCategoryId,
			PCP.FormulaSegmentId,PCP.EcolabSaturationId
			FROM TCD.PlantChainProgram PCP 
			LEFT OUTER JOIN TCD.ChainTextileCategory CTC ON CTC.TextileId=PCP.ChainTextileCategoryId
			LEFT OUTER JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId=PCP.EcolabTextileCategoryId
			LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=PCP.FormulaSegmentId
			LEFT OUTER JOIN TCD.EcolabSaturation ES ON ES.EcolabSaturationId=PCP.EcolabSaturationId
		 )ChainPlant ON SPD.ChainProgaramId=ChainPlant.PlantProgramId

	LEFT OUTER JOIN TCD.EcolabTextileCategory ETC1 ON ETC1.TextileId=PM.EcolabTextileCategoryId
	LEFT OUTER JOIN TCD.FormulaSegments FS1 ON FS1.FormulaSegmentID=PM.FormulaSegmentId
	LEFT OUTER JOIN TCD.EcolabSaturation ES1 ON ES1.EcolabSaturationId=PM.EcolabSaturationId
    WHERE isNull(ms.IsPony,0) = 0
    AND 
       CASE @StartDate                                                                                
       WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
       ELSE CASE WHEN PS.[StartDateTime] >= @startdate AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
       END='TRUE'

     AND
       CASE @MachineType   
       WHEN '' THEN 'TRUE'         
       ELSE                                                      
       CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
       MS.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable))) THEN 'TRUE' END                                                      
       END='TRUE'     
     AND       

		CASE @machineGroup   
		WHEN '' THEN 'TRUE'         
		ELSE                                                      
		CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
		MS.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable)) THEN 'TRUE' END                                                      
		END='TRUE' 
	 AND

		CASE @Machine   
		WHEN '' THEN 'TRUE'         
		ELSE                                                      
		CASE WHEN SPD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
		END='TRUE' 
	 AND
    
		CASE @EcolabCategory   
		WHEN '' THEN 'TRUE'         
		ELSE                                                      
		CASE WHEN SPD.EcolabTextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                      
		END='TRUE' 
	 AND
    
		CASE @ChainCategory   
		WHEN '' THEN 'TRUE'         
		ELSE                                                      
		CASE WHEN SPD.ChainTextileId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END                                                      
		END='TRUE'
	 AND

		CASE @PlantFormula   
		WHEN '' THEN 'TRUE'         
		ELSE                                                      
		CASE WHEN SPD.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                      
		END='TRUE'  
	 AND
    
		CASE @ChainFormula   
		WHEN '' THEN 'TRUE'         
		ELSE                                                      
		CASE WHEN SPD.ProgramMasterId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END                                                      
		END='TRUE'
	 AND
    
		CASE @Customer   
		WHEN '' THEN 'TRUE'         
			ELSE                                                      
			CASE WHEN SPD.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                      
		END='TRUE' 
	--Added by Kiran	
    AND 
		CASE @FormulaSegement                                                                                
		WHEN '' THEN  'TRUE'
		ELSE
			CASE WHEN SPD.ChainProgaramId  IS NOT NULL THEN
				CASE WHEN ChainPlant.FormulaSegmentId IN (SELECT FormulaSegment FROM @FormulaSegmentTable) THEN 'TRUE' END						                                                                               
			ELSE 
				CASE WHEN FS1.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)  THEN 'TRUE'END   
			END                                                     
		END='TRUE'

	--Updating Actual Production based Manual Production
	UPDATE S SET ActualProduction=ISNULL(S.ActualProduction,0)+ISNULL(MIP.ManualIPActualWeight,0),S.NoOfLoads=ISNULL(S.NoOfLoads,0)+ISNULL(MIP.NoofLoads,0)
	FROM  @ProductionSummaryTable S
	INNER JOIN 
		(
		SELECT WasherId,FormulaId,CONVERT(DATE,RecordedDate) AS LoadDate,SUM(Value) AS ManualIPActualWeight,
		COUNT(CONVERT(DATE,RecordedDate)) AS NoofLoads FROM
		TCD.ManualProduction MP
		GROUP BY WasherId,FormulaId,CONVERT(DATE,RecordedDate)
		)MIP ON MIP.WasherId=S.MachineId AND MIP.FormulaId=S.ProgramMasterId AND MIP.LoadDate=S.RecordDate
		WHERE S.RowNumberID=1



    IF(@Viewtype = 1)
    BEGIN
        ---- By TimeLine - Day View-------------
		IF(@Subview = 5)
		BEGIN
			INSERT INTO @resultSet
			SELECT 
				0,
				SPD.ShiftName,
				SUM(SPD.ActualProduction),
				COALESCE(SUM(SPD.ActualProduction)/ 
				NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),
				SUM(DISTINCT SPD.PlantTargetProd),
				SUM([NoOfLoads]),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime)
				,@Viewtype 
				,@Subview
				,0
				FROM @ProductionSummaryTable SPD
			GROUP BY 
			SPD.ShiftName
		END

		---- By TimeLine - Week View
		IF (@Subview = 4)
		BEGIN
			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime)
			AS
			(
			  SELECT 
				 CAST(RecordDate AS nvarchar(100)),
				SUM(SPD.ActualProduction),
			   COALESCE(SUM(SPD.ActualProduction)/ 
				NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),
				SUM(DISTINCT SPD.PlantTargetProd),
				SUM([NoOfLoads]),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime)
					FROM @ProductionSummaryTable SPD
				 GROUP BY DATEPART(weekday,RecordDate),RecordDate,SPD.ShiftId  
			)

			INSERT INTO @resultSet
				SELECT  
					 0, 
					 DateRange,
					 SUM(TotalLoad),
					 SUM(TotalEfficiency),
					 SUM(PlantTargetLoad),
					 SUM(Numberofbatches),
					 SUM(ActualRunTime),
					 SUM(TargetRuntime)
					 ,@Viewtype 
					 ,@Subview
					  ,0
				 FROM CTE 
					WHERE TotalLoad IS NOT NULL
				GROUP BY DateRange
		END

        ---- By TimeLine - Month View
		IF(@Subview = 3)
		BEGIN
			DECLARE @FirstDay date = (SELECT TOP 1 RecordDate FROM @ProductionSummaryTable ORDER BY RecordDate)
			DECLARE @LastDay date = (SELECT TOP 1 RecordDate FROM @ProductionSummaryTable ORDER BY RecordDate DESC)
			DECLARE @FirstSunday date = NULL,
			@LastSaturday date = NULL

    
			SELECT 
			@FirstSunday = CAST(DateAdd(dd, (8-DatePart(WEEKDAY, 
			   DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)))%7, 
			   DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)) AS DATE) 

			 SELECT
			  @LastSaturday = 
				DATEADD(dd,
					-DATEPART(WEEKDAY,
					  DATEADD(dd, -DAY(DATEADD(month, 1, @LastDay)),
					  DATEADD(month, 1, @LastDay))) ,
					DATEADD(dd, -DAY(DATEADD(MONTH, 1, @LastDay)), DATEADD(MONTH, 1, @LastDay)));
    
			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime)
			AS
			(
			SELECT 
       
			   CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,-1,@FirstSunday)) = 7 
			   AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate < DATEADD(DD,-1,@FirstSunday)) = 0)
			   THEN CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100))
			   WHEN DATEADD(DD,-1,@FirstSunday) > CAST(GETDATE() AS DATE) 
			   THEN
			   CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @enddate, 101) AS nvarchar(100))
			   ELSE
			   CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) END As DateRange,
			   SUM(SPD.ActualProduction),
				COALESCE(SUM(SPD.ActualProduction)/ 
				NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),
				SUM(DISTINCT SPD.PlantTargetProd),
				SUM([NoOfLoads]),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime)
				FROM @ProductionSummaryTable SPD
				WHERE RecordDate < @FirstSunday AND RecordDate >= @FirstDay 
				GROUP BY SPD.ShiftId

        
				UNION ALL

  
				SELECT 
       
				--CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100)) AS StartDate,
				--CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) AS EndDate,
				  CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100))  + CHAR(13) + '-' +
				 CASE WHEN CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) >
				 CAST(Convert(varchar, DateAdd(dd, (1 - DatePart(dw, @enddate) + 1), @enddate), 101) AS nvarchar(100))
				 THEN  CAST(Convert(varchar, DateAdd(dd, 1-1, @enddate), 101) AS nvarchar(100))
				 ELSE CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) END
				 As DateRange,
				SUM(SPD.ActualProduction),
				COALESCE(SUM(SPD.ActualProduction)/ 
				NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),
				SUM(DISTINCT SPD.PlantTargetProd),
				SUM([NoOfLoads]),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime)
				FROM @ProductionSummaryTable SPD
				   WHERE RecordDate BETWEEN @FirstSunday AND @LastSaturday
				GROUP BY Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101),
				 Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101),SPD.ShiftId
       
			   UNION ALL

				SELECT 
       
				CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,1,@LastSaturday)) = 1 
				AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate > DATEADD(DD,1,@LastSaturday)) = 0)
				THEN 
				CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) 
				ELSE
			   CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @LastDay, 101) AS nvarchar(100)) END   As DateRange,
				SUM(SPD.ActualProduction),
				COALESCE(SUM(SPD.ActualProduction)/ 
				NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),
				SUM(DISTINCT SPD.PlantTargetProd),
				SUM([NoOfLoads]),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime)
				FROM @ProductionSummaryTable SPD
				WHERE RecordDate > @LastSaturday AND RecordDate <= @LastDay GROUP BY SPD.ShiftId
				)
				INSERT INTO @resultSet
				 SELECT  
				 0, 
				 DateRange,
				 SUM(TotalLoad),
				 SUM(TotalEfficiency),
				 SUM(PlantTargetLoad),
				 SUM(Numberofbatches),
				 SUM(ActualRunTime),
				 SUM(TargetRuntime)
				 ,@Viewtype 
				 ,@Subview
				  ,0
				 FROM CTE 
					WHERE TotalLoad IS NOT NULL
				GROUP BY DateRange

        END

		IF(@Subview = 2)
		BEGIN
			DECLARE @QuarterYear VARCHAR(100) = YEAR(@enddate);
			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime)
			AS
			(
				SELECT        
				DATENAME(MONTH, RecordDate) + ' ' + @QuarterYear As DateRange,
				SUM(SPD.ActualProduction),
				COALESCE(SUM(SPD.ActualProduction)/ 
				NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),
				SUM(DISTINCT SPD.PlantTargetProd),
				SUM([NoOfLoads]),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime)
				FROM @ProductionSummaryTable SPD
				GROUP BY  DATEPART(MONTH, RecordDate),DATENAME(MONTH, RecordDate),SPD.ShiftId

			)
			INSERT INTO @resultSet
			SELECT  
					  0, 
					  DateRange,
					  SUM(TotalLoad),
					  SUM(TotalEfficiency),
					  SUM(PlantTargetLoad),
					  SUM(Numberofbatches),
					  SUM(ActualRunTime),
					  SUM(TargetRuntime)
					  ,@Viewtype 
					  ,@Subview
					   ,0
				 FROM CTE 
					WHERE TotalLoad IS NOT NULL
				GROUP BY DateRange
		END   

		IF(@Subview = 1)
		BEGIN
			DECLARE @Year VARCHAR(100) = RIGHT(YEAR(@enddate),2);
			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime)
			AS
			(
				SELECT 
			   CASE 'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10))
					   WHEN 'Q1' THEN 'Jan' + @Year + '- Mar' + @Year
					   WHEN 'Q2' THEN 'Apr' + @Year + '- Jun' + @Year
					   WHEN 'Q3' THEN 'Jul' + @Year + '-Sep' + @Year
					   WHEN 'Q4' THEN 'Oct' + @Year + '- Dec'+ @Year
				END AS DateRange,
				SUM(SPD.ActualProduction),
				COALESCE(SUM(SPD.ActualProduction)/ 
				NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),
				SUM(DISTINCT SPD.PlantTargetProd),
				SUM([NoOfLoads]),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime)
				FROM @ProductionSummaryTable SPD
				GROUP BY DATEPART(QUARTER, RecordDate),SPD.ShiftId
			)

			INSERT INTO @resultSet
			SELECT  
					  0, 
					  DateRange,
					  SUM(TotalLoad),
					  SUM(TotalEfficiency),
					  SUM(PlantTargetLoad),
					  SUM(Numberofbatches),
					  SUM(ActualRunTime),
					  SUM(TargetRuntime)
					  ,@Viewtype 
					  ,@Subview
					   ,0
				 FROM CTE 
					WHERE TotalLoad IS NOT NULL
				GROUP BY DateRange
		END
    END
    
    -- ******************************** Location View ***************************************************
    IF(@Viewtype = 2)
    BEGIN

		IF(@Subview = 9)
		BEGIN

			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,WasherGroupId)
			AS
			(
				SELECT  
				--SPD.MachineId,    
			  WG.WasherGroupName,
			SUM(SPD.ActualProduction),
			CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
			NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
			COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
			SUM(DISTINCT SPD.PlantTargetProd),
			SUM([NoOfLoads]),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(DISTINCT SPD.ShiftRunTime),
			WG.WasherGroupId
			FROM @ProductionSummaryTable SPD LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId
					 LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId 
			GROUP BY WG.WasherGroupName,WG.WasherGroupId,SPD.ShiftId--,SPD.MachineId
			)

			 INSERT INTO @resultSet
			 SELECT  
			   0, 
			  DateRange,
			  SUM(TotalLoad),
			  SUM(TotalEfficiency),
			  @PlantTargetProduction,
			  SUM(Numberofbatches),
			  SUM(ActualRunTime),
			  SUM(TargetRuntime)
			  ,@Viewtype 
			  ,@Subview
			   ,WasherGroupId
				 FROM CTE 
					WHERE TotalLoad IS NOT NULL       
				GROUP BY DateRange,WasherGroupId
		END

		IF(@Subview = 10)
		BEGIN
			 WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime)
			AS
			(
				SELECT         
				cast( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName as MachineName,
				SUM(SPD.ActualProduction),
				CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
				NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
				COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
				SUM(DISTINCT SPD.PlantTargetProd),
				SUM([NoOfLoads]),
				SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime)        
				FROM @ProductionSummaryTable SPD 
		  LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId
		  LEFT JOIN TCD.Washer w on MS.WasherId=w.WasherId
					 LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId 
				WHERE 
			  (
			   CASE @drillvalue   
				   WHEN '' THEN 'TRUE'         
				   ELSE                                                    
					CASE WHEN WG.WasherGroupId IN (@drillvalue) THEN 'TRUE' END            
				   END='TRUE'
			  )
			 GROUP BY cast( W.PlantWasherNumber as varchar(20))+':'+MS.MachineName,SPD.ShiftId 
        
			)

			 INSERT INTO @resultSet
			 SELECT 
				0, 
			  DateRange,
			  SUM(TotalLoad),
			  SUM(TotalEfficiency),
			  @PlantTargetProduction,
			  SUM(Numberofbatches),
			  SUM(ActualRunTime),
			  SUM(TargetRuntime)
			  ,@Viewtype 
			  ,@Subview
			   ,0
				 FROM CTE 
					WHERE TotalLoad IS NOT NULL
				GROUP BY DateRange
		END

    END	
	 --******************************** Formula View ****************************************************
	IF(@Viewtype = 7)
	BEGIN
		 WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,WasherGroupId)
			AS
			(
			SELECT  				    
			PM.Name,
			SUM(SPD.ActualProduction),
			CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
			NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
			COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
			SUM(DISTINCT SPD.PlantTargetProd),
			SUM([NoOfLoads]),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(DISTINCT SPD.ShiftRunTime),
			PM.ProgramId
			FROM @ProductionSummaryTable SPD
			INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
			Group by PM.Name,PM.ProgramId
			)
			 INSERT INTO @resultSet
			 SELECT  
			   0, 
			  DateRange,
			  SUM(TotalLoad),
			  SUM(TotalEfficiency),
			  @PlantTargetProduction,
			  SUM(Numberofbatches),
			  SUM(ActualRunTime),
			  SUM(TargetRuntime)
			  ,@Viewtype 
			  ,@Subview
			   ,WasherGroupId
				FROM CTE 
				WHERE TotalLoad IS NOT NULL       
				GROUP BY DateRange,WasherGroupId
    END

-- ******************************** Formula segmentView ****************************************************
	IF(@Viewtype = 8)
	BEGIN
		IF(@Subview =20)-- Formula Segment
		BEGIN	
			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,FormulaSegmentID)
			AS
			(
			SELECT  				    
			FS.SegmentName,
			SUM(SPD.ActualProduction),
			CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
			NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
			COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
			SUM(DISTINCT SPD.PlantTargetProd),
			SUM([NoOfLoads]),
			SUM(DISTINCT SPD.ShiftRunTime),
			SUM(DISTINCT SPD.ShiftRunTime),
			SPD.FormulaSegmentID
			FROM @ProductionSummaryTable SPD
			INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
			LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=SPD.FormulaSegmentID
			Group by SPD.FormulaSegmentID,FS.SegmentName			
			)
			 INSERT INTO @resultSet
			 SELECT  
			   0, 
			  DateRange,
			  SUM(TotalLoad),
			  SUM(TotalEfficiency),
			  @PlantTargetProduction,
			  SUM(Numberofbatches),
			  SUM(ActualRunTime),
			  SUM(TargetRuntime)
			  ,@Viewtype 
			  ,@Subview
			   ,FormulaSegmentID
				FROM CTE 
				WHERE TotalLoad IS NOT NULL       
				GROUP BY DateRange,FormulaSegmentID
		END
		IF(@Subview =21)-- Formula Categories
		BEGIN		
			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,TextileId)
			AS
			(
				SELECT EC.CategoryName,SUM(SPD.ActualProduction),
				CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
				NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
				COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
				SUM(DISTINCT SPD.PlantTargetProd),SUM([NoOfLoads]),SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime),EC.TextileId
				FROM @ProductionSummaryTable SPD
				LEFT JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
				WHERE EC.CategoryName IS NOT NULL
				GROUP BY EC.CategoryName,EC.TextileId	
				
				UNION

				SELECT CC.Name,SUM(SPD.ActualProduction),
				CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
				NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
				COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
				SUM(DISTINCT SPD.PlantTargetProd),SUM([NoOfLoads]),SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime),CC.TextileId
				FROM @ProductionSummaryTable SPD
				INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
				INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = SPD.ChainProgaramId
				INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId 
				Group by CC.Name,cc.TextileId
						
			)
			 INSERT INTO @resultSet
			 SELECT  
			   0, 
			  DateRange,
			  SUM(TotalLoad),
			  SUM(TotalEfficiency),
			  @PlantTargetProduction,
			  SUM(Numberofbatches),
			  SUM(ActualRunTime),
			  SUM(TargetRuntime)
			  ,@Viewtype 
			  ,@Subview
			  ,TextileId
				FROM CTE 
				WHERE TotalLoad IS NOT NULL       
				GROUP BY DateRange,TextileId
		END
		IF(@Subview=22) --Formula
		BEGIN
			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,WasherGroupId)
			AS
			(
				SELECT PM.Name,SUM(SPD.ActualProduction),
				CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
				NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
				COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
				SUM(DISTINCT SPD.PlantTargetProd),SUM([NoOfLoads]),SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime),PM.ProgramId
				FROM @ProductionSummaryTable SPD
				INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
				INNER JOIN TCD.ProgramMaster PM ON EC.TextileId = PM.EcolabTextileCategoryId AND SPD.ProgramMasterId = PM.ProgramId    
				WHERE
					(
					CASE    
						WHEN @drillvalue='' THEN 'TRUE' 
						WHEN @drillvalue IS NULL THEN 'TRUE'  
						ELSE                                                    
						CASE WHEN EC.TextileId IN (@drillvalue) THEN 'TRUE' END            
						END='TRUE'
					) AND PM.NAME IS NOT NULL
				GROUP BY PM.Name,PM.ProgramId	
				
				UNION

				SELECT PM.Name,SUM(SPD.ActualProduction),
				CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
				NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
				COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
				SUM(DISTINCT SPD.PlantTargetProd),SUM([NoOfLoads]),SUM(DISTINCT SPD.ShiftRunTime),
				SUM(DISTINCT SPD.ShiftRunTime),PM.ProgramId
				FROM @ProductionSummaryTable SPD 
				INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
				INNER JOIN TCD.ProgramMaster PM ON  SPD.ProgramMasterId = PM.ProgramId		
				WHERE
					(
					 CASE    
					 WHEN @drillvalue='' THEN 'TRUE' 
					 WHEN @drillvalue IS NULL THEN 'TRUE'  
					 ELSE                                                    
					 CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END            
					 END='TRUE'
					)
				GROUP BY PM.Name,PM.ProgramId
						
			)
			 INSERT INTO @resultSet
			 SELECT  
			   0, 
			  DateRange,
			  SUM(TotalLoad),
			  SUM(TotalEfficiency),
			  @PlantTargetProduction,
			  SUM(Numberofbatches),
			  SUM(ActualRunTime),
			  SUM(TargetRuntime)
			  ,@Viewtype 
			  ,@Subview
			  ,WasherGroupId
				FROM CTE 
				WHERE TotalLoad IS NOT NULL       
				GROUP BY DateRange,WasherGroupId
			
		END
	END

      SELECT       
      DateRange,
      ISNULL([TCD].[FnConsumptionOnMetrics](TotalLoad,'Weight',@UserId),0),
      --ISNULL(TotalLoad,0),
      ISNULL([TCD].[FnConsumptionOnMetrics](WasherEfficiency,'Weight',@UserId),0),
      --ISNULL(WasherEfficiency,0),
      ISNULL([TCD].[FnConsumptionOnMetrics](PlantTargetLoad,'Weight',@UserId),0),
      --ISNULL(PlantTargetLoad,0),
      ISNULL(Numberofbatches,0),
      ISNULL([ActualRunTime],0) [ActualRunTime],
      ISNULL([TargetRunTime],0) [TargetRunTime],
      Viewtype,
      Subview,
      Id,
      ShiftId,
      @CorrectionVariable
      FROM @resultSet 

SET NOCOUNT OFF
END
GO
  
IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[ReportProductionDetails]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[ReportProductionDetails] 
END 
GO 
  
CREATE PROCEDURE [TCD].[ReportProductionDetails]   
/******************************************************************  
DESCRIPTION  :   
  
  
MODIFICATION HISTORY DETAILS:   
 21st Jan 2015 -  Kiran     -  Added Formula hierarchy -->Formula segment-->Formula category-->formula  
  
  
REFERENC TABLES :  
  Select * from TCD.Plant --Plant master  
  Select * FROM TCD.PlantChain  --Master Plants  
  Select * FROM TCD.PlantChainProgram  
  Select * FROM TCD.ChainTextileCategory  
  Select * FROM TCD.ProgramMaster  
  Select * FROM TCD.EcolabTextileCategory  --Masters  
  Select * FROM TCD.EcolabSaturation --Masters  
  Select * FROM TCD.FormulaSegments --Masters  
  
EXECUTION STATEMENT :  
  
 EXEC [TCD].[ReportProductionDetails1] @startdate = '2015-01-11',@enddate = '2016-01-30',@Viewtype  = '7',@Subview = '',  
          @Drillvalue = '',@EcolabAccountNumber = '040242802',@MachineType = '', @MachineGroup  = '',@Machine  = '',   
          @EcolabCategory  = '',@ChainCategory  = '', @PlantFormula  = '', @ChainFormula = '', @Customer  = '',  
          @SortColumnId  = 0,@SortDirection  = '',@CurrencyCode = '', @UserId = 1, @FormulaSegement ='',  
          @FormulaCategory='',@Formula=''  
  
  
*******************************************************************/  
  
     @startdate datetime = '',  
     @enddate datetime = '',  
     @Viewtype Int = '',  
     @Subview Int= '',  
     @Drillvalue varchar(100)= '',  
     @EcolabAccountNumber Nvarchar(25) = '',  
     @MachineType VARCHAR(20)= '',  
     @MachineGroup VARCHAR(MAX) = '',  
     @Machine VARCHAR(MAX) = '',  
     @EcolabCategory VARCHAR(MAX) = '',  
     @ChainCategory VARCHAR(MAX) = '',  
     @PlantFormula  VARCHAR(MAX) = '',  
     @ChainFormula VARCHAR(MAX) = '',  
     @Customer VARCHAR(MAX) = '',  
     @SortColumnId int = 0,  
     @SortDirection varchar(4) = '',  
     @CurrencyCode varchar(3) = '',  
     @UserId INT = NULL,  
  @FormulaSegement VARCHAR(MAX)='', --Formula segment,  
  @FormulaCategory VARCHAR(MAX)='', --Formula category  
  @Formula VARCHAR(MAX)='' --Formula  
AS     
BEGIN     
SET NOCOUNT ON   
 SET @startdate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@startdate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@startdate AS time)) AS DateTime))  
 SET @EndDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndDate AS time)) AS DateTime))  
  
   
 DECLARE @ReportGenerated INT = 6, @Month INT = MONTH(GETDATE()),@CorrectionVariable Decimal(18,2),@PlantTargetProduction decimal(18,2)  
      --,@ShiftRuntime int,@NoShiftTotalRuntime INT,@TotaRuntime int  
  
 /* Inserting the record into Report History */  
 INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)  
 SELECT @EcolabAccountNumber,UM.UserId,UM.LoginName,GETUTCDATE(),@ReportGenerated,  
 CASE WHEN @ReportGenerated = 6  
  THEN 'Generated Report : Production Details Report' END  
 FROM TCD.UserMaster UM  
 WHERE UM.EcolabAccountNumber = @EcolabAccountNumber AND UM.UserId = @UserId  
  
    /* Completed the record insertion into Report History */   
  
    -- Return Table set  
    DECLARE @resultSet Table  
    (  
      ShiftId Int,  
      DateRange varchar(100),  
      TotalLoad Decimal(18,2) ,  
      WasherEfficiency Decimal(18,2),  
      PlantTargetLoad Decimal(18,2) ,  
      StandardLoad Decimal(18,2) ,  
      Numberofbatches INT,  
      [ActualRunTime] [int] NULL,  
      [TargetRunTime] [int] NULL,  
      NumberofPieces  [int] NULL,  
      Rewash [int] NULL,  
      Viewtype varchar(100) NULL,  
      Subview varchar(100) NULL,  
      Id int NULL        
    )  
  
    DECLARE @CorrectionFactor TABLE   
   (  
    [ShiftId] [int] NULL,  
    MachineId INT NULL,  
    [ActualProduction] [int] NULL,  
    [StandardProduction] [int] NULL,  
    [PlantTargetProd] [int] NULL,  
    [ActualRunTime] [int] NULL,  
    [TargetRunTime] [int] NULL,  
 ManualInputWeight INT,  
 ManulainputsNoofloads INT  
   )  
      
 --Machine type  
 DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))  
 INSERT INTO @MachineTypeTable EXEC [TCD].[CharlistToTable] @MachineType,','  
  
 --washer Group  
 DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))  
 INSERT INTO @WasherGroupTable EXEC [TCD].[CharlistToTable] @machineGroup,','    
  
 --Machine list  
 DECLARE @MachineTable TABLE(Machine Varchar(100))  
 INSERT INTO @MachineTable EXEC [TCD].[CharlistToTable] @Machine,','  
  
 --Ecolab category  
 DECLARE @EcolabCategoryTable TABLE(EcolabCategory Varchar(100))  
 INSERT INTO @EcolabCategoryTable EXEC [TCD].[CharlistToTable] @EcolabCategory,','  
  
 --Chain category  
 DECLARE @ChainCategoryTable TABLE(ChainCategory Varchar(100))  
 INSERT INTO @ChainCategoryTable EXEC [TCD].[CharlistToTable] @ChainCategory,','  
  
 --Plant formula  
 DECLARE @PlantFormulaTable TABLE(PlantFormula Varchar(100))  
 INSERT INTO @PlantFormulaTable EXEC [TCD].[CharlistToTable] @PlantFormula,','  
  
 --Chain Formula  
 DECLARE @ChainFormulaTable TABLE(ChainFormula Varchar(100))  
 INSERT INTO @ChainFormulaTable EXEC [TCD].[CharlistToTable] @ChainFormula,','  
  
 --Customer Table  
 DECLARE @CustomerTable TABLE(Customer Varchar(100))  
 INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','  
  
 --Formula Segment --added by Kiran  
 DECLARE @FormulaSegmentTable TABLE(FormulaSegment Varchar(1000))  
    INSERT INTO @FormulaSegmentTable EXEC [TCD].[CharlistToTable] @FormulaSegement,','  
  
 -----Formula category--------Start  
 DECLARE @FormulaCategoryTable TABLE(FormulaCategory Varchar(1000),Type CHAR(1))  
    INSERT INTO @FormulaCategoryTable(FormulaCategory) EXEC [TCD].[CharlistToTable] @Formulacategory,','  
   
 --segregating Ecolab/Chain categories  
 --UPDATE @FormulaCategoryTable SET TYPE=RIGHT(FormulaCategory,1),FormulaCategory=LEFT(FormulaCategory,LEN(FormulaCategory)-2)  
  
 --Below 1000 Ecolab category  
 UPDATE @FormulaCategoryTable SET TYPE='E' WHERE FormulaCategory<1000  
 --Above 1000 consider as Chain category  
 UPDATE @FormulaCategoryTable SET TYPE='C' WHERE FormulaCategory>=1000  
  
 --Rollbacking to actual ID  
 UPDATE @FormulaCategoryTable SET FormulaCategory=FormulaCategory-1000 WHERE TYPE='C'  
 --SELECT * FROM @FormulaCategoryTable  
  
 INSERT INTO @EcolabCategoryTable(EcolabCategory)  
 SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='E'   
  
 INSERT INTO @ChainCategoryTable(ChainCategory)  
 SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='C'  
  
 --Value Assigning  
 IF (EXISTS(SELECT * FROM @EcolabCategoryTable) AND @FormulaCategory!='')  
 BEGIN  
  SET @EcolabCategory=@FormulaCategory  
 END  
 IF (EXISTS(SELECT * FROM @ChainCategoryTable) AND @FormulaCategory!='')  
 BEGIN  
  SET @ChainCategory=@FormulaCategory  
 END  
 ---Formula category-------------------------End  
  
 -----Formula Ecolab/Chain categories  
 DECLARE @FormulaTable TABLE(Formula Varchar(1000),Type CHAR(1))  
    INSERT INTO @FormulaTable(Formula) EXEC [TCD].[CharlistToTable] @Formula,','  
  
 --segregating Ecolab/Chain categories  
 --UPDATE @FormulaTable SET TYPE=RIGHT(Formula,1),Formula=LEFT(Formula,LEN(Formula)-2)  
 /*  
 --Below 1000 Ecolab category  
 UPDATE @FormulaTable SET TYPE='E' WHERE Formula<1000  
 --Above 1000 consider as Chain category  
 UPDATE @FormulaTable SET TYPE='C' WHERE Formula>=1000  
  
 --Rollbacking to actual ID  
 UPDATE @FormulaTable SET Formula=Formula-1000 WHERE TYPE='C'  
 */  
 --Select * from @FormulaTable  
 --Plant fomula     
    INSERT INTO @PlantFormulaTable(PlantFormula)   
 SELECT Formula FROM @FormulaTable --WHERE Type='E'  
 --chain formula     
    INSERT INTO @ChainFormulaTable(ChainFormula)   
 SELECT Formula FROM @FormulaTable --WHERE Type='C'  
 --SELECT * FROM @PlantFormulaTable  
 --SELECT * FROM @ChainFormulaTable  
  
 --Value Assigning  
 IF (EXISTS(SELECT * FROM @PlantFormulaTable) AND @Formula!='')  
 BEGIN  
  SET @PlantFormula=@FormulaCategory  
 END  
 IF (EXISTS(SELECT * FROM @ChainFormulaTable) AND @Formula!='')  
 BEGIN  
  SET @ChainFormula=@FormulaCategory  
 END  
 --SELECT @PlantFormula,@ChainFormula  
 -----Formula Segregation end  
  
 --Insert Into @CorrectionFactor table  
 INSERT INTO @CorrectionFactor  
 (  
  [ShiftId],  
  [MachineId] ,  
  [ActualProduction] ,  
  [StandardProduction] ,  
  [PlantTargetProd] ,  
  [ActualRunTime] ,  
  [TargetRunTime],  
  ManualInputWeight,  
  ManulainputsNoofloads     
 )  
 SELECT   
  PS.[ShiftId],  
  SPD.[MachineId],  
  ISNULL([TCD].[FnConsumptionOnMetrics](SUM(ISNULL(SPD.[ActualProduction],0))+SUM(ISNULL(MIP.ActualWeight,0)),'Weight',@UserId),0),  
  --ISNULL([TCD].[FnConsumptionOnMetrics](SUM(ISNULL(SPD.[ActualProduction],0)),'Weight',@UserId),0),    
  --SUM(SPD.[ActualProduction]),  
  ISNULL([TCD].[FnConsumptionOnMetrics](SUM(ISNULL(SPD.StandardProduction,0)),'Weight',@UserId),0),  
  --SUM(SPD.StandardProduction),  
  ISNULL([TCD].[FnConsumptionOnMetrics](SUM(DISTINCT ISNULL(SPD.[PlantTargetProd],0)),'Weight',@UserId),0),  
  --SUM(DISTINCT SPD.[PlantTargetProd]),  
  SUM(ISNULL(SPD.[ActualRunTime],0) + ISNULL(SPD.ActualTurnTime,0)),  
  SUM(ISNULL(SPD.[TargetRunTime],0) + ISNULL(SPD.TargetTurnTime,0)),  
  SUM(ISNULL(MIP.ActualWeight,0)),SUM(ISNULL(MIP.NoofLoads,0))  
 FROM  TCD.ShiftProductionDataRollup SPD   
 INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId  
 LEFT OUTER JOIN --Manual Production Details appending  
  (  
   SELECT WasherId,FormulaId,CONVERT(DATE,RecordedDate) AS LoadDate,SUM(ISNULL(Value,0)) AS ActualWeight,  
   ISNULL(COUNT(CONVERT(DATE,RecordedDate)),0) AS NoofLoads FROM  
   TCD.ManualProduction MP  
   GROUP BY WasherId,FormulaId,CONVERT(DATE,RecordedDate)  
  )MIP ON MIP.WasherId=SPD.EcolabWasherId AND MIP.FormulaId=SPD.ProgramMasterId AND MIP.LoadDate=CONVERT(DATE,PS.StartDateTime)  
 WHERE   
  CASE @StartDate                                                                                  
  WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                  
  ELSE CASE WHEN PS.[StartDateTime] >= @startdate  AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                          
  END='TRUE'   
 GROUP BY MachineId,PS.ShiftId;  
  
 WITH CTE (PlantTargetProd) AS  
 (  
 SELECT SUM(DISTINCT SPD.[PlantTargetProd]) FROM @CorrectionFactor SPD GROUP BY ShiftId  
 )  
 SELECT @PlantTargetProduction = SUM(PlantTargetProd) FROM CTE;  
  
 WITH CTE (MachineId,PlantEfficiency)  
 AS  
 (  
 SELECT   
  MachineId,  
  CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/   
   NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) *   
   COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2))     
   FROM @CorrectionFactor SPD GROUP BY MachineId  
 )  
    SELECT @CorrectionVariable = @PlantTargetProduction/NULLIF(SUM(PlantEfficiency),0) FROM CTE  
  
  
 --  SELECT  @ShiftRuntime = SUM(A.ShiftTime)  
 --   FROM  
 --   (  
 --  SELECT  SUM( DISTINCT DATEDIFF(Second,psd.StartDateTime,PSd.EndDateTime)) AS ShiftTime FROM TCD.ShiftProductionDataRollup spdr   
 --      INNER JOIN TCD.ProductionShiftData psd ON psd.ShiftId = spdr.ShiftId  
 --   WHERE   
 -- CASE @StartDate                                                                                  
 -- WHEN '' THEN Case WHEN MONTH(CAST(psd.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                  
 -- ELSE CASE WHEN psd.[StartDateTime] >= @startdate AND psd.[StartDateTime] <  @enddate THEN 'TRUE'END                                                          
 -- END='TRUE'  
 -- AND psd.ShiftName <> 'No Shift'  
 --  GROUP BY spdr.ShiftId  
 --   ) A  
  
 -- SELECT  
 --@NoShiftTotalRuntime = SUM(SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0))  
 --   FROM TCD.ShiftProductionDataRollup SPD INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId  
 --  WHERE   
 --     CASE @StartDate                                                                                  
 --     WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                  
 --     ELSE CASE WHEN PS.[StartDateTime] >= @startdate AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                          
 --     END='TRUE'  
 -- AND PS.ShiftName = 'No Shift'  
  
 --  SELECT @TotaRuntime = ISNULL(@ShiftRuntime,0) + ISNULL(@NoShiftTotalRuntime,0)  
  
 DECLARE @ProductionSummaryTable TABLE  
 (  
  [ShiftId] [int] NULL,  
  [ShiftName] Varchar(100) NULL,  
  RecordDate date,   
  [MachineId] [int] NULL,  
  [ProgramMasterId] [int] NULL,  
  [EcolabWasherId] [int] NULL,  
  [ActualProduction] [int] NULL,  
  [StandardProduction] [int] NULL,  
  [NoOfLoads] [int] NULL,  
  [LoadEfficiency] [decimal](18, 2) NULL,  
  [TimeEfficiency] [decimal](18, 2) NULL,  
  TotalEfficiency [decimal](18, 2) NULL,  
  [PlantTargetProd] [int] NULL,  
  [ActualRunTime] [int] NULL,  
  [TargetRunTime] [int] NULL,  
  EcolabTextileId int,  
  ChainTextileId int,  
  ChainProgaramId int,  
  CustomerId int,  
  NoOfPieces int,  
  Rewash Int,  
  [ShiftRunTime] [int] NULL,  
  FormulaSegmentID INT,  
  RowNumberID INT  
 )  
  
    INSERT INTO @ProductionSummaryTable  
    SELECT   
        PS.[ShiftId],  
        PS.ShiftName,  
        CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date),  
        --CAST(PS.[StartDateTime] AS date),  
        SPD.[MachineId],  
        SPD.[ProgramMasterId],  
        SPD.[EcolabWasherId],  
        ISNULL(SPD.[ActualProduction],0),  
        ISNULL(SPD.StandardProduction,0),  
        ISNULL(SPD.[NoOfLoads],0),  
        ISNULL(SPD.[LoadEfficiency],0),  
        ISNULL(SPD.[TimeEfficiency],0),  
        (ISNULL(SPD.[LoadEfficiency],0) * ISNULL(SPD.TimeEfficiency,0)),  
        ISNULL(SPD.[PlantTargetProd],0),  
        ISNULL(SPD.[ActualRunTime],0) + ISNULL(SPD.ActualTurnTime,0),  
        ISNULL(SPD.[TargetRunTime],0) + ISNULL(SPD.TargetTurnTime,0),  
        SPD.EcolabTextileId,  
  SPD.ChainTextileId,  
        SPD.ChainProgaramId,  
        SPD.CustomerId,  
        ISNULL(SPD.NoOfPieces,0),  
        CAST((  
   SELECT spdr.ActualProduction FROM TCD.ShiftProductionDataRollup spdr WHERE spdr.ShiftId = SPD.ShiftId AND spdr.MachineId = SPD.MachineId  
   AND spdr.ProgramMasterId = SPD.ProgramMasterId AND spdr.ProgramMasterId IN (SELECT pm.ProgramId FROM TCD.ProgramMaster pm WHERE pm.Rewash = 1)  
   ) AS decimal(18,2)),  
  DATEDIFF(Second,ps.StartDateTime,PS.EndDateTime) +  
   ISNULL(  
     (  
     SELECT  
     SUM(SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0))  
     FROM TCD.ShiftProductionDataRollup SPD INNER JOIN TCD.ProductionShiftData PSD ON SPD.ShiftId = PSD.ShiftId  
     WHERE PSD.[StartDateTime] = PS.StartDateTime AND PSD.[StartDateTime] = PS.EndDateTime AND PS.ShiftName = 'No Shift'  
     ) ,0),  
  CASE WHEN SPD.ChainProgaramId IS NOT NULL THEN ChainPlant.FormulaSegmentId  
  ELSE FS1.FormulaSegmentID END AS Formulasegment,  
  
  ROW_NUMBER() OVER(Partition BY SPD.ProgramMasterId, SPD.[EcolabWasherId], CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date)  
   ORDER BY SPD.ProgramMasterId, SPD.[EcolabWasherId] )  
  
        --CAST(((SELECT SUM(MR.VALUE) FROM TCD.ManualRewash MR WHERE SPD.ProgramMasterId = MR.FormulaId AND CAST(PS.StartDateTime AS date) = CAST(MR.RecordedDate AS date) GROUP BY CAST(MR.RecordedDate AS date),MR.FormulaId)) AS decimal(18,2))  
 FROM  TCD.ShiftProductionDataRollup SPD   
 INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId  
 INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId   
 INNER JOIN TCD.MachineSetup ms ON SPD.MachineId = ms.WasherId  
 LEFT OUTER JOIN  
   (  
   --IF Chain Plant  
   SELECT PCP.PlantProgramId,PCP.PlantChainId,PCP.ChainTextileCategoryId,PCP.EcolabTextileCategoryId,  
   PCP.FormulaSegmentId,PCP.EcolabSaturationId  
   FROM TCD.PlantChainProgram PCP   
   LEFT OUTER JOIN TCD.ChainTextileCategory CTC ON CTC.TextileId=PCP.ChainTextileCategoryId  
   LEFT OUTER JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId=PCP.EcolabTextileCategoryId  
   LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=PCP.FormulaSegmentId  
   LEFT OUTER JOIN TCD.EcolabSaturation ES ON ES.EcolabSaturationId=PCP.EcolabSaturationId  
   )ChainPlant ON SPD.ChainProgaramId=ChainPlant.PlantProgramId  
  
 LEFT OUTER JOIN TCD.EcolabTextileCategory ETC1 ON ETC1.TextileId=PM.EcolabTextileCategoryId  
 LEFT OUTER JOIN TCD.FormulaSegments FS1 ON FS1.FormulaSegmentID=PM.FormulaSegmentId  
 LEFT OUTER JOIN TCD.EcolabSaturation ES1 ON ES1.EcolabSaturationId=PM.EcolabSaturationId  
   
    WHERE isNull(ms.IsPony,0) = 0  
    AND   
       CASE @StartDate                                                                                  
       WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                  
       ELSE CASE WHEN PS.[StartDateTime] >= @startdate  AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                          
       END='TRUE'  
  
     AND  
       CASE @MachineType     
       WHEN '' THEN 'TRUE'           
       ELSE                                                        
       CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE        
       MS.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable))) THEN 'TRUE' END                                                        
       END='TRUE'   
      
    AND         
  
    CASE @machineGroup     
    WHEN '' THEN 'TRUE'           
    ELSE                                                        
    CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE        
    MS.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable)) THEN 'TRUE' END                                                        
    END='TRUE'   
    AND  
  
    CASE @Machine     
    WHEN '' THEN 'TRUE'           
    ELSE                                                        
    CASE WHEN SPD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                   
    END='TRUE'   
    AND  
      
    CASE @EcolabCategory     
    WHEN '' THEN 'TRUE'           
    ELSE                                                        
    CASE WHEN SPD.EcolabTextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                        
    END='TRUE'   
     AND  
      
    CASE @ChainCategory     
    WHEN '' THEN 'TRUE'           
    ELSE                                                        
    CASE WHEN SPD.ChainTextileId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END                                                        
    END='TRUE'  
    AND  
  
    CASE @PlantFormula     
    WHEN '' THEN 'TRUE'           
    ELSE                                                        
    CASE WHEN SPD.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                        
    END='TRUE'    
    AND  
      
    CASE @ChainFormula     
    WHEN '' THEN 'TRUE'           
    ELSE                                                        
    CASE WHEN SPD.ProgramMasterId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END                                                        
    END='TRUE'  
    AND  
      
    CASE @Customer     
    WHEN '' THEN 'TRUE'           
       ELSE                                                        
       CASE WHEN SPD.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                        
    END='TRUE'  
 --Added by Kiran   
    AND   
  CASE @FormulaSegement                                                                                  
  WHEN '' THEN  'TRUE'  
  ELSE  
   CASE WHEN SPD.ChainProgaramId  IS NOT NULL THEN  
    CASE WHEN ChainPlant.FormulaSegmentId IN (SELECT FormulaSegment FROM @FormulaSegmentTable) THEN 'TRUE' END                                                                                       
   ELSE   
    CASE WHEN FS1.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)  THEN 'TRUE'END     
   END                                                       
  END='TRUE'  
  -----ENd  
  
  /*  
 SELECT S.ActualProduction AS Actual,MIP.ManualIPActualWeight AS Manual,   
 ISNULL(S.ActualProduction,0)+ISNULL(MIP.ManualIPActualWeight,0),  
 S.NoOfLoads AS Actualloads,MIP.NoofLoads AS Manualloads,  
 ISNULL(S.NoOfLoads,0)+ISNULL(MIP.NoofLoads,0)  
 FROM  @ProductionSummaryTable S  
 INNER JOIN   
  (  
  SELECT WasherId,FormulaId,CONVERT(DATE,RecordedDate) AS LoadDate,SUM(Value) AS ManualIPActualWeight,  
  COUNT(CONVERT(DATE,RecordedDate)) AS NoofLoads FROM  
  TCD.ManualProduction MP  
  GROUP BY WasherId,FormulaId,CONVERT(DATE,RecordedDate)  
  )MIP ON MIP.WasherId=S.EcolabWasherId AND MIP.FormulaId=S.ProgramMasterId AND MIP.LoadDate=S.RecordDate  
  WHERE S.RowNumberID=1  
 */  
  
 --For top 1 record combination updating the manual input data.  
 UPDATE S SET ActualProduction=ISNULL(S.ActualProduction,0)+ISNULL(MIP.ManualIPActualWeight,0),S.NoOfLoads=ISNULL(S.NoOfLoads,0)+ISNULL(MIP.NoofLoads,0)  
 FROM  @ProductionSummaryTable S  
 INNER JOIN   
  (  
  SELECT WasherId,FormulaId,CONVERT(DATE,RecordedDate) AS LoadDate,SUM(Value) AS ManualIPActualWeight,  
  COUNT(CONVERT(DATE,RecordedDate)) AS NoofLoads FROM  
  TCD.ManualProduction MP  
  GROUP BY WasherId,FormulaId,CONVERT(DATE,RecordedDate)  
  )MIP ON MIP.WasherId=S.MachineId AND MIP.FormulaId=S.ProgramMasterId AND MIP.LoadDate=S.RecordDate  
  WHERE S.RowNumberID=1  
  
 --SELECT * FROM @ProductionSummaryTable  
  
  
 IF(@Viewtype = 3)  
 BEGIN  
  IF(@Subview = 12)  
  BEGIN  
   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,TextileId)  
    AS  
    (  
     SELECT   
    EC.CategoryName,  
    SUM(SPD.ActualProduction),  
    COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
    SUM(DISTINCT SPD.PlantTargetProd),  
    SUM(SPD.StandardProduction),  
    SUM([NoOfLoads]),  
    SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(SPD.NoOfPieces),  
    SUM(SPD.Rewash),  
    EC.TextileId  
      FROM @ProductionSummaryTable SPD LEFT JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId  
    WHERE EC.CategoryName IS NOT NULL  
    GROUP BY   
      EC.CategoryName,EC.TextileId,SPD.ShiftId  
      )  
      INSERT INTO @resultSet  
      SELECT DISTINCT  
    0,  
    DateRange,  
    SUM(TotalLoad),  
    SUM(WasherEfficiency),  
    SUM(PlantTargetLoad),  
    SUM(StandardLoad),  
    SUM(Numberofbatches),  
    SUM(ActualRunTime),  
    SUM(TargetRuntime),  
    SUM(NumberofPieces),  
    SUM(Rewash)  
    ,@Viewtype   
    ,@Subview  
    ,TextileId  
    FROM CTE  
    WHERE TotalLoad IS NOT NULL  
    GROUP BY DateRange,TextileId     
     END  
  IF(@Subview = 17)  
  BEGIN  
   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
   AS  
   (  
   SELECT   
     
   PM.Name,  
   SUM(SPD.ActualProduction),  
   COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
   SUM(DISTINCT SPD.PlantTargetProd),  
   SUM(SPD.StandardProduction),  
   SUM([NoOfLoads]),  
   SUM(DISTINCT SPD.ShiftRunTime),  
   SUM(DISTINCT SPD.ShiftRunTime),  
   SUM(SPD.NoOfPieces),  
   SUM(SPD.Rewash)  
    FROM @ProductionSummaryTable SPD INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId  
     INNER JOIN TCD.ProgramMaster PM ON EC.TextileId = PM.EcolabTextileCategoryId AND SPD.ProgramMasterId = PM.ProgramId      
   WHERE  
    (  
    CASE      
     WHEN @drillvalue='' THEN 'TRUE'   
     WHEN @drillvalue IS NULL THEN 'TRUE'    
     ELSE                                                      
      CASE WHEN EC.TextileId IN (@drillvalue) THEN 'TRUE' END              
     END='TRUE'  
    ) AND PM.NAME IS NOT NULL  
   GROUP BY   
      PM.Name,SPD.ShiftId  
     )  
   INSERT INTO @resultSet  
     SELECT DISTINCT  
   0,  
      DateRange,  
      SUM(TotalLoad),  
      SUM(WasherEfficiency),  
      SUM(PlantTargetLoad),  
      SUM(StandardLoad),  
      SUM(Numberofbatches),  
      SUM(ActualRunTime),  
      SUM(TargetRuntime),  
      SUM(NumberofPieces),  
      SUM(Rewash)  
      ,@Viewtype   
      ,@Subview  
    ,0  
       FROM CTE  
     WHERE TotalLoad IS NOT NULL  
     GROUP BY DateRange  
  END  
  
 END  
  
    -- ************************ By Textile Category View ************************************************  
 IF(@Viewtype = 4)  
 BEGIN   
  IF(@Subview = 15)  
  BEGIN  
   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
    AS  
    (  
    SELECT      
    CC.Name,  
    SUM(SPD.ActualProduction),  
    COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
    SUM(DISTINCT SPD.PlantTargetProd),  
    SUM(SPD.StandardProduction),  
    SUM([NoOfLoads]),  
    SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(SPD.NoOfPieces),  
    SUM(SPD.Rewash)  
    FROM @ProductionSummaryTable SPD LEFT JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId  
    WHERE CC.Name IS NOT NULL   
    GROUP BY   
      CC.Name,CC.TextileId,SPD.ShiftId  
      )  
    INSERT INTO @resultSet  
      SELECT DISTINCT  
    0,  
       DateRange,  
       SUM(TotalLoad),  
       SUM(WasherEfficiency),  
       SUM(PlantTargetLoad),  
       SUM(StandardLoad),  
       SUM(Numberofbatches),  
       SUM(ActualRunTime),  
       SUM(TargetRuntime),  
       SUM(NumberofPieces),  
       SUM(Rewash)  
       ,@Viewtype   
       ,@Subview  
     ,0  
     FROM CTE  
     WHERE TotalLoad IS NOT NULL  
     GROUP BY DateRange  
        END    
  IF(@Subview = 18)  
  BEGIN  
   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
    AS  
    (  
    SELECT          
    PM.Name,  
    SUM(SPD.ActualProduction),  
    COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
    SUM(DISTINCT SPD.PlantTargetProd),  
    SUM(SPD.StandardProduction),  
    SUM([NoOfLoads]),  
    SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(SPD.NoOfPieces),  
    SUM(SPD.Rewash)  
       FROM @ProductionSummaryTable SPD INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId  
      INNER JOIN TCD.ProgramMaster PM ON CC.TextileId = PM.ChainTextileId AND SPD.ProgramMasterId = PM.ProgramId  
      
   WHERE  
    (  
    CASE      
     WHEN @drillvalue='' THEN 'TRUE'   
     WHEN @drillvalue IS NULL THEN 'TRUE'    
     ELSE                                                      
      CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END              
     END='TRUE'  
    )  
   GROUP BY   
      PM.Name,SPD.ShiftId  
      )  
    INSERT INTO @resultSet  
      SELECT DISTINCT  
    0,  
       DateRange,  
       SUM(TotalLoad),  
       SUM(WasherEfficiency),  
       SUM(PlantTargetLoad),  
       SUM(StandardLoad),  
       SUM(Numberofbatches),  
       SUM(ActualRunTime),  
       SUM(TargetRuntime),  
       SUM(NumberofPieces),  
       SUM(Rewash)  
       ,@Viewtype   
       ,@Subview  
     ,0  
        FROM CTE  
      WHERE TotalLoad IS NOT NULL  
      GROUP BY DateRange  
  END  
 END  
  
  -- ******************************** Timeline View ***************************************************  
 IF(@Viewtype = 1)  
 BEGIN  
  ---- By TimeLine - Day View  
    IF(@Subview = 5)  
  BEGIN   
   INSERT INTO @resultSet  
   SELECT DISTINCT  
   0,  
   SPD.ShiftName,  
   SUM(SPD.ActualProduction),  
   COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
   SUM(DISTINCT SPD.PlantTargetProd),  
   SUM(SPD.StandardProduction),  
   SUM([NoOfLoads]),  
   SUM(DISTINCT SPD.ShiftRunTime),  
   SUM(DISTINCT SPD.ShiftRunTime),  
   SUM(SPD.NoOfPieces),  
   SUM(SPD.Rewash)  
   ,@Viewtype   
   ,@Subview  
   ,0  
    FROM @ProductionSummaryTable SPD  
   GROUP BY   
   SPD.ShiftName  
  END  
  
       ---- By TimeLine - Week View  
    IF (@Subview = 4)  
    BEGIN  
   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
   AS  
   (  
   SELECT   
      CAST(RecordDate AS nvarchar(100)),  
    SUM(SPD.ActualProduction),  
    COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
    SUM(DISTINCT SPD.PlantTargetProd),  
    SUM(SPD.StandardProduction),  
    SUM([NoOfLoads]),  
    SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(SPD.NoOfPieces),  
    SUM(SPD.Rewash)  
     FROM @ProductionSummaryTable SPD  
    GROUP BY DATEPART(weekday,RecordDate),RecordDate,SPD.ShiftId  
  
   )  
     INSERT INTO @resultSet  
     SELECT DISTINCT  
      0,  
      DateRange,  
     SUM(TotalLoad),  
     SUM(WasherEfficiency),  
      SUM(PlantTargetLoad),  
      SUM(StandardLoad),  
      SUM(Numberofbatches),  
      SUM(ActualRunTime),  
      SUM(TargetRuntime),  
      SUM(NumberofPieces),  
      SUM(Rewash)  
      ,@Viewtype   
      ,@Subview  
    ,0  
       FROM CTE  
     WHERE TotalLoad IS NOT NULL  
     GROUP BY DateRange  
    END  
  ---- By TimeLine - Month View  
    IF(@Subview = 3)  
    BEGIN  
   DECLARE @FirstDay date = (SELECT TOP 1 RecordDate FROM @ProductionSummaryTable ORDER BY RecordDate)  
   DECLARE @LastDay date = (SELECT TOP 1 RecordDate FROM @ProductionSummaryTable ORDER BY RecordDate DESC)  
   DECLARE @FirstSunday date = NULL,  
   @LastSaturday date = NULL  
  
      
   SELECT   
   @FirstSunday = CAST(DateAdd(dd, (8-DatePart(WEEKDAY,   
   DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)))%7,   
   DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)) AS DATE)   
  
   SELECT  
   @LastSaturday =   
   DATEADD(dd,  
    -DATEPART(WEEKDAY,  
     DATEADD(dd, -DAY(DATEADD(month, 1, @LastDay)),  
     DATEADD(month, 1, @LastDay))) ,  
    DATEADD(dd, -DAY(DATEADD(MONTH, 1, @LastDay)), DATEADD(MONTH, 1, @LastDay)));  
  
   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
   AS  
   (  
   SELECT   
         
   CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,-1,@FirstSunday)) = 7   
   AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate < DATEADD(DD,-1,@FirstSunday)) = 0)  
   THEN CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100))  
   WHEN DATEADD(DD,-1,@FirstSunday) > CAST(GETDATE() AS DATE)   
   THEN  
   CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @enddate, 101) AS nvarchar(100))  
   ELSE  
   CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) END As DateRange,  
   SUM(SPD.ActualProduction),  
    COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
    SUM(DISTINCT SPD.PlantTargetProd),  
    SUM(SPD.StandardProduction),  
    SUM([NoOfLoads]),  
    SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(SPD.NoOfPieces),  
    SUM(SPD.Rewash)  
  
    FROM @ProductionSummaryTable SPD  
   WHERE RecordDate < @FirstSunday AND RecordDate >= @FirstDay  
   GROUP BY SPD.ShiftId  
  
          
   UNION ALL  
  
    
   SELECT  
          
   --CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100)) AS StartDate,  
   --CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) AS EndDate,  
    CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100))  + CHAR(13) + '-' +  
    CASE WHEN CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) >  
    CAST(Convert(varchar, DateAdd(dd, (1 - DatePart(dw, @enddate) + 1), @enddate), 101) AS nvarchar(100))  
    THEN  CAST(Convert(varchar, DateAdd(dd, 1-1, @enddate), 101) AS nvarchar(100))  
    ELSE CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) END  
    As DateRange,  
    SUM(SPD.ActualProduction),  
    COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
    SUM(DISTINCT SPD.PlantTargetProd),  
    SUM(SPD.StandardProduction),  
    SUM([NoOfLoads]),  
    SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(SPD.NoOfPieces),  
    SUM(SPD.Rewash)  
   FROM @ProductionSummaryTable SPD  
    WHERE RecordDate BETWEEN @FirstSunday AND @LastSaturday  
   GROUP BY Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101),  
    Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101),SPD.ShiftId  
         
   UNION ALL  
  
   SELECT   
    CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,1,@LastSaturday)) = 1   
   AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate > DATEADD(DD,1,@LastSaturday)) = 0)  
   THEN   
   CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100))   
   ELSE  
   CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @LastDay, 101) AS nvarchar(100)) END   As DateRange,  
   SUM(SPD.ActualProduction),  
    COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
    SUM(DISTINCT SPD.PlantTargetProd),  
    SUM(SPD.StandardProduction),  
    SUM([NoOfLoads]),  
    SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(SPD.NoOfPieces),  
    SUM(SPD.Rewash)  
   FROM @ProductionSummaryTable SPD  
   WHERE RecordDate > @LastSaturday AND RecordDate <= @LastDay   
   GROUP BY SPD.ShiftId  
   )  
   INSERT INTO @resultSet  
   SELECT DISTINCT  
   0,  
   DateRange,  
   SUM(TotalLoad),  
   SUM(WasherEfficiency),  
   SUM(PlantTargetLoad),  
   SUM(StandardLoad),  
   SUM(Numberofbatches),  
   SUM(ActualRunTime),  
   SUM(TargetRuntime),  
   SUM(NumberofPieces),  
   SUM(Rewash)  
   ,@Viewtype   
   ,@Subview  
    ,0  
    FROM CTE  
    WHERE TotalLoad IS NOT NULL  
    GROUP BY DateRange  
  
    END  
  
       IF(@Subview = 2)  
    BEGIN  
   DECLARE @QuarterYear VARCHAR(100) = YEAR(@enddate);  
   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
   AS  
   (  
     SELECT   
    DATENAME(MONTH, RecordDate) + ' ' + @QuarterYear As DateRange,  
    SUM(SPD.ActualProduction),  
    COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
    SUM(DISTINCT SPD.PlantTargetProd),  
    SUM(SPD.StandardProduction),  
    SUM([NoOfLoads]),  
    SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(SPD.NoOfPieces),  
    SUM(SPD.Rewash)  
    FROM @ProductionSummaryTable SPD  
    GROUP BY  DATEPART(MONTH, RecordDate),DATENAME(MONTH, RecordDate),SPD.ShiftId  
   )  
   INSERT INTO @resultSet  
    SELECT DISTINCT  
    0,  
    DateRange,  
      SUM(TotalLoad),  
      SUM(WasherEfficiency),  
    SUM(PlantTargetLoad),  
    SUM(StandardLoad),  
    SUM(Numberofbatches),  
    SUM(ActualRunTime),  
    SUM(TargetRuntime),  
    SUM(NumberofPieces),  
    SUM(Rewash)  
    ,@Viewtype   
    ,@Subview  
     ,0  
     FROM CTE  
     WHERE TotalLoad IS NOT NULL  
     GROUP BY DateRange  
    END     
  
      IF(@Subview = 1)  
      BEGIN  
   DECLARE @Year VARCHAR(100) = RIGHT(YEAR(@enddate),2);  
   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
   AS  
   (  
    SELECT   
    CASE 'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10))  
       WHEN 'Q1' THEN 'Jan' + @Year + '- Mar' + @Year  
       WHEN 'Q2' THEN 'Apr' + @Year + '- Jun' + @Year  
       WHEN 'Q3' THEN 'Jul' + @Year + '-Sep' + @Year  
       WHEN 'Q4' THEN 'Oct' + @Year + '- Dec'+ @Year  
    END AS DateRange,  
    SUM(SPD.ActualProduction),  
    COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
    SUM(DISTINCT SPD.PlantTargetProd),  
    SUM(SPD.StandardProduction),  
    SUM([NoOfLoads]),  
    SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(SPD.NoOfPieces),  
    SUM(SPD.Rewash)  
     FROM @ProductionSummaryTable SPD  
     GROUP BY DATEPART(QUARTER, RecordDate),SPD.ShiftId  
  
   )  
  
   INSERT INTO @resultSet  
   SELECT DISTINCT  
    0,  
    DateRange,  
      SUM(TotalLoad),  
      SUM(WasherEfficiency),  
    SUM(PlantTargetLoad),  
    SUM(StandardLoad),  
    SUM(Numberofbatches),  
    SUM(ActualRunTime),  
    SUM(TargetRuntime),  
    SUM(NumberofPieces),  
    SUM(Rewash)  
    ,@Viewtype   
    ,@Subview  
     ,0  
     FROM CTE  
     WHERE TotalLoad IS NOT NULL  
     GROUP BY DateRange  
  
   END  
    END  
  
    -- ******************************** Location View ***************************************************  
    IF(@Viewtype = 2)  
    BEGIN  
  
  IF(@Subview = 9)  
        BEGIN  
    WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,WasherGroupId)  
   AS  
   (  
    SELECT   
    --SPD.MachineId,  
    WG.WasherGroupName,  
    SUM(SPD.ActualProduction),  
    CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/   
    NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) *   
    COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),  
    SUM(DISTINCT SPD.PlantTargetProd),  
    SUM(SPD.StandardProduction),  
    SUM([NoOfLoads]),  
    SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(SPD.NoOfPieces),  
    SUM(SPD.Rewash),  
    WG.WasherGroupId  
     FROM @ProductionSummaryTable SPD LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId  
      LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId   
    GROUP BY WG.WasherGroupName,WG.WasherGroupId,SPD.ShiftId--,SPD.MachineId  
  
   )  
  
    INSERT INTO @resultSet  
    SELECT DISTINCT  
      0,  
      DateRange,  
      SUM(TotalLoad),  
      SUM(WasherEfficiency),  
   @PlantTargetProduction,  
      SUM(StandardLoad),  
      SUM(Numberofbatches),  
      SUM(ActualRunTime),  
      SUM(TargetRuntime),  
      SUM(NumberofPieces),  
      SUM(Rewash)  
      ,@Viewtype   
      ,@Subview  
      ,WasherGroupId  
    FROM CTE  
     WHERE TotalLoad IS NOT NULL  
     GROUP BY DateRange,WasherGroupId  
        END  
  
       IF(@Subview = 10)  
       BEGIN  
    WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
   AS  
   (  
   SELECT           
    cast( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName MachineName,  
    SUM(SPD.ActualProduction),  
    CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/   
    NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) *   
    COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)) ,  
    SUM(DISTINCT SPD.PlantTargetProd),  
    SUM(SPD.StandardProduction),  
    SUM([NoOfLoads]),  
    SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(SPD.NoOfPieces),  
    SUM(SPD.Rewash)  
          
    FROM @ProductionSummaryTable SPD   
    LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId  
    LEFT JOIN TCD.Washer w on MS.WasherId=w.WasherId  
    LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId   
   WHERE   
     (  
      CASE @drillvalue     
       WHEN '' THEN 'TRUE'           
       ELSE                                                      
     CASE WHEN WG.WasherGroupId IN (@drillvalue) THEN 'TRUE' END              
       END='TRUE'  
     )  
    GROUP BY cast( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName,SPD.ShiftId  
  
   )  
  
    INSERT INTO @resultSet  
     SELECT DISTINCT  
      0,  
      DateRange,  
      SUM(TotalLoad),  
      SUM(WasherEfficiency),  
      @PlantTargetProduction,  
      SUM(StandardLoad),  
      SUM(Numberofbatches),  
      SUM(ActualRunTime),  
      SUM(TargetRuntime),  
      SUM(NumberofPieces),  
      SUM(Rewash)  
      ,@Viewtype   
      ,@Subview  
      ,0  
    FROM CTE  
     WHERE TotalLoad IS NOT NULL  
     GROUP BY DateRange  
       END  
    END  
  
    -- ******************************** ChainCategory View **********************************************  
    IF(@Viewtype = 5)  
    BEGIN  
  IF(@Subview = 16)  
  BEGIN  
     -- ToDo : Change this part for chaincategory  
     WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,textileId)  
   AS  
   (  
    SELECT      
   CC.NAME,  
   SUM(SPD.ActualProduction),  
   COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
   SUM(DISTINCT SPD.PlantTargetProd),  
   SUM(SPD.StandardProduction),  
   SUM([NoOfLoads]),  
   SUM(DISTINCT SPD.ShiftRunTime),  
   SUM(DISTINCT SPD.ShiftRunTime),  
   SUM(SPD.NoOfPieces),  
   SUM(SPD.Rewash),  
   cc.TextileId  
      FROM  
    @ProductionSummaryTable SPD  
   INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
    INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = PM.PlantProgramId  
    INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId   
   Group by   
     CC.Name,cc.TextileId,SPD.ShiftId  
     )  
   INSERT INTO @resultSet  
     SELECT DISTINCT  
      0,  
      DateRange,  
      SUM(TotalLoad),  
      SUM(WasherEfficiency),  
      @PlantTargetProduction,  
      SUM(StandardLoad),  
      SUM(Numberofbatches),  
      SUM(ActualRunTime),  
      SUM(TargetRuntime),  
      SUM(NumberofPieces),  
      SUM(Rewash)  
      ,@Viewtype   
      ,@Subview  
      ,textileId  
    FROM CTE  
     WHERE TotalLoad IS NOT NULL  
     GROUP BY DateRange,textileId  
  END  
      
  IF(@Subview = 19)  
  BEGIN  
   -- ToDo : Change this part for chaincategory  
    WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
   AS  
   (  
    SELECT    
   PCP.PlantProgramName,  
   SUM(SPD.ActualProduction),  
   COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
   SUM(DISTINCT SPD.PlantTargetProd),  
   SUM(SPD.StandardProduction),  
   SUM([NoOfLoads]),  
   SUM(DISTINCT SPD.ShiftRunTime),  
   SUM(DISTINCT SPD.ShiftRunTime),  
   SUM(SPD.NoOfPieces),  
   SUM(SPD.Rewash)  
     FROM @ProductionSummaryTable SPD  
   INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
    INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = PM.PlantProgramId  
    INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId   
    WHERE  
   (  
     CASE @drillvalue     
      WHEN '' THEN 'TRUE'           
      ELSE                                                      
      CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END              
      END='TRUE'  
    )  
   Group by   
     PCP.PlantProgramName,PCP.PlantProgramId,SPD.ShiftId  
     )  
     INSERT INTO @resultSet  
     SELECT DISTINCT  
      0,  
      DateRange,  
      SUM(TotalLoad),  
      SUM(WasherEfficiency),  
      @PlantTargetProduction,  
      SUM(StandardLoad),  
      SUM(Numberofbatches),  
      SUM(ActualRunTime),  
      SUM(TargetRuntime),  
      SUM(NumberofPieces),  
      SUM(Rewash)  
      ,@Viewtype   
      ,@Subview  
      ,0  
    FROM CTE  
     WHERE TotalLoad IS NOT NULL  
     GROUP BY DateRange  
  END  
  
 END  
  
    -- ******************************** Customer View ***************************************************  
 IF(@Viewtype = 6)  
 BEGIN  
   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
   AS  
   (  
   SELECT   
   PC.CustomerName,  
   SUM(SPD.ActualProduction),  
   COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
   SUM(DISTINCT SPD.PlantTargetProd),  
   SUM(SPD.StandardProduction),  
   SUM([NoOfLoads]),  
   SUM(DISTINCT SPD.ShiftRunTime),  
   SUM(DISTINCT SPD.ShiftRunTime),  
   SUM(SPD.NoOfPieces),  
   SUM(SPD.Rewash)  
   FROM @ProductionSummaryTable SPD  INNER JOIN TCD.PlantCustomer PC on PC.CustomerId = SPD.CustomerId  
   GROUP BY   
     PC.CustomerName,SPD.ShiftId  
     )  
     INSERT INTO @resultSet  
     SELECT DISTINCT  
      0,  
      DateRange,  
      SUM(TotalLoad),  
      SUM(WasherEfficiency),  
      @PlantTargetProduction,  
      SUM(StandardLoad),  
      SUM(Numberofbatches),  
      SUM(ActualRunTime),  
      SUM(TargetRuntime),  
      SUM(NumberofPieces),  
      SUM(Rewash)  
      ,@Viewtype   
      ,@Subview  
      ,0  
    FROM CTE  
     WHERE TotalLoad IS NOT NULL  
     GROUP BY DateRange  
 END  
  
-- ******************************** Formula View ****************************************************  
 IF(@Viewtype = 7)  
 BEGIN  
   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
   AS  
   (  
   SELECT   
   PM.Name,  
   SUM(SPD.ActualProduction),  
     COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
   SUM(DISTINCT SPD.PlantTargetProd),  
   SUM(SPD.StandardProduction),  
   SUM([NoOfLoads]),  
   SUM(DISTINCT SPD.ShiftRunTime),  
   SUM(DISTINCT SPD.ShiftRunTime),  
   SUM(SPD.NoOfPieces),  
   SUM(SPD.Rewash)  
   FROM @ProductionSummaryTable SPD   
   INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
   Group by   
   PM.Name,SPD.ShiftId  
   )  
   INSERT INTO @resultSet  
     SELECT DISTINCT  
      0,  
      DateRange,  
      SUM(TotalLoad),  
      SUM(WasherEfficiency),  
      @PlantTargetProduction,  
      SUM(StandardLoad),  
      SUM(Numberofbatches),  
      SUM(ActualRunTime),  
      SUM(TargetRuntime),  
      SUM(NumberofPieces),  
      SUM(Rewash)  
      ,@Viewtype   
      ,@Subview  
      ,0  
    FROM CTE  
     WHERE TotalLoad IS NOT NULL  
     GROUP BY DateRange  
    END  
  
-- ******************************** Formula segmentView ****************************************************  
 IF(@Viewtype = 8)  
 BEGIN  
  IF(@Subview =20)-- Formula Segment  
  BEGIN  
   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,FormulaSegmentID)  
   AS  
   (  
   SELECT   
   FS.SegmentName,  
   SUM(SPD.ActualProduction),  
   COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
   SUM(DISTINCT SPD.PlantTargetProd),  
   SUM(SPD.StandardProduction),  
   SUM([NoOfLoads]),  
   SUM(DISTINCT SPD.ShiftRunTime),  
   SUM(DISTINCT SPD.ShiftRunTime),  
   SUM(SPD.NoOfPieces),  
   SUM(SPD.Rewash),  
   SPD.FormulaSegmentID  
   FROM @ProductionSummaryTable SPD   
   INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
   LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=SPD.FormulaSegmentID  
   Group by SPD.FormulaSegmentID,FS.SegmentName   
   )  
   INSERT INTO @resultSet  
   (  
     ShiftId,  
     DateRange ,  
     TotalLoad  ,  
     WasherEfficiency ,  
     PlantTargetLoad  ,  
     StandardLoad ,  
     Numberofbatches ,  
     [ActualRunTime],   
     [TargetRunTime],  
     NumberofPieces  ,  
     Rewash ,  
     Viewtype ,  
     Subview ,  
     Id  
   )  
    SELECT DISTINCT  
      0,  
      DateRange,  
      SUM(TotalLoad),  
      SUM(WasherEfficiency),  
      @PlantTargetProduction,  
      SUM(StandardLoad),  
      SUM(Numberofbatches),  
      SUM(ActualRunTime),  
      SUM(TargetRuntime),  
      SUM(NumberofPieces),  
      SUM(Rewash)  
      ,@Viewtype   
      ,@Subview  
      ,0  
    FROM CTE  
     WHERE TotalLoad IS NOT NULL  
     GROUP BY DateRange  
  END  
  IF(@Subview =21)-- Formula Categories  
  BEGIN    
    WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,TextileId)  
    AS  
    (  
    SELECT EC.CategoryName, SUM(SPD.ActualProduction),COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
    SUM(DISTINCT SPD.PlantTargetProd),SUM(SPD.StandardProduction),SUM([NoOfLoads]),SUM(DISTINCT SPD.ShiftRunTime),SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(SPD.NoOfPieces),SUM(SPD.Rewash),EC.TextileId  
    FROM @ProductionSummaryTable SPD   
    LEFT JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId  
    WHERE EC.CategoryName IS NOT NULL  
    GROUP BY EC.CategoryName,EC.TextileId,SPD.ShiftId  
  
    UNION  
  
    SELECT CC.NAME,SUM(SPD.ActualProduction),COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
    SUM(DISTINCT SPD.PlantTargetProd),SUM(SPD.StandardProduction),SUM([NoOfLoads]),SUM(DISTINCT SPD.ShiftRunTime),SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(SPD.NoOfPieces),SUM(SPD.Rewash),cc.TextileId  
    FROM @ProductionSummaryTable SPD  
    INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
    INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = SPD.ChainProgaramId  
    INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId   
    Group by CC.Name,cc.TextileId,SPD.ShiftId  
    )  
    INSERT INTO @resultSet  
    (  
      ShiftId,  
      DateRange ,  
      TotalLoad  ,  
      WasherEfficiency ,  
      PlantTargetLoad  ,  
      StandardLoad ,  
      Numberofbatches ,  
      [ActualRunTime],   
      [TargetRunTime],  
      NumberofPieces  ,  
      Rewash ,  
      Viewtype ,  
      Subview ,  
      Id  
    )  
    SELECT DISTINCT  
    0,  
    DateRange,  
    SUM(TotalLoad),  
    SUM(WasherEfficiency),  
    SUM(PlantTargetLoad),  
    SUM(StandardLoad),  
    SUM(Numberofbatches),  
    SUM(ActualRunTime),  
    SUM(TargetRuntime),  
    SUM(NumberofPieces),  
    SUM(Rewash)  
    ,@Viewtype   
    ,@Subview  
    ,TextileId  
    FROM CTE  
    WHERE TotalLoad IS NOT NULL  
    GROUP BY DateRange,TextileId  
  END  
  IF(@Subview=22) --Formula  
  BEGIN  
   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
   AS  
   (  
    SELECT PM.Name,SUM(SPD.ActualProduction),COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
    SUM(DISTINCT SPD.PlantTargetProd),SUM(SPD.StandardProduction),SUM([NoOfLoads]),SUM(DISTINCT SPD.ShiftRunTime),SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(SPD.NoOfPieces),SUM(SPD.Rewash)  
    FROM @ProductionSummaryTable SPD   
    INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId  
    INNER JOIN TCD.ProgramMaster PM ON EC.TextileId = PM.EcolabTextileCategoryId AND SPD.ProgramMasterId = PM.ProgramId      
    WHERE  
     (  
     CASE      
      WHEN @drillvalue='' THEN 'TRUE'   
      WHEN @drillvalue IS NULL THEN 'TRUE'    
      ELSE                                                      
      CASE WHEN EC.TextileId IN (@drillvalue) THEN 'TRUE' END              
      END='TRUE'  
     ) AND PM.NAME IS NOT NULL  
    GROUP BY PM.Name,SPD.ShiftId  
  
    UNION   
  
    SELECT PM.Name,SUM(SPD.ActualProduction),COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
    SUM(DISTINCT SPD.PlantTargetProd),SUM(SPD.StandardProduction),SUM([NoOfLoads]),SUM(DISTINCT SPD.ShiftRunTime),SUM(DISTINCT SPD.ShiftRunTime),  
    SUM(SPD.NoOfPieces),SUM(SPD.Rewash)  
    FROM @ProductionSummaryTable SPD   
    INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId  
    INNER JOIN TCD.ProgramMaster PM ON  SPD.ProgramMasterId = PM.ProgramId    
    WHERE  
     (  
      CASE      
      WHEN @drillvalue='' THEN 'TRUE'   
      WHEN @drillvalue IS NULL THEN 'TRUE'    
      ELSE                                                      
      CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END              
      END='TRUE'  
     )  
    GROUP BY PM.Name,SPD.ShiftId     
   )  
   INSERT INTO @resultSet(ShiftId,DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,  
      StandardLoad,Numberofbatches,[ActualRunTime],[TargetRunTime],NumberofPieces  ,  
      Rewash,Viewtype,Subview,Id  
   )  
   SELECT DISTINCT 0,DateRange,SUM(TotalLoad), SUM(WasherEfficiency),SUM(PlantTargetLoad),  
    SUM(StandardLoad),SUM(Numberofbatches), SUM(ActualRunTime), SUM(TargetRuntime), SUM(NumberofPieces),  
    SUM(Rewash),@Viewtype ,@Subview,0  
   FROM CTE  
   WHERE TotalLoad IS NOT NULL  
   GROUP BY DateRange  
  END  
 END  
   
--- ********* Return result ********************  
  
    SELECT DISTINCT  ShiftId, DateRange,ISNULL([TCD].[FnConsumptionOnMetrics](TotalLoad,'Weight',@UserId),0),        
      ISNULL([TCD].[FnConsumptionOnMetrics](WasherEfficiency,'Weight',@UserId),0), --ISNULL(WasherEfficiency,0),  
      ISNULL([TCD].[FnConsumptionOnMetrics](PlantTargetLoad,'Weight',@UserId),0),--ISNULL(PlantTargetLoad,0),  
      ISNULL([TCD].[FnConsumptionOnMetrics](StandardLoad,'Weight',@UserId),0),--ISNULL(StandardLoad,0),  
      ISNULL(Numberofbatches,0),ISNULL(ActualRunTime,0),ISNULL(TargetRunTime,0),ISNULL(NumberofPieces,0),  
      ISNULL(Rewash,0),Viewtype,Subview ,Id,@CorrectionVariable  
      FROM @resultSet   
  
  
   
SET NOCOUNT OFF     
END  
-----------------


---------------------Formula Hieararchy Scripts Starts here------------------------------------------
SET IDENTITY_INSERT [TCD].[ReportViewByMode] ON
Go
--Formula ViewMode
IF NOT EXISTS (SELECT 1 FROM [TCD].[ReportViewByMode] rvm WHERE rvm.ID=8)
BEGIN
	INSERT INTO [TCD].[ReportViewByMode](ID,[Name]) values(8,'Formula')
End
Go
SET IDENTITY_INSERT [TCD].[ReportViewByMode] OFF
Go



IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyMaster  WHERE KeyName='FIELD_FORMULA_SEGMENT')
BEGIN
	INSERT INTO TCD.ResourceKeyMaster
	(KeyName,KeyDescription)
	VALUES('FIELD_FORMULA_SEGMENT','Formula Segment')
END
IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyValue  WHERE KeyName='FIELD_FORMULA_SEGMENT')
BEGIN
	INSERT INTO TCD.ResourceKeyValue
	(KeyName,Value,languageID,LastModifiedTime)
	Values('FIELD_FORMULA_SEGMENT','Formula Segment',1,GETDATE())
END

IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyMaster  WHERE KeyName='FIELD_FORMULA_CATEGORY')
BEGIN
	INSERT INTO TCD.ResourceKeyMaster
	(KeyName,KeyDescription)
	VALUES('FIELD_FORMULA_CATEGORY','Formula Category')
END
IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyValue  WHERE KeyName='FIELD_FORMULA_CATEGORY')
BEGIN
	INSERT INTO TCD.ResourceKeyValue
	(KeyName,Value,languageID,LastModifiedTime)
	Values('FIELD_FORMULA_CATEGORY','Formula Category',1,GETDATE())
END

IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyMaster  WHERE KeyName='FIELD_FORMULA')
BEGIN
	INSERT INTO TCD.ResourceKeyMaster
	(KeyName,KeyDescription)
	VALUES('FIELD_FORMULA','Formula')
END
IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyValue  WHERE KeyName='FIELD_FORMULA')
BEGIN
	INSERT INTO TCD.ResourceKeyValue
	(KeyName,Value,languageID,LastModifiedTime)
	Values('FIELD_FORMULA','Formula',1,GETDATE())
END



--SELECT * FROM TCD.[ReportSubView] 

IF NOT Exists(SELECT 1 FROM TCD.[ReportSubView] where ID = 20)
BEGIN
	INSERT INTO [TCD].[ReportSubView]
	(Id,Name,ViewModeId,UsageKey)
	VALUES(20,'Formula Segment',8,'FIELD_FORMULA_SEGMENT')
END
GO
IF NOT Exists(SELECT 1 FROM TCD.[ReportSubView] where ID = 21)
BEGIN
	INSERT INTO [TCD].[ReportSubView]
	(Id,Name,ViewModeId,UsageKey)
	VALUES(21,'Formula Category',8,'FIELD_FORMULA_CATEGORY')
END
GO
IF NOT Exists(SELECT 1 FROM TCD.[ReportSubView] where ID = 22)
BEGIN
	INSERT INTO [TCD].[ReportSubView]
	(Id,Name,ViewModeId,UsageKey)
	VALUES(22,'Formula',8,'FIELD_FORMULA')
END
GO
UPDATE [TCD].[ReportSubView]
SET DrilldownView = 21
WHERE Id= 20
GO
UPDATE [TCD].[ReportSubView]
SET DrilldownView = 22,
	DrillupView=20
WHERE Id= 21
GO

UPDATE [TCD].[ReportSubView]
SET DrillupView=21
WHERE Id= 22
GO


IF NOT Exists(SELECT 1 FROM [TCD].[ReportViewByModeMapping]  WHERE ViewModeId =8)
BEGIN
	INSERT INTO [TCD].[ReportViewByModeMapping]
	(ViewModeId,ReportId,ChartType,SubViewId,isDefault,HasGroupBy)
	VALUES(8,2,'pie',20,1,1)

	INSERT INTO [TCD].[ReportViewByModeMapping]
	(ViewModeId,ReportId,ChartType,SubViewId,isDefault,HasGroupBy)
	VALUES(8,7,'column',20,1,1)

	INSERT INTO [TCD].[ReportViewByModeMapping]
	(ViewModeId,ReportId,ChartType,SubViewId,isDefault,HasGroupBy)
	VALUES(8,20,'column',20,1,1)

	INSERT INTO [TCD].[ReportViewByModeMapping]
	(ViewModeId,ReportId,ChartType,SubViewId,isDefault,HasGroupBy)
	VALUES(8,10,'column',20,1,1)
END

--SELECT * FROM tcd.ReportViewModeRoleMapping where ViewModeId =3

IF NOT Exists(SELECT  * FROM tcd.ReportViewModeRoleMapping WHERE ViewModeId = 8)
BEGIN
	INSERT INTO tcd.ReportViewModeRoleMapping
	(ViewModeId,RoleID,SettingValue)
	VALUES(8,9,1)
	INSERT INTO tcd.ReportViewModeRoleMapping
	(ViewModeId,RoleID,SettingValue)
	VALUES(8,5,1)
	INSERT INTO tcd.ReportViewModeRoleMapping
	(ViewModeId,RoleID,SettingValue)
	VALUES(8,6,1)
	INSERT INTO tcd.ReportViewModeRoleMapping
	(ViewModeId,RoleID,SettingValue)
	VALUES(8,7,1)
	INSERT INTO tcd.ReportViewModeRoleMapping
	(ViewModeId,RoleID,SettingValue)
	VALUES(8,8,1)
END

INSERT INTO tcd.ReportColumnsMapping
(ColumnId,
ReportId,
IsChartDisplay,
DisplayOrder,
IsSortable,
ViewById,
SwitchModeId,
IsVisible,
[Precision])
SELECT  
ColumnId,
ReportId,
IsChartDisplay,
DisplayOrder,
IsSortable,
8 ViewById,
SwitchModeId,
IsVisible,
[Precision]
 FROM tcd.ReportColumnsMapping where ViewById =3 and ReportId = 2

 
INSERT INTO tcd.ReportColumnsMapping
	(ColumnId,
	ReportId,
	IsChartDisplay,
	DisplayOrder,
	IsSortable,
	ViewById,
	SwitchModeId,
	IsVisible,
	[Precision])
SELECT  
	ColumnId,
	ReportId,
	IsChartDisplay,
	DisplayOrder,
	IsSortable,
	8 ViewById,
	SwitchModeId,
	IsVisible,
	[Precision]
	 FROM tcd.ReportColumnsMapping where ViewById =3 and ReportId = 10

Go

DELETE  FROM tcd.ReportColumnsMapping
WHERE ReportId = 2 and ViewById = 8 and ColumnID= 244
Go

DELETE  FROM tcd.ReportColumnsMapping
WHERE ReportId = 10 and ViewById = 8 and ColumnID= 244
GO

UPDATE [TCD].ReportViewModeRoleMapping   
SET SettingValue= 0 ,IsDefault =null
WHERE ViewModeId in(3,4,5,7)

UPDATE tcd.ReportDefaultViewRoleMapping 
SET DefaultViewId =8 
WHERE DefaultViewId  in(3,4,5,7)

UPDATE TCD.ReportFilter
SET FilterName ='Formula Segment'--Ecolab Category
WHERE ReportFilterId=7


Go

UPDATE TCD.ReportFilter
SET FilterName ='Formula Segment'--Ecolab Category
WHERE ReportFilterId=7


UPDATE  TCD.ReportLocalizationFilterMapping
SET UsageKey ='FIELD_FORMULA_SEGMENT'
where ReportFilterId =7
Go

UPDATE  TCD.ReportFilter
SET FilterName ='Formula Category'
 where ReportFilterId  =23
 Go

UPDATE  TCD.ReportLocalizationFilterMapping
SET UsageKey ='FIELD_FORMULA_CATEGORY'
where ReportFilterId =23



 UPDATE TCD.ReportFilter SET FilterName ='Formula'
 where ReportFilterId = 10
 GO
UPDATE  TCD.ReportLocalizationFilterMapping
SET UsageKey ='FIELD_FORMULA'
where ReportFilterId =10
GO

IF NOT Exists(SELECT  1 FROM TCD.ReportFilterMApping WHERE ReportID = 5 and FilterID = 10)
BEGIN
INSERT INTO TCD.ReportFilterMApping(FilterId,ReportId,IsDefault,SortOrder)
VALUES(10,5,0,10)
END
Go

---------------------Formula Hieararchy Scripts Completes here------------------------------------------




IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[ReportOperationsSummary]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[ReportOperationsSummary] 
END 
GO 
CREATE PROCEDURE [TCD].[ReportOperationsSummary] 
/******************************************************************

DESCRIPTION		: Populating Operation Summary Report  data based on filters and views,sub views.


MODIFICATION HISTORY DETAILS:	
	21st Jan 2015 -  Kiran     -  Added Formula hierarchy -->Formula segment-->Formula category-->formula


REFERENC TABLES :
		Select * from TCD.Plant --Plant master
		Select * FROM TCD.PlantChain  --Master Plants
		Select * FROM TCD.PlantChainProgram
		Select * FROM TCD.ChainTextileCategory
		Select * FROM TCD.ProgramMaster
		Select * FROM TCD.EcolabTextileCategory  --Masters
		Select * FROM TCD.EcolabSaturation --Masters
		Select * FROM TCD.FormulaSegments --Masters

EXECUTION STATEMENT :

	EXEC [TCD].[ReportOperationsSummary1] @startdate = '2015-01-11',@enddate = '2016-01-30',@Viewtype  = '8',@Subview = '22',
										@Drillvalue = '',@EcolabAccountNumber = '040242802',@MachineType = '', @MachineGroup  = '',@Machine  = '', 
										@EcolabCategory  = '',@ChainCategory  = '', @PlantFormula  = '', @ChainFormula = '', @Customer  = '',
										@SortColumnId  = 0,@SortDirection  = '',@CurrencyCode = '', @UserId = 1, @FormulaSegement ='',
										@FormulaCategory='',@Formula=''


*******************************************************************/
     @startdate datetime = '',
     @enddate datetime = '',
     @Viewtype Int = '',
     @Subview Int= '',
     @Drillvalue varchar(100)= '',
     @EcolabAccountNumber Nvarchar(25) = '',
     @MachineType VARCHAR(20)= '',		--Washer Group type
     @MachineGroup VARCHAR(MAX) = '',  --washer Group
     @Machine VARCHAR(MAX) = '',
     @EcolabCategory VARCHAR(MAX) = '', --EcolabcategoritextileID
     @ChainCategory VARCHAR(MAX) = '',  --Chain Texttilecategori ID
     @PlantFormula  VARCHAR(MAX) = '',
     @ChainFormula VARCHAR(MAX) = '',
     @Customer VARCHAR(MAX) = '',
     @SortColumnId int = 0,
     @SortDirection varchar(4) = '',
     @CurrencyCode varchar(3) = '',
     @UserId INT = NULL,
	 @FormulaSegement VARCHAR(MAX)='', --Formula segment,
	 @FormulaCategory VARCHAR(MAX)='', --Formula category
	 @Formula VARCHAR(MAX)='' --Formula
AS   
BEGIN   
SET NOCOUNT ON
	SET @startdate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@startdate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@startdate AS time)) AS DateTime))
    SET @EndDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndDate AS time)) AS DateTime))
	--SELECT @startdate,@enddate

    DECLARE @ReportGenerated INT = 6, @Month INT = MONTH(GETDATE()),@NoOfLoads int
	--SELECT @Month

    --Inserting the record into Report History 
	INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)
	SELECT @EcolabAccountNumber,UM.UserId, UM.LoginName, GETUTCDATE(), @ReportGenerated,
	CASE WHEN @ReportGenerated = 6 THEN 'Generated Report : Operations Summary Report' END
	FROM TCD.UserMaster UM
	WHERE UM.EcolabAccountNumber = @EcolabAccountNumber AND UM.UserId = @UserId
    --Completed the record insertion into Report History */

	-- Return Table set
    DECLARE @resultSet Table
    (
      ShiftId Int,DateRange varchar(100),TotalLoad Decimal(18,2),Numberofbatches INT,ActualChemicalConsumption Decimal(18,2),
      TargetChemicalConsumption Decimal(18,2),ActualEnergyConsumption  Decimal(18,2),TargetEnergyConsumption Decimal(18,2),
      ActualWaterConsumption  Decimal(18,2),TargetWaterConsumption Decimal(18,2),ActualChemicalCost Decimal(18,2),ActualWaterCost Decimal(18,2),
      ActualEnergyCost Decimal(18,2),Viewtype varchar(100) , Subview varchar(100) , Id int        
    )

	--Machine types 
    DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))
    INSERT INTO @MachineTypeTable EXEC [TCD].[CharlistToTable] @MachineType,','

	--Washergroups 
    DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))
    INSERT INTO @WasherGroupTable EXEC [TCD].[CharlistToTable] @machineGroup,','  

	--Machine list
    DECLARE @MachineTable TABLE(Machine Varchar(100))
    INSERT INTO @MachineTable EXEC [TCD].[CharlistToTable] @Machine,','

	--Ecolab category
    DECLARE @EcolabCategoryTable TABLE(EcolabCategory Varchar(100))
    INSERT INTO @EcolabCategoryTable EXEC [TCD].[CharlistToTable] @EcolabCategory,','

	--Chain category
    DECLARE @ChainCategoryTable TABLE(ChainCategory Varchar(100))
    INSERT INTO @ChainCategoryTable EXEC [TCD].[CharlistToTable] @ChainCategory,','

	--Plant fomula
    DECLARE @PlantFormulaTable TABLE(PlantFormula Varchar(100))
    INSERT INTO @PlantFormulaTable EXEC [TCD].[CharlistToTable] @PlantFormula,','

	--chain formula
    DECLARE @ChainFormulaTable TABLE(ChainFormula Varchar(100))
    INSERT INTO @ChainFormulaTable EXEC [TCD].[CharlistToTable] @ChainFormula,','
	
	--customer 
    DECLARE @CustomerTable TABLE(Customer Varchar(100))
    INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','

	--Formula Segment --added by Kiran
	DECLARE @FormulaSegmentTable TABLE(FormulaSegment Varchar(1000))
    INSERT INTO @FormulaSegmentTable EXEC [TCD].[CharlistToTable] @FormulaSegement,','

	-----Formula category--------Start
	DECLARE @FormulaCategoryTable TABLE(FormulaCategory Varchar(1000),Type CHAR(1))
    INSERT INTO @FormulaCategoryTable(FormulaCategory) EXEC [TCD].[CharlistToTable] @Formulacategory,','	
	
	--segregating Ecolab/Chain categories
	--UPDATE @FormulaCategoryTable SET TYPE=RIGHT(FormulaCategory,1),FormulaCategory=LEFT(FormulaCategory,LEN(FormulaCategory)-2)
	
	--Below 1000 Ecolab category
	UPDATE @FormulaCategoryTable SET TYPE='E' WHERE FormulaCategory<1000
	--Above 1000 consider as Chain category
	UPDATE @FormulaCategoryTable SET TYPE='C' WHERE FormulaCategory>=1000

	--Rollbacking to actual ID
	UPDATE @FormulaCategoryTable SET FormulaCategory=FormulaCategory-1000 WHERE TYPE='C'
	--SELECT * FROM @FormulaCategoryTable
	
	--SELECT * FROM @FormulaCategoryTable

	INSERT INTO @EcolabCategoryTable(EcolabCategory)
	SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='E'	

	INSERT INTO @ChainCategoryTable(ChainCategory)
	SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='C'

	--Value Assigning
	IF (EXISTS(SELECT * FROM @EcolabCategoryTable) AND @FormulaCategory!='')
	BEGIN
		SET @EcolabCategory=@FormulaCategory
	END
	IF (EXISTS(SELECT * FROM @ChainCategoryTable) AND @FormulaCategory!='')
	BEGIN
		SET @ChainCategory=@FormulaCategory
	END
	---Formula category-------------------------End

	-----Formula Ecolab/Chain categories
	DECLARE @FormulaTable TABLE(Formula Varchar(1000),Type CHAR(1))
    INSERT INTO @FormulaTable(Formula) EXEC [TCD].[CharlistToTable] @Formula,','

	--segregating Ecolab/Chain categories
	--UPDATE @FormulaTable SET TYPE=RIGHT(Formula,1),Formula=LEFT(Formula,LEN(Formula)-2)
	/*
	--Below 1000 Ecolab category
	UPDATE @FormulaTable SET TYPE='E' WHERE Formula<1000
	--Above 1000 consider as Chain category
	UPDATE @FormulaTable SET TYPE='C' WHERE Formula>=1000

	--Rollbacking to actual ID
	UPDATE @FormulaTable SET Formula=Formula-1000 WHERE TYPE='C'
	*/
	--Select * from @FormulaTable
	--Plant fomula   
    INSERT INTO @PlantFormulaTable(PlantFormula) 
	SELECT Formula FROM @FormulaTable --WHERE Type='E'
	--chain formula   
    INSERT INTO @ChainFormulaTable(ChainFormula) 
	SELECT Formula FROM @FormulaTable --WHERE Type='C'
	--SELECT * FROM @PlantFormulaTable
	--SELECT * FROM @ChainFormulaTable

	--Value Assigning
	IF (EXISTS(SELECT * FROM @PlantFormulaTable) AND @Formula!='')
	BEGIN
		SET @PlantFormula=@Formula
	END
	IF (EXISTS(SELECT * FROM @ChainFormulaTable) AND @Formula!='')
	BEGIN
		SET @ChainFormula=@Formula
	END
	--SELECT @PlantFormula,@ChainFormula
	-----Formula Segregation end

    DECLARE @actualproduction int,@uom int
    SELECT @uom =UM.UOMId FROM TCD.UserMaster AS UM WHERE UM.UserId = @UserId

   	--Operation summary Table Declaration
    DECLARE @OperationSummaryTable TABLE 
	 ( 
		[ShiftId] [int] NULL,[ShiftName] Varchar(100) NULL,RecordDate date,
		[MachineId] [int] NULL,[ProgramMasterId] [int] NULL,[EcolabWasherId] [int] NULL,
		ActualProduction [int] NULL,
		[NoOfLoads] [int] NULL,ActualChemicalConsumption Decimal(18,2),
		TargetChemicalConsumption Decimal(18,2),ActualEnergyConsumption  Decimal(18,2),TargetEnergyConsumption Decimal(18,2),
		ActualWaterConsumption  Decimal(18,2),TargetwaterConsumption Decimal(18,2),
		ActualChemicalCost decimal(18,2),ActualWaterCost decimal(18,2),ActualEnergyCost decimal(18,2),
		EcolabTextileId int,ChainTextileId int,ChainProgaramId int,CustomerId int,FormulaSegmentID INT        
        )

	--Operation summary Table Insertion
    INSERT INTO @OperationSummaryTable
		(
		[ShiftId] ,[ShiftName] ,RecordDate ,
		[MachineId] ,[ProgramMasterId],[EcolabWasherId],
		ActualProduction,
		[NoOfLoads],ActualChemicalConsumption,
		TargetChemicalConsumption,ActualEnergyConsumption ,TargetEnergyConsumption ,
		ActualWaterConsumption  ,TargetwaterConsumption ,
		ActualChemicalCost ,ActualWaterCost ,ActualEnergyCost ,
		EcolabTextileId ,ChainTextileId ,ChainProgaramId ,FormulaSegmentID,CustomerId
		)
		SELECT DISTINCT SPD.[ShiftId],PS.ShiftName, CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date),         
		SPD.[MachineId] ,SPD.[ProgramMasterId],SPD.[EcolabWasherId],
		
		CASE @uom WHEN 1 THEN SUM( DISTINCT ISNULL(spd.ActualProduction,0))
			WHEN 2 THEN ISNULL([TCD].[FnConsumptionOnMetrics](SUM( DISTINCT ISNULL(spd.ActualProduction,0)),'Weight',@UserId),0) END,         
		SUM(DISTINCT ISNULL(SPD.NoOfLoads,0)),SUM(ISNULL(SCD.ActualConsumption,0)),
		SUM(ISNULL(SCD.TargetConsumption,0)),SUM(ISNULL(SED.ActualConsumption,0)),SUM(ISNULL(SED.TargetConsumption,0)),
		SUM(ISNULL(SWD.ActualConsumption,0)),SUM(ISNULL(SWD.TargetConsumption,0)),
		SUM(ISNULL(SCD.ActualCost,0)),SUM(ISNULL(SED.ActualCost,0)),SUM(ISNULL(SWD.ActualCost,0)),  		  
		              
		--SPD.EcolabTextileId,SPD.ChainTextileId,SPD.ChainProgaramId,
				 
		CASE WHEN PM.PlantProgramId IS NOT NULL THEN ChainPlant.EcolabTextileCategoryId
		ELSE ETC1.TextileId END AS EcolabTextileCategory,
		CASE WHEN PM.PlantProgramId IS NOT NULL THEN ChainPlant.ChainTextileCategoryId
		ELSE NULL END AS ChainTextilecategory,	
		PM.PlantProgramId,
		CASE WHEN PM.PlantProgramId IS NOT NULL THEN ChainPlant.FormulaSegmentId
		ELSE FS1.FormulaSegmentID END AS Formulasegment,
		SPD.CustomerId
		         
		FROM 
		TCD.ShiftProductionDataRollup SPD 
		INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId 
		LEFT JOIN  TCD.ShiftChemicalDataRollup SCD  ON SPD.ShiftId = SCD.ShiftId AND SPD.MachineId = SCD.MachineId AND SPD.ProgramMasterId = SCD.ProgramMasterId
		LEFT JOIN TCD.ShiftEnergyDataRollup SED ON SED.ShiftId = SPD.ShiftId AND SED.MachineId = SPD.MachineId AND SED.ProgramMasterId = SPD.ProgramMasterId
		LEFT JOIN TCD.[ShiftWaterDataRollup] SWD ON SED.ShiftId = SPD.ShiftId AND SWD.MachineId = SPD.MachineId AND SWD.ProgramMasterId = SPD.ProgramMasterId
		INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId 
		--Added by Kiran
		LEFT OUTER JOIN
		 (
			--IF Chain Plant
			SELECT PCP.PlantProgramId,PCP.PlantChainId,PCP.ChainTextileCategoryId,PCP.EcolabTextileCategoryId,
			PCP.FormulaSegmentId,PCP.EcolabSaturationId
			FROM TCD.PlantChainProgram PCP 
			LEFT OUTER JOIN TCD.ChainTextileCategory CTC ON CTC.TextileId=PCP.ChainTextileCategoryId
			LEFT OUTER JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId=PCP.EcolabTextileCategoryId
			LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=PCP.FormulaSegmentId
			LEFT OUTER JOIN TCD.EcolabSaturation ES ON ES.EcolabSaturationId=PCP.EcolabSaturationId
		 )ChainPlant ON PM.PlantProgramId=ChainPlant.PlantProgramId

		LEFT OUTER JOIN TCD.EcolabTextileCategory ETC1 ON ETC1.TextileId=PM.EcolabTextileCategoryId
		LEFT OUTER JOIN TCD.FormulaSegments FS1 ON FS1.FormulaSegmentID=PM.FormulaSegmentId
		LEFT OUTER JOIN TCD.EcolabSaturation ES1 ON ES1.EcolabSaturationId=PM.EcolabSaturationId
		----End

        WHERE SPD.MachineId NOT IN (SELECT ms.WasherId FROM TCD.MachineSetup AS ms WHERE ms.IsPony = 1)
		AND 
			CASE @StartDate                                                                                
			WHEN '' THEN 
				CASE WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
			ELSE 
				CASE WHEN PS.[StartDateTime]  >= @startdate AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
			END='TRUE'		
		AND
			CASE @MachineType   
			WHEN '' THEN 'TRUE'         
			ELSE                                                      
			CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
			MS.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable))) THEN 'TRUE' END                                                      
			END='TRUE'	
		AND
			CASE @machineGroup   
			WHEN '' THEN 'TRUE'         
			ELSE                                                      
			CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
			MS.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable)) THEN 'TRUE' END                                                      
			END='TRUE' 
		AND
			CASE @Machine   
			WHEN '' THEN 'TRUE'         
			ELSE                                                      
			CASE WHEN SPD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
			END='TRUE'		 
		AND 
		/*   
			CASE @EcolabCategory   
			WHEN '' THEN 'TRUE'         
			ELSE                                                      
			CASE WHEN SPD.EcolabTextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                      
			END='TRUE' 
		AND 		   
			CASE @ChainCategory   
			WHEN '' THEN 'TRUE'         
			ELSE                                                      
			CASE WHEN SPD.ChainTextileId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END                                                      
			END='TRUE'
        AND
		   
			CASE @PlantFormula   
			WHEN '' THEN 'TRUE'         
			ELSE                                                      
			CASE WHEN SPD.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                      
			END='TRUE'  
        AND    
			CASE @ChainFormula   
			WHEN '' THEN 'TRUE'         
			ELSE                                                      
			CASE WHEN SPD.ChainTextileId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END                                                      
			END='TRUE'
        AND 
		*/		
			CASE @Customer   
			WHEN '' THEN 'TRUE'         
				ELSE                                                      
				CASE WHEN SPD.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                      
			END='TRUE'	

		--Added by Kiran
		AND 
			CASE @EcolabCategory   
			WHEN '' THEN 'TRUE' 
			ELSE
				CASE WHEN PM.PlantProgramId IS NOT NULL THEN
						CASE WHEN ChainPlant.EcolabTextileCategoryId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END					                                                                              
				ELSE 
				CASE WHEN ETC1.TextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable)  THEN 'TRUE'END 
			END  
			END='TRUE'                            
		AND 
			CASE @ChainCategory    
			WHEN '' THEN 'TRUE' 
				ELSE 
					CASE WHEN PM.PlantProgramId IS NOT NULL THEN
						CASE WHEN ChainPlant.ChainTextileCategoryId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END	
					ELSE 'TRUE' END                                                                                			                                                  
			END='TRUE'
		AND 			
			CASE @PlantFormula   
			WHEN '' THEN 'TRUE'         
			ELSE                                                      
			CASE WHEN SPD.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                      
			END='TRUE'
        AND    
			CASE @ChainFormula   
			WHEN '' THEN 'TRUE'         
			ELSE                                                      
				CASE WHEN PM.PlantProgramId IS NOT NULL THEN
						CASE WHEN ChainPlant.ChainTextileCategoryId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END	
				ELSE 'TRUE' END                                                        
			END='TRUE'
        AND 
			CASE @FormulaSegement                                                                                
			WHEN '' THEN  'TRUE'
			ELSE
				CASE WHEN PM.PlantProgramId IS NOT NULL THEN
					CASE WHEN ChainPlant.FormulaSegmentId IN (SELECT FormulaSegment FROM @FormulaSegmentTable) THEN 'TRUE' END						                                                                               
				ELSE 
					CASE WHEN FS1.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)  THEN 'TRUE'END   
				END                                                     
			END='TRUE'

		GROUP BY SPD.[ShiftId],PS.ShiftName,SPD.[MachineId] ,SPD.[ProgramMasterId],SPD.[EcolabWasherId],
		ChainPlant.ChainTextileCategoryId,ChainPlant.EcolabTextileCategoryId,
		SPD.ChainProgaramId,
		SPD.CustomerId,CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date),
		ChainPlant.FormulaSegmentId,PM.PlantProgramId,ETC1.TextileId,FS1.FormulaSegmentID
		
		--Kiran Added end
			
        /*    
		GROUP BY SPD.[ShiftId],PS.ShiftName,SPD.[MachineId] ,SPD.[ProgramMasterId],SPD.[EcolabWasherId],SPD.EcolabTextileId,         SPD.ChainTextileId,
		SPD.ChainProgaramId,
		SPD.CustomerId,CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date)--,PM.FormulaSegmentId
		*/
		--UPDATE     @OperationSummaryTable SET FormulaSegmentID=1 WHERE ShiftId=4
		--UPDATE     @OperationSummaryTable SET FormulaSegmentID=2 WHERE ShiftId in(7,1027)
		--UPDATE     @OperationSummaryTable SET FormulaSegmentID=3 WHERE ShiftId=1026

    --SELECT * FROM @OperationSummaryTable
    SELECT @NoOfLoads =  SUM(NoOfLoads) 
		FROM ( SELECT SUM(OST.NoOfLoads) AS NoOfLoads FROM @OperationSummaryTable AS OST GROUP BY OST.ShiftId )  NoOfLoads
	
    IF(@Viewtype = 3) ---Ecolab Categories

    BEGIN
		---EcoLabCategory
		IF(@Subview = 12)
		BEGIN
			 INSERT INTO @resultSet
			 (
				ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
				TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
				ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
				ActualEnergyCost ,Viewtype, Subview,Id 
			 )
			 SELECT DISTINCT
				0
				,EC.CategoryName
				,SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
				,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				,@Viewtype 
				,@Subview
				,EC.TextileId
			FROM @OperationSummaryTable SPD LEFT JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
			GROUP BY EC.CategoryName,EC.TextileId
        END
		---EcoLabFormula
		IF(@Subview = 17)
		BEGIN
			INSERT INTO @resultSet
			 (
				ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
				TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
				ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
				ActualEnergyCost ,Viewtype, Subview,Id 
			 )
			 SELECT 
			   DISTINCT
				0, 
				PM.Name
				,SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
				,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				,@Viewtype 
				,@Subview
				,0
				FROM @OperationSummaryTable SPD INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
					 INNER JOIN TCD.ProgramMaster PM ON EC.TextileId = PM.EcolabTextileCategoryId AND SPD.ProgramMasterId = PM.ProgramId
    
			WHERE
				(
				CASE    
				 WHEN @drillvalue='' THEN 'TRUE' 
				 WHEN @drillvalue IS NULL THEN 'TRUE'  
				 ELSE                                                    
				  CASE WHEN EC.TextileId IN (@drillvalue) THEN 'TRUE' END            
				 END='TRUE'
				)
			GROUP BY  PM.Name
		END
	END

	-- ************************ By Textile Category View ************************************************
	IF(@Viewtype = 4)
	BEGIN 
		--TextileCategory
		IF(@Subview = 15)
		BEGIN
			 INSERT INTO @resultSet
			 (
				ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
				TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
				ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
				ActualEnergyCost ,Viewtype, Subview,Id 
			 )
			 SELECT DISTINCT
				0,
				CC.Name
				,SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
				,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				,@Viewtype 
				,@Subview
				,CC.TextileId
				FROM @OperationSummaryTable SPD LEFT JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
			 GROUP BY CC.Name,CC.TextileId
		END  
		--TextileFormula
		IF(@Subview = 18)
		BEGIN
			 INSERT INTO @resultSet
			 (
				ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
				TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
				ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
				ActualEnergyCost ,Viewtype, Subview,Id 
			 )
			 SELECT DISTINCT       
				0, 
				PM.Name
				,SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
				,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				,@Viewtype 
				,@Subview
				,0
				FROM @OperationSummaryTable SPD INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
					 INNER JOIN TCD.ProgramMaster PM ON CC.TextileId = PM.ChainTextileId AND SPD.ProgramMasterId = PM.ProgramId
    
			WHERE
				(
				CASE    
				 WHEN @drillvalue='' THEN 'TRUE' 
				 WHEN @drillvalue IS NULL THEN 'TRUE'  
				 ELSE                                                    
				  CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END            
				 END='TRUE'
				)
			GROUP BY PM.Name
		END
	END

	-- ******************************** Timeline View ***************************************************
	IF(@Viewtype = 1)
	BEGIN
		---- By TimeLine - Day View
		IF(@Subview = 5)
		BEGIN 
			INSERT INTO @resultSet
			 (
				ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
				TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
				ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
				ActualEnergyCost ,Viewtype, Subview,Id 
			 )
				SELECT DISTINCT
				0,
				SPD.ShiftName
				 ,SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
				,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				,@Viewtype 
				,@Subview
				,0
				 FROM @OperationSummaryTable SPD
				GROUP BY SPD.ShiftName
		END		
		---- By TimeLine - Week View
		IF (@Subview = 4)
		BEGIN
			INSERT INTO @resultSet
			 (
				ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
				TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
				ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
				ActualEnergyCost ,Viewtype, Subview,Id 
			 )
			SELECT DISTINCT
			0,
			CAST(RecordDate AS nvarchar(100))
			,SUM(SPD.ActualProduction)
			,sum(DISTINCT NoOfLoads)
			,SUM(ActualChemicalConsumption)
			,SUM(TargetChemicalConsumption) 
			,SUM(ActualEnergyConsumption)
			,SUM(TargetEnergyConsumption)
			,SUM(ActualWaterConsumption)
			,SUM(TargetWaterConsumption)
			,SUM(ActualChemicalCost)
			,SUM(ActualWaterCost)
			,SUM(ActualEnergyCost)
			,@Viewtype 
			,@Subview
			,0
				FROM @OperationSummaryTable SPD
			GROUP BY DATEPART(weekday,RecordDate),RecordDate
		END
		
		---- By TimeLine - Month View
		IF(@Subview = 3)
		 BEGIN
			DECLARE @FirstDay date = (SELECT TOP 1 RecordDate FROM @OperationSummaryTable ORDER BY RecordDate)
			DECLARE @LastDay date = (SELECT TOP 1 RecordDate FROM @OperationSummaryTable ORDER BY RecordDate DESC)
			DECLARE @FirstSunday date = NULL,
			@LastSaturday date = NULL
						    
			SELECT 
			@FirstSunday = CAST(DateAdd(dd, (8-DatePart(WEEKDAY, 
			   DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)))%7, 
			   DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)) AS DATE) 

			 SELECT
			  @LastSaturday = 
				DATEADD(dd,
					-DATEPART(WEEKDAY,
					  DATEADD(dd, -DAY(DATEADD(month, 1, @LastDay)),
					  DATEADD(month, 1, @LastDay))) ,
					DATEADD(dd, -DAY(DATEADD(MONTH, 1, @LastDay)), DATEADD(MONTH, 1, @LastDay)));

			WITH CTE(DateRange ,TotalLoad,Numberofbatches,ActualChemicalConsumption,TargetChemicalConsumption,
			ActualEnergyConsumption,TargetEnergyConsumption,ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,ActualEnergyCost)
			AS
			(
			SELECT        
				CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,-1,@FirstSunday)) = 7 
			   AND (SELECT COUNT(1) FROM @OperationSummaryTable WHERE RecordDate < DATEADD(DD,-1,@FirstSunday)) = 0)
			   THEN CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100))
			   WHEN DATEADD(DD,-1,@FirstSunday) > CAST(GETDATE() AS DATE) 
			   THEN
			   CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @enddate, 101) AS nvarchar(100))
			   ELSE
			   CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) END As DateRange,
			   SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
				,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)

				 FROM @OperationSummaryTable SPD
				WHERE RecordDate < @FirstSunday AND RecordDate >= @FirstDay

        
				UNION ALL

  
				SELECT
        
				--CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100)) AS StartDate,
				--CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) AS EndDate,
				  CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100))  + CHAR(13) + '-' +
				 CASE WHEN CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) >
				 CAST(Convert(varchar, DateAdd(dd, (1 - DatePart(dw, @enddate) + 1), @enddate), 101) AS nvarchar(100))
				 THEN  CAST(Convert(varchar, DateAdd(dd, 1-1, @enddate), 101) AS nvarchar(100))
				 ELSE CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) END
				 As DateRange,
				 SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
				,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				 ,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				FROM @OperationSummaryTable SPD
				   WHERE RecordDate BETWEEN @FirstSunday AND @LastSaturday
				GROUP BY Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101),
				 Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101)
       
			   UNION ALL

				SELECT 
				 CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,1,@LastSaturday)) = 1 
				AND (SELECT COUNT(1) FROM @OperationSummaryTable WHERE RecordDate > DATEADD(DD,1,@LastSaturday)) = 0)
				THEN 
				CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) 
				ELSE
			   CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @LastDay, 101) AS nvarchar(100)) END   As DateRange,
				SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
				,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				 ,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				FROM @OperationSummaryTable SPD
				WHERE RecordDate > @LastSaturday AND RecordDate <= @LastDay
				)
				INSERT INTO @resultSet
				 (
					ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
					TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
					ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
					ActualEnergyCost ,Viewtype, Subview,Id 
				)
				SELECT DISTINCT
				0,
				DateRange,
				TotalLoad,
				Numberofbatches,
				ActualChemicalConsumption,
				TargetChemicalConsumption,
				ActualEnergyConsumption,
				TargetEnergyConsumption,
				ActualWaterConsumption,
				TargetWaterConsumption,
				ActualChemicalCost,
				ActualWaterCost,
				ActualEnergyCost       
				,@Viewtype 
				,@Subview
				 ,0
				FROM CTE
				WHERE TotalLoad IS NOT NULL

        END
		---- By TimeLine - Quarter View
		IF(@Subview = 2)
		BEGIN
			DECLARE @QuarterYear VARCHAR(100) = YEAR(@enddate);
			INSERT INTO @resultSet
			 (
				ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
				TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
				ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
				ActualEnergyCost ,Viewtype, Subview,Id 
			 )
			SELECT  DISTINCT
			    0,
				DATENAME(MONTH, RecordDate) + ' ' + @QuarterYear As DateRange,
				SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
				,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption) 
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				,@Viewtype 
				,@Subview
				,0
			FROM @OperationSummaryTable SPD
			GROUP BY  DATEPART(MONTH, RecordDate),DATENAME(MONTH, RecordDate)
		END   
		---- By TimeLine - Year View
		IF(@Subview = 1)
		BEGIN
			DECLARE @Year VARCHAR(100) = RIGHT(YEAR(@enddate),2)
			INSERT INTO @resultSet
			 (
				ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
				TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
				ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
				ActualEnergyCost ,Viewtype, Subview,Id 
			 )
			SELECT DISTINCT
				0,
				CASE 'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10))
				WHEN 'Q1' THEN 'Jan' + @Year + '- Mar' + @Year
				WHEN 'Q2' THEN 'Apr' + @Year + '- Jun' + @Year
				WHEN 'Q3' THEN 'Jul' + @Year + '-Sep' + @Year
				WHEN 'Q4' THEN 'Oct' + @Year + '- Dec'+ @Year
				END AS DateRange,
				SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
				,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				,@Viewtype 
				,@Subview
				,0
			FROM @OperationSummaryTable SPD
			GROUP BY DATEPART(QUARTER, RecordDate)
		END
    END

    -- ******************************** Location View ***************************************************
    IF(@Viewtype = 2)
    BEGIN
		--Plant
		IF(@Subview = 9)
		BEGIN
			WITH CTE(DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption,TargetChemicalConsumption,ActualEnergyConsumption,
			TargetEnergyConsumption,ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,ActualEnergyCost,WasherGroupId)
			AS
			(
			SELECT 
				WG.WasherGroupName,
				SUM(SPD.ActualProduction)
			   ,sum(NoOfLoads)
			   ,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				 ,SUM(ActualChemicalCost)
			 ,SUM(ActualWaterCost)
			 ,SUM(ActualEnergyCost)
			   ,WG.WasherGroupId

			FROM @OperationSummaryTable SPD LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId
					 LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId 
			GROUP BY WG.WasherGroupName,WG.WasherGroupId--,SPD.ShiftId
			) 

			 INSERT INTO @resultSet
			 (
				ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
				TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
				ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
				ActualEnergyCost ,Viewtype, Subview,Id 
			 )
			SELECT 0, 
			DateRange,
			SUM(TotalLoad),
			SUM(Numberofbatches),
			SUM(ActualChemicalConsumption)
			,SUM(TargetChemicalConsumption) 
			,SUM(ActualEnergyConsumption)
			,SUM(TargetEnergyConsumption)
			,SUM(ActualWaterConsumption)
			,SUM(TargetWaterConsumption)
			,SUM(ActualChemicalCost)
			,SUM(ActualWaterCost)
			,SUM(ActualEnergyCost)
			,@Viewtype 
			,@Subview
			,WasherGroupId
			FROM CTE 
			WHERE TotalLoad IS NOT NULL       
			GROUP BY DateRange,WasherGroupId
		 END
		--WasherGroup
		IF(@Subview = 10)
		BEGIN
			 WITH CTE(DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption,TargetChemicalConsumption,ActualEnergyConsumption,
			 TargetEnergyConsumption,ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,ActualEnergyCost)
			AS
			(
			SELECT 
				CAST( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName as MachineName,
				SUM(SPD.ActualProduction)
			   ,sum(NoOfLoads)
			   ,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)     
			FROM @OperationSummaryTable SPD 
			LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId
			LEFT JOIN TCD.Washer w on MS.WasherId=w.WasherId
			LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId 
			WHERE 
			  (
			   CASE @drillvalue   
				   WHEN '' THEN 'TRUE'         
				   ELSE                                                    
					CASE WHEN WG.WasherGroupId IN (@drillvalue) THEN 'TRUE' END            
				   END='TRUE'
			  )
			 GROUP BY CAST( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName--,SPD.ShiftId
			 )

			 INSERT INTO @resultSet
			 (
				ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
				TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
				ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
				ActualEnergyCost ,Viewtype, Subview,Id 
			 )
			 SELECT  0, 
				DateRange,
				SUM(TotalLoad),
				SUM(Numberofbatches),
				SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				,@Viewtype 
				,@Subview
				,0
				 FROM CTE 
				WHERE TotalLoad IS NOT NULL
				GROUP BY DateRange
		END
    END

    -- ******************************** ChainCategory View **********************************************
    IF(@Viewtype = 5)
    BEGIN
		--ChainCategory
		IF(@Subview = 16)
		BEGIN
			-- ToDo : Change this part for chaincategory
			 INSERT INTO @resultSet
			 (
				ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
				TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
				ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
				ActualEnergyCost ,Viewtype, Subview,Id 
			 )
				SELECT DISTINCT
				0,  
				CC.NAME,
				SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
				,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				,@Viewtype 
				,@Subview
				,CC.TextileId
				FROM
				@OperationSummaryTable SPD
				INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
				INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = PM.PlantProgramId
				INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId 
				Group by  CC.Name,CC.TextileId
		END
	    --ChainFormula
		IF(@Subview = 19)
		BEGIN
			-- ToDo : Change this part for chaincategory
			 INSERT INTO @resultSet
			 (
				ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
				TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
				ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
				ActualEnergyCost ,Viewtype, Subview,Id 
			 )
			 SELECT  DISTINCT
				0,
				PCP.PlantProgramName,
				SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
			    ,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				,@Viewtype 
				,@Subview
				,0
				FROM @OperationSummaryTable SPD
				INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
				INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = PM.PlantProgramId
				INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId 
				 WHERE
				(
			   CASE @drillvalue   
				   WHEN '' THEN 'TRUE'         
				   ELSE                                                    
				   CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END            
				   END='TRUE'
			  )
			 Group by  PCP.PlantProgramName,PCP.PlantProgramId
		END
	END

    -- ******************************** Customer View ***************************************************
	IF(@Viewtype = 6)
	BEGIN
		INSERT INTO @resultSet
		(
		ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
		TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
		ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
		ActualEnergyCost ,Viewtype, Subview,Id 
		)
		SELECT DISTINCT
		0,
		PC.CustomerName,
		SUM(SPD.ActualProduction)
		,sum(DISTINCT NoOfLoads)
		,SUM(ActualChemicalConsumption)
		,SUM(TargetChemicalConsumption) 
		,SUM(ActualEnergyConsumption)
		,SUM(TargetEnergyConsumption)
		,SUM(ActualWaterConsumption)
		,SUM(TargetWaterConsumption)
		,SUM(ActualChemicalCost)
		,SUM(ActualWaterCost)
		,SUM(ActualEnergyCost)
		,@Viewtype 
		,@Subview
		,0
		FROM @OperationSummaryTable SPD  INNER JOIN TCD.PlantCustomer PC on PC.CustomerId = SPD.CustomerId
		GROUP BY PC.CustomerName
	END

	-- ******************************** Formula View ****************************************************	
	IF(@Viewtype = 7)
	BEGIN
		INSERT INTO @resultSet
		(
		ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
		TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
		ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
		ActualEnergyCost ,Viewtype, Subview,Id 
		)
		SELECT DISTINCT
		0,
		PM.Name,
		SUM(SPD.ActualProduction)
		,sum(DISTINCT NoOfLoads)
		,SUM(ActualChemicalConsumption)
		,SUM(TargetChemicalConsumption) 
		,SUM(ActualEnergyConsumption)
		,SUM(TargetEnergyConsumption)
		,SUM(ActualWaterConsumption)
		,SUM(TargetWaterConsumption)
		,SUM(ActualChemicalCost)
		,SUM(ActualWaterCost)
		,SUM(ActualEnergyCost)
		,@Viewtype 
		,@Subview
		,0
		FROM @OperationSummaryTable SPD 
		INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
		Group by 
		PM.Name
   END
  
   -- ******************************** Formula Hierarchy****************************************************	
	IF(@Viewtype = 8) --Formula Hierarchy
	BEGIN
		 PRINT 'IN View'
		 IF(@Subview =20)-- Formula Segment
		 BEGIN
				PRINT 'IN subView'
				INSERT INTO @resultSet
				(
				ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
				TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
				ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
				ActualEnergyCost ,Viewtype, Subview,Id 
				)
				SELECT DISTINCT
				0,
				FS.SegmentName,
				SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
			    ,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				,@Viewtype 
				,@Subview
				,SPD.FormulaSegmentID
				FROM @OperationSummaryTable SPD 
				INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
				LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=SPD.FormulaSegmentID
				Group by SPD.FormulaSegmentID,FS.SegmentName
		END
		 IF(@Subview =21)-- Formula Categories
		 BEGIN
			 INSERT INTO @resultSet
			 (
				ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
				TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
				ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
				ActualEnergyCost ,Viewtype, Subview,Id 
			 )
			 --Chain Textile category
			 SELECT DISTINCT
				0,
				CC.Name
				,SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
				,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				,@Viewtype 
				,@Subview
				,CC.TextileId
				FROM @OperationSummaryTable SPD LEFT JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
				--WHERE SPD.ChainProgaramId IS NOT NULL --CHain Textilecategory
			 GROUP BY CC.Name,CC.TextileId

			 UNION 
			 --Ecolab Textile category
			 SELECT DISTINCT
				0
				,EC.CategoryName
				,SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
				,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				,@Viewtype 
				,@Subview
				,EC.TextileId
			FROM @OperationSummaryTable SPD LEFT JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
			--WHERE SPD.ChainProgaramId IS NULL ---Ecolab Textile categoriy
			GROUP BY EC.CategoryName,EC.TextileId

		  END
		 IF(@Subview=22) -- Formula
		 BEGIN				
			 INSERT INTO @resultSet
			 (
				ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
				TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
				ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
				ActualEnergyCost ,Viewtype, Subview,Id 
			 )
			 --chain TextileFormula
			 SELECT DISTINCT       
				0, 
				PM.Name
				,SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
				,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				,@Viewtype 
				,@Subview
				,0
				FROM @OperationSummaryTable SPD INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
					 INNER JOIN TCD.ProgramMaster PM ON CC.TextileId = PM.ChainTextileId AND SPD.ProgramMasterId = PM.ProgramId
    
			WHERE
				(
				CASE    
				 WHEN @drillvalue='' THEN 'TRUE' 
				 WHEN @drillvalue IS NULL THEN 'TRUE'  
				 ELSE                                                    
				  CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END            
				 END='TRUE'
				)
			GROUP BY PM.Name
			UNION
			---EcoLabFormula
			SELECT 
			   DISTINCT
				0, 
				PM.Name
				,SUM(SPD.ActualProduction)
				,sum(DISTINCT NoOfLoads)
				,SUM(ActualChemicalConsumption)
				,SUM(TargetChemicalConsumption) 
				,SUM(ActualEnergyConsumption)
				,SUM(TargetEnergyConsumption)
				,SUM(ActualWaterConsumption)
				,SUM(TargetWaterConsumption)
				,SUM(ActualChemicalCost)
				,SUM(ActualWaterCost)
				,SUM(ActualEnergyCost)
				,@Viewtype 
				,@Subview
				,0
				FROM @OperationSummaryTable SPD INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
					 INNER JOIN TCD.ProgramMaster PM ON EC.TextileId = PM.EcolabTextileCategoryId AND SPD.ProgramMasterId = PM.ProgramId
    
			WHERE
				(
				CASE    
				 WHEN @drillvalue='' THEN 'TRUE' 
				 WHEN @drillvalue IS NULL THEN 'TRUE'  
				 ELSE                                                    
				  CASE WHEN EC.TextileId IN (@drillvalue) THEN 'TRUE' END            
				 END='TRUE'
				)
			GROUP BY  PM.Name
		  END
	END

   
   --- ********* Return result ********************

   --SELECT * FROM @resultSet

    SELECT DISTINCT
     ShiftId,
      DateRange,
     CASE @uom WHEN 1 THEN TotalLoad
            WHEN 2 THEN ISNULL([TCD].[FnConsumptionOnMetrics](TotalLoad,'Weight',@UserId),0) END AS ActualProduction,
      --CAST(TotalLoad AS int) AS ActualProduction,
      Numberofbatches AS NoOfLoads,
      ISNULL([TCD].[FnConsumptionOnMetrics](ActualChemicalConsumption,'Volume',@UserId),0) ActualChemicalConsumption,
      --ActualChemicalConsumption ,
      ISNULL([TCD].[FnConsumptionOnMetrics](TargetChemicalConsumption,'Volume',@UserId),0) TargetChemicalConsumption,
      --TargetChemicalConsumption,
      ActualEnergyConsumption,
      TargetEnergyConsumption,
      ActualWaterConsumption,
      TargetWaterConsumption,
      ActualChemicalCost,
      ActualWaterCost,
      ActualEnergyCost,
      Viewtype,
      Subview ,
      Id,
      --CASE @uom WHEN 1 THEN ActualChemicalConsumption 
      --WHEN 2 THEN ActualChemicalConsumption * 28.3495 END AS ActualChemicalConsumptionMetrics ,
      --CASE @uom WHEN 1 THEN TargetChemicalConsumption 
      --WHEN 2 THEN TargetChemicalConsumption * 28.3495 END AS TargetChemicalConsumption,
     CASE @uom WHEN 1 THEN TotalLoad/100 
            WHEN 2 THEN ISNULL([TCD].[FnConsumptionOnMetrics](TotalLoad,'Weight',@UserId),0) END AS ActualProductionMetrics      
      FROM 
        @resultSet
        WHERE [@resultSet].DateRange IS NOT NULL
    

SET NOCOUNT OFF
END
GO


IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[GetReportColumnDetails]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[GetReportColumnDetails] 
END 
GO
CREATE PROCEDURE [TCD].[GetReportColumnDetails]
(
@ReportId INT = NULL,
@ViewById INT = NULL,
@SwitchModeId INT = NULL,
@UserId INT = NULL,
@RoleId INT = NULL,
@LanguageId INT = NULL,
@EcolabAccountNumber NVARCHAR(25) = NULL,
@SubViewID int = null
 

)
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE
		@LocalizedUom TABLE (
		UnitSystemId INT,
		Unit NVARCHAR(200),
		SubUnit NVARCHAR(200),
		UsageKey NVARCHAR(200),
		[Key] NVARCHAR(200),
		value NVARCHAR(800),
		LanguageId	INT);
	INSERT INTO @LocalizedUom
	EXEC TCD.GetResourceKeyValuesForUom @EcolabAccountNumber, @UserId;
	SELECT  a.Id,
		  a.Name,
		  a.DisplayOrder,
		  a.IsSortable,
		  a.ViewById,
		  a.SwitchModeId,
		  a.IsVisible,
		  a.IsChartDisplay,
		  a.LocalizedName,
		  a.LocalizedUom,
		  a.Precision
		  Into #ReportColumns
	 FROM(
		 SELECT DISTINCT RAC.Id,
					  RAC.Name,
					  RAM.DisplayOrder,
					  RAM.IsSortable,
					  RAM.ViewById,
					  RAM.SwitchModeId,
					  RAM.IsVisible,
					  RAM.IsChartDisplay,
					  RAM.ReportId,
					  RKV.Value AS LocalizedName,
					  LU.value AS LocalizedUom,
					  RAM.Precision
		   FROM TCD.ReportColumns RAC
			   INNER JOIN
			   TCD.ReportColumnsMapping RAM ON RAC.ID = RAM.ColumnId
			   INNER JOIN
			   TCD.ReportColumnsRoleMapping RAR ON RAR.ReportColumnId = RAM.ColumnId
										AND RAM.ReportId = RAR.ReportId
			   INNER JOIN
			   TCD.ReportLocalizationColumnMapping RLM ON RAC.Id = RLM.ReportColumnId
			   INNER JOIN
			   TCD.ResourceKeyMaster RK ON RLM.UsageKey = RK.[KeyName]
			   INNER JOIN
			   TCD.ResourceKeyValue RKV ON RK.KeyName = RKV.KeyName
			   LEFT JOIN
			   @LocalizedUom LU ON LU.UsageKey = RLM.UomKey
			   

		   --INNER JOIN [TCD].UserRoles UR ON UR.RoleId = RAR.RoleId AND UR.LevelId = @RoleId

		   WHERE(RAM.ReportId = @ReportId
			 OR RAM.ViewById = @ViewById)
			AND RKV.languageID = @LanguageId

		--OR RAM.SwitchModeId= @SwitchModeId	 				

		)a
	 WHERE a.ReportId = @ReportId
	 ORDER BY	 a.DisplayOrder;
	 IF (@ViewById =8) 
	 BEGIN
	    UPDATE #ReportColumns
		set  LocalizedName = RKV.[Value]
         FROM 
				#ReportColumns a ,
				[TCD].[ReportSubView] b 
			 	inner join TCD.ResourceKeyMaster RK ON b.UsageKey = RK.[KeyName]
			   INNER JOIN
			   TCD.ResourceKeyValue RKV ON RK.KeyName = RKV.KeyName
		 where a.Id = 83-- ReportColumnID = formula
		       and b.ID = @SubViewID
			   and RKV.languageID = @LanguageId

		
	 END 
	 SELECT * FROM #ReportColumns

	 ---83
	SET NOCOUNT OFF;
END;
GO


IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[GetReportDynamicDataByFilterId]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[GetReportDynamicDataByFilterId] 
END 
GO
--exec [TCD].[GetReportDynamicDataByFilterId] @FilterId=10

--exec [TCD].[GetReportDynamicDataByFilterId] @FilterId=10
CREATE PROCEDURE [TCD].[GetReportDynamicDataByFilterId]
								(
								    @UserId INT = NULL,
								    @RoleId INT = NULL,
								    @RegionId Nvarchar(1000) = NULL,
								    @CountryId Nvarchar(1000) = NULL,
								    @IsLocal BIT = NULL,
								    @PlantID Nvarchar(1000) = NULL,
								    @IsCountry BIT = 0,
								    @FilterId INT = NULL
								)   
AS 
SET NOCOUNT ON
BEGIN

    SELECT @PlantID = P.EcolabAccountNumber FROM TCD.Plant P

	   DECLARE @PlantTable TABLE(PlantID Varchar(100))
	   INSERT INTO @PlantTable EXEC [TCD].[CharlistToTable] @PlantID,','
	   
	     DECLARE @ResultTable TABLE
						  (
							 Id nvarchar(2000),
							 Name nvarchar(300),
							 TypeId Int
						  )

	   IF(@FilterId = 7)    --Filter Options for Ecolab Category
		  BEGIN
		  
		  INSERT INTO @ResultTable (
									   Id,
									   Name,
									   TypeId
								     )
		 SELECT CAST(FormulaSegmentID AS int) AS FormulaSegmentID,SegmentName AS FormulaSegmentName,7
		FROM TCD.FormulaSegments WHERE Is_Deleted=0
				
		  END

		  IF(@FilterId = 9)   --Filter Options for Customers
		  BEGIN
		  INSERT INTO @ResultTable (
									   Id,
									   Name,
									   TypeId
								     )			
		  SELECT 
				PC.CustomerId AS Id,
				PC.CustomerName AS Name,
				@FilterId
			 FROM [TCD].[PlantCustomer] PC 
				WHERE PC.EcolabAccountNumber IN (SELECT PlantID FROM @PlantTable)
				
		  END


	    IF(@FilterId = 10)   --Filter Options for plant formulas
		  BEGIN
			
			 INSERT INTO @ResultTable (
									   Id,
									   Name,
									   TypeId
								     )		
		  		----Append chain category+1000
		SELECT DISTINCT PM.ProgramID AS Formula,PM.Name AS Name ,10
		FROM TCD.ProgramMaster PM
		--INNER JOIN
		--	(
		--	--Chain plant
		--	SELECT PCP.PlantProgramId,PCP.PlantChainId,PCP.ChainTextileCategoryId,PCP.EcolabTextileCategoryId,
		--	PCP.FormulaSegmentId,PCP.EcolabSaturationId,CTC.TextileID,CTC.Name AS CategoryName
		--	FROM TCD.PlantChainProgram PCP 
		--	LEFT OUTER JOIN TCD.ChainTextileCategory CTC ON CTC.TextileId=PCP.ChainTextileCategoryId
		--	LEFT OUTER JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId=PCP.EcolabTextileCategoryId				
		--	)ChainPlant ON PM.PlantProgramID=ChainPlant.PlantProgramId
		--UNION
		--SELECT DISTINCT PM.ProgramID AS Formula,PM.Name AS Name ,10
		--FROM TCD.ProgramMaster PM
		--INNER JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId=PM.EcolabtextilecategoryID
				
		  END
    
	   IF(@FilterId = 23)   --Filter Options for Plant chain categories
		    BEGIN

			 --		--Append chain category+1000
			  INSERT INTO @ResultTable (
									   Id,
									   Name,
									   TypeId
								     )		
			SELECT DISTINCT ChainPlant.TextileID+1000 AS ID ,ChainPlant.CategoryName Name,23
			FROM TCD.ProgramMaster PM
			INNER JOIN
			 (
				--Chain plant
				SELECT PCP.PlantProgramId,PCP.PlantChainId,PCP.ChainTextileCategoryId,PCP.EcolabTextileCategoryId,
				PCP.FormulaSegmentId,PCP.EcolabSaturationId,CTC.TextileID,CTC.Name AS CategoryName
				FROM TCD.PlantChainProgram PCP 
				LEFT OUTER JOIN TCD.ChainTextileCategory CTC ON CTC.TextileId=PCP.ChainTextileCategoryId
				LEFT OUTER JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId=PCP.EcolabTextileCategoryId				
			 )ChainPlant ON PM.PlantProgramID=ChainPlant.PlantProgramId
			UNION
			SELECT DISTINCT ETC.TextileID AS FormulaCategoryID,ETC.CategoryName ,23
			FROM TCD.ProgramMaster PM
			LEFT OUTER JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId=PM.EcolabtextilecategoryID
		    END

	    IF(@FilterId = 24)   --Filter Options for plant chain programs
		    BEGIN

	  INSERT INTO @ResultTable (
									   Id,
									   Name,
									   TypeId
								     )		
		  SELECT 
				PC.PlantProgramId AS Id,
				PC.PlantProgramName AS Name,
				@FilterId
			 FROM [TCD].[PlantChainProgram] PC
				    WHERE PC.PlantChainId IN (SELECT P.PlantChainId FROM TCD.PLANT P WHERE P.EcolabAccountNumber IN (SELECT PlantID FROM @PlantTable))     
					OR PC.PlantChainId IS NULL
		    END

		    IF(@FilterId = 11)   --Filter Options for dispencer
		    BEGIN
		
		    INSERT INTO @ResultTable (
										  Id,
										  Name,
										  TypeId
									    )
			SELECT 
				    PC.ControllerId AS Id,
				    PC.Name AS Name,
				    @FilterId
				FROM TCD.ConduitController PC
					   WHERE PC.EcoalabAccountNumber IN (SELECT PlantID FROM @PlantTable)
		   END		

		   IF(@FilterId = 12)   --Filter Options for ALARM
		    BEGIN
		
		    INSERT INTO @ResultTable (
										  Id,
										  Name,
										  TypeId
									    )
			SELECT 
				    AGMVCMT.AlarmCode AS Id,
				    AGM.Description AS Name,
				    @FilterId
				FROM TCD.AlarmGroupMaster AGM
				JOIN TCD.AlarmGroupMsterVsControllerModelType AGMVCMT ON  AGMVCMT.AlarmGroupMasterId = AGM.AlarmGroupMasterId
					   
		   END		


    		 SELECT
				    DISTINCT
						Id,
						Name,
						TypeId
						 FROM @ResultTable


END
GO
IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[GetBatchSummarizedData]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[GetBatchSummarizedData] 
END 
GO
Create PROCEDURE [TCD].[GetBatchSummarizedData] (  
            @DashBoardId INT = NULL   
            )   
  
AS   
BEGIN   
  
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED  
    SET NOCOUNT ON  
  
  
     DECLARE   --@DashBoardId INT = 2,
        @Efficiencytype INT,  
 @OvernightBatchThreshold INT = 7200 -- mins  
      
     DECLARE @DashboardMachineMapping TABLE(  
         Id INT,  
         GroupId INT,  
         WasherId INT,  
         DisplayCustomer BIT,  
  WasherName NVARCHAR(100),   
	 WasherNumber INT,
	 IsPLCConnected BIT,
	 DispenserName VARCHAR(250))
  
      DECLARE @Summarizeddata TABLE(  
        GroupId INT,  
        TunnelName Nvarchar(100),  
        TargetLoad FLOAT,  
        ActualLoad FLOAT,  
 LoadEfficiency FLOAT,  
        TimeEfficiency FLOAT,  
        LostLBS FLOAT,  
        TransferPerHr FLOAT,  
        SignalStatus INT,          
        EmptyPockets INT,  
        Alarm Bit,  
        TransferPercent DECIMAL(10,2),  
        EndOfFormula INT,  
        DisplayCustomer BIT,  
        WasherNumber INT,
		IsPLCConnected BIT,
		DispenserName VARCHAR(250),
		LostBatches Decimal(18,6)
        )  
          
 DECLARE @ShiftIds TABLE(  
 ShiftId INT,  
 ShiftStartDate DATETIME,  
 ShiftEndDate DATETIME  
 )  
  
 SELECT  
  @Efficiencytype = ISNULL(EfficiencyCalcType, 1)  
     FROM tcd.Dashboard  
     WHERE DashboardId = @Dashboardid  
  
      INSERT INTO @DashboardMachineMapping  
        (  
            Id,  
            GroupId,  
            WasherId,  
     DisplayCustomer,  
     WasherName,  
	    WasherNumber,
		IsPLCConnected,
		DispenserName
        )  
    SELECT   
    ROW_NUMBER() OVER(ORDER BY GroupID) AS Id,  
    A.GroupId,  
    A.WasherId,  
    A.Customer,  
    A.WasherName,  
    A.WasherNumber,
	A.IsPLCConnected,
	DispenserName
    FROM  
    (SELECT DISTINCT  
     MS.GroupId,MS.WasherId,D.Customer,MS.MachineName AS WasherName, w.PlantWasherNumber AS WasherNumber,
	 (CASE WHEN ISNULL(IsActive,0) = 0 THEN CAST( 1 AS BIT)
	 WHEN ISNULL(IsActive,0) = 1 THEN CAST( 0 AS BIT)
	 END) AS IsPLCConnected,
	  CAST(CC.ControllerNumber AS NVARCHAR) + ' ('+CC.TopicName + ')' AS DispenserName
     FROM TCD.MonitorSetUpMapping DM   
        INNER JOIN TCD.MachineSetup MS ON DM.MachineId = MS.WasherID  
        INNER JOIN TCD.Dashboard D on DM.DashBoardId = D.DashBoardId  
 INNER JOIN TCD.Washer w ON ms.WasherId = w.WasherId  
		INNER JOIN TCD.ConduitController CC ON CC.ControllerId = MS.ControllerId
		LEFT JOIN TCD.AlarmData AD ON AD.ControllerId = MS.ControllerId AND IsActive = 1 AND AD.AlarmCode = 
		(CASE WHEN (SELECT VALUE FROM  TCD.controllerSetupData CSD LEFT JOIN TCD.Field F ON F.Id = CSD.FieldId  WHERE  F.Label = 'Webport Ftp Enabled' AND CSD.ControllerId = AD.ControllerId AND CC.ControllerTypeId = 1) = 'true'
			THEN 9002
			ELSE 9001
		END) 
    WHERE DM.DashboardId = @DashBoardId  
    AND ms.IsDeleted = 0  
    AND w.Is_Deleted = 0   
    )A;  
   
  
  
 -- For efficiency calculations on shift wise  
 IF @Efficiencytype = 1  
     BEGIN  
  
  INSERT INTO @Shiftids(shiftId,ShiftStartDate, ShiftEndDate)  
  SELECT DISTINCT ShiftId, StartDateTime, EndDateTime  
  FROM TCD.ProductionShiftData  
 -- WHERE ShiftId = 1103 
  WHERE GETUTCDATE() BETWEEN StartDateTime AND EndDateTime   
  
     END  
 ELSE -- For efficiency calculations on Day wise  
     BEGIN  
  
  INSERT @Shiftids(ShiftId, ShiftStartDate, ShiftEndDate)  
  SELECT DISTINCT ShiftId, StartDateTime, EndDateTime  
  FROM TCD.ProductionShiftData  
  WHERE startdatetime > CAST(GETUTCDATE()AS DATE)  
  AND startdatetime < DATEADD(dd, 1, CAST(GETUTCDATE()AS DATE))  
  
     END    

--select * from @ShiftIds
--select * from @DashboardMachineMapping
  
  
SELECT *   
INTO #BatchData  
FROM tcd.BatchData bd (NOLOCK) WHERE bd.ShiftId in (SELECT si.ShiftId FROM @ShiftIds si)  
AND bd.StandardWeight > 0  
and bd.ActualWeight > 0   
AND bd.EndDate IS NOT null


--select * from #BatchData  
  
-- Efficiency for each batch   
SELECT  bd.BatchId,  
  bd.GroupID,  
  bd.MachineID,  
  bd.ShiftId,  
  W_1.WasherNumber,  
  W_1.WasherName,  
  (bd.ActualWeight + ISNULL(BD.ManualInputWeight,0)) AS ActualProduction,  
  bd.StandardWeight AS StandardProduction,  
  --DATEDIFF(ss,bd.StartDate, bd.EndDate) AS ActualRunTime,  
  CASE WHEN DATEDIFF(mi,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OvernightBatchThreshold   
   THEN W_1.Standardruntime   
       ELSE DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
  END AS ActualRunTime,  
  W_1.StandardRunTime,  
  NULL AS ActualTurnTime,  
  bd.TargetTurnTime AS StandardTurnTime,  
  CASE WHEN W_1.WasherGroupTypeID = 2   THEN
    ---- Conventional  
    --THEN (CAST((W_1.Standardruntime + bd.TargetTurnTime)AS FLOAT) / (CAST(CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
    --          THEN W_1.StandardRunTime  
    --          ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
    --         END   
    --+ CASE WHEN TT.ACTUALTURNTIME = 0 THEN bd.TargetTurnTime   
    -- ELSE TT.ACTUALTURNTIME  
    --  END  AS FLOAT)))  
    ---- Tunnel  
   --ELSE   
   (CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT) )  
    / (CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0   
          THEN W_1.Standardruntime   
          ELSE CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
            THEN W_1.StandardRunTime  
                ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
           END  
         END AS FLOAT)   
                )  
  END AS TimeEfficiency,  
  ((CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS FLOAT)/CAST(NULLIF(bd.StandardWeight,0) AS FLOAT)) * 100) AS LoadEfficiency,  
  CASE WHEN W_1.WasherGroupTypeID = 2   
      THEN  
  (3600.00/(CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0   
       THEN NULLIF(W_1.Standardruntime,0)  
       ELSE DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
       END AS FLOAT)/W_1.NumberOfComp))   
   ELSE NULL  
  END AS TransferPerHr,  
  
  --missedloads formulae
		--------(((Actual Production/totalefficiency)*100)-actualproduction)
		
		(cast((cast(bd.ActualWeight AS decimal(18,6))/(((CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS decimal(18,6))/CAST(NULLIF(bd.StandardWeight,0) AS decimal(18,2))) * 100.0) 
  * (  CASE WHEN W_1.WasherGroupTypeID = 2   THEN
      ---- Conventional  
      --THEN (CAST((W_1.Standardruntime + bd.TargetTurnTime)AS FLOAT) / (CAST(CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
      --             THEN W_1.StandardRunTime  
      --             ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
      --            END + TT.ACTUALTURNTIME AS FLOAT)))  
      ---- Tunnel  
      --ELSE   
						(CAST(NULLIF(W_1.Standardruntime,0) AS decimal(18,6)) )
       / (CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0   
             THEN W_1.Standardruntime   
             ELSE CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
                  THEN W_1.StandardRunTime  
                  ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
                 END  
												END AS decimal(18,6)) 
															    )
				END))) AS decimal(18,6))*100.0)-cast(bd.ActualWeight AS decimal(18,6)) AS MissedLoads,
 -- ((bd.StandardWeight - bd.ActualWeight) +  
 -- (CASE WHEN W_1.WasherGroupTypeID = 2 THEN   
 --   --THEN  
 --   -- ((CAST((CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
 --   --   THEN W_1.StandardRunTime  
 --   --       ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
 --   --  END + TT.ACTUALTURNTIME) AS FLOAT) - W_1.Standardruntime - bd.TargetTurnTime)   
 --   -- * CAST((CAST(bd.StandardWeight AS FLOAT)/NULLIF((W_1.Standardruntime + bd.TargetTurnTime),0)) AS FLOAT))   
 --   --ELSE 
	--((CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
 --     THEN W_1.StandardRunTime  
 --         ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
 --    END - W_1.Standardruntime) * (CAST(bd.StandardWeight AS FLOAT)/ NULLIF(W_1.Standardruntime,0)))  
 -- END)) AS MissedLoads,  
  (((CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS FLOAT)/CAST(NULLIF(bd.StandardWeight,0) AS FLOAT)) * 100)   
  * (  CASE WHEN W_1.WasherGroupTypeID = 2   THEN
      ---- Conventional  
      --THEN (CAST((W_1.Standardruntime + bd.TargetTurnTime)AS FLOAT) / (CAST(CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
      --             THEN W_1.StandardRunTime  
      --             ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
      --            END + TT.ACTUALTURNTIME AS FLOAT)))  
      ---- Tunnel  
      --ELSE   
      (CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT) )  
       / (CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0   
                    THEN W_1.Standardruntime   
                    ELSE CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
                      THEN W_1.StandardRunTime  
                   ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
                     END  
            END AS FLOAT)   
                   )  
    END)) AS TotalEfficiency  ,
    w_1.maxload
  
INTO #BatchEfficiency  
FROM #BatchData bd  
--FROM TCD.BatchData bd   
INNER JOIN(       
                SELECT ms.EcoalabAccountNumber,      
                        ms.WasherId,      
                        ms.GroupId AS WasherGroupID,      
                        mg.WasherGroupTypeId AS WasherGroupTypeID,      
                        w.EcolabWasherId,      
                        ISNULL(ms.NumberOfComp,0) AS NumberOfComp,      
                        CASE      
                        WHEN MG.WASHERGROUPTYPEID = 1 THEN WSP.ProgramNumber      
                            ELSE TPS.ProgramNumber      
                        END AS ProgramNumber,      
                        CASE      
                        WHEN MG.WASHERGROUPTYPEID = 1 THEN WSP.ProgramId      
       ELSE TPS.ProgramId      
                        END AS ProgramId,      
                        CASE      
       WHEN MG.WASHERGROUPTYPEID = 1   
    THEN WSP.TotalRunTime      
                            ELSE TPS.TotalRunTime      
   END AS Standardruntime,  
   w.PlantWasherNumber AS WasherNumber,  
   ms.MachineName AS WasherName,  
   mg.WasherGroupName AS MachineGroup,  
   ms.IsTunnel , 
   w.maxload
   --mg.WasherGroupId AS MachineGroupID  
                    FROM TCD.MachineSetup AS ms (NOLOCK)      
                        INNER JOIN TCD.Washer AS w (NOLOCK) ON w.EcoLabAccountNumber = ms.EcoalabAccountNumber      
                                                    AND w.WasherId = ms.WasherId      
                        INNER JOIN TCD.WasherGroup AS mg (NOLOCK) ON ms.GroupId = mg.WasherGroupId      
                                                        AND w.EcoLabAccountNumber = mg.EcolabAccountNumber      
                        LEFT OUTER JOIN TCD.WasherProgramSetup AS WSP (NOLOCK) ON WSP.WasherGroupId = mg.WasherGroupId      
                                                                    AND WSP.EcolabAccountNumber = mg.EcolabAccountNumber      
                                                                    --AND WSP.WasherGroupId = ms.GroupId      
                 AND WSP.Is_Deleted = 0  
                        LEFT OUTER JOIN TCD.TunnelProgramSetup AS TPS (NOLOCK) ON TPS.WasherGroupId = mg.WasherGroupId      
                                                                    AND TPS.EcolabAccountNumber = mg.EcolabAccountNumber      
                                                                    --AND TPS.WasherGroupId = ms.GroupId   
                 AND TPS.Is_Deleted = 0   
   WHERE ms.IsTunnel = 1  
   ) AS W_1 ON BD.GroupId = W_1.WasherGroupID      
       AND BD.MachineId = W_1.WasherId      
       AND BD.ProgramMasterId = W_1.ProgramId      
       AND BD.ProgramNumber = W_1.ProgramNumber  
--LEFT JOIN [TCD].[Turntime] TT (NOLOCK) ON --ISNULL(BD.EcolabwasherID,0) = ISNULL(TT.EcolabWasherId,0)   
--    BD.batchid = TT.BatchID   
    --AND bd.MachineId = tt.MachineId  
--WHERE bd.ShiftId IN (SELECT si.ShiftId FROM @ShiftIds si)  
--AND bd.ActualWeight > 0   
--AND bd.StandardWeight > 0  
--AND DATEDIFF(ss, bd.StartDate, bd.EndDate) > (W_1.Standardruntime * 10/100)  
--AND bd.EndDate IS NOT NULL  
  
 
  
 -- Efficiency by Machine calculation   
 SELECT DM.GroupID,   
  DM.WasherId AS MachineID,  
  DM.WasherNumber,  
  DM.WasherName,  
  CAST(sum(t.ActualProduction) AS FLOAT) AS ActualProduction,  
  CAST(sum(t.StandardProduction) AS FLOAT) AS StandardProduction,  
  SUM(t.ActualRunTime) AS ActualRuntime,  
  SUM(t.StandardRunTime) AS StandardRunTime,  
  (SUM(t.MissedLoads)) AS MissedLoads,  
  (CAST(sum(t.LoadEfficiency) AS FLOAT) / count(DISTINCT t.BatchId)) AS LoadEfficiency,  
  (CAST(sum(t.TimeEfficiency) AS FLOAT) / count(DISTINCT t.BatchId)) AS TimeEfficiency,  
  (CAST(SUM(t.TransferPerHr) AS FLOAT)/ count(DISTINCT t.BatchId)) AS TransferPerHour,  
		((CAST(sum(t.LoadEfficiency) AS FLOAT) / count(DISTINCT t.BatchId)) * (CAST(sum(t.TimeEfficiency) AS FLOAT) / count(DISTINCT t.BatchId))) AS TotalEfficiency,
		DM.IsPLCConnected AS IsPLCConnected,
		DM.DispenserName,
	 (SUM(t.MissedLoads))/max(t.maxload) AS LostBatches	
 INTO #MachineEfficiency  
 FROM @Dashboardmachinemapping DM   
 LEFT JOIN #BatchEfficiency t ON DM.GroupID = t.GroupId AND dm.WasherId = t.MachineId  
 GROUP BY DM.GroupID,   
  DM.WasherId,  
  DM.WasherNumber,  
		DM.WasherName,
		DM.IsPLCConnected,
		DM.DispenserName
		
  
  
      DECLARE @EmptyPocketNAlarmddata TABLE(  
     GroupId INT,  
     WasherID INT,  
     EndOfFormula  INT,  
     DisplayCustomer Decimal(18,2),  
     EmptyPockets INT,  
     MachineNameDispalyType INT,  
     EmptyPocketLoad Decimal(18,2),  
     Alarm bit,  
     WasherStatus bit  
 )  
  
    INSERT @EmptyPocketNAlarmddata    (GroupId,WasherID,EndOfFormula,DisplayCustomer,EmptyPockets,MachineNameDispalyType, EmptyPocketLoad,Alarm,WasherStatus)  
    SELECT  D.GroupId,   
     D.WasherId,   
     w.EmptyPocketNumber AS EndOfFormula,   
     D.DisplayCustomer,   
     A.EmptyPockets,   
     (SELECT SUM(ISNULL(MachineNameDispalyType,0)) FROM TCD.Dashboard D1  
  INNER JOIN TCD.[MonitorSetUpMapping] MSM ON D1.DashboardId=MSM.DashboardId    
  WHERE MSM.MachineId=D.WasherId and D1.DashboardId=@DashBoardId  
  ) as MachineNameDispalyType,  
     sum(w.MaxLoad) AS EmptyPocketLoad,  
     NULL AS alarm,  
     sum(CASE WHEN B.WasherStatus > 0 THEN 1 ELSE 0 END) AS WasherStatus  
    FROM TCD.Washer AS w   
    INNER JOIN @DashboardMachineMapping AS D ON w.WasherId = d.WasherId  
    CROSS APPLY  (  
 SELECT COUNT(*) As EmptyPockets from TCD.BatchData AS b JOIN @ShiftIds AS s ON b.ShiftId = s.ShiftId   
 WHERE b.StartDate >= s.ShiftStartDate   
 AND b.GroupId = d.GroupId   
 AND b.ProgramNumber = w.EmptyPocketNumber  
       ) AS A  
    CROSS APPLY (  
 SELECT Count(*) as WasherStatus  
 from tcd.BatchData where MachineId = d.WasherId AND GroupId= D.GroupId and (EndDate >= DATEADD(mi,-30,GETUTCDATE()) OR EndDate is NULL)  
 ) AS B  
    GROUP BY D.GroupId, D.WasherId, w.EmptyPocketNumber, D.DisplayCustomer, A.EmptyPockets  
  
  
    UPDATE X   
    SET X.Alarm = ISNULL(Alarm.IsActive,0)  
    FROM @EmptyPocketNAlarmddata X  
    CROSS APPLY (   
 SELECT TOP 1 AD.IsActive  
     FROM [TCD].AlarmData AD   
     WHERE GroupId = X.GroupId  
     ORDER BY StartDate DESC  
  ) AS Alarm  
  
  
  
INSERT INTO @Summarizeddata(GroupId,TunnelName,TargetLoad,ActualLoad,LoadEfficiency, TimeEfficiency,  
        LostLBS,TransferPerHr,SignalStatus,EmptyPockets,Alarm,TransferPercent,EndOfFormula,DisplayCustomer,WasherNumber,IsPLCConnected, DispenserName,lostbatches)
 SELECT  me.GroupID,   
  CASE epn.MachineNameDispalyType   
     WHEN 0 THEN CAST( me.WasherNumber AS varchar(20))+' '+  me.WasherName  
     WHEN 1 THEN me.WasherName  
     WHEN 2 THEN CAST( me.WasherNumber AS varchar(20))          
  END AS TunnelName,  
  me.StandardProduction,   
  me.ActualProduction,   
  me.LoadEfficiency,  
  me.TimeEfficiency,   
  me.MissedLoads,  
  me.TransferPerHour,  
  epn.WasherStatus,  
  epn.EmptyPockets,  
  ISNULL(epn.Alarm,0) AS Alarm,  
  0 AS TransferPercent,  
  epn.EndOfFormula,  
  epn.DisplayCustomer,  
	 me.WasherNumber,
	 me.IsPLCConnected AS IsPLCConnected,
	 me.DispenserName AS DispenserName,
	 me.LostBatches
 from #MachineEfficiency me  
 LEFT JOIN @EmptyPocketNAlarmddata epn ON me.GroupID = epn.GroupId AND me.MachineID = epn.WasherID  
   
     SELECT  GroupId,  
     TunnelName,  
     TargetLoad,  
     ActualLoad,  
     LoadEfficiency,  
     TimeEfficiency,  
     ( CASE WHEN isnull(LostLBS,0)<0 THEN 0 ELSE LostLBS END) LostLBS ,  
     TransferPerHr,  
     SignalStatus,          
     EmptyPockets,  
     Alarm,  
     TransferPercent,  
     EndOfFormula,  
     DisplayCustomer,  
	    WasherNumber,
		IsPLCConnected,
		DispenserName,
		( CASE WHEN isnull(LostBatches,0)<0 THEN 0 ELSE LostBatches END) LostBatches
    FROM @Summarizeddata    
    ORDER BY WasherNumber  
  
-- CleanUp  
DROP TABLE #BatchData
DROP TABLE #BatchEfficiency  
DROP TABLE #MachineEfficiency  
  
END
GO

GO
IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[GetWasherBatchSummarizedData]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[GetWasherBatchSummarizedData] 
END 

GO
create PROCEDURE [TCD].[GetWasherBatchSummarizedData](  
    @DashBoardId int = NULL  
)   
AS   
BEGIN   
  
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED  
SET NOCOUNT ON  
  
   
DECLARE   --@DashBoardId int = 1, 
        @Washerid INT = NULL,   
        @Standardturntime INT = NULL,   
        @Machinenamedispalytype SMALLINT = 0,  
 @OverNightBatchThreshold int = 7200, -- Seconds  
 @EfficiencyType int  
  
 SELECT @EfficiencyType = ISNULL(EfficiencyCalcType,1) from tcd.Dashboard where DashboardId = @DashBoardId  
  
 DECLARE @Dashboardmachinemapping TABLE(  
  Id INT,   
  GroupID INT,  
  WasherId INT,  
  WasherName NVARCHAR(100),   
		WasherNumber INT,
		IsPLCConnected BIT,
		DispenserName VARCHAR(250))
  
 DECLARE @AlarmByMachine TABLE(  
  GroupID INT,  
  WasherID INT,   
  Alarm BIT NULL,  
  AlarmDescription NVARCHAR(250))  
  
 DECLARE @BatchEndtimes TABLE(  
  GroupID INT,  
  WasherID INT,   
  CurrentBatchEndTime INT NULL,  
  BatchEndTime time)  
  
 Declare @ShiftIds table(  
    ShiftId int,  
    ShiftStartDate DATETIME,  
    ShiftEndDate datetime)  
  
 DECLARE @Summarizeddata TABLE(  
  GroupId INT,   
  MachineId INT,   
  WasherName NVARCHAR(100),   
  WasherNumber INT,   
  TargetLoad float,   
  ActualLoad float,   
  LoadEfficiency float,   
  TimeEfficiency float,   
  LostLoad float,   
  Alarm BIT,   
  AlarmDescription NVARCHAR(250),   
  WasherStatus INT,   
  MachineNameDispalyType SMALLINT,  
  TargetTurnTime INT,  
		DefaultIdleTime INT,
		IsPLCConnected BIT,
	 DispenserName VARCHAR(250),
	 LostBatches Decimal(18,6))
  
 INSERT INTO @Dashboardmachinemapping(  
  Id,   
  GroupID,  
  WasherId,  
  WasherName,  
		WasherNumber,
		IsPLCConnected,
		DispenserName
		)
 SELECT  
  ROW_NUMBER()OVER(ORDER BY MS.GroupID)AS Id,   
  MS.GroupId,  
  MS.WasherID,  
  MS.MachineName,  
		W.PlantWasherNumber AS WasherNumber,		
		(CASE WHEN ISNULL(AD.IsActive,0) = 0 THEN CAST( 1 AS BIT)
		 WHEN ISNULL(AD.IsActive,0) = 1 THEN CAST( 0 AS BIT)
		 END) AS IsPLCConnected,
		CAST(CC.ControllerNumber AS NVARCHAR) + ' ('+CC.TopicName + ')' AS DispenserName
     FROM(SELECT DISTINCT  
    MachineId,   
    DashboardId  
  FROM TCD.MonitorSetUpMapping)AS DM  
  INNER JOIN TCD.MachineSetup AS MS ON DM.MachineId = MS.WasherID  
  INNER JOIN tcd.Washer AS W ON MS.WasherId = W.WasherId  
  INNER JOIN TCD.Dashboard AS D ON DM.DashBoardId = D.DashBoardId  
		INNER JOIN TCD.ConduitController CC ON CC.ControllerId = MS.ControllerId
		LEFT JOIN TCD.AlarmData AD ON AD.ControllerId = MS.ControllerId AND IsActive = 1 AND AD.AlarmCode = 
		(CASE WHEN (SELECT VALUE FROM  TCD.controllerSetupData CSD LEFT JOIN TCD.Field F ON F.Id = CSD.FieldId  WHERE  F.Label = 'Webport Ftp Enabled' AND CSD.ControllerId = AD.ControllerId AND CC.ControllerTypeId = 1) = 'true'
			THEN 9002
			ELSE 9001
		END) 
     WHERE DM.DashboardId = @Dashboardid  
       AND MS.IsDeleted = 0  
       AND w.Is_Deleted = 0  
    -- Exclude Phony Washers from Efficiency calculation   
       AND ms.WasherId NOT IN(SELECT  
          w.WasherId  
      FROM TCD.MachineSetup AS ms  
           INNER JOIN TCD.Washer AS w ON w.WasherId = ms.WasherId  
         AND ms.EcoalabAccountNumber = w.EcoLabAccountNumber  
      WHERE (NULLIF(ms.ControllerId, 0)IS NULL  
        AND w.WasherMode = 0)  
        OR MS.IsPony = 1  
        )  
  
  
 -- For efficiency calculations on shift wise  
 IF(@EfficiencyType = 1)  
  BEGIN  
      INSERT @ShiftIds(ShiftId,ShiftStartDate,ShiftEndDate)  
      SELECT DISTINCT ShiftId,StartDateTime, EndDateTime FROM TCD.ProductionShiftData  
   WHERE GETUTCDATE() BETWEEN StartDateTime AND EndDateTime   
  -- WHERE ShiftId = 33 
      END  
        
 ELSE -- For efficiency calculations on Day wise  
  BEGIN  
   INSERT @ShiftIds(ShiftId,ShiftStartDate,ShiftEndDate)  
   SELECT ShiftId, StartDateTime, EndDateTime    
   FROM [TCD].ProductionShiftData    
   WHERE   startdatetime > CAST(GETUTCDATE()AS DATE ) and startdatetime < dateadd(dd,1,CAST(GETUTCDATE()AS DATE ))   
   ORDER BY startdatetime   
     
  END  



  
SELECT *   
INTO #BatchData  
FROM tcd.BatchData bd (NOLOCK) WHERE bd.ShiftId in (SELECT si.ShiftId FROM @ShiftIds si)  
AND bd.StandardWeight > 0  
and bd.ActualWeight > 0   
AND bd.EndDate IS NOT null

--select * from @ShiftIds
--select * from @Dashboardmachinemapping
--select * from #BatchData
  
-- Efficiency for each batch   
SELECT  bd.BatchId,  
  W_1.WasherGroupID AS GroupID,  
  W_1.WasherId AS MachineID,  
  bd.ShiftId,  
  W_1.WasherNumber,  
  W_1.WasherName,  
  (bd.ActualWeight + ISNULL(BD.ManualInputWeight,0)) AS ActualProduction,  
  bd.StandardWeight AS StandardProduction,  
  CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
   THEN W_1.StandardRunTime  
       ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
  END AS ActualRunTime,  
  W_1.StandardRunTime,  
  TT.ActualTurnTime,  
  bd.TargetTurnTime AS StandardTurnTime,  
  CASE WHEN W_1.WasherGroupTypeID = 1   
    -- Conventional  
    THEN (CAST((W_1.Standardruntime + bd.TargetTurnTime)AS FLOAT) / (CAST(CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
              THEN W_1.StandardRunTime  
              ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
             END   
    + CASE WHEN TT.ACTUALTURNTIME = 0 THEN bd.TargetTurnTime   
     ELSE TT.ACTUALTURNTIME  
      END  AS FLOAT)))  
    -- Tunnel  
   ELSE   
   (CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT) )  
    / (CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0   
          THEN W_1.Standardruntime   
          ELSE CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
            THEN W_1.StandardRunTime  
                ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
           END  
         END AS FLOAT)   
                )  
  END AS TimeEfficiency,  
  ((CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS FLOAT)/CAST(NULLIF(bd.StandardWeight,0) AS FLOAT)) * 100) AS LoadEfficiency,  
  CASE WHEN W_1.WasherGroupTypeID = 2   
      THEN  
  (100 * ((3600.00/(CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0   
       THEN NULLIF(W_1.Standardruntime,0)  
       ELSE DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
       END AS FLOAT)/W_1.NumberOfComp)) /  
       (3600.00/(CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT)/W_1.NumberOfComp))))  
   ELSE NULL  
  END AS TransferPerHr,  
  --missedloads formulae
		--------(((Actual Production/totalefficiency)*100)-actualproduction)
		
		(cast(cast(bd.ActualWeight AS decimal(18,6))/(((CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS decimal(18,6))/CAST(NULLIF(bd.StandardWeight,0) AS decimal(18,6))) * 100.0) 
  * (  CASE WHEN W_1.WasherGroupTypeID = 1   
      -- Conventional  
      THEN (CAST((W_1.Standardruntime + bd.TargetTurnTime)AS decimal(18,6)) / (CAST(CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
       THEN W_1.StandardRunTime  
           ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
                  END + TT.ACTUALTURNTIME AS FLOAT)))  
      -- Tunnel  
      ELSE   
						(CAST(NULLIF(W_1.Standardruntime,0) AS decimal(18,6)) )
							/ (CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0 
													THEN W_1.Standardruntime 
													ELSE CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold
      THEN W_1.StandardRunTime  
          ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
													    END
												END AS decimal(18,6)) 
															    )
				END)) AS decimal(18,6))*100.0)-cast(bd.ActualWeight AS decimal(18,6)) AS MissedLoads,
  --((bd.StandardWeight - bd.ActualWeight) +  
  --(CASE WHEN W_1.WasherGroupTypeID = 1   
  --  THEN  
  --   ((CAST((CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
  --     THEN W_1.StandardRunTime  
  --         ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
  --    END + TT.ACTUALTURNTIME) AS FLOAT) - W_1.Standardruntime - bd.TargetTurnTime)   
  --   * CAST((CAST(bd.StandardWeight AS FLOAT)/NULLIF((W_1.Standardruntime + bd.TargetTurnTime),0)) AS FLOAT))   
  --  ELSE ((CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
  --    THEN W_1.StandardRunTime  
  --        ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
  --   END - W_1.Standardruntime) * (CAST(bd.StandardWeight AS FLOAT)/ NULLIF(W_1.Standardruntime,0)))  
  --END)) AS MissedLoads,  
  (((CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS FLOAT)/CAST(NULLIF(bd.StandardWeight,0) AS FLOAT)) * 100)   
  * (  CASE WHEN W_1.WasherGroupTypeID = 1   
      -- Conventional  
      THEN (CAST((W_1.Standardruntime + bd.TargetTurnTime)AS FLOAT) / (CAST(CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
                   THEN W_1.StandardRunTime  
                   ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
                  END + TT.ACTUALTURNTIME AS FLOAT)))  
      -- Tunnel  
      ELSE   
      (CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT))  
       / (CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0   
             THEN W_1.Standardruntime   
             ELSE CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
                  THEN W_1.StandardRunTime  
                  ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
                 END  
            END AS FLOAT)  
                   )  
    END)) AS TotalEfficiency  ,
    W_1.MaxLoad
  
  
INTO #BatchEfficiency  
FROM #BatchData bd
--FROM TCD.BatchData bd   
RIGHT OUTER JOIN(       
                SELECT ms.EcoalabAccountNumber,      
                        ms.WasherId,      
                        ms.GroupId AS WasherGroupID,      
                        mg.WasherGroupTypeId AS WasherGroupTypeID,      
                        w.EcolabWasherId, 
                        w.MaxLoad,     
                        ISNULL(ms.NumberOfComp,0) AS NumberOfComp,      
                        CASE      
                        WHEN MG.WASHERGROUPTYPEID = 1 THEN WSP.ProgramNumber      
                            ELSE TPS.ProgramNumber      
                        END AS ProgramNumber,      
                        CASE      
                        WHEN MG.WASHERGROUPTYPEID = 1 THEN WSP.ProgramId      
       ELSE TPS.ProgramId      
                        END AS ProgramId,      
                        CASE      
       WHEN MG.WASHERGROUPTYPEID = 1   
    THEN WSP.TotalRunTime      
                            ELSE TPS.TotalRunTime      
   END AS Standardruntime,  
   w.PlantWasherNumber AS WasherNumber,  
   ms.MachineName AS WasherName,  
   mg.WasherGroupName AS MachineGroup  
   --mg.WasherGroupId AS MachineGroupID  
                    FROM TCD.MachineSetup AS ms (NOLOCK)      
                        INNER JOIN TCD.Washer AS w (NOLOCK) ON w.EcoLabAccountNumber = ms.EcoalabAccountNumber      
                                                    AND w.WasherId = ms.WasherId      
                        INNER JOIN TCD.WasherGroup AS mg (NOLOCK) ON ms.GroupId = mg.WasherGroupId      
                                                        AND w.EcoLabAccountNumber = mg.EcolabAccountNumber      
                        LEFT OUTER JOIN TCD.WasherProgramSetup AS WSP (NOLOCK) ON WSP.WasherGroupId = mg.WasherGroupId      
                                                                    AND WSP.EcolabAccountNumber = mg.EcolabAccountNumber      
                 AND WSP.Is_Deleted = 0  
                                                                    --AND WSP.WasherGroupId = ms.GroupId      
                        LEFT OUTER JOIN TCD.TunnelProgramSetup AS TPS (NOLOCK) ON TPS.WasherGroupId = mg.WasherGroupId      
                                                                    AND TPS.EcolabAccountNumber = mg.EcolabAccountNumber      
                 AND TPS.Is_Deleted = 0   
                                                                    --AND TPS.WasherGroupId = ms.GroupId   
   RIGHT JOIN @Dashboardmachinemapping DM1 ON DM1.GroupID = ms.GroupId   
      AND DM1.WasherId = ms.WasherId  
   WHERE ms.IsTunnel = 0   
   AND ms.IsDeleted = 0  
   ) AS W_1 ON BD.GroupId = W_1.WasherGroupID      
                                    AND ISNULL(BD.EcolabWasherId,0) = ISNULL(W_1.EcolabWasherId,0)  
        AND bd.MachineID = W_1.WasherId  
                                    AND BD.ProgramMasterId = W_1.ProgramId      
                                    AND BD.ProgramNumber = W_1.ProgramNumber  
LEFT JOIN [TCD].[Turntime] TT ON ISNULL(BD.EcolabwasherID,0) = ISNULL(TT.EcolabWasherId,0) AND BD.batchid = TT.BatchID  
WHERE DATEDIFF(ss, bd.StartDate, bd.EndDate) > (W_1.Standardruntime * 10/100)  
--bd.ShiftId IN (SELECT si.ShiftId FROM @ShiftIds si)  
--AND bd.ActualWeight > 0   
--AND bd.StandardWeight > 0  
--AND DATEDIFF(ss, bd.StartDate, bd.EndDate) > (W_1.Standardruntime * 10/100)  
--AND bd.EndDate IS NOT NULL   
  
  
 -- Efficiency by Machine calculation   
 SELECT DM.GroupID,   
  DM.WasherId AS MachineID,  
  DM.WasherNumber,  
  DM.WasherName,  
  CAST(sum(t.ActualProduction) AS FLOAT) AS ActualProduction,  
  CAST(sum(t.StandardProduction) AS FLOAT) AS StandardProduction,  
  SUM(t.ActualRunTime) AS ActualRuntime,  
  SUM(t.StandardRunTime) AS StandardRunTime,  
  (SUM(t.MissedLoads)/count(DISTINCT t.BatchId)) AS MissedLoads,  
  (CAST(sum(t.LoadEfficiency) AS FLOAT) / count(DISTINCT t.BatchId)) AS LoadEfficiency,  
  ((CAST(sum(t.TimeEfficiency) AS FLOAT) / count(DISTINCT t.BatchId))*100)  AS TimeEfficiency,  
		((CAST(sum(t.LoadEfficiency) AS FLOAT) / count(DISTINCT t.BatchId)) * (CAST(sum(t.TimeEfficiency) AS FLOAT) / count(DISTINCT t.BatchId))) AS TotalEfficiency,
		DM.IsPLCConnected AS IsPLCConnected,
		DM.DispenserName,
	(SUM(t.MissedLoads)/count(DISTINCT t.BatchId))/max(t.MaxLoad) AS LostBatches	
 INTO #MachineEfficiency  
 FROM @Dashboardmachinemapping DM   
 LEFT JOIN #BatchEfficiency t ON DM.GroupID = t.GroupId AND dm.WasherId = t.MachineId  
 --AND t.ActualRunTime > (t.StandardRunTime * 10/100)  
 GROUP BY DM.GroupID,   
 DM.WasherId,  
 DM.WasherNumber,  
	DM.WasherName,
	DM.IsPLCConnected,
	DM.DispenserName
	

--SELECT * FROM #BatchEfficiency
--SELECT * FROM #MachineEfficiency
  
/*  
 -- Efficiency by Machine calculation   
 SELECT t.GroupID,   
  t.MachineId,  
  t.WasherNumber,  
  t.WasherName,  
  CAST(sum(t.ActualProduction) AS FLOAT) AS ActualProduction,  
  CAST(sum(t.StandardProduction) AS FLOAT) AS StandardProduction,  
  SUM(t.ActualRunTime) AS ActualRuntime,  
  SUM(t.StandardRunTime) AS StandardRunTime,  
  (SUM(t.MissedLoads)/count(DISTINCT t.BatchId)) AS MissedLoads,  
  (CAST(sum(t.LoadEfficiency) AS FLOAT) / count(DISTINCT t.BatchId)) AS LoadEfficiency,  
  ((CAST(sum(t.TimeEfficiency) AS FLOAT) / count(DISTINCT t.BatchId))*100)  AS TimeEfficiency,  
  ((CAST(sum(t.LoadEfficiency) AS FLOAT) / count(DISTINCT t.BatchId)) * (CAST(sum(t.TimeEfficiency) AS FLOAT) / count(DISTINCT t.BatchId))) AS TotalEfficiency  
 INTO #MachineEfficiency  
 FROM #BatchEfficiency t  
 RIGHT JOIN @Dashboardmachinemapping DM ON DM.GroupID = t.GroupId   
      AND dm.WasherId = t.MachineId  
 WHERE ActualRunTime > (t.StandardRunTime * 10/100)  
 GROUP BY t.GroupID,   
 t.MachineId,  
 t.WasherNumber,  
 t.WasherName  
*/  
    
  
 INSERT @AlarmByMachine  
 (  
     GroupID,  
     WasherID,  
     Alarm,  
     AlarmDescription  
 )  
 SELECT AlarmByMachine.GroupID, AlarmByMachine.WasherID, AlarmByMachine.Alarm, AlarmByMachine.AlarmDescription   
 FROM (  
     SELECT ROW_NUMBER() OVER (PARTITION BY AD.MachineId ORDER BY AD.StartDate DESC) AS rownum  
     , AD.IsActive AS Alarm, AM.[Description] AS AlarmDescription  
     , AD.MachineId AS WasherID  
     , d.GroupID  
     FROM TCD.AlarmData AD   
	    INNER JOIN TCD.AlarmGroupMaster AM on AM.AlarmGroupMasterId = AD.AlarmGroupMasterId
     INNER JOIN @Dashboardmachinemapping d ON AD.MachineId = D.WasherId  
     ) AS AlarmByMachine  
 WHERE rownum = 1  
  
 INSERT @BatchEndtimes  
 (  
     GroupID,  
     WasherID,  
     CurrentBatchEndTime,  
     BatchEndTime  
 )  
 SELECT d.GroupID, d.WasherId,   
 COUNT(CASE WHEN bd.EndDate IS NULL THEN 1 ELSE NULL END) AS CurrentBatchEndTime,  
 CAST(MAX(bd.EndDate) AS TIME) AS BatchEndTime  
 FROM @DashboardMachineMapping d  
 INNER JOIN TCD.BatchData bd ON d.GroupID = bd.GroupId AND d.WasherId = bd.MachineId  
 WHERE bd.ShiftId IN (  
 SELECT ShiftId FROM @ShiftIds)  
 GROUP BY d.GroupID, d.WasherId  
  
  
 SELECT @StandardTurnTime = ISNULL(ConStdTurnTime,30)  From tcd.Plant  
 SELECT @StandardTurnTime = @StandardTurnTime + ISNULL(TargetTurnTime,0)  From tcd.Washer Where WasherId = @WasherId  
  
 SELECT @MachineNameDispalyType=ISNULL( MachineNameDispalyType,0) FROM TCD.Dashboard D WHERE D.DashboardId=@DashBoardId  
  
  
 INSERT INTO @Summarizeddata(  
  GroupId,  
  MachineId,  
  WasherName ,  
  WasherNumber,  
  TargetLoad,  
  ActualLoad,  
  LoadEfficiency,  
  TimeEfficiency,  
  LostLoad,  
  Alarm,  
  AlarmDescription,  
  WasherStatus,  
  MachineNameDispalyType,  
  TargetTurnTime,  
		DefaultIdleTime,
		IsPLCConnected,
		DispenserName,
		LostBatches
  )  
  SELECT me.GroupID,  
  me.MachineID,  
  me.WasherName,  
  me.WasherNumber,  
  me.StandardProduction AS TargetLoad,  
  me.ActualProduction AS ActulaLoad,  
  me.LoadEfficiency,  
  me.TimeEfficiency,  
  me.MissedLoads AS LostLoad,  
  ISNULL(abm.Alarm,0) AS Alarm,  
  abm.AlarmDescription,  
  CASE   
      WHEN be.CurrentBatchEndTime = 1 THEN 1  
      WHEN CAST(GETUTCDATE() AS TIME) BETWEEN be.BatchEndTime AND DateAdd(Minute,@StandardTurnTime,be.BatchEndTime) THEN 2  
      WHEN abm.Alarm = 1 THEN 3  
      ELSE 3  
  END AS WasherStatus,  
  @MachineNameDispalyType,  
  ( SELECT TargetTurnTime FROM TCD.WASHER W WHERE W.WasherId=ME.MachineID),  
		  ( SELECT DefaultIdleTime FROM TCD.WASHER W WHERE W.WasherId=ME.MachineID),
		  me.IsPLCConnected,
		me.DispenserName,
		me.LostBatches
  FROM #MachineEfficiency me  
  LEFT JOIN @AlarmByMachine abm on ME.GroupID = abm.GroupID AND ME.MachineID = ABM.WasherID  
  LEFT JOIN @BatchEndtimes be ON me.GroupID = be.GroupID AND me.MachineID = be.WasherID  
  
 SELECT  
  GroupId,   
  MachineId,   
  CASE @Machinenamedispalytype  
      WHEN 0 THEN CAST(WasherNumber AS VARCHAR(20)) + ' ' + WasherName  
      WHEN 1 THEN WasherName  
      WHEN 2 THEN CAST(WasherNumber AS VARCHAR(20))  
  END AS WasherName,   
  WasherNumber,   
  TargetLoad,   
  ActualLoad,   
  LoadEfficiency,   
  TimeEfficiency,   
    ( CASE WHEN isnull(LostLoad,0)<0 THEN 0 ELSE LostLoad END) LostLoad,   
  Alarm,   
  AlarmDescription,   
  WasherStatus,  
  TargetTurnTime,  
		DefaultIdleTime,
		IsPLCConnected,
		DispenserName,
		( CASE WHEN isnull(LostBatches,0)<0 THEN 0 ELSE LostBatches END) LostBatches
     FROM @Summarizeddata  
     ORDER BY  
  WasherNumber  
  
  
---- CleanUp  
DROP TABLE #BatchData
DROP TABLE #BatchEfficiency  
DROP TABLE #MachineEfficiency  
  
END
GO


GO
/*Issue 138238:RW: M: Local: Location view should be displayed by default*/
 UPDATE RD SET RD.DefaultViewId=2 FROM TCD.ReportDefaultViewRoleMapping RD WHERE ReportId=1
 UPDATE TCD.ReportColumnsMapping SET DisplayOrder =2 WHERE ReportId=1 and ColumnId=133
UPDATE TCD.ReportColumnsMapping SET DisplayOrder =3 WHERE ReportId=1 and ColumnId=181
UPDATE TCD.ReportColumnsMapping SET DisplayOrder =4 WHERE ReportId=1 and ColumnId=200


UPDATE RCM SET IsVisible=1  FROM TCD.ReportColumnsMapping RCM WHERE ReportId=2 and ColumnId IN(133)
UPDATE TCD.ReportColumnsMapping SET DisplayOrder =2 WHERE ReportId=2 and ColumnId=133
 GO

 IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[ProductionShiftDataRollup]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[ProductionShiftDataRollup]
END 
Go
 CREATE PROCEDURE [TCD].[ProductionShiftDataRollup](@RedFlagShiftId INT OUTPUT)
AS
BEGIN
	SET NOCOUNT ON
    DECLARE @DayId INT = NULL,
	@ShiftId Int = NULL,
	@ShiftName Varchar(100) = NULL,
	@StartTime DateTime = NULL,
	@EndTime DateTime = NULL,
	@DateStartTime DATETIME= NULL,
	@DateEndTime DATETIME= NULL,
	@BatchUTCStart DATETIME= NULL,
	@BatchUTCEnd DATETIME= NULL,
	@ShiftTargetProd Decimal(18,2) = NULL,
	@ConStdTurnTime Int= NULL,
	@ActualRunandConTurnTime Int= NULL,
	@TargetRunandConTurnTime Int= NULL,
	@ActualRunandTunTurnTime Int= NULL,
	@TargetRunandTunTurnTime Int= NULL,
	@SummationProduction Int,
	@NoOfLoads INT,@prevDay INT,@Rollingcount int = 1        
	,@RowCount int = NULL,@RealDayId Int,@ShiftCount Int = 1,@LabourShift int
	,@EcolabAccountNumber NVARCHAR(25) = NULL
		
	--SELECT * FROM TCD.WeekDay  SELECT DATENAME(dw,GETDATE()) 

    SELECT @DayId = DayId FROM [TCD].WeekDay WITH (NOLOCK) WHERE DayName = DATENAME(dw,GETDATE()) 

    SELECT @prevDay = CASE WHEN @DayId = 1 THEN 7 ELSE @DayId - 1 END
    SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant 

    DECLARE @BatchShiftTable TABLE
						(
						  RowNumber int IDENTITY(1,1),
						  BatchUTCStartDate datetime,
						  BatchUTCEndDate datetime,
						  ShiftId int
						)

    DECLARE @Result TABLE
				    (
				    StartDate Datetime,
				    EndDate Datetime,
				    ShiftId INT,
				    ShiftName Varchar(1000),
				    DayID Int,
				    TargetProduction [decimal](18,2)
				    )

    DECLARE @shiftdata_temp TABLE
						  (
						  SNo INT IDENTITY(1,1),
						  [ShiftId] [int],
						   [ShiftName] [nvarchar](1000) ,
						   [DayId] [int] ,
						   [StartTime] [time](7) ,
						   [EndTime] [time](7) ,
						   [TargetProduction] [decimal](18, 2) ,
						   [Is_Deleted] [bit] ,
						   [EcolabAccountNumber] [nvarchar](1000) ,
						   [LastModifiedByUserId] [int] ,
						   [LastModifiedTime] [datetime] ,
						   [LastSyncTime] [datetime],
						   [TargetProduction_Display] [decimal](18, 2) 
						   )        
    INSERT INTO @shiftdata_temp
     SELECT 
		    [ShiftId] ,           
		    [ShiftName],		
		    [DayId],              
		    [StartTime],          
		    [EndTime],            
		    [TargetProduction] , 
		    [Is_Deleted],        
		    [EcolabAccountNumber],
		    [LastModifiedByUserId],
		    [LastModifiedTime],	
		    [LastSyncTime],
		    [TargetProduction_Display]		
	 FROM TCD.ShiftData WITH (NOLOCK) WHERE (DayId = @DayId OR (DayId = @prevDay AND (EndTime < StartTime OR EndTime = StartTime))) AND IS_Deleted = 0  
	 ORDER BY DayId
	 
	UPDATE @shiftdata_temp SET DayId = CASE WHEN @DayId = 1 THEN 0 ELSE DayId END WHERE DayId = 7
	UPDATE @shiftdata_temp SET DayId = CASE WHEN @DayId = 7 THEN 8 ELSE DayId END WHERE DayId = 1

	 SELECT @RowCount = SNo FROM @shiftdata_temp 

	WHILE(@Rollingcount <=  @RowCount)        
    BEGIN        
			DECLARE @VALIDSTART DATETIME,@VALIDEND DATETIME    
		    SELECT @VALIDSTART = CASE WHEN DayId > @DayId THEN  DATEADD(day, DATEDIFF(day, -1, GETDATE()), CAST(starttime AS datetime))
								 WHEN DayId < @DayId THEN   DATEADD(day, DATEDIFF(day, 1, GETDATE()), CAST(starttime AS datetime)) 
														ELSE
														 DATEADD(day, DATEDIFF(day, 0, GETDATE()), CAST(starttime AS datetime)) END		    ,
				   @VALIDEND =  CASE WHEN ((DayId > @DayId AND EndTime > StartTime) OR (DayId = @DayId AND (EndTime = StartTime OR EndTime < StartTime))) THEN 
													   DATEADD(day, DATEDIFF(day,-1, GETDATE()), CAST(EndTime AS datetime))
								 WHEN (DayId < @DayId AND (EndTime < StartTime OR EndTime = StartTime)) THEN 
													    DATEADD(day, DATEDIFF(day, 0, GETDATE()), CAST(EndTime AS datetime))
								 WHEN (DayId > @DayId AND (EndTime < StartTime OR EndTime = StartTime)) THEN 
												    	  DATEADD(day, DATEDIFF(day,-2, GETDATE()), CAST(EndTime AS datetime))						 
								 					   ELSE
														  DATEADD(day, DATEDIFF(day, 0, GETDATE()), CAST(EndTime AS datetime)) 
														  END,@ShiftId = ShiftId,@ShiftName = ShiftName,@RealDayId = DayId,@ShiftTargetProd = TargetProduction
					    FROM @shiftdata_temp WHERE SNo = @Rollingcount 

					    INSERT INTO @Result(StartDate,EndDate,ShiftId,ShiftName,DayID,TargetProduction)
					    SELECT @VALIDSTART,@VALIDEND,@ShiftId,@ShiftName,@RealDayId,@ShiftTargetProd

		        
			SET @Rollingcount = @Rollingcount + 1        
    END        

	
    SELECT DISTINCT @StartTime = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(StartDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(StartDate AS time)) AS DateTime)),
				@EndTime = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(EndDate AS time)) AS DateTime)),
				@ShiftId = ShiftId,@ShiftName = ShiftName,@DayId = DayID,@ShiftTargetProd = TargetProduction  FROM @Result
	WHERE GETDATE() BETWEEN StartDate AND EndDate

    SELECT @LabourShift = @ShiftId

    IF(@StartTime IS NULL AND @EndTime IS NULL)
    BEGIN
		SELECT @ShiftId = NULL,@ShiftName = NULL,@ShiftTargetProd = NULL
    END
   
	IF(COUNT(@ShiftId) <> 1)      ---NO shift Timings
	BEGIN
		SELECT TOP 1 @StartTime = EndTime FROM [TCD].ShiftData WITH (NOLOCK)
		WHERE DayId = @DayId 
			AND Is_Deleted = 0
			AND EndTime < CONVERT(TIME, CONVERT(VARCHAR(20), GETDATE(), 120)) ORDER BY EndTime DESC
			
		SELECT TOP 1 @EndTime = StartTime  FROM [TCD].ShiftData WITH (NOLOCK)
		WHERE DayId = @DayId 
			AND Is_Deleted = 0
			AND CONVERT(TIME, CONVERT(VARCHAR(20), GETDATE(), 120)) < StartTime ORDER BY StartTime	
					
			IF(COUNT(@StartTime) <> 1)
				BEGIN
					SELECT @StartTime = CAST(dateadd(DAY, datediff(day, 0, getdate()),0) AS dateTime)
				END
					ELSE
				BEGIN
					SELECT @StartTime = DATEADD(day, DATEDIFF(day, 0, GETDATE()),@StartTime)
				END

			IF(COUNT(@EndTime) <> 1)
				BEGIN
					SELECT @EndTime =  CAST(DATEADD(s, -1, DATEADD(day, 1,CONVERT(DATETIME, CONVERT(DATE, GETDATE())))) AS dateTime)
				END
					ELSE
				BEGIN
					SELECT @EndTime = DATEADD(day, DATEDIFF(day, 0, GETDATE()),@EndTime)
				END

		SET @StartTime = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@StartTime AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@StartTime AS time)) AS DateTime))
		SET @EndTime = 	dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndTime AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndTime AS time)) AS DateTime))		  

	END    	    

 	 --SET @ShiftId = CASE WHEN COUNT(@ShiftId) <> 1 THEN 0 ELSE @ShiftId END
	 ----- Inserting the meta data into shift production base table -------

      ----------------/* Getting the Target Production from TargetProduction details if exists else in shift data page */---------------

    IF ((SELECT COUNT(1) FROM TCD.TARGETPRODUCTIONDETAILS AS T WITH (NOLOCK) WHERE DayId = @DayId AND T.ShiftId = @ShiftId) = 1)
	BEGIN
		SELECT @ShiftTargetProd = TPD.TargetProduction FROM TCD.TARGETPRODUCTIONDETAILS TPD  WITH (NOLOCK)
		WHERE DayId = @DayId AND TPD.ShiftId = @ShiftId
	END
	   
		  
	--DELETE FROM TCD.ProductionShiftData WHERE ShiftId = @ShiftId AND CAST(StartDateTime AS date) = CAST(GETDATE() AS date)
	IF NOT EXISTS (SELECT 1 FROM [TCD].ProductionShiftData WITH (NOLOCK) WHERE StartDateTime = @StartTime )
	BEGIN
		--DECLARE @Count INt 
		--SELECT @Count = MAX(ShiftId) FROM [TCD].ProductionShiftData WITH (NOLOCK)

		UPDATE TCD.ProductionShiftData
		SET				        
			TCD.ProductionShiftData.EndDateTime = @StartTime
			WHERE TCD.ProductionShiftData.EndDateTime > @StartTime

		SELECT TOP 1 @RedFlagShiftId=ShiftId FROM [TCD].ProductionShiftData WHERE StartDateTime < @StartTime ORDER BY StartDateTime DESC

		INSERT INTO [TCD].ProductionShiftData (
										-- [ShiftId],
											[ShiftName],
											[StartDateTime],
											[EndDateTime],
											[TargetProduction],
											[EcolabAccountNumber]
										) 
		SELECT  --CASE WHEN COUNT(@Count) <> 1 THEN 1 ELSE @Count + 1 END,
			CASE WHEN COUNT(@ShiftName) <> 1 THEN 'No Shift' ELSE @ShiftName END,
			@StartTime,
			@EndTime,
			ISNULL(@ShiftTargetProd,0),
			@EcolabAccountNumber				    			
	END
			
	 INSERT INTO @BatchShiftTable
	 (
	    
	    BatchUTCStartDate,
	    BatchUTCEndDate,
	    ShiftId
	 )
	 SELECT TOP 2 
		StartDateTime,
		EndDateTime,
		ShiftId	 
		FROM [TCD].ProductionShiftData SD WITH (NOLOCK)  ORDER BY SD.StartDateTime DESC 
    
	   ------------------******// Inserting the Data into Batch Summary Temp table based on UTC shift timings //******-----------------------
    WHILE (@ShiftCount <= (SELECT COUNT(1) FROM @BatchShiftTable bst))
    BEGIN

     /* Picking up the first record from the top 2 records of production shift data */

	SELECT  @BatchUTCStart = bst.BatchUTCStartDate,
	@BatchUTCEnd =bst.BatchUTCEndDate,  @ShiftId = bst.ShiftId
	FROM @BatchShiftTable bst WHERE bst.RowNumber = @ShiftCount
					  
	DECLARE @BatchSummary TABLE
				(
				   RowNumber Int,
				   BatchId Int,
				   ActualWeight Int,
				   StandardWeight Int,
				   MachineId Int,
				   EcolabWasherId Int,
				   StartDate datetime2,
				   EndDate datetime2,
				   ProgramNumber Int,
				   ProgramMasterId Int,
				   CustomerId Int,
				   PiecesCount int,
				   ManualInputWeight int,
				   TargetTurnTime INT,
				   EcolabTextileId INT,
				   ChainTextileId  INT ,
				   PlantProgaramId INT
				)

    INSERT INTO @BatchSummary
		(
		RowNumber ,
		BatchId ,
		ActualWeight ,
		StandardWeight ,
		MachineId ,
		EcolabWasherId ,
		StartDate ,
		EndDate ,
		ProgramNumber,
		ProgramMasterId ,
		CustomerId ,
		PiecesCount ,
		ManualInputWeight ,
		TargetTurnTime ,
		EcolabTextileId ,
		ChainTextileId  ,
		PlantProgaramId 		
		)
	   SELECT 
				  ROW_NUMBER() OVER(PARTITION BY BD.MachineId ORDER BY BD.StartDate) RowNumber,
				   BD.BatchId,
				   ActualWeight,
				   StandardWeight,
				   MachineId,
				   BD.EcolabWasherId,
				   StartDate,
				   EndDate,
				   ProgramNumber,
				   ProgramMasterId,
				   BCD.CustomerId,
				   BCD.PiecesCount,
				   BD.ManualInputWeight,
				   BD.TargetTurnTime,
				   BD.EcolabTextileCategoryId,
				   BD.ChainTextileCategoryId,
				   BD.PlantProgramId
			 FROM TCD.BatchData BD WITH (NOLOCK)
					   INNER JOIN TCD.MachineSetup MS WITH (NOLOCK) ON MS.WasherId = BD.MachineId 
				    LEFT OUTER JOIN 
				 TCD.BatchCustomerData BCD WITH (NOLOCK) ON BD.BatchId = BCD.BatchId
			  WHERE BD.EndDate >= @BatchUTCStart AND BD.EndDate <= @BatchUTCEnd 

	   
	------------------******// Inserting the Data into Chemical temp table  //******-----------------------

	DECLARE @BatchChemicalSummary TABLE
				(
				   BatchId Int,
				   EcolabWasherId Int,
				   StartDate datetime2,
				   EndDate datetime2,
				   MachineId Int,
				   ProgramMasterId Int,
				   ProductId Int,
				   ActualQuantity Decimal(18,2),
				   StandardQuantity Decimal(18,2),
				   Price Decimal(18,2),
				   CustomerId Int,
				   EcolabTextileId INT,
				   ChainTextileId  INT ,
				   PlantProgaramId INT
				  			   
				)

    INSERT INTO @BatchChemicalSummary
		(
			BatchId,
			EcolabWasherId ,
			StartDate ,
			EndDate ,
			MachineId ,
			ProgramMasterId ,
			ProductId ,
			ActualQuantity ,
			StandardQuantity ,
			Price ,
			CustomerId ,
			EcolabTextileId ,
			ChainTextileId   ,
			PlantProgaramId 
		
		)
	   SELECT 
				   BD.BatchId,
				   BD.EcolabWasherId,
				   StartDate,
				   EndDate,
				   MachineId,
				   ProgramMasterId,
				   BPD.ProductId,
				   BPD.ActualQuantity,
				   BPD.StandardQuantity,
				   BPD.Price,
				   BCD.CustomerId,
				   BD.EcolabTextileCategoryId,
				   BD.ChainTextileCategoryId,
				   BD.PlantProgramId
			 FROM  TCD.BatchProductData BPD	WITH (NOLOCK)				   
					   INNER JOIN TCD.BatchData BD WITH (NOLOCK) ON BD.BatchId = BPD.BatchId
					   INNER JOIN TCD.MachineSetup MS WITH (NOLOCK) ON MS.WasherId = BD.MachineId 
					   LEFT OUTER JOIN TCD.ProductMaster PD WITH (NOLOCK) ON PD.ProductId = BPD.ProductId
					   LEFT OUTER JOIN  TCD.BatchCustomerData BCD WITH (NOLOCK) ON BD.BatchId = BCD.BatchId
					   WHERE BD.EndDate >= @BatchUTCStart AND BD.EndDate <= @BatchUTCEnd

	SELECT @NoOfLoads = COUNT(DISTINCT BatchId) FROM @BatchSummary
  
	------------------******// Inserting the Data into Machine Efficiency Temp table for runtimes based on machines //******-----------------------

	

	DECLARE @MachineEfficency TABLE
					   ( 
						  MachineId INT,
						  ProgramMasterId INT,
						  ActualRunTime INT, 
						  StandardRunTime INT,
						  ActualTurnTime INT,
						  StandardTurnTIme INT
					   )

    INSERT INTO @MachineEfficency
					   ( 
						  MachineId,
						  ProgramMasterId,
						  ActualRunTime , 
						  StandardRunTime,
						  ActualTurnTime,
						  StandardTurnTIme
					   )
	   SELECT 
			DISTINCT
			  CUR.MachineId,CUR.ProgramMasterId,	   
			 CAST(SUM(DATEDIFF(SECOND,CUR.StartDate,CUR.EndDate)) AS decimal(18,2)),
			 ISNULL(SUM(WPS.TotalRunTime),1),--+ @ConStdTurnTime + ISNULL(SUM(WPS.ExtraTime),1),
			 ISNULL(SUM( CASE WHEN DATEDIFF(SECOND,CUR.EndDate,nexting.StartDate) < 0 THEN 0 ELSE  DATEDIFF(SECOND,CUR.EndDate,nexting.StartDate) END),1),
			 ISNULL(SUM(CUR.TargetTurnTime),1)
	    FROM @BatchSummary CUR 
				LEFT OUTER JOIN @BatchSummary nexting ON cur.RowNumber = nexting.RowNumber - 1 AND CUR.MachineId = nexting.MachineId --AND CUR.ProgramMasterId = nexting.ProgramMasterId
				INNER JOIN TCD.MachineSetup MS WITH (NOLOCK) ON MS.WasherId = CUR.MachineId AND MS.IsTunnel = 0 AND MS.IsDeleted = 0
				LEFT JOIN TCD.WasherProgramSetup WPS WITH (NOLOCK) ON WPS.ProgramId = CUR.ProgramMasterId AND MS.GroupId = WPS.WasherGroupId AND WPS.Is_Deleted = 0
				GROUP BY CUR.MachineId,CUR.ProgramMasterId
	   UNION ALL

	   SELECT 
			DISTINCT
			CUR.MachineId,CUR.ProgramMasterId,
			 CAST(SUM(DATEDIFF(SECOND,CUR.StartDate,CUR.EndDate)) AS decimal(18,2)),			
			 ISNULL(SUM(TPS.TotalRunTime),1),
			SUM(COALESCE(3600/NULLIF(COALESCE(DATEDIFF(SECOND,CUR.StartDate,CUR.EndDate)/ NULLIF(MS.NumberOfComp,0),0) ,0), 0)) ,
			 SUM(COALESCE(3600/NULLIF(COALESCE(TPS.TotalRunTime/ NULLIF(MS.NumberOfComp,0),0) ,0), 0)) --+ ISNULL(SUM(TPS.ExtraTime),1)
	   FROM @BatchSummary CUR
				INNER JOIN TCD.MachineSetup MS WITH (NOLOCK) ON MS.WasherId = CUR.MachineId AND MS.IsTunnel = 1 AND MS.IsDeleted = 0
				        LEFT JOIN TCD.TunnelProgramSetup TPS WITH (NOLOCK) ON TPS.ProgramId = CUR.ProgramMasterId AND MS.GroupId = TPS.WasherGroupId AND TPS.Is_Deleted = 0
		  GROUP BY CUR.MachineId,CUR.ProgramMasterId

	--------------------------******// Inserting the Data into production Shift Rollup Data Table //******-------------------
	      		  
		 
	DELETE FROM [TCD].ShiftProductionDataRollup WHERE ShiftId = @ShiftId 
		 
	INSERT INTO [TCD].ShiftProductionDataRollup
							 (
								ShiftId,
								MachineId,
								ProgramMasterId,
								EcolabWasherId,
								NoOfLoads,
								ActualProduction ,
								StandardProduction,
								LoadEfficiency,
								TimeEfficiency,
								PlantTargetProd ,
								ActualRunTime,
								TargetRunTime,
								EcolabTextileId,
								ChainTextileId,
								ChainProgaramId,
								CustomerId,
								NoOfPieces,
								ActualTurnTime,
								TargetTurnTime
							 )	


		  SELECT 
				DISTINCT
					 @ShiftId,
				      CUR.MachineId,
					 CUR.ProgramMasterId,
					 CUR.EcolabWasherId,
					 COUNT(1),
					 SUM(CUR.ActualWeight) + ISNULL(SUM(CUR.ManualInputWeight),0),
					 SUM(CUR.StandardWeight),

					 CAST(COALESCE(((SUM(CUR.[ActualWeight]))/ NULLIF(ISNULL(SUM(CUR.[StandardWeight]),SUM(CUR.[ActualWeight])),0)), 0) AS decimal(18,2)),

					 --CAST(((SUM(CUR.[ActualWeight]))/ISNULL(SUM(CUR.[StandardWeight]),SUM(CUR.[ActualWeight]))) AS decimal(18,2)),

					 CAST(COALESCE(CAST(SUM(ME.StandardRunTime) AS Decimal(18,2))/ NULLIF(ISNULL(CAST(SUM(ME.ActualRunTime) AS decimal(18,2)),CAST(SUM(ME.ActualRunTime) AS Decimal(18,2))),0), 0) AS decimal(18,2)) ,

					 --CAST(CAST(SUM(ME.ActualRunTime) AS Decimal(18,2))/ISNULL(CAST(SUM(ME.StandardRunTime) AS decimal(18,2)),CAST(SUM(ME.ActualRunTime) AS Decimal(18,2))) AS decimal(18,2)) ,
			 		 @ShiftTargetProd * 1000,					 
					 COALESCE(SUM(ME.ActualRunTime) / NULLIF(COUNT(1),0), 0), 
					 COALESCE(ISNULL(SUM(ME.StandardRunTime),SUM(ME.ActualRunTime))/ NULLIF(COUNT(1),0), 0), 

					 CUR.EcolabTextileId,CUR.ChainTextileId,CUR.PlantProgaramId,
					 --ETC.TextileId,CTC.TextileId,PCP.PlantProgramId,
					 CUR.CustomerId,
				      SUM(CUR.PiecesCount),
					 COALESCE(SUM(ME.ActualTurnTime) / NULLIF(COUNT(1),0), 0),
					 COALESCE(ISNULL(SUM(ME.StandardTurnTIme),SUM(ME.ActualTurnTime))/ NULLIF(COUNT(1),0), 0)
							 FROM 
					   @BatchSummary CUR 
						  LEFT JOIN 
								@MachineEfficency ME ON CUR.MachineId = ME.MachineId AND CUR.ProgramMasterId = ME.ProgramMasterId
						  LEFT JOIN 
								 TCD.ProgramMaster PM WITH (NOLOCK) ON PM.ProgramId = CUR.ProgramMasterId
						/*
						  LEFT JOIN
								TCD.EcolabTextileCategory ETC WITH (NOLOCK) ON ETC.TextileId = PM.EcolabTextileCategoryId
						  LEFT JOIN
								TCD.ChainTextileCategory CTC WITH (NOLOCK) ON  CTC.TextileId = PM.ChainTextileId
						  LEFT JOIN
								TCD.PlantChainProgram PCP ON PCP.PlantProgramId = PM.PlantProgramId
						*/
						  GROUP BY CUR.MachineId,CUR.EcolabWasherId,CUR.ProgramMasterId,--ETC.TextileId,CTC.TextileId,PCP.PlantProgramId,
						  CUR.EcolabTextileId,CUR.ChainTextileId,CUR.PlantProgaramId,
						  CUR.CustomerId


	--------------------------******// Inserting the Data into Chemical Shift Rollup Data Table //******-------------------
	  	  
		 
	DELETE FROM [TCD].[ShiftChemicalDataRollup] WHERE ShiftId = @ShiftId 

	INSERT INTO [TCD].[ShiftChemicalDataRollup]
							 (
								 [ShiftId] ,
								 [MachineId],
								 [ProgramMasterId],
								 [EcolabWasherId],
								 [ProductId],
								 [ActualConsumption],
								 [TargetConsumption],
								 [ActualCost],
								 [EcolabTextileId],
								 [ChainTextileId],
								 [ChainProgaramId],
								 [CustomerId],
								 NoOfLoads
							 )
				SELECT
				    DISTINCT 
						  @ShiftId,
						  CUR.MachineId,
						  CUR.ProgramMasterId,
						  CUR.EcolabWasherId,
						  CUR.ProductId,
						  SUM(CUR.ActualQuantity),
						  SUM(CUR.StandardQuantity),
						  SUM(CUR.Price),
						  CUR.EcolabTextileId,
						  CUR.ChainTextileId,
						  CUR.PlantProgaramId,
						  CUR.CustomerId,
						  @NoOfLoads
						  FROM 
						  @BatchChemicalSummary CUR 
						   LEFT JOIN 
								 TCD.ProgramMaster PM WITH (NOLOCK) ON PM.ProgramId = CUR.ProgramMasterId
						  --LEFT JOIN
								--TCD.EcolabTextileCategory ETC WITH (NOLOCK) ON ETC.TextileId = PM.EcolabTextileCategoryId
						  --LEFT JOIN
								--TCD.ChainTextileCategory CTC WITH (NOLOCK) ON  CTC.TextileId = PM.ChainTextileId
						  --LEFT JOIN
								--TCD.PlantChainProgram PCP WITH (NOLOCK) ON PCP.PlantProgramId = PM.PlantProgramId
						  GROUP BY CUR.MachineId,CUR.EcolabWasherId,CUR.ProgramMasterId,CUR.ProductId,CUR.CustomerId,CUR.EcolabTextileId,CUR.ChainTextileId,CUR.PlantProgaramId

		IF NOT EXISTS (SELECT 1 FROM [TCD].[ProductionShiftLaborData] WHERE ShiftId = @ShiftId)
			BEGIN
				INSERT INTO [TCD].[ProductionShiftLaborData]
				SELECT  @ShiftId,
				SLD.LaborTypeId,
				SLD.LaborHours,
				SLD.LaborHours * SLD.PricePerHr
					FROM [TCD].[ShiftLaborData] SLD WITH (NOLOCK) WHERE ShiftId = @LabourShift AND DayId = @DayId
			END
		  
		  DELETE FROM @BatchSummary
		  DELETE FROM @BatchChemicalSummary
		  DELETE FROM @MachineEfficency
		  
	    SET @ShiftCount = @ShiftCount + 1
	END

SET NOCOUNT OFF
END

Go
 UPDATE tcd.ResourceKeyValue SET Value='oz/Cwt' WHERE KeyName='ounce_per_cwt'
 GO

 IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetWasherGroupFromulaInjectionDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetWasherGroupFromulaInjectionDetails
	END
GO  
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE  PROCEDURE [TCD].[GetWasherGroupFromulaInjectionDetails]

            (

            @EcolabAccountNumber nvarchar(25) = NULL,

            @WasherGroupId INT = NULL,

            @WasherProgramSetupId INT = NULL

            )

AS

SET NOCOUNT ON

BEGIN

   

 SELECT  

 DISTINCT

  WDS.WasherDosingSetupId

  ,CAST(WPS.ProgramNumber AS INT) AS ProgramId

  ,WG.WasherGroupNumber

  ,WDP.InjectionNumber

  ,CES.ControllerEquipmentId

  ,WDP.ProductId

  -- ,PM.Name

  ,WDP.Quantity

  ,IJ.ReferenceLoad

  --,WDS.StepNumber

  --,WS.[StepId] AS WashOperationId

  --,WS.[StepName] AS WashOperation   

  ,IJ.InjectionClass

  ,IJ.ControllerId

  ,CT.Id AS ControllerType

  ,WPS.NominalLoad

 FROM [TCD].[WasherProgramSetup] WPS



  INNER JOIN  [TCD].[WasherDosingSetup] WDS ON WPS.[WasherProgramSetupId] = WDS.[WasherProgramSetupId] AND WDS.Is_Deleted=0 

  INNER JOIN TCD.WasherDosingProductMapping WDP ON WDS.WasherDosingSetupId = WDP.WasherDosingSetupId AND WDP.IsDeleted = 0

  INNER JOIN TCD.WasherGroup WG ON WG.WasherGroupId = WPS.WasherGroupId

  INNER JOIN TCD.Injection IJ ON WG.WasherGroupNumber = IJ.WasherGroupNumber AND IJ.Is_Deleted=0

  INNER JOIN TCD.ConduitController CC ON IJ.ControllerId = CC.ControllerId AND cc.Active = 1 AND cc.IsDeleted =0

  INNER JOIN TCD.ControllerType CT ON CC.ControllerTypeId = CT.Id

  INNER JOIN TCD.ProductMaster PM ON WDP.ProductId = PM.ProductId

  INNER JOIN TCD.ControllerEquipmentSetup CES ON CES.ProductId = PM.ProductId AND CES.ControllerId = CC.ControllerId

  --LEFT JOIN [TCD].WashStep WS  ON WS.StepId     =   WDS.StepTypeId

 WHERE  

  WG.WasherGroupId=@WasherGroupId

  AND WPS.WasherProgramSetupId = @WasherProgramSetupId  

  AND WPS.EcolabAccountNumber = @EcolabAccountNumber
     

 END
 GO