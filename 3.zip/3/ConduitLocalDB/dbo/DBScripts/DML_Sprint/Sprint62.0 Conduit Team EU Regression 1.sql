﻿
/*TCD.GetControllerInfoById*/
GO
if object_id('TCD.GetControllerInfoById') is not null
begin
	drop proc TCD.GetControllerInfoById

end

GO

CREATE PROCEDURE TCD.GetControllerInfoById (
	@ControllerId INT
	,@EcolabAccountNumber nvarchar(25) = NULL
	)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @ControllerModelId INT = (
			SELECT ControllerModelId
			FROM TCD.ConduitController
			WHERE ControllerId = @ControllerId
				AND EcoalabAccountNumber = ISNULL(@EcolabAccountNumber, EcoalabAccountNumber)
			);

	DECLARE @ControllerTypeId INT = (
			SELECT ControllerTypeId
			FROM TCD.ConduitController
			WHERE ControllerId = @ControllerId
				AND EcoalabAccountNumber = ISNULL(@EcolabAccountNumber, EcoalabAccountNumber)
			);
	DECLARE @FieldId INT = NULL;

	IF @ControllerTypeId = 1
	BEGIN
		SET @FieldId = 11
	END;
	ELSE IF @ControllerTypeId = 2
	BEGIN
		SET @FieldId = 21
	END;

	IF @ControllerModelId = 7
	BEGIN
		IF @ControllerTypeId = 2
			BEGIN
				SET @FieldId = 21
			END;
	END

	ELSE IF @ControllerModelId = 8
	BEGIN
		IF @ControllerTypeId = 6
			BEGIN
				SET @FieldId = 387
			END;
		ELSE IF @ControllerTypeId = 7
			BEGIN
				SET @FieldId = 400
			END;
	END

	ELSE IF @ControllerModelId = 9
	BEGIN
		IF @ControllerTypeId = 8
			BEGIN
				SET @FieldId = 414
			END;
		ELSE IF @ControllerTypeId = 10
			BEGIN
				SET @FieldId = 426
			END;
	END

	ELSE IF @ControllerModelId = 10
	BEGIN
		IF @ControllerTypeId = 6
			BEGIN
				SET @FieldId = 460
			END;
	END
	
	ELSE IF @ControllerModelId = 11
	BEGIN
		IF @ControllerTypeId = 12
			BEGIN
				SET @FieldId = 348
			END;
		ELSE IF @ControllerTypeId = 13
			BEGIN
				SET @FieldId = 309
			END;
		ELSE IF @ControllerTypeId = 14
			BEGIN
				SET @FieldId = 269
			END;
	END
	
	ELSE IF @ControllerModelId = 14
	BEGIN
		IF @ControllerTypeId = 9
			BEGIN
				SET @FieldId = 438
			END;
		ELSE IF @ControllerTypeId = 11
			BEGIN
				SET @FieldId = 449
			END;
	END

	SELECT CC.ControllerId
		,CC.TopicName
		,CC.ControllerTypeId
		,CT.NAME AS ControllerType
		,CC.ControllerModelId
		,CM.NAME AS ControllerModel
		,CSD.Value
	FROM TCD.ConduitController CC
	INNER JOIN TCD.ControllerType CT ON CT.Id = CC.ControllerTypeId
	INNER JOIN TCD.ControllerModel CM ON CM.Id = CC.ControllerModelId
	LEFT JOIN TCD.ControllerSetupData CSD ON CC.ControllerId = CSD.ControllerId
	WHERE CC.ControllerId = @ControllerId
		AND CSD.FieldId = @FieldId
		AND EcoalabAccountNumber = ISNULL(@EcolabAccountNumber, EcoalabAccountNumber);

	SET NOCOUNT OFF;
END;

GO

ALTER TABLE [TCD].[ControllerEquipmentSetup] ALTER COLUMN FlowSwitchTimeOut DECIMAL(18, 1) NULL
ALTER TABLE [TCD].[ControllerEquipmentSetupHistory] ALTER COLUMN FlowSwitchTimeOut DECIMAL(18, 1) NULL
ALTER TABLE [TCD].[ControllerEquipmentSetup] ALTER COLUMN FactorFM_B_FM Smallint NULL 
ALTER TABLE [TCD].[ControllerEquipmentSetupHistory] ALTER COLUMN FactorFM_B_FM Smallint NULL
GO

/*
Start TCD.GetControllerEquipmentList

*/

if object_id('TCD.GetControllerEquipmentList') is not null
begin
	drop proc TCD.GetControllerEquipmentList

end
GO

CREATE PROCEDURE [TCD].[GetControllerEquipmentList]                
  @EcoLabAccountNumber     NVARCHAR(1000)                
    , @ControllerId       INT                
    , @ControllerEquipmentId     TINYINT = NULL                
    , @IsActive       BIT = NULL                
AS                
BEGIN                
    SET NOCOUNT ON;                
    DECLARE                
     @ErrorMessage         NVARCHAR(4000)                
     ,@PumpValveCount        TINYINT                
     ,@MECount          TINYINT                
     ,@ControllerEquipmentTypeId_PumpValve    TINYINT                
     ,@ControllerEquipmentTypeId_ME      TINYINT                
     ,@ControllerModelId        INT                
     ,@ReturnValue         INT = 0                
     ,@TagTypeLfs         VARCHAR(100) = 'Tag_NML'                
     ,@TagTypeKfactor         VARCHAR(100) = 'Tag_PPOL'                
     ,@TagTypeCalibration        VARCHAR(100) = 'Tag_OPSL'          
 ,@ControllerTypeId INT;                
           
    CREATE TABLE #Equipment (                
    ControllerEquipmentId     INT    IDENTITY(1, 1)                
  , ControllerEquipmentTypeId     TINYINT   NULL                
  , IsActive        BIT    NOT NULL                
              DEFAULT                
              'FALSE'                
  , ProductId        INT    NULL                
  , ProductName       NVARCHAR(255)  NULL                
  , PumpCalibration       DECIMAL(18, 3)  NULL                
  , FlowMeterSwitchFlag      BIT    NULL                
  , FlowMeterCalibration      INT    NULL                
  , MaximumDosingTime      SMALLINT   NULL                
  , FlowSwitchTimeOut       decimal(18,1)   NULL                
  , ControllerEquipmentSetupId    SMALLINT   NULL                
  , LfsChemicalName       NVARCHAR(200)  NULL                
  , KFactor        DECIMAL(18, 2)  NULL                
  , TunnelHold        BIT    NULL                
  , FlowDetectorType      INT    NULL                
  , FlowSwitchAlarm       BIT    NULL                
  , FlowMeterAlarm       BIT    NULL                
  , FlowMeterType       INT    NULL                
  , FlowAlarmDelay       INT    NULL                
  , FlowMeterPumpDelay      INT    NULL                
  , FlowMeterAlarmDelay      INT    NULL                
  , LastModifiedTime      DATETIME   NULL                
  , LastSyncTime       DATETIME   NULL                
  , ControllerEquipmentTypeModelID    INT    NULL                
  , ConventionalWasherGroupConnection   BIT    NOT NULL                
              DEFAULT                
              0                
  , AxillaryPumpCalibration     SMALLINT   NULL                
  , FlowmeterSwitchActivated     BIT    NOT NULL                
              DEFAULT                
              'FALSE'                
  , FlushWhileDosing      BIT    NOT NULL                
              DEFAULT                
              'FALSE'                
  , WeightControlledDosage     BIT    NOT NULL                
              DEFAULT                
              'FALSE'                
  , EquipmentDoseAlone      BIT    NOT NULL                
              DEFAULT                
              'FALSE'                
  , LowLevelAlarm       BIT    NOT NULL                
              DEFAULT                
              'FALSE'                
  , LeakageAlarm       BIT    NOT NULL                
              DEFAULT                
              'FALSE'                
  , FlushTime        SMALLINT   NULL                
  , PumpingTime       SMALLINT   NULL                
  , PreFlushTime       SMALLINT   NULL                
  , NightFlushPauseTime      SMALLINT   NULL                
  , NightFlushTime       SMALLINT   NULL                
  , AcceptedDeviation      SMALLINT   NULL               
  , LineNumber    tinyint NULL DEFAULT 0              
  , DirectDosingFlag      BIT    NULL                
              DEFAULT                
              'FALSE'             
  , DirectDosingMachineInternalId    INT    NULL                
  , DirectDosingTunnelCompartmentId   INT    NULL                
  , WasherGroupTypeId     INT    NULL               
  , NumberOfCompartments     INT    NULL                 
  , FlushValveNumber      TINYINT   NULL              
  , CalibrationConductSS_Tank    DECIMAL(18,2)   NULL              
  , BackFlowControl       BIT    NULL              
  , FactorFM_B_FM       SMALLINT         NULL              
  , AcceptedDeviationRingLine    SMALLINT  NULL              
  , UsePumpOfGroup1ForTunnel    BIT    NULL              
  , pHSensorEnabled       BIT    NULL              
  , Concentration    INT    NULL            
  , Deadband              BIT    NULL           
  , WasherGroupNumber    INT     NULL         
  , ValveOutputAsTom  BIT NOT NULL DEFAULT  'FALSE'        
  , FlowSwitchNumber int  NULL         
  , FlushTimeForFlushValve int NULL    
    , MinimumFlowRate INT NULL  
  , ProductDensity DECIMAL(18,2) NULL  
  , MaximumConcentration INT NULL  
   );                
    IF NOT EXISTS ( SELECT 1                
        FROM TCD.ConduitController   CC                
        WHERE CC.EcoalabAccountNumber = @EcoLabAccountNumber                
AND CC.ControllerId = @ControllerId                
    )                
    BEGIN                
    SET   @ErrorMessage = 'Invalid Plant/Controller combination specified';                
    RAISERROR (@ErrorMessage, 16, 1);                
    SET  @ReturnValue = -1;                
    RETURN                
    @ReturnValue;                
    END;                
    SET @ControllerTypeId = (SELECT ControllerTypeid          
       FROM TCD.ConduitController CC          
       WHERE CC.ControllerId = @ControllerId);          
    SELECT @ControllerModelId = CC.ControllerModelId                
  FROM TCD.ConduitController CC                
  WHERE CC.ControllerId = @ControllerId;                
    SELECT @ControllerEquipmentTypeId_PumpValve = CASE                
              WHEN CET.ControllerEquipmentTypeName = 'Pump/Valve'                
              THEN CET.ControllerEquipmentTypeId                
              ELSE @ControllerEquipmentTypeId_PumpValve                
              END                
     , @ControllerEquipmentTypeId_ME = CASE                
           WHEN CET.ControllerEquipmentTypeName = 'ME'                
           THEN CET.ControllerEquipmentTypeId                
           ELSE @ControllerEquipmentTypeId_ME                
           END                
  FROM TCD.ControllerEquipmentType CET                
  WHERE CET.ControllerEquipmentTypeName   IN   ('Pump/Valve', 'ME');                
    IF (@ControllerModelId <> 7 AND @ControllerModelId  <> 8 AND @ControllerModelId <> 9 AND @ControllerModelId <> 11    
    AND @ControllerModelId <> 10 AND @ControllerModelId <> 14)              
    BEGIN                
    SELECT @PumpValveCount = ISNULL(CSD.Value, 0)                
      FROM TCD.ConduitController CC                
       JOIN                
       TCD.ControllerModelControllerTypeMapping CMCTM ON CC.ControllerModelId = CMCTM.ControllerModelId                
       JOIN                
       TCD.ControllerSetupData CSD ON CSD.ControllerId = CC.ControllerId                
          AND CC.ControllerTypeId = CMCTM.ControllerTypeId                
       JOIN                
       TCD.FieldGroup FG ON FG.ControllerModelId = CC.ControllerModelId                
        AND FG.ControllerTypeId = CC.ControllerTypeId                
        AND FG.TabId = 3                
       INNER JOIN                
       TCD.FieldGroupFieldMapping FGM ON FGM.FieldGroupId = FG.Id                
       INNER JOIN                
       TCD.Field F ON F.Id = FGM.FieldId                
      AND CSD.FieldId = f.Id                
      WHERE CC.ControllerId = @ControllerId                
    AND F.ResourceKey = 'No._of_Chemical_Valves'                
    AND CSD.EcolabAccountNumber = @EcoLabAccountNumber;                
    SELECT @MECount = ISNULL(CMCTM.MECount, 0)                
      FROM TCD.ConduitController CC                
       JOIN                
       TCD.ControllerModelControllerTypeMapping CMCTM ON CC.ControllerModelId = CMCTM.ControllerModelId                
             AND CC.ControllerTypeId = CMCTM.ControllerTypeId                
      WHERE CC.ControllerId = @ControllerId;                
    END;       
    ELSE IF(@ControllerModelId = 11)              
    BEGIN              
    SELECT @PumpValveCount = 2*CMCTM.PumpValveCount              
     , @MECount = 2*CMCTM.MECount              
      FROM TCD.ControllerModelControllerTypeMapping CMCTM              
      WHERE CMCTM.ControllerModelId = @ControllerModelId;              
    END;              
  ELSE IF(@ControllerModelId = 7 OR @ControllerModelId = 8 OR @ControllerModelId = 9 OR @ControllerModelId = 10  OR @ControllerModelId = 14)              
  BEGIN              
    SELECT @PumpValveCount = CMCTM.PumpValveCount          
 , @MECount = CMCTM.MECount          
  FROM TCD.ControllerModelControllerTypeMapping CMCTM          
  WHERE CMCTM.ControllerModelId = @ControllerModelId          
    AND CMCTM.ControllerTypeId = @ControllerTypeId;              
    END;              
    IF (SELECT ISNULL(@PumpValveCount, 0)                
    +                
    ISNULL(@MECount, 0)) = 0                
    BEGIN                
    SELECT                
    T.ControllerEquipmentId  AS   ControllerEquipmentId                
  , T.ControllerEquipmentTypeId  AS   ControllerEquipmentTypeId                
  , T.IsActive     AS   IsActive                
  , T.ProductId     AS   ProductId                
  , T.ProductName    AS   ProductName                
  , T.PumpCalibration    AS   PumpCalibration                
  , T.FlowMeterSwitchFlag   AS   FlowMeterSwitchFlag                
  , T.MaximumDosingTime   AS   MaximumDosingTime                
  , T.FlowSwitchTimeOut   AS   FlowSwitchTimeOut                
  , T.ControllerEquipmentSetupId AS   ControllerEquipmentSetupId                
  , @EcoLabAccountNumber   AS   EcoLabAccountNumber                
  , @ControllerId    AS   ControllerId                
  , CC.TopicName     AS   ControllerName                
  , CC.ControllerTypeId   AS   ControllerTypeId                
  , T.LfsChemicalName    AS   LfsChemicalName                
  , T.KFactor     AS   KFactor                
  , T.TunnelHold     AS   TunnelHold                
  , T.FlowDetectorType   AS   FlowDetectorType                
  , T.FlowSwitchAlarm    AS   FlowSwitchAlarm                
  , T.FlowMeterAlarm    AS   FlowMeterAlarm                
  , T.FlowMeterType    AS   FlowMeterType                
  , T.FlowAlarmDelay    AS   FlowAlarmDelay                
  , T.FlowMeterPumpDelay   AS   FlowMeterPumpDelay                
  , T.FlowMeterAlarmDelay   AS   FlowMeterAlarmDelay                
  , T.ControllerEquipmentTypeModelID                
  , T.ConventionalWasherGroupConnection                
  , T.AxillaryPumpCalibration                
  , T.FlowmeterSwitchActivated                
  , T.FlushWhileDosing                
  , T.WeightControlledDosage                
  , T.EquipmentDoseAlone                
  , T.LowLevelAlarm                
  , T.LeakageAlarm                
  , T.FlushTime                
  , T.PumpingTime                
  , T.PreFlushTime                
  , T.NightFlushPauseTime                
  , T.NightFlushTime                
  , T.AcceptedDeviation               
  , T.LineNumber               
  , T.DirectDosingFlag                
  , T.DirectDosingMachineInternalId                
  , T.DirectDosingTunnelCompartmentId           
  , T.WasherGroupTypeId                   
  , T.NumberOfCompartments                   
  , T.FlushValveNumber                    
  , T.CalibrationConductSS_Tank                 
  , T.BackFlowControl                     
  , T.FactorFM_B_FM                    
  , T.AcceptedDeviationRingLine                  
  , T.UsePumpOfGroup1ForTunnel    
  , T.pHSensorEnabled             
  , T.Concentration               
  , T.Deadband           
  , T.WasherGroupNumber           
  , T.ValveOutputAsTom          
  , T.FlowSwitchNumber         
  , T.FlushTimeForFlushValve    
   , T.MinimumFlowRate   
  , T.ProductDensity   
  , T.MaximumConcentration  
  , (                
    SELECT MTS.TagAddress                
      FROM TCD.ModuleTags MTS                
      WHERE MTS.TagType = @TagTypeLfs                
    AND MTS.ModuleID = ControllerEquipmentSetupId                
    AND MTS.ModuleTypeId = 4                
    AND MTS.Active = 1) AS LfsChemicalNameTag                
  , (       
    SELECT MTS.TagAddress                
      FROM TCD.ModuleTags MTS                
      WHERE MTS.TagType = @TagTypeKfactor                
    AND MTS.ModuleID = ControllerEquipmentSetupId                
    AND MTS.ModuleTypeId = 4                
    AND MTS.Active = 1) AS KfactorTag                
  , (                
    SELECT MTS.TagAddress                
      FROM TCD.ModuleTags MTS                
      WHERE MTS.TagType = @TagTypeCalibration                
    AND MTS.ModuleID = ControllerEquipmentSetupId                
    AND MTS.ModuleTypeId = 4                
    AND MTS.Active = 1) AS CalibrationTag                
  , T.LastModifiedTime  AS  LastModifiedTime                
  , T.LastSyncTime   AS  LastSyncTime                
      FROM #Equipment  T                
    JOIN                
    TCD.ConduitController CC                
    ON CC.ControllerId = @ControllerId                
      WHERE T.IsActive = ISNULL(@IsActive, T.IsActive)                
    AND T.ControllerEquipmentId = ISNULL(@ControllerEquipmentId, T.ControllerEquipmentId);                
    RETURN                
    @ReturnValue;             
    IF ISNULL(@PumpValveCount, 0) <> 0                
    BEGIN                
    WITH NumCTE (N)                
    AS(SELECT '*' AS N                
  UNION ALL                
       SELECT '*' AS N)                
    INSERT INTO #Equipment (ControllerEquipmentTypeId)                
    SELECT TOP (@PumpValveCount) @ControllerEquipmentTypeId_PumpValve                
      FROM NumCTE N1, NumCTE N2, NumCTE N3, NumCTE N4, NumCTE N5;                
    END;                
    IF ISNULL(@MECount, 0) <> 0                
    BEGIN                
    WITH NumCTE (N)                
    AS (SELECT '*' AS N                
    UNION ALL                
    SELECT '*' AS N)                
    INSERT INTO #Equipment(ControllerEquipmentTypeId)                
    SELECT TOP (@MECount)@ControllerEquipmentTypeId_ME                
      FROM NumCTE N1, NumCTE N2, NumCTE N3, NumCTE N4, NumCTE N5;                
    END;               
    END;           
    ELSE        
    BEGIN        
    IF ((SELECT ISNULL(@PumpValveCount, 0)                
    +                
    ISNULL(@MECount, 0)) = (SELECT COUNT(*) FROM TCD.ControllerEquipmentSetup CES     WHERE CES.ControllerId    = @ControllerId))        
      BEGIN        
      SET IDENTITY_INSERT #Equipment ON        
      INSERT INTO #Equipment (ControllerEquipmentId, ControllerEquipmentTypeId)           
      SELECT CES.ControllerEquipmentId, CES.ControllerEquipmentTypeId FROM TCD.ControllerEquipmentSetup CES WHERE CES.ControllerId = @ControllerId         
      SET IDENTITY_INSERT #Equipment OFF        
      END        
    END         
    UPDATE U                
  SET U.IsActive = CES.IsActive                
    , U.ProductId = CES.ProductId                
    , U.ProductName = (SELECT ISNULL(PM.EnvisionDisplayName, PM.Name)                
         FROM TCD.ProductMaster PM                
         WHERE PM.ProductId = CES.ProductId)                
    , U.PumpCalibration = CES.PumpCalibration                
    , U.FlowMeterSwitchFlag = CES.FlowMeterSwitchFlag                
    , U.MaximumDosingTime = CES.MaximumDosingTime                
    , U.FlowSwitchTimeOut = CES.FlowSwitchTimeOut                
    , U.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId                
    , U.LfsChemicalName = CES.LfsChemicalName                
    , U.KFactor = CES.KFactor                
    , U.TunnelHold = CES.TunnelHold                
    , U.FlowDetectorType = CES.FlowDetectorType                
    , U.FlowSwitchAlarm = CES.FlowSwitchAlarm                
    , U.FlowMeterAlarm = CES.FlowMeterAlarm                
    , U.FlowMeterType = CES.FlowMeterType                
    , U.FlowAlarmDelay = CES.FlowAlarmDelay                
    , U.FlowMeterPumpDelay = CES.FlowMeterPumpDelay                
    , U.FlowMeterAlarmDelay = CES.FlowMeterAlarmDelay                
    , U.ControllerEquipmentTypeModelID = CES.ControllerEquipmentTypeModelID                
    , U.ConventionalWasherGroupConnection = CES.ConventionalWasherGroupConnection                
    , U.AxillaryPumpCalibration = CES.AxillaryPumpCalibration                
    , U.FlowmeterSwitchActivated = CES.FlowmeterSwitchActivated                
    , U.FlushWhileDosing = CES.FlushWhileDosing                
    , U.WeightControlledDosage = CES.WeightControlledDosage                
    , U.EquipmentDoseAlone = CES.EquipmentDoseAlone                
    , U.LowLevelAlarm = CES.LowLevelAlarm                
    , U.LeakageAlarm = CES.LeakageAlarm                
    , U.FlushTime = CES.FlushTime                
    , U.PumpingTime = CES.PumpingTime                
    , U.PreFlushTime = CES.PreFlushTime                
    , U.NightFlushPauseTime = CES.NightFlushPauseTime                
    , U.NightFlushTime = CES.NightFlushTime                
    , U.AcceptedDeviation = CES.AcceptedDeviation               
    , U.LineNumber = CES.LineNumber               
    , U.DirectDosingFlag = TCEVM.DirectDosingFlag                
    , U.DirectDosingMachineInternalId = TCEVM.TunnelNumber                
    , U.DirectDosingTunnelCompartmentId = TCEVM.CompartmentNumber              
    , U.LastModifiedTime = CES.LastModifiedTime                
    , U.LastSyncTime = CES.LastSyncTime              
    , U.FlushValveNumber      = CES.FlushValveNumber              
  , U.CalibrationConductSS_Tank    = CES.CalibrationConductSS_Tank            
  , U.BackFlowControl     = CES.BackFlowControl                
  , U.FactorFM_B_FM       = CES.FactorFM_B_FM             
  , U.AcceptedDeviationRingLine  = CES.AcceptedDeviationRingLine                
  , U.UsePumpOfGroup1ForTunnel   = CES.UsePumpOfGroup1ForTunnel            
  , U.pHSensorEnabled            = CES.pHSensorEnabled            
  , U.Concentration = CES.Concentration            
  , U.Deadband = CES.Deadband           
  , U.WasherGroupNumber = CES.WasherGroupNumber        
  , U.ValveOutputAsTom = CES.ValveOutputAsTom        
  , U.FlowSwitchNumber = CES.FlowSwitchNumber       
  , U.FlushTimeForFlushValve = CES.FlushTimeForFlushValve    
    , U.MinimumFlowRate = CES.MinimumFlowRate  
  , U.ProductDensity = CES.ProductDensity  
  , U.MaximumConcentration  = CES.MaximumConcentration   
  FROM #Equipment U                
   JOIN                
   TCD.ControllerEquipmentSetup CES                
  ON U.ControllerEquipmentId = CES.ControllerEquipmentId                
  AND U.ControllerEquipmentTypeId = CES.ControllerEquipmentTypeId             
  JOIN TCD.ConduitController CC ON CES.ControllerID = CC.ControllerId              
  LEFT JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId              
  LEFT JOIN TCD.WasherGroup WG ON CES.ControllerID = WG.ControllerID               
  LEFT JOIN TCD.MachineSetup MS ON WG.ControllerId = MS.ControllerId        
  WHERE CES.EcoLabAccountNumber = @EcoLabAccountNumber                
   AND CES.ControllerId = @ControllerId;             
   IF(@ControllerModelId = 11)              
   BEGIN          
   UPDATE U           
   SET U.WasherGroupTypeId = (SELECT MIN(WG.WasherGroupTypeId) FROM TCD.WasherGroup WG WHERE WG.ControllerId = @ControllerId)          
    FROM #Equipment U                
JOIN                
   TCD.ControllerEquipmentSetup CES                
  ON U.ControllerEquipmentId = CES.ControllerEquipmentId                
  AND U.ControllerEquipmentTypeId = CES.ControllerEquipmentTypeId              
  WHERE CES.EcoLabAccountNumber = @EcoLabAccountNumber                
   AND CES.ControllerId = @ControllerId          
   AND CES.ControllerEquipmentId IN (select top 14 CES.ControllerEquipmentId FROM  TCD.ControllerEquipmentSetup CES          
   where CES.ControllerId = @ControllerId )          
            
     UPDATE U           
   SET U.WasherGroupTypeId = (SELECT MAX(WG.WasherGroupTypeId) FROM TCD.WasherGroup WG WHERE WG.ControllerId = @ControllerId)          
    FROM #Equipment U                
   JOIN                
   TCD.ControllerEquipmentSetup CES                
  ON U.ControllerEquipmentId = CES.ControllerEquipmentId                
  AND U.ControllerEquipmentTypeId = CES.ControllerEquipmentTypeId             
  JOIN TCD.ConduitController CC ON CES.ControllerID = CC.ControllerId       
  WHERE CES.EcoLabAccountNumber = @EcoLabAccountNumber                
   AND CES.ControllerId = @ControllerId          
   AND CES.ControllerEquipmentId IN (select  CES.ControllerEquipmentId FROM TCD.ControllerEquipmentSetup CES          
    where CES.ControllerId = @ControllerId AND           
    CES.ControllerEquipmentId BETWEEN 15 AND 28 )      
         
   UPDATE U SET U.NumberOfCompartments = ms.NumberOfComp      
   FROM #Equipment U      
   INNER JOIN TCD.ControllerEquipmentSetup ces      
   ON u.ControllerEquipmentId = ces.ControllerEquipmentId       
   INNER JOIN TCD.WasherGroup wg ON ces.ControllerId = WG.ControllerId      
   INNER JOIN TCD.MachineSetup ms ON ms.ControllerId = ces.ControllerId AND ms.GroupId = WG.WasherGroupId      
   WHERE ces.ControllerId = @ControllerId AND U.WasherGroupTypeId = 2  AND ms.IsTunnel = 1 AND WG.WasherDosingNumber = U.WasherGroupNumber      
   END        
           
  -- END              
    GOTO ExitModule;                
    ExitModule:                
    SELECT                
    T.ControllerEquipmentId   AS ControllerEquipmentId                
  , T.ControllerEquipmentTypeId AS ControllerEquipmentTypeId                
  , T.IsActive      AS IsActive                
  , T.ProductId     AS ProductId                
  , T.ProductName     AS ProductName                
  , T.PumpCalibration    AS PumpCalibration                
  , T.FlowMeterSwitchFlag   AS FlowMeterSwitchFlag                
  , T.MaximumDosingTime    AS MaximumDosingTime                
  , T.FlowSwitchTimeOut    AS FlowSwitchTimeOut                
  , T.ControllerEquipmentSetupId  AS ControllerEquipmentSetupId                
  , @EcoLabAccountNumber    AS EcoLabAccountNumber                
  , @ControllerId     AS ControllerId                
  , CC.TopicName     AS ControllerName                
  , CC.ControllerTypeId    AS ControllerTypeId                
  , T.LfsChemicalName    AS LfsChemicalName                
  , T.KFactor      AS KFactor                
  , T.TunnelHold     AS TunnelHold                
  , T.FlowDetectorType    AS FlowDetectorType                
  , T.FlowSwitchAlarm    AS FlowSwitchAlarm                
  , T.FlowMeterAlarm    AS FlowMeterAlarm                
  , T.FlowMeterType     AS FlowMeterType                
 , T.FlowAlarmDelay    AS FlowAlarmDelay                
  , T.FlowMeterPumpDelay    AS FlowMeterPumpDelay                
  , T.FlowMeterAlarmDelay   AS FlowMeterAlarmDelay                
  , (                
    SELECT MTS.TagAddress                
  FROM TCD.ModuleTags MTS                
  WHERE MTS.TagType = @TagTypeLfs                
    AND MTS.ModuleID = ControllerEquipmentSetupId                
    AND MTS.ModuleTypeId = 4                
    AND MTS.Active = 1) AS LfsChemicalNameTag                
  , (                
    SELECT MTS.TagAddress                
  FROM TCD.ModuleTags MTS                
  WHERE MTS.TagType = @TagTypeKfactor                
    AND MTS.ModuleID = ControllerEquipmentSetupId                
    AND MTS.ModuleTypeId = 4                
    AND MTS.Active = 1) AS KfactorTag                
  , (                
    SELECT MTS.TagAddress                
  FROM TCD.ModuleTags MTS                
  WHERE MTS.TagType = @TagTypeCalibration                
    AND MTS.ModuleID = ControllerEquipmentSetupId                
    AND MTS.ModuleTypeId = 4                
    AND MTS.Active = 1) AS CalibrationTag                
  , T.ControllerEquipmentTypeModelID                
  , T.ConventionalWasherGroupConnection                
  , T.AxillaryPumpCalibration                
  , T.FlowmeterSwitchActivated                
  , T.FlushWhileDosing                
  , T.WeightControlledDosage                
  , T.EquipmentDoseAlone                
  , T.LowLevelAlarm                
  , T.LeakageAlarm                
  , T.FlushTime                
  , T.PumpingTime                
  , T.PreFlushTime                
  , T.NightFlushPauseTime                
  , T.NightFlushTime                
  , T.AcceptedDeviation                
  , T.LineNumber              
  , T.DirectDosingFlag                
  , T.DirectDosingMachineInternalId                
  , T.DirectDosingTunnelCompartmentId                
  , T.LastModifiedTime    AS LastModifiedTime                
  , T.LastSyncTime     AS LastSyncTime           
  , T.WasherGroupTypeId                   
  , T.NumberOfCompartments                   
  , T.FlushValveNumber                    
  , T.CalibrationConductSS_Tank                 
  , T.BackFlowControl                     
  , T.FactorFM_B_FM                    
  , T.AcceptedDeviationRingLine                  
  , T.UsePumpOfGroup1ForTunnel                  
  , T.pHSensorEnabled              
  , T.Concentration            
  , T.Deadband            
  , T.WasherGroupNumber        
  , T.ValveOutputAsTom        
  , T.FlowSwitchNumber        
  , T.FlushTimeForFlushValve    
    , T.MinimumFlowRate   
  , T.ProductDensity   
  , T.MaximumConcentration  
  FROM #Equipment T                
   JOIN                
   TCD.ConduitController CC ON CC.ControllerId = @ControllerId                
  WHERE T.IsActive = ISNULL(@IsActive, T.IsActive)                
   AND T.ControllerEquipmentId = ISNULL(@ControllerEquipmentId, T.ControllerEquipmentId)      
   ORDER BY  T.ControllerEquipmentId;                
    SET NOCOUNT OFF;                
    RETURN                
    @ReturnValue;                
END; 


/*
End TCD.GetControllerEquipmentList

*/

GO

/*
Start TCD.UpdateTunnel

*/
IF OBJECT_ID('[TCD].[UpdateTunnel]') is not null
BEGIN
	DROP PROC [TCD].[UpdateTunnel]

END

GO

/*	
Purpose					:	To edit details of a new Tunnel from the Washer-Tunnel (General) setup screen

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version

*/

CREATE	PROCEDURE    [TCD].[UpdateTunnel]
                    @EcoLabAccountNumber                    NVARCHAR(1000)
                ,    @WasherId                                INT
                ,    @WasherGroupId                            INT                                    --Not updated, for reference only
                ,    @TunnelName                            NVARCHAR(50)
                ,    @WasherModelName                        NVARCHAR(50)
                ,    @RegionId                                SMALLINT
                --,    @Size                                INT
                ,    @ControllerId                            INT
                ,    @LFSWasherNumber                        INT            =            1        --For tunnels, it will be 1 until a diff. number is passed (as per the scenario)
                ,    @PlantWasherNumber                        SMALLINT
                ,    @WasherMode                            SMALLINT
                ,    @MaxLoad                                SMALLINT
                ,    @AWEActive                            BIT
                ,    @NumberOfTanks                            TINYINT
                ,    @NumberOfComp                            INT                                --though this is INT in the table, we should not require it to be so
                ,    @TransferType                            TINYINT
                ,    @PressExtractor                        TINYINT
                ,    @ProgramNumber                            TINYINT
                ,    @EndOfFormula                            TINYINT
                ,    @Description                            NVARCHAR(1024)    =            NULL
                ,    @UserId                                INT
                --Adding these 3 params as part of re-factoring for integration with Synch/Configurator
                ,    @OutputTunnelId                        INT            =            NULL    OUTPUT
                ,    @LastModifiedTimestampAtCentral            DATETIME    =            NULL            --Nullable for local call; Synch/Central call will have to pass this -
                                                                                                    --else, it will be treated as a local call
                ,    @OutputLastModifiedTimestampAtLocal        DATETIME    =            NULL    OUTPUT
                ,   @RatioDosingActive                        BIT
                ,   @ControllerModelId                        INT        =        NULL
                ,   @NumberOfCompartmentsConveyorBelt            TINYINT    =        NULL
                ,   @MaxMachineLoad                            SMALLINT    =        NULL
                ,   @MinMachineLoad                            SMALLINT    =        NULL
                ,   @ProgramSelectionByTime                    BIT          =        NULL
                ,   @WeightSelectionByTime                    BIT          =        NULL
                ,   @WeightSelectionByAnalogInput                BIT          =        NULL
                ,   @TunInTomMode                            BIT          =        NULL
                ,   @SignalStopTunActive                        BIT          =        NULL
                ,   @SignalEjectionTunActive                      BIT          =        NULL
                ,   @DelayTimeForTunWashingPrograms            BIT          =        NULL
                ,   @KannegiesserPressSpecialMode                BIT          =        NULL
                ,   @ValveOutputsUsedAsTomSignal                BIT          =        NULL
                ,   @ExtendedClockOrDataProtocol                BIT          =        NULL
                ,   @WeightCorrectionFcc                        BIT          =        NULL
				,	@DateAndTimeWhenBatchEjects					BIT	  		=		NULL
				,	@AutoRinseDesamixAfter						SMALLINT	=		NULL
				,	@AutoRinseDesamix1For						SMALLINT	=		NULL
				,	@AutoRinseDesamix2For						SMALLINT	=		NULL
				,	@TemperatureAlarmProbe1						BIT			=		NULL
				,	@TemperatureAlarmProbe2						BIT			=		NULL
				,	@TemperatureAlarmProbe3						BIT			=		NULL
				,	@UseMe1OfGroup							tinyint					=	NULL
				,	@UseMe2OfGroup							tinyint					=	NULL
AS
BEGIN

SET    NOCOUNT    ON


DECLARE    
        @ReturnValue                    INT                =            0
    ,    @ErrorId                        INT                =            0
    ,    @ErrorMessage                    NVARCHAR(4000)    =            N''

    ,    @WasherModelId                    SMALLINT        =            NULL

    ,    @CurrentUTCTime                    DATETIME        =            GETUTCDATE()
	,	@ControllerValidate				int				=										   0

--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
SET        @OutputLastModifiedTimestampAtLocal                =            @CurrentUTCTime
SET        @OutputTunnelId                                    =            ISNULL(@OutputTunnelId, NULL)            --SQLEnlight

--If the call is not local, check that the LastModifiedTime matches with the central
IF    (
        @LastModifiedTimestampAtCentral            IS NOT    NULL
    AND    NOT    EXISTS    (    SELECT    1
                        FROM    TCD.[Washer]            W
                        WHERE    W.EcolabAccountNumber    =    @EcolabAccountNumber
                            AND    W.WasherId                =    @WasherId
                            AND    W.LastModifiedTime        =    @LastModifiedTimestampAtCentral
                    )
    )
    BEGIN
            SET            @ErrorId                    =    60000
            SET            @ErrorMessage                =    N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
            RAISERROR    (@ErrorMessage, 16, 1)
            SET            @ReturnValue                =    -1
            RETURN        (@ReturnValue)
    END

--Proceed, since it's either a local call or Synch. call with synch. time matching


--Valid Washer - based on Id...
IF    NOT    EXISTS    (    SELECT    1
                    FROM    [TCD].Washer                W
                    JOIN    [TCD].MachineSetup            MS
                        ON    W.WasherId                    =            MS.WasherId
                        AND    W.EcoLabAccountNumber        =            MS.EcoalabAccountNumber
                    WHERE    W.EcoLabAccountNumber        =            @EcoLabAccountNumber
                        AND    W.WasherId                    =            @WasherId
                        AND    MS.GroupId                    =            @WasherGroupId
                        AND    MS.IsTunnel                    =            'TRUE'
                        AND    W.Is_Deleted                =            'FALSE'
                        AND    MS.IsDeleted                =            'FALSE'
                )
            BEGIN
                SET        @ErrorId                        =            51006
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Washer-ID was provided for Updating.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET    @ReturnValue    =    -1
                RETURN    (@ReturnValue)
            END


--Check for uniqueness of PlantWasherNo. and Name
IF    EXISTS        (    SELECT    1
                    FROM    [TCD].Washer                W
                    JOIN    [TCD].MachineSetup            MS
                        ON    W.WasherId                    =            MS.WasherId
                        AND    W.EcoLabAccountNumber        =            MS.EcoalabAccountNumber
                    WHERE    W.EcoLabAccountNumber        =            @EcoLabAccountNumber
                        AND    W.WasherId                    <>            @WasherId
                        AND    (
                            W.PlantWasherNumber            =            @PlantWasherNumber
                            OR
                            MS.MachineName                =            @TunnelName
                            )
                        AND    W.Is_Deleted                =            'FALSE'
                        AND    MS.IsDeleted                =            'FALSE'
                )
            BEGIN
                SET        @ErrorId                        =            51002
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Specified Plant Washer #/Name already exists.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET    @ReturnValue    =    -1
                RETURN    (@ReturnValue)
            END


--Check that it's a valid Controller type/model (one that can control a Tunnel)
--EXEC @ControllerValidate = [TCD].[ValidateController] 2,@ControllerId,@EcoLabAccountNumber

--IF  (  @ControllerValidate = 1)
--            BEGIN
--                SET        @ErrorId                        =            51003
--                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller was provided.'
--                --GOTO    ErrorHandler
--                RAISERROR    (@ErrorMessage, 16, 1)
--                SET    @ReturnValue    =    -1
--                RETURN    (@ReturnValue)
--            END


--EOF should not be an asocciated formula for the WG...
IF    EXISTS        (    SELECT    1
                    FROM    [TCD].TunnelProgramSetup    TPS
                    WHERE    TPS.EcolabAccountNumber        =            @EcoLabAccountNumber
                        AND    TPS.WasherGroupId            =            @WasherGroupId
                        AND    TPS.ProgramNumber            =            @ProgramNumber
                        AND    TPS.Is_Deleted                =            'FALSE'
                )
            BEGIN
                SET        @ErrorId                        =            51004
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An assoicated formula cannot be specified as End-Of-Formula.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET    @ReturnValue    =    -1
                RETURN    (@ReturnValue)
            END


--WasherMode check
IF    NOT    EXISTS    (    SELECT    1
                    FROM    [TCD].ControllerModelControllerTypeMapping
                                                        CMCTM
                    JOIN    [TCD].ConduitController        CC
                        ON    CC.ControllerTypeId            =            CMCTM.ControllerTypeId
                        AND    CC.ControllerModelId        =            CMCTM.ControllerModelId
                    JOIN    [TCD].[WasherModeMapping]
                                                        CTM2WM
                        ON    CMCTM.Id                    =            CTM2WM.ControllerModelControllerTypeMappingId
                    WHERE    CC.EcoalabAccountNumber        =            @EcoLabAccountNumber
                        AND    CC.ControllerId                =            @ControllerId
                        AND    CC.IsDeleted                =            'FALSE'
                        --AND    CMCTM.CanControlTunnel        =            'TRUE'
                        AND    CTM2WM.WasherModeId            =            @WasherMode
                )
            BEGIN
                SET        @ErrorId                        =            51005
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherMode was provided.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET    @ReturnValue    =    -1
                RETURN    (@ReturnValue)
            END


--select the WasherModelId based on name
SELECT    TOP    1
        @WasherModelId                        =            WMS.WasherModelId
FROM    [TCD].WasherModelSize                WMS
WHERE    WMS.RegionId                        =            @RegionId
    AND    WMS.WasherModelName                    =            @WasherModelName
    AND    WMS.ModelTypeId                    =            2                            --TypeId 2 for Tunnel
    AND    WMS.Is_Deleted                        =            'FALSE'

--LFSWasherNumber duplicate check...
IF    EXISTS    (    SELECT    1
                FROM    [TCD].MachineSetup                    MS
                WHERE    MS.ControllerId                    =            @ControllerId
                    AND    MS.MachineInternalId            =            @LFSWasherNumber
                    AND    MS.IsDeleted                    =            'FALSE'
                    AND    MS.WasherId                        <>            @WasherId
                    AND MS.EcoalabAccountNumber            =            @EcoLabAccountNumber
                    AND MS.IsTunnel                        =            'TRUE'
            )
            BEGIN
                SET        @ErrorId                        =            51010
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate LFSWasher# provided.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET        @ReturnValue    =    -1
                RETURN    (@ReturnValue)
            END

--Now attempt Update...
BEGIN    TRAN

UPDATE    MS
    SET    MS.MachineName                    =            @TunnelName
    ,    MS.ControllerId                =            @ControllerId
    ,    MS.MachineInternalId            =            @LFSWasherNumber
    ,    MS.NumberOfComp                =            @NumberOfComp
    ,    MS.LastModifiedByUserId            =            @UserId
FROM    [TCD].MachineSetup                MS
JOIN    [TCD].Washer                    W
    ON    MS.WasherId                    =            W.WasherId
    AND    MS.EcoalabAccountNumber            =            W.EcolabAccountNumber
WHERE    MS.WasherId                    =            @WasherId
    AND    MS.EcoalabAccountNumber            =            @EcoLabAccountNumber
    AND    MS.IsDeleted                    =            'FALSE'
    AND    W.Is_Deleted                    =            'FALSE'

--check for any error
SET    @ErrorId    =    @@ERROR

IF    (@ErrorId    <>    0)
BEGIN

        IF    @@TRANCOUNT    >    0
        BEGIN
            ROLLBACK    TRAN
        END
    
    SET        @ErrorMessage                =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating washer data.'
    --GOTO    Errorhandler
    RAISERROR    (@ErrorMessage, 16, 1)
    SET    @ReturnValue    =    -1
    RETURN    (@ReturnValue)
END

--else, continue with the rest of the update in the other table...
IF(@ControllerModelId IS NOT NULL AND @ControllerModelId = 7 )
BEGIN
UPDATE    W
    SET    W.ModelId                        =            @WasherModelId
    ,    W.PlantWasherNumber                =            @PlantWasherNumber
    ,    W.WasherMode                    =            @WasherMode
    ,    W.MaxLoad                        =            @MaxLoad
    ,    W.AWEActive                    =            'FALSE'
    ,    W.NumberOfTanks                =            @NumberOfTanks
    ,    W.TransferType                    =            @TransferType
    ,    W.PressExtractor                =            @PressExtractor
    ,    W.EmptyPocketNumber                =            @ProgramNumber
    ,    W.[Description]                =            @Description
    ,    W.LastModifiedByUserId            =            @UserId
    ,    W.LastModifiedTime                =            @CurrentUTCTime
    ,    W.RatioDosingActive                =              NULL    
    ,    W.EndOfFormula                    =            0
    ,    W.NumberOfCompartmentsConveyorBelt     =            @NumberOfCompartmentsConveyorBelt
    ,    W.MinMachineLoad                 =            @MinMachineLoad
    ,    W.MaxMachineLoad                 =            @MaxMachineLoad
    ,    W.ProgramSelectionByTime             =            @ProgramSelectionByTime
    ,    W.WeightSelectionByTime             =            @WeightSelectionByTime
    ,    W.WeightSelectionByAnalogInput     =            @WeightSelectionByAnalogInput
    ,    W.TunInTomMode                     =            @TunInTomMode
    ,    W.SignalStopTunActive             =            @SignalStopTunActive
    ,    W.SignalEjectionTunActive         =            @SignalEjectionTunActive
    ,    W.DelayTimeForTunWashingPrograms     =            @DelayTimeForTunWashingPrograms
    ,    W.KannegiesserPressSpecialMode     =            @KannegiesserPressSpecialMode
    ,    W.ValveOutputsUsedAsTomSignal         =            @ValveOutputsUsedAsTomSignal
    ,    W.ExtendedClockOrDataProtocol         =            @ExtendedClockOrDataProtocol
    ,    W.WeightCorrectionFcc             =            @WeightCorrectionFcc
FROM    [TCD].Washer                    W
JOIN    [TCD].MachineSetup                MS
    ON    W.WasherId                    =            MS.WasherId
    AND    W.EcoLabAccountNumber            =            MS.EcoalabAccountNumber
WHERE    W.WasherId                    =            @WasherId
    AND    W.EcoLabAccountNumber            =            @EcoLabAccountNumber
    AND    W.Is_Deleted                    =            'FALSE'
    AND    MS.IsDeleted                    =            'FALSE'
END
ELSE IF(@ControllerModelId IS NOT NULL AND ( @ControllerModelId = 8	OR @ControllerModelId = 9	OR @ControllerModelId = 10 OR @ControllerModelId = 11 OR @ControllerModelId = 14))
BEGIN
UPDATE    W
    SET    W.ModelId                        =            @WasherModelId
    ,    W.PlantWasherNumber                =            @PlantWasherNumber
    ,    W.WasherMode                    =            @WasherMode
    ,    W.MaxLoad                        =            @MaxLoad
    ,    W.AWEActive                    =            'FALSE'
    ,    W.NumberOfTanks                =            @NumberOfTanks
    ,    W.TransferType                    =            @TransferType
    ,    W.PressExtractor                =            @PressExtractor
    ,    W.EmptyPocketNumber                =            @ProgramNumber
    ,    W.[Description]                =            @Description
    ,    W.LastModifiedByUserId            =            @UserId
    ,    W.LastModifiedTime                =            @CurrentUTCTime
    ,    W.RatioDosingActive                =              NULL    
    ,    W.EndOfFormula                    =            0
    ,    W.NumberOfCompartmentsConveyorBelt     =            @NumberOfCompartmentsConveyorBelt
    ,    W.MinMachineLoad                 =            @MinMachineLoad
    ,    W.MaxMachineLoad                 =            @MaxMachineLoad
    ,    W.TunInTomMode                     =            @TunInTomMode
    ,    W.DelayTimeForTunWashingPrograms     =            @DelayTimeForTunWashingPrograms
    ,    W.KannegiesserPressSpecialMode     =            @KannegiesserPressSpecialMode
    ,    W.WeightCorrectionFcc             =            @WeightCorrectionFcc
	,	 W.DateAndTimeWhenBatchEjects		=			@DateAndTimeWhenBatchEjects
	,	 W.AutoRinseDesamixAfter			=			@AutoRinseDesamixAfter
	,	 W.AutoRinseDesamix1For				=			@AutoRinseDesamix1For
	,	 W.AutoRinseDesamix2For				=			@AutoRinseDesamix2For
	,	 W.TemperatureAlarmProbe1			=			@TemperatureAlarmProbe1
	,	 W.TemperatureAlarmProbe2			=			@TemperatureAlarmProbe2
	,	 W.TemperatureAlarmProbe3			=			@TemperatureAlarmProbe3
	,	 W.UseMe1OfGroup					=			@UseMe1OfGroup
	,	 W.UseMe2OfGroup					=			@UseMe2OfGroup

FROM    [TCD].Washer                    W
JOIN    [TCD].MachineSetup                MS
    ON    W.WasherId                    =            MS.WasherId
    AND    W.EcoLabAccountNumber            =            MS.EcoalabAccountNumber
WHERE    W.WasherId                    =            @WasherId
    AND    W.EcoLabAccountNumber            =            @EcoLabAccountNumber
    AND    W.Is_Deleted                    =            'FALSE'
    AND    MS.IsDeleted                    =            'FALSE'
END
ELSE
BEGIN
UPDATE    W
    SET    W.ModelId                        =            @WasherModelId
    ,    W.PlantWasherNumber                =            @PlantWasherNumber
    ,    W.WasherMode                    =            @WasherMode
    ,    W.MaxLoad                        =            @MaxLoad
    ,    W.AWEActive                    =            @AWEActive
    ,    W.NumberOfTanks                =            @NumberOfTanks
    ,    W.TransferType                    =            @TransferType
    ,    W.PressExtractor                =            @PressExtractor
    ,    W.EmptyPocketNumber                =            @ProgramNumber
    ,    W.[Description]                =            @Description
    ,    W.LastModifiedByUserId            =            @UserId
    ,    W.LastModifiedTime                =            @CurrentUTCTime
    ,   W.RatioDosingActive                =              @RatioDosingActive    
    ,   W.EndOfFormula                    =            @EndOfFormula
    ,    W.LfsWasher                     =            NULL
    ,    W.NumberOfCompartmentsConveyorBelt     =            NULL
    ,    W.MinMachineLoad                 =            NULL
    ,    W.MaxMachineLoad                 =            NULL
    ,    W.ProgramSelectionByTime             =            NULL
    ,    W.WeightSelectionByTime             =            NULL
    ,    W.WeightSelectionByAnalogInput     =            NULL
    ,    W.TunInTomMode                     =            NULL
    ,    W.SignalStopTunActive             =            NULL
    ,    W.SignalEjectionTunActive         =            NULL
    ,    W.DelayTimeForTunWashingPrograms     =            NULL
    ,    W.KannegiesserPressSpecialMode     =            NULL
    ,    W.ValveOutputsUsedAsTomSignal         =            NULL
    ,    W.ExtendedClockOrDataProtocol         =            NULL
    ,    W.WeightCorrectionFcc             =            NULL
FROM    [TCD].Washer                    W
JOIN    [TCD].MachineSetup                MS
    ON    W.WasherId                    =            MS.WasherId
    AND    W.EcoLabAccountNumber            =            MS.EcoalabAccountNumber
WHERE    W.WasherId                    =            @WasherId
    AND    W.EcoLabAccountNumber            =            @EcoLabAccountNumber
    AND    W.Is_Deleted                    =            'FALSE'
    AND    MS.IsDeleted                    =            'FALSE'
END
--check for error, if none - commit the tran, else rollback
SET    @ErrorId    =    @@ERROR
IF    (@ErrorId    <>    0)
    BEGIN
        IF    (@@TRANCOUNT    >    0)
            BEGIN
                ROLLBACK
            END

        SET        @ErrorMessage                =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating washer data.'
        --GOTO    Errorhandler
        RAISERROR    (@ErrorMessage, 16, 1)
        SET    @ReturnValue    =    -1
        RETURN    (@ReturnValue)
    END
ELSE
    BEGIN
        IF    (@@TRANCOUNT    >    0)
            BEGIN
                COMMIT
            END

        SET    @OutputTunnelId    =    @WasherId
    END


--IF    (@ErrorId    =    0)
--    BEGIN
--        --GOTO    ExitModule
--        RETURN    (@ReturnValue)
--    END




--ErrorHandler:
--RAISERROR    (@ErrorMessage, 16, 1)
--SET    @ReturnValue    =    -1




--ExitModule:

SET    NOCOUNT    OFF
RETURN    (@ReturnValue)


END


/*
End TCD.UpdateTunnel

*/

/*
Start TCD.WasherFlushTimeTrigger

*/

GO
IF OBJECT_ID('[TCD].[WasherFlushTimeTrigger]') is not null
BEGIN
	DROP trigger [TCD].[WasherFlushTimeTrigger]
	
END

GO
/*                                           
###################################################################################################                                           

Trigger		:		WasherFlushTimeTrigger

Purpose		:		Trigger	for auditing changes on WasherFlushTime table

Parameter	:		NA

###################################################################################################                                           
*/


CREATE TRIGGER [TCD].[WasherFlushTimeTrigger]
	ON [TCD].[WasherFlushTime]
	FOR UPDATE, INSERT
	AS
	BEGIN
		SET NOCOUNT ON
		DECLARE	@AuditOperation_SQLInsertId			TINYINT				=			NULL
	,	@AuditOperation_SQLUpdateId			TINYINT				=			NULL
	,	@AuditOperation_AppDeleteId			TINYINT				=			NULL
	,	@ErrorNumber						INT					=			0
	,	@ErrorMessage						NVARCHAR(2048)		=			NULL
	,	@ErrorSeverity						INT					=			NULL
	,	@ErrorProcedure						SYSNAME				=			NULL
	,	@MessageString						NVARCHAR(2500)		=			NULL
	,	@SoftDeleteFlag						BIT					=			NULL			--0 for FALSE/1 for TRUE
	,	@CurrentTimeStamp					DATETIME			=			GETUTCDATE()	--CURRENT_TIMESTAMP

--select	*	from	AuditOperation
SELECT	@AuditOperation_SQLInsertId			=			AO.OperationId
FROM	[TCD].AuditOperation					AO
WHERE	AO.OperationCode					=			'SQLInsert'

SELECT	@AuditOperation_SQLUpdateId			=			AO.OperationId
FROM	[TCD].AuditOperation					AO
WHERE	AO.OperationCode					=			'SQLUpdate'

SELECT	@AuditOperation_AppDeleteId			=			AO.OperationId
FROM	[TCD].AuditOperation					AO
WHERE	AO.OperationCode					=			'AppDelete'

IF	NOT	EXISTS	(SELECT	1	FROM	[deleted])
	BEGIN

			BEGIN	TRY

					INSERT	[TCD].WasherFlushTimeHistory(
							WasherId,				OperationTimestamp,			OperationId,			OperationByUserId,		PlantId,
							LineNumber,				WasherFlushTypeId,			FlushTime,				Is_Deleted,				LastModifiedByUserId,
							LastModifiedTime,		LastSyncTime )

					SELECT	WasherId,			@CurrentTimeStamp,		@AuditOperation_SQLInsertId,		LastModifiedByUserId,		PlantId,
							LineNumber,			WasherFlushTypeId,		FlushTime,							Is_Deleted,					LastModifiedByUserId,
							LastModifiedTime,	LastSyncTime

					FROM	[inserted]
					END	TRY
			BEGIN	CATCH

					SELECT	@ErrorNumber				=			ERROR_NUMBER()
						,	@ErrorMessage				=			ERROR_MESSAGE()
						,	@ErrorProcedure				=			ERROR_PROCEDURE()
						,	@ErrorSeverity				=			ERROR_SEVERITY()

					--GOTO	ErrorHandler
					SET		@MessageString				=	N'An error occured while updating Audit data for WasherFlushTime table. The error is: '
														+	@ErrorMessage + '	'
														+	'Module: ' + @ErrorProcedure
					RAISERROR(@MessageString, @ErrorSeverity, 1)
					RETURN

			END	CATCH
	END

ELSE	IF	EXISTS	(SELECT	1	FROM	[inserted])
	BEGIN
			IF	UPDATE(Is_Deleted)
				SET	@SoftDeleteFlag	=	'TRUE'
			ELSE
				SET	@SoftDeleteFlag	=	'FALSE'

			BEGIN
					BEGIN	TRY

							INSERT	[TCD].WasherFlushTimeHistory(
							WasherId,				OperationTimestamp,		OperationId,			OperationByUserId,		PlantId,				LineNumber,
							WasherFlushTypeId,		FlushTime,				Is_Deleted,				LastModifiedByUserId,	LastModifiedTime,		LastSyncTime )

					SELECT	WasherId,			@CurrentTimeStamp,		@AuditOperation_SQLUpdateId,		LastModifiedByUserId,		PlantId,
							LineNumber,			WasherFlushTypeId,		FlushTime,							Is_Deleted,					LastModifiedByUserId,
							LastModifiedTime,	LastSyncTime

					FROM	[inserted]

					END	TRY
					BEGIN	CATCH

							SELECT	@ErrorNumber				=			ERROR_NUMBER()
								,	@ErrorMessage				=			ERROR_MESSAGE()
								,	@ErrorProcedure				=			ERROR_PROCEDURE()
								,	@ErrorSeverity				=			ERROR_SEVERITY()

							--GOTO	ErrorHandler
							SET		@MessageString				=	N'An error occured while updating Audit data for WasherFlushTime table. The error is: '
																+	@ErrorMessage + '	'
																+	'Module: ' + @ErrorProcedure
							RAISERROR(@MessageString, @ErrorSeverity, 1)
							RETURN

					END	CATCH
			END
	END


IF	@ErrorNumber	=	0
	--GOTO	ExitModule
	RETURN
		


ErrorHandler:

SET		@MessageString						=	N'An error occured while updating Audit data for WasherFlushTime table. The error is: '
											+	@ErrorMessage + '	'
											+	'Module: ' + @ErrorProcedure
RAISERROR(@MessageString, @ErrorSeverity, 1)



ExitModule:

SET	NOCOUNT	OFF

RETURN


END
/*
End TCD.[WasherFlushTimeTrigger]

*/

/*
Start TCD.GetControllerSetupAdvanceMetaDataWithValues

*/

GO
IF OBJECT_ID('[TCD].[GetControllerSetupAdvanceMetaDataWithValues]') is not null
BEGIN
	DROP proc [TCD].GetControllerSetupAdvanceMetaDataWithValues
	
END

GO

CREATE PROCEDURE [TCD].[GetControllerSetupAdvanceMetaDataWithValues]
(
		@TabId INT
	,	@ControllerId INT
	,	@EcolabAccountNumber nvarchar(25)
 )
AS
BEGIN  
SET NOCOUNT ON
	IF OBJECT_ID('tempdb..#tmpMetaDataAdvance') IS NOT NULL
		DROP TABLE #tmpMetaDataAdvance
	DECLARE @AllowDefaultTagAddress BIT;
	IF NOT EXISTS( SELECT 1
                     FROM TCD.ControllerTags
                     WHERE ControllerId
                           = 
                           @ControllerId
                 )
        BEGIN
            SET @AllowDefaultTagAddress = 'TRUE';
        END;
    ELSE
        BEGIN
            SET @AllowDefaultTagAddress = 'FALSE';
        END;
	SELECT DISTINCT 
			FG.Id AS FieldGroupId
			,FG.[NAME] AS FieldGroupName
			,FG.[image_Url] as FieldGroupImageUrl
			,FG.[helpText] as FieldGroupHelpText
			,FG.[ControllerModelId]
			,FG.[ControllerTypeId]
			,FGT.NAME AS FieldGroupTypeName
			,F.Id AS FieldId
			,F.Name AS FieldName
			,FT.Name AS FieldType
			,F.Label AS FieldLabel
			,F.[Min] AS FieldMinValue
			,F.[Max] AS FieldMaxValue
			,F.IsMandatory AS FieldIsMandatory
			,F.IsEditable AS FieldIsEditable
			,F.HelpText AS FieldHelpText
			, F.HelpTextUrl AS FieldHelpUrl
			,FG.TabId AS TabIndex
			,DT.Name AS ControlType
			,F.DataSourceId AS DataSourceId
			,( 
                SELECT FS.Value + ':' + FS.Name + ';'
                FROM TCD.FieldSource FS
                WHERE FS.DataSourceId
                        = 
                        F.DataSourceId
                FOR XML PATH( '' )
            )AS DataSourceKeyValue 
			,F.DataCategoryId AS DataCategoryId
			,F.DefaultValue
			,F.CurrencyId AS FieldCurrencyCode
			,F.ResourceKey AS FieldResourceKey
			,FG.ResourceKey AS FieldGroupResourceKey
			,FG.DisplayOrder AS FieldGroupDO
			,F.DisplayOrder AS FieldDO 
			,CSD.ControllerId
			,FRM.RoleId AS AccessToRole
			,F.HasFieldTag AS HasFieldTag
			, (SELECT TagAddress
                        FROM TCD.ControllerTags
                        WHERE TagType
                                = 
                                F.HasFieldTag
                            AND ControllerId
                                = 
                                @ControllerId
                            AND Active = 1) AS TagDefaultValue
			,F.ClassName AS ClassName
			,CC.ControllerVersion
			,0 IsDosingLineConsumed
	INTO #tmpMetaDataAdvance
	FROM [TCD].[FieldGroup] FG
	INNER JOIN [TCD].[FieldGroupFieldMapping] FGFM ON FG.Id = FGFM.FieldGroupId
	INNER JOIN [TCD].[Field] F ON F.Id = FGFM.FieldId
	LEFT JOIN [TCD].[FieldGroupType] FGT ON FGT.Id = FG.FieldGroupTypeId
	LEFT JOIN [TCD].FieldType FT ON FT.Id = F.TypeId 
	LEFT JOIN [TCD].DataType DT ON DT.Id = F.DataTypeId
	LEFT JOIN [TCD].[FieldRoleMapping] FRM ON FRM.FieldId = F.Id
	INNER JOIN [TCD].[ConduitController] CC ON CC.ControllerModelId = FG.ControllerModelId AND CC.ControllerTypeId = FG.ControllerTypeId
	INNER JOIN [TCD].[ControllerSetupData] CSD ON CSD.ControllerId = CC.ControllerId AND CSD.EcolabAccountNumber = @EcolabAccountNumber
	WHERE 
	CC.ControllerId = @ControllerId
	AND
	FG.TabId = @TabId
	AND 
	CC.EcoalabAccountNumber = @EcolabAccountNumber


	UPDATE tmd SET DefaultValue = CSD.Value
		FROM #tmpMetaDataAdvance tmd
		INNER JOIN [TCD].ControllerSetupData CSD ON  tmd.ControllerId = CSD.ControllerId 
			AND CSD.EcolabAccountNumber = @EcolabAccountNumber
			AND tmd.FieldGroupId = CSD.FieldGroupId 
			AND tmd.FieldId = CSD.FieldId 


update MDA set IsDosingLineConsumed =1
FROM  #tmpMetaDataAdvance MDA
inner join [TCD].[ControllerEquipmentSetUp] CES on MDA.ControllerId=CES.ControllerId  and IsActive=1
where  LTRIM(rtrim( FieldResourceKey))='No_of_Pumps_Connected_to_TCR1' 
and CES.LineNumber >= 1 and CES.LineNumber <= (case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)
and CES.ControllerEquipmentId >= 1 and CES.ControllerEquipmentId <= (case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)


update MDA set IsDosingLineConsumed =1
FROM  #tmpMetaDataAdvance MDA
inner join [TCD].[ControllerEquipmentSetUp] CES on MDA.ControllerId=CES.ControllerId  and IsActive=1
where  LTRIM(rtrim( FieldResourceKey))='No_of_Pumps_Connected_to_TCR2' 
and CES.LineNumber >= (case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end) and CES.LineNumber <= ((case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)*2)
and CES.ControllerEquipmentId >= (case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end) and CES.ControllerEquipmentId <= ((case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)*2)

update MDA set IsDosingLineConsumed =1
FROM  #tmpMetaDataAdvance MDA
inner join [TCD].[ControllerEquipmentSetUp] CES on MDA.ControllerId=CES.ControllerId  and IsActive=1
where  LTRIM(rtrim( FieldResourceKey))='No_of_Pumps_Connected_to_TCR3' 
and CES.LineNumber >= ((case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)*2) and CES.LineNumber <= ((case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)*3)
and CES.ControllerEquipmentId >=  ((case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)*2) and CES.ControllerEquipmentId <= ((case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)*3)

update MDA set IsDosingLineConsumed = (select IsDosingLineConsumed from #tmpMetaDataAdvance where  LTRIM(rtrim( FieldResourceKey))='No_of_Pumps_Connected_to_TCR1' )
FROM  #tmpMetaDataAdvance MDA
where  LTRIM(rtrim( FieldResourceKey)) in( 'Dosing_Line_Mode1' ,'Enable_Auxiliary_pump1','Flow-meter_for_Flow_check1')

update MDA set IsDosingLineConsumed = (select IsDosingLineConsumed from #tmpMetaDataAdvance where  LTRIM(rtrim( FieldResourceKey))='No_of_Pumps_Connected_to_TCR2' )
FROM  #tmpMetaDataAdvance MDA
where  LTRIM(rtrim( FieldResourceKey)) in( 'Dosing_Line_Mode2','Enable_Auxiliary_pump2','meter_for_Flow_check2')

update MDA set IsDosingLineConsumed = (select IsDosingLineConsumed from #tmpMetaDataAdvance where  LTRIM(rtrim( FieldResourceKey))='No_of_Pumps_Connected_to_TCR3' )
FROM  #tmpMetaDataAdvance MDA
where  LTRIM(rtrim( FieldResourceKey)) in( 'Dosing_Line_Mode3','Enable_Auxiliary_pump3','meter_for_Flow_check3') 

	SELECT 
		CC.Name AS ControllerName
		,FieldGroupId
		,FieldGroupName
		,FieldGroupImageUrl
		,FieldGroupHelpText
		,#tmpMetaDataAdvance.ControllerModelId
		,#tmpMetaDataAdvance.ControllerTypeId
		,FieldGroupTypeName
		,FieldId
		,FieldName
		,FieldType
		,FieldLabel
		,FieldMinValue
		,FieldMaxValue
		,FieldIsMandatory
		,FieldIsEditable
		,FieldHelpText
		,FieldHelpUrl
		,TabIndex
		,ControlType
		,DataSourceId
		,DataSourceKeyValue
		,DataCategoryId
		,#tmpMetaDataAdvance.DefaultValue As DefaultValue
		,FieldCurrencyCode
		,FieldResourceKey
		,FieldGroupResourceKey
		,FieldGroupDO
		,FieldDO 
		,#tmpMetaDataAdvance.AccessToRole
		,'Edit' AS Mode
		,HasFieldTag
		,TagDefaultValue
		,ClassName
		,#tmpMetaDataAdvance.ControllerVersion
		,CAST (IsDosingLineConsumed as bit) IsDosingLineConsumed
	FROM #tmpMetaDataAdvance
	INNER JOIN [TCD].ConduitController CC on #tmpMetaDataAdvance.ControllerId = CC.ControllerId  AND CC.EcoalabAccountNumber = @EcolabAccountNumber
	ORDER BY FieldGroupDO , FieldDO, FieldId 
SET NOCOUNT OFF
END

/*
End TCD.GetControllerSetupAdvanceMetaDataWithValues

*/


/*
Start TCD.GetNavigationMenuDetails

*/

GO
IF OBJECT_ID('[TCD].[GetNavigationMenuDetails]') is not null
BEGIN
	DROP Proc [TCD].GetNavigationMenuDetails
	
END

GO
CREATE PROCEDURE [TCD].[GetNavigationMenuDetails]
				
				(@EcoLabAccountNumber				NVARCHAR(1000) = NULL,
				 @PassingRoleCode					VARCHAR(250) = NULL)

AS
BEGIN

SET	NOCOUNT	ON



DECLARE @Eqip_Table TABLE
(
Id INT,
PumpCount INT,
ControllerID INT,
ControllerEquipmentTypeId INT
)
INSERT INTO @Eqip_Table
				    (
					   Id,
					   PumpCount,
					   ControllerID,
					   ControllerEquipmentTypeId
				    )

SELECT	ROW_NUMBER() OVER (ORDER BY ControllerId, A.ControllerEquipmentTypeId) AS Id,PumpCount,ControllerId,ControllerEquipmentTypeId FROM

(SELECT DISTINCT ISNULL(CSD.Value, 0) AS PumpCount,CC.ControllerId,Isnull(CES.ControllerEquipmentTypeId,1) AS ControllerEquipmentTypeId
FROM	[TCD].ConduitController						CC
JOIN	[TCD].ControllerSetupData	CSD
	ON	CC.ControllerId						=			CSD.ControllerId
	AND FieldId in (61,71,122,184,200)
	AND csd.EcolabAccountNumber = cc.EcoalabAccountNumber
LEFT OUTER JOIN TCD.ControllerEquipmentSetup CES ON CC.ControllerId = CES.ControllerId
WHERE CC.ControllerId !=0 AND cc.EcoalabAccountNumber = @EcoLabAccountNumber
UNION 
SELECT CMCTM.PumpValveCount
	, CC.ControllerId
	, 1 AS ControllerEquipmentTypeId
  FROM TCD.ConduitController CC
	  JOIN
	  TCD.ControllerModelControllerTypeMapping CMCTM ON CMCTM.ControllerModelId = CC.ControllerModelId
										   AND CMCTM.ControllerTypeId = CC.ControllerTypeId
										   AND CC.ControllerModelId IN (7,8,9,10,11,14)
  WHERE CC.ControllerId != 0
    AND cc.EcoalabAccountNumber = @EcoLabAccountNumber
    AND CC.IsDeleted = 0
    AND (CMCTM.PumpValveCount > 0 OR CMCTM.MECount  > 0)
    --UNION
--SELECT CMCTM.MECount
--	, CC.ControllerId
--	, 2 AS ControllerEquipmentTypeId
--  FROM TCD.ConduitController CC
--	  JOIN
--	  TCD.ControllerModelControllerTypeMapping CMCTM ON CMCTM.ControllerModelId = CC.ControllerModelId
--										   AND CMCTM.ControllerTypeId = CC.ControllerTypeId
--										   AND CC.ControllerModelId IN (7,8,9,10,11,14)
--  WHERE CC.ControllerId != 0
--    AND cc.EcoalabAccountNumber = @EcoLabAccountNumber
--    AND CMCTM.MECount > 0
--    AND CC.IsDeleted = 0
 ) A

DECLARE @PumpCount TABLE
(
RowNumber INT,
PumpCount INT,
Id INT,
ControllerID INT,
ControllerEquipmentTypeId INT
)

DECLARE @Role_Menu TABLE
(
SectionID INT,
SectionName Varchar(100),
SectionCode  Varchar(100),
SectionType Varchar(100),
ControllerName Varchar(100),
ViewName Varchar(100),
ResourceClass Varchar(100),
ResourceKey Varchar(100),
ParentId INT
)

DECLARE @Id INT = 1,@MaxID int
SELECT @MaxID = COUNT(1) FROM @Eqip_Table


WHILE(@ID <= @MaxID)
BEGIN
DECLARE @Count INT,@ControllerId INT,@ControllerEquipmentTypeId INT, @ControllerModelId INT
SELECT TOP 1 @Count = PumpCount,@ControllerId = ControllerId , @ControllerEquipmentTypeId = ControllerEquipmentTypeId  FROM @Eqip_Table WHERE Id = @Id
SELECT TOP 1 @ControllerModelId = ControllerModelId FROM TCD.ConduitController CC WHERE CC.ControllerId = @ControllerId	
IF(@ControllerModelId  IN (7,8,9,10,11,14))
BEGIN
INSERT INTO @PumpCount
SELECT CES.ControllerEquipmentId AS RowNumber, CASE CES.ControllerEquipmentTypeId WHEN 1 THEN CMCTM.PumpValveCount	 ELSE CMCTM.MECount	END AS PumpCount, @Id AS Id, CES.ControllerId, CES.ControllerEquipmentTypeId 
FROM TCD.ControllerEquipmentSetup CES  
JOIN TCD.ConduitController CC ON CC.EcoalabAccountNumber = CES.EcoLabAccountNumber AND CC.ControllerId = CES.ControllerId 
JOIN TCD.ControllerModelControllerTypeMapping CMCTM ON CMCTM.ControllerModelId = CC.ControllerModelId AND CMCTM.ControllerTypeId = CC.ControllerTypeId
WHERE CES.ControllerId  = @ControllerId AND CES.EcoLabAccountNumber = @EcoLabAccountNumber
END
ELSE
BEGIN
IF	(ISNULL(@Count, 0)	<>	0)
BEGIN
	;
	WITH	NumCTE	(N)
	AS	(	SELECT	'*'	AS	N
			UNION ALL
			SELECT	'*'	AS	N
	)
	INSERT INTO @PumpCount(PumpCount,Id,RowNumber,ControllerId,ControllerEquipmentTypeId)
	SELECT	Top	(@Count)
			@Count,@Id,ROW_NUMBER() OVER(ORDER BY N1.N),@ControllerId,@ControllerEquipmentTypeId
	from	NumCTE N1	,NumCTE N2	,NumCTE N3	,NumCTE N4	,NumCTE N5 
END
END
SET @Id = @Id + 1
END


INSERT INTO @Role_Menu(SectionID,SectionName,SectionCode,SectionType,ControllerName,ViewName,ResourceClass,ResourceKey,ParentId)
EXEC [TCD].[FetchMenuSettingsByRoleCode] @PassingRoleCode

;With menu_CTE (ID,Number,Name,ParentID,TypeId,TypeName,ControllerTypeId,ControllerModelId,WasherGroupId,WasherTypeFlag,WasherGroupTypeId,Hierarchy,SectionCode)
AS
(
--- CONTROLLER DATA--
SELECT 
			0 as ID, 
			Null as Number,
			'Dispensers' as Name, 
			Null as ParentID,
			1  AS TypeId, 
			'Controllers' as TypeName,Null,Null,Null,Null,Null,'Dispensers','CONTROLLERSETUP'

UNION

SELECT 
Distinct 
			ControllerId As ID, 
			ControllerNumber as Number,
			Name, 
			0 as ParentID, 
			1 AS TypeId , 
			'Controllers' as TypeName,ControllerTypeId,ControllerModelId,Null,Null,Null,'Dispensers > '+Name,'CONTROLLERSETUP'

FROM ConduitController
WHERE Name IS NOT NULL AND IsDeleted <> 1 AND EcoalabAccountNumber = @EcolabAccountNumber  AND ControllerId !=0

UNION

(
SELECT DISTINCT
	   PC.RowNumber AS Id,
	   PC.RowNumber as Number,
	   	   (CASE WHEN CC.ControllerModelId='11' AND CAST(PC.RowNumber AS INT) BETWEEN 1 AND 12 AND PC.ControllerEquipmentTypeId = 1  THEN 'Group 1 Pump'
			WHEN CC.ControllerModelId='11' AND PC.RowNumber IN ('13','14') AND PC.ControllerEquipmentTypeId <> 1 THEN 'Group 1 ME'
			WHEN CC.ControllerModelId='11' AND CAST(PC.RowNumber AS INT) BETWEEN 15 AND 26 AND PC.ControllerEquipmentTypeId = 1 THEN 'Group 2 Pump'
			WHEN CC.ControllerModelId='11' AND PC.RowNumber IN ('27','28') AND PC.ControllerEquipmentTypeId <> 1 THEN 'Group 2 ME'
			WHEN CC.ControllerModelId IN ('7','8','9','10','14') AND PC.ControllerEquipmentTypeId = 1  THEN 'Pump ' 
			WHEN CC.ControllerModelId IN ('7','8','9','10','14') AND PC.ControllerEquipmentTypeId <> 1  THEN 'ME ' 
			WHEN CC.ControllerModelId NOT IN ('7','8','9','10','14','11') AND PC.ControllerEquipmentTypeId = 1  THEN 'P/V ' ELSE 'ME ' 
			END)
			+ CONVERT(varchar(10),(
									--case when PC.RowNumber<=12 then PC.RowNumber else PC.RowNumber-12 end)) AS Name,	
									case when CC.ControllerModelId='11' AND  PC.RowNumber<=12 then PC.RowNumber 
										 when CC.ControllerModelId='11' AND  PC.RowNumber<=14 then PC.RowNumber-12
										 when CC.ControllerModelId='11' AND  PC.RowNumber<=26 then PC.RowNumber-14
										 when CC.ControllerModelId='11' AND  PC.RowNumber<=28 then PC.RowNumber-26
										 when CC.ControllerModelId='7' AND  PC.RowNumber<=24 then PC.RowNumber
										 when CC.ControllerModelId='7' AND  PC.RowNumber<=28 then PC.RowNumber-24
										 when CC.ControllerModelId='8' AND  PC.RowNumber<=8 then PC.RowNumber
										 when CC.ControllerModelId='8' AND  PC.RowNumber<=10 then PC.RowNumber-8
										 when CC.ControllerModelId IN ('9','10') AND  PC.RowNumber<=8 then PC.RowNumber
										 when CC.ControllerModelId IN ('9','10') AND  PC.RowNumber<=9 then PC.RowNumber-8
										 when CC.ControllerModelId='14' AND  PC.RowNumber<=24 then PC.RowNumber
										 when CC.ControllerModelId='14' AND  PC.RowNumber<=25 then PC.RowNumber-24

									else PC.RowNumber end)) AS Name,	
	   --CASE WHEN  PC.ControllerEquipmentTypeId = 1  THEN 'Pump ' ELSE 'ME 'END + CONVERT(varchar(10),PC.RowNumber) AS Name,	
	   PC.ControllerID AS ParentID,
		1 AS TypeId,
		'Pumps' as TypeName,
		CC.ControllerTypeId,CC.ControllerModelId
		,Null,Null,Null,'Dispensers > '+ CC.Name +' > Pumps >'+
									(CASE WHEN CC.ControllerModelId='11' AND CAST(PC.RowNumber AS INT) BETWEEN 1 AND 12 AND PC.ControllerEquipmentTypeId = 1  THEN 'Group 1 Pump '
										WHEN CC.ControllerModelId='11' AND PC.RowNumber IN ('13','14') AND PC.ControllerEquipmentTypeId <> 1 THEN 'Group 1 ME '
										WHEN CC.ControllerModelId='11' AND CAST(PC.RowNumber AS INT) BETWEEN 15 AND 26 AND PC.ControllerEquipmentTypeId = 1 THEN 'Group 2 Pump '
										WHEN CC.ControllerModelId='11' AND PC.RowNumber IN ('27','28') AND PC.ControllerEquipmentTypeId <> 1 THEN 'Group 2 ME '
										--WHEN CC.ControllerModelId<>'11' AND PC.ControllerEquipmentTypeId = 1  THEN 'Pump ' 
										WHEN CC.ControllerModelId IN ('7','8','9','10','14') AND PC.ControllerEquipmentTypeId = 1  THEN 'Pump ' 
			WHEN CC.ControllerModelId IN ('7','8','9','10','14') AND PC.ControllerEquipmentTypeId <> 1  THEN 'ME ' 
			WHEN CC.ControllerModelId NOT IN ('7','8','9','10','14','11') AND PC.ControllerEquipmentTypeId = 1  THEN 'P/V ' ELSE 'ME '
			END)+ 
			+ CONVERT(varchar(10),(
									--case when PC.RowNumber<=12 then PC.RowNumber else PC.RowNumber-12 end)) AS Name,	
									case when CC.ControllerModelId='11' AND  PC.RowNumber<=12 then PC.RowNumber 
										 when CC.ControllerModelId='11' AND  PC.RowNumber<=14 then PC.RowNumber-12
										 when CC.ControllerModelId='11' AND  PC.RowNumber<=26 then PC.RowNumber-14
										 when CC.ControllerModelId='11' AND  PC.RowNumber<=28 then PC.RowNumber-26
										 when CC.ControllerModelId='7' AND  PC.RowNumber<=24 then PC.RowNumber
										 when CC.ControllerModelId='7' AND  PC.RowNumber<=28 then PC.RowNumber-24
										 when CC.ControllerModelId='8' AND  PC.RowNumber<=8 then PC.RowNumber
										 when CC.ControllerModelId='8' AND  PC.RowNumber<=10 then PC.RowNumber-8
										 when CC.ControllerModelId IN ('9','10') AND  PC.RowNumber<=8 then PC.RowNumber
										 when CC.ControllerModelId IN ('9','10') AND  PC.RowNumber<=9 then PC.RowNumber-8
										 when CC.ControllerModelId='14' AND  PC.RowNumber<=24 then PC.RowNumber
										 when CC.ControllerModelId='14' AND  PC.RowNumber<=25 then PC.RowNumber-24
									else PC.RowNumber end)),'CONTROLLERSETUP' 
	 
	FROM @PumpCount PC 
	JOIN TCD.ConduitController CC	 ON PC.ControllerID	 = CC.ControllerId 
    WHERE CC.Name IS NOT NULL AND CC.IsDeleted <> 1  AND CC.EcoalabAccountNumber = @EcoLabAccountNumber
	
	)
	
-- END OF CONTROLLER ------
UNION

-- WASHER GROUPS--
SELECT		
			0 as ID, 
			Null as Number,
			'Washer Groups' as Name, 
			Null as ParentID,
			2  AS TypeId, 
			'Washer Groups'  as TypeName,Null,Null,Null,Null,Null,'Washer Groups','WASHERGROUPS'

UNION

SELECT
Distinct	
			WG.WasherGroupId AS ID,
			WG.WasherGroupNumber as Number,
			WG.WasherGroupName AS Name,
			0 as ParentId,
			2  AS TypeId, 
			'Washer Groups'  as TypeName,Null,Null,Null,Null,Null,'Washer Groups > '+WG.WasherGroupName,'WASHERGROUPS'

FROM	MachineGroup	GT
		INNER JOIN	WasherGroup	WG ON	GT.Id	= WG.WasherGroupId AND wg.ecolabaccountnumber = gt.ecolabaccountnumber
		INNER JOIN	WasherGroupType	WGT ON	WG.WasherGroupTypeId = WGT.WasherGroupTypeId
WHERE GroupTypeId = 2 AND GT.Is_Deleted <> 1 AND GT.EcolabAccountNumber = @EcolabAccountNumber AND WG.EcolabAccountNumber = @EcolabAccountNumber


UNION
---FORMULA ---
SELECT 
Distinct	WP.WasherProgramSetupId  As ID,
			CAST(WP.ProgramNumber AS INT) as Number,
			P.Name AS Name,
			WP.WasherGroupId  as ParentId,
			2  AS TypeId, 
			'Formula'  as TypeName,Null,Null,Null,Null,Null,'Washer Groups > '+WG.WasherGroupName +' > Formulas > '+P.Name,'WASHERGROUPS'

FROM			WasherProgramSetup AS WP 
	INNER JOIN  ProgramMaster AS P ON P.ProgramId = WP.ProgramId AND P.EcolabAccountNumber = WP.EcolabAccountNumber
	INNER JOIN  MachineGroup GT  ON GT.Id = WP.WasherGroupId AND GT.EcolabAccountNumber = WP.EcolabAccountNumber
	INNER JOIN	tcd.WasherGroup	WG ON	WP.WasherGroupId	= WG.WasherGroupId AND WP.EcolabAccountNumber = WG.EcolabAccountNumber
WHERE GroupTypeId = 2 AND GT.Is_Deleted <> 1 AND WP.Is_Deleted <> 1 AND GT.EcolabAccountNumber = @EcolabAccountNumber AND
		P.EcolabAccountNumber = @EcolabAccountNumber AND WG.EcolabAccountNumber = @EcolabAccountNumber AND WP.EcolabAccountNumber = @EcolabAccountNumber
		 

UNION
---END OF FORMULA--
SELECT 
Distinct	TP.TunnelProgramSetupId  As ID,
			CAST(TP.ProgramNumber AS INT) as Number,
			P.Name AS Name,
			TP.WasherGroupId  as ParentId,
			2  AS TypeId, 
			'Formula'  as TypeName,Null,Null,Null,Null,Null,'Washer Groups > '+WG.WasherGroupName +' > Formulas > '+P.Name,'WASHERGROUPS'

FROM			TunnelProgramSetup AS TP 
	INNER JOIN  ProgramMaster AS P ON P.ProgramId = TP.ProgramId AND P.EcolabAccountNumber = TP.EcolabAccountNumber
	INNER JOIN  MachineGroup GT  ON GT.Id = TP.WasherGroupId AND GT.EcolabAccountNumber = TP.EcolabAccountNumber
	INNER JOIN	tcd.WasherGroup	WG ON	TP.WasherGroupId	= WG.WasherGroupId AND TP.EcolabAccountNumber = WG.EcolabAccountNumber
WHERE GT.EcolabAccountNumber = @EcolabAccountNumber AND TP.Is_Deleted <> 1 AND
		P.EcolabAccountNumber = @EcolabAccountNumber AND WG.EcolabAccountNumber = @EcolabAccountNumber AND TP.EcolabAccountNumber = @EcolabAccountNumber



-- WASHERS--

UNION

SELECT		MS.WasherId As ID,
			W.PlantWasherNumber as Number,
			MS.MachineName AS Name,
			WG.WasherGroupId AS ParentId,
			2  AS TypeId, 
			'Washer'  as TypeName,Null,Null,WG.WasherGroupId,MS.IsTunnel AS WasherTypeFlag,WGT.WasherGroupTypeId,'Washer Groups > '+WG.WasherGroupName +' > Washers > '+MS.MachineName,'WASHERGROUPS'
FROM				WasherGroup WG
		INNER JOIN	MachineGroup			GT	ON	WG.WasherGroupId	=	GT.Id  AND	WG.EcolabAccountNumber	=	GT.EcoLabAccountNumber
		INNER JOIN	MachineSetup		MS	ON	WG.WasherGroupId	=	MS.GroupId AND	WG.EcolabAccountNumber	=	MS.EcoaLabAccountNumber
		INNER JOIN	Washer			W	ON	MS.WasherId			=	W.WasherId		AND	MS.EcoalabAccountNumber	=	W.EcoLabAccountNumber
		INNER JOIN	WasherGroupType	WGT ON	WG.WasherGroupTypeId = WGT.WasherGroupTypeId
		INNER JOIN	WasherModelSize	WMS	ON	W.ModelId			=	WMS.WasherModelId
		INNER JOIN	ConduitController	CC	ON	MS.ControllerId		= CC.ControllerId	AND	MS.EcoalabAccountNumber	=	CC.EcoalabAccountNumber
WHERE GT.GroupTypeId	= 2 AND	GT.Is_Deleted <> 1 AND	MS.IsDeleted <> 1 AND MS.EcoalabAccountNumber = @EcolabAccountNumber
AND		WG.EcolabAccountNumber = @EcolabAccountNumber AND GT.EcolabAccountNumber = @EcolabAccountNumber AND W.EcolabAccountNumber = @EcolabAccountNumber AND
		CC.EcoalabAccountNumber = @EcolabAccountNumber

-- END OF WASHERS ------

-- END OF WASHER GROUPS ------

UNION  


-- WASHERS--

SELECT		
			0 as ID, 
			Null as Number,
			'Washers' as Name, 
			Null as ParentID,
			3  AS TypeId, 
			'Washers'  as TypeName,Null,Null,Null,Null,Null,'Washers','WASHER'

UNION

SELECT		MS.WasherId As ID,
			W.PlantWasherNumber as Number,
			MS.MachineName AS Name,
			0 AS ParentId,
			3  AS TypeId, 
			'Washers'  as TypeName,Null,Null,WG.WasherGroupId,MS.IsTunnel AS WasherTypeFlag,WGT.WasherGroupTypeId,'Washers > '+MS.MachineName,'WASHER'

FROM				WasherGroup WG
		INNER JOIN	MachineGroup		GT	ON	WG.WasherGroupId	=	GT.Id  AND	GT.EcolabAccountNumber	=	WG.EcoLabAccountNumber
		INNER JOIN	MachineSetup		MS	ON	WG.WasherGroupId	=	MS.GroupId  AND	WG.EcolabAccountNumber	=	MS.EcoaLabAccountNumber
		INNER JOIN	Washer			W	ON	MS.WasherId			=	W.WasherId		AND	MS.EcoalabAccountNumber	=	W.EcoLabAccountNumber
		INNER JOIN	WasherGroupType	WGT ON	WG.WasherGroupTypeId = WGT.WasherGroupTypeId
		INNER JOIN	WasherModelSize	WMS	ON	W.ModelId			=	WMS.WasherModelId
		INNER JOIN	ConduitController	CC	ON	MS.ControllerId		= CC.ControllerId	AND	MS.EcoalabAccountNumber	=	CC.EcoalabAccountNumber
WHERE GT.GroupTypeId	= 2 AND	GT.Is_Deleted <> 1 AND	MS.IsDeleted <> 1 AND MS.EcoalabAccountNumber = @EcolabAccountNumber
AND		WG.EcolabAccountNumber = @EcolabAccountNumber AND GT.EcolabAccountNumber = @EcolabAccountNumber AND W.EcolabAccountNumber = @EcolabAccountNumber AND
		CC.EcoalabAccountNumber = @EcolabAccountNumber
-- END OF WASHERS ------


UNION

-- TANKS--
SELECT		
			0 as ID, 
			Null as Number,
			'Storage Tanks' as Name, 
			Null as ParentID,
			4  AS TypeId, 
			'Storage Tanks'  as TypeName,Null,Null,Null,Null,Null,'Storage Tanks','STORAGETANKS'

UNION

SELECT		TankId  As ID,
			Null as Number,
			TankName AS Name,
			0 AS ParentId,
			4  AS TypeId, 
			'Storage Tanks'  as TypeName,Null,Null,Null,Null,Null,'Storage Tanks > '+TankName,'STORAGETANKS'

FROM [TCD].TankSetup ts 
		INNER JOIN [TCD].ConduitController cc	ON ts.ControllerId=cc.ControllerId AND cc.EcoalabAccountNumber = ts.EcoalabAccountNumber
		INNER JOIN [TCD].ProductdataMapping pdm ON ts.SKU=pdm.SKU AND pdm.EcolabAccountNumber = ts.EcoalabAccountNumber
		INNER JOIN [TCD].ProductMaster pm on pm.ProductId = pdm.ProductID 
		WHERE ts.ControllerId IS NOT NULL AND ts.ControllerId <> 0 AND ts.Is_Deleted <> 1 AND ts.EcoalabAccountNumber = @EcolabAccountNumber
		AND cc.EcoalabAccountNumber = @EcoLabAccountNumber AND pdm.EcolabAccountNumber = @EcoLabAccountNumber

-- END OF TANKS ------
)

SELECT MC.ID,MC.Number,MC.Name,MC.ParentID,MC.TypeId,MC.TypeName,MC.ControllerTypeId,MC.ControllerModelId,MC.WasherGroupId,MC.WasherTypeFlag,MC.WasherGroupTypeId,MC.Hierarchy
FROM menu_CTE MC
INNER JOIN @Role_Menu RM on RTRIM(RM.SectionCode) = RTRIM(MC.SectionCode)
order by typeId ,Number

SET nocount OFF;
END

/*
End TCD.GetNavigationMenuDetails

*/


/*
End TCD.GetControllerSetupAdvanceMetaData

*/
GO
IF OBJECT_ID('[TCD].[GetControllerSetupAdvanceMetaData]') is not null
BEGIN
	DROP Proc [TCD].GetControllerSetupAdvanceMetaData
	
END

GO
CREATE PROCEDURE [TCD].[GetControllerSetupAdvanceMetaData]
(
		@TabId INT
	,	@ControllerId INT
	,	@EcolabAccountNumber nvarchar(25)
 )
AS
SET NOCOUNT ON
BEGIN
    DECLARE @ControllerModelId INT = NULL, @ControllerTypeId INT = NULL, @ControllerVersion VARCHAR(10) = NULL
	DECLARE @ControllerName VARCHAR(50) = NULL
	SELECT 
		@ControllerModelId = ControllerModelId
	,	@ControllerTypeId = ControllerTypeId
	,	@ControllerName = Name
	,	@ControllerVersion = ControllerVersion 
	FROM 
		[TCD].ConduitController
	WHERE 
		ControllerId = @ControllerId
		AND
		EcoalabAccountNumber = @EcolabAccountNumber
	SELECT DISTINCT
			@ControllerName AS ControllerName 
		,	FG.Id AS FieldGroupId
		,	FG.[NAME] AS FieldGroupName
		,	FG.[image_Url] as FieldGroupImageUrl
		,	FG.[helpText] as FieldGroupHelpText
		,	FG.[ControllerModelId]
		,	FG.[ControllerTypeId]
		,	FGT.NAME AS FieldGroupTypeName
		,	F.Id AS FieldId
		,	F.Name AS FieldName
		,	FT.Name AS FieldType
		,	F.Label AS FieldLabel
		,	F.[Min] AS FieldMinValue
		,	F.[Max] AS FieldMaxValue
		,	F.IsMandatory AS FieldIsMandatory
		,	F.IsEditable AS FieldIsEditable
		,	F.HelpText AS FieldHelpText
		,	F.HelpTextUrl AS FieldHelpUrl
		,	FG.TabId AS TabIndex
		,	DT.Name AS ControlType
		,	F.DataSourceId AS DataSourceId
		,	(Select FS.Value + ':' + FS.Name + ';' FROM [TCD].FieldSource FS where FS.DataSourceId = F.DataSourceId for xml path('')) as DataSourceKeyValue
		,	F.DataCategoryId AS DataCategoryId
		,	F.DefaultValue As FieldDefaultValue
		,	F.CurrencyId AS FieldCurrencyCode
		,	F.ResourceKey AS FieldResourceKey
		,	FG.ResourceKey AS FieldGroupResourceKey
		,	FG.DisplayOrder AS FieldGroupDO
		,	F.DisplayOrder AS FieldDO
		,	FRM.RoleId AS AccessToRole
		,	'Add' AS Mode
		,	F.HasFieldTag AS HasFieldTag
		,	F.DefaultFieldTag As TagDefaultValue
		,	F.ClassName As ClassName
		,	@ControllerVersion
		,CAST (0 as bit) IsDosingLineConsumed
	 FROM 
		[TCD].[FieldGroup] FG
		INNER JOIN [TCD].[FieldGroupFieldMapping] FGFM ON FG.Id = FGFM.FieldGroupId
		INNER JOIN [TCD].[Field] F ON F.Id = FGFM.FieldId
		LEFT JOIN [TCD].[FieldGroupType] FGT ON FGT.Id = FG.FieldGroupTypeId
		LEFT JOIN [TCD].FieldType FT ON FT.Id = F.TypeId 
		LEFT JOIN [TCD].DataType DT ON DT.Id = F.DataTypeId
		LEFT JOIN [TCD].[FieldRoleMapping] FRM ON FRM.FieldId = F.Id
	WHERE  
		FG.TabId = @TabId 
		AND 
		FG.[ControllerModelId] = @ControllerModelId
		AND
		FG.[ControllerTypeId] = @ControllerTypeId 
		ORDER BY FG.DisplayOrder , F.DisplayOrder, F.Id 
SET NOCOUNT OFF  
END
GO
/*
End TCD.GetControllerSetupAdvanceMetaData

*/

/*
Start TCD.GetControllerSetupMetaData

*/
GO
IF OBJECT_ID('[TCD].[GetControllerSetupMetaData]') is not null
BEGIN
	DROP Proc [TCD].GetControllerSetupMetaData
	
END

GO
CREATE PROCEDURE [TCD].[GetControllerSetupMetaData]
(
	@TabId INT
	,@ControllerModelId INT
	,@ControllerTypeId INT
	,@RoleId INT
 )
AS
BEGIN     
SET NOCOUNT ON
	SELECT DISTINCT 
		'' AS ControllerName
		,FG.Id AS FieldGroupId
		,FG.[NAME] AS FieldGroupName
		,FG.[image_Url] as FieldGroupImageUrl
		,FG.[helpText] as FieldGroupHelpText
		,FG.[ControllerModelId]
		,FG.[ControllerTypeId]
		,FGT.NAME AS FieldGroupTypeName
		,F.Id AS FieldId
		,F.Name AS FieldName
		,FT.Name AS FieldType
		,F.Label AS FieldLabel
		,F.[Min] AS FieldMinValue
		,F.[Max] AS FieldMaxValue
		,F.IsMandatory AS FieldIsMandatory
		,F.IsEditable AS FieldIsEditable
		,F.HelpText AS FieldHelpText
		, F.HelpTextUrl AS FieldHelpUrl
		,FG.TabId AS TabIndex
		,DT.Name AS ControlType
		,F.DataSourceId AS DataSourceId
		,(Select FS.Value + ':' + FS.Name + ';' FROM [TCD].FieldSource FS where FS.DataSourceId = F.DataSourceId for xml path('')) as DataSourceKeyValue
		,F.DataCategoryId AS DataCategoryId
		,CASE F.Name
			WHEN 'InstallDate' THEN CONVERT(VARCHAR(10), CONVERT(DATETIME, GETDATE(),   1), 101)
			ELSE F.DefaultValue
		END As FieldDefaultValue
		,F.CurrencyId AS FieldCurrencyCode
		,F.ResourceKey AS FieldResourceKey
		,FG.ResourceKey AS FieldGroupResourceKey
		,FG.DisplayOrder AS FieldGroupDO
		,F.DisplayOrder AS FieldDO
		,FRM.RoleId AS AccessToRole
		,'Add' AS Mode
		,F.HasFieldTag AS HasFieldTag
		,F.DefaultFieldTag AS TagDefaultValue
		,F.ClassName AS Classname
		,'' AS ControllerVersion
		,CAST (0 as bit) IsDosingLineConsumed
	 FROM [TCD].[FieldGroup] FG
		INNER JOIN [TCD].[FieldGroupFieldMapping] FGFM ON FG.Id = FGFM.FieldGroupId
		INNER JOIN [TCD].[Field] F ON F.Id = FGFM.FieldId
		LEFT JOIN [TCD].[FieldGroupType] FGT ON FGT.Id = FG.FieldGroupTypeId
		LEFT JOIN [TCD].FieldType FT ON FT.Id = F.TypeId 
		LEFT JOIN [TCD].DataType DT ON DT.Id = F.DataTypeId
		LEFT JOIN [TCD].[FieldRoleMapping] FRM ON FRM.FieldId = F.Id AND FRM.RoleId=@RoleId
	WHERE  
	FG.TabId = @TabId 
	AND 
	FG.[ControllerModelId] = @ControllerModelId
	AND
	FG.[ControllerTypeId] = @ControllerTypeId 
	ORDER BY FG.DisplayOrder , F.DisplayOrder, F.Id   
SET NOCOUNT OFF
END
/*
End TCD.GetControllerSetupMetaData

*/



/*
Start TCD.GetControllerSetupMetaDataWithValues

*/
GO
IF OBJECT_ID('[TCD].[GetControllerSetupMetaDataWithValues]') is not null
BEGIN
	DROP Proc [TCD].GetControllerSetupMetaDataWithValues
	
END

GO
CREATE PROCEDURE [TCD].[GetControllerSetupMetaDataWithValues]
(

		@TabId INT

	,	@ControllerId INT

	,	@EcolabAccountNumber nvarchar(25)

	,	@RoleId INT
 )

AS

BEGIN  

SET NOCOUNT ON

	IF OBJECT_ID('tempdb..#tmpMetaData') IS NOT NULL

		DROP TABLE #tmpMetaData

	SELECT DISTINCT 

			FG.Id AS FieldGroupId

			,FG.[NAME] AS FieldGroupName

			,FG.[image_Url] as FieldGroupImageUrl

			,FG.[helpText] as FieldGroupHelpText

			,FG.[ControllerModelId]

			,FG.[ControllerTypeId]

			,FGT.NAME AS FieldGroupTypeName

			,F.Id AS FieldId

			,F.Name AS FieldName

			,FT.Name AS FieldType

			,F.Label AS FieldLabel

			,F.[Min] AS FieldMinValue

			,F.[Max] AS FieldMaxValue

			,F.IsMandatory AS FieldIsMandatory

			,F.IsEditable AS FieldIsEditable

			,F.HelpText AS FieldHelpText

			, F.HelpTextUrl AS FieldHelpUrl

			,FG.TabId AS TabIndex

			,DT.Name AS ControlType

			,F.DataSourceId AS DataSourceId

			,(Select FS.Value + ':' + FS.Name + ';' FROM [TCD].FieldSource FS where FS.DataSourceId = F.DataSourceId for xml path('')) as DataSourceKeyValue

			,F.DataCategoryId AS DataCategoryId

			,F.DefaultValue

			,F.CurrencyId AS FieldCurrencyCode

			,F.ResourceKey AS FieldResourceKey

			,FG.ResourceKey AS FieldGroupResourceKey

			,FG.DisplayOrder AS FieldGroupDO

			,F.DisplayOrder AS FieldDO 

			,CSD.ControllerId

			,FRM.RoleId AS AccessToRole

			,F.HasFieldTag AS HasFieldTag

			,F.DefaultFieldTag As TagDefaultValue

			,F.ClassName AS ClassName

			,CC.ControllerVersion

	INTO #tmpMetaData

	FROM [TCD].[FieldGroup] FG

	INNER JOIN [TCD].[FieldGroupFieldMapping] FGFM ON FG.Id = FGFM.FieldGroupId

	INNER JOIN [TCD].[Field] F ON F.Id = FGFM.FieldId

	LEFT JOIN [TCD].[FieldGroupType] FGT ON FGT.Id = FG.FieldGroupTypeId

	LEFT JOIN [TCD].FieldType FT ON FT.Id = F.TypeId 

	LEFT JOIN [TCD].DataType DT ON DT.Id = F.DataTypeId

	LEFT JOIN [TCD].[FieldRoleMapping] FRM ON FRM.FieldId = F.Id AND FRM.RoleId=@RoleId	

	INNER JOIN [TCD].[ConduitController] CC ON CC.ControllerModelId = FG.ControllerModelId AND CC.ControllerTypeId = FG.ControllerTypeId AND CC.EcoalabAccountNumber = @EcolabAccountNumber

	INNER JOIN [TCD].[ControllerSetupData] CSD ON CSD.ControllerId = CC.ControllerId AND CSD.EcolabAccountNumber = @EcolabAccountNumber

	WHERE 
	CC.ControllerId = @ControllerId
	AND
	FG.TabId = @TabId

	UPDATE tmd SET DefaultValue = CSD.Value FROM #tmpMetaData tmd

	INNER JOIN [TCD].ControllerSetupData CSD 

	ON 
	tmd.ControllerId = CSD.ControllerId 

	AND 

	tmd.FieldGroupId = CSD.FieldGroupId 

	AND 

	tmd.FieldId = CSD.FieldId 

	SELECT 

		CC.Name AS ControllerName

		,FieldGroupId

		,FieldGroupName

		,FieldGroupImageUrl

		,FieldGroupHelpText

		,#tmpMetaData.ControllerModelId

		,#tmpMetaData.ControllerTypeId

		,FieldGroupTypeName

		,FieldId

		,FieldName

		,FieldType

		,FieldLabel

		,FieldMinValue

		,FieldMaxValue

		,FieldIsMandatory

		,FieldIsEditable

		,FieldHelpText

		,FieldHelpUrl

		,TabIndex

		,ControlType

		,DataSourceId

		,DataSourceKeyValue

		,DataCategoryId

		,CASE FieldName

			WHEN 'ControllerVersion' THEN CC.ControllerVersion

			WHEN 'ControllerNumber' THEN Cast(CC.ControllerNumber as varchar)

			WHEN 'InstallDate' THEN CONVERT(VARCHAR(10), CONVERT(datetime, CC.InstallDate,   1), 101)

			WHEN 'TopicName' THEN Cast(CC.TopicName as varchar)

			WHEN 'Active'	THEN  CASE  CC.Active WHEN 0 THEN 'false' WHEN 1 THEN 'true' END --cast(CC.Active as char)  


			ELSE #tmpMetaData.DefaultValue

		END As DefaultValue

		,FieldCurrencyCode

		,FieldResourceKey

		,FieldGroupResourceKey

		,FieldGroupDO

		,FieldDO 

		,#tmpMetaData.AccessToRole

		,'Edit' AS Mode

		,HasFieldTag

		,TagDefaultValue

		,ClassName

		,#tmpMetaData.ControllerVersion
		,CAST (0 as bit) IsDosingLineConsumed
	FROM #tmpMetaData

	INNER JOIN [TCD].ConduitController CC on #tmpMetaData.ControllerId = CC.ControllerId AND CC.EcoalabAccountNumber = @EcolabAccountNumber
	
	ORDER BY FieldGroupDO , FieldDO, FieldId 


SET NOCOUNT OFF

END

/*
END TCD.GetControllerSetupMetaDataWithValues

*/



/*
Start TCD.DeleteWasherGroup

*/
GO
IF OBJECT_ID('[TCD].[DeleteWasherGroup]') is not null
BEGIN
	DROP Proc [TCD].DeleteWasherGroup
	
END

GO

/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_DeleteWasherGroup]                                         

Purpose:				To delete the washer group.

Parameters:				@EcolabAccountNumber - holds the ecolab account number.
						@WasherGroupId - holds the washer group id.
						@UserId - holds the user id.
																																		
###################################################################################################                                           
*/
CREATE	PROCEDURE	[TCD].[DeleteWasherGroup]
					@EcoLabAccountNumber					NVARCHAR(1000)
				,	@WasherGroupId							INT
				,	@UserId									INT
				--Adding these 3 params as part of re-factoring for integration with Synch/Configurator
				,	@OutputWasherGroupId					INT			=			NULL	OUTPUT
				,	@LastModifiedTimestampAtCentral			DATETIME	=			NULL			--Nullable for local call; Synch/Central call will have to pass this -
																									--else, it will be treated as a local call
				,	@OutputLastModifiedTimestampAtLocal		DATETIME	=			NULL	OUTPUT
AS
BEGIN

SET	NOCOUNT	ON


DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()
	,	@WasherGroupTypeId				INT				=			0

--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
SET		@OutputLastModifiedTimestampAtLocal				=			@CurrentUTCTime
SET		@OutputWasherGroupId							=			ISNULL(@OutputWasherGroupId, NULL)			--SQLEnlight SA0121


--If the call is not local, check that the LastModifiedTime matches with the central
IF	(@LastModifiedTimestampAtCentral IS NOT	NULL
		AND	NOT	EXISTS	(SELECT	1 FROM TCD.[MachineGroup]	GT
							WHERE GT.EcolabAccountNumber = @EcolabAccountNumber
							AND	GT.Id=	@WasherGroupId
							AND	GT.LastModifiedTime		=	@LastModifiedTimestampAtCentral)
	)
	BEGIN
			SET			@ErrorId =	60000
			SET			@ErrorMessage =	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
			RAISERROR	(@ErrorMessage, 16, 1)
			SET			@ReturnValue =	-1
			RETURN		(@ReturnValue)
	END

--Proceed, since it's either a local call or Synch. call with synch. time matching


BEGIN	TRAN

UPDATE	GT SET	GT.Is_Deleted = 'TRUE'
		,GT.LastModifiedTime = @CurrentUTCTime
	FROM [TCD].MachineGroup	GT
		JOIN [TCD].WasherGroup WG ON GT.Id = WG.WasherGroupId AND GT.EcolabAccountNumber = WG.EcolabAccountNumber
		WHERE GT.EcolabAccountNumber =@EcoLabAccountNumber
			AND	GT.Id = @WasherGroupId						--Id is the WasherGroupId in WasherGroup table
			AND	GT.Is_Deleted = 'FALSE'

SET @WasherGroupTypeId =(select [TCD].WasherGroup.WasherGroupTypeId FROM [TCD].WasherGroup WHERE WasherGroupId=@WasherGroupId)

IF (@WasherGroupTypeId=1 )
BEGIN
-- Removing associated Formulas for the tunnel

UPDATE TPS

       SET    Is_Deleted                               =                    'TRUE'

       ,      LastModifiedByUserId       =                    @UserId

FROM   [TCD].TunnelProgramSetup   TPS

WHERE  TPS.WasherGroupId                 =                    @WasherGroupId

       AND    TPS.EcolabAccountNumber           =                    @EcoLabAccountNumber

       AND    TPS.Is_Deleted                           =                    'FALSE'
END


update W set W.Is_Deleted =1,
			 W.LastModifiedTime=@CurrentUTCTime,
			 W.LastModifiedByUserId=@UserId
 FROM 
 [TCD].WasherGroup  WG
	JOIN    [TCD].MachineGroup GT ON  WG.WasherGroupId = GT.Id AND WG.EcolabAccountNumber = GT.EcolabAccountNumber
	JOIN    [TCD].MachineSetup MS ON    WG.WasherGroupId = MS.GroupId AND  WG.EcolabAccountNumber = MS.EcoalabAccountNumber
	JOIN    [TCD].Washer W ON    MS.WasherId  = W.WasherId AND    MS.EcoalabAccountNumber = W.EcoLabAccountNumber
	and WG.WasherGroupId=@WasherGroupId
	and GT.EcolabAccountNumber =@EcoLabAccountNumber


UPDATE WT SET  Active =    0
from TCD.WasherTags WT
inner join [TCD].MachineSetup MS on  wt.WasherId=MS.WasherId and MS.GroupId=@WasherGroupId


--check for any error
SET	@ErrorId	=	@@ERROR
IF	(@ErrorId	<>	0)
	BEGIN
		IF	@@TRANCOUNT	>	0
		BEGIN
			ROLLBACK	TRAN
		END

		SET		@ErrorMessage = N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating washer group as DELETED.'
		--GOTO	Errorhandler
		RAISERROR	(@ErrorMessage, 16, 1)
		SET	@ReturnValue	=	-1
		RETURN	(@ReturnValue)
	END
--Else, continue...
UPDATE	WG SET	WG.LastModifiedByUserId	= @UserId
		FROM [TCD].MachineGroup	GT
			JOIN [TCD].WasherGroup WG ON GT.Id = WG.WasherGroupId AND GT.EcolabAccountNumber = WG.EcolabAccountNumber
		WHERE GT.EcolabAccountNumber = @EcoLabAccountNumber
				AND	GT.Id = @WasherGroupId						--Id is the WasherGroupId in WasherGroup table
				AND	GT.Is_Deleted =	'TRUE'
--check for any error
EXEC [TCD].[SaveInjectionDetails] @WashergroupId,0,0,@EcolabAccountNumber

SET	@ErrorId	=	@@ERROR
IF	(@ErrorId	<>	0)
	BEGIN
		IF	@@TRANCOUNT	>	0
		BEGIN
			ROLLBACK	TRAN
		END

		SET		@OutputWasherGroupId	=			NULL

		SET		@ErrorMessage			=			N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating washer group as DELETED.'
		--GOTO	Errorhandler
		RAISERROR	(@ErrorMessage, 16, 1)
		SET	@ReturnValue	=	-1
		RETURN	(@ReturnValue)
	END
ELSE
	BEGIN
		IF	@@TRANCOUNT	>	0
		BEGIN
			COMMIT
		END

		SET	@OutputWasherGroupId	=	@WasherGroupId
	END

	DECLARE 
	@WasherGroupNumber INT
	SELECT @WasherGroupNumber = WasherGroupNumber FROM TCD.WasherGroup WHERE WasherGroupId = @WasherGroupId

	UPDATE TCD.Injection SET Is_Deleted = 'TRUE' WHERE WasherGroupNumber = @WasherGroupNumber
--Commented, as this is not required now...
--IF	(	@ErrorId	=	0	)
--	BEGIN
--		--GOTO	ExitModule
--		RETURN	(@ReturnValue)
--	END




--ErrorHandler:
--RAISERROR	(@ErrorMessage, 16, 1)
--SET	@ReturnValue	=	-1




--ExitModule:

SET	NOCOUNT	OFF
RETURN	(@ReturnValue)


END
/*
END TCD.DeleteWasherGroup

*/


/*
Start TCD.ProcessMyControlOnlineProductDosing

*/
GO
IF OBJECT_ID('[TCD].[ProcessMyControlOnlineProductDosing]') is not null
BEGIN
	DROP Proc [TCD].ProcessMyControlOnlineProductDosing
	
END

GO

CREATE Procedure [TCD].[ProcessMyControlOnlineProductDosing]
	(
		@ControllerID INT,
		@VxML xML
	)
AS
BEGIN
   DECLARE 
			@TheoreticalQty			Decimal(10,6),
			@RealQty				Decimal(10,6),
			@BatchNumber			INT,
			@DosingPoint			INT,
			@DosingNumber			INT,
			@ValveNumber			INT,
			@ProgramNumber			INT,
			@WasherId				INT,
			@MachineInternalId		INT,
			@PrevRealQty			Decimal(10,6),
			@ProductId				INT,
			@PumpNum				INT,
			@EquipmentType			INT,
			@CompartmentNum			INT			
			
  	
	SELECT @TheoreticalQty=T.c.value('@TheoreticalQty', 'Decimal(10,6)'),
			@RealQty=T.c.value('@RealQty', 'Decimal(10,6)'),
			@BatchNumber=T.c.value('@BatchNumber', 'INT'),
			@ProgramNumber=T.c.value('@ProgramNumber', 'INT'),
			@DosingPoint=T.c.value('@DosingPoint', 'INT'),
			@DosingNumber=T.c.value('@DosingNumber', 'INT'),
			@PumpNum = T.c.value('@PumpNum', 'INT'),
			@ValveNumber = T.c.value('@ValveNumber', 'INT')
			
	FROM @VxML.nodes('MyControlOnlineProductDosing') T(C)
	
	IF(	@PumpNum >= 25 AND @PumpNum <= 26)
	BEGIN
		SET @EquipmentType = 2
	END
	ELSE
	BEGIN
		SET @EquipmentType = 1
	END

	IF(@DosingPoint >= 17 AND @DosingPoint <= 20)
	BEGIN
		SET @MachineInternalId = 1
	END
	ELSE IF(@DosingPoint >= 21 AND @DosingPoint <= 24)
	BEGIN
		SET @MachineInternalId = 2
	END

	IF(@DosingPoint >= 1 AND @DosingPoint <= 16)
	BEGIN
			set @MachineInternalId = @DosingPoint
			SELECT @WasherId = WasherId FROM TCD.MachineSetup WHERE ControllerID = @ControllerID AND MachineInternalId = @MachineInternalId AND IsTunnel = 0 AND IsDeleted = 0
			SELECT @ProductId = ProductId FROM TCD.ControllerEquipmentSetup WHERE ControllerEquipmentId = @PumpNum AND ControllerID = @ControllerID	
	END
	ELSE IF(@DosingPoint >= 17 AND @DosingPoint <= 24)
	BEGIN
			SELECT @WasherId = WasherId FROM TCD.MachineSetup WHERE ControllerID = @ControllerID AND MachineInternalId = @MachineInternalId AND IsTunnel = 1 AND IsDeleted = 0

			SELECT @ProductId=CES.ProductId, @CompartmentNum=TCEVM.CompartmentNumber
		    	FROM  tcd.ControllerEquipmentSetup CES INNER JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM
				ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
				WHERE CES.ControllerId=@ControllerID AND
						CES.ControllerEquipmentTypeId=@EquipmentType AND
						TCEVM.ValveNumber = @ValveNumber AND
						CES.ControllerEquipmentId = @PumpNum
	END
	
	SELECT TOP 1 @PrevRealQty = RealQty FROM TCD.WasherProductReading WHERE ControllerId=@ControllerID AND WasherId = @WasherId ORDER BY DateTimeStamp DESC
	
	IF(@ProductId IS NOT NULL)
	BEGIN
	IF(@PrevRealQty is null OR @PrevRealQty != @RealQty)
	BEGIN
		INSERT INTO [TCD].[WasherProductReading] 
			   (ControllerId,
				WasherId,
				MachineInternalId,
				ProductId,
				TheoreticalQty,
				RealQty,
				DosingPoint,
				DosingNumber,
				ProgramNumber,
				BatchNumber,
				ValveNumber,
				DateTimeStamp			   
			   )
				  SELECT
				   @ControllerId,
				   @WasherId,
				   @MachineInternalId,
				   @ProductId,
				   @TheoreticalQty,
				   @RealQty,
				   @DosingPoint,
				   @DosingNumber,
				   @ProgramNumber,
				   @BatchNumber,
				   @ValveNumber,
				   GETUTCDATE()				   
		END
	END		   			   	 
END

/*
END TCD.ProcessMyControlOnlineProductDosing

*/

GO
IF NOT EXISTS(SELECT 1 
				FROM INFORMATION_SCHEMA.COLUMNS
				WHERE 
					 TABLE_NAME = 'AlarmStatus' AND 
					 COLUMN_NAME = 'WasherId'
					 )
BEGIN
	ALTER TABLE tcd.AlarmStatus add  [WasherId] INT
END

GO
IF  EXISTS(SELECT 1 
				FROM INFORMATION_SCHEMA.COLUMNS
				WHERE 
					 TABLE_NAME = 'AlarmStatus' AND 
					 COLUMN_NAME = 'AlarmMachineMappingId'
					 )
BEGIN

	EXEC sp_rename 'TCD.AlarmStatus.AlarmMachineMappingId', 'AlarmGroupMsterVsControllerModelTypeId', 'COLUMN';
END

GO

IF EXISTS (SELECT 1
			FROM sys.objects
			WHERE parent_object_id = (OBJECT_ID('TCD.AlarmStatus')) 
			AND type IN ('C','F', 'PK')
			and name ='FK_AlarmStatus_AlarmGroupMsterVsControllerModelTypeId' )
BEGIN
	ALTER TABLE TCD.AlarmStatus	DROP CONSTRAINT FK_AlarmStatus_AlarmGroupMsterVsControllerModelTypeId
	
	ALTER TABLE TCD.AlarmStatus add constraint FK_AlarmStatus_AlarmGroupMsterVsControllerModelTypeId FOREIGN KEY ([AlarmGroupMsterVsControllerModelTypeId]) REFERENCES TCD.AlarmGroupMsterVsControllerModelType(AlarmGroupMsterVsControllerModelTypeID)
END

GO
/*
Start TCD.AlarmStatusAuditTrigger

*/
GO
IF OBJECT_ID('[TCD].[AlarmStatusAuditTrigger]') is not null
BEGIN
	DROP trigger [TCD].AlarmStatusAuditTrigger
	
END

GO
/*                                           
###################################################################################################                                           

Trigger		:		AlarmStatusAuditTrigger

Purpose		:		Trigger	for auditing changes on AlarmStatus table

Parameter	:		NA

###################################################################################################                                           
*/

CREATE	TRIGGER		[TCD].[AlarmStatusAuditTrigger]
ON					[TCD].[AlarmStatus]
FOR	INSERT, UPDATE
AS
BEGIN

SET	NOCOUNT	ON

DECLARE	@AuditOperation_SQLInsertId			TINYINT				=			NULL
	,	@AuditOperation_SQLUpdateId			TINYINT				=			NULL
	--,	@AuditOperation_AppDeleteId			TINYINT				=			NULL
	,	@ErrorNumber						INT					=			0
	,	@ErrorMessage						NVARCHAR(2048)		=			NULL
	,	@ErrorSeverity						INT					=			NULL
	,	@ErrorProcedure						SYSNAME				=			NULL
	,	@MessageString						NVARCHAR(2500)		=			NULL
	--,	@SoftDeleteFlag						BIT					=			NULL			--0 for FALSE/1 for TRUE
	,	@CurrentTimeStamp					DATETIME			=			GETUTCDATE()	--CURRENT_TIMESTAMP

--select	*	from	AuditOperation
SELECT	@AuditOperation_SQLInsertId			=			AO.OperationId
FROM	[TCD].AuditOperation					AO
WHERE	AO.OperationCode					=			'SQLInsert'

SELECT	@AuditOperation_SQLUpdateId			=			AO.OperationId
FROM	[TCD].AuditOperation					AO
WHERE	AO.OperationCode					=			'SQLUpdate'

--SELECT	@AuditOperation_AppDeleteId			=			AO.OperationId				--SQLEnlight SA0004
--FROM	[TCD].AuditOperation					AO
--WHERE	AO.OperationCode					=			'AppDelete'

IF	NOT	EXISTS	(SELECT	1	FROM	[deleted])
	BEGIN

			BEGIN	TRY
										INSERT	[TCD].AlarmStatusHistory(
												Id,
												OperationTimestamp,
												OperationId,
												OperationByUserId,
												AlarmMachineMappingId,
												Active,
												LastModifiedTime,
												LastSyncTime,
												EcolabAccountNumber)
										SELECT
							                    Id,
												@CurrentTimeStamp,
												@AuditOperation_SQLInsertId,
												LastModifiedByUserId,
												[AlarmGroupMsterVsControllerModelTypeId],
												Active,
												LastModifiedTime,
												LastSyncTime,
												EcolabAccountNumber
								FROM	[inserted]

			END	TRY
			BEGIN	CATCH

					SELECT	@ErrorNumber				=			ERROR_NUMBER()
						,	@ErrorMessage				=			ERROR_MESSAGE()
						,	@ErrorProcedure				=			ERROR_PROCEDURE()
						,	@ErrorSeverity				=			ERROR_SEVERITY()

					--GOTO	ErrorHandler
					SET		@MessageString				=	N'An error occured while updating Audit data for AlarmStatus table. The error is: '
														+	@ErrorMessage + '	'
														+	'Module: ' + @ErrorProcedure
					RAISERROR(@MessageString, @ErrorSeverity, 1)
					RETURN

			END	CATCH
	END
ELSE	IF	EXISTS	(SELECT	1	FROM	[inserted])
	BEGIN;
			--SET	@SoftDeleteFlag	=	'FALSE'												--SQLEnlight SA0004

			BEGIN
					BEGIN	TRY
										INSERT	[TCD].AlarmStatusHistory(
												Id,
												OperationTimestamp,
												OperationId,
												OperationByUserId,
												AlarmMachineMappingId,
												Active,
												LastModifiedTime,
												LastSyncTime,
												EcolabAccountNumber)
										SELECT	
									   		    Id,
												@CurrentTimeStamp,
												@AuditOperation_SQLUpdateId,
												LastModifiedByuserId,
												[AlarmGroupMsterVsControllerModelTypeId],
												Active,
												LastModifiedTime,
												LastSyncTime,
												EcolabAccountNumber
												FROM	[inserted]

					END	TRY
					BEGIN	CATCH

							SELECT	@ErrorNumber				=			ERROR_NUMBER()
								,	@ErrorMessage				=			ERROR_MESSAGE()
								,	@ErrorProcedure				=			ERROR_PROCEDURE()
								,	@ErrorSeverity				=			ERROR_SEVERITY()

							--GOTO	ErrorHandler
							SET		@MessageString				=	N'An error occured while updating Audit data for AlarmStatus table. The error is: '
																+	@ErrorMessage + '	'
																+	'Module: ' + @ErrorProcedure
							RAISERROR(@MessageString, @ErrorSeverity, 1)
							RETURN

					END	CATCH
			END
	END


IF	@ErrorNumber	=	0
	--GOTO	ExitModule
	RETURN
		


ErrorHandler:

SET		@MessageString						=	N'An error occured while updating Audit data for AlarmStatus table. The error is: '
											+	@ErrorMessage + '	'
											+	'Module: ' + @ErrorProcedure
RAISERROR(@MessageString, @ErrorSeverity, 1)



ExitModule:

RETURN

SET	NOCOUNT	OFF

END
GO
/*
END TCD.AlarmStatusAuditTrigger

*/


/*
Start TCD.ValidateAlarmsSave

*/
GO
IF OBJECT_ID('[TCD].[ValidateAlarmsSave]') is not null
BEGIN
	DROP proc [TCD].ValidateAlarmsSave
	
END

GO
/*	
Purpose					:	To Validate Alarms Save for sync

History					:
Dec. 2014					initial version

*/

CREATE	PROCEDURE	[TCD].[ValidateAlarmsSave]
		@ControllerModelId							INT
	,	@ControllerTypeId							INT
	,	@MachineNumber								INT
	,	@EcolabAccountNumber						NVARCHAR(1000)
	,	@MaxNoOfRec									INT
AS
BEGIN

SET	NOCOUNT	ON


DECLARE	
		@ReturnValue					int				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''


IF (
	(
		SELECT DISTINCT COUNT(*)
		FROM 
		[TCD].AlarmStatus A
		INNER JOIN [TCD].AlarmMachineMapping AMM ON AMM.Id = A.[AlarmGroupMsterVsControllerModelTypeId]
		INNER JOIN [TCD].AlarmMaster AM ON AM.AlarmCode = AMM.AlarmCode
		WHERE
		AM.IsDelete = 1
		AND
		AMM.ControllerModelId		= @ControllerModelId
		AND
		AMM.ControllerTypeId		= @ControllerTypeId
		AND 
		A.MachineNumber				= @MachineNumber
		AND
		A.EcolabAccountNumber		= @EcolabAccountNumber
		) <> @MaxNoOfRec
	)
	BEGIN
				SET		@ErrorId						=			51030
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record count does not match.'
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
	END

SET	NOCOUNT	OFF

RETURN	(@ReturnValue)

END
/*
END TCD.ValidateAlarmsSave

*/



/*
Start TCD.SaveAlarmStatus

*/
GO
IF OBJECT_ID('[TCD].[SaveAlarmStatus]') is not null
BEGIN
	DROP proc [TCD].SaveAlarmStatus
	
END

GO
CREATE	PROCEDURE	[TCD].[SaveAlarmStatus]	(
					@AlarmMachineMappingId					INT
				,	@ControllerModelId						INT
				,	@ControllerTypeId						INT
				,	@MachineNumber							INT		
				,	@Active									BIT
				
				,	@DeleteFlag								BIT			=			'FALSE'	--DO NOT SET THIS (to TRUE) UNLESS DELETE IS INTENDED
				,	@UserId									INT			=			NULL
				,	@EcolabAccountNumber					VARCHAR(1000)
				,	@WasherId								INT
				)
AS 
BEGIN 


SET	NOCOUNT	ON

DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''



IF	(	@DeleteFlag	=	'TRUE'	)
	BEGIN
			DELETE A
			FROM [TCD].AlarmStatus A
			INNER JOIN [TCD].[AlarmGroupMsterVsControllerModelType] AGM_V_CMT ON AGM_V_CMT.AlarmGroupMsterVsControllerModelTypeId = A.AlarmGroupMsterVsControllerModelTypeId
			INNER JOIN [TCD].[ControllerModelControllerTypeMapping] CMCTM ON CMCTM.Id = AGM_V_CMT.ControllerModelTypeId
			WHERE
			CMCTM.ControllerModelId		= @ControllerModelId
			AND
			CMCTM.ControllerTypeId		= @ControllerTypeId
			AND
			A.MachineNumber				= @MachineNumber
			AND
			A.EcolabAccountNumber		= @EcolabAccountNumber
			AND 
			A.WasherId					= @WasherId
			SET	@ErrorId	=	@@ERROR

			IF	(@ErrorId	<>	0)
			BEGIN
				SET		@ErrorMessage				=			N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred overwriting alarm data.'
				--GOTO	Errorhandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END

	END
ELSE
	BEGIN
		INSERT INTO	[TCD].AlarmStatus (
					AlarmGroupMsterVsControllerModelTypeId
				,	MachineNumber
				,	Active
				,	LastModifiedByuserId
				,	EcolabAccountNumber
				,	WasherId
				)
			SELECT
					@AlarmMachineMappingId	AS			AlarmGroupMsterVsControllerModelTypeId
				,	@MachineNumber			AS			MachineNumber
				,	@Active					AS			Active
				,	@UserId					AS			UserId
				,	@EcolabAccountNumber	AS			EcolabAccountNumber
				,	@WasherId				AS			WasherId
		--check for any error
		SET	@ErrorId	=	@@ERROR

		IF	(@ErrorId	<>	0)
		BEGIN
			SET		@ErrorMessage			=			N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred overswriting alarm data.'
			--GOTO	Errorhandler
			RAISERROR	(@ErrorMessage, 16, 1)
			SET	@ReturnValue	=	-1
			RETURN	(@ReturnValue)
		END
	END


IF	(	@ErrorId	=	0	)
	BEGIN
		--GOTO	ExitModule
		RETURN	(@ReturnValue)
	END

SET	NOCOUNT	OFF
RETURN	(@ReturnValue)

END
/*
END TCD.SaveAlarmStatus

*/


/*
Start TCD.GetAlarmSetupDetails

*/
GO
IF OBJECT_ID('[TCD].[GetAlarmSetupDetails]') is not null
BEGIN
	DROP proc [TCD].GetAlarmSetupDetails
	
END

GO
CREATE PROCEDURE [TCD].[GetAlarmSetupDetails]
(
	@ControllerModelId							INT
,	@ControllerTypeId							INT
,	@MachineNumber								INT				=	NULL			-- Null for Getting Alarms associated with ControllerModel and ControllerType
,	@WasherGroupTypeId            INT
,	@WasherId									INT				= NULL
)
AS
SET NOCOUNT ON

DECLARE @washerType nchar(10)
IF(@WasherGroupTypeId = 1 )

BEGIN
	
	SET @washerType = 'C'

END

ELSE IF (@WasherGroupTypeId = 2)

BEGIN

	SET @washerType = 'T'

END
ELSE
	SET @washerType = 'G'

	SELECT
	AGM_V_CMT.AlarmCode
	,AGM.[Description]
	,AGM_V_CMT.AlarmGroupMsterVsControllerModelTypeId AS AlarmMachineMappingId
	,AGM_V_CMT.DisplayOrder
	,AGM_V_CMT.IsDefault	
	,CASE WHEN ALS.Active = 1 OR AGM_V_CMT.IsDefault =1 THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT) END Active
	,AGM.ResourceKey
	FROM [TCD].AlarmGroupMaster AGM
	INNER JOIN [TCD].[AlarmGroupMsterVsControllerModelType] AGM_V_CMT ON AGM.AlarmGroupMasterId = AGM_V_CMT.AlarmGroupMasterId
	INNER JOIN [TCD].ControllerModelControllerTypeMapping CMTM ON CMTM.Id = AGM_V_CMT.ControllerModelTypeId
	LEFT JOIN [TCD].AlarmStatus ALS ON ALS.[AlarmGroupMsterVsControllerModelTypeId] = AGM_V_CMT.AlarmGroupMsterVsControllerModelTypeId
	AND 
	ALS.WasherId = @WasherId
	WHERE
	(AGM.WasherType = @washerType OR AGM.WasherType = 'G')
	AND
	AGM.IsDelete = 0
	AND 
	AGM_V_CMT.IsDelete = 0
	AND
	CMTM.ControllerModelId = @ControllerModelId
	AND
	CMTM.ControllerTypeId = @ControllerTypeId
	AND
	(AGM_V_CMT.MachineNumber IS NULL OR AGM_V_CMT.MachineNumber = @MachineNumber)
	AND 
	AGM.IsHoldCondition			= 1		
	ORDER BY AGM_V_CMT.AlarmCode

SET	NOCOUNT	OFF
/*
END TCD.GetAlarmSetupDetails

*/
/*
Start TCD.DeleteConventional

*/
GO
IF OBJECT_ID('[TCD].[DeleteConventional]') is not null
BEGIN
	DROP proc [TCD].DeleteConventional
	
END

GO
/*	
Purpose					:	To delete a Conventional Washer from the Washers grid UI
History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version
*/

CREATE	PROCEDURE	[TCD].[DeleteConventional](
@EcoLabAccountNumber	NVARCHAR(1000)
,@WasherId	INT
,@UserId	INT
,@LastModifiedTimestampAtCentral DATETIME =	NULL
,@OutputLastModifiedTimestampAtLocal DATETIME =	NULL OUTPUT)
AS
BEGIN
SET	NOCOUNT	ON
DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()
	,	@WashgroupId					INT				=			NULL
	,	@ControllerId					INT				=			NULL
	,	@ControllerModelId				INT				=			NULL

DECLARE @OutputList AS	TABLE ( LastModifiedTimestamp DATETIME )

SET		@OutputLastModifiedTimestampAtLocal	 =	 ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight


--Valid Washer - Id & Type...
IF	NOT	EXISTS	(	SELECT	1
					FROM	[TCD].Washer						W
					JOIN	[TCD].MachineSetup					MS
						ON	W.WasherId					=			MS.WasherId
						AND	W.EcoLabAccountNumber		=			MS.EcoalabAccountNumber
					WHERE	W.EcoLabAccountNumber		=			@EcoLabAccountNumber
						AND	W.WasherId					=			@WasherId
						AND	W.Is_Deleted				=			'FALSE'
						AND	MS.IsDeleted				=			'FALSE'
				)
			BEGIN
				SET		@ErrorId						=			51007
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Washer-ID or Type was provided.'
				RAISERROR	(@ErrorMessage, 16, 1)
				SET		@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


IF	( @LastModifiedTimestampAtCentral IS NOT NULL
			AND NOT	EXISTS	( SELECT	1 FROM	TCD.Washer W
								WHERE	W.EcolabAccountNumber	=	@EcolabAccountNumber AND	W.WasherId	 =	@WasherId
								AND	W.LastModifiedTime = @LastModifiedTimestampAtCentral )
	)
		BEGIN
				SET			@ErrorId				=	60000
				SET			@ErrorMessage			=	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
				RAISERROR	(@ErrorMessage, 16, 1)
				SET			@ReturnValue			=	-1
				RETURN		(@ReturnValue)
		END


--if valid, attempt to delete now...

--we will need tran, b'coz the data is spread across 2 tables...
BEGIN	TRAN

UPDATE	W
	SET	W.Is_Deleted			=			'TRUE'
	,	W.LastModifiedByUserId	=			@UserId
	,	W.LastModifiedTime		=			@CurrentUTCTime
OUTPUT 	inserted.LastModifiedTime AS LastModifiedTimestamp INTO	@OutputList	(LastModifiedTimestamp)
FROM	[TCD].Washer W
		JOIN [TCD].MachineSetup	MS ON W.WasherId = MS.WasherId 	AND	W.EcoLabAccountNumber	=	MS.EcoalabAccountNumber
WHERE	W.EcoLabAccountNumber	=	@EcoLabAccountNumber
		AND	W.WasherId	=	@WasherId
		AND	W.Is_Deleted = 'FALSE'
		AND	MS.IsDeleted = 'FALSE'
--check for any error
SET		@ErrorId				=			@@ERROR

--if any error, abort...
IF	(@ErrorId	<>	0)
	BEGIN
		--Rollback, if in tran
		IF	(@@TRANCOUNT	>	0)
			BEGIN
				ROLLBACK	TRAN
			END

		--Error-out...
		SET		@ErrorMessage=N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred deleting washer data.'
		RAISERROR	(@ErrorMessage, 16, 1)
		SET		@ReturnValue	=	-1
		RETURN	(@ReturnValue)
	END
--else, continue with the deletion in the 2nd table...

UPDATE	MS 	SET	MS.IsDeleted = 'TRUE'
	,	MS.LastModifiedByUserId	= @UserId
FROM	[TCD].MachineSetup	 MS
JOIN	[TCD].Washer W  ON	MS.WasherId	= W.WasherId AND MS.EcoalabAccountNumber	=	W.EcoLabAccountNumber
WHERE	MS.WasherId = @WasherId
	AND	MS.EcoalabAccountNumber	= @EcoLabAccountNumber
	AND	MS.IsDeleted = 'FALSE'
	AND	W.Is_Deleted = 'TRUE'

SELECT @WashgroupId = MS.GroupId,@ControllerId = MS.ControllerId FROM TCD.MachineSetup AS MS WHERE MS.WasherId = @WasherId AND MS.EcoalabAccountNumber = @EcoLabAccountNumber
EXEC [TCD].[SaveInjectionDetails] @WashgroupId,@ControllerId,@WasherId, @EcoLabAccountNumber

SELECT @ControllerModelId = cmctm.ControllerModelId 
FROM TCD.ControllerModelControllerTypeMapping cmctm 
INNER JOIN TCD.ConduitController cc 
	ON cc.ControllerModelId = cmctm.ControllerModelId
WHERE cc.ControllerId = @ControllerId AND cc.EcoalabAccountNumber = @EcoLabAccountNumber

-- Removing Tags Associated to it
UPDATE TCD.WasherTags SET  Active =	0 WHERE  WasherId =	@WasherId

UPDATE A SET Is_Deleted =1
			,LastModifiedByUserId=@UserId
			,LastModifiedTime=@CurrentUTCTime
 FROM tcd.WasherFlushTime A
 WHERE WasherId=@WasherId

--check for any error
SET @ErrorId = @@ERROR

--if any error, abort, else COMMIT the work...
IF	(@ErrorId	<>	0)
	BEGIN
		--Rollback, if in tran
		IF	(@@TRANCOUNT	>	0)
			BEGIN
				ROLLBACK	TRAN
			END

		--Error-out...
		SET		@ErrorMessage =			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred deleting washer data.'
		RAISERROR	(@ErrorMessage, 16, 1)
		SET		@ReturnValue	=	-1
		RETURN	(@ReturnValue)
	END
--else, continue with the deletion in the 2nd table...
ELSE
	BEGIN
		--COMMIT, if in tran
		IF	(@@TRANCOUNT	>	0)
			BEGIN
				COMMIT
			END

			SELECT	TOP 1 @OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp FROM @OutputList O
	END

IF	(@ErrorId	=	0)
	BEGIN
		IF (@ControllerModelId = 7)
			BEGIN
				UPDATE TCD.WasherGroup SET ControllerId = NULL WHERE WasherGroupId = @WashgroupId
			END 
		RETURN	(@ReturnValue)
		
	END

SET	NOCOUNT	OFF
RETURN	(@ReturnValue)
END
/*
END TCD.DeleteConventional

*/


/*
Start TCD.DeleteTunnel

*/
GO
IF OBJECT_ID('[TCD].[DeleteTunnel]') is not null
BEGIN
	DROP proc [TCD].DeleteTunnel
	
END

GO
/*
Purpose	:To delete a Tunnel from the Washers grid UI
History	: Oct. 2014	dfozdar@allianceglobalservice.com initial version
*/
CREATE	PROCEDURE	[TCD].[DeleteTunnel]
					@EcoLabAccountNumber					NVARCHAR(1000)
				,	@WasherId								INT
				,	@UserId									INT
				--Adding these 3 params as part of re-factoring for integration with Synch/Configurator
				,	@OutputTunnelId							INT			=			NULL	OUTPUT
				,	@OutputWasherGroupId					INT			=			NULL	OUTPUT	--since this marks t-WG 2 Formula association as deleted
				,	@LastModifiedTimestampAtCentral			DATETIME	=			NULL			--Nullable for local call; Synch/Central call will have to pass this -
																									--else, it will be treated as a local call
				,	@OutputLastModifiedTimestampAtLocal		DATETIME	=			NULL	OUTPUT
AS
BEGIN
SET	NOCOUNT	ON
DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	,	@WasherGroupId					INT				=			0
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()

--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
SET		@OutputLastModifiedTimestampAtLocal				=			@CurrentUTCTime
SET		@OutputTunnelId									=			ISNULL(@OutputTunnelId, NULL)			--SQLEnlight
SET		@OutputWasherGroupId							=			ISNULL(@OutputWasherGroupId, NULL)		--SQLEnlight


--If the call is not local, check that the LastModifiedTime matches with the central
IF	(@LastModifiedTimestampAtCentral IS NOT	NULL
			AND	NOT	EXISTS	(SELECT	1 FROM	TCD.[Washer] W
							WHERE	W.EcolabAccountNumber	=	@EcolabAccountNumber
							AND	W.WasherId				=	@WasherId
							AND	W.LastModifiedTime		=	@LastModifiedTimestampAtCentral )
	)
	BEGIN
			SET			@ErrorId					=	60000
			SET			@ErrorMessage				=	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
			RAISERROR	(@ErrorMessage, 16, 1)
			SET			@ReturnValue				=	-1
			RETURN		(@ReturnValue)
	END

--Proceed, since it's either a local call or Synch. call with synch. time matching

--Valid Washer - Id & Type...
IF	NOT	EXISTS	(	SELECT	1 FROM	[TCD].Washer W 
							JOIN	[TCD].MachineSetup	MS ON	W.WasherId = MS.WasherId AND	W.EcoLabAccountNumber = MS.EcoalabAccountNumber
					WHERE	W.EcoLabAccountNumber		=			@EcoLabAccountNumber
						AND	W.WasherId					=			@WasherId
						AND	MS.IsTunnel					=			'TRUE'
						AND	W.Is_Deleted				=			'FALSE'
						AND	MS.IsDeleted				=			'FALSE'
				)
			BEGIN
				SET		@ErrorId						=			51007
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Washer-ID or Type was provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END

--if valid, attempt to delete now...

--we will need tran, b'coz the data is spread across 2 tables...
SELECT @WasherGroupId = GroupId 
	FROM TCD.MachineSetup 
	Where WasherId = @WasherId

BEGIN	TRAN

UPDATE	W
	SET	W.Is_Deleted			=			'TRUE'
	,	W.LastModifiedByUserId	=			@UserId
	,	W.LastModifiedTime		=			@CurrentUTCTime
FROM	[TCD].Washer			W
JOIN	[TCD].MachineSetup		MS ON	W.WasherId = MS.WasherId
		AND	W.EcoLabAccountNumber	=	 MS.EcoalabAccountNumber
WHERE	W.EcoLabAccountNumber	=			@EcoLabAccountNumber
	AND	W.WasherId				=			@WasherId
	AND	W.Is_Deleted			=			'FALSE'
	AND	MS.IsDeleted			=			'FALSE'

-- Removing associated Formulas for the tunnel
UPDATE	TPS
	SET	Is_Deleted					=			'TRUE'
	,	LastModifiedByUserId		=			@UserId
FROM	[TCD].TunnelProgramSetup	TPS
WHERE	TPS.WasherGroupId			=			@WasherGroupId
	AND	TPS.EcolabAccountNumber		=			@EcoLabAccountNumber
	AND	TPS.Is_Deleted				=			'FALSE'

--check for any error
SET		@ErrorId				=			@@ERROR

--if any error, abort...
IF	(@ErrorId	<>	0)
	BEGIN
		--Rollback, if in tran
		IF	(@@TRANCOUNT	>	0)
			BEGIN
				ROLLBACK	TRAN
			END

		--Error-out...
		SET		@ErrorMessage				=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred deleting washer data.'
		--GOTO	Errorhandler
		RAISERROR	(@ErrorMessage, 16, 1)
		SET	@ReturnValue	=	-1
		RETURN	(@ReturnValue)
	END
--else, continue with the deletion in the 2nd table...

UPDATE	MS
	SET	MS.IsDeleted			=			'TRUE'
	,	MS.LastModifiedByUserId	=			@UserId
FROM	[TCD].MachineSetup			MS
JOIN	[TCD].Washer					W
	ON	MS.WasherId				=			W.WasherId
	AND	MS.EcoalabAccountNumber	=			W.EcoLabAccountNumber
WHERE	MS.WasherId				=			@WasherId
	AND	MS.EcoalabAccountNumber	=			@EcoLabAccountNumber
	AND	MS.IsDeleted			=			'FALSE'
	AND	W.Is_Deleted			=			'TRUE'


UPDATE TCD.WasherTags	 SET  Active =	0 	WHERE  WasherId		=	@WasherId
--check for any error
SET		@ErrorId				=			@@ERROR

--if any error, abort, else COMMIT the work...
IF	(@ErrorId	<>	0)
	BEGIN
		--Rollback, if in tran
		IF	(@@TRANCOUNT	>	0)
			BEGIN
				ROLLBACK	TRAN
			END

		--Error-out...
		SET		@ErrorMessage				=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred deleting washer data.'
		--GOTO	Errorhandler
		RAISERROR	(@ErrorMessage, 16, 1)
		SET	@ReturnValue	=	-1
		RETURN	(@ReturnValue)
	END
--else, continue with the deletion in the 2nd table...
ELSE
	BEGIN
		--COMMIT, if in tran
		IF	(@@TRANCOUNT	>	0)
			BEGIN
				COMMIT
			END
			--set Output variable for Synch./Central to consume 
		SET	@OutputTunnelId					=	@WasherId
		SET	@OutputWasherGroupId			=	@WasherGroupId
	END

IF	(@ErrorId	=	0)
	BEGIN
		--GOTO	ExitModule
		RETURN	(@ReturnValue)
	END

SET	NOCOUNT	OFF
RETURN	(@ReturnValue)


END

/*
END TCD.DeleteTunnel

*/

/*
Start TCD.SaveControllerEquipment

*/
GO
IF OBJECT_ID('[TCD].[SaveControllerEquipment]') is not null
BEGIN
	DROP proc [TCD].SaveControllerEquipment
	
END

GO
/*                                      
###################################################################################################                                             
  
Stored Procedure:       [dbo].[SaveControllerEquipment]                                           
  
Purpose:    To save the controller equipment.  
  
Parameters:    @EcolabAccountNumber - holds the ecolab account number.  
      @ControllerId - holds the controller Id.  
      @ControllerEquipmentId - holds the controller equuipment id.  
      @ControllerEquipmentTypeId - holds the controller equipment type id.  
      @ProductId - holds the product id.  
      @PumpCalibration - holds the pump calibration value.  
      @FlowMeterSwitchFlag - holds the flow meteer switch flag value.  
      @FlowMeterCalibration - holds the flow meter calibration.  
      @MaximumDosingTime - holds the maximum dosing time.  
      @FlowSwitchTimeOut - holds the flow switch time out.  
      @UserId - holds the user id.  
                                    
###################################################################################################                                             
*/  
CREATE PROCEDURE [TCD].[SaveControllerEquipment]          
      @EcoLabAccountNumber    NVARCHAR(25)          
    , @ControllerId     INT          
    , @ControllerEquipmentId    SMALLINT          
    , @ControllerEquipmentTypeId   TINYINT          
    , @ProductId      INT          
    , @PumpCalibration     DECIMAL(18, 3)          
    , @LfsChemicalName     NVARCHAR(200)          
    , @KFactor      DECIMAL(18,2)  = NULL          
    , @TunnelHold      BIT    = NULL          
    , @FlowDetectorType     INT    = NULL      
    , @FlowSwitchNumber        INT        = NULL      
    , @FlowSwitchAlarm     BIT    = NULL          
    , @FlowMeterAlarm     BIT    = NULL          
    , @FlowMeterType     INT    = NULL          
    , @FlowAlarmDelay     INT    = NULL          
    , @FlowMeterPumpDelay    INT    = NULL          
    , @FlowMeterAlarmDelay    INT    = NULL          
    , @LfsChemicalNameTag    NVARCHAR(200)  = NULL          
    , @KfactorTag      NVARCHAR(200)  = NULL          
    , @CalibrationTag     NVARCHAR(200)  = NULL          
    , @ControllerEquipmentTypeModelId  INT = NULL          
    , @ConventionalWasherGroupConnection BIT           
    , @AxillaryPumpCalibration   SMALLINT          
    , @FlowmeterSwitchActivated   BIT          
    , @FlushWhileDosing      BIT          
    , @WeightControlledDosage    BIT          
    , @EquipmentDoseAlone       BIT          
    , @LowLevelAlarm          BIT          
    , @LeakageAlarm          BIT          
    , @FlushTime         SMALLINT          
    , @PumpingTime         SMALLINT          
    , @PreFlushTime        SMALLINT          
    , @NightFlushPauseTime       SMALLINT          
    , @NightFlushTime        SMALLINT          
    , @AcceptedDeviation       SMALLINT          
    , @LineNumber      TINYINT          
    , @MaximumDosingTime    SMALLINT          
    , @FlowSwitchTimeOut    decimal(18,1)          
    , @UserId       INT                 
    , @FlushValveNumber   TINYINT    = NULL      
    , @CalibrationConductSS_Tank DECIMAL(18,2)  = NULL      
    , @BackFlowControl    BIT        
    , @FactorFM_B_FM    SMALLINT   = NULL      
    , @AcceptedDeviationRingLine SMALLINT   = NULL       
    , @UsePumpOfGroup1ForTunnel BIT   = NULL         
    , @pHSensorEnabled    BIT   = NULL    
 , @FlushTimeForFlushValve    INT   = NULL      
    , @Concentration      INT     = NULL      
    , @Deadband     BIT   = NULL     
 , @ValveOutputAsTom BIT = NULL   
    ,@MinimumFlowRate INT = NULL
    ,@ProductDensity DECIMAL(18,2) = NULL
    , @MaximumConcentration INT = NULL
    --Adding these 3 param as part of re-factoring for integration with Synch/Configurator          
    , @OutputControllerEquipmentSetupId INT   =   NULL OUTPUT          
    , @LastModifiedTimestampAtCentral  DATETIME =   NULL   --Nullable for local call; Synch/Central call will have to pass this -          
                        --else, it will be treated as a local call          
    , @OutputLastModifiedTimestampAtLocal DATETIME =   NULL OUTPUT          
          
AS          
BEGIN          
          
SET NOCOUNT ON          
          
DECLARE @Equipments TABLE (        
ProductId INT,        
EcoLabAccountNumber NVARCHAR(25),        
ControllerId INT        
)        
DECLARE @ReturnValue     INT      =   0          
 , @IsActive      BIT          
 , @ErrorId      INT      =   0          
 --, @ErrorMessage     NVARCHAR(4000)   =   N''          
 --, @ErrorNumber     INT     =   0          
 , @ErrorMessage     NVARCHAR(4000)   =   N''          
 , @ErrorSeverity     INT     =   NULL          
 , @ErrorProcedure     SYSNAME    =   NULL          
 , @MessageString     NVARCHAR(2500)  =   NULL          
          
 , @MaximumChemicalCount   TINYINT     =   NULL          
 , @DistinctChemicalCount   TINYINT     =   NULL          
 , @ControllerTypeId    INT          
 , @CurrentUTCTime     DATETIME    =   GETUTCDATE()          
          
--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype          
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded          
SET  @OutputLastModifiedTimestampAtLocal      =   @CurrentUTCTime          
SET  @OutputControllerEquipmentSetupId      =   ISNULL(@OutputControllerEquipmentSetupId, NULL)   --SQLEnlight SA0121          
          
    
          
SELECT @MaximumChemicalCount     =   CMCTM.MaximumChemicalCount          
  ,@ControllerTypeId      =   CC.ControllerTypeId          
FROM [TCD].ConduitController CC          
JOIN [TCD].ControllerModelControllerTypeMapping CMCTM          
 ON CC.ControllerModelId     =   CMCTM.ControllerModelId          
 AND CC.ControllerTypeId      =   CMCTM.ControllerTypeId          
WHERE CC.ControllerId       =   @ControllerId          
          
set @MaximumChemicalCount = 30 -- Added dummy value by srikanth, at times we are getting this value as 1, so that user is not able to add pumps more than 1. //Lemuel handled how many pumps should display based on the configuration so this check is useles 
  
    
     
       
         
          
SET  @IsActive        =   CASE WHEN @ProductId IS NULL THEN 'FALSE'          
                 ELSE 'TRUE'          
               END          
          
 DECLARE @ModuleType INT = 4 --select MTy.ModuleTypeId from TCD.ModuleType MTy WHERE ModuleDescription like '%Pump%Valve%'          
     ,@DefaultFrequency INT = 60          
     ,@TagTypeLfs VARCHAR(100) = 'Tag_NML'          
     ,@TagTypeKfactor VARCHAR(100) = 'Tag_PPOL'          
     ,@TagTypeCalibration VARCHAR(100) = 'Tag_OPSL'          
     ,@Result1 INT = NULL          
     ,@Result2 INT = NULL          
     ,@Result3 INT = NULL          
     ,@Type INT = 4 --@ModuleType          
     ,@RoleId INT = (SELECT UR.LevelId FROM TCD.UserMaster UM          
              INNER JOIN TCD.UserInRole UIR ON UM.UserId = UIR.UserId          
              INNER JOIN TCD.UserRoles UR ON UIR.RoleId = UR.RoleId          
              WHERE UM.UserId = @UserId)          
          
DECLARE          
  @OutputList      AS TABLE  (          
  ControllerEquipmentSetupId   INT          
 , LastModifiedTimestamp    DATETIME          
 )          
          
IF EXISTS ( SELECT 1          
    FROM [TCD].ControllerEquipmentSetup  CES          
    WHERE CES.ControllerId     =   @ControllerId          
     AND CES.ControllerEquipmentId   =   @ControllerEquipmentId          
     AND CES.EcoLabAccountNumber    =   @EcoLabAccountNumber          
   )          
  BEGIN          
    --If the call is not local, check that the LastModifiedTime matches with the central          
    IF (          
      @LastModifiedTimestampAtCentral   IS NOT NULL          
     AND NOT EXISTS ( SELECT 1          
          FROM TCD.[ControllerEquipmentSetup]          
                  CES          
          WHERE CES.EcolabAccountNumber = @EcolabAccountNumber        
           AND CES.ControllerId  = @ControllerId          
           AND CES.ControllerEquipmentId          
                  = @ControllerEquipmentId          
           AND CES.LastModifiedTime = @LastModifiedTimestampAtCentral          
         )          
     )          
     BEGIN          
       SET   @ErrorId      = 60000          
       SET   @ErrorMessage     = N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'          
       RAISERROR (@ErrorMessage, 16, 1)          
       SET   @ReturnValue     = -1          
       RETURN  (@ReturnValue)          
     END          
             
    --Proceed, since it's either a local call or Synch. call with synch. time matching          
    SELECT @DistinctChemicalCount    =   COUNT(DISTINCT D.ProductId) --distinct count          
    FROM (          
      SELECT @ProductId     AS   ProductId     --being assigned          
      UNION          
      SELECT DISTINCT ProductId  AS   ProductId     --already assigned          
      FROM [TCD].ControllerEquipmentSetup          
      WHERE ControllerId    =   @ControllerId          
       AND ControllerEquipmentId  <>   @ControllerEquipmentId          
       AND ProductId     <>   @ProductId          
      ) D          
          
    IF ( @DistinctChemicalCount > @MaximumChemicalCount )          
    BEGIN          
      SET @ErrorId   = 51000          
      SET @ErrorMessage  = N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Maximum chemical count exceeded. Cannot assign new chemical'          
      --GOTO ErrorHandler          
      RAISERROR (@ErrorMessage, 16, 1)          
      SET @ReturnValue = -1          
      RETURN (@ReturnValue)          
    END          
              
    --DECLARE @PumpId INT = (SELECT ControllerEquipmentSetupId          
    --            FROM [TCD].ControllerEquipmentSetup          
    --            WHERE ControllerId  = @ControllerId           
    --            AND ControllerEquipmentId = @ControllerEquipmentId           
    --            AND EcoLabAccountNumber  = @EcoLabAccountNumber)          
          
    --IF(@RoleId =8)          
    -- BEGIN          
    --   IF(@LfsChemicalNameTag IS NOT NULL AND @LfsChemicalNameTag <> '')          
    --    BEGIN          
    --     EXEC @Result1 = TCD.CheckDuplicateTag @LfsChemicalNameTag, @ControllerID, @PumpId, @Type          
    --     IF(@Result1 = 0)          
    --     BEGIN          
    --     SET @ErrorMessage = '801,'          
    --    END          
    --   END          
    --   IF(@KfactorTag IS NOT NULL AND @KfactorTag <> '')          
    --    BEGIN          
    --     EXEC @Result2 = TCD.CheckDuplicateTag @KfactorTag,@ControllerID, @PumpId, @Type          
    --     IF(@Result2 = 0)          
    --     BEGIN          
    --     SET @ErrorMessage = @ErrorMessage+'802,'          
    --     END          
    --    END          
    --   IF(@CalibrationTag IS NOT NULL AND @CalibrationTag <> '')          
    --   BEGIN          
    --    EXEC @Result3 = TCD.CheckDuplicateTag @CalibrationTag,@ControllerID, @PumpId, @Type          
    --    IF(@Result3 = 0)          
    --    BEGIN          
    --    SET @ErrorMessage = @ErrorMessage+'803,'          
    --    END          
    --   END          
    -- END          
          
    --SET @ErrorMessage = @ErrorMessage + CONVERT(VARCHAR(100),'')          
          
    --IF(@ErrorMessage <> '')          
    -- RAISERROR(@ErrorMessage, 16, 1)          
    --ELSE          
     BEGIN          
      BEGIN TRY          
        BEGIN TRAN          
          
        UPDATE [TCD].ControllerEquipmentSetup          
         SET ProductId      =   @ProductId          
         , IsActive      =   @IsActive          
         , LfsChemicalName    =   CASE @IsActive WHEN 'TRUE' THEN @LfsChemicalName   ELSE NULL END          
         , KFactor      =   CASE @IsActive WHEN 'TRUE' THEN @KFactor     ELSE NULL END          
         , PumpCalibration    =   CASE @IsActive WHEN 'TRUE' THEN @PumpCalibration   ELSE NULL END          
              
         , TunnelHold     =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @TunnelHold   ELSE NULL END ELSE NULL END          
         , FlowDetectorType    =   CASE @IsActive WHEN 'TRUE' THEN CASE WHEN @ControllerTypeId IN(2,6,7, 12,10, 14,8, 13,9,11) THEN @FlowDetectorType  ELSE NULL END ELSE NULL END   
         , FlowSwitchNumber    =    @FlowSwitchNumber  
         , FlowSwitchAlarm    =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowSwitchAlarm  ELSE NULL END ELSE NULL END          
         , FlowMeterAlarm     =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterAlarm  ELSE NULL END ELSE NULL END          
         , FlowMeterType     =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterType   ELSE NULL END ELSE NULL END          
         , FlowAlarmDelay     =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowAlarmDelay ELSE NULL END ELSE NULL END          
         , FlowMeterPumpDelay    =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterPumpDelay  ELSE NULL END ELSE NULL END          
         , FlowMeterAlarmDelay    =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterAlarmDelay ELSE NULL END ELSE NULL END          
         , ControllerEquipmentTypeModelId =   CASE @IsActive WHEN 'TRUE' THEN @ControllerEquipmentTypeModelId      ELSE NULL END          
             , ConventionalWasherGroupConnection =   CASE @IsActive WHEN 'TRUE' THEN @ConventionalWasherGroupConnection  ELSE 0 END          
             , AxillaryPumpCalibration   =   CASE @IsActive WHEN 'TRUE' THEN @AxillaryPumpCalibration    ELSE 0 END          
             , FlowmeterSwitchActivated   =   CASE @IsActive WHEN 'TRUE' THEN @FlowmeterSwitchActivated   ELSE 0 END          
             , FlushWhileDosing     =   CASE @IsActive WHEN 'TRUE' THEN @FlushWhileDosing      ELSE 0 END          
             , WeightControlledDosage    =   CASE @IsActive WHEN 'TRUE' THEN @WeightControlledDosage     ELSE 0 END          
             , EquipmentDoseAlone       =   CASE @IsActive WHEN 'TRUE' THEN @EquipmentDoseAlone        ELSE 0 END          
             , LowLevelAlarm          =   CASE @IsActive WHEN 'TRUE' THEN @LowLevelAlarm           ELSE 0 END          
             , LeakageAlarm          =   CASE @IsActive WHEN 'TRUE' THEN @LeakageAlarm           ELSE 0 END          
             , FlushTime         =   CASE @IsActive WHEN 'TRUE' THEN @FlushTime         ELSE NULL END          
             , PumpingTime        =   CASE @IsActive WHEN 'TRUE' THEN @PumpingTime         ELSE NULL END          
             , PreFlushTime        =   CASE @IsActive WHEN 'TRUE' THEN @PreFlushTime         ELSE NULL END          
             , NightFlushPauseTime       =   CASE @IsActive WHEN 'TRUE' THEN @NightFlushPauseTime       ELSE NULL END          
             , NightFlushTime        =   CASE @IsActive WHEN 'TRUE' THEN @NightFlushTime        ELSE NULL END          
             , AcceptedDeviation       =   CASE @IsActive WHEN 'TRUE' THEN @AcceptedDeviation        ELSE NULL END          
             , LineNumber        =   CASE @IsActive WHEN 'TRUE' THEN @LineNumber           ELSE 0 END          
             , MaximumDosingTime    =   CASE @IsActive WHEN 'TRUE' THEN @MaximumDosingTime     ELSE NULL END          
         , FlowSwitchTimeOut    =   CASE @IsActive WHEN 'TRUE' THEN @FlowSwitchTimeOut     ELSE NULL END       
        , ValveOutputAsTom               =   CASE @IsActive WHEN 'TRUE' THEN @ValveOutputAsTom           ELSE 0 END        
          
         , LastModifiedByUserId   =   @UserId          
        --** Adding a part of integration with Synch./Central -->          
         , LastModifiedTime    =   @CurrentUTCTime                  
       , FlushValveNumber  =   CASE @IsActive WHEN 'TRUE' THEN @FlushValveNumber     ELSE NULL END           
 , CalibrationConductSS_Tank =   CASE @IsActive WHEN 'TRUE' THEN @CalibrationConductSS_Tank     ELSE NULL END         
       , BackFlowControl  =   CASE @IsActive WHEN 'TRUE' THEN @BackFlowControl     ELSE 'False' END            
       , FactorFM_B_FM   =   CASE @IsActive WHEN 'TRUE' THEN @FactorFM_B_FM     ELSE NULL END                
       , AcceptedDeviationRingLine =   CASE @IsActive WHEN 'TRUE' THEN @AcceptedDeviationRingLine     ELSE NULL END           
       , UsePumpOfGroup1ForTunnel =   CASE @IsActive WHEN 'TRUE' THEN @UsePumpOfGroup1ForTunnel     ELSE NULL END             
       , pHSensorEnabled    =   CASE @IsActive WHEN 'TRUE' THEN @pHSensorEnabled     ELSE NULL END        
    , FlushTimeForFlushValve = @FlushTimeForFlushValve   
       , Concentration =   CASE @IsActive WHEN 'TRUE' THEN @Concentration     ELSE NULL END             
       , Deadband    =   CASE @IsActive WHEN 'TRUE' THEN @Deadband     ELSE NULL END          
       , MinimumFlowRate = CASE @IsActive WHEN 'TRUE' THEN @MinimumFlowRate     ELSE NULL END  
       , ProductDensity = CASE @IsActive WHEN 'TRUE' THEN @ProductDensity     ELSE NULL END
       , MaximumConcentration = CASE @IsActive WHEN 'TRUE' THEN @MaximumConcentration     ELSE NULL END
        OUTPUT inserted.ControllerEquipmentSetupId   AS   ControllerEquipmentSetupId          
         , inserted.LastModifiedTime     AS   LastModifiedTime          
        INTO @OutputList (          
          ControllerEquipmentSetupId          
         , LastModifiedTimestamp          
         )          
        --** <--          
        WHERE ControllerId    =   @ControllerId          
        AND ControllerEquipmentId   =   @ControllerEquipmentId          
        AND EcoLabAccountNumber    =   @EcoLabAccountNumber           
          
        SET @ErrorId = @@ERROR          
          
        IF (@ErrorId <> 0)          
         BEGIN          
          IF @@TRANCOUNT > 0          
           ROLLBACK          
          
          SET  @ErrorMessage  = N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating Equipment data'          
          --GOTO Errorhandler          
          RAISERROR (@ErrorMessage, 16, 1)          
          SET @ReturnValue = -1          
          RETURN (@ReturnValue)          
         END          
          
        ---Tags---          
        --IF(@RoleId =8)          
        --BEGIN          
        --  IF(@IsActive = 'TRUE')          
        --    BEGIN          
        --      --1st if-else...          
        --      IF NOT EXISTS(SELECT 1 FROM TCD.ModuleTags WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND Active = 1 AND TagType = @TagTypeLfs)          
        --        BEGIN          
        --          IF(@LfsChemicalNameTag IS NOT NULL AND @LfsChemicalNameTag <> '')           
        --           INSERT INTO [TCD].ModuleTags (EcolabAccountNumber ,TagType,TagAddress,ModuleTypeId,ModuleID,DeadBand,Active) VALUES(@EcoLabAccountNumber ,@TagTypeLfs,@LfsChemicalNameTag,@ModuleType,@PumpId,@DefaultFrequency,1)          
        --        END          
        --      ELSE          
        --      IF(@LfsChemicalNameTag IS NOT NULL AND @LfsChemicalNameTag <> '')          
        --        UPDATE [TCD].ModuleTags SET TagAddress = @LfsChemicalNameTag WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND TagType = @TagTypeLfs AND Active = 1          
        --      ELSE          
        --        UPDATE [TCD].ModuleTags SET Active = 0 WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND TagType = @TagTypeLfs AND Active = 1          
          
        --      --2nd if-else...          
        --      IF NOT EXISTS(SELECT 1 FROM TCD.ModuleTags WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND Active = 1 AND TagType = @TagTypeKfactor)          
        --        BEGIN          
        --          IF(@KfactorTag IS NOT NULL AND @KfactorTag <> '')          
        --           INSERT INTO [TCD].ModuleTags (EcolabAccountNumber ,TagType,TagAddress,ModuleTypeId,ModuleID,DeadBand,Active) VALUES(@EcoLabAccountNumber ,@TagTypeKfactor,@KfactorTag,@ModuleType,@PumpId,@DefaultFrequency,1)          
        --        END          
        --      ELSE           
        --      IF(@KfactorTag IS NOT NULL AND @KfactorTag <> '')          
        --        UPDATE [TCD].ModuleTags SET TagAddress = @KfactorTag WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND TagType = @TagTypeKfactor AND Active = 1          
        --      ELSE          
        --        UPDATE [TCD].ModuleTags SET Active = 0 WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND TagType = @TagTypeKfactor AND Active = 1          
          
        --      --3rd if-else...          
        --      IF NOT EXISTS(SELECT 1 FROM TCD.ModuleTags WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND Active = 1 AND TagType = @TagTypeCalibration)          
        --        BEGIN          
        --          IF(@CalibrationTag IS NOT NULL AND @CalibrationTag <> '')          
        --           INSERT INTO [TCD].ModuleTags (EcolabAccountNumber ,TagType,TagAddress,ModuleTypeId,ModuleID,DeadBand,Active) VALUES(@EcoLabAccountNumber ,@TagTypeCalibration,@CalibrationTag,@ModuleType,@PumpId,@DefaultFrequency,1)          
        --        END          
        --      ELSE           
        --      IF(@CalibrationTag IS NOT NULL AND @CalibrationTag <> '')          
        --        UPDATE [TCD].ModuleTags SET TagAddress = @CalibrationTag WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND TagType = @TagTypeCalibration AND Active = 1          
        --      ELSE          
        --        UPDATE [TCD].ModuleTags SET Active = 0 WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND TagType = @TagTypeCalibration AND Active = 1          
        --    END --@IsActive = 'TRUE'          
        --  ELSE          
        --    BEGIN --Can be combined into 1 update stmt. ...          
        --      UPDATE [TCD].ModuleTags SET Active = 0 WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND TagType = @TagTypeLfs AND Active = 1          
        --      UPDATE [TCD].ModuleTags SET Active = 0 WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND TagType = @TagTypeKfactor AND Active = 1          
        --      UPDATE [TCD].ModuleTags SET Active = 0 WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND TagType = @TagTypeCalibration AND Active = 1          
        --    END          
        --END          
        -----Tags---             
                 
        SELECT TOP 1          
          @OutputControllerEquipmentSetupId = O.ControllerEquipmentSetupId          
        FROM @OutputList   O          
          
        IF @@TRANCOUNT > 0          
         COMMIT          
      END TRY          
      BEGIN CATCH          
        IF @@TRANCOUNT > 0          
         ROLLBACK          
                 
        SELECT /*@ErrorNumber    =  ERROR_NUMBER()          
         , */@ErrorMessage    =  ERROR_MESSAGE()          
         , @ErrorProcedure    =  ERROR_PROCEDURE()          
         , @ErrorSeverity    =  ERROR_SEVERITY()          
                 
        SET  @OutputControllerEquipmentSetupId          
                 =  NULL          
        SET  @ReturnValue    =  -1          
        SET  @MessageString    =  N'An error occured while Updating Pump/Valve details. The error is: '          
                 +  @ErrorMessage + ' '          
                 +  'Module: ' + @ErrorProcedure          
                 
        RAISERROR(@MessageString, @ErrorSeverity, 1)          
      END CATCH          
     END          
  END          
ELSE          
  BEGIN          
    DECLARE @NewPumpId INT = NULL          
    SELECT @DistinctChemicalCount    =   COUNT(DISTINCT D.ProductId) --distinct count          
    FROM (          
      SELECT @ProductId     AS   ProductId     --being assigned          
      UNION          
      SELECT DISTINCT ProductId  AS   ProductId     --already assigned          
      FROM [TCD].ControllerEquipmentSetup          
      WHERE ControllerId    =   @ControllerId          
       AND ProductId     <>   @ProductId          
      ) D          
          
    IF ( @DistinctChemicalCount > @MaximumChemicalCount )          
    BEGIN          
      SET @ErrorId   = 51000          
      SET @ErrorMessage  = N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Maximum chemical count exceeded. Cannot assign new chemical'          
      --GOTO ErrorHandler          
      RAISERROR (@ErrorMessage, 16, 1)          
      SET @ReturnValue = -1          
      RETURN (@ReturnValue)          
    END          
          
    --IF(@RoleId =8)          
    --BEGIN          
    --  IF(@LfsChemicalNameTag IS NOT NULL AND @LfsChemicalNameTag <> '')          
    --   BEGIN          
    --   EXEC @Result1 = TCD.CheckDuplicateTag @LfsChemicalNameTag, @ControllerID          
    --   IF(@Result1 = 0)          
    --   BEGIN          
    --   SET @ErrorMessage = '801,'          
    --   END          
    --  END          
    --  IF(@KfactorTag IS NOT NULL AND @KfactorTag <> '')          
    --   BEGIN          
    --    EXEC @Result2 = TCD.CheckDuplicateTag @KfactorTag,@ControllerID          
    --    IF(@Result2 = 0)          
    --    BEGIN          
    --    SET @ErrorMessage = @ErrorMessage+'802,'          
    --    END       
    --   END          
    --  IF(@CalibrationTag IS NOT NULL AND @CalibrationTag <> '')          
    --   BEGIN          
    --    EXEC @Result3 = TCD.CheckDuplicateTag @CalibrationTag,@ControllerID          
    --    IF(@Result3 = 0)          
    --    BEGIN          
    --    SET @ErrorMessage = @ErrorMessage+'803,'          
    --    END          
    --   END          
    --END          
          
    --SET @ErrorMessage = @ErrorMessage + CONVERT(VARCHAR(100),'')          
    --IF(@ErrorMessage <> '')          
    -- RAISERROR(@ErrorMessage, 16, 1)          
    ELSE          
     BEGIN          
      BEGIN TRY          
        BEGIN TRAN          
          
        INSERT [TCD].ControllerEquipmentSetup  (          
             EcoLabAccountNumber          
        ,    ControllerId          
        ,    ControllerEquipmentId          
        ,    ControllerEquipmentTypeId          
        ,    ProductId          
        ,    IsActive          
        ,    LfsChemicalName          
        ,    KFactor          
        ,    PumpCalibration          
        ,    TunnelHold          
        ,    FlowDetectorType     
        ,     FlowSwitchNumber       
        ,    FlowSwitchAlarm          
        ,    FlowMeterAlarm          
        ,    FlowMeterType          
        ,    FlowAlarmDelay          
        ,    FlowMeterPumpDelay          
        ,    FlowMeterAlarmDelay          
        , ControllerEquipmentTypeModelId           
        , ConventionalWasherGroupConnection           
        , AxillaryPumpCalibration             
        , FlowmeterSwitchActivated             
        , FlushWhileDosing               
        , WeightControlledDosage              
        , EquipmentDoseAlone                 
        , LowLevelAlarm                    
        , LeakageAlarm                    
        , FlushTime                   
        , PumpingTime                  
        , PreFlushTime                  
        , NightFlushPauseTime                 
        , NightFlushTime                  
        , AcceptedDeviation                 
        , LineNumber                 
        , MaximumDosingTime              
        , FlowSwitchTimeOut   
       , ValveOutputAsTom         
        , LastModifiedByUserId            
       --** Adding a part of integration with Synch./Central -->          
        , LastModifiedTime          
        , FlushValveNumber              
       , CalibrationConductSS_Tank           
       , BackFlowControl                
       , FactorFM_B_FM                    
       , AcceptedDeviationRingLine           
       , UsePumpOfGroup1ForTunnel             
       , pHSensorEnabled      
    , FlushTimeForFlushValve    
       , Concentration       
       , Deadband      
        , MinimumFlowRate 
  , ProductDensity 
  , MaximumConcentration
        )          
       OUTPUT inserted.ControllerEquipmentSetupId   AS   ControllerEquipmentSetupId          
        , inserted.LastModifiedTime     AS   LastModifiedTime          
       INTO @OutputList (          
         ControllerEquipmentSetupId          
        , LastModifiedTimestamp          
        )          
       --** <--          
       SELECT @EcoLabAccountNumber    AS   EcoLabAccountNUmber          
        , @ControllerId      AS   ControllerEquipmentId          
        , @ControllerEquipmentId    AS   ControllerEquipmentId          
        , @ControllerEquipmentTypeId   AS   ControllerEquipmentTypeId          
        , @ProductId      AS   ProductId          
        , @IsActive       AS   IsActive          
          
        , LfsChemicalName     =   CASE @IsActive WHEN 'TRUE' THEN @LfsChemicalName   ELSE NULL END          
        , KFactor       =   CASE @IsActive WHEN 'TRUE' THEN @KFactor     ELSE NULL END          
        , PumpCalibration     =   CASE @IsActive WHEN 'TRUE' THEN @PumpCalibration   ELSE NULL END          
              
        , TunnelHold      =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @TunnelHold   ELSE NULL END ELSE NULL END          
        , FlowDetectorType     =   CASE @IsActive WHEN 'TRUE' THEN CASE WHEN @ControllerTypeId IN (2,6,7, 12,10, 14,8, 13,9,11) THEN @FlowDetectorType  ELSE NULL END ELSE NULL END          
        , FlowSwitchNumber        =    @FlowSwitchNumber  
        , FlowSwitchAlarm     =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowSwitchAlarm  ELSE NULL END ELSE NULL END          
      , FlowMeterAlarm      =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterAlarm  ELSE NULL END ELSE NULL END          
        , FlowMeterType      =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterType   ELSE NULL END ELSE NULL END          
        , FlowAlarmDelay      =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowAlarmDelay  ELSE NULL END ELSE NULL END          
        , FlowMeterPumpDelay     =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterPumpDelay  ELSE NULL END ELSE NULL END          
        , FlowMeterAlarmDelay     =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterAlarmDelay ELSE NULL END ELSE NULL END          
        , ControllerEquipmentTypeModelId  =   CASE @IsActive WHEN 'TRUE' THEN @ControllerEquipmentTypeModelId      ELSE NULL END          
        , ConventionalWasherGroupConnection      =   CASE @IsActive WHEN 'TRUE' THEN @ConventionalWasherGroupConnection  ELSE 0 END          
        , AxillaryPumpCalibration        =   CASE @IsActive WHEN 'TRUE' THEN @AxillaryPumpCalibration    ELSE 0 END          
        , FlowmeterSwitchActivated        =   CASE @IsActive WHEN 'TRUE' THEN @FlowmeterSwitchActivated   ELSE 0 END          
        , FlushWhileDosing          =   CASE @IsActive WHEN 'TRUE' THEN @FlushWhileDosing      ELSE 0 END          
        , WeightControlledDosage         =   CASE @IsActive WHEN 'TRUE' THEN @WeightControlledDosage     ELSE 0 END          
        , EquipmentDoseAlone            =   CASE @IsActive WHEN 'TRUE' THEN @EquipmentDoseAlone        ELSE 0 END          
        , LowLevelAlarm               =   CASE @IsActive WHEN 'TRUE' THEN @LowLevelAlarm           ELSE 0 END          
        , LeakageAlarm               =   CASE @IsActive WHEN 'TRUE' THEN @LeakageAlarm           ELSE 0 END          
        , FlushTime              =   CASE @IsActive WHEN 'TRUE' THEN @FlushTime         ELSE NULL END          
        , PumpingTime             =   CASE @IsActive WHEN 'TRUE' THEN @PumpingTime         ELSE NULL END          
        , PreFlushTime             =   CASE @IsActive WHEN 'TRUE' THEN @PreFlushTime         ELSE NULL END          
        , NightFlushPauseTime            =   CASE @IsActive WHEN 'TRUE' THEN @NightFlushPauseTime       ELSE NULL END          
        , NightFlushTime             =   CASE @IsActive WHEN 'TRUE' THEN @NightFlushTime  ELSE NULL END          
        , AcceptedDeviation            =   CASE @IsActive WHEN 'TRUE' THEN @AcceptedDeviation        ELSE NULL END          
        , LineNumber           =   CASE @IsActive WHEN 'TRUE' THEN @LineNumber           ELSE NULL END          
        , MaximumDosingTime         =   CASE @IsActive WHEN 'TRUE' THEN @MaximumDosingTime     ELSE NULL END          
        , FlowSwitchTimeOut     =   CASE @IsActive WHEN 'TRUE' THEN @FlowSwitchTimeOut     ELSE NULL END         
       , ValveOutputAsTom               =   CASE @IsActive WHEN 'TRUE' THEN @ValveOutputAsTom           ELSE 0 END     
         
        --, CASE @IsActive WHEN 'TRUE' THEN @FlowMeterSwitchFlag ELSE NULL END AS FlowMeterSwitchFlag           
        --, CASE @IsActive WHEN 'TRUE' THEN @FlowMeterCalibration ELSE NULL END AS FlowMeterCalibration          
        --, CASE @IsActive WHEN 'TRUE' THEN @MaximumDosingTime ELSE NULL END AS MaximumDosingTime          
        --, CASE @IsActive WHEN 'TRUE' THEN @FlowSwitchTimeOut ELSE NULL END AS FlowSwitchTimeOut          
        , @UserId        AS   LastModifiedByUserId          
        --Synch./Central integration additions          
        , @CurrentUTCTime      AS   LastModifiedTime          
       , FlushValveNumber  =   CASE @IsActive WHEN 'TRUE' THEN @FlushValveNumber     ELSE NULL END           
       , CalibrationConductSS_Tank =   CASE @IsActive WHEN 'TRUE' THEN @CalibrationConductSS_Tank     ELSE NULL END         
       , BackFlowControl  =   CASE @IsActive WHEN 'TRUE' THEN @BackFlowControl     ELSE 'False' END            
       , FactorFM_B_FM   =   CASE @IsActive WHEN 'TRUE' THEN @FactorFM_B_FM     ELSE NULL END                
       , AcceptedDeviationRingLine =   CASE @IsActive WHEN 'TRUE' THEN @AcceptedDeviationRingLine     ELSE NULL END           
       , UsePumpOfGroup1ForTunnel =   CASE @IsActive WHEN 'TRUE' THEN @UsePumpOfGroup1ForTunnel     ELSE NULL END             
       , pHSensorEnabled    =   CASE @IsActive WHEN 'TRUE' THEN @pHSensorEnabled     ELSE NULL END    
    , FlushTimeForFlushValve = @FlushTimeForFlushValve     
       , Concentration =   CASE @IsActive WHEN 'TRUE' THEN @Concentration     ELSE NULL END             
       , Deadband    =   CASE @IsActive WHEN 'TRUE' THEN @Deadband     ELSE NULL END       
        , MinimumFlowRate = CASE @IsActive WHEN 'TRUE' THEN @MinimumFlowRate     ELSE NULL END  
       , ProductDensity = CASE @IsActive WHEN 'TRUE' THEN @ProductDensity     ELSE NULL END
       , MaximumConcentration = CASE @IsActive WHEN 'TRUE' THEN @MaximumConcentration     ELSE NULL END 
        SET @NewPumpId = SCOPE_IDENTITY()           
               
        ---Tags---          
        --IF(@RoleId =8)          
        -- BEGIN          
        --   IF(@IsActive = 'TRUE')          
        --    BEGIN          
        --      IF(@LfsChemicalNameTag IS NOT NULL AND @LfsChemicalNameTag <> '')           
        --        INSERT INTO TCD.ModuleTags (EcolabAccountNumber ,TagType,TagAddress,ModuleTypeId,ModuleId,DeadBand,Active)          
        --        VALUES(@EcoLabAccountNumber ,@TagTypeLfs,@LfsChemicalNameTag,@ModuleType,@NewPumpId,@DefaultFrequency,1)          
          
        --      IF(@KfactorTag IS NOT NULL AND @KfactorTag <> '')           
        --        INSERT INTO TCD.ModuleTags (EcolabAccountNumber ,TagType,TagAddress,ModuleTypeId,ModuleId,DeadBand,Active)          
        --        VALUES(@EcoLabAccountNumber ,@TagTypeKfactor,@KfactorTag,@ModuleType,@NewPumpId,@DefaultFrequency,1)          
          
        --      IF(@CalibrationTag IS NOT NULL AND @CalibrationTag  <> '')           
        --        INSERT INTO TCD.ModuleTags (EcolabAccountNumber ,TagType,TagAddress,ModuleTypeId,ModuleId,DeadBand,Active)          
        --        VALUES(@EcoLabAccountNumber ,@TagTypeCalibration,@CalibrationTag,@ModuleType,@NewPumpId,@DefaultFrequency,1)          
        --    END          
        -- END          
        -----Tags---          
        SET @ErrorId = @@ERROR          
        IF (@ErrorId <> 0)          
         BEGIN          
          IF @@TRANCOUNT >0          
           ROLLBACK          
          
          SET  @ErrorMessage  = N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred associating Equipment to Controller'          
          --GOTO Errorhandler          
          RAISERROR (@ErrorMessage, 16, 1)          
          SET @ReturnValue = -1      
         RETURN (@ReturnValue)          
       END          
          
        SELECT TOP 1          
          @OutputControllerEquipmentSetupId = O.ControllerEquipmentSetupId          
        FROM @OutputList   O          
          
        IF @@TRANCOUNT > 0          
         COMMIT          
      END TRY          
      BEGIN CATCH          
        IF @@TRANCOUNT > 0          
         ROLLBACK          
                 
        SELECT /*@ErrorNumber    =  ERROR_NUMBER()          
         , */@ErrorMessage    =  ERROR_MESSAGE()          
         , @ErrorProcedure    =  ERROR_PROCEDURE()          
         , @ErrorSeverity    =  ERROR_SEVERITY()          
                 
        SET  @OutputControllerEquipmentSetupId          
                 =  NULL          
        SET  @ReturnValue    =  -1          
        SET  @MessageString    =  N'An error occured while Updating Pump/Valve details. The error is: '          
                 +  @ErrorMessage + ' '          
                 +  'Module: ' + @ErrorProcedure          
                 
        RAISERROR(@MessageString, @ErrorSeverity, 1)          
      END CATCH          
     END          
  END          
     
  -------------------------------------------
  IF((SELECT CONTROLLERMODELID FROM TCD.ConduitController WHERE ControllerId=@ControllerId)='11')
  BEGIN
	IF(@ControllerEquipmentTypeId=2 AND @ControllerEquipmentId IN(13,14,27,28))
	BEGIN

		UPDATE TCD.ControllerEquipmentSetup  SET CalibrationConductSS_Tank=@CalibrationConductSS_Tank
		WHERE EcoLabAccountNumber=@EcoLabAccountNumber AND	ControllerId=@ControllerId AND ControllerEquipmentTypeId=@ControllerEquipmentTypeId
		AND ControllerEquipmentId=CASE WHEN @ControllerEquipmentId=13 THEN 27 
								   WHEN @ControllerEquipmentId=27 THEN 13  	
								   WHEN @ControllerEquipmentId=14 THEN 28
								   WHEN @ControllerEquipmentId=28 THEN 14 END 
	END
  END	
  -------------------------------------------
                 
  IF ( @ErrorId = 0 )          
 BEGIN          
  --GOTO ExitModule          
  RETURN (@ReturnValue)          
 END          
          
          
  --ErrorHandler:          
--RAISERROR (@ErrorMessage, 16, 1)          
--SET @ReturnValue = -1          
          
          
          
          
--ExitModule:          
          
SET NOCOUNT OFF          
RETURN (@ReturnValue)          
          
          
END  
/*
END TCD.SaveControllerEquipment

*/


/*
Start TCD.GetWasherProductDeviationData

*/
GO
IF OBJECT_ID('[TCD].[GetWasherProductDeviationData]') is not null
BEGIN
	DROP proc [TCD].GetWasherProductDeviationData
	
END

GO
CREATE PROCEDURE [TCD].[GetWasherProductDeviationData](
	 @WasherId INT
	,@controllerId INT
    , @EcolabAccountNumber NVARCHAR(25))
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE
	    @plantId INT = (SELECT P.PlantId
					  FROM TCD.Plant P
					  WHERE P.EcolabAccountNumber = @EcolabAccountNumber);

	DECLARE @WasherProductDeviationCount INT = (Select COUNT(WasherProductDeviationID) from TCD.WasherProductDeviations where ControllerId = @controllerId AND WasherId = @WasherId)
	DECLARE @ControllerEquipmentSetupCount INT = (Select COUNT(ControllerEquipmentSetupId) from TCD.ControllerEquipmentSetup where ControllerId = @controllerId)

IF(@WasherProductDeviationCount = 0)
	BEGIN
		SELECT	WPD.WasherProductDeviationID,
				CES.ControllerEquipmentId,
				PM.Name,
				CASE CES.ConventionalWasherGroupConnection 
						WHEN 0 THEN 0
						WHEN 1 THEN CAST(ISNULL(wpd.ProductDeviation,100) AS int)
						END ProductDeviation,
				ISNULL(CES.ConventionalWasherGroupConnection,0)
				,PM.EnvisionDisplayName
		FROM
						TCD.ControllerEquipmentSetup CES 
			LEFT JOIN	TCD.WasherProductDeviations WPD	ON	WPD.ControllerId = CES.ControllerId
														AND WPD.ControllerEquipmentID = CES.ControllerEquipmentId
			LEFT JOIN	TCD.ProductMaster PM				ON	PM.ProductId = CES.ProductId
		WHERE CES.ControllerId = @controllerId

		ORDER BY WPD.ControllerEquipmentId

	END
ELSE
	BEGIN
		   SELECT 
					WPD.WasherProductDeviationID,
					WPD.ControllerEquipmentId,
					PM.Name,
					CASE CES.ConventionalWasherGroupConnection 
						WHEN 0 THEN 0
						WHEN 1 THEN CAST(ISNULL(wpd.ProductDeviation,100) AS int)
						END ProductDeviation,
					ISNULL(CES.ConventionalWasherGroupConnection,0),
					PM.EnvisionDisplayName
			FROM 
							TCD.WasherProductDeviations WPD
				LEFT JOIN	TCD.ControllerEquipmentSetup CES	ON	WPD.ControllerId = CES.ControllerId
																AND WPD.ControllerEquipmentID = CES.ControllerEquipmentId 
																AND wpd.WasherId = @WasherId
				LEFT JOIN	TCD.ProductMaster PM				ON	PM.ProductId = CES.ProductId

		WHERE WPD.ControllerId = @controllerId AND PlantId = @plantId

		ORDER BY WPD.ControllerEquipmentId
	END
   SET NOCOUNT OFF;
END;

/*
END TCD.GetWasherProductDeviationData

*/

/*
Start TCD.SaveControllerSetupData

*/
GO
IF OBJECT_ID('[TCD].[SaveControllerSetupData]') is not null
BEGIN
	DROP proc [TCD].SaveControllerSetupData
	
END

GO
CREATE PROCEDURE [TCD].[SaveControllerSetupData]
(
@ControllerSetupData     XML
, @UserId         INT
, @ControllerId       INT      OUTPUT
, @LastModifiedTimestampAtCentral   DATETIME = NULL
, @OutputLastModifiedTimestampAtLocal  DATETIME = NULL OUTPUT
)
AS
BEGIN
SET NOCOUNT ON

--DECLARE @ControllerId INT
DECLARE @ControllerNumber INT = NULL
DECLARE @ControllerModelId INT = NULL
DECLARE @ControllerModelName VARCHAR(50) = NULL
DECLARE @ControllerTypeId INT = NULL
DECLARE @ControllerTypeName VARCHAR(50) = NULL
DECLARE @EcolabAccountNumber NVARCHAR(25) = NULL
DECLARE @TopicName VARCHAR(1000) = NULL
DECLARE @Active BIT
DECLARE @ErrorMessage VARCHAR(200) = NULL
DECLARE @NumOfConvWasherGroups INT = NULL
DECLARE @NumOfTunnelWasherGroups INT = NULL
DECLARE @LoopCount INT = 0
DECLARE @WasherGroupName VARCHAR(100) = NULL
DECLARE @WasherGroupId INT = NULL
DECLARE @WasherGroupNumber VARCHAR(10) = NULL
DECLARE @OutputList AS TABLE (
ControllerId INT
,LastModifiedTimestamp DATETIME
)

SET @ControllerId = ISNULL(@ControllerId, NULL) --SQLEnlight SA0121
SET @OutputLastModifiedTimestampAtLocal = ISNULL(@OutputLastModifiedTimestampAtLocal, NULL) --SQLEnlight SA0121

SELECT @ControllerNumber = Tbl.col.value('@ControllerNumber', 'int')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)

SELECT @ControllerModelId = Tbl.col.value('@ControllerModelId', 'int')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)

SELECT @ControllerTypeId = Tbl.col.value('@ControllerTypeId', 'int')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)

SELECT @EcolabAccountNumber = Tbl.col.value('@EcolabAccountNumber', 'varchar(1000)')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)

SELECT @TopicName = Tbl.col.value('@TopicName', 'varchar(1000)')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)

SELECT @Active = Tbl.col.value('@Active', 'bit')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)

IF EXISTS (
SELECT 1
FROM [TCD].ConduitController WITH (NOLOCK)
WHERE ControllerNumber = @ControllerNumber
AND IsDeleted = 0
AND EcoalabAccountNumber = @EcolabAccountNumber
)
BEGIN
SET @ErrorMessage = '303 - Controller Number already exists.'

RAISERROR (
@ErrorMessage
,16
,1
)

RETURN
END

IF EXISTS (
SELECT 1
FROM [TCD].ConduitController WITH (NOLOCK)
WHERE TopicName = @TopicName
AND IsDeleted = 0
AND EcoalabAccountNumber = @EcolabAccountNumber
)
BEGIN
SET @ErrorMessage = '304 - Controller Name already exists.'

RAISERROR (
@ErrorMessage
,16
,1
)

RETURN
END




SELECT @ControllerModelName = NAME
FROM [TCD].ControllerModel WITH (NOLOCK)
WHERE Id = @ControllerModelId

SELECT @ControllerTypeName = NAME
FROM [TCD].ControllerType WITH (NOLOCK)
WHERE Id = @ControllerTypeId

DECLARE @TempMaster TABLE (
EcolabAccountNumber NVARCHAR(25)
,NAME VARCHAR(100)
,ControllerModelId INT
,ControllerNumber INT
,ControllerTypeId INT
,ControllerVersion VARCHAR(10)
,InstallDate DATETIME
,UserId INT
,TopicName VARCHAR(1000)
,Active BIT
)
DECLARE @TempDynamic TABLE (
EcolabAccountNumber NVARCHAR(25)
,ControllerId INT
,ControllerModelId INT
,FieldGroupId INT
,FieldId INT
,Value VARCHAR(1000)
,UserId INT
)


INSERT INTO @TempDynamic (
EcolabAccountNumber
,ControllerId
,ControllerModelId
,FieldGroupId
,FieldId
,Value
,UserId
)
SELECT @EcolabAccountNumber
,0
,Tbl.col.value('@ControllerModelId', 'int')
,Tbl.col.value('@FieldGroupId', 'int')
,Tbl.col.value('@FieldId', 'int')
,Tbl.col.value('@Value', 'varchar(1000)')
,@UserId
FROM @ControllerSetupData.nodes('/ControllerSetupData/DynamicSetupData/Data') AS Tbl(col)

DECLARE @TempFieldId INT
DECLARE @TempValue VARCHAR(1000)


SELECT @TempFieldId=FieldId,@TempValue=Value FROM @TempDynamic WHERE FieldId in (21,22,47,48,87,98,116,130,148,150,171,192,208,269,309,348,387,400,414,426,438,449,460)


IF EXISTS ( SELECT 1
            FROM  [TCD].conduitController CC WITH (NOLOCK) 
			INNER JOIN [TCD].ControllerSetupData CSD ON cc.ControllerId=csd.ControllerId 
			AND CC.Active=1
			and CSD.FieldId=@TempFieldId
			and CSD.Value =@TempValue
			and CC.ControllerTypeId=@ControllerTypeId
			and CC.ControllerModelId=@ControllerModelId
			and CC.EcoalabAccountNumber=@EcolabAccountNumber)
BEGIN
SET @ErrorMessage = '305 -IP Address/AMS Net ID Address already exists.'

RAISERROR (
@ErrorMessage
,16
,1
)

RETURN
END

BEGIN TRANSACTION

BEGIN TRY
INSERT INTO @TempMaster (
EcolabAccountNumber
,NAME
,ControllerModelId
,ControllerNumber
,ControllerTypeId
,ControllerVersion
,InstallDate
,UserId
,TopicName
,Active
)
SELECT @EcolabAccountNumber
,CAST(Tbl.col.value('@ControllerNumber', 'int') AS VARCHAR(10)) + ' (' + Tbl.col.value('@TopicName', 'varchar(100)') + ')'
,Tbl.col.value('@ControllerModelId', 'int')
,Tbl.col.value('@ControllerNumber', 'int')
,Tbl.col.value('@ControllerTypeId', 'varchar(100)')
,Tbl.col.value('@ControllerVersion', 'varchar(10)')
,CAST(Tbl.col.value('@InstallDate', 'datetime') AS DATETIME)
,@UserId
,Tbl.col.value('@TopicName', 'varchar(100)')
,Tbl.col.value('@Active', 'bit')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)

INSERT INTO [TCD].ConduitController (
EcoalabAccountNumber
,NAME
,ControllerModelId
,ControllerNumber
,ControllerTypeId
,ControllerVersion
,InstallDate
,TopicName
,Active
,LastModifiedByUserId
)
OUTPUT inserted.ControllerId AS ControllerId
,inserted.LastModifiedTime AS LastModifiedTimestamp
INTO @OutputList(ControllerId, LastModifiedTimestamp)
SELECT EcolabAccountNumber
,NAME
,ControllerModelId
,ControllerNumber
,ControllerTypeId
,ControllerVersion
,InstallDate
,TopicName
,Active
,UserId
FROM @TempMaster

SELECT TOP 1 @ControllerId = O.ControllerId
FROM @OutputList O

update @TempDynamic set ControllerId=@ControllerId

INSERT INTO [TCD].ControllerSetupData (
EcolabAccountNumber
,ControllerId
,FieldGroupId
,FieldId
,Value
,ControllerModelId
,LastModifiedByUserId
)
SELECT EcolabAccountNumber
,ControllerId
,FieldGroupId
,FieldId
,Value
,ControllerModelId
,UserId
FROM @TempDynamic

IF @ControllerModelId = 7
OR @ControllerModelId = 8
OR @ControllerModelId = 9
OR @ControllerModelId = 11
OR @ControllerModelId = 10
OR @ControllerModelId = 14
BEGIN
EXEC TCD.SaveDefaultControllerEquipment @ControllerId = @ControllerId
,@EcolabAccountNumber = @EcolabAccountNumber
,@UserId = @UserId;
END;

SELECT @NumOfConvWasherGroups = NumOfConvWasherGroups
,@NumOfTunnelWasherGroups = NumOfTunnelWasherGroups
FROM TCD.ControllerModelControllerTypeMapping
WHERE ControllerModelId = @ControllerModelId
AND ControllerTypeId = @ControllerTypeId

DECLARE @TotalGroupCount INT = 0;
DECLARE @WasherDosingNumber INT = 0;

IF ISNULL(@NumOfConvWasherGroups, 0) > 0
BEGIN
WHILE @LoopCount < @NumOfConvWasherGroups
            BEGIN
                SET @WasherGroupName = @TopicName + ' Dosing Group ' + CAST(@TotalGroupCount + 1 AS VARCHAR(10));
                SET @WasherDosingNumber = @TotalGroupCount + 1;

                EXEC TCD.SaveMachineGroup @GroupDescription = @WasherGroupName
                    ,@GroupTypeId = 2
                    ,@EcolabAccountNumber = @EcolabAccountNumber;

                SELECT @WasherGroupId = Id
                FROM TCD.MachineGroup
                WHERE GroupDescription = @WasherGroupName

                SELECT @WasherGroupNumber = MAX(CAST(WasherGroupNumber AS INT)) + 1
                FROM TCD.WasherGroup

                EXEC TCD.SaveWasherGroup @EcolabAccountNumber = @EcolabAccountNumber
                    ,@WasherGroupId = @WasherGroupId
                    ,@ControllerId = @ControllerId
                    ,@WasherGroupTypeId = 1
                    ,@WasherGroupName = @WasherGroupName
                    ,@WasherGroupNumber = @WasherGroupNumber
                    ,@LastModifiedByUserId = 1
                    ,@WasherDosingNumber = @WasherDosingNumber ;

                SET @LoopCount += 1;
                SET @TotalGroupCount += 1;
            END
        END

        SET @LoopCount = 0;

        IF ISNULL(@NumOfTunnelWasherGroups, 0) > 0
        BEGIN
            WHILE @LoopCount < @NumOfTunnelWasherGroups
            BEGIN
                SET @WasherGroupName = @TopicName + ' Dosing Group ' + CAST(@TotalGroupCount + 1 AS VARCHAR(10));
                SET @WasherDosingNumber = @TotalGroupCount + 1;

                EXEC TCD.SaveMachineGroup @GroupDescription = @WasherGroupName
                    ,@GroupTypeId = 2
                    ,@EcolabAccountNumber = @EcolabAccountNumber;

                SELECT @WasherGroupId = Id
                FROM TCD.MachineGroup
                WHERE GroupDescription = @WasherGroupName

                SELECT @WasherGroupNumber = MAX(CAST(WasherGroupNumber AS INT)) + 1
                FROM TCD.WasherGroup

                EXEC TCD.SaveWasherGroup @EcolabAccountNumber = @EcolabAccountNumber
                    ,@WasherGroupId = @WasherGroupId
                    ,@ControllerId = @ControllerId
                    ,@WasherGroupTypeId = 2
                    ,@WasherGroupName = @WasherGroupName
                    ,@WasherGroupNumber = @WasherGroupNumber
                    ,@LastModifiedByUserId = 1
                    ,@WasherDosingNumber = @WasherDosingNumber;

                SET @LoopCount += 1;
                SET @TotalGroupCount += 1;
            END
        END
    
   DECLARE @TempControllerTypeId INT, 
           @MaxInjectionClasses INT
   SELECT @TempControllerTypeId = ControllerTypeId FROM TCD.ConduitController WHERE ControllerId = @ControllerId

   IF (@TempControllerTypeId = 1)
   BEGIN
    SET @MaxInjectionClasses = 6
   END

    IF (@TempControllerTypeId = 2)
   BEGIN
    SET @MaxInjectionClasses = 8
   END
    
    UPDATE tcd.ConduitController SET LFSInjectionClasses = @MaxInjectionClasses where ControllerId = @ControllerId
 
            COMMIT TRANSACTION

        SELECT TOP 1 @OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp
        FROM @OutputList O
        END TRY

        BEGIN CATCH
        SELECT ERROR_NUMBER() AS ErrorNumber
            ,ERROR_SEVERITY() AS ErrorSeverity
            ,ERROR_STATE() AS ErrorState
            ,ERROR_PROCEDURE() AS ErrorProcedure
            ,ERROR_LINE() AS ErrorLine
            ,ERROR_MESSAGE() AS ErrorMessage

            ROLLBACK TRANSACTION
        END CATCH

SET NOCOUNT OFF
END
/*
END TCD.SaveControllerSetupData

*/



/*
Start TCD.UpdateControllerSetupData

*/
GO
IF OBJECT_ID('[TCD].[UpdateControllerSetupData]') is not null
BEGIN
	DROP proc [TCD].UpdateControllerSetupData
	
END

GO
CREATE PROCEDURE [TCD].[UpdateControllerSetupData](
		@ControllerSetupData					XML
	,	@UserId									INT
	,	@LastModifiedTimestampAtCentral			DATETIME = NULL
	,	@OutputLastModifiedTimestampAtLocal		DATETIME =	NULL	OUTPUT
)
AS
BEGIN
      SET NOCOUNT ON

	  DECLARE @EcolabAccountNumber	VARCHAR(1000)	=		NULL
	  DECLARE @ControllerId			INT				=		NULL
	  DECLARE @TopicName VARCHAR(1000) = NULL
	  DECLARE @ControllerModelId INT = NULL
	  DECLARE @ControllerTypeId INT = NULL

	  DECLARE @OutputList AS TABLE(	LastModifiedTimestamp	DATETIME)

	  DECLARE	
		@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()	  
	  
	  DECLARE @TempMaster TABLE (
				ControllerId			INT
		   ,	EcolabAccountNumber		VARCHAR(1000)
		   ,	Name					VARCHAR(100)
           ,	ControllerModelId		INT
           ,	ControllerNumber		INT
           ,	ControllerTypeId		INT
           ,	ControllerVersion		VARCHAR(10)
           ,	InstallDate				DATETIME
		   ,	TopicName				VARCHAR(1000)
		   ,	Active					BIT
        )

		DECLARE @TempDynamic TABLE(
				ControllerId			INT
			,	EcolabAccountNumber		VARCHAR(1000)
			,	ControllerModelId		INT
           ,	FieldGroupId			INT
           ,	FieldId					INT
           ,	Value					VARCHAR(1000)
        )

	SET		@OutputLastModifiedTimestampAtLocal=ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight

	SELECT @EcolabAccountNumber = Tbl.col.value('@EcolabAccountNumber', 'varchar(1000)')
			  FROM   @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl (col)

	SELECT @ControllerId = Tbl.col.value('@ControllerId', 'int')
			  FROM   @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl (col)
	SELECT @TopicName = Tbl.col.value('@TopicName', 'varchar(1000)')
		FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)

    IF	(@LastModifiedTimestampAtCentral IS NOT	NULL
			AND NOT	EXISTS	(SELECT	1
								FROM TCD.ConduitController	CC
											WHERE	CC.EcoalabAccountNumber		=	@EcolabAccountNumber
												AND	CC.ControllerId				=	@ControllerId
												AND	CC.LastModifiedTime			=	@LastModifiedTimestampAtCentral
										)
				)
			BEGIN
					SET	@ErrorId	=	60000
					SET	@ErrorMessage	=	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
					RAISERROR	(@ErrorMessage, 16, 1)
					RETURN
			END

INSERT INTO @TempMaster
                  (
				    ControllerId
					,	EcolabAccountNumber
					,	ControllerModelId
					,	ControllerNumber
					,	ControllerTypeId
					,	ControllerVersion
					,	InstallDate
					,	TopicName
					,	Active
					)
			  SELECT 
					@ControllerId
				,	@EcolabAccountNumber
				,	Tbl.col.value('@ControllerModelId', 'int')
				,	Tbl.col.value('@ControllerNumber', 'int')
				,	Tbl.col.value('@ControllerTypeId', 'int')
				,	Tbl.col.value('@ControllerVersion', 'varchar(10)')
				,	CAST(Tbl.col.value('@InstallDate', 'datetime') AS DATETIME)
				,	Tbl.col.value('@TopicName', 'varchar(1000)')
				,	Tbl.col.value('@Active', 'bit')
			  FROM   @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl (col)

INSERT INTO @TempDynamic(
						ControllerId
						,	EcolabAccountNumber						
						,	ControllerModelId
						,	FieldGroupId
						,	FieldId
						,	Value
						)
			SELECT Tbl.col.value('@ControllerId', 'int')
				,	@EcolabAccountNumber
				,	Tbl.col.value('@ControllerModelId', 'int')
				,	Tbl.col.value('@FieldGroupId', 'int')
				,	Tbl.col.value('@FieldId', 'int')
				,	Tbl.col.value('@Value', 'varchar(1000)')
			FROM   @ControllerSetupData.nodes('/ControllerSetupData/DynamicSetupData/Data') AS Tbl (col)

/*Validating Controle name duplicate*/
IF EXISTS ( SELECT 1
			FROM [TCD].ConduitController WITH (NOLOCK)
			WHERE TopicName = @TopicName AND IsDeleted = 0 AND ControllerId!=@ControllerId
			AND EcoalabAccountNumber = @EcolabAccountNumber)
BEGIN
		SET @ErrorMessage = '304 - Controller Name already exists.'
		RAISERROR ( @ErrorMessage,16,1)
RETURN
END



DECLARE @TempFieldId INT
DECLARE @TempValue VARCHAR(1000)


SELECT @TempFieldId=FieldId,@TempValue=Value FROM @TempDynamic WHERE FieldId in (21,22,47,48,87,98,116,130,148,150,171,192,208,269,309,348,387,400,414,426,438,449,460)

SELECT @ControllerTypeId=ControllerTypeId,@ControllerModelId=ControllerModelId FROM @TempMaster

IF EXISTS ( SELECT 1
            FROM  [TCD].conduitController CC WITH (NOLOCK) 
			INNER JOIN [TCD].ControllerSetupData CSD ON cc.ControllerId=csd.ControllerId 
			AND CC.Active=1
			and CSD.FieldId=@TempFieldId
			and CSD.Value =@TempValue
			and CC.ControllerTypeId=@ControllerTypeId
			and CC.ControllerModelId=@ControllerModelId
			AND CC.ControllerId!=@ControllerId
			and CC.EcoalabAccountNumber=@EcolabAccountNumber)
BEGIN
		SET @ErrorMessage = '305 -IP Address/AMS Net ID Address already exists.'
		RAISERROR (@ErrorMessage,16,1)
		RETURN
END


	BEGIN TRANSACTION
		BEGIN TRY	
					
			UPDATE [TCD].ConduitController
			SET ControllerVersion		=	tm.ControllerVersion
			,	InstallDate				=	tm.InstallDate
			,	TopicName				=	tm.TopicName
			,	Active					=	tm.Active
			,	LastModifiedByUserId	=	@UserId
			,	LastModifiedTime		=	@CurrentUTCTime
			,	Name					=	CAST(tm.ControllerNumber AS varchar(10))+'('+tm.TopicName+')'
			OUTPUT inserted.LastModifiedTime AS LastModifiedTimestamp INTO @OutputList( LastModifiedTimestamp )
			FROM [TCD].ConduitController CC
			INNER JOIN @TempMaster tm ON tm.ControllerId = CC.ControllerId AND tm.EcolabAccountNumber = CC.EcoalabAccountNumber			


			UPDATE [TCD].ControllerSetupData 
			SET Value = td.Value
			,	LastModifiedByUserId	=	@UserId
			FROM [TCD].ControllerSetupData CSD
			INNER JOIN @TempDynamic td ON td.ControllerId = CSD.ControllerId AND td.FieldGroupId = CSD.FieldGroupId
										AND td.FieldId = CSD.FieldId AND td.ControllerModelId = CSD.ControllerModelId
										AND td.EcolabAccountNumber = CSD.EcolabAccountNumber
	
			SELECT	TOP 1 @OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp FROM	@OutputList	O

			COMMIT TRANSACTION
		END TRY
		BEGIN CATCH
			SELECT 
				ERROR_NUMBER() AS ErrorNumber,
				ERROR_SEVERITY() AS ErrorSeverity,
				ERROR_STATE() AS ErrorState,
				ERROR_PROCEDURE() AS ErrorProcedure,
				ERROR_LINE() AS ErrorLine,
				ERROR_MESSAGE() AS ErrorMessage
			ROLLBACK TRANSACTION
		END CATCH

END
/*
END TCD.UpdateControllerSetupData

*/


/*
Start TCD.ProcessMyControlTunnelWasherProdData

*/
GO
IF OBJECT_ID('[TCD].[ProcessMyControlTunnelWasherProdData]') is not null
BEGIN
	DROP proc [TCD].ProcessMyControlTunnelWasherProdData
	
END

GO

CREATE PROCEDURE [TCD].[ProcessMyControlTunnelWasherProdData]
	(
	@ControllerID INT,
	@xmlTags xML,
	@PLCPointer INT,
	@ReadPointer INT
)
AS
BEGIN
   DECLARE 
			@BatchID						INT,
			@WasherID						INT,
			@EcolabWasherId					INT,								
			@CurrencyCode					VARCHAR(50),		
			@MachineInternalId				INT,
			@WasherGroupID					INT,
			@PlantWasherNumber				INT,
			@BatchStartDate					DATETIME2,
			@BatchEndDate					DATETIME2,			
			@ProgramNumber					INT,
			@Load							Decimal(10,2),
			@NominalLoad					Decimal(10,2),
			@CustomerNumber					INT,
			@PHStatus						INT,
			@PHValue						INT,
			@LFStatus						INT,
			@LFValue						INT,
			@EjectionSignal					INT,
			@TextTileCategory				INT,
			@BatchNumber					INT,
			@TargetTurnTime					INT,
			@ShiftID						INT,
			@ParameterID					INT,			
			@ShiftName						VARCHAR(50),
			@EcolabAccountNumber NVARCHAR(25) = NULL,
			@PartitionOn DATETIME2,
			@BatchStartTime DATETIME2,
			@BatchEndTime DATETIME2,
			@PorgramParameterID int,
			@PHParameterID int,
			@ConductivityParamID int,
			@RunTime int,
			@TextileCategory int,
			@ProgramID int,
			@NumberOfCompartments int,
			@TempParameter int,
			@PumpNo   INT, 
			@DosingPoint INT,
			@ProductId INT,
			@ActualQuantity Decimal(10,6),
			@CompartmentNum INT,
			@EquipmentType INT,
			@MinTempParamID INT,
			@MaxTempParamID INT,
			@TempStatusParamID INT,			
			@PHValueParamID INT,
			@PHStatusParamID INT,
			@ConductivityValueParamID INT,
			@ConductivityStatusParamID INT
	
	INSERT into MyControlXML (xmlData, BatchType, PLCPointer, ReadPointer, BatchID, comment,LastModified) values (@xmlTags, 'TunnelCompleted', null, null, null, '',getDate())

   	DECLARE @BatchShiftId int
	DECLARE @ShiftStartDateTemp table(ShiftId INT,ShiftName NVARCHAR(50),ShiftStartdate DATETIME)

	DECLARE @compartmentID int,
	 @TunnelXML xml

	SELECT @TunnelXML=T.c.query('.') 
		FROM   @xmlTags.nodes('MyControlTunnel/TunnelData') T(c)
		WHERE T.c.value('@CompartmentNumber', 'INT') = 0
					
	SELECT   @MachineInternalID=T.c.value('@MachineNumber', 'int'),
				  @BatchNumber= T.c.value('@BatchNumber', 'INT'),
 				  @BatchStartTime=T.c.value('@StartDateTime', 'DateTime'),
				  @BatchEndTime=T.c.value('@EndDateTime', 'DateTime'),
				  @ProgramNumber=T.c.value('@ProgramNumber', 'INT'),
				  @Load=T.c.value('@Load', 'Decimal(10,2)'),
				  @NominalLoad=T.c.value('@Nominalload', 'Decimal(10,2)'),
				  @CustomerNumber=T.c.value('@CustomerNumber', 'int'),
				  @PHStatus=T.c.value('@pHStatus', 'int'),
				  @PHValue=T.c.value('@pHValue', 'INT'),
				  @LFStatus=T.c.value('@LFStatus', 'INT'),
				  @LFValue=T.c.value('@LFValue', 'INT'),
				  @RunTime=T.c.value('@RunTime', 'INT'),
				  @EjectionSignal=T.c.value('@EjectionSignal', 'INT'),
				  @TextileCategory=T.c.value('@TextileCategory', 'INT'),
				  @PumpNo=T.c.value('@Number', 'INT'), 
				  @DosingPoint=T.c.value('@Point', 'INT'),
				  @ActualQuantity=T.c.value('@Quantity', 'INT')
		 FROM @xmlTags.nodes('MyControlTunnel/TunnelData')  T(c);
		 
		 
		SELECT 
				@EcolabWasherID=Ws.EcolabWasherId,
				@WasherGroupID= Wg.WasherGroupId,
				@PlantWasherNumber=PlantWasherNumber,
				@WasherID=ws.WasherId,
				@CurrencyCode=P.CurrencyCode,
				@NumberOfCompartments=Mst.NumberofComp
		FROM TCD.Washer Ws
				INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
				INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
				INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
				INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId = Mst.ControllerId
				INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.EcoLabAccountNumber
		WHERE  Ctrl.ControllerID = @ControllerID AND
				Mst.MachineInternalId = @MachineInternalID AND
				Mst.IsTunnel = 1
SELECT @EcolabWasherID
		 SELECT @ProgramID=ProgramId,
				@TargetTurnTime= (3600 / (tps.TotalRunTime /@NumberOfCompartments )) 
		 FROM TCD.TunnelProgramSetup AS tps 
		 WHERE tps.WasherGroupId = @WasherGroupID 
			   and tps.is_deleted =0
			   and ProgramNumber = @ProgramNumber

		 --INSERT #Batches(BatchNumber,StartDateTime)
		 --SELECT @BatchNumber,@BatchStartTime

		 DELETE FROM  @ShiftStartDateTemp;

		 IF (@BatchEndTime is Not Null)
		 BEGIN
			 INSERT INTO @ShiftStartDateTemp(ShiftId,ShiftName,ShiftStartdate) 
			 EXEC TCD.GetShiftStartDate @BatchEndTime,1
		 END
		 ELSE
		 BEGIN
			INSERT INTO @ShiftStartDateTemp(ShiftId,ShiftName,ShiftStartdate) 
			EXEC TCD.GetShiftStartDate @BatchStartTime,1
		 END

		 SELECT @BatchShiftId = ShiftID,
				  @PartitionOn=ShiftStartdate,
				  @ShiftName=ShiftName
		FROM @ShiftStartDateTemp

		
		SELECT @BatchID = Null 	
		 
		SELECT @BatchID=BatchID	FROM TCD.BatchData BD 
				WHERE BD.ControllerBatchId = @BatchNumber
						AND BD.StartDate= @BatchStartTime
						AND BD.MachineId = @WasherID
						--AND BD.MachineInternalID = @MachineInternalID
		IF (@BatchID is Null) 
		BEGIN
				INSERT INTO TCD.BatchData(
					ControllerBatchId ,
					EcolabWasherId,
					GroupId ,
					MachineInternalId,
					PlantWasherNumber,
					StartDate,
					EndDate,
					ProgramNumber,
					ProgramMasterId,
					MachineId,
					ActualWeight,
					StandardWeight,
					CurrencyCode,
					ShiftId,
					PartitionOn,
					TargetTurnTime
				)
			   SELECT @BatchNumber,
					  @EcolabWasherID,
					  @WasherGroupID,
					  @MachineInternalID,
					  @PlantWasherNumber,
					  @BatchStartTime,
					  @BatchEndTime,
					  @ProgramNumber,
					  @ProgramID,
					  @WasherID,
					  @Load,
					  @NominalLoad,
					  @CurrencyCode,
					  @BatchShiftId,
					  @PartitionOn,
					  @TargetTurnTime
				SELECT @BatchID=Scope_Identity()
				
				EXEC TCD.UPDATEBatchWashStepForTunnel @TunnelXML,@WasherID,@BatchID, @BatchStartTime,@PartitionOn,@EcolabWasherId,@NumberOfCompartments				
	 END 
	
	 IF (@BatchEndTime is Not Null and @BatchEndTime !='01/01/1900')
	 BEGIN
		UPDATE TCD.BatchData SET EndDate = @BatchEndTime, ShiftId = @BatchShiftId, PartitionOn = @PartitionOn WHERE BATCHID = @BatchID
	 END 
	 
	 IF(@CustomerNumber is not null)
	 BEGIN
		 IF NOT Exists(SELECT 1 FROM [TCD].[BatchCustomerData] WHERE BatchID = @BatchID)
		 BEGIN
			INSERT INTO [TCD].[BatchCustomerData] ([BatchId],CustomerID,[Weight],PartitionOn,EcolabWasherId)
			SELECT @BatchID,@CustomerNumber,@Load,@PartitionOn,@EcolabWasherId
		 END 
	 END
	 	 
	  CREATE TABLE #DosingDetails(Number INT, 
								  Quantity Decimal(10,6),
								  Point INT,
								  IsMainEquioment INT
								 )
  	 	 
	  INSERT INTO #DosingDetails(Number,Quantity, Point, IsMainEquioment)
	  SELECT 
			T.c.value('@Number', 'INT') AS Number, --PumpNumber
			T.c.value('@Quantity', 'Decimal(10,6)') AS Quantity, --Dosing Quanity
			T.c.value('@Point', 'INT') AS Point,	--Dosing point
			T.c.value('@IsMainEquioment', 'INT') AS IsMainEquioment
								
	  FROM @xmlTags.nodes('MyControlTunnel/TunnelData/Dose') T(C)
	
	  -- Fetching data from cursor
			DECLARE @MYCURSOR CURSOR
			SET @MYCURSOR = CURSOR FAST_FORWARD
			FOR
			SELECT		Number,
						Quantity,										
						Point,
						IsMainEquioment

				FROM #DosingDetails

			DECLARE			@Number				INT,
							@Quantity			Decimal(10,6),
							@Point				INT,
							@IsMainEquioment	INT

			OPEN @MYCURSOR
			FETCH NEXT FROM @MYCURSOR
						INTO 
							@Number,
							@Quantity,
							@Point,
							@IsMainEquioment
							
			WHILE @@FETCH_STATUS = 0			
			BEGIN	
				IF(@IsMainEquioment = 1)
				BEGIN
					SET @EquipmentType = 2
				END
				ELSE
				BEGIN
					SET @EquipmentType = 1
				END

				SELECT @ProductId=CES.ProductId, @CompartmentNum=TCEVM.CompartmentNumber
		    	FROM  tcd.ControllerEquipmentSetup CES INNER JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM
				ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
				WHERE CES.ControllerId=@ControllerID AND
						CES.ControllerEquipmentTypeId=@EquipmentType AND
						--CES.IsActive=1 AND
						--CES.WasherGroupNumber=@WasherGroupNum AND
						TCEVM.DosingPointNumber=@Point AND
						CES.ControllerEquipmentId = @Number
				
				--SELECT @EcolabWasherID
				IF(@ProductId is not null)
				BEGIN
	
					INSERT INTO TCD.BatchProductData 
					(BatchId, StepCompartment, ActualQuantity,[TimeStamp],PartitionOn,EcolabWasherId,ProductId)
					SELECT @BatchID,
						@CompartmentNum,
						@Quantity,
						@BatchEndTime,
						@PartitionOn,
						@EcolabWasherID,
						@ProductId
				END

				FETCH NEXT FROM @MYCURSOR
						INTO 
							@Number,
							@Quantity,
							@Point,
							@IsMainEquioment
			END

			CLOSE @MYCURSOR
			DEALLOCATE @MYCURSOR

			Drop table #DosingDetails
	 
	 	
		SELECT @MinTempParamID=Id 
		FROM [TCD].[ConduitParameters] 
		WHERE Name = 'Minimum Temperature' 

		
		SELECT @MaxTempParamID=Id 
		FROM [TCD].[ConduitParameters] 
		WHERE Name = 'Maximum Temperature'

		SELECT @TempStatusParamID=Id 
		FROM [TCD].[ConduitParameters] 
		WHERE Name = 'Temperature Status'

		SELECT @PHValueParamID=ID
		FROM [TCD].[ConduitParameters] 
		WHERE Name = 'PH'
				
		SELECT @PHStatusParamID=ID
		FROM [TCD].[ConduitParameters] 
		WHERE Name =  'PH Status'
		
		SELECT @ConductivityValueParamID=ID
		FROM [TCD].[ConduitParameters] 
		WHERE Name = 'Conductivity'
				
		SELECT @ConductivityStatusParamID=ID
		FROM [TCD].[ConduitParameters] 
		WHERE Name =  'LF Status'  
		
		IF(@PHValue is not null)
		BEGIN
				--pH Value
				INSERT INTO TCD.BatchParameters
				(BatchId,
				 EcolabWasherId,
				 ParameterId,
				 ParameterValue,
				 PartitionOn)
				VALUES(@BatchID,
						@EcoLabWasherID,
						@PHValueParamID,
						@PHValue,
						@PartitionOn)

				--pH Status
				INSERT INTO TCD.BatchParameters
				(BatchId,
				 EcolabWasherId,
				 ParameterId,
				 ParameterValue,
				 PartitionOn)
				VALUES(@BatchID,
						@EcoLabWasherID,
						@PHStatusParamID,
						@PHStatus,
						@PartitionOn)
		END

		IF(@LFValue is not null)
		BEGIN
				--Conductivity Value
				INSERT INTO TCD.BatchParameters
				(BatchId,
				 EcolabWasherId,
				 ParameterId,
				 ParameterValue,
				 PartitionOn)
				VALUES(@BatchID,
						@EcoLabWasherID,
						@ConductivityValueParamID,
						@LFValue,
						@PartitionOn)

				--Conductivity Status
				INSERT INTO TCD.BatchParameters
				(BatchId,
				 EcolabWasherId,
				 ParameterId,
				 ParameterValue,
				 PartitionOn)
				VALUES(@BatchID,
						@EcoLabWasherID,
						@ConductivityStatusParamID,
						@LFStatus,
						@PartitionOn)
		END

		CREATE TABLE #TemperatureDetails(MinimumTemp Decimal(10,2), 
										 MaximumTemp Decimal(10,2),
										 TempStatus Decimal(10,2)
										)
  	  
	  INSERT INTO #TemperatureDetails(MinimumTemp,MaximumTemp, TempStatus)
	  SELECT 
			T.c.value('@MinimumTemp', 'Decimal(10,2)') AS MinimumTemp, 
			T.c.value('@MaximumTemp', 'Decimal(10,2)') AS MaximumTemp,
			T.c.value('@Status', 'Decimal(10,2)') AS TempStatus
			
	  FROM @xmlTags.nodes('MyControlTunnel/TunnelData/TemperatureData') T(c)
	  
	  -- Fetching data from cursor
			DECLARE @TEMPCURSOR CURSOR
			SET @TEMPCURSOR = CURSOR FAST_FORWARD
			FOR
			SELECT		MinimumTemp,
						MaximumTemp,										
						TempStatus

			FROM #TemperatureDetails

			DECLARE			@MinimumTemp			Decimal(10,2),
							@MaximumTemp			Decimal(10,2),
							@TempStatus				Decimal(10,2)
							
			OPEN @TEMPCURSOR
			FETCH NEXT FROM @TEMPCURSOR
						INTO 
							@MinimumTemp,
							@MaximumTemp,
							@TempStatus
							
			WHILE @@FETCH_STATUS = 0			
			BEGIN	
				--Minimum Temperature
				INSERT INTO TCD.BatchParameters
				(BatchId,
				 EcolabWasherId,
				 ParameterId,
				 ParameterValue,
				 PartitionOn)
				VALUES(@BatchID,
						@EcoLabWasherID,
						@MinTempParamID,
						@MinimumTemp,
						@PartitionOn)

				--Maximum Temperature
				INSERT INTO TCD.BatchParameters
				(BatchId,
				 EcolabWasherId,
				 ParameterId,
				 ParameterValue,
				 PartitionOn)
				VALUES(@BatchID,
						@EcoLabWasherID,
						@MaxTempParamID,
						@MaximumTemp,
						@PartitionOn)

				--Temperature Status
				INSERT INTO TCD.BatchParameters
				(BatchId,
				 EcolabWasherId,
				 ParameterId,
				 ParameterValue,
				 PartitionOn)
				VALUES(@BatchID,
						@EcoLabWasherID,
						@TempStatusParamID,
						@TempStatus,
						@PartitionOn)								

				FETCH NEXT FROM @TEMPCURSOR
						INTO 
							@MinimumTemp,
							@MaximumTemp,
							@TempStatus
			END

			CLOSE @TEMPCURSOR
			DEALLOCATE @TEMPCURSOR

			Drop table #TemperatureDetails
		
	UPDATE TCD.BatchWashStepData SET EndTime=@BatchEndTime
	WHERE BatchId = @BatchID and EndTime is NULL
	
END	




/*
END TCD.ProcessMyControlTunnelWasherProdData

*/

/*
Start TCD.ProcessMyControlTunnelWasherOnlineData

*/
GO
IF OBJECT_ID('[TCD].[ProcessMyControlTunnelWasherOnlineData]') is not null
BEGIN
	DROP proc [TCD].ProcessMyControlTunnelWasherOnlineData
	
END

GO

CREATE PROCEDURE [TCD].[ProcessMyControlTunnelWasherOnlineData]
	(
	@ControllerID INT,
	@xmlTags xML
)
AS
BEGIN
   DECLARE 
			@BatchID						INT,
			@WasherID						INT,
			@EcolabWasherId					INT,								
			@CurrencyCode					VARCHAR(50),		
			@MachineInternalId				INT,
			@WasherGroupID					INT,
			@PlantWasherNumber				INT,
			@BatchStartDate					DATETIME2,
			@BatchEndDate					DATETIME2,			
			@ProgramNumber					INT,
			@Load							Decimal(10,2),
			@NominalLoad					Decimal(10,2),
			@CustomerNumber					INT,
			@PHStatus						INT,
			@PHValue						INT,
			@LFStatus						INT,
			@LFValue						INT,
			@EjectionSignal					INT,
			@TextTileCategory				INT,
			@BatchNumber					INT,
			@TargetTurnTime					INT,
			@ShiftID						INT,
			@ParameterID					INT,			
			@ShiftName						VARCHAR(50),
			@EcolabAccountNumber NVARCHAR(25) = NULL,
			@PartitionOn DateTime,
			@BatchStartTime DateTime,
			@BatchEndTime DateTime,
			@PorgramParameterID int,
			@PHParameterID int,
			@PHParameterStatus int,
			@ConductivityParamID int,
			@ConductivityStatusParamID int,
			@RunTime int,
			@TextileCategory int,
			@ProgramID int,
			@NumberOfCompartments int,
			@TempParameter int,
			@CompartmentNoId int,
			@TransferSignalId int,
			@BatchShiftId int,
			@compartmentID int,
			@TunnelXML xml,
			@TempXML xml

			
				

	INSERT into MyControlXML (xmlData, BatchType, PLCPointer, ReadPointer, BatchID, comment,LastModified) values (@xmlTags, 'TunnelOnline', null, null, null, '',getDate())

   
	SELECT @CompartmentNoId=ID
	FROM TCD.ConduitParameters WHERE NAME ='StepCompartment No' 

	SELECT @TransferSignalId=ID
	FROM TCD.ConduitParameters WHERE NAME ='Transfer Signal'

	CREATE TABLE #Batches(BatchNumber int,StartDateTime DateTime)			
		
	SET @compartmentID = 1	
	
	SELECT @TempXML=T.c.query('.') 	FROM   @xmlTags.nodes('MyControlTunnel') T(c)
	SELECT   @MachineInternalID=T.c.value('@MachineNumber', 'int') FROM @TempXML.nodes('MyControlTunnel')  T(c);

	SELECT 
			@EcolabWasherID=EcolabWasherId,
			@WasherGroupID= Wg.WasherGroupId,
			@PlantWasherNumber=PlantWasherNumber,
			@WasherID=ws.WasherId,
			@CurrencyCode=P.CurrencyCode,
			@NumberOfCompartments=Mst.NumberofComp
	FROM TCD.Washer Ws
			INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
			INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
			INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
			INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId = Mst.ControllerId
			INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.EcoLabAccountNumber
	WHERE  Ctrl.ControllerID = @ControllerID
			AND mst.MachineInternalId = @MachineInternalID
			AND Mst.IsTunnel = 1

	WHILE (@compartmentID <= @NumberOfCompartments)
	BEGIN
	  
	  	SELECT @TunnelXML=T.c.query('.') 
		FROM   @xmlTags.nodes('MyControlTunnel/TunnelData') T(c)
		WHERE T.c.value('@CompartmentNumber', 'INT') = @compartmentID


		 SELECT   @MachineInternalID=T.c.value('@MachineNumber', 'int'),
				  @BatchNumber= T.c.value('@BatchNumber', 'INT'),
 				  @BatchStartTime=T.c.value('@StartDateTime', 'DateTime'),
				  @BatchEndTime=T.c.value('@EndDateTime', 'DateTime'),
				  @ProgramNumber=T.c.value('@ProgramNumber', 'INT'),
				  @Load=T.c.value('@Load', 'Decimal(10,6)')/10,
				  @NominalLoad=T.c.value('@Nominalload', 'Decimal(10,6)'),
				  @CustomerNumber=T.c.value('@CustomerNumber', 'int'),
				  @PHStatus=T.c.value('@pHStatus', 'int'),
				  @PHValue=T.c.value('@pHValue', 'INT'),
				  @LFStatus=T.c.value('@LFStatus', 'INT'),
				  @LFValue=T.c.value('@LFValue', 'INT'),
				  @RunTime=T.c.value('@RunTime', 'INT'),
				  @EjectionSignal=T.c.value('@EjectionSignal', 'INT'),
				  @TextileCategory=T.c.value('@TextileCategory', 'INT')
		 FROM @TunnelXML.nodes('TunnelData')  T(c);
		 

		 IF (@ProgramNumber = 0 OR @BatchNumber=1) 
		 BEGIN
		    SELECT @compartmentID  = @compartmentID + 1
			Continue;
		 END 		 
		

		 SELECT @ProgramID=ProgramId,
				@TargetTurnTime= (3600 / (tps.TotalRunTime /@NumberOfCompartments )) 
		 FROM TCD.TunnelProgramSetup AS tps 
		 WHERE tps.WasherGroupId = @WasherGroupID 
			   and tps.is_deleted =0
			   and ProgramNumber = @ProgramNumber

		 INSERT #Batches(BatchNumber,StartDateTime)
		 SELECT @BatchNumber,@BatchStartTime

		 --DELETE FROM  @ShiftStartDateTemp;
				
		SELECT @BatchID = Null
		SELECT @BatchID=BatchID	FROM TCD.BatchData BD
			WHERE BD.ControllerBatchId = @BatchNumber
				  AND BD.StartDate= @BatchStartTime
				  AND BD.MachineId = @WasherID
				  
		IF (@BatchID is Null) 
		BEGIN

			 DECLARE @ShiftStartDateTemp table(ShiftId INT,ShiftName NVARCHAR(50),ShiftStartdate DATETIME)
			 INSERT INTO @ShiftStartDateTemp(ShiftId,ShiftName,ShiftStartdate) 
			 EXEC TCD.GetShiftStartDate @BatchStartTime,1

			 SELECT @BatchShiftId = ShiftID, @PartitionOn=ShiftStartdate, @ShiftName=ShiftName FROM @ShiftStartDateTemp

			INSERT INTO TCD.BatchData(
									   ControllerBatchId ,
									   EcolabWasherId,
									   GroupId ,
									   MachineInternalId,
									   PlantWasherNumber,
									   StartDate ,
									   ProgramNumber,
									   ProgramMasterId,
									   MachineId,
									   ActualWeight,
									   StandardWeight,
									   CurrencyCode,
									   ShiftId,
									   PartitionOn,
									   TargetTurnTime
									)
					   SELECT @BatchNumber,
							  @EcolabWasherID,
							  @WasherGroupID,
							  @MachineInternalID,
							  @PlantWasherNumber,
							  @BatchStartTime,
							  @ProgramNumber,
							  @ProgramID,
							  @WasherID,
							  @Load,
							  @NominalLoad,
							  @CurrencyCode,
							  @BatchShiftId,
							  @PartitionOn,
							  @TargetTurnTime

		SELECT @BatchID=Scope_Identity()	

		IF(@CustomerNumber is not null)
		BEGIN
			 IF NOT Exists(SELECT 1 FROM [TCD].[BatchCustomerData] WHERE BatchID = @BatchID)
			 BEGIN
				INSERT INTO [TCD].[BatchCustomerData] ([BatchId],CustomerID,[Weight],PartitionOn,EcolabWasherId)
				SELECT @BatchID,@CustomerNumber,@Load,@PartitionOn,@EcolabWasherId
			 END 
		END
			
	 END 

	 --IF (@BatchEndTime is Not Null and @BatchEndTime !='01/01/1900')
	 --BEGIN
		--UPDATE TCD.BatchData
		--SET EndDate = @BatchEndTime
		--WHERE BATCHID = @BatchID
	 --END 
	 
	 -- Transfer Signal
	 INSERT INTO TCD.WasherReading(
			WasherId,
			ParameterId,
			ParameterValue,
			DateTimeStamp,
			PartitionOn,
			EcolabWasherId)
			SELECT @WasherID,
			@TransferSignalId,
			1,
			@BatchStartTime,
			@PartitionOn,
			@EcolabWasherId
		UNION ALL
			SELECT @WasherID,
			@TransferSignalId,
			0,
			@BatchStartTime,
			@PartitionOn,
			@EcolabWasherId

	

	 ---- @Program Number
	 --SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
		--	WasherId = @WasherID 
		--	AND ParameterID = @PorgramParameterID 
		--	AND EcolabWasherId = @EcolabWasherId 
		--	AND DateTimeStamp = @BatchStartTime
		--	--AND ParameterValue = @ProgramNumber
		--	ORDER BY  DateTimeStamp DESC)

		--IF (@TempParameter != @ProgramNumber)
		--BEGIN
		--	INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
		--	SELECT @WasherID,@PorgramParameterID,@ProgramNumber,@BatchStartTime,@PartitionOn,@EcolabWasherId
		--END 
		
			
		---- Compartment No  
		--SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
		--	WasherId = @WasherID 
		--	AND ParameterID = @CompartmentNoId 
		--	AND EcolabWasherId = @EcolabWasherId 
		--	AND DateTimeStamp = @BatchStartTime
		--	--AND ParameterValue = @ProgramNumber
		--	ORDER BY  DateTimeStamp DESC)

		--IF (@TempParameter != @compartmentID)
		--BEGIN
		--	--IF (@LFValue > 0)
		--	--BEGIN
		--		INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
		--		SELECT @WasherID,@CompartmentNoId,@compartmentID,@BatchStartTime,@PartitionOn,@EcolabWasherId
		--	--END
		--END 	 

	  EXEC TCD.UPDATEBatchWashStepForTunnel @TunnelXML,@WasherID,@BatchID, @BatchStartTime,@PartitionOn,@EcolabWasherId,@compartmentID

	  SELECT @compartmentID= @compartmentID + 1 
	END	   

	
	-- Last Step is not getting closed in Tunnel BatchWashStepData
	UPDATE BWD
	SET EndTime=GetUTCDate()
	FROM TCD.BatchWashStepData BWD
	INNER JOIN TCD.BatchData BD on BWD.BatchId = BD.BatchId
	WHERE BD.MachineId =@WasherID
              AND BWD.EndTime is Null
              AND Not Exists(SELECT 1 FROM #Batches t
                             WHERE t.BatchNumber = BD.ControllerBatchId
                             and t.StartDateTime =BD.StartDate)      
END
			




/*
END TCD.ProcessMyControlTunnelWasherOnlineData

*/

GO

UPDATE TCD.Field	SET HasFieldTag='Tag_L160',		DefaultFieldTag = 'L160'	WHERE Id = 310
UPDATE TCD.Field	SET HasFieldTag='Tag_L53',		DefaultFieldTag = 'L53'		WHERE Id = 311
UPDATE TCD.Field	SET HasFieldTag='Tag_L92',		DefaultFieldTag = 'L92'		WHERE Id = 312
UPDATE TCD.Field	SET HasFieldTag='Tag_L54',		DefaultFieldTag = 'L54'		WHERE Id = 313
UPDATE TCD.Field	SET HasFieldTag='Tag_R4028',	DefaultFieldTag = 'R4028'	WHERE Id = 314
UPDATE TCD.Field	SET HasFieldTag='Tag_L800',		DefaultFieldTag = 'L800'	WHERE Id = 315
UPDATE TCD.Field	SET HasFieldTag='Tag_D776',		DefaultFieldTag = 'D776'	WHERE Id = 316
UPDATE TCD.Field	SET HasFieldTag='Tag_L801',		DefaultFieldTag = 'L801'	WHERE Id = 317
UPDATE TCD.Field	SET HasFieldTag='Tag_L131', 	DefaultFieldTag = 'L131'	WHERE Id = 318
UPDATE TCD.Field	SET HasFieldTag='Tag_L130', 	DefaultFieldTag = 'L130'	WHERE Id = 319
UPDATE TCD.Field	SET HasFieldTag='Tag_L78',		DefaultFieldTag = 'L78'		WHERE Id = 320
UPDATE TCD.Field	SET HasFieldTag='Tag_R4029',	DefaultFieldTag = 'R4029'	WHERE Id = 321
UPDATE TCD.Field	SET HasFieldTag='Tag_L79',		DefaultFieldTag = 'L79'		WHERE Id = 322
UPDATE TCD.Field	SET HasFieldTag='Tag_L91',		DefaultFieldTag = 'L91'		WHERE Id = 323
UPDATE TCD.Field	SET HasFieldTag='Tag_L74',		DefaultFieldTag = 'L74'		WHERE Id = 324
UPDATE TCD.Field	SET HasFieldTag='Tag_L80',		DefaultFieldTag = 'L80'		WHERE Id = 325
UPDATE TCD.Field	SET HasFieldTag='Tag_L76',		DefaultFieldTag = 'L76'		WHERE Id = 326
UPDATE TCD.Field	SET HasFieldTag='Tag_L81',		DefaultFieldTag = 'L81'		WHERE Id = 327
UPDATE TCD.Field	SET HasFieldTag='Tag_R3265',	DefaultFieldTag = 'R3265'	WHERE Id = 328
UPDATE TCD.Field	SET HasFieldTag='Tag_R3267',	DefaultFieldTag = 'R3267'	WHERE Id = 329
UPDATE TCD.Field	SET HasFieldTag='Tag_R3266',	DefaultFieldTag = 'R3266'	WHERE Id = 330
UPDATE TCD.Field	SET HasFieldTag='Tag_R3268',	DefaultFieldTag = 'R3268'	WHERE Id = 331
UPDATE TCD.Field	SET HasFieldTag='Tag_L65',		DefaultFieldTag = 'L65'		WHERE Id = 332
UPDATE TCD.Field	SET HasFieldTag='Tag_L70',		DefaultFieldTag = 'L70'		WHERE Id = 333
UPDATE TCD.Field	SET HasFieldTag='Tag_L66',		DefaultFieldTag = 'L66'		WHERE Id = 334
UPDATE TCD.Field	SET HasFieldTag='Tag_L71',		DefaultFieldTag = 'L71'		WHERE Id = 335
UPDATE TCD.Field	SET HasFieldTag='Tag_L67',		DefaultFieldTag = 'L67'		WHERE Id = 336
UPDATE TCD.Field	SET HasFieldTag='Tag_L72',		DefaultFieldTag = 'L72'		WHERE Id = 337
UPDATE TCD.Field	SET HasFieldTag='Tag_L68',		DefaultFieldTag = 'L68'		WHERE Id = 338
UPDATE TCD.Field	SET HasFieldTag='Tag_L73',		DefaultFieldTag = 'L73'		WHERE Id = 339
UPDATE TCD.Field	SET HasFieldTag='Tag_L69',		DefaultFieldTag = 'L69'		WHERE Id = 340


UPDATE TCD.Field	SET HasFieldTag='Tag_L160',		DefaultFieldTag = 'L160'	WHERE Id = 349
UPDATE TCD.Field	SET HasFieldTag='Tag_L53',		DefaultFieldTag = 'L53'		WHERE Id = 350
UPDATE TCD.Field	SET HasFieldTag='Tag_L92',		DefaultFieldTag = 'L92'		WHERE Id = 351
UPDATE TCD.Field	SET HasFieldTag='Tag_L54',		DefaultFieldTag = 'L54'		WHERE Id = 352
UPDATE TCD.Field	SET HasFieldTag='Tag_R4028',	DefaultFieldTag = 'R4028'	WHERE Id = 353
UPDATE TCD.Field	SET HasFieldTag='Tag_L800',		DefaultFieldTag = 'L800'	WHERE Id = 354
UPDATE TCD.Field	SET HasFieldTag='Tag_D776',		DefaultFieldTag = 'D776'	WHERE Id = 355
UPDATE TCD.Field	SET HasFieldTag='Tag_L801',		DefaultFieldTag = 'L160'	WHERE Id = 356
UPDATE TCD.Field	SET HasFieldTag='Tag_L131', 	DefaultFieldTag = 'L131'	WHERE Id = 357
UPDATE TCD.Field	SET HasFieldTag='Tag_L130', 	DefaultFieldTag = 'L130'	WHERE Id = 358
UPDATE TCD.Field	SET HasFieldTag='Tag_L78',		DefaultFieldTag = 'L78'		WHERE Id = 359
UPDATE TCD.Field	SET HasFieldTag='Tag_R4029',	DefaultFieldTag = 'R4029'	WHERE Id = 360
UPDATE TCD.Field	SET HasFieldTag='Tag_L79',		DefaultFieldTag = 'L79'		WHERE Id = 361
UPDATE TCD.Field	SET HasFieldTag='Tag_L91',		DefaultFieldTag = 'L91'		WHERE Id = 362
UPDATE TCD.Field	SET HasFieldTag='Tag_L74',		DefaultFieldTag = 'L74'		WHERE Id = 363
UPDATE TCD.Field	SET HasFieldTag='Tag_L80',		DefaultFieldTag = 'L80'		WHERE Id = 364
UPDATE TCD.Field	SET HasFieldTag='Tag_L76',		DefaultFieldTag = 'L76'		WHERE Id = 365
UPDATE TCD.Field	SET HasFieldTag='Tag_L81',		DefaultFieldTag = 'L81'		WHERE Id = 366
UPDATE TCD.Field	SET HasFieldTag='Tag_R3265',	DefaultFieldTag = 'R3265'	WHERE Id = 367
UPDATE TCD.Field	SET HasFieldTag='Tag_R3267',	DefaultFieldTag = 'R3267'	WHERE Id = 368
UPDATE TCD.Field	SET HasFieldTag='Tag_R3266',	DefaultFieldTag = 'R3266'	WHERE Id = 369
UPDATE TCD.Field	SET HasFieldTag='Tag_R3268',	DefaultFieldTag = 'R3268'	WHERE Id = 370
UPDATE TCD.Field	SET HasFieldTag='Tag_L65',		DefaultFieldTag = 'L65'		WHERE Id = 371
UPDATE TCD.Field	SET HasFieldTag='Tag_L70',		DefaultFieldTag = 'L70'		WHERE Id = 372
UPDATE TCD.Field	SET HasFieldTag='Tag_L66',		DefaultFieldTag = 'L66'		WHERE Id = 373
UPDATE TCD.Field	SET HasFieldTag='Tag_L71',		DefaultFieldTag = 'L71'		WHERE Id = 374
UPDATE TCD.Field	SET HasFieldTag='Tag_L67',		DefaultFieldTag = 'L67'		WHERE Id = 375
UPDATE TCD.Field	SET HasFieldTag='Tag_L72',		DefaultFieldTag = 'L72'		WHERE Id = 376
UPDATE TCD.Field	SET HasFieldTag='Tag_L68',		DefaultFieldTag = 'L68'		WHERE Id = 377
UPDATE TCD.Field	SET HasFieldTag='Tag_L73',		DefaultFieldTag = 'L73'		WHERE Id = 378
UPDATE TCD.Field	SET HasFieldTag='Tag_L69',		DefaultFieldTag = 'L69'		WHERE Id = 379


UPDATE TCD.Field	SET HasFieldTag='Tag_L160',		DefaultFieldTag = 'L160'	WHERE Id = 270
UPDATE TCD.Field	SET HasFieldTag='Tag_L53',		DefaultFieldTag = 'L53'		WHERE Id = 271
UPDATE TCD.Field	SET HasFieldTag='Tag_L92',		DefaultFieldTag = 'L92'		WHERE Id = 272
UPDATE TCD.Field	SET HasFieldTag='Tag_L54',		DefaultFieldTag = 'L54'		WHERE Id = 273
UPDATE TCD.Field	SET HasFieldTag='Tag_R4028',	DefaultFieldTag = 'R4028'	WHERE Id = 274
UPDATE TCD.Field	SET HasFieldTag='Tag_L800',		DefaultFieldTag = 'L800'	WHERE Id = 275
UPDATE TCD.Field	SET HasFieldTag='Tag_D776',		DefaultFieldTag = 'D776'	WHERE Id = 277
UPDATE TCD.Field	SET HasFieldTag='Tag_L801',		DefaultFieldTag = 'L160'	WHERE Id = 278
UPDATE TCD.Field	SET HasFieldTag='Tag_L131', 	DefaultFieldTag = 'L131'	WHERE Id = 279
UPDATE TCD.Field	SET HasFieldTag='Tag_L130', 	DefaultFieldTag = 'L130'	WHERE Id = 280
UPDATE TCD.Field	SET HasFieldTag='Tag_L78',		DefaultFieldTag = 'L78'		WHERE Id = 281
UPDATE TCD.Field	SET HasFieldTag='Tag_R4029',	DefaultFieldTag = 'R4029'	WHERE Id = 282
UPDATE TCD.Field	SET HasFieldTag='Tag_L79',		DefaultFieldTag = 'L79'		WHERE Id = 283
UPDATE TCD.Field	SET HasFieldTag='Tag_L91',		DefaultFieldTag = 'L91'		WHERE Id = 284
UPDATE TCD.Field	SET HasFieldTag='Tag_L74',		DefaultFieldTag = 'L74'		WHERE Id = 285
UPDATE TCD.Field	SET HasFieldTag='Tag_L80',		DefaultFieldTag = 'L80'		WHERE Id = 286
UPDATE TCD.Field	SET HasFieldTag='Tag_L76',		DefaultFieldTag = 'L76'		WHERE Id = 287
UPDATE TCD.Field	SET HasFieldTag='Tag_L81',		DefaultFieldTag = 'L81'		WHERE Id = 288
UPDATE TCD.Field	SET HasFieldTag='Tag_R3265',	DefaultFieldTag = 'R3265'	WHERE Id = 289
UPDATE TCD.Field	SET HasFieldTag='Tag_R3267',	DefaultFieldTag = 'R3267'	WHERE Id = 290
UPDATE TCD.Field	SET HasFieldTag='Tag_R3266',	DefaultFieldTag = 'R3266'	WHERE Id = 291
UPDATE TCD.Field	SET HasFieldTag='Tag_R3268',	DefaultFieldTag = 'R3268'	WHERE Id = 292
UPDATE TCD.Field	SET HasFieldTag='Tag_L65',		DefaultFieldTag = 'L65'		WHERE Id = 293
UPDATE TCD.Field	SET HasFieldTag='Tag_L70',		DefaultFieldTag = 'L70'		WHERE Id = 294
UPDATE TCD.Field	SET HasFieldTag='Tag_L66',		DefaultFieldTag = 'L66'		WHERE Id = 295
UPDATE TCD.Field	SET HasFieldTag='Tag_L71',		DefaultFieldTag = 'L71'		WHERE Id = 296
UPDATE TCD.Field	SET HasFieldTag='Tag_L67',		DefaultFieldTag = 'L67'		WHERE Id = 297
UPDATE TCD.Field	SET HasFieldTag='Tag_L72',		DefaultFieldTag = 'L72'		WHERE Id = 298
UPDATE TCD.Field	SET HasFieldTag='Tag_L68',		DefaultFieldTag = 'L68'		WHERE Id = 299
UPDATE TCD.Field	SET HasFieldTag='Tag_L73',		DefaultFieldTag = 'L73'		WHERE Id = 300
UPDATE TCD.Field	SET HasFieldTag='Tag_L69',		DefaultFieldTag = 'L69'		WHERE Id = 301

UPDATE TCD.FIELD SET DefaultValue='172.16.104.11' WHERE id IN (269, 309, 348)

GO


IF EXISTS (SELECT *
			FROM sys.objects
			WHERE parent_object_id = (OBJECT_ID('TCD.ControllerEquipmentSetup')) 
			AND type IN ('D')
			and name = 'DF_ControllerEquipmentSetup_UsePumpOfGroup1ForTunnel' )
begin
	alter table TCD.ControllerEquipmentSetup drop constraint DF_ControllerEquipmentSetup_UsePumpOfGroup1ForTunnel
end

IF EXISTS (SELECT *
			FROM sys.objects
			WHERE parent_object_id = (OBJECT_ID('TCD.ControllerEquipmentSetup')) 
			AND type IN ('D')
			and name = 'DF_ControllerEquipmentSetup_pHSensorEnabled' )
begin
	alter table TCD.ControllerEquipmentSetup drop constraint DF_ControllerEquipmentSetup_pHSensorEnabled
end
GO
Alter Table TCD.ControllerEquipmentSetup  Alter Column UsePumpOfGroup1ForTunnel BIT NULL
Alter Table TCD.ControllerEquipmentSetup  Alter Column pHSensorEnabled BIT NULL


Go
/*######################End of Trigger############################################*/
/*###################################################################################################    
Table:       [TCD].[WasherProductDeviationsHistory]                                           
  
Purpose:    To Log the history of WasherProductDeviations table.                                      
###################################################################################################  */

IF OBJECT_ID('[TCD].[WasherProductDeviationsHistory]') is null
BEGIN
	
CREATE TABLE [TCD].[WasherProductDeviationsHistory](
	[WasherProductDeviationsHistoryId] [int] IDENTITY(1,1) NOT NULL,
	[WasherProductDeviationID] [int] NOT NULL,
	[WasherId] [int] NOT NULL,
	[OperationTimestamp] [datetime] NOT NULL,
	[OperationId] [tinyint] NOT NULL,
	[ControllerEquipmentID] [tinyint] NOT NULL,
	[ControllerID] [smallint] NOT NULL,
	[ProductDeviation] [smallint] NOT NULL,
	[LastModifiedTime] [datetime] NOT NULL,
	[PlantId] [int] NULL,
 CONSTRAINT [PK_WasherProductDeviationsHistory] PRIMARY KEY CLUSTERED 
(
	[WasherProductDeviationsHistoryId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
	
END

GO
GO
IF OBJECT_ID('[TCD].[WasherProductDeviationsTrigger]') is not null
BEGIN
	DROP trigger [TCD].WasherProductDeviationsTrigger
	
END

GO
/*###################################################################################################    
Trigger:       [dbo].[WasherProductDeviationsTrigger]                                           
  
Purpose:    To perform the action to Log the history of WasherProductDeviations table.                                      
###################################################################################################  */
CREATE TRIGGER [TCD].[WasherProductDeviationsTrigger]
	ON [TCD].[WasherProductDeviations]
	FOR UPDATE, INSERT
	AS
	BEGIN
		SET NOCOUNT ON
		DECLARE	@AuditOperation_SQLInsertId TINYINT			= NULL
	,	@AuditOperation_SQLUpdateId			TINYINT			= NULL
	,	@AuditOperation_AppDeleteId			TINYINT			= NULL
	,	@ErrorNumber						INT				= 0
	,	@ErrorMessage						NVARCHAR(2048)	= NULL
	,	@ErrorSeverity						INT				= NULL
	,	@ErrorProcedure						SYSNAME			= NULL
	,	@MessageString						NVARCHAR(2500)	= NULL
	,	@SoftDeleteFlag						BIT				= NULL --0 for FALSE/1 for TRUE
	,	@CurrentTimeStamp					DATETIME		= GETUTCDATE() --CURRENT_TIMESTAMP

SELECT	@AuditOperation_SQLInsertId = AO.OperationId
FROM	[TCD].AuditOperation AO
WHERE	AO.OperationCode = 'SQLInsert'

SELECT	@AuditOperation_SQLUpdateId = AO.OperationId
FROM	[TCD].AuditOperation AO
WHERE	AO.OperationCode = 'SQLUpdate'

SELECT	@AuditOperation_AppDeleteId = AO.OperationId
FROM	[TCD].AuditOperation AO
WHERE	AO.OperationCode = 'AppDelete'

IF NOT EXISTS (SELECT 1 FROM [deleted])
	BEGIN
		BEGIN	TRY
			INSERT	[TCD].WasherProductDeviationsHistory(WasherProductDeviationID, WasherId, OperationTimestamp, OperationId, ControllerEquipmentID, ControllerID, ProductDeviation, LastModifiedTime, PlantId)
			SELECT	WasherProductDeviationID, WasherId, @CurrentTimeStamp, @AuditOperation_SQLInsertId, ControllerEquipmentID, ControllerID, ProductDeviation, LastModifiedTime, PlantId
			FROM	[inserted]
		END	TRY
		BEGIN	CATCH
			SELECT	@ErrorNumber = ERROR_NUMBER()
				,	@ErrorMessage = ERROR_MESSAGE()
				,	@ErrorProcedure = ERROR_PROCEDURE()
				,	@ErrorSeverity = ERROR_SEVERITY()

			--GOTO	ErrorHandler
			SET @MessageString = N'An error occured while updating Audit data for WasherProductDeviations table. The error is: '
								+ @ErrorMessage + '	'
								+ 'Module: ' + @ErrorProcedure
			RAISERROR(@MessageString, @ErrorSeverity, 1)
			RETURN
		END	CATCH
	END
ELSE IF	EXISTS (SELECT 1 FROM [inserted])
	BEGIN
		BEGIN
			BEGIN	TRY
				INSERT	[TCD].WasherProductDeviationsHistory(WasherProductDeviationID, WasherId, OperationTimestamp, OperationId, ControllerEquipmentID, ControllerID, ProductDeviation, LastModifiedTime, PlantId)
				SELECT	WasherProductDeviationID, WasherId, @CurrentTimeStamp, @AuditOperation_SQLUpdateId, ControllerEquipmentID, ControllerID, ProductDeviation, LastModifiedTime, PlantId
				FROM	[inserted]
			END	TRY
			BEGIN	CATCH
				SELECT	@ErrorNumber = ERROR_NUMBER()
					,	@ErrorMessage = ERROR_MESSAGE()
					,	@ErrorProcedure = ERROR_PROCEDURE()
					,	@ErrorSeverity = ERROR_SEVERITY()
				--GOTO	ErrorHandler
				SET @MessageString = N'An error occured while updating Audit data for WasherProductDeviations table. The error is: '
									+	@ErrorMessage + '	'
									+	'Module: ' + @ErrorProcedure
				RAISERROR(@MessageString, @ErrorSeverity, 1)
				RETURN
			END	CATCH
		END
	END
IF	@ErrorNumber	=	0
	--GOTO	ExitModule
	RETURN
ErrorHandler:
SET @MessageString = N'An error occured while updating Audit data for WasherProductDeviations table. The error is: '
				   + @ErrorMessage + '	'
				   + 'Module: ' + @ErrorProcedure
RAISERROR(@MessageString, @ErrorSeverity, 1)
ExitModule:
SET	NOCOUNT	OFF
RETURN
END


GO
if object_id('TCD.GetUsedChemicalName') is not null
begin
	drop proc TCD.[GetUsedChemicalName]

end
GO
/*	                                   
###################################################################################################                                           

Stored Procedure:       [TCD].[GetUsedChemicalName]                                             

Purpose:				To get Chemicals.

Parameters:				@EcoLabAccountNumber - holds ecolab account number.
						@ChemName - holds chemical names.
																
###################################################################################################                                           
*/

CREATE PROCEDURE [TCD].[GetUsedChemicalName]
	@ChemName Varchar(1000)
	,@EcolabAccountNumber nvarchar(25)
	,@WasherGroupId	INT = NULL
AS     

BEGIN     
	SET NOCOUNT ON    
	
	DECLARE @RegionId			INT =	NULL
		,	@ControllerId		INT	=	NULL
		,	@ControllerModelId	INT	=	NULL
		,	@ControllerTypeId	INT	=	NULL
	
	SELECT 
	@RegionId = RegionID FROM Plant 
	WHERE 
	EcolabAccountNumber = @EcolabAccountNumber

	SELECT @ControllerId =  wg.ControllerId FROM TCD.WasherGroup wg WHERE wg.WasherGroupId = @WasherGroupId AND wg.EcolabAccountNumber = @EcolabAccountNumber

	IF @ControllerId IS NULL
	BEGIN
		SELECT 
		Map.ProductId, RTRIM(CASE  
					WHEN EnvisionDisplayName IS NULL THEN NAME 
					ELSE EnvisionDisplayName 
					END ) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name
		, M.Cost
		, M.IncludeinCI
		, CAST (0 AS int) AS ControllerEquipmentTypeId
		FROM ProductMaster M
		INNER JOIN ProductdataMapping Map ON M.ProductId = Map.ProductId AND Map.Is_Deleted=0     
		WHERE 
		(M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
		AND M.RegionId = @RegionId
		AND M.Is_Deleted =0
	END
	ELSE
	BEGIN
		SELECT @ControllerModelId = cc.ControllerModelId, @ControllerTypeId = cc.ControllerTypeId FROM TCD.ConduitController cc WHERE cc.ControllerId = @ControllerId

		IF @ControllerModelId = 11
		BEGIN
			SELECT DISTINCT
			Map.ProductId, RTRIM(CASE  
						WHEN EnvisionDisplayName IS NULL THEN NAME 
						ELSE EnvisionDisplayName 
						END ) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name
			, M.Cost
			, M.IncludeinCI
			, CAST (ces.ControllerEquipmentTypeId AS int) AS ControllerEquipmentTypeId
			FROM ProductMaster M
			INNER JOIN ProductdataMapping Map ON M.ProductId = Map.ProductId AND Map.Is_Deleted=0  
			INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.EcoLabAccountNumber = Map.EcolabAccountNumber AND ces.ProductId = Map.ProductID
			LEFT JOIN TCD.TunnelCompartmentEquipmentValveMapping tcevm ON ces.ControllerEquipmentSetupID = tcevm.ControllerEquipmentSetupID AND tcevm.DirectDosingFlag = 1
			WHERE 
			(M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
			AND tcevm.ControllerEquipmentSetupID IS NULL
			AND M.RegionId = @RegionId
			AND M.Is_Deleted =0
			AND ces.ControllerId = @ControllerId
			AND ces.WasherGroupNumber =  CASE WHEN @ControllerTypeId = 13 THEN 1 ELSE ces.WasherGroupNumber END
		END
		ELSE
		BEGIN
			SELECT DISTINCT
			Map.ProductId, RTRIM(CASE  
						WHEN EnvisionDisplayName IS NULL THEN NAME 
						ELSE EnvisionDisplayName 
						END ) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name
			, M.Cost
			, M.IncludeinCI
			, CAST (ces.ControllerEquipmentTypeId AS int) AS ControllerEquipmentTypeId
			FROM ProductMaster M
			INNER JOIN ProductdataMapping Map ON M.ProductId = Map.ProductId AND Map.Is_Deleted=0  
			INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.EcoLabAccountNumber = Map.EcolabAccountNumber AND ces.ProductId = Map.ProductID
			LEFT JOIN TCD.TunnelCompartmentEquipmentValveMapping tcevm ON ces.ControllerEquipmentSetupID = tcevm.ControllerEquipmentSetupID AND tcevm.DirectDosingFlag = 1
			WHERE 
			(M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
			AND tcevm.ControllerEquipmentSetupID IS NULL
			AND M.RegionId = @RegionId
			AND M.Is_Deleted =0
			AND ces.ControllerId = @ControllerId
		END
	END
		

	SET NOCOUNT OFF 
 
END

/*	                                   
###################################################################################################                                           

Stored Procedure:       [TCD].[[SaveWasherFlushTime]]                                             

Purpose:				To save washer flush time.

Parameters:				 @udttWasherFlushTime, @EcolabAccountNumber, @UserId
																
###################################################################################################                                           
*/
GO
if object_id('TCD.[SaveWasherFlushTime]') is not null
begin
	drop proc TCD.[SaveWasherFlushTime]

end
GO

CREATE PROCEDURE [TCD].[SaveWasherFlushTime] (
      @udttWasherFlushTime TCD.udttWasherFlushTime READONLY 
    , @EcolabAccountNumber NVARCHAR(25)
    , @UserId INT)
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @CurrentUTC DATETIME = GETUTCDATE()
        ,      @PlantId INT = (SELECT P.PlantId 
                       FROM TCD.Plant P 
                       WHERE P.EcolabAccountNumber = @EcolabAccountNumber)

UPDATE wft
SET
    wft.FlushTime = uwft.FlushTime, -- int
    wft.LastModifiedByUserId = @UserId,
    wft.LastModifiedTime = @CurrentUTC
FROM TCD.WasherFlushTime wft
INNER JOIN @udttWasherFlushTime uwft
ON wft.WasherId = uwft.WasherId
AND wft.PlantId = @PlantId
AND wft.LineNumber = uwft.LineNumber
AND wft.WasherFlushTypeId = uwft.WasherFlushTypeId

INSERT INTO TCD.WasherFlushTime
(
    WasherId,
    PlantId,
    LineNumber,
    WasherFlushTypeId,
    FlushTime,
    LastModifiedByUserId,
    LastModifiedTime
)
SELECT uwft.WasherId,
      @PlantId,
      uwft.LineNumber,
      uwft.WasherFlushTypeId,
      uwft.FlushTime,
      @UserId,
      @CurrentUTC
FROM @udttWasherFlushTime uwft 
LEFT JOIN  TCD.WasherFlushTime as wft ON wft.WasherId = uwft.washerId AND wft.LineNumber = uwft.LineNumber AND wft.WasherFlushTypeId = uwft.WasherFlushTypeId AND wft.PlantId = @PlantId
WHERE wft.washerId IS NULL 



END

GO

UPDATE TCD.Field	SET HasFieldTag='Tag_HCAL', DefaultFieldTag = 'uint_Connex_Level_Delay'		WHERE Id = 407

UPDATE TCD.Field	SET HasFieldTag='Tag_M978', DefaultFieldTag = 'M978'		WHERE Id = 388
UPDATE TCD.Field	SET HasFieldTag='Tag_M930', DefaultFieldTag = 'M930'		WHERE Id = 389
UPDATE TCD.Field	SET HasFieldTag='Tag_D461', DefaultFieldTag = 'D461'		WHERE Id = 390
UPDATE TCD.Field	SET HasFieldTag='Tag_M931', DefaultFieldTag = 'M931'		WHERE Id = 391
UPDATE TCD.Field	SET HasFieldTag='Tag_M936', DefaultFieldTag = 'M936'		WHERE Id = 392
UPDATE TCD.Field	SET HasFieldTag='Tag_M935', DefaultFieldTag = 'M935'		WHERE Id = 393

UPDATE TCD.Field	SET HasFieldTag='Tag_M978', DefaultFieldTag = 'M978'		WHERE Id = 401
UPDATE TCD.Field	SET HasFieldTag='Tag_M930', DefaultFieldTag = 'M930'		WHERE Id = 402
UPDATE TCD.Field	SET HasFieldTag='Tag_D461', DefaultFieldTag = 'D461'		WHERE Id = 403
UPDATE TCD.Field	SET HasFieldTag='Tag_M931', DefaultFieldTag = 'M931'		WHERE Id = 404
UPDATE TCD.Field	SET HasFieldTag='Tag_M936', DefaultFieldTag = 'M936'		WHERE Id = 405
UPDATE TCD.Field	SET HasFieldTag='Tag_M935', DefaultFieldTag = 'M935'		WHERE Id = 406

GO

/*	                                   
###################################################################################################                                           

Stored Procedure:       [TCD].[SaveWasherProductDeviationData]                                             

Purpose:				To save washer product deviation.

Parameters:				  @udttProductDeviationData,@isNewRecord int,@EcolabAccountNumber
																
###################################################################################################                                           
*/
GO
if object_id('TCD.[SaveWasherProductDeviationData]') is not null
begin
	drop proc TCD.[SaveWasherProductDeviationData]

end
GO

CREATE PROCEDURE [TCD].[SaveWasherProductDeviationData](
	  @udttProductDeviationData TCD.udttProductDeviationData READONLY,
	  @isNewRecord int,
	  @EcolabAccountNumber NVARCHAR(25))
AS
BEGIN

DECLARE @PlantId INT = (SELECT P.PlantId 
                       FROM TCD.Plant P 
                       WHERE P.EcolabAccountNumber = @EcolabAccountNumber),
		@ExistingRecords INT = (SELECT count(*) FROM TCD.WasherProductDeviations WHERE TCD.WasherProductDeviations.WasherId=(SELECT TOP 1 (WasherId) FROM @udttProductDeviationData) and TCD.WasherProductDeviations.ControllerID=(SELECT TOP 1 (ControllerID) FROM @udttProductDeviationData))

	If(@ExistingRecords = 0)
		BEGIN
			INSERT INTO TCD.WasherProductDeviations
			(
				WasherId,
				ControllerEquipmentID,
				ControllerID,
				ProductDeviation,
				PlantId
			)
			SELECT 
				udtt.WasherId, 
				udtt.ControllerEquipmentID,
				udtt.ControllerID,
				udtt.Deviation,
				@PlantId
				FROM
				@udttProductDeviationData udtt 
		END
	ELSE
		BEGIN
	
	UPDATE WPD 
		SET	WPD.ProductDeviation = udtt.Deviation
	FROM TCD.WasherProductDeviations WPD
	
	INNER JOIN @udttProductDeviationData udtt 
			ON WPD.WasherProductDeviationID = udtt.WasherProductDeviationId
		END
END

/*	                                   
###################################################################################################                                           

Stored Procedure:       [TCD].[GetWasherProductDeviationData]                                             

Purpose:				To get washer product deviation.

Parameters:				   @WasherId, @controllerId, @EcolabAccountNumber
																
###################################################################################################                                           
*/
GO
if object_id('TCD.[GetWasherProductDeviationData]') is not null
begin
	drop proc TCD.[GetWasherProductDeviationData]

end
GO

CREATE PROCEDURE [TCD].[GetWasherProductDeviationData](
	 @WasherId INT
	,@controllerId INT
    , @EcolabAccountNumber NVARCHAR(25))
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE
	    @plantId INT = (SELECT P.PlantId
					  FROM TCD.Plant P
					  WHERE P.EcolabAccountNumber = @EcolabAccountNumber);

	DECLARE @WasherProductDeviationCount INT = (Select COUNT(WasherProductDeviationID) from TCD.WasherProductDeviations where ControllerId = @controllerId AND WasherId = @WasherId)
	DECLARE @ControllerEquipmentSetupCount INT = (Select COUNT(ControllerEquipmentSetupId) from TCD.ControllerEquipmentSetup where ControllerId = @controllerId)

IF(@WasherProductDeviationCount = 0)
	BEGIN
		SELECT	WPD.WasherProductDeviationID,
				CES.ControllerEquipmentId,
				PM.Name,
				CASE CES.ConventionalWasherGroupConnection 
						WHEN 0 THEN 0
						WHEN 1 THEN CAST(ISNULL(wpd.ProductDeviation,100) AS int)
						END ProductDeviation,
				ISNULL(CES.ConventionalWasherGroupConnection,0)
				,PM.EnvisionDisplayName
		FROM
						TCD.ControllerEquipmentSetup CES 
			LEFT JOIN	TCD.WasherProductDeviations WPD	ON	WPD.ControllerId = CES.ControllerId
														AND WPD.ControllerEquipmentID = CES.ControllerEquipmentId
														AND wpd.WasherId = @WasherId
			LEFT JOIN	TCD.ProductMaster PM				ON	PM.ProductId = CES.ProductId
		WHERE CES.ControllerId = @controllerId

		ORDER BY WPD.ControllerEquipmentId

	END
ELSE
	BEGIN
		   SELECT 
					WPD.WasherProductDeviationID,
					WPD.ControllerEquipmentId,
					PM.Name,
					CASE CES.ConventionalWasherGroupConnection 
						WHEN 0 THEN 0
						WHEN 1 THEN CAST(ISNULL(wpd.ProductDeviation,100) AS int)
						END ProductDeviation,
					ISNULL(CES.ConventionalWasherGroupConnection,0),
					PM.EnvisionDisplayName
			FROM 
							TCD.WasherProductDeviations WPD
				INNER JOIN	TCD.ControllerEquipmentSetup CES	ON	WPD.ControllerId = CES.ControllerId
																AND WPD.ControllerEquipmentID = CES.ControllerEquipmentId 
																AND wpd.WasherId = @WasherId
				LEFT JOIN	TCD.ProductMaster PM				ON	PM.ProductId = CES.ProductId

		WHERE WPD.ControllerId = @controllerId AND PlantId = @plantId

		ORDER BY WPD.ControllerEquipmentId
	END
   SET NOCOUNT OFF;
END;

/*	                                   
###################################################################################################                                           

Stored Procedure:       [TCD].[GetControllerEquipmentList]                                             

Purpose:				To get controller equipment data.

Parameters:				@EcoLabAccountNumber, @ControllerId, @ControllerEquipmentId, @IsActive 
																
###################################################################################################                                           
*/
GO
if object_id('TCD.[GetControllerEquipmentList]') is not null
begin
	drop proc TCD.[GetControllerEquipmentList]

end
GO

CREATE PROCEDURE [TCD].[GetControllerEquipmentList]                  
  @EcoLabAccountNumber     NVARCHAR(1000)                  
    , @ControllerId       INT                  
    , @ControllerEquipmentId     TINYINT = NULL                  
    , @IsActive       BIT = NULL                  
AS                  
BEGIN                  
    SET NOCOUNT ON;                  
    DECLARE                  
     @ErrorMessage         NVARCHAR(4000)                  
     ,@PumpValveCount        TINYINT                  
     ,@MECount          TINYINT                  
     ,@ControllerEquipmentTypeId_PumpValve    TINYINT                  
     ,@ControllerEquipmentTypeId_ME      TINYINT                  
     ,@ControllerModelId        INT                  
     ,@ReturnValue         INT = 0                  
     ,@TagTypeLfs         VARCHAR(100) = 'Tag_NML'                  
     ,@TagTypeKfactor         VARCHAR(100) = 'Tag_PPOL'                  
     ,@TagTypeCalibration        VARCHAR(100) = 'Tag_OPSL'            
 ,@ControllerTypeId INT;                  
             
    CREATE TABLE #Equipment (                  
    ControllerEquipmentId     INT    IDENTITY(1, 1)                  
  , ControllerEquipmentTypeId     TINYINT   NULL                  
  , IsActive        BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , ProductId        INT    NULL                  
  , ProductName       NVARCHAR(255)  NULL                  
  , PumpCalibration       DECIMAL(18, 3)  NULL                  
  , FlowMeterSwitchFlag      BIT    NULL                  
  , FlowMeterCalibration      INT    NULL                  
  , MaximumDosingTime      SMALLINT   NULL                  
  , FlowSwitchTimeOut       decimal(18,1)   NULL                  
  , ControllerEquipmentSetupId    SMALLINT   NULL                  
  , LfsChemicalName       NVARCHAR(200)  NULL                  
  , KFactor        DECIMAL(18, 2)  NULL                  
  , TunnelHold        BIT    NULL                  
  , FlowDetectorType      INT    NULL                  
  , FlowSwitchAlarm       BIT    NULL                  
  , FlowMeterAlarm       BIT    NULL                  
  , FlowMeterType       INT    NULL                  
  , FlowAlarmDelay       INT    NULL                  
  , FlowMeterPumpDelay      INT    NULL                  
  , FlowMeterAlarmDelay      INT    NULL                  
  , LastModifiedTime      DATETIME   NULL                  
  , LastSyncTime       DATETIME   NULL                  
  , ControllerEquipmentTypeModelID    INT    NULL                  
  , ConventionalWasherGroupConnection   BIT    NOT NULL                  
              DEFAULT                  
              0                  
  , AxillaryPumpCalibration     SMALLINT   NULL                  
  , FlowmeterSwitchActivated     BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , FlushWhileDosing      BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , WeightControlledDosage     BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , EquipmentDoseAlone      BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , LowLevelAlarm       BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , LeakageAlarm       BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , FlushTime        SMALLINT   NULL                  
  , PumpingTime       SMALLINT   NULL                  
  , PreFlushTime       SMALLINT   NULL                  
  , NightFlushPauseTime      SMALLINT   NULL                  
  , NightFlushTime       SMALLINT   NULL                  
  , AcceptedDeviation      SMALLINT   NULL                 
  , LineNumber    tinyint NULL DEFAULT 0                
  , DirectDosingFlag      BIT    NULL                  
              DEFAULT                  
              'FALSE'               
  , DirectDosingMachineInternalId    INT    NULL                  
  , DirectDosingTunnelCompartmentId   INT    NULL                  
  , WasherGroupTypeId     INT    NULL                 
  , NumberOfCompartments     INT    NULL                   
  , FlushValveNumber      TINYINT   NULL                
  , CalibrationConductSS_Tank    DECIMAL(18,2)   NULL                
  , BackFlowControl       BIT    NULL                
  , FactorFM_B_FM       SMALLINT         NULL                
  , AcceptedDeviationRingLine    SMALLINT  NULL                
  , UsePumpOfGroup1ForTunnel    BIT    NULL                
  , pHSensorEnabled       BIT    NULL                
  , Concentration    INT    NULL              
  , Deadband              BIT    NULL             
  , WasherGroupNumber    INT     NULL           
  , ValveOutputAsTom  BIT NOT NULL DEFAULT  'FALSE'          
  , FlowSwitchNumber int  NULL           
  , FlushTimeForFlushValve int NULL      
    , MinimumFlowRate INT NULL    
  , ProductDensity DECIMAL(18,2) NULL    
  , MaximumConcentration INT NULL  
  , DosingLineMode INT NULL  
   );                  
    IF NOT EXISTS ( SELECT 1                  
        FROM TCD.ConduitController   CC                  
        WHERE CC.EcoalabAccountNumber = @EcoLabAccountNumber                  
AND CC.ControllerId = @ControllerId                  
    )                  
    BEGIN                  
    SET   @ErrorMessage = 'Invalid Plant/Controller combination specified';                  
    RAISERROR (@ErrorMessage, 16, 1);                  
    SET  @ReturnValue = -1;                  
    RETURN                  
    @ReturnValue;                  
    END;                  
    SET @ControllerTypeId = (SELECT ControllerTypeid            
       FROM TCD.ConduitController CC            
       WHERE CC.ControllerId = @ControllerId);            
    SELECT @ControllerModelId = CC.ControllerModelId                  
  FROM TCD.ConduitController CC                  
  WHERE CC.ControllerId = @ControllerId;                  
    SELECT @ControllerEquipmentTypeId_PumpValve = CASE                  
              WHEN CET.ControllerEquipmentTypeName = 'Pump/Valve'                  
              THEN CET.ControllerEquipmentTypeId                  
              ELSE @ControllerEquipmentTypeId_PumpValve                  
              END                  
     , @ControllerEquipmentTypeId_ME = CASE                  
           WHEN CET.ControllerEquipmentTypeName = 'ME'                  
           THEN CET.ControllerEquipmentTypeId                  
           ELSE @ControllerEquipmentTypeId_ME                  
           END                  
  FROM TCD.ControllerEquipmentType CET                  
  WHERE CET.ControllerEquipmentTypeName   IN   ('Pump/Valve', 'ME');                  
    IF (@ControllerModelId <> 7 AND @ControllerModelId  <> 8 AND @ControllerModelId <> 9 AND @ControllerModelId <> 11      
    AND @ControllerModelId <> 10 AND @ControllerModelId <> 14)                
    BEGIN                  
    SELECT @PumpValveCount = ISNULL(CSD.Value, 0)                  
      FROM TCD.ConduitController CC                  
       JOIN                  
       TCD.ControllerModelControllerTypeMapping CMCTM ON CC.ControllerModelId = CMCTM.ControllerModelId                  
       JOIN                  
       TCD.ControllerSetupData CSD ON CSD.ControllerId = CC.ControllerId                  
          AND CC.ControllerTypeId = CMCTM.ControllerTypeId                  
       JOIN                  
       TCD.FieldGroup FG ON FG.ControllerModelId = CC.ControllerModelId                  
        AND FG.ControllerTypeId = CC.ControllerTypeId                  
        AND FG.TabId = 3                  
       INNER JOIN                  
       TCD.FieldGroupFieldMapping FGM ON FGM.FieldGroupId = FG.Id                  
       INNER JOIN            
       TCD.Field F ON F.Id = FGM.FieldId                  
      AND CSD.FieldId = f.Id                  
      WHERE CC.ControllerId = @ControllerId                  
    AND F.ResourceKey = 'No._of_Chemical_Valves'                  
    AND CSD.EcolabAccountNumber = @EcoLabAccountNumber;                  
    SELECT @MECount = ISNULL(CMCTM.MECount, 0)                  
      FROM TCD.ConduitController CC                  
       JOIN                  
       TCD.ControllerModelControllerTypeMapping CMCTM ON CC.ControllerModelId = CMCTM.ControllerModelId                  
             AND CC.ControllerTypeId = CMCTM.ControllerTypeId                  
      WHERE CC.ControllerId = @ControllerId;                  
    END;         
    ELSE IF(@ControllerModelId = 11)                
    BEGIN                
    SELECT @PumpValveCount = 2*CMCTM.PumpValveCount                
     , @MECount = 2*CMCTM.MECount                
      FROM TCD.ControllerModelControllerTypeMapping CMCTM                
      WHERE CMCTM.ControllerModelId = @ControllerModelId;                
    END;                
  ELSE IF(@ControllerModelId = 7 OR @ControllerModelId = 8 OR @ControllerModelId = 9 OR @ControllerModelId = 10  OR @ControllerModelId = 14)                
  BEGIN                
    SELECT @PumpValveCount = CMCTM.PumpValveCount            
 , @MECount = CMCTM.MECount            
  FROM TCD.ControllerModelControllerTypeMapping CMCTM            
  WHERE CMCTM.ControllerModelId = @ControllerModelId            
    AND CMCTM.ControllerTypeId = @ControllerTypeId;                
    END;                
    IF (SELECT ISNULL(@PumpValveCount, 0)                  
    +                  
    ISNULL(@MECount, 0)) = 0                  
    BEGIN                  
    SELECT                  
    T.ControllerEquipmentId  AS   ControllerEquipmentId                  
  , T.ControllerEquipmentTypeId  AS   ControllerEquipmentTypeId                  
  , T.IsActive     AS   IsActive                  
  , T.ProductId     AS   ProductId                  
  , T.ProductName    AS   ProductName                  
  , T.PumpCalibration    AS   PumpCalibration                  
  , T.FlowMeterSwitchFlag   AS   FlowMeterSwitchFlag                  
  , T.MaximumDosingTime   AS   MaximumDosingTime                  
  , T.FlowSwitchTimeOut   AS   FlowSwitchTimeOut                  
  , T.ControllerEquipmentSetupId AS   ControllerEquipmentSetupId                  
  , @EcoLabAccountNumber   AS   EcoLabAccountNumber                  
  , @ControllerId    AS   ControllerId                  
  , CC.TopicName     AS   ControllerName                  
  , CC.ControllerTypeId   AS   ControllerTypeId                  
  , T.LfsChemicalName    AS   LfsChemicalName                  
  , T.KFactor     AS   KFactor                  
  , T.TunnelHold     AS   TunnelHold                  
  , T.FlowDetectorType   AS   FlowDetectorType                  
  , T.FlowSwitchAlarm    AS   FlowSwitchAlarm                  
  , T.FlowMeterAlarm    AS   FlowMeterAlarm                  
  , T.FlowMeterType    AS   FlowMeterType                  
  , T.FlowAlarmDelay    AS   FlowAlarmDelay                  
  , T.FlowMeterPumpDelay   AS   FlowMeterPumpDelay                  
  , T.FlowMeterAlarmDelay   AS   FlowMeterAlarmDelay                  
  , T.ControllerEquipmentTypeModelID                  
  , T.ConventionalWasherGroupConnection                  
  , T.AxillaryPumpCalibration                  
  , T.FlowmeterSwitchActivated                  
  , T.FlushWhileDosing                  
  , T.WeightControlledDosage                  
  , T.EquipmentDoseAlone                  
  , T.LowLevelAlarm                  
  , T.LeakageAlarm                  
  , T.FlushTime                  
  , T.PumpingTime                  
  , T.PreFlushTime                  
  , T.NightFlushPauseTime                  
  , T.NightFlushTime                  
  , T.AcceptedDeviation                 
  , T.LineNumber                 
  , T.DirectDosingFlag        
  , T.DirectDosingMachineInternalId                  
  , T.DirectDosingTunnelCompartmentId             
  , T.WasherGroupTypeId                     
  , T.NumberOfCompartments                     
  , T.FlushValveNumber                      
  , T.CalibrationConductSS_Tank                   
  , T.BackFlowControl                       
  , T.FactorFM_B_FM                      
  , T.AcceptedDeviationRingLine                    
  , T.UsePumpOfGroup1ForTunnel      
  , T.pHSensorEnabled               
  , T.Concentration                 
  , T.Deadband             
  , T.WasherGroupNumber             
  , T.ValveOutputAsTom            
  , T.FlowSwitchNumber           
  , T.FlushTimeForFlushValve      
   , T.MinimumFlowRate     
  , T.ProductDensity     
  , T.MaximumConcentration  
  ,T.DosingLineMode  
  , (                  
    SELECT MTS.TagAddress                  
      FROM TCD.ModuleTags MTS                  
      WHERE MTS.TagType = @TagTypeLfs                  
    AND MTS.ModuleID = ControllerEquipmentSetupId                  
    AND MTS.ModuleTypeId = 4                  
    AND MTS.Active = 1) AS LfsChemicalNameTag                  
  , (         
    SELECT MTS.TagAddress                  
      FROM TCD.ModuleTags MTS                  
      WHERE MTS.TagType = @TagTypeKfactor                  
    AND MTS.ModuleID = ControllerEquipmentSetupId                  
    AND MTS.ModuleTypeId = 4                  
    AND MTS.Active = 1) AS KfactorTag                  
  , (                  
    SELECT MTS.TagAddress                  
      FROM TCD.ModuleTags MTS                  
      WHERE MTS.TagType = @TagTypeCalibration                  
    AND MTS.ModuleID = ControllerEquipmentSetupId                  
    AND MTS.ModuleTypeId = 4                  
    AND MTS.Active = 1) AS CalibrationTag                  
  , T.LastModifiedTime  AS  LastModifiedTime                  
  , T.LastSyncTime   AS  LastSyncTime                  
      FROM #Equipment  T                  
    JOIN                  
    TCD.ConduitController CC                  
    ON CC.ControllerId = @ControllerId                  
      WHERE T.IsActive = ISNULL(@IsActive, T.IsActive)                  
    AND T.ControllerEquipmentId = ISNULL(@ControllerEquipmentId, T.ControllerEquipmentId);                  
    RETURN                  
    @ReturnValue;               
                 
    END;             
    ELSE          
    BEGIN          
    IF ((SELECT ISNULL(@PumpValveCount, 0)                  
    +                  
    ISNULL(@MECount, 0)) = (SELECT COUNT(*) FROM TCD.ControllerEquipmentSetup CES     WHERE CES.ControllerId    = @ControllerId))          
      BEGIN          
      SET IDENTITY_INSERT #Equipment ON          
      INSERT INTO #Equipment (ControllerEquipmentId, ControllerEquipmentTypeId)             
      SELECT CES.ControllerEquipmentId, CES.ControllerEquipmentTypeId FROM TCD.ControllerEquipmentSetup CES WHERE CES.ControllerId = @ControllerId           
      SET IDENTITY_INSERT #Equipment OFF          
      END
	  ELSE
	  BEGIN
		 IF ISNULL(@PumpValveCount, 0) <> 0                  
    BEGIN                  
    WITH NumCTE (N)                  
    AS(SELECT '*' AS N                  
  UNION ALL                  
       SELECT '*' AS N)                  
    INSERT INTO #Equipment (ControllerEquipmentTypeId)                  
    SELECT TOP (@PumpValveCount) @ControllerEquipmentTypeId_PumpValve                  
      FROM NumCTE N1, NumCTE N2, NumCTE N3, NumCTE N4, NumCTE N5;                  
    END;                  
    IF ISNULL(@MECount, 0) <> 0                  
    BEGIN                  
    WITH NumCTE (N)                  
    AS (SELECT '*' AS N                  
    UNION ALL                  
    SELECT '*' AS N)                  
    INSERT INTO #Equipment(ControllerEquipmentTypeId)                  
    SELECT TOP (@MECount)@ControllerEquipmentTypeId_ME                  
      FROM NumCTE N1, NumCTE N2, NumCTE N3, NumCTE N4, NumCTE N5;                  
    END;   
	  END          
    END           
    UPDATE U                  
  SET U.IsActive = CES.IsActive                  
    , U.ProductId = CES.ProductId                  
    , U.ProductName = (SELECT ISNULL(PM.EnvisionDisplayName, PM.Name)                  
         FROM TCD.ProductMaster PM                  
         WHERE PM.ProductId = CES.ProductId)                  
    , U.PumpCalibration = CES.PumpCalibration                  
    , U.FlowMeterSwitchFlag = CES.FlowMeterSwitchFlag                  
    , U.MaximumDosingTime = CES.MaximumDosingTime                  
    , U.FlowSwitchTimeOut = CES.FlowSwitchTimeOut                  
    , U.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId                  
    , U.LfsChemicalName = CES.LfsChemicalName                  
    , U.KFactor = CES.KFactor                  
    , U.TunnelHold = CES.TunnelHold                  
    , U.FlowDetectorType = CES.FlowDetectorType                  
    , U.FlowSwitchAlarm = CES.FlowSwitchAlarm                  
    , U.FlowMeterAlarm = CES.FlowMeterAlarm                  
    , U.FlowMeterType = CES.FlowMeterType                  
    , U.FlowAlarmDelay = CES.FlowAlarmDelay                  
    , U.FlowMeterPumpDelay = CES.FlowMeterPumpDelay                  
    , U.FlowMeterAlarmDelay = CES.FlowMeterAlarmDelay                  
    , U.ControllerEquipmentTypeModelID = CES.ControllerEquipmentTypeModelID                  
    , U.ConventionalWasherGroupConnection = CES.ConventionalWasherGroupConnection                  
    , U.AxillaryPumpCalibration = CES.AxillaryPumpCalibration                  
    , U.FlowmeterSwitchActivated = CES.FlowmeterSwitchActivated                  
    , U.FlushWhileDosing = CES.FlushWhileDosing                  
    , U.WeightControlledDosage = CES.WeightControlledDosage                  
    , U.EquipmentDoseAlone = CES.EquipmentDoseAlone                  
    , U.LowLevelAlarm = CES.LowLevelAlarm                  
    , U.LeakageAlarm = CES.LeakageAlarm                  
    , U.FlushTime = CES.FlushTime                  
    , U.PumpingTime = CES.PumpingTime                  
    , U.PreFlushTime = CES.PreFlushTime                  
    , U.NightFlushPauseTime = CES.NightFlushPauseTime                  
    , U.NightFlushTime = CES.NightFlushTime                  
    , U.AcceptedDeviation = CES.AcceptedDeviation                 
    , U.LineNumber = CES.LineNumber                 
    , U.DirectDosingFlag = TCEVM.DirectDosingFlag                  
    , U.DirectDosingMachineInternalId = TCEVM.TunnelNumber                  
    , U.DirectDosingTunnelCompartmentId = TCEVM.CompartmentNumber                
    , U.LastModifiedTime = CES.LastModifiedTime                  
    , U.LastSyncTime = CES.LastSyncTime                
    , U.FlushValveNumber      = CES.FlushValveNumber                
  , U.CalibrationConductSS_Tank    = CES.CalibrationConductSS_Tank              
  , U.BackFlowControl     = CES.BackFlowControl                  
  , U.FactorFM_B_FM       = CES.FactorFM_B_FM               
  , U.AcceptedDeviationRingLine  = CES.AcceptedDeviationRingLine                  
  , U.UsePumpOfGroup1ForTunnel   = CES.UsePumpOfGroup1ForTunnel              
  , U.pHSensorEnabled            = CES.pHSensorEnabled              
  , U.Concentration = CES.Concentration              
  , U.Deadband = CES.Deadband             
  , U.WasherGroupNumber = CES.WasherGroupNumber          
  , U.ValveOutputAsTom = CES.ValveOutputAsTom          
  , U.FlowSwitchNumber = CES.FlowSwitchNumber         
  , U.FlushTimeForFlushValve = CES.FlushTimeForFlushValve      
    , U.MinimumFlowRate = CES.MinimumFlowRate    
  , U.ProductDensity = CES.ProductDensity    
  , U.MaximumConcentration  = CES.MaximumConcentration    
  ,U.DosingLineMode =1 
  FROM #Equipment U                  
   JOIN                  
   TCD.ControllerEquipmentSetup CES                  
  ON U.ControllerEquipmentId = CES.ControllerEquipmentId                  
  AND U.ControllerEquipmentTypeId = CES.ControllerEquipmentTypeId               
  JOIN TCD.ConduitController CC ON CES.ControllerID = CC.ControllerId                
  LEFT JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId                
  LEFT JOIN TCD.WasherGroup WG ON CES.ControllerID = WG.ControllerID                 
  LEFT JOIN TCD.MachineSetup MS ON WG.ControllerId = MS.ControllerId          
  WHERE CES.EcoLabAccountNumber = @EcoLabAccountNumber                  
   AND CES.ControllerId = @ControllerId; 
      IF(@ControllerModelId = 7)  
   BEGIN  
   Declare @DosingLineMode varchar(100) ,@NoOfPumpsConnected  varchar(100), @Counter int  
                                                                                                                                                                                                                                         
   
select @DosingLineMode =CES.Value  
       FROM TCD.ControllerSetupdata CES  
       INNER JOIN [TCD].[Field] F ON F.Id = CES.FieldId  
       AND EcoLabAccountNumber=@EcoLabAccountNumber  
       AND ControllerId=@ControllerId  
       AND ResourceKey ='Dosing_Line_Mode1'  
   
--select @DosingLineMode  
   
IF RTRIM( LTRIM(@DosingLineMode)) ='2'  
BEGIN  
 set @Counter = 1;  
       select @NoOfPumpsConnected = CES.Value   
       FROM TCD.ControllerSetupdata CES  
              INNER JOIN [TCD].[Field] F ON F.Id = CES.FieldId  
              AND EcoLabAccountNumber=@EcoLabAccountNumber  
              AND ControllerId=@ControllerId  
              AND ResourceKey ='No_of_Pumps_Connected_to_TCR1'  
       select @NoOfPumpsConnected = cast(@NoOfPumpsConnected as int)  
       update A set A.LineNumber =1,  
       A.DosingLineMode = 2  
       from #Equipment A where   ControllerEquipmentId >= 1 and ControllerEquipmentId <= @NoOfPumpsConnected  
END  
  
  
select @DosingLineMode =CES.Value  
       FROM TCD.ControllerSetupdata CES  
       INNER JOIN [TCD].[Field] F ON F.Id = CES.FieldId  
       AND EcoLabAccountNumber=@EcoLabAccountNumber  
       AND ControllerId=@ControllerId  
       AND ResourceKey ='Dosing_Line_Mode2'  
   
--select @DosingLineMode  
  
IF RTRIM( LTRIM(@DosingLineMode)) ='2'  
BEGIN  
    
 set @Counter = 9;  
       select @NoOfPumpsConnected = CES.Value   
       FROM TCD.ControllerSetupdata CES  
              INNER JOIN [TCD].[Field] F ON F.Id = CES.FieldId  
              AND EcoLabAccountNumber=@EcoLabAccountNumber  
              AND ControllerId=@ControllerId  
              AND ResourceKey ='No_of_Pumps_Connected_to_TCR2'  
       SET @NoOfPumpsConnected = cast(@NoOfPumpsConnected as int)  
       SET @NoOfPumpsConnected = @NoOfPumpsConnected + @Counter ;  
       update A set A.LineNumber =2,  
       A.DosingLineMode = 2  
       from #Equipment A where   ControllerEquipmentId BETWEEN  @Counter and  @NoOfPumpsConnected  
END  
  
  
select @DosingLineMode =CES.Value  
       FROM TCD.ControllerSetupdata CES  
       INNER JOIN [TCD].[Field] F ON F.Id = CES.FieldId  
       AND EcoLabAccountNumber=@EcoLabAccountNumber  
       AND ControllerId=@ControllerId  
       AND ResourceKey ='Dosing_Line_Mode3'  
   
--select @DosingLineMode  
   
IF RTRIM( LTRIM(@DosingLineMode)) ='2'  
BEGIN  
 set @Counter = 17;  
       select @NoOfPumpsConnected = CES.Value   
       FROM TCD.ControllerSetupdata CES  
              INNER JOIN [TCD].[Field] F ON F.Id = CES.FieldId  
              AND EcoLabAccountNumber=@EcoLabAccountNumber  
              AND ControllerId=@ControllerId  
              AND ResourceKey ='No_of_Pumps_Connected_to_TCR3'  
       SET @NoOfPumpsConnected = cast(@NoOfPumpsConnected as int)  
       SET @NoOfPumpsConnected = @NoOfPumpsConnected + @Counter ;  
       update A set A.LineNumber =3,  
       A.DosingLineMode = 2  
       from #Equipment A where   ControllerEquipmentId BETWEEN  @Counter and  @NoOfPumpsConnected  
END  
  
  
   END 
                 
   IF(@ControllerModelId = 11)                
   BEGIN            
   UPDATE U             
   SET U.WasherGroupTypeId = (SELECT MIN(WG.WasherGroupTypeId) FROM TCD.WasherGroup WG WHERE WG.ControllerId = @ControllerId)            
    FROM #Equipment U                  
JOIN                  
   TCD.ControllerEquipmentSetup CES                  
  ON U.ControllerEquipmentId = CES.ControllerEquipmentId                  
  AND U.ControllerEquipmentTypeId = CES.ControllerEquipmentTypeId                
  WHERE CES.EcoLabAccountNumber = @EcoLabAccountNumber                  
   AND CES.ControllerId = @ControllerId            
   AND CES.ControllerEquipmentId IN (select top 14 CES.ControllerEquipmentId FROM  TCD.ControllerEquipmentSetup CES            
   where CES.ControllerId = @ControllerId )            
              
     UPDATE U             
   SET U.WasherGroupTypeId = (SELECT MAX(WG.WasherGroupTypeId) FROM TCD.WasherGroup WG WHERE WG.ControllerId = @ControllerId)            
    FROM #Equipment U                  
   JOIN                  
   TCD.ControllerEquipmentSetup CES                  
  ON U.ControllerEquipmentId = CES.ControllerEquipmentId                  
  AND U.ControllerEquipmentTypeId = CES.ControllerEquipmentTypeId               
  JOIN TCD.ConduitController CC ON CES.ControllerID = CC.ControllerId         
  WHERE CES.EcoLabAccountNumber = @EcoLabAccountNumber                  
   AND CES.ControllerId = @ControllerId            
   AND CES.ControllerEquipmentId IN (select  CES.ControllerEquipmentId FROM TCD.ControllerEquipmentSetup CES            
    where CES.ControllerId = @ControllerId AND             
    CES.ControllerEquipmentId BETWEEN 15 AND 28 )        
           
   UPDATE U SET U.NumberOfCompartments = ms.NumberOfComp        
   FROM #Equipment U        
   INNER JOIN TCD.ControllerEquipmentSetup ces        
   ON u.ControllerEquipmentId = ces.ControllerEquipmentId         
   INNER JOIN TCD.WasherGroup wg ON ces.ControllerId = WG.ControllerId        
   INNER JOIN TCD.MachineSetup ms ON ms.ControllerId = ces.ControllerId AND ms.GroupId = WG.WasherGroupId        
   WHERE ces.ControllerId = @ControllerId AND U.WasherGroupTypeId = 2  AND ms.IsTunnel = 1 AND WG.WasherDosingNumber = U.WasherGroupNumber        
   END          
             
  -- END                
    GOTO ExitModule;                  
    ExitModule:                  
    SELECT                  
    T.ControllerEquipmentId   AS ControllerEquipmentId                  
  , T.ControllerEquipmentTypeId AS ControllerEquipmentTypeId                  
  , T.IsActive      AS IsActive                  
  , T.ProductId     AS ProductId                  
  , T.ProductName     AS ProductName                  
  , T.PumpCalibration    AS PumpCalibration                  
  , T.FlowMeterSwitchFlag   AS FlowMeterSwitchFlag                  
  , T.MaximumDosingTime    AS MaximumDosingTime                  
  , T.FlowSwitchTimeOut    AS FlowSwitchTimeOut                  
  , T.ControllerEquipmentSetupId  AS ControllerEquipmentSetupId                  
  , @EcoLabAccountNumber    AS EcoLabAccountNumber                  
  , @ControllerId     AS ControllerId                  
  , CC.TopicName     AS ControllerName                  
  , CC.ControllerTypeId    AS ControllerTypeId                  
  , T.LfsChemicalName    AS LfsChemicalName                  
  , T.KFactor      AS KFactor                  
  , T.TunnelHold     AS TunnelHold                  
  , T.FlowDetectorType    AS FlowDetectorType                  
, T.FlowSwitchAlarm    AS FlowSwitchAlarm                  
  , T.FlowMeterAlarm    AS FlowMeterAlarm                  
  , T.FlowMeterType     AS FlowMeterType                  
 , T.FlowAlarmDelay    AS FlowAlarmDelay                  
  , T.FlowMeterPumpDelay    AS FlowMeterPumpDelay                  
  , T.FlowMeterAlarmDelay   AS FlowMeterAlarmDelay                  
  , (                  
    SELECT MTS.TagAddress                  
  FROM TCD.ModuleTags MTS                  
  WHERE MTS.TagType = @TagTypeLfs                  
    AND MTS.ModuleID = ControllerEquipmentSetupId                  
    AND MTS.ModuleTypeId = 4                  
    AND MTS.Active = 1) AS LfsChemicalNameTag                  
  , (                  
    SELECT MTS.TagAddress                  
  FROM TCD.ModuleTags MTS                  
  WHERE MTS.TagType = @TagTypeKfactor                  
    AND MTS.ModuleID = ControllerEquipmentSetupId                  
    AND MTS.ModuleTypeId = 4                  
    AND MTS.Active = 1) AS KfactorTag                  
  , (                  
    SELECT MTS.TagAddress                  
  FROM TCD.ModuleTags MTS                  
  WHERE MTS.TagType = @TagTypeCalibration                  
    AND MTS.ModuleID = ControllerEquipmentSetupId                  
    AND MTS.ModuleTypeId = 4                  
    AND MTS.Active = 1) AS CalibrationTag                  
  , T.ControllerEquipmentTypeModelID                  
  , T.ConventionalWasherGroupConnection                  
  , T.AxillaryPumpCalibration                  
  , T.FlowmeterSwitchActivated                  
  , T.FlushWhileDosing                  
  , T.WeightControlledDosage                  
  , T.EquipmentDoseAlone                  
  , T.LowLevelAlarm                  
  , T.LeakageAlarm                  
  , T.FlushTime                  
  , T.PumpingTime                  
  , T.PreFlushTime                  
  , T.NightFlushPauseTime                  
  , T.NightFlushTime                  
  , T.AcceptedDeviation                  
  , T.LineNumber                
  , T.DirectDosingFlag                  
  , T.DirectDosingMachineInternalId                  
  , T.DirectDosingTunnelCompartmentId                  
  , T.LastModifiedTime    AS LastModifiedTime                  
  , T.LastSyncTime     AS LastSyncTime             
  , T.WasherGroupTypeId                     
  , T.NumberOfCompartments                     
  , T.FlushValveNumber                      
  , T.CalibrationConductSS_Tank                   
  , T.BackFlowControl                       
  , T.FactorFM_B_FM                      
  , T.AcceptedDeviationRingLine                    
  , T.UsePumpOfGroup1ForTunnel                    
  , T.pHSensorEnabled                
  , T.Concentration              
  , T.Deadband              
  , T.WasherGroupNumber          
  , T.ValveOutputAsTom          
  , T.FlowSwitchNumber          
  , T.FlushTimeForFlushValve      
    , T.MinimumFlowRate     
  , T.ProductDensity     
  , T.MaximumConcentration   
  , T.DosingLineMode 
  FROM #Equipment T                  
   JOIN                  
   TCD.ConduitController CC ON CC.ControllerId = @ControllerId                  
  WHERE T.IsActive = ISNULL(@IsActive, T.IsActive)                  
   AND T.ControllerEquipmentId = ISNULL(@ControllerEquipmentId, T.ControllerEquipmentId)        
   ORDER BY  T.ControllerEquipmentId;                  
    SET NOCOUNT OFF;                  
    RETURN                  
    @ReturnValue;                  
END;   
  
  
/*  
End TCD.GetControllerEquipmentList  
  
*/  
  
GO

IF EXISTS (SELECT * FROM [TCD].ControllerModelRegionMapping WHERE CONTROLLERMODELID = 7 AND REGIONID = 2)
BEGIN
	UPDATE [TCD].ControllerModelRegionMapping SET DISPLAYORDER  = 1 WHERE CONTROLLERMODELID = 7 AND REGIONID = 2
END
GO
IF EXISTS (SELECT * FROM [TCD].ControllerModelRegionMapping WHERE CONTROLLERMODELID = 5 AND REGIONID = 2)
BEGIN
	UPDATE [TCD].ControllerModelRegionMapping SET DISPLAYORDER  = 2 WHERE CONTROLLERMODELID = 5 AND REGIONID = 2
END
GO
IF EXISTS (SELECT * FROM [TCD].ControllerModelRegionMapping WHERE CONTROLLERMODELID = 6 AND REGIONID = 2)
BEGIN
	UPDATE [TCD].ControllerModelRegionMapping SET DISPLAYORDER  = 3 WHERE CONTROLLERMODELID = 6 AND REGIONID = 2
END
GO
IF EXISTS (SELECT * FROM [TCD].ControllerModelRegionMapping WHERE CONTROLLERMODELID = 8 AND REGIONID = 2)
BEGIN
	UPDATE [TCD].ControllerModelRegionMapping SET DISPLAYORDER  = 4 WHERE CONTROLLERMODELID = 8 AND REGIONID = 2
END
GO
IF EXISTS (SELECT * FROM [TCD].ControllerModelRegionMapping WHERE CONTROLLERMODELID = 10 AND REGIONID = 2)
BEGIN
	UPDATE [TCD].ControllerModelRegionMapping SET DISPLAYORDER  = 5 WHERE CONTROLLERMODELID = 10 AND REGIONID = 2
END
GO
IF EXISTS (SELECT * FROM [TCD].ControllerModelRegionMapping WHERE CONTROLLERMODELID = 9 AND REGIONID = 2)
BEGIN
	UPDATE [TCD].ControllerModelRegionMapping SET DISPLAYORDER  = 6 WHERE CONTROLLERMODELID = 9 AND REGIONID = 2
END
GO
IF EXISTS (SELECT * FROM [TCD].ControllerModelRegionMapping WHERE CONTROLLERMODELID = 14 AND REGIONID = 2)
BEGIN
	UPDATE [TCD].ControllerModelRegionMapping SET DISPLAYORDER  = 7 WHERE CONTROLLERMODELID = 14 AND REGIONID = 2
END
GO
IF EXISTS (SELECT * FROM [TCD].ControllerModelRegionMapping WHERE CONTROLLERMODELID = 11 AND REGIONID = 2)
BEGIN
	UPDATE [TCD].ControllerModelRegionMapping SET DISPLAYORDER  = 8 WHERE CONTROLLERMODELID = 11 AND REGIONID = 2
END
GO
IF EXISTS (SELECT * FROM [TCD].ControllerModelRegionMapping WHERE CONTROLLERMODELID = 1 AND REGIONID = 2)
BEGIN
	UPDATE [TCD].ControllerModelRegionMapping SET DISPLAYORDER  = 9 WHERE CONTROLLERMODELID = 1 AND REGIONID = 2
END
GO
IF EXISTS (SELECT * FROM [TCD].ControllerModelRegionMapping WHERE CONTROLLERMODELID = 2 AND REGIONID = 2)
BEGIN
	UPDATE [TCD].ControllerModelRegionMapping SET DISPLAYORDER  = 10 WHERE CONTROLLERMODELID = 2 AND REGIONID = 2
END
GO
IF EXISTS (SELECT * FROM [TCD].ControllerModelRegionMapping WHERE CONTROLLERMODELID = 3 AND REGIONID = 2)
BEGIN
	UPDATE [TCD].ControllerModelRegionMapping SET DISPLAYORDER  = 11 WHERE CONTROLLERMODELID = 3 AND REGIONID = 2
END
GO
IF EXISTS (SELECT * FROM [TCD].ControllerModelRegionMapping WHERE CONTROLLERMODELID = 4 AND REGIONID = 2)
BEGIN
	UPDATE [TCD].ControllerModelRegionMapping SET DISPLAYORDER  = 12 WHERE CONTROLLERMODELID = 4 AND REGIONID = 2
END
GO
IF EXISTS (SELECT * FROM [TCD].ControllerModelRegionMapping WHERE CONTROLLERMODELID = 13 AND REGIONID = 2)
BEGIN
	UPDATE [TCD].ControllerModelRegionMapping SET DISPLAYORDER  = 13 WHERE CONTROLLERMODELID = 13 AND REGIONID = 2
END
ELSE
BEGIN
	INSERT INTO [TCD].ControllerModelRegionMapping (CONTROLLERMODELID,REGIONID,DISPLAYORDER)
	VALUES(13,2,13)
END
GO
IF EXISTS (SELECT * FROM [TCD].ControllerModelRegionMapping WHERE CONTROLLERMODELID = 12 AND REGIONID = 2)
BEGIN
	DELETE [TCD].ControllerModelRegionMapping WHERE CONTROLLERMODELID = 12 AND REGIONID = 2
END
GO
/*	                                   
###################################################################################################                                           

Stored Procedure:       [TCD].[SaveTunnelCompartmentEquipmentValveMapping_XL]                                             

Purpose:				To Save Tunnel Compartment Values for PLCXL.

Parameters:				 @ValveCompartmentMappings, @ControllerEquipmentId, @ControllerId, @EcolabAccountNumber, @UserId
																
###################################################################################################                                           
*/
GO
if object_id('TCD.[SaveTunnelCompartmentEquipmentValveMapping_XL]') is not null
begin
	drop proc TCD.SaveTunnelCompartmentEquipmentValveMapping_XL

end
GO
CREATE PROC [TCD].[SaveTunnelCompartmentEquipmentValveMapping_XL] (    
  @ValveCompartmentMappings TCD.udttTunnelCompartmentEquipmentValveMapping READONLY    
    , @ControllerEquipmentId INT    
    , @ControllerId INT      
    , @EcolabAccountNumber NVARCHAR(25)    
    , @UserId INT    
)    
AS    
BEGIN    
    DECLARE    
     @EquipmentSetupId INT = (SELECT TOP 1 CES.ControllerEquipmentSetupId    
        FROM TCD.ControllerEquipmentSetup CES    
        WHERE CES.ControllerId = @ControllerId    
          AND CES.ControllerEquipmentId = @ControllerEquipmentId ),    
     @PlantId INT = (SELECT TOP 1 PlantId    
  FROM TCD.Plant P    
       WHERE P.EcolabAccountNumber = @EcolabAccountNumber),  
     @DDFlag BIT = CAST(    
     CASE    
     WHEN EXISTS(SELECT 1    
       FROM @ValveCompartmentMappings M    
       WHERE M.DirectDosingFlag = 1) THEN 1    
     ELSE 0    
     END    
     AS BIT);    
    
    /* Delete the values if not necessary */    
    
    IF @DDFlag = 'TRUE'    
    BEGIN    
    DELETE FROM TCD.TunnelCompartmentEquipmentValveMapping    
      WHERE ControllerEquipmentSetupID = @EquipmentSetupId    
    AND DirectDosingFlag = 'FALSE';    
    END;    
    ELSE    
    BEGIN    
    DELETE T    
      FROM TCD.TunnelCompartmentEquipmentValveMapping T    
      WHERE ControllerEquipmentSetupID = @EquipmentSetupId    
    AND T.PlantID = @PlantId    
    AND T.TunnelCompartmentEquipmentValveMappingID NOT IN(    
    SELECT TCEVM.TunnelCompartmentEquipmentValveMappingID    
      FROM TCD.TunnelCompartmentEquipmentValveMapping TCEVM    
       INNER JOIN    
       @ValveCompartmentMappings M ON TCEVM.TunnelNumber = M.TunnelNumber    
             AND TCEVM.DosingPointNumber = M.DosingPointNumber  
			 AND TCEVM.ValveNumber = M.ValveNumber    
             AND TCEVM.ControllerEquipmentSetupID = @EquipmentSetupId    
             AND TCEVM.PlantID = @PlantId);    
    END;   
       
    DECLARE    
     @TempMapping TABLE(    
     RowNumber INT NOT NULL    
   , ControllerEquipmentId TINYINT NOT NULL    
   , TunnelNumber INT NOT NULL    
   , CompartmentNumber TINYINT NOT NULL    
   , DosingPointNumber TINYINT NOT NULL    
   , DirectDosingFlag BIT NOT NULL  
   , ValveNumber TINYINT NOT NULL
   , WasherNumber int NOT NULL);    
    
    /* Create RowNumber inorder to increment and use row by row. */    
    
    WITH CTE_LCM    
    AS (    
    SELECT ROW_NUMBER() OVER (ORDER BY LCM.TunnelNumber, LCM.DosingPointNumber) AS RowNumber    
     , LCM.ControllerEquipmentId  
     , LCM.TunnelNumber  
     , LCM.CompartmentNumber  
     , LCM.DosingPointNumber  
     , LCM.DirectDosingFlag  
     , LCM.ValveNumber  
	 , LCM.WasherNumber
  FROM @ValveCompartmentMappings LCM    
    )    
    INSERT INTO @TempMapping    
    SELECT *    
  FROM CTE_LCM CL;    
    
    /* Loop */    
    
    DECLARE    
     @i INT = 1,    
     @max INT = (SELECT MAX(TM.RowNumber)    
       FROM @TempMapping TM);    
    WHILE @i <= @max    
    BEGIN    
    
    /* Declare and Initialize the current row data */    
    
    DECLARE    
     @TunnelNumber INT,    
     @CompartmentNumber TINYINT,    
     --@DosingpointNumber TINYINT,   
     @ValveNumber TINYINT;  
    SELECT TOP 1 @TunnelNumber = TM.TunnelNumber    
       --, @DosingPointNumber = TM.DosingpointNumber    
       , @CompartmentNumber = TM.CompartmentNumber    
       , @ValveNumber       = TM.ValveNumber  
      FROM @TempMapping TM    
      WHERE TM.RowNumber = @i;    
    --DECLARE    
    -- @ValveNumber INT = 0;    
    --IF @DDFlag = 'FALSE'    
    --BEGIN    
    
    --/* Get Min Available Valve Number */    
    
    --SELECT @ValveNumber = MIN(CEV.ControllerEquipmentValveID)    
    --  FROM TCD.ControllerEquipmentValves CEV    
    --  WHERE ControllerEquipmentValveID <> 0    
    --    AND CEV.ControllerEquipmentValveID  NOT IN (    
    --    SELECT TCEVM.ValveNumber    
    --  FROM TCD.TunnelCompartmentEquipmentValveMapping TCEVM    
    --   JOIN    
    --   TCD.ControllerEquipmentSetup CES ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupID    
    --  WHERE CES.ControllerID = @ControllerId    
    --    AND TCEVM.TunnelNumber = @TunnelNumber);    
    --END;    
    --PRINT @ValveNumber;    
    
    /* Update If Exists else Insert */    
    
    MERGE TCD.TunnelCompartmentEquipmentValveMapping T    
    USING (SELECT TOP 1 *    
     FROM @TempMapping TM    
     WHERE TM.RowNumber = @i) S    
    ON T.ControllerEquipmentSetupID = @EquipmentSetupId    
   --AND T.CompartmentNumber = S.CompartmentNumber    
   AND T.ValveNumber = S.ValveNumber    
    WHEN MATCHED    
      THEN    
      UPDATE SET --T.TunnelNumber = S.TunnelNumber             
        T.CompartmentNumber = S.CompartmentNumber  
       , T.DirectDosingFlag = S.DirectDosingFlag  
       --, T.ValveNumber =  S.ValveNumber  
          
    WHEN NOT MATCHED    
      THEN    
      INSERT (PlantID    
        , ControllerEquipmentSetupID    
        , TunnelNumber    
        , DosingPointNumber    
        , ValveNumber    
        , CompartmentNumber    
        , DirectDosingFlag    
        , LastModifiedByUserID)    
      VALUES (@PlantId,    
      @EquipmentSetupId,    
      S.TunnelNumber,    
      S.DosingPointNumber,    
      S.ValveNumber,    
      S.CompartmentNumber,    
      S.DirectDosingFlag,    
      @UserId);    
    
    /* Increment the row */    
    
    SET @i = @i + 1;    
    END;    
END;

/*	                                   
###################################################################################################                                           

Stored Procedure:       [TCD].[[SaveWasherFlushTime]]                                             

Purpose:				To save washer flush time.

Parameters:				 @udttWasherFlushTime, @EcolabAccountNumber, @UserId
																
###################################################################################################                                           
*/

GO
if object_id('TCD.[SaveWasherFlushTime]') is not null
begin
	drop proc TCD.[SaveWasherFlushTime]

end
GO

CREATE PROCEDURE [TCD].[SaveWasherFlushTime] (
      @udttWasherFlushTime TCD.udttWasherFlushTime READONLY 
    , @EcolabAccountNumber NVARCHAR(25)
    , @UserId INT)
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @CurrentUTC DATETIME = GETUTCDATE(),
			@PlantId INT = (SELECT P.PlantId 
							FROM TCD.Plant P 
							WHERE P.EcolabAccountNumber = @EcolabAccountNumber),
			@IsExistingRecord INT = (SELECT COUNT(*) FROM TCD.WasherFlushTime wft
														INNER JOIN @udttWasherFlushTime uwft
																	ON wft.WasherId = uwft.WasherId
																		AND wft.PlantId = (SELECT P.PlantId FROM TCD.Plant P WHERE P.EcolabAccountNumber = @EcolabAccountNumber)
																		AND wft.LineNumber = uwft.LineNumber
																		AND wft.WasherFlushTypeId = uwft.WasherFlushTypeId )

	IF @IsExistingRecord = 0
		BEGIN
			INSERT INTO TCD.WasherFlushTime
			(
				WasherId,
				PlantId,
				LineNumber,
				WasherFlushTypeId,
				FlushTime,
				LastModifiedByUserId,
				LastModifiedTime
			)
			SELECT uwft.WasherId,
					@PlantId,
					uwft.LineNumber,
					uwft.WasherFlushTypeId,
					uwft.FlushTime,
					@UserId,
					@CurrentUTC
			FROM @udttWasherFlushTime uwft 
			LEFT JOIN  TCD.WasherFlushTime as wft ON wft.WasherId = uwft.washerId AND wft.LineNumber = uwft.LineNumber AND wft.WasherFlushTypeId = uwft.WasherFlushTypeId AND wft.PlantId = @PlantId
			WHERE wft.washerId IS NULL 
		END

	ELSE
		BEGIN
			UPDATE wft
			SET
				wft.FlushTime = uwft.FlushTime, -- int
				wft.LastModifiedByUserId = @UserId,
				wft.LastModifiedTime = @CurrentUTC
			FROM @udttWasherFlushTime  uwft
			INNER JOIN TCD.WasherFlushTime wft
			ON wft.WasherId = uwft.WasherId
			AND wft.PlantId = @PlantId
			AND wft.LineNumber = uwft.LineNumber
			AND wft.WasherFlushTypeId = uwft.WasherFlushTypeId
			
		END	
			
END





GO
IF OBJECT_ID('[TCD].[WasherFlushTimeTrigger]') is not null
BEGIN
	DROP trigger [TCD].[WasherFlushTimeTrigger]
	
END

GO
/*                                           
###################################################################################################                                           

Trigger		:		WasherFlushTimeTrigger

Purpose		:		Trigger	for auditing changes on WasherFlushTime table

Parameter	:		NA

###################################################################################################                                           
*/
CREATE TRIGGER [TCD].[WasherFlushTimeTrigger]
	ON [TCD].[WasherFlushTime]
	AFTER UPDATE, INSERT
	AS
	BEGIN
		SET NOCOUNT ON
		DECLARE	@AuditOperation_SQLInsertId			TINYINT				=			NULL
	,	@AuditOperation_SQLUpdateId			TINYINT				=			NULL
	,	@AuditOperation_AppDeleteId			TINYINT				=			NULL
	,	@ErrorNumber						INT					=			0
	,	@ErrorMessage						NVARCHAR(2048)		=			NULL
	,	@ErrorSeverity						INT					=			NULL
	,	@ErrorProcedure						SYSNAME				=			NULL
	,	@MessageString						NVARCHAR(2500)		=			NULL
	,	@SoftDeleteFlag						BIT					=			NULL			--0 for FALSE/1 for TRUE
	,	@CurrentTimeStamp					DATETIME			=			GETUTCDATE()	--CURRENT_TIMESTAMP


SELECT	@AuditOperation_SQLInsertId			=			AO.OperationId
FROM	[TCD].AuditOperation					AO
WHERE	AO.OperationCode					=			'SQLInsert'

SELECT	@AuditOperation_SQLUpdateId			=			AO.OperationId
FROM	[TCD].AuditOperation					AO
WHERE	AO.OperationCode					=			'SQLUpdate'



IF	NOT	EXISTS	(SELECT	*	FROM	[deleted])
	BEGIN

			BEGIN	TRY
					SET NOCOUNT ON;

					INSERT	[TCD].WasherFlushTimeHistory(
							WasherId,				OperationTimestamp,			OperationId,			OperationByUserId,		PlantId,
							LineNumber,				WasherFlushTypeId,			FlushTime,				Is_Deleted,				LastModifiedByUserId,
							LastModifiedTime,		LastSyncTime )

					SELECT	WasherId,			@CurrentTimeStamp,		@AuditOperation_SQLInsertId,		LastModifiedByUserId,		PlantId,
							LineNumber,			WasherFlushTypeId,		FlushTime,							Is_Deleted,					LastModifiedByUserId,
							LastModifiedTime,	LastSyncTime

					FROM	[inserted] 
					END	TRY
			BEGIN	CATCH

					SELECT	@ErrorNumber				=			ERROR_NUMBER()
						,	@ErrorMessage				=			ERROR_MESSAGE()
						,	@ErrorProcedure				=			ERROR_PROCEDURE()
						,	@ErrorSeverity				=			ERROR_SEVERITY()

					--GOTO	ErrorHandler
					SET		@MessageString				=	N'An error occured while updating Audit data for WasherFlushTime table. The error is: '
														+	@ErrorMessage + '	'
														+	'Module: ' + @ErrorProcedure
					RAISERROR(@MessageString, @ErrorSeverity, 1)
					RETURN

			END	CATCH
	END

ELSE IF	EXISTS	(SELECT	*	FROM	[inserted])

	BEGIN
			
			BEGIN
					BEGIN	TRY

							SET NOCOUNT ON;

							IF UPDATE(FlushTime)
							BEGIN
							INSERT	[TCD].WasherFlushTimeHistory(
							WasherId,				OperationTimestamp,		OperationId,			OperationByUserId,		PlantId,				LineNumber,
							WasherFlushTypeId,		FlushTime,				Is_Deleted,				LastModifiedByUserId,	LastModifiedTime,		LastSyncTime )

					SELECT	ins.WasherId,			@CurrentTimeStamp,		@AuditOperation_SQLUpdateId,		ins.LastModifiedByUserId,		ins.PlantId,
							ins.LineNumber,			ins.WasherFlushTypeId,		ins.FlushTime,							ins.Is_Deleted,					ins.LastModifiedByUserId,
							ins.LastModifiedTime,	ins.LastSyncTime

							FROM	[inserted] ins 
							END

					END	TRY
					BEGIN	CATCH

							SELECT	@ErrorNumber				=			ERROR_NUMBER()
								,	@ErrorMessage				=			ERROR_MESSAGE()
								,	@ErrorProcedure				=			ERROR_PROCEDURE()
								,	@ErrorSeverity				=			ERROR_SEVERITY()

							--GOTO	ErrorHandler
							SET		@MessageString				=	N'An error occured while updating Audit data for WasherFlushTime table. The error is: '
																+	@ErrorMessage + '	'
																+	'Module: ' + @ErrorProcedure
							RAISERROR(@MessageString, @ErrorSeverity, 1)
							RETURN

					END	CATCH
			END
	END


IF	@ErrorNumber	=	0
	--GOTO	ExitModule
	RETURN
		


ErrorHandler:

SET		@MessageString						=	N'An error occured while updating Audit data for WasherFlushTime table. The error is: '
											+	@ErrorMessage + '	'
											+	'Module: ' + @ErrorProcedure
RAISERROR(@MessageString, @ErrorSeverity, 1)



ExitModule:

SET	NOCOUNT	OFF

RETURN


END


GO
IF OBJECT_ID('[TCD].[GetUsedChemicalName]') is not null
BEGIN
	DROP proc [TCD].[GetUsedChemicalName]
	
END

GO

CREATE PROCEDURE [TCD].[GetUsedChemicalName]
    @ChemName Varchar(1000)
    ,@EcolabAccountNumber nvarchar(25)
    ,@WasherGroupId    INT = NULL
AS     

BEGIN     
    SET NOCOUNT ON    
    
    DECLARE @RegionId            INT =    NULL
        ,    @ControllerId        INT    =    NULL
        ,    @ControllerModelId    INT    =    NULL
        ,    @ControllerTypeId    INT    =    NULL
    
    SELECT 
    @RegionId = RegionID FROM Plant 
    WHERE 
    EcolabAccountNumber = @EcolabAccountNumber

    SELECT @ControllerId =  wg.ControllerId FROM TCD.WasherGroup wg WHERE wg.WasherGroupId = @WasherGroupId AND wg.EcolabAccountNumber = @EcolabAccountNumber

    IF @ControllerId IS NULL
    BEGIN
    IF @WasherGroupId IS NULL
    BEGIN
        SELECT 
        Map.ProductId, RTRIM(Name) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name
        , M.Cost
        , M.IncludeinCI
        , TCD.FnChemicalCostInOunce(Map.ProductId) AS        Price
	   , 0
        FROM ProductMaster M
        INNER JOIN ProductdataMapping Map ON M.ProductId = Map.ProductId AND Map.Is_Deleted=0
        WHERE 
        (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
        AND M.RegionId = @RegionId
        AND M.Is_Deleted =0
    END
    ELSE
    BEGIN
        SELECT DISTINCT
        Map.ProductId, RTRIM(Name) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name
        , M.Cost
        , M.IncludeinCI
        , TCD.FnChemicalCostInOunce(Map.ProductId) AS        Price
	   , 0
        FROM TCD.ProductMaster M
        INNER JOIN TCD.ProductdataMapping Map ON M.ProductId = Map.ProductId AND Map.Is_Deleted=0
        LEFT JOIN TCD.ControllerEquipmentSetup ces ON ces.ProductId = Map.ProductId AND ces.EcoLabAccountNumber = Map.EcolabAccountNumber
        INNER JOIN TCD.MachineSetup ms ON ms.ControllerId = ces.ControllerId AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber AND ms.IsDeleted = 'False'
        INNER JOIN TCD.WasherGroup wg ON wg.WasherGroupId = ms.GroupId AND wg.EcolabAccountNumber = ms.EcoalabAccountNumber
        WHERE wg.WasherGroupId = ISNULL(@WasherGroupId, wg.WasherGroupId)
        AND (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
        AND M.RegionId = @RegionId
        AND M.Is_Deleted =0
        END
     END
    ELSE
    BEGIN
        SELECT @ControllerModelId = cc.ControllerModelId, @ControllerTypeId = cc.ControllerTypeId FROM TCD.ConduitController cc WHERE cc.ControllerId = @ControllerId

        IF @ControllerModelId = 11
        BEGIN
            SELECT DISTINCT
            Map.ProductId, RTRIM(CASE  
                        WHEN EnvisionDisplayName IS NULL THEN NAME 
                        ELSE EnvisionDisplayName 
                        END ) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name
            , M.Cost
            , M.IncludeinCI
            , CAST (ces.ControllerEquipmentTypeId AS int) AS ControllerEquipmentTypeId
            FROM ProductMaster M
            INNER JOIN ProductdataMapping Map ON M.ProductId = Map.ProductId AND Map.Is_Deleted=0  
            INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.EcoLabAccountNumber = Map.EcolabAccountNumber AND ces.ProductId = Map.ProductID
            LEFT JOIN TCD.TunnelCompartmentEquipmentValveMapping tcevm ON ces.ControllerEquipmentSetupID = tcevm.ControllerEquipmentSetupID AND tcevm.DirectDosingFlag = 1
            WHERE 
            (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
            AND tcevm.ControllerEquipmentSetupID IS NULL
            AND M.RegionId = @RegionId
            AND M.Is_Deleted =0
            AND ces.ControllerId = @ControllerId
            AND ces.WasherGroupNumber =  CASE WHEN @ControllerTypeId = 13 THEN 1 ELSE ces.WasherGroupNumber END
    END
        ELSE
        BEGIN
            SELECT DISTINCT
            Map.ProductId, RTRIM(CASE  
                        WHEN EnvisionDisplayName IS NULL THEN NAME 
                        ELSE EnvisionDisplayName 
                        END ) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name
    , M.Cost
    , M.IncludeinCI
    , TCD.FnChemicalCostInOunce(Map.ProductId) AS        Price
            , CAST (ces.ControllerEquipmentTypeId AS int) AS ControllerEquipmentTypeId
    FROM ProductMaster M
    INNER JOIN ProductdataMapping Map ON M.ProductId = Map.ProductId AND Map.Is_Deleted=0     
            INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.EcoLabAccountNumber = Map.EcolabAccountNumber AND ces.ProductId = Map.ProductID
            LEFT JOIN TCD.TunnelCompartmentEquipmentValveMapping tcevm ON ces.ControllerEquipmentSetupID = tcevm.ControllerEquipmentSetupID AND tcevm.DirectDosingFlag = 1
    WHERE 
    (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
            AND tcevm.ControllerEquipmentSetupID IS NULL
    AND M.RegionId = @RegionId
    AND M.Is_Deleted =0
            AND ces.ControllerId = @ControllerId
        END
    END
        

    SET NOCOUNT OFF 
 
END
