DECLARE @ControllerModelControllerTypeMappingId INT
DECLARE @id TinyINT


DECLARE UpdateWasherModeNumber CURSOR FOR
	 SELECT DISTINCT ControllerModelControllerTypeMappingId FROM TCD.WasherModeMapping

OPEN UpdateWasherModeNumber

FETCH NEXT FROM UpdateWasherModeNumber INTO @ControllerModelControllerTypeMappingId
	WHILE @@FETCH_STATUS = 0
BEGIN    
	SET @id = 0 
	UPDATE TCD.WasherModeMapping SET @id = WasherModeNumber = @id + 1 WHERE ControllerModelControllerTypeMappingId = @ControllerModelControllerTypeMappingId
	FETCH NEXT FROM UpdateWasherModeNumber INTO @ControllerModelControllerTypeMappingId 
END

CLOSE UpdateWasherModeNumber 
DEALLOCATE UpdateWasherModeNumber
Go

IF NOT EXISTS (SELECT 1 FROM TCD.WasherFlushType where WasherFlushTypeId IN (3,4))
BEGIN
INSERT INTO TCD.WasherFlushType
(
    TCD.WasherFlushType.WasherFlushTypeId,
    TCD.WasherFlushType.WasherFlushType
)
VALUES
(
    3, -- WasherFlushTypeId - int
    N'Water(Valve)' -- WasherFlushType - nvarchar
)

INSERT INTO TCD.WasherFlushType
(
    TCD.WasherFlushType.WasherFlushTypeId,
    TCD.WasherFlushType.WasherFlushType
)
VALUES
(
    4, -- WasherFlushTypeId - int
    N'Water(ME)' -- WasherFlushType - nvarchar
)
END
GO


IF EXISTS (SELECT 1 FROM tcd.controllertype where name='5 Washers 1 Tunnel')
BEGIN
Update tcd.controllertype set name='1 Tunnel 5 Washers' where name='5 Washers 1 Tunnel';
END
GO

IF NOT EXISTS(SELECT 1 FROM TCD.ResourceKeyMaster where [Key] = 'FILED_DOSINGLINEFLUSHTIMES')
BEGIN
INSERT INTO TCD.ResourceKeyMaster
(
    ResourceId ,
    TCD.ResourceKeyMaster.[Key]
)
VALUES
(
   2803,
    N'FILED_DOSINGLINEFLUSHTIMES'
)
INSERT INTO TCD.ResourceKeyValue
(
    Id,
    TCD.ResourceKeyValue.ResourceId,
    TCD.ResourceKeyValue.[Value],
    TCD.ResourceKeyValue.Locale,
    TCD.ResourceKeyValue.LanguageID,
    TCD.ResourceKeyValue.LastModifiedTime
)
VALUES
(
    21739,
    2803, -- ResourceId - int
    N'Dosing Line Flush Times', -- Value - nvarchar
    N'en-US', -- Locale - nvarchar
    1, -- LanguageID - int
    '2015-09-11 12:28:15' -- LastModifiedTime - datetime
)
END
GO

IF NOT EXISTS(SELECT 1 FROM TCD.ResourceKeyMaster where [Key] = 'FILED_PUMPS')
BEGIN
INSERT INTO TCD.ResourceKeyMaster
(
    ResourceId ,
    TCD.ResourceKeyMaster.[Key]
)
VALUES
(
   2804,
    N'FILED_PUMPS'
)
INSERT INTO TCD.ResourceKeyValue
(
   Id,
    TCD.ResourceKeyValue.ResourceId,
    TCD.ResourceKeyValue.[Value],
    TCD.ResourceKeyValue.Locale,
    TCD.ResourceKeyValue.LanguageID,
    TCD.ResourceKeyValue.LastModifiedTime
)
VALUES
(
    21740,
    2804, -- ResourceId - int
    N'Pumps', -- Value - nvarchar
    N'en-US', -- Locale - nvarchar
    1, -- LanguageID - int
    '2015-09-11 12:28:15' -- LastModifiedTime - datetime
)
END
GO

IF NOT EXISTS(SELECT 1 FROM TCD.ResourceKeyMaster where [Key] = 'FIELD_WATER')
BEGIN
INSERT INTO TCD.ResourceKeyMaster
(
    ResourceId ,
    TCD.ResourceKeyMaster.[Key]
)
VALUES
(
   2805,
    N'FIELD_WATER'
)
INSERT INTO TCD.ResourceKeyValue
(
    Id,
    TCD.ResourceKeyValue.ResourceId,
    TCD.ResourceKeyValue.[Value],
    TCD.ResourceKeyValue.Locale,
    TCD.ResourceKeyValue.LanguageID,
    TCD.ResourceKeyValue.LastModifiedTime
)
VALUES
(
    21741,
    2805, -- ResourceId - int
    N'Water', -- Value - nvarchar
    N'en-US', -- Locale - nvarchar
    1, -- LanguageID - int
    '2015-09-11 12:28:15' -- LastModifiedTime - datetime
)
END
GO

IF NOT EXISTS(SELECT 1 FROM TCD.ResourceKeyMaster where [Key] = 'FIELD_FLUSHTIMEVALVE')
BEGIN
INSERT INTO TCD.ResourceKeyMaster
(
    ResourceId ,
    TCD.ResourceKeyMaster.[Key]
)
VALUES
(
   2806,
    N'FIELD_FLUSHTIMEVALVE'
)
INSERT INTO TCD.ResourceKeyValue
(
   Id,
    TCD.ResourceKeyValue.ResourceId,
    TCD.ResourceKeyValue.[Value],
    TCD.ResourceKeyValue.Locale,
    TCD.ResourceKeyValue.LanguageID,
    TCD.ResourceKeyValue.LastModifiedTime
)
VALUES
(
    21742,
    2806, -- ResourceId - int
    N'Flush Time Valve', -- Value - nvarchar
    N'en-US', -- Locale - nvarchar
    1, -- LanguageID - int
    '2015-09-11 12:28:15' -- LastModifiedTime - datetime
)
END
GO

IF NOT EXISTS(SELECT 1 FROM TCD.ResourceKeyMaster where [Key] = 'FILED_MAINEQUIPMENT')
BEGIN
INSERT INTO TCD.ResourceKeyMaster
(
    ResourceId ,
    TCD.ResourceKeyMaster.[Key]
)
VALUES
(
   2808,
    N'FILED_MAINEQUIPMENT'
)
INSERT INTO TCD.ResourceKeyValue
(
    Id,
    TCD.ResourceKeyValue.ResourceId,
    TCD.ResourceKeyValue.[Value],
    TCD.ResourceKeyValue.Locale,
    TCD.ResourceKeyValue.LanguageID,
    TCD.ResourceKeyValue.LastModifiedTime
)
VALUES
(
    21743,
    2808, -- ResourceId - int
    N'Main Euipment', -- Value - nvarchar
    N'en-US', -- Locale - nvarchar
    1, -- LanguageID - int
    '2015-09-11 12:28:15' -- LastModifiedTime - datetime
)
END
GO

IF NOT EXISTS(SELECT 1 FROM TCD.ResourceKeyMaster where [Key] = 'FIELD_AIR')
BEGIN
INSERT INTO TCD.ResourceKeyMaster
(
    ResourceId ,
    TCD.ResourceKeyMaster.[Key]
)
VALUES
(
   2809,
    N'FIELD_AIR'
)
INSERT INTO TCD.ResourceKeyValue
(
    Id,
    TCD.ResourceKeyValue.ResourceId,
    TCD.ResourceKeyValue.[Value],
    TCD.ResourceKeyValue.Locale,
    TCD.ResourceKeyValue.LanguageID,
    TCD.ResourceKeyValue.LastModifiedTime
)
VALUES
(
    21744,
    2809, -- ResourceId - int
    N'Air', -- Value - nvarchar
    N'en-US', -- Locale - nvarchar
    1, -- LanguageID - int
    '2015-09-11 12:28:15' -- LastModifiedTime - datetime
)
END
GO

IF NOT EXISTS(SELECT 1 FROM TCD.ResourceKeyMaster where [Key] = 'FIELD_FLUSHTIMELINE')
BEGIN
INSERT INTO TCD.ResourceKeyMaster
(
    ResourceId ,
    TCD.ResourceKeyMaster.[Key]
)
VALUES
(
   2810,
    N'FIELD_FLUSHTIMELINE'
)
INSERT INTO TCD.ResourceKeyValue
(
    Id,
    TCD.ResourceKeyValue.ResourceId,
    TCD.ResourceKeyValue.[Value],
    TCD.ResourceKeyValue.Locale,
    TCD.ResourceKeyValue.LanguageID,
    TCD.ResourceKeyValue.LastModifiedTime
)
VALUES
(
    21745,
    2810, -- ResourceId - int
    N'Flush Time Line', -- Value - nvarchar
    N'en-US', -- Locale - nvarchar
    1, -- LanguageID - int
    '2015-09-11 12:28:15' -- LastModifiedTime - datetime
)
END
GO

IF NOT EXISTS(SELECT 1 FROM TCD.ResourceKeyMaster where [Key] = 'FILED_TIMEOUTMACHINETOM')
BEGIN
INSERT INTO TCD.ResourceKeyMaster
(
    ResourceId ,
    TCD.ResourceKeyMaster.[Key]
)
VALUES
(
   2811,
    N'FILED_TIMEOUTMACHINETOM'
)
INSERT INTO TCD.ResourceKeyValue
(
    Id,
    TCD.ResourceKeyValue.ResourceId,
    TCD.ResourceKeyValue.[Value],
    TCD.ResourceKeyValue.Locale,
    TCD.ResourceKeyValue.LanguageID,
    TCD.ResourceKeyValue.LastModifiedTime
)
VALUES
(
    21746,
    2811, -- ResourceId - int
    N'Time Out Machine', -- Value - nvarchar
    N'en-US', -- Locale - nvarchar
    1, -- LanguageID - int
    '2015-09-11 12:28:15' -- LastModifiedTime - datetime
)
END
GO

IF NOT EXISTS(SELECT 1 FROM TCD.ResourceKeyMaster where [Key] = 'FIELD_EQUIPMENT')
BEGIN
INSERT INTO TCD.ResourceKeyMaster
(
    ResourceId ,
    TCD.ResourceKeyMaster.[Key]
)
VALUES
(
   2812,
    N'FIELD_EQUIPMENT'
)
INSERT INTO TCD.ResourceKeyValue
(
   Id,
    TCD.ResourceKeyValue.ResourceId,
    TCD.ResourceKeyValue.[Value],
    TCD.ResourceKeyValue.Locale,
    TCD.ResourceKeyValue.LanguageID,
    TCD.ResourceKeyValue.LastModifiedTime
)
VALUES
(
    21747,
    2812, -- ResourceId - int
    N'Equipmnet', -- Value - nvarchar
    N'en-US', -- Locale - nvarchar
    1, -- LanguageID - int
    '2015-09-11 12:28:15' -- LastModifiedTime - datetime
)
END
GO

IF NOT EXISTS(SELECT 1 FROM TCD.ResourceKeyMaster where [Key] = 'FIELD_DOSINGPOINT')
BEGIN
INSERT INTO TCD.ResourceKeyMaster
(
    ResourceId ,
    TCD.ResourceKeyMaster.[Key]
)
VALUES
(
   2813,
    N'FIELD_DOSINGPOINT'
)
INSERT INTO TCD.ResourceKeyValue
(
    Id,
    TCD.ResourceKeyValue.ResourceId,
    TCD.ResourceKeyValue.[Value],
    TCD.ResourceKeyValue.Locale,
    TCD.ResourceKeyValue.LanguageID,
    TCD.ResourceKeyValue.LastModifiedTime
)
VALUES
(
    21748,
    2813, -- ResourceId - int
    N'Dosing Point', -- Value - nvarchar
    N'en-US', -- Locale - nvarchar
    1, -- LanguageID - int
    '2015-09-11 12:28:15' -- LastModifiedTime - datetime
)
END
GO

IF NOT EXISTS(SELECT 1 FROM TCD.ResourceKeyMaster where [Key] = 'FIELD_TOMSIGNAL')
BEGIN
INSERT INTO TCD.ResourceKeyMaster
(
    ResourceId ,
    TCD.ResourceKeyMaster.[Key]
)
VALUES
(
   2814,
    N'FIELD_TOMSIGNAL'
)
INSERT INTO TCD.ResourceKeyValue
(
    Id,
    TCD.ResourceKeyValue.ResourceId,
    TCD.ResourceKeyValue.[Value],
    TCD.ResourceKeyValue.Locale,
    TCD.ResourceKeyValue.LanguageID,
    TCD.ResourceKeyValue.LastModifiedTime
)
VALUES
(
    21749,
    2814, -- ResourceId - int
    N'TOM Signal', -- Value - nvarchar
    N'en-US', -- Locale - nvarchar
    1, -- LanguageID - int
    '2015-09-11 12:28:15' -- LastModifiedTime - datetime
)
END
GO

IF NOT EXISTS(SELECT 1 FROM TCD.ResourceKeyMaster where [Key] = 'FIELD_FLUSHTIMESSAVEDSUCCESSFULLY')
BEGIN
INSERT INTO TCD.ResourceKeyMaster
(
    ResourceId ,
    TCD.ResourceKeyMaster.[Key]
)
VALUES
(
   2815,
    N'FIELD_FLUSHTIMESSAVEDSUCCESSFULLY'
)
INSERT INTO TCD.ResourceKeyValue
(
    Id,
    TCD.ResourceKeyValue.ResourceId,
    TCD.ResourceKeyValue.[Value],
    TCD.ResourceKeyValue.Locale,
    TCD.ResourceKeyValue.LanguageID,
    TCD.ResourceKeyValue.LastModifiedTime
)
VALUES
(
    21750,
    2815, -- ResourceId - int
    N'Flush Times data saved successfully.', -- Value - nvarchar
    N'en-US', -- Locale - nvarchar
    1, -- LanguageID - int
    '2015-09-11 12:28:15' -- LastModifiedTime - datetime
)
END
GO

IF NOT EXISTS(SELECT 1 FROM TCD.ResourceKeyMaster where [Key] = 'FIELD_FLUSHTIMESANDSETUPTIMEOUTMACHINEDATASAVEDSUCCESSFULLY')
BEGIN
INSERT INTO TCD.ResourceKeyMaster
(
    ResourceId ,
    TCD.ResourceKeyMaster.[Key]
)
VALUES
(
   2816,
    N'FIELD_FLUSHTIMESANDSETUPTIMEOUTMACHINEDATASAVEDSUCCESSFULLY'
)
INSERT INTO TCD.ResourceKeyValue
(
    Id,
    TCD.ResourceKeyValue.ResourceId,
    TCD.ResourceKeyValue.[Value],
    TCD.ResourceKeyValue.Locale,
    TCD.ResourceKeyValue.LanguageID,
    TCD.ResourceKeyValue.LastModifiedTime
)
VALUES
(
    21751,
    2816, -- ResourceId - int
    N'Flush Times and Setup Time out Machine data saved successfully.', -- Value - nvarchar
    N'en-US', -- Locale - nvarchar
    1, -- LanguageID - int
    '2015-09-11 12:28:15' -- LastModifiedTime - datetime
)
END
GO

IF NOT EXISTS(SELECT 1 FROM TCD.[Page] WHERE PageName = 'Flush Time and TOM Setup')
BEGIN
INSERT INTO TCD.[Page]
(
    TCD.[Page].PageId,
    TCD.[Page].PageName,
    TCD.[Page].PageDescription
)
VALUES
(
    46, 
    N'Flush Time and TOM Setup', 
    N'Washer flush Time and Washer time out machine' 
)
END
GO

DECLARE	@tempResourceKeyPageMapping			TABLE	(
	TempId					INT					IDENTITY(1, 1)
	,	Id					INT					NOT NULL
	,	ResourceId			int					NOT NULL
	,	PageId				int					NOT NULL
	)

	INSERT	@tempResourceKeyPageMapping	(Id, ResourceId	,PageId	) VALUES
		(864, 2804, 46)
	,	(865, 2805, 46)
	,	(866, 2806, 46)
	,	(867, 2808, 46)
	,	(868, 2809, 46)
	,	(869, 2810, 46)
	,	(870, 2811, 46)
	,	(871, 2812, 46)
	,	(872, 2813, 46)
	,	(873, 2814, 46)
	,	(874, 2815, 46)
	,	(874, 2816, 46)


	 MERGE	TCD.ResourceKeyPageMapping			AS			TARGET
	USING	@tempResourceKeyPageMapping		AS			SOURCE
	ON	TARGET.Id		=			SOURCE.Id
	WHEN	NOT MATCHED		THEN
	INSERT	(Id , ResourceId, PageId)
	VALUES	(SOURCE.Id,SOURCE.ResourceId	,SOURCE.PageId	);

	
	
	--Declare temp table variable to hold input data
	DECLARE	@tempResourceKeyMaster	TABLE	(
	TempId					INT				IDENTITY(1, 1)
,	ResourceId				INT				PRIMARY	KEY
,	[Key]					NVARCHAR(100)
)

--Populate temp table variable with the input data
	INSERT @tempResourceKeyMaster ([ResourceId], [Key]) VALUES 
		 (2817, N'FIELD_LINE1')
	,	 (2818, N'FIELD_DOSINGLINEMODE1')
	,	 (2819, N'FIELD_ENABLEAUXILIARYPUMP1') 	
	,	 (2820, N'FIELD_FLOW-METERFORFLOWCHECK1')
	,	 (2821, N'FIELD_NOOFPUMPSCONNECTEDTOTCR1')
	,	 (2822, N'FIELD_LINE2')
	,	 (2823, N'FIELD_DOSINGLINEMODE2')
	,	 (2824, N'FIELD_ENABLEAUXILIARYPUMP2')
	,	 (2825, N'FIELD_FLOW-METERFORFLOWCHECK2')
	,	 (2826, N'FIELD_NOOFPUMPSCONNECTEDTOTCR2')
	,	 (2827, N'FIELD_LINE3')
	,	 (2828, N'FIELD_DOSINGLINEMODE3')
	,	 (2829, N'FIELD_ENABLEAUXILIARYPUMP3') 	
	,	 (2830, N'FIELD_FLOW-METERFORFLOWCHECK3')
	,	 (2831, N'FIELD_NOOFPUMPSCONNECTEDTOTCR3')

	,	 (2832, N'FIELD_CONTROLLERNUMBER')
	,	 (2833, N'FIELD_CONTROLLERVERSION')
	,	 (2834, N'FIELD_IPADDRESS')

	,	 (2835, N'FIELD_COMPORTNUMBER')

	,	 (2836, N'FIELD_ENABLECONNEXX')
	,	 (2837, N'FIELD_CONNEXXALARMDELAY')
	,	 (2838, N'FIELD_HYSTERESISONCONNEXXALARMLEVEL')

	,	 (2839, N'FIELD_ENVISIONENABLE')  	
	,	 (2840, N'FIELD_CHECKWATERFLOW')
	,	 (2841, N'FIELD_ENVISIONTIMEOUTENABLE')
	,	 (2842, N'FIELD_CHECKFLOWLEAKAGEALARM')
	,	 (2843, N'FIELD_ENVISIONTIMEOUTALARM')
	,	 (2844, N'FIELD_ENABLERESETBUTTON')
	,	 (2845, N'FIELD_DISABLEPROGRAMNOTFINISHEDALARM')
	,	 (2846, N'FIELD_ALARMRESETTIME')
	,	 (2847, N'FIELD_STOPTIMEDUBIX')
	,	 (2848, N'FIELD_SEPARATEAIRPRESSUREANDEMERGENCYSTOPALARM')
	,	 (2849, N'FIELD_INTERMEDIARYRINSETIME')  	
	,	 (2850, N'FIELD_INVERTMACHINESTOP')
	,	 (2851, N'FIELD_FILTERTOGENERATEALARMONANALOGUEVALUES')
	,	 (2852, N'FIELD_ALARMDEEPTRAYENABLED')

	,	 (2853, N'FIELD_L1')
	,	 (2854, N'FIELD_L2')
	,	 (2855, N'FIELD_L3')
	,	 (2856, N'FIELD_L4')
	,	 (2857, N'FIELD_L5')
	,	 (2858, N'FIELD_L6')
	,	 (2859, N'FIELD_L7')  	
	,	 (2860, N'FIELD_L8')
	,	 (2861, N'FIELD_L9')
	,	 (2862, N'FIELD_L10')
	,	 (2863, N'FIELD_L11')
	,	 (2864, N'FIELD_L12')
	,	 (2865, N'FIELD_L13')
	,	 (2866, N'FIELD_L14')
	,	 (2867, N'FIELD_L15')
	,	 (2868, N'FIELD_L16')

	,	 (2869, N'FIELD_PMRENABLED') 
	,	 (2870, N'FIELD_CHECKWATERFLOWGROUP1') 
	,	 (2871, N'FIELD_CHECKWATERFLOWGROUP2')
	,	 (2872, N'FIELD_CHECKFLOWLEAKAGEALARMGROUP1') 
	,	 (2873, N'FIELD_CHECKFLOWLEAKAGEALARMGROUP2') 
	,	 (2874, N'FIELD_DISABLEPROGRAMNOTFINISHEDALARM') 
	,	 (2875, N'FIELD_STARTDONOTGENERATEFIRSTSTEP') 
	,	 (2876, N'FIELD_CONDUCTIVITYCOMPENSATIONSTOCKSOLUTIONTANK1') 
	,	 (2877, N'FIELD_CONDUCTIVITYCOMPENSATIONSTOCKSOLUTIONTANK2') 
	,	 (2878, N'FIELD_INTERNALTAKE-OVERMAINEQUIPMENTNO.1') 
	,	 (2879, N'FIELD_INTERNALTAKE-OVERMAINEQUIPMENTNO.2') 
	,	 (2880, N'FIELD_SWITCHOVERFROMSTOCKSOLUTIONTANK1') 
	,	 (2881, N'FIELD_SWITCHOVERFROMSTOCKSOLUTIONTANK2') 
	,	 (2882, N'FIELD_GROUPNUMBERUSEDFOREXTERNALTAKEOVERME1') 
	,	 (2883, N'FIELD_GROUPNUMBERUSEDFOREXTERNALTAKEOVERME2') 
	,	 (2884, N'FIELD_EXTERNALEXTRAFLUSHTIMEME1') 
	,	 (2885, N'FIELD_EXTERNALEXTRAFLUSHTIMEME2') 

	,	 (2886, N'FIELD_DIGITALINPUTCARD1(SIGNALMACHINES)POSITION0RACK1') 
	,	 (2887, N'FIELD_DIGITALINPUTCARD6(ME2+P10,11,12)POSITION0RACK2') 
	,	 (2888, N'FIELD_DigitalInputCard2(SignalMachines)Position1Rack1') 
	,	 (2889, N'FIELD_ANALOGUEINPUTCARD1POSITION5RACK1') 
	,	 (2890, N'FIELD_DIGITALINPUTCARD3(DOSINGGROUP1)POSITION2RACK1') 
	,	 (2891, N'FIELD_ANALOGUEINPUTCARD2POSITION6RACK1')
	,	 (2892, N'FIELD_DIGITALINPUTCARD4(DOSINGGROUP2)POSITION3RACK1')
	,	 (2893, N'FIELD_ANALOGUEINPUTCARD3POSITION1RACK3')
	,	 (2894, N'FIELD_DIGITALINPUTCARD5(MINITERMINAL)POSITION4RACK1')

	,	 (2895, N'FIELD_ANALOGMONITORINGENABLE')
	,	 (2896, N'FIELD_ALARMREVERSE')

	,	 (2897, N'FIELD_SKIPEXTENSIONI/OMODULE1')

	,	 (2898, N'FIELD_FX2NCOM-ET-10USED')
	,	 (2899, N'FIELD_DISABLEPROGRAMNOTFINISHEDALARM')
	,	 (2900, N'FIELD_Disablenotvalidprogramalarm')

	--SET	IDENTITY_INSERT	TCD.ResourceKeyMaster	ON

	MERGE	TCD.ResourceKeyMaster			AS TARGET
	USING	@tempResourceKeyMaster		AS SOURCE
	ON	TARGET.ResourceId		=			SOURCE.ResourceId
	WHEN	NOT MATCHED		THEN
	INSERT	(ResourceId			,[Key]			)
	VALUES	(SOURCE.ResourceId	,SOURCE.[Key]	);

-- SET	IDENTITY_INSERT	TCD.ResourceKeyMaster	OFF
;

	DECLARE	@tempResourceKeyValue	TABLE	(
	TempId					INT				IDENTITY(1, 1)
	,	ResourceId				INT
	,	Value					NVARCHAR(400)	NOT	NULL
	,	Locale					NVARCHAR(50)	NOT	NULL
	,	languageID				INT
	)

	INSERT @tempResourceKeyValue ([ResourceId], [Value], [Locale], [languageID]) VALUES 
		(2817, N'Line1', N'en-US', 1)
	,	(2818, N'Dosing Line Mode1', N'en-US', 1)
	,	(2819, N'Enable Auxiliary pump1', N'en-US', 1)
	,	(2820, N'Flow-meter for Flow check1', N'en-US', 1)
	,	(2821, N'No of Pumps Connected to TCR1', N'en-US', 1)
	,	(2822, N'Line2', N'en-US', 1)
	,	(2823, N'Dosing Line Mode2', N'en-US', 1)
	,	(2824, N'Enable Auxiliary pump2', N'en-US', 1)
	,	(2825, N'Flow-meter for Flow check2', N'en-US', 1)
	,	(2826, N'No of Pumps Connected to TCR2', N'en-US', 1)
	,	(2827, N'Line3', N'en-US', 1)
	,	(2828, N'Dosing Line Mode3', N'en-US', 1)
	,	(2829, N'Enable Auxiliary pump3', N'en-US', 1)
	,	(2830, N'Flow-meter for Flow check3', N'en-US', 1)
	,	(2831, N'No of Pumps Connected to TCR3', N'en-US', 1)

	,	(2832, N'Dispenser Number', N'en-US', 1)
	,	(2833, N'Dispenser Version', N'en-US', 1)
	,	(2834, N'IP Address', N'en-US', 1)

	,	(2835, N'Com Port Number', N'en-US', 1)

	,	(2836, N'Enable Connexx', N'en-US', 1)
	,	(2837, N'Connexx Alarm delay', N'en-US', 1)
	,	(2838, N'Hysteresis on Connexx alarm level', N'en-US', 1)

	,	(2839, N'enVision Enable', N'en-US', 1)
	,	(2840, N'Check Water flow', N'en-US', 1)
	,	(2841, N'enVision Time out Enable', N'en-US', 1)
	,	(2842, N'Check flow leakage alarm', N'en-US', 1)
	,	(2843, N'enVision Timeout Alarm', N'en-US', 1)
	,	(2844, N'Enable reset button', N'en-US', 1)
	,	(2845, N'Disable Program not finished alarm', N'en-US', 1)
	,	(2846, N'Alarm Reset Time', N'en-US', 1)
	,	(2847, N'Stop Time Dubix', N'en-US', 1)
	,	(2848, N'Separate Air Pressure and Emergency stop Alarm', N'en-US', 1)
	,	(2849, N'Intermediary Rinse Time', N'en-US', 1)
	,	(2850, N'Invert Machine Stop', N'en-US', 1)
	,	(2851, N'Filter to generate alarm on analogue values', N'en-US', 1)
	,	(2852, N'Alarm Deep tray enabled', N'en-US', 1)

	,	(2853, N'L1', N'en-US', 1)
	,	(2854, N'L2', N'en-US', 1)
	,	(2855, N'L3', N'en-US', 1)
	,	(2856, N'L4', N'en-US', 1)
	,	(2857, N'L5', N'en-US', 1)
	,	(2858, N'L6', N'en-US', 1)
	,	(2859, N'L7', N'en-US', 1)
	,	(2860, N'L8', N'en-US', 1)
	,	(2861, N'L9', N'en-US', 1)
	,	(2862, N'L10', N'en-US', 1)
	,	(2863, N'L11', N'en-US', 1)
	,	(2864, N'L12', N'en-US', 1)
	,	(2865, N'L13', N'en-US', 1)
	,	(2866, N'L14', N'en-US', 1)
	,	(2867, N'L15', N'en-US', 1)
	,	(2868, N'L16', N'en-US', 1)

	,	(2869, N'PMR Enabled', N'en-US', 1)
	,	(2870, N'Check Water flow Group1', N'en-US', 1)
	,	(2871, N'Check Water flow Group2', N'en-US', 1)
	,	(2872, N'Check flow leakage alarm Group1', N'en-US', 1)
	,	(2873, N'Check flow leakage alarm Group2', N'en-US', 1)
	,	(2874, N'Disable Program not finished Alarm', N'en-US', 1)
	,	(2875, N'Start do not generate First Step', N'en-US', 1)
	,	(2876, N'Conductivity Compensation Stock Solution Tank 1', N'en-US', 1)
	,	(2877, N'Conductivity Compensation Stock Solution Tank 2', N'en-US', 1)
	,	(2878, N'Internal Take-Over Main Equipment No.1', N'en-US', 1)
	,	(2879, N'Internal Take-Over Main Equipment No.2', N'en-US', 1)
	,	(2880, N'Switch Over from Stock Solution Tank 1', N'en-US', 1)
	,	(2881, N'Switch Over from Stock Solution Tank 2', N'en-US', 1)
	,	(2882, N'Group Number used for external take over ME 1', N'en-US', 1)
	,	(2883, N'Group Number used for external take over ME 2', N'en-US', 1)
	,	(2884, N'External extra flush time ME1', N'en-US', 1)
	,	(2885, N'External extra flush time ME1', N'en-US', 1)

	,	(2886, N'Digital Input Card 1 (Signal Machines) Position 0 Rack 1', N'en-US', 1)
	,	(2887, N'Digital Input Card 6 (ME2 + P 10,11,12) Position 0 Rack 2', N'en-US', 1)
	,	(2888, N'Digital Input Card 2 (Signal Machines) Position 1 Rack 1', N'en-US', 1)
	,	(2889, N'Analogue Input Card 1 Position 5 Rack 1', N'en-US', 1)
	,	(2890, N'Digital Input Card 3 (Dosing Group 1) Position 2 Rack 1', N'en-US', 1)
	,	(2891, N'Analogue Input Card 2 Position 6 Rack 1', N'en-US', 1)
	,	(2892, N'Digital Input Card 4 (Dosing Group 2) Position 3 Rack 1', N'en-US', 1)
	,	(2893, N'Analogue Input Card 3 Position 1 Rack 3', N'en-US', 1)
	,	(2894, N'Digital Input Card 5 (Miniterminal) Position 4 Rack 1', N'en-US', 1)

	,	(2895, N'Analog Monitoring Enable', N'en-US', 1)
	,	(2896, N'Alarm Reverse', N'en-US', 1)

	,	(2897, N'Skip extension I/O module 1', N'en-US', 1)

	,	(2898, N'FX2N COM-ET-10 Used', N'en-US', 1)
	,	(2899, N'Disable Program not finished alarm', N'en-US', 1)
	,	(2900, N'Disable not valid program alarm', N'en-US', 1)

	

	MERGE	TCD.ResourceKeyValue			AS TARGET
	USING	@tempResourceKeyValue		AS SOURCE
	ON	TARGET.ResourceId		=			SOURCE.ResourceId
	AND	TARGET.languageID		=			SOURCE.languageID
	WHEN	NOT MATCHED		THEN
	INSERT	(ResourceId			,Value			,Locale			,languageID)
	VALUES	(SOURCE.ResourceId	,SOURCE.Value	,SOURCE.Locale	,SOURCE.languageID	);
	GO

	DECLARE	@tempResourceKeyPageMapping			TABLE	(
	TempId					INT					IDENTITY(1, 1)
	,	Id					INT					NOT NULL
	,	ResourceId			int					NOT NULL
	,	PageId				int					NOT NULL
	)

	INSERT	@tempResourceKeyPageMapping	(Id, ResourceId	,PageId	) VALUES
		(875, 2817, 26)
	,	(876, 2818, 26)
	,	(877, 2819, 26)
	,	(878, 2820, 26)
	,	(879, 2821, 26)
	,	(880, 2822, 26)
	,	(881, 2823, 26)
	,	(882, 2824, 26)
	,	(883, 2825, 26)
	,	(884, 2826, 26)
	,	(885, 2827, 26)
	,	(886, 2828, 26)
	,	(887, 2829, 26)
	,	(888, 2830, 26)
	,	(889, 2831, 26)

	,	(890, 515, 26)
	,	(891, 167, 26)
	,	(892, 2832, 26)
	,	(893, 1004, 26)
	,	(894, 2833, 26)
	,	(895, 995, 26)
	,	(896, 2834, 26)

	,	(897, 2835, 26)
	
	,	(898, 2836, 27)
	,	(899, 2837, 27)
	,	(900 , 2838, 27)

	,	(901 , 2839, 27)
	,	(902 , 2840, 27)
	,	(903 , 2841, 27)
	,	(904 , 2842, 27)
	,	(905 , 2843, 27)
	,	(906 , 2844, 27)
	,	(907 , 2845, 27)
	,	(908 , 2846, 27)
	,	(909 , 2847, 27)
	,	(910 , 2848, 27)
	,	(911 , 2849, 27)
	,	(912 , 2850, 27)
	,	(913 , 2851, 27)
	,	(914 , 2852, 27)

	,	(915 , 2853, 27)
	,	(916 , 2854, 27)
	,	(917 , 2855, 27)
	,	(918 , 2856, 27)
	,	(919 , 2857, 27)
	,	(920 , 2858, 27)
	,	(921 , 2859, 27)
	,	(922 , 2860, 27)
	,	(923 , 2861, 27)
	,	(924 , 2862, 27)
	,	(925 , 2863, 27)
	,	(926 , 2864, 27)
	,	(927 , 2865, 27)
	,	(928 , 2866, 27)
	,	(929 , 2867, 27)
	,	(930 , 2868, 27)

	,	(931 , 2869, 27)
	,	(932 , 2870, 27)
	,	(933 , 2871, 27)
	,	(934 , 2872, 27)
	,	(935 , 2873, 27)
	,	(936 , 2874, 27)
	,	(937 , 2875, 27)
	,	(938 , 2876, 27)
	,	(939 , 2877, 27)
	,	(940 , 2878, 27)
	,	(941 , 2879, 27)
	,	(942 , 2880, 27)
	,	(943 , 2881, 27)
	,	(944 , 2882, 27)
	,	(945 , 2883, 27)
	,	(946 , 2884, 27)
	,	(947 , 2885, 27)

	,	(948 , 2886, 27)
	,	(949 , 2887, 27)
	,	(950 , 2888, 27)
	,	(951 , 2889, 27)
	,	(952 , 2890, 27)
	,	(953 , 2891, 27)
	,	(954 , 2892, 27)
	,	(955 , 2893, 27)
	,	(956 , 2894, 27)

	,	(957 , 2895, 27)
	,	(958 , 2896, 27)

	,	(959 , 2897, 27)

	,	(960 , 2898, 27)
	,	(961 , 2899, 27)
	,	(962 , 2900, 27)
	

	 MERGE	TCD.ResourceKeyPageMapping			AS			TARGET
	USING	@tempResourceKeyPageMapping		AS			SOURCE
	ON	TARGET.Id		=			SOURCE.Id
	WHEN	NOT MATCHED		THEN
	INSERT	(Id , ResourceId, PageId)
	VALUES	(SOURCE.Id,SOURCE.ResourceId	,SOURCE.PageId	);
GO

IF EXISTS(SELECT 1 FROM TCD.ControllerModelControllerTypeMapping cmctm WHERE cmctm.ControllerModelId IN (7,8,11))
BEGIN
-- MyControl id = 7
UPDATE TCD.ControllerModelControllerTypeMapping 
SET 
	NumOfTunnelDosingLines					=	16
,	NumOfConvDosingLines					=	12
,	MaxNumOfTOMEquipmentForTunnel			=	22
,	MaxNumOfTOMDosingPointForTunnel			=	22
,	MaxNumOfTOMEquipmentForConventional		=	12
,	MaxNumOfTOMDosingPointForConventional	=	0 
WHERE
	ControllerModelId						=	7

-- E-Control plus id=8
UPDATE TCD.ControllerModelControllerTypeMapping 
SET 
	MaxNumOfValvesForConventional			=	8
,	MaxNumOfValvesForTunnel					=	8
,	MaxNumOfMEForConventional				=	2
,	MaxNumOfMEForTunnel						=	2 
,	MaxNumOfTOMEquipmentForTunnel			=	22
,	MaxNumOfTOMDosingPointForTunnel			=	22
,	MaxNumOfTOMEquipmentForConventional		=	0
,	MaxNumOfTOMDosingPointForConventional	=	0 
WHERE
	ControllerModelId						=	8 

--plc xl id=11
UPDATE TCD.ControllerModelControllerTypeMapping 
SET 
	MaxNumOfValvesForConventional	=	1
,	MaxNumOfValvesForTunnel			=	5
,	MaxNumOfMEForConventional		=	2
,	MaxNumOfMEForTunnel				=	2
WHERE
	ControllerModelId				=	11
END
GO
