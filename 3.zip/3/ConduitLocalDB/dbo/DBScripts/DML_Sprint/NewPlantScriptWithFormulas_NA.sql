
UPDATE TCD.UserMaster SET EcolabAccountNumber = N'P03810003' 
  
SET IDENTITY_INSERT [TCD].[UserMaster] ON
Begin
INSERT [TCD].[UserMaster] ([UserId], [FirstName], [LastName], [FullName], [LoginName], [Password], [Phone], [LanguageId], [UOMId], [Email], [IsActive], [LastLoggedIn], [LastModifiedByUserId], [EcolabAccountNumber], [Title], [Mobile], [Fax], [ContactId], [CurrencyCode], [LastModifiedTime], [LastSyncTime]) 
VALUES
 (1, N'Adminstrator', N'User', N'Adminstrator User', N'Admin', N'baloce', N'123456789', 1, 1, N'Admin@ecolab.com', 1, CAST(0x0000A3AB00263AAB AS DateTime), 0, N'P03810003', NULL, NULL, NULL, NULL, NULL, CAST(0x0000A50100A5390D AS DateTime), NULL);
End
SET IDENTITY_INSERT [TCD].[UserMaster] OFF
 
Begin
INSERT [TCD].[UserInRole] ([EcoLabAccountNumber], [UserId], [RoleId], [IsDeleted], [LastModifiedByUserId]) VALUES (N'P03810003', 1, 4, 0, 0);
End
 
Begin
INSERT [tcd].[UserProfile] ( [UserId], [EcolabAccountNumber],[LastModifiedByUserId])VALUES
( 1,'P03810003',1);
End
 
INSERT [TCD].[PlantChain] ([PlantChainId], [PlantChainName], [RegionId], [Is_Deleted], [MyServiceChnId], [MyServiceLastSynchTime]) 
VALUES (1, N'Training Laundry', 1, 0, NULL, CAST(0x0000A50000BFC630 AS DateTime))

INSERT [TCD].[Plant] ([PlantId], [EcolabAccountNumber], [Name], [DataLiveTime], [BudgetCustomer], [ExportPath], [LanguageId], [UOMId],
 [CurrencyCode], [PlantCategoryId], [AcutalIsTarget], [RegionId], [PlantChainId], [CreatedOn], [CreatedBy], [ModifiedOn], 
 [ModifiedBy], [TMName], [TMPhoneNumber], [DMName], [DMPhoneNumber], [ChainUnitNumber], [CensusPriceKg], [Remarks], [Rate], 
 [Is_Deleted], [Logo], [LastModifiedByUserId], [AllowManualRewash], [LastModifiedTime], [LastSyncTime], [DashboardSlideDuration],
 [MyServiceCustGuid], [MyServiceLastSynchTime], [PlantContractNumber], [LastArchiveDate], [ConStdTurnTime], [TimeZone],IsETechEnable) VALUES 

(9, N'P03810003', N'Training Laundry', 3, 0, N'C:\EcoLab\Envision\BACKUP', 1, 1, N'USD', 0, 0, 1, 1, 
CAST(0x0000A50100A53903 AS DateTime), 0, CAST(0x0000A50100A53903 AS DateTime), N'0         ', 
N'ANDERSON, MARSHALL J', N'816-726-6665', N'PAVLATOS, JERRY', N'-   -', N'      182', CAST(1.5900 AS Numeric(12, 4)), 
NULL, 0, 0, NULL, 0, 0, CAST(0x0000A50100A53903 AS DateTime), NULL, NULL, N'd504c4c7-cfd8-4cb8-8555-897b58d20f7a', 
CAST(0x0000A50100A539C0 AS DateTime), N'04000', NULL, NULL, 2,0);
INSERT [TCD].[PlantCustAddress] ([EcolabAccountNumber], [BillingAddr1], [BillingAddr2], [City], [Country], [Zip], [ShippingAddr1], [ShippingAddr2], [Shippingcity], [Shippingcountry], [Shippingzip], [MyServiceLastSynchTime]) VALUES (N'P03810003', N'', N'', N'', N'USA', N'               ', N'685 OLIVE ST', N'', N'SAINT PAUL', N'USA', N'55130          ', CAST(0x0000A50100A539C1 AS DateTime));
 
 SET IDENTITY_INSERT TCD.ConduitController ON
    INSERT [TCD].[ConduitController] 
                (    [ControllerId]
                ,    [EcoalabAccountNumber]
                ,    [TopicName]
                ,    [ControllerNumber]
                ,    [ControllerModelId]
                ,    [ControllerTypeId]
                ,    [ControllerVersion]
                ,    [InstallDate]
                ,    [Description]
                ,    [Name]
                ,    [Active]
                ,    [IsDeleted]
                ,    [LastConnectedTime]
                ,    [LastModifiedByUserId]) 
    
    VALUES        (    0
                ,    'P03810003'
                ,    N'Default Controller For myService'
                ,    4001
                ,    1
                ,    1
                ,    NULL
                ,    NULL
                ,    N'Dober Ultrax System #3'
                ,    N'4001 (Ultrax 6/12/16- Allen Bradley)'
                ,    0
                ,    0
                ,    NULL
                ,    0
                )
    
    INSERT [TCD].[ControllerSetupData]
                 (    [ControllerId]
                 ,    [FieldGroupId]
                 ,    [FieldId]
                 ,    [Value]
                 ,    [FieldTagValue]
                 ,    [ControllerModelId]
                 ,    [LastModifiedByUserId]
                 ,    [EcolabAccountNumber]
                 )
    
    VALUES        (0    ,6    ,56    ,N'10'        ,NULL    ,1    ,0    ,'P03810003'),
                (0    ,6    ,57    ,N'10'        ,NULL    ,1    ,0    ,'P03810003'),
                (0    ,6    ,21    ,N'10'        ,NULL    ,1    ,0    ,'P03810003'),
                (0    ,6    ,58    ,N'10'        ,NULL    ,1    ,0    ,'P03810003'),
                (0    ,6    ,79    ,N'33'        ,NULL    ,1    ,0    ,'P03810003'),
                (0    ,6    ,33    ,N'false'    ,NULL    ,1    ,0    ,'P03810003')
    SET IDENTITY_INSERT TCD.ConduitController OFF

	UPDATE TCD.MachineGroup	SET EcolabAccountNumber = N'P03810003'



INSERT [TCD].[ChainTextileCategory] ([TextileId], [Name], [PlantChainId], [IsDeleted], [LastModifiedTime], [LastSyncTime], [ResourceKey]) VALUES (0, N'None', NULL, 0, CAST(0x0000A58D013A45E8 AS DateTime), CAST(0x0000A59300874D9B AS DateTime), NULL)
INSERT [TCD].[ChainTextileCategory] ([TextileId], [Name], [PlantChainId], [IsDeleted], [LastModifiedTime], [LastSyncTime], [ResourceKey]) VALUES (1, N'textilecategory1', 1, 0, CAST(0x0000A58D013A45E8 AS DateTime), CAST(0x0000A59300874D9B AS DateTime), NULL)
INSERT [TCD].[ChainTextileCategory] ([TextileId], [Name], [PlantChainId], [IsDeleted], [LastModifiedTime], [LastSyncTime], [ResourceKey]) VALUES (2, N'textilecategory2', 1, 0, CAST(0x0000A58D013A45E8 AS DateTime), CAST(0x0000A59300874D9C AS DateTime), NULL)
INSERT [TCD].[ChainTextileCategory] ([TextileId], [Name], [PlantChainId], [IsDeleted], [LastModifiedTime], [LastSyncTime], [ResourceKey]) VALUES (3, N'textilecategory3', 1, 0, CAST(0x0000A58D013A45E8 AS DateTime), CAST(0x0000A59300874D9D AS DateTime), NULL)
INSERT [TCD].[ChainTextileCategory] ([TextileId], [Name], [PlantChainId], [IsDeleted], [LastModifiedTime], [LastSyncTime], [ResourceKey]) VALUES (4, N'textilecategory4', 1, 0, CAST(0x0000A58D013A45E8 AS DateTime), CAST(0x0000A59300874D9D AS DateTime), NULL)
INSERT [TCD].[PlantChainProgram] ([PlantProgramId], [PlantProgramName], [PlantChainId], [ChainTextileCategoryId], [EcolabSaturationId], [EcolabTextileCategoryId], [FormulaSegmentId], [Is_Deleted], [LastModifiedTime], [LastModifiedByUserId]) VALUES (0, N'None', NULL, NULL, NULL, NULL, NULL, 0, CAST(0x0000A59200E54C84 AS DateTime), NULL)
INSERT [TCD].[PlantChainProgram] ([PlantProgramId], [PlantProgramName], [PlantChainId], [ChainTextileCategoryId], [EcolabSaturationId], [EcolabTextileCategoryId], [FormulaSegmentId], [Is_Deleted], [LastModifiedTime], [LastModifiedByUserId]) VALUES (1, N'ChainProgram1', 1, 1, 2, 3, 1, 0, CAST(0x0000A58D013A6EEC AS DateTime), 0)
INSERT [TCD].[PlantChainProgram] ([PlantProgramId], [PlantProgramName], [PlantChainId], [ChainTextileCategoryId], [EcolabSaturationId], [EcolabTextileCategoryId], [FormulaSegmentId], [Is_Deleted], [LastModifiedTime], [LastModifiedByUserId]) VALUES (2, N'ChainProgram2', 1, 3, 3, 1, 2, 0, CAST(0x0000A58D013A6EEC AS DateTime), 0)
INSERT [TCD].[PlantChainProgram] ([PlantProgramId], [PlantProgramName], [PlantChainId], [ChainTextileCategoryId], [EcolabSaturationId], [EcolabTextileCategoryId], [FormulaSegmentId], [Is_Deleted], [LastModifiedTime], [LastModifiedByUserId]) VALUES (3, N'ChainProgram3', 1, 2, 2, 4, 3, 0, CAST(0x0000A58D013A6EEC AS DateTime), 0)
INSERT [TCD].[PlantChainProgram] ([PlantProgramId], [PlantProgramName], [PlantChainId], [ChainTextileCategoryId], [EcolabSaturationId], [EcolabTextileCategoryId], [FormulaSegmentId], [Is_Deleted], [LastModifiedTime], [LastModifiedByUserId]) VALUES (4, N'ChainProgram4', 1, 4, 5, 2, 2, 0, CAST(0x0000A58D013A6EEC AS DateTime), 0)
GO
--SET IDENTITY_INSERT [TCD].[FormulaSegments] ON 
--INSERT [TCD].[FormulaSegments] ([FormulaSegmentID], [SegmentName], [LastModifiedTime],  [Is_Deleted]) VALUES (1, N'Health Care', CAST(0x0000A58A009FE3B7 AS DateTime), 0)
--INSERT [TCD].[FormulaSegments] ([FormulaSegmentID], [SegmentName], [LastModifiedTime],  [Is_Deleted]) VALUES (2, N'Hospitality', CAST(0x0000A58A009FED45 AS DateTime), 0)
--INSERT [TCD].[FormulaSegments] ([FormulaSegmentID], [SegmentName], [LastModifiedTime],  [Is_Deleted]) VALUES (3, N'Food & Beverage', CAST(0x0000A58A009FF819 AS DateTime), 0)
--SET IDENTITY_INSERT [TCD].[FormulaSegments] OFF
--GO

INSERT INTO [TCD].ProductdataMapping (ProductID, SKU,Cost,LastModifiedByUserId) VALUES (7295,'G6124304', 5,1) 
INSERT INTO [TCD].ProductdataMapping (ProductID, SKU,Cost,LastModifiedByUserId) VALUES (7455,'G6713412', 5,1) 
INSERT INTO [TCD].ProductdataMapping (ProductID, SKU,Cost,LastModifiedByUserId) VALUES (7568,'G9991265', 5,1) 
INSERT INTO [TCD].ProductdataMapping (ProductID, SKU,Cost,LastModifiedByUserId) VALUES (7205,'G6010503', 5,1) 
GO
UPDATE tcd.ProductdataMapping
SET EcolabAccountNumber = 'P03810003'
GO

DECLARE @EcolabAccountNumber nvarchar(50) = N'P03810003'
INSERT [TCD].[ProgramMaster] ([ProgramId], [Name], [ProgramTargetCost], [Pieces], [DepreciationCost], [TargetChemicalCost], [TargetWaterCost], [TargetEnergeyCost], [EcolabTextileCategoryId], [Rewash], [Weight], [EcolabSaturationId], [EcolabAccountNumber], [PlantProgramId], [ChainTextileId], [CustomerId], [FormulaSegmentId], [Is_Deleted], [LastModifiedByUserId], [LastModifiedTime], [LastSyncTime], [Weight_Display]) 
VALUES (1, N'ChainProgram1', NULL, 2, NULL, NULL, NULL, NULL, NULL, 0, 30.0, 3, @EcolabAccountNumber, 2, NULL, 0, 3, 0, 0, CAST(0x0000A667007873FA AS DateTime), NULL, NULL)
GO
	    
