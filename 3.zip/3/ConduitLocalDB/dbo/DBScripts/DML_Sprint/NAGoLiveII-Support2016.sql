﻿IF  EXISTS (SELECT
			*
		FROM sys.objects 
		WHERE object_id = OBJECT_ID(N'[TCD].[GetChemicalName]') 
			AND type IN (N'P', N'PC'))
BEGIN
	DROP PROCEDURE [TCD].[GetChemicalName]
END
GO

CREATE PROCEDURE [TCD].[GetChemicalName](@ChemName Varchar(1000),@EcolabAccountNumber Varchar(100))     
AS     
SET NOCOUNT ON    
  BEGIN     
  DECLARE @RegionId int
  DECLARE @Country VARCHAR(250)
  SELECT @RegionId = RegionID from [TCD].Plant WHERE EcolabAccountNumber = @EcolabAccountNumber
  SELECT @Country = ISNULL(NULLIF(PLA.Country, ''), PLA.Shippingcountry) FROM [TCD].Plant P JOIN [TCD].PlantCustAddress PLA ON P.EcolabAccountNumber = PLA.EcolabAccountNumber 
	   WHERE P.EcolabAccountNumber = @EcolabAccountNumber

 SELECT M.ProductId, RTRIM(Name) + ' ( ' + RTRIM(SKU) + ' )' as Name, 
 (CASE WHEN ISNULL( M.Cost,0)>0 then M.Cost 
		WHEN ISNULL(PSP.ListPrice,0)>0 THEN PSP.ListPrice
		WHEN ISNULL(PSP.ContractPrice,0)>0 THEN PSP.ContractPrice
		WHEN ISNULL(PSP.CountryPrice,0)>0 THEN PSP.CountryPrice
		ELSE M.Cost 
 END) Cost
 
 ,M.IncludeinCI
 FROM [TCD].ProductMaster M    
 LEFT JOIN TCD.ProductStandardPrice PSP on M.ProductId=PSP.ProductId and PSP.EcolabAccountNumber=@EcolabAccountNumber
 WHERE (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
 AND M.RegionId = @RegionId
 AND M.Country IS NOT NULL
 AND M.Is_Deleted =0
 AND NOT EXISTS (SELECT ProductId     
     FROM   [TCD].ProductdataMapping Map     
                 WHERE  M.ProductId = Map.ProductId AND Map.Is_Deleted=0)  
Order By M.Name     
  END
GO
UPDATE TCD.ConfigSettings
SET
    [Value] = N'10.160.8.29'
WHERE
    [Value] = N'stg-3dtrasarcontroller.nalco.com'
GO
UPDATE TCD.ConfigSettings
SET
    [Value] = N'9343'
WHERE
    [Value] = N'9340'
GO

IF not EXISTS(SELECT 1 FROM TCD.Field f WHERE f.Id = 262 AND f.Label = 'Controller Version')
  BEGIN
	 SET	IDENTITY_INSERT	TCD.Field	ON
	 INSERT INTO tcd.Field
	 (
		Id ,TypeId, Label,Min,Max,FieldGroupId,DataSourceId,IsMandatory,HelpText,HelpTextUrl,DataTypeId,DataCategoryId,CurrencyId,DisplayOrder,ResourceKey,DefaultValue,
		IsEditable,Name,HasFieldTag,DefaultFieldTag,ClassName
	 )
	 VALUES
	 (
		262, 10, N'Controller Version',NULL, NULL, NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,7,N'Controller_Version',N'1.3.0',1,NULL,NULL,NULL,NULL
	 )
	 SET	IDENTITY_INSERT	TCD.Field	OFF
  END
  GO

  IF not EXISTS(SELECT 1 FROM TCD.FieldGroupFieldMapping fgfm WHERE fgfm.FieldId = 262 AND fgfm.FieldGroupId = 4)
  BEGIN
	 SET	IDENTITY_INSERT	TCD.FieldGroupFieldMapping	ON
	 INSERT INTO tcd.FieldGroupFieldMapping
	 (
		Id	,FieldGroupId	,FieldId
	 )
	 VALUES
	 (
		349, 4, 262
	 )
	 SET	IDENTITY_INSERT	TCD.FieldGroupFieldMapping	OFF
  END
  GO

IF  EXISTS (SELECT
			*
		FROM sys.objects 
		WHERE object_id = OBJECT_ID(N'[TCD].[GetRewashFormulasByGroupId]') 
			AND type IN (N'P', N'PC'))
BEGIN
	DROP PROCEDURE [TCD].[GetRewashFormulasByGroupId]
END
GO
CREATE PROCEDURE [TCD].[GetRewashFormulasByGroupId] 
(
  @WasherGroupId INT,
  @EcolabAccountNumber VARCHAR(100)
 )
AS 
  BEGIN    
  SET NOCOUNT ON  
  DECLARE   @WasherGroupTypeName   VARCHAR(50)   =   NULL,
		  @ControllerID	  int	    =	  NULL,
		  @ControllerModelID       INT      =  NULL

  --Determine the WasherGroup type - Conventional/Tunnel
 SELECT @WasherGroupTypeName   =   WGT.WasherGroupTypeName
 FROM  [TCD].WasherGroup       WG
 JOIN  [TCD].WasherGroupType   WGT
 ON   WG.WasherGroupTypeId    =   WGT.WasherGroupTypeId
 JOIN  [TCD].MachineGroup      GT
 ON    WG.WasherGroupId        =   GT.Id
 WHERE GT.EcolabAccountNumber  =   @EcoLabAccountNumber
 AND   WG.WasherGroupId    =   @WasherGroupId

 SELECT		@ControllerID			=		wg.ControllerId 
	FROM	TCD.WasherGroup			wg
	WHERE   wg.WasherGroupId		=		@WasherGroupId
AND			wg.EcolabAccountNumber	=		@EcoLabAccountNumber

SELECT  @ControllerModelID  =  cc.ControllerModelId
 FROM TCD.ConduitController cc
 WHERE cc.ControllerId   =  @ControllerID
AND   cc.EcoalabAccountNumber =  @EcoLabAccountNumber

IF @ControllerModelID = 7 -- MyControl
   BEGIN
    SET @WasherGroupId = NULL
   END

 
 IF ( @WasherGroupTypeName = 'Tunnel' )
    BEGIN
   SELECT DISTINCT pm.ProgramId
   ,    pm.Name
   FROM TCD.TunnelProgramSetup tps
   INNER JOIN TCD.ProgramMaster pm 
   ON pm.ProgramId = tps.ProgramId
   AND pm.EcolabAccountNumber = tps.EcolabAccountNumber
   WHERE tps.WasherGroupId = @WasherGroupId
   AND   tps.EcolabAccountNumber = @EcolabAccountNumber
   AND tps.Is_Deleted <> 1
    END
 ELSE
  BEGIN
     SELECT pm.ProgramId
     ,   pm.Name 
     FROM TCD.WasherProgramSetup wps
     INNER JOIN TCD.ProgramMaster pm 
     ON pm.ProgramId = wps.ProgramId 
     AND pm.EcolabAccountNumber = wps.EcolabAccountNumber
     WHERE (CASE WHEN @WasherGroupId IS NOT NULL 
        THEN wps.WasherGroupId
        ELSE wps.ControllerID
     END)         = (CASE WHEN @WasherGroupId IS NOT NULL 
                 THEN @WasherGroupId
                 ELSE @ControllerID
                 END)
     AND   wps.EcolabAccountNumber = @EcolabAccountNumber
	AND wps.Is_Deleted <> 1
  END
 
  SET NOCOUNT OFF
  END
GO

IF  EXISTS (SELECT
			*
		FROM sys.objects 
		WHERE object_id = OBJECT_ID(N'[TCD].[GetProductWasherGroups]') 
			AND type IN (N'P', N'PC'))
BEGIN
	DROP PROCEDURE [TCD].[GetProductWasherGroups]
END
GO
CREATE PROCEDURE [TCD].[GetProductWasherGroups]
 (
	@EcolabAccountNumber NVARCHAR(25)
 )
AS 
  BEGIN      
	 SET NOCOUNT ON
	 -- SELECT MG.Id,Mg.GroupDescription
  --    FROM   [TCD].MachineGroup MG
	 -- INNER JOIN [TCD].MachineSetup  AS MS  ON MG.Id = Ms.GroupId
	 -- INNER JOIN TCD.Washer w ON w.WasherId = Ms.WasherId
	 --  WHERE MG.GroupTypeId = 2 AND MG.EcolabAccountNumber = @EcolabAccountNumber AND MG.Is_Deleted <> 1 
	 --  AND MS.IsDeleted = 0     		
		--AND MS.ControllerId = 0
		--AND W.WasherMode = 0
		--GROUP BY MG.Id,Mg.GroupDescription
		 SELECT MG.Id,MG.GroupDescription FROM   [TCD].MachineGroup MG
      INNER JOIN TCD.WasherGroup WG ON MG.Id = WG.WasherGroupId       
      WHERE  MG.GroupTypeId = 2 AND MG.EcolabAccountNumber = @EcolabAccountNumber AND Is_Deleted <> 1 
  SET NOCOUNT OFF
  END
GO

------------------------------------------------------------------ Dash Board GetBatchTrendingGroupData start------------------------------------------------
IF  EXISTS (SELECT
			*
		FROM sys.objects 
		WHERE object_id = OBJECT_ID(N'[TCD].[GetBatchTrendingGroupData]') 
			AND type IN (N'P', N'PC'))
BEGIN
	DROP PROCEDURE [TCD].[GetBatchTrendingGroupData]
END
GO

CREATE PROCEDURE [TCD].[GetBatchTrendingGroupData] (@GroupId int )
AS 
SET NOCOUNT ON
BEGIN 

DECLARE @DayId Varchar(20) = NULL,
    @StartTime DateTime = NULL,
    @EndTime DateTime = NULL,
    @TransferStarttime Time = NULL,
    @TransferEndtime Time = NULL,
    @MachineId int = NULL,
    @ParameterId int = NULL,
    @ParameterValue  Int = NULL,
    @WasherStatus Int,
 @RegionId  Int = NULL,
 @EcoLabAccountNumber Varchar(50) = NULL

DECLARE @NoofComp Int = NULL, 
    @Count int = 1

SELECT @NoOfcomp = NumberOfComp FROM [TCD].machinesetup 
  WHERE Groupid = @GroupId and IsTunnel = 1

DECLARE @GET_COMPARTMENT TABLE (
   GroupId INT,
   MachineID INT,
   CompartmentNumber VARCHAR(1000))

WHILE(@count <=  @NoOfcomp) 
BEGIN
   INSERT INTO @GET_COMPARTMENT(GroupId,MachineID,CompartmentNumber)
    SELECT @GroupId,@count,'Compartment'+ cast(@count as Varchar(1000))+''
   SET @count = @count + 1
End

DECLARE @TrendingData TABLE(
    BatchId INT,
    CustomerId INT,
    ProgramId INT,
    ActualLoad DECIMAL(10,2),
    NominalLoad DECIMAL(10,2),
    GroupId INT,
    CompartmentId INT,
    --DupCount INT,
    Efficiency DECIMAL(10,2),
    Temparature  DECIMAL(10,2),
    Conductivity  DECIMAL(10,2),
    PH  DECIMAL(10,2)) 

Declare @DummyTrendingData TABLE(
    BatchId INT,
    CustomerId INT,
    ProgramId INT,
    ActualLoad DECIMAL(10,2),
    NominalLoad DECIMAL(10,2),
    GroupId INT,
    CompartmentId INT,
    --DupCount INT,
    Efficiency DECIMAL(10,2),
    Temparature  DECIMAL(10,2),
    Conductivity  DECIMAL(10,2),
    PH  DECIMAL(10,2)) 
   
INSERT INTO @TrendingData(
    BatchId ,
    CustomerId ,
    ProgramId ,
    ActualLoad,
    NominalLoad ,
    GroupId ,
    CompartmentId ,
    --DupCount INT,
    Efficiency ,
    Temparature ,
    Conductivity,
    PH) 


     SELECT DISTINCT
             BA.BatchId,
             BC.CustomerId,
             BA.ProgramNumber,
             BA.[ActualWeight],
             BA.[StandardWeight],
             BA.GroupId,
             BS.StepCompartment,
             (BA.[ActualWeight]/BA.[StandardWeight]) * 100 AS LoadEfficiency,
             TE.Reading AS Temparature,
             CO.Reading AS Conductivity,
             PH.Reading AS PH

        FROM [TCD].BatchWashStepData AS BS
             INNER JOIN [TCD].BatchData BA ON BA.BatchId = BS.BatchId
             LEFT OUTER JOIN [TCD].BatchCustomerData BC ON BC.BatchId = BA.BatchId
             LEFT OUTER JOIN (SELECT SS.GroupId,
                            SS.MachineCompartment,
                            MR.Reading
                        FROM TCD.ModuleReading MR INNER JOIN TCD.Sensor SS ON MR.ModuleId = SS.SensorId WHERE MR.ModuleTypeId = 3 AND SS.SensorType = 1) TE
             ON BA.GroupId = TE.GroupId AND BS.StepCompartment = TE.MachineCompartment
              LEFT OUTER JOIN (SELECT SS.GroupId,
                            SS.MachineCompartment,
                            MR.Reading
                        FROM TCD.ModuleReading MR INNER JOIN TCD.Sensor SS ON MR.ModuleId = SS.SensorId WHERE MR.ModuleTypeId = 3 AND SS.SensorType = 4) CO
             ON BA.GroupId = CO.GroupId AND BS.StepCompartment = CO.MachineCompartment

    LEFT OUTER JOIN (SELECT SS.GroupId,
                            SS.MachineCompartment,
                            MR.Reading
                        FROM TCD.ModuleReading MR INNER JOIN TCD.Sensor SS ON MR.ModuleId = SS.SensorId WHERE MR.ModuleTypeId = 3 AND SS.SensorType = 2) PH
             ON BA.GroupId = CO.GroupId AND BS.StepCompartment = CO.MachineCompartment

        WHERE BS.EndTime IS NULL AND BA.EndDate IS NULL
        AND BA.GroupId = @GroupId 
		AND BA.StandardWeight > 0  
		AND BA.ActualWeight > 0 

  Select @MachineId = WasherId,@EcoLabAccountNumber=EcoalabAccountNumber from tcd.MachineSetup where GroupId = @GroupId
  Select top 1 @ParameterId =  ParameterId ,@Parametervalue = ParameterValue from TCD.washerReading where WasherId = @MachineId order by DateTimeStamp desc
  select top 1 @RegionId = RegionId from TCD.Plant where EcolabAccountNumber=@EcoLabAccountNumber

  If(@ParameterId = 6 and @Parametervalue = 0)
   BEGIN
    set @WasherStatus = 1
   END
  Else If (@ParameterId = 6 and @Parametervalue = 1)
   BEGIN
    set @WasherStatus = 2
   END
  Else If (@ParameterId = 12)
   BEGIN
    set @WasherStatus = 0
   END

  INSERT INTO @DummyTrendingData(BatchId,CustomerId,ProgramId,ActualLoad,NominalLoad,GroupId,CompartmentId,Efficiency,Temparature,Conductivity,PH)
    SELECT 0,0,0,0,0,GroupId,MachineID,0,0,0,0 FROM @GET_COMPARTMENT

    IF(@WasherStatus != 2)
    BEGIN
    UPDATE  D  SET

      D.BatchId = C.BatchId, 
      D.CustomerId =  CASE WHEN C.ActualLoad = 0 THEN 0
       ELSE 
      C.CustomerId END,
      D.ProgramId = C.ProgramId,
      D.ActualLoad = C.ActualLoad,
      D.NominalLoad = C.NominalLoad,
      D.GroupId = CASE WHEN C.GroupId = 0 THEN C.GroupId ELSE D.GroupId END,
      D.CompartmentId =  CASE WHEN C.CompartmentId IS NOT NULL THEN C.CompartmentId ELSE D.CompartmentId END,
      D.Efficiency = CAST(C.Efficiency AS decimal(10,2)),
      D.Temparature = CAST(C.Temparature AS decimal(10,2)),
      D.Conductivity = CAST(C.Conductivity AS decimal(10,2)),
      D.PH = CAST(C.PH AS decimal(10,2)) 
      FROM @DummyTrendingData D LEFT OUTER JOIN @TrendingData C ON D.CompartmentId = C.CompartmentId

   END
       SELECT 
      ISNULL(BatchId,0) AS BatchId,
      ISNULL(CustomerId,0) AS CustomerId,
      ISNULL(ProgramId,0) AS ProgramId,
   (CASE WHEN (@RegionId=1) THEN ISNULL(ActualLoad,0) ELSE ROUND((ISNULL(ActualLoad,0)*0.453592),0) END) AS ActualLoad,
   (CASE WHEN (@RegionId=1) THEN ISNULL(NominalLoad,0) ELSE ROUND((ISNULL(NominalLoad,0)*0.453592),0) END) AS NominalLoad,
      ISNULL(GroupId,0) AS GroupId,
      ISNULL(CompartmentId,0) AS CompartmentId,
      ISNULL(Efficiency,0) AS Efficiency,
      ISNULL(Temparature,0) AS Temparature,
      ISNULL(Conductivity,0) AS Conductivity,
      ISNULL(PH,0) AS PH
       FROM @DummyTrendingData
  END

  ------------------------------------------------------------------ Dash Board GetBatchTrendingGroupData End------------------------------------------------

  Go

  ----------------------------------------------------------DCS Process Mycontrol Start----------------------------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlConventionalData_Online]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlConventionalData_Online]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ProcessMyControlConventionalData_Online]
(
	@ControllerID   INT,
	@VxML           XML,
	@RedFlagShiftId INT OUTPUT
)
AS
	BEGIN
	    DECLARE @MachineNumber           INT,
			  @StepNumber              INT,
			  @StartDateTime           DATETIME,
			  @EndDateTime             DATETIME,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @PHValue                 INT,
			  @TemperatureMin          INT,
			  @TemperatureMax          INT,
			  @TempMinStatus           INT,
			  @TempMaxStatus           INT,
			  @BatchNumber             INT,
			  @WasherID                INT,
			  @WasherGroupID           INT,
			  @EcoLabWasherID          INT,
			  @ProgramMasterID         INT,
			  @PlantWasherNumber       INT,
			  @ShiftID                 INT,
			  @FrmParameterID          INT,
			  @PHParameterID           INT,
			  @PHParameterStatus       INT,
			  @BatchID                 INT,
			  @ShiftStartdate          DATETIME,
			  @ShiftName               NVARCHAR(50),
			  @XMLDataID               INT,
			  @TempParameter           INT,
			  @TemperatureMinParam     INT,
			  @TemperatureMaxParam     INT,
			  @TempMinStatusParam      INT,
			  @TempMaxStatusParam      INT,
			  @WashStepNo              INT,
			  @CurrencyCode            VARCHAR(50),
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @TargetTurnTime          INT,
			  @MeterID                INT,
			  @WaterConsumption1      DECIMAL(18,4),
			  @WaterConsumption2      DECIMAL(18,4),
			  @ModuleCount			  INT

	    SELECT @MachineNumber = T.c.value('@MachineNumber', 'INT'),
			 @StepNumber = T.c.value('@StepNumber', 'INT'),
			 @StartDateTime = T.c.value('@StartDateTime', 'DATETIME'),
			 @EndDateTime = T.c.value('@EndDateTime', 'DATETIME'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@NominalLoad', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'INT'),
			 @PHStatus = T.c.value('@PHStatus', 'INT'),
			 @PHValue = T.c.value('@PHValue', 'INT'),
			 @TemperatureMin = T.c.value('@TemperatureMin', 'INT'),
			 @TemperatureMax = T.c.value('@TemperatureMax', 'INT'),
			 @TempMaxStatus = T.c.value('@TemperatureMaxStatus', 'INT'),
			 @TempMinStatus = T.c.value('@TemperatreMinStatus', 'INT'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @WaterConsumption1=T.c.value('@WaterConsumption1','DECIMAL(18,4)'),
			 @WaterConsumption2=T.c.value('@WaterConsumption2','DECIMAL(18,4)')
	    FROM @VxML.nodes('MyControlConventionalData') T(C);

		--Check for valid startdatetime
		IF(@StartDateTime <='01/01/1900' OR @StartDateTime > '06/06/2079')
		BEGIN
			return
		END

	    SELECT @PHParameterID = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'pH';
	    SELECT @PHParameterStatus = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'PH Status';
	    SELECT @TemperatureMinParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Mimum Temperature';
	    SELECT @TemperatureMaxParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Maximum Temperature';
	    SELECT @TempMinStatusParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Minimum Temperature Status';
	    SELECT @TempMaxStatusParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Max Temperature Status';
	    SELECT @WashStepNo = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'StepCompartment No';
	    SELECT @FrmParameterID = [Id]
	    FROM TCD.ConduitPArameters
	    WHERE Name = 'Formula Number';
	    DECLARE @ShiftMapping TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    INSERT INTO @ShiftMapping
	    (
		  ShiftId,
		  ShiftName,
		  ShiftStartdate
	    )
	    EXEC TCD.GetShiftStartDate
		    @StartDateTime
	    SELECT @ShiftID = ShiftID,
			 @ShiftStartdate = ShiftStartdate
	    FROM @ShiftMapping;
	    SELECT @WasherGroupID = GroupId,
			 @WasherID = WasherID
	    FROM TCD.MachineSetup ms
	    WHERE ControllerID = @ControllerID
			AND MachineInternalId = @MachineNumber
			AND IsTunnel = 0
			AND IsDeleted = 0;
	    IF(@EndDateTime = '1/1/1900')
		   SELECT @EndDateTime = NULL;
	    IF(@StartDateTime = '1/1/1900')
		   SELECT @StartDateTime = NULL;
	    IF(@WasherId IS NOT NULL)
		   BEGIN
			  SELECT @ProgramMasterId = Wps.ProgramId
			  FROM TCD.Washer Ws
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.ControllerID = Wg.ControllerId
				  INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.EcoLabAccountNumber
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wps.Is_Deleted = 0;
			  SELECT @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber,
				    @CurrencyCode = P.CurrencyCode,
				    @TargetTurnTime = w.TargetTurnTime * 60
			  FROM TCD.Washer w
				  INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.EcolabAccountNumber
			  WHERE w.WasherId = @WasherID;
	   END;
	    SELECT @BatchID = BatchID
	    FROM TCD.BatchData
	    WHERE MachineInternalID = @MachineNumber
			AND StartDate = @StartDateTime
			AND ControllerBatchId = @BatchNumber
			AND MachineID = @WasherID;

	    --Start Getting InjectionCount and StepCount
	    SELECT @StdInjectionSteps = COUNT(DISTINCT wdpm.
	    WasherDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) -
			 COUNT(DISTINCT wdpm.WasherDosingSetupId)
	    FROM TCD.WasherDosingProductMapping wdpm
		    RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm.
		    WasherDosingSetupId = wds.WasherDosingSetupId
	    WHERE wds.ControllerID = @ControllerID
			AND wds.ProgramNumber = @ProgramNumber;
	    --End Getting InjectionCount and StepCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramMasterId
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT @EcolabTextileCategoryId = pcp.
			  EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp.
				    ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    IF(@BatchID IS NULL)
		   BEGIN
			  INSERT INTO TCD.BatchData
			  (ControllerBatchID,
			   EcolabWasherId,
			   GroupId,
			   MachineInternalId,
			   PlantWasherNumber,
			   StartDate,
			   EndDate,
			   ProgramNumber,
			   ProgramMasterId,
			   MachineID,
			   ActualWeight,
			   StandardWeight,
			   CurrencyCode,
			   ShiftId,
			   PartitionOn,
			   StdInjectionSteps,
			   StdWashSteps,
			   EcolabTextileCategoryId,
			   ChainTextileCategoryId,
			   FormulaSegmentId,
			   EcolabSaturationId,
			   PlantProgramId,
			   EndDateFormula,
			   TargetTurnTime
			  )
			  VALUES
			  (
				    @BatchNumber,
				    @EcoLabWasherID,
				    @WasherGroupID,
				    @MachineNumber,
				    @PlantWasherNumber,
				    @StartDateTime,
				    @EndDateTime,
				    @ProgramNumber,
				    @ProgramMasterId,
				    @WasherID,
				    @Load,
				    @NominalLoad,
				    @CurrencyCode,
				    @ShiftID,
				    @ShiftStartdate,
				    @StdInjectionSteps,
				    @StdWashSteps,
				    @EcolabTextileCategoryId,
				    @ChainTextileCategoryId,
				    @FormulaSegmentId,
				    @EcolabSaturationId,
				    @PlantProgramId,
				    @EndDateTime,
				    @TargetTurnTime
			  );
			  SELECT @BatchID = SCOPE_IDENTITY();
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM TCD.BatchParameters
				 WHERE BatchId = @BatchID
					  AND ParameterID = 38
			   )
			   BEGIN
			   IF(@StdWashSteps <> 0
				 OR @StdWashSteps <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
					   BatchId,
					   EcolabWasherId,
					   ParameterId,
					   ParameterValue,
					   PartitionOn
					)
					SELECT @BatchID,
						  @EcoLabWasherID,
						  38,
						  @StdWashSteps,
						  @ShiftStartdate;
				  END
			END;

			  --End Date  Time  is Null 
			  UPDATE TCD.BatchData
			    SET
				   EndDate = GETUTCDATE()
			  WHERE MachineInternalID = @MachineNumber
				   AND StartDate <> @StartDateTime
				   AND EndDate IS NULL
				   AND ControllerBatchId <> @BatchNumber
				   AND MachineId = @WasherId;	
																  		
			  -- Program Number	
			  IF(@ProgramNumber IS NOT NULL
				AND @ProgramNumber > 0)
				 BEGIN
					IF NOT EXISTS
					(
					    SELECT *
					    FROM TCD.WasherReading
					    WHERE WasherId = @WasherID
							AND ParameterID = @FrmParameterID
							AND DateTimeStamp = @StartDateTime
					)
					    BEGIN
						   INSERT INTO TCD.WasherReading
						   (WasherID,
						    ParameterID,
						    ParameterValue,
						    DateTimeStamp,
						    EcoLabWasherID,
						    Partitionon
						   )
						   VALUES
						   (
								@WasherID,
								@FrmParameterID,
								@ProgramNumber,
								@StartDateTime,
								@EcoLabWasherID,
								@ShiftStartdate
						   );
					    END;
				 END;
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM [TCD].[BatchCustomerData]
				 WHERE BatchID = @BatchId
					  AND @CustomerNumber IS NOT NULL
			  )
				 BEGIN
					INSERT INTO [TCD].[BatchCustomerData]
					([BatchId],
					 CustomerID,
					 [Weight],
					 PartitionOn,
					 EcolabWasherId
					)
					VALUES
					(
						  @BatchID,
						  @CustomerNumber,
						  @Load,
						  @ShiftStartdate,
						  @EcolabWasherID
					);
				 END;
		   END;

	    -- PH Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @PHParameterID
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@PHValue <> 0
				OR @PHValue <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @PHParameterID,
							    @PHValue,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 
	 
	    -- PH Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @PHParameterStatus
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@PHStatus <> 0
				OR @PHStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @PHParameterStatus,
							    @PHStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Min Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TemperatureMinParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TemperatureMin <> 0
				OR @TemperatureMin <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TemperatureMinParam,
							    @TemperatureMin,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Max Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TemperatureMaxParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TemperatureMax <> 0
				OR @TemperatureMax <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TemperatureMaxParam,
							    @TemperatureMax,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Min Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TempMinStatusParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TempMinStatus <> 0
				OR @TempMinStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TempMinStatusParam,
							    @TempMinStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Max Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TempMaxStatusParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TempMaxStatus <> 0
				OR @TempMaxStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TempMaxStatusParam,
							    @TempMaxStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- StepCompartment No
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @WashStepNo
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@StepNumber <> 0
				OR @StepNumber <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @WashStepNo,
							    @StepNumber,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END;
 --Start water consumption per batch

	SELECT @MeterID=MeterId
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@MachineNumber
   AND mt.CounterNum = 1;

   SELECT @ModuleCount= COUNT(1) FROM TCD.ModuleReading WHERE Reading =@WaterConsumption1 AND ModuleId = @MeterID
  IF (@ModuleCount=0)
  BEGIN
  IF(ISNULL(@WaterConsumption1,0) > 0 AND ISNULL(@MeterID,0) > 0)
  BEGIN
   INSERT INTO TCD.ModuleReading
     (ModuleId,
      ModuleTypeId,
      Reading,
      TimeStamp
     )
     SELECT
     @MeterID,
     2,	  --Water Meter
     @WaterConsumption1,
     GETUTCDATE()
  END
 END 
 
 SELECT @MeterID=MeterId
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@MachineNumber
   AND mt.CounterNum = 2; 
 -- set  @ModuleCount=@@ROWCOUNT
  SELECT @ModuleCount= COUNT(1) FROM TCD.ModuleReading WHERE Reading =@WaterConsumption2 AND ModuleId = @MeterID
  IF (@ModuleCount=0)
  BEGIN
  IF(ISNULL(@WaterConsumption2,0) > 0 AND ISNULL(@MeterID,0) > 0)
  BEGIN
   INSERT INTO TCD.ModuleReading
     (ModuleId,
      ModuleTypeId,
      Reading,
      TimeStamp
     )
     SELECT
     @MeterID, 
     2,
     @WaterConsumption2,
     GETUTCDATE()
  END
      END   
	 --End water consumption per batch
 END;
 GO

 IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlConventionalData_CompletedBatches]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlConventionalData_CompletedBatches]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ProcessMyControlConventionalData_CompletedBatches](
	@ControllerID   INT,
	@VxML           XML,
	@PLCPointer     INT,
	@ReadPointer    INT,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @MachineNumber           INT,
			  @StartDateTime           DATETIME,
			  @EndDateTime             DATETIME,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @PHValue                 INT,
			  @TemperatureMin          INT,
			  @TemperatureMax          INT,
			  @TempMinStatus           INT,
			  @TempMaxStatus           INT,
			  @BatchNumber             INT,
			  @WasherID                INT,
			  @WasherGroupID           INT,
			  @EcoLabWasherID          INT,
			  @ProgramMasterID         INT,
			  @PlantWasherNumber       INT,
			  @ShiftID                 INT,
			  @BatchID                 INT,
			  @ShiftStartdate          DATETIME,
			  @LastStep                INT,
			  @CurrentStep             INT,
			  @CurrentStepTime         DATETIME,
			  @MinTempParamID          INT,
			  @MaxTempParamID          INT,
			  @MinTempStatuParamID     INT,
			  @MaxTempStatusParamID    INT,
			  @PHStatusParamID         INT,
			  @PHValueParamID          INT,
			  @CurrencyCode            VARCHAR(50),
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @ActualInjSteps          INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @TargetTurnTime          INT,
			  @PreviousShiftId         INT,
			  @CurrentShiftId          INT,
			  @MeterID                 INT,
			  @StepComportment         INT,
			  @Stepno                  INT,
			  @quantity                INT,
			  @productid               INT,
			  @Price                   DECIMAL(18, 4),
			  @StandardQty             DECIMAL(18, 4),
			  @TimeStamp               DATETIME2(7),
			  @MaxWashertGroupCapacity INT,
			  @InjectionNumber         INT,
			  @WaterConsumption1       DECIMAL(10,6),
			  @WaterConsumption2       DECIMAL(10,6),
			  @EnergyCount             INT,
			   @EcolabAccountNumber    VARCHAR(100),
	           @AlarmGroupMasterId     INT;
	    SELECT
			 @MachineNumber = T.c.value('@MachineNumber', 'INT'),
			 @StartDateTime = T.c.value('@StartDateTime', 'DateTime'),
			 @EndDateTime = T.c.value('@EndDateTime', 'DateTime'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@NominalLoad', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'INT'),
			 @PHStatus = T.c.value('@PHStatus', 'INT'),
			 @PHValue = T.c.value('@PHValue', 'INT'),
			 @TemperatureMin = T.c.value('@TemperatureMin', 'INT'),
			 @TemperatureMax = T.c.value('@TemperatureMax', 'INT'),
			 @TempMaxStatus = T.c.value('@TemperatureMaxStatus', 'INT'),
			 @TempMinStatus = T.c.value('@TemperatreMinStatus', 'INT'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @WaterConsumption1 = T.c.value('@WaterConsumption1','DECIMAL(10,6)'),
			 @WaterConsumption2 = T.c.value('@WaterConsumption2','DECIMAL(10,6)')
	    FROM @VxML.nodes('MyControlConventionalData') T(C);

		--Check for valid startdatetime
		IF(@StartDateTime <='01/01/1900' OR @StartDateTime > '06/06/2079')
		BEGIN
			return
		END

	    DECLARE @ShiftMapping TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    INSERT INTO @ShiftMapping
	    (
			 ShiftId,
			 ShiftName,
			 ShiftStartdate
	    )
	    EXEC TCD.GetShiftStartDate
		    @StartDateTime;
	    SELECT
			 @ShiftID = ShiftID,
			 @ShiftStartdate = ShiftStartdate
	    FROM @ShiftMapping;
	    SELECT
			 @WasherGroupID = GroupId,
			 @WasherID = WasherID
	    FROM TCD.MachineSetup ms
	    WHERE ControllerID = @ControllerID
			AND MachineInternalId = @MachineNumber
			AND IsTunnel = 0
			AND IsDeleted = 0;
	    IF(@WasherId IS NOT NULL)
		   BEGIN
			  SELECT
				    @ProgramMasterId = Wps.ProgramId
			  FROM TCD.Washer Ws
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws
				  .WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =
				  Mst.GroupId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.
				  ControllerID = Wg.ControllerId
				  INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber =
				  Ws.EcoLabAccountNumber
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wps.Is_Deleted = 0;
			  SELECT
				    @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber,
				    @CurrencyCode = P.CurrencyCode,
				    @TargetTurnTime = w.TargetTurnTime * 60
			  FROM TCD.Washer w
				  INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.
				  EcolabAccountNumber
			  WHERE w.WasherId = @WasherID;
		   END;
	    SELECT
			 @BatchID = BatchID
	    FROM TCD.BatchData
	    WHERE MachineInternalID = @MachineNumber
			AND StartDate = @StartDateTime
			AND ControllerBatchId = @BatchNumber
			AND MachineID = @WasherID;

	    --Start Getting InjectionCount and StepCount

	    SELECT
			 @StdInjectionSteps = COUNT(DISTINCT wdpm.
			 WasherDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) -
			 COUNT(DISTINCT wdpm.WasherDosingSetupId)
	    FROM TCD.WasherDosingProductMapping wdpm
		    RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm.
		    WasherDosingSetupId = wds.WasherDosingSetupId
	    WHERE wds.ControllerID = @ControllerID
			AND wds.ProgramNumber = @ProgramNumber;

	    --End Getting InjectionCount and StepCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT
			 @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramMasterId
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT
				    @EcolabTextileCategoryId = pcp.
				    EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp.
				    ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    IF(@BatchID IS NULL)
		   BEGIN

			  --Start Rollup for previous completed shift
			  IF(CAST(@StartDateTime AS DATE) < CAST(GETUTCDATE() AS
			  DATE))
				 BEGIN
					SELECT TOP 1
						  @PreviousShiftId = ShiftId
					FROM TCD.BatchData
					WHERE MachineId = @WasherId
					ORDER BY
						    StartDate DESC;
					SELECT TOP 1
						  @CurrentShiftId = ShiftId
					FROM @ShiftMapping;
					IF(@CurrentShiftId != @PreviousShiftId)
					    BEGIN
						   EXEC TCD.ProductionShiftDataRollup
							   @PreviousShiftId,
							   @RedFlagShiftId OUTPUT;
						   IF(@RedFlagShiftId IS NULL)
							  BEGIN
								 SET @RedFlagShiftId =
								 @PreviousShiftId;
							  END;
					    END;
				 END;
			  --End Rollup for previous completed shift

			  INSERT INTO TCD.BatchData
			  (
				    ControllerBatchID,
				    EcolabWasherId,
				    GroupId,
				    MachineInternalId,
				    PlantWasherNumber,
				    StartDate,
				    EndDate,
				    ProgramNumber,
				    ProgramMasterId,
				    MachineID,
				    ActualWeight,
				    StandardWeight,
				    CurrencyCode,
				    ShiftId,
				    PartitionOn,
				    StdInjectionSteps,
				    StdWashSteps,
				    EcolabTextileCategoryId,
				    ChainTextileCategoryId,
				    FormulaSegmentId,
				    EcolabSaturationId,
				    PlantProgramId,
				    EndDateFormula,
				    TargetTurnTime
			  )
			  VALUES
			  (
				    @BatchNumber,
				    @EcoLabWasherID,
				    @WasherGroupID,
				    @MachineNumber,
				    @PlantWasherNumber,
				    @StartDateTime,
				    @EndDateTime,
				    @ProgramNumber,
				    @ProgramMasterId,
				    @WasherID,
				    @Load,
				    @NominalLoad,
				    @CurrencyCode,
				    @ShiftID,
				    @ShiftStartdate,
				    @StdInjectionSteps,
				    @StdWashSteps,
				    @EcolabTextileCategoryId,
				    @ChainTextileCategoryId,
				    @FormulaSegmentId,
				    @EcolabSaturationId,
				    @PlantProgramId,
				    @EndDateTime,
				    @TargetTurnTime
			  );
			  SELECT
				    @BatchID = SCOPE_IDENTITY();
			  IF NOT EXISTS
			  (
				 SELECT
					   *
				 FROM TCD.BatchParameters
				 WHERE BatchId = @BatchID
					  AND ParameterID = 38
			  )
				 BEGIN
					IF(@StdWashSteps > 0
					   OR @StdWashSteps <> NULL)
					    INSERT INTO TCD.BatchParameters
					    (
							 BatchId,
							 EcolabWasherId,
							 ParameterId,
							 ParameterValue,
							 PartitionOn
					    )
					    SELECT
							 @BatchID,
							 @EcoLabWasherID,
							 38,
							 @StdWashSteps,
							 @ShiftStartdate;
				 END;
		   END;
	    ELSE
		   BEGIN
			  UPDATE tcd.BatchData
			    SET
				   EndDate = @EndDateTime,
				   EndDateFormula = @EndDateTime,
				   ProgramNumber = @ProgramNumber,
				   ProgramMasterId = @ProgramMasterID,
				   ActualWeight = @Load,
				   SyncReady = 1
			  WHERE
				   BatchID = @BatchID;
		   END;
		      --If the received formula is not configured in enVision then create an alarm 
       IF(@ProgramMasterId is NULL)
       BEGIN
       SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant;
       SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.AlarmGroupMsterVsControllerModelType AGMVCMT
       INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
       WHERE AGMVCMT.AlarmCode = 9000
        INSERT INTO [TCD].[AlarmData] 
           (EcoalabAccountNumber,
           AlarmCode,
           BatchId,
           controllerID,
           StartDate,
           GroupId,
           MachineInternalId,
           ProgramId,   
           IsActive,
           EndDate,
           MachineId,
           AlarmGroupMasterId)
           SELECT
            @ECOLABAccountNumber,
            9000,
            @BatchID,
            @ControllerId,
            @StartDateTime,
            @WasherGroupID,
            @MachineNumber,
            @ProgramNumber,
            0,
            @StartDateTime,
            @WasherId,
            @AlarmGroupMasterId
       END





	    IF NOT EXISTS
	    (
		   SELECT
				1
		   FROM [TCD].[BatchCustomerData]
		   WHERE BatchID = @BatchId
			    AND @CustomerNumber IS NOT NULL
	    )
		   BEGIN
			  INSERT INTO [TCD].[BatchCustomerData]
			  (
				    [BatchId],
				    CustomerID,
				    [Weight],
				    PartitionOn,
				    EcolabWasherId
			  )
			  VALUES
			  (
				    @BatchID,
				    @CustomerNumber,
				    @Load,
				    @ShiftStartdate,
				    @EcolabWasherID
			  );
		   END;
	    ELSE
	    IF(@CustomerNumber > 0)
		   BEGIN
			  UPDATE [TCD].[BatchCustomerData]
			    SET
				   CustomerID = @CustomerNumber,
				   [Weight] = @Load
			  WHERE
				   BatchID = @BatchId;
		   END;
	    CREATE TABLE #Dosing
	    (
		    equipmentNo INT,
		    StepNo      INT,
		    Qty         DECIMAL(10, 6)
	    );
	    INSERT INTO #Dosing
	    SELECT
			 T.c.value('@Equipment', 'INT'),
			 T.c.value('@stepNo', 'INT'),
			 T.c.value('@Qty', 'Decimal(10,6)')
	    FROM @VxML.nodes('MyControlConventionalData/DosingData/Dosing') T
	    (C)
	    WHERE T.c.value('@Qty', 'Decimal(10,6)') > 0;
	    CREATE TABLE #StepTime
	    (
		    Number    INT,
		    [Time]    INT,
		    StartTime DATETIME,
		    EndTime   DATETIME
	    );
	    INSERT INTO #StepTime
	    (
			 Number,
			 [Time]
	    )
	    SELECT
			 T.c.value('@Number', 'INT'),
			 T.c.value('@Time', 'INT')
	    FROM @VxML.nodes('MyControlConventionalData/StepTime/Step') T(C);
	    CREATE TABLE #TimeStamp
	    (
		    Step_Number INT,
		    Time_Stamp  INT
	    );
	
	    --For Calculating TIME_STAMP

	    WITH TempTable
		    AS (SELECT DISTINCT
					Number
			   FROM #StepTime)
		    INSERT INTO #TimeStamp
		    (
				 Step_Number,
				 Time_Stamp
		    )
		    SELECT
				 b.Number,
				 SUM(t.Time) Time_Stamp
		    FROM TempTable b
			    INNER JOIN #StepTime t ON b.Number >= t.Number
		    GROUP BY
				   b.Number;
	    CREATE TABLE #BatchProductData
	    (
		    equipmentNo INT,
		    StepNo      INT,
		    Qty         DECIMAL(10, 6),
		    Time_Stamp  DATETIME2(7),
		    ProductId   INT,
		    Row_No      INT
	    );
	    INSERT INTO #BatchProductData
	    (
			 EquipmentNo,
			 StepNo,
			 Qty,
			 Time_Stamp,
			 ProductId,
			 Row_No
	    )
	    SELECT
			 d.equipmentNo,
			 d.StepNo,
			 d.Qty,
			 DATEADD(ss, ts.Time_Stamp, @StartDateTime),
			 ces.ProductId,
			 ROW_NUMBER() OVER(ORDER BY d.StepNo DESC) AS Row
	    FROM #Dosing d
		    INNER JOIN #TimeStamp ts ON d.StepNo = ts.Step_Number
		    INNER JOIN tcd.ControllerEquipmentSetup ces ON ces.
		    ControllerEquipmentId = d.equipmentNo
	    WHERE d.equipmentNo > 0
			AND d.Qty > 0
			AND ControllerID = @ControllerID
			AND ces.ProductId IS NOT NULL;
	    SELECT
			 @MaxWashertGroupCapacity = MAX(ws.MaxLoad)
	    FROM TCD.Washer WS
		    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.
		    GroupId
	    WHERE Mst.GroupId = @WasherGroupID;
	    DECLARE @Counter INT;
	    SET @counter = 1;
	    WHILE(@counter <=
		    (
			   SELECT
					COUNT(ROW_No)
			   FROM #BatchProductData bpd
		    ))
		   BEGIN
			  SELECT
				    @stepno = bpd.StepNo,
				    @quantity = bpd.Qty,
				    @productid = bpd.ProductId,
				    @timestamp = bpd.Time_Stamp
			  FROM #BatchProductData bpd
			  WHERE bpd.Row_No = @counter
			  ORDER BY
					 bpd.StepNo;
			  SELECT
				    @InjectionNumber = Wdpm.InjectionNumber,
				    @standardqty = ((@NominalLoad / CONVERT( DECIMAL(
				    10, 2), 100)) * Wdpm.Quantity * Ws.MaxLoad) /
				    CONVERT(DECIMAL(10, 2), 100),
				    @price = ((@NominalLoad / CONVERT(       DECIMAL(
				    10, 2), 100)) * Wdpm.Quantity *
				    @MaxWashertGroupCapacity) / CONVERT(DECIMAL(10, 2),
				    100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID)
			  FROM TCD.Washer WS
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws
				  .WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =
				  Mst.GroupId
				  INNER JOIN TCD.WasherGroupType WgT ON WgT.
				  WasherGroupTypeId = Wg.WasherGroupTypeId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.
				  ControllerID = Wg.ControllerId
				  INNER JOIN TCD.WasherDosingSetup Wds ON Wds.
				  WasherProgramSetupId = Wps.WasherProgramSetupId
				  INNER JOIN TCD.WasherDosingProductMapping Wdpm ON
				  Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
				  INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.
				  ProductId = Wdpm.ProductId
				  INNER JOIN TCD.BatchData Bd ON Bd.MachineId = Ws.
				  WasherId
			  WHERE Ws.WasherId = @WasherID
				   AND Wps.ProgramNumber = @ProgramNumber
				   --AND Wdpm.InjectionNumber = @stepno
				   AND Bd.BatchId = @BatchID
				   AND Wps.Is_Deleted = 0
				   AND Pdm.Is_Deleted = 0;
			  INSERT INTO TCD.BatchProductData
			  (
				    BatchId,
				    StepCompartment,
				    ActualQuantity,
				    StandardQuantity,
				    Price,
				    PartitionOn,
				    EcolabWasherId,
				    ProductId,
				    TimeStamp,
				    InjectionNumber
			  )
			  VALUES
			  (
				    @BatchID,
				    @stepno,
				    @quantity,
				    ISNULL(@standardqty,0),
				    ISNULL(@price,0),
				    @ShiftStartdate,
				    @EcolabWasherId,
				    @productid,
				    @timestamp,
				    @InjectionNumber
			  );
			  SET @counter = @counter + 1;
		   END;
	    --END For calculating TIMESTAMP
	    --Start Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
	    SELECT
			 @ActualInjSteps = COUNT(DISTINCT StepNo)
	    FROM #Dosing 
		Where StepNo > 0 ;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE ParameterId = 37
			    AND batchid = @BatchID
			    AND @ActualInjSteps > 0
	    )
		   BEGIN
			  IF(@ActualInjSteps > 0
				OR @ActualInjSteps IS NOT NULL)
				 INSERT INTO TCD.BatchParameters
				 (
					   BatchId,
					   EcolabWasherId,
					   ParameterId,
					   ParameterValue,
					   PartitionOn
				 )
				 SELECT
					   @BatchId,
					   @EcolabWasherId,
					   37,
					   @ActualInjSteps,
					   @ShiftStartDate;
		   END;
	    ELSE
		   BEGIN
			  UPDATE TCD.BatchParameters
			    SET
				   ParameterValue = @ActualInjSteps
			  WHERE
				   ParameterId = 37
				   AND batchid = @BatchID;
		   END;
	    SELECT
			 @LastStep = MAX([Number])
	    FROM #StepTime
	    WHERE [Time] > 0;
	    SELECT
			 @CurrentStep = 1,
			 @CurrentStepTime = @StartDateTime;
	    WHILE(@CurrentStep <= @LastStep)
		   BEGIN
			  UPDATE #StepTime
			    SET
				   StartTime = @CurrentStepTime,
				   EndTime = DATEADD(ss, [time], @CurrentStepTime)
			  WHERE
				   Number = @CurrentStep;
			  SELECT
				    @CurrentStepTime = EndTime
			  FROM #StepTime
			  WHERE Number = @CurrentStep;
			  SELECT
				    @CurrentStep = @CurrentStep + 1;
		   END;
	    INSERT INTO [TCD].[BatchWashStepData]
	    (
			 BatchID,
			 StepCompartment,
			 StartTime,
			 EndTime,
			 PartitionOn,
			 EcolabWasherId
	    )
	    SELECT
			 @BatchID,
			 Number,
			 StartTime,
			 EndTime,
			 @ShiftStartdate,
			 @EcoLabWasherID
	    FROM #StepTime
	    WHERE Number <= @LastStep;
	    SELECT
			 @MinTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Mimum Temperature';
	    SELECT
			 @MaxTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Maximum Temperature';
	    SELECT
			 @MaxTempStatusParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Max Temperature Status';
	    SELECT
			 @MinTempStatuParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Minimum Temperature Status';
	    SELECT
			 @PHValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH';
	    SELECT
			 @PHStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH Status';
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MinTempParamID
	    )
		   BEGIN
			  IF(@TemperatureMin <> 0
				OR @TemperatureMin <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MinTempParamID,
						  @TemperatureMin,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MaxTempParamID
	    )
		   BEGIN
			  IF(@TemperatureMax <> 0
				OR @TemperatureMax <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MaxTempParamID,
						  @TemperatureMax,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MaxTempStatusParamID
	    )
		   BEGIN
			  IF(@TempMaxStatus <> 0
				OR @TempMaxStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MaxTempStatusParamID,
						  @TempMaxStatus,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MinTempStatuParamID
	    )
		   BEGIN
			  IF(@TempMinStatus <> 0
				OR @TempMinStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MinTempStatuParamID,
						  @TempMinStatus,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF(@PHStatus <> 0
		  OR @PHStatus <> NULL)
		   BEGIN
			  INSERT INTO TCD.BatchParameters
			  (
				    BatchId,
				    EcolabWasherId,
				    ParameterId,
				    ParameterValue,
				    PartitionOn
			  )
			  VALUES
			  (
				    @BatchID,
				    @EcoLabWasherID,
				    @PHStatusParamID,
				    @PHStatus,
				    @ShiftStartdate
			  );
		   END;
	    IF(@PHValue <> 0
		  OR @PHValue <> NULL)
		   BEGIN
			  INSERT INTO TCD.BatchParameters
			  (
				    BatchId,
				    EcolabWasherId,
				    ParameterId,
				    ParameterValue,
				    PartitionOn
			  )
			  VALUES
			  (
				    @BatchID,
				    @EcoLabWasherID,
				    @PHValueParamID,
				    @PHValue,
				    @ShiftStartdate
			  );
		   END;
	    EXEC TCD.ProcessMyControlProductionWaterConsumptionData
		    @BatchID,
		    @VxML,
		    @ShiftStartDate;
	    DROP TABLE #BatchProductData;
	    DROP TABLE #Dosing;
	    DROP TABLE #StepTime;
	    DROP TABLE #TimeStamp;

		--Start water consumption per batch

	SELECT @MeterID=MeterId,@StepComportment=MachineCompartment
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@MachineNumber
   AND mt.CounterNum = 1;


   SELECT @EnergyCount=COUNT(1) FROM TCd.BatchStepWaterUsageData bswud WHERE BatchId =@BatchID AND StepCompartment =@StepComportment AND ActualQuantity=@WaterConsumption1
    IF(@EnergyCount=0)
  BEGIN
  IF(ISNULL(@WaterConsumption1,0)>0  AND ISNULL(@MeterID,0)>0  AND ISNULL(@StepComportment,0)>0)
  BEGIN
   INSERT INTO TCD.BatchStepWaterUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
	  EcolabWasherId
     )
     SELECT
     @BatchID,
     @StepComportment,
     @WaterConsumption1,
     @ShiftStartdate,
	 @EcoLabWasherID
	 END
      END  

	 SELECT @MeterID=MeterId,@StepComportment=MachineCompartment
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@MachineNumber
   AND mt.CounterNum = 2;
SELECT @EnergyCount=COUNT(1) FROM TCd.BatchStepWaterUsageData WHERE BatchId =@BatchID AND StepCompartment =@StepComportment AND ActualQuantity=@WaterConsumption2
 IF(@EnergyCount=0)
  BEGIN
  IF(ISNULL(@WaterConsumption2,0)>0  AND ISNULL(@MeterID,0)>0  AND ISNULL(@StepComportment,0)>0)
  BEGIN
   INSERT INTO TCD.BatchStepWaterUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
	  EcolabWasherId
     )
     SELECT
     @BatchID,
     @StepComportment,
     @WaterConsumption2,
     @ShiftStartdate,
	 @EcoLabWasherID
	 END
      END   
	  --End water consumption per batch
	END;

GO

 IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlTunnelWasherOnlineData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlTunnelWasherOnlineData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ProcessMyControlTunnelWasherOnlineData](
	@ControllerID   INT,
	@xmlTags        XML,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @BatchID                 INT,
			  @WasherID                INT,
			  @EcolabWasherId          INT,
			  @CurrencyCode            VARCHAR(50),
			  @MachineInternalId       INT,
			  @WasherGroupID           INT,
			  @PlantWasherNumber       INT,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @BatchNumber             INT,
			  @TargetTurnTime          INT,
			  @PartitionOn             DATETIME,
			  @BatchStartTime          DATETIME,
			  @ProgramID               INT,
			  @NumberOfCompartments    INT,
			  @TransferSignalId        INT,
			  @BatchShiftId            INT,
			  @compartmentID           INT,
			  @TunnelXML               XML,
			  @TempXML                 XML,
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @CurrentStepComportmentNO INT,
               @CounterNO               INT,
               @MeterID                 INT,
              @ActualQuantity          DECIMAL(10,6),
			  @WasherModuleCount        INT

	    SELECT @TransferSignalId = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Transfer Signal';
	    CREATE TABLE #Batches
	    (
		    BatchNumber   INT,
		    StartDateTime DATETIME
	    );
	    -- SET @compartmentID = 1;

	    SELECT @TempXML = T.c.query('.')
	    FROM @xmlTags.nodes('MyControlTunnel') AS T(c);

	    SELECT @MachineInternalID = T.c.value('@MachineNumber', 'int')
	    FROM @TempXML.nodes('MyControlTunnel') AS T(c);
	    SELECT @EcolabWasherID = EcolabWasherId,
			 @WasherGroupID = Wg.WasherGroupId,
			 @PlantWasherNumber = PlantWasherNumber,
			 @WasherID = ws.WasherId,
			 @CurrencyCode = P.CurrencyCode,
			 @NumberOfCompartments = Mst.NumberofComp
	    FROM TCD.Washer AS Ws
		    INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = Ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.
		    GroupId
		    INNER JOIN TCD.WasherGroupType AS WgT ON WgT.
		    WasherGroupTypeId = Wg.WasherGroupTypeId
		    INNER JOIN TCD.ConduitController AS Ctrl ON Ctrl.
		    ControllerId = Mst.ControllerId
		    INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.
		    EcoLabAccountNumber
	    WHERE Ctrl.ControllerID = @ControllerID
			AND mst.MachineInternalId = @MachineInternalID
			AND Mst.IsTunnel = 1 AND Mst.IsDeleted =0;
	    SET @compartmentID = @NumberOfCompartments;
	    WHILE(@compartmentID <= @NumberOfCompartments
			AND @compartmentID > 0)
		   BEGIN
			  SELECT @TunnelXML = T.c.query('.')
			  FROM @xmlTags.nodes('MyControlTunnel/TunnelData') AS T(c)
			  WHERE T.c.value('@CompartmentNumber', 'INT') =
			  @compartmentID;
			  SELECT @MachineInternalID = T.c.value('@MachineNumber',
			  'int'
										    ),
				    @BatchNumber = T.c.value('@BatchNumber', 'INT'),
				    @BatchStartTime = T.c.value('@StartDateTime',
				    'DateTime'
										 ),
				    @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
				    @Load = T.c.value('@Load', 'Decimal(10,6)'),
				    @NominalLoad = T.c.value('@Nominalload',
				    'Decimal(10,6)'
									   ),
				    @CustomerNumber = T.c.value('@CustomerNumber',
				    'int'
										 ),
				    @PHStatus = T.c.value('@pHStatus', 'int')
			  FROM @TunnelXML.nodes('TunnelData') AS T(c);

			  --Check for valid startdatetime
			IF(@BatchStartTime <='01/01/1900' OR @BatchStartTime > '06/06/2079')
			BEGIN
				return
			END

			  DECLARE @ShiftStartDateTemp TABLE
			  (
				  ShiftId        INT,
				  ShiftName      NVARCHAR(50),
				  ShiftStartdate DATETIME
			  );
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchStartTime
			  SELECT @BatchShiftId = ShiftID,
				    @PartitionOn = ShiftStartdate
			  FROM @ShiftStartDateTemp;
			  IF(@ProgramNumber = 0)
				--OR @BatchNumber = 1)
				 BEGIN
					SELECT @compartmentID = @compartmentID - 1;
					CONTINUE;
				 END;
			  SELECT @ProgramID = ProgramId,
				    @TargetTurnTime = 3600 / (tps.TotalRunTime /
				    @NumberOfCompartments)
			  FROM TCD.TunnelProgramSetup AS tps
			  WHERE tps.WasherGroupId = @WasherGroupID
				   AND tps.is_deleted = 0
				   AND ProgramNumber = @ProgramNumber;
			  INSERT INTO #Batches
			  (BatchNumber,
			   StartDateTime
			  )
				    SELECT @BatchNumber,
						 @BatchStartTime;
			  SELECT @BatchID = NULL;
			  SELECT @BatchID = BatchID
			  FROM TCD.BatchData AS BD
			  WHERE BD.ControllerBatchId = @BatchNumber
				   AND BD.StartDate = @BatchStartTime
				   AND BD.MachineId = @WasherID;
			  --Start Getting InjectionCount,StepCount And ProductCount
			  SELECT @StdInjectionSteps = COUNT(tdpm.
			  TunnelDosingSetupId),
				    @StdWashSteps = COUNT(DISTINCT tds.
				    TunnelDosingSetupId) - COUNT(tdpm.
				    TunnelDosingSetupId)
			  FROM tcd.TunnelDosingProductMapping AS tdpm
				  RIGHT JOIN tcd.TunnelDosingSetup AS tds ON tdpm.
				  TunnelDosingSetupId = tds.TunnelDosingSetupId
			  WHERE tds.GroupId = @WasherGroupID
				   AND tds.ProgramNumber = @ProgramNumber;
			  --End Getting InjectionCount,StepCount And ProductCount
			  --Start-----ProgramMasterID logic for PlantChainProgram
			  SELECT @PlantProgramId = pm.PlantProgramId,
				    @EcolabTextileCategoryId = pm.
				    EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pm.ChainTextileId,
				    @FormulaSegmentId = pm.FormulaSegmentId,
				    @EcolabSaturationId = pm.EcolabSaturationId
			  FROM TCD.ProgramMaster AS pm
			  WHERE pm.ProgramId = @ProgramID
				   AND pm.Is_Deleted = 0;
			  IF(@PlantProgramId <> 0
				OR @PlantProgramId IS NOT NULL)
				 BEGIN
					--Assign value from plantchainprogram table based on plantprogramId
					SELECT @EcolabTextileCategoryId = pcp.
					EcolabTextileCategoryId,
						  @ChainTextileCategoryId = pcp.
						  ChainTextileCategoryId,
						  @FormulaSegmentId = pcp.FormulaSegmentId,
						  @EcolabSaturationId = pcp.
						  EcolabSaturationId
					FROM tcd.PlantChainProgram AS pcp
					WHERE pcp.PlantProgramId = @PlantProgramId
						 AND pcp.Is_Deleted = 0;
				 END;
			  --End-----ProgramMasterID logic for PlantChainProgram
			  IF @BatchID IS NULL
				 BEGIN
					INSERT INTO TCD.BatchData
					(ControllerBatchId,
					 EcolabWasherId,
					 GroupId,
					 MachineInternalId,
					 PlantWasherNumber,
					 StartDate,
					 ProgramNumber,
					 ProgramMasterId,
					 MachineId,
					 ActualWeight,
					 StandardWeight,
					 CurrencyCode,
					 ShiftId,
					 PartitionOn,
					 TargetTurnTime,
					 StdInjectionSteps,
					 StdWashSteps,
					 EcolabTextileCategoryId,
					 ChainTextileCategoryId,
					 FormulaSegmentId,
					 EcolabSaturationId,
					 PlantProgramId
					)
						  SELECT @BatchNumber,
							    @EcolabWasherID,
							    @WasherGroupID,
							    @MachineInternalID,
							    @PlantWasherNumber,
							    @BatchStartTime,
							    @ProgramNumber,
							    @ProgramID,
							    @WasherID,
							    @Load,
							    @NominalLoad,
							    @CurrencyCode,
							    @BatchShiftId,
							    @PartitionOn,
							    @TargetTurnTime,
							    @StdInjectionSteps,
							    @StdWashSteps,
							    @EcolabTextileCategoryId,
							    @ChainTextileCategoryId,
							    @FormulaSegmentId,
							    @EcolabSaturationId,
							    @PlantProgramId;
					SELECT @BatchID = SCOPE_IDENTITY();
					IF(@StdWashSteps > 0
					   OR @StdWashSteps <> NULL)
					    BEGIN
						   INSERT INTO TCD.BatchParameters
						   (BatchId,
						    EcolabWasherId,
						    ParameterId,
						    ParameterValue,
						    PartitionOn
						   )
								SELECT @BatchID,
									  @EcolabWasherId,
									  38,
									  @StdWashSteps,
									  @PartitionOn;
					    END;
					IF @CustomerNumber IS NOT NULL
					    BEGIN
						   IF NOT EXISTS
						   (
							  SELECT 1
							  FROM TCD.BatchCustomerData
							  WHERE BatchID = @BatchID
						   )
							  BEGIN
								 INSERT INTO TCD.BatchCustomerData
								 (BatchId,
								  CustomerID,
								  Weight,
								  PartitionOn,
								  EcolabWasherId
								 )
									   SELECT @BatchID,
											@CustomerNumber,
											@Load,
											@PartitionOn,
											@EcolabWasherId;
							  END;
					    END;
				 END;
			  -- Transfer Signal
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM tcd.WasherReading wr
				 WHERE wr.WasherId = @WasherID
					  AND wr.ParameterId = @TransferSignalId
					  AND wr.DateTimeStamp = @BatchStartTime
			  )
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterId,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TransferSignalId,
							    1,
							    @BatchStartTime,
							    @PartitionOn,
							    @EcolabWasherId
						  UNION ALL
						  SELECT @WasherID,
							    @TransferSignalId,
							    0,
							    @BatchStartTime,
							    @PartitionOn,
							    @EcolabWasherId;
				 END;
			  --Start Updating Batch Wash Step Data	 
			  EXEC TCD.UPDATEBatchWashStepForTunnel
				  @TunnelXML,
				  @WasherID,
				  @BatchID,
				  @BatchStartTime,
				  @PartitionOn,
				  @EcolabWasherId,
				  @compartmentID;
			  --End Updating Batch Wash Step Data	 
			  SELECT @compartmentID = @compartmentID - 1;
		   END;


	 --Start water consumption per step


   CREATE TABLE #WaterConsumptionData
     (
      Number          INT,
      Quantity        DECIMAL(10,6),
     );
     INSERT INTO #WaterConsumptionData
     (Number,
  Quantity
     )
    SELECT T.c.value('@Counter', 'INT') AS Number, --PumpNumber
       T.c.value('@Value', 'DECIMAL(10,6)') AS Quantity --Water Quanity
    FROM @xmlTags.nodes('MyControlTunnel/TunnelData/WaterConsumption') T(C);

  SET @CurrentStepComportmentNO=1;
  WHILE(@CurrentStepComportmentNO<=22)
  BEGIN
   SELECT @MeterID=MeterId,@CounterNO=mt.CounterNum
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@CurrentStepComportmentNO;
   SELECT @ActualQuantity=wc.Quantity
  FROM #WaterConsumptionData wc where wc.Number=@CounterNO
  SELECT @WasherModuleCount=COUNT(1) FROM TCD.WasherModuleOnlineUsageData WHERE WasherId = @WasherID AND StepComportment =@CurrentStepComportmentNO AND ModuleId = @MeterID AND ActualQuantity=@ActualQuantity
  IF(@WasherModuleCount=0)
  BEGIN
  IF(ISNULL(@WasherID,0)>0 AND ISNULL(@MeterID,0)>0 AND ISNULL(@ActualQuantity,0)>0 AND ISNULL(@CurrentStepComportmentNO,0)>0)
  BEGIN
   INSERT INTO TCD.WasherModuleOnlineUsageData
     (WasherId,
      StepComportment,
      ModuleId,
      ActualQuantity,
      TimeStamp,
      EcolabWasherId
     )
     SELECT
     @WasherID,
     @CurrentStepComportmentNO,
     @MeterID,
     @ActualQuantity,
     GETUTCDATE(),
     @EcolabWasherId
      END  

	  END
        SET  @CurrentStepComportmentNO=@CurrentStepComportmentNO+1;
   
  END;
 END;
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlTunnelWasherProdData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlTunnelWasherProdData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ProcessMyControlTunnelWasherProdData](
	@ControllerID   INT,
	@xmlTags        XML,
	@PLCPointer     INT,
	@ReadPointer    INT,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @BatchID                 INT,
			  @WasherID                  INT,
			  @EcolabWasherId            INT,
			  @CurrencyCode              VARCHAR(50),
			  @MachineInternalId         INT,
			  @WasherGroupID             INT,
			  @PlantWasherNumber         INT,
			  @ProgramNumber             INT,
			  @Load                      DECIMAL(10, 2),
			  @NominalLoad               DECIMAL(10, 2),
			  @CustomerNumber            INT,
			  @PHStatus                  INT,
			  @PHValue                   INT,
			  @LFStatus                  INT,
			  @LFValue                   INT,
			  @BatchNumber               INT,
			  @TargetTurnTime            INT,
			  @PartitionOn               DATETIME2,
			  @BatchStartTime            DATETIME2,
			  @BatchEndTime              DATETIME2,
			  @ProgramID                 INT,
			  @NumberOfCompartments      INT,
			  @ProductId                 INT,
			  @CompartmentNum            INT,
			  @EquipmentType             INT,
			  @MinTempParamID            INT,
			  @MaxTempParamID            INT,
			  @TempStatusParamID         INT,
			  @PHValueParamID            INT,
			  @PHStatusParamID           INT,
			  @ConductivityValueParamID  INT,
			  @ConductivityStatusParamID INT,
			  @StdInjectionSteps         INT,
			  @StdWashSteps              INT,
			  @ActualInjSteps            INT,
			  @EcolabTextileCategoryId   INT,
			  @ChainTextileCategoryId    INT,
			  @FormulaSegmentId          INT,
			  @EcolabSaturationId        INT,
			  @PlantProgramId            INT,
			  @PreviousShiftId		    INT,
			  @CurrentShiftId		    INT,
			  @CurrentStepComportmentNO INT,
              @CounterNO                INT,
               @MeterID                 INT,
              @ActualQuantity          DECIMAL(10,6),
			  @BatchStepCount         INT,
			  @EcolabAccountNumber   VARCHAR(100),
			  @AlarmGroupMasterId    INT,
			  @StandardQuantity          DECIMAL(18, 4),
			  @Price                     DECIMAL(18, 4);

	    DECLARE @BatchShiftId INT;
	    DECLARE @ShiftStartDateTemp TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    DECLARE @TunnelXML XML;
	    SELECT @TunnelXML = T.c.query('.')
	    FROM @xmlTags.nodes('MyControlTunnel/TunnelData') T(c)
	    WHERE T.c.value('@CompartmentNumber', 'INT') = 0;

		
	    SELECT @MachineInternalID = T.c.value('@MachineNumber', 'int'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @BatchStartTime = T.c.value('@StartDateTime', 'DateTime'),
			 @BatchEndTime = T.c.value('@EndDateTime', 'DateTime'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@Nominalload', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'int'),
			 @PHStatus = T.c.value('@Phstatus', 'int'),
			 @PHValue = T.c.value('@Phvalue', 'INT'),
			 @LFStatus = T.c.value('@LFStatus', 'INT'),
			 @LFValue = T.c.value('@LFValue', 'INT')
	    FROM @xmlTags.nodes('MyControlTunnel/TunnelData') T(c);

		--Check for valid startdatetime
		IF(@BatchStartTime <='01/01/1900' OR @BatchStartTime > '06/06/2079')
		BEGIN
			return
		END

	    SELECT @EcolabWasherID = Ws.EcolabWasherId,
			 @WasherGroupID = Wg.WasherGroupId,
			 @PlantWasherNumber = PlantWasherNumber,
			 @WasherID = ws.WasherId,
			 @CurrencyCode = P.CurrencyCode,
			 @NumberOfCompartments = Mst.NumberofComp
	    FROM TCD.Washer Ws
		    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.
		    GroupId
		    INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId
		    = Wg.WasherGroupTypeId
		    INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId =
		    Mst.ControllerId
		    INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.
		    EcoLabAccountNumber
	    WHERE Ctrl.ControllerID = @ControllerID
			AND Mst.MachineInternalId = @MachineInternalID
			AND Mst.IsTunnel = 1 AND Mst.IsDeleted=0;
	    SELECT @EcolabWasherID;
	    SELECT @ProgramID = ProgramId,
			 @TargetTurnTime = (3600 / (tps.TotalRunTime /
			 @NumberOfCompartments))
	    FROM TCD.TunnelProgramSetup AS tps
	    WHERE tps.WasherGroupId = @WasherGroupID
			AND tps.is_deleted = 0
			AND ProgramNumber = @ProgramNumber;
	    DELETE FROM @ShiftStartDateTemp;
	    IF(@BatchEndTime IS NOT NULL)
		   BEGIN
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchEndTime
		   END;
	    ELSE
		   BEGIN
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchStartTime
		   END;
	    SELECT @BatchShiftId = ShiftID,
			 @PartitionOn = ShiftStartdate
	    FROM @ShiftStartDateTemp;


	    --Start Getting InjectionCount,StepCount And ProductCount
	    SELECT @StdInjectionSteps = COUNT(tdpm.TunnelDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT tds.TunnelDosingSetupId) -
			 COUNT(tdpm.TunnelDosingSetupId)
	    FROM tcd.TunnelDosingProductMapping tdpm
		    RIGHT JOIN tcd.TunnelDosingSetup tds ON tdpm.
		    TunnelDosingSetupId = tds.TunnelDosingSetupId
	    WHERE tds.GroupId = @WasherGroupID
			AND tds.ProgramNumber = @ProgramNumber;
	    --End Getting InjectionCount,StepCount And ProductCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramID
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT @EcolabTextileCategoryId = pcp. EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp. ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    SELECT @BatchID = NULL;
	    SELECT @BatchID = BatchID
	    FROM TCD.BatchData BD
	    WHERE BD.ControllerBatchId = @BatchNumber
			AND BD.StartDate = @BatchStartTime
			AND BD.MachineId = @WasherID;
	    --AND BD.MachineInternalID = @MachineInternalID
	    IF(@BatchID IS NULL)
		   BEGIN
		   --Start Rollup for previous completed shift
	   IF(CAST(@BatchStartTime as date) < CAST(GETUTCDATE() as date))
	   BEGIN
		  SELECT TOP 1 @PreviousShiftId=ShiftId FROM TCD.BatchData WHERE MachineId=@WasherId ORDER BY StartDate DESC	   
		  SELECT Top 1 @CurrentShiftId = ShiftId from @ShiftStartDateTemp
		  IF(@CurrentShiftId != @PreviousShiftId)
		  BEGIN
			 EXEC TCD.ProductionShiftDataRollup @PreviousShiftId, @RedFlagShiftId OUTPUT
			 IF(@RedFlagShiftId IS NULL)
			 BEGIN
				SET @RedFlagShiftId = @PreviousShiftId
			 END
		  END
	   END
	   --End Rollup for previous completed shift
			  INSERT INTO TCD.BatchData
			  (ControllerBatchId,
			   EcolabWasherId,
			   GroupId,
			   MachineInternalId,
			   PlantWasherNumber,
			   StartDate,
			   EndDate,
			   ProgramNumber,
			   ProgramMasterId,
			   MachineId,
			   ActualWeight,
			   StandardWeight,
			   CurrencyCode,
			   ShiftId,
			   PartitionOn,
			   TargetTurnTime,
			   StdInjectionSteps,
			   StdWashSteps,
			   EcolabTextileCategoryId,
			   ChainTextileCategoryId,
			   FormulaSegmentId,
			   EcolabSaturationId,
			   PlantProgramId,
			   EndDateFormula
			  )
				    SELECT @BatchNumber,
						 @EcolabWasherID,
						 @WasherGroupID,
						 @MachineInternalID,
						 @PlantWasherNumber,
						 @BatchStartTime,
						 @BatchEndTime,
						 @ProgramNumber,
						 @ProgramID,
						 @WasherID,
						 @Load,
						 @NominalLoad,
						 @CurrencyCode,
						 @BatchShiftId,
						 @PartitionOn,
						 @TargetTurnTime,
						 @StdInjectionSteps,
						 @StdWashSteps,
						 @EcolabTextileCategoryId,
						 @ChainTextileCategoryId,
						 @FormulaSegmentId,
						 @EcolabSaturationId,
						 @PlantProgramId,
						 @BatchEndTime;
			  SELECT @BatchID = SCOPE_IDENTITY();
			  IF(@StdWashSteps > 0
				OR @StdWashSteps <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchID,
							@EcolabWasherId,
							38,
							@StdWashSteps,
							@PartitionOn;
			  EXEC TCD.UPDATEBatchWashStepForTunnel
				  @TunnelXML,
				  @WasherID,
				  @BatchID,
				  @BatchStartTime,
				  @PartitionOn,
				  @EcolabWasherId,
				  @NumberOfCompartments;
		   END;
	    IF(@BatchEndTime IS NOT NULL
		  AND @BatchEndTime != '01/01/1900')
		   BEGIN
			  UPDATE TCD.BatchData
			    SET
				   EndDate = @BatchEndTime,
				   ShiftId = @BatchShiftId,
				   PartitionOn = @PartitionOn,
				   EndDateFormula=@BatchEndTime
			  WHERE BATCHID = @BatchID;
		   END;

		      --If the received formula is not configured in enVision then create an alarm 
       IF(@ProgramID is NULL)
       BEGIN
       SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant;
       SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.AlarmGroupMsterVsControllerModelType AGMVCMT
       INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
       WHERE AGMVCMT.AlarmCode = 9000
        INSERT INTO [TCD].[AlarmData] 
           (EcoalabAccountNumber,
           AlarmCode,
           BatchId,
           controllerID,
           StartDate,
           GroupId,
           MachineInternalId,
           ProgramId,   
           IsActive,
           EndDate,
           MachineId,
           AlarmGroupMasterId)
           SELECT
            @ECOLABAccountNumber,
            9000,
            @BatchID,
            @ControllerId,
            @BatchStartTime,
            @WasherGroupID,
            @MachineInternalID,
            @ProgramNumber,
            0,
            @BatchStartTime,
            @WasherId,
            @AlarmGroupMasterId
       END


	    IF(@CustomerNumber IS NOT NULL)
		   BEGIN
			  IF NOT EXISTS
			  (
				 SELECT 1
				 FROM [TCD].[BatchCustomerData]
				 WHERE BatchID = @BatchID
			  )
				 BEGIN
					INSERT INTO [TCD].[BatchCustomerData]
					([BatchId],
					 CustomerID,
					 [Weight],
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @BatchID,
							    @CustomerNumber,
							    @Load,
							    @PartitionOn,
							    @EcolabWasherId;
				 END;
		   END;
	    CREATE TABLE #DosingDetails
	    (
		    Number          INT,
		    Quantity        DECIMAL(10, 6),
		    Point           INT,
		    IsMainEquioment INT
	    );
	    INSERT INTO #DosingDetails
	    (Number,
		Quantity,
		Point,
		IsMainEquioment
	    )
			 SELECT T.c.value('@Number', 'INT') AS Number, --PumpNumber
				   T.c.value('@Quantity', 'Decimal(10,6)') AS Quantity, --Dosing Quanity
				   T.c.value('@Point', 'INT') AS Point, --Dosing point
				   T.c.value('@IsMainEquioment', 'INT') AS
			 IsMainEquioment
			 FROM @xmlTags.nodes('MyControlTunnel/TunnelData/Dose') T(C)
	    ;
	
	    -- Fetching data from cursor
	    DECLARE @MYCURSOR CURSOR;
	    SET @MYCURSOR = CURSOR FAST_FORWARD
	    FOR SELECT Number,
				Quantity,
				Point,
				IsMainEquioment
		   FROM #DosingDetails;
	    DECLARE @Number          INT,
			  @Quantity        DECIMAL(10, 6),
			  @Point           INT,
			  @IsMainEquioment INT;
	    OPEN @MYCURSOR;
	    FETCH NEXT FROM @MYCURSOR INTO @Number,
								@Quantity,
								@Point,
								@IsMainEquioment;
	    WHILE @@FETCH_STATUS = 0
		   BEGIN
			  IF(@IsMainEquioment = 1)
				 BEGIN
					SET @EquipmentType = 2;
				 END;
			  ELSE
				 BEGIN
					SET @EquipmentType = 1;
				 END;
			  SELECT @ProductId = CES.ProductId,
				    @CompartmentNum = TCEVM.CompartmentNumber
			  FROM tcd.ControllerEquipmentSetup CES
				  INNER JOIN TCD.
				  TunnelCompartmentEquipmentValveMapping TCEVM ON CES.
				  ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
			  WHERE CES.ControllerId = @ControllerID
				   AND CES.ControllerEquipmentTypeId = @EquipmentType
				   AND --CES.IsActive=1 AND
				   --CES.WasherGroupNumber=@WasherGroupNum AND
				   TCEVM.DosingPointNumber = @Point
				   AND CES.ControllerEquipmentId = @Number;
				
			 SELECT DISTINCT
				    @StandardQuantity =((Wps.NominalLoad * Wdpm.Quantity) / 100),
				    @Price = (((Wps.NominalLoad * Wdpm.Quantity) / 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID))
			  FROM TCD.Washer WS
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =Mst.GroupId
				  INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
				  INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
				  INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
				  INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON
				  Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
				  INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId = Wdpm.ControllerEquipmentSetupId
				  INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId = Ces.ProductId
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wds.CompartmentNumber = @CompartmentNum
				   AND Wps.Is_Deleted = 0
				   AND Pdm.Is_Deleted = 0;
				
			  IF(@ProductId IS NOT NULL)
				 BEGIN
					INSERT INTO TCD.BatchProductData
					(
						  BatchId,
						  StepCompartment,
						  ActualQuantity,
						  StandardQuantity,
						  Price,
						  [TimeStamp],
						  PartitionOn,
						  EcolabWasherId,
						  ProductId
					)
					SELECT
						  @BatchID,
						  @CompartmentNum,
						  @Quantity,
						  isnull(@StandardQuantity,0),
						  isnull(@Price,0),
						  @BatchEndTime,
						  @PartitionOn,
						  @EcolabWasherID,
						  @ProductId;
				 END;
			  FETCH NEXT FROM @MYCURSOR INTO @Number,
									   @Quantity,
									   @Point,
									   @IsMainEquioment;
		   END;
	    CLOSE @MYCURSOR;
	    DEALLOCATE @MYCURSOR;
	    DROP TABLE #DosingDetails;
	    SELECT @ActualInjSteps = COUNT(DISTINCT StepCompartment)
	    FROM TCD.BatchProductData
	    WHERE BatchId = @BatchID;
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.BatchParameters
		   WHERE ParameterId = 37
			    AND batchid = @BatchID
			    AND @ActualInjSteps > 0
	    )
		   BEGIN
			  IF(@ActualInjSteps > 0
				OR @ActualInjSteps <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchId,
							@EcolabWasherId,
							37,
							@ActualInjSteps,
							@PartitionOn;
		   END;
	    ELSE
		   BEGIN
			  UPDATE TCD.BatchParameters
			    SET
				   ParameterValue = @ActualInjSteps
			  WHERE ParameterId = 37
				   AND batchid = @BatchID;
		   END;
	    SELECT @MinTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Mimum Temperature';
	    SELECT @MaxTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Maximum Temperature';
	    SELECT @TempStatusParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Temperature Status';
	    SELECT @PHValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH';
	    SELECT @PHStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH Status';
	    SELECT @ConductivityValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Conductivity';
	    SELECT @ConductivityStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'LF Status';
	    IF(@PHValue IS NOT NULL)
		   BEGIN
			  --pH Value
			  IF(@PHValue <> 0
				OR @PHValue <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @PHValueParamID,
					   @PHValue,
					   @PartitionOn
				 );

			  --pH Status
			  IF(@PHStatus <> 0
				OR @PHStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @PHStatusParamID,
					   @PHStatus,
					   @PartitionOn
				 );
		   END;
	    IF(@LFValue IS NOT NULL)
		   BEGIN
			  --Conductivity Value
			  IF(@LFValue <> 0
				OR @LFValue <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @ConductivityValueParamID,
					   @LFValue,
					   @PartitionOn
				 );

			  --Conductivity Status
			  IF(@LFStatus <> 0
				OR @LFStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @ConductivityStatusParamID,
					   @LFStatus,
					   @PartitionOn
				 );
		   END;
	    CREATE TABLE #TemperatureDetails
	    (
		    MinimumTemp DECIMAL(10, 2),
		    MaximumTemp DECIMAL(10, 2),
		    TempStatus  DECIMAL(10, 2)
	    );
	    INSERT INTO #TemperatureDetails
	    (MinimumTemp,
		MaximumTemp,
		TempStatus
	    )
			 SELECT T.c.value('@Minimum', 'Decimal(10,2)') AS
			 MinimumTemp,
				   T.c.value('@Maximum', 'Decimal(10,2)') AS
				   MaximumTemp,
				   T.c.value('@Status', 'Decimal(10,2)') AS TempStatus
			 FROM @xmlTags.nodes(
			 'MyControlTunnel/TunnelData/TemperatureData'
							) T(c);
	  
	    -- Fetching data from cursor
	    DECLARE @TEMPCURSOR CURSOR;
	    SET @TEMPCURSOR = CURSOR FAST_FORWARD
	    FOR SELECT MinimumTemp,
				MaximumTemp,
				TempStatus
		   FROM #TemperatureDetails;
	    DECLARE @MinimumTemp DECIMAL(10, 2),
			  @MaximumTemp DECIMAL(10, 2),
			  @TempStatus  DECIMAL(10, 2);
	    OPEN @TEMPCURSOR;
	    FETCH NEXT FROM @TEMPCURSOR INTO @MinimumTemp,
								  @MaximumTemp,
								  @TempStatus;
	    WHILE @@FETCH_STATUS = 0
		   BEGIN	
			  --Minimum Temperature
			  IF(@MinimumTemp <> 0
				OR @MinimumTemp <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @MinTempParamID,
					   @MinimumTemp,
					   @PartitionOn
				 );

			  --Maximum Temperature
			  IF(@MaximumTemp <> 0
				OR @MaximumTemp <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @MaxTempParamID,
					   @MaximumTemp,
					   @PartitionOn
				 );

			  --Temperature Status
			  IF(@TempStatus <> 0
				OR @TempStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @TempStatusParamID,
					   @TempStatus,
					   @PartitionOn
				 );
			  FETCH NEXT FROM @TEMPCURSOR INTO @MinimumTemp,
										@MaximumTemp,
										@TempStatus;
		   END;
	    CLOSE @TEMPCURSOR;
	    DEALLOCATE @TEMPCURSOR;
	    DROP TABLE #TemperatureDetails;
	    UPDATE TCD.BatchWashStepData
		 SET
			EndTime = DATEADD(ss,
						  (SELECT T.c.value('@Time', 'INT')
							 FROM @TunnelXML.nodes('TunnelData/CompartmentTime') T(c)
							 WHERE T.c.value('@CompartmentNo','INT') =
							 (
								SELECT
									  bwsd.StepCompartment
								FROM tcd.BatchWashStepData bwsd
								WHERE bwsd.BatchId = @BatchID
									 AND bwsd.EndTime IS NULL
							 )
						  ),
						  (
							 SELECT
								   bwsd.StartTime
							 FROM tcd.BatchWashStepData bwsd
							 WHERE bwsd.BatchId = @BatchID
								  AND bwsd.EndTime IS NULL
						  ))
	    WHERE
			BatchId = @BatchID
			AND EndTime IS NULL;
   
   --Start water consumption per batch


    CREATE TABLE #WaterConsumptionData
     (
      Number          INT,
      Quantity        DECIMAL(10,6),
     );
     INSERT INTO #WaterConsumptionData
     (Number,
  Quantity
     )
    SELECT T.c.value('@Counter', 'INT') AS Number, --PumpNumber
       T.c.value('@Value', 'DECIMAL(10,6)') AS Quantity --Water Quanity
    FROM @xmlTags.nodes('MyControlTunnel/TunnelData/WaterConsumption') T(C);

  
  SET @CurrentStepComportmentNO=1;

  WHILE(@CurrentStepComportmentNO<=22)
  BEGIN
  
   SELECT @MeterID=MeterId,@CounterNO=mt.CounterNum
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@CurrentStepComportmentNO

    SELECT @ActualQuantity=wc.Quantity
  FROM #WaterConsumptionData wc where wc.Number=@CounterNo
  SELECT @BatchStepCount=COUNT(1) FROM TCD.BatchStepWaterUsageData WHERE BatchId=@BatchID  AND StepCompartment =@CurrentStepComportmentNO AND ActualQuantity=@ActualQuantity 
  IF (@BatchStepCount=0)
  BEGIN
  IF(ISNULL(@BatchID,0)>0  AND ISNULL(@MeterID,0)>0 AND ISNULL(@ActualQuantity,0)>0)
  BEGIN

   INSERT INTO TCD.BatchStepWaterUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
      EcolabWasherId
     )
     SELECT
     @BatchID,
     @CurrentStepComportmentNO,
     @ActualQuantity,
     @PartitionOn,
     @EcolabWasherId
      END 
	  END 
      SET  @CurrentStepComportmentNO=@CurrentStepComportmentNO+1;  
  END;
 END;
Go
  ----------------------------------------------------------DCS Process Mycontrol End----------------------------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetTagManamenetDetails]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetTagManamenetDetails]
END
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [TCD].[GetTagManamenetDetails] 
@ControllerId INT,
@EcolabAccountNumber VARCHAR(100),
@UserId INT

AS
BEGIN 
DECLARE @Active INT = 1,
    @TankModuleTypeId INT,
    @SensorModuleTypeId INT,
    @PumpModuleTypeId INT,
    @LangunageId INT,
    @SplChars VARCHAR(50)   = ' # -',
    @LocaliseValue VARCHAR(200),
    @FactorMultiplier INT,
    @TimeVolumeMultipler INT,
	@ControllerModelId int,
	@ControllerTypeId INT


SELECT @TankModuleTypeId=mty.ModuleTypeId FROM TCD.ModuleType mty WHERE mty.ModuleDescription='Tank'
SELECT @SensorModuleTypeId=mty.ModuleTypeId FROM TCD.ModuleType mty WHERE mty.ModuleDescription='Sensor'
SELECT @PumpModuleTypeId=mty.ModuleTypeId FROM TCD.ModuleType mty WHERE mty.ModuleDescription='Pumps/Valves'
SELECT @LangunageId=p.languageID FROM TCD.Plant p WHERE p.EcolabAccountNumber=@EcolabAccountNumber


 SELECT @TimeVolumeMultipler= CAST(csd.[Value] AS decimal(18,0)) FROM TCD.ControllerSetupData csd 
 INNER JOIN TCD.Field f ON f.Id = csd.FieldId 
 WHERE csd.FieldId IN(SELECT f2.Id FROM TCD.Field f2 WHERE f2.Label LIKE '%OZ/Second Multiplier%') 
    AND csd.ControllerId=@ControllerId 
    AND csd.EcolabAccountNumber=@EcolabAccountNumber 
	AND ISNUMERIC(csd.[Value]) = 1

 SELECT @FactorMultiplier= CAST(csd.[Value] AS decimal(18,0)) FROM TCD.ControllerSetupData csd 
 INNER JOIN TCD.Field f ON f.Id = csd.FieldId 
 WHERE csd.FieldId IN(SELECT f2.Id FROM TCD.Field f2 WHERE f2.Label LIKE '%Factors Multiplier%') 
    AND csd.ControllerId=@ControllerId
    AND csd.EcolabAccountNumber=@EcolabAccountNumber 
	AND ISNUMERIC(csd.[Value]) = 1

SELECT @ControllerModelId=ControllerModelId,@ControllerTypeId=ControllerTypeId FROM tcd.ConduitController cc WHERE ControllerId=@ControllerId


CREATE TABLE #tmpTagManagementDetails
(
  Id INT
 ,TagAddress VARCHAR(100)
 ,[Description] VARCHAR(1000)
 ,Value VARCHAR(500)
 ,LastModifiedTime DATETIME 
 ,ColName VARCHAR(500)
 ,DataType varchar(100)
 ,RowNumber decimal(3,2)
 ,OriginalColumnName varchar(100)
 ,EntityType varchar(100)
 ,TagType varchar(100)
 ,ControllerEquipmentSetupId varchar(100)
 ,SortingOrder varchar(100)
)


--SELECT @LocaleValue=rkv.[Value] FROM TCD.ResourceKeyMaster rkm 
--    INNER JOIN TCD.ResourceKeyValue rkv on rkv.ResourceId = rkm.ResourceId 
--where rkm.[Key] ='FIELD_'+ UPPER(@KeyValue) 
--  AND 
--rkv.languageID=ISNULL((SELECT um.LanguageId FROM TCD.UserMaster um WHERE um.UserId=@UserId),(SELECT p.LanguageId FROM TCD.Plant p WHERE p.EcolabAccountNumber=@EcolabAccountNumber)) 


--------------------------------------
-- StorageTanks---
--------------------------------------

INSERT INTO #tmpTagManagementDetails(Id, TagAddress,    [Description],    [Value],    LastModifiedTime,colName,DataType,RowNumber,OriginalColumnName
	,EntityType,TagType,ControllerEquipmentSetupId,SortingOrder)

----------------------------------------------------------------
-- Conventional-AND-Tunnel(AWEA, EOF, MODE to be displayed)-----
----------------------------------------------------------------
SELECT ms.WasherId, wt.TagAddress,Convert(varchar(100),w.PlantWasherNumber)+' : '+ms.MachineName,Convert(varchar(100), CONVERT(int, w.EndOfFormula)),w.LastModifiedTime ,'EndofFormulaNumber',tt.DataType,1,
'EndOfFormula' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType,ms.MachineInternalId as ControllerEquipmentSetupId, 2 as SortingOrder 
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId) AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_EOF' AND ms.IsTunnel IN (0,1)
UNION

SELECT ms.WasherId, wt.TagAddress,Convert(varchar(100),w.PlantWasherNumber)+' : '+ms.MachineName,Convert(varchar(100), CONVERT(int, (
SELECT	wmm.WasherModeNumber FROM TCD.WasherModeMapping wmm	
				INNER JOIN	tcd.ControllerModelControllerTypeMapping cmctm	ON cmctm.Id	=wmm.ControllerModelControllerTypeMappingId	 
				AND cmctm.ControllerModelId=@ControllerModelId	 
				AND cmctm.ControllerTypeId=@ControllerTypeId 
				AND wmm.WasherModeId=w.WasherMode))),w.LastModifiedTime ,'WasherMode',tt.DataType,1,'WasherMode' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType,ms.MachineInternalId as ControllerEquipmentSetupId, 5 as SortingOrder  
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_MODE' AND ms.IsTunnel IN (0,1)
UNION

SELECT ms.WasherId, wt.TagAddress,Convert(varchar(100),w.PlantWasherNumber)+' : '+ms.MachineName,Convert(varchar(100), CONVERT(int, w.AWEActive)),w.LastModifiedTime ,'AWEActive',tt.DataType,1
,'AWEActive' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType,ms.MachineInternalId as ControllerEquipmentSetupId , 1 as SortingOrder 
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_AWEA' AND ms.IsTunnel IN (0,1)
UNION

SELECT ms.WasherId, wt.TagAddress,Convert(varchar(100),w.PlantWasherNumber)+' : '+ms.MachineName,Convert(varchar(100), CONVERT(int, w.HoldDelay)),w.LastModifiedTime ,'HoldDelay',tt.DataType,1
,'HoldDelay' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType, ms.MachineInternalId as ControllerEquipmentSetupId , 3 as SortingOrder

FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId  AND wt.Active=@Active  AND wt.TagType='Tag_HOLDD' AND ms.IsTunnel=0 
UNION

SELECT ms.WasherId, wt.TagAddress,Convert(varchar(100),w.PlantWasherNumber)+' : '+ms.MachineName,Convert(varchar(100), CONVERT(int, w.WaterFlushTime)),w.LastModifiedTime , 'WaterFlushTime' ,tt.DataType,1
,'WaterFlushTime' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType, ms.MachineInternalId as ControllerEquipmentSetupId, 6 as SortingOrder  
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_FLSHT' AND ms.IsTunnel=0
UNION

SELECT ms.WasherId, wt.TagAddress,Convert(varchar(100),w.PlantWasherNumber)+' : '+ms.MachineName,Convert(varchar(100), CONVERT(int, w.RatioDosingActive)),w.LastModifiedTime, 'RatioDosingActive',tt.DataType,1
,'RatioDosingActive' as OriginalColumnName,'[TCD].[Washer]' as EntityName,tt.TagType as TagType, ms.MachineInternalId as ControllerEquipmentSetupId, 4 as SortingOrder  
FROM TCD.WasherTags wt 
INNER JOIN  TCD.Washer w ON w.WasherId = wt.WasherId
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = wt.WasherId
Inner Join tcd.TagType tt on wt.TagType = tt.TagType
WHERE  wt.WasherId IN (SELECT wt.WasherId FROM TCD.MachineSetup ms2 WHERE ms2.ControllerId=@ControllerId)  AND MS.ControllerId=@ControllerId   AND wt.Active=@Active  AND wt.TagType='Tag_RATA' AND ms.IsTunnel=0

UNION
------------------------------------
---- Tanks---
------------------------------------
SELECT ts.TankId AS Id, mt.TagAddress AS TagAddress,   ts.TankName AS [Description],Convert(varchar(10),Convert(int,( ts.Size))) AS Value,   
ts.LastModifiedTime , 'Size',tt.DataType,1
,'Size-Size_Display' as OriginalColumnName,'[TCD].[TankSetup]' as EntityName,tt.TagType as TagType, 0 as ControllerEquipmentSetupId  , 0 as SortingOrder

FROM   TCD.ModuleTags mt INNER JOIN TCD.TankSetup ts ON ts.TankId=mt.ModuleId
Inner Join tcd.TagType tt on mt.TagType = tt.TagType

WHERE   mt.ModuleTypeId=@TankModuleTypeId    AND ts.ControllerId=@ControllerId     AND mt.Active=@Active    AND mt.TagType='Tag_SIZ' 
UNION

SELECT ts.TankId,mt.TagAddress,ts.TankName,Convert(varchar(100),Convert(int,( ts.LevelDeviation_Display))),ts.LastModifiedTime ,'Dead Band',tt.DataType,1
,'LevelDeviation-LevelDeviation_Display' as OriginalColumnName,'[TCD].[TankSetup]' as EntityName,tt.TagType as TagType, 0 as SortingOrder, 0 as ControllerEquipmentSetupId  

FROM    TCD.ModuleTags mt 
INNER JOIN  TCD.TankSetup ts ON ts.TankId=mt.ModuleId
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE   mt.ModuleTypeId=@TankModuleTypeId 
    AND ts.ControllerId=@ControllerId 
    AND mt.Active=@Active 
    AND mt.TagType='Tag_DEV' 
UNION

----------------------------------------
---- Meter---
----------------------------------------

----------------------------------------
---- Sensor---
----------------------------------------
SELECT s.SensorId,mt.TagAddress,s.[Description],CONVERT(VARCHAR(100),CAST(s.Calibration4mA as float)),s.LastModifiedTime ,'Calibration4mA',tt.DataType,3
,'Calibration4mA' as OriginalColumnName,'[TCD].[Sensor]' as EntityName,tt.TagType as TagType, 0 as ControllerEquipmentSetupId, 0 as SortingOrder  
from TCD.ModuleTags mt INNER JOIN TCD.Sensor s ON MT.ModuleId=s.SensorId 
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE mt.ModuleTypeId=@SensorModuleTypeId AND s.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_SC4'

UNION

SELECT s.SensorId,mt.TagAddress,s.[Description],CONVERT(VARCHAR(100),CAST(s.Calibration20mA as float)),s.LastModifiedTime , 'Calibration20mA',tt.DataType,3
,'Calibration20mA' as OriginalColumnName,'[TCD].[Sensor]' as EntityName,tt.TagType as TagType, 0 as ControllerEquipmentSetupId, 0 as SortingOrder  
from TCD.ModuleTags mt INNER JOIN TCD.Sensor s ON MT.ModuleId=s.SensorId 
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE mt.ModuleTypeId=@SensorModuleTypeId AND s.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_SC20' 
UNION
--------------------------------------
-- Pumps---
--------------------------------------



SELECT  Convert(int, ces.ControllerEquipmentSetupId), mt.TagAddress,'P/V'+Convert(varchar(100), ces.ControllerEquipmentId),
Convert(varchar(100),Convert(float, ces.KFactor * @FactorMultiplier)),ces.LastModifiedTime ,'K-Factor',tt.DataType,2
,'KFactor' as OriginalColumnName,'[TCD].[ControllerEquipmentSetup]' as EntityName,tt.TagType as TagType, ControllerEquipmentId as ControllerEquipmentSetupId, 1 as SortingOrder   

FROM TCD.ModuleTags mt INNER JOIN TCD.ControllerEquipmentSetup ces ON mt.ModuleId=ces.ControllerEquipmentSetupId 
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE mt.ModuleTypeId=@PumpModuleTypeId AND ces.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_PPOL'
UNION
SELECT  Convert(int, ces.ControllerEquipmentSetupId), mt.TagAddress,'P/V'+Convert(varchar(100), ces.ControllerEquipmentId),
Convert(varchar(100),Convert(float, ces.PumpCalibration *@TimeVolumeMultipler)),ces.LastModifiedTime, 'Time Volume Calibration',tt.DataType,2
,'PumpCalibration' as OriginalColumnName,'[TCD].[ControllerEquipmentSetup]' as EntityName,tt.TagType as TagType , ControllerEquipmentId as  ControllerEquipmentSetupId, 3 as SortingOrder 
FROM TCD.ModuleTags mt INNER JOIN TCD.ControllerEquipmentSetup ces ON mt.ModuleId=ces.ControllerEquipmentSetupId
Inner Join tcd.TagType tt on mt.TagType = tt.TagType
WHERE mt.ModuleTypeId=@PumpModuleTypeId AND ces.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_OPSL'
UNION

SELECT Convert(int, ces.ControllerEquipmentSetupId), mt.TagAddress,'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
ces.LfsChemicalName,ces.LastModifiedTime ,'LFS Chemical Name',tt.DataType,2
,'LfsChemicalName' as OriginalColumnName,'[TCD].[ControllerEquipmentSetup]' as EntityName,tt.TagType as TagType, ControllerEquipmentId as ControllerEquipmentSetupId  , 2 as SortingOrder 

FROM TCD.ModuleTags mt INNER JOIN TCD.ControllerEquipmentSetup ces ON mt.ModuleId=ces.ControllerEquipmentSetupId
Inner Join tcd.TagType tt on mt.TagType = tt.TagType 
WHERE mt.ModuleTypeId=@PumpModuleTypeId AND ces.ControllerId=@ControllerId AND mt.Active=@Active AND mt.TagType='Tag_NML' 
UNION

SELECT csd.ControllerId ,ct.TagAddress,NULL,csd.[Value],cc.LastModifiedTime , f.Label,tt.DataType,6
,'Value-'+CAST(csd.FieldId as varchar) as OriginalColumnName,'[TCD].[ControllerSetupData]' as EntityName,tt.TagType as TagType, 0 as ControllerEquipmentSetupId  , 0 as SortingOrder
FROM TCD.ControllerTags ct 
INNER JOIN TCD.ControllerSetupData csd ON csd.ControllerId = ct.ControllerId
INNER JOIN tcd.Field f ON f.Id = csd.FieldId AND ct.TagType=f.HasFieldTag
INNER JOIN TCD.ConduitController cc ON cc.ControllerId = ct.ControllerId
Inner Join tcd.TagType tt on ct.TagType = tt.TagType
WHERE ct.ControllerId=@ControllerId AND ct.Active=@Active

UNION

SELECT ces.ControllerEquipmentSetupId,
	   'stMachineConfig.xFlowSwitchType['+cast(ControllerEquipmentId AS varchar(20))+']' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  cast( FlowDetectorType AS varchar(20)) AS Value, 
	   ces.LastModifiedTime,
	   'Flow Detector Type' AS Lable,
	   'BIT' As DataType ,
	   2.1,
	   'FlowDetectorType' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stMachineConfig.xFlowSwitchType' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 5 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3


UNION --Flow Switch Alarm
SELECT ces.ControllerEquipmentSetupId,
	   'stMachineConfig.xFlowAlarmOverride['+cast(ControllerEquipmentId AS varchar(20))+']' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  Cast( ces.FlowSwitchAlarm  AS varchar(20)) AS Value, 
	   ces.LastModifiedTime,
	   'Flow Switch Alarm' AS Lable,
	   'BIT' As DataType ,
	   2.2,
	   'FlowSwitchAlarm' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stMachineConfig.xFlowAlarmOverride' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId , 10 as SortingOrder 
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3
UNION --Flow Meter Alarm
SELECT ces.ControllerEquipmentSetupId,
	   'stMachineConfig.xFlowMeterAlarmOverride['+cast(ControllerEquipmentId AS varchar(20))+']' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	 cast(  ces.FlowMeterAlarm  AS varchar(20)) AS Value, 
	   ces.LastModifiedTime,
	   'Flow Meter Alarm' AS Lable,
	   'BIT' As DataType ,
	   2.3,
	   'FlowMeterAlarm' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stMachineConfig.xFlowMeterAlarmOverride' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 6 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3
UNION --Flow Meter Type
     
SELECT ces.ControllerEquipmentSetupId,
	   'stPumpConfig['+cast(ControllerEquipmentId AS varchar(20))+'].eFlowMeterMode' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  cast( ces.FlowMeterType  AS varchar(20))  AS Value, 
	   ces.LastModifiedTime,
	   'Flow Meter Type' AS Lable,
	   'INT' As DataType ,
	   2.4,
	   'FlowMeterType' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stPumpConfig.eFlowMeterMode' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 9 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3

UNION --Flow Alarm Delay Time
SELECT ces.ControllerEquipmentSetupId,
	   'stPumpConfig['+cast(ControllerEquipmentId AS varchar(20))+'].fLossOfFlowDuration' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  cast( ces.FlowAlarmDelay  AS varchar(20))  AS Value, 
	   ces.LastModifiedTime,
	   'Flow Alarm Delay Time' AS Lable,
	   'FLOAT' As DataType ,
	   2.5,
	   'FlowAlarmDelay' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stPumpConfig.fLossofFlowDuration' TagType, ces.ControllerEquipmentId  as ControllerEquipmentSetupId, 4 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3
UNION --Flow Meter Pump Delay
SELECT ces.ControllerEquipmentSetupId,
	   'stPumpConfig['+cast(ControllerEquipmentId AS varchar(20))+'].fTdFlowMeter' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  cast( ces.FlowMeterPumpDelay  AS varchar(20))  AS Value, 
	   ces.LastModifiedTime,
	   'Flow Meter Pump Delay' AS Lable,
	   'FLOAT' As DataType ,
	   2.6,
	   'FlowMeterPumpDelay' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stPumpConfig.fTdFlowMeter' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 8 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3

UNION -- Flow Meter Alarm Delay
SELECT ces.ControllerEquipmentSetupId,
	   'stPumpConfig['+cast(ControllerEquipmentId AS varchar(20))+'].fTAlarmDelayFlowMeter' as TagAddress,
	   'P/V'+ Convert(varchar(100), ces.ControllerEquipmentId),
	  cast( ces.FlowMeterAlarmDelay  AS varchar(20))  AS Value, 
	   ces.LastModifiedTime,
	   'Flow Meter Alarm Delay' AS Lable,
	   'FLOAT' As DataType ,
	   2.7,
	   'FlowMeterAlarmDelay' AS OriginalColumnName ,
	   '[TCD].[ControllerEquipmentSetup]' EntityType,
    'stPumpConfig.fTAlarmDelayFlowMeter' TagType, ces.ControllerEquipmentId as ControllerEquipmentSetupId, 7 as SortingOrder  
FROM tcd.ControllerEquipmentSetup ces
WHERE ces.ControllerId=@ControllerId AND ces.IsActive=@Active AND @ControllerModelId=3



SELECT  ttmd.Id  
   ,ttmd.TagAddress  
   ,isnull(ttmd.[Description],'')
   ,ttmd.Value  
   ,ttmd.LastModifiedTime  
   ,ttmd.ColName
   ,ttmd.DataType
   ,ttmd.OriginalColumnName
	,ttmd.EntityType 
	,ttmd.TagType,ttmd.SortingOrder,ttmd.ControllerEquipmentSetupId  FROM dbo.#tmpTagManagementDetails ttmd WHERE ttmd.[Value] IS  NOT NULL AND ttmd.[Value]<> '' ORDER BY ttmd.RowNumber

END
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetBatchByGroupId]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetBatchByGroupId]
END
GO
CREATE PROCEDURE [TCD].[GetBatchByGroupId] 
(
    @GroupId        NVARCHAR(1000)        =   NULL
  , @MachineId        INT                 =   NULL
  , @ProgramId       INT                 =   NULL
  , @StartDate        DATETIME            =   NULL
  , @RowsPerPage INT =50
  , @PageNumber INT = 1
  ,	@EndDate	DATETIME            =   NULL
)
AS 
/*
-- Usage
EXEC [TCD].[GetBatchByGroupId] @GroupId =   NULL
  , @MachineId = 1
  , @ProgramId = 54
  , @StartDate = '2014-06-06'
  , @RowsPerPage = 50
  , @PageNumber = 3


*/

  BEGIN
  SET NOCOUNT ON

	if(@ProgramId = 0)      
    BEGIN      
    set @ProgramId = null      
    END    
    
   IF @PageNumber < 1 
    SET @PageNumber = 1 

   SELECT --TOP 10 
   bd.BatchId,
   CAST(StartDate AS datetime) AS StartDate,
   COALESCE(bd.ManualInputWeight,bd.ActualWeight), 
   bd.ProgramNumber,
   pm.Name,
  Count(*) Over() TotalRows ,  
  bd.EcolabWasherId
   FROM [TCD].BatchData bd
   INNER JOIN tcd.ProgramMaster pm ON pm.ProgramId = bd.ProgramMasterId
   WHERE 
 --   bd.GroupId           IN     (SELECT cast(items as int) FROM [TCD].[CharacterListToTable] (@GroupId, ','))
     bd.MachineId        =     @MachineId
   AND   bd.ProgramNumber   =    COALESCE(@ProgramId, bd.ProgramNumber ) -- (SELECT cast(items as int) FROM [TCD].[CharacterListToTable] (@ProgramId, ','))
   AND bd.[StartDate]       >=     @StartDate
  AND  bd.[StartDate]    <= ISNULL(@EndDate, GETUTCDATE())
   ORDER BY bd.BatchId
   OFFSET (@PageNumber-1)*@RowsPerPage ROWS
   FETCH NEXT @RowsPerPage ROWS ONLY

 SET NOCOUNT OFF
  END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetWasherGroupFormula]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetWasherGroupFormula]
END
GO
CREATE	PROCEDURE    [TCD].[GetWasherGroupFormula]
                     @EcoLabAccountNumber						NVARCHAR(25)
                ,    @WasherGroupId								INT
                ,    @ProgramSetupId                            INT                =		NULL            --Null for LIST
                ,    @Is_Deleted                                BIT                =		'FALSE'
AS
BEGIN

SET    NOCOUNT    ON

DECLARE
         @WasherGroupNumber							VARCHAR(10)				=    NULL
    ,    @WasherGroupName							NVARCHAR(50)			=    NULL
    ,    @WasherGroupTypeName						VARCHAR(30)				=    NULL
    ,    @NextAvailableStepNo						INT						=    NULL
    ,    @NextAvailableFormulaNo                    INT						=    NULL
    ,    @MyServiceMchGrpGuid						UNIQUEIDENTIFIER		=	 NULL
    ,    @MaxInjectionsCount                        INT						=	 0
    ,    @CanAddInjections							BIT						=	 0
    ,    @ReferenceLoad								INT						=	 0
    ,	 @ControllerID								INT						=	 NULL
    ,	 @ControllerModelID							INT						=	 NULL


CREATE TABLE #SetupDataTemp
(
     val varchar(32) not null
);

SELECT	
			@WasherGroupTypeName			=            WGT.WasherGroupTypeName
    ,		@WasherGroupNumber				=            WG.WasherGroupNumber
    ,		@WasherGroupName				=            WG.WasherGroupName
    ,		@MyServiceMchGrpGuid			=            GT.MyServiceCustMchGrpGuid
	FROM	[TCD].WasherGroup						WG (NOLOCK)
JOIN		[TCD].WasherGroupType					WGT (NOLOCK)
    ON		WG.WasherGroupTypeId			=			 WGT.WasherGroupTypeId
JOIN		[TCD].MachineGroup						GT (NOLOCK)
    ON		WG.WasherGroupId				=			 GT.Id
AND			WG.EcolabAccountNumber			=			 GT.EcolabAccountNumber
	WHERE   GT.EcolabAccountNumber			=            @EcoLabAccountNumber
AND			WG.WasherGroupId				=            @WasherGroupId

SELECT		@ControllerID			=		wg.ControllerId 
	FROM	TCD.WasherGroup			wg
	WHERE   wg.WasherGroupId		=		@WasherGroupId
AND			wg.EcolabAccountNumber	=		@EcoLabAccountNumber

SELECT		@ControllerModelID		=		cc.ControllerModelId
	FROM	TCD.ConduitController	cc
	WHERE	cc.ControllerId			=		@ControllerID
AND			cc.EcoalabAccountNumber =		@EcoLabAccountNumber

IF    (@WasherGroupTypeName			=	    'Tunnel')  --Tunnel/Washer Formula
	BEGIN
                     
			SELECT @NextAvailableFormulaNo = ISNULL(MAX(ProgramNumber), 0) + 1 FROM [TCD].TunnelProgramSetup 
			WHERE 
			WasherGroupId=@WasherGroupId 
			AND 
			Is_Deleted=0
			AND 
            EcolabAccountNumber    = @EcoLabAccountNumber        
		
			SELECT
					@WasherGroupNumber					AS			WasherGroupNumber
				,	@WasherGroupName					AS			WasherGroupName
				,	@WasherGroupTypeName				AS			WasherGroupTypeName
				,	TPS.TunnelProgramSetupId			AS			ProgramSetupId
				,	TPS.ProgramNumber					AS			ProgramNumber
				,	TPS.ProgramId						AS			ProductId
				,	PM.Name								AS			ProductName
				,	TPS.NominalLoad						AS			NominalLoad
				,	SUM(TDS.StepRunTime)				AS			TotalRunTime
				,	TPS.ExtraTime						AS			ExtraTime
				,	TPS.LoadsPerMonth					AS			LoadsPerMonth
				,	0									AS			NextAvailableStepNo
				,	TPS.LastModifiedTime				AS			LastModifiedTime
				,	TPS.LastSyncTime					AS			LastSyncTime
				,   TPS.EcolabAccountNumber				AS			EcolabAccountNumber 
				,	TPS.WasherGroupId					AS			WasherGroupId
				,	@NextAvailableFormulaNo				AS			NextAvailableFormulaNo
				,	TPS.MyServiceCustFrmulaMchGrpGUID	AS			MyServiceCustFrmulaMchGrpGUID
				,	TPS.Is_Deleted						AS			Is_Deleted
				,	(CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN ETC.MyServiceMstrLnnTypId 
					   ELSE cp.MyServiceEcolabTextileCategoryId END) AS MyServiceMstrLnnTypId
				,	@MyServiceMchGrpGuid				AS			MyServiceMchGrpGuid
				,	@MaxInjectionsCount					AS			MaxInjectionsCount
				,	@CanAddInjections					AS			CanAddInjections
				,	TPS.MyServiceLastSynchTime			AS			MyServiceLastSynchTime
				,	@ReferenceLoad						AS			ReferenceLoad
				,	(SELECT COUNT(DISTINCT tds.TunnelDosingSetupId) FROM TCD.TunnelDosingSetup tds
							INNER JOIN TCD.TunnelDosingProductMapping tdpm
							ON tdpm.TunnelDosingSetupId = tds.TunnelDosingSetupId
							AND tdpm.EcoLabAccountNumber = tds.EcolabAccountNumber
							INNER JOIN TCD.WasherGroup wg 
							ON wg.WasherGroupId = TPS.WasherGroupId
							AND wg.EcolabAccountNumber = TPS.EcolabAccountNumber
							INNER JOIN TCD.MachineSetup ms
							ON ms.GroupId = wg.WasherGroupId
							AND ms.EcoalabAccountNumber = wg.EcolabAccountNumber
							INNER JOIN TCD.TunnelCompartment tc
							ON tc.EcoLabAccountNumber = ms.EcoalabAccountNumber
							AND tc.WasherId = ms.WasherId
							INNER JOIN TCD.TunnelCompartmentEquipmentMapping tcem
							ON tcem.EcoLabAccountNumber = tc.EcoLabAccountNumber
							AND tcem.ControllerEquipmentSetupId = tdpm.ControllerEquipmentSetupId
							AND tc.TunnelCompartmentId = tcem.TunnelCompartmentId
							AND tcem.Is_Deleted = 'False'
							WHERE wg.WasherGroupId = @WasherGroupId
							AND wg.EcolabAccountNumber = @EcoLabAccountNumber
							AND tds.TunnelProgramSetupId = TPS.TunnelProgramSetupId) AS WashStepCount ,
					@ControllerID as ControllerID
					,@ControllerModelID as ControllerModelID
				,   (CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN ES.MyServiceMstrLnnTypId
					   ELSE cp.MyServiceEcolabSaturationId END) AS MyServiceSaturationTypeId
			FROM	[TCD].TunnelProgramSetup			TPS (NOLOCK)
			JOIN	[TCD].ProgramMaster					PM (NOLOCK)
				ON	TPS.ProgramId						=			PM.ProgramId
				AND PM.EcolabAccountNumber				=			TPS.EcolabAccountNumber
			LEFT JOIN TCD.EcolabTextileCategory		ETC  (NOLOCK)
				ON	PM.EcolabTextileCategoryId			=			ETC.TextileId
			LEFT JOIN TCD.EcolabSaturation			ES (NOLOCK)
				ON	PM.EcolabSaturationId				=			ES.EcolabSaturationId
		     LEFT JOIN TCD.ChainPrograms cp
				ON cp.PlantProgramId = pm.PlantProgramId AND pm.EcolabAccountNumber = cp.EcolabAccountNumber 
			LEFT JOIN [TCD].TunnelDosingSetup TDS (NOLOCK) 
                ON    TDS.TunnelProgramSetupId				=            TPS.TunnelProgramSetupId
                AND   TDS.EcolabAccountNumber               =            TPS.EcolabAccountNumber
                AND   (TDS.Is_Deleted						=            'FALSE' OR TDS.Is_Deleted = @Is_Deleted)
            WHERE     TPS.EcolabAccountNumber				=            @EcoLabAccountNumber
                AND   TPS.WasherGroupId						=            @WasherGroupId
                AND   TPS.TunnelProgramSetupId				=            ISNULL(@ProgramSetupId, TPS.TunnelProgramSetupId)
                AND   (TPS.Is_Deleted						=            'FALSE' OR TPS.Is_Deleted = @Is_Deleted)

			GROUP BY 
				TPS.TunnelProgramSetupId
				,TPS.ProgramNumber
				,TPS.ProgramId
				,PM.Name
				,TPS.NominalLoad
				,TPS.ExtraTime
				,TPS.LoadsPerMonth
				,TPS.LastModifiedTime
				,TPS.LastSyncTime
				,TPS.EcolabAccountNumber
				,TPS.WasherGroupId
				,TPS.MyServiceCustFrmulaMchGrpGUID
				,TPS.Is_Deleted
				,ETC.MyServiceMstrLnnTypId
				,TPS.MyServiceLastSynchTime
				,pm.PlantProgramId
				,cp.MyServiceEcolabSaturationId
				,ES.MyServiceMstrLnnTypId
				,cp.MyServiceEcolabTextileCategoryId


	END
ELSE    --Conventional/Washer Formula
	BEGIN

    IF @ControllerModelID > 7 OR @ControllerModelID NOT IN( 12, 13) 
    BEGIN
		SET @MaxInjectionsCount = 20
    END
    ELSE
    BEGIN
        

		WITH InjectValues (Value)
AS
(
        SELECT
            csd.[Value]
            FROM TCD.ControllerSetupData            AS        csd
             INNER JOIN TCD.ConduitController        AS        cc(NOLOCK)ON cc.ControllerId = csd.ControllerId
                    AND cc.EcoalabAccountNumber        =        csd.EcolabAccountNumber
             INNER JOIN TCD.FieldGroup                AS        fg ON fg.ControllerModelId = cc.ControllerModelId
                    AND fg.ControllerTypeId            =        cc.ControllerTypeId
             INNER JOIN TCD.FieldGroupFieldMapping    AS        fgfm ON fgfm.FieldGroupId = fg.Id
             INNER JOIN TCD.Field                    AS        f ON f.Id = fgfm.FieldId
                    AND f.ResourceKey                =        'Max_Formula_Injections'
                    AND csd.FieldId                    =        f.Id
             INNER JOIN TCD.MachineSetup            AS        ms(NOLOCK)ON ms.ControllerId = cc.ControllerId
                    AND cc.EcoalabAccountNumber        =        ms.EcoalabAccountNumber
             INNER JOIN TCD.WasherGroup                AS        wg(NOLOCK)ON wg.WasherGroupId = ms.GroupId
                    AND wg.EcolabAccountNumber        =        ms.EcoalabAccountNumber
            WHERE wg.WasherGroupId                    =        @Washergroupid
              AND ms.IsDeleted                        =        'False'
              AND wg.EcolabAccountNumber            =        @Ecolabaccountnumber
)
        INSERT INTO #SetupDataTemp  SELECT iv.[Value] FROM InjectValues iv
        
SELECT @MaxInjectionsCount = MIN(CAST(t.val AS INT)) FROM #SetupDataTemp t 

DROP TABLE #SetupDataTemp
    END
			
			DECLARE @MaxInjectionsNumber INT = 0
			
			SELECT  @MaxInjectionsNumber =  ISNULL(MAX(wdpm.InjectionNumber),0) FROM TCD.WasherDosingProductMapping wdpm (NOLOCK) 
                INNER JOIN TCD.WasherDosingSetup wds (NOLOCK) ON wds.WasherDosingSetupId = wdpm.WasherDosingSetupId 
				AND wds.EcoLabAccountNumber = wdpm.EcoLabAccountNumber
							WHERE wds.WasherProgramSetupId = @ProgramSetupId AND wds.EcoLabAccountNumber = @EcoLabAccountNumber
								AND wds.Is_Deleted = 0 AND wdpm.IsDeleted=0

			IF @MaxInjectionsNumber < @MaxInjectionsCount
			BEGIN
                SET @CanAddInjections    =    1
			END


			SELECT @NextAvailableStepNo = ISNULL(MAX(StepNumber), 0) + 1 FROM [TCD].WasherDosingSetup WDS (NOLOCK)
			WHERE 
            WDS.EcolabAccountNumber    = @EcoLabAccountNumber
			AND
			WDS.WasherProgramSetupId = @ProgramSetupId
			AND 
			Is_Deleted = 'FALSE'
            
			IF @ControllerModelID = 7 -- MyControl
			BEGIN
				SET @WasherGroupId = NULL
			END
			
			SELECT @NextAvailableFormulaNo = ISNULL(MAX(ProgramNumber), 0) + 1 FROM [TCD].WasherProgramSetup (NOLOCK) 
			WHERE 
            (CASE WHEN @WasherGroupId IS NOT NULL 
						  THEN WasherGroupId
						  ELSE ControllerID
					END)									= (CASE WHEN @WasherGroupId IS NOT NULL 
																	THEN @WasherGroupId
																	ELSE @ControllerID
																	END)
			AND 
			Is_Deleted=0
			AND EcolabAccountNumber = @EcoLabAccountNumber

			 SELECT @ReferenceLoad = MAX(i.ReferenceLoad) FROM	 TCD.Injection i (NOLOCK) 
				    INNER JOIN TCD.WasherGroup wg (NOLOCK) ON wg.WasherGroupNumber = i.WasherGroupNumber AND wg.EcolabAccountNumber = i.EcolabAccountNumber 
				    INNER JOIN TCD.MachineSetup ms (NOLOCK) ON ms.GroupId=wg.WasherGroupId AND ms.EcoalabAccountNumber=wg.EcolabAccountNumber AND ms.IsDeleted=0
				    INNER JOIN TCD.Washer w (NOLOCK) ON w.WasherId = ms.WasherId AND w.EcoLabAccountNumber=ms.EcoalabAccountNumber AND w.Is_Deleted=0
				    WHERE I.WasherGroupNumber IN (SELECT WasherGroupNumber FROM TCD.WasherGroup wg WHERE 
					(CASE WHEN @WasherGroupId IS NOT NULL 
						  THEN WG.WasherGroupId
						  ELSE WG.ControllerId
					END)									= (CASE WHEN @WasherGroupId IS NOT NULL 
																	THEN @WasherGroupId
																	ELSE @ControllerID
																	END) 
					AND wg.EcolabAccountNumber = @EcoLabAccountNumber) 
					    AND i.EcolabAccountNumber=@EcoLabAccountNumber

			SELECT
                     @WasherGroupNumber						AS            WasherGroupNumber
                ,    @WasherGroupName						AS            WasherGroupName
                ,    @WasherGroupTypeName					AS            WasherGroupTypeName
                ,    WPS.WasherProgramSetupId				AS            ProgramSetupId
                ,    WPS.ProgramNumber						AS            ProgramNumber
                ,    WPS.ProgramId							AS            ProductId
                ,    PM.Name                                AS            ProductName
                ,    WPS.NominalLoad                        AS            NominalLoad
                ,    SUM(WDS.StepRunTime)					AS            TotalRunTime
                ,    WPS.ExtraTime							AS            ExtraTime
                ,    WPS.LoadsPerMonth						AS            LoadsPerMonth
                ,    @NextAvailableStepNo					AS            NextAvailableStepNo
                ,    WPS.LastModifiedTime					AS            LastModifiedTime
                ,    WPS.LastSyncTime						AS            LastSyncTime
                ,    WPS.EcolabAccountNumber                AS            EcolabAccountNumber 
                ,    WPS.WasherGroupId						AS            WasherGroupId
                ,    @NextAvailableFormulaNo                AS            NextAvailableFormulaNo
                ,    WPS.MyServiceCustFrmulaMchGrpGUID		AS            MyServiceCustFrmulaMchGrpGUID
                ,    WPS.Is_Deleted							AS            Is_Deleted
                ,	(CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN ETC.MyServiceMstrLnnTypId 
				ELSE cp.MyServiceEcolabTextileCategoryId END) AS MyServiceMstrLnnTypId
                ,    @MyServiceMchGrpGuid					AS            MyServiceMchGrpGuid
                ,    @MaxInjectionsCount                    AS            MaxInjectionsCount
                ,    @CanAddInjections						AS            CanAddInjections
                ,    WPS.MyServiceLastSynchTime				AS            MyServiceLastSynchTime
                ,    @ReferenceLoad							AS            ReferenceLoad
                ,    (Select Count(DISTINCT WDS.WasherDosingSetupId) FROM [TCD].WasherDosingSetup WDS
                      INNER JOIN TCD.WasherDosingProductMapping WDPM
                      ON WDS.WasherDosingSetupId = WDPM.WasherDosingSetupId 
                      AND WDS.EcoLabAccountNumber = WDPM.EcoLabAccountNumber
                      AND WDPM.IsDeleted = 'FALSE'
                      WHERE WDS.WasherProgramSetupId = WPS.WasherProgramSetupId AND WDS.Is_Deleted = 'FALSE' AND WDS.EcoLabAccountNumber = @EcoLabAccountNumber) AS WashStepCount
			,	@ControllerID as ControllerID
			,	@ControllerModelID as ControllerModelID
			,	(CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN ES.MyServiceMstrLnnTypId
				ELSE cp.MyServiceEcolabSaturationId END) AS MyServiceSaturationTypeId
			FROM	[TCD].WasherProgramSetup			WPS (NOLOCK)
			JOIN	[TCD].ProgramMaster					PM (NOLOCK)			
				ON	WPS.ProgramId						=			PM.ProgramId
			LEFT JOIN TCD.EcolabTextileCategory		ETC (NOLOCK)
				ON	PM.EcolabTextileCategoryId			=			ETC.TextileId
		     LEFT JOIN TCD.EcolabSaturation			ES (NOLOCK)
				ON	PM.EcolabSaturationId				=			ES.EcolabSaturationId
		     LEFT JOIN TCD.ChainPrograms cp
				ON cp.PlantProgramId = pm.PlantProgramId AND pm.EcolabAccountNumber = cp.EcolabAccountNumber 
			LEFT JOIN [TCD].WasherDosingSetup WDS (NOLOCK) ON WDS.WasherProgramSetupId = WPS.WasherProgramSetupId
			AND (WDS.Is_Deleted					=			'FALSE' OR WDS.Is_Deleted = @Is_Deleted)
			WHERE	
			WPS.EcolabAccountNumber			=			@EcoLabAccountNumber
			 AND		(CASE WHEN @WasherGroupId IS NOT NULL 
						  THEN WPS.WasherGroupId
						  ELSE WPS.ControllerID
					END)									= (CASE WHEN @WasherGroupId IS NOT NULL 
																	THEN @WasherGroupId
																	ELSE @ControllerID
																	END)
			AND	
			WPS.WasherProgramSetupId		=			ISNULL(@ProgramSetupId, WPS.WasherProgramSetupId)
			AND	
			(WPS.Is_Deleted					=			'FALSE' OR WPS.Is_Deleted = @Is_Deleted)
			
			GROUP BY 
				WPS.WasherProgramSetupId
				,WPS.ProgramNumber
				,WPS.ProgramId
				,PM.Name
				,WPS.NominalLoad
				,WPS.ExtraTime
				,WPS.LoadsPerMonth
				,WPS.LastModifiedTime
				,WPS.LastSyncTime
				,WPS.EcolabAccountNumber
				,WPS.WasherGroupId
				,WPS.MyServiceCustFrmulaMchGrpGUID
				,WPS.Is_Deleted
				,ETC.MyServiceMstrLnnTypId
				,WPS.MyServiceLastSynchTime
				,pm.PlantProgramId
				,cp.MyServiceEcolabSaturationId
				,ES.MyServiceMstrLnnTypId
				,cp.MyServiceEcolabTextileCategoryId
	END

SET    NOCOUNT    OFF

END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[SaveTunnelCompartmentEquipmentValveMapping]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[SaveTunnelCompartmentEquipmentValveMapping]
END
GO
SET ANSI_NULLS ON
GO
CREATE PROC [TCD].[SaveTunnelCompartmentEquipmentValveMapping] (
  @lineCompartmentMappings TCD.TunnelCompartmentEquipmentValveMapping READONLY
    , @ControllerEquipmentId INT
    , @ControllerId INT
    , @LineNumber TINYINT
    , @EcolabAccountNumber NVARCHAR(25)
    , @UserId INT
)
AS
BEGIN
    DECLARE
     @ControllerModelId INT,
     @ControllerTypeId INT;
    (SELECT TOP 1 @ControllerModelId = CC.ControllerModelId
    , @ControllerTypeId = CC.ControllerTypeId
   FROM tcd.ConduitController CC
   WHERE ControllerId = @ControllerId);
    DECLARE
     @EquipmentSetupId INT = (SELECT TOP 1 CES.ControllerEquipmentSetupId
        FROM TCD.ControllerEquipmentSetup CES
        WHERE CES.ControllerId = @ControllerId
          AND CES.ControllerEquipmentId = @ControllerEquipmentId ),
     @PlantId INT = (SELECT TOP 1 PlantId
       FROM TCD.Plant P
       WHERE P.EcolabAccountNumber = @EcolabAccountNumber),
     @DDFlag BIT = CAST(
     CASE
     WHEN EXISTS(SELECT 1
       FROM @lineCompartmentMappings M
       WHERE M.DirectDosingFlag = 1) THEN 1
     ELSE 0
     END
     AS BIT);

    /* Delete the values if not necessary */

    IF @DDFlag = 'TRUE'
    BEGIN
    DELETE FROM TCD.TunnelCompartmentEquipmentValveMapping
      WHERE ControllerEquipmentSetupID = @EquipmentSetupId
    END;
    ELSE
    BEGIN

    /* Validation of max 20 Valves per Tunnel */

    /* Looping for two Machine internal Ids*/

    DECLARE
     @TunnelCount INT = (SELECT TOP 1 CMCTM.NumOfTunnelWasherGroups
           FROM TCD.ControllerModelControllerTypeMapping CMCTM
           WHERE CMCTM.ControllerModelId = @ControllerModelId
         AND CMCTM.ControllerTypeId = @ControllerTypeId);
    DECLARE
     @MaxValveCount INT = CASE
          WHEN @ControllerModelId IN (7, 8) THEN 20
          WHEN @ControllerModelId = 9 THEN 12
          END;
 
    
    IF (SELECT  COUNT(*)
      FROM TCD.TunnelCompartmentEquipmentValveMapping TCEVM
       JOIN
       TCD.ControllerEquipmentSetup CES ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupID
      WHERE CES.ControllerId = @ControllerId
        AND TCEVM.DirectDosingFlag = 'FALSE'
        AND CES.ControllerEquipmentId != @ControllerEquipmentId
        )
       +
       (SELECT COUNT(*)
      FROM @lineCompartmentMappings LCM
      ) > @MaxValveCount
        BEGIN
        RAISERROR ('8014', 16, 1);
        DECLARE
         @ReturnValue INT = -1;
        RETURN @ReturnValue;
        END;
    
    
    DELETE T
      FROM TCD.TunnelCompartmentEquipmentValveMapping T
      WHERE T.ControllerEquipmentSetupID = @EquipmentSetupId
    AND T.PlantID = @PlantId
    AND T.TunnelCompartmentEquipmentValveMappingID NOT IN(
    SELECT TCEVM.TunnelCompartmentEquipmentValveMappingID
      FROM TCD.TunnelCompartmentEquipmentValveMapping TCEVM
       INNER JOIN
       @lineCompartmentMappings M ON TCEVM.TunnelNumber = M.TunnelNumber
             AND TCEVM.DosingPointNumber = M.DosingPointNumber
             AND TCEVM.ControllerEquipmentSetupID = @EquipmentSetupId
             AND TCEVM.PlantID = @PlantId);
    END;
    DECLARE
     @TempMapping TABLE(
     RowNumber INT NOT NULL
   , ControllerEquipmentId TINYINT NOT NULL
   , TunnelNumber INT NOT NULL
   , CompartmentNumber TINYINT NOT NULL
   , DosingPointNumber TINYINT NOT NULL
   , DirectDosingFlag BIT NOT NULL
   , VlaveNumber TINYINT NOT NULL
   , WasherNumber int NOT NULL);

    /* Create RowNumber inorder to increment and use row by row. */

    WITH CTE_LCM
    AS (
    SELECT ROW_NUMBER() OVER (ORDER BY LCM.TunnelNumber, LCM.DosingPointNumber) AS RowNumber
     , *
  FROM @lineCompartmentMappings LCM
    )
    INSERT INTO @TempMapping
    SELECT *
  FROM CTE_LCM CL;

    /* Loop */

    DECLARE
     @j INT = 1,
     @max INT = (SELECT MAX(TM.RowNumber)
       FROM @TempMapping TM);
    WHILE @j <= @max
    BEGIN

    /* Declare and Initialize the current row data */

    DECLARE
     @TunnelNumber INT,
     @CompartmentNumber TINYINT,
     @DosingpointNumber TINYINT;
    SELECT TOP 1 @TunnelNumber = TM.TunnelNumber
       , @DosingPointNumber = TM.DosingpointNumber
       , @CompartmentNumber = TM.CompartmentNumber
      FROM @TempMapping TM
      WHERE TM.RowNumber = @j;
    DECLARE
     @ValveNumber INT = 0;
    IF @DDFlag = 'FALSE'
    BEGIN

    /* Get Min Available Valve Number */

    SELECT @ValveNumber = MIN(CEV.ControllerEquipmentValveID)
      FROM TCD.ControllerEquipmentValves CEV
      WHERE ControllerEquipmentValveID <> 0
        AND CEV.ControllerEquipmentValveID  NOT IN (
        SELECT TCEVM.ValveNumber
      FROM TCD.TunnelCompartmentEquipmentValveMapping TCEVM
       JOIN
       TCD.ControllerEquipmentSetup CES ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupID
      WHERE CES.ControllerID = @ControllerId);
    END;

    /* Update If Exists else Insert */

    MERGE TCD.TunnelCompartmentEquipmentValveMapping T
    USING (SELECT TOP 1 *
     FROM @TempMapping TM
     WHERE TM.RowNumber = @j) S
    ON T.ControllerEquipmentSetupID = @EquipmentSetupId
   AND T.PlantID = @PlantId
   AND T.TunnelNumber = S.TunnelNumber
   AND T.DosingPointNumber = S.DosingPointNumber
   AND T.DirectDosingFlag = S.DirectDosingFlag
    WHEN MATCHED
      THEN
      UPDATE SET T.CompartmentNumber = S.CompartmentNumber
       , T.ValveNumber = CASE  @DDFlag
         WHEN 'TRUE' THEN 0
             ELSE T.ValveNumber
         END
       , T.WasherExtractorNumber = S.WasherNumber
       , T.LastModifiedByUserID = @UserId
    WHEN NOT MATCHED
      THEN
      INSERT (PlantID
        , ControllerEquipmentSetupID
        , TunnelNumber
        , DosingPointNumber
        , ValveNumber
        , CompartmentNumber
        , DirectDosingFlag
        , LastModifiedByUserID)
      VALUES (@PlantId,
      @EquipmentSetupId,
      S.TunnelNumber,
      S.DosingPointNumber,
      @ValveNumber,
      S.CompartmentNumber,
      S.DirectDosingFlag,
      @UserId);

    /* Increment the row */

    SET @j = @j + 1;
    END;
END;
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[AddTunnel]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[AddTunnel]
END
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE	[TCD].[AddTunnel]	
					@MyServiceWasherId						UniqueIdentifier
				,	@EcoLabAccountNumber					NVARCHAR(25)
				,	@WasherGroupId							INT
				,	@TunnelName								NVARCHAR(50)
				,	@WasherModelName						NVARCHAR(50)
				,	@RegionId								SMALLINT
--				,	@Size									INT									--we don't need to save this; ModelId PK determines it
				,	@ControllerId							INT
				,	@LFSWasherNumber						TINYINT			=			1		--For tunnels, it will be 1 until a diff. number is passed (as per the scenario)
				,	@PlantWasherNumber						SMALLINT
				,	@WasherMode								TINYINT
				,	@MaxLoad								SMALLINT
				,	@AWEActive								BIT
				,	@NumberOfTanks							TINYINT
				,	@NumberOfComp							TINYINT								--though this is INT in the table, we should not require it to be so
				,	@TransferType							TINYINT         =			NULL
				,	@PressExtractor							TINYINT       =			NULL
				,	@ProgramNumber							TINYINT
				,	@EndOfFormula							TINYINT
				,	@Description							NVARCHAR(1024)	=			NULL
				,	@UserId									INT

				,	@OutputTunnelId							INT			OUTPUT
				--Adding as part of re-factoring for integration with Synch/Configurator... generated TunnelId (re-named) is already being OUTPUT above
				,	@OutputLastModifiedTimestampAtLocal		DATETIME		=			NULL	OUTPUT
				,   @RatioDosingActive						Bit = 'False'
				,   @ControllerModelId						INT		=		NULL
				,   @NumberOfCompartmentsConveyorBelt			TINYINT	=		NULL
				,   @MaxMachineLoad							TINYINT	=		NULL
				,   @MinMachineLoad							TINYINT	=		NULL
				,   @ProgramSelectionByTime					BIT	  	=		NULL
				,   @WeightSelectionByTime					BIT	  	=		NULL
				,   @WeightSelectionByAnalogInput				BIT	  	=		NULL
				,   @TunInTomMode							BIT	  	=		NULL
				,   @SignalStopTunActive						BIT	  	=		NULL
				,   @SignalEjectionTunActive	  				BIT	  	=		NULL
				,   @DelayTimeForTunWashingPrograms			BIT	  	=		NULL
				,   @KannegiesserPressSpecialMode				BIT	  	=		NULL
				,   @ValveOutputsUsedAsTomSignal				BIT	  	=		NULL
				,   @ExtendedClockOrDataProtocol				BIT	  	=		NULL
				,   @WeightCorrectionFcc						BIT	  	=		NULL
				,	@DateAndTimeWhenBatchEjects					BIT	  		=		NULL
				,	@AutoRinseDesamixAfter						SMALLINT	=		NULL
				,	@AutoRinseDesamix1For						SMALLINT	=		NULL
				,	@AutoRinseDesamix2For						SMALLINT	=		NULL
				,	@TemperatureAlarmProbe1						BIT			=		NULL
				,	@TemperatureAlarmProbe2						BIT			=		NULL
				,	@TemperatureAlarmProbe3						BIT			=		NULL
				,	@ETechWasherNumber						    INT			=		NULL
				,	@KannegiesserDosageInPreparationTankMode	bit			=		NULL
				,	@BatchOk									bit			=		NULL

AS
BEGIN

SET	NOCOUNT	ON


DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''

	,	@WasherId						INT				=			NULL
	,	@WasherModelId					SMALLINT		=			NULL
	--Adding for integration with Synch./Central
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()
	,	@ControllerValidate				int				=										   0

--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
SET		@OutputLastModifiedTimestampAtLocal				=			@CurrentUTCTime
SET		@OutputTunnelId									=			ISNULL(@OutputTunnelId, NULL)			--SQLEnlight

--Check that the WasherGroup being associated-to is a valid Tunnel-type WG...
IF	NOT	EXISTS	(	SELECT	1
					FROM	[TCD].WasherGroup			WG
					JOIN	[TCD].WasherGroupType		WGT
						ON	WG.WasherGroupTypeId		=			WGT.WasherGroupTypeId
					JOIN	[TCD].MachineGroup					GT									--this is actually the Groups table and NOT really a Group TYPE
						ON	WG.WasherGroupId			=			GT.Id			--GroupTypeId is actually the Id of the Group
					WHERE	WG.WasherGroupId			=			@WasherGroupId
						AND	GT.EcolabAccountNumber		=			@EcoLabAccountNumber
						AND	GT.GroupTypeId	  			=			2			--select	GroupMaintype	from	GroupType
						AND	WGT.WasherGroupTypeName		=			'Tunnel'				--select	WasherGroupTypeName	from	WasherGroupType
				)
			BEGIN
				SET		@ErrorId						=			51001
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherGroup provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--Check for only 1 tunnel for a WasherGroup
IF	EXISTS		(	SELECT	1
					FROM	[TCD].MachineSetup			MS
					JOIN	[TCD].Washer				W
						ON	MS.WasherId					=			W.WasherId
					WHERE	MS.GroupId					=			@WasherGroupId
						AND	MS.EcoalabAccountNumber		=			@EcoLabAccountNumber
						AND	MS.IsDeleted				=			'FALSE'
						AND	MS.IsTunnel					=			'TRUE'
						AND	W.Is_Deleted				=			'FALSE'
				)
			BEGIN
				SET		@ErrorId						=			51008
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': A Tunnel has already been added to this Washer Group.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--Check for unique PlantWasherNo.
IF	EXISTS		(	SELECT	1
					FROM	[TCD].Washer				W
					JOIN	[TCD].MachineSetup			MS
						ON	W.WasherId					=			MS.WasherId
						AND	W.EcoLabAccountNumber		=			MS.EcoalabAccountNumber
					WHERE	W.EcoLabAccountNumber		=			@EcoLabAccountNumber
						AND	(
							W.PlantWasherNumber			=			@PlantWasherNumber							
							)
						AND	W.Is_Deleted				=			'FALSE'
						AND	MS.IsDeleted				=			'FALSE'
				)
			BEGIN
				SET		@ErrorId						=			51002
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Specified Plant Washer #/ already exists.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--Check that it's a valid Controller type/model (one that can control a Tunnel)

EXEC @ControllerValidate = [TCD].[ValidateController] 2,@ControllerId,@EcoLabAccountNumber

IF(@ControllerValidate = 1)
				
			BEGIN
				SET		@ErrorId						=			51003
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller was provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--EOF should not be an asocciated formula for the WG...
IF	EXISTS		(	SELECT	1
					FROM	[TCD].TunnelProgramSetup	TPS
					WHERE	TPS.EcolabAccountNumber		=			@EcoLabAccountNumber
						AND	TPS.WasherGroupId			=			@WasherGroupId
						AND	TPS.ProgramNumber			=			@ProgramNumber
						AND	TPS.Is_Deleted				=			'FALSE'
				)
			BEGIN
				SET		@ErrorId						=			51004
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An associated formula cannot be specified as End-Of-Formula.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--WasherMode check
IF	NOT	EXISTS	(	SELECT	1
					FROM	[TCD].ControllerModelControllerTypeMapping
														CMCTM
					JOIN	[TCD].ConduitController		CC
						ON	CC.ControllerTypeId			=			CMCTM.ControllerTypeId
						AND	CC.ControllerModelId		=			CMCTM.ControllerModelId
					JOIN	[TCD].[WasherModeMapping]	CTM2WM
						ON	CMCTM.Id					=			CTM2WM.ControllerModelControllerTypeMappingId
					WHERE	CC.EcoalabAccountNumber		=			@EcoLabAccountNumber
						AND	CC.ControllerId				=			@ControllerId
						AND	CC.IsDeleted				=			'FALSE'
						AND	CMCTM.MaxtunnelCount > 0
						AND	CTM2WM.WasherModeId			=			@WasherMode
				)
			BEGIN
				SET		@ErrorId						=			51005
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherMode was provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--select the WasherModelId based on name
SELECT	TOP	1
		@WasherModelId						=			WMS.WasherModelId
FROM	[TCD].WasherModelSize				WMS
WHERE	WMS.RegionId						=			@RegionId
	AND	WMS.WasherModelName					=			@WasherModelName
	AND	WMS.ModelTypeId						=			2							--TypeId 2 for Tunnel
	AND	WMS.Is_Deleted						=			'FALSE'

--LFSWasherNumber duplicate check...
IF	EXISTS	(	SELECT	1
				FROM	[TCD].MachineSetup					MS
				WHERE	MS.ControllerId					=			@ControllerId
					AND	MS.MachineInternalId			=			@LFSWasherNumber
					AND MS.EcoalabAccountNumber			=			@EcoLabAccountNumber
					AND	MS.IsDeleted					=			'FALSE'
					AND MS.IsTunnel						=			'TRUE'
			)
			BEGIN
				SET		@ErrorId						=			51010
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate LFSWasher# provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET		@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END
--ETechWasherNumber duplicate check...
IF(@ControllerModelId NOT IN (7,8,9,10,11,14))
BEGIN
IF EXISTS ( SELECT 1
    FROM [TCD].Washer  AS W
    JOIN [TCD].MachineSetup AS MS ON MS.WasherId = W.WasherId 
    where W.ETechWasherNumber = @ETechWasherNumber
	 AND  MS.IsTunnel                    =            'TRUE'
)  
BEGIN  

SET  @ErrorId      =   51012  
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate ETechWasherNumber# provided.'  
--GOTO ErrorHandler  
RAISERROR (@ErrorMessage, 16, 1)  
SET  @ReturnValue = -1  
RETURN (@ReturnValue)  
END
END

--Now attempt to insert a new row for the tunnel record being created...
BEGIN	TRAN
IF(@ControllerModelId IS NOT NULL AND @ControllerModelId = 7 )
BEGIN
INSERT	[TCD].Washer	(
		 MyServiceCustMchGuid
		,EcoLabAccountNumber
		,PlantWasherNumber
		,ModelId
		,WasherMode
		,MaxLoad
		,[Description]
		,Is_Deleted
		,LastModifiedByUserId
		,NumberOfTanks
		,TransferType
		,PressExtractor
	--Adding for integration with Synch./Central
		,LastModifiedTime
		,EmptyPocketNumber
		,NumberOfCompartmentsConveyorBelt
		,MinMachineLoad
		,MaxMachineLoad
		,ProgramSelectionByTime
		,WeightSelectionByTime
		,WeightSelectionByAnalogInput
		,TunInTomMode
		,SignalStopTunActive
		,SignalEjectionTunActive
		,DelayTimeForTunWashingPrograms
		,KannegiesserPressSpecialMode
		,ValveOutputsUsedAsTomSignal
		,ExtendedClockOrDataProtocol
		,WeightCorrectionFcc
		,AWEActive
		,EndOfFormula
		,ETechWasherNumber
		,KannegiesserDosageInPreparationTankMode
		,BatchOk
	)
SELECT @MyServiceWasherId					AS			MyServiceWasherId	
	,	@EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	@PlantWasherNumber					AS			PlantWasherNumber
	,	@WasherModelId						AS			ModelId
	--,	@Size							AS			Size
	,	@WasherMode						AS			WasherMode
	,	@MaxLoad							AS			MaxLoad
	,	@Description						AS			[Description]
	,	'FALSE'							AS			Is_Deleted
	,	@UserId							AS			LastModifiedByUserId
	,	@NumberOfTanks						AS			NumberOfTanks
	,	@TransferType						AS			TransferType
	,	@PressExtractor					AS			PressExtractor
	,	@CurrentUTCTime					AS			LastModifiedTime
	,	@ProgramNumber						AS			ProgramNumber
	,   @NumberOfCompartmentsConveyorBelt		AS			NumberOfCompartmentsConveyorBelt
	,   @MinMachineLoad						AS			MinMachineLoad
	,   @MaxMachineLoad						AS			MaxMachineLoad
	,   @ProgramSelectionByTime				AS			ProgramSelectionByTime
	,   @WeightSelectionByTime				AS			WeightSelectionByTime
	,   @WeightSelectionByAnalogInput			AS			WeightSelectionByAnalogInput
	,   @TunInTomMode						AS			TunInTomMode
	,   @SignalStopTunActive					AS			SignalStopTunActive
	,   @SignalEjectionTunActive	  			AS			SignalEjectionTunActive
	,   @DelayTimeForTunWashingPrograms		AS			DelayTimeForTunWashingPrograms
	,   @KannegiesserPressSpecialMode			AS			KannegiesserPressSpecialMode
	,   @ValveOutputsUsedAsTomSignal			AS			ValveOutputsUsedAsTomSignal
	,   @ExtendedClockOrDataProtocol			AS			ExtendedClockOrDataProtocol
	,   @WeightCorrectionFcc					AS			WeightCorrectionFcc
	,	'FALSE'							AS			AWEActive
	,	0								AS			EndOfFormula
	,   @ETechWasherNumber			AS			ETechWasherNumber
	,	@KannegiesserDosageInPreparationTankMode	AS KannegiesserDosageInPreparationTankMode
	,	@BatchOk						AS		BatchOk
END
ELSE IF(@ControllerModelId IS NOT NULL AND ( @ControllerModelId = 8	OR @ControllerModelId = 9	OR @ControllerModelId = 10 OR @ControllerModelId = 11 OR @ControllerModelId = 14))
BEGIN
INSERT	[TCD].Washer	(
		 MyServiceCustMchGuid
		,EcoLabAccountNumber
		,PlantWasherNumber
		,ModelId
		,WasherMode
		,MaxLoad
		,[Description]
		,Is_Deleted
		,LastModifiedByUserId
		,NumberOfTanks
		,TransferType
		,PressExtractor
	--Adding for integration with Synch./Central
		,LastModifiedTime
		,EmptyPocketNumber
		,NumberOfCompartmentsConveyorBelt
		,MinMachineLoad
		,MaxMachineLoad
		,ProgramSelectionByTime
		,WeightSelectionByTime
		,WeightSelectionByAnalogInput
		,TunInTomMode
		,SignalStopTunActive
		,SignalEjectionTunActive
		,DelayTimeForTunWashingPrograms
		,KannegiesserPressSpecialMode
		,ValveOutputsUsedAsTomSignal
		,ExtendedClockOrDataProtocol
		,WeightCorrectionFcc
		,AWEActive
		,EndOfFormula
		,AutoRinseDesamixAfter
		,AutoRinseDesamix1For
		,AutoRinseDesamix2For
		,TemperatureAlarmProbe1
		,TemperatureAlarmProbe2
		,TemperatureAlarmProbe3
		,DateAndTimeWhenBatchEjects
		,ETechWasherNumber

	)
SELECT @MyServiceWasherId					AS			MyServiceWasherId	
	,	@EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	@PlantWasherNumber					AS			PlantWasherNumber
	,	@WasherModelId						AS			ModelId
	--,	@Size							AS			Size
	,	@WasherMode						AS			WasherMode
	,	@MaxLoad							AS			MaxLoad
	,	@Description						AS			[Description]
	,	'FALSE'							AS			Is_Deleted
	,	@UserId							AS			LastModifiedByUserId
	,	@NumberOfTanks						AS			NumberOfTanks
	,	@TransferType						AS			TransferType
	,	@PressExtractor					AS			PressExtractor
	,	@CurrentUTCTime					AS			LastModifiedTime
	,	@ProgramNumber						AS			ProgramNumber
	,   @NumberOfCompartmentsConveyorBelt		AS			NumberOfCompartmentsConveyorBelt
	,   @MinMachineLoad						AS			MinMachineLoad
	,   @MaxMachineLoad						AS			MaxMachineLoad
	,   @ProgramSelectionByTime				AS			ProgramSelectionByTime
	,   @WeightSelectionByTime				AS			WeightSelectionByTime
	,   @WeightSelectionByAnalogInput			AS			WeightSelectionByAnalogInput
	,   @TunInTomMode						AS			TunInTomMode
	,   @SignalStopTunActive					AS			SignalStopTunActive
	,   @SignalEjectionTunActive	  			AS			SignalEjectionTunActive
	,   @DelayTimeForTunWashingPrograms		AS			DelayTimeForTunWashingPrograms
	,   @KannegiesserPressSpecialMode			AS			KannegiesserPressSpecialMode
	,   @ValveOutputsUsedAsTomSignal			AS			ValveOutputsUsedAsTomSignal
	,   @ExtendedClockOrDataProtocol			AS			ExtendedClockOrDataProtocol
	,   @WeightCorrectionFcc					AS			WeightCorrectionFcc
	,	'FALSE'							AS			AWEActive
	,	0								AS			EndOfFormula
	,	@AutoRinseDesamixAfter
	,	@AutoRinseDesamix1For
	,	@AutoRinseDesamix2For
	,	@TemperatureAlarmProbe1
	,	@TemperatureAlarmProbe2
	,	@TemperatureAlarmProbe3
	,	@DateAndTimeWhenBatchEjects
	,   @ETechWasherNumber						AS			ETechWasherNumber
END
ELSE
BEGIN
INSERT	[TCD].Washer	(
		MyServiceCustMchGuid
		,EcoLabAccountNumber
		,PlantWasherNumber
		,ModelId
		,WasherMode
		,MaxLoad
		,AWEActive
		,EndOfFormula
		,[Description]
		,Is_Deleted
		,LastModifiedByUserId
		,NumberOfTanks
		,TransferType
		,PressExtractor
	--Adding for integration with Synch./Central
		,LastModifiedTime
		,RatioDosingActive
		,EmptyPocketNumber
	)
SELECT @MyServiceWasherId					AS			MyServiceWasherId	
	,	@EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	@PlantWasherNumber					AS			PlantWasherNumber
	,	@WasherModelId						AS			ModelId
	--,	@Size							AS			Size
	,	@WasherMode						AS			WasherMode
	,	@MaxLoad							AS			MaxLoad
	,	@AWEActive						AS			AWEActive
	,	@EndOfFormula						AS			EndOfFormula
	,	@Description						AS			[Description]
	,	'FALSE'							AS			Is_Deleted
	,	@UserId							AS			LastModifiedByUserId
	,	@NumberOfTanks						AS			NumberOfTanks
	,	@TransferType						AS			TransferType
	,	@PressExtractor					AS			PressExtractor
	,	@CurrentUTCTime					AS			LastModifiedTime
	,   @RatioDosingActive					AS			RatioDosingActive
	,	@ProgramNumber						AS			ProgramNumber 	
END

SET	@ErrorId	=	@@ERROR
	
IF	(@ErrorId	<>	0)
	BEGIN
			IF	@@TRANCOUNT	>	0
			BEGIN
				ROLLBACK	TRAN
			END

			SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred creating new record for tunnel.'
			--GOTO	ErrorHandler
			RAISERROR	(@ErrorMessage, 16, 1)
			SET	@ReturnValue	=	-1
			RETURN	(@ReturnValue)
	END

--if no error, collect the id of the newly generated row...
SELECT	@WasherId	=	SCOPE_IDENTITY()


--insert in MachineSetup
INSERT	[TCD].MachineSetup	(
		WasherId	,GroupId	,MachineInternalId	,EcoalabAccountNumber	,MachineName	,IsTunnel	,ControllerId	,NumberOfComp	,IsDeleted	,LastModifiedByUserId	)
SELECT	@WasherId					AS			WasherId
	,	@WasherGroupId				AS			GroupId
	,	@LFSWasherNumber			AS			MachineInternalId
	,	@EcoLabAccountNumber		AS			EcoalabAccountNumber
	,	@TunnelName					AS			MachineName
	,	'TRUE'						AS			IsTunnel
	,	@ControllerId				AS			ControllerId
	,	@NumberOfComp				AS			NumberOfComp
	,	'FALSE'						AS			IsDeleted
	,	@UserId						AS			LastModifiedByUserId

SET	@ErrorId	=	@@ERROR

IF	(@ErrorId	<>	0)
	BEGIN
			IF	@@TRANCOUNT	>	0
			BEGIN
				ROLLBACK	TRAN
			END

			SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred assoicating new record for tunnel.'
			--GOTO	ErrorHandler
			RAISERROR	(@ErrorMessage, 16, 1)
			SET	@ReturnValue	=	-1
			RETURN	(@ReturnValue)
	END
ELSE
	BEGIN
			IF	@@TRANCOUNT	>	0
			BEGIN
			IF (@ControllerModelId = 7)
				BEGIN
					UPDATE TCD.WasherGroup 
					SET	  ControllerId = @ControllerId ,
						  WasherDosingNumber = @LFSWasherNumber
					WHERE  WasherGroupId = @WasherGroupId
				END
				COMMIT
			END

			--SET the output param to be communicated back...
			SET	@OutputTunnelId	=	@WasherId
	END



--IF	(	@ErrorId	=	0	)
--	BEGIN
--		--GOTO	ExitModule
--		RETURN	(@ReturnValue)
--	END




--ErrorHandler:
--RAISERROR	(@ErrorMessage, 16, 1)
--SET	@ReturnValue	=	-1




--ExitModule:

SET	NOCOUNT	OFF
RETURN	(@ReturnValue)


END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[UpdateTunnel]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[UpdateTunnel]
END
GO
SET ANSI_NULLS ON
GO

CREATE	PROCEDURE    [TCD].[UpdateTunnel]
                    @EcoLabAccountNumber                    NVARCHAR(25)
                ,    @WasherId                                INT
                ,    @WasherGroupId                            INT                                    --Not updated, for reference only
                ,    @TunnelName                            NVARCHAR(50)
                ,    @WasherModelName                        NVARCHAR(50)
                ,    @RegionId                                SMALLINT
                --,    @Size                                INT
                ,    @ControllerId                            INT
                ,    @LFSWasherNumber                        INT            =            1        --For tunnels, it will be 1 until a diff. number is passed (as per the scenario)
                ,    @PlantWasherNumber                        SMALLINT
                ,    @WasherMode                            SMALLINT
                ,    @MaxLoad                                SMALLINT
                ,    @AWEActive                            BIT
                ,    @NumberOfTanks                            TINYINT
                ,    @NumberOfComp                            INT                                --though this is INT in the table, we should not require it to be so
                ,    @TransferType                            TINYINT
                ,    @PressExtractor                        TINYINT
                ,    @ProgramNumber                            TINYINT
                ,    @EndOfFormula                            TINYINT
                ,    @Description                            NVARCHAR(1024)    =            NULL
                ,    @UserId                                INT
				--Adding these 3 params as part of re-factoring for integration with Synch/Configurator
                ,    @OutputTunnelId                        INT            =            NULL    OUTPUT
                ,    @LastModifiedTimestampAtCentral            DATETIME    =            NULL            --Nullable for local call; Synch/Central call will have to pass this -
																									--else, it will be treated as a local call
                ,    @OutputLastModifiedTimestampAtLocal        DATETIME    =            NULL    OUTPUT
                ,   @RatioDosingActive                        BIT
                ,   @ControllerModelId                        INT        =        NULL
                ,   @NumberOfCompartmentsConveyorBelt            TINYINT    =        NULL
                ,   @MaxMachineLoad                            SMALLINT    =        NULL
                ,   @MinMachineLoad                            SMALLINT    =        NULL
                ,   @ProgramSelectionByTime                    BIT          =        NULL
                ,   @WeightSelectionByTime                    BIT          =        NULL
                ,   @WeightSelectionByAnalogInput                BIT          =        NULL
                ,   @TunInTomMode                            BIT          =        NULL
                ,   @SignalStopTunActive                        BIT          =        NULL
                ,   @SignalEjectionTunActive                      BIT          =        NULL
                ,   @DelayTimeForTunWashingPrograms            BIT          =        NULL
                ,   @KannegiesserPressSpecialMode                BIT          =        NULL
                ,   @ValveOutputsUsedAsTomSignal                BIT          =        NULL
                ,   @ExtendedClockOrDataProtocol                BIT          =        NULL
                ,   @WeightCorrectionFcc                        BIT          =        NULL
				,	@DateAndTimeWhenBatchEjects					BIT	  		=		NULL
				,	@AutoRinseDesamixAfter						SMALLINT	=		NULL
				,	@AutoRinseDesamix1For						SMALLINT	=		NULL
				,	@AutoRinseDesamix2For						SMALLINT	=		NULL
				,	@TemperatureAlarmProbe1						BIT			=		NULL
				,	@TemperatureAlarmProbe2						BIT			=		NULL
				,	@TemperatureAlarmProbe3						BIT			=		NULL
				,	@UseMe1OfGroup							tinyint					=	NULL
				,	@UseMe2OfGroup							tinyint					=	NULL
				,	@ETechWasherNumber						int					=	NULL
				,	@KannegiesserDosageInPreparationTankMode	bit			=		NULL
				,	@BatchOk									bit			=		NULL
AS
BEGIN

SET    NOCOUNT    ON


DECLARE	
        @ReturnValue                    INT                =            0
    ,    @ErrorId                        INT                =            0
    ,    @ErrorMessage                    NVARCHAR(4000)    =            N''

    ,    @WasherModelId                    SMALLINT        =            NULL

    ,    @CurrentUTCTime                    DATETIME        =            GETUTCDATE()
	,	@ControllerValidate				int				=										   0

--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
SET        @OutputLastModifiedTimestampAtLocal                =            @CurrentUTCTime
SET        @OutputTunnelId                                    =            ISNULL(@OutputTunnelId, NULL)            --SQLEnlight

--If the call is not local, check that the LastModifiedTime matches with the central
IF    (
        @LastModifiedTimestampAtCentral            IS NOT    NULL
    AND    NOT    EXISTS    (    SELECT    1
                        FROM    TCD.[Washer]            W
                        WHERE    W.EcolabAccountNumber    =    @EcolabAccountNumber
                            AND    W.WasherId                =    @WasherId
                            AND    W.LastModifiedTime        =    @LastModifiedTimestampAtCentral
					)
	)
	BEGIN
            SET            @ErrorId                    =    60000
            SET            @ErrorMessage                =    N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
            RAISERROR    (@ErrorMessage, 16, 1)
            SET            @ReturnValue                =    -1
            RETURN        (@ReturnValue)
	END

--Proceed, since it's either a local call or Synch. call with synch. time matching


--Valid Washer - based on Id...
IF    NOT    EXISTS    (    SELECT    1
                    FROM    [TCD].Washer                W
                    JOIN    [TCD].MachineSetup            MS
                        ON    W.WasherId                    =            MS.WasherId
                        AND    W.EcoLabAccountNumber        =            MS.EcoalabAccountNumber
                    WHERE    W.EcoLabAccountNumber        =            @EcoLabAccountNumber
                        AND    W.WasherId                    =            @WasherId
                        AND    MS.GroupId                    =            @WasherGroupId
                        AND    MS.IsTunnel                    =            'TRUE'
                        AND    W.Is_Deleted                =            'FALSE'
                        AND    MS.IsDeleted                =            'FALSE'
				)
			BEGIN
                SET        @ErrorId                        =            51006
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Washer-ID was provided for Updating.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET    @ReturnValue    =    -1
                RETURN    (@ReturnValue)
			END


--Check for uniqueness of PlantWasherNo. and Name
IF    EXISTS        (    SELECT    1
                    FROM    [TCD].Washer                W
                    JOIN    [TCD].MachineSetup            MS
                        ON    W.WasherId                    =            MS.WasherId
                        AND    W.EcoLabAccountNumber        =            MS.EcoalabAccountNumber
                    WHERE    W.EcoLabAccountNumber        =            @EcoLabAccountNumber
                        AND    W.WasherId                    <>            @WasherId
                        AND    (
                            W.PlantWasherNumber            =            @PlantWasherNumber
                            AND
                            MS.MachineName                =            @TunnelName
							)
                        AND    W.Is_Deleted                =            'FALSE'
                        AND    MS.IsDeleted                =            'FALSE'
				)
			BEGIN
                SET        @ErrorId                        =            51002
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Specified Plant Washer #/Name already exists.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET    @ReturnValue    =    -1
                RETURN    (@ReturnValue)
			END


--Check that it's a valid Controller type/model (one that can control a Tunnel)
IF	NOT	EXISTS	(	SELECT	1
					FROM	[TCD].ControllerModelControllerTypeMapping
														CMCTM
					JOIN	[TCD].ConduitController		CC
						ON	CC.ControllerTypeId			=			CMCTM.ControllerTypeId
						AND	CC.ControllerModelId		=			CMCTM.ControllerModelId
					WHERE	CC.EcoalabAccountNumber		=			@EcoLabAccountNumber
						AND	CC.ControllerId				=			@ControllerId
						AND	CC.IsDeleted				=			'FALSE'
						AND	CMCTM.CanControlTunnel		=			'TRUE'
				)
			BEGIN
				SET		@ErrorId						=			51003
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller was provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END

--IF  (  @ControllerValidate = 1)
--            BEGIN
--                SET        @ErrorId                        =            51003
--                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller was provided.'
--                --GOTO    ErrorHandler
--                RAISERROR    (@ErrorMessage, 16, 1)
--                SET    @ReturnValue    =    -1
--                RETURN    (@ReturnValue)
--            END


--EOF should not be an asocciated formula for the WG...
IF    EXISTS        (    SELECT    1
                    FROM    [TCD].TunnelProgramSetup    TPS
                    WHERE    TPS.EcolabAccountNumber        =            @EcoLabAccountNumber
                        AND    TPS.WasherGroupId            =            @WasherGroupId
                        AND    TPS.ProgramNumber            =            @ProgramNumber
                        AND    TPS.Is_Deleted                =            'FALSE'
				)
			BEGIN
                SET        @ErrorId                        =            51004
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An assoicated formula cannot be specified as End-Of-Formula.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET    @ReturnValue    =    -1
                RETURN    (@ReturnValue)
			END


--WasherMode check
IF    NOT    EXISTS    (    SELECT    1
                    FROM    [TCD].ControllerModelControllerTypeMapping
														CMCTM
                    JOIN    [TCD].ConduitController        CC
                        ON    CC.ControllerTypeId            =            CMCTM.ControllerTypeId
                        AND    CC.ControllerModelId        =            CMCTM.ControllerModelId
                    JOIN    [TCD].[WasherModeMapping]
														CTM2WM
                        ON    CMCTM.Id                    =            CTM2WM.ControllerModelControllerTypeMappingId
                    WHERE    CC.EcoalabAccountNumber        =            @EcoLabAccountNumber
                        AND    CC.ControllerId                =            @ControllerId
                        AND    CC.IsDeleted                =            'FALSE'
                        --AND    CMCTM.CanControlTunnel        =            'TRUE'
                        AND    CTM2WM.WasherModeId            =            @WasherMode
				)
			BEGIN
                SET        @ErrorId                        =            51005
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherMode was provided.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET    @ReturnValue    =    -1
                RETURN    (@ReturnValue)
			END


--select the WasherModelId based on name
SELECT    TOP    1
        @WasherModelId                        =            WMS.WasherModelId
FROM    [TCD].WasherModelSize                WMS
WHERE    WMS.RegionId                        =            @RegionId
    AND    WMS.WasherModelName                    =            @WasherModelName
    AND    WMS.ModelTypeId                    =            2                            --TypeId 2 for Tunnel
    AND    WMS.Is_Deleted                        =            'FALSE'

--LFSWasherNumber duplicate check...
IF    EXISTS    (    SELECT    1
                FROM    [TCD].MachineSetup                    MS
                WHERE    MS.ControllerId                    =            @ControllerId
                    AND    MS.MachineInternalId            =            @LFSWasherNumber
                    AND    MS.IsDeleted                    =            'FALSE'
                    AND    MS.WasherId                        <>            @WasherId
                    AND MS.EcoalabAccountNumber            =            @EcoLabAccountNumber
                    AND MS.IsTunnel                        =            'TRUE'
            )
            BEGIN
                SET        @ErrorId                        =            51010
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate LFSWasher# provided.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET        @ReturnValue    =    -1
                RETURN    (@ReturnValue)
            END
--ETechWasherNumber duplicate check...
IF(@ControllerModelId NOT IN (7,8,9,10,11,14))
BEGIN
IF EXISTS ( SELECT 1
    FROM [TCD].Washer  AS W
    JOIN [TCD].MachineSetup AS MS ON MS.WasherId = W.WasherId 
    where W.ETechWasherNumber = @ETechWasherNumber
	AND W.WasherId = @WasherId
	 AND  MS.IsTunnel                    =            'TRUE'
)  
BEGIN  

SET  @ErrorId      =   51012  
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate ETechWasherNumber# provided.'  
--GOTO ErrorHandler  
RAISERROR (@ErrorMessage, 16, 1)  
SET  @ReturnValue = -1  
RETURN (@ReturnValue)  
END
END

--Now attempt Update...
BEGIN    TRAN

UPDATE    MS
    SET    MS.MachineName                    =            @TunnelName
    ,    MS.ControllerId                =            @ControllerId
    ,    MS.MachineInternalId            =            @LFSWasherNumber
    ,    MS.NumberOfComp                =            @NumberOfComp
    ,    MS.LastModifiedByUserId            =            @UserId
FROM    [TCD].MachineSetup                MS
JOIN    [TCD].Washer                    W
    ON    MS.WasherId                    =            W.WasherId
    AND    MS.EcoalabAccountNumber            =            W.EcolabAccountNumber
WHERE    MS.WasherId                    =            @WasherId
    AND    MS.EcoalabAccountNumber            =            @EcoLabAccountNumber
    AND    MS.IsDeleted                    =            'FALSE'
    AND    W.Is_Deleted                    =            'FALSE'

--check for any error
SET    @ErrorId    =    @@ERROR

IF    (@ErrorId    <>    0)
BEGIN

        IF    @@TRANCOUNT    >    0
		BEGIN
            ROLLBACK    TRAN
		END
	
    SET        @ErrorMessage                =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating washer data.'
    --GOTO    Errorhandler
    RAISERROR    (@ErrorMessage, 16, 1)
    SET    @ReturnValue    =    -1
    RETURN    (@ReturnValue)
END

--else, continue with the rest of the update in the other table...
IF(@ControllerModelId IS NOT NULL AND @ControllerModelId = 7 )
BEGIN
UPDATE    W
    SET    W.ModelId                        =            @WasherModelId
    ,    W.PlantWasherNumber                =            @PlantWasherNumber
    ,    W.WasherMode                    =            @WasherMode
    ,    W.MaxLoad                        =            @MaxLoad
    ,    W.AWEActive                    =            'FALSE'
    ,    W.NumberOfTanks                =            @NumberOfTanks
    ,    W.TransferType                    =            @TransferType
    ,    W.PressExtractor                =            @PressExtractor
    ,    W.EmptyPocketNumber                =            @ProgramNumber
    ,    W.[Description]                =            @Description
    ,    W.LastModifiedByUserId            =            @UserId
    ,    W.LastModifiedTime                =            @CurrentUTCTime
    ,    W.RatioDosingActive                =              NULL    
    ,    W.EndOfFormula                    =            0
    ,    W.NumberOfCompartmentsConveyorBelt     =            @NumberOfCompartmentsConveyorBelt
    ,    W.MinMachineLoad                 =            @MinMachineLoad
    ,    W.MaxMachineLoad                 =            @MaxMachineLoad
    ,    W.ProgramSelectionByTime             =            @ProgramSelectionByTime
    ,    W.WeightSelectionByTime             =            @WeightSelectionByTime
    ,    W.WeightSelectionByAnalogInput     =            @WeightSelectionByAnalogInput
    ,    W.TunInTomMode                     =            @TunInTomMode
    ,    W.SignalStopTunActive             =            @SignalStopTunActive
    ,    W.SignalEjectionTunActive         =            @SignalEjectionTunActive
    ,    W.DelayTimeForTunWashingPrograms     =            @DelayTimeForTunWashingPrograms
    ,    W.KannegiesserPressSpecialMode     =            @KannegiesserPressSpecialMode
    ,    W.ValveOutputsUsedAsTomSignal         =            @ValveOutputsUsedAsTomSignal
    ,    W.ExtendedClockOrDataProtocol         =            @ExtendedClockOrDataProtocol
    ,    W.WeightCorrectionFcc             =            @WeightCorrectionFcc
	,	 W.ETechWasherNumber					=		@ETechWasherNumber
	,	W.KannegiesserDosageInPreparationTankMode = @KannegiesserDosageInPreparationTankMode
	,	W.BatchOk = @BatchOk
FROM    [TCD].Washer                    W
JOIN    [TCD].MachineSetup                MS
    ON    W.WasherId                    =            MS.WasherId
    AND    W.EcoLabAccountNumber            =            MS.EcoalabAccountNumber
WHERE    W.WasherId                    =            @WasherId
    AND    W.EcoLabAccountNumber            =            @EcoLabAccountNumber
    AND    W.Is_Deleted                    =            'FALSE'
    AND    MS.IsDeleted                    =            'FALSE'
END
ELSE IF(@ControllerModelId IS NOT NULL AND ( @ControllerModelId = 8	OR @ControllerModelId = 9	OR @ControllerModelId = 10 OR @ControllerModelId = 11 OR @ControllerModelId = 14))
BEGIN
UPDATE    W
    SET    W.ModelId                        =            @WasherModelId
    ,    W.PlantWasherNumber                =            @PlantWasherNumber
    ,    W.WasherMode                    =            @WasherMode
    ,    W.MaxLoad                        =            @MaxLoad
    ,    W.AWEActive                    =            'FALSE'
    ,    W.NumberOfTanks                =            @NumberOfTanks
    ,    W.TransferType                    =            @TransferType
    ,    W.PressExtractor                =            @PressExtractor
    ,    W.EmptyPocketNumber                =            @ProgramNumber
    ,    W.[Description]                =            @Description
    ,    W.LastModifiedByUserId            =            @UserId
    ,    W.LastModifiedTime                =            @CurrentUTCTime
    ,    W.RatioDosingActive                =              NULL    
    ,    W.EndOfFormula                    =            0
    ,    W.NumberOfCompartmentsConveyorBelt     =            @NumberOfCompartmentsConveyorBelt
    ,    W.MinMachineLoad                 =            @MinMachineLoad
    ,    W.MaxMachineLoad                 =            @MaxMachineLoad
    ,    W.TunInTomMode                     =            @TunInTomMode
    ,    W.DelayTimeForTunWashingPrograms     =            @DelayTimeForTunWashingPrograms
    ,    W.KannegiesserPressSpecialMode     =            @KannegiesserPressSpecialMode
    ,    W.WeightCorrectionFcc             =            @WeightCorrectionFcc
	,	 W.DateAndTimeWhenBatchEjects		=			@DateAndTimeWhenBatchEjects
	,	 W.AutoRinseDesamixAfter			=			@AutoRinseDesamixAfter
	,	 W.AutoRinseDesamix1For				=			@AutoRinseDesamix1For
	,	 W.AutoRinseDesamix2For				=			@AutoRinseDesamix2For
	,	 W.TemperatureAlarmProbe1			=			@TemperatureAlarmProbe1
	,	 W.TemperatureAlarmProbe2			=			@TemperatureAlarmProbe2
	,	 W.TemperatureAlarmProbe3			=			@TemperatureAlarmProbe3
	,	 W.UseMe1OfGroup					=			@UseMe1OfGroup
	,	 W.UseMe2OfGroup					=			@UseMe2OfGroup
	,	 W.ETechWasherNumber					=		@ETechWasherNumber

FROM    [TCD].Washer                    W
JOIN    [TCD].MachineSetup                MS
    ON    W.WasherId                    =            MS.WasherId
    AND    W.EcoLabAccountNumber            =            MS.EcoalabAccountNumber
WHERE    W.WasherId                    =            @WasherId
    AND    W.EcoLabAccountNumber            =            @EcoLabAccountNumber
    AND    W.Is_Deleted                    =            'FALSE'
    AND    MS.IsDeleted                    =            'FALSE'
END
ELSE
BEGIN
UPDATE    W
    SET    W.ModelId                        =            @WasherModelId
    ,    W.PlantWasherNumber                =            @PlantWasherNumber
    ,    W.WasherMode                    =            @WasherMode
    ,    W.MaxLoad                        =            @MaxLoad
    ,    W.AWEActive                    =            @AWEActive
    ,    W.NumberOfTanks                =            @NumberOfTanks
    ,    W.TransferType                    =            @TransferType
    ,    W.PressExtractor                =            @PressExtractor
    ,    W.EmptyPocketNumber                =            @ProgramNumber
    ,    W.[Description]                =            @Description
    ,    W.LastModifiedByUserId            =            @UserId
    ,    W.LastModifiedTime                =            @CurrentUTCTime
    ,   W.RatioDosingActive                =              @RatioDosingActive    
    ,   W.EndOfFormula                    =            @EndOfFormula
    ,    W.LfsWasher                     =            NULL
    ,    W.NumberOfCompartmentsConveyorBelt     =            NULL
    ,    W.MinMachineLoad                 =            NULL
    ,    W.MaxMachineLoad                 =            NULL
    ,    W.ProgramSelectionByTime             =            NULL
    ,    W.WeightSelectionByTime             =            NULL
    ,    W.WeightSelectionByAnalogInput     =            NULL
    ,    W.TunInTomMode                     =            NULL
    ,    W.SignalStopTunActive             =            NULL
    ,    W.SignalEjectionTunActive         =            NULL
    ,    W.DelayTimeForTunWashingPrograms     =            NULL
    ,    W.KannegiesserPressSpecialMode     =            NULL
    ,    W.ValveOutputsUsedAsTomSignal         =            NULL
    ,    W.ExtendedClockOrDataProtocol         =            NULL
    ,    W.WeightCorrectionFcc             =            NULL
	,	 W.ETechWasherNumber					=		@ETechWasherNumber
FROM    [TCD].Washer                    W
JOIN    [TCD].MachineSetup                MS
    ON    W.WasherId                    =            MS.WasherId
    AND    W.EcoLabAccountNumber            =            MS.EcoalabAccountNumber
WHERE    W.WasherId                    =            @WasherId
    AND    W.EcoLabAccountNumber            =            @EcoLabAccountNumber
    AND    W.Is_Deleted                    =            'FALSE'
    AND    MS.IsDeleted                    =            'FALSE'
END
--check for error, if none - commit the tran, else rollback
SET    @ErrorId    =    @@ERROR
IF    (@ErrorId    <>    0)
	BEGIN
        IF    (@@TRANCOUNT    >    0)
			BEGIN
				ROLLBACK
			END

        SET        @ErrorMessage                =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating washer data.'
        --GOTO    Errorhandler
        RAISERROR    (@ErrorMessage, 16, 1)
        SET    @ReturnValue    =    -1
        RETURN    (@ReturnValue)
	END
ELSE
	BEGIN
        IF    (@@TRANCOUNT    >    0)
			BEGIN
			IF (@ControllerModelId = 7)
				BEGIN
					UPDATE TCD.WasherGroup 
					SET	  ControllerId = @ControllerId ,
						  WasherDosingNumber = @LFSWasherNumber
					WHERE  WasherGroupId = @WasherGroupId
				END
				COMMIT
			END

        SET    @OutputTunnelId    =    @WasherId
	END


--IF    (@ErrorId    =    0)
--    BEGIN
--        --GOTO    ExitModule
--        RETURN    (@ReturnValue)
--    END




--ErrorHandler:
--RAISERROR    (@ErrorMessage, 16, 1)
--SET    @ReturnValue    =    -1




--ExitModule:

SET    NOCOUNT    OFF
RETURN    (@ReturnValue)


END
GO
IF  EXISTS (SELECT * FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[TCD].[ProcessModuleTags]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessModuleTags]
END
GO

CREATE PROCEDURE [TCD].[ProcessModuleTags]
(	
	@ModuleId INT,
	@ModuleTypeId INT,	
	@Reading DECIMAL(18,4),
	@TimeStamp DATETIME,
	@RollOverPoint INT
)

AS
SET NOCOUNT ON
BEGIN

DECLARE @PlantId int = NULL

SELECT @PlantId = p.PlantId FROM TCD.Plant p

		BEGIN
		
		
		 IF(@ModuleTypeId = 3)
		  BEGIN
		  IF NOT EXISTS(SELECT * FROM TCD.[SensorReading] WHERE SensorId=@ModuleId AND [TimeStamp]=@TimeStamp)
			BEGIN
				INSERT INTO [TCD].[SensorReading](
											  SensorId,
											  [Reading],
											  [TimeStamp]
 										   )
				VALUES
					(	@ModuleId,
						@Reading,
						@TimeStamp					
					)
			END			
		  END
		 ELSE
		  BEGIN
			DECLARE @MaxReading decimal(18,4),
				    @UsageReading decimal(18,4)
				    
			SELECT	@MaxReading  =  max(Reading) FROM TCD.ModuleReading where TimeStamp 
									in (select max(timestamp) from tcd.modulereading 
									where ModuleId = @ModuleId AND ModuleTypeId = @ModuleTypeId)
			IF(@MaxReading = 0.0000 OR @MaxReading IS NULL)
			BEGIN
			    SELECT @UsageReading = 0.0000
			END						
			ELSE IF(@Reading < @MaxReading)
			BEGIN
				SELECT @UsageReading = ((CAST(@RollOverPoint as decimal(18,4)) + @Reading)- @MaxReading)
			END
			ELSE
			BEGIN
				SELECT @UsageReading = (@Reading - @MaxReading)
			END									
			IF NOT EXISTS(SELECT * FROM TCD.[ModuleReading] WHERE [ModuleId]=@ModuleId AND [ModuleTypeId] = @ModuleTypeId AND [TimeStamp]=@TimeStamp)
			BEGIN
				INSERT INTO [TCD].[ModuleReading](
										   [ModuleId],
										   [ModuleTypeId],
										   [Reading],
										   [TimeStamp],
										   [Usage],
										   [PlantId]
										   )
				 VALUES
					(	@ModuleId,
						@ModuleTypeId,
						@Reading,
						@TimeStamp,
						@UsageReading,
						@PlantId
					)
			END			
		  END
			
		END		  		   
END
GO

--HoldTime changes - DCS - START
IF  EXISTS (SELECT * FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[TCD].[ProcessHoldSignal]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessHoldSignal]
END
GO

CREATE PROCEDURE [TCD].[ProcessHoldSignal]
	(	
	   @Controllerid INT
      ,@Washerid INT
      ,@Address		NVARCHAR(50)
      ,@Value		NVARCHAR(50)
      ,@Timestamp	DATETIME2
	)

AS
BEGIN

SET	NOCOUNT	ON														--SQLEnlight	SA0017

	DECLARE @HoldSignalParameterId  INT,
			@EcolabWasherId			INT			
	
	SELECT DISTINCT @EcolabWasherId=Ws.EcolabWasherId FROM TCD.Washer Ws WHERE Ws.WasherId=@WasherId AND Ws.Is_Deleted=0
	SELECT @HoldSignalParameterId=Id  FROM TCD.ConduitParameters where Name='HoldSignal'
	
IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp=@Timestamp)
   BEGIN
    INSERT INTO TCD.WasherReading(
         WasherId,
         ParameterId,
         ParameterValue,
         DateTimeStamp,
         PartitionOn,
         EcolabWasherId)
    SELECT    
		 @WasherId,
         @HoldSignalParameterId,
         @Value,
         @Timestamp,
         @Timestamp,
         @EcolabWasherId
   END   
END

GO
IF  EXISTS (SELECT * FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[TCD].[UpdateBatchParameterHoldTime]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[UpdateBatchParameterHoldTime]
END
GO

CREATE PROCEDURE [TCD].[UpdateBatchParameterHoldTime]
(
	@BatchId			INT,
	@BatchStartDate		DATETIME2,
	@BatchEndDate		DATETIME2,
	@WasherId			INT,
	@HoldTimePartitionOn DATETIME
)
AS

BEGIN

	SET	NOCOUNT	ON

	DECLARE @HoldTime INT,
			@HoldTimeParameterId INT,
			@EcolabWasherId INT

	SELECT DISTINCT @EcolabWasherId=Ws.EcolabWasherId FROM TCD.Washer Ws WHERE Ws.WasherId=@WasherId AND Ws.Is_Deleted=0

	IF EXISTS(SELECT TOP 1 * FROM TCD.WasherReading wr WHERE wr.WasherId=@WasherId AND wr.DateTimeStamp BETWEEN @BatchStartDate AND @BatchEndDate)
	BEGIN
		SELECT  ROW_NUMBER() OVER(ORDER BY wr.DateTimeStamp) as Row_Number, wr.ParameterId, wr.ParameterValue, wr.DateTimeStamp FROM TCD.WasherReading wr 
		WHERE wr.DateTimeStamp BETWEEN @BatchStartDate AND @BatchEndDate AND wr.WasherId=@WasherId 
		  ;WITH TempTable AS
		  (
			  SELECT  ROW_NUMBER() OVER(ORDER BY wr.DateTimeStamp) as Row_Number,wr.ParameterId, wr.ParameterValue, wr.DateTimeStamp FROM TCD.WasherReading wr 
			  WHERE wr.DateTimeStamp BETWEEN @BatchStartDate AND @BatchEndDate AND wr.WasherId=@WasherId 
		   )
		   SELECT tt.ParameterId, tt.ParameterValue, tt.DateTimeStamp, tt2.DateTimeStamp,DATEDIFF(second,tt2.DateTimeStamp, tt.DateTimeStamp) 
		   FROM TempTable tt INNER JOIN TempTable tt2 ON tt.Row_Number = tt2.Row_Number+1
			WHERE tt.ParameterValue = 0


		  ;WITH TempTable AS
		  (
			  SELECT  ROW_NUMBER() OVER(ORDER BY wr.DateTimeStamp) as Row_Number, wr.ParameterId, wr.ParameterValue, wr.DateTimeStamp FROM TCD.WasherReading wr 
			  WHERE wr.DateTimeStamp BETWEEN @BatchStartDate AND @BatchEndDate AND wr.WasherId=@WasherId
		   )
		   SELECT @HoldTime = sum(DATEDIFF(second,tt2.DateTimeStamp, tt.DateTimeStamp)) FROM TempTable tt INNER JOIN TempTable tt2 ON tt.Row_Number = tt2.Row_Number+1
			WHERE tt.ParameterValue = 0

			SELECT @HoldTimeParameterId=Id  FROM TCD.ConduitParameters where Name='HoldTime'
			INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) 
			SELECT @BatchId, @EcolabWasherId, @HoldTimeParameterId, @HoldTime, @HoldTimePartitionOn
	END
END	

GO
IF  EXISTS (SELECT * FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[TCD].[ProcessConventionalWasherData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessConventionalWasherData]
END
GO

CREATE PROCEDURE [TCD].[ProcessConventionalWasherData]
 ( 
 @WasherId INT, 
 @xmlTags XML,
 @RedFlagShiftId INT OUTPUT
)

AS
BEGIN
  DECLARE @BatchID        INT,
    @EcolabWasherId       INT,        
    @CurrencyCode       VARCHAR(50),  
    @MachineInternalId      INT,
    @GroupId        INT,  
    @Prveformula       INT,
    @Quantity        INT,
    @MaxWashertGroupCapacity    INT,

    @ProgramMasterId      INT,
    @NominalLoad       DECIMAL(10,2),
    @MaxLoad        DECIMAL(10,2),
    @StandardWeight       DECIMAL(10,2) ,     

    @CurrentFormula       INT,  
    @CurrentFormulaDate      DATETIME2,
    @FormulaIsModified      BIT,

    @CurrentInjection      INT,
    @CurrentInjectionDate     DATETIME2,
    @InjectionIsModified     BIT,

    @OperationalCount      INT,
    @OperationalIsModified     BIT, 
    
    @CurrentHoldSignal      INT,
    @CurrentHoldSignalDate     DATETIME2,
    @HoldSignalIsModified     BIT,  
             
    @EndofFormula       INT, 
    @EndofFormulaDate      DATETIME2,
    
    @AutoWeightEntryActive     BIT,
    @AutoWeightEntryWeight     DECIMAL(10,2),                                                                                                                              
    @ControllerId       INT,
    @CurrentHoldSignalValue     INT ,
    
    @MeterPlcAddress      INT,
    @MeterPlcAddressIsModified    INT,
    @BatchGroupId       INT,
    @BatchFormula       INT,    
    @HoldTime        INT,
    @CteTempBatchInjections     INT,
    @CteTempWaherReadingInjections   INT,
    @BatchStandardWaterUsage    INT,
    @BatchActualWaterUsage     INT,
    @BatchWaterUsagePrice     Decimal(10,2),
    @BatchUtilityPrice      Decimal(10,2),
    @BatchWaterType       INT,
    @PrevGroupId       INT,
    @WasherMeterExists      BIT,
    @ExtraTime        INT,
    @TargetTurnTime       INT,
    @RatioDosingEnabled      BIT,
 @EcolabAccountNumber NVARCHAR(25) = NULL,
 @PreviousFormulaDate      DATETIME2,
 @PreviousInjectionStep INT,
 @PreviousInjectionStartDate DATETIME2,
 @CurrentInjectionStep INT,
 @WashStepBatchId INT,
 @PrevFormulaExtraTime INT      ,
 @AlarmGroupMasterId INT,
 @StdWashSteps INT,
    @StdInjectionSteps INT,
 @EcolabTextileCategoryId INT,
 @ChainTextileCategoryId INT,
 @FormulaSegmentId INT,
 @EcolabSaturationId INT,
 @PlantProgramId INT,
 @PreviousShiftId INT,
 @CurrentShiftId INT,
 @HoldTimePartitionOn Datetime                                                                                                               

  SET @RedFlagShiftId = NULL
      
  IF EXISTS (SELECT  * FROM [TEMPDB].[DBO].[SYSOBJECTS] o where o.xtype in ('U') AND o.id = OBJECT_ID(N'tempdb..#XmlTagsTable'))
   BEGIN
     DROP TABLE #XmlTagsTable
   END


  CREATE TABLE  #XmlTagsTable ( TagId INT, 
          TagValue NVARCHAR(100), 
          ReceivedTime DATETIME2,
          TagType NVARCHAR(50),
          IsModified BIT
         )

 
  INSERT INTO #XmlTagsTable (
          TagId,
          TagValue,
          ReceivedTime,
          TagType,
          IsModified
         )   
  
  SELECT   
     T.c.value('@TagId', 'INT') as TagId,
     T.c.value('@Value', 'NVARCHAR(100)') TagValue,
     T.c.value('@TimeStamp', 'VARCHAR(100)') DateTimeStamp,
     T.c.value('@TagType', 'VARCHAR(50)') TagType,
     T.c.value('@IsModified', 'BIT') TagType
  FROM  @xmlTags.nodes('Tags/Tag') T(c)
  WHERE 
     T.c.value('@TagId', 'varchar(100)')  IS NOT NULL
 
  SELECT @CurrentFormula     =  TagValue,  
    @CurrentFormulaDate    =  ReceivedTime,
    @FormulaIsModified     =  IsModified
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_FRM'   
     
  SELECT @CurrentInjection    =  TagValue,
    @CurrentInjectionDate   =  ReceivedTime,
    @InjectionIsModified   =  IsModified   
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_INJ'

  SELECT @OperationalCount    =  TagValue,
    @OperationalIsModified   =  IsModified  
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_OPC'  
   
  SELECT @EndofFormula     =  TagValue,
    @EndofFormulaDate    =  ReceivedTime  
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_EOF' 
  
  SELECT @AutoWeightEntryActive   =  TagValue     
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_AWEA'                 

  SELECT @CurrentHoldSignal    =  TagValue, 
    @HoldSignalIsModified   =  IsModified,  
    @CurrentHoldSignalDate   =  ReceivedTime 
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_HOLDL'

  SELECT @AutoWeightEntryWeight   =  TagValue     
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_AWEW'

  SELECT @MeterPlcAddress    =  TagValue,
    @MeterPlcAddressIsModified  =       IsModified       
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_MPLC'
  
  SELECT @RatioDosingEnabled    =  TagValue      
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_RATA'
  
  SELECT * FROM #XmlTagsTable
  
  SELECT @ExtraTime      =  0

  SELECT TOP 1 @BatchID=BatchId, @Prveformula=ProgramNumber,@PrevGroupId=GroupId, @PreviousFormulaDate=StartDate FROM TCD.BatchData WHERE MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC

  IF(@PreviousFormulaDate is NOT NULL)
  BEGIN
	IF(@CurrentFormulaDate < @PreviousFormulaDate)
	BEGIN
		return
	END
  END

  IF(@CurrentFormula != @EndofFormula AND
     @CurrentFormula = @Prveformula AND 
  @CurrentInjection = 0 AND
  @OperationalCount = 0 AND
  @CurrentFormulaDate <= @PreviousFormulaDate AND
  @CurrentInjectionDate > @PreviousFormulaDate)
 BEGIN
 --Here means, If the same formula is received without EOF then the timestamp of the formula
 --will be still the old timestamp because value is not changed.
 --In this case assign injection=0 timestamp to formula timestamp
  SELECT @CurrentFormulaDate = @CurrentInjectionDate 
 END

  DECLARE @ShiftStartDate table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
  INSERT INTO @ShiftStartDate(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate

  SELECT DISTINCT 
     @EcolabWasherId    =  Ws.EcolabWasherId,
     @StandardWeight    =  Wps.NominalLoad,
     @CurrencyCode    =  Pl.CurrencyCode,
     @ControllerId    =  Ctrl.ControllerId,
     @TargetTurnTime    =  Ws.TargetTurnTime * 60     
  FROM 
     TCD.Washer Ws  
  INNER JOIN 
     TCD.MachineSetup Mst ON
     Mst.WasherId    =  Ws.WasherId
  INNER JOIN 
     TCD.WasherGroup Wg ON 
     Wg.WasherGroupId   =  Mst.GroupId    
  INNER JOIN 
     TCD.WasherProgramSetup Wps ON 
     Wps.WasherGroupId   =  Wg.WasherGroupId
  LEFT JOIN 
     TCD.WasherDosingSetup Wds ON 
     Wds.WasherProgramSetupId =  Wps.WasherProgramSetupId
  LEFT JOIN 
     TCD.WasherDosingProductMapping Wdpm ON 
     Wdpm.WasherDosingSetupId =  Wds.WasherDosingSetupId
  INNER JOIN 
     TCD.Plant Pl ON 
     Pl.EcolabAccountNumber  =  Ws.EcoLabAccountNumber
  INNER JOIN 
    TCD.ConduitController Ctrl 
    ON Ctrl.ControllerId   =  Mst.ControllerId 
  WHERE Ws.WasherId= @WasherId

  SELECT DISTINCT 
     @MachineInternalId=Mst.MachineInternalId,
     @GroupId=Mst.GroupId     
  FROM TCD.Washer Ws
      INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
      INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
      INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
   WHERE Ws.WasherId=@WasherId  

   SELECT DISTINCT      
     @ProgramMasterId=Wps.ProgramId,
     @NominalLoad=Wps.NominalLoad, --Wps.NominalLoad/CONVERT(decimal(10,2), 100) old code
     @MaxLoad =Ws.MaxLoad,
     @ExtraTime =Wps.ExtraTime
  FROM TCD.Washer Ws
      INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
      INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
      INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
      INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
   WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@CurrentFormula and Wps.Is_Deleted=0

  if(@ExtraTime IS NULL)
  BEGIN
   SELECT @ExtraTime      =  0
  END

  SELECT  @MaxWashertGroupCapacity=Max(ws.MaxLoad)
  FROM TCD.Washer WS
   INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
   INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId  
  WHERE Mst.GroupId=@GroupId

  SELECT @WasherMeterExists = M.MachineCompartment FROM Tcd.MachineSetup Ms
  INNER JOIN Tcd.Meter M ON M.GroupId= Ms.GroupId AND  M.MachineCompartment=Ms.MachineInternalId
  WHERE Ms.WasherId=@WasherId

  if(@AutoWeightEntryActive IS NULL)
  BEGIN
   SELECT @AutoWeightEntryActive = 0
  END

  SELECT @StandardWeight=(@NominalLoad * @MaxWashertGroupCapacity) /CONVERT(decimal(10,2), 100)   
  select @AutoWeightEntryActive,@StandardWeight
  SELECT @AutoWeightEntryWeight=Case @AutoWeightEntryActive WHEN 0 THEN @StandardWeight ELSE  @AutoWeightEntryWeight END  
  
  SELECT @CurrentHoldSignalValue=Id  FROM TCD.ConduitParameters where Name='HoldSignal'
  
   SELECT  * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC
  IF(@HoldSignalIsModified !=0)  
  BEGIN
  IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp =@CurrentHoldSignalDate)
   BEGIN
    INSERT INTO TCD.WasherReading(
         WasherId,
         ParameterId,
         ParameterValue,
         DateTimeStamp,
         PartitionOn,
         EcolabWasherId)
    SELECT    @WasherId,
         @CurrentHoldSignalValue,
         @CurrentHoldSignal,
         @CurrentHoldSignalDate,
         (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
         @EcolabWasherId
   END   
  END
  IF(@FormulaIsModified =1  OR @InjectionIsModified = 1 OR @OperationalIsModified = 1)
  BEGIN
   SELECT 'IsModified',@FormulaIsModified AS FormulaIsModified, 
        @InjectionIsModified AS InjectionIsModified,
        @OperationalIsModified AS OperationalIsModified
   IF(@CurrentFormula != 0)
   BEGIN
       DECLARE @BatchShiftId int,@BatchShiftStartDate datetime
       
       SELECT @BatchShiftStartDate = bd.StartDate FROM TCD.BatchData bd WHERE bd.BatchId = @BatchId

       IF(@BatchShiftStartDate > (SELECT TOP 1 [@ShiftStartDate].ShiftStartdate FROM @ShiftStartDate ORDER BY [@ShiftStartDate].ShiftStartdate ASC)
       AND DATEADD(second,@ExtraTime,@CurrentFormulaDate) > (SELECT TOP 1 [@ShiftStartDate].ShiftStartdate FROM @ShiftStartDate ORDER BY [@ShiftStartDate].ShiftStartdate DESC)
       )
       BEGIN 
         
         SELECT TOP 1  @BatchShiftId = ssdt.ShiftId FROM @ShiftStartDate ssdt ORDER BY ssdt.ShiftStartdate DESC
       END
       ELSE
       BEGIN
        SELECT TOP 1  @BatchShiftId = ssdt.ShiftId FROM @ShiftStartDate ssdt ORDER BY ssdt.ShiftStartdate ASC
       END
       

  SELECT DISTINCT      
   @PrevFormulaExtraTime =Wps.ExtraTime
   FROM TCD.Washer Ws
    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
    INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
    INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
    WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@Prveformula and Wps.Is_Deleted=0

  IF(@PrevFormulaExtraTime IS NULL)
  BEGIN
   SELECT @PrevFormulaExtraTime      =  0
  END

	SELECT Top 1 @HoldTimePartitionOn=ShiftStartdate from @ShiftStartDate

     IF(@CurrentFormula = @EndofFormula)
     BEGIN   
     SELECT * FROM #XmlTagsTable
      IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData 
           WHERE 
           BatchId=@BatchId AND 
           MachineId=@WasherId AND 
           EndDate IS NULL 
           ORDER BY StartDate DESC  )
       BEGIN
                                       
        UPDATE TCD.BatchData 
         SET EndDate = DATEADD(second,@PrevFormulaExtraTime,@CurrentFormulaDate),EndDateFormula = @CurrentFormulaDate,ShiftId = @BatchShiftId 
       WHERE  BatchId = @BatchId AND MachineId=@WasherId   
    
		EXEC TCD.UpdateBatchParameterHoldTime @BatchId, @PreviousFormulaDate, @CurrentFormulaDate, @WasherId, @HoldTimePartitionOn
    --DECLARE @ShiftMapping1 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
    --INSERT INTO @ShiftMapping1(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate,1, @RedFlagShiftId OUTPUT

    SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
      IF(@PreviousInjectionStep IS NOT NULL)
      BEGIN
       UPDATE TCD.BatchWashStepData SET EndTime=DATEADD(second,@ExtraTime,@CurrentFormulaDate) WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate
      END
                                                                   
       END 
     END 
     ELSE IF((@CurrentFormula != @Prveformula) AND (@BatchID IS NOT NULL))
     BEGIN  
     IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC  )
        BEGIN                          
         UPDATE TCD.BatchData
          SET EndDate = @CurrentFormulaDate,EndDateFormula = @CurrentFormulaDate,ShiftId = @BatchShiftId 
         WHERE  BatchId = @BatchId AND MachineId=@WasherId  
   
	 EXEC TCD.UpdateBatchParameterHoldTime @BatchId, @PreviousFormulaDate, @CurrentFormulaDate, @WasherId, @HoldTimePartitionOn

     INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,19,1,(SELECT Top 1 ShiftStartdate from @ShiftStartDate) 
     
   --  DECLARE @ShiftMapping2 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
   --INSERT INTO @ShiftMapping2(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate,1, @RedFlagShiftId OUTPUT
    
    SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
     IF(@PreviousInjectionStep IS NOT NULL)
     BEGIN
      UPDATE TCD.BatchWashStepData SET EndTime=@CurrentFormulaDate WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate
     END
       
        END 
      END
     ELSE IF((@CurrentInjection = 0) AND(@OperationalCount = 0) AND (@CurrentFormulaDate != @PreviousFormulaDate))
     BEGIN  
     IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC)
        BEGIN                           
         UPDATE TCD.BatchData
          SET EndDate = @CurrentInjectionDate,ShiftId = @BatchShiftId,EndDateFormula = @CurrentInjectionDate
         WHERE  BatchId = @BatchId AND MachineId=@WasherId  
   
    EXEC TCD.UpdateBatchParameterHoldTime @BatchId, @PreviousFormulaDate, @CurrentFormulaDate, @WasherId, @HoldTimePartitionOn
    INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,19,1,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)

   -- DECLARE @ShiftMapping3 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
   --INSERT INTO @ShiftMapping3(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentInjectionDate,1, @RedFlagShiftId OUTPUT
      
   SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
     IF(@PreviousInjectionStep IS NOT NULL)
     BEGIN
      UPDATE TCD.BatchWashStepData SET EndTime=@CurrentInjectionDate WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate
     END

        END 
      END
   
    -- Hold Time
     --IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
     -- BEGIN

      
     -- SELECT   @HoldTime=SUM(Wr.ParameterValue) FROM TCD. BatchData Bd
     -- INNER JOIN TCD.WasherReading Wr ON Wr.WasherId=Bd.MachineId
     -- WHERE Bd.BatchId=@BatchId  AND Wr.DateTimeStamp BETWEEN Bd.StartDate AND  Bd.EndDate and   Wr.ParameterId=9 -- Hold Signal value

     -- INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,17,@HoldTime,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)


     --END
     
     -- CapturingMeter Plc Address EndRedaing 
     IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
      BEGIN
      IF(@WasherMeterExists IS NOT NULL AND @MeterPlcAddress > 0)
      BEGIN
       IF(@MeterPlcAddressIsModified !=0)  
       BEGIN
       IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp =@CurrentFormulaDate)
       BEGIN
        INSERT INTO TCD.WasherReading(
         WasherId,
         ParameterId,
         ParameterValue,
         DateTimeStamp,
         PartitionOn,
         EcolabWasherId)
        SELECT 
         @WasherId,
         14, --MeterPlcAddress for EndSReading
         @MeterPlcAddress,
         @CurrentFormulaDate,
         (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
         @EcolabWasherId
       END

      END
      END
     END
         
     --Start Good or Bad Injection in BatchDataTable
     IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
      BEGIN
        ;WITH CteTempWaherReadingInjections  ( 
        InjectionsCount,BatchId,WasherId,ProgramNumber,Injectons
       ) AS  
       (
        SELECT DISTINCT Wr.ParameterValue,
            BD.BatchId,
            Wr.WasherId,
            Bd.ProgramNumber,
            Wr.ParameterValue FROM TCD. BatchData Bd
        INNER JOIN 
          TCD.WasherReading Wr ON Wr.WasherId   =  Bd.MachineId 
        WHERE    
              Wr.ParameterId    =  10    AND 
              Wr.ParameterValue   <>  0    AND 
              Bd.BatchId     =  @BatchID AND WR.DateTimeStamp BETWEEN BD.StartDate AND BD.EndDate) 
        SELECT @CteTempWaherReadingInjections=COUNT(CTE1.InjectionsCount)
        FROM CteTempWaherReadingInjections CTE1 
        INNER JOIN TCD.BatchData Bd ON Bd.BatchId=CTE1.BatchId
        WHERE Bd.BatchId=@BatchId

        ;WITH CteTempBatchInjections ( 
        InjectionsCount,BatchId,WasherId,ProgramNumber,Injectons
       ) AS  
       (
        SELECT  DISTINCT Wdpm.InjectionNumber,
            Bd.BatchId,
            Wps.ProgramNumber,
            Ws.WasherId,Wdpm.
            InjectionNumber
         FROM TCD.Washer WS
          INNER JOIN 
             TCD.MachineSetup Mst ON 
             Mst.WasherId     =  WS.WasherId
          INNER JOIN 
             TCD.WasherGroup Wg ON 
             Wg.WasherGroupId    =  Mst.GroupId       
          INNER JOIN 
             TCD.WasherProgramSetup Wps ON 
             Wps.WasherGroupId    =  Wg.WasherGroupId
          INNER JOIN 
             TCD.WasherDosingSetup Wds ON 
             Wds.WasherProgramSetupId  =  Wps.WasherProgramSetupId
          INNER JOIN 
             TCD.WasherDosingProductMapping Wdpm ON 
             Wdpm.WasherDosingSetupId  =  Wds.WasherDosingSetupID
          INNER JOIN 
             TCD.ProductdataMapping Pdm ON 
             Pdm.ProductId     =  Wdpm.ProductId
          INNER JOIN 
             TCD.BatchData Bd ON 
             Bd.MachineId     =  Ws.WasherId 
          INNER JOIN 
             TCD.WasherReading Wr ON 
             Wr.WasherId      =  Bd.MachineId
        WHERE 
        
             Wps.ProgramNumber    =  @Prveformula  AND 
             Bd.BatchId      =  @BatchID   AND 
             Ws.WasherId      =  @WasherId    )
        SELECT @CteTempBatchInjections=COUNT(CTE2.InjectionsCount)
        FROM CteTempBatchInjections CTE2 
        INNER JOIN TCD.BatchData Bd ON Bd.BatchId=CTE2.BatchId 
        WHERE Bd.BatchId=@BatchID


        Insert Tcd.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchID,@EcolabWasherId,18,
          CASE WHEN @CteTempBatchInjections = @CteTempWaherReadingInjections THEN 1
            WHEN @CteTempBatchInjections != @CteTempWaherReadingInjections THEN 3 END,
            (SELECT Top 1 ShiftStartdate from @ShiftStartDate) 
                           
    END
     --End Good or Bad Injection in BatchDataTable 
     IF(@OperationalCount = 0 AND @CurrentInjection = 0) AND (@CurrentFormula != @EndofFormula)
     BEGIN 
      IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchData WHERE MachineId=@WasherId AND StartDate =@CurrentFormulaDate)
      BEGIN     
       
	   --Start Rollup for previous completed shift
	   IF(CAST(@CurrentFormulaDate as date) < CAST(GETUTCDATE() as date))
	   BEGIN
		  SELECT TOP 1 @PreviousShiftId=ShiftId FROM TCD.BatchData WHERE MachineId=@WasherId ORDER BY StartDate DESC	   
		  SELECT Top 1 @CurrentShiftId = ShiftId from @ShiftStartDate
		  IF(@CurrentShiftId != @PreviousShiftId)
		  BEGIN
			 EXEC TCD.ProductionShiftDataRollup @PreviousShiftId, @RedFlagShiftId OUTPUT
			 IF(@RedFlagShiftId IS NULL)
			 BEGIN
				SET @RedFlagShiftId = @PreviousShiftId
			 END
		  END
	   END
	   --End Rollup for previous completed shift

       --Start Getting InjectionCount and StepCount
       SELECT 
       @StdInjectionSteps=count(DISTINCT wdpm.WasherDosingSetupId),
       @StdWashSteps= count(DISTINCT wds.WasherDosingSetupId)-count(DISTINCT wdpm.WasherDosingSetupId)
       FROM TCD.WasherDosingProductMapping wdpm
       RIGHT JOIN tcd.WasherDosingSetup wds on wdpm.WasherDosingSetupId=wds.WasherDosingSetupId
       WHERE wds.GroupId=@GroupId AND wds.ProgramNumber=@CurrentFormula
       --End Getting InjectionCount and StepCount
       --Start-----ProgramMasterID logic for PlantChainProgram
        SELECT 
        @PlantProgramId=pm.PlantProgramId,
        @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
        @ChainTextileCategoryId = pm.ChainTextileId,
        @FormulaSegmentId = pm.FormulaSegmentId,
        @EcolabSaturationId = pm.EcolabSaturationId 
        FROM TCD.ProgramMaster pm WHERE pm.ProgramId=@ProgramMasterId AND pm.Is_Deleted=0
        IF(@PlantProgramId <> 0  AND @PlantProgramId IS NOT NULL)
         BEGIN
            --Assign value from plantchainprogram table based on plantprogramId
            SELECT
             @EcolabTextileCategoryId = pcp.EcolabTextileCategoryId,
             @ChainTextileCategoryId = pcp.ChainTextileCategoryId,
             @FormulaSegmentId = pcp.FormulaSegmentId,
             @EcolabSaturationId = pcp.EcolabSaturationId
             FROM tcd.PlantChainProgram pcp
             WHERE pcp.PlantProgramId=@PlantProgramId AND pcp.Is_Deleted=0
         END
       --End-----ProgramMasterID logic for PlantChainProgram

       INSERT INTO TCD.BatchData(
          ControllerBatchId ,
          EcolabWasherId,
          GroupId ,
          MachineInternalId,
          PlantWasherNumber,
          StartDate ,
          EndDate ,
          ProgramNumber,
          ProgramMasterId,
          MachineId,
          ActualWeight,
          StandardWeight,
          CurrencyCode,
          ShiftId,         
          PartitionOn,
          TargetTurnTime,
          StdInjectionSteps,
          StdWashSteps,
          EcolabTextileCategoryId,
          ChainTextileCategoryId,
          FormulaSegmentId,
          EcolabSaturationId,
          PlantProgramId          
          )


         SELECT DISTINCT 0
          ,@EcolabWasherId
          ,@GroupId
          ,@MachineInternalId
          ,Ws.PlantWasherNumber
          ,@CurrentFormulaDate
          ,NULL
          ,@CurrentFormula
          ,@ProgramMasterId
          ,@WasherId
          ,@AutoWeightEntryWeight
          ,@StandardWeight 
          ,@CurrencyCode
          ,(SELECT Top 1 ShiftId from @ShiftStartDate)         
          ,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
          ,@TargetTurnTime
          ,@StdInjectionSteps
          ,@StdWashSteps
          ,@EcolabTextileCategoryId
          ,@ChainTextileCategoryId
          ,@FormulaSegmentId
          ,@EcolabSaturationId
          ,@PlantProgramId           

       FROM TCD.Washer Ws
          INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
          INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
          INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
       WHERE Ws.WasherId=@WasherId 
   
       SET @BatchID=SCOPE_IDENTITY() 
         
       INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,38,@StdWashSteps,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)

       --If the received formula is not configured in enVision then create an alarm 
       IF(@ProgramMasterId is NULL)
       BEGIN
       SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant;
       SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.AlarmGroupMsterVsControllerModelType AGMVCMT
       INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
       WHERE AGMVCMT.AlarmCode = 9000
        INSERT INTO [TCD].[AlarmData] 
           (EcoalabAccountNumber,
           AlarmCode,
           BatchId,
           controllerID,
           StartDate,
           GroupId,
           MachineInternalId,
           ProgramId,   
           IsActive,
           EndDate,
           MachineId,
           AlarmGroupMasterId,
		   PartitionOn)
           SELECT
            @ECOLABAccountNumber,
            9000,
            @BatchID,
            @ControllerId,
            @CurrentFormulaDate,
            @GroupId,
            @MachineInternalId,
            @CurrentFormula,
            0,
            @CurrentFormulaDate,
            @WasherId,
            @AlarmGroupMasterId,
			@CurrentFormulaDate
       END

         
         INSERT INTO TCD.BatchCustomerData
         (
         BatchId,
         CustomerId,
         Weight,
         PiecesCount,
         PartitionOn,
         EcolabWasherId
         )
        SELECT Bd.BatchId,  
        --SELECT @BatchID,
         Pc.ID,
         @AutoWeightEntryWeight,
         ROUND(COALESCE((@AutoWeightEntryWeight * Pm.Pieces) / NULLIF(Pm.Weight,0), 0),0),
         (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
         @EcolabWasherId
        
      
       FROM TCD.Washer WS
        INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
        INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId       
        INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
        INNER JOIN TCD.ProgramMaster Pm ON Pm.ProgramId=Wps.ProgramId
        INNER JOIN TCD.PlantCustomer Pc ON Pc.ID=Pm.CustomerId
        INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
       WHERE 
        Ws.WasherId=@WasherId AND 
        Wps.ProgramNumber=@CurrentFormula AND 
        Bd.BatchId=@BatchID  AND 
        Pm.CustomerId != -1 

       IF(@WasherMeterExists IS NOT NULL AND @MeterPlcAddress > 0)
       BEGIN        
        IF(@MeterPlcAddressIsModified !=0)  
        BEGIN
          INSERT INTO TCD.WasherReading(
           WasherId,
           ParameterId,
           ParameterValue,
           DateTimeStamp,
           PartitionOn,
           EcolabWasherId)
          SELECT 
           @WasherId,
           13, --MeterPlcAddress for StartReading
           @MeterPlcAddress,
           @CurrentFormulaDate,
           (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
           @EcolabWasherId
        END
       END 
      END              
     END      
     IF(@BatchID IS NOT NULL)     
     BEGIN
     IF(@CurrentInjection <= 0)
      BEGIN
       SET @CurrentInjectionDate=@CurrentFormulaDate
      END 
      IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp =@CurrentInjectionDate)
      BEGIN      
      INSERT INTO TCD.WasherReading(
          WasherId,
          ParameterId,
          ParameterValue,
          DateTimeStamp,
          PartitionOn,
          EcolabWasherId)
      SELECT   @WasherId,
          CASE TagType 
          WHEN 'Tag_FRM' THEN  5  
          WHEN 'Tag_INJ' THEN  10 
          WHEN 'Tag_OPC' THEN  11 
          END,
          TagValue,          
          @CurrentInjectionDate,
          (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
          @EcolabWasherId
       FROM  #XmlTagsTable 
       WHERE  Tagtype in ('Tag_FRM','Tag_INJ','Tag_OPC')         
     END
     END
    IF(@CurrentInjection > 0)     
     BEGIN
      IF (@RatioDosingEnabled = 1)
       BEGIN
       IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurrentInjectionDate and batchid=@BatchID)
       BEGIN
        INSERT INTO TCD.BatchProductData(BatchId,StepCompartment,ActualQuantity,StandardQuantity,Price,TimeStamp,PartitionOn,EcolabWasherId,ProductId)
        SELECT Bd.BatchId 
        --SELECT @BatchID 
         ,Wds.StepNumber
         ,(((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100)) * (@AutoWeightEntryWeight/@StandardWeight) AS ActualQuantity  
         ,(((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100)) * (@AutoWeightEntryWeight/@StandardWeight) AS StandardQuantity      
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * @MaxWashertGroupCapacity)/CONVERT(decimal(10,2), 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price         
         ,@CurrentInjectionDate
         ,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
         ,@EcolabWasherId
         ,Pdm.ProductID
        FROM TCD.Washer WS
         INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
         INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
         INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
         INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
         INNER JOIN TCD.WasherDosingSetup Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
         INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
         INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Wdpm.ProductId
         INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
        WHERE 
          Ws.WasherId=@WasherId     AND 
          Wps.ProgramNumber=@CurrentFormula  AND 
          Wdpm.InjectionNumber=@CurrentInjection AND
          Bd.BatchId=@BatchID AND
    Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
       END
       END
      ELSE
       BEGIN
       IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurrentInjectionDate and batchid=@BatchID)
       BEGIN
        INSERT INTO TCD.BatchProductData(BatchId,StepCompartment,ActualQuantity,StandardQuantity,Price,TimeStamp,PartitionOn,EcolabWasherId,ProductId)
        SELECT Bd.BatchId  
        --SELECT @BatchID
         ,Wds.StepNumber
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100) AS ActualQuantity  
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100) AS StandardQuantity      
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * @MaxWashertGroupCapacity)/CONVERT(decimal(10,2), 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price         
         ,@CurrentInjectionDate
         ,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
         ,@EcolabWasherId
         ,Pdm.ProductID
        FROM TCD.Washer WS
         INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
         INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
         INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
         INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
         INNER JOIN TCD.WasherDosingSetup Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
         INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
         INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Wdpm.ProductId
         INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
        WHERE 
          Ws.WasherId=@WasherId     AND 
          Wps.ProgramNumber=@CurrentFormula  AND 
          Wdpm.InjectionNumber=@CurrentInjection AND
          Bd.BatchId=@BatchID AND
    Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
       END  
       END 
       
  --Populating BatchWashstepdata
      SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
      
      IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchWashStepData WHERE StartTime =@CurrentInjectionDate and batchid=@BatchID)
      BEGIN
         SELECT @CurrentInjectionStep=Wds.StepNumber,
             @WashStepBatchId=Bd.BatchId
                 
         FROM TCD.Washer WS
          INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
          INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
          INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
          INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
          INNER JOIN TCD.WasherDosingSetup Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
          INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
          INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Wdpm.ProductId
          INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
         WHERE 
          Ws.WasherId=@WasherId     AND 
          Wps.ProgramNumber=@CurrentFormula  AND 
          Wdpm.InjectionNumber=@CurrentInjection AND
          Bd.BatchId=@BatchID AND
          Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0

         IF(@CurrentInjectionStep IS NOT NULL)
         BEGIN
          INSERT INTO TCD.BatchWashStepData(BatchId,StepCompartment,StartTime,PartitionOn,EcolabWasherId)
          VALUES (@WashStepBatchId,  @CurrentInjectionStep, @CurrentInjectionDate, (SELECT Top 1 ShiftStartdate from @ShiftStartDate), @EcolabWasherId)                
         
          UPDATE TCD.BatchWashStepData SET EndTime=@CurrentInjectionDate WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate         
         END

      END
      --End Populating BatchWashstepdata

      --Start Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
      IF NOT EXISTS(SELECT * FROM TCD.BatchParameters WHERE ParameterId =37 and batchid=@BatchID)
      BEGIN
       INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,37,1,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)       
      END
      ELSE
      BEGIN
       Update TCD.BatchParameters SET ParameterValue=@CurrentInjection WHERE ParameterId =37 and batchid=@BatchID
      END
        --End Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record

           
     END

     UPDATE TCD.ConduitController
      SET LastConnectedTime  = GETUTCDATE()
      WHERE ControllerId   = @ControllerId
   END
  END
 END

 GO
 -- HoldTime Changes - DCS - END
IF EXISTS(SELECT 1 FROM TCD.FieldGroupFieldMapping  WHERE FieldId = 218 AND Id = 304)
BEGIN
UPDATE tcd.FieldGroupFieldMapping
SET

FieldGroupId = 20
WHERE FieldId = 218
AND Id = 304

END
GO

IF EXISTS(SELECT 1 FROM TCD.Field  WHERE Id = 218)
BEGIN
UPDATE tcd.Field
SET
    tcd.Field.DisplayOrder = 5

    WHERE tcd.Field.Id = 218
END
GO

IF  EXISTS (SELECT * FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlTunnelWasherProdData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlTunnelWasherProdData]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ProcessMyControlTunnelWasherProdData](
	@ControllerID   INT,
	@xmlTags        XML,
	@PLCPointer     INT,
	@ReadPointer    INT,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @BatchID                 INT,
			  @WasherID                  INT,
			  @EcolabWasherId            INT,
			  @CurrencyCode              VARCHAR(50),
			  @MachineInternalId         INT,
			  @WasherGroupID             INT,
			  @PlantWasherNumber         INT,
			  @ProgramNumber             INT,
			  @Load                      DECIMAL(10, 2),
			  @NominalLoad               DECIMAL(10, 2),
			  @CustomerNumber            INT,
			  @PHStatus                  INT,
			  @PHValue                   INT,
			  @LFStatus                  INT,
			  @LFValue                   INT,
			  @BatchNumber               INT,
			  @TargetTurnTime            INT,
			  @PartitionOn               DATETIME2,
			  @BatchStartTime            DATETIME2,
			  @BatchEndTime              DATETIME2,
			  @ProgramID                 INT,
			  @NumberOfCompartments      INT,
			  @ProductId                 INT,
			  @CompartmentNum            INT,
			  @EquipmentType             INT,
			  @MinTempParamID            INT,
			  @MaxTempParamID            INT,
			  @TempStatusParamID         INT,
			  @PHValueParamID            INT,
			  @PHStatusParamID           INT,
			  @ConductivityValueParamID  INT,
			  @ConductivityStatusParamID INT,
			  @StdInjectionSteps         INT,
			  @StdWashSteps              INT,
			  @ActualInjSteps            INT,
			  @EcolabTextileCategoryId   INT,
			  @ChainTextileCategoryId    INT,
			  @FormulaSegmentId          INT,
			  @EcolabSaturationId        INT,
			  @PlantProgramId            INT,
			  @PreviousShiftId		    INT,
			  @CurrentShiftId		    INT,
			  @CurrentStepComportmentNO INT,
              @CounterNO                INT,
               @MeterID                 INT,
              @ActualQuantity          DECIMAL(18,4),
			  @BatchStepCount         INT,
			  @EcolabAccountNumber   VARCHAR(100),
			  @AlarmGroupMasterId    INT,
			  @StandardQuantity          DECIMAL(18, 4),
			  @Price                     DECIMAL(18, 4);

	    DECLARE @BatchShiftId INT;
	    DECLARE @ShiftStartDateTemp TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    DECLARE @TunnelXML XML;
	    SELECT @TunnelXML = T.c.query('.')
	    FROM @xmlTags.nodes('MyControlTunnel/TunnelData') T(c)
	    WHERE T.c.value('@CompartmentNumber', 'INT') = 0;

		
	    SELECT @MachineInternalID = T.c.value('@MachineNumber', 'int'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @BatchStartTime = T.c.value('@StartDateTime', 'DateTime'),
			 @BatchEndTime = T.c.value('@EndDateTime', 'DateTime'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@Nominalload', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'int'),
			 @PHStatus = T.c.value('@Phstatus', 'int'),
			 @PHValue = T.c.value('@Phvalue', 'INT'),
			 @LFStatus = T.c.value('@LFStatus', 'INT'),
			 @LFValue = T.c.value('@LFValue', 'INT')
	    FROM @xmlTags.nodes('MyControlTunnel/TunnelData') T(c);

		--Check for valid startdatetime
		IF(@BatchStartTime <='01/01/1900' OR @BatchStartTime > '06/06/2079')
		BEGIN
			return
		END

	    SELECT @EcolabWasherID = Ws.EcolabWasherId,
			 @WasherGroupID = Wg.WasherGroupId,
			 @PlantWasherNumber = PlantWasherNumber,
			 @WasherID = ws.WasherId,
			 @CurrencyCode = P.CurrencyCode,
			 @NumberOfCompartments = Mst.NumberofComp
	    FROM TCD.Washer Ws
		    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.
		    GroupId
		    INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId
		    = Wg.WasherGroupTypeId
		    INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId =
		    Mst.ControllerId
		    INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.
		    EcoLabAccountNumber
	    WHERE Ctrl.ControllerID = @ControllerID
			AND Mst.MachineInternalId = @MachineInternalID
			AND Mst.IsTunnel = 1 AND Mst.IsDeleted=0;
	    SELECT @EcolabWasherID;
	    SELECT @ProgramID = ProgramId,
			 @TargetTurnTime = (3600 / (tps.TotalRunTime /
			 @NumberOfCompartments))
	    FROM TCD.TunnelProgramSetup AS tps
	    WHERE tps.WasherGroupId = @WasherGroupID
			AND tps.is_deleted = 0
			AND ProgramNumber = @ProgramNumber;
	    DELETE FROM @ShiftStartDateTemp;
	    IF(@BatchEndTime IS NOT NULL)
		   BEGIN
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchEndTime
		   END;
	    ELSE
		   BEGIN
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchStartTime
		   END;
	    SELECT @BatchShiftId = ShiftID,
			 @PartitionOn = ShiftStartdate
	    FROM @ShiftStartDateTemp;


	    --Start Getting InjectionCount,StepCount And ProductCount
	    SELECT @StdInjectionSteps = COUNT(tdpm.TunnelDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT tds.TunnelDosingSetupId) -
			 COUNT(tdpm.TunnelDosingSetupId)
	    FROM tcd.TunnelDosingProductMapping tdpm
		    RIGHT JOIN tcd.TunnelDosingSetup tds ON tdpm.
		    TunnelDosingSetupId = tds.TunnelDosingSetupId
	    WHERE tds.GroupId = @WasherGroupID
			AND tds.ProgramNumber = @ProgramNumber;
	    --End Getting InjectionCount,StepCount And ProductCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramID
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT @EcolabTextileCategoryId = pcp. EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp. ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    SELECT @BatchID = NULL;
	    SELECT @BatchID = BatchID
	    FROM TCD.BatchData BD
	    WHERE BD.ControllerBatchId = @BatchNumber
			AND BD.StartDate = @BatchStartTime
			AND BD.MachineId = @WasherID;
	    --AND BD.MachineInternalID = @MachineInternalID
	    IF(@BatchID IS NULL)
		   BEGIN
		   --Start Rollup for previous completed shift
	   IF(CAST(@BatchStartTime as date) < CAST(GETUTCDATE() as date))
	   BEGIN
		  SELECT TOP 1 @PreviousShiftId=ShiftId FROM TCD.BatchData WHERE MachineId=@WasherId ORDER BY StartDate DESC	   
		  SELECT Top 1 @CurrentShiftId = ShiftId from @ShiftStartDateTemp
		  IF(@CurrentShiftId != @PreviousShiftId)
		  BEGIN
			 EXEC TCD.ProductionShiftDataRollup @PreviousShiftId, @RedFlagShiftId OUTPUT
			 IF(@RedFlagShiftId IS NULL)
			 BEGIN
				SET @RedFlagShiftId = @PreviousShiftId
			 END
		  END
	   END
	   --End Rollup for previous completed shift
			  INSERT INTO TCD.BatchData
			  (ControllerBatchId,
			   EcolabWasherId,
			   GroupId,
			   MachineInternalId,
			   PlantWasherNumber,
			   StartDate,
			   EndDate,
			   ProgramNumber,
			   ProgramMasterId,
			   MachineId,
			   ActualWeight,
			   StandardWeight,
			   CurrencyCode,
			   ShiftId,
			   PartitionOn,
			   TargetTurnTime,
			   StdInjectionSteps,
			   StdWashSteps,
			   EcolabTextileCategoryId,
			   ChainTextileCategoryId,
			   FormulaSegmentId,
			   EcolabSaturationId,
			   PlantProgramId,
			   EndDateFormula
			  )
				    SELECT @BatchNumber,
						 @EcolabWasherID,
						 @WasherGroupID,
						 @MachineInternalID,
						 @PlantWasherNumber,
						 @BatchStartTime,
						 @BatchEndTime,
						 @ProgramNumber,
						 @ProgramID,
						 @WasherID,
						 @Load,
						 @NominalLoad,
						 @CurrencyCode,
						 @BatchShiftId,
						 @PartitionOn,
						 @TargetTurnTime,
						 @StdInjectionSteps,
						 @StdWashSteps,
						 @EcolabTextileCategoryId,
						 @ChainTextileCategoryId,
						 @FormulaSegmentId,
						 @EcolabSaturationId,
						 @PlantProgramId,
						 @BatchEndTime;
			  SELECT @BatchID = SCOPE_IDENTITY();
			  IF(@StdWashSteps > 0
				OR @StdWashSteps <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchID,
							@EcolabWasherId,
							38,
							@StdWashSteps,
							@PartitionOn;
			  EXEC TCD.UPDATEBatchWashStepForTunnel
				  @TunnelXML,
				  @WasherID,
				  @BatchID,
				  @BatchStartTime,
				  @PartitionOn,
				  @EcolabWasherId,
				  @NumberOfCompartments;
		   END;
	    IF(@BatchEndTime IS NOT NULL
		  AND @BatchEndTime != '01/01/1900')
		   BEGIN
			  UPDATE TCD.BatchData
			    SET
				   EndDate = @BatchEndTime,
				   ShiftId = @BatchShiftId,
				   PartitionOn = @PartitionOn,
				   EndDateFormula=@BatchEndTime
			  WHERE BATCHID = @BatchID;
		   END;

		      --If the received formula is not configured in enVision then create an alarm 
       IF(@ProgramID is NULL)
       BEGIN
       SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant;
       SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.AlarmGroupMsterVsControllerModelType AGMVCMT
       INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
       WHERE AGMVCMT.AlarmCode = 9000
        INSERT INTO [TCD].[AlarmData] 
           (EcoalabAccountNumber,
           AlarmCode,
           BatchId,
           controllerID,
           StartDate,
           GroupId,
           MachineInternalId,
           ProgramId,   
           IsActive,
           EndDate,
           MachineId,
           AlarmGroupMasterId)
           SELECT
            @ECOLABAccountNumber,
            9000,
            @BatchID,
            @ControllerId,
            @BatchStartTime,
            @WasherGroupID,
            @MachineInternalID,
            @ProgramNumber,
            0,
            @BatchStartTime,
            @WasherId,
            @AlarmGroupMasterId
       END


	    IF(@CustomerNumber IS NOT NULL)
		   BEGIN
			  IF NOT EXISTS
			  (
				 SELECT 1
				 FROM [TCD].[BatchCustomerData]
				 WHERE BatchID = @BatchID
			  )
				 BEGIN
					INSERT INTO [TCD].[BatchCustomerData]
					([BatchId],
					 CustomerID,
					 [Weight],
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @BatchID,
							    @CustomerNumber,
							    @Load,
							    @PartitionOn,
							    @EcolabWasherId;
				 END;
		   END;
	    CREATE TABLE #DosingDetails
	    (
		    Number          INT,
		    Quantity        DECIMAL(10, 6),
		    Point           INT,
		    IsMainEquioment INT
	    );
	    INSERT INTO #DosingDetails
	    (Number,
		Quantity,
		Point,
		IsMainEquioment
	    )
			 SELECT T.c.value('@Number', 'INT') AS Number, --PumpNumber
				   T.c.value('@Quantity', 'Decimal(10,6)') AS Quantity, --Dosing Quanity
				   T.c.value('@Point', 'INT') AS Point, --Dosing point
				   T.c.value('@IsMainEquioment', 'INT') AS
			 IsMainEquioment
			 FROM @xmlTags.nodes('MyControlTunnel/TunnelData/Dose') T(C)
	    ;
	
	    -- Fetching data from cursor
	    DECLARE @MYCURSOR CURSOR;
	    SET @MYCURSOR = CURSOR FAST_FORWARD
	    FOR SELECT Number,
				Quantity,
				Point,
				IsMainEquioment
		   FROM #DosingDetails;
	    DECLARE @Number          INT,
			  @Quantity        DECIMAL(10, 6),
			  @Point           INT,
			  @IsMainEquioment INT;
	    OPEN @MYCURSOR;
	    FETCH NEXT FROM @MYCURSOR INTO @Number,
								@Quantity,
								@Point,
								@IsMainEquioment;
	    WHILE @@FETCH_STATUS = 0
		   BEGIN
			  IF(@IsMainEquioment = 1)
				 BEGIN
					SET @EquipmentType = 2;
				 END;
			  ELSE
				 BEGIN
					SET @EquipmentType = 1;
				 END;
			  SELECT @ProductId = CES.ProductId,
				    @CompartmentNum = TCEVM.CompartmentNumber
			  FROM tcd.ControllerEquipmentSetup CES
				  INNER JOIN TCD.
				  TunnelCompartmentEquipmentValveMapping TCEVM ON CES.
				  ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
			  WHERE CES.ControllerId = @ControllerID
				   AND CES.ControllerEquipmentTypeId = @EquipmentType
				   AND --CES.IsActive=1 AND
				   --CES.WasherGroupNumber=@WasherGroupNum AND
				   TCEVM.DosingPointNumber = @Point
				   AND CES.ControllerEquipmentId = @Number;
				
			 SELECT DISTINCT
				    @StandardQuantity =((Wps.NominalLoad * Wdpm.Quantity) / 100),
				    @Price = (((Wps.NominalLoad * Wdpm.Quantity) / 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID))
			  FROM TCD.Washer WS
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =Mst.GroupId
				  INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
				  INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
				  INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
				  INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON
				  Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
				  INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId = Wdpm.ControllerEquipmentSetupId
				  INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId = Ces.ProductId
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wds.CompartmentNumber = @CompartmentNum
				   AND Wps.Is_Deleted = 0
				   AND Pdm.Is_Deleted = 0;
				
			  IF(@ProductId IS NOT NULL)
				 BEGIN
					INSERT INTO TCD.BatchProductData
					(
						  BatchId,
						  StepCompartment,
						  ActualQuantity,
						  StandardQuantity,
						  Price,
						  [TimeStamp],
						  PartitionOn,
						  EcolabWasherId,
						  ProductId
					)
					SELECT
						  @BatchID,
						  @CompartmentNum,
						  @Quantity,
						  isnull(@StandardQuantity,0),
						  isnull(@Price,0),
						  @BatchEndTime,
						  @PartitionOn,
						  @EcolabWasherID,
						  @ProductId;
				 END;
			  FETCH NEXT FROM @MYCURSOR INTO @Number,
									   @Quantity,
									   @Point,
									   @IsMainEquioment;
		   END;
	    CLOSE @MYCURSOR;
	    DEALLOCATE @MYCURSOR;
	    DROP TABLE #DosingDetails;
	    SELECT @ActualInjSteps = COUNT(DISTINCT StepCompartment)
	    FROM TCD.BatchProductData
	    WHERE BatchId = @BatchID;
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.BatchParameters
		   WHERE ParameterId = 37
			    AND batchid = @BatchID
			    AND @ActualInjSteps > 0
	    )
		   BEGIN
			  IF(@ActualInjSteps > 0
				OR @ActualInjSteps <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchId,
							@EcolabWasherId,
							37,
							@ActualInjSteps,
							@PartitionOn;
		   END;
	    ELSE
		   BEGIN
			  UPDATE TCD.BatchParameters
			    SET
				   ParameterValue = @ActualInjSteps
			  WHERE ParameterId = 37
				   AND batchid = @BatchID;
		   END;
	    SELECT @MinTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Mimum Temperature';
	    SELECT @MaxTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Maximum Temperature';
	    SELECT @TempStatusParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Temperature Status';
	    SELECT @PHValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH';
	    SELECT @PHStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH Status';
	    SELECT @ConductivityValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Conductivity';
	    SELECT @ConductivityStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'LF Status';
	    IF(@PHValue IS NOT NULL)
		   BEGIN
			  --pH Value
			  IF(@PHValue <> 0
				OR @PHValue <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @PHValueParamID,
					   @PHValue,
					   @PartitionOn
				 );

			  --pH Status
			  IF(@PHStatus <> 0
				OR @PHStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @PHStatusParamID,
					   @PHStatus,
					   @PartitionOn
				 );
		   END;
	    IF(@LFValue IS NOT NULL)
		   BEGIN
			  --Conductivity Value
			  IF(@LFValue <> 0
				OR @LFValue <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @ConductivityValueParamID,
					   @LFValue,
					   @PartitionOn
				 );

			  --Conductivity Status
			  IF(@LFStatus <> 0
				OR @LFStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @ConductivityStatusParamID,
					   @LFStatus,
					   @PartitionOn
				 );
		   END;
	    CREATE TABLE #TemperatureDetails
	    (
		    MinimumTemp DECIMAL(10, 2),
		    MaximumTemp DECIMAL(10, 2),
		    TempStatus  DECIMAL(10, 2)
	    );
	    INSERT INTO #TemperatureDetails
	    (MinimumTemp,
		MaximumTemp,
		TempStatus
	    )
			 SELECT T.c.value('@Minimum', 'Decimal(10,2)') AS
			 MinimumTemp,
				   T.c.value('@Maximum', 'Decimal(10,2)') AS
				   MaximumTemp,
				   T.c.value('@Status', 'Decimal(10,2)') AS TempStatus
			 FROM @xmlTags.nodes(
			 'MyControlTunnel/TunnelData/TemperatureData'
							) T(c);
	  
	    -- Fetching data from cursor
	    DECLARE @TEMPCURSOR CURSOR;
	    SET @TEMPCURSOR = CURSOR FAST_FORWARD
	    FOR SELECT MinimumTemp,
				MaximumTemp,
				TempStatus
		   FROM #TemperatureDetails;
	    DECLARE @MinimumTemp DECIMAL(10, 2),
			  @MaximumTemp DECIMAL(10, 2),
			  @TempStatus  DECIMAL(10, 2);
	    OPEN @TEMPCURSOR;
	    FETCH NEXT FROM @TEMPCURSOR INTO @MinimumTemp,
								  @MaximumTemp,
								  @TempStatus;
	    WHILE @@FETCH_STATUS = 0
		   BEGIN	
			  --Minimum Temperature
			  IF(@MinimumTemp <> 0
				OR @MinimumTemp <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @MinTempParamID,
					   @MinimumTemp,
					   @PartitionOn
				 );

			  --Maximum Temperature
			  IF(@MaximumTemp <> 0
				OR @MaximumTemp <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @MaxTempParamID,
					   @MaximumTemp,
					   @PartitionOn
				 );

			  --Temperature Status
			  IF(@TempStatus <> 0
				OR @TempStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @TempStatusParamID,
					   @TempStatus,
					   @PartitionOn
				 );
			  FETCH NEXT FROM @TEMPCURSOR INTO @MinimumTemp,
										@MaximumTemp,
										@TempStatus;
		   END;
	    CLOSE @TEMPCURSOR;
	    DEALLOCATE @TEMPCURSOR;
	    DROP TABLE #TemperatureDetails;
	    UPDATE TCD.BatchWashStepData
		 SET
			EndTime = DATEADD(ss,
						  (SELECT T.c.value('@Time', 'INT')
							 FROM @TunnelXML.nodes('TunnelData/CompartmentTime') T(c)
							 WHERE T.c.value('@CompartmentNo','INT') =
							 (
								SELECT
									  bwsd.StepCompartment
								FROM tcd.BatchWashStepData bwsd
								WHERE bwsd.BatchId = @BatchID
									 AND bwsd.EndTime IS NULL
							 )
						  ),
						  (
							 SELECT
								   bwsd.StartTime
							 FROM tcd.BatchWashStepData bwsd
							 WHERE bwsd.BatchId = @BatchID
								  AND bwsd.EndTime IS NULL
						  ))
	    WHERE
			BatchId = @BatchID
			AND EndTime IS NULL;
   
   --Start water consumption per batch


    CREATE TABLE #WaterConsumptionData
     (
      Number          INT,
      Quantity        DECIMAL(18,4),
     );
     INSERT INTO #WaterConsumptionData
     (Number,
  Quantity
     )
    SELECT T.c.value('@Counter', 'INT') AS Number, --PumpNumber
       T.c.value('@Value', 'DECIMAL(18,4)') AS Quantity --Water Quanity
    FROM @xmlTags.nodes('MyControlTunnel/TunnelData/WaterConsumption') T(C);

  
  SET @CurrentStepComportmentNO=1;

  WHILE(@CurrentStepComportmentNO<=22)
  BEGIN
  
   SELECT @MeterID=MeterId,@CounterNO=mt.CounterNum
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@CurrentStepComportmentNO

    SELECT @ActualQuantity=wc.Quantity
  FROM #WaterConsumptionData wc where wc.Number=@CounterNo
  SELECT @BatchStepCount=COUNT(1) FROM TCD.BatchStepWaterUsageData WHERE BatchId=@BatchID  AND StepCompartment =@CurrentStepComportmentNO AND ActualQuantity=@ActualQuantity 
  IF (@BatchStepCount=0)
  BEGIN
  IF(ISNULL(@BatchID,0)>0  AND ISNULL(@MeterID,0)>0 AND ISNULL(@ActualQuantity,0)>0)
  BEGIN

   INSERT INTO TCD.BatchStepWaterUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
      EcolabWasherId
     )
     SELECT
     @BatchID,
     @CurrentStepComportmentNO,
     @ActualQuantity,
     @PartitionOn,
     @EcolabWasherId
      END 
	  END 
      SET  @CurrentStepComportmentNO=@CurrentStepComportmentNO+1;  
  END;
 END;

GO

 IF  EXISTS (SELECT * FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[TCD].[GetBatchTrendingGroupData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetBatchTrendingGroupData]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[GetBatchTrendingGroupData] (@GroupId int )
AS 
SET NOCOUNT ON
BEGIN 

DECLARE @DayId Varchar(20) = NULL,
    @StartTime DateTime = NULL,
    @EndTime DateTime = NULL,
    @TransferStarttime Time = NULL,
    @TransferEndtime Time = NULL,
    @MachineId int = NULL,
    @ParameterId int = NULL,
    @ParameterValue  Int = NULL,
    @WasherStatus Int,
 @RegionId  Int = NULL,
 @EcoLabAccountNumber Varchar(50) = NULL

DECLARE @NoofComp Int = NULL, 
    @Count int = 1

SELECT @NoOfcomp = NumberOfComp FROM [TCD].machinesetup 
  WHERE Groupid = @GroupId and IsTunnel = 1

DECLARE @GET_COMPARTMENT TABLE (
   GroupId INT,
   MachineID INT,
   CompartmentNumber VARCHAR(1000))

WHILE(@count <=  @NoOfcomp) 
BEGIN
   INSERT INTO @GET_COMPARTMENT(GroupId,MachineID,CompartmentNumber)
    SELECT @GroupId,@count,'Compartment'+ cast(@count as Varchar(1000))+''
   SET @count = @count + 1
End

DECLARE @TrendingData TABLE(
    BatchId INT,
    CustomerId INT,
    ProgramId INT,
    ActualLoad DECIMAL(10,2),
    NominalLoad DECIMAL(10,2),
    GroupId INT,
    CompartmentId INT,
    --DupCount INT,
    Efficiency DECIMAL(10,2),
    Temparature  DECIMAL(10,2),
    Conductivity  DECIMAL(10,2),
    PH  DECIMAL(10,2)) 

Declare @DummyTrendingData TABLE(
    BatchId INT,
    CustomerId INT,
    ProgramId INT,
    ActualLoad DECIMAL(10,2),
    NominalLoad DECIMAL(10,2),
    GroupId INT,
    CompartmentId INT,
    --DupCount INT,
    Efficiency DECIMAL(10,2),
    Temparature  DECIMAL(10,2),
    Conductivity  DECIMAL(10,2),
    PH  DECIMAL(10,2)) 
   
INSERT INTO @TrendingData(
    BatchId ,
    CustomerId ,
    ProgramId ,
    ActualLoad,
    NominalLoad ,
    GroupId ,
    CompartmentId ,
    --DupCount INT,
    Efficiency ,
    Temparature ,
    Conductivity,
    PH) 


     SELECT DISTINCT
             BA.BatchId,
             BC.CustomerId,
             BA.ProgramNumber,
             BA.[ActualWeight],
             BA.[StandardWeight],
             BA.GroupId,
             BS.StepCompartment,
			 CASE WHEN BA.[StandardWeight] <> 0 THEN (BA.[ActualWeight]/BA.[StandardWeight]) * 100 ELSE 0 END  AS LoadEfficiency,
             --(BA.[ActualWeight]/BA.[StandardWeight]) * 100 AS LoadEfficiency,
             TE.Reading AS Temparature,
             CO.Reading AS Conductivity,
             PH.Reading AS PH

        FROM [TCD].BatchWashStepData AS BS
             INNER JOIN [TCD].BatchData BA ON BA.BatchId = BS.BatchId
             LEFT OUTER JOIN [TCD].BatchCustomerData BC ON BC.BatchId = BA.BatchId
             LEFT OUTER JOIN (SELECT SS.GroupId,
                            SS.MachineCompartment,
                            MR.Reading
                        FROM TCD.ModuleReading MR INNER JOIN TCD.Sensor SS ON MR.ModuleId = SS.SensorId WHERE MR.ModuleTypeId = 3 AND SS.SensorType = 1) TE
             ON BA.GroupId = TE.GroupId AND BS.StepCompartment = TE.MachineCompartment
              LEFT OUTER JOIN (SELECT SS.GroupId,
                            SS.MachineCompartment,
                            MR.Reading
                        FROM TCD.ModuleReading MR INNER JOIN TCD.Sensor SS ON MR.ModuleId = SS.SensorId WHERE MR.ModuleTypeId = 3 AND SS.SensorType = 4) CO
             ON BA.GroupId = CO.GroupId AND BS.StepCompartment = CO.MachineCompartment

    LEFT OUTER JOIN (SELECT SS.GroupId,
                            SS.MachineCompartment,
                            MR.Reading
                        FROM TCD.ModuleReading MR INNER JOIN TCD.Sensor SS ON MR.ModuleId = SS.SensorId WHERE MR.ModuleTypeId = 3 AND SS.SensorType = 2) PH
             ON BA.GroupId = CO.GroupId AND BS.StepCompartment = CO.MachineCompartment

        WHERE BS.EndTime IS NULL AND BA.EndDate IS NULL
        AND BA.GroupId = @GroupId 
		--AND BA.StandardWeight > 0  
		--AND BA.ActualWeight > 0 

  Select @MachineId = WasherId,@EcoLabAccountNumber=EcoalabAccountNumber from tcd.MachineSetup where GroupId = @GroupId
  Select top 1 @ParameterId =  ParameterId ,@Parametervalue = ParameterValue from TCD.washerReading where WasherId = @MachineId order by DateTimeStamp desc
  select top 1 @RegionId = RegionId from TCD.Plant where EcolabAccountNumber=@EcoLabAccountNumber

  If(@ParameterId = 6 and @Parametervalue = 0)
   BEGIN
    set @WasherStatus = 1
   END
  Else If (@ParameterId = 6 and @Parametervalue = 1)
   BEGIN
    set @WasherStatus = 2
   END
  Else If (@ParameterId = 12)
   BEGIN
    set @WasherStatus = 0
   END

  INSERT INTO @DummyTrendingData(BatchId,CustomerId,ProgramId,ActualLoad,NominalLoad,GroupId,CompartmentId,Efficiency,Temparature,Conductivity,PH)
    SELECT 0,0,0,0,0,GroupId,MachineID,0,0,0,0 FROM @GET_COMPARTMENT

    IF(@WasherStatus != 2)
    BEGIN
    UPDATE  D  SET

      D.BatchId = C.BatchId, 
      D.CustomerId =  CASE WHEN C.ActualLoad = 0 THEN 0
       ELSE 
      C.CustomerId END,
      D.ProgramId = C.ProgramId,
      D.ActualLoad = C.ActualLoad,
      D.NominalLoad = C.NominalLoad,
      D.GroupId = CASE WHEN C.GroupId = 0 THEN C.GroupId ELSE D.GroupId END,
      D.CompartmentId =  CASE WHEN C.CompartmentId IS NOT NULL THEN C.CompartmentId ELSE D.CompartmentId END,
      D.Efficiency = CAST(C.Efficiency AS decimal(10,2)),
      D.Temparature = CAST(C.Temparature AS decimal(10,2)),
      D.Conductivity = CAST(C.Conductivity AS decimal(10,2)),
      D.PH = CAST(C.PH AS decimal(10,2)) 
      FROM @DummyTrendingData D LEFT OUTER JOIN @TrendingData C ON D.CompartmentId = C.CompartmentId

   END
       SELECT 
      ISNULL(BatchId,0) AS BatchId,
      ISNULL(CustomerId,0) AS CustomerId,
      ISNULL(ProgramId,0) AS ProgramId,
   (CASE WHEN (@RegionId=1) THEN ISNULL(ActualLoad,0) ELSE ROUND((ISNULL(ActualLoad,0)*0.453592),0) END) AS ActualLoad,
   (CASE WHEN (@RegionId=1) THEN ISNULL(NominalLoad,0) ELSE ROUND((ISNULL(NominalLoad,0)*0.453592),0) END) AS NominalLoad,
      ISNULL(GroupId,0) AS GroupId,
      ISNULL(CompartmentId,0) AS CompartmentId,
      ISNULL(Efficiency,0) AS Efficiency,
      ISNULL(Temparature,0) AS Temparature,
      ISNULL(Conductivity,0) AS Conductivity,
      ISNULL(PH,0) AS PH
       FROM @DummyTrendingData
  END
GO
IF  EXISTS (SELECT * FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[TCD].[GetDispencerRecordedLoads]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetDispencerRecordedLoads]
END
GO

CREATE PROCEDURE [TCD].[GetDispencerRecordedLoads] 
(
    @GroupId        NVARCHAR(1000)        =   NULL
  , @MachineId        INT                 =   NULL
  , @ProgramId       INT                 =   NULL
  , @StartDate        DATETIME            =   NULL
  , @RowsPerPage INT =50
  , @PageNumber INT = 1
  ,	@EndDate	DATETIME            =   NULL
)
AS 

  BEGIN
  SET NOCOUNT ON

	IF(@ProgramId = 0)      
    BEGIN      
		SET @ProgramId = NULL      
    END    
    
   IF @PageNumber < 1 
   BEGIN
		SET @PageNumber = 1 
   END

   SET @startdate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@startdate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@startdate AS time)) AS DateTime))  
   SET @EndDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndDate AS time)) AS DateTime))  

   SELECT	bd.BatchId,
			CAST(StartDate AS datetime) AS StartDate,
			COALESCE(bd.ManualInputWeight,bd.ActualWeight), 
			bd.ProgramNumber,
			pm.Name,
			Count(*) Over() TotalRows ,  
			bd.EcolabWasherId    
	FROM TCD.BatchData bd
	INNER JOIN TCD.ProductionShiftData psd ON psd.ShiftId = bd.ShiftId
	INNER JOIN TCD.ProgramMaster pm ON pm.ProgramId = bd.ProgramMasterId
	WHERE bd.EndDate IS NOT NULL 
	AND bd.MachineId = @MachineId
	AND bd.ProgramNumber = COALESCE(@ProgramId, bd.ProgramNumber )
	AND psd.StartDateTime Between @StartDate AND @EndDate
	ORDER BY bd.BatchId
   OFFSET (@PageNumber-1)*@RowsPerPage ROWS
   FETCH NEXT @RowsPerPage ROWS ONLY

 SET NOCOUNT OFF
  END
  
  --Changes for Alarms. Fix for populating correct end date. - START
GO

IF  EXISTS (SELECT * FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[TCD].[ProcessNowTags]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessNowTags]
END
GO

CREATE PROCEDURE [TCD].[ProcessNowTags]
(	
	@ControllerId INT,	
	@xmlTags XML
)

AS
SET NOCOUNT ON
BEGIN
		DECLARE @BatchID INT,
				@AlarmCode INT,				
				@GroupId INT,		
				@Valve INT,
				@ProgramId INT,
				@MachineNumber INT,
				@InjectionNumber INT,
				@WasherId INT,
				@MachineId INT,
				@ECOLABAccountNumber nvarchar(25),
				@AlarmDate DATETIME2,
				@AlarmGroupMasterId INT

						
		IF EXISTS (SELECT  * FROM TEMPDB.DBO.SYSOBJECTS o where o.xtype in ('U') AND o.id = OBJECT_ID(N'tempdb..#XmlTagsTable'))
			BEGIN
					DROP TABLE #XmlTagsTable
			END


		CREATE TABLE  #XmlTagsTable (	TagId INT, 
										TagValue INT, 
										ReceivedTime DATETIME2,
										TagType NVARCHAR(50)
									)

	
		INSERT INTO #XmlTagsTable	(
										TagId,
										TagValue,
										ReceivedTime,
										TagType
									)			
		
		SELECT 		
					T.c.value('@TagId', 'INT') as TagId,
					T.c.value('@Value', 'INT')	TagValue,
					T.c.value('@TimeStamp', 'varchar(100)') DateTimeStamp,
					T.c.value('@TagType', 'varchar(50)') TagType
		FROM		@xmlTags.nodes('Tags/Tag') T(c)
		WHERE	
					T.c.value('@TagId', 'varchar(100)')  IS NOT NULL
				
			
		SELECT	@AlarmCode					=		TagValue,		
				@AlarmDate					=		ReceivedTime
		FROM	#XmlTagsTable 
		WHERE	TagType						=		'NowMessage'			
					
		SELECT @Valve						=		TagValue	    FROM #XmlTagsTable WHERE TagType='NowValve'

		SELECT @ProgramId					=		TagValue		FROM #XmlTagsTable WHERE TagType='NowFormula'	
		
		SELECT @MachineNumber				=		TagValue		FROM #XmlTagsTable WHERE TagType='NowWasher'	
		
		SELECT @WasherId = WasherID, @GroupId = GroupId, @MachineId = WasherId FROM TCD.MachineSetup WHERE MachineInternalId = @MachineNumber and ControllerId = @ControllerId
		
		SELECT @BatchID = BatchId FROM TCD.BatchData WHERE MachineId = @WasherId and EndDate IS NULL ORDER BY StartDate DESC
				
		SELECT @InjectionNumber = MAX(ParameterValue) FROM TCD.WasherReading where ParameterId = 10 --WHERE MachineInternalId = @MachineNumber
		
		SELECT @ECOLABAccountNumber = EcolabAccountNumber FROM TCD.Plant 

																					
		IF(@AlarmCode = 0)
		  BEGIN
			--UPDATE TCD.AlarmData SET IsActive = 0, EndDate = getutcdate() WHERE controllerID = @controllerID
			UPDATE TCD.AlarmData SET IsActive = 0, EndDate = @AlarmDate WHERE controllerID = @controllerID AND IsActive=1 AND AlarmCode NOT IN (9000,9001,9002)
		  END
		
		 IF(@AlarmCode is NOT NULL AND @AlarmCode  <> 0)
    
		  BEGIN

		  IF NOT EXISTS(SELECT TOP 1 * FROM TCD.AlarmData WHERE StartDate=@AlarmDate AND ControllerId=@ControllerId AND AlarmCode=@AlarmCode)
		  BEGIN

			SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.ConduitController CC 
			INNER JOIN TCD.ControllerModelControllerTypeMapping CMCTM ON CMCTM.ControllerModelId = CC.ControllerModelId AND CMCTM.ControllerTypeId = CC.ControllerTypeId
			INNER JOIN TCD.AlarmGroupMsterVsControllerModelType AGMVCMT ON CMCTM.Id = AGMVCMT.ControllerModelTypeId
			INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
			WHERE AGMVCMT.AlarmCode = @AlarmCode AND CC.ControllerId = @ControllerId

			INSERT INTO [TCD].[AlarmData] 
			(EcoalabAccountNumber,
			AlarmCode,
			BatchId,
			controllerID,
			StartDate,
			GroupId,
			MachineInternalId,
			Valve,
			ProgramId,			
			InjectionNumber,
			IsActive,
			MachineId,
			AlarmGroupMasterId,
			PartitionOn)
		    SELECT
			    @ECOLABAccountNumber,
			    @AlarmCode,
			    @BatchID,
			    @ControllerId,
			    @AlarmDate,
			    @GroupId,
			    @MachineNumber,
			    @Valve,
			    @ProgramId,
			    @InjectionNumber,
			    1,
			    @MachineId,
				@AlarmGroupMasterId,
				@AlarmDate
		  END
		 END	
		  	   
	END

	GO

    IF  EXISTS (SELECT * FROM sys.objects 
    WHERE object_id = OBJECT_ID(N'[TCD].[UpdateControllerConnectivityAlarm]') AND type in (N'P', N'PC'))
    BEGIN
    DROP PROCEDURE [TCD].[UpdateControllerConnectivityAlarm]
    END
    GO

    CREATE PROCEDURE [TCD].[UpdateControllerConnectivityAlarm]
( 
    @Controllerid INT,
	@AlarmCode INT,
    @IsActive BIT
)

AS
BEGIN

	SET NOCOUNT ON              --SQLEnlight SA0017

	DECLARE
		@ECOLABAccountNumber	NVARCHAR(1000),
		@AlarmGroupMasterId		INT;
	IF NOT EXISTS(SELECT * FROM TCD.AlarmData WHERE controllerID = @ControllerId AND AlarmCode = @AlarmCode AND IsActive = 1)
	BEGIN
		IF(@IsActive = 1)
		BEGIN
			SELECT @ECOLABAccountNumber = EcolabAccountNumber FROM TCD.Plant;
			SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.AlarmGroupMsterVsControllerModelType AGMVCMT
			INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
			WHERE AGMVCMT.AlarmCode = @AlarmCode;
			INSERT INTO [TCD].[AlarmData]
				(EcoalabAccountNumber,
					AlarmCode,
					controllerID,
					IsActive,
					StartDate,
					AlarmGroupMasterId,
					PartitionOn
				)
			SELECT
				@ECOLABAccountNumber,
				@AlarmCode,
				@Controllerid,
				@IsActive,
				GETUTCDATE(),
				@AlarmGroupMasterId,
				GETUTCDATE()
		END
	END
	
	ELSE
	BEGIN
		IF(@IsActive = 0)
		BEGIN
			UPDATE [TCD].[AlarmData] SET IsActive=@IsActive, EndDate=GETUTCDATE() WHERE controllerID = @ControllerId AND AlarmCode = @AlarmCode AND IsActive=1
		END
	END
 
END

GO

--Changes for Alarms. Fix for populating correct end date. - START

---------------------------------------------------Start Mycontrol timeout issue for tunnel online changes-------------------------------------------------
IF EXISTS
(
    SELECT
		 *
    FROM sys.objects
    WHERE object_id = OBJECT_ID(
    N'[TCD].[ProcessMyControlTunnelWasherOnlineData]')
		AND type IN(N'P', N'PC')
)
    BEGIN
	   DROP PROCEDURE
		   [TCD].[ProcessMyControlTunnelWasherOnlineData];
    END;
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE PROCEDURE [TCD].[ProcessMyControlTunnelWasherOnlineData]
(
	@ControllerID   INT,
	@xmlTags        XML,
	@RedFlagShiftId INT OUTPUT
)
AS
	BEGIN
	    DECLARE @BatchID                  INT,
			  @WasherID                 INT,
			  @EcolabWasherId           INT,
			  @CurrencyCode             VARCHAR(50),
			  @MachineInternalId        INT,
			  @WasherGroupID            INT,
			  @PlantWasherNumber        INT,
			  @ProgramNumber            INT,
			  @Load                     DECIMAL(10, 2),
			  @NominalLoad              DECIMAL(10, 2),
			  @CustomerNumber           INT,
			  @PHStatus                 INT,
			  @BatchNumber              INT,
			  @TargetTurnTime           INT,
			  @PartitionOn              DATETIME,
			  @BatchStartTime           DATETIME,
			  @ProgramID                INT,
			  @NumberOfCompartments     INT,
			  @TransferSignalId         INT,
			  @BatchShiftId             INT,
			  @compartmentID            INT,
			  @TunnelXML                XML,
			  @TempXML                  XML,
			  @StdInjectionSteps        INT,
			  @StdWashSteps             INT,
			  @EcolabTextileCategoryId  INT,
			  @ChainTextileCategoryId   INT,
			  @FormulaSegmentId         INT,
			  @EcolabSaturationId       INT,
			  @PlantProgramId           INT,
			  @CurrentStepComportmentNO INT,
			  @CounterNO                INT,
			  @MeterID                  INT,
			  @ActualQuantity           DECIMAL(10, 6),
			  @WasherModuleCount        INT;
	    SELECT
			 @TransferSignalId = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Transfer Signal';
	    CREATE TABLE #Batches
	    (
		    BatchNumber   INT,
		    StartDateTime DATETIME
	    );
	    SELECT
			 @TempXML = T.c.query('.')
	    FROM @xmlTags.nodes('MyControlTunnel') AS T(c);
	    SELECT
			 @MachineInternalID = T.c.value('@MachineNumber', 'int')
	    FROM @TempXML.nodes('MyControlTunnel') AS T(c);
	    SELECT
			 @EcolabWasherID = EcolabWasherId,
			 @WasherGroupID = Wg.WasherGroupId,
			 @PlantWasherNumber = PlantWasherNumber,
			 @WasherID = ws.WasherId,
			 @CurrencyCode = P.CurrencyCode,
			 @NumberOfCompartments = Mst.NumberofComp
	    FROM TCD.Washer AS Ws
		    INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = Ws.WasherId
		    INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
		    INNER JOIN TCD.WasherGroupType AS WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
		    INNER JOIN TCD.ConduitController AS Ctrl ON Ctrl.ControllerId = Mst.ControllerId
		    INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.
		    EcoLabAccountNumber
	    WHERE Ctrl.ControllerID = @ControllerID
			AND mst.MachineInternalId = @MachineInternalID
			AND Mst.IsTunnel = 1
			AND Mst.IsDeleted = 0;
	    SET @compartmentID = @NumberOfCompartments;
	    WHILE(@compartmentID <= @NumberOfCompartments
			AND @compartmentID > 0)
		   BEGIN
			  SELECT
				    @TunnelXML = T.c.query('.')
			  FROM @xmlTags.nodes('MyControlTunnel/TunnelData') AS T(c)
			  WHERE T.c.value('@CompartmentNumber', 'INT') =
			  @compartmentID;
			  SELECT
				    @MachineInternalID = T.c.value('@MachineNumber','int'),
				    @BatchNumber = T.c.value('@BatchNumber', 'INT'),
				    @BatchStartTime = T.c.value('@StartDateTime','DateTime'),
				    @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
				    @Load = T.c.value('@Load', 'Decimal(10,6)'),
				    @NominalLoad = T.c.value('@Nominalload','Decimal(10,6)'),
				    @CustomerNumber = T.c.value('@CustomerNumber','int'),
				    @PHStatus = T.c.value('@pHStatus', 'int')
			  FROM @TunnelXML.nodes('TunnelData') AS T(c);
			   --Check for valid startdatetime
			 IF(@BatchStartTime <='01/01/1900' OR @BatchStartTime > '06/06/2079')
			 BEGIN
			  return
			 END
			  DECLARE @ShiftStartDateTemp TABLE
			  (
				  ShiftId        INT,
				  ShiftName      NVARCHAR(50),
				  ShiftStartdate DATETIME
			  );
			  INSERT INTO @ShiftStartDateTemp
			  (
				    ShiftId,
				    ShiftName,
				    ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchStartTime;
			  SELECT
				    @BatchShiftId = ShiftID,
				    @PartitionOn = ShiftStartdate
			  FROM @ShiftStartDateTemp;
			  IF(@ProgramNumber = 0
				OR @BatchNumber = 1)
				 BEGIN
					SELECT
						  @compartmentID = @compartmentID - 1;
					CONTINUE;
				 END;
			  SELECT
				    @ProgramID = ProgramId,
				    @TargetTurnTime = 3600 / (tps.TotalRunTime /
				    @NumberOfCompartments)
			  FROM TCD.TunnelProgramSetup AS tps
			  WHERE tps.WasherGroupId = @WasherGroupID
				   AND tps.is_deleted = 0
				   AND ProgramNumber = @ProgramNumber;
			  INSERT INTO #Batches
			  (
				    BatchNumber,
				    StartDateTime
			  )
			  SELECT
				    @BatchNumber,
				    @BatchStartTime;
			  SELECT
				    @BatchID = NULL;
			  SELECT
				    @BatchID = BatchID
			  FROM TCD.BatchData AS BD
			  WHERE BD.ControllerBatchId = @BatchNumber
				   AND BD.StartDate = @BatchStartTime
				   AND BD.MachineId = @WasherID;
			  --Start Getting InjectionCount,StepCount And ProductCount
			  SELECT
				    @StdInjectionSteps = COUNT(tdpm.TunnelDosingSetupId),
				    @StdWashSteps = COUNT(DISTINCT tds.TunnelDosingSetupId) - COUNT(tdpm.TunnelDosingSetupId)
			  FROM tcd.TunnelDosingProductMapping AS tdpm
				  RIGHT JOIN tcd.TunnelDosingSetup AS tds ON tdpm.TunnelDosingSetupId = tds.TunnelDosingSetupId
			  WHERE tds.GroupId = @WasherGroupID
				   AND tds.ProgramNumber = @ProgramNumber;
			  --End Getting InjectionCount,StepCount And ProductCount
			  --Start-----ProgramMasterID logic for PlantChainProgram
			  SELECT
				    @PlantProgramId = pm.PlantProgramId,
				    @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pm.ChainTextileId,
				    @FormulaSegmentId = pm.FormulaSegmentId,
				    @EcolabSaturationId = pm.EcolabSaturationId
			  FROM TCD.ProgramMaster AS pm
			  WHERE pm.ProgramId = @ProgramID
				   AND pm.Is_Deleted = 0;
			  IF(@PlantProgramId <> 0
				OR @PlantProgramId IS NOT NULL)
				 BEGIN
					--Assign value from plantchainprogram table based on plantprogramId
					SELECT
						  @EcolabTextileCategoryId = pcp.EcolabTextileCategoryId,
						  @ChainTextileCategoryId = pcp.ChainTextileCategoryId,
						  @FormulaSegmentId = pcp.FormulaSegmentId,
						  @EcolabSaturationId = pcp.EcolabSaturationId
					FROM tcd.PlantChainProgram AS pcp
					WHERE pcp.PlantProgramId = @PlantProgramId
						 AND pcp.Is_Deleted = 0;
				 END;
			  --End-----ProgramMasterID logic for PlantChainProgram
			  IF @BatchID IS NULL
				 BEGIN
					INSERT INTO TCD.BatchData
					(
						  ControllerBatchId,
						  EcolabWasherId,
						  GroupId,
						  MachineInternalId,
						  PlantWasherNumber,
						  StartDate,
						  ProgramNumber,
						  ProgramMasterId,
						  MachineId,
						  ActualWeight,
						  StandardWeight,
						  CurrencyCode,
						  ShiftId,
						  PartitionOn,
						  TargetTurnTime,
						  StdInjectionSteps,
						  StdWashSteps,
						  EcolabTextileCategoryId,
						  ChainTextileCategoryId,
						  FormulaSegmentId,
						  EcolabSaturationId,
						  PlantProgramId
					)
					SELECT
						  @BatchNumber,
						  @EcolabWasherID,
						  @WasherGroupID,
						  @MachineInternalID,
						  @PlantWasherNumber,
						  @BatchStartTime,
						  @ProgramNumber,
						  @ProgramID,
						  @WasherID,
						  @Load,
						  @NominalLoad,
						  @CurrencyCode,
						  @BatchShiftId,
						  @PartitionOn,
						  @TargetTurnTime,
						  @StdInjectionSteps,
						  @StdWashSteps,
						  @EcolabTextileCategoryId,
						  @ChainTextileCategoryId,
						  @FormulaSegmentId,
						  @EcolabSaturationId,
						  @PlantProgramId;
					SELECT
						  @BatchID = SCOPE_IDENTITY();
					IF(@StdWashSteps > 0
					   OR @StdWashSteps <> NULL)
					    BEGIN
						   INSERT INTO TCD.BatchParameters
						   (
								BatchId,
								EcolabWasherId,
								ParameterId,
								ParameterValue,
								PartitionOn
						   )
						   SELECT
								@BatchID,
								@EcolabWasherId,
								38,
								@StdWashSteps,
								@PartitionOn;
					    END;
					IF @CustomerNumber IS NOT NULL
					    BEGIN
						   IF NOT EXISTS
						   (
							  SELECT
								    1
							  FROM TCD.BatchCustomerData
							  WHERE BatchID = @BatchID
						   )
							  BEGIN
								 INSERT INTO TCD.BatchCustomerData
								 (
									   BatchId,
									   CustomerID,
									   Weight,
									   PartitionOn,
									   EcolabWasherId
								 )
								 SELECT
									   @BatchID,
									   @CustomerNumber,
									   @Load,
									   @PartitionOn,
									   @EcolabWasherId;
							  END;
					    END;
				 END;
			  -- Transfer Signal
			  IF NOT EXISTS
			  (
				 SELECT
					   *
				 FROM tcd.WasherReading wr
				 WHERE wr.WasherId = @WasherID
					  AND wr.ParameterId = @TransferSignalId
					  AND wr.DateTimeStamp = @BatchStartTime
			  )
				 BEGIN
					INSERT INTO TCD.WasherReading
					(
						  WasherId,
						  ParameterId,
						  ParameterValue,
						  DateTimeStamp,
						  PartitionOn,
						  EcolabWasherId
					)
					SELECT
						  @WasherID,
						  @TransferSignalId,
						  1,
						  @BatchStartTime,
						  @PartitionOn,
						  @EcolabWasherId
					UNION ALL
					SELECT
						  @WasherID,
						  @TransferSignalId,
						  0,
						  @BatchStartTime,
						  @PartitionOn,
						  @EcolabWasherId;
				 END;
			  --Start Updating Batch Wash Step Data  
			  CREATE TABLE #BatchWashStepData
			  (
				  Compartment_No  INT,
				  Step_Time       INT,
				  Batch_StartDate DATETIME
			  );
			  INSERT INTO #BatchWashStepData
			  (
				    Compartment_No,
				    Step_Time,
				    Batch_StartDate
			  )
			  SELECT
				    T.c.value('@CompartmentNo', 'INT'),
				    T.c.value('@Time', 'INT'),
				    T.c.value('../@StartDateTime', 'Datetime')
			  FROM @TunnelXML.nodes('TunnelData/CompartmentTime') T(c);
			  WITH CTE
				  AS (SELECT
						   a.Compartment_No,
						   a.Step_Time,
						   a.Batch_StartDate,
						   SUM(b.Step_Time) AS TotalSeconds
					 FROM #BatchWashStepData a
						 CROSS JOIN #BatchWashStepData b
					 WHERE b.Compartment_No <= a.Compartment_No
					 GROUP BY
							a.Compartment_No,
							a.Step_Time,
							a.Batch_StartDate --ORDER BY a.Compartment_No
					 ),
				  CTE2
				  AS (SELECT
						   c.*,
						   DATEADD(ss, c.TotalSeconds, c.Batch_StartDate)
						   Step_End
					 FROM CTE c
					 WHERE c.Step_Time > 0)
				  MERGE INTO TCD.BatchWashStepData bpd
				  USING
				  (
					 SELECT
						   p.*,
						   LAG(p.Step_End, 1, p.Batch_StartDate)
						   OVER(ORDER BY p.Compartment_No) AS
						       Step_StartTime,
						   CASE
							  WHEN p.Compartment_No =
							  @compartmentID
							  THEN NULL
							  WHEN p.Compartment_No <>
							  @compartmentID
							  THEN p.Step_End
						   END Step_EndTIme
					 FROM CTE2 p
				  ) temp
				  ON bpd.BatchId = @BatchID
					AND bpd.StepCompartment = temp.Compartment_No
					 WHEN MATCHED
					 THEN UPDATE SET
								  StartTime = temp.Step_StartTime,
								  EndTime = temp.Step_EndTIme
					 WHEN NOT MATCHED
					 THEN INSERT(
							   BatchId,
							   StepCompartment,
							   StartTime,
							   EndTime,
							   PartitionOn,
							   EcolabWasherId) VALUES
				  (
												 @BatchId,
												 temp.
												 Compartment_No,
												 temp.
												 Step_StartTime,
												 temp.
												 Step_EndTIme,
												 @PartitionOn,
												 @EcolabWasherID
				  );
			  DROP TABLE #BatchWashStepData;
			  --End Updating Batch Wash Step Data  
			  SELECT
				    @compartmentID = @compartmentID - 1;
		   END;
		    WITH XmlData
		    AS (SELECT
					m.MeterId,
					m.CounterNum                              Meter_Counter,
					T.c.value('../@CompartmentNumber', 'INT') CompNo, --Compartment No
					T.c.value('@Counter', 'INT') AS           Xml_Counter, --PumpNumber
					T.c.value('@Value', 'DECIMAL(10,6)') AS   Quantity	    --Water Quanity
			   FROM @xmlTags.nodes(
					'MyControlTunnel/TunnelData/WaterConsumption'
							  ) T(C)
				   INNER JOIN TCD.Meter m ON m.UtilityType = 2
									    AND m.GroupId =
									    @WasherGroupID
									    AND m.ControllerID =
									    @ControllerID
									    AND m.MachineCompartment
									    = T.c.value('../@CompartmentNumber',
									    'INT'
												)
				   AND m.CounterNum = T.c.value('@Counter', 'INT')
			   WHERE T.c.value('@Value', 'DECIMAL(10,6)') > 0)
		    MERGE INTO TCD.WasherModuleOnlineUsageData
		    USING
		    (
			   SELECT
					*
			   FROM XmlData
		    ) temp
		    ON WasherId = @WasherID
			  AND StepComportment = temp.CompNo
			  AND ModuleId = temp.MeterId
			  AND ActualQuantity = temp.Quantity
			   WHEN NOT MATCHED AND(temp.Quantity <> NULL
							    OR temp.Quantity <> 0)
			   THEN INSERT(
							 WasherId,
							 StepComportment,
							 ModuleId,
							 ActualQuantity,
							 TimeStamp,
							 EcolabWasherId
						) 
						VALUES
						(
							@WasherID,
							temp.CompNo,
							temp.MeterId,
							temp.Quantity,
							GETUTCDATE(),
							@EcolabWasherId
						 );
	END;
	GO
---------------------------------------------------End Mycontrol timeout issue for tunnel online changes-------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[TCD].[ValidateAlarmsSave]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ValidateAlarmsSave]
END
GO

CREATE	PROCEDURE	[TCD].[ValidateAlarmsSave]
		@ControllerModelId							INT
	,	@ControllerTypeId							INT
	,	@MachineNumber								INT
	,	@EcolabAccountNumber						NVARCHAR(25)
	,	@MaxNoOfRec									INT
AS
BEGIN

SET	NOCOUNT	ON


DECLARE	
		@ReturnValue					int				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''


IF (
	(
		SELECT DISTINCT COUNT(*)
		FROM 
		[TCD].AlarmStatus A
		INNER JOIN [TCD].AlarmGroupMsterVsControllerModelType AGMVCMT ON AGMVCMT.AlarmGroupMsterVsControllerModelTypeId = A.[AlarmGroupMsterVsControllerModelTypeId]
		INNER JOIN [TCD].AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
		INNER JOIN TCD.ControllerModelControllerTypeMapping cmctm ON AGMVCMT.ControllerModelTypeId = cmctm.Id
		WHERE		
		--cmctm.ControllerModelId		= @ControllerModelId
		--AND
		--cmctm.ControllerTypeId		= @ControllerTypeId
		--AND 
		--A.MachineNumber				= @MachineNumber
		--AND
		A.EcolabAccountNumber		= @EcolabAccountNumber
		) <> @MaxNoOfRec
	)
	BEGIN
				SET		@ErrorId						=			51030
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record count does not match.'
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
	END

SET	NOCOUNT	OFF

RETURN	(@ReturnValue)

END
GO


IF  EXISTS (SELECT * FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[TCD].[GetPumpsAndMECount]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetPumpsAndMECount]
END
GO

CREATE PROCEDURE [TCD].[GetPumpsAndMECount](@controllerId INT
          , @EcolabAccountNumber NVARCHAR(25))
AS
BEGIN
 
 SET NOCOUNT ON;

  DECLARE
   @plantId INT = (SELECT P.PlantId
        FROM TCD.Plant P
        WHERE P.EcolabAccountNumber = @EcolabAccountNumber);

  DECLARE @controllerModelId INT
  DECLARE @controllerTypeId INT

  SELECT 
   @controllerModelId = CC.ControllerModelId , 
   @controllerTypeId = CC.ControllerTypeId 
 FROM TCD.ConduitController CC 
 WHERE CC.ControllerId = @controllerId and CC.EcoalabAccountNumber = @Ecolabaccountnumber

 SELECT PumpValveCount as Pumps,
   MECount as equipments
 FROM 
   TCD.ControllerModelControllerTypeMapping CMCTM
 WHERE CMCTM.ControllerModelId = @controllerModelId 
  AND CMCTM.ControllerTypeId = @controllerTypeId

 SET NOCOUNT OFF;
END
GO
-----------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[CopyConventionalFormula]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[CopyConventionalFormula]
END
GO
CREATE PROCEDURE [TCD].[CopyConventionalFormula]
		 @SubstituteMissingChemical				 TCD.SubstituteMissingChemical	READONLY	
    ,    @ToWasherGroupId                            INT								=            NULL
    ,    @FromWasherGroupId                          INT								=            NULL
    ,    @ProgramNumber                              SMALLINT							=            NULL 
    ,    @WasherProgramSetupId                       INT								=            NULL
    ,    @ProgramId                                  INT								=            NULL
    ,    @EcoLabAccountNumber                        NVARCHAR(25)						=            NULL
    ,    @UserId                                     INT								=            NULL
    ,    @ProgramSetupId                             INT								=            NULL   OUTPUT 
	

AS
BEGIN
    SET NOCOUNT ON;

    DECLARE      @TotalNumberOfPrograms      SMALLINT        =       NULL
    ,            @ReturnValue                INT             =       0
    ,            @ErrorId                    INT             =       0
    ,            @ErrorMessage               NVARCHAR(4000)  =       N''
    ,            @MaxNumberOfPrograms        SMALLINT        =       127

    DECLARE
                @OutputList                                AS    TABLE        (
                OutputProgramSetupId                       INT
        )

    --ProgramNumber check
    IF    (    @ProgramNumber                >            @MaxNumberOfPrograms)
    BEGIN
            SET        @ErrorId                        =            51002
            SET        @ErrorMessage                    =            N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Invalid ProgramNumber... Aborting.'
            --GOTO    ErrorHandler
            RAISERROR    (@ErrorMessage, 16, 1)
            SET    @ReturnValue    =    -1
            RETURN    (@ReturnValue)
    END

        IF    EXISTS    (        SELECT    1
                                FROM    [TCD].WasherProgramSetup            WPS
                                WHERE    WPS.EcolabAccountNumber        =            @EcoLabAccountNumber
                                    AND    WPS.WasherGroupId            =            @ToWasherGroupId
                                    AND    WPS.ProgramNumber            =            @ProgramNumber
                                    AND    WPS.Is_Deleted                =            'FALSE'
                        )
                    BEGIN
                            SET        @ErrorId                        =            51001
                            SET        @ErrorMessage                    =            N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Specified ProgramNumber for the WasherGroup already exists for the plant.'
                            --GOTO    ErrorHandler
                            RAISERROR    (@ErrorMessage, 16, 1)
                            SET    @ReturnValue    =    -1
                            RETURN    (@ReturnValue)
                    END

        SELECT @TotalNumberOfPrograms        =            COUNT(WPS.ProgramNumber)
        FROM   [TCD].WasherProgramSetup      AS           WPS
        WHERE  WPS.EcolabAccountNumber       =            @EcoLabAccountNumber
        AND    WPS.WasherGroupId             =            @ToWasherGroupId
        AND    WPS.Is_Deleted                =            'FALSE'
    
        IF (@TotalNumberOfPrograms           =            @MaxNumberOfPrograms)
            BEGIN
                    SET        @ErrorId        =            51000
                    SET        @ErrorMessage    =            N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Maximum Number of programs that can be associated to a WasherGroup already defined... Aborting.'
                    RAISERROR  (@ErrorMessage, 16, 1)
                    SET            @ReturnValue    =    -1
                    RETURN        (@ReturnValue)
            END

        INSERT INTO TCD.WasherProgramSetup
        (
            EcolabAccountNumber,
            WasherGroupId,
            ProgramNumber,
            ProgramId,
            NominalLoad,
            LoadsPerMonth,
            TotalRunTime,
            ExtraTime,
            TotalSteps,
            CoolDownStep,
            FinalExtractingTime,
            Category,
            CustomProgramName,
            PlantProgramNumber,
            NumberOfDrains,
            DrainTime,
            Rewash,
            CleanWt,
            CleanAw,
            CustomerId,
            Is_Deleted,
            LastModifiedByUserId,
            MyServiceCustFrmulaMchGrpGUID,
            LastModifiedTime
        )
        OUTPUT
            inserted.WasherProgramSetupId    AS    Id
        INTO
            @OutputList(
                    OutputProgramSetupId
                       )
        SELECT    wps.EcolabAccountNumber
        ,        @ToWasherGroupId
        ,        @ProgramNumber
        ,        @ProgramId
        ,        wps.NominalLoad
        ,        wps.LoadsPerMonth
        ,        wps.TotalRunTime
        ,        wps.ExtraTime
        ,        wps.TotalSteps
        ,        wps.CoolDownStep
        ,        wps.FinalExtractingTime
        ,        wps.Category
        ,        wps.CustomProgramName
        ,        wps.PlantProgramNumber
        ,        wps.NumberOfDrains
        ,        wps.DrainTime
        ,        wps.Rewash
        ,        wps.CleanWt
        ,        wps.CleanAw
        ,        wps.CustomerId
        ,        'False'
        ,        @UserId
        ,        NEWID()
        ,        GETUTCDATE()
        FROM TCD.WasherProgramSetup wps
        WHERE wps.EcolabAccountNumber    =    @EcoLabAccountNumber
        AND      wps.WasherGroupId            =    @FromWasherGroupId
        AND      wps.WasherProgramSetupId    =    @WasherProgramSetupId

        --check for any error
            SET    @ErrorId    =    @@ERROR
    
            IF    (@ErrorId    <>    0)
                BEGIN
                        SET    @ReturnValue    =    -1
                        RETURN    (@ReturnValue)
                END

        SELECT  TOP 1 @ProgramSetupId    =   O.OutputProgramSetupId FROM @OutputList O
        
        INSERT INTO TCD.WasherDosingSetup
        (
            --WasherDosingSetupId - this column value is auto-generated
            EcoLabAccountNumber,
            WasherProgramSetupId,
            GroupId,
            ProgramNumber,
            StepNumber,
            StepTypeId,
            ProductId,
            StepRunTime,
            Quantity,
            [Delay],
            ResourceDetailId,
            MENumber,
            Temperature,
            WaterType,
            WaterLevel,
            DrainDestinationId,
            pHLevel,
            Note,
            Is_Deleted,
            LastModifiedByUserId,
            StandardWeight,
            MyServiceCustFrmulaStpGUID,
            StandardWaterUsage
        )
        SELECT    wds.EcoLabAccountNumber
        ,        @ProgramSetupId
        ,        @ToWasherGroupId
        ,        @ProgramNumber
        ,        wds.StepNumber
        ,        wds.StepTypeId
        ,        wds.ProductId
        ,        wds.StepRunTime
        ,        wds.Quantity
        ,        wds.[Delay]
        ,        wds.ResourceDetailId
        ,        wds.MENumber
        ,        wds.Temperature
        ,        wds.WaterType
        ,        wds.WaterLevel
        ,        wds.DrainDestinationId
        ,        wds.pHLevel
        ,        wds.Note
        ,        wds.Is_Deleted
        ,        @UserId
        ,        wds.StandardWeight
        ,        NEWID()
        ,        wds.StandardWaterUsage
        FROM TCD.WasherDosingSetup wds
        WHERE wds.WasherProgramSetupId = @WasherProgramSetupId
        AND      wds.EcoLabAccountNumber  = @EcoLabAccountNumber
        AND      wds.Is_Deleted           = 'False'

        --check for any error
            SET    @ErrorId    =    @@ERROR
    
            IF    (@ErrorId    <>    0)
                BEGIN
                        SET    @ReturnValue    =    -1
                        RETURN    (@ReturnValue)
                END

		SELECT    wdpm.EcoLabAccountNumber
        ,        wds2.WasherDosingSetupId
        ,        wdpm.InjectionNumber
        ,        wdpm.ProductId
        ,        wdpm.Quantity
        ,        wdpm.IsDeleted
		INTO #tempWasherDosingProductMapping
        FROM TCD.WasherDosingProductMapping wdpm
        INNER JOIN TCD.WasherDosingSetup wds
        ON wds.EcoLabAccountNumber = wdpm.EcoLabAccountNumber
        AND wds.WasherDosingSetupId = wdpm.WasherDosingSetupId
        LEFT JOIN TCD.WasherDosingSetup wds2 
        ON wds.EcoLabAccountNumber = wds2.EcoLabAccountNumber
        AND wds.StepNumber = wds2.StepNumber
        AND wds2.WasherProgramSetupId = @ProgramSetupId
        WHERE wds.WasherProgramSetupId = @WasherProgramSetupId
        AND wds.Is_Deleted = 'False'
        ORDER BY wds.StepNumber 

		UPDATE twdpm
		SET twdpm.ProductId = CASE WHEN udd.NewProductId > 0 THEN udd.NewProductId ELSE twdpm.ProductId END
		,	twdpm.IsDeleted = CASE WHEN udd.NewProductId > 0 THEN 0 ELSE 1 END
		,   twdpm.Quantity  = CASE WHEN udd.ScalarOption = 1 
                              THEN CASE WHEN (twdpm.Quantity - ((twdpm.Quantity * udd.ScalarAmountPercent)/100)) < 0 
									THEN 0
									ELSE  (twdpm.Quantity - ((twdpm.Quantity * udd.ScalarAmountPercent)/100))
									END
								WHEN udd.ScalarOption = 2 
								THEN (twdpm.Quantity + ((twdpm.Quantity * udd.ScalarAmountPercent)/100)) 
								ELSE twdpm.Quantity 
								END
		FROM #tempWasherDosingProductMapping twdpm
		INNER JOIN @SubstituteMissingChemical udd
		ON twdpm.ProductId = udd.OldProductId
		
        INSERT INTO TCD.WasherDosingProductMapping
        (
            --WasherDosingProductMappingId - this column value is auto-generated
            EcoLabAccountNumber,
            WasherDosingSetupId,
            InjectionNumber,
            ProductId,
            Quantity,
            LastModifiedByUserId,
            MyServiceFrmulaStpDsgDvcGuid,
            LastModifiedTime,
            IsDeleted
        )
        SELECT   td.EcoLabAccountNumber
        ,        td.WasherDosingSetupId
        ,        td.InjectionNumber
        ,        td.ProductId
        ,        td.Quantity
        ,        @UserId
        ,        NEWID()
        ,        GETUTCDATE()
        ,        td.IsDeleted
        FROM #tempWasherDosingProductMapping td
        WHERE td.IsDeleted = 'False'
			
		DROP TABLE #tempWasherDosingProductMapping

		-- For Reording the washer injection based on the update or insert of the productdosing for the washer.
		EXEC [TCD].[WasherInjectionOrdering] @ProgramSetupId,@EcolabAccountNumber

        --check for any error
            SET    @ErrorId    =    @@ERROR
    
            IF    (@ErrorId    <>    0)
                BEGIN
                        SET    @ReturnValue    =    -1
                        RETURN    (@ReturnValue)
                END

    IF    (    @ErrorId    =    0    )
    BEGIN
        --GOTO    ExitModule
        RETURN    (@ReturnValue)
    END

    SET    NOCOUNT    OFF
    RETURN    (@ReturnValue)
END
GO
-------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[CopyTunnelFormula]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[CopyTunnelFormula]
END
GO
CREATE PROCEDURE [TCD].[CopyTunnelFormula]
		 @ToWasherGroupId                            INT								=            NULL
    ,    @FromWasherGroupId                          INT								=            NULL
    ,    @ProgramNumber                              SMALLINT							=            NULL 
    ,    @WasherProgramSetupId                       INT								=            NULL
    ,    @ProgramId                                  INT								=            NULL
    ,    @EcoLabAccountNumber                        NVARCHAR(25)						=            NULL
    ,    @UserId                                     INT								=            NULL
    ,    @ProgramSetupId                             INT								=            NULL   OUTPUT 
	

AS
BEGIN
    SET NOCOUNT ON;

    DECLARE      @TotalNumberOfPrograms      SMALLINT        =       NULL
    ,            @ReturnValue                INT             =       0
    ,            @ErrorId                    INT             =       0
    ,            @ErrorMessage               NVARCHAR(4000)  =       N''
    ,            @MaxNumberOfPrograms        SMALLINT        =       127
	,			 @PlantId INT

	SET @PlantId = (SELECT p.PlantId FROM tcd.Plant p WHERE EcolabAccountNumber = @EcolabAccountNumber)

    DECLARE
                @OutputList                                AS    TABLE        (
                OutputProgramSetupId                       INT
        )

    --ProgramNumber check
    IF    (    @ProgramNumber                >            @MaxNumberOfPrograms)
    BEGIN
            SET        @ErrorId                        =            51002
            SET        @ErrorMessage                    =            N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Invalid ProgramNumber... Aborting.'
            --GOTO    ErrorHandler
            RAISERROR    (@ErrorMessage, 16, 1)
            SET    @ReturnValue    =    -1
            RETURN    (@ReturnValue)
    END

        --Check for unique ProgramNumber
        IF    EXISTS    (        SELECT    1
                            FROM    [TCD].TunnelProgramSetup            TPS
                            WHERE    TPS.EcolabAccountNumber        =            @EcoLabAccountNumber
                                AND    TPS.WasherGroupId            =            @ToWasherGroupId
                                AND    TPS.ProgramNumber            =            @ProgramNumber
                                AND    TPS.Is_Deleted                =            'FALSE'
                    )
                BEGIN
                        SET        @ErrorId            =            51001
                        SET        @ErrorMessage        =            N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Specified ProgramNumber for the WasherGroup already exists for the plant.'
                        --GOTO    ErrorHandler
                        RAISERROR    (@ErrorMessage, 16, 1)
                        SET    @ReturnValue    =    -1
                        RETURN    (@ReturnValue)
                END

        --Check for total number of programs/formulae associated
        SELECT    @TotalNumberOfPrograms        =            COUNT(TPS.ProgramNumber)
        FROM    [TCD].TunnelProgramSetup                        TPS
        WHERE    TPS.EcolabAccountNumber        =            @EcoLabAccountNumber
            AND    TPS.WasherGroupId            =            @ToWasherGroupId
            AND    TPS.Is_Deleted                =            'FALSE'
        
        IF    (    @TotalNumberOfPrograms        =            @MaxNumberOfPrograms    )
            BEGIN
                    SET        @ErrorId        =            51000
                    SET        @ErrorMessage    =            N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Maximum Number of programs that can be associated to a WasherGroup already defined... Aborting.'
                    --GOTO    ErrorHandler
                    RAISERROR    (@ErrorMessage, 16, 1)
                    SET    @ReturnValue    =    -1
                    RETURN    (@ReturnValue)
            END

        INSERT INTO TCD.TunnelProgramSetup
        (
            --TunnelProgramSetupId - this column value is auto-generated
            EcolabAccountNumber,
            WasherGroupId,
            ProgramNumber,
            [Description],
            ProgramId,
            NominalLoad,
            LoadsPerMonth,
            TotalRunTime,
            ExtraTime,
            NumberOfDrains,
            DrainTime,
            Category,
            CleanWt,
            CleanAw,
            CustomerId,
            Rewash,
            Is_Deleted,
            LastModifiedByUserId,
            MyServiceCustFrmulaMchGrpGUID,
            LastModifiedTime
        )
        OUTPUT
            INSERTED.TunnelProgramSetupId    AS    Id
        INTO
            @OutputList(
                    OutputProgramSetupId
                       )
        SELECT    tps.EcolabAccountNumber
        ,        @ToWasherGroupId
        ,        @ProgramNumber
        ,        tps.[Description]
        ,        @ProgramId
        ,        tps.NominalLoad
        ,        tps.LoadsPerMonth
        ,        tps.TotalRunTime
        ,        tps.ExtraTime
        ,        tps.NumberOfDrains
        ,        tps.DrainTime
        ,        tps.Category
        ,        tps.CleanWt
        ,        tps.CleanAw
        ,        tps.CustomerId
        ,        tps.Rewash
        ,        tps.Is_Deleted
        ,        @UserId
        ,        NEWID()
        ,        GETUTCDATE()
        FROM TCD.TunnelProgramSetup tps
        WHERE tps.EcolabAccountNumber    =    @EcoLabAccountNumber
        AND      tps.TunnelProgramSetupId  =    @WasherProgramSetupId
        AND   tps.WasherGroupId            =    @FromWasherGroupId

         --check for any error
            SET    @ErrorId    =    @@ERROR
    
            IF    (@ErrorId    <>    0)
                BEGIN
                        SET        @ErrorMessage    =            N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred associating formula to the conventional washer group.'
                        --GOTO    ErrorHandler
                        RAISERROR    (@ErrorMessage, 16, 1)
                        SET    @ReturnValue    =    -1
                        RETURN    (@ReturnValue)
                END

        SELECT  TOP 1 @ProgramSetupId    =   O.OutputProgramSetupId FROM @OutputList O

        INSERT INTO TCD.TunnelDosingSetup
        (
            --TunnelDosingSetupId - this column value is auto-generated
            EcolabAccountNumber,
            TunnelProgramSetupId,
            GroupId,
            ProgramNumber,
            StepNumber,
            StepTypeId,
            ProductId,
            StepRunTime,
            CompartmentNumber,
            MachineNumber,
            Quantity,
            [Delay],
            DosingNumber,
            Temperature,
            WaterType,
            WaterLevel,
            DrainDestinationId,
            pHLevel,
            WaterInletDrain,
            Note,
            Is_Deleted,
            LastModifiedByUserId,
            MyServiceCustFrmulaStpGUID,
            StandardWaterUsage,
			PhRegLevel,
			MonLevel,
			ConRegLevel
        )
        SELECT tds.EcolabAccountNumber
        , @ProgramSetupId
        , @ToWasherGroupId
        , @ProgramNumber
        , tds.StepNumber
        , tds.StepTypeId
        , tds.ProductId
        , tds.StepRunTime
        , tds.CompartmentNumber
        , tds.MachineNumber
        , tds.Quantity
        , tds.[Delay]
        , tds.DosingNumber
        , tds.Temperature
        , tds.WaterType
        , tds.WaterLevel
        , tds.DrainDestinationId
        , tds.pHLevel
        , tds.WaterInletDrain
        , tds.Note
        , 'False'
        , @UserId
        , NEWID()
        , tds.StandardWaterUsage
		, tds.PhRegLevel
		, tds.MonLevel
		, tds.ConRegLevel
        FROM TCD.TunnelDosingSetup tds
        WHERE tds.TunnelProgramSetupId = @WasherProgramSetupId
        AND        tds.EcolabAccountNumber = @EcoLabAccountNumber
        AND        tds.Is_Deleted    = 'False'

        --check for any error
            SET    @ErrorId    =    @@ERROR
    
            IF    (@ErrorId    <>    0)
                BEGIN
                        SET        @ErrorMessage    =            N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred associating formula to the conventional washer group.'
                        --GOTO    ErrorHandler
                        RAISERROR    (@ErrorMessage, 16, 1)
                        SET    @ReturnValue    =    -1
                        RETURN    (@ReturnValue)
                END
        
        SELECT tc.CompartmentNumber, ces.ProductId, tcem.ControllerEquipmentSetupId INTO #Tunnel1 FROM TCD.TunnelCompartmentEquipmentMapping tcem
        INNER JOIN TCD.TunnelCompartment tc
        ON tc.TunnelCompartmentId = tcem.TunnelCompartmentId AND tc.EcoLabAccountNumber = tcem.EcoLabAccountNumber AND tcem.Is_Deleted = 0
        INNER JOIN TCD.MachineSetup ms
        ON ms.WasherId = tc.WasherId AND ms.EcoalabAccountNumber = tc.EcoLabAccountNumber AND ms.IsDeleted = 0
        INNER JOIN TCD.WasherGroup wg
        ON wg.WasherGroupId = ms.GroupId
        LEFT JOIN TCD.ControllerEquipmentSetup ces 
        ON ces.ControllerEquipmentSetupId = tcem.ControllerEquipmentSetupId
        WHERE wg.WasherGroupId = @ToWasherGroupId


        INSERT TCD.TunnelDosingProductMapping
        (
            --TunnelDosingProductMappingId - this column value is auto-generated
            EcoLabAccountNumber,
            TunnelDosingSetupId,
            GroupId,
            CompartmentNumber,
            ControllerEquipmentSetupId,
            InjectionNumber,
            ProductId,
            Quantity,
            LastModifiedByUserId,
            LastModifiedTime,
            MyServiceFrmulaStpDsgDvcGuid,
            DelayTime
        )
        SELECT tdpm.EcoLabAccountNumber
        , tds2.TunnelDosingSetupId
        , @ToWasherGroupId
        , tdpm.CompartmentNumber
        , t.ControllerEquipmentSetupId
        , tdpm.InjectionNumber
        , tdpm.ProductId
        , tdpm.Quantity
        , @UserId
        , GETUTCDATE()
        , NEWID()
        , tdpm.DelayTime 
        FROM TCD.TunnelDosingProductMapping tdpm
        INNER JOIN TCD.TunnelDosingSetup tds
        ON tds.TunnelDosingSetupId = tdpm.TunnelDosingSetupId
        AND tds.EcolabAccountNumber = tdpm.EcoLabAccountNumber
        LEFT JOIN TCD.TunnelDosingSetup tds2
        ON tds2.CompartmentNumber = tds.CompartmentNumber
        AND tds2.EcolabAccountNumber = tds.EcolabAccountNumber
        AND tds2.TunnelProgramSetupId = @ProgramSetupId
        INNER JOIN TCD.ControllerEquipmentSetup ces 
        ON ces.ControllerEquipmentSetupId = tdpm.ControllerEquipmentSetupId
        INNER JOIN #Tunnel1 t
        ON t.CompartmentNumber = tdpm.CompartmentNumber
        AND t.ProductId = ces.ProductId
        WHERE tds.TunnelProgramSetupId = @WasherProgramSetupId
        AND tds.Is_Deleted = 'False'
        ORDER BY tds.CompartmentNumber	


		INSERT INTO TCD.TunnelTempSetup
			(
				TunnelProgramSetupId,					    
				DesiredTemperature,
				MinTime,
				StartDelay,
				AcceptDelay,
				CompartmentNumber,
				ProductCheck,
				PlantId
			)
			SELECT 
			@ProgramSetupId,
			tts.DesiredTemperature,
			tts.MinTime,
			tts.StartDelay,
			tts.AcceptDelay,
			tts.CompartmentNumber,
			tts.ProductCheck,
			tts.PlantId
			FROM  TCD.TunnelDosingSetup tds 
			INNER JOIN TCD.TunnelTempSetup tts 
			ON tds.TunnelProgramSetupId = tts.TunnelProgramSetupId
			AND tds.CompartmentNumber = tts.CompartmentNumber		
			WHERE 
			tts.PlantId = @PlantId		
			AND tds.EcolabAccountNumber = @EcolabAccountNumber 
			AND tds.TunnelProgramSetupId = @WasherProgramSetupId			

-- CleanUp
        DROP TABLE #Tunnel1

    IF    (    @ErrorId    =    0    )
    BEGIN
        --GOTO    ExitModule
        RETURN    (@ReturnValue)
    END

    SET    NOCOUNT    OFF
    RETURN    (@ReturnValue)
END
GO
-------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetPlantMeterMachines]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetPlantMeterMachines]
END
GO

CREATE PROCEDURE [TCD].[GetPlantMeterMachines] (@GroupTypeID int, @EcolabAccountNumber NVARCHAR(25))
AS 
    BEGIN 
      SET nocount ON; 
	  Declare @Istunnel int = NULL,@TypeId INT = NULL
	  select @IStunnel = Istunnel from [TCD].machinesetup where GroupId = @GroupTypeID 
		
	  SELECT @TypeId = GroupTypeId FROM  [TCD].MachineGroup WHERE Id = @GroupTypeID AND Is_Deleted = 0
	  IF(@TypeId = 1)
		BEGIN
			SELECT 0, 'ALL', NULL,0
		END
		ELSE
			IF(@TypeId = 2)
			BEGIN
				IF(@IStunnel = 1)
				Begin
					Declare @NoofComp Int, @Count int = 2,@HasPress BIT, @ControllerId INT
					SELECT @NoOfcomp = NumberOfComp, @ControllerId = ControllerId  FROM [TCD].MachineSetup where Groupid = @GroupTypeID and IsTunnel = 1
					Select @HasPress = HasPress from [TCD].machinesetup where GroupId = @GroupTypeID
					--IF((SELECT COUNT(1) FROM TCD.GROUPTYPE GT LEFT JOIN TCD.MachineSetup MS ON MS.GroupId = GT.Id WHERE GT.Id = @GroupTypeID AND MS.HasPress = 1)>0)
					--SET @HasPress = 1 ELSE SET @HasPress = 0
					CREATE TABLE #GET_COMPARTMENT
					(
					MachineID INT,
					CompartmentNumber VARCHAR(1000),
					ControllerId INT,
					PlantWasherNumber INT
					)
					While(@count <=  @NoOfcomp + 1) 
					begin
						Insert into #GET_COMPARTMENT(MachineID,CompartmentNumber,ControllerId,PlantWasherNumber)
						select @count-1,'Compartment'+ cast(@count - 1 as Varchar(1000))+'',@ControllerId,0
						Set @count = @count + 1
					End
					IF (@HasPress = 1)
					BEGIN 
						Select 1,'Press', @ControllerId,0 Union all Select MachineID,CompartmentNumber,ControllerId,PlantWasherNumber from #GET_COMPARTMENT   END
					ELSE 
					BEGIN 
						Select MachineID,CompartmentNumber,ControllerId,PlantWasherNumber from #GET_COMPARTMENT END
					End
				Else 
				Begin 					
					Select Distinct MS.WasherId,MS.MachineName,MS.ControllerId,CAST(WS.PlantWasherNumber AS INT) from [TCD].machinesetup MS LEFT JOIN TCD.Washer WS ON MS.WasherId = WS.WasherId where GroupID = @GroupTypeID AND IsDeleted = 0 And EcoalabAccountNumber = @EcolabAccountNumber AND ISNULL(MS.ControllerId, 0) != 0
				End
			END
		 ELSE
			IF(@TypeId = 3)
		 Begin 
			SELECT 0, 'ALL', NULL,0 
			UNION 
			Select Distinct Id,Description,NULL,0 from [TCD].Dryers D where D.DryerGroupId = @GroupTypeID AND Is_deleted = 0 And EcolabAccountNumber = @EcolabAccountNumber
		End
	    ELSE
		 IF(@TypeId = 4)
		Begin 
			SELECT 0, 'ALL', NULL,0
			UNION 
			Select Distinct FinnisherId,Name, NULL,0 from [TCD].Finnishers F where F.FinnisherGroupId = @GroupTypeID AND Is_deleted = 0 And EcolabAccountNumber = @EcolabAccountNumber
		End		  
		 ELSE
		 IF(@TypeId = 5)
		 BEGIN
			SELECT 0, 'ALL', NULL,0
			UNION
			SELECT DISTINCT WE.DeviceNumber, WE.DeviceName,NULL,0 FROM TCD.WaterAndEnergy WE WHERE WE.Is_deleted  = 0  And EcolabAccountNumber = @EcolabAccountNumber
		 END

SET nocount OFF;
 END
 GO
 
 
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetAlarmCodesandNumbers]') AND type in (N'P', N'PC'))
BEGIN
	DROP PROCEDURE [TCD].[GetAlarmCodesandNumbers]
END
GO
 
 CREATE PROCEDURE [TCD].[GetAlarmCodesandNumbers](@AlarmMachineMappingIds VARCHAR(MAX)
                                                ,@IsBatchEjectCondition BIT
                                                ,@washerid INT
                                                ,@OutputIsTunnel BIT OUTPUT
                                                ,@OutputControllerId INT OUTPUT)
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE
       @sql NVARCHAR(MAX)
    SET @sql=''
    IF(@IsBatchEjectCondition=1)
        BEGIN
            SET @sql='SELECT AlarmNumber FROM tcd.BatchEjectCondition AS bec WHERE bec.BatchEjectConditionId IN ('+@AlarmMachineMappingIds+')'
        END
    ELSE
        BEGIN
            SET @sql='SELECT AlarmCode FROM tcd.AlarmGroupMsterVsControllerModelType agmvcmt WHERE agmvcmt.AlarmGroupMsterVsControllerModelTypeId in ('+@AlarmMachineMappingIds+')'
        END
    EXECUTE sp_executesql
            @sql

    SELECT
           @OutputIsTunnel=ms.IsTunnel,
           @OutputControllerId=ms.ControllerId
    FROM tcd.MachineSetup AS ms
    WHERE washerid=@washerid
      AND ms.IsDeleted=0
END

GO
 ------------------------------------
 IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetControllerEquipmentList]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetControllerEquipmentList]
END
GO
CREATE PROCEDURE [TCD].[GetControllerEquipmentList]                  
  @EcoLabAccountNumber     NVARCHAR(1000)                  
    , @ControllerId       INT                  
    , @ControllerEquipmentId     TINYINT = NULL                  
    , @IsActive       BIT = NULL                  
AS
BEGIN
    SET NOCOUNT ON;                  
    DECLARE                  
     @ErrorMessage         NVARCHAR(4000)                  
     ,@PumpValveCount        TINYINT                  
     ,@MECount          TINYINT                  
     ,@ControllerEquipmentTypeId_PumpValve    TINYINT                  
     ,@ControllerEquipmentTypeId_ME      TINYINT                  
     ,@ControllerModelId        INT                  
     ,@ReturnValue         INT = 0                  
     ,@TagTypeLfs         VARCHAR(100) = 'Tag_NML'                  
     ,@TagTypeKfactor         VARCHAR(100) = 'Tag_PPOL'                  
     ,@TagTypeCalibration        VARCHAR(100) = 'Tag_OPSL'            
 ,@ControllerTypeId INT;                  

    CREATE TABLE #Equipment (                  
    ControllerEquipmentId     INT    IDENTITY(1, 1)                  
  , ControllerEquipmentTypeId     TINYINT   NULL                  
  , IsActive        BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , ProductId        INT    NULL                  
  , ProductName       NVARCHAR(255)  NULL                  
  , PumpCalibration       DECIMAL(18, 3)  NULL                  
  , FlowMeterSwitchFlag      BIT    NULL                  
  , FlowMeterCalibration      INT    NULL                  
  , MaximumDosingTime      SMALLINT   NULL                  
  , FlowSwitchTimeOut       decimal(18,1)   NULL                  
  , ControllerEquipmentSetupId    SMALLINT   NULL                  
  , LfsChemicalName       NVARCHAR(200)  NULL                  
  , KFactor        DECIMAL(18, 2)  NULL                  
  , TunnelHold        BIT    NULL                  
  , FlowDetectorType      INT    NULL                  
  , FlowSwitchAlarm       BIT    NULL                  
  , FlowMeterAlarm       BIT    NULL                  
  , FlowMeterType       INT    NULL                  
  , FlowAlarmDelay       DECIMAL(18, 2)    NULL                  
  , FlowMeterPumpDelay      DECIMAL(18, 2)    NULL                  
  , FlowMeterAlarmDelay      DECIMAL(18, 2)    NULL                  
  , LastModifiedTime      DATETIME   NULL                  
  , LastSyncTime       DATETIME   NULL                  
  , ControllerEquipmentTypeModelID    INT    NULL                  
  , ConventionalWasherGroupConnection   BIT    NOT NULL                  
              DEFAULT                  
              0                  
  , AxillaryPumpCalibration     SMALLINT   NULL                  
  , FlowmeterSwitchActivated     BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , FlushWhileDosing      BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , WeightControlledDosage     BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , EquipmentDoseAlone      BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , LowLevelAlarm       BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , LeakageAlarm       BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , FlushTime        SMALLINT   NULL                  
  , PumpingTime       SMALLINT   NULL                  
  , PreFlushTime       SMALLINT   NULL                  
  , NightFlushPauseTime      SMALLINT   NULL                  
  , NightFlushTime       SMALLINT   NULL                  
  , AcceptedDeviation      SMALLINT   NULL                 
  , LineNumber    tinyint NULL DEFAULT 0                
  , DirectDosingFlag      BIT    NULL                  
              DEFAULT                  
              'FALSE'               
  , DirectDosingMachineInternalId    INT    NULL                  
  , DirectDosingTunnelCompartmentId   INT    NULL                  
  , WasherGroupTypeId     INT    NULL                 
  , NumberOfCompartments     INT    NULL                   
  , FlushValveNumber      TINYINT   NULL                
  , CalibrationConductSS_Tank    DECIMAL(18,2)   NULL                
  , BackFlowControl       BIT    NULL                
  , FactorFM_B_FM       SMALLINT         NULL                
  , AcceptedDeviationRingLine    SMALLINT  NULL                
  , UsePumpOfGroup1ForTunnel    BIT    NULL                
  , pHSensorEnabled       BIT    NULL                
  , Concentration    INT    NULL              
  , Deadband              BIT    NULL             
  , WasherGroupNumber    INT     NULL           
  , ValveOutputAsTom  BIT NOT NULL DEFAULT  'FALSE'          
  , FlowSwitchNumber int  NULL           
  , FlushTimeForFlushValve int NULL      
    , MinimumFlowRate INT NULL    
  , ProductDensity DECIMAL(18,2) NULL    
  , MaximumConcentration INT NULL  
  , DosingLineMode INT NULL  
   );                  
    IF NOT EXISTS ( SELECT 1                  
        FROM TCD.ConduitController   CC                  
        WHERE CC.EcoalabAccountNumber = @EcoLabAccountNumber                  
AND CC.ControllerId = @ControllerId                  
    )                  
    BEGIN                  
    SET   @ErrorMessage = 'Invalid Plant/Controller combination specified';                  
    RAISERROR (@ErrorMessage, 16, 1);                  
    SET  @ReturnValue = -1;                  
    RETURN                  
    @ReturnValue;                  
    END;                  
    SET @ControllerTypeId = (SELECT ControllerTypeid            
       FROM TCD.ConduitController CC            
       WHERE CC.ControllerId = @ControllerId);            
    SELECT @ControllerModelId = CC.ControllerModelId                  
  FROM TCD.ConduitController CC                  
  WHERE CC.ControllerId = @ControllerId;                  
    SELECT @ControllerEquipmentTypeId_PumpValve = CASE                  
              WHEN CET.ControllerEquipmentTypeName = 'Pump/Valve'                  
              THEN CET.ControllerEquipmentTypeId                  
              ELSE @ControllerEquipmentTypeId_PumpValve                  
              END                  
     , @ControllerEquipmentTypeId_ME = CASE                  
           WHEN CET.ControllerEquipmentTypeName = 'ME'                  
           THEN CET.ControllerEquipmentTypeId                  
           ELSE @ControllerEquipmentTypeId_ME                  
           END                  
  FROM TCD.ControllerEquipmentType CET                  
  WHERE CET.ControllerEquipmentTypeName   IN   ('Pump/Valve', 'ME');                  
    IF (@ControllerModelId <> 7 AND @ControllerModelId  <> 8 AND @ControllerModelId <> 9 AND @ControllerModelId <> 11      
    AND @ControllerModelId <> 10 AND @ControllerModelId <> 14)                
    BEGIN                  
    SELECT @PumpValveCount = ISNULL(CSD.Value, 0)                  
      FROM TCD.ConduitController CC                  
       JOIN                  
       TCD.ControllerModelControllerTypeMapping CMCTM ON CC.ControllerModelId = CMCTM.ControllerModelId                  
       JOIN                  
       TCD.ControllerSetupData CSD ON CSD.ControllerId = CC.ControllerId                  
          AND CC.ControllerTypeId = CMCTM.ControllerTypeId                  
       JOIN                  
       TCD.FieldGroup FG ON FG.ControllerModelId = CC.ControllerModelId                  
        AND FG.ControllerTypeId = CC.ControllerTypeId                  
        AND FG.TabId = 3                  
       INNER JOIN                  
       TCD.FieldGroupFieldMapping FGM ON FGM.FieldGroupId = FG.Id                  
       INNER JOIN            
       TCD.Field F ON F.Id = FGM.FieldId                  
      AND CSD.FieldId = f.Id                  
      WHERE CC.ControllerId = @ControllerId                  
    AND F.ResourceKey = 'No._of_Chemical_Valves'                  
    AND CSD.EcolabAccountNumber = @EcoLabAccountNumber;                  
    SELECT @MECount = ISNULL(CMCTM.MECount, 0)                  
      FROM TCD.ConduitController CC                  
       JOIN                  
       TCD.ControllerModelControllerTypeMapping CMCTM ON CC.ControllerModelId = CMCTM.ControllerModelId                  
             AND CC.ControllerTypeId = CMCTM.ControllerTypeId                  
      WHERE CC.ControllerId = @ControllerId;                  
    END;         
    ELSE IF(@ControllerModelId = 11)                
    BEGIN                
    SELECT @PumpValveCount = 2*CMCTM.PumpValveCount                
     , @MECount = 2*CMCTM.MECount                
      FROM TCD.ControllerModelControllerTypeMapping CMCTM                
      WHERE CMCTM.ControllerModelId = @ControllerModelId;                
    END;                
  ELSE IF(@ControllerModelId = 7 OR @ControllerModelId = 8 OR @ControllerModelId = 9 OR @ControllerModelId = 10  OR @ControllerModelId = 14)                
  BEGIN                
    SELECT @PumpValveCount = CMCTM.PumpValveCount            
 , @MECount = CMCTM.MECount            
  FROM TCD.ControllerModelControllerTypeMapping CMCTM            
  WHERE CMCTM.ControllerModelId = @ControllerModelId            
    AND CMCTM.ControllerTypeId = @ControllerTypeId;                
    END;                
    IF (SELECT ISNULL(@PumpValveCount, 0)                  
    +                  
    ISNULL(@MECount, 0)) = 0                  
    BEGIN                  
    SELECT                  
    T.ControllerEquipmentId  AS   ControllerEquipmentId                  
  , T.ControllerEquipmentTypeId  AS   ControllerEquipmentTypeId                  
  , T.IsActive     AS   IsActive                  
  , T.ProductId     AS   ProductId                  
  , T.ProductName    AS   ProductName                  
  , T.PumpCalibration    AS   PumpCalibration                  
  , T.FlowMeterSwitchFlag   AS   FlowMeterSwitchFlag                  
  , T.MaximumDosingTime   AS   MaximumDosingTime                  
  , T.FlowSwitchTimeOut   AS   FlowSwitchTimeOut                  
  , T.ControllerEquipmentSetupId AS   ControllerEquipmentSetupId                  
  , @EcoLabAccountNumber   AS   EcoLabAccountNumber                  
  , @ControllerId    AS   ControllerId                  
  , CC.TopicName     AS   ControllerName                  
  , CC.ControllerTypeId   AS   ControllerTypeId                  
  , T.LfsChemicalName    AS   LfsChemicalName                  
  , T.KFactor     AS   KFactor                  
  , T.TunnelHold     AS   TunnelHold                  
  , T.FlowDetectorType   AS   FlowDetectorType                  
  , T.FlowSwitchAlarm    AS   FlowSwitchAlarm                  
  , T.FlowMeterAlarm    AS   FlowMeterAlarm                  
  , T.FlowMeterType    AS   FlowMeterType                  
  , T.FlowAlarmDelay    AS   FlowAlarmDelay                  
  , T.FlowMeterPumpDelay   AS   FlowMeterPumpDelay                  
  , T.FlowMeterAlarmDelay   AS   FlowMeterAlarmDelay                  
  , T.ControllerEquipmentTypeModelID                  
  , T.ConventionalWasherGroupConnection                  
  , T.AxillaryPumpCalibration                  
  , T.FlowmeterSwitchActivated                  
  , T.FlushWhileDosing                  
  , T.WeightControlledDosage                  
  , T.EquipmentDoseAlone                  
  , T.LowLevelAlarm                  
  , T.LeakageAlarm                  
  , T.FlushTime                  
  , T.PumpingTime                  
  , T.PreFlushTime                  
  , T.NightFlushPauseTime                  
  , T.NightFlushTime                  
  , T.AcceptedDeviation                 
  , T.LineNumber                 
  , T.DirectDosingFlag        
  , T.DirectDosingMachineInternalId                  
  , T.DirectDosingTunnelCompartmentId             
  , T.WasherGroupTypeId                     
  , T.NumberOfCompartments                     
  , T.FlushValveNumber                      
  , T.CalibrationConductSS_Tank                   
  , T.BackFlowControl                       
  , T.FactorFM_B_FM                      
  , T.AcceptedDeviationRingLine                    
  , T.UsePumpOfGroup1ForTunnel      
  , T.pHSensorEnabled               
  , T.Concentration                 
  , T.Deadband             
  , T.WasherGroupNumber             
  , T.ValveOutputAsTom            
  , T.FlowSwitchNumber           
  , T.FlushTimeForFlushValve      
   , T.MinimumFlowRate     
  , T.ProductDensity     
  , T.MaximumConcentration  
  ,T.DosingLineMode  
  , (                  
    SELECT MTS.TagAddress                  
      FROM TCD.ModuleTags MTS                  
      WHERE MTS.TagType = @TagTypeLfs                  
    AND MTS.ModuleID = ControllerEquipmentSetupId                  
    AND MTS.ModuleTypeId = 4                  
    AND MTS.Active = 1) AS LfsChemicalNameTag                  
  , (         
    SELECT MTS.TagAddress                  
      FROM TCD.ModuleTags MTS                  
      WHERE MTS.TagType = @TagTypeKfactor                  
    AND MTS.ModuleID = ControllerEquipmentSetupId                  
    AND MTS.ModuleTypeId = 4                  
    AND MTS.Active = 1) AS KfactorTag                  
  , (                  
    SELECT MTS.TagAddress                  
      FROM TCD.ModuleTags MTS                  
      WHERE MTS.TagType = @TagTypeCalibration                  
    AND MTS.ModuleID = ControllerEquipmentSetupId                  
    AND MTS.ModuleTypeId = 4                  
    AND MTS.Active = 1) AS CalibrationTag                  
  , T.LastModifiedTime  AS  LastModifiedTime                  
  , T.LastSyncTime   AS  LastSyncTime                  
      FROM #Equipment  T                  
    JOIN                  
    TCD.ConduitController CC                  
    ON CC.ControllerId = @ControllerId                  
      WHERE T.IsActive = ISNULL(@IsActive, T.IsActive)                  
    AND T.ControllerEquipmentId = ISNULL(@ControllerEquipmentId, T.ControllerEquipmentId);                  
    RETURN                  
    @ReturnValue;               

    END;             
    ELSE          
    BEGIN          
    IF ((SELECT ISNULL(@PumpValveCount, 0)                  
    +                  
    ISNULL(@MECount, 0)) = (SELECT COUNT(*) FROM TCD.ControllerEquipmentSetup CES     WHERE CES.ControllerId    = @ControllerId))          
      BEGIN          
      SET IDENTITY_INSERT #Equipment ON          
      INSERT INTO #Equipment (ControllerEquipmentId, ControllerEquipmentTypeId)             
      SELECT CES.ControllerEquipmentId, CES.ControllerEquipmentTypeId FROM TCD.ControllerEquipmentSetup CES WHERE CES.ControllerId = @ControllerId           
      SET IDENTITY_INSERT #Equipment OFF          
      END
	  ELSE
	  BEGIN
		 IF ISNULL(@PumpValveCount, 0) <> 0                  
    BEGIN                  
    WITH NumCTE (N)                  
    AS(SELECT '*' AS N                  
  UNION ALL                  
       SELECT '*' AS N)                  
    INSERT INTO #Equipment (ControllerEquipmentTypeId)                  
    SELECT TOP (@PumpValveCount) @ControllerEquipmentTypeId_PumpValve                  
      FROM NumCTE N1, NumCTE N2, NumCTE N3, NumCTE N4, NumCTE N5;                  
    END;                  
    IF ISNULL(@MECount, 0) <> 0                  
    BEGIN                  
    WITH NumCTE (N)                  
    AS (SELECT '*' AS N                  
    UNION ALL                  
    SELECT '*' AS N)                  
    INSERT INTO #Equipment(ControllerEquipmentTypeId)                  
    SELECT TOP (@MECount)@ControllerEquipmentTypeId_ME                  
      FROM NumCTE N1, NumCTE N2, NumCTE N3, NumCTE N4, NumCTE N5;                  
    END;   
	  END          
    END           
    UPDATE U                  
  SET U.IsActive = CES.IsActive                  
    , U.ProductId = CES.ProductId                  
    , U.ProductName = (SELECT ISNULL(NULLIF(PM.EnvisionDisplayName, ' '),PM.Name)                  
         FROM TCD.ProductMaster PM                  
         WHERE PM.ProductId = CES.ProductId)                  
    , U.PumpCalibration = CES.PumpCalibration                  
    , U.FlowMeterSwitchFlag = CES.FlowMeterSwitchFlag                  
    , U.MaximumDosingTime = CES.MaximumDosingTime                  
    , U.FlowSwitchTimeOut = CES.FlowSwitchTimeOut                  
    , U.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId                  
    , U.LfsChemicalName = CES.LfsChemicalName                  
    , U.KFactor = CES.KFactor                  
    , U.TunnelHold = CES.TunnelHold                  
    , U.FlowDetectorType = CES.FlowDetectorType                  
    , U.FlowSwitchAlarm = CES.FlowSwitchAlarm                  
    , U.FlowMeterAlarm = CES.FlowMeterAlarm                  
    , U.FlowMeterType = CES.FlowMeterType                  
    , U.FlowAlarmDelay = CES.FlowAlarmDelay                  
    , U.FlowMeterPumpDelay = CES.FlowMeterPumpDelay                  
    , U.FlowMeterAlarmDelay = CES.FlowMeterAlarmDelay                  
    , U.ControllerEquipmentTypeModelID = CES.ControllerEquipmentTypeModelID                  
    , U.ConventionalWasherGroupConnection = CES.ConventionalWasherGroupConnection                  
    , U.AxillaryPumpCalibration = CES.AxillaryPumpCalibration                  
    , U.FlowmeterSwitchActivated = CES.FlowmeterSwitchActivated                  
    , U.FlushWhileDosing = CES.FlushWhileDosing                  
    , U.WeightControlledDosage = CES.WeightControlledDosage                  
    , U.EquipmentDoseAlone = CES.EquipmentDoseAlone                  
    , U.LowLevelAlarm = CES.LowLevelAlarm                  
    , U.LeakageAlarm = CES.LeakageAlarm                  
    , U.FlushTime = CES.FlushTime                  
    , U.PumpingTime = CES.PumpingTime                  
    , U.PreFlushTime = CES.PreFlushTime                  
    , U.NightFlushPauseTime = CES.NightFlushPauseTime                  
    , U.NightFlushTime = CES.NightFlushTime                  
    , U.AcceptedDeviation = CES.AcceptedDeviation                 
    , U.LineNumber = CES.LineNumber                 
    , U.DirectDosingFlag = TCEVM.DirectDosingFlag                  
    , U.DirectDosingMachineInternalId = TCEVM.TunnelNumber                  
    , U.DirectDosingTunnelCompartmentId = TCEVM.CompartmentNumber                
    , U.LastModifiedTime = CES.LastModifiedTime                  
    , U.LastSyncTime = CES.LastSyncTime                
    , U.FlushValveNumber      = CES.FlushValveNumber                
  , U.CalibrationConductSS_Tank    = CES.CalibrationConductSS_Tank              
  , U.BackFlowControl     = CES.BackFlowControl                  
  , U.FactorFM_B_FM       = CES.FactorFM_B_FM               
  , U.AcceptedDeviationRingLine  = CES.AcceptedDeviationRingLine                  
  , U.UsePumpOfGroup1ForTunnel   = CES.UsePumpOfGroup1ForTunnel              
  , U.pHSensorEnabled            = CES.pHSensorEnabled              
  , U.Concentration = CES.Concentration              
  , U.Deadband = CES.Deadband             
  , U.WasherGroupNumber = CES.WasherGroupNumber          
  , U.ValveOutputAsTom = CES.ValveOutputAsTom          
  , U.FlowSwitchNumber = CES.FlowSwitchNumber         
  , U.FlushTimeForFlushValve = CES.FlushTimeForFlushValve      
    , U.MinimumFlowRate = CES.MinimumFlowRate    
  , U.ProductDensity = CES.ProductDensity    
  , U.MaximumConcentration  = CES.MaximumConcentration    
  ,U.DosingLineMode =1 
  FROM #Equipment U                  
   JOIN                  
   TCD.ControllerEquipmentSetup CES                  
  ON U.ControllerEquipmentId = CES.ControllerEquipmentId                  
  AND U.ControllerEquipmentTypeId = CES.ControllerEquipmentTypeId               
  JOIN TCD.ConduitController CC ON CES.ControllerID = CC.ControllerId                
  LEFT JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId                
  LEFT JOIN TCD.WasherGroup WG ON CES.ControllerID = WG.ControllerID                 
  LEFT JOIN TCD.MachineSetup MS ON WG.ControllerId = MS.ControllerId          
  WHERE CES.EcoLabAccountNumber = @EcoLabAccountNumber                  
   AND CES.ControllerId = @ControllerId; 
      

   IF(@ControllerModelId = 11)                
   BEGIN            
   UPDATE U             
   SET U.WasherGroupTypeId = (SELECT MIN(WG.WasherGroupTypeId) FROM TCD.WasherGroup WG WHERE WG.ControllerId = @ControllerId)            
    FROM #Equipment U                  
JOIN                  
   TCD.ControllerEquipmentSetup CES                  
  ON U.ControllerEquipmentId = CES.ControllerEquipmentId                  
  AND U.ControllerEquipmentTypeId = CES.ControllerEquipmentTypeId                
  WHERE CES.EcoLabAccountNumber = @EcoLabAccountNumber                  
   AND CES.ControllerId = @ControllerId            
   AND CES.ControllerEquipmentId IN (select top 14 CES.ControllerEquipmentId FROM  TCD.ControllerEquipmentSetup CES            
   where CES.ControllerId = @ControllerId )            

     UPDATE U             
   SET U.WasherGroupTypeId = (SELECT MAX(WG.WasherGroupTypeId) FROM TCD.WasherGroup WG WHERE WG.ControllerId = @ControllerId)            
    FROM #Equipment U                  
   JOIN                  
   TCD.ControllerEquipmentSetup CES                  
  ON U.ControllerEquipmentId = CES.ControllerEquipmentId                  
  AND U.ControllerEquipmentTypeId = CES.ControllerEquipmentTypeId               
  JOIN TCD.ConduitController CC ON CES.ControllerID = CC.ControllerId         
  WHERE CES.EcoLabAccountNumber = @EcoLabAccountNumber                  
   AND CES.ControllerId = @ControllerId            
   AND CES.ControllerEquipmentId IN (select  CES.ControllerEquipmentId FROM TCD.ControllerEquipmentSetup CES            
    where CES.ControllerId = @ControllerId AND             
    CES.ControllerEquipmentId BETWEEN 15 AND 28 )        

   UPDATE U SET U.NumberOfCompartments = ms.NumberOfComp        
   FROM #Equipment U        
   INNER JOIN TCD.ControllerEquipmentSetup ces        
   ON u.ControllerEquipmentId = ces.ControllerEquipmentId         
   INNER JOIN TCD.WasherGroup wg ON ces.ControllerId = WG.ControllerId        
   INNER JOIN TCD.MachineSetup ms ON ms.ControllerId = ces.ControllerId AND ms.GroupId = WG.WasherGroupId        
   WHERE ces.ControllerId = @ControllerId AND U.WasherGroupTypeId = 2  AND ms.IsTunnel = 1 AND WG.WasherDosingNumber = U.WasherGroupNumber        
   END          

  -- END                
    GOTO ExitModule;                  
ExitModule:
    SELECT                  
    T.ControllerEquipmentId   AS ControllerEquipmentId                  
  , T.ControllerEquipmentTypeId AS ControllerEquipmentTypeId                  
  , T.IsActive      AS IsActive                  
  , T.ProductId     AS ProductId                  
  , T.ProductName     AS ProductName                  
  , T.PumpCalibration    AS PumpCalibration                  
  , T.FlowMeterSwitchFlag   AS FlowMeterSwitchFlag                  
  , T.MaximumDosingTime    AS MaximumDosingTime                  
  , T.FlowSwitchTimeOut    AS FlowSwitchTimeOut                  
  , T.ControllerEquipmentSetupId  AS ControllerEquipmentSetupId                  
  , @EcoLabAccountNumber    AS EcoLabAccountNumber                  
  , @ControllerId     AS ControllerId                  
  , CC.TopicName     AS ControllerName                  
  , CC.ControllerTypeId    AS ControllerTypeId                  
  , T.LfsChemicalName    AS LfsChemicalName                  
  , T.KFactor      AS KFactor                  
  , T.TunnelHold     AS TunnelHold                  
  , T.FlowDetectorType    AS FlowDetectorType                  
, T.FlowSwitchAlarm    AS FlowSwitchAlarm                  
  , T.FlowMeterAlarm    AS FlowMeterAlarm                  
  , T.FlowMeterType     AS FlowMeterType                  
 , T.FlowAlarmDelay    AS FlowAlarmDelay                  
  , T.FlowMeterPumpDelay    AS FlowMeterPumpDelay                  
  , T.FlowMeterAlarmDelay   AS FlowMeterAlarmDelay                  
  , (                  
    SELECT MTS.TagAddress                  
  FROM TCD.ModuleTags MTS                  
  WHERE MTS.TagType = @TagTypeLfs                  
    AND MTS.ModuleID = ControllerEquipmentSetupId                  
    AND MTS.ModuleTypeId = 4                  
    AND MTS.Active = 1) AS LfsChemicalNameTag                  
  , (                  
    SELECT MTS.TagAddress                  
  FROM TCD.ModuleTags MTS                  
  WHERE MTS.TagType = @TagTypeKfactor                  
    AND MTS.ModuleID = ControllerEquipmentSetupId                  
    AND MTS.ModuleTypeId = 4                  
    AND MTS.Active = 1) AS KfactorTag                  
  , (                  
    SELECT MTS.TagAddress                  
  FROM TCD.ModuleTags MTS                  
  WHERE MTS.TagType = @TagTypeCalibration                  
    AND MTS.ModuleID = ControllerEquipmentSetupId                  
    AND MTS.ModuleTypeId = 4                  
    AND MTS.Active = 1) AS CalibrationTag                  
  , T.ControllerEquipmentTypeModelID                  
  , T.ConventionalWasherGroupConnection                  
  , T.AxillaryPumpCalibration                  
  , T.FlowmeterSwitchActivated                  
  , T.FlushWhileDosing                  
  , T.WeightControlledDosage                  
  , T.EquipmentDoseAlone                  
  , T.LowLevelAlarm                  
  , T.LeakageAlarm                  
  , T.FlushTime                  
  , T.PumpingTime                  
  , T.PreFlushTime                  
  , T.NightFlushPauseTime                  
  , T.NightFlushTime                  
  , T.AcceptedDeviation                  
  , T.LineNumber                
  , T.DirectDosingFlag                  
  , T.DirectDosingMachineInternalId                  
  , T.DirectDosingTunnelCompartmentId                  
  , T.LastModifiedTime    AS LastModifiedTime                  
  , T.LastSyncTime     AS LastSyncTime             
  , T.WasherGroupTypeId                     
  , T.NumberOfCompartments                     
  , T.FlushValveNumber                      
  , T.CalibrationConductSS_Tank                   
  , T.BackFlowControl                       
  , T.FactorFM_B_FM                      
  , T.AcceptedDeviationRingLine                    
  , T.UsePumpOfGroup1ForTunnel                    
  , T.pHSensorEnabled                
  , T.Concentration              
  , T.Deadband              
  , T.WasherGroupNumber          
  , T.ValveOutputAsTom          
  , T.FlowSwitchNumber          
  , T.FlushTimeForFlushValve      
    , T.MinimumFlowRate     
  , T.ProductDensity     
  , T.MaximumConcentration   
  , T.DosingLineMode 
  FROM #Equipment T                  
   JOIN                  
   TCD.ConduitController CC ON CC.ControllerId = @ControllerId                  
  WHERE T.IsActive = ISNULL(@IsActive, T.IsActive)                  
   AND T.ControllerEquipmentId = ISNULL(@ControllerEquipmentId, T.ControllerEquipmentId)        
   ORDER BY  T.ControllerEquipmentId;                  
    SET NOCOUNT OFF;                  
    RETURN                  
    @ReturnValue;                  
END;  
GO
 IF  EXISTS (SELECT
			*
		FROM sys.objects 
		WHERE object_id = OBJECT_ID(N'[TCD].[GetTunnelWashStepProducts]') 
			AND type IN (N'P', N'PC'))
BEGIN
	DROP PROCEDURE [TCD].[GetTunnelWashStepProducts]
END
GO
CREATE PROCEDURE [TCD].[GetTunnelWashStepProducts]

     @EcoLabAccountNumber     NVARCHAR(1000)

    , @CompartmentNumber       INT

    , @GroupId         INT

    , @DosingSetupId        INT

AS

BEGIN

SET NOCOUNT ON
DECLARE @TunnelProgramSetupId INT
,  @LastModifiedTime DATETIME  = NULL
,  @MyServiceFrmulaStpDsgDvcGuid UNIQUEIDENTIFIER = NULL
,  @RegionId INT
,  @PlantId INT 
,  @ControllerModelId INT
,  @ControllerId INT
,  @TunnelId INT
SELECT @RegionId = RegionId, @PlantId = PlantId FROM TCD.Plant WHERE EcolabAccountNumber = @EcoLabAccountNumber

SELECT @TunnelId = ms.WasherId FROM TCD.MachineSetup ms Where ms.GroupId = @GroupId AND ms.EcoalabAccountNumber = @EcoLabAccountNumber AND ms.IsTunnel = 1 AND ms.IsDeleted = 0

SELECT @TunnelProgramSetupId = tds.TunnelProgramSetupId FROM TCD.TunnelDosingSetup tds WHERE tds.TunnelDosingSetupId = @DosingSetupId AND tds.EcolabAccountNumber = @EcoLabAccountNumber

 SELECT @ControllerId = ISNULL(WG.ControllerId, - 1)
 FROM [TCD].WasherGroup WG
 WHERE WG.EcolabAccountNumber = @EcoLabAccountNumber
 AND WG.WasherGroupId = @GroupId

SELECT @ControllerModelId = cc.ControllerModelId from tcd.ConduitController cc WHERE cc.ControllerId = @ControllerId AND cc.EcoalabAccountNumber = @EcoLabAccountNumber

IF (@ControllerModelId < 7  OR @ControllerModelId IN (12, 13))
BEGIN
	IF NOT EXISTS (SELECT 1 FROM TCD.TunnelDosingProductMapping tdpm WHERE tdpm.TunnelDosingSetupId = @DosingSetupId AND tdpm.EcoLabAccountNumber = @EcoLabAccountNumber)
	 BEGIN
	  SELECT 
	  0           AS  TunnelDosingProductMappingId,
	  TC.EcoLabAccountNumber      AS  EcoalabAccountNumber, 
	  CES.ControllerEquipmentSetupId    AS  ControllerEquipmentSetupId, 
	  PM.ProductId        AS  ProductId, 
	  ISNULL(NULLIF(PM.EnvisionDisplayName, ' '),PM.Name)  AS ProductName,
	  0.0           AS  Quantity,
	  0           AS  DelayTime,  
	  CAST(TC.[CompartmentNumber] AS INT)   AS  CompartmentNumber, 
	  MS.GroupId         AS  GroupId,
	  @LastModifiedTime       AS  LastModifiedTime,
	  @MyServiceFrmulaStpDsgDvcGuid    AS  MyServiceFrmulaStpDsgDvcGuid,
	  TCD.FnChemicalCostInOunce(PM.ProductId)  AS  Price,
	  GETUTCDATE()        AS  MyServiceLastSynchTime,
	  CAST(CES.ControllerEquipmentTypeId AS INT)    AS  ControllerEquipmentSetupTypeId
	FROM TCD.TunnelCompartment TC 
	JOIN TCD.MachineSetup MS ON TC.WasherId = MS.WasherId AND TC.EcoLabAccountNumber = MS.EcoalabAccountNumber AND ms.IsDeleted = 'False' 
	JOIN TCD.TunnelCompartmentEquipmentMapping TCE ON TCE.TunnelCompartmentId = TC.TunnelCompartmentId AND TCE.EcoLabAccountNumber = TC.EcoLabAccountNumber AND TCE.Is_Deleted = 'False'
	JOIN TCD.ControllerEquipmentSetup CES on CES.ControllerEquipmentSetupId = TCE.ControllerEquipmentSetupId AND CES.EcoLabAccountNumber = TCE.EcoLabAccountNumber
	JOIN TCD.ProductMaster PM on PM.ProductId = CES.ProductId 
	JOIN TCD.TunnelProgramSetup TPS on TPS.WasherGroupId = MS.GroupId AND TPS.EcolabAccountNumber = MS.EcoalabAccountNumber
	 WHERE TC.CompartmentNumber = @CompartmentNumber AND MS.GroupId = @GroupId 
	 AND MS.EcoalabAccountNumber = @EcoLabAccountNumber 
	 AND TPS.TunnelProgramSetupId = @TunnelProgramSetupId
	END
	ELSE
	BEGIN
	SELECT 
	  ISNULL(TDPM.TunnelDosingProductMappingId,0)   AS  TunnelDosingProductMappingId,
	  TC.EcoLabAccountNumber      AS  EcoalabAccountNumber, 
	  CES.ControllerEquipmentSetupId    AS  ControllerEquipmentSetupId, 
	  PM.ProductId        AS  ProductId, 
	  ISNULL(NULLIF(PM.EnvisionDisplayName, ' '),PM.Name)  AS ProductName,
	  ISNULL(TDPM.Quantity,0.0) AS Quantity,
	  ISNULL(TDPM.DelayTime,0) AS DelayTime,   
	  CAST(TC.[CompartmentNumber] AS INT)   AS  CompartmentNumber, 
	  MS.GroupId         AS  GroupId,
	  TDPM.LastModifiedTime      AS  LastModifiedTime,
	  TDPM.MyServiceFrmulaStpDsgDvcGuid   AS  MyServiceFrmulaStpDsgDvcGuid,
	  TCD.FnChemicalCostInOunce(PM.ProductId)  AS  Price,
	  TDPM.MyServiceLastSynchTime     AS  MyServiceLastSynchTime,
	  CAST(CES.ControllerEquipmentTypeId AS INT)     AS  ControllerEquipmentSetupTypeId
	FROM TCD.TunnelCompartment TC 
	JOIN TCD.MachineSetup MS ON TC.WasherId = MS.WasherId AND TC.EcoLabAccountNumber = MS.EcoalabAccountNumber AND ms.IsDeleted = 'False' 
	JOIN TCD.TunnelCompartmentEquipmentMapping TCE ON TCE.TunnelCompartmentId = TC.TunnelCompartmentId AND TCE.EcoLabAccountNumber = TC.EcoLabAccountNumber AND TCE.Is_Deleted = 'False'
	JOIN TCD.ControllerEquipmentSetup CES ON CES.ControllerEquipmentSetupId = TCE.ControllerEquipmentSetupId AND CES.EcoLabAccountNumber = TCE.EcoLabAccountNumber
	JOIN TCD.ProductMaster PM ON PM.ProductId = CES.ProductId 
	JOIN TCD.TunnelProgramSetup TPS ON TPS.WasherGroupId = MS.GroupId AND TPS.EcolabAccountNumber = MS.EcoalabAccountNumber
	JOIN TCD.TunnelDosingSetup TDS ON tds.EcolabAccountNumber = TPS.EcolabAccountNumber 
		   AND TDS.TunnelProgramSetupId = TPS.TunnelProgramSetupId AND TDS.CompartmentNumber = TC.CompartmentNumber
	LEFT JOIN TCD.TunnelDosingProductMapping TDPM ON TDPM.CompartmentNumber = TC.CompartmentNumber AND TDPM.EcoLabAccountNumber = TDS.EcoLabAccountNumber
		   AND TDPM.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId AND TDPM.TunnelDosingSetupId = TDS.TunnelDosingSetupId
	 WHERE TC.CompartmentNumber = @CompartmentNumber AND MS.GroupId = @GroupId AND TDS.TunnelDosingSetupId = @DosingSetupId 
	 AND MS.EcoalabAccountNumber = @EcoLabAccountNumber 
	 AND TPS.TunnelProgramSetupId = @TunnelProgramSetupId
	END 
END
ELSE
BEGIN
	IF EXISTS (SELECT 1 FROM TCD.TunnelCompartment tc WHERE tc.WasherId = @TunnelId AND tc.CompartmentNumber = @CompartmentNumber AND tc.EcoLabAccountNumber = @EcoLabAccountNumber)
	BEGIN
	IF NOT EXISTS (SELECT 1 FROM TCD.TunnelDosingProductMapping tdpm WHERE tdpm.TunnelDosingSetupId = @DosingSetupId AND tdpm.EcoLabAccountNumber = @EcoLabAccountNumber)
	 BEGIN
	  SELECT 
	  0           AS  TunnelDosingProductMappingId,
	  TC.EcoLabAccountNumber      AS  EcoalabAccountNumber, 
	  CES.ControllerEquipmentSetupId    AS  ControllerEquipmentSetupId, 
	  PM.ProductId        AS  ProductId, 
	  ISNULL(NULLIF(pm2.EnvisionDisplayName, ' '),pm2.Name)  AS ProductName,
	  0.0           AS  Quantity,
	  0           AS  DelayTime,  
	  CAST(TC.[CompartmentNumber] AS INT)   AS  CompartmentNumber, 
	  MS.GroupId         AS  GroupId,
	  @LastModifiedTime       AS  LastModifiedTime,
	  @MyServiceFrmulaStpDsgDvcGuid    AS  MyServiceFrmulaStpDsgDvcGuid,
	  TCD.FnChemicalCostInOunce(PM.ProductId)  AS  Price,
	  GETUTCDATE()        AS  MyServiceLastSynchTime,
	  CAST(CES.ControllerEquipmentTypeId AS INT)    AS  ControllerEquipmentSetupTypeId
	FROM TCD.TunnelCompartmentEquipmentValveMapping tcevm
    INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.ControllerEquipmentSetupId = tcevm.ControllerEquipmentSetupId 
    AND tcevm.PlantID = @PlantId
	INNER JOIN TCD.TunnelCompartment TC ON  tc.CompartmentNumber = tcevm.CompartmentNumber AND tc.EcoLabAccountNumber = ces.EcoLabAccountNumber
	LEFT JOIN TCD.TunnelCompartmentEquipmentMapping tcem ON tcevm.ControllerEquipmentSetupID = tcem.ControllerEquipmentSetupId
    AND tc.TunnelCompartmentId = tcem.TunnelCompartmentId AND tcem.Is_Deleted = 'False'
    AND tcem.EcoLabAccountNumber = tc.EcoLabAccountNumber AND tcem.EcoLabAccountNumber = ces.EcoLabAccountNumber
	INNER JOIN TCD.MachineSetup ms ON ms.WasherId = tc.WasherId AND ms.ControllerId = ces.ControllerId AND ms.EcoalabAccountNumber = tc.EcoLabAccountNumber
    AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber AND ms.MachineInternalId = tcevm.TunnelNumber AND MS.IsTunnel = 'TRUE' AND MS.IsDeleted = 'FALSE'
	INNER JOIN TCD.ProductdataMapping pm ON pm.EcolabAccountNumber = ces.EcoLabAccountNumber AND pm.ProductID = ces.ProductId 
    INNER JOIN TCD.ProductMaster pm2 ON pm2.ProductId = pm.ProductID
	INNER JOIN TCD.TunnelProgramSetup TPS on TPS.WasherGroupId = MS.GroupId AND TPS.EcolabAccountNumber = MS.EcoalabAccountNumber
	 WHERE TC.CompartmentNumber = @CompartmentNumber AND MS.GroupId = @GroupId 
	 AND MS.EcoalabAccountNumber = @EcoLabAccountNumber 
	 AND TPS.TunnelProgramSetupId = @TunnelProgramSetupId
	END
	ELSE
	BEGIN
	SELECT 
	  ISNULL(TDPM.TunnelDosingProductMappingId,0)   AS  TunnelDosingProductMappingId,
	  TC.EcoLabAccountNumber      AS  EcoalabAccountNumber, 
	  CES.ControllerEquipmentSetupId    AS  ControllerEquipmentSetupId, 
	  PM.ProductId        AS  ProductId, 
	  ISNULL(NULLIF(pm2.EnvisionDisplayName, ' '),pm2.Name)  AS ProductName,
	  ISNULL(TDPM.Quantity,0.0) AS Quantity,
	  ISNULL(TDPM.DelayTime,0) AS DelayTime,   
	  CAST(TC.[CompartmentNumber] AS INT)   AS  CompartmentNumber, 
	  MS.GroupId         AS  GroupId,
	  TDPM.LastModifiedTime      AS  LastModifiedTime,
	  TDPM.MyServiceFrmulaStpDsgDvcGuid   AS  MyServiceFrmulaStpDsgDvcGuid,
	  TCD.FnChemicalCostInOunce(PM.ProductId)  AS  Price,
	  TDPM.MyServiceLastSynchTime     AS  MyServiceLastSynchTime,
	  CAST(CES.ControllerEquipmentTypeId AS INT)     AS  ControllerEquipmentSetupTypeId
	FROM TCD.TunnelCompartmentEquipmentValveMapping tcevm
    INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.ControllerEquipmentSetupId = tcevm.ControllerEquipmentSetupId 
    AND tcevm.PlantID = @PlantId
	INNER JOIN TCD.TunnelCompartment TC ON  tc.CompartmentNumber = tcevm.CompartmentNumber AND tc.EcoLabAccountNumber = ces.EcoLabAccountNumber
	LEFT JOIN TCD.TunnelCompartmentEquipmentMapping tcem ON tcevm.ControllerEquipmentSetupID = tcem.ControllerEquipmentSetupId
    AND tc.TunnelCompartmentId = tcem.TunnelCompartmentId AND tcem.Is_Deleted = 'False'
    AND tcem.EcoLabAccountNumber = tc.EcoLabAccountNumber AND tcem.EcoLabAccountNumber = ces.EcoLabAccountNumber
	INNER JOIN TCD.MachineSetup ms ON ms.WasherId = tc.WasherId AND ms.ControllerId = ces.ControllerId AND ms.EcoalabAccountNumber = tc.EcoLabAccountNumber
    AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber AND ms.MachineInternalId = tcevm.TunnelNumber AND MS.IsTunnel = 'TRUE' AND MS.IsDeleted = 'FALSE'
	INNER JOIN TCD.ProductdataMapping pm ON pm.EcolabAccountNumber = ces.EcoLabAccountNumber AND pm.ProductID = ces.ProductId 
    INNER JOIN TCD.ProductMaster pm2 ON pm2.ProductId = pm.ProductID
	INNER JOIN TCD.TunnelProgramSetup TPS on TPS.WasherGroupId = MS.GroupId AND TPS.EcolabAccountNumber = MS.EcoalabAccountNumber
	JOIN TCD.TunnelDosingSetup TDS ON tds.EcolabAccountNumber = TPS.EcolabAccountNumber 
		   AND TDS.TunnelProgramSetupId = TPS.TunnelProgramSetupId AND TDS.CompartmentNumber = TC.CompartmentNumber
	LEFT JOIN TCD.TunnelDosingProductMapping TDPM ON TDPM.CompartmentNumber = TC.CompartmentNumber AND TDPM.EcoLabAccountNumber = TDS.EcoLabAccountNumber
		   AND TDPM.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId AND TDPM.TunnelDosingSetupId = TDS.TunnelDosingSetupId
	 WHERE TC.CompartmentNumber = @CompartmentNumber AND MS.GroupId = @GroupId AND TDS.TunnelDosingSetupId = @DosingSetupId 
	 AND MS.EcoalabAccountNumber = @EcoLabAccountNumber 
	 AND TPS.TunnelProgramSetupId = @TunnelProgramSetupId
	END 
	END
	ELSE
	BEGIN
	IF NOT EXISTS (SELECT 1 FROM TCD.TunnelDosingProductMapping tdpm WHERE tdpm.TunnelDosingSetupId = @DosingSetupId AND tdpm.EcoLabAccountNumber = @EcoLabAccountNumber)
	 BEGIN
	 SELECT 
	  0           AS  TunnelDosingProductMappingId,
	  @EcoLabAccountNumber      AS  EcoalabAccountNumber, 
	  CES.ControllerEquipmentSetupId    AS  ControllerEquipmentSetupId, 
	  PM.ProductId        AS  ProductId, 
	  ISNULL(NULLIF(pm2.EnvisionDisplayName, ' '),pm2.Name)  AS ProductName,
	  0.0           AS  Quantity,
	  0           AS  DelayTime,  
	  CAST(tcevm.CompartmentNumber AS INT)   AS  CompartmentNumber, 
	  MS.GroupId         AS  GroupId,
	  @LastModifiedTime       AS  LastModifiedTime,
	  @MyServiceFrmulaStpDsgDvcGuid    AS  MyServiceFrmulaStpDsgDvcGuid,
	  TCD.FnChemicalCostInOunce(PM.ProductId)  AS  Price,
	  GETUTCDATE()        AS  MyServiceLastSynchTime,
	  CAST(CES.ControllerEquipmentTypeId AS INT)    AS  ControllerEquipmentSetupTypeId 
 FROM TCD.TunnelCompartmentEquipmentValveMapping tcevm
 INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.ControllerEquipmentSetupId = tcevm.ControllerEquipmentSetupID
 INNER JOIN TCD.MachineSetup ms ON ms.ControllerId = ces.ControllerId AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber AND ms.MachineInternalId = tcevm.TunnelNumber
 INNER JOIN TCD.ProductdataMapping pm ON pm.EcolabAccountNumber = ces.EcoLabAccountNumber AND pm.ProductID = ces.ProductId
 INNER JOIN TCD.ProductMaster pm2 ON pm2.ProductId = pm.ProductId
 WHERE (PM.Is_Deleted = 'FALSE' OR PM.Is_Deleted = 0)
 AND tcevm.CompartmentNumber = @CompartmentNumber
    AND tcevm.PlantID = @PlantId
 AND ms.WasherId = @TunnelId  AND ms.EcoalabAccountNumber =  @EcoLabAccountNumber
    AND MS.IsTunnel = 'TRUE' AND (MS.IsDeleted = 'FALSE' OR MS.IsDeleted = 0) 
	END
	ELSE
	BEGIN
		SELECT 
	  ISNULL(TDPM.TunnelDosingProductMappingId,0)   AS  TunnelDosingProductMappingId,
	  @EcoLabAccountNumber      AS  EcoalabAccountNumber, 
	  CES.ControllerEquipmentSetupId    AS  ControllerEquipmentSetupId, 
	  PM.ProductId        AS  ProductId, 
	  ISNULL(NULLIF(pm2.EnvisionDisplayName, ' '),pm2.Name)  AS ProductName,
	  ISNULL(TDPM.Quantity,0.0) AS Quantity,
	  ISNULL(TDPM.DelayTime,0) AS DelayTime,   
	  CAST(tcevm.[CompartmentNumber] AS INT)   AS  CompartmentNumber, 
	  MS.GroupId         AS  GroupId,
	  TDPM.LastModifiedTime      AS  LastModifiedTime,
	  TDPM.MyServiceFrmulaStpDsgDvcGuid   AS  MyServiceFrmulaStpDsgDvcGuid,
	  TCD.FnChemicalCostInOunce(PM.ProductId)  AS  Price,
	  TDPM.MyServiceLastSynchTime     AS  MyServiceLastSynchTime,
	  CAST(CES.ControllerEquipmentTypeId AS INT)     AS  ControllerEquipmentSetupTypeId
	FROM TCD.TunnelCompartmentEquipmentValveMapping tcevm
    INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.ControllerEquipmentSetupId = tcevm.ControllerEquipmentSetupId 
    AND tcevm.PlantID = @PlantId
	INNER JOIN TCD.MachineSetup ms ON ms.ControllerId = ces.ControllerId AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber AND ms.MachineInternalId = tcevm.TunnelNumber
    AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber AND ms.MachineInternalId = tcevm.TunnelNumber AND MS.IsTunnel = 'TRUE' AND MS.IsDeleted = 'FALSE'
	INNER JOIN TCD.ProductdataMapping pm ON pm.EcolabAccountNumber = ces.EcoLabAccountNumber AND pm.ProductID = ces.ProductId 
    INNER JOIN TCD.ProductMaster pm2 ON pm2.ProductId = pm.ProductID
	INNER JOIN TCD.TunnelProgramSetup TPS on TPS.WasherGroupId = MS.GroupId AND TPS.EcolabAccountNumber = MS.EcoalabAccountNumber
	JOIN TCD.TunnelDosingSetup TDS ON tds.EcolabAccountNumber = TPS.EcolabAccountNumber 
		   AND TDS.TunnelProgramSetupId = TPS.TunnelProgramSetupId AND TDS.CompartmentNumber = tcevm.CompartmentNumber
	LEFT JOIN TCD.TunnelDosingProductMapping TDPM ON TDPM.CompartmentNumber = tcevm.CompartmentNumber AND TDPM.EcoLabAccountNumber = TDS.EcoLabAccountNumber
		   AND TDPM.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId AND TDPM.TunnelDosingSetupId = TDS.TunnelDosingSetupId
	 WHERE tcevm.CompartmentNumber = @CompartmentNumber AND MS.GroupId = @GroupId AND TDS.TunnelDosingSetupId = @DosingSetupId 
	 AND MS.EcoalabAccountNumber = @EcoLabAccountNumber 
	 AND TPS.TunnelProgramSetupId = @TunnelProgramSetupId
	END
	END
END 

 
SET NOCOUNT OFF

END
GO
----------------------------------------------------------
 IF  EXISTS (SELECT
			*
		FROM sys.objects 
		WHERE object_id = OBJECT_ID(N'[TCD].[GetTunnelProductListForFormulaWithInjectionCount]') 
			AND type IN (N'P', N'PC'))
BEGIN
	DROP PROCEDURE [TCD].[GetTunnelProductListForFormulaWithInjectionCount]
END
GO

CREATE PROCEDURE [TCD].[GetTunnelProductListForFormulaWithInjectionCount]
     @EcoLabAccountNumber      NVARCHAR(25)
    , @GroupId         INT
    , @TunnelProgramSetupId      INT
AS
BEGIN
DECLARE @Count INT = NULL
,  @PlantId INT 
,  @ControllerModelId INT
,  @ControllerId INT
,  @TunnelId INT

SELECT @Count = ms.NumberOfComp, @TunnelId = ms.WasherId FROM TCD.MachineSetup ms WHERE ms.GroupId = @GroupId AND ms.IsDeleted = 'False' AND ms.EcoalabAccountNumber = @EcoLabAccountNumber AND ms.IsTunnel = 1

SELECT @PlantId = PlantId FROM TCD.Plant WHERE EcolabAccountNumber = @EcoLabAccountNumber

 SELECT @ControllerId = ISNULL(WG.ControllerId, - 1)
 FROM [TCD].WasherGroup WG
 WHERE WG.EcolabAccountNumber = @EcoLabAccountNumber
 AND WG.WasherGroupId = @GroupId

SELECT @ControllerModelId = cc.ControllerModelId from tcd.ConduitController cc WHERE cc.ControllerId = @ControllerId AND cc.EcoalabAccountNumber = @EcoLabAccountNumber

SET NOCOUNT ON
IF (@ControllerModelId < 7  OR @ControllerModelId IN (12, 13))
BEGIN
   SELECT TOP (@Count)  TDS.[TunnelDosingSetupId]
   ,TDS.CompartmentNumber
   ,TDS.GroupId
   , (Count(CASE WHEN tcem.Is_Deleted = 1 THEN NULL ELSE tcem.ControllerEquipmentSetupId END)) AS TotalInjections
  FROM TCD.TunnelDosingSetup tds 
  INNER JOIN TCD.TunnelProgramSetup tps 
  ON tps.TunnelProgramSetupId = tds.TunnelProgramSetupId AND tps.EcolabAccountNumber = tds.EcolabAccountNumber
  INNER JOIN TCD.MachineSetup ms ON ms.GroupId = tps.WasherGroupId AND ms.EcoalabAccountNumber = tps.EcolabAccountNumber 
  LEFT JOIN TCD.TunnelCompartment tc ON tc.CompartmentNumber = tds.CompartmentNumber AND TC.EcoLabAccountNumber = TDS.EcolabAccountNumber 
                     AND tc.WasherId = ms.WasherId AND ms.IsDeleted = 'False'
  LEFT JOIN TCD.TunnelCompartmentEquipmentMapping tcem ON tcem.EcoLabAccountNumber = tc.EcoLabAccountNumber 
  AND tcem.TunnelCompartmentId = tc.TunnelCompartmentId AND tcem.Is_Deleted = 'False'
  
  WHERE 
  TDS.EcolabAccountNumber = @EcoLabAccountNumber 
  AND 
  TDS.GroupId = @GroupId
  AND
  TDS.TunnelProgramSetupId = @TunnelProgramSetupId
  AND 
  MS.IsTunnel = 'TRUE'
  AND
  MS.IsDeleted = 'FALSE'
  Group By
     TDS.[TunnelDosingSetupId]
     ,TDS.[CompartmentNumber]
     ,TDS.[GroupId] 

  Order By TDS.CompartmentNumber
END
ELSE
BEGIN
  SELECT 
	 TOP (@Count)  TDS.[TunnelDosingSetupId]
   ,TDS.CompartmentNumber
   ,TDS.GroupId
   ,(Count(DISTINCT tcevm.TunnelCompartmentEquipmentValveMappingID)) AS TotalInjections
   FROM TCD.TunnelDosingSetup tds
   INNER JOIN TCD.TunnelProgramSetup tps ON tps.TunnelProgramSetupId = tds.TunnelProgramSetupId
   INNER JOIN TCD.MachineSetup ms ON ms.GroupId = tps.WasherGroupId AND ms.EcoalabAccountNumber = tps.EcolabAccountNumber AND ms.IsDeleted = 0 AND ms.IsTunnel = 1
   INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.ControllerId = ms.ControllerId
   LEFT JOIN TCD.TunnelCompartment tc ON tc.WasherId = ms.WasherId AND tc.EcoLabAccountNumber = ms.EcoalabAccountNumber AND tc.CompartmentNumber = tds.CompartmentNumber
   LEFT JOIN TCD.TunnelCompartmentEquipmentMapping tcem ON tcem.EcoLabAccountNumber = tc.EcoLabAccountNumber AND tcem.TunnelCompartmentId = tc.TunnelCompartmentId 
   AND tcem.Is_Deleted = 0
   LEFT JOIN TCD.TunnelCompartmentEquipmentValveMapping tcevm ON tcevm.ControllerEquipmentSetupID = ces.ControllerEquipmentSetupId AND ms.MachineInternalId = tcevm.TunnelNumber
   AND tcevm.CompartmentNumber = tds.CompartmentNumber
    WHERE MS.GroupId = @GroupId AND TDS.TunnelProgramSetupId = @TunnelProgramSetupId 
	 AND MS.EcoalabAccountNumber = @EcoLabAccountNumber 
	 AND TPS.TunnelProgramSetupId = @TunnelProgramSetupId
	 	 Group By
     TDS.[TunnelDosingSetupId]
     ,TDS.[CompartmentNumber]
     ,TDS.[GroupId] 
	 Order By TDS.CompartmentNumber
	END
	
SET NOCOUNT OFF

END
GO
--------------------------------------------------------------------------
IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.COLUMNS c WHERE c.TABLE_NAME = 'WasherDosingProductMapping' AND c.TABLE_SCHEMA = 'TCD' AND c.COLUMN_NAME = 'ControllerEquipmentSetupId')
BEGIN
    ALTER TABLE TCD.WasherDosingProductMapping ADD [ControllerEquipmentSetupId] smallint NULL 
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.COLUMNS c WHERE c.TABLE_NAME = 'WasherDosingProductMappingHistory' AND c.TABLE_SCHEMA = 'TCD' AND c.COLUMN_NAME = 'ControllerEquipmentSetupId')
BEGIN
    ALTER TABLE TCD.WasherDosingProductMappingHistory ADD [ControllerEquipmentSetupId] smallint NULL 
END
GO

IF NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.COLUMNS c WHERE c.TABLE_NAME = 'WasherDosingProductMappingHistory' AND c.TABLE_SCHEMA = 'TCD' AND c.COLUMN_NAME = 'IsDeleted')
BEGIN
	ALTER TABLE TCD.WasherDosingProductMappingHistory ADD [IsDeleted] [bit]  NULL
	ALTER TABLE TCD.WasherDosingProductMappingHistory ADD [Delay] [smallint] NULL 
END
GO
------------------------------------------------------------------------------------------------------------------------------------------------------
IF EXISTS(SELECT
			*
		FROM sys.triggers
		WHERE object_id = OBJECT_ID(N'[TCD].[WasherDosingProductMappingAuditTrigger]'))
	BEGIN
		DROP TRIGGER
			TCD.WasherDosingProductMappingAuditTrigger;
	END; 
	GO 

	CREATE	TRIGGER		[TCD].WasherDosingProductMappingAuditTrigger
ON					[TCD].WasherDosingProductMapping
FOR	INSERT, UPDATE
AS
BEGIN

SET	NOCOUNT	ON

DECLARE	@AuditOperation_SQLInsertId			TINYINT				=			NULL
	,	@AuditOperation_SQLUpdateId			TINYINT				=			NULL
	,	@AuditOperationId					TINYINT				=			NULL
	,	@ErrorNumber						INT					=			0
	,	@ErrorMessage						NVARCHAR(2048)		=			NULL
	,	@ErrorSeverity						INT					=			NULL
	,	@ErrorProcedure						SYSNAME				=			NULL
	,	@MessageString						NVARCHAR(2500)		=			NULL
	--,	@SoftDeleteFlag						BIT					=			NULL			--0 for FALSE/1 for TRUE			--SQLEnlight SA0004
	,	@CurrentTimeStamp					DATETIME			=			GETUTCDATE()	--CURRENT_TIMESTAMP

--select	*	from	AuditOperation
SELECT	@AuditOperation_SQLInsertId			=			AO.OperationId
FROM	[TCD].AuditOperation					AO
WHERE	AO.OperationCode					=			'SQLInsert'

SELECT	@AuditOperation_SQLUpdateId			=			AO.OperationId
FROM	[TCD].AuditOperation					AO
WHERE	AO.OperationCode					=			'SQLUpdate'

BEGIN	TRY
	SET @AuditOperationId = @AuditOperation_SQLInsertId;
	IF UPDATE(Quantity)
		SET @AuditOperationId = @AuditOperation_SQLUpdateId
	
		INSERT	[TCD].[WasherDosingProductMappingHistory]	(
				WasherDosingProductMappingId	,OperationTimestamp	,OperationId					,OperationByUserId		,[EcolabAccountNumber]	,WasherDosingSetupId
			,	InjectionNumber					,ProductId			,Quantity		
			--	Adding cols. for myService integration
			,	MyServiceFrmulaStpDsgDvcGuid
			,	MyServiceLastSynchTime
			,	[Delay]
			,	IsDeleted
			,	ControllerEquipmentSetupId
			)
		SELECT	WasherDosingProductMappingId	,@CurrentTimeStamp	,@AuditOperationId	,LastModifiedByUserId	,[EcolabAccountNumber]	,WasherDosingSetupId
			,	InjectionNumber					,ProductId			,Quantity
			--	Adding cols. for myService integration
			,	MyServiceFrmulaStpDsgDvcGuid
			,	MyServiceLastSynchTime
			,	[Delay]
			,	IsDeleted
			,	ControllerEquipmentSetupId
		FROM	[inserted]

END	TRY
BEGIN	CATCH

		SELECT	@ErrorNumber				=			ERROR_NUMBER()
			,	@ErrorMessage				=			ERROR_MESSAGE()
			,	@ErrorProcedure				=			ERROR_PROCEDURE()
			,	@ErrorSeverity				=			ERROR_SEVERITY()

		--GOTO	ErrorHandler
		SET		@MessageString				=	N'An error occured while updating Audit data for WasherDosingProductMapping table. The error is: '
											+	@ErrorMessage + '	'
											+	'Module: ' + @ErrorProcedure
		RAISERROR(@MessageString, @ErrorSeverity, 1)
		RETURN

END	CATCH


IF	@ErrorNumber	=	0
	--GOTO	ExitModule
	RETURN
		


ErrorHandler:

SET		@MessageString						=	N'An error occured while updating Audit data for WasherDosingProductMapping table. The error is: '
											+	@ErrorMessage + '	'
											+	'Module: ' + @ErrorProcedure
RAISERROR(@MessageString, @ErrorSeverity, 1)



ExitModule:

SET	NOCOUNT	OFF

RETURN


END
GO
-------------------------------------------------------------------------------------------------------------------------------------------
IF EXISTS( SELECT *
			 FROM sys.objects
			 WHERE object_id = OBJECT_ID( N'[TCD].[SaveWasherDosingProduct]' )
				AND type IN( N'P' , N'PC' )
		 )
	BEGIN
		DROP PROCEDURE TCD.SaveWasherDosingProduct;
	END;
GO
CREATE	PROCEDURE	[TCD].[SaveWasherDosingProduct]	(
@EcoLabAccountNumber					NVARCHAR(1000)
,	@WasherDosingSetupId					INT
,	@ProgramSetupId							INT
,	@InjectionNumber						SMALLINT	=			NULL
,	@ProductId								INT			=			NULL
,	@Quantity								DECIMAL(18,2)=			NULL
,	@IsDeleted								BIT			=			'FALSE'	--DO NOT SET THIS (to TRUE) UNLESS DELETE IS INTENDED
,	@UserId									INT			=			NULL
,	@LastModifiedTimestampAtCentral			DATETIME					=	NULL
,	@MyServiceFrmulaStpDsgDvcGuid			UNIQUEIDENTIFIER	=		NULL
,   @WasherDosingProductMapId				INT						=	NULL
,	@Delay									SMALLINT				=	NULL
,	@ControllerEquipmentSetupId				SMALLINT				=	NULL
)
AS
BEGIN

SET	NOCOUNT	ON

DECLARE
@ReturnValue					INT					=			0
,	@ErrorId						INT					=			0
,	@ErrorMessage					NVARCHAR(4000)		=			N''
,	@CurrentUTCTime					DATETIME			=			GETUTCDATE()



SET	@LastModifiedTimestampAtCentral						=			ISNULL(@LastModifiedTimestampAtCentral, NULL)				--SQLEnlight SA0029

IF @ControllerEquipmentSetupId = 0
BEGIN
	SET @ControllerEquipmentSetupId = NULL
END

IF	NOT	EXISTS (SELECT	1
FROM	[TCD].WasherDosingProductMapping
WHERE	WasherDosingSetupId			=			@WasherDosingSetupId
AND	ProductId					=			@ProductId
AND WasherDosingProductMappingId = @WasherDosingProductMapId
AND EcoLabAccountNumber=@EcoLabAccountNumber
)
BEGIN

IF @IsDeleted = 'False'
BEGIN
-- For setting the next available injection number.
DECLARE @AvailableInjectionNumber int
DECLARE @WasherDosingProductMappingId INT

INSERT INTO	[TCD].WasherDosingProductMapping (
EcoLabAccountNumber
,	WasherDosingSetupId
,	InjectionNumber
,	ProductId
,	Quantity
,	LastModifiedByuserId
,	MyServiceFrmulaStpDsgDvcGuid
,	IsDeleted
,	[Delay]
,	[ControllerEquipmentSetupId]
)

SELECT
@EcoLabAccountNumber			AS			EcoLabAccountNumber
,	@WasherDosingSetupId			AS			WasherDosingSetupId
,	@InjectionNumber				AS			InjectionNumber
,	@ProductId						AS			ProductId
,	@Quantity						AS			Quantity
,	@UserId							AS			UserId
,	@MyServiceFrmulaStpDsgDvcGuid	AS			MyServiceFrmulaStpDsgDvcGuid
,	@IsDeleted						AS			IsDeleted
,	@Delay							AS			[Delay]
,	@ControllerEquipmentSetupId		AS			ControllerEquipmentSetupId


SET @WasherDosingProductMappingId=SCOPE_IDENTITY()

IF @InjectionNumber = 0 AND (SELECT COUNT(WasherDosingSetupId) FROM [TCD].WasherDosingProductMapping WHERE WasherDosingSetupId=@WasherDosingSetupId AND IsDeleted<>'True' AND InjectionNumber<>0)=0
BEGIN
SELECT @AvailableInjectionNumber= MAX(wdpm.InjectionNumber)+1 FROM TCD.WasherDosingProductMapping wdpm INNER JOIN TCD.WasherDosingSetup wds
ON wds.WasherDosingSetupId = wdpm.WasherDosingSetupId
WHERE  wds.WasherProgramSetupId = @ProgramSetupId AND wdpm.EcoLabAccountNumber=@EcoLabAccountNumber --AND wdpm.IsDeleted='False'
END
ELSE
BEGIN
SELECT TOP 1 @AvailableInjectionNumber= wdpm.InjectionNumber FROM TCD.WasherDosingProductMapping wdpm WHERE WasherDosingSetupId=@WasherDosingSetupId
END


IF @AvailableInjectionNumber>0
BEGIN
UPDATE TCD.WasherDosingProductMapping
SET	   InjectionNumber=@AvailableInjectionNumber
WHERE   WasherDosingProductMappingId=@WasherDosingProductMappingId
END






--check for any error
SET	@ErrorId	=	@@ERROR

IF	(@ErrorId	<>	0)
BEGIN
SET		@ErrorMessage			=			N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred overswriting wash step PRODUCT data.'
--GOTO	Errorhandler
RAISERROR	(@ErrorMessage, 16, 1)
SET	@ReturnValue	=	-1
RETURN	(@ReturnValue)
END
END
END
ELSE
BEGIN
-- UPDate

UPDATE [TCD].WasherDosingProductMapping
SET
InjectionNumber					=		@InjectionNumber
,	ProductId						=		@ProductId
,	Quantity						=		@Quantity
,	LastModifiedByuserId			=		@UserId
,	IsDeleted						=		@IsDeleted
,	[Delay]							=		@Delay
,	LastModifiedTime				=		GETUTCDATE()
,	ControllerEquipmentSetupId		=		@ControllerEquipmentSetupId
WHERE   WasherDosingSetupId				=		@WasherDosingSetupId
AND		EcolabAccountNumber				=		@EcolabAccountNumber
AND		WasherDosingProductMappingId	=		@WasherDosingProductMapId
AND		IsDeleted						=		0



END

-- For Reording the washer injection based on the update or insert of the productdosing for the washer.
EXEC [TCD].[WasherInjectionOrdering] @ProgramSetupId,@EcolabAccountNumber




IF	(	@ErrorId	=	0	)
BEGIN
--GOTO	ExitModule
RETURN	(@ReturnValue)
END


--ErrorHandler:
--RAISERROR	(@ErrorMessage, 16, 1)
--SET	@ReturnValue	=	-1


--ExitModule:

SET	NOCOUNT	OFF
RETURN	(@ReturnValue)


END
GO
-------------------------------------------------------------------------------------------------------
IF EXISTS( SELECT *
			 FROM sys.objects
			 WHERE object_id = OBJECT_ID( N'[TCD].[GetWasherGroupInjectionDetailsForMyControl]' )
				AND type IN( N'P' , N'PC' )
		 )
	BEGIN
		DROP PROCEDURE TCD.GetWasherGroupInjectionDetailsForMyControl;
	END;
GO
CREATE PROCEDURE [TCD].[GetWasherGroupInjectionDetailsForMyControl](@EcolabAccountNumber	VARCHAR(1000) = NULL, 
                                                                    @WasherGroupId			INT = NULL,
                                                                    @WasherProgramSetupId	INT = NULL,
																	@ControllerId			INT = NULL)
AS 
  BEGIN 
      DECLARE @WasherGroupTypeId TINYINT = NULL 

      SET @WasherGroupTypeId = (SELECT Washergrouptypeid 
                                FROM   TCD.washergroup 
                                WHERE  Washergroupid = @WasherGroupId 
                                       AND Ecolabaccountnumber = @EcolabAccountNumber) 

      IF( @WasherGroupTypeId = 1 ) 
        BEGIN 
            SELECT DISTINCT WPS.Programid, 
                            WDS.Washerdosingsetupid, 
                            WG.Washergroupnumber, 
                            WG.Washergroupname, 
                            WPS.Nominalload              AS NominalLoad, 
                            WPS.Loadspermonth            AS LoadsPerMonth, 
                            WPS.Totalruntime             AS TotalRunTime,
							WDS.StepRunTime				 AS RunTime,
							WDS.DrainDestinationId		 AS DrainDestination, 
                            WPS.Extratime                AS ExtraTime, 
                            WPS.Totalsteps               AS NoOfWashSteps, 
                            WPS.Cooldownstep             AS CooldownStep, 
                            PRGM.Ecolabtextilecategoryid AS EcolabTextileCategoryId, 
                            WDS.Stepnumber               AS WashStepNumber, 
                            WDP.Injectionnumber          AS InjectionNumber, 
                            WDS.Temperature              AS Temperature, 
							WDACM.MinimumTime            AS Mintime, 
                            WDACM.StartDelay             AS StartDelay, 
                            WDACM.AcceptedDelay          AS AcceptDelay, 
							WDACM.ProductId				 AS ProductCheck,
							WDACM.SetPointTemperature    AS SetPoint,
                            WDP.Quantity, 
                            WDP.Delay, 
                            WDACM.Phcontrolduringdrain   AS PHControlDuringDrain, 
                            WDACM.Phdelaytime            AS PHControlDelayTime, 
                            WDACM.Phmeasuringtime        AS PHControlMeasuringTime, 
                            WDACM.Phmaximum              AS PHControlMaximum, 
                            WDACM.Phmininum              AS PHControlMinimum, 
                            PM.Productid, 
                            PM.NAME, 
                            WPS.Programnumber, 
                            WPS.Washerprogramsetupid, 
                            WDS.Watertype, 
                            WDS.Waterlevel,
							WG.ControllerId,
							CES.ControllerEquipmentId,
							WDP.WasherDosingProductMappingId
            FROM   [TCD].[washerdosingsetup] WDS 
                   INNER JOIN [TCD].[washerprogramsetup] WPS 
                           ON WPS.[Washerprogramsetupid] = WDS.[Washerprogramsetupid] 
                              AND WDS.Is_deleted = 0 
                   INNER JOIN TCD.washergroup WG 
                           ON WG.Controllerid = WPS.Controllerid 
                              AND WPS.Is_deleted = 0 
                   INNER JOIN TCD.injection IJ 
                           ON WG.Washergroupnumber = IJ.Washergroupnumber 
                              AND IJ.Is_deleted = 0 
                   INNER JOIN TCD.conduitcontroller CC 
                           ON IJ.Controllerid = CC.Controllerid 
                              AND CC.Isdeleted = 0 
                              --AND CC.Active = 1 
                   INNER JOIN TCD.controllertype CT 
                           ON CC.Controllertypeid = CT.Id 
                   INNER JOIN TCD.programmaster PRGM 
                           ON PRGM.Programid = WPS.Programid 
                   LEFT OUTER JOIN TCD.[washerdosinganalogcontrollermapping] WDACM 
                                ON WDACM.Washerdosingsetupid = WDS.Washerdosingsetupid 
                   LEFT OUTER JOIN TCD.[washertempsetup] WTS 
                                ON WPS.Programnumber = WTS.Programnumber 
                   LEFT JOIN TCD.washerdosingproductmapping WDP 
                          ON WDS.Washerdosingsetupid = WDP.Washerdosingsetupid 
                             AND WDP.Isdeleted = 0 
                   LEFT JOIN TCD.productmaster PM 
                          ON WDP.Productid = PM.Productid 
                             AND pm.Is_deleted = 0 
                   INNER JOIN TCD.controllerequipmentsetup CES 
                           ON CES.Productid = PM.Productid 
                              AND CES.Isactive = 1 
                              AND CES.Controllerid = CC.Controllerid
							  AND CES.ControllerEquipmentSetupId = WDP.ControllerEquipmentSetupId 
                   LEFT JOIN [TCD].washstep WS 
                          ON WS.Stepid = WDS.Steptypeid 
                             AND WS.Isactive = 1 
             WHERE  WG.washergroupid = @WasherGroupId 
				   AND WG.ecolabaccountnumber = @EcolabAccountNumber 
				   AND cc.controllerid = @ControllerId 
				   AND WPS.WasherProgramSetupId = ISNULL(@WasherProgramSetupId, WPS.WasherProgramSetupId)
				   AND WDP.injectionnumber IS NOT NULL 
        END 
      ELSE 
        BEGIN 
            SELECT DISTINCT TPS.Programid, 
                            TDS.Tunneldosingsetupid, 
                            WG.Washergroupnumber, 
                            WG.Washergroupname, 
                            TPS.Nominalload              AS NominalLoad, 
                            TPS.Loadspermonth            AS LoadsPerMonth, 
                            TPS.Totalruntime             AS TotalRunTime, 
                            TPS.Extratime                AS ExtraTime, 
                            PRGM.Ecolabtextilecategoryid AS EcolabTextileCategoryId, 
                            TDS.Compartmentnumber        AS CompartmentNumber, 
                            TDP.Injectionnumber          AS InjectionNumber, 
                            TDS.PhRegLevel,
							TDS.MonLevel				 AS PhMonLevel,
							TDS.ConRegLevel, 
                            TDS.Temperature              AS Temperature, 
                            TTS.Mintime                  AS Mintime, 
                            TTS.Startdelay               AS StartDelay, 
                            TTS.Acceptdelay              AS AcceptDelay, 
                            TTS.Productcheck             AS ProductCheck, 
							TTS.DesiredTemperature		 AS SetPoint,
                            TDP.Quantity, 
                            TDP.Delaytime, 
                            PM.Productid, 
                            PM.NAME, 
                            TPS.Programnumber, 
                            TPS.Tunnelprogramsetupid, 
                            TDS.Watertype, 
                            TDS.Waterlevel,
							WG.ControllerId,
							CES.ControllerEquipmentId,  
							WG.WasherDosingNumber,
							TCEVM.DosingPointNumber
             FROM   [TCD].[tunneldosingsetup] TDS 
                   INNER JOIN [TCD].[tunnelprogramsetup] TPS 
                           ON TPS.[Tunnelprogramsetupid] = TDS.[Tunnelprogramsetupid] 
                              AND TDS.Is_deleted = 0 
                   INNER JOIN TCD.washergroup WG 
                           ON WG.Washergroupid = TPS.Washergroupid 
                              AND TPS.Is_deleted = 0 
                   LEFT JOIN TCD.injection IJ 
                           ON WG.Washergroupnumber = IJ.Washergroupnumber 
                              AND IJ.Is_deleted = 0 
                   LEFT JOIN TCD.conduitcontroller CC 
                           ON IJ.ControllerId = WG.ControllerId
                              AND CC.Isdeleted = 0 
                              --AND CC.Active = 1 
                   LEFT JOIN TCD.controllertype CT 
                           ON CC.Controllertypeid = CT.Id 
                   INNER JOIN TCD.programmaster PRGM 
                           ON PRGM.Programid = TPS.Programid 
                   LEFT JOIN TCD.[tunneltempsetup] TTS 
                                ON TPS.Tunnelprogramsetupid = TTS.Tunnelprogramsetupid AND TTS.CompartmentNumber = TDS.CompartmentNumber
                   INNER JOIN TCD.tunneldosingproductmapping TDP 
                          ON TDS.Tunneldosingsetupid = TDP.Tunneldosingsetupid
				   INNER JOIN TCD.controllerequipmentsetup CES 
					        ON CES.ControllerEquipmentSetupId  = TDP.ControllerEquipmentSetupId
					           AND CES.Isactive = 1 
							   LEFT JOIN TCD.productmaster PM 
					       ON PM.Productid = CES.Productid 
					          AND pm.Is_deleted = 0
					LEFT JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM
					     ON TCEVM.ControllerEquipmentSetupID = CES.ControllerEquipmentSetupId
							AND TCEVM.TunnelNumber = WG.WasherDosingNumber
							AND ((TCEVM.DosingPointNumber = 0) OR (TCEVM.compartmentnumber = TDS.compartmentnumber AND TCEVM.DosingPointNumber <> 0))
					LEFT JOIN [TCD].washstep WS 
					       ON WS.Stepid = TDS.Steptypeid 
					          AND WS.Isactive = 1 
            WHERE  WG.washergroupid = @WasherGroupId 
				   AND WG.ecolabaccountnumber = @EcolabAccountNumber 
				   AND WG.controllerid = @ControllerId
					AND TCEVM.DosingPointNumber IS NOT NULL				   
        END 
  END 
GO
----------------------------------------------------------------------------------------------------------------------------------------
IF EXISTS( SELECT *
			 FROM sys.objects
			 WHERE object_id = OBJECT_ID( N'[TCD].[GetWasherGroupFromulaInjectionDetailsForMyControl]' )
				AND type IN( N'P' , N'PC' )
		 )
	BEGIN
		DROP PROCEDURE TCD.GetWasherGroupFromulaInjectionDetailsForMyControl;
	END;
GO
CREATE PROCEDURE [TCD].[GetWasherGroupFromulaInjectionDetailsForMyControl](@EcolabAccountNumber  VARCHAR(1000) = NULL, 
                                                                           @WasherGroupId        INT = NULL,
                                                                           @WasherProgramSetupId INT = NULL)
AS 
  BEGIN 
      DECLARE @WasherGroupTypeId TINYINT =NULL 

      SET @WasherGroupTypeId = (SELECT Washergrouptypeid 
                                FROM   TCD.washergroup 
                                WHERE  Washergroupid = @WasherGroupId 
                                       AND Ecolabaccountnumber = @EcolabAccountNumber) 

      IF( @WasherGroupTypeId = 1 ) 
        BEGIN 
            SELECT DISTINCT WPS.Programid, 
                            WDS.Washerdosingsetupid, 
                            WG.Washergroupnumber, 
                            WG.Washergroupname, 
                            WPS.Nominalload              AS NominalLoad, 
                            WPS.Loadspermonth            AS LoadsPerMonth, 
                            WPS.Totalruntime             AS TotalRunTime,
							WDS.StepRunTime				 AS RunTime,
							WDS.DrainDestinationId		 AS DrainDestination,  
                            WPS.Extratime                AS ExtraTime, 
                            WPS.Totalsteps               AS NoOfWashSteps, 
                            WPS.Cooldownstep             AS CooldownStep, 
                            PRGM.Ecolabtextilecategoryid AS EcolabTextileCategoryId, 
                            WDS.Stepnumber               AS WashStepNumber, 
                            WDP.Injectionnumber          AS InjectionNumber, 
                            WDS.Temperature              AS Temperature, 
                            WDACM.MinimumTime            AS Mintime, 
                            WDACM.StartDelay             AS StartDelay, 
                            WDACM.AcceptedDelay          AS AcceptDelay, 
							WDACM.ProductId				 AS ProductCheck,
							WDACM.SetPointTemperature    AS SetPoint, 
                            WDP.Quantity, 
                            WDP.Delay, 
                            WDACM.Phcontrolduringdrain   AS PHControlDuringDrain, 
                            WDACM.Phdelaytime            AS PHControlDelayTime, 
                            WDACM.Phmeasuringtime        AS PHControlMeasuringTime, 
                            WDACM.Phmaximum              AS PHControlMaximum, 
                            WDACM.Phmininum              AS PHControlMinimum, 
                            PM.Productid, 
                            PM.NAME, 
                            WPS.Programnumber, 
                            WPS.Washerprogramsetupid, 
                            WDS.Watertype, 
                            WDS.Waterlevel,
							WG.ControllerId,
							CES.ControllerEquipmentId,
							WDP.WasherDosingProductMappingId 
            FROM   [TCD].[washerdosingsetup] WDS 
                   INNER JOIN [TCD].[washerprogramsetup] WPS 
                           ON WPS.[Washerprogramsetupid] = WDS.[Washerprogramsetupid] 
                              AND WDS.Is_deleted = 0 
                   INNER JOIN TCD.washergroup WG 
                           ON WG.Controllerid = WPS.Controllerid 
                              AND WPS.Is_deleted = 0 
                   INNER JOIN TCD.injection IJ 
                           ON WG.Washergroupnumber = IJ.Washergroupnumber 
                              AND IJ.Is_deleted = 0 
                   INNER JOIN TCD.conduitcontroller CC 
                           ON IJ.Controllerid = CC.Controllerid 
                              AND CC.Isdeleted = 0 
                              --AND CC.Active = 1 
                   INNER JOIN TCD.controllertype CT 
                           ON CC.Controllertypeid = CT.Id 
                   INNER JOIN TCD.programmaster PRGM 
                           ON PRGM.Programid = WPS.Programid 
                   LEFT OUTER JOIN TCD.[washerdosinganalogcontrollermapping] WDACM 
                                ON WDACM.Washerdosingsetupid = WDS.Washerdosingsetupid 
                   LEFT OUTER JOIN TCD.[washertempsetup] WTS 
                                ON WPS.Programnumber = WTS.Programnumber 
                   LEFT JOIN TCD.washerdosingproductmapping WDP 
                          ON WDS.Washerdosingsetupid = WDP.Washerdosingsetupid 
                             AND WDP.Isdeleted = 0 
                   LEFT JOIN TCD.productmaster PM 
                          ON WDP.Productid = PM.Productid 
                             AND pm.Is_deleted = 0 
                   INNER JOIN TCD.controllerequipmentsetup CES 
                           ON CES.Productid = PM.Productid 
                              AND CES.Isactive = 1 
                              AND CES.Controllerid = CC.Controllerid 
							  AND CES.ControllerEquipmentSetupId = WDP.ControllerEquipmentSetupId 
                   LEFT JOIN [TCD].washstep WS 
                          ON WS.Stepid = WDS.Steptypeid 
                             AND WS.Isactive = 1 
            WHERE  WG.Washergroupid = @WasherGroupId 
                   AND WPS.Washerprogramsetupid = @WasherProgramSetupId 
                   AND WPS.Ecolabaccountnumber = @EcolabAccountNumber 
        END 
      ELSE 
        BEGIN 
            SELECT DISTINCT TPS.Programid, 
                            TDS.Tunneldosingsetupid, 
                            WG.Washergroupnumber, 
                            WG.Washergroupname, 
                            TPS.Nominalload              AS NominalLoad, 
                            TPS.Loadspermonth            AS LoadsPerMonth, 
                            TPS.Totalruntime             AS TotalRunTime, 
                            TPS.Extratime                AS ExtraTime, 
                            PRGM.Ecolabtextilecategoryid AS EcolabTextileCategoryId, 
                            TDS.Compartmentnumber        AS CompartmentNumber, 
                            TDP.Injectionnumber          AS InjectionNumber, 
                            TDS.PhRegLevel,
							TDS.MonLevel				 AS PhMonLevel,
							TDS.ConRegLevel, 
                            TDS.Temperature              AS Temperature, 
                            TTS.Mintime                  AS Mintime, 
                            TTS.Startdelay               AS StartDelay, 
                            TTS.Acceptdelay              AS AcceptDelay, 
                            TTS.Productcheck             AS ProductCheck, 
							TTS.DesiredTemperature		 AS SetPoint,
                            TDP.Quantity, 
                            TDP.Delaytime, 
                            PM.Productid, 
                            PM.NAME, 
                            TPS.Programnumber, 
                            TPS.Tunnelprogramsetupid, 
                            TDS.Watertype, 
                            TDS.Waterlevel,
							WG.ControllerId,
							CES.ControllerEquipmentId,  
							WG.WasherDosingNumber,
							TCEVM.DosingPointNumber
             FROM   [TCD].[tunneldosingsetup] TDS 
                   INNER JOIN [TCD].[tunnelprogramsetup] TPS 
                           ON TPS.[Tunnelprogramsetupid] = TDS.[Tunnelprogramsetupid] 
                              AND TDS.Is_deleted = 0 
                   INNER JOIN TCD.washergroup WG 
                           ON WG.Washergroupid = TPS.Washergroupid 
                              AND TPS.Is_deleted = 0 
                   LEFT JOIN TCD.injection IJ 
                           ON WG.Washergroupnumber = IJ.Washergroupnumber 
                              AND IJ.Is_deleted = 0 
                   LEFT JOIN TCD.conduitcontroller CC 
                           ON IJ.ControllerId = WG.ControllerId
                              AND CC.Isdeleted = 0 
                              --AND CC.Active = 1 
                   LEFT JOIN TCD.controllertype CT 
                           ON CC.Controllertypeid = CT.Id 
                   INNER JOIN TCD.programmaster PRGM 
                           ON PRGM.Programid = TPS.Programid 
                   LEFT JOIN TCD.[tunneltempsetup] TTS 
                                ON TPS.Tunnelprogramsetupid = TTS.Tunnelprogramsetupid AND TTS.CompartmentNumber = TDS.CompartmentNumber
                   INNER JOIN TCD.tunneldosingproductmapping TDP 
                          ON TDS.Tunneldosingsetupid = TDP.Tunneldosingsetupid
				   INNER JOIN TCD.controllerequipmentsetup CES 
					        ON CES.ControllerEquipmentSetupId  = TDP.ControllerEquipmentSetupId
					           AND CES.Isactive = 1 
							   LEFT JOIN TCD.productmaster PM 
					       ON PM.Productid = CES.Productid 
					          AND pm.Is_deleted = 0 
					LEFT JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM
					     ON TCEVM.ControllerEquipmentSetupID = CES.ControllerEquipmentSetupId
							AND TCEVM.TunnelNumber = WG.WasherDosingNumber
							AND ((TCEVM.DosingPointNumber = 0) OR (TCEVM.compartmentnumber = TDS.compartmentnumber AND TCEVM.DosingPointNumber <> 0))
					LEFT JOIN [TCD].washstep WS 
					       ON WS.Stepid = TDS.Steptypeid 
					          AND WS.Isactive = 1 
            WHERE  WG.Washergroupid = @WasherGroupId 
                   AND TPS.Tunnelprogramsetupid = @WasherProgramSetupId 
                   AND WG.Ecolabaccountnumber = @EcolabAccountNumber
                   AND TCEVM.DosingPointNumber IS NOT NULL				   
        END 
  END 
GO
----------------------------------------------------------------------------------------------------------------------
IF EXISTS( SELECT *
			 FROM sys.objects
			 WHERE object_id = OBJECT_ID( N'[TCD].[GetUsedChemicalName]' )
				AND type IN( N'P' , N'PC' )
		 )
	BEGIN
		DROP PROCEDURE TCD.GetUsedChemicalName;
	END;
GO
CREATE PROCEDURE [TCD].[GetUsedChemicalName]
    @ChemName Varchar(1000)
    ,@EcolabAccountNumber VARCHAR(100)
    ,@WasherGroupId    INT = NULL
AS     

BEGIN     
    SET NOCOUNT ON    
    
    DECLARE @RegionId            INT =    NULL
        ,    @ControllerId        INT    =    NULL
        ,    @ControllerModelId    INT    =    NULL
        ,    @ControllerTypeId    INT    =    NULL
		,	 @ControllerEquipmentId TINYINT = NULL
		,	 @ControllerEquipmentSetupId SMALLINT = NULL
    
    SELECT 
    @RegionId = RegionID FROM Plant 
    WHERE 
    EcolabAccountNumber = @EcolabAccountNumber

    SELECT @ControllerId =  wg.ControllerId FROM TCD.WasherGroup wg WHERE wg.WasherGroupId = @WasherGroupId AND wg.EcolabAccountNumber = @EcolabAccountNumber

    IF @ControllerId IS NULL OR @Controllerid = 0
    BEGIN
    IF @WasherGroupId IS NULL
    BEGIN
        SELECT
		@ControllerEquipmentId,
		@ControllerEquipmentSetupId, 
        Map.ProductId, RTRIM(ISNULL(NULLIF(M.EnvisionDisplayName, ' '), M.Name)) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name
        , M.Cost
        , M.IncludeinCI
        , TCD.FnChemicalCostInOunce(Map.ProductId) AS        Price
    , 0
        FROM ProductMaster M
        INNER JOIN ProductdataMapping Map ON M.ProductId = Map.ProductId AND Map.Is_Deleted=0
        WHERE 
        (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
        AND M.RegionId = @RegionId
        AND M.Is_Deleted =0
    END
    ELSE
    BEGIN
        SELECT DISTINCT
		@ControllerEquipmentId,
		@ControllerEquipmentSetupId,
        Map.ProductId, RTRIM(ISNULL(NULLIF(M.EnvisionDisplayName, ' '), M.Name)) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name
        , M.Cost
        , M.IncludeinCI
        , TCD.FnChemicalCostInOunce(Map.ProductId) AS        Price
    , 0
        FROM TCD.ProductMaster M
        INNER JOIN TCD.ProductdataMapping Map ON M.ProductId = Map.ProductId AND Map.Is_Deleted=0
        LEFT JOIN TCD.ControllerEquipmentSetup ces ON ces.ProductId = Map.ProductId AND ces.EcoLabAccountNumber = Map.EcolabAccountNumber
        INNER JOIN TCD.MachineSetup ms ON ms.ControllerId = ces.ControllerId AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber AND ms.IsDeleted = 'False'
        INNER JOIN TCD.WasherGroup wg ON wg.WasherGroupId = ms.GroupId AND wg.EcolabAccountNumber = ms.EcoalabAccountNumber
        WHERE wg.WasherGroupId = ISNULL(@WasherGroupId, wg.WasherGroupId)
        AND (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
        AND M.RegionId = @RegionId
        AND M.Is_Deleted =0
        END
     END
    ELSE
    BEGIN
        SELECT @ControllerModelId = cc.ControllerModelId, @ControllerTypeId = cc.ControllerTypeId FROM TCD.ConduitController cc WHERE cc.ControllerId = @ControllerId

        IF @ControllerModelId = 11
        BEGIN
            SELECT 
			ces.ControllerEquipmentId,
		    ces.ControllerEquipmentSetupId,
            Map.ProductId, 
			RTRIM(ISNULL(NULLIF(M.EnvisionDisplayName, ' '), M.Name)) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name
            , M.Cost
            , M.IncludeinCI
            , CAST (ces.ControllerEquipmentTypeId AS int) AS ControllerEquipmentTypeId
            FROM ProductMaster M
            INNER JOIN ProductdataMapping Map ON M.ProductId = Map.ProductId AND Map.Is_Deleted=0  
            INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.EcoLabAccountNumber = Map.EcolabAccountNumber AND ces.ProductId = Map.ProductID
            LEFT JOIN TCD.TunnelCompartmentEquipmentValveMapping tcevm ON ces.ControllerEquipmentSetupID = tcevm.ControllerEquipmentSetupID AND tcevm.DirectDosingFlag = 1
            WHERE 
            (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
            AND tcevm.ControllerEquipmentSetupID IS NULL
            AND M.RegionId = @RegionId
            AND M.Is_Deleted =0
            AND ces.ControllerId = @ControllerId
            AND ces.WasherGroupNumber =  CASE WHEN @ControllerTypeId = 13 THEN 1 ELSE ces.WasherGroupNumber END
    END
        ELSE
        BEGIN
            SELECT 
			CASE ces.ControllerEquipmentTypeId WHEN 2 THEN 
											   CASE @ControllerModelId WHEN 7 THEN CAST(ces.ControllerEquipmentId-24 AS tinyint) 
											   ELSE ces.ControllerEquipmentId END 
											   ELSE ces.ControllerEquipmentId END,
		    ces.ControllerEquipmentSetupId,
            Map.ProductId, 
			RTRIM(ISNULL(NULLIF(M.EnvisionDisplayName, ' '), M.Name)) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name
    , M.Cost
    , M.IncludeinCI
    , TCD.FnChemicalCostInOunce(Map.ProductId) AS        Price
            , CAST (ces.ControllerEquipmentTypeId AS int) AS ControllerEquipmentTypeId
    FROM ProductMaster M
    INNER JOIN ProductdataMapping Map ON M.ProductId = Map.ProductId AND Map.Is_Deleted=0     
            INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.EcoLabAccountNumber = Map.EcolabAccountNumber AND ces.ProductId = Map.ProductID 
		  AND CASE WHEN @ControllerModelId = 7 THEN ces.ConventionalWasherGroupConnection ELSE ISNULL(ces.ConventionalWasherGroupConnection, 0) END = CASE WHEN @ControllerModelId = 7 THEN 1 ELSE 0 END
            LEFT JOIN TCD.TunnelCompartmentEquipmentValveMapping tcevm ON ces.ControllerEquipmentSetupID = tcevm.ControllerEquipmentSetupID AND tcevm.DirectDosingFlag = 1
    WHERE 
    (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
            AND tcevm.ControllerEquipmentSetupID IS NULL
    AND M.RegionId = @RegionId
    AND M.Is_Deleted =0
            AND ces.ControllerId = @ControllerId
        END
    END
        

    SET NOCOUNT OFF 
 
END
GO
--------------------------------------------------------------------------------------------------------------------------
IF EXISTS( SELECT *
			 FROM sys.objects
			 WHERE object_id = OBJECT_ID( N'[TCD].[GetWasherDosingProductMapping]' )
				AND type IN( N'P' , N'PC' )
		 )
	BEGIN
		DROP PROCEDURE TCD.GetWasherDosingProductMapping;
	END;
GO
CREATE	PROCEDURE	[TCD].[GetWasherDosingProductMapping]	(
                @EcoLabAccountNumber					NVARCHAR(25)
              ,	@WasherDosingSetupId					INT
			  ,	@Is_Deleted								BIT			=		'FALSE'
)
AS
BEGIN

SET	NOCOUNT	ON

SELECT		WDPM.WasherDosingProductMappingId		AS			WasherDosingProductMappingId
		,	WDPM.WasherDosingSetupId				AS			WasherDosingSetupId		
        ,	WDPM.InjectionNumber					AS			InjectionNUmber
        ,	WDPM.ProductId							AS			ProductId
        ,	ISNULL(NULLIF(PM.EnvisionDisplayName, ' '),PM.Name) 	AS ProductName
        ,	WDPM.Quantity							AS			Quantity
        ,	WDPM.MyServiceFrmulaStpDsgDvcGuid		AS			MyServiceFrmulaStpDsgDvcGuid
		,	WDPM.MyServiceLastSynchTime				AS			MyServiceLastSynchTime
		,	WDPM.IsDeleted							AS			IsDeleted
		,	WDPM.[Delay]							AS			[Delay]
		,	WDPM.ControllerEquipmentSetupId			AS			ControllerEquipmentSetupId
		,	CASE ces.ControllerEquipmentTypeId WHEN 2 THEN 
											   CASE cc.ControllerModelId WHEN 7 THEN 
											   CAST(ces.ControllerEquipmentId-24 AS tinyint) ELSE ces.ControllerEquipmentId END 
											   ELSE ces.ControllerEquipmentId END
FROM [TCD].WasherDosingProductMapping               WDPM  
JOIN [TCD].ProductMaster                          PM  
ON       WDPM.ProductId      =   PM.ProductId  
LEFT JOIN TCD.ControllerEquipmentSetup ces 
ON ces.ControllerEquipmentSetupId = WDPM.ControllerEquipmentSetupId AND ces.EcoLabAccountNumber = WDPM.EcoLabAccountNumber AND ces.ProductId = PM.ProductId
INNER JOIN TCD.ConduitController cc ON cc.EcoalabAccountNumber = ces.EcoLabAccountNumber AND cc.ControllerId = ces.ControllerId
WHERE   (WDPM.IsDeleted      =   'False' OR WDPM.IsDeleted = @Is_Deleted)  
AND       WDPM.EcoLabAccountNumber   =   @EcoLabAccountNumber  
AND       WDPM.WasherDosingSetupId   =   @WasherDosingSetupId 
SET	NOCOUNT	OFF

END
GO
---------------------------------------------------------------------------------------------------------------------------------
IF EXISTS( SELECT *
			 FROM sys.objects
			 WHERE object_id = OBJECT_ID( N'[TCD].[GetTunnelWashStepProducts]' )
				AND type IN( N'P' , N'PC' )
		 )
	BEGIN
		DROP PROCEDURE TCD.GetTunnelWashStepProducts;
	END;
GO
CREATE PROCEDURE [TCD].[GetTunnelWashStepProducts]

     @EcoLabAccountNumber     NVARCHAR(1000)

    , @CompartmentNumber       INT

    , @GroupId         INT

    , @DosingSetupId        INT

AS

BEGIN

SET NOCOUNT ON
DECLARE @TunnelProgramSetupId INT
,  @LastModifiedTime DATETIME  = NULL
,  @MyServiceFrmulaStpDsgDvcGuid UNIQUEIDENTIFIER = NULL
,  @RegionId INT
,  @PlantId INT 
,  @ControllerModelId INT
,  @ControllerId INT
,  @TunnelId INT
,  @ControllerEquipmentId TINYINT = NULL
SELECT @RegionId = RegionId, @PlantId = PlantId FROM TCD.Plant WHERE EcolabAccountNumber = @EcoLabAccountNumber

SELECT @TunnelId = ms.WasherId FROM TCD.MachineSetup ms Where ms.GroupId = @GroupId AND ms.EcoalabAccountNumber = @EcoLabAccountNumber AND ms.IsTunnel = 1 AND ms.IsDeleted = 0

SELECT @TunnelProgramSetupId = tds.TunnelProgramSetupId FROM TCD.TunnelDosingSetup tds WHERE tds.TunnelDosingSetupId = @DosingSetupId AND tds.EcolabAccountNumber = @EcoLabAccountNumber

 SELECT @ControllerId = ISNULL(WG.ControllerId, - 1)
 FROM [TCD].WasherGroup WG
 WHERE WG.EcolabAccountNumber = @EcoLabAccountNumber
 AND WG.WasherGroupId = @GroupId

SELECT @ControllerModelId = cc.ControllerModelId from tcd.ConduitController cc WHERE cc.ControllerId = @ControllerId AND cc.EcoalabAccountNumber = @EcoLabAccountNumber

IF (@ControllerModelId < 7  OR @ControllerModelId IN (12, 13))
BEGIN
	IF NOT EXISTS (SELECT 1 FROM TCD.TunnelDosingProductMapping tdpm WHERE tdpm.TunnelDosingSetupId = @DosingSetupId AND tdpm.EcoLabAccountNumber = @EcoLabAccountNumber)
	 BEGIN
	  SELECT 
	  0           AS  TunnelDosingProductMappingId,
	  TC.EcoLabAccountNumber      AS  EcoalabAccountNumber, 
	  CES.ControllerEquipmentSetupId    AS  ControllerEquipmentSetupId, 
	  PM.ProductId        AS  ProductId, 
	  ISNULL(NULLIF(PM.EnvisionDisplayName, ' '),PM.Name)  AS ProductName,
	  0.0           AS  Quantity,
	  0           AS  DelayTime,  
	  CAST(TC.[CompartmentNumber] AS INT)   AS  CompartmentNumber, 
	  MS.GroupId         AS  GroupId,
	  @LastModifiedTime       AS  LastModifiedTime,
	  @MyServiceFrmulaStpDsgDvcGuid    AS  MyServiceFrmulaStpDsgDvcGuid,
	  TCD.FnChemicalCostInOunce(PM.ProductId)  AS  Price,
	  GETUTCDATE()        AS  MyServiceLastSynchTime,
	  CAST(CES.ControllerEquipmentTypeId AS INT)    AS  ControllerEquipmentSetupTypeId,
	  @ControllerEquipmentId
	FROM TCD.TunnelCompartment TC 
	JOIN TCD.MachineSetup MS ON TC.WasherId = MS.WasherId AND TC.EcoLabAccountNumber = MS.EcoalabAccountNumber AND ms.IsDeleted = 'False' 
	JOIN TCD.TunnelCompartmentEquipmentMapping TCE ON TCE.TunnelCompartmentId = TC.TunnelCompartmentId AND TCE.EcoLabAccountNumber = TC.EcoLabAccountNumber AND TCE.Is_Deleted = 'False'
	JOIN TCD.ControllerEquipmentSetup CES on CES.ControllerEquipmentSetupId = TCE.ControllerEquipmentSetupId AND CES.EcoLabAccountNumber = TCE.EcoLabAccountNumber
	JOIN TCD.ProductMaster PM on PM.ProductId = CES.ProductId 
	JOIN TCD.TunnelProgramSetup TPS on TPS.WasherGroupId = MS.GroupId AND TPS.EcolabAccountNumber = MS.EcoalabAccountNumber
	 WHERE TC.CompartmentNumber = @CompartmentNumber AND MS.GroupId = @GroupId 
	 AND MS.EcoalabAccountNumber = @EcoLabAccountNumber 
	 AND TPS.TunnelProgramSetupId = @TunnelProgramSetupId
	END
	ELSE
	BEGIN
	SELECT 
	  ISNULL(TDPM.TunnelDosingProductMappingId,0)   AS  TunnelDosingProductMappingId,
	  TC.EcoLabAccountNumber      AS  EcoalabAccountNumber, 
	  CES.ControllerEquipmentSetupId    AS  ControllerEquipmentSetupId, 
	  PM.ProductId        AS  ProductId, 
	  ISNULL(NULLIF(PM.EnvisionDisplayName, ' '),PM.Name)  AS ProductName,
	  ISNULL(TDPM.Quantity,0.0) AS Quantity,
	  ISNULL(TDPM.DelayTime,0) AS DelayTime,   
	  CAST(TC.[CompartmentNumber] AS INT)   AS  CompartmentNumber, 
	  MS.GroupId         AS  GroupId,
	  TDPM.LastModifiedTime      AS  LastModifiedTime,
	  TDPM.MyServiceFrmulaStpDsgDvcGuid   AS  MyServiceFrmulaStpDsgDvcGuid,
	  TCD.FnChemicalCostInOunce(PM.ProductId)  AS  Price,
	  TDPM.MyServiceLastSynchTime     AS  MyServiceLastSynchTime,
	  CAST(CES.ControllerEquipmentTypeId AS INT)     AS  ControllerEquipmentSetupTypeId,
	  @ControllerEquipmentId
	FROM TCD.TunnelCompartment TC 
	JOIN TCD.MachineSetup MS ON TC.WasherId = MS.WasherId AND TC.EcoLabAccountNumber = MS.EcoalabAccountNumber AND ms.IsDeleted = 'False' 
	JOIN TCD.TunnelCompartmentEquipmentMapping TCE ON TCE.TunnelCompartmentId = TC.TunnelCompartmentId AND TCE.EcoLabAccountNumber = TC.EcoLabAccountNumber AND TCE.Is_Deleted = 'False'
	JOIN TCD.ControllerEquipmentSetup CES ON CES.ControllerEquipmentSetupId = TCE.ControllerEquipmentSetupId AND CES.EcoLabAccountNumber = TCE.EcoLabAccountNumber
	JOIN TCD.ProductMaster PM ON PM.ProductId = CES.ProductId 
	JOIN TCD.TunnelProgramSetup TPS ON TPS.WasherGroupId = MS.GroupId AND TPS.EcolabAccountNumber = MS.EcoalabAccountNumber
	JOIN TCD.TunnelDosingSetup TDS ON tds.EcolabAccountNumber = TPS.EcolabAccountNumber 
		   AND TDS.TunnelProgramSetupId = TPS.TunnelProgramSetupId AND TDS.CompartmentNumber = TC.CompartmentNumber
	LEFT JOIN TCD.TunnelDosingProductMapping TDPM ON TDPM.CompartmentNumber = TC.CompartmentNumber AND TDPM.EcoLabAccountNumber = TDS.EcoLabAccountNumber
		   AND TDPM.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId AND TDPM.TunnelDosingSetupId = TDS.TunnelDosingSetupId
	 WHERE TC.CompartmentNumber = @CompartmentNumber AND MS.GroupId = @GroupId AND TDS.TunnelDosingSetupId = @DosingSetupId 
	 AND MS.EcoalabAccountNumber = @EcoLabAccountNumber 
	 AND TPS.TunnelProgramSetupId = @TunnelProgramSetupId
	END 
END
ELSE
BEGIN
	IF EXISTS (SELECT 1 FROM TCD.TunnelCompartment tc WHERE tc.WasherId = @TunnelId AND tc.CompartmentNumber = @CompartmentNumber AND tc.EcoLabAccountNumber = @EcoLabAccountNumber)
	BEGIN
	IF NOT EXISTS (SELECT 1 FROM TCD.TunnelDosingProductMapping tdpm WHERE tdpm.TunnelDosingSetupId = @DosingSetupId AND tdpm.EcoLabAccountNumber = @EcoLabAccountNumber)
	 BEGIN
	  SELECT 
	  0           AS  TunnelDosingProductMappingId,
	  TC.EcoLabAccountNumber      AS  EcoalabAccountNumber, 
	  CES.ControllerEquipmentSetupId    AS  ControllerEquipmentSetupId, 
	  PM.ProductId        AS  ProductId, 
	  ISNULL(NULLIF(pm2.EnvisionDisplayName, ' '),pm2.Name)  AS ProductName,
	  0.0           AS  Quantity,
	  0           AS  DelayTime,  
	  CAST(TC.[CompartmentNumber] AS INT)   AS  CompartmentNumber, 
	  MS.GroupId         AS  GroupId,
	  @LastModifiedTime       AS  LastModifiedTime,
	  @MyServiceFrmulaStpDsgDvcGuid    AS  MyServiceFrmulaStpDsgDvcGuid,
	  TCD.FnChemicalCostInOunce(PM.ProductId)  AS  Price,
	  GETUTCDATE()        AS  MyServiceLastSynchTime,
	  CAST(CES.ControllerEquipmentTypeId AS INT)    AS  ControllerEquipmentSetupTypeId,
	   CES.ControllerEquipmentId
	FROM TCD.TunnelCompartmentEquipmentValveMapping tcevm
    INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.ControllerEquipmentSetupId = tcevm.ControllerEquipmentSetupId 
    AND tcevm.PlantID = @PlantId
	INNER JOIN TCD.TunnelCompartment TC ON  tc.CompartmentNumber = tcevm.CompartmentNumber AND tc.EcoLabAccountNumber = ces.EcoLabAccountNumber
	LEFT JOIN TCD.TunnelCompartmentEquipmentMapping tcem ON tcevm.ControllerEquipmentSetupID = tcem.ControllerEquipmentSetupId
    AND tc.TunnelCompartmentId = tcem.TunnelCompartmentId AND tcem.Is_Deleted = 'False'
    AND tcem.EcoLabAccountNumber = tc.EcoLabAccountNumber AND tcem.EcoLabAccountNumber = ces.EcoLabAccountNumber
	INNER JOIN TCD.MachineSetup ms ON ms.WasherId = tc.WasherId AND ms.ControllerId = ces.ControllerId AND ms.EcoalabAccountNumber = tc.EcoLabAccountNumber
    AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber AND ms.MachineInternalId = tcevm.TunnelNumber AND MS.IsTunnel = 'TRUE' AND MS.IsDeleted = 'FALSE'
	INNER JOIN TCD.ProductdataMapping pm ON pm.EcolabAccountNumber = ces.EcoLabAccountNumber AND pm.ProductID = ces.ProductId 
    INNER JOIN TCD.ProductMaster pm2 ON pm2.ProductId = pm.ProductID
	INNER JOIN TCD.TunnelProgramSetup TPS on TPS.WasherGroupId = MS.GroupId AND TPS.EcolabAccountNumber = MS.EcoalabAccountNumber
	 WHERE TC.CompartmentNumber = @CompartmentNumber AND MS.GroupId = @GroupId 
	 AND MS.EcoalabAccountNumber = @EcoLabAccountNumber 
	 AND TPS.TunnelProgramSetupId = @TunnelProgramSetupId
	END
	ELSE
	BEGIN
	SELECT 
	  ISNULL(TDPM.TunnelDosingProductMappingId,0)   AS  TunnelDosingProductMappingId,
	  TC.EcoLabAccountNumber      AS  EcoalabAccountNumber, 
	  CES.ControllerEquipmentSetupId    AS  ControllerEquipmentSetupId, 
	  PM.ProductId        AS  ProductId, 
	  ISNULL(NULLIF(pm2.EnvisionDisplayName, ' '),pm2.Name)  AS ProductName,
	  ISNULL(TDPM.Quantity,0.0) AS Quantity,
	  ISNULL(TDPM.DelayTime,0) AS DelayTime,   
	  CAST(TC.[CompartmentNumber] AS INT)   AS  CompartmentNumber, 
	  MS.GroupId         AS  GroupId,
	  TDPM.LastModifiedTime      AS  LastModifiedTime,
	  TDPM.MyServiceFrmulaStpDsgDvcGuid   AS  MyServiceFrmulaStpDsgDvcGuid,
	  TCD.FnChemicalCostInOunce(PM.ProductId)  AS  Price,
	  TDPM.MyServiceLastSynchTime     AS  MyServiceLastSynchTime,
	  CAST(CES.ControllerEquipmentTypeId AS INT)     AS  ControllerEquipmentSetupTypeId,
	   CES.ControllerEquipmentId
	FROM TCD.TunnelCompartmentEquipmentValveMapping tcevm
    INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.ControllerEquipmentSetupId = tcevm.ControllerEquipmentSetupId 
    AND tcevm.PlantID = @PlantId
	INNER JOIN TCD.TunnelCompartment TC ON  tc.CompartmentNumber = tcevm.CompartmentNumber AND tc.EcoLabAccountNumber = ces.EcoLabAccountNumber
	LEFT JOIN TCD.TunnelCompartmentEquipmentMapping tcem ON tcevm.ControllerEquipmentSetupID = tcem.ControllerEquipmentSetupId
    AND tc.TunnelCompartmentId = tcem.TunnelCompartmentId AND tcem.Is_Deleted = 'False'
    AND tcem.EcoLabAccountNumber = tc.EcoLabAccountNumber AND tcem.EcoLabAccountNumber = ces.EcoLabAccountNumber
	INNER JOIN TCD.MachineSetup ms ON ms.WasherId = tc.WasherId AND ms.ControllerId = ces.ControllerId AND ms.EcoalabAccountNumber = tc.EcoLabAccountNumber
    AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber AND ms.MachineInternalId = tcevm.TunnelNumber AND MS.IsTunnel = 'TRUE' AND MS.IsDeleted = 'FALSE'
	INNER JOIN TCD.ProductdataMapping pm ON pm.EcolabAccountNumber = ces.EcoLabAccountNumber AND pm.ProductID = ces.ProductId 
    INNER JOIN TCD.ProductMaster pm2 ON pm2.ProductId = pm.ProductID
	INNER JOIN TCD.TunnelProgramSetup TPS on TPS.WasherGroupId = MS.GroupId AND TPS.EcolabAccountNumber = MS.EcoalabAccountNumber
	JOIN TCD.TunnelDosingSetup TDS ON tds.EcolabAccountNumber = TPS.EcolabAccountNumber 
		   AND TDS.TunnelProgramSetupId = TPS.TunnelProgramSetupId AND TDS.CompartmentNumber = TC.CompartmentNumber
	LEFT JOIN TCD.TunnelDosingProductMapping TDPM ON TDPM.CompartmentNumber = TC.CompartmentNumber AND TDPM.EcoLabAccountNumber = TDS.EcoLabAccountNumber
		   AND TDPM.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId AND TDPM.TunnelDosingSetupId = TDS.TunnelDosingSetupId
	 WHERE TC.CompartmentNumber = @CompartmentNumber AND MS.GroupId = @GroupId AND TDS.TunnelDosingSetupId = @DosingSetupId 
	 AND MS.EcoalabAccountNumber = @EcoLabAccountNumber 
	 AND TPS.TunnelProgramSetupId = @TunnelProgramSetupId
	END 
	END
	ELSE
	BEGIN
	IF NOT EXISTS (SELECT 1 FROM TCD.TunnelDosingProductMapping tdpm WHERE tdpm.TunnelDosingSetupId = @DosingSetupId AND tdpm.EcoLabAccountNumber = @EcoLabAccountNumber)
	 BEGIN
	 SELECT 
	  0           AS  TunnelDosingProductMappingId,
	  @EcoLabAccountNumber      AS  EcoalabAccountNumber, 
	  CES.ControllerEquipmentSetupId    AS  ControllerEquipmentSetupId, 
	  PM.ProductId        AS  ProductId, 
	  ISNULL(NULLIF(pm2.EnvisionDisplayName, ' '),pm2.Name)  AS ProductName,
	  0.0           AS  Quantity,
	  0           AS  DelayTime,  
	  CAST(tcevm.CompartmentNumber AS INT)   AS  CompartmentNumber, 
	  MS.GroupId         AS  GroupId,
	  @LastModifiedTime       AS  LastModifiedTime,
	  @MyServiceFrmulaStpDsgDvcGuid    AS  MyServiceFrmulaStpDsgDvcGuid,
	  TCD.FnChemicalCostInOunce(PM.ProductId)  AS  Price,
	  GETUTCDATE()        AS  MyServiceLastSynchTime,
	  CAST(CES.ControllerEquipmentTypeId AS INT)    AS  ControllerEquipmentSetupTypeId ,
	   CES.ControllerEquipmentId
 FROM TCD.TunnelCompartmentEquipmentValveMapping tcevm
 INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.ControllerEquipmentSetupId = tcevm.ControllerEquipmentSetupID
 INNER JOIN TCD.MachineSetup ms ON ms.ControllerId = ces.ControllerId AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber AND ms.MachineInternalId = tcevm.TunnelNumber
 INNER JOIN TCD.ProductdataMapping pm ON pm.EcolabAccountNumber = ces.EcoLabAccountNumber AND pm.ProductID = ces.ProductId
 INNER JOIN TCD.ProductMaster pm2 ON pm2.ProductId = pm.ProductId
 WHERE (PM.Is_Deleted = 'FALSE' OR PM.Is_Deleted = 0)
 AND tcevm.CompartmentNumber = @CompartmentNumber
    AND tcevm.PlantID = @PlantId
 AND ms.WasherId = @TunnelId  AND ms.EcoalabAccountNumber =  @EcoLabAccountNumber
    AND MS.IsTunnel = 'TRUE' AND (MS.IsDeleted = 'FALSE' OR MS.IsDeleted = 0) 
	END
	ELSE
	BEGIN
		SELECT 
	  ISNULL(TDPM.TunnelDosingProductMappingId,0)   AS  TunnelDosingProductMappingId,
	  @EcoLabAccountNumber      AS  EcoalabAccountNumber, 
	  CES.ControllerEquipmentSetupId    AS  ControllerEquipmentSetupId, 
	  PM.ProductId        AS  ProductId, 
	  ISNULL(NULLIF(pm2.EnvisionDisplayName, ' '),pm2.Name)  AS ProductName,
	  ISNULL(TDPM.Quantity,0.0) AS Quantity,
	  ISNULL(TDPM.DelayTime,0) AS DelayTime,   
	  CAST(tcevm.[CompartmentNumber] AS INT)   AS  CompartmentNumber, 
	  MS.GroupId         AS  GroupId,
	  TDPM.LastModifiedTime      AS  LastModifiedTime,
	  TDPM.MyServiceFrmulaStpDsgDvcGuid   AS  MyServiceFrmulaStpDsgDvcGuid,
	  TCD.FnChemicalCostInOunce(PM.ProductId)  AS  Price,
	  TDPM.MyServiceLastSynchTime     AS  MyServiceLastSynchTime,
	  CAST(CES.ControllerEquipmentTypeId AS INT)     AS  ControllerEquipmentSetupTypeId,
	   CES.ControllerEquipmentId
	FROM TCD.TunnelCompartmentEquipmentValveMapping tcevm
    INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.ControllerEquipmentSetupId = tcevm.ControllerEquipmentSetupId 
    AND tcevm.PlantID = @PlantId
	INNER JOIN TCD.MachineSetup ms ON ms.ControllerId = ces.ControllerId AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber AND ms.MachineInternalId = tcevm.TunnelNumber
    AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber AND ms.MachineInternalId = tcevm.TunnelNumber AND MS.IsTunnel = 'TRUE' AND MS.IsDeleted = 'FALSE'
	INNER JOIN TCD.ProductdataMapping pm ON pm.EcolabAccountNumber = ces.EcoLabAccountNumber AND pm.ProductID = ces.ProductId 
    INNER JOIN TCD.ProductMaster pm2 ON pm2.ProductId = pm.ProductID
	INNER JOIN TCD.TunnelProgramSetup TPS on TPS.WasherGroupId = MS.GroupId AND TPS.EcolabAccountNumber = MS.EcoalabAccountNumber
	JOIN TCD.TunnelDosingSetup TDS ON tds.EcolabAccountNumber = TPS.EcolabAccountNumber 
		   AND TDS.TunnelProgramSetupId = TPS.TunnelProgramSetupId AND TDS.CompartmentNumber = tcevm.CompartmentNumber
	LEFT JOIN TCD.TunnelDosingProductMapping TDPM ON TDPM.CompartmentNumber = tcevm.CompartmentNumber AND TDPM.EcoLabAccountNumber = TDS.EcoLabAccountNumber
		   AND TDPM.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId AND TDPM.TunnelDosingSetupId = TDS.TunnelDosingSetupId
	 WHERE tcevm.CompartmentNumber = @CompartmentNumber AND MS.GroupId = @GroupId AND TDS.TunnelDosingSetupId = @DosingSetupId 
	 AND MS.EcoalabAccountNumber = @EcoLabAccountNumber 
	 AND TPS.TunnelProgramSetupId = @TunnelProgramSetupId
	END
	END
END 

 
SET NOCOUNT OFF

END
GO
-----------------------------------------------------------------start My Control Tunnel online and production sp changes-----------------------------------
 IF EXISTS
(
    SELECT
		 *
    FROM sys.objects
    WHERE object_id = OBJECT_ID(
    N'[TCD].[ProcessMyControlTunnelWasherProdData]')
		AND type IN(N'P', N'PC')
)
    BEGIN
	   DROP PROCEDURE
		   [TCD].[ProcessMyControlTunnelWasherProdData];
    END;
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE PROCEDURE [TCD].[ProcessMyControlTunnelWasherProdData](
	@ControllerID   INT,
	@xmlTags        XML,
	@PLCPointer     INT,
	@ReadPointer    INT,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @BatchID                   INT,
			  @WasherID                  INT,
			  @EcolabWasherId            INT,
			  @CurrencyCode              VARCHAR(50),
			  @MachineInternalId         INT,
			  @WasherGroupID             INT,
			  @PlantWasherNumber         INT,
			  @ProgramNumber             INT,
			  @Load                      DECIMAL(10, 2),
			  @NominalLoad               DECIMAL(10, 2),
			  @CustomerNumber            INT,
			  @PHStatus                  INT,
			  @PHValue                   INT,
			  @LFStatus                  INT,
			  @LFValue                   INT,
			  @BatchNumber               INT,
			  @TargetTurnTime            INT,
			  @PartitionOn               DATETIME2,
			  @BatchStartTime            DATETIME2,
			  @BatchEndTime              DATETIME2,
			  @ProgramID                 INT,
			  @NumberOfCompartments      INT,
			  @ProductId                 INT,
			  @CompartmentNum            INT,
			  @EquipmentType             INT,
			  @MinTempParamID            INT,
			  @MaxTempParamID            INT,
			  @TempStatusParamID         INT,
			  @PHValueParamID            INT,
			  @PHStatusParamID           INT,
			  @ConductivityValueParamID  INT,
			  @ConductivityStatusParamID INT,
			  @StdInjectionSteps         INT,
			  @StdWashSteps              INT,
			  @ActualInjSteps            INT,
			  @EcolabTextileCategoryId   INT,
			  @ChainTextileCategoryId    INT,
			  @FormulaSegmentId          INT,
			  @EcolabSaturationId        INT,
			  @PlantProgramId            INT,
			  @PreviousShiftId		    INT,
			  @CurrentShiftId		    INT,
			  @CurrentStepComportmentNO  INT,
			  @CounterNO			    INT,
			  @MeterID			    INT,
                 @ActualQuantity		    DECIMAL(18,4),
			  @BatchStepCount		    INT,
			  @EcolabAccountNumber	    VARCHAR(100),
			  @AlarmGroupMasterId	    INT,
			  @StandardQuantity          DECIMAL(18, 4),
			  @Price                     DECIMAL(18, 4);

	    DECLARE @BatchShiftId INT;
	    DECLARE @ShiftStartDateTemp TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    DECLARE @TunnelXML XML;
	    SELECT @TunnelXML = T.c.query('.')
	    FROM @xmlTags.nodes('MyControlTunnel/TunnelData') T(c)
	    WHERE T.c.value('@CompartmentNumber', 'INT') = 0;

		
	    SELECT @MachineInternalID = T.c.value('@MachineNumber', 'int'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @BatchStartTime = T.c.value('@StartDateTime', 'DateTime'),
			 @BatchEndTime = T.c.value('@EndDateTime', 'DateTime'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@Nominalload', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'int'),
			 @PHStatus = T.c.value('@Phstatus', 'int'),
			 @PHValue = T.c.value('@Phvalue', 'INT'),
			 @LFStatus = T.c.value('@LFStatus', 'INT'),
			 @LFValue = T.c.value('@LFValue', 'INT')
	    FROM @xmlTags.nodes('MyControlTunnel/TunnelData') T(c);

		--Check for valid startdatetime
		IF(@BatchStartTime <='01/01/1900' OR @BatchStartTime > '06/06/2079')
		BEGIN
			return
		END

	    SELECT @EcolabWasherID = Ws.EcolabWasherId,
			 @WasherGroupID = Wg.WasherGroupId,
			 @PlantWasherNumber = PlantWasherNumber,
			 @WasherID = ws.WasherId,
			 @CurrencyCode = P.CurrencyCode,
			 @NumberOfCompartments = Mst.NumberofComp
	    FROM TCD.Washer Ws
		    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.
		    GroupId
		    INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId
		    = Wg.WasherGroupTypeId
		    INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId =
		    Mst.ControllerId
		    INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.
		    EcoLabAccountNumber
	    WHERE Ctrl.ControllerID = @ControllerID
			AND Mst.MachineInternalId = @MachineInternalID
			AND Mst.IsTunnel = 1 AND Mst.IsDeleted=0;
	    SELECT @EcolabWasherID;
	    SELECT @ProgramID = ProgramId,
			 @TargetTurnTime = (3600 / (tps.TotalRunTime /
			 @NumberOfCompartments))
	    FROM TCD.TunnelProgramSetup AS tps
	    WHERE tps.WasherGroupId = @WasherGroupID
			AND tps.is_deleted = 0
			AND ProgramNumber = @ProgramNumber;
	    DELETE FROM @ShiftStartDateTemp;
	    IF(@BatchEndTime IS NOT NULL)
		   BEGIN
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchEndTime
		   END;
	    ELSE
		   BEGIN
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchStartTime
		   END;
	    SELECT @BatchShiftId = ShiftID,
			 @PartitionOn = ShiftStartdate
	    FROM @ShiftStartDateTemp;


	    --Start Getting InjectionCount,StepCount And ProductCount
	    SELECT @StdInjectionSteps = COUNT(tdpm.TunnelDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT tds.TunnelDosingSetupId) -
			 COUNT(tdpm.TunnelDosingSetupId)
	    FROM tcd.TunnelDosingProductMapping tdpm
		    RIGHT JOIN tcd.TunnelDosingSetup tds ON tdpm.
		    TunnelDosingSetupId = tds.TunnelDosingSetupId
	    WHERE tds.GroupId = @WasherGroupID
			AND tds.ProgramNumber = @ProgramNumber;
	    --End Getting InjectionCount,StepCount And ProductCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramID
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT @EcolabTextileCategoryId = pcp. EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp. ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    SELECT @BatchID = NULL;
	    SELECT @BatchID = BatchID
	    FROM TCD.BatchData BD
	    WHERE BD.ControllerBatchId = @BatchNumber
			AND BD.StartDate = @BatchStartTime
			AND BD.MachineId = @WasherID;
	    --AND BD.MachineInternalID = @MachineInternalID
	    IF(@BatchID IS NULL)
		   BEGIN
		   --Start Rollup for previous completed shift
	   IF(CAST(@BatchStartTime as date) < CAST(GETUTCDATE() as date))
	   BEGIN
		  SELECT TOP 1 @PreviousShiftId=ShiftId FROM TCD.BatchData WHERE MachineId=@WasherId ORDER BY StartDate DESC	   
		  SELECT Top 1 @CurrentShiftId = ShiftId from @ShiftStartDateTemp
		  IF(@CurrentShiftId != @PreviousShiftId)
		  BEGIN
			 EXEC TCD.ProductionShiftDataRollup @PreviousShiftId, @RedFlagShiftId OUTPUT
			 IF(@RedFlagShiftId IS NULL)
			 BEGIN
				SET @RedFlagShiftId = @PreviousShiftId
			 END
		  END
	   END
	   --End Rollup for previous completed shift
			  INSERT INTO TCD.BatchData
			  (ControllerBatchId,
			   EcolabWasherId,
			   GroupId,
			   MachineInternalId,
			   PlantWasherNumber,
			   StartDate,
			   EndDate,
			   ProgramNumber,
			   ProgramMasterId,
			   MachineId,
			   ActualWeight,
			   StandardWeight,
			   CurrencyCode,
			   ShiftId,
			   PartitionOn,
			   TargetTurnTime,
			   StdInjectionSteps,
			   StdWashSteps,
			   EcolabTextileCategoryId,
			   ChainTextileCategoryId,
			   FormulaSegmentId,
			   EcolabSaturationId,
			   PlantProgramId,
			   EndDateFormula
			  )
				    SELECT @BatchNumber,
						 @EcolabWasherID,
						 @WasherGroupID,
						 @MachineInternalID,
						 @PlantWasherNumber,
						 @BatchStartTime,
						 @BatchEndTime,
						 @ProgramNumber,
						 @ProgramID,
						 @WasherID,
						 @Load,
						 @NominalLoad,
						 @CurrencyCode,
						 @BatchShiftId,
						 @PartitionOn,
						 @TargetTurnTime,
						 @StdInjectionSteps,
						 @StdWashSteps,
						 @EcolabTextileCategoryId,
						 @ChainTextileCategoryId,
						 @FormulaSegmentId,
						 @EcolabSaturationId,
						 @PlantProgramId,
						 @BatchEndTime;
			  SELECT @BatchID = SCOPE_IDENTITY();
			  IF(@StdWashSteps > 0
				OR @StdWashSteps <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchID,
							@EcolabWasherId,
							38,
							@StdWashSteps,
							@PartitionOn;
			  EXEC TCD.UPDATEBatchWashStepForTunnel
				  @TunnelXML,
				  @WasherID,
				  @BatchID,
				  @BatchStartTime,
				  @PartitionOn,
				  @EcolabWasherId,
				  @NumberOfCompartments;
		   END;
		ELSE 
		BEGIN
			IF(@BatchEndTime IS NOT NULL
			  AND @BatchEndTime != '01/01/1900')
			   BEGIN
				  UPDATE TCD.BatchData
					SET
					   EndDate = @BatchEndTime,
					   ShiftId = @BatchShiftId,
					   PartitionOn = @PartitionOn,
					   EndDateFormula=@BatchEndTime
				  WHERE BATCHID = @BatchID;
			   END;
		END

		      --If the received formula is not configured in enVision then create an alarm 
       IF(@ProgramID is NULL)
       BEGIN
       SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant;
       SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.AlarmGroupMsterVsControllerModelType AGMVCMT
       INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
       WHERE AGMVCMT.AlarmCode = 9000
        INSERT INTO [TCD].[AlarmData] 
           (EcoalabAccountNumber,
           AlarmCode,
           BatchId,
           controllerID,
           StartDate,
           GroupId,
           MachineInternalId,
           ProgramId,   
           IsActive,
           EndDate,
           MachineId,
           AlarmGroupMasterId)
           SELECT
            @ECOLABAccountNumber,
            9000,
            @BatchID,
            @ControllerId,
            @BatchStartTime,
            @WasherGroupID,
            @MachineInternalID,
            @ProgramNumber,
            0,
            @BatchStartTime,
            @WasherId,
            @AlarmGroupMasterId
       END


	    IF(@CustomerNumber IS NOT NULL)
		   BEGIN
			  IF NOT EXISTS
			  (
				 SELECT 1
				 FROM [TCD].[BatchCustomerData]
				 WHERE BatchID = @BatchID
			  )
				 BEGIN
					INSERT INTO [TCD].[BatchCustomerData]
					([BatchId],
					 CustomerID,
					 [Weight],
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @BatchID,
							    @CustomerNumber,
							    @Load,
							    @PartitionOn,
							    @EcolabWasherId;
				 END;
		   END;
	    CREATE TABLE #DosingDetails
	    (
		    Number          INT,
		    Quantity        DECIMAL(10, 6),
		    Point           INT,
		    IsMainEquioment INT
	    );
	    INSERT INTO #DosingDetails
	    (Number,
		Quantity,
		Point,
		IsMainEquioment
	    )
			 SELECT T.c.value('@Number', 'INT') AS Number, --PumpNumber
				   T.c.value('@Quantity', 'Decimal(10,6)') AS Quantity, --Dosing Quanity
				   T.c.value('@Point', 'INT') AS Point, --Dosing point
				   T.c.value('@IsMainEquioment', 'INT') AS
			 IsMainEquioment
			 FROM @xmlTags.nodes('MyControlTunnel/TunnelData/Dose') T(C)
	    ;
	
	    -- Fetching data from cursor
	    DECLARE @MYCURSOR CURSOR;
	    SET @MYCURSOR = CURSOR FAST_FORWARD
	    FOR SELECT Number,
				Quantity,
				Point,
				IsMainEquioment
		   FROM #DosingDetails;
	    DECLARE @Number          INT,
			  @Quantity        DECIMAL(10, 6),
			  @Point           INT,
			  @IsMainEquioment INT;
	    OPEN @MYCURSOR;
	    FETCH NEXT FROM @MYCURSOR INTO @Number,
								@Quantity,
								@Point,
								@IsMainEquioment;
	    WHILE @@FETCH_STATUS = 0
		   BEGIN
			  IF(@IsMainEquioment = 1)
				 BEGIN
					SET @EquipmentType = 2;
				 END;
			  ELSE
				 BEGIN
					SET @EquipmentType = 1;
				 END;
			  SELECT @ProductId = CES.ProductId,
				    @CompartmentNum = TCEVM.CompartmentNumber
			  FROM tcd.ControllerEquipmentSetup CES
				  INNER JOIN TCD.
				  TunnelCompartmentEquipmentValveMapping TCEVM ON CES.
				  ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
			  WHERE CES.ControllerId = @ControllerID
				   AND CES.ControllerEquipmentTypeId = @EquipmentType
				   AND --CES.IsActive=1 AND
				   --CES.WasherGroupNumber=@WasherGroupNum AND
				   TCEVM.DosingPointNumber = @Point
				   AND CES.ControllerEquipmentId = @Number;
				
			 SELECT DISTINCT
				    @StandardQuantity =((Wps.NominalLoad * Wdpm.Quantity) / 100),
				    @Price = (((Wps.NominalLoad * Wdpm.Quantity) / 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID))
			  FROM TCD.Washer WS
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =Mst.GroupId
				  INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
				  INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
				  INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
				  INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON
				  Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
				  INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId = Wdpm.ControllerEquipmentSetupId
				  INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId = Ces.ProductId
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wds.CompartmentNumber = @CompartmentNum
				   AND Wps.Is_Deleted = 0
				   AND Pdm.Is_Deleted = 0;
				
			  IF(@ProductId IS NOT NULL)
				 BEGIN
					INSERT INTO TCD.BatchProductData
					(
						  BatchId,
						  StepCompartment,
						  ActualQuantity,
						  StandardQuantity,
						  Price,
						  [TimeStamp],
						  PartitionOn,
						  EcolabWasherId,
						  ProductId
					)
					SELECT
						  @BatchID,
						  @CompartmentNum,
						  @Quantity,
						  isnull(@StandardQuantity,0),
						  isnull(@Price,0),
						  @BatchEndTime,
						  @PartitionOn,
						  @EcolabWasherID,
						  @ProductId;
				 END;
			  FETCH NEXT FROM @MYCURSOR INTO @Number,
									   @Quantity,
									   @Point,
									   @IsMainEquioment;
		   END;
	    CLOSE @MYCURSOR;
	    DEALLOCATE @MYCURSOR;
	    DROP TABLE #DosingDetails;
	    SELECT @ActualInjSteps = COUNT(DISTINCT StepCompartment)
	    FROM TCD.BatchProductData
	    WHERE BatchId = @BatchID;
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.BatchParameters
		   WHERE ParameterId = 37
			    AND batchid = @BatchID
			    AND @ActualInjSteps > 0
	    )
		   BEGIN
			  IF(@ActualInjSteps > 0
				OR @ActualInjSteps <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchId,
							@EcolabWasherId,
							37,
							@ActualInjSteps,
							@PartitionOn;
		   END;
	    ELSE
		   BEGIN
			  UPDATE TCD.BatchParameters
			    SET
				   ParameterValue = @ActualInjSteps
			  WHERE ParameterId = 37
				   AND batchid = @BatchID;
		   END;
	    SELECT @MinTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Mimum Temperature';
	    SELECT @MaxTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Maximum Temperature';
	    SELECT @TempStatusParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Temperature Status';
	    SELECT @PHValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH';
	    SELECT @PHStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH Status';
	    SELECT @ConductivityValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Conductivity';
	    SELECT @ConductivityStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'LF Status';
	    IF(@PHValue IS NOT NULL)
		   BEGIN
			  --pH Value
			  IF(@PHValue <> 0
				OR @PHValue <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @PHValueParamID,
					   @PHValue,
					   @PartitionOn
				 );

			  --pH Status
			  IF(@PHStatus <> 0
				OR @PHStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @PHStatusParamID,
					   @PHStatus,
					   @PartitionOn
				 );
		   END;
	    IF(@LFValue IS NOT NULL)
		   BEGIN
			  --Conductivity Value
			  IF(@LFValue <> 0
				OR @LFValue <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @ConductivityValueParamID,
					   @LFValue,
					   @PartitionOn
				 );

			  --Conductivity Status
			  IF(@LFStatus <> 0
				OR @LFStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @ConductivityStatusParamID,
					   @LFStatus,
					   @PartitionOn
				 );
		   END;
	    CREATE TABLE #TemperatureDetails
	    (
		    MinimumTemp DECIMAL(10, 2),
		    MaximumTemp DECIMAL(10, 2),
		    TempStatus  DECIMAL(10, 2)
	    );
	    INSERT INTO #TemperatureDetails
	    (MinimumTemp,
		MaximumTemp,
		TempStatus
	    )
			 SELECT T.c.value('@Minimum', 'Decimal(10,2)') AS
			 MinimumTemp,
				   T.c.value('@Maximum', 'Decimal(10,2)') AS
				   MaximumTemp,
				   T.c.value('@Status', 'Decimal(10,2)') AS TempStatus
			 FROM @xmlTags.nodes(
			 'MyControlTunnel/TunnelData/TemperatureData'
							) T(c);
	  
	    -- Fetching data from cursor
	    DECLARE @TEMPCURSOR CURSOR;
	    SET @TEMPCURSOR = CURSOR FAST_FORWARD
	    FOR SELECT MinimumTemp,
				MaximumTemp,
				TempStatus
		   FROM #TemperatureDetails;
	    DECLARE @MinimumTemp DECIMAL(10, 2),
			  @MaximumTemp DECIMAL(10, 2),
			  @TempStatus  DECIMAL(10, 2);
	    OPEN @TEMPCURSOR;
	    FETCH NEXT FROM @TEMPCURSOR INTO @MinimumTemp,
								  @MaximumTemp,
								  @TempStatus;
	    WHILE @@FETCH_STATUS = 0
		   BEGIN	
			  --Minimum Temperature
			  IF(@MinimumTemp <> 0
				OR @MinimumTemp <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @MinTempParamID,
					   @MinimumTemp,
					   @PartitionOn
				 );

			  --Maximum Temperature
			  IF(@MaximumTemp <> 0
				OR @MaximumTemp <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @MaxTempParamID,
					   @MaximumTemp,
					   @PartitionOn
				 );

			  --Temperature Status
			  IF(@TempStatus <> 0
				OR @TempStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @TempStatusParamID,
					   @TempStatus,
					   @PartitionOn
				 );
			  FETCH NEXT FROM @TEMPCURSOR INTO @MinimumTemp,
										@MaximumTemp,
										@TempStatus;
		   END;
	    CLOSE @TEMPCURSOR;
	    DEALLOCATE @TEMPCURSOR;
	    DROP TABLE #TemperatureDetails;
	    UPDATE TCD.BatchWashStepData
		 SET
			EndTime = DATEADD(ss,
						  (SELECT T.c.value('@Time', 'INT')
							 FROM @TunnelXML.nodes('TunnelData/CompartmentTime') T(c)
							 WHERE T.c.value('@CompartmentNo','INT') =
							 (
								SELECT
									  bwsd.StepCompartment
								FROM tcd.BatchWashStepData bwsd
								WHERE bwsd.BatchId = @BatchID
									 AND bwsd.EndTime IS NULL
							 )
						  ),
						  (
							 SELECT
								   bwsd.StartTime
							 FROM tcd.BatchWashStepData bwsd
							 WHERE bwsd.BatchId = @BatchID
								  AND bwsd.EndTime IS NULL
						  ))
	    WHERE
			BatchId = @BatchID
			AND EndTime IS NULL;
   
   --Start water consumption per batch


    CREATE TABLE #WaterConsumptionData
     (
      Number          INT,
      Quantity        DECIMAL(18,4),
     );
     INSERT INTO #WaterConsumptionData
     (Number,
  Quantity
     )
    SELECT T.c.value('@Counter', 'INT') AS Number, --PumpNumber
       T.c.value('@Value', 'DECIMAL(18,4)') AS Quantity --Water Quanity
    FROM @xmlTags.nodes('MyControlTunnel/TunnelData/WaterConsumption') T(C);

  
  SET @CurrentStepComportmentNO=1;

  WHILE(@CurrentStepComportmentNO<=22)
  BEGIN
  
   SELECT @MeterID=MeterId,@CounterNO=mt.CounterNum
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@CurrentStepComportmentNO

    SELECT @ActualQuantity=wc.Quantity
  FROM #WaterConsumptionData wc where wc.Number=@CounterNo
  SELECT @BatchStepCount=COUNT(1) FROM TCD.BatchStepWaterUsageData WHERE BatchId=@BatchID  AND StepCompartment =@CurrentStepComportmentNO AND ActualQuantity=@ActualQuantity 
  IF (@BatchStepCount=0)
  BEGIN
  IF(ISNULL(@BatchID,0)>0  AND ISNULL(@MeterID,0)>0 AND ISNULL(@ActualQuantity,0)>0)
  BEGIN

   INSERT INTO TCD.BatchStepWaterUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
      EcolabWasherId
     )
     SELECT
     @BatchID,
     @CurrentStepComportmentNO,
     @ActualQuantity,
     @PartitionOn,
     @EcolabWasherId
      END 
	  END 
      SET  @CurrentStepComportmentNO=@CurrentStepComportmentNO+1;  
  END;
 END;
 GO
 IF EXISTS
(
    SELECT
		 *
    FROM sys.objects
    WHERE object_id = OBJECT_ID(
    N'[TCD].[ProcessMyControlTunnelWasherOnlineData]')
		AND type IN(N'P', N'PC')
)
    BEGIN
	   DROP PROCEDURE
		   [TCD].[ProcessMyControlTunnelWasherOnlineData];
    END;
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE PROCEDURE [TCD].[ProcessMyControlTunnelWasherOnlineData]
(
	@ControllerID   INT,
	@xmlTags        XML,
	@RedFlagShiftId INT OUTPUT
)
AS
	BEGIN
	    DECLARE @BatchID                  INT,
			  @WasherID                 INT,
			  @EcolabWasherId           INT,
			  @CurrencyCode             VARCHAR(50),
			  @MachineInternalId        INT,
			  @WasherGroupID            INT,
			  @PlantWasherNumber        INT,
			  @ProgramNumber            INT,
			  @Load                     DECIMAL(10, 2),
			  @NominalLoad              DECIMAL(10, 2),
			  @CustomerNumber           INT,
			  @PHStatus                 INT,
			  @BatchNumber              INT,
			  @TargetTurnTime           INT,
			  @PartitionOn              DATETIME,
			  @BatchStartTime           DATETIME,
			  @ProgramID                INT,
			  @NumberOfCompartments     INT,
			  @TransferSignalId         INT,
			  @BatchShiftId             INT,
			  @compartmentID            INT,
			  @TunnelXML                XML,
			  @TempXML                  XML,
			  @StdInjectionSteps        INT,
			  @StdWashSteps             INT,
			  @EcolabTextileCategoryId  INT,
			  @ChainTextileCategoryId   INT,
			  @FormulaSegmentId         INT,
			  @EcolabSaturationId       INT,
			  @PlantProgramId           INT,
			  @CurrentStepComportmentNO INT,
			  @CounterNO                INT,
			  @MeterID                  INT,
			  @ActualQuantity           DECIMAL(10, 6),
			  @WasherModuleCount        INT;
	    SELECT
			 @TransferSignalId = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Transfer Signal';
	    CREATE TABLE #Batches
	    (
		    BatchNumber   INT,
		    StartDateTime DATETIME
	    );
	    SELECT
			 @TempXML = T.c.query('.')
	    FROM @xmlTags.nodes('MyControlTunnel') AS T(c);
	    SELECT
			 @MachineInternalID = T.c.value('@MachineNumber', 'int')
	    FROM @TempXML.nodes('MyControlTunnel') AS T(c);
	    SELECT
			 @EcolabWasherID = EcolabWasherId,
			 @WasherGroupID = Wg.WasherGroupId,
			 @PlantWasherNumber = PlantWasherNumber,
			 @WasherID = ws.WasherId,
			 @CurrencyCode = P.CurrencyCode,
			 @NumberOfCompartments = Mst.NumberofComp
	    FROM TCD.Washer AS Ws
		    INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = Ws.WasherId
		    INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
		    INNER JOIN TCD.WasherGroupType AS WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
		    INNER JOIN TCD.ConduitController AS Ctrl ON Ctrl.ControllerId = Mst.ControllerId
		    INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.
		    EcoLabAccountNumber
	    WHERE Ctrl.ControllerID = @ControllerID
			AND mst.MachineInternalId = @MachineInternalID
			AND Mst.IsTunnel = 1
			AND Mst.IsDeleted = 0;
	    SET @compartmentID = @NumberOfCompartments;
	    WHILE(@compartmentID <= @NumberOfCompartments
			AND @compartmentID > 0)
		   BEGIN
			  SELECT
				    @TunnelXML = T.c.query('.')
			  FROM @xmlTags.nodes('MyControlTunnel/TunnelData') AS T(c)
			  WHERE T.c.value('@CompartmentNumber', 'INT') =
			  @compartmentID;
			  SELECT
				    @MachineInternalID = T.c.value('@MachineNumber','int'),
				    @BatchNumber = T.c.value('@BatchNumber', 'INT'),
				    @BatchStartTime = T.c.value('@StartDateTime','DateTime'),
				    @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
				    @Load = T.c.value('@Load', 'Decimal(10,6)'),
				    @NominalLoad = T.c.value('@Nominalload','Decimal(10,6)'),
				    @CustomerNumber = T.c.value('@CustomerNumber','int'),
				    @PHStatus = T.c.value('@pHStatus', 'int')
			  FROM @TunnelXML.nodes('TunnelData') AS T(c);
			   --Check for valid startdatetime
			 IF(@BatchStartTime <='01/01/1900' OR @BatchStartTime > '06/06/2079')
			 BEGIN
			  return
			 END
			  DECLARE @ShiftStartDateTemp TABLE
			  (
				  ShiftId        INT,
				  ShiftName      NVARCHAR(50),
				  ShiftStartdate DATETIME
			  );
			  INSERT INTO @ShiftStartDateTemp
			  (
				    ShiftId,
				    ShiftName,
				    ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchStartTime;
			  SELECT
				    @BatchShiftId = ShiftID,
				    @PartitionOn = ShiftStartdate
			  FROM @ShiftStartDateTemp;
			 -- IF(@ProgramNumber = 0
				--OR @BatchNumber = 1)
				-- BEGIN
				--	SELECT
				--		  @compartmentID = @compartmentID - 1;
				--	CONTINUE;
				-- END;
			  SELECT
				    @ProgramID = ProgramId,
				    @TargetTurnTime = 3600 / (tps.TotalRunTime /
				    @NumberOfCompartments)
			  FROM TCD.TunnelProgramSetup AS tps
			  WHERE tps.WasherGroupId = @WasherGroupID
				   AND tps.is_deleted = 0
				   AND ProgramNumber = @ProgramNumber;
			  INSERT INTO #Batches
			  (
				    BatchNumber,
				    StartDateTime
			  )
			  SELECT
				    @BatchNumber,
				    @BatchStartTime;
			  SELECT
				    @BatchID = NULL;
			  SELECT
				    @BatchID = BatchID
			  FROM TCD.BatchData AS BD
			  WHERE BD.ControllerBatchId = @BatchNumber
				   AND BD.StartDate = @BatchStartTime
				   AND BD.MachineId = @WasherID;
			  --Start Getting InjectionCount,StepCount And ProductCount
			  SELECT
				    @StdInjectionSteps = COUNT(tdpm.TunnelDosingSetupId),
				    @StdWashSteps = COUNT(DISTINCT tds.TunnelDosingSetupId) - COUNT(tdpm.TunnelDosingSetupId)
			  FROM tcd.TunnelDosingProductMapping AS tdpm
				  RIGHT JOIN tcd.TunnelDosingSetup AS tds ON tdpm.TunnelDosingSetupId = tds.TunnelDosingSetupId
			  WHERE tds.GroupId = @WasherGroupID
				   AND tds.ProgramNumber = @ProgramNumber;
			  --End Getting InjectionCount,StepCount And ProductCount
			  --Start-----ProgramMasterID logic for PlantChainProgram
			  SELECT
				    @PlantProgramId = pm.PlantProgramId,
				    @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pm.ChainTextileId,
				    @FormulaSegmentId = pm.FormulaSegmentId,
				    @EcolabSaturationId = pm.EcolabSaturationId
			  FROM TCD.ProgramMaster AS pm
			  WHERE pm.ProgramId = @ProgramID
				   AND pm.Is_Deleted = 0;
			  IF(@PlantProgramId <> 0
				OR @PlantProgramId IS NOT NULL)
				 BEGIN
					--Assign value from plantchainprogram table based on plantprogramId
					SELECT
						  @EcolabTextileCategoryId = pcp.EcolabTextileCategoryId,
						  @ChainTextileCategoryId = pcp.ChainTextileCategoryId,
						  @FormulaSegmentId = pcp.FormulaSegmentId,
						  @EcolabSaturationId = pcp.EcolabSaturationId
					FROM tcd.PlantChainProgram AS pcp
					WHERE pcp.PlantProgramId = @PlantProgramId
						 AND pcp.Is_Deleted = 0;
				 END;
			  --End-----ProgramMasterID logic for PlantChainProgram
			  IF @BatchID IS NULL
				 BEGIN
					INSERT INTO TCD.BatchData
					(
						  ControllerBatchId,
						  EcolabWasherId,
						  GroupId,
						  MachineInternalId,
						  PlantWasherNumber,
						  StartDate,
						  ProgramNumber,
						  ProgramMasterId,
						  MachineId,
						  ActualWeight,
						  StandardWeight,
						  CurrencyCode,
						  ShiftId,
						  PartitionOn,
						  TargetTurnTime,
						  StdInjectionSteps,
						  StdWashSteps,
						  EcolabTextileCategoryId,
						  ChainTextileCategoryId,
						  FormulaSegmentId,
						  EcolabSaturationId,
						  PlantProgramId
					)
					SELECT
						  @BatchNumber,
						  @EcolabWasherID,
						  @WasherGroupID,
						  @MachineInternalID,
						  @PlantWasherNumber,
						  @BatchStartTime,
						  @ProgramNumber,
						  @ProgramID,
						  @WasherID,
						  @Load,
						  @NominalLoad,
						  @CurrencyCode,
						  @BatchShiftId,
						  @PartitionOn,
						  @TargetTurnTime,
						  @StdInjectionSteps,
						  @StdWashSteps,
						  @EcolabTextileCategoryId,
						  @ChainTextileCategoryId,
						  @FormulaSegmentId,
						  @EcolabSaturationId,
						  @PlantProgramId;
					SELECT
						  @BatchID = SCOPE_IDENTITY();
					IF(@StdWashSteps > 0
					   OR @StdWashSteps <> NULL)
					    BEGIN
						   INSERT INTO TCD.BatchParameters
						   (
								BatchId,
								EcolabWasherId,
								ParameterId,
								ParameterValue,
								PartitionOn
						   )
						   SELECT
								@BatchID,
								@EcolabWasherId,
								38,
								@StdWashSteps,
								@PartitionOn;
					    END;
					IF @CustomerNumber IS NOT NULL
					    BEGIN
						   IF NOT EXISTS
						   (
							  SELECT
								    1
							  FROM TCD.BatchCustomerData
							  WHERE BatchID = @BatchID
						   )
							  BEGIN
								 INSERT INTO TCD.BatchCustomerData
								 (
									   BatchId,
									   CustomerID,
									   Weight,
									   PartitionOn,
									   EcolabWasherId
								 )
								 SELECT
									   @BatchID,
									   @CustomerNumber,
									   @Load,
									   @PartitionOn,
									   @EcolabWasherId;
							  END;
					    END;
				 END;
			  -- Transfer Signal
			  IF NOT EXISTS
			  (
				 SELECT
					   *
				 FROM tcd.WasherReading wr
				 WHERE wr.WasherId = @WasherID
					  AND wr.ParameterId = @TransferSignalId
					  AND wr.DateTimeStamp = @BatchStartTime
			  )
				 BEGIN
					INSERT INTO TCD.WasherReading
					(
						  WasherId,
						  ParameterId,
						  ParameterValue,
						  DateTimeStamp,
						  PartitionOn,
						  EcolabWasherId
					)
					SELECT
						  @WasherID,
						  @TransferSignalId,
						  1,
						  @BatchStartTime,
						  @PartitionOn,
						  @EcolabWasherId
					UNION ALL
					SELECT
						  @WasherID,
						  @TransferSignalId,
						  0,
						  @BatchStartTime,
						  @PartitionOn,
						  @EcolabWasherId;
				 END;
			  --Start Updating Batch Wash Step Data  
			  CREATE TABLE #BatchWashStepData
			  (
				  Compartment_No  INT,
				  Step_Time       INT,
				  Batch_StartDate DATETIME
			  );
			  INSERT INTO #BatchWashStepData
			  (
				    Compartment_No,
				    Step_Time,
				    Batch_StartDate
			  )
			  SELECT
				    T.c.value('@CompartmentNo', 'INT'),
				    T.c.value('@Time', 'INT'),
				    T.c.value('../@StartDateTime', 'Datetime')
			  FROM @TunnelXML.nodes('TunnelData/CompartmentTime') T(c);
			  WITH CTE
				  AS (SELECT
						   a.Compartment_No,
						   a.Step_Time,
						   a.Batch_StartDate,
						   SUM(b.Step_Time) AS TotalSeconds
					 FROM #BatchWashStepData a
						 CROSS JOIN #BatchWashStepData b
					 WHERE b.Compartment_No <= a.Compartment_No
					 GROUP BY
							a.Compartment_No,
							a.Step_Time,
							a.Batch_StartDate --ORDER BY a.Compartment_No
					 ),
				  CTE2
				  AS (SELECT
						   c.*,
						   DATEADD(ss, c.TotalSeconds, c.Batch_StartDate)
						   Step_End
					 FROM CTE c
					 WHERE c.Step_Time > 0)
				  MERGE INTO TCD.BatchWashStepData bpd
				  USING
				  (
					 SELECT
						   p.*,
						   LAG(p.Step_End, 1, p.Batch_StartDate)
						   OVER(ORDER BY p.Compartment_No) AS
						       Step_StartTime,
						   CASE
							  WHEN p.Compartment_No =
							  @compartmentID
							  THEN NULL
							  WHEN p.Compartment_No <>
							  @compartmentID
							  THEN p.Step_End
						   END Step_EndTIme
					 FROM CTE2 p
				  ) temp
				  ON bpd.BatchId = @BatchID
					AND bpd.StepCompartment = temp.Compartment_No
					 WHEN MATCHED
					 THEN UPDATE SET
								  StartTime = temp.Step_StartTime,
								  EndTime = temp.Step_EndTIme
					 WHEN NOT MATCHED
					 THEN INSERT(
							   BatchId,
							   StepCompartment,
							   StartTime,
							   EndTime,
							   PartitionOn,
							   EcolabWasherId) VALUES
				  (
												 @BatchId,
												 temp.
												 Compartment_No,
												 temp.
												 Step_StartTime,
												 temp.
												 Step_EndTIme,
												 @PartitionOn,
												 @EcolabWasherID
				  );
			  DROP TABLE #BatchWashStepData;
			  --End Updating Batch Wash Step Data  
			  SELECT
				    @compartmentID = @compartmentID - 1;
		   END;
		    WITH XmlData
		    AS (SELECT
					m.MeterId,
					m.CounterNum                              Meter_Counter,
					T.c.value('../@CompartmentNumber', 'INT') CompNo, --Compartment No
					T.c.value('@Counter', 'INT') AS           Xml_Counter, --PumpNumber
					T.c.value('@Value', 'DECIMAL(10,6)') AS   Quantity	    --Water Quanity
			   FROM @xmlTags.nodes(
					'MyControlTunnel/TunnelData/WaterConsumption'
							  ) T(C)
				   INNER JOIN TCD.Meter m ON m.UtilityType = 2
									    AND m.GroupId =
									    @WasherGroupID
									    AND m.ControllerID =
									    @ControllerID
									    AND m.MachineCompartment
									    = T.c.value('../@CompartmentNumber',
									    'INT'
												)
				   AND m.CounterNum = T.c.value('@Counter', 'INT')
			   WHERE T.c.value('@Value', 'DECIMAL(10,6)') > 0)
		    MERGE INTO TCD.WasherModuleOnlineUsageData
		    USING
		    (
			   SELECT
					*
			   FROM XmlData
		    ) temp
		    ON WasherId = @WasherID
			  AND StepComportment = temp.CompNo
			  AND ModuleId = temp.MeterId
			  AND ActualQuantity = temp.Quantity
			   WHEN NOT MATCHED AND(temp.Quantity <> NULL
							    OR temp.Quantity <> 0)
			   THEN INSERT(
							 WasherId,
							 StepComportment,
							 ModuleId,
							 ActualQuantity,
							 TimeStamp,
							 EcolabWasherId
						) 
						VALUES
						(
							@WasherID,
							temp.CompNo,
							temp.MeterId,
							temp.Quantity,
							GETUTCDATE(),
							@EcolabWasherId
						 );

						 
	UPDATE BD
	SET EndDate=DateAdd(mi,10,StartDate)
	FROM TCD.BatchData BD
	WHERE MachineId =@WasherID
		  AND EndDate is Null
	      AND Not Exists(SELECT 1 
						 FROM #Batches t
						 WHERE t.BatchNumber = BD.ControllerBatchId
							   and t.StartDateTime =BD.StartDate
						)
	END;
	GO
-----------------------------------------------------------------End My Control Tunnel online and production sp changes-----------------------------------
-----------------------------------------------------------------End My Control Tunnel and conventional production sp changes-----------------------------------
 IF EXISTS
(
    SELECT
		 *
    FROM sys.objects
    WHERE object_id = OBJECT_ID(
    N'[TCD].[ProcessMyControlTunnelWasherProdData]')
		AND type IN(N'P', N'PC')
)
    BEGIN
	   DROP PROCEDURE
		   [TCD].[ProcessMyControlTunnelWasherProdData];
    END;
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE PROCEDURE [TCD].[ProcessMyControlTunnelWasherProdData](
	@ControllerID   INT,
	@xmlTags        XML,
	@PLCPointer     INT,
	@ReadPointer    INT,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @BatchID                   INT,
			  @WasherID                  INT,
			  @EcolabWasherId            INT,
			  @CurrencyCode              VARCHAR(50),
			  @MachineInternalId         INT,
			  @WasherGroupID             INT,
			  @PlantWasherNumber         INT,
			  @ProgramNumber             INT,
			  @Load                      DECIMAL(10, 2),
			  @NominalLoad               DECIMAL(10, 2),
			  @CustomerNumber            INT,
			  @PHStatus                  INT,
			  @PHValue                   INT,
			  @LFStatus                  INT,
			  @LFValue                   INT,
			  @BatchNumber               INT,
			  @TargetTurnTime            INT,
			  @PartitionOn               DATETIME2,
			  @BatchStartTime            DATETIME2,
			  @BatchEndTime              DATETIME2,
			  @ProgramID                 INT,
			  @NumberOfCompartments      INT,
			  @ProductId                 INT,
			  @CompartmentNum            INT,
			  @EquipmentType             INT,
			  @MinTempParamID            INT,
			  @MaxTempParamID            INT,
			  @TempStatusParamID         INT,
			  @PHValueParamID            INT,
			  @PHStatusParamID           INT,
			  @ConductivityValueParamID  INT,
			  @ConductivityStatusParamID INT,
			  @StdInjectionSteps         INT,
			  @StdWashSteps              INT,
			  @ActualInjSteps            INT,
			  @EcolabTextileCategoryId   INT,
			  @ChainTextileCategoryId    INT,
			  @FormulaSegmentId          INT,
			  @EcolabSaturationId        INT,
			  @PlantProgramId            INT,
			  @PreviousShiftId		    INT,
			  @CurrentShiftId		    INT,
			  @CurrentStepComportmentNO  INT,
			  @CounterNO			    INT,
			  @MeterID			    INT,
                 @ActualQuantity		    DECIMAL(18,4),
			  @BatchStepCount		    INT,
			  @EcolabAccountNumber	    VARCHAR(100),
			  @AlarmGroupMasterId	    INT,
			  @StandardQuantity          DECIMAL(18, 4),
			  @Price                     DECIMAL(18, 4);

	    DECLARE @BatchShiftId INT;
	    DECLARE @ShiftStartDateTemp TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    DECLARE @TunnelXML XML;
	    SELECT @TunnelXML = T.c.query('.')
	    FROM @xmlTags.nodes('MyControlTunnel/TunnelData') T(c)
	    WHERE T.c.value('@CompartmentNumber', 'INT') = 0;

		
	    SELECT @MachineInternalID = T.c.value('@MachineNumber', 'int'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @BatchStartTime = T.c.value('@StartDateTime', 'DateTime'),
			 @BatchEndTime = T.c.value('@EndDateTime', 'DateTime'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@Nominalload', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'int'),
			 @PHStatus = T.c.value('@Phstatus', 'int'),
			 @PHValue = T.c.value('@Phvalue', 'INT'),
			 @LFStatus = T.c.value('@LFStatus', 'INT'),
			 @LFValue = T.c.value('@LFValue', 'INT')
	    FROM @xmlTags.nodes('MyControlTunnel/TunnelData') T(c);

		--Check for valid startdatetime
		IF(@BatchStartTime <='01/01/1900' OR @BatchStartTime > '06/06/2079')
		BEGIN
			return
		END

	    SELECT @EcolabWasherID = Ws.EcolabWasherId,
			 @WasherGroupID = Wg.WasherGroupId,
			 @PlantWasherNumber = PlantWasherNumber,
			 @WasherID = ws.WasherId,
			 @CurrencyCode = P.CurrencyCode,
			 @NumberOfCompartments = Mst.NumberofComp
	    FROM TCD.Washer Ws
		    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.
		    GroupId
		    INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId
		    = Wg.WasherGroupTypeId
		    INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId =
		    Mst.ControllerId
		    INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.
		    EcoLabAccountNumber
	    WHERE Ctrl.ControllerID = @ControllerID
			AND Mst.MachineInternalId = @MachineInternalID
			AND Mst.IsTunnel = 1 AND Mst.IsDeleted=0;
	    SELECT @EcolabWasherID;
	    SELECT @ProgramID = ProgramId,
			 @TargetTurnTime = (3600 / (tps.TotalRunTime /
			 @NumberOfCompartments))
	    FROM TCD.TunnelProgramSetup AS tps
	    WHERE tps.WasherGroupId = @WasherGroupID
			AND tps.is_deleted = 0
			AND ProgramNumber = @ProgramNumber;
	    DELETE FROM @ShiftStartDateTemp;
	    IF(@BatchEndTime IS NOT NULL)
		   BEGIN
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchEndTime
		   END;
	    ELSE
		   BEGIN
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchStartTime
		   END;
	    SELECT @BatchShiftId = ShiftID,
			 @PartitionOn = ShiftStartdate
	    FROM @ShiftStartDateTemp;


	    --Start Getting InjectionCount,StepCount And ProductCount
	    SELECT @StdInjectionSteps = COUNT(tdpm.TunnelDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT tds.TunnelDosingSetupId) -
			 COUNT(tdpm.TunnelDosingSetupId)
	    FROM tcd.TunnelDosingProductMapping tdpm
		    RIGHT JOIN tcd.TunnelDosingSetup tds ON tdpm.
		    TunnelDosingSetupId = tds.TunnelDosingSetupId
	    WHERE tds.GroupId = @WasherGroupID
			AND tds.ProgramNumber = @ProgramNumber;
	    --End Getting InjectionCount,StepCount And ProductCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramID
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT @EcolabTextileCategoryId = pcp. EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp. ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    SELECT @BatchID = NULL;
	    SELECT @BatchID = BatchID
	    FROM TCD.BatchData BD
	    WHERE BD.ControllerBatchId = @BatchNumber
			AND BD.StartDate = @BatchStartTime
			AND BD.MachineId = @WasherID;
	    --AND BD.MachineInternalID = @MachineInternalID
	    IF(@BatchID IS NULL)
		   BEGIN
		   --Start Rollup for previous completed shift
	   IF(CAST(@BatchStartTime as date) < CAST(GETUTCDATE() as date))
	   BEGIN
		  SELECT TOP 1 @PreviousShiftId=ShiftId FROM TCD.BatchData WHERE MachineId=@WasherId ORDER BY StartDate DESC	   
		  SELECT Top 1 @CurrentShiftId = ShiftId from @ShiftStartDateTemp
		  IF(@CurrentShiftId != @PreviousShiftId)
		  BEGIN
			 EXEC TCD.ProductionShiftDataRollup @PreviousShiftId, @RedFlagShiftId OUTPUT
			 IF(@RedFlagShiftId IS NULL)
			 BEGIN
				SET @RedFlagShiftId = @PreviousShiftId
			 END
		  END
	   END
	   --End Rollup for previous completed shift
			  INSERT INTO TCD.BatchData
			  (ControllerBatchId,
			   EcolabWasherId,
			   GroupId,
			   MachineInternalId,
			   PlantWasherNumber,
			   StartDate,
			   EndDate,
			   ProgramNumber,
			   ProgramMasterId,
			   MachineId,
			   ActualWeight,
			   StandardWeight,
			   CurrencyCode,
			   ShiftId,
			   PartitionOn,
			   TargetTurnTime,
			   StdInjectionSteps,
			   StdWashSteps,
			   EcolabTextileCategoryId,
			   ChainTextileCategoryId,
			   FormulaSegmentId,
			   EcolabSaturationId,
			   PlantProgramId,
			   EndDateFormula
			  )
				    SELECT @BatchNumber,
						 @EcolabWasherID,
						 @WasherGroupID,
						 @MachineInternalID,
						 @PlantWasherNumber,
						 @BatchStartTime,
						 @BatchEndTime,
						 @ProgramNumber,
						 @ProgramID,
						 @WasherID,
						 @Load,
						 @NominalLoad,
						 @CurrencyCode,
						 @BatchShiftId,
						 @PartitionOn,
						 @TargetTurnTime,
						 @StdInjectionSteps,
						 @StdWashSteps,
						 @EcolabTextileCategoryId,
						 @ChainTextileCategoryId,
						 @FormulaSegmentId,
						 @EcolabSaturationId,
						 @PlantProgramId,
						 @BatchEndTime;
			  SELECT @BatchID = SCOPE_IDENTITY();
			  IF(@StdWashSteps > 0
				OR @StdWashSteps <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchID,
							@EcolabWasherId,
							38,
							@StdWashSteps,
							@PartitionOn;
			  EXEC TCD.UPDATEBatchWashStepForTunnel
				  @TunnelXML,
				  @WasherID,
				  @BatchID,
				  @BatchStartTime,
				  @PartitionOn,
				  @EcolabWasherId,
				  @NumberOfCompartments;
		   END;
		ELSE 
		BEGIN
			IF(@BatchEndTime IS NOT NULL
			  AND @BatchEndTime != '01/01/1900')
			   BEGIN
				  UPDATE TCD.BatchData
					SET
					   EndDate = @BatchEndTime,
					   ShiftId = @BatchShiftId,
					   PartitionOn = @PartitionOn,
					   EndDateFormula=@BatchEndTime
				  WHERE BATCHID = @BatchID;
			   END;
		END

		      --If the received formula is not configured in enVision then create an alarm 
       IF(@ProgramID is NULL)
       BEGIN
       SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant;
       SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.AlarmGroupMsterVsControllerModelType AGMVCMT
       INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
       WHERE AGMVCMT.AlarmCode = 9000
        INSERT INTO [TCD].[AlarmData] 
           (EcoalabAccountNumber,
           AlarmCode,
           BatchId,
           controllerID,
           StartDate,
           GroupId,
           MachineInternalId,
           ProgramId,   
           IsActive,
           EndDate,
           MachineId,
           AlarmGroupMasterId)
           SELECT
            @ECOLABAccountNumber,
            9000,
            @BatchID,
            @ControllerId,
            @BatchStartTime,
            @WasherGroupID,
            @MachineInternalID,
            @ProgramNumber,
            0,
            @BatchStartTime,
            @WasherId,
            @AlarmGroupMasterId
       END


	    IF(@CustomerNumber IS NOT NULL)
		   BEGIN
			  IF NOT EXISTS
			  (
				 SELECT 1
				 FROM [TCD].[BatchCustomerData]
				 WHERE BatchID = @BatchID
			  )
				 BEGIN
					INSERT INTO [TCD].[BatchCustomerData]
					([BatchId],
					 CustomerID,
					 [Weight],
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @BatchID,
							    @CustomerNumber,
							    @Load,
							    @PartitionOn,
							    @EcolabWasherId;
				 END;
		   END;
	    CREATE TABLE #DosingDetails
	    (
		    Number          INT,
		    Quantity        DECIMAL(10, 6),
		    Point           INT,
		    IsMainEquioment INT
	    );
	    INSERT INTO #DosingDetails
	    (Number,
		Quantity,
		Point,
		IsMainEquioment
	    )
			 SELECT T.c.value('@Number', 'INT') AS Number, --PumpNumber
				   T.c.value('@Quantity', 'Decimal(10,6)') AS Quantity, --Dosing Quanity
				   T.c.value('@Point', 'INT') AS Point, --Dosing point
				   T.c.value('@IsMainEquioment', 'INT') AS
			 IsMainEquioment
			 FROM @xmlTags.nodes('MyControlTunnel/TunnelData/Dose') T(C)
	    ;
	
	    -- Fetching data from cursor
	    DECLARE @MYCURSOR CURSOR;
	    SET @MYCURSOR = CURSOR FAST_FORWARD
	    FOR SELECT Number,
				Quantity,
				Point,
				IsMainEquioment
		   FROM #DosingDetails;
	    DECLARE @Number          INT,
			  @Quantity        DECIMAL(10, 6),
			  @Point           INT,
			  @IsMainEquioment INT;
	    OPEN @MYCURSOR;
	    FETCH NEXT FROM @MYCURSOR INTO @Number,
								@Quantity,
								@Point,
								@IsMainEquioment;
	    WHILE @@FETCH_STATUS = 0
		   BEGIN
		   Set @ProductId = null;
		   Set @CompartmentNum = null;
			  IF(@IsMainEquioment = 1)
				 BEGIN
					SET @EquipmentType = 2;
				 END;
			  ELSE
				 BEGIN
					SET @EquipmentType = 1;
				 END;
			  SELECT @ProductId = CES.ProductId,
				    @CompartmentNum = TCEVM.CompartmentNumber
			  FROM tcd.ControllerEquipmentSetup CES
				  INNER JOIN TCD.
				  TunnelCompartmentEquipmentValveMapping TCEVM ON CES.
				  ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
			  WHERE CES.ControllerId = @ControllerID
				   AND CES.ControllerEquipmentTypeId = @EquipmentType
				   AND --CES.IsActive=1 AND
				   --CES.WasherGroupNumber=@WasherGroupNum AND
                              --TCEVM.DosingPointNumber = @Point è OLD
                              TCEVM.DosingPointNumber= CASE WHEN TCEVM.DirectDosingFlag=0 THEN @Point ELSE 0 END 
				   AND CES.ControllerEquipmentId = @Number;
				
			 SELECT DISTINCT
				    @StandardQuantity =((Wps.NominalLoad * Wdpm.Quantity) / 100),
				    @Price = (((Wps.NominalLoad * Wdpm.Quantity) / 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID))
			  FROM TCD.Washer WS
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =Mst.GroupId
				  INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
				  INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
				  INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
				  INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON
				  Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
				  INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId = Wdpm.ControllerEquipmentSetupId
				  INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId = Ces.ProductId
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wds.CompartmentNumber = @CompartmentNum
				   AND Wps.Is_Deleted = 0
				   AND Pdm.Is_Deleted = 0;
				
			  IF(@ProductId IS NOT NULL)
				 BEGIN
					INSERT INTO TCD.BatchProductData
					(
						  BatchId,
						  StepCompartment,
						  ActualQuantity,
						  StandardQuantity,
						  Price,
						  [TimeStamp],
						  PartitionOn,
						  EcolabWasherId,
						  ProductId
					)
					SELECT
						  @BatchID,
						  @CompartmentNum,
						  @Quantity,
						  isnull(@StandardQuantity,0),
						  isnull(@Price,0),
						  @BatchEndTime,
						  @PartitionOn,
						  @EcolabWasherID,
						  @ProductId;
				 END;
			  FETCH NEXT FROM @MYCURSOR INTO @Number,
									   @Quantity,
									   @Point,
									   @IsMainEquioment;
		   END;
	    CLOSE @MYCURSOR;
	    DEALLOCATE @MYCURSOR;
	    DROP TABLE #DosingDetails;
	    SELECT @ActualInjSteps = COUNT(DISTINCT StepCompartment)
	    FROM TCD.BatchProductData
	    WHERE BatchId = @BatchID;
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.BatchParameters
		   WHERE ParameterId = 37
			    AND batchid = @BatchID
			    AND @ActualInjSteps > 0
	    )
		   BEGIN
			  IF(@ActualInjSteps > 0
				OR @ActualInjSteps <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchId,
							@EcolabWasherId,
							37,
							@ActualInjSteps,
							@PartitionOn;
		   END;
	    ELSE
		   BEGIN
			  UPDATE TCD.BatchParameters
			    SET
				   ParameterValue = @ActualInjSteps
			  WHERE ParameterId = 37
				   AND batchid = @BatchID;
		   END;
	    SELECT @MinTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Mimum Temperature';
	    SELECT @MaxTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Maximum Temperature';
	    SELECT @TempStatusParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Temperature Status';
	    SELECT @PHValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH';
	    SELECT @PHStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH Status';
	    SELECT @ConductivityValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Conductivity';
	    SELECT @ConductivityStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'LF Status';
	    IF(@PHValue IS NOT NULL)
		   BEGIN
			  --pH Value
			  IF(@PHValue <> 0
				OR @PHValue <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @PHValueParamID,
					   @PHValue,
					   @PartitionOn
				 );

			  --pH Status
			  IF(@PHStatus <> 0
				OR @PHStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @PHStatusParamID,
					   @PHStatus,
					   @PartitionOn
				 );
		   END;
	    IF(@LFValue IS NOT NULL)
		   BEGIN
			  --Conductivity Value
			  IF(@LFValue <> 0
				OR @LFValue <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @ConductivityValueParamID,
					   @LFValue,
					   @PartitionOn
				 );

			  --Conductivity Status
			  IF(@LFStatus <> 0
				OR @LFStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @ConductivityStatusParamID,
					   @LFStatus,
					   @PartitionOn
				 );
		   END;
	    CREATE TABLE #TemperatureDetails
	    (
		    MinimumTemp DECIMAL(10, 2),
		    MaximumTemp DECIMAL(10, 2),
		    TempStatus  DECIMAL(10, 2)
	    );
	    INSERT INTO #TemperatureDetails
	    (MinimumTemp,
		MaximumTemp,
		TempStatus
	    )
			 SELECT T.c.value('@Minimum', 'Decimal(10,2)') AS
			 MinimumTemp,
				   T.c.value('@Maximum', 'Decimal(10,2)') AS
				   MaximumTemp,
				   T.c.value('@Status', 'Decimal(10,2)') AS TempStatus
			 FROM @xmlTags.nodes(
			 'MyControlTunnel/TunnelData/TemperatureData'
							) T(c);
	  
	    -- Fetching data from cursor
	    DECLARE @TEMPCURSOR CURSOR;
	    SET @TEMPCURSOR = CURSOR FAST_FORWARD
	    FOR SELECT MinimumTemp,
				MaximumTemp,
				TempStatus
		   FROM #TemperatureDetails;
	    DECLARE @MinimumTemp DECIMAL(10, 2),
			  @MaximumTemp DECIMAL(10, 2),
			  @TempStatus  DECIMAL(10, 2);
	    OPEN @TEMPCURSOR;
	    FETCH NEXT FROM @TEMPCURSOR INTO @MinimumTemp,
								  @MaximumTemp,
								  @TempStatus;
	    WHILE @@FETCH_STATUS = 0
		   BEGIN	
			  --Minimum Temperature
			  IF(@MinimumTemp <> 0
				OR @MinimumTemp <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @MinTempParamID,
					   @MinimumTemp,
					   @PartitionOn
				 );

			  --Maximum Temperature
			  IF(@MaximumTemp <> 0
				OR @MaximumTemp <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @MaxTempParamID,
					   @MaximumTemp,
					   @PartitionOn
				 );

			  --Temperature Status
			  IF(@TempStatus <> 0
				OR @TempStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @TempStatusParamID,
					   @TempStatus,
					   @PartitionOn
				 );
			  FETCH NEXT FROM @TEMPCURSOR INTO @MinimumTemp,
										@MaximumTemp,
										@TempStatus;
		   END;
	    CLOSE @TEMPCURSOR;
	    DEALLOCATE @TEMPCURSOR;
	    DROP TABLE #TemperatureDetails;
	    UPDATE TCD.BatchWashStepData
		 SET
			EndTime = DATEADD(ss,
						  (SELECT T.c.value('@Time', 'INT')
							 FROM @TunnelXML.nodes('TunnelData/CompartmentTime') T(c)
							 WHERE T.c.value('@CompartmentNo','INT') =
							 (
								SELECT
									  bwsd.StepCompartment
								FROM tcd.BatchWashStepData bwsd
								WHERE bwsd.BatchId = @BatchID
									 AND bwsd.EndTime IS NULL
							 )
						  ),
						  (
							 SELECT
								   bwsd.StartTime
							 FROM tcd.BatchWashStepData bwsd
							 WHERE bwsd.BatchId = @BatchID
								  AND bwsd.EndTime IS NULL
						  ))
	    WHERE
			BatchId = @BatchID
			AND EndTime IS NULL;
   
   --Start water consumption per batch


    CREATE TABLE #WaterConsumptionData
     (
      Number          INT,
      Quantity        DECIMAL(18,4),
     );
     INSERT INTO #WaterConsumptionData
     (Number,
  Quantity
     )
    SELECT T.c.value('@Counter', 'INT') AS Number, --PumpNumber
       T.c.value('@Value', 'DECIMAL(18,4)') AS Quantity --Water Quanity
    FROM @xmlTags.nodes('MyControlTunnel/TunnelData/WaterConsumption') T(C);

  
  SET @CurrentStepComportmentNO=1;

  WHILE(@CurrentStepComportmentNO<=22)
  BEGIN
  
   SELECT @MeterID=MeterId,@CounterNO=mt.CounterNum
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@CurrentStepComportmentNO

    SELECT @ActualQuantity=wc.Quantity
  FROM #WaterConsumptionData wc where wc.Number=@CounterNo
  SELECT @BatchStepCount=COUNT(1) FROM TCD.BatchStepWaterUsageData WHERE BatchId=@BatchID  AND StepCompartment =@CurrentStepComportmentNO AND ActualQuantity=@ActualQuantity 
  IF (@BatchStepCount=0)
  BEGIN
  IF(ISNULL(@BatchID,0)>0  AND ISNULL(@MeterID,0)>0 AND ISNULL(@ActualQuantity,0)>0)
  BEGIN

   INSERT INTO TCD.BatchStepWaterUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
      EcolabWasherId
     )
     SELECT
     @BatchID,
     @CurrentStepComportmentNO,
     @ActualQuantity,
     @PartitionOn,
     @EcolabWasherId
      END 
	  END 
      SET  @CurrentStepComportmentNO=@CurrentStepComportmentNO+1;  
  END;
 END;
 GO
  IF EXISTS
(
    SELECT
		 *
    FROM sys.objects
    WHERE object_id = OBJECT_ID(
    N'[TCD].[ProcessMyControlConventionalData_CompletedBatches]')
		AND type IN(N'P', N'PC')
)
    BEGIN
	   DROP PROCEDURE
		   [TCD].[ProcessMyControlConventionalData_CompletedBatches];
    END;
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO
CREATE PROCEDURE [TCD].[ProcessMyControlConventionalData_CompletedBatches](
	@ControllerID   INT,
	@VxML           XML,
	@PLCPointer     INT,
	@ReadPointer    INT,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @MachineNumber           INT,
			  @StartDateTime           DATETIME,
			  @EndDateTime             DATETIME,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @PHValue                 INT,
			  @TemperatureMin          INT,
			  @TemperatureMax          INT,
			  @TempMinStatus           INT,
			  @TempMaxStatus           INT,
			  @BatchNumber             INT,
			  @WasherID                INT,
			  @WasherGroupID           INT,
			  @EcoLabWasherID          INT,
			  @ProgramMasterID         INT,
			  @PlantWasherNumber       INT,
			  @ShiftID                 INT,
			  @BatchID                 INT,
			  @ShiftStartdate          DATETIME,
			  @LastStep                INT,
			  @CurrentStep             INT,
			  @CurrentStepTime         DATETIME,
			  @MinTempParamID          INT,
			  @MaxTempParamID          INT,
			  @MinTempStatuParamID     INT,
			  @MaxTempStatusParamID    INT,
			  @PHStatusParamID         INT,
			  @PHValueParamID          INT,
			  @CurrencyCode            VARCHAR(50),
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @ActualInjSteps          INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @TargetTurnTime          INT,
			  @PreviousShiftId         INT,
			  @CurrentShiftId          INT,
			  @MeterID                 INT,
			  @StepComportment         INT,
			  @Stepno                  INT,
			  @quantity                INT,
			  @productid               INT,
			  @Price                   DECIMAL(18, 4),
			  @StandardQty             DECIMAL(18, 4),
			  @TimeStamp               DATETIME2(7),
			  @MaxWashertGroupCapacity INT,
			  @InjectionNumber         INT,
			  @WaterConsumption1       DECIMAL(10,6),
			  @WaterConsumption2       DECIMAL(10,6),
			  @EnergyCount             INT,
			   @EcolabAccountNumber    VARCHAR(100),
	           @AlarmGroupMasterId     INT;
	    SELECT
			 @MachineNumber = T.c.value('@MachineNumber', 'INT'),
			 @StartDateTime = T.c.value('@StartDateTime', 'DateTime'),
			 @EndDateTime = T.c.value('@EndDateTime', 'DateTime'),
				    @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@NominalLoad', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'INT'),
			 @PHStatus = T.c.value('@PHStatus', 'INT'),
			 @PHValue = T.c.value('@PHValue', 'INT'),
			 @TemperatureMin = T.c.value('@TemperatureMin', 'INT'),
			 @TemperatureMax = T.c.value('@TemperatureMax', 'INT'),
			 @TempMaxStatus = T.c.value('@TemperatureMaxStatus', 'INT'),
			 @TempMinStatus = T.c.value('@TemperatreMinStatus', 'INT'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @WaterConsumption1 = T.c.value('@WaterConsumption1','DECIMAL(10,6)'),
			 @WaterConsumption2 = T.c.value('@WaterConsumption2','DECIMAL(10,6)')
	    FROM @VxML.nodes('MyControlConventionalData') T(C);

			   --Check for valid startdatetime
		IF(@StartDateTime <='01/01/1900' OR @StartDateTime > '06/06/2079')
			 BEGIN
			  return
			 END

	    DECLARE @ShiftMapping TABLE
			  (
				  ShiftId        INT,
				  ShiftName      NVARCHAR(50),
				  ShiftStartdate DATETIME
			  );
	    INSERT INTO @ShiftMapping
			  (
				    ShiftId,
				    ShiftName,
				    ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
		    @StartDateTime;
			  SELECT
			 @ShiftID = ShiftID,
			 @ShiftStartdate = ShiftStartdate
	    FROM @ShiftMapping;
			  SELECT
			 @WasherGroupID = GroupId,
			 @WasherID = WasherID
	    FROM TCD.MachineSetup ms
	    WHERE ControllerID = @ControllerID
			AND MachineInternalId = @MachineNumber
			AND IsTunnel = 0
			AND IsDeleted = 0;
	    IF(@WasherId IS NOT NULL)
		   BEGIN
			  SELECT
				    @ProgramMasterId = Wps.ProgramId
			  FROM TCD.Washer Ws
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws
				  .WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =
				  Mst.GroupId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.
				  ControllerID = Wg.ControllerId
				  INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber =
				  Ws.EcoLabAccountNumber
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wps.Is_Deleted = 0;
			  SELECT
				    @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber,
				    @CurrencyCode = P.CurrencyCode,
				    @TargetTurnTime = w.TargetTurnTime * 60
			  FROM TCD.Washer w
				  INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.
				  EcolabAccountNumber
			  WHERE w.WasherId = @WasherID;
		   END;
			  SELECT
				    @BatchID = BatchID
	    FROM TCD.BatchData
	    WHERE MachineInternalID = @MachineNumber
			AND StartDate = @StartDateTime
			AND ControllerBatchId = @BatchNumber
			AND MachineID = @WasherID;

	    --Start Getting InjectionCount and StepCount

			  SELECT
			 @StdInjectionSteps = COUNT(DISTINCT wdpm.
			 WasherDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) -
			 COUNT(DISTINCT wdpm.WasherDosingSetupId)
	    FROM TCD.WasherDosingProductMapping wdpm
		    RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm.
		    WasherDosingSetupId = wds.WasherDosingSetupId
	    WHERE wds.ControllerID = @ControllerID
			AND wds.ProgramNumber = @ProgramNumber;

	    --End Getting InjectionCount and StepCount
			  --Start-----ProgramMasterID logic for PlantChainProgram
			  SELECT
				    @PlantProgramId = pm.PlantProgramId,
				    @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pm.ChainTextileId,
				    @FormulaSegmentId = pm.FormulaSegmentId,
				    @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramMasterId
				   AND pm.Is_Deleted = 0;
			  IF(@PlantProgramId <> 0
				OR @PlantProgramId IS NOT NULL)
				 BEGIN
					--Assign value from plantchainprogram table based on plantprogramId
					SELECT
				    @EcolabTextileCategoryId = pcp.
				    EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp.
				    ChainTextileCategoryId,
						  @FormulaSegmentId = pcp.FormulaSegmentId,
						  @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
					WHERE pcp.PlantProgramId = @PlantProgramId
						 AND pcp.Is_Deleted = 0;
				 END;
			  --End-----ProgramMasterID logic for PlantChainProgram

	    IF(@BatchID IS NULL)
				 BEGIN

			  --Start Rollup for previous completed shift
			  IF(CAST(@StartDateTime AS DATE) < CAST(GETUTCDATE() AS
			  DATE))
				 BEGIN
					SELECT TOP 1
						  @PreviousShiftId = ShiftId
					FROM TCD.BatchData
					WHERE MachineId = @WasherId
					ORDER BY
						    StartDate DESC;
					SELECT TOP 1
						  @CurrentShiftId = ShiftId
					FROM @ShiftMapping;
					IF(@CurrentShiftId != @PreviousShiftId)
					    BEGIN
						   EXEC TCD.ProductionShiftDataRollup
							   @PreviousShiftId,
							   @RedFlagShiftId OUTPUT;
						   IF(@RedFlagShiftId IS NULL)
							  BEGIN
								 SET @RedFlagShiftId =
								 @PreviousShiftId;
							  END;
					    END;
				 END;
			  --End Rollup for previous completed shift

					INSERT INTO TCD.BatchData
					(
				    ControllerBatchID,
						  EcolabWasherId,
						  GroupId,
						  MachineInternalId,
						  PlantWasherNumber,
						  StartDate,
				    EndDate,
						  ProgramNumber,
						  ProgramMasterId,
				    MachineID,
						  ActualWeight,
						  StandardWeight,
						  CurrencyCode,
						  ShiftId,
						  PartitionOn,
						  StdInjectionSteps,
						  StdWashSteps,
						  EcolabTextileCategoryId,
						  ChainTextileCategoryId,
						  FormulaSegmentId,
						  EcolabSaturationId,
				    PlantProgramId,
				    EndDateFormula,
				    TargetTurnTime
					)
			  VALUES
			  (
						  @BatchNumber,
				    @EcoLabWasherID,
						  @WasherGroupID,
				    @MachineNumber,
						  @PlantWasherNumber,
				    @StartDateTime,
				    @EndDateTime,
						  @ProgramNumber,
				    @ProgramMasterId,
						  @WasherID,
						  @Load,
						  @NominalLoad,
						  @CurrencyCode,
				    @ShiftID,
				    @ShiftStartdate,
						  @StdInjectionSteps,
						  @StdWashSteps,
						  @EcolabTextileCategoryId,
						  @ChainTextileCategoryId,
						  @FormulaSegmentId,
						  @EcolabSaturationId,
				    @PlantProgramId,
				    @EndDateTime,
				    @TargetTurnTime
			  );
					SELECT
						  @BatchID = SCOPE_IDENTITY();
			  IF NOT EXISTS
			  (
				 SELECT
					   *
				 FROM TCD.BatchParameters
				 WHERE BatchId = @BatchID
					  AND ParameterID = 38
			  )
				 BEGIN
					IF(@StdWashSteps > 0
					   OR @StdWashSteps <> NULL)
						   INSERT INTO TCD.BatchParameters
						   (
								BatchId,
								EcolabWasherId,
								ParameterId,
								ParameterValue,
								PartitionOn
						   )
						   SELECT
								@BatchID,
							 @EcoLabWasherID,
								38,
								@StdWashSteps,
							 @ShiftStartdate;
					    END;
		   END;
	    ELSE
					    BEGIN
			  UPDATE tcd.BatchData
			    SET
				   EndDate = @EndDateTime,
				   ShiftId = @ShiftID,
				   EndDateFormula = @EndDateTime,
				   ProgramNumber = @ProgramNumber,
				   ProgramMasterId = @ProgramMasterID,
				   ActualWeight = @Load,
				   SyncReady = 1
			  WHERE
				   BatchID = @BatchID;
					    END;
		      --If the received formula is not configured in enVision then create an alarm 
       IF(@ProgramMasterId is NULL)
					    BEGIN
       SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant;
       SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.AlarmGroupMsterVsControllerModelType AGMVCMT
       INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
       WHERE AGMVCMT.AlarmCode = 9000
        INSERT INTO [TCD].[AlarmData] 
           (EcoalabAccountNumber,
           AlarmCode,
           BatchId,
           controllerID,
           StartDate,
           GroupId,
           MachineInternalId,
           ProgramId,   
           IsActive,
           EndDate,
           MachineId,
           AlarmGroupMasterId)
           SELECT
            @ECOLABAccountNumber,
            9000,
            @BatchID,
            @ControllerId,
            @StartDateTime,
            @WasherGroupID,
            @MachineNumber,
            @ProgramNumber,
            0,
            @StartDateTime,
            @WasherId,
            @AlarmGroupMasterId
       END





						   IF NOT EXISTS
						   (
							  SELECT
								    1
		   FROM [TCD].[BatchCustomerData]
		   WHERE BatchID = @BatchId
			    AND @CustomerNumber IS NOT NULL
						   )
							  BEGIN
			  INSERT INTO [TCD].[BatchCustomerData]
								 (
				    [BatchId],
									   CustomerID,
				    [Weight],
									   PartitionOn,
									   EcolabWasherId
								 )
			  VALUES
			  (
									   @BatchID,
									   @CustomerNumber,
									   @Load,
				    @ShiftStartdate,
				    @EcolabWasherID
			  );
							  END;
	    ELSE
	    IF(@CustomerNumber > 0)
		   BEGIN
			  UPDATE [TCD].[BatchCustomerData]
			    SET
				   CustomerID = @CustomerNumber,
				   [Weight] = @Load
			  WHERE
				   BatchID = @BatchId;
					    END;
	    CREATE TABLE #Dosing
			  (
		    equipmentNo INT,
		    StepNo      INT,
		    Qty         DECIMAL(10, 6)
	    );
	    INSERT INTO #Dosing
				 SELECT
			 T.c.value('@Equipment', 'INT'),
			 T.c.value('@stepNo', 'INT'),
			 T.c.value('@Qty', 'Decimal(10,6)')
	    FROM @VxML.nodes('MyControlConventionalData/DosingData/Dosing') T
	    (C)
	    WHERE T.c.value('@Qty', 'Decimal(10,6)') > 0;
	    CREATE TABLE #StepTime
					(
		    Number    INT,
		    [Time]    INT,
		    StartTime DATETIME,
		    EndTime   DATETIME
	    );
	    INSERT INTO #StepTime
	    (
			 Number,
			 [Time]
					)
					SELECT
			 T.c.value('@Number', 'INT'),
			 T.c.value('@Time', 'INT')
	    FROM @VxML.nodes('MyControlConventionalData/StepTime/Step') T(C);
	    CREATE TABLE #TimeStamp
			  (
		    Step_Number INT,
		    Time_Stamp  INT
			  );
	
	    --For Calculating TIME_STAMP

	    WITH TempTable
		    AS (SELECT DISTINCT
					Number
			   FROM #StepTime)
		    INSERT INTO #TimeStamp
			  (
				 Step_Number,
				 Time_Stamp
			  )
			  SELECT
				 b.Number,
				 SUM(t.Time) Time_Stamp
		    FROM TempTable b
			    INNER JOIN #StepTime t ON b.Number >= t.Number
					 GROUP BY
				   b.Number;
	    CREATE TABLE #BatchProductData
				  (
		    equipmentNo INT,
		    StepNo      INT,
		    Qty         DECIMAL(10, 6),
		    Time_Stamp  DATETIME2(7),
		    ProductId   INT,
		    Row_No      INT
				  );
	    INSERT INTO #BatchProductData
	    (
			 EquipmentNo,
			 StepNo,
			 Qty,
			 Time_Stamp,
			 ProductId,
			 Row_No
												)
	    SELECT
			 d.equipmentNo,
			 d.StepNo,
			 d.Qty,
			 DATEADD(ss, ts.Time_Stamp, @StartDateTime),
			 ces.ProductId,
			 ROW_NUMBER() OVER(ORDER BY d.StepNo DESC) AS Row
	    FROM #Dosing d
		    INNER JOIN #TimeStamp ts ON d.StepNo = ts.Step_Number
		    INNER JOIN tcd.ControllerEquipmentSetup ces ON ces.
		    ControllerEquipmentId = d.equipmentNo
	    WHERE d.equipmentNo > 0
			AND d.Qty > 0
			AND ControllerID = @ControllerID
			AND ces.ProductId IS NOT NULL;
	    SELECT
			 @MaxWashertGroupCapacity = MAX(ws.MaxLoad)
	    FROM TCD.Washer WS
		    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.
		    GroupId
	    WHERE Mst.GroupId = @WasherGroupID;
	    DECLARE @Counter INT;
	    SET @counter = 1;
	    WHILE(@counter <=
		    (
			   SELECT
					COUNT(ROW_No)
			   FROM #BatchProductData bpd
		    ))
		   BEGIN
			  SELECT
				    @stepno = bpd.StepNo,
				    @quantity = bpd.Qty,
				    @productid = bpd.ProductId,
				    @timestamp = bpd.Time_Stamp
			  FROM #BatchProductData bpd
			  WHERE bpd.Row_No = @counter
			  ORDER BY
					 bpd.StepNo;
			  SELECT
				    @InjectionNumber = Wdpm.InjectionNumber,
				    @standardqty = ((@NominalLoad / CONVERT( DECIMAL(
				    10, 2), 100)) * Wdpm.Quantity * Ws.MaxLoad) /
				    CONVERT(DECIMAL(10, 2), 100),
				    @price = ((@NominalLoad / CONVERT(       DECIMAL(
				    10, 2), 100)) * Wdpm.Quantity *
				    @MaxWashertGroupCapacity) / CONVERT(DECIMAL(10, 2),
				    100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID)
			  FROM TCD.Washer WS
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws
				  .WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =
				  Mst.GroupId
				  INNER JOIN TCD.WasherGroupType WgT ON WgT.
				  WasherGroupTypeId = Wg.WasherGroupTypeId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.
				  ControllerID = Wg.ControllerId
				  INNER JOIN TCD.WasherDosingSetup Wds ON Wds.
				  WasherProgramSetupId = Wps.WasherProgramSetupId
				  INNER JOIN TCD.WasherDosingProductMapping Wdpm ON
				  Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
				  INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.
				  ProductId = Wdpm.ProductId
				  INNER JOIN TCD.BatchData Bd ON Bd.MachineId = Ws.
				  WasherId
			  WHERE Ws.WasherId = @WasherID
				   AND Wps.ProgramNumber = @ProgramNumber
				   --AND Wdpm.InjectionNumber = @stepno
				   AND Bd.BatchId = @BatchID
				   AND Wps.Is_Deleted = 0
				   AND Pdm.Is_Deleted = 0;
			  INSERT INTO TCD.BatchProductData
			  (
				    BatchId,
				    StepCompartment,
							 ActualQuantity,
				    StandardQuantity,
				    Price,
				    PartitionOn,
				    EcolabWasherId,
				    ProductId,
							 TimeStamp,
				    InjectionNumber
						) 
						VALUES
						(
				    @BatchID,
				    @stepno,
				    @quantity,
				    ISNULL(@standardqty,0),
				    ISNULL(@price,0),
				    @ShiftStartdate,
				    @EcolabWasherId,
				    @productid,
				    @timestamp,
				    @InjectionNumber
						 );
			  SET @counter = @counter + 1;
				 END;
	    --END For calculating TIMESTAMP
	    --Start Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
		  SELECT
			 @ActualInjSteps = COUNT(DISTINCT StepNo)
	    FROM #Dosing 
		Where StepNo > 0 ;
			  IF NOT EXISTS
			  (
				 SELECT
					   *
		   FROM TCD.BatchParameters
		   WHERE ParameterId = 37
			    AND batchid = @BatchID
			    AND @ActualInjSteps > 0
			  )
				 BEGIN
			  IF(@ActualInjSteps > 0
				OR @ActualInjSteps IS NOT NULL)
				 INSERT INTO TCD.BatchParameters
					(
					   BatchId,
					   EcolabWasherId,
						  ParameterId,
						  ParameterValue,
					   PartitionOn
 )  
    SELECT
					   @BatchId,
					   @EcolabWasherId,
					   37,
					   @ActualInjSteps,
					   @ShiftStartDate;
    END;
ELSE
BEGIN
			  UPDATE TCD.BatchParameters
			    SET
				   ParameterValue = @ActualInjSteps
			  WHERE
				   ParameterId = 37
				   AND batchid = @BatchID;
		   END;
	    SELECT
			 @LastStep = MAX([Number])
	    FROM #StepTime
	    WHERE [Time] > 0;
	    SELECT
			 @CurrentStep = 1,
			 @CurrentStepTime = @StartDateTime;
	    WHILE(@CurrentStep <= @LastStep)
BEGIN
			  UPDATE #StepTime
			    SET
				   StartTime = @CurrentStepTime,
				   EndTime = DATEADD(ss, [time], @CurrentStepTime)
			  WHERE
				   Number = @CurrentStep;
SELECT 
				    @CurrentStepTime = EndTime
			  FROM #StepTime
			  WHERE Number = @CurrentStep;
SELECT 
				    @CurrentStep = @CurrentStep + 1;
		   END;
	    INSERT INTO [TCD].[BatchWashStepData]
(
			 BatchID,
			 StepCompartment,
			 StartTime,
			 EndTime,
						  PartitionOn,
						  EcolabWasherId
					)
					SELECT
			 @BatchID,
			 Number,
			 StartTime,
			 EndTime,
			 @ShiftStartdate,
			 @EcoLabWasherID
	    FROM #StepTime
	    WHERE Number <= @LastStep;
					SELECT
			 @MinTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Mimum Temperature';
SELECT 
			 @MaxTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Maximum Temperature';
SELECT 
			 @MaxTempStatusParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Max Temperature Status';
SELECT		
			 @MinTempStatuParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Minimum Temperature Status';
SELECT		
			 @PHValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH';
	    SELECT
			 @PHStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH Status';
	    IF NOT EXISTS
			  (
					SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MinTempParamID
       )  
BEGIN  
			  IF(@TemperatureMin <> 0
				OR @TemperatureMin <> NULL)
BEGIN
					INSERT INTO TCD.BatchParameters
			  (
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
			  )
					VALUES
			  (
						  @BatchID,
						  @EcoLabWasherID,
						  @MinTempParamID,
						  @TemperatureMin,
						  @ShiftStartdate
			  );
				 END;
		   END;
	    IF NOT EXISTS
			  (
			  SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MaxTempParamID
			  )
 BEGIN 
			  IF(@TemperatureMax <> 0
				OR @TemperatureMax <> NULL)
  BEGIN
					INSERT INTO TCD.BatchParameters
				  (
							   BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
    )
					VALUES
				  (
						  @BatchID,
						  @EcoLabWasherID,
						  @MaxTempParamID,
						  @TemperatureMax,
						  @ShiftStartdate
				  );
				 END;
		   END;
	    IF NOT EXISTS
		    (
			   SELECT
					*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MaxTempStatusParamID
    )
  BEGIN
			  IF(@TempMaxStatus <> 0
				OR @TempMaxStatus <> NULL)
  BEGIN
					INSERT INTO TCD.BatchParameters
    (
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
						) 
						VALUES
						(
						  @BatchID,
						  @EcoLabWasherID,
						  @MaxTempStatusParamID,
						  @TempMaxStatus,
						  @ShiftStartdate
						 );
				 END;
	END;
	GO



---------------------------------End Tunnle online, production and Getbatchsummarized proc's change-------------------
IF EXISTS (SELECT * 
           FROM   sys.objects 
           WHERE  object_id = Object_id(N'[TCD].[GetPlantMeterDetailsByMeterId]' 
                              ) 
                  AND type IN ( N'P', N'PC' )) 
BEGIN
      DROP PROCEDURE [TCD].[GetPlantMeterDetailsByMeterId] 
END

GO

CREATE PROCEDURE [TCD].[GetPlantMeterDetailsByMeterId] 
  -- Add the parameters for the stored procedure here 
  @MeterId             INT = NULL, 
  @EcolabAccountNumber NVARCHAR(25) 
AS   
BEGIN   
      -- SET NOCOUNT ON added to prevent extra result sets from 
      -- interfering with SELECT statements. 
      SET NOCOUNT ON; 

      SELECT M.MeterId                         AS MeterId, 
             M.[Description]                   AS [Description], 
             M.UtilityType                     AS MeterType, 
             M.GroupId                         AS GroupId, 
             M.EcolabAccountNumber             AS EcolabAccountNumber, 
             M.MaxValueLimit                   AS MaxValueLimit, 
             M.MeterTickUnit                   AS MeterTickUnit, 
             M.UsageFactor                     AS UsageFactor, 
             M.ControllerID                    AS ControllerId, 
             M.Parent                          AS ParentId, 
             M.Calibration                     AS Calibration, 
             M.DigitalInputNumber              AS DigitalInputNumber, 
             M.AllowManualentry                AS AllowManualEntry, 
             M.Is_deleted                      AS IsDeleted, 
             M.MachineCompartment              AS MachineId, 
             M.Id                              AS Id, 
             M.LastModifiedByUserId            AS LastModifiedByUserId, 
             M.LastSyncTime                    AS LastSyncTime, 
             M.IsPlant                         AS IsPlant, 
             M.IsPress                         AS IsPress, 
             M.LastModifiedTime                AS LastModifiedTime, 
             M.CounterAlarmValue, 
             M.WaterType, 
             M.WaterTypeFromFormulaSetup, 
             M.RunningTimeAlarmValue, 
             Cast(ISNULL(csd.Value, 0) AS BIT) AS ISWaterEnergyLogSel, 
             M.DigitalInputNumber, 
             M.CounterUsage, 
             M.RunningTimeUsage, 
             M.CounterNum, 
             wg.WasherGroupTypeId, 
             ms.MachineInternalId              AS LfsWasherNumber 
      FROM   TCD.Meter M 
             LEFT JOIN TCD.ControllerSetupData csd 
                    ON csd.ControllerId = M.ControllerID 
                       AND csd.FieldId = 473 
                       AND csd.FieldGroupId = 20 
                       AND csd.EcolabAccountNumber = M.EcolabAccountNumber 
             INNER JOIN tcd.WasherGroup wg 
                     ON wg.WasherGroupId = M.GroupId 
                        AND wg.EcolabAccountNumber = M.EcolabAccountNumber 
             INNER JOIN tcd.MachineSetup ms 
                     ON ms.GroupId = M.GroupId 
                        AND ms.EcoalabAccountNumber = M.EcolabAccountNumber 
                        AND ( CASE wg.WasherGroupTypeId 
                                WHEN 1 THEN ms.WasherId 
                                ELSE 1 
                              END = CASE wg.WasherGroupTypeId 
                                      WHEN 1 THEN M.MachineCompartment 
                                      ELSE 1 
                                    END ) 
      WHERE  M.MeterId = ISNULL(@MeterId, M.MeterId) 
             AND M.EcolabAccountNumber = @EcolabAccountNumber 
    END

GO 
	    
IF EXISTS (SELECT * 
           FROM   sys.objects 
           WHERE  object_id = 
                  Object_id(N'[TCD].[GetPlantSensorDetailsBySensorId]') 
                  AND type IN ( N'P', N'PC' )) 
    BEGIN
      DROP PROCEDURE [TCD].[GetPlantSensorDetailsBySensorId] 
    END

GO 

CREATE PROCEDURE [TCD].[GetPlantSensorDetailsBySensorId] 
  -- Add the parameters for the stored procedure here 
  @SensorId            INT = NULL, 
  @EcolabAccountNumber NVARCHAR(25) 
AS 
  BEGIN 
      -- SET NOCOUNT ON added to prevent extra result sets from 
      -- interfering with SELECT statements. 
      SET NOCOUNT ON; 

      SELECT TOP 1 S.SensorId                        AS SensorId, 
                   S.[Description]                   AS [Description], 
                   S.SensorType                      AS SensorType, 
                   S.GroupId                         AS GroupId, 
                   S.MachineCompartment              AS MachineCompartment, 
                   S.EcolabAccountNumber             AS EcolabAccountNumber, 
                   S.ControllerID                    AS ControllerID, 
                   S.OutputType                      AS OutputType, 
                   S.Calibration4mA                  AS Calibration4mA, 
                   S.AnalogueInputNumber             AS AnalogueInputNumber, 
                   S.ChemicalforChart                AS ChemicalforChart, 
                   S.UOM                             AS UOM, 
                   S.DashboardActualValue            AS DashboardActualValue, 
                   S.Is_deleted                      AS Is_deleted, 
                   S.Id                              AS Id, 
                   S.LastModifiedByUserId            AS LastModifiedByUserId, 
                   S.IsPlant                         AS IsPlant, 
                   S.IsPress                         AS IsPress, 
                   S.Calibration20mA                 AS Calibration20mA, 
                   S.LastSyncTime                    AS LastSyncTime, 
                   S.LastModifiedTime                AS LastModifiedTime, 
                   s.SensorNum, 
                   s.AlarmEnable, 
                   s.MinimumAlarmValue, 
                   s.MaximumAlarmValue, 
                   s.AnalogueInputNumber, 
                   Cast(ISNULL(csd.Value, 0) AS BIT) AS ISWaterEnergyLogSel, 
                   wg.WasherGroupTypeId, 
                   ms.MachineInternalId              AS LfsWasherNumber, 
                   ces.ControllerEquipmentId         AS PumpNumber 
      FROM   TCD.Sensor S 
             LEFT JOIN TCD.ControllerSetupData csd 
                    ON csd.ControllerId = S.ControllerID 
                       AND csd.FieldId = 473 
                       AND csd.FieldGroupId = 20 
                       AND csd.EcolabAccountNumber = S.EcolabAccountNumber 
             INNER JOIN tcd.WasherGroup wg 
                     ON wg.WasherGroupId = S.GroupId 
                        AND wg.EcolabAccountNumber = S.EcolabAccountNumber 
             INNER JOIN tcd.MachineSetup ms 
                     ON ms.GroupId = S.GroupId 
                        AND ms.EcoalabAccountNumber = s.EcolabAccountNumber 
                        AND ( CASE wg.WasherGroupTypeId 
                                WHEN 1 THEN ms.WasherId 
                                ELSE 1 
                              END = CASE wg.WasherGroupTypeId 
                                      WHEN 1 THEN s.MachineCompartment 
                                      ELSE 1 
                                    END ) 
             LEFT JOIN tcd.ControllerEquipmentSetup ces 
                    ON ces.ControllerId = s.ControllerID 
                       AND ces.ProductId = s.ChemicalforChart 
                       AND ces.EcoLabAccountNumber = s.EcolabAccountNumber 
      WHERE  S.SensorId = ISNULL(@SensorId, S.SensorId) 
             AND S.EcolabAccountNumber = @EcolabAccountNumber 
      ORDER  BY ces.ControllerEquipmentId 
			END
	
GO 

IF EXISTS (SELECT * 
           FROM   sys.objects 
           WHERE  object_id = Object_id(N'[TCD].[GetChemicalsForChart]' 
                              ) 
                  AND type IN ( N'P', N'PC' )) 
  BEGIN 
      DROP PROCEDURE [TCD].[GetChemicalsForChart] 
  END 

GO

CREATE PROCEDURE [TCD].[GetChemicalsForChart] (@GroupId             INT = NULL, 
                                               @MachineId           INT = NULL, 
                                               @ControllerId        INT = NULL, 
                                               @EcolabAccountNumber VARCHAR(1000 
)) 
AS 
  BEGIN 
      SET NOCOUNT ON; 

      DECLARE @IStunnel BIT = (SELECT DISTINCT Istunnel 
         FROM   TCD.machinesetup MS 
         WHERE  Ms.GroupId = @GroupId 
                AND EcoalabAccountNumber = @EcolabAccountNumber 
                AND MS.IsDeleted = 0); 

      IF @ControllerId IS NULL 
        BEGIN 
            SELECT TOP (1) @ControllerId = ControllerID 
            FROM   TCD.ConduitController 
            WHERE  ControllerModelId = 5 
                   AND EcoalabAccountNumber = @EcolabAccountNumber 
                   AND TCD.ConduitController.IsDeleted = 0; 
        END; 

      IF @IStunnel = 'TRUE' 
        BEGIN 
            SELECT DISTINCT PM.ProductId, 
                            CASE 
                              WHEN PM.EnvisionDisplayName IS NULL THEN PM.NAME 
                              ELSE PM.EnvisionDisplayName 
                            END as NAME 
            FROM   TCD.MachineSetup MS 
                   INNER JOIN TCD.TunnelCompartment TC 
                           ON TC.WasherId = MS.WasherId 
                   INNER JOIN TCD.ConduitController CC 
                           ON CC.ControllerId = MS.ControllerId 
                   INNER JOIN TCD.TunnelCompartmentEquipmentMapping TCEM 
                           ON TCEM.TunnelCompartmentId = TC.TunnelCompartmentId 
                   INNER JOIN TCD.ControllerEquipmentSetup CES 
                           ON CES.ControllerEquipmentSetupId = 
                              TCEM.ControllerEquipmentSetupId 
                   INNER JOIN TCD.ProductdataMapping PDM 
                           ON PDM.ProductID = CES.ProductId 
                   INNER JOIN TCD.ProductMaster PM 
                           ON PM.ProductId = PDM.ProductID 
            WHERE  MS.IsDeleted = 0 
                   AND CC.IsDeleted = 0 
                   AND TCEM.Is_Deleted = 0 
                   AND CES.IsActive = 1 
                   AND PDM.Is_Deleted = 0 
                   AND MS.EcoalabAccountNumber = @EcolabAccountNumber 
                   AND TC.EcoLabAccountNumber = @EcolabAccountNumber 
                   AND CC.EcoalabAccountNumber = @EcolabAccountNumber 
                   AND TCEM.EcoLabAccountNumber = @EcolabAccountNumber 
                   AND CES.EcoLabAccountNumber = @EcolabAccountNumber 
                   AND PDM.EcolabAccountNumber = @EcolabAccountNumber 
                   AND ( MS.GroupId = @GroupId 
                          OR @GroupId IS NULL 
                          OR @GroupId = 1 ) 
                   AND ( TC.CompartmentNumber = @MachineId
                          OR @MachineId IS NULL 
                          OR @MachineId = 0 ) 
                   AND CC.ControllerId = @ControllerId; 
        END; 
      ELSE 
        BEGIN 
            SELECT DISTINCT pm.ProductId, 
                            CASE 
                              WHEN PM.EnvisionDisplayName IS NULL THEN PM.NAME 
                              ELSE PM.EnvisionDisplayName 
                            END as NAME 
            FROM   TCD.Washer WS 
                   INNER JOIN TCD.MachineSetup Mst 
                           ON Mst.WasherId = ws.WasherId 
                   INNER JOIN TCD.WasherGroup Wg 
                           ON Wg.WasherGroupId = Mst.GroupId 
                   INNER JOIN TCD.WasherProgramSetup Wps 
                           ON Wps.WasherGroupId = Wg.WasherGroupId 
                   INNER JOIN TCD.WasherDosingSetup Wds 
                           ON Wds.WasherProgramSetupId = 
                              Wps.WasherProgramSetupId 
                   INNER JOIN TCD.WasherDosingProductMapping Wdpm 
                           ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID 
                   INNER JOIN TCD.ConduitController CC 
                           ON CC.ControllerId = Mst.ControllerId 
                   INNER JOIN TCD.ProductdataMapping PDM 
                           ON PDM.ProductID = WDPM.ProductId 
                   INNER JOIN TCD.ProductMaster pm 
                           ON pm.ProductId = Wdpm.ProductId 
            WHERE  WS.Is_Deleted = 0 
                   AND Mst.IsDeleted = 0 
                   AND Wds.Is_Deleted = 0 
                   AND PDM.Is_Deleted = 0 
                   AND pm.Is_Deleted = 0 
                   AND CC.IsDeleted = 0 
                   AND Wdpm.IsDeleted = 0 
                   AND WS.EcoLabAccountNumber = @EcolabAccountNumber 
                   AND Wg.EcolabAccountNumber = @EcolabAccountNumber 
                   AND Wps.EcolabAccountNumber = @EcolabAccountNumber 
                   AND Wds.EcoLabAccountNumber = @EcolabAccountNumber 
                   AND Wdpm.EcoLabAccountNumber = @EcolabAccountNumber 
                   AND PDM.EcolabAccountNumber = @EcolabAccountNumber 
                   AND ( MST.GroupId = @GroupId 
                          OR @GroupId IS NULL 
                          OR @GroupId = 1 ) 
                   AND ( mst.WasherId = @MachineId 
                          OR @MachineId IS NULL 
                          OR @MachineId = 0 ) 
                   AND CC.ControllerId = @ControllerId; 
        END; 

      SET NOCOUNT OFF; 
  END; 

GO

		
---Chemical Consumption Report SP -  UOM column---

IF  EXISTS (SELECT
			*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MinTempStatuParamID
     )
		BEGIN
			  IF(@TempMinStatus <> 0
				OR @TempMinStatus <> NULL)
		BEGIN
					INSERT INTO TCD.BatchParameters
	(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
	)
					VALUES
(
						  @BatchID,
						  @EcoLabWasherID,
						  @MinTempStatuParamID,
						  @TempMinStatus,
						  @ShiftStartdate
					);
				 END;
    END;
	    IF(@PHStatus <> 0
		  OR @PHStatus <> NULL)
BEGIN   
			  INSERT INTO TCD.BatchParameters
        (  
				    BatchId,
				    EcolabWasherId,
				    ParameterId,
				    ParameterValue,
				    PartitionOn
 )  
			  VALUES
(
				    @BatchID,
				    @EcoLabWasherID,
				    @PHStatusParamID,
				    @PHStatus,
				    @ShiftStartdate
			  );
    END;
	    IF(@PHValue <> 0
		  OR @PHValue <> NULL)
BEGIN
			  INSERT INTO TCD.BatchParameters
(
				    BatchId,
				    EcolabWasherId,
				    ParameterId,
				    ParameterValue,
				    PartitionOn
)
			  VALUES
				    (
				    @BatchID,
				    @EcoLabWasherID,
				    @PHValueParamID,
				    @PHValue,
				    @ShiftStartdate
			  );
		   END;
	    EXEC TCD.ProcessMyControlProductionWaterConsumptionData
		    @BatchID,
		    @VxML,
		    @ShiftStartDate;
	    DROP TABLE #BatchProductData;
	    DROP TABLE #Dosing;
	    DROP TABLE #StepTime;
	    DROP TABLE #TimeStamp;
			
		--Start water consumption per batch

	SELECT @MeterID=MeterId,@StepComportment=MachineCompartment
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@MachineNumber
   AND mt.CounterNum = 1;


   SELECT @EnergyCount=COUNT(1) FROM TCd.BatchStepWaterUsageData bswud WHERE BatchId =@BatchID AND StepCompartment =@StepComportment AND ActualQuantity=@WaterConsumption1
    IF(@EnergyCount=0)
BEGIN
  IF(ISNULL(@WaterConsumption1,0)>0  AND ISNULL(@MeterID,0)>0  AND ISNULL(@StepComportment,0)>0)
		BEGIN
   INSERT INTO TCD.BatchStepWaterUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
	  EcolabWasherId
	)
SELECT 
     @BatchID,
     @StepComportment,
     @WaterConsumption1,
     @ShiftStartdate,
	 @EcoLabWasherID
		END
		END

	 SELECT @MeterID=MeterId,@StepComportment=MachineCompartment
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@MachineNumber
   AND mt.CounterNum = 2;
SELECT @EnergyCount=COUNT(1) FROM TCd.BatchStepWaterUsageData WHERE BatchId =@BatchID AND StepCompartment =@StepComportment AND ActualQuantity=@WaterConsumption2
 IF(@EnergyCount=0)
		BEGIN
  IF(ISNULL(@WaterConsumption2,0)>0  AND ISNULL(@MeterID,0)>0  AND ISNULL(@StepComportment,0)>0)
		BEGIN
   INSERT INTO TCD.BatchStepWaterUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
	  EcolabWasherId
    )
    SELECT 
     @BatchID,
     @StepComportment,
     @WaterConsumption2,
     @ShiftStartdate,
	 @EcoLabWasherID
		END
			 END    
	  --End water consumption per batch
	END;
GO
	------------------------------------End Mycontrol tunnel and conventional production sp changes--------------------------
GO
IF EXISTS(SELECT * FROM SYS.PROCEDURES WHERE NAME = 'ReportChemicalInventoryRollup' AND SCHEMA_ID = SCHEMA_ID('TCD'))
    DROP PROCEDURE [TCD].[ReportChemicalInventoryRollup]
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [TCD].[ReportChemicalInventoryRollup]
AS
BEGIN
/*
======================================================================================
CHANGE ID(TFS)  CHANGED BY CHANGED ON     CHANGE DESCRIPTION
======================================================================================
    PSAJJA    07/09/2015     Scheduled the procedure to run every 15 mins from windows 
            and data get populdated TCD.ChemicalInventoryRollUp table
            to improve ChemicalInventory report performance.
 PSAJJA 10/09/2015 Added AvgDailyNeedsForInventoryPeriod Column
 PSAJJA 10/13/2015 DaysBeforeOutOfStock column changed to Int as per client
======================================================================================
*/
  
    
 SET NOCOUNT ON;
 DECLARE @CurrentYearWorkingDays INT    = NULL
    ,@PreviousYearWorkingDays INT    = NULL
    ,@CurrencyCode   VARCHAR(3)  = NULL

 SELECT @CurrencyCode = p.CurrencyCode
 FROM TCD.Plant p

 SELECT @CurrentYearWorkingDays = COUNT(DISTINCT CAST(PS.StartDateTime AS DATE))
 FROM TCD.ProductionShiftData PS (NOLOCK) 
 WHERE PS.StartDateTime >= DATEADD(yy, DATEDIFF(yy,0,getdate()), 0)
 AND PS.LastSyncTime IS NOT NULL
 AND EXISTS (SELECT 1 FROM [TCD].ShiftProductionDataRollup SPD (NOLOCK)
    WHERE SPD.ShiftId = PS.ShiftId
    )

 SELECT @PreviousYearWorkingDays = COUNT(DISTINCT CAST(PS.StartDateTime AS DATE))
 FROM TCD.ProductionShiftData PS (NOLOCK) 
 WHERE PS.StartDateTime >= DATEADD(YEAR, DATEDIFF(YEAR, 0,DATEADD(YEAR, -1, GETDATE())), 0)
 AND PS.StartDateTime <= DATEADD(MILLISECOND, -3, DATEADD(YEAR, DATEDIFF(YEAR, 0, DATEADD(YEAR, -1, GETDATE())) +1, 0))
 AND PS.LastSyncTime IS NOT NULL
 AND EXISTS (SELECT 1 FROM [TCD].ShiftProductionDataRollup SPD (NOLOCK) 
    WHERE SPD.ShiftId = PS.ShiftId
    )
  
--SELECT @CurrentYearWorkingDays, @PreviousYearWorkingDays


 DECLARE @ChemicalLastInventory TABLE (
   ProductId INT
  ,LastInventoryDate DATETIME
  ,BeforeLastInventoryDate DATETIME
  );
    
CREATE TABLE #InventoryRollUp (
    ProductID INT PRIMARY KEY,
    ChemicalName VARCHAR(512),
    LastInventory DECIMAL(18,2),
    InventoryBasedConsumption DECIMAL(18,2),
    DispencerBasedConsumption DECIMAL(18,2),
    TodayEstimateInventory DECIMAL(18,2),
    AvgDailyNeedsYTD DECIMAL(18,2),
    AvgDailyCostYTD DECIMAL(18,6),
    AvgDailyCostLoadYTD DECIMAL(18,6),
    AvgDailyNeedsLY DECIMAL(18,2),
    DayBeforeOutOfStock INT,
    InventoryDateRange varchar(70),
    UnitSize VARCHAR(10),
    AvgDailyNeedsForInventoryPeriod DECIMAL(18,2)
    );
   
WITH CTE (
   Rownumber
  ,ProductId
  ,InventoryDate
    )
 AS (
  SELECT ROW_NUMBER() OVER (
    PARTITION BY CI.ProductId ORDER BY InventoryDate DESC
	)
   ,CI.ProductId
   ,CI.InventoryDate
  FROM TCD.ChemicalInventory CI (NOLOCK)
  ),
 CTE_INV AS (
 SELECT CT.ProductId
  , MAX(CT.InventoryDate) AS LastInventoryDate
  , MIN(CT.InventoryDate) AS BeforeLastInventoryDate
 FROM CTE CT
 WHERE CT.Rownumber < 3
 GROUP BY CT.ProductId
 )
 INSERT INTO @ChemicalLastInventory
 SELECT DISTINCT CT.productid, Inv.LastInventoryDate, Inv.BeforeLastInventoryDate
 FROM CTE CT
 JOIN CTE_INV Inv ON CT.productid = Inv.Productid
 WHERE CT.Rownumber < 2;
		
    
 WITH CTE_dispencer_estimate_Inventory
AS (
 SELECT SCD.ProductId
    , SUM(CASE WHEN (psd.StartDateTime BETWEEN CLI.BeforeLastInventoryDate AND CLI.LastInventoryDate)
    THEN SCD.ActualConsumption * 0.0078125
      END) AS DispencerBasedConsumption
    , SUM(CASE WHEN (psd.StartDateTime BETWEEN CLI.LastInventoryDate AND GETDATE())
    THEN SCD.ActualConsumption * 0.0078125
      END) AS TodayEstimateInventory
 FROM TCD.ShiftChemicalDataRollup SCD (NOLOCK)
 INNER JOIN TCD.ProductionShiftData psd ON psd.ShiftId = SCD.ShiftId
 INNER JOIN @ChemicalLastInventory CLI ON SCD.ProductId = CLI.ProductId
 WHERE psd.LastSyncTime IS NOT NULL
 GROUP BY SCD.ProductId
),
CTE_YTD
AS (
 SELECT ci.ProductId
 , SUM(CASE WHEN ci.InventoryDate >= DATEADD(yy, DATEDIFF(yy,0,getdate()), 0) 
  THEN ci.UsedQuantity
    ELSE NULL
    END ) AS AvgDailyNeeds
 , NULL AS AvgDailyCost
 --, SUM(CASE WHEN ci.InventoryDate >= DATEADD(yy, DATEDIFF(yy,0,getdate()), 0) 
 -- THEN CASE WHEN ci.UnitSize = 'lbs' THEN (ci.UsedQuantity * 16.00) 
 --   WHEN ci.UnitSize = 'oz'  THEN ci.UsedQuantity 
 --   WHEN ci.UnitSize = 'gal' THEN ci.UsedQuantity * 128.00
 --   ELSE ci.UsedQuantity
 --   END
 --   ELSE NULL
 --   END ) * [TCD].[FnChemicalCostInOunce](ci.ProductId) AS AvgDailyCost
 , SUM(CASE WHEN (ci.InventoryDate >= DATEADD(YEAR, DATEDIFF(YEAR, 0,DATEADD(YEAR, -1, GETDATE())), 0)
    AND ci.InventoryDate <= DATEADD(MILLISECOND, -3, DATEADD(YEAR, DATEDIFF(YEAR, 0, DATEADD(YEAR, -1, GETDATE())) +1, 0)))
  THEN ci.UsedQuantity
    ELSE NULL
    END ) AS AvgDailyNeedsLY
 , SUM(CASE WHEN (ci.InventoryDate >= cli.BeforeLastInventoryDate
    AND ci.InventoryDate <= cli.LastInventoryDate)
  THEN ci.UsedQuantity
    ELSE NULL
    END ) AS AvgDailyNeedsForInventoryPeriod
FROM TCD.ChemicalInventory ci
INNER JOIN tcd.ProductdataMapping pm ON ci.ProductId = pm.ProductID
INNER JOIN @ChemicalLastInventory cli ON cli.ProductId = ci.ProductId
GROUP BY ci.ProductId
)
SELECT   X.ProductId
    , X.DispencerBasedConsumption
    , X.TodayEstimateInventory
    , cy.AvgDailyNeeds
    , cy.AvgDailyCost
    , cy.AvgDailyCost AS AvgDailyCostPerLoad
    , cy.AvgDailyNeedsLY
    , cy.AvgDailyNeedsForInventoryPeriod
INTO #CI_Data
FROM CTE_YTD cy
LEFT JOIN CTE_dispencer_estimate_Inventory X ON X.ProductId = cy.ProductId
    

--select * from #CI_Data
DECLARE @ChemicalInventory TABLE (
  ProductId INT
  ,ChemicalName VARCHAR(1000)
  ,LastInventory DECIMAL(18, 2)
  ,InventoryDate DATETIME
  ,InventoryDateRange VARCHAR(70)
  ,InventorybasedConsumption DECIMAL(18, 2)
  ,DispencerBasedConsumption DECIMAL(18, 2)
  ,TodayEstimateInventory DECIMAL(18, 2)
  ,AvgDailyNeedsYTD DECIMAL(18, 2)
  ,AvgDailyCostYTD DECIMAL(18, 6)
  ,AvgDailyCostloadYTD DECIMAL(18, 6)
  ,AvgDailyNeedsLY DECIMAL(18, 2)
  ,DayBeforeOutOfStock INT
  ,UnitSize varchar(10)
  ,AvgDailyNeedsForInventoryPeriod DECIMAL(18, 2)
  )
    
 INSERT INTO @ChemicalInventory
 SELECT DISTINCT CI.ProductId
  , PM.NAME
  --, COALESCE(pm.EnvisionDisplayName, PM.NAME) 
  , CI.ClosingQuantity AS LastInventory
  , CIL.LastInventoryDate AS InventoryDate
  ,(CONVERT(VARCHAR(25),CIL.BeforeLastInventoryDate, 110) + ' - ' + CONVERT(VARCHAR(25), CIL.LastInventoryDate, 110)) AS inventoryDateRange
  , CI.UsedQuantity AS InventorybasedConsumption
  , CID.DispencerBasedConsumption
  , (CI.ClosingQuantity - CID.TodayEstimateInventory) AS TodayEstimateInventory
  , NULLIF(CID.AvgDailyNeeds,0)/NULLIF(@CurrentYearWorkingDays, 0) AS AvgDailyNeedsYTD
  , NULLIF(@CurrentYearWorkingDays, 0) AS AvgDailyCostYTD
  , (SELECT NULLIF(COUNT(DISTINCT bd.batchid),0) FROM TCD.BatchData bd (NOLOCK)
        INNER JOIN tcd.BatchProductData bpd (NOLOCK) ON bpd.BatchId = bd.BatchId
        WHERE bd.StartDate >= DATEADD( yy,DATEDIFF( yy,0,GETDATE()),0 )
        AND bpd.ProductId = CI.ProductId) AS AvgDailyCostloadYTD
  --, NULLIF(CID.AvgDailyCost,0)/NULLIF(@CurrentYearWorkingDays, 0) AS AvgDailyCostYTD
  --, CID.AvgDailyCostPerLoad / (SELECT NULLIF(COUNT(DISTINCT bd.batchid),0) FROM TCD.BatchData bd (NOLOCK)
  --      INNER JOIN tcd.BatchProductData bpd (NOLOCK) ON bpd.BatchId = bd.BatchId
  --      WHERE bd.StartDate >= DATEADD( yy,DATEDIFF( yy,0,GETDATE()),0 )
  --      AND bpd.ProductId = CI.ProductId) * 100
  --, CID.AvgDailyCostPerLoad / (SELECT NULLIF(SUM(DISTINCT scdr.NoOfLoads),0) FROM TCD.ProductionShiftData psd
  --      INNER JOIN TCD.ShiftChemicalDataRollup scdr ON scdr.ShiftId = psd.ShiftId
  --      WHERE psd.StartDateTime >= DATEADD(yy, DATEDIFF(yy,0,getdate()), 0) 
  --      AND scdr.ProductId = CI.ProductId
  --      ) * 100  
  , NULLIF(CID.AvgDailyNeedsLY,0) / NULLIF(@PreviousYearWorkingDays, 0)
  ,(CI.ClosingQuantity - CID.TodayEstimateInventory) / NULLIF((NULLIF(CID.AvgDailyNeeds,0)/NULLIF(@CurrentYearWorkingDays, 0)), 0)
 , CI.UnitSize
  , NULLIF(CID.AvgDailyNeedsForInventoryPeriod,0) /(SELECT NULLIF(COUNT(DISTINCT CAST(PS.StartDateTime AS DATE)),0)
             FROM TCD.ProductionShiftData PS (NOLOCK) 
             CROSS JOIN @ChemicalLastInventory cli
             WHERE PS.StartDateTime >= cli.BeforeLastInventoryDate
             AND PS.StartDateTime <= cli.LastInventoryDate
             AND cli.ProductId = CIL.ProductId
	     AND PS.LastSyncTime IS NOT NULL
             AND EXISTS (SELECT 1 FROM [TCD].ShiftProductionDataRollup SPD (NOLOCK) 
             WHERE SPD.ShiftId = PS.ShiftId)
             )
 FROM TCD.ChemicalInventory CI (NOLOCK)
 INNER JOIN TCD.ProductdataMapping PDM (NOLOCK) ON CI.ProductId = PDM.ProductID
 INNER JOIN TCD.ProductMaster PM (NOLOCK) ON PM.ProductId = PDM.ProductID
 INNER JOIN @ChemicalLastInventory CIL ON CI.InventoryDate = CIL.LastInventoryDate AND CI.ProductId = CIL.ProductId
 LEFT JOIN #CI_Data CID ON CI.ProductId = CID.ProductId

 INSERT #InventoryRollUp
 (ProductId,ChemicalName,LastInventory,InventorybasedConsumption,DispencerBasedConsumption,TodayEstimateInventory
 ,AvgDailyNeedsYTD,AvgDailyCostYTD,AvgDailyCostloadYTD,AvgDailyNeedsLY,DayBeforeOutOfStock,InventoryDateRange,UnitSize
 ,AvgDailyNeedsForInventoryPeriod)
 SELECT CI.ProductId
  ,CI.ChemicalName
  ,CI.LastInventory
  ,CI.InventorybasedConsumption
  ,CI.DispencerBasedConsumption
  ,CI.TodayEstimateInventory
  ,CI.AvgDailyNeedsYTD
  ,CI.AvgDailyCostYTD
  ,CI.AvgDailyCostloadYTD
  ,CI.AvgDailyNeedsLY
  ,CI.DayBeforeOutOfStock
  ,CI.InventoryDateRange
  ,CI.UnitSize
  ,CI.AvgDailyNeedsForInventoryPeriod
 FROM @ChemicalInventory CI
    
    UPDATE [Target]
    SET  [Target].ChemicalName = [Source].ChemicalName
    ,[Target].LastInventory = [Source].LastInventory 
    ,[Target].InventorybasedConsumption = [Source].InventorybasedConsumption
    ,[Target].DispencerBasedConsumption = [Source].DispencerBasedConsumption
    ,[Target].TodayEstimateInventory = [Source].TodayEstimateInventory
    ,[Target].AvgDailyNeedsYTD = [Source].AvgDailyNeedsYTD
    ,[Target].AvgDailyCostYTD = [Source].AvgDailyCostYTD
    ,[Target].AvgDailyCostloadYTD = [Source].AvgDailyCostloadYTD
    ,[Target].AvgDailyNeedsLY = [Source].AvgDailyNeedsLY
    ,[Target].DayBeforeOutOfStock = [Source].DayBeforeOutOfStock
    ,[Target].InventoryDateRange = [Source].InventoryDateRange
    ,[Target].UnitSize = [Source].UnitSize
    ,[Target].AvgDailyNeedsForInventoryPeriod = [Source].AvgDailyNeedsForInventoryPeriod
    FROM TCD.ChemicalInventoryRollUp AS [Target]
    JOIN #InventoryRollUp AS [Source]
    ON [Target].ProductID = [Source].ProductID
		

    INSERT TCD.ChemicalInventoryRollUp
    (ProductId,ChemicalName,LastInventory,InventorybasedConsumption,DispencerBasedConsumption,TodayEstimateInventory
     ,AvgDailyNeedsYTD,AvgDailyCostYTD,AvgDailyCostloadYTD,AvgDailyNeedsLY,DayBeforeOutOfStock,InventoryDateRange,UnitSize
     ,AvgDailyNeedsForInventoryPeriod)
    SELECT [Source].ProductId, [Source].ChemicalName,[Source].LastInventory,[Source].InventorybasedConsumption
     ,[Source].DispencerBasedConsumption,[Source].TodayEstimateInventory,[Source].AvgDailyNeedsYTD,[Source].AvgDailyCostYTD
     ,[Source].AvgDailyCostloadYTD,[Source].AvgDailyNeedsLY,[Source].DayBeforeOutOfStock,[Source].InventoryDateRange, [Source].UnitSize
     ,[Source].AvgDailyNeedsForInventoryPeriod
    FROM #InventoryRollUp AS [Source]
    LEFT OUTER JOIN TCD.ChemicalInventoryRollUp AS [Target] (NOLOCK)
    ON [Target].ProductID = [Source].ProductID
    WHERE [Target].ProductID IS NULL


-- CleanUp
DROP TABLE #InventoryRollUp
DROP TABLE #CI_Data

END
GO

   
IF EXISTS(SELECT * FROM SYS.PROCEDURES WHERE NAME = 'ReportChemicalInventory' AND SCHEMA_ID = SCHEMA_ID('TCD'))
    DROP PROCEDURE [TCD].[ReportChemicalInventory]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
  
CREATE PROCEDURE [TCD].[ReportChemicalInventory] (
  @EcolabAccountNumber NVARCHAR(25) = NULL
 ,@UserId INT = NULL
 ,@ReportID INT = NULL
 )
AS   
BEGIN   
 SET NOCOUNT ON;
  
 DECLARE @ReportGenerated INT = 6,
	 @UserCurrency NCHAR(3),
	 @BatchCurrency NCHAR(3)
  
 /* Inserting the record into Report History */
 INSERT INTO TCD.ReportHistory (
   EcolabAccountNumber
  ,UserId
  ,UserName
  ,DateAndTime
  ,ActionTypeId
  ,ActionDescription
        )  
 SELECT @EcolabAccountNumber
  ,UM.UserId
  ,UM.LoginName
  ,GETUTCDATE()
  ,@ReportGenerated
  ,CASE 
   WHEN @ReportGenerated = 6
    THEN 'Generated Report : ChemicalInventoryReport'
   END
 FROM TCD.UserMaster UM (NOLOCK)
 WHERE UM.EcolabAccountNumber = @EcolabAccountNumber
  AND UM.UserId = @UserId
          
SELECT @UserCurrency = um.CurrencyCode 
FROM TCD.UserMaster um 
WHERE um.UserId = @UserId
  
SELECT @BatchCurrency = (SELECT TOP 1 bd.CurrencyCode FROM TCD.BatchData bd);
  
WITH CTE_CostConversion (ProductID, AvgDailyCost, CurrentYearWorkingDays,CurrentYearNoOfLoads)
AS (
 SELECT   CIR.[ProductID]
  , SUM(CASE WHEN ci.InventoryDate >= DATEADD(yy, DATEDIFF(yy,0,getdate()), 0) 
	      THEN (CASE WHEN ci.UnitSize = 'lbs' THEN (ci.UsedQuantity * 16.00) 
			WHEN ci.UnitSize = 'oz'  THEN ci.UsedQuantity 
			WHEN ci.UnitSize = 'gal' THEN ci.UsedQuantity * 128.00
			ELSE ci.UsedQuantity
		    END  * [TCD].[FnChemicalCostInOunce](ci.ProductId)
        )  
		    * (CASE 
			   WHEN @BatchCurrency = @UserCurrency 
			     THEN 1
			   WHEN @BatchCurrency <> @UserCurrency 
			     THEN TCD.FnCurrencyExchangeRate(@UserCurrency,ci.InventoryDate)
		END) 
	ELSE NULL
	END )  AS AvgDailyCost
     ,MAX(CIR.[AvgDailyCostYTD]) As CurrentYearWorkingDays
     ,MAX(CIR.[AvgDailyCostLoadYTD]) AS CurrentYearNoOfLoads
 FROM [TCD].[ChemicalInventoryRollUp] AS CIR
 INNER JOIN TCD.ChemicalInventory AS CI (NOLOCK) ON CIR.ProductID = CI.ProductId
 INNER JOIN TCD.ProductdataMapping PDM (NOLOCK) ON CI.ProductId = PDM.ProductID
 GROUP BY CIR.[ProductID]
)
   
 SELECT   CIR.[ProductID]
     ,CIR.[ChemicalName]
     ,CIR.[InventoryDateRange]
     ,CIR.[LastInventory]
     ,CIR.[InventoryBasedConsumption]
     ,CIR.[DispencerBasedConsumption]
     ,CIR.[TodayEstimateInventory]
     ,CIR.[AvgDailyNeedsYTD]
     , (CC.AvgDailyCost / NULLIF(CC.CurrentYearWorkingDays, 0)) AS AvgDailyCostYTD
     , ((CC.AvgDailyCost / CC.CurrentYearNoOfLoads) * 100) AS [AvgDailyCostLoadYTD]
     ,CIR.[AvgDailyNeedsLY]
     ,CIR.[DayBeforeOutOfStock]
     ,CIR.[UnitSize]
     ,CIR.[AvgDailyNeedsForInventoryPeriod]
 FROM [TCD].[ChemicalInventoryRollUp] AS CIR
 INNER JOIN CTE_CostConversion AS CC ON CC.ProductID = CIR.ProductID
  
     END  
GO
  
  
IF  EXISTS (SELECT * FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[TCD].[SaveUserDetails]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[SaveUserDetails]
     END    
GO

CREATE PROCEDURE [TCD].[SaveUserDetails] (
  
@ContactId									INT
,@FirstName									NVARCHAR(100)
,@LastName									NVARCHAR(100)
,@LoginName									NVARCHAR(100)
,@Password									NVARCHAR(100)
,@MailId									NVARCHAR(100)			= NULL
,@ContactNo									NVARCHAR(100)			= NULL
,@RoleId									INT
,@UserId									INT
,@EcolabAccountNumber						NVARCHAR(1000)
,@CurrencyCode								NVARCHAR(100)
,@UOMID										INT
,@Scope										VARCHAR(100)						OUTPUT
,@OutputUserId								INT						=	NULL	OUTPUT
,@LastModifiedTimestampAtCentral			DATETIME				=	NULL
,@OutputLastModifiedTimestampAtLocal		DATETIME				=	NULL	OUTPUT
                )  

AS
BEGIN
    SET NOCOUNT ON;
	DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()
  
	DECLARE
			@OutputList						AS	TABLE		(
			UserId							INT
		,	LastModifiedTimestamp			DATETIME
															    )
    DECLARE
	    @OUTput VARCHAR(100) = '';
  
SET		@Scope										=			ISNULL(@Scope, NULL)										--SQLEnlight SA0121
SET		@OutputLastModifiedTimestampAtLocal			=			ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight
SET		@OutputUserId								=			ISNULL(@OutputUserId, NULL)									--SQLEnlight
SET		@LastModifiedTimestampAtCentral				=			ISNULL(@LastModifiedTimestampAtCentral, NULL)				--SQLEnlight SA0029
   
SELECT	@UOMID = UOMId FROM TCD.Plant WHERE	TCD.Plant.EcolabAccountNumber	=	@EcolabAccountNumber	
  
SELECT	@CurrencyCode	=  CurrencyCode FROM TCD.Plant  WHERE	EcolabAccountNumber	=	@EcolabAccountNumber	
  
    IF @ContactId IS NOT NULL
					AND 
					EXISTS(SELECT 1
							 FROM TCD.UserMaster
							 WHERE ContactId = @ContactId
							   AND IsActive = 1
)
    BEGIN
		  SET @OutPut = '302';
		  SET @Scope = @OutPut;
		  SELECT @Scope;
    END;

    ELSE
BEGIN
		  IF EXISTS (SELECT 1
					FROM TCD.UserMaster
					WHERE LoginName = @LoginName
					  AND IsActive = 1)

			 BEGIN
				BEGIN
					 SET @OutPut = '301';
					 SET @Scope = @OutPut;
					 SELECT @Scope;
				END;
			 END;
			   IF EXISTS (SELECT 1 FROM TCD.UserMaster WHERE Email = @MailId AND ISACTIVE=1)
				  BEGIN
					BEGIN Set @OutPut = '501'   
					SET @Scope = @OutPut 
					Select @Scope  
					END
				 END
		  ELSE
			 BEGIN
				IF @ContactId IS NOT NULL
				    BEGIN

					   UPDATE TCD.PlantContact
						SET ContactFirstName = @FirstName,
						    ContactLastName = @LastName,
						    ContactEmail = @MailId,
						    ContactMobilePhone = @ContactNo,
						    LastModifiedByUserId = @UserId
						WHERE ID = @ContactId
						  AND EcolabAccountNumber = @EcolabAccountNumber;

					   INSERT INTO TCD.UserMaster (
					   FirstName,
					   LastName,
					   FullName,
					   LoginName,
					   Password,
					   Email,
					   Phone,
					   LanguageId,
					   IsActive,
					   LastModifiedByUserId,
					   EcolabAccountNumber,
					   ContactId,
					   CurrencyCode,
					   UOMId)
					   	OUTPUT
							inserted.UserId						AS			Id
						,	inserted.LastModifiedTime			AS			LastModifiedTimestamp
						INTO
							@OutputList	(
							UserId
						,	LastModifiedTimestamp
)
					   VALUES (
						    @FirstName,
						    @LastName,
							@FirstName
							+
							' '
							+
							@LastName,
							@LoginName,
							@Password,
							@MailId,
							@ContactNo,
							(SELECT LanguageId
							   FROM TCD.Plant
							   WHERE EcolabAccountNumber = @EcolabAccountNumber),
							1,
							@UserId,
							@EcolabAccountNumber,
							@ContactId,
							@CurrencyCode,
							@UOMId);
				    END;
				ELSE
				    BEGIN
					   INSERT INTO TCD.UserMaster (FirstName,
											 LastName,
											 FullName,
											 LoginName,
											 Password,
											 Email,
											 Phone,
											 LanguageId,
											 IsActive,
											 LastModifiedByUserId,
											 EcolabAccountNumber,
											 CurrencyCode,
											UOMId)
				OUTPUT
					inserted.UserId						AS			Id
				,	inserted.LastModifiedTime			AS			LastModifiedTimestamp
				INTO
					@OutputList	(
					UserId
				,	LastModifiedTimestamp
				    )
					   VALUES (	@FirstName,
								@LastName,
								@FirstName
								+
								' '
								+
								@LastName,
								@LoginName,
								@Password,
								@MailId,
								@ContactNo,
								(SELECT LanguageId
								   FROM TCD.Plant
								   WHERE EcolabAccountNumber = @EcolabAccountNumber),
								1,
								@UserId,
								@EcolabAccountNumber,
								@CurrencyCode,
								@UOMId);
				    END;
				DECLARE
					@NewUserNumber INT = SCOPE_IDENTITY();
				INSERT INTO TCD.UserInRole (
									   EcoLabAccountNumber,
									   UserId,
									   RoleId,
									   LastModifiedByUserId)
				VALUES( 
					   @EcolabAccountNumber,
					   @NewUserNumber,
					   @RoleId,
					   @UserId );
				INSERT INTO TCD.UserProfile (UserId,
									    EcolabAccountNumber)
				VALUES( @NewUserNumber,
					   @EcolabAccountNumber);
			 END;
	   END;
SELECT	TOP 1	
		@OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp
	,	@OutputUserId				=	O.UserId
FROM	@OutputList	O
    SET NOCOUNT OFF;
END;
GO

IF  EXISTS (SELECT * FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[TCD].[UpdateUserDetails]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[UpdateUserDetails]
END
GO


CREATE PROCEDURE [TCD].[UpdateUserDetails] (
	@FirstName nvarchar(100),
	@LastName  nvarchar(100),
	@UserNumber INT,
	@LoginName nvarchar(100),
	@Password  nvarchar(100),
	@MailId	 nvarchar(100)= NULL,
	@ContactNo nvarchar(100)= NULL,
	@RoleId	 INT,
	@UserId	 INT,
	@EcolabAccountNumber nvarchar(25),
	@Scope varchar(100) OUTPUT,
	@OutputUserId INT =	NULL	OUTPUT,
	@LastModifiedTimestampAtCentral	DATETIME	=	NULL,
	@OutputLastModifiedTimestampAtLocal	DATETIME	=	NULL	OUTPUT
)
AS 
  BEGIN 
      SET nocount ON;
	 DECLARE @OUTput Varchar(100) = '' 
	 DECLARE 
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	--,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()

	DECLARE
			@OutputList						AS	TABLE
(
			UserId							INT
		,	LastModifiedTimestamp			DATETIME
)

	 SET		@Scope										=			ISNULL(@Scope, NULL)										--SQLEnligth SA0121
	 SET		@OutputLastModifiedTimestampAtLocal			=			ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight SA0121
	 SET			@OutputUserId							=			ISNULL(@OutputUserId, NULL)									--SQLEnlight SA0121

	  IF NOT EXISTS (SELECT 1 FROM TCD.UserMaster UM WHERE UM.IsActive = 'TRUE' AND UM.LoginName = @LoginName AND UM.UserId != @UserNumber)
	  BEGIN
	  DECLARE	 
		    @ContactId INT = (SELECT UM.ContactId
		    				  FROM TCD.UserMaster UM
		    				  WHERE UM.UserId = @UserNumber);
		IF(@ContactId IS NOT NULL)
BEGIN
		IF	(
			@LastModifiedTimestampAtCentral				IS NOT	NULL
			AND
			NOT	EXISTS	(	SELECT	1
					FROM	TCD.UserMaster		UM
					WHERE	UM.EcolabAccountNumber	=	@EcolabAccountNumber
						AND	UM.UserId				=	@UserNumber
						AND	UM.LastModifiedTime		=	@LastModifiedTimestampAtCentral
				)
			)
BEGIN
				SET			@ErrorId				=	60000
				SET			@ErrorMessage			=	N'' + CAST(@ErrorId AS NVARCHAR) + N': Record not in-synch between plant and central.'
				RAISERROR	(@ErrorMessage, 16, 1)
				SET			@ReturnValue			=	-1
				RETURN		(@ReturnValue)
		END
		UPDATE [TCD].PlantContact
		SET ContactFirstName = @FirstName,  
		ContactLastName = @LastName,  
		ContactEmail = @MailId,  
		ContactMobilePhone = @ContactNo,
		LastModifiedByUserId = @UserId
		Where ID = @ContactId AND EcolabAccountNumber = @EcolabAccountNumber

		 UPDATE [TCD].UserMaster SET 
				LoginName = @LoginName,
				Password = @Password,
				LastModifiedByUserId = @UserId,
				LastModifiedTime = GETUTCDATE()
		OUTPUT
				inserted.UserId					AS			Id
			,	inserted.LastModifiedTime		AS			LastModifiedTimestamp
		INTO
				@OutputList	(
				UserId
			,	LastModifiedTimestamp
				)	
		WHERE UserId = @UserNumber AND EcolabAccountNumber = @EcolabAccountNumber
END
ELSE
BEGIN
		IF	(
			@LastModifiedTimestampAtCentral				IS NOT	NULL
			AND
			NOT	EXISTS	(	SELECT	1
			FROM	TCD.UserMaster		UM
			WHERE	UM.EcolabAccountNumber	=	@EcolabAccountNumber
			AND		UM.UserId				=	@UserNumber
			AND		UM.LastModifiedTime		=	@LastModifiedTimestampAtCentral
						)
			)
			BEGIN
					SET			@ErrorId				=	60000
					SET			@ErrorMessage			=	N'' + CAST(@ErrorId AS NVARCHAR) + N': Record not in-synch between plant and central.'
					RAISERROR	(@ErrorMessage, 16, 1)
					SET			@ReturnValue			=	-1
					RETURN		(@ReturnValue)
			END

			 IF NOT EXISTS(SELECT * FROM TCD.UserMaster WHERE Email = @MailId AND UserId != @UserId AND ISACTIVE=1)
BEGIN
						UPDATE [TCD].UserMaster SET 
							FirstName = @FirstName,
							LastName	= @LastName,
							LoginName = @LoginName,
							Password = @Password,
							Email = @MailId,
							Phone = @ContactNo,
							LastModifiedByUserId = @UserId,
							LastModifiedTime = GETUTCDATE()
					OUTPUT
							inserted.UserId					AS			Id
						,	inserted.LastModifiedTime		AS			LastModifiedTimestamp
					INTO
							@OutputList	(
							UserId
						,	LastModifiedTimestamp
	)
					WHERE UserId = @UserNumber AND EcolabAccountNumber = @EcolabAccountNumber
			END
			ELSE
				  BEGIN
						BEGIN Set @OutPut = '501'   
						SET @Scope = @OutPut 
						Select @Scope  
				END
END
END
		UPDATE [TCD].UserInRole SET
				UserId = @UserNumber,
				RoleId = @RoleId,
				LastModifiedByUserId = @UserId
		WHERE UserId = @UserNumber
	     AND
		 EcoLabAccountNumber = @EcolabAccountNumber
END

	  ELSE
	  BEGIN
		 BEGIN Set @OutPut = '301'   
  		   SET @Scope = @OutPut 
		   Select @Scope  
		   	  END
       END
SELECT	TOP 1	
		@OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp
	,	@OutputUserId						=	O.UserId
FROM	@OutputList							O		  

	SET nocount OFF;
  END
  GO




  IF  EXISTS (SELECT * FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[TCD].[UpdateDashboardSlideDuration]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[UpdateDashboardSlideDuration]
END
GO



CREATE PROCEDURE [TCD].[UpdateDashboardSlideDuration](
			@SlideDuration Int = Null,
			@EcolabAccountNumber Varchar(100),
			@Scope INT OUTPUT
			)
AS 
BEGIN
UPDATE TCD.Plant set DashboardSlideDuration = @SlideDuration where EcolabAccountNumber = @EcolabAccountNumber
	 
DECLARE @OutPut int = 1
BEGIN
SET @Scope = @OutPut SELECT @Scope  
END
END
GO
	
  CREATE PROCEDURE [TCD].[GetDispencerRecordedLoads] 
(
    @GroupId        NVARCHAR(1000)        =   NULL
  , @MachineId        INT                 =   NULL
  , @ProgramId       INT                 =   NULL
  , @StartDate        DATETIME            =   NULL
  , @RowsPerPage INT =50
  , @PageNumber INT = 1
  ,	@EndDate	DATETIME            =   NULL
	)
AS 
	
  BEGIN
  SET NOCOUNT ON

	IF(@ProgramId = 0)      
    BEGIN      
		SET @ProgramId = NULL      
    END    

   IF @PageNumber < 1 
   BEGIN
		SET @PageNumber = 1 
   END

   SET @startdate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@startdate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@startdate AS time)) AS DateTime))  
   SET @EndDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndDate AS time)) AS DateTime))  

   Declare @RegionId int= 0;
   select top 1 @RegionId = RegionId from TCD.Plant

   SELECT	bd.BatchId,
			CAST(StartDate AS datetime) AS StartDate,
    CAST(ROUND(CASE WHEN (@RegionId=1) THEN  COALESCE(bd.ManualInputWeight,bd.ActualWeight) ELSE (COALESCE(bd.ManualInputWeight,bd.ActualWeight)*0.453592) END,0) AS int),
			bd.ProgramNumber,
			pm.Name,
			Count(*) Over() TotalRows ,  
			bd.EcolabWasherId    
	FROM TCD.BatchData bd
	INNER JOIN TCD.ProductionShiftData psd ON psd.ShiftId = bd.ShiftId
	INNER JOIN TCD.ProgramMaster pm ON pm.ProgramId = bd.ProgramMasterId
	WHERE bd.EndDate IS NOT NULL 
	AND bd.MachineId = @MachineId
	AND bd.ProgramNumber = COALESCE(@ProgramId, bd.ProgramNumber )
	AND psd.StartDateTime Between @StartDate AND @EndDate
	ORDER BY bd.BatchId
   OFFSET (@PageNumber-1)*@RowsPerPage ROWS
   FETCH NEXT @RowsPerPage ROWS ONLY

 SET NOCOUNT OFF
  END
  GO

IF  EXISTS (SELECT * FROM sys.objects  WHERE object_id = OBJECT_ID(N'[TCD].[GetManualLaborDetails]') AND type IN (N'P', N'PC'))
BEGIN
	DROP PROCEDURE [TCD].[GetManualLaborDetails]
END
GO
		 
CREATE PROCEDURE [TCD].[GetManualLaborDetails] 
(
				@LocationId int = NULL,
				@ManHourTypeId Int = NULL,
				@EcolabAccountNumber Varchar(100)
)
AS
BEGIN
SET NOCOUNT ON


  SELECT TOP 1	 ML.Id					AS		Id
				,ML.LocationId			AS		LocationId	
				,ML.ManHourTypeId		AS		ManHourTypeId
				,ML.StartDate			As		StartDate
				,ML.EndDate				AS		EndDate
				,ML.LaborCost			AS		LaborCost
				,ML.AllocatedManHours	AS		AllocatedManHours
				,ML.EcolabAccountNumber	AS		EcolabAccountNumber
  FROM			[TCD].ManualLabor ML
  WHERE 		ML.ManHourTypeId			=		@ManHourTypeId 
  AND			ML.LocationId				=		@LocationId 
  AND			ML.EcolabAccountNumber		=		@EcolabAccountNumber
  AND			ML.IsDeleted				=		'FALSE'
  ORDER BY		ML.Id DESC

SET NOCOUNT OFF
END
GO



  IF  EXISTS (SELECT * FROM sys.objects  WHERE object_id = OBJECT_ID(N'[TCD].[GetDispencerRecordedLoads]') AND type IN (N'P', N'PC'))
BEGIN
	DROP PROCEDURE [TCD].[GetDispencerRecordedLoads]
END
GO

  CREATE PROCEDURE [TCD].[GetDispencerRecordedLoads] 
(
    @GroupId        NVARCHAR(1000)        =   NULL
  , @MachineId        INT                 =   NULL
  , @ProgramId       INT                 =   NULL
  , @StartDate        DATETIME            =   NULL
  , @RowsPerPage INT =50
  , @PageNumber INT = 1
  ,	@EndDate	DATETIME            =   NULL
)
AS 

  BEGIN
  SET NOCOUNT ON

	IF(@ProgramId = 0)      
    BEGIN      
		SET @ProgramId = NULL      
    END    

   IF @PageNumber < 1 
   BEGIN
		SET @PageNumber = 1 
   END

   SET @startdate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@startdate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@startdate AS time)) AS DateTime))  
   SET @EndDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndDate AS time)) AS DateTime))  

   Declare @RegionId int= 0;
   select top 1 @RegionId = RegionId from TCD.Plant

   SELECT	bd.BatchId,
			CAST(StartDate AS datetime) AS StartDate,
    CAST(ROUND(CASE WHEN (@RegionId=1) THEN  COALESCE(bd.ManualInputWeight,bd.ActualWeight) ELSE (COALESCE(bd.ManualInputWeight,bd.ActualWeight)*0.453592) END,0) AS int),
			bd.ProgramNumber,
			pm.Name,
			Count(*) Over() TotalRows ,  
			bd.EcolabWasherId    
	FROM TCD.BatchData bd
	INNER JOIN TCD.ProductionShiftData psd ON psd.ShiftId = bd.ShiftId
	INNER JOIN TCD.ProgramMaster pm ON pm.ProgramId = bd.ProgramMasterId
	WHERE bd.EndDate IS NOT NULL 
	AND bd.MachineId = @MachineId
	AND bd.ProgramNumber = COALESCE(@ProgramId, bd.ProgramNumber )
	AND psd.StartDateTime Between @StartDate AND @EndDate
	ORDER BY bd.BatchId
   OFFSET (@PageNumber-1)*@RowsPerPage ROWS
   FETCH NEXT @RowsPerPage ROWS ONLY

 SET NOCOUNT OFF
  END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetSpecifiedLanguage]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetSpecifiedLanguage]
END
GO
CREATE PROCEDURE [TCD].[GetSpecifiedLanguage] (@Locale [NVARCHAR](50)) 
AS 
  BEGIN 
	  SET nocount ON; 

	  DECLARE @CurrencySymbol nvarchar(10) ='$'

	  SELECT top(1) @CurrencySymbol = cs.CurrencySymbol  FROM TCD.CurrencySymbol cs WHERE cs.CurrencyCode = ( SELECT Top(1) p.CurrencyCode FROM TCD.Plant p)

	  SELECT DISTINCT KeyMaster.[KeyName], 
			 REPLACE(ValueMaster.[Value], '#currency#',@CurrencySymbol) AS [Value]
	  FROM    [TCD].ResourceKeyMaster KeyMaster 
	  INNER JOIN [TCD].ResourceKeyValue ValueMaster On KeyMaster.[KeyName]=  ValueMaster.[KeyName]
	  INNER JOIN TCD.LanguageMaster lm ON lm.LanguageId = ValueMaster.LanguageId
	  WHERE  lm.Locale = @Locale 
  END 
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetResourceKeyValuesForUom]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetResourceKeyValuesForUom]
END
GO
CREATE PROCEDURE [TCD].[GetResourceKeyValuesForUom]
                     (
                       @EcolabAccountNumber Nvarchar(25) = NULL,
                       @UserId Int = NULL
                     )   
AS
SET NOCOUNT ON
BEGIN
DECLARE @UOM Int,@LanguageId Int,@CurrencyCode Varchar(20), @CurrencySymbol nvarchar(10) ='$'
SELECT @UOM = UOMId FROM TCD.UserMaster WHERE TCD.UserMaster.EcolabAccountNumber = @EcolabAccountNumber AND UserId =@UserId 
SELECT @CurrencyCode = P.CurrencyCode FROM TCD.PLANT P WHERE EcolabAccountNumber = @EcolabAccountNumber
SELECT @LanguageId = ISNULL(UM.LanguageId,(SELECT LanguageId FROM TCD.Plant where EcolabAccountNumber = @EcolabAccountNumber)) FROM TCD.UserMaster UM
                    WHERE UM.UserId = @UserId AND EcolabAccountNumber = @EcolabAccountNumber
SELECT TOP(1) @CurrencySymbol = cs.CurrencySymbol  FROM TCD.CurrencySymbol cs WHERE cs.CurrencyCode = ( SELECT TOP(1) p.CurrencyCode FROM TCD.Plant p WHERE p.EcolabAccountNumber = @EcolabAccountNumber)

DECLARE @UnitSystem TABLE
                    (
                       UnitSystemId INT,
                       Unit NVARCHAR(200) ,
                       Subunit NVARCHAR(200),
                       UsageKey NVARCHAR(200),
                       [KeyName] NVARCHAR(200),
                       Value NVARCHAR(800),
                       languageID INT
                    )

INSERT INTO @UnitSystem
  SELECT  UnitSystemId, Unit, Subunit,  UsageKey,RKM.[KeyName],ISNULL(RKV.Value,RKVEn.Value) as Value,ISNULL(RKV.languageID,RKVEn.languageID) as LanguageId
  FROM TCD.DimensionalUnitsDefaults DM
  LEFT OUTER JOIN TCD.ResourceKeyMaster RKM ON DM.Subunit = RKM.[KeyName]
  LEFT OUTER JOIN TCD.ResourceKeyValue RKV ON RKM.KeyName = RKV.KeyName AND RKV.languageID = @LanguageId	
  LEFT OUTER JOIN TCD.ResourceKeyValue RKVEn ON RKM.KeyName = RKVEn.KeyName AND RKVEn.languageID = 1
  WHERE UnitSystemId = @UOM and ISNULL(RKV.languageID,RKVEn.languageID) is not null 
       --UNION ALL

          --SELECT 
                -- NULL,   
                --'Cuurency',
                --'Cuurency',
                --'Cuurency',
                --'Cuurency',
                --CASE @CurrencyCode WHEN 'USD' THEN '$'
                --                WHEN 'EUR'THEN '�' END,
                --1
SELECT 
                      UnitSystemId ,
                       Unit  ,
                       Subunit,
                       UsageKey,
                       [KeyName] ,
                       REPLACE(Value ,'#currency#', @CurrencySymbol),
                       languageID 
                        FROM @UnitSystem
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetUtilityDimensionalUnits]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetUtilityDimensionalUnits]
END
GO
CREATE Procedure [TCD].[GetUtilityDimensionalUnits]	(
					@EcolabAccountNumber				NVARCHAR(1000)
)
AS 
SET NOCOUNT ON
Declare @price NVARCHAR(500)=NULL
Declare @ElectricTariff NVARCHAR(500)=NULL
Declare @gasOilPrice NVARCHAR(500)=NULL
Declare @Temperature NVARCHAR(500)=NULL
Declare @EnergyContent NVARCHAR(500)=NULL
DECLARE @CurrencySymbol nvarchar(10) ='$'
Declare @UOM INT=(select UOMId from [TCD].plant where EcolabAccountNumber=@EcolabAccountNumber) --Remove the EcolabAccountNumber from here and pass it as parameter
Declare @LanguageId INT=(select RegionId from [TCD].plant where EcolabAccountNumber=@EcolabAccountNumber) --Remove the EcolabAccountNumber from here and pass it as parameter
  BEGIN 

	SELECT TOP(1) @CurrencySymbol = cs.CurrencySymbol  FROM TCD.CurrencySymbol cs WHERE cs.CurrencyCode = ( SELECT TOP(1) p.CurrencyCode FROM TCD.Plant p WHERE p.EcolabAccountNumber = @EcolabAccountNumber)
	Select @price=SubUnit from [TCD].GetDimensionalUnits('Price_tcd',@UOM)
	Select @ElectricTariff=SubUnit from [TCD].GetDimensionalUnits('Price_Electric_Tariff_Tcd',@UOM)
	Select @gasOilPrice=SubUnit from [TCD].GetDimensionalUnits('Price_GasOil_Tcd',@UOM)
	Select @Temperature=SubUnit from [TCD].GetDimensionalUnits('Temperature_CandF',@UOM)
	Select @EnergyContent=SubUnit from [TCD].GetDimensionalUnits('Energy_Content_TCD',@UOM)

	SELECT @price= ResourceKeyValue.Value FROM [TCD].ResourceKeyMaster INNER JOIN [TCD].ResourceKeyValue ON ResourceKeyMaster.KeyName = ResourceKeyValue.KeyName WHERE   ResourceKeyMaster.KeyName=@price and languageID=@LanguageId
	SELECT @ElectricTariff=ResourceKeyValue.Value FROM [TCD].ResourceKeyMaster INNER JOIN [TCD].ResourceKeyValue ON ResourceKeyMaster.KeyName = ResourceKeyValue.KeyName WHERE   ResourceKeyMaster.KeyName=@ElectricTariff and languageID=@LanguageId
	SELECT @gasOilPrice=ResourceKeyValue.Value FROM [TCD].ResourceKeyMaster INNER JOIN [TCD].ResourceKeyValue ON ResourceKeyMaster.KeyName = ResourceKeyValue.KeyName WHERE   ResourceKeyMaster.KeyName=@gasOilPrice and languageID=@LanguageId
	SELECT @Temperature=ResourceKeyValue.Value FROM [TCD].ResourceKeyMaster INNER JOIN [TCD].ResourceKeyValue ON ResourceKeyMaster.KeyName = ResourceKeyValue.KeyName WHERE   ResourceKeyMaster.KeyName=@Temperature and languageID=@LanguageId
	SELECT @EnergyContent=ResourceKeyValue.Value FROM [TCD].ResourceKeyMaster INNER JOIN [TCD].ResourceKeyValue ON ResourceKeyMaster.KeyName = ResourceKeyValue.KeyName WHERE   ResourceKeyMaster.KeyName=@EnergyContent and languageID=@LanguageId

	select REPLACE(@price, '#currency#', @CurrencySymbol) AS Price 
		  ,@ElectricTariff AS ElectricPrice
		  ,@gasOilPrice AS GasPrice
		  ,@Temperature AS Temperature
		  ,@EnergyContent AS EnergyContent

END
GO

IF EXISTS(SELECT * FROM tcd.Plant p)
BEGIN
UPDATE tcd.plant SET
tcd.Plant.ExportPath='C:\EcoLab\Envision\BACKUP'
END
GO