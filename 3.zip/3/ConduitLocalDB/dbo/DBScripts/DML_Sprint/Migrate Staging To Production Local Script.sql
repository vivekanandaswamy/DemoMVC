
DECLARE @CentralIp nvarchar(200) = '10.160.8.72'
, @CentralPort nvarchar(50) = '9340';

-------------------Delete the PlantSettings table for the Node details to be created again and Sync to Production------------
DELETE	FROM TCD.PlantSettings	;

-----------------Update Config settings to point to production---------------------------------------------------------------
UPDATE TCD.ConfigSettings
SET
    TCD.ConfigSettings.[Value] = @CentralIp	
    WHERE TCD.ConfigSettings.KeyName	='HostName';

UPDATE TCD.ConfigSettings
SET
    TCD.ConfigSettings.[Value] = @CentralPort	
    WHERE TCD.ConfigSettings.KeyName	='PortNumber';

	
------------------Update Lastsynctime as NULL for the service to sync the data again to Production--------------------------
UPDATE tcd.BatchData
SET
    TCD.BatchData.LastSyncTime = NULL;

UPDATE	tcd.ProductionShiftData
SET
    TCD.ProductionShiftData.LastSyncTime = NULL;
	
UPDATE tcd.AlarmData
SET
    TCD.AlarmData.LastSyncTime = NULL;

UPDATE	TCD.RedFlagData
SET
    TCD.RedFlagData.LastSyncTime = NULL	;
