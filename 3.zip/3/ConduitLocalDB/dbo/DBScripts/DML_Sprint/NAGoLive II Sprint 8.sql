﻿
GO
IF  NOT EXISTS (SELECT * FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[TCD].[WasherModuleOnlineUsageData]') AND type in (N'U'))
BEGIN
 CREATE TABLE [TCD].[WasherModuleOnlineUsageData](
	[WasherModuleOnlineUsageDataId] [int] IDENTITY(1,1) NOT NULL,
	[WasherId] [int] NOT NULL,
	[StepComportment] [int] NOT NULL,
	[ModuleId] [int] NOT NULL,
	[ActualQuantity] [float] NULL,
	[TimeStamp] [datetime] NULL,
	[EcolabWasherId] [int] NULL,
 CONSTRAINT [PK_WasherModuleOnlineUsageData] PRIMARY KEY CLUSTERED 
(
	[WasherModuleOnlineUsageDataId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

ALTER TABLE [TCD].[WasherModuleOnlineUsageData]  WITH CHECK ADD  CONSTRAINT [FK_WasherModuleOnlineUsageData_Meter] FOREIGN KEY([ModuleId])
REFERENCES [TCD].[Meter] ([MeterId])
ALTER TABLE [TCD].[WasherModuleOnlineUsageData] CHECK CONSTRAINT [FK_WasherModuleOnlineUsageData_Meter]
ALTER TABLE [TCD].[WasherModuleOnlineUsageData]  WITH CHECK ADD  CONSTRAINT [FK_WasherModuleOnlineUsageData_Washer] FOREIGN KEY([WasherId])
REFERENCES [TCD].[Washer] ([WasherId])
ALTER TABLE [TCD].[WasherModuleOnlineUsageData] CHECK CONSTRAINT [FK_WasherModuleOnlineUsageData_Washer]
END
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlConventionalData_Online]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlConventionalData_Online]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessMyControlConventionalData_Online]
(
	@ControllerID   INT,
	@VxML           XML,
	@RedFlagShiftId INT OUTPUT
)
AS
	BEGIN
	    DECLARE @MachineNumber           INT,
			  @StepNumber              INT,
			  @StartDateTime           DATETIME,
			  @EndDateTime             DATETIME,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @PHValue                 INT,
			  @TemperatureMin          INT,
			  @TemperatureMax          INT,
			  @TempMinStatus           INT,
			  @TempMaxStatus           INT,
			  @BatchNumber             INT,
			  @WasherID                INT,
			  @WasherGroupID           INT,
			  @EcoLabWasherID          INT,
			  @ProgramMasterID         INT,
			  @PlantWasherNumber       INT,
			  @ShiftID                 INT,
			  @FrmParameterID          INT,
			  @PHParameterID           INT,
			  @PHParameterStatus       INT,
			  @BatchID                 INT,
			  @ShiftStartdate          DATETIME,
			  @ShiftName               NVARCHAR(50),
			  @XMLDataID               INT,
			  @TempParameter           INT,
			  @TemperatureMinParam     INT,
			  @TemperatureMaxParam     INT,
			  @TempMinStatusParam      INT,
			  @TempMaxStatusParam      INT,
			  @WashStepNo              INT,
			  @CurrencyCode            VARCHAR(50),
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @TargetTurnTime          INT;
	    SELECT @MachineNumber = T.c.value('@MachineNumber', 'INT'),
			 @StepNumber = T.c.value('@StepNumber', 'INT'),
			 @StartDateTime = T.c.value('@StartDateTime', 'DATETIME'),
			 @EndDateTime = T.c.value('@EndDateTime', 'DATETIME'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)')/10,
			 @NominalLoad = T.c.value('@NominalLoad', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'INT'),
			 @PHStatus = T.c.value('@PHStatus', 'INT'),
			 @PHValue = T.c.value('@PHValue', 'INT'),
			 @TemperatureMin = T.c.value('@TemperatureMin', 'INT'),
			 @TemperatureMax = T.c.value('@TemperatureMax', 'INT'),
			 @TempMaxStatus = T.c.value('@TemperatureMaxStatus', 'INT'),
			 @TempMinStatus = T.c.value('@TemperatreMinStatus', 'INT'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT')
	    FROM @VxML.nodes('MyControlConventionalData') T(C);
	    SELECT @PHParameterID = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'pH';
	    SELECT @PHParameterStatus = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'PH Status';
	    SELECT @TemperatureMinParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Mimum Temperature';
	    SELECT @TemperatureMaxParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Maximum Temperature';
	    SELECT @TempMinStatusParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Minimum Temperature Status';
	    SELECT @TempMaxStatusParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Max Temperature Status';
	    SELECT @WashStepNo = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'StepCompartment No';
	    SELECT @FrmParameterID = [Id]
	    FROM TCD.ConduitPArameters
	    WHERE Name = 'Formula Number';
	    DECLARE @ShiftMapping TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    INSERT INTO @ShiftMapping
	    (
		  ShiftId,
		  ShiftName,
		  ShiftStartdate
	    )
	    EXEC TCD.GetShiftStartDate
		    @StartDateTime
	    SELECT @ShiftID = ShiftID,
			 @ShiftStartdate = ShiftStartdate
	    FROM @ShiftMapping;
	    SELECT @WasherGroupID = GroupId,
			 @WasherID = WasherID
	    FROM TCD.MachineSetup ms
	    WHERE ControllerID = @ControllerID
			AND MachineInternalId = @MachineNumber
			AND IsTunnel = 0
			AND IsDeleted = 0;
	    IF(@EndDateTime = '1/1/1900')
		   SELECT @EndDateTime = NULL;
	    IF(@StartDateTime = '1/1/1900')
		   SELECT @StartDateTime = NULL;
	    IF(@WasherId IS NOT NULL)
		   BEGIN
			  SELECT @ProgramMasterId = Wps.ProgramId
			  FROM TCD.Washer Ws
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.ControllerID = Wg.ControllerId
				  INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.EcoLabAccountNumber
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wps.Is_Deleted = 0;
			  SELECT @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber,
				    @CurrencyCode = P.CurrencyCode,
				    @TargetTurnTime = w.TargetTurnTime * 60
			  FROM TCD.Washer w
				  INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.EcolabAccountNumber
			  WHERE w.WasherId = @WasherID;
	   END;
	    SELECT @BatchID = BatchID
	    FROM TCD.BatchData
	    WHERE MachineInternalID = @MachineNumber
			AND StartDate = @StartDateTime
			AND ControllerBatchId = @BatchNumber
			AND MachineID = @WasherID;

	    --Start Getting InjectionCount and StepCount
	    SELECT @StdInjectionSteps = COUNT(DISTINCT wdpm.
	    WasherDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) -
			 COUNT(DISTINCT wdpm.WasherDosingSetupId)
	    FROM TCD.WasherDosingProductMapping wdpm
		    RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm.
		    WasherDosingSetupId = wds.WasherDosingSetupId
	    WHERE wds.ControllerID = @ControllerID
			AND wds.ProgramNumber = @ProgramNumber;
	    --End Getting InjectionCount and StepCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramMasterId
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT @EcolabTextileCategoryId = pcp.
			  EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp.
				    ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    IF(@BatchID IS NULL)
		   BEGIN
			  INSERT INTO TCD.BatchData
			  (ControllerBatchID,
			   EcolabWasherId,
			   GroupId,
			   MachineInternalId,
			   PlantWasherNumber,
			   StartDate,
			   EndDate,
			   ProgramNumber,
			   ProgramMasterId,
			   MachineID,
			   ActualWeight,
			   StandardWeight,
			   CurrencyCode,
			   ShiftId,
			   PartitionOn,
			   StdInjectionSteps,
			   StdWashSteps,
			   EcolabTextileCategoryId,
			   ChainTextileCategoryId,
			   FormulaSegmentId,
			   EcolabSaturationId,
			   PlantProgramId,
			   EndDateFormula,
			   TargetTurnTime
			  )
			  VALUES
			  (
				    @BatchNumber,
				    @EcoLabWasherID,
				    @WasherGroupID,
				    @MachineNumber,
				    @PlantWasherNumber,
				    @StartDateTime,
				    @EndDateTime,
				    @ProgramNumber,
				    @ProgramMasterId,
				    @WasherID,
				    @Load,
				    @NominalLoad,
				    @CurrencyCode,
				    @ShiftID,
				    @ShiftStartdate,
				    @StdInjectionSteps,
				    @StdWashSteps,
				    @EcolabTextileCategoryId,
				    @ChainTextileCategoryId,
				    @FormulaSegmentId,
				    @EcolabSaturationId,
				    @PlantProgramId,
				    @EndDateTime,
				    @TargetTurnTime
			  );
			  SELECT @BatchID = SCOPE_IDENTITY();
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM TCD.BatchParameters
				 WHERE BatchId = @BatchID
					  AND ParameterID = 38
			   )
			   BEGIN
			   IF(@StdWashSteps <> 0
				 OR @StdWashSteps <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
					   BatchId,
					   EcolabWasherId,
					   ParameterId,
					   ParameterValue,
					   PartitionOn
					)
					SELECT @BatchID,
						  @EcoLabWasherID,
						  38,
						  @StdWashSteps,
						  @ShiftStartdate;
				  END
			END;

			  --End Date  Time  is Null 
			  UPDATE TCD.BatchData
			    SET
				   EndDate = GETUTCDATE()
			  WHERE MachineInternalID = @MachineNumber
				   AND StartDate <> @StartDateTime
				   AND EndDate IS NULL
				   AND ControllerBatchId <> @BatchNumber
				   AND MachineId = @WasherId;	
																  		
			  -- Program Number	
			  IF(@ProgramNumber IS NOT NULL
				AND @ProgramNumber > 0)
				 BEGIN
					IF NOT EXISTS
					(
					    SELECT *
					    FROM TCD.WasherReading
					    WHERE WasherId = @WasherID
							AND ParameterID = @FrmParameterID
							AND DateTimeStamp = @StartDateTime
					)
					    BEGIN
						   INSERT INTO TCD.WasherReading
						   (WasherID,
						    ParameterID,
						    ParameterValue,
						    DateTimeStamp,
						    EcoLabWasherID,
						    Partitionon
						   )
						   VALUES
						   (
								@WasherID,
								@FrmParameterID,
								@ProgramNumber,
								@StartDateTime,
								@EcoLabWasherID,
								@ShiftStartdate
						   );
					    END;
				 END;
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM [TCD].[BatchCustomerData]
				 WHERE BatchID = @BatchId
					  AND @CustomerNumber IS NOT NULL
			  )
				 BEGIN
					INSERT INTO [TCD].[BatchCustomerData]
					([BatchId],
					 CustomerID,
					 [Weight],
					 PartitionOn,
					 EcolabWasherId
					)
					VALUES
					(
						  @BatchID,
						  @CustomerNumber,
						  @Load,
						  @ShiftStartdate,
						  @EcolabWasherID
					);
				 END;
		   END;

	    -- PH Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @PHParameterID
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@PHValue <> 0
				OR @PHValue <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @PHParameterID,
							    @PHValue,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 
	 
	    -- PH Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @PHParameterStatus
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@PHStatus <> 0
				OR @PHStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @PHParameterStatus,
							    @PHStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Min Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TemperatureMinParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TemperatureMin <> 0
				OR @TemperatureMin <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TemperatureMinParam,
							    @TemperatureMin,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Max Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TemperatureMaxParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TemperatureMax <> 0
				OR @TemperatureMax <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TemperatureMaxParam,
							    @TemperatureMax,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Min Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TempMinStatusParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TempMinStatus <> 0
				OR @TempMinStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TempMinStatusParam,
							    @TempMinStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Max Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TempMaxStatusParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TempMaxStatus <> 0
				OR @TempMaxStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TempMaxStatusParam,
							    @TempMaxStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- StepCompartment No
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @WashStepNo
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@StepNumber <> 0
				OR @StepNumber <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @WashStepNo,
							    @StepNumber,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END;
	END;

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlProductionWaterConsumptionData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlProductionWaterConsumptionData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [TCD].[ProcessMyControlProductionWaterConsumptionData]
(
    @BatchId			   INT,
    @WaterConsumptionXML	   XML,
    @PartitionOn		   DATETIME
)
AS
    BEGIN
	   DECLARE @WaterTypeId		 INT,
			 @StandardQuantity	 INT,
			 @Price			 INT,
			 @EcolabWasherID	 INT


			SELECT   @EcolabWasherID=bd.EcolabWasherId  
			FROM TCD.BatchData bd
			WHERE bd.BatchId=@BatchId 
			 -- 1.Getting xml data  into XmlData with CTE
			 ;WITH XmlData AS 
			 (
				SELECT  T.c.value('@StepNo', 'INT') StepNo,
					   T.c.value('@WCCounter1', 'Decimal(10,2)') + T.c.value('@WCCounter2', 'Decimal(10,2)')  ActualQuantity
				FROM @WaterConsumptionXML.nodes('MyControlConventionalData/WaterConsumptionData/StepConsumption') T(c)
			 )
			 -- inserting records into tcd.BatchStepWaterUsageData table using merge statement
			 MERGE INTO tcd.BatchStepWaterUsageData bswud
			 USING
			 (
				SELECT xd.StepNo,
					  xd.ActualQuantity
				   FROM XmlData xd
			 ) temp 
			 ON bswud.BatchId = @BatchId AND bswud.stepCompartment=temp.stepNo AND bswud.ActualQuantity=temp.ActualQuantity
			 WHEN NOT MATCHED AND
			 (
				temp.ActualQuantity > 0 
			 )
			 THEN 
			 INSERT
			 (
				Batchid,
				StepCompartment,
				WaterTypeId,
				ActualQuantity,
				StandardQuantity,
				Price,
				PartitionOn,
				EcolabWasherId
			 )
			 VALUES
			 (
				@BatchId,
				temp.StepNo,
				NULL,
				temp.ActualQuantity,
				NULL,
				NULL,
				@PartitionOn,
				@EcolabWasherID
			 );
    END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlConventionalData_CompletedBatches]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlConventionalData_CompletedBatches]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessMyControlConventionalData_CompletedBatches](
	@ControllerID   INT,
	@VxML           XML,
	@PLCPointer     INT,
	@ReadPointer    INT,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @MachineNumber           INT,
			  @StartDateTime           DATETIME,
			  @EndDateTime             DATETIME,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @PHValue                 INT,
			  @TemperatureMin          INT,
			  @TemperatureMax          INT,
			  @TempMinStatus           INT,
			  @TempMaxStatus           INT,
			  @BatchNumber             INT,
			  @WasherID                INT,
			  @WasherGroupID           INT,
			  @EcoLabWasherID          INT,
			  @ProgramMasterID         INT,
			  @PlantWasherNumber       INT,
			  @ShiftID                 INT,
			  @BatchID                 INT,
			  @ShiftStartdate          DATETIME,
			  @LastStep                INT,
			  @CurrentStep             INT,
			  @CurrentStepTime         DATETIME,
			  @MinTempParamID          INT,
			  @MaxTempParamID          INT,
			  @MinTempStatuParamID     INT,
			  @MaxTempStatusParamID    INT,
			  @PHStatusParamID         INT,
			  @PHValueParamID          INT,
			  @CurrencyCode            VARCHAR(50),
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @ActualInjSteps          INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @TargetTurnTime          INT,
			  @PreviousShiftId		  INT,
			  @CurrentShiftId		  INT;
	    SELECT @MachineNumber = T.c.value('@MachineNumber', 'INT'),
			 @StartDateTime = T.c.value('@StartDateTime', 'DateTime'),
			 @EndDateTime = T.c.value('@EndDateTime', 'DateTime'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@NominalLoad', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'INT'),
			 @PHStatus = T.c.value('@PHStatus', 'INT'),
			 @PHValue = T.c.value('@PHValue', 'INT'),
			 @TemperatureMin = T.c.value('@TemperatureMin', 'INT'),
			 @TemperatureMax = T.c.value('@TemperatureMax', 'INT'),
			 @TempMaxStatus = T.c.value('@TemperatureMaxStatus', 'INT'),
			 @TempMinStatus = T.c.value('@TemperatreMinStatus', 'INT'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT')
	    FROM @VxML.nodes('MyControlConventionalData') T(C);
	    DECLARE @ShiftMapping TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    INSERT INTO @ShiftMapping
	    (ShiftId,
		ShiftName,
		ShiftStartdate
	    )
	    EXEC TCD.GetShiftStartDate
		    @StartDateTime
	    SELECT @ShiftID = ShiftID,
			 @ShiftStartdate = ShiftStartdate
	    FROM @ShiftMapping;
	    SELECT @WasherGroupID = GroupId,
			 @WasherID = WasherID
	    FROM TCD.MachineSetup ms
	    WHERE ControllerID = @ControllerID
			AND MachineInternalId = @MachineNumber
			AND IsTunnel = 0
			AND IsDeleted = 0;
	    IF(@WasherId IS NOT NULL)
		   BEGIN
			  SELECT @ProgramMasterId = Wps.ProgramId
			  FROM TCD.Washer Ws
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws
				  .WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =
				  Mst.GroupId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.
				  ControllerID = Wg.ControllerId
				  INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber =
				  Ws.EcoLabAccountNumber
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wps.Is_Deleted = 0;
			  SELECT @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber,
				    @CurrencyCode = P.CurrencyCode,
				    @TargetTurnTime = w.TargetTurnTime * 60
			  FROM TCD.Washer w
				  INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.
				  EcolabAccountNumber
			  WHERE w.WasherId = @WasherID;
		   END;
	    SELECT @BatchID = BatchID
	    FROM TCD.BatchData
	    WHERE MachineInternalID = @MachineNumber
			AND StartDate = @StartDateTime
			AND ControllerBatchId = @BatchNumber
			AND MachineID = @WasherID;

	    --Start Getting InjectionCount and StepCount

	    SELECT @StdInjectionSteps = COUNT(DISTINCT wdpm.
	    WasherDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) -
			 COUNT(DISTINCT wdpm.WasherDosingSetupId)
	    FROM TCD.WasherDosingProductMapping wdpm
		    RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm.
		    WasherDosingSetupId = wds.WasherDosingSetupId
	    WHERE wds.ControllerID = @ControllerID
			AND wds.ProgramNumber = @ProgramNumber;

	    --End Getting InjectionCount and StepCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramMasterId
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT @EcolabTextileCategoryId = pcp.
			  EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp.
				    ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    IF(@BatchID IS NULL)
		   BEGIN

		    --Start Rollup for previous completed shift
	   IF(CAST(@StartDateTime as date) < CAST(GETUTCDATE() as date))
	   BEGIN
		  SELECT TOP 1 @PreviousShiftId=ShiftId FROM TCD.BatchData WHERE MachineId=@WasherId ORDER BY StartDate DESC	   
		  SELECT Top 1 @CurrentShiftId = ShiftId from @ShiftMapping
		  IF(@CurrentShiftId != @PreviousShiftId)
		  BEGIN
			 EXEC TCD.ProductionShiftDataRollup @PreviousShiftId, @RedFlagShiftId OUTPUT
			 IF(@RedFlagShiftId IS NULL)
			 BEGIN
				SET @RedFlagShiftId = @PreviousShiftId
			 END
		  END
	   END
	   --End Rollup for previous completed shift

			  INSERT INTO TCD.BatchData
			  (ControllerBatchID,
			   EcolabWasherId,
			   GroupId,
			   MachineInternalId,
			   PlantWasherNumber,
			   StartDate,
			   EndDate,
			   ProgramNumber,
			   ProgramMasterId,
			   MachineID,
			   ActualWeight,
			   StandardWeight,
			   CurrencyCode,
			   ShiftId,
			   PartitionOn,
			   StdInjectionSteps,
			   StdWashSteps,
			   EcolabTextileCategoryId,
			   ChainTextileCategoryId,
			   FormulaSegmentId,
			   EcolabSaturationId,
			   PlantProgramId,
			   EndDateFormula,
			   TargetTurnTime
			  )
			  VALUES
			  (
				    @BatchNumber,
				    @EcoLabWasherID,
				    @WasherGroupID,
				    @MachineNumber,
				    @PlantWasherNumber,
				    @StartDateTime,
				    @EndDateTime,
				    @ProgramNumber,
				    @ProgramMasterId,
				    @WasherID,
				    @Load,
				    @NominalLoad,
				    @CurrencyCode,
				    @ShiftID,
				    @ShiftStartdate,
				    @StdInjectionSteps,
				    @StdWashSteps,
				    @EcolabTextileCategoryId,
				    @ChainTextileCategoryId,
				    @FormulaSegmentId,
				    @EcolabSaturationId,
				    @PlantProgramId,
				    @EndDateTime,
				    @TargetTurnTime
			  );
			  SELECT @BatchID = SCOPE_IDENTITY();
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM TCD.BatchParameters
				 WHERE BatchId = @BatchID
					  AND ParameterID = 38
			  )
				 BEGIN
					IF(@StdWashSteps > 0
					   OR @StdWashSteps <> NULL)
					    INSERT INTO TCD.BatchParameters
					    (BatchId,
						EcolabWasherId,
						ParameterId,
						ParameterValue,
						PartitionOn
					    )
							 SELECT @BatchID,
								   @EcoLabWasherID,
								   38,
								   @StdWashSteps,
								   @ShiftStartdate;
				 END;
		   END;
	    ELSE
		   BEGIN
			  UPDATE tcd.BatchData
			    SET
				   EndDate = @EndDateTime,
				   EndDateFormula = @EndDateTime,
				   ProgramNumber = @ProgramNumber,
				   ProgramMasterId = @ProgramMasterID,
				   ActualWeight = @Load,
				   SyncReady = 1
			  WHERE BatchID = @BatchID;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT 1
		   FROM [TCD].[BatchCustomerData]
		   WHERE BatchID = @BatchId
			    AND @CustomerNumber IS NOT NULL
	    )
		   BEGIN
			  INSERT INTO [TCD].[BatchCustomerData]
			  ([BatchId],
			   CustomerID,
			   [Weight],
			   PartitionOn,
			   EcolabWasherId
			  )
			  VALUES
			  (
				    @BatchID,
				    @CustomerNumber,
				    @Load,
				    @ShiftStartdate,
				    @EcolabWasherID
			  );
		   END;
	    ELSE
	    IF(@CustomerNumber > 0)
		   BEGIN
			  UPDATE [TCD].[BatchCustomerData]
			    SET
				   CustomerID = @CustomerNumber,
				   [Weight] = @Load
			  WHERE BatchID = @BatchId;
		   END;
	    CREATE TABLE #Dosing
	    (
		    equipmentNo INT,
		    StepNo      INT,
		    Qty         DECIMAL(10, 6)
	    );
	    INSERT INTO #Dosing
			 SELECT T.c.value('@Equipment', 'INT'),
				   T.c.value('@stepNo', 'INT'),
				   T.c.value('@Qty', 'Decimal(10,6)')
			 FROM @VxML.nodes(
			 'MyControlConventionalData/DosingData/Dosing'
						  ) T(C)
			 WHERE T.c.value('@Qty', 'Decimal(10,6)') > 0;
	    CREATE TABLE #StepTime
	    (
		    Number    INT,
		    [Time]    INT,
		    StartTime DATETIME,
		    EndTime   DATETIME
	    );
	    INSERT INTO #StepTime
	    (Number,
		[Time]
	    )
			 SELECT T.c.value('@Number', 'INT'),
				   T.c.value('@Time', 'INT')
			 FROM @VxML.nodes('MyControlConventionalData/StepTime/Step')
			 T(C);
	    CREATE TABLE #TimeStamp
	    (
		    Step_Number INT,
		    Time_Stamp  INT
	    );
	
	    --For Calculating TIME_STAMP

	    WITH TempTable
		    AS (SELECT DISTINCT
					Number
			   FROM #StepTime)
		    INSERT INTO #TimeStamp
		    (Step_Number,
			Time_Stamp
		    )
				 SELECT b.Number,
					   SUM(t.Time) Time_Stamp
				 FROM TempTable b
					 INNER JOIN #StepTime t ON b.Number >= t.Number
				 GROUP BY b.Number;
	    CREATE TABLE #BatchProductData
	    (
		    equipmentNo INT,
		    StepNo      INT,
		    Qty         DECIMAL(10, 6),
		    Time_Stamp  DATETIME2(7)
	    );
	    INSERT INTO #BatchProductData
	    (equipmentNo,
		StepNo,
		Qty,
		Time_Stamp
	    )
			 SELECT d.equipmentNo,
				   d.StepNo,
				   d.Qty,
				   DATEADD(ss, ts.Time_Stamp, @StartDateTime)
			 FROM #Dosing d
				 INNER JOIN #TimeStamp ts ON d.StepNo = ts.Step_Number
	    ;


	    --END For calculating TIMESTAMP

	    INSERT INTO TCD.BatchProductData
	    (BatchId,
		StepCompartment,
		ActualQuantity,
		PartitionOn,
		EcolabWasherId,
		ProductId,
		TimeStamp
	    )
			 SELECT @BatchID,
				   b.StepNo,
				   b.Qty,
				   @ShiftStartdate,
				   @EcolabWasherId,
				   a.ProductId,
				   b.Time_Stamp
			 FROM TCD.ControllerEquipmentSetup a
				 INNER JOIN #BatchProductData b ON a.
				 ControllerEquipmentId = b.equipmentNo
			 WHERE b.equipmentNo > 0
				  AND b.Qty > 0
				  AND ControllerID = @ControllerID
				  AND a.ProductId IS NOT NULL
				  

	    --Start Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
	    SELECT @ActualInjSteps = COUNT(DISTINCT StepNo)
	    FROM #Dosing;
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.BatchParameters
		   WHERE ParameterId = 37
			    AND batchid = @BatchID
			    AND @ActualInjSteps > 0
	    )
		   BEGIN
			  IF(@ActualInjSteps > 0
				OR @ActualInjSteps IS NOT NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchId,
							@EcolabWasherId,
							37,
							@ActualInjSteps,
							@ShiftStartDate;
		   END;
	    ELSE
		   BEGIN
			  UPDATE TCD.BatchParameters
			    SET
				   ParameterValue = @ActualInjSteps
			  WHERE ParameterId = 37
				   AND batchid = @BatchID;
		   END;
	    SELECT @LastStep = MAX([Number])
	    FROM #StepTime
	    WHERE [Time] > 0;
	    SELECT @CurrentStep = 1,
			 @CurrentStepTime = @StartDateTime;
	    WHILE(@CurrentStep <= @LastStep)
		   BEGIN
			  UPDATE #StepTime
			    SET
				   StartTime = @CurrentStepTime,
				   EndTime = DATEADD(ss, [time], @CurrentStepTime)
			  WHERE Number = @CurrentStep;
			  SELECT @CurrentStepTime = EndTime
			  FROM #StepTime
			  WHERE Number = @CurrentStep;
			  SELECT @CurrentStep = @CurrentStep + 1;
		   END;
	    INSERT INTO [TCD].[BatchWashStepData]
	    (BatchID,
		StepCompartment,
		StartTime,
		EndTime,
		PartitionOn,
		EcolabWasherId
	    )
			 SELECT @BatchID,
				   Number,
				   StartTime,
				   EndTime,
				   @ShiftStartdate,
				   @EcoLabWasherID
			 FROM #StepTime
			 WHERE Number <= @LastStep;
	    SELECT @MinTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Mimum Temperature';
	    SELECT @MaxTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Maximum Temperature';
	    SELECT @MaxTempStatusParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Max Temperature Status';
	    SELECT @MinTempStatuParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Minimum Temperature Status';
	    SELECT @PHValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH';
	    SELECT @PHStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH Status';
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MinTempParamID
	    )
		   BEGIN
			  IF(@TemperatureMin <> 0
				OR @TemperatureMin <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(BatchId,
					 EcolabWasherId,
					 ParameterId,
					 ParameterValue,
					 PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MinTempParamID,
						  @TemperatureMin,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MaxTempParamID
	    )
		   BEGIN
			  IF(@TemperatureMax <> 0
				OR @TemperatureMax <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(BatchId,
					 EcolabWasherId,
					 ParameterId,
					 ParameterValue,
					 PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MaxTempParamID,
						  @TemperatureMax,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MaxTempStatusParamID
	    )
		   BEGIN
			  IF(@TempMaxStatus <> 0
				OR @TempMaxStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(BatchId,
					 EcolabWasherId,
					 ParameterId,
					 ParameterValue,
					 PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MaxTempStatusParamID,
						  @TempMaxStatus,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MinTempStatuParamID
	    )
		   BEGIN
			  IF(@TempMinStatus <> 0
				OR @TempMinStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(BatchId,
					 EcolabWasherId,
					 ParameterId,
					 ParameterValue,
					 PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MinTempStatuParamID,
						  @TempMinStatus,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF(@PHStatus <> 0
		  OR @PHStatus <> NULL)
		   BEGIN
			  INSERT INTO TCD.BatchParameters
			  (BatchId,
			   EcolabWasherId,
			   ParameterId,
			   ParameterValue,
			   PartitionOn
			  )
			  VALUES
			  (
				    @BatchID,
				    @EcoLabWasherID,
				    @PHStatusParamID,
				    @PHStatus,
				    @ShiftStartdate
			  );
		   END;
	    IF(@PHValue <> 0
		  OR @PHValue <> NULL)
		   BEGIN
			  INSERT INTO TCD.BatchParameters
			  (BatchId,
			   EcolabWasherId,
			   ParameterId,
			   ParameterValue,
			   PartitionOn
			  )
			  VALUES
			  (
				    @BatchID,
				    @EcoLabWasherID,
				    @PHValueParamID,
				    @PHValue,
				    @ShiftStartdate
			  );
		   END;
		    EXEC TCD.ProcessMyControlProductionWaterConsumptionData
			 @BatchID,
			 @VxML,
			 @ShiftStartDate
	    DROP TABLE #BatchProductData;
	    DROP TABLE #Dosing;
	    DROP TABLE #StepTime;
	    DROP TABLE #TimeStamp;
	END;



GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlTunnelWasherOnlineData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlTunnelWasherOnlineData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessMyControlTunnelWasherOnlineData](
	@ControllerID   INT,
	@xmlTags        XML,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @BatchID                 INT,
			  @WasherID                INT,
			  @EcolabWasherId          INT,
			  @CurrencyCode            VARCHAR(50),
			  @MachineInternalId       INT,
			  @WasherGroupID           INT,
			  @PlantWasherNumber       INT,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @BatchNumber             INT,
			  @TargetTurnTime          INT,
			  @PartitionOn             DATETIME,
			  @BatchStartTime          DATETIME,
			  @ProgramID               INT,
			  @NumberOfCompartments    INT,
			  @TransferSignalId        INT,
			  @BatchShiftId            INT,
			  @compartmentID           INT,
			  @TunnelXML               XML,
			  @TempXML                 XML,
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT;
	    SELECT @TransferSignalId = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Transfer Signal';
	    CREATE TABLE #Batches
	    (
		    BatchNumber   INT,
		    StartDateTime DATETIME
	    );
	    -- SET @compartmentID = 1;

	    SELECT @TempXML = T.c.query('.')
	    FROM @xmlTags.nodes('MyControlTunnel') AS T(c);
	    SELECT @MachineInternalID = T.c.value('@MachineNumber', 'int')
	    FROM @TempXML.nodes('MyControlTunnel') AS T(c);
	    SELECT @EcolabWasherID = EcolabWasherId,
			 @WasherGroupID = Wg.WasherGroupId,
			 @PlantWasherNumber = PlantWasherNumber,
			 @WasherID = ws.WasherId,
			 @CurrencyCode = P.CurrencyCode,
			 @NumberOfCompartments = Mst.NumberofComp
	    FROM TCD.Washer AS Ws
		    INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = Ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.
		    GroupId
		    INNER JOIN TCD.WasherGroupType AS WgT ON WgT.
		    WasherGroupTypeId = Wg.WasherGroupTypeId
		    INNER JOIN TCD.ConduitController AS Ctrl ON Ctrl.
		    ControllerId = Mst.ControllerId
		    INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.
		    EcoLabAccountNumber
	    WHERE Ctrl.ControllerID = @ControllerID
			AND mst.MachineInternalId = @MachineInternalID
			AND Mst.IsTunnel = 1 AND Mst.IsDeleted =0;
	    SET @compartmentID = @NumberOfCompartments;
	    WHILE(@compartmentID <= @NumberOfCompartments
			AND @compartmentID > 0)
		   BEGIN
			  SELECT @TunnelXML = T.c.query('.')
			  FROM @xmlTags.nodes('MyControlTunnel/TunnelData') AS T(c)
			  WHERE T.c.value('@CompartmentNumber', 'INT') =
			  @compartmentID;
			  SELECT @MachineInternalID = T.c.value('@MachineNumber',
			  'int'
										    ),
				    @BatchNumber = T.c.value('@BatchNumber', 'INT'),
				    @BatchStartTime = T.c.value('@StartDateTime',
				    'DateTime'
										 ),
				    @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
				    @Load = T.c.value('@Load', 'Decimal(10,6)')/10,
				    @NominalLoad = T.c.value('@Nominalload',
				    'Decimal(10,6)'
									   ),
				    @CustomerNumber = T.c.value('@CustomerNumber',
				    'int'
										 ),
				    @PHStatus = T.c.value('@pHStatus', 'int')
			  FROM @TunnelXML.nodes('TunnelData') AS T(c);
			  DECLARE @ShiftStartDateTemp TABLE
			  (
				  ShiftId        INT,
				  ShiftName      NVARCHAR(50),
				  ShiftStartdate DATETIME
			  );
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchStartTime
			  SELECT @BatchShiftId = ShiftID,
				    @PartitionOn = ShiftStartdate
			  FROM @ShiftStartDateTemp;
			  IF(@ProgramNumber = 0
				OR @BatchNumber = 1)
				 BEGIN
					SELECT @compartmentID = @compartmentID - 1;
					CONTINUE;
				 END;
			  SELECT @ProgramID = ProgramId,
				    @TargetTurnTime = 3600 / (tps.TotalRunTime /
				    @NumberOfCompartments)
			  FROM TCD.TunnelProgramSetup AS tps
			  WHERE tps.WasherGroupId = @WasherGroupID
				   AND tps.is_deleted = 0
				   AND ProgramNumber = @ProgramNumber;
			  INSERT INTO #Batches
			  (BatchNumber,
			   StartDateTime
			  )
				    SELECT @BatchNumber,
						 @BatchStartTime;
			  SELECT @BatchID = NULL;
			  SELECT @BatchID = BatchID
			  FROM TCD.BatchData AS BD
			  WHERE BD.ControllerBatchId = @BatchNumber
				   AND BD.StartDate = @BatchStartTime
				   AND BD.MachineId = @WasherID;
			  --Start Getting InjectionCount,StepCount And ProductCount
			  SELECT @StdInjectionSteps = COUNT(tdpm.
			  TunnelDosingSetupId),
				    @StdWashSteps = COUNT(DISTINCT tds.
				    TunnelDosingSetupId) - COUNT(tdpm.
				    TunnelDosingSetupId)
			  FROM tcd.TunnelDosingProductMapping AS tdpm
				  RIGHT JOIN tcd.TunnelDosingSetup AS tds ON tdpm.
				  TunnelDosingSetupId = tds.TunnelDosingSetupId
			  WHERE tds.GroupId = @WasherGroupID
				   AND tds.ProgramNumber = @ProgramNumber;
			  --End Getting InjectionCount,StepCount And ProductCount
			  --Start-----ProgramMasterID logic for PlantChainProgram
			  SELECT @PlantProgramId = pm.PlantProgramId,
				    @EcolabTextileCategoryId = pm.
				    EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pm.ChainTextileId,
				    @FormulaSegmentId = pm.FormulaSegmentId,
				    @EcolabSaturationId = pm.EcolabSaturationId
			  FROM TCD.ProgramMaster AS pm
			  WHERE pm.ProgramId = @ProgramID
				   AND pm.Is_Deleted = 0;
			  IF(@PlantProgramId <> 0
				OR @PlantProgramId IS NOT NULL)
				 BEGIN
					--Assign value from plantchainprogram table based on plantprogramId
					SELECT @EcolabTextileCategoryId = pcp.
					EcolabTextileCategoryId,
						  @ChainTextileCategoryId = pcp.
						  ChainTextileCategoryId,
						  @FormulaSegmentId = pcp.FormulaSegmentId,
						  @EcolabSaturationId = pcp.
						  EcolabSaturationId
					FROM tcd.PlantChainProgram AS pcp
					WHERE pcp.PlantProgramId = @PlantProgramId
						 AND pcp.Is_Deleted = 0;
				 END;
			  --End-----ProgramMasterID logic for PlantChainProgram
			  IF @BatchID IS NULL
				 BEGIN
					INSERT INTO TCD.BatchData
					(ControllerBatchId,
					 EcolabWasherId,
					 GroupId,
					 MachineInternalId,
					 PlantWasherNumber,
					 StartDate,
					 ProgramNumber,
					 ProgramMasterId,
					 MachineId,
					 ActualWeight,
					 StandardWeight,
					 CurrencyCode,
					 ShiftId,
					 PartitionOn,
					 TargetTurnTime,
					 StdInjectionSteps,
					 StdWashSteps,
					 EcolabTextileCategoryId,
					 ChainTextileCategoryId,
					 FormulaSegmentId,
					 EcolabSaturationId,
					 PlantProgramId
					)
						  SELECT @BatchNumber,
							    @EcolabWasherID,
							    @WasherGroupID,
							    @MachineInternalID,
							    @PlantWasherNumber,
							    @BatchStartTime,
							    @ProgramNumber,
							    @ProgramID,
							    @WasherID,
							    @Load,
							    @NominalLoad,
							    @CurrencyCode,
							    @BatchShiftId,
							    @PartitionOn,
							    @TargetTurnTime,
							    @StdInjectionSteps,
							    @StdWashSteps,
							    @EcolabTextileCategoryId,
							    @ChainTextileCategoryId,
							    @FormulaSegmentId,
							    @EcolabSaturationId,
							    @PlantProgramId;
					SELECT @BatchID = SCOPE_IDENTITY();
					IF(@StdWashSteps > 0
					   OR @StdWashSteps <> NULL)
					    BEGIN
						   INSERT INTO TCD.BatchParameters
						   (BatchId,
						    EcolabWasherId,
						    ParameterId,
						    ParameterValue,
						    PartitionOn
						   )
								SELECT @BatchID,
									  @EcolabWasherId,
									  38,
									  @StdWashSteps,
									  @PartitionOn;
					    END;
					IF @CustomerNumber IS NOT NULL
					    BEGIN
						   IF NOT EXISTS
						   (
							  SELECT 1
							  FROM TCD.BatchCustomerData
							  WHERE BatchID = @BatchID
						   )
							  BEGIN
								 INSERT INTO TCD.BatchCustomerData
								 (BatchId,
								  CustomerID,
								  Weight,
								  PartitionOn,
								  EcolabWasherId
								 )
									   SELECT @BatchID,
											@CustomerNumber,
											@Load,
											@PartitionOn,
											@EcolabWasherId;
							  END;
					    END;
				 END;
			  -- Transfer Signal
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM tcd.WasherReading wr
				 WHERE wr.WasherId = @WasherID
					  AND wr.ParameterId = @TransferSignalId
					  AND wr.DateTimeStamp = @BatchStartTime
			  )
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterId,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TransferSignalId,
							    1,
							    @BatchStartTime,
							    @PartitionOn,
							    @EcolabWasherId
						  UNION ALL
						  SELECT @WasherID,
							    @TransferSignalId,
							    0,
							    @BatchStartTime,
							    @PartitionOn,
							    @EcolabWasherId;
				 END;
			  --Start Updating Batch Wash Step Data	 
			  EXEC TCD.UPDATEBatchWashStepForTunnel
				  @TunnelXML,
				  @WasherID,
				  @BatchID,
				  @BatchStartTime,
				  @PartitionOn,
				  @EcolabWasherId,
				  @compartmentID;
			  --End Updating Batch Wash Step Data	 
			  SELECT @compartmentID = @compartmentID - 1;
		   END;
	END;

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlTunnelWasherProdData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlTunnelWasherProdData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [TCD].[ProcessMyControlTunnelWasherProdData](
	@ControllerID   INT,
	@xmlTags        XML,
	@PLCPointer     INT,
	@ReadPointer    INT,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @BatchID                   INT,
			  @WasherID                  INT,
			  @EcolabWasherId            INT,
			  @CurrencyCode              VARCHAR(50),
			  @MachineInternalId         INT,
			  @WasherGroupID             INT,
			  @PlantWasherNumber         INT,
			  @ProgramNumber             INT,
			  @Load                      DECIMAL(10, 2),
			  @NominalLoad               DECIMAL(10, 2),
			  @CustomerNumber            INT,
			  @PHStatus                  INT,
			  @PHValue                   INT,
			  @LFStatus                  INT,
			  @LFValue                   INT,
			  @BatchNumber               INT,
			  @TargetTurnTime            INT,
			  @PartitionOn               DATETIME2,
			  @BatchStartTime            DATETIME2,
			  @BatchEndTime              DATETIME2,
			  @ProgramID                 INT,
			  @NumberOfCompartments      INT,
			  @ProductId                 INT,
			  @CompartmentNum            INT,
			  @EquipmentType             INT,
			  @MinTempParamID            INT,
			  @MaxTempParamID            INT,
			  @TempStatusParamID         INT,
			  @PHValueParamID            INT,
			  @PHStatusParamID           INT,
			  @ConductivityValueParamID  INT,
			  @ConductivityStatusParamID INT,
			  @StdInjectionSteps         INT,
			  @StdWashSteps              INT,
			  @ActualInjSteps            INT,
			  @EcolabTextileCategoryId   INT,
			  @ChainTextileCategoryId    INT,
			  @FormulaSegmentId          INT,
			  @EcolabSaturationId        INT,
			  @PlantProgramId            INT,
			  @PreviousShiftId		    INT,
			  @CurrentShiftId		    INT;
	    DECLARE @BatchShiftId INT;
	    DECLARE @ShiftStartDateTemp TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    DECLARE @TunnelXML XML;
	    SELECT @TunnelXML = T.c.query('.')
	    FROM @xmlTags.nodes('MyControlTunnel/TunnelData') T(c)
	    WHERE T.c.value('@CompartmentNumber', 'INT') = 0;
	    SELECT @MachineInternalID = T.c.value('@MachineNumber', 'int'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @BatchStartTime = T.c.value('@StartDateTime', 'DateTime'),
			 @BatchEndTime = T.c.value('@EndDateTime', 'DateTime'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@Nominalload', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'int'),
			 @PHStatus = T.c.value('@Phstatus', 'int'),
			 @PHValue = T.c.value('@Phvalue', 'INT'),
			 @LFStatus = T.c.value('@LFStatus', 'INT'),
			 @LFValue = T.c.value('@LFValue', 'INT')
	    FROM @xmlTags.nodes('MyControlTunnel/TunnelData') T(c);
	    SELECT @EcolabWasherID = Ws.EcolabWasherId,
			 @WasherGroupID = Wg.WasherGroupId,
			 @PlantWasherNumber = PlantWasherNumber,
			 @WasherID = ws.WasherId,
			 @CurrencyCode = P.CurrencyCode,
			 @NumberOfCompartments = Mst.NumberofComp
	    FROM TCD.Washer Ws
		    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.
		    GroupId
		    INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId
		    = Wg.WasherGroupTypeId
		    INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId =
		    Mst.ControllerId
		    INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.
		    EcoLabAccountNumber
	    WHERE Ctrl.ControllerID = @ControllerID
			AND Mst.MachineInternalId = @MachineInternalID
			AND Mst.IsTunnel = 1 AND Mst.IsDeleted=0;
	    SELECT @EcolabWasherID;
	    SELECT @ProgramID = ProgramId,
			 @TargetTurnTime = (3600 / (tps.TotalRunTime /
			 @NumberOfCompartments))
	    FROM TCD.TunnelProgramSetup AS tps
	    WHERE tps.WasherGroupId = @WasherGroupID
			AND tps.is_deleted = 0
			AND ProgramNumber = @ProgramNumber;
	    DELETE FROM @ShiftStartDateTemp;
	    IF(@BatchEndTime IS NOT NULL)
		   BEGIN
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchEndTime
		   END;
	    ELSE
		   BEGIN
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchStartTime
		   END;
	    SELECT @BatchShiftId = ShiftID,
			 @PartitionOn = ShiftStartdate
	    FROM @ShiftStartDateTemp;


	    --Start Getting InjectionCount,StepCount And ProductCount
	    SELECT @StdInjectionSteps = COUNT(tdpm.TunnelDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT tds.TunnelDosingSetupId) -
			 COUNT(tdpm.TunnelDosingSetupId)
	    FROM tcd.TunnelDosingProductMapping tdpm
		    RIGHT JOIN tcd.TunnelDosingSetup tds ON tdpm.
		    TunnelDosingSetupId = tds.TunnelDosingSetupId
	    WHERE tds.GroupId = @WasherGroupID
			AND tds.ProgramNumber = @ProgramNumber;
	    --End Getting InjectionCount,StepCount And ProductCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramID
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT @EcolabTextileCategoryId = pcp. EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp. ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    SELECT @BatchID = NULL;
	    SELECT @BatchID = BatchID
	    FROM TCD.BatchData BD
	    WHERE BD.ControllerBatchId = @BatchNumber
			AND BD.StartDate = @BatchStartTime
			AND BD.MachineId = @WasherID;
	    --AND BD.MachineInternalID = @MachineInternalID
	    IF(@BatchID IS NULL)
		   BEGIN
		   --Start Rollup for previous completed shift
	   IF(CAST(@BatchStartTime as date) < CAST(GETUTCDATE() as date))
	   BEGIN
		  SELECT TOP 1 @PreviousShiftId=ShiftId FROM TCD.BatchData WHERE MachineId=@WasherId ORDER BY StartDate DESC	   
		  SELECT Top 1 @CurrentShiftId = ShiftId from @ShiftStartDateTemp
		  IF(@CurrentShiftId != @PreviousShiftId)
		  BEGIN
			 EXEC TCD.ProductionShiftDataRollup @PreviousShiftId, @RedFlagShiftId OUTPUT
			 IF(@RedFlagShiftId IS NULL)
			 BEGIN
				SET @RedFlagShiftId = @PreviousShiftId
			 END
		  END
	   END
	   --End Rollup for previous completed shift
			  INSERT INTO TCD.BatchData
			  (ControllerBatchId,
			   EcolabWasherId,
			   GroupId,
			   MachineInternalId,
			   PlantWasherNumber,
			   StartDate,
			   EndDate,
			   ProgramNumber,
			   ProgramMasterId,
			   MachineId,
			   ActualWeight,
			   StandardWeight,
			   CurrencyCode,
			   ShiftId,
			   PartitionOn,
			   TargetTurnTime,
			   StdInjectionSteps,
			   StdWashSteps,
			   EcolabTextileCategoryId,
			   ChainTextileCategoryId,
			   FormulaSegmentId,
			   EcolabSaturationId,
			   PlantProgramId,
			   EndDateFormula
			  )
				    SELECT @BatchNumber,
						 @EcolabWasherID,
						 @WasherGroupID,
						 @MachineInternalID,
						 @PlantWasherNumber,
						 @BatchStartTime,
						 @BatchEndTime,
						 @ProgramNumber,
						 @ProgramID,
						 @WasherID,
						 @Load,
						 @NominalLoad,
						 @CurrencyCode,
						 @BatchShiftId,
						 @PartitionOn,
						 @TargetTurnTime,
						 @StdInjectionSteps,
						 @StdWashSteps,
						 @EcolabTextileCategoryId,
						 @ChainTextileCategoryId,
						 @FormulaSegmentId,
						 @EcolabSaturationId,
						 @PlantProgramId,
						 @BatchEndTime;
			  SELECT @BatchID = SCOPE_IDENTITY();
			  IF(@StdWashSteps > 0
				OR @StdWashSteps <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchID,
							@EcolabWasherId,
							38,
							@StdWashSteps,
							@PartitionOn;
			  EXEC TCD.UPDATEBatchWashStepForTunnel
				  @TunnelXML,
				  @WasherID,
				  @BatchID,
				  @BatchStartTime,
				  @PartitionOn,
				  @EcolabWasherId,
				  @NumberOfCompartments;
		   END;
	    IF(@BatchEndTime IS NOT NULL
		  AND @BatchEndTime != '01/01/1900')
		   BEGIN
			  UPDATE TCD.BatchData
			    SET
				   EndDate = @BatchEndTime,
				   ShiftId = @BatchShiftId,
				   PartitionOn = @PartitionOn,
				   EndDateFormula=@BatchEndTime
			  WHERE BATCHID = @BatchID;
		   END;
	    IF(@CustomerNumber IS NOT NULL)
		   BEGIN
			  IF NOT EXISTS
			  (
				 SELECT 1
				 FROM [TCD].[BatchCustomerData]
				 WHERE BatchID = @BatchID
			  )
				 BEGIN
					INSERT INTO [TCD].[BatchCustomerData]
					([BatchId],
					 CustomerID,
					 [Weight],
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @BatchID,
							    @CustomerNumber,
							    @Load,
							    @PartitionOn,
							    @EcolabWasherId;
				 END;
		   END;
	    CREATE TABLE #DosingDetails
	    (
		    Number          INT,
		    Quantity        DECIMAL(10, 6),
		    Point           INT,
		    IsMainEquioment INT
	    );
	    INSERT INTO #DosingDetails
	    (Number,
		Quantity,
		Point,
		IsMainEquioment
	    )
			 SELECT T.c.value('@Number', 'INT') AS Number, --PumpNumber
				   T.c.value('@Quantity', 'Decimal(10,6)') AS Quantity, --Dosing Quanity
				   T.c.value('@Point', 'INT') AS Point, --Dosing point
				   T.c.value('@IsMainEquioment', 'INT') AS
			 IsMainEquioment
			 FROM @xmlTags.nodes('MyControlTunnel/TunnelData/Dose') T(C)
	    ;
	
	    -- Fetching data from cursor
	    DECLARE @MYCURSOR CURSOR;
	    SET @MYCURSOR = CURSOR FAST_FORWARD
	    FOR SELECT Number,
				Quantity,
				Point,
				IsMainEquioment
		   FROM #DosingDetails;
	    DECLARE @Number          INT,
			  @Quantity        DECIMAL(10, 6),
			  @Point           INT,
			  @IsMainEquioment INT;
	    OPEN @MYCURSOR;
	    FETCH NEXT FROM @MYCURSOR INTO @Number,
								@Quantity,
								@Point,
								@IsMainEquioment;
	    WHILE @@FETCH_STATUS = 0
		   BEGIN
			  IF(@IsMainEquioment = 1)
				 BEGIN
					SET @EquipmentType = 2;
				 END;
			  ELSE
				 BEGIN
					SET @EquipmentType = 1;
				 END;
			  SELECT @ProductId = CES.ProductId,
				    @CompartmentNum = TCEVM.CompartmentNumber
			  FROM tcd.ControllerEquipmentSetup CES
				  INNER JOIN TCD.
				  TunnelCompartmentEquipmentValveMapping TCEVM ON CES.
				  ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
			  WHERE CES.ControllerId = @ControllerID
				   AND CES.ControllerEquipmentTypeId = @EquipmentType
				   AND --CES.IsActive=1 AND
				   --CES.WasherGroupNumber=@WasherGroupNum AND
				   TCEVM.DosingPointNumber = @Point
				   AND CES.ControllerEquipmentId = @Number;
				
			  --SELECT @EcolabWasherID
			  IF(@ProductId IS NOT NULL)
				 BEGIN
					INSERT INTO TCD.BatchProductData
					(BatchId,
					 StepCompartment,
					 ActualQuantity,
					 [TimeStamp],
					 PartitionOn,
					 EcolabWasherId,
					 ProductId
					)
						  SELECT @BatchID,
							    @CompartmentNum,
							    @Quantity,
							    @BatchEndTime,
							    @PartitionOn,
							    @EcolabWasherID,
							    @ProductId;
				 END;
			  FETCH NEXT FROM @MYCURSOR INTO @Number,
									   @Quantity,
									   @Point,
									   @IsMainEquioment;
		   END;
	    CLOSE @MYCURSOR;
	    DEALLOCATE @MYCURSOR;
	    DROP TABLE #DosingDetails;
	    SELECT @ActualInjSteps = COUNT(DISTINCT StepCompartment)
	    FROM TCD.BatchProductData
	    WHERE BatchId = @BatchID;
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.BatchParameters
		   WHERE ParameterId = 37
			    AND batchid = @BatchID
			    AND @ActualInjSteps > 0
	    )
		   BEGIN
			  IF(@ActualInjSteps > 0
				OR @ActualInjSteps <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchId,
							@EcolabWasherId,
							37,
							@ActualInjSteps,
							@PartitionOn;
		   END;
	    ELSE
		   BEGIN
			  UPDATE TCD.BatchParameters
			    SET
				   ParameterValue = @ActualInjSteps
			  WHERE ParameterId = 37
				   AND batchid = @BatchID;
		   END;
	    SELECT @MinTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Mimum Temperature';
	    SELECT @MaxTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Maximum Temperature';
	    SELECT @TempStatusParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Temperature Status';
	    SELECT @PHValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH';
	    SELECT @PHStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH Status';
	    SELECT @ConductivityValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Conductivity';
	    SELECT @ConductivityStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'LF Status';
	    IF(@PHValue IS NOT NULL)
		   BEGIN
			  --pH Value
			  IF(@PHValue <> 0
				OR @PHValue <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @PHValueParamID,
					   @PHValue,
					   @PartitionOn
				 );

			  --pH Status
			  IF(@PHStatus <> 0
				OR @PHStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @PHStatusParamID,
					   @PHStatus,
					   @PartitionOn
				 );
		   END;
	    IF(@LFValue IS NOT NULL)
		   BEGIN
			  --Conductivity Value
			  IF(@LFValue <> 0
				OR @LFValue <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @ConductivityValueParamID,
					   @LFValue,
					   @PartitionOn
				 );

			  --Conductivity Status
			  IF(@LFStatus <> 0
				OR @LFStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @ConductivityStatusParamID,
					   @LFStatus,
					   @PartitionOn
				 );
		   END;
	    CREATE TABLE #TemperatureDetails
	    (
		    MinimumTemp DECIMAL(10, 2),
		    MaximumTemp DECIMAL(10, 2),
		    TempStatus  DECIMAL(10, 2)
	    );
	    INSERT INTO #TemperatureDetails
	    (MinimumTemp,
		MaximumTemp,
		TempStatus
	    )
			 SELECT T.c.value('@Minimum', 'Decimal(10,2)') AS
			 MinimumTemp,
				   T.c.value('@Maximum', 'Decimal(10,2)') AS
				   MaximumTemp,
				   T.c.value('@Status', 'Decimal(10,2)') AS TempStatus
			 FROM @xmlTags.nodes(
			 'MyControlTunnel/TunnelData/TemperatureData'
							) T(c);
	  
	    -- Fetching data from cursor
	    DECLARE @TEMPCURSOR CURSOR;
	    SET @TEMPCURSOR = CURSOR FAST_FORWARD
	    FOR SELECT MinimumTemp,
				MaximumTemp,
				TempStatus
		   FROM #TemperatureDetails;
	    DECLARE @MinimumTemp DECIMAL(10, 2),
			  @MaximumTemp DECIMAL(10, 2),
			  @TempStatus  DECIMAL(10, 2);
	    OPEN @TEMPCURSOR;
	    FETCH NEXT FROM @TEMPCURSOR INTO @MinimumTemp,
								  @MaximumTemp,
								  @TempStatus;
	    WHILE @@FETCH_STATUS = 0
		   BEGIN	
			  --Minimum Temperature
			  IF(@MinimumTemp <> 0
				OR @MinimumTemp <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @MinTempParamID,
					   @MinimumTemp,
					   @PartitionOn
				 );

			  --Maximum Temperature
			  IF(@MaximumTemp <> 0
				OR @MaximumTemp <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @MaxTempParamID,
					   @MaximumTemp,
					   @PartitionOn
				 );

			  --Temperature Status
			  IF(@TempStatus <> 0
				OR @TempStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @TempStatusParamID,
					   @TempStatus,
					   @PartitionOn
				 );
			  FETCH NEXT FROM @TEMPCURSOR INTO @MinimumTemp,
										@MaximumTemp,
										@TempStatus;
		   END;
	    CLOSE @TEMPCURSOR;
	    DEALLOCATE @TEMPCURSOR;
	    DROP TABLE #TemperatureDetails;
	    UPDATE TCD.BatchWashStepData
		 SET
			EndTime = @BatchEndTime
	    WHERE BatchId = @BatchID
			AND EndTime IS NULL;
	END;



GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlOnlineProductDosing]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlOnlineProductDosing]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [TCD].[ProcessMyControlOnlineProductDosing](
	@ControllerID INT,
	@VxML         XML)
AS
	BEGIN
	    DECLARE @TheoreticalQty    DECIMAL(10, 6),
			  @RealQty           DECIMAL(10, 6),
			  @BatchNumber       INT,
			  @DosingPoint       INT,
			  @DosingNumber      INT,
			  @ValveNumber       INT,
			  @ProgramNumber     INT,
			  @WasherId          INT,
			  @MachineInternalId INT,
			  @PrevRealQty       DECIMAL(10, 6),
			  @ProductId         INT,
			  @PumpNum           INT,
			  @EquipmentType     INT,
			  @CompartmentNum    INT;
	    SELECT @TheoreticalQty = T.c.value('@TheoreticalQty','Decimal(10,6)'),
			 @RealQty = T.c.value('@RealQty', 'Decimal(10,6)'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @DosingPoint = T.c.value('@DosingPoint', 'INT'),
			 @DosingNumber = T.c.value('@DoseNumber', 'INT'),
			 @PumpNum = T.c.value('@PumpNum', 'INT'),
			 @ValveNumber = T.c.value('@ValveNumber', 'INT')
	    FROM @VxML.nodes('MyControlOnlineProductDosing') T(C);
	    IF(@PumpNum >= 25
		  AND @PumpNum <= 26)
		   BEGIN
			  SET @EquipmentType = 2;
		   END;
	    ELSE
		   BEGIN
			  SET @EquipmentType = 1;
		   END;
	    IF(@DosingPoint >= 17
		  AND @DosingPoint <= 20)
		   BEGIN
			  SET @MachineInternalId = 1;
		   END;
	    ELSE
	    IF(@DosingPoint >= 21
		  AND @DosingPoint <= 24)
		   BEGIN
			  SET @MachineInternalId = 2;
		   END;
	    IF(@DosingPoint >= 1
		  AND @DosingPoint <= 16)
		   BEGIN
			  SET @MachineInternalId = @DosingPoint;
			  SELECT @WasherId = WasherId
			  FROM TCD.MachineSetup
			  WHERE ControllerID = @ControllerID
				   AND MachineInternalId = @MachineInternalId
				   AND IsTunnel = 0
				   AND IsDeleted = 0;
			  SELECT @ProductId = ProductId
			  FROM TCD.ControllerEquipmentSetup
			  WHERE ControllerEquipmentId = @PumpNum
				   AND ControllerID = @ControllerID;
		   END;
	    ELSE
	    IF(@DosingPoint >= 17
		  AND @DosingPoint <= 24)
		   BEGIN
			  SELECT @WasherId = WasherId
			  FROM TCD.MachineSetup
			  WHERE ControllerID = @ControllerID
				   AND MachineInternalId = @MachineInternalId
				   AND IsTunnel = 1
				   AND IsDeleted = 0;
			  SELECT @ProductId = CES.ProductId,
				    @CompartmentNum = TCEVM.CompartmentNumber
			  FROM tcd.ControllerEquipmentSetup CES
				  INNER JOIN TCD.
				  TunnelCompartmentEquipmentValveMapping TCEVM ON CES.
				  ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
			  WHERE CES.ControllerId = @ControllerID
				   AND CES.ControllerEquipmentTypeId = @EquipmentType
				   AND TCEVM.ValveNumber = @ValveNumber
				   AND CES.ControllerEquipmentId = @PumpNum;
		   END;
	    SELECT TOP 1 @PrevRealQty = RealQty
	    FROM TCD.WasherProductReading
	    WHERE ControllerId = @ControllerID
			AND WasherId = @WasherId
	    ORDER BY DateTimeStamp DESC;
	    IF(@ProductId IS NOT NULL)
		   BEGIN
			  IF(@PrevRealQty IS NULL
				OR @PrevRealQty != @RealQty)
				 BEGIN
					INSERT INTO [TCD].[WasherProductReading]
					(ControllerId,
					 WasherId,
					 MachineInternalId,
					 ProductId,
					 TheoreticalQty,
					 RealQty,
					 DosingPoint,
					 DosingNumber,
					 ProgramNumber,
					 BatchNumber,
					 ValveNumber,
					 DateTimeStamp
					)
						  SELECT @ControllerId,
							    @WasherId,
							    @MachineInternalId,
							    @ProductId,
							    @TheoreticalQty,
							    @RealQty,
							    @DosingPoint,
							    @DosingNumber,
							    @ProgramNumber,
							    @BatchNumber,
							    @ValveNumber,
							    GETUTCDATE();
				 END;
		   END;
	END

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[UPDATEBatchWashStepForTunnel]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[UPDATEBatchWashStepForTunnel]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [TCD].[UPDATEBatchWashStepForTunnel](
	@TunnelXML      XML,
	@WasherID       INT,
	@BatchID        INT,
	@BatchStartTime DATETIME,
	@PartitionOn    DATETIME,
	@EcolabWasherId INT,
	@CurrentStep    INT)
AS
	BEGIN
	    DECLARE @StepStart     DATETIME,
			  @StepEnd       DATETIME,
			  @CompartmentNo INT,
			  @Duration      INT,
			  @LaspStep      INT,
			  @RowCount      INT;
	    CREATE TABLE #BatchStep
	    (
		    CompartmentNo INT,
		    TimeStep      INT,
		    StartDateTime DATETIME,
		    EndDateTime   DATETIME
	    );
	    INSERT INTO #BatchStep
	    (
			 CompartmentNo,
			 TimeStep
	    )
	    SELECT T.c.value('@CompartmentNo', 'INT') AS CompartmentNo,
			 T.c.value('@Time', 'INT') AS [Time]
	    FROM @TunnelXML.nodes('TunnelData/CompartmentTime') T(c)
	    ORDER BY 1;
	    SELECT @CompartmentNo = 1,
			 @StepStart = @BatchStartTime;
	    WHILE(@CompartmentNo <= @CurrentStep AND @CompartmentNo > 0)
		   BEGIN
			  SELECT @Duration = TimeStep
			  FROM #BatchStep
			  WHERE CompartmentNo = @CompartmentNo;
			  SELECT @StepEnd = DATEADD(ss, @Duration, @StepStart);
			  IF(@CompartmentNo = @CurrentStep)
				 SELECT @StepEnd = NULL;
			  UPDATE BWS
			    SET
				   StartTime = @StepStart,
				   EndTime = @StepEnd
			  FROM TCD.BatchWashStepData BWS
			  WHERE BatchId = @BatchID
				   AND StepCompartment = @CompartmentNo;
			  SELECT @RowCount = @@RowCount;
			  IF(@RowCount = 0)
				 BEGIN
					INSERT INTO TCD.BatchWashStepData
					(BatchId,
					 StepCompartment,
					 StartTime,
					 EndTime,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @BatchID,
							    @CompartmentNo,
							    @StepStart,
							    @StepEnd,
							    @PartitionOn,
							    @EcolabWasherId;
				 END; --IF (@RowCount = 0)
			  SELECT @CompartmentNo = @CompartmentNo + 1;
			  SELECT @StepStart = @StepEnd;
		   END; --WHILE (@CompartmentNo <=@LaspStep)
	    DROP TABLE #BatchStep;
	END;

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetWasherBatchTrendingData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetWasherBatchTrendingData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [TCD].[GetWasherBatchTrendingData](
	@DashBoardId         INT           = NULL,
	@EcolabAccountNumber NVARCHAR(25) = NULL,
	@StartTimeHrs        DATETIME      = NULL,
	@EndTimeHrs          DATETIME      = NULL)
AS
	BEGIN
	    SET NOCOUNT ON;              --SQLEnlight SA0017

	    SET @EcolabAccountNumber = ISNULL(@EcolabAccountNumber, NULL);   --SQLEnlight SA0029

	    SELECT DISTINCT
			 MS.GroupId,
			 MS.WasherID,
			 BD.BatchId,
			 Bd.ProgramMasterId,
			 PM.Name AS ProgramName,
			 DATEDIFF(SECOND, @StartTimeHrs, BD.StartDate) AS StartTime,
			 DATEDIFF(SECOND, @StartTimeHrs, BD.StartDate) + WPS.
			 TotalRunTime AS StandardEndTime,
			 DATEDIFF(SECOND, @StartTimeHrs, BD.EndDate) AS
			 ActualEndTime,
			 --Isnull(W.TargetTurnTime,10)* 60 as StandardTurnTime,
			 Isnull(BD.TargetTurnTime, 0) AS StandardTurnTime,
			 CASE
				WHEN BD.EndDate IS NULL
				THEN 1
				ELSE 0
			 END AS RunningStatus,
			 D.Formula AS DisplayFormula,
			 WPS.ProgramNumber,
			 D.DisplayFormulaType
	    FROM [TCD].MonitorSetUpMapping DM
		    INNER JOIN [TCD].MachineSetup MS ON DM.MachineId = MS. WasherID
		    INNER JOIN [TCD].Dashboard D ON DM.DashBoardId = D.DashBoardId
		    INNER JOIN [TCD].BatchData BD ON BD.MachineId = MS.WasherID
		    INNER JOIN [TCD].ProgramMaster PM ON PM.ProgramId = BD.ProgramMasterId
		    INNER JOIN [TCD].WasherProgramSetup WPS ON WPS.ProgramNumber = BD.ProgramNumber
											  AND  (WPS.ControllerID = MS.ControllerId 
											 OR WPS.WasherGroupId = MS.GroupId)
		    LEFT OUTER JOIN [TCD].Washer W ON W.WasherId = MS.WasherID
	    WHERE DM.DashboardId = @DashBoardId
			AND ((BD.StartDate >= DATEADD(HOUR, -1, @StartTimeHrs)
				 OR DATEADD(HOUR, -1, @StartTimeHrs) BETWEEN BD.StartDate AND BD.EndDate)
				OR (BD.EndDate IS NULL))
			AND WPS.Is_Deleted = 0
	    ORDER BY MS.WasherId,
			   BD.BatchId;
	END;

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetPlantInfo]') AND type in (N'P', N'PC'))
DROP PROCEDURE [TCD].[GetPlantInfo]

GO
CREATE PROCEDURE [TCD].[GetPlantInfo]
AS

BEGIN

SET nocount ON;

SELECT 
p.EcolabAccountNumber,
p.Name,
p.IsETechEnable,
p.ETechIpAddress,
p.ETechTimeDiff
FROM   [TCD].plant P WHERE   Is_Deleted      = 0

SET nocount OFF;
END

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetWasherBatchSummarizedData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetWasherBatchSummarizedData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[GetWasherBatchSummarizedData](
	@DashBoardId INT = NULL)
AS
	BEGIN
	    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	    SET NOCOUNT ON;
	    DECLARE   --@DashBoardId int = 1, 
	    @Washerid                INT      = NULL,
	    @Standardturntime        INT      = NULL,
	    @Machinenamedispalytype  SMALLINT = 0,
	    @OverNightBatchThreshold INT      = 7200, -- Seconds  
	    @EfficiencyType          INT;
	    SELECT
			 @EfficiencyType = ISNULL(EfficiencyCalcType, 1)
	    FROM tcd.Dashboard
	    WHERE DashboardId = @DashBoardId;
	    DECLARE @Dashboardmachinemapping TABLE
	    (
		    Id             INT,
		    GroupID        INT,
		    WasherId       INT,
		    WasherName     NVARCHAR(100),
		    WasherNumber   INT,
		    IsPLCConnected BIT,
		    DispenserName  VARCHAR(250)
	    );
	    DECLARE @AlarmByMachine TABLE
	    (
		    GroupID          INT,
		    WasherID         INT,
		    Alarm            BIT NULL,
		    AlarmDescription NVARCHAR(250)
	    );
	    DECLARE @BatchEndtimes TABLE
	    (
		    GroupID             INT,
		    WasherID            INT,
		    CurrentBatchEndTime INT NULL,
		    BatchEndTime        TIME
	    );
	    DECLARE @ShiftIds TABLE
	    (
		    ShiftId        INT,
		    ShiftStartDate DATETIME,
		    ShiftEndDate   DATETIME
	    );
	    DECLARE @Summarizeddata TABLE
	    (
		    GroupId                INT,
		    MachineId              INT,
		    WasherName             NVARCHAR(100),
		    WasherNumber           INT,
		    TargetLoad             FLOAT,
		    ActualLoad             FLOAT,
		    LoadEfficiency         FLOAT,
		    TimeEfficiency         FLOAT,
		    LostLoad               FLOAT,
		    Alarm                  BIT,
		    AlarmDescription       NVARCHAR(250),
		    WasherStatus           INT,
		    MachineNameDispalyType SMALLINT,
		    TargetTurnTime         INT,
		    DefaultIdleTime        INT,
		    IsPLCConnected         BIT,
		    DispenserName          VARCHAR(250),
		    LostBatches            DECIMAL(18, 6)
	    );
	    INSERT INTO @Dashboardmachinemapping
	    (
			 Id,
			 GroupID,
			 WasherId,
			 WasherName,
			 WasherNumber,
			 IsPLCConnected,
			 DispenserName
	    )
	    SELECT
			 ROW_NUMBER() OVER(ORDER BY MS.GroupID) AS Id,
			 MS.GroupId,
			 MS.WasherID,
			 MS.MachineName,
			 W.PlantWasherNumber AS                    WasherNumber,
			 (CASE
				 WHEN ISNULL(AD.IsActive, 0) = 0
				 THEN CAST(1 AS    BIT)
				 WHEN ISNULL(AD.IsActive, 0) = 1
				 THEN CAST(0 AS BIT)
			  END) AS                                  IsPLCConnected,
			 CAST(CC.ControllerNumber AS NVARCHAR)+' ('+CC.TopicName+
			 ')' AS                                    DispenserName
	    FROM
	    (
		   SELECT DISTINCT
				MachineId,
				DashboardId
		   FROM TCD.MonitorSetUpMapping
	    ) AS DM
	    INNER JOIN TCD.MachineSetup AS MS ON DM.MachineId = MS.WasherID
	    INNER JOIN tcd.Washer AS W ON MS.WasherId = W.WasherId
	    INNER JOIN TCD.Dashboard AS D ON DM.DashBoardId = D.DashBoardId
	    INNER JOIN TCD.ConduitController CC ON CC.ControllerId = MS.
	    ControllerId
	    LEFT JOIN TCD.AlarmData AD ON AD.ControllerId = MS.ControllerId
							    AND IsActive = 1
							    AND AD.AlarmCode = (CASE
												   WHEN
											   (
												  SELECT
													    VALUE
												  FROM TCD.
												  controllerSetupData CSD
													  LEFT
													  JOIN TCD.Field F ON F.Id = CSD.FieldId
												  WHERE F.
												  Label = 'Webport Ftp Enabled'
													   AND
													   CSD.ControllerId = AD.ControllerId
													   AND CC
													   .ControllerTypeId = 1
											   ) = 'true'
												   THEN 9002
												   ELSE 9001
											    END)
	    WHERE DM.DashboardId = @Dashboardid
			AND MS.IsDeleted = 0
			AND w.Is_Deleted = 0  
			-- Exclude Phony Washers from Efficiency calculation   
			AND ms.WasherId NOT IN
	    (
		   SELECT
				w.WasherId
		   FROM TCD.MachineSetup AS ms
			   INNER JOIN TCD.Washer AS w ON w.WasherId = ms.WasherId
									   AND ms.
									   EcoalabAccountNumber = w.EcoLabAccountNumber
		   WHERE(NULLIF(ms.ControllerId, 0) IS NULL
			    AND w.WasherMode = 0)
			   OR MS.IsPony = 1
	    );  
  
  
	    -- For efficiency calculations on shift wise  
	    IF(@EfficiencyType = 1)
		   BEGIN
			  INSERT INTO @ShiftIds
			  (
				    ShiftId,
				    ShiftStartDate,
				    ShiftEndDate
			  )
			  SELECT DISTINCT
				    ShiftId,
				    StartDateTime,
				    EndDateTime
			  FROM TCD.ProductionShiftData
			  WHERE GETUTCDATE() BETWEEN StartDateTime AND EndDateTime;   
			  -- WHERE ShiftId = 33 
		   END;
	    ELSE -- For efficiency calculations on Day wise  
		   BEGIN
			  INSERT INTO @ShiftIds
			  (
				    ShiftId,
				    ShiftStartDate,
				    ShiftEndDate
			  )
			  SELECT
				    ShiftId,
				    StartDateTime,
				    EndDateTime
			  FROM [TCD].ProductionShiftData
			  WHERE startdatetime > CAST(GETUTCDATE() AS DATE)
				   AND startdatetime < DATEADD(dd, 1, CAST(GETUTCDATE()
				   AS DATE))
			  ORDER BY
					 startdatetime;
		   END;
	    SELECT
			 *
	    INTO
		    #BatchData
	    FROM tcd.BatchData bd(NOLOCK)
	    WHERE bd.ShiftId IN
	    (
		   SELECT
				si.ShiftId
		   FROM @ShiftIds si
	    )
			AND bd.StandardWeight > 0
			AND bd.ActualWeight > 0
			AND bd.EndDate IS NOT NULL;
	    -- Efficiency for each batch   
	    SELECT
			 bd.BatchId,
			 W_1.WasherGroupID AS         GroupID,
			 W_1.WasherId AS              MachineID,
			 bd.ShiftId,
			 W_1.WasherNumber,
			 W_1.WasherName,
			 (bd.ActualWeight + ISNULL(BD.ManualInputWeight, 0)) AS
			                              ActualProduction,
			 bd.StandardWeight AS         StandardProduction,
			 CASE
				WHEN DATEDIFF(ss, bd.StartDate, ISNULL(bd.EndDate,
				GETDATE())) > @OverNightBatchThreshold
				THEN W_1.StandardRunTime
				ELSE DATEDIFF(ss, bd.StartDate, ISNULL(bd.EndDate,
				GETDATE()))
			 END AS                       ActualRunTime,
			 W_1.StandardRunTime,
			 TT.ActualTurnTime,
			 bd.TargetTurnTime AS         StandardTurnTime,
			 CASE
				WHEN W_1.WasherGroupTypeID = 1   
							  -- Conventional  
				THEN(CAST((W_1.Standardruntime + bd.TargetTurnTime) AS
							  FLOAT) / (CAST(CASE
											 WHEN DATEDIFF(ss,
											 bd.StartDate,
											 ISNULL(bd.EndDate,
											 GETDATE())) >
											 @OverNightBatchThreshold
											 THEN W_1.
											 StandardRunTime
											 ELSE DATEDIFF(ss,
											 bd.StartDate,
											 ISNULL(bd.EndDate,
											 GETDATE()))
										  END + CASE
												  WHEN TT.
												  ACTUALTURNTIME = 0
												  THEN bd.
												  TargetTurnTime
												  ELSE TT.
												  ACTUALTURNTIME
											   END AS FLOAT)))  
							  -- Tunnel  
				ELSE(CAST(NULLIF(W_1.Standardruntime, 0) AS FLOAT)) /
							  (CAST(CASE
									  WHEN DATEDIFF(second, bd.
									  StartDate, ISNULL(bd.
									  EndDate, GETDATE())) = 0
									  THEN W_1.Standardruntime
									  ELSE CASE
											 WHEN DATEDIFF(ss,
											 bd.StartDate,
											 ISNULL(bd.EndDate,
											 GETDATE())) >
											 @OverNightBatchThreshold
											 THEN W_1.
											 StandardRunTime
											 ELSE DATEDIFF(ss,
											 bd.StartDate,
											 ISNULL(bd.EndDate,
											 GETDATE()))
										  END
								   END AS FLOAT))
			 END AS                       TimeEfficiency,
			 ((CAST((bd.ActualWeight + ISNULL(BD.ManualInputWeight, 0))
			 AS    FLOAT) / CAST(NULLIF(bd.StandardWeight, 0) AS FLOAT))
			 * 100) AS                    LoadEfficiency,
			 CASE
				WHEN W_1.WasherGroupTypeID = 2
				THEN(100 * ((3600.00 / (CAST(CASE
										   WHEN DATEDIFF(second,
										   bd.StartDate, ISNULL(
										   bd.EndDate, GETDATE()))
										   = 0
										   THEN NULLIF(W_1.
										   Standardruntime, 0)
										   ELSE DATEDIFF(second,
										   bd.StartDate, ISNULL(
										   bd.EndDate, GETDATE()))
									    END AS FLOAT) / W_1.
									    NumberOfComp)) / (3600.00
									    / (CAST(NULLIF(W_1.Standardruntime,
									    0) AS FLOAT) / W_1.
									    NumberOfComp))))
				ELSE NULL
			 END AS                       TransferPerHr,  
			 --missedloads formulae
			 --------(((Actual Production/totalefficiency)*100)-actualproduction)
		
			 (CAST(CAST(bd.ActualWeight AS    DECIMAL(18, 6)) / (((CAST
			 ((bd.ActualWeight + ISNULL(BD.ManualInputWeight, 0)) AS
			 DECIMAL(18, 6)) / CAST(NULLIF(bd.StandardWeight, 0) AS
			 DECIMAL(18, 6))) * 100.0) * (CASE
									    WHEN W_1.
									    WasherGroupTypeID = 1   
									-- Conventional  
									    THEN(CAST((W_1.
									Standardruntime + bd.TargetTurnTime)
									AS DECIMAL(18, 6)) / (CAST(
									CASE
									    WHEN DATEDIFF(ss, bd.
									    StartDate, ISNULL(bd.
									    EndDate, GETDATE())) >
									    @OverNightBatchThreshold
									    THEN W_1.StandardRunTime
									    ELSE DATEDIFF(ss, bd.
									    StartDate, ISNULL(bd.
									    EndDate, GETDATE()))
									END + TT.ACTUALTURNTIME AS
									FLOAT)))  
									-- Tunnel  
									    ELSE(CAST(NULLIF(W_1.
									Standardruntime, 0) AS
									DECIMAL(18, 6))) / (CAST(CASE
														    WHEN
														    DATEDIFF(second,
														    bd.StartDate,
														    ISNULL(bd.EndDate,
														    GETDATE()))
														    = 0
														    THEN
														    W_1.Standardruntime
														    ELSE
														    CASE
															   WHEN
															   DATEDIFF(ss,
															   bd.StartDate,
															   ISNULL(bd.EndDate,
															   GETDATE()))
															   > @OverNightBatchThreshold
															   THEN
															   W_1.StandardRunTime
															   ELSE
															   DATEDIFF(ss,
															   bd.StartDate,
															   ISNULL(bd.EndDate,
															   GETDATE()))
														    END
														END
														AS DECIMAL(18,
														6)))
									END)) AS DECIMAL(18, 6)) *
									100.0) - CAST(bd.ActualWeight
									AS DECIMAL(18, 6)) AS
									MissedLoads,
			 (((CAST((bd.ActualWeight + ISNULL(BD.ManualInputWeight, 0))
			 AS    FLOAT) / CAST(NULLIF(bd.StandardWeight, 0) AS FLOAT))
			 * 100) * (CASE
						WHEN W_1.WasherGroupTypeID = 1   
					 -- Conventional  
						THEN(CAST((W_1.Standardruntime + bd.
					 TargetTurnTime) AS FLOAT) / (CAST(CASE
												    WHEN
												    DATEDIFF(ss,
												    bd.StartDate,
												    ISNULL(bd.EndDate,
												    GETDATE()))
												    > @OverNightBatchThreshold
												    THEN W_1.
												    StandardRunTime
												    ELSE
												    DATEDIFF(ss,
												    bd.StartDate,
												    ISNULL(bd.EndDate,
												    GETDATE()))
												END + TT.
												ACTUALTURNTIME AS FLOAT)))  
					 -- Tunnel  
						ELSE(CAST(NULLIF(W_1.Standardruntime, 0) AS
					 FLOAT)) / (CAST(CASE
									 WHEN DATEDIFF(second, bd.
									 StartDate, ISNULL(bd.EndDate,
									 GETDATE())) = 0
									 THEN W_1.Standardruntime
									 ELSE CASE
											WHEN DATEDIFF(ss,
											bd.StartDate,
											ISNULL(bd.EndDate,
											GETDATE())) >
											@OverNightBatchThreshold
											THEN W_1.
											StandardRunTime
											ELSE DATEDIFF(ss,
											bd.StartDate,
											ISNULL(bd.EndDate,
											GETDATE()))
										 END
								  END AS FLOAT))
					 END)) AS           TotalEfficiency,
			 W_1.MaxLoad
	    INTO
		    #BatchEfficiency
	    FROM #BatchData bd --FROM TCD.BatchData bd   
		    RIGHT OUTER JOIN
	    (
		   SELECT
				ms.EcoalabAccountNumber,
				ms.WasherId,
				ms.GroupId AS                 WasherGroupID,
				mg.WasherGroupTypeId AS       WasherGroupTypeID,
				w.EcolabWasherId,
				w.MaxLoad,
				ISNULL(ms.NumberOfComp, 0) AS NumberOfComp,
				CASE
				    WHEN MG.WASHERGROUPTYPEID = 1
				    THEN WSP.ProgramNumber
				    ELSE TPS.ProgramNumber
				END AS                        ProgramNumber,
				CASE
				    WHEN MG.WASHERGROUPTYPEID = 1
				    THEN WSP.ProgramId
				    ELSE TPS.ProgramId
				END AS                        ProgramId,
				CASE
				    WHEN MG.WASHERGROUPTYPEID = 1
				    THEN WSP.TotalRunTime
				    ELSE TPS.TotalRunTime
				END AS                        Standardruntime,
				w.PlantWasherNumber AS        WasherNumber,
				ms.MachineName AS             WasherName,
				mg.WasherGroupName AS         MachineGroup  
		   --mg.WasherGroupId AS MachineGroupID  
		   FROM TCD.MachineSetup AS ms(NOLOCK)
			   INNER JOIN TCD.Washer AS w(NOLOCK) ON w.
			   EcoLabAccountNumber = ms.EcoalabAccountNumber
											 AND w.WasherId =
											 ms.WasherId
			   INNER JOIN TCD.WasherGroup AS mg(NOLOCK) ON ms.GroupId =
			   mg.WasherGroupId
												  AND w.
												  EcoLabAccountNumber = mg.EcolabAccountNumber
			   LEFT OUTER JOIN TCD.WasherProgramSetup AS WSP(NOLOCK) ON
			   (WSP.WasherGroupId = mg.WasherGroupId
			    OR WSP.ControllerID = mg.ControllerId)
			   AND WSP.EcolabAccountNumber = mg.EcolabAccountNumber
			   AND WSP.Is_Deleted = 0 --AND WSP.WasherGroupId = ms.GroupId      
			   LEFT OUTER JOIN TCD.TunnelProgramSetup AS TPS(NOLOCK) ON
			   TPS.WasherGroupId = mg.WasherGroupId
			   AND TPS.EcolabAccountNumber = mg.EcolabAccountNumber
			   AND TPS.Is_Deleted = 0 --AND TPS.WasherGroupId = ms.GroupId   
			   RIGHT JOIN @Dashboardmachinemapping DM1 ON DM1.GroupID =
			   ms.GroupId
												 AND DM1.
												 WasherId = ms.WasherId
		   WHERE ms.IsTunnel = 0
			    AND ms.IsDeleted = 0
	    ) AS W_1 ON BD.GroupId = W_1.WasherGroupID
				 AND ISNULL(BD.EcolabWasherId, 0) = ISNULL(W_1.
				 EcolabWasherId, 0)
				 AND bd.MachineID = W_1.WasherId
				 AND BD.ProgramMasterId = W_1.ProgramId
				 AND BD.ProgramNumber = W_1.ProgramNumber
		    LEFT JOIN [TCD].[Turntime] TT ON ISNULL(BD.EcolabwasherID, 0)
		    = ISNULL(TT.EcolabWasherId, 0)
									  AND BD.batchid = TT.BatchID
	    WHERE DATEDIFF(ss, bd.StartDate, bd.EndDate) > (W_1.
	    Standardruntime * 10 / 100);
	    SELECT
			 DM.GroupID,
			 DM.WasherId AS                                     MachineID,
			 DM.WasherNumber,
			 DM.WasherName,
			 CAST(SUM(t.ActualProduction) AS FLOAT) AS          ActualProduction,
			 CAST(SUM(t.StandardProduction) AS FLOAT) AS
			                                                    StandardProduction,
			 SUM(t.ActualRunTime) AS                            ActualRuntime,
			 SUM(t.StandardRunTime) AS                          StandardRunTime,
			 (SUM(t.MissedLoads) / COUNT(DISTINCT t.BatchId)) AS
			                                                    MissedLoads,
			 (CAST(SUM(t.LoadEfficiency) AS    FLOAT) / COUNT(DISTINCT
			 t.BatchId)) AS                                     LoadEfficiency,
			 ((CAST(SUM(t.TimeEfficiency) AS    FLOAT) / COUNT(DISTINCT
			 t.BatchId)) * 100) AS                              TimeEfficiency,
			 ((CAST(SUM(t.LoadEfficiency) AS    FLOAT) / COUNT(DISTINCT
			 t.BatchId)) * (CAST(SUM(t.TimeEfficiency) AS FLOAT) /
			 COUNT(DISTINCT t.BatchId))) AS                     TotalEfficiency,
			 DM.IsPLCConnected AS                               IsPLCConnected,
			 DM.DispenserName,
			 (SUM(t.MissedLoads) / COUNT(DISTINCT t.BatchId)) / CASE
														 WHEN
														 MAX(t.MaxLoad)
														 = 0
														 THEN
														 1
														 ELSE
														 MAX(t.MaxLoad)
													  END AS
													  LostBatches
	    INTO
		    #MachineEfficiency
	    FROM @Dashboardmachinemapping DM
		    LEFT JOIN #BatchEfficiency t ON DM.GroupID = t.GroupId
									 AND dm.WasherId = t.
									 MachineId  
	    --AND t.ActualRunTime > (t.StandardRunTime * 10/100)  
	    GROUP BY
			   DM.GroupID,
			   DM.WasherId,
			   DM.WasherNumber,
			   DM.WasherName,
			   DM.IsPLCConnected,
			   DM.DispenserName;
	    INSERT INTO @AlarmByMachine
	    (
			 GroupID,
			 WasherID,
			 Alarm,
			 AlarmDescription
	    )
	    SELECT
			 AlarmByMachine.GroupID,
			 AlarmByMachine.WasherID,
			 AlarmByMachine.Alarm,
			 AlarmByMachine.AlarmDescription
	    FROM
	    (
		   SELECT
				ROW_NUMBER() OVER(PARTITION BY AD.MachineId ORDER BY
				AD.StartDate DESC) AS rownum,
				AD.IsActive AS        Alarm,
				AM.[Description] AS   AlarmDescription,
				AD.MachineId AS       WasherID,
				d.GroupID
		   FROM TCD.AlarmData AD
			   INNER JOIN TCD.AlarmGroupMaster AM ON AM.
			   AlarmGroupMasterId = AD.AlarmGroupMasterId
			   INNER JOIN @Dashboardmachinemapping d ON AD.MachineId =
			   D.WasherId
	    ) AS AlarmByMachine
	    WHERE rownum = 1;
	    INSERT INTO @BatchEndtimes
	    (
			 GroupID,
			 WasherID,
			 CurrentBatchEndTime,
			 BatchEndTime
	    )
	    SELECT
			 d.GroupID,
			 d.WasherId,
			 COUNT(CASE
					 WHEN bd.EndDate IS NULL
					 THEN 1
					 ELSE NULL
				  END) AS                    CurrentBatchEndTime,
			 CAST(MAX(bd.EndDate) AS TIME) AS BatchEndTime
	    FROM @DashboardMachineMapping d
		    INNER JOIN TCD.BatchData bd ON d.GroupID = bd.GroupId
									AND d.WasherId = bd.MachineId
	    WHERE bd.ShiftId IN
	    (
		   SELECT
				ShiftId
		   FROM @ShiftIds
	    )
	    GROUP BY
			   d.GroupID,
			   d.WasherId;
	    SELECT
			 @StandardTurnTime = ISNULL(ConStdTurnTime, 30)
	    FROM tcd.Plant;
	    SELECT
			 @StandardTurnTime = @StandardTurnTime + ISNULL(
			 TargetTurnTime, 0)
	    FROM tcd.Washer
	    WHERE WasherId = @WasherId;
	    SELECT
			 @MachineNameDispalyType = ISNULL(MachineNameDispalyType, 0)
	    FROM TCD.Dashboard D
	    WHERE D.DashboardId = @DashBoardId;
	    INSERT INTO @Summarizeddata
	    (
			 GroupId,
			 MachineId,
			 WasherName,
			 WasherNumber,
			 TargetLoad,
			 ActualLoad,
			 LoadEfficiency,
			 TimeEfficiency,
			 LostLoad,
			 Alarm,
			 AlarmDescription,
			 WasherStatus,
			 MachineNameDispalyType,
			 TargetTurnTime,
			 DefaultIdleTime,
			 IsPLCConnected,
			 DispenserName,
			 LostBatches
	    )
	    SELECT
			 me.GroupID,
			 me.MachineID,
			 me.WasherName,
			 me.WasherNumber,
			 me.StandardProduction AS TargetLoad,
			 me.ActualProduction AS   ActulaLoad,
			 me.LoadEfficiency,
			 me.TimeEfficiency,
			 me.MissedLoads AS        LostLoad,
			 ISNULL(abm.Alarm, 0) AS  Alarm,
			 abm.AlarmDescription,
			 CASE
				WHEN be.CurrentBatchEndTime = 1
				THEN 1
				WHEN CAST(GETUTCDATE() AS TIME) BETWEEN be.
				BatchEndTime AND DATEADD(Minute, @StandardTurnTime, be
				.BatchEndTime)
				THEN 2
				WHEN abm.Alarm = 1
				THEN 3
				ELSE 3
			 END AS                   WasherStatus,
			 @MachineNameDispalyType,
	    (
		   SELECT
				TargetTurnTime
		   FROM TCD.WASHER W
		   WHERE W.WasherId = ME.MachineID
	    ),
	    (
		   SELECT
				DefaultIdleTime
		   FROM TCD.WASHER W
		   WHERE W.WasherId = ME.MachineID
	    ),
			 me.IsPLCConnected,
			 me.DispenserName,
			 me.LostBatches
	    FROM #MachineEfficiency me
		    LEFT JOIN @AlarmByMachine abm ON ME.GroupID = abm.GroupID
									  AND ME.MachineID = ABM.
									  WasherID
		    LEFT JOIN @BatchEndtimes be ON me.GroupID = be.GroupID
									AND me.MachineID = be.
									WasherID;
	    SELECT
			 GroupId,
			 MachineId,
			 CASE @Machinenamedispalytype
				WHEN 0
				THEN CAST(WasherNumber AS VARCHAR(20))+' '+WasherName
				WHEN 1
				THEN WasherName
				WHEN 2
				THEN CAST(WasherNumber AS VARCHAR(20))
			 END AS WasherName,
			 WasherNumber,
			 TargetLoad,
			 ActualLoad,
			 LoadEfficiency,
			 TimeEfficiency,
			 (CASE
				 WHEN ISNULL(LostLoad, 0) < 0
				 THEN 0
				 ELSE LostLoad
			  END)  LostLoad,
			 Alarm,
			 AlarmDescription,
			 WasherStatus,
			 TargetTurnTime,
			 DefaultIdleTime,
			 IsPLCConnected,
			 DispenserName,
			 (CASE
				 WHEN ISNULL(LostBatches, 0) < 0
				 THEN 0
				 ELSE LostBatches
			  END)  LostBatches
	    FROM @Summarizeddata
	    ORDER BY
			   WasherNumber;  
  
  
	    ---- CleanUp  
	    DROP TABLE #BatchData;
	    DROP TABLE #BatchEfficiency;
	    DROP TABLE #MachineEfficiency;
	END;

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlAnalogData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlAnalogData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [TCD].[ProcessMyControlAnalogData](
	@ControllerID INT,
	@VxML         XML)
AS
	BEGIN
	    DECLARE @TimeStamp    DATETIME
	    -- Getting the current UTC time 
	    SELECT
			 @TimeStamp = GETUTCDATE();

	    -- 1.Extracting xml data 
	    -- 2.And joining with sensor table
	    -- 3.Getting specific Sensor id by passing machine id and controller id and is_deleted(active sensor's)
	    -- 4.CTE will return table of columns i.e sensorid,sensortype,temparature,ph values
	    --Conventional washer sensor readings

	    WITH TempData
		    AS (SELECT
					s.SensorId,
					s.SensorType,
					T.c.value('@Temperature', 'DECIMAL(18,4)') temparature,
					T.c.value('@pH', 'DECIMAL(18,4)')          ph
			   FROM @VxML.nodes('MyControlAnalogData/WEAnalogData') T(c)
				   INNER JOIN TCD.Sensor s ON MachineCompartment =
			   (
				  SELECT TOP 1
					    ms.WasherId
				  FROM tcd.MachineSetup ms
				  WHERE ms.MachineInternalId = T.c.value('@WENumber','INT')
				  AND ms.ControllerId = @ControllerID
				  AND ms.IsDeleted = 0
				  AND ms.IsTunnel = 0
			   )
				   AND s.ControllerID = @controllerid
				   AND s.Is_deleted = 0) 
		    -- inserting records into sensor reading table using merge statement
		    MERGE INTO tcd.sensorreading sr
		    USING
		    (
			   SELECT
					sensorid,
					sensortype,
					CASE
					    WHEN SensorType = 1
					    THEN Temparature		 --Temparature
					    WHEN SensorType = 2
					    THEN ph				 --PH
					END reading
			   FROM tempdata
		    ) temp
		    ON sr.sensorId = temp.sensorid
			  AND temp.reading =
		    (
			   SELECT TOP 1
					reading
			   FROM tcd.SensorReading
			   WHERE SensorId = temp.sensorid
			   ORDER BY
					  TimeStamp DESC
		    ) 

		    -- If records are not in the sensor reading tables
		    -- Sensor records are inserted depending on the sensor type	
	
			   WHEN NOT MATCHED AND(temp.reading <> NULL
							    OR temp.reading <> 0)
			   THEN INSERT(
						sensorid,
						reading,
						timestamp) VALUES
		    (
									   temp.sensorid,
									   temp.reading,
									   @TimeStamp
		    );
	END;

	GO

	IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetActiveControllers]') AND type in (N'P', N'PC'))
DROP PROCEDURE [TCD].[GetActiveControllers]
GO
CREATE PROCEDURE [TCD].[GetActiveControllers]
 AS
BEGIN

SET NOCOUNT ON              --SQLEnlight SA0017

  DECLARE @TempControllerFields TABLE
  (
    ControllerId INT,
    OpcServer INT,
    IpAddress INT,
	AMSNetIDAddress INT,
    ComportNumber INT,
    WebportFtpEnabled INT,
    WebportIP INT,
    WebportLogin INT,
    WebportPassword INT
  )
  INSERT INTO @TempControllerFields
  (  
    ControllerId ,
    OpcServer ,
    IpAddress ,
	AMSNetIDAddress,
    ComportNumber ,
    WebportFtpEnabled ,
    WebportIP ,
    WebportLogin ,
    WebportPassword
  )
  SELECT distinct
    Csd.ControllerId,
    max(case when Fld.Label = 'OPC Server' then Fld.Id end) OpcServer,
	max(case when Fld.Label = 'IP Address' then Fld.Id end) IpAddress,
    max(case when Fld.Label = 'AMS Net ID Address' then Fld.Id end) AMSNetIDAddress,
    max(case when Fld.Label = 'Com port Number' then Fld.Id end) ComportNumber,
    max(case when Fld.Label = 'Webport Ftp Enabled' then Fld.Id end) WebportFtpEnabled,
    max(case when Fld.Label = 'Webport IP' then Fld.Id end) WebportIP,
    max(case when Fld.Label = 'Webport Login' then Fld.Id end) WebportLogin,
    max(case when Fld.Label = 'Webport Password' then Fld.Id end) WebportPassword 
  FROM TCD.Field Fld
    INNER JOIN 
      TCD.ControllerSetupData Csd 
      ON Csd.FieldId=Fld.Id
  GROUP BY Csd.ControllerId

  SELECT DISTINCT 
      P.RegionID as RegionID,      
      Ctrl.ControllerId,
      Ctrl.EcoalabAccountNumber,
      Ctrl.ControllerTypeId,
      Ctrl.Name,
      CASE WHEN (CsdOpc.Value IS NULL) THEN NULL 
        ELSE CsdOpc.Value END 
        AS OpcServerName,
      CASE WHEN (CsdIP.Value IS NULL) THEN NULL 
        ELSE CsdIP.Value END 
        AS IpAddress,
	 CASE WHEN (CsdAMSId.Value IS NULL) THEN NULL 
        ELSE CsdAMSId.Value END 
        AS AMSNetIDAddress,
      CASE WHEN (CsdComport.Value IS NULL) THEN NULL 
        ELSE CsdComport.Value END 
        AS ComportNumber,
      CASE WHEN (CsdWebFtp.Value IS NULL) THEN NULL
         WHEN CsdWebFtp.Value = 'False' THEN 0 
        WHEN CsdWebFtp.Value = 'True' THEN 1  
        END 
        AS WebportFtpEnabled,
      CASE WHEN (CsdWebIP.Value IS NULL) THEN NULL 
        ELSE CsdWebIP.Value END 
        AS WebportIP,
      CASE WHEN (CsdWebLogin.Value IS NULL) THEN NULL 
        ELSE CsdWebLogin.Value END 
        AS WebportLogin,
      CASE WHEN (CsdWebPwd.Value IS NULL) THEN NULL 
        ELSE CsdWebPwd.Value END 
        AS WebportPassword,
      Ctrl.ControllerModelId,
      Ctrl.TopicName,
      Ctrl.WebportReadTime
   FROM  TCD.ConduitController Ctrl 
   INNER JOIN 
      @TempControllerFields Tcf 
      ON Tcf.ControllerId=Ctrl.ControllerId
   INNER JOIN 
      Plant P
      ON P.EcolabAccountNumber=Ctrl.EcoalabAccountNumber
   LEFT JOIN 
      TCD.ControllerSetupData CsdOpc 
      ON CsdOpc.FieldId = Tcf.OPCServer 
      AND CsdOpc.ControllerId = Ctrl.ControllerId
   LEFT JOIN 
      tcd.ControllerSetupData CsdIp 
      ON CsdIp.FieldId=Tcf.IpAddress 
      AND CsdIp.ControllerId = Ctrl.ControllerId
  LEFT JOIN 
      tcd.ControllerSetupData CsdAMSId 
      ON CsdAMSId.FieldId=Tcf.AMSNetIDAddress 
      AND CsdAMSId.ControllerId = Ctrl.ControllerId
   LEFT JOIN 
      TCD.ControllerSetupData CsdComport 
      ON CsdComport.FieldId=Tcf.ComportNumber 
      AND CsdComport.ControllerId = Ctrl.ControllerId
   LEFT JOIN 
      TCD.ControllerSetupData CsdWebFtp 
      ON CsdWebFtp.FieldId=Tcf.WebportFtpEnabled 
      AND CsdWebFtp.ControllerId = Ctrl.ControllerId
   LEFT JOIN 
      TCD.ControllerSetupData CsdWebIP 
      ON CsdWebIP.FieldId=Tcf.WebportIP 
      AND CsdWebIP.ControllerId = Ctrl.ControllerId
   LEFT JOIN 
      TCD.ControllerSetupData CsdWebLogin 
      ON CsdWebLogin.FieldId=Tcf.WebportLogin 
      AND CsdWebLogin.ControllerId = Ctrl.ControllerId
   LEFT JOIN 
      TCD.ControllerSetupData CsdWebPwd 
      ON CsdWebPwd.FieldId=Tcf.WebportPassword 
      AND CsdWebPwd.ControllerId = Ctrl.ControllerId

   WHERE 
      Ctrl.Active=1 
    AND  Ctrl.IsDeleted=0

  
 END

 GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetShiftStartDate]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetShiftStartDate]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[GetShiftStartDate](@BatchDate datetime)
AS

BEGIN
IF (@BatchDate is NOT NULL)
BEGIN
IF NOT EXISTS(SELECT TCD.productionshiftdata.ShiftId,TCD.productionshiftdata.ShiftName,TCD.productionshiftdata.StartDateTime
     FROM tcd.productionshiftdata 
     where @BatchDate between StartDateTime AND EndDateTime)
 BEGIN
 DECLARE @DayId INT = NULL,
    @ShiftId Int = NULL,
    @ShiftName Varchar(100) = NULL,
    @StartTime DateTime = NULL,
    @EndTime DateTime = NULL,
    @DateStartTime DATETIME= NULL,
    @DateEndTime DATETIME= NULL,
    @BatchUTCStart DATETIME= NULL,
    @BatchUTCEnd DATETIME= NULL,
    @ShiftTargetProd Decimal(18,2) = NULL,
    @ConStdTurnTime Int= NULL,
    @ActualRunandConTurnTime Int= NULL,
    @TargetRunandConTurnTime Int= NULL,
    @ActualRunandTunTurnTime Int= NULL,
    @TargetRunandTunTurnTime Int= NULL,
    @SummationProduction Int,
    @NoOfLoads INT,@prevDay INT,@Rollingcount int = 1        
  ,@RowCount int = NULL,@RealDayId Int,@ShiftCount Int = 1,@LabourShift int
  ,@EcolabAccountNumber NVARCHAR(25) = NULL

  SELECT @BatchDate = DATEADD(MILLISECOND,DATEDIFF(MILLISECOND,getutcdate(),GETDATE()),@BatchDate) 

  SELECT @DayId = DayId FROM [TCD].WeekDay WITH (NOLOCK) WHERE DayName = DATENAME(dw,@BatchDate) 

  SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant

    DECLARE @BatchShiftTable TABLE
      (
        RowNumber int IDENTITY(1,1),
        BatchUTCStartDate datetime,
        BatchUTCEndDate datetime,
        ShiftId int
      )

    DECLARE @Result TABLE
        (
        StartDate Datetime,
        EndDate Datetime,
        ShiftId INT,
        ShiftName Varchar(1000),
        DayID Int,
        TargetProduction [decimal](18,2)
        )

    DECLARE @shiftdata_temp TABLE
        (
        SNo INT IDENTITY(1,1),
        [ShiftId] [int],
         [ShiftName] [nvarchar](1000) ,
         [DayId] [int] ,
         [StartTime] [time](7) ,
         [EndTime] [time](7) ,
         [TargetProduction] [decimal](18, 2)
    
         )        
      INSERT INTO @shiftdata_temp
     SELECT TOP 1  
      SDH.[ShiftId] ,           
      SD.[ShiftName],  
      SDH.[DayId],              
      SDH.[StartTime],          
      SDH.[EndTime],            
      SDH.[TargetProduction]
      
  FROM TCD.ShiftDataHistory SDH WITH (NOLOCK) INNER JOIN TCD.ShiftData SD WITH (NOLOCK) ON SDH.DayId = SD.DayId AND SDH.ShiftId = SD.ShiftId
    WHERE OperationTimestamp < = @BatchDate AND SDH.DayId = @DayId  
  ORDER BY SDH.OperationTimestamp DESC


  UPDATE @shiftdata_temp SET DayId = CASE WHEN @DayId = 1 THEN 0 ELSE DayId END WHERE DayId = 7
  UPDATE @shiftdata_temp SET DayId = CASE WHEN @DayId = 7 THEN 8 ELSE DayId END WHERE DayId = 1

       
   DECLARE @VALIDSTART DATETIME,@VALIDEND DATETIME    
      SELECT @VALIDSTART = CASE WHEN DayId > @DayId THEN  DATEADD(day, DATEDIFF(day, -1, @BatchDate), CAST(starttime AS datetime))
         WHEN DayId < @DayId THEN   DATEADD(day, DATEDIFF(day, 1, @BatchDate), CAST(starttime AS datetime)) 
              ELSE
               DATEADD(day, DATEDIFF(day, 0, @BatchDate), CAST(starttime AS datetime)) END      ,
       @VALIDEND =  CASE WHEN ((DayId > @DayId AND EndTime > StartTime) OR (DayId = @DayId AND (EndTime = StartTime OR EndTime < StartTime))) THEN 
                DATEADD(day, DATEDIFF(day,-1, @BatchDate), CAST(EndTime AS datetime))
         WHEN (DayId < @DayId AND (EndTime < StartTime OR EndTime = StartTime)) THEN 
                 DATEADD(day, DATEDIFF(day, 0, @BatchDate), CAST(EndTime AS datetime))
         WHEN (DayId > @DayId AND (EndTime < StartTime OR EndTime = StartTime)) THEN 
                   DATEADD(day, DATEDIFF(day,-2, @BatchDate), CAST(EndTime AS datetime))       
                 ELSE
                DATEADD(day, DATEDIFF(day, 0, @BatchDate), CAST(EndTime AS datetime)) 
                END,@ShiftId = ShiftId,@ShiftName = ShiftName,@RealDayId = DayId,@ShiftTargetProd = TargetProduction
         FROM @shiftdata_temp WHERE SNo = @Rollingcount 

         INSERT INTO @Result(StartDate,EndDate,ShiftId,ShiftName,DayID,TargetProduction)
         SELECT @VALIDSTART,@VALIDEND,@ShiftId,@ShiftName,@RealDayId,@ShiftTargetProd

          
  

 
    SELECT DISTINCT @StartTime = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(StartDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(StartDate AS time)) AS DateTime)),
    @EndTime = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(EndDate AS time)) AS DateTime)),
    @ShiftId = ShiftId,@ShiftName = ShiftName,@DayId = DayID,@ShiftTargetProd = TargetProduction  FROM @Result
   WHERE @BatchDate BETWEEN StartDate AND EndDate

    SELECT @LabourShift = @ShiftId

     IF(@StartTime IS NULL AND @EndTime IS NULL)
    BEGIN
 SELECT @ShiftId = NULL,@ShiftName = NULL
    END
   
    IF(COUNT(@ShiftId) <> 1)      ---NO shift Timings
    BEGIN
 
     SELECT TOP 1 @StartTime = SDH.EndTime FROM TCD.ShiftDataHistory SDH WITH (NOLOCK) INNER JOIN TCD.ShiftData SD WITH (NOLOCK) ON SDH.DayId = SD.DayId AND SDH.ShiftId = SD.ShiftId 
    WHERE SDH.DayId = @DayId 
     AND SDH.EndTime < CONVERT(TIME, CONVERT(VARCHAR(20), @BatchDate, 120)) AND OperationTimestamp < = @BatchDate   
  ORDER BY SDH.EndTime
   
    SELECT TOP 1 @EndTime = SDH.StartTime  FROM TCD.ShiftDataHistory SDH WITH (NOLOCK) INNER JOIN TCD.ShiftData SD WITH (NOLOCK) ON SDH.DayId = SD.DayId AND SDH.ShiftId = SD.ShiftId 
    WHERE SDH.DayId = @DayId 
     AND CONVERT(TIME, CONVERT(VARCHAR(20), @BatchDate, 120)) < SDH.StartTime  AND OperationTimestamp < = @BatchDate   
  
  ORDER BY SDH.StartTime 
     
     IF(COUNT(@StartTime) <> 1)
        BEGIN
        SELECT @StartTime = CAST(dateadd(DAY, datediff(day, 0, @BatchDate),0) AS dateTime)
        END
        ELSE
        BEGIN
        SELECT @StartTime = DATEADD(day, DATEDIFF(day, 0, @BatchDate),@StartTime)
        END

        IF(COUNT(@EndTime) <> 1)
        BEGIN
        SELECT @EndTime =  CAST(DATEADD(s, -1, DATEADD(day, 1,CONVERT(DATETIME, CONVERT(DATE, @BatchDate)))) AS dateTime)
        END
        ELSE
        BEGIN
        SELECT @EndTime = DATEADD(day, DATEDIFF(day, 0, @BatchDate),@EndTime)
        END

      SET @StartTime = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@StartTime AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@StartTime AS time)) AS DateTime))
      SET @EndTime =  dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndTime AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndTime AS time)) AS DateTime))    

    END     
    
	IF ((SELECT COUNT(1) FROM TCD.TARGETPRODUCTIONDETAILS AS T WITH (NOLOCK) WHERE DayId = @DayId AND T.ShiftId = @ShiftId) = 1)
    BEGIN
    SELECT @ShiftTargetProd = TPD.TargetProduction FROM TCD.TARGETPRODUCTIONDETAILS TPD  WITH (NOLOCK)
        WHERE DayId = @DayId 
        AND TPD.ShiftId = @ShiftId
    END
    
    
   IF NOT EXISTS (SELECT 1 FROM [TCD].ProductionShiftData WITH (NOLOCK) WHERE StartDateTime = @StartTime )
   BEGIN
    
    INSERT INTO [TCD].ProductionShiftData (
             [ShiftName],
             [StartDateTime],
             [EndDateTime],
             [TargetProduction],
    [EcolabAccountNumber]
            ) 
     SELECT  --CASE WHEN COUNT(@Count) <> 1 THEN 1 ELSE @Count + 1 END,
        CASE WHEN COUNT(@ShiftName) <> 1 THEN 'No Shift' ELSE @ShiftName END,
        @StartTime,
        @EndTime,
        @ShiftTargetProd,
  @EcolabAccountNumber

  SET @BatchDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@BatchDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@BatchDate AS time)) AS DateTime))
 END
END


SELECT TCD.productionshiftdata.ShiftId,TCD.productionshiftdata.ShiftName,TCD.productionshiftdata.StartDateTime
  FROM tcd.productionshiftdata 
  where @BatchDate between StartDateTime AND EndDateTime

  END 

END

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProductionShiftDataRollup]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProductionShiftDataRollup]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProductionShiftDataRollup](@InputShiftId INT,@RedFlagShiftId INT OUTPUT)
AS
BEGIN
	SET NOCOUNT ON
    DECLARE @DayId INT = NULL,
	@ShiftId Int = NULL,
	@ShiftName Varchar(100) = NULL,
	@StartTime DateTime = NULL,
	@EndTime DateTime = NULL,
	@DateStartTime DATETIME= NULL,
	@DateEndTime DATETIME= NULL,
	@BatchUTCStart DATETIME= NULL,
	@BatchUTCEnd DATETIME= NULL,
	@ShiftTargetProd Decimal(18,2) = NULL,
	@ConStdTurnTime Int= NULL,
	@ActualRunandConTurnTime Int= NULL,
	@TargetRunandConTurnTime Int= NULL,
	@ActualRunandTunTurnTime Int= NULL,
	@TargetRunandTunTurnTime Int= NULL,
	@SummationProduction Int,
	@NoOfLoads INT,@prevDay INT,@Rollingcount int = 1        
	,@RowCount int = NULL,@RealDayId Int,@ShiftCount Int = 1,@LabourShift int
	,@EcolabAccountNumber NVARCHAR(25) = NULL
		
	--SELECT * FROM TCD.WeekDay  SELECT DATENAME(dw,GETDATE()) 

    SELECT @DayId = DayId FROM [TCD].WeekDay WITH (NOLOCK) WHERE DayName = DATENAME(dw,GETDATE()) 

    SELECT @prevDay = CASE WHEN @DayId = 1 THEN 7 ELSE @DayId - 1 END
    SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant 

    DECLARE @BatchShiftTable TABLE
						(
						  RowNumber int IDENTITY(1,1),
						  BatchUTCStartDate datetime,
						  BatchUTCEndDate datetime,
						  ShiftId int
						)

    DECLARE @Result TABLE
				    (
				    StartDate Datetime,
				    EndDate Datetime,
				    ShiftId INT,
				    ShiftName Varchar(1000),
				    DayID Int,
				    TargetProduction [decimal](18,2)
				    )

    DECLARE @shiftdata_temp TABLE
						  (
						  SNo INT IDENTITY(1,1),
						  [ShiftId] [int],
						   [ShiftName] [nvarchar](1000) ,
						   [DayId] [int] ,
						   [StartTime] [time](7) ,
						   [EndTime] [time](7) ,
						   [TargetProduction] [decimal](18, 2) ,
						   [Is_Deleted] [bit] ,
						   [EcolabAccountNumber] [nvarchar](1000) ,
						   [LastModifiedByUserId] [int] ,
						   [LastModifiedTime] [datetime] ,
						   [LastSyncTime] [datetime],
						   [TargetProduction_Display] [decimal](18, 2) 
						   )        
    INSERT INTO @shiftdata_temp
     SELECT 
		    [ShiftId] ,           
		    [ShiftName],		
		    [DayId],              
		    [StartTime],          
		    [EndTime],            
		    [TargetProduction] , 
		    [Is_Deleted],        
		    [EcolabAccountNumber],
		    [LastModifiedByUserId],
		    [LastModifiedTime],	
		    [LastSyncTime],
		    [TargetProduction_Display]		
	 FROM TCD.ShiftData WITH (NOLOCK) WHERE (DayId = @DayId OR (DayId = @prevDay AND (EndTime < StartTime OR EndTime = StartTime))) AND IS_Deleted = 0  
	 ORDER BY DayId
	 
	UPDATE @shiftdata_temp SET DayId = CASE WHEN @DayId = 1 THEN 0 ELSE DayId END WHERE DayId = 7
	UPDATE @shiftdata_temp SET DayId = CASE WHEN @DayId = 7 THEN 8 ELSE DayId END WHERE DayId = 1

	 SELECT @RowCount = SNo FROM @shiftdata_temp 

	WHILE(@Rollingcount <=  @RowCount)        
    BEGIN        
			DECLARE @VALIDSTART DATETIME,@VALIDEND DATETIME    
		    SELECT @VALIDSTART = CASE WHEN DayId > @DayId THEN  DATEADD(day, DATEDIFF(day, -1, GETDATE()), CAST(starttime AS datetime))
								 WHEN DayId < @DayId THEN   DATEADD(day, DATEDIFF(day, 1, GETDATE()), CAST(starttime AS datetime)) 
														ELSE
														 DATEADD(day, DATEDIFF(day, 0, GETDATE()), CAST(starttime AS datetime)) END		    ,
				   @VALIDEND =  CASE WHEN ((DayId > @DayId AND EndTime > StartTime) OR (DayId = @DayId AND (EndTime = StartTime OR EndTime < StartTime))) THEN 
													   DATEADD(day, DATEDIFF(day,-1, GETDATE()), CAST(EndTime AS datetime))
								 WHEN (DayId < @DayId AND (EndTime < StartTime OR EndTime = StartTime)) THEN 
													    DATEADD(day, DATEDIFF(day, 0, GETDATE()), CAST(EndTime AS datetime))
								 WHEN (DayId > @DayId AND (EndTime < StartTime OR EndTime = StartTime)) THEN 
												    	  DATEADD(day, DATEDIFF(day,-2, GETDATE()), CAST(EndTime AS datetime))						 
								 					   ELSE
														  DATEADD(day, DATEDIFF(day, 0, GETDATE()), CAST(EndTime AS datetime)) 
														  END,@ShiftId = ShiftId,@ShiftName = ShiftName,@RealDayId = DayId,@ShiftTargetProd = TargetProduction
					    FROM @shiftdata_temp WHERE SNo = @Rollingcount 

					    INSERT INTO @Result(StartDate,EndDate,ShiftId,ShiftName,DayID,TargetProduction)
					    SELECT @VALIDSTART,@VALIDEND,@ShiftId,@ShiftName,@RealDayId,@ShiftTargetProd

		        
			SET @Rollingcount = @Rollingcount + 1        
    END        

	
    SELECT DISTINCT @StartTime = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(StartDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(StartDate AS time)) AS DateTime)),
				@EndTime = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(EndDate AS time)) AS DateTime)),
				@ShiftId = ShiftId,@ShiftName = ShiftName,@DayId = DayID,@ShiftTargetProd = TargetProduction  FROM @Result
	WHERE GETDATE() BETWEEN StartDate AND EndDate

    SELECT @LabourShift = @ShiftId

    IF(@StartTime IS NULL AND @EndTime IS NULL)
    BEGIN
		SELECT @ShiftId = NULL,@ShiftName = NULL,@ShiftTargetProd = NULL
    END
   
	IF(COUNT(@ShiftId) <> 1)      ---NO shift Timings
	BEGIN
		SELECT TOP 1 @StartTime = EndTime FROM [TCD].ShiftData WITH (NOLOCK)
		WHERE DayId = @DayId 
			AND Is_Deleted = 0
			AND EndTime < CONVERT(TIME, CONVERT(VARCHAR(20), GETDATE(), 120)) ORDER BY EndTime DESC
			
		SELECT TOP 1 @EndTime = StartTime  FROM [TCD].ShiftData WITH (NOLOCK)
		WHERE DayId = @DayId 
			AND Is_Deleted = 0
			AND CONVERT(TIME, CONVERT(VARCHAR(20), GETDATE(), 120)) < StartTime ORDER BY StartTime	
					
			IF(COUNT(@StartTime) <> 1)
				BEGIN
					SELECT @StartTime = CAST(dateadd(DAY, datediff(day, 0, getdate()),0) AS dateTime)
				END
					ELSE
				BEGIN
					SELECT @StartTime = DATEADD(day, DATEDIFF(day, 0, GETDATE()),@StartTime)
				END

			IF(COUNT(@EndTime) <> 1)
				BEGIN
					SELECT @EndTime =  CAST(DATEADD(s, -1, DATEADD(day, 1,CONVERT(DATETIME, CONVERT(DATE, GETDATE())))) AS dateTime)
				END
					ELSE
				BEGIN
					SELECT @EndTime = DATEADD(day, DATEDIFF(day, 0, GETDATE()),@EndTime)
				END

		SET @StartTime = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@StartTime AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@StartTime AS time)) AS DateTime))
		SET @EndTime = 	dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndTime AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndTime AS time)) AS DateTime))		  

	END    	    

 	 --SET @ShiftId = CASE WHEN COUNT(@ShiftId) <> 1 THEN 0 ELSE @ShiftId END
	 ----- Inserting the meta data into shift production base table -------

      ----------------/* Getting the Target Production from TargetProduction details if exists else in shift data page */---------------

    IF ((SELECT COUNT(1) FROM TCD.TARGETPRODUCTIONDETAILS AS T WITH (NOLOCK) WHERE DayId = @DayId AND T.ShiftId = @ShiftId) = 1)
	BEGIN
		SELECT @ShiftTargetProd = TPD.TargetProduction FROM TCD.TARGETPRODUCTIONDETAILS TPD  WITH (NOLOCK)
		WHERE DayId = @DayId AND TPD.ShiftId = @ShiftId
	END
	   
		  
	--DELETE FROM TCD.ProductionShiftData WHERE ShiftId = @ShiftId AND CAST(StartDateTime AS date) = CAST(GETDATE() AS date)
	IF NOT EXISTS (SELECT 1 FROM [TCD].ProductionShiftData WITH (NOLOCK) WHERE StartDateTime = @StartTime )
	BEGIN
		--DECLARE @Count INt 
		--SELECT @Count = MAX(ShiftId) FROM [TCD].ProductionShiftData WITH (NOLOCK)

		UPDATE TCD.ProductionShiftData
		SET				        
			TCD.ProductionShiftData.EndDateTime = @StartTime
			WHERE TCD.ProductionShiftData.EndDateTime > @StartTime

		SELECT TOP 1 @RedFlagShiftId=ShiftId FROM [TCD].ProductionShiftData WHERE StartDateTime < @StartTime ORDER BY StartDateTime DESC

		INSERT INTO [TCD].ProductionShiftData (
										-- [ShiftId],
											[ShiftName],
											[StartDateTime],
											[EndDateTime],
											[TargetProduction],
											[EcolabAccountNumber]
										) 
		SELECT  --CASE WHEN COUNT(@Count) <> 1 THEN 1 ELSE @Count + 1 END,
			CASE WHEN COUNT(@ShiftName) <> 1 THEN 'No Shift' ELSE @ShiftName END,
			@StartTime,
			@EndTime,
			ISNULL(@ShiftTargetProd,0),
			@EcolabAccountNumber				    			
	END
		IF(@InputShiftId > 0)
	BEGIN	
	 INSERT INTO @BatchShiftTable
	 (
	    
	    BatchUTCStartDate,
	    BatchUTCEndDate,
	    ShiftId
	 )
	 SELECT TOP 2 
		StartDateTime,
		EndDateTime,
		ShiftId	 
		FROM [TCD].ProductionShiftData SD WITH (NOLOCK) WHERE ShiftId=@InputShiftId ORDER BY SD.StartDateTime DESC 
		END
    
	   ------------------******// Inserting the Data into Batch Summary Temp table based on UTC shift timings //******-----------------------
    WHILE (@ShiftCount <= (SELECT COUNT(1) FROM @BatchShiftTable bst))
    BEGIN

     /* Picking up the first record from the top 2 records of production shift data */

	SELECT  @BatchUTCStart = bst.BatchUTCStartDate,
	@BatchUTCEnd =bst.BatchUTCEndDate,  @ShiftId = bst.ShiftId
	FROM @BatchShiftTable bst WHERE bst.RowNumber = @ShiftCount
					  
	DECLARE @BatchSummary TABLE
				(
				   RowNumber Int,
				   BatchId Int,
				   ActualWeight Int,
				   StandardWeight Int,
				   MachineId Int,
				   EcolabWasherId Int,
				   StartDate datetime2,
				   EndDate datetime2,
				   ProgramNumber Int,
				   ProgramMasterId Int,
				   CustomerId Int,
				   PiecesCount int,
				   ManualInputWeight int,
				   TargetTurnTime INT,
				   EcolabTextileId INT,
				   ChainTextileId  INT ,
				   PlantProgaramId INT
				)

    INSERT INTO @BatchSummary
		(
		RowNumber ,
		BatchId ,
		ActualWeight ,
		StandardWeight ,
		MachineId ,
		EcolabWasherId ,
		StartDate ,
		EndDate ,
		ProgramNumber,
		ProgramMasterId ,
		CustomerId ,
		PiecesCount ,
		ManualInputWeight ,
		TargetTurnTime ,
		EcolabTextileId ,
		ChainTextileId  ,
		PlantProgaramId 		
		)
	   SELECT 
				  ROW_NUMBER() OVER(PARTITION BY BD.MachineId ORDER BY BD.StartDate) RowNumber,
				   BD.BatchId,
				   ActualWeight,
				   StandardWeight,
				   MachineId,
				   BD.EcolabWasherId,
				   StartDate,
				   EndDate,
				   ProgramNumber,
				   ProgramMasterId,
				   BCD.CustomerId,
				   BCD.PiecesCount,
				   BD.ManualInputWeight,
				   BD.TargetTurnTime,
				   BD.EcolabTextileCategoryId,
				   BD.ChainTextileCategoryId,
				   BD.PlantProgramId
			 FROM TCD.BatchData BD WITH (NOLOCK)
					   INNER JOIN TCD.MachineSetup MS WITH (NOLOCK) ON MS.WasherId = BD.MachineId 
				    LEFT OUTER JOIN 
				 TCD.BatchCustomerData BCD WITH (NOLOCK) ON BD.BatchId = BCD.BatchId
			  WHERE BD.EndDate >= @BatchUTCStart AND BD.EndDate <= @BatchUTCEnd 

	   
	------------------******// Inserting the Data into Chemical temp table  //******-----------------------

	DECLARE @BatchChemicalSummary TABLE
				(
				   BatchId Int,
				   EcolabWasherId Int,
				   StartDate datetime2,
				   EndDate datetime2,
				   MachineId Int,
				   ProgramMasterId Int,
				   ProductId Int,
				   ActualQuantity Decimal(18,2),
				   StandardQuantity Decimal(18,2),
				   Price Decimal(18,2),
				   CustomerId Int,
				   EcolabTextileId INT,
				   ChainTextileId  INT ,
				   PlantProgaramId INT
				  			   
				)

    INSERT INTO @BatchChemicalSummary
		(
			BatchId,
			EcolabWasherId ,
			StartDate ,
			EndDate ,
			MachineId ,
			ProgramMasterId ,
			ProductId ,
			ActualQuantity ,
			StandardQuantity ,
			Price ,
			CustomerId ,
			EcolabTextileId ,
			ChainTextileId   ,
			PlantProgaramId 
		
		)
	   SELECT 
				   BD.BatchId,
				   BD.EcolabWasherId,
				   StartDate,
				   EndDate,
				   MachineId,
				   ProgramMasterId,
				   BPD.ProductId,
				   BPD.ActualQuantity,
				   BPD.StandardQuantity,
				   BPD.Price,
				   BCD.CustomerId,
				   BD.EcolabTextileCategoryId,
				   BD.ChainTextileCategoryId,
				   BD.PlantProgramId
			 FROM  TCD.BatchProductData BPD	WITH (NOLOCK)				   
					   INNER JOIN TCD.BatchData BD WITH (NOLOCK) ON BD.BatchId = BPD.BatchId
					   INNER JOIN TCD.MachineSetup MS WITH (NOLOCK) ON MS.WasherId = BD.MachineId 
					   LEFT OUTER JOIN TCD.ProductMaster PD WITH (NOLOCK) ON PD.ProductId = BPD.ProductId
					   LEFT OUTER JOIN  TCD.BatchCustomerData BCD WITH (NOLOCK) ON BD.BatchId = BCD.BatchId
					   WHERE BD.EndDate >= @BatchUTCStart AND BD.EndDate <= @BatchUTCEnd

	SELECT @NoOfLoads = COUNT(DISTINCT BatchId) FROM @BatchSummary
  
	------------------******// Inserting the Data into Machine Efficiency Temp table for runtimes based on machines //******-----------------------

	

	DECLARE @MachineEfficency TABLE
					   ( 
						  MachineId INT,
						  ProgramMasterId INT,
						  ActualRunTime INT, 
						  StandardRunTime INT,
						  ActualTurnTime INT,
						  StandardTurnTIme INT
					   )

    INSERT INTO @MachineEfficency
					   ( 
						  MachineId,
						  ProgramMasterId,
						  ActualRunTime , 
						  StandardRunTime,
						  ActualTurnTime,
						  StandardTurnTIme
					   )
	   SELECT 
			DISTINCT
			  CUR.MachineId,CUR.ProgramMasterId,	   
			 CAST(SUM(DATEDIFF(SECOND,CUR.StartDate,CUR.EndDate)) AS decimal(18,2)),
			 ISNULL(SUM(WPS.TotalRunTime),1),--+ @ConStdTurnTime + ISNULL(SUM(WPS.ExtraTime),1),
			 ISNULL(SUM( CASE WHEN DATEDIFF(SECOND,CUR.EndDate,nexting.StartDate) < 0 THEN 0 ELSE  DATEDIFF(SECOND,CUR.EndDate,nexting.StartDate) END),1),
			 ISNULL(SUM(CUR.TargetTurnTime),1)
	    FROM @BatchSummary CUR 
				LEFT OUTER JOIN @BatchSummary nexting ON cur.RowNumber = nexting.RowNumber - 1 AND CUR.MachineId = nexting.MachineId --AND CUR.ProgramMasterId = nexting.ProgramMasterId
				INNER JOIN TCD.MachineSetup MS WITH (NOLOCK) ON MS.WasherId = CUR.MachineId AND MS.IsTunnel = 0 AND MS.IsDeleted = 0
				LEFT JOIN TCD.WasherProgramSetup WPS WITH (NOLOCK) ON WPS.ProgramId = CUR.ProgramMasterId AND MS.GroupId = WPS.WasherGroupId AND WPS.Is_Deleted = 0
				GROUP BY CUR.MachineId,CUR.ProgramMasterId
	   UNION ALL

	   SELECT 
			DISTINCT
			CUR.MachineId,CUR.ProgramMasterId,
			 CAST(SUM(DATEDIFF(SECOND,CUR.StartDate,CUR.EndDate)) AS decimal(18,2)),			
			 ISNULL(SUM(TPS.TotalRunTime),1),
			SUM(COALESCE(3600/NULLIF(COALESCE(DATEDIFF(SECOND,CUR.StartDate,CUR.EndDate)/ NULLIF(MS.NumberOfComp,0),0) ,0), 0)) ,
			 SUM(COALESCE(3600/NULLIF(COALESCE(TPS.TotalRunTime/ NULLIF(MS.NumberOfComp,0),0) ,0), 0)) --+ ISNULL(SUM(TPS.ExtraTime),1)
	   FROM @BatchSummary CUR
				INNER JOIN TCD.MachineSetup MS WITH (NOLOCK) ON MS.WasherId = CUR.MachineId AND MS.IsTunnel = 1 AND MS.IsDeleted = 0
				        LEFT JOIN TCD.TunnelProgramSetup TPS WITH (NOLOCK) ON TPS.ProgramId = CUR.ProgramMasterId AND MS.GroupId = TPS.WasherGroupId AND TPS.Is_Deleted = 0
		  GROUP BY CUR.MachineId,CUR.ProgramMasterId

	--------------------------******// Inserting the Data into production Shift Rollup Data Table //******-------------------
	      		  
		 
	DELETE FROM [TCD].ShiftProductionDataRollup WHERE ShiftId = @ShiftId 
		 
	INSERT INTO [TCD].ShiftProductionDataRollup
							 (
								ShiftId,
								MachineId,
								ProgramMasterId,
								EcolabWasherId,
								NoOfLoads,
								ActualProduction ,
								StandardProduction,
								LoadEfficiency,
								TimeEfficiency,
								PlantTargetProd ,
								ActualRunTime,
								TargetRunTime,
								EcolabTextileId,
								ChainTextileId,
								ChainProgaramId,
								CustomerId,
								NoOfPieces,
								ActualTurnTime,
								TargetTurnTime
							 )	


		  SELECT 
				DISTINCT
					 @ShiftId,
				      CUR.MachineId,
					 CUR.ProgramMasterId,
					 CUR.EcolabWasherId,
					 COUNT(1),
					 SUM(CUR.ActualWeight) + ISNULL(SUM(CUR.ManualInputWeight),0),
					 SUM(CUR.StandardWeight),

					 CAST(COALESCE(((SUM(CUR.[ActualWeight]))/ NULLIF(ISNULL(SUM(CUR.[StandardWeight]),SUM(CUR.[ActualWeight])),0)), 0) AS decimal(18,2)),

					 --CAST(((SUM(CUR.[ActualWeight]))/ISNULL(SUM(CUR.[StandardWeight]),SUM(CUR.[ActualWeight]))) AS decimal(18,2)),

					 CAST(COALESCE(CAST(SUM(ME.StandardRunTime) AS Decimal(18,2))/ NULLIF(ISNULL(CAST(SUM(ME.ActualRunTime) AS decimal(18,2)),CAST(SUM(ME.ActualRunTime) AS Decimal(18,2))),0), 0) AS decimal(18,2)) ,

					 --CAST(CAST(SUM(ME.ActualRunTime) AS Decimal(18,2))/ISNULL(CAST(SUM(ME.StandardRunTime) AS decimal(18,2)),CAST(SUM(ME.ActualRunTime) AS Decimal(18,2))) AS decimal(18,2)) ,
			 		 @ShiftTargetProd * 1000,					 
					 COALESCE(SUM(ME.ActualRunTime) / NULLIF(COUNT(1),0), 0), 
					 COALESCE(ISNULL(SUM(ME.StandardRunTime),SUM(ME.ActualRunTime))/ NULLIF(COUNT(1),0), 0), 

					 CUR.EcolabTextileId,CUR.ChainTextileId,CUR.PlantProgaramId,
					 --ETC.TextileId,CTC.TextileId,PCP.PlantProgramId,
					 CUR.CustomerId,
				      SUM(CUR.PiecesCount),
					 COALESCE(SUM(ME.ActualTurnTime) / NULLIF(COUNT(1),0), 0),
					 COALESCE(ISNULL(SUM(ME.StandardTurnTIme),SUM(ME.ActualTurnTime))/ NULLIF(COUNT(1),0), 0)
							 FROM 
					   @BatchSummary CUR 
						  LEFT JOIN 
								@MachineEfficency ME ON CUR.MachineId = ME.MachineId AND CUR.ProgramMasterId = ME.ProgramMasterId
						  LEFT JOIN 
								 TCD.ProgramMaster PM WITH (NOLOCK) ON PM.ProgramId = CUR.ProgramMasterId
						/*
						  LEFT JOIN
								TCD.EcolabTextileCategory ETC WITH (NOLOCK) ON ETC.TextileId = PM.EcolabTextileCategoryId
						  LEFT JOIN
								TCD.ChainTextileCategory CTC WITH (NOLOCK) ON  CTC.TextileId = PM.ChainTextileId
						  LEFT JOIN
								TCD.PlantChainProgram PCP ON PCP.PlantProgramId = PM.PlantProgramId
						*/
						  GROUP BY CUR.MachineId,CUR.EcolabWasherId,CUR.ProgramMasterId,--ETC.TextileId,CTC.TextileId,PCP.PlantProgramId,
						  CUR.EcolabTextileId,CUR.ChainTextileId,CUR.PlantProgaramId,
						  CUR.CustomerId


	--------------------------******// Inserting the Data into Chemical Shift Rollup Data Table //******-------------------
	  	  
		 
	DELETE FROM [TCD].[ShiftChemicalDataRollup] WHERE ShiftId = @ShiftId 

	INSERT INTO [TCD].[ShiftChemicalDataRollup]
							 (
								 [ShiftId] ,
								 [MachineId],
								 [ProgramMasterId],
								 [EcolabWasherId],
								 [ProductId],
								 [ActualConsumption],
								 [TargetConsumption],
								 [ActualCost],
								 [EcolabTextileId],
								 [ChainTextileId],
								 [ChainProgaramId],
								 [CustomerId],
								 NoOfLoads
							 )
				SELECT
				    DISTINCT 
						  @ShiftId,
						  CUR.MachineId,
						  CUR.ProgramMasterId,
						  CUR.EcolabWasherId,
						  CUR.ProductId,
						  SUM(CUR.ActualQuantity),
						  SUM(CUR.StandardQuantity),
						  SUM(CUR.Price),
						  CUR.EcolabTextileId,
						  CUR.ChainTextileId,
						  CUR.PlantProgaramId,
						  CUR.CustomerId,
						  @NoOfLoads
						  FROM 
						  @BatchChemicalSummary CUR 
						   LEFT JOIN 
								 TCD.ProgramMaster PM WITH (NOLOCK) ON PM.ProgramId = CUR.ProgramMasterId
						  --LEFT JOIN
								--TCD.EcolabTextileCategory ETC WITH (NOLOCK) ON ETC.TextileId = PM.EcolabTextileCategoryId
						  --LEFT JOIN
								--TCD.ChainTextileCategory CTC WITH (NOLOCK) ON  CTC.TextileId = PM.ChainTextileId
						  --LEFT JOIN
								--TCD.PlantChainProgram PCP WITH (NOLOCK) ON PCP.PlantProgramId = PM.PlantProgramId
						  GROUP BY CUR.MachineId,CUR.EcolabWasherId,CUR.ProgramMasterId,CUR.ProductId,CUR.CustomerId,CUR.EcolabTextileId,CUR.ChainTextileId,CUR.PlantProgaramId

		IF NOT EXISTS (SELECT 1 FROM [TCD].[ProductionShiftLaborData] WHERE ShiftId = @ShiftId)
			BEGIN
				INSERT INTO [TCD].[ProductionShiftLaborData]
				SELECT  @ShiftId,
				SLD.LaborTypeId,
				SLD.LaborHours,
				SLD.LaborHours * SLD.PricePerHr
					FROM [TCD].[ShiftLaborData] SLD WITH (NOLOCK) WHERE ShiftId = @LabourShift AND DayId = @DayId
			END
		  
		  DELETE FROM @BatchSummary
		  DELETE FROM @BatchChemicalSummary
		  DELETE FROM @MachineEfficency
		  
	    SET @ShiftCount = @ShiftCount + 1
	END

SET NOCOUNT OFF
END


GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlProductionWaterConsumptionData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlProductionWaterConsumptionData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [TCD].[ProcessMyControlProductionWaterConsumptionData]
(
    @BatchId			   INT,
    @WaterConsumptionXML	   XML,
    @PartitionOn		   DATETIME
)
AS
    BEGIN
	   DECLARE @WaterTypeId		 INT,
			 @StandardQuantity	 INT,
			 @Price			 INT,
			 @EcolabWasherID	 INT


			SELECT   @EcolabWasherID=bd.EcolabWasherId  
			FROM TCD.BatchData bd
			WHERE bd.BatchId=@BatchId 
			 -- 1.Getting xml data  into XmlData with CTE
			 ;WITH XmlData AS 
			 (
				SELECT  T.c.value('@StepNo', 'INT') StepNo,
					   T.c.value('@WCCounter1', 'Decimal(10,2)') + T.c.value('@WCCounter2', 'Decimal(10,2)')  ActualQuantity
				FROM @WaterConsumptionXML.nodes('MyControlConventionalData/WaterConsumptionData/StepConsumption') T(c)
			 )
			 -- inserting records into tcd.BatchStepWaterUsageData table using merge statement
			 MERGE INTO tcd.BatchStepWaterUsageData bswud
			 USING
			 (
				SELECT xd.StepNo,
					  xd.ActualQuantity
				   FROM XmlData xd
			 ) temp 
			 ON bswud.BatchId = @BatchId AND bswud.stepCompartment=temp.stepNo AND bswud.ActualQuantity=temp.ActualQuantity
			 WHEN NOT MATCHED AND
			 (
				temp.ActualQuantity > 0 
			 )
			 THEN 
			 INSERT
			 (
				Batchid,
				StepCompartment,
				WaterTypeId,
				ActualQuantity,
				StandardQuantity,
				Price,
				PartitionOn,
				EcolabWasherId
			 )
			 VALUES
			 (
				@BatchId,
				temp.StepNo,
				NULL,
				temp.ActualQuantity,
				NULL,
				NULL,
				@PartitionOn,
				@EcolabWasherID
			 );
    END

	GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlOnlineCWStepWaterConsumptionData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlOnlineCWStepWaterConsumptionData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessMyControlOnlineCWStepWaterConsumptionData]
(
@ControllerID   INT,
	@VxML       XML
)	
AS
BEGIN
DECLARE @MachineNumber   INT,
		@WasherID INT,
		@MeterID INT,
		@WasherGroupID INT,
		@StepComportmentNO INT,
		@ActualQuantity INT,
		@EcolabWasherId INT,
		@CurrentStepComportmentNO INT

		 SELECT @MachineNumber = T.c.value('@MachineNumber', 'INT')
	    FROM @VxML.nodes('MyControlConventionalData') T(C);
		CREATE TABLE #StepConsumptionData
		(
		    StepNo      INT,
		    Qty         DECIMAL(10, 6)
		)
		 INSERT INTO #StepConsumptionData 
		 SELECT  T.c.value('@StepNo', 'INT'),
		       T.c.value('@WCCounter1', 'Decimal(10,2)')+T.c.value('@WCCounter2', 'Decimal(10,2)')
	    FROM @VxML.nodes('MyControlConventionalData/WaterConsumptionData/StepConsumption') T(C)
		WHERE T.c.value('@WCCounter1', 'Decimal(10,6)')>0 OR T.c.value('@WCCounter2', 'Decimal(10,6)')>0 ;

  --Getting WasherGroupId,WasherId from MachineSetup
   SELECT @WasherGroupID = GroupId,
			 @WasherID = ms.WasherID
	    FROM TCD.MachineSetup ms
	      WHERE ControllerID = @ControllerID
			AND MachineInternalId = @MachineNumber
			AND IsTunnel = 0
			AND IsDeleted = 0;

			--Getting MeterId,WasherId from Meter
			SELECT @MeterID=MeterId
			FROM tcd.Meter mt
			WHERE mt.UtilityType=2 
			AND mt.GroupId=@WasherGroupID 
			AND mt.ControllerID=@ControllerID 
			AND mt.MachineCompartment=@WasherID

		  --Getting @EcolabWasherId from Washer
			SELECT @EcolabWasherId= wr.EcolabWasherId
			FROM TCD.Washer wr
		    WHERE wr.WasherId=@WasherID

		
		SET @CurrentStepComportmentNO=1;
		WHILE(@CurrentStepComportmentNO<=25)
		BEGIN
		SELECT @StepComportmentNO=scd.StepNo,@ActualQuantity=scd.Qty
		FROM #StepConsumptionData scd where scd.StepNo=@CurrentStepComportmentNO
		IF NOT EXISTS(SELECT * FROM TCD.WasherModuleOnlineUsageData WHERE WasherId = @WasherID AND StepComportment =@StepComportmentNO AND ModuleId = @MeterID AND ActualQuantity=@ActualQuantity )
		BEGIN
		IF(@StepComportmentNO IS NOT NULL AND @WasherID IS NOT NULL AND @MeterID IS NOT NULL)
			INSERT INTO TCD.WasherModuleOnlineUsageData
					(WasherId,
					 StepComportment,
					 ModuleId,
					 ActualQuantity,
					 TimeStamp,
					 EcolabWasherId
					)
					SELECT
					@WasherID,
					@StepComportmentNO,
					@MeterID,
					@ActualQuantity,
					GETUTCDATE(),
					@EcolabWasherId
    		END		
        SET  @CurrentStepComportmentNO=@CurrentStepComportmentNO+1;
		 
		END;
END;

GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessConventionalWasherData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessConventionalWasherData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessConventionalWasherData]
( 
 @WasherId INT, 
 @xmlTags XML,
 @RedFlagShiftId INT OUTPUT
)

AS
BEGIN
  DECLARE @BatchID        INT,
    @EcolabWasherId       INT,        
    @CurrencyCode       VARCHAR(50),  
    @MachineInternalId      INT,
    @GroupId        INT,  
    @Prveformula       INT,
    @Quantity        INT,
    @MaxWashertGroupCapacity    INT,

    @ProgramMasterId      INT,
    @NominalLoad       DECIMAL(10,2),
    @MaxLoad        DECIMAL(10,2),
    @StandardWeight       DECIMAL(10,2) ,     

    @CurrentFormula       INT,  
    @CurrentFormulaDate      DATETIME2,
    @FormulaIsModified      BIT,

    @CurrentInjection      INT,
    @CurrentInjectionDate     DATETIME2,
    @InjectionIsModified     BIT,

    @OperationalCount      INT,
    @OperationalIsModified     BIT, 
    
    @CurrentHoldSignal      INT,
    @CurrentHoldSignalDate     DATETIME2,
    @HoldSignalIsModified     BIT,  
             
    @EndofFormula       INT, 
    @EndofFormulaDate      DATETIME2,
    
    @AutoWeightEntryActive     BIT,
    @AutoWeightEntryWeight     DECIMAL(10,2),                                                                                                                              
    @ControllerId       INT,
    @CurrentHoldSignalValue     INT ,
    
    @MeterPlcAddress      INT,
    @MeterPlcAddressIsModified    INT,
    @BatchGroupId       INT,
    @BatchFormula       INT,    
    @HoldTime        INT,
    @CteTempBatchInjections     INT,
    @CteTempWaherReadingInjections   INT,
    @BatchStandardWaterUsage    INT,
    @BatchActualWaterUsage     INT,
    @BatchWaterUsagePrice     Decimal(10,2),
    @BatchUtilityPrice      Decimal(10,2),
    @BatchWaterType       INT,
    @PrevGroupId       INT,
    @WasherMeterExists      BIT,
    @ExtraTime        INT,
    @TargetTurnTime       INT,
    @RatioDosingEnabled      BIT,
	@EcolabAccountNumber NVARCHAR(25) = NULL,
	@PreviousFormulaDate      DATETIME2,
    @PreviousInjectionStep INT,
	@PreviousInjectionStartDate DATETIME2,
	@CurrentInjectionStep INT,
	@WashStepBatchId INT,
	@PrevFormulaExtraTime INT      ,
	@AlarmGroupMasterId INT,
	@StdWashSteps INT,
    @StdInjectionSteps INT,
	@EcolabTextileCategoryId INT,
	@ChainTextileCategoryId INT,
	@FormulaSegmentId INT,
	@EcolabSaturationId INT,
	@PlantProgramId INT,
	@ETechLastDroppedAt  DATETIME2                                                                                                             

  SELECT @ETechLastDroppedAt = NULL 
  IF EXISTS (SELECT  * FROM [TEMPDB].[DBO].[SYSOBJECTS] o where o.xtype in ('U') AND o.id = OBJECT_ID(N'tempdb..#XmlTagsTable'))
   BEGIN
     DROP TABLE #XmlTagsTable
   END


  CREATE TABLE  #XmlTagsTable ( TagId INT, 
          TagValue NVARCHAR(100), 
          ReceivedTime DATETIME2,
          TagType NVARCHAR(50),
          IsModified BIT,
		  ETechLastDropped VARCHAR(100)
         )

 
  INSERT INTO #XmlTagsTable (
          TagId,
          TagValue,
          ReceivedTime,
          TagType,
          IsModified,
		  ETechLastDropped
         )   
  
  SELECT   
     T.c.value('@TagId', 'INT') as TagId,
     T.c.value('@Value', 'NVARCHAR(100)') TagValue,
     T.c.value('@TimeStamp', 'VARCHAR(100)') DateTimeStamp,
     T.c.value('@TagType', 'VARCHAR(50)') TagType,
     T.c.value('@IsModified', 'BIT') TagType,
	 T.c.value('@ETechLastDroppedAt', 'VARCHAR(100)') ETechLastDropped
  FROM  @xmlTags.nodes('Tags/Tag') T(c)
  WHERE 
     T.c.value('@TagId', 'varchar(100)')  IS NOT NULL
 
  SELECT @CurrentFormula     =  TagValue,  
    @CurrentFormulaDate    =  ReceivedTime,
    @FormulaIsModified     =  IsModified
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_FRM'   
     
  SELECT @CurrentInjection    =  TagValue,
    @CurrentInjectionDate   =  ReceivedTime,
    @InjectionIsModified   =  IsModified   
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_INJ'

  SELECT @OperationalCount    =  TagValue,
    @OperationalIsModified   =  IsModified  
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_OPC'  
   
  SELECT @EndofFormula     =  TagValue,
    @EndofFormulaDate    =  ReceivedTime  
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_EOF' 
  
  SELECT @AutoWeightEntryActive   =  TagValue     
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_AWEA'                 

  SELECT @CurrentHoldSignal    =  TagValue, 
    @HoldSignalIsModified   =  IsModified,  
    @CurrentHoldSignalDate   =  ReceivedTime 
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_HOLDL'

  SELECT @AutoWeightEntryWeight   =  TagValue,
  @ETechLastDroppedAt    =  CONVERT(datetime,ETechLastDropped)   
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_AWEW'

  SELECT @MeterPlcAddress    =  TagValue,
    @MeterPlcAddressIsModified  =       IsModified       
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_MPLC'
  
  SELECT @RatioDosingEnabled    =  TagValue      
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_RATA'
  
  SELECT * FROM #XmlTagsTable
  
  SELECT @ExtraTime      =  0
 
  SELECT TOP 1 @BatchID=BatchId, @Prveformula=ProgramNumber,@PrevGroupId=GroupId, @PreviousFormulaDate=StartDate FROM TCD.BatchData WHERE MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC

  IF(@CurrentFormula != @EndofFormula AND
     @CurrentFormula = @Prveformula AND 
  @CurrentInjection = 0 AND
  @OperationalCount = 0 AND
  @CurrentFormulaDate <= @PreviousFormulaDate AND
  @CurrentInjectionDate > @PreviousFormulaDate)
 BEGIN
 --Here means, If the same formula is received without EOF then the timestamp of the formula
 --will be still the old timestamp because value is not changed.
 --In this case assign injection=0 timestamp to formula timestamp
  SELECT @CurrentFormulaDate = @CurrentInjectionDate 
 END

  DECLARE @ShiftStartDate table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
  INSERT INTO @ShiftStartDate(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate

  SELECT DISTINCT 
     @EcolabWasherId    =  Ws.EcolabWasherId,
     @StandardWeight    =  Wps.NominalLoad,
     @CurrencyCode    =  Pl.CurrencyCode,
     @ControllerId    =  Ctrl.ControllerId,
     @TargetTurnTime    =  Ws.TargetTurnTime * 60     
  FROM 
     TCD.Washer Ws  
  INNER JOIN 
     TCD.MachineSetup Mst ON
     Mst.WasherId    =  Ws.WasherId
  INNER JOIN 
     TCD.WasherGroup Wg ON 
     Wg.WasherGroupId   =  Mst.GroupId    
  INNER JOIN 
     TCD.WasherProgramSetup Wps ON 
     Wps.WasherGroupId   =  Wg.WasherGroupId
  LEFT JOIN 
     TCD.WasherDosingSetup Wds ON 
     Wds.WasherProgramSetupId =  Wps.WasherProgramSetupId
  LEFT JOIN 
     TCD.WasherDosingProductMapping Wdpm ON 
     Wdpm.WasherDosingSetupId =  Wds.WasherDosingSetupId
  INNER JOIN 
     TCD.Plant Pl ON 
     Pl.EcolabAccountNumber  =  Ws.EcoLabAccountNumber
  INNER JOIN 
    TCD.ConduitController Ctrl 
    ON Ctrl.ControllerId   =  Mst.ControllerId 
  WHERE Ws.WasherId= @WasherId

  SELECT DISTINCT 
     @MachineInternalId=Mst.MachineInternalId,
     @GroupId=Mst.GroupId     
  FROM TCD.Washer Ws
      INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
      INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
      INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
   WHERE Ws.WasherId=@WasherId  

   SELECT DISTINCT      
     @ProgramMasterId=Wps.ProgramId,
     @NominalLoad=Wps.NominalLoad, --Wps.NominalLoad/CONVERT(decimal(10,2), 100) old code
     @MaxLoad =Ws.MaxLoad,
     @ExtraTime =Wps.ExtraTime
  FROM TCD.Washer Ws
      INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
      INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
      INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
      INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
   WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@CurrentFormula and Wps.Is_Deleted=0

  if(@ExtraTime IS NULL)
  BEGIN
   SELECT @ExtraTime      =  0
  END

  SELECT  @MaxWashertGroupCapacity=Max(ws.MaxLoad)
  FROM TCD.Washer WS
   INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
   INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId  
  WHERE Mst.GroupId=@GroupId

  SELECT @WasherMeterExists = M.MachineCompartment FROM Tcd.MachineSetup Ms
  INNER JOIN Tcd.Meter M ON M.GroupId= Ms.GroupId AND  M.MachineCompartment=Ms.MachineInternalId
  WHERE Ms.WasherId=@WasherId

  if(@AutoWeightEntryActive IS NULL)
  BEGIN
   SELECT @AutoWeightEntryActive = 0
  END

  SELECT @StandardWeight=(@NominalLoad * @MaxWashertGroupCapacity) /CONVERT(decimal(10,2), 100)   
  select @AutoWeightEntryActive,@StandardWeight
  SELECT @AutoWeightEntryWeight=Case @AutoWeightEntryActive WHEN 0 THEN @StandardWeight ELSE  @AutoWeightEntryWeight END  
  
  SELECT @CurrentHoldSignalValue=Id  FROM TCD.ConduitParameters where Name='HoldSignal'
  
   SELECT  * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC
  IF(@HoldSignalIsModified !=0)  
  BEGIN
  IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp =@CurrentHoldSignalDate)
   BEGIN
    INSERT INTO TCD.WasherReading(
         WasherId,
         ParameterId,
         ParameterValue,
         DateTimeStamp,
         PartitionOn,
         EcolabWasherId)
    SELECT    @WasherId,
         @CurrentHoldSignalValue,
         @CurrentHoldSignal,
         @CurrentHoldSignalDate,
         (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
         @EcolabWasherId
   END   
  END
  IF(@FormulaIsModified =1  OR @InjectionIsModified = 1 OR @OperationalIsModified = 1)
  BEGIN
   SELECT 'IsModified',@FormulaIsModified AS FormulaIsModified, 
        @InjectionIsModified AS InjectionIsModified,
        @OperationalIsModified AS OperationalIsModified
   IF(@CurrentFormula != 0)
   BEGIN
       DECLARE @BatchShiftId int,@BatchShiftStartDate datetime
       
       SELECT @BatchShiftStartDate = bd.StartDate FROM TCD.BatchData bd WHERE bd.BatchId = @BatchId

       IF(@BatchShiftStartDate > (SELECT TOP 1 [@ShiftStartDate].ShiftStartdate FROM @ShiftStartDate ORDER BY [@ShiftStartDate].ShiftStartdate ASC)
       AND DATEADD(second,@ExtraTime,@CurrentFormulaDate) > (SELECT TOP 1 [@ShiftStartDate].ShiftStartdate FROM @ShiftStartDate ORDER BY [@ShiftStartDate].ShiftStartdate DESC)
       )
       BEGIN 
         
         SELECT TOP 1  @BatchShiftId = ssdt.ShiftId FROM @ShiftStartDate ssdt ORDER BY ssdt.ShiftStartdate DESC
       END
       ELSE
       BEGIN
        SELECT TOP 1  @BatchShiftId = ssdt.ShiftId FROM @ShiftStartDate ssdt ORDER BY ssdt.ShiftStartdate ASC
       END
       

  SELECT DISTINCT      
   @PrevFormulaExtraTime =Wps.ExtraTime
   FROM TCD.Washer Ws
    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
    INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
    INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
    WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@Prveformula and Wps.Is_Deleted=0

  IF(@PrevFormulaExtraTime IS NULL)
  BEGIN
   SELECT @PrevFormulaExtraTime      =  0
  END

     IF(@CurrentFormula = @EndofFormula)
     BEGIN   
     SELECT * FROM #XmlTagsTable
      IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData 
           WHERE 
           BatchId=@BatchId AND 
           MachineId=@WasherId AND 
           EndDate IS NULL 
           ORDER BY StartDate DESC  )
       BEGIN
                                       
        UPDATE TCD.BatchData 
         SET EndDate = DATEADD(second,@PrevFormulaExtraTime,@CurrentFormulaDate),EndDateFormula = @CurrentFormulaDate,ShiftId = @BatchShiftId 
       WHERE  BatchId = @BatchId AND MachineId=@WasherId   
    
    DECLARE @ShiftMapping1 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
    INSERT INTO @ShiftMapping1(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate

    SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
      IF(@PreviousInjectionStep IS NOT NULL)
      BEGIN
       UPDATE TCD.BatchWashStepData SET EndTime=DATEADD(second,@ExtraTime,@CurrentFormulaDate) WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate
      END
                                                                   
       END 
     END 
     ELSE IF((@CurrentFormula != @Prveformula) AND (@BatchID IS NOT NULL))
     BEGIN  
     IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC  )
        BEGIN                          
         UPDATE TCD.BatchData
          SET EndDate = @CurrentFormulaDate,EndDateFormula = @CurrentFormulaDate,ShiftId = @BatchShiftId 
         WHERE  BatchId = @BatchId AND MachineId=@WasherId  
   
     INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,19,1,(SELECT Top 1 ShiftStartdate from @ShiftStartDate) 
     
     DECLARE @ShiftMapping2 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
   INSERT INTO @ShiftMapping2(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate
    
    SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
     IF(@PreviousInjectionStep IS NOT NULL)
     BEGIN
      UPDATE TCD.BatchWashStepData SET EndTime=@CurrentFormulaDate WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate
     END
       
        END 
      END
     ELSE IF((@CurrentInjection = 0) AND(@OperationalCount = 0) AND (@CurrentFormulaDate != @PreviousFormulaDate))
     BEGIN  
     IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC)
        BEGIN                           
         UPDATE TCD.BatchData
          SET EndDate = @CurrentInjectionDate,ShiftId = @BatchShiftId,EndDateFormula = @CurrentInjectionDate
         WHERE  BatchId = @BatchId AND MachineId=@WasherId  
   
    INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,19,1,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)

    DECLARE @ShiftMapping3 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
   INSERT INTO @ShiftMapping3(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentInjectionDate
      
   SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
     IF(@PreviousInjectionStep IS NOT NULL)
     BEGIN
      UPDATE TCD.BatchWashStepData SET EndTime=@CurrentInjectionDate WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate
     END

        END 
      END
   
    -- Hold Time
     IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
      BEGIN

      
      SELECT   @HoldTime=SUM(Wr.ParameterValue) FROM TCD. BatchData Bd
      INNER JOIN TCD.WasherReading Wr ON Wr.WasherId=Bd.MachineId
      WHERE Bd.BatchId=@BatchId  AND Wr.DateTimeStamp BETWEEN Bd.StartDate AND  Bd.EndDate and   Wr.ParameterId=9 -- Hold Signal value

      INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,17,@HoldTime,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)


     END
     
     -- CapturingMeter Plc Address EndRedaing 
     IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
      BEGIN
      IF(@WasherMeterExists IS NOT NULL AND @MeterPlcAddress > 0)
      BEGIN
       IF(@MeterPlcAddressIsModified !=0)  
       BEGIN
       IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp =@CurrentFormulaDate)
       BEGIN
        INSERT INTO TCD.WasherReading(
         WasherId,
         ParameterId,
         ParameterValue,
         DateTimeStamp,
         PartitionOn,
         EcolabWasherId)
        SELECT 
         @WasherId,
         14, --MeterPlcAddress for EndSReading
         @MeterPlcAddress,
         @CurrentFormulaDate,
         (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
         @EcolabWasherId
       END

      END
      END
     END
         
     --Start Good or Bad Injection in BatchDataTable
     IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
      BEGIN
        ;WITH CteTempWaherReadingInjections  ( 
        InjectionsCount,BatchId,WasherId,ProgramNumber,Injectons
       ) AS  
       (
        SELECT DISTINCT Wr.ParameterValue,
            BD.BatchId,
            Wr.WasherId,
            Bd.ProgramNumber,
            Wr.ParameterValue FROM TCD. BatchData Bd
        INNER JOIN 
          TCD.WasherReading Wr ON Wr.WasherId   =  Bd.MachineId 
        WHERE    
              Wr.ParameterId    =  10    AND 
              Wr.ParameterValue   <>  0    AND 
              Bd.BatchId     =  @BatchID AND WR.DateTimeStamp BETWEEN BD.StartDate AND BD.EndDate) 
        SELECT @CteTempWaherReadingInjections=COUNT(CTE1.InjectionsCount)
        FROM CteTempWaherReadingInjections CTE1 
        INNER JOIN TCD.BatchData Bd ON Bd.BatchId=CTE1.BatchId
        WHERE Bd.BatchId=@BatchId

        ;WITH CteTempBatchInjections ( 
        InjectionsCount,BatchId,WasherId,ProgramNumber,Injectons
       ) AS  
       (
        SELECT  DISTINCT Wdpm.InjectionNumber,
            Bd.BatchId,
            Wps.ProgramNumber,
            Ws.WasherId,Wdpm.
            InjectionNumber
         FROM TCD.Washer WS
          INNER JOIN 
             TCD.MachineSetup Mst ON 
             Mst.WasherId     =  WS.WasherId
          INNER JOIN 
             TCD.WasherGroup Wg ON 
             Wg.WasherGroupId    =  Mst.GroupId       
          INNER JOIN 
             TCD.WasherProgramSetup Wps ON 
             Wps.WasherGroupId    =  Wg.WasherGroupId
          INNER JOIN 
             TCD.WasherDosingSetup Wds ON 
             Wds.WasherProgramSetupId  =  Wps.WasherProgramSetupId
          INNER JOIN 
             TCD.WasherDosingProductMapping Wdpm ON 
             Wdpm.WasherDosingSetupId  =  Wds.WasherDosingSetupID
          INNER JOIN 
             TCD.ProductdataMapping Pdm ON 
             Pdm.ProductId     =  Wdpm.ProductId
          INNER JOIN 
             TCD.BatchData Bd ON 
             Bd.MachineId     =  Ws.WasherId 
          INNER JOIN 
             TCD.WasherReading Wr ON 
             Wr.WasherId      =  Bd.MachineId
        WHERE 
        
             Wps.ProgramNumber    =  @Prveformula  AND 
             Bd.BatchId      =  @BatchID   AND 
             Ws.WasherId      =  @WasherId    )
        SELECT @CteTempBatchInjections=COUNT(CTE2.InjectionsCount)
        FROM CteTempBatchInjections CTE2 
        INNER JOIN TCD.BatchData Bd ON Bd.BatchId=CTE2.BatchId 
        WHERE Bd.BatchId=@BatchID


        Insert Tcd.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchID,@EcolabWasherId,18,
          CASE WHEN @CteTempBatchInjections = @CteTempWaherReadingInjections THEN 1
            WHEN @CteTempBatchInjections != @CteTempWaherReadingInjections THEN 3 END,
            (SELECT Top 1 ShiftStartdate from @ShiftStartDate) 
                           
    END
     --End Good or Bad Injection in BatchDataTable 
     IF(@OperationalCount = 0 AND @CurrentInjection = 0) AND (@CurrentFormula != @EndofFormula)
     BEGIN 
      IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchData WHERE MachineId=@WasherId AND StartDate =@CurrentFormulaDate)
      BEGIN     
       
       --Start Getting InjectionCount and StepCount
       SELECT 
       @StdInjectionSteps=count(DISTINCT wdpm.WasherDosingSetupId),
       @StdWashSteps= count(DISTINCT wds.WasherDosingSetupId)-count(DISTINCT wdpm.WasherDosingSetupId)
       FROM TCD.WasherDosingProductMapping wdpm
       RIGHT JOIN tcd.WasherDosingSetup wds on wdpm.WasherDosingSetupId=wds.WasherDosingSetupId
       WHERE wds.GroupId=@GroupId AND wds.ProgramNumber=@CurrentFormula
       --End Getting InjectionCount and StepCount
       --Start-----ProgramMasterID logic for PlantChainProgram
        SELECT 
        @PlantProgramId=pm.PlantProgramId,
        @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
        @ChainTextileCategoryId = pm.ChainTextileId,
        @FormulaSegmentId = pm.FormulaSegmentId,
        @EcolabSaturationId = pm.EcolabSaturationId 
        FROM TCD.ProgramMaster pm WHERE pm.ProgramId=@ProgramMasterId AND pm.Is_Deleted=0
        IF(@PlantProgramId <> 0  AND @PlantProgramId IS NOT NULL)
         BEGIN
            --Assign value from plantchainprogram table based on plantprogramId
            SELECT
             @EcolabTextileCategoryId = pcp.EcolabTextileCategoryId,
             @ChainTextileCategoryId = pcp.ChainTextileCategoryId,
             @FormulaSegmentId = pcp.FormulaSegmentId,
             @EcolabSaturationId = pcp.EcolabSaturationId
             FROM tcd.PlantChainProgram pcp
             WHERE pcp.PlantProgramId=@PlantProgramId AND pcp.Is_Deleted=0
         END
       --End-----ProgramMasterID logic for PlantChainProgram

       INSERT INTO TCD.BatchData(
          ControllerBatchId ,
          EcolabWasherId,
          GroupId ,
          MachineInternalId,
          PlantWasherNumber,
          StartDate ,
          EndDate ,
          ProgramNumber,
          ProgramMasterId,
          MachineId,
          ActualWeight,
          StandardWeight,
          CurrencyCode,
          ShiftId,         
          PartitionOn,
          TargetTurnTime,
          StdInjectionSteps,
          StdWashSteps,
          EcolabTextileCategoryId,
          ChainTextileCategoryId,
          FormulaSegmentId,
          EcolabSaturationId,
          PlantProgramId,
		  ETechlastDroppedTimeStamp          
          )


         SELECT DISTINCT 0
          ,@EcolabWasherId
          ,@GroupId
          ,@MachineInternalId
          ,Ws.PlantWasherNumber
          ,@CurrentFormulaDate
          ,NULL
          ,@CurrentFormula
          ,@ProgramMasterId
          ,@WasherId
          ,@AutoWeightEntryWeight
          ,@StandardWeight 
          ,@CurrencyCode
          ,(SELECT Top 1 ShiftId from @ShiftStartDate)         
          ,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
          ,@TargetTurnTime
          ,@StdInjectionSteps
          ,@StdWashSteps
          ,@EcolabTextileCategoryId
          ,@ChainTextileCategoryId
          ,@FormulaSegmentId
          ,@EcolabSaturationId
          ,@PlantProgramId
		  ,@ETechLastDroppedAt           

       FROM TCD.Washer Ws
          INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
          INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
          INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
       WHERE Ws.WasherId=@WasherId 
   
       SET @BatchID=SCOPE_IDENTITY() 
         
       INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,38,@StdWashSteps,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)

       --If the received formula is not configured in enVision then create an alarm 
       IF(@ProgramMasterId is NULL)
       BEGIN
       SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant;
       SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.AlarmGroupMsterVsControllerModelType AGMVCMT
       INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
       WHERE AGMVCMT.AlarmCode = 9000
        INSERT INTO [TCD].[AlarmData] 
           (EcoalabAccountNumber,
           AlarmCode,
           BatchId,
           controllerID,
           StartDate,
           GroupId,
           MachineInternalId,
           ProgramId,   
           IsActive,
           EndDate,
           MachineId,
           AlarmGroupMasterId)
           SELECT
            @ECOLABAccountNumber,
            9000,
            @BatchID,
            @ControllerId,
            @CurrentFormulaDate,
            @GroupId,
            @MachineInternalId,
            @CurrentFormula,
            0,
            @CurrentFormulaDate,
            @WasherId,
            @AlarmGroupMasterId
       END

         
         INSERT INTO TCD.BatchCustomerData
         (
         BatchId,
         CustomerId,
         Weight,
         PiecesCount,
         PartitionOn,
         EcolabWasherId
         )
        SELECT Bd.BatchId,  
        --SELECT @BatchID,
         Pc.ID,
         @AutoWeightEntryWeight,
         ROUND(COALESCE((@AutoWeightEntryWeight * Pm.Pieces) / NULLIF(Pm.Weight,0), 0),0),
         (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
         @EcolabWasherId
        
      
       FROM TCD.Washer WS
        INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
        INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId       
        INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
        INNER JOIN TCD.ProgramMaster Pm ON Pm.ProgramId=Wps.ProgramId
        INNER JOIN TCD.PlantCustomer Pc ON Pc.ID=Pm.CustomerId
        INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
       WHERE 
        Ws.WasherId=@WasherId AND 
        Wps.ProgramNumber=@CurrentFormula AND 
        Bd.BatchId=@BatchID  AND 
        Pm.CustomerId != -1 

       IF(@WasherMeterExists IS NOT NULL AND @MeterPlcAddress > 0)
       BEGIN        
        IF(@MeterPlcAddressIsModified !=0)  
        BEGIN
          INSERT INTO TCD.WasherReading(
           WasherId,
           ParameterId,
           ParameterValue,
           DateTimeStamp,
           PartitionOn,
           EcolabWasherId)
          SELECT 
           @WasherId,
           13, --MeterPlcAddress for StartReading
           @MeterPlcAddress,
           @CurrentFormulaDate,
           (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
           @EcolabWasherId
        END
       END 
      END              
     END      
     IF(@BatchID IS NOT NULL)     
     BEGIN
     IF(@CurrentInjection <= 0)
      BEGIN
       SET @CurrentInjectionDate=@CurrentFormulaDate
      END 
      IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp =@CurrentInjectionDate)
      BEGIN      
      INSERT INTO TCD.WasherReading(
          WasherId,
          ParameterId,
          ParameterValue,
          DateTimeStamp,
          PartitionOn,
          EcolabWasherId)
      SELECT   @WasherId,
          CASE TagType 
          WHEN 'Tag_FRM' THEN  5  
          WHEN 'Tag_INJ' THEN  10 
          WHEN 'Tag_OPC' THEN  11 
          END,
          TagValue,          
          @CurrentInjectionDate,
          (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
          @EcolabWasherId
       FROM  #XmlTagsTable 
       WHERE  Tagtype in ('Tag_FRM','Tag_INJ','Tag_OPC')         
     END
     END
    IF(@CurrentInjection > 0)     
     BEGIN
      IF (@RatioDosingEnabled = 1)
       BEGIN
       IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurrentInjectionDate and batchid=@BatchID)
       BEGIN
        INSERT INTO TCD.BatchProductData(BatchId,StepCompartment,ActualQuantity,StandardQuantity,Price,TimeStamp,PartitionOn,EcolabWasherId,ProductId)
        SELECT Bd.BatchId 
        --SELECT @BatchID 
         ,Wds.StepNumber
         ,(((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100)) * (@AutoWeightEntryWeight/@StandardWeight) AS ActualQuantity  
         ,(((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100)) * (@AutoWeightEntryWeight/@StandardWeight) AS StandardQuantity      
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * @MaxWashertGroupCapacity)/CONVERT(decimal(10,2), 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price         
         ,@CurrentInjectionDate
         ,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
         ,@EcolabWasherId
         ,Pdm.ProductID
        FROM TCD.Washer WS
         INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
         INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
         INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
         INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
         INNER JOIN TCD.WasherDosingSetup Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
         INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
         INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Wdpm.ProductId
         INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
        WHERE 
          Ws.WasherId=@WasherId     AND 
          Wps.ProgramNumber=@CurrentFormula  AND 
          Wdpm.InjectionNumber=@CurrentInjection AND
          Bd.BatchId=@BatchID AND
    Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
       END
       END
      ELSE
       BEGIN
       IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurrentInjectionDate and batchid=@BatchID)
       BEGIN
        INSERT INTO TCD.BatchProductData(BatchId,StepCompartment,ActualQuantity,StandardQuantity,Price,TimeStamp,PartitionOn,EcolabWasherId,ProductId)
        SELECT Bd.BatchId  
        --SELECT @BatchID
         ,Wds.StepNumber
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100) AS ActualQuantity  
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100) AS StandardQuantity      
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * @MaxWashertGroupCapacity)/CONVERT(decimal(10,2), 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price         
         ,@CurrentInjectionDate
         ,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
         ,@EcolabWasherId
         ,Pdm.ProductID
        FROM TCD.Washer WS
         INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
         INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
         INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
         INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
         INNER JOIN TCD.WasherDosingSetup Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
         INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
         INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Wdpm.ProductId
         INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
        WHERE 
          Ws.WasherId=@WasherId     AND 
          Wps.ProgramNumber=@CurrentFormula  AND 
          Wdpm.InjectionNumber=@CurrentInjection AND
          Bd.BatchId=@BatchID AND
    Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
       END  
       END 
       
  --Populating BatchWashstepdata
      SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
      
      IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchWashStepData WHERE StartTime =@CurrentInjectionDate and batchid=@BatchID)
      BEGIN
         SELECT @CurrentInjectionStep=Wds.StepNumber,
             @WashStepBatchId=Bd.BatchId
                 
         FROM TCD.Washer WS
          INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
          INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
          INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
          INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
          INNER JOIN TCD.WasherDosingSetup Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
          INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
          INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Wdpm.ProductId
          INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
         WHERE 
          Ws.WasherId=@WasherId     AND 
          Wps.ProgramNumber=@CurrentFormula  AND 
          Wdpm.InjectionNumber=@CurrentInjection AND
          Bd.BatchId=@BatchID AND
          Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0

         IF(@CurrentInjectionStep IS NOT NULL)
         BEGIN
          INSERT INTO TCD.BatchWashStepData(BatchId,StepCompartment,StartTime,PartitionOn,EcolabWasherId)
          VALUES (@WashStepBatchId,  @CurrentInjectionStep, @CurrentInjectionDate, (SELECT Top 1 ShiftStartdate from @ShiftStartDate), @EcolabWasherId)                
         
          UPDATE TCD.BatchWashStepData SET EndTime=@CurrentInjectionDate WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate         
         END

      END
      --End Populating BatchWashstepdata

      --Start Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
      IF NOT EXISTS(SELECT * FROM TCD.BatchParameters WHERE ParameterId =37 and batchid=@BatchID)
      BEGIN
       INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,37,1,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)       
      END
      ELSE
      BEGIN
       Update TCD.BatchParameters SET ParameterValue=@CurrentInjection WHERE ParameterId =37 and batchid=@BatchID
      END
        --End Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record

           
     END

     UPDATE TCD.ConduitController
      SET LastConnectedTime  = GETUTCDATE()
      WHERE ControllerId   = @ControllerId
   END
  END
 END

---------------------------------------------

GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessTunnelWasherData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessTunnelWasherData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessTunnelWasherData]
 ( 
 @WasherId INT, 
 @xmlTags XML,
 @RedFlagShiftId INT OUTPUT
)
AS
BEGIN
  DECLARE @BatchID      INT,
    @EcolabWasherId     INT,        
    @CurrencyCode     VARCHAR(50),  
    @MachineInternalId    INT ,
    @GroupId      INT,  
    @Prveformula     INT,
    @Quantity      INT,
    @MaxWashertGroupCapacity  INT,
    @PrevBatchId     INT,
    @PrevLoadId      INT,
    @ExistedLoadId     INT,
    @NumberOfCompartments   INT,
    @ProgramMasterId    INT,
    @NominalLoad     Decimal(10,2),
    @MaxLoad      Decimal(10,2),
    @StandardWeight     Decimal(10,2) ,     
    @PlantWasherNumber    INT,
           
    @CurrentDay      DATE=CAST(GETUTCDATE() as date),
    @TempTunnelTimeStamp   DATETIME2,

    @ControllerId     INT ,
    @CurrentHoldSignal    INT,
    
    @TotalRunTime     INT,
    @BatchGroupId     INT,
    @BatchFormula     INT,
    @BatchStartDate     DATETIME2,
    @BatchEndDate     DATETIME2,
    @HoldTime      INT,
    @CteTempBatchTunnelWashSteps INT,
    @CteTemTunnelWashSetps   INT,
    @PrevFormula     INT,
    @PrevStepCompartment   INT,
    @BatchStandardWaterUsage  INT,
    @BatchActualWaterUsage   INT,
    @BatchWaterUsagePrice   Decimal(10,2),
    @BatchUtilityPrice    Decimal(10,2),
    @BatchWaterType     INT,
    @ExtraTime      INT,
    @TargetTurnTime     INT,
    @EcolabAccountNumber NVARCHAR(25) = NULL,
    @AlarmGroupMasterId INT,
    @PartitionOn SMALLDATETIME,
    @StdInjectionSteps INT,
    @StdWashSteps INT,
    @EcolabTextileCategoryId INT,
    @ChainTextileCategoryId INT,
    @FormulaSegmentId INT,
    @EcolabSaturationId INT,
    @PlantProgramId INT,
	@ETechLastDroppedAt  DATETIME2         
                                      
  SELECT @ExtraTime = 0

  SELECT DISTINCT      
     @NumberOfCompartments=MST.NumberOfComp,
     @EcolabWasherId=Ws.EcolabWasherId
   FROM  TCD.Washer Ws
   INNER JOIN 
      TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId     
  WHERE Ws.WasherId=@WasherId and Ws.Is_Deleted=0
  
    
  IF EXISTS (SELECT  * FROM TEMPDB.DBO.SYSOBJECTS o where o.xtype in ('U') AND o.id = OBJECT_ID(N'tempdb..#XmlTagsTable'))
   BEGIN
     DROP TABLE #XmlTagsTable
   END
  CREATE TABLE  #XmlTagsTable ( CurrentFormula    INT,
          CurretnInjection   INT,
          CurrentOperationCounter  INT,
          Eof       INT,
          TunnelTimeStamp    DATETIME2,
          OnHold      BIT,          
          CompartmentId    INT, 
          CompartmentLoadId   INT, 
          CompartmentFormulaId  INT,          
          ReceivedTime    DATETIME2,
          AutoWeightEntryActive  VARCHAR(10),
          AutoWeightEntryWeight  INT,
          IsFormulaModified   BIT,
          IsHoldSignalModified  BIT ,
          IsStopSinalModified   BIT,
          StopSignal     INT,
          RatioDosingEnabled   INT,
		  ETechLastDropped VARCHAR(100)      
         )
  INSERT INTO #XmlTagsTable (
          CurrentFormula ,
          CurretnInjection,          
          CurrentOperationCounter,
          Eof,
          TunnelTimeStamp ,
          OnHold,
          CompartmentId, 
          CompartmentLoadId, 
          CompartmentFormulaId,
          ReceivedTime,
          AutoWeightEntryActive,
          AutoWeightEntryWeight,
          IsFormulaModified,
          IsHoldSignalModified,
          IsStopSinalModified,
          StopSignal,
          RatioDosingEnabled,
		  ETechLastDropped 
         )   
  
  -- Populate tempdata from xml
  SELECT T.c.value('../@CurrentFormula', 'INT') AS CurrentFormula, 
    T.c.value('../@CurrentInjection', 'INT') AS CurretnInjection,     
    T.c.value('../@CurrentOperationCounter', 'INT') AS CurrentOperationCounter,       
    T.c.value('../@Eof', 'INT') AS EndofFormula, 
    T.c.value('../@TimeStamp', 'VARCHAR(100)') AS TunnelTimeStamp, 
    T.c.value('../@OnHold', 'VARCHAR(100)') AS OnHold, 
    T.c.value('@CompartmentId', 'INT') AS CompartmentId, 
    T.c.value('@LoadId', 'INT') AS CompartmentLoadId, 
    T.c.value('@FormulaId', 'INT') AS CompartmentFormulaId,     
    T.c.value('@TimeStamp', 'VARCHAR(100)') DateTimeStamp,
    T.c.value('../@Awea', 'VARCHAR(10)') AS AutoWeightEntryActive,     
    T.c.value('../@Awew', 'INT') AS AutoWeightEntryWeight, 
    T.c.value('../@IsFormulaModified', 'BIT') AS IsFormulaModified,
    T.c.value('../@IsHoldSignalModified', 'BIT') AS IsHoldSignalModified,
    T.c.value('../@IsStopSinalModified', 'BIT') AS IsStopSinalModified,
    T.c.value('../@StopSignal', 'INT') AS StopSignal,
    T.c.value('../@RATA', 'INT') AS RatioDosingEnabled,
	T.c.value('../@ETechLastDroppedAt', 'VARCHAR(100)') AS ETechLastDropped
    
    
  
  FROM @xmlTags.nodes('/Tunnel/Compartment')  T(c)

  
  WHERE 
  T.c.value('@LoadId', 'VARCHAR(100)')  != 0
  AND
  T.c.value('@CompartmentId', 'INT')    <= @NumberOfCompartments

  --ETech last dropped 
  SELECT @ETechLastDroppedAt=CONVERT(datetime,ETechLastDropped) from #XmlTagsTable

  IF EXISTS (SELECT 1 FROM #XmlTagsTable where IsHoldSignalModified = 1)  
   BEGIN   
    SELECT @CurrentHoldSignal = Id  FROM TCD.ConduitParameters where Name='HoldSignal'
    INSERT INTO TCD.WasherReading(
        WasherId,
        ParameterId,
        ParameterValue,
        DateTimeStamp,
        EcolabWasherId)
     SELECT  @WasherId,
        @CurrentHoldSignal,
        OnHold,
        ReceivedTime,
        @EcolabWasherId 
     FROM #XmlTagsTable
   END 
  IF EXISTS (SELECT 1 FROM #XmlTagsTable where IsStopSinalModified = 1)  
   BEGIN 
    INSERT INTO TCD.WasherReading(
       WasherId,
       ParameterId,
       ParameterValue,
       DateTimeStamp,
       EcolabWasherId)
    SELECT  @WasherId,
       12,
       StopSignal,
       ReceivedTime,
       @EcolabWasherId
    FROM #XmlTagsTable
   END 
  IF EXISTS (SELECT 1 FROM #XmlTagsTable where IsFormulaModified = 1)  
   BEGIN
  
   -- Start find missing load id form xml  and set end date for corresponding enddates in the database
   DECLARE @TempExisitingLoadIds table(ExstingLoadId INT,ExistsBatchId int)
   INSERT INTO @TempExisitingLoadIds(ExstingLoadId,ExistsBatchId)
    SELECT Bd.ControllerBatchId,Bd.BatchId FROM TCD.BatchData Bd     
     --INNER JOIN TCD.BatchWashStepData Bwsd on Bwsd.BatchId=Bd.BatchId
    WHERE Bd.MachineId=@WasherId AND Bd.EndDate IS NULL ORDER BY Bd.StartDate DESC   
  
   SELECT @TempTunnelTimeStamp =(SELECT T.c.value('./@TimeStamp', 'VARCHAR(100)') AS TunnelTimeStamp FROM @xmlTags.nodes('/Tunnel')  T(c))
   
   DECLARE @TempBatchStepIs TABLE(StepBatchId INT)
   INSERT INTO @TempBatchStepIs (StepBatchId)
   SELECT ExistsBatchId 
    FROM @TempExisitingLoadIds 
    WHERE ExstingLoadId NOT IN (SELECT CompartmentLoadId FROM #XmlTagsTable)
  
  SELECT @PrevStepCompartment=StepCompartment,@PrevBatchId =BatchID 
  FROM TCD.BatchWashStepData  
  WHERE BatchId in (select StepBatchId from @TempBatchStepIs) AND EndTime IS NULL

  UPDATE 
  TCD.BatchWashStepData 
  SET EndTime = @TempTunnelTimeStamp
  WHERE BatchId in (select StepBatchId from @TempBatchStepIs) AND EndTime IS NULL

  DECLARE @BatchShiftId int
  DECLARE @ShiftStartDateTemp table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
  INSERT INTO @ShiftStartDateTemp(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @TempTunnelTimeStamp
  SELECT @BatchShiftId = ssdt.ShiftId FROM @ShiftStartDateTemp ssdt ORDER BY ssdt.ShiftStartdate

  -- Updating Batches moved out of the tunnel
  UPDATE TCD.BatchData 
  SET  
    EndDate=@TempTunnelTimeStamp
   , EndDateFormula=@TempTunnelTimeStamp,
   ShiftId = @BatchShiftId
  WHERE BatchId in (select StepBatchId from @TempBatchStepIs)

  --End find missing load id form xml  and set end date for corresponding enddates in the database
   
  --Start HoldTime Calculation
   SELECT 
     @BatchGroupId=GroupId
    , @BatchFormula=ProgramNumber
    , @BatchStartDate=StartDate
    , @BatchEndDate=EndDate 
   FROM TCD.BatchData 
   WHERE BatchId IN (select  StepBatchId from @TempBatchStepIs)

   SELECT @TotalRunTime=TotalRunTime 
   FROM TCD.TunnelProgramSetup 
   WHERE WasherGroupId =@BatchGroupId 
    AND ProgramNumber=@BatchFormula

   
   INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) 
   SELECT StepBatchId,@EcolabWasherId,17,(DATEDIFF(SECOND, @BatchStartDate, @BatchEndDate))-@TotalRunTime,bd.partitionon
            FROM @TempBatchStepIs,TCD.BatchData bd WHERE bd.BatchId= [@TempBatchStepIs].StepBatchId  and [@TempBatchStepIs].StepBatchId NOT IN (SELECT BATCHID FROM TCD.BatchParameters AS BP WHERE BP.ParameterId = 17)
 
  --End HoldTime Calculation

    --Start Good or Bad Injection in BatchDataTable
     IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@PrevBatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
      BEGIN
     
       ;WITH CteTempBatchTunnelStepData  ( 
        InjectionsCount,BatchId,ProgramNumber
       ) AS  
       (
        SELECT DISTINCT Bws.StepCompartment,
            BD.BatchId,            
            Bd.ProgramNumber
            FROM TCD. BatchData Bd
        INNER JOIN 
          TCD.BatchWashStepData Bws 
               ON Bws.BatchId   =  Bd.BatchId 
        WHERE    
              
              Bd.BatchId     =  @PrevBatchId ) 
        SELECT @CteTemTunnelWashSetps=COUNT(CTE1.InjectionsCount)
        FROM CteTempBatchTunnelStepData CTE1 
        INNER JOIN TCD.BatchData Bd ON Bd.BatchId=CTE1.BatchId
        WHERE Bd.BatchId=@BatchId

        ;WITH CteTempBatchInjections ( 
        InjectionsCount,ProgramNumber
       ) AS  
       (
        SELECT  DISTINCT 
            
            Tds.CompartmentNumber,
            Tps.ProgramNumber
           FROM TCD.TunnelProgramSetup Tps 
          INNER JOIN 
             TCD.TunnelDosingSetup Tds ON 
              Tds.TunnelProgramSetupId =  Tps.TunnelProgramSetupId
          INNER JOIN 
             TCD.TunnelDosingProductMapping Tdpm ON 
             Tdpm.TunnelDosingSetupId  =  Tds.TunnelDosingSetupId
          INNER JOIN 
             TCD.ControllerEquipmentSetup Ces ON 
             Ces.ControllerEquipmentSetupId =  Tdpm.ControllerEquipmentSetupId
             WHERE                            
             Tps.ProgramNumber    =  @PrevFormula )
        SELECT @CteTempBatchTunnelWashSteps=COUNT(CTE2.InjectionsCount)
        FROM CteTempBatchInjections CTE2 

          Insert Tcd.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @PrevBatchId,@EcolabWasherId,18,
          CASE WHEN @CteTempBatchTunnelWashSteps = @CteTemTunnelWashSetps THEN 1
            WHEN @CteTempBatchTunnelWashSteps != @CteTemTunnelWashSetps THEN 3 END,
            (SELECT PartitionOn FROM TCD.BatchData where BatchId=@PrevBatchId and MachineId=@WasherId)
              
              
                
    END

   -- End Good or Bad Injection in BatchDataTable


 -- Fetching data from cursor
   DECLARE @MYCURSOR CURSOR
   SET @MYCURSOR = CURSOR FAST_FORWARD
   FOR
   SELECT  CurrentFormula ,
      CurretnInjection,          
      CurrentOperationCounter,
      Eof,
      TunnelTimeStamp ,
      OnHold,
      CompartmentId, 
      CompartmentLoadId, 
      CompartmentFormulaId,
      ReceivedTime,
      AutoWeightEntryActive,
      AutoWeightEntryWeight,
      IsFormulaModified,
      IsHoldSignalModified,
      IsStopSinalModified,
      StopSignal,
      RatioDosingEnabled

    FROM #XmlTagsTable ORDER BY CompartmentId ASC
   DECLARE   @CurCurrentFormula     INT,
       @CurCurretnInjection   INT,
       @CurCurrentOperationCounter  INT,
       @CurEof       INT,
       @CurTunnelTimeStamp    DATETIME2,
       @CurOnHold      BIT,
       @CurCompartmentId    INT, 
       @CurCompartmentLoadId   INT, 
       @CurCompartmentFormulaId  INT,
       @CurReceivedTime    DATETIME2,
       @AutoWeightEntryActive   VARCHAR(10),
       @AutoWeightEntryWeight   INT,
       @IsFormulaModified    BIT,
       @IsHoldSignalModified   BIT,
       @IsStopSinalModified   BIT,
       @StopSignal      INT,
       @RatioDosingEnabled    INT 

   OPEN @MYCURSOR
   FETCH NEXT FROM @MYCURSOR
       INTO @CurCurrentFormula   ,
       @CurCurretnInjection   ,
       @CurCurrentOperationCounter  ,
       @CurEof       ,
       @CurTunnelTimeStamp    ,
       @CurOnHold      ,
       @CurCompartmentId    , 
       @CurCompartmentLoadId   , 
       @CurCompartmentFormulaId  ,
       @CurReceivedTime    ,
       @AutoWeightEntryActive   ,
       @AutoWeightEntryWeight   ,
       @IsFormulaModified    ,
       @IsHoldSignalModified   ,
       @IsStopSinalModified   ,
       @StopSignal      ,
       @RatioDosingEnabled
   WHILE @@FETCH_STATUS = 0
   BEGIN
    

   IF(@IsFormulaModified !=0) 
   BEGIN
    IF(@CurCurrentFormula != @CurEof and @CurCurretnInjection = 0 and @CurCurrentOperationCounter = 0)
     BEGIN

   SELECT DISTINCT        
       @MachineInternalId   = Mst.MachineInternalId,
       @GroupId     = Mst.GroupId,
       @ControllerId    = Ctrl.ControllerId    
     FROM TCD.Washer Ws
      INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
      INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
      INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
      INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId = Mst.ControllerId
     WHERE Ws.WasherId=@WasherId  

    SELECT DISTINCT 
       @ProgramMasterId   = Wps.ProgramId,
       @NominalLoad    = Wps.NominalLoad,
       @MaxLoad     = Ws.MaxLoad,
       @CurrencyCode    = Pl.CurrencyCode, 
       @TargetTurnTime    =   (3600/(Wps.TotalRunTime/Mst.NumberofComp))

    FROM TCD.Washer Ws
      INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
      INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
      INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
      INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
      INNER JOIN TCD.Plant Pl ON Pl.EcolabAccountNumber =  Ws.EcoLabAccountNumber
      
    WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@CurCurrentFormula and Wps.Is_Deleted=0

    select @PlantWasherNumber = plantwashernumber from tcd.washer where washerid = @WasherId
 
    SELECT  @MaxWashertGroupCapacity  = Max(ws.MaxLoad)
    FROM TCD.Washer WS
     INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
     INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId  
    WHERE Mst.GroupId=@GroupId

    SELECT @StandardWeight     = @NominalLoad          
    SELECT @AutoWeightEntryWeight=Case @AutoWeightEntryActive WHEN 'False' THEN @StandardWeight ELSE  @AutoWeightEntryWeight END 
    
      
    SELECT @MachineInternalId,@GroupId,@ProgramMasterId,@NominalLoad,@WasherId,@CurCurrentFormula,@PrevBatchId
    SELECT @CurCurrentFormula    AS CurCurrentFormula   ,
       @CurCurretnInjection  AS CurCurretnInjection  ,
       @CurCurrentOperationCounter AS CurCurrentOperationCounter ,
       @CurEof      AS CurEof   ,
       @CurTunnelTimeStamp   AS CurTunnelTimeStamp  ,
       @CurOnHold     AS CurOnHold   ,
       @CurCompartmentId   AS CurCompartmentId   , 
       @CurCompartmentLoadId  AS CurCompartmentLoadId   , 
       @CurCompartmentFormulaId AS CurCompartmentFormulaId  ,
       @CurReceivedTime   AS CurReceivedTime,
       @AutoWeightEntryActive  AS AutoWeightEntryActive,
       @AutoWeightEntryWeight  AS AutoWeightEntryWeight,
       @IsFormulaModified   AS IsFormulaModified
  
  IF(@CurCompartmentFormulaId > 0)
  BEGIN
     UPDATE TCD.ConduitController
     SET LastConnectedTime  = GETUTCDATE()
     WHERE ControllerId   = @ControllerId
  END
  
  
  IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchData WHERE MachineId=@WasherId AND StartDate =@CurTunnelTimeStamp)
  BEGIN

   DECLARE @ShiftStartDate table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
   INSERT INTO @ShiftStartDate(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurTunnelTimeStamp

    --Start Getting InjectionCount,StepCount And ProductCount
     SELECT @StdInjectionSteps= count(tdpm.TunnelDosingSetupId) ,
     @StdWashSteps= count(DISTINCT tds.TunnelDosingSetupId)-count(tdpm.TunnelDosingSetupId) 
     FROM TCD.TunnelDosingProductMapping tdpm
     RIGHT JOIN tcd.TunnelDosingSetup tds on tdpm.TunnelDosingSetupId=tds.TunnelDosingSetupId
     WHERE tds.GroupId=@GroupId AND tds.ProgramNumber=@CurCurrentFormula
       --Start-----ProgramMasterID logic for PlantChainProgram
     SELECT 
     @PlantProgramId=pm.PlantProgramId,
     @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
     @ChainTextileCategoryId = pm.ChainTextileId,
     @FormulaSegmentId = pm.FormulaSegmentId,
     @EcolabSaturationId = pm.EcolabSaturationId 
     FROM TCD.ProgramMaster pm WHERE pm.ProgramId=@ProgramMasterId AND pm.Is_Deleted=0
     IF(@PlantProgramId <> 0  AND @PlantProgramId IS NOT NULL)
      BEGIN
       --Assign value from plantchainprogram table based on plantprogramId
       SELECT
        @EcolabTextileCategoryId = pcp.EcolabTextileCategoryId,
        @ChainTextileCategoryId = pcp.ChainTextileCategoryId,
        @FormulaSegmentId = pcp.FormulaSegmentId,
        @EcolabSaturationId = pcp.EcolabSaturationId
        FROM tcd.PlantChainProgram pcp
        WHERE pcp.PlantProgramId=@PlantProgramId AND pcp.Is_Deleted=0
      END
    --End-----ProgramMasterID logic for PlantChainProgram
    -- New Batch Creation
       INSERT INTO TCD.BatchData(
           ControllerBatchId ,
           EcolabWasherId,
           GroupId ,
           MachineInternalId,
           PlantWasherNumber,
           StartDate ,
           EndDate ,
           ProgramNumber,
           ProgramMasterId,
           MachineId,
           ActualWeight,
           StandardWeight,
           CurrencyCode,
           ShiftId,
           PartitionOn,
           TargetTurnTime,
           StdInjectionSteps,
           StdWashSteps,
           EcolabTextileCategoryId,
           ChainTextileCategoryId,
           FormulaSegmentId,
           EcolabSaturationId,
           PlantProgramId,
		   ETechlastDroppedTimeStamp
           )


          SELECT DISTINCT @CurCompartmentLoadId
           ,@EcolabWasherId
           ,@GroupId
           ,@MachineInternalId
           ,@PlantWasherNumber
           --,@CurReceivedTime
           ,@CurTunnelTimeStamp
           ,NULL
           ,@CurCurrentFormula
           ,@ProgramMasterId
           ,@WasherId
           ,@AutoWeightEntryWeight
           ,@StandardWeight 
           ,@CurrencyCode
           ,(SELECT Top 1 ShiftId from @ShiftStartDate)
           ,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
           ,@TargetTurnTime
           ,@StdInjectionSteps
           ,@StdWashSteps
           ,@EcolabTextileCategoryId
           ,@ChainTextileCategoryId
           ,@FormulaSegmentId
           ,@EcolabSaturationId
           ,@PlantProgramId
		   ,@ETechLastDroppedAt 
        
   
        SET @BatchID=SCOPE_IDENTITY() 

        --Start insert InjectionActualCount and StepActualCount in TCD.BatchParameters
        INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchID,@EcolabWasherId,37,@StdInjectionSteps,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
        INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchID,@EcolabWasherId,38,@StdWashSteps,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)  
        --End insert InjectionActualCount and StepActualCount in TCD.BatchParameters

        --If the received formula is not configured in enVision then create an alarm 
       IF(@ProgramMasterId is NULL)
       BEGIN
       SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant
       SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.AlarmGroupMsterVsControllerModelType AGMVCMT
       INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
       WHERE AGMVCMT.AlarmCode = 9000
        INSERT INTO [TCD].[AlarmData] 
           (EcoalabAccountNumber,
           AlarmCode,
           BatchId,
           controllerID,
           StartDate,
           GroupId,
           MachineInternalId,
           ProgramId,   
           IsActive,
           EndDate,
           MachineId,
           AlarmGroupMasterId)
           SELECT
            @ECOLABAccountNumber,
            9000,
            @BatchID,
            @ControllerId,
            @CurTunnelTimeStamp,
            @GroupId,
            @MachineInternalId,
            @CurCurrentFormula,
            0,
            @CurTunnelTimeStamp,
            @WasherId,
            @AlarmGroupMasterId
       END


      -- Wash Step Information  
      INSERT INTO TCD.BatchWashStepData(
           BatchId
           ,StepCompartment
           ,StartTime
           ,EndTime
           ,PartitionOn
           ,EcolabWasherId)     
      SELECT 
           @BatchID,
           @CurCompartmentId,
           @CurTunnelTimeStamp,
           --@CurReceivedTime,
           NULL,
           (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
           @EcolabWasherId
      -- Product Usage
    IF (@RatioDosingEnabled = 1)
     BEGIN
      INSERT INTO TCD.BatchProductData(
         BatchId,
         StepCompartment,
         ActualQuantity,
         StandardQuantity,
         Price,
         [TimeStamp],
         PartitionOn,
         EcolabWasherId,
         ProductId
      )     
      SELECT DISTINCT @BatchID 
          ,@CurCompartmentId
          ,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * (@AutoWeightEntryWeight/@StandardWeight) AS ActualQuantity      
          ,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * (@AutoWeightEntryWeight/@StandardWeight) AS StandardQuantity          
          ,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price 
          ,@CurTunnelTimeStamp        
          --,@CurReceivedTime
          ,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
          ,@EcolabWasherId
          ,Pdm.ProductID
       FROM TCD.Washer WS
       INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
       INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
       INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
       INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
       INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
       INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
       INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId=Wdpm.ControllerEquipmentSetupId
       INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Ces.ProductId
       --INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
      WHERE 
        Ws.WasherId=@WasherId AND 
        Wps.ProgramNumber=@CurCurrentFormula AND 
        Wds.CompartmentNumber=@CurCompartmentId AND
        Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
     END
    ELSE
     BEGIN
      INSERT INTO TCD.BatchProductData(
         BatchId,
         StepCompartment,
         ActualQuantity,
         StandardQuantity,
         Price,
         [TimeStamp],
         PartitionOn,
         EcolabWasherId,
         ProductId
      )     
      SELECT DISTINCT @BatchID 
          ,@CurCompartmentId
          ,((Wps.NominalLoad * Wdpm.Quantity)/ 100) AS ActualQuantity      
          ,((Wps.NominalLoad * Wdpm.Quantity)/ 100) AS StandardQuantity          
          ,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price
          ,@CurTunnelTimeStamp         
          --,@CurReceivedTime
          ,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
          ,@EcolabWasherId
          ,Pdm.ProductID
       FROM TCD.Washer WS
       INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
       INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
       INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
       INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
       INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
       INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
       INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId=Wdpm.ControllerEquipmentSetupId
       INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Ces.ProductId
       --INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
      WHERE 
        Ws.WasherId=@WasherId AND 
        Wps.ProgramNumber=@CurCurrentFormula AND 
        Wds.CompartmentNumber=@CurCompartmentId AND
        Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
     END   
        
        
      -- Transfer Signal  
        INSERT INTO TCD.WasherReading(
               WasherId,
               ParameterId,
               ParameterValue,
               DateTimeStamp,
               PartitionOn,
               EcolabWasherId)
         SELECT @WasherId,
           6,
           1,
           @TempTunnelTimeStamp,
           (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
           @EcolabWasherId
         UNION ALL
         SELECT @WasherId,
           6,
           0,
           GETUTCDATE(),
           (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
           @EcolabWasherId
   
      -- Insert Customer Data
      INSERT INTO TCD.BatchCustomerData(
          BatchId,
          CustomerId,
          Weight,
          PiecesCount,
          PartitionOn,
          EcolabWasherId
          )
      SELECT DISTINCT 
          Bd.BatchId,  
          Pc.ID,
          @AutoWeightEntryWeight,
          ROUND(COALESCE((@AutoWeightEntryWeight * Pm.Pieces) / NULLIF(Pm.Weight,0), 0),0),
          (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
          @EcolabWasherId
      
      FROM TCD.Washer WS
       INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
       INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId       
       INNER JOIN TCD.TunnelProgramSetup Tps ON Tps.WasherGroupId = Wg.WasherGroupId
       INNER JOIN TCD.ProgramMaster Pm ON Pm.ProgramId=Tps.ProgramId
       INNER JOIN TCD.PlantCustomer Pc ON Pc.ID=Pm.CustomerId
       INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
      WHERE 
       Ws.WasherId=@WasherId AND 
       Tps.ProgramNumber=@CurCompartmentFormulaId AND 
       Bd.BatchId=@BatchID   AND 
       Pm.CustomerId != -1
       AND Pm.[Weight] > 0
  END

  ELSE
  BEGIN
   SELECT @BatchID=BatchId, @PartitionOn=PartitionOn
   FROM TCD.BatchData 
   WHERE MachineId=@WasherId 
   AND ControllerBatchId=@CurCompartmentLoadId
   
   IF(@BatchID IS NOT NULL)
   BEGIN
   UPDATE TCD.BatchWashStepData 
    SET EndTime=@CurTunnelTimeStamp
   WHERE BatchId=@BatchId 
    AND StepCompartment=@CurCompartmentId-1

    IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchWashStepData WHERE StartTime=@CurTunnelTimeStamp and BatchId=@BatchID)
    BEGIN
     INSERT INTO TCD.BatchWashStepData(
           BatchId
           ,StepCompartment
           ,StartTime
           ,EndTime
           ,PartitionOn
           ,EcolabWasherId)     
      SELECT 
           @BatchID,
           @CurCompartmentId,
           @CurTunnelTimeStamp,
           --@CurReceivedTime,
           NULL,
           @PartitionOn,
           @EcolabWasherId
    END       
    IF (@RatioDosingEnabled = 1)
     BEGIN
     IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurTunnelTimeStamp and BatchId=@BatchID)
     BEGIN
      INSERT INTO TCD.BatchProductData(
         BatchId,
         StepCompartment,
         ActualQuantity,
         StandardQuantity,
         Price,
         [TimeStamp],
         PartitionOn,
         EcolabWasherId,
         ProductId
         )
      SELECT DISTINCT 
         @BatchID 
         ,@CurCompartmentId
         ,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * (@AutoWeightEntryWeight/@StandardWeight) AS ActualQuantity       
         ,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * (@AutoWeightEntryWeight/@StandardWeight) AS StandardQuantity 
         ,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price
         ,@CurTunnelTimeStamp         
         --,@CurReceivedTime
         ,@PartitionOn
         ,@EcolabWasherId
         ,Pdm.ProductID
      FROM TCD.Washer WS
      INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
      INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
      INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
      INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
      INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
      INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
      INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId=Wdpm.ControllerEquipmentSetupId
      INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Ces.ProductId
      --INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
      WHERE 
       Ws.WasherId=@WasherId 
       AND Wps.ProgramNumber=@CurCompartmentFormulaId 
       AND Wds.CompartmentNumber=@CurCompartmentId AND
       Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
     END
    END -- end of ratio dosing if
    ELSE
     BEGIN
     IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurTunnelTimeStamp and BatchId=@BatchID)
     BEGIN
     INSERT INTO TCD.BatchProductData(
         BatchId,
         StepCompartment,
         ActualQuantity,
         StandardQuantity,
         Price,
         [TimeStamp],
         PartitionOn,
         EcolabWasherId,
         ProductId
         )
     SELECT DISTINCT 
         @BatchID 
         ,@CurCompartmentId
         ,((Wps.NominalLoad * Wdpm.Quantity)/ 100) AS ActualQuantity       
         ,((Wps.NominalLoad * Wdpm.Quantity)/ 100) AS StandardQuantity 
         ,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price
         ,@CurTunnelTimeStamp         
         --,@CurReceivedTime
         ,@PartitionOn
         ,@EcolabWasherId
         ,Pdm.ProductID
      FROM TCD.Washer WS
      INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
      INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
      INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
      INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
      INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
      INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
      INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId=Wdpm.ControllerEquipmentSetupId
      INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Ces.ProductId
        
     WHERE 
       Ws.WasherId=@WasherId 
       AND Wps.ProgramNumber=@CurCompartmentFormulaId 
       AND Wds.CompartmentNumber=@CurCompartmentId AND
        Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0 
   END
   END        
    END -- end of BatchId NULL if
   END -- end of else
  END  -- end of IF(@CurCurrentFormula != @CurEof and @CurCurretnInjection = 0 and @CurCurrentOperationCounter = 0)       
 END  -- end of IF(@IsFormulaModified !=0) 
               
   FETCH NEXT FROM @MYCURSOR
   INTO @CurCurrentFormula   ,
       @CurCurretnInjection   ,
       @CurCurrentOperationCounter  ,
       @CurEof       ,
       @CurTunnelTimeStamp    ,
       @CurOnHold      ,
       @CurCompartmentId    , 
       @CurCompartmentLoadId   , 
       @CurCompartmentFormulaId  ,
       @CurReceivedTime    ,
       @AutoWeightEntryActive   ,
       @AutoWeightEntryWeight   ,
       @IsFormulaModified    ,
       @IsHoldSignalModified   ,
       @IsStopSinalModified   ,
       @StopSignal      ,
       @RatioDosingEnabled
   END
   CLOSE @MYCURSOR
   DEALLOCATE @MYCURSOR 
   
  
  END
END
--------------------------------------------
GO
----------------------------Task 144020 start------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetBatchTrendingGroupData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetBatchTrendingGroupData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[GetBatchTrendingGroupData] (@GroupId int )
AS 
SET NOCOUNT ON
BEGIN 

DECLARE @DayId Varchar(20) = NULL,
    @StartTime DateTime = NULL,
    @EndTime DateTime = NULL,
    @TransferStarttime Time = NULL,
    @TransferEndtime Time = NULL,
    @MachineId int = NULL,
    @ParameterId int = NULL,
    @ParameterValue  Int = NULL,
    @WasherStatus Int,
	@RegionId  Int = NULL,
	@EcoLabAccountNumber nvarchar(25) = NULL

DECLARE @NoofComp Int = NULL, 
    @Count int = 1

SELECT @NoOfcomp = NumberOfComp FROM [TCD].machinesetup 
  WHERE Groupid = @GroupId and IsTunnel = 1

DECLARE @GET_COMPARTMENT TABLE (
   GroupId INT,
   MachineID INT,
   CompartmentNumber VARCHAR(1000))

WHILE(@count <=  @NoOfcomp) 
BEGIN
   INSERT INTO @GET_COMPARTMENT(GroupId,MachineID,CompartmentNumber)
    SELECT @GroupId,@count,'Compartment'+ cast(@count as Varchar(1000))+''
   SET @count = @count + 1
End

DECLARE @TrendingData TABLE(
    BatchId INT,
    CustomerId INT,
    ProgramId INT,
    ActualLoad DECIMAL(10,2),
    NominalLoad DECIMAL(10,2),
    GroupId INT,
    CompartmentId INT,
    --DupCount INT,
    Efficiency DECIMAL(10,2),
    Temparature  DECIMAL(10,2),
    Conductivity  DECIMAL(10,2),
    PH  DECIMAL(10,2)) 

Declare @DummyTrendingData TABLE(
    BatchId INT,
    CustomerId INT,
    ProgramId INT,
    ActualLoad DECIMAL(10,2),
    NominalLoad DECIMAL(10,2),
    GroupId INT,
    CompartmentId INT,
    --DupCount INT,
    Efficiency DECIMAL(10,2),
    Temparature  DECIMAL(10,2),
    Conductivity  DECIMAL(10,2),
    PH  DECIMAL(10,2)) 
   
INSERT INTO @TrendingData(
    BatchId ,
    CustomerId ,
    ProgramId ,
    ActualLoad,
    NominalLoad ,
    GroupId ,
    CompartmentId ,
    --DupCount INT,
    Efficiency ,
    Temparature ,
    Conductivity,
    PH) 


     SELECT DISTINCT
             BA.BatchId,
             BC.CustomerId,
             BA.ProgramNumber,
             BA.[ActualWeight],
             BA.[StandardWeight],
             BA.GroupId,
             BS.StepCompartment,
             (BA.[ActualWeight]/BA.[StandardWeight]) * 100 AS LoadEfficiency,
             TE.Reading AS Temparature,
             CO.Reading AS Conductivity,
             PH.Reading AS PH

        FROM [TCD].BatchWashStepData AS BS
             INNER JOIN [TCD].BatchData BA ON BA.BatchId = BS.BatchId
             LEFT OUTER JOIN [TCD].BatchCustomerData BC ON BC.BatchId = BA.BatchId
             LEFT OUTER JOIN (SELECT SS.GroupId,
                            SS.MachineCompartment,
                            MR.Reading
                        FROM TCD.ModuleReading MR INNER JOIN TCD.Sensor SS ON MR.ModuleId = SS.SensorId WHERE MR.ModuleTypeId = 3 AND SS.SensorType = 1) TE
             ON BA.GroupId = TE.GroupId AND BS.StepCompartment = TE.MachineCompartment
              LEFT OUTER JOIN (SELECT SS.GroupId,
                            SS.MachineCompartment,
                            MR.Reading
                        FROM TCD.ModuleReading MR INNER JOIN TCD.Sensor SS ON MR.ModuleId = SS.SensorId WHERE MR.ModuleTypeId = 3 AND SS.SensorType = 4) CO
             ON BA.GroupId = CO.GroupId AND BS.StepCompartment = CO.MachineCompartment

    LEFT OUTER JOIN (SELECT SS.GroupId,
                            SS.MachineCompartment,
                            MR.Reading
                        FROM TCD.ModuleReading MR INNER JOIN TCD.Sensor SS ON MR.ModuleId = SS.SensorId WHERE MR.ModuleTypeId = 3 AND SS.SensorType = 2) PH
             ON BA.GroupId = CO.GroupId AND BS.StepCompartment = CO.MachineCompartment

        WHERE BS.EndTime IS NULL AND BA.EndDate IS NULL
               AND BA.GroupId = @GroupId 

  Select @MachineId = WasherId,@EcoLabAccountNumber=EcoalabAccountNumber from tcd.MachineSetup where GroupId = @GroupId
  Select top 1 @ParameterId =  ParameterId ,@Parametervalue = ParameterValue from TCD.washerReading where WasherId = @MachineId order by DateTimeStamp desc
  select top 1 @RegionId = RegionId from TCD.Plant where EcolabAccountNumber=@EcoLabAccountNumber

  If(@ParameterId = 6 and @Parametervalue = 0)
   BEGIN
    set @WasherStatus = 1
   END
  Else If (@ParameterId = 6 and @Parametervalue = 1)
   BEGIN
    set @WasherStatus = 2
   END
  Else If (@ParameterId = 12)
   BEGIN
    set @WasherStatus = 0
   END

  INSERT INTO @DummyTrendingData(BatchId,CustomerId,ProgramId,ActualLoad,NominalLoad,GroupId,CompartmentId,Efficiency,Temparature,Conductivity,PH)
    SELECT 0,0,0,0,0,GroupId,MachineID,0,0,0,0 FROM @GET_COMPARTMENT

    IF(@WasherStatus != 2)
    BEGIN
    UPDATE  D  SET

      D.BatchId = C.BatchId, 
      D.CustomerId =  CASE WHEN C.ActualLoad = 0 THEN 0
       ELSE 
      C.CustomerId END,
      D.ProgramId = C.ProgramId,
      D.ActualLoad = C.ActualLoad,
      D.NominalLoad = C.NominalLoad,
      D.GroupId = CASE WHEN C.GroupId = 0 THEN C.GroupId ELSE D.GroupId END,
      D.CompartmentId =  CASE WHEN C.CompartmentId IS NOT NULL THEN C.CompartmentId ELSE D.CompartmentId END,
      D.Efficiency = CAST(C.Efficiency AS decimal(10,2)),
      D.Temparature = CAST(C.Temparature AS decimal(10,2)),
      D.Conductivity = CAST(C.Conductivity AS decimal(10,2)),
      D.PH = CAST(C.PH AS decimal(10,2)) 
      FROM @DummyTrendingData D LEFT OUTER JOIN @TrendingData C ON D.CompartmentId = C.CompartmentId

   END
       SELECT 
      ISNULL(BatchId,0) AS BatchId,
      ISNULL(CustomerId,0) AS CustomerId,
      ISNULL(ProgramId,0) AS ProgramId,
	  (CASE WHEN (@RegionId=1) THEN ISNULL(ActualLoad,0) ELSE ROUND((ISNULL(ActualLoad,0)*0.453592),0) END) AS ActualLoad,
	  (CASE WHEN (@RegionId=1) THEN ISNULL(NominalLoad,0) ELSE ROUND((ISNULL(NominalLoad,0)*0.453592),0) END) AS NominalLoad,
      ISNULL(GroupId,0) AS GroupId,
      ISNULL(CompartmentId,0) AS CompartmentId,
      ISNULL(Efficiency,0) AS Efficiency,
      ISNULL(Temparature,0) AS Temparature,
      ISNULL(Conductivity,0) AS Conductivity,
      ISNULL(PH,0) AS PH
       FROM @DummyTrendingData
  END

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetBatchSummarizedData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetBatchSummarizedData]
END
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [TCD].[GetBatchSummarizedData] (  
            @DashBoardId INT = NULL   
            )   
  
AS   
BEGIN   
  
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED  
    SET NOCOUNT ON  
  
  
     DECLARE   --@DashBoardId INT = 2,
        @Efficiencytype INT,  
        @OvernightBatchThreshold INT = 7200,-- mins  
        @RegionId INT,
        @EcoLabAccountNumber nvarchar(25)
      
     DECLARE @DashboardMachineMapping TABLE(  
         Id INT,  
         GroupId INT,  
         WasherId INT,  
         DisplayCustomer BIT,  
  WasherName NVARCHAR(100),   
  WasherNumber INT,
  IsPLCConnected BIT,
  DispenserName VARCHAR(250))
  
      DECLARE @Summarizeddata TABLE(  
        GroupId INT,  
        TunnelName Nvarchar(100),  
        TargetLoad FLOAT,  
        ActualLoad FLOAT,  
 LoadEfficiency FLOAT,  
        TimeEfficiency FLOAT,  
        LostLBS FLOAT,  
        TransferPerHr FLOAT,  
        SignalStatus INT,          
        EmptyPockets INT,  
        Alarm Bit,  
        TransferPercent DECIMAL(10,2),  
        EndOfFormula INT,  
        DisplayCustomer BIT,  
        WasherNumber INT,
  IsPLCConnected BIT,
  DispenserName VARCHAR(250),
  LostBatches Decimal(18,6)
        )  
          
 DECLARE @ShiftIds TABLE(  
 ShiftId INT,  
 ShiftStartDate DATETIME,  
 ShiftEndDate DATETIME  
 )  
  
 SELECT  
  @Efficiencytype = ISNULL(EfficiencyCalcType, 1), 
  @EcoLabAccountNumber = EcolabAccountNumber
     FROM tcd.Dashboard  
     WHERE DashboardId = @Dashboardid  

 SELECT @RegionId=RegionId FROM TCD.Plant WHERE EcolabAccountNumber=@EcoLabAccountNumber

      INSERT INTO @DashboardMachineMapping  
        (  
            Id,  
            GroupId,  
            WasherId,  
     DisplayCustomer,  
     WasherName,  
     WasherNumber,
  IsPLCConnected,
  DispenserName
        )  
    SELECT   
    ROW_NUMBER() OVER(ORDER BY GroupID) AS Id,  
    A.GroupId,  
    A.WasherId,  
    A.Customer,  
    A.WasherName,  
    A.WasherNumber,
 A.IsPLCConnected,
 DispenserName
    FROM  
    (SELECT DISTINCT  
     MS.GroupId,MS.WasherId,D.Customer,MS.MachineName AS WasherName, w.PlantWasherNumber AS WasherNumber,
  (CASE WHEN ISNULL(IsActive,0) = 0 THEN CAST( 1 AS BIT)
  WHEN ISNULL(IsActive,0) = 1 THEN CAST( 0 AS BIT)
  END) AS IsPLCConnected,
   CAST(CC.ControllerNumber AS NVARCHAR) + ' ('+CC.TopicName + ')' AS DispenserName
     FROM TCD.MonitorSetUpMapping DM   
        INNER JOIN TCD.MachineSetup MS ON DM.MachineId = MS.WasherID  
        INNER JOIN TCD.Dashboard D on DM.DashBoardId = D.DashBoardId  
 INNER JOIN TCD.Washer w ON ms.WasherId = w.WasherId  
  INNER JOIN TCD.ConduitController CC ON CC.ControllerId = MS.ControllerId
  LEFT JOIN TCD.AlarmData AD ON AD.ControllerId = MS.ControllerId AND IsActive = 1 AND AD.AlarmCode = 
  (CASE WHEN (SELECT VALUE FROM  TCD.controllerSetupData CSD LEFT JOIN TCD.Field F ON F.Id = CSD.FieldId  WHERE  F.Label = 'Webport Ftp Enabled' AND CSD.ControllerId = AD.ControllerId AND CC.ControllerTypeId = 1) = 'true'
   THEN 9002
   ELSE 9001
  END) 
    WHERE DM.DashboardId = @DashBoardId  
    AND ms.IsDeleted = 0  
    AND w.Is_Deleted = 0   
    )A;  
   
  
  
 -- For efficiency calculations on shift wise  
 IF @Efficiencytype = 1  
     BEGIN  
  
  INSERT INTO @Shiftids(shiftId,ShiftStartDate, ShiftEndDate)  
  SELECT DISTINCT ShiftId, StartDateTime, EndDateTime  
  FROM TCD.ProductionShiftData  
 -- WHERE ShiftId = 1103 
  WHERE GETUTCDATE() BETWEEN StartDateTime AND EndDateTime   
  
     END  
 ELSE -- For efficiency calculations on Day wise  
     BEGIN  
  
  INSERT @Shiftids(ShiftId, ShiftStartDate, ShiftEndDate)  
  SELECT DISTINCT ShiftId, StartDateTime, EndDateTime  
  FROM TCD.ProductionShiftData  
  WHERE startdatetime > CAST(GETUTCDATE()AS DATE)  
  AND startdatetime < DATEADD(dd, 1, CAST(GETUTCDATE()AS DATE))  
  
     END    

--select * from @ShiftIds
--select * from @DashboardMachineMapping
  
  
SELECT *   
INTO #BatchData  
FROM tcd.BatchData bd (NOLOCK) WHERE bd.ShiftId in (SELECT si.ShiftId FROM @ShiftIds si)  
AND bd.StandardWeight > 0  
and bd.ActualWeight > 0   
AND bd.EndDate IS NOT null


--select * from #BatchData  
  
-- Efficiency for each batch   
SELECT  bd.BatchId,  
  bd.GroupID,  
  bd.MachineID,  
  bd.ShiftId,  
  W_1.WasherNumber,  
  W_1.WasherName,  
  (bd.ActualWeight + ISNULL(BD.ManualInputWeight,0)) AS ActualProduction,  
  bd.StandardWeight AS StandardProduction,  
  --DATEDIFF(ss,bd.StartDate, bd.EndDate) AS ActualRunTime,  
  CASE WHEN DATEDIFF(mi,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OvernightBatchThreshold   
   THEN W_1.Standardruntime   
       ELSE DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
  END AS ActualRunTime,  
  W_1.StandardRunTime,  
  NULL AS ActualTurnTime,  
  bd.TargetTurnTime AS StandardTurnTime,  
  CASE WHEN W_1.WasherGroupTypeID = 2   THEN
    ---- Conventional  
    --THEN (CAST((W_1.Standardruntime + bd.TargetTurnTime)AS FLOAT) / (CAST(CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
    --          THEN W_1.StandardRunTime  
    --          ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
    --         END   
    --+ CASE WHEN TT.ACTUALTURNTIME = 0 THEN bd.TargetTurnTime   
    -- ELSE TT.ACTUALTURNTIME  
    --  END  AS FLOAT)))  
    ---- Tunnel  
   --ELSE   
   (CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT) )  
    / (CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0   
          THEN W_1.Standardruntime   
          ELSE CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
            THEN W_1.StandardRunTime  
                ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
           END  
         END AS FLOAT)   
                )  
  END AS TimeEfficiency,  
  ((CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS FLOAT)/CAST(NULLIF(bd.StandardWeight,0) AS FLOAT)) * 100) AS LoadEfficiency,  
  CASE WHEN W_1.WasherGroupTypeID = 2   
      THEN  
  (3600.00/(CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0   
       THEN NULLIF(W_1.Standardruntime,0)  
       ELSE DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
       END AS FLOAT)/W_1.NumberOfComp))   
   ELSE NULL  
  END AS TransferPerHr,  
  
  --missedloads formulae
  --------(((Actual Production/totalefficiency)*100)-actualproduction)
  
  (cast((cast(bd.ActualWeight AS decimal(18,6))/(((CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS decimal(18,6))/CAST(NULLIF(bd.StandardWeight,0) AS decimal(18,2))) * 100.0) 
  * (  CASE WHEN W_1.WasherGroupTypeID = 2   THEN
      ---- Conventional  
      --THEN (CAST((W_1.Standardruntime + bd.TargetTurnTime)AS FLOAT) / (CAST(CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
      --             THEN W_1.StandardRunTime  
      --             ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
      --            END + TT.ACTUALTURNTIME AS FLOAT)))  
      ---- Tunnel  
      --ELSE   
      (CAST(NULLIF(W_1.Standardruntime,0) AS decimal(18,6)) )
       / (CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0   
             THEN W_1.Standardruntime   
             ELSE CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
                  THEN W_1.StandardRunTime  
                  ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
                 END  
            END AS decimal(18,6)) 
                   )
    END))) AS decimal(18,6))*100.0)-cast(bd.ActualWeight AS decimal(18,6)) AS MissedLoads,
 -- ((bd.StandardWeight - bd.ActualWeight) +  
 -- (CASE WHEN W_1.WasherGroupTypeID = 2 THEN   
 --   --THEN  
 --   -- ((CAST((CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
 --   --   THEN W_1.StandardRunTime  
 --   --       ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
 --   --  END + TT.ACTUALTURNTIME) AS FLOAT) - W_1.Standardruntime - bd.TargetTurnTime)   
 --   -- * CAST((CAST(bd.StandardWeight AS FLOAT)/NULLIF((W_1.Standardruntime + bd.TargetTurnTime),0)) AS FLOAT))   
 --   --ELSE 
 --((CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
 --     THEN W_1.StandardRunTime  
 --         ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
 --    END - W_1.Standardruntime) * (CAST(bd.StandardWeight AS FLOAT)/ NULLIF(W_1.Standardruntime,0)))  
 -- END)) AS MissedLoads,  
  (((CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS FLOAT)/CAST(NULLIF(bd.StandardWeight,0) AS FLOAT)) * 100)   
  * (  CASE WHEN W_1.WasherGroupTypeID = 2   THEN
      ---- Conventional  
      --THEN (CAST((W_1.Standardruntime + bd.TargetTurnTime)AS FLOAT) / (CAST(CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
      --             THEN W_1.StandardRunTime  
      --             ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
      --            END + TT.ACTUALTURNTIME AS FLOAT)))  
      ---- Tunnel  
      --ELSE   
      (CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT) )  
       / (CAST(CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0   
                    THEN W_1.Standardruntime   
                    ELSE CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OverNightBatchThreshold  
                      THEN W_1.StandardRunTime  
                   ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
                     END  
            END AS FLOAT)   
                   )  
    END)) AS TotalEfficiency  ,
    w_1.maxload
  
INTO #BatchEfficiency  
FROM #BatchData bd  
--FROM TCD.BatchData bd   
INNER JOIN(       
                SELECT ms.EcoalabAccountNumber,      
                        ms.WasherId,      
                        ms.GroupId AS WasherGroupID,      
                        mg.WasherGroupTypeId AS WasherGroupTypeID,      
                        w.EcolabWasherId,      
                        ISNULL(ms.NumberOfComp,0) AS NumberOfComp,      
                        CASE      
                        WHEN MG.WASHERGROUPTYPEID = 1 THEN WSP.ProgramNumber      
                            ELSE TPS.ProgramNumber      
                        END AS ProgramNumber,      
                        CASE      
                        WHEN MG.WASHERGROUPTYPEID = 1 THEN WSP.ProgramId      
       ELSE TPS.ProgramId      
                        END AS ProgramId,      
                        CASE      
       WHEN MG.WASHERGROUPTYPEID = 1   
    THEN WSP.TotalRunTime      
                            ELSE TPS.TotalRunTime      
   END AS Standardruntime,  
   w.PlantWasherNumber AS WasherNumber,  
   ms.MachineName AS WasherName,  
   mg.WasherGroupName AS MachineGroup,  
   ms.IsTunnel , 
   w.maxload
   --mg.WasherGroupId AS MachineGroupID  
                    FROM TCD.MachineSetup AS ms (NOLOCK)      
                        INNER JOIN TCD.Washer AS w (NOLOCK) ON w.EcoLabAccountNumber = ms.EcoalabAccountNumber      
                                                    AND w.WasherId = ms.WasherId      
                        INNER JOIN TCD.WasherGroup AS mg (NOLOCK) ON ms.GroupId = mg.WasherGroupId      
                                                        AND w.EcoLabAccountNumber = mg.EcolabAccountNumber      
                        LEFT OUTER JOIN TCD.WasherProgramSetup AS WSP (NOLOCK) ON WSP.WasherGroupId = mg.WasherGroupId      
                                                                    AND WSP.EcolabAccountNumber = mg.EcolabAccountNumber      
                                                                    --AND WSP.WasherGroupId = ms.GroupId      
                 AND WSP.Is_Deleted = 0  
                        LEFT OUTER JOIN TCD.TunnelProgramSetup AS TPS (NOLOCK) ON TPS.WasherGroupId = mg.WasherGroupId      
                                                                    AND TPS.EcolabAccountNumber = mg.EcolabAccountNumber      
                                                                    --AND TPS.WasherGroupId = ms.GroupId   
                 AND TPS.Is_Deleted = 0   
   WHERE ms.IsTunnel = 1  
   ) AS W_1 ON BD.GroupId = W_1.WasherGroupID      
       AND BD.MachineId = W_1.WasherId      
       AND BD.ProgramMasterId = W_1.ProgramId      
       AND BD.ProgramNumber = W_1.ProgramNumber  
--LEFT JOIN [TCD].[Turntime] TT (NOLOCK) ON --ISNULL(BD.EcolabwasherID,0) = ISNULL(TT.EcolabWasherId,0)   
--    BD.batchid = TT.BatchID   
    --AND bd.MachineId = tt.MachineId  
--WHERE bd.ShiftId IN (SELECT si.ShiftId FROM @ShiftIds si)  
--AND bd.ActualWeight > 0   
--AND bd.StandardWeight > 0  
--AND DATEDIFF(ss, bd.StartDate, bd.EndDate) > (W_1.Standardruntime * 10/100)  
--AND bd.EndDate IS NOT NULL  
  
 
  
 -- Efficiency by Machine calculation   
 SELECT DM.GroupID,   
  DM.WasherId AS MachineID,  
  DM.WasherNumber,  
  DM.WasherName,  
  CAST(sum(t.ActualProduction) AS FLOAT) AS ActualProduction,  
  CAST(sum(t.StandardProduction) AS FLOAT) AS StandardProduction,  
  SUM(t.ActualRunTime) AS ActualRuntime,  
  SUM(t.StandardRunTime) AS StandardRunTime,  
  (SUM(t.MissedLoads)) AS MissedLoads,  
  (CAST(sum(t.LoadEfficiency) AS FLOAT) / count(DISTINCT t.BatchId)) AS LoadEfficiency,  
  (CAST(sum(t.TimeEfficiency) AS FLOAT) / count(DISTINCT t.BatchId)) AS TimeEfficiency,  
  (CAST(SUM(t.TransferPerHr) AS FLOAT)/ count(DISTINCT t.BatchId)) AS TransferPerHour,  
  ((CAST(sum(t.LoadEfficiency) AS FLOAT) / count(DISTINCT t.BatchId)) * (CAST(sum(t.TimeEfficiency) AS FLOAT) / count(DISTINCT t.BatchId))) AS TotalEfficiency,
  DM.IsPLCConnected AS IsPLCConnected,
  DM.DispenserName,
  (SUM(t.MissedLoads))/max(t.maxload) AS LostBatches 
 INTO #MachineEfficiency  
 FROM @Dashboardmachinemapping DM   
 LEFT JOIN #BatchEfficiency t ON DM.GroupID = t.GroupId AND dm.WasherId = t.MachineId  
 GROUP BY DM.GroupID,   
  DM.WasherId,  
  DM.WasherNumber,  
  DM.WasherName,
  DM.IsPLCConnected,
  DM.DispenserName
  
  
  
      DECLARE @EmptyPocketNAlarmddata TABLE(  
     GroupId INT,  
     WasherID INT,  
     EndOfFormula  INT,  
     DisplayCustomer Decimal(18,2),  
     EmptyPockets INT,  
     MachineNameDispalyType INT,  
     EmptyPocketLoad Decimal(18,2),  
     Alarm bit,  
     WasherStatus bit  
 )  
  
    INSERT @EmptyPocketNAlarmddata    (GroupId,WasherID,EndOfFormula,DisplayCustomer,EmptyPockets,MachineNameDispalyType, EmptyPocketLoad,Alarm,WasherStatus)  
    SELECT  D.GroupId,   
     D.WasherId,   
     w.EmptyPocketNumber AS EndOfFormula,   
     D.DisplayCustomer,   
     A.EmptyPockets,   
     (SELECT SUM(ISNULL(MachineNameDispalyType,0)) FROM TCD.Dashboard D1  
  INNER JOIN TCD.[MonitorSetUpMapping] MSM ON D1.DashboardId=MSM.DashboardId    
  WHERE MSM.MachineId=D.WasherId and D1.DashboardId=@DashBoardId  
  ) as MachineNameDispalyType,  
     sum(w.MaxLoad) AS EmptyPocketLoad,  
     NULL AS alarm,  
     sum(CASE WHEN B.WasherStatus > 0 THEN 1 ELSE 0 END) AS WasherStatus  
    FROM TCD.Washer AS w   
    INNER JOIN @DashboardMachineMapping AS D ON w.WasherId = d.WasherId  
    CROSS APPLY  (  
 SELECT COUNT(*) As EmptyPockets from TCD.BatchData AS b JOIN @ShiftIds AS s ON b.ShiftId = s.ShiftId   
 WHERE b.StartDate >= s.ShiftStartDate   
 AND b.GroupId = d.GroupId   
 AND b.ProgramNumber = w.EmptyPocketNumber  
       ) AS A  
    CROSS APPLY (  
 SELECT Count(*) as WasherStatus  
 from tcd.BatchData where MachineId = d.WasherId AND GroupId= D.GroupId and (EndDate >= DATEADD(mi,-30,GETUTCDATE()) OR EndDate is NULL)  
 ) AS B  
    GROUP BY D.GroupId, D.WasherId, w.EmptyPocketNumber, D.DisplayCustomer, A.EmptyPockets  
  
  
    UPDATE X   
    SET X.Alarm = ISNULL(Alarm.IsActive,0)  
    FROM @EmptyPocketNAlarmddata X  
    CROSS APPLY (   
 SELECT TOP 1 AD.IsActive  
     FROM [TCD].AlarmData AD   
     WHERE GroupId = X.GroupId  
     ORDER BY StartDate DESC  
  ) AS Alarm  
  
  
  
INSERT INTO @Summarizeddata(GroupId,TunnelName,TargetLoad,ActualLoad,LoadEfficiency, TimeEfficiency,  
        LostLBS,TransferPerHr,SignalStatus,EmptyPockets,Alarm,TransferPercent,EndOfFormula,DisplayCustomer,WasherNumber,IsPLCConnected, DispenserName,lostbatches)
 SELECT  me.GroupID,   
  CASE epn.MachineNameDispalyType   
     WHEN 0 THEN CAST( me.WasherNumber AS varchar(20))+' '+  me.WasherName  
     WHEN 1 THEN me.WasherName  
     WHEN 2 THEN CAST( me.WasherNumber AS varchar(20))          
  END AS TunnelName,  
  me.StandardProduction,   
  me.ActualProduction,   
  me.LoadEfficiency,  
  me.TimeEfficiency,   
  me.MissedLoads,  
  me.TransferPerHour,  
  epn.WasherStatus,  
  epn.EmptyPockets,  
  ISNULL(epn.Alarm,0) AS Alarm,  
  0 AS TransferPercent,  
  epn.EndOfFormula,  
  epn.DisplayCustomer,  
  me.WasherNumber,
  me.IsPLCConnected AS IsPLCConnected,
  me.DispenserName AS DispenserName,
  me.LostBatches
 from #MachineEfficiency me  
 LEFT JOIN @EmptyPocketNAlarmddata epn ON me.GroupID = epn.GroupId AND me.MachineID = epn.WasherID  
   
     SELECT  GroupId,  
     TunnelName,
	 (CASE WHEN (@RegionId=1) THEN ISNULL(TargetLoad,0) ELSE ROUND((ISNULL(TargetLoad,0)*0.453592),0) END) AS TargetLoad,
	  (CASE WHEN (@RegionId=1) THEN ISNULL(ActualLoad,0) ELSE ROUND((ISNULL(ActualLoad,0)*0.453592),0) END) AS ActualLoad,
     LoadEfficiency,  
     TimeEfficiency,  
     ( CASE WHEN isnull(LostLBS,0)<0 THEN 0 ELSE LostLBS END) LostLBS ,  
     TransferPerHr,  
     SignalStatus,          
     EmptyPockets,  
     Alarm,  
     TransferPercent,  
     EndOfFormula,  
     DisplayCustomer,  
     WasherNumber,
  IsPLCConnected,
  DispenserName,
  ( CASE WHEN isnull(LostBatches,0)<0 THEN 0 ELSE LostBatches END) LostBatches
    FROM @Summarizeddata    
    ORDER BY WasherNumber  
  
-- CleanUp  
DROP TABLE #BatchData
DROP TABLE #BatchEfficiency  
DROP TABLE #MachineEfficiency  
  
END

GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlConventionalData_Online]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlConventionalData_Online]
END
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [TCD].[ProcessMyControlConventionalData_Online]
(
	@ControllerID   INT,
	@VxML           XML,
	@RedFlagShiftId INT OUTPUT
)
AS
	BEGIN
	    DECLARE @MachineNumber           INT,
			  @StepNumber              INT,
			  @StartDateTime           DATETIME,
			  @EndDateTime             DATETIME,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @PHValue                 INT,
			  @TemperatureMin          INT,
			  @TemperatureMax          INT,
			  @TempMinStatus           INT,
			  @TempMaxStatus           INT,
			  @BatchNumber             INT,
			  @WasherID                INT,
			  @WasherGroupID           INT,
			  @EcoLabWasherID          INT,
			  @ProgramMasterID         INT,
			  @PlantWasherNumber       INT,
			  @ShiftID                 INT,
			  @FrmParameterID          INT,
			  @PHParameterID           INT,
			  @PHParameterStatus       INT,
			  @BatchID                 INT,
			  @ShiftStartdate          DATETIME,
			  @ShiftName               NVARCHAR(50),
			  @XMLDataID               INT,
			  @TempParameter           INT,
			  @TemperatureMinParam     INT,
			  @TemperatureMaxParam     INT,
			  @TempMinStatusParam      INT,
			  @TempMaxStatusParam      INT,
			  @WashStepNo              INT,
			  @CurrencyCode            VARCHAR(50),
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @TargetTurnTime          INT;
	    SELECT @MachineNumber = T.c.value('@MachineNumber', 'INT'),
			 @StepNumber = T.c.value('@StepNumber', 'INT'),
			 @StartDateTime = T.c.value('@StartDateTime', 'DATETIME'),
			 @EndDateTime = T.c.value('@EndDateTime', 'DATETIME'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@NominalLoad', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'INT'),
			 @PHStatus = T.c.value('@PHStatus', 'INT'),
			 @PHValue = T.c.value('@PHValue', 'INT'),
			 @TemperatureMin = T.c.value('@TemperatureMin', 'INT'),
			 @TemperatureMax = T.c.value('@TemperatureMax', 'INT'),
			 @TempMaxStatus = T.c.value('@TemperatureMaxStatus', 'INT'),
			 @TempMinStatus = T.c.value('@TemperatreMinStatus', 'INT'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT')
	    FROM @VxML.nodes('MyControlConventionalData') T(C);
	    SELECT @PHParameterID = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'pH';
	    SELECT @PHParameterStatus = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'PH Status';
	    SELECT @TemperatureMinParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Mimum Temperature';
	    SELECT @TemperatureMaxParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Maximum Temperature';
	    SELECT @TempMinStatusParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Minimum Temperature Status';
	    SELECT @TempMaxStatusParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Max Temperature Status';
	    SELECT @WashStepNo = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'StepCompartment No';
	    SELECT @FrmParameterID = [Id]
	    FROM TCD.ConduitPArameters
	    WHERE Name = 'Formula Number';
	    DECLARE @ShiftMapping TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    INSERT INTO @ShiftMapping
	    (
		  ShiftId,
		  ShiftName,
		  ShiftStartdate
	    )
	    EXEC TCD.GetShiftStartDate
		    @StartDateTime
	    SELECT @ShiftID = ShiftID,
			 @ShiftStartdate = ShiftStartdate
	    FROM @ShiftMapping;
	    SELECT @WasherGroupID = GroupId,
			 @WasherID = WasherID
	    FROM TCD.MachineSetup ms
	    WHERE ControllerID = @ControllerID
			AND MachineInternalId = @MachineNumber
			AND IsTunnel = 0
			AND IsDeleted = 0;
	    IF(@EndDateTime = '1/1/1900')
		   SELECT @EndDateTime = NULL;
	    IF(@StartDateTime = '1/1/1900')
		   SELECT @StartDateTime = NULL;
	    IF(@WasherId IS NOT NULL)
		   BEGIN
			  SELECT @ProgramMasterId = Wps.ProgramId
			  FROM TCD.Washer Ws
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.ControllerID = Wg.ControllerId
				  INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.EcoLabAccountNumber
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wps.Is_Deleted = 0;
			  SELECT @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber,
				    @CurrencyCode = P.CurrencyCode,
				    @TargetTurnTime = w.TargetTurnTime * 60
			  FROM TCD.Washer w
				  INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.EcolabAccountNumber
			  WHERE w.WasherId = @WasherID;
	   END;
	    SELECT @BatchID = BatchID
	    FROM TCD.BatchData
	    WHERE MachineInternalID = @MachineNumber
			AND StartDate = @StartDateTime
			AND ControllerBatchId = @BatchNumber
			AND MachineID = @WasherID;

	    --Start Getting InjectionCount and StepCount
	    SELECT @StdInjectionSteps = COUNT(DISTINCT wdpm.
	    WasherDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) -
			 COUNT(DISTINCT wdpm.WasherDosingSetupId)
	    FROM TCD.WasherDosingProductMapping wdpm
		    RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm.
		    WasherDosingSetupId = wds.WasherDosingSetupId
	    WHERE wds.ControllerID = @ControllerID
			AND wds.ProgramNumber = @ProgramNumber;
	    --End Getting InjectionCount and StepCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramMasterId
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT @EcolabTextileCategoryId = pcp.
			  EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp.
				    ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    IF(@BatchID IS NULL)
		   BEGIN
			  INSERT INTO TCD.BatchData
			  (ControllerBatchID,
			   EcolabWasherId,
			   GroupId,
			   MachineInternalId,
			   PlantWasherNumber,
			   StartDate,
			   EndDate,
			   ProgramNumber,
			   ProgramMasterId,
			   MachineID,
			   ActualWeight,
			   StandardWeight,
			   CurrencyCode,
			   ShiftId,
			   PartitionOn,
			   StdInjectionSteps,
			   StdWashSteps,
			   EcolabTextileCategoryId,
			   ChainTextileCategoryId,
			   FormulaSegmentId,
			   EcolabSaturationId,
			   PlantProgramId,
			   EndDateFormula,
			   TargetTurnTime
			  )
			  VALUES
			  (
				    @BatchNumber,
				    @EcoLabWasherID,
				    @WasherGroupID,
				    @MachineNumber,
				    @PlantWasherNumber,
				    @StartDateTime,
				    @EndDateTime,
				    @ProgramNumber,
				    @ProgramMasterId,
				    @WasherID,
				    @Load,
				    @NominalLoad,
				    @CurrencyCode,
				    @ShiftID,
				    @ShiftStartdate,
				    @StdInjectionSteps,
				    @StdWashSteps,
				    @EcolabTextileCategoryId,
				    @ChainTextileCategoryId,
				    @FormulaSegmentId,
				    @EcolabSaturationId,
				    @PlantProgramId,
				    @EndDateTime,
				    @TargetTurnTime
			  );
			  SELECT @BatchID = SCOPE_IDENTITY();
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM TCD.BatchParameters
				 WHERE BatchId = @BatchID
					  AND ParameterID = 38
			   )
			   BEGIN
			   IF(@StdWashSteps <> 0
				 OR @StdWashSteps <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
					   BatchId,
					   EcolabWasherId,
					   ParameterId,
					   ParameterValue,
					   PartitionOn
					)
					SELECT @BatchID,
						  @EcoLabWasherID,
						  38,
						  @StdWashSteps,
						  @ShiftStartdate;
				  END
			END;

			  --End Date  Time  is Null 
			  UPDATE TCD.BatchData
			    SET
				   EndDate = GETUTCDATE()
			  WHERE MachineInternalID = @MachineNumber
				   AND StartDate <> @StartDateTime
				   AND EndDate IS NULL
				   AND ControllerBatchId <> @BatchNumber
				   AND MachineId = @WasherId;	
																  		
			  -- Program Number	
			  IF(@ProgramNumber IS NOT NULL
				AND @ProgramNumber > 0)
				 BEGIN
					IF NOT EXISTS
					(
					    SELECT *
					    FROM TCD.WasherReading
					    WHERE WasherId = @WasherID
							AND ParameterID = @FrmParameterID
							AND DateTimeStamp = @StartDateTime
					)
					    BEGIN
						   INSERT INTO TCD.WasherReading
						   (WasherID,
						    ParameterID,
						    ParameterValue,
						    DateTimeStamp,
						    EcoLabWasherID,
						    Partitionon
						   )
						   VALUES
						   (
								@WasherID,
								@FrmParameterID,
								@ProgramNumber,
								@StartDateTime,
								@EcoLabWasherID,
								@ShiftStartdate
						   );
					    END;
				 END;
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM [TCD].[BatchCustomerData]
				 WHERE BatchID = @BatchId
					  AND @CustomerNumber IS NOT NULL
			  )
				 BEGIN
					INSERT INTO [TCD].[BatchCustomerData]
					([BatchId],
					 CustomerID,
					 [Weight],
					 PartitionOn,
					 EcolabWasherId
					)
					VALUES
					(
						  @BatchID,
						  @CustomerNumber,
						  @Load,
						  @ShiftStartdate,
						  @EcolabWasherID
					);
				 END;
		   END;

	    -- PH Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @PHParameterID
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@PHValue <> 0
				OR @PHValue <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @PHParameterID,
							    @PHValue,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 
	 
	    -- PH Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @PHParameterStatus
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@PHStatus <> 0
				OR @PHStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @PHParameterStatus,
							    @PHStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Min Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TemperatureMinParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TemperatureMin <> 0
				OR @TemperatureMin <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TemperatureMinParam,
							    @TemperatureMin,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Max Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TemperatureMaxParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TemperatureMax <> 0
				OR @TemperatureMax <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TemperatureMaxParam,
							    @TemperatureMax,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Min Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TempMinStatusParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TempMinStatus <> 0
				OR @TempMinStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TempMinStatusParam,
							    @TempMinStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Max Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TempMaxStatusParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TempMaxStatus <> 0
				OR @TempMaxStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TempMaxStatusParam,
							    @TempMaxStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- StepCompartment No
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @WashStepNo
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@StepNumber <> 0
				OR @StepNumber <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @WashStepNo,
							    @StepNumber,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END;
	END;
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlTunnelWasherOnlineData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlTunnelWasherOnlineData]
END
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [TCD].[ProcessMyControlTunnelWasherOnlineData](
	@ControllerID   INT,
	@xmlTags        XML,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @BatchID                 INT,
			  @WasherID                INT,
			  @EcolabWasherId          INT,
			  @CurrencyCode            VARCHAR(50),
			  @MachineInternalId       INT,
			  @WasherGroupID           INT,
			  @PlantWasherNumber       INT,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @BatchNumber             INT,
			  @TargetTurnTime          INT,
			  @PartitionOn             DATETIME,
			  @BatchStartTime          DATETIME,
			  @ProgramID               INT,
			  @NumberOfCompartments    INT,
			  @TransferSignalId        INT,
			  @BatchShiftId            INT,
			  @compartmentID           INT,
			  @TunnelXML               XML,
			  @TempXML                 XML,
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT;
	    SELECT @TransferSignalId = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Transfer Signal';
	    CREATE TABLE #Batches
	    (
		    BatchNumber   INT,
		    StartDateTime DATETIME
	    );
	    -- SET @compartmentID = 1;

	    SELECT @TempXML = T.c.query('.')
	    FROM @xmlTags.nodes('MyControlTunnel') AS T(c);
	    SELECT @MachineInternalID = T.c.value('@MachineNumber', 'int')
	    FROM @TempXML.nodes('MyControlTunnel') AS T(c);
	    SELECT @EcolabWasherID = EcolabWasherId,
			 @WasherGroupID = Wg.WasherGroupId,
			 @PlantWasherNumber = PlantWasherNumber,
			 @WasherID = ws.WasherId,
			 @CurrencyCode = P.CurrencyCode,
			 @NumberOfCompartments = Mst.NumberofComp
	    FROM TCD.Washer AS Ws
		    INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = Ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.
		    GroupId
		    INNER JOIN TCD.WasherGroupType AS WgT ON WgT.
		    WasherGroupTypeId = Wg.WasherGroupTypeId
		    INNER JOIN TCD.ConduitController AS Ctrl ON Ctrl.
		    ControllerId = Mst.ControllerId
		    INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.
		    EcoLabAccountNumber
	    WHERE Ctrl.ControllerID = @ControllerID
			AND mst.MachineInternalId = @MachineInternalID
			AND Mst.IsTunnel = 1 AND Mst.IsDeleted =0;
	    SET @compartmentID = @NumberOfCompartments;
	    WHILE(@compartmentID <= @NumberOfCompartments
			AND @compartmentID > 0)
		   BEGIN
			  SELECT @TunnelXML = T.c.query('.')
			  FROM @xmlTags.nodes('MyControlTunnel/TunnelData') AS T(c)
			  WHERE T.c.value('@CompartmentNumber', 'INT') =
			  @compartmentID;
			  SELECT @MachineInternalID = T.c.value('@MachineNumber',
			  'int'
										    ),
				    @BatchNumber = T.c.value('@BatchNumber', 'INT'),
				    @BatchStartTime = T.c.value('@StartDateTime',
				    'DateTime'
										 ),
				    @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
				    @Load = T.c.value('@Load', 'Decimal(10,6)'),
				    @NominalLoad = T.c.value('@Nominalload',
				    'Decimal(10,6)'
									   ),
				    @CustomerNumber = T.c.value('@CustomerNumber',
				    'int'
										 ),
				    @PHStatus = T.c.value('@pHStatus', 'int')
			  FROM @TunnelXML.nodes('TunnelData') AS T(c);
			  DECLARE @ShiftStartDateTemp TABLE
			  (
				  ShiftId        INT,
				  ShiftName      NVARCHAR(50),
				  ShiftStartdate DATETIME
			  );
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchStartTime
			  SELECT @BatchShiftId = ShiftID,
				    @PartitionOn = ShiftStartdate
			  FROM @ShiftStartDateTemp;
			  IF(@ProgramNumber = 0
				OR @BatchNumber = 1)
				 BEGIN
					SELECT @compartmentID = @compartmentID - 1;
					CONTINUE;
				 END;
			  SELECT @ProgramID = ProgramId,
				    @TargetTurnTime = 3600 / (tps.TotalRunTime /
				    @NumberOfCompartments)
			  FROM TCD.TunnelProgramSetup AS tps
			  WHERE tps.WasherGroupId = @WasherGroupID
				   AND tps.is_deleted = 0
				   AND ProgramNumber = @ProgramNumber;
			  INSERT INTO #Batches
			  (BatchNumber,
			   StartDateTime
			  )
				    SELECT @BatchNumber,
						 @BatchStartTime;
			  SELECT @BatchID = NULL;
			  SELECT @BatchID = BatchID
			  FROM TCD.BatchData AS BD
			  WHERE BD.ControllerBatchId = @BatchNumber
				   AND BD.StartDate = @BatchStartTime
				   AND BD.MachineId = @WasherID;
			  --Start Getting InjectionCount,StepCount And ProductCount
			  SELECT @StdInjectionSteps = COUNT(tdpm.
			  TunnelDosingSetupId),
				    @StdWashSteps = COUNT(DISTINCT tds.
				    TunnelDosingSetupId) - COUNT(tdpm.
				    TunnelDosingSetupId)
			  FROM tcd.TunnelDosingProductMapping AS tdpm
				  RIGHT JOIN tcd.TunnelDosingSetup AS tds ON tdpm.
				  TunnelDosingSetupId = tds.TunnelDosingSetupId
			  WHERE tds.GroupId = @WasherGroupID
				   AND tds.ProgramNumber = @ProgramNumber;
			  --End Getting InjectionCount,StepCount And ProductCount
			  --Start-----ProgramMasterID logic for PlantChainProgram
			  SELECT @PlantProgramId = pm.PlantProgramId,
				    @EcolabTextileCategoryId = pm.
				    EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pm.ChainTextileId,
				    @FormulaSegmentId = pm.FormulaSegmentId,
				    @EcolabSaturationId = pm.EcolabSaturationId
			  FROM TCD.ProgramMaster AS pm
			  WHERE pm.ProgramId = @ProgramID
				   AND pm.Is_Deleted = 0;
			  IF(@PlantProgramId <> 0
				OR @PlantProgramId IS NOT NULL)
				 BEGIN
					--Assign value from plantchainprogram table based on plantprogramId
					SELECT @EcolabTextileCategoryId = pcp.
					EcolabTextileCategoryId,
						  @ChainTextileCategoryId = pcp.
						  ChainTextileCategoryId,
						  @FormulaSegmentId = pcp.FormulaSegmentId,
						  @EcolabSaturationId = pcp.
						  EcolabSaturationId
					FROM tcd.PlantChainProgram AS pcp
					WHERE pcp.PlantProgramId = @PlantProgramId
						 AND pcp.Is_Deleted = 0;
				 END;
			  --End-----ProgramMasterID logic for PlantChainProgram
			  IF @BatchID IS NULL
				 BEGIN
					INSERT INTO TCD.BatchData
					(ControllerBatchId,
					 EcolabWasherId,
					 GroupId,
					 MachineInternalId,
					 PlantWasherNumber,
					 StartDate,
					 ProgramNumber,
					 ProgramMasterId,
					 MachineId,
					 ActualWeight,
					 StandardWeight,
					 CurrencyCode,
					 ShiftId,
					 PartitionOn,
					 TargetTurnTime,
					 StdInjectionSteps,
					 StdWashSteps,
					 EcolabTextileCategoryId,
					 ChainTextileCategoryId,
					 FormulaSegmentId,
					 EcolabSaturationId,
					 PlantProgramId
					)
						  SELECT @BatchNumber,
							    @EcolabWasherID,
							    @WasherGroupID,
							    @MachineInternalID,
							    @PlantWasherNumber,
							    @BatchStartTime,
							    @ProgramNumber,
							    @ProgramID,
							    @WasherID,
							    @Load,
							    @NominalLoad,
							    @CurrencyCode,
							    @BatchShiftId,
							    @PartitionOn,
							    @TargetTurnTime,
							    @StdInjectionSteps,
							    @StdWashSteps,
							    @EcolabTextileCategoryId,
							    @ChainTextileCategoryId,
							    @FormulaSegmentId,
							    @EcolabSaturationId,
							    @PlantProgramId;
					SELECT @BatchID = SCOPE_IDENTITY();
					IF(@StdWashSteps > 0
					   OR @StdWashSteps <> NULL)
					    BEGIN
						   INSERT INTO TCD.BatchParameters
						   (BatchId,
						    EcolabWasherId,
						    ParameterId,
						    ParameterValue,
						    PartitionOn
						   )
								SELECT @BatchID,
									  @EcolabWasherId,
									  38,
									  @StdWashSteps,
									  @PartitionOn;
					    END;
					IF @CustomerNumber IS NOT NULL
					    BEGIN
						   IF NOT EXISTS
						   (
							  SELECT 1
							  FROM TCD.BatchCustomerData
							  WHERE BatchID = @BatchID
						   )
							  BEGIN
								 INSERT INTO TCD.BatchCustomerData
								 (BatchId,
								  CustomerID,
								  Weight,
								  PartitionOn,
								  EcolabWasherId
								 )
									   SELECT @BatchID,
											@CustomerNumber,
											@Load,
											@PartitionOn,
											@EcolabWasherId;
							  END;
					    END;
				 END;
			  -- Transfer Signal
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM tcd.WasherReading wr
				 WHERE wr.WasherId = @WasherID
					  AND wr.ParameterId = @TransferSignalId
					  AND wr.DateTimeStamp = @BatchStartTime
			  )
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterId,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TransferSignalId,
							    1,
							    @BatchStartTime,
							    @PartitionOn,
							    @EcolabWasherId
						  UNION ALL
						  SELECT @WasherID,
							    @TransferSignalId,
							    0,
							    @BatchStartTime,
							    @PartitionOn,
							    @EcolabWasherId;
				 END;
			  --Start Updating Batch Wash Step Data	 
			  EXEC TCD.UPDATEBatchWashStepForTunnel
				  @TunnelXML,
				  @WasherID,
				  @BatchID,
				  @BatchStartTime,
				  @PartitionOn,
				  @EcolabWasherId,
				  @compartmentID;
			  --End Updating Batch Wash Step Data	 
			  SELECT @compartmentID = @compartmentID - 1;
		   END;
	END;

Go
----------------------------Task 144020 end------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetWasherBatchTrendingData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetWasherBatchTrendingData]
END
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [TCD].[GetWasherBatchTrendingData](
	@DashBoardId         INT           = NULL,
	@EcolabAccountNumber NVARCHAR(25) = NULL,
	@StartTimeHrs        DATETIME      = NULL,
	@EndTimeHrs          DATETIME      = NULL)
AS
	BEGIN
	    SET NOCOUNT ON;              --SQLEnlight SA0017
		DECLARE
		@RegionId  Int = NULL

	    SET @EcolabAccountNumber = ISNULL(@EcolabAccountNumber, NULL);   --SQLEnlight SA0029
		select top 1 @RegionId = RegionId from TCD.Plant where EcolabAccountNumber=@EcoLabAccountNumber

	    SELECT DISTINCT
			 MS.GroupId,
			 MS.WasherID,
			 (CASE WHEN (@RegionId=1) THEN  BD.BatchId ELSE BD.ControllerBatchId END) AS BatchId,
			 Bd.ProgramMasterId,
			 PM.Name AS ProgramName,
			 DATEDIFF(SECOND, @StartTimeHrs, BD.StartDate) AS StartTime,
			 DATEDIFF(SECOND, @StartTimeHrs, BD.StartDate) + WPS.
			 TotalRunTime AS StandardEndTime,
			 DATEDIFF(SECOND, @StartTimeHrs, BD.EndDate) AS
			 ActualEndTime,
			 --Isnull(W.TargetTurnTime,10)* 60 as StandardTurnTime,
			 Isnull(BD.TargetTurnTime, 0) AS StandardTurnTime,
			 CASE
				WHEN BD.EndDate IS NULL
				THEN 1
				ELSE 0
			 END AS RunningStatus,
			 D.Formula AS DisplayFormula,
			 WPS.ProgramNumber,
			 D.DisplayFormulaType
	    FROM [TCD].MonitorSetUpMapping DM
		    INNER JOIN [TCD].MachineSetup MS ON DM.MachineId = MS. WasherID
		    INNER JOIN [TCD].Dashboard D ON DM.DashBoardId = D.DashBoardId
		    INNER JOIN [TCD].BatchData BD ON BD.MachineId = MS.WasherID
		    INNER JOIN [TCD].ProgramMaster PM ON PM.ProgramId = BD.ProgramMasterId
		    INNER JOIN [TCD].WasherProgramSetup WPS ON WPS.ProgramNumber = BD.ProgramNumber
											  AND  (WPS.ControllerID = MS.ControllerId 
											 OR WPS.WasherGroupId = MS.GroupId)
		    LEFT OUTER JOIN [TCD].Washer W ON W.WasherId = MS.WasherID
	    WHERE DM.DashboardId = @DashBoardId
			AND ((BD.StartDate >= DATEADD(HOUR, -1, @StartTimeHrs)
				 OR DATEADD(HOUR, -1, @StartTimeHrs) BETWEEN BD.StartDate AND BD.EndDate)
				OR (BD.EndDate IS NULL))
			AND WPS.Is_Deleted = 0
	    ORDER BY MS.WasherId,
			   (CASE WHEN (@RegionId=1) THEN  BD.BatchId ELSE BD.ControllerBatchId END);
	END;
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ReportProductionDetails]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ReportProductionDetails]
END
GO

CREATE PROCEDURE [TCD].[ReportProductionDetails]   
/******************************************************************  
DESCRIPTION		: 
  
  
MODIFICATION HISTORY DETAILS:   
 21st Jan 2015 -  Kiran     -  Added Formula hierarchy -->Formula segment-->Formula category-->formula  
  
  
REFERENC TABLES :  
  Select * from TCD.Plant --Plant master  
  Select * FROM TCD.PlantChain  --Master Plants  
  Select * FROM TCD.PlantChainProgram  
  Select * FROM TCD.ChainTextileCategory  
  Select * FROM TCD.ProgramMaster  
  Select * FROM TCD.EcolabTextileCategory  --Masters  
  Select * FROM TCD.EcolabSaturation --Masters  
  Select * FROM TCD.FormulaSegments --Masters  
  
EXECUTION STATEMENT :  
  
	EXEC [TCD].[ReportProductionDetails] @startdate = '2015-01-01 00:00:00',@enddate = '2016-01-01 00:00:00',@Viewtype  = '8',@Subview = '20',
          @Drillvalue = '',@EcolabAccountNumber = '040242802',@MachineType = '', @MachineGroup  = '',@Machine  = '',   
          @EcolabCategory  = '',@ChainCategory  = '', @PlantFormula  = '', @ChainFormula = '', @Customer  = '',  
          @SortColumnId  = 0,@SortDirection  = 'Desc',@CurrencyCode = '', @UserId = 1, @FormulaSegement ='',  
          @FormulaCategory='',@Formula=''
	
	EXEC [TCD].[ReportProductionDetails] @startdate = '2015-01-01 00:00:00',@enddate = '2016-01-01 00:00:00',@Viewtype  = '8',@Subview = '21',
          @Drillvalue = '1',@EcolabAccountNumber = '040242802',@MachineType = '', @MachineGroup  = '',@Machine  = '',   
          @EcolabCategory  = '',@ChainCategory  = '', @PlantFormula  = '', @ChainFormula = '', @Customer  = '',  
          @SortColumnId  = 0,@SortDirection  = 'Desc',@CurrencyCode = '', @UserId = 1, @FormulaSegement ='',  
          @FormulaCategory='',@Formula=''    

	EXEC [TCD].[ReportProductionDetails] @startdate = '2015-01-01 00:00:00',@enddate = '2016-01-01 00:00:00',@Viewtype  = '8',@Subview = '22',
          @Drillvalue = '3',@EcolabAccountNumber = '040242802',@MachineType = '', @MachineGroup  = '',@Machine  = '',   
          @EcolabCategory  = '',@ChainCategory  = '', @PlantFormula  = '', @ChainFormula = '', @Customer  = '',  
          @SortColumnId  = 0,@SortDirection  = 'Desc',@CurrencyCode = '', @UserId = 1, @FormulaSegement ='1,2',  
          @FormulaCategory='',@Formula='2'
    
*******************************************************************/ 
  
	@startdate datetime = '',  
	@enddate datetime = '',  
	@Viewtype Int = '',  
	@Subview Int= '',  
	@Drillvalue varchar(100)= '',  
	@EcolabAccountNumber Nvarchar(25) = '',  
	@MachineType VARCHAR(20)= '',  
	@MachineGroup VARCHAR(MAX) = '',  
	@Machine VARCHAR(MAX) = '',  
	@EcolabCategory VARCHAR(MAX) = '',  
	@ChainCategory VARCHAR(MAX) = '',  
	@PlantFormula  VARCHAR(MAX) = '',  
	@ChainFormula VARCHAR(MAX) = '',  
	@Customer VARCHAR(MAX) = '',  
	@SortColumnId int = 0,  
	@SortDirection varchar(4) = '',  
	@CurrencyCode varchar(3) = '',  
	@UserId INT = NULL,  
	@FormulaSegement VARCHAR(MAX)='', --Formula segment,  
	@FormulaCategory VARCHAR(MAX)='', --Formula category  
	@Formula VARCHAR(MAX)='' --Formula  
AS     
BEGIN     
SET NOCOUNT ON   
	 SET @startdate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@startdate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@startdate AS time)) AS DateTime))  
	 SET @EndDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndDate AS time)) AS DateTime))  

	 --SELECT @startdate,@EndDate 
	 DECLARE @ReportGenerated INT = 6, @Month INT = MONTH(GETDATE()),@CorrectionVariable Decimal(18,2),@PlantTargetProduction decimal(18,2)  
        
	 /* Inserting the record into Report History */  
	 INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)  
	 SELECT @EcolabAccountNumber,UM.UserId,UM.LoginName,GETUTCDATE(),@ReportGenerated,  
	 CASE WHEN @ReportGenerated = 6  
	  THEN 'Generated Report : Production Details Report' END  
	 FROM TCD.UserMaster UM  
	 WHERE UM.EcolabAccountNumber = @EcolabAccountNumber AND UM.UserId = @UserId  
       
	-- Return Table set  
	DECLARE @resultSet Table  
	(  
		ShiftId Int,  
		DateRange varchar(100),  
		TotalLoad Decimal(18,2) ,  
		WasherEfficiency Decimal(18,2),  
		PlantTargetLoad Decimal(18,2) ,  
		StandardLoad Decimal(18,2) ,  
		Numberofbatches INT,  
		[ActualRunTime] Decimal(30,10) NULL,  
		[TargetRunTime] Decimal(30,10) NULL,  
		NumberofPieces  [int] NULL,  
		Rewash [int] NULL,  
		Viewtype varchar(100) NULL,  
		Subview varchar(100) NULL,  
		Id int NULL        
	)  
  
	-- Correction factor
	DECLARE @CorrectionFactor TABLE   
	(  
		[ShiftId] [int] NULL,  
		MachineId INT NULL,  
		[ActualProduction] [int] NULL,  
		[StandardProduction] [int] NULL,  
		[PlantTargetProd] [int] NULL,  
		[ActualRunTime] [int] NULL,  
		[TargetRunTime] [int] NULL,  
		ManualInputWeight INT,  
		ManulainputsNoofloads INT  
	)  
      
	--Machine type  
	DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))  
	INSERT INTO @MachineTypeTable EXEC [TCD].[CharlistToTable] @MachineType,','  
  
	--washer Group  
	DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))  
	INSERT INTO @WasherGroupTable EXEC [TCD].[CharlistToTable] @machineGroup,','    
  
	--Machine list  
	DECLARE @MachineTable TABLE(Machine Varchar(100))  
	INSERT INTO @MachineTable EXEC [TCD].[CharlistToTable] @Machine,','  
  
	--Ecolab category  
	DECLARE @EcolabCategoryTable TABLE(EcolabCategory Varchar(100))  
	INSERT INTO @EcolabCategoryTable EXEC [TCD].[CharlistToTable] @EcolabCategory,','  
  
	--Chain category  
	DECLARE @ChainCategoryTable TABLE(ChainCategory Varchar(100))  
	INSERT INTO @ChainCategoryTable EXEC [TCD].[CharlistToTable] @ChainCategory,','  
  
	--Plant formula  
	DECLARE @PlantFormulaTable TABLE(PlantFormula Varchar(100))  
	INSERT INTO @PlantFormulaTable EXEC [TCD].[CharlistToTable] @PlantFormula,','  
  
	--Chain Formula  
	DECLARE @ChainFormulaTable TABLE(ChainFormula Varchar(100))  
	INSERT INTO @ChainFormulaTable EXEC [TCD].[CharlistToTable] @ChainFormula,','  
  
	 --Customer Table  
	DECLARE @CustomerTable TABLE(Customer Varchar(100))  
	INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','  
  
	 --Formula Segment --added by Kiran  
	DECLARE @FormulaSegmentTable TABLE(FormulaSegment Varchar(1000))  
	INSERT INTO @FormulaSegmentTable EXEC [TCD].[CharlistToTable] @FormulaSegement,','  
  
-----Formula category--------Start  
	DECLARE @FormulaCategoryTable TABLE(FormulaCategory Varchar(1000),Type CHAR(1))  
	INSERT INTO @FormulaCategoryTable(FormulaCategory) EXEC [TCD].[CharlistToTable] @Formulacategory,','     	   
  
		--Below 1000 Ecolab category  
		UPDATE @FormulaCategoryTable SET TYPE='E' WHERE FormulaCategory<1000  
		--Above 1000 consider as Chain category  
		UPDATE @FormulaCategoryTable SET TYPE='C' WHERE FormulaCategory>=1000  
  
		--Rollbacking to actual ID  
		UPDATE @FormulaCategoryTable SET FormulaCategory=FormulaCategory-1000 WHERE TYPE='C'  
		--SELECT * FROM @FormulaCategoryTable  
  
		INSERT INTO @EcolabCategoryTable(EcolabCategory)  
		SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='E'   
  
		INSERT INTO @ChainCategoryTable(ChainCategory)  
		SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='C'  
  
		--Value Assigning  
		IF (EXISTS(SELECT * FROM @EcolabCategoryTable) AND @FormulaCategory!='')  
		BEGIN  
		SET @EcolabCategory=@FormulaCategory  
		END  
		IF (EXISTS(SELECT * FROM @ChainCategoryTable) AND @FormulaCategory!='')  
		BEGIN  
		SET @ChainCategory=@FormulaCategory  
		END  
---Formula category-------------------------End  
  
 -----Formula Ecolab/Chain formulas  
	DECLARE @FormulaTable TABLE(Formula Varchar(1000),Type CHAR(1))  
	INSERT INTO @FormulaTable(Formula) EXEC [TCD].[CharlistToTable] @Formula,','  
   	 
		--Plant fomula     
		INSERT INTO @PlantFormulaTable(PlantFormula)   
		SELECT Formula FROM @FormulaTable --WHERE Type='E'  
		--chain formula     
		INSERT INTO @ChainFormulaTable(ChainFormula)   
		SELECT Formula FROM @FormulaTable --WHERE Type='C'  
		--Select * FROM @FormulaTable
		--SELECT * FROM @PlantFormulaTable  
		--SELECT * FROM @ChainFormulaTable  
  
		 --Value Assigning  
		 IF (EXISTS(SELECT * FROM @PlantFormulaTable) AND @Formula!='')  
		 BEGIN  
				SET @PlantFormula=@Formula
		 END  
		 IF (EXISTS(SELECT * FROM @ChainFormulaTable) AND @Formula!='')  
		 BEGIN  
				SET @ChainFormula=@Formula
		 END  
			--SELECT @PlantFormula,@ChainFormula  
-----Formula Segregation end  
  
	 --Insert Into @CorrectionFactor table  
	 INSERT INTO @CorrectionFactor  
	 (  
		  [ShiftId],  
		  [MachineId] ,  
		  [ActualProduction] ,  
		  [StandardProduction] ,  
		  [PlantTargetProd] ,  
		  [ActualRunTime] ,  
		  [TargetRunTime],  
		  ManualInputWeight,  
		  ManulainputsNoofloads     
	 )  
	 SELECT   
	  PS.[ShiftId],  
	  SPD.[MachineId],  
	  ISNULL([TCD].[FnConsumptionOnMetrics](SUM(ISNULL(SPD.[ActualProduction],0))+SUM(ISNULL(MIP.ActualWeight,0)),'Weight',@UserId),0),  
	  --ISNULL([TCD].[FnConsumptionOnMetrics](SUM(ISNULL(SPD.[ActualProduction],0)),'Weight',@UserId),0),    
	  --SUM(SPD.[ActualProduction]),  
	  ISNULL([TCD].[FnConsumptionOnMetrics](SUM(ISNULL(SPD.StandardProduction,0)),'Weight',@UserId),0),  
	  --SUM(SPD.StandardProduction),  
	  ISNULL([TCD].[FnConsumptionOnMetrics](SUM(DISTINCT ISNULL(SPD.[PlantTargetProd],0)),'Weight',@UserId),0),  
	  --SUM(DISTINCT SPD.[PlantTargetProd]),  
	  SUM(ISNULL(SPD.[ActualRunTime],0) + ISNULL(SPD.ActualTurnTime,0)),  
	  SUM(ISNULL(SPD.[TargetRunTime],0) + ISNULL(SPD.TargetTurnTime,0)),  
	  SUM(ISNULL(MIP.ActualWeight,0)),SUM(ISNULL(MIP.NoofLoads,0))  
	 FROM  TCD.ShiftProductionDataRollup SPD   
	 INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId  
	 LEFT OUTER JOIN --Manual Production Details appending  
	  (  
	   SELECT WasherId,FormulaId,CONVERT(DATE,RecordedDate) AS LoadDate,SUM(ISNULL(Value,0)) AS ActualWeight,  
	   ISNULL(COUNT(CONVERT(DATE,RecordedDate)),0) AS NoofLoads FROM  
	   TCD.ManualProduction MP  
	   GROUP BY WasherId,FormulaId,CONVERT(DATE,RecordedDate)  
	  )MIP ON MIP.WasherId=SPD.EcolabWasherId AND MIP.FormulaId=SPD.ProgramMasterId AND MIP.LoadDate=CONVERT(DATE,PS.StartDateTime)  
	 WHERE   
	  CASE @StartDate                                                                                  
	  WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                  
	  ELSE CASE WHEN PS.[StartDateTime] >= @startdate  AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                          
	  END='TRUE'   
	 GROUP BY MachineId,PS.ShiftId;  
  
	 WITH CTE (PlantTargetProd) AS  
	 (  
	 SELECT SUM(DISTINCT SPD.[PlantTargetProd]) FROM @CorrectionFactor SPD GROUP BY ShiftId  
	 )  
	 SELECT @PlantTargetProduction = SUM(PlantTargetProd) FROM CTE;  
  
	 WITH CTE (MachineId,PlantEfficiency)  
	 AS  
	 (  
	 SELECT   
	  MachineId,  
	  CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/   
	   NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) *   
	   COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2))     
	   FROM @CorrectionFactor SPD GROUP BY MachineId  
	 )  
		SELECT @CorrectionVariable = @PlantTargetProduction/NULLIF(SUM(PlantEfficiency),0) FROM CTE  
  	
	 DECLARE @ProductionSummaryTable TABLE  
	 (  
	  [ShiftId] [int] NULL,  
	  [ShiftName] Varchar(100) NULL,  
	  RecordDate date,   
	  [MachineId] [int] NULL,  
	  [ProgramMasterId] [int] NULL,  
	  [EcolabWasherId] [int] NULL,  
	  [ActualProduction] [int] NULL,  
	  [StandardProduction] [int] NULL,  
	  [NoOfLoads] [int] NULL,  
	  [LoadEfficiency] [decimal](18, 2) NULL,  
	  [TimeEfficiency] [decimal](18, 2) NULL,  
	  TotalEfficiency [decimal](18, 2) NULL,  
	  [PlantTargetProd] [int] NULL,  
	  [ActualRunTime] INT NULL,  
	  [TargetRunTime] INT NULL,  
	  EcolabTextileId int,  
	  ChainTextileId int,  
	  ChainProgaramId int,  
	  CustomerId int,  
	  NoOfPieces int,  
	  Rewash Int,  
	  [ShiftRunTime] DECIMAL(30,10) NULL,  
	  FormulaSegmentID INT,  
	  RowNumberID INT,
	  IndividualShiftRunTime Decimal(30,10),
	  ShiftRownumber INT  
	 )  
  
	INSERT INTO @ProductionSummaryTable  
	SELECT   
		PS.[ShiftId],  
		PS.ShiftName,  
		CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date),  		 
		SPD.[MachineId],  
		SPD.[ProgramMasterId],  
		SPD.[EcolabWasherId],  
		ISNULL(SPD.[ActualProduction],0),  
		ISNULL(SPD.StandardProduction,0),  
		ISNULL(SPD.[NoOfLoads],0),  
		ISNULL(SPD.[LoadEfficiency],0),  
		ISNULL(SPD.[TimeEfficiency],0),  
		(ISNULL(SPD.[LoadEfficiency],0) * ISNULL(SPD.TimeEfficiency,0)),  
		ISNULL(SPD.[PlantTargetProd],0),  
		ISNULL(SPD.[ActualRunTime],0) + ISNULL(SPD.ActualTurnTime,0),  
		ISNULL(SPD.[TargetRunTime],0) + ISNULL(SPD.TargetTurnTime,0),  
		SPD.EcolabTextileId,  
		SPD.ChainTextileId,  
		SPD.ChainProgaramId,  
		SPD.CustomerId,  
		ISNULL(SPD.NoOfPieces,0),  
		CAST((  
			SELECT spdr.ActualProduction FROM TCD.ShiftProductionDataRollup spdr WHERE spdr.ShiftId = SPD.ShiftId AND spdr.MachineId = SPD.MachineId  
			AND spdr.ProgramMasterId = SPD.ProgramMasterId AND spdr.ProgramMasterId IN (SELECT pm.ProgramId FROM TCD.ProgramMaster pm WHERE pm.Rewash = 1)  
			) AS decimal(18,2)),  
		DATEDIFF(Second,ps.StartDateTime,PS.EndDateTime) +  
		ISNULL(  
			(  
			SELECT  
			SUM(SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0))  
			FROM TCD.ShiftProductionDataRollup SPD INNER JOIN TCD.ProductionShiftData PSD ON SPD.ShiftId = PSD.ShiftId  
			WHERE PSD.[StartDateTime] = PS.StartDateTime AND PSD.[StartDateTime] = PS.EndDateTime AND PS.ShiftName = 'No Shift'  
			) ,0),  
		CASE WHEN SPD.ChainProgaramId IS NOT NULL THEN ChainPlant.FormulaSegmentId  
		ELSE FS1.FormulaSegmentID END AS Formulasegment,  
		ROW_NUMBER() OVER(Partition BY SPD.ProgramMasterId, SPD.[EcolabWasherId], CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date)  
		ORDER BY SPD.ProgramMasterId, SPD.[EcolabWasherId] ) ,
		0, --IndividualShiftruntime
		ROW_NUMBER() OVER(Partition BY SPD.ShiftID  ORDER BY SPD.ShiftID)
  
		--CAST(((SELECT SUM(MR.VALUE) FROM TCD.ManualRewash MR WHERE SPD.ProgramMasterId = MR.FormulaId AND CAST(PS.StartDateTime AS date) = CAST(MR.RecordedDate AS date) GROUP BY CAST(MR.RecordedDate AS date),MR.FormulaId)) AS decimal(18,2))  
	FROM  TCD.ShiftProductionDataRollup SPD   
	INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId  
	INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId   
	INNER JOIN TCD.MachineSetup ms ON SPD.MachineId = ms.WasherId  
	LEFT OUTER JOIN  
	(  
		--IF Chain Plant  
		SELECT PCP.PlantProgramId,PCP.PlantChainId,PCP.ChainTextileCategoryId,PCP.EcolabTextileCategoryId,  
		PCP.FormulaSegmentId,PCP.EcolabSaturationId  
		FROM TCD.PlantChainProgram PCP    
		LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=PCP.FormulaSegmentId    
	)ChainPlant ON SPD.ChainProgaramId=ChainPlant.PlantProgramId    
	LEFT OUTER JOIN TCD.FormulaSegments FS1 ON FS1.FormulaSegmentID=PM.FormulaSegmentId   
	WHERE isNull(ms.IsPony,0) = 0  
	AND   
		CASE @StartDate                                                                                  
		WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                  
		ELSE CASE WHEN PS.[StartDateTime] >= @startdate  AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                          
		END='TRUE'   
	AND  
		CASE @MachineType     
		WHEN '' THEN 'TRUE'           
		ELSE                                                        
		CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE        
		MS.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable))) THEN 'TRUE' END                                                        
		END='TRUE'      
	AND  
		CASE @machineGroup     
		WHEN '' THEN 'TRUE'           
		ELSE                                                        
		CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE        
		MS.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable)) THEN 'TRUE' END                                                        
		END='TRUE'   
	AND    
		CASE @Machine     
		WHEN '' THEN 'TRUE'           
		ELSE                                                        
		CASE WHEN SPD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                   
		END='TRUE'   
	AND        
		CASE @EcolabCategory     
		WHEN '' THEN 'TRUE'           
		ELSE                                                        
		CASE WHEN SPD.EcolabTextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                        
		END='TRUE'   
	AND        
		CASE @ChainCategory     
		WHEN '' THEN 'TRUE'           
		ELSE                                                        
		CASE WHEN SPD.ChainTextileId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END                                                        
		END='TRUE'  
	AND    
		CASE @PlantFormula     
		WHEN '' THEN 'TRUE'           
		ELSE                                                        
		CASE WHEN SPD.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                        
		END='TRUE'    
	AND       
		CASE @ChainFormula     
		WHEN '' THEN 'TRUE'           
		ELSE                                                        
		CASE WHEN SPD.ProgramMasterId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END                                                        
		END='TRUE'  
	AND        
		CASE @Customer     
		WHEN '' THEN 'TRUE'           
			ELSE                                                        
			CASE WHEN SPD.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                        
		END='TRUE'  
	--Added by Kiran   
	AND   
		CASE @FormulaSegement                                                                                  
		WHEN '' THEN  'TRUE'  
		ELSE  
			CASE WHEN SPD.ChainProgaramId  IS NOT NULL THEN  
				CASE WHEN ChainPlant.FormulaSegmentId IN (SELECT FormulaSegment FROM @FormulaSegmentTable) THEN 'TRUE' END                                                                                       
			ELSE   
			CASE WHEN FS1.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)  THEN 'TRUE'END     
		END                                                       
		END='TRUE'  
	-----ENd  
	------------------------------
	 DECLARE @ProductionSummaryTable1 TABLE  
	 (  
	  [ShiftId] [int] NULL,  
	  [ShiftName] Varchar(100) NULL,  
	  RecordDate date,   
	  [MachineId] [int] NULL,  
	  [ProgramMasterId] [int] NULL,  
	  [EcolabWasherId] [int] NULL,  
	  [ActualProduction] [int] NULL,  
	  [StandardProduction] [int] NULL,  
	  [NoOfLoads] [int] NULL,  
	  [LoadEfficiency] [decimal](18, 2) NULL,  
	  [TimeEfficiency] [decimal](18, 2) NULL,  
	  TotalEfficiency [decimal](18, 2) NULL,  
	  [PlantTargetProd] [int] NULL,  
	  [ActualRunTime] INT NULL,  
	  [TargetRunTime] INT NULL,  
	  EcolabTextileId int,  
	  ChainTextileId int,  
	  ChainProgaramId int,  
	  CustomerId int,  
	  NoOfPieces int,  
	  Rewash Int,  
	  [ShiftRunTime] DECIMAL(30,10) NULL,  
	  FormulaSegmentID INT,  
	  RowNumberID INT,
	  IndividualShiftRunTime Decimal(30,10),
	  ShiftRownumber INT  
	 )  
  
	INSERT INTO @ProductionSummaryTable1  
	SELECT   
		PS.[ShiftId],  
		PS.ShiftName,  
		CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date),  		 
		SPD.[MachineId],  
		SPD.[ProgramMasterId],  
		SPD.[EcolabWasherId],  
		ISNULL(SPD.[ActualProduction],0),  
		ISNULL(SPD.StandardProduction,0),  
		ISNULL(SPD.[NoOfLoads],0),  
		ISNULL(SPD.[LoadEfficiency],0),  
		ISNULL(SPD.[TimeEfficiency],0),  
		(ISNULL(SPD.[LoadEfficiency],0) * ISNULL(SPD.TimeEfficiency,0)),  
		ISNULL(SPD.[PlantTargetProd],0),  
		ISNULL(SPD.[ActualRunTime],0) + ISNULL(SPD.ActualTurnTime,0),  
		ISNULL(SPD.[TargetRunTime],0) + ISNULL(SPD.TargetTurnTime,0),  
		SPD.EcolabTextileId,  
		SPD.ChainTextileId,  
		SPD.ChainProgaramId,  
		SPD.CustomerId,  
		ISNULL(SPD.NoOfPieces,0),  
		CAST((  
			SELECT spdr.ActualProduction FROM TCD.ShiftProductionDataRollup spdr WHERE spdr.ShiftId = SPD.ShiftId AND spdr.MachineId = SPD.MachineId  
			AND spdr.ProgramMasterId = SPD.ProgramMasterId AND spdr.ProgramMasterId IN (SELECT pm.ProgramId FROM TCD.ProgramMaster pm WHERE pm.Rewash = 1)  
			) AS decimal(18,2)),  
		DATEDIFF(Second,ps.StartDateTime,PS.EndDateTime) +  
		ISNULL(  
			(  
			SELECT  
			SUM(SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0))  
			FROM TCD.ShiftProductionDataRollup SPD INNER JOIN TCD.ProductionShiftData PSD ON SPD.ShiftId = PSD.ShiftId  
			WHERE PSD.[StartDateTime] = PS.StartDateTime AND PSD.[StartDateTime] = PS.EndDateTime AND PS.ShiftName = 'No Shift'  
			) ,0),  
		CASE WHEN SPD.ChainProgaramId IS NOT NULL THEN ChainPlant.FormulaSegmentId  
		ELSE FS1.FormulaSegmentID END AS Formulasegment,  
		ROW_NUMBER() OVER(Partition BY SPD.ProgramMasterId, SPD.[EcolabWasherId], CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date)  
		ORDER BY SPD.ProgramMasterId, SPD.[EcolabWasherId] ) ,
		0, --IndividualShiftruntime
		ROW_NUMBER() OVER(Partition BY SPD.ShiftID  ORDER BY SPD.ShiftID)
  
		--CAST(((SELECT SUM(MR.VALUE) FROM TCD.ManualRewash MR WHERE SPD.ProgramMasterId = MR.FormulaId AND CAST(PS.StartDateTime AS date) = CAST(MR.RecordedDate AS date) GROUP BY CAST(MR.RecordedDate AS date),MR.FormulaId)) AS decimal(18,2))  
	FROM  TCD.ShiftProductionDataRollup SPD   
	INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId  
	INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId   
	INNER JOIN TCD.MachineSetup ms ON SPD.MachineId = ms.WasherId  
	LEFT OUTER JOIN  
	(  
		--IF Chain Plant  
		SELECT PCP.PlantProgramId,PCP.PlantChainId,PCP.ChainTextileCategoryId,PCP.EcolabTextileCategoryId,  
		PCP.FormulaSegmentId,PCP.EcolabSaturationId  
		FROM TCD.PlantChainProgram PCP    
		LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=PCP.FormulaSegmentId    
	)ChainPlant ON SPD.ChainProgaramId=ChainPlant.PlantProgramId    
	LEFT OUTER JOIN TCD.FormulaSegments FS1 ON FS1.FormulaSegmentID=PM.FormulaSegmentId   
	WHERE isNull(ms.IsPony,0) = 0  
	AND   
		CASE @StartDate                                                                                  
		WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                  
		ELSE CASE WHEN PS.[StartDateTime] >= @startdate  AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                          
		END='TRUE'   
	 
	--------------------------------  
   	 --For top 1 record combination updating the manual input data.  
	 UPDATE S SET ActualProduction=ISNULL(S.ActualProduction,0)+ISNULL(MIP.ManualIPActualWeight,0),S.NoOfLoads=ISNULL(S.NoOfLoads,0)+ISNULL(MIP.NoofLoads,0)  
	 FROM  @ProductionSummaryTable S  
	 INNER JOIN   
	  (  
	  SELECT WasherId,FormulaId,CONVERT(DATE,RecordedDate) AS LoadDate,SUM(Value) AS ManualIPActualWeight,  
	  COUNT(CONVERT(DATE,RecordedDate)) AS NoofLoads FROM  
	  TCD.ManualProduction MP  
	  GROUP BY WasherId,FormulaId,CONVERT(DATE,RecordedDate)  
	  )MIP ON MIP.WasherId=S.MachineId AND MIP.FormulaId=S.ProgramMasterId AND MIP.LoadDate=S.RecordDate  
	  WHERE S.RowNumberID=1  
	   
	/*	
		--Finding Max shift runtime for Particula shift
		UPDATE S SET S.IndividualShiftRunTime=MIP.MaxShiftruntime,S.ShiftRunTime=MIP.MaxShiftruntime
		FROM  @ProductionSummaryTable S  
		INNER JOIN   
		(  
			SELECT ShiftId,MAX(ShiftRunTime) AS MaxShiftruntime FROM @ProductionSummaryTable	 
			GROUP BY ShiftID 
		)MIP ON MIP.ShiftId=S.ShiftId	 
	  
		--Dividing Maxshift time for all the shift based records
		UPDATE S SET S.IndividualShiftRunTime=(S.IndividualShiftRunTime/PS.noofShifts),S.ShiftRunTime=(S.ShiftRunTime/PS.noofShifts)
		FROM  @ProductionSummaryTable S  
		INNER JOIN   
  			(	 
			SELECT PS1.ShiftID,Count(PS1.ShiftID)AS noofShifts 
			FROM  TCD.ShiftProductionDataRollup SPD   
			INNER JOIN TCD.ProductionShiftData PS1 ON SPD.ShiftId = PS1.ShiftId  
			INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId AND PS1.EcolabAccountNumber=PM.EcolabAccountNumber  
			INNER JOIN TCD.MachineSetup ms ON SPD.MachineId = ms.WasherId	
			WHERE isNull(ms.IsPony,0) = 0  AND PM.EcolabAccountNumber=@EcolabAccountNumber
			GROUP BY PS1.shiftID		 
			) PS  
			ON PS.ShiftId=S.ShiftId 
	*/
	
	
	DECLARE @TableShiftruntime TABLE(ShiftID INT ,ShiftRuntime Decimal(20,10),ID INT,Name VARCHAR(1000))	
    
	 IF(@Viewtype = 3)  
	 BEGIN  
	  IF(@Subview = 12)  
	  BEGIN  
	   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,TextileId)  
		AS  
		(  
		 SELECT   
		EC.CategoryName,  
		SUM(SPD.ActualProduction),  
		COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
		SUM(DISTINCT SPD.PlantTargetProd),  
		SUM(SPD.StandardProduction),  
		SUM([NoOfLoads]),  
		SUM( SPD.ShiftRunTime),  
		SUM( SPD.ShiftRunTime),  
		SUM(SPD.NoOfPieces),  
		SUM(SPD.Rewash),  
		EC.TextileId  
		  FROM @ProductionSummaryTable SPD LEFT JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId  
		WHERE EC.CategoryName IS NOT NULL  
		GROUP BY   
		  EC.CategoryName,EC.TextileId,SPD.ShiftId  
		  )  
		  INSERT INTO @resultSet  
		  SELECT DISTINCT  
		0,  
		DateRange,  
		SUM(TotalLoad),  
		SUM(WasherEfficiency),  
		SUM(PlantTargetLoad),  
		SUM(StandardLoad),  
		SUM(Numberofbatches),  
		SUM(ActualRunTime),  
		SUM(TargetRuntime),  
		SUM(NumberofPieces),  
		SUM(Rewash)  
		,@Viewtype   
		,@Subview  
		,TextileId  
		FROM CTE  
		WHERE TotalLoad IS NOT NULL  
		GROUP BY DateRange,TextileId     
		 END  
	  IF(@Subview = 17)  
	  BEGIN  
	   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
	   AS  
	   (  
	   SELECT   
     
	   PM.Name,  
	   SUM(SPD.ActualProduction),  
	   COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
	   SUM(DISTINCT SPD.PlantTargetProd),  
	   SUM(SPD.StandardProduction),  
	   SUM([NoOfLoads]),  
	   SUM( SPD.ShiftRunTime),  
	   SUM( SPD.ShiftRunTime),  
	   SUM(SPD.NoOfPieces),  
	   SUM(SPD.Rewash)  
		FROM @ProductionSummaryTable SPD INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId  
		 INNER JOIN TCD.ProgramMaster PM ON EC.TextileId = PM.EcolabTextileCategoryId AND SPD.ProgramMasterId = PM.ProgramId      
	   WHERE  
		(  
		CASE      
		 WHEN @drillvalue='' THEN 'TRUE'   
		 WHEN @drillvalue IS NULL THEN 'TRUE'    
		 ELSE                                                      
		  CASE WHEN EC.TextileId IN (@drillvalue) THEN 'TRUE' END              
		 END='TRUE'  
		) AND PM.NAME IS NOT NULL  
	   GROUP BY   
		  PM.Name,SPD.ShiftId  
		 )  
	   INSERT INTO @resultSet  
		 SELECT DISTINCT  
	   0,  
		  DateRange,  
		  SUM(TotalLoad),  
		  SUM(WasherEfficiency),  
		  SUM(PlantTargetLoad),  
		  SUM(StandardLoad),  
		  SUM(Numberofbatches),  
		  SUM(ActualRunTime),  
		  SUM(TargetRuntime),  
		  SUM(NumberofPieces),  
		  SUM(Rewash)  
		  ,@Viewtype   
		  ,@Subview  
		,0  
		   FROM CTE  
		 WHERE TotalLoad IS NOT NULL  
		 GROUP BY DateRange  
	  END    
	 END  
  
	-- ************************ By Textile Category View ************************************************  
	 IF(@Viewtype = 4)  
	 BEGIN   
	  IF(@Subview = 15)  
	  BEGIN  
	   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
		AS  
		(  
		SELECT      
		CC.Name,  
		SUM(SPD.ActualProduction),  
		COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
		SUM(DISTINCT SPD.PlantTargetProd),  
		SUM(SPD.StandardProduction),  
		SUM([NoOfLoads]),  
		SUM( SPD.ShiftRunTime),  
		SUM( SPD.ShiftRunTime),  
		SUM(SPD.NoOfPieces),  
		SUM(SPD.Rewash)  
		FROM @ProductionSummaryTable SPD LEFT JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId  
		WHERE CC.Name IS NOT NULL   
		GROUP BY   
		  CC.Name,CC.TextileId,SPD.ShiftId  
		  )  
		INSERT INTO @resultSet  
		  SELECT DISTINCT  
		0,  
		   DateRange,  
		   SUM(TotalLoad),  
		   SUM(WasherEfficiency),  
		   SUM(PlantTargetLoad),  
		   SUM(StandardLoad),  
		   SUM(Numberofbatches),  
		   SUM(ActualRunTime),  
		   SUM(TargetRuntime),  
		   SUM(NumberofPieces),  
		   SUM(Rewash)  
		   ,@Viewtype   
		   ,@Subview  
		 ,0  
		 FROM CTE  
		 WHERE TotalLoad IS NOT NULL  
		 GROUP BY DateRange  
			END    
	  IF(@Subview = 18)  
	  BEGIN  
	   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
		AS  
		(  
		SELECT          
		PM.Name,  
		SUM(SPD.ActualProduction),  
		COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
		SUM(DISTINCT SPD.PlantTargetProd),  
		SUM(SPD.StandardProduction),  
		SUM([NoOfLoads]),  
		SUM( SPD.ShiftRunTime),  
		SUM( SPD.ShiftRunTime),  
		SUM(SPD.NoOfPieces),  
		SUM(SPD.Rewash)  
		   FROM @ProductionSummaryTable SPD INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId  
		  INNER JOIN TCD.ProgramMaster PM ON CC.TextileId = PM.ChainTextileId AND SPD.ProgramMasterId = PM.ProgramId  
      
	   WHERE  
		(  
		CASE      
		 WHEN @drillvalue='' THEN 'TRUE'   
		 WHEN @drillvalue IS NULL THEN 'TRUE'    
		 ELSE                                                      
		  CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END              
		 END='TRUE'  
		)  
	   GROUP BY   
		  PM.Name,SPD.ShiftId  
		  )  
		INSERT INTO @resultSet  
		  SELECT DISTINCT  
		0,  
		   DateRange,  
		   SUM(TotalLoad),  
		   SUM(WasherEfficiency),  
		   SUM(PlantTargetLoad),  
		   SUM(StandardLoad),  
		   SUM(Numberofbatches),  
		   SUM(ActualRunTime),  
		   SUM(TargetRuntime),  
		   SUM(NumberofPieces),  
		   SUM(Rewash)  
		   ,@Viewtype   
		   ,@Subview  
		 ,0  
			FROM CTE  
		  WHERE TotalLoad IS NOT NULL  
		  GROUP BY DateRange  
	  END  
	 END  
  
	  -- ******************************** Timeline View ***************************************************  
	 IF(@Viewtype = 1)  
	 BEGIN  
		---- By TimeLine - Day View  
		IF(@Subview = 5)  
		BEGIN 
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			SPD.ShiftName  
			FROM @ProductionSummaryTable1 SPD ;			
		 
			INSERT INTO @resultSet  
			SELECT DISTINCT  
			0,  
			SPD.ShiftName,  
			SUM(SPD.ActualProduction),  
			COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
			SUM(DISTINCT SPD.PlantTargetProd),  
			SUM(SPD.StandardProduction),  
			SUM([NoOfLoads]),  
			SUM( SPD.ShiftRunTime),  
			SUM( SPD.ShiftRunTime),  
			SUM(SPD.NoOfPieces),  
			SUM(SPD.Rewash)  
			,@Viewtype   
			,@Subview  
			,0  
			FROM @ProductionSummaryTable SPD  
			GROUP BY   
			SPD.ShiftName;

			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name		
		  
		 END  
  
		---- By TimeLine - Week View  
		IF (@Subview = 4)  
		BEGIN  
			
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			CAST(RecordDate AS nvarchar(100))  
			FROM @ProductionSummaryTable1 SPD ;

			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
			AS  
			(  
				SELECT   
				CAST(RecordDate AS nvarchar(100)),  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM(SPD.StandardProduction),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime),  
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash)  
				FROM @ProductionSummaryTable SPD  
				GROUP BY DATEPART(weekday,RecordDate),RecordDate,SPD.ShiftId    
			)  
			INSERT INTO @resultSet  
			SELECT DISTINCT  
			0,  
			DateRange,  
			SUM(TotalLoad),  
			SUM(WasherEfficiency),  
			SUM(PlantTargetLoad),  
			SUM(StandardLoad),  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime),  
			SUM(NumberofPieces),  
			SUM(Rewash)  
			,@Viewtype   
			,@Subview  
			,0  
			FROM CTE  
			WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange;  

			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name

		END  
		
		---- By TimeLine - Month View  
		IF(@Subview = 3)  
		BEGIN  
		   DECLARE @FirstDay date = (SELECT TOP 1 RecordDate FROM @ProductionSummaryTable ORDER BY RecordDate)  
		   DECLARE @LastDay date = (SELECT TOP 1 RecordDate FROM @ProductionSummaryTable ORDER BY RecordDate DESC)  
		   DECLARE @FirstSunday date = NULL,  
		   @LastSaturday date = NULL  
        
		   SELECT   
		   @FirstSunday = CAST(DateAdd(dd, (8-DatePart(WEEKDAY,   
		   DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)))%7,   
		   DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)) AS DATE)   
  
		   SELECT  
		   @LastSaturday =   
		   DATEADD(dd,  
			-DATEPART(WEEKDAY,  
			 DATEADD(dd, -DAY(DATEADD(month, 1, @LastDay)),  
			 DATEADD(month, 1, @LastDay))) ,  
			DATEADD(dd, -DAY(DATEADD(MONTH, 1, @LastDay)), DATEADD(MONTH, 1, @LastDay)));  
		  
		  INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
		  SELECT DISTINCT SPD.ShiftId,SPD.ShiftRunTime AS ShiftRuntime,
				CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,-1,@FirstSunday)) = 7   
				AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate < DATEADD(DD,-1,@FirstSunday)) = 0)  
				THEN CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100))  
				WHEN DATEADD(DD,-1,@FirstSunday) > CAST(GETDATE() AS DATE)   
				THEN  
				CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @enddate, 101) AS nvarchar(100))  
				ELSE  
				CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) END As DateRange 
				FROM @ProductionSummaryTable1 SPD WHERE RecordDate < @FirstSunday AND RecordDate >= @FirstDay
		 UNION ALL
		  
		 SELECT DISTINCT SPD.ShiftId,SPD.ShiftRunTime AS ShiftRuntime,
				CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100))  + CHAR(13) + '-' +  
				CASE WHEN CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 121) AS nvarchar(100)) >  
				CAST(Convert(varchar, DateAdd(dd, (1 - DatePart(dw, @enddate) + 1), @enddate), 121) AS nvarchar(100))  
				THEN  CAST(Convert(varchar, DateAdd(dd, 1-1, @enddate), 101) AS nvarchar(100))  
				ELSE CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) END
				FROM @ProductionSummaryTable1 SPD  
				WHERE RecordDate BETWEEN @FirstSunday AND @LastSaturday

		 UNION ALL

		 SELECT DISTINCT SPD.ShiftId,SPD.ShiftRunTime AS ShiftRuntime,
		 CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,1,@LastSaturday)) = 1   
				AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate > DATEADD(DD,1,@LastSaturday)) = 0)  
				THEN   
				CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100))   
				ELSE  
				CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @LastDay, 101) AS nvarchar(100)) END
				FROM @ProductionSummaryTable1 SPD  
				WHERE RecordDate > @LastSaturday AND RecordDate <= @LastDay;				

  
		   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash) 
		    
		   AS  
		   (  
				SELECT          
				CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,-1,@FirstSunday)) = 7   
				AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate < DATEADD(DD,-1,@FirstSunday)) = 0)  
				THEN CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100))  
				WHEN DATEADD(DD,-1,@FirstSunday) > CAST(GETDATE() AS DATE)   
				THEN  
				CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @enddate, 101) AS nvarchar(100))  
				ELSE  
				CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) END As DateRange,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM(SPD.StandardProduction),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime),  
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash)  
  
				FROM @ProductionSummaryTable SPD  
				WHERE RecordDate < @FirstSunday AND RecordDate >= @FirstDay  
				GROUP BY SPD.ShiftId   
          
				UNION ALL    
    
				SELECT    
				CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100))  + CHAR(13) + '-' +  
				CASE WHEN CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 121) AS nvarchar(100)) >  
				CAST(Convert(varchar, DateAdd(dd, (1 - DatePart(dw, @enddate) + 1), @enddate), 121) AS nvarchar(100))  
				THEN  CAST(Convert(varchar, DateAdd(dd, 1-1, @enddate), 101) AS nvarchar(100))  
				ELSE CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) END  
				As DateRange,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM(SPD.StandardProduction),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime),  
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash)  
				FROM @ProductionSummaryTable SPD  
				WHERE RecordDate BETWEEN @FirstSunday AND @LastSaturday  
				GROUP BY Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101),  
				Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101),
				Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 121),		
				SPD.ShiftId  
         
				UNION ALL  
  
				SELECT   
				CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,1,@LastSaturday)) = 1   
				AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate > DATEADD(DD,1,@LastSaturday)) = 0)  
				THEN   
				CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100))   
				ELSE  
				CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @LastDay, 101) AS nvarchar(100)) END   As DateRange,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM(SPD.StandardProduction),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime),  
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash)  
				FROM @ProductionSummaryTable SPD  
				WHERE RecordDate > @LastSaturday AND RecordDate <= @LastDay   
				GROUP BY SPD.ShiftId  
		   )  
		   INSERT INTO @resultSet  
		   SELECT DISTINCT  
		   0,  
		   DateRange,  
		   SUM(TotalLoad),  
		   SUM(WasherEfficiency),  
		   SUM(PlantTargetLoad),  
		   SUM(StandardLoad),  
		   SUM(Numberofbatches),  
		   SUM(ActualRunTime),  
		   SUM(TargetRuntime),  
		   SUM(NumberofPieces),  
		   SUM(Rewash)  
		   ,@Viewtype   
		   ,@Subview  
			,0  
			FROM CTE  
			WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange ; 
		  
		   WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name
		END  
  
		IF(@Subview = 2)  
		BEGIN  
		   DECLARE @QuarterYear VARCHAR(100) = YEAR(@enddate);  

			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			DATENAME(MONTH, RecordDate) + ' ' +CAST( YEAR(RecordDate) as varchar)  
			FROM @ProductionSummaryTable1 SPD;

		   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
		   AS  
		   (  
				SELECT   
				DATENAME(MONTH, RecordDate) + ' ' +CAST( YEAR(RecordDate) as varchar) As DateRange,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM(SPD.StandardProduction),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime),  
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash)  
				FROM @ProductionSummaryTable SPD  
				GROUP BY  DATEPART(MONTH, RecordDate),DATENAME(MONTH, RecordDate),SPD.ShiftId,YEAR(RecordDate)  
		   )  
		    INSERT INTO @resultSet  
			SELECT DISTINCT  
			0,  
			DateRange,  
			SUM(TotalLoad),  
			SUM(WasherEfficiency),  
			SUM(PlantTargetLoad),  
			SUM(StandardLoad),  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime),  
			SUM(NumberofPieces),  
			SUM(Rewash)  
			,@Viewtype   
			,@Subview  
			,0  
			FROM CTE  
			WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange;
			
			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name
			 
		END     
  
		IF(@Subview = 1)  
		BEGIN  
			DECLARE @Year VARCHAR(100) = RIGHT(YEAR(@enddate),2);  
			
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name,ID)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			CASE 'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10))  
				WHEN 'Q1' THEN 'Jan' + RIGHT(YEAR(RecordDate),2)  + '- Mar' + RIGHT(YEAR(RecordDate),2)   
				WHEN 'Q2' THEN 'Apr' + RIGHT(YEAR(RecordDate),2)  + '- Jun' + RIGHT(YEAR(RecordDate),2)   
				WHEN 'Q3' THEN 'Jul' + RIGHT(YEAR(RecordDate),2)  + '-Sep' + RIGHT(YEAR(RecordDate),2)   
				WHEN 'Q4' THEN 'Oct' + RIGHT(YEAR(RecordDate),2)  + '- Dec'+ RIGHT(YEAR(RecordDate),2)   
				END, 
			cast( cast(RIGHT(YEAR(RecordDate),2) AS varchar ) +cast(  DATEPART(QUARTER, RecordDate) AS varchar) AS int)
			FROM @ProductionSummaryTable1 SPD ;
			
		    WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,RowNo)  
		    AS  
		    (  
				SELECT   
				CASE 'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10))  
				WHEN 'Q1' THEN 'Jan' + RIGHT(YEAR(RecordDate),2)  + '- Mar' + RIGHT(YEAR(RecordDate),2)   
				WHEN 'Q2' THEN 'Apr' + RIGHT(YEAR(RecordDate),2)  + '- Jun' + RIGHT(YEAR(RecordDate),2)   
				WHEN 'Q3' THEN 'Jul' + RIGHT(YEAR(RecordDate),2)  + '-Sep' + RIGHT(YEAR(RecordDate),2)   
				WHEN 'Q4' THEN 'Oct' + RIGHT(YEAR(RecordDate),2)  + '- Dec'+ RIGHT(YEAR(RecordDate),2)   
				END AS DateRange,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM(SPD.StandardProduction),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime),  
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash),
				cast( cast(RIGHT(YEAR(RecordDate),2) AS varchar ) +cast(  DATEPART(QUARTER, RecordDate) AS varchar) AS int)  RowNo  
				FROM @ProductionSummaryTable SPD  
				GROUP BY DATEPART(QUARTER, RecordDate),SPD.ShiftId ,RIGHT(YEAR(RecordDate),2)   
			)  
  
			INSERT INTO @resultSet  
			SELECT   
			0,  
			DateRange,  
			SUM(TotalLoad),  
			SUM(WasherEfficiency),  
			SUM(PlantTargetLoad),  
			SUM(StandardLoad),  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime),  
			SUM(NumberofPieces),  
			SUM(Rewash)  
			,@Viewtype   
			,@Subview  
			,0  
			FROM CTE  
			WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange ,RowNo
			order by RowNo;

			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name;
  
	   END  
	 END  
  
	 -- ******************************** Location View ***************************************************  
	 IF(@Viewtype = 2) 			 					
	 BEGIN 				   		
		IF(@Subview = 9)  
		BEGIN  
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,ID)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			WG.WasherGroupId  
			FROM @ProductionSummaryTable1 SPD 
			LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId  
			LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId ;
				
			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,WasherGroupId)  
			AS  
				(  
				SELECT   
				--SPD.MachineId,  
				WG.WasherGroupName,  
				SUM(SPD.ActualProduction),  
				CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/   
				NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) *   
				COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM(SPD.StandardProduction),  
				SUM([NoOfLoads]),  
				SUM(  SPD.ShiftRunTime),  
				SUM(  SPD.ShiftRunTime),  
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash),  
				WG.WasherGroupId  
					FROM @ProductionSummaryTable SPD LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId  
					LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId   
				GROUP BY WG.WasherGroupName,WG.WasherGroupId,SPD.ShiftId--,SPD.MachineId    
				)  
				INSERT INTO @resultSet  
				SELECT DISTINCT  
					0,  
					DateRange,  
					SUM(TotalLoad),  
					SUM(WasherEfficiency),  
					@PlantTargetProduction,  
					SUM(StandardLoad),  
					SUM(Numberofbatches),  
					SUM( ActualRunTime),  
					SUM( TargetRuntime),  
					SUM(NumberofPieces),  
					SUM(Rewash)  
					,@Viewtype   
					,@Subview  
					,WasherGroupId  
				FROM CTE  
					WHERE TotalLoad IS NOT NULL  
					GROUP BY DateRange,WasherGroupId	;

			WITH CTE1
			AS
			(
				SELECT SUM(ShiftRuntime) AS Shiftruntime,ID FROM @TableShiftruntime
				GROUP BY ID
			)

			--Update Shiftruntime in Temp table
			UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
			FROM @resultSet  RS
			LEFT OUTER JOIN 
			CTE1 TS ON RS.Id=TS.ID
						
		END  
  
		IF(@Subview = 10)  
		BEGIN 
				
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime,         
			cast( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName MachineName
			FROM @ProductionSummaryTable1 SPD   
			LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId  
			LEFT JOIN TCD.Washer w on MS.WasherId=w.WasherId  
			LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId ;  
			--WHERE   
			--	(  
			--	CASE @drillvalue     
			--	WHEN '' THEN 'TRUE'           
			--	ELSE                                                      
			--	CASE WHEN WG.WasherGroupId IN (@drillvalue) THEN 'TRUE' END              
			--	END='TRUE'  
			--	)  ;				 
			  

			--SELECT * FROM @TableShiftruntime;
				 
			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
			AS  
			(  
			SELECT           
			cast( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName MachineName,  
			SUM(SPD.ActualProduction),  
			CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/   
			NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) *   
			COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)) ,  
			SUM(DISTINCT SPD.PlantTargetProd),  
			SUM(SPD.StandardProduction),  
			SUM([NoOfLoads]),  
			SUM(  SPD.ShiftRunTime),  
			SUM(  SPD.ShiftRunTime),  
			SUM(SPD.NoOfPieces),  
			SUM(SPD.Rewash)  
          
			FROM @ProductionSummaryTable SPD   
			LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId  
			LEFT JOIN TCD.Washer w on MS.WasherId=w.WasherId  
			LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId   
			WHERE   
				(  
				CASE @drillvalue     
				WHEN '' THEN 'TRUE'           
				ELSE                                                      
				CASE WHEN WG.WasherGroupId IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				)  
			GROUP BY cast( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName,SPD.ShiftId  
  
			)  
  
			INSERT INTO @resultSet  
				SELECT DISTINCT  
				0,  
				DateRange,  
				SUM(TotalLoad),  
				SUM(WasherEfficiency),  
				@PlantTargetProduction,  
				SUM(StandardLoad),  
				SUM( Numberofbatches),  
				SUM( ActualRunTime),  
				SUM( TargetRuntime),  
				SUM(NumberofPieces),  
				SUM(Rewash)  
				,@Viewtype   
				,@Subview  
				,0  
			FROM CTE  
				WHERE TotalLoad IS NOT NULL  
				GROUP BY DateRange;

			WITH CTE1
			AS
			(
				SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
				GROUP BY Name 
			)				
			--Update Shiftruntime in Temp table
			UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
			FROM @resultSet  RS
			LEFT OUTER JOIN 
			CTE1 TS ON RS.DateRange=TS.Name		
				   
		END  
	 END  
  
		-- ******************************** ChainCategory View **********************************************  
	 IF(@Viewtype = 5)  
	 BEGIN  
	  IF(@Subview = 16)  
	  BEGIN  
		 -- ToDo : Change this part for chaincategory  
		 WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,textileId)  
	   AS  
	   (  
		SELECT      
	   CC.NAME,  
	   SUM(SPD.ActualProduction),  
	   COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
	   SUM(DISTINCT SPD.PlantTargetProd),  
	   SUM(SPD.StandardProduction),  
	   SUM([NoOfLoads]),  
	   SUM( SPD.ShiftRunTime),  
	   SUM( SPD.ShiftRunTime),  
	   SUM(SPD.NoOfPieces),  
	   SUM(SPD.Rewash),  
	   cc.TextileId  
		  FROM  
		@ProductionSummaryTable SPD  
	   INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
		INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = PM.PlantProgramId  
		INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId   
	   Group by   
		 CC.Name,cc.TextileId,SPD.ShiftId  
		 )  
	   INSERT INTO @resultSet  
		 SELECT DISTINCT  
		  0,  
		  DateRange,  
		  SUM(TotalLoad),  
		  SUM(WasherEfficiency),  
		  @PlantTargetProduction,  
		  SUM(StandardLoad),  
		  SUM(Numberofbatches),  
		  SUM(ActualRunTime),  
		  SUM(TargetRuntime),  
		  SUM(NumberofPieces),  
		  SUM(Rewash)  
		  ,@Viewtype   
		  ,@Subview  
		  ,textileId  
		FROM CTE  
		 WHERE TotalLoad IS NOT NULL  
		 GROUP BY DateRange,textileId  
	  END  
      
	  IF(@Subview = 19)  
	  BEGIN  
	   -- ToDo : Change this part for chaincategory  
		WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
	   AS  
	   (  
		SELECT    
	   PCP.PlantProgramName,  
	   SUM(SPD.ActualProduction),  
	   COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
	   SUM(DISTINCT SPD.PlantTargetProd),  
	   SUM(SPD.StandardProduction),  
	   SUM([NoOfLoads]),  
	   SUM( SPD.ShiftRunTime),  
	   SUM( SPD.ShiftRunTime),  
	   SUM(SPD.NoOfPieces),  
	   SUM(SPD.Rewash)  
		 FROM @ProductionSummaryTable SPD  
	   INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
		INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = PM.PlantProgramId  
		INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId   
		WHERE  
	   (  
		 CASE @drillvalue     
		  WHEN '' THEN 'TRUE'           
		  ELSE                                                      
		  CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END              
		  END='TRUE'  
		)  
	   Group by   
		 PCP.PlantProgramName,PCP.PlantProgramId,SPD.ShiftId  
		 )  
		 INSERT INTO @resultSet  
		 SELECT DISTINCT  
		  0,  
		  DateRange,  
		  SUM(TotalLoad),  
		  SUM(WasherEfficiency),  
		  @PlantTargetProduction,  
		  SUM(StandardLoad),  
		  SUM(Numberofbatches),  
		  SUM(ActualRunTime),  
		  SUM(TargetRuntime),  
		  SUM(NumberofPieces),  
		  SUM(Rewash)  
		  ,@Viewtype   
		  ,@Subview  
		  ,0  
		FROM CTE  
		 WHERE TotalLoad IS NOT NULL  
		 GROUP BY DateRange  
	  END  
  
	 END  
  
		-- ******************************** Customer View ***************************************************  
	 IF(@Viewtype = 6)  
		 BEGIN  

			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			PC.CustomerName  
			FROM @ProductionSummaryTable SPD  INNER JOIN TCD.PlantCustomer PC on PC.CustomerId = SPD.CustomerId  ;	

		    WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
		    AS  
			(  
				SELECT   
				PC.CustomerName,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM(SPD.StandardProduction),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime),  
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash)  
				FROM @ProductionSummaryTable SPD  INNER JOIN TCD.PlantCustomer PC on PC.CustomerId = SPD.CustomerId  
				GROUP BY   
				PC.CustomerName,SPD.ShiftId  
			)  
			INSERT INTO @resultSet  
			SELECT DISTINCT  
			0,  
			DateRange,  
			SUM(TotalLoad),  
			SUM(WasherEfficiency),  
			@PlantTargetProduction,  
			SUM(StandardLoad),  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime),  
			SUM(NumberofPieces),  
			SUM(Rewash)  
			,@Viewtype   
			,@Subview  
			,0  
			FROM CTE  
			WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange ; 
			
			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name	

		 END  
  
	-- ******************************** Formula View ****************************************************  
	 IF(@Viewtype = 7)  
	 BEGIN  
	   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
	   AS  
	   (  
	   SELECT   
	   PM.Name,  
	   SUM(SPD.ActualProduction),  
		 COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
	   SUM(DISTINCT SPD.PlantTargetProd),  
	   SUM(SPD.StandardProduction),  
	   SUM([NoOfLoads]),  
	   SUM( SPD.ShiftRunTime),  
	   SUM( SPD.ShiftRunTime),  
	   SUM(SPD.NoOfPieces),  
	   SUM(SPD.Rewash)  
	   FROM @ProductionSummaryTable SPD   
	   INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
	   Group by   
	   PM.Name,SPD.ShiftId  
	   )  
	   INSERT INTO @resultSet  
		 SELECT DISTINCT  
		  0,  
		  DateRange,  
		  SUM(TotalLoad),  
		  SUM(WasherEfficiency),  
		  @PlantTargetProduction,  
		  SUM(StandardLoad),  
		  SUM(Numberofbatches),  
		  SUM(ActualRunTime),  
		  SUM(TargetRuntime),  
		  SUM(NumberofPieces),  
		  SUM(Rewash)  
		  ,@Viewtype   
		  ,@Subview  
		  ,0  
		FROM CTE  
		 WHERE TotalLoad IS NOT NULL  
		 GROUP BY DateRange  
		END  
  
	-- ******************************** Formula segmentView ****************************************************  
	  	
	 IF(@Viewtype = 8)  
	 BEGIN  
		IF(@Subview =20)-- Formula Segment  
		BEGIN 
			
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			FS.SegmentName    
			FROM @ProductionSummaryTable1 SPD
			INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
			INNER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=SPD.FormulaSegmentID ;

		
			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,FormulaSegmentID)  
			AS  
			(  
				SELECT   
				FS.SegmentName,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM(SPD.StandardProduction),  
				SUM([NoOfLoads]),  
				SUM(SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime),  
				--SUM(SPD.IndividualShiftRunTime),
				--SUM(SPD.IndividualShiftRunTime),
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash),  
				SPD.FormulaSegmentID  
				FROM @ProductionSummaryTable SPD   
				INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
				INNER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=SPD.FormulaSegmentID   
				Group by SPD.FormulaSegmentID,FS.SegmentName,SPD.ShiftId    
			)  
			INSERT INTO @resultSet  
			(  
			ShiftId,  
			DateRange ,  
			TotalLoad  ,  
			WasherEfficiency ,  
			PlantTargetLoad  ,  
			StandardLoad ,  
			Numberofbatches ,  
			[ActualRunTime],   
			[TargetRunTime],  
			NumberofPieces  ,  
			Rewash ,  
			Viewtype ,  
			Subview ,  
			Id  
			)  
			SELECT DISTINCT  
			0,  
			DateRange,  
			SUM(TotalLoad),  
			SUM(WasherEfficiency),  
			@PlantTargetProduction,  
			SUM(StandardLoad),  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime),  
			SUM(NumberofPieces),  
			SUM(Rewash)  
			,@Viewtype   
			,@Subview  
			,FormulaSegmentID  
			FROM CTE  
			WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange,FormulaSegmentID;
			
			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name	
			 
		END  
		IF(@Subview =21)-- Formula Categories  
		BEGIN 
		  
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT SPD.ShiftId,SPD.ShiftRunTime AS ShiftRuntime, EC.CategoryName    
				FROM @ProductionSummaryTable1 SPD
				INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
				--WHERE  
				--	(  
				--	CASE      
				--	WHEN @drillvalue='' THEN 'TRUE'   
				--	WHEN @drillvalue IS NULL THEN 'TRUE'    
				--	ELSE                                                      
				--	CASE WHEN SPD.FormulaSegmentID IN (@drillvalue) THEN 'TRUE' END              
				--	END='TRUE'  
				--	) AND EC.CategoryName IS NOT NULL
			UNION 

			SELECT DISTINCT SPD.ShiftId,SPD.ShiftRunTime AS ShiftRuntime, CC.NAME   
			FROM @ProductionSummaryTable1 SPD
			--INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
			--INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = SPD.ChainProgaramId  
			INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
				--WHERE  
				--(  
				--CASE      
				--WHEN @drillvalue='' THEN 'TRUE'   
				--WHEN @drillvalue IS NULL THEN 'TRUE'    
				--ELSE                                                      
				--CASE WHEN SPD.FormulaSegmentID IN (@drillvalue) THEN 'TRUE' END              
				--END='TRUE'  
				--) 
				;
			  
			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,TextileId)  
			AS  
			(  
				SELECT EC.CategoryName,	SUM(SPD.ActualProduction),COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
				SUM(DISTINCT SPD.PlantTargetProd),SUM(SPD.StandardProduction),SUM([NoOfLoads]),SUM( SPD.ShiftRunTime),SUM( SPD.ShiftRunTime),  
				--SUM(SPD.IndividualShiftRunTime),SUM(SPD.IndividualShiftRunTime),
				SUM(SPD.NoOfPieces),SUM(SPD.Rewash),EC.TextileId  
				FROM @ProductionSummaryTable SPD   
				INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId  
				WHERE  
				(  
				CASE      
				WHEN @drillvalue='' THEN 'TRUE'   
				WHEN @drillvalue IS NULL THEN 'TRUE'    
				ELSE                                                      
				CASE WHEN SPD.FormulaSegmentID IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				) AND EC.CategoryName IS NOT NULL  
				GROUP BY EC.CategoryName,EC.TextileId,SPD.ShiftId  
  
				UNION  
  
				SELECT CC.NAME,SUM(SPD.ActualProduction),COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),SUM(SPD.StandardProduction),SUM([NoOfLoads]),SUM( SPD.ShiftRunTime),SUM( SPD.ShiftRunTime), 
				--SUM(SPD.IndividualShiftRunTime),SUM(SPD.IndividualShiftRunTime), 
				SUM(SPD.NoOfPieces),SUM(SPD.Rewash),cc.TextileId  
				FROM @ProductionSummaryTable SPD  
				--INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
				--INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = SPD.ChainProgaramId  
				INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
				WHERE  
				(  
				CASE      
				WHEN @drillvalue='' THEN 'TRUE'   
				WHEN @drillvalue IS NULL THEN 'TRUE'    
				ELSE                                                      
				CASE WHEN SPD.FormulaSegmentID IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				)   
				Group by CC.Name,cc.TextileId,SPD.ShiftId  
				)  
				INSERT INTO @resultSet  
				(  
				ShiftId,  
				DateRange ,  
				TotalLoad  ,  
				WasherEfficiency ,  
				PlantTargetLoad  ,  
				StandardLoad ,  
				Numberofbatches ,  
				[ActualRunTime],   
				[TargetRunTime],  
				NumberofPieces  ,  
				Rewash ,  
				Viewtype ,  
				Subview ,  
				Id  
				)  
				SELECT DISTINCT  
				0,  
				DateRange,  
				SUM(TotalLoad),  
				SUM(WasherEfficiency),  
				SUM(PlantTargetLoad),  
				SUM(StandardLoad),  
				SUM(Numberofbatches),  
				SUM(ActualRunTime),  
				SUM(TargetRuntime),  
				SUM(NumberofPieces),  
				SUM(Rewash)  
				,@Viewtype   
				,@Subview  
				,TextileId  
				FROM CTE  
				WHERE TotalLoad IS NOT NULL  
				GROUP BY DateRange,TextileId  ;
			
			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name	

	    END  
		IF(@Subview=22) --Formula  
		BEGIN  

			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			PM.Name    
			FROM @ProductionSummaryTable1 SPD
			INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId  
				INNER JOIN TCD.ProgramMaster PM ON --EC.TextileId = PM.EcolabTextileCategoryId AND 
				SPD.ProgramMasterId = PM.ProgramId    
	
				--WHERE  
				--(  
				--CASE      
				--WHEN @drillvalue='' THEN 'TRUE'   
				--WHEN @drillvalue IS NULL THEN 'TRUE'    
				--ELSE                                                      
				--CASE WHEN EC.TextileId IN (@drillvalue) THEN 'TRUE' END              
				--END='TRUE'  
				--) AND PM.NAME IS NOT NULL
			
			UNION

			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			PM.Name    
			FROM @ProductionSummaryTable1 SPD
			INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId  
				INNER JOIN TCD.ProgramMaster PM ON  SPD.ProgramMasterId = PM.ProgramId    
				--WHERE  
				--(  
				--CASE      
				--WHEN @drillvalue='' THEN 'TRUE'   
				--WHEN @drillvalue IS NULL THEN 'TRUE'    
				--ELSE                                                      
				--CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END              
				--END='TRUE' 
				--)
				 ;

			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,ID)  
			AS  
			(  
				SELECT PM.Name,SUM(SPD.ActualProduction),COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),SUM(SPD.StandardProduction),SUM([NoOfLoads]),SUM(SPD.ShiftRunTime),SUM(SPD.ShiftRunTime), 		
				--SUM(SPD.IndividualShiftRunTime),SUM(SPD.IndividualShiftRunTime),
				SUM(SPD.NoOfPieces),SUM(SPD.Rewash),PM.ProgramId  
				FROM @ProductionSummaryTable SPD   
				INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId  
				INNER JOIN TCD.ProgramMaster PM ON --EC.TextileId = PM.EcolabTextileCategoryId AND 
				SPD.ProgramMasterId = PM.ProgramId    
	
				WHERE  
				(  
				CASE      
				WHEN @drillvalue='' THEN 'TRUE'   
				WHEN @drillvalue IS NULL THEN 'TRUE'    
				ELSE                                                      
				CASE WHEN EC.TextileId IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				) AND PM.NAME IS NOT NULL 
				GROUP BY PM.Name,PM.ProgramId--,SPD.ShiftId 
  
				UNION   
  
				SELECT PM.Name,SUM(SPD.ActualProduction),COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),SUM(SPD.StandardProduction),SUM([NoOfLoads]),SUM( SPD.ShiftRunTime),SUM( SPD.ShiftRunTime),  
				--SUM(SPD.IndividualShiftRunTime),SUM(SPD.IndividualShiftRunTime), 
				SUM(SPD.NoOfPieces),SUM(SPD.Rewash),PM.ProgramId  
				FROM @ProductionSummaryTable SPD   
				INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId  
				INNER JOIN TCD.ProgramMaster PM ON  SPD.ProgramMasterId = PM.ProgramId    
				WHERE  
				(  
				CASE      
				WHEN @drillvalue='' THEN 'TRUE'   
				WHEN @drillvalue IS NULL THEN 'TRUE'    
				ELSE                                                      
				CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE' 
				)  
				GROUP BY PM.Name,PM.ProgramId--,SPD.ShiftId    
			)  
  
			INSERT INTO @resultSet(ShiftId,DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,  
			StandardLoad,Numberofbatches,[ActualRunTime],[TargetRunTime],NumberofPieces  ,  
			Rewash,Viewtype,Subview,Id  
			)  
			SELECT DISTINCT 0,DateRange,SUM(TotalLoad),	SUM(WasherEfficiency),SUM(PlantTargetLoad),
			SUM(StandardLoad),SUM(Numberofbatches),	SUM(ActualRunTime),	SUM(TargetRuntime),	SUM(NumberofPieces),
			SUM(Rewash),@Viewtype ,@Subview,ID  
			FROM CTE  
			WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange,ID ; 
			
			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name	

		END  
	 END  

	DECLARE @MaxShiftruntime DECIMAL(30,10)=NULL   
	IF(@Viewtype IN (2,8) ) --for Location and Formula, shift hours will be total shifthours for particular duration
	BEGIN		
		 IF(@Subview=9)
		 BEGIN
			SELECT @MaxShiftruntime=MAX(A.Shiftruntime) FROM
			 (
				SELECT SUM(ShiftRuntime) AS Shiftruntime,ID FROM @TableShiftruntime
				GROUP BY ID
			)A
		 END
		 ELSE
		 BEGIN
			SELECT @MaxShiftruntime=MAX(A.Shiftruntime) FROM
			 (
				SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
				GROUP BY Name
			)A
		 END
		
		UPDATE  @resultSet SET ActualRunTime=@MaxShiftruntime
	END
	ELSE IF(@Viewtype IN(1))
	BEGIN
		SELECT @MaxShiftruntime= (SELECT SUM(ShiftRuntime) AS Shiftruntime FROM @TableShiftruntime)
	END
	

	--- ********* Return result ********************  
  
		SELECT DISTINCT  ShiftId, DateRange,ISNULL([TCD].[FnConsumptionOnMetrics](TotalLoad,'Weight',@UserId),0) AS TotalLoad,        
		  ISNULL([TCD].[FnConsumptionOnMetrics](WasherEfficiency,'Weight',@UserId),0)AS Washerefficiency,  
		  ISNULL([TCD].[FnConsumptionOnMetrics](PlantTargetLoad,'Weight',@UserId),0) AS PlantTargetLoad,
		  ISNULL([TCD].[FnConsumptionOnMetrics](StandardLoad,'Weight',@UserId),0) AS StandardLoad,
		  ISNULL(Numberofbatches,0)AS NumberofBatches,ISNULL(ActualRunTime,0) ShiftRuntime,ISNULL(TargetRunTime,0) TargetRuntime,
		  ISNULL(NumberofPieces,0) AS NoofPieces,  
		  ISNULL(Rewash,0) AS Rewash,Viewtype,Subview ,Id,@CorrectionVariable,@MaxShiftruntime AS Maxshiftruntime  
		  FROM @resultSet   
  
  
   
SET NOCOUNT OFF     
END  

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ReportProductionSummary]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ReportProductionSummary]
END
GO

CREATE PROCEDURE [TCD].[ReportProductionSummary]   
 
     @startdate datetime = '',  
     @enddate datetime = '',  
     @Viewtype varchar(30) = '',  
     @Subview varchar(30)= '',  
     @Drillvalue varchar(100)= '',  
     @EcolabAccountNumber Nvarchar(25) = '',  
     @MachineType VARCHAR(20)= '',  
     @MachineGroup VARCHAR(MAX) = '',  
     @Machine VARCHAR(MAX) = '',  
     @EcolabCategory VARCHAR(MAX) = '',  
     @ChainCategory VARCHAR(MAX) = '',  
     @PlantFormula  VARCHAR(MAX) = '',  
     @ChainFormula VARCHAR(MAX) = '',  
     @Customer VARCHAR(MAX) = '',  
     @SortColumnId int = 0,  
     @SortDirection varchar(4) = '',  
     @CurrencyCode varchar(3) = '',  
     @UserId INT = NULL,
	 @FormulaSegement VARCHAR(MAX)='', --Formula segment,
	 @FormulaCategory VARCHAR(MAX)='', --Formula category
	 @Formula VARCHAR(MAX)='' --Formula
AS     
BEGIN     
SET NOCOUNT ON   
  
 SET @startdate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@startdate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@startdate AS time)) AS DateTime))  
 SET @EndDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndDate AS time)) AS DateTime))  
   
   --SELECT @startdate,@enddate
 DECLARE @ReportGenerated INT = 6,  
    @Month INT = MONTH(GETDATE()),@CorrectionVariable Decimal(18,2),@PlantTargetProduction decimal(18,2)  
    --,@ShiftRuntime int,@NoShiftTotalRuntime INT,@TotaRuntime int  
  
 -- Inserting the record into Report History   
 INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)  
 SELECT @EcolabAccountNumber,UM.UserId,UM.LoginName,GETUTCDATE(),@ReportGenerated,  
 CASE WHEN @ReportGenerated = 6  
  THEN 'Generated Report : Production Summary Report' END  
 FROM TCD.UserMaster UM  
 WHERE UM.EcolabAccountNumber = @EcolabAccountNumber AND UM.UserId = @UserId  
 /* Completed the record insertion into Report History */   
  
    -- Return Table set  
    DECLARE @resultSet Table  
    (  
      ShiftId Int,  
      DateRange varchar(100),  
      TotalLoad Decimal(18,2) ,  
      WasherEfficiency Decimal(18,2),  
      PlantTargetLoad Decimal(18,2) ,  
      Numberofbatches INT,  
      [ActualRunTime] [int] NULL,  
      [TargetRunTime] [int] NULL,  
      Viewtype varchar(100) NULL,  
      Subview varchar(100) NULL,  
      Id int NULL        
    )  
    DECLARE @CorrectionFactor TABLE   
 (  
 [ShiftId] [int] NULL,  
 MachineId INT NULL,  
 [ActualProduction] [int] NULL,  
 [StandardProduction] [int] NULL,  
 [PlantTargetProd] [int] NULL,  
 [ActualRunTime] [int] NULL,  
 [TargetRunTime] [int] NULL,  
 ManualInputWeight INT,  
 ManulainputsNoofloads INT  
 )  
  
 DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))  
 INSERT INTO @MachineTypeTable EXEC [TCD].[CharlistToTable] @MachineType,','  
  
 DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))  
 INSERT INTO @WasherGroupTable EXEC [TCD].[CharlistToTable] @machineGroup,','    
  
 DECLARE @MachineTable TABLE(Machine Varchar(100))  
 INSERT INTO @MachineTable EXEC [TCD].[CharlistToTable] @Machine,','  
  
 DECLARE @EcolabCategoryTable TABLE(EcolabCategory Varchar(100))  
 INSERT INTO @EcolabCategoryTable EXEC [TCD].[CharlistToTable] @EcolabCategory,','  
  
 DECLARE @ChainCategoryTable TABLE(ChainCategory Varchar(100))  
 INSERT INTO @ChainCategoryTable EXEC [TCD].[CharlistToTable] @ChainCategory,','  
  
 DECLARE @PlantFormulaTable TABLE(PlantFormula Varchar(100))  
 INSERT INTO @PlantFormulaTable EXEC [TCD].[CharlistToTable] @PlantFormula,','  
  
 DECLARE @ChainFormulaTable TABLE(ChainFormula Varchar(100))  
 INSERT INTO @ChainFormulaTable EXEC [TCD].[CharlistToTable] @ChainFormula,','  
  
 DECLARE @CustomerTable TABLE(Customer Varchar(100))  
 INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','  
  
 --Formula Segment --added by Kiran
 DECLARE @FormulaSegmentTable TABLE(FormulaSegment Varchar(1000))
    INSERT INTO @FormulaSegmentTable EXEC [TCD].[CharlistToTable] @FormulaSegement,','

 --Formula category
 DECLARE @FormulaCategoryTable TABLE(FormulaCategory Varchar(1000),Type CHAR(1))
    INSERT INTO @FormulaCategoryTable(FormulaCategory) EXEC [TCD].[CharlistToTable] @Formulacategory,',' 
  
  --Below 1000 Ecolab category
  UPDATE @FormulaCategoryTable SET TYPE='E' WHERE FormulaCategory<1000
  --Above 1000 consider as Chain category
  UPDATE @FormulaCategoryTable SET TYPE='C' WHERE FormulaCategory>=1000

  --Rollbacking to actual ID
  UPDATE @FormulaCategoryTable SET FormulaCategory=FormulaCategory-1000 WHERE TYPE='C'
 
  --SELECT * FROM @FormulaCategoryTable

  INSERT INTO @EcolabCategoryTable(EcolabCategory)
  SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='E' 

  INSERT INTO @ChainCategoryTable(ChainCategory)
  SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='C'

  --Value Assigning
  IF (EXISTS(SELECT * FROM @EcolabCategoryTable) AND @FormulaCategory!='')
  BEGIN
   SET @EcolabCategory=@FormulaCategory
  END
  IF (EXISTS(SELECT * FROM @ChainCategoryTable) AND @FormulaCategory!='')
  BEGIN
   SET @ChainCategory=@FormulaCategory
  END

 -----Formula Ecolab/Chain categories
 DECLARE @FormulaTable TABLE(Formula Varchar(1000),Type CHAR(1))
    INSERT INTO @FormulaTable(Formula) EXEC [TCD].[CharlistToTable] @Formula,',' 
      
  --Plant fomula   
  INSERT INTO @PlantFormulaTable(PlantFormula) 
  SELECT Formula FROM @FormulaTable 
  --chain formula   
  INSERT INTO @ChainFormulaTable(ChainFormula) 
  SELECT Formula FROM @FormulaTable 
  --SELECT * FROM @PlantFormulaTable
  --SELECT * FROM @ChainFormulaTable

  --Value Assigning
  IF (EXISTS(SELECT * FROM @PlantFormulaTable) AND @Formula!='')
  BEGIN
   SET @PlantFormula=@Formula
  END
  IF (EXISTS(SELECT * FROM @ChainFormulaTable) AND @Formula!='')
  BEGIN
   SET @ChainFormula=@Formula
  END
 --Formula end

 INSERT INTO @CorrectionFactor  
 (  
   [ShiftId],  
   [MachineId] ,  
   [ActualProduction] ,  
   [StandardProduction] ,  
   [PlantTargetProd] ,  
   [ActualRunTime] ,  
   [TargetRunTime],  
   ManualInputWeight,  
   ManulainputsNoofloads     
 )  
 SELECT   
  PS.[ShiftId],  
  SPD.[MachineId],  
  ISNULL([TCD].[FnConsumptionOnMetrics](SUM(ISNULL(SPD.[ActualProduction],0))+SUM(ISNULL(MIP.ActualWeight,0)),'Weight',@UserId),0),  
  --ISNULL([TCD].[FnConsumptionOnMetrics](SUM(SPD.[ActualProduction]),'Weight',@UserId),0),  
  --SUM(SPD.[ActualProduction]),  
  ISNULL([TCD].[FnConsumptionOnMetrics](SUM(SPD.StandardProduction),'Weight',@UserId),0),  
  --SUM(SPD.StandardProduction),  
  ISNULL([TCD].[FnConsumptionOnMetrics](SUM(DISTINCT SPD.[PlantTargetProd]),'Weight',@UserId),0),  
  --SUM(DISTINCT SPD.[PlantTargetProd]),  
  SUM(SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0)),  
  SUM(SPD.[TargetRunTime] + ISNULL(SPD.TargetTurnTime,0)),  
  SUM(ISNULL(MIP.ActualWeight,0)),SUM(ISNULL(MIP.NoofLoads,0))  
 FROM  TCD.ShiftProductionDataRollup SPD   
 INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId  
 INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId   
 LEFT OUTER JOIN --Manual Production Details appending  
  (  
  SELECT WasherId,FormulaId,CONVERT(DATE,RecordedDate) AS LoadDate,SUM(ISNULL(Value,0)) AS ActualWeight,  
  ISNULL(COUNT(CONVERT(DATE,RecordedDate)),0) AS NoofLoads FROM  
  TCD.ManualProduction MP  
  GROUP BY WasherId,FormulaId,CONVERT(DATE,RecordedDate)  
  )MIP ON MIP.WasherId=SPD.EcolabWasherId AND MIP.FormulaId=SPD.ProgramMasterId AND MIP.LoadDate=CONVERT(DATE,PS.StartDateTime)  
 WHERE   
 CASE @StartDate                                                                                  
 WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                  
 ELSE CASE WHEN PS.[StartDateTime] >= @startdate  AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                          
 END='TRUE'   
 GROUP BY MachineId,PS.ShiftId;  
  
 --SELECT * FROM  @CorrectionFactor;
  
  
 WITH CTE (PlantTargetProd) AS  
 (  
 SELECT SUM(DISTINCT SPD.[PlantTargetProd]) FROM @CorrectionFactor SPD GROUP BY ShiftId  
 )  
 SELECT @PlantTargetProduction = SUM(PlantTargetProd) FROM CTE;  
  
  
 WITH CTE (MachineId,PlantEfficiency)  
 AS  
 (  
 SELECT   
  MachineId,  
  CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/   
   NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) *   
   COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2))     
   FROM @CorrectionFactor SPD GROUP BY MachineId  
 )  
    SELECT @CorrectionVariable = @PlantTargetProduction/NULLIF(SUM(PlantEfficiency),0) FROM CTE  
  
      
 DECLARE @ProductionSummaryTable TABLE(  
		[ShiftId] [int] NULL,  
		[ShiftName] Varchar(100) NULL,  
		RecordDate date,   
		[StartDateTime] [datetime] NULL,  
		[EndDateTime] [datetime] NULL,  
		[MachineId] [int] NULL,  
		[EcolabWasherId] [int] NULL,  
		[ActualProduction] [int] NULL,  
		[StandardProduction] [int] NULL,  
		[NoOfLoads] [int] NULL,  
		[LoadEfficiency] [decimal](18, 2) NULL,  
		[TimeEfficiency] [decimal](18, 2) NULL,  
		TotalEfficiency [decimal](18, 2) NULL,  
		[PlantTargetProd] [int] NULL,  
		[ActualRunTime] [int] NULL,  
		[TargetRunTime] [int] NULL,  
		[ShiftRunTime] Decimal(30,10)  NULL,  
		RowNumberID INT NULL,  
		ProgramMasterID INT NULL,
		EcolabTextileId int,
		ChainTextileId int,
		ChainProgaramId int,
		FormulaSegmentID INT,
		CustomerId int,
		IndividualShiftRunTime Decimal(30,10) 
             )  
 INSERT INTO @ProductionSummaryTable  
 (  
 [ShiftId] ,[ShiftName] ,RecordDate, [StartDateTime] ,[EndDateTime] ,[MachineId]  ,[EcolabWasherId]  ,  
 [ActualProduction] ,[StandardProduction] ,[NoOfLoads] ,[LoadEfficiency],[TimeEfficiency] ,TotalEfficiency ,  
 [PlantTargetProd],[ActualRunTime] ,[TargetRunTime] ,[ShiftRunTime] ,RowNumberID ,ProgramMasterID,
 EcolabTextileId,ChainTextileId,ChainProgaramId,FormulaSegmentID,CustomerId
 )  
    SELECT   
 SPD.[ShiftId],  
 PS.ShiftName,  
 CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date),  
 DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]),  
 DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[EndDateTime]),          
 SPD.[MachineId],  
 SPD.[EcolabWasherId],  
 SPD.[ActualProduction],  
 SPD.StandardProduction,  
 SPD.[NoOfLoads],  
 SPD.[LoadEfficiency],  
 SPD.[TimeEfficiency],  
 (SPD.[LoadEfficiency] * SPD.TimeEfficiency),  
 SPD.[PlantTargetProd],  
 SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0),  
 SPD.[TargetRunTime] + ISNULL(SPD.TargetTurnTime,0),  
 DATEDIFF(Second,ps.StartDateTime,PS.EndDateTime) +  
 ISNULL(  
 (  
 SELECT  
 SUM(SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0))  
  FROM TCD.ShiftProductionDataRollup SPD   
 INNER JOIN TCD.ProductionShiftData PSD ON SPD.ShiftId = PSD.ShiftId  
 INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId   
 WHERE   
 PSD.[StartDateTime] = PS.StartDateTime AND PSD.[StartDateTime] = PS.EndDateTime AND PS.ShiftName = 'No Shift'  
 ),0),  
 ROW_NUMBER() OVER(Partition BY SPD.ProgramMasterId, SPD.[EcolabWasherId], CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date)  
 ORDER BY SPD.ProgramMasterId, SPD.[EcolabWasherId] ),  
 SPD.ProgramMasterId,
 SPD.EcolabTextileId,SPD.ChainTextileId,SPD.ChainProgaramId,
    CASE WHEN SPD.ChainProgaramId IS NOT NULL THEN ChainPlant.FormulaSegmentId
 ELSE FS1.FormulaSegmentID END AS Formulasegment,
 SPD.CustomerId
      
 FROM TCD.ShiftProductionDataRollup SPD   
 INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId  
 INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
 INNER JOIN TCD.MachineSetup ms ON SPD.MachineId = ms.WasherId  
 LEFT OUTER JOIN
   (
   --IF Chain Plant
   SELECT PCP.PlantProgramId,PCP.PlantChainId,PCP.ChainTextileCategoryId,PCP.EcolabTextileCategoryId,
   PCP.FormulaSegmentId,PCP.EcolabSaturationId
   FROM TCD.PlantChainProgram PCP 
   LEFT OUTER JOIN TCD.ChainTextileCategory CTC ON CTC.TextileId=PCP.ChainTextileCategoryId
   LEFT OUTER JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId=PCP.EcolabTextileCategoryId
   LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=PCP.FormulaSegmentId
   LEFT OUTER JOIN TCD.EcolabSaturation ES ON ES.EcolabSaturationId=PCP.EcolabSaturationId
   )ChainPlant ON SPD.ChainProgaramId=ChainPlant.PlantProgramId

 LEFT OUTER JOIN TCD.EcolabTextileCategory ETC1 ON ETC1.TextileId=PM.EcolabTextileCategoryId
 LEFT OUTER JOIN TCD.FormulaSegments FS1 ON FS1.FormulaSegmentID=PM.FormulaSegmentId
 LEFT OUTER JOIN TCD.EcolabSaturation ES1 ON ES1.EcolabSaturationId=PM.EcolabSaturationId
    WHERE isNull(ms.IsPony,0) = 0  
    AND   
       CASE @StartDate                                                                                  
       WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                  
       ELSE CASE WHEN PS.[StartDateTime] >= @startdate AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                          
       END='TRUE'  
  
     AND  
       CASE @MachineType     
       WHEN '' THEN 'TRUE'           
       ELSE                                                        
       CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE        
       MS.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable))) THEN 'TRUE' END                                                        
       END='TRUE'       
     AND         
  
  CASE @machineGroup     
  WHEN '' THEN 'TRUE'           
  ELSE                                                        
  CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE        
  MS.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable)) THEN 'TRUE' END                                                        
  END='TRUE'   
  AND  
  
  CASE @Machine     
  WHEN '' THEN 'TRUE'           
  ELSE                                                        
  CASE WHEN SPD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                   
  END='TRUE'   
  AND  
      
  CASE @EcolabCategory     
  WHEN '' THEN 'TRUE'           
  ELSE                                                        
  CASE WHEN SPD.EcolabTextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                        
  END='TRUE'   
  AND  
      
  CASE @ChainCategory     
  WHEN '' THEN 'TRUE'           
  ELSE                                                        
  CASE WHEN SPD.ChainTextileId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END                                                        
  END='TRUE'  
  AND  
  
  CASE @PlantFormula     
  WHEN '' THEN 'TRUE'           
  ELSE                                                        
  CASE WHEN SPD.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                        
  END='TRUE'    
  AND  
      
  CASE @ChainFormula     
  WHEN '' THEN 'TRUE'           
  ELSE                                                        
  CASE WHEN SPD.ProgramMasterId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END                                                      
  END='TRUE'  
  AND  
      
  CASE @Customer     
  WHEN '' THEN 'TRUE'           
   ELSE                                                        
   CASE WHEN SPD.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                        
  END='TRUE'   
 --Added by Kiran 
    AND 
  CASE @FormulaSegement                                                                                
  WHEN '' THEN  'TRUE'
  ELSE
   CASE WHEN SPD.ChainProgaramId  IS NOT NULL THEN
    CASE WHEN ChainPlant.FormulaSegmentId IN (SELECT FormulaSegment FROM @FormulaSegmentTable) THEN 'TRUE' END                                                                                     
   ELSE 
    CASE WHEN FS1.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)  THEN 'TRUE'END   
   END                                                     
  END='TRUE'
 ---------------------------------------------------
 DECLARE @ProductionSummaryTable1 TABLE(  
		[ShiftId] [int] NULL,  
		[ShiftName] Varchar(100) NULL,  
		RecordDate date,   
		[StartDateTime] [datetime] NULL,  
		[EndDateTime] [datetime] NULL,  
		[MachineId] [int] NULL,  
		[EcolabWasherId] [int] NULL,  
		[ActualProduction] [int] NULL,  
		[StandardProduction] [int] NULL,  
		[NoOfLoads] [int] NULL,  
		[LoadEfficiency] [decimal](18, 2) NULL,  
		[TimeEfficiency] [decimal](18, 2) NULL,  
		TotalEfficiency [decimal](18, 2) NULL,  
		[PlantTargetProd] [int] NULL,  
		[ActualRunTime] [int] NULL,  
		[TargetRunTime] [int] NULL,  
		[ShiftRunTime] Decimal(30,10)  NULL,  
		RowNumberID INT NULL,  
		ProgramMasterID INT NULL,
		EcolabTextileId int,
		ChainTextileId int,
		ChainProgaramId int,
		FormulaSegmentID INT,
		CustomerId int,
		IndividualShiftRunTime Decimal(30,10) 
             )  
 INSERT INTO @ProductionSummaryTable1  
 (  
 [ShiftId] ,[ShiftName] ,RecordDate, [StartDateTime] ,[EndDateTime] ,[MachineId]  ,[EcolabWasherId]  ,  
 [ActualProduction] ,[StandardProduction] ,[NoOfLoads] ,[LoadEfficiency],[TimeEfficiency] ,TotalEfficiency ,  
 [PlantTargetProd],[ActualRunTime] ,[TargetRunTime] ,[ShiftRunTime] ,RowNumberID ,ProgramMasterID,
 EcolabTextileId,ChainTextileId,ChainProgaramId,FormulaSegmentID,CustomerId
 )  
 SELECT   
 SPD.[ShiftId],  
 PS.ShiftName,  
 CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date),  
 DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]),  
 DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[EndDateTime]),          
 SPD.[MachineId],  
 SPD.[EcolabWasherId],  
 SPD.[ActualProduction],  
 SPD.StandardProduction,  
 SPD.[NoOfLoads],  
 SPD.[LoadEfficiency],  
 SPD.[TimeEfficiency],  
 (SPD.[LoadEfficiency] * SPD.TimeEfficiency),  
 SPD.[PlantTargetProd],  
 SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0),  
 SPD.[TargetRunTime] + ISNULL(SPD.TargetTurnTime,0),  
 DATEDIFF(Second,ps.StartDateTime,PS.EndDateTime) +  
 ISNULL(  
 (  
 SELECT  
 SUM(SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0))  
  FROM TCD.ShiftProductionDataRollup SPD   
 INNER JOIN TCD.ProductionShiftData PSD ON SPD.ShiftId = PSD.ShiftId  
 INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId   
 WHERE   
 PSD.[StartDateTime] = PS.StartDateTime AND PSD.[StartDateTime] = PS.EndDateTime AND PS.ShiftName = 'No Shift'  
 ),0),  
 ROW_NUMBER() OVER(Partition BY SPD.ProgramMasterId, SPD.[EcolabWasherId], CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date)  
 ORDER BY SPD.ProgramMasterId, SPD.[EcolabWasherId] ),  
 SPD.ProgramMasterId,
 SPD.EcolabTextileId,SPD.ChainTextileId,SPD.ChainProgaramId,
    CASE WHEN SPD.ChainProgaramId IS NOT NULL THEN ChainPlant.FormulaSegmentId
 ELSE FS1.FormulaSegmentID END AS Formulasegment,
 SPD.CustomerId
      
 FROM TCD.ShiftProductionDataRollup SPD   
 INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId  
 INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
 INNER JOIN TCD.MachineSetup ms ON SPD.MachineId = ms.WasherId  
 LEFT OUTER JOIN
   (
   --IF Chain Plant
   SELECT PCP.PlantProgramId,PCP.PlantChainId,PCP.ChainTextileCategoryId,PCP.EcolabTextileCategoryId,
   PCP.FormulaSegmentId,PCP.EcolabSaturationId
   FROM TCD.PlantChainProgram PCP 
   LEFT OUTER JOIN TCD.ChainTextileCategory CTC ON CTC.TextileId=PCP.ChainTextileCategoryId
   LEFT OUTER JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId=PCP.EcolabTextileCategoryId
   LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=PCP.FormulaSegmentId
   LEFT OUTER JOIN TCD.EcolabSaturation ES ON ES.EcolabSaturationId=PCP.EcolabSaturationId
   )ChainPlant ON SPD.ChainProgaramId=ChainPlant.PlantProgramId

 LEFT OUTER JOIN TCD.EcolabTextileCategory ETC1 ON ETC1.TextileId=PM.EcolabTextileCategoryId
 LEFT OUTER JOIN TCD.FormulaSegments FS1 ON FS1.FormulaSegmentID=PM.FormulaSegmentId
 LEFT OUTER JOIN TCD.EcolabSaturation ES1 ON ES1.EcolabSaturationId=PM.EcolabSaturationId
    WHERE isNull(ms.IsPony,0) = 0  
    AND   
       CASE @StartDate                                                                                  
       WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                  
       ELSE CASE WHEN PS.[StartDateTime] >= @startdate AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                          
       END='TRUE'    
     
 -----------------------------------------------
  
 --Updating Actual Production based Manual Production  
 UPDATE S SET ActualProduction=ISNULL(S.ActualProduction,0)+ISNULL(MIP.ManualIPActualWeight,0),S.NoOfLoads=ISNULL(S.NoOfLoads,0)+ISNULL(MIP.NoofLoads,0)  
 FROM  @ProductionSummaryTable S  
 INNER JOIN   
  (  
  SELECT WasherId,FormulaId,CONVERT(DATE,RecordedDate) AS LoadDate,SUM(Value) AS ManualIPActualWeight,  
  COUNT(CONVERT(DATE,RecordedDate)) AS NoofLoads FROM  
  TCD.ManualProduction MP  
  GROUP BY WasherId,FormulaId,CONVERT(DATE,RecordedDate)  
  )MIP ON MIP.WasherId=S.MachineId AND MIP.FormulaId=S.ProgramMasterId AND MIP.LoadDate=S.RecordDate  
  WHERE S.RowNumberID=1  

 /*
  --Finding Max shift runtime for Particula shift
  UPDATE S SET S.IndividualShiftRunTime=MIP.MaxShiftruntime,S.ShiftRunTime=MIP.MaxShiftruntime
	 FROM  @ProductionSummaryTable S  
	 INNER JOIN   
	  (  
		 SELECT ShiftId,MAX(ShiftRunTime) AS MaxShiftruntime FROM @ProductionSummaryTable	 
		 GROUP BY ShiftID 
	  )MIP ON MIP.ShiftId=S.ShiftId	 

	 --Dividing Maxshift time for all the shift based records
	 UPDATE S SET S.IndividualShiftRunTime=(S.IndividualShiftRunTime/PS.noofShifts),S.ShiftRunTime=(S.ShiftRunTime/PS.noofShifts)
	 FROM  @ProductionSummaryTable S  
	 INNER JOIN   
  		 (	 
			SELECT PS1.ShiftID,Count(PS1.ShiftID)AS noofShifts 
			FROM  TCD.ShiftProductionDataRollup SPD   
			INNER JOIN TCD.ProductionShiftData PS1 ON SPD.ShiftId = PS1.ShiftId  
			INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId AND PS1.EcolabAccountNumber=PM.EcolabAccountNumber  
			INNER JOIN TCD.MachineSetup ms ON SPD.MachineId = ms.WasherId	
			WHERE isNull(ms.IsPony,0) = 0 AND PM.EcolabAccountNumber=@EcolabAccountNumber
			GROUP BY PS1.shiftID			 
		  ) PS  
		 ON PS.ShiftId=S.ShiftId 

	*/
  --SELECT Distinct Month(RecordDate) FROM @ProductionSummaryTable WHere Year(RecordDate)=2014 --AND ActualProduction>0
  --GROUP BY Year(RecordDate)

	DECLARE @TableShiftruntime TABLE(ShiftID INT ,ShiftRuntime Decimal(20,10),ID INT,Name VARCHAR(1000))

    IF(@Viewtype = 1)  
    BEGIN  
        ---- By TimeLine - Day View-------------  
		IF(@Subview = 5)  
		BEGIN  
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			SPD.ShiftName  
			FROM @ProductionSummaryTable1 SPD ;

			INSERT INTO @resultSet  
			SELECT   
			0,  
			SPD.ShiftName,  
			SUM(SPD.ActualProduction),  
			COALESCE(SUM(SPD.ActualProduction)/   
			NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),  
			SUM(DISTINCT SPD.PlantTargetProd),  
			SUM([NoOfLoads]),  
			SUM( SPD.ShiftRunTime),  
			SUM( SPD.ShiftRunTime)  
			,@Viewtype   
			,@Subview  
			,0  
			FROM @ProductionSummaryTable SPD  
			GROUP BY   
			SPD.ShiftName ;
			
			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name	 
	    END  
  
		---- By TimeLine - Week View  
		IF (@Subview = 4)  
		BEGIN  
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			CAST(RecordDate AS nvarchar(100))  
			FROM @ProductionSummaryTable1 SPD ;
			
			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime)  
			AS  
			(  
				SELECT   
				CAST(RecordDate AS nvarchar(100)),  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/   
				NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime)  
				FROM @ProductionSummaryTable SPD  
				GROUP BY DATEPART(weekday,RecordDate),RecordDate,SPD.ShiftId    
			)  
  
			INSERT INTO @resultSet  
			SELECT    
			0,   
			DateRange,  
			SUM(TotalLoad),  
			SUM(TotalEfficiency),  
			SUM(PlantTargetLoad),  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime)  
			,@Viewtype   
			,@Subview  
			,0  
			FROM CTE   
			WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange; 
			
			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name;
			 
		END  
  
        ---- By TimeLine - Month View  
		IF(@Subview = 3)  
		BEGIN  
			DECLARE @FirstDay date = (SELECT TOP 1 RecordDate FROM @ProductionSummaryTable ORDER BY RecordDate)  
			DECLARE @LastDay date = (SELECT TOP 1 RecordDate FROM @ProductionSummaryTable ORDER BY RecordDate DESC)  
			DECLARE @FirstSunday date = NULL,@LastSaturday date = NULL    
      
		   SELECT   
		   @FirstSunday = CAST(DateAdd(dd, (8-DatePart(WEEKDAY,   
			  DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)))%7,   
			  DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)) AS DATE)   
  
			SELECT  
			 @LastSaturday =   
			DATEADD(dd,  
			 -DATEPART(WEEKDAY,  
			   DATEADD(dd, -DAY(DATEADD(month, 1, @LastDay)),  
			   DATEADD(month, 1, @LastDay))) ,  
			 DATEADD(dd, -DAY(DATEADD(MONTH, 1, @LastDay)), DATEADD(MONTH, 1, @LastDay)));  

			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT SPD.ShiftId,SPD.ShiftRunTime AS ShiftRuntime,
				CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,-1,@FirstSunday)) = 7   
				AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate < DATEADD(DD,-1,@FirstSunday)) = 0)  
				THEN CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100))  
				WHEN DATEADD(DD,-1,@FirstSunday) > CAST(GETDATE() AS DATE)   
				THEN  
				CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @enddate, 101) AS nvarchar(100))  
				ELSE  
				CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) END As DateRange 
				FROM @ProductionSummaryTable1 SPD WHERE RecordDate < @FirstSunday AND RecordDate >= @FirstDay
			 
			UNION ALL
		  
			SELECT DISTINCT SPD.ShiftId,SPD.ShiftRunTime AS ShiftRuntime,
				CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100))  + CHAR(13) + '-' +  
				CASE WHEN CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 121) AS nvarchar(100)) >  
				CAST(Convert(varchar, DateAdd(dd, (1 - DatePart(dw, @enddate) + 1), @enddate), 121) AS nvarchar(100))  
				THEN  CAST(Convert(varchar, DateAdd(dd, 1-1, @enddate), 101) AS nvarchar(100))  
				ELSE CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) END
				FROM @ProductionSummaryTable1 SPD  
				WHERE RecordDate BETWEEN @FirstSunday AND @LastSaturday

			UNION ALL

			SELECT DISTINCT SPD.ShiftId,SPD.ShiftRunTime AS ShiftRuntime,
				CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,1,@LastSaturday)) = 1   
				AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate > DATEADD(DD,1,@LastSaturday)) = 0)  
				THEN   
				CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100))   
				ELSE  
				CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @LastDay, 101) AS nvarchar(100)) END
				FROM @ProductionSummaryTable1 SPD  
				WHERE RecordDate > @LastSaturday AND RecordDate <= @LastDay;


			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime)  
			AS  
			(  
			   SELECT          
					CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,-1,@FirstSunday)) = 7   
					AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate < DATEADD(DD,-1,@FirstSunday)) = 0)  
					THEN CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100))  
					WHEN DATEADD(DD,-1,@FirstSunday) > CAST(GETDATE() AS DATE)   
					THEN  
					CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @enddate, 101) AS nvarchar(100))  
					ELSE  
					CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) END As DateRange,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/   
				NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime)  
				FROM @ProductionSummaryTable SPD  
				WHERE RecordDate < @FirstSunday AND RecordDate >= @FirstDay   
				GROUP BY SPD.ShiftId   
          
				UNION ALL    
    
				SELECT  			 
					CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100))  + CHAR(13) + '-' +  
					CASE WHEN CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 121) AS nvarchar(100)) >  
					CAST(Convert(varchar, DateAdd(dd, (1 - DatePart(dw, @enddate) + 1), @enddate), 121) AS nvarchar(100))  
					THEN  CAST(Convert(varchar, DateAdd(dd, 1-1, @enddate), 101) AS nvarchar(100))  
					ELSE CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) END  
					As DateRange,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/   
				NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime)  
				FROM @ProductionSummaryTable SPD  
				WHERE RecordDate BETWEEN @FirstSunday AND @LastSaturday  
				GROUP BY Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101),  
				Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101),
				Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 121),
				SPD.ShiftId  
         
				UNION ALL  
  
				SELECT         
					CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,1,@LastSaturday)) = 1   
					AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate > DATEADD(DD,1,@LastSaturday)) = 0)  
					THEN   
					CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100))   
					ELSE  
					  CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @LastDay, 101) AS nvarchar(100)) END   As DateRange,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/   
				NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime)  
				FROM @ProductionSummaryTable SPD  
				WHERE RecordDate > @LastSaturday AND RecordDate <= @LastDay GROUP BY SPD.ShiftId  
				)  
				INSERT INTO @resultSet  
				 SELECT    
				 0,   
				 DateRange,  
				 SUM(TotalLoad),  
				 SUM(TotalEfficiency),  
				 SUM(PlantTargetLoad),  
				 SUM(Numberofbatches),  
				 SUM(ActualRunTime),  
				 SUM(TargetRuntime)  
				 ,@Viewtype   
				 ,@Subview  
				  ,0  
				 FROM CTE   
				 WHERE TotalLoad IS NOT NULL  
				GROUP BY DateRange; 
			
			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name 
  
		END  
  
		IF(@Subview = 2)  
		BEGIN  
			DECLARE @QuarterYear VARCHAR(100) = YEAR(@enddate);  

			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			DATENAME(MONTH, RecordDate) + ' ' +CAST( YEAR(RecordDate) as varchar)  
			FROM @ProductionSummaryTable1 SPD;

			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime)  
			AS  
			(  
				SELECT          
				DATENAME(MONTH, RecordDate) + ' ' + CAST( YEAR(RecordDate) as varchar)  As DateRange,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/   
				NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime)  
				FROM @ProductionSummaryTable SPD  
				GROUP BY  DATEPART(MONTH, RecordDate),DATENAME(MONTH, RecordDate),SPD.ShiftId , YEAR(RecordDate) 
			)  
			INSERT INTO @resultSet  
			SELECT    
			0,   
			DateRange,  
			SUM(TotalLoad),  
			SUM(TotalEfficiency),  
			SUM(PlantTargetLoad),  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime)  
			,@Viewtype   
			,@Subview  
			,0  
			FROM CTE   
			WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange;  
			
			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name;

		END 
     
		IF(@Subview = 1)  
		BEGIN  
			DECLARE @Year VARCHAR(100) = RIGHT(YEAR(@enddate),2);  

			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name,ID)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			CASE 'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10))  
				WHEN 'Q1' THEN 'Jan' + RIGHT(YEAR(RecordDate),2)  + '- Mar' + RIGHT(YEAR(RecordDate),2)   
				WHEN 'Q2' THEN 'Apr' + RIGHT(YEAR(RecordDate),2)  + '- Jun' + RIGHT(YEAR(RecordDate),2)   
				WHEN 'Q3' THEN 'Jul' + RIGHT(YEAR(RecordDate),2)  + '-Sep' + RIGHT(YEAR(RecordDate),2)   
				WHEN 'Q4' THEN 'Oct' + RIGHT(YEAR(RecordDate),2)  + '- Dec'+ RIGHT(YEAR(RecordDate),2)   
				END, 
			cast( cast(RIGHT(YEAR(RecordDate),2) AS varchar ) +cast(  DATEPART(QUARTER, RecordDate) AS varchar) AS int)
			FROM @ProductionSummaryTable1 SPD ;

			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,RowNo)  
			AS  
			(  
				SELECT   
					CASE 'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10))  
					WHEN 'Q1' THEN 'Jan' + RIGHT(YEAR(RecordDate),2)  + '- Mar' + RIGHT(YEAR(RecordDate),2)  
					WHEN 'Q2' THEN 'Apr' + RIGHT(YEAR(RecordDate),2) + '- Jun' + RIGHT(YEAR(RecordDate),2)  
					WHEN 'Q3' THEN 'Jul' + RIGHT(YEAR(RecordDate),2) + '-Sep' + RIGHT(YEAR(RecordDate),2)  
					WHEN 'Q4' THEN 'Oct' + RIGHT(YEAR(RecordDate),2) + '- Dec'+ RIGHT(YEAR(RecordDate),2)   
				END AS DateRange,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/   
				NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime)  ,
				cast( cast(RIGHT(YEAR(RecordDate),2) AS varchar ) +cast(  DATEPART(QUARTER, RecordDate) AS varchar) AS int)  RowNo
				FROM @ProductionSummaryTable SPD  
				GROUP BY DATEPART(QUARTER, RecordDate),SPD.ShiftId,RIGHT(YEAR(RecordDate),2)
			)  
  
		   INSERT INTO @resultSet  
		   SELECT    
				0,   
				DateRange,  
				SUM(TotalLoad),  
				SUM(TotalEfficiency),  
				SUM(PlantTargetLoad),  
				SUM(Numberofbatches),  
				SUM(ActualRunTime),  
				SUM(TargetRuntime)  
				,@Viewtype   
				,@Subview  
				,0  
				FROM CTE   
			 WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange  ,RowNo
			ORDER BY RowNo;

			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name;
		END  
    END  
      
    -- ******************************** Location View ***************************************************  
    IF(@Viewtype = 2)  
    BEGIN    
		IF(@Subview = 9)  
		BEGIN  			
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,ID)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			WG.WasherGroupId  
			FROM @ProductionSummaryTable1 SPD 
			LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId  
			LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId ;

			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,WasherGroupId)  
			AS  
			(  
				SELECT    
				--SPD.MachineId,      
				WG.WasherGroupName,  
				SUM(SPD.ActualProduction),  
				CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/   
				NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) *   
				COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime),  
				WG.WasherGroupId  
				FROM @ProductionSummaryTable SPD LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId  
				LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId   
				GROUP BY WG.WasherGroupName,WG.WasherGroupId,SPD.ShiftId--,SPD.MachineId  
			)  
  
			INSERT INTO @resultSet  
			SELECT    
			0,   
			DateRange,  
			SUM(TotalLoad),  
			SUM(TotalEfficiency),  
			@PlantTargetProduction,  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime)  
			,@Viewtype   
			,@Subview  
			,WasherGroupId  
			FROM CTE   
			WHERE TotalLoad IS NOT NULL         
			GROUP BY DateRange,WasherGroupId ; 
			
			WITH CTE1
			AS
			(
				SELECT SUM(ShiftRuntime) AS Shiftruntime,ID FROM @TableShiftruntime
				GROUP BY ID
			)

			--Update Shiftruntime in Temp table
			UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
			FROM @resultSet  RS
			LEFT OUTER JOIN 
			CTE1 TS ON RS.Id=TS.ID;
		
		END  
  
		IF(@Subview = 10)  
		BEGIN  
			
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  SPD.ShiftId,SPD.ShiftRunTime AS ShiftRuntime,         
			cast( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName MachineName
			FROM @ProductionSummaryTable1 SPD   
			LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId  
			LEFT JOIN TCD.Washer w on MS.WasherId=w.WasherId  
			LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId;   
			--WHERE   
			--	(  
			--	CASE @drillvalue     
			--	WHEN '' THEN 'TRUE'           
			--	ELSE                                                      
			--	CASE WHEN WG.WasherGroupId IN (@drillvalue) THEN 'TRUE' END              
			--	END='TRUE'  
			--	) ;    

			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime)  
		    AS  
		    (  
				SELECT           
				cast( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName as MachineName,  
				SUM(SPD.ActualProduction),  
				CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/   
				NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) *   
				COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime)          
				FROM @ProductionSummaryTable SPD   
				LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId  
				LEFT JOIN TCD.Washer w on MS.WasherId=w.WasherId  
				LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId   
				WHERE   
				(  
				CASE @drillvalue     
				WHEN '' THEN 'TRUE'           
				ELSE                                                      
				CASE WHEN WG.WasherGroupId IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				)  
				GROUP BY cast( W.PlantWasherNumber as varchar(20))+':'+MS.MachineName,SPD.ShiftId             
		   )    
			INSERT INTO @resultSet  
			SELECT   
			0,   
			DateRange,  
			SUM(TotalLoad),  
			SUM(TotalEfficiency),  
			@PlantTargetProduction,  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime)  
			,@Viewtype   
			,@Subview  
			,0  
			FROM CTE   
			WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange ; 
			
			WITH CTE1
			AS
			(
				SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
				GROUP BY Name 
			)				
			--Update Shiftruntime in Temp table
			UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
			FROM @resultSet  RS
			LEFT OUTER JOIN 
			CTE1 TS ON RS.DateRange=TS.Name;
		END  
  	END  
  --******************************** Formula View ****************************************************
	IF(@Viewtype = 7)
	BEGIN
		WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,WasherGroupId)
		AS
		(
		SELECT          
		PM.Name,
		SUM(SPD.ActualProduction),
		CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
		NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
		COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
		SUM(DISTINCT SPD.PlantTargetProd),
		SUM([NoOfLoads]),
		SUM( SPD.ShiftRunTime),
		SUM( SPD.ShiftRunTime),
		PM.ProgramId
		FROM @ProductionSummaryTable SPD
		INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
		Group by PM.Name,PM.ProgramId
		)
		INSERT INTO @resultSet
		SELECT  
			0, 
			DateRange,
			SUM(TotalLoad),
			SUM(TotalEfficiency),
			@PlantTargetProduction,
			SUM(Numberofbatches),
			SUM(ActualRunTime),
			SUM(TargetRuntime)
			,@Viewtype 
			,@Subview
			,WasherGroupId
		FROM CTE 
		WHERE TotalLoad IS NOT NULL       
		GROUP BY DateRange,WasherGroupId
	END

-- ******************************** Formula segmentView ****************************************************
	IF(@Viewtype = 8)
	BEGIN
		IF(@Subview =20)-- Formula Segment
		BEGIN 
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			FS.SegmentName    
			FROM @ProductionSummaryTable1 SPD
			INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
			INNER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=SPD.FormulaSegmentID ;

			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,FormulaSegmentID)
			AS
			(
			   SELECT          
			   FS.SegmentName,
			   SUM(SPD.ActualProduction),
			   CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
			   NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
			   COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
			   SUM(DISTINCT SPD.PlantTargetProd),
			   SUM([NoOfLoads]),
			   SUM( SPD.ShiftRunTime),
			   SUM( SPD.ShiftRunTime),
			   SPD.FormulaSegmentID
			   FROM @ProductionSummaryTable SPD
			   INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
			   LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=SPD.FormulaSegmentID
			   Group by SPD.FormulaSegmentID,FS.SegmentName   
			)
				INSERT INTO @resultSet
				SELECT  
				0, 
				DateRange,
				SUM(TotalLoad),
				SUM(TotalEfficiency),
				@PlantTargetProduction,
				SUM(Numberofbatches),
				SUM(ActualRunTime),
				SUM(TargetRuntime)
				,@Viewtype 
				,@Subview
				,FormulaSegmentID
				FROM CTE 
				WHERE TotalLoad IS NOT NULL       
				GROUP BY DateRange,FormulaSegmentID;

			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name	;
		END
		
		IF(@Subview =21)-- Formula Categories
		BEGIN 
		 
		   INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT SPD.ShiftId,SPD.ShiftRunTime AS ShiftRuntime, EC.CategoryName    
				FROM @ProductionSummaryTable1 SPD
				INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
				--WHERE  
				--	(  
				--	CASE      
				--	WHEN @drillvalue='' THEN 'TRUE'   
				--	WHEN @drillvalue IS NULL THEN 'TRUE'    
				--	ELSE                                                      
				--	CASE WHEN SPD.FormulaSegmentID IN (@drillvalue) THEN 'TRUE' END              
				--	END='TRUE'  
				--	) AND EC.CategoryName IS NOT NULL
			UNION 

			SELECT DISTINCT SPD.ShiftId,SPD.ShiftRunTime AS ShiftRuntime, CC.NAME   
			FROM @ProductionSummaryTable1 SPD
			INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
			INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = SPD.ChainProgaramId  
			INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId
				--WHERE  
				--(  
				--CASE      
				--WHEN @drillvalue='' THEN 'TRUE'   
				--WHEN @drillvalue IS NULL THEN 'TRUE'    
				--ELSE                                                      
				--CASE WHEN SPD.FormulaSegmentID IN (@drillvalue) THEN 'TRUE' END              
				--END='TRUE'  
				--) 
				;
		   	
		   WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,TextileId)
		   AS
		   (
			SELECT EC.CategoryName,SUM(SPD.ActualProduction),
			CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
			NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
			COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
			SUM(DISTINCT SPD.PlantTargetProd),SUM([NoOfLoads]),SUM( SPD.ShiftRunTime),
			SUM( SPD.ShiftRunTime),EC.TextileId
			FROM @ProductionSummaryTable SPD
			LEFT JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
			WHERE  
				(  
				CASE      
				WHEN @drillvalue='' THEN 'TRUE'   
				WHEN @drillvalue IS NULL THEN 'TRUE'    
				ELSE                                                      
				CASE WHEN SPD.FormulaSegmentID IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				) AND EC.CategoryName IS NOT NULL  
				GROUP BY EC.CategoryName,EC.TextileId,SPD.ShiftId 
    
			UNION

			SELECT CC.Name,SUM(SPD.ActualProduction),
			CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
			NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
			COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
			SUM(DISTINCT SPD.PlantTargetProd),SUM([NoOfLoads]),SUM( SPD.ShiftRunTime),
			SUM( SPD.ShiftRunTime),CC.TextileId
			FROM @ProductionSummaryTable SPD
			INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
			INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = SPD.ChainProgaramId
			INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId 
			WHERE  
				(  
				CASE      
				WHEN @drillvalue='' THEN 'TRUE'   
				WHEN @drillvalue IS NULL THEN 'TRUE'    
				ELSE                                                      
				CASE WHEN SPD.FormulaSegmentID IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				)   
				Group by CC.Name,cc.TextileId,SPD.ShiftId  
  
		   )
			INSERT INTO @resultSet
			SELECT         
			0, 
			DateRange,  
			SUM(TotalLoad),
			SUM(TotalEfficiency),
			@PlantTargetProduction,
			SUM(Numberofbatches),
			SUM(ActualRunTime),
			SUM(TargetRuntime)
			,@Viewtype 
			,@Subview
			,TextileId
			FROM CTE 
			WHERE TotalLoad IS NOT NULL       
			GROUP BY DateRange,TextileId;

           WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name
							   
	    END
  
		IF(@Subview=22) --Formula
		BEGIN
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			PM.Name    
			FROM @ProductionSummaryTable1 SPD
			INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId  
				INNER JOIN TCD.ProgramMaster PM ON --EC.TextileId = PM.EcolabTextileCategoryId AND 
				SPD.ProgramMasterId = PM.ProgramId    
	
				--WHERE  
				--(  
				--CASE      
				--WHEN @drillvalue='' THEN 'TRUE'   
				--WHEN @drillvalue IS NULL THEN 'TRUE'    
				--ELSE                                                      
				--CASE WHEN EC.TextileId IN (@drillvalue) THEN 'TRUE' END              
				--END='TRUE'  
				--) AND PM.NAME IS NOT NULL
			
			UNION

			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			PM.Name    
			FROM @ProductionSummaryTable1 SPD
			INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId  
				INNER JOIN TCD.ProgramMaster PM ON  SPD.ProgramMasterId = PM.ProgramId    
				--WHERE  
				--(  
				--CASE      
				--WHEN @drillvalue='' THEN 'TRUE'   
				--WHEN @drillvalue IS NULL THEN 'TRUE'    
				--ELSE                                                      
				--CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END              
				--END='TRUE' 
				--)
				 ;

			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,WasherGroupId)
			AS
			(
				SELECT PM.Name,SUM(SPD.ActualProduction),
				CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
				NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
				COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
				SUM( SPD.PlantTargetProd),SUM([NoOfLoads]),SUM( SPD.ShiftRunTime),
				SUM( SPD.ShiftRunTime),PM.ProgramId
				FROM @ProductionSummaryTable SPD
				INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
				INNER JOIN TCD.ProgramMaster PM ON --EC.TextileId = PM.EcolabTextileCategoryId AND 
				SPD.ProgramMasterId = PM.ProgramId    
				WHERE
				 (
				 CASE    
				  WHEN @drillvalue='' THEN 'TRUE' 
				  WHEN @drillvalue IS NULL THEN 'TRUE'  
				  ELSE                                                    
				  CASE WHEN EC.TextileId IN (@drillvalue) THEN 'TRUE' END            
				  END='TRUE'
				 ) AND PM.NAME IS NOT NULL
				GROUP BY PM.Name,PM.ProgramId --,SPD.ShiftId 
    
			UNION

				SELECT PM.Name,SUM(SPD.ActualProduction),
				CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
				NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
				COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
				SUM(DISTINCT SPD.PlantTargetProd),SUM([NoOfLoads]),SUM( SPD.ShiftRunTime),
				SUM( SPD.ShiftRunTime),PM.ProgramId
				FROM @ProductionSummaryTable SPD 
				INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
				INNER JOIN TCD.ProgramMaster PM ON  SPD.ProgramMasterId = PM.ProgramId  
				WHERE
				 (
				  CASE    
				  WHEN @drillvalue='' THEN 'TRUE' 
				  WHEN @drillvalue IS NULL THEN 'TRUE'  
				  ELSE                                                    
				  CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END            
				  END='TRUE'
				 )
				GROUP BY PM.Name,PM.ProgramId--,SPD.ShiftId  
      
			)
			INSERT INTO @resultSet
			SELECT  
			0, 
			DateRange,
			SUM(TotalLoad),
			SUM(TotalEfficiency),
			@PlantTargetProduction,
			SUM(Numberofbatches),
			SUM(ActualRunTime),
			SUM(TargetRuntime)
			,@Viewtype 
			,@Subview
			,WasherGroupId
			FROM CTE 
			WHERE TotalLoad IS NOT NULL       
			GROUP BY DateRange,WasherGroupId;
			
			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name
END
	END

	DECLARE @MaxShiftruntime DECIMAL(30,10)=NULL
	IF(@Viewtype IN (2,8) ) --for Location and Formula, shift hours will be total shifthours for particular duration
	BEGIN
		
		 IF(@Subview=9)
		 BEGIN
			SELECT @MaxShiftruntime=MAX(A.Shiftruntime) FROM
			 (
				SELECT SUM(ShiftRuntime) AS Shiftruntime,ID FROM @TableShiftruntime
				GROUP BY ID
			)A
		 END
		 ELSE
		 BEGIN
			SELECT @MaxShiftruntime=MAX(A.Shiftruntime) FROM
			 (
				SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
				GROUP BY Name
			)A
		 END
		 UPDATE  @resultSet SET ActualRunTime=@MaxShiftruntime
	 END
	 ELSE IF(@Viewtype IN(1))
	 BEGIN
		SELECT @MaxShiftruntime= (SELECT SUM(ShiftRuntime) AS Shiftruntime FROM @TableShiftruntime)
	 END

      SELECT       
      DateRange,
      ISNULL([TCD].[FnConsumptionOnMetrics](TotalLoad,'Weight',@UserId),0),  
      --ISNULL(TotalLoad,0),  
      ISNULL([TCD].[FnConsumptionOnMetrics](WasherEfficiency,'Weight',@UserId),0),  
      --ISNULL(WasherEfficiency,0),  
      ISNULL([TCD].[FnConsumptionOnMetrics](PlantTargetLoad,'Weight',@UserId),0),  
      --ISNULL(PlantTargetLoad,0),  
      ISNULL(Numberofbatches,0),  
      ISNULL([ActualRunTime],0) [ActualRunTime],  
      ISNULL([TargetRunTime],0) [TargetRunTime],  
      Viewtype,  
      Subview,  
      Id,  
      ShiftId,  
      @CorrectionVariable,
	  @MaxShiftruntime AS Maxshiftruntime  
      FROM @resultSet   


	  
SET NOCOUNT OFF
END
GO

