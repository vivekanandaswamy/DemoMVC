
UPDATE TCD.UserMaster SET EcolabAccountNumber = N'P03810010' 
  
SET IDENTITY_INSERT [TCD].[UserMaster] ON
Begin
INSERT [TCD].[UserMaster] ([UserId], [FirstName], [LastName], [FullName], [LoginName], [Password], [Phone], [LanguageId], [UOMId], [Email], [IsActive], [LastLoggedIn], [LastModifiedByUserId], [EcolabAccountNumber], [Title], [Mobile], [Fax], [ContactId], [CurrencyCode], [LastModifiedTime], [LastSyncTime]) 
VALUES
 (1, N'Adminstrator', N'User', N'Adminstrator User', N'Admin', N'baloce', N'123456789', 1, 1, N'Admin@ecolab.com', 1, CAST(0x0000A3AB00263AAB AS DateTime), 0, N'P03810010', NULL, NULL, NULL, NULL, NULL, CAST(0x0000A50100A5390D AS DateTime), NULL);
End
SET IDENTITY_INSERT [TCD].[UserMaster] OFF
 
Begin
INSERT [TCD].[UserInRole] ([EcoLabAccountNumber], [UserId], [RoleId], [IsDeleted], [LastModifiedByUserId]) VALUES (N'P03810010', 1, 4, 0, 0);
End
 
Begin
INSERT [tcd].[UserProfile] ( [UserId], [EcolabAccountNumber],[LastModifiedByUserId])VALUES
( 1,'P03810010',1);
End
 
INSERT [TCD].[PlantChain] ([PlantChainId], [PlantChainName], [RegionId], [Is_Deleted], [MyServiceChnId], [MyServiceLastSynchTime]) 
VALUES (14, N'Training Laundry_10', 1, 0, NULL, CAST(0x0000A50000BFC630 AS DateTime))

INSERT [TCD].[Plant] ([PlantId], [EcolabAccountNumber], [Name], [DataLiveTime], [BudgetCustomer], [ExportPath], [LanguageId], [UOMId],
 [CurrencyCode], [PlantCategoryId], [AcutalIsTarget], [RegionId], [PlantChainId], [CreatedOn], [CreatedBy], [ModifiedOn], 
 [ModifiedBy], [TMName], [TMPhoneNumber], [DMName], [DMPhoneNumber], [ChainUnitNumber], [CensusPriceKg], [Remarks], [Rate], 
 [Is_Deleted], [Logo], [LastModifiedByUserId], [AllowManualRewash], [LastModifiedTime], [LastSyncTime], [DashboardSlideDuration],
 [MyServiceCustGuid], [MyServiceLastSynchTime], [PlantContractNumber], [LastArchiveDate], [ConStdTurnTime], [TimeZone],IsETechEnable) VALUES 

(39, N'P03810010', N'Training Laundry_10', 3, 0, N'C:\EcoLab\Envision\BACKUP', 1, 2, N'EUR', 0, 0, 2, 14, 
CAST(0x0000A50100A53903 AS DateTime), 0, CAST(0x0000A50100A53903 AS DateTime), N'0         ', 
N'ANDERSON, MARSHALL J', N'816-726-6665', N'PAVLATOS, JERRY', N'-   -', N'      182', CAST(1.5900 AS Numeric(12, 4)), 
NULL, 0, 0, NULL, 0, 0, CAST(0x0000A50100A53903 AS DateTime), NULL, NULL, N'd504c4c7-cfd8-4cb8-8555-897b58d20f7a', 
CAST(0x0000A50100A539C0 AS DateTime), N'04120', NULL, NULL, 2,0);

INSERT [TCD].[PlantCustAddress] ([EcolabAccountNumber], [BillingAddr1], [BillingAddr2], [City], [Country], [Zip], [ShippingAddr1], [ShippingAddr2], [Shippingcity], [Shippingcountry], [Shippingzip], [MyServiceLastSynchTime]) VALUES (N'P03810010', N'', N'', N'', N'Sweden', N'               ', N'685 OLIVE ST', N'', N'SAINT PAUL', N'Sweden', N'55130          ', CAST(0x0000A50100A539C1 AS DateTime));
 
 SET IDENTITY_INSERT TCD.ConduitController ON
    INSERT [TCD].[ConduitController] 
                (    [ControllerId]
                ,    [EcoalabAccountNumber]
                ,    [TopicName]
                ,    [ControllerNumber]
                ,    [ControllerModelId]
                ,    [ControllerTypeId]
                ,    [ControllerVersion]
                ,    [InstallDate]
                ,    [Description]
                ,    [Name]
                ,    [Active]
                ,    [IsDeleted]
                ,    [LastConnectedTime]
                ,    [LastModifiedByUserId]) 
    
    VALUES        (    0
                ,    'P03810010'
                ,    N'Default Controller For myService'
                ,    4001
                ,    1
                ,    1
                ,    NULL
                ,    NULL
                ,    N'Dober Ultrax System #3'
                ,    N'4001 (Ultrax 6/12/16- Allen Bradley)'
                ,    0
                ,    0
                ,    NULL
                ,    0
                )
    
    INSERT [TCD].[ControllerSetupData]
                 (    [ControllerId]
                 ,    [FieldGroupId]
                 ,    [FieldId]
                 ,    [Value]
                 ,    [FieldTagValue]
                 ,    [ControllerModelId]
                 ,    [LastModifiedByUserId]
                 ,    [EcolabAccountNumber]
                 )
    
    VALUES        (0    ,6    ,56    ,N'10'        ,NULL    ,1    ,0    ,'P03810010'),
                (0    ,6    ,57    ,N'10'        ,NULL    ,1    ,0    ,'P03810010'),
                (0    ,6    ,21    ,N'10'        ,NULL    ,1    ,0    ,'P03810010'),
                (0    ,6    ,58    ,N'10'        ,NULL    ,1    ,0    ,'P03810010'),
                (0    ,6    ,79    ,N'33'        ,NULL    ,1    ,0    ,'P03810010'),
                (0    ,6    ,33    ,N'false'    ,NULL    ,1    ,0    ,'P03810010')
    SET IDENTITY_INSERT TCD.ConduitController OFF

	UPDATE TCD.MachineGroup	SET EcolabAccountNumber = N'P03810010'



INSERT [TCD].[ChainTextileCategory] ([TextileId], [Name], [PlantChainId], [IsDeleted], [LastModifiedTime], [LastSyncTime], [ResourceKey]) VALUES (40, N'None', NULL, 0, CAST(0x0000A58D013A45E8 AS DateTime), CAST(0x0000A59300874D9B AS DateTime), NULL)
INSERT [TCD].[ChainTextileCategory] ([TextileId], [Name], [PlantChainId], [IsDeleted], [LastModifiedTime], [LastSyncTime], [ResourceKey]) VALUES (41, N'textilecategory1', 14, 0, CAST(0x0000A58D013A45E8 AS DateTime), CAST(0x0000A59300874D9B AS DateTime), NULL)
INSERT [TCD].[ChainTextileCategory] ([TextileId], [Name], [PlantChainId], [IsDeleted], [LastModifiedTime], [LastSyncTime], [ResourceKey]) VALUES (42, N'textilecategory2', 14, 0, CAST(0x0000A58D013A45E8 AS DateTime), CAST(0x0000A59300874D9C AS DateTime), NULL)
INSERT [TCD].[ChainTextileCategory] ([TextileId], [Name], [PlantChainId], [IsDeleted], [LastModifiedTime], [LastSyncTime], [ResourceKey]) VALUES (43, N'textilecategory3', 14, 0, CAST(0x0000A58D013A45E8 AS DateTime), CAST(0x0000A59300874D9D AS DateTime), NULL)
INSERT [TCD].[ChainTextileCategory] ([TextileId], [Name], [PlantChainId], [IsDeleted], [LastModifiedTime], [LastSyncTime], [ResourceKey]) VALUES (44, N'textilecategory4', 14, 0, CAST(0x0000A58D013A45E8 AS DateTime), CAST(0x0000A59300874D9D AS DateTime), NULL)
INSERT [TCD].[PlantChainProgram] ([PlantProgramId], [PlantProgramName], [PlantChainId], [ChainTextileCategoryId], [EcolabSaturationId], [EcolabTextileCategoryId], [FormulaSegmentId], [Is_Deleted], [LastModifiedTime], [LastModifiedByUserId]) VALUES (40, N'None', NULL, NULL, NULL, NULL, NULL, 0, CAST(0x0000A59200E54C84 AS DateTime), NULL)
INSERT [TCD].[PlantChainProgram] ([PlantProgramId], [PlantProgramName], [PlantChainId], [ChainTextileCategoryId], [EcolabSaturationId], [EcolabTextileCategoryId], [FormulaSegmentId], [Is_Deleted], [LastModifiedTime], [LastModifiedByUserId]) VALUES (41, N'ChainProgram1', 14, 41, 2, 3, 1, 0, CAST(0x0000A58D013A6EEC AS DateTime), 0)
INSERT [TCD].[PlantChainProgram] ([PlantProgramId], [PlantProgramName], [PlantChainId], [ChainTextileCategoryId], [EcolabSaturationId], [EcolabTextileCategoryId], [FormulaSegmentId], [Is_Deleted], [LastModifiedTime], [LastModifiedByUserId]) VALUES (42, N'ChainProgram2', 14, 43, 3, 1, 2, 0, CAST(0x0000A58D013A6EEC AS DateTime), 0)
INSERT [TCD].[PlantChainProgram] ([PlantProgramId], [PlantProgramName], [PlantChainId], [ChainTextileCategoryId], [EcolabSaturationId], [EcolabTextileCategoryId], [FormulaSegmentId], [Is_Deleted], [LastModifiedTime], [LastModifiedByUserId]) VALUES (43, N'ChainProgram3', 14, 42, 2, 4, 3, 0, CAST(0x0000A58D013A6EEC AS DateTime), 0)
INSERT [TCD].[PlantChainProgram] ([PlantProgramId], [PlantProgramName], [PlantChainId], [ChainTextileCategoryId], [EcolabSaturationId], [EcolabTextileCategoryId], [FormulaSegmentId], [Is_Deleted], [LastModifiedTime], [LastModifiedByUserId]) VALUES (44, N'ChainProgram4', 14, 44, 5, 2, 2, 0, CAST(0x0000A58D013A6EEC AS DateTime), 0)
GO

/*      
 ==========================================================================================      
 Purpose:  Fecthing the Chemical Names from product Master    
    
 Author:  Krishna Gangadhar Thota  
    
 --------------------------------------------------------------      
 Sep-04-2014 ENT: Initial version.      
 ==========================================================================================  
  [dbo].[usp_GetChemicalName],    
*/     
ALTER PROCEDURE [TCD].[GetChemicalName](@ChemName Varchar(1000),@EcolabAccountNumber Varchar(100))     
AS     
SET NOCOUNT ON    
  BEGIN     
  DECLARE @RegionId int
  DECLARE @Country VARCHAR(250)
  SELECT @RegionId = RegionID from [TCD].Plant WHERE EcolabAccountNumber = @EcolabAccountNumber
  SELECT @Country = ISNULL(NULLIF(PLA.Country, ''), PLA.Shippingcountry) FROM [TCD].Plant P JOIN [TCD].PlantCustAddress PLA ON P.EcolabAccountNumber = PLA.EcolabAccountNumber 
	   WHERE P.EcolabAccountNumber = @EcolabAccountNumber

 SELECT M.ProductId, RTRIM(Name) + ' ( ' + RTRIM(SKU) + ' )' as Name, 
 (CASE WHEN ISNULL( M.Cost,0)>0 then M.Cost 
		WHEN ISNULL(PSP.ListPrice,0)>0 THEN PSP.ListPrice
		WHEN ISNULL(PSP.ContractPrice,0)>0 THEN PSP.ContractPrice
		WHEN ISNULL(PSP.CountryPrice,0)>0 THEN PSP.CountryPrice
		ELSE M.Cost 
 END) Cost
 
 ,M.IncludeinCI
 FROM [TCD].ProductMaster M    
 LEFT JOIN TCD.ProductStandardPrice PSP on M.ProductId=PSP.ProductId and PSP.EcolabAccountNumber=@EcolabAccountNumber
 WHERE (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
 AND M.RegionId = @RegionId
 AND M.Country IS NOT NULL
 AND M.Is_Deleted =0
 AND NOT EXISTS (SELECT ProductId     
     FROM   [TCD].ProductdataMapping Map     
                 WHERE  M.ProductId = Map.ProductId AND Map.Is_Deleted=0)  
Order By M.Name     
  END
GO


INSERT INTO [TCD].ProductdataMapping (ProductID, SKU,Cost,LastModifiedByUserId) VALUES (793,'9040700', 5,1) 
INSERT INTO [TCD].ProductdataMapping (ProductID, SKU,Cost,LastModifiedByUserId) VALUES (7808,'9043090', 5,1) 
INSERT INTO [TCD].ProductdataMapping (ProductID, SKU,Cost,LastModifiedByUserId) VALUES (9824,'7145901', 5,1) 
INSERT INTO [TCD].ProductdataMapping (ProductID, SKU,Cost,LastModifiedByUserId) VALUES (9818,'18070', 5,1) 
INSERT INTO [TCD].ProductdataMapping (ProductID, SKU,Cost,LastModifiedByUserId) VALUES (221,'1014300', 5,1) 
INSERT INTO [TCD].ProductdataMapping (ProductID, SKU,Cost,LastModifiedByUserId) VALUES (9815,'7100751', 5,1) 
GO
UPDATE tcd.ProductdataMapping
SET EcolabAccountNumber = 'P03810010'
GO

DECLARE @EcolabAccountNumber nvarchar(50) = N'P03810010'
INSERT [TCD].[ProgramMaster] ([ProgramId], [Name], [ProgramTargetCost], [Pieces], [DepreciationCost], [TargetChemicalCost], [TargetWaterCost], [TargetEnergeyCost], [EcolabTextileCategoryId], [Rewash], [Weight], [EcolabSaturationId], [EcolabAccountNumber], [PlantProgramId], [ChainTextileId], [CustomerId], [FormulaSegmentId], [Is_Deleted], [LastModifiedByUserId], [LastModifiedTime], [LastSyncTime], [Weight_Display]) 
VALUES (1, N'ChainProgram1', NULL, 2, NULL, NULL, NULL, NULL, NULL, 0, 30.0, 3, @EcolabAccountNumber, 41, NULL, 0, 3, 0, 0, CAST(0x0000A667007873FA AS DateTime), NULL, NULL)
INSERT [TCD].[ProgramMaster] ([ProgramId], [Name], [ProgramTargetCost], [Pieces], [DepreciationCost], [TargetChemicalCost], [TargetWaterCost], [TargetEnergeyCost], [EcolabTextileCategoryId], [Rewash], [Weight], [EcolabSaturationId], [EcolabAccountNumber], [PlantProgramId], [ChainTextileId], [CustomerId], [FormulaSegmentId], [Is_Deleted], [LastModifiedByUserId], [LastModifiedTime], [LastSyncTime], [Weight_Display]) 
VALUES (2, N'ChainProgram2', NULL, 2, NULL, NULL, NULL, NULL, NULL, 0, 30.0, 3, @EcolabAccountNumber, 42, NULL, 0, 3, 0, 0, CAST(0x0000A667007873FA AS DateTime), NULL, NULL)
GO

   
