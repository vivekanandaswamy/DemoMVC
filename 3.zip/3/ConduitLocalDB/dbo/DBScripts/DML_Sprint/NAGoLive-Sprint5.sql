﻿IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlAnalogData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlAnalogData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE procedure TCD.ProcessMyControlAnalogData (@ControllerID INT, @VxML xML)
AS
BEGIN
	DECLARE @MachineID int,
			@Sensorid  int,
			@SensorTypeId int,
			@Temperature int,
			@PH int,
			@TimeStamp datetime,
			@Readings decimal(18, 4),
			@SensorType varchar(10)

-- Getting the current UTC time 
	 select @TimeStamp = GetUTCDate()

-- 1.Extracting xml data 
-- 2.And joining with sensor table
-- 3.Getting specific Sensor id by passing machine id and controller id and is_deleted(active sensor's)
-- 4.CTE will return table of columns i.e sensorid,sensortype,temparature,ph values

--Conventional washer sensor readings

	;with TempData as
	(
		SELECT s.SensorId,s.SensorType, T.c.value('@Temperature', 'INT') temparature,  T.c.value('@pH', 'INT') ph 
		FROM @VxML.nodes('MyControlAnalogData/WEAnalogData')  T(c) inner join  TCD.Sensor s
		on MachineCompartment= T.c.value('@WENumber', 'INT') and s.ControllerID=@controllerid and s.Is_deleted = 0
	) 

-- inserting records into sensor reading table using merge statement

	MERGE INTO tcd.sensorreading sr
	USING(select sensorid,sensortype, Case 
											WHEN SensorType = 1 THEN  Temparature		 --Temparature
											WHEN SensorType = 2 THEN  ph						 --PH
									 End reading
									from tempdata ) temp ON sr.sensorId = temp.sensorid and temp.reading = 
									(select top 1 reading from tcd.SensorReading where SensorId=temp.sensorid order by TimeStamp desc ) 

-- If records are not in the sensor reading tables
-- Sensor records are inserted depending on the sensor type	
	
	WHEN NOT MATCHED AND (temp.reading <> '' or temp.reading <> null or temp.reading <> 0)
	THEN 
		INSERT(sensorid,reading,timestamp)
		VALUES(temp.sensorid,temp.reading, @TimeStamp)
;
End

GO

--To add new column in batchdata 

IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'StdInjectionSteps' AND Object_ID = Object_ID(N'[TCD].[BatchData]'))
BEGIN
	ALTER TABLE TCD.BatchData ADD [StdInjectionSteps] INT NULL 
END

IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'StdWashSteps' AND Object_ID = Object_ID(N'[TCD].[BatchData]'))
BEGIN
	ALTER TABLE TCD.BatchData ADD [StdWashSteps] INT NULL 
END

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlConventionalData_Online]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlConventionalData_Online]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE TCD.ProcessMyControlConventionalData_Online
(
	@ControllerID	INT, 
	@VxML			XML, 
	@RedFlagShiftId INT OUTPUT
)
AS
BEGIN
   DECLARE 
			@MachineNumber				INT,
			@StepNumber					INT,
			@StartDateTime				DATETIME,
			@EndDateTime				DATETIME,
			@ProgramNumber				INT,
			@Load						DECIMAL(10,2),
			@NominalLoad				DECIMAL(10,2),
			@CustomerNumber				INT,
			@PHStatus					INT,
			@PHValue					INT,
			@TemperatureMin				INT,
			@TemperatureMax				INT,
			@TempMinStatus				INT,
			@TempMaxStatus				INT,
			@BatchNumber				INT,
		    @WasherID					INT,
			@WasherGroupID				INT,
			@EcoLabWasherID				INT,
			@ProgramMasterID			INT,
			@PlantWasherNumber			INT,
			@ShiftID					INT,
			@FrmParameterID				INT,
			@PHParameterID				INT,
			@PHParameterStatus			INT,
			@BatchID					INT,
			@ShiftStartdate				DATETIME,
			@ShiftName					NVARCHAR(50),
			@XMLDataID					INT,
			@TempParameter				INT,
			@TemperatureMinParam		INT,
			@TemperatureMaxParam		INT,
			@TempMinStatusParam			INT,
			@TempMaxStatusParam			INT,
			@WashStepNo					INT,
			@CurrencyCode				VARCHAR(50),
			@StdInjectionSteps			INT,
			@StdWashSteps				INT,
			@EcolabTextileCategoryId	INT,
			@ChainTextileCategoryId		INT,
			@FormulaSegmentId			INT,
			@EcolabSaturationId			INT,
			@PlantProgramId				INT,
			@TargetTurnTime				INT				
			
	SELECT @MachineNumber=T.c.value('@MachineNumber', 'INT'),
			@StepNumber=T.c.value('@StepNumber', 'INT'),
			@StartDateTime=T.c.value('@StartDateTime', 'DATETIME'),
			@EndDateTime=T.c.value('@EndDateTime', 'DATETIME'),
			@ProgramNumber=T.c.value('@ProgramNumber', 'INT'),
			@Load=T.c.value('@Load', 'Decimal(10,2)')/10,
			@NominalLoad=T.c.value('@NominalLoad', 'Decimal(10,2)'),
			@CustomerNumber=T.c.value('@CustomerNumber', 'INT'),
			@PHStatus=T.c.value('@PHStatus', 'INT'),
			@PHValue=T.c.value('@PHValue', 'INT'),
			@TemperatureMin=T.c.value('@TemperatureMin', 'INT'),
			@TemperatureMax=T.c.value('@TemperatureMax', 'INT'),
			@TempMaxStatus=T.c.value('@TemperatureMaxStatus', 'INT'),
			@TempMinStatus=T.c.value('@TemperatreMinStatus', 'INT'),
			@BatchNumber=T.c.value('@BatchNumber', 'INT')
	FROM @VxML.nodes('MyControlConventionalData') T(C)


	SELECT @PHParameterID=ID
	FROM TCD.ConduitParameters WHERE NAME ='pH'

	SELECT @PHParameterStatus=ID
	FROM TCD.ConduitParameters WHERE NAME ='PH Status'

	SELECT @TemperatureMinParam=ID
	FROM TCD.ConduitParameters WHERE NAME ='Mimum Temperature'

	SELECT @TemperatureMaxParam=ID
	FROM TCD.ConduitParameters WHERE NAME ='Maximum Temperature'

	SELECT @TempMinStatusParam=ID
	FROM TCD.ConduitParameters WHERE NAME ='Minimum Temperature Status'

	SELECT @TempMaxStatusParam=ID
	FROM TCD.ConduitParameters WHERE NAME ='Max Temperature Status'
	
	SELECT @WashStepNo=ID
	FROM TCD.ConduitParameters WHERE NAME ='StepCompartment No'

	SELECT @FrmParameterID = [Id]
	FROM TCD.ConduitPArameters WHERE Name='Formula Number'


	
	DECLARE @ShiftMapping1 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)

	INSERT INTO @ShiftMapping1(ShiftId,ShiftName,ShiftStartdate) 
	EXEC TCD.GetShiftStartDate @StartDateTime,1,@RedFlagShiftId OUTPUT

	SELECT @ShiftID = ShiftID, @ShiftStartdate=ShiftStartdate FROM @ShiftMapping1
						
	SELECT	@WasherGroupID=GroupId,@WasherID=WasherID FROM TCD.MachineSetup ms WHERE ControllerID = @ControllerID
																				 AND MachineInternalId= @MachineNumber
																				 AND IsTunnel =0
																				 AND IsDeleted=0

	IF(@EndDateTime = '1/1/1900') 
		SELECT @EndDateTime= null
		
	IF(@StartDateTime ='1/1/1900')
		SELECT @StartDateTime= null

	IF (@WasherId IS NOT NULL)
	BEGIN
	SELECT	@ProgramMasterId=Wps.ProgramId FROM TCD.Washer Ws
				INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
				INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
				INNER JOIN TCD.WasherProgramSetup Wps ON Wps.ControllerID = Wg.ControllerId
				INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.EcoLabAccountNumber
	WHERE Ws.WasherId=@WasherId
	  AND Wps.ProgramNumber=@ProgramNumber 
	  AND Wps.Is_Deleted=0

	  SELECT @EcoLabWasherID = EcolabWasherId,
			 @PlantWasherNumber = PlantWasherNumber,
			 @CurrencyCode = P.CurrencyCode,
			 @TargetTurnTime = w.TargetTurnTime * 60 
	  FROM TCD.Washer w 
		INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber=p.EcolabAccountNumber WHERE w.WasherId=@WasherID
	END
      
	SELECT  @BatchID=BatchID FROM TCD.BatchData WHERE MachineInternalID = @MachineNumber
												  AND StartDate = @StartDateTime
												  AND ControllerBatchId=@BatchNumber
												  AND MachineID =@WasherID

	--Start Getting InjectionCount and StepCount
	SELECT
		@StdInjectionSteps=count(DISTINCT wdpm.WasherDosingSetupId),
		@StdWashSteps= count(DISTINCT wds.WasherDosingSetupId)- count(DISTINCT wdpm.WasherDosingSetupId)
	FROM TCD.WasherDosingProductMapping wdpm
		RIGHT JOIN TCD.WasherDosingSetup wds on wdpm.WasherDosingSetupId=wds.WasherDosingSetupId
	WHERE wds.ControllerID=@ControllerID 
	  AND wds.ProgramNumber=@ProgramNumber
	--End Getting InjectionCount and StepCount

	--Start-----ProgramMasterID logic for PlantChainProgram
	SELECT @PlantProgramId=pm.PlantProgramId,
			@EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			@ChainTextileCategoryId = pm.ChainTextileId,
			@FormulaSegmentId = pm.FormulaSegmentId,
			@EcolabSaturationId = pm.EcolabSaturationId
	FROM TCD.ProgramMaster pm WHERE pm.ProgramId=@ProgramMasterId 
							    AND pm.Is_Deleted=0

	IF(@PlantProgramId <> 0  AND @PlantProgramId <> NULL)
	BEGIN
		--Assign value from plantchainprogram table based on plantprogramId
		SELECT
			@EcolabTextileCategoryId = pcp.EcolabTextileCategoryId,
			@ChainTextileCategoryId = pcp.ChainTextileCategoryId,
			@FormulaSegmentId = pcp.FormulaSegmentId,
			@EcolabSaturationId = pcp.EcolabSaturationId 
		FROM tcd.PlantChainProgram pcp	WHERE pcp.PlantProgramId=@PlantProgramId 
										  AND pcp.Is_Deleted=0
	END
	--End-----ProgramMasterID logic for PlantChainProgram

	IF (@BatchID IS NULL)
	BEGIN
		INSERT INTO TCD.BatchData
		(
				ControllerBatchID,
				EcolabWasherId,
				GroupId,
				MachineInternalId,
				PlantWasherNumber,
				StartDate,
				EndDate,
				ProgramNumber,
				ProgramMasterId,
				MachineID,
				ActualWeight,
				StandardWeight,
				CurrencyCode,
				ShiftId,
				PartitionOn,
				StdInjectionSteps,
				StdWashSteps,
				EcolabTextileCategoryId,
				ChainTextileCategoryId,
				FormulaSegmentId,
				EcolabSaturationId,
				PlantProgramId,
				EndDateFormula,
				TargetTurnTime
		)
		VALUES
		(		
				@BatchNumber,
				@EcoLabWasherID,
				@WasherGroupID,
				@MachineNumber,
				@PlantWasherNumber,
				@StartDateTime,
				@EndDateTime,
				@ProgramNumber,
				@ProgramMasterId,
				@WasherID,
				@Load,
				@NominalLoad,
				@CurrencyCode,
				@ShiftID,
				@ShiftStartdate,
				@StdInjectionSteps,
				@StdWashSteps,
				@EcolabTextileCategoryId,
				@ChainTextileCategoryId,
				@FormulaSegmentId,
				@EcolabSaturationId,
				@PlantProgramId,
				@EndDateTime,
				@TargetTurnTime
		)

		SELECT @BatchID = Scope_Identity()
				
		IF(@StdWashSteps <>0 OR @StdWashSteps <> NULL)
		BEGIN
			INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) 
			SELECT @BatchID,@EcoLabWasherID,38,@StdWashSteps,@ShiftStartdate
		END

		--End Date  Time  is Null 
		UPDATE TCD.BatchData SET EndDate = getUTCDate() WHERE MachineInternalID = @MachineNumber
														  AND StartDate <> @StartDateTime
														  AND EndDate is Null
														  AND ControllerBatchId <> @BatchNumber
														  AND MachineId = @WasherId	
																  		
		-- Program Number	
		IF (@ProgramNumber IS NOT NULL AND @ProgramNumber > 0)
		BEGIN					
			IF NOT EXISTS( SELECT * FROM TCD.WasherReading WHERE WasherId = @WasherID 
															 AND ParameterID = @FrmParameterID 
															 AND DateTimeStamp = @StartDateTime)								
			BEGIN
				INSERT INTO TCD.WasherReading
				(
						WasherID,
						ParameterID,
						ParameterValue,
						DateTimeStamp,
						EcoLabWasherID,
						Partitionon
				)
				VALUES
				(		
						@WasherID,
						@FrmParameterID,
						@ProgramNumber,
						@StartDateTime,
						@EcoLabWasherID,
						@ShiftStartdate
				)
			END
		END		    
			
		IF NOT EXISTS(SELECT * FROM [TCD].[BatchCustomerData] WHERE BatchID = @BatchId AND @CustomerNumber IS NOT NULL)
		BEGIN
			INSERT INTO [TCD].[BatchCustomerData] ([BatchId],CustomerID,[Weight],PartitionOn,EcolabWasherId)
			Values(@BatchID,@CustomerNumber,@Load,@ShiftStartdate,@EcolabWasherID)
		END 
	END

	-- PH Value
	IF NOT EXISTS(SELECT * FROM TCD.WasherReading WHERE WasherId = @WasherID 
														AND ParameterID = @PHParameterID 
														AND DateTimeStamp = @StartDateTime)
	BEGIN
		IF (@PHValue <> 0 OR @PHValue <> NULL)
		BEGIN
			INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
			SELECT @WasherID,@PHParameterID,@PHValue,GetUTCDate(),@ShiftStartdate,@EcolabWasherId
		END
	END 
	 
	-- PH Status
	IF NOT EXISTS(SELECT * FROM TCD.WasherReading WHERE WasherId = @WasherID 
													AND ParameterID = @PHParameterStatus 
													AND DateTimeStamp = @StartDateTime)
	BEGIN
	IF (@PHStatus <> 0 OR @PHStatus <> NULL)
		BEGIN
			INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
			SELECT @WasherID,@PHParameterStatus,@PHStatus,GetUTCDate(),@ShiftStartdate,@EcolabWasherId
		END
	END 

	-- Temperature Min Value
	IF NOT EXISTS(SELECT * FROM TCD.WasherReading WHERE WasherId = @WasherID 
													AND ParameterID = @TemperatureMinParam 
													AND DateTimeStamp = @StartDateTime)
	BEGIN
	IF (@TemperatureMin <> 0 OR @TemperatureMin <> NULL)
		BEGIN
			INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
			SELECT @WasherID,@TemperatureMinParam,@TemperatureMin,GetUTCDate(),@ShiftStartdate,@EcolabWasherId
		END
	END 

	-- Temperature Max Value
	IF NOT EXISTS(SELECT * FROM TCD.WasherReading WHERE WasherId = @WasherID 
													AND ParameterID = @TemperatureMaxParam 
													AND DateTimeStamp = @StartDateTime)
	BEGIN
	IF (@TemperatureMax <> 0 OR @TemperatureMax <> NULL)
		BEGIN
			INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
			SELECT @WasherID,@TemperatureMaxParam,@TemperatureMax,GetUTCDate(),@ShiftStartdate,@EcolabWasherId
		END
	END 

	-- Temperature Min Status
	IF NOT EXISTS(SELECT * FROM TCD.WasherReading WHERE WasherId = @WasherID 
													AND ParameterID = @TempMinStatusParam 
													AND DateTimeStamp = @StartDateTime)
	BEGIN
	IF (@TempMinStatus <> 0 OR @TempMinStatus <> NULL)
		BEGIN
			INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
			SELECT @WasherID,@TempMinStatusParam,@TempMinStatus,GetUTCDate(),@ShiftStartdate,@EcolabWasherId
		END
	END 

	-- Temperature Max Status
	IF NOT EXISTS(SELECT * FROM TCD.WasherReading WHERE WasherId = @WasherID 
													AND ParameterID = @TempMaxStatusParam 
													AND DateTimeStamp = @StartDateTime)
	BEGIN
	IF (@TempMaxStatus <> 0 OR @TempMaxStatus <> NULL)
		BEGIN
			INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
			SELECT @WasherID,@TempMaxStatusParam,@TempMaxStatus,GetUTCDate(),@ShiftStartdate,@EcolabWasherId
		END
	END 

	-- StepCompartment No
	IF NOT EXISTS(SELECT * FROM TCD.WasherReading WHERE WasherId = @WasherID 
													AND ParameterID = @WashStepNo 
													AND DateTimeStamp = @StartDateTime)
	BEGIN
	IF (@StepNumber <> 0 OR @StepNumber <> NULL)
		BEGIN
			INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
			SELECT @WasherID,@WashStepNo,@StepNumber,GetUTCDate(),@ShiftStartdate,@EcolabWasherId
		END
	END 
END 



GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlConventionalData_CompletedBatches]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlConventionalData_CompletedBatches]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE TCD.ProcessMyControlConventionalData_CompletedBatches
(
		@ControllerID	INT, 
		@VxML			XML,
		@PLCPointer		INT, 
		@ReadPointer	INT, 
		@RedFlagShiftId INT OUTPUT
)
AS
BEGIN
   DECLARE 
			@MachineNumber				INT,
			@StartDateTime				DATETIME,
			@EndDateTime				DATETIME,
			@ProgramNumber				INT,
			@Load						DECIMAL(10,2),
			@NominalLoad				DECIMAL(10,2),
			@CustomerNumber				INT,
			@PHStatus					INT,
			@PHValue					INT,
			@TemperatureMin				INT,
			@TemperatureMax				INT,
			@TempMinStatus				INT,
			@TempMaxStatus				INT,
			@BatchNumber				INT,
		    @WasherID					INT,
			@WasherGroupID				INT,
			@EcoLabWasherID				INT,
			@ProgramMasterID			INT,
			@PlantWasherNumber			INT,
			@ShiftID					INT,
			@BatchID					INT,
			@ShiftStartdate				DATETIME,
			@LastStep					INT,
			@CurrentStep				INT,
			@CurrentStepTime			DATETIME,
			@MinTempParamID				INT,
			@MaxTempParamID				INT,
			@MinTempStatuParamID		INT,
			@MaxTempStatusParamID		INT,
			@PHStatusParamID			INT ,
			@PHValueParamID				INT,
			@CurrencyCode				VARCHAR(50),
			@StdInjectionSteps			INT,
			@StdWashSteps				INT,
			@ActualInjSteps				INT,
			@EcolabTextileCategoryId	INT,
			@ChainTextileCategoryId		INT,
			@FormulaSegmentId			INT,
			@EcolabSaturationId			INT,
			@PlantProgramId				INT,	
			@TargetTurnTime				INT	

	SELECT @MachineNumber=T.c.value('@MachineNumber', 'INT'),
			@StartDateTime=T.c.value('@StartDateTime', 'DateTime'),
			@EndDateTime=T.c.value('@EndDateTime', 'DateTime'),
			@ProgramNumber=T.c.value('@ProgramNumber', 'INT'),
			@Load=T.c.value('@Load', 'Decimal(10,2)'),
			@NominalLoad=T.c.value('@NominalLoad', 'Decimal(10,2)'),
			@CustomerNumber=T.c.value('@CustomerNumber', 'INT'),
			@PHStatus=T.c.value('@PHStatus', 'INT'),
			@PHValue=T.c.value('@PHValue', 'INT'),
			@TemperatureMin=T.c.value('@TemperatureMin', 'INT'),
			@TemperatureMax=T.c.value('@TemperatureMax', 'INT'),
			@TempMaxStatus=T.c.value('@TemperatureMaxStatus', 'INT'),
			@TempMinStatus=T.c.value('@TemperatreMinStatus', 'INT'),
			@BatchNumber=T.c.value('@BatchNumber', 'INT')
	FROM @VxML.nodes('MyControlConventionalData') T(C)

	
	DECLARE @ShiftMapping table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)

	INSERT INTO @ShiftMapping(ShiftId,ShiftName,ShiftStartdate) 
	EXEC TCD.GetShiftStartDate @StartDateTime,1, @RedFlagShiftId OUTPUT

	SELECT @ShiftID = ShiftID, @ShiftStartdate=ShiftStartdate FROM @ShiftMapping
			
	SELECT	@WasherGroupID=GroupId,
			@WasherID=WasherID
	FROM TCD.MachineSetup ms WHERE ControllerID = @ControllerID
							   AND MachineInternalId= @MachineNumber
							   AND IsTunnel =0
							   AND IsDeleted=0

	IF (@WasherId IS NOT NULL)
	BEGIN
		SELECT	@ProgramMasterId=Wps.ProgramId FROM TCD.Washer Ws
					INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
					INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
					INNER JOIN TCD.WasherProgramSetup Wps ON Wps.ControllerID = Wg.ControllerId
					INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.EcoLabAccountNumber
		WHERE Ws.WasherId=@WasherId
		  AND Wps.ProgramNumber=@ProgramNumber 
		  AND Wps.Is_Deleted=0
		
		SELECT @EcoLabWasherID=EcolabWasherId,
			   @PlantWasherNumber=PlantWasherNumber,
			   @CurrencyCode=P.CurrencyCode,
			   @TargetTurnTime = w.TargetTurnTime * 60
		FROM TCD.Washer w 
			INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber=p.EcolabAccountNumber WHERE w.WasherId=@WasherID
	END
      
	SELECT  @BatchID=BatchID FROM TCD.BatchData WHERE MachineInternalID = @MachineNumber
												  AND StartDate = @StartDateTime
												  AND ControllerBatchId=@BatchNumber
												  AND MachineID =@WasherID

   --Start Getting InjectionCount and StepCount

	SELECT	@StdInjectionSteps=count(DISTINCT wdpm.WasherDosingSetupId),
			@StdWashSteps= count(DISTINCT wds.WasherDosingSetupId) - count(DISTINCT wdpm.WasherDosingSetupId)
	FROM TCD.WasherDosingProductMapping wdpm
			RIGHT JOIN TCD.WasherDosingSetup wds on wdpm.WasherDosingSetupId=wds.WasherDosingSetupId
	WHERE wds.ControllerID=@ControllerID 
	  AND wds.ProgramNumber=@ProgramNumber

	--End Getting InjectionCount and StepCount

	--Start-----ProgramMasterID logic for PlantChainProgram
	SELECT 	@PlantProgramId=pm.PlantProgramId,
			@EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			@ChainTextileCategoryId = pm.ChainTextileId,
			@FormulaSegmentId = pm.FormulaSegmentId,
			@EcolabSaturationId = pm.EcolabSaturationId 
	FROM TCD.ProgramMaster pm WHERE pm.ProgramId=@ProgramMasterId 
								AND pm.Is_Deleted=0

	IF(@PlantProgramId <> 0  AND @PlantProgramId IS NOT NULL)
	BEGIN
	  --Assign value from plantchainprogram table based on plantprogramId
		SELECT	@EcolabTextileCategoryId = pcp.EcolabTextileCategoryId,
				@ChainTextileCategoryId = pcp.ChainTextileCategoryId,
				@FormulaSegmentId = pcp.FormulaSegmentId,
				@EcolabSaturationId = pcp.EcolabSaturationId
		FROM tcd.PlantChainProgram pcp
		WHERE pcp.PlantProgramId=@PlantProgramId 
		  AND pcp.Is_Deleted=0
	END
	--End-----ProgramMasterID logic for PlantChainProgram

	If (@BatchID is Null)
	BEGIN
		INSERT INTO TCD.BatchData
		(
				ControllerBatchID,
				EcolabWasherId,
				GroupId,
				MachineInternalId,
				PlantWasherNumber,
				StartDate,
				EndDate,
				ProgramNumber,
				ProgramMasterId,
				MachineID,
				ActualWeight,
				StandardWeight,
				CurrencyCode,
				ShiftId,
				PartitionOn,
				StdInjectionSteps,
				StdWashSteps,
				EcolabTextileCategoryId,
				ChainTextileCategoryId,
				FormulaSegmentId,
				EcolabSaturationId,
				PlantProgramId,
				EndDateFormula,
				TargetTurnTime
		)
		VALUES
		(		@BatchNumber,
				@EcoLabWasherID,
				@WasherGroupID,
				@MachineNumber,
				@PlantWasherNumber,
				@StartDateTime,
				@EndDateTime,
				@ProgramNumber,
				@ProgramMasterId,
				@WasherID,
				@Load,
				@NominalLoad,
				@CurrencyCode,
				@ShiftID,
				@ShiftStartdate,
				@StdInjectionSteps,
				@StdWashSteps,
				@EcolabTextileCategoryId,
				@ChainTextileCategoryId,
				@FormulaSegmentId,
				@EcolabSaturationId,
				@PlantProgramId,
				@EndDateTime,
				@TargetTurnTime
		)

		SELECT @BatchID = Scope_Identity()
		
		IF(@StdWashSteps > 0 OR @StdWashSteps <> NULL)	
		INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchID,@EcoLabWasherID,38,@StdWashSteps,@ShiftStartdate
	END 
	ELSE
	BEGIN
		UPDATE tcd.BatchData
		SET  EndDate=@EndDateTime,
			 ProgramNumber=@ProgramNumber,
			 ProgramMasterId=@ProgramMasterID,
			 ActualWeight=@Load,
			 SyncReady=1
		WHERE BatchID = @BatchID
	END

	IF NOT EXISTS(SELECT 1 FROM [TCD].[BatchCustomerData] WHERE BatchID = @BatchId AND @CustomerNumber IS NOT NULL)
	BEGIN
		INSERT INTO [TCD].[BatchCustomerData] ([BatchId],CustomerID,[Weight],PartitionOn,EcolabWasherId)
		Values(@BatchID,@CustomerNumber,@Load,@ShiftStartdate,@EcolabWasherID)
	END 
	ELSE If (@CustomerNumber > 0 ) 
	BEGIN
			UPDATE [TCD].[BatchCustomerData] SET CustomerID=@CustomerNumber, [Weight]=@Load	WHERE BatchID = @BatchId 
	END

	CREATE TABLE #Dosing(equipmentNo int, StepNo int,Qty Decimal(10,6))

	INSERT INTO #Dosing
	SELECT T.c.value('@Equipment', 'INT'),
		   T.c.value('@stepNo', 'INT'),
		   T.c.value('@Qty', 'Decimal(10,6)')
	FROM @VxML.nodes('MyControlConventionalData/DosingData/Dosing') T(C) WHERE T.c.value('@Qty', 'Decimal(10,6)') > 0

	CREATE TABLE #StepTime(Number int, [Time] int,StartTime DateTime,EndTime DateTime)

	INSERT INTO #StepTime(Number,[Time])
	SELECT   T.c.value('@Number', 'INT'),
			 T.c.value('@Time', 'INT')
	FROM @VxML.nodes('MyControlConventionalData/StepTime/Step') T(C)
	

	CREATE TABLE #TimeStamp (Step_Number int, Time_Stamp int)
	
	--For Calculating TIME_STAMP

	;WITH TempTable AS (
		SELECT DISTINCT Number FROM #StepTime
	)
	INSERT INTO #TimeStamp
	(
	    Step_Number,
		Time_Stamp
	)
	SELECT 
		b.Number, 
		SUM(t.Time) Time_Stamp	
	FROM TempTable b 
		INNER JOIN  #StepTime t ON b.Number >= t.Number GROUP BY b.Number 

		CREATE TABLE #BatchProductData(equipmentNo int, StepNo int,Qty Decimal(10,6),Time_Stamp datetime2(7))

		INSERT INTO #BatchProductData
		(
			equipmentNo, 
			StepNo,
			Qty,
			Time_Stamp
		)
		SELECT 
			d.equipmentNo,
			d.StepNo,
			d.Qty,
			DATEADD(ss,ts.Time_Stamp,@StartDateTime)
		FROM #Dosing d INNER JOIN #TimeStamp ts ON d.StepNo=ts.Step_Number

	--END For Calculating TIMESTAMP

	INSERT INTO TCD.BatchProductData
	(
			BatchId, 
			StepCompartment, 
			ActualQuantity,
			PartitionOn,
			EcolabWasherId,
			ProductId,
			TimeStamp
	)
	SELECT @BatchID,
			b.StepNo,
			b.Qty,
			@ShiftStartdate,
			@EcolabWasherId,
			a.ProductId,
			b.Time_Stamp
	FROM TCD.ControllerEquipmentSetup  a 
		INNER JOIN #BatchProductData b on a.ControllerEquipmentId = b.equipmentNo	
		WHERE b.equipmentNo > 0
		  AND b.Qty > 0
		  AND ControllerID = @ControllerID

	--Start Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
	SELECT @ActualInjSteps = COUNT(DISTINCT StepNo) FROM #Dosing

	IF NOT EXISTS(SELECT * FROM TCD.BatchParameters WHERE ParameterId =37 and batchid=@BatchID AND @ActualInjSteps > 0)
	BEGIN
	IF(@ActualInjSteps > 0 OR @ActualInjSteps IS NOT NULL)
		INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,37,@ActualInjSteps, @ShiftStartDate
	END
	ELSE
	BEGIN
		Update TCD.BatchParameters SET ParameterValue=@ActualInjSteps WHERE ParameterId =37 and batchid=@BatchID
	END
	  		
	SELECT @LastStep = MAX([Number]) FROM #StepTime WHERE [Time] > 0

	SELECT @CurrentStep = 1,@CurrentStepTime= @StartDateTime
			
	WHILE (@CurrentStep <=@LastStep)
	BEGIN
		UPDATE #StepTime SET StartTime = @CurrentStepTime,EndTime = DateAdd(ss,[time],@CurrentStepTime)	WHERE Number = @CurrentStep

		SELECT @CurrentStepTime=EndTime FROM #StepTime WHERE Number = @CurrentStep

		SELECT @CurrentStep = @CurrentStep + 1 
	END 
		
	INSERT INTO [TCD].[BatchWashStepData]
			(BatchID,
			StepCompartment,
			StartTime,
			EndTime,
			PartitionOn,
			EcolabWasherId)
	SELECT @BatchID,
			Number,
			StartTime,
			EndTime,
			@ShiftStartdate,
			@EcoLabWasherID
	FROM #StepTime
	WHERE Number<=@LastStep

	SELECT @MinTempParamID=Id 
	FROM [TCD].[ConduitParameters] 
	WHERE Name = 'Mimum Temperature' 

	SELECT @MaxTempParamID=Id 
	FROM [TCD].[ConduitParameters] 
	WHERE Name = 'Maximum Temperature'

	SELECT @MaxTempStatusParamID=Id 
	FROM [TCD].[ConduitParameters] 
	WHERE Name = 'Max Temperature Status'

	SELECT @MinTempStatuParamID=Id 
	FROM [TCD].[ConduitParameters] 
	WHERE Name = 'Minimum Temperature Status'

	SELECT @MinTempStatuParamID=Id 
	FROM [TCD].[ConduitParameters] 
	WHERE Name = 'Minimum Temperature Status'

	SELECT @PHValueParamID=ID
	FROM [TCD].[ConduitParameters] 
	WHERE Name = 'PH'
		
	SELECT @PHStatusParamID=ID
	FROM [TCD].[ConduitParameters] 
	WHERE Name =  'PH Status'

	SELECT @MinTempStatuParamID=Id 
	FROM [TCD].[ConduitParameters] 
	WHERE Name = 'Minimum Temperature Status'

	IF (@TemperatureMin <> 0 OR @TemperatureMin <> NULL )
		BEGIN
			INSERT INTO TCD.BatchParameters
					(BatchId,
					EcolabWasherId,
					ParameterId,
					ParameterValue,
					PartitionOn)
			VALUES (@BatchID,
					@EcoLabWasherID,
					@MinTempParamID,
					@TemperatureMin,
					@ShiftStartdate)
		END
	IF (@TemperatureMax <> 0 OR @TemperatureMax <> NULL)
	BEGIN
		INSERT INTO TCD.BatchParameters
				(BatchId,
				EcolabWasherId,
				ParameterId,
				ParameterValue,
				PartitionOn)
		VALUES  (@BatchID,
				@EcoLabWasherID,
				@MaxTempParamID,
				@TemperatureMax,
				@ShiftStartdate)
	END
	IF (@TempMaxStatus <> 0 OR @TempMaxStatus <> NULL )
	BEGIN
		INSERT INTO TCD.BatchParameters
				(BatchId,
				EcolabWasherId,
				ParameterId,
				ParameterValue,
				PartitionOn)
		VALUES  (@BatchID,
				@EcoLabWasherID,
				@MaxTempStatusParamID,
				@TempMaxStatus,
				@ShiftStartdate)
	END
	IF (@TempMinStatus <> 0 OR @TempMinStatus <> NULL)
	BEGIN
		INSERT INTO TCD.BatchParameters
				(BatchId,
				EcolabWasherId,
				ParameterId,
				ParameterValue,
				PartitionOn)
		VALUES  (@BatchID,
				@EcoLabWasherID,
				@MinTempStatuParamID,
				@TempMinStatus,
				@ShiftStartdate)
	END
	IF (@PHStatus <> 0 OR @PHStatus <> NULL )
	BEGIN
		INSERT INTO TCD.BatchParameters
				(BatchId,
				EcolabWasherId,
				ParameterId,
				ParameterValue,
				PartitionOn)
		VALUES  (@BatchID,
				@EcoLabWasherID,
				@PHStatusParamID,
				@PHStatus,
				@ShiftStartdate)
	END
	IF (@PHValue <> 0 OR @PHValue <> NULL )
	BEGIN
		INSERT INTO TCD.BatchParameters
				(BatchId,
				EcolabWasherId,
				ParameterId,
				ParameterValue,
				PartitionOn)
		VALUES  (@BatchID,
				@EcoLabWasherID,
				@PHValueParamID,
				@PHValue,
				@ShiftStartdate)
	END

	DROP TABLE #BatchProductData
	DROP TABLE #Dosing
	DROP TABLE #StepTime
	DROP TABLE #TimeStamp
END 



GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlTunnelWasherOnlineData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlTunnelWasherOnlineData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [TCD].[ProcessMyControlTunnelWasherOnlineData]
	(
	@ControllerID INT,
	@xmlTags xML,
	@RedFlagShiftId INT OUTPUT
)
AS
BEGIN
   DECLARE 
			@BatchID						INT,
			@WasherID						INT,
			@EcolabWasherId					INT,								
			@CurrencyCode					VARCHAR(50),		
			@MachineInternalId				INT,
			@WasherGroupID					INT,
			@PlantWasherNumber				INT,
			@BatchStartDate					DATETIME2,
			@BatchEndDate					DATETIME2,			
			@ProgramNumber					INT,
			@Load							Decimal(10,2),
			@NominalLoad					Decimal(10,2),
			@CustomerNumber					INT,
			@PHStatus						INT,
			@PHValue						INT,
			@LFStatus						INT,
			@LFValue						INT,
			@EjectionSignal					INT,
			@TextTileCategory				INT,
			@BatchNumber					INT,
			@TargetTurnTime					INT,
			@ShiftID						INT,
			@ParameterID					INT,			
			@ShiftName						VARCHAR(50),
			@EcolabAccountNumber NVARCHAR(25) = NULL,
			@PartitionOn DateTime,
			@BatchStartTime DateTime,
			@BatchEndTime DateTime,
			@PorgramParameterID int,
			@PHParameterID int,
			@PHParameterStatus int,
			@ConductivityParamID int,
			@ConductivityStatusParamID int,
			@RunTime int,
			@TextileCategory int,
			@ProgramID int,
			@NumberOfCompartments int,
			@TempParameter int,
			@CompartmentNoId int,
			@TransferSignalId int,
			@BatchShiftId int,
			@compartmentID int,
			@TunnelXML xml,
			@TempXML xml,
			@StdInjectionSteps INT,
			@StdWashSteps INT

	   
	SELECT @CompartmentNoId=ID
	FROM TCD.ConduitParameters WHERE NAME ='StepCompartment No' 

	SELECT @TransferSignalId=ID
	FROM TCD.ConduitParameters WHERE NAME ='Transfer Signal'

	CREATE TABLE #Batches(BatchNumber int,StartDateTime DateTime)			
		
	SET @compartmentID = 1	
	
	SELECT @TempXML=T.c.query('.') 	FROM   @xmlTags.nodes('MyControlTunnel') T(c)
	SELECT   @MachineInternalID=T.c.value('@MachineNumber', 'int') FROM @TempXML.nodes('MyControlTunnel')  T(c);

	SELECT 
			@EcolabWasherID=EcolabWasherId,
			@WasherGroupID= Wg.WasherGroupId,
			@PlantWasherNumber=PlantWasherNumber,
			@WasherID=ws.WasherId,
			@CurrencyCode=P.CurrencyCode,
			@NumberOfCompartments=Mst.NumberofComp
	FROM TCD.Washer Ws
			INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
			INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
			INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
			INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId = Mst.ControllerId
			INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.EcoLabAccountNumber
	WHERE  Ctrl.ControllerID = @ControllerID
			AND mst.MachineInternalId = @MachineInternalID
			AND Mst.IsTunnel = 1

	WHILE (@compartmentID <= @NumberOfCompartments)
	BEGIN
	  
	  	SELECT @TunnelXML=T.c.query('.') 
		FROM   @xmlTags.nodes('MyControlTunnel/TunnelData') T(c)
		WHERE T.c.value('@CompartmentNumber', 'INT') = @compartmentID


		 SELECT   @MachineInternalID=T.c.value('@MachineNumber', 'int'),
				  @BatchNumber= T.c.value('@BatchNumber', 'INT'),
 				  @BatchStartTime=T.c.value('@StartDateTime', 'DateTime'),
				  @BatchEndTime=T.c.value('@EndDateTime', 'DateTime'),
				  @ProgramNumber=T.c.value('@ProgramNumber', 'INT'),
				  @Load=T.c.value('@Load', 'Decimal(10,6)')/10,
				  @NominalLoad=T.c.value('@Nominalload', 'Decimal(10,6)'),
				  @CustomerNumber=T.c.value('@CustomerNumber', 'int'),
				  @PHStatus=T.c.value('@pHStatus', 'int'),
				  @PHValue=T.c.value('@pHValue', 'INT'),
				  @LFStatus=T.c.value('@LFStatus', 'INT'),
				  @LFValue=T.c.value('@LFValue', 'INT'),
				  @RunTime=T.c.value('@RunTime', 'INT'),
				  @EjectionSignal=T.c.value('@EjectionSignal', 'INT'),
				  @TextileCategory=T.c.value('@TextileCategory', 'INT')
		 FROM @TunnelXML.nodes('TunnelData')  T(c);
		 

		 IF (@ProgramNumber = 0 OR @BatchNumber=1) 
		 BEGIN
		    SELECT @compartmentID  = @compartmentID + 1
			Continue;
		 END 		 
		

		 SELECT @ProgramID=ProgramId,
				@TargetTurnTime= (3600 / (tps.TotalRunTime /@NumberOfCompartments )) 
		 FROM TCD.TunnelProgramSetup AS tps 
		 WHERE tps.WasherGroupId = @WasherGroupID 
			   and tps.is_deleted =0
			   and ProgramNumber = @ProgramNumber

		 INSERT #Batches(BatchNumber,StartDateTime)
		 SELECT @BatchNumber,@BatchStartTime

		 --DELETE FROM  @ShiftStartDateTemp;
				
		SELECT @BatchID = Null
		SELECT @BatchID=BatchID	FROM TCD.BatchData BD
			WHERE BD.ControllerBatchId = @BatchNumber
				  AND BD.StartDate= @BatchStartTime
				  AND BD.MachineId = @WasherID
				  
		--Start Getting InjectionCount,StepCount And ProductCount
			SELECT @StdInjectionSteps= count(tdpm.TunnelDosingSetupId) ,
			@StdWashSteps= count(DISTINCT tds.TunnelDosingSetupId)-count(tdpm.TunnelDosingSetupId) 
			FROM tcd.TunnelDosingProductMapping tdpm
			RIGHT JOIN tcd.TunnelDosingSetup tds on tdpm.TunnelDosingSetupId=tds.TunnelDosingSetupId
			WHERE tds.GroupId=@WasherGroupID AND tds.ProgramNumber= @ProgramNumber
			--End Getting InjectionCount,StepCount And ProductCount

		IF (@BatchID is Null) 
		BEGIN

			 DECLARE @ShiftStartDateTemp table(ShiftId INT,ShiftName NVARCHAR(50),ShiftStartdate DATETIME)
			 INSERT INTO @ShiftStartDateTemp(ShiftId,ShiftName,ShiftStartdate) 
			 EXEC TCD.GetShiftStartDate @BatchStartTime,1, @RedFlagShiftId OUTPUT

			 SELECT @BatchShiftId = ShiftID, @PartitionOn=ShiftStartdate, @ShiftName=ShiftName FROM @ShiftStartDateTemp			 

				INSERT INTO TCD.BatchData(
									   ControllerBatchId ,
									   EcolabWasherId,
									   GroupId ,
									   MachineInternalId,
									   PlantWasherNumber,
									   StartDate ,
									   ProgramNumber,
									   ProgramMasterId,
									   MachineId,
									   ActualWeight,
									   StandardWeight,
									   CurrencyCode,
									   ShiftId,
									   PartitionOn,
									   TargetTurnTime,
									   StdInjectionSteps,
									   StdWashSteps
									)
					   SELECT @BatchNumber,
							  @EcolabWasherID,
							  @WasherGroupID,
							  @MachineInternalID,
							  @PlantWasherNumber,
							  @BatchStartTime,
							  @ProgramNumber,
							  @ProgramID,
							  @WasherID,
							  @Load,
							  @NominalLoad,
							  @CurrencyCode,
							  @BatchShiftId,
							  @PartitionOn,
							  @TargetTurnTime,
							  @StdInjectionSteps,
							  @StdWashSteps

		SELECT @BatchID=Scope_Identity()	

		INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue,PartitionOn) SELECT @BatchID,@EcolabWasherId,38,@StdWashSteps, @PartitionOn  

		IF(@CustomerNumber is not null)
		BEGIN
			 IF NOT Exists(SELECT 1 FROM [TCD].[BatchCustomerData] WHERE BatchID = @BatchID)
			 BEGIN
				INSERT INTO [TCD].[BatchCustomerData] ([BatchId],CustomerID,[Weight],PartitionOn,EcolabWasherId)
				SELECT @BatchID,@CustomerNumber,@Load,@PartitionOn,@EcolabWasherId
			 END 
		END
			
	 END 

	 --IF (@BatchEndTime is Not Null and @BatchEndTime !='01/01/1900')
	 --BEGIN
		--UPDATE TCD.BatchData
		--SET EndDate = @BatchEndTime
		--WHERE BATCHID = @BatchID
	 --END 
	 
	 -- Transfer Signal
	 INSERT INTO TCD.WasherReading(
			WasherId,
			ParameterId,
			ParameterValue,
			DateTimeStamp,
			PartitionOn,
			EcolabWasherId)
			SELECT @WasherID,
			@TransferSignalId,
			1,
			@BatchStartTime,
			@PartitionOn,
			@EcolabWasherId
		UNION ALL
			SELECT @WasherID,
			@TransferSignalId,
			0,
			@BatchStartTime,
			@PartitionOn,
			@EcolabWasherId

	

	 ---- @Program Number
	 --SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
		--	WasherId = @WasherID 
		--	AND ParameterID = @PorgramParameterID 
		--	AND EcolabWasherId = @EcolabWasherId 
		--	AND DateTimeStamp = @BatchStartTime
		--	--AND ParameterValue = @ProgramNumber
		--	ORDER BY  DateTimeStamp DESC)

		--IF (@TempParameter != @ProgramNumber)
		--BEGIN
		--	INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
		--	SELECT @WasherID,@PorgramParameterID,@ProgramNumber,@BatchStartTime,@PartitionOn,@EcolabWasherId
		--END 
		
			
		---- Compartment No  
		--SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
		--	WasherId = @WasherID 
		--	AND ParameterID = @CompartmentNoId 
		--	AND EcolabWasherId = @EcolabWasherId 
		--	AND DateTimeStamp = @BatchStartTime
		--	--AND ParameterValue = @ProgramNumber
		--	ORDER BY  DateTimeStamp DESC)

		--IF (@TempParameter != @compartmentID)
		--BEGIN
		--	--IF (@LFValue > 0)
		--	--BEGIN
		--		INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
		--		SELECT @WasherID,@CompartmentNoId,@compartmentID,@BatchStartTime,@PartitionOn,@EcolabWasherId
		--	--END
		--END 	 

	  EXEC TCD.UPDATEBatchWashStepForTunnel @TunnelXML,@WasherID,@BatchID, @BatchStartTime,@PartitionOn,@EcolabWasherId,@compartmentID

	  SELECT @compartmentID= @compartmentID + 1 
	END	   

	
	-- Last Step is not getting closed in Tunnel BatchWashStepData
	UPDATE BWD
	SET EndTime=GetUTCDate()
	FROM TCD.BatchWashStepData BWD
	INNER JOIN TCD.BatchData BD on BWD.BatchId = BD.BatchId
	WHERE BD.MachineId =@WasherID
              AND BWD.EndTime is Null
              AND Not Exists(SELECT 1 FROM #Batches t
                             WHERE t.BatchNumber = BD.ControllerBatchId
                             and t.StartDateTime =BD.StartDate)      
END
			

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlTunnelWasherProdData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlTunnelWasherProdData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [TCD].[ProcessMyControlTunnelWasherProdData]
	(
	@ControllerID INT,
	@xmlTags xML,
	@PLCPointer INT,
	@ReadPointer INT,
	@RedFlagShiftId INT OUTPUT
)
AS
BEGIN
   DECLARE 
			@BatchID						INT,
			@WasherID						INT,
			@EcolabWasherId					INT,								
			@CurrencyCode					VARCHAR(50),		
			@MachineInternalId				INT,
			@WasherGroupID					INT,
			@PlantWasherNumber				INT,
			@BatchStartDate					DATETIME2,
			@BatchEndDate					DATETIME2,			
			@ProgramNumber					INT,
			@Load							Decimal(10,2),
			@NominalLoad					Decimal(10,2),
			@CustomerNumber					INT,
			@PHStatus						INT,
			@PHValue						INT,
			@LFStatus						INT,
			@LFValue						INT,
			@EjectionSignal					INT,
			@TextTileCategory				INT,
			@BatchNumber					INT,
			@TargetTurnTime					INT,
			@ShiftID						INT,
			@ParameterID					INT,			
			@ShiftName						VARCHAR(50),
			@EcolabAccountNumber NVARCHAR(25) = NULL,
			@PartitionOn DATETIME2,
			@BatchStartTime DATETIME2,
			@BatchEndTime DATETIME2,
			@PorgramParameterID int,
			@PHParameterID int,
			@ConductivityParamID int,
			@RunTime int,
			@TextileCategory int,
			@ProgramID int,
			@NumberOfCompartments int,
			@TempParameter int,
			@PumpNo   INT, 
			@DosingPoint INT,
			@ProductId INT,
			@ActualQuantity Decimal(10,6),
			@CompartmentNum INT,
			@EquipmentType INT,
			@MinTempParamID INT,
			@MaxTempParamID INT,
			@TempStatusParamID INT,			
			@PHValueParamID INT,
			@PHStatusParamID INT,
			@ConductivityValueParamID INT,
			@ConductivityStatusParamID INT,
			@StdInjectionSteps INT,
			@StdWashSteps INT,
			@ActualInjSteps INT
	
	DECLARE @BatchShiftId int
	DECLARE @ShiftStartDateTemp table(ShiftId INT,ShiftName NVARCHAR(50),ShiftStartdate DATETIME)

	DECLARE @compartmentID int,
	 @TunnelXML xml

	SELECT @TunnelXML=T.c.query('.') 
		FROM   @xmlTags.nodes('MyControlTunnel/TunnelData') T(c)
		WHERE T.c.value('@CompartmentNumber', 'INT') = 0
					
	SELECT   @MachineInternalID=T.c.value('@MachineNumber', 'int'),
				  @BatchNumber= T.c.value('@BatchNumber', 'INT'),
 				  @BatchStartTime=T.c.value('@StartDateTime', 'DateTime'),
				  @BatchEndTime=T.c.value('@EndDateTime', 'DateTime'),
				  @ProgramNumber=T.c.value('@ProgramNumber', 'INT'),
				  @Load=T.c.value('@Load', 'Decimal(10,2)'),
				  @NominalLoad=T.c.value('@Nominalload', 'Decimal(10,2)'),
				  @CustomerNumber=T.c.value('@CustomerNumber', 'int'),
				  @PHStatus=T.c.value('@pHStatus', 'int'),
				  @PHValue=T.c.value('@pHValue', 'INT'),
				  @LFStatus=T.c.value('@LFStatus', 'INT'),
				  @LFValue=T.c.value('@LFValue', 'INT'),
				  @RunTime=T.c.value('@RunTime', 'INT'),
				  @EjectionSignal=T.c.value('@EjectionSignal', 'INT'),
				  @TextileCategory=T.c.value('@TextileCategory', 'INT'),
				  @PumpNo=T.c.value('@Number', 'INT'), 
				  @DosingPoint=T.c.value('@Point', 'INT'),
				  @ActualQuantity=T.c.value('@Quantity', 'INT')
		 FROM @xmlTags.nodes('MyControlTunnel/TunnelData')  T(c);
		 
		 
		SELECT 
				@EcolabWasherID=Ws.EcolabWasherId,
				@WasherGroupID= Wg.WasherGroupId,
				@PlantWasherNumber=PlantWasherNumber,
				@WasherID=ws.WasherId,
				@CurrencyCode=P.CurrencyCode,
				@NumberOfCompartments=Mst.NumberofComp
		FROM TCD.Washer Ws
				INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
				INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
				INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
				INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId = Mst.ControllerId
				INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.EcoLabAccountNumber
		WHERE  Ctrl.ControllerID = @ControllerID AND
				Mst.MachineInternalId = @MachineInternalID AND
				Mst.IsTunnel = 1
SELECT @EcolabWasherID
		 SELECT @ProgramID=ProgramId,
				@TargetTurnTime= (3600 / (tps.TotalRunTime /@NumberOfCompartments )) 
		 FROM TCD.TunnelProgramSetup AS tps 
		 WHERE tps.WasherGroupId = @WasherGroupID 
			   and tps.is_deleted =0
			   and ProgramNumber = @ProgramNumber

		 --INSERT #Batches(BatchNumber,StartDateTime)
		 --SELECT @BatchNumber,@BatchStartTime

		 DELETE FROM  @ShiftStartDateTemp;

		 IF (@BatchEndTime is Not Null)
		 BEGIN
			 INSERT INTO @ShiftStartDateTemp(ShiftId,ShiftName,ShiftStartdate) 
			 EXEC TCD.GetShiftStartDate @BatchEndTime,1,@RedFlagShiftId OUTPUT
		 END
		 ELSE
		 BEGIN
			INSERT INTO @ShiftStartDateTemp(ShiftId,ShiftName,ShiftStartdate) 
			EXEC TCD.GetShiftStartDate @BatchStartTime,1,@RedFlagShiftId OUTPUT
		 END

		 SELECT @BatchShiftId = ShiftID,
				  @PartitionOn=ShiftStartdate,
				  @ShiftName=ShiftName
		FROM @ShiftStartDateTemp


			--Start Getting InjectionCount,StepCount And ProductCount
			SELECT @StdInjectionSteps= count(tdpm.TunnelDosingSetupId) ,
			@StdWashSteps= count(DISTINCT tds.TunnelDosingSetupId)-count(tdpm.TunnelDosingSetupId) 
			FROM tcd.TunnelDosingProductMapping tdpm
			RIGHT JOIN tcd.TunnelDosingSetup tds on tdpm.TunnelDosingSetupId=tds.TunnelDosingSetupId
			WHERE tds.GroupId=@WasherGroupID AND tds.ProgramNumber= @ProgramNumber
			--End Getting InjectionCount,StepCount And ProductCount
		
		SELECT @BatchID = Null 	
		 
		SELECT @BatchID=BatchID	FROM TCD.BatchData BD 
				WHERE BD.ControllerBatchId = @BatchNumber
						AND BD.StartDate= @BatchStartTime
						AND BD.MachineId = @WasherID
						--AND BD.MachineInternalID = @MachineInternalID
		IF (@BatchID is Null) 
		BEGIN
				INSERT INTO TCD.BatchData(
					ControllerBatchId ,
					EcolabWasherId,
					GroupId ,
					MachineInternalId,
					PlantWasherNumber,
					StartDate,
					EndDate,
					ProgramNumber,
					ProgramMasterId,
					MachineId,
					ActualWeight,
					StandardWeight,
					CurrencyCode,
					ShiftId,
					PartitionOn,
					TargetTurnTime,
					StdInjectionSteps,
					StdWashSteps
				)
			   SELECT @BatchNumber,
					  @EcolabWasherID,
					  @WasherGroupID,
					  @MachineInternalID,
					  @PlantWasherNumber,
					  @BatchStartTime,
					  @BatchEndTime,
					  @ProgramNumber,
					  @ProgramID,
					  @WasherID,
					  @Load,
					  @NominalLoad,
					  @CurrencyCode,
					  @BatchShiftId,
					  @PartitionOn,
					  @TargetTurnTime,
					  @StdInjectionSteps,
					  @StdWashSteps

				SELECT @BatchID=Scope_Identity()
				
				INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue,PartitionOn) SELECT @BatchID,@EcolabWasherId,38,@StdWashSteps, @PartitionOn

				EXEC TCD.UPDATEBatchWashStepForTunnel @TunnelXML,@WasherID,@BatchID, @BatchStartTime,@PartitionOn,@EcolabWasherId,@NumberOfCompartments				
	 END 
	
	 IF (@BatchEndTime is Not Null and @BatchEndTime !='01/01/1900')
	 BEGIN
		UPDATE TCD.BatchData SET EndDate = @BatchEndTime, ShiftId = @BatchShiftId, PartitionOn = @PartitionOn WHERE BATCHID = @BatchID
	 END 
	 
	 IF(@CustomerNumber is not null)
	 BEGIN
		 IF NOT Exists(SELECT 1 FROM [TCD].[BatchCustomerData] WHERE BatchID = @BatchID)
		 BEGIN
			INSERT INTO [TCD].[BatchCustomerData] ([BatchId],CustomerID,[Weight],PartitionOn,EcolabWasherId)
			SELECT @BatchID,@CustomerNumber,@Load,@PartitionOn,@EcolabWasherId
		 END 
	 END
	 	 
	  CREATE TABLE #DosingDetails(Number INT, 
								  Quantity Decimal(10,6),
								  Point INT,
								  IsMainEquioment INT
								 )
  	 	 
	  INSERT INTO #DosingDetails(Number,Quantity, Point, IsMainEquioment)
	  SELECT 
			T.c.value('@Number', 'INT') AS Number, --PumpNumber
			T.c.value('@Quantity', 'Decimal(10,6)') AS Quantity, --Dosing Quanity
			T.c.value('@Point', 'INT') AS Point,	--Dosing point
			T.c.value('@IsMainEquioment', 'INT') AS IsMainEquioment
								
	  FROM @xmlTags.nodes('MyControlTunnel/TunnelData/Dose') T(C)
	
	  -- Fetching data from cursor
			DECLARE @MYCURSOR CURSOR
			SET @MYCURSOR = CURSOR FAST_FORWARD
			FOR
			SELECT		Number,
						Quantity,										
						Point,
						IsMainEquioment

				FROM #DosingDetails

			DECLARE			@Number				INT,
							@Quantity			Decimal(10,6),
							@Point				INT,
							@IsMainEquioment	INT

			OPEN @MYCURSOR
			FETCH NEXT FROM @MYCURSOR
						INTO 
							@Number,
							@Quantity,
							@Point,
							@IsMainEquioment
							
			WHILE @@FETCH_STATUS = 0			
			BEGIN	
				IF(@IsMainEquioment = 1)
				BEGIN
					SET @EquipmentType = 2
				END
				ELSE
				BEGIN
					SET @EquipmentType = 1
				END

				SELECT @ProductId=CES.ProductId, @CompartmentNum=TCEVM.CompartmentNumber
		    	FROM  tcd.ControllerEquipmentSetup CES INNER JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM
				ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
				WHERE CES.ControllerId=@ControllerID AND
						CES.ControllerEquipmentTypeId=@EquipmentType AND
						--CES.IsActive=1 AND
						--CES.WasherGroupNumber=@WasherGroupNum AND
						TCEVM.DosingPointNumber=@Point AND
						CES.ControllerEquipmentId = @Number
				
				--SELECT @EcolabWasherID
				IF(@ProductId is not null)
				BEGIN
	
					INSERT INTO TCD.BatchProductData 
					(BatchId, StepCompartment, ActualQuantity,[TimeStamp],PartitionOn,EcolabWasherId,ProductId)
					SELECT @BatchID,
						@CompartmentNum,
						@Quantity,
						@BatchEndTime,
						@PartitionOn,
						@EcolabWasherID,
						@ProductId
				END

				FETCH NEXT FROM @MYCURSOR
						INTO 
							@Number,
							@Quantity,
							@Point,
							@IsMainEquioment
			END

			CLOSE @MYCURSOR
			DEALLOCATE @MYCURSOR

			Drop table #DosingDetails
	 
		SELECT @ActualInjSteps = COUNT(DISTINCT StepCompartment) FROM TCD.BatchProductData WHERE BatchId=@BatchID
		IF NOT EXISTS(SELECT * FROM TCD.BatchParameters WHERE ParameterId =37 and batchid=@BatchID AND @ActualInjSteps > 0)
		BEGIN
			INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,37,@ActualInjSteps, @PartitionOn
		END
		ELSE
		BEGIN
			Update TCD.BatchParameters SET ParameterValue=@ActualInjSteps WHERE ParameterId =37 and batchid=@BatchID
		END
	 	
		SELECT @MinTempParamID=Id 
		FROM [TCD].[ConduitParameters] 
		WHERE Name = 'Minimum Temperature' 

		
		SELECT @MaxTempParamID=Id 
		FROM [TCD].[ConduitParameters] 
		WHERE Name = 'Maximum Temperature'

		SELECT @TempStatusParamID=Id 
		FROM [TCD].[ConduitParameters] 
		WHERE Name = 'Temperature Status'

		SELECT @PHValueParamID=ID
		FROM [TCD].[ConduitParameters] 
		WHERE Name = 'PH'
				
		SELECT @PHStatusParamID=ID
		FROM [TCD].[ConduitParameters] 
		WHERE Name =  'PH Status'
		
		SELECT @ConductivityValueParamID=ID
		FROM [TCD].[ConduitParameters] 
		WHERE Name = 'Conductivity'
				
		SELECT @ConductivityStatusParamID=ID
		FROM [TCD].[ConduitParameters] 
		WHERE Name =  'LF Status'  
		
		IF(@PHValue is not null)
		BEGIN
				--pH Value
				INSERT INTO TCD.BatchParameters
				(BatchId,
				 EcolabWasherId,
				 ParameterId,
				 ParameterValue,
				 PartitionOn)
				VALUES(@BatchID,
						@EcoLabWasherID,
						@PHValueParamID,
						@PHValue,
						@PartitionOn)

				--pH Status
				INSERT INTO TCD.BatchParameters
				(BatchId,
				 EcolabWasherId,
				 ParameterId,
				 ParameterValue,
				 PartitionOn)
				VALUES(@BatchID,
						@EcoLabWasherID,
						@PHStatusParamID,
						@PHStatus,
						@PartitionOn)
		END

		IF(@LFValue is not null)
		BEGIN
				--Conductivity Value
				INSERT INTO TCD.BatchParameters
				(BatchId,
				 EcolabWasherId,
				 ParameterId,
				 ParameterValue,
				 PartitionOn)
				VALUES(@BatchID,
						@EcoLabWasherID,
						@ConductivityValueParamID,
						@LFValue,
						@PartitionOn)

				--Conductivity Status
				INSERT INTO TCD.BatchParameters
				(BatchId,
				 EcolabWasherId,
				 ParameterId,
				 ParameterValue,
				 PartitionOn)
				VALUES(@BatchID,
						@EcoLabWasherID,
						@ConductivityStatusParamID,
						@LFStatus,
						@PartitionOn)
		END

		CREATE TABLE #TemperatureDetails(MinimumTemp Decimal(10,2), 
										 MaximumTemp Decimal(10,2),
										 TempStatus Decimal(10,2)
										)
  	  
	  INSERT INTO #TemperatureDetails(MinimumTemp,MaximumTemp, TempStatus)
	  SELECT 
			T.c.value('@MinimumTemp', 'Decimal(10,2)') AS MinimumTemp, 
			T.c.value('@MaximumTemp', 'Decimal(10,2)') AS MaximumTemp,
			T.c.value('@Status', 'Decimal(10,2)') AS TempStatus
			
	  FROM @xmlTags.nodes('MyControlTunnel/TunnelData/TemperatureData') T(c)
	  
	  -- Fetching data from cursor
			DECLARE @TEMPCURSOR CURSOR
			SET @TEMPCURSOR = CURSOR FAST_FORWARD
			FOR
			SELECT		MinimumTemp,
						MaximumTemp,										
						TempStatus

			FROM #TemperatureDetails

			DECLARE			@MinimumTemp			Decimal(10,2),
							@MaximumTemp			Decimal(10,2),
							@TempStatus				Decimal(10,2)
							
			OPEN @TEMPCURSOR
			FETCH NEXT FROM @TEMPCURSOR
						INTO 
							@MinimumTemp,
							@MaximumTemp,
							@TempStatus
							
			WHILE @@FETCH_STATUS = 0			
			BEGIN	
				--Minimum Temperature
				INSERT INTO TCD.BatchParameters
				(BatchId,
				 EcolabWasherId,
				 ParameterId,
				 ParameterValue,
				 PartitionOn)
				VALUES(@BatchID,
						@EcoLabWasherID,
						@MinTempParamID,
						@MinimumTemp,
						@PartitionOn)

				--Maximum Temperature
				INSERT INTO TCD.BatchParameters
				(BatchId,
				 EcolabWasherId,
				 ParameterId,
				 ParameterValue,
				 PartitionOn)
				VALUES(@BatchID,
						@EcoLabWasherID,
						@MaxTempParamID,
						@MaximumTemp,
						@PartitionOn)

				--Temperature Status
				INSERT INTO TCD.BatchParameters
				(BatchId,
				 EcolabWasherId,
				 ParameterId,
				 ParameterValue,
				 PartitionOn)
				VALUES(@BatchID,
						@EcoLabWasherID,
						@TempStatusParamID,
						@TempStatus,
						@PartitionOn)								

				FETCH NEXT FROM @TEMPCURSOR
						INTO 
							@MinimumTemp,
							@MaximumTemp,
							@TempStatus
			END

			CLOSE @TEMPCURSOR
			DEALLOCATE @TEMPCURSOR

			Drop table #TemperatureDetails
		
	UPDATE TCD.BatchWashStepData SET EndTime=@BatchEndTime
	WHERE BatchId = @BatchID and EndTime is NULL
	
END	

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessConventionalWasherData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessConventionalWasherData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [TCD].[ProcessConventionalWasherData]
	(	
	@WasherId INT,	
	@xmlTags XML,
	@RedFlagShiftId INT OUTPUT
)

AS
BEGIN
  DECLARE @BatchID        INT,
    @EcolabWasherId       INT,        
    @CurrencyCode       VARCHAR(50),  
    @MachineInternalId      INT,
    @GroupId        INT,  
    @Prveformula       INT,
    @Quantity        INT,
    @MaxWashertGroupCapacity    INT,

    @ProgramMasterId      INT,
    @NominalLoad       DECIMAL(10,2),
    @MaxLoad        DECIMAL(10,2),
    @StandardWeight       DECIMAL(10,2) ,     

    @CurrentFormula       INT,  
    @CurrentFormulaDate      DATETIME2,
    @FormulaIsModified      BIT,

    @CurrentInjection      INT,
    @CurrentInjectionDate     DATETIME2,
    @InjectionIsModified     BIT,

    @OperationalCount      INT,
    @OperationalIsModified     BIT, 
				
    @CurrentHoldSignal      INT,
    @CurrentHoldSignalDate     DATETIME2,
    @HoldSignalIsModified     BIT,  
													
    @EndofFormula       INT, 
    @EndofFormulaDate      DATETIME2,
				
    @AutoWeightEntryActive     BIT,
    @AutoWeightEntryWeight     DECIMAL(10,2),                                                                                                                              
    @ControllerId       INT,
    @CurrentHoldSignalValue     INT ,
				
    @MeterPlcAddress      INT,
    @MeterPlcAddressIsModified    INT,
    @BatchGroupId       INT,
    @BatchFormula       INT,    
    @HoldTime        INT,
    @CteTempBatchInjections     INT,
    @CteTempWaherReadingInjections   INT,
    @BatchStandardWaterUsage    INT,
    @BatchActualWaterUsage     INT,
    @BatchWaterUsagePrice     Decimal(10,2),
    @BatchUtilityPrice      Decimal(10,2),
    @BatchWaterType       INT,
    @PrevGroupId       INT,
    @WasherMeterExists      BIT,
    @ExtraTime        INT,
    @TargetTurnTime       INT,
    @RatioDosingEnabled      BIT,
	@EcolabAccountNumber NVARCHAR(25) = NULL,
	@PreviousFormulaDate      DATETIME2,
	@PreviousInjectionStep	INT,
	@PreviousInjectionStartDate DATETIME2,
	@CurrentInjectionStep INT,
	@WashStepBatchId INT,
	@PrevFormulaExtraTime INT      ,
	@AlarmGroupMasterId INT,
	@StdWashSteps INT,
    @StdInjectionSteps INT			                                                                                                    							

						
		IF EXISTS (SELECT  * FROM [TEMPDB].[DBO].[SYSOBJECTS] o where o.xtype in ('U') AND o.id = OBJECT_ID(N'tempdb..#XmlTagsTable'))
			BEGIN
					DROP TABLE #XmlTagsTable
			END


  CREATE TABLE  #XmlTagsTable ( TagId INT, 
										TagValue NVARCHAR(100), 
										ReceivedTime DATETIME2,
										TagType NVARCHAR(50),
										IsModified BIT
									)

	
  INSERT INTO #XmlTagsTable (
										TagId,
										TagValue,
										ReceivedTime,
										TagType,
										IsModified
									)			
		
		SELECT 		
					T.c.value('@TagId', 'INT') as TagId,
     T.c.value('@Value', 'NVARCHAR(100)') TagValue,
					T.c.value('@TimeStamp', 'VARCHAR(100)') DateTimeStamp,
					T.c.value('@TagType', 'VARCHAR(50)') TagType,
					T.c.value('@IsModified', 'BIT') TagType
  FROM  @xmlTags.nodes('Tags/Tag') T(c)
		WHERE	
					T.c.value('@TagId', 'varchar(100)')  IS NOT NULL
	
  SELECT @CurrentFormula     =  TagValue,  
    @CurrentFormulaDate    =  ReceivedTime,
    @FormulaIsModified     =  IsModified
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_FRM'   
					
  SELECT @CurrentInjection    =  TagValue,
    @CurrentInjectionDate   =  ReceivedTime,
    @InjectionIsModified   =  IsModified   
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_INJ'

  SELECT @OperationalCount    =  TagValue,
    @OperationalIsModified   =  IsModified  
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_OPC'  
			
  SELECT @EndofFormula     =  TagValue,
    @EndofFormulaDate    =  ReceivedTime  
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_EOF' 
		
  SELECT @AutoWeightEntryActive   =  TagValue     
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_AWEA'                 

  SELECT @CurrentHoldSignal    =  TagValue, 
    @HoldSignalIsModified   =  IsModified,  
    @CurrentHoldSignalDate   =  ReceivedTime 
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_HOLDL'

  SELECT @AutoWeightEntryWeight   =  TagValue     
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_AWEW'

  SELECT @MeterPlcAddress    =  TagValue,
    @MeterPlcAddressIsModified  =       IsModified       
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_MPLC'
		
  SELECT @RatioDosingEnabled    =  TagValue      
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_RATA'
		
		SELECT * FROM #XmlTagsTable
		
  SELECT @ExtraTime      =  0

  SELECT TOP 1 @BatchID=BatchId, @Prveformula=ProgramNumber,@PrevGroupId=GroupId, @PreviousFormulaDate=StartDate FROM TCD.BatchData WHERE MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC

  IF(@CurrentFormula != @EndofFormula AND
     @CurrentFormula = @Prveformula AND 
	 @CurrentInjection = 0 AND
	 @OperationalCount = 0 AND
	 @CurrentFormulaDate <= @PreviousFormulaDate AND
	 @CurrentInjectionDate > @PreviousFormulaDate)
	BEGIN
	--Here means, If the same formula is received without EOF then the timestamp of the formula
	--will be still the old timestamp because value is not changed.
	--In this case assign injection=0 timestamp to formula timestamp
	 SELECT @CurrentFormulaDate = @CurrentInjectionDate	
	END

		DECLARE @ShiftStartDate table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
		INSERT INTO @ShiftStartDate(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate,1, @RedFlagShiftId OUTPUT

		SELECT DISTINCT 
     @EcolabWasherId    =  Ws.EcolabWasherId,
     @StandardWeight    =  Wps.NominalLoad,
     @CurrencyCode    =  Pl.CurrencyCode,
     @ControllerId    =  Ctrl.ControllerId,
     @TargetTurnTime    =  Ws.TargetTurnTime * 60     
		FROM 
					TCD.Washer Ws		
		INNER JOIN 
					TCD.MachineSetup Mst ON
     Mst.WasherId    =  Ws.WasherId
		INNER JOIN 
					TCD.WasherGroup Wg ON 
     Wg.WasherGroupId   =  Mst.GroupId    
		INNER JOIN 
					TCD.WasherProgramSetup Wps ON 
     Wps.WasherGroupId   =  Wg.WasherGroupId
		LEFT JOIN 
					TCD.WasherDosingSetup Wds ON 
     Wds.WasherProgramSetupId =  Wps.WasherProgramSetupId
		LEFT JOIN 
					TCD.WasherDosingProductMapping Wdpm ON 
     Wdpm.WasherDosingSetupId =  Wds.WasherDosingSetupId
		INNER JOIN 
					TCD.Plant Pl ON 
     Pl.EcolabAccountNumber  =  Ws.EcoLabAccountNumber
		INNER JOIN 
				TCD.ConduitController Ctrl 
    ON Ctrl.ControllerId   =  Mst.ControllerId 
		WHERE Ws.WasherId= @WasherId

		SELECT DISTINCT 
					@MachineInternalId=Mst.MachineInternalId,
					@GroupId=Mst.GroupId					
		FROM TCD.Washer Ws
						INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
						INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
						INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
			WHERE Ws.WasherId=@WasherId 	

			SELECT DISTINCT 					
					@ProgramMasterId=Wps.ProgramId,
					@NominalLoad=Wps.NominalLoad, --Wps.NominalLoad/CONVERT(decimal(10,2), 100) old code
					@MaxLoad =Ws.MaxLoad,
					@ExtraTime =Wps.ExtraTime
		FROM TCD.Washer Ws
						INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
						INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
						INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
						INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
			WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@CurrentFormula and Wps.Is_Deleted=0

		if(@ExtraTime IS NULL)
		BEGIN
			SELECT @ExtraTime      =  0
		END

		SELECT  @MaxWashertGroupCapacity=Max(ws.MaxLoad)
		FROM TCD.Washer WS
			INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
			INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId		
		WHERE Mst.GroupId=@GroupId

		SELECT @WasherMeterExists = M.MachineCompartment FROM Tcd.MachineSetup Ms
		INNER JOIN Tcd.Meter M ON M.GroupId= Ms.GroupId AND  M.MachineCompartment=Ms.MachineInternalId
		WHERE Ms.WasherId=@WasherId

		if(@AutoWeightEntryActive IS NULL)
		BEGIN
			SELECT @AutoWeightEntryActive = 0
		END

		SELECT @StandardWeight=(@NominalLoad * @MaxWashertGroupCapacity) /CONVERT(decimal(10,2), 100)			
		select @AutoWeightEntryActive,@StandardWeight
		SELECT @AutoWeightEntryWeight=Case @AutoWeightEntryActive WHEN 0 THEN @StandardWeight ELSE  @AutoWeightEntryWeight END 	
		
		SELECT @CurrentHoldSignalValue=Id  FROM TCD.ConduitParameters where Name='HoldSignal'
		
		 SELECT  * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC
		IF(@HoldSignalIsModified !=0)	 
		BEGIN
		IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp =@CurrentHoldSignalDate)
			BEGIN
				INSERT INTO TCD.WasherReading(
									WasherId,
									ParameterId,
									ParameterValue,
									DateTimeStamp,
									PartitionOn,
									EcolabWasherId)
    SELECT    @WasherId,
									@CurrentHoldSignalValue,
									@CurrentHoldSignal,
									@CurrentHoldSignalDate,
									(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
									@EcolabWasherId
			END			
		END
		IF(@FormulaIsModified =1  OR @InjectionIsModified = 1 OR @OperationalIsModified = 1)
		BEGIN
			SELECT 'IsModified',@FormulaIsModified AS FormulaIsModified, 
								@InjectionIsModified AS InjectionIsModified,
								@OperationalIsModified AS OperationalIsModified
			IF(@CurrentFormula != 0)
			BEGIN
							DECLARE @BatchShiftId int,@BatchShiftStartDate datetime
							
							SELECT @BatchShiftStartDate = bd.StartDate FROM TCD.BatchData bd WHERE bd.BatchId = @BatchId

							IF(@BatchShiftStartDate > (SELECT TOP 1 [@ShiftStartDate].ShiftStartdate FROM @ShiftStartDate ORDER BY [@ShiftStartDate].ShiftStartdate ASC)
							AND DATEADD(second,@ExtraTime,@CurrentFormulaDate) > (SELECT TOP 1 [@ShiftStartDate].ShiftStartdate FROM @ShiftStartDate ORDER BY [@ShiftStartDate].ShiftStartdate DESC)
							)
							BEGIN 
								 
         SELECT TOP 1  @BatchShiftId = ssdt.ShiftId FROM @ShiftStartDate ssdt ORDER BY ssdt.ShiftStartdate DESC
							END
							ELSE
							BEGIN
        SELECT TOP 1  @BatchShiftId = ssdt.ShiftId FROM @ShiftStartDate ssdt ORDER BY ssdt.ShiftStartdate ASC
							END
							

		SELECT DISTINCT      
			@PrevFormulaExtraTime =Wps.ExtraTime
			FROM TCD.Washer Ws
				INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
				INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
				INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
				INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
				WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@Prveformula and Wps.Is_Deleted=0

		IF(@PrevFormulaExtraTime IS NULL)
		BEGIN
			SELECT @PrevFormulaExtraTime      =  0
		END

					IF(@CurrentFormula = @EndofFormula)
					BEGIN			
					SELECT * FROM #XmlTagsTable
						IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData 
								   WHERE 
											BatchId=@BatchId AND 
											MachineId=@WasherId AND 
											EndDate IS NULL 
											ORDER BY StartDate DESC  )
							BEGIN
																																							
								UPDATE TCD.BatchData 
         SET EndDate = DATEADD(second,@PrevFormulaExtraTime,@CurrentFormulaDate),EndDateFormula = @CurrentFormulaDate,ShiftId = @BatchShiftId 
       WHERE  BatchId = @BatchId AND MachineId=@WasherId   
	   
	   DECLARE @ShiftMapping1 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
	   INSERT INTO @ShiftMapping1(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate,1, @RedFlagShiftId OUTPUT

	   SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
						IF(@PreviousInjectionStep IS NOT NULL)
						BEGIN
							UPDATE TCD.BatchWashStepData SET EndTime=DATEADD(second,@ExtraTime,@CurrentFormulaDate) WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate
						END
	                                                                  
							END 
					END 
					ELSE IF((@CurrentFormula != @Prveformula) AND (@BatchID IS NOT NULL))
					BEGIN		
					IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC  )
								BEGIN																										
									UPDATE TCD.BatchData
          SET EndDate = @CurrentFormulaDate,EndDateFormula = @CurrentFormulaDate,ShiftId = @BatchShiftId 
         WHERE  BatchId = @BatchId AND MachineId=@WasherId  
		 
		   INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,19,1,(SELECT Top 1 ShiftStartdate from @ShiftStartDate) 
		   
		   DECLARE @ShiftMapping2 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
			INSERT INTO @ShiftMapping2(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate,1, @RedFlagShiftId OUTPUT
			 
			 SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
					IF(@PreviousInjectionStep IS NOT NULL)
					BEGIN
						UPDATE TCD.BatchWashStepData SET EndTime=@CurrentFormulaDate WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate
					END
			    
								END 
						END
					ELSE IF((@CurrentInjection = 0) AND(@OperationalCount = 0) AND (@CurrentFormulaDate != @PreviousFormulaDate))
					BEGIN		
					IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC)
								BEGIN																											
									UPDATE TCD.BatchData
          SET EndDate = @CurrentInjectionDate,ShiftId = @BatchShiftId,EndDateFormula = @CurrentInjectionDate
         WHERE  BatchId = @BatchId AND MachineId=@WasherId  
		 
		  INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,19,1,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)

		  DECLARE @ShiftMapping3 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
			INSERT INTO @ShiftMapping3(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentInjectionDate,1, @RedFlagShiftId OUTPUT
		    
			SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
					IF(@PreviousInjectionStep IS NOT NULL)
					BEGIN
						UPDATE TCD.BatchWashStepData SET EndTime=@CurrentInjectionDate WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate
					END

								END 
						END
			
				-- Hold Time
					IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
						BEGIN

						
						SELECT   @HoldTime=SUM(Wr.ParameterValue) FROM TCD. BatchData Bd
						INNER JOIN TCD.WasherReading Wr ON Wr.WasherId=Bd.MachineId
						WHERE Bd.BatchId=@BatchId  AND Wr.DateTimeStamp BETWEEN Bd.StartDate AND  Bd.EndDate and   Wr.ParameterId=9 -- Hold Signal value

						INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,17,@HoldTime,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)


					END
					
					-- CapturingMeter Plc Address EndRedaing 
					IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
						BEGIN
						IF(@WasherMeterExists IS NOT NULL AND @MeterPlcAddress > 0)
						BEGIN
							IF(@MeterPlcAddressIsModified !=0)	 
							BEGIN
							IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp =@CurrentFormulaDate)
							BEGIN
								INSERT INTO TCD.WasherReading(
									WasherId,
									ParameterId,
									ParameterValue,
									DateTimeStamp,
									PartitionOn,
									EcolabWasherId)
								SELECT	
									@WasherId,
									14, --MeterPlcAddress for EndSReading
									@MeterPlcAddress,
									@CurrentFormulaDate,
									(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
									@EcolabWasherId
							END

						END
						END
					END
									
					--Start Good or Bad Injection in BatchDataTable
					IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
						BEGIN
								;WITH CteTempWaherReadingInjections  (	
								InjectionsCount,BatchId,WasherId,ProgramNumber,Injectons
							) AS  
							(
								SELECT DISTINCT Wr.ParameterValue,
												BD.BatchId,
												Wr.WasherId,
												Bd.ProgramNumber,
												Wr.ParameterValue FROM TCD. BatchData Bd
								INNER JOIN 
          TCD.WasherReading Wr ON Wr.WasherId   =  Bd.MachineId 
								WHERE    
              Wr.ParameterId    =  10    AND 
              Wr.ParameterValue   <>  0    AND 
              Bd.BatchId     =  @BatchID AND WR.DateTimeStamp BETWEEN BD.StartDate AND BD.EndDate) 
								SELECT @CteTempWaherReadingInjections=COUNT(CTE1.InjectionsCount)
								FROM CteTempWaherReadingInjections CTE1 
								INNER JOIN TCD.BatchData Bd ON Bd.BatchId=CTE1.BatchId
								WHERE Bd.BatchId=@BatchId

								;WITH CteTempBatchInjections (	
								InjectionsCount,BatchId,WasherId,ProgramNumber,Injectons
							) AS  
							(
								SELECT  DISTINCT Wdpm.InjectionNumber,
												Bd.BatchId,
												Wps.ProgramNumber,
												Ws.WasherId,Wdpm.
												InjectionNumber
									FROM TCD.Washer WS
										INNER JOIN 
													TCD.MachineSetup Mst ON 
             Mst.WasherId     =  WS.WasherId
										INNER JOIN 
													TCD.WasherGroup Wg ON 
             Wg.WasherGroupId    =  Mst.GroupId       
										INNER JOIN 
													TCD.WasherProgramSetup Wps ON 
             Wps.WasherGroupId    =  Wg.WasherGroupId
										INNER JOIN 
													TCD.WasherDosingSetup Wds ON 
             Wds.WasherProgramSetupId  =  Wps.WasherProgramSetupId
										INNER JOIN 
													TCD.WasherDosingProductMapping Wdpm ON 
             Wdpm.WasherDosingSetupId  =  Wds.WasherDosingSetupID
										INNER JOIN 
													TCD.ProductdataMapping Pdm ON 
             Pdm.ProductId     =  Wdpm.ProductId
										INNER JOIN 
													TCD.BatchData Bd ON 
             Bd.MachineId     =  Ws.WasherId 
										INNER JOIN 
													TCD.WasherReading Wr ON 
             Wr.WasherId      =  Bd.MachineId
								WHERE 
								
             Wps.ProgramNumber    =  @Prveformula  AND 
             Bd.BatchId      =  @BatchID   AND 
             Ws.WasherId      =  @WasherId    )
								SELECT @CteTempBatchInjections=COUNT(CTE2.InjectionsCount)
								FROM CteTempBatchInjections CTE2 
								INNER JOIN TCD.BatchData Bd ON Bd.BatchId=CTE2.BatchId 
								WHERE Bd.BatchId=@BatchID


								Insert Tcd.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchID,@EcolabWasherId,18,
          CASE WHEN @CteTempBatchInjections = @CteTempWaherReadingInjections THEN 1
            WHEN @CteTempBatchInjections != @CteTempWaherReadingInjections THEN 3 END,
												(SELECT Top 1 ShiftStartdate from @ShiftStartDate)	
																											
				END
					--End Good or Bad Injection in BatchDataTable	
					IF(@OperationalCount = 0 AND @CurrentInjection = 0) AND (@CurrentFormula != @EndofFormula)
					BEGIN	
						IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchData WHERE MachineId=@WasherId AND StartDate =@CurrentFormulaDate)
						BEGIN					
       
							--Start Getting InjectionCount and StepCount
							SELECT 
							@StdInjectionSteps=count(DISTINCT wdpm.WasherDosingSetupId),
							@StdWashSteps= count(DISTINCT wds.WasherDosingSetupId)-count(DISTINCT wdpm.WasherDosingSetupId)
							FROM TCD.WasherDosingProductMapping wdpm
							RIGHT JOIN tcd.WasherDosingSetup wds on wdpm.WasherDosingSetupId=wds.WasherDosingSetupId
							WHERE wds.GroupId=@GroupId AND wds.ProgramNumber=@CurrentFormula
							--End Getting InjectionCount and StepCount


							INSERT INTO TCD.BatchData(
										ControllerBatchId ,
										EcolabWasherId,
										GroupId ,
										MachineInternalId,
										PlantWasherNumber,
										StartDate ,
										EndDate ,
										ProgramNumber,
										ProgramMasterId,
										MachineId,
										ActualWeight,
										StandardWeight,
										CurrencyCode,
										ShiftId,									
										PartitionOn,
										TargetTurnTime,
										StdInjectionSteps,
										StdWashSteps										
										)


									SELECT DISTINCT 0
										,@EcolabWasherId
										,@GroupId
										,@MachineInternalId
										,Ws.PlantWasherNumber
										,@CurrentFormulaDate
										,NULL
										,@CurrentFormula
										,@ProgramMasterId
										,@WasherId
										,@AutoWeightEntryWeight
										,@StandardWeight 
										,@CurrencyCode
										,(SELECT Top 1 ShiftId from @ShiftStartDate)									
										,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
										,@TargetTurnTime
										,@StdInjectionSteps
										,@StdWashSteps										

							FROM TCD.Washer Ws
										INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
										INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
										INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
							WHERE Ws.WasherId=@WasherId 
			
							SET @BatchID=SCOPE_IDENTITY()	
									
							INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,38,@StdWashSteps,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)

							--If the received formula is not configured in enVision then create an alarm 
							IF(@ProgramMasterId is NULL)
							BEGIN
							SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant;
							SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.AlarmGroupMsterVsControllerModelType AGMVCMT
							INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
							WHERE AGMVCMT.AlarmCode = 9000
								INSERT INTO [TCD].[AlarmData] 
								   (EcoalabAccountNumber,
								   AlarmCode,
								   BatchId,
								   controllerID,
								   StartDate,
								   GroupId,
								   MachineInternalId,
								   ProgramId,   
								   IsActive,
								   EndDate,
								   MachineId,
								   AlarmGroupMasterId)
									  SELECT
									   @ECOLABAccountNumber,
									   9000,
									   @BatchID,
									   @ControllerId,
									   @CurrentFormulaDate,
									   @GroupId,
									   @MachineInternalId,
									   @CurrentFormula,
									   0,
									   @CurrentFormulaDate,
									   @WasherId,
									   @AlarmGroupMasterId
							END

									
									INSERT INTO TCD.BatchCustomerData
									(
									BatchId,
									CustomerId,
									Weight,
									PiecesCount,
									PartitionOn,
									EcolabWasherId
									)
								SELECT Bd.BatchId,  
								--SELECT @BatchID,
									Pc.ID,
									@AutoWeightEntryWeight,
									ROUND(COALESCE((@AutoWeightEntryWeight * Pm.Pieces) / NULLIF(Pm.Weight,0), 0),0),
									(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
									@EcolabWasherId
								
						
							FROM TCD.Washer WS
								INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
								INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId							
								INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
								INNER JOIN TCD.ProgramMaster Pm ON Pm.ProgramId=Wps.ProgramId
								INNER JOIN TCD.PlantCustomer Pc ON Pc.ID=Pm.CustomerId
								INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
							WHERE 
								Ws.WasherId=@WasherId AND 
								Wps.ProgramNumber=@CurrentFormula AND 
								Bd.BatchId=@BatchID  AND 
								Pm.CustomerId != -1 

							IF(@WasherMeterExists IS NOT NULL AND @MeterPlcAddress > 0)
							BEGIN								
								IF(@MeterPlcAddressIsModified !=0)	 
								BEGIN
										INSERT INTO TCD.WasherReading(
											WasherId,
											ParameterId,
											ParameterValue,
											DateTimeStamp,
											PartitionOn,
											EcolabWasherId)
										SELECT	
											@WasherId,
											13, --MeterPlcAddress for StartReading
											@MeterPlcAddress,
											@CurrentFormulaDate,
											(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
											@EcolabWasherId
								END
							END	
						END														
					END	 				
					IF(@BatchID IS NOT NULL)					
					BEGIN
					IF(@CurrentInjection <= 0)
						BEGIN
							SET @CurrentInjectionDate=@CurrentFormulaDate
						END	
						IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp =@CurrentInjectionDate)
						BEGIN						
						INSERT INTO TCD.WasherReading(
										WasherId,
										ParameterId,
										ParameterValue,
										DateTimeStamp,
										PartitionOn,
										EcolabWasherId)
      SELECT   @WasherId,
										CASE TagType 
										WHEN 'Tag_FRM' THEN  5  
										WHEN 'Tag_INJ' THEN  10 
										WHEN 'Tag_OPC' THEN  11 
										END,
										TagValue,										
										@CurrentInjectionDate,
										(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
										@EcolabWasherId
       FROM  #XmlTagsTable 
       WHERE  Tagtype in ('Tag_FRM','Tag_INJ','Tag_OPC')         
					END
					END
				IF(@CurrentInjection > 0)					
					BEGIN
						IF (@RatioDosingEnabled = 1)
							BEGIN
							IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurrentInjectionDate and batchid=@BatchID)
							BEGIN
								INSERT INTO TCD.BatchProductData(BatchId,StepCompartment,ActualQuantity,StandardQuantity,Price,TimeStamp,PartitionOn,EcolabWasherId,ProductId)
								SELECT Bd.BatchId	
								--SELECT @BatchID	
									,Wds.StepNumber
         ,(((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100)) * (@AutoWeightEntryWeight/@StandardWeight) AS ActualQuantity  
         ,(((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100)) * (@AutoWeightEntryWeight/@StandardWeight) AS StandardQuantity      
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * @MaxWashertGroupCapacity)/CONVERT(decimal(10,2), 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price         
									,@CurrentInjectionDate
									,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
									,@EcolabWasherId
									,Pdm.ProductID
								FROM TCD.Washer WS
									INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
									INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
									INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
									INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
									INNER JOIN TCD.WasherDosingSetup Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
									INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
									INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Wdpm.ProductId
									INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
								WHERE 
          Ws.WasherId=@WasherId     AND 
          Wps.ProgramNumber=@CurrentFormula  AND 
          Wdpm.InjectionNumber=@CurrentInjection AND
										Bd.BatchId=@BatchID AND
		  Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
							END
							END
						ELSE
							BEGIN
							IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurrentInjectionDate and batchid=@BatchID)
							BEGIN
								INSERT INTO TCD.BatchProductData(BatchId,StepCompartment,ActualQuantity,StandardQuantity,Price,TimeStamp,PartitionOn,EcolabWasherId,ProductId)
								SELECT Bd.BatchId		
								--SELECT @BatchID
									,Wds.StepNumber
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100) AS ActualQuantity  
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100) AS StandardQuantity      
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * @MaxWashertGroupCapacity)/CONVERT(decimal(10,2), 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price         
									,@CurrentInjectionDate
									,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
									,@EcolabWasherId
									,Pdm.ProductID
								FROM TCD.Washer WS
									INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
									INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
									INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
									INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
									INNER JOIN TCD.WasherDosingSetup Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
									INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
									INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Wdpm.ProductId
									INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
								WHERE 
          Ws.WasherId=@WasherId     AND 
          Wps.ProgramNumber=@CurrentFormula  AND 
          Wdpm.InjectionNumber=@CurrentInjection AND
										Bd.BatchId=@BatchID AND
		  Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
							END		
							END	
							
		--Populating BatchWashstepdata
						SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
						
						IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchWashStepData WHERE StartTime =@CurrentInjectionDate and batchid=@BatchID)
						BEGIN
									SELECT @CurrentInjectionStep=Wds.StepNumber,
										   @WashStepBatchId=Bd.BatchId
         								
									FROM TCD.Washer WS
										INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
										INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
										INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
										INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
										INNER JOIN TCD.WasherDosingSetup Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
										INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
										INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Wdpm.ProductId
										INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
									WHERE 
										Ws.WasherId=@WasherId     AND 
										Wps.ProgramNumber=@CurrentFormula  AND 
										Wdpm.InjectionNumber=@CurrentInjection AND
										Bd.BatchId=@BatchID AND
										Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0

									IF(@CurrentInjectionStep IS NOT NULL)
									BEGIN
										INSERT INTO TCD.BatchWashStepData(BatchId,StepCompartment,StartTime,PartitionOn,EcolabWasherId)
										VALUES (@WashStepBatchId,  @CurrentInjectionStep, @CurrentInjectionDate, (SELECT Top 1 ShiftStartdate from @ShiftStartDate), @EcolabWasherId)																
									
										UPDATE TCD.BatchWashStepData SET EndTime=@CurrentInjectionDate WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate									
									END

						END
						--End Populating BatchWashstepdata

						--Start Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
						IF NOT EXISTS(SELECT * FROM TCD.BatchParameters WHERE ParameterId =37 and batchid=@BatchID)
						BEGIN
							INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,37,1,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)							
						END
						ELSE
						BEGIN
							Update TCD.BatchParameters SET ParameterValue=@CurrentInjection WHERE ParameterId =37 and batchid=@BatchID
						END
	  					--End Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record

											
					END

					UPDATE TCD.ConduitController
      SET LastConnectedTime  = GETUTCDATE()
      WHERE ControllerId   = @ControllerId
			END
		END
	END

	
	
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessTunnelWasherData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessTunnelWasherData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [TCD].[ProcessTunnelWasherData]
	(	
	@WasherId INT,	
	@xmlTags XML,
	@RedFlagShiftId INT OUTPUT
)
AS
BEGIN
		DECLARE @BatchID						INT,
				@EcolabWasherId					INT,								
				@CurrencyCode					VARCHAR(50),		
				@MachineInternalId				INT ,
				@GroupId						INT,		
				@Prveformula					INT,
				@Quantity						INT,
				@MaxWashertGroupCapacity		INT,
				@PrevBatchId					INT,
				@PrevLoadId						INT,
				@ExistedLoadId					INT,
				@NumberOfCompartments			INT,

				@ProgramMasterId				INT,
				@NominalLoad					Decimal(10,2),
				@MaxLoad						Decimal(10,2),
				@StandardWeight					Decimal(10,2) , 				
				@PlantWasherNumber				INT,
											
				@CurrentDay						DATE=CAST(GETUTCDATE() as date),
				@TempTunnelTimeStamp			DATETIME2,

				@ControllerId					INT ,
				@CurrentHoldSignal				INT,
				
				@TotalRunTime					INT,
				@BatchGroupId					INT,
				@BatchFormula					INT,
				@BatchStartDate					DATETIME2,
				@BatchEndDate					DATETIME2,
				@HoldTime						INT,
				@CteTempBatchTunnelWashSteps	INT,
				@CteTemTunnelWashSetps			INT,
				@PrevFormula					INT,
				@PrevStepCompartment			INT,
				@BatchStandardWaterUsage		INT,
				@BatchActualWaterUsage			INT,
				@BatchWaterUsagePrice			Decimal(10,2),
				@BatchUtilityPrice				Decimal(10,2),
				@BatchWaterType					INT,
				@ExtraTime						INT,
				@TargetTurnTime					INT,
				@EcolabAccountNumber NVARCHAR(25) = NULL,
				@AlarmGroupMasterId INT,
				@PartitionOn SMALLDATETIME,
				@StdInjectionSteps INT,
				@StdWashSteps INT
	                              							
		SELECT @ExtraTime = 0

		SELECT DISTINCT 					
					@NumberOfCompartments=MST.NumberOfComp,
					@EcolabWasherId=Ws.EcolabWasherId
			FROM		TCD.Washer Ws
			INNER JOIN 
						TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId					
		WHERE Ws.WasherId=@WasherId and Ws.Is_Deleted=0
		
				
		IF EXISTS (SELECT  * FROM TEMPDB.DBO.SYSOBJECTS o where o.xtype in ('U') AND o.id = OBJECT_ID(N'tempdb..#XmlTagsTable'))
			BEGIN
					DROP TABLE #XmlTagsTable
			END
		CREATE TABLE  #XmlTagsTable (	CurrentFormula				INT,
										CurretnInjection			INT,
										CurrentOperationCounter		INT,
										Eof							INT,
										TunnelTimeStamp				DATETIME2,
										OnHold						BIT,										
										CompartmentId				INT, 
										CompartmentLoadId			INT, 
										CompartmentFormulaId		INT,										
										ReceivedTime				DATETIME2,
										AutoWeightEntryActive		VARCHAR(10),
										AutoWeightEntryWeight		INT,
										IsFormulaModified			BIT,
										IsHoldSignalModified		BIT	,
										IsStopSinalModified			BIT,
										StopSignal					INT,
										RatioDosingEnabled			INT						
									)
		INSERT INTO #XmlTagsTable	(
										CurrentFormula	,
										CurretnInjection,										
										CurrentOperationCounter,
										Eof,
										TunnelTimeStamp	,
										OnHold,
										CompartmentId, 
										CompartmentLoadId, 
										CompartmentFormulaId,
										ReceivedTime,
										AutoWeightEntryActive,
										AutoWeightEntryWeight,
										IsFormulaModified,
										IsHoldSignalModified,
										IsStopSinalModified,
										StopSignal,
										RatioDosingEnabled
									)			
		
		-- Populate tempdata from xml
		SELECT	T.c.value('../@CurrentFormula', 'INT') AS CurrentFormula, 
				T.c.value('../@CurrentInjection', 'INT') AS CurretnInjection, 				
				T.c.value('../@CurrentOperationCounter', 'INT') AS CurrentOperationCounter, 						
				T.c.value('../@Eof', 'INT') AS EndofFormula, 
				T.c.value('../@TimeStamp', 'VARCHAR(100)') AS TunnelTimeStamp, 
				T.c.value('../@OnHold', 'VARCHAR(100)') AS OnHold, 
				T.c.value('@CompartmentId', 'INT') AS CompartmentId, 
				T.c.value('@LoadId', 'INT') AS CompartmentLoadId, 
				T.c.value('@FormulaId', 'INT') AS CompartmentFormulaId, 				
				T.c.value('@TimeStamp', 'VARCHAR(100)') DateTimeStamp,
				T.c.value('../@Awea', 'VARCHAR(10)') AS AutoWeightEntryActive, 				
				T.c.value('../@Awew', 'INT') AS AutoWeightEntryWeight,	
				T.c.value('../@IsFormulaModified', 'BIT') AS IsFormulaModified,
				T.c.value('../@IsHoldSignalModified', 'BIT') AS IsHoldSignalModified,
				T.c.value('../@IsStopSinalModified', 'BIT') AS IsStopSinalModified,
				T.c.value('../@StopSignal', 'INT') AS StopSignal,
				T.c.value('../@RATA', 'INT') AS RatioDosingEnabled
				
				
		
		FROM @xmlTags.nodes('/Tunnel/Compartment')  T(c)

		
		WHERE	
		T.c.value('@LoadId', 'VARCHAR(100)')  != 0
		AND
		T.c.value('@CompartmentId', 'INT')    <= @NumberOfCompartments
		
		IF EXISTS (SELECT 1 FROM #XmlTagsTable where IsHoldSignalModified = 1)	 
			BEGIN			
				SELECT	@CurrentHoldSignal = Id  FROM TCD.ConduitParameters where Name='HoldSignal'
				INSERT INTO TCD.WasherReading(
								WasherId,
								ParameterId,
								ParameterValue,
								DateTimeStamp,
								EcolabWasherId)
					SELECT		@WasherId,
								@CurrentHoldSignal,
								OnHold,
								ReceivedTime,
								@EcolabWasherId	
					FROM #XmlTagsTable
			END	
		IF EXISTS (SELECT 1 FROM #XmlTagsTable where IsStopSinalModified = 1)	 
			BEGIN	
				INSERT INTO TCD.WasherReading(
							WasherId,
							ParameterId,
							ParameterValue,
							DateTimeStamp,
							EcolabWasherId)
				SELECT		@WasherId,
							12,
							StopSignal,
							ReceivedTime,
							@EcolabWasherId
				FROM #XmlTagsTable
			END	
		IF EXISTS (SELECT 1 FROM #XmlTagsTable where IsFormulaModified = 1)	 
			BEGIN
		
			-- Start find missing load id form xml  and set end date for corresponding enddates in the database
			DECLARE @TempExisitingLoadIds table(ExstingLoadId INT,ExistsBatchId int)
			INSERT INTO @TempExisitingLoadIds(ExstingLoadId,ExistsBatchId)
				SELECT Bd.ControllerBatchId,Bd.BatchId FROM TCD.BatchData Bd					
					--INNER JOIN TCD.BatchWashStepData Bwsd on Bwsd.BatchId=Bd.BatchId
				WHERE Bd.MachineId=@WasherId AND Bd.EndDate IS NULL ORDER BY Bd.StartDate DESC			
		
			SELECT @TempTunnelTimeStamp =(SELECT T.c.value('./@TimeStamp', 'VARCHAR(100)') AS TunnelTimeStamp	FROM @xmlTags.nodes('/Tunnel')  T(c))
			
			DECLARE @TempBatchStepIs TABLE(StepBatchId INT)
			INSERT INTO @TempBatchStepIs (StepBatchId)
			SELECT ExistsBatchId 
				FROM @TempExisitingLoadIds 
				WHERE ExstingLoadId NOT IN (SELECT CompartmentLoadId FROM #XmlTagsTable)
		
		SELECT @PrevStepCompartment=StepCompartment,@PrevBatchId =BatchID 
		FROM TCD.BatchWashStepData  
		WHERE BatchId in (select StepBatchId from @TempBatchStepIs) AND EndTime IS NULL

		UPDATE 
		TCD.BatchWashStepData 
		SET EndTime = @TempTunnelTimeStamp
		WHERE BatchId in (select StepBatchId from @TempBatchStepIs) AND EndTime IS NULL

		DECLARE @BatchShiftId int
		DECLARE @ShiftStartDateTemp table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
		INSERT INTO @ShiftStartDateTemp(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @TempTunnelTimeStamp,1, @RedFlagShiftId OUTPUT
		SELECT @BatchShiftId = ssdt.ShiftId FROM @ShiftStartDateTemp ssdt ORDER BY ssdt.ShiftStartdate

		-- Updating Batches moved out of the tunnel
		UPDATE TCD.BatchData 
		SET		
				EndDate=@TempTunnelTimeStamp
			,	EndDateFormula=@TempTunnelTimeStamp,
			ShiftId = @BatchShiftId
		WHERE BatchId in (select StepBatchId from @TempBatchStepIs)

		--End find missing load id form xml  and set end date for corresponding enddates in the database
		 
		--Start HoldTime Calculation
			SELECT 
					@BatchGroupId=GroupId
				,	@BatchFormula=ProgramNumber
				,	@BatchStartDate=StartDate
				,	@BatchEndDate=EndDate 
			FROM TCD.BatchData 
			WHERE BatchId IN (select		StepBatchId from @TempBatchStepIs)

			SELECT @TotalRunTime=TotalRunTime 
			FROM TCD.TunnelProgramSetup 
			WHERE	WasherGroupId =@BatchGroupId 
				AND ProgramNumber=@BatchFormula

			
			INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) 
			SELECT StepBatchId,@EcolabWasherId,17,(DATEDIFF(SECOND, @BatchStartDate, @BatchEndDate))-@TotalRunTime,bd.partitionon
            FROM @TempBatchStepIs,TCD.BatchData bd WHERE bd.BatchId= [@TempBatchStepIs].StepBatchId  and [@TempBatchStepIs].StepBatchId NOT IN (SELECT BATCHID FROM TCD.BatchParameters AS BP WHERE BP.ParameterId = 17)
 
		--End HoldTime Calculation

			 --Start Good or Bad Injection in BatchDataTable
					IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@PrevBatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
						BEGIN
					
							;WITH CteTempBatchTunnelStepData  (	
								InjectionsCount,BatchId,ProgramNumber
							) AS  
							(
								SELECT DISTINCT Bws.StepCompartment,
												BD.BatchId,												
												Bd.ProgramNumber
												FROM TCD. BatchData Bd
								INNER JOIN 
										TCD.BatchWashStepData Bws 
															ON Bws.BatchId			=		Bd.BatchId 
								WHERE    
														
														Bd.BatchId					=		@PrevBatchId ) 
								SELECT @CteTemTunnelWashSetps=COUNT(CTE1.InjectionsCount)
								FROM CteTempBatchTunnelStepData CTE1 
								INNER JOIN TCD.BatchData Bd ON Bd.BatchId=CTE1.BatchId
								WHERE Bd.BatchId=@BatchId

								;WITH CteTempBatchInjections (	
								InjectionsCount,ProgramNumber
							) AS  
							(
								SELECT  DISTINCT 
												
												Tds.CompartmentNumber,
												Tps.ProgramNumber
									 	FROM TCD.TunnelProgramSetup Tps 
										INNER JOIN 
													TCD.TunnelDosingSetup Tds ON 
														Tds.TunnelProgramSetupId	=		Tps.TunnelProgramSetupId
										INNER JOIN 
													TCD.TunnelDosingProductMapping Tdpm ON 
													Tdpm.TunnelDosingSetupId		=		Tds.TunnelDosingSetupId
										INNER JOIN 
													TCD.ControllerEquipmentSetup Ces ON 
													Ces.ControllerEquipmentSetupId	=		Tdpm.ControllerEquipmentSetupId
													WHERE 																		 								
													Tps.ProgramNumber				=		@PrevFormula )
								SELECT @CteTempBatchTunnelWashSteps=COUNT(CTE2.InjectionsCount)
								FROM CteTempBatchInjections CTE2 

										Insert Tcd.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @PrevBatchId,@EcolabWasherId,18,
										CASE	WHEN @CteTempBatchTunnelWashSteps	=	@CteTemTunnelWashSetps THEN 1
												WHEN @CteTempBatchTunnelWashSteps	!=	@CteTemTunnelWashSetps THEN 3 END,
												(SELECT PartitionOn FROM TCD.BatchData where BatchId=@PrevBatchId and MachineId=@WasherId)
														
														
																
				END

			-- End Good or Bad Injection in BatchDataTable


	-- Fetching data from cursor
			DECLARE @MYCURSOR CURSOR
			SET @MYCURSOR = CURSOR FAST_FORWARD
			FOR
			SELECT		CurrentFormula	,
						CurretnInjection,										
						CurrentOperationCounter,
						Eof,
						TunnelTimeStamp	,
						OnHold,
						CompartmentId, 
						CompartmentLoadId, 
						CompartmentFormulaId,
						ReceivedTime,
						AutoWeightEntryActive,
						AutoWeightEntryWeight,
						IsFormulaModified,
						IsHoldSignalModified,
						IsStopSinalModified,
						StopSignal,
						RatioDosingEnabled

				FROM #XmlTagsTable ORDER BY CompartmentId ASC
			DECLARE			@CurCurrentFormula					INT,
							@CurCurretnInjection			INT,
							@CurCurrentOperationCounter		INT,
							@CurEof							INT,
							@CurTunnelTimeStamp				DATETIME2,
							@CurOnHold						BIT,
							@CurCompartmentId				INT, 
							@CurCompartmentLoadId			INT, 
							@CurCompartmentFormulaId		INT,
							@CurReceivedTime				DATETIME2,
							@AutoWeightEntryActive			VARCHAR(10),
							@AutoWeightEntryWeight			INT,
							@IsFormulaModified				BIT,
							@IsHoldSignalModified			BIT,
							@IsStopSinalModified			BIT,
							@StopSignal						INT,
							@RatioDosingEnabled				INT	

			OPEN @MYCURSOR
			FETCH NEXT FROM @MYCURSOR
							INTO @CurCurrentFormula			,
							@CurCurretnInjection			,
							@CurCurrentOperationCounter		,
							@CurEof							,
							@CurTunnelTimeStamp				,
							@CurOnHold						,
							@CurCompartmentId				, 
							@CurCompartmentLoadId			, 
							@CurCompartmentFormulaId		,
							@CurReceivedTime				,
							@AutoWeightEntryActive			,
							@AutoWeightEntryWeight			,
							@IsFormulaModified				,
							@IsHoldSignalModified			,
							@IsStopSinalModified			,
							@StopSignal						,
							@RatioDosingEnabled
			WHILE @@FETCH_STATUS = 0
			BEGIN
				

			IF(@IsFormulaModified !=0)	
			BEGIN
				IF(@CurCurrentFormula != @CurEof and @CurCurretnInjection = 0 and @CurCurrentOperationCounter = 0)
					BEGIN

			SELECT DISTINCT 							
							@MachineInternalId			=	Mst.MachineInternalId,
							@GroupId					=	Mst.GroupId,
							@ControllerId				=	Ctrl.ControllerId				
					FROM TCD.Washer Ws
						INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
						INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
						INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
						INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId	=	Mst.ControllerId
					WHERE Ws.WasherId=@WasherId 	

				SELECT DISTINCT 
							@ProgramMasterId			=	Wps.ProgramId,
							@NominalLoad				=	Wps.NominalLoad,
							@MaxLoad					=	Ws.MaxLoad,
							@CurrencyCode				=	Pl.CurrencyCode, 
							@TargetTurnTime				=   (3600/(Wps.TotalRunTime/Mst.NumberofComp))

				FROM TCD.Washer Ws
						INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
						INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
						INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
						INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
						INNER JOIN TCD.Plant Pl ON Pl.EcolabAccountNumber	=		Ws.EcoLabAccountNumber
						
				WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@CurCurrentFormula and Wps.Is_Deleted=0

				select @PlantWasherNumber = plantwashernumber from tcd.washer where washerid = @WasherId
	
				SELECT  @MaxWashertGroupCapacity		=	Max(ws.MaxLoad)
				FROM TCD.Washer WS
					INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
					INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId		
				WHERE Mst.GroupId=@GroupId

				SELECT @StandardWeight					=	@NominalLoad  								
				SELECT @AutoWeightEntryWeight=Case @AutoWeightEntryActive WHEN 'False' THEN @StandardWeight ELSE  @AutoWeightEntryWeight END 
				
						
				SELECT @MachineInternalId,@GroupId,@ProgramMasterId,@NominalLoad,@WasherId,@CurCurrentFormula,@PrevBatchId
				SELECT @CurCurrentFormula				AS CurCurrentFormula			,
							@CurCurretnInjection		AS CurCurretnInjection		,
							@CurCurrentOperationCounter	AS CurCurrentOperationCounter	,
							@CurEof						AS CurEof 		,
							@CurTunnelTimeStamp			AS CurTunnelTimeStamp		,
							@CurOnHold					AS CurOnHold			,
							@CurCompartmentId			AS CurCompartmentId			, 
							@CurCompartmentLoadId		AS CurCompartmentLoadId 		, 
							@CurCompartmentFormulaId	AS CurCompartmentFormulaId		,
							@CurReceivedTime			AS CurReceivedTime,
							@AutoWeightEntryActive		AS AutoWeightEntryActive,
							@AutoWeightEntryWeight		AS AutoWeightEntryWeight,
							@IsFormulaModified			AS IsFormulaModified
		
		IF(@CurCompartmentFormulaId > 0)
		BEGIN
					UPDATE TCD.ConduitController
					SET LastConnectedTime		=	GETUTCDATE()
					WHERE ControllerId			=	@ControllerId
		END
		
		
		IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchData WHERE MachineId=@WasherId AND StartDate =@CurTunnelTimeStamp)
		BEGIN

			DECLARE @ShiftStartDate table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
			INSERT INTO @ShiftStartDate(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurTunnelTimeStamp,0, @RedFlagShiftId OUTPUT

			--Start Getting InjectionCount,StepCount And ProductCount
			SELECT @StdInjectionSteps= count(tdpm.TunnelDosingSetupId) ,
			@StdWashSteps= count(DISTINCT tds.TunnelDosingSetupId)-count(tdpm.TunnelDosingSetupId) 
			FROM TCD.TunnelDosingProductMapping tdpm
			RIGHT JOIN tcd.TunnelDosingSetup tds on tdpm.TunnelDosingSetupId=tds.TunnelDosingSetupId
			WHERE tds.GroupId=@GroupId AND tds.ProgramNumber=@CurCurrentFormula

				-- New Batch Creation
							INSERT INTO TCD.BatchData(
											ControllerBatchId ,
											EcolabWasherId,
											GroupId ,
											MachineInternalId,
											PlantWasherNumber,
											StartDate ,
											EndDate ,
											ProgramNumber,
											ProgramMasterId,
											MachineId,
											ActualWeight,
											StandardWeight,
											CurrencyCode,
											ShiftId,
											PartitionOn,
											TargetTurnTime,
											StdInjectionSteps,
											StdWashSteps
											)


										SELECT DISTINCT @CurCompartmentLoadId
											,@EcolabWasherId
											,@GroupId
											,@MachineInternalId
											,@PlantWasherNumber
											--,@CurReceivedTime
											,@CurTunnelTimeStamp
											,NULL
											,@CurCurrentFormula
											,@ProgramMasterId
											,@WasherId
											,@AutoWeightEntryWeight
											,@StandardWeight 
											,@CurrencyCode
											,(SELECT Top 1 ShiftId from @ShiftStartDate)
											,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
											,@TargetTurnTime
											,@StdInjectionSteps
											,@StdWashSteps

								
			
								SET @BatchID=SCOPE_IDENTITY()	

								--Start insert InjectionActualCount and StepActualCount in TCD.BatchParameters
								INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchID,@EcolabWasherId,37,@StdInjectionSteps,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
								INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchID,@EcolabWasherId,38,@StdWashSteps,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)  
								--End insert InjectionActualCount and StepActualCount in TCD.BatchParameters

								--If the received formula is not configured in enVision then create an alarm 
							IF(@ProgramMasterId is NULL)
							BEGIN
							SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant
							SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.AlarmGroupMsterVsControllerModelType AGMVCMT
							INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
							WHERE AGMVCMT.AlarmCode = 9000
								INSERT INTO [TCD].[AlarmData] 
								   (EcoalabAccountNumber,
								   AlarmCode,
								   BatchId,
								   controllerID,
								   StartDate,
								   GroupId,
								   MachineInternalId,
								   ProgramId,   
								   IsActive,
								   EndDate,
								   MachineId,
								   AlarmGroupMasterId)
									  SELECT
									   @ECOLABAccountNumber,
									   9000,
									   @BatchID,
									   @ControllerId,
									   @CurTunnelTimeStamp,
									   @GroupId,
									   @MachineInternalId,
									   @CurCurrentFormula,
									   0,
									   @CurTunnelTimeStamp,
									   @WasherId,
									   @AlarmGroupMasterId
							END


						-- Wash Step Information		
						INSERT INTO TCD.BatchWashStepData(
											BatchId
											,StepCompartment
											,StartTime
											,EndTime
											,PartitionOn
											,EcolabWasherId) 				
						SELECT	
											@BatchID,
											@CurCompartmentId,
											@CurTunnelTimeStamp,
											--@CurReceivedTime,
											NULL,
											(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
											@EcolabWasherId
						-- Product Usage
				IF (@RatioDosingEnabled = 1)
					BEGIN
						INSERT INTO TCD.BatchProductData(
									BatchId,
									StepCompartment,
									ActualQuantity,
									StandardQuantity,
									Price,
									[TimeStamp],
									PartitionOn,
									EcolabWasherId,
									ProductId
						)					
						SELECT DISTINCT @BatchID	
										,@CurCompartmentId
										,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * (@AutoWeightEntryWeight/@StandardWeight) AS ActualQuantity						
										,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * (@AutoWeightEntryWeight/@StandardWeight) AS StandardQuantity										
										,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price	
										,@CurTunnelTimeStamp								
										--,@CurReceivedTime
										,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
										,@EcolabWasherId
										,Pdm.ProductID
							FROM TCD.Washer WS
							INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
							INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
							INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
							INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
							INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
							INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
							INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId=Wdpm.ControllerEquipmentSetupId
							INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Ces.ProductId
							--INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
						WHERE 
								Ws.WasherId=@WasherId AND 
								Wps.ProgramNumber=@CurCurrentFormula AND 
								Wds.CompartmentNumber=@CurCompartmentId	AND
								Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
					END
				ELSE
					BEGIN
						INSERT INTO TCD.BatchProductData(
									BatchId,
									StepCompartment,
									ActualQuantity,
									StandardQuantity,
									Price,
									[TimeStamp],
									PartitionOn,
									EcolabWasherId,
									ProductId
						)					
						SELECT DISTINCT @BatchID	
										,@CurCompartmentId
										,((Wps.NominalLoad * Wdpm.Quantity)/ 100) AS ActualQuantity						
										,((Wps.NominalLoad * Wdpm.Quantity)/ 100) AS StandardQuantity										
										,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price
										,@CurTunnelTimeStamp									
										--,@CurReceivedTime
										,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
										,@EcolabWasherId
										,Pdm.ProductID
							FROM TCD.Washer WS
							INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
							INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
							INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
							INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
							INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
							INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
							INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId=Wdpm.ControllerEquipmentSetupId
							INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Ces.ProductId
							--INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
						WHERE 
								Ws.WasherId=@WasherId AND 
								Wps.ProgramNumber=@CurCurrentFormula AND 
								Wds.CompartmentNumber=@CurCompartmentId	AND
								Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
					END			
								
								
						-- Transfer Signal		
								INSERT INTO TCD.WasherReading(
															WasherId,
															ParameterId,
															ParameterValue,
															DateTimeStamp,
															PartitionOn,
															EcolabWasherId)
									SELECT @WasherId,
											6,
											1,
											@TempTunnelTimeStamp,
											(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
											@EcolabWasherId
									UNION ALL
									SELECT @WasherId,
											6,
											0,
											GETUTCDATE(),
											(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
											@EcolabWasherId
			
						-- Insert Customer Data
						INSERT INTO TCD.BatchCustomerData(
										BatchId,
										CustomerId,
										Weight,
										PiecesCount,
										PartitionOn,
										EcolabWasherId
										)
						SELECT DISTINCT	
										Bd.BatchId,		
										Pc.ID,
										@AutoWeightEntryWeight,
										ROUND(COALESCE((@AutoWeightEntryWeight * Pm.Pieces) / NULLIF(Pm.Weight,0), 0),0),
										(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
										@EcolabWasherId
						
						FROM TCD.Washer WS
							INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
							INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId							
							INNER JOIN TCD.TunnelProgramSetup Tps ON Tps.WasherGroupId = Wg.WasherGroupId
							INNER JOIN TCD.ProgramMaster Pm ON Pm.ProgramId=Tps.ProgramId
							INNER JOIN TCD.PlantCustomer Pc ON Pc.ID=Pm.CustomerId
							INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
						WHERE 
							Ws.WasherId=@WasherId AND 
							Tps.ProgramNumber=@CurCompartmentFormulaId AND 
							Bd.BatchId=@BatchID	  AND 
							Pm.CustomerId != -1
							AND Pm.[Weight] > 0
		END

		ELSE
		BEGIN
			SELECT @BatchID=BatchId, @PartitionOn=PartitionOn
			FROM TCD.BatchData 
			WHERE MachineId=@WasherId 
			AND ControllerBatchId=@CurCompartmentLoadId
			
			IF(@BatchID IS NOT NULL)
			BEGIN
			UPDATE TCD.BatchWashStepData 
				SET EndTime=@CurTunnelTimeStamp
			WHERE BatchId=@BatchId 
				AND StepCompartment=@CurCompartmentId-1

				IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchWashStepData WHERE StartTime=@CurTunnelTimeStamp and BatchId=@BatchID)
				BEGIN
					INSERT INTO TCD.BatchWashStepData(
											BatchId
											,StepCompartment
											,StartTime
											,EndTime
											,PartitionOn
											,EcolabWasherId) 				
						SELECT	
											@BatchID,
											@CurCompartmentId,
											@CurTunnelTimeStamp,
											--@CurReceivedTime,
											NULL,
											@PartitionOn,
											@EcolabWasherId
				END							
				IF (@RatioDosingEnabled = 1)
					BEGIN
					IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurTunnelTimeStamp and BatchId=@BatchID)
					BEGIN
						INSERT INTO TCD.BatchProductData(
									BatchId,
									StepCompartment,
									ActualQuantity,
									StandardQuantity,
									Price,
									[TimeStamp],
									PartitionOn,
									EcolabWasherId,
									ProductId
									)
						SELECT DISTINCT 
									@BatchID	
									,@CurCompartmentId
									,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * (@AutoWeightEntryWeight/@StandardWeight) AS ActualQuantity							
									,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * (@AutoWeightEntryWeight/@StandardWeight) AS StandardQuantity	
									,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price
									,@CurTunnelTimeStamp									
									--,@CurReceivedTime
									,@PartitionOn
									,@EcolabWasherId
									,Pdm.ProductID
						FROM TCD.Washer WS
						INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
						INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
						INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
						INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
						INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
						INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
						INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId=Wdpm.ControllerEquipmentSetupId
						INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Ces.ProductId
						--INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
						WHERE 
							Ws.WasherId=@WasherId 
							AND Wps.ProgramNumber=@CurCompartmentFormulaId 
							AND Wds.CompartmentNumber=@CurCompartmentId	AND
							Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
					END
				END -- end of ratio dosing if
				ELSE
					BEGIN
					IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurTunnelTimeStamp and BatchId=@BatchID)
					BEGIN
					INSERT INTO TCD.BatchProductData(
									BatchId,
									StepCompartment,
									ActualQuantity,
									StandardQuantity,
									Price,
									[TimeStamp],
									PartitionOn,
									EcolabWasherId,
									ProductId
									)
					SELECT DISTINCT 
									@BatchID	
									,@CurCompartmentId
									,((Wps.NominalLoad * Wdpm.Quantity)/ 100) AS ActualQuantity							
									,((Wps.NominalLoad * Wdpm.Quantity)/ 100) AS StandardQuantity	
									,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price
									,@CurTunnelTimeStamp									
									--,@CurReceivedTime
									,@PartitionOn
									,@EcolabWasherId
									,Pdm.ProductID
						FROM TCD.Washer WS
						INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
						INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
						INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
						INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
						INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
						INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
						INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId=Wdpm.ControllerEquipmentSetupId
						INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Ces.ProductId
								
					WHERE 
							Ws.WasherId=@WasherId 
							AND Wps.ProgramNumber=@CurCompartmentFormulaId 
							AND Wds.CompartmentNumber=@CurCompartmentId	AND
								Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0	
			END
			END								
				END -- end of BatchId NULL if
			END -- end of else
		END		-- end of IF(@CurCurrentFormula != @CurEof and @CurCurretnInjection = 0 and @CurCurrentOperationCounter = 0)							
	END		-- end of IF(@IsFormulaModified !=0)	
															
			FETCH NEXT FROM @MYCURSOR
			INTO @CurCurrentFormula			,
							@CurCurretnInjection			,
							@CurCurrentOperationCounter		,
							@CurEof							,
							@CurTunnelTimeStamp				,
							@CurOnHold						,
							@CurCompartmentId				, 
							@CurCompartmentLoadId			, 
							@CurCompartmentFormulaId		,
							@CurReceivedTime				,
							@AutoWeightEntryActive			,
							@AutoWeightEntryWeight			,
							@IsFormulaModified				,
							@IsHoldSignalModified			,
							@IsStopSinalModified			,
							@StopSignal						,
							@RatioDosingEnabled
			END
			CLOSE @MYCURSOR
			DEALLOCATE @MYCURSOR	
			
		
		END
END

--Conduit Paramters for BatchStatus tracking
GO
IF NOT EXISTS(SELECT * FROM TCD.ConduitParameters WHERE Id=37)
BEGIN
	INSERT INTO TCD.ConduitParameters (Id,Name,Description,MandatoryCol,IsActive,SortOrder,IsTrending)
	VALUES (37, 'Number of Injection/Dosage Steps', 'Number of Injection/Dosage Steps', 0, 1, 37, 1)
END

IF NOT EXISTS(SELECT * FROM TCD.ConduitParameters WHERE Id=38)
BEGIN
	INSERT INTO TCD.ConduitParameters (Id,Name,Description,MandatoryCol,IsActive,SortOrder,IsTrending)
	VALUES (38, 'Number of Wash Steps', 'Number of Wash Steps', 0, 1, 38, 1)
END

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessConventionalOnlineDataForPLCXL]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessConventionalOnlineDataForPLCXL]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE Procedure [TCD].[ProcessConventionalOnlineDataForPLCXL](@ControllerID int, @VxML xML, @RedFlagShiftId INT OUTPUT)
AS
BEGIN




   DECLARE 
			@MachineNumber int,
			@StepNumber	int,
			@StartDateTime DateTime,
			@EndDateTime  DateTime,
			@ProgramNumber int,
			@Load decimal(10,2),
			@NominalLoad decimal(10,2),
			@CustomerNumber int,
			@WaterConsumption1 int,
			@WaterConsumption2 int,
			@PHStatus int,
			@PHValue int,
			@TemperatureMin int,
			@TemperatureMax int,
			@TempMinStatus int,
			@TempMaxStatus int,
			@BatchNumber int,
		    @WasherID int,
			@WasherGroupID int,
			@EcoLabWasherID int,
			@ProgramMasterID int,
			@PlantWasherNumber int,
			@ShiftID int,
			@ParameterID int,
			@BatchID int,
			@ShiftStartdate DateTime,
			@ShiftName nvarchar(50),
			@PreviousStep int,
			@XMLDataID int,
			@LastProgramID int,
			@SensorID int,
			@ReadingValue decimal(18,4),
			@StdInjectionSteps int,
			@StdWashSteps int,
			@ActualInjSteps int


    Print  'Start Date Time --' + Convert(nvarchar(max),getDate(),121) 

	SELECT @XMLDataID =  Scope_Identity()

	SELECT @MachineNumber=T.c.value('@MachineNumber', 'INT'),
			@StepNumber=T.c.value('@StepNumber', 'INT'),
			@StartDateTime=T.c.value('@StartDateTime', 'DATETIME'),
			@EndDateTime=T.c.value('@EndDateTime', 'DATETIME'),
			@ProgramNumber=T.c.value('@ProgramNumber', 'INT'),
			@Load=T.c.value('@Load', 'decimal(10,2)'),
			@NominalLoad=T.c.value('@NominalLoad', 'decimal(10,2)'),
			@CustomerNumber=T.c.value('@CustomerNumber', 'INT'),
			@WaterConsumption1=T.c.value('@WaterConsumption1', 'INT'),
			@WaterConsumption2=T.c.value('@WaterConsumption2', 'INT'),
			@PHStatus=T.c.value('@PHStatus', 'INT'),
			@PHValue=T.c.value('@PHValue', 'INT'),
			@TemperatureMin=T.c.value('@TemperatureMin', 'INT'),
			@TemperatureMax=T.c.value('@TemperatureMax', 'INT'),
			@TempMaxStatus=T.c.value('@TemperatureMaxStatus', 'INT'),
			@TempMinStatus=T.c.value('@TemperatreMinStatus', 'INT'),
			@BatchNumber=T.c.value('@BatchNumber', 'INT')
	FROM @VxML.nodes('ConventionalWasherData') T(C)
	print '*********************************' + convert(nvarchar(10),@CustomerNumber)
	print '@CustomerNumber :' + convert(nvarchar(10),@CustomerNumber)

	
			DECLARE @ShiftMapping1 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
			INSERT INTO @ShiftMapping1(ShiftId,ShiftName,ShiftStartdate) 
			EXEC TCD.GetShiftStartDate @StartDateTime,1,@RedFlagShiftId OUTPUT

			SELECT @ShiftID = ShiftID,
				  @ShiftStartdate=ShiftStartdate,
				  @ShiftName=ShiftName
			FROM @ShiftMapping1
			
			
			SELECT	
					@WasherGroupID=GroupId,
					@WasherID=WasherID
			FROM TCD.MachineSetup ms 
			WHERE ControllerID = @ControllerID
				  and MachineInternalId= @MachineNumber
				  and IsTunnel =0

		IF  (@EndDateTime = '1/1/1900') 
			SELECT @EndDateTime= null
		
		IF (@StartDateTime ='1/1/1900')
			SELECT @StartDateTime= null

		  IF (@WasherId is not null)
		  BEGIN
			SELECT	@EcoLabWasherID=EcolabWasherId,		
					@PlantWasherNumber=PlantWasherNumber,
					@ProgramMasterId=Wps.ProgramId
			FROM TCD.Washer Ws
						INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
						INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
						INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
			WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@ProgramNumber and Wps.Is_Deleted=0
		  END
      
			SELECT  @BatchID=BatchID 
			FROM TCD.BatchData 
			WHERE MachineInternalID = @MachineNumber
			      and StartDate = @StartDateTime
				   and ControllerBatchId=@BatchNumber
							 and MachineID =@WasherID

           --Start Getting InjectionCount and StepCount
			SELECT
			@StdInjectionSteps=count(DISTINCT wdpm.WasherDosingSetupId),
			@StdWashSteps= count(DISTINCT wds.WasherDosingSetupId)-count(DISTINCT wdpm.WasherDosingSetupId)
			FROM TCD.WasherDosingProductMapping wdpm
			RIGHT JOIN TCD.WasherDosingSetup wds on wdpm.WasherDosingSetupId=wds.WasherDosingSetupId
			WHERE wds.GroupId=@WasherGroupID AND wds.ProgramNumber=@ProgramNumber
			--End Getting InjectionCount and StepCount
			If (@BatchID is Null)
			BEGIN
			   INSERT INTO TCD.BatchData(
										 ControllerBatchID,
										 EcolabWasherId,
										 GroupId,
										 MachineInternalId,
										 PlantWasherNumber,
										 StartDate,
										 EndDate,
										 ProgramNumber,
										 ProgramMasterId,
										 MachineID,
										 ActualWeight,
										 StandardWeight,
										 ShiftId,
										 StdInjectionSteps,
										 StdWashSteps)
										 
				Values(@BatchNumber,
						@EcoLabWasherID,
						@WasherGroupID,
						@MachineNumber,
						@PlantWasherNumber,
						@StartDateTime,
						@EndDateTime,
						@ProgramNumber,
						@ProgramMasterId,
						@WasherID,
						@Load,
						@NominalLoad,
						@ShiftID,
						@StdInjectionSteps,
						@StdWashSteps)
				SELECT @BatchID = Scope_Identity()
				INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchID,@EcoLabWasherID,38,@StdWashSteps,@ShiftStartdate
				print 'INSERTED Batch ID ' + Convert(nvarchar(10),@BatchID)

				--End Date  Time  is Null 
				UPDATE TCD.BatchData
				SET EndDate = DateAdd(ss,-10,@StartDateTime)
				WHERE MachineInternalID = @MachineNumber
					  and StartDate <> @StartDateTime
					  and EndDate is Null
				      and ControllerBatchId <> @BatchNumber
					  and MachineId = @WasherId

			
			END 
	
			IF (isNull(@ProgramNumber,0) >0)
			BEGIN
				SELECT top 1 @LastProgramID = ParameterValue
				FROM TCD.WasherReading
				WHERE WasherID = @WasherID
					  and ParameterID = @ParameterID
				ORDER BY DateTimeStamp desc

				SELECT  @ParameterID = [Id]
				FRom TCD.ConduitPArameters 
				WHERE Name='Formula Number'
				print 'INSERT INTO Washer Reading'
				IF (@LastProgramID <>@ProgramNumber)  
				BEGIN
					INSERT INTO TCD.WasherReading(WasherID,
												  ParameterID,
												  ParameterValue,
												  DateTimeStamp,
												  EcoLabWasherID,
												  Partitionon)
					VALUES(@WasherID,
							@ParameterID,
							@ProgramNumber,
							getDate(),
							@EcoLabWasherID,
							@ShiftStartdate)
				END
			END
		    
			
			IF Not Exists(SELECT 1 FROM [TCD].[BatchCustomerData] WHERE BatchID = @BatchId 
						   and @CustomerNumber is not Null)
			BEGIN
				print 'INSERT [BatchCustomerData]'	
				INSERT INTO [TCD].[BatchCustomerData] ([BatchId],CustomerID,[Weight],PartitionOn,EcolabWasherId)
				Values(@BatchID,@CustomerNumber,@Load,@ShiftStartdate,@EcolabWasherID)
			END 
			ELSE If (@CustomerNumber >0 ) 
			BEGIN
			print 'UPDATE [BatchCustomerData]'	
			 UPDATE [TCD].[BatchCustomerData]
			 SET CustomerID=@CustomerNumber,
				[Weight]=@Load
			 WHERE BatchID = @BatchId 
			END
			
			EXEC TCD.AddSensorData @ControllerID,@WasherID,@WasherGroupID,1,@TemperatureMax
			EXEC TCD.AddSensorData @ControllerID,@WasherID,@WasherGroupID,2,@PHValue
			EXEC TCD.AddMeterReading @ControllerID,@WasherID,2,@WaterConsumption1
			
	


	CREATE TABLE #Dosing(equipmentNo int, StepNo int,Qty decimal(18,4))
	INSERT INTO #Dosing
	SELECT   T.c.value('@Equipment', 'INT'),
				T.c.value('@stepNo', 'INT'),
				T.c.value('@Qty', 'decimal(18,4)')
	FROM @VxML.nodes('ConventionalWasherData/DosingData/Dosing') T(C)
	   --Start Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
			SELECT @ActualInjSteps = COUNT(DISTINCT StepNo) FROM #Dosing

			IF NOT EXISTS(SELECT * FROM TCD.BatchParameters WHERE ParameterId =37 and batchid=@BatchId AND @ActualInjSteps > 0)
			BEGIN
				INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherID,37,@ActualInjSteps, @ShiftStartDate
		  	END
			ELSE
			BEGIN
				Update TCD.BatchParameters SET ParameterValue=@ActualInjSteps WHERE ParameterId =37 and batchid=@BatchID
			END
	  		
			--END Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
	INSERT INTO [TCD].[WasherProductReading]
	(ControllerId,WasherId,MachineInternalId,ProductId,TheoreticalQty,RealQty,DosingPoint,
	 DosingNumber,ProgramNumber,BatchNumber,ValveNumber,DateTimeStamp)
	SELECT @ControllerID,
		   @WasherID,
		   @MachineNumber,
		   CE.ProductID,
		   Null,
		   dosing.Qty,
		   equipmentNo,
		   equipmentNo,
		   @ProgramNumber,
		   @BatchNumber,
		   Null,
		   getDate()
	FROM  #Dosing  dosing
		  INNER JOIN TCD.ControllerEquipmentSetup CE on dosing.equipmentNo = CE.ControllerEquipmentId
														and CE.controllerID= @ControllerID
														and CE.ProductID is not null

		
	
END 
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMitsubishiTunnelWasherOnlineData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMitsubishiTunnelWasherOnlineData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessMitsubishiTunnelWasherOnlineData]
	(
		@ControllerID INT,
		@xmlTags xML,
		@RedFlagShiftId INT OUTPUT	
	)
AS
BEGIN
   DECLARE 
			@BatchID						INT,
			@WasherID						INT,
			@EcolabWasherId					INT,								
			@CurrencyCode					VARCHAR(50),		
			@MachineInternalId				INT,
			@WasherGroupID					INT,

			@PlantWasherNumber				INT,
			@BatchStartDate					DATETIME2,
			@BatchEndDate					DATETIME2,			
			@ProgramNumber					INT,
			@Load							Decimal(10,2),
			@NominalLoad					Decimal(10,2),
			@CustomerNumber					INT,
			--@PHStatus						INT,
			@PHValue						INT,
			@PHCompartment					INT,
			@ConductivityValue				INT,
			@ConductivityCompartment		INT,
			@TemperatureValue				INT,
			@TemperatureCompartment			INT,
			--@LFStatus						INT,
			--@LFValue						INT,
			@EjectionSignal					INT,
			@TextTileCategory				INT,
			@BatchNumber					INT,
			@TargetTurnTime					INT,
			@ShiftID						INT,
			@ParameterID					INT,			
			@ShiftName						VARCHAR(50),
			@EcolabAccountNumber NVARCHAR(25) = NULL,
			@PartitionOn DateTime,
			@BatchStartTime DateTime,
			@BatchEndTime DateTime,
			@PorgramParameterID int,
			@PHParameterID int,
			@PHParameterStatus int,
			@ConductivityParamID int,
			@ConductivityStatusParamID int,
			@RunTime int,
			@TextileCategory int,
			@ProgramID int,
			@NumberOfCompartments int,
			@TempParameter int,
			@CompartmentNoId int,
			@TransferSignalId int,
			@TempBatchStartTime DateTime,
			@ProductId	INT,
			@CompartmentNum	INT,
			@WasherGroupNum INT,
			@PrevRealQty			INT,
			@StdInjectionSteps INT,
			@StdWashSteps INT
			
				
	--INSERT into MyControlXML (xmlData, BatchType, PLCPointer, ReadPointer, BatchID, comment,LastModified) values (@xmlTags, 'TunnelOnline', null, null, null, '',getDate())

 --   SELECT @PorgramParameterID=ID
	--FROM TCD.ConduitParameters WHERE NAME ='Formula Number'

	--SELECT @PHParameterID=ID
	--FROM TCD.ConduitParameters WHERE NAME ='pH'

	--SELECT @PHParameterStatus=ID
	--FROM TCD.ConduitParameters WHERE NAME ='PH Status'
	
	--SELECT @ConductivityParamID=ID
	--FROM TCD.ConduitParameters WHERE NAME ='Conductivity'

	--SELECT @ConductivityStatusParamID=ID
	--FROM TCD.ConduitParameters WHERE NAME ='LF Status' 
	
	SELECT @CompartmentNoId=ID
	FROM TCD.ConduitParameters WHERE NAME ='StepCompartment No' 

	SELECT @TransferSignalId=ID
	FROM TCD.ConduitParameters WHERE NAME ='Transfer Signal'

	CREATE TABLE #Batches(BatchNumber int,StartDateTime DateTime)			
		

	DECLARE @BatchShiftId int
	DECLARE @ShiftStartDateTemp table(ShiftId INT,ShiftName NVARCHAR(50),ShiftStartdate DATETIME)

	DECLARE @compartmentID int,
			@TunnelXML xml
			
	SET @compartmentID = 20
	
	SELECT @WasherID=null;
	   
	WHILE (@compartmentID >=1)
	BEGIN
	  
	  	SELECT @TunnelXML=T.c.query('.') 
		FROM   @xmlTags.nodes('MyControlTunnel/TunnelData') T(c)
		WHERE T.c.value('@CompartmentNumber', 'INT') = @compartmentID


		 SELECT   @MachineInternalID=T.c.value('@MachineNumber', 'int'),
				  @BatchNumber= T.c.value('@BatchNumber', 'INT'),
				  @BatchStartTime=T.c.value('@StartDateTime', 'DateTime'),
				  @BatchEndTime=T.c.value('@EndDateTime', 'DateTime'),
				  @ProgramNumber=T.c.value('@ProgramNumber', 'INT'),
				  @WasherGroupNum=T.c.value('@GroupNumber', 'int'),
				  @Load=T.c.value('@Load', 'Decimal(10,2)'),
				  @NominalLoad=T.c.value('@Nominalload', 'Decimal(10,2)'),
				  @CustomerNumber=T.c.value('@CustomerNumber', 'int'),
				  --@PHStatus=T.c.value('@pHStatus', 'int'),
				  @PHValue=T.c.value('@pHValue', 'INT'),
				  @PHCompartment=T.c.value('@pHCompartment', 'INT'),
				  @ConductivityValue=T.c.value('@ConductivityValue', 'INT'),
				  @ConductivityCompartment=T.c.value('@ConductivityCompartment', 'INT'),
				  @RunTime=T.c.value('@RunTime', 'INT'),
				  @EjectionSignal=T.c.value('@EjectionSignal', 'INT'),
				  @TextileCategory=T.c.value('@TextileCategory', 'INT')
		 FROM @TunnelXML.nodes('TunnelData')  T(c);
		 

		 IF (@ProgramNumber = 0 OR @BatchNumber=1) 
		 BEGIN
		    SELECT @compartmentID  = @compartmentID - 1
			Continue;
		 END 

		 IF (@WasherID is null) 
		 BEGIN
			SELECT 
					@EcolabWasherID=EcolabWasherId,
					@WasherGroupID= Wg.WasherGroupId,
					@PlantWasherNumber=PlantWasherNumber,
					@WasherID=ws.WasherId,
					@CurrencyCode=P.CurrencyCode,
					@NumberOfCompartments=Mst.NumberofComp
			FROM TCD.Washer Ws
				 INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
				 INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
				 INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
				 INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId = Mst.ControllerId
				 INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.EcoLabAccountNumber
			WHERE  Ctrl.ControllerID = @ControllerID
				  AND mst.MachineInternalId = @MachineInternalID
				  AND mst.IsTunnel = 1

		 END 
		

		 SELECT @ProgramID=tps.ProgramId,
				@TargetTurnTime= (3600 / (tps.TotalRunTime /@NumberOfCompartments )) 
		 FROM TCD.TunnelProgramSetup AS tps 
		 WHERE tps.WasherGroupId = @WasherGroupID 
			   and tps.is_deleted =0
			   and tps.ProgramNumber = @ProgramNumber

		 INSERT #Batches(BatchNumber,StartDateTime)
		 SELECT @BatchNumber,@BatchStartTime

		SELECT @BatchID = Null

		SELECT @BatchID=BatchID, @PartitionOn=PartitionOn, @TempBatchStartTime=StartDate
		FROM TCD.BatchData BD
		WHERE BD.ControllerBatchId = @BatchNumber
			  --AND BD.StartDate= @BatchStartTime
			  AND BD.MachineId = @WasherID
			  AND CAST(StartDate as date)=CAST(@BatchStartTime as date)
			 --Start Getting InjectionCount,StepCount And ProductCount
			SELECT @StdInjectionSteps= count(tdpm.TunnelDosingSetupId) ,
			@StdWashSteps= count(DISTINCT tds.TunnelDosingSetupId)-count(tdpm.TunnelDosingSetupId) 
			FROM tcd.TunnelDosingProductMapping tdpm
			RIGHT JOIN tcd.TunnelDosingSetup tds on tdpm.TunnelDosingSetupId=tds.TunnelDosingSetupId
			WHERE tds.GroupId=@WasherGroupID AND tds.ProgramNumber= @ProgramNumber
			--End Getting InjectionCount,StepCount And ProductCount
		IF (@BatchID is Null) 
				BEGIN

							DELETE FROM  @ShiftStartDateTemp;

							 INSERT INTO @ShiftStartDateTemp(ShiftId,ShiftName,ShiftStartdate) 
							 EXEC TCD.GetShiftStartDate @BatchStartTime,1, @RedFlagShiftId OUTPUT

							 SELECT @BatchShiftId = ShiftID,
									  @PartitionOn=ShiftStartdate,
									  @ShiftName=ShiftName
							FROM @ShiftStartDateTemp


								INSERT INTO TCD.BatchData(
								   ControllerBatchId ,
								   EcolabWasherId,
								   GroupId ,
								   MachineInternalId,
								   PlantWasherNumber,
								   StartDate ,
								   ProgramNumber,
								   ProgramMasterId,
								   MachineId,
								   ActualWeight,
								   StandardWeight,
								   CurrencyCode,
								   ShiftId,
								   PartitionOn,
								   TargetTurnTime,
								   StdInjectionSteps,
								   StdWashSteps
							   )
						   SELECT @BatchNumber,
								  @EcolabWasherID,
								  @WasherGroupID,
								  @MachineInternalID,
								  @PlantWasherNumber,
								  @BatchStartTime,
								  @ProgramNumber,
								  @ProgramID,
								  @WasherID,
								  @Load,
								  @Load,
								  @CurrencyCode,
								  @BatchShiftId,
								  @PartitionOn,
								  @TargetTurnTime,
								  @StdInjectionSteps,
								  @StdWashSteps
							SELECT @BATCHID=Scope_Identity()
							INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue,PartitionOn) SELECT @BatchID,@EcolabWasherId,38,@StdWashSteps, @PartitionOn
							print 'BatchID : ' +Convert(nvarchar(20),@BatchID)

							IF( @CustomerNumber is not null)
							BEGIN
							INSERT INTO [TCD].[BatchCustomerData] ([BatchId],CustomerID,[Weight],PartitionOn,EcolabWasherId)
							SELECT @BatchID,@CustomerNumber,@Load,@PartitionOn,@EcolabWasherId
							END

						 END 
		ELSE
		BEGIN
			SET @BatchStartTime = @TempBatchStartTime
		END
	 --IF (@BatchEndTime is Not Null and @BatchEndTime !='01/01/1900')
	 --BEGIN
		--UPDATE TCD.BatchData
		--SET EndDate = @BatchEndTime
		--WHERE BATCHID = @BatchID
	 --END 
	 
	 -- Transfer Signal
	 INSERT INTO TCD.WasherReading(
			WasherId,
			ParameterId,
			ParameterValue,
			DateTimeStamp,
			PartitionOn,
			EcolabWasherId)
			SELECT @WasherID,
			@TransferSignalId,
			1,
			@BatchStartTime,
			@PartitionOn,
			@EcolabWasherId
		UNION ALL
			SELECT @WasherID,
			@TransferSignalId,
			0,
			@BatchStartTime,
			@PartitionOn,
			@EcolabWasherId

	 --IF NOT Exists(SELECT 1 FROM [TCD].[BatchCustomerData] 
		--		   WHERE BatchID = @BatchID)
	 --BEGIN
		--INSERT INTO [TCD].[BatchCustomerData] ([BatchId],CustomerID,[Weight],PartitionOn,EcolabWasherId)
		--SELECT @BatchID,@CustomerNumber,@Load,@PartitionOn,@EcolabWasherId
	 --END 

	 -- @Program Number
	 SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
			WasherId = @WasherID 
			AND ParameterID = @PorgramParameterID 
			AND EcolabWasherId = @EcolabWasherId 
			AND DateTimeStamp = @BatchStartTime
			--AND ParameterValue = @ProgramNumber
			ORDER BY  DateTimeStamp DESC)

		IF (@TempParameter != @ProgramNumber)
		BEGIN
			INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
			SELECT @WasherID,@PorgramParameterID,@ProgramNumber,@BatchStartTime,@PartitionOn,@EcolabWasherId
		END 
		
		---- PH Value
		--SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
		--	WasherId = @WasherID 
		--	AND ParameterID = @PHParameterID 
		--	AND EcolabWasherId = @EcolabWasherId 
		--	AND DateTimeStamp = @BatchStartTime
		--	--AND ParameterValue = @ProgramNumber
		--	ORDER BY  DateTimeStamp DESC)
		
		--IF (@TempParameter != @PHValue)
		--BEGIN
		--	IF (@PHValue > 0)
		--	BEGIN
		--		INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
		--		SELECT @WasherID,@PHParameterID,@PHValue,@BatchStartTime,@PartitionOn,@EcolabWasherId
		--	END
		--END 

		-- PH Status
	 --SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
		--	WasherId = @WasherID 
		--	AND ParameterID = @PHParameterStatus 
		--	AND EcolabWasherId = @EcoLabWasherID 
		--	AND DateTimeStamp = @BatchStartTime
		--	--AND ParameterValue = @ProgramNumber
		--	ORDER BY  DateTimeStamp DESC)

		--IF (@TempParameter != @PHStatus)
		--BEGIN
		--	--IF (@PHStatus > 0)
		--	--BEGIN
		--		INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
		--		SELECT @WasherID,@PHParameterStatus,@PHStatus,@BatchStartTime,@PartitionOn,@EcolabWasherId
		--	--END
		--END 
	 
	 -- LF Value
		--SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
		--	WasherId = @WasherID 
		--	AND ParameterID = @ConductivityParamID 
		--	AND EcolabWasherId = @EcolabWasherId 
		--	AND DateTimeStamp = @BatchStartTime
		--	--AND ParameterValue = @ProgramNumber
		--	ORDER BY  DateTimeStamp DESC)

		--IF (@TempParameter != @LFValue)
		--BEGIN
		--	IF (@LFValue > 0)
		--	BEGIN
		--		INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
		--		SELECT @WasherID,@ConductivityParamID,@LFValue,@BatchStartTime,@PartitionOn,@EcolabWasherId
		--	END
		--END 
		
		-- LF Status
		--SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
		--	WasherId = @WasherID 
		--	AND ParameterID = @ConductivityStatusParamID 
		--	AND EcolabWasherId = @EcolabWasherId 
		--	AND DateTimeStamp = @BatchStartTime
		--	--AND ParameterValue = @ProgramNumber
		--	ORDER BY  DateTimeStamp DESC)

		--IF (@TempParameter != @LFStatus)
		--BEGIN
		--	--IF (@LFValue > 0)
		--	--BEGIN
		--		INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
		--		SELECT @WasherID,@ConductivityStatusParamID,@LFStatus,@BatchStartTime,@PartitionOn,@EcolabWasherId
		--	--END
		--END 
		
		-- Compartment No  
		SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
			WasherId = @WasherID 
			AND ParameterID = @CompartmentNoId 
			AND EcolabWasherId = @EcolabWasherId 
			AND DateTimeStamp = @BatchStartTime
			--AND ParameterValue = @ProgramNumber
			ORDER BY  DateTimeStamp DESC)

		IF (@TempParameter != @compartmentID)
		BEGIN
			--IF (@LFValue > 0)
			--BEGIN
				INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
				SELECT @WasherID,@CompartmentNoId,@compartmentID,@BatchStartTime,@PartitionOn,@EcolabWasherId
			--END
		END 	 

	
	  EXEC TCD.UPDATEBatchWashStepForTunnel @TunnelXML,@WasherID,@BatchID, @BatchStartTime,@PartitionOn,@EcolabWasherId,@compartmentID
		
	IF(@PHValue is not null)
	BEGIN
	  EXEC TCD.AddSensorData @ControllerID,@PHCompartment,@WasherGroupID,2,@PHValue
	END

	IF(@ConductivityValue is not null)
	BEGIN
	  EXEC TCD.AddSensorData @ControllerID,@ConductivityCompartment,@WasherGroupID,4,@ConductivityValue
	END

	CREATE TABLE #TemperatureData(Value INT, 
								  Compartment INT
								 )

	INSERT INTO #TemperatureData(Value,Compartment)
	  SELECT 
			T.c.value('@TemperatureValue', 'INT') AS Value, 
			T.c.value('@TemperatureCompartment', 'INT') AS Compartment
			
	  FROM @TunnelXML.nodes('TunnelData/TemperatureData') T(c)
	  
	  -- Fetching data from cursor
			DECLARE @MYCURSOR CURSOR
			SET @MYCURSOR = CURSOR FAST_FORWARD
			FOR
			SELECT		Value,
						Compartment

				FROM #TemperatureData

			DECLARE			@TempValue				INT,
							@TempCompartment		INT

			OPEN @MYCURSOR
			FETCH NEXT FROM @MYCURSOR
						INTO 
							@TempValue,
							@TempCompartment
							
			WHILE @@FETCH_STATUS = 0			
			BEGIN	
				
				IF(@TempValue is not null)
				BEGIN
					EXEC TCD.AddSensorData @ControllerID,@TempCompartment,@WasherGroupID,1,@TempValue
				END

				FETCH NEXT FROM @MYCURSOR
						INTO 
							@TempValue,
							@TempCompartment
			END

			CLOSE @MYCURSOR
			DEALLOCATE @MYCURSOR

			Drop table #TemperatureData


			 CREATE TABLE #DosingDetails(Number INT, 
								  Quantity Decimal(10,6),
								  Point INT,
								  IsMainEquioment INT,
								  IsDirectDosing INT
								 )
  		
	  INSERT INTO #DosingDetails(Number,Quantity, Point, IsMainEquioment, IsDirectDosing)
	  SELECT 
			T.c.value('@Number', 'INT') AS Number, --PumpNumber
			T.c.value('@Quantity', 'Decimal(10,6)') AS Quantity, --Dosing Quanity
			T.c.value('@Point', 'INT') AS Point,	--ValveNumber
			T.c.value('@IsMainEquioment', 'INT') AS IsMainEquioment,
			T.c.value('@IsDirectDosing', 'INT') AS IsDirectDosing
					
	  FROM @TunnelXML.nodes('TunnelData/Dose') T(c)
	  
	  -- Fetching data from cursor
			DECLARE @MYCURSOR1 CURSOR
			SET @MYCURSOR1 = CURSOR FAST_FORWARD
			FOR
			SELECT		Number,
						Quantity,										
						Point,
						IsMainEquioment,
						IsDirectDosing

				FROM #DosingDetails

			DECLARE			@Number				INT,
							@Quantity			Decimal(10,6),
							@Point				INT,
							@IsMainEquioment	INT,
							@IsDirectDosing		INT

			OPEN @MYCURSOR1
			FETCH NEXT FROM @MYCURSOR1
						INTO 
							@Number,
							@Quantity,
							@Point,
							@IsMainEquioment,
							@IsDirectDosing
							
			WHILE @@FETCH_STATUS = 0			
			BEGIN	
				IF(@IsDirectDosing = 1)
				BEGIN
					SELECT @ProductId=CES.ProductId, @CompartmentNum=TCEVM.CompartmentNumber
					FROM tcd.ControllerEquipmentSetup CES 
					INNER JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM
					ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
					WHERE TCEVM.DirectDosingFlag = 1
						  AND CES.ControllerId=@ControllerID 
						  AND CES.ControllerEquipmentId=@Number
						  AND CES.ControllerEquipmentTypeId=1 
						  --AND IsActive=1 
						  AND CES.WasherGroupNumber=@WasherGroupNum
				END
				ELSE IF(@IsMainEquioment = 1)
				BEGIN
					SELECT @ProductId=CES.ProductId, @CompartmentNum=TCEVM.CompartmentNumber
		    		FROM  tcd.ControllerEquipmentSetup CES INNER JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM
					ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
					WHERE CES.ControllerId=@ControllerID AND
						  CES.ControllerEquipmentTypeId=2 AND
						  --CES.IsActive=1 AND
						  CES.WasherGroupNumber=@WasherGroupNum AND
						  TCEVM.ValveNumber=@Point AND
						  CES.ControllerEquipmentId = @Number
				END
				ELSE
				BEGIN
					SELECT @ProductId=CES.ProductId, @CompartmentNum=TCEVM.CompartmentNumber
				    FROM  tcd.ControllerEquipmentSetup CES INNER JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM
					ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
					WHERE CES.ControllerId=@ControllerID AND
						  CES.ControllerEquipmentTypeId=1 AND
						  --CES.IsActive=1 AND
						  CES.WasherGroupNumber = @WasherGroupNum AND
						  TCEVM.ValveNumber=@Point 					
				END

				IF(@ProductId is not null)
				BEGIN
					SELECT TOP 1 @PrevRealQty = RealQty FROM TCD.WasherProductReading WHERE ControllerId=@ControllerID AND WasherId = @WasherId ORDER BY DateTimeStamp DESC
	
					IF(@PrevRealQty is null OR @PrevRealQty != @Quantity)
					BEGIN
				
						INSERT INTO [TCD].[WasherProductReading] 
							   (ControllerId,
								WasherId,
								MachineInternalId,
								ProductId,
								RealQty,
								DosingNumber,
								ProgramNumber,
								BatchNumber,
								ValveNumber,
								DateTimeStamp			   
							   )
								  SELECT
								   @ControllerId,
								   @WasherId,
								   @MachineInternalId,
								   @ProductId,
								   @Quantity,
								   @Number,
								   @ProgramNumber,
								   @BatchNumber,
								   @Point,
								   GETUTCDATE()				   
					END
				END

				FETCH NEXT FROM @MYCURSOR1
						INTO 
							@Number,
							@Quantity,
							@Point,
							@IsMainEquioment,
							@IsDirectDosing
			END

			CLOSE @MYCURSOR1
			DEALLOCATE @MYCURSOR1

			Drop table #DosingDetails
						
	  SELECT @compartmentID= @compartmentID - 1 
	END	   

	UPDATE BD
	SET EndDate=GetUTCDate()
	FROM TCD.BatchData BD
	WHERE MachineId =@WasherID
		  AND EndDate is Null
		  AND CAST(StartDate as date)=CAST(@BatchStartTime as date)
	      AND Not Exists(SELECT 1 
						 FROM #Batches t
						 WHERE t.BatchNumber = BD.ControllerBatchId
							   --and t.StartDateTime =BD.StartDate
						)

	 --Last Step is not getting closed in Tunnel BatchWashStepData
	UPDATE BWD
	SET EndTime=GetUTCDate()
	FROM TCD.BatchWashStepData BWD
	INNER JOIN TCD.BatchData BD on BWD.BatchId = BD.BatchId
	WHERE BD.MachineId =@WasherID
              AND BWD.EndTime is Null
              AND Not Exists(SELECT 1 FROM #Batches t
                             WHERE t.BatchNumber = BD.ControllerBatchId)
                             --and t.StartDateTime =BD.StartDate)      
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMitsubishiAccessSaveData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMitsubishiAccessSaveData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessMitsubishiAccessSaveData]
	(
		@ControllerID INT,
		@xmlTags xML
	)
AS
BEGIN
   DECLARE 
			@BatchID						INT,
			@WasherID						INT,
			@EcolabWasherId					INT,								
			@CurrencyCode					VARCHAR(50),		
			@MachineInternalId				INT,
			@WasherGroupID					INT,
			@PlantWasherNumber				INT,
			@BatchStartTime					DATETIME2,
			@BatchEndTime					DATETIME2,			
			@ProgramNumber					INT,
			@Load							Decimal(10,2),
			@NominalLoad					Decimal(10,2),
			@CustomerNumber					INT,
			@BatchCounter					INT,
			@IsTunnel						INT,
			@BatchShiftId					INT,
			@PartitionOn				    DATETIME2,
			@ShiftName						VARCHAR(50),
			@ProgramMasterId				INT,
			@NumberOfCompartments			INT,
			@TargetTurnTime					INT,
			@EcolabAccountNumber NVARCHAR(25) = NULL,
			@StdInjectionSteps INT,
			@StdWashSteps INT
			
					
	
	  	SELECT    @MachineInternalID=T.c.value('@MachineNumber', 'int'),
				  @BatchCounter= T.c.value('@BatchCounter', 'INT'),
				  @BatchStartTime=T.c.value('@StartDateTime', 'DateTime'),
				  @BatchEndTime=T.c.value('@EndDateTime', 'DateTime'),
				  @ProgramNumber=T.c.value('@ProgramNumber', 'INT'),
				  @Load=T.c.value('@Load', 'Decimal(10,2)'),
				  @NominalLoad=T.c.value('@NominalLoad', 'Decimal(10,2)'),
				  @CustomerNumber=T.c.value('@CustomerNumber', 'int'),
				  @IsTunnel=T.c.value('@IsTunnel', 'int')
				  
		 FROM @xmlTags.nodes('PLCData')  T(c);
		 
		
			SELECT 	@EcolabWasherID=EcolabWasherId,
					@WasherGroupID= Wg.WasherGroupId,
					@PlantWasherNumber=PlantWasherNumber,
					@WasherID=ws.WasherId,
					@CurrencyCode=P.CurrencyCode,
					@NumberOfCompartments=Mst.NumberofComp
			FROM TCD.Washer Ws
				 INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
				 INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
				 INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
				 INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId = Mst.ControllerId
				 INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.EcoLabAccountNumber
			WHERE  Ctrl.ControllerID = @ControllerID
				  AND mst.MachineInternalId = @MachineInternalID
				  AND mst.IsTunnel = @IsTunnel

		IF(@IsTunnel = 1)
		BEGIN
			SELECT @ProgramMasterId=ProgramId,
					@TargetTurnTime= (3600 / (tps.TotalRunTime /@NumberOfCompartments )) 
			 FROM TCD.TunnelProgramSetup AS tps 
			 WHERE tps.WasherGroupId = @WasherGroupID 
				   and tps.is_deleted =0
				   and ProgramNumber = @ProgramNumber 
		END
		ELSE
		BEGIN
			SELECT DISTINCT @ProgramMasterId=Wps.ProgramId
				FROM TCD.Washer Ws
							INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
							INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
							INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
							INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
				WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@ProgramNumber and Wps.Is_Deleted=0
		END
		SET @BatchID = Null

		SELECT @BatchID=BatchID
			FROM TCD.BatchData BD
			WHERE BD.ControllerBatchId = @BatchCounter
				 --AND BD.StartDate= @BatchStartTime
				AND BD.MachineId = @WasherID
				AND CAST(StartDate as date)=CAST(@BatchStartTime as date)
          --Start Getting InjectionCount and StepCount
			SELECT
			@StdInjectionSteps=count(DISTINCT wdpm.WasherDosingSetupId),
			@StdWashSteps= count(DISTINCT wds.WasherDosingSetupId)-count(DISTINCT wdpm.WasherDosingSetupId)
			FROM TCD.WasherDosingProductMapping wdpm
			RIGHT JOIN TCD.WasherDosingSetup wds on wdpm.WasherDosingSetupId=wds.WasherDosingSetupId
			WHERE wds.GroupId=@WasherGroupID AND wds.ProgramNumber=@ProgramNumber
			--End Getting InjectionCount and StepCount
		IF (@BatchID is Null) 
		BEGIN

			DECLARE @ShiftStartDate table(ShiftId INT, ShiftName NVARCHAR(50), ShiftStartdate DATETIME)
			INSERT INTO @ShiftStartDate(ShiftId,ShiftName,ShiftStartdate) EXEC TCD.GetShiftStartDate @BatchStartTime,1

			SELECT @BatchShiftId = ShiftID, @PartitionOn=ShiftStartdate, @ShiftName=ShiftName FROM @ShiftStartDate

			IF(@IsTunnel = 0)
			BEGIN
				SET @BatchEndTime = DateAdd(mi,10,@BatchStartTime) 
			END

			INSERT INTO TCD.BatchData(
									   ControllerBatchId ,
									   EcolabWasherId,
									   GroupId ,
									   MachineInternalId,
									   PlantWasherNumber,
									   StartDate ,
									   EndDate,
									   ProgramNumber,
									   ProgramMasterId,
									   MachineId,
									   ActualWeight,
									   StandardWeight,
									   CurrencyCode,
									   ShiftId,
									   PartitionOn,
									   StdInjectionSteps,
									   StdWashSteps
								   )
							   SELECT @BatchCounter,
									  @EcolabWasherID,
									  @WasherGroupID,
									  @MachineInternalID,
									  @PlantWasherNumber,
									  @BatchStartTime,
									  @BatchEndTime,
									  @ProgramNumber,
									  @ProgramMasterId,
									  @WasherID,
									  @Load,
									  @NominalLoad,
									  @CurrencyCode,
									  @BatchShiftId,
									  @PartitionOn,
									  @StdInjectionSteps,
									  @StdWashSteps
								  
			SELECT @BatchID=Scope_Identity()
							
			IF( @CustomerNumber is not null)
			BEGIN
				INSERT INTO [TCD].[BatchCustomerData] ([BatchId],CustomerID,[Weight],PartitionOn,EcolabWasherId)
				SELECT @BatchID,@CustomerNumber,@Load,@PartitionOn,@EcolabWasherId
			END
		END 

		ELSE
		BEGIN	
			IF(@IsTunnel = 1)
			BEGIN				
				UPDATE TCD.BatchData set StartDate = @BatchStartTime, StandardWeight = @NominalLoad
				WHERE 
					ControllerBatchId = @BatchCounter
					AND MachineId = @WasherID
					AND CAST(StartDate as date)=CAST(@BatchStartTime as date)
			END		
		END
	  
END
			
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMitsubishiTunnelWasherProdData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMitsubishiTunnelWasherProdData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessMitsubishiTunnelWasherProdData]
	(
		@ControllerID INT,
		@xmlTags xML,
		@RedFlagShiftId INT OUTPUT
	)
AS
BEGIN
   DECLARE 
			@BatchID						INT,
			@WasherID						INT,
			@EcolabWasherId					INT,								
			@CurrencyCode					VARCHAR(50),		
			@MachineInternalId				INT,
			@WasherGroupID					INT,
			@WasherGroupNum					INT,
			@PlantWasherNumber				INT,
			@BatchStartDate					DATETIME2,
			@BatchEndDate					DATETIME2,			
			@ProgramNumber					INT,
			@Load							Decimal(10,2),
			@NominalLoad					Decimal(10,2),
			@CustomerNumber					INT,
			@PHStatus						INT,
			@PHValue						INT,
			@LFStatus						INT,
			@LFValue						INT,
			@EjectionSignal					INT,
			@TextTileCategory				INT,
			@BatchNumber					INT,
			@TargetTurnTime					INT,
			@ShiftID						INT,
			@ParameterID					INT,			
			@ShiftName						VARCHAR(50),
			@EcolabAccountNumber NVARCHAR(25) = NULL,
			@PartitionOn DateTime,
			@BatchStartTime DateTime,
			@BatchEndTime DateTime,
			@PorgramParameterID int,
			@PHParameterID int,
			@ConductivityParamID int,
			@RunTime int,
			@TextileCategory int,
			@ProgramID int,
			@NumberOfCompartments int,
			@TempParameter int,
			@PumpNo   INT, 
			@DosingPoint INT,
			@ProductId INT,
			@CompartmentNum INT,
			@MinTempParamID INT,
			@MaxTempParamID INT,
			@TempStatusParamID INT,
			@PHValueParamID INT,
			@PHStatusParamID INT,
			@ActualInjSteps INT
			
				
	--INSERT into MyControlXML (xmlData, BatchType, PLCPointer, ReadPointer, BatchID, comment,LastModified) values (@xmlTags, 'TunnelCompleted', null, null, null, '',getDate())

    SELECT @PorgramParameterID=ID
	FROM TCD.ConduitParameters WHERE NAME ='Formula Number'

	SELECT @PHParameterID=ID
	FROM TCD.ConduitParameters WHERE NAME ='pH'

	SELECT @ConductivityParamID=ID
	FROM TCD.ConduitParameters WHERE NAME ='Conductivity'

	CREATE TABLE #Batches(BatchNumber int,StartDateTime DateTime)
				
	DECLARE @BatchShiftId int
	DECLARE @ShiftStartDateTemp table(ShiftId INT,ShiftName NVARCHAR(50),ShiftStartdate DATETIME)

	DECLARE @compartmentID int,
			@TunnelXML xml
			
			
	SELECT @compartmentID = 1
	SELECT @WasherID=null;
	   
	--WHILE (@compartmentID <=25)
	--BEGIN
	  
	  	SELECT @TunnelXML=T.c.query('.') 
		FROM   @xmlTags.nodes('MyControlTunnel/TunnelData') T(c)
		WHERE T.c.value('@CompartmentNumber', 'INT') = 20


		 SELECT   
				  --@MachineInternalID=T.c.value('@MachineNumber', 'int'),
				  @BatchNumber= T.c.value('@BatchNumber', 'INT'),
 				  @BatchStartTime=T.c.value('@StartDateTime', 'DateTime'),
				  @BatchEndTime=T.c.value('@EndDateTime', 'DateTime'),
				  @ProgramNumber=T.c.value('@ProgramNumber', 'INT'),
				  @Load=T.c.value('@Load', 'Decimal(10,2)')/10,
				  @NominalLoad=T.c.value('@Nominalload', 'Decimal(10,2)'),
				  @WasherGroupNum=T.c.value('@GroupNumber', 'int'),
				  @CustomerNumber=T.c.value('@CustomerNumber', 'int'),
				  @PHStatus=T.c.value('@pHStatus', 'int'),
				  @PHValue=T.c.value('@pHValue', 'INT'),
				  @LFStatus=T.c.value('@LFStatus', 'INT'),
				  @LFValue=T.c.value('@LFValue', 'INT'),
				  @RunTime=T.c.value('@RunTime', 'INT'),
				  @EjectionSignal=T.c.value('@EjectionSignal', 'INT'),
				  @TextileCategory=T.c.value('@TextileCategory', 'INT')
		 FROM @TunnelXML.nodes('TunnelData')  T(c);
		 

		 --IF (@ProgramNumber = 0 OR @BatchNumber=1) 
		 --BEGIN
		 --   SELECT @compartmentID  = @compartmentID + 1
			----Continue;
		 --END 
		 	 
		
		SELECT @WasherGroupID= Wg.WasherGroupId
			FROM TCD.WasherGroup Wg WHERE ControllerID = @ControllerID AND WasherGroupNumber = @WasherGroupNum AND WasherGroupTypeId = 2

		 SELECT @ProgramID=ProgramId,
				@TargetTurnTime= (3600 / (tps.TotalRunTime /@NumberOfCompartments )) 
		 FROM TCD.TunnelProgramSetup AS tps 
		 WHERE tps.WasherGroupId = @WasherGroupID 
			   and tps.is_deleted =0
			   and ProgramNumber = @ProgramNumber
			   	

		SELECT @BatchID = Null

		SELECT @BatchID=BatchID, @WasherID=MachineId, @BatchStartTime=StartDate, @EcolabWasherId=EcolabWasherId
			FROM TCD.BatchData
			WHERE	ControllerBatchId = @BatchNumber
					AND GroupId = @WasherGroupID 
					AND CAST(StartDate as date)=CAST(@BatchStartTime as date)

		IF (@BatchID is NOT Null) 
		BEGIN
			IF (@BatchEndTime is Not Null)
			BEGIN
				INSERT INTO @ShiftStartDateTemp(ShiftId,ShiftName,ShiftStartdate) 
				EXEC TCD.GetShiftStartDate @BatchEndTime,1, @RedFlagShiftId OUTPUT

				SELECT @BatchShiftId = ShiftID, @PartitionOn=ShiftStartdate FROM @ShiftStartDateTemp
				UPDATE TCD.BatchData SET EndDate = @BatchEndTime, ShiftId=@BatchShiftId, PartitionOn=@PartitionOn WHERE BATCHID = @BatchID

				--EXEC TCD.UPDATEBatchWashStepForTunnel @TunnelXML, @WasherID, @BatchID, @BatchStartTime, @PartitionOn, @EcolabWasherId, 20
			END
					 
		
	  CREATE TABLE #DosingDetails(Number INT, 
								  Quantity Decimal(10,6),
								  Point INT,
								  IsMainEquioment INT,
								  IsDirectDosing INT
								 )
  	  
	  --IF EXISTS (SELECT  * FROM TEMPDB.DBO.SYSOBJECTS o where o.xtype in ('U') AND o.id = OBJECT_ID(N'tempdb..#DosingDetails'))
			--BEGIN
			--		DROP TABLE #DosingDetails
			--END

	  INSERT INTO #DosingDetails(Number,Quantity, Point, IsMainEquioment, IsDirectDosing)
	  SELECT 
			T.c.value('@Number', 'INT') AS Number, --PumpNumber
			T.c.value('@Quantity', 'Decimal(10,6)') AS Quantity, --Dosing Quanity
			T.c.value('@Point', 'INT') AS Point,	--ValveNumber
			T.c.value('@IsMainEquioment', 'INT') AS IsMainEquioment,
			T.c.value('@IsDirectDosing', 'INT') AS IsDirectDosing
					
	  FROM @TunnelXML.nodes('TunnelData/Dose') T(c)
	  
	  -- Fetching data from cursor
			DECLARE @MYCURSOR CURSOR
			SET @MYCURSOR = CURSOR FAST_FORWARD
			FOR
			SELECT		Number,
						Quantity,										
						Point,
						IsMainEquioment,
						IsDirectDosing

				FROM #DosingDetails

			DECLARE			@Number				INT,
							@Quantity			Decimal(10,6),
							@Point				INT,
							@IsMainEquioment	INT,
							@IsDirectDosing		INT

			OPEN @MYCURSOR
			FETCH NEXT FROM @MYCURSOR
						INTO 
							@Number,
							@Quantity,
							@Point,
							@IsMainEquioment,
							@IsDirectDosing
							
			WHILE @@FETCH_STATUS = 0			
			BEGIN	
				IF(@IsDirectDosing = 1)
				BEGIN
					SELECT @ProductId=CES.ProductId, @CompartmentNum=TCEVM.CompartmentNumber
					FROM tcd.ControllerEquipmentSetup CES 
					INNER JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM
					ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
					WHERE TCEVM.DirectDosingFlag = 1
						  AND CES.ControllerId=@ControllerID 
						  AND CES.ControllerEquipmentId=@Number
						  AND CES.ControllerEquipmentTypeId=1 
						  --AND IsActive=1 
						  AND CES.WasherGroupNumber=@WasherGroupNum
				END
				ELSE IF(@IsMainEquioment = 1)
				BEGIN
					SELECT @ProductId=CES.ProductId, @CompartmentNum=TCEVM.CompartmentNumber
		    		FROM  tcd.ControllerEquipmentSetup CES INNER JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM
					ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
					WHERE CES.ControllerId=@ControllerID AND
						  CES.ControllerEquipmentTypeId=2 AND
						  --CES.IsActive=1 AND
						  CES.WasherGroupNumber=@WasherGroupNum AND
						  TCEVM.ValveNumber=@Point AND
						  CES.ControllerEquipmentId = @Number
				END
				ELSE
				BEGIN
					SELECT @ProductId=CES.ProductId, @CompartmentNum=TCEVM.CompartmentNumber
				    FROM  tcd.ControllerEquipmentSetup CES INNER JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM
					ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
					WHERE CES.ControllerId=@ControllerID AND
						  CES.ControllerEquipmentTypeId=1 AND
						  --CES.IsActive=1 AND
						  CES.WasherGroupNumber = @WasherGroupNum AND
						  TCEVM.ValveNumber=@Point 					
				END

				IF(@ProductId is not null)
				BEGIN
					INSERT INTO TCD.BatchProductData 
					(BatchId, StepCompartment, ActualQuantity,PartitionOn,EcolabWasherId,ProductId)
					SELECT @BatchID,
						@CompartmentNum,
						@Quantity,
						@PartitionOn,
						@EcolabWasherId,
						@ProductId
				END

				FETCH NEXT FROM @MYCURSOR
						INTO 
							@Number,
							@Quantity,
							@Point,
							@IsMainEquioment,
							@IsDirectDosing
			END

			CLOSE @MYCURSOR
			DEALLOCATE @MYCURSOR

			Drop table #DosingDetails

			
		SELECT @ActualInjSteps = COUNT(DISTINCT StepCompartment) FROM TCD.BatchProductData WHERE BatchId=@BatchID
		IF NOT EXISTS(SELECT * FROM TCD.BatchParameters WHERE ParameterId =37 and batchid=@BatchID AND @ActualInjSteps > 0)
		BEGIN
			INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,37,@ActualInjSteps, @PartitionOn
		END
		ELSE
		BEGIN
			Update TCD.BatchParameters SET ParameterValue=@ActualInjSteps WHERE ParameterId =37 and batchid=@BatchID
		END
	  END 


	--UPDATE BD
	--SET EndDate=GetUTCDate()
	--FROM TCD.BatchData BD
	--WHERE MachineId =@WasherID
	--	  AND EndDate is Null
	--      AND Not Exists(SELECT 1 
	--					 FROM #Batches t
	--					 WHERE t.BatchNumber = BD.ControllerBatchId
	--						   and t.StartDateTime =BD.StartDate
	--					)						 
		
	--UPDATE BD
 --       SET EndTime=GetUTCDate()
 --       FROM TCD.BatchWashStepData BWD
 --               INNER JOIN TCD.BatchData BD on BWD.BatchId = BD.BatchId
 --       WHERE BD.MachineId =@WasherID
 --                 AND BWD.EndTime is Null
 --             AND Not Exists(SELECT 1
 --                                               FROM #Batches t
 --                                               WHERE t.BatchNumber = BD.ControllerBatchId
 --                                                          and t.StartDateTime =BD.StartDate
 --                                               )   
 
 --Populate Batch Paramters
 
		SELECT @MinTempParamID=Id 
		FROM [TCD].[ConduitParameters] 
		WHERE Name = 'Mimum Temperature' 
				
		SELECT @MaxTempParamID=Id 
		FROM [TCD].[ConduitParameters] 
		WHERE Name = 'Maximum Temperature'

		SELECT @TempStatusParamID=Id 
		FROM [TCD].[ConduitParameters] 
		WHERE Name = 'Temperature Status'

		SELECT @PHValueParamID=ID
		FROM [TCD].[ConduitParameters] 
		WHERE Name = 'PH'
				
		SELECT @PHStatusParamID=ID
		FROM [TCD].[ConduitParameters] 
		WHERE Name =  'PH Status'  
		
		--pH Status
		INSERT INTO TCD.BatchParameters
		(BatchId,
		 EcolabWasherId,
		 ParameterId,
		 ParameterValue,
		 PartitionOn)
		VALUES(@BatchID,
				@EcoLabWasherID,
				@PHStatusParamID,
				@PHStatus,
				@PartitionOn)

		--pH Value
		INSERT INTO TCD.BatchParameters
		(BatchId,
		 EcolabWasherId,
		 ParameterId,
		 ParameterValue,
		 PartitionOn)
		VALUES(@BatchID,
				@EcoLabWasherID,
				@PHValueParamID,
				@PHValue,
				@PartitionOn)

		CREATE TABLE #TemperatureDetails(MinimumTemp Decimal(10,2), 
										 MaximumTemp Decimal(10,2),
										 TempStatus Decimal(10,2)
										)
  	  
	  INSERT INTO #TemperatureDetails(MinimumTemp,MaximumTemp, TempStatus)
	  SELECT 
			T.c.value('@MinimumTemp', 'Decimal(10,2)') AS MinimumTemp, 
			T.c.value('@MaximumTemp', 'Decimal(10,2)') AS MaximumTemp,
			T.c.value('@Status', 'Decimal(10,2)') AS Status
			
	  FROM @TunnelXML.nodes('TunnelData/TemperatureData') T(c)
	  
	  -- Fetching data from cursor
			DECLARE @TEMPCURSOR CURSOR
			SET @TEMPCURSOR = CURSOR FAST_FORWARD
			FOR
			SELECT		MinimumTemp,
						MaximumTemp,										
						TempStatus

				FROM #TemperatureDetails

			DECLARE			@MinimumTemp				Decimal(10,2),
							@MaximumTemp			Decimal(10,2),
							@TempStatus				Decimal(10,2)
							
			OPEN @TEMPCURSOR
			FETCH NEXT FROM @TEMPCURSOR
						INTO 
							@MinimumTemp,
							@MaximumTemp,
							@TempStatus
							
			WHILE @@FETCH_STATUS = 0			
			BEGIN	
				--Minimum Temperature
				INSERT INTO TCD.BatchParameters
				(BatchId,
				 EcolabWasherId,
				 ParameterId,
				 ParameterValue,
				 PartitionOn)
				VALUES(@BatchID,
						@EcoLabWasherID,
						@MinTempParamID,
						@MinimumTemp,
						@PartitionOn)

				--Maximum Temperature
				INSERT INTO TCD.BatchParameters
				(BatchId,
				 EcolabWasherId,
				 ParameterId,
				 ParameterValue,
				 PartitionOn)
				VALUES(@BatchID,
						@EcoLabWasherID,
						@MaxTempParamID,
						@MaximumTemp,
						@PartitionOn)

				--Temperature Status
				INSERT INTO TCD.BatchParameters
				(BatchId,
				 EcolabWasherId,
				 ParameterId,
				 ParameterValue,
				 PartitionOn)
				VALUES(@BatchID,
						@EcoLabWasherID,
						@TempStatusParamID,
						@TempStatus,
						@PartitionOn)								

				FETCH NEXT FROM @TEMPCURSOR
						INTO 
							@MinimumTemp,
							@MaximumTemp,
							@TempStatus
			END

			CLOSE @TEMPCURSOR
			DEALLOCATE @TEMPCURSOR

			Drop table #TemperatureDetails
	                                          	

END
			
GO
UPDATE rkv set rkv.[Value]='$/Cwt'
FROM TCD.ResourceKeyValue rkv WHERE rkv.languageID=1 
AND rkv.KeyName='dollar_per_centrum_weight'
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[SaveControllerSetupData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[SaveControllerSetupData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[SaveControllerSetupData] 
(
  @ControllerSetupData     XML
 , @UserId         INT
 , @ControllerId       INT      OUTPUT
 , @LastModifiedTimestampAtCentral   DATETIME = NULL
 , @OutputLastModifiedTimestampAtLocal  DATETIME = NULL OUTPUT
)
AS
BEGIN
      SET NOCOUNT ON
   
--DECLARE @ControllerId INT
DECLARE @ControllerNumber INT = NULL
DECLARE @ControllerModelId INT = NULL
DECLARE @ControllerModelName VARCHAR(50) = NULL
DECLARE @ControllerTypeId INT = NULL
DECLARE @ControllerTypeName VARCHAR(50) = NULL
DECLARE @EcolabAccountNumber NVARCHAR(25) = NULL
DECLARE @TopicName VARCHAR(1000) = NULL
DECLARE @Active BIT
DECLARE @ErrorMessage VARCHAR(200) = NULL
DECLARE @NumOfConvWasherGroups INT = NULL
DECLARE @NumOfTunnelWasherGroups INT = NULL
DECLARE @LoopCount INT = 0
DECLARE @WasherGroupName VARCHAR(100) = NULL
DECLARE @WasherGroupId INT = NULL
DECLARE @WasherGroupNumber VARCHAR(10) = NULL
DECLARE @OutputList AS TABLE (
ControllerId INT
,LastModifiedTimestamp DATETIME
  )

SET @ControllerId = ISNULL(@ControllerId, NULL) --SQLEnlight SA0121
SET @OutputLastModifiedTimestampAtLocal = ISNULL(@OutputLastModifiedTimestampAtLocal, NULL) --SQLEnlight SA0121

   SELECT @ControllerNumber = Tbl.col.value('@ControllerNumber', 'int')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)

   SELECT @ControllerModelId = Tbl.col.value('@ControllerModelId', 'int')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)

   SELECT @ControllerTypeId = Tbl.col.value('@ControllerTypeId', 'int')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)
   
   SELECT @EcolabAccountNumber = Tbl.col.value('@EcolabAccountNumber', 'varchar(1000)')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)

    SELECT @TopicName = Tbl.col.value('@TopicName', 'varchar(1000)')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)

    SELECT @Active = Tbl.col.value('@Active', 'bit')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)
   
IF EXISTS (
SELECT 1
FROM [TCD].ConduitController WITH (NOLOCK)
WHERE ControllerNumber = @ControllerNumber
AND IsDeleted = 0
AND EcoalabAccountNumber = @EcolabAccountNumber
)
   BEGIN
SET @ErrorMessage = '303 - Controller Number already exists.'

RAISERROR (
@ErrorMessage
,16
,1
)

   RETURN
   END

IF EXISTS (
SELECT 1
FROM [TCD].ConduitController WITH (NOLOCK)
WHERE TopicName = @TopicName
AND IsDeleted = 0
AND EcoalabAccountNumber = @EcolabAccountNumber
)
BEGIN
SET @ErrorMessage = '304 - Controller Name already exists.'

RAISERROR (
@ErrorMessage
,16
,1
        )

RETURN
END




SELECT @ControllerModelName = Name
FROM [TCD].ControllerModel WITH (NOLOCK)
WHERE Id = @ControllerModelId

SELECT @ControllerTypeName = Name
FROM [TCD].ControllerType WITH (NOLOCK)
WHERE Id = @ControllerTypeId

DECLARE @TempMaster TABLE (
EcolabAccountNumber NVARCHAR(25)
,NAME VARCHAR(100)
,ControllerModelId INT
,ControllerNumber INT
,ControllerTypeId INT
,ControllerVersion VARCHAR(10)
,InstallDate DATETIME
,UserId INT
,TopicName VARCHAR(1000)
,Active BIT
        )
DECLARE @TempDynamic TABLE (
EcolabAccountNumber NVARCHAR(25)
,ControllerId INT
,ControllerModelId INT
,FieldGroupId INT
,FieldId INT
,Value VARCHAR(1000)
,UserId INT
)


INSERT INTO @TempDynamic (
EcolabAccountNumber
,ControllerId
,ControllerModelId
,FieldGroupId
,FieldId
,Value
,UserId
)
SELECT @EcolabAccountNumber
,0
,Tbl.col.value('@ControllerModelId', 'int')
,Tbl.col.value('@FieldGroupId', 'int')
,Tbl.col.value('@FieldId', 'int')
,Tbl.col.value('@Value', 'varchar(1000)')
,@UserId
FROM @ControllerSetupData.nodes('/ControllerSetupData/DynamicSetupData/Data') AS Tbl(col)

DECLARE @TempFieldId INT
DECLARE @TempValue VARCHAR(1000)


SELECT @TempFieldId=FieldId,@TempValue=Value FROM @TempDynamic WHERE FieldId in (21,22,47,48,87,98,116,130,148,150,171,192,208,269,309,348,387,400,414,426,438,449,460)


IF EXISTS ( SELECT 1
            FROM  [TCD].ConduitController CC WITH (NOLOCK) 
			INNER JOIN [TCD].ControllerSetupData CSD ON cc.ControllerId=csd.ControllerId 
			AND CC.Active=1
			and CSD.FieldId=@TempFieldId
			and CSD.Value =@TempValue
			and CC.ControllerTypeId=@ControllerTypeId
			and CC.ControllerModelId=@ControllerModelId
			and CC.EcoalabAccountNumber=@EcolabAccountNumber)
BEGIN
SET @ErrorMessage = '305 -IP Address/AMS Net ID Address already exists.'

RAISERROR (
@ErrorMessage
,16
,1
)

RETURN
END

 BEGIN TRANSACTION

  BEGIN TRY
INSERT INTO @TempMaster (
      EcolabAccountNumber
,NAME
,ControllerModelId
,ControllerNumber
,ControllerTypeId
,ControllerVersion
,InstallDate
,UserId
,TopicName
,Active
     )
SELECT @EcolabAccountNumber
,CAST(Tbl.col.value('@ControllerNumber', 'int') AS VARCHAR(10)) + ' (' + Tbl.col.value('@TopicName', 'varchar(100)') + ')'
    ,Tbl.col.value('@ControllerModelId', 'int')
    ,Tbl.col.value('@ControllerNumber', 'int')
    ,Tbl.col.value('@ControllerTypeId', 'varchar(100)')
    ,Tbl.col.value('@ControllerVersion', 'varchar(10)')
    ,CAST(Tbl.col.value('@InstallDate', 'datetime') AS DATETIME)
    ,@UserId
    ,Tbl.col.value('@TopicName', 'varchar(100)')
,Tbl.col.value('@Active', 'bit')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)

INSERT INTO [TCD].ConduitController (
EcoalabAccountNumber
,Name
,ControllerModelId
,ControllerNumber
,ControllerTypeId
,ControllerVersion
,InstallDate
,TopicName
,Active
,LastModifiedByUserId
    )
OUTPUT inserted.ControllerId AS ControllerId
,inserted.LastModifiedTime AS LastModifiedTimestamp
INTO @OutputList(ControllerId, LastModifiedTimestamp)
SELECT EcolabAccountNumber
,NAME
,ControllerModelId
,ControllerNumber
,ControllerTypeId
,ControllerVersion
,InstallDate
,TopicName
,Active
,UserId
FROM @TempMaster
   
SELECT TOP 1 @ControllerId = O.ControllerId
FROM @OutputList O

update @TempDynamic set ControllerId=@ControllerId

INSERT INTO [TCD].ControllerSetupData (
       EcolabAccountNumber
,ControllerId
,FieldGroupId
,FieldId
,Value
,ControllerModelId
,LastModifiedByUserId
      )
SELECT EcolabAccountNumber
,ControllerId
,FieldGroupId
,FieldId
,Value
,ControllerModelId
,UserId
FROM @TempDynamic

IF @ControllerModelId = 7
OR @ControllerModelId = 8
OR @ControllerModelId = 9
OR @ControllerModelId = 11
OR @ControllerModelId = 10
OR @ControllerModelId = 14
BEGIN
EXEC TCD.SaveDefaultControllerEquipment @ControllerId = @ControllerId
,@EcolabAccountNumber = @EcolabAccountNumber
,@UserId = @UserId;
END;

SELECT @NumOfConvWasherGroups = NumOfConvWasherGroups
,@NumOfTunnelWasherGroups = NumOfTunnelWasherGroups
FROM TCD.ControllerModelControllerTypeMapping
WHERE ControllerModelId = @ControllerModelId
AND ControllerTypeId = @ControllerTypeId

DECLARE @TotalGroupCount INT = 0;
DECLARE @WasherDosingNumber INT = 0;

IF ISNULL(@NumOfConvWasherGroups, 0) > 0
BEGIN
WHILE @LoopCount < @NumOfConvWasherGroups
            BEGIN
                SET @WasherGroupName = @TopicName + ' Dosing Group ' + CAST(@TotalGroupCount + 1 AS VARCHAR(10));
                SET @WasherDosingNumber = @TotalGroupCount + 1;

                EXEC TCD.SaveMachineGroup @GroupDescription = @WasherGroupName
                    ,@GroupTypeId = 2
                    ,@EcolabAccountNumber = @EcolabAccountNumber;

                SELECT @WasherGroupId = Id
                FROM TCD.MachineGroup
                WHERE GroupDescription = @WasherGroupName

                SELECT @WasherGroupNumber = ISNULL(MAX(CAST(WasherGroupNumber AS INT)),0) + 1
                FROM TCD.WasherGroup

                EXEC TCD.SaveWasherGroup @EcolabAccountNumber = @EcolabAccountNumber
                    ,@WasherGroupId = @WasherGroupId
                    ,@ControllerId = @ControllerId
                    ,@WasherGroupTypeId = 1
                    ,@WasherGroupName = @WasherGroupName
                    ,@WasherGroupNumber = @WasherGroupNumber
                    ,@LastModifiedByUserId = 1
                    ,@WasherDosingNumber = @WasherDosingNumber ;

                SET @LoopCount += 1;
                SET @TotalGroupCount += 1;
            END
        END

        SET @LoopCount = 0;

        IF ISNULL(@NumOfTunnelWasherGroups, 0) > 0
        BEGIN
            WHILE @LoopCount < @NumOfTunnelWasherGroups
            BEGIN
                SET @WasherGroupName = @TopicName + ' Dosing Group ' + CAST(@TotalGroupCount + 1 AS VARCHAR(10));
                SET @WasherDosingNumber = @TotalGroupCount + 1;

                EXEC TCD.SaveMachineGroup @GroupDescription = @WasherGroupName
                    ,@GroupTypeId = 2
                    ,@EcolabAccountNumber = @EcolabAccountNumber;

                SELECT @WasherGroupId = Id
                FROM TCD.MachineGroup
                WHERE GroupDescription = @WasherGroupName

                SELECT @WasherGroupNumber = ISNULL(MAX(CAST(WasherGroupNumber AS INT)),0) + 1
                FROM TCD.WasherGroup

                EXEC TCD.SaveWasherGroup @EcolabAccountNumber = @EcolabAccountNumber
                    ,@WasherGroupId = @WasherGroupId
                    ,@ControllerId = @ControllerId
                    ,@WasherGroupTypeId = 2
                    ,@WasherGroupName = @WasherGroupName
                    ,@WasherGroupNumber = @WasherGroupNumber
                    ,@LastModifiedByUserId = 1
                    ,@WasherDosingNumber = @WasherDosingNumber;

                SET @LoopCount += 1;
                SET @TotalGroupCount += 1;
            END
        END

   DECLARE @TempControllerTypeId INT, 
		   @MaxInjectionClasses INT
   SELECT @TempControllerTypeId = ControllerTypeId FROM TCD.ConduitController WHERE ControllerId = @ControllerId

   IF (@TempControllerTypeId = 1)
   BEGIN
	SET @MaxInjectionClasses = 6
   END

    IF (@TempControllerTypeId = 2)
   BEGIN
	SET @MaxInjectionClasses = 8
   END
    
	UPDATE tcd.ConduitController SET LFSInjectionClasses = @MaxInjectionClasses where ControllerId = @ControllerId
 
   COMMIT TRANSACTION

        SELECT TOP 1 @OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp
        FROM @OutputList O
  END TRY

  BEGIN CATCH
        SELECT ERROR_NUMBER() AS ErrorNumber
            ,ERROR_SEVERITY() AS ErrorSeverity
            ,ERROR_STATE() AS ErrorState
            ,ERROR_PROCEDURE() AS ErrorProcedure
            ,ERROR_LINE() AS ErrorLine
            ,ERROR_MESSAGE() AS ErrorMessage

   ROLLBACK TRANSACTION
  END CATCH

SET NOCOUNT OFF
END
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ReportProductionDetails]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ReportProductionDetails]
END
GO
CREATE PROCEDURE [TCD].[ReportProductionDetails]   
/******************************************************************  
DESCRIPTION		: 
  
  
MODIFICATION HISTORY DETAILS:   
 21st Jan 2015 -  Kiran     -  Added Formula hierarchy -->Formula segment-->Formula category-->formula  
  
  
REFERENC TABLES :  
  Select * from TCD.Plant --Plant master  
  Select * FROM TCD.PlantChain  --Master Plants  
  Select * FROM TCD.PlantChainProgram  
  Select * FROM TCD.ChainTextileCategory  
  Select * FROM TCD.ProgramMaster  
  Select * FROM TCD.EcolabTextileCategory  --Masters  
  Select * FROM TCD.EcolabSaturation --Masters  
  Select * FROM TCD.FormulaSegments --Masters  
  
EXECUTION STATEMENT :  
  
	EXEC [TCD].[ReportProductionDetails] @startdate = '2015-01-01 00:00:00',@enddate = '2016-01-01 00:00:00',@Viewtype  = '8',@Subview = '20',
          @Drillvalue = '',@EcolabAccountNumber = '040242802',@MachineType = '', @MachineGroup  = '',@Machine  = '',   
          @EcolabCategory  = '',@ChainCategory  = '', @PlantFormula  = '', @ChainFormula = '', @Customer  = '',  
          @SortColumnId  = 0,@SortDirection  = 'Desc',@CurrencyCode = '', @UserId = 1, @FormulaSegement ='',  
          @FormulaCategory='',@Formula=''
	
	EXEC [TCD].[ReportProductionDetails] @startdate = '2015-01-01 00:00:00',@enddate = '2016-01-01 00:00:00',@Viewtype  = '8',@Subview = '21',
          @Drillvalue = '1',@EcolabAccountNumber = '040242802',@MachineType = '', @MachineGroup  = '',@Machine  = '',   
          @EcolabCategory  = '',@ChainCategory  = '', @PlantFormula  = '', @ChainFormula = '', @Customer  = '',  
          @SortColumnId  = 0,@SortDirection  = 'Desc',@CurrencyCode = '', @UserId = 1, @FormulaSegement ='',  
          @FormulaCategory='',@Formula=''    

	EXEC [TCD].[ReportProductionDetails] @startdate = '2015-01-01 00:00:00',@enddate = '2016-01-01 00:00:00',@Viewtype  = '8',@Subview = '22',
          @Drillvalue = '3',@EcolabAccountNumber = '040242802',@MachineType = '', @MachineGroup  = '',@Machine  = '',   
          @EcolabCategory  = '',@ChainCategory  = '', @PlantFormula  = '', @ChainFormula = '', @Customer  = '',  
          @SortColumnId  = 0,@SortDirection  = 'Desc',@CurrencyCode = '', @UserId = 1, @FormulaSegement ='1,2',  
          @FormulaCategory='',@Formula='2'
    
*******************************************************************/ 
  
	@startdate datetime = '',  
	@enddate datetime = '',  
	@Viewtype Int = '',  
	@Subview Int= '',  
	@Drillvalue varchar(100)= '',  
	@EcolabAccountNumber Nvarchar(25) = '',  
	@MachineType VARCHAR(20)= '',  
	@MachineGroup VARCHAR(MAX) = '',  
	@Machine VARCHAR(MAX) = '',  
	@EcolabCategory VARCHAR(MAX) = '',  
	@ChainCategory VARCHAR(MAX) = '',  
	@PlantFormula  VARCHAR(MAX) = '',  
	@ChainFormula VARCHAR(MAX) = '',  
	@Customer VARCHAR(MAX) = '',  
	@SortColumnId int = 0,  
	@SortDirection varchar(4) = '',  
	@CurrencyCode varchar(3) = '',  
	@UserId INT = NULL,  
	@FormulaSegement VARCHAR(MAX)='', --Formula segment,  
	@FormulaCategory VARCHAR(MAX)='', --Formula category  
	@Formula VARCHAR(MAX)='' --Formula  
AS     
BEGIN     
SET NOCOUNT ON   
	 SET @startdate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@startdate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@startdate AS time)) AS DateTime))  
	 SET @EndDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndDate AS time)) AS DateTime))  

	 --SELECT @startdate,@EndDate 
	 DECLARE @ReportGenerated INT = 6, @Month INT = MONTH(GETDATE()),@CorrectionVariable Decimal(18,2),@PlantTargetProduction decimal(18,2)  
        
	 /* Inserting the record into Report History */  
	 INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)  
	 SELECT @EcolabAccountNumber,UM.UserId,UM.LoginName,GETUTCDATE(),@ReportGenerated,  
	 CASE WHEN @ReportGenerated = 6  
	  THEN 'Generated Report : Production Details Report' END  
	 FROM TCD.UserMaster UM  
	 WHERE UM.EcolabAccountNumber = @EcolabAccountNumber AND UM.UserId = @UserId  
       
	-- Return Table set  
	DECLARE @resultSet Table  
	(  
		ShiftId Int,  
		DateRange varchar(100),  
		TotalLoad Decimal(18,2) ,  
		WasherEfficiency Decimal(18,2),  
		PlantTargetLoad Decimal(18,2) ,  
		StandardLoad Decimal(18,2) ,  
		Numberofbatches INT,  
		[ActualRunTime] Decimal(30,10) NULL,  
		[TargetRunTime] Decimal(30,10) NULL,  
		NumberofPieces  [int] NULL,  
		Rewash [int] NULL,  
		Viewtype varchar(100) NULL,  
		Subview varchar(100) NULL,  
		Id int NULL        
	)  
  
	-- Correction factor
	DECLARE @CorrectionFactor TABLE   
	(  
		[ShiftId] [int] NULL,  
		MachineId INT NULL,  
		[ActualProduction] [int] NULL,  
		[StandardProduction] [int] NULL,  
		[PlantTargetProd] [int] NULL,  
		[ActualRunTime] [int] NULL,  
		[TargetRunTime] [int] NULL,  
		ManualInputWeight INT,  
		ManulainputsNoofloads INT  
	)  
      
	--Machine type  
	DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))  
	INSERT INTO @MachineTypeTable EXEC [TCD].[CharlistToTable] @MachineType,','  
  
	--washer Group  
	DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))  
	INSERT INTO @WasherGroupTable EXEC [TCD].[CharlistToTable] @machineGroup,','    
  
	--Machine list  
	DECLARE @MachineTable TABLE(Machine Varchar(100))  
	INSERT INTO @MachineTable EXEC [TCD].[CharlistToTable] @Machine,','  
  
	--Ecolab category  
	DECLARE @EcolabCategoryTable TABLE(EcolabCategory Varchar(100))  
	INSERT INTO @EcolabCategoryTable EXEC [TCD].[CharlistToTable] @EcolabCategory,','  
  
	--Chain category  
	DECLARE @ChainCategoryTable TABLE(ChainCategory Varchar(100))  
	INSERT INTO @ChainCategoryTable EXEC [TCD].[CharlistToTable] @ChainCategory,','  
  
	--Plant formula  
	DECLARE @PlantFormulaTable TABLE(PlantFormula Varchar(100))  
	INSERT INTO @PlantFormulaTable EXEC [TCD].[CharlistToTable] @PlantFormula,','  
  
	--Chain Formula  
	DECLARE @ChainFormulaTable TABLE(ChainFormula Varchar(100))  
	INSERT INTO @ChainFormulaTable EXEC [TCD].[CharlistToTable] @ChainFormula,','  
  
	 --Customer Table  
	DECLARE @CustomerTable TABLE(Customer Varchar(100))  
	INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','  
  
	 --Formula Segment --added by Kiran  
	DECLARE @FormulaSegmentTable TABLE(FormulaSegment Varchar(1000))  
	INSERT INTO @FormulaSegmentTable EXEC [TCD].[CharlistToTable] @FormulaSegement,','  
  
-----Formula category--------Start  
	DECLARE @FormulaCategoryTable TABLE(FormulaCategory Varchar(1000),Type CHAR(1))  
	INSERT INTO @FormulaCategoryTable(FormulaCategory) EXEC [TCD].[CharlistToTable] @Formulacategory,','     	   
  
		--Below 1000 Ecolab category  
		UPDATE @FormulaCategoryTable SET TYPE='E' WHERE FormulaCategory<1000  
		--Above 1000 consider as Chain category  
		UPDATE @FormulaCategoryTable SET TYPE='C' WHERE FormulaCategory>=1000  
  
		--Rollbacking to actual ID  
		UPDATE @FormulaCategoryTable SET FormulaCategory=FormulaCategory-1000 WHERE TYPE='C'  
		--SELECT * FROM @FormulaCategoryTable  
  
		INSERT INTO @EcolabCategoryTable(EcolabCategory)  
		SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='E'   
  
		INSERT INTO @ChainCategoryTable(ChainCategory)  
		SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='C'  
  
		--Value Assigning  
		IF (EXISTS(SELECT * FROM @EcolabCategoryTable) AND @FormulaCategory!='')  
		BEGIN  
		SET @EcolabCategory=@FormulaCategory  
		END  
		IF (EXISTS(SELECT * FROM @ChainCategoryTable) AND @FormulaCategory!='')  
		BEGIN  
		SET @ChainCategory=@FormulaCategory  
		END  
---Formula category-------------------------End  
  
 -----Formula Ecolab/Chain formulas  
	DECLARE @FormulaTable TABLE(Formula Varchar(1000),Type CHAR(1))  
	INSERT INTO @FormulaTable(Formula) EXEC [TCD].[CharlistToTable] @Formula,','  
   	 
		--Plant fomula     
		INSERT INTO @PlantFormulaTable(PlantFormula)   
		SELECT Formula FROM @FormulaTable --WHERE Type='E'  
		--chain formula     
		INSERT INTO @ChainFormulaTable(ChainFormula)   
		SELECT Formula FROM @FormulaTable --WHERE Type='C'  
		--Select * FROM @FormulaTable
		--SELECT * FROM @PlantFormulaTable  
		--SELECT * FROM @ChainFormulaTable  
  
		 --Value Assigning  
		 IF (EXISTS(SELECT * FROM @PlantFormulaTable) AND @Formula!='')  
		 BEGIN  
				SET @PlantFormula=@Formula
		 END  
		 IF (EXISTS(SELECT * FROM @ChainFormulaTable) AND @Formula!='')  
		 BEGIN  
				SET @ChainFormula=@Formula
		 END  
			--SELECT @PlantFormula,@ChainFormula  
-----Formula Segregation end  
  
	 --Insert Into @CorrectionFactor table  
	 INSERT INTO @CorrectionFactor  
	 (  
		  [ShiftId],  
		  [MachineId] ,  
		  [ActualProduction] ,  
		  [StandardProduction] ,  
		  [PlantTargetProd] ,  
		  [ActualRunTime] ,  
		  [TargetRunTime],  
		  ManualInputWeight,  
		  ManulainputsNoofloads     
	 )  
	 SELECT   
	  PS.[ShiftId],  
	  SPD.[MachineId],  
	  ISNULL([TCD].[FnConsumptionOnMetrics](SUM(ISNULL(SPD.[ActualProduction],0))+SUM(ISNULL(MIP.ActualWeight,0)),'Weight',@UserId),0),  
	  --ISNULL([TCD].[FnConsumptionOnMetrics](SUM(ISNULL(SPD.[ActualProduction],0)),'Weight',@UserId),0),    
	  --SUM(SPD.[ActualProduction]),  
	  ISNULL([TCD].[FnConsumptionOnMetrics](SUM(ISNULL(SPD.StandardProduction,0)),'Weight',@UserId),0),  
	  --SUM(SPD.StandardProduction),  
	  ISNULL([TCD].[FnConsumptionOnMetrics](SUM(DISTINCT ISNULL(SPD.[PlantTargetProd],0)),'Weight',@UserId),0),  
	  --SUM(DISTINCT SPD.[PlantTargetProd]),  
	  SUM(ISNULL(SPD.[ActualRunTime],0) + ISNULL(SPD.ActualTurnTime,0)),  
	  SUM(ISNULL(SPD.[TargetRunTime],0) + ISNULL(SPD.TargetTurnTime,0)),  
	  SUM(ISNULL(MIP.ActualWeight,0)),SUM(ISNULL(MIP.NoofLoads,0))  
	 FROM  TCD.ShiftProductionDataRollup SPD   
	 INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId  
	 LEFT OUTER JOIN --Manual Production Details appending  
	  (  
	   SELECT WasherId,FormulaId,CONVERT(DATE,RecordedDate) AS LoadDate,SUM(ISNULL(Value,0)) AS ActualWeight,  
	   ISNULL(COUNT(CONVERT(DATE,RecordedDate)),0) AS NoofLoads FROM  
	   TCD.ManualProduction MP  
	   GROUP BY WasherId,FormulaId,CONVERT(DATE,RecordedDate)  
	  )MIP ON MIP.WasherId=SPD.EcolabWasherId AND MIP.FormulaId=SPD.ProgramMasterId AND MIP.LoadDate=CONVERT(DATE,PS.StartDateTime)  
	 WHERE   
	  CASE @StartDate                                                                                  
	  WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                  
	  ELSE CASE WHEN PS.[StartDateTime] >= @startdate  AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                          
	  END='TRUE'   
	 GROUP BY MachineId,PS.ShiftId;  
  
	 WITH CTE (PlantTargetProd) AS  
	 (  
	 SELECT SUM(DISTINCT SPD.[PlantTargetProd]) FROM @CorrectionFactor SPD GROUP BY ShiftId  
	 )  
	 SELECT @PlantTargetProduction = SUM(PlantTargetProd) FROM CTE;  
  
	 WITH CTE (MachineId,PlantEfficiency)  
	 AS  
	 (  
	 SELECT   
	  MachineId,  
	  CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/   
	   NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) *   
	   COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2))     
	   FROM @CorrectionFactor SPD GROUP BY MachineId  
	 )  
		SELECT @CorrectionVariable = @PlantTargetProduction/NULLIF(SUM(PlantEfficiency),0) FROM CTE  
  	
	 DECLARE @ProductionSummaryTable TABLE  
	 (  
	  [ShiftId] [int] NULL,  
	  [ShiftName] Varchar(100) NULL,  
	  RecordDate date,   
	  [MachineId] [int] NULL,  
	  [ProgramMasterId] [int] NULL,  
	  [EcolabWasherId] [int] NULL,  
	  [ActualProduction] [int] NULL,  
	  [StandardProduction] [int] NULL,  
	  [NoOfLoads] [int] NULL,  
	  [LoadEfficiency] [decimal](18, 2) NULL,  
	  [TimeEfficiency] [decimal](18, 2) NULL,  
	  TotalEfficiency [decimal](18, 2) NULL,  
	  [PlantTargetProd] [int] NULL,  
	  [ActualRunTime] INT NULL,  
	  [TargetRunTime] INT NULL,  
	  EcolabTextileId int,  
	  ChainTextileId int,  
	  ChainProgaramId int,  
	  CustomerId int,  
	  NoOfPieces int,  
	  Rewash Int,  
	  [ShiftRunTime] DECIMAL(30,10) NULL,  
	  FormulaSegmentID INT,  
	  RowNumberID INT,
	  IndividualShiftRunTime Decimal(30,10),
	  ShiftRownumber INT  
	 )  
  
	INSERT INTO @ProductionSummaryTable  
	SELECT   
		PS.[ShiftId],  
		PS.ShiftName,  
		CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date),  		 
		SPD.[MachineId],  
		SPD.[ProgramMasterId],  
		SPD.[EcolabWasherId],  
		ISNULL(SPD.[ActualProduction],0),  
		ISNULL(SPD.StandardProduction,0),  
		ISNULL(SPD.[NoOfLoads],0),  
		ISNULL(SPD.[LoadEfficiency],0),  
		ISNULL(SPD.[TimeEfficiency],0),  
		(ISNULL(SPD.[LoadEfficiency],0) * ISNULL(SPD.TimeEfficiency,0)),  
		ISNULL(SPD.[PlantTargetProd],0),  
		ISNULL(SPD.[ActualRunTime],0) + ISNULL(SPD.ActualTurnTime,0),  
		ISNULL(SPD.[TargetRunTime],0) + ISNULL(SPD.TargetTurnTime,0),  
		SPD.EcolabTextileId,  
		SPD.ChainTextileId,  
		SPD.ChainProgaramId,  
		SPD.CustomerId,  
		ISNULL(SPD.NoOfPieces,0),  
		CAST((  
			SELECT spdr.ActualProduction FROM TCD.ShiftProductionDataRollup spdr WHERE spdr.ShiftId = SPD.ShiftId AND spdr.MachineId = SPD.MachineId  
			AND spdr.ProgramMasterId = SPD.ProgramMasterId AND spdr.ProgramMasterId IN (SELECT pm.ProgramId FROM TCD.ProgramMaster pm WHERE pm.Rewash = 1)  
			) AS decimal(18,2)),  
		DATEDIFF(Second,ps.StartDateTime,PS.EndDateTime) +  
		ISNULL(  
			(  
			SELECT  
			SUM(SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0))  
			FROM TCD.ShiftProductionDataRollup SPD INNER JOIN TCD.ProductionShiftData PSD ON SPD.ShiftId = PSD.ShiftId  
			WHERE PSD.[StartDateTime] = PS.StartDateTime AND PSD.[StartDateTime] = PS.EndDateTime AND PS.ShiftName = 'No Shift'  
			) ,0),  
		CASE WHEN SPD.ChainProgaramId IS NOT NULL THEN ChainPlant.FormulaSegmentId  
		ELSE FS1.FormulaSegmentID END AS Formulasegment,  
		ROW_NUMBER() OVER(Partition BY SPD.ProgramMasterId, SPD.[EcolabWasherId], CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date)  
		ORDER BY SPD.ProgramMasterId, SPD.[EcolabWasherId] ) ,
		0, --IndividualShiftruntime
		ROW_NUMBER() OVER(Partition BY SPD.ShiftID  ORDER BY SPD.ShiftID)
  
		--CAST(((SELECT SUM(MR.VALUE) FROM TCD.ManualRewash MR WHERE SPD.ProgramMasterId = MR.FormulaId AND CAST(PS.StartDateTime AS date) = CAST(MR.RecordedDate AS date) GROUP BY CAST(MR.RecordedDate AS date),MR.FormulaId)) AS decimal(18,2))  
	FROM  TCD.ShiftProductionDataRollup SPD   
	INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId  
	INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId   
	INNER JOIN TCD.MachineSetup ms ON SPD.MachineId = ms.WasherId  
	LEFT OUTER JOIN  
	(  
		--IF Chain Plant  
		SELECT PCP.PlantProgramId,PCP.PlantChainId,PCP.ChainTextileCategoryId,PCP.EcolabTextileCategoryId,  
		PCP.FormulaSegmentId,PCP.EcolabSaturationId  
		FROM TCD.PlantChainProgram PCP    
		LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=PCP.FormulaSegmentId    
	)ChainPlant ON SPD.ChainProgaramId=ChainPlant.PlantProgramId    
	LEFT OUTER JOIN TCD.FormulaSegments FS1 ON FS1.FormulaSegmentID=PM.FormulaSegmentId   
	WHERE isNull(ms.IsPony,0) = 0  
	AND   
		CASE @StartDate                                                                                  
		WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                  
		ELSE CASE WHEN PS.[StartDateTime] >= @startdate  AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                          
		END='TRUE'   
	AND  
		CASE @MachineType     
		WHEN '' THEN 'TRUE'           
		ELSE                                                        
		CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE        
		MS.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable))) THEN 'TRUE' END                                                        
		END='TRUE'      
	AND  
		CASE @machineGroup     
		WHEN '' THEN 'TRUE'           
		ELSE                                                        
		CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE        
		MS.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable)) THEN 'TRUE' END                                                        
		END='TRUE'   
	AND    
		CASE @Machine     
		WHEN '' THEN 'TRUE'           
		ELSE                                                        
		CASE WHEN SPD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                   
		END='TRUE'   
	AND        
		CASE @EcolabCategory     
		WHEN '' THEN 'TRUE'           
		ELSE                                                        
		CASE WHEN SPD.EcolabTextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                        
		END='TRUE'   
	AND        
		CASE @ChainCategory     
		WHEN '' THEN 'TRUE'           
		ELSE                                                        
		CASE WHEN SPD.ChainTextileId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END                                                        
		END='TRUE'  
	AND    
		CASE @PlantFormula     
		WHEN '' THEN 'TRUE'           
		ELSE                                                        
		CASE WHEN SPD.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                        
		END='TRUE'    
	AND       
		CASE @ChainFormula     
		WHEN '' THEN 'TRUE'           
		ELSE                                                        
		CASE WHEN SPD.ProgramMasterId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END                                                        
		END='TRUE'  
	AND        
		CASE @Customer     
		WHEN '' THEN 'TRUE'           
			ELSE                                                        
			CASE WHEN SPD.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                        
		END='TRUE'  
	--Added by Kiran   
	AND   
		CASE @FormulaSegement                                                                                  
		WHEN '' THEN  'TRUE'  
		ELSE  
			CASE WHEN SPD.ChainProgaramId  IS NOT NULL THEN  
				CASE WHEN ChainPlant.FormulaSegmentId IN (SELECT FormulaSegment FROM @FormulaSegmentTable) THEN 'TRUE' END                                                                                       
			ELSE   
			CASE WHEN FS1.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)  THEN 'TRUE'END     
		END                                                       
		END='TRUE'  
	-----ENd  
  
   	 --For top 1 record combination updating the manual input data.  
	 UPDATE S SET ActualProduction=ISNULL(S.ActualProduction,0)+ISNULL(MIP.ManualIPActualWeight,0),S.NoOfLoads=ISNULL(S.NoOfLoads,0)+ISNULL(MIP.NoofLoads,0)  
	 FROM  @ProductionSummaryTable S  
	 INNER JOIN   
	  (  
	  SELECT WasherId,FormulaId,CONVERT(DATE,RecordedDate) AS LoadDate,SUM(Value) AS ManualIPActualWeight,  
	  COUNT(CONVERT(DATE,RecordedDate)) AS NoofLoads FROM  
	  TCD.ManualProduction MP  
	  GROUP BY WasherId,FormulaId,CONVERT(DATE,RecordedDate)  
	  )MIP ON MIP.WasherId=S.MachineId AND MIP.FormulaId=S.ProgramMasterId AND MIP.LoadDate=S.RecordDate  
	  WHERE S.RowNumberID=1  
	   
	/*	
		--Finding Max shift runtime for Particula shift
		UPDATE S SET S.IndividualShiftRunTime=MIP.MaxShiftruntime,S.ShiftRunTime=MIP.MaxShiftruntime
		FROM  @ProductionSummaryTable S  
		INNER JOIN   
		(  
			SELECT ShiftId,MAX(ShiftRunTime) AS MaxShiftruntime FROM @ProductionSummaryTable	 
			GROUP BY ShiftID 
		)MIP ON MIP.ShiftId=S.ShiftId	 
	  
		--Dividing Maxshift time for all the shift based records
		UPDATE S SET S.IndividualShiftRunTime=(S.IndividualShiftRunTime/PS.noofShifts),S.ShiftRunTime=(S.ShiftRunTime/PS.noofShifts)
		FROM  @ProductionSummaryTable S  
		INNER JOIN   
  			(	 
			SELECT PS1.ShiftID,Count(PS1.ShiftID)AS noofShifts 
			FROM  TCD.ShiftProductionDataRollup SPD   
			INNER JOIN TCD.ProductionShiftData PS1 ON SPD.ShiftId = PS1.ShiftId  
			INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId AND PS1.EcolabAccountNumber=PM.EcolabAccountNumber  
			INNER JOIN TCD.MachineSetup ms ON SPD.MachineId = ms.WasherId	
			WHERE isNull(ms.IsPony,0) = 0  AND PM.EcolabAccountNumber=@EcolabAccountNumber
			GROUP BY PS1.shiftID		 
			) PS  
			ON PS.ShiftId=S.ShiftId 
	*/
	
	
	DECLARE @TableShiftruntime TABLE(ShiftID INT ,ShiftRuntime Decimal(20,10),ID INT,Name VARCHAR(1000))	
    
	 IF(@Viewtype = 3)  
	 BEGIN  
	  IF(@Subview = 12)  
	  BEGIN  
	   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,TextileId)  
		AS  
		(  
		 SELECT   
		EC.CategoryName,  
		SUM(SPD.ActualProduction),  
		COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
		SUM(DISTINCT SPD.PlantTargetProd),  
		SUM(SPD.StandardProduction),  
		SUM([NoOfLoads]),  
		SUM( SPD.ShiftRunTime),  
		SUM( SPD.ShiftRunTime),  
		SUM(SPD.NoOfPieces),  
		SUM(SPD.Rewash),  
		EC.TextileId  
		  FROM @ProductionSummaryTable SPD LEFT JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId  
		WHERE EC.CategoryName IS NOT NULL  
		GROUP BY   
		  EC.CategoryName,EC.TextileId,SPD.ShiftId  
		  )  
		  INSERT INTO @resultSet  
		  SELECT DISTINCT  
		0,  
		DateRange,  
		SUM(TotalLoad),  
		SUM(WasherEfficiency),  
		SUM(PlantTargetLoad),  
		SUM(StandardLoad),  
		SUM(Numberofbatches),  
		SUM(ActualRunTime),  
		SUM(TargetRuntime),  
		SUM(NumberofPieces),  
		SUM(Rewash)  
		,@Viewtype   
		,@Subview  
		,TextileId  
		FROM CTE  
		WHERE TotalLoad IS NOT NULL  
		GROUP BY DateRange,TextileId     
		 END  
	  IF(@Subview = 17)  
	  BEGIN  
	   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
	   AS  
	   (  
	   SELECT   
     
	   PM.Name,  
	   SUM(SPD.ActualProduction),  
	   COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
	   SUM(DISTINCT SPD.PlantTargetProd),  
	   SUM(SPD.StandardProduction),  
	   SUM([NoOfLoads]),  
	   SUM( SPD.ShiftRunTime),  
	   SUM( SPD.ShiftRunTime),  
	   SUM(SPD.NoOfPieces),  
	   SUM(SPD.Rewash)  
		FROM @ProductionSummaryTable SPD INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId  
		 INNER JOIN TCD.ProgramMaster PM ON EC.TextileId = PM.EcolabTextileCategoryId AND SPD.ProgramMasterId = PM.ProgramId      
	   WHERE  
		(  
		CASE      
		 WHEN @drillvalue='' THEN 'TRUE'   
		 WHEN @drillvalue IS NULL THEN 'TRUE'    
		 ELSE                                                      
		  CASE WHEN EC.TextileId IN (@drillvalue) THEN 'TRUE' END              
		 END='TRUE'  
		) AND PM.NAME IS NOT NULL  
	   GROUP BY   
		  PM.Name,SPD.ShiftId  
		 )  
	   INSERT INTO @resultSet  
		 SELECT DISTINCT  
	   0,  
		  DateRange,  
		  SUM(TotalLoad),  
		  SUM(WasherEfficiency),  
		  SUM(PlantTargetLoad),  
		  SUM(StandardLoad),  
		  SUM(Numberofbatches),  
		  SUM(ActualRunTime),  
		  SUM(TargetRuntime),  
		  SUM(NumberofPieces),  
		  SUM(Rewash)  
		  ,@Viewtype   
		  ,@Subview  
		,0  
		   FROM CTE  
		 WHERE TotalLoad IS NOT NULL  
		 GROUP BY DateRange  
	  END    
	 END  
  
	-- ************************ By Textile Category View ************************************************  
	 IF(@Viewtype = 4)  
	 BEGIN   
	  IF(@Subview = 15)  
	  BEGIN  
	   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
		AS  
		(  
		SELECT      
		CC.Name,  
		SUM(SPD.ActualProduction),  
		COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
		SUM(DISTINCT SPD.PlantTargetProd),  
		SUM(SPD.StandardProduction),  
		SUM([NoOfLoads]),  
		SUM( SPD.ShiftRunTime),  
		SUM( SPD.ShiftRunTime),  
		SUM(SPD.NoOfPieces),  
		SUM(SPD.Rewash)  
		FROM @ProductionSummaryTable SPD LEFT JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId  
		WHERE CC.Name IS NOT NULL   
		GROUP BY   
		  CC.Name,CC.TextileId,SPD.ShiftId  
		  )  
		INSERT INTO @resultSet  
		  SELECT DISTINCT  
		0,  
		   DateRange,  
		   SUM(TotalLoad),  
		   SUM(WasherEfficiency),  
		   SUM(PlantTargetLoad),  
		   SUM(StandardLoad),  
		   SUM(Numberofbatches),  
		   SUM(ActualRunTime),  
		   SUM(TargetRuntime),  
		   SUM(NumberofPieces),  
		   SUM(Rewash)  
		   ,@Viewtype   
		   ,@Subview  
		 ,0  
		 FROM CTE  
		 WHERE TotalLoad IS NOT NULL  
		 GROUP BY DateRange  
			END    
	  IF(@Subview = 18)  
	  BEGIN  
	   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
		AS  
		(  
		SELECT          
		PM.Name,  
		SUM(SPD.ActualProduction),  
		COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
		SUM(DISTINCT SPD.PlantTargetProd),  
		SUM(SPD.StandardProduction),  
		SUM([NoOfLoads]),  
		SUM( SPD.ShiftRunTime),  
		SUM( SPD.ShiftRunTime),  
		SUM(SPD.NoOfPieces),  
		SUM(SPD.Rewash)  
		   FROM @ProductionSummaryTable SPD INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId  
		  INNER JOIN TCD.ProgramMaster PM ON CC.TextileId = PM.ChainTextileId AND SPD.ProgramMasterId = PM.ProgramId  
      
	   WHERE  
		(  
		CASE      
		 WHEN @drillvalue='' THEN 'TRUE'   
		 WHEN @drillvalue IS NULL THEN 'TRUE'    
		 ELSE                                                      
		  CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END              
		 END='TRUE'  
		)  
	   GROUP BY   
		  PM.Name,SPD.ShiftId  
		  )  
		INSERT INTO @resultSet  
		  SELECT DISTINCT  
		0,  
		   DateRange,  
		   SUM(TotalLoad),  
		   SUM(WasherEfficiency),  
		   SUM(PlantTargetLoad),  
		   SUM(StandardLoad),  
		   SUM(Numberofbatches),  
		   SUM(ActualRunTime),  
		   SUM(TargetRuntime),  
		   SUM(NumberofPieces),  
		   SUM(Rewash)  
		   ,@Viewtype   
		   ,@Subview  
		 ,0  
			FROM CTE  
		  WHERE TotalLoad IS NOT NULL  
		  GROUP BY DateRange  
	  END  
	 END  
  
	  -- ******************************** Timeline View ***************************************************  
	 IF(@Viewtype = 1)  
	 BEGIN  
		---- By TimeLine - Day View  
		IF(@Subview = 5)  
		BEGIN 
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			SPD.ShiftName  
			FROM @ProductionSummaryTable SPD ;			
		 
			INSERT INTO @resultSet  
			SELECT DISTINCT  
			0,  
			SPD.ShiftName,  
			SUM(SPD.ActualProduction),  
			COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
			SUM(DISTINCT SPD.PlantTargetProd),  
			SUM(SPD.StandardProduction),  
			SUM([NoOfLoads]),  
			SUM( SPD.ShiftRunTime),  
			SUM( SPD.ShiftRunTime),  
			SUM(SPD.NoOfPieces),  
			SUM(SPD.Rewash)  
			,@Viewtype   
			,@Subview  
			,0  
			FROM @ProductionSummaryTable SPD  
			GROUP BY   
			SPD.ShiftName;

			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name		
		  
		 END  
  
		---- By TimeLine - Week View  
		IF (@Subview = 4)  
		BEGIN  
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			CAST(RecordDate AS nvarchar(100))  
			FROM @ProductionSummaryTable SPD ;

			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
			AS  
			(  
				SELECT   
				CAST(RecordDate AS nvarchar(100)),  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM(SPD.StandardProduction),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime),  
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash)  
				FROM @ProductionSummaryTable SPD  
				GROUP BY DATEPART(weekday,RecordDate),RecordDate,SPD.ShiftId    
			)  
			INSERT INTO @resultSet  
			SELECT DISTINCT  
			0,  
			DateRange,  
			SUM(TotalLoad),  
			SUM(WasherEfficiency),  
			SUM(PlantTargetLoad),  
			SUM(StandardLoad),  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime),  
			SUM(NumberofPieces),  
			SUM(Rewash)  
			,@Viewtype   
			,@Subview  
			,0  
			FROM CTE  
			WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange;  

			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name

		END  
		
		---- By TimeLine - Month View  
		IF(@Subview = 3)  
		BEGIN  
		   DECLARE @FirstDay date = (SELECT TOP 1 RecordDate FROM @ProductionSummaryTable ORDER BY RecordDate)  
		   DECLARE @LastDay date = (SELECT TOP 1 RecordDate FROM @ProductionSummaryTable ORDER BY RecordDate DESC)  
		   DECLARE @FirstSunday date = NULL,  
		   @LastSaturday date = NULL  
        
		   SELECT   
		   @FirstSunday = CAST(DateAdd(dd, (8-DatePart(WEEKDAY,   
		   DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)))%7,   
		   DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)) AS DATE)   
  
		   SELECT  
		   @LastSaturday =   
		   DATEADD(dd,  
			-DATEPART(WEEKDAY,  
			 DATEADD(dd, -DAY(DATEADD(month, 1, @LastDay)),  
			 DATEADD(month, 1, @LastDay))) ,  
			DATEADD(dd, -DAY(DATEADD(MONTH, 1, @LastDay)), DATEADD(MONTH, 1, @LastDay)));  
		  
		  INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
		  SELECT DISTINCT SPD.ShiftId,SPD.ShiftRunTime AS ShiftRuntime,
				CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,-1,@FirstSunday)) = 7   
				AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate < DATEADD(DD,-1,@FirstSunday)) = 0)  
				THEN CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100))  
				WHEN DATEADD(DD,-1,@FirstSunday) > CAST(GETDATE() AS DATE)   
				THEN  
				CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @enddate, 101) AS nvarchar(100))  
				ELSE  
				CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) END As DateRange 
				FROM @ProductionSummaryTable SPD WHERE RecordDate < @FirstSunday AND RecordDate >= @FirstDay
		 UNION ALL
		  
		 SELECT DISTINCT SPD.ShiftId,SPD.ShiftRunTime AS ShiftRuntime,
				CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100))  + CHAR(13) + '-' +  
				CASE WHEN CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 121) AS nvarchar(100)) >  
				CAST(Convert(varchar, DateAdd(dd, (1 - DatePart(dw, @enddate) + 1), @enddate), 121) AS nvarchar(100))  
				THEN  CAST(Convert(varchar, DateAdd(dd, 1-1, @enddate), 101) AS nvarchar(100))  
				ELSE CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) END
				FROM @ProductionSummaryTable SPD  
				WHERE RecordDate BETWEEN @FirstSunday AND @LastSaturday

		 UNION ALL

		 SELECT DISTINCT SPD.ShiftId,SPD.ShiftRunTime AS ShiftRuntime,
		 CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,1,@LastSaturday)) = 1   
				AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate > DATEADD(DD,1,@LastSaturday)) = 0)  
				THEN   
				CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100))   
				ELSE  
				CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @LastDay, 101) AS nvarchar(100)) END
				FROM @ProductionSummaryTable SPD  
				WHERE RecordDate > @LastSaturday AND RecordDate <= @LastDay;
				
  
		   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash) 
		    
		   AS  
		   (  
				SELECT          
				CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,-1,@FirstSunday)) = 7   
				AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate < DATEADD(DD,-1,@FirstSunday)) = 0)  
				THEN CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100))  
				WHEN DATEADD(DD,-1,@FirstSunday) > CAST(GETDATE() AS DATE)   
				THEN  
				CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @enddate, 101) AS nvarchar(100))  
				ELSE  
				CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) END As DateRange,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM(SPD.StandardProduction),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime),  
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash)  
  
				FROM @ProductionSummaryTable SPD  
				WHERE RecordDate < @FirstSunday AND RecordDate >= @FirstDay  
				GROUP BY SPD.ShiftId   
          
				UNION ALL    
    
				SELECT    
				CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100))  + CHAR(13) + '-' +  
				CASE WHEN CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 121) AS nvarchar(100)) >  
				CAST(Convert(varchar, DateAdd(dd, (1 - DatePart(dw, @enddate) + 1), @enddate), 121) AS nvarchar(100))  
				THEN  CAST(Convert(varchar, DateAdd(dd, 1-1, @enddate), 101) AS nvarchar(100))  
				ELSE CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) END  
				As DateRange,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM(SPD.StandardProduction),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime),  
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash)  
				FROM @ProductionSummaryTable SPD  
				WHERE RecordDate BETWEEN @FirstSunday AND @LastSaturday  
				GROUP BY Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101),  
				Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101),
				Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 121),		
				SPD.ShiftId  
         
				UNION ALL  
  
				SELECT   
				CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,1,@LastSaturday)) = 1   
				AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate > DATEADD(DD,1,@LastSaturday)) = 0)  
				THEN   
				CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100))   
				ELSE  
				CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @LastDay, 101) AS nvarchar(100)) END   As DateRange,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM(SPD.StandardProduction),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime),  
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash)  
				FROM @ProductionSummaryTable SPD  
				WHERE RecordDate > @LastSaturday AND RecordDate <= @LastDay   
				GROUP BY SPD.ShiftId  
		   )  
		   INSERT INTO @resultSet  
		   SELECT DISTINCT  
		   0,  
		   DateRange,  
		   SUM(TotalLoad),  
		   SUM(WasherEfficiency),  
		   SUM(PlantTargetLoad),  
		   SUM(StandardLoad),  
		   SUM(Numberofbatches),  
		   SUM(ActualRunTime),  
		   SUM(TargetRuntime),  
		   SUM(NumberofPieces),  
		   SUM(Rewash)  
		   ,@Viewtype   
		   ,@Subview  
			,0  
			FROM CTE  
			WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange ; 
		  
		   WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name
		END  
  
		IF(@Subview = 2)  
		BEGIN  
		   DECLARE @QuarterYear VARCHAR(100) = YEAR(@enddate);  

			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			DATENAME(MONTH, RecordDate) + ' ' +CAST( YEAR(RecordDate) as varchar)  
			FROM @ProductionSummaryTable SPD;

		   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
		   AS  
		   (  
				SELECT   
				DATENAME(MONTH, RecordDate) + ' ' +CAST( YEAR(RecordDate) as varchar) As DateRange,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM(SPD.StandardProduction),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime),  
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash)  
				FROM @ProductionSummaryTable SPD  
				GROUP BY  DATEPART(MONTH, RecordDate),DATENAME(MONTH, RecordDate),SPD.ShiftId,YEAR(RecordDate)  
		   )  
		    INSERT INTO @resultSet  
			SELECT DISTINCT  
			0,  
			DateRange,  
			SUM(TotalLoad),  
			SUM(WasherEfficiency),  
			SUM(PlantTargetLoad),  
			SUM(StandardLoad),  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime),  
			SUM(NumberofPieces),  
			SUM(Rewash)  
			,@Viewtype   
			,@Subview  
			,0  
			FROM CTE  
			WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange;
			
			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name
			 
		END     
  
		IF(@Subview = 1)  
		BEGIN  
			DECLARE @Year VARCHAR(100) = RIGHT(YEAR(@enddate),2);  
			
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name,ID)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			CASE 'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10))  
				WHEN 'Q1' THEN 'Jan' + RIGHT(YEAR(RecordDate),2)  + '- Mar' + RIGHT(YEAR(RecordDate),2)   
				WHEN 'Q2' THEN 'Apr' + RIGHT(YEAR(RecordDate),2)  + '- Jun' + RIGHT(YEAR(RecordDate),2)   
				WHEN 'Q3' THEN 'Jul' + RIGHT(YEAR(RecordDate),2)  + '-Sep' + RIGHT(YEAR(RecordDate),2)   
				WHEN 'Q4' THEN 'Oct' + RIGHT(YEAR(RecordDate),2)  + '- Dec'+ RIGHT(YEAR(RecordDate),2)   
				END, 
			cast( cast(RIGHT(YEAR(RecordDate),2) AS varchar ) +cast(  DATEPART(QUARTER, RecordDate) AS varchar) AS int)
			FROM @ProductionSummaryTable SPD ;
			
		    WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,RowNo)  
		    AS  
		    (  
				SELECT   
				CASE 'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10))  
				WHEN 'Q1' THEN 'Jan' + RIGHT(YEAR(RecordDate),2)  + '- Mar' + RIGHT(YEAR(RecordDate),2)   
				WHEN 'Q2' THEN 'Apr' + RIGHT(YEAR(RecordDate),2)  + '- Jun' + RIGHT(YEAR(RecordDate),2)   
				WHEN 'Q3' THEN 'Jul' + RIGHT(YEAR(RecordDate),2)  + '-Sep' + RIGHT(YEAR(RecordDate),2)   
				WHEN 'Q4' THEN 'Oct' + RIGHT(YEAR(RecordDate),2)  + '- Dec'+ RIGHT(YEAR(RecordDate),2)   
				END AS DateRange,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM(SPD.StandardProduction),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime),  
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash),
				cast( cast(RIGHT(YEAR(RecordDate),2) AS varchar ) +cast(  DATEPART(QUARTER, RecordDate) AS varchar) AS int)  RowNo  
				FROM @ProductionSummaryTable SPD  
				GROUP BY DATEPART(QUARTER, RecordDate),SPD.ShiftId ,RIGHT(YEAR(RecordDate),2)   
			)  
  
			INSERT INTO @resultSet  
			SELECT   
			0,  
			DateRange,  
			SUM(TotalLoad),  
			SUM(WasherEfficiency),  
			SUM(PlantTargetLoad),  
			SUM(StandardLoad),  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime),  
			SUM(NumberofPieces),  
			SUM(Rewash)  
			,@Viewtype   
			,@Subview  
			,0  
			FROM CTE  
			WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange ,RowNo
			order by RowNo;

			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name;
  
	   END  
	 END  
  
	 -- ******************************** Location View ***************************************************  
	 IF(@Viewtype = 2) 			 					
	 BEGIN 				   		
		IF(@Subview = 9)  
		BEGIN  
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,ID)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			WG.WasherGroupId  
			FROM @ProductionSummaryTable SPD 
			LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId  
			LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId ;
				
			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,WasherGroupId)  
			AS  
				(  
				SELECT   
				--SPD.MachineId,  
				WG.WasherGroupName,  
				SUM(SPD.ActualProduction),  
				CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/   
				NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) *   
				COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM(SPD.StandardProduction),  
				SUM([NoOfLoads]),  
				SUM(  SPD.ShiftRunTime),  
				SUM(  SPD.ShiftRunTime),  
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash),  
				WG.WasherGroupId  
					FROM @ProductionSummaryTable SPD LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId  
					LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId   
				GROUP BY WG.WasherGroupName,WG.WasherGroupId,SPD.ShiftId--,SPD.MachineId    
				)  
				INSERT INTO @resultSet  
				SELECT DISTINCT  
					0,  
					DateRange,  
					SUM(TotalLoad),  
					SUM(WasherEfficiency),  
					@PlantTargetProduction,  
					SUM(StandardLoad),  
					SUM(Numberofbatches),  
					SUM( ActualRunTime),  
					SUM( TargetRuntime),  
					SUM(NumberofPieces),  
					SUM(Rewash)  
					,@Viewtype   
					,@Subview  
					,WasherGroupId  
				FROM CTE  
					WHERE TotalLoad IS NOT NULL  
					GROUP BY DateRange,WasherGroupId	;

			WITH CTE1
			AS
			(
				SELECT SUM(ShiftRuntime) AS Shiftruntime,ID FROM @TableShiftruntime
				GROUP BY ID
			)

			--Update Shiftruntime in Temp table
			UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
			FROM @resultSet  RS
			LEFT OUTER JOIN 
			CTE1 TS ON RS.Id=TS.ID
						
		END  
  
		IF(@Subview = 10)  
		BEGIN 
				
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime,         
			cast( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName MachineName
			FROM @ProductionSummaryTable SPD   
			LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId  
			LEFT JOIN TCD.Washer w on MS.WasherId=w.WasherId  
			LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId   
			WHERE   
				(  
				CASE @drillvalue     
				WHEN '' THEN 'TRUE'           
				ELSE                                                      
				CASE WHEN WG.WasherGroupId IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				)  ;				 
			  

			--SELECT * FROM @TableShiftruntime;
				 
			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
			AS  
			(  
			SELECT           
			cast( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName MachineName,  
			SUM(SPD.ActualProduction),  
			CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/   
			NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) *   
			COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)) ,  
			SUM(DISTINCT SPD.PlantTargetProd),  
			SUM(SPD.StandardProduction),  
			SUM([NoOfLoads]),  
			SUM(  SPD.ShiftRunTime),  
			SUM(  SPD.ShiftRunTime),  
			SUM(SPD.NoOfPieces),  
			SUM(SPD.Rewash)  
          
			FROM @ProductionSummaryTable SPD   
			LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId  
			LEFT JOIN TCD.Washer w on MS.WasherId=w.WasherId  
			LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId   
			WHERE   
				(  
				CASE @drillvalue     
				WHEN '' THEN 'TRUE'           
				ELSE                                                      
				CASE WHEN WG.WasherGroupId IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				)  
			GROUP BY cast( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName,SPD.ShiftId  
  
			)  
  
			INSERT INTO @resultSet  
				SELECT DISTINCT  
				0,  
				DateRange,  
				SUM(TotalLoad),  
				SUM(WasherEfficiency),  
				@PlantTargetProduction,  
				SUM(StandardLoad),  
				SUM( Numberofbatches),  
				SUM( ActualRunTime),  
				SUM( TargetRuntime),  
				SUM(NumberofPieces),  
				SUM(Rewash)  
				,@Viewtype   
				,@Subview  
				,0  
			FROM CTE  
				WHERE TotalLoad IS NOT NULL  
				GROUP BY DateRange;

			WITH CTE1
			AS
			(
				SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
				GROUP BY Name 
			)				
			--Update Shiftruntime in Temp table
			UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
			FROM @resultSet  RS
			LEFT OUTER JOIN 
			CTE1 TS ON RS.DateRange=TS.Name
				   
		END  
	 END  
  
		-- ******************************** ChainCategory View **********************************************  
	 IF(@Viewtype = 5)  
	 BEGIN  
	  IF(@Subview = 16)  
	  BEGIN  
		 -- ToDo : Change this part for chaincategory  
		 WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,textileId)  
	   AS  
	   (  
		SELECT      
	   CC.NAME,  
	   SUM(SPD.ActualProduction),  
	   COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
	   SUM(DISTINCT SPD.PlantTargetProd),  
	   SUM(SPD.StandardProduction),  
	   SUM([NoOfLoads]),  
	   SUM( SPD.ShiftRunTime),  
	   SUM( SPD.ShiftRunTime),  
	   SUM(SPD.NoOfPieces),  
	   SUM(SPD.Rewash),  
	   cc.TextileId  
		  FROM  
		@ProductionSummaryTable SPD  
	   INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
		INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = PM.PlantProgramId  
		INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId   
	   Group by   
		 CC.Name,cc.TextileId,SPD.ShiftId  
		 )  
	   INSERT INTO @resultSet  
		 SELECT DISTINCT  
		  0,  
		  DateRange,  
		  SUM(TotalLoad),  
		  SUM(WasherEfficiency),  
		  @PlantTargetProduction,  
		  SUM(StandardLoad),  
		  SUM(Numberofbatches),  
		  SUM(ActualRunTime),  
		  SUM(TargetRuntime),  
		  SUM(NumberofPieces),  
		  SUM(Rewash)  
		  ,@Viewtype   
		  ,@Subview  
		  ,textileId  
		FROM CTE  
		 WHERE TotalLoad IS NOT NULL  
		 GROUP BY DateRange,textileId  
	  END  
      
	  IF(@Subview = 19)  
	  BEGIN  
	   -- ToDo : Change this part for chaincategory  
		WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
	   AS  
	   (  
		SELECT    
	   PCP.PlantProgramName,  
	   SUM(SPD.ActualProduction),  
	   COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
	   SUM(DISTINCT SPD.PlantTargetProd),  
	   SUM(SPD.StandardProduction),  
	   SUM([NoOfLoads]),  
	   SUM( SPD.ShiftRunTime),  
	   SUM( SPD.ShiftRunTime),  
	   SUM(SPD.NoOfPieces),  
	   SUM(SPD.Rewash)  
		 FROM @ProductionSummaryTable SPD  
	   INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
		INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = PM.PlantProgramId  
		INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId   
		WHERE  
	   (  
		 CASE @drillvalue     
		  WHEN '' THEN 'TRUE'           
		  ELSE                                                      
		  CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END              
		  END='TRUE'  
		)  
	   Group by   
		 PCP.PlantProgramName,PCP.PlantProgramId,SPD.ShiftId  
		 )  
		 INSERT INTO @resultSet  
		 SELECT DISTINCT  
		  0,  
		  DateRange,  
		  SUM(TotalLoad),  
		  SUM(WasherEfficiency),  
		  @PlantTargetProduction,  
		  SUM(StandardLoad),  
		  SUM(Numberofbatches),  
		  SUM(ActualRunTime),  
		  SUM(TargetRuntime),  
		  SUM(NumberofPieces),  
		  SUM(Rewash)  
		  ,@Viewtype   
		  ,@Subview  
		  ,0  
		FROM CTE  
		 WHERE TotalLoad IS NOT NULL  
		 GROUP BY DateRange  
	  END  
  
	 END  
  
		-- ******************************** Customer View ***************************************************  
	 IF(@Viewtype = 6)  
		 BEGIN  

			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			PC.CustomerName  
			FROM @ProductionSummaryTable SPD  INNER JOIN TCD.PlantCustomer PC on PC.CustomerId = SPD.CustomerId  ;	

		    WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
		    AS  
			(  
				SELECT   
				PC.CustomerName,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM(SPD.StandardProduction),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime),  
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash)  
				FROM @ProductionSummaryTable SPD  INNER JOIN TCD.PlantCustomer PC on PC.CustomerId = SPD.CustomerId  
				GROUP BY   
				PC.CustomerName,SPD.ShiftId  
			)  
			INSERT INTO @resultSet  
			SELECT DISTINCT  
			0,  
			DateRange,  
			SUM(TotalLoad),  
			SUM(WasherEfficiency),  
			@PlantTargetProduction,  
			SUM(StandardLoad),  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime),  
			SUM(NumberofPieces),  
			SUM(Rewash)  
			,@Viewtype   
			,@Subview  
			,0  
			FROM CTE  
			WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange ; 
			
			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name	

		 END  
  
	-- ******************************** Formula View ****************************************************  
	 IF(@Viewtype = 7)  
	 BEGIN  
	   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
	   AS  
	   (  
	   SELECT   
	   PM.Name,  
	   SUM(SPD.ActualProduction),  
		 COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
	   SUM(DISTINCT SPD.PlantTargetProd),  
	   SUM(SPD.StandardProduction),  
	   SUM([NoOfLoads]),  
	   SUM( SPD.ShiftRunTime),  
	   SUM( SPD.ShiftRunTime),  
	   SUM(SPD.NoOfPieces),  
	   SUM(SPD.Rewash)  
	   FROM @ProductionSummaryTable SPD   
	   INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
	   Group by   
	   PM.Name,SPD.ShiftId  
	   )  
	   INSERT INTO @resultSet  
		 SELECT DISTINCT  
		  0,  
		  DateRange,  
		  SUM(TotalLoad),  
		  SUM(WasherEfficiency),  
		  @PlantTargetProduction,  
		  SUM(StandardLoad),  
		  SUM(Numberofbatches),  
		  SUM(ActualRunTime),  
		  SUM(TargetRuntime),  
		  SUM(NumberofPieces),  
		  SUM(Rewash)  
		  ,@Viewtype   
		  ,@Subview  
		  ,0  
		FROM CTE  
		 WHERE TotalLoad IS NOT NULL  
		 GROUP BY DateRange  
		END  
  
	-- ******************************** Formula segmentView ****************************************************  
	  	
	 IF(@Viewtype = 8)  
	 BEGIN  
		IF(@Subview =20)-- Formula Segment  
		BEGIN 
			
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			FS.SegmentName    
			FROM @ProductionSummaryTable SPD
			INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
			INNER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=SPD.FormulaSegmentID ;

			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,FormulaSegmentID)  
			AS  
			(  
				SELECT   
				FS.SegmentName,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM(SPD.StandardProduction),  
				SUM([NoOfLoads]),  
				SUM(SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime),  
				--SUM(SPD.IndividualShiftRunTime),
				--SUM(SPD.IndividualShiftRunTime),
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash),  
				SPD.FormulaSegmentID  
				FROM @ProductionSummaryTable SPD   
				INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
				INNER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=SPD.FormulaSegmentID   
				Group by SPD.FormulaSegmentID,FS.SegmentName,SPD.ShiftId    
			)  
			INSERT INTO @resultSet  
			(  
			ShiftId,  
			DateRange ,  
			TotalLoad  ,  
			WasherEfficiency ,  
			PlantTargetLoad  ,  
			StandardLoad ,  
			Numberofbatches ,  
			[ActualRunTime],   
			[TargetRunTime],  
			NumberofPieces  ,  
			Rewash ,  
			Viewtype ,  
			Subview ,  
			Id  
			)  
			SELECT DISTINCT  
			0,  
			DateRange,  
			SUM(TotalLoad),  
			SUM(WasherEfficiency),  
			@PlantTargetProduction,  
			SUM(StandardLoad),  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime),  
			SUM(NumberofPieces),  
			SUM(Rewash)  
			,@Viewtype   
			,@Subview  
			,FormulaSegmentID  
			FROM CTE  
			WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange,FormulaSegmentID;
			
			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name	
			 
		END  
		IF(@Subview =21)-- Formula Categories  
		BEGIN 
		  
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT SPD.ShiftId,SPD.ShiftRunTime AS ShiftRuntime, EC.CategoryName    
				FROM @ProductionSummaryTable SPD
				INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
				WHERE  
					(  
					CASE      
					WHEN @drillvalue='' THEN 'TRUE'   
					WHEN @drillvalue IS NULL THEN 'TRUE'    
					ELSE                                                      
					CASE WHEN SPD.FormulaSegmentID IN (@drillvalue) THEN 'TRUE' END              
					END='TRUE'  
					) AND EC.CategoryName IS NOT NULL
			UNION 

			SELECT DISTINCT SPD.ShiftId,SPD.ShiftRunTime AS ShiftRuntime, CC.NAME   
			FROM @ProductionSummaryTable SPD
			INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
			INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = SPD.ChainProgaramId  
			INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId
				WHERE  
				(  
				CASE      
				WHEN @drillvalue='' THEN 'TRUE'   
				WHEN @drillvalue IS NULL THEN 'TRUE'    
				ELSE                                                      
				CASE WHEN SPD.FormulaSegmentID IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				) ;
			  
			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,TextileId)  
			AS  
			(  
				SELECT EC.CategoryName,	SUM(SPD.ActualProduction),COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
				SUM(DISTINCT SPD.PlantTargetProd),SUM(SPD.StandardProduction),SUM([NoOfLoads]),SUM( SPD.ShiftRunTime),SUM( SPD.ShiftRunTime),  
				--SUM(SPD.IndividualShiftRunTime),SUM(SPD.IndividualShiftRunTime),
				SUM(SPD.NoOfPieces),SUM(SPD.Rewash),EC.TextileId  
				FROM @ProductionSummaryTable SPD   
				INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId  
				WHERE  
				(  
				CASE      
				WHEN @drillvalue='' THEN 'TRUE'   
				WHEN @drillvalue IS NULL THEN 'TRUE'    
				ELSE                                                      
				CASE WHEN SPD.FormulaSegmentID IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				) AND EC.CategoryName IS NOT NULL  
				GROUP BY EC.CategoryName,EC.TextileId,SPD.ShiftId  
  
				UNION  
  
				SELECT CC.NAME,SUM(SPD.ActualProduction),COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),SUM(SPD.StandardProduction),SUM([NoOfLoads]),SUM( SPD.ShiftRunTime),SUM( SPD.ShiftRunTime), 
				--SUM(SPD.IndividualShiftRunTime),SUM(SPD.IndividualShiftRunTime), 
				SUM(SPD.NoOfPieces),SUM(SPD.Rewash),cc.TextileId  
				FROM @ProductionSummaryTable SPD  
				INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
				INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = SPD.ChainProgaramId  
				INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId
				WHERE  
				(  
				CASE      
				WHEN @drillvalue='' THEN 'TRUE'   
				WHEN @drillvalue IS NULL THEN 'TRUE'    
				ELSE                                                      
				CASE WHEN SPD.FormulaSegmentID IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				)   
				Group by CC.Name,cc.TextileId,SPD.ShiftId  
				)  
				INSERT INTO @resultSet  
				(  
				ShiftId,  
				DateRange ,  
				TotalLoad  ,  
				WasherEfficiency ,  
				PlantTargetLoad  ,  
				StandardLoad ,  
				Numberofbatches ,  
				[ActualRunTime],   
				[TargetRunTime],  
				NumberofPieces  ,  
				Rewash ,  
				Viewtype ,  
				Subview ,  
				Id  
				)  
				SELECT DISTINCT  
				0,  
				DateRange,  
				SUM(TotalLoad),  
				SUM(WasherEfficiency),  
				SUM(PlantTargetLoad),  
				SUM(StandardLoad),  
				SUM(Numberofbatches),  
				SUM(ActualRunTime),  
				SUM(TargetRuntime),  
				SUM(NumberofPieces),  
				SUM(Rewash)  
				,@Viewtype   
				,@Subview  
				,TextileId  
				FROM CTE  
				WHERE TotalLoad IS NOT NULL  
				GROUP BY DateRange,TextileId  ;
			
			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name	

	    END  
		IF(@Subview=22) --Formula  
		BEGIN  

			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			PM.Name    
			FROM @ProductionSummaryTable SPD
			INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId  
				INNER JOIN TCD.ProgramMaster PM ON --EC.TextileId = PM.EcolabTextileCategoryId AND 
				SPD.ProgramMasterId = PM.ProgramId    
	
				WHERE  
				(  
				CASE      
				WHEN @drillvalue='' THEN 'TRUE'   
				WHEN @drillvalue IS NULL THEN 'TRUE'    
				ELSE                                                      
				CASE WHEN EC.TextileId IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				) AND PM.NAME IS NOT NULL
			
			UNION

			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			PM.Name    
			FROM @ProductionSummaryTable SPD
			INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId  
				INNER JOIN TCD.ProgramMaster PM ON  SPD.ProgramMasterId = PM.ProgramId    
				WHERE  
				(  
				CASE      
				WHEN @drillvalue='' THEN 'TRUE'   
				WHEN @drillvalue IS NULL THEN 'TRUE'    
				ELSE                                                      
				CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE' 
				) ;

			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,ID)  
			AS  
			(  
				SELECT PM.Name,SUM(SPD.ActualProduction),COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),SUM(SPD.StandardProduction),SUM([NoOfLoads]),SUM(SPD.ShiftRunTime),SUM(SPD.ShiftRunTime), 		
				--SUM(SPD.IndividualShiftRunTime),SUM(SPD.IndividualShiftRunTime),
				SUM(SPD.NoOfPieces),SUM(SPD.Rewash),PM.ProgramId  
				FROM @ProductionSummaryTable SPD   
				INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId  
				INNER JOIN TCD.ProgramMaster PM ON --EC.TextileId = PM.EcolabTextileCategoryId AND 
				SPD.ProgramMasterId = PM.ProgramId    
	
				WHERE  
				(  
				CASE      
				WHEN @drillvalue='' THEN 'TRUE'   
				WHEN @drillvalue IS NULL THEN 'TRUE'    
				ELSE                                                      
				CASE WHEN EC.TextileId IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				) AND PM.NAME IS NOT NULL 
				GROUP BY PM.Name,PM.ProgramId--,SPD.ShiftId 
  
				UNION   
  
				SELECT PM.Name,SUM(SPD.ActualProduction),COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),SUM(SPD.StandardProduction),SUM([NoOfLoads]),SUM( SPD.ShiftRunTime),SUM( SPD.ShiftRunTime),  
				--SUM(SPD.IndividualShiftRunTime),SUM(SPD.IndividualShiftRunTime), 
				SUM(SPD.NoOfPieces),SUM(SPD.Rewash),PM.ProgramId  
				FROM @ProductionSummaryTable SPD   
				INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId  
				INNER JOIN TCD.ProgramMaster PM ON  SPD.ProgramMasterId = PM.ProgramId    
				WHERE  
				(  
				CASE      
				WHEN @drillvalue='' THEN 'TRUE'   
				WHEN @drillvalue IS NULL THEN 'TRUE'    
				ELSE                                                      
				CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE' 
				)  
				GROUP BY PM.Name,PM.ProgramId--,SPD.ShiftId    
			)  
  
			INSERT INTO @resultSet(ShiftId,DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,  
			StandardLoad,Numberofbatches,[ActualRunTime],[TargetRunTime],NumberofPieces  ,  
			Rewash,Viewtype,Subview,Id  
			)  
			SELECT DISTINCT 0,DateRange,SUM(TotalLoad),	SUM(WasherEfficiency),SUM(PlantTargetLoad),
			SUM(StandardLoad),SUM(Numberofbatches),	SUM(ActualRunTime),	SUM(TargetRuntime),	SUM(NumberofPieces),
			SUM(Rewash),@Viewtype ,@Subview,ID  
			FROM CTE  
			WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange,ID ; 
			
			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name	

		END  
	 END  
   
	--- ********* Return result ********************  
  
		SELECT DISTINCT  ShiftId, DateRange,ISNULL([TCD].[FnConsumptionOnMetrics](TotalLoad,'Weight',@UserId),0) AS TotalLoad,        
		  ISNULL([TCD].[FnConsumptionOnMetrics](WasherEfficiency,'Weight',@UserId),0)AS Washerefficiency,  
		  ISNULL([TCD].[FnConsumptionOnMetrics](PlantTargetLoad,'Weight',@UserId),0) AS PlantTargetLoad,
		  ISNULL([TCD].[FnConsumptionOnMetrics](StandardLoad,'Weight',@UserId),0) AS StandardLoad,
		  ISNULL(Numberofbatches,0)AS NumberofBatches,ISNULL(ActualRunTime,0) ShiftRuntime,ISNULL(TargetRunTime,0) TargetRuntime,
		  ISNULL(NumberofPieces,0) AS NoofPieces,  
		  ISNULL(Rewash,0) AS Rewash,Viewtype,Subview ,Id,@CorrectionVariable  
		  FROM @resultSet   
  
  
   
SET NOCOUNT OFF     
END  
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ReportProductionSummary]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ReportProductionSummary]
END
GO
CREATE PROCEDURE [TCD].[ReportProductionSummary]   
 
     @startdate datetime = '',  
     @enddate datetime = '',  
     @Viewtype varchar(30) = '',  
     @Subview varchar(30)= '',  
     @Drillvalue varchar(100)= '',  
     @EcolabAccountNumber Nvarchar(25) = '',  
     @MachineType VARCHAR(20)= '',  
     @MachineGroup VARCHAR(MAX) = '',  
     @Machine VARCHAR(MAX) = '',  
     @EcolabCategory VARCHAR(MAX) = '',  
     @ChainCategory VARCHAR(MAX) = '',  
     @PlantFormula  VARCHAR(MAX) = '',  
     @ChainFormula VARCHAR(MAX) = '',  
     @Customer VARCHAR(MAX) = '',  
     @SortColumnId int = 0,  
     @SortDirection varchar(4) = '',  
     @CurrencyCode varchar(3) = '',  
     @UserId INT = NULL,
	 @FormulaSegement VARCHAR(MAX)='', --Formula segment,
	 @FormulaCategory VARCHAR(MAX)='', --Formula category
	 @Formula VARCHAR(MAX)='' --Formula
AS     
BEGIN     
SET NOCOUNT ON   
  
 SET @startdate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@startdate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@startdate AS time)) AS DateTime))  
 SET @EndDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndDate AS time)) AS DateTime))  
   
   --SELECT @startdate,@enddate
 DECLARE @ReportGenerated INT = 6,  
    @Month INT = MONTH(GETDATE()),@CorrectionVariable Decimal(18,2),@PlantTargetProduction decimal(18,2)  
    --,@ShiftRuntime int,@NoShiftTotalRuntime INT,@TotaRuntime int  
  
 -- Inserting the record into Report History   
 INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)  
 SELECT @EcolabAccountNumber,UM.UserId,UM.LoginName,GETUTCDATE(),@ReportGenerated,  
 CASE WHEN @ReportGenerated = 6  
  THEN 'Generated Report : Production Summary Report' END  
 FROM TCD.UserMaster UM  
 WHERE UM.EcolabAccountNumber = @EcolabAccountNumber AND UM.UserId = @UserId  
 /* Completed the record insertion into Report History */   
  
    -- Return Table set  
    DECLARE @resultSet Table  
    (  
      ShiftId Int,  
      DateRange varchar(100),  
      TotalLoad Decimal(18,2) ,  
      WasherEfficiency Decimal(18,2),  
      PlantTargetLoad Decimal(18,2) ,  
      Numberofbatches INT,  
      [ActualRunTime] [int] NULL,  
      [TargetRunTime] [int] NULL,  
      Viewtype varchar(100) NULL,  
      Subview varchar(100) NULL,  
      Id int NULL        
    )  
    DECLARE @CorrectionFactor TABLE   
 (  
 [ShiftId] [int] NULL,  
 MachineId INT NULL,  
 [ActualProduction] [int] NULL,  
 [StandardProduction] [int] NULL,  
 [PlantTargetProd] [int] NULL,  
 [ActualRunTime] [int] NULL,  
 [TargetRunTime] [int] NULL,  
 ManualInputWeight INT,  
 ManulainputsNoofloads INT  
 )  
  
 DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))  
 INSERT INTO @MachineTypeTable EXEC [TCD].[CharlistToTable] @MachineType,','  
  
 DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))  
 INSERT INTO @WasherGroupTable EXEC [TCD].[CharlistToTable] @machineGroup,','    
  
 DECLARE @MachineTable TABLE(Machine Varchar(100))  
 INSERT INTO @MachineTable EXEC [TCD].[CharlistToTable] @Machine,','  
  
 DECLARE @EcolabCategoryTable TABLE(EcolabCategory Varchar(100))  
 INSERT INTO @EcolabCategoryTable EXEC [TCD].[CharlistToTable] @EcolabCategory,','  
  
 DECLARE @ChainCategoryTable TABLE(ChainCategory Varchar(100))  
 INSERT INTO @ChainCategoryTable EXEC [TCD].[CharlistToTable] @ChainCategory,','  
  
 DECLARE @PlantFormulaTable TABLE(PlantFormula Varchar(100))  
 INSERT INTO @PlantFormulaTable EXEC [TCD].[CharlistToTable] @PlantFormula,','  
  
 DECLARE @ChainFormulaTable TABLE(ChainFormula Varchar(100))  
 INSERT INTO @ChainFormulaTable EXEC [TCD].[CharlistToTable] @ChainFormula,','  
  
 DECLARE @CustomerTable TABLE(Customer Varchar(100))  
 INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','  
  
 --Formula Segment --added by Kiran
 DECLARE @FormulaSegmentTable TABLE(FormulaSegment Varchar(1000))
    INSERT INTO @FormulaSegmentTable EXEC [TCD].[CharlistToTable] @FormulaSegement,','

 --Formula category
 DECLARE @FormulaCategoryTable TABLE(FormulaCategory Varchar(1000),Type CHAR(1))
    INSERT INTO @FormulaCategoryTable(FormulaCategory) EXEC [TCD].[CharlistToTable] @Formulacategory,',' 
  
  --Below 1000 Ecolab category
  UPDATE @FormulaCategoryTable SET TYPE='E' WHERE FormulaCategory<1000
  --Above 1000 consider as Chain category
  UPDATE @FormulaCategoryTable SET TYPE='C' WHERE FormulaCategory>=1000

  --Rollbacking to actual ID
  UPDATE @FormulaCategoryTable SET FormulaCategory=FormulaCategory-1000 WHERE TYPE='C'
 
  --SELECT * FROM @FormulaCategoryTable

  INSERT INTO @EcolabCategoryTable(EcolabCategory)
  SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='E' 

  INSERT INTO @ChainCategoryTable(ChainCategory)
  SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='C'

  --Value Assigning
  IF (EXISTS(SELECT * FROM @EcolabCategoryTable) AND @FormulaCategory!='')
  BEGIN
   SET @EcolabCategory=@FormulaCategory
  END
  IF (EXISTS(SELECT * FROM @ChainCategoryTable) AND @FormulaCategory!='')
  BEGIN
   SET @ChainCategory=@FormulaCategory
  END

 -----Formula Ecolab/Chain categories
 DECLARE @FormulaTable TABLE(Formula Varchar(1000),Type CHAR(1))
    INSERT INTO @FormulaTable(Formula) EXEC [TCD].[CharlistToTable] @Formula,',' 
      
  --Plant fomula   
  INSERT INTO @PlantFormulaTable(PlantFormula) 
  SELECT Formula FROM @FormulaTable 
  --chain formula   
  INSERT INTO @ChainFormulaTable(ChainFormula) 
  SELECT Formula FROM @FormulaTable 
  --SELECT * FROM @PlantFormulaTable
  --SELECT * FROM @ChainFormulaTable

  --Value Assigning
  IF (EXISTS(SELECT * FROM @PlantFormulaTable) AND @Formula!='')
  BEGIN
   SET @PlantFormula=@Formula
  END
  IF (EXISTS(SELECT * FROM @ChainFormulaTable) AND @Formula!='')
  BEGIN
   SET @ChainFormula=@Formula
  END
 --Formula end

 INSERT INTO @CorrectionFactor  
 (  
   [ShiftId],  
   [MachineId] ,  
   [ActualProduction] ,  
   [StandardProduction] ,  
   [PlantTargetProd] ,  
   [ActualRunTime] ,  
   [TargetRunTime],  
   ManualInputWeight,  
   ManulainputsNoofloads     
 )  
 SELECT   
  PS.[ShiftId],  
  SPD.[MachineId],  
  ISNULL([TCD].[FnConsumptionOnMetrics](SUM(ISNULL(SPD.[ActualProduction],0))+SUM(ISNULL(MIP.ActualWeight,0)),'Weight',@UserId),0),  
  --ISNULL([TCD].[FnConsumptionOnMetrics](SUM(SPD.[ActualProduction]),'Weight',@UserId),0),  
  --SUM(SPD.[ActualProduction]),  
  ISNULL([TCD].[FnConsumptionOnMetrics](SUM(SPD.StandardProduction),'Weight',@UserId),0),  
  --SUM(SPD.StandardProduction),  
  ISNULL([TCD].[FnConsumptionOnMetrics](SUM(DISTINCT SPD.[PlantTargetProd]),'Weight',@UserId),0),  
  --SUM(DISTINCT SPD.[PlantTargetProd]),  
  SUM(SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0)),  
  SUM(SPD.[TargetRunTime] + ISNULL(SPD.TargetTurnTime,0)),  
  SUM(ISNULL(MIP.ActualWeight,0)),SUM(ISNULL(MIP.NoofLoads,0))  
 FROM  TCD.ShiftProductionDataRollup SPD   
 INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId  
 INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId   
 LEFT OUTER JOIN --Manual Production Details appending  
  (  
  SELECT WasherId,FormulaId,CONVERT(DATE,RecordedDate) AS LoadDate,SUM(ISNULL(Value,0)) AS ActualWeight,  
  ISNULL(COUNT(CONVERT(DATE,RecordedDate)),0) AS NoofLoads FROM  
  TCD.ManualProduction MP  
  GROUP BY WasherId,FormulaId,CONVERT(DATE,RecordedDate)  
  )MIP ON MIP.WasherId=SPD.EcolabWasherId AND MIP.FormulaId=SPD.ProgramMasterId AND MIP.LoadDate=CONVERT(DATE,PS.StartDateTime)  
 WHERE   
 CASE @StartDate                                                                                  
 WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                  
 ELSE CASE WHEN PS.[StartDateTime] >= @startdate  AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                          
 END='TRUE'   
 GROUP BY MachineId,PS.ShiftId;  
  
 --SELECT * FROM  @CorrectionFactor;
  
  
 WITH CTE (PlantTargetProd) AS  
 (  
 SELECT SUM(DISTINCT SPD.[PlantTargetProd]) FROM @CorrectionFactor SPD GROUP BY ShiftId  
 )  
 SELECT @PlantTargetProduction = SUM(PlantTargetProd) FROM CTE;  
  
  
 WITH CTE (MachineId,PlantEfficiency)  
 AS  
 (  
 SELECT   
  MachineId,  
  CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/   
   NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) *   
   COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2))     
   FROM @CorrectionFactor SPD GROUP BY MachineId  
 )  
    SELECT @CorrectionVariable = @PlantTargetProduction/NULLIF(SUM(PlantEfficiency),0) FROM CTE  
  
      
 DECLARE @ProductionSummaryTable TABLE(  
		[ShiftId] [int] NULL,  
		[ShiftName] Varchar(100) NULL,  
		RecordDate date,   
		[StartDateTime] [datetime] NULL,  
		[EndDateTime] [datetime] NULL,  
		[MachineId] [int] NULL,  
		[EcolabWasherId] [int] NULL,  
		[ActualProduction] [int] NULL,  
		[StandardProduction] [int] NULL,  
		[NoOfLoads] [int] NULL,  
		[LoadEfficiency] [decimal](18, 2) NULL,  
		[TimeEfficiency] [decimal](18, 2) NULL,  
		TotalEfficiency [decimal](18, 2) NULL,  
		[PlantTargetProd] [int] NULL,  
		[ActualRunTime] [int] NULL,  
		[TargetRunTime] [int] NULL,  
		[ShiftRunTime] Decimal(30,10)  NULL,  
		RowNumberID INT NULL,  
		ProgramMasterID INT NULL,
		EcolabTextileId int,
		ChainTextileId int,
		ChainProgaramId int,
		FormulaSegmentID INT,
		CustomerId int,
		IndividualShiftRunTime Decimal(30,10) 
             )  
 INSERT INTO @ProductionSummaryTable  
 (  
 [ShiftId] ,[ShiftName] ,RecordDate, [StartDateTime] ,[EndDateTime] ,[MachineId]  ,[EcolabWasherId]  ,  
 [ActualProduction] ,[StandardProduction] ,[NoOfLoads] ,[LoadEfficiency],[TimeEfficiency] ,TotalEfficiency ,  
 [PlantTargetProd],[ActualRunTime] ,[TargetRunTime] ,[ShiftRunTime] ,RowNumberID ,ProgramMasterID,
 EcolabTextileId,ChainTextileId,ChainProgaramId,FormulaSegmentID,CustomerId
 )  
    SELECT   
 SPD.[ShiftId],  
 PS.ShiftName,  
 CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date),  
 DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]),  
 DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[EndDateTime]),          
 SPD.[MachineId],  
 SPD.[EcolabWasherId],  
 SPD.[ActualProduction],  
 SPD.StandardProduction,  
 SPD.[NoOfLoads],  
 SPD.[LoadEfficiency],  
 SPD.[TimeEfficiency],  
 (SPD.[LoadEfficiency] * SPD.TimeEfficiency),  
 SPD.[PlantTargetProd],  
 SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0),  
 SPD.[TargetRunTime] + ISNULL(SPD.TargetTurnTime,0),  
 DATEDIFF(Second,ps.StartDateTime,PS.EndDateTime) +  
 ISNULL(  
 (  
 SELECT  
 SUM(SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0))  
  FROM TCD.ShiftProductionDataRollup SPD   
 INNER JOIN TCD.ProductionShiftData PSD ON SPD.ShiftId = PSD.ShiftId  
 INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId   
 WHERE   
 PSD.[StartDateTime] = PS.StartDateTime AND PSD.[StartDateTime] = PS.EndDateTime AND PS.ShiftName = 'No Shift'  
 ),0),  
 ROW_NUMBER() OVER(Partition BY SPD.ProgramMasterId, SPD.[EcolabWasherId], CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date)  
 ORDER BY SPD.ProgramMasterId, SPD.[EcolabWasherId] ),  
 SPD.ProgramMasterId,
 SPD.EcolabTextileId,SPD.ChainTextileId,SPD.ChainProgaramId,
    CASE WHEN SPD.ChainProgaramId IS NOT NULL THEN ChainPlant.FormulaSegmentId
 ELSE FS1.FormulaSegmentID END AS Formulasegment,
 SPD.CustomerId
      
 FROM TCD.ShiftProductionDataRollup SPD   
 INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId  
 INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
 INNER JOIN TCD.MachineSetup ms ON SPD.MachineId = ms.WasherId  
 LEFT OUTER JOIN
   (
   --IF Chain Plant
   SELECT PCP.PlantProgramId,PCP.PlantChainId,PCP.ChainTextileCategoryId,PCP.EcolabTextileCategoryId,
   PCP.FormulaSegmentId,PCP.EcolabSaturationId
   FROM TCD.PlantChainProgram PCP 
   LEFT OUTER JOIN TCD.ChainTextileCategory CTC ON CTC.TextileId=PCP.ChainTextileCategoryId
   LEFT OUTER JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId=PCP.EcolabTextileCategoryId
   LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=PCP.FormulaSegmentId
   LEFT OUTER JOIN TCD.EcolabSaturation ES ON ES.EcolabSaturationId=PCP.EcolabSaturationId
   )ChainPlant ON SPD.ChainProgaramId=ChainPlant.PlantProgramId

 LEFT OUTER JOIN TCD.EcolabTextileCategory ETC1 ON ETC1.TextileId=PM.EcolabTextileCategoryId
 LEFT OUTER JOIN TCD.FormulaSegments FS1 ON FS1.FormulaSegmentID=PM.FormulaSegmentId
 LEFT OUTER JOIN TCD.EcolabSaturation ES1 ON ES1.EcolabSaturationId=PM.EcolabSaturationId
    WHERE isNull(ms.IsPony,0) = 0  
    AND   
       CASE @StartDate                                                                                  
       WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                  
       ELSE CASE WHEN PS.[StartDateTime] >= @startdate AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                          
       END='TRUE'  
  
     AND  
       CASE @MachineType     
       WHEN '' THEN 'TRUE'           
       ELSE                                                        
       CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE        
       MS.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable))) THEN 'TRUE' END                                                        
       END='TRUE'       
     AND         
  
  CASE @machineGroup     
  WHEN '' THEN 'TRUE'           
  ELSE                                                        
  CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE        
  MS.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable)) THEN 'TRUE' END                                                        
  END='TRUE'   
  AND  
  
  CASE @Machine     
  WHEN '' THEN 'TRUE'           
  ELSE                                                        
  CASE WHEN SPD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                   
  END='TRUE'   
  AND  
      
  CASE @EcolabCategory     
  WHEN '' THEN 'TRUE'           
  ELSE                                                        
  CASE WHEN SPD.EcolabTextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                        
  END='TRUE'   
  AND  
      
  CASE @ChainCategory     
  WHEN '' THEN 'TRUE'           
  ELSE                                                        
  CASE WHEN SPD.ChainTextileId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END                                                        
  END='TRUE'  
  AND  
  
  CASE @PlantFormula     
  WHEN '' THEN 'TRUE'           
  ELSE                                                        
  CASE WHEN SPD.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                        
  END='TRUE'    
  AND  
      
  CASE @ChainFormula     
  WHEN '' THEN 'TRUE'           
  ELSE                                                        
  CASE WHEN SPD.ProgramMasterId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END                                                      
  END='TRUE'  
  AND  
      
  CASE @Customer     
  WHEN '' THEN 'TRUE'           
   ELSE                                                        
   CASE WHEN SPD.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                        
  END='TRUE'   
 --Added by Kiran 
    AND 
  CASE @FormulaSegement                                                                                
  WHEN '' THEN  'TRUE'
  ELSE
   CASE WHEN SPD.ChainProgaramId  IS NOT NULL THEN
    CASE WHEN ChainPlant.FormulaSegmentId IN (SELECT FormulaSegment FROM @FormulaSegmentTable) THEN 'TRUE' END                                                                                     
   ELSE 
    CASE WHEN FS1.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)  THEN 'TRUE'END   
   END                                                     
  END='TRUE'
  
 --Updating Actual Production based Manual Production  
 UPDATE S SET ActualProduction=ISNULL(S.ActualProduction,0)+ISNULL(MIP.ManualIPActualWeight,0),S.NoOfLoads=ISNULL(S.NoOfLoads,0)+ISNULL(MIP.NoofLoads,0)  
 FROM  @ProductionSummaryTable S  
 INNER JOIN   
  (  
  SELECT WasherId,FormulaId,CONVERT(DATE,RecordedDate) AS LoadDate,SUM(Value) AS ManualIPActualWeight,  
  COUNT(CONVERT(DATE,RecordedDate)) AS NoofLoads FROM  
  TCD.ManualProduction MP  
  GROUP BY WasherId,FormulaId,CONVERT(DATE,RecordedDate)  
  )MIP ON MIP.WasherId=S.MachineId AND MIP.FormulaId=S.ProgramMasterId AND MIP.LoadDate=S.RecordDate  
  WHERE S.RowNumberID=1  

 /*
  --Finding Max shift runtime for Particula shift
  UPDATE S SET S.IndividualShiftRunTime=MIP.MaxShiftruntime,S.ShiftRunTime=MIP.MaxShiftruntime
	 FROM  @ProductionSummaryTable S  
	 INNER JOIN   
	  (  
		 SELECT ShiftId,MAX(ShiftRunTime) AS MaxShiftruntime FROM @ProductionSummaryTable	 
		 GROUP BY ShiftID 
	  )MIP ON MIP.ShiftId=S.ShiftId	 

	 --Dividing Maxshift time for all the shift based records
	 UPDATE S SET S.IndividualShiftRunTime=(S.IndividualShiftRunTime/PS.noofShifts),S.ShiftRunTime=(S.ShiftRunTime/PS.noofShifts)
	 FROM  @ProductionSummaryTable S  
	 INNER JOIN   
  		 (	 
			SELECT PS1.ShiftID,Count(PS1.ShiftID)AS noofShifts 
			FROM  TCD.ShiftProductionDataRollup SPD   
			INNER JOIN TCD.ProductionShiftData PS1 ON SPD.ShiftId = PS1.ShiftId  
			INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId AND PS1.EcolabAccountNumber=PM.EcolabAccountNumber  
			INNER JOIN TCD.MachineSetup ms ON SPD.MachineId = ms.WasherId	
			WHERE isNull(ms.IsPony,0) = 0 AND PM.EcolabAccountNumber=@EcolabAccountNumber
			GROUP BY PS1.shiftID			 
		  ) PS  
		 ON PS.ShiftId=S.ShiftId 

	*/
  --SELECT Distinct Month(RecordDate) FROM @ProductionSummaryTable WHere Year(RecordDate)=2014 --AND ActualProduction>0
  --GROUP BY Year(RecordDate)

	DECLARE @TableShiftruntime TABLE(ShiftID INT ,ShiftRuntime Decimal(20,10),ID INT,Name VARCHAR(1000))

    IF(@Viewtype = 1)  
    BEGIN  
        ---- By TimeLine - Day View-------------  
		IF(@Subview = 5)  
		BEGIN  
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			SPD.ShiftName  
			FROM @ProductionSummaryTable SPD ;

			INSERT INTO @resultSet  
			SELECT   
			0,  
			SPD.ShiftName,  
			SUM(SPD.ActualProduction),  
			COALESCE(SUM(SPD.ActualProduction)/   
			NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),  
			SUM(DISTINCT SPD.PlantTargetProd),  
			SUM([NoOfLoads]),  
			SUM( SPD.ShiftRunTime),  
			SUM( SPD.ShiftRunTime)  
			,@Viewtype   
			,@Subview  
			,0  
			FROM @ProductionSummaryTable SPD  
			GROUP BY   
			SPD.ShiftName ;
			
			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name	 
	    END  
  
		---- By TimeLine - Week View  
		IF (@Subview = 4)  
		BEGIN  
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			CAST(RecordDate AS nvarchar(100))  
			FROM @ProductionSummaryTable SPD ;
			
			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime)  
			AS  
			(  
				SELECT   
				CAST(RecordDate AS nvarchar(100)),  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/   
				NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime)  
				FROM @ProductionSummaryTable SPD  
				GROUP BY DATEPART(weekday,RecordDate),RecordDate,SPD.ShiftId    
			)  
  
			INSERT INTO @resultSet  
			SELECT    
			0,   
			DateRange,  
			SUM(TotalLoad),  
			SUM(TotalEfficiency),  
			SUM(PlantTargetLoad),  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime)  
			,@Viewtype   
			,@Subview  
			,0  
			FROM CTE   
			WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange; 
			
			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name;
			 
		END  
  
        ---- By TimeLine - Month View  
		IF(@Subview = 3)  
		BEGIN  
			DECLARE @FirstDay date = (SELECT TOP 1 RecordDate FROM @ProductionSummaryTable ORDER BY RecordDate)  
			DECLARE @LastDay date = (SELECT TOP 1 RecordDate FROM @ProductionSummaryTable ORDER BY RecordDate DESC)  
			DECLARE @FirstSunday date = NULL,@LastSaturday date = NULL    
      
		   SELECT   
		   @FirstSunday = CAST(DateAdd(dd, (8-DatePart(WEEKDAY,   
			  DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)))%7,   
			  DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)) AS DATE)   
  
			SELECT  
			 @LastSaturday =   
			DATEADD(dd,  
			 -DATEPART(WEEKDAY,  
			   DATEADD(dd, -DAY(DATEADD(month, 1, @LastDay)),  
			   DATEADD(month, 1, @LastDay))) ,  
			 DATEADD(dd, -DAY(DATEADD(MONTH, 1, @LastDay)), DATEADD(MONTH, 1, @LastDay)));  

			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT SPD.ShiftId,SPD.ShiftRunTime AS ShiftRuntime,
				CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,-1,@FirstSunday)) = 7   
				AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate < DATEADD(DD,-1,@FirstSunday)) = 0)  
				THEN CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100))  
				WHEN DATEADD(DD,-1,@FirstSunday) > CAST(GETDATE() AS DATE)   
				THEN  
				CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @enddate, 101) AS nvarchar(100))  
				ELSE  
				CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) END As DateRange 
				FROM @ProductionSummaryTable SPD WHERE RecordDate < @FirstSunday AND RecordDate >= @FirstDay
			 
			UNION ALL
		  
			SELECT DISTINCT SPD.ShiftId,SPD.ShiftRunTime AS ShiftRuntime,
				CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100))  + CHAR(13) + '-' +  
				CASE WHEN CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 121) AS nvarchar(100)) >  
				CAST(Convert(varchar, DateAdd(dd, (1 - DatePart(dw, @enddate) + 1), @enddate), 121) AS nvarchar(100))  
				THEN  CAST(Convert(varchar, DateAdd(dd, 1-1, @enddate), 101) AS nvarchar(100))  
				ELSE CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) END
				FROM @ProductionSummaryTable SPD  
				WHERE RecordDate BETWEEN @FirstSunday AND @LastSaturday

			UNION ALL

			SELECT DISTINCT SPD.ShiftId,SPD.ShiftRunTime AS ShiftRuntime,
				CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,1,@LastSaturday)) = 1   
				AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate > DATEADD(DD,1,@LastSaturday)) = 0)  
				THEN   
				CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100))   
				ELSE  
				CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @LastDay, 101) AS nvarchar(100)) END
				FROM @ProductionSummaryTable SPD  
				WHERE RecordDate > @LastSaturday AND RecordDate <= @LastDay;


			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime)  
			AS  
			(  
			   SELECT          
					CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,-1,@FirstSunday)) = 7   
					AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate < DATEADD(DD,-1,@FirstSunday)) = 0)  
					THEN CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100))  
					WHEN DATEADD(DD,-1,@FirstSunday) > CAST(GETDATE() AS DATE)   
					THEN  
					CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @enddate, 101) AS nvarchar(100))  
					ELSE  
					CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) END As DateRange,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/   
				NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime)  
				FROM @ProductionSummaryTable SPD  
				WHERE RecordDate < @FirstSunday AND RecordDate >= @FirstDay   
				GROUP BY SPD.ShiftId   
          
				UNION ALL    
    
				SELECT  			 
					CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100))  + CHAR(13) + '-' +  
					CASE WHEN CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 121) AS nvarchar(100)) >  
					CAST(Convert(varchar, DateAdd(dd, (1 - DatePart(dw, @enddate) + 1), @enddate), 121) AS nvarchar(100))  
					THEN  CAST(Convert(varchar, DateAdd(dd, 1-1, @enddate), 101) AS nvarchar(100))  
					ELSE CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) END  
					As DateRange,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/   
				NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime)  
				FROM @ProductionSummaryTable SPD  
				WHERE RecordDate BETWEEN @FirstSunday AND @LastSaturday  
				GROUP BY Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101),  
				Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101),
				Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 121),
				SPD.ShiftId  
         
				UNION ALL  
  
				SELECT         
					CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,1,@LastSaturday)) = 1   
					AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate > DATEADD(DD,1,@LastSaturday)) = 0)  
					THEN   
					CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100))   
					ELSE  
					  CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @LastDay, 101) AS nvarchar(100)) END   As DateRange,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/   
				NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime)  
				FROM @ProductionSummaryTable SPD  
				WHERE RecordDate > @LastSaturday AND RecordDate <= @LastDay GROUP BY SPD.ShiftId  
				)  
				INSERT INTO @resultSet  
				 SELECT    
				 0,   
				 DateRange,  
				 SUM(TotalLoad),  
				 SUM(TotalEfficiency),  
				 SUM(PlantTargetLoad),  
				 SUM(Numberofbatches),  
				 SUM(ActualRunTime),  
				 SUM(TargetRuntime)  
				 ,@Viewtype   
				 ,@Subview  
				  ,0  
				 FROM CTE   
				 WHERE TotalLoad IS NOT NULL  
				GROUP BY DateRange; 
			
			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name 
  
		END  
  
		IF(@Subview = 2)  
		BEGIN  
			DECLARE @QuarterYear VARCHAR(100) = YEAR(@enddate);  

			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			DATENAME(MONTH, RecordDate) + ' ' +CAST( YEAR(RecordDate) as varchar)  
			FROM @ProductionSummaryTable SPD;

			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime)  
			AS  
			(  
				SELECT          
				DATENAME(MONTH, RecordDate) + ' ' + CAST( YEAR(RecordDate) as varchar)  As DateRange,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/   
				NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime)  
				FROM @ProductionSummaryTable SPD  
				GROUP BY  DATEPART(MONTH, RecordDate),DATENAME(MONTH, RecordDate),SPD.ShiftId , YEAR(RecordDate) 
			)  
			INSERT INTO @resultSet  
			SELECT    
			0,   
			DateRange,  
			SUM(TotalLoad),  
			SUM(TotalEfficiency),  
			SUM(PlantTargetLoad),  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime)  
			,@Viewtype   
			,@Subview  
			,0  
			FROM CTE   
			WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange;  
			
			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name;

		END 
     
		IF(@Subview = 1)  
		BEGIN  
			DECLARE @Year VARCHAR(100) = RIGHT(YEAR(@enddate),2);  

			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name,ID)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			CASE 'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10))  
				WHEN 'Q1' THEN 'Jan' + RIGHT(YEAR(RecordDate),2)  + '- Mar' + RIGHT(YEAR(RecordDate),2)   
				WHEN 'Q2' THEN 'Apr' + RIGHT(YEAR(RecordDate),2)  + '- Jun' + RIGHT(YEAR(RecordDate),2)   
				WHEN 'Q3' THEN 'Jul' + RIGHT(YEAR(RecordDate),2)  + '-Sep' + RIGHT(YEAR(RecordDate),2)   
				WHEN 'Q4' THEN 'Oct' + RIGHT(YEAR(RecordDate),2)  + '- Dec'+ RIGHT(YEAR(RecordDate),2)   
				END, 
			cast( cast(RIGHT(YEAR(RecordDate),2) AS varchar ) +cast(  DATEPART(QUARTER, RecordDate) AS varchar) AS int)
			FROM @ProductionSummaryTable SPD ;

			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,RowNo)  
			AS  
			(  
				SELECT   
					CASE 'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10))  
					WHEN 'Q1' THEN 'Jan' + RIGHT(YEAR(RecordDate),2)  + '- Mar' + RIGHT(YEAR(RecordDate),2)  
					WHEN 'Q2' THEN 'Apr' + RIGHT(YEAR(RecordDate),2) + '- Jun' + RIGHT(YEAR(RecordDate),2)  
					WHEN 'Q3' THEN 'Jul' + RIGHT(YEAR(RecordDate),2) + '-Sep' + RIGHT(YEAR(RecordDate),2)  
					WHEN 'Q4' THEN 'Oct' + RIGHT(YEAR(RecordDate),2) + '- Dec'+ RIGHT(YEAR(RecordDate),2)   
				END AS DateRange,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/   
				NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime)  ,
				cast( cast(RIGHT(YEAR(RecordDate),2) AS varchar ) +cast(  DATEPART(QUARTER, RecordDate) AS varchar) AS int)  RowNo
				FROM @ProductionSummaryTable SPD  
				GROUP BY DATEPART(QUARTER, RecordDate),SPD.ShiftId,RIGHT(YEAR(RecordDate),2)
			)  
  
		   INSERT INTO @resultSet  
		   SELECT    
				0,   
				DateRange,  
				SUM(TotalLoad),  
				SUM(TotalEfficiency),  
				SUM(PlantTargetLoad),  
				SUM(Numberofbatches),  
				SUM(ActualRunTime),  
				SUM(TargetRuntime)  
				,@Viewtype   
				,@Subview  
				,0  
				FROM CTE   
			 WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange  ,RowNo
			ORDER BY RowNo;

			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name;
		END  
    END  
      
    -- ******************************** Location View ***************************************************  
    IF(@Viewtype = 2)  
    BEGIN    
		IF(@Subview = 9)  
		BEGIN  			
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,ID)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			WG.WasherGroupId  
			FROM @ProductionSummaryTable SPD 
			LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId  
			LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId ;

			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,WasherGroupId)  
			AS  
			(  
				SELECT    
				--SPD.MachineId,      
				WG.WasherGroupName,  
				SUM(SPD.ActualProduction),  
				CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/   
				NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) *   
				COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime),  
				WG.WasherGroupId  
				FROM @ProductionSummaryTable SPD LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId  
				LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId   
				GROUP BY WG.WasherGroupName,WG.WasherGroupId,SPD.ShiftId--,SPD.MachineId  
			)  
  
			INSERT INTO @resultSet  
			SELECT    
			0,   
			DateRange,  
			SUM(TotalLoad),  
			SUM(TotalEfficiency),  
			@PlantTargetProduction,  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime)  
			,@Viewtype   
			,@Subview  
			,WasherGroupId  
			FROM CTE   
			WHERE TotalLoad IS NOT NULL         
			GROUP BY DateRange,WasherGroupId ; 
			
			WITH CTE1
			AS
			(
				SELECT SUM(ShiftRuntime) AS Shiftruntime,ID FROM @TableShiftruntime
				GROUP BY ID
			)

			--Update Shiftruntime in Temp table
			UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
			FROM @resultSet  RS
			LEFT OUTER JOIN 
			CTE1 TS ON RS.Id=TS.ID;
		
		END  
  
		IF(@Subview = 10)  
		BEGIN  
			
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  SPD.ShiftId,SPD.ShiftRunTime AS ShiftRuntime,         
			cast( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName MachineName
			FROM @ProductionSummaryTable SPD   
			LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId  
			LEFT JOIN TCD.Washer w on MS.WasherId=w.WasherId  
			LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId   
			WHERE   
				(  
				CASE @drillvalue     
				WHEN '' THEN 'TRUE'           
				ELSE                                                      
				CASE WHEN WG.WasherGroupId IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				) ;    

			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime)  
		    AS  
		    (  
				SELECT           
				cast( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName as MachineName,  
				SUM(SPD.ActualProduction),  
				CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/   
				NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) *   
				COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime)          
				FROM @ProductionSummaryTable SPD   
				LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId  
				LEFT JOIN TCD.Washer w on MS.WasherId=w.WasherId  
				LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId   
				WHERE   
				(  
				CASE @drillvalue     
				WHEN '' THEN 'TRUE'           
				ELSE                                                      
				CASE WHEN WG.WasherGroupId IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				)  
				GROUP BY cast( W.PlantWasherNumber as varchar(20))+':'+MS.MachineName,SPD.ShiftId             
		   )    
			INSERT INTO @resultSet  
			SELECT   
			0,   
			DateRange,  
			SUM(TotalLoad),  
			SUM(TotalEfficiency),  
			@PlantTargetProduction,  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime)  
			,@Viewtype   
			,@Subview  
			,0  
			FROM CTE   
			WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange ; 
			
			WITH CTE1
			AS
			(
				SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
				GROUP BY Name 
			)				
			--Update Shiftruntime in Temp table
			UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
			FROM @resultSet  RS
			LEFT OUTER JOIN 
			CTE1 TS ON RS.DateRange=TS.Name;
		END  
  	END  
  --******************************** Formula View ****************************************************
	IF(@Viewtype = 7)
	BEGIN
		WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,WasherGroupId)
		AS
		(
		SELECT          
		PM.Name,
		SUM(SPD.ActualProduction),
		CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
		NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
		COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
		SUM(DISTINCT SPD.PlantTargetProd),
		SUM([NoOfLoads]),
		SUM( SPD.ShiftRunTime),
		SUM( SPD.ShiftRunTime),
		PM.ProgramId
		FROM @ProductionSummaryTable SPD
		INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
		Group by PM.Name,PM.ProgramId
		)
		INSERT INTO @resultSet
		SELECT  
			0, 
			DateRange,
			SUM(TotalLoad),
			SUM(TotalEfficiency),
			@PlantTargetProduction,
			SUM(Numberofbatches),
			SUM(ActualRunTime),
			SUM(TargetRuntime)
			,@Viewtype 
			,@Subview
			,WasherGroupId
		FROM CTE 
		WHERE TotalLoad IS NOT NULL       
		GROUP BY DateRange,WasherGroupId
	END

-- ******************************** Formula segmentView ****************************************************
	IF(@Viewtype = 8)
	BEGIN
		IF(@Subview =20)-- Formula Segment
		BEGIN 
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			FS.SegmentName    
			FROM @ProductionSummaryTable SPD
			INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
			INNER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=SPD.FormulaSegmentID ;

			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,FormulaSegmentID)
			AS
			(
			   SELECT          
			   FS.SegmentName,
			   SUM(SPD.ActualProduction),
			   CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
			   NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
			   COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
			   SUM(DISTINCT SPD.PlantTargetProd),
			   SUM([NoOfLoads]),
			   SUM( SPD.ShiftRunTime),
			   SUM( SPD.ShiftRunTime),
			   SPD.FormulaSegmentID
			   FROM @ProductionSummaryTable SPD
			   INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
			   LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=SPD.FormulaSegmentID
			   Group by SPD.FormulaSegmentID,FS.SegmentName   
			)
				INSERT INTO @resultSet
				SELECT  
				0, 
				DateRange,
				SUM(TotalLoad),
				SUM(TotalEfficiency),
				@PlantTargetProduction,
				SUM(Numberofbatches),
				SUM(ActualRunTime),
				SUM(TargetRuntime)
				,@Viewtype 
				,@Subview
				,FormulaSegmentID
				FROM CTE 
				WHERE TotalLoad IS NOT NULL       
				GROUP BY DateRange,FormulaSegmentID;

			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name	;
		END
		
		IF(@Subview =21)-- Formula Categories
		BEGIN 
		 
		   INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT SPD.ShiftId,SPD.ShiftRunTime AS ShiftRuntime, EC.CategoryName    
				FROM @ProductionSummaryTable SPD
				INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
				WHERE  
					(  
					CASE      
					WHEN @drillvalue='' THEN 'TRUE'   
					WHEN @drillvalue IS NULL THEN 'TRUE'    
					ELSE                                                      
					CASE WHEN SPD.FormulaSegmentID IN (@drillvalue) THEN 'TRUE' END              
					END='TRUE'  
					) AND EC.CategoryName IS NOT NULL
			UNION 

			SELECT DISTINCT SPD.ShiftId,SPD.ShiftRunTime AS ShiftRuntime, CC.NAME   
			FROM @ProductionSummaryTable SPD
			INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
			INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = SPD.ChainProgaramId  
			INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId
				WHERE  
				(  
				CASE      
				WHEN @drillvalue='' THEN 'TRUE'   
				WHEN @drillvalue IS NULL THEN 'TRUE'    
				ELSE                                                      
				CASE WHEN SPD.FormulaSegmentID IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				) ;
		   	
		   WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,TextileId)
		   AS
		   (
			SELECT EC.CategoryName,SUM(SPD.ActualProduction),
			CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
			NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
			COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
			SUM(DISTINCT SPD.PlantTargetProd),SUM([NoOfLoads]),SUM( SPD.ShiftRunTime),
			SUM( SPD.ShiftRunTime),EC.TextileId
			FROM @ProductionSummaryTable SPD
			LEFT JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
			WHERE  
				(  
				CASE      
				WHEN @drillvalue='' THEN 'TRUE'   
				WHEN @drillvalue IS NULL THEN 'TRUE'    
				ELSE                                                      
				CASE WHEN SPD.FormulaSegmentID IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				) AND EC.CategoryName IS NOT NULL  
				GROUP BY EC.CategoryName,EC.TextileId,SPD.ShiftId 
    
			UNION

			SELECT CC.Name,SUM(SPD.ActualProduction),
			CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
			NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
			COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
			SUM(DISTINCT SPD.PlantTargetProd),SUM([NoOfLoads]),SUM( SPD.ShiftRunTime),
			SUM( SPD.ShiftRunTime),CC.TextileId
			FROM @ProductionSummaryTable SPD
			INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
			INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = SPD.ChainProgaramId
			INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId 
			WHERE  
				(  
				CASE      
				WHEN @drillvalue='' THEN 'TRUE'   
				WHEN @drillvalue IS NULL THEN 'TRUE'    
				ELSE                                                      
				CASE WHEN SPD.FormulaSegmentID IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				)   
				Group by CC.Name,cc.TextileId,SPD.ShiftId  
  
		   )
			INSERT INTO @resultSet
			SELECT         
			0, 
			DateRange,  
			SUM(TotalLoad),
			SUM(TotalEfficiency),
			@PlantTargetProduction,
			SUM(Numberofbatches),
			SUM(ActualRunTime),
			SUM(TargetRuntime)
			,@Viewtype 
			,@Subview
			,TextileId
			FROM CTE 
			WHERE TotalLoad IS NOT NULL       
			GROUP BY DateRange,TextileId;

           WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name
							   
	    END
  
		IF(@Subview=22) --Formula
		BEGIN
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			PM.Name    
			FROM @ProductionSummaryTable SPD
			INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId  
				INNER JOIN TCD.ProgramMaster PM ON --EC.TextileId = PM.EcolabTextileCategoryId AND 
				SPD.ProgramMasterId = PM.ProgramId    
	
				WHERE  
				(  
				CASE      
				WHEN @drillvalue='' THEN 'TRUE'   
				WHEN @drillvalue IS NULL THEN 'TRUE'    
				ELSE                                                      
				CASE WHEN EC.TextileId IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				) AND PM.NAME IS NOT NULL
			
			UNION

			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			PM.Name    
			FROM @ProductionSummaryTable SPD
			INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId  
				INNER JOIN TCD.ProgramMaster PM ON  SPD.ProgramMasterId = PM.ProgramId    
				WHERE  
				(  
				CASE      
				WHEN @drillvalue='' THEN 'TRUE'   
				WHEN @drillvalue IS NULL THEN 'TRUE'    
				ELSE                                                      
				CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE' 
				) ;

			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,WasherGroupId)
			AS
			(
				SELECT PM.Name,SUM(SPD.ActualProduction),
				CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
				NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
				COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
				SUM( SPD.PlantTargetProd),SUM([NoOfLoads]),SUM( SPD.ShiftRunTime),
				SUM( SPD.ShiftRunTime),PM.ProgramId
				FROM @ProductionSummaryTable SPD
				INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
				INNER JOIN TCD.ProgramMaster PM ON --EC.TextileId = PM.EcolabTextileCategoryId AND 
				SPD.ProgramMasterId = PM.ProgramId    
				WHERE
				 (
				 CASE    
				  WHEN @drillvalue='' THEN 'TRUE' 
				  WHEN @drillvalue IS NULL THEN 'TRUE'  
				  ELSE                                                    
				  CASE WHEN EC.TextileId IN (@drillvalue) THEN 'TRUE' END            
				  END='TRUE'
				 ) AND PM.NAME IS NOT NULL
				GROUP BY PM.Name,PM.ProgramId --,SPD.ShiftId 
    
			UNION

				SELECT PM.Name,SUM(SPD.ActualProduction),
				CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
				NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
				COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
				SUM(DISTINCT SPD.PlantTargetProd),SUM([NoOfLoads]),SUM( SPD.ShiftRunTime),
				SUM( SPD.ShiftRunTime),PM.ProgramId
				FROM @ProductionSummaryTable SPD 
				INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
				INNER JOIN TCD.ProgramMaster PM ON  SPD.ProgramMasterId = PM.ProgramId  
				WHERE
				 (
				  CASE    
				  WHEN @drillvalue='' THEN 'TRUE' 
				  WHEN @drillvalue IS NULL THEN 'TRUE'  
				  ELSE                                                    
				  CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END            
				  END='TRUE'
				 )
				GROUP BY PM.Name,PM.ProgramId--,SPD.ShiftId  
      
			)
			INSERT INTO @resultSet
			SELECT  
			0, 
			DateRange,
			SUM(TotalLoad),
			SUM(TotalEfficiency),
			@PlantTargetProduction,
			SUM(Numberofbatches),
			SUM(ActualRunTime),
			SUM(TargetRuntime)
			,@Viewtype 
			,@Subview
			,WasherGroupId
			FROM CTE 
			WHERE TotalLoad IS NOT NULL       
			GROUP BY DateRange,WasherGroupId;
			
			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name
END
 END

      SELECT       
      DateRange,
      ISNULL([TCD].[FnConsumptionOnMetrics](TotalLoad,'Weight',@UserId),0),  
      --ISNULL(TotalLoad,0),  
      ISNULL([TCD].[FnConsumptionOnMetrics](WasherEfficiency,'Weight',@UserId),0),  
      --ISNULL(WasherEfficiency,0),  
      ISNULL([TCD].[FnConsumptionOnMetrics](PlantTargetLoad,'Weight',@UserId),0),  
      --ISNULL(PlantTargetLoad,0),  
      ISNULL(Numberofbatches,0),  
      ISNULL([ActualRunTime],0) [ActualRunTime],  
      ISNULL([TargetRunTime],0) [TargetRunTime],  
      Viewtype,  
      Subview,  
      Id,  
      ShiftId,  
      @CorrectionVariable  
      FROM @resultSet   


	  
SET NOCOUNT OFF
END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[SavePlantSettings]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[SavePlantSettings]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[SavePlantSettings]
(
@PlantId			 NVARCHAR(1000)		,
@IPAddress	         NVARCHAR(1000)		,
@PortNumber		     NVARCHAR(1000)		,
@PlantVersion		 NVARCHAR(25)				
)
AS
BEGIN
SET nocount ON;
DECLARE @UpdateFlag BIT = 1
IF NOT EXISTS (SELECT 1 FROM TCD.PlantSettings WHERE PlantId=@PlantId)
	BEGIN
		INSERT INTO TCD.PlantSettings
		(PlantId, IPAddress, PortNumber, PlantVersion)
		VALUES(@PlantId,@IPAddress, @PortNumber, @PlantVersion)
	END
ELSE
	BEGIN
		IF EXISTS(SELECT 1 FROM TCD.PlantSettings WHERE PlantId=@PlantId AND IpAddress = @IPAddress AND NodeId IS NOT NULL)
			BEGIN
				SET @UpdateFlag = 0
			END

		UPDATE TCD.PlantSettings 
		SET IPAddress=@IPAddress, PortNumber=@PortNumber 
		WHERE PlantId=@PlantId
	END
	
	SELECT @UpdateFlag

SET NOCOUNT OFF;
END
GO