﻿IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlConventionalData_Online]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlConventionalData_Online]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessMyControlConventionalData_Online]
(
	@ControllerID   INT,
	@VxML           XML,
	@RedFlagShiftId INT OUTPUT
)
AS
	BEGIN
	    DECLARE @MachineNumber           INT,
			  @StepNumber              INT,
			  @StartDateTime           DATETIME,
			  @EndDateTime             DATETIME,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @PHValue                 INT,
			  @TemperatureMin          INT,
			  @TemperatureMax          INT,
			  @TempMinStatus           INT,
			  @TempMaxStatus           INT,
			  @BatchNumber             INT,
			  @WasherID                INT,
			  @WasherGroupID           INT,
			  @EcoLabWasherID          INT,
			  @ProgramMasterID         INT,
			  @PlantWasherNumber       INT,
			  @ShiftID                 INT,
			  @FrmParameterID          INT,
			  @PHParameterID           INT,
			  @PHParameterStatus       INT,
			  @BatchID                 INT,
			  @ShiftStartdate          DATETIME,
			  @ShiftName               NVARCHAR(50),
			  @XMLDataID               INT,
			  @TempParameter           INT,
			  @TemperatureMinParam     INT,
			  @TemperatureMaxParam     INT,
			  @TempMinStatusParam      INT,
			  @TempMaxStatusParam      INT,
			  @WashStepNo              INT,
			  @CurrencyCode            VARCHAR(50),
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @TargetTurnTime          INT;
	    SELECT @MachineNumber = T.c.value('@MachineNumber', 'INT'),
			 @StepNumber = T.c.value('@StepNumber', 'INT'),
			 @StartDateTime = T.c.value('@StartDateTime', 'DATETIME'),
			 @EndDateTime = T.c.value('@EndDateTime', 'DATETIME'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)')/10,
			 @NominalLoad = T.c.value('@NominalLoad', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'INT'),
			 @PHStatus = T.c.value('@PHStatus', 'INT'),
			 @PHValue = T.c.value('@PHValue', 'INT'),
			 @TemperatureMin = T.c.value('@TemperatureMin', 'INT'),
			 @TemperatureMax = T.c.value('@TemperatureMax', 'INT'),
			 @TempMaxStatus = T.c.value('@TemperatureMaxStatus', 'INT'),
			 @TempMinStatus = T.c.value('@TemperatreMinStatus', 'INT'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT')
	    FROM @VxML.nodes('MyControlConventionalData') T(C);
	    SELECT @PHParameterID = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'pH';
	    SELECT @PHParameterStatus = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'PH Status';
	    SELECT @TemperatureMinParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Mimum Temperature';
	    SELECT @TemperatureMaxParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Maximum Temperature';
	    SELECT @TempMinStatusParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Minimum Temperature Status';
	    SELECT @TempMaxStatusParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Max Temperature Status';
	    SELECT @WashStepNo = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'StepCompartment No';
	    SELECT @FrmParameterID = [Id]
	    FROM TCD.ConduitPArameters
	    WHERE Name = 'Formula Number';
	    DECLARE @ShiftMapping TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    INSERT INTO @ShiftMapping
	    (
		  ShiftId,
		  ShiftName,
		  ShiftStartdate
	    )
	    EXEC TCD.GetShiftStartDate
		    @StartDateTime,
		    1,
		    @RedFlagShiftId OUTPUT;
	    SELECT @ShiftID = ShiftID,
			 @ShiftStartdate = ShiftStartdate
	    FROM @ShiftMapping;
	    SELECT @WasherGroupID = GroupId,
			 @WasherID = WasherID
	    FROM TCD.MachineSetup ms
	    WHERE ControllerID = @ControllerID
			AND MachineInternalId = @MachineNumber
			AND IsTunnel = 0
			AND IsDeleted = 0;
	    IF(@EndDateTime = '1/1/1900')
		   SELECT @EndDateTime = NULL;
	    IF(@StartDateTime = '1/1/1900')
		   SELECT @StartDateTime = NULL;
	    IF(@WasherId IS NOT NULL)
		   BEGIN
			  SELECT @ProgramMasterId = Wps.ProgramId
			  FROM TCD.Washer Ws
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.ControllerID = Wg.ControllerId
				  INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.EcoLabAccountNumber
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wps.Is_Deleted = 0;
			  SELECT @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber,
				    @CurrencyCode = P.CurrencyCode,
				    @TargetTurnTime = w.TargetTurnTime * 60
			  FROM TCD.Washer w
				  INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.EcolabAccountNumber
			  WHERE w.WasherId = @WasherID;
	   END;
	    SELECT @BatchID = BatchID
	    FROM TCD.BatchData
	    WHERE MachineInternalID = @MachineNumber
			AND StartDate = @StartDateTime
			AND ControllerBatchId = @BatchNumber
			AND MachineID = @WasherID;

	    --Start Getting InjectionCount and StepCount
	    SELECT @StdInjectionSteps = COUNT(DISTINCT wdpm.
	    WasherDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) -
			 COUNT(DISTINCT wdpm.WasherDosingSetupId)
	    FROM TCD.WasherDosingProductMapping wdpm
		    RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm.
		    WasherDosingSetupId = wds.WasherDosingSetupId
	    WHERE wds.ControllerID = @ControllerID
			AND wds.ProgramNumber = @ProgramNumber;
	    --End Getting InjectionCount and StepCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramMasterId
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT @EcolabTextileCategoryId = pcp.
			  EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp.
				    ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    IF(@BatchID IS NULL)
		   BEGIN
			  INSERT INTO TCD.BatchData
			  (ControllerBatchID,
			   EcolabWasherId,
			   GroupId,
			   MachineInternalId,
			   PlantWasherNumber,
			   StartDate,
			   EndDate,
			   ProgramNumber,
			   ProgramMasterId,
			   MachineID,
			   ActualWeight,
			   StandardWeight,
			   CurrencyCode,
			   ShiftId,
			   PartitionOn,
			   StdInjectionSteps,
			   StdWashSteps,
			   EcolabTextileCategoryId,
			   ChainTextileCategoryId,
			   FormulaSegmentId,
			   EcolabSaturationId,
			   PlantProgramId,
			   EndDateFormula,
			   TargetTurnTime
			  )
			  VALUES
			  (
				    @BatchNumber,
				    @EcoLabWasherID,
				    @WasherGroupID,
				    @MachineNumber,
				    @PlantWasherNumber,
				    @StartDateTime,
				    @EndDateTime,
				    @ProgramNumber,
				    @ProgramMasterId,
				    @WasherID,
				    @Load,
				    @NominalLoad,
				    @CurrencyCode,
				    @ShiftID,
				    @ShiftStartdate,
				    @StdInjectionSteps,
				    @StdWashSteps,
				    @EcolabTextileCategoryId,
				    @ChainTextileCategoryId,
				    @FormulaSegmentId,
				    @EcolabSaturationId,
				    @PlantProgramId,
				    @EndDateTime,
				    @TargetTurnTime
			  );
			  SELECT @BatchID = SCOPE_IDENTITY();
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM TCD.BatchParameters
				 WHERE BatchId = @BatchID
					  AND ParameterID = 38
			   )
			   BEGIN
			   IF(@StdWashSteps <> 0
				 OR @StdWashSteps <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
					   BatchId,
					   EcolabWasherId,
					   ParameterId,
					   ParameterValue,
					   PartitionOn
					)
					SELECT @BatchID,
						  @EcoLabWasherID,
						  38,
						  @StdWashSteps,
						  @ShiftStartdate;
				  END
			END;

			  --End Date  Time  is Null 
			  UPDATE TCD.BatchData
			    SET
				   EndDate = GETUTCDATE()
			  WHERE MachineInternalID = @MachineNumber
				   AND StartDate <> @StartDateTime
				   AND EndDate IS NULL
				   AND ControllerBatchId <> @BatchNumber
				   AND MachineId = @WasherId;	
																  		
			  -- Program Number	
			  IF(@ProgramNumber IS NOT NULL
				AND @ProgramNumber > 0)
				 BEGIN
					IF NOT EXISTS
					(
					    SELECT *
					    FROM TCD.WasherReading
					    WHERE WasherId = @WasherID
							AND ParameterID = @FrmParameterID
							AND DateTimeStamp = @StartDateTime
					)
					    BEGIN
						   INSERT INTO TCD.WasherReading
						   (WasherID,
						    ParameterID,
						    ParameterValue,
						    DateTimeStamp,
						    EcoLabWasherID,
						    Partitionon
						   )
						   VALUES
						   (
								@WasherID,
								@FrmParameterID,
								@ProgramNumber,
								@StartDateTime,
								@EcoLabWasherID,
								@ShiftStartdate
						   );
					    END;
				 END;
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM [TCD].[BatchCustomerData]
				 WHERE BatchID = @BatchId
					  AND @CustomerNumber IS NOT NULL
			  )
				 BEGIN
					INSERT INTO [TCD].[BatchCustomerData]
					([BatchId],
					 CustomerID,
					 [Weight],
					 PartitionOn,
					 EcolabWasherId
					)
					VALUES
					(
						  @BatchID,
						  @CustomerNumber,
						  @Load,
						  @ShiftStartdate,
						  @EcolabWasherID
					);
				 END;
		   END;

	    -- PH Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @PHParameterID
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@PHValue <> 0
				OR @PHValue <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @PHParameterID,
							    @PHValue,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 
	 
	    -- PH Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @PHParameterStatus
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@PHStatus <> 0
				OR @PHStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @PHParameterStatus,
							    @PHStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Min Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TemperatureMinParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TemperatureMin <> 0
				OR @TemperatureMin <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TemperatureMinParam,
							    @TemperatureMin,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Max Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TemperatureMaxParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TemperatureMax <> 0
				OR @TemperatureMax <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TemperatureMaxParam,
							    @TemperatureMax,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Min Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TempMinStatusParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TempMinStatus <> 0
				OR @TempMinStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TempMinStatusParam,
							    @TempMinStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Max Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TempMaxStatusParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TempMaxStatus <> 0
				OR @TempMaxStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TempMaxStatusParam,
							    @TempMaxStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- StepCompartment No
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @WashStepNo
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@StepNumber <> 0
				OR @StepNumber <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @WashStepNo,
							    @StepNumber,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END;
	END;

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlConventionalData_CompletedBatches]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlConventionalData_CompletedBatches]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessMyControlConventionalData_CompletedBatches](
	@ControllerID   INT,
	@VxML           XML,
	@PLCPointer     INT,
	@ReadPointer    INT,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @MachineNumber           INT,
			  @StartDateTime           DATETIME,
			  @EndDateTime             DATETIME,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @PHValue                 INT,
			  @TemperatureMin          INT,
			  @TemperatureMax          INT,
			  @TempMinStatus           INT,
			  @TempMaxStatus           INT,
			  @BatchNumber             INT,
			  @WasherID                INT,
			  @WasherGroupID           INT,
			  @EcoLabWasherID          INT,
			  @ProgramMasterID         INT,
			  @PlantWasherNumber       INT,
			  @ShiftID                 INT,
			  @BatchID                 INT,
			  @ShiftStartdate          DATETIME,
			  @LastStep                INT,
			  @CurrentStep             INT,
			  @CurrentStepTime         DATETIME,
			  @MinTempParamID          INT,
			  @MaxTempParamID          INT,
			  @MinTempStatuParamID     INT,
			  @MaxTempStatusParamID    INT,
			  @PHStatusParamID         INT,
			  @PHValueParamID          INT,
			  @CurrencyCode            VARCHAR(50),
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @ActualInjSteps          INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @TargetTurnTime          INT;
	    SELECT @MachineNumber = T.c.value('@MachineNumber', 'INT'),
			 @StartDateTime = T.c.value('@StartDateTime', 'DateTime'),
			 @EndDateTime = T.c.value('@EndDateTime', 'DateTime'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@NominalLoad', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'INT'),
			 @PHStatus = T.c.value('@PHStatus', 'INT'),
			 @PHValue = T.c.value('@PHValue', 'INT'),
			 @TemperatureMin = T.c.value('@TemperatureMin', 'INT'),
			 @TemperatureMax = T.c.value('@TemperatureMax', 'INT'),
			 @TempMaxStatus = T.c.value('@TemperatureMaxStatus', 'INT'),
			 @TempMinStatus = T.c.value('@TemperatreMinStatus', 'INT'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT')
	    FROM @VxML.nodes('MyControlConventionalData') T(C);
	    DECLARE @ShiftMapping TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    INSERT INTO @ShiftMapping
	    (ShiftId,
		ShiftName,
		ShiftStartdate
	    )
	    EXEC TCD.GetShiftStartDate
		    @StartDateTime,
		    1,
		    @RedFlagShiftId OUTPUT;
	    SELECT @ShiftID = ShiftID,
			 @ShiftStartdate = ShiftStartdate
	    FROM @ShiftMapping;
	    SELECT @WasherGroupID = GroupId,
			 @WasherID = WasherID
	    FROM TCD.MachineSetup ms
	    WHERE ControllerID = @ControllerID
			AND MachineInternalId = @MachineNumber
			AND IsTunnel = 0
			AND IsDeleted = 0;
	    IF(@WasherId IS NOT NULL)
		   BEGIN
			  SELECT @ProgramMasterId = Wps.ProgramId
			  FROM TCD.Washer Ws
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws
				  .WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =
				  Mst.GroupId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.
				  ControllerID = Wg.ControllerId
				  INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber =
				  Ws.EcoLabAccountNumber
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wps.Is_Deleted = 0;
			  SELECT @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber,
				    @CurrencyCode = P.CurrencyCode,
				    @TargetTurnTime = w.TargetTurnTime * 60
			  FROM TCD.Washer w
				  INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.
				  EcolabAccountNumber
			  WHERE w.WasherId = @WasherID;
		   END;
	    SELECT @BatchID = BatchID
	    FROM TCD.BatchData
	    WHERE MachineInternalID = @MachineNumber
			AND StartDate = @StartDateTime
			AND ControllerBatchId = @BatchNumber
			AND MachineID = @WasherID;

	    --Start Getting InjectionCount and StepCount

	    SELECT @StdInjectionSteps = COUNT(DISTINCT wdpm.
	    WasherDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) -
			 COUNT(DISTINCT wdpm.WasherDosingSetupId)
	    FROM TCD.WasherDosingProductMapping wdpm
		    RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm.
		    WasherDosingSetupId = wds.WasherDosingSetupId
	    WHERE wds.ControllerID = @ControllerID
			AND wds.ProgramNumber = @ProgramNumber;

	    --End Getting InjectionCount and StepCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramMasterId
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT @EcolabTextileCategoryId = pcp.
			  EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp.
				    ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    IF(@BatchID IS NULL)
		   BEGIN
			  INSERT INTO TCD.BatchData
			  (ControllerBatchID,
			   EcolabWasherId,
			   GroupId,
			   MachineInternalId,
			   PlantWasherNumber,
			   StartDate,
			   EndDate,
			   ProgramNumber,
			   ProgramMasterId,
			   MachineID,
			   ActualWeight,
			   StandardWeight,
			   CurrencyCode,
			   ShiftId,
			   PartitionOn,
			   StdInjectionSteps,
			   StdWashSteps,
			   EcolabTextileCategoryId,
			   ChainTextileCategoryId,
			   FormulaSegmentId,
			   EcolabSaturationId,
			   PlantProgramId,
			   EndDateFormula,
			   TargetTurnTime
			  )
			  VALUES
			  (
				    @BatchNumber,
				    @EcoLabWasherID,
				    @WasherGroupID,
				    @MachineNumber,
				    @PlantWasherNumber,
				    @StartDateTime,
				    @EndDateTime,
				    @ProgramNumber,
				    @ProgramMasterId,
				    @WasherID,
				    @Load,
				    @NominalLoad,
				    @CurrencyCode,
				    @ShiftID,
				    @ShiftStartdate,
				    @StdInjectionSteps,
				    @StdWashSteps,
				    @EcolabTextileCategoryId,
				    @ChainTextileCategoryId,
				    @FormulaSegmentId,
				    @EcolabSaturationId,
				    @PlantProgramId,
				    @EndDateTime,
				    @TargetTurnTime
			  );
			  SELECT @BatchID = SCOPE_IDENTITY();
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM TCD.BatchParameters
				 WHERE BatchId = @BatchID
					  AND ParameterID = 38
			  )
				 BEGIN
					IF(@StdWashSteps > 0
					   OR @StdWashSteps <> NULL)
					    INSERT INTO TCD.BatchParameters
					    (BatchId,
						EcolabWasherId,
						ParameterId,
						ParameterValue,
						PartitionOn
					    )
							 SELECT @BatchID,
								   @EcoLabWasherID,
								   38,
								   @StdWashSteps,
								   @ShiftStartdate;
				 END;
		   END;
	    ELSE
		   BEGIN
			  UPDATE tcd.BatchData
			    SET
				   EndDate = @EndDateTime,
				   EndDateFormula = @EndDateTime,
				   ProgramNumber = @ProgramNumber,
				   ProgramMasterId = @ProgramMasterID,
				   ActualWeight = @Load,
				   SyncReady = 1
			  WHERE BatchID = @BatchID;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT 1
		   FROM [TCD].[BatchCustomerData]
		   WHERE BatchID = @BatchId
			    AND @CustomerNumber IS NOT NULL
	    )
		   BEGIN
			  INSERT INTO [TCD].[BatchCustomerData]
			  ([BatchId],
			   CustomerID,
			   [Weight],
			   PartitionOn,
			   EcolabWasherId
			  )
			  VALUES
			  (
				    @BatchID,
				    @CustomerNumber,
				    @Load,
				    @ShiftStartdate,
				    @EcolabWasherID
			  );
		   END;
	    ELSE
	    IF(@CustomerNumber > 0)
		   BEGIN
			  UPDATE [TCD].[BatchCustomerData]
			    SET
				   CustomerID = @CustomerNumber,
				   [Weight] = @Load
			  WHERE BatchID = @BatchId;
		   END;
	    CREATE TABLE #Dosing
	    (
		    equipmentNo INT,
		    StepNo      INT,
		    Qty         DECIMAL(10, 6)
	    );
	    INSERT INTO #Dosing
			 SELECT T.c.value('@Equipment', 'INT'),
				   T.c.value('@stepNo', 'INT'),
				   T.c.value('@Qty', 'Decimal(10,6)')
			 FROM @VxML.nodes(
			 'MyControlConventionalData/DosingData/Dosing'
						  ) T(C)
			 WHERE T.c.value('@Qty', 'Decimal(10,6)') > 0;
	    CREATE TABLE #StepTime
	    (
		    Number    INT,
		    [Time]    INT,
		    StartTime DATETIME,
		    EndTime   DATETIME
	    );
	    INSERT INTO #StepTime
	    (Number,
		[Time]
	    )
			 SELECT T.c.value('@Number', 'INT'),
				   T.c.value('@Time', 'INT')
			 FROM @VxML.nodes('MyControlConventionalData/StepTime/Step')
			 T(C);
	    CREATE TABLE #TimeStamp
	    (
		    Step_Number INT,
		    Time_Stamp  INT
	    );
	
	    --For Calculating TIME_STAMP

	    WITH TempTable
		    AS (SELECT DISTINCT
					Number
			   FROM #StepTime)
		    INSERT INTO #TimeStamp
		    (Step_Number,
			Time_Stamp
		    )
				 SELECT b.Number,
					   SUM(t.Time) Time_Stamp
				 FROM TempTable b
					 INNER JOIN #StepTime t ON b.Number >= t.Number
				 GROUP BY b.Number;
	    CREATE TABLE #BatchProductData
	    (
		    equipmentNo INT,
		    StepNo      INT,
		    Qty         DECIMAL(10, 6),
		    Time_Stamp  DATETIME2(7)
	    );
	    INSERT INTO #BatchProductData
	    (equipmentNo,
		StepNo,
		Qty,
		Time_Stamp
	    )
			 SELECT d.equipmentNo,
				   d.StepNo,
				   d.Qty,
				   DATEADD(ss, ts.Time_Stamp, @StartDateTime)
			 FROM #Dosing d
				 INNER JOIN #TimeStamp ts ON d.StepNo = ts.Step_Number
	    ;


	    --END For calculating TIMESTAMP

	    INSERT INTO TCD.BatchProductData
	    (BatchId,
		StepCompartment,
		ActualQuantity,
		PartitionOn,
		EcolabWasherId,
		ProductId,
		TimeStamp
	    )
			 SELECT @BatchID,
				   b.StepNo,
				   b.Qty,
				   @ShiftStartdate,
				   @EcolabWasherId,
				   a.ProductId,
				   b.Time_Stamp
			 FROM TCD.ControllerEquipmentSetup a
				 INNER JOIN #BatchProductData b ON a.
				 ControllerEquipmentId = b.equipmentNo
			 WHERE b.equipmentNo > 0
				  AND b.Qty > 0
				  AND ControllerID = @ControllerID
				  AND a.ProductId IS NOT NULL
				  

	    --Start Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
	    SELECT @ActualInjSteps = COUNT(DISTINCT StepNo)
	    FROM #Dosing;
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.BatchParameters
		   WHERE ParameterId = 37
			    AND batchid = @BatchID
			    AND @ActualInjSteps > 0
	    )
		   BEGIN
			  IF(@ActualInjSteps > 0
				OR @ActualInjSteps IS NOT NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchId,
							@EcolabWasherId,
							37,
							@ActualInjSteps,
							@ShiftStartDate;
		   END;
	    ELSE
		   BEGIN
			  UPDATE TCD.BatchParameters
			    SET
				   ParameterValue = @ActualInjSteps
			  WHERE ParameterId = 37
				   AND batchid = @BatchID;
		   END;
	    SELECT @LastStep = MAX([Number])
	    FROM #StepTime
	    WHERE [Time] > 0;
	    SELECT @CurrentStep = 1,
			 @CurrentStepTime = @StartDateTime;
	    WHILE(@CurrentStep <= @LastStep)
		   BEGIN
			  UPDATE #StepTime
			    SET
				   StartTime = @CurrentStepTime,
				   EndTime = DATEADD(ss, [time], @CurrentStepTime)
			  WHERE Number = @CurrentStep;
			  SELECT @CurrentStepTime = EndTime
			  FROM #StepTime
			  WHERE Number = @CurrentStep;
			  SELECT @CurrentStep = @CurrentStep + 1;
		   END;
	    INSERT INTO [TCD].[BatchWashStepData]
	    (BatchID,
		StepCompartment,
		StartTime,
		EndTime,
		PartitionOn,
		EcolabWasherId
	    )
			 SELECT @BatchID,
				   Number,
				   StartTime,
				   EndTime,
				   @ShiftStartdate,
				   @EcoLabWasherID
			 FROM #StepTime
			 WHERE Number <= @LastStep;
	    SELECT @MinTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Mimum Temperature';
	    SELECT @MaxTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Maximum Temperature';
	    SELECT @MaxTempStatusParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Max Temperature Status';
	    SELECT @MinTempStatuParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Minimum Temperature Status';
	    SELECT @PHValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH';
	    SELECT @PHStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH Status';
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MinTempParamID
	    )
		   BEGIN
			  IF(@TemperatureMin <> 0
				OR @TemperatureMin <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(BatchId,
					 EcolabWasherId,
					 ParameterId,
					 ParameterValue,
					 PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MinTempParamID,
						  @TemperatureMin,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MaxTempParamID
	    )
		   BEGIN
			  IF(@TemperatureMax <> 0
				OR @TemperatureMax <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(BatchId,
					 EcolabWasherId,
					 ParameterId,
					 ParameterValue,
					 PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MaxTempParamID,
						  @TemperatureMax,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MaxTempStatusParamID
	    )
		   BEGIN
			  IF(@TempMaxStatus <> 0
				OR @TempMaxStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(BatchId,
					 EcolabWasherId,
					 ParameterId,
					 ParameterValue,
					 PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MaxTempStatusParamID,
						  @TempMaxStatus,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MinTempStatuParamID
	    )
		   BEGIN
			  IF(@TempMinStatus <> 0
				OR @TempMinStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(BatchId,
					 EcolabWasherId,
					 ParameterId,
					 ParameterValue,
					 PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MinTempStatuParamID,
						  @TempMinStatus,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF(@PHStatus <> 0
		  OR @PHStatus <> NULL)
		   BEGIN
			  INSERT INTO TCD.BatchParameters
			  (BatchId,
			   EcolabWasherId,
			   ParameterId,
			   ParameterValue,
			   PartitionOn
			  )
			  VALUES
			  (
				    @BatchID,
				    @EcoLabWasherID,
				    @PHStatusParamID,
				    @PHStatus,
				    @ShiftStartdate
			  );
		   END;
	    IF(@PHValue <> 0
		  OR @PHValue <> NULL)
		   BEGIN
			  INSERT INTO TCD.BatchParameters
			  (BatchId,
			   EcolabWasherId,
			   ParameterId,
			   ParameterValue,
			   PartitionOn
			  )
			  VALUES
			  (
				    @BatchID,
				    @EcoLabWasherID,
				    @PHValueParamID,
				    @PHValue,
				    @ShiftStartdate
			  );
		   END;
	    DROP TABLE #BatchProductData;
	    DROP TABLE #Dosing;
	    DROP TABLE #StepTime;
	    DROP TABLE #TimeStamp;
	END;

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlTunnelWasherOnlineData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlTunnelWasherOnlineData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessMyControlTunnelWasherOnlineData](
	@ControllerID   INT,
	@xmlTags        XML,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @BatchID                 INT,
			  @WasherID                INT,
			  @EcolabWasherId          INT,
			  @CurrencyCode            VARCHAR(50),
			  @MachineInternalId       INT,
			  @WasherGroupID           INT,
			  @PlantWasherNumber       INT,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @BatchNumber             INT,
			  @TargetTurnTime          INT,
			  @PartitionOn             DATETIME,
			  @BatchStartTime          DATETIME,
			  @ProgramID               INT,
			  @NumberOfCompartments    INT,
			  @TransferSignalId        INT,
			  @BatchShiftId            INT,
			  @compartmentID           INT,
			  @TunnelXML               XML,
			  @TempXML                 XML,
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT;
	    SELECT @TransferSignalId = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Transfer Signal';
	    CREATE TABLE #Batches
	    (
		    BatchNumber   INT,
		    StartDateTime DATETIME
	    );
	    -- SET @compartmentID = 1;

	    SELECT @TempXML = T.c.query('.')
	    FROM @xmlTags.nodes('MyControlTunnel') AS T(c);
	    SELECT @MachineInternalID = T.c.value('@MachineNumber', 'int')
	    FROM @TempXML.nodes('MyControlTunnel') AS T(c);
	    SELECT @EcolabWasherID = EcolabWasherId,
			 @WasherGroupID = Wg.WasherGroupId,
			 @PlantWasherNumber = PlantWasherNumber,
			 @WasherID = ws.WasherId,
			 @CurrencyCode = P.CurrencyCode,
			 @NumberOfCompartments = Mst.NumberofComp
	    FROM TCD.Washer AS Ws
		    INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = Ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.
		    GroupId
		    INNER JOIN TCD.WasherGroupType AS WgT ON WgT.
		    WasherGroupTypeId = Wg.WasherGroupTypeId
		    INNER JOIN TCD.ConduitController AS Ctrl ON Ctrl.
		    ControllerId = Mst.ControllerId
		    INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.
		    EcoLabAccountNumber
	    WHERE Ctrl.ControllerID = @ControllerID
			AND mst.MachineInternalId = @MachineInternalID
			AND Mst.IsTunnel = 1 AND Mst.IsDeleted =0;
	    SET @compartmentID = @NumberOfCompartments;
	    WHILE(@compartmentID <= @NumberOfCompartments
			AND @compartmentID > 0)
		   BEGIN
			  SELECT @TunnelXML = T.c.query('.')
			  FROM @xmlTags.nodes('MyControlTunnel/TunnelData') AS T(c)
			  WHERE T.c.value('@CompartmentNumber', 'INT') =
			  @compartmentID;
			  SELECT @MachineInternalID = T.c.value('@MachineNumber',
			  'int'
										    ),
				    @BatchNumber = T.c.value('@BatchNumber', 'INT'),
				    @BatchStartTime = T.c.value('@StartDateTime',
				    'DateTime'
										 ),
				    @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
				    @Load = T.c.value('@Load', 'Decimal(10,6)')/10,
				    @NominalLoad = T.c.value('@Nominalload',
				    'Decimal(10,6)'
									   ),
				    @CustomerNumber = T.c.value('@CustomerNumber',
				    'int'
										 ),
				    @PHStatus = T.c.value('@pHStatus', 'int')
			  FROM @TunnelXML.nodes('TunnelData') AS T(c);
			  DECLARE @ShiftStartDateTemp TABLE
			  (
				  ShiftId        INT,
				  ShiftName      NVARCHAR(50),
				  ShiftStartdate DATETIME
			  );
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchStartTime,
				  1,
				  @RedFlagShiftId OUTPUT;
			  SELECT @BatchShiftId = ShiftID,
				    @PartitionOn = ShiftStartdate
			  FROM @ShiftStartDateTemp;
			  IF(@ProgramNumber = 0
				OR @BatchNumber = 1)
				 BEGIN
					SELECT @compartmentID = @compartmentID - 1;
					CONTINUE;
				 END;
			  SELECT @ProgramID = ProgramId,
				    @TargetTurnTime = 3600 / (tps.TotalRunTime /
				    @NumberOfCompartments)
			  FROM TCD.TunnelProgramSetup AS tps
			  WHERE tps.WasherGroupId = @WasherGroupID
				   AND tps.is_deleted = 0
				   AND ProgramNumber = @ProgramNumber;
			  INSERT INTO #Batches
			  (BatchNumber,
			   StartDateTime
			  )
				    SELECT @BatchNumber,
						 @BatchStartTime;
			  SELECT @BatchID = NULL;
			  SELECT @BatchID = BatchID
			  FROM TCD.BatchData AS BD
			  WHERE BD.ControllerBatchId = @BatchNumber
				   AND BD.StartDate = @BatchStartTime
				   AND BD.MachineId = @WasherID;
			  --Start Getting InjectionCount,StepCount And ProductCount
			  SELECT @StdInjectionSteps = COUNT(tdpm.
			  TunnelDosingSetupId),
				    @StdWashSteps = COUNT(DISTINCT tds.
				    TunnelDosingSetupId) - COUNT(tdpm.
				    TunnelDosingSetupId)
			  FROM tcd.TunnelDosingProductMapping AS tdpm
				  RIGHT JOIN tcd.TunnelDosingSetup AS tds ON tdpm.
				  TunnelDosingSetupId = tds.TunnelDosingSetupId
			  WHERE tds.GroupId = @WasherGroupID
				   AND tds.ProgramNumber = @ProgramNumber;
			  --End Getting InjectionCount,StepCount And ProductCount
			  --Start-----ProgramMasterID logic for PlantChainProgram
			  SELECT @PlantProgramId = pm.PlantProgramId,
				    @EcolabTextileCategoryId = pm.
				    EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pm.ChainTextileId,
				    @FormulaSegmentId = pm.FormulaSegmentId,
				    @EcolabSaturationId = pm.EcolabSaturationId
			  FROM TCD.ProgramMaster AS pm
			  WHERE pm.ProgramId = @ProgramID
				   AND pm.Is_Deleted = 0;
			  IF(@PlantProgramId <> 0
				OR @PlantProgramId IS NOT NULL)
				 BEGIN
					--Assign value from plantchainprogram table based on plantprogramId
					SELECT @EcolabTextileCategoryId = pcp.
					EcolabTextileCategoryId,
						  @ChainTextileCategoryId = pcp.
						  ChainTextileCategoryId,
						  @FormulaSegmentId = pcp.FormulaSegmentId,
						  @EcolabSaturationId = pcp.
						  EcolabSaturationId
					FROM tcd.PlantChainProgram AS pcp
					WHERE pcp.PlantProgramId = @PlantProgramId
						 AND pcp.Is_Deleted = 0;
				 END;
			  --End-----ProgramMasterID logic for PlantChainProgram
			  IF @BatchID IS NULL
				 BEGIN
					INSERT INTO TCD.BatchData
					(ControllerBatchId,
					 EcolabWasherId,
					 GroupId,
					 MachineInternalId,
					 PlantWasherNumber,
					 StartDate,
					 ProgramNumber,
					 ProgramMasterId,
					 MachineId,
					 ActualWeight,
					 StandardWeight,
					 CurrencyCode,
					 ShiftId,
					 PartitionOn,
					 TargetTurnTime,
					 StdInjectionSteps,
					 StdWashSteps,
					 EcolabTextileCategoryId,
					 ChainTextileCategoryId,
					 FormulaSegmentId,
					 EcolabSaturationId,
					 PlantProgramId
					)
						  SELECT @BatchNumber,
							    @EcolabWasherID,
							    @WasherGroupID,
							    @MachineInternalID,
							    @PlantWasherNumber,
							    @BatchStartTime,
							    @ProgramNumber,
							    @ProgramID,
							    @WasherID,
							    @Load,
							    @NominalLoad,
							    @CurrencyCode,
							    @BatchShiftId,
							    @PartitionOn,
							    @TargetTurnTime,
							    @StdInjectionSteps,
							    @StdWashSteps,
							    @EcolabTextileCategoryId,
							    @ChainTextileCategoryId,
							    @FormulaSegmentId,
							    @EcolabSaturationId,
							    @PlantProgramId;
					SELECT @BatchID = SCOPE_IDENTITY();
					IF(@StdWashSteps > 0
					   OR @StdWashSteps <> NULL)
					    BEGIN
						   INSERT INTO TCD.BatchParameters
						   (BatchId,
						    EcolabWasherId,
						    ParameterId,
						    ParameterValue,
						    PartitionOn
						   )
								SELECT @BatchID,
									  @EcolabWasherId,
									  38,
									  @StdWashSteps,
									  @PartitionOn;
					    END;
					IF @CustomerNumber IS NOT NULL
					    BEGIN
						   IF NOT EXISTS
						   (
							  SELECT 1
							  FROM TCD.BatchCustomerData
							  WHERE BatchID = @BatchID
						   )
							  BEGIN
								 INSERT INTO TCD.BatchCustomerData
								 (BatchId,
								  CustomerID,
								  Weight,
								  PartitionOn,
								  EcolabWasherId
								 )
									   SELECT @BatchID,
											@CustomerNumber,
											@Load,
											@PartitionOn,
											@EcolabWasherId;
							  END;
					    END;
				 END;
			  -- Transfer Signal
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM tcd.WasherReading wr
				 WHERE wr.WasherId = @WasherID
					  AND wr.ParameterId = @TransferSignalId
					  AND wr.DateTimeStamp = @BatchStartTime
			  )
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterId,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TransferSignalId,
							    1,
							    @BatchStartTime,
							    @PartitionOn,
							    @EcolabWasherId
						  UNION ALL
						  SELECT @WasherID,
							    @TransferSignalId,
							    0,
							    @BatchStartTime,
							    @PartitionOn,
							    @EcolabWasherId;
				 END;
			  --Start Updating Batch Wash Step Data	 
			  EXEC TCD.UPDATEBatchWashStepForTunnel
				  @TunnelXML,
				  @WasherID,
				  @BatchID,
				  @BatchStartTime,
				  @PartitionOn,
				  @EcolabWasherId,
				  @compartmentID;
			  --End Updating Batch Wash Step Data	 
			  SELECT @compartmentID = @compartmentID - 1;
		   END;
	END;

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlTunnelWasherProdData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlTunnelWasherProdData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [TCD].[ProcessMyControlTunnelWasherProdData](
	@ControllerID   INT,
	@xmlTags        XML,
	@PLCPointer     INT,
	@ReadPointer    INT,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @BatchID                   INT,
			  @WasherID                  INT,
			  @EcolabWasherId            INT,
			  @CurrencyCode              VARCHAR(50),
			  @MachineInternalId         INT,
			  @WasherGroupID             INT,
			  @PlantWasherNumber         INT,
			  @ProgramNumber             INT,
			  @Load                      DECIMAL(10, 2),
			  @NominalLoad               DECIMAL(10, 2),
			  @CustomerNumber            INT,
			  @PHStatus                  INT,
			  @PHValue                   INT,
			  @LFStatus                  INT,
			  @LFValue                   INT,
			  @BatchNumber               INT,
			  @TargetTurnTime            INT,
			  @PartitionOn               DATETIME2,
			  @BatchStartTime            DATETIME2,
			  @BatchEndTime              DATETIME2,
			  @ProgramID                 INT,
			  @NumberOfCompartments      INT,
			  @ProductId                 INT,
			  @CompartmentNum            INT,
			  @EquipmentType             INT,
			  @MinTempParamID            INT,
			  @MaxTempParamID            INT,
			  @TempStatusParamID         INT,
			  @PHValueParamID            INT,
			  @PHStatusParamID           INT,
			  @ConductivityValueParamID  INT,
			  @ConductivityStatusParamID INT,
			  @StdInjectionSteps         INT,
			  @StdWashSteps              INT,
			  @ActualInjSteps            INT,
			  @EcolabTextileCategoryId   INT,
			  @ChainTextileCategoryId    INT,
			  @FormulaSegmentId          INT,
			  @EcolabSaturationId        INT,
			  @PlantProgramId            INT;
	    DECLARE @BatchShiftId INT;
	    DECLARE @ShiftStartDateTemp TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    DECLARE @TunnelXML XML;
	    SELECT @TunnelXML = T.c.query('.')
	    FROM @xmlTags.nodes('MyControlTunnel/TunnelData') T(c)
	    WHERE T.c.value('@CompartmentNumber', 'INT') = 0;
	    SELECT @MachineInternalID = T.c.value('@MachineNumber', 'int'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @BatchStartTime = T.c.value('@StartDateTime', 'DateTime'),
			 @BatchEndTime = T.c.value('@EndDateTime', 'DateTime'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@Nominalload', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'int'),
			 @PHStatus = T.c.value('@Phstatus', 'int'),
			 @PHValue = T.c.value('@Phvalue', 'INT'),
			 @LFStatus = T.c.value('@LFStatus', 'INT'),
			 @LFValue = T.c.value('@LFValue', 'INT')
	    FROM @xmlTags.nodes('MyControlTunnel/TunnelData') T(c);
	    SELECT @EcolabWasherID = Ws.EcolabWasherId,
			 @WasherGroupID = Wg.WasherGroupId,
			 @PlantWasherNumber = PlantWasherNumber,
			 @WasherID = ws.WasherId,
			 @CurrencyCode = P.CurrencyCode,
			 @NumberOfCompartments = Mst.NumberofComp
	    FROM TCD.Washer Ws
		    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.
		    GroupId
		    INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId
		    = Wg.WasherGroupTypeId
		    INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId =
		    Mst.ControllerId
		    INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.
		    EcoLabAccountNumber
	    WHERE Ctrl.ControllerID = @ControllerID
			AND Mst.MachineInternalId = @MachineInternalID
			AND Mst.IsTunnel = 1 AND Mst.IsDeleted=0;
	    SELECT @EcolabWasherID;
	    SELECT @ProgramID = ProgramId,
			 @TargetTurnTime = (3600 / (tps.TotalRunTime /
			 @NumberOfCompartments))
	    FROM TCD.TunnelProgramSetup AS tps
	    WHERE tps.WasherGroupId = @WasherGroupID
			AND tps.is_deleted = 0
			AND ProgramNumber = @ProgramNumber;
	    DELETE FROM @ShiftStartDateTemp;
	    IF(@BatchEndTime IS NOT NULL)
		   BEGIN
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchEndTime,
				  1,
				  @RedFlagShiftId OUTPUT;
		   END;
	    ELSE
		   BEGIN
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchStartTime,
				  1,
				  @RedFlagShiftId OUTPUT;
		   END;
	    SELECT @BatchShiftId = ShiftID,
			 @PartitionOn = ShiftStartdate
	    FROM @ShiftStartDateTemp;


	    --Start Getting InjectionCount,StepCount And ProductCount
	    SELECT @StdInjectionSteps = COUNT(tdpm.TunnelDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT tds.TunnelDosingSetupId) -
			 COUNT(tdpm.TunnelDosingSetupId)
	    FROM tcd.TunnelDosingProductMapping tdpm
		    RIGHT JOIN tcd.TunnelDosingSetup tds ON tdpm.
		    TunnelDosingSetupId = tds.TunnelDosingSetupId
	    WHERE tds.GroupId = @WasherGroupID
			AND tds.ProgramNumber = @ProgramNumber;
	    --End Getting InjectionCount,StepCount And ProductCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramID
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT @EcolabTextileCategoryId = pcp. EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp. ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    SELECT @BatchID = NULL;
	    SELECT @BatchID = BatchID
	    FROM TCD.BatchData BD
	    WHERE BD.ControllerBatchId = @BatchNumber
			AND BD.StartDate = @BatchStartTime
			AND BD.MachineId = @WasherID;
	    --AND BD.MachineInternalID = @MachineInternalID
	    IF(@BatchID IS NULL)
		   BEGIN
			  INSERT INTO TCD.BatchData
			  (ControllerBatchId,
			   EcolabWasherId,
			   GroupId,
			   MachineInternalId,
			   PlantWasherNumber,
			   StartDate,
			   EndDate,
			   ProgramNumber,
			   ProgramMasterId,
			   MachineId,
			   ActualWeight,
			   StandardWeight,
			   CurrencyCode,
			   ShiftId,
			   PartitionOn,
			   TargetTurnTime,
			   StdInjectionSteps,
			   StdWashSteps,
			   EcolabTextileCategoryId,
			   ChainTextileCategoryId,
			   FormulaSegmentId,
			   EcolabSaturationId,
			   PlantProgramId,
			   EndDateFormula
			  )
				    SELECT @BatchNumber,
						 @EcolabWasherID,
						 @WasherGroupID,
						 @MachineInternalID,
						 @PlantWasherNumber,
						 @BatchStartTime,
						 @BatchEndTime,
						 @ProgramNumber,
						 @ProgramID,
						 @WasherID,
						 @Load,
						 @NominalLoad,
						 @CurrencyCode,
						 @BatchShiftId,
						 @PartitionOn,
						 @TargetTurnTime,
						 @StdInjectionSteps,
						 @StdWashSteps,
						 @EcolabTextileCategoryId,
						 @ChainTextileCategoryId,
						 @FormulaSegmentId,
						 @EcolabSaturationId,
						 @PlantProgramId,
						 @BatchEndTime;
			  SELECT @BatchID = SCOPE_IDENTITY();
			  IF(@StdWashSteps > 0
				OR @StdWashSteps <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchID,
							@EcolabWasherId,
							38,
							@StdWashSteps,
							@PartitionOn;
			  EXEC TCD.UPDATEBatchWashStepForTunnel
				  @TunnelXML,
				  @WasherID,
				  @BatchID,
				  @BatchStartTime,
				  @PartitionOn,
				  @EcolabWasherId,
				  @NumberOfCompartments;
		   END;
	    IF(@BatchEndTime IS NOT NULL
		  AND @BatchEndTime != '01/01/1900')
		   BEGIN
			  UPDATE TCD.BatchData
			    SET
				   EndDate = @BatchEndTime,
				   ShiftId = @BatchShiftId,
				   PartitionOn = @PartitionOn,
				   EndDateFormula=@BatchEndTime
			  WHERE BATCHID = @BatchID;
		   END;
	    IF(@CustomerNumber IS NOT NULL)
		   BEGIN
			  IF NOT EXISTS
			  (
				 SELECT 1
				 FROM [TCD].[BatchCustomerData]
				 WHERE BatchID = @BatchID
			  )
				 BEGIN
					INSERT INTO [TCD].[BatchCustomerData]
					([BatchId],
					 CustomerID,
					 [Weight],
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @BatchID,
							    @CustomerNumber,
							    @Load,
							    @PartitionOn,
							    @EcolabWasherId;
				 END;
		   END;
	    CREATE TABLE #DosingDetails
	    (
		    Number          INT,
		    Quantity        DECIMAL(10, 6),
		    Point           INT,
		    IsMainEquioment INT
	    );
	    INSERT INTO #DosingDetails
	    (Number,
		Quantity,
		Point,
		IsMainEquioment
	    )
			 SELECT T.c.value('@Number', 'INT') AS Number, --PumpNumber
				   T.c.value('@Quantity', 'Decimal(10,6)') AS Quantity, --Dosing Quanity
				   T.c.value('@Point', 'INT') AS Point, --Dosing point
				   T.c.value('@IsMainEquioment', 'INT') AS
			 IsMainEquioment
			 FROM @xmlTags.nodes('MyControlTunnel/TunnelData/Dose') T(C)
	    ;
	
	    -- Fetching data from cursor
	    DECLARE @MYCURSOR CURSOR;
	    SET @MYCURSOR = CURSOR FAST_FORWARD
	    FOR SELECT Number,
				Quantity,
				Point,
				IsMainEquioment
		   FROM #DosingDetails;
	    DECLARE @Number          INT,
			  @Quantity        DECIMAL(10, 6),
			  @Point           INT,
			  @IsMainEquioment INT;
	    OPEN @MYCURSOR;
	    FETCH NEXT FROM @MYCURSOR INTO @Number,
								@Quantity,
								@Point,
								@IsMainEquioment;
	    WHILE @@FETCH_STATUS = 0
		   BEGIN
			  IF(@IsMainEquioment = 1)
				 BEGIN
					SET @EquipmentType = 2;
				 END;
			  ELSE
				 BEGIN
					SET @EquipmentType = 1;
				 END;
			  SELECT @ProductId = CES.ProductId,
				    @CompartmentNum = TCEVM.CompartmentNumber
			  FROM tcd.ControllerEquipmentSetup CES
				  INNER JOIN TCD.
				  TunnelCompartmentEquipmentValveMapping TCEVM ON CES.
				  ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
			  WHERE CES.ControllerId = @ControllerID
				   AND CES.ControllerEquipmentTypeId = @EquipmentType
				   AND --CES.IsActive=1 AND
				   --CES.WasherGroupNumber=@WasherGroupNum AND
				   TCEVM.DosingPointNumber = @Point
				   AND CES.ControllerEquipmentId = @Number;
				
			  --SELECT @EcolabWasherID
			  IF(@ProductId IS NOT NULL)
				 BEGIN
					INSERT INTO TCD.BatchProductData
					(BatchId,
					 StepCompartment,
					 ActualQuantity,
					 [TimeStamp],
					 PartitionOn,
					 EcolabWasherId,
					 ProductId
					)
						  SELECT @BatchID,
							    @CompartmentNum,
							    @Quantity,
							    @BatchEndTime,
							    @PartitionOn,
							    @EcolabWasherID,
							    @ProductId;
				 END;
			  FETCH NEXT FROM @MYCURSOR INTO @Number,
									   @Quantity,
									   @Point,
									   @IsMainEquioment;
		   END;
	    CLOSE @MYCURSOR;
	    DEALLOCATE @MYCURSOR;
	    DROP TABLE #DosingDetails;
	    SELECT @ActualInjSteps = COUNT(DISTINCT StepCompartment)
	    FROM TCD.BatchProductData
	    WHERE BatchId = @BatchID;
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.BatchParameters
		   WHERE ParameterId = 37
			    AND batchid = @BatchID
			    AND @ActualInjSteps > 0
	    )
		   BEGIN
			  IF(@ActualInjSteps > 0
				OR @ActualInjSteps <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchId,
							@EcolabWasherId,
							37,
							@ActualInjSteps,
							@PartitionOn;
		   END;
	    ELSE
		   BEGIN
			  UPDATE TCD.BatchParameters
			    SET
				   ParameterValue = @ActualInjSteps
			  WHERE ParameterId = 37
				   AND batchid = @BatchID;
		   END;
	    SELECT @MinTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Mimum Temperature';
	    SELECT @MaxTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Maximum Temperature';
	    SELECT @TempStatusParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Temperature Status';
	    SELECT @PHValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH';
	    SELECT @PHStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH Status';
	    SELECT @ConductivityValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Conductivity';
	    SELECT @ConductivityStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'LF Status';
	    IF(@PHValue IS NOT NULL)
		   BEGIN
			  --pH Value
			  IF(@PHValue <> 0
				OR @PHValue <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @PHValueParamID,
					   @PHValue,
					   @PartitionOn
				 );

			  --pH Status
			  IF(@PHStatus <> 0
				OR @PHStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @PHStatusParamID,
					   @PHStatus,
					   @PartitionOn
				 );
		   END;
	    IF(@LFValue IS NOT NULL)
		   BEGIN
			  --Conductivity Value
			  IF(@LFValue <> 0
				OR @LFValue <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @ConductivityValueParamID,
					   @LFValue,
					   @PartitionOn
				 );

			  --Conductivity Status
			  IF(@LFStatus <> 0
				OR @LFStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @ConductivityStatusParamID,
					   @LFStatus,
					   @PartitionOn
				 );
		   END;
	    CREATE TABLE #TemperatureDetails
	    (
		    MinimumTemp DECIMAL(10, 2),
		    MaximumTemp DECIMAL(10, 2),
		    TempStatus  DECIMAL(10, 2)
	    );
	    INSERT INTO #TemperatureDetails
	    (MinimumTemp,
		MaximumTemp,
		TempStatus
	    )
			 SELECT T.c.value('@Minimum', 'Decimal(10,2)') AS
			 MinimumTemp,
				   T.c.value('@Maximum', 'Decimal(10,2)') AS
				   MaximumTemp,
				   T.c.value('@Status', 'Decimal(10,2)') AS TempStatus
			 FROM @xmlTags.nodes(
			 'MyControlTunnel/TunnelData/TemperatureData'
							) T(c);
	  
	    -- Fetching data from cursor
	    DECLARE @TEMPCURSOR CURSOR;
	    SET @TEMPCURSOR = CURSOR FAST_FORWARD
	    FOR SELECT MinimumTemp,
				MaximumTemp,
				TempStatus
		   FROM #TemperatureDetails;
	    DECLARE @MinimumTemp DECIMAL(10, 2),
			  @MaximumTemp DECIMAL(10, 2),
			  @TempStatus  DECIMAL(10, 2);
	    OPEN @TEMPCURSOR;
	    FETCH NEXT FROM @TEMPCURSOR INTO @MinimumTemp,
								  @MaximumTemp,
								  @TempStatus;
	    WHILE @@FETCH_STATUS = 0
		   BEGIN	
			  --Minimum Temperature
			  IF(@MinimumTemp <> 0
				OR @MinimumTemp <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @MinTempParamID,
					   @MinimumTemp,
					   @PartitionOn
				 );

			  --Maximum Temperature
			  IF(@MaximumTemp <> 0
				OR @MaximumTemp <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @MaxTempParamID,
					   @MaximumTemp,
					   @PartitionOn
				 );

			  --Temperature Status
			  IF(@TempStatus <> 0
				OR @TempStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @TempStatusParamID,
					   @TempStatus,
					   @PartitionOn
				 );
			  FETCH NEXT FROM @TEMPCURSOR INTO @MinimumTemp,
										@MaximumTemp,
										@TempStatus;
		   END;
	    CLOSE @TEMPCURSOR;
	    DEALLOCATE @TEMPCURSOR;
	    DROP TABLE #TemperatureDetails;
	    UPDATE TCD.BatchWashStepData
		 SET
			EndTime = @BatchEndTime
	    WHERE BatchId = @BatchID
			AND EndTime IS NULL;
	END;

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlOnlineProductDosing]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlOnlineProductDosing]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [TCD].[ProcessMyControlOnlineProductDosing](
	@ControllerID INT,
	@VxML         XML)
AS
	BEGIN
	    DECLARE @TheoreticalQty    DECIMAL(10, 6),
			  @RealQty           DECIMAL(10, 6),
			  @BatchNumber       INT,
			  @DosingPoint       INT,
			  @DosingNumber      INT,
			  @ValveNumber       INT,
			  @ProgramNumber     INT,
			  @WasherId          INT,
			  @MachineInternalId INT,
			  @PrevRealQty       DECIMAL(10, 6),
			  @ProductId         INT,
			  @PumpNum           INT,
			  @EquipmentType     INT,
			  @CompartmentNum    INT;
	    SELECT @TheoreticalQty = T.c.value('@TheoreticalQty','Decimal(10,6)'),
			 @RealQty = T.c.value('@RealQty', 'Decimal(10,6)'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @DosingPoint = T.c.value('@DosingPoint', 'INT'),
			 @DosingNumber = T.c.value('@DoseNumber', 'INT'),
			 @PumpNum = T.c.value('@PumpNum', 'INT'),
			 @ValveNumber = T.c.value('@ValveNumber', 'INT')
	    FROM @VxML.nodes('MyControlOnlineProductDosing') T(C);
	    IF(@PumpNum >= 25
		  AND @PumpNum <= 26)
		   BEGIN
			  SET @EquipmentType = 2;
		   END;
	    ELSE
		   BEGIN
			  SET @EquipmentType = 1;
		   END;
	    IF(@DosingPoint >= 17
		  AND @DosingPoint <= 20)
		   BEGIN
			  SET @MachineInternalId = 1;
		   END;
	    ELSE
	    IF(@DosingPoint >= 21
		  AND @DosingPoint <= 24)
		   BEGIN
			  SET @MachineInternalId = 2;
		   END;
	    IF(@DosingPoint >= 1
		  AND @DosingPoint <= 16)
		   BEGIN
			  SET @MachineInternalId = @DosingPoint;
			  SELECT @WasherId = WasherId
			  FROM TCD.MachineSetup
			  WHERE ControllerID = @ControllerID
				   AND MachineInternalId = @MachineInternalId
				   AND IsTunnel = 0
				   AND IsDeleted = 0;
			  SELECT @ProductId = ProductId
			  FROM TCD.ControllerEquipmentSetup
			  WHERE ControllerEquipmentId = @PumpNum
				   AND ControllerID = @ControllerID;
		   END;
	    ELSE
	    IF(@DosingPoint >= 17
		  AND @DosingPoint <= 24)
		   BEGIN
			  SELECT @WasherId = WasherId
			  FROM TCD.MachineSetup
			  WHERE ControllerID = @ControllerID
				   AND MachineInternalId = @MachineInternalId
				   AND IsTunnel = 1
				   AND IsDeleted = 0;
			  SELECT @ProductId = CES.ProductId,
				    @CompartmentNum = TCEVM.CompartmentNumber
			  FROM tcd.ControllerEquipmentSetup CES
				  INNER JOIN TCD.
				  TunnelCompartmentEquipmentValveMapping TCEVM ON CES.
				  ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
			  WHERE CES.ControllerId = @ControllerID
				   AND CES.ControllerEquipmentTypeId = @EquipmentType
				   AND TCEVM.ValveNumber = @ValveNumber
				   AND CES.ControllerEquipmentId = @PumpNum;
		   END;
	    SELECT TOP 1 @PrevRealQty = RealQty
	    FROM TCD.WasherProductReading
	    WHERE ControllerId = @ControllerID
			AND WasherId = @WasherId
	    ORDER BY DateTimeStamp DESC;
	    IF(@ProductId IS NOT NULL)
		   BEGIN
			  IF(@PrevRealQty IS NULL
				OR @PrevRealQty != @RealQty)
				 BEGIN
					INSERT INTO [TCD].[WasherProductReading]
					(ControllerId,
					 WasherId,
					 MachineInternalId,
					 ProductId,
					 TheoreticalQty,
					 RealQty,
					 DosingPoint,
					 DosingNumber,
					 ProgramNumber,
					 BatchNumber,
					 ValveNumber,
					 DateTimeStamp
					)
						  SELECT @ControllerId,
							    @WasherId,
							    @MachineInternalId,
							    @ProductId,
							    @TheoreticalQty,
							    @RealQty,
							    @DosingPoint,
							    @DosingNumber,
							    @ProgramNumber,
							    @BatchNumber,
							    @ValveNumber,
							    GETUTCDATE();
				 END;
		   END;
	END

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[UPDATEBatchWashStepForTunnel]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[UPDATEBatchWashStepForTunnel]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [TCD].[UPDATEBatchWashStepForTunnel](
	@TunnelXML      XML,
	@WasherID       INT,
	@BatchID        INT,
	@BatchStartTime DATETIME,
	@PartitionOn    DATETIME,
	@EcolabWasherId INT,
	@CurrentStep    INT)
AS
	BEGIN
	    DECLARE @StepStart     DATETIME,
			  @StepEnd       DATETIME,
			  @CompartmentNo INT,
			  @Duration      INT,
			  @LaspStep      INT,
			  @RowCount      INT;
	    CREATE TABLE #BatchStep
	    (
		    CompartmentNo INT,
		    TimeStep      INT,
		    StartDateTime DATETIME,
		    EndDateTime   DATETIME
	    );
	    INSERT INTO #BatchStep
	    (
			 CompartmentNo,
			 TimeStep
	    )
	    SELECT T.c.value('@CompartmentNo', 'INT') AS CompartmentNo,
			 T.c.value('@Time', 'INT') AS [Time]
	    FROM @TunnelXML.nodes('TunnelData/CompartmentTime') T(c)
	    ORDER BY 1;
	    SELECT @CompartmentNo = 1,
			 @StepStart = @BatchStartTime;
	    WHILE(@CompartmentNo <= @CurrentStep AND @CompartmentNo > 0)
		   BEGIN
			  SELECT @Duration = TimeStep
			  FROM #BatchStep
			  WHERE CompartmentNo = @CompartmentNo;
			  SELECT @StepEnd = DATEADD(ss, @Duration, @StepStart);
			  IF(@CompartmentNo = @CurrentStep)
				 SELECT @StepEnd = NULL;
			  UPDATE BWS
			    SET
				   StartTime = @StepStart,
				   EndTime = @StepEnd
			  FROM TCD.BatchWashStepData BWS
			  WHERE BatchId = @BatchID
				   AND StepCompartment = @CompartmentNo;
			  SELECT @RowCount = @@RowCount;
			  IF(@RowCount = 0)
				 BEGIN
					INSERT INTO TCD.BatchWashStepData
					(BatchId,
					 StepCompartment,
					 StartTime,
					 EndTime,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @BatchID,
							    @CompartmentNo,
							    @StepStart,
							    @StepEnd,
							    @PartitionOn,
							    @EcolabWasherId;
				 END; --IF (@RowCount = 0)
			  SELECT @CompartmentNo = @CompartmentNo + 1;
			  SELECT @StepStart = @StepEnd;
		   END; --WHILE (@CompartmentNo <=@LaspStep)
	    DROP TABLE #BatchStep;
	END;

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetWasherBatchTrendingData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetWasherBatchTrendingData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [TCD].[GetWasherBatchTrendingData](
	@DashBoardId         INT           = NULL,
	@EcolabAccountNumber NVARCHAR(25) = NULL,
	@StartTimeHrs        DATETIME      = NULL,
	@EndTimeHrs          DATETIME      = NULL)
AS
	BEGIN
	    SET NOCOUNT ON;              --SQLEnlight SA0017

	    SET @EcolabAccountNumber = ISNULL(@EcolabAccountNumber, NULL);   --SQLEnlight SA0029

	    SELECT DISTINCT
			 MS.GroupId,
			 MS.WasherID,
			 BD.BatchId,
			 Bd.ProgramMasterId,
			 PM.Name AS ProgramName,
			 DATEDIFF(SECOND, @StartTimeHrs, BD.StartDate) AS StartTime,
			 DATEDIFF(SECOND, @StartTimeHrs, BD.StartDate) + WPS.
			 TotalRunTime AS StandardEndTime,
			 DATEDIFF(SECOND, @StartTimeHrs, BD.EndDate) AS
			 ActualEndTime,
			 --Isnull(W.TargetTurnTime,10)* 60 as StandardTurnTime,
			 Isnull(BD.TargetTurnTime, 0) AS StandardTurnTime,
			 CASE
				WHEN BD.EndDate IS NULL
				THEN 1
				ELSE 0
			 END AS RunningStatus,
			 D.Formula AS DisplayFormula,
			 WPS.ProgramNumber,
			 D.DisplayFormulaType
	    FROM [TCD].MonitorSetUpMapping DM
		    INNER JOIN [TCD].MachineSetup MS ON DM.MachineId = MS. WasherID
		    INNER JOIN [TCD].Dashboard D ON DM.DashBoardId = D.DashBoardId
		    INNER JOIN [TCD].BatchData BD ON BD.MachineId = MS.WasherID
		    INNER JOIN [TCD].ProgramMaster PM ON PM.ProgramId = BD.ProgramMasterId
		    INNER JOIN [TCD].WasherProgramSetup WPS ON WPS.ProgramNumber = BD.ProgramNumber
											  AND  (WPS.ControllerID = MS.ControllerId 
											 OR WPS.WasherGroupId = MS.GroupId)
		    LEFT OUTER JOIN [TCD].Washer W ON W.WasherId = MS.WasherID
	    WHERE DM.DashboardId = @DashBoardId
			AND ((BD.StartDate >= DATEADD(HOUR, -1, @StartTimeHrs)
				 OR DATEADD(HOUR, -1, @StartTimeHrs) BETWEEN BD.StartDate AND BD.EndDate)
				OR (BD.EndDate IS NULL))
			AND WPS.Is_Deleted = 0
	    ORDER BY MS.WasherId,
			   BD.BatchId;
	END;

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessConventionalOnlineDataForPLCXL]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessConventionalOnlineDataForPLCXL]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Create PROCEDURE [TCD].[ProcessConventionalOnlineDataForPLCXL](
	@ControllerID   INT,
	@VxML           XML,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @MachineNumber     INT,
			  @StepNumber        INT,
			  @StartDateTime     DATETIME,
			  @EndDateTime       DATETIME,
			  @ProgramNumber     INT,
			  @Load              DECIMAL(10, 2),
			  @NominalLoad       DECIMAL(10, 2),
			  @CustomerNumber    INT,
			  @WaterConsumption1 INT,
			  @WaterConsumption2 INT,
			  @PHStatus          INT,
			  @PHValue           INT,
			  @TemperatureMin    INT,
			  @TemperatureMax    INT,
			  @TempMinStatus     INT,
			  @TempMaxStatus     INT,
			  @BatchNumber       INT,
			  @WasherID          INT,
			  @WasherGroupID     INT,
			  @EcoLabWasherID    INT,
			  @ProgramMasterID   INT,
			  @PlantWasherNumber INT,
			  @ShiftID           INT,
			  @ParameterID       INT,
			  @BatchID           INT,
			  @ShiftStartdate    DATETIME,
			  @ShiftName         NVARCHAR(50),
			  @XMLDataID         INT,
			  @LastProgramID     INT,
			  @StdInjectionSteps INT,
			  @StdWashSteps      INT,
			  @ActualInjSteps    INT,
			  @CurrencyCode         VARCHAR(50),
			  @PartitionOn          DATETIME2,
			  @TargetTurnTime    SMALLINT

	    PRINT 'Start Date Time --'+CONVERT(NVARCHAR(MAX), GETDATE(), 121);	    
	    SELECT @XMLDataID = SCOPE_IDENTITY();
	    SELECT @MachineNumber = T.c.value('@MachineNumber', 'INT'),
			 @StepNumber = T.c.value('@StepNumber', 'INT'),
			 @StartDateTime = T.c.value('@StartDateTime', 'DATETIME'),
			 --@EndDateTime = T.c.value('@EndDateTime', 'DATETIME'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'decimal(10,2)'),
			 @NominalLoad = T.c.value('@NominalLoad', 'decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'INT'),
			 @WaterConsumption1 = T.c.value('@WaterConsumption1', 'INT'),
			 @WaterConsumption2 = T.c.value('@WaterConsumption2', 'INT'),
			 @PHStatus = T.c.value('@PHStatus', 'INT'),
			 @PHValue = T.c.value('@PHValue', 'INT'),
			 @TemperatureMin = T.c.value('@TemperatureMin', 'INT'),
			 @TemperatureMax = T.c.value('@TemperatureMax', 'INT'),
			 @TempMaxStatus = T.c.value('@TemperatureMaxStatus', 'INT'),
			 @TempMinStatus = T.c.value('@TemperatreMinStatus', 'INT'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT')
	    FROM @VxML.nodes('ConventionalWasherData') T(C);
	    PRINT '*********************************'+CONVERT(NVARCHAR(10),
	    @CustomerNumber);
	    PRINT '@CustomerNumber :'+CONVERT(NVARCHAR(10), @CustomerNumber);
	    DECLARE @ShiftMapping1 TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    INSERT INTO @ShiftMapping1
	    (ShiftId,
		ShiftName,
		ShiftStartdate
	    )
	    EXEC TCD.GetShiftStartDate @StartDateTime, 1, @RedFlagShiftId OUTPUT;

	    SELECT @ShiftID = ShiftID, @ShiftStartdate = ShiftStartdate, @ShiftName = ShiftName, @PartitionOn = ShiftStartdate
	    FROM @ShiftMapping1;

	    SELECT @WasherGroupID = GroupId,
		       @WasherID = WasherID
	    FROM TCD.MachineSetup ms
	    WHERE ControllerID = @ControllerID
			AND MachineInternalId = @MachineNumber
			AND IsTunnel = 0;
	    IF(@EndDateTime = '1/1/1900')
		   SELECT @EndDateTime = NULL;
	    IF(@StartDateTime = '1/1/1900')
		   SELECT @StartDateTime = NULL;
		   IF(@WasherId IS NOT NULL)
		   BEGIN
			  SELECT @ProgramMasterId = Wps.ProgramId
			  FROM  TCD.WasherProgramSetup Wps where Wps.WasherGroupId = @WasherGroupID AND Wps.Is_Deleted = 0;

			  SELECT @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber,
				    @CurrencyCode = P.CurrencyCode,
				    @TargetTurnTime = w.TargetTurnTime * 60
			  FROM TCD.Washer w
				  INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.EcolabAccountNumber
			  WHERE w.WasherId = @WasherID;
		   END;
	    SELECT @BatchID = BatchID
	    FROM TCD.BatchData
	    WHERE MachineInternalID = @MachineNumber
			--AND StartDate = @StartDateTime
			AND CAST(StartDate AS DATE) = CAST(@StartDateTime AS DATE)
			AND ControllerBatchId = @BatchNumber
			AND MachineID = @WasherID;
	    --Start Getting InjectionCount and StepCount
	    SELECT @StdInjectionSteps = COUNT(DISTINCT wdpm.WasherDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) -
			 COUNT(DISTINCT wdpm.WasherDosingSetupId)
	    FROM TCD.WasherDosingProductMapping wdpm
		    RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm.WasherDosingSetupId = wds.WasherDosingSetupId
	    WHERE wds.GroupId = @WasherGroupID
			AND wds.ProgramNumber = @ProgramNumber;

	    --End Getting InjectionCount and StepCount
	    IF(@BatchID IS NULL)
		   BEGIN

		   UPDATE TCD.BatchData SET  EndDate = DATEADD(ss, -10, @StartDateTime)
			  WHERE MachineInternalID = @MachineNumber
				   AND StartDate <> @StartDateTime
				   AND EndDate IS NULL
				   AND ControllerBatchId <> @BatchNumber
				   AND MachineId = @WasherId;

			  INSERT INTO TCD.BatchData
			  (ControllerBatchID,
			   EcolabWasherId,
			   GroupId,
			   MachineInternalId,
			   PlantWasherNumber,
			   StartDate,
			   EndDate,
			   ProgramNumber,
			   ProgramMasterId,
			   MachineID,
			   ActualWeight,
			   StandardWeight,
			   CurrencyCode,
			   ShiftId,
			   PartitionOn,
			   StdInjectionSteps,
			   StdWashSteps,
			   TargetTurnTime
			  )
			  VALUES
			  (
				    @BatchNumber,
				    @EcoLabWasherID,
				    @WasherGroupID,
				    @MachineNumber,
				    @PlantWasherNumber,
				    @StartDateTime,
				    @EndDateTime,
				    @ProgramNumber,
				    @ProgramMasterId,
				    @WasherID,
				    @Load,
				    @NominalLoad,
					@CurrencyCode,
					@ShiftID,
					@PartitionOn,
				    @StdInjectionSteps,
				    @StdWashSteps,
					@TargetTurnTime
			  );
			  SELECT @BatchID = SCOPE_IDENTITY();
			  INSERT INTO TCD.BatchParameters
			  (BatchId,
			   EcolabWasherId,
			   ParameterId,
			   ParameterValue,
			   PartitionOn
			  )
				    SELECT @BatchID,
						 @EcoLabWasherID,
						 38,
						 @StdWashSteps,
						 @ShiftStartdate;
			
				   INSERT INTO TCD.WasherReading
					(WasherID,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 EcoLabWasherID,
					 Partitionon
					)
					VALUES
					(
						  @WasherID,
						  @ParameterID,
						  @ProgramNumber,
						  --GETDATE(),
						  @StartDateTime,
						  @EcoLabWasherID,
						  @ShiftStartdate
					);

		   END;
	  
	    IF NOT EXISTS
	    (
		   SELECT 1
		   FROM [TCD].[BatchCustomerData]
		   WHERE BatchID = @BatchId
			    AND @CustomerNumber IS NOT NULL
	    )
		   BEGIN
			  PRINT 'INSERT [BatchCustomerData]';
			  INSERT INTO [TCD].[BatchCustomerData]
			  ([BatchId],
			   CustomerID,
			   [Weight],
			   PartitionOn,
			   EcolabWasherId
			  )
			  VALUES
			  (
				    @BatchID,
				    @CustomerNumber,
				    @Load,
				    @ShiftStartdate,
				    @EcolabWasherID
			  );
		   END;
	    ELSE
	    IF(@CustomerNumber > 0)
		   BEGIN
			  PRINT 'UPDATE [BatchCustomerData]';
			  UPDATE [TCD].[BatchCustomerData]
			    SET
				   CustomerID = @CustomerNumber,
				   [Weight] = @Load
			  WHERE BatchID = @BatchId;
		   END;
	    EXEC TCD.AddSensorData
		    @ControllerID,
		    @WasherID,
		    @WasherGroupID,
		    1,
		    @TemperatureMax;
	    EXEC TCD.AddSensorData
		    @ControllerID,
		    @WasherID,
		    @WasherGroupID,
		    2,
		    @PHValue;
	    EXEC TCD.AddMeterReading
		    @ControllerID,
		    @WasherID,
		    2,
		    @WaterConsumption1;
	    CREATE TABLE #Dosing
	    (
		    equipmentNo INT,
		    StepNo      INT,
		    Qty         DECIMAL(18, 4)
	    );
	    INSERT INTO #Dosing
			 SELECT T.c.value('@Equipment', 'INT'),
				   T.c.value('@stepNo', 'INT'),
				   T.c.value('@Qty', 'decimal(18,4)')
			 FROM @VxML.nodes(
			 'ConventionalWasherData/DosingData/Dosing'
						  ) T(C);
	    --Start Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
	    SELECT @ActualInjSteps = COUNT(DISTINCT StepNo)
	    FROM #Dosing;
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.BatchParameters
		   WHERE ParameterId = 37
			    AND batchid = @BatchId
			    AND @ActualInjSteps > 0
	    )
		   BEGIN
			  INSERT INTO TCD.BatchParameters
			  (BatchId,
			   EcolabWasherId,
			   ParameterId,
			   ParameterValue,
			   PartitionOn
			  )
				    SELECT @BatchId,
						 @EcolabWasherID,
						 37,
						 @ActualInjSteps,
						 @ShiftStartDate;
		   END;
	    ELSE
		   BEGIN
			  UPDATE TCD.BatchParameters
			    SET
				   ParameterValue = @ActualInjSteps
			  WHERE ParameterId = 37
				   AND batchid = @BatchID;
		   END;     
	    --END Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
	    INSERT INTO [TCD].[WasherProductReading]
			(ControllerId,
			WasherId,
			MachineInternalId,
			ProductId,
			TheoreticalQty,
			RealQty,
			DosingPoint,
			DosingNumber,
			ProgramNumber,
			BatchNumber,
			ValveNumber,
			DateTimeStamp
	    )
			 SELECT @ControllerID,
				   @WasherID,
				   @MachineNumber,
				   CE.ProductID,
				   NULL,
				   dosing.Qty,
				   equipmentNo,
				   equipmentNo,
				   @ProgramNumber,
				   @BatchNumber,
				   NULL,
				   GETDATE()
			 FROM #Dosing dosing
				 INNER JOIN TCD.ControllerEquipmentSetup CE ON dosing.
				 equipmentNo = CE.ControllerEquipmentId
													  AND CE.
													  controllerID = @ControllerID
													  AND CE.
													  ProductID IS NOT NULL;
	END;

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMitsubishiAccessSaveData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMitsubishiAccessSaveData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


Create PROCEDURE [TCD].[ProcessMitsubishiAccessSaveData](
	@ControllerID INT,
	@xmlTags      XML)
AS
	BEGIN
	    DECLARE @BatchID              INT,
			  @WasherID             INT,
			  @EcolabWasherId       INT,
			  @CurrencyCode         VARCHAR(50),
			  @MachineInternalId    INT,
			  @WasherGroupID        INT,
			  @PlantWasherNumber    INT,
			  @BatchStartTime       DATETIME2,
			  @BatchEndTime         DATETIME2,
			  @ProgramNumber        INT,
			  @Load                 DECIMAL(10, 2),
			  @NominalLoad          DECIMAL(10, 2),
			  @CustomerNumber       INT,
			  @BatchCounter         INT,
			  @IsTunnel             INT,
			  @BatchShiftId         INT,
			  @PartitionOn          DATETIME2,
			  @ShiftName            VARCHAR(50),
			  @ProgramMasterId      INT,
			  @NumberOfCompartments INT,
			  @TargetTurnTime       INT,
			  @EcolabAccountNumber  NVARCHAR(1000) = NULL,
			  @StdInjectionSteps    INT,
			  @StdWashSteps         INT		 

	    SELECT @MachineInternalID = T.c.value('@MachineNumber', 'int'),
			 @BatchCounter = T.c.value('@BatchCounter', 'INT'),
			 @BatchStartTime = T.c.value('@StartDateTime', 'DateTime'),
			 @BatchEndTime = T.c.value('@EndDateTime', 'DateTime'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@NominalLoad', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'int'),
			 @IsTunnel = T.c.value('@IsTunnel', 'int')
	    FROM @xmlTags.nodes('PLCData') T(c);

	    SELECT @EcolabWasherID = EcolabWasherId,
			 @WasherGroupID = Wg.WasherGroupId,
			 @PlantWasherNumber = PlantWasherNumber,
			 @WasherID = ws.WasherId,
			 @CurrencyCode = P.CurrencyCode,
			 @NumberOfCompartments = Mst.NumberofComp
	    FROM TCD.Washer Ws
		    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
		    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
		    INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
		    INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId = Mst.ControllerId
		    INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.EcoLabAccountNumber
	    WHERE Ctrl.ControllerID = @ControllerID
			AND mst.MachineInternalId = @MachineInternalID
			AND mst.IsTunnel = @IsTunnel;			

	    IF(@IsTunnel = 1)
		   BEGIN
			  SELECT @ProgramMasterId = ProgramId,
				    @TargetTurnTime = (3600 / (tps.TotalRunTime /@NumberOfCompartments))
			  FROM TCD.TunnelProgramSetup AS tps
			  WHERE tps.WasherGroupId = @WasherGroupID
				   AND tps.is_deleted = 0
				   AND ProgramNumber = @ProgramNumber;
		   END;
	    ELSE
		   BEGIN
			  SELECT DISTINCT
				   @ProgramMasterId = Wps.ProgramId
			  FROM TCD.Washer Ws
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
				  INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wps.Is_Deleted = 0;

				   SELECT @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber,
				    @CurrencyCode = P.CurrencyCode,
				    @TargetTurnTime = w.TargetTurnTime * 60
			  FROM TCD.Washer w
				  INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.EcolabAccountNumber
			  WHERE w.WasherId = @WasherID;
		   END;

	    SET @BatchID = NULL;

	    SELECT @BatchID = BatchID
	    FROM TCD.BatchData BD
	    WHERE BD.ControllerBatchId = @BatchCounter
			--AND BD.StartDate= @BatchStartTime
			AND BD.MachineId = @WasherID
			AND CAST(StartDate AS DATE) = CAST(@BatchStartTime AS DATE)
	    ;

	    --Start Getting InjectionCount and StepCount
	    SELECT @StdInjectionSteps = COUNT(DISTINCT wdpm. WasherDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) - COUNT(DISTINCT wdpm.WasherDosingSetupId)
	    FROM TCD.WasherDosingProductMapping wdpm
		    RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm.
		    WasherDosingSetupId = wds.WasherDosingSetupId
	    WHERE wds.GroupId = @WasherGroupID
			AND wds.ProgramNumber = @ProgramNumber;

	    --End Getting InjectionCount and StepCount
	    IF(@BatchID IS NULL)
		   BEGIN
			  DECLARE @ShiftStartDate TABLE
			  (
				  ShiftId        INT,
				  ShiftName      NVARCHAR(50),
				  ShiftStartdate DATETIME
			  );

			  INSERT INTO @ShiftStartDate
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )

			  EXEC TCD.GetShiftStartDate  @BatchStartTime,0,1;

			  SELECT @BatchShiftId = ShiftID,
				    @PartitionOn = ShiftStartdate,
				    @ShiftName = ShiftName
			  FROM @ShiftStartDate;
			  
			  IF(@IsTunnel = 0)
				 BEGIN
					--SET @BatchEndTime = DATEADD(mi, 10,
					--@BatchStartTime);
					 UPDATE TCD.BatchData SET  EndDate = DATEADD(ss, -10, @BatchStartTime)
						WHERE MachineInternalID = @MachineInternalID
						AND StartDate <> @BatchStartTime
						AND EndDate IS NULL
						AND ControllerBatchId <> @BatchCounter
						AND MachineId = @WasherId;
				 END;
				 
			  INSERT INTO TCD.BatchData
				  (ControllerBatchId,
				   EcolabWasherId,
				   GroupId,
				   MachineInternalId,
				   PlantWasherNumber,
				   StartDate,
				   EndDate,
				   ProgramNumber,
				   ProgramMasterId,
				   MachineId,
				   ActualWeight,
				   StandardWeight,
				   CurrencyCode,
				   ShiftId,
				   PartitionOn,
				   StdInjectionSteps,
				   StdWashSteps,
				   TargetTurnTime
			       )
				    SELECT @BatchCounter,
						 @EcolabWasherID,
						 @WasherGroupID,
						 @MachineInternalID,
						 @PlantWasherNumber,
						 @BatchStartTime,
						 @BatchEndTime,
						 @ProgramNumber,
						 @ProgramMasterId,
						 @WasherID,
						 @Load,
						 @NominalLoad,
						 @CurrencyCode,
						 @BatchShiftId,
						 @PartitionOn,
						 @StdInjectionSteps,
						 @StdWashSteps,
						 @TargetTurnTime

			  SELECT @BatchID = SCOPE_IDENTITY();

			  IF(@CustomerNumber IS NOT NULL)
				 BEGIN
					INSERT INTO [TCD].[BatchCustomerData]
					([BatchId],
					 CustomerID,
					 [Weight],
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @BatchID,
							    @CustomerNumber,
							    @Load,
							    @PartitionOn,
							    @EcolabWasherId;
				 END;
		   END;
	    ELSE
		   BEGIN
			  IF(@IsTunnel = 1)
				 BEGIN
					UPDATE TCD.BatchData
					  SET
						 StartDate = @BatchStartTime,
						 StandardWeight = @NominalLoad
					WHERE ControllerBatchId = @BatchCounter
						 AND MachineId = @WasherID
						 AND CAST(StartDate AS DATE) = CAST(@BatchStartTime AS DATE);
				 END;
		   END;
	END;

GO
----------------------------------------------- User Story - 139521 -----start----------------------------------------------------------------------------

GO
IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'IsETechEnable' AND Object_ID = Object_ID(N'[TCD].[plant]'))
BEGIN
	ALTER TABLE TCD.Plant ADD IsETechEnable bit NOT NULL CONSTRAINT DF_Plant_IsETechEnable DEFAULT(0) 
END
Go
IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'ETechIpAddress' AND Object_ID = Object_ID(N'[TCD].[plant]'))
BEGIN
	ALTER TABLE TCD.plant ADD [ETechIpAddress] varchar(100) NULL 
END

GO
IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'ETechTimeDiff' AND Object_ID = Object_ID(N'[TCD].[plant]'))
BEGIN
	ALTER TABLE TCD.plant ADD [ETechTimeDiff] int NULL 
END
GO
--ETechlastDroppedTimeStamp
IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'ETechlastDroppedTimeStamp' AND Object_ID = Object_ID(N'[TCD].[BatchData]'))
BEGIN
	ALTER TABLE TCD.BatchData ADD [ETechlastDroppedTimeStamp] Datetime2 NULL 
END
GO
--ETechWasherNumber
IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'ETechWasherNumber' AND Object_ID = Object_ID(N'[TCD].[Washer]'))
BEGIN
	ALTER TABLE TCD.Washer	ADD ETechWasherNumber int NOT NULL CONSTRAINT DF_Plant_ETechWasherNumber DEFAULT(0)
END
GO


---------------------Procs
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetPlantInfo]') AND type in (N'P', N'PC'))
DROP PROCEDURE [TCD].[GetPlantInfo]

GO
CREATE PROCEDURE [TCD].[GetPlantInfo]
AS

BEGIN

SET nocount ON;

SELECT 
p.EcolabAccountNumber,
p.Name,
p.IsETechEnable,
p.ETechIpAddress,
p.ETechTimeDiff
FROM   [TCD].plant P WHERE   Is_Deleted      = 0

SET nocount OFF;
END

GO
--------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetActiveWahsersByControllerId]') AND type in (N'P', N'PC'))
DROP PROCEDURE [TCD].[GetActiveWahsersByControllerId]

GO
CREATE PROCEDURE [TCD].[GetActiveWahsersByControllerId]
( 
  @ControllerId INT
)

AS
SET NOCOUNT ON
BEGIN
  SELECT 
    Wt.WasherTagId as TagId,
    Wt.TagAddress,
    Tt.TagType,
    Tt.TagTypeId,
    Tt.TagDescription,
    Wt.WasherId,
    Wg.WasherGroupName,
    WgT.WasherGroupTypeName,
    Ms.MachineName as WasherName,
    Ctrl.TopicName,
    CAST(Ws.EndOfFormula AS INT) AS EndOfFormula,
    Ws.AWEActive,
    Ws.RatioDosingActive,
	Ws.ETechWasherNumber
  FROM TCD.MachineSetup  Ms 
  INNER JOIN
    TCD.Washer Ws 
    ON Ws.WasherId     =   Ms.WasherId 
  INNER JOIN 
    TCD.WasherTags Wt 
    ON Wt.washerID     =   Ws.washerId and Wt.Active=1
  INNER JOIN
    TCD.TagType Tt 
    ON Tt.TagType     =   Wt.Tagtype and Tt.Active=1
  INNER JOIN 
    TCD.ConduitController Ctrl 
    ON Ctrl.ControllerId   =   Ms.ControllerId and Ctrl.Active=1
  INNER JOIN 
    TCD.Plant Pl 
    ON Pl.EcolabAccountNumber  =   Ctrl.EcoalabAccountNumber 
  INNER JOIN 
    TCD.WasherGroup Wg 
    on Wg.WasherGroupId    =   Ms.GroupId 
  INNER JOIN 
    TCD.WasherGroupType WgT 
    ON WgT.WasherGroupTypeId  =   Wg.WasherGroupTypeId 

  WHERE Ctrl.ControllerId    =   @ControllerId
  AND  Ctrl.Active      =   1 
  AND  Ctrl.IsDeleted    =   0
  ORDER BY Ws.washerId ASC

  
 END

 --------------------------------------------
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessConventionalWasherData]') AND type in (N'P', N'PC'))
DROP PROCEDURE [TCD].[ProcessConventionalWasherData]

GO
CREATE PROCEDURE [TCD].[ProcessConventionalWasherData]
( 
 @WasherId INT, 
 @xmlTags XML,
 @RedFlagShiftId INT OUTPUT
)

AS
BEGIN
  DECLARE @BatchID        INT,
    @EcolabWasherId       INT,        
    @CurrencyCode       VARCHAR(50),  
    @MachineInternalId      INT,
    @GroupId        INT,  
    @Prveformula       INT,
    @Quantity        INT,
    @MaxWashertGroupCapacity    INT,

    @ProgramMasterId      INT,
    @NominalLoad       DECIMAL(10,2),
    @MaxLoad        DECIMAL(10,2),
    @StandardWeight       DECIMAL(10,2) ,     

    @CurrentFormula       INT,  
    @CurrentFormulaDate      DATETIME2,
    @FormulaIsModified      BIT,

    @CurrentInjection      INT,
    @CurrentInjectionDate     DATETIME2,
    @InjectionIsModified     BIT,

    @OperationalCount      INT,
    @OperationalIsModified     BIT, 
    
    @CurrentHoldSignal      INT,
    @CurrentHoldSignalDate     DATETIME2,
    @HoldSignalIsModified     BIT,  
             
    @EndofFormula       INT, 
    @EndofFormulaDate      DATETIME2,
    
    @AutoWeightEntryActive     BIT,
    @AutoWeightEntryWeight     DECIMAL(10,2),                                                                                                                              
    @ControllerId       INT,
    @CurrentHoldSignalValue     INT ,
    
    @MeterPlcAddress      INT,
    @MeterPlcAddressIsModified    INT,
    @BatchGroupId       INT,
    @BatchFormula       INT,    
    @HoldTime        INT,
    @CteTempBatchInjections     INT,
    @CteTempWaherReadingInjections   INT,
    @BatchStandardWaterUsage    INT,
    @BatchActualWaterUsage     INT,
    @BatchWaterUsagePrice     Decimal(10,2),
    @BatchUtilityPrice      Decimal(10,2),
    @BatchWaterType       INT,
    @PrevGroupId       INT,
    @WasherMeterExists      BIT,
    @ExtraTime        INT,
    @TargetTurnTime       INT,
    @RatioDosingEnabled      BIT,
	@EcolabAccountNumber NVARCHAR(25) = NULL,
	@PreviousFormulaDate      DATETIME2,
    @PreviousInjectionStep INT,
	@PreviousInjectionStartDate DATETIME2,
	@CurrentInjectionStep INT,
	@WashStepBatchId INT,
	@PrevFormulaExtraTime INT      ,
	@AlarmGroupMasterId INT,
	@StdWashSteps INT,
    @StdInjectionSteps INT,
	@EcolabTextileCategoryId INT,
	@ChainTextileCategoryId INT,
	@FormulaSegmentId INT,
	@EcolabSaturationId INT,
	@PlantProgramId INT,
	@ETechLastDroppedAt  DATETIME2                                                                                                             

  SELECT @ETechLastDroppedAt = NULL 
  IF EXISTS (SELECT  * FROM [TEMPDB].[DBO].[SYSOBJECTS] o where o.xtype in ('U') AND o.id = OBJECT_ID(N'tempdb..#XmlTagsTable'))
   BEGIN
     DROP TABLE #XmlTagsTable
   END


  CREATE TABLE  #XmlTagsTable ( TagId INT, 
          TagValue NVARCHAR(100), 
          ReceivedTime DATETIME2,
          TagType NVARCHAR(50),
          IsModified BIT,
		  ETechLastDropped VARCHAR(100)
         )

 
  INSERT INTO #XmlTagsTable (
          TagId,
          TagValue,
          ReceivedTime,
          TagType,
          IsModified,
		  ETechLastDropped
         )   
  
  SELECT   
     T.c.value('@TagId', 'INT') as TagId,
     T.c.value('@Value', 'NVARCHAR(100)') TagValue,
     T.c.value('@TimeStamp', 'VARCHAR(100)') DateTimeStamp,
     T.c.value('@TagType', 'VARCHAR(50)') TagType,
     T.c.value('@IsModified', 'BIT') TagType,
	 T.c.value('@ETechLastDroppedAt', 'VARCHAR(100)') ETechLastDropped
  FROM  @xmlTags.nodes('Tags/Tag') T(c)
  WHERE 
     T.c.value('@TagId', 'varchar(100)')  IS NOT NULL
 
  SELECT @CurrentFormula     =  TagValue,  
    @CurrentFormulaDate    =  ReceivedTime,
    @FormulaIsModified     =  IsModified
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_FRM'   
     
  SELECT @CurrentInjection    =  TagValue,
    @CurrentInjectionDate   =  ReceivedTime,
    @InjectionIsModified   =  IsModified   
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_INJ'

  SELECT @OperationalCount    =  TagValue,
    @OperationalIsModified   =  IsModified  
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_OPC'  
   
  SELECT @EndofFormula     =  TagValue,
    @EndofFormulaDate    =  ReceivedTime  
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_EOF' 
  
  SELECT @AutoWeightEntryActive   =  TagValue     
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_AWEA'                 

  SELECT @CurrentHoldSignal    =  TagValue, 
    @HoldSignalIsModified   =  IsModified,  
    @CurrentHoldSignalDate   =  ReceivedTime 
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_HOLDL'

  SELECT @AutoWeightEntryWeight   =  TagValue,
  @ETechLastDroppedAt    =  CONVERT(datetime,ETechLastDropped)   
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_AWEW'

  SELECT @MeterPlcAddress    =  TagValue,
    @MeterPlcAddressIsModified  =       IsModified       
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_MPLC'
  
  SELECT @RatioDosingEnabled    =  TagValue      
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_RATA'
  
  SELECT * FROM #XmlTagsTable
  
  SELECT @ExtraTime      =  0
 
  SELECT TOP 1 @BatchID=BatchId, @Prveformula=ProgramNumber,@PrevGroupId=GroupId, @PreviousFormulaDate=StartDate FROM TCD.BatchData WHERE MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC

  IF(@CurrentFormula != @EndofFormula AND
     @CurrentFormula = @Prveformula AND 
  @CurrentInjection = 0 AND
  @OperationalCount = 0 AND
  @CurrentFormulaDate <= @PreviousFormulaDate AND
  @CurrentInjectionDate > @PreviousFormulaDate)
 BEGIN
 --Here means, If the same formula is received without EOF then the timestamp of the formula
 --will be still the old timestamp because value is not changed.
 --In this case assign injection=0 timestamp to formula timestamp
  SELECT @CurrentFormulaDate = @CurrentInjectionDate 
 END

  DECLARE @ShiftStartDate table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
  INSERT INTO @ShiftStartDate(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate,1, @RedFlagShiftId OUTPUT

  SELECT DISTINCT 
     @EcolabWasherId    =  Ws.EcolabWasherId,
     @StandardWeight    =  Wps.NominalLoad,
     @CurrencyCode    =  Pl.CurrencyCode,
     @ControllerId    =  Ctrl.ControllerId,
     @TargetTurnTime    =  Ws.TargetTurnTime * 60     
  FROM 
     TCD.Washer Ws  
  INNER JOIN 
     TCD.MachineSetup Mst ON
     Mst.WasherId    =  Ws.WasherId
  INNER JOIN 
     TCD.WasherGroup Wg ON 
     Wg.WasherGroupId   =  Mst.GroupId    
  INNER JOIN 
     TCD.WasherProgramSetup Wps ON 
     Wps.WasherGroupId   =  Wg.WasherGroupId
  LEFT JOIN 
     TCD.WasherDosingSetup Wds ON 
     Wds.WasherProgramSetupId =  Wps.WasherProgramSetupId
  LEFT JOIN 
     TCD.WasherDosingProductMapping Wdpm ON 
     Wdpm.WasherDosingSetupId =  Wds.WasherDosingSetupId
  INNER JOIN 
     TCD.Plant Pl ON 
     Pl.EcolabAccountNumber  =  Ws.EcoLabAccountNumber
  INNER JOIN 
    TCD.ConduitController Ctrl 
    ON Ctrl.ControllerId   =  Mst.ControllerId 
  WHERE Ws.WasherId= @WasherId

  SELECT DISTINCT 
     @MachineInternalId=Mst.MachineInternalId,
     @GroupId=Mst.GroupId     
  FROM TCD.Washer Ws
      INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
      INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
      INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
   WHERE Ws.WasherId=@WasherId  

   SELECT DISTINCT      
     @ProgramMasterId=Wps.ProgramId,
     @NominalLoad=Wps.NominalLoad, --Wps.NominalLoad/CONVERT(decimal(10,2), 100) old code
     @MaxLoad =Ws.MaxLoad,
     @ExtraTime =Wps.ExtraTime
  FROM TCD.Washer Ws
      INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
      INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
      INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
      INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
   WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@CurrentFormula and Wps.Is_Deleted=0

  if(@ExtraTime IS NULL)
  BEGIN
   SELECT @ExtraTime      =  0
  END

  SELECT  @MaxWashertGroupCapacity=Max(ws.MaxLoad)
  FROM TCD.Washer WS
   INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
   INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId  
  WHERE Mst.GroupId=@GroupId

  SELECT @WasherMeterExists = M.MachineCompartment FROM Tcd.MachineSetup Ms
  INNER JOIN Tcd.Meter M ON M.GroupId= Ms.GroupId AND  M.MachineCompartment=Ms.MachineInternalId
  WHERE Ms.WasherId=@WasherId

  if(@AutoWeightEntryActive IS NULL)
  BEGIN
   SELECT @AutoWeightEntryActive = 0
  END

  SELECT @StandardWeight=(@NominalLoad * @MaxWashertGroupCapacity) /CONVERT(decimal(10,2), 100)   
  select @AutoWeightEntryActive,@StandardWeight
  SELECT @AutoWeightEntryWeight=Case @AutoWeightEntryActive WHEN 0 THEN @StandardWeight ELSE  @AutoWeightEntryWeight END  
  
  SELECT @CurrentHoldSignalValue=Id  FROM TCD.ConduitParameters where Name='HoldSignal'
  
   SELECT  * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC
  IF(@HoldSignalIsModified !=0)  
  BEGIN
  IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp =@CurrentHoldSignalDate)
   BEGIN
    INSERT INTO TCD.WasherReading(
         WasherId,
         ParameterId,
         ParameterValue,
         DateTimeStamp,
         PartitionOn,
         EcolabWasherId)
    SELECT    @WasherId,
         @CurrentHoldSignalValue,
         @CurrentHoldSignal,
         @CurrentHoldSignalDate,
         (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
         @EcolabWasherId
   END   
  END
  IF(@FormulaIsModified =1  OR @InjectionIsModified = 1 OR @OperationalIsModified = 1)
  BEGIN
   SELECT 'IsModified',@FormulaIsModified AS FormulaIsModified, 
        @InjectionIsModified AS InjectionIsModified,
        @OperationalIsModified AS OperationalIsModified
   IF(@CurrentFormula != 0)
   BEGIN
       DECLARE @BatchShiftId int,@BatchShiftStartDate datetime
       
       SELECT @BatchShiftStartDate = bd.StartDate FROM TCD.BatchData bd WHERE bd.BatchId = @BatchId

       IF(@BatchShiftStartDate > (SELECT TOP 1 [@ShiftStartDate].ShiftStartdate FROM @ShiftStartDate ORDER BY [@ShiftStartDate].ShiftStartdate ASC)
       AND DATEADD(second,@ExtraTime,@CurrentFormulaDate) > (SELECT TOP 1 [@ShiftStartDate].ShiftStartdate FROM @ShiftStartDate ORDER BY [@ShiftStartDate].ShiftStartdate DESC)
       )
       BEGIN 
         
         SELECT TOP 1  @BatchShiftId = ssdt.ShiftId FROM @ShiftStartDate ssdt ORDER BY ssdt.ShiftStartdate DESC
       END
       ELSE
       BEGIN
        SELECT TOP 1  @BatchShiftId = ssdt.ShiftId FROM @ShiftStartDate ssdt ORDER BY ssdt.ShiftStartdate ASC
       END
       

  SELECT DISTINCT      
   @PrevFormulaExtraTime =Wps.ExtraTime
   FROM TCD.Washer Ws
    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
    INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
    INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
    WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@Prveformula and Wps.Is_Deleted=0

  IF(@PrevFormulaExtraTime IS NULL)
  BEGIN
   SELECT @PrevFormulaExtraTime      =  0
  END

     IF(@CurrentFormula = @EndofFormula)
     BEGIN   
     SELECT * FROM #XmlTagsTable
      IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData 
           WHERE 
           BatchId=@BatchId AND 
           MachineId=@WasherId AND 
           EndDate IS NULL 
           ORDER BY StartDate DESC  )
       BEGIN
                                       
        UPDATE TCD.BatchData 
         SET EndDate = DATEADD(second,@PrevFormulaExtraTime,@CurrentFormulaDate),EndDateFormula = @CurrentFormulaDate,ShiftId = @BatchShiftId 
       WHERE  BatchId = @BatchId AND MachineId=@WasherId   
    
    DECLARE @ShiftMapping1 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
    INSERT INTO @ShiftMapping1(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate,1, @RedFlagShiftId OUTPUT

    SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
      IF(@PreviousInjectionStep IS NOT NULL)
      BEGIN
       UPDATE TCD.BatchWashStepData SET EndTime=DATEADD(second,@ExtraTime,@CurrentFormulaDate) WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate
      END
                                                                   
       END 
     END 
     ELSE IF((@CurrentFormula != @Prveformula) AND (@BatchID IS NOT NULL))
     BEGIN  
     IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC  )
        BEGIN                          
         UPDATE TCD.BatchData
          SET EndDate = @CurrentFormulaDate,EndDateFormula = @CurrentFormulaDate,ShiftId = @BatchShiftId 
         WHERE  BatchId = @BatchId AND MachineId=@WasherId  
   
     INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,19,1,(SELECT Top 1 ShiftStartdate from @ShiftStartDate) 
     
     DECLARE @ShiftMapping2 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
   INSERT INTO @ShiftMapping2(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate,1, @RedFlagShiftId OUTPUT
    
    SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
     IF(@PreviousInjectionStep IS NOT NULL)
     BEGIN
      UPDATE TCD.BatchWashStepData SET EndTime=@CurrentFormulaDate WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate
     END
       
        END 
      END
     ELSE IF((@CurrentInjection = 0) AND(@OperationalCount = 0) AND (@CurrentFormulaDate != @PreviousFormulaDate))
     BEGIN  
     IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC)
        BEGIN                           
         UPDATE TCD.BatchData
          SET EndDate = @CurrentInjectionDate,ShiftId = @BatchShiftId,EndDateFormula = @CurrentInjectionDate
         WHERE  BatchId = @BatchId AND MachineId=@WasherId  
   
    INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,19,1,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)

    DECLARE @ShiftMapping3 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
   INSERT INTO @ShiftMapping3(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentInjectionDate,1, @RedFlagShiftId OUTPUT
      
   SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
     IF(@PreviousInjectionStep IS NOT NULL)
     BEGIN
      UPDATE TCD.BatchWashStepData SET EndTime=@CurrentInjectionDate WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate
     END

        END 
      END
   
    -- Hold Time
     IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
      BEGIN

      
      SELECT   @HoldTime=SUM(Wr.ParameterValue) FROM TCD. BatchData Bd
      INNER JOIN TCD.WasherReading Wr ON Wr.WasherId=Bd.MachineId
      WHERE Bd.BatchId=@BatchId  AND Wr.DateTimeStamp BETWEEN Bd.StartDate AND  Bd.EndDate and   Wr.ParameterId=9 -- Hold Signal value

      INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,17,@HoldTime,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)


     END
     
     -- CapturingMeter Plc Address EndRedaing 
     IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
      BEGIN
      IF(@WasherMeterExists IS NOT NULL AND @MeterPlcAddress > 0)
      BEGIN
       IF(@MeterPlcAddressIsModified !=0)  
       BEGIN
       IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp =@CurrentFormulaDate)
       BEGIN
        INSERT INTO TCD.WasherReading(
         WasherId,
         ParameterId,
         ParameterValue,
         DateTimeStamp,
         PartitionOn,
         EcolabWasherId)
        SELECT 
         @WasherId,
         14, --MeterPlcAddress for EndSReading
         @MeterPlcAddress,
         @CurrentFormulaDate,
         (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
         @EcolabWasherId
       END

      END
      END
     END
         
     --Start Good or Bad Injection in BatchDataTable
     IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
      BEGIN
        ;WITH CteTempWaherReadingInjections  ( 
        InjectionsCount,BatchId,WasherId,ProgramNumber,Injectons
       ) AS  
       (
        SELECT DISTINCT Wr.ParameterValue,
            BD.BatchId,
            Wr.WasherId,
            Bd.ProgramNumber,
            Wr.ParameterValue FROM TCD. BatchData Bd
        INNER JOIN 
          TCD.WasherReading Wr ON Wr.WasherId   =  Bd.MachineId 
        WHERE    
              Wr.ParameterId    =  10    AND 
              Wr.ParameterValue   <>  0    AND 
              Bd.BatchId     =  @BatchID AND WR.DateTimeStamp BETWEEN BD.StartDate AND BD.EndDate) 
        SELECT @CteTempWaherReadingInjections=COUNT(CTE1.InjectionsCount)
        FROM CteTempWaherReadingInjections CTE1 
        INNER JOIN TCD.BatchData Bd ON Bd.BatchId=CTE1.BatchId
        WHERE Bd.BatchId=@BatchId

        ;WITH CteTempBatchInjections ( 
        InjectionsCount,BatchId,WasherId,ProgramNumber,Injectons
       ) AS  
       (
        SELECT  DISTINCT Wdpm.InjectionNumber,
            Bd.BatchId,
            Wps.ProgramNumber,
            Ws.WasherId,Wdpm.
            InjectionNumber
         FROM TCD.Washer WS
          INNER JOIN 
             TCD.MachineSetup Mst ON 
             Mst.WasherId     =  WS.WasherId
          INNER JOIN 
             TCD.WasherGroup Wg ON 
             Wg.WasherGroupId    =  Mst.GroupId       
          INNER JOIN 
             TCD.WasherProgramSetup Wps ON 
             Wps.WasherGroupId    =  Wg.WasherGroupId
          INNER JOIN 
             TCD.WasherDosingSetup Wds ON 
             Wds.WasherProgramSetupId  =  Wps.WasherProgramSetupId
          INNER JOIN 
             TCD.WasherDosingProductMapping Wdpm ON 
             Wdpm.WasherDosingSetupId  =  Wds.WasherDosingSetupID
          INNER JOIN 
             TCD.ProductdataMapping Pdm ON 
             Pdm.ProductId     =  Wdpm.ProductId
          INNER JOIN 
             TCD.BatchData Bd ON 
             Bd.MachineId     =  Ws.WasherId 
          INNER JOIN 
             TCD.WasherReading Wr ON 
             Wr.WasherId      =  Bd.MachineId
        WHERE 
        
             Wps.ProgramNumber    =  @Prveformula  AND 
             Bd.BatchId      =  @BatchID   AND 
             Ws.WasherId      =  @WasherId    )
        SELECT @CteTempBatchInjections=COUNT(CTE2.InjectionsCount)
        FROM CteTempBatchInjections CTE2 
        INNER JOIN TCD.BatchData Bd ON Bd.BatchId=CTE2.BatchId 
        WHERE Bd.BatchId=@BatchID


        Insert Tcd.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchID,@EcolabWasherId,18,
          CASE WHEN @CteTempBatchInjections = @CteTempWaherReadingInjections THEN 1
            WHEN @CteTempBatchInjections != @CteTempWaherReadingInjections THEN 3 END,
            (SELECT Top 1 ShiftStartdate from @ShiftStartDate) 
                           
    END
     --End Good or Bad Injection in BatchDataTable 
     IF(@OperationalCount = 0 AND @CurrentInjection = 0) AND (@CurrentFormula != @EndofFormula)
     BEGIN 
      IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchData WHERE MachineId=@WasherId AND StartDate =@CurrentFormulaDate)
      BEGIN     
       
       --Start Getting InjectionCount and StepCount
       SELECT 
       @StdInjectionSteps=count(DISTINCT wdpm.WasherDosingSetupId),
       @StdWashSteps= count(DISTINCT wds.WasherDosingSetupId)-count(DISTINCT wdpm.WasherDosingSetupId)
       FROM TCD.WasherDosingProductMapping wdpm
       RIGHT JOIN tcd.WasherDosingSetup wds on wdpm.WasherDosingSetupId=wds.WasherDosingSetupId
       WHERE wds.GroupId=@GroupId AND wds.ProgramNumber=@CurrentFormula
       --End Getting InjectionCount and StepCount
       --Start-----ProgramMasterID logic for PlantChainProgram
        SELECT 
        @PlantProgramId=pm.PlantProgramId,
        @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
        @ChainTextileCategoryId = pm.ChainTextileId,
        @FormulaSegmentId = pm.FormulaSegmentId,
        @EcolabSaturationId = pm.EcolabSaturationId 
        FROM TCD.ProgramMaster pm WHERE pm.ProgramId=@ProgramMasterId AND pm.Is_Deleted=0
        IF(@PlantProgramId <> 0  AND @PlantProgramId IS NOT NULL)
         BEGIN
            --Assign value from plantchainprogram table based on plantprogramId
            SELECT
             @EcolabTextileCategoryId = pcp.EcolabTextileCategoryId,
             @ChainTextileCategoryId = pcp.ChainTextileCategoryId,
             @FormulaSegmentId = pcp.FormulaSegmentId,
             @EcolabSaturationId = pcp.EcolabSaturationId
             FROM tcd.PlantChainProgram pcp
             WHERE pcp.PlantProgramId=@PlantProgramId AND pcp.Is_Deleted=0
         END
       --End-----ProgramMasterID logic for PlantChainProgram

       INSERT INTO TCD.BatchData(
          ControllerBatchId ,
          EcolabWasherId,
          GroupId ,
          MachineInternalId,
          PlantWasherNumber,
          StartDate ,
          EndDate ,
          ProgramNumber,
          ProgramMasterId,
          MachineId,
          ActualWeight,
          StandardWeight,
          CurrencyCode,
          ShiftId,         
          PartitionOn,
          TargetTurnTime,
          StdInjectionSteps,
          StdWashSteps,
          EcolabTextileCategoryId,
          ChainTextileCategoryId,
          FormulaSegmentId,
          EcolabSaturationId,
          PlantProgramId,
		  ETechlastDroppedTimeStamp          
          )


         SELECT DISTINCT 0
          ,@EcolabWasherId
          ,@GroupId
          ,@MachineInternalId
          ,Ws.PlantWasherNumber
          ,@CurrentFormulaDate
          ,NULL
          ,@CurrentFormula
          ,@ProgramMasterId
          ,@WasherId
          ,@AutoWeightEntryWeight
          ,@StandardWeight 
          ,@CurrencyCode
          ,(SELECT Top 1 ShiftId from @ShiftStartDate)         
          ,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
          ,@TargetTurnTime
          ,@StdInjectionSteps
          ,@StdWashSteps
          ,@EcolabTextileCategoryId
          ,@ChainTextileCategoryId
          ,@FormulaSegmentId
          ,@EcolabSaturationId
          ,@PlantProgramId
		  ,@ETechLastDroppedAt           

       FROM TCD.Washer Ws
          INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
          INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
          INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
       WHERE Ws.WasherId=@WasherId 
   
       SET @BatchID=SCOPE_IDENTITY() 
         
       INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,38,@StdWashSteps,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)

       --If the received formula is not configured in enVision then create an alarm 
       IF(@ProgramMasterId is NULL)
       BEGIN
       SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant;
       SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.AlarmGroupMsterVsControllerModelType AGMVCMT
       INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
       WHERE AGMVCMT.AlarmCode = 9000
        INSERT INTO [TCD].[AlarmData] 
           (EcoalabAccountNumber,
           AlarmCode,
           BatchId,
           controllerID,
           StartDate,
           GroupId,
           MachineInternalId,
           ProgramId,   
           IsActive,
           EndDate,
           MachineId,
           AlarmGroupMasterId)
           SELECT
            @ECOLABAccountNumber,
            9000,
            @BatchID,
            @ControllerId,
            @CurrentFormulaDate,
            @GroupId,
            @MachineInternalId,
            @CurrentFormula,
            0,
            @CurrentFormulaDate,
            @WasherId,
            @AlarmGroupMasterId
       END

         
         INSERT INTO TCD.BatchCustomerData
         (
         BatchId,
         CustomerId,
         Weight,
         PiecesCount,
         PartitionOn,
         EcolabWasherId
         )
        SELECT Bd.BatchId,  
        --SELECT @BatchID,
         Pc.ID,
         @AutoWeightEntryWeight,
         ROUND(COALESCE((@AutoWeightEntryWeight * Pm.Pieces) / NULLIF(Pm.Weight,0), 0),0),
         (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
         @EcolabWasherId
        
      
       FROM TCD.Washer WS
        INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
        INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId       
        INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
        INNER JOIN TCD.ProgramMaster Pm ON Pm.ProgramId=Wps.ProgramId
        INNER JOIN TCD.PlantCustomer Pc ON Pc.ID=Pm.CustomerId
        INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
       WHERE 
        Ws.WasherId=@WasherId AND 
        Wps.ProgramNumber=@CurrentFormula AND 
        Bd.BatchId=@BatchID  AND 
        Pm.CustomerId != -1 

       IF(@WasherMeterExists IS NOT NULL AND @MeterPlcAddress > 0)
       BEGIN        
        IF(@MeterPlcAddressIsModified !=0)  
        BEGIN
          INSERT INTO TCD.WasherReading(
           WasherId,
           ParameterId,
           ParameterValue,
           DateTimeStamp,
           PartitionOn,
           EcolabWasherId)
          SELECT 
           @WasherId,
           13, --MeterPlcAddress for StartReading
           @MeterPlcAddress,
           @CurrentFormulaDate,
           (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
           @EcolabWasherId
        END
       END 
      END              
     END      
     IF(@BatchID IS NOT NULL)     
     BEGIN
     IF(@CurrentInjection <= 0)
      BEGIN
       SET @CurrentInjectionDate=@CurrentFormulaDate
      END 
      IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp =@CurrentInjectionDate)
      BEGIN      
      INSERT INTO TCD.WasherReading(
          WasherId,
          ParameterId,
          ParameterValue,
          DateTimeStamp,
          PartitionOn,
          EcolabWasherId)
      SELECT   @WasherId,
          CASE TagType 
          WHEN 'Tag_FRM' THEN  5  
          WHEN 'Tag_INJ' THEN  10 
          WHEN 'Tag_OPC' THEN  11 
          END,
          TagValue,          
          @CurrentInjectionDate,
          (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
          @EcolabWasherId
       FROM  #XmlTagsTable 
       WHERE  Tagtype in ('Tag_FRM','Tag_INJ','Tag_OPC')         
     END
     END
    IF(@CurrentInjection > 0)     
     BEGIN
      IF (@RatioDosingEnabled = 1)
       BEGIN
       IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurrentInjectionDate and batchid=@BatchID)
       BEGIN
        INSERT INTO TCD.BatchProductData(BatchId,StepCompartment,ActualQuantity,StandardQuantity,Price,TimeStamp,PartitionOn,EcolabWasherId,ProductId)
        SELECT Bd.BatchId 
        --SELECT @BatchID 
         ,Wds.StepNumber
         ,(((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100)) * (@AutoWeightEntryWeight/@StandardWeight) AS ActualQuantity  
         ,(((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100)) * (@AutoWeightEntryWeight/@StandardWeight) AS StandardQuantity      
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * @MaxWashertGroupCapacity)/CONVERT(decimal(10,2), 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price         
         ,@CurrentInjectionDate
         ,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
         ,@EcolabWasherId
         ,Pdm.ProductID
        FROM TCD.Washer WS
         INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
         INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
         INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
         INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
         INNER JOIN TCD.WasherDosingSetup Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
         INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
         INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Wdpm.ProductId
         INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
        WHERE 
          Ws.WasherId=@WasherId     AND 
          Wps.ProgramNumber=@CurrentFormula  AND 
          Wdpm.InjectionNumber=@CurrentInjection AND
          Bd.BatchId=@BatchID AND
    Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
       END
       END
      ELSE
       BEGIN
       IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurrentInjectionDate and batchid=@BatchID)
       BEGIN
        INSERT INTO TCD.BatchProductData(BatchId,StepCompartment,ActualQuantity,StandardQuantity,Price,TimeStamp,PartitionOn,EcolabWasherId,ProductId)
        SELECT Bd.BatchId  
        --SELECT @BatchID
         ,Wds.StepNumber
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100) AS ActualQuantity  
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100) AS StandardQuantity      
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * @MaxWashertGroupCapacity)/CONVERT(decimal(10,2), 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price         
         ,@CurrentInjectionDate
         ,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
         ,@EcolabWasherId
         ,Pdm.ProductID
        FROM TCD.Washer WS
         INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
         INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
         INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
         INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
         INNER JOIN TCD.WasherDosingSetup Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
         INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
         INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Wdpm.ProductId
         INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
        WHERE 
          Ws.WasherId=@WasherId     AND 
          Wps.ProgramNumber=@CurrentFormula  AND 
          Wdpm.InjectionNumber=@CurrentInjection AND
          Bd.BatchId=@BatchID AND
    Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
       END  
       END 
       
  --Populating BatchWashstepdata
      SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
      
      IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchWashStepData WHERE StartTime =@CurrentInjectionDate and batchid=@BatchID)
      BEGIN
         SELECT @CurrentInjectionStep=Wds.StepNumber,
             @WashStepBatchId=Bd.BatchId
                 
         FROM TCD.Washer WS
          INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
          INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
          INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
          INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
          INNER JOIN TCD.WasherDosingSetup Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
          INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
          INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Wdpm.ProductId
          INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
         WHERE 
          Ws.WasherId=@WasherId     AND 
          Wps.ProgramNumber=@CurrentFormula  AND 
          Wdpm.InjectionNumber=@CurrentInjection AND
          Bd.BatchId=@BatchID AND
          Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0

         IF(@CurrentInjectionStep IS NOT NULL)
         BEGIN
          INSERT INTO TCD.BatchWashStepData(BatchId,StepCompartment,StartTime,PartitionOn,EcolabWasherId)
          VALUES (@WashStepBatchId,  @CurrentInjectionStep, @CurrentInjectionDate, (SELECT Top 1 ShiftStartdate from @ShiftStartDate), @EcolabWasherId)                
         
          UPDATE TCD.BatchWashStepData SET EndTime=@CurrentInjectionDate WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate         
         END

      END
      --End Populating BatchWashstepdata

      --Start Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
      IF NOT EXISTS(SELECT * FROM TCD.BatchParameters WHERE ParameterId =37 and batchid=@BatchID)
      BEGIN
       INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,37,1,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)       
      END
      ELSE
      BEGIN
       Update TCD.BatchParameters SET ParameterValue=@CurrentInjection WHERE ParameterId =37 and batchid=@BatchID
      END
        --End Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record

           
     END

     UPDATE TCD.ConduitController
      SET LastConnectedTime  = GETUTCDATE()
      WHERE ControllerId   = @ControllerId
   END
  END
 END

 ---------------------------------------------
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessTunnelWasherData]') AND type in (N'P', N'PC'))
DROP PROCEDURE [TCD].[ProcessTunnelWasherData]

GO
CREATE PROCEDURE [TCD].[ProcessTunnelWasherData]
 ( 
 @WasherId INT, 
 @xmlTags XML,
 @RedFlagShiftId INT OUTPUT
)
AS
BEGIN
  DECLARE @BatchID      INT,
    @EcolabWasherId     INT,        
    @CurrencyCode     VARCHAR(50),  
    @MachineInternalId    INT ,
    @GroupId      INT,  
    @Prveformula     INT,
    @Quantity      INT,
    @MaxWashertGroupCapacity  INT,
    @PrevBatchId     INT,
    @PrevLoadId      INT,
    @ExistedLoadId     INT,
    @NumberOfCompartments   INT,
    @ProgramMasterId    INT,
    @NominalLoad     Decimal(10,2),
    @MaxLoad      Decimal(10,2),
    @StandardWeight     Decimal(10,2) ,     
    @PlantWasherNumber    INT,
           
    @CurrentDay      DATE=CAST(GETUTCDATE() as date),
    @TempTunnelTimeStamp   DATETIME2,

    @ControllerId     INT ,
    @CurrentHoldSignal    INT,
    
    @TotalRunTime     INT,
    @BatchGroupId     INT,
    @BatchFormula     INT,
    @BatchStartDate     DATETIME2,
    @BatchEndDate     DATETIME2,
    @HoldTime      INT,
    @CteTempBatchTunnelWashSteps INT,
    @CteTemTunnelWashSetps   INT,
    @PrevFormula     INT,
    @PrevStepCompartment   INT,
    @BatchStandardWaterUsage  INT,
    @BatchActualWaterUsage   INT,
    @BatchWaterUsagePrice   Decimal(10,2),
    @BatchUtilityPrice    Decimal(10,2),
    @BatchWaterType     INT,
    @ExtraTime      INT,
    @TargetTurnTime     INT,
    @EcolabAccountNumber NVARCHAR(25) = NULL,
    @AlarmGroupMasterId INT,
    @PartitionOn SMALLDATETIME,
    @StdInjectionSteps INT,
    @StdWashSteps INT,
    @EcolabTextileCategoryId INT,
    @ChainTextileCategoryId INT,
    @FormulaSegmentId INT,
    @EcolabSaturationId INT,
    @PlantProgramId INT,
	@ETechLastDroppedAt  DATETIME2         
                                      
  SELECT @ExtraTime = 0

  SELECT DISTINCT      
     @NumberOfCompartments=MST.NumberOfComp,
     @EcolabWasherId=Ws.EcolabWasherId
   FROM  TCD.Washer Ws
   INNER JOIN 
      TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId     
  WHERE Ws.WasherId=@WasherId and Ws.Is_Deleted=0
  
    
  IF EXISTS (SELECT  * FROM TEMPDB.DBO.SYSOBJECTS o where o.xtype in ('U') AND o.id = OBJECT_ID(N'tempdb..#XmlTagsTable'))
   BEGIN
     DROP TABLE #XmlTagsTable
   END
  CREATE TABLE  #XmlTagsTable ( CurrentFormula    INT,
          CurretnInjection   INT,
          CurrentOperationCounter  INT,
          Eof       INT,
          TunnelTimeStamp    DATETIME2,
          OnHold      BIT,          
          CompartmentId    INT, 
          CompartmentLoadId   INT, 
          CompartmentFormulaId  INT,          
          ReceivedTime    DATETIME2,
          AutoWeightEntryActive  VARCHAR(10),
          AutoWeightEntryWeight  INT,
          IsFormulaModified   BIT,
          IsHoldSignalModified  BIT ,
          IsStopSinalModified   BIT,
          StopSignal     INT,
          RatioDosingEnabled   INT,
		  ETechLastDropped VARCHAR(100)      
         )
  INSERT INTO #XmlTagsTable (
          CurrentFormula ,
          CurretnInjection,          
          CurrentOperationCounter,
          Eof,
          TunnelTimeStamp ,
          OnHold,
          CompartmentId, 
          CompartmentLoadId, 
          CompartmentFormulaId,
          ReceivedTime,
          AutoWeightEntryActive,
          AutoWeightEntryWeight,
          IsFormulaModified,
          IsHoldSignalModified,
          IsStopSinalModified,
          StopSignal,
          RatioDosingEnabled,
		  ETechLastDropped 
         )   
  
  -- Populate tempdata from xml
  SELECT T.c.value('../@CurrentFormula', 'INT') AS CurrentFormula, 
    T.c.value('../@CurrentInjection', 'INT') AS CurretnInjection,     
    T.c.value('../@CurrentOperationCounter', 'INT') AS CurrentOperationCounter,       
    T.c.value('../@Eof', 'INT') AS EndofFormula, 
    T.c.value('../@TimeStamp', 'VARCHAR(100)') AS TunnelTimeStamp, 
    T.c.value('../@OnHold', 'VARCHAR(100)') AS OnHold, 
    T.c.value('@CompartmentId', 'INT') AS CompartmentId, 
    T.c.value('@LoadId', 'INT') AS CompartmentLoadId, 
    T.c.value('@FormulaId', 'INT') AS CompartmentFormulaId,     
    T.c.value('@TimeStamp', 'VARCHAR(100)') DateTimeStamp,
    T.c.value('../@Awea', 'VARCHAR(10)') AS AutoWeightEntryActive,     
    T.c.value('../@Awew', 'INT') AS AutoWeightEntryWeight, 
    T.c.value('../@IsFormulaModified', 'BIT') AS IsFormulaModified,
    T.c.value('../@IsHoldSignalModified', 'BIT') AS IsHoldSignalModified,
    T.c.value('../@IsStopSinalModified', 'BIT') AS IsStopSinalModified,
    T.c.value('../@StopSignal', 'INT') AS StopSignal,
    T.c.value('../@RATA', 'INT') AS RatioDosingEnabled,
	T.c.value('../@ETechLastDroppedAt', 'VARCHAR(100)') AS ETechLastDropped
    
    
  
  FROM @xmlTags.nodes('/Tunnel/Compartment')  T(c)

  
  WHERE 
  T.c.value('@LoadId', 'VARCHAR(100)')  != 0
  AND
  T.c.value('@CompartmentId', 'INT')    <= @NumberOfCompartments

  --ETech last dropped 
  SELECT @ETechLastDroppedAt=CONVERT(datetime,ETechLastDropped) from #XmlTagsTable

  IF EXISTS (SELECT 1 FROM #XmlTagsTable where IsHoldSignalModified = 1)  
   BEGIN   
    SELECT @CurrentHoldSignal = Id  FROM TCD.ConduitParameters where Name='HoldSignal'
    INSERT INTO TCD.WasherReading(
        WasherId,
        ParameterId,
        ParameterValue,
        DateTimeStamp,
        EcolabWasherId)
     SELECT  @WasherId,
        @CurrentHoldSignal,
        OnHold,
        ReceivedTime,
        @EcolabWasherId 
     FROM #XmlTagsTable
   END 
  IF EXISTS (SELECT 1 FROM #XmlTagsTable where IsStopSinalModified = 1)  
   BEGIN 
    INSERT INTO TCD.WasherReading(
       WasherId,
       ParameterId,
       ParameterValue,
       DateTimeStamp,
       EcolabWasherId)
    SELECT  @WasherId,
       12,
       StopSignal,
       ReceivedTime,
       @EcolabWasherId
    FROM #XmlTagsTable
   END 
  IF EXISTS (SELECT 1 FROM #XmlTagsTable where IsFormulaModified = 1)  
   BEGIN
  
   -- Start find missing load id form xml  and set end date for corresponding enddates in the database
   DECLARE @TempExisitingLoadIds table(ExstingLoadId INT,ExistsBatchId int)
   INSERT INTO @TempExisitingLoadIds(ExstingLoadId,ExistsBatchId)
    SELECT Bd.ControllerBatchId,Bd.BatchId FROM TCD.BatchData Bd     
     --INNER JOIN TCD.BatchWashStepData Bwsd on Bwsd.BatchId=Bd.BatchId
    WHERE Bd.MachineId=@WasherId AND Bd.EndDate IS NULL ORDER BY Bd.StartDate DESC   
  
   SELECT @TempTunnelTimeStamp =(SELECT T.c.value('./@TimeStamp', 'VARCHAR(100)') AS TunnelTimeStamp FROM @xmlTags.nodes('/Tunnel')  T(c))
   
   DECLARE @TempBatchStepIs TABLE(StepBatchId INT)
   INSERT INTO @TempBatchStepIs (StepBatchId)
   SELECT ExistsBatchId 
    FROM @TempExisitingLoadIds 
    WHERE ExstingLoadId NOT IN (SELECT CompartmentLoadId FROM #XmlTagsTable)
  
  SELECT @PrevStepCompartment=StepCompartment,@PrevBatchId =BatchID 
  FROM TCD.BatchWashStepData  
  WHERE BatchId in (select StepBatchId from @TempBatchStepIs) AND EndTime IS NULL

  UPDATE 
  TCD.BatchWashStepData 
  SET EndTime = @TempTunnelTimeStamp
  WHERE BatchId in (select StepBatchId from @TempBatchStepIs) AND EndTime IS NULL

  DECLARE @BatchShiftId int
  DECLARE @ShiftStartDateTemp table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
  INSERT INTO @ShiftStartDateTemp(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @TempTunnelTimeStamp,1, @RedFlagShiftId OUTPUT
  SELECT @BatchShiftId = ssdt.ShiftId FROM @ShiftStartDateTemp ssdt ORDER BY ssdt.ShiftStartdate

  -- Updating Batches moved out of the tunnel
  UPDATE TCD.BatchData 
  SET  
    EndDate=@TempTunnelTimeStamp
   , EndDateFormula=@TempTunnelTimeStamp,
   ShiftId = @BatchShiftId
  WHERE BatchId in (select StepBatchId from @TempBatchStepIs)

  --End find missing load id form xml  and set end date for corresponding enddates in the database
   
  --Start HoldTime Calculation
   SELECT 
     @BatchGroupId=GroupId
    , @BatchFormula=ProgramNumber
    , @BatchStartDate=StartDate
    , @BatchEndDate=EndDate 
   FROM TCD.BatchData 
   WHERE BatchId IN (select  StepBatchId from @TempBatchStepIs)

   SELECT @TotalRunTime=TotalRunTime 
   FROM TCD.TunnelProgramSetup 
   WHERE WasherGroupId =@BatchGroupId 
    AND ProgramNumber=@BatchFormula

   
   INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) 
   SELECT StepBatchId,@EcolabWasherId,17,(DATEDIFF(SECOND, @BatchStartDate, @BatchEndDate))-@TotalRunTime,bd.partitionon
            FROM @TempBatchStepIs,TCD.BatchData bd WHERE bd.BatchId= [@TempBatchStepIs].StepBatchId  and [@TempBatchStepIs].StepBatchId NOT IN (SELECT BATCHID FROM TCD.BatchParameters AS BP WHERE BP.ParameterId = 17)
 
  --End HoldTime Calculation

    --Start Good or Bad Injection in BatchDataTable
     IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@PrevBatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
      BEGIN
     
       ;WITH CteTempBatchTunnelStepData  ( 
        InjectionsCount,BatchId,ProgramNumber
       ) AS  
       (
        SELECT DISTINCT Bws.StepCompartment,
            BD.BatchId,            
            Bd.ProgramNumber
            FROM TCD. BatchData Bd
        INNER JOIN 
          TCD.BatchWashStepData Bws 
               ON Bws.BatchId   =  Bd.BatchId 
        WHERE    
              
              Bd.BatchId     =  @PrevBatchId ) 
        SELECT @CteTemTunnelWashSetps=COUNT(CTE1.InjectionsCount)
        FROM CteTempBatchTunnelStepData CTE1 
        INNER JOIN TCD.BatchData Bd ON Bd.BatchId=CTE1.BatchId
        WHERE Bd.BatchId=@BatchId

        ;WITH CteTempBatchInjections ( 
        InjectionsCount,ProgramNumber
       ) AS  
       (
        SELECT  DISTINCT 
            
            Tds.CompartmentNumber,
            Tps.ProgramNumber
           FROM TCD.TunnelProgramSetup Tps 
          INNER JOIN 
             TCD.TunnelDosingSetup Tds ON 
              Tds.TunnelProgramSetupId =  Tps.TunnelProgramSetupId
          INNER JOIN 
             TCD.TunnelDosingProductMapping Tdpm ON 
             Tdpm.TunnelDosingSetupId  =  Tds.TunnelDosingSetupId
          INNER JOIN 
             TCD.ControllerEquipmentSetup Ces ON 
             Ces.ControllerEquipmentSetupId =  Tdpm.ControllerEquipmentSetupId
             WHERE                            
             Tps.ProgramNumber    =  @PrevFormula )
        SELECT @CteTempBatchTunnelWashSteps=COUNT(CTE2.InjectionsCount)
        FROM CteTempBatchInjections CTE2 

          Insert Tcd.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @PrevBatchId,@EcolabWasherId,18,
          CASE WHEN @CteTempBatchTunnelWashSteps = @CteTemTunnelWashSetps THEN 1
            WHEN @CteTempBatchTunnelWashSteps != @CteTemTunnelWashSetps THEN 3 END,
            (SELECT PartitionOn FROM TCD.BatchData where BatchId=@PrevBatchId and MachineId=@WasherId)
              
              
                
    END

   -- End Good or Bad Injection in BatchDataTable


 -- Fetching data from cursor
   DECLARE @MYCURSOR CURSOR
   SET @MYCURSOR = CURSOR FAST_FORWARD
   FOR
   SELECT  CurrentFormula ,
      CurretnInjection,          
      CurrentOperationCounter,
      Eof,
      TunnelTimeStamp ,
      OnHold,
      CompartmentId, 
      CompartmentLoadId, 
      CompartmentFormulaId,
      ReceivedTime,
      AutoWeightEntryActive,
      AutoWeightEntryWeight,
      IsFormulaModified,
      IsHoldSignalModified,
      IsStopSinalModified,
      StopSignal,
      RatioDosingEnabled

    FROM #XmlTagsTable ORDER BY CompartmentId ASC
   DECLARE   @CurCurrentFormula     INT,
       @CurCurretnInjection   INT,
       @CurCurrentOperationCounter  INT,
       @CurEof       INT,
       @CurTunnelTimeStamp    DATETIME2,
       @CurOnHold      BIT,
       @CurCompartmentId    INT, 
       @CurCompartmentLoadId   INT, 
       @CurCompartmentFormulaId  INT,
       @CurReceivedTime    DATETIME2,
       @AutoWeightEntryActive   VARCHAR(10),
       @AutoWeightEntryWeight   INT,
       @IsFormulaModified    BIT,
       @IsHoldSignalModified   BIT,
       @IsStopSinalModified   BIT,
       @StopSignal      INT,
       @RatioDosingEnabled    INT 

   OPEN @MYCURSOR
   FETCH NEXT FROM @MYCURSOR
       INTO @CurCurrentFormula   ,
       @CurCurretnInjection   ,
       @CurCurrentOperationCounter  ,
       @CurEof       ,
       @CurTunnelTimeStamp    ,
       @CurOnHold      ,
       @CurCompartmentId    , 
       @CurCompartmentLoadId   , 
       @CurCompartmentFormulaId  ,
       @CurReceivedTime    ,
       @AutoWeightEntryActive   ,
       @AutoWeightEntryWeight   ,
       @IsFormulaModified    ,
       @IsHoldSignalModified   ,
       @IsStopSinalModified   ,
       @StopSignal      ,
       @RatioDosingEnabled
   WHILE @@FETCH_STATUS = 0
   BEGIN
    

   IF(@IsFormulaModified !=0) 
   BEGIN
    IF(@CurCurrentFormula != @CurEof and @CurCurretnInjection = 0 and @CurCurrentOperationCounter = 0)
     BEGIN

   SELECT DISTINCT        
       @MachineInternalId   = Mst.MachineInternalId,
       @GroupId     = Mst.GroupId,
       @ControllerId    = Ctrl.ControllerId    
     FROM TCD.Washer Ws
      INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
      INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
      INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
      INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId = Mst.ControllerId
     WHERE Ws.WasherId=@WasherId  

    SELECT DISTINCT 
       @ProgramMasterId   = Wps.ProgramId,
       @NominalLoad    = Wps.NominalLoad,
       @MaxLoad     = Ws.MaxLoad,
       @CurrencyCode    = Pl.CurrencyCode, 
       @TargetTurnTime    =   (3600/(Wps.TotalRunTime/Mst.NumberofComp))

    FROM TCD.Washer Ws
      INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
      INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
      INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
      INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
      INNER JOIN TCD.Plant Pl ON Pl.EcolabAccountNumber =  Ws.EcoLabAccountNumber
      
    WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@CurCurrentFormula and Wps.Is_Deleted=0

    select @PlantWasherNumber = plantwashernumber from tcd.washer where washerid = @WasherId
 
    SELECT  @MaxWashertGroupCapacity  = Max(ws.MaxLoad)
    FROM TCD.Washer WS
     INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
     INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId  
    WHERE Mst.GroupId=@GroupId

    SELECT @StandardWeight     = @NominalLoad          
    SELECT @AutoWeightEntryWeight=Case @AutoWeightEntryActive WHEN 'False' THEN @StandardWeight ELSE  @AutoWeightEntryWeight END 
    
      
    SELECT @MachineInternalId,@GroupId,@ProgramMasterId,@NominalLoad,@WasherId,@CurCurrentFormula,@PrevBatchId
    SELECT @CurCurrentFormula    AS CurCurrentFormula   ,
       @CurCurretnInjection  AS CurCurretnInjection  ,
       @CurCurrentOperationCounter AS CurCurrentOperationCounter ,
       @CurEof      AS CurEof   ,
       @CurTunnelTimeStamp   AS CurTunnelTimeStamp  ,
       @CurOnHold     AS CurOnHold   ,
       @CurCompartmentId   AS CurCompartmentId   , 
       @CurCompartmentLoadId  AS CurCompartmentLoadId   , 
       @CurCompartmentFormulaId AS CurCompartmentFormulaId  ,
       @CurReceivedTime   AS CurReceivedTime,
       @AutoWeightEntryActive  AS AutoWeightEntryActive,
       @AutoWeightEntryWeight  AS AutoWeightEntryWeight,
       @IsFormulaModified   AS IsFormulaModified
  
  IF(@CurCompartmentFormulaId > 0)
  BEGIN
     UPDATE TCD.ConduitController
     SET LastConnectedTime  = GETUTCDATE()
     WHERE ControllerId   = @ControllerId
  END
  
  
  IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchData WHERE MachineId=@WasherId AND StartDate =@CurTunnelTimeStamp)
  BEGIN

   DECLARE @ShiftStartDate table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
   INSERT INTO @ShiftStartDate(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurTunnelTimeStamp,0, @RedFlagShiftId OUTPUT

    --Start Getting InjectionCount,StepCount And ProductCount
     SELECT @StdInjectionSteps= count(tdpm.TunnelDosingSetupId) ,
     @StdWashSteps= count(DISTINCT tds.TunnelDosingSetupId)-count(tdpm.TunnelDosingSetupId) 
     FROM TCD.TunnelDosingProductMapping tdpm
     RIGHT JOIN tcd.TunnelDosingSetup tds on tdpm.TunnelDosingSetupId=tds.TunnelDosingSetupId
     WHERE tds.GroupId=@GroupId AND tds.ProgramNumber=@CurCurrentFormula
       --Start-----ProgramMasterID logic for PlantChainProgram
     SELECT 
     @PlantProgramId=pm.PlantProgramId,
     @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
     @ChainTextileCategoryId = pm.ChainTextileId,
     @FormulaSegmentId = pm.FormulaSegmentId,
     @EcolabSaturationId = pm.EcolabSaturationId 
     FROM TCD.ProgramMaster pm WHERE pm.ProgramId=@ProgramMasterId AND pm.Is_Deleted=0
     IF(@PlantProgramId <> 0  AND @PlantProgramId IS NOT NULL)
      BEGIN
       --Assign value from plantchainprogram table based on plantprogramId
       SELECT
        @EcolabTextileCategoryId = pcp.EcolabTextileCategoryId,
        @ChainTextileCategoryId = pcp.ChainTextileCategoryId,
        @FormulaSegmentId = pcp.FormulaSegmentId,
        @EcolabSaturationId = pcp.EcolabSaturationId
        FROM tcd.PlantChainProgram pcp
        WHERE pcp.PlantProgramId=@PlantProgramId AND pcp.Is_Deleted=0
      END
    --End-----ProgramMasterID logic for PlantChainProgram
    -- New Batch Creation
       INSERT INTO TCD.BatchData(
           ControllerBatchId ,
           EcolabWasherId,
           GroupId ,
           MachineInternalId,
           PlantWasherNumber,
           StartDate ,
           EndDate ,
           ProgramNumber,
           ProgramMasterId,
           MachineId,
           ActualWeight,
           StandardWeight,
           CurrencyCode,
           ShiftId,
           PartitionOn,
           TargetTurnTime,
           StdInjectionSteps,
           StdWashSteps,
           EcolabTextileCategoryId,
           ChainTextileCategoryId,
           FormulaSegmentId,
           EcolabSaturationId,
           PlantProgramId,
		   ETechlastDroppedTimeStamp
           )


          SELECT DISTINCT @CurCompartmentLoadId
           ,@EcolabWasherId
           ,@GroupId
           ,@MachineInternalId
           ,@PlantWasherNumber
           --,@CurReceivedTime
           ,@CurTunnelTimeStamp
           ,NULL
           ,@CurCurrentFormula
           ,@ProgramMasterId
           ,@WasherId
           ,@AutoWeightEntryWeight
           ,@StandardWeight 
           ,@CurrencyCode
           ,(SELECT Top 1 ShiftId from @ShiftStartDate)
           ,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
           ,@TargetTurnTime
           ,@StdInjectionSteps
           ,@StdWashSteps
           ,@EcolabTextileCategoryId
           ,@ChainTextileCategoryId
           ,@FormulaSegmentId
           ,@EcolabSaturationId
           ,@PlantProgramId
		   ,@ETechLastDroppedAt 
        
   
        SET @BatchID=SCOPE_IDENTITY() 

        --Start insert InjectionActualCount and StepActualCount in TCD.BatchParameters
        INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchID,@EcolabWasherId,37,@StdInjectionSteps,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
        INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchID,@EcolabWasherId,38,@StdWashSteps,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)  
        --End insert InjectionActualCount and StepActualCount in TCD.BatchParameters

        --If the received formula is not configured in enVision then create an alarm 
       IF(@ProgramMasterId is NULL)
       BEGIN
       SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant
       SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.AlarmGroupMsterVsControllerModelType AGMVCMT
       INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
       WHERE AGMVCMT.AlarmCode = 9000
        INSERT INTO [TCD].[AlarmData] 
           (EcoalabAccountNumber,
           AlarmCode,
           BatchId,
           controllerID,
           StartDate,
           GroupId,
           MachineInternalId,
           ProgramId,   
           IsActive,
           EndDate,
           MachineId,
           AlarmGroupMasterId)
           SELECT
            @ECOLABAccountNumber,
            9000,
            @BatchID,
            @ControllerId,
            @CurTunnelTimeStamp,
            @GroupId,
            @MachineInternalId,
            @CurCurrentFormula,
            0,
            @CurTunnelTimeStamp,
            @WasherId,
            @AlarmGroupMasterId
       END


      -- Wash Step Information  
      INSERT INTO TCD.BatchWashStepData(
           BatchId
           ,StepCompartment
           ,StartTime
           ,EndTime
           ,PartitionOn
           ,EcolabWasherId)     
      SELECT 
           @BatchID,
           @CurCompartmentId,
           @CurTunnelTimeStamp,
           --@CurReceivedTime,
           NULL,
           (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
           @EcolabWasherId
      -- Product Usage
    IF (@RatioDosingEnabled = 1)
     BEGIN
      INSERT INTO TCD.BatchProductData(
         BatchId,
         StepCompartment,
         ActualQuantity,
         StandardQuantity,
         Price,
         [TimeStamp],
         PartitionOn,
         EcolabWasherId,
         ProductId
      )     
      SELECT DISTINCT @BatchID 
          ,@CurCompartmentId
          ,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * (@AutoWeightEntryWeight/@StandardWeight) AS ActualQuantity      
          ,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * (@AutoWeightEntryWeight/@StandardWeight) AS StandardQuantity          
          ,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price 
          ,@CurTunnelTimeStamp        
          --,@CurReceivedTime
          ,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
          ,@EcolabWasherId
          ,Pdm.ProductID
       FROM TCD.Washer WS
       INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
       INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
       INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
       INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
       INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
       INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
       INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId=Wdpm.ControllerEquipmentSetupId
       INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Ces.ProductId
       --INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
      WHERE 
        Ws.WasherId=@WasherId AND 
        Wps.ProgramNumber=@CurCurrentFormula AND 
        Wds.CompartmentNumber=@CurCompartmentId AND
        Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
     END
    ELSE
     BEGIN
      INSERT INTO TCD.BatchProductData(
         BatchId,
         StepCompartment,
         ActualQuantity,
         StandardQuantity,
         Price,
         [TimeStamp],
         PartitionOn,
         EcolabWasherId,
         ProductId
      )     
      SELECT DISTINCT @BatchID 
          ,@CurCompartmentId
          ,((Wps.NominalLoad * Wdpm.Quantity)/ 100) AS ActualQuantity      
          ,((Wps.NominalLoad * Wdpm.Quantity)/ 100) AS StandardQuantity          
          ,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price
          ,@CurTunnelTimeStamp         
          --,@CurReceivedTime
          ,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
          ,@EcolabWasherId
          ,Pdm.ProductID
       FROM TCD.Washer WS
       INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
       INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
       INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
       INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
       INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
       INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
       INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId=Wdpm.ControllerEquipmentSetupId
       INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Ces.ProductId
       --INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
      WHERE 
        Ws.WasherId=@WasherId AND 
        Wps.ProgramNumber=@CurCurrentFormula AND 
        Wds.CompartmentNumber=@CurCompartmentId AND
        Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
     END   
        
        
      -- Transfer Signal  
        INSERT INTO TCD.WasherReading(
               WasherId,
               ParameterId,
               ParameterValue,
               DateTimeStamp,
               PartitionOn,
               EcolabWasherId)
         SELECT @WasherId,
           6,
           1,
           @TempTunnelTimeStamp,
           (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
           @EcolabWasherId
         UNION ALL
         SELECT @WasherId,
           6,
           0,
           GETUTCDATE(),
           (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
           @EcolabWasherId
   
      -- Insert Customer Data
      INSERT INTO TCD.BatchCustomerData(
          BatchId,
          CustomerId,
          Weight,
          PiecesCount,
          PartitionOn,
          EcolabWasherId
          )
      SELECT DISTINCT 
          Bd.BatchId,  
          Pc.ID,
          @AutoWeightEntryWeight,
          ROUND(COALESCE((@AutoWeightEntryWeight * Pm.Pieces) / NULLIF(Pm.Weight,0), 0),0),
          (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
          @EcolabWasherId
      
      FROM TCD.Washer WS
       INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
       INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId       
       INNER JOIN TCD.TunnelProgramSetup Tps ON Tps.WasherGroupId = Wg.WasherGroupId
       INNER JOIN TCD.ProgramMaster Pm ON Pm.ProgramId=Tps.ProgramId
       INNER JOIN TCD.PlantCustomer Pc ON Pc.ID=Pm.CustomerId
       INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
      WHERE 
       Ws.WasherId=@WasherId AND 
       Tps.ProgramNumber=@CurCompartmentFormulaId AND 
       Bd.BatchId=@BatchID   AND 
       Pm.CustomerId != -1
       AND Pm.[Weight] > 0
  END

  ELSE
  BEGIN
   SELECT @BatchID=BatchId, @PartitionOn=PartitionOn
   FROM TCD.BatchData 
   WHERE MachineId=@WasherId 
   AND ControllerBatchId=@CurCompartmentLoadId
   
   IF(@BatchID IS NOT NULL)
   BEGIN
   UPDATE TCD.BatchWashStepData 
    SET EndTime=@CurTunnelTimeStamp
   WHERE BatchId=@BatchId 
    AND StepCompartment=@CurCompartmentId-1

    IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchWashStepData WHERE StartTime=@CurTunnelTimeStamp and BatchId=@BatchID)
    BEGIN
     INSERT INTO TCD.BatchWashStepData(
           BatchId
           ,StepCompartment
           ,StartTime
           ,EndTime
           ,PartitionOn
           ,EcolabWasherId)     
      SELECT 
           @BatchID,
           @CurCompartmentId,
           @CurTunnelTimeStamp,
           --@CurReceivedTime,
           NULL,
           @PartitionOn,
           @EcolabWasherId
    END       
    IF (@RatioDosingEnabled = 1)
     BEGIN
     IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurTunnelTimeStamp and BatchId=@BatchID)
     BEGIN
      INSERT INTO TCD.BatchProductData(
         BatchId,
         StepCompartment,
         ActualQuantity,
         StandardQuantity,
         Price,
         [TimeStamp],
         PartitionOn,
         EcolabWasherId,
         ProductId
         )
      SELECT DISTINCT 
         @BatchID 
         ,@CurCompartmentId
         ,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * (@AutoWeightEntryWeight/@StandardWeight) AS ActualQuantity       
         ,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * (@AutoWeightEntryWeight/@StandardWeight) AS StandardQuantity 
         ,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price
         ,@CurTunnelTimeStamp         
         --,@CurReceivedTime
         ,@PartitionOn
         ,@EcolabWasherId
         ,Pdm.ProductID
      FROM TCD.Washer WS
      INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
      INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
      INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
      INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
      INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
      INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
      INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId=Wdpm.ControllerEquipmentSetupId
      INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Ces.ProductId
      --INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
      WHERE 
       Ws.WasherId=@WasherId 
       AND Wps.ProgramNumber=@CurCompartmentFormulaId 
       AND Wds.CompartmentNumber=@CurCompartmentId AND
       Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
     END
    END -- end of ratio dosing if
    ELSE
     BEGIN
     IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurTunnelTimeStamp and BatchId=@BatchID)
     BEGIN
     INSERT INTO TCD.BatchProductData(
         BatchId,
         StepCompartment,
         ActualQuantity,
         StandardQuantity,
         Price,
         [TimeStamp],
         PartitionOn,
         EcolabWasherId,
         ProductId
         )
     SELECT DISTINCT 
         @BatchID 
         ,@CurCompartmentId
         ,((Wps.NominalLoad * Wdpm.Quantity)/ 100) AS ActualQuantity       
         ,((Wps.NominalLoad * Wdpm.Quantity)/ 100) AS StandardQuantity 
         ,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price
         ,@CurTunnelTimeStamp         
         --,@CurReceivedTime
         ,@PartitionOn
         ,@EcolabWasherId
         ,Pdm.ProductID
      FROM TCD.Washer WS
      INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
      INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
      INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
      INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
      INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
      INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
      INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId=Wdpm.ControllerEquipmentSetupId
      INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Ces.ProductId
        
     WHERE 
       Ws.WasherId=@WasherId 
       AND Wps.ProgramNumber=@CurCompartmentFormulaId 
       AND Wds.CompartmentNumber=@CurCompartmentId AND
        Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0 
   END
   END        
    END -- end of BatchId NULL if
   END -- end of else
  END  -- end of IF(@CurCurrentFormula != @CurEof and @CurCurretnInjection = 0 and @CurCurrentOperationCounter = 0)       
 END  -- end of IF(@IsFormulaModified !=0) 
               
   FETCH NEXT FROM @MYCURSOR
   INTO @CurCurrentFormula   ,
       @CurCurretnInjection   ,
       @CurCurrentOperationCounter  ,
       @CurEof       ,
       @CurTunnelTimeStamp    ,
       @CurOnHold      ,
       @CurCompartmentId    , 
       @CurCompartmentLoadId   , 
       @CurCompartmentFormulaId  ,
       @CurReceivedTime    ,
       @AutoWeightEntryActive   ,
       @AutoWeightEntryWeight   ,
       @IsFormulaModified    ,
       @IsHoldSignalModified   ,
       @IsStopSinalModified   ,
       @StopSignal      ,
       @RatioDosingEnabled
   END
   CLOSE @MYCURSOR
   DEALLOCATE @MYCURSOR 
   
  
  END
END
-----------------------------------
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetActiveControllers]') AND type in (N'P', N'PC'))
DROP PROCEDURE [TCD].[GetActiveControllers]
GO
CREATE PROCEDURE [TCD].[GetActiveControllers]
 AS
BEGIN

SET NOCOUNT ON              --SQLEnlight SA0017

  DECLARE @TempControllerFields TABLE
  (
    ControllerId INT,
    OpcServer INT,
    IpAddress INT,
	AMSNetIDAddress INT,
    ComportNumber INT,
    WebportFtpEnabled INT,
    WebportIP INT,
    WebportLogin INT,
    WebportPassword INT
  )
  INSERT INTO @TempControllerFields
  (  
    ControllerId ,
    OpcServer ,
    IpAddress ,
	AMSNetIDAddress,
    ComportNumber ,
    WebportFtpEnabled ,
    WebportIP ,
    WebportLogin ,
    WebportPassword
  )
  SELECT distinct
    Csd.ControllerId,
    max(case when Fld.Label = 'OPC Server' then Fld.Id end) OpcServer,
	max(case when Fld.Label = 'IP Address' then Fld.Id end) IpAddress,
    max(case when Fld.Label = 'AMS Net ID Address' then Fld.Id end) AMSNetIDAddress,
    max(case when Fld.Label = 'Com port Number' then Fld.Id end) ComportNumber,
    max(case when Fld.Label = 'Webport Ftp Enabled' then Fld.Id end) WebportFtpEnabled,
    max(case when Fld.Label = 'Webport IP' then Fld.Id end) WebportIP,
    max(case when Fld.Label = 'Webport Login' then Fld.Id end) WebportLogin,
    max(case when Fld.Label = 'Webport Password' then Fld.Id end) WebportPassword 
  FROM TCD.Field Fld
    INNER JOIN 
      TCD.ControllerSetupData Csd 
      ON Csd.FieldId=Fld.Id
  GROUP BY Csd.ControllerId

  SELECT DISTINCT 
      P.RegionID as RegionID,      
      Ctrl.ControllerId,
      Ctrl.EcoalabAccountNumber,
      Ctrl.ControllerTypeId,
      Ctrl.Name,
      CASE WHEN (CsdOpc.Value IS NULL) THEN NULL 
        ELSE CsdOpc.Value END 
        AS OpcServerName,
      CASE WHEN (CsdIP.Value IS NULL) THEN NULL 
        ELSE CsdIP.Value END 
        AS IpAddress,
	 CASE WHEN (CsdAMSId.Value IS NULL) THEN NULL 
        ELSE CsdAMSId.Value END 
        AS AMSNetIDAddress,
      CASE WHEN (CsdComport.Value IS NULL) THEN NULL 
        ELSE CsdComport.Value END 
        AS ComportNumber,
      CASE WHEN (CsdWebFtp.Value IS NULL) THEN NULL
         WHEN CsdWebFtp.Value = 'False' THEN 0 
        WHEN CsdWebFtp.Value = 'True' THEN 1  
        END 
        AS WebportFtpEnabled,
      CASE WHEN (CsdWebIP.Value IS NULL) THEN NULL 
        ELSE CsdWebIP.Value END 
        AS WebportIP,
      CASE WHEN (CsdWebLogin.Value IS NULL) THEN NULL 
        ELSE CsdWebLogin.Value END 
        AS WebportLogin,
      CASE WHEN (CsdWebPwd.Value IS NULL) THEN NULL 
        ELSE CsdWebPwd.Value END 
        AS WebportPassword,
      Ctrl.ControllerModelId,
      Ctrl.TopicName,
      Ctrl.WebportReadTime
   FROM  TCD.ConduitController Ctrl 
   INNER JOIN 
      @TempControllerFields Tcf 
      ON Tcf.ControllerId=Ctrl.ControllerId
   INNER JOIN 
      Plant P
      ON P.EcolabAccountNumber=Ctrl.EcoalabAccountNumber
   LEFT JOIN 
      TCD.ControllerSetupData CsdOpc 
      ON CsdOpc.FieldId = Tcf.OPCServer 
      AND CsdOpc.ControllerId = Ctrl.ControllerId
   LEFT JOIN 
      tcd.ControllerSetupData CsdIp 
      ON CsdIp.FieldId=Tcf.IpAddress 
      AND CsdIp.ControllerId = Ctrl.ControllerId
  LEFT JOIN 
      tcd.ControllerSetupData CsdAMSId 
      ON CsdAMSId.FieldId=Tcf.AMSNetIDAddress 
      AND CsdAMSId.ControllerId = Ctrl.ControllerId
   LEFT JOIN 
      TCD.ControllerSetupData CsdComport 
      ON CsdComport.FieldId=Tcf.ComportNumber 
      AND CsdComport.ControllerId = Ctrl.ControllerId
   LEFT JOIN 
      TCD.ControllerSetupData CsdWebFtp 
      ON CsdWebFtp.FieldId=Tcf.WebportFtpEnabled 
      AND CsdWebFtp.ControllerId = Ctrl.ControllerId
   LEFT JOIN 
      TCD.ControllerSetupData CsdWebIP 
      ON CsdWebIP.FieldId=Tcf.WebportIP 
      AND CsdWebIP.ControllerId = Ctrl.ControllerId
   LEFT JOIN 
      TCD.ControllerSetupData CsdWebLogin 
      ON CsdWebLogin.FieldId=Tcf.WebportLogin 
      AND CsdWebLogin.ControllerId = Ctrl.ControllerId
   LEFT JOIN 
      TCD.ControllerSetupData CsdWebPwd 
      ON CsdWebPwd.FieldId=Tcf.WebportPassword 
      AND CsdWebPwd.ControllerId = Ctrl.ControllerId

   WHERE 
      Ctrl.Active=1 
    AND  Ctrl.IsDeleted=0

  
 END
----------------------------------------------- User Story - 139521 ------end---------------------------------------------------------------------------
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMitsubishiStepSaveData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMitsubishiStepSaveData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE Procedure [TCD].[ProcessMitsubishiStepSaveData](@ControllerID int, 
              @VxML XML,
              @RedFlagShiftId INT OUTPUT
             )
AS
BEGIN
   DECLARE 
   @MachineNumber int,
   @StepNumber int,
   @StartDateTime DateTime,
   @EndDateTime  DateTime,
   @ProgramNumber int,
   @Load decimal(10,2),
   @NominalLoad decimal(10,2),
   @CustomerNumber int,
   @WaterConsumption1 int,
   @WaterConsumption2 int,
   @PHStatus int,
   @PHValue int,
   @TemperatureMin int,
   @TemperatureMax int,
   @TempMinStatus int,
   @TempMaxStatus int,
   @BatchNumber int,
   @WasherID int,
   @WasherGroupID int,
   @EcoLabWasherID int,
   @ProgramMasterID int,
   @PlantWasherNumber int,
   @ShiftID int,
   @ParameterID int,
   @BatchID int,
   @ShiftStartdate DateTime,
   @ShiftName nvarchar(50),
   @PreviousStep int,
   @XMLDataID int,
   @LastStep int,
   @CurrentStep int,
   @CurrentStepTime DateTime,
   @MinTempParamID int,
   @MaxTempParamID int,
   @MinTempStatuParamID int,
   @MaxTempStatusParamID int,
   @PHStatusParamID int ,
   @PHValueParamID int,
   @Runtime int,
   @ErrorMessage nvarchar(max),
   @StepDuration int,
   @BatchStartDateTime DateTime,
   @MinStepNo int,
   @StepStartTime  DateTime,
   @MaxWashertGroupCapacity int,
   @WashStep int,
   @CoolDownFactor int
   


   
   SELECT @XMLDataID =  Scope_Identity()

 SELECT @MachineNumber=T.c.value('@MachineNumber', 'INT'),
   @StepNumber=T.c.value('@StepNumber', 'INT'),
   @StartDateTime=T.c.value('@StartDateTime', 'DateTime'),
   @EndDateTime=T.c.value('@EndDateTime', 'DateTime'),
   @ProgramNumber=T.c.value('@ProgramNumber', 'INT'),
   @Load=T.c.value('@Load', 'decimal(10,2)'),
   @NominalLoad=T.c.value('@NominalLoad', 'decimal(10,2)'),
   @CustomerNumber=T.c.value('@CustomerNumber', 'INT'),
   @WaterConsumption1=T.c.value('@WaterConsumption1', 'INT'),
   @WaterConsumption2=T.c.value('@WaterConsumption1', 'INT'),
   @PHStatus=T.c.value('@PHStatus', 'INT'),
   @PHValue=T.c.value('@PHValue', 'INT'),
   @TemperatureMin=T.c.value('@TemperatureMin', 'INT'),
   @TemperatureMax=T.c.value('@TemperatureMax', 'INT'),
   @TempMaxStatus=T.c.value('@TemperatureMaxStatus', 'INT'),
   @TempMinStatus=T.c.value('@TemperatreMinStatus', 'INT'),
   @BatchNumber=T.c.value('@BatchNumber', 'INT'),
   @Runtime =T.c.value('@Runtime','INT'),
   @StepDuration= T.c.value('@StepDuration','INT'),
   @CoolDownFactor= T.c.value('@CoolDown','INT')
 FROM @VxML.nodes('ConventionalWasherData') T(C)
 SELECT 
   @WasherGroupID=GroupId,
   @WasherID=WasherID
 FROM TCD.MachineSetup ms 
 WHERE ControllerID = @ControllerID
     and MachineInternalId= @MachineNumber
    and IsTunnel =0

    
      
 SELECT  @BatchID=BatchID,
   @ShiftID=ShiftId,
   @BatchStartDateTime = StartDate,
   @ProgramNumber=ProgramNumber,
   @ProgramMasterId=ProgramMasterId
 FROM TCD.BatchData 
 WHERE MachineInternalID = @MachineNumber
   and Year(StartDate) = year(@StartDateTime)
   and Month(StartDate) = month(@StartDateTime)
   and abs(Day(StartDate)-Day(@StartDateTime))<2
        
   and ControllerBatchId=@BatchNumber
      and MachineID =@WasherID

 If (@BatchID is Null)
 BEGIN
  SELECT @ErrorMessage = 'Batch Missing for Step Save'
        + ' Controller ID : ' + convert(nvarchar(10),@ControllerID)
        +' Washer Number  : '  + convert(nvarchar(10),@MachineNumber)
        + ' Batch Number : ' + convert(nvarchar(10),@BatchNumber)
  INSERT INTO TCD.Logs ([Date],[Thread],[Level],[Logger],[Message])
  Values(getdate(),'1','1','ReadStepSave',@ErrorMessage)
  return ;
 END

 IF (@WasherId is not null)
 BEGIN
 SELECT @EcoLabWasherID=EcolabWasherId,  
   @PlantWasherNumber=PlantWasherNumber
 FROM TCD.Washer Ws
    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
    INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
 WHERE Ws.WasherId=@WasherId 
   and Wps.ProgramNumber=@ProgramNumber 
   and Wps.Is_Deleted=0
 END

 
 DECLARE @ShiftMapping1 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
 INSERT INTO @ShiftMapping1(ShiftId,ShiftName,ShiftStartdate) 
 EXEC TCD.GetShiftStartDate @BatchStartDateTime,1,@RedFlagShiftId OUTPUT

 SELECT @ShiftID = ShiftID,
   @ShiftStartdate=ShiftStartdate,
   @ShiftName=ShiftName
 FROM @ShiftMapping1



  CREATE TABLE #Dosing(equipmentNo int, StepNo int,Qty decimal(18,4))
  INSERT INTO #Dosing
  SELECT   T.c.value('@Equipment', 'INT'),
     T.c.value('@stepNo', 'INT'),
     T.c.value('@Qty', 'decimal(18,4)')
  FROM @VxML.nodes('ConventionalWasherData/DosingData/Dosing') T(C)

  SELECT  @MaxWashertGroupCapacity=Max(ws.MaxLoad)
  FROM TCD.Washer WS
   INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
   INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId  
  WHERE Mst.GroupId=@WasherGroupID


   INSERT INTO TCD.BatchProductData(BatchId,StepCompartment,ActualQuantity,StandardQuantity,Price,[TimeStamp],PartitionOn,
            EcolabWasherId,ProductId,InjectionNumber)
   SELECT Bd.BatchId,
        Wds.StepNumber,
        dosing.Qty,
        ((Wps.NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100) AS StandardQuantity,      
        ((Wps.NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * @MaxWashertGroupCapacity)/CONVERT(decimal(10,2), 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price,         
        @BatchStartDateTime,
        @ShiftStartdate,
        @EcolabWasherId,
        Pdm.ProductID,
        dosing.StepNo
      FROM TCD.Washer WS
       INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
       INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
       INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
       INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
       INNER JOIN TCD.WasherDosingSetup Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
       INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
       INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Wdpm.ProductId
       INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
       INNER JOIN TCD.ControllerEquipmentSetup CES  on CES.ProductId =  Pdm.ProductId
                   and CES.ControllerID = @ControllerID
       INNER JOIN #Dosing dosing  on CES.ControllerEquipmentId = dosing.equipmentNo
               and Wdpm.InjectionNumber = dosing.StepNo
      WHERE  Ws.WasherId=@WasherId     
        AND  Wps.ProgramNumber=@ProgramNumber AND 
        Bd.BatchId=@BatchID

     SELECT @WashStep=StepCompartment
     FROM TCD.BatchProductData
     WHERE BatchID = @BatchID
       and InjectionNumber = @StepNumber

  SELECT Top 1 @StepStartTime = EndTime
  FROM TCD.BatchWashStepData
  WHERE BatchID = @BatchID
  ORDER BY StepCompartment desc

  IF (@StepStartTime is null) SELECT @StepStartTime=@BatchStartDateTime 

  INSERT INTO TCD.BatchWashStepData
  (BatchId,StepCompartment,StartTime,EndTime,
  PartitionOn,EcolabWasherId)
  SELECT @BatchID,
    isNull(@WashStep,@StepNumber),
    @StepStartTime,
    DateAdd(ss,@StepDuration,@StepStartTime) EndTime,
    @ShiftStartdate,
    @EcoLabWasherID
 IF (isNull(@Runtime,0) = 0)
 BEGIN
  Return 

 END 
 DELETE FROM @ShiftMapping1 
 
 INSERT INTO @ShiftMapping1(ShiftId,ShiftName,ShiftStartdate) 
 EXEC TCD.GetShiftStartDate @EndDateTime,1,@RedFlagShiftId OUTPUT

 SELECT @ShiftID = ShiftID,
   @ShiftStartdate=ShiftStartdate,
   @ShiftName=ShiftName
 FROM @ShiftMapping1
    
 UPDATE TCD.BatchData
 SET EndDate = @EndDateTime,
  ShiftId = @ShiftID
 WHERE BatchID = @BatchID 


 SELECT @MinTempParamID=Id 
 FROM [TCD].[ConduitParameters] 
 WHERE Name = 'Mimum Temperature' 

  
 SELECT @MaxTempParamID=Id 
 FROM [TCD].[ConduitParameters] 
 WHERE Name = 'Maximum Temperature'

 SELECT @MinTempStatuParamID=Id 
 FROM [TCD].[ConduitParameters] 
 WHERE Name = 'Temperature Status'

 
  
 SELECT @PHValueParamID=ID
 FROM [TCD].[ConduitParameters] 
 WHERE Name = 'PH'

  
 SELECT @PHStatusParamID=ID
 FROM [TCD].[ConduitParameters] 
 WHERE Name =  'PH Status'


 If (@TemperatureMin >0) 
 BEGIN
  INSERT INTO TCD.BatchParameters
  (BatchId,
   EcolabWasherId,
   ParameterId,
   ParameterValue,
   PartitionOn)
  VALUES(@BatchID,
    @EcoLabWasherID,
    @MinTempParamID,
    @TemperatureMin,
    @ShiftStartdate)
 END
 IF (isNull(@TemperatureMax,0) >0)
 BEGIN
  INSERT INTO TCD.BatchParameters
  (BatchId,
   EcolabWasherId,
   ParameterId,
   ParameterValue,
   PartitionOn)
  VALUES(@BatchID,
    @EcoLabWasherID,
    @MaxTempParamID,
    @TemperatureMax,
    @ShiftStartdate)
 END
 IF (@TempMinStatus>0) 
 BEGIN
  INSERT INTO TCD.BatchParameters
  (BatchId,
   EcolabWasherId,
   ParameterId,
   ParameterValue,
   PartitionOn)
  VALUES(@BatchID,
    @EcoLabWasherID,
    @MinTempStatuParamID,
    @TempMinStatus,
    @ShiftStartdate)
 END

 IF (@PHStatus > 0)
 BEGIN
  INSERT INTO TCD.BatchParameters
  (BatchId,
   EcolabWasherId,
   ParameterId,
   ParameterValue,
   PartitionOn)
  VALUES(@BatchID,
    @EcoLabWasherID,
    @PHStatusParamID,
    @PHStatus,
    @ShiftStartdate)
 END

 IF (isNull(@PHValue,0) > 0)
 BEGIN
  INSERT INTO TCD.BatchParameters
  (BatchId,
   EcolabWasherId,
   ParameterId,
   ParameterValue,
   PartitionOn)
  VALUES(@BatchID,
    @EcoLabWasherID,
    @PHValueParamID,
    @PHValue,
    @ShiftStartdate)
 END
 if (@WaterConsumption1 > 0)
 BEGIN
  INSERT INTO [TCD].[BatchStepWaterUsageData]
  (BatchId,StepCompartment,ActualQuantity,
   PartitionOn,EcolabWasherId
  )
  SELECT @BatchID,
   @WashStep,
   @WaterConsumption1 ActualQuantity,
   @ShiftStartdate,
   @EcoLabWasherID
 END
END
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessConventionalOnlineDataForEcontrolPlus]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessConventionalOnlineDataForEcontrolPlus]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
Create Procedure [TCD].[ProcessConventionalOnlineDataForEcontrolPlus](@ControllerID int, @VxML xML, @RedFlagShiftId INT OUTPUT)
AS
BEGIN
   DECLARE 
   @MachineNumber int,
   @StepNumber int,
   @StartDateTime DateTime,
   @EndDateTime  DateTime,
   @ProgramNumber int,
   @Load Decimal(10,2),
   @NominalLoad Decimal(10,2),
   @CustomerNumber int,
   @WaterConsumption1 int,
   @WaterConsumption2 int,
   @PHStatus int,
   @PHValue int,
   @TemperatureMin int,
   @TemperatureMax int,
   @TempMinStatus int,
   @TempMaxStatus int,
   @BatchNumber int,
      @WasherID int,
   @WasherGroupID int,
   @EcoLabWasherID int,
   @ProgramMasterID int,
   @PlantWasherNumber int,
   @ShiftID int,
   @ParameterID int,
   @PHParameterID int,
   @PHParameterStatus int,
   @BatchID int,
   @ShiftStartdate DateTime,
   @ShiftName nvarchar(50),
   @PreviousStep int,
   @XMLDataID int,
   @TempParameter int,
   @TemperatureMinParam int,
   @TemperatureMaxParam int,
   @TempMinStatusParam int,
   @TempMaxStatusParam int,
   @WashStepNo int,
   @CurrencyCode VARCHAR(50),
   @StdInjectionSteps INT,
   @StdWashSteps INT  


    Print  'Start Date Time --' + Convert(nvarchar(max),getDate(),121) 

 SELECT @PHParameterID=ID
 FROM TCD.ConduitParameters WHERE NAME ='pH'

 SELECT @PHParameterStatus=ID
 FROM TCD.ConduitParameters WHERE NAME ='PH Status'

 SELECT @TemperatureMinParam=ID
 FROM TCD.ConduitParameters WHERE NAME ='Mimum Temperature'

 SELECT @TemperatureMaxParam=ID
 FROM TCD.ConduitParameters WHERE NAME ='Maximum Temperature'

 SELECT @TempMinStatusParam=ID
 FROM TCD.ConduitParameters WHERE NAME ='Minimum Temperature Status'

 SELECT @TempMaxStatusParam=ID
 FROM TCD.ConduitParameters WHERE NAME ='Max Temperature Status'
 
 SELECT @WashStepNo=ID
 FROM TCD.ConduitParameters WHERE NAME ='StepCompartment No'
 
 SELECT @XMLDataID =  Scope_Identity()

 SELECT @MachineNumber=T.c.value('@MachineNumber', 'INT'),
   @StepNumber=T.c.value('@StepNumber', 'INT'),
   @StartDateTime=T.c.value('@StartDateTime', 'DATETIME'),
   @EndDateTime=T.c.value('@EndDateTime', 'DATETIME'),
   @ProgramNumber=T.c.value('@ProgramNumber', 'INT'),
   @Load=T.c.value('@Load', 'Decimal(10,2)')/10,
   @NominalLoad=T.c.value('@NominalLoad', 'Decimal(10,2)'),
   @CustomerNumber=T.c.value('@CustomerNumber', 'INT'),
   @WaterConsumption1=T.c.value('@WaterConsumption1', 'INT'),
   @WaterConsumption2=T.c.value('@WaterConsumption2', 'INT'),
   @PHStatus=T.c.value('@PHStatus', 'INT'),
   @PHValue=T.c.value('@PHValue', 'INT'),
   @TemperatureMin=T.c.value('@TemperatureMin', 'INT'),
   @TemperatureMax=T.c.value('@TemperatureMax', 'INT'),
   @TempMaxStatus=T.c.value('@TemperatureMaxStatus', 'INT'),
   @TempMinStatus=T.c.value('@TemperatreMinStatus', 'INT'),
   @BatchNumber=T.c.value('@BatchNumber', 'INT')
 FROM @VxML.nodes('MyControlConventionalData') T(C)

 
   DECLARE @ShiftMapping1 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
   INSERT INTO @ShiftMapping1(ShiftId,ShiftName,ShiftStartdate) 
   EXEC TCD.GetShiftStartDate @StartDateTime,1,@RedFlagShiftId OUTPUT

   SELECT @ShiftID = ShiftID,
      @ShiftStartdate=ShiftStartdate,
      @ShiftName=ShiftName
   FROM @ShiftMapping1
   
   
   SELECT 
     @WasherGroupID=GroupId,
     @WasherID=WasherID
   FROM TCD.MachineSetup ms 
   WHERE ControllerID = @ControllerID
      and MachineInternalId= @MachineNumber
      and IsTunnel =0

  IF  (@EndDateTime = '1/1/1900') 
   SELECT @EndDateTime= null
  
  IF (@StartDateTime ='1/1/1900')
   SELECT @StartDateTime= null

    IF (@WasherId is not null)
    BEGIN
   SELECT @EcoLabWasherID=EcolabWasherId,  
     @PlantWasherNumber=PlantWasherNumber,
     @ProgramMasterId=Wps.ProgramId,
     @CurrencyCode=P.CurrencyCode
   FROM TCD.Washer Ws
      INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
      INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
      INNER JOIN TCD.WasherProgramSetup Wps ON Wps.ControllerID = Wg.ControllerId
      INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.EcoLabAccountNumber
   WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@ProgramNumber and Wps.Is_Deleted=0
    END
      
   SELECT  @BatchID=BatchID 
   FROM TCD.BatchData 
   WHERE MachineInternalID = @MachineNumber
         and StartDate = @StartDateTime
       and ControllerBatchId=@BatchNumber
        and MachineID =@WasherID


   --Start Getting InjectionCount and StepCount
   SELECT
   @StdInjectionSteps=count(DISTINCT wdpm.WasherDosingSetupId),
   @StdWashSteps= count(DISTINCT wds.WasherDosingSetupId)-count(DISTINCT wdpm.WasherDosingSetupId)
   FROM TCD.WasherDosingProductMapping wdpm
   RIGHT JOIN TCD.WasherDosingSetup wds on wdpm.WasherDosingSetupId=wds.WasherDosingSetupId
   WHERE wds.ControllerID=@ControllerID AND wds.ProgramNumber=@ProgramNumber
   --End Getting InjectionCount and StepCount


   If (@BatchID is Null)
   BEGIN
      INSERT INTO TCD.BatchData(
           ControllerBatchID,
           EcolabWasherId,
           GroupId,
           MachineInternalId,
           PlantWasherNumber,
           StartDate,
           EndDate,
           ProgramNumber,
           ProgramMasterId,
           MachineID,
           ActualWeight,
           StandardWeight,
           CurrencyCode,
           ShiftId,
           PartitionOn,
           StdInjectionSteps,
           StdWashSteps)
           
    Values(@BatchNumber,
      @EcoLabWasherID,
      @WasherGroupID,
      @MachineNumber,
      @PlantWasherNumber,
      @StartDateTime,
      @EndDateTime,
      @ProgramNumber,
      @ProgramMasterId,
      @WasherID,
      @Load,
      @NominalLoad,
      @CurrencyCode,
      @ShiftID,
      @ShiftStartdate,
      @StdInjectionSteps,
      @StdWashSteps)
    SELECT @BatchID = Scope_Identity()
    print 'INSERTED Batch ID ' + Convert(nvarchar(10),@BatchID)

    INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchID,@EcoLabWasherID,38,@StdWashSteps,@ShiftStartdate

    --End Date  Time  is Null 
    UPDATE TCD.BatchData
    SET EndDate = getUTCDate()
    WHERE MachineInternalID = @MachineNumber
       and StartDate <> @StartDateTime
       and EndDate is Null
          and ControllerBatchId <> @BatchNumber
       and MachineId = @WasherId

   
   END 
 
   -- Program Number 
   IF (isNull(@ProgramNumber,0) >0)
   BEGIN
    SELECT  @ParameterID = [Id]
    FRom TCD.ConduitPArameters 
    WHERE Name='Formula Number'

    SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
            WasherId = @WasherID 
            AND ParameterID = @ParameterID 
            AND EcolabWasherId = @EcoLabWasherID 
            AND DateTimeStamp = @StartDateTime
            --AND ParameterValue = @ProgramNumber
            ORDER BY  DateTimeStamp DESC)

    IF (@TempParameter != @ProgramNumber)
    BEGIN
     print 'INSERT INTO Washer Reading'
     INSERT INTO TCD.WasherReading(WasherID,
              ParameterID,
              ParameterValue,
              DateTimeStamp,
              EcoLabWasherID,
              Partitionon)
     VALUES(@WasherID,
       @ParameterID,
       @ProgramNumber,
       getDate(),
       @EcoLabWasherID,
       @ShiftStartdate)
    END
   END      
   
   IF Not Exists(SELECT 1 FROM [TCD].[BatchCustomerData] WHERE BatchID = @BatchId 
         and @CustomerNumber is not Null)
   BEGIN
    print 'INSERT [BatchCustomerData]' 
    INSERT INTO [TCD].[BatchCustomerData] ([BatchId],CustomerID,[Weight],PartitionOn,EcolabWasherId)
    Values(@BatchID,@CustomerNumber,@Load,@ShiftStartdate,@EcolabWasherID)
   END 
   ELSE If (@CustomerNumber >0 ) 
   BEGIN
   print 'UPDATE [BatchCustomerData]' 
    UPDATE [TCD].[BatchCustomerData]
    SET CustomerID=@CustomerNumber,
    [Weight]=@Load
    WHERE BatchID = @BatchId 
   END
   Print  'End Date Time --' + Convert(nvarchar(max),getDate(),121) 

   -- PH Value
   SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
            WasherId = @WasherID 
            AND ParameterID = @PHParameterID 
            AND EcolabWasherId = @EcoLabWasherID 
            AND DateTimeStamp = @StartDateTime
            --AND ParameterValue = @ProgramNumber
            ORDER BY  DateTimeStamp DESC)

  IF (@TempParameter != @PHValue)
  BEGIN
   IF (@PHValue > 0)
   BEGIN
    INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
    SELECT @WasherID,@PHParameterID,@PHValue,GetUTCDate(),@ShiftStartdate,@EcolabWasherId
   END
  END 
  
  -- PH Status
  SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
            WasherId = @WasherID 
            AND ParameterID = @PHParameterStatus 
            AND EcolabWasherId = @EcoLabWasherID 
            AND DateTimeStamp = @StartDateTime
            --AND ParameterValue = @ProgramNumber
            ORDER BY  DateTimeStamp DESC)

  IF (@TempParameter != @PHStatus)
  BEGIN
   --IF (@PHStatus > 0)
   --BEGIN
    INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
    SELECT @WasherID,@PHParameterStatus,@PHStatus,GetUTCDate(),@ShiftStartdate,@EcolabWasherId
   --END
  END 

  -- Temperature Min Value
  SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
            WasherId = @WasherID 
            AND ParameterID = @TemperatureMinParam 
            AND EcolabWasherId = @EcoLabWasherID 
            AND DateTimeStamp = @StartDateTime
            --AND ParameterValue = @ProgramNumber
            ORDER BY  DateTimeStamp DESC)

  IF (@TempParameter != @TemperatureMin)
  BEGIN
   --IF (@PHStatus > 0)
   --BEGIN
    INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
    SELECT @WasherID,@TemperatureMinParam,@TemperatureMin,GetUTCDate(),@ShiftStartdate,@EcolabWasherId
   --END
  END 

   -- Temperature Max Value
  SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
            WasherId = @WasherID 
            AND ParameterID = @TemperatureMaxParam 
            AND EcolabWasherId = @EcoLabWasherID 
            AND DateTimeStamp = @StartDateTime
            --AND ParameterValue = @ProgramNumber
            ORDER BY  DateTimeStamp DESC)

  IF (@TempParameter != @TemperatureMax)
  BEGIN
   --IF (@PHStatus > 0)
   --BEGIN
    INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
    SELECT @WasherID,@TemperatureMaxParam,@TemperatureMax,GetUTCDate(),@ShiftStartdate,@EcolabWasherId
   --END
  END 

  -- Temperature Min Status
  SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
            WasherId = @WasherID 
            AND ParameterID = @TempMinStatusParam 
            AND EcolabWasherId = @EcoLabWasherID 
            AND DateTimeStamp = @StartDateTime
            --AND ParameterValue = @ProgramNumber
            ORDER BY  DateTimeStamp DESC)

  IF (@TempParameter != @TempMinStatus)
  BEGIN
   --IF (@PHStatus > 0)
   --BEGIN
    INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
    SELECT @WasherID,@TempMinStatusParam,@TempMinStatus,GetUTCDate(),@ShiftStartdate,@EcolabWasherId
   --END
  END 

  -- Temperature Max Status
  SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
            WasherId = @WasherID 
            AND ParameterID = @TempMaxStatusParam 
            AND EcolabWasherId = @EcoLabWasherID 
            AND DateTimeStamp = @StartDateTime
            --AND ParameterValue = @ProgramNumber
            ORDER BY  DateTimeStamp DESC)

  IF (@TempParameter != @TempMaxStatus)
  BEGIN
   --IF (@PHStatus > 0)
   --BEGIN
    INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
    SELECT @WasherID,@TempMaxStatusParam,@TempMaxStatus,GetUTCDate(),@ShiftStartdate,@EcolabWasherId
   --END
  END 

  -- StepCompartment No
  SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
            WasherId = @WasherID 
            AND ParameterID = @WashStepNo 
            AND EcolabWasherId = @EcoLabWasherID 
            AND DateTimeStamp = @StartDateTime
            --AND ParameterValue = @ProgramNumber
            ORDER BY  DateTimeStamp DESC)

  IF (@TempParameter != @StepNumber)
  BEGIN
   --IF (@PHStatus > 0)
   --BEGIN
    INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
    SELECT @WasherID,@WashStepNo,@StepNumber,GetUTCDate(),@ShiftStartdate,@EcolabWasherId
   --END
  END 
END
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessEcontrolPlusTunnelWasherOnlineData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessEcontrolPlusTunnelWasherOnlineData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessEcontrolPlusTunnelWasherOnlineData]
 (
 @ControllerID INT,
 @xmlTags xML,
 @RedFlagShiftId INT OUTPUT
)
AS
BEGIN
   DECLARE 
   @BatchID      INT,
   @WasherID      INT,
   @EcolabWasherId     INT,        
   @CurrencyCode     VARCHAR(50),  
   @MachineInternalId    INT,
   @WasherGroupID     INT,
   @PlantWasherNumber    INT,
   @BatchStartDate     DATETIME2,
   @BatchEndDate     DATETIME2,   
   @ProgramNumber     INT,
   @Load       Decimal(10,2),
   @NominalLoad     Decimal(10,2),
   @CustomerNumber     INT,
   @PHStatus      INT,
   @PHValue      INT,
   @LFStatus      INT,
   @LFValue      INT,
   @EjectionSignal     INT,
   @TextTileCategory    INT,
   @BatchNumber     INT,
   @TargetTurnTime     INT,
   @ShiftID      INT,
   @ParameterID     INT,   
   @ShiftName      VARCHAR(50),
   @EcolabAccountNumber NVARCHAR(25) = NULL,
   @PartitionOn DateTime,
   @BatchStartTime DateTime,
   @BatchEndTime DateTime,
   @PorgramParameterID int,
   @PHParameterID int,
   @PHParameterStatus int,
   @ConductivityParamID int,
   @ConductivityStatusParamID int,
   @RunTime int,
   @TextileCategory int,
   @ProgramID int,
   @NumberOfCompartments int,
   @TempParameter int,
   @CompartmentNoId int,
   @TransferSignalId int,
   @BatchShiftId int,
   @compartmentID int,
   @TunnelXML xml,
   @TempXML xml,
   @StdInjectionSteps INT,
   @StdWashSteps INT

    
 SELECT @CompartmentNoId=ID
 FROM TCD.ConduitParameters WHERE NAME ='StepCompartment No' 

 SELECT @TransferSignalId=ID
 FROM TCD.ConduitParameters WHERE NAME ='Transfer Signal'

 CREATE TABLE #Batches(BatchNumber int,StartDateTime DateTime)   
  
 SET @compartmentID = 1 
 
 SELECT @TempXML=T.c.query('.')  FROM   @xmlTags.nodes('MyControlTunnel') T(c)
 SELECT   @MachineInternalID=T.c.value('@MachineNumber', 'int') FROM @TempXML.nodes('MyControlTunnel')  T(c);

 SELECT 
   @EcolabWasherID=EcolabWasherId,
   @WasherGroupID= Wg.WasherGroupId,
   @PlantWasherNumber=PlantWasherNumber,
   @WasherID=ws.WasherId,
   @CurrencyCode=P.CurrencyCode,
   @NumberOfCompartments=Mst.NumberofComp
 FROM TCD.Washer Ws
   INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
   INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
   INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
   INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId = Mst.ControllerId
   INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.EcoLabAccountNumber
 WHERE  Ctrl.ControllerID = @ControllerID
   AND mst.MachineInternalId = @MachineInternalID
   AND Mst.IsTunnel = 1

 WHILE (@compartmentID <= @NumberOfCompartments)
 BEGIN
   
    SELECT @TunnelXML=T.c.query('.') 
  FROM   @xmlTags.nodes('MyControlTunnel/TunnelData') T(c)
  WHERE T.c.value('@CompartmentNumber', 'INT') = @compartmentID


   SELECT   @MachineInternalID=T.c.value('@MachineNumber', 'int'),
      @BatchNumber= T.c.value('@BatchNumber', 'INT'),
       @BatchStartTime=T.c.value('@StartDateTime', 'DateTime'),
      @BatchEndTime=T.c.value('@EndDateTime', 'DateTime'),
      @ProgramNumber=T.c.value('@ProgramNumber', 'INT'),
      @Load=T.c.value('@Load', 'Decimal(10,6)')/10,
      @NominalLoad=T.c.value('@Nominalload', 'Decimal(10,6)'),
      @CustomerNumber=T.c.value('@CustomerNumber', 'int'),
      @PHStatus=T.c.value('@pHStatus', 'int'),
      @PHValue=T.c.value('@pHValue', 'INT'),
      @LFStatus=T.c.value('@LFStatus', 'INT'),
      @LFValue=T.c.value('@LFValue', 'INT'),
      @RunTime=T.c.value('@RunTime', 'INT'),
      @EjectionSignal=T.c.value('@EjectionSignal', 'INT'),
      @TextileCategory=T.c.value('@TextileCategory', 'INT')
   FROM @TunnelXML.nodes('TunnelData')  T(c);
   

   IF (@ProgramNumber = 0 OR @BatchNumber=1) 
   BEGIN
      SELECT @compartmentID  = @compartmentID + 1
   Continue;
   END    
  

   SELECT @ProgramID=ProgramId,
    @TargetTurnTime= (3600 / (tps.TotalRunTime /@NumberOfCompartments )) 
   FROM TCD.TunnelProgramSetup AS tps 
   WHERE tps.WasherGroupId = @WasherGroupID 
      and tps.is_deleted =0
      and ProgramNumber = @ProgramNumber

   INSERT #Batches(BatchNumber,StartDateTime)
   SELECT @BatchNumber,@BatchStartTime

   --DELETE FROM  @ShiftStartDateTemp;
    
  SELECT @BatchID = Null
  SELECT @BatchID=BatchID FROM TCD.BatchData BD
   WHERE BD.ControllerBatchId = @BatchNumber
      AND BD.StartDate= @BatchStartTime
      AND BD.MachineId = @WasherID
      
  --Start Getting InjectionCount,StepCount And ProductCount
   SELECT @StdInjectionSteps= count(tdpm.TunnelDosingSetupId) ,
   @StdWashSteps= count(DISTINCT tds.TunnelDosingSetupId)-count(tdpm.TunnelDosingSetupId) 
   FROM tcd.TunnelDosingProductMapping tdpm
   RIGHT JOIN tcd.TunnelDosingSetup tds on tdpm.TunnelDosingSetupId=tds.TunnelDosingSetupId
   WHERE tds.GroupId=@WasherGroupID AND tds.ProgramNumber= @ProgramNumber
   --End Getting InjectionCount,StepCount And ProductCount

  IF (@BatchID is Null) 
  BEGIN

    DECLARE @ShiftStartDateTemp table(ShiftId INT,ShiftName NVARCHAR(50),ShiftStartdate DATETIME)
    INSERT INTO @ShiftStartDateTemp(ShiftId,ShiftName,ShiftStartdate) 
    EXEC TCD.GetShiftStartDate @BatchStartTime,1, @RedFlagShiftId OUTPUT

    SELECT @BatchShiftId = ShiftID, @PartitionOn=ShiftStartdate, @ShiftName=ShiftName FROM @ShiftStartDateTemp    

    INSERT INTO TCD.BatchData(
            ControllerBatchId ,
            EcolabWasherId,
            GroupId ,
            MachineInternalId,
            PlantWasherNumber,
            StartDate ,
            ProgramNumber,
            ProgramMasterId,
            MachineId,
            ActualWeight,
            StandardWeight,
            CurrencyCode,
            ShiftId,
            PartitionOn,
            TargetTurnTime,
            StdInjectionSteps,
            StdWashSteps
         )
        SELECT @BatchNumber,
         @EcolabWasherID,
         @WasherGroupID,
         @MachineInternalID,
         @PlantWasherNumber,
         @BatchStartTime,
         @ProgramNumber,
         @ProgramID,
         @WasherID,
         @Load,
         @NominalLoad,
         @CurrencyCode,
         @BatchShiftId,
         @PartitionOn,
         @TargetTurnTime,
         @StdInjectionSteps,
         @StdWashSteps

  SELECT @BatchID=Scope_Identity() 

  INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue,PartitionOn) SELECT @BatchID,@EcolabWasherId,38,@StdWashSteps, @PartitionOn  

  IF(@CustomerNumber is not null)
  BEGIN
    IF NOT Exists(SELECT 1 FROM [TCD].[BatchCustomerData] WHERE BatchID = @BatchID)
    BEGIN
    INSERT INTO [TCD].[BatchCustomerData] ([BatchId],CustomerID,[Weight],PartitionOn,EcolabWasherId)
    SELECT @BatchID,@CustomerNumber,@Load,@PartitionOn,@EcolabWasherId
    END 
  END
   
  END 

  --IF (@BatchEndTime is Not Null and @BatchEndTime !='01/01/1900')
  --BEGIN
  --UPDATE TCD.BatchData
  --SET EndDate = @BatchEndTime
  --WHERE BATCHID = @BatchID
  --END 
  
  -- Transfer Signal
  INSERT INTO TCD.WasherReading(
   WasherId,
   ParameterId,
   ParameterValue,
   DateTimeStamp,
   PartitionOn,
   EcolabWasherId)
   SELECT @WasherID,
   @TransferSignalId,
   1,
   @BatchStartTime,
   @PartitionOn,
   @EcolabWasherId
  UNION ALL
   SELECT @WasherID,
   @TransferSignalId,
   0,
   @BatchStartTime,
   @PartitionOn,
   @EcolabWasherId

 

  ---- @Program Number
  --SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
  -- WasherId = @WasherID 
  -- AND ParameterID = @PorgramParameterID 
  -- AND EcolabWasherId = @EcolabWasherId 
  -- AND DateTimeStamp = @BatchStartTime
  -- --AND ParameterValue = @ProgramNumber
  -- ORDER BY  DateTimeStamp DESC)

  --IF (@TempParameter != @ProgramNumber)
  --BEGIN
  -- INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
  -- SELECT @WasherID,@PorgramParameterID,@ProgramNumber,@BatchStartTime,@PartitionOn,@EcolabWasherId
  --END 
  
   
  ---- Compartment No  
  --SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
  -- WasherId = @WasherID 
  -- AND ParameterID = @CompartmentNoId 
  -- AND EcolabWasherId = @EcolabWasherId 
  -- AND DateTimeStamp = @BatchStartTime
  -- --AND ParameterValue = @ProgramNumber
  -- ORDER BY  DateTimeStamp DESC)

  --IF (@TempParameter != @compartmentID)
  --BEGIN
  -- --IF (@LFValue > 0)
  -- --BEGIN
  --  INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
  --  SELECT @WasherID,@CompartmentNoId,@compartmentID,@BatchStartTime,@PartitionOn,@EcolabWasherId
  -- --END
  --END   

   EXEC TCD.UPDATEBatchWashStepForTunnel @TunnelXML,@WasherID,@BatchID, @BatchStartTime,@PartitionOn,@EcolabWasherId,@compartmentID

   SELECT @compartmentID= @compartmentID + 1 
 END    

 
 -- Last Step is not getting closed in Tunnel BatchWashStepData
 UPDATE BWD
 SET EndTime=GetUTCDate()
 FROM TCD.BatchWashStepData BWD
 INNER JOIN TCD.BatchData BD on BWD.BatchId = BD.BatchId
 WHERE BD.MachineId =@WasherID
              AND BWD.EndTime is Null
              AND Not Exists(SELECT 1 FROM #Batches t
                             WHERE t.BatchNumber = BD.ControllerBatchId
                             and t.StartDateTime =BD.StartDate)      
END

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetWasherBatchSummarizedData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetWasherBatchSummarizedData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[GetWasherBatchSummarizedData](
	@DashBoardId INT = NULL)
AS
	BEGIN
	    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	    SET NOCOUNT ON;
	    DECLARE   --@DashBoardId int = 1, 
	    @Washerid                INT      = NULL,
	    @Standardturntime        INT      = NULL,
	    @Machinenamedispalytype  SMALLINT = 0,
	    @OverNightBatchThreshold INT      = 7200, -- Seconds  
	    @EfficiencyType          INT;
	    SELECT
			 @EfficiencyType = ISNULL(EfficiencyCalcType, 1)
	    FROM tcd.Dashboard
	    WHERE DashboardId = @DashBoardId;
	    DECLARE @Dashboardmachinemapping TABLE
	    (
		    Id             INT,
		    GroupID        INT,
		    WasherId       INT,
		    WasherName     NVARCHAR(100),
		    WasherNumber   INT,
		    IsPLCConnected BIT,
		    DispenserName  VARCHAR(250)
	    );
	    DECLARE @AlarmByMachine TABLE
	    (
		    GroupID          INT,
		    WasherID         INT,
		    Alarm            BIT NULL,
		    AlarmDescription NVARCHAR(250)
	    );
	    DECLARE @BatchEndtimes TABLE
	    (
		    GroupID             INT,
		    WasherID            INT,
		    CurrentBatchEndTime INT NULL,
		    BatchEndTime        TIME
	    );
	    DECLARE @ShiftIds TABLE
	    (
		    ShiftId        INT,
		    ShiftStartDate DATETIME,
		    ShiftEndDate   DATETIME
	    );
	    DECLARE @Summarizeddata TABLE
	    (
		    GroupId                INT,
		    MachineId              INT,
		    WasherName             NVARCHAR(100),
		    WasherNumber           INT,
		    TargetLoad             FLOAT,
		    ActualLoad             FLOAT,
		    LoadEfficiency         FLOAT,
		    TimeEfficiency         FLOAT,
		    LostLoad               FLOAT,
		    Alarm                  BIT,
		    AlarmDescription       NVARCHAR(250),
		    WasherStatus           INT,
		    MachineNameDispalyType SMALLINT,
		    TargetTurnTime         INT,
		    DefaultIdleTime        INT,
		    IsPLCConnected         BIT,
		    DispenserName          VARCHAR(250),
		    LostBatches            DECIMAL(18, 6)
	    );
	    INSERT INTO @Dashboardmachinemapping
	    (
			 Id,
			 GroupID,
			 WasherId,
			 WasherName,
			 WasherNumber,
			 IsPLCConnected,
			 DispenserName
	    )
	    SELECT
			 ROW_NUMBER() OVER(ORDER BY MS.GroupID) AS Id,
			 MS.GroupId,
			 MS.WasherID,
			 MS.MachineName,
			 W.PlantWasherNumber AS                    WasherNumber,
			 (CASE
				 WHEN ISNULL(AD.IsActive, 0) = 0
				 THEN CAST(1 AS    BIT)
				 WHEN ISNULL(AD.IsActive, 0) = 1
				 THEN CAST(0 AS BIT)
			  END) AS                                  IsPLCConnected,
			 CAST(CC.ControllerNumber AS NVARCHAR)+' ('+CC.TopicName+
			 ')' AS                                    DispenserName
	    FROM
	    (
		   SELECT DISTINCT
				MachineId,
				DashboardId
		   FROM TCD.MonitorSetUpMapping
	    ) AS DM
	    INNER JOIN TCD.MachineSetup AS MS ON DM.MachineId = MS.WasherID
	    INNER JOIN tcd.Washer AS W ON MS.WasherId = W.WasherId
	    INNER JOIN TCD.Dashboard AS D ON DM.DashBoardId = D.DashBoardId
	    INNER JOIN TCD.ConduitController CC ON CC.ControllerId = MS.
	    ControllerId
	    LEFT JOIN TCD.AlarmData AD ON AD.ControllerId = MS.ControllerId
							    AND IsActive = 1
							    AND AD.AlarmCode = (CASE
												   WHEN
											   (
												  SELECT
													    VALUE
												  FROM TCD.
												  controllerSetupData CSD
													  LEFT
													  JOIN TCD.Field F ON F.Id = CSD.FieldId
												  WHERE F.
												  Label = 'Webport Ftp Enabled'
													   AND
													   CSD.ControllerId = AD.ControllerId
													   AND CC
													   .ControllerTypeId = 1
											   ) = 'true'
												   THEN 9002
												   ELSE 9001
											    END)
	    WHERE DM.DashboardId = @Dashboardid
			AND MS.IsDeleted = 0
			AND w.Is_Deleted = 0  
			-- Exclude Phony Washers from Efficiency calculation   
			AND ms.WasherId NOT IN
	    (
		   SELECT
				w.WasherId
		   FROM TCD.MachineSetup AS ms
			   INNER JOIN TCD.Washer AS w ON w.WasherId = ms.WasherId
									   AND ms.
									   EcoalabAccountNumber = w.EcoLabAccountNumber
		   WHERE(NULLIF(ms.ControllerId, 0) IS NULL
			    AND w.WasherMode = 0)
			   OR MS.IsPony = 1
	    );  
  
  
	    -- For efficiency calculations on shift wise  
	    IF(@EfficiencyType = 1)
		   BEGIN
			  INSERT INTO @ShiftIds
			  (
				    ShiftId,
				    ShiftStartDate,
				    ShiftEndDate
			  )
			  SELECT DISTINCT
				    ShiftId,
				    StartDateTime,
				    EndDateTime
			  FROM TCD.ProductionShiftData
			  WHERE GETUTCDATE() BETWEEN StartDateTime AND EndDateTime;   
			  -- WHERE ShiftId = 33 
		   END;
	    ELSE -- For efficiency calculations on Day wise  
		   BEGIN
			  INSERT INTO @ShiftIds
			  (
				    ShiftId,
				    ShiftStartDate,
				    ShiftEndDate
			  )
			  SELECT
				    ShiftId,
				    StartDateTime,
				    EndDateTime
			  FROM [TCD].ProductionShiftData
			  WHERE startdatetime > CAST(GETUTCDATE() AS DATE)
				   AND startdatetime < DATEADD(dd, 1, CAST(GETUTCDATE()
				   AS DATE))
			  ORDER BY
					 startdatetime;
		   END;
	    SELECT
			 *
	    INTO
		    #BatchData
	    FROM tcd.BatchData bd(NOLOCK)
	    WHERE bd.ShiftId IN
	    (
		   SELECT
				si.ShiftId
		   FROM @ShiftIds si
	    )
			AND bd.StandardWeight > 0
			AND bd.ActualWeight > 0
			AND bd.EndDate IS NOT NULL;
	    -- Efficiency for each batch   
	    SELECT
			 bd.BatchId,
			 W_1.WasherGroupID AS         GroupID,
			 W_1.WasherId AS              MachineID,
			 bd.ShiftId,
			 W_1.WasherNumber,
			 W_1.WasherName,
			 (bd.ActualWeight + ISNULL(BD.ManualInputWeight, 0)) AS
			                              ActualProduction,
			 bd.StandardWeight AS         StandardProduction,
			 CASE
				WHEN DATEDIFF(ss, bd.StartDate, ISNULL(bd.EndDate,
				GETDATE())) > @OverNightBatchThreshold
				THEN W_1.StandardRunTime
				ELSE DATEDIFF(ss, bd.StartDate, ISNULL(bd.EndDate,
				GETDATE()))
			 END AS                       ActualRunTime,
			 W_1.StandardRunTime,
			 TT.ActualTurnTime,
			 bd.TargetTurnTime AS         StandardTurnTime,
			 CASE
				WHEN W_1.WasherGroupTypeID = 1   
							  -- Conventional  
				THEN(CAST((W_1.Standardruntime + bd.TargetTurnTime) AS
							  FLOAT) / (CAST(CASE
											 WHEN DATEDIFF(ss,
											 bd.StartDate,
											 ISNULL(bd.EndDate,
											 GETDATE())) >
											 @OverNightBatchThreshold
											 THEN W_1.
											 StandardRunTime
											 ELSE DATEDIFF(ss,
											 bd.StartDate,
											 ISNULL(bd.EndDate,
											 GETDATE()))
										  END + CASE
												  WHEN TT.
												  ACTUALTURNTIME = 0
												  THEN bd.
												  TargetTurnTime
												  ELSE TT.
												  ACTUALTURNTIME
											   END AS FLOAT)))  
							  -- Tunnel  
				ELSE(CAST(NULLIF(W_1.Standardruntime, 0) AS FLOAT)) /
							  (CAST(CASE
									  WHEN DATEDIFF(second, bd.
									  StartDate, ISNULL(bd.
									  EndDate, GETDATE())) = 0
									  THEN W_1.Standardruntime
									  ELSE CASE
											 WHEN DATEDIFF(ss,
											 bd.StartDate,
											 ISNULL(bd.EndDate,
											 GETDATE())) >
											 @OverNightBatchThreshold
											 THEN W_1.
											 StandardRunTime
											 ELSE DATEDIFF(ss,
											 bd.StartDate,
											 ISNULL(bd.EndDate,
											 GETDATE()))
										  END
								   END AS FLOAT))
			 END AS                       TimeEfficiency,
			 ((CAST((bd.ActualWeight + ISNULL(BD.ManualInputWeight, 0))
			 AS    FLOAT) / CAST(NULLIF(bd.StandardWeight, 0) AS FLOAT))
			 * 100) AS                    LoadEfficiency,
			 CASE
				WHEN W_1.WasherGroupTypeID = 2
				THEN(100 * ((3600.00 / (CAST(CASE
										   WHEN DATEDIFF(second,
										   bd.StartDate, ISNULL(
										   bd.EndDate, GETDATE()))
										   = 0
										   THEN NULLIF(W_1.
										   Standardruntime, 0)
										   ELSE DATEDIFF(second,
										   bd.StartDate, ISNULL(
										   bd.EndDate, GETDATE()))
									    END AS FLOAT) / W_1.
									    NumberOfComp)) / (3600.00
									    / (CAST(NULLIF(W_1.Standardruntime,
									    0) AS FLOAT) / W_1.
									    NumberOfComp))))
				ELSE NULL
			 END AS                       TransferPerHr,  
			 --missedloads formulae
			 --------(((Actual Production/totalefficiency)*100)-actualproduction)
		
			 (CAST(CAST(bd.ActualWeight AS    DECIMAL(18, 6)) / (((CAST
			 ((bd.ActualWeight + ISNULL(BD.ManualInputWeight, 0)) AS
			 DECIMAL(18, 6)) / CAST(NULLIF(bd.StandardWeight, 0) AS
			 DECIMAL(18, 6))) * 100.0) * (CASE
									    WHEN W_1.
									    WasherGroupTypeID = 1   
									-- Conventional  
									    THEN(CAST((W_1.
									Standardruntime + bd.TargetTurnTime)
									AS DECIMAL(18, 6)) / (CAST(
									CASE
									    WHEN DATEDIFF(ss, bd.
									    StartDate, ISNULL(bd.
									    EndDate, GETDATE())) >
									    @OverNightBatchThreshold
									    THEN W_1.StandardRunTime
									    ELSE DATEDIFF(ss, bd.
									    StartDate, ISNULL(bd.
									    EndDate, GETDATE()))
									END + TT.ACTUALTURNTIME AS
									FLOAT)))  
									-- Tunnel  
									    ELSE(CAST(NULLIF(W_1.
									Standardruntime, 0) AS
									DECIMAL(18, 6))) / (CAST(CASE
														    WHEN
														    DATEDIFF(second,
														    bd.StartDate,
														    ISNULL(bd.EndDate,
														    GETDATE()))
														    = 0
														    THEN
														    W_1.Standardruntime
														    ELSE
														    CASE
															   WHEN
															   DATEDIFF(ss,
															   bd.StartDate,
															   ISNULL(bd.EndDate,
															   GETDATE()))
															   > @OverNightBatchThreshold
															   THEN
															   W_1.StandardRunTime
															   ELSE
															   DATEDIFF(ss,
															   bd.StartDate,
															   ISNULL(bd.EndDate,
															   GETDATE()))
														    END
														END
														AS DECIMAL(18,
														6)))
									END)) AS DECIMAL(18, 6)) *
									100.0) - CAST(bd.ActualWeight
									AS DECIMAL(18, 6)) AS
									MissedLoads,
			 (((CAST((bd.ActualWeight + ISNULL(BD.ManualInputWeight, 0))
			 AS    FLOAT) / CAST(NULLIF(bd.StandardWeight, 0) AS FLOAT))
			 * 100) * (CASE
						WHEN W_1.WasherGroupTypeID = 1   
					 -- Conventional  
						THEN(CAST((W_1.Standardruntime + bd.
					 TargetTurnTime) AS FLOAT) / (CAST(CASE
												    WHEN
												    DATEDIFF(ss,
												    bd.StartDate,
												    ISNULL(bd.EndDate,
												    GETDATE()))
												    > @OverNightBatchThreshold
												    THEN W_1.
												    StandardRunTime
												    ELSE
												    DATEDIFF(ss,
												    bd.StartDate,
												    ISNULL(bd.EndDate,
												    GETDATE()))
												END + TT.
												ACTUALTURNTIME AS FLOAT)))  
					 -- Tunnel  
						ELSE(CAST(NULLIF(W_1.Standardruntime, 0) AS
					 FLOAT)) / (CAST(CASE
									 WHEN DATEDIFF(second, bd.
									 StartDate, ISNULL(bd.EndDate,
									 GETDATE())) = 0
									 THEN W_1.Standardruntime
									 ELSE CASE
											WHEN DATEDIFF(ss,
											bd.StartDate,
											ISNULL(bd.EndDate,
											GETDATE())) >
											@OverNightBatchThreshold
											THEN W_1.
											StandardRunTime
											ELSE DATEDIFF(ss,
											bd.StartDate,
											ISNULL(bd.EndDate,
											GETDATE()))
										 END
								  END AS FLOAT))
					 END)) AS           TotalEfficiency,
			 W_1.MaxLoad
	    INTO
		    #BatchEfficiency
	    FROM #BatchData bd --FROM TCD.BatchData bd   
		    RIGHT OUTER JOIN
	    (
		   SELECT
				ms.EcoalabAccountNumber,
				ms.WasherId,
				ms.GroupId AS                 WasherGroupID,
				mg.WasherGroupTypeId AS       WasherGroupTypeID,
				w.EcolabWasherId,
				w.MaxLoad,
				ISNULL(ms.NumberOfComp, 0) AS NumberOfComp,
				CASE
				    WHEN MG.WASHERGROUPTYPEID = 1
				    THEN WSP.ProgramNumber
				    ELSE TPS.ProgramNumber
				END AS                        ProgramNumber,
				CASE
				    WHEN MG.WASHERGROUPTYPEID = 1
				    THEN WSP.ProgramId
				    ELSE TPS.ProgramId
				END AS                        ProgramId,
				CASE
				    WHEN MG.WASHERGROUPTYPEID = 1
				    THEN WSP.TotalRunTime
				    ELSE TPS.TotalRunTime
				END AS                        Standardruntime,
				w.PlantWasherNumber AS        WasherNumber,
				ms.MachineName AS             WasherName,
				mg.WasherGroupName AS         MachineGroup  
		   --mg.WasherGroupId AS MachineGroupID  
		   FROM TCD.MachineSetup AS ms(NOLOCK)
			   INNER JOIN TCD.Washer AS w(NOLOCK) ON w.
			   EcoLabAccountNumber = ms.EcoalabAccountNumber
											 AND w.WasherId =
											 ms.WasherId
			   INNER JOIN TCD.WasherGroup AS mg(NOLOCK) ON ms.GroupId =
			   mg.WasherGroupId
												  AND w.
												  EcoLabAccountNumber = mg.EcolabAccountNumber
			   LEFT OUTER JOIN TCD.WasherProgramSetup AS WSP(NOLOCK) ON
			   (WSP.WasherGroupId = mg.WasherGroupId
			    OR WSP.ControllerID = mg.ControllerId)
			   AND WSP.EcolabAccountNumber = mg.EcolabAccountNumber
			   AND WSP.Is_Deleted = 0 --AND WSP.WasherGroupId = ms.GroupId      
			   LEFT OUTER JOIN TCD.TunnelProgramSetup AS TPS(NOLOCK) ON
			   TPS.WasherGroupId = mg.WasherGroupId
			   AND TPS.EcolabAccountNumber = mg.EcolabAccountNumber
			   AND TPS.Is_Deleted = 0 --AND TPS.WasherGroupId = ms.GroupId   
			   RIGHT JOIN @Dashboardmachinemapping DM1 ON DM1.GroupID =
			   ms.GroupId
												 AND DM1.
												 WasherId = ms.WasherId
		   WHERE ms.IsTunnel = 0
			    AND ms.IsDeleted = 0
	    ) AS W_1 ON BD.GroupId = W_1.WasherGroupID
				 AND ISNULL(BD.EcolabWasherId, 0) = ISNULL(W_1.
				 EcolabWasherId, 0)
				 AND bd.MachineID = W_1.WasherId
				 AND BD.ProgramMasterId = W_1.ProgramId
				 AND BD.ProgramNumber = W_1.ProgramNumber
		    LEFT JOIN [TCD].[Turntime] TT ON ISNULL(BD.EcolabwasherID, 0)
		    = ISNULL(TT.EcolabWasherId, 0)
									  AND BD.batchid = TT.BatchID
	    WHERE DATEDIFF(ss, bd.StartDate, bd.EndDate) > (W_1.
	    Standardruntime * 10 / 100);
	    SELECT
			 DM.GroupID,
			 DM.WasherId AS                                     MachineID,
			 DM.WasherNumber,
			 DM.WasherName,
			 CAST(SUM(t.ActualProduction) AS FLOAT) AS          ActualProduction,
			 CAST(SUM(t.StandardProduction) AS FLOAT) AS
			                                                    StandardProduction,
			 SUM(t.ActualRunTime) AS                            ActualRuntime,
			 SUM(t.StandardRunTime) AS                          StandardRunTime,
			 (SUM(t.MissedLoads) / COUNT(DISTINCT t.BatchId)) AS
			                                                    MissedLoads,
			 (CAST(SUM(t.LoadEfficiency) AS    FLOAT) / COUNT(DISTINCT
			 t.BatchId)) AS                                     LoadEfficiency,
			 ((CAST(SUM(t.TimeEfficiency) AS    FLOAT) / COUNT(DISTINCT
			 t.BatchId)) * 100) AS                              TimeEfficiency,
			 ((CAST(SUM(t.LoadEfficiency) AS    FLOAT) / COUNT(DISTINCT
			 t.BatchId)) * (CAST(SUM(t.TimeEfficiency) AS FLOAT) /
			 COUNT(DISTINCT t.BatchId))) AS                     TotalEfficiency,
			 DM.IsPLCConnected AS                               IsPLCConnected,
			 DM.DispenserName,
			 (SUM(t.MissedLoads) / COUNT(DISTINCT t.BatchId)) / CASE
														 WHEN
														 MAX(t.MaxLoad)
														 = 0
														 THEN
														 1
														 ELSE
														 MAX(t.MaxLoad)
													  END AS
													  LostBatches
	    INTO
		    #MachineEfficiency
	    FROM @Dashboardmachinemapping DM
		    LEFT JOIN #BatchEfficiency t ON DM.GroupID = t.GroupId
									 AND dm.WasherId = t.
									 MachineId  
	    --AND t.ActualRunTime > (t.StandardRunTime * 10/100)  
	    GROUP BY
			   DM.GroupID,
			   DM.WasherId,
			   DM.WasherNumber,
			   DM.WasherName,
			   DM.IsPLCConnected,
			   DM.DispenserName;
	    INSERT INTO @AlarmByMachine
	    (
			 GroupID,
			 WasherID,
			 Alarm,
			 AlarmDescription
	    )
	    SELECT
			 AlarmByMachine.GroupID,
			 AlarmByMachine.WasherID,
			 AlarmByMachine.Alarm,
			 AlarmByMachine.AlarmDescription
	    FROM
	    (
		   SELECT
				ROW_NUMBER() OVER(PARTITION BY AD.MachineId ORDER BY
				AD.StartDate DESC) AS rownum,
				AD.IsActive AS        Alarm,
				AM.[Description] AS   AlarmDescription,
				AD.MachineId AS       WasherID,
				d.GroupID
		   FROM TCD.AlarmData AD
			   INNER JOIN TCD.AlarmGroupMaster AM ON AM.
			   AlarmGroupMasterId = AD.AlarmGroupMasterId
			   INNER JOIN @Dashboardmachinemapping d ON AD.MachineId =
			   D.WasherId
	    ) AS AlarmByMachine
	    WHERE rownum = 1;
	    INSERT INTO @BatchEndtimes
	    (
			 GroupID,
			 WasherID,
			 CurrentBatchEndTime,
			 BatchEndTime
	    )
	    SELECT
			 d.GroupID,
			 d.WasherId,
			 COUNT(CASE
					 WHEN bd.EndDate IS NULL
					 THEN 1
					 ELSE NULL
				  END) AS                    CurrentBatchEndTime,
			 CAST(MAX(bd.EndDate) AS TIME) AS BatchEndTime
	    FROM @DashboardMachineMapping d
		    INNER JOIN TCD.BatchData bd ON d.GroupID = bd.GroupId
									AND d.WasherId = bd.MachineId
	    WHERE bd.ShiftId IN
	    (
		   SELECT
				ShiftId
		   FROM @ShiftIds
	    )
	    GROUP BY
			   d.GroupID,
			   d.WasherId;
	    SELECT
			 @StandardTurnTime = ISNULL(ConStdTurnTime, 30)
	    FROM tcd.Plant;
	    SELECT
			 @StandardTurnTime = @StandardTurnTime + ISNULL(
			 TargetTurnTime, 0)
	    FROM tcd.Washer
	    WHERE WasherId = @WasherId;
	    SELECT
			 @MachineNameDispalyType = ISNULL(MachineNameDispalyType, 0)
	    FROM TCD.Dashboard D
	    WHERE D.DashboardId = @DashBoardId;
	    INSERT INTO @Summarizeddata
	    (
			 GroupId,
			 MachineId,
			 WasherName,
			 WasherNumber,
			 TargetLoad,
			 ActualLoad,
			 LoadEfficiency,
			 TimeEfficiency,
			 LostLoad,
			 Alarm,
			 AlarmDescription,
			 WasherStatus,
			 MachineNameDispalyType,
			 TargetTurnTime,
			 DefaultIdleTime,
			 IsPLCConnected,
			 DispenserName,
			 LostBatches
	    )
	    SELECT
			 me.GroupID,
			 me.MachineID,
			 me.WasherName,
			 me.WasherNumber,
			 me.StandardProduction AS TargetLoad,
			 me.ActualProduction AS   ActulaLoad,
			 me.LoadEfficiency,
			 me.TimeEfficiency,
			 me.MissedLoads AS        LostLoad,
			 ISNULL(abm.Alarm, 0) AS  Alarm,
			 abm.AlarmDescription,
			 CASE
				WHEN be.CurrentBatchEndTime = 1
				THEN 1
				WHEN CAST(GETUTCDATE() AS TIME) BETWEEN be.
				BatchEndTime AND DATEADD(Minute, @StandardTurnTime, be
				.BatchEndTime)
				THEN 2
				WHEN abm.Alarm = 1
				THEN 3
				ELSE 3
			 END AS                   WasherStatus,
			 @MachineNameDispalyType,
	    (
		   SELECT
				TargetTurnTime
		   FROM TCD.WASHER W
		   WHERE W.WasherId = ME.MachineID
	    ),
	    (
		   SELECT
				DefaultIdleTime
		   FROM TCD.WASHER W
		   WHERE W.WasherId = ME.MachineID
	    ),
			 me.IsPLCConnected,
			 me.DispenserName,
			 me.LostBatches
	    FROM #MachineEfficiency me
		    LEFT JOIN @AlarmByMachine abm ON ME.GroupID = abm.GroupID
									  AND ME.MachineID = ABM.
									  WasherID
		    LEFT JOIN @BatchEndtimes be ON me.GroupID = be.GroupID
									AND me.MachineID = be.
									WasherID;
	    SELECT
			 GroupId,
			 MachineId,
			 CASE @Machinenamedispalytype
				WHEN 0
				THEN CAST(WasherNumber AS VARCHAR(20))+' '+WasherName
				WHEN 1
				THEN WasherName
				WHEN 2
				THEN CAST(WasherNumber AS VARCHAR(20))
			 END AS WasherName,
			 WasherNumber,
			 TargetLoad,
			 ActualLoad,
			 LoadEfficiency,
			 TimeEfficiency,
			 (CASE
				 WHEN ISNULL(LostLoad, 0) < 0
				 THEN 0
				 ELSE LostLoad
			  END)  LostLoad,
			 Alarm,
			 AlarmDescription,
			 WasherStatus,
			 TargetTurnTime,
			 DefaultIdleTime,
			 IsPLCConnected,
			 DispenserName,
			 (CASE
				 WHEN ISNULL(LostBatches, 0) < 0
				 THEN 0
				 ELSE LostBatches
			  END)  LostBatches
	    FROM @Summarizeddata
	    ORDER BY
			   WasherNumber;  
  
  
	    ---- CleanUp  
	    DROP TABLE #BatchData;
	    DROP TABLE #BatchEfficiency;
	    DROP TABLE #MachineEfficiency;
	END;

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlAnalogData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlAnalogData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [TCD].[ProcessMyControlAnalogData](
	@ControllerID INT,
	@VxML         XML)
AS
	BEGIN
	    DECLARE @MachineID    INT,
			  @Sensorid     INT,
			  @SensorTypeId INT,
			  @Temperature  INT,
			  @PH           INT,
			  @TimeStamp    DATETIME,
			  @Readings     DECIMAL(18, 4),
			  @SensorType   VARCHAR(10);

	    -- Getting the current UTC time 
	    SELECT
			 @TimeStamp = GETUTCDATE();

	    -- 1.Extracting xml data 
	    -- 2.And joining with sensor table
	    -- 3.Getting specific Sensor id by passing machine id and controller id and is_deleted(active sensor's)
	    -- 4.CTE will return table of columns i.e sensorid,sensortype,temparature,ph values
	    --Conventional washer sensor readings

	    WITH TempData
		    AS (SELECT
					s.SensorId,
					s.SensorType,
					T.c.value('@Temperature', 'INT') temparature,
					T.c.value('@pH', 'INT')          ph
			   FROM @VxML.nodes('MyControlAnalogData/WEAnalogData') T(c)
				   INNER JOIN TCD.Sensor s ON MachineCompartment =
			   (
				  SELECT TOP 1
					    ms.WasherId
				  FROM tcd.MachineSetup ms
				  WHERE ms.MachineInternalId = T.c.value('@WENumber','INT')
				  AND ms.ControllerId = @ControllerID
				  AND ms.IsDeleted = 0
				  AND ms.IsTunnel = 0
			   )
				   AND s.ControllerID = @controllerid
				   AND s.Is_deleted = 0) 
		    -- inserting records into sensor reading table using merge statement
		    MERGE INTO tcd.sensorreading sr
		    USING
		    (
			   SELECT
					sensorid,
					sensortype,
					CASE
					    WHEN SensorType = 1
					    THEN Temparature		 --Temparature
					    WHEN SensorType = 2
					    THEN ph				 --PH
					END reading
			   FROM tempdata
		    ) temp
		    ON sr.sensorId = temp.sensorid
			  AND temp.reading =
		    (
			   SELECT TOP 1
					reading
			   FROM tcd.SensorReading
			   WHERE SensorId = temp.sensorid
			   ORDER BY
					  TimeStamp DESC
		    ) 

		    -- If records are not in the sensor reading tables
		    -- Sensor records are inserted depending on the sensor type	
	
			   WHEN NOT MATCHED AND(temp.reading <> ''
							    OR temp.reading <> NULL
							    OR temp.reading <> 0)
			   THEN INSERT(
						sensorid,
						reading,
						timestamp) VALUES
		    (
									   temp.sensorid,
									   temp.reading,
									   @TimeStamp
		    );
	END;


--------REPORTS - CURRENCY CONVERSION------------

--EXCHANGE RATE FUNCTION
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[FnCurrencyExchangeRate]'))
BEGIN
DROP FUNCTION [TCD].[FnCurrencyExchangeRate]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [TCD].[FnCurrencyExchangeRate]  
       (  
        @CurrencyCode nvarchar(100) = NULL,  
        @dtDate datetime  
       
       )  
RETURNS float  
AS   
BEGIN  
  
DECLARE 
  @ExchangeRate FLOAT  
  
 IF @CurrencyCode IS NULL  
  SET @CurrencyCode = ISNULL(@CurrencyCode,'USD')  
  
-- SET @dtDate = DATETIMEFROMPARTS(@year,@Month,1, 23, 59, 59, 0 )  
  
SELECT top 1 @ExchangeRate = RATE  
FROM TCD.CurrencyExchangeRate  
WHERE currencyCode = @CurrencyCode  and TargetCurrencyCode='USD' 
AND EffectiveExchangeRateDate <= @dtDate  order by EffectiveExchangeRateDate  desc
--AND EffectiveExchangeRateDate IN (  
--SELECT MAX(EffectiveExchangeRateDate) FROM TCD.CurrencyExchangeRate  
--WHERE currencyCode = @CurrencyCode  
--AND EffectiveExchangeRateDate <= @dtDate  
--)  
  
SET @ExchangeRate = ISNULL(NULLIF(@ExchangeRate, 0.00),1)  
  
  
RETURN (COALESCE(1/ NULLIF(@ExchangeRate,0), 0))  
  
END


GO
--OPERATION SUMMARY REPORT
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ReportOperationsSummary]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ReportOperationsSummary]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ReportOperationsSummary] 
/******************************************************************

DESCRIPTION  : Populating Operation Summary Report  data based on filters and views,sub views.


MODIFICATION HISTORY DETAILS: 
 21st Jan 2015 -  Kiran     -  Added Formula hierarchy -->Formula segment-->Formula category-->formula


REFERENC TABLES :
  Select * from TCD.Plant --Plant master
  Select * FROM TCD.PlantChain  --Master Plants
  Select * FROM TCD.PlantChainProgram
  Select * FROM TCD.ChainTextileCategory
  Select * FROM TCD.ProgramMaster
  Select * FROM TCD.EcolabTextileCategory  --Masters
  Select * FROM TCD.EcolabSaturation --Masters
  Select * FROM TCD.FormulaSegments --Masters

EXECUTION STATEMENT :

 EXEC [TCD].[ReportOperationsSummary] @startdate = '2015-01-11',@enddate = '2016-01-30',@Viewtype  = '8',@Subview = '22',
          @Drillvalue = '',@EcolabAccountNumber = '040242802',@MachineType = '', @MachineGroup  = '',@Machine  = '', 
          @EcolabCategory  = '',@ChainCategory  = '', @PlantFormula  = '', @ChainFormula = '', @Customer  = '',
          @SortColumnId  = 0,@SortDirection  = '',@CurrencyCode = '', @UserId = 1, @FormulaSegement ='',
          @FormulaCategory='',@Formula=''


*******************************************************************/
     @startdate datetime = '',
     @enddate datetime = '',
     @Viewtype Int = '',
     @Subview Int= '',
     @Drillvalue varchar(100)= '',
     @EcolabAccountNumber Nvarchar(25) = '',
     @MachineType VARCHAR(20)= '',  --Washer Group type
     @MachineGroup VARCHAR(MAX) = '',  --washer Group
     @Machine VARCHAR(MAX) = '',
     @EcolabCategory VARCHAR(MAX) = '', --EcolabcategoritextileID
     @ChainCategory VARCHAR(MAX) = '',  --Chain Texttilecategori ID
     @PlantFormula  VARCHAR(MAX) = '',
     @ChainFormula VARCHAR(MAX) = '',
     @Customer VARCHAR(MAX) = '',
     @SortColumnId int = 0,
     @SortDirection varchar(4) = '',
     @CurrencyCode varchar(3) = '',
     @UserId INT = NULL,
  @FormulaSegement VARCHAR(MAX)='', --Formula segment,
  @FormulaCategory VARCHAR(MAX)='', --Formula category
  @Formula VARCHAR(MAX)='' --Formula
AS   
BEGIN   
SET NOCOUNT ON

SELECT @CurrencyCode = ISNULL(um.CurrencyCode,0) FROM TCD.UserMaster um WHERE um.UserId = @UserId
    IF (COUNT(@CurrencyCode) <> 1)
    BEGIN
  SELECT @CurrencyCode = p.CurrencyCode FROM TCD.Plant P WHERE P.EcolabAccountNumber=@EcolabAccountNumber
    END
    
 SET @startdate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@startdate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@startdate AS time)) AS DateTime))
    SET @EndDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndDate AS time)) AS DateTime))
 --SELECT @startdate,@enddate

    DECLARE @ReportGenerated INT = 6, @Month INT = MONTH(GETDATE()),@NoOfLoads int
 --SELECT @Month

    --Inserting the record into Report History 
 INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)
 SELECT @EcolabAccountNumber,UM.UserId, UM.LoginName, GETUTCDATE(), @ReportGenerated,
 CASE WHEN @ReportGenerated = 6 THEN 'Generated Report : Operations Summary Report' END
 FROM TCD.UserMaster UM
 WHERE UM.EcolabAccountNumber = @EcolabAccountNumber AND UM.UserId = @UserId
    --Completed the record insertion into Report History */

 -- Return Table set
    DECLARE @resultSet Table
    (
      ShiftId Int,DateRange varchar(100),TotalLoad Decimal(18,2),Numberofbatches INT,ActualChemicalConsumption Decimal(18,2),
      TargetChemicalConsumption Decimal(18,2),ActualEnergyConsumption  Decimal(18,2),TargetEnergyConsumption Decimal(18,2),
      ActualWaterConsumption  Decimal(18,2),TargetWaterConsumption Decimal(18,2),ActualChemicalCost Decimal(18,2),ActualWaterCost Decimal(18,2),
      ActualEnergyCost Decimal(18,2),Viewtype varchar(100) , Subview varchar(100) , Id int        
    )

 --Machine types 
    DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))
    INSERT INTO @MachineTypeTable EXEC [TCD].[CharlistToTable] @MachineType,','

 --Washergroups 
    DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))
    INSERT INTO @WasherGroupTable EXEC [TCD].[CharlistToTable] @machineGroup,','  

 --Machine list
    DECLARE @MachineTable TABLE(Machine Varchar(100))
    INSERT INTO @MachineTable EXEC [TCD].[CharlistToTable] @Machine,','

 --Ecolab category
    DECLARE @EcolabCategoryTable TABLE(EcolabCategory Varchar(100))
    INSERT INTO @EcolabCategoryTable EXEC [TCD].[CharlistToTable] @EcolabCategory,','

 --Chain category
    DECLARE @ChainCategoryTable TABLE(ChainCategory Varchar(100))
    INSERT INTO @ChainCategoryTable EXEC [TCD].[CharlistToTable] @ChainCategory,','

 --Plant fomula
    DECLARE @PlantFormulaTable TABLE(PlantFormula Varchar(100))
    INSERT INTO @PlantFormulaTable EXEC [TCD].[CharlistToTable] @PlantFormula,','

 --chain formula
    DECLARE @ChainFormulaTable TABLE(ChainFormula Varchar(100))
    INSERT INTO @ChainFormulaTable EXEC [TCD].[CharlistToTable] @ChainFormula,','
 
 --customer 
    DECLARE @CustomerTable TABLE(Customer Varchar(100))
    INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','

 --Formula Segment --added by Kiran
 DECLARE @FormulaSegmentTable TABLE(FormulaSegment Varchar(1000))
    INSERT INTO @FormulaSegmentTable EXEC [TCD].[CharlistToTable] @FormulaSegement,','

 -----Formula category--------Start
 DECLARE @FormulaCategoryTable TABLE(FormulaCategory Varchar(1000),Type CHAR(1))
    INSERT INTO @FormulaCategoryTable(FormulaCategory) EXEC [TCD].[CharlistToTable] @Formulacategory,',' 
 
 --segregating Ecolab/Chain categories
 --UPDATE @FormulaCategoryTable SET TYPE=RIGHT(FormulaCategory,1),FormulaCategory=LEFT(FormulaCategory,LEN(FormulaCategory)-2)
 
 --Below 1000 Ecolab category
 UPDATE @FormulaCategoryTable SET TYPE='E' WHERE FormulaCategory<1000
 --Above 1000 consider as Chain category
 UPDATE @FormulaCategoryTable SET TYPE='C' WHERE FormulaCategory>=1000

 --Rollbacking to actual ID
 UPDATE @FormulaCategoryTable SET FormulaCategory=FormulaCategory-1000 WHERE TYPE='C'
 --SELECT * FROM @FormulaCategoryTable
 
 --SELECT * FROM @FormulaCategoryTable

 INSERT INTO @EcolabCategoryTable(EcolabCategory)
 SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='E' 

 INSERT INTO @ChainCategoryTable(ChainCategory)
 SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='C'

 --Value Assigning
 IF (EXISTS(SELECT * FROM @EcolabCategoryTable) AND @FormulaCategory!='')
 BEGIN
  SET @EcolabCategory=@FormulaCategory
 END
 IF (EXISTS(SELECT * FROM @ChainCategoryTable) AND @FormulaCategory!='')
 BEGIN
  SET @ChainCategory=@FormulaCategory
 END
 ---Formula category-------------------------End

 -----Formula Ecolab/Chain categories
 DECLARE @FormulaTable TABLE(Formula Varchar(1000),Type CHAR(1))
    INSERT INTO @FormulaTable(Formula) EXEC [TCD].[CharlistToTable] @Formula,','

 --segregating Ecolab/Chain categories
 --UPDATE @FormulaTable SET TYPE=RIGHT(Formula,1),Formula=LEFT(Formula,LEN(Formula)-2)
 /*
 --Below 1000 Ecolab category
 UPDATE @FormulaTable SET TYPE='E' WHERE Formula<1000
 --Above 1000 consider as Chain category
 UPDATE @FormulaTable SET TYPE='C' WHERE Formula>=1000

 --Rollbacking to actual ID
 UPDATE @FormulaTable SET Formula=Formula-1000 WHERE TYPE='C'
 */
 --Select * from @FormulaTable
 --Plant fomula   
    INSERT INTO @PlantFormulaTable(PlantFormula) 
 SELECT Formula FROM @FormulaTable --WHERE Type='E'
 --chain formula   
    INSERT INTO @ChainFormulaTable(ChainFormula) 
 SELECT Formula FROM @FormulaTable --WHERE Type='C'
 --SELECT * FROM @PlantFormulaTable
 --SELECT * FROM @ChainFormulaTable

 --Value Assigning
 IF (EXISTS(SELECT * FROM @PlantFormulaTable) AND @Formula!='')
 BEGIN
  SET @PlantFormula=@Formula
 END
 IF (EXISTS(SELECT * FROM @ChainFormulaTable) AND @Formula!='')
 BEGIN
  SET @ChainFormula=@Formula
 END
 --SELECT @PlantFormula,@ChainFormula
 -----Formula Segregation end

    DECLARE @actualproduction int,@uom int
    SELECT @uom =UM.UOMId FROM TCD.UserMaster AS UM WHERE UM.UserId = @UserId

    --Operation summary Table Declaration
    DECLARE @OperationSummaryTable TABLE 
  ( 
  [ShiftId] [int] NULL,[ShiftName] Varchar(100) NULL,RecordDate date,
  [MachineId] [int] NULL,[ProgramMasterId] [int] NULL,[EcolabWasherId] [int] NULL,
  ActualProduction [int] NULL,
  [NoOfLoads] [int] NULL,ActualChemicalConsumption Decimal(18,2),
  TargetChemicalConsumption Decimal(18,2),ActualEnergyConsumption  Decimal(18,2),TargetEnergyConsumption Decimal(18,2),
  ActualWaterConsumption  Decimal(18,2),TargetwaterConsumption Decimal(18,2),
  ActualChemicalCost decimal(18,2),ActualWaterCost decimal(18,2),ActualEnergyCost decimal(18,2),
  EcolabTextileId int,ChainTextileId int,ChainProgaramId int,CustomerId int,FormulaSegmentID INT        
        )

 --Operation summary Table Insertion
    INSERT INTO @OperationSummaryTable
  (
  [ShiftId] ,[ShiftName] ,RecordDate ,
  [MachineId] ,[ProgramMasterId],[EcolabWasherId],
  ActualProduction,
  [NoOfLoads],ActualChemicalConsumption,
  TargetChemicalConsumption,ActualEnergyConsumption ,TargetEnergyConsumption ,
  ActualWaterConsumption  ,TargetwaterConsumption ,
  ActualChemicalCost ,ActualWaterCost ,ActualEnergyCost ,
  EcolabTextileId ,ChainTextileId ,ChainProgaramId ,FormulaSegmentID,CustomerId
  )
  SELECT DISTINCT SPD.[ShiftId],PS.ShiftName, CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date),         
  SPD.[MachineId] ,SPD.[ProgramMasterId],SPD.[EcolabWasherId],
  
  CASE @uom WHEN 1 THEN SUM( DISTINCT ISNULL(spd.ActualProduction,0))
   WHEN 2 THEN ISNULL([TCD].[FnConsumptionOnMetrics](SUM( DISTINCT ISNULL(spd.ActualProduction,0)),'Weight',@UserId),0) END,         
  SUM(DISTINCT ISNULL(SPD.NoOfLoads,0)),SUM(ISNULL(SCD.ActualConsumption,0)),
  SUM(ISNULL(SCD.TargetConsumption,0)),SUM(ISNULL(SED.ActualConsumption,0)),SUM(ISNULL(SED.TargetConsumption,0)),
  SUM(ISNULL(SWD.ActualConsumption,0)),SUM(ISNULL(SWD.TargetConsumption,0)),
 -- SUM(ISNULL(SCD.ActualCost,0)),SUM(ISNULL(SED.ActualCost,0)),SUM(ISNULL(SWD.ActualCost,0)),      
    SUM(ISNULL(SCD.ActualCost,0)* ISNULL(Tcd.FnCurrencyExchangeRate(@CurrencyCode,@startdate),1)),
  SUM(ISNULL(SED.ActualCost,0)* ISNULL(Tcd.FnCurrencyExchangeRate(@CurrencyCode,@startdate),1)),
  SUM(ISNULL(SWD.ActualCost,0)* ISNULL(Tcd.FnCurrencyExchangeRate(@CurrencyCode,@startdate),1)),      
                 
  --SPD.EcolabTextileId,SPD.ChainTextileId,SPD.ChainProgaramId,
     
  CASE WHEN PM.PlantProgramId IS NOT NULL AND ChainPlant.EcolabTextileCategoryId IS NOT NULL 
	THEN ChainPlant.EcolabTextileCategoryId
	ELSE ETC1.TextileId 
    END AS EcolabTextileCategory,
  CASE WHEN PM.PlantProgramId IS NOT NULL THEN ChainPlant.ChainTextileCategoryId
  ELSE NULL END AS ChainTextilecategory, 
  PM.PlantProgramId,
  CASE WHEN PM.PlantProgramId IS NOT NULL THEN ChainPlant.FormulaSegmentId
  ELSE FS1.FormulaSegmentID END AS Formulasegment,
  SPD.CustomerId
           
  FROM 
  TCD.ShiftProductionDataRollup SPD 
  INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId 
  LEFT JOIN  TCD.ShiftChemicalDataRollup SCD  ON SPD.ShiftId = SCD.ShiftId AND SPD.MachineId = SCD.MachineId AND SPD.ProgramMasterId = SCD.ProgramMasterId
  LEFT JOIN TCD.ShiftEnergyDataRollup SED ON SED.ShiftId = SPD.ShiftId AND SED.MachineId = SPD.MachineId AND SED.ProgramMasterId = SPD.ProgramMasterId
  LEFT JOIN TCD.[ShiftWaterDataRollup] SWD ON SED.ShiftId = SPD.ShiftId AND SWD.MachineId = SPD.MachineId AND SWD.ProgramMasterId = SPD.ProgramMasterId
  INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId 
  --Added by Kiran
  LEFT OUTER JOIN
   (
   --IF Chain Plant
   SELECT PCP.PlantProgramId,PCP.PlantChainId,PCP.ChainTextileCategoryId,PCP.EcolabTextileCategoryId,
   PCP.FormulaSegmentId,PCP.EcolabSaturationId
   FROM TCD.PlantChainProgram PCP 
   LEFT OUTER JOIN TCD.ChainTextileCategory CTC ON CTC.TextileId=NULLIF(PCP.ChainTextileCategoryId,0)
   LEFT OUTER JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId=NULLIF(PCP.EcolabTextileCategoryId,0)
   LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=PCP.FormulaSegmentId
   LEFT OUTER JOIN TCD.EcolabSaturation ES ON ES.EcolabSaturationId=PCP.EcolabSaturationId
   )ChainPlant ON PM.PlantProgramId=ChainPlant.PlantProgramId

  LEFT OUTER JOIN TCD.EcolabTextileCategory ETC1 ON ETC1.TextileId=PM.EcolabTextileCategoryId
  LEFT OUTER JOIN TCD.FormulaSegments FS1 ON FS1.FormulaSegmentID=PM.FormulaSegmentId
  LEFT OUTER JOIN TCD.EcolabSaturation ES1 ON ES1.EcolabSaturationId=PM.EcolabSaturationId
  ----End

        WHERE SPD.MachineId NOT IN (SELECT ms.WasherId FROM TCD.MachineSetup AS ms WHERE ms.IsPony = 1)
  AND 
   CASE @StartDate                                                                                
   WHEN '' THEN 
    CASE WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
   ELSE 
    CASE WHEN PS.[StartDateTime]  >= @startdate AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
   END='TRUE'  
  AND
   CASE @MachineType   
   WHEN '' THEN 'TRUE'         
   ELSE                                                      
   CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
   MS.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable))) THEN 'TRUE' END                                                      
   END='TRUE' 
  AND
   CASE @machineGroup   
   WHEN '' THEN 'TRUE'         
   ELSE                                                      
   CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
   MS.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable)) THEN 'TRUE' END                                                      
   END='TRUE' 
  AND
   CASE @Machine   
   WHEN '' THEN 'TRUE'         
   ELSE                                                      
   CASE WHEN SPD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
   END='TRUE'   
  AND 
  /*   
   CASE @EcolabCategory   
   WHEN '' THEN 'TRUE'         
   ELSE                                                      
   CASE WHEN SPD.EcolabTextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                      
   END='TRUE' 
  AND      
   CASE @ChainCategory   
   WHEN '' THEN 'TRUE'         
   ELSE                                                      
   CASE WHEN SPD.ChainTextileId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END                                                      
   END='TRUE'
        AND
     
   CASE @PlantFormula   
   WHEN '' THEN 'TRUE'         
   ELSE                                                      
   CASE WHEN SPD.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                      
   END='TRUE'  
        AND    
   CASE @ChainFormula   
   WHEN '' THEN 'TRUE'         
   ELSE                                                      
   CASE WHEN SPD.ChainTextileId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END                                                      
   END='TRUE'
        AND 
  */  
   CASE @Customer   
   WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                      
   END='TRUE' 

  --Added by Kiran
  AND 
   CASE @EcolabCategory   
   WHEN '' THEN 'TRUE' 
   ELSE
    CASE WHEN PM.PlantProgramId IS NOT NULL THEN
      CASE WHEN ChainPlant.EcolabTextileCategoryId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                                                   
    ELSE 
    CASE WHEN ETC1.TextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable)  THEN 'TRUE'END 
   END  
   END='TRUE'                            
  AND 
   CASE @ChainCategory    
   WHEN '' THEN 'TRUE' 
    ELSE 
     CASE WHEN PM.PlantProgramId IS NOT NULL THEN
      CASE WHEN ChainPlant.ChainTextileCategoryId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END 
     ELSE 'TRUE' END                                                                                                                                     
   END='TRUE'
  AND    
   CASE @PlantFormula   
   WHEN '' THEN 'TRUE'         
   ELSE                                                      
   CASE WHEN SPD.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                      
   END='TRUE'
        AND    
   CASE @ChainFormula   
   WHEN '' THEN 'TRUE'         
   ELSE                                                      
    CASE WHEN PM.PlantProgramId IS NOT NULL THEN
      CASE WHEN ChainPlant.ChainTextileCategoryId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END 
    ELSE 'TRUE' END                                                        
   END='TRUE'
        AND 
   CASE @FormulaSegement                                                                                
   WHEN '' THEN  'TRUE'
   ELSE
    CASE WHEN PM.PlantProgramId IS NOT NULL THEN
     CASE WHEN ChainPlant.FormulaSegmentId IN (SELECT FormulaSegment FROM @FormulaSegmentTable) THEN 'TRUE' END                                                                                     
    ELSE 
     CASE WHEN FS1.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)  THEN 'TRUE'END   
    END                                                     
   END='TRUE'

  GROUP BY SPD.[ShiftId],PS.ShiftName,SPD.[MachineId] ,SPD.[ProgramMasterId],SPD.[EcolabWasherId],
  ChainPlant.ChainTextileCategoryId,ChainPlant.EcolabTextileCategoryId,
  SPD.ChainProgaramId,
  SPD.CustomerId,CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date),
  ChainPlant.FormulaSegmentId,PM.PlantProgramId,ETC1.TextileId,FS1.FormulaSegmentID
  
  --Kiran Added end
   
        /*    
  GROUP BY SPD.[ShiftId],PS.ShiftName,SPD.[MachineId] ,SPD.[ProgramMasterId],SPD.[EcolabWasherId],SPD.EcolabTextileId,         SPD.ChainTextileId,
  SPD.ChainProgaramId,
  SPD.CustomerId,CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date)--,PM.FormulaSegmentId
  */
  --UPDATE     @OperationSummaryTable SET FormulaSegmentID=1 WHERE ShiftId=4
  --UPDATE     @OperationSummaryTable SET FormulaSegmentID=2 WHERE ShiftId in(7,1027)
  --UPDATE     @OperationSummaryTable SET FormulaSegmentID=3 WHERE ShiftId=1026

    --SELECT * FROM @OperationSummaryTable
    SELECT @NoOfLoads =  SUM(NoOfLoads) 
  FROM ( SELECT SUM(OST.NoOfLoads) AS NoOfLoads FROM @OperationSummaryTable AS OST GROUP BY OST.ShiftId )  NoOfLoads
 
    IF(@Viewtype = 3) ---Ecolab Categories

    BEGIN
  ---EcoLabCategory
  IF(@Subview = 12)
  BEGIN
    INSERT INTO @resultSet
    (
    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id 
    )
    SELECT DISTINCT
    0
    ,EC.CategoryName
    ,SUM(SPD.ActualProduction)
    ,sum(NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,EC.TextileId
   FROM @OperationSummaryTable SPD LEFT JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
   GROUP BY EC.CategoryName,EC.TextileId
        END
  ---EcoLabFormula
  IF(@Subview = 17)
  BEGIN
   INSERT INTO @resultSet
    (
    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id 
    )
    SELECT 
      DISTINCT
    0, 
    PM.Name
    ,SUM(SPD.ActualProduction)
    ,sum( NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,0
    FROM @OperationSummaryTable SPD INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
      INNER JOIN TCD.ProgramMaster PM ON EC.TextileId = PM.EcolabTextileCategoryId AND SPD.ProgramMasterId = PM.ProgramId
    
   WHERE
    (
    CASE    
     WHEN @drillvalue='' THEN 'TRUE' 
     WHEN @drillvalue IS NULL THEN 'TRUE'  
     ELSE                                                    
      CASE WHEN EC.TextileId IN (@drillvalue) THEN 'TRUE' END            
     END='TRUE'
    )
   GROUP BY  PM.Name
  END
 END

 -- ************************ By Textile Category View ************************************************
 IF(@Viewtype = 4)
 BEGIN 
  --TextileCategory
  IF(@Subview = 15)
  BEGIN
    INSERT INTO @resultSet
    (
    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id 
    )
    SELECT DISTINCT
    0,
    CC.Name
    ,SUM(SPD.ActualProduction)
    ,sum( NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,CC.TextileId
    FROM @OperationSummaryTable SPD LEFT JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
    GROUP BY CC.Name,CC.TextileId
  END  
  --TextileFormula
  IF(@Subview = 18)
  BEGIN
    INSERT INTO @resultSet
    (
    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id 
    )
    SELECT DISTINCT       
    0, 
    PM.Name
    ,SUM(SPD.ActualProduction)
    ,sum( NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,0
    FROM @OperationSummaryTable SPD INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
      INNER JOIN TCD.ProgramMaster PM ON CC.TextileId = PM.ChainTextileId AND SPD.ProgramMasterId = PM.ProgramId
    
   WHERE
    (
    CASE    
     WHEN @drillvalue='' THEN 'TRUE' 
     WHEN @drillvalue IS NULL THEN 'TRUE'  
     ELSE                                                    
      CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END            
     END='TRUE'
    )
   GROUP BY PM.Name
  END
 END

 -- ******************************** Timeline View ***************************************************
 IF(@Viewtype = 1)
 BEGIN
  ---- By TimeLine - Day View
  IF(@Subview = 5)
  BEGIN 
   INSERT INTO @resultSet
    (
    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id 
    )
    SELECT DISTINCT
    0,
    SPD.ShiftName
     ,SUM(SPD.ActualProduction)
    ,sum( NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,0
     FROM @OperationSummaryTable SPD
    GROUP BY SPD.ShiftName
  END  
  ---- By TimeLine - Week View
  IF (@Subview = 4)
  BEGIN
   INSERT INTO @resultSet
    (
    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id 
    )
   SELECT DISTINCT
   0,
   --CAST(RecordDate AS nvarchar(100))
    CONVERT(VARCHAR(11),CONVERT(DATE,RecordDate),113)+' ('+LEFT(datename(dw,RecordDate),3)+')'
   ,SUM(SPD.ActualProduction)
   ,sum( NoOfLoads)
   ,SUM(ActualChemicalConsumption)
   ,SUM(TargetChemicalConsumption) 
   ,SUM(ActualEnergyConsumption)
   ,SUM(TargetEnergyConsumption)
   ,SUM(ActualWaterConsumption)
   ,SUM(TargetWaterConsumption)
   ,SUM(ActualChemicalCost)
   ,SUM(ActualWaterCost)
   ,SUM(ActualEnergyCost)
   ,@Viewtype 
   ,@Subview
   ,0
    FROM @OperationSummaryTable SPD
   GROUP BY DATEPART(weekday,RecordDate),RecordDate
  END
  
  ---- By TimeLine - Month View
  IF(@Subview = 3)
   BEGIN
   DECLARE @FirstDay date = (SELECT TOP 1 RecordDate FROM @OperationSummaryTable ORDER BY RecordDate)
   DECLARE @LastDay date = (SELECT TOP 1 RecordDate FROM @OperationSummaryTable ORDER BY RecordDate DESC)
   DECLARE @FirstSunday date = NULL,
   @LastSaturday date = NULL
          
   SELECT 
   @FirstSunday = CAST(DateAdd(dd, (8-DatePart(WEEKDAY, 
      DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)))%7, 
      DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)) AS DATE) 

    SELECT
     @LastSaturday = 
    DATEADD(dd,
     -DATEPART(WEEKDAY,
       DATEADD(dd, -DAY(DATEADD(month, 1, @LastDay)),
       DATEADD(month, 1, @LastDay))) ,
     DATEADD(dd, -DAY(DATEADD(MONTH, 1, @LastDay)), DATEADD(MONTH, 1, @LastDay)));

   WITH CTE(DateRange ,TotalLoad,Numberofbatches,ActualChemicalConsumption,TargetChemicalConsumption,
   ActualEnergyConsumption,TargetEnergyConsumption,ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,ActualEnergyCost)
   AS
   (
   SELECT        
    CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,-1,@FirstSunday)) = 7 
      AND (SELECT COUNT(1) FROM @OperationSummaryTable WHERE RecordDate < DATEADD(DD,-1,@FirstSunday)) = 0)
      THEN CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100))
      WHEN DATEADD(DD,-1,@FirstSunday) > CAST(GETDATE() AS DATE) 
      THEN
      CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @enddate, 101) AS nvarchar(100))
      ELSE
      CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) END As DateRange,
      SUM(SPD.ActualProduction)
    ,sum( NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)

     FROM @OperationSummaryTable SPD
    WHERE RecordDate < @FirstSunday AND RecordDate >= @FirstDay

        
    UNION ALL

  
    SELECT
        
    --CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100)) AS StartDate,
    --CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) AS EndDate,
      CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100))  + CHAR(13) + '-' +
     CASE WHEN CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) >
     CAST(Convert(varchar, DateAdd(dd, (1 - DatePart(dw, @enddate) + 1), @enddate), 101) AS nvarchar(100))
     THEN  CAST(Convert(varchar, DateAdd(dd, 1-1, @enddate), 101) AS nvarchar(100))
     ELSE CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) END
     As DateRange,
     SUM(SPD.ActualProduction)
    ,sum(NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
     ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    FROM @OperationSummaryTable SPD
       WHERE RecordDate BETWEEN @FirstSunday AND @LastSaturday
    GROUP BY Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101),
     Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101)
       
      UNION ALL

    SELECT 
     CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,1,@LastSaturday)) = 1 
    AND (SELECT COUNT(1) FROM @OperationSummaryTable WHERE RecordDate > DATEADD(DD,1,@LastSaturday)) = 0)
    THEN 
    CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) 
    ELSE
      CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @LastDay, 101) AS nvarchar(100)) END   As DateRange,
    SUM(SPD.ActualProduction)
    ,sum( NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
     ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    FROM @OperationSummaryTable SPD
    WHERE RecordDate > @LastSaturday AND RecordDate <= @LastDay
    )
    INSERT INTO @resultSet
     (
     ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
     TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
     ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
     ActualEnergyCost ,Viewtype, Subview,Id 
    )
    SELECT DISTINCT
    0,
    DateRange,
    TotalLoad,
    Numberofbatches,
    ActualChemicalConsumption,
    TargetChemicalConsumption,
    ActualEnergyConsumption,
    TargetEnergyConsumption,
    ActualWaterConsumption,
    TargetWaterConsumption,
    ActualChemicalCost,
    ActualWaterCost,
    ActualEnergyCost       
    ,@Viewtype 
    ,@Subview
     ,0
    FROM CTE
    WHERE TotalLoad IS NOT NULL

        END
  ---- By TimeLine - Quarter View
  IF(@Subview = 2)
  BEGIN
   DECLARE @QuarterYear VARCHAR(100) = YEAR(@enddate);
   INSERT INTO @resultSet
    (
    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id 
    )
   SELECT  DISTINCT
       0,
    DATENAME(MONTH, RecordDate) + ' ' + CAST( YEAR(RecordDate) as varchar) As DateRange,
    SUM(SPD.ActualProduction)
    ,sum( NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption) 
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,0
   FROM @OperationSummaryTable SPD
   GROUP BY  DATEPART(MONTH, RecordDate),DATENAME(MONTH, RecordDate),YEAR(RecordDate) 
  END   
  ---- By TimeLine - Year View
  IF(@Subview = 1)
  BEGIN
   DECLARE @Year VARCHAR(100) = RIGHT(YEAR(@enddate),2)
   INSERT INTO @resultSet
    (
    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id 
    )
   SELECT 
    0,
    CASE 'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10))
    WHEN 'Q1' THEN 'Jan' + RIGHT(YEAR(RecordDate),2) + '- Mar' + RIGHT(YEAR(RecordDate),2)
    WHEN 'Q2' THEN 'Apr' + RIGHT(YEAR(RecordDate),2) + '- Jun' + RIGHT(YEAR(RecordDate),2)
    WHEN 'Q3' THEN 'Jul' + RIGHT(YEAR(RecordDate),2) + '-Sep' + RIGHT(YEAR(RecordDate),2)
    WHEN 'Q4' THEN 'Oct' + RIGHT(YEAR(RecordDate),2) + '- Dec'+ RIGHT(YEAR(RecordDate),2)
    END AS DateRange,
    SUM(SPD.ActualProduction)
    ,sum( NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,0
   FROM @OperationSummaryTable SPD
   GROUP BY DATEPART(QUARTER, RecordDate),RIGHT(YEAR(RecordDate),2)
  order by cast( cast(RIGHT(YEAR(RecordDate),2) AS varchar ) +cast(  DATEPART(QUARTER, RecordDate) AS varchar) AS int)  
  END
    END

    -- ******************************** Location View ***************************************************
    IF(@Viewtype = 2)
    BEGIN
  --Plant
  IF(@Subview = 9)
  BEGIN
   WITH CTE(DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption,TargetChemicalConsumption,ActualEnergyConsumption,
   TargetEnergyConsumption,ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,ActualEnergyCost,WasherGroupId)
   AS
   (
   SELECT 
    WG.WasherGroupName,
    SUM(SPD.ActualProduction)
      ,sum(NoOfLoads)
      ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
     ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
      ,WG.WasherGroupId

   FROM @OperationSummaryTable SPD LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId
      LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId 
   GROUP BY WG.WasherGroupName,WG.WasherGroupId--,SPD.ShiftId
   ) 

    INSERT INTO @resultSet
    (
    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id 
    )
   SELECT 0, 
   DateRange,
   SUM(TotalLoad),
   SUM(Numberofbatches),
   SUM(ActualChemicalConsumption)
   ,SUM(TargetChemicalConsumption) 
   ,SUM(ActualEnergyConsumption)
   ,SUM(TargetEnergyConsumption)
   ,SUM(ActualWaterConsumption)
   ,SUM(TargetWaterConsumption)
   ,SUM(ActualChemicalCost)
   ,SUM(ActualWaterCost)
   ,SUM(ActualEnergyCost)
   ,@Viewtype 
   ,@Subview
   ,WasherGroupId
   FROM CTE 
   WHERE TotalLoad IS NOT NULL       
   GROUP BY DateRange,WasherGroupId
   END
  --WasherGroup
  IF(@Subview = 10)
  BEGIN
    WITH CTE(DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption,TargetChemicalConsumption,ActualEnergyConsumption,
    TargetEnergyConsumption,ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,ActualEnergyCost)
   AS
   (
   SELECT 
    CAST( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName as MachineName,
    SUM(SPD.ActualProduction)
      ,sum(NoOfLoads)
      ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)     
   FROM @OperationSummaryTable SPD 
   LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId
   LEFT JOIN TCD.Washer w on MS.WasherId=w.WasherId
   LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId 
   WHERE 
     (
      CASE @drillvalue   
       WHEN '' THEN 'TRUE'         
       ELSE                                                    
     CASE WHEN WG.WasherGroupId IN (@drillvalue) THEN 'TRUE' END            
       END='TRUE'
     )
    GROUP BY CAST( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName--,SPD.ShiftId
    )

    INSERT INTO @resultSet
    (
    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id 
    )
    SELECT  0, 
    DateRange,
    SUM(TotalLoad),
    SUM(Numberofbatches),
    SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,0
     FROM CTE 
    WHERE TotalLoad IS NOT NULL
    GROUP BY DateRange
  END
    END

    -- ******************************** ChainCategory View **********************************************
    IF(@Viewtype = 5)
    BEGIN
  --ChainCategory
  IF(@Subview = 16)
  BEGIN
   -- ToDo : Change this part for chaincategory
    INSERT INTO @resultSet
    (
    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id 
    )
    SELECT DISTINCT
    0,  
    CC.NAME,
    SUM(SPD.ActualProduction)
    ,sum( NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,CC.TextileId
    FROM
    @OperationSummaryTable SPD
    INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
    INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = PM.PlantProgramId
    INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId 
    Group by  CC.Name,CC.TextileId
  END
     --ChainFormula
  IF(@Subview = 19)
  BEGIN
   -- ToDo : Change this part for chaincategory
    INSERT INTO @resultSet
    (
    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id 
    )
    SELECT  DISTINCT
    0,
    PCP.PlantProgramName,
    SUM(SPD.ActualProduction)
    ,sum( NoOfLoads)
       ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,0
    FROM @OperationSummaryTable SPD
    INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
    INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = PM.PlantProgramId
    INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId 
     WHERE
    (
      CASE @drillvalue   
       WHEN '' THEN 'TRUE'         
       ELSE                                                    
       CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END            
       END='TRUE'
     )
    Group by  PCP.PlantProgramName,PCP.PlantProgramId
  END
 END

    -- ******************************** Customer View ***************************************************
 IF(@Viewtype = 6)
 BEGIN
  INSERT INTO @resultSet
  (
  ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
  TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
  ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
  ActualEnergyCost ,Viewtype, Subview,Id 
  )
  SELECT DISTINCT
  0,
  PC.CustomerName,
  SUM(SPD.ActualProduction)
  ,sum(NoOfLoads)
  ,SUM(ActualChemicalConsumption)
  ,SUM(TargetChemicalConsumption) 
  ,SUM(ActualEnergyConsumption)
  ,SUM(TargetEnergyConsumption)
  ,SUM(ActualWaterConsumption)
  ,SUM(TargetWaterConsumption)
  ,SUM(ActualChemicalCost)
  ,SUM(ActualWaterCost)
  ,SUM(ActualEnergyCost)
  ,@Viewtype 
  ,@Subview
  ,0
  FROM @OperationSummaryTable SPD  INNER JOIN TCD.PlantCustomer PC on PC.CustomerId = SPD.CustomerId
  GROUP BY PC.CustomerName
 END

 -- ******************************** Formula View **************************************************** 
 IF(@Viewtype = 7)
 BEGIN
  INSERT INTO @resultSet
  (
  ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
  TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
  ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
  ActualEnergyCost ,Viewtype, Subview,Id 
  )
  SELECT DISTINCT
  0,
  PM.Name,
  SUM(SPD.ActualProduction)
  ,sum( NoOfLoads)
  ,SUM(ActualChemicalConsumption)
  ,SUM(TargetChemicalConsumption) 
  ,SUM(ActualEnergyConsumption)
  ,SUM(TargetEnergyConsumption)
  ,SUM(ActualWaterConsumption)
  ,SUM(TargetWaterConsumption)
  ,SUM(ActualChemicalCost)
  ,SUM(ActualWaterCost)
  ,SUM(ActualEnergyCost)
  ,@Viewtype 
  ,@Subview
  ,0
  FROM @OperationSummaryTable SPD 
  INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
  Group by 
  PM.Name
   END
  
   -- ******************************** Formula Hierarchy**************************************************** 
 IF(@Viewtype = 8) --Formula Hierarchy
 BEGIN
   PRINT 'IN View'
   IF(@Subview =20)-- Formula Segment
   BEGIN
    PRINT 'IN subView'
    INSERT INTO @resultSet
    (
    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id 
    )
    SELECT DISTINCT
    0,
    FS.SegmentName,
    SUM(SPD.ActualProduction)
    ,sum( NoOfLoads)
       ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,SPD.FormulaSegmentID
    FROM @OperationSummaryTable SPD 
    INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
    LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=SPD.FormulaSegmentID
    Group by SPD.FormulaSegmentID,FS.SegmentName
  END
   IF(@Subview =21)-- Formula Categories
   BEGIN

--SELECT * FROM @OperationSummaryTable
    INSERT INTO @resultSet
    (
    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id 
    )
    --Chain Textile category
    SELECT DISTINCT
    0,
    CC.Name
    ,SUM(SPD.ActualProduction)
    ,sum( NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,CC.TextileId
    FROM @OperationSummaryTable SPD 
    LEFT JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
   WHERE SPD.FormulaSegmentID =@drillvalue OR isnull( @drillvalue,'')='' --CHain Textilecategory
    GROUP BY CC.Name,CC.TextileId

    UNION 
    --Ecolab Textile category
    SELECT DISTINCT
    0
    ,EC.CategoryName
    ,SUM(SPD.ActualProduction)
    ,sum( NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,EC.TextileId
   FROM @OperationSummaryTable SPD LEFT JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
   WHERE SPD.FormulaSegmentID = @drillvalue OR isnull( @drillvalue,'')='' ---Ecolab Textile categoriy
   GROUP BY EC.CategoryName,EC.TextileId

    END
   IF(@Subview=22) -- Formula
   BEGIN   
     DECLARE @ChaincategoryDrillValue INT
			IF(@Drillvalue>1000)
				SET @ChaincategoryDrillValue=@Drillvalue-1000
			 ELSE IF (@Drillvalue <1000)
				SET @ChaincategoryDrillValue=@Drillvalue+1000
			---End 
    INSERT INTO @resultSet
    (
    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id 
    )
    --chain TextileFormula
    SELECT DISTINCT       
    0, 
    PM.Name
    ,SUM(SPD.ActualProduction)
    ,sum( NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,PM.ProgramId
    FROM @OperationSummaryTable SPD     
    INNER JOIN TCD.ProgramMaster PM ON SPD.ProgramMasterId = PM.ProgramId
			WHERE  SPD.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable) 
				AND
				(  
				CASE      
				WHEN @drillvalue='' THEN 'TRUE'   
				WHEN @drillvalue IS NULL THEN 'TRUE'    
				ELSE                                                      
				CASE WHEN SPD.EcolabTextileId  IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				) --AND PM.NAME IS NOT NULL    
   
   GROUP BY PM.Name,PM.ProgramId
   UNION
   ---EcoLabFormula
   SELECT 
      DISTINCT
    0, 
    PM.Name
    ,SUM(SPD.ActualProduction)
    ,sum( NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,PM.ProgramId
    FROM @OperationSummaryTable SPD 
   INNER JOIN TCD.ProgramMaster PM ON  SPD.ProgramMasterId = PM.ProgramId    
			WHERE  SPD.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)
			AND 
				(  
				CASE      
				WHEN @drillvalue='' THEN 'TRUE'   
				WHEN @drillvalue IS NULL THEN 'TRUE'    
				ELSE                                                      
				CASE WHEN SPD.ChainTextileId IN (@ChaincategoryDrillValue) THEN 'TRUE' END              
				END='TRUE' 
				)
   GROUP BY  PM.Name,PM.ProgramId
    END
 END

   
   --- ********* Return result ********************

   --SELECT * FROM @resultSet

    SELECT DISTINCT
     ShiftId,
      DateRange,
     CASE @uom WHEN 1 THEN TotalLoad
            WHEN 2 THEN ISNULL([TCD].[FnConsumptionOnMetrics](TotalLoad,'Weight',@UserId),0) END AS ActualProduction,
      --CAST(TotalLoad AS int) AS ActualProduction,
      Numberofbatches AS NoOfLoads,
      ISNULL([TCD].[FnConsumptionOnMetrics](ActualChemicalConsumption,'Volume',@UserId),0) ActualChemicalConsumption,
      --ActualChemicalConsumption ,
      ISNULL([TCD].[FnConsumptionOnMetrics](TargetChemicalConsumption,'Volume',@UserId),0) TargetChemicalConsumption,
      --TargetChemicalConsumption,
      ActualEnergyConsumption,
      TargetEnergyConsumption,
      ActualWaterConsumption,
      TargetWaterConsumption,
      ActualChemicalCost,
      ActualWaterCost,
      ActualEnergyCost,
      Viewtype,
      Subview ,
      Id,
      --CASE @uom WHEN 1 THEN ActualChemicalConsumption 
      --WHEN 2 THEN ActualChemicalConsumption * 28.3495 END AS ActualChemicalConsumptionMetrics ,
      --CASE @uom WHEN 1 THEN TargetChemicalConsumption 
      --WHEN 2 THEN TargetChemicalConsumption * 28.3495 END AS TargetChemicalConsumption,
     CASE @uom WHEN 1 THEN TotalLoad/100 
            WHEN 2 THEN ISNULL([TCD].[FnConsumptionOnMetrics](TotalLoad,'Weight',@UserId),0) END AS ActualProductionMetrics      
      FROM 
        @resultSet
        WHERE [@resultSet].DateRange IS NOT NULL
    

SET NOCOUNT OFF
END


----CHEMICAL CONSUMPTION
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ReportChemicalConsumption]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ReportChemicalConsumption]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [TCD].[ReportChemicalConsumption]
/********************************************************************************************************


Execution Statement:
 EXECUTE [TCD].[ReportChemicalConsumption1]
   @startdate  = '2010-12-01',@enddate  = '2016-12-01',@EcolabAccountNumber = '',
   @MachineType = '',@MachineGroup  = '',@Machine  = '',
   @EcolabCategory = '',@ChainCategory  = '',@PlantFormula   = '',@ChainFormula  = '',
   @Customer  = '',@CurrencyCode='',@UserId  = 1,
   @FormulaSegement ='1',@FormulaCategory ='',@Formula ='' 



********************************************************************************************************/ 

 @startdate datetime = '',
 @enddate datetime = '',
 @EcolabAccountNumber Nvarchar(25) = '',
 @MachineType VARCHAR(20)= '',
 @MachineGroup VARCHAR(MAX) = '',
 @Machine VARCHAR(MAX) = '',
 @EcolabCategory VARCHAR(MAX) = '',
 @ChainCategory VARCHAR(MAX) = '',
 @PlantFormula  VARCHAR(MAX) = '',
 @ChainFormula VARCHAR(MAX) = '',
 @Customer VARCHAR(MAX) = '',
 @CurrencyCode varchar(3) = NULL,
 @UserId INT = NULL,
 @FormulaSegement VARCHAR(MAX)='', --Formula segment,
 @FormulaCategory VARCHAR(MAX)='', --Formula category
 @Formula VARCHAR(MAX)='' --Formula
AS   
BEGIN   
SET NOCOUNT ON 

 SET @startdate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@startdate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@startdate AS time)) AS DateTime))
    SET @EndDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndDate AS time)) AS DateTime))

    SELECT @CurrencyCode = ISNULL(um.CurrencyCode,0) FROM TCD.UserMaster um WHERE um.UserId = @UserId
    IF (COUNT(@CurrencyCode) <> 1)
    BEGIN
  SELECT @CurrencyCode = p.CurrencyCode FROM TCD.Plant P WHERE P.EcolabAccountNumber=@EcolabAccountNumber
    END

    DECLARE @ReportGenerated INT = 6,@Month INT = MONTH(GETDATE()),@NoOfLoads INT,@NoOfPrograms INT

 -- Inserting the record into Report History
 INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)
 SELECT @EcolabAccountNumber,UM.UserId,UM.LoginName, GETUTCDATE(),@ReportGenerated,
   CASE WHEN @ReportGenerated = 6
     THEN 'Generated Report : Chemical Consumption Report' 
   END
 FROM TCD.UserMaster UM
 WHERE UM.EcolabAccountNumber = @EcolabAccountNumber AND UM.UserId = @UserId
 
 --Declaraion of table variables
    DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))
    INSERT INTO @MachineTypeTable EXEC [TCD].[CharlistToTable] @MachineType,','

    DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))
    INSERT INTO @WasherGroupTable EXEC [TCD].[CharlistToTable] @machineGroup,','  

    DECLARE @MachineTable TABLE(Machine Varchar(100))
    INSERT INTO @MachineTable EXEC [TCD].[CharlistToTable] @Machine,','

    DECLARE @EcolabCategoryTable TABLE(EcolabCategory Varchar(100))
    INSERT INTO @EcolabCategoryTable EXEC [TCD].[CharlistToTable] @EcolabCategory,','

    DECLARE @ChainCategoryTable TABLE(ChainCategory Varchar(100))
    INSERT INTO @ChainCategoryTable EXEC [TCD].[CharlistToTable] @ChainCategory,','

    DECLARE @PlantFormulaTable TABLE(PlantFormula Varchar(100))
    INSERT INTO @PlantFormulaTable EXEC [TCD].[CharlistToTable] @PlantFormula,','

    DECLARE @ChainFormulaTable TABLE(ChainFormula Varchar(100))
    INSERT INTO @ChainFormulaTable EXEC [TCD].[CharlistToTable] @ChainFormula,','

    DECLARE @CustomerTable TABLE(Customer Varchar(100))
    INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','

 --Formula Segment 
 DECLARE @FormulaSegmentTable TABLE(FormulaSegment Varchar(1000))
    INSERT INTO @FormulaSegmentTable EXEC [TCD].[CharlistToTable] @FormulaSegement,','

 --Formula category
 DECLARE @FormulaCategoryTable TABLE(FormulaCategory Varchar(1000),Type CHAR(1))
    INSERT INTO @FormulaCategoryTable(FormulaCategory) EXEC [TCD].[CharlistToTable] @Formulacategory,',' 
  
  --Assuming Below 1000 Ecolab category --Drop down also they have to listed same way
  UPDATE @FormulaCategoryTable SET TYPE='E' WHERE FormulaCategory<1000
  --Above 1000 consider as Chain category--for chain category they need to Append in Drop down filters
  UPDATE @FormulaCategoryTable SET TYPE='C' WHERE FormulaCategory>=1000

  --Rollbacking to actual ID
  UPDATE @FormulaCategoryTable SET FormulaCategory=FormulaCategory-1000 WHERE TYPE='C'
   
  --SELECT * FROM @FormulaCategoryTable

  INSERT INTO @EcolabCategoryTable(EcolabCategory)
  SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='E' 

  INSERT INTO @ChainCategoryTable(ChainCategory)
  SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='C'

  --Value Assigning
  IF (EXISTS(SELECT * FROM @EcolabCategoryTable) AND @FormulaCategory!='')
  BEGIN
   SET @EcolabCategory=@FormulaCategory
  END
  IF (EXISTS(SELECT * FROM @ChainCategoryTable) AND @FormulaCategory!='')
  BEGIN
   SET @ChainCategory=@FormulaCategory
  END

 
 --Formula Ecolab/Chain categories
 DECLARE @FormulaTable TABLE(Formula Varchar(1000),Type CHAR(1))
    INSERT INTO @FormulaTable(Formula) EXEC [TCD].[CharlistToTable] @Formula,','
  
  --Select * from @FormulaTable
  --Plant fomula   
  INSERT INTO @PlantFormulaTable(PlantFormula) 
  SELECT Formula FROM @FormulaTable 
  --chain formula   
  INSERT INTO @ChainFormulaTable(ChainFormula) 
  SELECT Formula FROM @FormulaTable  

  --Value Assigning
  IF (EXISTS(SELECT * FROM @PlantFormulaTable) AND @Formula!='')
  BEGIN
   SET @PlantFormula=@Formula
  END
  IF (EXISTS(SELECT * FROM @ChainFormulaTable) AND @Formula!='')
  BEGIN
   SET @ChainFormula=@Formula
  END
  --SELECT @PlantFormula,@ChainFormula
 
 DECLARE @actualproduction decimal(18,2),@uom int
    SELECT @uom =UM.UOMId FROM TCD.UserMaster AS UM WHERE UM.UserId = @UserId
 
 --FInding Actual Production
 SELECT @actualproduction =
    CASE @uom 
     WHEN 1 THEN sum(ISNULL(spdr.ActualProduction,0))/100.00 
     WHEN 2 THEN ISNULL([TCD].[FnConsumptionOnMetrics](sum(ISNULL(spdr.ActualProduction,0)),'Weight',@UserId),0) 
    END    
 FROM tcd.ShiftProductionDataRollup spdr
 INNER JOIN TCD.ProductionShiftData AS PS ON PS.ShiftId = spdr.ShiftId 
  INNER JOIN tcd.machinesetup ms ON ms.WasherId=spdr.MachineId
 --Added by Kiran For Formula Hierarchy
 INNER JOIN TCD.ProgramMaster PM on SPDR.ProgramMasterId = PM.ProgramId 
 LEFT OUTER JOIN
   (
   --IF Chain Plant
   SELECT PCP.PlantProgramId,PCP.PlantChainId,PCP.ChainTextileCategoryId,PCP.EcolabTextileCategoryId,
   PCP.FormulaSegmentId,PCP.EcolabSaturationId
   FROM TCD.PlantChainProgram PCP 
   LEFT OUTER JOIN TCD.ChainTextileCategory CTC ON CTC.TextileId=PCP.ChainTextileCategoryId
   LEFT OUTER JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId=PCP.EcolabTextileCategoryId
   LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=PCP.FormulaSegmentId
   LEFT OUTER JOIN TCD.EcolabSaturation ES ON ES.EcolabSaturationId=PCP.EcolabSaturationId
   )ChainPlant ON PM.PlantProgramId=ChainPlant.PlantProgramId

 LEFT OUTER JOIN TCD.EcolabTextileCategory ETC1 ON ETC1.TextileId=PM.EcolabTextileCategoryId
 LEFT OUTER JOIN TCD.FormulaSegments FS1 ON FS1.FormulaSegmentID=PM.FormulaSegmentId
 LEFT OUTER JOIN TCD.EcolabSaturation ES1 ON ES1.EcolabSaturationId=PM.EcolabSaturationId
 ----End

    WHERE isnull(ms.IsPony,0)=0 and

       CASE @StartDate                                                                                
       WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
       ELSE CASE WHEN PS.[StartDateTime] >= @startdate AND PS.[StartDateTime] <=  @enddate THEN 'TRUE'END                                                        
       END='TRUE'
     AND
       CASE @MachineType   
       WHEN '' THEN 'TRUE'         
       ELSE                                                      
       CASE WHEN spdr.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
       MS.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable))) THEN 'TRUE' END                                                      
       END='TRUE'    
    AND    
        CASE @machineGroup   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN spdr.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
        MS.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable)) THEN 'TRUE' END                                                      
        END='TRUE' 
    AND
        CASE @Machine   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN spdr.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
        END='TRUE' 
    AND
  
    
        CASE @Customer   
        WHEN '' THEN 'TRUE'         
           ELSE                                                      
           CASE WHEN spdr.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                      
        END='TRUE' 
  --Added by Kiran
 AND 
  CASE @EcolabCategory   
  WHEN '' THEN 'TRUE' 
  ELSE
   CASE WHEN PM.PlantProgramId IS NOT NULL THEN
     CASE WHEN ChainPlant.EcolabTextileCategoryId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                                                   
   ELSE 
   CASE WHEN ETC1.TextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable)  THEN 'TRUE'END 
  END  
  END='TRUE'                            
 AND 
  CASE @ChainCategory    
  WHEN '' THEN 'TRUE' 
   ELSE 
    CASE WHEN PM.PlantProgramId IS NOT NULL THEN
     CASE WHEN ChainPlant.ChainTextileCategoryId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END 
    ELSE 'TRUE' END                                                                                                                                     
  END='TRUE'
 AND    
  CASE @PlantFormula   
  WHEN '' THEN 'TRUE'         
  ELSE                                                      
  CASE WHEN spdr.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                      
  END='TRUE'
    AND    
  CASE @ChainFormula   
  WHEN '' THEN 'TRUE'         
  ELSE                                                      
   CASE WHEN PM.PlantProgramId IS NOT NULL THEN
     CASE WHEN ChainPlant.ChainTextileCategoryId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END 
   ELSE 'TRUE' END                                                        
  END='TRUE'
    AND 
  CASE @FormulaSegement                                                                                
  WHEN '' THEN  'TRUE'
  ELSE
   CASE WHEN PM.PlantProgramId IS NOT NULL THEN
    CASE WHEN ChainPlant.FormulaSegmentId IN (SELECT FormulaSegment FROM @FormulaSegmentTable) THEN 'TRUE' END                                                                                     
   ELSE 
    CASE WHEN FS1.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)  THEN 'TRUE'END   
   END                                                     
  END='TRUE'

  /**/

  DECLARE @BatchCount int

  SELECT @BatchCount =count( distinct bd.batchid)
  
 FROM tcd.BatchData bd 
 INNER JOIN TCD.ProductionShiftData AS PS ON PS.ShiftId = bd.ShiftId 
  INNER JOIN tcd.machinesetup ms ON ms.WasherId=bd.MachineId
 --Added by Kiran For Formula Hierarchy
 INNER JOIN TCD.ProgramMaster PM on bd.ProgramMasterId = PM.ProgramId 
 LEFT OUTER JOIN
   (
   --IF Chain Plant
   SELECT PCP.PlantProgramId,PCP.PlantChainId,PCP.ChainTextileCategoryId,PCP.EcolabTextileCategoryId,
   PCP.FormulaSegmentId,PCP.EcolabSaturationId
   FROM TCD.PlantChainProgram PCP 
   LEFT OUTER JOIN TCD.ChainTextileCategory CTC ON CTC.TextileId=PCP.ChainTextileCategoryId
   LEFT OUTER JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId=PCP.EcolabTextileCategoryId
   LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=PCP.FormulaSegmentId
   LEFT OUTER JOIN TCD.EcolabSaturation ES ON ES.EcolabSaturationId=PCP.EcolabSaturationId
   )ChainPlant ON PM.PlantProgramId=ChainPlant.PlantProgramId

 LEFT OUTER JOIN TCD.EcolabTextileCategory ETC1 ON ETC1.TextileId=PM.EcolabTextileCategoryId
 LEFT OUTER JOIN TCD.FormulaSegments FS1 ON FS1.FormulaSegmentID=PM.FormulaSegmentId
 LEFT OUTER JOIN TCD.EcolabSaturation ES1 ON ES1.EcolabSaturationId=PM.EcolabSaturationId
 ----End

    WHERE isnull(ms.IsPony,0)=0 and

       CASE @StartDate                                                                                
       WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
       ELSE CASE WHEN PS.[StartDateTime] >= @startdate AND PS.[StartDateTime] <=  @enddate THEN 'TRUE'END                                                        
       END='TRUE'
     AND
       CASE @MachineType   
       WHEN '' THEN 'TRUE'         
       ELSE                                                      
       CASE WHEN bd.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
       MS.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable))) THEN 'TRUE' END                                                      
       END='TRUE'    
    AND    
        CASE @machineGroup   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN bd.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
        MS.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable)) THEN 'TRUE' END                                                      
        END='TRUE' 
    AND
        CASE @Machine   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN bd.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
        END='TRUE' 
   
    
  --Added by Kiran
 AND 
  CASE @EcolabCategory   
  WHEN '' THEN 'TRUE' 
  ELSE
   CASE WHEN PM.PlantProgramId IS NOT NULL THEN
     CASE WHEN ChainPlant.EcolabTextileCategoryId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                                                   
   ELSE 
   CASE WHEN ETC1.TextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable)  THEN 'TRUE'END 
  END  
  END='TRUE'                            
 AND 
  CASE @ChainCategory    
  WHEN '' THEN 'TRUE' 
   ELSE 
    CASE WHEN PM.PlantProgramId IS NOT NULL THEN
     CASE WHEN ChainPlant.ChainTextileCategoryId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END 
    ELSE 'TRUE' END                                                                                                                                     
  END='TRUE'
 AND    
  CASE @PlantFormula   
  WHEN '' THEN 'TRUE'         
  ELSE                                                      
  CASE WHEN bd.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                      
  END='TRUE'
    AND    
  CASE @ChainFormula   
  WHEN '' THEN 'TRUE'         
  ELSE                                                      
   CASE WHEN PM.PlantProgramId IS NOT NULL THEN
     CASE WHEN ChainPlant.ChainTextileCategoryId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END 
   ELSE 'TRUE' END                                                        
  END='TRUE'
    AND 
  CASE @FormulaSegement                                                                                
  WHEN '' THEN  'TRUE'
  ELSE
   CASE WHEN PM.PlantProgramId IS NOT NULL THEN
    CASE WHEN ChainPlant.FormulaSegmentId IN (SELECT FormulaSegment FROM @FormulaSegmentTable) THEN 'TRUE' END                                                                                     
   ELSE 
    CASE WHEN FS1.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)  THEN 'TRUE'END   
   END                                                     
  END='TRUE'

 --Result Table
    DECLARE @resultSet TABLE
    (          
        ChemicalName VARCHAR(100),ActualConsumption DECIMAL(18,2),TargetConsumption DECIMAL(18,2),--MachineId INT,
        ProgramMasterId INT,NoOfDays INT,NoOfLoads DECIMAL(18,2),
  Cost DECIMAL(18,2),StartDateTime date,PackageSizeId int,
  UnitWeightVolumeUOMId int,packagesizeweightuomcode varchar(100)
    )
 INSERT INTO @resultSet
 (
  ChemicalName ,ActualConsumption ,TargetConsumption ,--MachineId ,
  ProgramMasterId ,NoOfDays ,NoOfLoads ,
  Cost,StartDateTime ,PackageSizeId ,
  UnitWeightVolumeUOMId,
  packagesizeweightuomcode 
 )
 SELECT PM.Name,SUM(SCD.ActualConsumption), SUM(SCD.TargetConsumption),--SCD.MachineId,
  SCD.ProgramMasterId,COUNT(DISTINCT CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date)),@actualproduction,
  SUM(SCD.ActualCost),PS.StartDateTime,PM.PackageSizeId, 
  CASE WHEN pm.PackageSizeId IS NULL AND type = 'Liquid' THEN isnull(psi.UnitWeightVolumeUOMId, 6) 
    WHEN pm.PackageSizeId IS NULL AND type = 'solid' THEN isnull(psi.UnitWeightVolumeUOMId, 12) 
    ELSE psi.UnitWeightVolumeUOMId END AS UnitWeightVolumeUOMId, 
  CASE WHEN pm.PackageSizeId IS NULL AND type = 'Liquid' THEN isnull(psi.packagesizeweightuomcode, 'Pounds') 
    WHEN pm.PackageSizeId IS NULL AND type = 'solid' THEN isnull(psi.packagesizeweightuomcode, 'gal')
    WHEN pm.PackageSizeId IS NULL and type is null then 'gal'
    ELSE psi.packagesizeweightuomcode END AS packagesizeweightuomcode
 FROM 
 TCD.ShiftChemicalDataRollup SCD 
 INNER JOIN TCD.ProductionShiftData PS ON SCD.SHIFTID = PS.ShiftId
 INNER JOIN TCD.ProgramMaster PRM on SCD.ProgramMasterId = PRM.ProgramId
 LEFT OUTER JOIN TCD.ProductMaster PM ON SCD.ProductId = PM.ProductId 
 INNER JOIN TCD.ProductdataMapping AS PDM ON PDM.ProductId = PM.ProductId 
 LEFT OUTER JOIN TCD.PackageSize AS PSi ON PM.PackageSizeId = PSi.PackageSizeId
 --Added by Kiran For Formula Hierarchy 
 LEFT OUTER JOIN
   (
   --IF Chain Plant
   SELECT PCP.PlantProgramId,PCP.PlantChainId,PCP.ChainTextileCategoryId,PCP.EcolabTextileCategoryId,
   PCP.FormulaSegmentId,PCP.EcolabSaturationId
   FROM TCD.PlantChainProgram PCP 
   LEFT OUTER JOIN TCD.ChainTextileCategory CTC ON CTC.TextileId=PCP.ChainTextileCategoryId
   LEFT OUTER JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId=PCP.EcolabTextileCategoryId
   LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=PCP.FormulaSegmentId
   LEFT OUTER JOIN TCD.EcolabSaturation ES ON ES.EcolabSaturationId=PCP.EcolabSaturationId
   )ChainPlant ON PRM.PlantProgramId=ChainPlant.PlantProgramId

 LEFT OUTER JOIN TCD.EcolabTextileCategory ETC1 ON ETC1.TextileId=PRM.EcolabTextileCategoryId
 LEFT OUTER JOIN TCD.FormulaSegments FS1 ON FS1.FormulaSegmentID=PRM.FormulaSegmentId
 LEFT OUTER JOIN TCD.EcolabSaturation ES1 ON ES1.EcolabSaturationId=PRM.EcolabSaturationId
 ----End
 WHERE    
  SCD.machineID IN (SELECT ms.WasherId FROM TCD.MachineSetup AS ms WHERE isNull(ms.IsPony,0) = 0) -- Exclude pony washers
  AND
   CASE @StartDate                                                                                
      WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
      ELSE CASE WHEN PS.[StartDateTime] >= @startdate AND PS.[StartDateTime] <=  @enddate THEN 'TRUE'END                                                        
      END='TRUE'
  AND
   CASE @MachineType   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SCD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE     
    MS.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable))) THEN 'TRUE' END                                                      
    END='TRUE'     
  AND   
   CASE @machineGroup   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SCD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE   
    MS.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable)) THEN 'TRUE' END                                                      
    END='TRUE' 
  AND
   CASE @Machine   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SCD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
    END='TRUE' 
  AND  
   CASE @EcolabCategory   
   WHEN '' THEN 'TRUE'         
   ELSE                                                      
   CASE WHEN SCD.EcolabTextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                      
   END='TRUE' 
  AND
    
   CASE @ChainCategory   
   WHEN '' THEN 'TRUE'         
   ELSE                                                      
   CASE WHEN SCD.ChainTextileId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END                                                      
   END='TRUE'
  AND

   CASE @PlantFormula   
   WHEN '' THEN 'TRUE'         
   ELSE                                                      
   CASE WHEN SCD.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                      
   END='TRUE'  
  AND
    
   CASE @ChainFormula   
   WHEN '' THEN 'TRUE'         
   ELSE                                                      
   CASE WHEN SCD.ProgramMasterId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END                                                      
   END='TRUE'
  AND
  
   CASE @Customer   
   WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SCD.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                      
   END='TRUE'
  AND 
   CASE @FormulaSegement                                                                                
   WHEN '' THEN  'TRUE'
   ELSE
    CASE WHEN PRM.PlantProgramId IS NOT NULL THEN
     CASE WHEN ChainPlant.FormulaSegmentId IN (SELECT FormulaSegment FROM @FormulaSegmentTable) THEN 'TRUE' END                                                                                     
    ELSE 
     CASE WHEN FS1.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)  THEN 'TRUE'END   
    END                                                     
   END='TRUE'

 GROUP BY PM.Name,SCD.ProgramMasterId,PS.StartDateTime,pm.PackageSizeId,psi.UnitWeightVolumeUOMId,psi.packagesizeweightuomcode,pm.type


    DECLARE @Exchangerate TABLE (ChemicalName VARCHAR(100), Cost DECIMAL(18,2))  
     DECLARE @tblExchangerate TABLE (Cyear int,exChangeRate float)  
 --INSERT INTO @tblExchangerate(Cyear,exChangeRate)
 --Select Cyear,exChangeRate From Tcd.GetYearlyExchangeRates(@startdate,@enddate,@UserId)
 

    INSERT INTO @Exchangerate(ChemicalName,Cost)        
    SELECT ChemicalName,SUM(Cost)
    FROM
        (
   SELECT  ChemicalName AS ChemicalName,
   SUM(ISNULL(Cost,0))
    * 
    --ISNULL(te.exChangeRate,1)
   
  ISNULL([TCD].[FnCurrencyExchangeRate](@CurrencyCode,StartDateTime),1)
    AS Cost
   FROM @resultSet
   --Left join @tblExchangerate te on te.Cyear=YEAR(StartDateTime)
   GROUP BY ChemicalName,StartDateTime--,te.exChangeRate
        ) A
         GROUP BY A.ChemicalName

   

    SELECT
    ChemicalName,
     cast (ISNULL([TCD].[UnitConversionbyUserUOM](ActualConsumption,isnull(packagesizeweightuomcode,'gal'),@UserId),0)as decimal(18,2)),
    --ActualConsumption * 0.0078125 AS ActualConsumption,--gal
    cast(ISNULL([TCD].[UnitConversionbyUserUOM](TargetConsumption,isnull(packagesizeweightuomcode,'gal'),@UserId),0) as decimal(18,2)),
    --TargetConsumption * 0.0078125 AS TargetConsumption,--gal
   @BatchCount ProgramCount,
    NoOfLoads,
    NoOfDays,
    Cost,
   -- CAST((COALESCE(Cost/ NULLIF(ISNULL([TCD].[UnitConversionbyUserUOM](ActualConsumption,isnull(packagesizeweightuomcode,'gal'),@UserId),1),0), 0) * ISNULL([TCD].[UnitConversionbyUserUOM](TargetConsumption,isnull(packagesizeweightuomcode,'gal'),@UserId),0)) AS DECIMAL(18,2)) AS TargetCost,
     CAST(((cast(Cost AS decimal(18,2))/ (CASE WHEN ActualConsumption =0 THEN 1 ELSE ActualConsumption end)) * ISNULL(TargetConsumption,0)) AS DECIMAL(18,2)) AS TargetCost,

    --CAST(((Cost / ISNULL([TCD].[FnConsumptionOnMetrics](ActualConsumption,'Volume',@UserId),0)) * ISNULL([TCD].[FnConsumptionOnMetrics](TargetConsumption,'Volume',@UserId),0))AS DECIMAL(18,2)) AS TargetCost
    --CAST(((Cost / (ActualConsumption * 0.0078125)) * (TargetConsumption* 0.0078125))AS DECIMAL(18,2)) AS TargetCost
    CASE @uom WHEN 1 THEN ActualConsumption 
     WHEN 2 THEN ActualConsumption * 28.3495 END AS ActualConsumptionMetrics,     
   isnull(packagesizeweightuomcode,'gal') as UOM
    FROM
  (
    SELECT
    r.ChemicalName,
    SUM(ActualConsumption) AS ActualConsumption,
    SUM(TargetConsumption) AS TargetConsumption,
    COUNT( ProgramMasterId) AS ProgramCount,
    COUNT(DISTINCT r.StartDateTime) AS NoOfDays,
    MAX(NoOfLoads) AS NoOfLoads,
    e.Cost AS Cost,
    PackageSizeId ,
    UnitWeightVolumeUOMId ,
    packagesizeweightuomcode
    --* ISNULL([TCD].[FnCurrencyExchangeRate](@CurrencyCode,MONTH(StartDateTime),YEAR(StartDateTime)),1) AS Cost

    FROM @resultSet r INNER JOIN @Exchangerate e ON r.ChemicalName = e.ChemicalName
    GROUP BY r.ChemicalName,e.Cost,r.PackageSizeId,r.UnitWeightVolumeUOMId,r.packagesizeweightuomcode
  ) A
SET NOCOUNT OFF
END


---CHEMICAL INVENTROY--
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ReportChemicalInventoryRollup]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ReportChemicalInventoryRollup]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ReportChemicalInventoryRollup]
AS
BEGIN
/*
======================================================================================
CHANGE ID(TFS)  CHANGED BY CHANGED ON     CHANGE DESCRIPTION
======================================================================================
    PSAJJA    07/09/2015     Scheduled the procedure to run every 15 mins from windows 
            and data get populdated TCD.ChemicalInventoryRollUp table
            to improve ChemicalInventory report performance.
 PSAJJA 10/09/2015 Added AvgDailyNeedsForInventoryPeriod Column
 PSAJJA 10/13/2015 DaysBeforeOutOfStock column changed to Int as per client
======================================================================================
*/


 SET NOCOUNT ON;
 DECLARE @CurrentYearWorkingDays INT    = NULL
    ,@PreviousYearWorkingDays INT    = NULL
    ,@CurrencyCode   VARCHAR(3)  = NULL

 SELECT @CurrencyCode = p.CurrencyCode
 FROM TCD.Plant p

 SELECT @CurrentYearWorkingDays = COUNT(DISTINCT CAST(PS.StartDateTime AS DATE))
 FROM TCD.ProductionShiftData PS (NOLOCK) 
 WHERE PS.StartDateTime >= DATEADD(yy, DATEDIFF(yy,0,getdate()), 0)
 AND PS.LastSyncTime IS NOT NULL
 AND EXISTS (SELECT 1 FROM [TCD].ShiftProductionDataRollup SPD (NOLOCK)
    WHERE SPD.ShiftId = PS.ShiftId
    )

 SELECT @PreviousYearWorkingDays = COUNT(DISTINCT CAST(PS.StartDateTime AS DATE))
 FROM TCD.ProductionShiftData PS (NOLOCK) 
 WHERE PS.StartDateTime >= DATEADD(YEAR, DATEDIFF(YEAR, 0,DATEADD(YEAR, -1, GETDATE())), 0)
 AND PS.StartDateTime <= DATEADD(MILLISECOND, -3, DATEADD(YEAR, DATEDIFF(YEAR, 0, DATEADD(YEAR, -1, GETDATE())) +1, 0))
 AND PS.LastSyncTime IS NOT NULL
 AND EXISTS (SELECT 1 FROM [TCD].ShiftProductionDataRollup SPD (NOLOCK) 
    WHERE SPD.ShiftId = PS.ShiftId
    )

--SELECT @CurrentYearWorkingDays, @PreviousYearWorkingDays


 DECLARE @ChemicalLastInventory TABLE (
   ProductId INT
  ,LastInventoryDate DATETIME
  ,BeforeLastInventoryDate DATETIME
  );

CREATE TABLE #InventoryRollUp (
    ProductID INT PRIMARY KEY,
    ChemicalName VARCHAR(512),
    LastInventory DECIMAL(18,2),
    InventoryBasedConsumption DECIMAL(18,2),
    DispencerBasedConsumption DECIMAL(18,2),
    TodayEstimateInventory DECIMAL(18,2),
    AvgDailyNeedsYTD DECIMAL(18,2),
    AvgDailyCostYTD DECIMAL(18,6),
    AvgDailyCostLoadYTD DECIMAL(18,6),
    AvgDailyNeedsLY DECIMAL(18,2),
    DayBeforeOutOfStock INT,
    InventoryDateRange varchar(70),
    UnitSize VARCHAR(10),
    AvgDailyNeedsForInventoryPeriod DECIMAL(18,2)
    );

WITH CTE (
   Rownumber
  ,ProductId
  ,InventoryDate
  )
 AS (
  SELECT ROW_NUMBER() OVER (
    PARTITION BY CI.ProductId ORDER BY InventoryDate DESC
    )
   ,CI.ProductId
   ,CI.InventoryDate
  FROM TCD.ChemicalInventory CI (NOLOCK)
  ),
 CTE_INV AS (
 SELECT CT.ProductId
  , MAX(CT.InventoryDate) AS LastInventoryDate
  , MIN(CT.InventoryDate) AS BeforeLastInventoryDate
 FROM CTE CT
 WHERE CT.Rownumber < 3
 GROUP BY CT.ProductId
 )
 INSERT INTO @ChemicalLastInventory
 SELECT DISTINCT CT.productid, Inv.LastInventoryDate, Inv.BeforeLastInventoryDate
 FROM CTE CT
 JOIN CTE_INV Inv ON CT.productid = Inv.Productid
 WHERE CT.Rownumber < 2;


 --  SELECT distinct SCD.ProductId
 --  , CASE WHEN (psd.StartDateTime BETWEEN CLI.BeforeLastInventoryDate AND CLI.LastInventoryDate)
	--    THEN SCD.ShiftId
	--END 
 --   --, SUM(CASE WHEN (psd.StartDateTime BETWEEN CLI.BeforeLastInventoryDate AND CLI.LastInventoryDate)
 --   --THEN SCD.ActualConsumption * 0.0078125
 --   --  END) AS DispencerBasedConsumption
 --   --, SUM(CASE WHEN (psd.StartDateTime BETWEEN CLI.LastInventoryDate AND GETDATE())
 --   --THEN SCD.ActualConsumption * 0.0078125
 --   --  END) AS TodayEstimateInventory
 --FROM TCD.ShiftChemicalDataRollup SCD (NOLOCK)
 --INNER JOIN TCD.ProductionShiftData psd ON psd.ShiftId = SCD.ShiftId
 --INNER JOIN @ChemicalLastInventory CLI ON SCD.ProductId = CLI.ProductId
 --WHERE psd.LastSyncTime IS NOT NULL
 --AND SCD.ProductId = 9725
 ----GROUP BY SCD.ProductId
  
 WITH CTE_dispencer_estimate_Inventory
AS (
 SELECT SCD.ProductId
    , SUM(CASE WHEN (psd.StartDateTime BETWEEN CLI.BeforeLastInventoryDate AND CLI.LastInventoryDate)
    THEN SCD.ActualConsumption * 0.0078125
      END) AS DispencerBasedConsumption
    , SUM(CASE WHEN (psd.StartDateTime BETWEEN CLI.LastInventoryDate AND GETDATE())
    THEN SCD.ActualConsumption * 0.0078125
      END) AS TodayEstimateInventory
 FROM TCD.ShiftChemicalDataRollup SCD (NOLOCK)
 INNER JOIN TCD.ProductionShiftData psd ON psd.ShiftId = SCD.ShiftId
 INNER JOIN @ChemicalLastInventory CLI ON SCD.ProductId = CLI.ProductId
 WHERE psd.LastSyncTime IS NOT NULL
 GROUP BY SCD.ProductId
),
CTE_YTD
AS (
 SELECT ci.ProductId
 , SUM(CASE WHEN ci.InventoryDate >= DATEADD(yy, DATEDIFF(yy,0,getdate()), 0) 
  THEN ci.UsedQuantity
    ELSE NULL
    END ) AS AvgDailyNeeds
 , SUM(CASE WHEN ci.InventoryDate >= DATEADD(yy, DATEDIFF(yy,0,getdate()), 0) 
  THEN CASE WHEN ci.UnitSize = 'lbs' THEN (ci.UsedQuantity * 16.00) 
    WHEN ci.UnitSize = 'oz'  THEN ci.UsedQuantity 
    WHEN ci.UnitSize = 'gal' THEN ci.UsedQuantity * 128.00
    ELSE ci.UsedQuantity
    END
    ELSE NULL
    END ) * [TCD].[FnChemicalCostInOunce](ci.ProductId) AS AvgDailyCost
 , SUM(CASE WHEN (ci.InventoryDate >= DATEADD(YEAR, DATEDIFF(YEAR, 0,DATEADD(YEAR, -1, GETDATE())), 0)
    AND ci.InventoryDate <= DATEADD(MILLISECOND, -3, DATEADD(YEAR, DATEDIFF(YEAR, 0, DATEADD(YEAR, -1, GETDATE())) +1, 0)))
  THEN ci.UsedQuantity
    ELSE NULL
    END ) AS AvgDailyNeedsLY
 , SUM(CASE WHEN (ci.InventoryDate >= cli.BeforeLastInventoryDate
    AND ci.InventoryDate <= cli.LastInventoryDate)
  THEN ci.UsedQuantity
    ELSE NULL
    END ) AS AvgDailyNeedsForInventoryPeriod
FROM TCD.ChemicalInventory ci
INNER JOIN tcd.ProductdataMapping pm ON ci.ProductId = pm.ProductID
INNER JOIN @ChemicalLastInventory cli ON cli.ProductId = ci.ProductId
GROUP BY ci.ProductId
)
SELECT   X.ProductId
    , X.DispencerBasedConsumption
    , X.TodayEstimateInventory
    , cy.AvgDailyNeeds
    , cy.AvgDailyCost
    , cy.AvgDailyCost AS AvgDailyCostPerLoad
    , cy.AvgDailyNeedsLY
    , cy.AvgDailyNeedsForInventoryPeriod
INTO #CI_Data
FROM CTE_YTD cy
LEFT JOIN CTE_dispencer_estimate_Inventory X ON X.ProductId = cy.ProductId


--select * from #CI_Data
DECLARE @ChemicalInventory TABLE (
  ProductId INT
  ,ChemicalName VARCHAR(1000)
  ,LastInventory DECIMAL(18, 2)
  ,InventoryDate DATETIME
  ,InventoryDateRange VARCHAR(70)
  ,InventorybasedConsumption DECIMAL(18, 2)
  ,DispencerBasedConsumption DECIMAL(18, 2)
  ,TodayEstimateInventory DECIMAL(18, 2)
  ,AvgDailyNeedsYTD DECIMAL(18, 2)
  ,AvgDailyCostYTD DECIMAL(18, 6)
  ,AvgDailyCostloadYTD DECIMAL(18, 6)
  ,AvgDailyNeedsLY DECIMAL(18, 2)
  ,DayBeforeOutOfStock INT
  ,UnitSize varchar(10)
  ,AvgDailyNeedsForInventoryPeriod DECIMAL(18, 2)
  )

 INSERT INTO @ChemicalInventory
 SELECT DISTINCT CI.ProductId
  , PM.NAME
  --, COALESCE(pm.EnvisionDisplayName, PM.NAME) 
  , CI.ClosingQuantity AS LastInventory
  , CIL.LastInventoryDate AS InventoryDate
  , (CONVERT(VARCHAR(25),CIL.BeforeLastInventoryDate, 110) + ' - ' + CONVERT(VARCHAR(25), CIL.LastInventoryDate, 110)) AS inventoryDateRange
  , CI.UsedQuantity AS InventorybasedConsumption
  , CID.DispencerBasedConsumption
  , (CI.ClosingQuantity - CID.TodayEstimateInventory) AS TodayEstimateInventory
  , NULLIF(CID.AvgDailyNeeds,0)/NULLIF(@CurrentYearWorkingDays, 0) AS AvgDailyNeedsYTD
  , NULLIF(CID.AvgDailyCost,0)/NULLIF(@CurrentYearWorkingDays, 0) AS AvgDailyCostYTD
  , CID.AvgDailyCostPerLoad / (SELECT NULLIF(COUNT(DISTINCT bd.batchid),0) FROM TCD.BatchData bd (NOLOCK)
        INNER JOIN tcd.BatchProductData bpd (NOLOCK) ON bpd.BatchId = bd.BatchId
        WHERE bd.StartDate >= DATEADD( yy,DATEDIFF( yy,0,GETDATE()),0 )
        AND bpd.ProductId = CI.ProductId) * 100
  --, CID.AvgDailyCostPerLoad / (SELECT NULLIF(SUM(DISTINCT scdr.NoOfLoads),0) FROM TCD.ProductionShiftData psd
  --      INNER JOIN TCD.ShiftChemicalDataRollup scdr ON scdr.ShiftId = psd.ShiftId
  --      WHERE psd.StartDateTime >= DATEADD(yy, DATEDIFF(yy,0,getdate()), 0) 
  --      AND scdr.ProductId = CI.ProductId
  --      ) * 100  
  , NULLIF(CID.AvgDailyNeedsLY,0) / NULLIF(@PreviousYearWorkingDays, 0)
  ,(CI.ClosingQuantity - CID.TodayEstimateInventory) / NULLIF((NULLIF(CID.AvgDailyNeeds,0)/NULLIF(@CurrentYearWorkingDays, 0)), 0)
 , CI.UnitSize
  , NULLIF(CID.AvgDailyNeedsForInventoryPeriod,0) /(SELECT NULLIF(COUNT(DISTINCT CAST(PS.StartDateTime AS DATE)),0)
             FROM TCD.ProductionShiftData PS (NOLOCK) 
             CROSS JOIN @ChemicalLastInventory cli
             WHERE PS.StartDateTime >= cli.BeforeLastInventoryDate
             AND PS.StartDateTime <= cli.LastInventoryDate
             AND cli.ProductId = CIL.ProductId
	     AND PS.LastSyncTime IS NOT NULL
             AND EXISTS (SELECT 1 FROM [TCD].ShiftProductionDataRollup SPD (NOLOCK) 
             WHERE SPD.ShiftId = PS.ShiftId)
             )
 FROM TCD.ChemicalInventory CI (NOLOCK)
 INNER JOIN TCD.ProductdataMapping PDM (NOLOCK) ON CI.ProductId = PDM.ProductID
 INNER JOIN TCD.ProductMaster PM (NOLOCK) ON PM.ProductId = PDM.ProductID
 INNER JOIN @ChemicalLastInventory CIL ON CI.InventoryDate = CIL.LastInventoryDate AND CI.ProductId = CIL.ProductId
 LEFT JOIN #CI_Data CID ON CI.ProductId = CID.ProductId

 --SELECT * FROM @ChemicalInventory

 DECLARE @Exchangerate TABLE (
  ChemicalName VARCHAR(100)
  ,AvgDailyCostYTD DECIMAL(18, 2)
  ,AvgDailyCostloadYTD DECIMAL(18, 2)
  )

 INSERT INTO @Exchangerate (
  ChemicalName
  ,AvgDailyCostYTD
  ,AvgDailyCostloadYTD
  )
 SELECT ChemicalName
  ,AvgDailyCostYTD
  ,AvgDailyCostloadYTD
 FROM (
  SELECT ChemicalName AS ChemicalName
   ,AvgDailyCostYTD * ISNULL([TCD].[FnCurrencyExchangeRate](@CurrencyCode, InventoryDate), 1) AS AvgDailyCostYTD
   ,AvgDailyCostloadYTD * ISNULL([TCD].[FnCurrencyExchangeRate](@CurrencyCode, InventoryDate), 1) AS AvgDailyCostloadYTD
  FROM @ChemicalInventory
  ) A

 INSERT #InventoryRollUp
 (ProductId,ChemicalName,LastInventory,InventorybasedConsumption,DispencerBasedConsumption,TodayEstimateInventory
 ,AvgDailyNeedsYTD,AvgDailyCostYTD,AvgDailyCostloadYTD,AvgDailyNeedsLY,DayBeforeOutOfStock,InventoryDateRange,UnitSize
 ,AvgDailyNeedsForInventoryPeriod)
 SELECT CI.ProductId
  ,CI.ChemicalName
  ,CI.LastInventory
  ,CI.InventorybasedConsumption
  ,CI.DispencerBasedConsumption
  ,CI.TodayEstimateInventory
  ,CI.AvgDailyNeedsYTD
  ,E.AvgDailyCostYTD
  ,E.AvgDailyCostloadYTD
  ,CI.AvgDailyNeedsLY
  ,CI.DayBeforeOutOfStock
  ,CI.InventoryDateRange
  ,CI.UnitSize
  ,CI.AvgDailyNeedsForInventoryPeriod
 FROM @ChemicalInventory CI
 INNER JOIN @Exchangerate e ON CI.ChemicalName = e.ChemicalName
 

-- SELECT iru.* FROM #InventoryRollUp iru

    UPDATE [Target]
    SET  [Target].ChemicalName = [Source].ChemicalName
    ,[Target].LastInventory = [Source].LastInventory 
    ,[Target].InventorybasedConsumption = [Source].InventorybasedConsumption
    ,[Target].DispencerBasedConsumption = [Source].DispencerBasedConsumption
    ,[Target].TodayEstimateInventory = [Source].TodayEstimateInventory
    ,[Target].AvgDailyNeedsYTD = [Source].AvgDailyNeedsYTD
    ,[Target].AvgDailyCostYTD = [Source].AvgDailyCostYTD
    ,[Target].AvgDailyCostloadYTD = [Source].AvgDailyCostloadYTD
    ,[Target].AvgDailyNeedsLY = [Source].AvgDailyNeedsLY
    ,[Target].DayBeforeOutOfStock = [Source].DayBeforeOutOfStock
    ,[Target].InventoryDateRange = [Source].InventoryDateRange
    ,[Target].UnitSize = [Source].UnitSize
    ,[Target].AvgDailyNeedsForInventoryPeriod = [Source].AvgDailyNeedsForInventoryPeriod
    FROM TCD.ChemicalInventoryRollUp AS [Target]
    JOIN #InventoryRollUp AS [Source]
    ON [Target].ProductID = [Source].ProductID
    
    
    INSERT TCD.ChemicalInventoryRollUp
    (ProductId,ChemicalName,LastInventory,InventorybasedConsumption,DispencerBasedConsumption,TodayEstimateInventory
     ,AvgDailyNeedsYTD,AvgDailyCostYTD,AvgDailyCostloadYTD,AvgDailyNeedsLY,DayBeforeOutOfStock,InventoryDateRange,UnitSize
     ,AvgDailyNeedsForInventoryPeriod)
    SELECT [Source].ProductId, [Source].ChemicalName,[Source].LastInventory,[Source].InventorybasedConsumption
     ,[Source].DispencerBasedConsumption,[Source].TodayEstimateInventory,[Source].AvgDailyNeedsYTD,[Source].AvgDailyCostYTD
     ,[Source].AvgDailyCostloadYTD,[Source].AvgDailyNeedsLY,[Source].DayBeforeOutOfStock,[Source].InventoryDateRange, [Source].UnitSize
     ,[Source].AvgDailyNeedsForInventoryPeriod
    FROM #InventoryRollUp AS [Source]
    LEFT OUTER JOIN TCD.ChemicalInventoryRollUp AS [Target] (NOLOCK)
    ON [Target].ProductID = [Source].ProductID
    WHERE [Target].ProductID IS NULL


-- CleanUp
DROP TABLE #InventoryRollUp
DROP TABLE #CI_Data

END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ReportProductionDetails]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ReportProductionDetails]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ReportProductionDetails]   
/******************************************************************  
DESCRIPTION		: 
  
  
MODIFICATION HISTORY DETAILS:   
 21st Jan 2015 -  Kiran     -  Added Formula hierarchy -->Formula segment-->Formula category-->formula  
  
  
REFERENC TABLES :  
  Select * from TCD.Plant --Plant master  
  Select * FROM TCD.PlantChain  --Master Plants  
  Select * FROM TCD.PlantChainProgram  
  Select * FROM TCD.ChainTextileCategory  
  Select * FROM TCD.ProgramMaster  
  Select * FROM TCD.EcolabTextileCategory  --Masters  
  Select * FROM TCD.EcolabSaturation --Masters  
  Select * FROM TCD.FormulaSegments --Masters  
  
EXECUTION STATEMENT :  
  
	EXEC [TCD].[ReportProductionDetails] @startdate = '2015-01-01 00:0:00',@enddate = '2016-01-01 11:59:59',@Viewtype  = '8',@Subview = '21',
          @Drillvalue = '',@EcolabAccountNumber = '040242802',@MachineType = '', @MachineGroup  = '',@Machine  = '',   
          @EcolabCategory  = '',@ChainCategory  = '', @PlantFormula  = '', @ChainFormula = '', @Customer  = '',  
          @SortColumnId  = 0,@SortDirection  = 'Desc',@CurrencyCode = '', @UserId = 1, @FormulaSegement ='',  
          @FormulaCategory='',@Formula=''
	
	EXEC [TCD].[ReportProductionDetails] @startdate = '2015-01-01 00:00:00',@enddate = '2016-01-01 00:00:00',@Viewtype  = '8',@Subview = '21',
          @Drillvalue = '1',@EcolabAccountNumber = '040242802',@MachineType = '', @MachineGroup  = '',@Machine  = '',   
          @EcolabCategory  = '',@ChainCategory  = '', @PlantFormula  = '', @ChainFormula = '', @Customer  = '',  
          @SortColumnId  = 0,@SortDirection  = 'Desc',@CurrencyCode = '', @UserId = 1, @FormulaSegement ='',  
          @FormulaCategory='',@Formula=''    

	EXEC [TCD].[ReportProductionDetails] @startdate = '2015-01-01 00:00:00',@enddate = '2016-01-01 00:00:00',@Viewtype  = '8',@Subview = '22',
          @Drillvalue = '3',@EcolabAccountNumber = '040298214',@MachineType = '', @MachineGroup  = '',@Machine  = '',   
          @EcolabCategory  = '',@ChainCategory  = '', @PlantFormula  = '', @ChainFormula = '', @Customer  = '',  
          @SortColumnId  = 0,@SortDirection  = 'Desc',@CurrencyCode = '', @UserId = 1, @FormulaSegement ='1,2',  
          @FormulaCategory='',@Formula='2'
    
*******************************************************************/ 
  
	@startdate datetime = '',  
	@enddate datetime = '',  
	@Viewtype Int = '',  
	@Subview Int= '',  
	@Drillvalue varchar(100)= '',  
	@EcolabAccountNumber Nvarchar(25) = '',  
	@MachineType VARCHAR(20)= '',  
	@MachineGroup VARCHAR(MAX) = '',  
	@Machine VARCHAR(MAX) = '',  
	@EcolabCategory VARCHAR(MAX) = '',  
	@ChainCategory VARCHAR(MAX) = '',  
	@PlantFormula  VARCHAR(MAX) = '',  
	@ChainFormula VARCHAR(MAX) = '',  
	@Customer VARCHAR(MAX) = '',  
	@SortColumnId int = 0,  
	@SortDirection varchar(4) = '',  
	@CurrencyCode varchar(3) = '',  
	@UserId INT = NULL,  
	@FormulaSegement VARCHAR(MAX)='', --Formula segment,  
	@FormulaCategory VARCHAR(MAX)='', --Formula category  
	@Formula VARCHAR(MAX)='' --Formula  
AS     
BEGIN     
SET NOCOUNT ON   
	 SET @startdate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@startdate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@startdate AS time)) AS DateTime))  
	 SET @EndDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndDate AS time)) AS DateTime))  

	 --SELECT @startdate,@EndDate 
	 DECLARE @ReportGenerated INT = 6, @Month INT = MONTH(GETDATE()),@CorrectionVariable Decimal(18,2),@PlantTargetProduction decimal(18,2)  
        
	 /* Inserting the record into Report History */  
	 INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)  
	 SELECT @EcolabAccountNumber,UM.UserId,UM.LoginName,GETUTCDATE(),@ReportGenerated,  
	 CASE WHEN @ReportGenerated = 6  
	  THEN 'Generated Report : Production Details Report' END  
	 FROM TCD.UserMaster UM  
	 WHERE UM.EcolabAccountNumber = @EcolabAccountNumber AND UM.UserId = @UserId  
       
	-- Return Table set  
	DECLARE @resultSet Table  
	(  
		ShiftId Int,  
		DateRange varchar(100),  
		TotalLoad Decimal(18,2) ,  
		WasherEfficiency Decimal(18,2),  
		PlantTargetLoad Decimal(18,2) ,  
		StandardLoad Decimal(18,2) ,  
		Numberofbatches INT,  
		[ActualRunTime] Decimal(30,10) NULL,  
		[TargetRunTime] Decimal(30,10) NULL,  
		NumberofPieces  [int] NULL,  
		Rewash [int] NULL,  
		Viewtype varchar(100) NULL,  
		Subview varchar(100) NULL,  
		Id int NULL  ,
		SortOrder  int NULL       
	)  
  
	-- Correction factor
	DECLARE @CorrectionFactor TABLE   
	(  
		[ShiftId] [int] NULL,  
		MachineId INT NULL,  
		[ActualProduction] [int] NULL,  
		[StandardProduction] [int] NULL,  
		[PlantTargetProd] [int] NULL,  
		[ActualRunTime] [int] NULL,  
		[TargetRunTime] [int] NULL,  
		ManualInputWeight INT,  
		ManulainputsNoofloads INT  
	)  
      
	--Machine type  
	DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))  
	INSERT INTO @MachineTypeTable EXEC [TCD].[CharlistToTable] @MachineType,','  
  
	--washer Group  
	DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))  
	INSERT INTO @WasherGroupTable EXEC [TCD].[CharlistToTable] @machineGroup,','    
  
	--Machine list  
	DECLARE @MachineTable TABLE(Machine Varchar(100))  
	INSERT INTO @MachineTable EXEC [TCD].[CharlistToTable] @Machine,','  
  
	--Ecolab category  
	DECLARE @EcolabCategoryTable TABLE(EcolabCategory Varchar(100))  
	INSERT INTO @EcolabCategoryTable EXEC [TCD].[CharlistToTable] @EcolabCategory,','  
  
	--Chain category  
	DECLARE @ChainCategoryTable TABLE(ChainCategory Varchar(100))  
	INSERT INTO @ChainCategoryTable EXEC [TCD].[CharlistToTable] @ChainCategory,','  
  
	--Plant formula  
	DECLARE @PlantFormulaTable TABLE(PlantFormula Varchar(100))  
	INSERT INTO @PlantFormulaTable EXEC [TCD].[CharlistToTable] @PlantFormula,','  
  
	--Chain Formula  
	DECLARE @ChainFormulaTable TABLE(ChainFormula Varchar(100))  
	INSERT INTO @ChainFormulaTable EXEC [TCD].[CharlistToTable] @ChainFormula,','  
  
	 --Customer Table  
	DECLARE @CustomerTable TABLE(Customer Varchar(100))  
	INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','  
  
	 --Formula Segment --added by Kiran  
	DECLARE @FormulaSegmentTable TABLE(FormulaSegment Varchar(1000))  
	INSERT INTO @FormulaSegmentTable EXEC [TCD].[CharlistToTable] @FormulaSegement,','  
  
	-----Formula category--------Start  
	DECLARE @FormulaCategoryTable TABLE(FormulaCategory Varchar(1000),Type CHAR(1))  
	INSERT INTO @FormulaCategoryTable(FormulaCategory) EXEC [TCD].[CharlistToTable] @Formulacategory,','     	   
  
		--Below 1000 Ecolab category  
		UPDATE @FormulaCategoryTable SET TYPE='E' WHERE FormulaCategory<1000  
		--Above 1000 consider as Chain category  
		UPDATE @FormulaCategoryTable SET TYPE='C' WHERE FormulaCategory>=1000  
  
		--Rollbacking to actual ID  
		UPDATE @FormulaCategoryTable SET FormulaCategory=FormulaCategory-1000 WHERE TYPE='C'  
		  
		INSERT INTO @EcolabCategoryTable(EcolabCategory)  
		SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='E'   
  
		INSERT INTO @ChainCategoryTable(ChainCategory)  
		SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='C'  
  
		--Value Assigning  
		IF (EXISTS(SELECT * FROM @EcolabCategoryTable) AND @FormulaCategory!='')  
		BEGIN  
		SET @EcolabCategory=@FormulaCategory  
		END  
		IF (EXISTS(SELECT * FROM @ChainCategoryTable) AND @FormulaCategory!='')  
		BEGIN  
		SET @ChainCategory=@FormulaCategory  
		END  
	
  
	-----Formula Ecolab/Chain formulas  
	DECLARE @FormulaTable TABLE(Formula Varchar(1000),Type CHAR(1))  
	INSERT INTO @FormulaTable(Formula) EXEC [TCD].[CharlistToTable] @Formula,','  
   	 
		--Plant fomula     
		INSERT INTO @PlantFormulaTable(PlantFormula)   
		SELECT Formula FROM @FormulaTable --WHERE Type='E'  
		--chain formula     
		INSERT INTO @ChainFormulaTable(ChainFormula)   
		SELECT Formula FROM @FormulaTable --WHERE Type='C'  
		   
		 --Value Assigning  
		 IF (EXISTS(SELECT * FROM @PlantFormulaTable) AND @Formula!='')  
		 BEGIN  
				SET @PlantFormula=@Formula
		 END  
		 IF (EXISTS(SELECT * FROM @ChainFormulaTable) AND @Formula!='')  
		 BEGIN  
				SET @ChainFormula=@Formula
		 END  
		
  
	 --Insert Into @CorrectionFactor table  
	 INSERT INTO @CorrectionFactor  
	 (  
		  [ShiftId],  
		  [MachineId] ,  
		  [ActualProduction] ,  
		  [StandardProduction] ,  
		  [PlantTargetProd] ,  
		  [ActualRunTime] ,  
		  [TargetRunTime],  
		  ManualInputWeight,  
		  ManulainputsNoofloads     
	 )  
	 SELECT   
	  PS.[ShiftId],  
	  SPD.[MachineId],  
	  ISNULL([TCD].[FnConsumptionOnMetrics](SUM(ISNULL(SPD.[ActualProduction],0))+SUM(ISNULL(MIP.ActualWeight,0)),'Weight',@UserId),0),  
	  --ISNULL([TCD].[FnConsumptionOnMetrics](SUM(ISNULL(SPD.[ActualProduction],0)),'Weight',@UserId),0),    
	  --SUM(SPD.[ActualProduction]),  
	  ISNULL([TCD].[FnConsumptionOnMetrics](SUM(ISNULL(SPD.StandardProduction,0)),'Weight',@UserId),0),  
	  --SUM(SPD.StandardProduction),  
	  ISNULL([TCD].[FnConsumptionOnMetrics](SUM(DISTINCT ISNULL(SPD.[PlantTargetProd],0)),'Weight',@UserId),0),  
	  --SUM(DISTINCT SPD.[PlantTargetProd]),  
	  SUM(ISNULL(SPD.[ActualRunTime],0) + ISNULL(SPD.ActualTurnTime,0)),  
	  SUM(ISNULL(SPD.[TargetRunTime],0) + ISNULL(SPD.TargetTurnTime,0)),  
	  SUM(ISNULL(MIP.ActualWeight,0)),SUM(ISNULL(MIP.NoofLoads,0))  
	 FROM  TCD.ShiftProductionDataRollup SPD   
	 INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId  
	 LEFT OUTER JOIN --Manual Production Details appending  
	  (  
	   SELECT WasherId,FormulaId,CONVERT(DATE,RecordedDate) AS LoadDate,SUM(ISNULL(Value,0)) AS ActualWeight,  
	   ISNULL(COUNT(CONVERT(DATE,RecordedDate)),0) AS NoofLoads FROM  
	   TCD.ManualProduction MP  
	   GROUP BY WasherId,FormulaId,CONVERT(DATE,RecordedDate)  
	  )MIP ON MIP.WasherId=SPD.EcolabWasherId AND MIP.FormulaId=SPD.ProgramMasterId AND MIP.LoadDate=CONVERT(DATE,PS.StartDateTime)  
	 WHERE   
	  CASE @StartDate                                                                                  
	  WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                  
	  ELSE CASE WHEN PS.[StartDateTime] >= @startdate  AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                          
	  END='TRUE'   
	 GROUP BY MachineId,PS.ShiftId;  
  
	 WITH CTE (PlantTargetProd) AS  
	 (  
	 SELECT SUM(DISTINCT SPD.[PlantTargetProd]) FROM @CorrectionFactor SPD GROUP BY ShiftId  
	 )  
	 SELECT @PlantTargetProduction = SUM(PlantTargetProd) FROM CTE;  
  
	 WITH CTE (MachineId,PlantEfficiency)  
	 AS  
	 (  
	 SELECT   
	  MachineId,  
	  CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/   
	   NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) *   
	   COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2))     
	   FROM @CorrectionFactor SPD GROUP BY MachineId  
	 )  
		SELECT @CorrectionVariable = @PlantTargetProduction/NULLIF(SUM(PlantEfficiency),0) FROM CTE  
  	
	 DECLARE @ProductionSummaryTable TABLE  
	 (  
	  [ShiftId] [int] NULL,  
	  [ShiftName] Varchar(100) NULL,  
	  RecordDate date,   
	  [MachineId] [int] NULL,  
	  [ProgramMasterId] [int] NULL,  
	  [EcolabWasherId] [int] NULL,  
	  [ActualProduction] [int] NULL,  
	  [StandardProduction] [int] NULL,  
	  [NoOfLoads] [int] NULL,  
	  [LoadEfficiency] [decimal](18, 2) NULL,  
	  [TimeEfficiency] [decimal](18, 2) NULL,  
	  TotalEfficiency [decimal](18, 2) NULL,  
	  [PlantTargetProd] [int] NULL,  
	  [ActualRunTime] INT NULL,  
	  [TargetRunTime] INT NULL,  
	  EcolabTextileId int,  
	  ChainTextileId int,  
	  ChainProgaramId int,  
	  CustomerId int,  
	  NoOfPieces int,  
	  Rewash Int,  
	  [ShiftRunTime] DECIMAL(30,10) NULL,  
	  FormulaSegmentID INT,  
	  RowNumberID INT,
	  IndividualShiftRunTime Decimal(30,10),
	  ShiftRownumber INT  
	 )  
  
	INSERT INTO @ProductionSummaryTable  
	SELECT   
		PS.[ShiftId],  
		PS.ShiftName,  
		CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date),  		 
		SPD.[MachineId],  
		SPD.[ProgramMasterId],  
		SPD.[EcolabWasherId],  
		ISNULL(SPD.[ActualProduction],0),  
		ISNULL(SPD.StandardProduction,0),  
		ISNULL(SPD.[NoOfLoads],0),  
		ISNULL(SPD.[LoadEfficiency],0),  
		ISNULL(SPD.[TimeEfficiency],0),  
		(ISNULL(SPD.[LoadEfficiency],0) * ISNULL(SPD.TimeEfficiency,0)),  
		ISNULL(SPD.[PlantTargetProd],0),  
		ISNULL(SPD.[ActualRunTime],0) + ISNULL(SPD.ActualTurnTime,0),  
		ISNULL(SPD.[TargetRunTime],0) + ISNULL(SPD.TargetTurnTime,0),  
		SPD.EcolabTextileId,  
		SPD.ChainTextileId,  
		SPD.ChainProgaramId,  
		SPD.CustomerId,  
		ISNULL(SPD.NoOfPieces,0),  
		CAST((  
			SELECT spdr.ActualProduction FROM TCD.ShiftProductionDataRollup spdr WHERE spdr.ShiftId = SPD.ShiftId AND spdr.MachineId = SPD.MachineId  
			AND spdr.ProgramMasterId = SPD.ProgramMasterId AND spdr.ProgramMasterId IN (SELECT pm.ProgramId FROM TCD.ProgramMaster pm WHERE pm.Rewash = 1)  
			) AS decimal(18,2)),  
		DATEDIFF(Second,ps.StartDateTime,PS.EndDateTime) +  
		ISNULL(  
			(  
			SELECT  
			SUM(SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0))  
			FROM TCD.ShiftProductionDataRollup SPD INNER JOIN TCD.ProductionShiftData PSD ON SPD.ShiftId = PSD.ShiftId  
			WHERE PSD.[StartDateTime] = PS.StartDateTime AND PSD.[StartDateTime] = PS.EndDateTime AND PS.ShiftName = 'No Shift'  
			) ,0),  
		CASE WHEN  SPD.ChainProgaramId IS NOT NULL and  SPD.ChainProgaramId>0 THEN ChainPlant.FormulaSegmentId  
		ELSE FS1.FormulaSegmentID END AS Formulasegment,  
		ROW_NUMBER() OVER(Partition BY SPD.ProgramMasterId, SPD.[EcolabWasherId], CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date)  
		ORDER BY SPD.ProgramMasterId, SPD.[EcolabWasherId] ) ,
		0, --IndividualShiftruntime
		ROW_NUMBER() OVER(Partition BY SPD.ShiftID  ORDER BY SPD.ShiftID)
  
		--CAST(((SELECT SUM(MR.VALUE) FROM TCD.ManualRewash MR WHERE SPD.ProgramMasterId = MR.FormulaId AND CAST(PS.StartDateTime AS date) = CAST(MR.RecordedDate AS date) GROUP BY CAST(MR.RecordedDate AS date),MR.FormulaId)) AS decimal(18,2))  
	FROM  TCD.ShiftProductionDataRollup SPD 	    
	INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId 
	INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId   
	INNER JOIN TCD.MachineSetup ms ON SPD.MachineId = ms.WasherId  
	LEFT OUTER JOIN  
	(  
		--IF Chain Plant  
		SELECT PCP.PlantProgramId,PCP.PlantChainId,PCP.ChainTextileCategoryId,PCP.EcolabTextileCategoryId,  
		PCP.FormulaSegmentId,PCP.EcolabSaturationId  
		FROM TCD.PlantChainProgram PCP    
		LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=PCP.FormulaSegmentId    
	)ChainPlant ON SPD.ChainProgaramId=ChainPlant.PlantProgramId    
	LEFT OUTER JOIN TCD.FormulaSegments FS1 ON FS1.FormulaSegmentID=PM.FormulaSegmentId   
	WHERE isNull(ms.IsPony,0) = 0  
	AND   
		CASE @StartDate                                                                                  
		WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                  
		ELSE CASE WHEN PS.[StartDateTime] >= @startdate  AND PS.[StartDateTime] <=  @enddate THEN 'TRUE'END                                                          
		END='TRUE'   
	AND  
		CASE @MachineType     
		WHEN '' THEN 'TRUE'           
		ELSE                                                        
		CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE        
		MS.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable))) THEN 'TRUE' END                                                        
		END='TRUE'      
	AND  
		CASE @machineGroup     
		WHEN '' THEN 'TRUE'           
		ELSE                                                        
		CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE        
		MS.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable)) THEN 'TRUE' END                                                        
		END='TRUE'   
	AND    
		CASE @Machine     
		WHEN '' THEN 'TRUE'           
		ELSE                                                        
		CASE WHEN SPD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                   
		END='TRUE'   
	AND        
		(CASE @EcolabCategory     
		WHEN '' THEN 'TRUE'           
		ELSE                                                        
		CASE WHEN SPD.EcolabTextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                        
		END='TRUE'   
	OR        
		CASE @ChainCategory     
		WHEN '' THEN 'TRUE'           
		ELSE                                                        
		CASE WHEN SPD.ChainTextileId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END                                                        
		END='TRUE'  )
	AND    
		CASE @PlantFormula     
		WHEN '' THEN 'TRUE'           
		ELSE                                                        
		CASE WHEN SPD.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                        
		END='TRUE'    
	AND       
		CASE @ChainFormula     
		WHEN '' THEN 'TRUE'           
		ELSE                                                        
		CASE WHEN SPD.ProgramMasterId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END                                                        
		END='TRUE'  
	AND        
		CASE @Customer     
		WHEN '' THEN 'TRUE'           
			ELSE                                                        
			CASE WHEN SPD.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                        
		END='TRUE'  
	--Added by Kiran   
	AND   
		CASE @FormulaSegement                                                                                  
		WHEN '' THEN  'TRUE'  
		ELSE  
			CASE WHEN SPD.ChainProgaramId  IS NOT NULL  and  SPD.ChainProgaramId>0 THEN  
				CASE WHEN ChainPlant.FormulaSegmentId IN (SELECT FormulaSegment FROM @FormulaSegmentTable) THEN 'TRUE' END                                                                                       
			ELSE   
			CASE WHEN FS1.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)  THEN 'TRUE'END     
		END                                                       
		END='TRUE'  
 
	
	--------------------------------  
   	 --For top 1 record combination updating the manual input data.  
	 UPDATE S SET ActualProduction=ISNULL(S.ActualProduction,0)+ISNULL(MIP.ManualIPActualWeight,0),S.NoOfLoads=ISNULL(S.NoOfLoads,0)+ISNULL(MIP.NoofLoads,0)  
	 FROM  @ProductionSummaryTable S  
	 INNER JOIN   
	  (  
	  SELECT WasherId,FormulaId,CONVERT(DATE,RecordedDate) AS LoadDate,SUM(Value) AS ManualIPActualWeight,  
	  COUNT(CONVERT(DATE,RecordedDate)) AS NoofLoads FROM  
	  TCD.ManualProduction MP  
	  GROUP BY WasherId,FormulaId,CONVERT(DATE,RecordedDate)  
	  )MIP ON MIP.WasherId=S.MachineId AND MIP.FormulaId=S.ProgramMasterId AND MIP.LoadDate=S.RecordDate  
	  WHERE S.RowNumberID=1  
	
	
	DECLARE @TableShiftruntime TABLE(ShiftID INT ,ShiftRuntime Decimal(20,10),ID INT,Name VARCHAR(1000))
	DECLARE @MaxShiftruntime1 DECIMAL(30,10),@noofShifts INT
	--FInding  total shiftruntime irrespective of Ecolab AccountnNumber
	--SELECT @MaxShiftruntime1=ISNULL(SUM(A.Shiftruntime),0) ,@noofShifts=COUNT(A.Shiftruntime)  FROM 
	--	(SELECT DISTINCT SHIFTID, ShiftRuntime Shiftruntime,RecordDATE FROM @ProductionSummaryTable1)A	
    
	 IF(@Viewtype = 3) --Ecolab Categorie View 
	 BEGIN  
	  IF(@Subview = 12)  
	  BEGIN  
	   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,TextileId)  
		AS  
		(  
		 SELECT   
		EC.CategoryName,  
		SUM(SPD.ActualProduction),  
		COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
		SUM(DISTINCT SPD.PlantTargetProd),  
		SUM(SPD.StandardProduction),  
		SUM([NoOfLoads]),  
		SUM( SPD.ShiftRunTime),  
		SUM( SPD.ShiftRunTime),  
		SUM(SPD.NoOfPieces),  
		SUM(SPD.Rewash),  
		EC.TextileId  
		  FROM @ProductionSummaryTable SPD LEFT JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId  
		WHERE EC.CategoryName IS NOT NULL  
		GROUP BY   
		  EC.CategoryName,EC.TextileId,SPD.ShiftId  
		  )  
		  INSERT INTO @resultSet  
		  SELECT DISTINCT  
		0,  
		DateRange,  
		SUM(TotalLoad),  
		SUM(WasherEfficiency),  
		SUM(PlantTargetLoad),  
		SUM(StandardLoad),  
		SUM(Numberofbatches),  
		SUM(ActualRunTime),  
		SUM(TargetRuntime),  
		SUM(NumberofPieces),  
		SUM(Rewash)  
		,@Viewtype   
		,@Subview  
		,TextileId  
		,0
		FROM CTE  
		WHERE TotalLoad IS NOT NULL  
		GROUP BY DateRange,TextileId     
		 END  
	  IF(@Subview = 17)  
	  BEGIN  
	   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
	   AS  
	   (  
	   SELECT   
     
	   PM.Name,  
	   SUM(SPD.ActualProduction),  
	   COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
	   SUM(DISTINCT SPD.PlantTargetProd),  
	   SUM(SPD.StandardProduction),  
	   SUM([NoOfLoads]),  
	   SUM( SPD.ShiftRunTime),  
	   SUM( SPD.ShiftRunTime),  
	   SUM(SPD.NoOfPieces),  
	   SUM(SPD.Rewash)  
		FROM @ProductionSummaryTable SPD INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId  
		 INNER JOIN TCD.ProgramMaster PM ON EC.TextileId = PM.EcolabTextileCategoryId AND SPD.ProgramMasterId = PM.ProgramId      
	   WHERE  
		(  
		CASE      
		 WHEN @drillvalue='' THEN 'TRUE'   
		 WHEN @drillvalue IS NULL THEN 'TRUE'    
		 ELSE                                                      
		  CASE WHEN EC.TextileId IN (@drillvalue) THEN 'TRUE' END              
		 END='TRUE'  
		) AND PM.NAME IS NOT NULL  
	   GROUP BY   
		  PM.Name,SPD.ShiftId  
		 )  
	   INSERT INTO @resultSet  
		 SELECT DISTINCT  
	   0,  
		  DateRange,  
		  SUM(TotalLoad),  
		  SUM(WasherEfficiency),  
		  SUM(PlantTargetLoad),  
		  SUM(StandardLoad),  
		  SUM(Numberofbatches),  
		  SUM(ActualRunTime),  
		  SUM(TargetRuntime),  
		  SUM(NumberofPieces),  
		  SUM(Rewash)  
		  ,@Viewtype   
		  ,@Subview  
		,0  
		,0
		   FROM CTE  
		 WHERE TotalLoad IS NOT NULL  
		 GROUP BY DateRange  
	  END    
	 END   
	
	 IF(@Viewtype = 4) --Textile Category View  
	 BEGIN   
	  IF(@Subview = 15)  
	  BEGIN  
	   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
		AS  
		(  
		SELECT      
		CC.Name,  
		SUM(SPD.ActualProduction),  
		COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
		SUM(DISTINCT SPD.PlantTargetProd),  
		SUM(SPD.StandardProduction),  
		SUM([NoOfLoads]),  
		SUM( SPD.ShiftRunTime),  
		SUM( SPD.ShiftRunTime),  
		SUM(SPD.NoOfPieces),  
		SUM(SPD.Rewash)  
		FROM @ProductionSummaryTable SPD LEFT JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId  
		WHERE CC.Name IS NOT NULL   
		GROUP BY   
		  CC.Name,CC.TextileId,SPD.ShiftId  
		  )  
		INSERT INTO @resultSet  
		  SELECT DISTINCT  
		0,  
		   DateRange,  
		   SUM(TotalLoad),  
		   SUM(WasherEfficiency),  
		   SUM(PlantTargetLoad),  
		   SUM(StandardLoad),  
		   SUM(Numberofbatches),  
		   SUM(ActualRunTime),  
		   SUM(TargetRuntime),  
		   SUM(NumberofPieces),  
		   SUM(Rewash)  
		   ,@Viewtype   
		   ,@Subview  
		 ,0  
		 ,0
		 FROM CTE  
		 WHERE TotalLoad IS NOT NULL  
		 GROUP BY DateRange  
			END    
	  IF(@Subview = 18)  
	  BEGIN  
	   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
		AS  
		(  
		SELECT          
		PM.Name,  
		SUM(SPD.ActualProduction),  
		COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
		SUM(DISTINCT SPD.PlantTargetProd),  
		SUM(SPD.StandardProduction),  
		SUM([NoOfLoads]),  
		SUM( SPD.ShiftRunTime),  
		SUM( SPD.ShiftRunTime),  
		SUM(SPD.NoOfPieces),  
		SUM(SPD.Rewash)  
		   FROM @ProductionSummaryTable SPD INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId  
		  INNER JOIN TCD.ProgramMaster PM ON CC.TextileId = PM.ChainTextileId AND SPD.ProgramMasterId = PM.ProgramId  
      
	   WHERE  
		(  
		CASE      
		 WHEN @drillvalue='' THEN 'TRUE'   
		 WHEN @drillvalue IS NULL THEN 'TRUE'    
		 ELSE                                                      
		  CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END              
		 END='TRUE'  
		)  
	   GROUP BY   
		  PM.Name,SPD.ShiftId  
		  )  
		INSERT INTO @resultSet  
		  SELECT DISTINCT  
		0,  
		   DateRange,  
		   SUM(TotalLoad),  
		   SUM(WasherEfficiency),  
		   SUM(PlantTargetLoad),  
		   SUM(StandardLoad),  
		   SUM(Numberofbatches),  
		   SUM(ActualRunTime),  
		   SUM(TargetRuntime),  
		   SUM(NumberofPieces),  
		   SUM(Rewash)  
		   ,@Viewtype   
		   ,@Subview  
		 ,0  
		 ,0
			FROM CTE  
		  WHERE TotalLoad IS NOT NULL  
		  GROUP BY DateRange  
	  END  
	 END  
  	  
	 IF(@Viewtype = 1) --Timeline View 
	 BEGIN  
		
		IF(@Subview = 5) -- Day view  
		BEGIN 
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			SPD.ShiftName  
			FROM @ProductionSummaryTable SPD ;			
		 
			INSERT INTO @resultSet  
			SELECT DISTINCT  
			0,  
			SPD.ShiftName,  
			SUM(SPD.ActualProduction),  
			COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
			SUM(DISTINCT SPD.PlantTargetProd),  
			SUM(SPD.StandardProduction),  
			SUM([NoOfLoads]),  
			SUM( SPD.ShiftRunTime),  
			SUM( SPD.ShiftRunTime),  
			SUM(SPD.NoOfPieces),  
			SUM(SPD.Rewash)  
			,@Viewtype   
			,@Subview  
			,0  
			,0			
			FROM @ProductionSummaryTable SPD  
			GROUP BY   
			SPD.ShiftName;

			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name		
		  
		 END  
  		  
		IF (@Subview = 4) --Week View  
		BEGIN  
			
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			CAST(RecordDate AS nvarchar(100))  
			FROM @ProductionSummaryTable SPD ;

			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,SortOrder)  
			AS  
			(  
				SELECT   
				CAST(RecordDate AS nvarchar(100)),  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM(SPD.StandardProduction),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime),  
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash)  
				,ROW_NUMBER () OVER (ORDER BY RecordDate)  
				FROM @ProductionSummaryTable SPD  
				GROUP BY DATEPART(weekday,RecordDate),cast( RecordDate AS  date)--,SPD.ShiftId
			)  
			INSERT INTO @resultSet  
			SELECT DISTINCT  
			0,  
			DateRange,  
			SUM(TotalLoad),  
			SUM(WasherEfficiency),  
			SUM(PlantTargetLoad),  
			SUM(StandardLoad),  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime),  
			SUM(NumberofPieces),  
			SUM(Rewash)  
			,@Viewtype   
			,@Subview  
			,0 
			,SortOrder 
			FROM CTE  
			WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange,SortOrder;  			

			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime,
					DateRange=CONVERT(VARCHAR(11),CONVERT(DATE,DateRange),113)+' ('+LEFT(datename(dw,DateRange),3)+')' --Appending DayName in Output	
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name;			
				
		END  
				
		IF(@Subview = 3) --MonthView  
		BEGIN  
		   DECLARE @FirstDay date = (SELECT TOP 1 RecordDate FROM @ProductionSummaryTable ORDER BY RecordDate)  
		   DECLARE @LastDay date = (SELECT TOP 1 RecordDate FROM @ProductionSummaryTable ORDER BY RecordDate DESC)  
		   DECLARE @FirstSunday date = NULL,  
		   @LastSaturday date = NULL  
        
		   SELECT   
		   @FirstSunday = CAST(DateAdd(dd, (8-DatePart(WEEKDAY,   
		   DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)))%7,   
		   DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)) AS DATE)   
  
		   SELECT  
		   @LastSaturday =   
		   DATEADD(dd,  
			-DATEPART(WEEKDAY,  
			 DATEADD(dd, -DAY(DATEADD(month, 1, @LastDay)),  
			 DATEADD(month, 1, @LastDay))) ,  
			DATEADD(dd, -DAY(DATEADD(MONTH, 1, @LastDay)), DATEADD(MONTH, 1, @LastDay)));  
		  
		  INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
		  SELECT DISTINCT SPD.ShiftId,SPD.ShiftRunTime AS ShiftRuntime,
				CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,-1,@FirstSunday)) = 7   
				AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate < DATEADD(DD,-1,@FirstSunday)) = 0)  
				THEN CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100))  
				WHEN DATEADD(DD,-1,@FirstSunday) > CAST(GETDATE() AS DATE)   
				THEN  
				CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @enddate, 101) AS nvarchar(100))  
				ELSE  
				CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) END As DateRange 
				FROM @ProductionSummaryTable SPD WHERE RecordDate < @FirstSunday AND RecordDate >= @FirstDay
		 UNION ALL
		  
		 SELECT DISTINCT SPD.ShiftId,SPD.ShiftRunTime AS ShiftRuntime,
				CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100))  + CHAR(13) + '-' +  
				CASE WHEN CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 121) AS nvarchar(100)) >  
				CAST(Convert(varchar, DateAdd(dd, (1 - DatePart(dw, @enddate) + 1), @enddate), 121) AS nvarchar(100))  
				THEN  CAST(Convert(varchar, DateAdd(dd, 1-1, @enddate), 101) AS nvarchar(100))  
				ELSE CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) END
				FROM @ProductionSummaryTable SPD  
				WHERE RecordDate BETWEEN @FirstSunday AND @LastSaturday

		 UNION ALL

		 SELECT DISTINCT SPD.ShiftId,SPD.ShiftRunTime AS ShiftRuntime,
		 CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,1,@LastSaturday)) = 1   
				AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate > DATEADD(DD,1,@LastSaturday)) = 0)  
				THEN   
				CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100))   
				ELSE  
				CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @LastDay, 101) AS nvarchar(100)) END
				FROM @ProductionSummaryTable SPD  
				WHERE RecordDate > @LastSaturday AND RecordDate <= @LastDay;				

  
		   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash) 
		    
		   AS  
		   (  
				SELECT          
				CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,-1,@FirstSunday)) = 7   
				AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate < DATEADD(DD,-1,@FirstSunday)) = 0)  
				THEN CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100))  
				WHEN DATEADD(DD,-1,@FirstSunday) > CAST(GETDATE() AS DATE)   
				THEN  
				CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @enddate, 101) AS nvarchar(100))  
				ELSE  
				CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) END As DateRange,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM(SPD.StandardProduction),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime),  
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash)  
  
				FROM @ProductionSummaryTable SPD  
				WHERE RecordDate < @FirstSunday AND RecordDate >= @FirstDay  
				GROUP BY SPD.ShiftId   
          
				UNION ALL    
    
				SELECT    
				CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100))  + CHAR(13) + '-' +  
				CASE WHEN CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 121) AS nvarchar(100)) >  
				CAST(Convert(varchar, DateAdd(dd, (1 - DatePart(dw, @enddate) + 1), @enddate), 121) AS nvarchar(100))  
				THEN  CAST(Convert(varchar, DateAdd(dd, 1-1, @enddate), 101) AS nvarchar(100))  
				ELSE CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) END  
				As DateRange,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM(SPD.StandardProduction),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime),  
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash)  
				FROM @ProductionSummaryTable SPD  
				WHERE RecordDate BETWEEN @FirstSunday AND @LastSaturday  
				GROUP BY Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101),  
				Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101),
				Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 121),		
				SPD.ShiftId  
         
				UNION ALL  
  
				SELECT   
				CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,1,@LastSaturday)) = 1   
				AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate > DATEADD(DD,1,@LastSaturday)) = 0)  
				THEN   
				CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100))   
				ELSE  
				CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @LastDay, 101) AS nvarchar(100)) END   As DateRange,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM(SPD.StandardProduction),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime),  
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash)  
				FROM @ProductionSummaryTable SPD  
				WHERE RecordDate > @LastSaturday AND RecordDate <= @LastDay   
				GROUP BY SPD.ShiftId  
		   )  
		   INSERT INTO @resultSet  
		   SELECT DISTINCT  
		   0,  
		   DateRange,  
		   SUM(TotalLoad),  
		   SUM(WasherEfficiency),  
		   SUM(PlantTargetLoad),  
		   SUM(StandardLoad),  
		   SUM(Numberofbatches),  
		   SUM(ActualRunTime),  
		   SUM(TargetRuntime),  
		   SUM(NumberofPieces),  
		   SUM(Rewash)  
		   ,@Viewtype   
		   ,@Subview  
			,0  
			,0
			FROM CTE  
			WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange ; 
		  
		   WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name
		END  
  
		IF(@Subview = 2) --Year view 
		BEGIN  
		   DECLARE @QuarterYear VARCHAR(100) = YEAR(@enddate);  

			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			DATENAME(MONTH, RecordDate) + ' ' +CAST( YEAR(RecordDate) as varchar)  
			FROM @ProductionSummaryTable SPD;

		   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,MonthOrder,YearOrder)  
		   AS  
		   (  
				SELECT   
				DATENAME(MONTH, RecordDate) + ' ' +CAST( YEAR(RecordDate) as varchar) As DateRange,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM(SPD.StandardProduction),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime),  
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash),
				DATEPART(MONTH, RecordDate) ,
				YEAR(RecordDate) 
				FROM @ProductionSummaryTable SPD  
				GROUP BY  DATEPART(MONTH, RecordDate),DATENAME(MONTH, RecordDate),SPD.ShiftId,YEAR(RecordDate)  
		   )  
		    INSERT INTO @resultSet  
			SELECT DISTINCT  
			0,  
			DateRange,  
			SUM(TotalLoad),  
			SUM(WasherEfficiency),  
			SUM(PlantTargetLoad),  
			SUM(StandardLoad),  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime),  
			SUM(NumberofPieces),  
			SUM(Rewash)  
			,@Viewtype   
			,@Subview  
			,0
			,ROW_NUMBER () OVER (ORDER BY YearOrder,MonthOrder)  
			FROM CTE  
			WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange,MonthOrder,YearOrder;
			
			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name
			 
		END     
  
		IF(@Subview = 1) --Quarter View  
		BEGIN  
			DECLARE @Year VARCHAR(100) = RIGHT(YEAR(@enddate),2);  
			
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name,ID)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			CASE 'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10))  
				WHEN 'Q1' THEN 'Jan' + RIGHT(YEAR(RecordDate),2)  + '- Mar' + RIGHT(YEAR(RecordDate),2)   
				WHEN 'Q2' THEN 'Apr' + RIGHT(YEAR(RecordDate),2)  + '- Jun' + RIGHT(YEAR(RecordDate),2)   
				WHEN 'Q3' THEN 'Jul' + RIGHT(YEAR(RecordDate),2)  + '-Sep' + RIGHT(YEAR(RecordDate),2)   
				WHEN 'Q4' THEN 'Oct' + RIGHT(YEAR(RecordDate),2)  + '- Dec'+ RIGHT(YEAR(RecordDate),2)   
				END, 
			cast( cast(RIGHT(YEAR(RecordDate),2) AS varchar ) +cast(  DATEPART(QUARTER, RecordDate) AS varchar) AS int)
			FROM @ProductionSummaryTable SPD ;
			
		    WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,RowNo)  
		    AS  
		    (  
				SELECT   
				CASE 'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10))  
				WHEN 'Q1' THEN 'Jan' + RIGHT(YEAR(RecordDate),2)  + '- Mar' + RIGHT(YEAR(RecordDate),2)   
				WHEN 'Q2' THEN 'Apr' + RIGHT(YEAR(RecordDate),2)  + '- Jun' + RIGHT(YEAR(RecordDate),2)   
				WHEN 'Q3' THEN 'Jul' + RIGHT(YEAR(RecordDate),2)  + '-Sep' + RIGHT(YEAR(RecordDate),2)   
				WHEN 'Q4' THEN 'Oct' + RIGHT(YEAR(RecordDate),2)  + '- Dec'+ RIGHT(YEAR(RecordDate),2)   
				END AS DateRange,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM(SPD.StandardProduction),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime),  
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash),
				cast( cast(RIGHT(YEAR(RecordDate),2) AS varchar ) +cast(  DATEPART(QUARTER, RecordDate) AS varchar) AS int)  RowNo  
				FROM @ProductionSummaryTable SPD  
				GROUP BY DATEPART(QUARTER, RecordDate),SPD.ShiftId ,RIGHT(YEAR(RecordDate),2)   
			)  
  
			INSERT INTO @resultSet  
			SELECT   
			0,  
			DateRange,  
			SUM(TotalLoad),  
			SUM(WasherEfficiency),  
			SUM(PlantTargetLoad),  
			SUM(StandardLoad),  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime),  
			SUM(NumberofPieces),  
			SUM(Rewash)  
			,@Viewtype   
			,@Subview  
			,0  
			,RowNo
			FROM CTE  
			WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange ,RowNo
			ORDER BY RowNo
			;

			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name;
  
	   END  
	 END  
  	 
	 IF(@Viewtype = 2) 	--Location View		 					
	 BEGIN 				   		
		IF(@Subview = 9)  --Washer group view 
		BEGIN  
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,ID)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			WG.WasherGroupId  
			FROM @ProductionSummaryTable SPD 
			INNER JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId  
			INNER JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId ;
				
			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,WasherGroupId)  
			AS  
				(  
				SELECT   
				--SPD.MachineId,  
				WG.WasherGroupName,  
				SUM(SPD.ActualProduction),  
				CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/   
				NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) *   
				COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM(SPD.StandardProduction),  
				SUM([NoOfLoads]),  
				SUM(  SPD.ShiftRunTime),  
				SUM(  SPD.ShiftRunTime),  
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash),  
				WG.WasherGroupId  
					FROM @ProductionSummaryTable SPD 
					INNER JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId  
					INNER JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId   
				GROUP BY WG.WasherGroupName,WG.WasherGroupId,SPD.ShiftId--,SPD.MachineId    
				)  
				INSERT INTO @resultSet  
				SELECT DISTINCT  
					0,  
					DateRange,  
					SUM(TotalLoad),  
					SUM(WasherEfficiency),  
					@PlantTargetProduction,  
					SUM(StandardLoad),  
					SUM(Numberofbatches),  
					SUM( ActualRunTime),  
					SUM( TargetRuntime),  
					SUM(NumberofPieces),  
					SUM(Rewash)  
					,@Viewtype   
					,@Subview  
					,WasherGroupId,
					0  
				FROM CTE  
					WHERE TotalLoad IS NOT NULL  
					GROUP BY DateRange,WasherGroupId	;

			WITH CTE1
			AS
			(
				SELECT SUM(ShiftRuntime) AS Shiftruntime,ID FROM @TableShiftruntime
				GROUP BY ID
			)

			--Update Shiftruntime in Temp table
			UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
			FROM @resultSet  RS
			LEFT OUTER JOIN 
			CTE1 TS ON RS.Id=TS.ID
						
		END  
  
		IF(@Subview = 10) --Washer/machine view  
		BEGIN 
				
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime,         
			cast( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName MachineName
			FROM @ProductionSummaryTable SPD   
			INNER JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId  
			INNER JOIN TCD.Washer w on MS.WasherId=w.WasherId  
			INNER JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId 
			WHERE   
				(  
				CASE @drillvalue     
				WHEN '' THEN 'TRUE'           
				ELSE                                                      
				CASE WHEN WG.WasherGroupId IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				)  ;				 
			  

			--SELECT * FROM @TableShiftruntime;
				 
			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
			AS  
			(  
			SELECT           
			cast( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName MachineName,  
			SUM(SPD.ActualProduction),  
			CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/   
			NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) *   
			COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)) ,  
			SUM(DISTINCT SPD.PlantTargetProd),  
			SUM(SPD.StandardProduction),  
			SUM([NoOfLoads]),  
			SUM(  SPD.ShiftRunTime),  
			SUM(  SPD.ShiftRunTime),  
			SUM(SPD.NoOfPieces),  
			SUM(SPD.Rewash)  
          
			FROM @ProductionSummaryTable SPD   
			INNER JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId  
			INNER JOIN TCD.Washer w on MS.WasherId=w.WasherId  
			INNER JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId   
			WHERE   
				(  
				CASE @drillvalue     
				WHEN '' THEN 'TRUE'           
				ELSE                                                      
				CASE WHEN WG.WasherGroupId IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				)  
			GROUP BY cast( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName,SPD.ShiftId  
  
			)  
  
			INSERT INTO @resultSet  
				SELECT DISTINCT  
				0,  
				DateRange,  
				SUM(TotalLoad),  
				SUM(WasherEfficiency),  
				@PlantTargetProduction,  
				SUM(StandardLoad),  
				SUM( Numberofbatches),  
				SUM( ActualRunTime),  
				SUM( TargetRuntime),  
				SUM(NumberofPieces),  
				SUM(Rewash)  
				,@Viewtype   
				,@Subview  
				,0  
				,0
			FROM CTE  
				WHERE TotalLoad IS NOT NULL  
				GROUP BY DateRange;

			WITH CTE1
			AS
			(
				SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
				GROUP BY Name 
			)				
			--Update Shiftruntime in Temp table
			UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
			FROM @resultSet  RS
			LEFT OUTER JOIN 
			CTE1 TS ON RS.DateRange=TS.Name		
				   
		END  
	 END  
  		 
	 IF(@Viewtype = 5) --ChainCategory View  
	 BEGIN  
	  IF(@Subview = 16)  
	  BEGIN  
		 -- ToDo : Change this part for chaincategory  
		 WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,textileId)  
	   AS  
	   (  
		SELECT      
	   CC.NAME,  
	   SUM(SPD.ActualProduction),  
	   COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
	   SUM(DISTINCT SPD.PlantTargetProd),  
	   SUM(SPD.StandardProduction),  
	   SUM([NoOfLoads]),  
	   SUM( SPD.ShiftRunTime),  
	   SUM( SPD.ShiftRunTime),  
	   SUM(SPD.NoOfPieces),  
	   SUM(SPD.Rewash),  
	   cc.TextileId  
		  FROM  
		@ProductionSummaryTable SPD  
	   INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
		INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = PM.PlantProgramId  
		INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId   
	   Group by   
		 CC.Name,cc.TextileId,SPD.ShiftId  
		 )  
	   INSERT INTO @resultSet  
		 SELECT DISTINCT  
		  0,  
		  DateRange,  
		  SUM(TotalLoad),  
		  SUM(WasherEfficiency),  
		  @PlantTargetProduction,  
		  SUM(StandardLoad),  
		  SUM(Numberofbatches),  
		  SUM(ActualRunTime),  
		  SUM(TargetRuntime),  
		  SUM(NumberofPieces),  
		  SUM(Rewash)  
		  ,@Viewtype   
		  ,@Subview  
		  ,textileId
		  ,0  
		FROM CTE  
		 WHERE TotalLoad IS NOT NULL  
		 GROUP BY DateRange,textileId  
	  END  
      
	  IF(@Subview = 19)  
	  BEGIN  
	   -- ToDo : Change this part for chaincategory  
		WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
	   AS  
	   (  
		SELECT    
	   PCP.PlantProgramName,  
	   SUM(SPD.ActualProduction),  
	   COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
	   SUM(DISTINCT SPD.PlantTargetProd),  
	   SUM(SPD.StandardProduction),  
	   SUM([NoOfLoads]),  
	   SUM( SPD.ShiftRunTime),  
	   SUM( SPD.ShiftRunTime),  
	   SUM(SPD.NoOfPieces),  
	   SUM(SPD.Rewash)  
		 FROM @ProductionSummaryTable SPD  
	   INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
		INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = PM.PlantProgramId  
		INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId   
		WHERE  
	   (  
		 CASE @drillvalue     
		  WHEN '' THEN 'TRUE'           
		  ELSE                                                      
		  CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END              
		  END='TRUE'  
		)  
	   Group by   
		 PCP.PlantProgramName,PCP.PlantProgramId,SPD.ShiftId  
		 )  
		 INSERT INTO @resultSet  
		 SELECT DISTINCT  
		  0,  
		  DateRange,  
		  SUM(TotalLoad),  
		  SUM(WasherEfficiency),  
		  @PlantTargetProduction,  
		  SUM(StandardLoad),  
		  SUM(Numberofbatches),  
		  SUM(ActualRunTime),  
		  SUM(TargetRuntime),  
		  SUM(NumberofPieces),  
		  SUM(Rewash)  
		  ,@Viewtype   
		  ,@Subview  
		  ,0  
		  ,0
		FROM CTE  
		 WHERE TotalLoad IS NOT NULL  
		 GROUP BY DateRange  
	  END  
  
	 END  
  		
	 IF(@Viewtype = 6) --Customer View  
		 BEGIN 
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			PC.CustomerName  
			FROM @ProductionSummaryTable SPD  INNER JOIN TCD.PlantCustomer PC on PC.CustomerId = SPD.CustomerId  ;	

		    WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
		    AS  
			(  
				SELECT   
				PC.CustomerName,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM(SPD.StandardProduction),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime),  
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash)  
				FROM @ProductionSummaryTable SPD  INNER JOIN TCD.PlantCustomer PC on PC.CustomerId = SPD.CustomerId  
				GROUP BY   
				PC.CustomerName,SPD.ShiftId  
			)  
			INSERT INTO @resultSet  
			SELECT DISTINCT  
			0,  
			DateRange,  
			SUM(TotalLoad),  
			SUM(WasherEfficiency),  
			@PlantTargetProduction,  
			SUM(StandardLoad),  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime),  
			SUM(NumberofPieces),  
			SUM(Rewash)  
			,@Viewtype   
			,@Subview  
			,0  
			,0
			FROM CTE  
			WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange ; 
			
			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name	

		 END  
  	  
	 IF(@Viewtype = 7) --Formula View 
	 BEGIN  
	   WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash)  
	   AS  
	   (  
	   SELECT   
	   PM.Name,  
	   SUM(SPD.ActualProduction),  
		 COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
	   SUM(DISTINCT SPD.PlantTargetProd),  
	   SUM(SPD.StandardProduction),  
	   SUM([NoOfLoads]),  
	   SUM( SPD.ShiftRunTime),  
	   SUM( SPD.ShiftRunTime),  
	   SUM(SPD.NoOfPieces),  
	   SUM(SPD.Rewash)  
	   FROM @ProductionSummaryTable SPD   
	   INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
	   Group by   
	   PM.Name,SPD.ShiftId  
	   )  
	   INSERT INTO @resultSet  
		 SELECT DISTINCT  
		  0,  
		  DateRange,  
		  SUM(TotalLoad),  
		  SUM(WasherEfficiency),  
		  @PlantTargetProduction,  
		  SUM(StandardLoad),  
		  SUM(Numberofbatches),  
		  SUM(ActualRunTime),  
		  SUM(TargetRuntime),  
		  SUM(NumberofPieces),  
		  SUM(Rewash)  
		  ,@Viewtype   
		  ,@Subview  
		  ,0  
		  ,0
		FROM CTE  
		 WHERE TotalLoad IS NOT NULL  
		 GROUP BY DateRange  
		END  
  	  	
	 IF(@Viewtype = 8) --Formula segmentView 
	 BEGIN  
		IF(@Subview =20)-- Formula Segment  
		BEGIN 
					
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			FS.SegmentName    
			FROM @ProductionSummaryTable SPD
			INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
			INNER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=SPD.FormulaSegmentID ;
					
			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,FormulaSegmentID)  
			AS  
			(  
				SELECT   
				FS.SegmentName,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM(SPD.StandardProduction),  
				SUM([NoOfLoads]),  
				SUM(SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime),  
				--SUM(SPD.IndividualShiftRunTime),
				--SUM(SPD.IndividualShiftRunTime),
				SUM(SPD.NoOfPieces),  
				SUM(SPD.Rewash),  
				SPD.FormulaSegmentID  
				FROM @ProductionSummaryTable SPD   
				INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
				INNER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=SPD.FormulaSegmentID   
				Group by SPD.FormulaSegmentID,FS.SegmentName,SPD.ShiftId    
			)  
			INSERT INTO @resultSet  
			(  
			ShiftId,  
			DateRange ,  
			TotalLoad  ,  
			WasherEfficiency ,  
			PlantTargetLoad  ,  
			StandardLoad ,  
			Numberofbatches ,  
			[ActualRunTime],   
			[TargetRunTime],  
			NumberofPieces  ,  
			Rewash ,  
			Viewtype ,  
			Subview ,  
			Id  
			,SortOrder
			)  
			SELECT DISTINCT  
			0,  
			DateRange,  
			SUM(TotalLoad),  
			SUM(WasherEfficiency),  
			@PlantTargetProduction,  
			SUM(StandardLoad),  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime),  
			SUM(NumberofPieces),  
			SUM(Rewash)  
			,@Viewtype   
			,@Subview  
			,FormulaSegmentID  
			,0
			FROM CTE  
			WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange,FormulaSegmentID;
			
			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name	
			 
		END  
		
		IF(@Subview =21)-- Formula Categories  
		BEGIN 
		  
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT SPD.ShiftId,SPD.ShiftRunTime AS ShiftRuntime, EC.CategoryName    
				FROM @ProductionSummaryTable SPD
				INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
				WHERE  
					(  
					CASE      
					WHEN @drillvalue='' THEN 'TRUE'   
					WHEN @drillvalue IS NULL THEN 'TRUE'    
					ELSE                                                      
					CASE WHEN SPD.FormulaSegmentID IN (@drillvalue) THEN 'TRUE' END              
					END='TRUE'  
					) --AND EC.CategoryName IS NOT NULL
			UNION ALL

			SELECT DISTINCT SPD.ShiftId,SPD.ShiftRunTime AS ShiftRuntime, CC.NAME   
			FROM @ProductionSummaryTable SPD
			--INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
			--INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = SPD.ChainProgaramId  
			INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
				WHERE  
				(  
				CASE      
				WHEN @drillvalue='' THEN 'TRUE'   
				WHEN @drillvalue IS NULL THEN 'TRUE'    
				ELSE                                                      
				CASE WHEN SPD.FormulaSegmentID IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				);
			  
			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,TextileId)  
			AS  
			(  
				SELECT EC.CategoryName,	SUM(SPD.ActualProduction),COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),
				SUM(DISTINCT SPD.PlantTargetProd),SUM(SPD.StandardProduction),SUM([NoOfLoads]),SUM( SPD.ShiftRunTime),SUM( SPD.ShiftRunTime),  				
				SUM(SPD.NoOfPieces),SUM(SPD.Rewash),EC.TextileId  
				FROM @ProductionSummaryTable SPD   
				INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId  
				WHERE  
				(  
					CASE      
					WHEN @drillvalue='' THEN 'TRUE'   
					WHEN @drillvalue IS NULL THEN 'TRUE'    
					ELSE                                                      
					CASE WHEN SPD.FormulaSegmentID IN (@drillvalue) THEN 'TRUE' END              
					END='TRUE'  
				) --AND EC.CategoryName IS NOT NULL  
				GROUP BY EC.CategoryName,EC.TextileId,SPD.ShiftId  
  
				UNION  ALL
  
				SELECT CC.NAME,SUM(SPD.ActualProduction),COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),SUM(SPD.StandardProduction),SUM([NoOfLoads]),SUM( SPD.ShiftRunTime),SUM( SPD.ShiftRunTime),				
				SUM(SPD.NoOfPieces),SUM(SPD.Rewash), ( 1000+ cc.TextileId)   TextileId
				FROM @ProductionSummaryTable SPD  
				--INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
				--INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = SPD.ChainProgaramId  
				INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
				WHERE  
				(  
				CASE      
				WHEN @drillvalue='' THEN 'TRUE'   
				WHEN @drillvalue IS NULL THEN 'TRUE'    
				ELSE                                                      
				CASE WHEN SPD.FormulaSegmentID IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				)   
				Group by CC.Name,cc.TextileId,SPD.ShiftId  
				)  
				INSERT INTO @resultSet  
				(  
				ShiftId,  
				DateRange ,  
				TotalLoad  ,  
				WasherEfficiency ,  
				PlantTargetLoad  ,  
				StandardLoad ,  
				Numberofbatches ,  
				[ActualRunTime],   
				[TargetRunTime],  
				NumberofPieces  ,  
				Rewash ,  
				Viewtype ,  
				Subview ,  
				Id  ,
				SortOrder
				)  
				SELECT DISTINCT  
				0,  
				DateRange,  
				SUM(TotalLoad),  
				SUM(WasherEfficiency),  
				SUM(PlantTargetLoad),  
				SUM(StandardLoad),  
				SUM(Numberofbatches),  
				SUM(ActualRunTime),  
				SUM(TargetRuntime),  
				SUM(NumberofPieces),  
				SUM(Rewash)  
				,@Viewtype   
				,@Subview  
				,TextileId  
				,0
				FROM CTE  
				WHERE TotalLoad IS NOT NULL  
				GROUP BY DateRange,TextileId  ;
			
			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name	

	    END  
		
		IF(@Subview=22) --Formula  
		BEGIN  
			---Checking Drill value Ecolb/chain category
			DECLARE @ChaincategoryDrillValue INT
			IF(@Drillvalue>1000)
				SET @ChaincategoryDrillValue=@Drillvalue-1000
			 ELSE IF (@Drillvalue <1000)
				SET @ChaincategoryDrillValue=@Drillvalue+1000
			---End

			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			PM.Name    
			FROM @ProductionSummaryTable SPD
			--INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId  
			INNER JOIN TCD.ProgramMaster PM ON SPD.ProgramMasterId = PM.ProgramId
			WHERE  SPD.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable) 
				AND
				(  
				CASE      
				WHEN @drillvalue='' THEN 'TRUE'   
				WHEN @drillvalue IS NULL THEN 'TRUE'    
				ELSE                                                      
				CASE WHEN SPD.EcolabTextileId  IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				) --AND PM.NAME IS NOT NULL
			
			UNION

			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			PM.Name    
			FROM @ProductionSummaryTable SPD
			--INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId  
			INNER JOIN TCD.ProgramMaster PM ON  SPD.ProgramMasterId = PM.ProgramId    
			WHERE  SPD.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)
			AND 
				(  
				CASE      
				WHEN @drillvalue='' THEN 'TRUE'   
				WHEN @drillvalue IS NULL THEN 'TRUE'    
				ELSE                                                      
				CASE WHEN SPD.ChainTextileId IN (@ChaincategoryDrillValue) THEN 'TRUE' END              
				END='TRUE' 
				) ;

			WITH CTE(DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,StandardLoad,Numberofbatches,ActualRunTime,TargetRuntime,NumberofPieces,Rewash,ID)  
			AS  
			(  
				SELECT PM.Name,SUM(SPD.ActualProduction),COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),SUM(SPD.StandardProduction),SUM([NoOfLoads]),SUM(SPD.ShiftRunTime),SUM(SPD.ShiftRunTime),			
				SUM(SPD.NoOfPieces),SUM(SPD.Rewash),PM.ProgramId  
				FROM @ProductionSummaryTable SPD   
				--INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId  
				INNER JOIN TCD.ProgramMaster PM ON SPD.ProgramMasterId = PM.ProgramId    
				WHERE  SPD.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)
				AND  
				(  
					CASE      
					WHEN @drillvalue='' THEN 'TRUE'   
					WHEN @drillvalue IS NULL THEN 'TRUE'    
					ELSE                                                      
					CASE WHEN SPD.EcolabTextileId IN (@drillvalue) THEN 'TRUE' END              
					END='TRUE'  
				) --AND PM.NAME IS NOT NULL 
				GROUP BY PM.Name,PM.ProgramId--,SPD.ShiftId 
  
				UNION   
  
				SELECT PM.Name,SUM(SPD.ActualProduction),COALESCE(SUM(SPD.ActualProduction)/ NULLIF((SUM([LoadEfficiency]) * SUM(SPD.TimeEfficiency)),0), 0),  
				SUM(DISTINCT SPD.PlantTargetProd),SUM(SPD.StandardProduction),SUM([NoOfLoads]),SUM( SPD.ShiftRunTime),SUM( SPD.ShiftRunTime),  
				SUM(SPD.NoOfPieces),SUM(SPD.Rewash),PM.ProgramId  
				FROM @ProductionSummaryTable SPD   
				--INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId  
				INNER JOIN TCD.ProgramMaster PM ON  SPD.ProgramMasterId = PM.ProgramId    
				WHERE  SPD.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)
				AND
				(  
					CASE      
					WHEN @drillvalue='' THEN 'TRUE'   
					WHEN @drillvalue IS NULL THEN 'TRUE'    
					ELSE                                                      
					CASE WHEN SPD.ChainTextileId IN (@ChaincategoryDrillValue) THEN 'TRUE' END              
					END='TRUE' 
				)  
				GROUP BY PM.Name,PM.ProgramId--,SPD.ShiftId    
			)  
  
			INSERT INTO @resultSet(ShiftId,DateRange,TotalLoad,WasherEfficiency,PlantTargetLoad,  
			StandardLoad,Numberofbatches,[ActualRunTime],[TargetRunTime],NumberofPieces  ,  
			Rewash,Viewtype,Subview,Id  
			)  
			SELECT DISTINCT 0,DateRange,SUM(TotalLoad),	SUM(WasherEfficiency),SUM(PlantTargetLoad),
			SUM(StandardLoad),SUM(Numberofbatches),	SUM(ActualRunTime),	SUM(TargetRuntime),	SUM(NumberofPieces),
			SUM(Rewash),@Viewtype ,@Subview,ID  
			FROM CTE  
			WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange,ID ; 
			
			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name	

		END  
	 END  


	DECLARE @MaxShiftruntime DECIMAL(30,10)=NULL   
	IF(@Viewtype IN (2,8) ) --for Location and Formula, shift hours will be total shifthours for particular duration
	BEGIN		
		 IF(@Subview IN(9,10,20,21,22))
		 BEGIN
			SELECT @MaxShiftruntime=SUM(A.Shiftruntime)  FROM
				(
				SELECT DISTINCT ShiftID AS ShiftID,MAX(ShiftRuntime) AS Shiftruntime  FROM @TableShiftruntime
				GROUP BY ShiftID
				)A
		 END
	END
	ELSE IF(@Viewtype IN(1))
	BEGIN
		SELECT @MaxShiftruntime= (SELECT SUM(ShiftRuntime) AS Shiftruntime FROM @TableShiftruntime)		
	END
	

	--- ********* Return result ********************  
  
		SELECT DISTINCT  ShiftId, DateRange,ISNULL([TCD].[FnConsumptionOnMetrics](TotalLoad,'Weight',@UserId),0) AS TotalLoad,        
		  ISNULL([TCD].[FnConsumptionOnMetrics](WasherEfficiency,'Weight',@UserId),0)AS Washerefficiency,  
		  ISNULL([TCD].[FnConsumptionOnMetrics](PlantTargetLoad,'Weight',@UserId),0) AS PlantTargetLoad,
		  ISNULL([TCD].[FnConsumptionOnMetrics](StandardLoad,'Weight',@UserId),0) AS StandardLoad,
		  ISNULL(Numberofbatches,0)AS NumberofBatches,ISNULL(ActualRunTime,0) ShiftRuntime,ISNULL(TargetRunTime,0) TargetRuntime,
		  ISNULL(NumberofPieces,0) AS NoofPieces,  
		  ISNULL(Rewash,0) AS Rewash,Viewtype,Subview ,Id,@CorrectionVariable AS CorrectionVariable,@MaxShiftruntime AS Maxshiftruntime,SortOrder--, 
		--  @MaxShiftruntime1 AS MaxShiftruntime1, @noofShifts AS NoOfshifts  
		  FROM @resultSet  
  
  
   
SET NOCOUNT OFF     
END  

GO

IF NOT EXISTS (SELECT 1 FROM [TCD].[ReportViewByMode] WHERE Name = 'Formula')
BEGIN
INSERT INTO [TCD].[ReportViewByMode]
(Name) VALUES ('Formula')
END


