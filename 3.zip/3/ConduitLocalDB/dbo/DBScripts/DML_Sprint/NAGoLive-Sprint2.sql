﻿IF NOT EXISTS(SELECT * FROM sys.columns WHERE  object_id = OBJECT_ID(N'TCD.Plant') AND name = 'MigrationStep')
BEGIN
	ALTER TABLE TCD.Plant 
	ADD MigrationStep INT NULL DEFAULT 1
END

IF NOT EXISTS(SELECT * FROM sys.columns WHERE  object_id = OBJECT_ID(N'TCD.Plant') AND name = 'LastMigratedBatch')
BEGIN
	ALTER TABLE TCD.Plant 
	ADD LastMigratedBatch INT NULL
END

IF NOT EXISTS(SELECT * FROM sys.columns WHERE  object_id = OBJECT_ID(N'TCD.Plant') AND name = 'LastMigratedBatchTime')
BEGIN
	ALTER TABLE TCD.Plant 
	ADD LastMigratedBatchTime DateTime NULL
END

/*TCD.UpdateControllerConnectivityAlarm*/
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[UpdateControllerConnectivityAlarm]') AND type in (N'P', N'PC'))
DROP PROCEDURE [TCD].[UpdateControllerConnectivityAlarm]

GO

CREATE PROCEDURE [TCD].[UpdateControllerConnectivityAlarm]
( 
    @Controllerid INT,
	@AlarmCode INT,
    @IsActive BIT
)

AS
BEGIN

	SET NOCOUNT ON              --SQLEnlight SA0017

	DECLARE
		@ECOLABAccountNumber	NVARCHAR(1000)
	
	IF NOT EXISTS(SELECT * FROM TCD.AlarmData WHERE controllerID = @ControllerId AND AlarmCode = @AlarmCode AND IsActive = 1)
	BEGIN
		IF(@IsActive = 1)
		BEGIN
			SELECT @ECOLABAccountNumber = EcolabAccountNumber FROM TCD.Plant
			INSERT INTO [TCD].[AlarmData]
				(EcoalabAccountNumber,
					AlarmCode,
					controllerID,
					IsActive,
					StartDate
				)
			SELECT
				@ECOLABAccountNumber,
				@AlarmCode,
				@Controllerid,
				@IsActive,
				GETUTCDATE()
		END
	END
	
	ELSE
	BEGIN
		IF(@IsActive = 0)
		BEGIN
			UPDATE [TCD].[AlarmData] SET IsActive=@IsActive, EndDate=GETUTCDATE() WHERE controllerID = @ControllerId AND AlarmCode = @AlarmCode AND IsActive=1
		END
	END
 
END


/*TCD.GetAlarmDetailsReport*/
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetAlarmDetailsReport]') AND type in (N'P', N'PC'))
DROP PROCEDURE [TCD].[GetAlarmDetailsReport]

GO

CREATE PROCEDURE [TCD].[GetAlarmDetailsReport] (
										  @Corporate Varchar(max) = '',
										  @Country Varchar(max) = '',
										  @Region Varchar(max) = '',
										  @EcolabAccountNumber Nvarchar(25) = '',
										  @Controller Varchar(max) = '',
										  @Machine Varchar(max) = '', 
										  @machineGroup Varchar(max) = '',
										  @Formula Varchar(max) = '',
										  @MachineType Varchar(20)= '',
										  @Alarm Varchar(max) = '',
										  @FromDate Datetime = '',
										  @ToDate Datetime = '',
										  @GroupId Varchar(max) = '',
										  @MachineInternalId Varchar(max) = '',
										  @SortColumnID INT = NULL,
										  @SortDirection Varchar(100) = '',
										  @UserId INT = NULL,
										  @PageNo	INT	 = NULL,
										  @RecordsPerPage INT = NULL
									   )
AS   
BEGIN   
SET NOCOUNT ON;   

SET @FromDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@FromDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@FromDate AS time)) AS DateTime))
SET @ToDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@ToDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@ToDate AS time)) AS DateTime))


DECLARE @ReportGenerated INT = 6
/* Inserting the record into Report History */
SET @PageNo = @PageNo-1
INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)
SELECT @EcolabAccountNumber,UM.UserId,
	  UM.LoginName,
	  GETUTCDATE(),
	  @ReportGenerated,
	  CASE WHEN @ReportGenerated = 6
		THEN 'Generated Report : AlarmDetailsReport' END
	  FROM TCD.UserMaster UM
	    WHERE	UM.EcolabAccountNumber =	@EcolabAccountNumber AND UM.UserId = @UserId

/* Completed the record insertion into Report History */

DECLARE @Month INT = MONTH(GETDATE()),
	   @SortField Varchar(100) = '',
	   @SummationInMin Int = NULL,
	   @SQLStatement varchar(max)

	     SELECT @SortField =  CASE WHEN @SortColumnID = 13 THEN 'AlarmDescription'
						WHEN @SortColumnID = 14 THEN 'AlarmCode'
						WHEN @SortColumnID = 69 THEN 'EndDate'
						WHEN @SortColumnID = 168 THEN 'StartDate'
						WHEN @SortColumnID = 247 THEN 'Controller'
						WHEN @SortColumnID = 248 THEN 'AlarmCode'
						WHEN @SortColumnID = 249 THEN 'WasherNumber'
						WHEN @SortColumnID = 250 THEN 'BatchId'
						WHEN @SortColumnID = 251 THEN 'ValveNumber'
						WHEN @SortColumnID = 252 THEN 'ChemicalName'
						WHEN @SortColumnID = 253 THEN 'InjectionNo'
						WHEN @SortColumnID = 254 THEN 'FormulaNo'
						WHEN @SortColumnID = 255 THEN 'FormulaName'
						WHEN @SortColumnID = 256 THEN 'DesiredValue'
						WHEN @SortColumnID = 257 THEN 'MeasuredValue'
						WHEN @SortColumnID = 258 THEN 'IsActiveStatus'
						WHEN @SortColumnID = 0 THEN 'StartDate'
						 END



DECLARE @ControllerTable TABLE(Controller Varchar(100))
INSERT INTO @ControllerTable(Controller) EXEC [TCD].[charlistToTable] @Controller,','

DECLARE @MachineTable TABLE(Machine Varchar(100))
INSERT INTO @MachineTable(Machine) EXEC [TCD].[charlistToTable] @Machine,','

DECLARE @GroupMachineTable TABLE(GroupId INT,MachineInternalId INT)  
INSERT INTO @GroupMachineTable(GroupId,MachineInternalId) 
SELECT GroupId,MachineInternalId FROM TCD.MachineSetup MS 
									INNER JOIN TCD.Washer WS ON MS.WasherId = WS.WasherId WHERE WS.PlantWasherNumber IN (SELECT Machine FROM @MachineTable);

DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))
INSERT INTO @WasherGroupTable(MachineGroup) EXEC [TCD].[charlistToTable] @machineGroup,','

DECLARE @FormulaTable TABLE(Formula Varchar(100))
INSERT INTO @FormulaTable(Formula) EXEC [TCD].[charlistToTable] @Formula,','

DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))
INSERT INTO @MachineTypeTable(MachineType) EXEC [TCD].[charlistToTable] @MachineType,','

DECLARE @AlarmsTable TABLE(Alarm Varchar(100))
INSERT INTO @AlarmsTable(Alarm) EXEC [TCD].[charlistToTable] @Alarm,','

DECLARE @GroupTable TABLE(GroupId Varchar(100))
INSERT INTO @GroupTable(GroupId) EXEC [TCD].[CharlistToTable] @GroupId,','

DECLARE @MachineInternalTable TABLE(MachineInternalId Varchar(100))
INSERT INTO @MachineInternalTable(MachineInternalId) EXEC [TCD].[CharlistToTable] @MachineInternalId,','

	  DECLARE @AlarmTable TABLE(
							 AlarmCode Int,
							 AlarmDescription NVarchar(2000),
							 Controller Nvarchar(100),
							 StartDate Datetime,
							 EndDate Datetime,
							 SecDuration INT,
							 WasherNumber INT,
							 BatchID INT,
							 ValveNumber INT,
							 ChemicalName Nvarchar(1000),
							 InjectionNo INT,
							 FormulaNo INT,
							 FormulaName Nvarchar(1000),
							 DesiredValue decimal(10,2),
							 MeasuredValue decimal(10,2),
							 IsActiveStatus BIT
    						  )

;WITH NonPonyWashers_CTE (WasherId)
AS
(
    SELECT WasherId
    FROM [TCD].MachineSetup MS
    WHERE MS.IsPony = 0    
)

INSERT INTO @AlarmTable(
							 AlarmCode ,
							 AlarmDescription ,
							 Controller ,
							 StartDate ,
							 EndDate ,
							 SecDuration ,
							 WasherNumber ,
							 BatchID ,
							 ValveNumber ,
							 ChemicalName,
							 InjectionNo ,
							 FormulaNo ,
							 FormulaName ,
							 DesiredValue ,
							 MeasuredValue ,
							 IsActiveStatus 
    						  )
SELECT 
		  DISTINCT
			  AD.AlarmCode,	
	   		  AM.Description,	
			  (SELECT cc.Name FROM [TCD].ConduitController CC  WHERE cc.ControllerId = AD.ControllerId) AS Controller,	 
			  AD.StartDate,
			  AD.EndDate,
			  DATEDIFF(SECOND,AD.StartDate,AD.EndDate),
			  MS.WasherId,
			  AD.BatchId,
			  AD.Valve,
			  PM.Name,
			  AD.InjectionNumber,
			  AD.ProgramId,
			  PP.Name,
			  AD.DesiredQuatity,
			  AD.MeasuredQuantity,
			  AD.IsActive
	FROM [TCD].AlarmData AS AD
		   INNER JOIN [TCD].AlarmMaster AM ON AD.AlarmCode = AM.AlarmCode
		   LEFT JOIN NonPonyWashers_CTE MS ON MS.WasherId = AD.MachineId		   
		   LEFT JOIN [TCD].ControllerEquipmentSetup CES ON AD.Valve = CES.ControllerEquipmentId AND AD.ControllerId = CES.ControllerId
		   LEFT JOIN [TCD].ProductMaster PM ON CES.ProductId = PM.ProductId
		   LEFT JOIN [TCD].ProgramMaster PP ON AD.ProgramId = PP.ProgramId

		    WHERE  
				CASE @Controller   
				 WHEN '' THEN 'TRUE'         
				 ELSE                                                      
				  CASE WHEN AD.ControllerId IN (SELECT Controller FROM @ControllerTable) THEN 'TRUE' END                                                      
				END='TRUE' 

				AND       
				CASE @Machine   
				WHEN '' THEN 'TRUE'         
				ELSE                                                      
				CASE WHEN AD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
				END='TRUE' 
				AND       

				CASE @machineGroup   
	   			WHEN '' THEN 'TRUE'         
				ELSE                                                      
				CASE WHEN AD.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable) THEN 'TRUE' END                                    
				END='TRUE' 
				AND    

				CASE @Formula   
	     		WHEN '' THEN 'TRUE'         
				ELSE                                                      
				CASE WHEN AD.ProgramId IN (SELECT Formula FROM @FormulaTable) AND AD.AlarmCode NOT IN (9000) THEN 'TRUE' END                                                      
				END='TRUE' 
				AND       

				CASE @MachineType   
				WHEN '' THEN 'TRUE'         
				ELSE                                                      
				cASE WHEN AD.GroupId IN (SELECT WG.WasherGroupId FROM [TCD].WasherGroup WG WHERE WG.WasherGroupTypeId IN (select MachineType from @MachineTypeTable)) THEN 'TRUE' END                                                      
				END='TRUE' 

				AND       
				CASE @FromDate                                                                                
				WHEN '' THEN Case WHEN MONTH(AD.StartDate) = @Month Then  'true' END                                                                                
				ELSE CASE WHEN AD.StartDate >= @FromDate and AD.StartDate<= @ToDate THEN 'true'END                                                        
				END='true'

				AND
				CASE @Alarm   
				WHEN '' THEN 'TRUE'         
				ELSE                                                      
				CASE WHEN AD.AlarmCode IN (SELECT Alarm FROM @AlarmsTable) THEN 'TRUE' END                                                      
				END='TRUE' 

				AND
				CASE @GroupId 
	   			WHEN '' THEN 'TRUE' 
				ELSE        
				CASE WHEN (AD.GroupId IN (@GroupId) AND 
				AD.MachineInternalId  IN (@MachineInternalId)) THEN 'TRUE' END                                                   
				END='TRUE' 
				AND

				CASE @MachineInternalId 
                    WHEN '' THEN 'TRUE' 
				ELSE        
				CASE WHEN (AD.GroupId IN (@GroupId) AND 
				AD.MachineInternalId  IN (@MachineInternalId)) THEN 'TRUE' END                                                   
				END='TRUE' 
				
			SELECT  
						AlarmCode,
						AlarmDescription,
						Controller,
						StartDate,  
						EndDate,
						SecDuration, 
						WasherNumber,  
						BatchId, 
						ValveNumber, 
						ChemicalName,
						InjectionNo,
						FormulaNo, 
						FormulaName, 
						DesiredValue, 
						MeasuredValue, 
						IsActiveStatus,
						COUNT(*) OVER() as TotalCount,
						ROW_NUMBER() OVER (ORDER BY  + @SortField + ' ' + @SortDirection) AS ROWNO
			INTO #AlarmRowTable
			FROM @AlarmTable

  			SELECT 		   	    
					C.AlarmCode,
	   				C.AlarmDescription,
    						C.StartDate,
						C.EndDate,
					(SELECT RIGHT('0' + CAST(DATEDIFF(SECOND,C.StartDate,C.EndDate) / 3600 AS VARCHAR),4) + ':' +
							RIGHT('0' + CAST((DATEDIFF(SECOND,C.StartDate,C.EndDate) / 60) % 60 AS VARCHAR),2)  + ':' +
							RIGHT('0' + CAST(DATEDIFF(SECOND,C.StartDate,C.EndDate) % 60 AS VARCHAR),2)) AS AlarmDuration,
						--SecDuration	AS AlarmDuration,
					C.Controller,
					C.WasherNumber,
					C.BatchID,
					C.ValveNumber,
					C.ChemicalName,
					C.InjectionNo,
					C.FormulaNo,
					C.FormulaName,
					C.DesiredValue,
					C.MeasuredValue, 
					C.IsActiveStatus,
					C.TotalCount,
					C.ROWNO
						INTO #AlarmTableOrder
			FROM #AlarmRowTable C 
			WHERE ROWNO BETWEEN @PageNo * @RecordsPerPage + 1 AND (@PageNo + 1) *  @RecordsPerPage  
			ORDER BY  @SortField + ' ' + @SortDirection

			SET @SQLStatement = 'SELECT * FROM #AlarmTableOrder ORDER BY ' + @SortField + ' ' + @SortDirection							   
	   		EXEC(@SQLStatement)

SET nocount OFF;
END


/*TCD.GetAlarmSummaryReport*/
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetAlarmSummaryReport]') AND type in (N'P', N'PC'))
DROP PROCEDURE [TCD].[GetAlarmSummaryReport]

GO
CREATE PROCEDURE [TCD].[GetAlarmSummaryReport] (
										  @Corporate Varchar(max) = '',
										  @Country Varchar(max) = '',
										  @Region Varchar(max) = '',
										  @EcolabAccountNumber Nvarchar(25) = '',
										  @Controller Varchar(max) = '',
										  @Machine Varchar(max) = '', 
										  @machineGroup Varchar(max) = '',
										  @Formula Varchar(max) = '',
										  @MachineType Varchar(20)= '',
										  @Alarm Varchar(max) = '',
										  @FromDate Datetime = '',
										  @ToDate Datetime = '',
										  @GroupId Varchar(max) = '',
										  @MachineInternalId Varchar(max) = '',
										  @SortColumnID INT = NULL,
										  @SortDirection Varchar(100) = '',
										  @UserId INT = NULL,
										  @PageNo	INT	 = NULL,
										  @RecordsPerPage INT = NULL
										  
									   )
AS   
BEGIN   
SET nocount ON;   
DECLARE @ReportGenerated INT = 6

SET @FromDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@FromDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@FromDate AS time)) AS DateTime))
SET @ToDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@ToDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@ToDate AS time)) AS DateTime))

/* Inserting the record into Report History */
SET @PageNo = @PageNo-1
INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)
SELECT @EcolabAccountNumber,UM.UserId,
	  UM.LoginName,
	  GETUTCDATE(),
	  @ReportGenerated,
	  CASE WHEN @ReportGenerated = 6
		THEN 'Generated Report : AlarmSummaryReport' END
	  FROM TCD.UserMaster UM
	    WHERE	UM.EcolabAccountNumber =	@EcolabAccountNumber AND UM.UserId = @UserId

/* Completed the record insertion into Report History */


DECLARE @Month INT = MONTH(GETDATE()),
	   @SortField Varchar(100) = '',
	   @SummationInMin Int = NULL,
	   @SQLStatement varchar(max)

    SELECT @SortField =  CASE WHEN @SortColumnID = 13 THEN 'AlarmDescription'
						WHEN @SortColumnID = 131 THEN 'NumberOfAlarms'
						WHEN @SortColumnID = 247 THEN 'Controller'
						WHEN @SortColumnID = 248 THEN 'AlarmCode'
						WHEN @SortColumnID = 0 THEN 'AlarmCode' END


DECLARE @ControllerTable TABLE(Controller Varchar(100))
INSERT INTO @ControllerTable(Controller) EXEC [TCD].[charlistToTable] @Controller,','

DECLARE @MachineTable TABLE(Machine Varchar(100))
INSERT INTO @MachineTable(Machine) EXEC [TCD].[charlistToTable] @Machine,','

DECLARE @GroupMachineTable TABLE(GroupId INT,MachineInternalId INT)  
INSERT INTO @GroupMachineTable(GroupId,MachineInternalId)  
SELECT GroupId,MachineInternalId FROM TCD.MachineSetup MS 
									INNER JOIN TCD.Washer WS ON MS.WasherId = WS.WasherId WHERE WS.PlantWasherNumber IN (SELECT Machine FROM @MachineTable);

DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))
INSERT INTO @WasherGroupTable(MachineGroup) EXEC [TCD].[charlistToTable] @machineGroup,','

DECLARE @FormulaTable TABLE(Formula Varchar(100))
INSERT INTO @FormulaTable(Formula) EXEC [TCD].[charlistToTable] @Formula,','

DECLARE @AlarmsTable TABLE(Alarm Varchar(100))
INSERT INTO @AlarmsTable(Alarm) EXEC [TCD].[charlistToTable] @Alarm,','

DECLARE @GroupTable TABLE(GroupId Varchar(100))
INSERT INTO @GroupTable(GroupId) EXEC [TCD].[CharlistToTable] @GroupId,','

DECLARE @MachineInternalTable TABLE(MachineInternalId Varchar(100))
INSERT INTO @MachineInternalTable(MachineInternalId) EXEC [TCD].[CharlistToTable] @MachineInternalId,','

DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))
INSERT INTO @MachineTypeTable EXEC [TCD].[CharlistToTable] @MachineType,','

	  DECLARE @AlarmTable TABLE(
							 AlarmCode INT,
							 AlarmDescription NVarchar(2000),
							 Controller Nvarchar(100),
							 StartDate Datetime,
							 EndDate Datetime,
							 SecDuration INT
    						  )

;WITH NonPonyWashers_CTE (WasherId)
AS
(
    SELECT WasherId
    FROM [TCD].MachineSetup MS
    WHERE MS.IsPony = 0    
)

INSERT INTO @AlarmTable (
							 AlarmCode ,
							 AlarmDescription ,
							 Controller ,
							 StartDate ,
							 EndDate ,
							 SecDuration 
    						  )
SELECT 
		  DISTINCT
			  AM.AlarmCode,
	   		  AM.Description,	
			  (SELECT cc.Name FROM [TCD].ConduitController CC  WHERE cc.ControllerId = AD.ControllerId) AS Controller,	 
			  AD.StartDate,
			  AD.EndDate,
			  DATEDIFF(SECOND,AD.StartDate,AD.EndDate)
	FROM [TCD].AlarmData AS AD
		   INNER JOIN [TCD].AlarmMaster AM ON AD.AlarmCode = AM.AlarmCode
		   LEFT JOIN NonPonyWashers_CTE MS ON MS.WasherId = AD.MachineId
		   LEFT JOIN [TCD].ControllerEquipmentSetup CES ON AD.Valve = CES.ControllerEquipmentId AND AD.ControllerId = CES.ControllerId
		   LEFT JOIN [TCD].ProductMaster PM ON CES.ProductId = PM.ProductId
		   LEFT JOIN [TCD].ProgramMaster PP ON AD.ProgramId = PP.ProgramId

		   WHERE 
				CASE @Controller   
				 WHEN '' THEN 'TRUE'         
				 ELSE                                                      
				  CASE WHEN AD.ControllerId IN (SELECT Controller FROM @ControllerTable) THEN 'TRUE' END                                                      
				END='TRUE' 

				AND       
				CASE @Machine   
				WHEN '' THEN 'TRUE'         
				ELSE                                                      
				CASE WHEN AD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
				END='TRUE' 
				AND       

				CASE @machineGroup   
	   			WHEN '' THEN 'TRUE'         
				ELSE                                                      
				CASE WHEN AD.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable) THEN 'TRUE' END                                    
				END='TRUE' 
				AND    

				CASE @Formula   
	     		WHEN '' THEN 'TRUE'         
				ELSE                                                      
				CASE WHEN AD.ProgramId IN (SELECT Formula FROM @FormulaTable) THEN 'TRUE' END                                                      
				END='TRUE' 
				AND       

				CASE @MachineType   
				WHEN '' THEN 'TRUE'         
				ELSE                                                      
				CASE WHEN AD.GroupId IN (SELECT WG.WasherGroupId FROM [TCD].WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable)) THEN 'TRUE' END                                                      
				END='TRUE' 

				AND       
				CASE @FromDate                                                                                
				WHEN '' THEN Case WHEN MONTH(AD.StartDate) = @Month Then  'true' END                                                                                
				ELSE CASE WHEN AD.StartDate >= @FromDate and AD.StartDate<= @ToDate THEN 'true'END                                                        
				END='true'

				AND
				CASE @Alarm   
				WHEN '' THEN 'TRUE'         
				ELSE                                                      
				CASE WHEN AD.AlarmCode IN (SELECT Alarm FROM @AlarmsTable) THEN 'TRUE' END                                                      
				END='TRUE' 

				AND
				CASE @GroupId 
	   			WHEN '' THEN 'TRUE' 
				ELSE        
				CASE WHEN (AD.GroupId IN (@GroupId) AND 
				AD.MachineInternalId  IN (@MachineInternalId)) THEN 'TRUE' END                                                   
				END='TRUE' 
				AND

				CASE @MachineInternalId 
                    WHEN '' THEN 'TRUE' 
				ELSE        
				CASE WHEN (AD.GroupId IN (@GroupId) AND 
				AD.MachineInternalId  IN (@MachineInternalId)) THEN 'TRUE' END                                                   
				END='TRUE'; 
				
				SELECT  
						AlarmCode,
						AlarmDescription,
						Controller,  
						COUNT(1) AS NumberOfAlarms,
					     (SELECT RIGHT('0' + CAST(SUM(SecDuration) / 3600 AS VARCHAR),2) + ':' +
						  RIGHT('0' + CAST((SUM(SecDuration) / 60) % 60 AS VARCHAR),2)  + ':' +
						  RIGHT('0' + CAST(SUM(SecDuration) % 60 AS VARCHAR),2)) AS AlarmDuration,
						--StartDate,  
						--EndDate,
						--SecDuration,
						COUNT(*) OVER() as TotalCount,
						ROW_NUMBER() OVER (ORDER BY  + @SortField + ' ' + @SortDirection) AS ROWNO
			INTO #AlarmRowTable
			FROM @AlarmTable
			GROUP BY AlarmCode,AlarmDescription,Controller

		  SELECT	
			         C.AlarmCode,
				    C.AlarmDescription,
				    C.NumberOfAlarms,
				    C.AlarmDuration,
				    C.Controller,
				    C.TotalCount,
				    C.ROWNO 
				    INTO #AlarmTableOrder
			FROM #AlarmRowTable C 
			    WHERE ROWNO BETWEEN @PageNo * @RecordsPerPage + 1 AND (@PageNo + 1) *  @RecordsPerPage  
			    --GROUP BY C.AlarmCode,C.alarmDescription,
					  -- C.Controller,C.TotalCount,C.ROWNO
			
			SET @SQLStatement 
					   ='SELECT * FROM #AlarmTableOrder ORDER BY ' + @SortField + ' ' + @SortDirection

	   		EXEC(@SQLStatement)

DROP TABLE #AlarmTableOrder
SET nocount OFF;

END
GO



IF EXISTS(SELECT
				  * FROM sys.views WHERE object_id = OBJECT_ID(N'[TCD].[Turntime]')
									 AND type = N'V')
	BEGIN
		DROP VIEW
				TCD.Turntime
	END
GO



   
   
CREATE VIEW [TCD].[Turntime]  
AS  
       
        
WITH CTE_TurnTime  
AS (  
SELECT  
     ROW_NUMBER() OVER(PARTITION BY BD.ECOLABWASHERID ORDER BY BD.STARTDATE) AS ROWNUMBER,  
     BD.ECOLABWASHERID,  
     BD.BATCHID,  
     STARTDATE,  
     ENDDATE,  
     BD.TARGETTURNTIME , 
     W.DEFAULTIDLETIME,
      BD.GROUPID,
    BD.MachineId
    FROM TCD.BATCHDATA AS BD WITH (NOLOCK)  
     INNER JOIN TCD.WASHER AS W           ON BD.MachineId = W.WasherID  
                                                      AND BD.EcolabWasherId = W.EcolabWasherId  
     INNER JOIN TCD.WASHERGROUP AS WG     ON WG.WASHERGROUPID=BD.GROUPID  
                                                            AND W.ECOLABACCOUNTNUMBER = WG.ECOLABACCOUNTNUMBER  
     INNER JOIN TCD.MACHINESETUP AS MS    ON MS.GroupId = WG.WasherGroupId  
                                                            AND ms.WasherId = W.WasherId  
                                                            AND w.EcoLabAccountNumber = ms.EcoalabAccountNumber  
    WHERE BD.PROGRAMMASTERID <> 0  
    AND WG.WASHERGROUPTYPEID=1  
)  
   
SELECT CurBatch.BATCHID  
, CurBatch.ECOLABWASHERID  
,CurBatch.ENDDATE  
, CurBatch.MachineId
,nextBatch.STARTDATE  
, CASE  
      WHEN (DATEDIFF(SECOND,CurBatch.ENDDATE,ISNULL(nextBatch.STARTDATE, GETDATE())) <= 0 or DATEDIFF(second,CurBatch.ENDDATE,ISNULL(nextBatch.STARTDATE, GETDATE())) > CurBatch. defaultidletime)  
      --OR DATEDIFF(hh,CurBatch.ENDDATE,ISNULL(nextBatch.STARTDATE, GETDATE())) > 2)  
      THEN CurBatch.defaultidletime  
      ELSE DATEDIFF(SECOND,CurBatch.ENDDATE, nextBatch.STARTDATE)  
      END AS ActualTurnTime  
FROM CTE_TurnTime CurBatch  
LEFT JOIN CTE_TurnTime nextBatch ON isnull(CurBatch.ECOLABWASHERID,0) = isnull(nextBatch.ECOLABWASHERID,0)
AND CurBatch.MachineId = nextBatch.MachineId
		  AND CurBatch.GROUPID = nextBatch.GROUPID  
AND CurBatch.ROWNUMBER + 1 = nextBatch.ROWNUMBER  

GO

/*KPI RedFlag DB Scripts Start*/

/*	
Purpose		: Create TCD.RedFlagCategory table for RedFlagCategory master data
*/
IF OBJECT_ID('[TCD].[RedFlagCategory]') is null  
BEGIN 
CREATE TABLE TCD.RedFlagCategory
	(
		RedFlagCategoryID INT IDENTITY(1,1) PRIMARY KEY,
		Name NVARCHAR(100) NOT NULL,
		LastUpdatedUserId INT,
		LastUpdatedTime DATETIME2
	)
end

/*	
Purpose		: Insert RedFlagCategory master data
*/
IF NOT EXISTS(SELECT 
			1 
		FROM TCD.RedFlagCategory 
		WHERE Name='Production Efficiency')
INSERT INTO TCD.RedFlagCategory	(
		Name,
		LastUpdatedUserId,
		LastUpdatedTime
	) 
	VALUES
	(
		'Production Efficiency',
		NULL,
		GETUTCDATE()
	)

/*	
Purpose		: Insert RedFlagCategory master data
*/
IF NOT EXISTS(SELECT 
			1 
		FROM TCD.RedFlagCategory 
		WHERE Name='Process Validation')
INSERT INTO TCD.RedFlagCategory	(
		Name,
		LastUpdatedUserId,
		LastUpdatedTime
	) 
	VALUES
	(
		'Process Validation',
		NULL,
		GETUTCDATE()
	)

/*	
Purpose		: Insert RedFlagCategory master data
*/
IF NOT EXISTS(SELECT 
			1 
		FROM TCD.RedFlagCategory 
		WHERE Name='Resources')
INSERT INTO TCD.RedFlagCategory	(
		Name,
		LastUpdatedUserId,
		LastUpdatedTime
	) 
	VALUES
	(
		'Resources',
		NULL,
		GETUTCDATE()
	)

/*	
Purpose		: Insert RedFlagCategory master data
*/
IF NOT EXISTS(SELECT 
			1 
		FROM TCD.RedFlagCategory 
		WHERE Name='Financials')
INSERT INTO TCD.RedFlagCategory	(
		Name,
		LastUpdatedUserId,
		LastUpdatedTime
	) 
	VALUES
	(
		'Financials',
		NULL,
		GETUTCDATE()
	)

/*	
Purpose		: Insert RedFlagCategory master data
*/
IF NOT EXISTS(SELECT 
			1 
		FROM TCD.RedFlagCategory 
		WHERE Name='Ecolab Internal')
INSERT INTO TCD.RedFlagCategory	(
		Name,
		LastUpdatedUserId,
		LastUpdatedTime
	) 
	VALUES
	(
		'Ecolab Internal',
		NULL,
		GETUTCDATE()
	)


/*	
Purpose		: Add Column RedFlagItemList in TCD.RedFlagItemList
*/

IF NOT EXISTS (SELECT
			*
		FROM sys.columns
		WHERE object_id = OBJECT_ID(N'[TCD].[RedFlagItemList]') 
			AND name = 'CategoryId')
BEGIN
	ALTER TABLE TCD.RedFlagItemList
			ADD CategoryId INT
end

/*	
Purpose		:	FK_RedFlagItemList_CategoryId_RedFlagCategory_RedFlagCategoryID
*/

IF EXISTS (SELECT 1
			FROM sys.objects
			WHERE parent_object_id = (OBJECT_ID('TCD.RedFlagItemList')) 
			AND type IN ('C','F', 'PK')
			and name ='FK_RedFlagItemList_CategoryId_RedFlagCategory_RedFlagCategoryID' )
BEGIN
	ALTER TABLE TCD.RedFlagItemList	DROP CONSTRAINT FK_RedFlagItemList_CategoryId_RedFlagCategory_RedFlagCategoryID
	
	ALTER TABLE TCD.RedFlagItemList	ADD CONSTRAINT FK_RedFlagItemList_CategoryId_RedFlagCategory_RedFlagCategoryID FOREIGN KEY (CategoryId) REFERENCES TCD.RedFlagCategory(RedFlagCategoryID)
END
ELSE
BEGIN		
	ALTER TABLE TCD.RedFlagItemList	ADD CONSTRAINT FK_RedFlagItemList_CategoryId_RedFlagCategory_RedFlagCategoryID FOREIGN KEY (CategoryId) REFERENCES TCD.RedFlagCategory(RedFlagCategoryID)
END

GO


/*	
Purpose		: Update RedFlagItemList master data
*/
UPDATE TCD.RedFlagItemList 
	SET 
		CategoryId=1 
	WHERE ItemName='Overall Efficiency'

/*	
Purpose		: Update RedFlagItemList master data
*/
UPDATE TCD.RedFlagItemList 
	SET 
		CategoryId=1 
	WHERE ItemName='Runtime Efficiency'

/*	
Purpose		: Update RedFlagItemList master data
*/
UPDATE TCD.RedFlagItemList 
	SET 
		CategoryId=1 
	WHERE ItemName='Turn Time Efficiency'

/*	
Purpose		: Update RedFlagItemList master data
*/
UPDATE TCD.RedFlagItemList 
	SET 
		CategoryId=1 
	WHERE ItemName='Transfer/Hour'

/*	
Purpose		: Update RedFlagItemList master data
*/
UPDATE TCD.RedFlagItemList 
	SET 
		CategoryId=2 
	WHERE ItemName='Rewash Rate'

/*	
Purpose		: Update RedFlagItemList master data
*/
UPDATE TCD.RedFlagItemList 
	SET 
		CategoryId=3 
	WHERE ItemName='Water usage'

/*	
Purpose		: Update RedFlagItemList master data
*/
UPDATE TCD.RedFlagItemList 
	SET	
		CategoryId=3 
	WHERE ItemName='Energy consumption'

/*	
Purpose		: Update RedFlagItemList master data
*/
UPDATE TCD.RedFlagItemList 
	SET 
		CategoryId=3 
	WHERE ItemName='Gas consumption'

/*	
Purpose		: Update RedFlagItemList master data
*/
UPDATE TCD.RedFlagItemList 
	SET 
		CategoryId=3 
	WHERE ItemName='Chemical Consumption'

/*	
Purpose		: Update RedFlagItemList master data
*/
UPDATE TCD.RedFlagItemList 
	SET 
		CategoryId=1 
	WHERE ItemName='Drying Efficiency'


/*	
Purpose		: Insert RedFlagItemList master data
*/
IF NOT EXISTS(SELECT 
			1 
		FROM TCD.RedFlagItemList 
		WHERE ItemName='Production vs Target')
INSERT INTO TCD.RedFlagItemList (
		ItemName,
		UOMNA,
		UOMEurope,
		CategoryId
	) 
	VALUES
	(
		'Production vs Target',
		'%',
		'%',
		1
	)

/*	
Purpose		: Insert RedFlagItemList master data
*/
IF NOT EXISTS(SELECT 
			1 
		FROM TCD.RedFlagItemList 
		WHERE ItemName='Lost Capacity')
INSERT INTO TCD.RedFlagItemList	(
		ItemName,
		UOMNA,
		UOMEurope,
		CategoryId
	) 
	VALUES
	(
		'Lost Capacity',
		'lbs',
		'kg',
		1
	)

/*	
Purpose		: Insert RedFlagItemList master data
*/
IF NOT EXISTS(SELECT 
			1 
		FROM TCD.RedFlagItemList 
		WHERE ItemName='Production')
INSERT INTO TCD.RedFlagItemList	(
		ItemName,
		UOMNA,
		UOMEurope,
		CategoryId
	) 
	VALUES
	(
		'Production',
		'lbs',
		'kg/H',
		1
	)

/*	
Purpose		: Insert RedFlagItemList master data
*/
IF NOT EXISTS(SELECT 
			1 
		FROM TCD.RedFlagItemList 
		WHERE ItemName='Production Mix')
INSERT INTO TCD.RedFlagItemList	(
		ItemName,
		UOMNA,
		UOMEurope,
		CategoryId
	) 
	VALUES
	(
		'Production Mix',
		'%',
		'%',
		1
	)

/*	
Purpose		: Insert RedFlagItemList master data
*/
IF NOT EXISTS(SELECT 
			1 
		FROM TCD.RedFlagItemList 
		WHERE ItemName='Number of Loads')
INSERT INTO TCD.RedFlagItemList	(
		ItemName,
		UOMNA,
		UOMEurope,
		CategoryId
	) 
	VALUES
	(
		'Number of Loads',
		'Number',
		'Number',
		1
	)

/*	
Purpose		: Insert RedFlagItemList master data
*/
IF NOT EXISTS(SELECT 
			1 
		FROM TCD.RedFlagItemList 
		WHERE ItemName='Load Efficiency')
INSERT INTO TCD.RedFlagItemList	(
		ItemName,
		UOMNA,
		UOMEurope,
		CategoryId
	) 
	VALUES
	(
		'Load Efficiency',
		'%',
		'%',
		1
	)

/*	
Purpose		: Insert RedFlagItemList master data
*/
IF NOT EXISTS(SELECT 
			1 
		FROM TCD.RedFlagItemList 
		WHERE ItemName='Average Run Time')
INSERT INTO TCD.RedFlagItemList	(
		ItemName,
		UOMNA,
		UOMEurope,
		CategoryId
	) 
	VALUES
	(
		'Average Run Time',
		'Time',
		'Time',
		1
	)

/*	
Purpose		: Insert RedFlagItemList master data
*/
IF NOT EXISTS(SELECT 
			1 
		FROM TCD.RedFlagItemList 
		WHERE ItemName='Lost Loads due to Turn Time')
INSERT INTO TCD.RedFlagItemList	(
		ItemName,
		UOMNA,
		UOMEurope,
		CategoryId
	) 
	VALUES
	(
		'Lost Loads due to Turn Time',
		'Number',
		'Number',
		1
	)

/*	
Purpose		: Insert RedFlagItemList master data
*/
IF NOT EXISTS(SELECT 
			1 
		FROM TCD.RedFlagItemList 
		WHERE ItemName='Average Turn Time')
INSERT INTO TCD.RedFlagItemList	(
		ItemName,
		UOMNA,
		UOMEurope,
		CategoryId
	) 
	VALUES
	(
		'Average Turn Time',
		'Time',
		'Time',
		1
	)

/*	
Purpose		: Insert RedFlagItemList master data
*/
IF NOT EXISTS(SELECT 
			1 
		FROM TCD.RedFlagItemList 
		WHERE ItemName='Number Rejected Batches')
INSERT INTO TCD.RedFlagItemList	(
		ItemName,
		UOMNA,
		UOMEurope,
		CategoryId
	) 
	VALUES
	(
		'Number Rejected Batches',
		'Number',
		'Number',
		2
	)

/*	
Purpose		: Insert RedFlagItemList master data
*/
IF NOT EXISTS(SELECT 
			1 
		FROM TCD.RedFlagItemList 
		WHERE ItemName='Number Rejecte Batches')
INSERT INTO TCD.RedFlagItemList	(
		ItemName,
		UOMNA,
		UOMEurope,
		CategoryId
	) 
	VALUES
	(
		'Number Rejecte Batches',
		'%',
		'%',
		2
	)

/*	
Purpose		: Insert RedFlagItemList master data
*/
IF NOT EXISTS(SELECT 
			1 
		FROM TCD.RedFlagItemList 
		WHERE ItemName='Water Cost')
INSERT INTO TCD.RedFlagItemList	(
		ItemName,
		UOMNA,
		UOMEurope,
		CategoryId
	) 
	VALUES
	(
		'Water Cost',
		'$/CwT',
		'$/kg',
		4
	)

/*	
Purpose		: Insert RedFlagItemList master data
*/
IF NOT EXISTS(SELECT 
			1 
		FROM TCD.RedFlagItemList 
		WHERE ItemName='Energy Cost')
INSERT INTO TCD.RedFlagItemList	(
		ItemName,
		UOMNA,
		UOMEurope,
		CategoryId
	) 
	VALUES
	(
		'Energy Cost',
		'$/CwT',
		'$/kg',
		4
	)

/*	
Purpose		: Insert RedFlagItemList master data
*/
IF NOT EXISTS(SELECT 
			1 
		FROM TCD.RedFlagItemList 
		WHERE ItemName='Gas Cost')
INSERT INTO TCD.RedFlagItemList	(
		ItemName,
		UOMNA,
		UOMEurope,
		CategoryId
	) 
	VALUES
	(
		'Gas Cost',
		'$/CwT',
		'$/kg',
		4
	)

/*	
Purpose		: Insert RedFlagItemList master data
*/
IF NOT EXISTS(SELECT 
			1 
		FROM TCD.RedFlagItemList 
		WHERE ItemName='Chemical Consumption deviation')
INSERT INTO TCD.RedFlagItemList	(
		ItemName,
		UOMNA,
		UOMEurope,
		CategoryId
	) 
	VALUES
	(
		'Chemical Consumption deviation',
		'%',
		'%',
		3
	)

/*	
Purpose		: Insert RedFlagItemList master data
*/
IF NOT EXISTS(SELECT 
			1 
		FROM TCD.RedFlagItemList 
		WHERE ItemName='Chemical Cost')
INSERT INTO TCD.RedFlagItemList	(
		ItemName,
		UOMNA,
		UOMEurope,
		CategoryId
	) 
	VALUES
	(
		'Chemical Cost',
		'$/CwT',
		'$/kg',
		4
	)

/*	
Purpose		: Insert RedFlagItemList master data
*/
IF NOT EXISTS(SELECT 
			1 
		FROM TCD.RedFlagItemList 
		WHERE ItemName='Chemicals C&I')
INSERT INTO TCD.RedFlagItemList	(
		ItemName,
		UOMNA,
		UOMEurope,
		CategoryId
	) 
	VALUES
	(
		'Chemicals C&I',
		'Number of days',
		'Number of days',
		3
	)

/*	
Purpose		: Insert RedFlagItemList master data
*/
IF NOT EXISTS(SELECT 
			1 
		FROM TCD.RedFlagItemList 
		WHERE ItemName='Total Cost')
INSERT INTO TCD.RedFlagItemList	(
		ItemName,
		UOMNA,
		UOMEurope,
		CategoryId
	) 
	VALUES
	(
		'Total Cost',
		'$/CwT',
		'$/kg',
		4
	)

/*	
Purpose		: Insert RedFlagItemList master data
*/
IF NOT EXISTS(SELECT 
			1 
		FROM TCD.RedFlagItemList 
		WHERE ItemName='FF Cost Excess')
INSERT INTO TCD.RedFlagItemList	(
		ItemName,
		UOMNA,
		UOMEurope,
		CategoryId
	) 
	VALUES
	(
		'FF Cost Excess',
		'$/CwT',
		'$/kg',
		5
	)

/*	
Purpose		: Insert RedFlagItemList master data
*/
IF NOT EXISTS(SELECT 
			1 
		FROM TCD.RedFlagItemList 
		WHERE ItemName='pH')
INSERT INTO TCD.RedFlagItemList	(
		ItemName,
		UOMNA,
		UOMEurope,
		CategoryId
	) 
	VALUES
	(
		'pH',
		'pH',
		'pH',
		2
	)

/*	
Purpose		: Insert RedFlagItemList master data
*/
IF NOT EXISTS(SELECT 
			1 
		FROM TCD.RedFlagItemList 
		WHERE ItemName='Conductivity')
INSERT INTO TCD.RedFlagItemList	(
		ItemName,
		UOMNA,
		UOMEurope,
		CategoryId
	) 
	VALUES
	(
		'Conductivity',
		'mS',
		'mS',
		2
	)

/*	
Purpose		: Insert RedFlagItemList master data
*/
IF NOT EXISTS(SELECT 
			1 
		FROM TCD.RedFlagItemList 
		WHERE ItemName='Redox')
INSERT INTO TCD.RedFlagItemList	(
		ItemName,
		UOMNA,
		UOMEurope,
		CategoryId
	) 
	VALUES
	(
		'Redox',
		'mV',
		'mV',
		2
	)

/*	
Purpose		: Insert RedFlagItemList master data
*/
IF NOT EXISTS(SELECT 
			1 
		FROM TCD.RedFlagItemList 
		WHERE ItemName='Temperature')
INSERT INTO TCD.RedFlagItemList	(
		ItemName,
		UOMNA,
		UOMEurope,
		CategoryId
	) 
	VALUES
	(
		'Temperature',
		'F',
		'C',
		1
	)

	

/*	
Purpose		: Add Column RedFlagCategoryId in TCD.RedFlag
*/

IF NOT EXISTS (SELECT
			*
		FROM sys.columns
		WHERE object_id = OBJECT_ID(N'[TCD].[RedFlag]') 
			AND name = 'RedFlagCategoryId')
BEGIN
	ALTER TABLE TCD.RedFlag
			ADD RedFlagCategoryId INT
end

/*	
Purpose		:	FK_RedFlag_RedFlagCategoryId_RedFlagCategory_RedFlagCategoryId
*/

IF EXISTS (SELECT 1
			FROM sys.objects
			WHERE parent_object_id = (OBJECT_ID('TCD.RedFlag')) 
			AND type IN ('C','F', 'PK')
			and name ='FK_RedFlag_RedFlagCategoryId_RedFlagCategory_RedFlagCategoryId' )
BEGIN
	ALTER TABLE TCD.RedFlag	DROP CONSTRAINT FK_RedFlag_RedFlagCategoryId_RedFlagCategory_RedFlagCategoryId
	
	ALTER TABLE TCD.RedFlag	ADD CONSTRAINT FK_RedFlag_RedFlagCategoryId_RedFlagCategory_RedFlagCategoryId FOREIGN KEY (RedFlagCategoryId) REFERENCES TCD.RedFlagCategory(RedFlagCategoryID)
END
ELSE
BEGIN		
	ALTER TABLE TCD.RedFlag	ADD CONSTRAINT FK_RedFlag_RedFlagCategoryId_RedFlagCategory_RedFlagCategoryId FOREIGN KEY (RedFlagCategoryId) REFERENCES TCD.RedFlagCategory(RedFlagCategoryID)
END

GO

/*	
Purpose		: Add Column FormulaId in TCD.RedFlag
*/

IF NOT EXISTS (SELECT
			*
		FROM sys.columns
		WHERE object_id = OBJECT_ID(N'[TCD].[RedFlag]') 
			AND name = 'FormulaId')
BEGIN
	ALTER TABLE TCD.RedFlag
			ADD FormulaId INT
end

/*	
Purpose		:	FK_RedFlag_FormulaId_ProgramMaster_ProgramId
*/

IF EXISTS (SELECT 1
			FROM sys.objects
			WHERE parent_object_id = (OBJECT_ID('TCD.RedFlag')) 
			AND type IN ('C','F', 'PK')
			and name ='FK_RedFlag_FormulaId_ProgramMaster_ProgramId' )
BEGIN
	ALTER TABLE TCD.RedFlag	DROP CONSTRAINT FK_RedFlag_FormulaId_ProgramMaster_ProgramId
	
	ALTER TABLE TCD.RedFlag	ADD CONSTRAINT FK_RedFlag_FormulaId_ProgramMaster_ProgramId FOREIGN KEY (FormulaId) REFERENCES TCD.ProgramMaster(ProgramId)
END
ELSE
BEGIN		
	ALTER TABLE TCD.RedFlag	ADD CONSTRAINT FK_RedFlag_FormulaId_ProgramMaster_ProgramId FOREIGN KEY (FormulaId) REFERENCES TCD.ProgramMaster(ProgramId)
END

GO

/*	
Purpose		: Add Column ProductId in TCD.RedFlag
*/

IF NOT EXISTS (SELECT
			*
		FROM sys.columns
		WHERE object_id = OBJECT_ID(N'[TCD].[RedFlag]') 
			AND name = 'ProductId')
BEGIN
	ALTER TABLE TCD.RedFlag
			ADD ProductId INT
end

/*	
Purpose		:	FK_RedFlag_ProductId_ProductMaster_ProductId
*/

IF EXISTS (SELECT 1
			FROM sys.objects
			WHERE parent_object_id = (OBJECT_ID('TCD.RedFlag')) 
			AND type IN ('C','F', 'PK')
			and name ='FK_RedFlag_ProductId_ProductMaster_ProductId' )
BEGIN
	ALTER TABLE TCD.RedFlag	DROP CONSTRAINT FK_RedFlag_ProductId_ProductMaster_ProductId
	
	ALTER TABLE TCD.RedFlag	ADD CONSTRAINT FK_RedFlag_ProductId_ProductMaster_ProductId FOREIGN KEY (ProductId) REFERENCES TCD.ProductMaster(ProductId)
END
ELSE
BEGIN		
	ALTER TABLE TCD.RedFlag	ADD CONSTRAINT FK_RedFlag_ProductId_ProductMaster_ProductId FOREIGN KEY (ProductId) REFERENCES TCD.ProductMaster(ProductId)
END

GO



/*	
Purpose		: Add Column MeterId in TCD.RedFlag
*/

IF NOT EXISTS (SELECT
			*
		FROM sys.columns
		WHERE object_id = OBJECT_ID(N'[TCD].[RedFlag]') 
			AND name = 'MeterId')
BEGIN
	ALTER TABLE TCD.RedFlag
			ADD MeterId INT
end

/*	
Purpose		:	FK_RedFlag_MeterId_Meter_MeterId
*/

IF EXISTS (SELECT 1
			FROM sys.objects
			WHERE parent_object_id = (OBJECT_ID('TCD.RedFlag')) 
			AND type IN ('C','F', 'PK')
			and name ='FK_RedFlag_MeterId_Meter_MeterId' )
BEGIN
	ALTER TABLE TCD.RedFlag	DROP CONSTRAINT FK_RedFlag_MeterId_Meter_MeterId
	
	ALTER TABLE TCD.RedFlag	ADD CONSTRAINT FK_RedFlag_MeterId_Meter_MeterId FOREIGN KEY (MeterId) REFERENCES TCD.Meter(MeterId)
END
ELSE
BEGIN		
	ALTER TABLE TCD.RedFlag	ADD CONSTRAINT FK_RedFlag_MeterId_Meter_MeterId FOREIGN KEY (MeterId) REFERENCES TCD.Meter(MeterId)
END

GO




/*	
Purpose		:	Column SensorId
*/

IF NOT EXISTS (SELECT
			*
		FROM sys.columns
		WHERE object_id = OBJECT_ID(N'[TCD].[RedFlag]') 
			AND name = 'SensorId')
BEGIN
	ALTER TABLE TCD.RedFlag
			ADD SensorId INT
end


/*	
Purpose		:	Column PlantId
*/

IF NOT EXISTS (SELECT
			*
		FROM sys.columns
		WHERE object_id = OBJECT_ID(N'[TCD].[RedFlag]') 
			AND name = 'PlantId')
BEGIN
	ALTER TABLE TCD.RedFlag
			ADD PlantId INT
end

/*	
Purpose		:	PK_Sensor
*/

IF NOT EXISTS (SELECT 1
			FROM sys.objects
			WHERE parent_object_id = (OBJECT_ID('TCD.Sensor')) 
			AND type IN ('C','F', 'PK')
			and name ='PK_Sensor' )
BEGIN	
	ALTER TABLE TCd.Sensor ADD CONSTRAINT PK_Sensor PRIMARY KEY (SensorId, EcolabAccountNumber)
END

GO

/*	
Purpose		:	EcolabAccountNumber Data type lenghth increased to 1000
*/

ALTER TABLE TCD.RedFlag
	ALTER COLUMN EcolabAccountNumber NVARCHAR(25)

/*	
Purpose		:	FK_RedFlag_SensorId_EAN_Sensor_SensorId_EAN
*/

IF EXISTS (SELECT 1
			FROM sys.objects
			WHERE parent_object_id = (OBJECT_ID('TCD.RedFlag')) 
			AND type IN ('C','F', 'PK')
			and name ='FK_RedFlag_SensorId_EAN_Sensor_SensorId_EAN' )
BEGIN
	ALTER TABLE TCD.RedFlag	DROP CONSTRAINT FK_RedFlag_SensorId_EAN_Sensor_SensorId_EAN
	
	ALTER TABLE TCD.RedFlag	ADD CONSTRAINT FK_RedFlag_SensorId_EAN_Sensor_SensorId_EAN FOREIGN KEY (SensorId, EcolabAccountNumber) REFERENCES TCD.Sensor(SensorId,EcolabAccountNumber)
END
ELSE
BEGIN		
	ALTER TABLE TCD.RedFlag	ADD CONSTRAINT FK_RedFlag_SensorId_EAN_Sensor_SensorId_EAN FOREIGN KEY (SensorId, EcolabAccountNumber) REFERENCES TCD.Sensor(SensorId,EcolabAccountNumber)
END

GO




/*	
Purpose		:	SP To save redflag details
*/
IF  EXISTS (SELECT
			*
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'[TCD].[SaveRedFlagDetails]') 
			AND type IN (N'P', N'PC')) 
BEGIN 
	DROP PROCEDURE [TCD].[SaveRedFlagDetails] 
END 
GO 

CREATE PROCEDURE [TCD].[SaveRedFlagDetails] (
@Id INT
,@ItemID int
,@MinRange Decimal(18,3)
,@MaxRange Decimal(18,3)
,@LocationID int
,@MachineCompartmentId int
,@EcolabAccountNumber nvarchar(25)
,@UserID INT = NULL
,@Scope varchar(100) OUTPUT
,@OutputRedFlagId INT =	NULL	OUTPUT
,@LastModifiedTimestampAtCentral	DATETIME	=	NULL
,@OutputLastModifiedTimestampAtLocal	DATETIME	=	NULL	OUTPUT
,@CategoryId int
,@FormulaId int
,@ProductId int
,@MeterId int
,@SensorId int
)
AS

BEGIN
SET NOCOUNT ON
IF(@ItemID <> 0)
BEGIN
DECLARE
@OutPut							VARCHAR(100)	=			''
,	@ReturnValue					INT				=			0
--,	@ErrorId						INT				=			0					--SQLEnlight SA0004
--,	@ErrorMessage					NVARCHAR(4000)	=			N''					--SQLEnlight SA0004
--,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()		--SQLEnlight SA0004

DECLARE
@OutputList						AS	TABLE		(
RedFlagId						INT
,	LastModifiedTimestamp			DATETIME
)
DECLARE @PlantId INT;  
SET @PlantId = (SELECT 
			PlantId 
		FROM TCD.Plant 
		WHERE EcolabAccountNumber=@EcolabAccountNumber)   
DECLARE @MachineGroupId INT = (SELECT MG.Id
FROM TCD.MachineGroupType MGT
INNER JOIN
TCD.MachineGroup MG ON MGT.Id = MG.GroupTypeId
WHERE MGT.Id = 1
AND MG.Is_Deleted = 0);
SET		@Scope									=			ISNULL(@Scope, NULL)									--SQLEnlight SA0121
SET		@LastModifiedTimestampAtCentral			=			ISNULL(@LastModifiedTimestampAtCentral, NULL)			--SQLEnlight SA0121

IF(@LocationID > 1 AND @MachineCompartmentId IS NULL AND NOT EXISTS (SELECT * FROM tcd.MachineGroup MG
LEFT JOIN TCD.Meter M ON MG.Id = CASE M.IsPlant WHEN 'TRUE' THEN COALESCE(  M.GroupId ,@MachineGroupId) ELSE M.GroupId END
LEFT JOIN TCD.Sensor S ON MG.Id = CASE S.IsPlant WHEN 'TRUE' THEN COALESCE(  S.GroupId ,@MachineGroupId) ELSE S.GroupId END
WHERE ((S.SensorId	IS NOT NULL
AND S.Is_deleted = 0
AND S.MachineCompartment	IS NULL)
OR (M.MeterId	IS NOT NULL
AND M.Is_deleted = 0
AND M.MachineCompartment	IS NULL))
AND MG.Id = @LocationID))
BEGIN
SET @Scope = '301'
END
ELSE
BEGIN
IF NOT EXISTS (SELECT 1
FROM   [TCD].RedFlag
WHERE  Item = @ItemID AND Location = @LocationID AND Is_Deleted=0)
BEGIN
INSERT INTO [TCD].RedFlag(Item,MaximumRange,MinimumRange,Location,EcolabAccountNumber,LastModifiedByUserId,RedFlagCategoryId,FormulaId,ProductId,MeterId,SensorId,PlantId)
OUTPUT
inserted.ID						AS			Id
,	inserted.LastModifiedTime		AS			LastModifiedTimestamp
INTO
@OutputList	(
RedFlagId
,	LastModifiedTimestamp
)
VALUES(@ItemID,@MaxRange,@MinRange,@LocationID,@EcolabAccountNumber,@UserID,@CategoryId,@FormulaId,@ProductId,@MeterId,@SensorId,@PlantId)

DECLARE @NewId int = SCOPE_IDENTITY()

INSERT INTO [TCD].RedFlagMappingData(MappingId,MachineId,EcolabAccountNumber,LastModifiedByUserId)
VALUES(@NewId,@MachineCompartmentId,@EcolabAccountNumber,@UserID)

SET @OutPut = @NewId
SET @Scope = @OutPut SELECT @Scope

END

ELSE
BEGIN
--DECLARE @Id INT
--SELECT @Id = ID FROM RedFlag R WHERE R.Location = @LocationID AND Item = @ItemID
IF(@Id = -1)
BEGIN
IF NOT EXISTS(SELECT 1 FROM [TCD].RedFlagMappingData RM INNER JOIN [TCD].RedFlag RF ON RM.MappingId = RF.Id
WHERE ISNULL(RM.MachineId,'') = ISNULL(@MachineCompartmentId,'') AND RF.Item = @ItemID AND RF.Location = @LocationID AND RF.Is_Deleted = 0 AND RM.Is_Deleted = 0 )
BEGIN
INSERT INTO [TCD].RedFlag(Item,MaximumRange,MinimumRange,Location,EcolabAccountNumber,LastModifiedByUserId,RedFlagCategoryId,FormulaId,ProductId,MeterId,SensorId,PlantId)
OUTPUT
inserted.ID						AS			Id
,	inserted.LastModifiedTime		AS			LastModifiedTimestamp
INTO
@OutputList	(
RedFlagId
,	LastModifiedTimestamp
)
VALUES(@ItemID,@MaxRange,@MinRange,@LocationID,@EcolabAccountNumber,@UserID,@CategoryId,@FormulaId,@ProductId,@MeterId,@SensorId,@PlantId)

DECLARE @NewGroupId int = SCOPE_IDENTITY()

INSERT INTO [TCD].RedFlagMappingData(MappingId,MachineId,EcolabAccountNumber,LastModifiedByUserId)
VALUES(@NewGroupId,@MachineCompartmentId,@EcolabAccountNumber,@UserID)
SET @OutPut = @NewGroupId
SET @Scope = @OutPut SELECT @Scope
END
ELSE
BEGIN
SET @OutPut = '401'
SET @Scope = @OutPut SELECT @Scope
END

END
ELSE
IF NOT EXISTS(SELECT MachineId FROM [TCD].RedFlagMappingData WHERE MappingId = @Id AND MachineId = @MachineCompartmentId AND Is_Deleted = 0)
BEGIN
INSERT INTO [TCD].RedFlagMappingData(MappingId,MachineId,EcolabAccountNumber,LastModifiedByUserId)
VALUES(@Id,@MachineCompartmentId,@EcolabAccountNumber,@UserID)
SET @OutPut = @Id
SET @Scope = @OutPut SELECT @Scope
END
ELSE
BEGIN
SET @OutPut = '401'
SET @Scope = @OutPut SELECT @Scope
END
END
END
SELECT	TOP 1
@OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp
,	@OutputRedFlagId				=	O.RedFlagId
FROM	@OutputList	O
END

SET NOCOUNT OFF
END
Go
/*KPI RedFlag DB Scripts End*/


GO
IF  EXISTS (SELECT 
			* 
		FROM sys.objects 
		WHERE object_id = OBJECT_ID(N'[TCD].[GetRedFlagDetails]') 
		AND type IN (N'P', N'PC'))
DROP PROCEDURE [TCD].[GetRedFlagDetails]
GO
/*
==========================================================================================
Purpose:  Fetching the Plant Red Flag Details

Author:  PREMCHAND YELAVARTHI

--------------------------------------------------------------
Aug-13-2014 ENT: Initial version.
==========================================================================================

[dbo].[usp_GetRedFlagDetails] NULL,1
*/
CREATE PROCEDURE [TCD].[GetRedFlagDetails]
(
		@Id INT = NULL
	,	@EcolabAccountNumber nvarchar(25) 
)
AS
BEGIN
SET NOCOUNT ON;

DECLARE @PlantId INT;  
SET @PlantId = (SELECT 
			PlantId 
		FROM TCD.Plant 
		WHERE EcolabAccountNumber=@EcolabAccountNumber)   
SELECT
		PR.Id
	,	ItemID = PR.Item
	,	ItemName = (SELECT RF.ItemName FROM [TCD].RedFlagItemList RF WHERE RF.Id = PR.Item)
	,	PR.MinimumRange
	,	PR.MaximumRange
	,	CASE (select RegionId from [TCD].Plant WHERE PlantId =@PlantId) WHEN 1 THEN IL.UOMNA WHEN 2 THEN IL.UOMEurope END AS UOM
	,	LocationID = PR.Location
	,	LocationName  = (SELECT GT.GroupDescription FROM [TCD].MachineGroup GT WHERE GT.Id = PR.Location AND GT.Is_Deleted = 0)
	,	PR.EcolabAccountNumber
	,	(SELECT STUFF((select DISTINCT ','+ CAST(IsNull(MachineId,-1) AS VARCHAR(1000)) from [TCD].RedFlagMappingData MD WHERE MD.MappingID = PR.ID AND MD.Is_Deleted = 0 FOR XML PATH('')  ) ,1,1,'')) as MachineID
	,	(SELECT LTRIM(ISNULL(STUFF((select DISTINCT ', '+
			(SELECT
				CASE WHEN( SELECT DISTINCT Istunnel FROM [TCD].machinesetup S WHERE S.groupId = PR.Location)= 1 THEN
				CASE WHEN (SELECT RD.MachineId FROM [TCD].RedFlag MM INNER JOIN [TCD].RedFlagMappingData RD ON MM.Id = RD.MappingId WHERE RD.MachineId = MD.MachineId AND RD.MachineId = 0 AND RD.Is_Deleted = 0) = 0 THEN 'Press'
				ELSE
				'Compartment' + CAST( MD.MachineId -1 AS varchar( 100)) END
				WHEN( SELECT DISTINCT Istunnel FROM [TCD].machinesetup S WHERE S.groupId = PR.Location)= 0 THEN (SELECT TOP(1) CAST(WS.PlantWasherNumber AS nvarchar)+':'+MS.MachineName FROM TCD.MachineSetup MS INNER JOIN TCD.Washer WS ON MS.WasherId = WS.WasherId WHERE MS.GroupId = PR.Location AND MS.WasherId = MD.MachineId)
				WHEN (SELECT DISTINCT GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.Id = PR.Location ) = 3 THEN
				(SELECT Description FROM [TCD].Dryers D WHERE D.DryerGroupId = PR.Location AND D.DryerNo =  MD.MachineId AND D.Is_deleted = 0)
				WHEN (SELECT DISTINCT GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.Id = PR.Location ) = 4 THEN
				(SELECT Name FROM [TCD].Finnishers F WHERE F.FinnisherGroupId = PR.Location AND F.FinnisherNo =  MD.MachineId AND F.Is_deleted = 0)
			END)
		FROM 
		[TCD].RedFlagMappingData MD  
	WHERE 
	MD.MappingID = PR.ID 
	AND 
	MD.Is_Deleted = 0
		FOR XML PATH('')  ) ,1,1,''),'ALL'))) as MachineName
 , PR.RedFlagCategoryId AS CategoryId  
, PR.FormulaId AS FormulaId  
, PM.Name AS FormulaName     
, PR.ProductId   
, PRM.Name AS ProductName  
, PR.MeterId  
, ME.Description AS MeterName  
,PR.LastModifiedTime
,PR.LastSyncTime
,PR.Is_Deleted
FROM  
[TCD].RedFlag PR
INNER JOIN [TCD].RedFlagItemList IL ON PR.Item = IL.Id 
LEFT JOIN tcd.ProgramMaster AS PM ON PM.ProgramId = PR.FormulaId    
LEFT JOIN TCD.ProductMaster AS PRM ON PRM.ProductId = PR.ProductId   
LEFT JOIN TCD.Meter AS ME ON ME.MeterId = PR.MeterId   
LEFT JOIN TCD.RedFlagCategory AS RFC ON RFC.RedFlagCategoryId = PR.RedFlagCategoryId   
INNER JOIN [TCD].MachineGroup GT ON PR.Location = GT.Id  
WHERE 
PR.PlantId = @PlantId
AND 
PR.Is_Deleted=0 
AND GT.Is_Deleted = 0
AND 
CASE ISNULL(@Id,'') WHEN '' THEN 'TRUE' ELSE CASE WHEN PR.Id = @Id THEN 'TRUE' END END = 'TRUE'
SET NOCOUNT OFF;
END

/*
SELECT * FROM RedFlagMappingData

SELECT * FROM RedFlag

SELECT * FROM RedFlagItemList

SELECT * FROM GroupType

SELECT * FROM Dryers WHERE Is_deleted = 0
*/

GO
IF  EXISTS (SELECT 
			* 
		FROM sys.objects 
		WHERE object_id = OBJECT_ID(N'[TCD].[UpdateRedFlagDetails]') 
		AND type IN (N'P', N'PC'))
DROP PROCEDURE [TCD].[UpdateRedFlagDetails]

GO
CREATE PROCEDURE [TCD].[UpdateRedFlagDetails] (      
@Id INT ,      
@ItemID int,      
@MinRange Decimal(18,3) ,      
@MaxRange Decimal(18,3),      
@LocationID int,      
@MachineCompartmentId Int,      
@IsSelected Bit,      
@IsDirty Bit,      
@EcolabAccountNumber nvarchar(25),      
@UserID INT = NULL,      
@Scope varchar(100) OUTPUT,      
@OutputRedFlagId INT = NULL OUTPUT,      
@LastModifiedTimestampAtCentral DATETIME = NULL,      
@OutputLastModifiedTimestampAtLocal DATETIME = NULL OUTPUT      
,@CategoryId int      
,@FormulaId int      
,@ProductId int      
,@MeterId int      
,@SensorId int      
)      
AS       
      
BEGIN      
SET NOCOUNT ON      
      
DECLARE       
  @OutPut       VARCHAR(100) =   ''      
 , @Min       Decimal(18,3) =   NULL      
 , @Max       Decimal(18,3) =   NULL      
 , @ExistingLoc     INT    =   NULL      
 , @ExistingItem     INT    =   NULL      
 , @ReturnValue     INT    =   0      
 , @ErrorId      INT    =   0      
 , @ErrorMessage     NVARCHAR(4000) =   N''      
 --, @CurrentUTCTime     DATETIME  =   GETUTCDATE()      
      
DECLARE      
   @OutputList      AS TABLE  (      
   RedFlagId      INT      
  , LastModifiedTimestamp   DATETIME      
  )      
      
SET  @OutputLastModifiedTimestampAtLocal   =   ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)   --SQLEnlight SA0121      
SET  @OutputRedFlagId       =   ISNULL(@OutputRedFlagId, NULL)        --SQLEnlight SA0121      
SET  @Scope          =   ISNULL(@Scope, NULL)          --SQLEnlight SA0121      
      
      
    SELECT @Min = RM.MinimumRange FROM [TCD].RedFlag RM WHERE Item = @ItemID AND Id = @Id      
    SELECT @Max = RM.MaximumRange FROM [TCD].RedFlag RM WHERE Item = @ItemID AND Id = @Id      
 SELECT @ExistingLoc = Location FROM  [TCD].RedFlag WHERE  Id = @Id AND Is_Deleted=0       
 SELECT @ExistingItem = Item FROM  [TCD].RedFlag WHERE  Id = @Id AND Is_Deleted=0       
    DECLARE @PlantId INT = (SELECT MG.Id      
       FROM TCD.MachineGroupType MGT      
        INNER JOIN      
        TCD.MachineGroup MG ON MGT.Id = MG.GroupTypeId      
       WHERE MGT.Id = 1      
     AND MG.Is_Deleted = 0);      
  IF(@LocationID > 1 AND @MachineCompartmentId IS NULL AND NOT EXISTS (SELECT * FROM tcd.MachineGroup MG      
      LEFT JOIN TCD.Meter M ON MG.Id = CASE M.IsPlant WHEN 'TRUE' THEN COALESCE(  M.GroupId ,@PlantId) ELSE M.GroupId END      
      LEFT JOIN TCD.Sensor S ON MG.Id = CASE S.IsPlant WHEN 'TRUE' THEN COALESCE(  S.GroupId ,@PlantId) ELSE S.GroupId END      
      WHERE ((S.SensorId IS NOT NULL      
          AND S.Is_deleted = 0      
          AND S.MachineCompartment IS NULL)      
       OR (M.MeterId IS NOT NULL      
          AND M.Is_deleted = 0      
          AND M.MachineCompartment IS NULL))      
       AND MG.Id = @LocationID))      
  BEGIN      
    SET @Scope  = '301'      
  END      
  ELSE      
  BEGIN      
   IF(@IsDirty = 1)      
   BEGIN      
   IF (      
         @LastModifiedTimestampAtCentral    IS NOT NULL      
         AND      
         NOT EXISTS ( SELECT 1      
           FROM TCD.RedFlag  RF      
           WHERE RF.EcolabAccountNumber = @EcolabAccountNumber      
            AND RF.ID     = @Id      
            AND RF.LastModifiedTime  = @LastModifiedTimestampAtCentral      
          )      
       )      
        BEGIN      
          SET   @ErrorId    = 60000      
          SET   @ErrorMessage   = N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'      
          RAISERROR (@ErrorMessage, 16, 1)      
          SET   @ReturnValue   = -1      
          RETURN  (@ReturnValue)      
        END      
   UPDATE [TCD].RedFlag SET MinimumRange = @MinRange,MaximumRange = @MaxRange,LastModifiedByUserId = @UserID       
     OUTPUT      
      inserted.ID      AS   Id      
     , inserted.LastModifiedTime  AS   LastModifiedTimestamp      
     INTO      
      @OutputList (      
      RedFlagId      
     , LastModifiedTimestamp      
     )         
        FROM [TCD].RedFlag WHERE Item = @ItemID AND Id = @Id      
   SET @OutPut = '201'         
    SET @Scope = @OutPut --SELECT @Scope       
   END      
   ELSE      
   BEGIN      
      
    IF(NOT EXISTS (SELECT 1 FROM  [TCD].RedFlag WHERE  Item = @ItemID AND Location = @LocationID AND Id <> @Id AND Is_Deleted=0) AND @IsSelected = 1)        
      BEGIN      
      
    IF((@ExistingLoc <> @LocationID) OR (@ExistingItem <> @ItemID) OR       
   EXISTS(SELECT 1 FROM [TCD].RedFlagMappingData WHERE MappingId = @Id AND MachineId IS NOT NULL AND @MachineCompartmentId IS NULL AND Is_Deleted=0) OR      
   EXISTS(SELECT 1 FROM [TCD].RedFlagMappingData WHERE MappingId = @Id AND MachineId IS NULL AND @MachineCompartmentId IS NOT NULL AND Is_Deleted=0)      
    )      
    BEGIN      
     UPDATE [TCD].RedFlagMappingData SET      
            Is_Deleted = 1,LastModifiedByUserId = @UserID  WHERE MappingId = @Id      
    END      
   IF (      
         @LastModifiedTimestampAtCentral    IS NOT NULL      
         AND      
         NOT EXISTS ( SELECT 1      
           FROM TCD.RedFlag  RF      
           WHERE RF.EcolabAccountNumber = @EcolabAccountNumber      
            AND RF.ID     = @Id      
            AND RF.LastModifiedTime  = @LastModifiedTimestampAtCentral      
          )      
       )      
        BEGIN      
          SET   @ErrorId    = 60000      
          SET   @ErrorMessage   = N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'      
          RAISERROR (@ErrorMessage, 16, 1)      
          SET   @ReturnValue   = -1      
          RETURN  (@ReturnValue)      
        END         
  UPDATE [TCD].RedFlag SET      
  Item = @ItemID,      
  MaximumRange = @MaxRange,      
  MinimumRange = @MinRange,      
  Location = @LocationID,      
  LastModifiedByUserId = @UserID   ,    
  RedFlagCategoryId = @CategoryId,    
  FormulaId = @FormulaId,    
  ProductId = @ProductId,    
  MeterId = @MeterId,    
  SensorId = @SensorId    
  OUTPUT      
    inserted.ID      AS   Id      
   , inserted.LastModifiedTime  AS   LastModifiedTimestamp      
  INTO      
    @OutputList (      
    RedFlagId      
   , LastModifiedTimestamp      
  )         
  WHERE ID = @Id AND EcolabAccountNumber = @EcolabAccountNumber      
      
  INSERT INTO [TCD].RedFlagMappingData(MappingId,MachineId,EcolabAccountNumber,LastModifiedByUserId) VALUES(@Id,@MachineCompartmentId,@EcolabAccountNumber,@UserID)      
  SET @OutPut = '201'         
    SET @Scope = @OutPut --SELECT @Scope        
     END      
  ELSE       
  BEGIN      
   IF NOT EXISTS(SELECT 1 FROM [TCD].RedFlagMappingData RM INNER JOIN [TCD].RedFlag RF ON RM.MappingId = RF.Id       
    WHERE ISNULL(RM.MachineId,'') = ISNULL(@MachineCompartmentId,'') AND RF.Item = @ItemID AND RF.Location = @LocationID AND RF.Is_Deleted = 0 AND RM.Is_Deleted = 0 AND @IsSelected = 1)      
      
  BEGIN      
      
    /* Machine level Update and adding for already existing redflag details */      
      
      IF(@IsSelected = 1)      
    BEGIN      
    IF EXISTS (SELECT 1 FROM [TCD].RedFlagMappingData WHERE MachineId is NULL AND MappingId = @Id AND Is_Deleted = 0)      
    BEGIN      
    UPDATE [TCD].RedFlagMappingData SET      
            Is_Deleted = 1,LastModifiedByUserId = @UserID  WHERE MappingId = @Id      
      
   IF (      
         @LastModifiedTimestampAtCentral    IS NOT NULL      
         AND      
         NOT EXISTS ( SELECT 1      
           FROM TCD.RedFlag  RF      
           WHERE RF.EcolabAccountNumber = @EcolabAccountNumber      
            AND RF.ID     = @Id      
            AND RF.LastModifiedTime  = @LastModifiedTimestampAtCentral      
          )      
       )      
        BEGIN      
          SET   @ErrorId    = 60000      
          SET   @ErrorMessage   = N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'      
          RAISERROR (@ErrorMessage, 16, 1)      
          SET   @ReturnValue   = -1      
          RETURN  (@ReturnValue)      
        END         
   UPDATE [TCD].RedFlag SET      
      Item = @ItemID,      
      MaximumRange = @MaxRange,      
      MinimumRange = @MinRange,      
      Location = @LocationID,      
      LastModifiedByUserId = @UserID    ,    
  RedFlagCategoryId = @CategoryId,    
  FormulaId = @FormulaId,    
  ProductId = @ProductId,    
  MeterId = @MeterId,    
  SensorId = @SensorId     
      OUTPUT      
       inserted.ID      AS   Id      
      , inserted.LastModifiedTime  AS   LastModifiedTimestamp      
      INTO      
       @OutputList (      
       RedFlagId      
      , LastModifiedTimestamp      
      )          
      WHERE ID = @Id AND EcolabAccountNumber = @EcolabAccountNumber      
         
   INSERT INTO [TCD].RedFlagMappingData(MappingId,MachineId,EcolabAccountNumber,LastModifiedByUserId)       
        VALUES(@Id,@MachineCompartmentId,@EcolabAccountNumber,@UserID)      
    END      
    ELSE      
    BEGIN      
          
               
   INSERT INTO [TCD].RedFlagMappingData(MappingId,MachineId,EcolabAccountNumber,LastModifiedByUserId)       
        VALUES(@Id,@MachineCompartmentId,@EcolabAccountNumber,@UserID)      
     END      
     END      
     ELSE      
     BEGIN      
    UPDATE [TCD].RedFlagMappingData SET      
            Is_Deleted = CASE WHEN @IsSelected = 0 THEN 1 WHEN @IsSelected = 1 THEN 0 END,      
            LastModifiedByUserId = @UserID  WHERE MachineId = @MachineCompartmentId AND MappingId = @Id      
      
   IF(@IsSelected = 1)      
   INSERT INTO [TCD].RedFlagMappingData(MappingId,MachineId,EcolabAccountNumber,LastModifiedByUserId)       
        VALUES(@Id,@MachineCompartmentId,@EcolabAccountNumber,@UserID)      
     END      
      
    /* End of the Machine Level logic */      
      
    /*  Group level Update and adding for already existing redflag details */      
      
    IF(@MachineCompartmentId IS NULL AND @IsSelected = 1)      
    BEGIN      
    UPDATE [TCD].RedFlagMappingData SET      
            Is_Deleted = 1 WHERE MappingId = @Id      
      
    INSERT INTO [TCD].RedFlagMappingData(MappingId,MachineId,EcolabAccountNumber,LastModifiedByUserId)       
        VALUES(@Id,@MachineCompartmentId,@EcolabAccountNumber,@UserID)      
    END      
      
    /* End of the Group Level logic */      
    SET @OutPut = '201'         
      SET @Scope = @OutPut --SELECT @Scope        
          
    IF(@Min <> @MinRange OR @Max <> @MaxRange)      
   BEGIN      
   IF (      
         @LastModifiedTimestampAtCentral    IS NOT NULL      
         AND      
         NOT EXISTS ( SELECT 1      
           FROM TCD.RedFlag  RF      
           WHERE RF.EcolabAccountNumber = @EcolabAccountNumber      
            AND RF.ID     = @Id      
            AND RF.LastModifiedTime  = @LastModifiedTimestampAtCentral      
          )      
       )      
        BEGIN      
          SET   @ErrorId    = 60000      
          SET   @ErrorMessage   = N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'      
          RAISERROR (@ErrorMessage, 16, 1)      
          SET   @ReturnValue   = -1      
          RETURN  (@ReturnValue)      
        END         
    UPDATE [TCD].RedFlag SET MinimumRange = @MinRange,MaximumRange = @MaxRange,LastModifiedByUserId = @UserID        
        OUTPUT      
       inserted.ID      AS   Id      
      , inserted.LastModifiedTime  AS   LastModifiedTimestamp      
      INTO      
       @OutputList (      
       RedFlagId      
      , LastModifiedTimestamp      
      )       
        FROM [TCD].RedFlag       
               
        WHERE Item = @ItemID AND Id = @Id      
   SET @OutPut = '201'         
    SET @Scope = @OutPut --SELECT @Scope        
    END      
      
   END         
   ELSE      
    BEGIN      
     SET @OutPut = '401'         
      SET @Scope = @OutPut SELECT @Scope        
    END       
  END      
END       
  END      
 SELECT TOP 1       
  @OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp      
 , @OutputRedFlagId    = O.RedFlagId      
FROM @OutputList       O          
      
RETURN (@ReturnValue)      
      
--SET NOCOUNT OFF                --SQLEnlight SA0144      
END

GO



IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProductStandardPrice]') AND type in (N'U ') )
BEGIN
CREATE TABLE [TCD].[ProductStandardPrice]
(
	[Id] INT NOT NULL IDENTITY(1,1)  PRIMARY KEY 
	,[EcolabAccountNumber] [nvarchar](1000) NOT NULL
	,[ProductId] INT
    ,[ListPrice] NUMERIC(18, 4) NULL
	,[ContractPrice] NUMERIC(18,4) NULL
	,[CountryPrice] NUMERIC(18,4) NULL
	,[LastModifiedByUserId]    INT         NULL,
	[LastModifiedTime] DATETIME NOT NULL DEFAULT getutcdate(), 
    [LastSyncTime] DATETIME NULL
)

END

GO


GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetChemicalName]') AND type in (N'P', N'PC'))
DROP PROCEDURE [TCD].[GetChemicalName]

GO
/*      
 ==========================================================================================      
 Purpose:  Fecthing the Chemical Names from product Master    
    
 Author:  Krishna Gangadhar Thota  
    
 --------------------------------------------------------------      
 Sep-04-2014 ENT: Initial version.      
 ==========================================================================================  
  [dbo].[usp_GetChemicalName],    
*/     
CREATE PROCEDURE [TCD].[GetChemicalName](@ChemName Varchar(25),@EcolabAccountNumber nvarchar(25))     
AS     
SET NOCOUNT ON    
  BEGIN     
  DECLARE @RegionId int
  DECLARE @Country VARCHAR(250)
  SELECT @RegionId = RegionID from [TCD].Plant WHERE EcolabAccountNumber = @EcolabAccountNumber
  SELECT @Country = ISNULL(NULLIF(PLA.Country, ''), PLA.Shippingcountry) FROM [TCD].Plant P JOIN [TCD].PlantCustAddress PLA ON P.EcolabAccountNumber = PLA.EcolabAccountNumber 
	   WHERE P.EcolabAccountNumber = @EcolabAccountNumber

 SELECT M.ProductId, RTRIM(Name) + ' ( ' + RTRIM(SKU) + ' )' as Name, 
 (CASE WHEN ISNULL( M.Cost,0)>0 then M.Cost 
		WHEN ISNULL(PSP.ListPrice,0)>0 THEN PSP.ListPrice
		WHEN ISNULL(PSP.ContractPrice,0)>0 THEN PSP.ContractPrice
		WHEN ISNULL(PSP.CountryPrice,0)>0 THEN PSP.CountryPrice
		ELSE M.Cost 
 END) Cost
 
 ,M.IncludeinCI
 FROM [TCD].ProductMaster M    
 LEFT JOIN TCD.ProductStandardPrice PSP on M.ProductId=PSP.ProductId and PSP.EcolabAccountNumber=@EcolabAccountNumber
 WHERE (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
 AND M.RegionId = @RegionId
 AND M.Country = @Country
 AND M.Is_Deleted =0
 AND NOT EXISTS (SELECT ProductId     
     FROM   [TCD].ProductdataMapping Map     
                 WHERE  M.ProductId = Map.ProductId AND Map.Is_Deleted=0)  
Order By M.Name     
  END
GO

GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[SavePlantProductStandardPrice]') AND type in (N'P', N'PC'))
DROP PROCEDURE [TCD].[SavePlantProductStandardPrice] 

GO
/*      
 ==========================================================================================      
 Purpose:  Save the Standard Price 
    
 Author:  Suresh kanchamreddy

    
 --------------------------------------------------------------      
 Dec-11-2015 ENT: Initial version.      
 ==========================================================================================   
*/

CREATE PROCEDURE [TCD].[SavePlantProductStandardPrice] 
(		
		@Id										INT						=	NULL
		,@EcolabAccountNumber					NVARCHAR(1000)
		,@ProductId									INT	
		,@ListPrice									FLOAT
		,@ContractPrice								FLOAT
		,@CountryPrice								FLOAT
		,@UserID									INT
	,	@OutputStandardPriceId							INT						=	NULL	OUTPUT
	,	@LastModifiedTimestampAtCentral				DATETIME				=	NULL
	,	@OutputLastModifiedTimestampAtLocal			DATETIME				=	NULL	OUTPUT
) 
AS 
SET NOCOUNT ON
  
  BEGIN 
	
	DECLARE	
		@Output							VARCHAR(100)	=			''  
	,	@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()
	
	DECLARE
			@OutputList						AS	TABLE		(
			StandardPriceId					INT
		,	LastModifiedTimestamp			DATETIME
		)

SET		@OutputLastModifiedTimestampAtLocal			=			ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight
SET		@OutputStandardPriceId							=			ISNULL(@OutputStandardPriceId, NULL)								--SQLEnlight

	
	IF EXISTS (SELECT 1 FROM [TCD].ProductStandardPrice WHERE  ProductID = @ProductId AND EcolabAccountNumber = @EcolabAccountNumber)
		BEGIN
			  
					
						  UPDATE 
							[TCD].ProductStandardPrice 
							SET 
								ListPrice = @ListPrice 
							,	ContractPrice = @ContractPrice
							,	CountryPrice = @CountryPrice
							,	LastModifiedByUserId	=	@UserID
							,	LastModifiedTime		=	@CurrentUTCTime							
							OUTPUT
								inserted.Id	AS	 StandardPriceId
							,	inserted.LastModifiedTime		AS	LastModifiedTimestamp
							INTO
								@OutputList	(
								StandardPriceId
							,	LastModifiedTimestamp
							)
							WHERE ProductID = @ProductId AND  EcolabAccountNumber = @EcolabAccountNumber 
		END
	ELSE
	IF NOT EXISTS (SELECT 1 FROM [TCD].ProductStandardPrice WHERE  ProductID = @ProductId AND EcolabAccountNumber = @EcolabAccountNumber)   
		BEGIN
			
			INSERT INTO [TCD].ProductStandardPrice(EcolabAccountNumber,ProductId,ListPrice,ContractPrice,CountryPrice,LastModifiedByUserId)
			OUTPUT
					inserted.Id						AS			StandardPriceId
				,	inserted.LastModifiedTime		AS			LastModifiedTimestamp
				INTO
					@OutputList	(
					StandardPriceId
				,	LastModifiedTimestamp
				)
			values( @EcolabAccountNumber, @ProductId, @ListPrice, @ContractPrice, @CountryPrice, @UserID )

		END

	SELECT	TOP 1	
		@OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp
	,	@OutputStandardPriceId				=	O.StandardPriceId
FROM	@OutputList							O


RETURN	(@ReturnValue)

--SET NOCOUNT OFF;
END

GO