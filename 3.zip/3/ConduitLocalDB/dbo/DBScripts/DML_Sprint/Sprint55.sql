--Declare temp table variable to hold input data
DECLARE	@tempResourceKeyMaster	TABLE	(
TempId					INT				IDENTITY(1, 1)
,	ResourceId				INT				PRIMARY	KEY
,	[Key]					NVARCHAR(100)
)

--Populate temp table variable with the input data
INSERT @tempResourceKeyMaster ([ResourceId], [Key]) VALUES
(2145, N'FIELD_UseMe1FromGroup')
,	 (2146, N'FIELD_UseMe2FromGroup')
,	 (2147, N'FIELD_UsePumpOfGroup')
,	 (2148, N'FIELD_STOPMODE2')
,	 (2149, N'FIELD_WASHERSTOPUSEFINALEXTRACTING')
,	 (2150, N'FIELD_STOPMODE1')
,	 (2151, N'FIELD_TEMPERATUREALARMYESNO')
,	 (2152, N'FIELD_PHPROBE')
,	 (2153, N'FIELD_WEIGHTCELL')
,	 (2154, N'FIELD_TEMPERATURE')
,	 (2155, N'FIELD_WATERCOUNTER')

SET	IDENTITY_INSERT	TCD.ResourceKeyMaster	ON

MERGE	TCD.ResourceKeyMaster			AS TARGET
USING	@tempResourceKeyMaster		AS SOURCE
ON	TARGET.ResourceId		=			SOURCE.ResourceId
WHEN	NOT MATCHED		THEN
INSERT	(ResourceId			,[Key]			)
VALUES	(SOURCE.ResourceId	,SOURCE.[Key]	);

SET	IDENTITY_INSERT	TCD.ResourceKeyMaster	OFF
;

DECLARE	@tempResourceKeyValue	TABLE	(
TempId					INT				IDENTITY(1, 1)
,	ResourceId				INT
,	Value					NVARCHAR(400)	NOT	NULL
,	Locale					NVARCHAR(50)	NOT	NULL
,	languageID				INT
)

INSERT @tempResourceKeyValue ([ResourceId], [Value], [Locale], [languageID]) VALUES
(2145, N'Use ME 1 from Group', N'en-US', 1)
,	(2146, N'Use ME 2 from Group', N'en-US', 1)
,	(2147, N'Use Pump of Group', N'en-US', 1)
,	(2148, N'(Stop Mode 2)', N'en-US', 1)
,	(2149, N'Washer Stop: Use Final Extracting', N'en-US', 1)
,	(2150, N'(Stop Mode 1)', N'en-US', 1)
,	(2151, N'Temperature Alarm Yes/No', N'en-US', 1)
,	(2152, N'pH probe', N'en-US', 1)
,	(2153, N'Current Injection', N'en-US', 1)
,	(2154, N'Current Injection', N'en-US', 1)
,	(2155, N'Current Injection', N'en-US', 1)

MERGE	TCD.ResourceKeyValue			AS TARGET
USING	@tempResourceKeyValue		AS SOURCE
ON	TARGET.ResourceId		=			SOURCE.ResourceId
AND	TARGET.languageID		=			SOURCE.languageID
WHEN	NOT MATCHED		THEN
INSERT	(ResourceId			,Value			,Locale			,languageID)
VALUES	(SOURCE.ResourceId	,SOURCE.Value	,SOURCE.Locale	,SOURCE.languageID	);

DECLARE	@tempResourceKeyPageMapping			TABLE	(
TempId					INT					IDENTITY(1, 1)
,	Id					INT					NOT NULL
,	ResourceId			int					NOT NULL
,	PageId				int					NOT NULL
)

INSERT	@tempResourceKeyPageMapping	(Id, ResourceId	,PageId	) VALUES
(853, 2145, 31)
,	(854, 2146, 31)
,	(855, 2147, 31)
,	(856, 2148, 31)
,	(857, 2149, 31)
,	(858, 2150, 31)
,	(859, 2151, 31)
,	(860, 2152, 31)
,	(861, 2153, 31)
,	(862, 2154, 31)
,	(863, 2155, 31)


MERGE	TCD.ResourceKeyPageMapping			AS			TARGET
USING	@tempResourceKeyPageMapping		AS			SOURCE
ON	TARGET.Id		=			SOURCE.Id
WHEN	NOT MATCHED		THEN
INSERT	(Id , ResourceId, PageId)
VALUES	(SOURCE.Id,SOURCE.ResourceId	,SOURCE.PageId	);

GO


Update TCD.ControllerModelControllerTypeMapping SET PumpValveCount = 8, MECount = 2 WHERE ControllerModelId = 8
Update TCD.ControllerModelControllerTypeMapping SET PumpValveCount = 12, MECount = 2 WHERE ControllerModelId = 11