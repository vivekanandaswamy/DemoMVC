﻿IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = N'TCD'  AND TABLE_NAME = N'SyncConfigSettings')
AND NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = N'TCD'  AND TABLE_NAME = N'ConfigSettings')
BEGIN
	EXEC sys.sp_rename
		@objname = 'TCD.SyncConfigSettings',
		@newname = 'ConfigSettings'
END
GO

IF  EXISTS (SELECT
			*
		FROM sys.objects 
		WHERE object_id = OBJECT_ID(N'[TCD].[GetSyncConfigSettings]') 
			AND type IN (N'P', N'PC'))
BEGIN
	DROP PROCEDURE [TCD].[GetSyncConfigSettings]
END
GO

CREATE PROCEDURE [TCD].[GetSyncConfigSettings]
	@Type NVARCHAR(50)	
	
AS
SET NOCOUNT ON
	SELECT SCS.KEYNAME,SCS.VALUE  from TCD.ConfigSettings SCS
	WHERE SCS.Type=@Type AND SCS.Active=1
RETURN 0
GO

IF  EXISTS (SELECT
			*
		FROM sys.objects 
		WHERE object_id = OBJECT_ID(N'[TCD].[UpdateConfiguration]') 
			AND type IN (N'P', N'PC'))
BEGIN
	DROP PROCEDURE [TCD].[UpdateConfiguration]
END
GO

CREATE PROCEDURE [TCD].[UpdateConfiguration]
(	
	@ServiceName NVARCHAR(50),
	@KeyName NVARCHAR(50),
	@Value NVARCHAR(50)
)
AS
SET NOCOUNT ON
BEGIN
	UPDATE TCD.ConfigSettings 
	SET Value = @Value
	WHERE KeyName = @KeyName 
	AND [Type] = @ServiceName 
	AND Active=1
RETURN 0
END
