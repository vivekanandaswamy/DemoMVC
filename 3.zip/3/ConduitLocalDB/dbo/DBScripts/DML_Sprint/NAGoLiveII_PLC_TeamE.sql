﻿IF NOT EXISTS (SELECT * FROM SYS.columns c WHERE C.name = 'CounterNum' AND c.object_id = object_id('[TCD].[Meter]'))
BEGIN
	ALTER TABLE TCD.METER ADD CounterNum INT
END
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlConventionalData_Online]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlConventionalData_Online]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ProcessMyControlConventionalData_Online]
(
	@ControllerID   INT,
	@VxML           XML,
	@RedFlagShiftId INT OUTPUT
)
AS
	BEGIN
	    DECLARE @MachineNumber           INT,
			  @StepNumber              INT,
			  @StartDateTime           DATETIME,
			  @EndDateTime             DATETIME,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @PHValue                 INT,
			  @TemperatureMin          INT,
			  @TemperatureMax          INT,
			  @TempMinStatus           INT,
			  @TempMaxStatus           INT,
			  @BatchNumber             INT,
			  @WasherID                INT,
			  @WasherGroupID           INT,
			  @EcoLabWasherID          INT,
			  @ProgramMasterID         INT,
			  @PlantWasherNumber       INT,
			  @ShiftID                 INT,
			  @FrmParameterID          INT,
			  @PHParameterID           INT,
			  @PHParameterStatus       INT,
			  @BatchID                 INT,
			  @ShiftStartdate          DATETIME,
			  @ShiftName               NVARCHAR(50),
			  @XMLDataID               INT,
			  @TempParameter           INT,
			  @TemperatureMinParam     INT,
			  @TemperatureMaxParam     INT,
			  @TempMinStatusParam      INT,
			  @TempMaxStatusParam      INT,
			  @WashStepNo              INT,
			  @CurrencyCode            VARCHAR(50),
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @TargetTurnTime          INT,
			  @MeterID                INT,
			  @WaterConsumption1      INT,
			   @WaterConsumption2      INT

	    SELECT @MachineNumber = T.c.value('@MachineNumber', 'INT'),
			 @StepNumber = T.c.value('@StepNumber', 'INT'),
			 @StartDateTime = T.c.value('@StartDateTime', 'DATETIME'),
			 @EndDateTime = T.c.value('@EndDateTime', 'DATETIME'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@NominalLoad', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'INT'),
			 @PHStatus = T.c.value('@PHStatus', 'INT'),
			 @PHValue = T.c.value('@PHValue', 'INT'),
			 @TemperatureMin = T.c.value('@TemperatureMin', 'INT'),
			 @TemperatureMax = T.c.value('@TemperatureMax', 'INT'),
			 @TempMaxStatus = T.c.value('@TemperatureMaxStatus', 'INT'),
			 @TempMinStatus = T.c.value('@TemperatreMinStatus', 'INT'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @WaterConsumption1=T.c.value('@WaterConsumption1','NVARCHAR'),
			 @WaterConsumption2=T.c.value('@WaterConsumption2','NVARCHAR')

	    FROM @VxML.nodes('MyControlConventionalData') T(C);
	    SELECT @PHParameterID = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'pH';
	    SELECT @PHParameterStatus = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'PH Status';
	    SELECT @TemperatureMinParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Mimum Temperature';
	    SELECT @TemperatureMaxParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Maximum Temperature';
	    SELECT @TempMinStatusParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Minimum Temperature Status';
	    SELECT @TempMaxStatusParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Max Temperature Status';
	    SELECT @WashStepNo = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'StepCompartment No';
	    SELECT @FrmParameterID = [Id]
	    FROM TCD.ConduitPArameters
	    WHERE Name = 'Formula Number';
	    DECLARE @ShiftMapping TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    INSERT INTO @ShiftMapping
	    (
		  ShiftId,
		  ShiftName,
		  ShiftStartdate
	    )
	    EXEC TCD.GetShiftStartDate
		    @StartDateTime
	    SELECT @ShiftID = ShiftID,
			 @ShiftStartdate = ShiftStartdate
	    FROM @ShiftMapping;
	    SELECT @WasherGroupID = GroupId,
			 @WasherID = WasherID
	    FROM TCD.MachineSetup ms
	    WHERE ControllerID = @ControllerID
			AND MachineInternalId = @MachineNumber
			AND IsTunnel = 0
			AND IsDeleted = 0;
	    IF(@EndDateTime = '1/1/1900')
		   SELECT @EndDateTime = NULL;
	    IF(@StartDateTime = '1/1/1900')
		   SELECT @StartDateTime = NULL;
	    IF(@WasherId IS NOT NULL)
		   BEGIN
			  SELECT @ProgramMasterId = Wps.ProgramId
			  FROM TCD.Washer Ws
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.ControllerID = Wg.ControllerId
				  INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.EcoLabAccountNumber
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wps.Is_Deleted = 0;
			  SELECT @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber,
				    @CurrencyCode = P.CurrencyCode,
				    @TargetTurnTime = w.TargetTurnTime * 60
			  FROM TCD.Washer w
				  INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.EcolabAccountNumber
			  WHERE w.WasherId = @WasherID;
	   END;
	    SELECT @BatchID = BatchID
	    FROM TCD.BatchData
	    WHERE MachineInternalID = @MachineNumber
			AND StartDate = @StartDateTime
			AND ControllerBatchId = @BatchNumber
			AND MachineID = @WasherID;

	    --Start Getting InjectionCount and StepCount
	    SELECT @StdInjectionSteps = COUNT(DISTINCT wdpm.
	    WasherDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) -
			 COUNT(DISTINCT wdpm.WasherDosingSetupId)
	    FROM TCD.WasherDosingProductMapping wdpm
		    RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm.
		    WasherDosingSetupId = wds.WasherDosingSetupId
	    WHERE wds.ControllerID = @ControllerID
			AND wds.ProgramNumber = @ProgramNumber;
	    --End Getting InjectionCount and StepCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramMasterId
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT @EcolabTextileCategoryId = pcp.
			  EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp.
				    ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    IF(@BatchID IS NULL)
		   BEGIN
			  INSERT INTO TCD.BatchData
			  (ControllerBatchID,
			   EcolabWasherId,
			   GroupId,
			   MachineInternalId,
			   PlantWasherNumber,
			   StartDate,
			   EndDate,
			   ProgramNumber,
			   ProgramMasterId,
			   MachineID,
			   ActualWeight,
			   StandardWeight,
			   CurrencyCode,
			   ShiftId,
			   PartitionOn,
			   StdInjectionSteps,
			   StdWashSteps,
			   EcolabTextileCategoryId,
			   ChainTextileCategoryId,
			   FormulaSegmentId,
			   EcolabSaturationId,
			   PlantProgramId,
			   EndDateFormula,
			   TargetTurnTime
			  )
			  VALUES
			  (
				    @BatchNumber,
				    @EcoLabWasherID,
				    @WasherGroupID,
				    @MachineNumber,
				    @PlantWasherNumber,
				    @StartDateTime,
				    @EndDateTime,
				    @ProgramNumber,
				    @ProgramMasterId,
				    @WasherID,
				    @Load,
				    @NominalLoad,
				    @CurrencyCode,
				    @ShiftID,
				    @ShiftStartdate,
				    @StdInjectionSteps,
				    @StdWashSteps,
				    @EcolabTextileCategoryId,
				    @ChainTextileCategoryId,
				    @FormulaSegmentId,
				    @EcolabSaturationId,
				    @PlantProgramId,
				    @EndDateTime,
				    @TargetTurnTime
			  );
			  SELECT @BatchID = SCOPE_IDENTITY();
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM TCD.BatchParameters
				 WHERE BatchId = @BatchID
					  AND ParameterID = 38
			   )
			   BEGIN
			   IF(@StdWashSteps <> 0
				 OR @StdWashSteps <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
					   BatchId,
					   EcolabWasherId,
					   ParameterId,
					   ParameterValue,
					   PartitionOn
					)
					SELECT @BatchID,
						  @EcoLabWasherID,
						  38,
						  @StdWashSteps,
						  @ShiftStartdate;
				  END
			END;

			  --End Date  Time  is Null 
			  UPDATE TCD.BatchData
			    SET
				   EndDate = GETUTCDATE()
			  WHERE MachineInternalID = @MachineNumber
				   AND StartDate <> @StartDateTime
				   AND EndDate IS NULL
				   AND ControllerBatchId <> @BatchNumber
				   AND MachineId = @WasherId;	
																  		
			  -- Program Number	
			  IF(@ProgramNumber IS NOT NULL
				AND @ProgramNumber > 0)
				 BEGIN
					IF NOT EXISTS
					(
					    SELECT *
					    FROM TCD.WasherReading
					    WHERE WasherId = @WasherID
							AND ParameterID = @FrmParameterID
							AND DateTimeStamp = @StartDateTime
					)
					    BEGIN
						   INSERT INTO TCD.WasherReading
						   (WasherID,
						    ParameterID,
						    ParameterValue,
						    DateTimeStamp,
						    EcoLabWasherID,
						    Partitionon
						   )
						   VALUES
						   (
								@WasherID,
								@FrmParameterID,
								@ProgramNumber,
								@StartDateTime,
								@EcoLabWasherID,
								@ShiftStartdate
						   );
					    END;
				 END;
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM [TCD].[BatchCustomerData]
				 WHERE BatchID = @BatchId
					  AND @CustomerNumber IS NOT NULL
			  )
				 BEGIN
					INSERT INTO [TCD].[BatchCustomerData]
					([BatchId],
					 CustomerID,
					 [Weight],
					 PartitionOn,
					 EcolabWasherId
					)
					VALUES
					(
						  @BatchID,
						  @CustomerNumber,
						  @Load,
						  @ShiftStartdate,
						  @EcolabWasherID
					);
				 END;
		   END;

	    -- PH Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @PHParameterID
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@PHValue <> 0
				OR @PHValue <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @PHParameterID,
							    @PHValue,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 
	 
	    -- PH Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @PHParameterStatus
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@PHStatus <> 0
				OR @PHStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @PHParameterStatus,
							    @PHStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Min Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TemperatureMinParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TemperatureMin <> 0
				OR @TemperatureMin <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TemperatureMinParam,
							    @TemperatureMin,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Max Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TemperatureMaxParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TemperatureMax <> 0
				OR @TemperatureMax <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TemperatureMaxParam,
							    @TemperatureMax,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Min Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TempMinStatusParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TempMinStatus <> 0
				OR @TempMinStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TempMinStatusParam,
							    @TempMinStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Max Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TempMaxStatusParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TempMaxStatus <> 0
				OR @TempMaxStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TempMaxStatusParam,
							    @TempMaxStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- StepCompartment No
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @WashStepNo
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@StepNumber <> 0
				OR @StepNumber <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @WashStepNo,
							    @StepNumber,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END;
--Start water consumption per batch

	SELECT @MeterID=MeterId
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@WasherID

    IF NOT EXISTS(SELECT * FROM TCD.ModuleReading WHERE Reading =@WaterConsumption1 AND ModuleId = @MeterID)
  BEGIN
  IF(@WaterConsumption1 IS NOT NULL  AND @MeterID IS NOT NULL)
  BEGIN
   INSERT INTO TCD.ModuleReading
     (ModuleId,
      ModuleTypeId,
      Reading,
      TimeStamp
     )
     SELECT
     @MeterID,
     2,
     @WaterConsumption1,
     GETUTCDATE()
	 END
      END  
	  
   IF NOT EXISTS(SELECT * FROM TCD.ModuleReading WHERE Reading =@WaterConsumption2 AND ModuleId = @MeterID)
  BEGIN
  IF(@WaterConsumption2 IS NOT NULL  AND @MeterID IS NOT NULL)
  BEGIN
   INSERT INTO TCD.ModuleReading
     (ModuleId,
      ModuleTypeId,
      Reading,
      TimeStamp
     )
     SELECT
     @MeterID,	
     2,
     @WaterConsumption2,
     GETUTCDATE()
	 END
      END 

	 --End water consumption per batch
 END;

 
 
 GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlConventionalData_CompletedBatches]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlConventionalData_CompletedBatches]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessMyControlConventionalData_CompletedBatches](
	@ControllerID   INT,
	@VxML           XML,
	@PLCPointer     INT,
	@ReadPointer    INT,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @MachineNumber           INT,
			  @StartDateTime           DATETIME,
			  @EndDateTime             DATETIME,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @PHValue                 INT,
			  @TemperatureMin          INT,
			  @TemperatureMax          INT,
			  @TempMinStatus           INT,
			  @TempMaxStatus           INT,
			  @BatchNumber             INT,
			  @WasherID                INT,
			  @WasherGroupID           INT,
			  @EcoLabWasherID          INT,
			  @ProgramMasterID         INT,
			  @PlantWasherNumber       INT,
			  @ShiftID                 INT,
			  @BatchID                 INT,
			  @ShiftStartdate          DATETIME,
			  @LastStep                INT,
			  @CurrentStep             INT,
			  @CurrentStepTime         DATETIME,
			  @MinTempParamID          INT,
			  @MaxTempParamID          INT,
			  @MinTempStatuParamID     INT,
			  @MaxTempStatusParamID    INT,
			  @PHStatusParamID         INT,
			  @PHValueParamID          INT,
			  @CurrencyCode            VARCHAR(50),
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @ActualInjSteps          INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @TargetTurnTime          INT,
			  @PreviousShiftId		  INT,
			  @CurrentShiftId		  INT,
			  @MeterID                INT,
			  @StepComportment         INT,
			  @WaterConsumption1       INT,
			  @WaterConsumption2       INT

	    SELECT @MachineNumber = T.c.value('@MachineNumber', 'INT'),
			 @StartDateTime = T.c.value('@StartDateTime', 'DateTime'),
			 @EndDateTime = T.c.value('@EndDateTime', 'DateTime'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@NominalLoad', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'INT'),
			 @PHStatus = T.c.value('@PHStatus', 'INT'),
			 @PHValue = T.c.value('@PHValue', 'INT'),
			 @TemperatureMin = T.c.value('@TemperatureMin', 'INT'),
			 @TemperatureMax = T.c.value('@TemperatureMax', 'INT'),
			 @TempMaxStatus = T.c.value('@TemperatureMaxStatus', 'INT'),
			 @TempMinStatus = T.c.value('@TemperatreMinStatus', 'INT'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @WaterConsumption1=T.c.value('@WaterConsumption1','NVARCHAR'),
			 @WaterConsumption2=T.c.value('@WaterConsumption2','NVARCHAR')
	    FROM @VxML.nodes('MyControlConventionalData') T(C);
	    DECLARE @ShiftMapping TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    INSERT INTO @ShiftMapping
	    (ShiftId,
		ShiftName,
		ShiftStartdate
	    )
	    EXEC TCD.GetShiftStartDate
		    @StartDateTime
	    SELECT @ShiftID = ShiftID,
			 @ShiftStartdate = ShiftStartdate
	    FROM @ShiftMapping;
	    SELECT @WasherGroupID = GroupId,
			 @WasherID = WasherID
	    FROM TCD.MachineSetup ms
	    WHERE ControllerID = @ControllerID
			AND MachineInternalId = @MachineNumber
			AND IsTunnel = 0
			AND IsDeleted = 0;
	    IF(@WasherId IS NOT NULL)
		   BEGIN
			  SELECT @ProgramMasterId = Wps.ProgramId
			  FROM TCD.Washer Ws
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws
				  .WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =
				  Mst.GroupId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.
				  ControllerID = Wg.ControllerId
				  INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber =
				  Ws.EcoLabAccountNumber
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wps.Is_Deleted = 0;
			  SELECT @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber,
				    @CurrencyCode = P.CurrencyCode,
				    @TargetTurnTime = w.TargetTurnTime * 60
			  FROM TCD.Washer w
				  INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.
				  EcolabAccountNumber
			  WHERE w.WasherId = @WasherID;
		   END;
	    SELECT @BatchID = BatchID
	    FROM TCD.BatchData
	    WHERE MachineInternalID = @MachineNumber
			AND StartDate = @StartDateTime
			AND ControllerBatchId = @BatchNumber
			AND MachineID = @WasherID;

	    --Start Getting InjectionCount and StepCount

	    SELECT @StdInjectionSteps = COUNT(DISTINCT wdpm.
	    WasherDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) -
			 COUNT(DISTINCT wdpm.WasherDosingSetupId)
	    FROM TCD.WasherDosingProductMapping wdpm
		    RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm.
		    WasherDosingSetupId = wds.WasherDosingSetupId
	    WHERE wds.ControllerID = @ControllerID
			AND wds.ProgramNumber = @ProgramNumber;

	    --End Getting InjectionCount and StepCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramMasterId
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT @EcolabTextileCategoryId = pcp.
			  EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp.
				    ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    IF(@BatchID IS NULL)
		   BEGIN

		    --Start Rollup for previous completed shift
	   IF(CAST(@StartDateTime as date) < CAST(GETUTCDATE() as date))
	   BEGIN
		  SELECT TOP 1 @PreviousShiftId=ShiftId FROM TCD.BatchData WHERE MachineId=@WasherId ORDER BY StartDate DESC	   
		  SELECT Top 1 @CurrentShiftId = ShiftId from @ShiftMapping
		  IF(@CurrentShiftId != @PreviousShiftId)
		  BEGIN
			 EXEC TCD.ProductionShiftDataRollup @PreviousShiftId, @RedFlagShiftId OUTPUT
			 IF(@RedFlagShiftId IS NULL)
			 BEGIN
				SET @RedFlagShiftId = @PreviousShiftId
			 END
		  END
	   END
	   --End Rollup for previous completed shift

			  INSERT INTO TCD.BatchData
			  (ControllerBatchID,
			   EcolabWasherId,
			   GroupId,
			   MachineInternalId,
			   PlantWasherNumber,
			   StartDate,
			   EndDate,
			   ProgramNumber,
			   ProgramMasterId,
			   MachineID,
			   ActualWeight,
			   StandardWeight,
			   CurrencyCode,
			   ShiftId,
			   PartitionOn,
			   StdInjectionSteps,
			   StdWashSteps,
			   EcolabTextileCategoryId,
			   ChainTextileCategoryId,
			   FormulaSegmentId,
			   EcolabSaturationId,
			   PlantProgramId,
			   EndDateFormula,
			   TargetTurnTime
			  )
			  VALUES
			  (
				    @BatchNumber,
				    @EcoLabWasherID,
				    @WasherGroupID,
				    @MachineNumber,
				    @PlantWasherNumber,
				    @StartDateTime,
				    @EndDateTime,
				    @ProgramNumber,
				    @ProgramMasterId,
				    @WasherID,
				    @Load,
				    @NominalLoad,
				    @CurrencyCode,
				    @ShiftID,
				    @ShiftStartdate,
				    @StdInjectionSteps,
				    @StdWashSteps,
				    @EcolabTextileCategoryId,
				    @ChainTextileCategoryId,
				    @FormulaSegmentId,
				    @EcolabSaturationId,
				    @PlantProgramId,
				    @EndDateTime,
				    @TargetTurnTime
			  );
			  SELECT @BatchID = SCOPE_IDENTITY();
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM TCD.BatchParameters
				 WHERE BatchId = @BatchID
					  AND ParameterID = 38
			  )
				 BEGIN
					IF(@StdWashSteps > 0
					   OR @StdWashSteps <> NULL)
					    INSERT INTO TCD.BatchParameters
					    (BatchId,
						EcolabWasherId,
						ParameterId,
						ParameterValue,
						PartitionOn
					    )
							 SELECT @BatchID,
								   @EcoLabWasherID,
								   38,
								   @StdWashSteps,
								   @ShiftStartdate;
				 END;
		   END;
	    ELSE
		   BEGIN
			  UPDATE tcd.BatchData
			    SET
				   EndDate = @EndDateTime,
				   EndDateFormula = @EndDateTime,
				   ProgramNumber = @ProgramNumber,
				   ProgramMasterId = @ProgramMasterID,
				   ActualWeight = @Load,
				   SyncReady = 1
			  WHERE BatchID = @BatchID;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT 1
		   FROM [TCD].[BatchCustomerData]
		   WHERE BatchID = @BatchId
			    AND @CustomerNumber IS NOT NULL
	    )
		   BEGIN
			  INSERT INTO [TCD].[BatchCustomerData]
			  ([BatchId],
			   CustomerID,
			   [Weight],
			   PartitionOn,
			   EcolabWasherId
			  )
			  VALUES
			  (
				    @BatchID,
				    @CustomerNumber,
				    @Load,
				    @ShiftStartdate,
				    @EcolabWasherID
			  );
		   END;
	    ELSE
	    IF(@CustomerNumber > 0)
		   BEGIN
			  UPDATE [TCD].[BatchCustomerData]
			    SET
				   CustomerID = @CustomerNumber,
				   [Weight] = @Load
			  WHERE BatchID = @BatchId;
		   END;
	    CREATE TABLE #Dosing
	    (
		    equipmentNo INT,
		    StepNo      INT,
		    Qty         DECIMAL(10, 6)
	    );
	    INSERT INTO #Dosing
			 SELECT T.c.value('@Equipment', 'INT'),
				   T.c.value('@stepNo', 'INT'),
				   T.c.value('@Qty', 'Decimal(10,6)')
			 FROM @VxML.nodes(
			 'MyControlConventionalData/DosingData/Dosing'
						  ) T(C)
			 WHERE T.c.value('@Qty', 'Decimal(10,6)') > 0;
	    CREATE TABLE #StepTime
	    (
		    Number    INT,
		    [Time]    INT,
		    StartTime DATETIME,
		    EndTime   DATETIME
	    );
	    INSERT INTO #StepTime
	    (Number,
		[Time]
	    )
			 SELECT T.c.value('@Number', 'INT'),
				   T.c.value('@Time', 'INT')
			 FROM @VxML.nodes('MyControlConventionalData/StepTime/Step')
			 T(C);
	    CREATE TABLE #TimeStamp
	    (
		    Step_Number INT,
		    Time_Stamp  INT
	    );
	
	    --For Calculating TIME_STAMP

	    WITH TempTable
		    AS (SELECT DISTINCT
					Number
			   FROM #StepTime)
		    INSERT INTO #TimeStamp
		    (Step_Number,
			Time_Stamp
		    )
				 SELECT b.Number,
					   SUM(t.Time) Time_Stamp
				 FROM TempTable b
					 INNER JOIN #StepTime t ON b.Number >= t.Number
				 GROUP BY b.Number;
	    CREATE TABLE #BatchProductData
	    (
		    equipmentNo INT,
		    StepNo      INT,
		    Qty         DECIMAL(10, 6),
		    Time_Stamp  DATETIME2(7)
	    );
	    INSERT INTO #BatchProductData
	    (equipmentNo,
		StepNo,
		Qty,
		Time_Stamp
	    )
			 SELECT d.equipmentNo,
				   d.StepNo,
				   d.Qty,
				   DATEADD(ss, ts.Time_Stamp, @StartDateTime)
			 FROM #Dosing d
				 INNER JOIN #TimeStamp ts ON d.StepNo = ts.Step_Number
	    ;


	    --END For calculating TIMESTAMP

	    INSERT INTO TCD.BatchProductData
	    (BatchId,
		StepCompartment,
		ActualQuantity,
		PartitionOn,
		EcolabWasherId,
		ProductId,
		TimeStamp
	    )
			 SELECT @BatchID,
				   b.StepNo,
				   b.Qty,
				   @ShiftStartdate,
				   @EcolabWasherId,
				   a.ProductId,
				   b.Time_Stamp
			 FROM TCD.ControllerEquipmentSetup a
				 INNER JOIN #BatchProductData b ON a.
				 ControllerEquipmentId = b.equipmentNo
			 WHERE b.equipmentNo > 0
				  AND b.Qty > 0
				  AND ControllerID = @ControllerID
				  AND a.ProductId IS NOT NULL
				  

	    --Start Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
	    SELECT @ActualInjSteps = COUNT(DISTINCT StepNo)
	    FROM #Dosing;
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.BatchParameters
		   WHERE ParameterId = 37
			    AND batchid = @BatchID
			    AND @ActualInjSteps > 0
	    )
		   BEGIN
			  IF(@ActualInjSteps > 0
				OR @ActualInjSteps IS NOT NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchId,
							@EcolabWasherId,
							37,
							@ActualInjSteps,
							@ShiftStartDate;
		   END;
	    ELSE
		   BEGIN
			  UPDATE TCD.BatchParameters
			    SET
				   ParameterValue = @ActualInjSteps
			  WHERE ParameterId = 37
				   AND batchid = @BatchID;
		   END;
	    SELECT @LastStep = MAX([Number])
	    FROM #StepTime
	    WHERE [Time] > 0;
	    SELECT @CurrentStep = 1,
			 @CurrentStepTime = @StartDateTime;
	    WHILE(@CurrentStep <= @LastStep)
		   BEGIN
			  UPDATE #StepTime
			    SET
				   StartTime = @CurrentStepTime,
				   EndTime = DATEADD(ss, [time], @CurrentStepTime)
			  WHERE Number = @CurrentStep;
			  SELECT @CurrentStepTime = EndTime
			  FROM #StepTime
			  WHERE Number = @CurrentStep;
			  SELECT @CurrentStep = @CurrentStep + 1;
		   END;
	    INSERT INTO [TCD].[BatchWashStepData]
	    (BatchID,
		StepCompartment,
		StartTime,
		EndTime,
		PartitionOn,
		EcolabWasherId
	    )
			 SELECT @BatchID,
				   Number,
				   StartTime,
				   EndTime,
				   @ShiftStartdate,
				   @EcoLabWasherID
			 FROM #StepTime
			 WHERE Number <= @LastStep;
	    SELECT @MinTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Mimum Temperature';
	    SELECT @MaxTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Maximum Temperature';
	    SELECT @MaxTempStatusParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Max Temperature Status';
	    SELECT @MinTempStatuParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Minimum Temperature Status';
	    SELECT @PHValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH';
	    SELECT @PHStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH Status';
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MinTempParamID
	    )
		   BEGIN
			  IF(@TemperatureMin <> 0
				OR @TemperatureMin <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(BatchId,
					 EcolabWasherId,
					 ParameterId,
					 ParameterValue,
					 PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MinTempParamID,
						  @TemperatureMin,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MaxTempParamID
	    )
		   BEGIN
			  IF(@TemperatureMax <> 0
				OR @TemperatureMax <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(BatchId,
					 EcolabWasherId,
					 ParameterId,
					 ParameterValue,
					 PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MaxTempParamID,
						  @TemperatureMax,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MaxTempStatusParamID
	    )
		   BEGIN
			  IF(@TempMaxStatus <> 0
				OR @TempMaxStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(BatchId,
					 EcolabWasherId,
					 ParameterId,
					 ParameterValue,
					 PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MaxTempStatusParamID,
						  @TempMaxStatus,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MinTempStatuParamID
	    )
		   BEGIN
			  IF(@TempMinStatus <> 0
				OR @TempMinStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(BatchId,
					 EcolabWasherId,
					 ParameterId,
					 ParameterValue,
					 PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MinTempStatuParamID,
						  @TempMinStatus,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF(@PHStatus <> 0
		  OR @PHStatus <> NULL)
		   BEGIN
			  INSERT INTO TCD.BatchParameters
			  (BatchId,
			   EcolabWasherId,
			   ParameterId,
			   ParameterValue,
			   PartitionOn
			  )
			  VALUES
			  (
				    @BatchID,
				    @EcoLabWasherID,
				    @PHStatusParamID,
				    @PHStatus,
				    @ShiftStartdate
			  );
		   END;
	    IF(@PHValue <> 0
		  OR @PHValue <> NULL)
		   BEGIN
			  INSERT INTO TCD.BatchParameters
			  (BatchId,
			   EcolabWasherId,
			   ParameterId,
			   ParameterValue,
			   PartitionOn
			  )
			  VALUES
			  (
				    @BatchID,
				    @EcoLabWasherID,
				    @PHValueParamID,
				    @PHValue,
				    @ShiftStartdate
			  );
		   END;
		    EXEC TCD.ProcessMyControlProductionWaterConsumptionData
			 @BatchID,
			 @VxML,
			 @ShiftStartDate
	    DROP TABLE #BatchProductData;
	    DROP TABLE #Dosing;
	    DROP TABLE #StepTime;
	    DROP TABLE #TimeStamp;

	--Start water consumption per batch

	SELECT @MeterID=MeterId,@StepComportment=MachineCompartment
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@WasherID

    IF NOT EXISTS(SELECT * FROM TCD.BatchEnergyUsageData WHERE BatchId =@BatchID AND StepCompartment =@StepComportment AND ActualQuantity=@WaterConsumption1)
  BEGIN
  IF(@WaterConsumption1 IS NOT NULL  AND @MeterID IS NOT NULL AND @StepComportment IS NOT NULL)
  BEGIN
   INSERT INTO TCD.BatchEnergyUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
	  EcolabWasherId
     )
     SELECT
     @BatchID,
     @StepComportment,
     @WaterConsumption1,
     @ShiftStartdate,
	 @EcoLabWasherID
	 END
      END  
	  
 IF NOT EXISTS(SELECT * FROM TCD.BatchEnergyUsageData WHERE BatchId =@BatchID AND StepCompartment =@StepComportment AND ActualQuantity=@WaterConsumption2)
  BEGIN
  IF(@WaterConsumption2 IS NOT NULL  AND @MeterID IS NOT NULL AND @StepComportment IS NOT NULL AND @BatchID IS NOT NULL)
  BEGIN
   INSERT INTO TCD.BatchEnergyUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
	  EcolabWasherId
     )
     SELECT
     @BatchID,
     @StepComportment,
     @WaterConsumption2,
     @ShiftStartdate,
	 @EcoLabWasherID
	 END
      END  
 END;

 GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlTunnelWasherOnlineData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlTunnelWasherOnlineData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessMyControlTunnelWasherOnlineData](
	@ControllerID   INT,
	@xmlTags        XML,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @BatchID                 INT,
			  @WasherID                INT,
			  @EcolabWasherId          INT,
			  @CurrencyCode            VARCHAR(50),
			  @MachineInternalId       INT,
			  @WasherGroupID           INT,
			  @PlantWasherNumber       INT,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @BatchNumber             INT,
			  @TargetTurnTime          INT,
			  @PartitionOn             DATETIME,
			  @BatchStartTime          DATETIME,
			  @ProgramID               INT,
			  @NumberOfCompartments    INT,
			  @TransferSignalId        INT,
			  @BatchShiftId            INT,
			  @compartmentID           INT,
			  @TunnelXML               XML,
			  @TempXML                 XML,
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @CurrentStepComportmentNO INT,
               @CounterNO               INT,
               @MeterID                 INT,
               @ActualQuantity          INT

	    SELECT @TransferSignalId = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Transfer Signal';
	    CREATE TABLE #Batches
	    (
		    BatchNumber   INT,
		    StartDateTime DATETIME
	    );
	    -- SET @compartmentID = 1;

	    SELECT @TempXML = T.c.query('.')
	    FROM @xmlTags.nodes('MyControlTunnel') AS T(c);
	    SELECT @MachineInternalID = T.c.value('@MachineNumber', 'int')
	    FROM @TempXML.nodes('MyControlTunnel') AS T(c);
	    SELECT @EcolabWasherID = EcolabWasherId,
			 @WasherGroupID = Wg.WasherGroupId,
			 @PlantWasherNumber = PlantWasherNumber,
			 @WasherID = ws.WasherId,
			 @CurrencyCode = P.CurrencyCode,
			 @NumberOfCompartments = Mst.NumberofComp
	    FROM TCD.Washer AS Ws
		    INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = Ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.
		    GroupId
		    INNER JOIN TCD.WasherGroupType AS WgT ON WgT.
		    WasherGroupTypeId = Wg.WasherGroupTypeId
		    INNER JOIN TCD.ConduitController AS Ctrl ON Ctrl.
		    ControllerId = Mst.ControllerId
		    INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.
		    EcoLabAccountNumber
	    WHERE Ctrl.ControllerID = @ControllerID
			AND mst.MachineInternalId = @MachineInternalID
			AND Mst.IsTunnel = 1 AND Mst.IsDeleted =0;
	    SET @compartmentID = @NumberOfCompartments;
	    WHILE(@compartmentID <= @NumberOfCompartments
			AND @compartmentID > 0)
		   BEGIN
			  SELECT @TunnelXML = T.c.query('.')
			  FROM @xmlTags.nodes('MyControlTunnel/TunnelData') AS T(c)
			  WHERE T.c.value('@CompartmentNumber', 'INT') =
			  @compartmentID;
			  SELECT @MachineInternalID = T.c.value('@MachineNumber',
			  'int'
										    ),
				    @BatchNumber = T.c.value('@BatchNumber', 'INT'),
				    @BatchStartTime = T.c.value('@StartDateTime',
				    'DateTime'
										 ),
				    @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
				    @Load = T.c.value('@Load', 'Decimal(10,6)'),
				    @NominalLoad = T.c.value('@Nominalload',
				    'Decimal(10,6)'
									   ),
				    @CustomerNumber = T.c.value('@CustomerNumber',
				    'int'
										 ),
				    @PHStatus = T.c.value('@pHStatus', 'int')
			  FROM @TunnelXML.nodes('TunnelData') AS T(c);
			  DECLARE @ShiftStartDateTemp TABLE
			  (
				  ShiftId        INT,
				  ShiftName      NVARCHAR(50),
				  ShiftStartdate DATETIME
			  );
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchStartTime
			  SELECT @BatchShiftId = ShiftID,
				    @PartitionOn = ShiftStartdate
			  FROM @ShiftStartDateTemp;
			  IF(@ProgramNumber = 0
				OR @BatchNumber = 1)
				 BEGIN
					SELECT @compartmentID = @compartmentID - 1;
					CONTINUE;
				 END;
			  SELECT @ProgramID = ProgramId,
				    @TargetTurnTime = 3600 / (tps.TotalRunTime /
				    @NumberOfCompartments)
			  FROM TCD.TunnelProgramSetup AS tps
			  WHERE tps.WasherGroupId = @WasherGroupID
				   AND tps.is_deleted = 0
				   AND ProgramNumber = @ProgramNumber;
			  INSERT INTO #Batches
			  (BatchNumber,
			   StartDateTime
			  )
				    SELECT @BatchNumber,
						 @BatchStartTime;
			  SELECT @BatchID = NULL;
			  SELECT @BatchID = BatchID
			  FROM TCD.BatchData AS BD
			  WHERE BD.ControllerBatchId = @BatchNumber
				   AND BD.StartDate = @BatchStartTime
				   AND BD.MachineId = @WasherID;
			  --Start Getting InjectionCount,StepCount And ProductCount
			  SELECT @StdInjectionSteps = COUNT(tdpm.
			  TunnelDosingSetupId),
				    @StdWashSteps = COUNT(DISTINCT tds.
				    TunnelDosingSetupId) - COUNT(tdpm.
				    TunnelDosingSetupId)
			  FROM tcd.TunnelDosingProductMapping AS tdpm
				  RIGHT JOIN tcd.TunnelDosingSetup AS tds ON tdpm.
				  TunnelDosingSetupId = tds.TunnelDosingSetupId
			  WHERE tds.GroupId = @WasherGroupID
				   AND tds.ProgramNumber = @ProgramNumber;
			  --End Getting InjectionCount,StepCount And ProductCount
			  --Start-----ProgramMasterID logic for PlantChainProgram
			  SELECT @PlantProgramId = pm.PlantProgramId,
				    @EcolabTextileCategoryId = pm.
				    EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pm.ChainTextileId,
				    @FormulaSegmentId = pm.FormulaSegmentId,
				    @EcolabSaturationId = pm.EcolabSaturationId
			  FROM TCD.ProgramMaster AS pm
			  WHERE pm.ProgramId = @ProgramID
				   AND pm.Is_Deleted = 0;
			  IF(@PlantProgramId <> 0
				OR @PlantProgramId IS NOT NULL)
				 BEGIN
					--Assign value from plantchainprogram table based on plantprogramId
					SELECT @EcolabTextileCategoryId = pcp.
					EcolabTextileCategoryId,
						  @ChainTextileCategoryId = pcp.
						  ChainTextileCategoryId,
						  @FormulaSegmentId = pcp.FormulaSegmentId,
						  @EcolabSaturationId = pcp.
						  EcolabSaturationId
					FROM tcd.PlantChainProgram AS pcp
					WHERE pcp.PlantProgramId = @PlantProgramId
						 AND pcp.Is_Deleted = 0;
				 END;
			  --End-----ProgramMasterID logic for PlantChainProgram
			  IF @BatchID IS NULL
				 BEGIN
					INSERT INTO TCD.BatchData
					(ControllerBatchId,
					 EcolabWasherId,
					 GroupId,
					 MachineInternalId,
					 PlantWasherNumber,
					 StartDate,
					 ProgramNumber,
					 ProgramMasterId,
					 MachineId,
					 ActualWeight,
					 StandardWeight,
					 CurrencyCode,
					 ShiftId,
					 PartitionOn,
					 TargetTurnTime,
					 StdInjectionSteps,
					 StdWashSteps,
					 EcolabTextileCategoryId,
					 ChainTextileCategoryId,
					 FormulaSegmentId,
					 EcolabSaturationId,
					 PlantProgramId
					)
						  SELECT @BatchNumber,
							    @EcolabWasherID,
							    @WasherGroupID,
							    @MachineInternalID,
							    @PlantWasherNumber,
							    @BatchStartTime,
							    @ProgramNumber,
							    @ProgramID,
							    @WasherID,
							    @Load,
							    @NominalLoad,
							    @CurrencyCode,
							    @BatchShiftId,
							    @PartitionOn,
							    @TargetTurnTime,
							    @StdInjectionSteps,
							    @StdWashSteps,
							    @EcolabTextileCategoryId,
							    @ChainTextileCategoryId,
							    @FormulaSegmentId,
							    @EcolabSaturationId,
							    @PlantProgramId;
					SELECT @BatchID = SCOPE_IDENTITY();
					IF(@StdWashSteps > 0
					   OR @StdWashSteps <> NULL)
					    BEGIN
						   INSERT INTO TCD.BatchParameters
						   (BatchId,
						    EcolabWasherId,
						    ParameterId,
						    ParameterValue,
						    PartitionOn
						   )
								SELECT @BatchID,
									  @EcolabWasherId,
									  38,
									  @StdWashSteps,
									  @PartitionOn;
					    END;
					IF @CustomerNumber IS NOT NULL
					    BEGIN
						   IF NOT EXISTS
						   (
							  SELECT 1
							  FROM TCD.BatchCustomerData
							  WHERE BatchID = @BatchID
						   )
							  BEGIN
								 INSERT INTO TCD.BatchCustomerData
								 (BatchId,
								  CustomerID,
								  Weight,
								  PartitionOn,
								  EcolabWasherId
								 )
									   SELECT @BatchID,
											@CustomerNumber,
											@Load,
											@PartitionOn,
											@EcolabWasherId;
							  END;
					    END;
				 END;
			  -- Transfer Signal
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM tcd.WasherReading wr
				 WHERE wr.WasherId = @WasherID
					  AND wr.ParameterId = @TransferSignalId
					  AND wr.DateTimeStamp = @BatchStartTime
			  )
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterId,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TransferSignalId,
							    1,
							    @BatchStartTime,
							    @PartitionOn,
							    @EcolabWasherId
						  UNION ALL
						  SELECT @WasherID,
							    @TransferSignalId,
							    0,
							    @BatchStartTime,
							    @PartitionOn,
							    @EcolabWasherId;
				 END;
			  --Start Updating Batch Wash Step Data	 
			  EXEC TCD.UPDATEBatchWashStepForTunnel
				  @TunnelXML,
				  @WasherID,
				  @BatchID,
				  @BatchStartTime,
				  @PartitionOn,
				  @EcolabWasherId,
				  @compartmentID;
			  --End Updating Batch Wash Step Data	 
			  SELECT @compartmentID = @compartmentID - 1;
		   END;


	 --Start water consumption per step


   CREATE TABLE #WaterConsumptionData
     (
      Number          INT,
      Quantity        NVARCHAR,
     );
     INSERT INTO #WaterConsumptionData
     (Number,
  Quantity
     )
    SELECT T.c.value('@Counter', 'INT') AS Number, --PumpNumber
       T.c.value('@Value', 'NVARCHAR') AS Quantity --Water Quanity
    FROM @xmlTags.nodes('MyControlTunnel/TunnelData/WaterConsumption') T(C);

  
  SET @CurrentStepComportmentNO=1;
  SET @CounterNO=1;
  WHILE(@CurrentStepComportmentNO<=22)
  BEGIN
   SELECT @MeterID=MeterId
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@CurrentStepComportmentNO
   SELECT @ActualQuantity=wc.Quantity
  FROM #WaterConsumptionData wc where wc.Number=@CounterNO
  IF NOT EXISTS(SELECT * FROM TCD.WasherModuleOnlineUsageData WHERE WasherId = @WasherID AND StepComportment =@CurrentStepComportmentNO AND ModuleId = @MeterID AND ActualQuantity=@ActualQuantity )
  BEGIN
  IF(@WasherID IS NOT NULL AND @MeterID IS NOT NULL AND @MeterID IS NOT NULL AND @ActualQuantity IS NOT NULL)
  BEGIN
  SET @CounterNO=@CounterNO+1;
   INSERT INTO TCD.WasherModuleOnlineUsageData
     (WasherId,
      StepComportment,
      ModuleId,
      ActualQuantity,
      TimeStamp,
      EcolabWasherId
     )
     SELECT
     @WasherID,
     @CurrentStepComportmentNO,
     @MeterID,
     @ActualQuantity,
     GETUTCDATE(),
     @EcolabWasherId
      END  

	  END
        SET  @CurrentStepComportmentNO=@CurrentStepComportmentNO+1;
   
  END;

 END;


 GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlTunnelWasherProdData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlTunnelWasherProdData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ProcessMyControlTunnelWasherProdData](
	@ControllerID   INT,
	@xmlTags        XML,
	@PLCPointer     INT,
	@ReadPointer    INT,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @BatchID                   INT,
			  @WasherID                  INT,
			  @EcolabWasherId            INT,
			  @CurrencyCode              VARCHAR(50),
			  @MachineInternalId         INT,
			  @WasherGroupID             INT,
			  @PlantWasherNumber         INT,
			  @ProgramNumber             INT,
			  @Load                      DECIMAL(10, 2),
			  @NominalLoad               DECIMAL(10, 2),
			  @CustomerNumber            INT,
			  @PHStatus                  INT,
			  @PHValue                   INT,
			  @LFStatus                  INT,
			  @LFValue                   INT,
			  @BatchNumber               INT,
			  @TargetTurnTime            INT,
			  @PartitionOn               DATETIME2,
			  @BatchStartTime            DATETIME2,
			  @BatchEndTime              DATETIME2,
			  @ProgramID                 INT,
			  @NumberOfCompartments      INT,
			  @ProductId                 INT,
			  @CompartmentNum            INT,
			  @EquipmentType             INT,
			  @MinTempParamID            INT,
			  @MaxTempParamID            INT,
			  @TempStatusParamID         INT,
			  @PHValueParamID            INT,
			  @PHStatusParamID           INT,
			  @ConductivityValueParamID  INT,
			  @ConductivityStatusParamID INT,
			  @StdInjectionSteps         INT,
			  @StdWashSteps              INT,
			  @ActualInjSteps            INT,
			  @EcolabTextileCategoryId   INT,
			  @ChainTextileCategoryId    INT,
			  @FormulaSegmentId          INT,
			  @EcolabSaturationId        INT,
			  @PlantProgramId            INT,
			  @PreviousShiftId		    INT,
			  @CurrentShiftId		    INT,
			  @CurrentStepComportmentNO INT,
              @CounterNO                INT,
               @MeterID                 INT,
               @ActualQuantity          INT
	    DECLARE @BatchShiftId INT;
	    DECLARE @ShiftStartDateTemp TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    DECLARE @TunnelXML XML;
	    SELECT @TunnelXML = T.c.query('.')
	    FROM @xmlTags.nodes('MyControlTunnel/TunnelData') T(c)
	    WHERE T.c.value('@CompartmentNumber', 'INT') = 0;
	    SELECT @MachineInternalID = T.c.value('@MachineNumber', 'int'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @BatchStartTime = T.c.value('@StartDateTime', 'DateTime'),
			 @BatchEndTime = T.c.value('@EndDateTime', 'DateTime'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@Nominalload', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'int'),
			 @PHStatus = T.c.value('@Phstatus', 'int'),
			 @PHValue = T.c.value('@Phvalue', 'INT'),
			 @LFStatus = T.c.value('@LFStatus', 'INT'),
			 @LFValue = T.c.value('@LFValue', 'INT')
	    FROM @xmlTags.nodes('MyControlTunnel/TunnelData') T(c);
	    SELECT @EcolabWasherID = Ws.EcolabWasherId,
			 @WasherGroupID = Wg.WasherGroupId,
			 @PlantWasherNumber = PlantWasherNumber,
			 @WasherID = ws.WasherId,
			 @CurrencyCode = P.CurrencyCode,
			 @NumberOfCompartments = Mst.NumberofComp
	    FROM TCD.Washer Ws
		    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.
		    GroupId
		    INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId
		    = Wg.WasherGroupTypeId
		    INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId =
		    Mst.ControllerId
		    INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.
		    EcoLabAccountNumber
	    WHERE Ctrl.ControllerID = @ControllerID
			AND Mst.MachineInternalId = @MachineInternalID
			AND Mst.IsTunnel = 1 AND Mst.IsDeleted=0;
	    SELECT @EcolabWasherID;
	    SELECT @ProgramID = ProgramId,
			 @TargetTurnTime = (3600 / (tps.TotalRunTime /
			 @NumberOfCompartments))
	    FROM TCD.TunnelProgramSetup AS tps
	    WHERE tps.WasherGroupId = @WasherGroupID
			AND tps.is_deleted = 0
			AND ProgramNumber = @ProgramNumber;
	    DELETE FROM @ShiftStartDateTemp;
	    IF(@BatchEndTime IS NOT NULL)
		   BEGIN
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchEndTime
		   END;
	    ELSE
		   BEGIN
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchStartTime
		   END;
	    SELECT @BatchShiftId = ShiftID,
			 @PartitionOn = ShiftStartdate
	    FROM @ShiftStartDateTemp;


	    --Start Getting InjectionCount,StepCount And ProductCount
	    SELECT @StdInjectionSteps = COUNT(tdpm.TunnelDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT tds.TunnelDosingSetupId) -
			 COUNT(tdpm.TunnelDosingSetupId)
	    FROM tcd.TunnelDosingProductMapping tdpm
		    RIGHT JOIN tcd.TunnelDosingSetup tds ON tdpm.
		    TunnelDosingSetupId = tds.TunnelDosingSetupId
	    WHERE tds.GroupId = @WasherGroupID
			AND tds.ProgramNumber = @ProgramNumber;
	    --End Getting InjectionCount,StepCount And ProductCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramID
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT @EcolabTextileCategoryId = pcp. EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp. ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    SELECT @BatchID = NULL;
	    SELECT @BatchID = BatchID
	    FROM TCD.BatchData BD
	    WHERE BD.ControllerBatchId = @BatchNumber
			AND BD.StartDate = @BatchStartTime
			AND BD.MachineId = @WasherID;
	    --AND BD.MachineInternalID = @MachineInternalID
	    IF(@BatchID IS NULL)
		   BEGIN
		   --Start Rollup for previous completed shift
	   IF(CAST(@BatchStartTime as date) < CAST(GETUTCDATE() as date))
	   BEGIN
		  SELECT TOP 1 @PreviousShiftId=ShiftId FROM TCD.BatchData WHERE MachineId=@WasherId ORDER BY StartDate DESC	   
		  SELECT Top 1 @CurrentShiftId = ShiftId from @ShiftStartDateTemp
		  IF(@CurrentShiftId != @PreviousShiftId)
		  BEGIN
			 EXEC TCD.ProductionShiftDataRollup @PreviousShiftId, @RedFlagShiftId OUTPUT
			 IF(@RedFlagShiftId IS NULL)
			 BEGIN
				SET @RedFlagShiftId = @PreviousShiftId
			 END
		  END
	   END
	   --End Rollup for previous completed shift
			  INSERT INTO TCD.BatchData
			  (ControllerBatchId,
			   EcolabWasherId,
			   GroupId,
			   MachineInternalId,
			   PlantWasherNumber,
			   StartDate,
			   EndDate,
			   ProgramNumber,
			   ProgramMasterId,
			   MachineId,
			   ActualWeight,
			   StandardWeight,
			   CurrencyCode,
			   ShiftId,
			   PartitionOn,
			   TargetTurnTime,
			   StdInjectionSteps,
			   StdWashSteps,
			   EcolabTextileCategoryId,
			   ChainTextileCategoryId,
			   FormulaSegmentId,
			   EcolabSaturationId,
			   PlantProgramId,
			   EndDateFormula
			  )
				    SELECT @BatchNumber,
						 @EcolabWasherID,
						 @WasherGroupID,
						 @MachineInternalID,
						 @PlantWasherNumber,
						 @BatchStartTime,
						 @BatchEndTime,
						 @ProgramNumber,
						 @ProgramID,
						 @WasherID,
						 @Load,
						 @NominalLoad,
						 @CurrencyCode,
						 @BatchShiftId,
						 @PartitionOn,
						 @TargetTurnTime,
						 @StdInjectionSteps,
						 @StdWashSteps,
						 @EcolabTextileCategoryId,
						 @ChainTextileCategoryId,
						 @FormulaSegmentId,
						 @EcolabSaturationId,
						 @PlantProgramId,
						 @BatchEndTime;
			  SELECT @BatchID = SCOPE_IDENTITY();
			  IF(@StdWashSteps > 0
				OR @StdWashSteps <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchID,
							@EcolabWasherId,
							38,
							@StdWashSteps,
							@PartitionOn;
			  EXEC TCD.UPDATEBatchWashStepForTunnel
				  @TunnelXML,
				  @WasherID,
				  @BatchID,
				  @BatchStartTime,
				  @PartitionOn,
				  @EcolabWasherId,
				  @NumberOfCompartments;
		   END;
	    IF(@BatchEndTime IS NOT NULL
		  AND @BatchEndTime != '01/01/1900')
		   BEGIN
			  UPDATE TCD.BatchData
			    SET
				   EndDate = @BatchEndTime,
				   ShiftId = @BatchShiftId,
				   PartitionOn = @PartitionOn,
				   EndDateFormula=@BatchEndTime
			  WHERE BATCHID = @BatchID;
		   END;
	    IF(@CustomerNumber IS NOT NULL)
		   BEGIN
			  IF NOT EXISTS
			  (
				 SELECT 1
				 FROM [TCD].[BatchCustomerData]
				 WHERE BatchID = @BatchID
			  )
				 BEGIN
					INSERT INTO [TCD].[BatchCustomerData]
					([BatchId],
					 CustomerID,
					 [Weight],
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @BatchID,
							    @CustomerNumber,
							    @Load,
							    @PartitionOn,
							    @EcolabWasherId;
				 END;
		   END;
	    CREATE TABLE #DosingDetails
	    (
		    Number          INT,
		    Quantity        DECIMAL(10, 6),
		    Point           INT,
		    IsMainEquioment INT
	    );
	    INSERT INTO #DosingDetails
	    (Number,
		Quantity,
		Point,
		IsMainEquioment
	    )
			 SELECT T.c.value('@Number', 'INT') AS Number, --PumpNumber
				   T.c.value('@Quantity', 'Decimal(10,6)') AS Quantity, --Dosing Quanity
				   T.c.value('@Point', 'INT') AS Point, --Dosing point
				   T.c.value('@IsMainEquioment', 'INT') AS
			 IsMainEquioment
			 FROM @xmlTags.nodes('MyControlTunnel/TunnelData/Dose') T(C)
	    ;
	
	    -- Fetching data from cursor
	    DECLARE @MYCURSOR CURSOR;
	    SET @MYCURSOR = CURSOR FAST_FORWARD
	    FOR SELECT Number,
				Quantity,
				Point,
				IsMainEquioment
		   FROM #DosingDetails;
	    DECLARE @Number          INT,
			  @Quantity        DECIMAL(10, 6),
			  @Point           INT,
			  @IsMainEquioment INT;
	    OPEN @MYCURSOR;
	    FETCH NEXT FROM @MYCURSOR INTO @Number,
								@Quantity,
								@Point,
								@IsMainEquioment;
	    WHILE @@FETCH_STATUS = 0
		   BEGIN
			  IF(@IsMainEquioment = 1)
				 BEGIN
					SET @EquipmentType = 2;
				 END;
			  ELSE
				 BEGIN
					SET @EquipmentType = 1;
				 END;
			  SELECT @ProductId = CES.ProductId,
				    @CompartmentNum = TCEVM.CompartmentNumber
			  FROM tcd.ControllerEquipmentSetup CES
				  INNER JOIN TCD.
				  TunnelCompartmentEquipmentValveMapping TCEVM ON CES.
				  ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
			  WHERE CES.ControllerId = @ControllerID
				   AND CES.ControllerEquipmentTypeId = @EquipmentType
				   AND --CES.IsActive=1 AND
				   --CES.WasherGroupNumber=@WasherGroupNum AND
				   TCEVM.DosingPointNumber = @Point
				   AND CES.ControllerEquipmentId = @Number;
				
			  --SELECT @EcolabWasherID
			  IF(@ProductId IS NOT NULL)
				 BEGIN
					INSERT INTO TCD.BatchProductData
					(BatchId,
					 StepCompartment,
					 ActualQuantity,
					 [TimeStamp],
					 PartitionOn,
					 EcolabWasherId,
					 ProductId
					)
						  SELECT @BatchID,
							    @CompartmentNum,
							    @Quantity,
							    @BatchEndTime,
							    @PartitionOn,
							    @EcolabWasherID,
							    @ProductId;
				 END;
			  FETCH NEXT FROM @MYCURSOR INTO @Number,
									   @Quantity,
									   @Point,
									   @IsMainEquioment;
		   END;
	    CLOSE @MYCURSOR;
	    DEALLOCATE @MYCURSOR;
	    DROP TABLE #DosingDetails;
	    SELECT @ActualInjSteps = COUNT(DISTINCT StepCompartment)
	    FROM TCD.BatchProductData
	    WHERE BatchId = @BatchID;
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.BatchParameters
		   WHERE ParameterId = 37
			    AND batchid = @BatchID
			    AND @ActualInjSteps > 0
	    )
		   BEGIN
			  IF(@ActualInjSteps > 0
				OR @ActualInjSteps <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchId,
							@EcolabWasherId,
							37,
							@ActualInjSteps,
							@PartitionOn;
		   END;
	    ELSE
		   BEGIN
			  UPDATE TCD.BatchParameters
			    SET
				   ParameterValue = @ActualInjSteps
			  WHERE ParameterId = 37
				   AND batchid = @BatchID;
		   END;
	    SELECT @MinTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Mimum Temperature';
	    SELECT @MaxTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Maximum Temperature';
	    SELECT @TempStatusParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Temperature Status';
	    SELECT @PHValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH';
	    SELECT @PHStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH Status';
	    SELECT @ConductivityValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Conductivity';
	    SELECT @ConductivityStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'LF Status';
	    IF(@PHValue IS NOT NULL)
		   BEGIN
			  --pH Value
			  IF(@PHValue <> 0
				OR @PHValue <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @PHValueParamID,
					   @PHValue,
					   @PartitionOn
				 );

			  --pH Status
			  IF(@PHStatus <> 0
				OR @PHStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @PHStatusParamID,
					   @PHStatus,
					   @PartitionOn
				 );
		   END;
	    IF(@LFValue IS NOT NULL)
		   BEGIN
			  --Conductivity Value
			  IF(@LFValue <> 0
				OR @LFValue <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @ConductivityValueParamID,
					   @LFValue,
					   @PartitionOn
				 );

			  --Conductivity Status
			  IF(@LFStatus <> 0
				OR @LFStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @ConductivityStatusParamID,
					   @LFStatus,
					   @PartitionOn
				 );
		   END;
	    CREATE TABLE #TemperatureDetails
	    (
		    MinimumTemp DECIMAL(10, 2),
		    MaximumTemp DECIMAL(10, 2),
		    TempStatus  DECIMAL(10, 2)
	    );
	    INSERT INTO #TemperatureDetails
	    (MinimumTemp,
		MaximumTemp,
		TempStatus
	    )
			 SELECT T.c.value('@Minimum', 'Decimal(10,2)') AS
			 MinimumTemp,
				   T.c.value('@Maximum', 'Decimal(10,2)') AS
				   MaximumTemp,
				   T.c.value('@Status', 'Decimal(10,2)') AS TempStatus
			 FROM @xmlTags.nodes(
			 'MyControlTunnel/TunnelData/TemperatureData'
							) T(c);
	  
	    -- Fetching data from cursor
	    DECLARE @TEMPCURSOR CURSOR;
	    SET @TEMPCURSOR = CURSOR FAST_FORWARD
	    FOR SELECT MinimumTemp,
				MaximumTemp,
				TempStatus
		   FROM #TemperatureDetails;
	    DECLARE @MinimumTemp DECIMAL(10, 2),
			  @MaximumTemp DECIMAL(10, 2),
			  @TempStatus  DECIMAL(10, 2);
	    OPEN @TEMPCURSOR;
	    FETCH NEXT FROM @TEMPCURSOR INTO @MinimumTemp,
								  @MaximumTemp,
								  @TempStatus;
	    WHILE @@FETCH_STATUS = 0
		   BEGIN	
			  --Minimum Temperature
			  IF(@MinimumTemp <> 0
				OR @MinimumTemp <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @MinTempParamID,
					   @MinimumTemp,
					   @PartitionOn
				 );

			  --Maximum Temperature
			  IF(@MaximumTemp <> 0
				OR @MaximumTemp <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @MaxTempParamID,
					   @MaximumTemp,
					   @PartitionOn
				 );

			  --Temperature Status
			  IF(@TempStatus <> 0
				OR @TempStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @TempStatusParamID,
					   @TempStatus,
					   @PartitionOn
				 );
			  FETCH NEXT FROM @TEMPCURSOR INTO @MinimumTemp,
										@MaximumTemp,
										@TempStatus;
		   END;
	    CLOSE @TEMPCURSOR;
	    DEALLOCATE @TEMPCURSOR;
	    DROP TABLE #TemperatureDetails;
	    UPDATE TCD.BatchWashStepData
		 SET
			EndTime = @BatchEndTime
	    WHERE BatchId = @BatchID
			AND EndTime IS NULL;

   --Start water consumption per batch

   SELECT @MeterID=MeterId
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@WasherID


    CREATE TABLE #WaterConsumptionData
     (
      Number          INT,
      Quantity        NVARCHAR,
     );
     INSERT INTO #WaterConsumptionData
     (Number,
  Quantity
     )
    SELECT T.c.value('@Counter', 'INT') AS Number, --PumpNumber
       T.c.value('@Value', 'NVARCHAR') AS Quantity --Water Quanity
    FROM @xmlTags.nodes('MyControlTunnel/TunnelData/WaterConsumption') T(C);

  
  SET @CurrentStepComportmentNO=1;
  SET @CounterNo=1
  WHILE(@CurrentStepComportmentNO<=22)
  BEGIN
    SELECT @ActualQuantity=wc.Quantity
  FROM #WaterConsumptionData wc where wc.Number=@CounterNo
  IF NOT EXISTS(SELECT * FROM TCD.BatchStepWaterUsageData WHERE BatchId=@BatchID  AND StepCompartment =@CurrentStepComportmentNO AND ActualQuantity=@ActualQuantity )
  BEGIN
  IF(@BatchID IS NOT NULL AND @MeterID IS NOT NULL)
  BEGIN
  SET @CounterNo=@CounterNo+1;
   INSERT INTO TCD.BatchStepWaterUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
      EcolabWasherId
     )
     SELECT
     @BatchID,
     @CurrentStepComportmentNO,
     @ActualQuantity,
     @PartitionOn,
     @EcolabWasherId
      END 
	  END 
      SET  @CurrentStepComportmentNO=@CurrentStepComportmentNO+1;
   
  END;
 END;

 GO
 if not exists (select * from  [TCD].[AlarmGroupMaster] where AlarmGroupMasterId=641) 
 BEGIN
 --Tunnel
  INSERT INTO TCD.AlarmGroupMaster(AlarmGroupMasterId,DESCRIPTION,ResourceKey,IsDelete,IsHoldCondition,LastModifiedTime,WasherType)
 values(641,'Low level P15','FIELD_ALARM_148_myControl(Beckhoff)',0,1,GETUTCDATE(),'T')
 END
 GO
  if not exists (select * from  [TCD].[AlarmGroupMaster] where AlarmGroupMasterId=642) 
 BEGIN
  INSERT INTO TCD.AlarmGroupMaster(AlarmGroupMasterId,DESCRIPTION,ResourceKey,IsDelete,IsHoldCondition,LastModifiedTime,WasherType)
 values(642,'Low level P16','FIELD_ALARM_149_myControl(Beckhoff)',0,1,GETUTCDATE(),'T')
 END
 GO
  if not exists (select * from  [TCD].[AlarmGroupMaster] where AlarmGroupMasterId=643) 
 BEGIN
 INSERT INTO TCD.AlarmGroupMaster(AlarmGroupMasterId,DESCRIPTION,ResourceKey,IsDelete,IsHoldCondition,LastModifiedTime,WasherType)
 values(643,'Low level P17','FIELD_ALARM_150_myControl(Beckhoff)',0,1,GETUTCDATE(),'T')
 END
 GO
  if not exists (select * from  [TCD].[AlarmGroupMaster] where AlarmGroupMasterId=644) 
 BEGIN
 INSERT INTO TCD.AlarmGroupMaster(AlarmGroupMasterId,DESCRIPTION,ResourceKey,IsDelete,IsHoldCondition,LastModifiedTime,WasherType)
 values(644,'Low level P18','FIELD_ALARM_151_myControl(Beckhoff)',0,1,GETUTCDATE(),'T')
 END
 GO
  if not exists (select * from  [TCD].[AlarmGroupMaster] where AlarmGroupMasterId=645) 
 BEGIN
  INSERT INTO TCD.AlarmGroupMaster(AlarmGroupMasterId,DESCRIPTION,ResourceKey,IsDelete,IsHoldCondition,LastModifiedTime,WasherType)
 values(645,'Low level P19','FIELD_ALARM_152_myControl(Beckhoff)',0,1,GETUTCDATE(),'T')
 END
 GO
  if not exists (select * from  [TCD].[AlarmGroupMaster] where AlarmGroupMasterId=646) 
 BEGIN
   INSERT INTO TCD.AlarmGroupMaster(AlarmGroupMasterId,DESCRIPTION,ResourceKey,IsDelete,IsHoldCondition,LastModifiedTime,WasherType)
 values(646,'Low level P20','FIELD_ALARM_153_myControl(Beckhoff)',0,1,GETUTCDATE(),'T')
 END
 GO
  if not exists (select * from  [TCD].[AlarmGroupMaster] where AlarmGroupMasterId=647) 
 BEGIN
   INSERT INTO TCD.AlarmGroupMaster(AlarmGroupMasterId,DESCRIPTION,ResourceKey,IsDelete,IsHoldCondition,LastModifiedTime,WasherType)
 values(647,'Low level P21','FIELD_ALARM_154_myControl(Beckhoff)',0,1,GETUTCDATE(),'T')
 END
 GO
  if not exists (select * from  [TCD].[AlarmGroupMaster] where AlarmGroupMasterId=648) 
 BEGIN
   INSERT INTO TCD.AlarmGroupMaster(AlarmGroupMasterId,DESCRIPTION,ResourceKey,IsDelete,IsHoldCondition,LastModifiedTime,WasherType)
 values(648,'Low level P22','FIELD_ALARM_155_myControl(Beckhoff)',0,1,GETUTCDATE(),'T')
 END
 GO
  if not exists (select * from  [TCD].[AlarmGroupMaster] where AlarmGroupMasterId=649) 
 BEGIN
   INSERT INTO TCD.AlarmGroupMaster(AlarmGroupMasterId,DESCRIPTION,ResourceKey,IsDelete,IsHoldCondition,LastModifiedTime,WasherType)
 values(649,'Low level P23','FIELD_ALARM_156_myControl(Beckhoff)',0,1,GETUTCDATE(),'T')
 END
 GO
  if not exists (select * from  [TCD].[AlarmGroupMaster] where AlarmGroupMasterId=650) 
 BEGIN
   INSERT INTO TCD.AlarmGroupMaster(AlarmGroupMasterId,DESCRIPTION,ResourceKey,IsDelete,IsHoldCondition,LastModifiedTime,WasherType)
 values(650,'Low level P24','FIELD_ALARM_157_myControl(Beckhoff)',0,1,GETUTCDATE(),'T')
 END
 GO
--Conventional
 if not exists (select * from  [TCD].[AlarmGroupMaster] where AlarmGroupMasterId=651) 
 BEGIN
  INSERT INTO TCD.AlarmGroupMaster(AlarmGroupMasterId,DESCRIPTION,ResourceKey,IsDelete,IsHoldCondition,LastModifiedTime,WasherType)
 values(651,'Low level P15','FIELD_ALARM_148_myControl(Beckhoff)',0,1,GETUTCDATE(),'C')
 END
 GO
  if not exists (select * from  [TCD].[AlarmGroupMaster] where AlarmGroupMasterId=652) 
 BEGIN
  INSERT INTO TCD.AlarmGroupMaster(AlarmGroupMasterId,DESCRIPTION,ResourceKey,IsDelete,IsHoldCondition,LastModifiedTime,WasherType)
 values(652,'Low level P16','FIELD_ALARM_149_myControl(Beckhoff)',0,1,GETUTCDATE(),'C')
 END
 GO
  if not exists (select * from  [TCD].[AlarmGroupMaster] where AlarmGroupMasterId=653) 
 BEGIN
 INSERT INTO TCD.AlarmGroupMaster(AlarmGroupMasterId,DESCRIPTION,ResourceKey,IsDelete,IsHoldCondition,LastModifiedTime,WasherType)
 values(653,'Low level P17','FIELD_ALARM_150_myControl(Beckhoff)',0,1,GETUTCDATE(),'C')
 END
 GO
  if not exists (select * from  [TCD].[AlarmGroupMaster] where AlarmGroupMasterId=654) 
 BEGIN
 INSERT INTO TCD.AlarmGroupMaster(AlarmGroupMasterId,DESCRIPTION,ResourceKey,IsDelete,IsHoldCondition,LastModifiedTime,WasherType)
 values(654,'Low level P18','FIELD_ALARM_151_myControl(Beckhoff)',0,1,GETUTCDATE(),'C')
 END
 GO
  if not exists (select * from  [TCD].[AlarmGroupMaster] where AlarmGroupMasterId=655) 
 BEGIN
  INSERT INTO TCD.AlarmGroupMaster(AlarmGroupMasterId,DESCRIPTION,ResourceKey,IsDelete,IsHoldCondition,LastModifiedTime,WasherType)
 values(655,'Low level P19','FIELD_ALARM_152_myControl(Beckhoff)',0,1,GETUTCDATE(),'C')
 END
 GO
  if not exists (select * from  [TCD].[AlarmGroupMaster] where AlarmGroupMasterId=656) 
 BEGIN
   INSERT INTO TCD.AlarmGroupMaster(AlarmGroupMasterId,DESCRIPTION,ResourceKey,IsDelete,IsHoldCondition,LastModifiedTime,WasherType)
 values(656,'Low level P20','FIELD_ALARM_153_myControl(Beckhoff)',0,1,GETUTCDATE(),'C')
 END
 GO
  if not exists (select * from  [TCD].[AlarmGroupMaster] where AlarmGroupMasterId=657) 
 BEGIN
   INSERT INTO TCD.AlarmGroupMaster(AlarmGroupMasterId,DESCRIPTION,ResourceKey,IsDelete,IsHoldCondition,LastModifiedTime,WasherType)
 values(657,'Low level P21','FIELD_ALARM_154_myControl(Beckhoff)',0,1,GETUTCDATE(),'C')
 END
 GO
  if not exists (select * from  [TCD].[AlarmGroupMaster] where AlarmGroupMasterId=658) 
 BEGIN
   INSERT INTO TCD.AlarmGroupMaster(AlarmGroupMasterId,DESCRIPTION,ResourceKey,IsDelete,IsHoldCondition,LastModifiedTime,WasherType)
 values(658,'Low level P22','FIELD_ALARM_155_myControl(Beckhoff)',0,1,GETUTCDATE(),'C')
 END
 GO
  if not exists (select * from  [TCD].[AlarmGroupMaster] where AlarmGroupMasterId=659) 
 BEGIN
 
   INSERT INTO TCD.AlarmGroupMaster(AlarmGroupMasterId,DESCRIPTION,ResourceKey,IsDelete,IsHoldCondition,LastModifiedTime,WasherType)
 values(659,'Low level P23','FIELD_ALARM_156_myControl(Beckhoff)',0,1,GETUTCDATE(),'C')
 END
 GO
  if not exists (select * from  [TCD].[AlarmGroupMaster] where AlarmGroupMasterId=660) 
 BEGIN
   INSERT INTO TCD.AlarmGroupMaster(AlarmGroupMasterId,DESCRIPTION,ResourceKey,IsDelete,IsHoldCondition,LastModifiedTime,WasherType)
 values(660,'Low level P24','FIELD_ALARM_157_myControl(Beckhoff)',0,1,GETUTCDATE(),'C')
 END

 GO
 ---AlarmGroupMsterVsControllerModelType Mater data for COnventional and tunnel

  if not exists (select * from  [TCD].[AlarmGroupMsterVsControllerModelType] where AlarmGroupMsterVsControllerModelTypeId=874) 
 BEGIN
 
 INSERT INTO tcd.AlarmGroupMsterVsControllerModelType(AlarmGroupMsterVsControllerModelTypeId,AlarmCode,ControllerModelTypeId,IsDefault,IsDelete,AlarmGroupMasterId)
 values(874,148,10,0,0,641)
 END
 GO
   if not exists (select * from  [TCD].[AlarmGroupMsterVsControllerModelType] where AlarmGroupMsterVsControllerModelTypeId=875) 
 BEGIN
 
 INSERT INTO tcd.AlarmGroupMsterVsControllerModelType(AlarmGroupMsterVsControllerModelTypeId,AlarmCode,ControllerModelTypeId,IsDefault,IsDelete,AlarmGroupMasterId)
 values(875,149,10,0,0,642)
 END

 GO
   if not exists (select * from  [TCD].[AlarmGroupMsterVsControllerModelType] where AlarmGroupMsterVsControllerModelTypeId=876) 
 BEGIN
 
 INSERT INTO tcd.AlarmGroupMsterVsControllerModelType(AlarmGroupMsterVsControllerModelTypeId,AlarmCode,ControllerModelTypeId,IsDefault,IsDelete,AlarmGroupMasterId)
 values(876,150,10,0,0,643)
 END

  GO
   if not exists (select * from  [TCD].[AlarmGroupMsterVsControllerModelType] where AlarmGroupMsterVsControllerModelTypeId=877) 
 BEGIN
 
 INSERT INTO tcd.AlarmGroupMsterVsControllerModelType(AlarmGroupMsterVsControllerModelTypeId,AlarmCode,ControllerModelTypeId,IsDefault,IsDelete,AlarmGroupMasterId)
 values(877,151,10,0,0,644)
 END
   GO
   if not exists (select * from  [TCD].[AlarmGroupMsterVsControllerModelType] where AlarmGroupMsterVsControllerModelTypeId=878) 
 BEGIN
 
 INSERT INTO tcd.AlarmGroupMsterVsControllerModelType(AlarmGroupMsterVsControllerModelTypeId,AlarmCode,ControllerModelTypeId,IsDefault,IsDelete,AlarmGroupMasterId)
 values(878,152,10,0,0,645)
 END
   GO
   if not exists (select * from  [TCD].[AlarmGroupMsterVsControllerModelType] where AlarmGroupMsterVsControllerModelTypeId=879) 
 BEGIN
 
 INSERT INTO tcd.AlarmGroupMsterVsControllerModelType(AlarmGroupMsterVsControllerModelTypeId,AlarmCode,ControllerModelTypeId,IsDefault,IsDelete,AlarmGroupMasterId)
 values(879,153,10,0,0,646)
 END

   GO
   if not exists (select * from  [TCD].[AlarmGroupMsterVsControllerModelType] where AlarmGroupMsterVsControllerModelTypeId=880) 
 BEGIN
 
 INSERT INTO tcd.AlarmGroupMsterVsControllerModelType(AlarmGroupMsterVsControllerModelTypeId,AlarmCode,ControllerModelTypeId,IsDefault,IsDelete,AlarmGroupMasterId)
 values(880,154,10,0,0,647)
 END
    GO
   if not exists (select * from  [TCD].[AlarmGroupMsterVsControllerModelType] where AlarmGroupMsterVsControllerModelTypeId=881) 
 BEGIN
 
 INSERT INTO tcd.AlarmGroupMsterVsControllerModelType(AlarmGroupMsterVsControllerModelTypeId,AlarmCode,ControllerModelTypeId,IsDefault,IsDelete,AlarmGroupMasterId)
 values(881,155,10,0,0,648)
 END

   GO
   if not exists (select * from  [TCD].[AlarmGroupMsterVsControllerModelType] where AlarmGroupMsterVsControllerModelTypeId=882) 
 BEGIN
 
 INSERT INTO tcd.AlarmGroupMsterVsControllerModelType(AlarmGroupMsterVsControllerModelTypeId,AlarmCode,ControllerModelTypeId,IsDefault,IsDelete,AlarmGroupMasterId)
 values(882,156,10,0,0,649)
 END
   GO
   if not exists (select * from  [TCD].[AlarmGroupMsterVsControllerModelType] where AlarmGroupMsterVsControllerModelTypeId=883) 
 BEGIN
 
 INSERT INTO tcd.AlarmGroupMsterVsControllerModelType(AlarmGroupMsterVsControllerModelTypeId,AlarmCode,ControllerModelTypeId,IsDefault,IsDelete,AlarmGroupMasterId)
 values(883,157,10,0,0,650)
 END

   GO
   if not exists (select * from  [TCD].[AlarmGroupMsterVsControllerModelType] where AlarmGroupMsterVsControllerModelTypeId=884) 
 BEGIN
 
 INSERT INTO tcd.AlarmGroupMsterVsControllerModelType(AlarmGroupMsterVsControllerModelTypeId,AlarmCode,ControllerModelTypeId,IsDefault,IsDelete,AlarmGroupMasterId)
 values(884,148,10,0,0,651)
 END

   GO
   if not exists (select * from  [TCD].[AlarmGroupMsterVsControllerModelType] where AlarmGroupMsterVsControllerModelTypeId=885) 
 BEGIN
 
 INSERT INTO tcd.AlarmGroupMsterVsControllerModelType(AlarmGroupMsterVsControllerModelTypeId,AlarmCode,ControllerModelTypeId,IsDefault,IsDelete,AlarmGroupMasterId)
 values(885,149,10,0,0,652)
 END

  GO
   if not exists (select * from  [TCD].[AlarmGroupMsterVsControllerModelType] where AlarmGroupMsterVsControllerModelTypeId=886) 
 BEGIN
 
 INSERT INTO tcd.AlarmGroupMsterVsControllerModelType(AlarmGroupMsterVsControllerModelTypeId,AlarmCode,ControllerModelTypeId,IsDefault,IsDelete,AlarmGroupMasterId)
 values(886,150,10,0,0,653)
 END

  GO
   if not exists (select * from  [TCD].[AlarmGroupMsterVsControllerModelType] where AlarmGroupMsterVsControllerModelTypeId=887) 
 BEGIN
 
 INSERT INTO tcd.AlarmGroupMsterVsControllerModelType(AlarmGroupMsterVsControllerModelTypeId,AlarmCode,ControllerModelTypeId,IsDefault,IsDelete,AlarmGroupMasterId)
 values(887,151,10,0,0,654)
 END
  GO
   if not exists (select * from  [TCD].[AlarmGroupMsterVsControllerModelType] where AlarmGroupMsterVsControllerModelTypeId=888) 
 BEGIN
 
 INSERT INTO tcd.AlarmGroupMsterVsControllerModelType(AlarmGroupMsterVsControllerModelTypeId,AlarmCode,ControllerModelTypeId,IsDefault,IsDelete,AlarmGroupMasterId)
 values(888,152,10,0,0,655)
 END
   GO
   if not exists (select * from  [TCD].[AlarmGroupMsterVsControllerModelType] where AlarmGroupMsterVsControllerModelTypeId=889) 
 BEGIN
 
 INSERT INTO tcd.AlarmGroupMsterVsControllerModelType(AlarmGroupMsterVsControllerModelTypeId,AlarmCode,ControllerModelTypeId,IsDefault,IsDelete,AlarmGroupMasterId)
 values(889,153,10,0,0,656)
 END
   GO
   if not exists (select * from  [TCD].[AlarmGroupMsterVsControllerModelType] where AlarmGroupMsterVsControllerModelTypeId=890) 
 BEGIN
 
 INSERT INTO tcd.AlarmGroupMsterVsControllerModelType(AlarmGroupMsterVsControllerModelTypeId,AlarmCode,ControllerModelTypeId,IsDefault,IsDelete,AlarmGroupMasterId)
 values(890,154,10,0,0,657)
 END
    GO
   if not exists (select * from  [TCD].[AlarmGroupMsterVsControllerModelType] where AlarmGroupMsterVsControllerModelTypeId=891) 
 BEGIN
 
 INSERT INTO tcd.AlarmGroupMsterVsControllerModelType(AlarmGroupMsterVsControllerModelTypeId,AlarmCode,ControllerModelTypeId,IsDefault,IsDelete,AlarmGroupMasterId)
 values(891,155,10,0,0,658)
 END
    GO
   if not exists (select * from  [TCD].[AlarmGroupMsterVsControllerModelType] where AlarmGroupMsterVsControllerModelTypeId=892) 
 BEGIN
 
 INSERT INTO tcd.AlarmGroupMsterVsControllerModelType(AlarmGroupMsterVsControllerModelTypeId,AlarmCode,ControllerModelTypeId,IsDefault,IsDelete,AlarmGroupMasterId)
 values(892,156,10,0,0,659)
 END
    GO
   if not exists (select * from  [TCD].[AlarmGroupMsterVsControllerModelType] where AlarmGroupMsterVsControllerModelTypeId=893) 
 BEGIN
 
 INSERT INTO tcd.AlarmGroupMsterVsControllerModelType(AlarmGroupMsterVsControllerModelTypeId,AlarmCode,ControllerModelTypeId,IsDefault,IsDelete,AlarmGroupMasterId)
 values(893,157,10,0,0,660)
 END
 GO
------------------- Start 144481	RW:H:Mycontrol : Standard quantity and Price are showing null in batch product data	TODO------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlConventionalData_CompletedBatches]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlConventionalData_CompletedBatches]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessMyControlConventionalData_CompletedBatches](
	@ControllerID   INT,
	@VxML           XML,
	@PLCPointer     INT,
	@ReadPointer    INT,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @MachineNumber           INT,
			  @StartDateTime           DATETIME,
			  @EndDateTime             DATETIME,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @PHValue                 INT,
			  @TemperatureMin          INT,
			  @TemperatureMax          INT,
			  @TempMinStatus           INT,
			  @TempMaxStatus           INT,
			  @BatchNumber             INT,
			  @WasherID                INT,
			  @WasherGroupID           INT,
			  @EcoLabWasherID          INT,
			  @ProgramMasterID         INT,
			  @PlantWasherNumber       INT,
			  @ShiftID                 INT,
			  @BatchID                 INT,
			  @ShiftStartdate          DATETIME,
			  @LastStep                INT,
			  @CurrentStep             INT,
			  @CurrentStepTime         DATETIME,
			  @MinTempParamID          INT,
			  @MaxTempParamID          INT,
			  @MinTempStatuParamID     INT,
			  @MaxTempStatusParamID    INT,
			  @PHStatusParamID         INT,
			  @PHValueParamID          INT,
			  @CurrencyCode            VARCHAR(50),
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @ActualInjSteps          INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @TargetTurnTime          INT,
			  @PreviousShiftId         INT,
			  @CurrentShiftId          INT,
			  @MeterID                 INT,
			  @StepComportment         INT,
			  @WaterConsumption1       INT,
			  @WaterConsumption2       INT,
			  @Stepno                  INT,
			  @quantity                INT,
			  @productid               INT,
			  @Price                   DECIMAL(18, 4),
			  @StandardQty             DECIMAL(18, 4),
			  @TimeStamp               DATETIME2(7),
			  @MaxWashertGroupCapacity INT,
			  @InjectionNumber         INT;
	    SELECT
			 @MachineNumber = T.c.value('@MachineNumber', 'INT'),
			 @StartDateTime = T.c.value('@StartDateTime', 'DateTime'),
			 @EndDateTime = T.c.value('@EndDateTime', 'DateTime'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@NominalLoad', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'INT'),
			 @PHStatus = T.c.value('@PHStatus', 'INT'),
			 @PHValue = T.c.value('@PHValue', 'INT'),
			 @TemperatureMin = T.c.value('@TemperatureMin', 'INT'),
			 @TemperatureMax = T.c.value('@TemperatureMax', 'INT'),
			 @TempMaxStatus = T.c.value('@TemperatureMaxStatus', 'INT'),
			 @TempMinStatus = T.c.value('@TemperatreMinStatus', 'INT'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @WaterConsumption1 = T.c.value('@WaterConsumption1',
			 'NVARCHAR'
									 ),
			 @WaterConsumption2 = T.c.value('@WaterConsumption2',
			 'NVARCHAR'
									 )
	    FROM @VxML.nodes('MyControlConventionalData') T(C);
	    DECLARE @ShiftMapping TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    INSERT INTO @ShiftMapping
	    (
			 ShiftId,
			 ShiftName,
			 ShiftStartdate
	    )
	    EXEC TCD.GetShiftStartDate
		    @StartDateTime;
	    SELECT
			 @ShiftID = ShiftID,
			 @ShiftStartdate = ShiftStartdate
	    FROM @ShiftMapping;
	    SELECT
			 @WasherGroupID = GroupId,
			 @WasherID = WasherID
	    FROM TCD.MachineSetup ms
	    WHERE ControllerID = @ControllerID
			AND MachineInternalId = @MachineNumber
			AND IsTunnel = 0
			AND IsDeleted = 0;
	    IF(@WasherId IS NOT NULL)
		   BEGIN
			  SELECT
				    @ProgramMasterId = Wps.ProgramId
			  FROM TCD.Washer Ws
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws
				  .WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =
				  Mst.GroupId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.
				  ControllerID = Wg.ControllerId
				  INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber =
				  Ws.EcoLabAccountNumber
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wps.Is_Deleted = 0;
			  SELECT
				    @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber,
				    @CurrencyCode = P.CurrencyCode,
				    @TargetTurnTime = w.TargetTurnTime * 60
			  FROM TCD.Washer w
				  INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.
				  EcolabAccountNumber
			  WHERE w.WasherId = @WasherID;
		   END;
	    SELECT
			 @BatchID = BatchID
	    FROM TCD.BatchData
	    WHERE MachineInternalID = @MachineNumber
			AND StartDate = @StartDateTime
			AND ControllerBatchId = @BatchNumber
			AND MachineID = @WasherID;

	    --Start Getting InjectionCount and StepCount

	    SELECT
			 @StdInjectionSteps = COUNT(DISTINCT wdpm.
			 WasherDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) -
			 COUNT(DISTINCT wdpm.WasherDosingSetupId)
	    FROM TCD.WasherDosingProductMapping wdpm
		    RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm.
		    WasherDosingSetupId = wds.WasherDosingSetupId
	    WHERE wds.ControllerID = @ControllerID
			AND wds.ProgramNumber = @ProgramNumber;

	    --End Getting InjectionCount and StepCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT
			 @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramMasterId
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT
				    @EcolabTextileCategoryId = pcp.
				    EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp.
				    ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    IF(@BatchID IS NULL)
		   BEGIN

			  --Start Rollup for previous completed shift
			  IF(CAST(@StartDateTime AS DATE) < CAST(GETUTCDATE() AS
			  DATE))
				 BEGIN
					SELECT TOP 1
						  @PreviousShiftId = ShiftId
					FROM TCD.BatchData
					WHERE MachineId = @WasherId
					ORDER BY
						    StartDate DESC;
					SELECT TOP 1
						  @CurrentShiftId = ShiftId
					FROM @ShiftMapping;
					IF(@CurrentShiftId != @PreviousShiftId)
					    BEGIN
						   EXEC TCD.ProductionShiftDataRollup
							   @PreviousShiftId,
							   @RedFlagShiftId OUTPUT;
						   IF(@RedFlagShiftId IS NULL)
							  BEGIN
								 SET @RedFlagShiftId =
								 @PreviousShiftId;
							  END;
					    END;
				 END;
			  --End Rollup for previous completed shift

			  INSERT INTO TCD.BatchData
			  (
				    ControllerBatchID,
				    EcolabWasherId,
				    GroupId,
				    MachineInternalId,
				    PlantWasherNumber,
				    StartDate,
				    EndDate,
				    ProgramNumber,
				    ProgramMasterId,
				    MachineID,
				    ActualWeight,
				    StandardWeight,
				    CurrencyCode,
				    ShiftId,
				    PartitionOn,
				    StdInjectionSteps,
				    StdWashSteps,
				    EcolabTextileCategoryId,
				    ChainTextileCategoryId,
				    FormulaSegmentId,
				    EcolabSaturationId,
				    PlantProgramId,
				    EndDateFormula,
				    TargetTurnTime
			  )
			  VALUES
			  (
				    @BatchNumber,
				    @EcoLabWasherID,
				    @WasherGroupID,
				    @MachineNumber,
				    @PlantWasherNumber,
				    @StartDateTime,
				    @EndDateTime,
				    @ProgramNumber,
				    @ProgramMasterId,
				    @WasherID,
				    @Load,
				    @NominalLoad,
				    @CurrencyCode,
				    @ShiftID,
				    @ShiftStartdate,
				    @StdInjectionSteps,
				    @StdWashSteps,
				    @EcolabTextileCategoryId,
				    @ChainTextileCategoryId,
				    @FormulaSegmentId,
				    @EcolabSaturationId,
				    @PlantProgramId,
				    @EndDateTime,
				    @TargetTurnTime
			  );
			  SELECT
				    @BatchID = SCOPE_IDENTITY();
			  IF NOT EXISTS
			  (
				 SELECT
					   *
				 FROM TCD.BatchParameters
				 WHERE BatchId = @BatchID
					  AND ParameterID = 38
			  )
				 BEGIN
					IF(@StdWashSteps > 0
					   OR @StdWashSteps <> NULL)
					    INSERT INTO TCD.BatchParameters
					    (
							 BatchId,
							 EcolabWasherId,
							 ParameterId,
							 ParameterValue,
							 PartitionOn
					    )
					    SELECT
							 @BatchID,
							 @EcoLabWasherID,
							 38,
							 @StdWashSteps,
							 @ShiftStartdate;
				 END;
		   END;
	    ELSE
		   BEGIN
			  UPDATE tcd.BatchData
			    SET
				   EndDate = @EndDateTime,
				   EndDateFormula = @EndDateTime,
				   ProgramNumber = @ProgramNumber,
				   ProgramMasterId = @ProgramMasterID,
				   ActualWeight = @Load,
				   SyncReady = 1
			  WHERE
				   BatchID = @BatchID;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				1
		   FROM [TCD].[BatchCustomerData]
		   WHERE BatchID = @BatchId
			    AND @CustomerNumber IS NOT NULL
	    )
		   BEGIN
			  INSERT INTO [TCD].[BatchCustomerData]
			  (
				    [BatchId],
				    CustomerID,
				    [Weight],
				    PartitionOn,
				    EcolabWasherId
			  )
			  VALUES
			  (
				    @BatchID,
				    @CustomerNumber,
				    @Load,
				    @ShiftStartdate,
				    @EcolabWasherID
			  );
		   END;
	    ELSE
	    IF(@CustomerNumber > 0)
		   BEGIN
			  UPDATE [TCD].[BatchCustomerData]
			    SET
				   CustomerID = @CustomerNumber,
				   [Weight] = @Load
			  WHERE
				   BatchID = @BatchId;
		   END;
	    CREATE TABLE #Dosing
	    (
		    equipmentNo INT,
		    StepNo      INT,
		    Qty         DECIMAL(10, 6)
	    );
	    INSERT INTO #Dosing
	    SELECT
			 T.c.value('@Equipment', 'INT'),
			 T.c.value('@stepNo', 'INT'),
			 T.c.value('@Qty', 'Decimal(10,6)')
	    FROM @VxML.nodes('MyControlConventionalData/DosingData/Dosing') T
	    (C)
	    WHERE T.c.value('@Qty', 'Decimal(10,6)') > 0;
	    CREATE TABLE #StepTime
	    (
		    Number    INT,
		    [Time]    INT,
		    StartTime DATETIME,
		    EndTime   DATETIME
	    );
	    INSERT INTO #StepTime
	    (
			 Number,
			 [Time]
	    )
	    SELECT
			 T.c.value('@Number', 'INT'),
			 T.c.value('@Time', 'INT')
	    FROM @VxML.nodes('MyControlConventionalData/StepTime/Step') T(C);
	    CREATE TABLE #TimeStamp
	    (
		    Step_Number INT,
		    Time_Stamp  INT
	    );
	
	    --For Calculating TIME_STAMP

	    WITH TempTable
		    AS (SELECT DISTINCT
					Number
			   FROM #StepTime)
		    INSERT INTO #TimeStamp
		    (
				 Step_Number,
				 Time_Stamp
		    )
		    SELECT
				 b.Number,
				 SUM(t.Time) Time_Stamp
		    FROM TempTable b
			    INNER JOIN #StepTime t ON b.Number >= t.Number
		    GROUP BY
				   b.Number;
	    CREATE TABLE #BatchProductData
	    (
		    equipmentNo INT,
		    StepNo      INT,
		    Qty         DECIMAL(10, 6),
		    Time_Stamp  DATETIME2(7),
		    ProductId   INT,
		    Row_No      INT
	    );
	    INSERT INTO #BatchProductData
	    (
			 EquipmentNo,
			 StepNo,
			 Qty,
			 Time_Stamp,
			 ProductId,
			 Row_No
	    )
	    SELECT
			 d.equipmentNo,
			 d.StepNo,
			 d.Qty,
			 DATEADD(ss, ts.Time_Stamp, @StartDateTime),
			 ces.ProductId,
			 ROW_NUMBER() OVER(ORDER BY d.StepNo DESC) AS Row
	    FROM #Dosing d
		    INNER JOIN #TimeStamp ts ON d.StepNo = ts.Step_Number
		    INNER JOIN tcd.ControllerEquipmentSetup ces ON ces.
		    ControllerEquipmentId = d.equipmentNo
	    WHERE d.equipmentNo > 0
			AND d.Qty > 0
			AND ControllerID = @ControllerID
			AND ces.ProductId IS NOT NULL;
	    SELECT
			 @MaxWashertGroupCapacity = MAX(ws.MaxLoad)
	    FROM TCD.Washer WS
		    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.
		    GroupId
	    WHERE Mst.GroupId = @WasherGroupID;
	    DECLARE @Counter INT;
	    SET @counter = 1;
	    WHILE(@counter <=
		    (
			   SELECT
					COUNT(ROW_No)
			   FROM #BatchProductData bpd
		    ))
		   BEGIN
			  SELECT
				    @stepno = bpd.StepNo,
				    @quantity = bpd.Qty,
				    @productid = bpd.ProductId,
				    @timestamp = bpd.Time_Stamp
			  FROM #BatchProductData bpd
			  WHERE bpd.Row_No = @counter
			  ORDER BY
					 bpd.StepNo;
			  SELECT
				    @InjectionNumber = Wdpm.InjectionNumber,
				    @standardqty = ((@NominalLoad / CONVERT( DECIMAL(
				    10, 2), 100)) * Wdpm.Quantity * Ws.MaxLoad) /
				    CONVERT(DECIMAL(10, 2), 100),
				    @price = ((@NominalLoad / CONVERT(       DECIMAL(
				    10, 2), 100)) * Wdpm.Quantity *
				    @MaxWashertGroupCapacity) / CONVERT(DECIMAL(10, 2),
				    100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID)
			  FROM TCD.Washer WS
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws
				  .WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =
				  Mst.GroupId
				  INNER JOIN TCD.WasherGroupType WgT ON WgT.
				  WasherGroupTypeId = Wg.WasherGroupTypeId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.
				  ControllerID = Wg.ControllerId
				  INNER JOIN TCD.WasherDosingSetup Wds ON Wds.
				  WasherProgramSetupId = Wps.WasherProgramSetupId
				  INNER JOIN TCD.WasherDosingProductMapping Wdpm ON
				  Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
				  INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.
				  ProductId = Wdpm.ProductId
				  INNER JOIN TCD.BatchData Bd ON Bd.MachineId = Ws.
				  WasherId
			  WHERE Ws.WasherId = @WasherID
				   AND Wps.ProgramNumber = @ProgramNumber
				   --AND Wdpm.InjectionNumber = @stepno
				   AND Bd.BatchId = @BatchID
				   AND Wps.Is_Deleted = 0
				   AND Pdm.Is_Deleted = 0;
			  INSERT INTO TCD.BatchProductData
			  (
				    BatchId,
				    StepCompartment,
				    ActualQuantity,
				    StandardQuantity,
				    Price,
				    PartitionOn,
				    EcolabWasherId,
				    ProductId,
				    TimeStamp,
				    InjectionNumber
			  )
			  VALUES
			  (
				    @BatchID,
				    @stepno,
				    @quantity,
				    @standardqty,
				    @price,
				    @ShiftStartdate,
				    @EcolabWasherId,
				    @productid,
				    @timestamp,
				    @InjectionNumber
			  );
			  SET @counter = @counter + 1;
		   END;
	    --END For calculating TIMESTAMP
	    --Start Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
	    SELECT
			 @ActualInjSteps = COUNT(DISTINCT StepNo)
	    FROM #Dosing;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE ParameterId = 37
			    AND batchid = @BatchID
			    AND @ActualInjSteps > 0
	    )
		   BEGIN
			  IF(@ActualInjSteps > 0
				OR @ActualInjSteps IS NOT NULL)
				 INSERT INTO TCD.BatchParameters
				 (
					   BatchId,
					   EcolabWasherId,
					   ParameterId,
					   ParameterValue,
					   PartitionOn
				 )
				 SELECT
					   @BatchId,
					   @EcolabWasherId,
					   37,
					   @ActualInjSteps,
					   @ShiftStartDate;
		   END;
	    ELSE
		   BEGIN
			  UPDATE TCD.BatchParameters
			    SET
				   ParameterValue = @ActualInjSteps
			  WHERE
				   ParameterId = 37
				   AND batchid = @BatchID;
		   END;
	    SELECT
			 @LastStep = MAX([Number])
	    FROM #StepTime
	    WHERE [Time] > 0;
	    SELECT
			 @CurrentStep = 1,
			 @CurrentStepTime = @StartDateTime;
	    WHILE(@CurrentStep <= @LastStep)
		   BEGIN
			  UPDATE #StepTime
			    SET
				   StartTime = @CurrentStepTime,
				   EndTime = DATEADD(ss, [time], @CurrentStepTime)
			  WHERE
				   Number = @CurrentStep;
			  SELECT
				    @CurrentStepTime = EndTime
			  FROM #StepTime
			  WHERE Number = @CurrentStep;
			  SELECT
				    @CurrentStep = @CurrentStep + 1;
		   END;
	    INSERT INTO [TCD].[BatchWashStepData]
	    (
			 BatchID,
			 StepCompartment,
			 StartTime,
			 EndTime,
			 PartitionOn,
			 EcolabWasherId
	    )
	    SELECT
			 @BatchID,
			 Number,
			 StartTime,
			 EndTime,
			 @ShiftStartdate,
			 @EcoLabWasherID
	    FROM #StepTime
	    WHERE Number <= @LastStep;
	    SELECT
			 @MinTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Mimum Temperature';
	    SELECT
			 @MaxTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Maximum Temperature';
	    SELECT
			 @MaxTempStatusParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Max Temperature Status';
	    SELECT
			 @MinTempStatuParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Minimum Temperature Status';
	    SELECT
			 @PHValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH';
	    SELECT
			 @PHStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH Status';
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MinTempParamID
	    )
		   BEGIN
			  IF(@TemperatureMin <> 0
				OR @TemperatureMin <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MinTempParamID,
						  @TemperatureMin,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MaxTempParamID
	    )
		   BEGIN
			  IF(@TemperatureMax <> 0
				OR @TemperatureMax <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MaxTempParamID,
						  @TemperatureMax,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MaxTempStatusParamID
	    )
		   BEGIN
			  IF(@TempMaxStatus <> 0
				OR @TempMaxStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MaxTempStatusParamID,
						  @TempMaxStatus,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MinTempStatuParamID
	    )
		   BEGIN
			  IF(@TempMinStatus <> 0
				OR @TempMinStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MinTempStatuParamID,
						  @TempMinStatus,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF(@PHStatus <> 0
		  OR @PHStatus <> NULL)
		   BEGIN
			  INSERT INTO TCD.BatchParameters
			  (
				    BatchId,
				    EcolabWasherId,
				    ParameterId,
				    ParameterValue,
				    PartitionOn
			  )
			  VALUES
			  (
				    @BatchID,
				    @EcoLabWasherID,
				    @PHStatusParamID,
				    @PHStatus,
				    @ShiftStartdate
			  );
		   END;
	    IF(@PHValue <> 0
		  OR @PHValue <> NULL)
		   BEGIN
			  INSERT INTO TCD.BatchParameters
			  (
				    BatchId,
				    EcolabWasherId,
				    ParameterId,
				    ParameterValue,
				    PartitionOn
			  )
			  VALUES
			  (
				    @BatchID,
				    @EcoLabWasherID,
				    @PHValueParamID,
				    @PHValue,
				    @ShiftStartdate
			  );
		   END;
	    EXEC TCD.ProcessMyControlProductionWaterConsumptionData
		    @BatchID,
		    @VxML,
		    @ShiftStartDate;
	    DROP TABLE #BatchProductData;
	    DROP TABLE #Dosing;
	    DROP TABLE #StepTime;
	    DROP TABLE #TimeStamp;

	    --Start water consumption per batch

	    SELECT
			 @MeterID = MeterId,
			 @StepComportment = MachineCompartment
	    FROM tcd.Meter mt
	    WHERE mt.UtilityType = 2
			AND mt.GroupId = @WasherGroupID
			AND mt.ControllerID = @ControllerID
			AND mt.MachineCompartment = @WasherID;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchEnergyUsageData
		   WHERE BatchId = @BatchID
			    AND StepCompartment = @StepComportment
			    AND ActualQuantity = @WaterConsumption1
	    )
		   BEGIN
			  IF(@WaterConsumption1 IS NOT NULL
				AND @MeterID IS NOT NULL
				AND @StepComportment IS NOT NULL)
				 BEGIN
					INSERT INTO TCD.BatchEnergyUsageData
					(
						  BatchId,
						  StepCompartment,
						  ActualQuantity,
						  PartitionOn,
						  EcolabWasherId
					)
					SELECT
						  @BatchID,
						  @StepComportment,
						  @WaterConsumption1,
						  @ShiftStartdate,
						  @EcoLabWasherID;
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchEnergyUsageData
		   WHERE BatchId = @BatchID
			    AND StepCompartment = @StepComportment
			    AND ActualQuantity = @WaterConsumption2
	    )
		   BEGIN
			  IF(@WaterConsumption2 IS NOT NULL
				AND @MeterID IS NOT NULL
				AND @StepComportment IS NOT NULL
				AND @BatchID IS NOT NULL)
				 BEGIN
					INSERT INTO TCD.BatchEnergyUsageData
					(
						  BatchId,
						  StepCompartment,
						  ActualQuantity,
						  PartitionOn,
						  EcolabWasherId
					)
					SELECT
						  @BatchID,
						  @StepComportment,
						  @WaterConsumption2,
						  @ShiftStartdate,
						  @EcoLabWasherID;
				 END;
		   END;
	END;
--------------------------------------------------------END 144481--------------------------------------------------------------------
-----------------------start Xml Data Insertion---------------------------------------------------------

GO
IF  NOT EXISTS (SELECT * FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[TCD].[PLCXMLData]') AND type in (N'U'))
BEGIN

CREATE TABLE [TCD].[PLCXMLData](
	[PLCXMLDataId] [int] IDENTITY(1,1) NOT NULL,
	[PLC_Type] [int] NOT NULL,
	[XML_Data] [nvarchar](max) NOT NULL,
	[XML_Type] [int] NOT NULL,
	[Batch_Number] [int] NOT NULL,
	[Time_Stamp] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_ PLCXMLData] PRIMARY KEY CLUSTERED 
(
	[PLCXMLDataId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

END

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlConventionalData_Online]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlConventionalData_Online]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessMyControlConventionalData_Online]
(
	@ControllerID   INT,
	@VxML           XML,
	@RedFlagShiftId INT OUTPUT
)
AS
	BEGIN
	    DECLARE @MachineNumber           INT,
			  @StepNumber              INT,
			  @StartDateTime           DATETIME,
			  @EndDateTime             DATETIME,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @PHValue                 INT,
			  @TemperatureMin          INT,
			  @TemperatureMax          INT,
			  @TempMinStatus           INT,
			  @TempMaxStatus           INT,
			  @BatchNumber             INT,
			  @WasherID                INT,
			  @WasherGroupID           INT,
			  @EcoLabWasherID          INT,
			  @ProgramMasterID         INT,
			  @PlantWasherNumber       INT,
			  @ShiftID                 INT,
			  @FrmParameterID          INT,
			  @PHParameterID           INT,
			  @PHParameterStatus       INT,
			  @BatchID                 INT,
			  @ShiftStartdate          DATETIME,
			  @ShiftName               NVARCHAR(50),
			  @XMLDataID               INT,
			  @TempParameter           INT,
			  @TemperatureMinParam     INT,
			  @TemperatureMaxParam     INT,
			  @TempMinStatusParam      INT,
			  @TempMaxStatusParam      INT,
			  @WashStepNo              INT,
			  @CurrencyCode            VARCHAR(50),
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @TargetTurnTime          INT,
			  @MeterID                INT,
			  @WaterConsumption1      INT,
			   @WaterConsumption2      INT

	    SELECT @MachineNumber = T.c.value('@MachineNumber', 'INT'),
			 @StepNumber = T.c.value('@StepNumber', 'INT'),
			 @StartDateTime = T.c.value('@StartDateTime', 'DATETIME'),
			 @EndDateTime = T.c.value('@EndDateTime', 'DATETIME'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@NominalLoad', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'INT'),
			 @PHStatus = T.c.value('@PHStatus', 'INT'),
			 @PHValue = T.c.value('@PHValue', 'INT'),
			 @TemperatureMin = T.c.value('@TemperatureMin', 'INT'),
			 @TemperatureMax = T.c.value('@TemperatureMax', 'INT'),
			 @TempMaxStatus = T.c.value('@TemperatureMaxStatus', 'INT'),
			 @TempMinStatus = T.c.value('@TemperatreMinStatus', 'INT'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @WaterConsumption1=T.c.value('@WaterConsumption1','NVARCHAR'),
			 @WaterConsumption2=T.c.value('@WaterConsumption2','NVARCHAR')
	    FROM @VxML.nodes('MyControlConventionalData') T(C);

     --Inserts Xml Data

		INSERT INTO tcd.PLCXMLData
	    (
			 PLC_Type,
			 XML_Data,
			 XML_Type,
			 Batch_Number,
			 Time_Stamp
	    )
	       VALUES
				(
					 3,
					CONVERT(nvarchar(max), @VxML),
					 1,
					ISNULL(@BatchNumber,0),		 
					 GETUTCDATE()
				);


	    SELECT @PHParameterID = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'pH';
	    SELECT @PHParameterStatus = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'PH Status';
	    SELECT @TemperatureMinParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Mimum Temperature';
	    SELECT @TemperatureMaxParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Maximum Temperature';
	    SELECT @TempMinStatusParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Minimum Temperature Status';
	    SELECT @TempMaxStatusParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Max Temperature Status';
	    SELECT @WashStepNo = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'StepCompartment No';
	    SELECT @FrmParameterID = [Id]
	    FROM TCD.ConduitPArameters
	    WHERE Name = 'Formula Number';
	    DECLARE @ShiftMapping TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    INSERT INTO @ShiftMapping
	    (
		  ShiftId,
		  ShiftName,
		  ShiftStartdate
	    )
	    EXEC TCD.GetShiftStartDate
		    @StartDateTime
	    SELECT @ShiftID = ShiftID,
			 @ShiftStartdate = ShiftStartdate
	    FROM @ShiftMapping;
	    SELECT @WasherGroupID = GroupId,
			 @WasherID = WasherID
	    FROM TCD.MachineSetup ms
	    WHERE ControllerID = @ControllerID
			AND MachineInternalId = @MachineNumber
			AND IsTunnel = 0
			AND IsDeleted = 0;
	    IF(@EndDateTime = '1/1/1900')
		   SELECT @EndDateTime = NULL;
	    IF(@StartDateTime = '1/1/1900')
		   SELECT @StartDateTime = NULL;
	    IF(@WasherId IS NOT NULL)
		   BEGIN
			  SELECT @ProgramMasterId = Wps.ProgramId
			  FROM TCD.Washer Ws
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.ControllerID = Wg.ControllerId
				  INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.EcoLabAccountNumber
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wps.Is_Deleted = 0;
			  SELECT @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber,
				    @CurrencyCode = P.CurrencyCode,
				    @TargetTurnTime = w.TargetTurnTime * 60
			  FROM TCD.Washer w
				  INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.EcolabAccountNumber
			  WHERE w.WasherId = @WasherID;
	   END;
	    SELECT @BatchID = BatchID
	    FROM TCD.BatchData
	    WHERE MachineInternalID = @MachineNumber
			AND StartDate = @StartDateTime
			AND ControllerBatchId = @BatchNumber
			AND MachineID = @WasherID;

	    --Start Getting InjectionCount and StepCount
	    SELECT @StdInjectionSteps = COUNT(DISTINCT wdpm.
	    WasherDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) -
			 COUNT(DISTINCT wdpm.WasherDosingSetupId)
	    FROM TCD.WasherDosingProductMapping wdpm
		    RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm.
		    WasherDosingSetupId = wds.WasherDosingSetupId
	    WHERE wds.ControllerID = @ControllerID
			AND wds.ProgramNumber = @ProgramNumber;
	    --End Getting InjectionCount and StepCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramMasterId
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT @EcolabTextileCategoryId = pcp.
			  EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp.
				    ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    IF(@BatchID IS NULL)
		   BEGIN
			  INSERT INTO TCD.BatchData
			  (ControllerBatchID,
			   EcolabWasherId,
			   GroupId,
			   MachineInternalId,
			   PlantWasherNumber,
			   StartDate,
			   EndDate,
			   ProgramNumber,
			   ProgramMasterId,
			   MachineID,
			   ActualWeight,
			   StandardWeight,
			   CurrencyCode,
			   ShiftId,
			   PartitionOn,
			   StdInjectionSteps,
			   StdWashSteps,
			   EcolabTextileCategoryId,
			   ChainTextileCategoryId,
			   FormulaSegmentId,
			   EcolabSaturationId,
			   PlantProgramId,
			   EndDateFormula,
			   TargetTurnTime
			  )
			  VALUES
			  (
				    @BatchNumber,
				    @EcoLabWasherID,
				    @WasherGroupID,
				    @MachineNumber,
				    @PlantWasherNumber,
				    @StartDateTime,
				    @EndDateTime,
				    @ProgramNumber,
				    @ProgramMasterId,
				    @WasherID,
				    @Load,
				    @NominalLoad,
				    @CurrencyCode,
				    @ShiftID,
				    @ShiftStartdate,
				    @StdInjectionSteps,
				    @StdWashSteps,
				    @EcolabTextileCategoryId,
				    @ChainTextileCategoryId,
				    @FormulaSegmentId,
				    @EcolabSaturationId,
				    @PlantProgramId,
				    @EndDateTime,
				    @TargetTurnTime
			  );
			  SELECT @BatchID = SCOPE_IDENTITY();
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM TCD.BatchParameters
				 WHERE BatchId = @BatchID
					  AND ParameterID = 38
			   )
			   BEGIN
			   IF(@StdWashSteps <> 0
				 OR @StdWashSteps <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
					   BatchId,
					   EcolabWasherId,
					   ParameterId,
					   ParameterValue,
					   PartitionOn
					)
					SELECT @BatchID,
						  @EcoLabWasherID,
						  38,
						  @StdWashSteps,
						  @ShiftStartdate;
				  END
			END;

			  --End Date  Time  is Null 
			  UPDATE TCD.BatchData
			    SET
				   EndDate = GETUTCDATE()
			  WHERE MachineInternalID = @MachineNumber
				   AND StartDate <> @StartDateTime
				   AND EndDate IS NULL
				   AND ControllerBatchId <> @BatchNumber
				   AND MachineId = @WasherId;	
																  		
			  -- Program Number	
			  IF(@ProgramNumber IS NOT NULL
				AND @ProgramNumber > 0)
				 BEGIN
					IF NOT EXISTS
					(
					    SELECT *
					    FROM TCD.WasherReading
					    WHERE WasherId = @WasherID
							AND ParameterID = @FrmParameterID
							AND DateTimeStamp = @StartDateTime
					)
					    BEGIN
						   INSERT INTO TCD.WasherReading
						   (WasherID,
						    ParameterID,
						    ParameterValue,
						    DateTimeStamp,
						    EcoLabWasherID,
						    Partitionon
						   )
						   VALUES
						   (
								@WasherID,
								@FrmParameterID,
								@ProgramNumber,
								@StartDateTime,
								@EcoLabWasherID,
								@ShiftStartdate
						   );
					    END;
				 END;
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM [TCD].[BatchCustomerData]
				 WHERE BatchID = @BatchId
					  AND @CustomerNumber IS NOT NULL
			  )
				 BEGIN
					INSERT INTO [TCD].[BatchCustomerData]
					([BatchId],
					 CustomerID,
					 [Weight],
					 PartitionOn,
					 EcolabWasherId
					)
					VALUES
					(
						  @BatchID,
						  @CustomerNumber,
						  @Load,
						  @ShiftStartdate,
						  @EcolabWasherID
					);
				 END;
		   END;

	    -- PH Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @PHParameterID
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@PHValue <> 0
				OR @PHValue <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @PHParameterID,
							    @PHValue,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 
	 
	    -- PH Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @PHParameterStatus
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@PHStatus <> 0
				OR @PHStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @PHParameterStatus,
							    @PHStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Min Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TemperatureMinParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TemperatureMin <> 0
				OR @TemperatureMin <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TemperatureMinParam,
							    @TemperatureMin,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Max Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TemperatureMaxParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TemperatureMax <> 0
				OR @TemperatureMax <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TemperatureMaxParam,
							    @TemperatureMax,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Min Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TempMinStatusParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TempMinStatus <> 0
				OR @TempMinStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TempMinStatusParam,
							    @TempMinStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Max Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TempMaxStatusParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TempMaxStatus <> 0
				OR @TempMaxStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TempMaxStatusParam,
							    @TempMaxStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- StepCompartment No
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @WashStepNo
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@StepNumber <> 0
				OR @StepNumber <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @WashStepNo,
							    @StepNumber,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END;
--Start water consumption per batch

	SELECT @MeterID=MeterId
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@MachineNumber

    IF NOT EXISTS(SELECT * FROM TCD.ModuleReading WHERE Reading =@WaterConsumption1 AND ModuleId = @MeterID)
  BEGIN
  IF(@WaterConsumption1 IS NOT NULL  AND @MeterID IS NOT NULL)
  BEGIN
   INSERT INTO TCD.ModuleReading
     (ModuleId,
      ModuleTypeId,
      Reading,
      TimeStamp
     )
     SELECT
     @MeterID,
     2,
     @WaterConsumption1,
     GETUTCDATE()
	 END
      END  
	  
   IF NOT EXISTS(SELECT * FROM TCD.ModuleReading WHERE Reading =@WaterConsumption2 AND ModuleId = @MeterID)
  BEGIN
  IF(@WaterConsumption2 IS NOT NULL  AND @MeterID IS NOT NULL)
  BEGIN
   INSERT INTO TCD.ModuleReading
     (ModuleId,
      ModuleTypeId,
      Reading,
      TimeStamp
     )
     SELECT
     @MeterID,	
     2,
     @WaterConsumption2,
     GETUTCDATE()
	 END
      END 

	 --End water consumption per batch
 END;

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlConventionalData_CompletedBatches]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlConventionalData_CompletedBatches]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [TCD].[ProcessMyControlConventionalData_CompletedBatches](
	@ControllerID   INT,
	@VxML           XML,
	@PLCPointer     INT,
	@ReadPointer    INT,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @MachineNumber           INT,
			  @StartDateTime           DATETIME,
			  @EndDateTime             DATETIME,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @PHValue                 INT,
			  @TemperatureMin          INT,
			  @TemperatureMax          INT,
			  @TempMinStatus           INT,
			  @TempMaxStatus           INT,
			  @BatchNumber             INT,
			  @WasherID                INT,
			  @WasherGroupID           INT,
			  @EcoLabWasherID          INT,
			  @ProgramMasterID         INT,
			  @PlantWasherNumber       INT,
			  @ShiftID                 INT,
			  @BatchID                 INT,
			  @ShiftStartdate          DATETIME,
			  @LastStep                INT,
			  @CurrentStep             INT,
			  @CurrentStepTime         DATETIME,
			  @MinTempParamID          INT,
			  @MaxTempParamID          INT,
			  @MinTempStatuParamID     INT,
			  @MaxTempStatusParamID    INT,
			  @PHStatusParamID         INT,
			  @PHValueParamID          INT,
			  @CurrencyCode            VARCHAR(50),
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @ActualInjSteps          INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @TargetTurnTime          INT,
			  @PreviousShiftId         INT,
			  @CurrentShiftId          INT,
			  @MeterID                 INT,
			  @StepComportment         INT,
			  @WaterConsumption1       INT,
			  @WaterConsumption2       INT,
			  @Stepno                  INT,
			  @quantity                INT,
			  @productid               INT,
			  @Price                   DECIMAL(18, 4),
			  @StandardQty             DECIMAL(18, 4),
			  @TimeStamp               DATETIME2(7),
			  @MaxWashertGroupCapacity INT,
			  @InjectionNumber         INT;
	    SELECT
			 @MachineNumber = T.c.value('@MachineNumber', 'INT'),
			 @StartDateTime = T.c.value('@StartDateTime', 'DateTime'),
			 @EndDateTime = T.c.value('@EndDateTime', 'DateTime'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@NominalLoad', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'INT'),
			 @PHStatus = T.c.value('@PHStatus', 'INT'),
			 @PHValue = T.c.value('@PHValue', 'INT'),
			 @TemperatureMin = T.c.value('@TemperatureMin', 'INT'),
			 @TemperatureMax = T.c.value('@TemperatureMax', 'INT'),
			 @TempMaxStatus = T.c.value('@TemperatureMaxStatus', 'INT'),
			 @TempMinStatus = T.c.value('@TemperatreMinStatus', 'INT'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @WaterConsumption1 = T.c.value('@WaterConsumption1',
			 'NVARCHAR'
									 ),
			 @WaterConsumption2 = T.c.value('@WaterConsumption2',
			 'NVARCHAR'
									 )
	    FROM @VxML.nodes('MyControlConventionalData') T(C);

		--Inserts Xml Data
		INSERT INTO tcd.PLCXMLData
	    (
			 PLC_Type,
			 XML_Data,
			 XML_Type,
			 Batch_Number,
			 Time_Stamp
	    )
	       VALUES
				(
					 3,
					CONVERT(nvarchar(max), @VxML),
					 2,
					ISNULL(@BatchNumber,0),		 
					 GETUTCDATE()
				);

	    DECLARE @ShiftMapping TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    INSERT INTO @ShiftMapping
	    (
			 ShiftId,
			 ShiftName,
			 ShiftStartdate
	    )
	    EXEC TCD.GetShiftStartDate
		    @StartDateTime;
	    SELECT
			 @ShiftID = ShiftID,
			 @ShiftStartdate = ShiftStartdate
	    FROM @ShiftMapping;
	    SELECT
			 @WasherGroupID = GroupId,
			 @WasherID = WasherID
	    FROM TCD.MachineSetup ms
	    WHERE ControllerID = @ControllerID
			AND MachineInternalId = @MachineNumber
			AND IsTunnel = 0
			AND IsDeleted = 0;
	    IF(@WasherId IS NOT NULL)
		   BEGIN
			  SELECT
				    @ProgramMasterId = Wps.ProgramId
			  FROM TCD.Washer Ws
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws
				  .WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =
				  Mst.GroupId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.
				  ControllerID = Wg.ControllerId
				  INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber =
				  Ws.EcoLabAccountNumber
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wps.Is_Deleted = 0;
			  SELECT
				    @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber,
				    @CurrencyCode = P.CurrencyCode,
				    @TargetTurnTime = w.TargetTurnTime * 60
			  FROM TCD.Washer w
				  INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.
				  EcolabAccountNumber
			  WHERE w.WasherId = @WasherID;
		   END;
	    SELECT
			 @BatchID = BatchID
	    FROM TCD.BatchData
	    WHERE MachineInternalID = @MachineNumber
			AND StartDate = @StartDateTime
			AND ControllerBatchId = @BatchNumber
			AND MachineID = @WasherID;

	    --Start Getting InjectionCount and StepCount

	    SELECT
			 @StdInjectionSteps = COUNT(DISTINCT wdpm.
			 WasherDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) -
			 COUNT(DISTINCT wdpm.WasherDosingSetupId)
	    FROM TCD.WasherDosingProductMapping wdpm
		    RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm.
		    WasherDosingSetupId = wds.WasherDosingSetupId
	    WHERE wds.ControllerID = @ControllerID
			AND wds.ProgramNumber = @ProgramNumber;

	    --End Getting InjectionCount and StepCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT
			 @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramMasterId
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT
				    @EcolabTextileCategoryId = pcp.
				    EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp.
				    ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    IF(@BatchID IS NULL)
		   BEGIN

			  --Start Rollup for previous completed shift
			  IF(CAST(@StartDateTime AS DATE) < CAST(GETUTCDATE() AS
			  DATE))
				 BEGIN
					SELECT TOP 1
						  @PreviousShiftId = ShiftId
					FROM TCD.BatchData
					WHERE MachineId = @WasherId
					ORDER BY
						    StartDate DESC;
					SELECT TOP 1
						  @CurrentShiftId = ShiftId
					FROM @ShiftMapping;
					IF(@CurrentShiftId != @PreviousShiftId)
					    BEGIN
						   EXEC TCD.ProductionShiftDataRollup
							   @PreviousShiftId,
							   @RedFlagShiftId OUTPUT;
						   IF(@RedFlagShiftId IS NULL)
							  BEGIN
								 SET @RedFlagShiftId =
								 @PreviousShiftId;
							  END;
					    END;
				 END;
			  --End Rollup for previous completed shift

			  INSERT INTO TCD.BatchData
			  (
				    ControllerBatchID,
				    EcolabWasherId,
				    GroupId,
				    MachineInternalId,
				    PlantWasherNumber,
				    StartDate,
				    EndDate,
				    ProgramNumber,
				    ProgramMasterId,
				    MachineID,
				    ActualWeight,
				    StandardWeight,
				    CurrencyCode,
				    ShiftId,
				    PartitionOn,
				    StdInjectionSteps,
				    StdWashSteps,
				    EcolabTextileCategoryId,
				    ChainTextileCategoryId,
				    FormulaSegmentId,
				    EcolabSaturationId,
				    PlantProgramId,
				    EndDateFormula,
				    TargetTurnTime
			  )
			  VALUES
			  (
				    @BatchNumber,
				    @EcoLabWasherID,
				    @WasherGroupID,
				    @MachineNumber,
				    @PlantWasherNumber,
				    @StartDateTime,
				    @EndDateTime,
				    @ProgramNumber,
				    @ProgramMasterId,
				    @WasherID,
				    @Load,
				    @NominalLoad,
				    @CurrencyCode,
				    @ShiftID,
				    @ShiftStartdate,
				    @StdInjectionSteps,
				    @StdWashSteps,
				    @EcolabTextileCategoryId,
				    @ChainTextileCategoryId,
				    @FormulaSegmentId,
				    @EcolabSaturationId,
				    @PlantProgramId,
				    @EndDateTime,
				    @TargetTurnTime
			  );
			  SELECT
				    @BatchID = SCOPE_IDENTITY();
			  IF NOT EXISTS
			  (
				 SELECT
					   *
				 FROM TCD.BatchParameters
				 WHERE BatchId = @BatchID
					  AND ParameterID = 38
			  )
				 BEGIN
					IF(@StdWashSteps > 0
					   OR @StdWashSteps <> NULL)
					    INSERT INTO TCD.BatchParameters
					    (
							 BatchId,
							 EcolabWasherId,
							 ParameterId,
							 ParameterValue,
							 PartitionOn
					    )
					    SELECT
							 @BatchID,
							 @EcoLabWasherID,
							 38,
							 @StdWashSteps,
							 @ShiftStartdate;
				 END;
		   END;
	    ELSE
		   BEGIN
			  UPDATE tcd.BatchData
			    SET
				   EndDate = @EndDateTime,
				   EndDateFormula = @EndDateTime,
				   ProgramNumber = @ProgramNumber,
				   ProgramMasterId = @ProgramMasterID,
				   ActualWeight = @Load,
				   SyncReady = 1
			  WHERE
				   BatchID = @BatchID;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				1
		   FROM [TCD].[BatchCustomerData]
		   WHERE BatchID = @BatchId
			    AND @CustomerNumber IS NOT NULL
	    )
		   BEGIN
			  INSERT INTO [TCD].[BatchCustomerData]
			  (
				    [BatchId],
				    CustomerID,
				    [Weight],
				    PartitionOn,
				    EcolabWasherId
			  )
			  VALUES
			  (
				    @BatchID,
				    @CustomerNumber,
				    @Load,
				    @ShiftStartdate,
				    @EcolabWasherID
			  );
		   END;
	    ELSE
	    IF(@CustomerNumber > 0)
		   BEGIN
			  UPDATE [TCD].[BatchCustomerData]
			    SET
				   CustomerID = @CustomerNumber,
				   [Weight] = @Load
			  WHERE
				   BatchID = @BatchId;
		   END;
	    CREATE TABLE #Dosing
	    (
		    equipmentNo INT,
		    StepNo      INT,
		    Qty         DECIMAL(10, 6)
	    );
	    INSERT INTO #Dosing
	    SELECT
			 T.c.value('@Equipment', 'INT'),
			 T.c.value('@stepNo', 'INT'),
			 T.c.value('@Qty', 'Decimal(10,6)')
	    FROM @VxML.nodes('MyControlConventionalData/DosingData/Dosing') T
	    (C)
	    WHERE T.c.value('@Qty', 'Decimal(10,6)') > 0;
	    CREATE TABLE #StepTime
	    (
		    Number    INT,
		    [Time]    INT,
		    StartTime DATETIME,
		    EndTime   DATETIME
	    );
	    INSERT INTO #StepTime
	    (
			 Number,
			 [Time]
	    )
	    SELECT
			 T.c.value('@Number', 'INT'),
			 T.c.value('@Time', 'INT')
	    FROM @VxML.nodes('MyControlConventionalData/StepTime/Step') T(C);
	    CREATE TABLE #TimeStamp
	    (
		    Step_Number INT,
		    Time_Stamp  INT
	    );
	
	    --For Calculating TIME_STAMP

	    WITH TempTable
		    AS (SELECT DISTINCT
					Number
			   FROM #StepTime)
		    INSERT INTO #TimeStamp
		    (
				 Step_Number,
				 Time_Stamp
		    )
		    SELECT
				 b.Number,
				 SUM(t.Time) Time_Stamp
		    FROM TempTable b
			    INNER JOIN #StepTime t ON b.Number >= t.Number
		    GROUP BY
				   b.Number;
	    CREATE TABLE #BatchProductData
	    (
		    equipmentNo INT,
		    StepNo      INT,
		    Qty         DECIMAL(10, 6),
		    Time_Stamp  DATETIME2(7),
		    ProductId   INT,
		    Row_No      INT
	    );
	    INSERT INTO #BatchProductData
	    (
			 EquipmentNo,
			 StepNo,
			 Qty,
			 Time_Stamp,
			 ProductId,
			 Row_No
	    )
	    SELECT
			 d.equipmentNo,
			 d.StepNo,
			 d.Qty,
			 DATEADD(ss, ts.Time_Stamp, @StartDateTime),
			 ces.ProductId,
			 ROW_NUMBER() OVER(ORDER BY d.StepNo DESC) AS Row
	    FROM #Dosing d
		    INNER JOIN #TimeStamp ts ON d.StepNo = ts.Step_Number
		    INNER JOIN tcd.ControllerEquipmentSetup ces ON ces.
		    ControllerEquipmentId = d.equipmentNo
	    WHERE d.equipmentNo > 0
			AND d.Qty > 0
			AND ControllerID = @ControllerID
			AND ces.ProductId IS NOT NULL;
	    SELECT
			 @MaxWashertGroupCapacity = MAX(ws.MaxLoad)
	    FROM TCD.Washer WS
		    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.
		    GroupId
	    WHERE Mst.GroupId = @WasherGroupID;
	    DECLARE @Counter INT;
	    SET @counter = 1;
	    WHILE(@counter <=
		    (
			   SELECT
					COUNT(ROW_No)
			   FROM #BatchProductData bpd
		    ))
		   BEGIN
			  SELECT
				    @stepno = bpd.StepNo,
				    @quantity = bpd.Qty,
				    @productid = bpd.ProductId,
				    @timestamp = bpd.Time_Stamp
			  FROM #BatchProductData bpd
			  WHERE bpd.Row_No = @counter
			  ORDER BY
					 bpd.StepNo;
			  SELECT
				    @InjectionNumber = Wdpm.InjectionNumber,
				    @standardqty = ((@NominalLoad / CONVERT( DECIMAL(
				    10, 2), 100)) * Wdpm.Quantity * Ws.MaxLoad) /
				    CONVERT(DECIMAL(10, 2), 100),
				    @price = ((@NominalLoad / CONVERT(       DECIMAL(
				    10, 2), 100)) * Wdpm.Quantity *
				    @MaxWashertGroupCapacity) / CONVERT(DECIMAL(10, 2),
				    100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID)
			  FROM TCD.Washer WS
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws
				  .WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =
				  Mst.GroupId
				  INNER JOIN TCD.WasherGroupType WgT ON WgT.
				  WasherGroupTypeId = Wg.WasherGroupTypeId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.
				  ControllerID = Wg.ControllerId
				  INNER JOIN TCD.WasherDosingSetup Wds ON Wds.
				  WasherProgramSetupId = Wps.WasherProgramSetupId
				  INNER JOIN TCD.WasherDosingProductMapping Wdpm ON
				  Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
				  INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.
				  ProductId = Wdpm.ProductId
				  INNER JOIN TCD.BatchData Bd ON Bd.MachineId = Ws.
				  WasherId
			  WHERE Ws.WasherId = @WasherID
				   AND Wps.ProgramNumber = @ProgramNumber
				   --AND Wdpm.InjectionNumber = @stepno
				   AND Bd.BatchId = @BatchID
				   AND Wps.Is_Deleted = 0
				   AND Pdm.Is_Deleted = 0;
			  INSERT INTO TCD.BatchProductData
			  (
				    BatchId,
				    StepCompartment,
				    ActualQuantity,
				    StandardQuantity,
				    Price,
				    PartitionOn,
				    EcolabWasherId,
				    ProductId,
				    TimeStamp,
				    InjectionNumber
			  )
			  VALUES
			  (
				    @BatchID,
				    @stepno,
				    @quantity,
				    @standardqty,
				    @price,
				    @ShiftStartdate,
				    @EcolabWasherId,
				    @productid,
				    @timestamp,
				    @InjectionNumber
			  );
			  SET @counter = @counter + 1;
		   END;
	    --END For calculating TIMESTAMP
	    --Start Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
	    SELECT
			 @ActualInjSteps = COUNT(DISTINCT StepNo)
	    FROM #Dosing;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE ParameterId = 37
			    AND batchid = @BatchID
			    AND @ActualInjSteps > 0
	    )
		   BEGIN
			  IF(@ActualInjSteps > 0
				OR @ActualInjSteps IS NOT NULL)
				 INSERT INTO TCD.BatchParameters
				 (
					   BatchId,
					   EcolabWasherId,
					   ParameterId,
					   ParameterValue,
					   PartitionOn
				 )
				 SELECT
					   @BatchId,
					   @EcolabWasherId,
					   37,
					   @ActualInjSteps,
					   @ShiftStartDate;
		   END;
	    ELSE
		   BEGIN
			  UPDATE TCD.BatchParameters
			    SET
				   ParameterValue = @ActualInjSteps
			  WHERE
				   ParameterId = 37
				   AND batchid = @BatchID;
		   END;
	    SELECT
			 @LastStep = MAX([Number])
	    FROM #StepTime
	    WHERE [Time] > 0;
	    SELECT
			 @CurrentStep = 1,
			 @CurrentStepTime = @StartDateTime;
	    WHILE(@CurrentStep <= @LastStep)
		   BEGIN
			  UPDATE #StepTime
			    SET
				   StartTime = @CurrentStepTime,
				   EndTime = DATEADD(ss, [time], @CurrentStepTime)
			  WHERE
				   Number = @CurrentStep;
			  SELECT
				    @CurrentStepTime = EndTime
			  FROM #StepTime
			  WHERE Number = @CurrentStep;
			  SELECT
				    @CurrentStep = @CurrentStep + 1;
		   END;
	    INSERT INTO [TCD].[BatchWashStepData]
	    (
			 BatchID,
			 StepCompartment,
			 StartTime,
			 EndTime,
			 PartitionOn,
			 EcolabWasherId
	    )
	    SELECT
			 @BatchID,
			 Number,
			 StartTime,
			 EndTime,
			 @ShiftStartdate,
			 @EcoLabWasherID
	    FROM #StepTime
	    WHERE Number <= @LastStep;
	    SELECT
			 @MinTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Mimum Temperature';
	    SELECT
			 @MaxTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Maximum Temperature';
	    SELECT
			 @MaxTempStatusParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Max Temperature Status';
	    SELECT
			 @MinTempStatuParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Minimum Temperature Status';
	    SELECT
			 @PHValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH';
	    SELECT
			 @PHStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH Status';
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MinTempParamID
	    )
		   BEGIN
			  IF(@TemperatureMin <> 0
				OR @TemperatureMin <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MinTempParamID,
						  @TemperatureMin,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MaxTempParamID
	    )
		   BEGIN
			  IF(@TemperatureMax <> 0
				OR @TemperatureMax <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MaxTempParamID,
						  @TemperatureMax,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MaxTempStatusParamID
	    )
		   BEGIN
			  IF(@TempMaxStatus <> 0
				OR @TempMaxStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MaxTempStatusParamID,
						  @TempMaxStatus,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MinTempStatuParamID
	    )
		   BEGIN
			  IF(@TempMinStatus <> 0
				OR @TempMinStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MinTempStatuParamID,
						  @TempMinStatus,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF(@PHStatus <> 0
		  OR @PHStatus <> NULL)
		   BEGIN
			  INSERT INTO TCD.BatchParameters
			  (
				    BatchId,
				    EcolabWasherId,
				    ParameterId,
				    ParameterValue,
				    PartitionOn
			  )
			  VALUES
			  (
				    @BatchID,
				    @EcoLabWasherID,
				    @PHStatusParamID,
				    @PHStatus,
				    @ShiftStartdate
			  );
		   END;
	    IF(@PHValue <> 0
		  OR @PHValue <> NULL)
		   BEGIN
			  INSERT INTO TCD.BatchParameters
			  (
				    BatchId,
				    EcolabWasherId,
				    ParameterId,
				    ParameterValue,
				    PartitionOn
			  )
			  VALUES
			  (
				    @BatchID,
				    @EcoLabWasherID,
				    @PHValueParamID,
				    @PHValue,
				    @ShiftStartdate
			  );
		   END;
	    EXEC TCD.ProcessMyControlProductionWaterConsumptionData
		    @BatchID,
		    @VxML,
		    @ShiftStartDate;
	    DROP TABLE #BatchProductData;
	    DROP TABLE #Dosing;
	    DROP TABLE #StepTime;
	    DROP TABLE #TimeStamp;

	    --Start water consumption per batch

	    SELECT
			 @MeterID = MeterId,
			 @StepComportment = MachineCompartment
	    FROM tcd.Meter mt
	    WHERE mt.UtilityType = 2
			AND mt.GroupId = @WasherGroupID
			AND mt.ControllerID = @ControllerID
			AND mt.MachineCompartment = @MachineNumber;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchEnergyUsageData
		   WHERE BatchId = @BatchID
			    AND StepCompartment = @StepComportment
			    AND ActualQuantity = @WaterConsumption1
	    )
		   BEGIN
			  IF(@WaterConsumption1 IS NOT NULL
				AND @MeterID IS NOT NULL
				AND @StepComportment IS NOT NULL)
				 BEGIN
					INSERT INTO TCD.BatchEnergyUsageData
					(
						  BatchId,
						  StepCompartment,
						  ActualQuantity,
						  PartitionOn,
						  EcolabWasherId
					)
					SELECT
						  @BatchID,
						  @StepComportment,
						  @WaterConsumption1,
						  @ShiftStartdate,
						  @EcoLabWasherID;
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchEnergyUsageData
		   WHERE BatchId = @BatchID
			    AND StepCompartment = @StepComportment
			    AND ActualQuantity = @WaterConsumption2
	    )
		   BEGIN
			  IF(@WaterConsumption2 IS NOT NULL
				AND @MeterID IS NOT NULL
				AND @StepComportment IS NOT NULL
				AND @BatchID IS NOT NULL)
				 BEGIN
					INSERT INTO TCD.BatchEnergyUsageData
					(
						  BatchId,
						  StepCompartment,
						  ActualQuantity,
						  PartitionOn,
						  EcolabWasherId
					)
					SELECT
						  @BatchID,
						  @StepComportment,
						  @WaterConsumption2,
						  @ShiftStartdate,
						  @EcoLabWasherID;
				 END;
		   END;
	END;


GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlOnlineCWStepWaterConsumptionData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlOnlineCWStepWaterConsumptionData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [TCD].[ProcessMyControlOnlineCWStepWaterConsumptionData]
(
@ControllerID   INT,
 @VxML       XML
) 
AS
BEGIN
DECLARE @MachineNumber   INT,
  @WasherID INT,
  @MeterID INT,
  @WasherGroupID INT,
  @StepComportmentNO INT,
  @ActualQuantity INT,
  @EcolabWasherId INT,
  @CurrentStepComportmentNO INT

   SELECT @MachineNumber = T.c.value('@MachineNumber', 'INT')
     FROM @VxML.nodes('MyControlConventionalData') T(C);

	 --Inserts Xml Data
	 INSERT INTO tcd.PLCXMLData
	    (
			 PLC_Type,
			 XML_Data,
			 XML_Type,
			 Batch_Number,
			 Time_Stamp
	    )
	       VALUES
				(
					 3,
					CONVERT(nvarchar(max), @VxML),
					 5,
					 0,			 
					 GETUTCDATE()
				);



  CREATE TABLE #StepConsumptionData
  (
      StepNo      INT,
      Qty         DECIMAL(10, 6)
  )
   INSERT INTO #StepConsumptionData 
   SELECT  T.c.value('@StepNo', 'INT'),
         T.c.value('@WCCounter1', 'Decimal(10,2)')+T.c.value('@WCCounter2', 'Decimal(10,2)')
     FROM @VxML.nodes('MyControlConventionalData/WaterConsumptionData/StepConsumption') T(C)
  WHERE T.c.value('@WCCounter1', 'Decimal(10,6)')>0 OR T.c.value('@WCCounter2', 'Decimal(10,6)')>0 ;

  --Getting WasherGroupId,WasherId from MachineSetup
   SELECT @WasherGroupID = GroupId,
    @WasherID = ms.WasherID
     FROM TCD.MachineSetup ms
       WHERE ControllerID = @ControllerID
   AND MachineInternalId = @MachineNumber
   AND IsTunnel = 0
   AND IsDeleted = 0;

   --Getting MeterId,WasherId from Meter
   SELECT @MeterID=MeterId
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@WasherID

    --Getting @EcolabWasherId from Washer
   SELECT @EcolabWasherId= wr.EcolabWasherId
   FROM TCD.Washer wr
      WHERE wr.WasherId=@WasherID

  
  SET @CurrentStepComportmentNO=1;
  WHILE(@CurrentStepComportmentNO<=25)
  BEGIN
  SELECT @StepComportmentNO=scd.StepNo,@ActualQuantity=scd.Qty
  FROM #StepConsumptionData scd where scd.StepNo=@CurrentStepComportmentNO
  IF NOT EXISTS(SELECT * FROM TCD.WasherModuleOnlineUsageData WHERE WasherId = @WasherID AND StepComportment =@StepComportmentNO AND ModuleId = @MeterID AND ActualQuantity=@ActualQuantity )
  BEGIN
  IF(@StepComportmentNO IS NOT NULL AND @WasherID IS NOT NULL AND @MeterID IS NOT NULL)
   INSERT INTO TCD.WasherModuleOnlineUsageData
     (WasherId,
      StepComportment,
      ModuleId,
      ActualQuantity,
      TimeStamp,
      EcolabWasherId
     )
     SELECT
     @WasherID,
     @StepComportmentNO,
     @MeterID,
     @ActualQuantity,
     GETUTCDATE(),
     @EcolabWasherId
      END  
        SET  @CurrentStepComportmentNO=@CurrentStepComportmentNO+1;
   
  END;
END;

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlTunnelWasherOnlineData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlTunnelWasherOnlineData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessMyControlTunnelWasherOnlineData](
	@ControllerID   INT,
	@xmlTags        XML,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @BatchID                 INT,
			  @WasherID                INT,
			  @EcolabWasherId          INT,
			  @CurrencyCode            VARCHAR(50),
			  @MachineInternalId       INT,
			  @WasherGroupID           INT,
			  @PlantWasherNumber       INT,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @BatchNumber             INT,
			  @TargetTurnTime          INT,
			  @PartitionOn             DATETIME,
			  @BatchStartTime          DATETIME,
			  @ProgramID               INT,
			  @NumberOfCompartments    INT,
			  @TransferSignalId        INT,
			  @BatchShiftId            INT,
			  @compartmentID           INT,
			  @TunnelXML               XML,
			  @TempXML                 XML,
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @CurrentStepComportmentNO INT,
               @CounterNO               INT,
               @MeterID                 INT,
               @ActualQuantity          INT

	    SELECT @TransferSignalId = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Transfer Signal';
	    CREATE TABLE #Batches
	    (
		    BatchNumber   INT,
		    StartDateTime DATETIME
	    );
	    -- SET @compartmentID = 1;

	    SELECT @TempXML = T.c.query('.')
	    FROM @xmlTags.nodes('MyControlTunnel') AS T(c);

	    SELECT @MachineInternalID = T.c.value('@MachineNumber', 'int')
	    FROM @TempXML.nodes('MyControlTunnel') AS T(c);
	    SELECT @EcolabWasherID = EcolabWasherId,
			 @WasherGroupID = Wg.WasherGroupId,
			 @PlantWasherNumber = PlantWasherNumber,
			 @WasherID = ws.WasherId,
			 @CurrencyCode = P.CurrencyCode,
			 @NumberOfCompartments = Mst.NumberofComp
	    FROM TCD.Washer AS Ws
		    INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = Ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.
		    GroupId
		    INNER JOIN TCD.WasherGroupType AS WgT ON WgT.
		    WasherGroupTypeId = Wg.WasherGroupTypeId
		    INNER JOIN TCD.ConduitController AS Ctrl ON Ctrl.
		    ControllerId = Mst.ControllerId
		    INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.
		    EcoLabAccountNumber
	    WHERE Ctrl.ControllerID = @ControllerID
			AND mst.MachineInternalId = @MachineInternalID
			AND Mst.IsTunnel = 1 AND Mst.IsDeleted =0;
	    SET @compartmentID = @NumberOfCompartments;
	    WHILE(@compartmentID <= @NumberOfCompartments
			AND @compartmentID > 0)
		   BEGIN
			  SELECT @TunnelXML = T.c.query('.')
			  FROM @xmlTags.nodes('MyControlTunnel/TunnelData') AS T(c)
			  WHERE T.c.value('@CompartmentNumber', 'INT') =
			  @compartmentID;
			  SELECT @MachineInternalID = T.c.value('@MachineNumber',
			  'int'
										    ),
				    @BatchNumber = T.c.value('@BatchNumber', 'INT'),
				    @BatchStartTime = T.c.value('@StartDateTime',
				    'DateTime'
										 ),
				    @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
				    @Load = T.c.value('@Load', 'Decimal(10,6)'),
				    @NominalLoad = T.c.value('@Nominalload',
				    'Decimal(10,6)'
									   ),
				    @CustomerNumber = T.c.value('@CustomerNumber',
				    'int'
										 ),
				    @PHStatus = T.c.value('@pHStatus', 'int')
			  FROM @TunnelXML.nodes('TunnelData') AS T(c);

			  --Inserts Xml Data
		INSERT INTO tcd.PLCXMLData
	    (
			 PLC_Type,
			 XML_Data,
			 XML_Type,
			 Batch_Number,
			 Time_Stamp
	    )
	       VALUES
				(
					 3,
					CONVERT(nvarchar(max), @xmlTags),
					 1,
					ISNULL(@BatchNumber,0),		 
					 GETUTCDATE()
				);

			  DECLARE @ShiftStartDateTemp TABLE
			  (
				  ShiftId        INT,
				  ShiftName      NVARCHAR(50),
				  ShiftStartdate DATETIME
			  );
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchStartTime
			  SELECT @BatchShiftId = ShiftID,
				    @PartitionOn = ShiftStartdate
			  FROM @ShiftStartDateTemp;
			  IF(@ProgramNumber = 0
				OR @BatchNumber = 1)
				 BEGIN
					SELECT @compartmentID = @compartmentID - 1;
					CONTINUE;
				 END;
			  SELECT @ProgramID = ProgramId,
				    @TargetTurnTime = 3600 / (tps.TotalRunTime /
				    @NumberOfCompartments)
			  FROM TCD.TunnelProgramSetup AS tps
			  WHERE tps.WasherGroupId = @WasherGroupID
				   AND tps.is_deleted = 0
				   AND ProgramNumber = @ProgramNumber;
			  INSERT INTO #Batches
			  (BatchNumber,
			   StartDateTime
			  )
				    SELECT @BatchNumber,
						 @BatchStartTime;
			  SELECT @BatchID = NULL;
			  SELECT @BatchID = BatchID
			  FROM TCD.BatchData AS BD
			  WHERE BD.ControllerBatchId = @BatchNumber
				   AND BD.StartDate = @BatchStartTime
				   AND BD.MachineId = @WasherID;
			  --Start Getting InjectionCount,StepCount And ProductCount
			  SELECT @StdInjectionSteps = COUNT(tdpm.
			  TunnelDosingSetupId),
				    @StdWashSteps = COUNT(DISTINCT tds.
				    TunnelDosingSetupId) - COUNT(tdpm.
				    TunnelDosingSetupId)
			  FROM tcd.TunnelDosingProductMapping AS tdpm
				  RIGHT JOIN tcd.TunnelDosingSetup AS tds ON tdpm.
				  TunnelDosingSetupId = tds.TunnelDosingSetupId
			  WHERE tds.GroupId = @WasherGroupID
				   AND tds.ProgramNumber = @ProgramNumber;
			  --End Getting InjectionCount,StepCount And ProductCount
			  --Start-----ProgramMasterID logic for PlantChainProgram
			  SELECT @PlantProgramId = pm.PlantProgramId,
				    @EcolabTextileCategoryId = pm.
				    EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pm.ChainTextileId,
				    @FormulaSegmentId = pm.FormulaSegmentId,
				    @EcolabSaturationId = pm.EcolabSaturationId
			  FROM TCD.ProgramMaster AS pm
			  WHERE pm.ProgramId = @ProgramID
				   AND pm.Is_Deleted = 0;
			  IF(@PlantProgramId <> 0
				OR @PlantProgramId IS NOT NULL)
				 BEGIN
					--Assign value from plantchainprogram table based on plantprogramId
					SELECT @EcolabTextileCategoryId = pcp.
					EcolabTextileCategoryId,
						  @ChainTextileCategoryId = pcp.
						  ChainTextileCategoryId,
						  @FormulaSegmentId = pcp.FormulaSegmentId,
						  @EcolabSaturationId = pcp.
						  EcolabSaturationId
					FROM tcd.PlantChainProgram AS pcp
					WHERE pcp.PlantProgramId = @PlantProgramId
						 AND pcp.Is_Deleted = 0;
				 END;
			  --End-----ProgramMasterID logic for PlantChainProgram
			  IF @BatchID IS NULL
				 BEGIN
					INSERT INTO TCD.BatchData
					(ControllerBatchId,
					 EcolabWasherId,
					 GroupId,
					 MachineInternalId,
					 PlantWasherNumber,
					 StartDate,
					 ProgramNumber,
					 ProgramMasterId,
					 MachineId,
					 ActualWeight,
					 StandardWeight,
					 CurrencyCode,
					 ShiftId,
					 PartitionOn,
					 TargetTurnTime,
					 StdInjectionSteps,
					 StdWashSteps,
					 EcolabTextileCategoryId,
					 ChainTextileCategoryId,
					 FormulaSegmentId,
					 EcolabSaturationId,
					 PlantProgramId
					)
						  SELECT @BatchNumber,
							    @EcolabWasherID,
							    @WasherGroupID,
							    @MachineInternalID,
							    @PlantWasherNumber,
							    @BatchStartTime,
							    @ProgramNumber,
							    @ProgramID,
							    @WasherID,
							    @Load,
							    @NominalLoad,
							    @CurrencyCode,
							    @BatchShiftId,
							    @PartitionOn,
							    @TargetTurnTime,
							    @StdInjectionSteps,
							    @StdWashSteps,
							    @EcolabTextileCategoryId,
							    @ChainTextileCategoryId,
							    @FormulaSegmentId,
							    @EcolabSaturationId,
							    @PlantProgramId;
					SELECT @BatchID = SCOPE_IDENTITY();
					IF(@StdWashSteps > 0
					   OR @StdWashSteps <> NULL)
					    BEGIN
						   INSERT INTO TCD.BatchParameters
						   (BatchId,
						    EcolabWasherId,
						    ParameterId,
						    ParameterValue,
						    PartitionOn
						   )
								SELECT @BatchID,
									  @EcolabWasherId,
									  38,
									  @StdWashSteps,
									  @PartitionOn;
					    END;
					IF @CustomerNumber IS NOT NULL
					    BEGIN
						   IF NOT EXISTS
						   (
							  SELECT 1
							  FROM TCD.BatchCustomerData
							  WHERE BatchID = @BatchID
						   )
							  BEGIN
								 INSERT INTO TCD.BatchCustomerData
								 (BatchId,
								  CustomerID,
								  Weight,
								  PartitionOn,
								  EcolabWasherId
								 )
									   SELECT @BatchID,
											@CustomerNumber,
											@Load,
											@PartitionOn,
											@EcolabWasherId;
							  END;
					    END;
				 END;
			  -- Transfer Signal
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM tcd.WasherReading wr
				 WHERE wr.WasherId = @WasherID
					  AND wr.ParameterId = @TransferSignalId
					  AND wr.DateTimeStamp = @BatchStartTime
			  )
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterId,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TransferSignalId,
							    1,
							    @BatchStartTime,
							    @PartitionOn,
							    @EcolabWasherId
						  UNION ALL
						  SELECT @WasherID,
							    @TransferSignalId,
							    0,
							    @BatchStartTime,
							    @PartitionOn,
							    @EcolabWasherId;
				 END;
			  --Start Updating Batch Wash Step Data	 
			  EXEC TCD.UPDATEBatchWashStepForTunnel
				  @TunnelXML,
				  @WasherID,
				  @BatchID,
				  @BatchStartTime,
				  @PartitionOn,
				  @EcolabWasherId,
				  @compartmentID;
			  --End Updating Batch Wash Step Data	 
			  SELECT @compartmentID = @compartmentID - 1;
		   END;


	 --Start water consumption per step


   CREATE TABLE #WaterConsumptionData
     (
      Number          INT,
      Quantity        NVARCHAR,
     );
     INSERT INTO #WaterConsumptionData
     (Number,
  Quantity
     )
    SELECT T.c.value('@Counter', 'INT') AS Number, --PumpNumber
       T.c.value('@Value', 'NVARCHAR') AS Quantity --Water Quanity
    FROM @xmlTags.nodes('MyControlTunnel/TunnelData/WaterConsumption') T(C);

  
  SET @CurrentStepComportmentNO=1;
  SET @CounterNO=1;
  WHILE(@CurrentStepComportmentNO<=22)
  BEGIN
   SELECT @MeterID=MeterId
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@CurrentStepComportmentNO
   SELECT @ActualQuantity=wc.Quantity
  FROM #WaterConsumptionData wc where wc.Number=@CounterNO
  IF NOT EXISTS(SELECT * FROM TCD.WasherModuleOnlineUsageData WHERE WasherId = @WasherID AND StepComportment =@CurrentStepComportmentNO AND ModuleId = @MeterID AND ActualQuantity=@ActualQuantity )
  BEGIN
  IF(@WasherID IS NOT NULL AND @MeterID IS NOT NULL AND @MeterID IS NOT NULL AND @ActualQuantity IS NOT NULL)
  BEGIN
  SET @CounterNO=@CounterNO+1;
   INSERT INTO TCD.WasherModuleOnlineUsageData
     (WasherId,
      StepComportment,
      ModuleId,
      ActualQuantity,
      TimeStamp,
      EcolabWasherId
     )
     SELECT
     @WasherID,
     @CurrentStepComportmentNO,
     @MeterID,
     @ActualQuantity,
     GETUTCDATE(),
     @EcolabWasherId
      END  

	  END
        SET  @CurrentStepComportmentNO=@CurrentStepComportmentNO+1;
   
  END;

 END;

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlTunnelWasherProdData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlTunnelWasherProdData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessMyControlTunnelWasherProdData](
	@ControllerID   INT,
	@xmlTags        XML,
	@PLCPointer     INT,
	@ReadPointer    INT,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @BatchID                   INT,
			  @WasherID                  INT,
			  @EcolabWasherId            INT,
			  @CurrencyCode              VARCHAR(50),
			  @MachineInternalId         INT,
			  @WasherGroupID             INT,
			  @PlantWasherNumber         INT,
			  @ProgramNumber             INT,
			  @Load                      DECIMAL(10, 2),
			  @NominalLoad               DECIMAL(10, 2),
			  @CustomerNumber            INT,
			  @PHStatus                  INT,
			  @PHValue                   INT,
			  @LFStatus                  INT,
			  @LFValue                   INT,
			  @BatchNumber               INT,
			  @TargetTurnTime            INT,
			  @PartitionOn               DATETIME2,
			  @BatchStartTime            DATETIME2,
			  @BatchEndTime              DATETIME2,
			  @ProgramID                 INT,
			  @NumberOfCompartments      INT,
			  @ProductId                 INT,
			  @CompartmentNum            INT,
			  @EquipmentType             INT,
			  @MinTempParamID            INT,
			  @MaxTempParamID            INT,
			  @TempStatusParamID         INT,
			  @PHValueParamID            INT,
			  @PHStatusParamID           INT,
			  @ConductivityValueParamID  INT,
			  @ConductivityStatusParamID INT,
			  @StdInjectionSteps         INT,
			  @StdWashSteps              INT,
			  @ActualInjSteps            INT,
			  @EcolabTextileCategoryId   INT,
			  @ChainTextileCategoryId    INT,
			  @FormulaSegmentId          INT,
			  @EcolabSaturationId        INT,
			  @PlantProgramId            INT,
			  @PreviousShiftId		    INT,
			  @CurrentShiftId		    INT,
			  @CurrentStepComportmentNO INT,
              @CounterNO                INT,
               @MeterID                 INT,
               @ActualQuantity          INT
	    DECLARE @BatchShiftId INT;
	    DECLARE @ShiftStartDateTemp TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    DECLARE @TunnelXML XML;
	    SELECT @TunnelXML = T.c.query('.')
	    FROM @xmlTags.nodes('MyControlTunnel/TunnelData') T(c)
	    WHERE T.c.value('@CompartmentNumber', 'INT') = 0;

		
	    SELECT @MachineInternalID = T.c.value('@MachineNumber', 'int'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @BatchStartTime = T.c.value('@StartDateTime', 'DateTime'),
			 @BatchEndTime = T.c.value('@EndDateTime', 'DateTime'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@Nominalload', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'int'),
			 @PHStatus = T.c.value('@Phstatus', 'int'),
			 @PHValue = T.c.value('@Phvalue', 'INT'),
			 @LFStatus = T.c.value('@LFStatus', 'INT'),
			 @LFValue = T.c.value('@LFValue', 'INT')
	    FROM @xmlTags.nodes('MyControlTunnel/TunnelData') T(c);

		--Inserts Xml Data
		INSERT INTO tcd.PLCXMLData
	    (
			 PLC_Type,
			 XML_Data,
			 XML_Type,
			 Batch_Number,
			 Time_Stamp
	    )
	       VALUES
				(
					 3,
					CONVERT(nvarchar(max), @xmlTags),
					 2,
					ISNULL(@BatchNumber,0),		 
					 GETUTCDATE()
				);

	    SELECT @EcolabWasherID = Ws.EcolabWasherId,
			 @WasherGroupID = Wg.WasherGroupId,
			 @PlantWasherNumber = PlantWasherNumber,
			 @WasherID = ws.WasherId,
			 @CurrencyCode = P.CurrencyCode,
			 @NumberOfCompartments = Mst.NumberofComp
	    FROM TCD.Washer Ws
		    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.
		    GroupId
		    INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId
		    = Wg.WasherGroupTypeId
		    INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId =
		    Mst.ControllerId
		    INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.
		    EcoLabAccountNumber
	    WHERE Ctrl.ControllerID = @ControllerID
			AND Mst.MachineInternalId = @MachineInternalID
			AND Mst.IsTunnel = 1 AND Mst.IsDeleted=0;
	    SELECT @EcolabWasherID;
	    SELECT @ProgramID = ProgramId,
			 @TargetTurnTime = (3600 / (tps.TotalRunTime /
			 @NumberOfCompartments))
	    FROM TCD.TunnelProgramSetup AS tps
	    WHERE tps.WasherGroupId = @WasherGroupID
			AND tps.is_deleted = 0
			AND ProgramNumber = @ProgramNumber;
	    DELETE FROM @ShiftStartDateTemp;
	    IF(@BatchEndTime IS NOT NULL)
		   BEGIN
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchEndTime
		   END;
	    ELSE
		   BEGIN
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchStartTime
		   END;
	    SELECT @BatchShiftId = ShiftID,
			 @PartitionOn = ShiftStartdate
	    FROM @ShiftStartDateTemp;


	    --Start Getting InjectionCount,StepCount And ProductCount
	    SELECT @StdInjectionSteps = COUNT(tdpm.TunnelDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT tds.TunnelDosingSetupId) -
			 COUNT(tdpm.TunnelDosingSetupId)
	    FROM tcd.TunnelDosingProductMapping tdpm
		    RIGHT JOIN tcd.TunnelDosingSetup tds ON tdpm.
		    TunnelDosingSetupId = tds.TunnelDosingSetupId
	    WHERE tds.GroupId = @WasherGroupID
			AND tds.ProgramNumber = @ProgramNumber;
	    --End Getting InjectionCount,StepCount And ProductCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramID
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT @EcolabTextileCategoryId = pcp. EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp. ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    SELECT @BatchID = NULL;
	    SELECT @BatchID = BatchID
	    FROM TCD.BatchData BD
	    WHERE BD.ControllerBatchId = @BatchNumber
			AND BD.StartDate = @BatchStartTime
			AND BD.MachineId = @WasherID;
	    --AND BD.MachineInternalID = @MachineInternalID
	    IF(@BatchID IS NULL)
		   BEGIN
		   --Start Rollup for previous completed shift
	   IF(CAST(@BatchStartTime as date) < CAST(GETUTCDATE() as date))
	   BEGIN
		  SELECT TOP 1 @PreviousShiftId=ShiftId FROM TCD.BatchData WHERE MachineId=@WasherId ORDER BY StartDate DESC	   
		  SELECT Top 1 @CurrentShiftId = ShiftId from @ShiftStartDateTemp
		  IF(@CurrentShiftId != @PreviousShiftId)
		  BEGIN
			 EXEC TCD.ProductionShiftDataRollup @PreviousShiftId, @RedFlagShiftId OUTPUT
			 IF(@RedFlagShiftId IS NULL)
			 BEGIN
				SET @RedFlagShiftId = @PreviousShiftId
			 END
		  END
	   END
	   --End Rollup for previous completed shift
			  INSERT INTO TCD.BatchData
			  (ControllerBatchId,
			   EcolabWasherId,
			   GroupId,
			   MachineInternalId,
			   PlantWasherNumber,
			   StartDate,
			   EndDate,
			   ProgramNumber,
			   ProgramMasterId,
			   MachineId,
			   ActualWeight,
			   StandardWeight,
			   CurrencyCode,
			   ShiftId,
			   PartitionOn,
			   TargetTurnTime,
			   StdInjectionSteps,
			   StdWashSteps,
			   EcolabTextileCategoryId,
			   ChainTextileCategoryId,
			   FormulaSegmentId,
			   EcolabSaturationId,
			   PlantProgramId,
			   EndDateFormula
			  )
				    SELECT @BatchNumber,
						 @EcolabWasherID,
						 @WasherGroupID,
						 @MachineInternalID,
						 @PlantWasherNumber,
						 @BatchStartTime,
						 @BatchEndTime,
						 @ProgramNumber,
						 @ProgramID,
						 @WasherID,
						 @Load,
						 @NominalLoad,
						 @CurrencyCode,
						 @BatchShiftId,
						 @PartitionOn,
						 @TargetTurnTime,
						 @StdInjectionSteps,
						 @StdWashSteps,
						 @EcolabTextileCategoryId,
						 @ChainTextileCategoryId,
						 @FormulaSegmentId,
						 @EcolabSaturationId,
						 @PlantProgramId,
						 @BatchEndTime;
			  SELECT @BatchID = SCOPE_IDENTITY();
			  IF(@StdWashSteps > 0
				OR @StdWashSteps <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchID,
							@EcolabWasherId,
							38,
							@StdWashSteps,
							@PartitionOn;
			  EXEC TCD.UPDATEBatchWashStepForTunnel
				  @TunnelXML,
				  @WasherID,
				  @BatchID,
				  @BatchStartTime,
				  @PartitionOn,
				  @EcolabWasherId,
				  @NumberOfCompartments;
		   END;
	    IF(@BatchEndTime IS NOT NULL
		  AND @BatchEndTime != '01/01/1900')
		   BEGIN
			  UPDATE TCD.BatchData
			    SET
				   EndDate = @BatchEndTime,
				   ShiftId = @BatchShiftId,
				   PartitionOn = @PartitionOn,
				   EndDateFormula=@BatchEndTime
			  WHERE BATCHID = @BatchID;
		   END;
	    IF(@CustomerNumber IS NOT NULL)
		   BEGIN
			  IF NOT EXISTS
			  (
				 SELECT 1
				 FROM [TCD].[BatchCustomerData]
				 WHERE BatchID = @BatchID
			  )
				 BEGIN
					INSERT INTO [TCD].[BatchCustomerData]
					([BatchId],
					 CustomerID,
					 [Weight],
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @BatchID,
							    @CustomerNumber,
							    @Load,
							    @PartitionOn,
							    @EcolabWasherId;
				 END;
		   END;
	    CREATE TABLE #DosingDetails
	    (
		    Number          INT,
		    Quantity        DECIMAL(10, 6),
		    Point           INT,
		    IsMainEquioment INT
	    );
	    INSERT INTO #DosingDetails
	    (Number,
		Quantity,
		Point,
		IsMainEquioment
	    )
			 SELECT T.c.value('@Number', 'INT') AS Number, --PumpNumber
				   T.c.value('@Quantity', 'Decimal(10,6)') AS Quantity, --Dosing Quanity
				   T.c.value('@Point', 'INT') AS Point, --Dosing point
				   T.c.value('@IsMainEquioment', 'INT') AS
			 IsMainEquioment
			 FROM @xmlTags.nodes('MyControlTunnel/TunnelData/Dose') T(C)
	    ;
	
	    -- Fetching data from cursor
	    DECLARE @MYCURSOR CURSOR;
	    SET @MYCURSOR = CURSOR FAST_FORWARD
	    FOR SELECT Number,
				Quantity,
				Point,
				IsMainEquioment
		   FROM #DosingDetails;
	    DECLARE @Number          INT,
			  @Quantity        DECIMAL(10, 6),
			  @Point           INT,
			  @IsMainEquioment INT;
	    OPEN @MYCURSOR;
	    FETCH NEXT FROM @MYCURSOR INTO @Number,
								@Quantity,
								@Point,
								@IsMainEquioment;
	    WHILE @@FETCH_STATUS = 0
		   BEGIN
			  IF(@IsMainEquioment = 1)
				 BEGIN
					SET @EquipmentType = 2;
				 END;
			  ELSE
				 BEGIN
					SET @EquipmentType = 1;
				 END;
			  SELECT @ProductId = CES.ProductId,
				    @CompartmentNum = TCEVM.CompartmentNumber
			  FROM tcd.ControllerEquipmentSetup CES
				  INNER JOIN TCD.
				  TunnelCompartmentEquipmentValveMapping TCEVM ON CES.
				  ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
			  WHERE CES.ControllerId = @ControllerID
				   AND CES.ControllerEquipmentTypeId = @EquipmentType
				   AND --CES.IsActive=1 AND
				   --CES.WasherGroupNumber=@WasherGroupNum AND
				   TCEVM.DosingPointNumber = @Point
				   AND CES.ControllerEquipmentId = @Number;
				
			  --SELECT @EcolabWasherID
			  IF(@ProductId IS NOT NULL)
				 BEGIN
					INSERT INTO TCD.BatchProductData
					(BatchId,
					 StepCompartment,
					 ActualQuantity,
					 [TimeStamp],
					 PartitionOn,
					 EcolabWasherId,
					 ProductId
					)
						  SELECT @BatchID,
							    @CompartmentNum,
							    @Quantity,
							    @BatchEndTime,
							    @PartitionOn,
							    @EcolabWasherID,
							    @ProductId;
				 END;
			  FETCH NEXT FROM @MYCURSOR INTO @Number,
									   @Quantity,
									   @Point,
									   @IsMainEquioment;
		   END;
	    CLOSE @MYCURSOR;
	    DEALLOCATE @MYCURSOR;
	    DROP TABLE #DosingDetails;
	    SELECT @ActualInjSteps = COUNT(DISTINCT StepCompartment)
	    FROM TCD.BatchProductData
	    WHERE BatchId = @BatchID;
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.BatchParameters
		   WHERE ParameterId = 37
			    AND batchid = @BatchID
			    AND @ActualInjSteps > 0
	    )
		   BEGIN
			  IF(@ActualInjSteps > 0
				OR @ActualInjSteps <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchId,
							@EcolabWasherId,
							37,
							@ActualInjSteps,
							@PartitionOn;
		   END;
	    ELSE
		   BEGIN
			  UPDATE TCD.BatchParameters
			    SET
				   ParameterValue = @ActualInjSteps
			  WHERE ParameterId = 37
				   AND batchid = @BatchID;
		   END;
	    SELECT @MinTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Mimum Temperature';
	    SELECT @MaxTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Maximum Temperature';
	    SELECT @TempStatusParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Temperature Status';
	    SELECT @PHValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH';
	    SELECT @PHStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH Status';
	    SELECT @ConductivityValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Conductivity';
	    SELECT @ConductivityStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'LF Status';
	    IF(@PHValue IS NOT NULL)
		   BEGIN
			  --pH Value
			  IF(@PHValue <> 0
				OR @PHValue <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @PHValueParamID,
					   @PHValue,
					   @PartitionOn
				 );

			  --pH Status
			  IF(@PHStatus <> 0
				OR @PHStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @PHStatusParamID,
					   @PHStatus,
					   @PartitionOn
				 );
		   END;
	    IF(@LFValue IS NOT NULL)
		   BEGIN
			  --Conductivity Value
			  IF(@LFValue <> 0
				OR @LFValue <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @ConductivityValueParamID,
					   @LFValue,
					   @PartitionOn
				 );

			  --Conductivity Status
			  IF(@LFStatus <> 0
				OR @LFStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @ConductivityStatusParamID,
					   @LFStatus,
					   @PartitionOn
				 );
		   END;
	    CREATE TABLE #TemperatureDetails
	    (
		    MinimumTemp DECIMAL(10, 2),
		    MaximumTemp DECIMAL(10, 2),
		    TempStatus  DECIMAL(10, 2)
	    );
	    INSERT INTO #TemperatureDetails
	    (MinimumTemp,
		MaximumTemp,
		TempStatus
	    )
			 SELECT T.c.value('@Minimum', 'Decimal(10,2)') AS
			 MinimumTemp,
				   T.c.value('@Maximum', 'Decimal(10,2)') AS
				   MaximumTemp,
				   T.c.value('@Status', 'Decimal(10,2)') AS TempStatus
			 FROM @xmlTags.nodes(
			 'MyControlTunnel/TunnelData/TemperatureData'
							) T(c);
	  
	    -- Fetching data from cursor
	    DECLARE @TEMPCURSOR CURSOR;
	    SET @TEMPCURSOR = CURSOR FAST_FORWARD
	    FOR SELECT MinimumTemp,
				MaximumTemp,
				TempStatus
		   FROM #TemperatureDetails;
	    DECLARE @MinimumTemp DECIMAL(10, 2),
			  @MaximumTemp DECIMAL(10, 2),
			  @TempStatus  DECIMAL(10, 2);
	    OPEN @TEMPCURSOR;
	    FETCH NEXT FROM @TEMPCURSOR INTO @MinimumTemp,
								  @MaximumTemp,
								  @TempStatus;
	    WHILE @@FETCH_STATUS = 0
		   BEGIN	
			  --Minimum Temperature
			  IF(@MinimumTemp <> 0
				OR @MinimumTemp <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @MinTempParamID,
					   @MinimumTemp,
					   @PartitionOn
				 );

			  --Maximum Temperature
			  IF(@MaximumTemp <> 0
				OR @MaximumTemp <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @MaxTempParamID,
					   @MaximumTemp,
					   @PartitionOn
				 );

			  --Temperature Status
			  IF(@TempStatus <> 0
				OR @TempStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @TempStatusParamID,
					   @TempStatus,
					   @PartitionOn
				 );
			  FETCH NEXT FROM @TEMPCURSOR INTO @MinimumTemp,
										@MaximumTemp,
										@TempStatus;
		   END;
	    CLOSE @TEMPCURSOR;
	    DEALLOCATE @TEMPCURSOR;
	    DROP TABLE #TemperatureDetails;
	    UPDATE TCD.BatchWashStepData
		 SET
			EndTime = @BatchEndTime
	    WHERE BatchId = @BatchID
			AND EndTime IS NULL;

   --Start water consumption per batch

   SELECT @MeterID=MeterId
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@MachineInternalId


    CREATE TABLE #WaterConsumptionData
     (
      Number          INT,
      Quantity        NVARCHAR,
     );
     INSERT INTO #WaterConsumptionData
     (Number,
  Quantity
     )
    SELECT T.c.value('@Counter', 'INT') AS Number, --PumpNumber
       T.c.value('@Value', 'NVARCHAR') AS Quantity --Water Quanity
    FROM @xmlTags.nodes('MyControlTunnel/TunnelData/WaterConsumption') T(C);

  
  SET @CurrentStepComportmentNO=1;
  SET @CounterNo=1
  WHILE(@CurrentStepComportmentNO<=22)
  BEGIN
    SELECT @ActualQuantity=wc.Quantity
  FROM #WaterConsumptionData wc where wc.Number=@CounterNo
  IF NOT EXISTS(SELECT * FROM TCD.BatchStepWaterUsageData WHERE BatchId=@BatchID  AND StepCompartment =@CurrentStepComportmentNO AND ActualQuantity=@ActualQuantity )
  BEGIN
  IF(@BatchID IS NOT NULL AND @MeterID IS NOT NULL)
  BEGIN
  SET @CounterNo=@CounterNo+1;
   INSERT INTO TCD.BatchStepWaterUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
      EcolabWasherId
     )
     SELECT
     @BatchID,
     @CurrentStepComportmentNO,
     @ActualQuantity,
     @PartitionOn,
     @EcolabWasherId
      END 
	  END 
      SET  @CurrentStepComportmentNO=@CurrentStepComportmentNO+1;
   
  END;
 END;


GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlAlarmData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlAlarmData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE Procedure [TCD].[ProcessMyControlAlarmData]
	(
	@ControllerID int, 
	@VxML xML
	)
AS
BEGIN
   DECLARE 
			@StartDateTime			DATETIME2,
			@StopDateTime			DATETIME2,
			@AlarmNumber			INT,
			@MachineNumber			INT,
			@BatchNumber			INT,
			@DesiredValue			INT,
			@MeasuredValue			INT,
			@Status					INT,
			@ProgramNumber			INT,
			@GroupId				INT,
			@MachineId				INT,
			@BatchID				INT,
			@ECOLABAccountNumber	NVARCHAR(1000),
			@CurrentDay				DATE=CAST(GETUTCDATE() as date),
			@IsActive				INT,
			@IsTunnel				INT,
			@AlarmGroupMasterId		INT;
			
  	
	SELECT @MachineNumber=T.c.value('@MachineNumber', 'INT'),
			@StartDateTime=T.c.value('@StartDateTime', 'DATETIME'),
			@StopDateTime=T.c.value('@StopDateTime', 'DATETIME'),
			@ProgramNumber=T.c.value('@ProgramNumber', 'INT'),
			@BatchNumber=T.c.value('@BatchNumber', 'INT'),
			@AlarmNumber=T.c.value('@AlarmNumber', 'INT'),
			@DesiredValue=T.c.value('@DesiredValue', 'INT'),
			@MeasuredValue=T.c.value('@MeasuredValue', 'INT'),
			@Status=T.c.value('@Status', 'INT'),
			@IsTunnel=T.c.value('@IsTunnel', 'INT')

	FROM @VxML.nodes('MyControlAlarmData') T(C)

	--Inserts Xml Data
	INSERT INTO tcd.PLCXMLData
	    (
			 PLC_Type,
			 XML_Data,
			 XML_Type,
			 Batch_Number,
			 Time_Stamp
	    )
	       VALUES
				(
					 3,
					CONVERT(nvarchar(max), @VxML),
					 3,
					 ISNULL(@BatchNumber,0),		 
					 GETUTCDATE()
				);

	SELECT @ECOLABAccountNumber = EcolabAccountNumber FROM TCD.Plant

	IF (@stopdatetime is NULL)
	 BEGIN
		SELECT @IsActive = 1
	 END
	 ElSE
	 BEGIN
		SELECT @IsActive = 0
	 END
	
	IF NOT EXISTS(SELECT * FROM TCD.AlarmData 
		WHERE StartDate = @StartDateTime AND controllerID = @ControllerId AND AlarmCode = @AlarmNumber AND MachineInternalId = @MachineNumber AND BatchNumber = @BatchNumber)
	BEGIN

	SELECT @GroupId = GroupId, @MachineId = WasherId FROM TCD.MachineSetup WHERE MachineInternalId = @MachineNumber and ControllerId = @ControllerId and IsTunnel = @IsTunnel
	SELECT @BatchID = BatchId FROM TCD.BatchData WHERE MachineId = @MachineId and ControllerBatchId = @BatchNumber and CAST(StartDate as date)= @CurrentDay

	SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.ConduitController CC 
			INNER JOIN TCD.ControllerModelControllerTypeMapping CMCTM ON CMCTM.ControllerModelId = CC.ControllerModelId AND CMCTM.ControllerTypeId = CC.ControllerTypeId
			INNER JOIN TCD.AlarmGroupMsterVsControllerModelType AGMVCMT ON CMCTM.Id = AGMVCMT.ControllerModelTypeId
			INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
			WHERE AGMVCMT.AlarmCode = @AlarmNumber AND CC.ControllerId = @ControllerId

		INSERT INTO [TCD].[AlarmData] 
		   (EcoalabAccountNumber,
		   AlarmCode,
		   BatchId,
		   controllerID,
		   StartDate,
		   MachineInternalId,
		   ProgramId,
		   DesiredQuatity,
		   MeasuredQuantity,
		   TempStatus,
		   GroupId,
		   MachineId,
		   BatchNumber,
		   EndDate,
		   IsActive,
		   AlarmGroupMasterId
		   )
			  SELECT
			   @ECOLABAccountNumber,
			   @AlarmNumber,
			   @BatchID,
			   @ControllerId,
			   @StartDateTime,
			   @MachineNumber,
			   @ProgramNumber,
			   @DesiredValue,
			   @MeasuredValue,
			   @Status,
			   @GroupId,
			   @MachineId,
			   @BatchNumber,
			   @StopDateTime,
			   @IsActive,
			   @AlarmGroupMasterId
	END

	ELSE
	BEGIN
		IF (@StopDateTime is not null)
		BEGIN
		
		UPDATE tcd.AlarmData set EndDate = @StopDateTime, IsActive = 0
			WHERE StartDate = @StartDateTime AND controllerID = @ControllerId AND AlarmCode = @AlarmNumber AND MachineInternalId = @MachineNumber AND BatchNumber = @BatchNumber
		
		END
	END
			   	 
END 




GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlOnlineProductDosing]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlOnlineProductDosing]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessMyControlOnlineProductDosing](
	@ControllerID INT,
	@VxML         XML)
AS
	BEGIN
	    DECLARE @TheoreticalQty    DECIMAL(10, 6),
			  @RealQty           DECIMAL(10, 6),
			  @BatchNumber       INT,
			  @DosingPoint       INT,
			  @DosingNumber      INT,
			  @ValveNumber       INT,
			  @ProgramNumber     INT,
			  @WasherId          INT,
			  @MachineInternalId INT,
			  @PrevRealQty       DECIMAL(10, 6),
			  @ProductId         INT,
			  @PumpNum           INT,
			  @EquipmentType     INT,
			  @CompartmentNum    INT;
	    SELECT @TheoreticalQty = T.c.value('@TheoreticalQty','Decimal(10,6)'),
			 @RealQty = T.c.value('@RealQty', 'Decimal(10,6)'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @DosingPoint = T.c.value('@DosingPoint', 'INT'),
			 @DosingNumber = T.c.value('@DoseNumber', 'INT'),
			 @PumpNum = T.c.value('@PumpNum', 'INT'),
			 @ValveNumber = T.c.value('@ValveNumber', 'INT')
	    FROM @VxML.nodes('MyControlOnlineProductDosing') T(C);
		
       --Inserts Xml Data
		INSERT INTO tcd.PLCXMLData
	    (
			 PLC_Type,
			 XML_Data,
			 XML_Type,
			 Batch_Number,
			 Time_Stamp
	    )
	       VALUES
				(
					 3,
					CONVERT(nvarchar(max), @VxML),
					 1,
					 ISNULL(@BatchNumber,0),		 
					 GETUTCDATE()
				);


	    IF(@PumpNum >= 25
		  AND @PumpNum <= 26)
		   BEGIN
			  SET @EquipmentType = 2;
		   END;
	    ELSE
		   BEGIN
			  SET @EquipmentType = 1;
		   END;
	    IF(@DosingPoint >= 17
		  AND @DosingPoint <= 20)
		   BEGIN
			  SET @MachineInternalId = 1;
		   END;
	    ELSE
	    IF(@DosingPoint >= 21
		  AND @DosingPoint <= 24)
		   BEGIN
			  SET @MachineInternalId = 2;
		   END;
	    IF(@DosingPoint >= 1
		  AND @DosingPoint <= 16)
		   BEGIN
			  SET @MachineInternalId = @DosingPoint;
			  SELECT @WasherId = WasherId
			  FROM TCD.MachineSetup
			  WHERE ControllerID = @ControllerID
				   AND MachineInternalId = @MachineInternalId
				   AND IsTunnel = 0
				   AND IsDeleted = 0;
			  SELECT @ProductId = ProductId
			  FROM TCD.ControllerEquipmentSetup
			  WHERE ControllerEquipmentId = @PumpNum
				   AND ControllerID = @ControllerID;
		   END;
	    ELSE
	    IF(@DosingPoint >= 17
		  AND @DosingPoint <= 24)
		   BEGIN
			  SELECT @WasherId = WasherId
			  FROM TCD.MachineSetup
			  WHERE ControllerID = @ControllerID
				   AND MachineInternalId = @MachineInternalId
				   AND IsTunnel = 1
				   AND IsDeleted = 0;
			  SELECT @ProductId = CES.ProductId,
				    @CompartmentNum = TCEVM.CompartmentNumber
			  FROM tcd.ControllerEquipmentSetup CES
				  INNER JOIN TCD.
				  TunnelCompartmentEquipmentValveMapping TCEVM ON CES.
				  ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
			  WHERE CES.ControllerId = @ControllerID
				   AND CES.ControllerEquipmentTypeId = @EquipmentType
				   AND TCEVM.ValveNumber = @ValveNumber
				   AND CES.ControllerEquipmentId = @PumpNum;
		   END;
	    SELECT TOP 1 @PrevRealQty = RealQty
	    FROM TCD.WasherProductReading
	    WHERE ControllerId = @ControllerID
			AND WasherId = @WasherId
	    ORDER BY DateTimeStamp DESC;
	    IF(@ProductId IS NOT NULL)
		   BEGIN
			  IF(@PrevRealQty IS NULL
				OR @PrevRealQty != @RealQty)
				 BEGIN
					INSERT INTO [TCD].[WasherProductReading]
					(ControllerId,
					 WasherId,
					 MachineInternalId,
					 ProductId,
					 TheoreticalQty,
					 RealQty,
					 DosingPoint,
					 DosingNumber,
					 ProgramNumber,
					 BatchNumber,
					 ValveNumber,
					 DateTimeStamp
					)
						  SELECT @ControllerId,
							    @WasherId,
							    @MachineInternalId,
							    @ProductId,
							    @TheoreticalQty,
							    @RealQty,
							    @DosingPoint,
							    @DosingNumber,
							    @ProgramNumber,
							    @BatchNumber,
							    @ValveNumber,
							    GETUTCDATE();
				 END;
		   END;
	END

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlAnalogData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlAnalogData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [TCD].[ProcessMyControlAnalogData](
	@ControllerID INT,
	@VxML         XML)
AS
	BEGIN
	    DECLARE @TimeStamp    DATETIME
	    -- Getting the current UTC time 
	    SELECT
			 @TimeStamp = GETUTCDATE();

	    -- 1.Extracting xml data 
	    -- 2.And joining with sensor table
	    -- 3.Getting specific Sensor id by passing machine id and controller id and is_deleted(active sensor's)
	    -- 4.CTE will return table of columns i.e sensorid,sensortype,temparature,ph values
	    --Conventional washer sensor readings

	    WITH TempData
		    AS (SELECT
					s.SensorId,
					s.SensorType,
					T.c.value('@Temperature', 'DECIMAL(18,4)') temparature,
					T.c.value('@pH', 'DECIMAL(18,4)')          ph
			   FROM @VxML.nodes('MyControlAnalogData/WEAnalogData') T(c)
				   INNER JOIN TCD.Sensor s ON MachineCompartment =
			   (
				  SELECT TOP 1
					    ms.WasherId
				  FROM tcd.MachineSetup ms
				  WHERE ms.MachineInternalId = T.c.value('@WENumber','INT')
				  AND ms.ControllerId = @ControllerID
				  AND ms.IsDeleted = 0
				  AND ms.IsTunnel = 0
			   )
				   AND s.ControllerID = @controllerid
				   AND s.Is_deleted = 0) 
				   


		    -- inserting records into sensor reading table using merge statement
		    MERGE INTO tcd.sensorreading sr
		    USING
		    (
			   SELECT
					sensorid,
					sensortype,
					CASE
					    WHEN SensorType = 1
					    THEN Temparature		 --Temparature
					    WHEN SensorType = 2
					    THEN ph				 --PH
					END reading
			   FROM tempdata
		    ) temp
		    ON sr.sensorId = temp.sensorid
			  AND temp.reading =
		    (
			   SELECT TOP 1
					reading
			   FROM tcd.SensorReading
			   WHERE SensorId = temp.sensorid
			   ORDER BY
					  TimeStamp DESC
		    ) 

		    -- If records are not in the sensor reading tables
		    -- Sensor records are inserted depending on the sensor type	
	
			   WHEN NOT MATCHED AND(temp.reading <> NULL
							    OR temp.reading <> 0)
			   THEN INSERT(
						sensorid,
						reading,
						timestamp) VALUES
		    (
									   temp.sensorid,
									   temp.reading,
									   @TimeStamp
		    );

			--Inserts Xml Data
				   INSERT INTO tcd.PLCXMLData
	    (
			 PLC_Type,
			 XML_Data,
			 XML_Type,
			 Batch_Number,
			 Time_Stamp
	    )
	       VALUES
				(
					 3,
					CONVERT(nvarchar(max), @VxML),
					 4,
					 0,			 
					 GETUTCDATE()
				);
	END;

GO
 




------------------------End Xml Data Insertion------------------------------------------------------------
-----------------------Modified Alarm Stored Procedure-------------------------------------------------------

GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlAlarmData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlAlarmData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE Procedure [TCD].[ProcessMyControlAlarmData]
	(
	@ControllerID int, 
	@VxML xML
	)
AS
BEGIN
   DECLARE 
			@StartDateTime			DATETIME2,
			@StopDateTime			DATETIME2,
			@AlarmNumber			INT,
			@MachineNumber			INT,
			@BatchNumber			INT,
			@DesiredValue			INT,
			@MeasuredValue			INT,
			@Status					INT,
			@ProgramNumber			INT,
			@GroupId				INT,
			@MachineId				INT,
			@BatchID				INT,
			@ECOLABAccountNumber	NVARCHAR(1000),
			@CurrentDay				DATE=CAST(GETUTCDATE() as date),
			@IsActive				INT,
			@IsTunnel				INT,
			@AlarmGroupMasterId		INT;
			
  	
	SELECT @MachineNumber=T.c.value('@MachineNumber', 'INT'),
			@StartDateTime=T.c.value('@StartDateTime', 'DATETIME'),
			@StopDateTime=T.c.value('@StopDateTime', 'DATETIME'),
			@ProgramNumber=T.c.value('@ProgramNumber', 'INT'),
			@BatchNumber=T.c.value('@BatchNumber', 'INT'),
			@AlarmNumber=T.c.value('@AlarmNumber', 'INT'),
			@DesiredValue=T.c.value('@DesiredValue', 'INT'),
			@MeasuredValue=T.c.value('@MeasuredValue', 'INT'),
			@Status=T.c.value('@Status', 'INT'),
			@IsTunnel=T.c.value('@IsTunnel', 'INT')

	FROM @VxML.nodes('MyControlAlarmData') T(C)

	--Inserts Xml Data
	INSERT INTO tcd.PLCXMLData
	    (
			 PLC_Type,
			 XML_Data,
			 XML_Type,
			 Batch_Number,
			 Time_Stamp
	    )
	       VALUES
				(
					 3,
					CONVERT(nvarchar(max), @VxML),
					 3,
					 ISNULL(@BatchNumber,0),		 
					 GETUTCDATE()
				);

	SELECT @ECOLABAccountNumber = EcolabAccountNumber FROM TCD.Plant

	IF (@stopdatetime is NULL)
	 BEGIN
		SELECT @IsActive = 1
	 END
	 ElSE
	 BEGIN
		SELECT @IsActive = 0
	 END
	
	IF NOT EXISTS(SELECT * FROM TCD.AlarmData 
		WHERE StartDate = @StartDateTime AND controllerID = @ControllerId AND AlarmCode = @AlarmNumber AND MachineInternalId = @MachineNumber AND BatchNumber = @BatchNumber)
	BEGIN

	SELECT @GroupId = GroupId, @MachineId = WasherId FROM TCD.MachineSetup WHERE MachineInternalId = @MachineNumber and ControllerId = @ControllerId and IsTunnel = @IsTunnel
	SELECT @BatchID = BatchId FROM TCD.BatchData WHERE MachineId = @MachineId and ControllerBatchId = @BatchNumber and CAST(StartDate as date)= @CurrentDay

	SELECT TOP 1 @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.ConduitController CC 
			INNER JOIN TCD.ControllerModelControllerTypeMapping CMCTM ON CMCTM.ControllerModelId = CC.ControllerModelId AND CMCTM.ControllerTypeId = CC.ControllerTypeId
			INNER JOIN TCD.AlarmGroupMsterVsControllerModelType AGMVCMT ON CMCTM.Id = AGMVCMT.ControllerModelTypeId
			INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
			WHERE AGMVCMT.AlarmCode = @AlarmNumber AND CC.ControllerId = @ControllerId

		INSERT INTO [TCD].[AlarmData] 
		   (EcoalabAccountNumber,
		   AlarmCode,
		   BatchId,
		   controllerID,
		   StartDate,
		   MachineInternalId,
		   ProgramId,
		   DesiredQuatity,
		   MeasuredQuantity,
		   TempStatus,
		   GroupId,
		   MachineId,
		   BatchNumber,
		   EndDate,
		   IsActive,
		   AlarmGroupMasterId
		   )
			  SELECT
			   @ECOLABAccountNumber,
			   @AlarmNumber,
			   @BatchID,
			   @ControllerId,
			   @StartDateTime,
			   @MachineNumber,
			   @ProgramNumber,
			   @DesiredValue,
			   @MeasuredValue,
			   @Status,
			   @GroupId,
			   @MachineId,
			   @BatchNumber,
			   @StopDateTime,
			   @IsActive,
			   @AlarmGroupMasterId
	END

	ELSE
	BEGIN
		IF (@StopDateTime is not null)
		BEGIN
		
		UPDATE tcd.AlarmData set EndDate = @StopDateTime, IsActive = 0
			WHERE StartDate = @StartDateTime AND controllerID = @ControllerId AND AlarmCode = @AlarmNumber AND MachineInternalId = @MachineNumber AND BatchNumber = @BatchNumber
		
		END
	END
			   	 
END 
----------------------------------------------End Of Alarm Stored Procedure-----------------------------------------------------
Go

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlConventionalData_Online]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlConventionalData_Online]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessMyControlConventionalData_Online]
(
	@ControllerID   INT,
	@VxML           XML,
	@RedFlagShiftId INT OUTPUT
)
AS
	BEGIN
	    DECLARE @MachineNumber           INT,
			  @StepNumber              INT,
			  @StartDateTime           DATETIME,
			  @EndDateTime             DATETIME,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @PHValue                 INT,
			  @TemperatureMin          INT,
			  @TemperatureMax          INT,
			  @TempMinStatus           INT,
			  @TempMaxStatus           INT,
			  @BatchNumber             INT,
			  @WasherID                INT,
			  @WasherGroupID           INT,
			  @EcoLabWasherID          INT,
			  @ProgramMasterID         INT,
			  @PlantWasherNumber       INT,
			  @ShiftID                 INT,
			  @FrmParameterID          INT,
			  @PHParameterID           INT,
			  @PHParameterStatus       INT,
			  @BatchID                 INT,
			  @ShiftStartdate          DATETIME,
			  @ShiftName               NVARCHAR(50),
			  @XMLDataID               INT,
			  @TempParameter           INT,
			  @TemperatureMinParam     INT,
			  @TemperatureMaxParam     INT,
			  @TempMinStatusParam      INT,
			  @TempMaxStatusParam      INT,
			  @WashStepNo              INT,
			  @CurrencyCode            VARCHAR(50),
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @TargetTurnTime          INT,
			  @MeterID                INT,
			  @WaterConsumption1      DECIMAL(18,4),
			  @WaterConsumption2      DECIMAL(18,4),
			  @ModuleCount			  INT

	    SELECT @MachineNumber = T.c.value('@MachineNumber', 'INT'),
			 @StepNumber = T.c.value('@StepNumber', 'INT'),
			 @StartDateTime = T.c.value('@StartDateTime', 'DATETIME'),
			 @EndDateTime = T.c.value('@EndDateTime', 'DATETIME'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@NominalLoad', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'INT'),
			 @PHStatus = T.c.value('@PHStatus', 'INT'),
			 @PHValue = T.c.value('@PHValue', 'INT'),
			 @TemperatureMin = T.c.value('@TemperatureMin', 'INT'),
			 @TemperatureMax = T.c.value('@TemperatureMax', 'INT'),
			 @TempMaxStatus = T.c.value('@TemperatureMaxStatus', 'INT'),
			 @TempMinStatus = T.c.value('@TemperatreMinStatus', 'INT'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @WaterConsumption1=T.c.value('@WaterConsumption1','DECIMAL(18,4)'),
			 @WaterConsumption2=T.c.value('@WaterConsumption2','DECIMAL(18,4)')
	    FROM @VxML.nodes('MyControlConventionalData') T(C);

		---Deletes Xml Data from max of timestamp to previous 7 days

		delete  from tcd.PLCXMLData where convert(date,Time_Stamp) <= DATEADD(day,-7,(select max(convert(date,Time_Stamp)) from tcd.PLCXMLData))

     --Inserts Xml Data

		INSERT INTO tcd.PLCXMLData
	    (
			 PLC_Type,
			 XML_Data,
			 XML_Type,
			 Batch_Number,
			 Time_Stamp
	    )
	       VALUES
				(
					 3,
					CONVERT(nvarchar(max), @VxML),
					 1,
					 ISNULL(@BatchNumber,0),		 
					 GETUTCDATE()
				);


	    SELECT @PHParameterID = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'pH';
	    SELECT @PHParameterStatus = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'PH Status';
	    SELECT @TemperatureMinParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Mimum Temperature';
	    SELECT @TemperatureMaxParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Maximum Temperature';
	    SELECT @TempMinStatusParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Minimum Temperature Status';
	    SELECT @TempMaxStatusParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Max Temperature Status';
	    SELECT @WashStepNo = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'StepCompartment No';
	    SELECT @FrmParameterID = [Id]
	    FROM TCD.ConduitPArameters
	    WHERE Name = 'Formula Number';
	    DECLARE @ShiftMapping TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    INSERT INTO @ShiftMapping
	    (
		  ShiftId,
		  ShiftName,
		  ShiftStartdate
	    )
	    EXEC TCD.GetShiftStartDate
		    @StartDateTime
	    SELECT @ShiftID = ShiftID,
			 @ShiftStartdate = ShiftStartdate
	    FROM @ShiftMapping;
	    SELECT @WasherGroupID = GroupId,
			 @WasherID = WasherID
	    FROM TCD.MachineSetup ms
	    WHERE ControllerID = @ControllerID
			AND MachineInternalId = @MachineNumber
			AND IsTunnel = 0
			AND IsDeleted = 0;
	    IF(@EndDateTime = '1/1/1900')
		   SELECT @EndDateTime = NULL;
	    IF(@StartDateTime = '1/1/1900')
		   SELECT @StartDateTime = NULL;
	    IF(@WasherId IS NOT NULL)
		   BEGIN
			  SELECT @ProgramMasterId = Wps.ProgramId
			  FROM TCD.Washer Ws
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.ControllerID = Wg.ControllerId
				  INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.EcoLabAccountNumber
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wps.Is_Deleted = 0;
			  SELECT @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber,
				    @CurrencyCode = P.CurrencyCode,
				    @TargetTurnTime = w.TargetTurnTime * 60
			  FROM TCD.Washer w
				  INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.EcolabAccountNumber
			  WHERE w.WasherId = @WasherID;
	   END;
	    SELECT @BatchID = BatchID
	    FROM TCD.BatchData
	    WHERE MachineInternalID = @MachineNumber
			AND StartDate = @StartDateTime
			AND ControllerBatchId = @BatchNumber
			AND MachineID = @WasherID;

	    --Start Getting InjectionCount and StepCount
	    SELECT @StdInjectionSteps = COUNT(DISTINCT wdpm.
	    WasherDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) -
			 COUNT(DISTINCT wdpm.WasherDosingSetupId)
	    FROM TCD.WasherDosingProductMapping wdpm
		    RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm.
		    WasherDosingSetupId = wds.WasherDosingSetupId
	    WHERE wds.ControllerID = @ControllerID
			AND wds.ProgramNumber = @ProgramNumber;
	    --End Getting InjectionCount and StepCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramMasterId
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT @EcolabTextileCategoryId = pcp.
			  EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp.
				    ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    IF(@BatchID IS NULL)
		   BEGIN
			  INSERT INTO TCD.BatchData
			  (ControllerBatchID,
			   EcolabWasherId,
			   GroupId,
			   MachineInternalId,
			   PlantWasherNumber,
			   StartDate,
			   EndDate,
			   ProgramNumber,
			   ProgramMasterId,
			   MachineID,
			   ActualWeight,
			   StandardWeight,
			   CurrencyCode,
			   ShiftId,
			   PartitionOn,
			   StdInjectionSteps,
			   StdWashSteps,
			   EcolabTextileCategoryId,
			   ChainTextileCategoryId,
			   FormulaSegmentId,
			   EcolabSaturationId,
			   PlantProgramId,
			   EndDateFormula,
			   TargetTurnTime
			  )
			  VALUES
			  (
				    @BatchNumber,
				    @EcoLabWasherID,
				    @WasherGroupID,
				    @MachineNumber,
				    @PlantWasherNumber,
				    @StartDateTime,
				    @EndDateTime,
				    @ProgramNumber,
				    @ProgramMasterId,
				    @WasherID,
				    @Load,
				    @NominalLoad,
				    @CurrencyCode,
				    @ShiftID,
				    @ShiftStartdate,
				    @StdInjectionSteps,
				    @StdWashSteps,
				    @EcolabTextileCategoryId,
				    @ChainTextileCategoryId,
				    @FormulaSegmentId,
				    @EcolabSaturationId,
				    @PlantProgramId,
				    @EndDateTime,
				    @TargetTurnTime
			  );
			  SELECT @BatchID = SCOPE_IDENTITY();
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM TCD.BatchParameters
				 WHERE BatchId = @BatchID
					  AND ParameterID = 38
			   )
			   BEGIN
			   IF(@StdWashSteps <> 0
				 OR @StdWashSteps <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
					   BatchId,
					   EcolabWasherId,
					   ParameterId,
					   ParameterValue,
					   PartitionOn
					)
					SELECT @BatchID,
						  @EcoLabWasherID,
						  38,
						  @StdWashSteps,
						  @ShiftStartdate;
				  END
			END;

			  --End Date  Time  is Null 
			  UPDATE TCD.BatchData
			    SET
				   EndDate = GETUTCDATE()
			  WHERE MachineInternalID = @MachineNumber
				   AND StartDate <> @StartDateTime
				   AND EndDate IS NULL
				   AND ControllerBatchId <> @BatchNumber
				   AND MachineId = @WasherId;	
																  		
			  -- Program Number	
			  IF(@ProgramNumber IS NOT NULL
				AND @ProgramNumber > 0)
				 BEGIN
					IF NOT EXISTS
					(
					    SELECT *
					    FROM TCD.WasherReading
					    WHERE WasherId = @WasherID
							AND ParameterID = @FrmParameterID
							AND DateTimeStamp = @StartDateTime
					)
					    BEGIN
						   INSERT INTO TCD.WasherReading
						   (WasherID,
						    ParameterID,
						    ParameterValue,
						    DateTimeStamp,
						    EcoLabWasherID,
						    Partitionon
						   )
						   VALUES
						   (
								@WasherID,
								@FrmParameterID,
								@ProgramNumber,
								@StartDateTime,
								@EcoLabWasherID,
								@ShiftStartdate
						   );
					    END;
				 END;
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM [TCD].[BatchCustomerData]
				 WHERE BatchID = @BatchId
					  AND @CustomerNumber IS NOT NULL
			  )
				 BEGIN
					INSERT INTO [TCD].[BatchCustomerData]
					([BatchId],
					 CustomerID,
					 [Weight],
					 PartitionOn,
					 EcolabWasherId
					)
					VALUES
					(
						  @BatchID,
						  @CustomerNumber,
						  @Load,
						  @ShiftStartdate,
						  @EcolabWasherID
					);
				 END;
		   END;

	    -- PH Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @PHParameterID
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@PHValue <> 0
				OR @PHValue <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @PHParameterID,
							    @PHValue,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 
	 
	    -- PH Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @PHParameterStatus
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@PHStatus <> 0
				OR @PHStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @PHParameterStatus,
							    @PHStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Min Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TemperatureMinParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TemperatureMin <> 0
				OR @TemperatureMin <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TemperatureMinParam,
							    @TemperatureMin,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Max Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TemperatureMaxParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TemperatureMax <> 0
				OR @TemperatureMax <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TemperatureMaxParam,
							    @TemperatureMax,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Min Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TempMinStatusParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TempMinStatus <> 0
				OR @TempMinStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TempMinStatusParam,
							    @TempMinStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Max Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TempMaxStatusParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TempMaxStatus <> 0
				OR @TempMaxStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TempMaxStatusParam,
							    @TempMaxStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- StepCompartment No
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @WashStepNo
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@StepNumber <> 0
				OR @StepNumber <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @WashStepNo,
							    @StepNumber,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END;
		   --Start water consumption per batch

	SELECT @MeterID=MeterId
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@MachineNumber
   SELECT @ModuleCount= COUNT(1) FROM TCD.ModuleReading WHERE Reading =@WaterConsumption1 AND ModuleId = @MeterID
  IF (@ModuleCount=0)
  BEGIN
  IF(@WaterConsumption1 IS NOT NULL  AND @MeterID IS NOT NULL)
  BEGIN
   INSERT INTO TCD.ModuleReading
     (ModuleId,
      ModuleTypeId,
      Reading,
      TimeStamp
     )
     SELECT
     @MeterID,
     2,
     @WaterConsumption1,
     GETUTCDATE()
  END
 END  
 -- set  @ModuleCount=@@ROWCOUNT
  SELECT @ModuleCount= COUNT(1) FROM TCD.ModuleReading WHERE Reading =@WaterConsumption2 AND ModuleId = @MeterID
  IF (@ModuleCount=0)
  BEGIN
  IF(@WaterConsumption2 IS NOT NULL  AND @MeterID IS NOT NULL)
  BEGIN
   INSERT INTO TCD.ModuleReading
     (ModuleId,
      ModuleTypeId,
      Reading,
      TimeStamp
     )
     SELECT
     @MeterID, 
     2,
     @WaterConsumption2,
     GETUTCDATE()
  END
      END   
	 --End water consumption per batch
 END;

 
 
 GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlConventionalData_CompletedBatches]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlConventionalData_CompletedBatches]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessMyControlConventionalData_CompletedBatches](
	@ControllerID   INT,
	@VxML           XML,
	@PLCPointer     INT,
	@ReadPointer    INT,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @MachineNumber           INT,
			  @StartDateTime           DATETIME,
			  @EndDateTime             DATETIME,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @PHValue                 INT,
			  @TemperatureMin          INT,
			  @TemperatureMax          INT,
			  @TempMinStatus           INT,
			  @TempMaxStatus           INT,
			  @BatchNumber             INT,
			  @WasherID                INT,
			  @WasherGroupID           INT,
			  @EcoLabWasherID          INT,
			  @ProgramMasterID         INT,
			  @PlantWasherNumber       INT,
			  @ShiftID                 INT,
			  @BatchID                 INT,
			  @ShiftStartdate          DATETIME,
			  @LastStep                INT,
			  @CurrentStep             INT,
			  @CurrentStepTime         DATETIME,
			  @MinTempParamID          INT,
			  @MaxTempParamID          INT,
			  @MinTempStatuParamID     INT,
			  @MaxTempStatusParamID    INT,
			  @PHStatusParamID         INT,
			  @PHValueParamID          INT,
			  @CurrencyCode            VARCHAR(50),
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @ActualInjSteps          INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @TargetTurnTime          INT,
			  @PreviousShiftId         INT,
			  @CurrentShiftId          INT,
			  @MeterID                 INT,
			  @StepComportment         INT,
			  @Stepno                  INT,
			  @quantity                INT,
			  @productid               INT,
			  @Price                   DECIMAL(18, 4),
			  @StandardQty             DECIMAL(18, 4),
			  @TimeStamp               DATETIME2(7),
			  @MaxWashertGroupCapacity INT,
			  @InjectionNumber         INT,
			   @WaterConsumption1       DECIMAL(10,6),
			  @WaterConsumption2       DECIMAL(10,6),
			  @EnergyCount             INT
	    SELECT
			 @MachineNumber = T.c.value('@MachineNumber', 'INT'),
			 @StartDateTime = T.c.value('@StartDateTime', 'DateTime'),
			 @EndDateTime = T.c.value('@EndDateTime', 'DateTime'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@NominalLoad', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'INT'),
			 @PHStatus = T.c.value('@PHStatus', 'INT'),
			 @PHValue = T.c.value('@PHValue', 'INT'),
			 @TemperatureMin = T.c.value('@TemperatureMin', 'INT'),
			 @TemperatureMax = T.c.value('@TemperatureMax', 'INT'),
			 @TempMaxStatus = T.c.value('@TemperatureMaxStatus', 'INT'),
			 @TempMinStatus = T.c.value('@TemperatreMinStatus', 'INT'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @WaterConsumption1 = T.c.value('@WaterConsumption1',
			 'NVARCHAR'
									 ),
			 @WaterConsumption2 = T.c.value('@WaterConsumption2',
			 'NVARCHAR'
									 )
	    FROM @VxML.nodes('MyControlConventionalData') T(C);

		--Inserts Xml Data
		INSERT INTO tcd.PLCXMLData
	    (
			 PLC_Type,
			 XML_Data,
			 XML_Type,
			 Batch_Number,
			 Time_Stamp
	    )
	       VALUES
				(
					 3,
					CONVERT(nvarchar(max), @VxML),
					 2,
					ISNULL(@BatchNumber,0),		 
					 GETUTCDATE()
				);

	    DECLARE @ShiftMapping TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    INSERT INTO @ShiftMapping
	    (
			 ShiftId,
			 ShiftName,
			 ShiftStartdate
	    )
	    EXEC TCD.GetShiftStartDate
		    @StartDateTime;
	    SELECT
			 @ShiftID = ShiftID,
			 @ShiftStartdate = ShiftStartdate
	    FROM @ShiftMapping;
	    SELECT
			 @WasherGroupID = GroupId,
			 @WasherID = WasherID
	    FROM TCD.MachineSetup ms
	    WHERE ControllerID = @ControllerID
			AND MachineInternalId = @MachineNumber
			AND IsTunnel = 0
			AND IsDeleted = 0;
	    IF(@WasherId IS NOT NULL)
		   BEGIN
			  SELECT
				    @ProgramMasterId = Wps.ProgramId
			  FROM TCD.Washer Ws
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws
				  .WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =
				  Mst.GroupId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.
				  ControllerID = Wg.ControllerId
				  INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber =
				  Ws.EcoLabAccountNumber
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wps.Is_Deleted = 0;
			  SELECT
				    @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber,
				    @CurrencyCode = P.CurrencyCode,
				    @TargetTurnTime = w.TargetTurnTime * 60
			  FROM TCD.Washer w
				  INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.
				  EcolabAccountNumber
			  WHERE w.WasherId = @WasherID;
		   END;
	    SELECT
			 @BatchID = BatchID
	    FROM TCD.BatchData
	    WHERE MachineInternalID = @MachineNumber
			AND StartDate = @StartDateTime
			AND ControllerBatchId = @BatchNumber
			AND MachineID = @WasherID;

	    --Start Getting InjectionCount and StepCount

	    SELECT
			 @StdInjectionSteps = COUNT(DISTINCT wdpm.
			 WasherDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) -
			 COUNT(DISTINCT wdpm.WasherDosingSetupId)
	    FROM TCD.WasherDosingProductMapping wdpm
		    RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm.
		    WasherDosingSetupId = wds.WasherDosingSetupId
	    WHERE wds.ControllerID = @ControllerID
			AND wds.ProgramNumber = @ProgramNumber;

	    --End Getting InjectionCount and StepCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT
			 @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramMasterId
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT
				    @EcolabTextileCategoryId = pcp.
				    EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp.
				    ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    IF(@BatchID IS NULL)
		   BEGIN

			  --Start Rollup for previous completed shift
			  IF(CAST(@StartDateTime AS DATE) < CAST(GETUTCDATE() AS
			  DATE))
				 BEGIN
					SELECT TOP 1
						  @PreviousShiftId = ShiftId
					FROM TCD.BatchData
					WHERE MachineId = @WasherId
					ORDER BY
						    StartDate DESC;
					SELECT TOP 1
						  @CurrentShiftId = ShiftId
					FROM @ShiftMapping;
					IF(@CurrentShiftId != @PreviousShiftId)
					    BEGIN
						   EXEC TCD.ProductionShiftDataRollup
							   @PreviousShiftId,
							   @RedFlagShiftId OUTPUT;
						   IF(@RedFlagShiftId IS NULL)
							  BEGIN
								 SET @RedFlagShiftId =
								 @PreviousShiftId;
							  END;
					    END;
				 END;
			  --End Rollup for previous completed shift

			  INSERT INTO TCD.BatchData
			  (
				    ControllerBatchID,
				    EcolabWasherId,
				    GroupId,
				    MachineInternalId,
				    PlantWasherNumber,
				    StartDate,
				    EndDate,
				    ProgramNumber,
				    ProgramMasterId,
				    MachineID,
				    ActualWeight,
				    StandardWeight,
				    CurrencyCode,
				    ShiftId,
				    PartitionOn,
				    StdInjectionSteps,
				    StdWashSteps,
				    EcolabTextileCategoryId,
				    ChainTextileCategoryId,
				    FormulaSegmentId,
				    EcolabSaturationId,
				    PlantProgramId,
				    EndDateFormula,
				    TargetTurnTime
			  )
			  VALUES
			  (
				    @BatchNumber,
				    @EcoLabWasherID,
				    @WasherGroupID,
				    @MachineNumber,
				    @PlantWasherNumber,
				    @StartDateTime,
				    @EndDateTime,
				    @ProgramNumber,
				    @ProgramMasterId,
				    @WasherID,
				    @Load,
				    @NominalLoad,
				    @CurrencyCode,
				    @ShiftID,
				    @ShiftStartdate,
				    @StdInjectionSteps,
				    @StdWashSteps,
				    @EcolabTextileCategoryId,
				    @ChainTextileCategoryId,
				    @FormulaSegmentId,
				    @EcolabSaturationId,
				    @PlantProgramId,
				    @EndDateTime,
				    @TargetTurnTime
			  );
			  SELECT
				    @BatchID = SCOPE_IDENTITY();
			  IF NOT EXISTS
			  (
				 SELECT
					   *
				 FROM TCD.BatchParameters
				 WHERE BatchId = @BatchID
					  AND ParameterID = 38
			  )
				 BEGIN
					IF(@StdWashSteps > 0
					   OR @StdWashSteps <> NULL)
					    INSERT INTO TCD.BatchParameters
					    (
							 BatchId,
							 EcolabWasherId,
							 ParameterId,
							 ParameterValue,
							 PartitionOn
					    )
					    SELECT
							 @BatchID,
							 @EcoLabWasherID,
							 38,
							 @StdWashSteps,
							 @ShiftStartdate;
				 END;
		   END;
	    ELSE
		   BEGIN
			  UPDATE tcd.BatchData
			    SET
				   EndDate = @EndDateTime,
				   EndDateFormula = @EndDateTime,
				   ProgramNumber = @ProgramNumber,
				   ProgramMasterId = @ProgramMasterID,
				   ActualWeight = @Load,
				   SyncReady = 1
			  WHERE
				   BatchID = @BatchID;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				1
		   FROM [TCD].[BatchCustomerData]
		   WHERE BatchID = @BatchId
			    AND @CustomerNumber IS NOT NULL
	    )
		   BEGIN
			  INSERT INTO [TCD].[BatchCustomerData]
			  (
				    [BatchId],
				    CustomerID,
				    [Weight],
				    PartitionOn,
				    EcolabWasherId
			  )
			  VALUES
			  (
				    @BatchID,
				    @CustomerNumber,
				    @Load,
				    @ShiftStartdate,
				    @EcolabWasherID
			  );
		   END;
	    ELSE
	    IF(@CustomerNumber > 0)
		   BEGIN
			  UPDATE [TCD].[BatchCustomerData]
			    SET
				   CustomerID = @CustomerNumber,
				   [Weight] = @Load
			  WHERE
				   BatchID = @BatchId;
		   END;
	    CREATE TABLE #Dosing
	    (
		    equipmentNo INT,
		    StepNo      INT,
		    Qty         DECIMAL(10, 6)
	    );
	    INSERT INTO #Dosing
	    SELECT
			 T.c.value('@Equipment', 'INT'),
			 T.c.value('@stepNo', 'INT'),
			 T.c.value('@Qty', 'Decimal(10,6)')
	    FROM @VxML.nodes('MyControlConventionalData/DosingData/Dosing') T
	    (C)
	    WHERE T.c.value('@Qty', 'Decimal(10,6)') > 0;
	    CREATE TABLE #StepTime
	    (
		    Number    INT,
		    [Time]    INT,
		    StartTime DATETIME,
		    EndTime   DATETIME
	    );
	    INSERT INTO #StepTime
	    (
			 Number,
			 [Time]
	    )
	    SELECT
			 T.c.value('@Number', 'INT'),
			 T.c.value('@Time', 'INT')
	    FROM @VxML.nodes('MyControlConventionalData/StepTime/Step') T(C);
	    CREATE TABLE #TimeStamp
	    (
		    Step_Number INT,
		    Time_Stamp  INT
	    );
	
	    --For Calculating TIME_STAMP

	    WITH TempTable
		    AS (SELECT DISTINCT
					Number
			   FROM #StepTime)
		    INSERT INTO #TimeStamp
		    (
				 Step_Number,
				 Time_Stamp
		    )
		    SELECT
				 b.Number,
				 SUM(t.Time) Time_Stamp
		    FROM TempTable b
			    INNER JOIN #StepTime t ON b.Number >= t.Number
		    GROUP BY
				   b.Number;
	    CREATE TABLE #BatchProductData
	    (
		    equipmentNo INT,
		    StepNo      INT,
		    Qty         DECIMAL(10, 6),
		    Time_Stamp  DATETIME2(7),
		    ProductId   INT,
		    Row_No      INT
	    );
	    INSERT INTO #BatchProductData
	    (
			 EquipmentNo,
			 StepNo,
			 Qty,
			 Time_Stamp,
			 ProductId,
			 Row_No
	    )
	    SELECT
			 d.equipmentNo,
			 d.StepNo,
			 d.Qty,
			 DATEADD(ss, ts.Time_Stamp, @StartDateTime),
			 ces.ProductId,
			 ROW_NUMBER() OVER(ORDER BY d.StepNo DESC) AS Row
	    FROM #Dosing d
		    INNER JOIN #TimeStamp ts ON d.StepNo = ts.Step_Number
		    INNER JOIN tcd.ControllerEquipmentSetup ces ON ces.
		    ControllerEquipmentId = d.equipmentNo
	    WHERE d.equipmentNo > 0
			AND d.Qty > 0
			AND ControllerID = @ControllerID
			AND ces.ProductId IS NOT NULL;
	    SELECT
			 @MaxWashertGroupCapacity = MAX(ws.MaxLoad)
	    FROM TCD.Washer WS
		    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.
		    GroupId
	    WHERE Mst.GroupId = @WasherGroupID;
	    DECLARE @Counter INT;
	    SET @counter = 1;
	    WHILE(@counter <=
		    (
			   SELECT
					COUNT(ROW_No)
			   FROM #BatchProductData bpd
		    ))
		   BEGIN
			  SELECT
				    @stepno = bpd.StepNo,
				    @quantity = bpd.Qty,
				    @productid = bpd.ProductId,
				    @timestamp = bpd.Time_Stamp
			  FROM #BatchProductData bpd
			  WHERE bpd.Row_No = @counter
			  ORDER BY
					 bpd.StepNo;
			  SELECT
				    @InjectionNumber = Wdpm.InjectionNumber,
				    @standardqty = ((@NominalLoad / CONVERT( DECIMAL(
				    10, 2), 100)) * Wdpm.Quantity * Ws.MaxLoad) /
				    CONVERT(DECIMAL(10, 2), 100),
				    @price = ((@NominalLoad / CONVERT(       DECIMAL(
				    10, 2), 100)) * Wdpm.Quantity *
				    @MaxWashertGroupCapacity) / CONVERT(DECIMAL(10, 2),
				    100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID)
			  FROM TCD.Washer WS
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws
				  .WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =
				  Mst.GroupId
				  INNER JOIN TCD.WasherGroupType WgT ON WgT.
				  WasherGroupTypeId = Wg.WasherGroupTypeId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.
				  ControllerID = Wg.ControllerId
				  INNER JOIN TCD.WasherDosingSetup Wds ON Wds.
				  WasherProgramSetupId = Wps.WasherProgramSetupId
				  INNER JOIN TCD.WasherDosingProductMapping Wdpm ON
				  Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
				  INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.
				  ProductId = Wdpm.ProductId
				  INNER JOIN TCD.BatchData Bd ON Bd.MachineId = Ws.
				  WasherId
			  WHERE Ws.WasherId = @WasherID
				   AND Wps.ProgramNumber = @ProgramNumber
				   --AND Wdpm.InjectionNumber = @stepno
				   AND Bd.BatchId = @BatchID
				   AND Wps.Is_Deleted = 0
				   AND Pdm.Is_Deleted = 0;
			  INSERT INTO TCD.BatchProductData
			  (
				    BatchId,
				    StepCompartment,
				    ActualQuantity,
				    StandardQuantity,
				    Price,
				    PartitionOn,
				    EcolabWasherId,
				    ProductId,
				    TimeStamp,
				    InjectionNumber
			  )
			  VALUES
			  (
				    @BatchID,
				    @stepno,
				    @quantity,
				    @standardqty,
				    @price,
				    @ShiftStartdate,
				    @EcolabWasherId,
				    @productid,
				    @timestamp,
				    @InjectionNumber
			  );
			  SET @counter = @counter + 1;
		   END;
	    --END For calculating TIMESTAMP
	    --Start Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
	    SELECT
			 @ActualInjSteps = COUNT(DISTINCT StepNo)
	    FROM #Dosing;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE ParameterId = 37
			    AND batchid = @BatchID
			    AND @ActualInjSteps > 0
	    )
		   BEGIN
			  IF(@ActualInjSteps > 0
				OR @ActualInjSteps IS NOT NULL)
				 INSERT INTO TCD.BatchParameters
				 (
					   BatchId,
					   EcolabWasherId,
					   ParameterId,
					   ParameterValue,
					   PartitionOn
				 )
				 SELECT
					   @BatchId,
					   @EcolabWasherId,
					   37,
					   @ActualInjSteps,
					   @ShiftStartDate;
		   END;
	    ELSE
		   BEGIN
			  UPDATE TCD.BatchParameters
			    SET
				   ParameterValue = @ActualInjSteps
			  WHERE
				   ParameterId = 37
				   AND batchid = @BatchID;
		   END;
	    SELECT
			 @LastStep = MAX([Number])
	    FROM #StepTime
	    WHERE [Time] > 0;
	    SELECT
			 @CurrentStep = 1,
			 @CurrentStepTime = @StartDateTime;
	    WHILE(@CurrentStep <= @LastStep)
		   BEGIN
			  UPDATE #StepTime
			    SET
				   StartTime = @CurrentStepTime,
				   EndTime = DATEADD(ss, [time], @CurrentStepTime)
			  WHERE
				   Number = @CurrentStep;
			  SELECT
				    @CurrentStepTime = EndTime
			  FROM #StepTime
			  WHERE Number = @CurrentStep;
			  SELECT
				    @CurrentStep = @CurrentStep + 1;
		   END;
	    INSERT INTO [TCD].[BatchWashStepData]
	    (
			 BatchID,
			 StepCompartment,
			 StartTime,
			 EndTime,
			 PartitionOn,
			 EcolabWasherId
	    )
	    SELECT
			 @BatchID,
			 Number,
			 StartTime,
			 EndTime,
			 @ShiftStartdate,
			 @EcoLabWasherID
	    FROM #StepTime
	    WHERE Number <= @LastStep;
	    SELECT
			 @MinTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Mimum Temperature';
	    SELECT
			 @MaxTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Maximum Temperature';
	    SELECT
			 @MaxTempStatusParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Max Temperature Status';
	    SELECT
			 @MinTempStatuParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Minimum Temperature Status';
	    SELECT
			 @PHValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH';
	    SELECT
			 @PHStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH Status';
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MinTempParamID
	    )
		   BEGIN
			  IF(@TemperatureMin <> 0
				OR @TemperatureMin <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MinTempParamID,
						  @TemperatureMin,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MaxTempParamID
	    )
		   BEGIN
			  IF(@TemperatureMax <> 0
				OR @TemperatureMax <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MaxTempParamID,
						  @TemperatureMax,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MaxTempStatusParamID
	    )
		   BEGIN
			  IF(@TempMaxStatus <> 0
				OR @TempMaxStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MaxTempStatusParamID,
						  @TempMaxStatus,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MinTempStatuParamID
	    )
		   BEGIN
			  IF(@TempMinStatus <> 0
				OR @TempMinStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MinTempStatuParamID,
						  @TempMinStatus,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF(@PHStatus <> 0
		  OR @PHStatus <> NULL)
		   BEGIN
			  INSERT INTO TCD.BatchParameters
			  (
				    BatchId,
				    EcolabWasherId,
				    ParameterId,
				    ParameterValue,
				    PartitionOn
			  )
			  VALUES
			  (
				    @BatchID,
				    @EcoLabWasherID,
				    @PHStatusParamID,
				    @PHStatus,
				    @ShiftStartdate
			  );
		   END;
	    IF(@PHValue <> 0
		  OR @PHValue <> NULL)
		   BEGIN
			  INSERT INTO TCD.BatchParameters
			  (
				    BatchId,
				    EcolabWasherId,
				    ParameterId,
				    ParameterValue,
				    PartitionOn
			  )
			  VALUES
			  (
				    @BatchID,
				    @EcoLabWasherID,
				    @PHValueParamID,
				    @PHValue,
				    @ShiftStartdate
			  );
		   END;
	    EXEC TCD.ProcessMyControlProductionWaterConsumptionData
		    @BatchID,
		    @VxML,
		    @ShiftStartDate;
	    DROP TABLE #BatchProductData;
	    DROP TABLE #Dosing;
	    DROP TABLE #StepTime;
	    DROP TABLE #TimeStamp;

		--Start water consumption per batch

	SELECT @MeterID=MeterId,@StepComportment=MachineCompartment
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@MachineNumber


   SELECT @EnergyCount=COUNT(1) FROM TCd.BatchEnergyUsageData WHERE BatchId =@BatchID AND StepCompartment =@StepComportment AND ActualQuantity=@WaterConsumption1
    IF(@EnergyCount=0)
  BEGIN
  IF(ISNULL(@WaterConsumption1,0)>0  AND ISNULL(@MeterID,0)>0  AND ISNULL(@StepComportment,0)>0)
  BEGIN
   INSERT INTO TCD.BatchEnergyUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
	  EcolabWasherId
     )
     SELECT
     @BatchID,
     @StepComportment,
     @WaterConsumption1,
     @ShiftStartdate,
	 @EcoLabWasherID
	 END
      END  
SELECT @EnergyCount=COUNT(1) FROM TCd.BatchEnergyUsageData WHERE BatchId =@BatchID AND StepCompartment =@StepComportment AND ActualQuantity=@WaterConsumption2
 IF(@EnergyCount=0)
  BEGIN
  IF(ISNULL(@WaterConsumption2,0)>0  AND ISNULL(@MeterID,0)>0  AND ISNULL(@StepComportment,0)>0)
  BEGIN
   INSERT INTO TCD.BatchEnergyUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
	  EcolabWasherId
     )
     SELECT
     @BatchID,
     @StepComportment,
     @WaterConsumption2,
     @ShiftStartdate,
	 @EcoLabWasherID
	 END
      END   
	  --End water consumption per batch
	END;
	 
	 GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlTunnelWasherOnlineData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlTunnelWasherOnlineData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ProcessMyControlTunnelWasherOnlineData](
	@ControllerID   INT,
	@xmlTags        XML,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @BatchID                 INT,
			  @WasherID                INT,
			  @EcolabWasherId          INT,
			  @CurrencyCode            VARCHAR(50),
			  @MachineInternalId       INT,
			  @WasherGroupID           INT,
			  @PlantWasherNumber       INT,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @BatchNumber             INT,
			  @TargetTurnTime          INT,
			  @PartitionOn             DATETIME,
			  @BatchStartTime          DATETIME,
			  @ProgramID               INT,
			  @NumberOfCompartments    INT,
			  @TransferSignalId        INT,
			  @BatchShiftId            INT,
			  @compartmentID           INT,
			  @TunnelXML               XML,
			  @TempXML                 XML,
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @CurrentStepComportmentNO INT,
               @CounterNO               INT,
               @MeterID                 INT,
              @ActualQuantity          DECIMAL(10,6),
			  @WasherModuleCount       INT

	    SELECT @TransferSignalId = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Transfer Signal';
	    CREATE TABLE #Batches
	    (
		    BatchNumber   INT,
		    StartDateTime DATETIME
	    );
	    -- SET @compartmentID = 1;

	    SELECT @TempXML = T.c.query('.')
	    FROM @xmlTags.nodes('MyControlTunnel') AS T(c);

	    SELECT @MachineInternalID = T.c.value('@MachineNumber', 'int')
	    FROM @TempXML.nodes('MyControlTunnel') AS T(c);
	    SELECT @EcolabWasherID = EcolabWasherId,
			 @WasherGroupID = Wg.WasherGroupId,
			 @PlantWasherNumber = PlantWasherNumber,
			 @WasherID = ws.WasherId,
			 @CurrencyCode = P.CurrencyCode,
			 @NumberOfCompartments = Mst.NumberofComp
	    FROM TCD.Washer AS Ws
		    INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = Ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.
		    GroupId
		    INNER JOIN TCD.WasherGroupType AS WgT ON WgT.
		    WasherGroupTypeId = Wg.WasherGroupTypeId
		    INNER JOIN TCD.ConduitController AS Ctrl ON Ctrl.
		    ControllerId = Mst.ControllerId
		    INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.
		    EcoLabAccountNumber
	    WHERE Ctrl.ControllerID = @ControllerID
			AND mst.MachineInternalId = @MachineInternalID
			AND Mst.IsTunnel = 1 AND Mst.IsDeleted =0;
	    SET @compartmentID = @NumberOfCompartments;
	    WHILE(@compartmentID <= @NumberOfCompartments
			AND @compartmentID > 0)
		   BEGIN
			  SELECT @TunnelXML = T.c.query('.')
			  FROM @xmlTags.nodes('MyControlTunnel/TunnelData') AS T(c)
			  WHERE T.c.value('@CompartmentNumber', 'INT') =
			  @compartmentID;
			  SELECT @MachineInternalID = T.c.value('@MachineNumber',
			  'int'
										    ),
				    @BatchNumber = T.c.value('@BatchNumber', 'INT'),
				    @BatchStartTime = T.c.value('@StartDateTime',
				    'DateTime'
										 ),
				    @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
				    @Load = T.c.value('@Load', 'Decimal(10,6)'),
				    @NominalLoad = T.c.value('@Nominalload',
				    'Decimal(10,6)'
									   ),
				    @CustomerNumber = T.c.value('@CustomerNumber',
				    'int'
										 ),
				    @PHStatus = T.c.value('@pHStatus', 'int')
			  FROM @TunnelXML.nodes('TunnelData') AS T(c);

			  --Inserts Xml Data
		INSERT INTO tcd.PLCXMLData
	    (
			 PLC_Type,
			 XML_Data,
			 XML_Type,
			 Batch_Number,
			 Time_Stamp
	    )
	       VALUES
				(
					 3,
					CONVERT(nvarchar(max), @xmlTags),
					 1,
					 ISNULL(@BatchNumber,0),			 
					 GETUTCDATE()
				);

			  DECLARE @ShiftStartDateTemp TABLE
			  (
				  ShiftId        INT,
				  ShiftName      NVARCHAR(50),
				  ShiftStartdate DATETIME
			  );
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchStartTime
			  SELECT @BatchShiftId = ShiftID,
				    @PartitionOn = ShiftStartdate
			  FROM @ShiftStartDateTemp;
			  IF(@ProgramNumber = 0
				OR @BatchNumber = 1)
				 BEGIN
					SELECT @compartmentID = @compartmentID - 1;
					CONTINUE;
				 END;
			  SELECT @ProgramID = ProgramId,
				    @TargetTurnTime = 3600 / (tps.TotalRunTime /
				    @NumberOfCompartments)
			  FROM TCD.TunnelProgramSetup AS tps
			  WHERE tps.WasherGroupId = @WasherGroupID
				   AND tps.is_deleted = 0
				   AND ProgramNumber = @ProgramNumber;
			  INSERT INTO #Batches
			  (BatchNumber,
			   StartDateTime
			  )
				    SELECT @BatchNumber,
						 @BatchStartTime;
			  SELECT @BatchID = NULL;
			  SELECT @BatchID = BatchID
			  FROM TCD.BatchData AS BD
			  WHERE BD.ControllerBatchId = @BatchNumber
				   AND BD.StartDate = @BatchStartTime
				   AND BD.MachineId = @WasherID;
			  --Start Getting InjectionCount,StepCount And ProductCount
			  SELECT @StdInjectionSteps = COUNT(tdpm.
			  TunnelDosingSetupId),
				    @StdWashSteps = COUNT(DISTINCT tds.
				    TunnelDosingSetupId) - COUNT(tdpm.
				    TunnelDosingSetupId)
			  FROM tcd.TunnelDosingProductMapping AS tdpm
				  RIGHT JOIN tcd.TunnelDosingSetup AS tds ON tdpm.
				  TunnelDosingSetupId = tds.TunnelDosingSetupId
			  WHERE tds.GroupId = @WasherGroupID
				   AND tds.ProgramNumber = @ProgramNumber;
			  --End Getting InjectionCount,StepCount And ProductCount
			  --Start-----ProgramMasterID logic for PlantChainProgram
			  SELECT @PlantProgramId = pm.PlantProgramId,
				    @EcolabTextileCategoryId = pm.
				    EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pm.ChainTextileId,
				    @FormulaSegmentId = pm.FormulaSegmentId,
				    @EcolabSaturationId = pm.EcolabSaturationId
			  FROM TCD.ProgramMaster AS pm
			  WHERE pm.ProgramId = @ProgramID
				   AND pm.Is_Deleted = 0;
			  IF(@PlantProgramId <> 0
				OR @PlantProgramId IS NOT NULL)
				 BEGIN
					--Assign value from plantchainprogram table based on plantprogramId
					SELECT @EcolabTextileCategoryId = pcp.
					EcolabTextileCategoryId,
						  @ChainTextileCategoryId = pcp.
						  ChainTextileCategoryId,
						  @FormulaSegmentId = pcp.FormulaSegmentId,
						  @EcolabSaturationId = pcp.
						  EcolabSaturationId
					FROM tcd.PlantChainProgram AS pcp
					WHERE pcp.PlantProgramId = @PlantProgramId
						 AND pcp.Is_Deleted = 0;
				 END;
			  --End-----ProgramMasterID logic for PlantChainProgram
			  IF @BatchID IS NULL
				 BEGIN
					INSERT INTO TCD.BatchData
					(ControllerBatchId,
					 EcolabWasherId,
					 GroupId,
					 MachineInternalId,
					 PlantWasherNumber,
					 StartDate,
					 ProgramNumber,
					 ProgramMasterId,
					 MachineId,
					 ActualWeight,
					 StandardWeight,
					 CurrencyCode,
					 ShiftId,
					 PartitionOn,
					 TargetTurnTime,
					 StdInjectionSteps,
					 StdWashSteps,
					 EcolabTextileCategoryId,
					 ChainTextileCategoryId,
					 FormulaSegmentId,
					 EcolabSaturationId,
					 PlantProgramId
					)
						  SELECT @BatchNumber,
							    @EcolabWasherID,
							    @WasherGroupID,
							    @MachineInternalID,
							    @PlantWasherNumber,
							    @BatchStartTime,
							    @ProgramNumber,
							    @ProgramID,
							    @WasherID,
							    @Load,
							    @NominalLoad,
							    @CurrencyCode,
							    @BatchShiftId,
							    @PartitionOn,
							    @TargetTurnTime,
							    @StdInjectionSteps,
							    @StdWashSteps,
							    @EcolabTextileCategoryId,
							    @ChainTextileCategoryId,
							    @FormulaSegmentId,
							    @EcolabSaturationId,
							    @PlantProgramId;
					SELECT @BatchID = SCOPE_IDENTITY();
					IF(@StdWashSteps > 0
					   OR @StdWashSteps <> NULL)
					    BEGIN
						   INSERT INTO TCD.BatchParameters
						   (BatchId,
						    EcolabWasherId,
						    ParameterId,
						    ParameterValue,
						    PartitionOn
						   )
								SELECT @BatchID,
									  @EcolabWasherId,
									  38,
									  @StdWashSteps,
									  @PartitionOn;
					    END;
					IF @CustomerNumber IS NOT NULL
					    BEGIN
						   IF NOT EXISTS
						   (
							  SELECT 1
							  FROM TCD.BatchCustomerData
							  WHERE BatchID = @BatchID
						   )
							  BEGIN
								 INSERT INTO TCD.BatchCustomerData
								 (BatchId,
								  CustomerID,
								  Weight,
								  PartitionOn,
								  EcolabWasherId
								 )
									   SELECT @BatchID,
											@CustomerNumber,
											@Load,
											@PartitionOn,
											@EcolabWasherId;
							  END;
					    END;
				 END;
			  -- Transfer Signal
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM tcd.WasherReading wr
				 WHERE wr.WasherId = @WasherID
					  AND wr.ParameterId = @TransferSignalId
					  AND wr.DateTimeStamp = @BatchStartTime
			  )
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterId,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TransferSignalId,
							    1,
							    @BatchStartTime,
							    @PartitionOn,
							    @EcolabWasherId
						  UNION ALL
						  SELECT @WasherID,
							    @TransferSignalId,
							    0,
							    @BatchStartTime,
							    @PartitionOn,
							    @EcolabWasherId;
				 END;
			  --Start Updating Batch Wash Step Data	 
			  EXEC TCD.UPDATEBatchWashStepForTunnel
				  @TunnelXML,
				  @WasherID,
				  @BatchID,
				  @BatchStartTime,
				  @PartitionOn,
				  @EcolabWasherId,
				  @compartmentID;
			  --End Updating Batch Wash Step Data	 
			  SELECT @compartmentID = @compartmentID - 1;
		   END;
	 --Start water consumption per step


   CREATE TABLE #WaterConsumptionData
     (
      Number          INT,
      Quantity        DECIMAL(10,6),
     );
     INSERT INTO #WaterConsumptionData
     (Number,
  Quantity
     )
    SELECT T.c.value('@Counter', 'INT') AS Number, --PumpNumber
       T.c.value('@Value', 'DECIMAL(10,6)') AS Quantity --Water Quanity
    FROM @xmlTags.nodes('MyControlTunnel/TunnelData/WaterConsumption') T(C);

  SET @CurrentStepComportmentNO=1;
  SET @CounterNO=1;
  WHILE(@CurrentStepComportmentNO<=22)
  BEGIN
   SELECT @MeterID=MeterId
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@CurrentStepComportmentNO
   SELECT @ActualQuantity=wc.Quantity
  FROM #WaterConsumptionData wc where wc.Number=@CounterNO
  SELECT @WasherModuleCount=COUNT(1) FROM TCD.WasherModuleOnlineUsageData WHERE WasherId = @WasherID AND StepComportment =@CurrentStepComportmentNO AND ModuleId = @MeterID AND ActualQuantity=@ActualQuantity
  IF(@WasherModuleCount=0)
  BEGIN
  IF(ISNULL(@WasherID,0)>0 AND ISNULL(@MeterID,0)>0 AND ISNULL(@ActualQuantity,0)>0 AND ISNULL(@CurrentStepComportmentNO,0)>0)
  BEGIN
  SET @CounterNO=@CounterNO+1;
   INSERT INTO TCD.WasherModuleOnlineUsageData
     (WasherId,
      StepComportment,
      ModuleId,
      ActualQuantity,
      TimeStamp,
      EcolabWasherId
     )
     SELECT
     @WasherID,
     @CurrentStepComportmentNO,
     @MeterID,
     @ActualQuantity,
     GETUTCDATE(),
     @EcolabWasherId
      END  

	  END
        SET  @CurrentStepComportmentNO=@CurrentStepComportmentNO+1;
   
  END;
 END;

 
 GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlTunnelWasherProdData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlTunnelWasherProdData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ProcessMyControlTunnelWasherProdData](
	@ControllerID   INT,
	@xmlTags        XML,
	@PLCPointer     INT,
	@ReadPointer    INT,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @BatchID                   INT,
			  @WasherID                  INT,
			  @EcolabWasherId            INT,
			  @CurrencyCode              VARCHAR(50),
			  @MachineInternalId         INT,
			  @WasherGroupID             INT,
			  @PlantWasherNumber         INT,
			  @ProgramNumber             INT,
			  @Load                      DECIMAL(10, 2),
			  @NominalLoad               DECIMAL(10, 2),
			  @CustomerNumber            INT,
			  @PHStatus                  INT,
			  @PHValue                   INT,
			  @LFStatus                  INT,
			  @LFValue                   INT,
			  @BatchNumber               INT,
			  @TargetTurnTime            INT,
			  @PartitionOn               DATETIME2,
			  @BatchStartTime            DATETIME2,
			  @BatchEndTime              DATETIME2,
			  @ProgramID                 INT,
			  @NumberOfCompartments      INT,
			  @ProductId                 INT,
			  @CompartmentNum            INT,
			  @EquipmentType             INT,
			  @MinTempParamID            INT,
			  @MaxTempParamID            INT,
			  @TempStatusParamID         INT,
			  @PHValueParamID            INT,
			  @PHStatusParamID           INT,
			  @ConductivityValueParamID  INT,
			  @ConductivityStatusParamID INT,
			  @StdInjectionSteps         INT,
			  @StdWashSteps              INT,
			  @ActualInjSteps            INT,
			  @EcolabTextileCategoryId   INT,
			  @ChainTextileCategoryId    INT,
			  @FormulaSegmentId          INT,
			  @EcolabSaturationId        INT,
			  @PlantProgramId            INT,
			  @PreviousShiftId		    INT,
			  @CurrentShiftId		    INT,
			  @CurrentStepComportmentNO INT,
              @CounterNO                INT,
               @MeterID                 INT,
              @ActualQuantity          DECIMAL(10,6),
			  @BatchStepCount          INT
	    DECLARE @BatchShiftId INT;
	    DECLARE @ShiftStartDateTemp TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    DECLARE @TunnelXML XML;
	    SELECT @TunnelXML = T.c.query('.')
	    FROM @xmlTags.nodes('MyControlTunnel/TunnelData') T(c)
	    WHERE T.c.value('@CompartmentNumber', 'INT') = 0;

		
	    SELECT @MachineInternalID = T.c.value('@MachineNumber', 'int'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @BatchStartTime = T.c.value('@StartDateTime', 'DateTime'),
			 @BatchEndTime = T.c.value('@EndDateTime', 'DateTime'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@Nominalload', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'int'),
			 @PHStatus = T.c.value('@Phstatus', 'int'),
			 @PHValue = T.c.value('@Phvalue', 'INT'),
			 @LFStatus = T.c.value('@LFStatus', 'INT'),
			 @LFValue = T.c.value('@LFValue', 'INT')
	    FROM @xmlTags.nodes('MyControlTunnel/TunnelData') T(c);

		--Inserts Xml Data
		INSERT INTO tcd.PLCXMLData
	    (
			 PLC_Type,
			 XML_Data,
			 XML_Type,
			 Batch_Number,
			 Time_Stamp
	    )
	       VALUES
				(
					 3,
					CONVERT(nvarchar(max), @xmlTags),
					 2,
					ISNULL(@BatchNumber,0),			 
					 GETUTCDATE()
				);

	    SELECT @EcolabWasherID = Ws.EcolabWasherId,
			 @WasherGroupID = Wg.WasherGroupId,
			 @PlantWasherNumber = PlantWasherNumber,
			 @WasherID = ws.WasherId,
			 @CurrencyCode = P.CurrencyCode,
			 @NumberOfCompartments = Mst.NumberofComp
	    FROM TCD.Washer Ws
		    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.
		    GroupId
		    INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId
		    = Wg.WasherGroupTypeId
		    INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId =
		    Mst.ControllerId
		    INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.
		    EcoLabAccountNumber
	    WHERE Ctrl.ControllerID = @ControllerID
			AND Mst.MachineInternalId = @MachineInternalID
			AND Mst.IsTunnel = 1 AND Mst.IsDeleted=0;
	    SELECT @EcolabWasherID;
	    SELECT @ProgramID = ProgramId,
			 @TargetTurnTime = (3600 / (tps.TotalRunTime /
			 @NumberOfCompartments))
	    FROM TCD.TunnelProgramSetup AS tps
	    WHERE tps.WasherGroupId = @WasherGroupID
			AND tps.is_deleted = 0
			AND ProgramNumber = @ProgramNumber;
	    DELETE FROM @ShiftStartDateTemp;
	    IF(@BatchEndTime IS NOT NULL)
		   BEGIN
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchEndTime
		   END;
	    ELSE
		   BEGIN
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchStartTime
		   END;
	    SELECT @BatchShiftId = ShiftID,
			 @PartitionOn = ShiftStartdate
	    FROM @ShiftStartDateTemp;


	    --Start Getting InjectionCount,StepCount And ProductCount
	    SELECT @StdInjectionSteps = COUNT(tdpm.TunnelDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT tds.TunnelDosingSetupId) -
			 COUNT(tdpm.TunnelDosingSetupId)
	    FROM tcd.TunnelDosingProductMapping tdpm
		    RIGHT JOIN tcd.TunnelDosingSetup tds ON tdpm.
		    TunnelDosingSetupId = tds.TunnelDosingSetupId
	    WHERE tds.GroupId = @WasherGroupID
			AND tds.ProgramNumber = @ProgramNumber;
	    --End Getting InjectionCount,StepCount And ProductCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramID
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT @EcolabTextileCategoryId = pcp. EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp. ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    SELECT @BatchID = NULL;
	    SELECT @BatchID = BatchID
	    FROM TCD.BatchData BD
	    WHERE BD.ControllerBatchId = @BatchNumber
			AND BD.StartDate = @BatchStartTime
			AND BD.MachineId = @WasherID;
	    --AND BD.MachineInternalID = @MachineInternalID
	    IF(@BatchID IS NULL)
		   BEGIN
		   --Start Rollup for previous completed shift
	   IF(CAST(@BatchStartTime as date) < CAST(GETUTCDATE() as date))
	   BEGIN
		  SELECT TOP 1 @PreviousShiftId=ShiftId FROM TCD.BatchData WHERE MachineId=@WasherId ORDER BY StartDate DESC	   
		  SELECT Top 1 @CurrentShiftId = ShiftId from @ShiftStartDateTemp
		  IF(@CurrentShiftId != @PreviousShiftId)
		  BEGIN
			 EXEC TCD.ProductionShiftDataRollup @PreviousShiftId, @RedFlagShiftId OUTPUT
			 IF(@RedFlagShiftId IS NULL)
			 BEGIN
				SET @RedFlagShiftId = @PreviousShiftId
			 END
		  END
	   END
	   --End Rollup for previous completed shift
			  INSERT INTO TCD.BatchData
			  (ControllerBatchId,
			   EcolabWasherId,
			   GroupId,
			   MachineInternalId,
			   PlantWasherNumber,
			   StartDate,
			   EndDate,
			   ProgramNumber,
			   ProgramMasterId,
			   MachineId,
			   ActualWeight,
			   StandardWeight,
			   CurrencyCode,
			   ShiftId,
			   PartitionOn,
			   TargetTurnTime,
			   StdInjectionSteps,
			   StdWashSteps,
			   EcolabTextileCategoryId,
			   ChainTextileCategoryId,
			   FormulaSegmentId,
			   EcolabSaturationId,
			   PlantProgramId,
			   EndDateFormula
			  )
				    SELECT @BatchNumber,
						 @EcolabWasherID,
						 @WasherGroupID,
						 @MachineInternalID,
						 @PlantWasherNumber,
						 @BatchStartTime,
						 @BatchEndTime,
						 @ProgramNumber,
						 @ProgramID,
						 @WasherID,
						 @Load,
						 @NominalLoad,
						 @CurrencyCode,
						 @BatchShiftId,
						 @PartitionOn,
						 @TargetTurnTime,
						 @StdInjectionSteps,
						 @StdWashSteps,
						 @EcolabTextileCategoryId,
						 @ChainTextileCategoryId,
						 @FormulaSegmentId,
						 @EcolabSaturationId,
						 @PlantProgramId,
						 @BatchEndTime;
			  SELECT @BatchID = SCOPE_IDENTITY();
			  IF(@StdWashSteps > 0
				OR @StdWashSteps <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchID,
							@EcolabWasherId,
							38,
							@StdWashSteps,
							@PartitionOn;
			  EXEC TCD.UPDATEBatchWashStepForTunnel
				  @TunnelXML,
				  @WasherID,
				  @BatchID,
				  @BatchStartTime,
				  @PartitionOn,
				  @EcolabWasherId,
				  @NumberOfCompartments;
		   END;
	    IF(@BatchEndTime IS NOT NULL
		  AND @BatchEndTime != '01/01/1900')
		   BEGIN
			  UPDATE TCD.BatchData
			    SET
				   EndDate = @BatchEndTime,
				   ShiftId = @BatchShiftId,
				   PartitionOn = @PartitionOn,
				   EndDateFormula=@BatchEndTime
			  WHERE BATCHID = @BatchID;
		   END;
	    IF(@CustomerNumber IS NOT NULL)
		   BEGIN
			  IF NOT EXISTS
			  (
				 SELECT 1
				 FROM [TCD].[BatchCustomerData]
				 WHERE BatchID = @BatchID
			  )
				 BEGIN
					INSERT INTO [TCD].[BatchCustomerData]
					([BatchId],
					 CustomerID,
					 [Weight],
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @BatchID,
							    @CustomerNumber,
							    @Load,
							    @PartitionOn,
							    @EcolabWasherId;
				 END;
		   END;
	    CREATE TABLE #DosingDetails
	    (
		    Number          INT,
		    Quantity        DECIMAL(10, 6),
		    Point           INT,
		    IsMainEquioment INT
	    );
	    INSERT INTO #DosingDetails
	    (Number,
		Quantity,
		Point,
		IsMainEquioment
	    )
			 SELECT T.c.value('@Number', 'INT') AS Number, --PumpNumber
				   T.c.value('@Quantity', 'Decimal(10,6)') AS Quantity, --Dosing Quanity
				   T.c.value('@Point', 'INT') AS Point, --Dosing point
				   T.c.value('@IsMainEquioment', 'INT') AS
			 IsMainEquioment
			 FROM @xmlTags.nodes('MyControlTunnel/TunnelData/Dose') T(C)
	    ;
	
	    -- Fetching data from cursor
	    DECLARE @MYCURSOR CURSOR;
	    SET @MYCURSOR = CURSOR FAST_FORWARD
	    FOR SELECT Number,
				Quantity,
				Point,
				IsMainEquioment
		   FROM #DosingDetails;
	    DECLARE @Number          INT,
			  @Quantity        DECIMAL(10, 6),
			  @Point           INT,
			  @IsMainEquioment INT;
	    OPEN @MYCURSOR;
	    FETCH NEXT FROM @MYCURSOR INTO @Number,
								@Quantity,
								@Point,
								@IsMainEquioment;
	    WHILE @@FETCH_STATUS = 0
		   BEGIN
			  IF(@IsMainEquioment = 1)
				 BEGIN
					SET @EquipmentType = 2;
				 END;
			  ELSE
				 BEGIN
					SET @EquipmentType = 1;
				 END;
			  SELECT @ProductId = CES.ProductId,
				    @CompartmentNum = TCEVM.CompartmentNumber
			  FROM tcd.ControllerEquipmentSetup CES
				  INNER JOIN TCD.
				  TunnelCompartmentEquipmentValveMapping TCEVM ON CES.
				  ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
			  WHERE CES.ControllerId = @ControllerID
				   AND CES.ControllerEquipmentTypeId = @EquipmentType
				   AND --CES.IsActive=1 AND
				   --CES.WasherGroupNumber=@WasherGroupNum AND
				   TCEVM.DosingPointNumber = @Point
				   AND CES.ControllerEquipmentId = @Number;
				
			  --SELECT @EcolabWasherID
			  IF(@ProductId IS NOT NULL)
				 BEGIN
					INSERT INTO TCD.BatchProductData
					(BatchId,
					 StepCompartment,
					 ActualQuantity,
					 [TimeStamp],
					 PartitionOn,
					 EcolabWasherId,
					 ProductId
					)
						  SELECT @BatchID,
							    @CompartmentNum,
							    @Quantity,
							    @BatchEndTime,
							    @PartitionOn,
							    @EcolabWasherID,
							    @ProductId;
				 END;
			  FETCH NEXT FROM @MYCURSOR INTO @Number,
									   @Quantity,
									   @Point,
									   @IsMainEquioment;
		   END;
	    CLOSE @MYCURSOR;
	    DEALLOCATE @MYCURSOR;
	    DROP TABLE #DosingDetails;
	    SELECT @ActualInjSteps = COUNT(DISTINCT StepCompartment)
	    FROM TCD.BatchProductData
	    WHERE BatchId = @BatchID;
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.BatchParameters
		   WHERE ParameterId = 37
			    AND batchid = @BatchID
			    AND @ActualInjSteps > 0
	    )
		   BEGIN
			  IF(@ActualInjSteps > 0
				OR @ActualInjSteps <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchId,
							@EcolabWasherId,
							37,
							@ActualInjSteps,
							@PartitionOn;
		   END;
	    ELSE
		   BEGIN
			  UPDATE TCD.BatchParameters
			    SET
				   ParameterValue = @ActualInjSteps
			  WHERE ParameterId = 37
				   AND batchid = @BatchID;
		   END;
	    SELECT @MinTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Mimum Temperature';
	    SELECT @MaxTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Maximum Temperature';
	    SELECT @TempStatusParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Temperature Status';
	    SELECT @PHValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH';
	    SELECT @PHStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH Status';
	    SELECT @ConductivityValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Conductivity';
	    SELECT @ConductivityStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'LF Status';
	    IF(@PHValue IS NOT NULL)
		   BEGIN
			  --pH Value
			  IF(@PHValue <> 0
				OR @PHValue <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @PHValueParamID,
					   @PHValue,
					   @PartitionOn
				 );

			  --pH Status
			  IF(@PHStatus <> 0
				OR @PHStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @PHStatusParamID,
					   @PHStatus,
					   @PartitionOn
				 );
		   END;
	    IF(@LFValue IS NOT NULL)
		   BEGIN
			  --Conductivity Value
			  IF(@LFValue <> 0
				OR @LFValue <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @ConductivityValueParamID,
					   @LFValue,
					   @PartitionOn
				 );

			  --Conductivity Status
			  IF(@LFStatus <> 0
				OR @LFStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @ConductivityStatusParamID,
					   @LFStatus,
					   @PartitionOn
				 );
		   END;
	    CREATE TABLE #TemperatureDetails
	    (
		    MinimumTemp DECIMAL(10, 2),
		    MaximumTemp DECIMAL(10, 2),
		    TempStatus  DECIMAL(10, 2)
	    );
	    INSERT INTO #TemperatureDetails
	    (MinimumTemp,
		MaximumTemp,
		TempStatus
	    )
			 SELECT T.c.value('@Minimum', 'Decimal(10,2)') AS
			 MinimumTemp,
				   T.c.value('@Maximum', 'Decimal(10,2)') AS
				   MaximumTemp,
				   T.c.value('@Status', 'Decimal(10,2)') AS TempStatus
			 FROM @xmlTags.nodes(
			 'MyControlTunnel/TunnelData/TemperatureData'
							) T(c);
	  
	    -- Fetching data from cursor
	    DECLARE @TEMPCURSOR CURSOR;
	    SET @TEMPCURSOR = CURSOR FAST_FORWARD
	    FOR SELECT MinimumTemp,
				MaximumTemp,
				TempStatus
		   FROM #TemperatureDetails;
	    DECLARE @MinimumTemp DECIMAL(10, 2),
			  @MaximumTemp DECIMAL(10, 2),
			  @TempStatus  DECIMAL(10, 2);
	    OPEN @TEMPCURSOR;
	    FETCH NEXT FROM @TEMPCURSOR INTO @MinimumTemp,
								  @MaximumTemp,
								  @TempStatus;
	    WHILE @@FETCH_STATUS = 0
		   BEGIN	
			  --Minimum Temperature
			  IF(@MinimumTemp <> 0
				OR @MinimumTemp <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @MinTempParamID,
					   @MinimumTemp,
					   @PartitionOn
				 );

			  --Maximum Temperature
			  IF(@MaximumTemp <> 0
				OR @MaximumTemp <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @MaxTempParamID,
					   @MaximumTemp,
					   @PartitionOn
				 );

			  --Temperature Status
			  IF(@TempStatus <> 0
				OR @TempStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @TempStatusParamID,
					   @TempStatus,
					   @PartitionOn
				 );
			  FETCH NEXT FROM @TEMPCURSOR INTO @MinimumTemp,
										@MaximumTemp,
										@TempStatus;
		   END;
	    CLOSE @TEMPCURSOR;
	    DEALLOCATE @TEMPCURSOR;
	    DROP TABLE #TemperatureDetails;
	    UPDATE TCD.BatchWashStepData
		 SET
			EndTime = @BatchEndTime
	    WHERE BatchId = @BatchID
			AND EndTime IS NULL;
   
   --Start water consumption per batch
    CREATE TABLE #WaterConsumptionData
     (
      Number          INT,
      Quantity        DECIMAL(10,6),
     );
     INSERT INTO #WaterConsumptionData
     (Number,
  Quantity
     )
    SELECT T.c.value('@Counter', 'INT') AS Number, --PumpNumber
       T.c.value('@Value', 'DECIMAL(10,6)') AS Quantity --Water Quanity
    FROM @xmlTags.nodes('MyControlTunnel/TunnelData/WaterConsumption') T(C);

  
  SET @CurrentStepComportmentNO=1;
  SET @CounterNo=1
  WHILE(@CurrentStepComportmentNO<=22)
  BEGIN
  SELECT @MeterID=MeterId
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@CurrentStepComportmentNO

    SELECT @ActualQuantity=wc.Quantity
  FROM #WaterConsumptionData wc where wc.Number=@CounterNo
  SELECT @BatchStepCount=COUNT(1) FROM TCD.BatchStepWaterUsageData WHERE BatchId=@BatchID  AND StepCompartment =@CurrentStepComportmentNO AND ActualQuantity=@ActualQuantity 
  IF(@BatchStepCount=0)
  BEGIN
  IF(ISNULL(@BatchID,0)>0  AND ISNULL(@MeterID,0)>0 AND ISNULL(@ActualQuantity,0)>0)
  BEGIN
  SET @CounterNo=@CounterNo+1;
   INSERT INTO TCD.BatchStepWaterUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
      EcolabWasherId
     )
     SELECT
     @BatchID,
     @CurrentStepComportmentNO,
     @ActualQuantity,
     @PartitionOn,
     @EcolabWasherId
      END 
	  END 
      SET  @CurrentStepComportmentNO=@CurrentStepComportmentNO+1;  
  END;
 END;
  GO
 IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlOnlineCWStepWaterConsumptionData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlOnlineCWStepWaterConsumptionData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessMyControlOnlineCWStepWaterConsumptionData]
(
@ControllerID   INT,
 @VxML       XML
) 
AS
BEGIN
DECLARE @MachineNumber   INT,
  @WasherID INT,
  @MeterID INT,
  @WasherGroupID INT,
  @StepComportmentNO INT,
  @ActualQuantity Decimal(10,6),
  @EcolabWasherId INT,
  @CurrentStepComportmentNO INT,
  @WasherModuleCount        INT

   SELECT @MachineNumber = T.c.value('@MachineNumber', 'INT')
     FROM @VxML.nodes('MyControlConventionalData') T(C);

	 --Inserts Xml Data
	 INSERT INTO tcd.PLCXMLData
	    (
			 PLC_Type,
			 XML_Data,
			 XML_Type,
			 Batch_Number,
			 Time_Stamp
	    )
	       VALUES
				(
					 3,
					CONVERT(nvarchar(max), @VxML),
					 5,
					 0,			 
					 GETUTCDATE()
				);



  CREATE TABLE #StepConsumptionData
  (
      StepNo      INT,
      Qty         DECIMAL(10, 6)
  )
   INSERT INTO #StepConsumptionData 
   SELECT  T.c.value('@StepNo', 'INT'),
         T.c.value('@WCCounter1', 'Decimal(10,2)')+T.c.value('@WCCounter2', 'Decimal(10,2)')
     FROM @VxML.nodes('MyControlConventionalData/WaterConsumptionData/StepConsumption') T(C)
  WHERE T.c.value('@WCCounter1', 'Decimal(10,6)')>0 OR T.c.value('@WCCounter2', 'Decimal(10,6)')>0 ;

  --Getting WasherGroupId,WasherId from MachineSetup
   SELECT @WasherGroupID = GroupId,
    @WasherID = ms.WasherID
     FROM TCD.MachineSetup ms
       WHERE ControllerID = @ControllerID
   AND MachineInternalId = @MachineNumber
   AND IsTunnel = 0
   AND IsDeleted = 0;

   --Getting MeterId,WasherId from Meter
   SELECT @MeterID=MeterId
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@MachineNumber

    --Getting @EcolabWasherId from Washer
   SELECT @EcolabWasherId= wr.EcolabWasherId
   FROM TCD.Washer wr
      WHERE wr.WasherId=@WasherID

  
  SET @CurrentStepComportmentNO=1;
  WHILE(@CurrentStepComportmentNO<=25)
  BEGIN
  SELECT @StepComportmentNO=scd.StepNo,@ActualQuantity=scd.Qty
  FROM #StepConsumptionData scd where scd.StepNo=@CurrentStepComportmentNO
  SELECT @WasherModuleCount=COUNT(1) FROM TCD.WasherModuleOnlineUsageData WHERE WasherId = @WasherID AND StepComportment =@StepComportmentNO AND ModuleId = @MeterID AND ActualQuantity=@ActualQuantity 
  IF(@WasherModuleCount=0)
  BEGIN
  IF(@StepComportmentNO IS NOT NULL AND @WasherID IS NOT NULL AND @MeterID IS NOT NULL)
   INSERT INTO TCD.WasherModuleOnlineUsageData
     (WasherId,
      StepComportment,
      ModuleId,
      ActualQuantity,
      TimeStamp,
      EcolabWasherId
     )
     SELECT
     @WasherID,
     @StepComportmentNO,
     @MeterID,
     @ActualQuantity,
     GETUTCDATE(),
     @EcolabWasherId
      END  
        SET  @CurrentStepComportmentNO=@CurrentStepComportmentNO+1;
   
  END;
END;
GO
----------------------------------------------Start Tcd.BatchWashStepData Start and End Time issue-------------------------------------------------

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlTunnelWasherProdData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlTunnelWasherProdData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ProcessMyControlTunnelWasherProdData](
	@ControllerID   INT,
	@xmlTags        XML,
	@PLCPointer     INT,
	@ReadPointer    INT,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @BatchID                   INT,
			  @WasherID                  INT,
			  @EcolabWasherId            INT,
			  @CurrencyCode              VARCHAR(50),
			  @MachineInternalId         INT,
			  @WasherGroupID             INT,
			  @PlantWasherNumber         INT,
			  @ProgramNumber             INT,
			  @Load                      DECIMAL(10, 2),
			  @NominalLoad               DECIMAL(10, 2),
			  @CustomerNumber            INT,
			  @PHStatus                  INT,
			  @PHValue                   INT,
			  @LFStatus                  INT,
			  @LFValue                   INT,
			  @BatchNumber               INT,
			  @TargetTurnTime            INT,
			  @PartitionOn               DATETIME2,
			  @BatchStartTime            DATETIME2,
			  @BatchEndTime              DATETIME2,
			  @ProgramID                 INT,
			  @NumberOfCompartments      INT,
			  @ProductId                 INT,
			  @CompartmentNum            INT,
			  @EquipmentType             INT,
			  @MinTempParamID            INT,
			  @MaxTempParamID            INT,
			  @TempStatusParamID         INT,
			  @PHValueParamID            INT,
			  @PHStatusParamID           INT,
			  @ConductivityValueParamID  INT,
			  @ConductivityStatusParamID INT,
			  @StdInjectionSteps         INT,
			  @StdWashSteps              INT,
			  @ActualInjSteps            INT,
			  @EcolabTextileCategoryId   INT,
			  @ChainTextileCategoryId    INT,
			  @FormulaSegmentId          INT,
			  @EcolabSaturationId        INT,
			  @PlantProgramId            INT,
			  @PreviousShiftId		    INT,
			  @CurrentShiftId		    INT,
			  @CurrentStepComportmentNO INT,
              @CounterNO                INT,
               @MeterID                 INT,
              @ActualQuantity          DECIMAL(10,6),
			  @BatchStepCount         INT
	    DECLARE @BatchShiftId INT;
	    DECLARE @ShiftStartDateTemp TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    DECLARE @TunnelXML XML;
	    SELECT @TunnelXML = T.c.query('.')
	    FROM @xmlTags.nodes('MyControlTunnel/TunnelData') T(c)
	    WHERE T.c.value('@CompartmentNumber', 'INT') = 0;

		
	    SELECT @MachineInternalID = T.c.value('@MachineNumber', 'int'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @BatchStartTime = T.c.value('@StartDateTime', 'DateTime'),
			 @BatchEndTime = T.c.value('@EndDateTime', 'DateTime'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@Nominalload', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'int'),
			 @PHStatus = T.c.value('@Phstatus', 'int'),
			 @PHValue = T.c.value('@Phvalue', 'INT'),
			 @LFStatus = T.c.value('@LFStatus', 'INT'),
			 @LFValue = T.c.value('@LFValue', 'INT')
	    FROM @xmlTags.nodes('MyControlTunnel/TunnelData') T(c);

		--Inserts Xml Data
		INSERT INTO tcd.PLCXMLData
	    (
			 PLC_Type,
			 XML_Data,
			 XML_Type,
			 Batch_Number,
			 Time_Stamp
	    )
	       VALUES
				(
					 3,
					CONVERT(nvarchar(max), @xmlTags),
					 2,
					ISNULL(@BatchNumber,0),			 
					 GETUTCDATE()
				);

	    SELECT @EcolabWasherID = Ws.EcolabWasherId,
			 @WasherGroupID = Wg.WasherGroupId,
			 @PlantWasherNumber = PlantWasherNumber,
			 @WasherID = ws.WasherId,
			 @CurrencyCode = P.CurrencyCode,
			 @NumberOfCompartments = Mst.NumberofComp
	    FROM TCD.Washer Ws
		    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.
		    GroupId
		    INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId
		    = Wg.WasherGroupTypeId
		    INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId =
		    Mst.ControllerId
		    INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.
		    EcoLabAccountNumber
	    WHERE Ctrl.ControllerID = @ControllerID
			AND Mst.MachineInternalId = @MachineInternalID
			AND Mst.IsTunnel = 1 AND Mst.IsDeleted=0;
	    SELECT @EcolabWasherID;
	    SELECT @ProgramID = ProgramId,
			 @TargetTurnTime = (3600 / (tps.TotalRunTime /
			 @NumberOfCompartments))
	    FROM TCD.TunnelProgramSetup AS tps
	    WHERE tps.WasherGroupId = @WasherGroupID
			AND tps.is_deleted = 0
			AND ProgramNumber = @ProgramNumber;
	    DELETE FROM @ShiftStartDateTemp;
	    IF(@BatchEndTime IS NOT NULL)
		   BEGIN
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchEndTime
		   END;
	    ELSE
		   BEGIN
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchStartTime
		   END;
	    SELECT @BatchShiftId = ShiftID,
			 @PartitionOn = ShiftStartdate
	    FROM @ShiftStartDateTemp;


	    --Start Getting InjectionCount,StepCount And ProductCount
	    SELECT @StdInjectionSteps = COUNT(tdpm.TunnelDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT tds.TunnelDosingSetupId) -
			 COUNT(tdpm.TunnelDosingSetupId)
	    FROM tcd.TunnelDosingProductMapping tdpm
		    RIGHT JOIN tcd.TunnelDosingSetup tds ON tdpm.
		    TunnelDosingSetupId = tds.TunnelDosingSetupId
	    WHERE tds.GroupId = @WasherGroupID
			AND tds.ProgramNumber = @ProgramNumber;
	    --End Getting InjectionCount,StepCount And ProductCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramID
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT @EcolabTextileCategoryId = pcp. EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp. ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    SELECT @BatchID = NULL;
	    SELECT @BatchID = BatchID
	    FROM TCD.BatchData BD
	    WHERE BD.ControllerBatchId = @BatchNumber
			AND BD.StartDate = @BatchStartTime
			AND BD.MachineId = @WasherID;
	    --AND BD.MachineInternalID = @MachineInternalID
	    IF(@BatchID IS NULL)
		   BEGIN
		   --Start Rollup for previous completed shift
	   IF(CAST(@BatchStartTime as date) < CAST(GETUTCDATE() as date))
	   BEGIN
		  SELECT TOP 1 @PreviousShiftId=ShiftId FROM TCD.BatchData WHERE MachineId=@WasherId ORDER BY StartDate DESC	   
		  SELECT Top 1 @CurrentShiftId = ShiftId from @ShiftStartDateTemp
		  IF(@CurrentShiftId != @PreviousShiftId)
		  BEGIN
			 EXEC TCD.ProductionShiftDataRollup @PreviousShiftId, @RedFlagShiftId OUTPUT
			 IF(@RedFlagShiftId IS NULL)
			 BEGIN
				SET @RedFlagShiftId = @PreviousShiftId
			 END
		  END
	   END
	   --End Rollup for previous completed shift
			  INSERT INTO TCD.BatchData
			  (ControllerBatchId,
			   EcolabWasherId,
			   GroupId,
			   MachineInternalId,
			   PlantWasherNumber,
			   StartDate,
			   EndDate,
			   ProgramNumber,
			   ProgramMasterId,
			   MachineId,
			   ActualWeight,
			   StandardWeight,
			   CurrencyCode,
			   ShiftId,
			   PartitionOn,
			   TargetTurnTime,
			   StdInjectionSteps,
			   StdWashSteps,
			   EcolabTextileCategoryId,
			   ChainTextileCategoryId,
			   FormulaSegmentId,
			   EcolabSaturationId,
			   PlantProgramId,
			   EndDateFormula
			  )
				    SELECT @BatchNumber,
						 @EcolabWasherID,
						 @WasherGroupID,
						 @MachineInternalID,
						 @PlantWasherNumber,
						 @BatchStartTime,
						 @BatchEndTime,
						 @ProgramNumber,
						 @ProgramID,
						 @WasherID,
						 @Load,
						 @NominalLoad,
						 @CurrencyCode,
						 @BatchShiftId,
						 @PartitionOn,
						 @TargetTurnTime,
						 @StdInjectionSteps,
						 @StdWashSteps,
						 @EcolabTextileCategoryId,
						 @ChainTextileCategoryId,
						 @FormulaSegmentId,
						 @EcolabSaturationId,
						 @PlantProgramId,
						 @BatchEndTime;
			  SELECT @BatchID = SCOPE_IDENTITY();
			  IF(@StdWashSteps > 0
				OR @StdWashSteps <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchID,
							@EcolabWasherId,
							38,
							@StdWashSteps,
							@PartitionOn;
			  EXEC TCD.UPDATEBatchWashStepForTunnel
				  @TunnelXML,
				  @WasherID,
				  @BatchID,
				  @BatchStartTime,
				  @PartitionOn,
				  @EcolabWasherId,
				  @NumberOfCompartments;
		   END;
	    IF(@BatchEndTime IS NOT NULL
		  AND @BatchEndTime != '01/01/1900')
		   BEGIN
			  UPDATE TCD.BatchData
			    SET
				   EndDate = @BatchEndTime,
				   ShiftId = @BatchShiftId,
				   PartitionOn = @PartitionOn,
				   EndDateFormula=@BatchEndTime
			  WHERE BATCHID = @BatchID;
		   END;
	    IF(@CustomerNumber IS NOT NULL)
		   BEGIN
			  IF NOT EXISTS
			  (
				 SELECT 1
				 FROM [TCD].[BatchCustomerData]
				 WHERE BatchID = @BatchID
			  )
				 BEGIN
					INSERT INTO [TCD].[BatchCustomerData]
					([BatchId],
					 CustomerID,
					 [Weight],
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @BatchID,
							    @CustomerNumber,
							    @Load,
							    @PartitionOn,
							    @EcolabWasherId;
				 END;
		   END;
	    CREATE TABLE #DosingDetails
	    (
		    Number          INT,
		    Quantity        DECIMAL(10, 6),
		    Point           INT,
		    IsMainEquioment INT
	    );
	    INSERT INTO #DosingDetails
	    (Number,
		Quantity,
		Point,
		IsMainEquioment
	    )
			 SELECT T.c.value('@Number', 'INT') AS Number, --PumpNumber
				   T.c.value('@Quantity', 'Decimal(10,6)') AS Quantity, --Dosing Quanity
				   T.c.value('@Point', 'INT') AS Point, --Dosing point
				   T.c.value('@IsMainEquioment', 'INT') AS
			 IsMainEquioment
			 FROM @xmlTags.nodes('MyControlTunnel/TunnelData/Dose') T(C)
	    ;
	
	    -- Fetching data from cursor
	    DECLARE @MYCURSOR CURSOR;
	    SET @MYCURSOR = CURSOR FAST_FORWARD
	    FOR SELECT Number,
				Quantity,
				Point,
				IsMainEquioment
		   FROM #DosingDetails;
	    DECLARE @Number          INT,
			  @Quantity        DECIMAL(10, 6),
			  @Point           INT,
			  @IsMainEquioment INT;
	    OPEN @MYCURSOR;
	    FETCH NEXT FROM @MYCURSOR INTO @Number,
								@Quantity,
								@Point,
								@IsMainEquioment;
	    WHILE @@FETCH_STATUS = 0
		   BEGIN
			  IF(@IsMainEquioment = 1)
				 BEGIN
					SET @EquipmentType = 2;
				 END;
			  ELSE
				 BEGIN
					SET @EquipmentType = 1;
				 END;
			  SELECT @ProductId = CES.ProductId,
				    @CompartmentNum = TCEVM.CompartmentNumber
			  FROM tcd.ControllerEquipmentSetup CES
				  INNER JOIN TCD.
				  TunnelCompartmentEquipmentValveMapping TCEVM ON CES.
				  ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
			  WHERE CES.ControllerId = @ControllerID
				   AND CES.ControllerEquipmentTypeId = @EquipmentType
				   AND --CES.IsActive=1 AND
				   --CES.WasherGroupNumber=@WasherGroupNum AND
				   TCEVM.DosingPointNumber = @Point
				   AND CES.ControllerEquipmentId = @Number;
				
			  --SELECT @EcolabWasherID
			  IF(@ProductId IS NOT NULL)
				 BEGIN
					INSERT INTO TCD.BatchProductData
					(BatchId,
					 StepCompartment,
					 ActualQuantity,
					 [TimeStamp],
					 PartitionOn,
					 EcolabWasherId,
					 ProductId
					)
						  SELECT @BatchID,
							    @CompartmentNum,
							    @Quantity,
							    @BatchEndTime,
							    @PartitionOn,
							    @EcolabWasherID,
							    @ProductId;
				 END;
			  FETCH NEXT FROM @MYCURSOR INTO @Number,
									   @Quantity,
									   @Point,
									   @IsMainEquioment;
		   END;
	    CLOSE @MYCURSOR;
	    DEALLOCATE @MYCURSOR;
	    DROP TABLE #DosingDetails;
	    SELECT @ActualInjSteps = COUNT(DISTINCT StepCompartment)
	    FROM TCD.BatchProductData
	    WHERE BatchId = @BatchID;
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.BatchParameters
		   WHERE ParameterId = 37
			    AND batchid = @BatchID
			    AND @ActualInjSteps > 0
	    )
		   BEGIN
			  IF(@ActualInjSteps > 0
				OR @ActualInjSteps <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchId,
							@EcolabWasherId,
							37,
							@ActualInjSteps,
							@PartitionOn;
		   END;
	    ELSE
		   BEGIN
			  UPDATE TCD.BatchParameters
			    SET
				   ParameterValue = @ActualInjSteps
			  WHERE ParameterId = 37
				   AND batchid = @BatchID;
		   END;
	    SELECT @MinTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Mimum Temperature';
	    SELECT @MaxTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Maximum Temperature';
	    SELECT @TempStatusParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Temperature Status';
	    SELECT @PHValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH';
	    SELECT @PHStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH Status';
	    SELECT @ConductivityValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Conductivity';
	    SELECT @ConductivityStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'LF Status';
	    IF(@PHValue IS NOT NULL)
		   BEGIN
			  --pH Value
			  IF(@PHValue <> 0
				OR @PHValue <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @PHValueParamID,
					   @PHValue,
					   @PartitionOn
				 );

			  --pH Status
			  IF(@PHStatus <> 0
				OR @PHStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @PHStatusParamID,
					   @PHStatus,
					   @PartitionOn
				 );
		   END;
	    IF(@LFValue IS NOT NULL)
		   BEGIN
			  --Conductivity Value
			  IF(@LFValue <> 0
				OR @LFValue <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @ConductivityValueParamID,
					   @LFValue,
					   @PartitionOn
				 );

			  --Conductivity Status
			  IF(@LFStatus <> 0
				OR @LFStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @ConductivityStatusParamID,
					   @LFStatus,
					   @PartitionOn
				 );
		   END;
	    CREATE TABLE #TemperatureDetails
	    (
		    MinimumTemp DECIMAL(10, 2),
		    MaximumTemp DECIMAL(10, 2),
		    TempStatus  DECIMAL(10, 2)
	    );
	    INSERT INTO #TemperatureDetails
	    (MinimumTemp,
		MaximumTemp,
		TempStatus
	    )
			 SELECT T.c.value('@Minimum', 'Decimal(10,2)') AS
			 MinimumTemp,
				   T.c.value('@Maximum', 'Decimal(10,2)') AS
				   MaximumTemp,
				   T.c.value('@Status', 'Decimal(10,2)') AS TempStatus
			 FROM @xmlTags.nodes(
			 'MyControlTunnel/TunnelData/TemperatureData'
							) T(c);
	  
	    -- Fetching data from cursor
	    DECLARE @TEMPCURSOR CURSOR;
	    SET @TEMPCURSOR = CURSOR FAST_FORWARD
	    FOR SELECT MinimumTemp,
				MaximumTemp,
				TempStatus
		   FROM #TemperatureDetails;
	    DECLARE @MinimumTemp DECIMAL(10, 2),
			  @MaximumTemp DECIMAL(10, 2),
			  @TempStatus  DECIMAL(10, 2);
	    OPEN @TEMPCURSOR;
	    FETCH NEXT FROM @TEMPCURSOR INTO @MinimumTemp,
								  @MaximumTemp,
								  @TempStatus;
	    WHILE @@FETCH_STATUS = 0
		   BEGIN	
			  --Minimum Temperature
			  IF(@MinimumTemp <> 0
				OR @MinimumTemp <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @MinTempParamID,
					   @MinimumTemp,
					   @PartitionOn
				 );

			  --Maximum Temperature
			  IF(@MaximumTemp <> 0
				OR @MaximumTemp <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @MaxTempParamID,
					   @MaximumTemp,
					   @PartitionOn
				 );

			  --Temperature Status
			  IF(@TempStatus <> 0
				OR @TempStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @TempStatusParamID,
					   @TempStatus,
					   @PartitionOn
				 );
			  FETCH NEXT FROM @TEMPCURSOR INTO @MinimumTemp,
										@MaximumTemp,
										@TempStatus;
		   END;
	    CLOSE @TEMPCURSOR;
	    DEALLOCATE @TEMPCURSOR;
	    DROP TABLE #TemperatureDetails;
	    UPDATE TCD.BatchWashStepData
		 SET
			EndTime = DATEADD(ss,
						  (SELECT T.c.value('@Time', 'INT')
							 FROM @TunnelXML.nodes('TunnelData/CompartmentTime') T(c)
							 WHERE T.c.value('@CompartmentNo','INT') =
							 (
								SELECT
									  bwsd.StepCompartment
								FROM tcd.BatchWashStepData bwsd
								WHERE bwsd.BatchId = @BatchID
									 AND bwsd.EndTime IS NULL
							 )
						  ),
						  (
							 SELECT
								   bwsd.StartTime
							 FROM tcd.BatchWashStepData bwsd
							 WHERE bwsd.BatchId = @BatchID
								  AND bwsd.EndTime IS NULL
						  ))
	    WHERE
			BatchId = @BatchID
			AND EndTime IS NULL;
   
   --Start water consumption per batch


    CREATE TABLE #WaterConsumptionData
     (
      Number          INT,
      Quantity        DECIMAL(10,6),
     );
     INSERT INTO #WaterConsumptionData
     (Number,
  Quantity
     )
    SELECT T.c.value('@Counter', 'INT') AS Number, --PumpNumber
       T.c.value('@Value', 'DECIMAL(10,6)') AS Quantity --Water Quanity
    FROM @xmlTags.nodes('MyControlTunnel/TunnelData/WaterConsumption') T(C);

  
  SET @CurrentStepComportmentNO=1;
  SET @CounterNo=1
  WHILE(@CurrentStepComportmentNO<=22)
  BEGIN
  
   SELECT @MeterID=MeterId
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@CurrentStepComportmentNO

    SELECT @ActualQuantity=wc.Quantity
  FROM #WaterConsumptionData wc where wc.Number=@CounterNo
  SELECT @BatchStepCount=COUNT(1) FROM TCD.BatchStepWaterUsageData WHERE BatchId=@BatchID  AND StepCompartment =@CurrentStepComportmentNO AND ActualQuantity=@ActualQuantity 
  IF (@BatchStepCount=0)
  BEGIN
  IF(ISNULL(@BatchID,0)>0  AND ISNULL(@MeterID,0)>0 AND ISNULL(@ActualQuantity,0)>0)
  BEGIN
  SET @CounterNo=@CounterNo+1;
   INSERT INTO TCD.BatchStepWaterUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
      EcolabWasherId
     )
     SELECT
     @BatchID,
     @CurrentStepComportmentNO,
     @ActualQuantity,
     @PartitionOn,
     @EcolabWasherId
      END 
	  END 
      SET  @CurrentStepComportmentNO=@CurrentStepComportmentNO+1;  
  END;
 END;
 GO

 IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[UPDATEBatchWashStepForTunnel]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[UPDATEBatchWashStepForTunnel]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[UPDATEBatchWashStepForTunnel](
	@TunnelXML      XML,
	@WasherID       INT,
	@BatchID        INT,
	@BatchStartTime DATETIME,
	@PartitionOn    DATETIME,
	@EcolabWasherId INT,
	@CurrentStep    INT)
AS
	BEGIN
	    DECLARE @StepStart     DATETIME,
			  @StepEnd       DATETIME,
			  @CompartmentNo INT,
			  @Duration      INT,
			  @LaspStep      INT,
			  @RowCount      INT,
			  @EndDateTime	  DATETIME;
	    CREATE TABLE #BatchStep
	    (
		    CompartmentNo INT,
		    TimeStep      INT,
		    StartDateTime DATETIME,
		    EndDateTime   DATETIME
	    );
	    INSERT INTO #BatchStep
	    (
			 CompartmentNo,
			 TimeStep
	    )
	    SELECT T.c.value('@CompartmentNo', 'INT') AS CompartmentNo,
			 T.c.value('@Time', 'INT') AS [Time]
	    FROM @TunnelXML.nodes('TunnelData/CompartmentTime') T(c)
	    ORDER BY 1;
	    SELECT @EndDateTime=T.c.value('@EndDateTime', 'DateTime') FROM @TunnelXML.nodes('MyControlTunnel/TunnelData') T(c);
	    SELECT @CompartmentNo = 1,
			 @StepStart = @BatchStartTime;
	    WHILE(@CompartmentNo <= @CurrentStep AND @CompartmentNo > 0)
		   BEGIN
			  SELECT @Duration = TimeStep
			  FROM #BatchStep
			  WHERE CompartmentNo = @CompartmentNo;
			  SELECT @StepEnd = DATEADD(ss, @Duration, @StepStart);
	   IF(@CompartmentNo = @CurrentStep)
	   BEGIN
		  if(@EndDateTime IS NOT NULL)
		  SELECT @StepEnd = @StepEnd
	   ELSE
		  SELECT @StepEnd = NULL;
	   END
			  UPDATE BWS
			    SET
				   StartTime = @StepStart,
				   EndTime = @StepEnd
			  FROM TCD.BatchWashStepData BWS
			  WHERE BatchId = @BatchID
				   AND StepCompartment = @CompartmentNo;
			  SELECT @RowCount = @@RowCount;
			  IF(@RowCount = 0 AND @Duration > 0)
				 BEGIN
					INSERT INTO TCD.BatchWashStepData
					(BatchId,
					 StepCompartment,
					 StartTime,
					 EndTime,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @BatchID,
							    @CompartmentNo,
							    @StepStart,
							    @StepEnd,
							    @PartitionOn,
							    @EcolabWasherId;
				 END; --IF (@RowCount = 0)
			  SELECT @CompartmentNo = @CompartmentNo + 1;
			  SELECT @StepStart = @StepEnd;
		   END; --WHILE (@CompartmentNo <=@LaspStep)
	    DROP TABLE #BatchStep;
	END;
	GO
----------------------------------------------End Tcd.BatchWashStepData Start and End Time issue-------------------------------------------------
----------------------------------------------Start Water and Energy Logger Digital/Analog Inputs------------------------------------------------
IF  NOT EXISTS (SELECT * FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[TCD].[WaterAndEnergyConsumptionLog]') AND type in (N'U'))
BEGIN
CREATE TABLE [TCD].[WaterAndEnergyConsumptionLog](
[WaterAndEnergyConsumptionLogId] [int] IDENTITY(1,1) NOT NULL,
[MeterId] [int] NOT NULL,
[Value] [BIGINT] NOT NULL,
[CreatedDate] [datetime2] NOT NULL,
 CONSTRAINT [PK_WaterAndEnergyConsumptionLog] PRIMARY KEY CLUSTERED 
(
[WaterAndEnergyConsumptionLogId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlWandEDigitalData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlWandEDigitalData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessMyControlWandEDigitalData](
 @ControllerID   INT,
 @xmlTags        XML
 )
AS
BEGIN

DECLARE @BatchID  INT,
@MeterId          INT,
@CurrentDayReading  DECIMAL(18,4),
@CurrentDayRunTime  INT,
@PreviousDayReading DECIMAL(18,4),
@PreviousDayRuntime INT,
@CurrentDate        DATETIME,
@PrevoiusDate       DATETIME,
@WasherGroupID    INT,
@DigitalInputNumber  INT,
@CurrentCounter     INT,
@PartitionOn        DATETIME,
@ModuleCount        INT,
@WandECount         INT,
@UtilityType        INT



 CREATE TABLE #WaterEnergyLoggerData
     (
	   Number                    INT,
      CurrentDayReading          DECIMAL(18,4),
      CurrentDayRunTime          INT,
      PreviousDayReading         DECIMAL(18,4),
      PreviousDayRuntime         INT,
	  CurrentDate                VARCHAR(50),
	  PrevoiusDate               VARCHAR(50)
     );
     INSERT INTO #WaterEnergyLoggerData
     (
	  Number,
	  CurrentDayReading,
      CurrentDayRunTime,
      PreviousDayReading,
      PreviousDayRuntime,
      CurrentDate,
      PrevoiusDate)
    SELECT T.c.value('@InputNumber','INT') AS Number,
	 T.c.value('@CurrentDayReading', 'DECIMAL(18,4)') AS CurrentReading, --CurrentDayReading
       T.c.value('@CurrentDayRunTime', 'INT') AS CurrentTime, --CurrentDayRunTime
       T.c.value('@PreviousDayReading', 'DECIMAL(18,4)') AS PreviousReading, --PreviousDayReading
       T.c.value('@PreviousDayRuntime', 'INT') AS PreviousRuntime, --PreviousDayRuntime
	   T.c.value('@CurrentDate','VARCHAR(50)') AS CurrentDate,
	   T.c.value('@PrevoiusDate','VARCHAR(50)') AS PrevoiusDate
    FROM @xmlTags.nodes('MyControlWaterEnergyLoggerData/DigitalInputData/DigitalData') T(C);

	SET @CurrentCounter=1;
	WHILE(@CurrentCounter<=32)
	BEGIN
	SELECT @MeterID=MeterId
   FROM tcd.Meter mt
   WHERE mt.ControllerID=@ControllerID 
   AND mt.DigitalInputNumber=@CurrentCounter
   AND mt.UtilityType=2

   SELECT @DigitalInputNumber=weld.Number,
   @CurrentDayReading=weld.CurrentDayReading,
   @CurrentDayRunTime=weld.CurrentDayRunTime,
   @PreviousDayReading=weld.PreviousDayReading,
   @PreviousDayRuntime=weld.PreviousDayRuntime,
   @CurrentDate=CONVERT(DATETIME,weld.CurrentDate),
   @PrevoiusDate=CONVERT(DATETIME,weld.PrevoiusDate)
   FROM #WaterEnergyLoggerData weld where Number=@CurrentCounter
    DECLARE @ShiftMapping TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    INSERT INTO @ShiftMapping
	    (
		  ShiftId,
		  ShiftName,
		  ShiftStartdate
	    )
	    EXEC TCD.GetShiftStartDate
		    @CurrentDate
	    SELECT 
			 @PartitionOn= ShiftStartdate
	    FROM @ShiftMapping;
	--SET @MeterId=2
   IF(ISNULL(@MeterId,0)>0 AND ISNULL(@DigitalInputNumber,0)>0 AND ISNULL(@CurrentDayReading,0)>0  AND ISNULL(@CurrentDate,0)>0)
   BEGIN
   SELECT @ModuleCount=COUNT(1) FROM TCD.ModuleReading WHERE ModuleId =@MeterId AND Reading =@CurrentDayReading
   IF(@ModuleCount=0)
   BEGIN
   INSERT INTO TCD.ModuleReading
   (ModuleId,ModuleTypeId,Reading,TimeStamp,PartitionOn)
   SELECT @MeterId,2,@CurrentDayReading,@CurrentDate,@PartitionOn
   END
   END
     IF(ISNULL(@MeterId,0)>0 AND ISNULL(@DigitalInputNumber,0)>0 AND ISNULL(@PreviousDayReading,0)>0  AND ISNULL(@PrevoiusDate,0)>0)
   BEGIN
   SELECT @ModuleCount=COUNT(1) FROM TCD.ModuleReading WHERE ModuleId =@MeterId AND Reading =@PreviousDayReading 
   IF(@ModuleCount=0)
   BEGIN
   INSERT INTO TCD.ModuleReading
   (ModuleId,ModuleTypeId,Reading,TimeStamp,PartitionOn)
   SELECT @MeterId,2,@PreviousDayReading,@PrevoiusDate,@PartitionOn
   END
   END
   IF(ISNULL(@MeterId,0)>0 AND ISNULL(@CurrentDayRunTime,0)>0)
   BEGIN
   SELECT @WandECount=COUNT(1) from TCD.WaterAndEnergyConsumptionLog WHERE MeterId=@MeterId AND Value=@CurrentDayRunTime
   IF(@WandECount=0)
   BEGIN
   INSERT INTO TCD.WaterAndEnergyConsumptionLog
   (MeterId,Value,CreatedDate)
   SELECT @MeterId,@CurrentDayRunTime,GETUTCDATE() 
   END
   END
   IF(ISNULL(@MeterId,0)>0 AND ISNULL(@PreviousDayRuntime,0)>0)
   BEGIN
    SELECT @WandECount=COUNT(1) from TCD.WaterAndEnergyConsumptionLog WHERE MeterId=@MeterId AND Value=@PreviousDayRuntime
   IF(@WandECount=0)
   BEGIN
   INSERT INTO TCD.WaterAndEnergyConsumptionLog
   (MeterId,Value,CreatedDate)
   SELECT @MeterId,@PreviousDayRuntime,GETUTCDATE() 
   END
   END
    SET @CurrentCounter=@CurrentCounter+1;
   END
END
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlWAndEAnalogData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlWAndEAnalogData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ProcessMyControlWAndEAnalogData]
(
@ControllerID   INT,
@xmlTags        XML
) 
	
AS
BEGIN
DECLARE @Reading DECIMAL(10,6),
@AnalogInputNumber INT,
@MachineCompartment INT,
@SensorId          INT,
@AnalogCount       INT

END

 CREATE TABLE #AnalogInputData
     (
      Number          INT,
      Quantity        DECIMAL(10,6),
     );
     INSERT INTO #AnalogInputData
     (Number,
  Quantity
     )
    SELECT T.c.value('@CounterNo', 'INT') AS Number, --AnalogNumber
       T.c.value('@Reading', 'DECIMAL(10,6)') AS Quantity --Water Quanity
    FROM @xmlTags.nodes('MyControlWaterEnergyLoggerAnalogData/AnalogInputData/AnalogData') T(C);
SET @AnalogInputNumber=1
While(@AnalogInputNumber<=8)
BEGIN
SELECT @SensorId=sr.SensorId,@MachineCompartment=sr.MachineCompartment
FROM TCD.Sensor sr 
WHERE sr.AnalogueInputNumber=@AnalogInputNumber AND sr.ControllerID=@ControllerID

 SELECT @Reading=wc.Quantity
  FROM #AnalogInputData wc where wc.Number=@AnalogInputNumber
 --SET @SensorId=1
 --SET @MachineCompartment=2
   SELECT @AnalogCount= COUNT(1) FROM TCD.SensorReading WHERE Reading =@Reading AND SensorId = @SensorId
  IF (@AnalogCount=0)
  BEGIN
  IF(ISNULL(@Reading,0)>0  AND ISNULL(@SensorId,0)>0 AND ISNULL(@MachineCompartment,0)>0)
  BEGIN
   INSERT INTO TCD.SensorReading
     (SensorId,
      Reading,
      TimeStamp
     )
     SELECT
     @SensorId,
     @Reading,
     GETUTCDATE()
  END
 SET @AnalogInputNumber=@AnalogInputNumber+1;
 END  
END
GO

----------------------------------------------End Water and Energy Logger Digital/Analog Inputs------------------------------------------------

----------------------------------------------Start Water consumption per batch changes------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlConventionalData_Online]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlConventionalData_Online]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ProcessMyControlConventionalData_Online]
(
	@ControllerID   INT,
	@VxML           XML,
	@RedFlagShiftId INT OUTPUT
)
AS
	BEGIN
	    DECLARE @MachineNumber           INT,
			  @StepNumber              INT,
			  @StartDateTime           DATETIME,
			  @EndDateTime             DATETIME,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @PHValue                 INT,
			  @TemperatureMin          INT,
			  @TemperatureMax          INT,
			  @TempMinStatus           INT,
			  @TempMaxStatus           INT,
			  @BatchNumber             INT,
			  @WasherID                INT,
			  @WasherGroupID           INT,
			  @EcoLabWasherID          INT,
			  @ProgramMasterID         INT,
			  @PlantWasherNumber       INT,
			  @ShiftID                 INT,
			  @FrmParameterID          INT,
			  @PHParameterID           INT,
			  @PHParameterStatus       INT,
			  @BatchID                 INT,
			  @ShiftStartdate          DATETIME,
			  @ShiftName               NVARCHAR(50),
			  @XMLDataID               INT,
			  @TempParameter           INT,
			  @TemperatureMinParam     INT,
			  @TemperatureMaxParam     INT,
			  @TempMinStatusParam      INT,
			  @TempMaxStatusParam      INT,
			  @WashStepNo              INT,
			  @CurrencyCode            VARCHAR(50),
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @TargetTurnTime          INT,
			  @MeterID                INT,
			  @WaterConsumption1      DECIMAL(18,4),
			  @WaterConsumption2      DECIMAL(18,4),
			  @ModuleCount			  INT

	    SELECT @MachineNumber = T.c.value('@MachineNumber', 'INT'),
			 @StepNumber = T.c.value('@StepNumber', 'INT'),
			 @StartDateTime = T.c.value('@StartDateTime', 'DATETIME'),
			 @EndDateTime = T.c.value('@EndDateTime', 'DATETIME'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@NominalLoad', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'INT'),
			 @PHStatus = T.c.value('@PHStatus', 'INT'),
			 @PHValue = T.c.value('@PHValue', 'INT'),
			 @TemperatureMin = T.c.value('@TemperatureMin', 'INT'),
			 @TemperatureMax = T.c.value('@TemperatureMax', 'INT'),
			 @TempMaxStatus = T.c.value('@TemperatureMaxStatus', 'INT'),
			 @TempMinStatus = T.c.value('@TemperatreMinStatus', 'INT'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @WaterConsumption1=T.c.value('@WaterConsumption1','DECIMAL(18,4)'),
			 @WaterConsumption2=T.c.value('@WaterConsumption2','DECIMAL(18,4)')
	    FROM @VxML.nodes('MyControlConventionalData') T(C);

		---Deletes Xml Data from max of timestamp to previous 7 days

		delete  from tcd.PLCXMLData where convert(date,Time_Stamp) <= DATEADD(day,-2,(select max(convert(date,Time_Stamp)) from tcd.PLCXMLData))

     --Inserts Xml Data

		INSERT INTO tcd.PLCXMLData
	    (
			 PLC_Type,
			 XML_Data,
			 XML_Type,
			 Batch_Number,
			 Time_Stamp
	    )
	       VALUES
				(
					 3,
					CONVERT(nvarchar(max), @VxML),
					 1,
					 ISNULL(@BatchNumber,0),		 
					 GETUTCDATE()
				);


	    SELECT @PHParameterID = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'pH';
	    SELECT @PHParameterStatus = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'PH Status';
	    SELECT @TemperatureMinParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Mimum Temperature';
	    SELECT @TemperatureMaxParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Maximum Temperature';
	    SELECT @TempMinStatusParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Minimum Temperature Status';
	    SELECT @TempMaxStatusParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Max Temperature Status';
	    SELECT @WashStepNo = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'StepCompartment No';
	    SELECT @FrmParameterID = [Id]
	    FROM TCD.ConduitPArameters
	    WHERE Name = 'Formula Number';
	    DECLARE @ShiftMapping TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    INSERT INTO @ShiftMapping
	    (
		  ShiftId,
		  ShiftName,
		  ShiftStartdate
	    )
	    EXEC TCD.GetShiftStartDate
		    @StartDateTime
	    SELECT @ShiftID = ShiftID,
			 @ShiftStartdate = ShiftStartdate
	    FROM @ShiftMapping;
	    SELECT @WasherGroupID = GroupId,
			 @WasherID = WasherID
	    FROM TCD.MachineSetup ms
	    WHERE ControllerID = @ControllerID
			AND MachineInternalId = @MachineNumber
			AND IsTunnel = 0
			AND IsDeleted = 0;
	    IF(@EndDateTime = '1/1/1900')
		   SELECT @EndDateTime = NULL;
	    IF(@StartDateTime = '1/1/1900')
		   SELECT @StartDateTime = NULL;
	    IF(@WasherId IS NOT NULL)
		   BEGIN
			  SELECT @ProgramMasterId = Wps.ProgramId
			  FROM TCD.Washer Ws
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.ControllerID = Wg.ControllerId
				  INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.EcoLabAccountNumber
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wps.Is_Deleted = 0;
			  SELECT @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber,
				    @CurrencyCode = P.CurrencyCode,
				    @TargetTurnTime = w.TargetTurnTime * 60
			  FROM TCD.Washer w
				  INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.EcolabAccountNumber
			  WHERE w.WasherId = @WasherID;
	   END;
	    SELECT @BatchID = BatchID
	    FROM TCD.BatchData
	    WHERE MachineInternalID = @MachineNumber
			AND StartDate = @StartDateTime
			AND ControllerBatchId = @BatchNumber
			AND MachineID = @WasherID;

	    --Start Getting InjectionCount and StepCount
	    SELECT @StdInjectionSteps = COUNT(DISTINCT wdpm.
	    WasherDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) -
			 COUNT(DISTINCT wdpm.WasherDosingSetupId)
	    FROM TCD.WasherDosingProductMapping wdpm
		    RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm.
		    WasherDosingSetupId = wds.WasherDosingSetupId
	    WHERE wds.ControllerID = @ControllerID
			AND wds.ProgramNumber = @ProgramNumber;
	    --End Getting InjectionCount and StepCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramMasterId
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT @EcolabTextileCategoryId = pcp.
			  EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp.
				    ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    IF(@BatchID IS NULL)
		   BEGIN
			  INSERT INTO TCD.BatchData
			  (ControllerBatchID,
			   EcolabWasherId,
			   GroupId,
			   MachineInternalId,
			   PlantWasherNumber,
			   StartDate,
			   EndDate,
			   ProgramNumber,
			   ProgramMasterId,
			   MachineID,
			   ActualWeight,
			   StandardWeight,
			   CurrencyCode,
			   ShiftId,
			   PartitionOn,
			   StdInjectionSteps,
			   StdWashSteps,
			   EcolabTextileCategoryId,
			   ChainTextileCategoryId,
			   FormulaSegmentId,
			   EcolabSaturationId,
			   PlantProgramId,
			   EndDateFormula,
			   TargetTurnTime
			  )
			  VALUES
			  (
				    @BatchNumber,
				    @EcoLabWasherID,
				    @WasherGroupID,
				    @MachineNumber,
				    @PlantWasherNumber,
				    @StartDateTime,
				    @EndDateTime,
				    @ProgramNumber,
				    @ProgramMasterId,
				    @WasherID,
				    @Load,
				    @NominalLoad,
				    @CurrencyCode,
				    @ShiftID,
				    @ShiftStartdate,
				    @StdInjectionSteps,
				    @StdWashSteps,
				    @EcolabTextileCategoryId,
				    @ChainTextileCategoryId,
				    @FormulaSegmentId,
				    @EcolabSaturationId,
				    @PlantProgramId,
				    @EndDateTime,
				    @TargetTurnTime
			  );
			  SELECT @BatchID = SCOPE_IDENTITY();
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM TCD.BatchParameters
				 WHERE BatchId = @BatchID
					  AND ParameterID = 38
			   )
			   BEGIN
			   IF(@StdWashSteps <> 0
				 OR @StdWashSteps <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
					   BatchId,
					   EcolabWasherId,
					   ParameterId,
					   ParameterValue,
					   PartitionOn
					)
					SELECT @BatchID,
						  @EcoLabWasherID,
						  38,
						  @StdWashSteps,
						  @ShiftStartdate;
				  END
			END;

			  --End Date  Time  is Null 
			  UPDATE TCD.BatchData
			    SET
				   EndDate = GETUTCDATE()
			  WHERE MachineInternalID = @MachineNumber
				   AND StartDate <> @StartDateTime
				   AND EndDate IS NULL
				   AND ControllerBatchId <> @BatchNumber
				   AND MachineId = @WasherId;	
																  		
			  -- Program Number	
			  IF(@ProgramNumber IS NOT NULL
				AND @ProgramNumber > 0)
				 BEGIN
					IF NOT EXISTS
					(
					    SELECT *
					    FROM TCD.WasherReading
					    WHERE WasherId = @WasherID
							AND ParameterID = @FrmParameterID
							AND DateTimeStamp = @StartDateTime
					)
					    BEGIN
						   INSERT INTO TCD.WasherReading
						   (WasherID,
						    ParameterID,
						    ParameterValue,
						    DateTimeStamp,
						    EcoLabWasherID,
						    Partitionon
						   )
						   VALUES
						   (
								@WasherID,
								@FrmParameterID,
								@ProgramNumber,
								@StartDateTime,
								@EcoLabWasherID,
								@ShiftStartdate
						   );
					    END;
				 END;
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM [TCD].[BatchCustomerData]
				 WHERE BatchID = @BatchId
					  AND @CustomerNumber IS NOT NULL
			  )
				 BEGIN
					INSERT INTO [TCD].[BatchCustomerData]
					([BatchId],
					 CustomerID,
					 [Weight],
					 PartitionOn,
					 EcolabWasherId
					)
					VALUES
					(
						  @BatchID,
						  @CustomerNumber,
						  @Load,
						  @ShiftStartdate,
						  @EcolabWasherID
					);
				 END;
		   END;

	    -- PH Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @PHParameterID
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@PHValue <> 0
				OR @PHValue <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @PHParameterID,
							    @PHValue,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 
	 
	    -- PH Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @PHParameterStatus
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@PHStatus <> 0
				OR @PHStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @PHParameterStatus,
							    @PHStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Min Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TemperatureMinParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TemperatureMin <> 0
				OR @TemperatureMin <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TemperatureMinParam,
							    @TemperatureMin,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Max Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TemperatureMaxParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TemperatureMax <> 0
				OR @TemperatureMax <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TemperatureMaxParam,
							    @TemperatureMax,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Min Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TempMinStatusParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TempMinStatus <> 0
				OR @TempMinStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TempMinStatusParam,
							    @TempMinStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Max Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TempMaxStatusParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TempMaxStatus <> 0
				OR @TempMaxStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TempMaxStatusParam,
							    @TempMaxStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- StepCompartment No
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @WashStepNo
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@StepNumber <> 0
				OR @StepNumber <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @WashStepNo,
							    @StepNumber,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END;
 --Start water consumption per batch

	SELECT @MeterID=MeterId
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@MachineNumber
   AND mt.CounterNum = 1;

   SELECT @ModuleCount= COUNT(1) FROM TCD.ModuleReading WHERE Reading =@WaterConsumption1 AND ModuleId = @MeterID
  IF (@ModuleCount=0)
  BEGIN
  IF(ISNULL(@WaterConsumption1,0) > 0 AND ISNULL(@MeterID,0) > 0)
  BEGIN
   INSERT INTO TCD.ModuleReading
     (ModuleId,
      ModuleTypeId,
      Reading,
      TimeStamp
     )
     SELECT
     @MeterID,
     2,	  --Water Meter
     @WaterConsumption1,
     GETUTCDATE()
  END
 END 
 
 SELECT @MeterID=MeterId
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@MachineNumber
   AND mt.CounterNum = 2; 
 -- set  @ModuleCount=@@ROWCOUNT
  SELECT @ModuleCount= COUNT(1) FROM TCD.ModuleReading WHERE Reading =@WaterConsumption2 AND ModuleId = @MeterID
  IF (@ModuleCount=0)
  BEGIN
  IF(ISNULL(@WaterConsumption2,0) > 0 AND ISNULL(@MeterID,0) > 0)
  BEGIN
   INSERT INTO TCD.ModuleReading
     (ModuleId,
      ModuleTypeId,
      Reading,
      TimeStamp
     )
     SELECT
     @MeterID, 
     2,
     @WaterConsumption2,
     GETUTCDATE()
  END
      END   
	 --End water consumption per batch
 END;
 
 GO

 IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlConventionalData_CompletedBatches]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlConventionalData_CompletedBatches]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ProcessMyControlConventionalData_CompletedBatches](
	@ControllerID   INT,
	@VxML           XML,
	@PLCPointer     INT,
	@ReadPointer    INT,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @MachineNumber           INT,
			  @StartDateTime           DATETIME,
			  @EndDateTime             DATETIME,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @PHValue                 INT,
			  @TemperatureMin          INT,
			  @TemperatureMax          INT,
			  @TempMinStatus           INT,
			  @TempMaxStatus           INT,
			  @BatchNumber             INT,
			  @WasherID                INT,
			  @WasherGroupID           INT,
			  @EcoLabWasherID          INT,
			  @ProgramMasterID         INT,
			  @PlantWasherNumber       INT,
			  @ShiftID                 INT,
			  @BatchID                 INT,
			  @ShiftStartdate          DATETIME,
			  @LastStep                INT,
			  @CurrentStep             INT,
			  @CurrentStepTime         DATETIME,
			  @MinTempParamID          INT,
			  @MaxTempParamID          INT,
			  @MinTempStatuParamID     INT,
			  @MaxTempStatusParamID    INT,
			  @PHStatusParamID         INT,
			  @PHValueParamID          INT,
			  @CurrencyCode            VARCHAR(50),
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @ActualInjSteps          INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @TargetTurnTime          INT,
			  @PreviousShiftId         INT,
			  @CurrentShiftId          INT,
			  @MeterID                 INT,
			  @StepComportment         INT,
			  @Stepno                  INT,
			  @quantity                INT,
			  @productid               INT,
			  @Price                   DECIMAL(18, 4),
			  @StandardQty             DECIMAL(18, 4),
			  @TimeStamp               DATETIME2(7),
			  @MaxWashertGroupCapacity INT,
			  @InjectionNumber         INT,
			  @WaterConsumption1       DECIMAL(10,6),
			  @WaterConsumption2       DECIMAL(10,6),
			  @EnergyCount             INT
	    SELECT
			 @MachineNumber = T.c.value('@MachineNumber', 'INT'),
			 @StartDateTime = T.c.value('@StartDateTime', 'DateTime'),
			 @EndDateTime = T.c.value('@EndDateTime', 'DateTime'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@NominalLoad', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'INT'),
			 @PHStatus = T.c.value('@PHStatus', 'INT'),
			 @PHValue = T.c.value('@PHValue', 'INT'),
			 @TemperatureMin = T.c.value('@TemperatureMin', 'INT'),
			 @TemperatureMax = T.c.value('@TemperatureMax', 'INT'),
			 @TempMaxStatus = T.c.value('@TemperatureMaxStatus', 'INT'),
			 @TempMinStatus = T.c.value('@TemperatreMinStatus', 'INT'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @WaterConsumption1 = T.c.value('@WaterConsumption1','DECIMAL(10,6)'),
			 @WaterConsumption2 = T.c.value('@WaterConsumption2','DECIMAL(10,6)')
	    FROM @VxML.nodes('MyControlConventionalData') T(C);

		--Inserts Xml Data
		INSERT INTO tcd.PLCXMLData
	    (
			 PLC_Type,
			 XML_Data,
			 XML_Type,
			 Batch_Number,
			 Time_Stamp
	    )
	       VALUES
				(
					 3,
					CONVERT(nvarchar(max), @VxML),
					 2,
					ISNULL(@BatchNumber,0),		 
					 GETUTCDATE()
				);

	    DECLARE @ShiftMapping TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    INSERT INTO @ShiftMapping
	    (
			 ShiftId,
			 ShiftName,
			 ShiftStartdate
	    )
	    EXEC TCD.GetShiftStartDate
		    @StartDateTime;
	    SELECT
			 @ShiftID = ShiftID,
			 @ShiftStartdate = ShiftStartdate
	    FROM @ShiftMapping;
	    SELECT
			 @WasherGroupID = GroupId,
			 @WasherID = WasherID
	    FROM TCD.MachineSetup ms
	    WHERE ControllerID = @ControllerID
			AND MachineInternalId = @MachineNumber
			AND IsTunnel = 0
			AND IsDeleted = 0;
	    IF(@WasherId IS NOT NULL)
		   BEGIN
			  SELECT
				    @ProgramMasterId = Wps.ProgramId
			  FROM TCD.Washer Ws
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws
				  .WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =
				  Mst.GroupId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.
				  ControllerID = Wg.ControllerId
				  INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber =
				  Ws.EcoLabAccountNumber
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wps.Is_Deleted = 0;
			  SELECT
				    @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber,
				    @CurrencyCode = P.CurrencyCode,
				    @TargetTurnTime = w.TargetTurnTime * 60
			  FROM TCD.Washer w
				  INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.
				  EcolabAccountNumber
			  WHERE w.WasherId = @WasherID;
		   END;
	    SELECT
			 @BatchID = BatchID
	    FROM TCD.BatchData
	    WHERE MachineInternalID = @MachineNumber
			AND StartDate = @StartDateTime
			AND ControllerBatchId = @BatchNumber
			AND MachineID = @WasherID;

	    --Start Getting InjectionCount and StepCount

	    SELECT
			 @StdInjectionSteps = COUNT(DISTINCT wdpm.
			 WasherDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) -
			 COUNT(DISTINCT wdpm.WasherDosingSetupId)
	    FROM TCD.WasherDosingProductMapping wdpm
		    RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm.
		    WasherDosingSetupId = wds.WasherDosingSetupId
	    WHERE wds.ControllerID = @ControllerID
			AND wds.ProgramNumber = @ProgramNumber;

	    --End Getting InjectionCount and StepCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT
			 @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramMasterId
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT
				    @EcolabTextileCategoryId = pcp.
				    EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp.
				    ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    IF(@BatchID IS NULL)
		   BEGIN

			  --Start Rollup for previous completed shift
			  IF(CAST(@StartDateTime AS DATE) < CAST(GETUTCDATE() AS
			  DATE))
				 BEGIN
					SELECT TOP 1
						  @PreviousShiftId = ShiftId
					FROM TCD.BatchData
					WHERE MachineId = @WasherId
					ORDER BY
						    StartDate DESC;
					SELECT TOP 1
						  @CurrentShiftId = ShiftId
					FROM @ShiftMapping;
					IF(@CurrentShiftId != @PreviousShiftId)
					    BEGIN
						   EXEC TCD.ProductionShiftDataRollup
							   @PreviousShiftId,
							   @RedFlagShiftId OUTPUT;
						   IF(@RedFlagShiftId IS NULL)
							  BEGIN
								 SET @RedFlagShiftId =
								 @PreviousShiftId;
							  END;
					    END;
				 END;
			  --End Rollup for previous completed shift

			  INSERT INTO TCD.BatchData
			  (
				    ControllerBatchID,
				    EcolabWasherId,
				    GroupId,
				    MachineInternalId,
				    PlantWasherNumber,
				    StartDate,
				    EndDate,
				    ProgramNumber,
				    ProgramMasterId,
				    MachineID,
				    ActualWeight,
				    StandardWeight,
				    CurrencyCode,
				    ShiftId,
				    PartitionOn,
				    StdInjectionSteps,
				    StdWashSteps,
				    EcolabTextileCategoryId,
				    ChainTextileCategoryId,
				    FormulaSegmentId,
				    EcolabSaturationId,
				    PlantProgramId,
				    EndDateFormula,
				    TargetTurnTime
			  )
			  VALUES
			  (
				    @BatchNumber,
				    @EcoLabWasherID,
				    @WasherGroupID,
				    @MachineNumber,
				    @PlantWasherNumber,
				    @StartDateTime,
				    @EndDateTime,
				    @ProgramNumber,
				    @ProgramMasterId,
				    @WasherID,
				    @Load,
				    @NominalLoad,
				    @CurrencyCode,
				    @ShiftID,
				    @ShiftStartdate,
				    @StdInjectionSteps,
				    @StdWashSteps,
				    @EcolabTextileCategoryId,
				    @ChainTextileCategoryId,
				    @FormulaSegmentId,
				    @EcolabSaturationId,
				    @PlantProgramId,
				    @EndDateTime,
				    @TargetTurnTime
			  );
			  SELECT
				    @BatchID = SCOPE_IDENTITY();
			  IF NOT EXISTS
			  (
				 SELECT
					   *
				 FROM TCD.BatchParameters
				 WHERE BatchId = @BatchID
					  AND ParameterID = 38
			  )
				 BEGIN
					IF(@StdWashSteps > 0
					   OR @StdWashSteps <> NULL)
					    INSERT INTO TCD.BatchParameters
					    (
							 BatchId,
							 EcolabWasherId,
							 ParameterId,
							 ParameterValue,
							 PartitionOn
					    )
					    SELECT
							 @BatchID,
							 @EcoLabWasherID,
							 38,
							 @StdWashSteps,
							 @ShiftStartdate;
				 END;
		   END;
	    ELSE
		   BEGIN
			  UPDATE tcd.BatchData
			    SET
				   EndDate = @EndDateTime,
				   EndDateFormula = @EndDateTime,
				   ProgramNumber = @ProgramNumber,
				   ProgramMasterId = @ProgramMasterID,
				   ActualWeight = @Load,
				   SyncReady = 1
			  WHERE
				   BatchID = @BatchID;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				1
		   FROM [TCD].[BatchCustomerData]
		   WHERE BatchID = @BatchId
			    AND @CustomerNumber IS NOT NULL
	    )
		   BEGIN
			  INSERT INTO [TCD].[BatchCustomerData]
			  (
				    [BatchId],
				    CustomerID,
				    [Weight],
				    PartitionOn,
				    EcolabWasherId
			  )
			  VALUES
			  (
				    @BatchID,
				    @CustomerNumber,
				    @Load,
				    @ShiftStartdate,
				    @EcolabWasherID
			  );
		   END;
	    ELSE
	    IF(@CustomerNumber > 0)
		   BEGIN
			  UPDATE [TCD].[BatchCustomerData]
			    SET
				   CustomerID = @CustomerNumber,
				   [Weight] = @Load
			  WHERE
				   BatchID = @BatchId;
		   END;
	    CREATE TABLE #Dosing
	    (
		    equipmentNo INT,
		    StepNo      INT,
		    Qty         DECIMAL(10, 6)
	    );
	    INSERT INTO #Dosing
	    SELECT
			 T.c.value('@Equipment', 'INT'),
			 T.c.value('@stepNo', 'INT'),
			 T.c.value('@Qty', 'Decimal(10,6)')
	    FROM @VxML.nodes('MyControlConventionalData/DosingData/Dosing') T
	    (C)
	    WHERE T.c.value('@Qty', 'Decimal(10,6)') > 0;
	    CREATE TABLE #StepTime
	    (
		    Number    INT,
		    [Time]    INT,
		    StartTime DATETIME,
		    EndTime   DATETIME
	    );
	    INSERT INTO #StepTime
	    (
			 Number,
			 [Time]
	    )
	    SELECT
			 T.c.value('@Number', 'INT'),
			 T.c.value('@Time', 'INT')
	    FROM @VxML.nodes('MyControlConventionalData/StepTime/Step') T(C);
	    CREATE TABLE #TimeStamp
	    (
		    Step_Number INT,
		    Time_Stamp  INT
	    );
	
	    --For Calculating TIME_STAMP

	    WITH TempTable
		    AS (SELECT DISTINCT
					Number
			   FROM #StepTime)
		    INSERT INTO #TimeStamp
		    (
				 Step_Number,
				 Time_Stamp
		    )
		    SELECT
				 b.Number,
				 SUM(t.Time) Time_Stamp
		    FROM TempTable b
			    INNER JOIN #StepTime t ON b.Number >= t.Number
		    GROUP BY
				   b.Number;
	    CREATE TABLE #BatchProductData
	    (
		    equipmentNo INT,
		    StepNo      INT,
		    Qty         DECIMAL(10, 6),
		    Time_Stamp  DATETIME2(7),
		    ProductId   INT,
		    Row_No      INT
	    );
	    INSERT INTO #BatchProductData
	    (
			 EquipmentNo,
			 StepNo,
			 Qty,
			 Time_Stamp,
			 ProductId,
			 Row_No
	    )
	    SELECT
			 d.equipmentNo,
			 d.StepNo,
			 d.Qty,
			 DATEADD(ss, ts.Time_Stamp, @StartDateTime),
			 ces.ProductId,
			 ROW_NUMBER() OVER(ORDER BY d.StepNo DESC) AS Row
	    FROM #Dosing d
		    INNER JOIN #TimeStamp ts ON d.StepNo = ts.Step_Number
		    INNER JOIN tcd.ControllerEquipmentSetup ces ON ces.
		    ControllerEquipmentId = d.equipmentNo
	    WHERE d.equipmentNo > 0
			AND d.Qty > 0
			AND ControllerID = @ControllerID
			AND ces.ProductId IS NOT NULL;
	    SELECT
			 @MaxWashertGroupCapacity = MAX(ws.MaxLoad)
	    FROM TCD.Washer WS
		    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.
		    GroupId
	    WHERE Mst.GroupId = @WasherGroupID;
	    DECLARE @Counter INT;
	    SET @counter = 1;
	    WHILE(@counter <=
		    (
			   SELECT
					COUNT(ROW_No)
			   FROM #BatchProductData bpd
		    ))
		   BEGIN
			  SELECT
				    @stepno = bpd.StepNo,
				    @quantity = bpd.Qty,
				    @productid = bpd.ProductId,
				    @timestamp = bpd.Time_Stamp
			  FROM #BatchProductData bpd
			  WHERE bpd.Row_No = @counter
			  ORDER BY
					 bpd.StepNo;
			  SELECT
				    @InjectionNumber = Wdpm.InjectionNumber,
				    @standardqty = ((@NominalLoad / CONVERT( DECIMAL(
				    10, 2), 100)) * Wdpm.Quantity * Ws.MaxLoad) /
				    CONVERT(DECIMAL(10, 2), 100),
				    @price = ((@NominalLoad / CONVERT(       DECIMAL(
				    10, 2), 100)) * Wdpm.Quantity *
				    @MaxWashertGroupCapacity) / CONVERT(DECIMAL(10, 2),
				    100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID)
			  FROM TCD.Washer WS
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws
				  .WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =
				  Mst.GroupId
				  INNER JOIN TCD.WasherGroupType WgT ON WgT.
				  WasherGroupTypeId = Wg.WasherGroupTypeId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.
				  ControllerID = Wg.ControllerId
				  INNER JOIN TCD.WasherDosingSetup Wds ON Wds.
				  WasherProgramSetupId = Wps.WasherProgramSetupId
				  INNER JOIN TCD.WasherDosingProductMapping Wdpm ON
				  Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
				  INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.
				  ProductId = Wdpm.ProductId
				  INNER JOIN TCD.BatchData Bd ON Bd.MachineId = Ws.
				  WasherId
			  WHERE Ws.WasherId = @WasherID
				   AND Wps.ProgramNumber = @ProgramNumber
				   --AND Wdpm.InjectionNumber = @stepno
				   AND Bd.BatchId = @BatchID
				   AND Wps.Is_Deleted = 0
				   AND Pdm.Is_Deleted = 0;
			  INSERT INTO TCD.BatchProductData
			  (
				    BatchId,
				    StepCompartment,
				    ActualQuantity,
				    StandardQuantity,
				    Price,
				    PartitionOn,
				    EcolabWasherId,
				    ProductId,
				    TimeStamp,
				    InjectionNumber
			  )
			  VALUES
			  (
				    @BatchID,
				    @stepno,
				    @quantity,
				    @standardqty,
				    @price,
				    @ShiftStartdate,
				    @EcolabWasherId,
				    @productid,
				    @timestamp,
				    @InjectionNumber
			  );
			  SET @counter = @counter + 1;
		   END;
	    --END For calculating TIMESTAMP
	    --Start Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
	    SELECT
			 @ActualInjSteps = COUNT(DISTINCT StepNo)
	    FROM #Dosing;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE ParameterId = 37
			    AND batchid = @BatchID
			    AND @ActualInjSteps > 0
	    )
		   BEGIN
			  IF(@ActualInjSteps > 0
				OR @ActualInjSteps IS NOT NULL)
				 INSERT INTO TCD.BatchParameters
				 (
					   BatchId,
					   EcolabWasherId,
					   ParameterId,
					   ParameterValue,
					   PartitionOn
				 )
				 SELECT
					   @BatchId,
					   @EcolabWasherId,
					   37,
					   @ActualInjSteps,
					   @ShiftStartDate;
		   END;
	    ELSE
		   BEGIN
			  UPDATE TCD.BatchParameters
			    SET
				   ParameterValue = @ActualInjSteps
			  WHERE
				   ParameterId = 37
				   AND batchid = @BatchID;
		   END;
	    SELECT
			 @LastStep = MAX([Number])
	    FROM #StepTime
	    WHERE [Time] > 0;
	    SELECT
			 @CurrentStep = 1,
			 @CurrentStepTime = @StartDateTime;
	    WHILE(@CurrentStep <= @LastStep)
		   BEGIN
			  UPDATE #StepTime
			    SET
				   StartTime = @CurrentStepTime,
				   EndTime = DATEADD(ss, [time], @CurrentStepTime)
			  WHERE
				   Number = @CurrentStep;
			  SELECT
				    @CurrentStepTime = EndTime
			  FROM #StepTime
			  WHERE Number = @CurrentStep;
			  SELECT
				    @CurrentStep = @CurrentStep + 1;
		   END;
	    INSERT INTO [TCD].[BatchWashStepData]
	    (
			 BatchID,
			 StepCompartment,
			 StartTime,
			 EndTime,
			 PartitionOn,
			 EcolabWasherId
	    )
	    SELECT
			 @BatchID,
			 Number,
			 StartTime,
			 EndTime,
			 @ShiftStartdate,
			 @EcoLabWasherID
	    FROM #StepTime
	    WHERE Number <= @LastStep;
	    SELECT
			 @MinTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Mimum Temperature';
	    SELECT
			 @MaxTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Maximum Temperature';
	    SELECT
			 @MaxTempStatusParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Max Temperature Status';
	    SELECT
			 @MinTempStatuParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Minimum Temperature Status';
	    SELECT
			 @PHValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH';
	    SELECT
			 @PHStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH Status';
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MinTempParamID
	    )
		   BEGIN
			  IF(@TemperatureMin <> 0
				OR @TemperatureMin <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MinTempParamID,
						  @TemperatureMin,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MaxTempParamID
	    )
		   BEGIN
			  IF(@TemperatureMax <> 0
				OR @TemperatureMax <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MaxTempParamID,
						  @TemperatureMax,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MaxTempStatusParamID
	    )
		   BEGIN
			  IF(@TempMaxStatus <> 0
				OR @TempMaxStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MaxTempStatusParamID,
						  @TempMaxStatus,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MinTempStatuParamID
	    )
		   BEGIN
			  IF(@TempMinStatus <> 0
				OR @TempMinStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MinTempStatuParamID,
						  @TempMinStatus,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF(@PHStatus <> 0
		  OR @PHStatus <> NULL)
		   BEGIN
			  INSERT INTO TCD.BatchParameters
			  (
				    BatchId,
				    EcolabWasherId,
				    ParameterId,
				    ParameterValue,
				    PartitionOn
			  )
			  VALUES
			  (
				    @BatchID,
				    @EcoLabWasherID,
				    @PHStatusParamID,
				    @PHStatus,
				    @ShiftStartdate
			  );
		   END;
	    IF(@PHValue <> 0
		  OR @PHValue <> NULL)
		   BEGIN
			  INSERT INTO TCD.BatchParameters
			  (
				    BatchId,
				    EcolabWasherId,
				    ParameterId,
				    ParameterValue,
				    PartitionOn
			  )
			  VALUES
			  (
				    @BatchID,
				    @EcoLabWasherID,
				    @PHValueParamID,
				    @PHValue,
				    @ShiftStartdate
			  );
		   END;
	    EXEC TCD.ProcessMyControlProductionWaterConsumptionData
		    @BatchID,
		    @VxML,
		    @ShiftStartDate;
	    DROP TABLE #BatchProductData;
	    DROP TABLE #Dosing;
	    DROP TABLE #StepTime;
	    DROP TABLE #TimeStamp;

		--Start water consumption per batch

	SELECT @MeterID=MeterId,@StepComportment=MachineCompartment
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@MachineNumber
   AND mt.CounterNum = 1;


   SELECT @EnergyCount=COUNT(1) FROM TCd.BatchStepWaterUsageData bswud WHERE BatchId =@BatchID AND StepCompartment =@StepComportment AND ActualQuantity=@WaterConsumption1
    IF(@EnergyCount=0)
  BEGIN
  IF(ISNULL(@WaterConsumption1,0)>0  AND ISNULL(@MeterID,0)>0  AND ISNULL(@StepComportment,0)>0)
  BEGIN
   INSERT INTO TCD.BatchStepWaterUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
	  EcolabWasherId
     )
     SELECT
     @BatchID,
     @StepComportment,
     @WaterConsumption1,
     @ShiftStartdate,
	 @EcoLabWasherID
	 END
      END  

	 SELECT @MeterID=MeterId,@StepComportment=MachineCompartment
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@MachineNumber
   AND mt.CounterNum = 2;
SELECT @EnergyCount=COUNT(1) FROM TCd.BatchStepWaterUsageData WHERE BatchId =@BatchID AND StepCompartment =@StepComportment AND ActualQuantity=@WaterConsumption2
 IF(@EnergyCount=0)
  BEGIN
  IF(ISNULL(@WaterConsumption2,0)>0  AND ISNULL(@MeterID,0)>0  AND ISNULL(@StepComportment,0)>0)
  BEGIN
   INSERT INTO TCD.BatchStepWaterUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
	  EcolabWasherId
     )
     SELECT
     @BatchID,
     @StepComportment,
     @WaterConsumption2,
     @ShiftStartdate,
	 @EcoLabWasherID
	 END
      END   
	  --End water consumption per batch
	END;
GO
 IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlTunnelWasherOnlineData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlTunnelWasherOnlineData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessMyControlTunnelWasherOnlineData](
	@ControllerID   INT,
	@xmlTags        XML,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @BatchID                 INT,
			  @WasherID                INT,
			  @EcolabWasherId          INT,
			  @CurrencyCode            VARCHAR(50),
			  @MachineInternalId       INT,
			  @WasherGroupID           INT,
			  @PlantWasherNumber       INT,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @BatchNumber             INT,
			  @TargetTurnTime          INT,
			  @PartitionOn             DATETIME,
			  @BatchStartTime          DATETIME,
			  @ProgramID               INT,
			  @NumberOfCompartments    INT,
			  @TransferSignalId        INT,
			  @BatchShiftId            INT,
			  @compartmentID           INT,
			  @TunnelXML               XML,
			  @TempXML                 XML,
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @CurrentStepComportmentNO INT,
               @CounterNO               INT,
               @MeterID                 INT,
              @ActualQuantity          DECIMAL(10,6),
			  @WasherModuleCount        INT

	    SELECT @TransferSignalId = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Transfer Signal';
	    CREATE TABLE #Batches
	    (
		    BatchNumber   INT,
		    StartDateTime DATETIME
	    );
	    -- SET @compartmentID = 1;

	    SELECT @TempXML = T.c.query('.')
	    FROM @xmlTags.nodes('MyControlTunnel') AS T(c);

	    SELECT @MachineInternalID = T.c.value('@MachineNumber', 'int')
	    FROM @TempXML.nodes('MyControlTunnel') AS T(c);
	    SELECT @EcolabWasherID = EcolabWasherId,
			 @WasherGroupID = Wg.WasherGroupId,
			 @PlantWasherNumber = PlantWasherNumber,
			 @WasherID = ws.WasherId,
			 @CurrencyCode = P.CurrencyCode,
			 @NumberOfCompartments = Mst.NumberofComp
	    FROM TCD.Washer AS Ws
		    INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = Ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.
		    GroupId
		    INNER JOIN TCD.WasherGroupType AS WgT ON WgT.
		    WasherGroupTypeId = Wg.WasherGroupTypeId
		    INNER JOIN TCD.ConduitController AS Ctrl ON Ctrl.
		    ControllerId = Mst.ControllerId
		    INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.
		    EcoLabAccountNumber
	    WHERE Ctrl.ControllerID = @ControllerID
			AND mst.MachineInternalId = @MachineInternalID
			AND Mst.IsTunnel = 1 AND Mst.IsDeleted =0;
	    SET @compartmentID = @NumberOfCompartments;
	    WHILE(@compartmentID <= @NumberOfCompartments
			AND @compartmentID > 0)
		   BEGIN
			  SELECT @TunnelXML = T.c.query('.')
			  FROM @xmlTags.nodes('MyControlTunnel/TunnelData') AS T(c)
			  WHERE T.c.value('@CompartmentNumber', 'INT') =
			  @compartmentID;
			  SELECT @MachineInternalID = T.c.value('@MachineNumber',
			  'int'
										    ),
				    @BatchNumber = T.c.value('@BatchNumber', 'INT'),
				    @BatchStartTime = T.c.value('@StartDateTime',
				    'DateTime'
										 ),
				    @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
				    @Load = T.c.value('@Load', 'Decimal(10,6)'),
				    @NominalLoad = T.c.value('@Nominalload',
				    'Decimal(10,6)'
									   ),
				    @CustomerNumber = T.c.value('@CustomerNumber',
				    'int'
										 ),
				    @PHStatus = T.c.value('@pHStatus', 'int')
			  FROM @TunnelXML.nodes('TunnelData') AS T(c);

			  --Inserts Xml Data
		INSERT INTO tcd.PLCXMLData
	    (
			 PLC_Type,
			 XML_Data,
			 XML_Type,
			 Batch_Number,
			 Time_Stamp
	    )
	       VALUES
				(
					 3,
					CONVERT(nvarchar(max), @xmlTags),
					 1,
					 ISNULL(@BatchNumber,0),			 
					 GETUTCDATE()
				);

			  DECLARE @ShiftStartDateTemp TABLE
			  (
				  ShiftId        INT,
				  ShiftName      NVARCHAR(50),
				  ShiftStartdate DATETIME
			  );
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchStartTime
			  SELECT @BatchShiftId = ShiftID,
				    @PartitionOn = ShiftStartdate
			  FROM @ShiftStartDateTemp;
			  IF(@ProgramNumber = 0
				OR @BatchNumber = 1)
				 BEGIN
					SELECT @compartmentID = @compartmentID - 1;
					CONTINUE;
				 END;
			  SELECT @ProgramID = ProgramId,
				    @TargetTurnTime = 3600 / (tps.TotalRunTime /
				    @NumberOfCompartments)
			  FROM TCD.TunnelProgramSetup AS tps
			  WHERE tps.WasherGroupId = @WasherGroupID
				   AND tps.is_deleted = 0
				   AND ProgramNumber = @ProgramNumber;
			  INSERT INTO #Batches
			  (BatchNumber,
			   StartDateTime
			  )
				    SELECT @BatchNumber,
						 @BatchStartTime;
			  SELECT @BatchID = NULL;
			  SELECT @BatchID = BatchID
			  FROM TCD.BatchData AS BD
			  WHERE BD.ControllerBatchId = @BatchNumber
				   AND BD.StartDate = @BatchStartTime
				   AND BD.MachineId = @WasherID;
			  --Start Getting InjectionCount,StepCount And ProductCount
			  SELECT @StdInjectionSteps = COUNT(tdpm.
			  TunnelDosingSetupId),
				    @StdWashSteps = COUNT(DISTINCT tds.
				    TunnelDosingSetupId) - COUNT(tdpm.
				    TunnelDosingSetupId)
			  FROM tcd.TunnelDosingProductMapping AS tdpm
				  RIGHT JOIN tcd.TunnelDosingSetup AS tds ON tdpm.
				  TunnelDosingSetupId = tds.TunnelDosingSetupId
			  WHERE tds.GroupId = @WasherGroupID
				   AND tds.ProgramNumber = @ProgramNumber;
			  --End Getting InjectionCount,StepCount And ProductCount
			  --Start-----ProgramMasterID logic for PlantChainProgram
			  SELECT @PlantProgramId = pm.PlantProgramId,
				    @EcolabTextileCategoryId = pm.
				    EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pm.ChainTextileId,
				    @FormulaSegmentId = pm.FormulaSegmentId,
				    @EcolabSaturationId = pm.EcolabSaturationId
			  FROM TCD.ProgramMaster AS pm
			  WHERE pm.ProgramId = @ProgramID
				   AND pm.Is_Deleted = 0;
			  IF(@PlantProgramId <> 0
				OR @PlantProgramId IS NOT NULL)
				 BEGIN
					--Assign value from plantchainprogram table based on plantprogramId
					SELECT @EcolabTextileCategoryId = pcp.
					EcolabTextileCategoryId,
						  @ChainTextileCategoryId = pcp.
						  ChainTextileCategoryId,
						  @FormulaSegmentId = pcp.FormulaSegmentId,
						  @EcolabSaturationId = pcp.
						  EcolabSaturationId
					FROM tcd.PlantChainProgram AS pcp
					WHERE pcp.PlantProgramId = @PlantProgramId
						 AND pcp.Is_Deleted = 0;
				 END;
			  --End-----ProgramMasterID logic for PlantChainProgram
			  IF @BatchID IS NULL
				 BEGIN
					INSERT INTO TCD.BatchData
					(ControllerBatchId,
					 EcolabWasherId,
					 GroupId,
					 MachineInternalId,
					 PlantWasherNumber,
					 StartDate,
					 ProgramNumber,
					 ProgramMasterId,
					 MachineId,
					 ActualWeight,
					 StandardWeight,
					 CurrencyCode,
					 ShiftId,
					 PartitionOn,
					 TargetTurnTime,
					 StdInjectionSteps,
					 StdWashSteps,
					 EcolabTextileCategoryId,
					 ChainTextileCategoryId,
					 FormulaSegmentId,
					 EcolabSaturationId,
					 PlantProgramId
					)
						  SELECT @BatchNumber,
							    @EcolabWasherID,
							    @WasherGroupID,
							    @MachineInternalID,
							    @PlantWasherNumber,
							    @BatchStartTime,
							    @ProgramNumber,
							    @ProgramID,
							    @WasherID,
							    @Load,
							    @NominalLoad,
							    @CurrencyCode,
							    @BatchShiftId,
							    @PartitionOn,
							    @TargetTurnTime,
							    @StdInjectionSteps,
							    @StdWashSteps,
							    @EcolabTextileCategoryId,
							    @ChainTextileCategoryId,
							    @FormulaSegmentId,
							    @EcolabSaturationId,
							    @PlantProgramId;
					SELECT @BatchID = SCOPE_IDENTITY();
					IF(@StdWashSteps > 0
					   OR @StdWashSteps <> NULL)
					    BEGIN
						   INSERT INTO TCD.BatchParameters
						   (BatchId,
						    EcolabWasherId,
						    ParameterId,
						    ParameterValue,
						    PartitionOn
						   )
								SELECT @BatchID,
									  @EcolabWasherId,
									  38,
									  @StdWashSteps,
									  @PartitionOn;
					    END;
					IF @CustomerNumber IS NOT NULL
					    BEGIN
						   IF NOT EXISTS
						   (
							  SELECT 1
							  FROM TCD.BatchCustomerData
							  WHERE BatchID = @BatchID
						   )
							  BEGIN
								 INSERT INTO TCD.BatchCustomerData
								 (BatchId,
								  CustomerID,
								  Weight,
								  PartitionOn,
								  EcolabWasherId
								 )
									   SELECT @BatchID,
											@CustomerNumber,
											@Load,
											@PartitionOn,
											@EcolabWasherId;
							  END;
					    END;
				 END;
			  -- Transfer Signal
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM tcd.WasherReading wr
				 WHERE wr.WasherId = @WasherID
					  AND wr.ParameterId = @TransferSignalId
					  AND wr.DateTimeStamp = @BatchStartTime
			  )
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterId,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TransferSignalId,
							    1,
							    @BatchStartTime,
							    @PartitionOn,
							    @EcolabWasherId
						  UNION ALL
						  SELECT @WasherID,
							    @TransferSignalId,
							    0,
							    @BatchStartTime,
							    @PartitionOn,
							    @EcolabWasherId;
				 END;
			  --Start Updating Batch Wash Step Data	 
			  EXEC TCD.UPDATEBatchWashStepForTunnel
				  @TunnelXML,
				  @WasherID,
				  @BatchID,
				  @BatchStartTime,
				  @PartitionOn,
				  @EcolabWasherId,
				  @compartmentID;
			  --End Updating Batch Wash Step Data	 
			  SELECT @compartmentID = @compartmentID - 1;
		   END;


	 --Start water consumption per step


   CREATE TABLE #WaterConsumptionData
     (
      Number          INT,
      Quantity        DECIMAL(10,6),
     );
     INSERT INTO #WaterConsumptionData
     (Number,
  Quantity
     )
    SELECT T.c.value('@Counter', 'INT') AS Number, --PumpNumber
       T.c.value('@Value', 'DECIMAL(10,6)') AS Quantity --Water Quanity
    FROM @xmlTags.nodes('MyControlTunnel/TunnelData/WaterConsumption') T(C);

  SET @CurrentStepComportmentNO=1;
  WHILE(@CurrentStepComportmentNO<=22)
  BEGIN
   SELECT @MeterID=MeterId,@CounterNO=mt.CounterNum
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@CurrentStepComportmentNO;
   SELECT @ActualQuantity=wc.Quantity
  FROM #WaterConsumptionData wc where wc.Number=@CounterNO
  SELECT @WasherModuleCount=COUNT(1) FROM TCD.WasherModuleOnlineUsageData WHERE WasherId = @WasherID AND StepComportment =@CurrentStepComportmentNO AND ModuleId = @MeterID AND ActualQuantity=@ActualQuantity
  IF(@WasherModuleCount=0)
  BEGIN
  IF(ISNULL(@WasherID,0)>0 AND ISNULL(@MeterID,0)>0 AND ISNULL(@ActualQuantity,0)>0 AND ISNULL(@CurrentStepComportmentNO,0)>0)
  BEGIN
   INSERT INTO TCD.WasherModuleOnlineUsageData
     (WasherId,
      StepComportment,
      ModuleId,
      ActualQuantity,
      TimeStamp,
      EcolabWasherId
     )
     SELECT
     @WasherID,
     @CurrentStepComportmentNO,
     @MeterID,
     @ActualQuantity,
     GETUTCDATE(),
     @EcolabWasherId
      END  

	  END
        SET  @CurrentStepComportmentNO=@CurrentStepComportmentNO+1;
   
  END;
 END;
GO

 IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlTunnelWasherProdData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlTunnelWasherProdData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [TCD].[ProcessMyControlTunnelWasherProdData](
	@ControllerID   INT,
	@xmlTags        XML,
	@PLCPointer     INT,
	@ReadPointer    INT,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @BatchID                   INT,
			  @WasherID                  INT,
			  @EcolabWasherId            INT,
			  @CurrencyCode              VARCHAR(50),
			  @MachineInternalId         INT,
			  @WasherGroupID             INT,
			  @PlantWasherNumber         INT,
			  @ProgramNumber             INT,
			  @Load                      DECIMAL(10, 2),
			  @NominalLoad               DECIMAL(10, 2),
			  @CustomerNumber            INT,
			  @PHStatus                  INT,
			  @PHValue                   INT,
			  @LFStatus                  INT,
			  @LFValue                   INT,
			  @BatchNumber               INT,
			  @TargetTurnTime            INT,
			  @PartitionOn               DATETIME2,
			  @BatchStartTime            DATETIME2,
			  @BatchEndTime              DATETIME2,
			  @ProgramID                 INT,
			  @NumberOfCompartments      INT,
			  @ProductId                 INT,
			  @CompartmentNum            INT,
			  @EquipmentType             INT,
			  @MinTempParamID            INT,
			  @MaxTempParamID            INT,
			  @TempStatusParamID         INT,
			  @PHValueParamID            INT,
			  @PHStatusParamID           INT,
			  @ConductivityValueParamID  INT,
			  @ConductivityStatusParamID INT,
			  @StdInjectionSteps         INT,
			  @StdWashSteps              INT,
			  @ActualInjSteps            INT,
			  @EcolabTextileCategoryId   INT,
			  @ChainTextileCategoryId    INT,
			  @FormulaSegmentId          INT,
			  @EcolabSaturationId        INT,
			  @PlantProgramId            INT,
			  @PreviousShiftId		    INT,
			  @CurrentShiftId		    INT,
			  @CurrentStepComportmentNO INT,
              @CounterNO                INT,
               @MeterID                 INT,
              @ActualQuantity          DECIMAL(10,6),
			  @BatchStepCount         INT
	    DECLARE @BatchShiftId INT;
	    DECLARE @ShiftStartDateTemp TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    DECLARE @TunnelXML XML;
	    SELECT @TunnelXML = T.c.query('.')
	    FROM @xmlTags.nodes('MyControlTunnel/TunnelData') T(c)
	    WHERE T.c.value('@CompartmentNumber', 'INT') = 0;

		
	    SELECT @MachineInternalID = T.c.value('@MachineNumber', 'int'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @BatchStartTime = T.c.value('@StartDateTime', 'DateTime'),
			 @BatchEndTime = T.c.value('@EndDateTime', 'DateTime'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@Nominalload', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'int'),
			 @PHStatus = T.c.value('@Phstatus', 'int'),
			 @PHValue = T.c.value('@Phvalue', 'INT'),
			 @LFStatus = T.c.value('@LFStatus', 'INT'),
			 @LFValue = T.c.value('@LFValue', 'INT')
	    FROM @xmlTags.nodes('MyControlTunnel/TunnelData') T(c);

		--Inserts Xml Data
		INSERT INTO tcd.PLCXMLData
	    (
			 PLC_Type,
			 XML_Data,
			 XML_Type,
			 Batch_Number,
			 Time_Stamp
	    )
	       VALUES
				(
					 3,
					CONVERT(nvarchar(max), @xmlTags),
					 2,
					ISNULL(@BatchNumber,0),			 
					 GETUTCDATE()
				);

	    SELECT @EcolabWasherID = Ws.EcolabWasherId,
			 @WasherGroupID = Wg.WasherGroupId,
			 @PlantWasherNumber = PlantWasherNumber,
			 @WasherID = ws.WasherId,
			 @CurrencyCode = P.CurrencyCode,
			 @NumberOfCompartments = Mst.NumberofComp
	    FROM TCD.Washer Ws
		    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.
		    GroupId
		    INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId
		    = Wg.WasherGroupTypeId
		    INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId =
		    Mst.ControllerId
		    INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.
		    EcoLabAccountNumber
	    WHERE Ctrl.ControllerID = @ControllerID
			AND Mst.MachineInternalId = @MachineInternalID
			AND Mst.IsTunnel = 1 AND Mst.IsDeleted=0;
	    SELECT @EcolabWasherID;
	    SELECT @ProgramID = ProgramId,
			 @TargetTurnTime = (3600 / (tps.TotalRunTime /
			 @NumberOfCompartments))
	    FROM TCD.TunnelProgramSetup AS tps
	    WHERE tps.WasherGroupId = @WasherGroupID
			AND tps.is_deleted = 0
			AND ProgramNumber = @ProgramNumber;
	    DELETE FROM @ShiftStartDateTemp;
	    IF(@BatchEndTime IS NOT NULL)
		   BEGIN
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchEndTime
		   END;
	    ELSE
		   BEGIN
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchStartTime
		   END;
	    SELECT @BatchShiftId = ShiftID,
			 @PartitionOn = ShiftStartdate
	    FROM @ShiftStartDateTemp;


	    --Start Getting InjectionCount,StepCount And ProductCount
	    SELECT @StdInjectionSteps = COUNT(tdpm.TunnelDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT tds.TunnelDosingSetupId) -
			 COUNT(tdpm.TunnelDosingSetupId)
	    FROM tcd.TunnelDosingProductMapping tdpm
		    RIGHT JOIN tcd.TunnelDosingSetup tds ON tdpm.
		    TunnelDosingSetupId = tds.TunnelDosingSetupId
	    WHERE tds.GroupId = @WasherGroupID
			AND tds.ProgramNumber = @ProgramNumber;
	    --End Getting InjectionCount,StepCount And ProductCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramID
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT @EcolabTextileCategoryId = pcp. EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp. ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    SELECT @BatchID = NULL;
	    SELECT @BatchID = BatchID
	    FROM TCD.BatchData BD
	    WHERE BD.ControllerBatchId = @BatchNumber
			AND BD.StartDate = @BatchStartTime
			AND BD.MachineId = @WasherID;
	    --AND BD.MachineInternalID = @MachineInternalID
	    IF(@BatchID IS NULL)
		   BEGIN
		   --Start Rollup for previous completed shift
	   IF(CAST(@BatchStartTime as date) < CAST(GETUTCDATE() as date))
	   BEGIN
		  SELECT TOP 1 @PreviousShiftId=ShiftId FROM TCD.BatchData WHERE MachineId=@WasherId ORDER BY StartDate DESC	   
		  SELECT Top 1 @CurrentShiftId = ShiftId from @ShiftStartDateTemp
		  IF(@CurrentShiftId != @PreviousShiftId)
		  BEGIN
			 EXEC TCD.ProductionShiftDataRollup @PreviousShiftId, @RedFlagShiftId OUTPUT
			 IF(@RedFlagShiftId IS NULL)
			 BEGIN
				SET @RedFlagShiftId = @PreviousShiftId
			 END
		  END
	   END
	   --End Rollup for previous completed shift
			  INSERT INTO TCD.BatchData
			  (ControllerBatchId,
			   EcolabWasherId,
			   GroupId,
			   MachineInternalId,
			   PlantWasherNumber,
			   StartDate,
			   EndDate,
			   ProgramNumber,
			   ProgramMasterId,
			   MachineId,
			   ActualWeight,
			   StandardWeight,
			   CurrencyCode,
			   ShiftId,
			   PartitionOn,
			   TargetTurnTime,
			   StdInjectionSteps,
			   StdWashSteps,
			   EcolabTextileCategoryId,
			   ChainTextileCategoryId,
			   FormulaSegmentId,
			   EcolabSaturationId,
			   PlantProgramId,
			   EndDateFormula
			  )
				    SELECT @BatchNumber,
						 @EcolabWasherID,
						 @WasherGroupID,
						 @MachineInternalID,
						 @PlantWasherNumber,
						 @BatchStartTime,
						 @BatchEndTime,
						 @ProgramNumber,
						 @ProgramID,
						 @WasherID,
						 @Load,
						 @NominalLoad,
						 @CurrencyCode,
						 @BatchShiftId,
						 @PartitionOn,
						 @TargetTurnTime,
						 @StdInjectionSteps,
						 @StdWashSteps,
						 @EcolabTextileCategoryId,
						 @ChainTextileCategoryId,
						 @FormulaSegmentId,
						 @EcolabSaturationId,
						 @PlantProgramId,
						 @BatchEndTime;
			  SELECT @BatchID = SCOPE_IDENTITY();
			  IF(@StdWashSteps > 0
				OR @StdWashSteps <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchID,
							@EcolabWasherId,
							38,
							@StdWashSteps,
							@PartitionOn;
			  EXEC TCD.UPDATEBatchWashStepForTunnel
				  @TunnelXML,
				  @WasherID,
				  @BatchID,
				  @BatchStartTime,
				  @PartitionOn,
				  @EcolabWasherId,
				  @NumberOfCompartments;
		   END;
	    IF(@BatchEndTime IS NOT NULL
		  AND @BatchEndTime != '01/01/1900')
		   BEGIN
			  UPDATE TCD.BatchData
			    SET
				   EndDate = @BatchEndTime,
				   ShiftId = @BatchShiftId,
				   PartitionOn = @PartitionOn,
				   EndDateFormula=@BatchEndTime
			  WHERE BATCHID = @BatchID;
		   END;
	    IF(@CustomerNumber IS NOT NULL)
		   BEGIN
			  IF NOT EXISTS
			  (
				 SELECT 1
				 FROM [TCD].[BatchCustomerData]
				 WHERE BatchID = @BatchID
			  )
				 BEGIN
					INSERT INTO [TCD].[BatchCustomerData]
					([BatchId],
					 CustomerID,
					 [Weight],
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @BatchID,
							    @CustomerNumber,
							    @Load,
							    @PartitionOn,
							    @EcolabWasherId;
				 END;
		   END;
	    CREATE TABLE #DosingDetails
	    (
		    Number          INT,
		    Quantity        DECIMAL(10, 6),
		    Point           INT,
		    IsMainEquioment INT
	    );
	    INSERT INTO #DosingDetails
	    (Number,
		Quantity,
		Point,
		IsMainEquioment
	    )
			 SELECT T.c.value('@Number', 'INT') AS Number, --PumpNumber
				   T.c.value('@Quantity', 'Decimal(10,6)') AS Quantity, --Dosing Quanity
				   T.c.value('@Point', 'INT') AS Point, --Dosing point
				   T.c.value('@IsMainEquioment', 'INT') AS
			 IsMainEquioment
			 FROM @xmlTags.nodes('MyControlTunnel/TunnelData/Dose') T(C)
	    ;
	
	    -- Fetching data from cursor
	    DECLARE @MYCURSOR CURSOR;
	    SET @MYCURSOR = CURSOR FAST_FORWARD
	    FOR SELECT Number,
				Quantity,
				Point,
				IsMainEquioment
		   FROM #DosingDetails;
	    DECLARE @Number          INT,
			  @Quantity        DECIMAL(10, 6),
			  @Point           INT,
			  @IsMainEquioment INT;
	    OPEN @MYCURSOR;
	    FETCH NEXT FROM @MYCURSOR INTO @Number,
								@Quantity,
								@Point,
								@IsMainEquioment;
	    WHILE @@FETCH_STATUS = 0
		   BEGIN
			  IF(@IsMainEquioment = 1)
				 BEGIN
					SET @EquipmentType = 2;
				 END;
			  ELSE
				 BEGIN
					SET @EquipmentType = 1;
				 END;
			  SELECT @ProductId = CES.ProductId,
				    @CompartmentNum = TCEVM.CompartmentNumber
			  FROM tcd.ControllerEquipmentSetup CES
				  INNER JOIN TCD.
				  TunnelCompartmentEquipmentValveMapping TCEVM ON CES.
				  ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
			  WHERE CES.ControllerId = @ControllerID
				   AND CES.ControllerEquipmentTypeId = @EquipmentType
				   AND --CES.IsActive=1 AND
				   --CES.WasherGroupNumber=@WasherGroupNum AND
				   TCEVM.DosingPointNumber = @Point
				   AND CES.ControllerEquipmentId = @Number;
				
			  --SELECT @EcolabWasherID
			  IF(@ProductId IS NOT NULL)
				 BEGIN
					INSERT INTO TCD.BatchProductData
					(BatchId,
					 StepCompartment,
					 ActualQuantity,
					 [TimeStamp],
					 PartitionOn,
					 EcolabWasherId,
					 ProductId
					)
						  SELECT @BatchID,
							    @CompartmentNum,
							    @Quantity,
							    @BatchEndTime,
							    @PartitionOn,
							    @EcolabWasherID,
							    @ProductId;
				 END;
			  FETCH NEXT FROM @MYCURSOR INTO @Number,
									   @Quantity,
									   @Point,
									   @IsMainEquioment;
		   END;
	    CLOSE @MYCURSOR;
	    DEALLOCATE @MYCURSOR;
	    DROP TABLE #DosingDetails;
	    SELECT @ActualInjSteps = COUNT(DISTINCT StepCompartment)
	    FROM TCD.BatchProductData
	    WHERE BatchId = @BatchID;
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.BatchParameters
		   WHERE ParameterId = 37
			    AND batchid = @BatchID
			    AND @ActualInjSteps > 0
	    )
		   BEGIN
			  IF(@ActualInjSteps > 0
				OR @ActualInjSteps <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchId,
							@EcolabWasherId,
							37,
							@ActualInjSteps,
							@PartitionOn;
		   END;
	    ELSE
		   BEGIN
			  UPDATE TCD.BatchParameters
			    SET
				   ParameterValue = @ActualInjSteps
			  WHERE ParameterId = 37
				   AND batchid = @BatchID;
		   END;
	    SELECT @MinTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Mimum Temperature';
	    SELECT @MaxTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Maximum Temperature';
	    SELECT @TempStatusParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Temperature Status';
	    SELECT @PHValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH';
	    SELECT @PHStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH Status';
	    SELECT @ConductivityValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Conductivity';
	    SELECT @ConductivityStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'LF Status';
	    IF(@PHValue IS NOT NULL)
		   BEGIN
			  --pH Value
			  IF(@PHValue <> 0
				OR @PHValue <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @PHValueParamID,
					   @PHValue,
					   @PartitionOn
				 );

			  --pH Status
			  IF(@PHStatus <> 0
				OR @PHStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @PHStatusParamID,
					   @PHStatus,
					   @PartitionOn
				 );
		   END;
	    IF(@LFValue IS NOT NULL)
		   BEGIN
			  --Conductivity Value
			  IF(@LFValue <> 0
				OR @LFValue <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @ConductivityValueParamID,
					   @LFValue,
					   @PartitionOn
				 );

			  --Conductivity Status
			  IF(@LFStatus <> 0
				OR @LFStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @ConductivityStatusParamID,
					   @LFStatus,
					   @PartitionOn
				 );
		   END;
	    CREATE TABLE #TemperatureDetails
	    (
		    MinimumTemp DECIMAL(10, 2),
		    MaximumTemp DECIMAL(10, 2),
		    TempStatus  DECIMAL(10, 2)
	    );
	    INSERT INTO #TemperatureDetails
	    (MinimumTemp,
		MaximumTemp,
		TempStatus
	    )
			 SELECT T.c.value('@Minimum', 'Decimal(10,2)') AS
			 MinimumTemp,
				   T.c.value('@Maximum', 'Decimal(10,2)') AS
				   MaximumTemp,
				   T.c.value('@Status', 'Decimal(10,2)') AS TempStatus
			 FROM @xmlTags.nodes(
			 'MyControlTunnel/TunnelData/TemperatureData'
							) T(c);
	  
	    -- Fetching data from cursor
	    DECLARE @TEMPCURSOR CURSOR;
	    SET @TEMPCURSOR = CURSOR FAST_FORWARD
	    FOR SELECT MinimumTemp,
				MaximumTemp,
				TempStatus
		   FROM #TemperatureDetails;
	    DECLARE @MinimumTemp DECIMAL(10, 2),
			  @MaximumTemp DECIMAL(10, 2),
			  @TempStatus  DECIMAL(10, 2);
	    OPEN @TEMPCURSOR;
	    FETCH NEXT FROM @TEMPCURSOR INTO @MinimumTemp,
								  @MaximumTemp,
								  @TempStatus;
	    WHILE @@FETCH_STATUS = 0
		   BEGIN	
			  --Minimum Temperature
			  IF(@MinimumTemp <> 0
				OR @MinimumTemp <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @MinTempParamID,
					   @MinimumTemp,
					   @PartitionOn
				 );

			  --Maximum Temperature
			  IF(@MaximumTemp <> 0
				OR @MaximumTemp <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @MaxTempParamID,
					   @MaximumTemp,
					   @PartitionOn
				 );

			  --Temperature Status
			  IF(@TempStatus <> 0
				OR @TempStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @TempStatusParamID,
					   @TempStatus,
					   @PartitionOn
				 );
			  FETCH NEXT FROM @TEMPCURSOR INTO @MinimumTemp,
										@MaximumTemp,
										@TempStatus;
		   END;
	    CLOSE @TEMPCURSOR;
	    DEALLOCATE @TEMPCURSOR;
	    DROP TABLE #TemperatureDetails;
	    UPDATE TCD.BatchWashStepData
		 SET
			EndTime = DATEADD(ss,
						  (SELECT T.c.value('@Time', 'INT')
							 FROM @TunnelXML.nodes('TunnelData/CompartmentTime') T(c)
							 WHERE T.c.value('@CompartmentNo','INT') =
							 (
								SELECT
									  bwsd.StepCompartment
								FROM tcd.BatchWashStepData bwsd
								WHERE bwsd.BatchId = @BatchID
									 AND bwsd.EndTime IS NULL
							 )
						  ),
						  (
							 SELECT
								   bwsd.StartTime
							 FROM tcd.BatchWashStepData bwsd
							 WHERE bwsd.BatchId = @BatchID
								  AND bwsd.EndTime IS NULL
						  ))
	    WHERE
			BatchId = @BatchID
			AND EndTime IS NULL;
   
   --Start water consumption per batch


    CREATE TABLE #WaterConsumptionData
     (
      Number          INT,
      Quantity        DECIMAL(10,6),
     );
     INSERT INTO #WaterConsumptionData
     (Number,
  Quantity
     )
    SELECT T.c.value('@Counter', 'INT') AS Number, --PumpNumber
       T.c.value('@Value', 'DECIMAL(10,6)') AS Quantity --Water Quanity
    FROM @xmlTags.nodes('MyControlTunnel/TunnelData/WaterConsumption') T(C);

  
  SET @CurrentStepComportmentNO=1;

  WHILE(@CurrentStepComportmentNO<=22)
  BEGIN
  
   SELECT @MeterID=MeterId,@CounterNO=mt.CounterNum
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@CurrentStepComportmentNO

    SELECT @ActualQuantity=wc.Quantity
  FROM #WaterConsumptionData wc where wc.Number=@CounterNo
  SELECT @BatchStepCount=COUNT(1) FROM TCD.BatchStepWaterUsageData WHERE BatchId=@BatchID  AND StepCompartment =@CurrentStepComportmentNO AND ActualQuantity=@ActualQuantity 
  IF (@BatchStepCount=0)
  BEGIN
  IF(ISNULL(@BatchID,0)>0  AND ISNULL(@MeterID,0)>0 AND ISNULL(@ActualQuantity,0)>0)
  BEGIN

   INSERT INTO TCD.BatchStepWaterUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
      EcolabWasherId
     )
     SELECT
     @BatchID,
     @CurrentStepComportmentNO,
     @ActualQuantity,
     @PartitionOn,
     @EcolabWasherId
      END 
	  END 
      SET  @CurrentStepComportmentNO=@CurrentStepComportmentNO+1;  
  END;
 END;
GO








----------------------------------------------End Water consumption per batch changes------------------------------------------------


IF  EXISTS (SELECT * FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[TCD].[ProcessModuleTags]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessModuleTags]
END
GO

CREATE PROCEDURE [TCD].[ProcessModuleTags]
(	
	@ModuleId INT,
	@ModuleTypeId INT,	
	@Reading DECIMAL(18,4),
	@TimeStamp DATETIME,
	@RollOverPoint INT
)

AS
SET NOCOUNT ON
BEGIN
		BEGIN
		
		
		 IF(@ModuleTypeId = 3)
		  BEGIN
		  IF NOT EXISTS(SELECT * FROM TCD.[SensorReading] WHERE SensorId=@ModuleId AND [TimeStamp]=@TimeStamp)
			BEGIN
				INSERT INTO [TCD].[SensorReading](
											  SensorId,
											  [Reading],
											  [TimeStamp]
 										   )
				VALUES
					(	@ModuleId,
						@Reading,
						@TimeStamp					
					)
			END			
		  END
		 ELSE
		  BEGIN
			DECLARE @MaxReading decimal(18,4),
				    @UsageReading decimal(18,4)
				    
			SELECT	@MaxReading  =  max(Reading) FROM TCD.ModuleReading where TimeStamp 
									in (select max(timestamp) from tcd.modulereading 
									where ModuleId = @ModuleId AND ModuleTypeId = @ModuleTypeId)
			IF(@MaxReading = 0.0000 OR @MaxReading IS NULL)
			BEGIN
			    SELECT @UsageReading = 0.0000
			END						
			ELSE IF(@Reading < @MaxReading)
			BEGIN
				SELECT @UsageReading = ((CAST(@RollOverPoint as decimal(18,4)) + @Reading)- @MaxReading)
			END
			ELSE
			BEGIN
				SELECT @UsageReading = (@Reading - @MaxReading)
			END									
			IF NOT EXISTS(SELECT * FROM TCD.[ModuleReading] WHERE [ModuleId]=@ModuleId AND [ModuleTypeId] = @ModuleTypeId AND [TimeStamp]=@TimeStamp)
			BEGIN
				INSERT INTO [TCD].[ModuleReading](
										   [ModuleId],
										   [ModuleTypeId],
										   [Reading],
										   [TimeStamp],
										   [Usage],
										   [PartitionOn]
										   )
				 VALUES
					(	@ModuleId,
						@ModuleTypeId,
						@Reading,
						@TimeStamp,
						@UsageReading,
						@TimeStamp
					)
			END			
		  END
			
		END		  		   
END
GO

IF  EXISTS (SELECT * FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[TCD].[ProcessNowTags]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessNowTags]
END
GO

CREATE PROCEDURE [TCD].[ProcessNowTags]
(	
	@ControllerId INT,	
	@xmlTags XML
)

AS
SET NOCOUNT ON
BEGIN
		DECLARE @BatchID INT,
				@AlarmCode INT,				
				@GroupId INT,		
				@Valve INT,
				@ProgramId INT,
				@MachineNumber INT,
				@InjectionNumber INT,
				@WasherId INT,
				@MachineId INT,
				@ECOLABAccountNumber nvarchar(25),
				@AlarmDate DATETIME2,
				@AlarmGroupMasterId INT

						
		IF EXISTS (SELECT  * FROM TEMPDB.DBO.SYSOBJECTS o where o.xtype in ('U') AND o.id = OBJECT_ID(N'tempdb..#XmlTagsTable'))
			BEGIN
					DROP TABLE #XmlTagsTable
			END


		CREATE TABLE  #XmlTagsTable (	TagId INT, 
										TagValue INT, 
										ReceivedTime DATETIME2,
										TagType NVARCHAR(50)
									)

	
		INSERT INTO #XmlTagsTable	(
										TagId,
										TagValue,
										ReceivedTime,
										TagType
									)			
		
		SELECT 		
					T.c.value('@TagId', 'INT') as TagId,
					T.c.value('@Value', 'INT')	TagValue,
					T.c.value('@TimeStamp', 'varchar(100)') DateTimeStamp,
					T.c.value('@TagType', 'varchar(50)') TagType
		FROM		@xmlTags.nodes('Tags/Tag') T(c)
		WHERE	
					T.c.value('@TagId', 'varchar(100)')  IS NOT NULL
				
			
		SELECT	@AlarmCode					=		TagValue,		
				@AlarmDate					=		ReceivedTime
		FROM	#XmlTagsTable 
		WHERE	TagType						=		'NowMessage'			
					
		SELECT @Valve						=		TagValue	    FROM #XmlTagsTable WHERE TagType='NowValve'

		SELECT @ProgramId					=		TagValue		FROM #XmlTagsTable WHERE TagType='NowFormula'	
		
		SELECT @MachineNumber				=		TagValue		FROM #XmlTagsTable WHERE TagType='NowWasher'	
		
		SELECT @WasherId = WasherID, @GroupId = GroupId, @MachineId = WasherId FROM TCD.MachineSetup WHERE MachineInternalId = @MachineNumber and ControllerId = @ControllerId
		
		SELECT @BatchID = BatchId FROM TCD.BatchData WHERE MachineId = @WasherId and EndDate IS NULL ORDER BY StartDate DESC
				
		SELECT @InjectionNumber = MAX(ParameterValue) FROM TCD.WasherReading where ParameterId = 10 --WHERE MachineInternalId = @MachineNumber
		
		SELECT @ECOLABAccountNumber = EcolabAccountNumber FROM TCD.Plant 

																					
		IF(@AlarmCode = 0)
		  BEGIN
			UPDATE TCD.AlarmData SET IsActive = 0, EndDate = getutcdate() WHERE controllerID = @controllerID
		  END
		
		 IF(@AlarmCode is NOT NULL AND @AlarmCode  <> 0)
    
		  BEGIN

			SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.ConduitController CC 
			INNER JOIN TCD.ControllerModelControllerTypeMapping CMCTM ON CMCTM.ControllerModelId = CC.ControllerModelId AND CMCTM.ControllerTypeId = CC.ControllerTypeId
			INNER JOIN TCD.AlarmGroupMsterVsControllerModelType AGMVCMT ON CMCTM.Id = AGMVCMT.ControllerModelTypeId
			INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
			WHERE AGMVCMT.AlarmCode = @AlarmCode AND CC.ControllerId = @ControllerId

			INSERT INTO [TCD].[AlarmData] 
			(EcoalabAccountNumber,
			AlarmCode,
			BatchId,
			controllerID,
			StartDate,
			GroupId,
			MachineInternalId,
			Valve,
			ProgramId,			
			InjectionNumber,
			IsActive,
			MachineId,
			AlarmGroupMasterId,
			PartitionOn)
		    SELECT
			    @ECOLABAccountNumber,
			    @AlarmCode,
			    @BatchID,
			    @ControllerId,
			    @AlarmDate,
			    @GroupId,
			    @MachineNumber,
			    @Valve,
			    @ProgramId,
			    @InjectionNumber,
			    1,
			    @MachineId,
				@AlarmGroupMasterId,
				@AlarmDate
		  END	
		  	   
	END

	GO

	IF  EXISTS (SELECT * FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[TCD].[ProcessConventionalWasherData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessConventionalWasherData]
END
GO

CREATE PROCEDURE [TCD].[ProcessConventionalWasherData]
	(	
	@WasherId INT,	
	@xmlTags XML,
	@RedFlagShiftId INT OUTPUT
)

AS
BEGIN
  DECLARE @BatchID        INT,
    @EcolabWasherId       INT,        
    @CurrencyCode       VARCHAR(50),  
    @MachineInternalId      INT,
    @GroupId        INT,  
    @Prveformula       INT,
    @Quantity        INT,
    @MaxWashertGroupCapacity    INT,

    @ProgramMasterId      INT,
    @NominalLoad       DECIMAL(10,2),
    @MaxLoad        DECIMAL(10,2),
    @StandardWeight       DECIMAL(10,2) ,     

    @CurrentFormula       INT,  
    @CurrentFormulaDate      DATETIME2,
    @FormulaIsModified      BIT,

    @CurrentInjection      INT,
    @CurrentInjectionDate     DATETIME2,
    @InjectionIsModified     BIT,

    @OperationalCount      INT,
    @OperationalIsModified     BIT, 
				
    @CurrentHoldSignal      INT,
    @CurrentHoldSignalDate     DATETIME2,
    @HoldSignalIsModified     BIT,  
													
    @EndofFormula       INT, 
    @EndofFormulaDate      DATETIME2,
				
    @AutoWeightEntryActive     BIT,
    @AutoWeightEntryWeight     DECIMAL(10,2),                                                                                                                              
    @ControllerId       INT,
    @CurrentHoldSignalValue     INT ,
				
    @MeterPlcAddress      INT,
    @MeterPlcAddressIsModified    INT,
    @BatchGroupId       INT,
    @BatchFormula       INT,    
    @HoldTime        INT,
    @CteTempBatchInjections     INT,
    @CteTempWaherReadingInjections   INT,
    @BatchStandardWaterUsage    INT,
    @BatchActualWaterUsage     INT,
    @BatchWaterUsagePrice     Decimal(10,2),
    @BatchUtilityPrice      Decimal(10,2),
    @BatchWaterType       INT,
    @PrevGroupId       INT,
    @WasherMeterExists      BIT,
    @ExtraTime        INT,
    @TargetTurnTime       INT,
    @RatioDosingEnabled      BIT,
	@EcolabAccountNumber NVARCHAR(25) = NULL,
	@PreviousFormulaDate      DATETIME2,
 @PreviousInjectionStep INT,
	@PreviousInjectionStartDate DATETIME2,
	@CurrentInjectionStep INT,
	@WashStepBatchId INT,
	@PrevFormulaExtraTime INT      ,
	@AlarmGroupMasterId INT,
	@StdWashSteps INT,
    @StdInjectionSteps INT,
	@EcolabTextileCategoryId INT,
	@ChainTextileCategoryId INT,
	@FormulaSegmentId INT,
	@EcolabSaturationId INT,
 
 @PreviousShiftId INT,
 @CurrentShiftId INT,                                                                                                              
 @PlantProgramId INT,
	@ETechLastDroppedAt  DATETIME2			                                                                                                    							

  SET @RedFlagShiftId = NULL
						
		IF EXISTS (SELECT  * FROM [TEMPDB].[DBO].[SYSOBJECTS] o where o.xtype in ('U') AND o.id = OBJECT_ID(N'tempdb..#XmlTagsTable'))
			BEGIN
					DROP TABLE #XmlTagsTable
			END


  CREATE TABLE  #XmlTagsTable ( TagId INT, 
										TagValue NVARCHAR(100), 
										ReceivedTime DATETIME2,
										TagType NVARCHAR(50),
										IsModified BIT,
										ETechLastDropped VARCHAR(100)
									)

	
  INSERT INTO #XmlTagsTable (
										TagId,
										TagValue,
										ReceivedTime,
										TagType,
										IsModified,
										ETechLastDropped
									)			
		
		SELECT 		
					T.c.value('@TagId', 'INT') as TagId,
     T.c.value('@Value', 'NVARCHAR(100)') TagValue,
					T.c.value('@TimeStamp', 'VARCHAR(100)') DateTimeStamp,
					T.c.value('@TagType', 'VARCHAR(50)') TagType,
					T.c.value('@IsModified', 'BIT') TagType,
					T.c.value('@ETechLastDroppedAt', 'VARCHAR(100)') ETechLastDropped
  FROM  @xmlTags.nodes('Tags/Tag') T(c)
		WHERE	
					T.c.value('@TagId', 'varchar(100)')  IS NOT NULL
	
  SELECT @CurrentFormula     =  TagValue,  
    @CurrentFormulaDate    =  ReceivedTime,
    @FormulaIsModified     =  IsModified
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_FRM'   
					
  SELECT @CurrentInjection    =  TagValue,
    @CurrentInjectionDate   =  ReceivedTime,
    @InjectionIsModified   =  IsModified   
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_INJ'

  SELECT @OperationalCount    =  TagValue,
    @OperationalIsModified   =  IsModified  
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_OPC'  
			
  SELECT @EndofFormula     =  TagValue,
    @EndofFormulaDate    =  ReceivedTime  
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_EOF' 
		
  SELECT @AutoWeightEntryActive   =  TagValue     
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_AWEA'                 

  SELECT @CurrentHoldSignal    =  TagValue, 
    @HoldSignalIsModified   =  IsModified,  
    @CurrentHoldSignalDate   =  ReceivedTime 
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_HOLDL'

  SELECT @AutoWeightEntryWeight   =  TagValue,
   @ETechLastDroppedAt    =  CONVERT(datetime,ETechLastDropped)        
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_AWEW'

  SELECT @MeterPlcAddress    =  TagValue,
    @MeterPlcAddressIsModified  =       IsModified       
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_MPLC'
		
  SELECT @RatioDosingEnabled    =  TagValue      
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_RATA'
		
		SELECT * FROM #XmlTagsTable
		
  SELECT @ExtraTime      =  0

  SELECT TOP 1 @BatchID=BatchId, @Prveformula=ProgramNumber,@PrevGroupId=GroupId, @PreviousFormulaDate=StartDate FROM TCD.BatchData WHERE MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC

  IF(@PreviousFormulaDate is NOT NULL)
  BEGIN
	IF(@CurrentFormulaDate < @PreviousFormulaDate)
	BEGIN
		return
	END
  END

  IF(@CurrentFormula != @EndofFormula AND
     @CurrentFormula = @Prveformula AND 
	 @CurrentInjection = 0 AND
	 @OperationalCount = 0 AND
	 @CurrentFormulaDate <= @PreviousFormulaDate AND
	 @CurrentInjectionDate > @PreviousFormulaDate)
	BEGIN
	--Here means, If the same formula is received without EOF then the timestamp of the formula
	--will be still the old timestamp because value is not changed.
	--In this case assign injection=0 timestamp to formula timestamp
	 SELECT @CurrentFormulaDate = @CurrentInjectionDate	
	END

		DECLARE @ShiftStartDate table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
  INSERT INTO @ShiftStartDate(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate

		SELECT DISTINCT 
     @EcolabWasherId    =  Ws.EcolabWasherId,
     @StandardWeight    =  Wps.NominalLoad,
     @CurrencyCode    =  Pl.CurrencyCode,
     @ControllerId    =  Ctrl.ControllerId,
     @TargetTurnTime    =  Ws.TargetTurnTime * 60     
		FROM 
					TCD.Washer Ws		
		INNER JOIN 
					TCD.MachineSetup Mst ON
     Mst.WasherId    =  Ws.WasherId
		INNER JOIN 
					TCD.WasherGroup Wg ON 
     Wg.WasherGroupId   =  Mst.GroupId    
		INNER JOIN 
					TCD.WasherProgramSetup Wps ON 
     Wps.WasherGroupId   =  Wg.WasherGroupId
		LEFT JOIN 
					TCD.WasherDosingSetup Wds ON 
     Wds.WasherProgramSetupId =  Wps.WasherProgramSetupId
		LEFT JOIN 
					TCD.WasherDosingProductMapping Wdpm ON 
     Wdpm.WasherDosingSetupId =  Wds.WasherDosingSetupId
		INNER JOIN 
					TCD.Plant Pl ON 
     Pl.EcolabAccountNumber  =  Ws.EcoLabAccountNumber
		INNER JOIN 
				TCD.ConduitController Ctrl 
    ON Ctrl.ControllerId   =  Mst.ControllerId 
		WHERE Ws.WasherId= @WasherId

		SELECT DISTINCT 
					@MachineInternalId=Mst.MachineInternalId,
					@GroupId=Mst.GroupId					
		FROM TCD.Washer Ws
						INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
						INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
						INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
			WHERE Ws.WasherId=@WasherId 	

			SELECT DISTINCT 					
					@ProgramMasterId=Wps.ProgramId,
					@NominalLoad=Wps.NominalLoad, --Wps.NominalLoad/CONVERT(decimal(10,2), 100) old code
					@MaxLoad =Ws.MaxLoad,
					@ExtraTime =Wps.ExtraTime
		FROM TCD.Washer Ws
						INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
						INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
						INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
						INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
			WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@CurrentFormula and Wps.Is_Deleted=0

		if(@ExtraTime IS NULL)
		BEGIN
			SELECT @ExtraTime      =  0
		END

		SELECT  @MaxWashertGroupCapacity=Max(ws.MaxLoad)
		FROM TCD.Washer WS
			INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
			INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId		
		WHERE Mst.GroupId=@GroupId

		SELECT @WasherMeterExists = M.MachineCompartment FROM Tcd.MachineSetup Ms
		INNER JOIN Tcd.Meter M ON M.GroupId= Ms.GroupId AND  M.MachineCompartment=Ms.MachineInternalId
		WHERE Ms.WasherId=@WasherId

		if(@AutoWeightEntryActive IS NULL)
		BEGIN
			SELECT @AutoWeightEntryActive = 0
		END

		SELECT @StandardWeight=(@NominalLoad * @MaxWashertGroupCapacity) /CONVERT(decimal(10,2), 100)			
		select @AutoWeightEntryActive,@StandardWeight
		SELECT @AutoWeightEntryWeight=Case @AutoWeightEntryActive WHEN 0 THEN @StandardWeight ELSE  @AutoWeightEntryWeight END 	
		
		SELECT @CurrentHoldSignalValue=Id  FROM TCD.ConduitParameters where Name='HoldSignal'
		
		 SELECT  * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC
		IF(@HoldSignalIsModified !=0)	 
		BEGIN
		IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp =@CurrentHoldSignalDate)
			BEGIN
				INSERT INTO TCD.WasherReading(
									WasherId,
									ParameterId,
									ParameterValue,
									DateTimeStamp,
									PartitionOn,
									EcolabWasherId)
    SELECT    @WasherId,
									@CurrentHoldSignalValue,
									@CurrentHoldSignal,
									@CurrentHoldSignalDate,
									(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
									@EcolabWasherId
			END			
		END
		IF(@FormulaIsModified =1  OR @InjectionIsModified = 1 OR @OperationalIsModified = 1)
		BEGIN
			SELECT 'IsModified',@FormulaIsModified AS FormulaIsModified, 
								@InjectionIsModified AS InjectionIsModified,
								@OperationalIsModified AS OperationalIsModified
			IF(@CurrentFormula != 0)
			BEGIN
							DECLARE @BatchShiftId int,@BatchShiftStartDate datetime
							
							SELECT @BatchShiftStartDate = bd.StartDate FROM TCD.BatchData bd WHERE bd.BatchId = @BatchId

							IF(@BatchShiftStartDate > (SELECT TOP 1 [@ShiftStartDate].ShiftStartdate FROM @ShiftStartDate ORDER BY [@ShiftStartDate].ShiftStartdate ASC)
							AND DATEADD(second,@ExtraTime,@CurrentFormulaDate) > (SELECT TOP 1 [@ShiftStartDate].ShiftStartdate FROM @ShiftStartDate ORDER BY [@ShiftStartDate].ShiftStartdate DESC)
							)
							BEGIN 
								 
         SELECT TOP 1  @BatchShiftId = ssdt.ShiftId FROM @ShiftStartDate ssdt ORDER BY ssdt.ShiftStartdate DESC
							END
							ELSE
							BEGIN
        SELECT TOP 1  @BatchShiftId = ssdt.ShiftId FROM @ShiftStartDate ssdt ORDER BY ssdt.ShiftStartdate ASC
							END
							

		SELECT DISTINCT      
			@PrevFormulaExtraTime =Wps.ExtraTime
			FROM TCD.Washer Ws
				INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
				INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
				INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
				INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
				WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@Prveformula and Wps.Is_Deleted=0

		IF(@PrevFormulaExtraTime IS NULL)
		BEGIN
			SELECT @PrevFormulaExtraTime      =  0
		END

					IF(@CurrentFormula = @EndofFormula)
					BEGIN			
					SELECT * FROM #XmlTagsTable
						IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData 
								   WHERE 
											BatchId=@BatchId AND 
											MachineId=@WasherId AND 
											EndDate IS NULL 
											ORDER BY StartDate DESC  )
							BEGIN
																																							
								UPDATE TCD.BatchData 
         SET EndDate = DATEADD(second,@PrevFormulaExtraTime,@CurrentFormulaDate),EndDateFormula = @CurrentFormulaDate,ShiftId = @BatchShiftId 
       WHERE  BatchId = @BatchId AND MachineId=@WasherId   
	   
    --DECLARE @ShiftMapping1 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
    --INSERT INTO @ShiftMapping1(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate,1, @RedFlagShiftId OUTPUT

	   SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
						IF(@PreviousInjectionStep IS NOT NULL)
						BEGIN
							UPDATE TCD.BatchWashStepData SET EndTime=DATEADD(second,@ExtraTime,@CurrentFormulaDate) WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate
						END
	                                                                  
							END 
					END 
					ELSE IF((@CurrentFormula != @Prveformula) AND (@BatchID IS NOT NULL))
					BEGIN		
					IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC  )
								BEGIN																										
									UPDATE TCD.BatchData
          SET EndDate = @CurrentFormulaDate,EndDateFormula = @CurrentFormulaDate,ShiftId = @BatchShiftId 
         WHERE  BatchId = @BatchId AND MachineId=@WasherId  
		 
		   INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,19,1,(SELECT Top 1 ShiftStartdate from @ShiftStartDate) 
		   
   --  DECLARE @ShiftMapping2 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
   --INSERT INTO @ShiftMapping2(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate,1, @RedFlagShiftId OUTPUT
			 
			 SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
					IF(@PreviousInjectionStep IS NOT NULL)
					BEGIN
						UPDATE TCD.BatchWashStepData SET EndTime=@CurrentFormulaDate WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate
					END
			    
								END 
						END
					ELSE IF((@CurrentInjection = 0) AND(@OperationalCount = 0) AND (@CurrentFormulaDate != @PreviousFormulaDate))
					BEGIN		
					IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC)
								BEGIN																											
									UPDATE TCD.BatchData
          SET EndDate = @CurrentInjectionDate,ShiftId = @BatchShiftId,EndDateFormula = @CurrentInjectionDate
         WHERE  BatchId = @BatchId AND MachineId=@WasherId  
		 
		  INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,19,1,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)

   -- DECLARE @ShiftMapping3 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
   --INSERT INTO @ShiftMapping3(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentInjectionDate,1, @RedFlagShiftId OUTPUT
		    
			SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
					IF(@PreviousInjectionStep IS NOT NULL)
					BEGIN
						UPDATE TCD.BatchWashStepData SET EndTime=@CurrentInjectionDate WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate
					END

								END 
						END
			
				-- Hold Time
					IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
						BEGIN

						
						SELECT   @HoldTime=SUM(Wr.ParameterValue) FROM TCD. BatchData Bd
						INNER JOIN TCD.WasherReading Wr ON Wr.WasherId=Bd.MachineId
						WHERE Bd.BatchId=@BatchId  AND Wr.DateTimeStamp BETWEEN Bd.StartDate AND  Bd.EndDate and   Wr.ParameterId=9 -- Hold Signal value

						INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,17,@HoldTime,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)


					END
					
					-- CapturingMeter Plc Address EndRedaing 
					IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
						BEGIN
						IF(@WasherMeterExists IS NOT NULL AND @MeterPlcAddress > 0)
						BEGIN
							IF(@MeterPlcAddressIsModified !=0)	 
							BEGIN
							IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp =@CurrentFormulaDate)
							BEGIN
								INSERT INTO TCD.WasherReading(
									WasherId,
									ParameterId,
									ParameterValue,
									DateTimeStamp,
									PartitionOn,
									EcolabWasherId)
								SELECT	
									@WasherId,
									14, --MeterPlcAddress for EndSReading
									@MeterPlcAddress,
									@CurrentFormulaDate,
									(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
									@EcolabWasherId
							END

						END
						END
					END
									
					--Start Good or Bad Injection in BatchDataTable
					IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
						BEGIN
								;WITH CteTempWaherReadingInjections  (	
								InjectionsCount,BatchId,WasherId,ProgramNumber,Injectons
							) AS  
							(
								SELECT DISTINCT Wr.ParameterValue,
												BD.BatchId,
												Wr.WasherId,
												Bd.ProgramNumber,
												Wr.ParameterValue FROM TCD. BatchData Bd
								INNER JOIN 
          TCD.WasherReading Wr ON Wr.WasherId   =  Bd.MachineId 
								WHERE    
              Wr.ParameterId    =  10    AND 
              Wr.ParameterValue   <>  0    AND 
              Bd.BatchId     =  @BatchID AND WR.DateTimeStamp BETWEEN BD.StartDate AND BD.EndDate) 
								SELECT @CteTempWaherReadingInjections=COUNT(CTE1.InjectionsCount)
								FROM CteTempWaherReadingInjections CTE1 
								INNER JOIN TCD.BatchData Bd ON Bd.BatchId=CTE1.BatchId
								WHERE Bd.BatchId=@BatchId

								;WITH CteTempBatchInjections (	
								InjectionsCount,BatchId,WasherId,ProgramNumber,Injectons
							) AS  
							(
								SELECT  DISTINCT Wdpm.InjectionNumber,
												Bd.BatchId,
												Wps.ProgramNumber,
												Ws.WasherId,Wdpm.
												InjectionNumber
									FROM TCD.Washer WS
										INNER JOIN 
													TCD.MachineSetup Mst ON 
             Mst.WasherId     =  WS.WasherId
										INNER JOIN 
													TCD.WasherGroup Wg ON 
             Wg.WasherGroupId    =  Mst.GroupId       
										INNER JOIN 
													TCD.WasherProgramSetup Wps ON 
             Wps.WasherGroupId    =  Wg.WasherGroupId
										INNER JOIN 
													TCD.WasherDosingSetup Wds ON 
             Wds.WasherProgramSetupId  =  Wps.WasherProgramSetupId
										INNER JOIN 
													TCD.WasherDosingProductMapping Wdpm ON 
             Wdpm.WasherDosingSetupId  =  Wds.WasherDosingSetupID
										INNER JOIN 
													TCD.ProductdataMapping Pdm ON 
             Pdm.ProductId     =  Wdpm.ProductId
										INNER JOIN 
													TCD.BatchData Bd ON 
             Bd.MachineId     =  Ws.WasherId 
										INNER JOIN 
													TCD.WasherReading Wr ON 
             Wr.WasherId      =  Bd.MachineId
								WHERE 
								
             Wps.ProgramNumber    =  @Prveformula  AND 
             Bd.BatchId      =  @BatchID   AND 
             Ws.WasherId      =  @WasherId    )
								SELECT @CteTempBatchInjections=COUNT(CTE2.InjectionsCount)
								FROM CteTempBatchInjections CTE2 
								INNER JOIN TCD.BatchData Bd ON Bd.BatchId=CTE2.BatchId 
								WHERE Bd.BatchId=@BatchID


								Insert Tcd.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchID,@EcolabWasherId,18,
          CASE WHEN @CteTempBatchInjections = @CteTempWaherReadingInjections THEN 1
            WHEN @CteTempBatchInjections != @CteTempWaherReadingInjections THEN 3 END,
												(SELECT Top 1 ShiftStartdate from @ShiftStartDate)	
																											
				END
					--End Good or Bad Injection in BatchDataTable	
					IF(@OperationalCount = 0 AND @CurrentInjection = 0) AND (@CurrentFormula != @EndofFormula)
					BEGIN	
						IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchData WHERE MachineId=@WasherId AND StartDate =@CurrentFormulaDate)
						BEGIN					
       
	   --Start Rollup for previous completed shift
	   IF(CAST(@CurrentFormulaDate as date) < CAST(GETUTCDATE() as date))
	   BEGIN
		  SELECT TOP 1 @PreviousShiftId=ShiftId FROM TCD.BatchData WHERE MachineId=@WasherId ORDER BY StartDate DESC	   
		  SELECT Top 1 @CurrentShiftId = ShiftId from @ShiftStartDate
		  IF(@CurrentShiftId != @PreviousShiftId)
		  BEGIN
			 EXEC TCD.ProductionShiftDataRollup @PreviousShiftId, @RedFlagShiftId OUTPUT
			 IF(@RedFlagShiftId IS NULL)
			 BEGIN
				SET @RedFlagShiftId = @PreviousShiftId
			 END
		  END
	   END
	   --End Rollup for previous completed shift
       
							--Start Getting InjectionCount and StepCount
							SELECT 
							@StdInjectionSteps=count(DISTINCT wdpm.WasherDosingSetupId),
							@StdWashSteps= count(DISTINCT wds.WasherDosingSetupId)-count(DISTINCT wdpm.WasherDosingSetupId)
							FROM TCD.WasherDosingProductMapping wdpm
							RIGHT JOIN tcd.WasherDosingSetup wds on wdpm.WasherDosingSetupId=wds.WasherDosingSetupId
							WHERE wds.GroupId=@GroupId AND wds.ProgramNumber=@CurrentFormula
							--End Getting InjectionCount and StepCount
							--Start-----ProgramMasterID logic for PlantChainProgram
								SELECT 
								@PlantProgramId=pm.PlantProgramId,
								@EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
								@ChainTextileCategoryId = pm.ChainTextileId,
								@FormulaSegmentId = pm.FormulaSegmentId,
								@EcolabSaturationId = pm.EcolabSaturationId 
								FROM TCD.ProgramMaster pm WHERE pm.ProgramId=@ProgramMasterId AND pm.Is_Deleted=0
								IF(@PlantProgramId <> 0  AND @PlantProgramId IS NOT NULL)
									BEGIN
									   --Assign value from plantchainprogram table based on plantprogramId
									   SELECT
										   @EcolabTextileCategoryId = pcp.EcolabTextileCategoryId,
										   @ChainTextileCategoryId = pcp.ChainTextileCategoryId,
										   @FormulaSegmentId = pcp.FormulaSegmentId,
										   @EcolabSaturationId = pcp.EcolabSaturationId
										   FROM tcd.PlantChainProgram pcp
										   WHERE pcp.PlantProgramId=@PlantProgramId AND pcp.Is_Deleted=0
									END
							--End-----ProgramMasterID logic for PlantChainProgram

							INSERT INTO TCD.BatchData(
										ControllerBatchId ,
										EcolabWasherId,
										GroupId ,
										MachineInternalId,
										PlantWasherNumber,
										StartDate ,
										EndDate ,
										ProgramNumber,
										ProgramMasterId,
										MachineId,
										ActualWeight,
										StandardWeight,
										CurrencyCode,
										ShiftId,									
										PartitionOn,
										TargetTurnTime,
										StdInjectionSteps,
										StdWashSteps,
										EcolabTextileCategoryId,
										ChainTextileCategoryId,
										FormulaSegmentId,
										EcolabSaturationId,
										PlantProgramId,
										ETechlastDroppedTimeStamp										
										)


									SELECT DISTINCT 0
										,@EcolabWasherId
										,@GroupId
										,@MachineInternalId
										,Ws.PlantWasherNumber
										,@CurrentFormulaDate
										,NULL
										,@CurrentFormula
										,@ProgramMasterId
										,@WasherId
										,@AutoWeightEntryWeight
										,@StandardWeight 
										,@CurrencyCode
										,(SELECT Top 1 ShiftId from @ShiftStartDate)									
										,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
										,@TargetTurnTime
										,@StdInjectionSteps
										,@StdWashSteps
										,@EcolabTextileCategoryId
										,@ChainTextileCategoryId
										,@FormulaSegmentId
										,@EcolabSaturationId
										,@PlantProgramId											
										,@ETechLastDroppedAt 											

							FROM TCD.Washer Ws
										INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
										INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
										INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
							WHERE Ws.WasherId=@WasherId 
			
							SET @BatchID=SCOPE_IDENTITY()	
									
							INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,38,@StdWashSteps,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)

							--If the received formula is not configured in enVision then create an alarm 
							IF(@ProgramMasterId is NULL)
							BEGIN
							SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant;
							SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.AlarmGroupMsterVsControllerModelType AGMVCMT
							INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
							WHERE AGMVCMT.AlarmCode = 9000
								INSERT INTO [TCD].[AlarmData] 
								   (EcoalabAccountNumber,
								   AlarmCode,
								   BatchId,
								   controllerID,
								   StartDate,
								   GroupId,
								   MachineInternalId,
								   ProgramId,   
								   IsActive,
								   EndDate,
								   MachineId,
								   AlarmGroupMasterId,
								   PartitionOn)
									  SELECT
									   @ECOLABAccountNumber,
									   9000,
									   @BatchID,
									   @ControllerId,
									   @CurrentFormulaDate,
									   @GroupId,
									   @MachineInternalId,
									   @CurrentFormula,
									   0,
									   @CurrentFormulaDate,
									   @WasherId,
									   @AlarmGroupMasterId,
									   @CurrentFormulaDate
							END

									
									INSERT INTO TCD.BatchCustomerData
									(
									BatchId,
									CustomerId,
									Weight,
									PiecesCount,
									PartitionOn,
									EcolabWasherId
									)
								SELECT Bd.BatchId,  
								--SELECT @BatchID,
									Pc.ID,
									@AutoWeightEntryWeight,
									ROUND(COALESCE((@AutoWeightEntryWeight * Pm.Pieces) / NULLIF(Pm.Weight,0), 0),0),
									(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
									@EcolabWasherId
								
						
							FROM TCD.Washer WS
								INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
								INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId							
								INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
								INNER JOIN TCD.ProgramMaster Pm ON Pm.ProgramId=Wps.ProgramId
								INNER JOIN TCD.PlantCustomer Pc ON Pc.ID=Pm.CustomerId
								INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
							WHERE 
								Ws.WasherId=@WasherId AND 
								Wps.ProgramNumber=@CurrentFormula AND 
								Bd.BatchId=@BatchID  AND 
								Pm.CustomerId != -1 

							IF(@WasherMeterExists IS NOT NULL AND @MeterPlcAddress > 0)
							BEGIN								
								IF(@MeterPlcAddressIsModified !=0)	 
								BEGIN
										INSERT INTO TCD.WasherReading(
											WasherId,
											ParameterId,
											ParameterValue,
											DateTimeStamp,
											PartitionOn,
											EcolabWasherId)
										SELECT	
											@WasherId,
											13, --MeterPlcAddress for StartReading
											@MeterPlcAddress,
											@CurrentFormulaDate,
											(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
											@EcolabWasherId
								END
							END	
						END														
					END	 				
					IF(@BatchID IS NOT NULL)					
					BEGIN
					IF(@CurrentInjection <= 0)
						BEGIN
							SET @CurrentInjectionDate=@CurrentFormulaDate
						END	
						IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp =@CurrentInjectionDate)
						BEGIN						
						INSERT INTO TCD.WasherReading(
										WasherId,
										ParameterId,
										ParameterValue,
										DateTimeStamp,
										PartitionOn,
										EcolabWasherId)
      SELECT   @WasherId,
										CASE TagType 
										WHEN 'Tag_FRM' THEN  5  
										WHEN 'Tag_INJ' THEN  10 
										WHEN 'Tag_OPC' THEN  11 
										END,
										TagValue,										
										@CurrentInjectionDate,
										(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
										@EcolabWasherId
       FROM  #XmlTagsTable 
       WHERE  Tagtype in ('Tag_FRM','Tag_INJ','Tag_OPC')         
					END
					END
				IF(@CurrentInjection > 0)					
					BEGIN
						IF (@RatioDosingEnabled = 1)
							BEGIN
							IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurrentInjectionDate and batchid=@BatchID)
							BEGIN
								INSERT INTO TCD.BatchProductData(BatchId,StepCompartment,ActualQuantity,StandardQuantity,Price,TimeStamp,PartitionOn,EcolabWasherId,ProductId)
								SELECT Bd.BatchId	
								--SELECT @BatchID	
									,Wds.StepNumber
         ,(((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100)) * (@AutoWeightEntryWeight/@StandardWeight) AS ActualQuantity  
         ,(((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100)) * (@AutoWeightEntryWeight/@StandardWeight) AS StandardQuantity      
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * @MaxWashertGroupCapacity)/CONVERT(decimal(10,2), 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price         
									,@CurrentInjectionDate
									,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
									,@EcolabWasherId
									,Pdm.ProductID
								FROM TCD.Washer WS
									INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
									INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
									INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
									INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
									INNER JOIN TCD.WasherDosingSetup Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
									INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
									INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Wdpm.ProductId
									INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
								WHERE 
          Ws.WasherId=@WasherId     AND 
          Wps.ProgramNumber=@CurrentFormula  AND 
          Wdpm.InjectionNumber=@CurrentInjection AND
										Bd.BatchId=@BatchID AND
		  Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
							END
							END
						ELSE
							BEGIN
							IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurrentInjectionDate and batchid=@BatchID)
							BEGIN
								INSERT INTO TCD.BatchProductData(BatchId,StepCompartment,ActualQuantity,StandardQuantity,Price,TimeStamp,PartitionOn,EcolabWasherId,ProductId)
								SELECT Bd.BatchId		
								--SELECT @BatchID
									,Wds.StepNumber
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100) AS ActualQuantity  
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100) AS StandardQuantity      
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * @MaxWashertGroupCapacity)/CONVERT(decimal(10,2), 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price         
									,@CurrentInjectionDate
									,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
									,@EcolabWasherId
									,Pdm.ProductID
								FROM TCD.Washer WS
									INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
									INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
									INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
									INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
									INNER JOIN TCD.WasherDosingSetup Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
									INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
									INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Wdpm.ProductId
									INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
								WHERE 
          Ws.WasherId=@WasherId     AND 
          Wps.ProgramNumber=@CurrentFormula  AND 
          Wdpm.InjectionNumber=@CurrentInjection AND
										Bd.BatchId=@BatchID AND
		  Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
							END		
							END	
							
		--Populating BatchWashstepdata
						SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
						
						IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchWashStepData WHERE StartTime =@CurrentInjectionDate and batchid=@BatchID)
						BEGIN
									SELECT @CurrentInjectionStep=Wds.StepNumber,
										   @WashStepBatchId=Bd.BatchId
         								
									FROM TCD.Washer WS
										INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
										INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
										INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
										INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
										INNER JOIN TCD.WasherDosingSetup Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
										INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
										INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Wdpm.ProductId
										INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
									WHERE 
										Ws.WasherId=@WasherId     AND 
										Wps.ProgramNumber=@CurrentFormula  AND 
										Wdpm.InjectionNumber=@CurrentInjection AND
										Bd.BatchId=@BatchID AND
										Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0

									IF(@CurrentInjectionStep IS NOT NULL)
									BEGIN
										INSERT INTO TCD.BatchWashStepData(BatchId,StepCompartment,StartTime,PartitionOn,EcolabWasherId)
										VALUES (@WashStepBatchId,  @CurrentInjectionStep, @CurrentInjectionDate, (SELECT Top 1 ShiftStartdate from @ShiftStartDate), @EcolabWasherId)																
									
										UPDATE TCD.BatchWashStepData SET EndTime=@CurrentInjectionDate WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate									
									END

						END
						--End Populating BatchWashstepdata

						--Start Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
						IF NOT EXISTS(SELECT * FROM TCD.BatchParameters WHERE ParameterId =37 and batchid=@BatchID)
						BEGIN
							INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,37,1,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)							
						END
						ELSE
						BEGIN
							Update TCD.BatchParameters SET ParameterValue=@CurrentInjection WHERE ParameterId =37 and batchid=@BatchID
						END
	  					--End Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record

											
					END

					UPDATE TCD.ConduitController
      SET LastConnectedTime  = GETUTCDATE()
      WHERE ControllerId   = @ControllerId
			END
		END
	END


	GO

	IF  EXISTS (SELECT * FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[TCD].[ProcessTunnelWasherData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessTunnelWasherData]
END
GO

CREATE PROCEDURE [TCD].[ProcessTunnelWasherData]
	(	
	@WasherId INT,	
	@xmlTags XML,
	@RedFlagShiftId INT OUTPUT
)
AS
BEGIN
		DECLARE @BatchID						INT,
				@EcolabWasherId					INT,								
				@CurrencyCode					VARCHAR(50),		
				@MachineInternalId				INT ,
				@GroupId						INT,		
				@Prveformula					INT,
				@Quantity						INT,
				@MaxWashertGroupCapacity		INT,
				@PrevBatchId					INT,
				@PrevLoadId						INT,
				@ExistedLoadId					INT,
				@NumberOfCompartments			INT,

				@ProgramMasterId				INT,
				@NominalLoad					Decimal(10,2),
				@MaxLoad						Decimal(10,2),
				@StandardWeight					Decimal(10,2) , 				
				@PlantWasherNumber				INT,
											
				@CurrentDay						DATE=CAST(GETUTCDATE() as date),
				@TempTunnelTimeStamp			DATETIME2,

				@ControllerId					INT ,
				@CurrentHoldSignal				INT,
				
				@TotalRunTime					INT,
				@BatchGroupId					INT,
				@BatchFormula					INT,
				@BatchStartDate					DATETIME2,
				@BatchEndDate					DATETIME2,
				@HoldTime						INT,
				@CteTempBatchTunnelWashSteps	INT,
				@CteTemTunnelWashSetps			INT,
				@PrevFormula					INT,
				@PrevStepCompartment			INT,
				@BatchStandardWaterUsage		INT,
				@BatchActualWaterUsage			INT,
				@BatchWaterUsagePrice			Decimal(10,2),
				@BatchUtilityPrice				Decimal(10,2),
				@BatchWaterType					INT,
				@ExtraTime						INT,
				@TargetTurnTime					INT,
				@EcolabAccountNumber NVARCHAR(25) = NULL,
				@AlarmGroupMasterId INT,
				@PartitionOn SMALLDATETIME,
				@StdInjectionSteps INT,
				@StdWashSteps INT,
				@EcolabTextileCategoryId INT,
				@ChainTextileCategoryId INT,
				@FormulaSegmentId INT,
				@EcolabSaturationId INT,
				@PlantProgramId INT,
				@PreviousShiftId INT,
				@CurrentShiftId INT,
				@ETechLastDroppedAt  DATETIME2   
	                              							
		SELECT @ExtraTime = 0

		SELECT DISTINCT 					
					@NumberOfCompartments=MST.NumberOfComp,
					@EcolabWasherId=Ws.EcolabWasherId
			FROM		TCD.Washer Ws
			INNER JOIN 
						TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId					
		WHERE Ws.WasherId=@WasherId and Ws.Is_Deleted=0
		
				
		IF EXISTS (SELECT  * FROM TEMPDB.DBO.SYSOBJECTS o where o.xtype in ('U') AND o.id = OBJECT_ID(N'tempdb..#XmlTagsTable'))
			BEGIN
					DROP TABLE #XmlTagsTable
			END
		CREATE TABLE  #XmlTagsTable (	CurrentFormula				INT,
										CurretnInjection			INT,
										CurrentOperationCounter		INT,
										Eof							INT,
										TunnelTimeStamp				DATETIME2,
										OnHold						BIT,										
										CompartmentId				INT, 
										CompartmentLoadId			INT, 
										CompartmentFormulaId		INT,										
										ReceivedTime				DATETIME2,
										AutoWeightEntryActive		VARCHAR(10),
										AutoWeightEntryWeight		INT,
										IsFormulaModified			BIT,
										IsHoldSignalModified		BIT	,
										IsStopSinalModified			BIT,
										StopSignal					INT,
										RatioDosingEnabled			INT,
										ETechLastDropped			VARCHAR(100) 						
									)
		INSERT INTO #XmlTagsTable	(
										CurrentFormula	,
										CurretnInjection,										
										CurrentOperationCounter,
										Eof,
										TunnelTimeStamp	,
										OnHold,
										CompartmentId, 
										CompartmentLoadId, 
										CompartmentFormulaId,
										ReceivedTime,
										AutoWeightEntryActive,
										AutoWeightEntryWeight,
										IsFormulaModified,
										IsHoldSignalModified,
										IsStopSinalModified,
										StopSignal,
										RatioDosingEnabled,
										ETechLastDropped
									)			
		
		-- Populate tempdata from xml
		SELECT	T.c.value('../@CurrentFormula', 'INT') AS CurrentFormula, 
				T.c.value('../@CurrentInjection', 'INT') AS CurretnInjection, 				
				T.c.value('../@CurrentOperationCounter', 'INT') AS CurrentOperationCounter, 						
				T.c.value('../@Eof', 'INT') AS EndofFormula, 
				T.c.value('../@TimeStamp', 'VARCHAR(100)') AS TunnelTimeStamp, 
				T.c.value('../@OnHold', 'VARCHAR(100)') AS OnHold, 
				T.c.value('@CompartmentId', 'INT') AS CompartmentId, 
				T.c.value('@LoadId', 'INT') AS CompartmentLoadId, 
				T.c.value('@FormulaId', 'INT') AS CompartmentFormulaId, 				
				T.c.value('@TimeStamp', 'VARCHAR(100)') DateTimeStamp,
				T.c.value('../@Awea', 'VARCHAR(10)') AS AutoWeightEntryActive, 				
				T.c.value('../@Awew', 'INT') AS AutoWeightEntryWeight,	
				T.c.value('../@IsFormulaModified', 'BIT') AS IsFormulaModified,
				T.c.value('../@IsHoldSignalModified', 'BIT') AS IsHoldSignalModified,
				T.c.value('../@IsStopSinalModified', 'BIT') AS IsStopSinalModified,
				T.c.value('../@StopSignal', 'INT') AS StopSignal,
				T.c.value('../@RATA', 'INT') AS RatioDosingEnabled,
				T.c.value('../@ETechLastDroppedAt', 'VARCHAR(100)') AS ETechLastDropped
				
				
		
		FROM @xmlTags.nodes('/Tunnel/Compartment')  T(c)

		
		WHERE	
		T.c.value('@LoadId', 'VARCHAR(100)')  != 0
		AND
		T.c.value('@CompartmentId', 'INT')    <= @NumberOfCompartments
		 --ETech last dropped 
		SELECT @ETechLastDroppedAt=CONVERT(datetime,ETechLastDropped) from #XmlTagsTable
		
		IF EXISTS (SELECT 1 FROM #XmlTagsTable where IsHoldSignalModified = 1)	 
			BEGIN			
				SELECT	@CurrentHoldSignal = Id  FROM TCD.ConduitParameters where Name='HoldSignal'
				INSERT INTO TCD.WasherReading(
								WasherId,
								ParameterId,
								ParameterValue,
								DateTimeStamp,
								EcolabWasherId)
					SELECT		@WasherId,
								@CurrentHoldSignal,
								OnHold,
								ReceivedTime,
								@EcolabWasherId	
					FROM #XmlTagsTable
			END	
		IF EXISTS (SELECT 1 FROM #XmlTagsTable where IsStopSinalModified = 1)	 
			BEGIN	
				INSERT INTO TCD.WasherReading(
							WasherId,
							ParameterId,
							ParameterValue,
							DateTimeStamp,
							EcolabWasherId)
				SELECT		@WasherId,
							12,
							StopSignal,
							ReceivedTime,
							@EcolabWasherId
				FROM #XmlTagsTable
			END	
		IF EXISTS (SELECT 1 FROM #XmlTagsTable where IsFormulaModified = 1)	 
			BEGIN
		
			-- Start find missing load id form xml  and set end date for corresponding enddates in the database
			DECLARE @TempExisitingLoadIds table(ExstingLoadId INT,ExistsBatchId int)
			INSERT INTO @TempExisitingLoadIds(ExstingLoadId,ExistsBatchId)
				SELECT Bd.ControllerBatchId,Bd.BatchId FROM TCD.BatchData Bd					
					--INNER JOIN TCD.BatchWashStepData Bwsd on Bwsd.BatchId=Bd.BatchId
				WHERE Bd.MachineId=@WasherId AND Bd.EndDate IS NULL ORDER BY Bd.StartDate DESC			
		
			SELECT @TempTunnelTimeStamp =(SELECT T.c.value('./@TimeStamp', 'VARCHAR(100)') AS TunnelTimeStamp	FROM @xmlTags.nodes('/Tunnel')  T(c))
			
			DECLARE @TempBatchStepIs TABLE(StepBatchId INT)
			INSERT INTO @TempBatchStepIs (StepBatchId)
			SELECT ExistsBatchId 
				FROM @TempExisitingLoadIds 
				WHERE ExstingLoadId NOT IN (SELECT CompartmentLoadId FROM #XmlTagsTable)
		
		SELECT @PrevStepCompartment=StepCompartment,@PrevBatchId =BatchID 
		FROM TCD.BatchWashStepData  
		WHERE BatchId in (select StepBatchId from @TempBatchStepIs) AND EndTime IS NULL

		UPDATE 
		TCD.BatchWashStepData 
		SET EndTime = @TempTunnelTimeStamp
		WHERE BatchId in (select StepBatchId from @TempBatchStepIs) AND EndTime IS NULL

		DECLARE @BatchShiftId int
		DECLARE @ShiftStartDateTemp table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
		INSERT INTO @ShiftStartDateTemp(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @TempTunnelTimeStamp
		SELECT @BatchShiftId = ssdt.ShiftId FROM @ShiftStartDateTemp ssdt ORDER BY ssdt.ShiftStartdate

		-- Updating Batches moved out of the tunnel
		UPDATE TCD.BatchData 
		SET		
				EndDate=@TempTunnelTimeStamp
			,	EndDateFormula=@TempTunnelTimeStamp,
			ShiftId = @BatchShiftId
		WHERE BatchId in (select StepBatchId from @TempBatchStepIs)

		--End find missing load id form xml  and set end date for corresponding enddates in the database
		 
		--Start HoldTime Calculation
			SELECT 
					@BatchGroupId=GroupId
				,	@BatchFormula=ProgramNumber
				,	@BatchStartDate=StartDate
				,	@BatchEndDate=EndDate 
			FROM TCD.BatchData 
			WHERE BatchId IN (select		StepBatchId from @TempBatchStepIs)

			SELECT @TotalRunTime=TotalRunTime 
			FROM TCD.TunnelProgramSetup 
			WHERE	WasherGroupId =@BatchGroupId 
				AND ProgramNumber=@BatchFormula

			
			INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) 
			SELECT StepBatchId,@EcolabWasherId,17,(DATEDIFF(SECOND, @BatchStartDate, @BatchEndDate))-@TotalRunTime,bd.partitionon
            FROM @TempBatchStepIs,TCD.BatchData bd WHERE bd.BatchId= [@TempBatchStepIs].StepBatchId  and [@TempBatchStepIs].StepBatchId NOT IN (SELECT BATCHID FROM TCD.BatchParameters AS BP WHERE BP.ParameterId = 17)
 
		--End HoldTime Calculation

			 --Start Good or Bad Injection in BatchDataTable
					IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@PrevBatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
						BEGIN
					
							;WITH CteTempBatchTunnelStepData  (	
								InjectionsCount,BatchId,ProgramNumber
							) AS  
							(
								SELECT DISTINCT Bws.StepCompartment,
												BD.BatchId,												
												Bd.ProgramNumber
												FROM TCD. BatchData Bd
								INNER JOIN 
										TCD.BatchWashStepData Bws 
															ON Bws.BatchId			=		Bd.BatchId 
								WHERE    
														
														Bd.BatchId					=		@PrevBatchId ) 
								SELECT @CteTemTunnelWashSetps=COUNT(CTE1.InjectionsCount)
								FROM CteTempBatchTunnelStepData CTE1 
								INNER JOIN TCD.BatchData Bd ON Bd.BatchId=CTE1.BatchId
								WHERE Bd.BatchId=@BatchId

								;WITH CteTempBatchInjections (	
								InjectionsCount,ProgramNumber
							) AS  
							(
								SELECT  DISTINCT 
												
												Tds.CompartmentNumber,
												Tps.ProgramNumber
									 	FROM TCD.TunnelProgramSetup Tps 
										INNER JOIN 
													TCD.TunnelDosingSetup Tds ON 
														Tds.TunnelProgramSetupId	=		Tps.TunnelProgramSetupId
										INNER JOIN 
													TCD.TunnelDosingProductMapping Tdpm ON 
													Tdpm.TunnelDosingSetupId		=		Tds.TunnelDosingSetupId
										INNER JOIN 
													TCD.ControllerEquipmentSetup Ces ON 
													Ces.ControllerEquipmentSetupId	=		Tdpm.ControllerEquipmentSetupId
													WHERE 																		 								
													Tps.ProgramNumber				=		@PrevFormula )
								SELECT @CteTempBatchTunnelWashSteps=COUNT(CTE2.InjectionsCount)
								FROM CteTempBatchInjections CTE2 

										Insert Tcd.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @PrevBatchId,@EcolabWasherId,18,
										CASE	WHEN @CteTempBatchTunnelWashSteps	=	@CteTemTunnelWashSetps THEN 1
												WHEN @CteTempBatchTunnelWashSteps	!=	@CteTemTunnelWashSetps THEN 3 END,
												(SELECT PartitionOn FROM TCD.BatchData where BatchId=@PrevBatchId and MachineId=@WasherId)
														
														
																
				END

			-- End Good or Bad Injection in BatchDataTable


	-- Fetching data from cursor
			DECLARE @MYCURSOR CURSOR
			SET @MYCURSOR = CURSOR FAST_FORWARD
			FOR
			SELECT		CurrentFormula	,
						CurretnInjection,										
						CurrentOperationCounter,
						Eof,
						TunnelTimeStamp	,
						OnHold,
						CompartmentId, 
						CompartmentLoadId, 
						CompartmentFormulaId,
						ReceivedTime,
						AutoWeightEntryActive,
						AutoWeightEntryWeight,
						IsFormulaModified,
						IsHoldSignalModified,
						IsStopSinalModified,
						StopSignal,
						RatioDosingEnabled

				FROM #XmlTagsTable ORDER BY CompartmentId ASC
			DECLARE			@CurCurrentFormula					INT,
							@CurCurretnInjection			INT,
							@CurCurrentOperationCounter		INT,
							@CurEof							INT,
							@CurTunnelTimeStamp				DATETIME2,
							@CurOnHold						BIT,
							@CurCompartmentId				INT, 
							@CurCompartmentLoadId			INT, 
							@CurCompartmentFormulaId		INT,
							@CurReceivedTime				DATETIME2,
							@AutoWeightEntryActive			VARCHAR(10),
							@AutoWeightEntryWeight			INT,
							@IsFormulaModified				BIT,
							@IsHoldSignalModified			BIT,
							@IsStopSinalModified			BIT,
							@StopSignal						INT,
							@RatioDosingEnabled				INT	

			OPEN @MYCURSOR
			FETCH NEXT FROM @MYCURSOR
							INTO @CurCurrentFormula			,
							@CurCurretnInjection			,
							@CurCurrentOperationCounter		,
							@CurEof							,
							@CurTunnelTimeStamp				,
							@CurOnHold						,
							@CurCompartmentId				, 
							@CurCompartmentLoadId			, 
							@CurCompartmentFormulaId		,
							@CurReceivedTime				,
							@AutoWeightEntryActive			,
							@AutoWeightEntryWeight			,
							@IsFormulaModified				,
							@IsHoldSignalModified			,
							@IsStopSinalModified			,
							@StopSignal						,
							@RatioDosingEnabled
			WHILE @@FETCH_STATUS = 0
			BEGIN
				

			IF(@IsFormulaModified !=0)	
			BEGIN
				IF(@CurCurrentFormula != @CurEof and @CurCurretnInjection = 0 and @CurCurrentOperationCounter = 0)
					BEGIN

			SELECT DISTINCT 							
							@MachineInternalId			=	Mst.MachineInternalId,
							@GroupId					=	Mst.GroupId,
							@ControllerId				=	Ctrl.ControllerId				
					FROM TCD.Washer Ws
						INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
						INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
						INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
						INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId	=	Mst.ControllerId
					WHERE Ws.WasherId=@WasherId 	

				SELECT DISTINCT 
							@ProgramMasterId			=	Wps.ProgramId,
							@NominalLoad				=	Wps.NominalLoad,
							@MaxLoad					=	Ws.MaxLoad,
							@CurrencyCode				=	Pl.CurrencyCode, 
							@TargetTurnTime				=   (3600/(Wps.TotalRunTime/Mst.NumberofComp))

				FROM TCD.Washer Ws
						INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
						INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
						INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
						INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
						INNER JOIN TCD.Plant Pl ON Pl.EcolabAccountNumber	=		Ws.EcoLabAccountNumber
						
				WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@CurCurrentFormula and Wps.Is_Deleted=0

				select @PlantWasherNumber = plantwashernumber from tcd.washer where washerid = @WasherId
	
				SELECT  @MaxWashertGroupCapacity		=	Max(ws.MaxLoad)
				FROM TCD.Washer WS
					INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
					INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId		
				WHERE Mst.GroupId=@GroupId

				SELECT @StandardWeight					=	@NominalLoad  								
				SELECT @AutoWeightEntryWeight=Case @AutoWeightEntryActive WHEN 'False' THEN @StandardWeight ELSE  @AutoWeightEntryWeight END 
				
						
				SELECT @MachineInternalId,@GroupId,@ProgramMasterId,@NominalLoad,@WasherId,@CurCurrentFormula,@PrevBatchId
				SELECT @CurCurrentFormula				AS CurCurrentFormula			,
							@CurCurretnInjection		AS CurCurretnInjection		,
							@CurCurrentOperationCounter	AS CurCurrentOperationCounter	,
							@CurEof						AS CurEof 		,
							@CurTunnelTimeStamp			AS CurTunnelTimeStamp		,
							@CurOnHold					AS CurOnHold			,
							@CurCompartmentId			AS CurCompartmentId			, 
							@CurCompartmentLoadId		AS CurCompartmentLoadId 		, 
							@CurCompartmentFormulaId	AS CurCompartmentFormulaId		,
							@CurReceivedTime			AS CurReceivedTime,
							@AutoWeightEntryActive		AS AutoWeightEntryActive,
							@AutoWeightEntryWeight		AS AutoWeightEntryWeight,
							@IsFormulaModified			AS IsFormulaModified
		
		IF(@CurCompartmentFormulaId > 0)
		BEGIN
					UPDATE TCD.ConduitController
					SET LastConnectedTime		=	GETUTCDATE()
					WHERE ControllerId			=	@ControllerId
		END
		
		
		IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchData WHERE MachineId=@WasherId AND StartDate =@CurTunnelTimeStamp)
		BEGIN

			DECLARE @ShiftStartDate table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
			INSERT INTO @ShiftStartDate(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurTunnelTimeStamp


			 --Start Rollup for previous completed shift
			   IF(CAST(@CurTunnelTimeStamp as date) < CAST(GETUTCDATE() as date))
			   BEGIN
				  SELECT TOP 1 @PreviousShiftId=ShiftId FROM TCD.BatchData WHERE MachineId=@WasherId ORDER BY StartDate DESC	   
				  SELECT Top 1 @CurrentShiftId = ShiftId from @ShiftStartDate
				  IF(@CurrentShiftId != @PreviousShiftId)
				  BEGIN
					 EXEC TCD.ProductionShiftDataRollup @PreviousShiftId, @RedFlagShiftId OUTPUT
					 IF(@RedFlagShiftId IS NULL)
					 BEGIN
						SET @RedFlagShiftId = @PreviousShiftId
					 END
				  END
			   END
			   --End Rollup for previous completed shift

				--Start Getting InjectionCount,StepCount And ProductCount
					SELECT @StdInjectionSteps= count(tdpm.TunnelDosingSetupId) ,
					@StdWashSteps= count(DISTINCT tds.TunnelDosingSetupId)-count(tdpm.TunnelDosingSetupId) 
					FROM TCD.TunnelDosingProductMapping tdpm
					RIGHT JOIN tcd.TunnelDosingSetup tds on tdpm.TunnelDosingSetupId=tds.TunnelDosingSetupId
					WHERE tds.GroupId=@GroupId AND tds.ProgramNumber=@CurCurrentFormula
			    --Start-----ProgramMasterID logic for PlantChainProgram
					SELECT 
					@PlantProgramId=pm.PlantProgramId,
					@EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
					@ChainTextileCategoryId = pm.ChainTextileId,
					@FormulaSegmentId = pm.FormulaSegmentId,
					@EcolabSaturationId = pm.EcolabSaturationId 
					FROM TCD.ProgramMaster pm WHERE pm.ProgramId=@ProgramMasterId AND pm.Is_Deleted=0
					IF(@PlantProgramId <> 0  AND @PlantProgramId IS NOT NULL)
						BEGIN
							--Assign value from plantchainprogram table based on plantprogramId
							SELECT
								@EcolabTextileCategoryId = pcp.EcolabTextileCategoryId,
								@ChainTextileCategoryId = pcp.ChainTextileCategoryId,
								@FormulaSegmentId = pcp.FormulaSegmentId,
								@EcolabSaturationId = pcp.EcolabSaturationId
								FROM tcd.PlantChainProgram pcp
								WHERE pcp.PlantProgramId=@PlantProgramId AND pcp.Is_Deleted=0
						END
				--End-----ProgramMasterID logic for PlantChainProgram
				-- New Batch Creation
							INSERT INTO TCD.BatchData(
											ControllerBatchId ,
											EcolabWasherId,
											GroupId ,
											MachineInternalId,
											PlantWasherNumber,
											StartDate ,
											EndDate ,
											ProgramNumber,
											ProgramMasterId,
											MachineId,
											ActualWeight,
											StandardWeight,
											CurrencyCode,
											ShiftId,
											PartitionOn,
											TargetTurnTime,
											StdInjectionSteps,
											StdWashSteps,
											EcolabTextileCategoryId,
											ChainTextileCategoryId,
											FormulaSegmentId,
											EcolabSaturationId,
											PlantProgramId,
											ETechlastDroppedTimeStamp
											)


										SELECT DISTINCT @CurCompartmentLoadId
											,@EcolabWasherId
											,@GroupId
											,@MachineInternalId
											,@PlantWasherNumber
											--,@CurReceivedTime
											,@CurTunnelTimeStamp
											,NULL
											,@CurCurrentFormula
											,@ProgramMasterId
											,@WasherId
											,@AutoWeightEntryWeight
											,@StandardWeight 
											,@CurrencyCode
											,(SELECT Top 1 ShiftId from @ShiftStartDate)
											,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
											,@TargetTurnTime
											,@StdInjectionSteps
											,@StdWashSteps
											,@EcolabTextileCategoryId
											,@ChainTextileCategoryId
											,@FormulaSegmentId
											,@EcolabSaturationId
											,@PlantProgramId	
											,@ETechLastDroppedAt	
								
			
								SET @BatchID=SCOPE_IDENTITY()	

								--Start insert InjectionActualCount and StepActualCount in TCD.BatchParameters
								INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchID,@EcolabWasherId,37,@StdInjectionSteps,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
								INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchID,@EcolabWasherId,38,@StdWashSteps,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)  
								--End insert InjectionActualCount and StepActualCount in TCD.BatchParameters

								--If the received formula is not configured in enVision then create an alarm 
							IF(@ProgramMasterId is NULL)
							BEGIN
							SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant
							SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.AlarmGroupMsterVsControllerModelType AGMVCMT
							INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
							WHERE AGMVCMT.AlarmCode = 9000
								INSERT INTO [TCD].[AlarmData] 
								   (EcoalabAccountNumber,
								   AlarmCode,
								   BatchId,
								   controllerID,
								   StartDate,
								   GroupId,
								   MachineInternalId,
								   ProgramId,   
								   IsActive,
								   EndDate,
								   MachineId,
								   AlarmGroupMasterId,
								   PartitionOn)
									  SELECT
									   @ECOLABAccountNumber,
									   9000,
									   @BatchID,
									   @ControllerId,
									   @CurTunnelTimeStamp,
									   @GroupId,
									   @MachineInternalId,
									   @CurCurrentFormula,
									   0,
									   @CurTunnelTimeStamp,
									   @WasherId,
									   @AlarmGroupMasterId,
									   @CurTunnelTimeStamp
							END


						-- Wash Step Information		
						INSERT INTO TCD.BatchWashStepData(
											BatchId
											,StepCompartment
											,StartTime
											,EndTime
											,PartitionOn
											,EcolabWasherId) 				
						SELECT	
											@BatchID,
											@CurCompartmentId,
											@CurTunnelTimeStamp,
											--@CurReceivedTime,
											NULL,
											(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
											@EcolabWasherId
						-- Product Usage
				IF (@RatioDosingEnabled = 1)
					BEGIN
						INSERT INTO TCD.BatchProductData(
									BatchId,
									StepCompartment,
									ActualQuantity,
									StandardQuantity,
									Price,
									[TimeStamp],
									PartitionOn,
									EcolabWasherId,
									ProductId
						)					
						SELECT DISTINCT @BatchID	
										,@CurCompartmentId
										,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * (@AutoWeightEntryWeight/@StandardWeight) AS ActualQuantity						
										,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * (@AutoWeightEntryWeight/@StandardWeight) AS StandardQuantity										
										,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price	
										,@CurTunnelTimeStamp								
										--,@CurReceivedTime
										,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
										,@EcolabWasherId
										,Pdm.ProductID
							FROM TCD.Washer WS
							INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
							INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
							INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
							INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
							INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
							INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
							INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId=Wdpm.ControllerEquipmentSetupId
							INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Ces.ProductId
							--INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
						WHERE 
								Ws.WasherId=@WasherId AND 
								Wps.ProgramNumber=@CurCurrentFormula AND 
								Wds.CompartmentNumber=@CurCompartmentId	AND
								Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
					END
				ELSE
					BEGIN
						INSERT INTO TCD.BatchProductData(
									BatchId,
									StepCompartment,
									ActualQuantity,
									StandardQuantity,
									Price,
									[TimeStamp],
									PartitionOn,
									EcolabWasherId,
									ProductId
						)					
						SELECT DISTINCT @BatchID	
										,@CurCompartmentId
										,((Wps.NominalLoad * Wdpm.Quantity)/ 100) AS ActualQuantity						
										,((Wps.NominalLoad * Wdpm.Quantity)/ 100) AS StandardQuantity										
										,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price
										,@CurTunnelTimeStamp									
										--,@CurReceivedTime
										,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
										,@EcolabWasherId
										,Pdm.ProductID
							FROM TCD.Washer WS
							INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
							INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
							INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
							INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
							INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
							INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
							INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId=Wdpm.ControllerEquipmentSetupId
							INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Ces.ProductId
							--INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
						WHERE 
								Ws.WasherId=@WasherId AND 
								Wps.ProgramNumber=@CurCurrentFormula AND 
								Wds.CompartmentNumber=@CurCompartmentId	AND
								Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
					END			
								
								
						-- Transfer Signal		
								INSERT INTO TCD.WasherReading(
															WasherId,
															ParameterId,
															ParameterValue,
															DateTimeStamp,
															PartitionOn,
															EcolabWasherId)
									SELECT @WasherId,
											6,
											1,
											@TempTunnelTimeStamp,
											(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
											@EcolabWasherId
									UNION ALL
									SELECT @WasherId,
											6,
											0,
											GETUTCDATE(),
											(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
											@EcolabWasherId
			
						-- Insert Customer Data
						INSERT INTO TCD.BatchCustomerData(
										BatchId,
										CustomerId,
										Weight,
										PiecesCount,
										PartitionOn,
										EcolabWasherId
										)
						SELECT DISTINCT	
										Bd.BatchId,		
										Pc.ID,
										@AutoWeightEntryWeight,
										ROUND(COALESCE((@AutoWeightEntryWeight * Pm.Pieces) / NULLIF(Pm.Weight,0), 0),0),
										(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
										@EcolabWasherId
						
						FROM TCD.Washer WS
							INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
							INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId							
							INNER JOIN TCD.TunnelProgramSetup Tps ON Tps.WasherGroupId = Wg.WasherGroupId
							INNER JOIN TCD.ProgramMaster Pm ON Pm.ProgramId=Tps.ProgramId
							INNER JOIN TCD.PlantCustomer Pc ON Pc.ID=Pm.CustomerId
							INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
						WHERE 
							Ws.WasherId=@WasherId AND 
							Tps.ProgramNumber=@CurCompartmentFormulaId AND 
							Bd.BatchId=@BatchID	  AND 
							Pm.CustomerId != -1
							AND Pm.[Weight] > 0
		END

		ELSE
		BEGIN
			SELECT @BatchID=BatchId, @PartitionOn=PartitionOn
			FROM TCD.BatchData 
			WHERE MachineId=@WasherId 
			AND ControllerBatchId=@CurCompartmentLoadId
			
			IF(@BatchID IS NOT NULL)
			BEGIN
			UPDATE TCD.BatchWashStepData 
				SET EndTime=@CurTunnelTimeStamp
			WHERE BatchId=@BatchId 
				AND StepCompartment=@CurCompartmentId-1

				IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchWashStepData WHERE StartTime=@CurTunnelTimeStamp and BatchId=@BatchID)
				BEGIN
					INSERT INTO TCD.BatchWashStepData(
											BatchId
											,StepCompartment
											,StartTime
											,EndTime
											,PartitionOn
											,EcolabWasherId) 				
						SELECT	
											@BatchID,
											@CurCompartmentId,
											@CurTunnelTimeStamp,
											--@CurReceivedTime,
											NULL,
											@PartitionOn,
											@EcolabWasherId
				END							
				IF (@RatioDosingEnabled = 1)
					BEGIN
					IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurTunnelTimeStamp and BatchId=@BatchID)
					BEGIN
						INSERT INTO TCD.BatchProductData(
									BatchId,
									StepCompartment,
									ActualQuantity,
									StandardQuantity,
									Price,
									[TimeStamp],
									PartitionOn,
									EcolabWasherId,
									ProductId
									)
						SELECT DISTINCT 
									@BatchID	
									,@CurCompartmentId
									,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * (@AutoWeightEntryWeight/@StandardWeight) AS ActualQuantity							
									,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * (@AutoWeightEntryWeight/@StandardWeight) AS StandardQuantity	
									,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price
									,@CurTunnelTimeStamp									
									--,@CurReceivedTime
									,@PartitionOn
									,@EcolabWasherId
									,Pdm.ProductID
						FROM TCD.Washer WS
						INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
						INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
						INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
						INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
						INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
						INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
						INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId=Wdpm.ControllerEquipmentSetupId
						INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Ces.ProductId
						--INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
						WHERE 
							Ws.WasherId=@WasherId 
							AND Wps.ProgramNumber=@CurCompartmentFormulaId 
							AND Wds.CompartmentNumber=@CurCompartmentId	AND
							Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
					END
				END -- end of ratio dosing if
				ELSE
					BEGIN
					IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurTunnelTimeStamp and BatchId=@BatchID)
					BEGIN
					INSERT INTO TCD.BatchProductData(
									BatchId,
									StepCompartment,
									ActualQuantity,
									StandardQuantity,
									Price,
									[TimeStamp],
									PartitionOn,
									EcolabWasherId,
									ProductId
									)
					SELECT DISTINCT 
									@BatchID	
									,@CurCompartmentId
									,((Wps.NominalLoad * Wdpm.Quantity)/ 100) AS ActualQuantity							
									,((Wps.NominalLoad * Wdpm.Quantity)/ 100) AS StandardQuantity	
									,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price
									,@CurTunnelTimeStamp									
									--,@CurReceivedTime
									,@PartitionOn
									,@EcolabWasherId
									,Pdm.ProductID
						FROM TCD.Washer WS
						INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
						INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
						INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
						INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
						INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
						INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
						INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId=Wdpm.ControllerEquipmentSetupId
						INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Ces.ProductId
								
					WHERE 
							Ws.WasherId=@WasherId 
							AND Wps.ProgramNumber=@CurCompartmentFormulaId 
							AND Wds.CompartmentNumber=@CurCompartmentId	AND
								Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0	
			END
			END								
				END -- end of BatchId NULL if
			END -- end of else
		END		-- end of IF(@CurCurrentFormula != @CurEof and @CurCurretnInjection = 0 and @CurCurrentOperationCounter = 0)							
	END		-- end of IF(@IsFormulaModified !=0)	
															
			FETCH NEXT FROM @MYCURSOR
			INTO @CurCurrentFormula			,
							@CurCurretnInjection			,
							@CurCurrentOperationCounter		,
							@CurEof							,
							@CurTunnelTimeStamp				,
							@CurOnHold						,
							@CurCompartmentId				, 
							@CurCompartmentLoadId			, 
							@CurCompartmentFormulaId		,
							@CurReceivedTime				,
							@AutoWeightEntryActive			,
							@AutoWeightEntryWeight			,
							@IsFormulaModified				,
							@IsHoldSignalModified			,
							@IsStopSinalModified			,
							@StopSignal						,
							@RatioDosingEnabled
			END
			CLOSE @MYCURSOR
			DEALLOCATE @MYCURSOR	
			
		
		END
END

GO

----------------------------------------------PLCXML Data Deletion Query----------------------------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlConventionalData_Online]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlConventionalData_Online]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ProcessMyControlConventionalData_Online]
(
	@ControllerID   INT,
	@VxML           XML,
	@RedFlagShiftId INT OUTPUT
)
AS
	BEGIN
	    DECLARE @MachineNumber           INT,
			  @StepNumber              INT,
			  @StartDateTime           DATETIME,
			  @EndDateTime             DATETIME,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @PHValue                 INT,
			  @TemperatureMin          INT,
			  @TemperatureMax          INT,
			  @TempMinStatus           INT,
			  @TempMaxStatus           INT,
			  @BatchNumber             INT,
			  @WasherID                INT,
			  @WasherGroupID           INT,
			  @EcoLabWasherID          INT,
			  @ProgramMasterID         INT,
			  @PlantWasherNumber       INT,
			  @ShiftID                 INT,
			  @FrmParameterID          INT,
			  @PHParameterID           INT,
			  @PHParameterStatus       INT,
			  @BatchID                 INT,
			  @ShiftStartdate          DATETIME,
			  @ShiftName               NVARCHAR(50),
			  @XMLDataID               INT,
			  @TempParameter           INT,
			  @TemperatureMinParam     INT,
			  @TemperatureMaxParam     INT,
			  @TempMinStatusParam      INT,
			  @TempMaxStatusParam      INT,
			  @WashStepNo              INT,
			  @CurrencyCode            VARCHAR(50),
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @TargetTurnTime          INT,
			  @MeterID                INT,
			  @WaterConsumption1      DECIMAL(18,4),
			  @WaterConsumption2      DECIMAL(18,4),
			  @ModuleCount			  INT

	    SELECT @MachineNumber = T.c.value('@MachineNumber', 'INT'),
			 @StepNumber = T.c.value('@StepNumber', 'INT'),
			 @StartDateTime = T.c.value('@StartDateTime', 'DATETIME'),
			 @EndDateTime = T.c.value('@EndDateTime', 'DATETIME'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@NominalLoad', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'INT'),
			 @PHStatus = T.c.value('@PHStatus', 'INT'),
			 @PHValue = T.c.value('@PHValue', 'INT'),
			 @TemperatureMin = T.c.value('@TemperatureMin', 'INT'),
			 @TemperatureMax = T.c.value('@TemperatureMax', 'INT'),
			 @TempMaxStatus = T.c.value('@TemperatureMaxStatus', 'INT'),
			 @TempMinStatus = T.c.value('@TemperatreMinStatus', 'INT'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @WaterConsumption1=T.c.value('@WaterConsumption1','DECIMAL(18,4)'),
			 @WaterConsumption2=T.c.value('@WaterConsumption2','DECIMAL(18,4)')
	    FROM @VxML.nodes('MyControlConventionalData') T(C);

		---Deletes Xml Data from max of timestamp to previous 7 days

		IF((SELECT  count(PLCXMLDataId) FROM tcd.PLCXMLData) > 50000)
		BEGIN
			TRUNCATE  TABLE tcd.plcxmldata;
		END ​


     --Inserts Xml Data

		INSERT INTO tcd.PLCXMLData
	    (
			 PLC_Type,
			 XML_Data,
			 XML_Type,
			 Batch_Number,
			 Time_Stamp
	    )
	       VALUES
				(
					 3,
					CONVERT(nvarchar(max), @VxML),
					 1,
					 ISNULL(@BatchNumber,0),		 
					 GETUTCDATE()
				);


	    SELECT @PHParameterID = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'pH';
	    SELECT @PHParameterStatus = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'PH Status';
	    SELECT @TemperatureMinParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Mimum Temperature';
	    SELECT @TemperatureMaxParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Maximum Temperature';
	    SELECT @TempMinStatusParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Minimum Temperature Status';
	    SELECT @TempMaxStatusParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Max Temperature Status';
	    SELECT @WashStepNo = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'StepCompartment No';
	    SELECT @FrmParameterID = [Id]
	    FROM TCD.ConduitPArameters
	    WHERE Name = 'Formula Number';
	    DECLARE @ShiftMapping TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    INSERT INTO @ShiftMapping
	    (
		  ShiftId,
		  ShiftName,
		  ShiftStartdate
	    )
	    EXEC TCD.GetShiftStartDate
		    @StartDateTime
	    SELECT @ShiftID = ShiftID,
			 @ShiftStartdate = ShiftStartdate
	    FROM @ShiftMapping;
	    SELECT @WasherGroupID = GroupId,
			 @WasherID = WasherID
	    FROM TCD.MachineSetup ms
	    WHERE ControllerID = @ControllerID
			AND MachineInternalId = @MachineNumber
			AND IsTunnel = 0
			AND IsDeleted = 0;
	    IF(@EndDateTime = '1/1/1900')
		   SELECT @EndDateTime = NULL;
	    IF(@StartDateTime = '1/1/1900')
		   SELECT @StartDateTime = NULL;
	    IF(@WasherId IS NOT NULL)
		   BEGIN
			  SELECT @ProgramMasterId = Wps.ProgramId
			  FROM TCD.Washer Ws
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.ControllerID = Wg.ControllerId
				  INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.EcoLabAccountNumber
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wps.Is_Deleted = 0;
			  SELECT @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber,
				    @CurrencyCode = P.CurrencyCode,
				    @TargetTurnTime = w.TargetTurnTime * 60
			  FROM TCD.Washer w
				  INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.EcolabAccountNumber
			  WHERE w.WasherId = @WasherID;
	   END;
	    SELECT @BatchID = BatchID
	    FROM TCD.BatchData
	    WHERE MachineInternalID = @MachineNumber
			AND StartDate = @StartDateTime
			AND ControllerBatchId = @BatchNumber
			AND MachineID = @WasherID;

	    --Start Getting InjectionCount and StepCount
	    SELECT @StdInjectionSteps = COUNT(DISTINCT wdpm.
	    WasherDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) -
			 COUNT(DISTINCT wdpm.WasherDosingSetupId)
	    FROM TCD.WasherDosingProductMapping wdpm
		    RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm.
		    WasherDosingSetupId = wds.WasherDosingSetupId
	    WHERE wds.ControllerID = @ControllerID
			AND wds.ProgramNumber = @ProgramNumber;
	    --End Getting InjectionCount and StepCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramMasterId
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT @EcolabTextileCategoryId = pcp.
			  EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp.
				    ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    IF(@BatchID IS NULL)
		   BEGIN
			  INSERT INTO TCD.BatchData
			  (ControllerBatchID,
			   EcolabWasherId,
			   GroupId,
			   MachineInternalId,
			   PlantWasherNumber,
			   StartDate,
			   EndDate,
			   ProgramNumber,
			   ProgramMasterId,
			   MachineID,
			   ActualWeight,
			   StandardWeight,
			   CurrencyCode,
			   ShiftId,
			   PartitionOn,
			   StdInjectionSteps,
			   StdWashSteps,
			   EcolabTextileCategoryId,
			   ChainTextileCategoryId,
			   FormulaSegmentId,
			   EcolabSaturationId,
			   PlantProgramId,
			   EndDateFormula,
			   TargetTurnTime
			  )
			  VALUES
			  (
				    @BatchNumber,
				    @EcoLabWasherID,
				    @WasherGroupID,
				    @MachineNumber,
				    @PlantWasherNumber,
				    @StartDateTime,
				    @EndDateTime,
				    @ProgramNumber,
				    @ProgramMasterId,
				    @WasherID,
				    @Load,
				    @NominalLoad,
				    @CurrencyCode,
				    @ShiftID,
				    @ShiftStartdate,
				    @StdInjectionSteps,
				    @StdWashSteps,
				    @EcolabTextileCategoryId,
				    @ChainTextileCategoryId,
				    @FormulaSegmentId,
				    @EcolabSaturationId,
				    @PlantProgramId,
				    @EndDateTime,
				    @TargetTurnTime
			  );
			  SELECT @BatchID = SCOPE_IDENTITY();
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM TCD.BatchParameters
				 WHERE BatchId = @BatchID
					  AND ParameterID = 38
			   )
			   BEGIN
			   IF(@StdWashSteps <> 0
				 OR @StdWashSteps <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
					   BatchId,
					   EcolabWasherId,
					   ParameterId,
					   ParameterValue,
					   PartitionOn
					)
					SELECT @BatchID,
						  @EcoLabWasherID,
						  38,
						  @StdWashSteps,
						  @ShiftStartdate;
				  END
			END;

			  --End Date  Time  is Null 
			  UPDATE TCD.BatchData
			    SET
				   EndDate = GETUTCDATE()
			  WHERE MachineInternalID = @MachineNumber
				   AND StartDate <> @StartDateTime
				   AND EndDate IS NULL
				   AND ControllerBatchId <> @BatchNumber
				   AND MachineId = @WasherId;	
																  		
			  -- Program Number	
			  IF(@ProgramNumber IS NOT NULL
				AND @ProgramNumber > 0)
				 BEGIN
					IF NOT EXISTS
					(
					    SELECT *
					    FROM TCD.WasherReading
					    WHERE WasherId = @WasherID
							AND ParameterID = @FrmParameterID
							AND DateTimeStamp = @StartDateTime
					)
					    BEGIN
						   INSERT INTO TCD.WasherReading
						   (WasherID,
						    ParameterID,
						    ParameterValue,
						    DateTimeStamp,
						    EcoLabWasherID,
						    Partitionon
						   )
						   VALUES
						   (
								@WasherID,
								@FrmParameterID,
								@ProgramNumber,
								@StartDateTime,
								@EcoLabWasherID,
								@ShiftStartdate
						   );
					    END;
				 END;
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM [TCD].[BatchCustomerData]
				 WHERE BatchID = @BatchId
					  AND @CustomerNumber IS NOT NULL
			  )
				 BEGIN
					INSERT INTO [TCD].[BatchCustomerData]
					([BatchId],
					 CustomerID,
					 [Weight],
					 PartitionOn,
					 EcolabWasherId
					)
					VALUES
					(
						  @BatchID,
						  @CustomerNumber,
						  @Load,
						  @ShiftStartdate,
						  @EcolabWasherID
					);
				 END;
		   END;

	    -- PH Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @PHParameterID
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@PHValue <> 0
				OR @PHValue <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @PHParameterID,
							    @PHValue,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 
	 
	    -- PH Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @PHParameterStatus
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@PHStatus <> 0
				OR @PHStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @PHParameterStatus,
							    @PHStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Min Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TemperatureMinParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TemperatureMin <> 0
				OR @TemperatureMin <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TemperatureMinParam,
							    @TemperatureMin,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Max Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TemperatureMaxParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TemperatureMax <> 0
				OR @TemperatureMax <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TemperatureMaxParam,
							    @TemperatureMax,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Min Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TempMinStatusParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TempMinStatus <> 0
				OR @TempMinStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TempMinStatusParam,
							    @TempMinStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Max Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TempMaxStatusParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TempMaxStatus <> 0
				OR @TempMaxStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TempMaxStatusParam,
							    @TempMaxStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- StepCompartment No
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @WashStepNo
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@StepNumber <> 0
				OR @StepNumber <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @WashStepNo,
							    @StepNumber,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END;
 --Start water consumption per batch

	SELECT @MeterID=MeterId
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@MachineNumber
   AND mt.CounterNum = 1;

   SELECT @ModuleCount= COUNT(1) FROM TCD.ModuleReading WHERE Reading =@WaterConsumption1 AND ModuleId = @MeterID
  IF (@ModuleCount=0)
  BEGIN
  IF(ISNULL(@WaterConsumption1,0) > 0 AND ISNULL(@MeterID,0) > 0)
  BEGIN
   INSERT INTO TCD.ModuleReading
     (ModuleId,
      ModuleTypeId,
      Reading,
      TimeStamp
     )
     SELECT
     @MeterID,
     2,	  --Water Meter
     @WaterConsumption1,
     GETUTCDATE()
  END
 END 
 
 SELECT @MeterID=MeterId
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@MachineNumber
   AND mt.CounterNum = 2; 
 -- set  @ModuleCount=@@ROWCOUNT
  SELECT @ModuleCount= COUNT(1) FROM TCD.ModuleReading WHERE Reading =@WaterConsumption2 AND ModuleId = @MeterID
  IF (@ModuleCount=0)
  BEGIN
  IF(ISNULL(@WaterConsumption2,0) > 0 AND ISNULL(@MeterID,0) > 0)
  BEGIN
   INSERT INTO TCD.ModuleReading
     (ModuleId,
      ModuleTypeId,
      Reading,
      TimeStamp
     )
     SELECT
     @MeterID, 
     2,
     @WaterConsumption2,
     GETUTCDATE()
  END
      END   
	 --End water consumption per batch
 END;
 GO
----------------------------------------------END PLCXML Data Deletion Query------------------------------------------------------------------

----------------------------------------------Start PLCXML Data Deletion------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlAlarmData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlAlarmData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [TCD].[ProcessMyControlAlarmData]
	(
	@ControllerID int, 
	@VxML xML
	)
AS
BEGIN
   DECLARE 
			@StartDateTime			DATETIME2,
			@StopDateTime			DATETIME2,
			@AlarmNumber			INT,
			@MachineNumber			INT,
			@BatchNumber			INT,
			@DesiredValue			INT,
			@MeasuredValue			INT,
			@Status					INT,
			@ProgramNumber			INT,
			@GroupId				INT,
			@MachineId				INT,
			@BatchID				INT,
			@ECOLABAccountNumber	NVARCHAR(1000),
			@CurrentDay				DATE=CAST(GETUTCDATE() as date),
			@IsActive				INT,
			@IsTunnel				INT,
			@AlarmGroupMasterId		INT;
			
  	
	SELECT @MachineNumber=T.c.value('@MachineNumber', 'INT'),
			@StartDateTime=T.c.value('@StartDateTime', 'DATETIME'),
			@StopDateTime=T.c.value('@StopDateTime', 'DATETIME'),
			@ProgramNumber=T.c.value('@ProgramNumber', 'INT'),
			@BatchNumber=T.c.value('@BatchNumber', 'INT'),
			@AlarmNumber=T.c.value('@AlarmNumber', 'INT'),
			@DesiredValue=T.c.value('@DesiredValue', 'INT'),
			@MeasuredValue=T.c.value('@MeasuredValue', 'INT'),
			@Status=T.c.value('@Status', 'INT'),
			@IsTunnel=T.c.value('@IsTunnel', 'INT')

	FROM @VxML.nodes('MyControlAlarmData') T(C)

	SELECT @ECOLABAccountNumber = EcolabAccountNumber FROM TCD.Plant

	IF (@stopdatetime is NULL)
	 BEGIN
		SELECT @IsActive = 1
	 END
	 ElSE
	 BEGIN
		SELECT @IsActive = 0
	 END
	
	IF NOT EXISTS(SELECT * FROM TCD.AlarmData 
		WHERE StartDate = @StartDateTime AND controllerID = @ControllerId AND AlarmCode = @AlarmNumber AND MachineInternalId = @MachineNumber AND BatchNumber = @BatchNumber)
	BEGIN

	SELECT @GroupId = GroupId, @MachineId = WasherId FROM TCD.MachineSetup WHERE MachineInternalId = @MachineNumber and ControllerId = @ControllerId and IsTunnel = @IsTunnel
	SELECT @BatchID = BatchId FROM TCD.BatchData WHERE MachineId = @MachineId and ControllerBatchId = @BatchNumber and CAST(StartDate as date)= @CurrentDay

	SELECT TOP 1 @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.ConduitController CC 
			INNER JOIN TCD.ControllerModelControllerTypeMapping CMCTM ON CMCTM.ControllerModelId = CC.ControllerModelId AND CMCTM.ControllerTypeId = CC.ControllerTypeId
			INNER JOIN TCD.AlarmGroupMsterVsControllerModelType AGMVCMT ON CMCTM.Id = AGMVCMT.ControllerModelTypeId
			INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
			WHERE AGMVCMT.AlarmCode = @AlarmNumber AND CC.ControllerId = @ControllerId

		INSERT INTO [TCD].[AlarmData] 
		   (EcoalabAccountNumber,
		   AlarmCode,
		   BatchId,
		   controllerID,
		   StartDate,
		   MachineInternalId,
		   ProgramId,
		   DesiredQuatity,
		   MeasuredQuantity,
		   TempStatus,
		   GroupId,
		   MachineId,
		   BatchNumber,
		   EndDate,
		   IsActive,
		   AlarmGroupMasterId
		   )
			  SELECT
			   @ECOLABAccountNumber,
			   @AlarmNumber,
			   @BatchID,
			   @ControllerId,
			   @StartDateTime,
			   @MachineNumber,
			   @ProgramNumber,
			   @DesiredValue,
			   @MeasuredValue,
			   @Status,
			   @GroupId,
			   @MachineId,
			   @BatchNumber,
			   @StopDateTime,
			   @IsActive,
			   @AlarmGroupMasterId
	END

	ELSE
	BEGIN
		IF (@StopDateTime is not null)
		BEGIN
		
		UPDATE tcd.AlarmData set EndDate = @StopDateTime, IsActive = 0
			WHERE StartDate = @StartDateTime AND controllerID = @ControllerId AND AlarmCode = @AlarmNumber AND MachineInternalId = @MachineNumber AND BatchNumber = @BatchNumber
		
		END
	END
			   	 
END 
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlAnalogData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlAnalogData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ProcessMyControlAnalogData](
	@ControllerID INT,
	@VxML         XML)
AS
	BEGIN
	    DECLARE @TimeStamp    DATETIME
	    -- Getting the current UTC time 
	    SELECT
			 @TimeStamp = GETUTCDATE();

	    -- 1.Extracting xml data 
	    -- 2.And joining with sensor table
	    -- 3.Getting specific Sensor id by passing machine id and controller id and is_deleted(active sensor's)
	    -- 4.CTE will return table of columns i.e sensorid,sensortype,temparature,ph values
	    --Conventional washer sensor readings

	    WITH TempData
		    AS (SELECT
					s.SensorId,
					s.SensorType,
					T.c.value('@Temperature', 'DECIMAL(18,4)') temparature,
					T.c.value('@pH', 'DECIMAL(18,4)')          ph
			   FROM @VxML.nodes('MyControlAnalogData/WEAnalogData') T(c)
				   INNER JOIN TCD.Sensor s ON MachineCompartment =
			   (
				  SELECT TOP 1
					    ms.WasherId
				  FROM tcd.MachineSetup ms
				  WHERE ms.MachineInternalId = T.c.value('@WENumber','INT')
				  AND ms.ControllerId = @ControllerID
				  AND ms.IsDeleted = 0
				  AND ms.IsTunnel = 0
			   )
				   AND s.ControllerID = @controllerid
				   AND s.Is_deleted = 0) 
				   


		    -- inserting records into sensor reading table using merge statement
		    MERGE INTO tcd.sensorreading sr
		    USING
		    (
			   SELECT
					sensorid,
					sensortype,
					CASE
					    WHEN SensorType = 1
					    THEN Temparature		 --Temparature
					    WHEN SensorType = 2
					    THEN ph				 --PH
					END reading
			   FROM tempdata
		    ) temp
		    ON sr.sensorId = temp.sensorid
			  AND temp.reading =
		    (
			   SELECT TOP 1
					reading
			   FROM tcd.SensorReading
			   WHERE SensorId = temp.sensorid
			   ORDER BY
					  TimeStamp DESC
		    ) 

		    -- If records are not in the sensor reading tables
		    -- Sensor records are inserted depending on the sensor type	
	
			   WHEN NOT MATCHED AND(temp.reading <> NULL
							    OR temp.reading <> 0)
			   THEN INSERT(
						sensorid,
						reading,
						timestamp) VALUES
		    (
									   temp.sensorid,
									   temp.reading,
									   @TimeStamp
		    );
	END;
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlConventionalData_CompletedBatches]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlConventionalData_CompletedBatches]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ProcessMyControlConventionalData_CompletedBatches](
	@ControllerID   INT,
	@VxML           XML,
	@PLCPointer     INT,
	@ReadPointer    INT,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @MachineNumber           INT,
			  @StartDateTime           DATETIME,
			  @EndDateTime             DATETIME,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @PHValue                 INT,
			  @TemperatureMin          INT,
			  @TemperatureMax          INT,
			  @TempMinStatus           INT,
			  @TempMaxStatus           INT,
			  @BatchNumber             INT,
			  @WasherID                INT,
			  @WasherGroupID           INT,
			  @EcoLabWasherID          INT,
			  @ProgramMasterID         INT,
			  @PlantWasherNumber       INT,
			  @ShiftID                 INT,
			  @BatchID                 INT,
			  @ShiftStartdate          DATETIME,
			  @LastStep                INT,
			  @CurrentStep             INT,
			  @CurrentStepTime         DATETIME,
			  @MinTempParamID          INT,
			  @MaxTempParamID          INT,
			  @MinTempStatuParamID     INT,
			  @MaxTempStatusParamID    INT,
			  @PHStatusParamID         INT,
			  @PHValueParamID          INT,
			  @CurrencyCode            VARCHAR(50),
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @ActualInjSteps          INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @TargetTurnTime          INT,
			  @PreviousShiftId         INT,
			  @CurrentShiftId          INT,
			  @MeterID                 INT,
			  @StepComportment         INT,
			  @Stepno                  INT,
			  @quantity                INT,
			  @productid               INT,
			  @Price                   DECIMAL(18, 4),
			  @StandardQty             DECIMAL(18, 4),
			  @TimeStamp               DATETIME2(7),
			  @MaxWashertGroupCapacity INT,
			  @InjectionNumber         INT,
			  @WaterConsumption1       DECIMAL(10,6),
			  @WaterConsumption2       DECIMAL(10,6),
			  @EnergyCount             INT
	    SELECT
			 @MachineNumber = T.c.value('@MachineNumber', 'INT'),
			 @StartDateTime = T.c.value('@StartDateTime', 'DateTime'),
			 @EndDateTime = T.c.value('@EndDateTime', 'DateTime'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@NominalLoad', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'INT'),
			 @PHStatus = T.c.value('@PHStatus', 'INT'),
			 @PHValue = T.c.value('@PHValue', 'INT'),
			 @TemperatureMin = T.c.value('@TemperatureMin', 'INT'),
			 @TemperatureMax = T.c.value('@TemperatureMax', 'INT'),
			 @TempMaxStatus = T.c.value('@TemperatureMaxStatus', 'INT'),
			 @TempMinStatus = T.c.value('@TemperatreMinStatus', 'INT'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @WaterConsumption1 = T.c.value('@WaterConsumption1','DECIMAL(10,6)'),
			 @WaterConsumption2 = T.c.value('@WaterConsumption2','DECIMAL(10,6)')
	    FROM @VxML.nodes('MyControlConventionalData') T(C);

	    DECLARE @ShiftMapping TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    INSERT INTO @ShiftMapping
	    (
			 ShiftId,
			 ShiftName,
			 ShiftStartdate
	    )
	    EXEC TCD.GetShiftStartDate
		    @StartDateTime;
	    SELECT
			 @ShiftID = ShiftID,
			 @ShiftStartdate = ShiftStartdate
	    FROM @ShiftMapping;
	    SELECT
			 @WasherGroupID = GroupId,
			 @WasherID = WasherID
	    FROM TCD.MachineSetup ms
	    WHERE ControllerID = @ControllerID
			AND MachineInternalId = @MachineNumber
			AND IsTunnel = 0
			AND IsDeleted = 0;
	    IF(@WasherId IS NOT NULL)
		   BEGIN
			  SELECT
				    @ProgramMasterId = Wps.ProgramId
			  FROM TCD.Washer Ws
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws
				  .WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =
				  Mst.GroupId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.
				  ControllerID = Wg.ControllerId
				  INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber =
				  Ws.EcoLabAccountNumber
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wps.Is_Deleted = 0;
			  SELECT
				    @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber,
				    @CurrencyCode = P.CurrencyCode,
				    @TargetTurnTime = w.TargetTurnTime * 60
			  FROM TCD.Washer w
				  INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.
				  EcolabAccountNumber
			  WHERE w.WasherId = @WasherID;
		   END;
	    SELECT
			 @BatchID = BatchID
	    FROM TCD.BatchData
	    WHERE MachineInternalID = @MachineNumber
			AND StartDate = @StartDateTime
			AND ControllerBatchId = @BatchNumber
			AND MachineID = @WasherID;

	    --Start Getting InjectionCount and StepCount

	    SELECT
			 @StdInjectionSteps = COUNT(DISTINCT wdpm.
			 WasherDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) -
			 COUNT(DISTINCT wdpm.WasherDosingSetupId)
	    FROM TCD.WasherDosingProductMapping wdpm
		    RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm.
		    WasherDosingSetupId = wds.WasherDosingSetupId
	    WHERE wds.ControllerID = @ControllerID
			AND wds.ProgramNumber = @ProgramNumber;

	    --End Getting InjectionCount and StepCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT
			 @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramMasterId
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT
				    @EcolabTextileCategoryId = pcp.
				    EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp.
				    ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    IF(@BatchID IS NULL)
		   BEGIN

			  --Start Rollup for previous completed shift
			  IF(CAST(@StartDateTime AS DATE) < CAST(GETUTCDATE() AS
			  DATE))
				 BEGIN
					SELECT TOP 1
						  @PreviousShiftId = ShiftId
					FROM TCD.BatchData
					WHERE MachineId = @WasherId
					ORDER BY
						    StartDate DESC;
					SELECT TOP 1
						  @CurrentShiftId = ShiftId
					FROM @ShiftMapping;
					IF(@CurrentShiftId != @PreviousShiftId)
					    BEGIN
						   EXEC TCD.ProductionShiftDataRollup
							   @PreviousShiftId,
							   @RedFlagShiftId OUTPUT;
						   IF(@RedFlagShiftId IS NULL)
							  BEGIN
								 SET @RedFlagShiftId =
								 @PreviousShiftId;
							  END;
					    END;
				 END;
			  --End Rollup for previous completed shift

			  INSERT INTO TCD.BatchData
			  (
				    ControllerBatchID,
				    EcolabWasherId,
				    GroupId,
				    MachineInternalId,
				    PlantWasherNumber,
				    StartDate,
				    EndDate,
				    ProgramNumber,
				    ProgramMasterId,
				    MachineID,
				    ActualWeight,
				    StandardWeight,
				    CurrencyCode,
				    ShiftId,
				    PartitionOn,
				    StdInjectionSteps,
				    StdWashSteps,
				    EcolabTextileCategoryId,
				    ChainTextileCategoryId,
				    FormulaSegmentId,
				    EcolabSaturationId,
				    PlantProgramId,
				    EndDateFormula,
				    TargetTurnTime
			  )
			  VALUES
			  (
				    @BatchNumber,
				    @EcoLabWasherID,
				    @WasherGroupID,
				    @MachineNumber,
				    @PlantWasherNumber,
				    @StartDateTime,
				    @EndDateTime,
				    @ProgramNumber,
				    @ProgramMasterId,
				    @WasherID,
				    @Load,
				    @NominalLoad,
				    @CurrencyCode,
				    @ShiftID,
				    @ShiftStartdate,
				    @StdInjectionSteps,
				    @StdWashSteps,
				    @EcolabTextileCategoryId,
				    @ChainTextileCategoryId,
				    @FormulaSegmentId,
				    @EcolabSaturationId,
				    @PlantProgramId,
				    @EndDateTime,
				    @TargetTurnTime
			  );
			  SELECT
				    @BatchID = SCOPE_IDENTITY();
			  IF NOT EXISTS
			  (
				 SELECT
					   *
				 FROM TCD.BatchParameters
				 WHERE BatchId = @BatchID
					  AND ParameterID = 38
			  )
				 BEGIN
					IF(@StdWashSteps > 0
					   OR @StdWashSteps <> NULL)
					    INSERT INTO TCD.BatchParameters
					    (
							 BatchId,
							 EcolabWasherId,
							 ParameterId,
							 ParameterValue,
							 PartitionOn
					    )
					    SELECT
							 @BatchID,
							 @EcoLabWasherID,
							 38,
							 @StdWashSteps,
							 @ShiftStartdate;
				 END;
		   END;
	    ELSE
		   BEGIN
			  UPDATE tcd.BatchData
			    SET
				   EndDate = @EndDateTime,
				   EndDateFormula = @EndDateTime,
				   ProgramNumber = @ProgramNumber,
				   ProgramMasterId = @ProgramMasterID,
				   ActualWeight = @Load,
				   SyncReady = 1
			  WHERE
				   BatchID = @BatchID;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				1
		   FROM [TCD].[BatchCustomerData]
		   WHERE BatchID = @BatchId
			    AND @CustomerNumber IS NOT NULL
	    )
		   BEGIN
			  INSERT INTO [TCD].[BatchCustomerData]
			  (
				    [BatchId],
				    CustomerID,
				    [Weight],
				    PartitionOn,
				    EcolabWasherId
			  )
			  VALUES
			  (
				    @BatchID,
				    @CustomerNumber,
				    @Load,
				    @ShiftStartdate,
				    @EcolabWasherID
			  );
		   END;
	    ELSE
	    IF(@CustomerNumber > 0)
		   BEGIN
			  UPDATE [TCD].[BatchCustomerData]
			    SET
				   CustomerID = @CustomerNumber,
				   [Weight] = @Load
			  WHERE
				   BatchID = @BatchId;
		   END;
	    CREATE TABLE #Dosing
	    (
		    equipmentNo INT,
		    StepNo      INT,
		    Qty         DECIMAL(10, 6)
	    );
	    INSERT INTO #Dosing
	    SELECT
			 T.c.value('@Equipment', 'INT'),
			 T.c.value('@stepNo', 'INT'),
			 T.c.value('@Qty', 'Decimal(10,6)')
	    FROM @VxML.nodes('MyControlConventionalData/DosingData/Dosing') T
	    (C)
	    WHERE T.c.value('@Qty', 'Decimal(10,6)') > 0;
	    CREATE TABLE #StepTime
	    (
		    Number    INT,
		    [Time]    INT,
		    StartTime DATETIME,
		    EndTime   DATETIME
	    );
	    INSERT INTO #StepTime
	    (
			 Number,
			 [Time]
	    )
	    SELECT
			 T.c.value('@Number', 'INT'),
			 T.c.value('@Time', 'INT')
	    FROM @VxML.nodes('MyControlConventionalData/StepTime/Step') T(C);
	    CREATE TABLE #TimeStamp
	    (
		    Step_Number INT,
		    Time_Stamp  INT
	    );
	
	    --For Calculating TIME_STAMP

	    WITH TempTable
		    AS (SELECT DISTINCT
					Number
			   FROM #StepTime)
		    INSERT INTO #TimeStamp
		    (
				 Step_Number,
				 Time_Stamp
		    )
		    SELECT
				 b.Number,
				 SUM(t.Time) Time_Stamp
		    FROM TempTable b
			    INNER JOIN #StepTime t ON b.Number >= t.Number
		    GROUP BY
				   b.Number;
	    CREATE TABLE #BatchProductData
	    (
		    equipmentNo INT,
		    StepNo      INT,
		    Qty         DECIMAL(10, 6),
		    Time_Stamp  DATETIME2(7),
		    ProductId   INT,
		    Row_No      INT
	    );
	    INSERT INTO #BatchProductData
	    (
			 EquipmentNo,
			 StepNo,
			 Qty,
			 Time_Stamp,
			 ProductId,
			 Row_No
	    )
	    SELECT
			 d.equipmentNo,
			 d.StepNo,
			 d.Qty,
			 DATEADD(ss, ts.Time_Stamp, @StartDateTime),
			 ces.ProductId,
			 ROW_NUMBER() OVER(ORDER BY d.StepNo DESC) AS Row
	    FROM #Dosing d
		    INNER JOIN #TimeStamp ts ON d.StepNo = ts.Step_Number
		    INNER JOIN tcd.ControllerEquipmentSetup ces ON ces.
		    ControllerEquipmentId = d.equipmentNo
	    WHERE d.equipmentNo > 0
			AND d.Qty > 0
			AND ControllerID = @ControllerID
			AND ces.ProductId IS NOT NULL;
	    SELECT
			 @MaxWashertGroupCapacity = MAX(ws.MaxLoad)
	    FROM TCD.Washer WS
		    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.
		    GroupId
	    WHERE Mst.GroupId = @WasherGroupID;
	    DECLARE @Counter INT;
	    SET @counter = 1;
	    WHILE(@counter <=
		    (
			   SELECT
					COUNT(ROW_No)
			   FROM #BatchProductData bpd
		    ))
		   BEGIN
			  SELECT
				    @stepno = bpd.StepNo,
				    @quantity = bpd.Qty,
				    @productid = bpd.ProductId,
				    @timestamp = bpd.Time_Stamp
			  FROM #BatchProductData bpd
			  WHERE bpd.Row_No = @counter
			  ORDER BY
					 bpd.StepNo;
			  SELECT
				    @InjectionNumber = Wdpm.InjectionNumber,
				    @standardqty = ((@NominalLoad / CONVERT( DECIMAL(
				    10, 2), 100)) * Wdpm.Quantity * Ws.MaxLoad) /
				    CONVERT(DECIMAL(10, 2), 100),
				    @price = ((@NominalLoad / CONVERT(       DECIMAL(
				    10, 2), 100)) * Wdpm.Quantity *
				    @MaxWashertGroupCapacity) / CONVERT(DECIMAL(10, 2),
				    100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID)
			  FROM TCD.Washer WS
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws
				  .WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =
				  Mst.GroupId
				  INNER JOIN TCD.WasherGroupType WgT ON WgT.
				  WasherGroupTypeId = Wg.WasherGroupTypeId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.
				  ControllerID = Wg.ControllerId
				  INNER JOIN TCD.WasherDosingSetup Wds ON Wds.
				  WasherProgramSetupId = Wps.WasherProgramSetupId
				  INNER JOIN TCD.WasherDosingProductMapping Wdpm ON
				  Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
				  INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.
				  ProductId = Wdpm.ProductId
				  INNER JOIN TCD.BatchData Bd ON Bd.MachineId = Ws.
				  WasherId
			  WHERE Ws.WasherId = @WasherID
				   AND Wps.ProgramNumber = @ProgramNumber
				   --AND Wdpm.InjectionNumber = @stepno
				   AND Bd.BatchId = @BatchID
				   AND Wps.Is_Deleted = 0
				   AND Pdm.Is_Deleted = 0;
			  INSERT INTO TCD.BatchProductData
			  (
				    BatchId,
				    StepCompartment,
				    ActualQuantity,
				    StandardQuantity,
				    Price,
				    PartitionOn,
				    EcolabWasherId,
				    ProductId,
				    TimeStamp,
				    InjectionNumber
			  )
			  VALUES
			  (
				    @BatchID,
				    @stepno,
				    @quantity,
				    @standardqty,
				    @price,
				    @ShiftStartdate,
				    @EcolabWasherId,
				    @productid,
				    @timestamp,
				    @InjectionNumber
			  );
			  SET @counter = @counter + 1;
		   END;
	    --END For calculating TIMESTAMP
	    --Start Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
	    SELECT
			 @ActualInjSteps = COUNT(DISTINCT StepNo)
	    FROM #Dosing;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE ParameterId = 37
			    AND batchid = @BatchID
			    AND @ActualInjSteps > 0
	    )
		   BEGIN
			  IF(@ActualInjSteps > 0
				OR @ActualInjSteps IS NOT NULL)
				 INSERT INTO TCD.BatchParameters
				 (
					   BatchId,
					   EcolabWasherId,
					   ParameterId,
					   ParameterValue,
					   PartitionOn
				 )
				 SELECT
					   @BatchId,
					   @EcolabWasherId,
					   37,
					   @ActualInjSteps,
					   @ShiftStartDate;
		   END;
	    ELSE
		   BEGIN
			  UPDATE TCD.BatchParameters
			    SET
				   ParameterValue = @ActualInjSteps
			  WHERE
				   ParameterId = 37
				   AND batchid = @BatchID;
		   END;
	    SELECT
			 @LastStep = MAX([Number])
	    FROM #StepTime
	    WHERE [Time] > 0;
	    SELECT
			 @CurrentStep = 1,
			 @CurrentStepTime = @StartDateTime;
	    WHILE(@CurrentStep <= @LastStep)
		   BEGIN
			  UPDATE #StepTime
			    SET
				   StartTime = @CurrentStepTime,
				   EndTime = DATEADD(ss, [time], @CurrentStepTime)
			  WHERE
				   Number = @CurrentStep;
			  SELECT
				    @CurrentStepTime = EndTime
			  FROM #StepTime
			  WHERE Number = @CurrentStep;
			  SELECT
				    @CurrentStep = @CurrentStep + 1;
		   END;
	    INSERT INTO [TCD].[BatchWashStepData]
	    (
			 BatchID,
			 StepCompartment,
			 StartTime,
			 EndTime,
			 PartitionOn,
			 EcolabWasherId
	    )
	    SELECT
			 @BatchID,
			 Number,
			 StartTime,
			 EndTime,
			 @ShiftStartdate,
			 @EcoLabWasherID
	    FROM #StepTime
	    WHERE Number <= @LastStep;
	    SELECT
			 @MinTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Mimum Temperature';
	    SELECT
			 @MaxTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Maximum Temperature';
	    SELECT
			 @MaxTempStatusParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Max Temperature Status';
	    SELECT
			 @MinTempStatuParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Minimum Temperature Status';
	    SELECT
			 @PHValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH';
	    SELECT
			 @PHStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH Status';
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MinTempParamID
	    )
		   BEGIN
			  IF(@TemperatureMin <> 0
				OR @TemperatureMin <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MinTempParamID,
						  @TemperatureMin,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MaxTempParamID
	    )
		   BEGIN
			  IF(@TemperatureMax <> 0
				OR @TemperatureMax <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MaxTempParamID,
						  @TemperatureMax,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MaxTempStatusParamID
	    )
		   BEGIN
			  IF(@TempMaxStatus <> 0
				OR @TempMaxStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MaxTempStatusParamID,
						  @TempMaxStatus,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MinTempStatuParamID
	    )
		   BEGIN
			  IF(@TempMinStatus <> 0
				OR @TempMinStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MinTempStatuParamID,
						  @TempMinStatus,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF(@PHStatus <> 0
		  OR @PHStatus <> NULL)
		   BEGIN
			  INSERT INTO TCD.BatchParameters
			  (
				    BatchId,
				    EcolabWasherId,
				    ParameterId,
				    ParameterValue,
				    PartitionOn
			  )
			  VALUES
			  (
				    @BatchID,
				    @EcoLabWasherID,
				    @PHStatusParamID,
				    @PHStatus,
				    @ShiftStartdate
			  );
		   END;
	    IF(@PHValue <> 0
		  OR @PHValue <> NULL)
		   BEGIN
			  INSERT INTO TCD.BatchParameters
			  (
				    BatchId,
				    EcolabWasherId,
				    ParameterId,
				    ParameterValue,
				    PartitionOn
			  )
			  VALUES
			  (
				    @BatchID,
				    @EcoLabWasherID,
				    @PHValueParamID,
				    @PHValue,
				    @ShiftStartdate
			  );
		   END;
	    EXEC TCD.ProcessMyControlProductionWaterConsumptionData
		    @BatchID,
		    @VxML,
		    @ShiftStartDate;
	    DROP TABLE #BatchProductData;
	    DROP TABLE #Dosing;
	    DROP TABLE #StepTime;
	    DROP TABLE #TimeStamp;

		--Start water consumption per batch

	SELECT @MeterID=MeterId,@StepComportment=MachineCompartment
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@MachineNumber
   AND mt.CounterNum = 1;


   SELECT @EnergyCount=COUNT(1) FROM TCd.BatchStepWaterUsageData bswud WHERE BatchId =@BatchID AND StepCompartment =@StepComportment AND ActualQuantity=@WaterConsumption1
    IF(@EnergyCount=0)
  BEGIN
  IF(ISNULL(@WaterConsumption1,0)>0  AND ISNULL(@MeterID,0)>0  AND ISNULL(@StepComportment,0)>0)
  BEGIN
   INSERT INTO TCD.BatchStepWaterUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
	  EcolabWasherId
     )
     SELECT
     @BatchID,
     @StepComportment,
     @WaterConsumption1,
     @ShiftStartdate,
	 @EcoLabWasherID
	 END
      END  

	 SELECT @MeterID=MeterId,@StepComportment=MachineCompartment
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@MachineNumber
   AND mt.CounterNum = 2;
SELECT @EnergyCount=COUNT(1) FROM TCd.BatchStepWaterUsageData WHERE BatchId =@BatchID AND StepCompartment =@StepComportment AND ActualQuantity=@WaterConsumption2
 IF(@EnergyCount=0)
  BEGIN
  IF(ISNULL(@WaterConsumption2,0)>0  AND ISNULL(@MeterID,0)>0  AND ISNULL(@StepComportment,0)>0)
  BEGIN
   INSERT INTO TCD.BatchStepWaterUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
	  EcolabWasherId
     )
     SELECT
     @BatchID,
     @StepComportment,
     @WaterConsumption2,
     @ShiftStartdate,
	 @EcoLabWasherID
	 END
      END   
	  --End water consumption per batch
	END;
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlConventionalData_Online]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlConventionalData_Online]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ProcessMyControlConventionalData_Online]
(
	@ControllerID   INT,
	@VxML           XML,
	@RedFlagShiftId INT OUTPUT
)
AS
	BEGIN
	    DECLARE @MachineNumber           INT,
			  @StepNumber              INT,
			  @StartDateTime           DATETIME,
			  @EndDateTime             DATETIME,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @PHValue                 INT,
			  @TemperatureMin          INT,
			  @TemperatureMax          INT,
			  @TempMinStatus           INT,
			  @TempMaxStatus           INT,
			  @BatchNumber             INT,
			  @WasherID                INT,
			  @WasherGroupID           INT,
			  @EcoLabWasherID          INT,
			  @ProgramMasterID         INT,
			  @PlantWasherNumber       INT,
			  @ShiftID                 INT,
			  @FrmParameterID          INT,
			  @PHParameterID           INT,
			  @PHParameterStatus       INT,
			  @BatchID                 INT,
			  @ShiftStartdate          DATETIME,
			  @ShiftName               NVARCHAR(50),
			  @XMLDataID               INT,
			  @TempParameter           INT,
			  @TemperatureMinParam     INT,
			  @TemperatureMaxParam     INT,
			  @TempMinStatusParam      INT,
			  @TempMaxStatusParam      INT,
			  @WashStepNo              INT,
			  @CurrencyCode            VARCHAR(50),
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @TargetTurnTime          INT,
			  @MeterID                INT,
			  @WaterConsumption1      DECIMAL(18,4),
			  @WaterConsumption2      DECIMAL(18,4),
			  @ModuleCount			  INT

	    SELECT @MachineNumber = T.c.value('@MachineNumber', 'INT'),
			 @StepNumber = T.c.value('@StepNumber', 'INT'),
			 @StartDateTime = T.c.value('@StartDateTime', 'DATETIME'),
			 @EndDateTime = T.c.value('@EndDateTime', 'DATETIME'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@NominalLoad', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'INT'),
			 @PHStatus = T.c.value('@PHStatus', 'INT'),
			 @PHValue = T.c.value('@PHValue', 'INT'),
			 @TemperatureMin = T.c.value('@TemperatureMin', 'INT'),
			 @TemperatureMax = T.c.value('@TemperatureMax', 'INT'),
			 @TempMaxStatus = T.c.value('@TemperatureMaxStatus', 'INT'),
			 @TempMinStatus = T.c.value('@TemperatreMinStatus', 'INT'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @WaterConsumption1=T.c.value('@WaterConsumption1','DECIMAL(18,4)'),
			 @WaterConsumption2=T.c.value('@WaterConsumption2','DECIMAL(18,4)')
	    FROM @VxML.nodes('MyControlConventionalData') T(C);

	    SELECT @PHParameterID = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'pH';
	    SELECT @PHParameterStatus = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'PH Status';
	    SELECT @TemperatureMinParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Mimum Temperature';
	    SELECT @TemperatureMaxParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Maximum Temperature';
	    SELECT @TempMinStatusParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Minimum Temperature Status';
	    SELECT @TempMaxStatusParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Max Temperature Status';
	    SELECT @WashStepNo = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'StepCompartment No';
	    SELECT @FrmParameterID = [Id]
	    FROM TCD.ConduitPArameters
	    WHERE Name = 'Formula Number';
	    DECLARE @ShiftMapping TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    INSERT INTO @ShiftMapping
	    (
		  ShiftId,
		  ShiftName,
		  ShiftStartdate
	    )
	    EXEC TCD.GetShiftStartDate
		    @StartDateTime
	    SELECT @ShiftID = ShiftID,
			 @ShiftStartdate = ShiftStartdate
	    FROM @ShiftMapping;
	    SELECT @WasherGroupID = GroupId,
			 @WasherID = WasherID
	    FROM TCD.MachineSetup ms
	    WHERE ControllerID = @ControllerID
			AND MachineInternalId = @MachineNumber
			AND IsTunnel = 0
			AND IsDeleted = 0;
	    IF(@EndDateTime = '1/1/1900')
		   SELECT @EndDateTime = NULL;
	    IF(@StartDateTime = '1/1/1900')
		   SELECT @StartDateTime = NULL;
	    IF(@WasherId IS NOT NULL)
		   BEGIN
			  SELECT @ProgramMasterId = Wps.ProgramId
			  FROM TCD.Washer Ws
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.ControllerID = Wg.ControllerId
				  INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.EcoLabAccountNumber
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wps.Is_Deleted = 0;
			  SELECT @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber,
				    @CurrencyCode = P.CurrencyCode,
				    @TargetTurnTime = w.TargetTurnTime * 60
			  FROM TCD.Washer w
				  INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.EcolabAccountNumber
			  WHERE w.WasherId = @WasherID;
	   END;
	    SELECT @BatchID = BatchID
	    FROM TCD.BatchData
	    WHERE MachineInternalID = @MachineNumber
			AND StartDate = @StartDateTime
			AND ControllerBatchId = @BatchNumber
			AND MachineID = @WasherID;

	    --Start Getting InjectionCount and StepCount
	    SELECT @StdInjectionSteps = COUNT(DISTINCT wdpm.
	    WasherDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) -
			 COUNT(DISTINCT wdpm.WasherDosingSetupId)
	    FROM TCD.WasherDosingProductMapping wdpm
		    RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm.
		    WasherDosingSetupId = wds.WasherDosingSetupId
	    WHERE wds.ControllerID = @ControllerID
			AND wds.ProgramNumber = @ProgramNumber;
	    --End Getting InjectionCount and StepCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramMasterId
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT @EcolabTextileCategoryId = pcp.
			  EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp.
				    ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    IF(@BatchID IS NULL)
		   BEGIN
			  INSERT INTO TCD.BatchData
			  (ControllerBatchID,
			   EcolabWasherId,
			   GroupId,
			   MachineInternalId,
			   PlantWasherNumber,
			   StartDate,
			   EndDate,
			   ProgramNumber,
			   ProgramMasterId,
			   MachineID,
			   ActualWeight,
			   StandardWeight,
			   CurrencyCode,
			   ShiftId,
			   PartitionOn,
			   StdInjectionSteps,
			   StdWashSteps,
			   EcolabTextileCategoryId,
			   ChainTextileCategoryId,
			   FormulaSegmentId,
			   EcolabSaturationId,
			   PlantProgramId,
			   EndDateFormula,
			   TargetTurnTime
			  )
			  VALUES
			  (
				    @BatchNumber,
				    @EcoLabWasherID,
				    @WasherGroupID,
				    @MachineNumber,
				    @PlantWasherNumber,
				    @StartDateTime,
				    @EndDateTime,
				    @ProgramNumber,
				    @ProgramMasterId,
				    @WasherID,
				    @Load,
				    @NominalLoad,
				    @CurrencyCode,
				    @ShiftID,
				    @ShiftStartdate,
				    @StdInjectionSteps,
				    @StdWashSteps,
				    @EcolabTextileCategoryId,
				    @ChainTextileCategoryId,
				    @FormulaSegmentId,
				    @EcolabSaturationId,
				    @PlantProgramId,
				    @EndDateTime,
				    @TargetTurnTime
			  );
			  SELECT @BatchID = SCOPE_IDENTITY();
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM TCD.BatchParameters
				 WHERE BatchId = @BatchID
					  AND ParameterID = 38
			   )
			   BEGIN
			   IF(@StdWashSteps <> 0
				 OR @StdWashSteps <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
					   BatchId,
					   EcolabWasherId,
					   ParameterId,
					   ParameterValue,
					   PartitionOn
					)
					SELECT @BatchID,
						  @EcoLabWasherID,
						  38,
						  @StdWashSteps,
						  @ShiftStartdate;
				  END
			END;

			  --End Date  Time  is Null 
			  UPDATE TCD.BatchData
			    SET
				   EndDate = GETUTCDATE()
			  WHERE MachineInternalID = @MachineNumber
				   AND StartDate <> @StartDateTime
				   AND EndDate IS NULL
				   AND ControllerBatchId <> @BatchNumber
				   AND MachineId = @WasherId;	
																  		
			  -- Program Number	
			  IF(@ProgramNumber IS NOT NULL
				AND @ProgramNumber > 0)
				 BEGIN
					IF NOT EXISTS
					(
					    SELECT *
					    FROM TCD.WasherReading
					    WHERE WasherId = @WasherID
							AND ParameterID = @FrmParameterID
							AND DateTimeStamp = @StartDateTime
					)
					    BEGIN
						   INSERT INTO TCD.WasherReading
						   (WasherID,
						    ParameterID,
						    ParameterValue,
						    DateTimeStamp,
						    EcoLabWasherID,
						    Partitionon
						   )
						   VALUES
						   (
								@WasherID,
								@FrmParameterID,
								@ProgramNumber,
								@StartDateTime,
								@EcoLabWasherID,
								@ShiftStartdate
						   );
					    END;
				 END;
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM [TCD].[BatchCustomerData]
				 WHERE BatchID = @BatchId
					  AND @CustomerNumber IS NOT NULL
			  )
				 BEGIN
					INSERT INTO [TCD].[BatchCustomerData]
					([BatchId],
					 CustomerID,
					 [Weight],
					 PartitionOn,
					 EcolabWasherId
					)
					VALUES
					(
						  @BatchID,
						  @CustomerNumber,
						  @Load,
						  @ShiftStartdate,
						  @EcolabWasherID
					);
				 END;
		   END;

	    -- PH Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @PHParameterID
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@PHValue <> 0
				OR @PHValue <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @PHParameterID,
							    @PHValue,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 
	 
	    -- PH Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @PHParameterStatus
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@PHStatus <> 0
				OR @PHStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @PHParameterStatus,
							    @PHStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Min Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TemperatureMinParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TemperatureMin <> 0
				OR @TemperatureMin <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TemperatureMinParam,
							    @TemperatureMin,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Max Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TemperatureMaxParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TemperatureMax <> 0
				OR @TemperatureMax <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TemperatureMaxParam,
							    @TemperatureMax,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Min Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TempMinStatusParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TempMinStatus <> 0
				OR @TempMinStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TempMinStatusParam,
							    @TempMinStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Max Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TempMaxStatusParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TempMaxStatus <> 0
				OR @TempMaxStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TempMaxStatusParam,
							    @TempMaxStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- StepCompartment No
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @WashStepNo
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@StepNumber <> 0
				OR @StepNumber <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @WashStepNo,
							    @StepNumber,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END;
 --Start water consumption per batch

	SELECT @MeterID=MeterId
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@MachineNumber
   AND mt.CounterNum = 1;

   SELECT @ModuleCount= COUNT(1) FROM TCD.ModuleReading WHERE Reading =@WaterConsumption1 AND ModuleId = @MeterID
  IF (@ModuleCount=0)
  BEGIN
  IF(ISNULL(@WaterConsumption1,0) > 0 AND ISNULL(@MeterID,0) > 0)
  BEGIN
   INSERT INTO TCD.ModuleReading
     (ModuleId,
      ModuleTypeId,
      Reading,
      TimeStamp
     )
     SELECT
     @MeterID,
     2,	  --Water Meter
     @WaterConsumption1,
     GETUTCDATE()
  END
 END 
 
 SELECT @MeterID=MeterId
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@MachineNumber
   AND mt.CounterNum = 2; 
 -- set  @ModuleCount=@@ROWCOUNT
  SELECT @ModuleCount= COUNT(1) FROM TCD.ModuleReading WHERE Reading =@WaterConsumption2 AND ModuleId = @MeterID
  IF (@ModuleCount=0)
  BEGIN
  IF(ISNULL(@WaterConsumption2,0) > 0 AND ISNULL(@MeterID,0) > 0)
  BEGIN
   INSERT INTO TCD.ModuleReading
     (ModuleId,
      ModuleTypeId,
      Reading,
      TimeStamp
     )
     SELECT
     @MeterID, 
     2,
     @WaterConsumption2,
     GETUTCDATE()
  END
      END   
	 --End water consumption per batch
 END;
 GO
 IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlOnlineCWStepWaterConsumptionData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlOnlineCWStepWaterConsumptionData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ProcessMyControlOnlineCWStepWaterConsumptionData]
(
@ControllerID   INT,
 @VxML       XML
) 
AS
BEGIN
DECLARE @MachineNumber   INT,
  @WasherID INT,
  @MeterID INT,
  @WasherGroupID INT,
  @StepComportmentNO INT,
  @ActualQuantity Decimal(10,6),
  @EcolabWasherId INT,
  @CurrentStepComportmentNO INT,
  @WasherModuleCount        INT

   SELECT @MachineNumber = T.c.value('@MachineNumber', 'INT')
     FROM @VxML.nodes('MyControlConventionalData') T(C);


  CREATE TABLE #StepConsumptionData
  (
      StepNo      INT,
      Qty         DECIMAL(10, 6)
  )
   INSERT INTO #StepConsumptionData 
   SELECT  T.c.value('@StepNo', 'INT'),
         T.c.value('@WCCounter1', 'Decimal(10,2)')+T.c.value('@WCCounter2', 'Decimal(10,2)')
     FROM @VxML.nodes('MyControlConventionalData/WaterConsumptionData/StepConsumption') T(C)
  WHERE T.c.value('@WCCounter1', 'Decimal(10,6)')>0 OR T.c.value('@WCCounter2', 'Decimal(10,6)')>0 ;

  --Getting WasherGroupId,WasherId from MachineSetup
   SELECT @WasherGroupID = GroupId,
    @WasherID = ms.WasherID
     FROM TCD.MachineSetup ms
       WHERE ControllerID = @ControllerID
   AND MachineInternalId = @MachineNumber
   AND IsTunnel = 0
   AND IsDeleted = 0;

   --Getting MeterId,WasherId from Meter
   SELECT @MeterID=MeterId
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@WasherID

    --Getting @EcolabWasherId from Washer
   SELECT @EcolabWasherId= wr.EcolabWasherId
   FROM TCD.Washer wr
      WHERE wr.WasherId=@WasherID

  
  SET @CurrentStepComportmentNO=1;
  WHILE(@CurrentStepComportmentNO<=25)
  BEGIN
  SELECT @StepComportmentNO=scd.StepNo,@ActualQuantity=scd.Qty
  FROM #StepConsumptionData scd where scd.StepNo=@CurrentStepComportmentNO
  SELECT @WasherModuleCount=COUNT(1) FROM TCD.WasherModuleOnlineUsageData WHERE WasherId = @WasherID AND StepComportment =@StepComportmentNO AND ModuleId = @MeterID AND ActualQuantity=@ActualQuantity 
  IF(@WasherModuleCount=0)
  BEGIN
  IF(@StepComportmentNO IS NOT NULL AND @WasherID IS NOT NULL AND @MeterID IS NOT NULL)
   INSERT INTO TCD.WasherModuleOnlineUsageData
     (WasherId,
      StepComportment,
      ModuleId,
      ActualQuantity,
      TimeStamp,
      EcolabWasherId
     )
     SELECT
     @WasherID,
     @StepComportmentNO,
     @MeterID,
     @ActualQuantity,
     GETUTCDATE(),
     @EcolabWasherId
      END  
        SET  @CurrentStepComportmentNO=@CurrentStepComportmentNO+1;
   
  END;
END;
GO
 IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlOnlineProductDosing]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlOnlineProductDosing]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ProcessMyControlOnlineProductDosing](
	@ControllerID INT,
	@VxML         XML)
AS
	BEGIN
	    DECLARE @TheoreticalQty    DECIMAL(10, 6),
			  @RealQty           DECIMAL(10, 6),
			  @BatchNumber       INT,
			  @DosingPoint       INT,
			  @DosingNumber      INT,
			  @ValveNumber       INT,
			  @ProgramNumber     INT,
			  @WasherId          INT,
			  @MachineInternalId INT,
			  @PrevRealQty       DECIMAL(10, 6),
			  @ProductId         INT,
			  @PumpNum           INT,
			  @EquipmentType     INT,
			  @CompartmentNum    INT;
	    SELECT @TheoreticalQty = T.c.value('@TheoreticalQty','Decimal(10,6)'),
			 @RealQty = T.c.value('@RealQty', 'Decimal(10,6)'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @DosingPoint = T.c.value('@DosingPoint', 'INT'),
			 @DosingNumber = T.c.value('@DoseNumber', 'INT'),
			 @PumpNum = T.c.value('@PumpNum', 'INT'),
			 @ValveNumber = T.c.value('@ValveNumber', 'INT')
	    FROM @VxML.nodes('MyControlOnlineProductDosing') T(C);
	    IF(@PumpNum >= 25
		  AND @PumpNum <= 26)
		   BEGIN
			  SET @EquipmentType = 2;
		   END;
	    ELSE
		   BEGIN
			  SET @EquipmentType = 1;
		   END;
	    IF(@DosingPoint >= 17
		  AND @DosingPoint <= 20)
		   BEGIN
			  SET @MachineInternalId = 1;
		   END;
	    ELSE
	    IF(@DosingPoint >= 21
		  AND @DosingPoint <= 24)
		   BEGIN
			  SET @MachineInternalId = 2;
		   END;
	    IF(@DosingPoint >= 1
		  AND @DosingPoint <= 16)
		   BEGIN
			  SET @MachineInternalId = @DosingPoint;
			  SELECT @WasherId = WasherId
			  FROM TCD.MachineSetup
			  WHERE ControllerID = @ControllerID
				   AND MachineInternalId = @MachineInternalId
				   AND IsTunnel = 0
				   AND IsDeleted = 0;
			  SELECT @ProductId = ProductId
			  FROM TCD.ControllerEquipmentSetup
			  WHERE ControllerEquipmentId = @PumpNum
				   AND ControllerID = @ControllerID;
		   END;
	    ELSE
	    IF(@DosingPoint >= 17
		  AND @DosingPoint <= 24)
		   BEGIN
			  SELECT @WasherId = WasherId
			  FROM TCD.MachineSetup
			  WHERE ControllerID = @ControllerID
				   AND MachineInternalId = @MachineInternalId
				   AND IsTunnel = 1
				   AND IsDeleted = 0;
			  SELECT @ProductId = CES.ProductId,
				    @CompartmentNum = TCEVM.CompartmentNumber
			  FROM tcd.ControllerEquipmentSetup CES
				  INNER JOIN TCD.
				  TunnelCompartmentEquipmentValveMapping TCEVM ON CES.
				  ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
			  WHERE CES.ControllerId = @ControllerID
				   AND CES.ControllerEquipmentTypeId = @EquipmentType
				   AND TCEVM.ValveNumber = @ValveNumber
				   AND CES.ControllerEquipmentId = @PumpNum;
		   END;
	    SELECT TOP 1 @PrevRealQty = RealQty
	    FROM TCD.WasherProductReading
	    WHERE ControllerId = @ControllerID
			AND WasherId = @WasherId
	    ORDER BY DateTimeStamp DESC;
	    IF(@ProductId IS NOT NULL)
		   BEGIN
			  IF(@PrevRealQty IS NULL
				OR @PrevRealQty != @RealQty)
				 BEGIN
					INSERT INTO [TCD].[WasherProductReading]
					(ControllerId,
					 WasherId,
					 MachineInternalId,
					 ProductId,
					 TheoreticalQty,
					 RealQty,
					 DosingPoint,
					 DosingNumber,
					 ProgramNumber,
					 BatchNumber,
					 ValveNumber,
					 DateTimeStamp
					)
						  SELECT @ControllerId,
							    @WasherId,
							    @MachineInternalId,
							    @ProductId,
							    @TheoreticalQty,
							    @RealQty,
							    @DosingPoint,
							    @DosingNumber,
							    @ProgramNumber,
							    @BatchNumber,
							    @ValveNumber,
							    GETUTCDATE();
				 END;
		   END;
	END
	GO
 IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlTunnelWasherOnlineData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlTunnelWasherOnlineData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ProcessMyControlTunnelWasherOnlineData](
	@ControllerID   INT,
	@xmlTags        XML,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @BatchID                 INT,
			  @WasherID                INT,
			  @EcolabWasherId          INT,
			  @CurrencyCode            VARCHAR(50),
			  @MachineInternalId       INT,
			  @WasherGroupID           INT,
			  @PlantWasherNumber       INT,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @BatchNumber             INT,
			  @TargetTurnTime          INT,
			  @PartitionOn             DATETIME,
			  @BatchStartTime          DATETIME,
			  @ProgramID               INT,
			  @NumberOfCompartments    INT,
			  @TransferSignalId        INT,
			  @BatchShiftId            INT,
			  @compartmentID           INT,
			  @TunnelXML               XML,
			  @TempXML                 XML,
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @CurrentStepComportmentNO INT,
               @CounterNO               INT,
               @MeterID                 INT,
              @ActualQuantity          DECIMAL(10,6),
			  @WasherModuleCount        INT

	    SELECT @TransferSignalId = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Transfer Signal';
	    CREATE TABLE #Batches
	    (
		    BatchNumber   INT,
		    StartDateTime DATETIME
	    );
	    -- SET @compartmentID = 1;

	    SELECT @TempXML = T.c.query('.')
	    FROM @xmlTags.nodes('MyControlTunnel') AS T(c);

	    SELECT @MachineInternalID = T.c.value('@MachineNumber', 'int')
	    FROM @TempXML.nodes('MyControlTunnel') AS T(c);
	    SELECT @EcolabWasherID = EcolabWasherId,
			 @WasherGroupID = Wg.WasherGroupId,
			 @PlantWasherNumber = PlantWasherNumber,
			 @WasherID = ws.WasherId,
			 @CurrencyCode = P.CurrencyCode,
			 @NumberOfCompartments = Mst.NumberofComp
	    FROM TCD.Washer AS Ws
		    INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = Ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.
		    GroupId
		    INNER JOIN TCD.WasherGroupType AS WgT ON WgT.
		    WasherGroupTypeId = Wg.WasherGroupTypeId
		    INNER JOIN TCD.ConduitController AS Ctrl ON Ctrl.
		    ControllerId = Mst.ControllerId
		    INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.
		    EcoLabAccountNumber
	    WHERE Ctrl.ControllerID = @ControllerID
			AND mst.MachineInternalId = @MachineInternalID
			AND Mst.IsTunnel = 1 AND Mst.IsDeleted =0;
	    SET @compartmentID = @NumberOfCompartments;
	    WHILE(@compartmentID <= @NumberOfCompartments
			AND @compartmentID > 0)
		   BEGIN
			  SELECT @TunnelXML = T.c.query('.')
			  FROM @xmlTags.nodes('MyControlTunnel/TunnelData') AS T(c)
			  WHERE T.c.value('@CompartmentNumber', 'INT') =
			  @compartmentID;
			  SELECT @MachineInternalID = T.c.value('@MachineNumber',
			  'int'
										    ),
				    @BatchNumber = T.c.value('@BatchNumber', 'INT'),
				    @BatchStartTime = T.c.value('@StartDateTime',
				    'DateTime'
										 ),
				    @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
				    @Load = T.c.value('@Load', 'Decimal(10,6)'),
				    @NominalLoad = T.c.value('@Nominalload',
				    'Decimal(10,6)'
									   ),
				    @CustomerNumber = T.c.value('@CustomerNumber',
				    'int'
										 ),
				    @PHStatus = T.c.value('@pHStatus', 'int')
			  FROM @TunnelXML.nodes('TunnelData') AS T(c);

			  DECLARE @ShiftStartDateTemp TABLE
			  (
				  ShiftId        INT,
				  ShiftName      NVARCHAR(50),
				  ShiftStartdate DATETIME
			  );
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchStartTime
			  SELECT @BatchShiftId = ShiftID,
				    @PartitionOn = ShiftStartdate
			  FROM @ShiftStartDateTemp;
			  IF(@ProgramNumber = 0
				OR @BatchNumber = 1)
				 BEGIN
					SELECT @compartmentID = @compartmentID - 1;
					CONTINUE;
				 END;
			  SELECT @ProgramID = ProgramId,
				    @TargetTurnTime = 3600 / (tps.TotalRunTime /
				    @NumberOfCompartments)
			  FROM TCD.TunnelProgramSetup AS tps
			  WHERE tps.WasherGroupId = @WasherGroupID
				   AND tps.is_deleted = 0
				   AND ProgramNumber = @ProgramNumber;
			  INSERT INTO #Batches
			  (BatchNumber,
			   StartDateTime
			  )
				    SELECT @BatchNumber,
						 @BatchStartTime;
			  SELECT @BatchID = NULL;
			  SELECT @BatchID = BatchID
			  FROM TCD.BatchData AS BD
			  WHERE BD.ControllerBatchId = @BatchNumber
				   AND BD.StartDate = @BatchStartTime
				   AND BD.MachineId = @WasherID;
			  --Start Getting InjectionCount,StepCount And ProductCount
			  SELECT @StdInjectionSteps = COUNT(tdpm.
			  TunnelDosingSetupId),
				    @StdWashSteps = COUNT(DISTINCT tds.
				    TunnelDosingSetupId) - COUNT(tdpm.
				    TunnelDosingSetupId)
			  FROM tcd.TunnelDosingProductMapping AS tdpm
				  RIGHT JOIN tcd.TunnelDosingSetup AS tds ON tdpm.
				  TunnelDosingSetupId = tds.TunnelDosingSetupId
			  WHERE tds.GroupId = @WasherGroupID
				   AND tds.ProgramNumber = @ProgramNumber;
			  --End Getting InjectionCount,StepCount And ProductCount
			  --Start-----ProgramMasterID logic for PlantChainProgram
			  SELECT @PlantProgramId = pm.PlantProgramId,
				    @EcolabTextileCategoryId = pm.
				    EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pm.ChainTextileId,
				    @FormulaSegmentId = pm.FormulaSegmentId,
				    @EcolabSaturationId = pm.EcolabSaturationId
			  FROM TCD.ProgramMaster AS pm
			  WHERE pm.ProgramId = @ProgramID
				   AND pm.Is_Deleted = 0;
			  IF(@PlantProgramId <> 0
				OR @PlantProgramId IS NOT NULL)
				 BEGIN
					--Assign value from plantchainprogram table based on plantprogramId
					SELECT @EcolabTextileCategoryId = pcp.
					EcolabTextileCategoryId,
						  @ChainTextileCategoryId = pcp.
						  ChainTextileCategoryId,
						  @FormulaSegmentId = pcp.FormulaSegmentId,
						  @EcolabSaturationId = pcp.
						  EcolabSaturationId
					FROM tcd.PlantChainProgram AS pcp
					WHERE pcp.PlantProgramId = @PlantProgramId
						 AND pcp.Is_Deleted = 0;
				 END;
			  --End-----ProgramMasterID logic for PlantChainProgram
			  IF @BatchID IS NULL
				 BEGIN
					INSERT INTO TCD.BatchData
					(ControllerBatchId,
					 EcolabWasherId,
					 GroupId,
					 MachineInternalId,
					 PlantWasherNumber,
					 StartDate,
					 ProgramNumber,
					 ProgramMasterId,
					 MachineId,
					 ActualWeight,
					 StandardWeight,
					 CurrencyCode,
					 ShiftId,
					 PartitionOn,
					 TargetTurnTime,
					 StdInjectionSteps,
					 StdWashSteps,
					 EcolabTextileCategoryId,
					 ChainTextileCategoryId,
					 FormulaSegmentId,
					 EcolabSaturationId,
					 PlantProgramId
					)
						  SELECT @BatchNumber,
							    @EcolabWasherID,
							    @WasherGroupID,
							    @MachineInternalID,
							    @PlantWasherNumber,
							    @BatchStartTime,
							    @ProgramNumber,
							    @ProgramID,
							    @WasherID,
							    @Load,
							    @NominalLoad,
							    @CurrencyCode,
							    @BatchShiftId,
							    @PartitionOn,
							    @TargetTurnTime,
							    @StdInjectionSteps,
							    @StdWashSteps,
							    @EcolabTextileCategoryId,
							    @ChainTextileCategoryId,
							    @FormulaSegmentId,
							    @EcolabSaturationId,
							    @PlantProgramId;
					SELECT @BatchID = SCOPE_IDENTITY();
					IF(@StdWashSteps > 0
					   OR @StdWashSteps <> NULL)
					    BEGIN
						   INSERT INTO TCD.BatchParameters
						   (BatchId,
						    EcolabWasherId,
						    ParameterId,
						    ParameterValue,
						    PartitionOn
						   )
								SELECT @BatchID,
									  @EcolabWasherId,
									  38,
									  @StdWashSteps,
									  @PartitionOn;
					    END;
					IF @CustomerNumber IS NOT NULL
					    BEGIN
						   IF NOT EXISTS
						   (
							  SELECT 1
							  FROM TCD.BatchCustomerData
							  WHERE BatchID = @BatchID
						   )
							  BEGIN
								 INSERT INTO TCD.BatchCustomerData
								 (BatchId,
								  CustomerID,
								  Weight,
								  PartitionOn,
								  EcolabWasherId
								 )
									   SELECT @BatchID,
											@CustomerNumber,
											@Load,
											@PartitionOn,
											@EcolabWasherId;
							  END;
					    END;
				 END;
			  -- Transfer Signal
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM tcd.WasherReading wr
				 WHERE wr.WasherId = @WasherID
					  AND wr.ParameterId = @TransferSignalId
					  AND wr.DateTimeStamp = @BatchStartTime
			  )
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterId,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TransferSignalId,
							    1,
							    @BatchStartTime,
							    @PartitionOn,
							    @EcolabWasherId
						  UNION ALL
						  SELECT @WasherID,
							    @TransferSignalId,
							    0,
							    @BatchStartTime,
							    @PartitionOn,
							    @EcolabWasherId;
				 END;
			  --Start Updating Batch Wash Step Data	 
			  EXEC TCD.UPDATEBatchWashStepForTunnel
				  @TunnelXML,
				  @WasherID,
				  @BatchID,
				  @BatchStartTime,
				  @PartitionOn,
				  @EcolabWasherId,
				  @compartmentID;
			  --End Updating Batch Wash Step Data	 
			  SELECT @compartmentID = @compartmentID - 1;
		   END;


	 --Start water consumption per step


   CREATE TABLE #WaterConsumptionData
     (
      Number          INT,
      Quantity        DECIMAL(10,6),
     );
     INSERT INTO #WaterConsumptionData
     (Number,
  Quantity
     )
    SELECT T.c.value('@Counter', 'INT') AS Number, --PumpNumber
       T.c.value('@Value', 'DECIMAL(10,6)') AS Quantity --Water Quanity
    FROM @xmlTags.nodes('MyControlTunnel/TunnelData/WaterConsumption') T(C);

  SET @CurrentStepComportmentNO=1;
  WHILE(@CurrentStepComportmentNO<=22)
  BEGIN
   SELECT @MeterID=MeterId,@CounterNO=mt.CounterNum
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@CurrentStepComportmentNO;
   SELECT @ActualQuantity=wc.Quantity
  FROM #WaterConsumptionData wc where wc.Number=@CounterNO
  SELECT @WasherModuleCount=COUNT(1) FROM TCD.WasherModuleOnlineUsageData WHERE WasherId = @WasherID AND StepComportment =@CurrentStepComportmentNO AND ModuleId = @MeterID AND ActualQuantity=@ActualQuantity
  IF(@WasherModuleCount=0)
  BEGIN
  IF(ISNULL(@WasherID,0)>0 AND ISNULL(@MeterID,0)>0 AND ISNULL(@ActualQuantity,0)>0 AND ISNULL(@CurrentStepComportmentNO,0)>0)
  BEGIN
   INSERT INTO TCD.WasherModuleOnlineUsageData
     (WasherId,
      StepComportment,
      ModuleId,
      ActualQuantity,
      TimeStamp,
      EcolabWasherId
     )
     SELECT
     @WasherID,
     @CurrentStepComportmentNO,
     @MeterID,
     @ActualQuantity,
     GETUTCDATE(),
     @EcolabWasherId
      END  

	  END
        SET  @CurrentStepComportmentNO=@CurrentStepComportmentNO+1;
   
  END;
 END;
 GO
  IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlTunnelWasherProdData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlTunnelWasherProdData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ProcessMyControlTunnelWasherProdData](
	@ControllerID   INT,
	@xmlTags        XML,
	@PLCPointer     INT,
	@ReadPointer    INT,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @BatchID                   INT,
			  @WasherID                  INT,
			  @EcolabWasherId            INT,
			  @CurrencyCode              VARCHAR(50),
			  @MachineInternalId         INT,
			  @WasherGroupID             INT,
			  @PlantWasherNumber         INT,
			  @ProgramNumber             INT,
			  @Load                      DECIMAL(10, 2),
			  @NominalLoad               DECIMAL(10, 2),
			  @CustomerNumber            INT,
			  @PHStatus                  INT,
			  @PHValue                   INT,
			  @LFStatus                  INT,
			  @LFValue                   INT,
			  @BatchNumber               INT,
			  @TargetTurnTime            INT,
			  @PartitionOn               DATETIME2,
			  @BatchStartTime            DATETIME2,
			  @BatchEndTime              DATETIME2,
			  @ProgramID                 INT,
			  @NumberOfCompartments      INT,
			  @ProductId                 INT,
			  @CompartmentNum            INT,
			  @EquipmentType             INT,
			  @MinTempParamID            INT,
			  @MaxTempParamID            INT,
			  @TempStatusParamID         INT,
			  @PHValueParamID            INT,
			  @PHStatusParamID           INT,
			  @ConductivityValueParamID  INT,
			  @ConductivityStatusParamID INT,
			  @StdInjectionSteps         INT,
			  @StdWashSteps              INT,
			  @ActualInjSteps            INT,
			  @EcolabTextileCategoryId   INT,
			  @ChainTextileCategoryId    INT,
			  @FormulaSegmentId          INT,
			  @EcolabSaturationId        INT,
			  @PlantProgramId            INT,
			  @PreviousShiftId		    INT,
			  @CurrentShiftId		    INT,
			  @CurrentStepComportmentNO INT,
              @CounterNO                INT,
               @MeterID                 INT,
              @ActualQuantity          DECIMAL(10,6),
			  @BatchStepCount         INT
	    DECLARE @BatchShiftId INT;
	    DECLARE @ShiftStartDateTemp TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    DECLARE @TunnelXML XML;
	    SELECT @TunnelXML = T.c.query('.')
	    FROM @xmlTags.nodes('MyControlTunnel/TunnelData') T(c)
	    WHERE T.c.value('@CompartmentNumber', 'INT') = 0;

		
	    SELECT @MachineInternalID = T.c.value('@MachineNumber', 'int'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @BatchStartTime = T.c.value('@StartDateTime', 'DateTime'),
			 @BatchEndTime = T.c.value('@EndDateTime', 'DateTime'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@Nominalload', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'int'),
			 @PHStatus = T.c.value('@Phstatus', 'int'),
			 @PHValue = T.c.value('@Phvalue', 'INT'),
			 @LFStatus = T.c.value('@LFStatus', 'INT'),
			 @LFValue = T.c.value('@LFValue', 'INT')
	    FROM @xmlTags.nodes('MyControlTunnel/TunnelData') T(c);

	    SELECT @EcolabWasherID = Ws.EcolabWasherId,
			 @WasherGroupID = Wg.WasherGroupId,
			 @PlantWasherNumber = PlantWasherNumber,
			 @WasherID = ws.WasherId,
			 @CurrencyCode = P.CurrencyCode,
			 @NumberOfCompartments = Mst.NumberofComp
	    FROM TCD.Washer Ws
		    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.
		    GroupId
		    INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId
		    = Wg.WasherGroupTypeId
		    INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId =
		    Mst.ControllerId
		    INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.
		    EcoLabAccountNumber
	    WHERE Ctrl.ControllerID = @ControllerID
			AND Mst.MachineInternalId = @MachineInternalID
			AND Mst.IsTunnel = 1 AND Mst.IsDeleted=0;
	    SELECT @EcolabWasherID;
	    SELECT @ProgramID = ProgramId,
			 @TargetTurnTime = (3600 / (tps.TotalRunTime /
			 @NumberOfCompartments))
	    FROM TCD.TunnelProgramSetup AS tps
	    WHERE tps.WasherGroupId = @WasherGroupID
			AND tps.is_deleted = 0
			AND ProgramNumber = @ProgramNumber;
	    DELETE FROM @ShiftStartDateTemp;
	    IF(@BatchEndTime IS NOT NULL)
		   BEGIN
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchEndTime
		   END;
	    ELSE
		   BEGIN
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchStartTime
		   END;
	    SELECT @BatchShiftId = ShiftID,
			 @PartitionOn = ShiftStartdate
	    FROM @ShiftStartDateTemp;


	    --Start Getting InjectionCount,StepCount And ProductCount
	    SELECT @StdInjectionSteps = COUNT(tdpm.TunnelDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT tds.TunnelDosingSetupId) -
			 COUNT(tdpm.TunnelDosingSetupId)
	    FROM tcd.TunnelDosingProductMapping tdpm
		    RIGHT JOIN tcd.TunnelDosingSetup tds ON tdpm.
		    TunnelDosingSetupId = tds.TunnelDosingSetupId
	    WHERE tds.GroupId = @WasherGroupID
			AND tds.ProgramNumber = @ProgramNumber;
	    --End Getting InjectionCount,StepCount And ProductCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramID
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT @EcolabTextileCategoryId = pcp. EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp. ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    SELECT @BatchID = NULL;
	    SELECT @BatchID = BatchID
	    FROM TCD.BatchData BD
	    WHERE BD.ControllerBatchId = @BatchNumber
			AND BD.StartDate = @BatchStartTime
			AND BD.MachineId = @WasherID;
	    --AND BD.MachineInternalID = @MachineInternalID
	    IF(@BatchID IS NULL)
		   BEGIN
		   --Start Rollup for previous completed shift
	   IF(CAST(@BatchStartTime as date) < CAST(GETUTCDATE() as date))
	   BEGIN
		  SELECT TOP 1 @PreviousShiftId=ShiftId FROM TCD.BatchData WHERE MachineId=@WasherId ORDER BY StartDate DESC	   
		  SELECT Top 1 @CurrentShiftId = ShiftId from @ShiftStartDateTemp
		  IF(@CurrentShiftId != @PreviousShiftId)
		  BEGIN
			 EXEC TCD.ProductionShiftDataRollup @PreviousShiftId, @RedFlagShiftId OUTPUT
			 IF(@RedFlagShiftId IS NULL)
			 BEGIN
				SET @RedFlagShiftId = @PreviousShiftId
			 END
		  END
	   END
	   --End Rollup for previous completed shift
			  INSERT INTO TCD.BatchData
			  (ControllerBatchId,
			   EcolabWasherId,
			   GroupId,
			   MachineInternalId,
			   PlantWasherNumber,
			   StartDate,
			   EndDate,
			   ProgramNumber,
			   ProgramMasterId,
			   MachineId,
			   ActualWeight,
			   StandardWeight,
			   CurrencyCode,
			   ShiftId,
			   PartitionOn,
			   TargetTurnTime,
			   StdInjectionSteps,
			   StdWashSteps,
			   EcolabTextileCategoryId,
			   ChainTextileCategoryId,
			   FormulaSegmentId,
			   EcolabSaturationId,
			   PlantProgramId,
			   EndDateFormula
			  )
				    SELECT @BatchNumber,
						 @EcolabWasherID,
						 @WasherGroupID,
						 @MachineInternalID,
						 @PlantWasherNumber,
						 @BatchStartTime,
						 @BatchEndTime,
						 @ProgramNumber,
						 @ProgramID,
						 @WasherID,
						 @Load,
						 @NominalLoad,
						 @CurrencyCode,
						 @BatchShiftId,
						 @PartitionOn,
						 @TargetTurnTime,
						 @StdInjectionSteps,
						 @StdWashSteps,
						 @EcolabTextileCategoryId,
						 @ChainTextileCategoryId,
						 @FormulaSegmentId,
						 @EcolabSaturationId,
						 @PlantProgramId,
						 @BatchEndTime;
			  SELECT @BatchID = SCOPE_IDENTITY();
			  IF(@StdWashSteps > 0
				OR @StdWashSteps <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchID,
							@EcolabWasherId,
							38,
							@StdWashSteps,
							@PartitionOn;
			  EXEC TCD.UPDATEBatchWashStepForTunnel
				  @TunnelXML,
				  @WasherID,
				  @BatchID,
				  @BatchStartTime,
				  @PartitionOn,
				  @EcolabWasherId,
				  @NumberOfCompartments;
		   END;
	    IF(@BatchEndTime IS NOT NULL
		  AND @BatchEndTime != '01/01/1900')
		   BEGIN
			  UPDATE TCD.BatchData
			    SET
				   EndDate = @BatchEndTime,
				   ShiftId = @BatchShiftId,
				   PartitionOn = @PartitionOn,
				   EndDateFormula=@BatchEndTime
			  WHERE BATCHID = @BatchID;
		   END;
	    IF(@CustomerNumber IS NOT NULL)
		   BEGIN
			  IF NOT EXISTS
			  (
				 SELECT 1
				 FROM [TCD].[BatchCustomerData]
				 WHERE BatchID = @BatchID
			  )
				 BEGIN
					INSERT INTO [TCD].[BatchCustomerData]
					([BatchId],
					 CustomerID,
					 [Weight],
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @BatchID,
							    @CustomerNumber,
							    @Load,
							    @PartitionOn,
							    @EcolabWasherId;
				 END;
		   END;
	    CREATE TABLE #DosingDetails
	    (
		    Number          INT,
		    Quantity        DECIMAL(10, 6),
		    Point           INT,
		    IsMainEquioment INT
	    );
	    INSERT INTO #DosingDetails
	    (Number,
		Quantity,
		Point,
		IsMainEquioment
	    )
			 SELECT T.c.value('@Number', 'INT') AS Number, --PumpNumber
				   T.c.value('@Quantity', 'Decimal(10,6)') AS Quantity, --Dosing Quanity
				   T.c.value('@Point', 'INT') AS Point, --Dosing point
				   T.c.value('@IsMainEquioment', 'INT') AS
			 IsMainEquioment
			 FROM @xmlTags.nodes('MyControlTunnel/TunnelData/Dose') T(C)
	    ;
	
	    -- Fetching data from cursor
	    DECLARE @MYCURSOR CURSOR;
	    SET @MYCURSOR = CURSOR FAST_FORWARD
	    FOR SELECT Number,
				Quantity,
				Point,
				IsMainEquioment
		   FROM #DosingDetails;
	    DECLARE @Number          INT,
			  @Quantity        DECIMAL(10, 6),
			  @Point           INT,
			  @IsMainEquioment INT;
	    OPEN @MYCURSOR;
	    FETCH NEXT FROM @MYCURSOR INTO @Number,
								@Quantity,
								@Point,
								@IsMainEquioment;
	    WHILE @@FETCH_STATUS = 0
		   BEGIN
			  IF(@IsMainEquioment = 1)
				 BEGIN
					SET @EquipmentType = 2;
				 END;
			  ELSE
				 BEGIN
					SET @EquipmentType = 1;
				 END;
			  SELECT @ProductId = CES.ProductId,
				    @CompartmentNum = TCEVM.CompartmentNumber
			  FROM tcd.ControllerEquipmentSetup CES
				  INNER JOIN TCD.
				  TunnelCompartmentEquipmentValveMapping TCEVM ON CES.
				  ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
			  WHERE CES.ControllerId = @ControllerID
				   AND CES.ControllerEquipmentTypeId = @EquipmentType
				   AND --CES.IsActive=1 AND
				   --CES.WasherGroupNumber=@WasherGroupNum AND
				   TCEVM.DosingPointNumber = @Point
				   AND CES.ControllerEquipmentId = @Number;
				
			  --SELECT @EcolabWasherID
			  IF(@ProductId IS NOT NULL)
				 BEGIN
					INSERT INTO TCD.BatchProductData
					(BatchId,
					 StepCompartment,
					 ActualQuantity,
					 [TimeStamp],
					 PartitionOn,
					 EcolabWasherId,
					 ProductId
					)
						  SELECT @BatchID,
							    @CompartmentNum,
							    @Quantity,
							    @BatchEndTime,
							    @PartitionOn,
							    @EcolabWasherID,
							    @ProductId;
				 END;
			  FETCH NEXT FROM @MYCURSOR INTO @Number,
									   @Quantity,
									   @Point,
									   @IsMainEquioment;
		   END;
	    CLOSE @MYCURSOR;
	    DEALLOCATE @MYCURSOR;
	    DROP TABLE #DosingDetails;
	    SELECT @ActualInjSteps = COUNT(DISTINCT StepCompartment)
	    FROM TCD.BatchProductData
	    WHERE BatchId = @BatchID;
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.BatchParameters
		   WHERE ParameterId = 37
			    AND batchid = @BatchID
			    AND @ActualInjSteps > 0
	    )
		   BEGIN
			  IF(@ActualInjSteps > 0
				OR @ActualInjSteps <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchId,
							@EcolabWasherId,
							37,
							@ActualInjSteps,
							@PartitionOn;
		   END;
	    ELSE
		   BEGIN
			  UPDATE TCD.BatchParameters
			    SET
				   ParameterValue = @ActualInjSteps
			  WHERE ParameterId = 37
				   AND batchid = @BatchID;
		   END;
	    SELECT @MinTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Mimum Temperature';
	    SELECT @MaxTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Maximum Temperature';
	    SELECT @TempStatusParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Temperature Status';
	    SELECT @PHValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH';
	    SELECT @PHStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH Status';
	    SELECT @ConductivityValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Conductivity';
	    SELECT @ConductivityStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'LF Status';
	    IF(@PHValue IS NOT NULL)
		   BEGIN
			  --pH Value
			  IF(@PHValue <> 0
				OR @PHValue <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @PHValueParamID,
					   @PHValue,
					   @PartitionOn
				 );

			  --pH Status
			  IF(@PHStatus <> 0
				OR @PHStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @PHStatusParamID,
					   @PHStatus,
					   @PartitionOn
				 );
		   END;
	    IF(@LFValue IS NOT NULL)
		   BEGIN
			  --Conductivity Value
			  IF(@LFValue <> 0
				OR @LFValue <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @ConductivityValueParamID,
					   @LFValue,
					   @PartitionOn
				 );

			  --Conductivity Status
			  IF(@LFStatus <> 0
				OR @LFStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @ConductivityStatusParamID,
					   @LFStatus,
					   @PartitionOn
				 );
		   END;
	    CREATE TABLE #TemperatureDetails
	    (
		    MinimumTemp DECIMAL(10, 2),
		    MaximumTemp DECIMAL(10, 2),
		    TempStatus  DECIMAL(10, 2)
	    );
	    INSERT INTO #TemperatureDetails
	    (MinimumTemp,
		MaximumTemp,
		TempStatus
	    )
			 SELECT T.c.value('@Minimum', 'Decimal(10,2)') AS
			 MinimumTemp,
				   T.c.value('@Maximum', 'Decimal(10,2)') AS
				   MaximumTemp,
				   T.c.value('@Status', 'Decimal(10,2)') AS TempStatus
			 FROM @xmlTags.nodes(
			 'MyControlTunnel/TunnelData/TemperatureData'
							) T(c);
	  
	    -- Fetching data from cursor
	    DECLARE @TEMPCURSOR CURSOR;
	    SET @TEMPCURSOR = CURSOR FAST_FORWARD
	    FOR SELECT MinimumTemp,
				MaximumTemp,
				TempStatus
		   FROM #TemperatureDetails;
	    DECLARE @MinimumTemp DECIMAL(10, 2),
			  @MaximumTemp DECIMAL(10, 2),
			  @TempStatus  DECIMAL(10, 2);
	    OPEN @TEMPCURSOR;
	    FETCH NEXT FROM @TEMPCURSOR INTO @MinimumTemp,
								  @MaximumTemp,
								  @TempStatus;
	    WHILE @@FETCH_STATUS = 0
		   BEGIN	
			  --Minimum Temperature
			  IF(@MinimumTemp <> 0
				OR @MinimumTemp <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @MinTempParamID,
					   @MinimumTemp,
					   @PartitionOn
				 );

			  --Maximum Temperature
			  IF(@MaximumTemp <> 0
				OR @MaximumTemp <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @MaxTempParamID,
					   @MaximumTemp,
					   @PartitionOn
				 );

			  --Temperature Status
			  IF(@TempStatus <> 0
				OR @TempStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @TempStatusParamID,
					   @TempStatus,
					   @PartitionOn
				 );
			  FETCH NEXT FROM @TEMPCURSOR INTO @MinimumTemp,
										@MaximumTemp,
										@TempStatus;
		   END;
	    CLOSE @TEMPCURSOR;
	    DEALLOCATE @TEMPCURSOR;
	    DROP TABLE #TemperatureDetails;
	    UPDATE TCD.BatchWashStepData
		 SET
			EndTime = DATEADD(ss,
						  (SELECT T.c.value('@Time', 'INT')
							 FROM @TunnelXML.nodes('TunnelData/CompartmentTime') T(c)
							 WHERE T.c.value('@CompartmentNo','INT') =
							 (
								SELECT
									  bwsd.StepCompartment
								FROM tcd.BatchWashStepData bwsd
								WHERE bwsd.BatchId = @BatchID
									 AND bwsd.EndTime IS NULL
							 )
						  ),
						  (
							 SELECT
								   bwsd.StartTime
							 FROM tcd.BatchWashStepData bwsd
							 WHERE bwsd.BatchId = @BatchID
								  AND bwsd.EndTime IS NULL
						  ))
	    WHERE
			BatchId = @BatchID
			AND EndTime IS NULL;
   
   --Start water consumption per batch


    CREATE TABLE #WaterConsumptionData
     (
      Number          INT,
      Quantity        DECIMAL(10,6),
     );
     INSERT INTO #WaterConsumptionData
     (Number,
  Quantity
     )
    SELECT T.c.value('@Counter', 'INT') AS Number, --PumpNumber
       T.c.value('@Value', 'DECIMAL(10,6)') AS Quantity --Water Quanity
    FROM @xmlTags.nodes('MyControlTunnel/TunnelData/WaterConsumption') T(C);

  
  SET @CurrentStepComportmentNO=1;

  WHILE(@CurrentStepComportmentNO<=22)
  BEGIN
  
   SELECT @MeterID=MeterId,@CounterNO=mt.CounterNum
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@CurrentStepComportmentNO

    SELECT @ActualQuantity=wc.Quantity
  FROM #WaterConsumptionData wc where wc.Number=@CounterNo
  SELECT @BatchStepCount=COUNT(1) FROM TCD.BatchStepWaterUsageData WHERE BatchId=@BatchID  AND StepCompartment =@CurrentStepComportmentNO AND ActualQuantity=@ActualQuantity 
  IF (@BatchStepCount=0)
  BEGIN
  IF(ISNULL(@BatchID,0)>0  AND ISNULL(@MeterID,0)>0 AND ISNULL(@ActualQuantity,0)>0)
  BEGIN

   INSERT INTO TCD.BatchStepWaterUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
      EcolabWasherId
     )
     SELECT
     @BatchID,
     @CurrentStepComportmentNO,
     @ActualQuantity,
     @PartitionOn,
     @EcolabWasherId
      END 
	  END 
      SET  @CurrentStepComportmentNO=@CurrentStepComportmentNO+1;  
  END;
 END;
 GO
----------------------------------------------END PLCXML Data Delection------------------------------------------------
----------------------------------------------Start Added non formula alarm data for conventional and tunnel prod-------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlConventionalData_CompletedBatches]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlConventionalData_CompletedBatches]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessMyControlConventionalData_CompletedBatches](
	@ControllerID   INT,
	@VxML           XML,
	@PLCPointer     INT,
	@ReadPointer    INT,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @MachineNumber           INT,
			  @StartDateTime           DATETIME,
			  @EndDateTime             DATETIME,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @PHValue                 INT,
			  @TemperatureMin          INT,
			  @TemperatureMax          INT,
			  @TempMinStatus           INT,
			  @TempMaxStatus           INT,
			  @BatchNumber             INT,
			  @WasherID                INT,
			  @WasherGroupID           INT,
			  @EcoLabWasherID          INT,
			  @ProgramMasterID         INT,
			  @PlantWasherNumber       INT,
			  @ShiftID                 INT,
			  @BatchID                 INT,
			  @ShiftStartdate          DATETIME,
			  @LastStep                INT,
			  @CurrentStep             INT,
			  @CurrentStepTime         DATETIME,
			  @MinTempParamID          INT,
			  @MaxTempParamID          INT,
			  @MinTempStatuParamID     INT,
			  @MaxTempStatusParamID    INT,
			  @PHStatusParamID         INT,
			  @PHValueParamID          INT,
			  @CurrencyCode            VARCHAR(50),
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @ActualInjSteps          INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @TargetTurnTime          INT,
			  @PreviousShiftId         INT,
			  @CurrentShiftId          INT,
			  @MeterID                 INT,
			  @StepComportment         INT,
			  @Stepno                  INT,
			  @quantity                INT,
			  @productid               INT,
			  @Price                   DECIMAL(18, 4),
			  @StandardQty             DECIMAL(18, 4),
			  @TimeStamp               DATETIME2(7),
			  @MaxWashertGroupCapacity INT,
			  @InjectionNumber         INT,
			  @WaterConsumption1       DECIMAL(10,6),
			  @WaterConsumption2       DECIMAL(10,6),
			  @EnergyCount             INT,
			   @EcolabAccountNumber    INT,
	           @AlarmGroupMasterId     INT
	    SELECT
			 @MachineNumber = T.c.value('@MachineNumber', 'INT'),
			 @StartDateTime = T.c.value('@StartDateTime', 'DateTime'),
			 @EndDateTime = T.c.value('@EndDateTime', 'DateTime'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@NominalLoad', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'INT'),
			 @PHStatus = T.c.value('@PHStatus', 'INT'),
			 @PHValue = T.c.value('@PHValue', 'INT'),
			 @TemperatureMin = T.c.value('@TemperatureMin', 'INT'),
			 @TemperatureMax = T.c.value('@TemperatureMax', 'INT'),
			 @TempMaxStatus = T.c.value('@TemperatureMaxStatus', 'INT'),
			 @TempMinStatus = T.c.value('@TemperatreMinStatus', 'INT'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @WaterConsumption1 = T.c.value('@WaterConsumption1','DECIMAL(10,6)'),
			 @WaterConsumption2 = T.c.value('@WaterConsumption2','DECIMAL(10,6)')
	    FROM @VxML.nodes('MyControlConventionalData') T(C);

	    DECLARE @ShiftMapping TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    INSERT INTO @ShiftMapping
	    (
			 ShiftId,
			 ShiftName,
			 ShiftStartdate
	    )
	    EXEC TCD.GetShiftStartDate
		    @StartDateTime;
	    SELECT
			 @ShiftID = ShiftID,
			 @ShiftStartdate = ShiftStartdate
	    FROM @ShiftMapping;
	    SELECT
			 @WasherGroupID = GroupId,
			 @WasherID = WasherID
	    FROM TCD.MachineSetup ms
	    WHERE ControllerID = @ControllerID
			AND MachineInternalId = @MachineNumber
			AND IsTunnel = 0
			AND IsDeleted = 0;
	    IF(@WasherId IS NOT NULL)
		   BEGIN
			  SELECT
				    @ProgramMasterId = Wps.ProgramId
			  FROM TCD.Washer Ws
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws
				  .WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =
				  Mst.GroupId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.
				  ControllerID = Wg.ControllerId
				  INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber =
				  Ws.EcoLabAccountNumber
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wps.Is_Deleted = 0;
			  SELECT
				    @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber,
				    @CurrencyCode = P.CurrencyCode,
				    @TargetTurnTime = w.TargetTurnTime * 60
			  FROM TCD.Washer w
				  INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.
				  EcolabAccountNumber
			  WHERE w.WasherId = @WasherID;
		   END;
	    SELECT
			 @BatchID = BatchID
	    FROM TCD.BatchData
	    WHERE MachineInternalID = @MachineNumber
			AND StartDate = @StartDateTime
			AND ControllerBatchId = @BatchNumber
			AND MachineID = @WasherID;

	    --Start Getting InjectionCount and StepCount

	    SELECT
			 @StdInjectionSteps = COUNT(DISTINCT wdpm.
			 WasherDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) -
			 COUNT(DISTINCT wdpm.WasherDosingSetupId)
	    FROM TCD.WasherDosingProductMapping wdpm
		    RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm.
		    WasherDosingSetupId = wds.WasherDosingSetupId
	    WHERE wds.ControllerID = @ControllerID
			AND wds.ProgramNumber = @ProgramNumber;

	    --End Getting InjectionCount and StepCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT
			 @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramMasterId
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT
				    @EcolabTextileCategoryId = pcp.
				    EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp.
				    ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    IF(@BatchID IS NULL)
		   BEGIN

			  --Start Rollup for previous completed shift
			  IF(CAST(@StartDateTime AS DATE) < CAST(GETUTCDATE() AS
			  DATE))
				 BEGIN
					SELECT TOP 1
						  @PreviousShiftId = ShiftId
					FROM TCD.BatchData
					WHERE MachineId = @WasherId
					ORDER BY
						    StartDate DESC;
					SELECT TOP 1
						  @CurrentShiftId = ShiftId
					FROM @ShiftMapping;
					IF(@CurrentShiftId != @PreviousShiftId)
					    BEGIN
						   EXEC TCD.ProductionShiftDataRollup
							   @PreviousShiftId,
							   @RedFlagShiftId OUTPUT;
						   IF(@RedFlagShiftId IS NULL)
							  BEGIN
								 SET @RedFlagShiftId =
								 @PreviousShiftId;
							  END;
					    END;
				 END;
			  --End Rollup for previous completed shift

			  INSERT INTO TCD.BatchData
			  (
				    ControllerBatchID,
				    EcolabWasherId,
				    GroupId,
				    MachineInternalId,
				    PlantWasherNumber,
				    StartDate,
				    EndDate,
				    ProgramNumber,
				    ProgramMasterId,
				    MachineID,
				    ActualWeight,
				    StandardWeight,
				    CurrencyCode,
				    ShiftId,
				    PartitionOn,
				    StdInjectionSteps,
				    StdWashSteps,
				    EcolabTextileCategoryId,
				    ChainTextileCategoryId,
				    FormulaSegmentId,
				    EcolabSaturationId,
				    PlantProgramId,
				    EndDateFormula,
				    TargetTurnTime
			  )
			  VALUES
			  (
				    @BatchNumber,
				    @EcoLabWasherID,
				    @WasherGroupID,
				    @MachineNumber,
				    @PlantWasherNumber,
				    @StartDateTime,
				    @EndDateTime,
				    @ProgramNumber,
				    @ProgramMasterId,
				    @WasherID,
				    @Load,
				    @NominalLoad,
				    @CurrencyCode,
				    @ShiftID,
				    @ShiftStartdate,
				    @StdInjectionSteps,
				    @StdWashSteps,
				    @EcolabTextileCategoryId,
				    @ChainTextileCategoryId,
				    @FormulaSegmentId,
				    @EcolabSaturationId,
				    @PlantProgramId,
				    @EndDateTime,
				    @TargetTurnTime
			  );
			  SELECT
				    @BatchID = SCOPE_IDENTITY();
			  IF NOT EXISTS
			  (
				 SELECT
					   *
				 FROM TCD.BatchParameters
				 WHERE BatchId = @BatchID
					  AND ParameterID = 38
			  )
				 BEGIN
					IF(@StdWashSteps > 0
					   OR @StdWashSteps <> NULL)
					    INSERT INTO TCD.BatchParameters
					    (
							 BatchId,
							 EcolabWasherId,
							 ParameterId,
							 ParameterValue,
							 PartitionOn
					    )
					    SELECT
							 @BatchID,
							 @EcoLabWasherID,
							 38,
							 @StdWashSteps,
							 @ShiftStartdate;
				 END;
		   END;
	    ELSE
		   BEGIN
			  UPDATE tcd.BatchData
			    SET
				   EndDate = @EndDateTime,
				   EndDateFormula = @EndDateTime,
				   ProgramNumber = @ProgramNumber,
				   ProgramMasterId = @ProgramMasterID,
				   ActualWeight = @Load,
				   SyncReady = 1
			  WHERE
				   BatchID = @BatchID;
		   END;
		      --If the received formula is not configured in enVision then create an alarm 
       IF(@ProgramMasterId is NULL)
       BEGIN
       SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant;
       SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.AlarmGroupMsterVsControllerModelType AGMVCMT
       INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
       WHERE AGMVCMT.AlarmCode = 9000
        INSERT INTO [TCD].[AlarmData] 
           (EcoalabAccountNumber,
           AlarmCode,
           BatchId,
           controllerID,
           StartDate,
           GroupId,
           MachineInternalId,
           ProgramId,   
           IsActive,
           EndDate,
           MachineId,
           AlarmGroupMasterId)
           SELECT
            @ECOLABAccountNumber,
            9000,
            @BatchID,
            @ControllerId,
            @StartDateTime,
            @WasherGroupID,
            @MachineNumber,
            @ProgramNumber,
            0,
            @StartDateTime,
            @WasherId,
            @AlarmGroupMasterId
       END





	    IF NOT EXISTS
	    (
		   SELECT
				1
		   FROM [TCD].[BatchCustomerData]
		   WHERE BatchID = @BatchId
			    AND @CustomerNumber IS NOT NULL
	    )
		   BEGIN
			  INSERT INTO [TCD].[BatchCustomerData]
			  (
				    [BatchId],
				    CustomerID,
				    [Weight],
				    PartitionOn,
				    EcolabWasherId
			  )
			  VALUES
			  (
				    @BatchID,
				    @CustomerNumber,
				    @Load,
				    @ShiftStartdate,
				    @EcolabWasherID
			  );
		   END;
	    ELSE
	    IF(@CustomerNumber > 0)
		   BEGIN
			  UPDATE [TCD].[BatchCustomerData]
			    SET
				   CustomerID = @CustomerNumber,
				   [Weight] = @Load
			  WHERE
				   BatchID = @BatchId;
		   END;
	    CREATE TABLE #Dosing
	    (
		    equipmentNo INT,
		    StepNo      INT,
		    Qty         DECIMAL(10, 6)
	    );
	    INSERT INTO #Dosing
	    SELECT
			 T.c.value('@Equipment', 'INT'),
			 T.c.value('@stepNo', 'INT'),
			 T.c.value('@Qty', 'Decimal(10,6)')
	    FROM @VxML.nodes('MyControlConventionalData/DosingData/Dosing') T
	    (C)
	    WHERE T.c.value('@Qty', 'Decimal(10,6)') > 0;
	    CREATE TABLE #StepTime
	    (
		    Number    INT,
		    [Time]    INT,
		    StartTime DATETIME,
		    EndTime   DATETIME
	    );
	    INSERT INTO #StepTime
	    (
			 Number,
			 [Time]
	    )
	    SELECT
			 T.c.value('@Number', 'INT'),
			 T.c.value('@Time', 'INT')
	    FROM @VxML.nodes('MyControlConventionalData/StepTime/Step') T(C);
	    CREATE TABLE #TimeStamp
	    (
		    Step_Number INT,
		    Time_Stamp  INT
	    );
	
	    --For Calculating TIME_STAMP

	    WITH TempTable
		    AS (SELECT DISTINCT
					Number
			   FROM #StepTime)
		    INSERT INTO #TimeStamp
		    (
				 Step_Number,
				 Time_Stamp
		    )
		    SELECT
				 b.Number,
				 SUM(t.Time) Time_Stamp
		    FROM TempTable b
			    INNER JOIN #StepTime t ON b.Number >= t.Number
		    GROUP BY
				   b.Number;
	    CREATE TABLE #BatchProductData
	    (
		    equipmentNo INT,
		    StepNo      INT,
		    Qty         DECIMAL(10, 6),
		    Time_Stamp  DATETIME2(7),
		    ProductId   INT,
		    Row_No      INT
	    );
	    INSERT INTO #BatchProductData
	    (
			 EquipmentNo,
			 StepNo,
			 Qty,
			 Time_Stamp,
			 ProductId,
			 Row_No
	    )
	    SELECT
			 d.equipmentNo,
			 d.StepNo,
			 d.Qty,
			 DATEADD(ss, ts.Time_Stamp, @StartDateTime),
			 ces.ProductId,
			 ROW_NUMBER() OVER(ORDER BY d.StepNo DESC) AS Row
	    FROM #Dosing d
		    INNER JOIN #TimeStamp ts ON d.StepNo = ts.Step_Number
		    INNER JOIN tcd.ControllerEquipmentSetup ces ON ces.
		    ControllerEquipmentId = d.equipmentNo
	    WHERE d.equipmentNo > 0
			AND d.Qty > 0
			AND ControllerID = @ControllerID
			AND ces.ProductId IS NOT NULL;
	    SELECT
			 @MaxWashertGroupCapacity = MAX(ws.MaxLoad)
	    FROM TCD.Washer WS
		    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.
		    GroupId
	    WHERE Mst.GroupId = @WasherGroupID;
	    DECLARE @Counter INT;
	    SET @counter = 1;
	    WHILE(@counter <=
		    (
			   SELECT
					COUNT(ROW_No)
			   FROM #BatchProductData bpd
		    ))
		   BEGIN
			  SELECT
				    @stepno = bpd.StepNo,
				    @quantity = bpd.Qty,
				    @productid = bpd.ProductId,
				    @timestamp = bpd.Time_Stamp
			  FROM #BatchProductData bpd
			  WHERE bpd.Row_No = @counter
			  ORDER BY
					 bpd.StepNo;
			  SELECT
				    @InjectionNumber = Wdpm.InjectionNumber,
				    @standardqty = ((@NominalLoad / CONVERT( DECIMAL(
				    10, 2), 100)) * Wdpm.Quantity * Ws.MaxLoad) /
				    CONVERT(DECIMAL(10, 2), 100),
				    @price = ((@NominalLoad / CONVERT(       DECIMAL(
				    10, 2), 100)) * Wdpm.Quantity *
				    @MaxWashertGroupCapacity) / CONVERT(DECIMAL(10, 2),
				    100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID)
			  FROM TCD.Washer WS
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws
				  .WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =
				  Mst.GroupId
				  INNER JOIN TCD.WasherGroupType WgT ON WgT.
				  WasherGroupTypeId = Wg.WasherGroupTypeId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.
				  ControllerID = Wg.ControllerId
				  INNER JOIN TCD.WasherDosingSetup Wds ON Wds.
				  WasherProgramSetupId = Wps.WasherProgramSetupId
				  INNER JOIN TCD.WasherDosingProductMapping Wdpm ON
				  Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
				  INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.
				  ProductId = Wdpm.ProductId
				  INNER JOIN TCD.BatchData Bd ON Bd.MachineId = Ws.
				  WasherId
			  WHERE Ws.WasherId = @WasherID
				   AND Wps.ProgramNumber = @ProgramNumber
				   --AND Wdpm.InjectionNumber = @stepno
				   AND Bd.BatchId = @BatchID
				   AND Wps.Is_Deleted = 0
				   AND Pdm.Is_Deleted = 0;
			  INSERT INTO TCD.BatchProductData
			  (
				    BatchId,
				    StepCompartment,
				    ActualQuantity,
				    StandardQuantity,
				    Price,
				    PartitionOn,
				    EcolabWasherId,
				    ProductId,
				    TimeStamp,
				    InjectionNumber
			  )
			  VALUES
			  (
				    @BatchID,
				    @stepno,
				    @quantity,
				    @standardqty,
				    @price,
				    @ShiftStartdate,
				    @EcolabWasherId,
				    @productid,
				    @timestamp,
				    @InjectionNumber
			  );
			  SET @counter = @counter + 1;
		   END;
	    --END For calculating TIMESTAMP
	    --Start Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
	    SELECT
			 @ActualInjSteps = COUNT(DISTINCT StepNo)
	    FROM #Dosing;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE ParameterId = 37
			    AND batchid = @BatchID
			    AND @ActualInjSteps > 0
	    )
		   BEGIN
			  IF(@ActualInjSteps > 0
				OR @ActualInjSteps IS NOT NULL)
				 INSERT INTO TCD.BatchParameters
				 (
					   BatchId,
					   EcolabWasherId,
					   ParameterId,
					   ParameterValue,
					   PartitionOn
				 )
				 SELECT
					   @BatchId,
					   @EcolabWasherId,
					   37,
					   @ActualInjSteps,
					   @ShiftStartDate;
		   END;
	    ELSE
		   BEGIN
			  UPDATE TCD.BatchParameters
			    SET
				   ParameterValue = @ActualInjSteps
			  WHERE
				   ParameterId = 37
				   AND batchid = @BatchID;
		   END;
	    SELECT
			 @LastStep = MAX([Number])
	    FROM #StepTime
	    WHERE [Time] > 0;
	    SELECT
			 @CurrentStep = 1,
			 @CurrentStepTime = @StartDateTime;
	    WHILE(@CurrentStep <= @LastStep)
		   BEGIN
			  UPDATE #StepTime
			    SET
				   StartTime = @CurrentStepTime,
				   EndTime = DATEADD(ss, [time], @CurrentStepTime)
			  WHERE
				   Number = @CurrentStep;
			  SELECT
				    @CurrentStepTime = EndTime
			  FROM #StepTime
			  WHERE Number = @CurrentStep;
			  SELECT
				    @CurrentStep = @CurrentStep + 1;
		   END;
	    INSERT INTO [TCD].[BatchWashStepData]
	    (
			 BatchID,
			 StepCompartment,
			 StartTime,
			 EndTime,
			 PartitionOn,
			 EcolabWasherId
	    )
	    SELECT
			 @BatchID,
			 Number,
			 StartTime,
			 EndTime,
			 @ShiftStartdate,
			 @EcoLabWasherID
	    FROM #StepTime
	    WHERE Number <= @LastStep;
	    SELECT
			 @MinTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Mimum Temperature';
	    SELECT
			 @MaxTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Maximum Temperature';
	    SELECT
			 @MaxTempStatusParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Max Temperature Status';
	    SELECT
			 @MinTempStatuParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Minimum Temperature Status';
	    SELECT
			 @PHValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH';
	    SELECT
			 @PHStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH Status';
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MinTempParamID
	    )
		   BEGIN
			  IF(@TemperatureMin <> 0
				OR @TemperatureMin <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MinTempParamID,
						  @TemperatureMin,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MaxTempParamID
	    )
		   BEGIN
			  IF(@TemperatureMax <> 0
				OR @TemperatureMax <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MaxTempParamID,
						  @TemperatureMax,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MaxTempStatusParamID
	    )
		   BEGIN
			  IF(@TempMaxStatus <> 0
				OR @TempMaxStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MaxTempStatusParamID,
						  @TempMaxStatus,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MinTempStatuParamID
	    )
		   BEGIN
			  IF(@TempMinStatus <> 0
				OR @TempMinStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MinTempStatuParamID,
						  @TempMinStatus,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF(@PHStatus <> 0
		  OR @PHStatus <> NULL)
		   BEGIN
			  INSERT INTO TCD.BatchParameters
			  (
				    BatchId,
				    EcolabWasherId,
				    ParameterId,
				    ParameterValue,
				    PartitionOn
			  )
			  VALUES
			  (
				    @BatchID,
				    @EcoLabWasherID,
				    @PHStatusParamID,
				    @PHStatus,
				    @ShiftStartdate
			  );
		   END;
	    IF(@PHValue <> 0
		  OR @PHValue <> NULL)
		   BEGIN
			  INSERT INTO TCD.BatchParameters
			  (
				    BatchId,
				    EcolabWasherId,
				    ParameterId,
				    ParameterValue,
				    PartitionOn
			  )
			  VALUES
			  (
				    @BatchID,
				    @EcoLabWasherID,
				    @PHValueParamID,
				    @PHValue,
				    @ShiftStartdate
			  );
		   END;
	    EXEC TCD.ProcessMyControlProductionWaterConsumptionData
		    @BatchID,
		    @VxML,
		    @ShiftStartDate;
	    DROP TABLE #BatchProductData;
	    DROP TABLE #Dosing;
	    DROP TABLE #StepTime;
	    DROP TABLE #TimeStamp;

		--Start water consumption per batch

	SELECT @MeterID=MeterId,@StepComportment=MachineCompartment
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@MachineNumber
   AND mt.CounterNum = 1;


   SELECT @EnergyCount=COUNT(1) FROM TCd.BatchStepWaterUsageData bswud WHERE BatchId =@BatchID AND StepCompartment =@StepComportment AND ActualQuantity=@WaterConsumption1
    IF(@EnergyCount=0)
  BEGIN
  IF(ISNULL(@WaterConsumption1,0)>0  AND ISNULL(@MeterID,0)>0  AND ISNULL(@StepComportment,0)>0)
  BEGIN
   INSERT INTO TCD.BatchStepWaterUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
	  EcolabWasherId
     )
     SELECT
     @BatchID,
     @StepComportment,
     @WaterConsumption1,
     @ShiftStartdate,
	 @EcoLabWasherID
	 END
      END  

	 SELECT @MeterID=MeterId,@StepComportment=MachineCompartment
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@MachineNumber
   AND mt.CounterNum = 2;
SELECT @EnergyCount=COUNT(1) FROM TCd.BatchStepWaterUsageData WHERE BatchId =@BatchID AND StepCompartment =@StepComportment AND ActualQuantity=@WaterConsumption2
 IF(@EnergyCount=0)
  BEGIN
  IF(ISNULL(@WaterConsumption2,0)>0  AND ISNULL(@MeterID,0)>0  AND ISNULL(@StepComportment,0)>0)
  BEGIN
   INSERT INTO TCD.BatchStepWaterUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
	  EcolabWasherId
     )
     SELECT
     @BatchID,
     @StepComportment,
     @WaterConsumption2,
     @ShiftStartdate,
	 @EcoLabWasherID
	 END
      END   
	  --End water consumption per batch
	END;

GO

	IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlTunnelWasherProdData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlTunnelWasherProdData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessMyControlTunnelWasherProdData](
	@ControllerID   INT,
	@xmlTags        XML,
	@PLCPointer     INT,
	@ReadPointer    INT,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @BatchID                   INT,
			  @WasherID                  INT,
			  @EcolabWasherId            INT,
			  @CurrencyCode              VARCHAR(50),
			  @MachineInternalId         INT,
			  @WasherGroupID             INT,
			  @PlantWasherNumber         INT,
			  @ProgramNumber             INT,
			  @Load                      DECIMAL(10, 2),
			  @NominalLoad               DECIMAL(10, 2),
			  @CustomerNumber            INT,
			  @PHStatus                  INT,
			  @PHValue                   INT,
			  @LFStatus                  INT,
			  @LFValue                   INT,
			  @BatchNumber               INT,
			  @TargetTurnTime            INT,
			  @PartitionOn               DATETIME2,
			  @BatchStartTime            DATETIME2,
			  @BatchEndTime              DATETIME2,
			  @ProgramID                 INT,
			  @NumberOfCompartments      INT,
			  @ProductId                 INT,
			  @CompartmentNum            INT,
			  @EquipmentType             INT,
			  @MinTempParamID            INT,
			  @MaxTempParamID            INT,
			  @TempStatusParamID         INT,
			  @PHValueParamID            INT,
			  @PHStatusParamID           INT,
			  @ConductivityValueParamID  INT,
			  @ConductivityStatusParamID INT,
			  @StdInjectionSteps         INT,
			  @StdWashSteps              INT,
			  @ActualInjSteps            INT,
			  @EcolabTextileCategoryId   INT,
			  @ChainTextileCategoryId    INT,
			  @FormulaSegmentId          INT,
			  @EcolabSaturationId        INT,
			  @PlantProgramId            INT,
			  @PreviousShiftId		    INT,
			  @CurrentShiftId		    INT,
			  @CurrentStepComportmentNO INT,
              @CounterNO                INT,
               @MeterID                 INT,
              @ActualQuantity          DECIMAL(10,6),
			  @BatchStepCount         INT,
			  @EcolabAccountNumber   INT,
			  @AlarmGroupMasterId    INT

	    DECLARE @BatchShiftId INT;
	    DECLARE @ShiftStartDateTemp TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    DECLARE @TunnelXML XML;
	    SELECT @TunnelXML = T.c.query('.')
	    FROM @xmlTags.nodes('MyControlTunnel/TunnelData') T(c)
	    WHERE T.c.value('@CompartmentNumber', 'INT') = 0;

		
	    SELECT @MachineInternalID = T.c.value('@MachineNumber', 'int'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @BatchStartTime = T.c.value('@StartDateTime', 'DateTime'),
			 @BatchEndTime = T.c.value('@EndDateTime', 'DateTime'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@Nominalload', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'int'),
			 @PHStatus = T.c.value('@Phstatus', 'int'),
			 @PHValue = T.c.value('@Phvalue', 'INT'),
			 @LFStatus = T.c.value('@LFStatus', 'INT'),
			 @LFValue = T.c.value('@LFValue', 'INT')
	    FROM @xmlTags.nodes('MyControlTunnel/TunnelData') T(c);

	    SELECT @EcolabWasherID = Ws.EcolabWasherId,
			 @WasherGroupID = Wg.WasherGroupId,
			 @PlantWasherNumber = PlantWasherNumber,
			 @WasherID = ws.WasherId,
			 @CurrencyCode = P.CurrencyCode,
			 @NumberOfCompartments = Mst.NumberofComp
	    FROM TCD.Washer Ws
		    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.
		    GroupId
		    INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId
		    = Wg.WasherGroupTypeId
		    INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId =
		    Mst.ControllerId
		    INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.
		    EcoLabAccountNumber
	    WHERE Ctrl.ControllerID = @ControllerID
			AND Mst.MachineInternalId = @MachineInternalID
			AND Mst.IsTunnel = 1 AND Mst.IsDeleted=0;
	    SELECT @EcolabWasherID;
	    SELECT @ProgramID = ProgramId,
			 @TargetTurnTime = (3600 / (tps.TotalRunTime /
			 @NumberOfCompartments))
	    FROM TCD.TunnelProgramSetup AS tps
	    WHERE tps.WasherGroupId = @WasherGroupID
			AND tps.is_deleted = 0
			AND ProgramNumber = @ProgramNumber;
	    DELETE FROM @ShiftStartDateTemp;
	    IF(@BatchEndTime IS NOT NULL)
		   BEGIN
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchEndTime
		   END;
	    ELSE
		   BEGIN
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchStartTime
		   END;
	    SELECT @BatchShiftId = ShiftID,
			 @PartitionOn = ShiftStartdate
	    FROM @ShiftStartDateTemp;


	    --Start Getting InjectionCount,StepCount And ProductCount
	    SELECT @StdInjectionSteps = COUNT(tdpm.TunnelDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT tds.TunnelDosingSetupId) -
			 COUNT(tdpm.TunnelDosingSetupId)
	    FROM tcd.TunnelDosingProductMapping tdpm
		    RIGHT JOIN tcd.TunnelDosingSetup tds ON tdpm.
		    TunnelDosingSetupId = tds.TunnelDosingSetupId
	    WHERE tds.GroupId = @WasherGroupID
			AND tds.ProgramNumber = @ProgramNumber;
	    --End Getting InjectionCount,StepCount And ProductCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramID
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT @EcolabTextileCategoryId = pcp. EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp. ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    SELECT @BatchID = NULL;
	    SELECT @BatchID = BatchID
	    FROM TCD.BatchData BD
	    WHERE BD.ControllerBatchId = @BatchNumber
			AND BD.StartDate = @BatchStartTime
			AND BD.MachineId = @WasherID;
	    --AND BD.MachineInternalID = @MachineInternalID
	    IF(@BatchID IS NULL)
		   BEGIN
		   --Start Rollup for previous completed shift
	   IF(CAST(@BatchStartTime as date) < CAST(GETUTCDATE() as date))
	   BEGIN
		  SELECT TOP 1 @PreviousShiftId=ShiftId FROM TCD.BatchData WHERE MachineId=@WasherId ORDER BY StartDate DESC	   
		  SELECT Top 1 @CurrentShiftId = ShiftId from @ShiftStartDateTemp
		  IF(@CurrentShiftId != @PreviousShiftId)
		  BEGIN
			 EXEC TCD.ProductionShiftDataRollup @PreviousShiftId, @RedFlagShiftId OUTPUT
			 IF(@RedFlagShiftId IS NULL)
			 BEGIN
				SET @RedFlagShiftId = @PreviousShiftId
			 END
		  END
	   END
	   --End Rollup for previous completed shift
			  INSERT INTO TCD.BatchData
			  (ControllerBatchId,
			   EcolabWasherId,
			   GroupId,
			   MachineInternalId,
			   PlantWasherNumber,
			   StartDate,
			   EndDate,
			   ProgramNumber,
			   ProgramMasterId,
			   MachineId,
			   ActualWeight,
			   StandardWeight,
			   CurrencyCode,
			   ShiftId,
			   PartitionOn,
			   TargetTurnTime,
			   StdInjectionSteps,
			   StdWashSteps,
			   EcolabTextileCategoryId,
			   ChainTextileCategoryId,
			   FormulaSegmentId,
			   EcolabSaturationId,
			   PlantProgramId,
			   EndDateFormula
			  )
				    SELECT @BatchNumber,
						 @EcolabWasherID,
						 @WasherGroupID,
						 @MachineInternalID,
						 @PlantWasherNumber,
						 @BatchStartTime,
						 @BatchEndTime,
						 @ProgramNumber,
						 @ProgramID,
						 @WasherID,
						 @Load,
						 @NominalLoad,
						 @CurrencyCode,
						 @BatchShiftId,
						 @PartitionOn,
						 @TargetTurnTime,
						 @StdInjectionSteps,
						 @StdWashSteps,
						 @EcolabTextileCategoryId,
						 @ChainTextileCategoryId,
						 @FormulaSegmentId,
						 @EcolabSaturationId,
						 @PlantProgramId,
						 @BatchEndTime;
			  SELECT @BatchID = SCOPE_IDENTITY();
			  IF(@StdWashSteps > 0
				OR @StdWashSteps <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchID,
							@EcolabWasherId,
							38,
							@StdWashSteps,
							@PartitionOn;
			  EXEC TCD.UPDATEBatchWashStepForTunnel
				  @TunnelXML,
				  @WasherID,
				  @BatchID,
				  @BatchStartTime,
				  @PartitionOn,
				  @EcolabWasherId,
				  @NumberOfCompartments;
		   END;
	    IF(@BatchEndTime IS NOT NULL
		  AND @BatchEndTime != '01/01/1900')
		   BEGIN
			  UPDATE TCD.BatchData
			    SET
				   EndDate = @BatchEndTime,
				   ShiftId = @BatchShiftId,
				   PartitionOn = @PartitionOn,
				   EndDateFormula=@BatchEndTime
			  WHERE BATCHID = @BatchID;
		   END;

		      --If the received formula is not configured in enVision then create an alarm 
       IF(@ProgramID is NULL)
       BEGIN
       SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant;
       SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.AlarmGroupMsterVsControllerModelType AGMVCMT
       INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
       WHERE AGMVCMT.AlarmCode = 9000
        INSERT INTO [TCD].[AlarmData] 
           (EcoalabAccountNumber,
           AlarmCode,
           BatchId,
           controllerID,
           StartDate,
           GroupId,
           MachineInternalId,
           ProgramId,   
           IsActive,
           EndDate,
           MachineId,
           AlarmGroupMasterId)
           SELECT
            @ECOLABAccountNumber,
            9000,
            @BatchID,
            @ControllerId,
            @BatchStartTime,
            @WasherGroupID,
            @MachineInternalID,
            @ProgramNumber,
            0,
            @BatchStartTime,
            @WasherId,
            @AlarmGroupMasterId
       END


	    IF(@CustomerNumber IS NOT NULL)
		   BEGIN
			  IF NOT EXISTS
			  (
				 SELECT 1
				 FROM [TCD].[BatchCustomerData]
				 WHERE BatchID = @BatchID
			  )
				 BEGIN
					INSERT INTO [TCD].[BatchCustomerData]
					([BatchId],
					 CustomerID,
					 [Weight],
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @BatchID,
							    @CustomerNumber,
							    @Load,
							    @PartitionOn,
							    @EcolabWasherId;
				 END;
		   END;
	    CREATE TABLE #DosingDetails
	    (
		    Number          INT,
		    Quantity        DECIMAL(10, 6),
		    Point           INT,
		    IsMainEquioment INT
	    );
	    INSERT INTO #DosingDetails
	    (Number,
		Quantity,
		Point,
		IsMainEquioment
	    )
			 SELECT T.c.value('@Number', 'INT') AS Number, --PumpNumber
				   T.c.value('@Quantity', 'Decimal(10,6)') AS Quantity, --Dosing Quanity
				   T.c.value('@Point', 'INT') AS Point, --Dosing point
				   T.c.value('@IsMainEquioment', 'INT') AS
			 IsMainEquioment
			 FROM @xmlTags.nodes('MyControlTunnel/TunnelData/Dose') T(C)
	    ;
	
	    -- Fetching data from cursor
	    DECLARE @MYCURSOR CURSOR;
	    SET @MYCURSOR = CURSOR FAST_FORWARD
	    FOR SELECT Number,
				Quantity,
				Point,
				IsMainEquioment
		   FROM #DosingDetails;
	    DECLARE @Number          INT,
			  @Quantity        DECIMAL(10, 6),
			  @Point           INT,
			  @IsMainEquioment INT;
	    OPEN @MYCURSOR;
	    FETCH NEXT FROM @MYCURSOR INTO @Number,
								@Quantity,
								@Point,
								@IsMainEquioment;
	    WHILE @@FETCH_STATUS = 0
		   BEGIN
			  IF(@IsMainEquioment = 1)
				 BEGIN
					SET @EquipmentType = 2;
				 END;
			  ELSE
				 BEGIN
					SET @EquipmentType = 1;
				 END;
			  SELECT @ProductId = CES.ProductId,
				    @CompartmentNum = TCEVM.CompartmentNumber
			  FROM tcd.ControllerEquipmentSetup CES
				  INNER JOIN TCD.
				  TunnelCompartmentEquipmentValveMapping TCEVM ON CES.
				  ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
			  WHERE CES.ControllerId = @ControllerID
				   AND CES.ControllerEquipmentTypeId = @EquipmentType
				   AND --CES.IsActive=1 AND
				   --CES.WasherGroupNumber=@WasherGroupNum AND
				   TCEVM.DosingPointNumber = @Point
				   AND CES.ControllerEquipmentId = @Number;
				
			  --SELECT @EcolabWasherID
			  IF(@ProductId IS NOT NULL)
				 BEGIN
					INSERT INTO TCD.BatchProductData
					(BatchId,
					 StepCompartment,
					 ActualQuantity,
					 [TimeStamp],
					 PartitionOn,
					 EcolabWasherId,
					 ProductId
					)
						  SELECT @BatchID,
							    @CompartmentNum,
							    @Quantity,
							    @BatchEndTime,
							    @PartitionOn,
							    @EcolabWasherID,
							    @ProductId;
				 END;
			  FETCH NEXT FROM @MYCURSOR INTO @Number,
									   @Quantity,
									   @Point,
									   @IsMainEquioment;
		   END;
	    CLOSE @MYCURSOR;
	    DEALLOCATE @MYCURSOR;
	    DROP TABLE #DosingDetails;
	    SELECT @ActualInjSteps = COUNT(DISTINCT StepCompartment)
	    FROM TCD.BatchProductData
	    WHERE BatchId = @BatchID;
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.BatchParameters
		   WHERE ParameterId = 37
			    AND batchid = @BatchID
			    AND @ActualInjSteps > 0
	    )
		   BEGIN
			  IF(@ActualInjSteps > 0
				OR @ActualInjSteps <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchId,
							@EcolabWasherId,
							37,
							@ActualInjSteps,
							@PartitionOn;
		   END;
	    ELSE
		   BEGIN
			  UPDATE TCD.BatchParameters
			    SET
				   ParameterValue = @ActualInjSteps
			  WHERE ParameterId = 37
				   AND batchid = @BatchID;
		   END;
	    SELECT @MinTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Mimum Temperature';
	    SELECT @MaxTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Maximum Temperature';
	    SELECT @TempStatusParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Temperature Status';
	    SELECT @PHValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH';
	    SELECT @PHStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH Status';
	    SELECT @ConductivityValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Conductivity';
	    SELECT @ConductivityStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'LF Status';
	    IF(@PHValue IS NOT NULL)
		   BEGIN
			  --pH Value
			  IF(@PHValue <> 0
				OR @PHValue <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @PHValueParamID,
					   @PHValue,
					   @PartitionOn
				 );

			  --pH Status
			  IF(@PHStatus <> 0
				OR @PHStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @PHStatusParamID,
					   @PHStatus,
					   @PartitionOn
				 );
		   END;
	    IF(@LFValue IS NOT NULL)
		   BEGIN
			  --Conductivity Value
			  IF(@LFValue <> 0
				OR @LFValue <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @ConductivityValueParamID,
					   @LFValue,
					   @PartitionOn
				 );

			  --Conductivity Status
			  IF(@LFStatus <> 0
				OR @LFStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @ConductivityStatusParamID,
					   @LFStatus,
					   @PartitionOn
				 );
		   END;
	    CREATE TABLE #TemperatureDetails
	    (
		    MinimumTemp DECIMAL(10, 2),
		    MaximumTemp DECIMAL(10, 2),
		    TempStatus  DECIMAL(10, 2)
	    );
	    INSERT INTO #TemperatureDetails
	    (MinimumTemp,
		MaximumTemp,
		TempStatus
	    )
			 SELECT T.c.value('@Minimum', 'Decimal(10,2)') AS
			 MinimumTemp,
				   T.c.value('@Maximum', 'Decimal(10,2)') AS
				   MaximumTemp,
				   T.c.value('@Status', 'Decimal(10,2)') AS TempStatus
			 FROM @xmlTags.nodes(
			 'MyControlTunnel/TunnelData/TemperatureData'
							) T(c);
	  
	    -- Fetching data from cursor
	    DECLARE @TEMPCURSOR CURSOR;
	    SET @TEMPCURSOR = CURSOR FAST_FORWARD
	    FOR SELECT MinimumTemp,
				MaximumTemp,
				TempStatus
		   FROM #TemperatureDetails;
	    DECLARE @MinimumTemp DECIMAL(10, 2),
			  @MaximumTemp DECIMAL(10, 2),
			  @TempStatus  DECIMAL(10, 2);
	    OPEN @TEMPCURSOR;
	    FETCH NEXT FROM @TEMPCURSOR INTO @MinimumTemp,
								  @MaximumTemp,
								  @TempStatus;
	    WHILE @@FETCH_STATUS = 0
		   BEGIN	
			  --Minimum Temperature
			  IF(@MinimumTemp <> 0
				OR @MinimumTemp <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @MinTempParamID,
					   @MinimumTemp,
					   @PartitionOn
				 );

			  --Maximum Temperature
			  IF(@MaximumTemp <> 0
				OR @MaximumTemp <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @MaxTempParamID,
					   @MaximumTemp,
					   @PartitionOn
				 );

			  --Temperature Status
			  IF(@TempStatus <> 0
				OR @TempStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @TempStatusParamID,
					   @TempStatus,
					   @PartitionOn
				 );
			  FETCH NEXT FROM @TEMPCURSOR INTO @MinimumTemp,
										@MaximumTemp,
										@TempStatus;
		   END;
	    CLOSE @TEMPCURSOR;
	    DEALLOCATE @TEMPCURSOR;
	    DROP TABLE #TemperatureDetails;
	    UPDATE TCD.BatchWashStepData
		 SET
			EndTime = DATEADD(ss,
						  (SELECT T.c.value('@Time', 'INT')
							 FROM @TunnelXML.nodes('TunnelData/CompartmentTime') T(c)
							 WHERE T.c.value('@CompartmentNo','INT') =
							 (
								SELECT
									  bwsd.StepCompartment
								FROM tcd.BatchWashStepData bwsd
								WHERE bwsd.BatchId = @BatchID
									 AND bwsd.EndTime IS NULL
							 )
						  ),
						  (
							 SELECT
								   bwsd.StartTime
							 FROM tcd.BatchWashStepData bwsd
							 WHERE bwsd.BatchId = @BatchID
								  AND bwsd.EndTime IS NULL
						  ))
	    WHERE
			BatchId = @BatchID
			AND EndTime IS NULL;
   
   --Start water consumption per batch


    CREATE TABLE #WaterConsumptionData
     (
      Number          INT,
      Quantity        DECIMAL(10,6),
     );
     INSERT INTO #WaterConsumptionData
     (Number,
  Quantity
     )
    SELECT T.c.value('@Counter', 'INT') AS Number, --PumpNumber
       T.c.value('@Value', 'DECIMAL(10,6)') AS Quantity --Water Quanity
    FROM @xmlTags.nodes('MyControlTunnel/TunnelData/WaterConsumption') T(C);

  
  SET @CurrentStepComportmentNO=1;

  WHILE(@CurrentStepComportmentNO<=22)
  BEGIN
  
   SELECT @MeterID=MeterId,@CounterNO=mt.CounterNum
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@CurrentStepComportmentNO

    SELECT @ActualQuantity=wc.Quantity
  FROM #WaterConsumptionData wc where wc.Number=@CounterNo
  SELECT @BatchStepCount=COUNT(1) FROM TCD.BatchStepWaterUsageData WHERE BatchId=@BatchID  AND StepCompartment =@CurrentStepComportmentNO AND ActualQuantity=@ActualQuantity 
  IF (@BatchStepCount=0)
  BEGIN
  IF(ISNULL(@BatchID,0)>0  AND ISNULL(@MeterID,0)>0 AND ISNULL(@ActualQuantity,0)>0)
  BEGIN

   INSERT INTO TCD.BatchStepWaterUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
      EcolabWasherId
     )
     SELECT
     @BatchID,
     @CurrentStepComportmentNO,
     @ActualQuantity,
     @PartitionOn,
     @EcolabWasherId
      END 
	  END 
      SET  @CurrentStepComportmentNO=@CurrentStepComportmentNO+1;  
  END;
 END;

 
 
 GO


 ----------------------------------------------End Added non formula alarm data for conventional and tunnel prod-------------

 ------------------------------------------------Tunnel batch product data price and standart quantity calclutions--------------------
 IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlConventionalData_CompletedBatches]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlConventionalData_CompletedBatches]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ProcessMyControlConventionalData_CompletedBatches](
	@ControllerID   INT,
	@VxML           XML,
	@PLCPointer     INT,
	@ReadPointer    INT,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @MachineNumber           INT,
			  @StartDateTime           DATETIME,
			  @EndDateTime             DATETIME,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @PHValue                 INT,
			  @TemperatureMin          INT,
			  @TemperatureMax          INT,
			  @TempMinStatus           INT,
			  @TempMaxStatus           INT,
			  @BatchNumber             INT,
			  @WasherID                INT,
			  @WasherGroupID           INT,
			  @EcoLabWasherID          INT,
			  @ProgramMasterID         INT,
			  @PlantWasherNumber       INT,
			  @ShiftID                 INT,
			  @BatchID                 INT,
			  @ShiftStartdate          DATETIME,
			  @LastStep                INT,
			  @CurrentStep             INT,
			  @CurrentStepTime         DATETIME,
			  @MinTempParamID          INT,
			  @MaxTempParamID          INT,
			  @MinTempStatuParamID     INT,
			  @MaxTempStatusParamID    INT,
			  @PHStatusParamID         INT,
			  @PHValueParamID          INT,
			  @CurrencyCode            VARCHAR(50),
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @ActualInjSteps          INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @TargetTurnTime          INT,
			  @PreviousShiftId         INT,
			  @CurrentShiftId          INT,
			  @MeterID                 INT,
			  @StepComportment         INT,
			  @Stepno                  INT,
			  @quantity                INT,
			  @productid               INT,
			  @Price                   DECIMAL(18, 4),
			  @StandardQty             DECIMAL(18, 4),
			  @TimeStamp               DATETIME2(7),
			  @MaxWashertGroupCapacity INT,
			  @InjectionNumber         INT,
			  @WaterConsumption1       DECIMAL(10,6),
			  @WaterConsumption2       DECIMAL(10,6),
			  @EnergyCount             INT,
			   @EcolabAccountNumber    NVARCHAR(25),
	           @AlarmGroupMasterId     INT;
	    SELECT
			 @MachineNumber = T.c.value('@MachineNumber', 'INT'),
			 @StartDateTime = T.c.value('@StartDateTime', 'DateTime'),
			 @EndDateTime = T.c.value('@EndDateTime', 'DateTime'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@NominalLoad', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'INT'),
			 @PHStatus = T.c.value('@PHStatus', 'INT'),
			 @PHValue = T.c.value('@PHValue', 'INT'),
			 @TemperatureMin = T.c.value('@TemperatureMin', 'INT'),
			 @TemperatureMax = T.c.value('@TemperatureMax', 'INT'),
			 @TempMaxStatus = T.c.value('@TemperatureMaxStatus', 'INT'),
			 @TempMinStatus = T.c.value('@TemperatreMinStatus', 'INT'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @WaterConsumption1 = T.c.value('@WaterConsumption1','DECIMAL(10,6)'),
			 @WaterConsumption2 = T.c.value('@WaterConsumption2','DECIMAL(10,6)')
	    FROM @VxML.nodes('MyControlConventionalData') T(C);

	    DECLARE @ShiftMapping TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    INSERT INTO @ShiftMapping
	    (
			 ShiftId,
			 ShiftName,
			 ShiftStartdate
	    )
	    EXEC TCD.GetShiftStartDate
		    @StartDateTime;
	    SELECT
			 @ShiftID = ShiftID,
			 @ShiftStartdate = ShiftStartdate
	    FROM @ShiftMapping;
	    SELECT
			 @WasherGroupID = GroupId,
			 @WasherID = WasherID
	    FROM TCD.MachineSetup ms
	    WHERE ControllerID = @ControllerID
			AND MachineInternalId = @MachineNumber
			AND IsTunnel = 0
			AND IsDeleted = 0;
	    IF(@WasherId IS NOT NULL)
		   BEGIN
			  SELECT
				    @ProgramMasterId = Wps.ProgramId
			  FROM TCD.Washer Ws
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws
				  .WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =
				  Mst.GroupId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.
				  ControllerID = Wg.ControllerId
				  INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber =
				  Ws.EcoLabAccountNumber
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wps.Is_Deleted = 0;
			  SELECT
				    @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber,
				    @CurrencyCode = P.CurrencyCode,
				    @TargetTurnTime = w.TargetTurnTime * 60
			  FROM TCD.Washer w
				  INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.
				  EcolabAccountNumber
			  WHERE w.WasherId = @WasherID;
		   END;
	    SELECT
			 @BatchID = BatchID
	    FROM TCD.BatchData
	    WHERE MachineInternalID = @MachineNumber
			AND StartDate = @StartDateTime
			AND ControllerBatchId = @BatchNumber
			AND MachineID = @WasherID;

	    --Start Getting InjectionCount and StepCount

	    SELECT
			 @StdInjectionSteps = COUNT(DISTINCT wdpm.
			 WasherDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) -
			 COUNT(DISTINCT wdpm.WasherDosingSetupId)
	    FROM TCD.WasherDosingProductMapping wdpm
		    RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm.
		    WasherDosingSetupId = wds.WasherDosingSetupId
	    WHERE wds.ControllerID = @ControllerID
			AND wds.ProgramNumber = @ProgramNumber;

	    --End Getting InjectionCount and StepCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT
			 @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramMasterId
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT
				    @EcolabTextileCategoryId = pcp.
				    EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp.
				    ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    IF(@BatchID IS NULL)
		   BEGIN

			  --Start Rollup for previous completed shift
			  IF(CAST(@StartDateTime AS DATE) < CAST(GETUTCDATE() AS
			  DATE))
				 BEGIN
					SELECT TOP 1
						  @PreviousShiftId = ShiftId
					FROM TCD.BatchData
					WHERE MachineId = @WasherId
					ORDER BY
						    StartDate DESC;
					SELECT TOP 1
						  @CurrentShiftId = ShiftId
					FROM @ShiftMapping;
					IF(@CurrentShiftId != @PreviousShiftId)
					    BEGIN
						   EXEC TCD.ProductionShiftDataRollup
							   @PreviousShiftId,
							   @RedFlagShiftId OUTPUT;
						   IF(@RedFlagShiftId IS NULL)
							  BEGIN
								 SET @RedFlagShiftId =
								 @PreviousShiftId;
							  END;
					    END;
				 END;
			  --End Rollup for previous completed shift

			  INSERT INTO TCD.BatchData
			  (
				    ControllerBatchID,
				    EcolabWasherId,
				    GroupId,
				    MachineInternalId,
				    PlantWasherNumber,
				    StartDate,
				    EndDate,
				    ProgramNumber,
				    ProgramMasterId,
				    MachineID,
				    ActualWeight,
				    StandardWeight,
				    CurrencyCode,
				    ShiftId,
				    PartitionOn,
				    StdInjectionSteps,
				    StdWashSteps,
				    EcolabTextileCategoryId,
				    ChainTextileCategoryId,
				    FormulaSegmentId,
				    EcolabSaturationId,
				    PlantProgramId,
				    EndDateFormula,
				    TargetTurnTime
			  )
			  VALUES
			  (
				    @BatchNumber,
				    @EcoLabWasherID,
				    @WasherGroupID,
				    @MachineNumber,
				    @PlantWasherNumber,
				    @StartDateTime,
				    @EndDateTime,
				    @ProgramNumber,
				    @ProgramMasterId,
				    @WasherID,
				    @Load,
				    @NominalLoad,
				    @CurrencyCode,
				    @ShiftID,
				    @ShiftStartdate,
				    @StdInjectionSteps,
				    @StdWashSteps,
				    @EcolabTextileCategoryId,
				    @ChainTextileCategoryId,
				    @FormulaSegmentId,
				    @EcolabSaturationId,
				    @PlantProgramId,
				    @EndDateTime,
				    @TargetTurnTime
			  );
			  SELECT
				    @BatchID = SCOPE_IDENTITY();
			  IF NOT EXISTS
			  (
				 SELECT
					   *
				 FROM TCD.BatchParameters
				 WHERE BatchId = @BatchID
					  AND ParameterID = 38
			  )
				 BEGIN
					IF(@StdWashSteps > 0
					   OR @StdWashSteps <> NULL)
					    INSERT INTO TCD.BatchParameters
					    (
							 BatchId,
							 EcolabWasherId,
							 ParameterId,
							 ParameterValue,
							 PartitionOn
					    )
					    SELECT
							 @BatchID,
							 @EcoLabWasherID,
							 38,
							 @StdWashSteps,
							 @ShiftStartdate;
				 END;
		   END;
	    ELSE
		   BEGIN
			  UPDATE tcd.BatchData
			    SET
				   EndDate = @EndDateTime,
				   EndDateFormula = @EndDateTime,
				   ProgramNumber = @ProgramNumber,
				   ProgramMasterId = @ProgramMasterID,
				   ActualWeight = @Load,
				   SyncReady = 1
			  WHERE
				   BatchID = @BatchID;
		   END;
		      --If the received formula is not configured in enVision then create an alarm 
       IF(@ProgramMasterId is NULL)
       BEGIN
       SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant;
       SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.AlarmGroupMsterVsControllerModelType AGMVCMT
       INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
       WHERE AGMVCMT.AlarmCode = 9000
        INSERT INTO [TCD].[AlarmData] 
           (EcoalabAccountNumber,
           AlarmCode,
           BatchId,
           controllerID,
           StartDate,
           GroupId,
           MachineInternalId,
           ProgramId,   
           IsActive,
           EndDate,
           MachineId,
           AlarmGroupMasterId)
           SELECT
            @ECOLABAccountNumber,
            9000,
            @BatchID,
            @ControllerId,
            @StartDateTime,
            @WasherGroupID,
            @MachineNumber,
            @ProgramNumber,
            0,
            @StartDateTime,
            @WasherId,
            @AlarmGroupMasterId
       END





	    IF NOT EXISTS
	    (
		   SELECT
				1
		   FROM [TCD].[BatchCustomerData]
		   WHERE BatchID = @BatchId
			    AND @CustomerNumber IS NOT NULL
	    )
		   BEGIN
			  INSERT INTO [TCD].[BatchCustomerData]
			  (
				    [BatchId],
				    CustomerID,
				    [Weight],
				    PartitionOn,
				    EcolabWasherId
			  )
			  VALUES
			  (
				    @BatchID,
				    @CustomerNumber,
				    @Load,
				    @ShiftStartdate,
				    @EcolabWasherID
			  );
		   END;
	    ELSE
	    IF(@CustomerNumber > 0)
		   BEGIN
			  UPDATE [TCD].[BatchCustomerData]
			    SET
				   CustomerID = @CustomerNumber,
				   [Weight] = @Load
			  WHERE
				   BatchID = @BatchId;
		   END;
	    CREATE TABLE #Dosing
	    (
		    equipmentNo INT,
		    StepNo      INT,
		    Qty         DECIMAL(10, 6)
	    );
	    INSERT INTO #Dosing
	    SELECT
			 T.c.value('@Equipment', 'INT'),
			 T.c.value('@stepNo', 'INT'),
			 T.c.value('@Qty', 'Decimal(10,6)')
	    FROM @VxML.nodes('MyControlConventionalData/DosingData/Dosing') T
	    (C)
	    WHERE T.c.value('@Qty', 'Decimal(10,6)') > 0;
	    CREATE TABLE #StepTime
	    (
		    Number    INT,
		    [Time]    INT,
		    StartTime DATETIME,
		    EndTime   DATETIME
	    );
	    INSERT INTO #StepTime
	    (
			 Number,
			 [Time]
	    )
	    SELECT
			 T.c.value('@Number', 'INT'),
			 T.c.value('@Time', 'INT')
	    FROM @VxML.nodes('MyControlConventionalData/StepTime/Step') T(C);
	    CREATE TABLE #TimeStamp
	    (
		    Step_Number INT,
		    Time_Stamp  INT
	    );
	
	    --For Calculating TIME_STAMP

	    WITH TempTable
		    AS (SELECT DISTINCT
					Number
			   FROM #StepTime)
		    INSERT INTO #TimeStamp
		    (
				 Step_Number,
				 Time_Stamp
		    )
		    SELECT
				 b.Number,
				 SUM(t.Time) Time_Stamp
		    FROM TempTable b
			    INNER JOIN #StepTime t ON b.Number >= t.Number
		    GROUP BY
				   b.Number;
	    CREATE TABLE #BatchProductData
	    (
		    equipmentNo INT,
		    StepNo      INT,
		    Qty         DECIMAL(10, 6),
		    Time_Stamp  DATETIME2(7),
		    ProductId   INT,
		    Row_No      INT
	    );
	    INSERT INTO #BatchProductData
	    (
			 EquipmentNo,
			 StepNo,
			 Qty,
			 Time_Stamp,
			 ProductId,
			 Row_No
	    )
	    SELECT
			 d.equipmentNo,
			 d.StepNo,
			 d.Qty,
			 DATEADD(ss, ts.Time_Stamp, @StartDateTime),
			 ces.ProductId,
			 ROW_NUMBER() OVER(ORDER BY d.StepNo DESC) AS Row
	    FROM #Dosing d
		    INNER JOIN #TimeStamp ts ON d.StepNo = ts.Step_Number
		    INNER JOIN tcd.ControllerEquipmentSetup ces ON ces.
		    ControllerEquipmentId = d.equipmentNo
	    WHERE d.equipmentNo > 0
			AND d.Qty > 0
			AND ControllerID = @ControllerID
			AND ces.ProductId IS NOT NULL;
	    SELECT
			 @MaxWashertGroupCapacity = MAX(ws.MaxLoad)
	    FROM TCD.Washer WS
		    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.
		    GroupId
	    WHERE Mst.GroupId = @WasherGroupID;
	    DECLARE @Counter INT;
	    SET @counter = 1;
	    WHILE(@counter <=
		    (
			   SELECT
					COUNT(ROW_No)
			   FROM #BatchProductData bpd
		    ))
		   BEGIN
			  SELECT
				    @stepno = bpd.StepNo,
				    @quantity = bpd.Qty,
				    @productid = bpd.ProductId,
				    @timestamp = bpd.Time_Stamp
			  FROM #BatchProductData bpd
			  WHERE bpd.Row_No = @counter
			  ORDER BY
					 bpd.StepNo;
			  SELECT
				    @InjectionNumber = Wdpm.InjectionNumber,
				    @standardqty = ((@NominalLoad / CONVERT( DECIMAL(
				    10, 2), 100)) * Wdpm.Quantity * Ws.MaxLoad) /
				    CONVERT(DECIMAL(10, 2), 100),
				    @price = ((@NominalLoad / CONVERT(       DECIMAL(
				    10, 2), 100)) * Wdpm.Quantity *
				    @MaxWashertGroupCapacity) / CONVERT(DECIMAL(10, 2),
				    100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID)
			  FROM TCD.Washer WS
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws
				  .WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =
				  Mst.GroupId
				  INNER JOIN TCD.WasherGroupType WgT ON WgT.
				  WasherGroupTypeId = Wg.WasherGroupTypeId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.
				  ControllerID = Wg.ControllerId
				  INNER JOIN TCD.WasherDosingSetup Wds ON Wds.
				  WasherProgramSetupId = Wps.WasherProgramSetupId
				  INNER JOIN TCD.WasherDosingProductMapping Wdpm ON
				  Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
				  INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.
				  ProductId = Wdpm.ProductId
				  INNER JOIN TCD.BatchData Bd ON Bd.MachineId = Ws.
				  WasherId
			  WHERE Ws.WasherId = @WasherID
				   AND Wps.ProgramNumber = @ProgramNumber
				   --AND Wdpm.InjectionNumber = @stepno
				   AND Bd.BatchId = @BatchID
				   AND Wps.Is_Deleted = 0
				   AND Pdm.Is_Deleted = 0;
			  INSERT INTO TCD.BatchProductData
			  (
				    BatchId,
				    StepCompartment,
				    ActualQuantity,
				    StandardQuantity,
				    Price,
				    PartitionOn,
				    EcolabWasherId,
				    ProductId,
				    TimeStamp,
				    InjectionNumber
			  )
			  VALUES
			  (
				    @BatchID,
				    @stepno,
				    @quantity,
				    ISNULL(@standardqty,0),
				    ISNULL(@price,0),
				    @ShiftStartdate,
				    @EcolabWasherId,
				    @productid,
				    @timestamp,
				    @InjectionNumber
			  );
			  SET @counter = @counter + 1;
		   END;
	    --END For calculating TIMESTAMP
	    --Start Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
	    SELECT
			 @ActualInjSteps = COUNT(DISTINCT StepNo)
	    FROM #Dosing;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE ParameterId = 37
			    AND batchid = @BatchID
			    AND @ActualInjSteps > 0
	    )
		   BEGIN
			  IF(@ActualInjSteps > 0
				OR @ActualInjSteps IS NOT NULL)
				 INSERT INTO TCD.BatchParameters
				 (
					   BatchId,
					   EcolabWasherId,
					   ParameterId,
					   ParameterValue,
					   PartitionOn
				 )
				 SELECT
					   @BatchId,
					   @EcolabWasherId,
					   37,
					   @ActualInjSteps,
					   @ShiftStartDate;
		   END;
	    ELSE
		   BEGIN
			  UPDATE TCD.BatchParameters
			    SET
				   ParameterValue = @ActualInjSteps
			  WHERE
				   ParameterId = 37
				   AND batchid = @BatchID;
		   END;
	    SELECT
			 @LastStep = MAX([Number])
	    FROM #StepTime
	    WHERE [Time] > 0;
	    SELECT
			 @CurrentStep = 1,
			 @CurrentStepTime = @StartDateTime;
	    WHILE(@CurrentStep <= @LastStep)
		   BEGIN
			  UPDATE #StepTime
			    SET
				   StartTime = @CurrentStepTime,
				   EndTime = DATEADD(ss, [time], @CurrentStepTime)
			  WHERE
				   Number = @CurrentStep;
			  SELECT
				    @CurrentStepTime = EndTime
			  FROM #StepTime
			  WHERE Number = @CurrentStep;
			  SELECT
				    @CurrentStep = @CurrentStep + 1;
		   END;
	    INSERT INTO [TCD].[BatchWashStepData]
	    (
			 BatchID,
			 StepCompartment,
			 StartTime,
			 EndTime,
			 PartitionOn,
			 EcolabWasherId
	    )
	    SELECT
			 @BatchID,
			 Number,
			 StartTime,
			 EndTime,
			 @ShiftStartdate,
			 @EcoLabWasherID
	    FROM #StepTime
	    WHERE Number <= @LastStep;
	    SELECT
			 @MinTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Mimum Temperature';
	    SELECT
			 @MaxTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Maximum Temperature';
	    SELECT
			 @MaxTempStatusParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Max Temperature Status';
	    SELECT
			 @MinTempStatuParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Minimum Temperature Status';
	    SELECT
			 @PHValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH';
	    SELECT
			 @PHStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH Status';
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MinTempParamID
	    )
		   BEGIN
			  IF(@TemperatureMin <> 0
				OR @TemperatureMin <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MinTempParamID,
						  @TemperatureMin,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MaxTempParamID
	    )
		   BEGIN
			  IF(@TemperatureMax <> 0
				OR @TemperatureMax <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MaxTempParamID,
						  @TemperatureMax,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MaxTempStatusParamID
	    )
		   BEGIN
			  IF(@TempMaxStatus <> 0
				OR @TempMaxStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MaxTempStatusParamID,
						  @TempMaxStatus,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MinTempStatuParamID
	    )
		   BEGIN
			  IF(@TempMinStatus <> 0
				OR @TempMinStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MinTempStatuParamID,
						  @TempMinStatus,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF(@PHStatus <> 0
		  OR @PHStatus <> NULL)
		   BEGIN
			  INSERT INTO TCD.BatchParameters
			  (
				    BatchId,
				    EcolabWasherId,
				    ParameterId,
				    ParameterValue,
				    PartitionOn
			  )
			  VALUES
			  (
				    @BatchID,
				    @EcoLabWasherID,
				    @PHStatusParamID,
				    @PHStatus,
				    @ShiftStartdate
			  );
		   END;
	    IF(@PHValue <> 0
		  OR @PHValue <> NULL)
		   BEGIN
			  INSERT INTO TCD.BatchParameters
			  (
				    BatchId,
				    EcolabWasherId,
				    ParameterId,
				    ParameterValue,
				    PartitionOn
			  )
			  VALUES
			  (
				    @BatchID,
				    @EcoLabWasherID,
				    @PHValueParamID,
				    @PHValue,
				    @ShiftStartdate
			  );
		   END;
	    EXEC TCD.ProcessMyControlProductionWaterConsumptionData
		    @BatchID,
		    @VxML,
		    @ShiftStartDate;
	    DROP TABLE #BatchProductData;
	    DROP TABLE #Dosing;
	    DROP TABLE #StepTime;
	    DROP TABLE #TimeStamp;

		--Start water consumption per batch

	SELECT @MeterID=MeterId,@StepComportment=MachineCompartment
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@MachineNumber
   AND mt.CounterNum = 1;


   SELECT @EnergyCount=COUNT(1) FROM TCd.BatchStepWaterUsageData bswud WHERE BatchId =@BatchID AND StepCompartment =@StepComportment AND ActualQuantity=@WaterConsumption1
    IF(@EnergyCount=0)
  BEGIN
  IF(ISNULL(@WaterConsumption1,0)>0  AND ISNULL(@MeterID,0)>0  AND ISNULL(@StepComportment,0)>0)
  BEGIN
   INSERT INTO TCD.BatchStepWaterUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
	  EcolabWasherId
     )
     SELECT
     @BatchID,
     @StepComportment,
     @WaterConsumption1,
     @ShiftStartdate,
	 @EcoLabWasherID
	 END
      END  

	 SELECT @MeterID=MeterId,@StepComportment=MachineCompartment
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@MachineNumber
   AND mt.CounterNum = 2;
SELECT @EnergyCount=COUNT(1) FROM TCd.BatchStepWaterUsageData WHERE BatchId =@BatchID AND StepCompartment =@StepComportment AND ActualQuantity=@WaterConsumption2
 IF(@EnergyCount=0)
  BEGIN
  IF(ISNULL(@WaterConsumption2,0)>0  AND ISNULL(@MeterID,0)>0  AND ISNULL(@StepComportment,0)>0)
  BEGIN
   INSERT INTO TCD.BatchStepWaterUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
	  EcolabWasherId
     )
     SELECT
     @BatchID,
     @StepComportment,
     @WaterConsumption2,
     @ShiftStartdate,
	 @EcoLabWasherID
	 END
      END   
	  --End water consumption per batch
	END;
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlTunnelWasherProdData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlTunnelWasherProdData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ProcessMyControlTunnelWasherProdData](
	@ControllerID   INT,
	@xmlTags        XML,
	@PLCPointer     INT,
	@ReadPointer    INT,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @BatchID                   INT,
			  @WasherID                  INT,
			  @EcolabWasherId            INT,
			  @CurrencyCode              VARCHAR(50),
			  @MachineInternalId         INT,
			  @WasherGroupID             INT,
			  @PlantWasherNumber         INT,
			  @ProgramNumber             INT,
			  @Load                      DECIMAL(10, 2),
			  @NominalLoad               DECIMAL(10, 2),
			  @CustomerNumber            INT,
			  @PHStatus                  INT,
			  @PHValue                   INT,
			  @LFStatus                  INT,
			  @LFValue                   INT,
			  @BatchNumber               INT,
			  @TargetTurnTime            INT,
			  @PartitionOn               DATETIME2,
			  @BatchStartTime            DATETIME2,
			  @BatchEndTime              DATETIME2,
			  @ProgramID                 INT,
			  @NumberOfCompartments      INT,
			  @ProductId                 INT,
			  @CompartmentNum            INT,
			  @EquipmentType             INT,
			  @MinTempParamID            INT,
			  @MaxTempParamID            INT,
			  @TempStatusParamID         INT,
			  @PHValueParamID            INT,
			  @PHStatusParamID           INT,
			  @ConductivityValueParamID  INT,
			  @ConductivityStatusParamID INT,
			  @StdInjectionSteps         INT,
			  @StdWashSteps              INT,
			  @ActualInjSteps            INT,
			  @EcolabTextileCategoryId   INT,
			  @ChainTextileCategoryId    INT,
			  @FormulaSegmentId          INT,
			  @EcolabSaturationId        INT,
			  @PlantProgramId            INT,
			  @PreviousShiftId		    INT,
			  @CurrentShiftId		    INT,
			  @CurrentStepComportmentNO INT,
              @CounterNO                INT,
               @MeterID                 INT,
              @ActualQuantity          DECIMAL(10,6),
			  @BatchStepCount         INT,
			  @EcolabAccountNumber   VARCHAR(100),
			  @AlarmGroupMasterId    INT,
			  @StandardQuantity          DECIMAL(18, 4),
			  @Price                     DECIMAL(18, 4);

	    DECLARE @BatchShiftId INT;
	    DECLARE @ShiftStartDateTemp TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    DECLARE @TunnelXML XML;
	    SELECT @TunnelXML = T.c.query('.')
	    FROM @xmlTags.nodes('MyControlTunnel/TunnelData') T(c)
	    WHERE T.c.value('@CompartmentNumber', 'INT') = 0;

		
	    SELECT @MachineInternalID = T.c.value('@MachineNumber', 'int'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @BatchStartTime = T.c.value('@StartDateTime', 'DateTime'),
			 @BatchEndTime = T.c.value('@EndDateTime', 'DateTime'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@Nominalload', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'int'),
			 @PHStatus = T.c.value('@Phstatus', 'int'),
			 @PHValue = T.c.value('@Phvalue', 'INT'),
			 @LFStatus = T.c.value('@LFStatus', 'INT'),
			 @LFValue = T.c.value('@LFValue', 'INT')
	    FROM @xmlTags.nodes('MyControlTunnel/TunnelData') T(c);

	    SELECT @EcolabWasherID = Ws.EcolabWasherId,
			 @WasherGroupID = Wg.WasherGroupId,
			 @PlantWasherNumber = PlantWasherNumber,
			 @WasherID = ws.WasherId,
			 @CurrencyCode = P.CurrencyCode,
			 @NumberOfCompartments = Mst.NumberofComp
	    FROM TCD.Washer Ws
		    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.
		    GroupId
		    INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId
		    = Wg.WasherGroupTypeId
		    INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId =
		    Mst.ControllerId
		    INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.
		    EcoLabAccountNumber
	    WHERE Ctrl.ControllerID = @ControllerID
			AND Mst.MachineInternalId = @MachineInternalID
			AND Mst.IsTunnel = 1 AND Mst.IsDeleted=0;
	    SELECT @EcolabWasherID;
	    SELECT @ProgramID = ProgramId,
			 @TargetTurnTime = (3600 / (tps.TotalRunTime /
			 @NumberOfCompartments))
	    FROM TCD.TunnelProgramSetup AS tps
	    WHERE tps.WasherGroupId = @WasherGroupID
			AND tps.is_deleted = 0
			AND ProgramNumber = @ProgramNumber;
	    DELETE FROM @ShiftStartDateTemp;
	    IF(@BatchEndTime IS NOT NULL)
		   BEGIN
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchEndTime
		   END;
	    ELSE
		   BEGIN
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchStartTime
		   END;
	    SELECT @BatchShiftId = ShiftID,
			 @PartitionOn = ShiftStartdate
	    FROM @ShiftStartDateTemp;


	    --Start Getting InjectionCount,StepCount And ProductCount
	    SELECT @StdInjectionSteps = COUNT(tdpm.TunnelDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT tds.TunnelDosingSetupId) -
			 COUNT(tdpm.TunnelDosingSetupId)
	    FROM tcd.TunnelDosingProductMapping tdpm
		    RIGHT JOIN tcd.TunnelDosingSetup tds ON tdpm.
		    TunnelDosingSetupId = tds.TunnelDosingSetupId
	    WHERE tds.GroupId = @WasherGroupID
			AND tds.ProgramNumber = @ProgramNumber;
	    --End Getting InjectionCount,StepCount And ProductCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramID
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT @EcolabTextileCategoryId = pcp. EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp. ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    SELECT @BatchID = NULL;
	    SELECT @BatchID = BatchID
	    FROM TCD.BatchData BD
	    WHERE BD.ControllerBatchId = @BatchNumber
			AND BD.StartDate = @BatchStartTime
			AND BD.MachineId = @WasherID;
	    --AND BD.MachineInternalID = @MachineInternalID
	    IF(@BatchID IS NULL)
		   BEGIN
		   --Start Rollup for previous completed shift
	   IF(CAST(@BatchStartTime as date) < CAST(GETUTCDATE() as date))
	   BEGIN
		  SELECT TOP 1 @PreviousShiftId=ShiftId FROM TCD.BatchData WHERE MachineId=@WasherId ORDER BY StartDate DESC	   
		  SELECT Top 1 @CurrentShiftId = ShiftId from @ShiftStartDateTemp
		  IF(@CurrentShiftId != @PreviousShiftId)
		  BEGIN
			 EXEC TCD.ProductionShiftDataRollup @PreviousShiftId, @RedFlagShiftId OUTPUT
			 IF(@RedFlagShiftId IS NULL)
			 BEGIN
				SET @RedFlagShiftId = @PreviousShiftId
			 END
		  END
	   END
	   --End Rollup for previous completed shift
			  INSERT INTO TCD.BatchData
			  (ControllerBatchId,
			   EcolabWasherId,
			   GroupId,
			   MachineInternalId,
			   PlantWasherNumber,
			   StartDate,
			   EndDate,
			   ProgramNumber,
			   ProgramMasterId,
			   MachineId,
			   ActualWeight,
			   StandardWeight,
			   CurrencyCode,
			   ShiftId,
			   PartitionOn,
			   TargetTurnTime,
			   StdInjectionSteps,
			   StdWashSteps,
			   EcolabTextileCategoryId,
			   ChainTextileCategoryId,
			   FormulaSegmentId,
			   EcolabSaturationId,
			   PlantProgramId,
			   EndDateFormula
			  )
				    SELECT @BatchNumber,
						 @EcolabWasherID,
						 @WasherGroupID,
						 @MachineInternalID,
						 @PlantWasherNumber,
						 @BatchStartTime,
						 @BatchEndTime,
						 @ProgramNumber,
						 @ProgramID,
						 @WasherID,
						 @Load,
						 @NominalLoad,
						 @CurrencyCode,
						 @BatchShiftId,
						 @PartitionOn,
						 @TargetTurnTime,
						 @StdInjectionSteps,
						 @StdWashSteps,
						 @EcolabTextileCategoryId,
						 @ChainTextileCategoryId,
						 @FormulaSegmentId,
						 @EcolabSaturationId,
						 @PlantProgramId,
						 @BatchEndTime;
			  SELECT @BatchID = SCOPE_IDENTITY();
			  IF(@StdWashSteps > 0
				OR @StdWashSteps <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchID,
							@EcolabWasherId,
							38,
							@StdWashSteps,
							@PartitionOn;
			  EXEC TCD.UPDATEBatchWashStepForTunnel
				  @TunnelXML,
				  @WasherID,
				  @BatchID,
				  @BatchStartTime,
				  @PartitionOn,
				  @EcolabWasherId,
				  @NumberOfCompartments;
		   END;
	    IF(@BatchEndTime IS NOT NULL
		  AND @BatchEndTime != '01/01/1900')
		   BEGIN
			  UPDATE TCD.BatchData
			    SET
				   EndDate = @BatchEndTime,
				   ShiftId = @BatchShiftId,
				   PartitionOn = @PartitionOn,
				   EndDateFormula=@BatchEndTime
			  WHERE BATCHID = @BatchID;
		   END;

		      --If the received formula is not configured in enVision then create an alarm 
       IF(@ProgramID is NULL)
       BEGIN
       SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant;
       SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.AlarmGroupMsterVsControllerModelType AGMVCMT
       INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
       WHERE AGMVCMT.AlarmCode = 9000
        INSERT INTO [TCD].[AlarmData] 
           (EcoalabAccountNumber,
           AlarmCode,
           BatchId,
           controllerID,
           StartDate,
           GroupId,
           MachineInternalId,
           ProgramId,   
           IsActive,
           EndDate,
           MachineId,
           AlarmGroupMasterId)
           SELECT
            @ECOLABAccountNumber,
            9000,
            @BatchID,
            @ControllerId,
            @BatchStartTime,
            @WasherGroupID,
            @MachineInternalID,
            @ProgramNumber,
            0,
            @BatchStartTime,
            @WasherId,
            @AlarmGroupMasterId
       END


	    IF(@CustomerNumber IS NOT NULL)
		   BEGIN
			  IF NOT EXISTS
			  (
				 SELECT 1
				 FROM [TCD].[BatchCustomerData]
				 WHERE BatchID = @BatchID
			  )
				 BEGIN
					INSERT INTO [TCD].[BatchCustomerData]
					([BatchId],
					 CustomerID,
					 [Weight],
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @BatchID,
							    @CustomerNumber,
							    @Load,
							    @PartitionOn,
							    @EcolabWasherId;
				 END;
		   END;
	    CREATE TABLE #DosingDetails
	    (
		    Number          INT,
		    Quantity        DECIMAL(10, 6),
		    Point           INT,
		    IsMainEquioment INT
	    );
	    INSERT INTO #DosingDetails
	    (Number,
		Quantity,
		Point,
		IsMainEquioment
	    )
			 SELECT T.c.value('@Number', 'INT') AS Number, --PumpNumber
				   T.c.value('@Quantity', 'Decimal(10,6)') AS Quantity, --Dosing Quanity
				   T.c.value('@Point', 'INT') AS Point, --Dosing point
				   T.c.value('@IsMainEquioment', 'INT') AS
			 IsMainEquioment
			 FROM @xmlTags.nodes('MyControlTunnel/TunnelData/Dose') T(C)
	    ;
	
	    -- Fetching data from cursor
	    DECLARE @MYCURSOR CURSOR;
	    SET @MYCURSOR = CURSOR FAST_FORWARD
	    FOR SELECT Number,
				Quantity,
				Point,
				IsMainEquioment
		   FROM #DosingDetails;
	    DECLARE @Number          INT,
			  @Quantity        DECIMAL(10, 6),
			  @Point           INT,
			  @IsMainEquioment INT;
	    OPEN @MYCURSOR;
	    FETCH NEXT FROM @MYCURSOR INTO @Number,
								@Quantity,
								@Point,
								@IsMainEquioment;
	    WHILE @@FETCH_STATUS = 0
		   BEGIN
			  IF(@IsMainEquioment = 1)
				 BEGIN
					SET @EquipmentType = 2;
				 END;
			  ELSE
				 BEGIN
					SET @EquipmentType = 1;
				 END;
			  SELECT @ProductId = CES.ProductId,
				    @CompartmentNum = TCEVM.CompartmentNumber
			  FROM tcd.ControllerEquipmentSetup CES
				  INNER JOIN TCD.
				  TunnelCompartmentEquipmentValveMapping TCEVM ON CES.
				  ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
			  WHERE CES.ControllerId = @ControllerID
				   AND CES.ControllerEquipmentTypeId = @EquipmentType
				   AND --CES.IsActive=1 AND
				   --CES.WasherGroupNumber=@WasherGroupNum AND
				   TCEVM.DosingPointNumber = @Point
				   AND CES.ControllerEquipmentId = @Number;
				
			 SELECT DISTINCT
				    @StandardQuantity =((Wps.NominalLoad * Wdpm.Quantity) / 100),
				    @Price = (((Wps.NominalLoad * Wdpm.Quantity) / 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID))
			  FROM TCD.Washer WS
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =Mst.GroupId
				  INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
				  INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
				  INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
				  INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON
				  Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
				  INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId = Wdpm.ControllerEquipmentSetupId
				  INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId = Ces.ProductId
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wds.CompartmentNumber = @CompartmentNum
				   AND Wps.Is_Deleted = 0
				   AND Pdm.Is_Deleted = 0;
				
			  IF(@ProductId IS NOT NULL)
				 BEGIN
					INSERT INTO TCD.BatchProductData
					(
						  BatchId,
						  StepCompartment,
						  ActualQuantity,
						  StandardQuantity,
						  Price,
						  [TimeStamp],
						  PartitionOn,
						  EcolabWasherId,
						  ProductId
					)
					SELECT
						  @BatchID,
						  @CompartmentNum,
						  @Quantity,
						  isnull(@StandardQuantity,0),
						  isnull(@Price,0),
						  @BatchEndTime,
						  @PartitionOn,
						  @EcolabWasherID,
						  @ProductId;
				 END;
			  FETCH NEXT FROM @MYCURSOR INTO @Number,
									   @Quantity,
									   @Point,
									   @IsMainEquioment;
		   END;
	    CLOSE @MYCURSOR;
	    DEALLOCATE @MYCURSOR;
	    DROP TABLE #DosingDetails;
	    SELECT @ActualInjSteps = COUNT(DISTINCT StepCompartment)
	    FROM TCD.BatchProductData
	    WHERE BatchId = @BatchID;
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.BatchParameters
		   WHERE ParameterId = 37
			    AND batchid = @BatchID
			    AND @ActualInjSteps > 0
	    )
		   BEGIN
			  IF(@ActualInjSteps > 0
				OR @ActualInjSteps <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchId,
							@EcolabWasherId,
							37,
							@ActualInjSteps,
							@PartitionOn;
		   END;
	    ELSE
		   BEGIN
			  UPDATE TCD.BatchParameters
			    SET
				   ParameterValue = @ActualInjSteps
			  WHERE ParameterId = 37
				   AND batchid = @BatchID;
		   END;
	    SELECT @MinTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Mimum Temperature';
	    SELECT @MaxTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Maximum Temperature';
	    SELECT @TempStatusParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Temperature Status';
	    SELECT @PHValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH';
	    SELECT @PHStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH Status';
	    SELECT @ConductivityValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Conductivity';
	    SELECT @ConductivityStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'LF Status';
	    IF(@PHValue IS NOT NULL)
		   BEGIN
			  --pH Value
			  IF(@PHValue <> 0
				OR @PHValue <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @PHValueParamID,
					   @PHValue,
					   @PartitionOn
				 );

			  --pH Status
			  IF(@PHStatus <> 0
				OR @PHStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @PHStatusParamID,
					   @PHStatus,
					   @PartitionOn
				 );
		   END;
	    IF(@LFValue IS NOT NULL)
		   BEGIN
			  --Conductivity Value
			  IF(@LFValue <> 0
				OR @LFValue <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @ConductivityValueParamID,
					   @LFValue,
					   @PartitionOn
				 );

			  --Conductivity Status
			  IF(@LFStatus <> 0
				OR @LFStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @ConductivityStatusParamID,
					   @LFStatus,
					   @PartitionOn
				 );
		   END;
	    CREATE TABLE #TemperatureDetails
	    (
		    MinimumTemp DECIMAL(10, 2),
		    MaximumTemp DECIMAL(10, 2),
		    TempStatus  DECIMAL(10, 2)
	    );
	    INSERT INTO #TemperatureDetails
	    (MinimumTemp,
		MaximumTemp,
		TempStatus
	    )
			 SELECT T.c.value('@Minimum', 'Decimal(10,2)') AS
			 MinimumTemp,
				   T.c.value('@Maximum', 'Decimal(10,2)') AS
				   MaximumTemp,
				   T.c.value('@Status', 'Decimal(10,2)') AS TempStatus
			 FROM @xmlTags.nodes(
			 'MyControlTunnel/TunnelData/TemperatureData'
							) T(c);
	  
	    -- Fetching data from cursor
	    DECLARE @TEMPCURSOR CURSOR;
	    SET @TEMPCURSOR = CURSOR FAST_FORWARD
	    FOR SELECT MinimumTemp,
				MaximumTemp,
				TempStatus
		   FROM #TemperatureDetails;
	    DECLARE @MinimumTemp DECIMAL(10, 2),
			  @MaximumTemp DECIMAL(10, 2),
			  @TempStatus  DECIMAL(10, 2);
	    OPEN @TEMPCURSOR;
	    FETCH NEXT FROM @TEMPCURSOR INTO @MinimumTemp,
								  @MaximumTemp,
								  @TempStatus;
	    WHILE @@FETCH_STATUS = 0
		   BEGIN	
			  --Minimum Temperature
			  IF(@MinimumTemp <> 0
				OR @MinimumTemp <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @MinTempParamID,
					   @MinimumTemp,
					   @PartitionOn
				 );

			  --Maximum Temperature
			  IF(@MaximumTemp <> 0
				OR @MaximumTemp <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @MaxTempParamID,
					   @MaximumTemp,
					   @PartitionOn
				 );

			  --Temperature Status
			  IF(@TempStatus <> 0
				OR @TempStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @TempStatusParamID,
					   @TempStatus,
					   @PartitionOn
				 );
			  FETCH NEXT FROM @TEMPCURSOR INTO @MinimumTemp,
										@MaximumTemp,
										@TempStatus;
		   END;
	    CLOSE @TEMPCURSOR;
	    DEALLOCATE @TEMPCURSOR;
	    DROP TABLE #TemperatureDetails;
	    UPDATE TCD.BatchWashStepData
		 SET
			EndTime = DATEADD(ss,
						  (SELECT T.c.value('@Time', 'INT')
							 FROM @TunnelXML.nodes('TunnelData/CompartmentTime') T(c)
							 WHERE T.c.value('@CompartmentNo','INT') =
							 (
								SELECT
									  bwsd.StepCompartment
								FROM tcd.BatchWashStepData bwsd
								WHERE bwsd.BatchId = @BatchID
									 AND bwsd.EndTime IS NULL
							 )
						  ),
						  (
							 SELECT
								   bwsd.StartTime
							 FROM tcd.BatchWashStepData bwsd
							 WHERE bwsd.BatchId = @BatchID
								  AND bwsd.EndTime IS NULL
						  ))
	    WHERE
			BatchId = @BatchID
			AND EndTime IS NULL;
   
   --Start water consumption per batch


    CREATE TABLE #WaterConsumptionData
     (
      Number          INT,
      Quantity        DECIMAL(10,6),
     );
     INSERT INTO #WaterConsumptionData
     (Number,
  Quantity
     )
    SELECT T.c.value('@Counter', 'INT') AS Number, --PumpNumber
       T.c.value('@Value', 'DECIMAL(10,6)') AS Quantity --Water Quanity
    FROM @xmlTags.nodes('MyControlTunnel/TunnelData/WaterConsumption') T(C);

  
  SET @CurrentStepComportmentNO=1;

  WHILE(@CurrentStepComportmentNO<=22)
  BEGIN
  
   SELECT @MeterID=MeterId,@CounterNO=mt.CounterNum
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@CurrentStepComportmentNO

    SELECT @ActualQuantity=wc.Quantity
  FROM #WaterConsumptionData wc where wc.Number=@CounterNo
  SELECT @BatchStepCount=COUNT(1) FROM TCD.BatchStepWaterUsageData WHERE BatchId=@BatchID  AND StepCompartment =@CurrentStepComportmentNO AND ActualQuantity=@ActualQuantity 
  IF (@BatchStepCount=0)
  BEGIN
  IF(ISNULL(@BatchID,0)>0  AND ISNULL(@MeterID,0)>0 AND ISNULL(@ActualQuantity,0)>0)
  BEGIN

   INSERT INTO TCD.BatchStepWaterUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
      EcolabWasherId
     )
     SELECT
     @BatchID,
     @CurrentStepComportmentNO,
     @ActualQuantity,
     @PartitionOn,
     @EcolabWasherId
      END 
	  END 
      SET  @CurrentStepComportmentNO=@CurrentStepComportmentNO+1;  
  END;
 END;
 GO
------------------------------------------------END Tunnel batch product data price and standart quantity calclutions--------------------

---------------------------------------------------------Start Conventional Dasboard Cal---------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetWasherBatchSummarizedData]') AND type 
in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetWasherBatchSummarizedData]
END
GO
SET ANSI_NULLS ON
GO
CREATE PROCEDURE [TCD].[GetWasherBatchSummarizedData](
 @DashBoardId INT = NULL)
AS
 BEGIN
     SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
     SET NOCOUNT ON;
     DECLARE   --@DashBoardId int = 1, 
     @Washerid                INT      = NULL,
     @Standardturntime        INT      = NULL,
     @Machinenamedispalytype  SMALLINT = 0,
     @OverNightBatchThreshold INT      = 7200, -- Seconds  
     @EfficiencyType          INT,
	  @RegionId INT,
	 @EcoLabAccountNumber nvarchar(25);
     SELECT
    @EfficiencyType = ISNULL(EfficiencyCalcType, 1),
	@EcoLabAccountNumber = EcolabAccountNumber
     FROM tcd.Dashboard
     WHERE DashboardId = @DashBoardId;
	 SELECT @RegionId=RegionId FROM TCD.Plant WHERE EcolabAccountNumber=@EcoLabAccountNumber
     DECLARE @Dashboardmachinemapping TABLE
     (
      Id             INT,
      GroupID        INT,
      WasherId       INT,
      WasherName     NVARCHAR(100),
      WasherNumber   INT,
      IsPLCConnected BIT,
      DispenserName  VARCHAR(250)
     );
     DECLARE @AlarmByMachine TABLE
     (
      GroupID          INT,
      WasherID         INT,
      Alarm            BIT NULL,
      AlarmDescription NVARCHAR(250)
     );
     DECLARE @BatchEndtimes TABLE
     (
      GroupID             INT,
      WasherID            INT,
      CurrentBatchEndTime INT NULL,
      BatchEndTime        TIME
     );
     DECLARE @ShiftIds TABLE
     (
      ShiftId        INT,
      ShiftStartDate DATETIME,
      ShiftEndDate   DATETIME
     );
     DECLARE @Summarizeddata TABLE
     (
      GroupId                INT,
      MachineId              INT,
      WasherName             NVARCHAR(100),
      WasherNumber           INT,
      TargetLoad             FLOAT,
      ActualLoad             FLOAT,
      LoadEfficiency         FLOAT,
      TimeEfficiency         FLOAT,
      LostLoad               FLOAT,
      Alarm                  BIT,
      AlarmDescription       NVARCHAR(250),
      WasherStatus           INT,
      MachineNameDispalyType SMALLINT,
      TargetTurnTime         INT,
      DefaultIdleTime        INT,
      IsPLCConnected         BIT,
      DispenserName          VARCHAR(250),
      LostBatches            DECIMAL(18, 6)
     );
     INSERT INTO @Dashboardmachinemapping
     (
    Id,
    GroupID,
    WasherId,
    WasherName,
    WasherNumber,
    IsPLCConnected,
    DispenserName
     )
     SELECT
    ROW_NUMBER() OVER(ORDER BY MS.GroupID) AS Id,
    MS.GroupId,
    MS.WasherID,
    MS.MachineName,
    W.PlantWasherNumber AS                    WasherNumber,
    (CASE
     WHEN ISNULL(AD.IsActive, 0) = 0
     THEN CAST(1 AS    BIT)
     WHEN ISNULL(AD.IsActive, 0) = 1
     THEN CAST(0 AS BIT)
     END) AS                                  IsPLCConnected,
    CAST(CC.ControllerNumber AS NVARCHAR)+' ('+CC.TopicName+
    ')' AS                                    DispenserName
     FROM
     (
     SELECT DISTINCT
    MachineId,
    DashboardId
     FROM TCD.MonitorSetUpMapping
     ) AS DM
     INNER JOIN TCD.MachineSetup AS MS ON DM.MachineId = MS.WasherID
     INNER JOIN tcd.Washer AS W ON MS.WasherId = W.WasherId
     INNER JOIN TCD.Dashboard AS D ON DM.DashBoardId = D.DashBoardId
     INNER JOIN TCD.ConduitController CC ON CC.ControllerId = MS.
     ControllerId
     LEFT JOIN TCD.AlarmData AD ON AD.ControllerId = MS.ControllerId
           AND IsActive = 1
           AND AD.AlarmCode = (CASE
               WHEN
              (
              SELECT
                 VALUE
              FROM TCD.
              controllerSetupData CSD
               LEFT
               JOIN TCD.Field F ON F.Id = CSD.FieldId
              WHERE F.
              Label = 'Webport Ftp Enabled'
                AND
                CSD.ControllerId = AD.ControllerId
                AND CC
                .ControllerTypeId = 1
              ) = 'true'
               THEN 9002
               ELSE 9001
               END)
     WHERE DM.DashboardId = @Dashboardid
   AND MS.IsDeleted = 0
   AND w.Is_Deleted = 0  
   -- Exclude Phony Washers from Efficiency calculation   
   AND ms.WasherId NOT IN
     (
     SELECT
    w.WasherId
     FROM TCD.MachineSetup AS ms
      INNER JOIN TCD.Washer AS w ON w.WasherId = ms.WasherId
            AND ms.
            EcoalabAccountNumber = w.EcoLabAccountNumber
     WHERE(NULLIF(ms.ControllerId, 0) IS NULL
       AND w.WasherMode = 0)
      OR MS.IsPony = 1
     );  
  
  
     -- For efficiency calculations on shift wise  
     IF(@EfficiencyType = 1)
     BEGIN
     INSERT INTO @ShiftIds
     (
        ShiftId,
        ShiftStartDate,
        ShiftEndDate
     )
     SELECT DISTINCT
        ShiftId,
        StartDateTime,
        EndDateTime
     FROM TCD.ProductionShiftData
     WHERE GETUTCDATE() BETWEEN StartDateTime AND EndDateTime;   
     -- WHERE ShiftId = 33 
     END;
     ELSE -- For efficiency calculations on Day wise  
     BEGIN
     INSERT INTO @ShiftIds
     (
        ShiftId,
        ShiftStartDate,
        ShiftEndDate
     )
     SELECT
        ShiftId,
        StartDateTime,
        EndDateTime
     FROM [TCD].ProductionShiftData
     WHERE startdatetime > CAST(GETUTCDATE() AS DATE)
       AND startdatetime < DATEADD(dd, 1, CAST(GETUTCDATE()
       AS DATE))
     ORDER BY
      startdatetime;
     END;
     SELECT
    *
     INTO
      #BatchData
     FROM tcd.BatchData bd(NOLOCK)
     WHERE bd.ShiftId IN
     (
     SELECT
    si.ShiftId
     FROM @ShiftIds si
     )
   AND bd.StandardWeight > 0
   AND bd.ActualWeight > 0
   AND bd.EndDate IS NOT NULL;
     -- Efficiency for each batch   
     SELECT
    bd.BatchId,
    W_1.WasherGroupID AS         GroupID,
    W_1.WasherId AS              MachineID,
    bd.ShiftId,
    W_1.WasherNumber,
    W_1.WasherName,
    (bd.ActualWeight + ISNULL(BD.ManualInputWeight, 0)) AS
                                 ActualProduction,
    bd.StandardWeight AS         StandardProduction,
    CASE
    WHEN DATEDIFF(ss, bd.StartDate, ISNULL(bd.EndDate,
    GETDATE())) > @OverNightBatchThreshold
    THEN W_1.StandardRunTime
    ELSE DATEDIFF(ss, bd.StartDate, ISNULL(bd.EndDate,
    GETDATE()))
    END AS                       ActualRunTime,
    W_1.StandardRunTime,
    TT.ActualTurnTime,
    bd.TargetTurnTime AS         StandardTurnTime,
    CASE
    WHEN W_1.WasherGroupTypeID = 1   
         -- Conventional  
    THEN(CAST((W_1.Standardruntime + bd.TargetTurnTime) AS
         FLOAT) / (CAST(CASE
            WHEN DATEDIFF(ss,
            bd.StartDate,
            ISNULL(bd.EndDate,
            GETDATE())) >
            @OverNightBatchThreshold
            THEN W_1.
            StandardRunTime
            ELSE DATEDIFF(ss,
            bd.StartDate,
            ISNULL(bd.EndDate,
            GETDATE()))
            END + CASE
              WHEN TT.
              ACTUALTURNTIME = 0
              THEN bd.
              TargetTurnTime
              ELSE TT.
              ACTUALTURNTIME
              END AS FLOAT)))  
         -- Tunnel  
    ELSE(CAST(NULLIF(W_1.Standardruntime, 0) AS FLOAT)) /
         (CAST(CASE
           WHEN DATEDIFF(second, bd.
           StartDate, ISNULL(bd.
           EndDate, GETDATE())) = 0
           THEN W_1.Standardruntime
           ELSE CASE
            WHEN DATEDIFF(ss,
            bd.StartDate,
            ISNULL(bd.EndDate,
            GETDATE())) >
            @OverNightBatchThreshold
            THEN W_1.
            StandardRunTime
            ELSE DATEDIFF(ss,
            bd.StartDate,
            ISNULL(bd.EndDate,
            GETDATE()))
            END
           END AS FLOAT))
    END AS                       TimeEfficiency,
    ((CAST((bd.ActualWeight + ISNULL(BD.ManualInputWeight, 0))
    AS    FLOAT) / CAST(NULLIF(bd.StandardWeight, 0) AS FLOAT))
    * 100) AS                    LoadEfficiency,
    CASE
    WHEN W_1.WasherGroupTypeID = 2
    THEN(100 * ((3600.00 / (CAST(CASE
             WHEN DATEDIFF(second,
             bd.StartDate, ISNULL(
             bd.EndDate, GETDATE()))
             = 0
             THEN NULLIF(W_1.
             Standardruntime, 0)
             ELSE DATEDIFF(second,
             bd.StartDate, ISNULL(
             bd.EndDate, GETDATE()))
             END AS FLOAT) / W_1.
             NumberOfComp)) / (3600.00
             / (CAST(NULLIF(W_1.Standardruntime,
             0) AS FLOAT) / W_1.
             NumberOfComp))))
    ELSE NULL
    END AS                       TransferPerHr,  
    --missedloads formulae
    --------(((Actual Production/totalefficiency)*100)-actualproduction)
  
    (CAST(CAST(bd.ActualWeight AS    DECIMAL(18, 6)) / (((CAST
    ((bd.ActualWeight + ISNULL(BD.ManualInputWeight, 0)) AS
    DECIMAL(18, 6)) / CAST(NULLIF(bd.StandardWeight, 0) AS
    DECIMAL(18, 6))) * 100.0) * (CASE
             WHEN W_1.
             WasherGroupTypeID = 1   
         -- Conventional  
             THEN(CAST((W_1.
         Standardruntime + bd.TargetTurnTime)
         AS DECIMAL(18, 6)) / (CAST(
         CASE
             WHEN DATEDIFF(ss, bd.
             StartDate, ISNULL(bd.
             EndDate, GETDATE())) >
             @OverNightBatchThreshold
             THEN W_1.StandardRunTime
             ELSE DATEDIFF(ss, bd.
             StartDate, ISNULL(bd.
             EndDate, GETDATE()))
         END + TT.ACTUALTURNTIME AS
         FLOAT)))  
         -- Tunnel  
             ELSE(CAST(NULLIF(W_1.
         Standardruntime, 0) AS
         DECIMAL(18, 6))) / (CAST(CASE
                  WHEN
                  DATEDIFF(second,
                  bd.StartDate,
                  ISNULL(bd.EndDate,
                  GETDATE()))
                  = 0
                  THEN
                  W_1.Standardruntime
                  ELSE
                  CASE
                  WHEN
                  DATEDIFF(ss,
                  bd.StartDate,
                  ISNULL(bd.EndDate,
                  GETDATE()))
                  > @OverNightBatchThreshold
                  THEN
                  W_1.StandardRunTime
                  ELSE
                  DATEDIFF(ss,
                  bd.StartDate,
                  ISNULL(bd.EndDate,
                  GETDATE()))
                  END
              END
              AS DECIMAL(18,
              6)))
         END)) AS DECIMAL(18, 6)) *
         100.0) - CAST(bd.ActualWeight
         AS DECIMAL(18, 6)) AS
         MissedLoads,
    (((CAST((bd.ActualWeight + ISNULL(BD.ManualInputWeight, 0))
    AS    FLOAT) / CAST(NULLIF(bd.StandardWeight, 0) AS FLOAT))
    * 100) * (CASE
      WHEN W_1.WasherGroupTypeID = 1   
      -- Conventional  
      THEN(CAST((W_1.Standardruntime + bd.
      TargetTurnTime) AS FLOAT) / (CAST(CASE
                WHEN
                DATEDIFF(ss,
                bd.StartDate,
                ISNULL(bd.EndDate,
                GETDATE()))
                > @OverNightBatchThreshold
                THEN W_1.
                StandardRunTime
                ELSE
                DATEDIFF(ss,
                bd.StartDate,
                ISNULL(bd.EndDate,
                GETDATE()))
            END + TT.
            ACTUALTURNTIME AS FLOAT)))  
      -- Tunnel  
      ELSE(CAST(NULLIF(W_1.Standardruntime, 0) AS
      FLOAT)) / (CAST(CASE
          WHEN DATEDIFF(second, bd.
          StartDate, ISNULL(bd.EndDate,
          GETDATE())) = 0
          THEN W_1.Standardruntime
          ELSE CASE
           WHEN DATEDIFF(ss,
           bd.StartDate,
           ISNULL(bd.EndDate,
           GETDATE())) >
           @OverNightBatchThreshold
           THEN W_1.
           StandardRunTime
           ELSE DATEDIFF(ss,
           bd.StartDate,
           ISNULL(bd.EndDate,
           GETDATE()))
           END
          END AS FLOAT))
      END)) AS           TotalEfficiency,
    W_1.MaxLoad
     INTO
      #BatchEfficiency
     FROM #BatchData bd --FROM TCD.BatchData bd   
      RIGHT OUTER JOIN
     (
     SELECT
    ms.EcoalabAccountNumber,
    ms.WasherId,
    ms.GroupId AS                 WasherGroupID,
    mg.WasherGroupTypeId AS       WasherGroupTypeID,
    w.EcolabWasherId,
    w.MaxLoad,
    ISNULL(ms.NumberOfComp, 0) AS NumberOfComp,
    CASE
        WHEN MG.WASHERGROUPTYPEID = 1
        THEN WSP.ProgramNumber
        ELSE TPS.ProgramNumber
    END AS                        ProgramNumber,
    CASE
        WHEN MG.WASHERGROUPTYPEID = 1
        THEN WSP.ProgramId
        ELSE TPS.ProgramId
    END AS                        ProgramId,
    CASE
        WHEN MG.WASHERGROUPTYPEID = 1
        THEN WSP.TotalRunTime
        ELSE TPS.TotalRunTime
    END AS                        Standardruntime,
    w.PlantWasherNumber AS        WasherNumber,
    ms.MachineName AS             WasherName,
    mg.WasherGroupName AS         MachineGroup  
     --mg.WasherGroupId AS MachineGroupID  
     FROM TCD.MachineSetup AS ms(NOLOCK)
      INNER JOIN TCD.Washer AS w(NOLOCK) ON w.
      EcoLabAccountNumber = ms.EcoalabAccountNumber
            AND w.WasherId =
            ms.WasherId
      INNER JOIN TCD.WasherGroup AS mg(NOLOCK) ON ms.GroupId =
      mg.WasherGroupId
              AND w.
              EcoLabAccountNumber = mg.EcolabAccountNumber
      LEFT OUTER JOIN TCD.WasherProgramSetup AS WSP(NOLOCK) ON
      (WSP.WasherGroupId = mg.WasherGroupId
       OR WSP.ControllerID = mg.ControllerId)
      AND WSP.EcolabAccountNumber = mg.EcolabAccountNumber
      AND WSP.Is_Deleted = 0 --AND WSP.WasherGroupId = ms.GroupId      
      LEFT OUTER JOIN TCD.TunnelProgramSetup AS TPS(NOLOCK) ON
      TPS.WasherGroupId = mg.WasherGroupId
      AND TPS.EcolabAccountNumber = mg.EcolabAccountNumber
      AND TPS.Is_Deleted = 0 --AND TPS.WasherGroupId = ms.GroupId   
      RIGHT JOIN @Dashboardmachinemapping DM1 ON DM1.GroupID =
      ms.GroupId
             AND DM1.
             WasherId = ms.WasherId
     WHERE ms.IsTunnel = 0
       AND ms.IsDeleted = 0
     ) AS W_1 ON BD.GroupId = W_1.WasherGroupID
     AND ISNULL(BD.EcolabWasherId, 0) = ISNULL(W_1.
     EcolabWasherId, 0)
     AND bd.MachineID = W_1.WasherId
     AND BD.ProgramMasterId = W_1.ProgramId
     AND BD.ProgramNumber = W_1.ProgramNumber
      LEFT JOIN [TCD].[Turntime] TT ON ISNULL(BD.EcolabwasherID, 0)
      = ISNULL(TT.EcolabWasherId, 0)
           AND BD.batchid = TT.BatchID
     WHERE DATEDIFF(ss, bd.StartDate, bd.EndDate) > (W_1.
     Standardruntime * 10 / 100);
     SELECT
    DM.GroupID,
    DM.WasherId AS                                     MachineID,
    DM.WasherNumber,
    DM.WasherName,
    CAST(SUM(t.ActualProduction) AS FLOAT) AS          ActualProduction,
    CAST(SUM(t.StandardProduction) AS FLOAT) AS
                                                       StandardProduction,
    SUM(t.ActualRunTime) AS                            ActualRuntime,
    SUM(t.StandardRunTime) AS                          StandardRunTime,
    (SUM(t.MissedLoads) / COUNT(DISTINCT t.BatchId)) AS
                                                       MissedLoads,
    (CAST(SUM(t.LoadEfficiency) AS    FLOAT) / COUNT(DISTINCT
    t.BatchId)) AS                                     LoadEfficiency,
    ((CAST(SUM(t.TimeEfficiency) AS    FLOAT) / COUNT(DISTINCT
    t.BatchId)) * 100) AS                              TimeEfficiency,
    ((CAST(SUM(t.LoadEfficiency) AS    FLOAT) / COUNT(DISTINCT
    t.BatchId)) * (CAST(SUM(t.TimeEfficiency) AS FLOAT) /
    COUNT(DISTINCT t.BatchId))) AS                     TotalEfficiency,
    DM.IsPLCConnected AS                               IsPLCConnected,
    DM.DispenserName,
    (SUM(t.MissedLoads) / COUNT(DISTINCT t.BatchId)) / CASE
               WHEN
               MAX(t.MaxLoad)
               = 0
               THEN
               1
               ELSE
               MAX(t.MaxLoad)
               END AS
               LostBatches
     INTO
      #MachineEfficiency
     FROM @Dashboardmachinemapping DM
      LEFT JOIN #BatchEfficiency t ON DM.GroupID = t.GroupId
          AND dm.WasherId = t.
          MachineId  
     --AND t.ActualRunTime > (t.StandardRunTime * 10/100)  
     GROUP BY
      DM.GroupID,
      DM.WasherId,
      DM.WasherNumber,
      DM.WasherName,
      DM.IsPLCConnected,
      DM.DispenserName;
     INSERT INTO @AlarmByMachine
     (
    GroupID,
    WasherID,
    Alarm,
    AlarmDescription
     )
     SELECT
    AlarmByMachine.GroupID,
    AlarmByMachine.WasherID,
    AlarmByMachine.Alarm,
    AlarmByMachine.AlarmDescription
     FROM
     (
     SELECT
    ROW_NUMBER() OVER(PARTITION BY AD.MachineId ORDER BY
    AD.StartDate DESC) AS rownum,
    AD.IsActive AS        Alarm,
    AM.[Description] AS   AlarmDescription,
    AD.MachineId AS       WasherID,
    d.GroupID
     FROM TCD.AlarmData AD
      INNER JOIN TCD.AlarmGroupMaster AM ON AM.
      AlarmGroupMasterId = AD.AlarmGroupMasterId
      INNER JOIN @Dashboardmachinemapping d ON AD.MachineId =
      D.WasherId
     ) AS AlarmByMachine
     WHERE rownum = 1;
     INSERT INTO @BatchEndtimes
     (
    GroupID,
    WasherID,
    CurrentBatchEndTime,
    BatchEndTime
     )
     SELECT
    d.GroupID,
    d.WasherId,
    COUNT(CASE
      WHEN bd.EndDate IS NULL
      THEN 1
      ELSE NULL
      END) AS                    CurrentBatchEndTime,
    CAST(MAX(bd.EndDate) AS TIME) AS BatchEndTime
     FROM @DashboardMachineMapping d
      INNER JOIN TCD.BatchData bd ON d.GroupID = bd.GroupId
         AND d.WasherId = bd.MachineId
     WHERE bd.ShiftId IN
     (
     SELECT
    ShiftId
     FROM @ShiftIds
     )
     GROUP BY
      d.GroupID,
      d.WasherId;
     SELECT
    @StandardTurnTime = ISNULL(ConStdTurnTime, 30)
     FROM tcd.Plant;
     SELECT
    @StandardTurnTime = @StandardTurnTime + ISNULL(
    TargetTurnTime, 0)
     FROM tcd.Washer
     WHERE WasherId = @WasherId;
     SELECT
    @MachineNameDispalyType = ISNULL(MachineNameDispalyType, 0)
     FROM TCD.Dashboard D
     WHERE D.DashboardId = @DashBoardId;
     INSERT INTO @Summarizeddata
     (
    GroupId,
    MachineId,
    WasherName,
    WasherNumber,
    TargetLoad,
    ActualLoad,
    LoadEfficiency,
    TimeEfficiency,
    LostLoad,
    Alarm,
    AlarmDescription,
    WasherStatus,
    MachineNameDispalyType,
    TargetTurnTime,
    DefaultIdleTime,
    IsPLCConnected,
    DispenserName,
    LostBatches
     )
     SELECT
    me.GroupID,
    me.MachineID,
    me.WasherName,
    me.WasherNumber,
    me.StandardProduction AS TargetLoad,
    me.ActualProduction AS   ActulaLoad,
    me.LoadEfficiency,
    me.TimeEfficiency,
    me.MissedLoads AS        LostLoad,
    ISNULL(abm.Alarm, 0) AS  Alarm,
    abm.AlarmDescription,
    CASE
    WHEN be.CurrentBatchEndTime = 1
    THEN 1
    WHEN CAST(GETUTCDATE() AS TIME) BETWEEN be.
    BatchEndTime AND DATEADD(Minute, @StandardTurnTime, be
    .BatchEndTime)
    THEN 2
    WHEN abm.Alarm = 1
    THEN 3
    ELSE 3
    END AS                   WasherStatus,
    @MachineNameDispalyType,
     (
     SELECT
    TargetTurnTime
     FROM TCD.WASHER W
     WHERE W.WasherId = ME.MachineID
     ),
     (
     SELECT
    DefaultIdleTime
     FROM TCD.WASHER W
     WHERE W.WasherId = ME.MachineID
     ),
    me.IsPLCConnected,
    me.DispenserName,
    me.LostBatches
     FROM #MachineEfficiency me
      LEFT JOIN @AlarmByMachine abm ON ME.GroupID = abm.GroupID
           AND ME.MachineID = ABM.
           WasherID
      LEFT JOIN @BatchEndtimes be ON me.GroupID = be.GroupID
         AND me.MachineID = be.
         WasherID;
     SELECT
    GroupId,
    MachineId,
    CASE @Machinenamedispalytype
    WHEN 0
    THEN CAST(WasherNumber AS VARCHAR(20))+' '+WasherName
    WHEN 1
    THEN WasherName
    WHEN 2
    THEN CAST(WasherNumber AS VARCHAR(20))
    END AS WasherName,
    WasherNumber,
	(CASE WHEN (@RegionId=1) THEN ISNULL(TargetLoad,0) ELSE ROUND((ISNULL(TargetLoad,0)*0.453592),0) END) AS TargetLoad,
   (CASE WHEN (@RegionId=1) THEN ISNULL(ActualLoad,0) ELSE ROUND((ISNULL(ActualLoad,0)*0.453592),0) END) AS ActualLoad,
    LoadEfficiency,
    TimeEfficiency,
    (CASE
     WHEN ISNULL(LostLoad, 0) < 0
     THEN 0
     ELSE LostLoad
     END)  LostLoad,
    Alarm,
    AlarmDescription,
    WasherStatus,
    TargetTurnTime,
    DefaultIdleTime,
    IsPLCConnected,
    DispenserName,
    (CASE
     WHEN ISNULL(LostBatches, 0) < 0
     THEN 0
     ELSE LostBatches
     END)  LostBatches
     FROM @Summarizeddata
     ORDER BY
      WasherNumber;  
  
  
     ---- CleanUp  
     DROP TABLE #BatchData;
     DROP TABLE #BatchEfficiency;
     DROP TABLE #MachineEfficiency;
 END;
 GO

--------------------------------------------------END Conventional Dasboard Cal-------------------------------------------

---------------------------------------------------Start W AND E Changes-----------------------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlWAndEAnalogData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlWAndEAnalogData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ProcessMyControlWAndEAnalogData](
	@ControllerID INT,
	@xmlTags      XML)
AS
	BEGIN
	    DECLARE @Reading            DECIMAL(10, 6),
			  @AnalogInputNumber  INT,
			  @MachineCompartment INT,
			  @SensorId           INT,
			  @AnalogCount        INT;
	    CREATE TABLE #AnalogInputData
	    (
		    Number   INT,
		    Quantity DECIMAL(10, 6),
	    );
	    INSERT INTO #AnalogInputData
	    (
			 Number,
			 Quantity
	    )
	    SELECT
			 T.c.value('@CounterNo', 'INT') AS         Number, --AnalogNumber
			 T.c.value('@Reading', 'DECIMAL(10,6)') AS Quantity --Water Quanity
	    FROM @xmlTags.nodes(
			 'MyControlWaterEnergyLoggerAnalogData/AnalogInputData/AnalogData'
					   ) T(C);
	    SET @AnalogInputNumber = 1;
	    WHILE(@AnalogInputNumber <= 8)
		   BEGIN
			  SELECT
				    @SensorId = sr.SensorId,
				    @MachineCompartment = sr.MachineCompartment
			  FROM TCD.Sensor sr
			  WHERE sr.AnalogueInputNumber = @AnalogInputNumber
				   AND sr.ControllerID = @ControllerID;
			  SELECT
				    @Reading = wc.Quantity
			  FROM #AnalogInputData wc
			  WHERE wc.Number = @AnalogInputNumber;
			  --SET @SensorId=1
			  --SET @MachineCompartment=2
			  SELECT
				    @AnalogCount = COUNT(1)
			  FROM TCD.SensorReading
			  WHERE Reading = @Reading
				   AND SensorId = @SensorId;
			  IF(@AnalogCount = 0)
				 BEGIN
					IF(ISNULL(@Reading, 0) > 0
					   AND ISNULL(@SensorId, 0) > 0
					   AND ISNULL(@MachineCompartment, 0) > 0)
					    BEGIN
						   INSERT INTO TCD.SensorReading
						   (
								SensorId,
								Reading,
								TimeStamp
						   )
						   SELECT
								@SensorId,
								@Reading,
								GETUTCDATE();
					    END;
				 END;
				 SET @AnalogInputNumber = @AnalogInputNumber + 1;
		   END;
	END;
	GO
---------------------------------------------------END W AND E Changes------------------------------------------------------------------
---------------------------------------------------Start Production shift rollup temp table (@machineefficiency) changes------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProductionShiftDataRollup]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProductionShiftDataRollup]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ProductionShiftDataRollup](@InputShiftId INT, @RedFlagShiftId INT OUTPUT)
AS
BEGIN
	SET NOCOUNT ON
    DECLARE @DayId INT = NULL,
	@ShiftId Int = NULL,
	@ShiftName Varchar(100) = NULL,
	@StartTime DateTime = NULL,
	@EndTime DateTime = NULL,
	@DateStartTime DATETIME= NULL,
	@DateEndTime DATETIME= NULL,
	@BatchUTCStart DATETIME= NULL,
	@BatchUTCEnd DATETIME= NULL,
	@ShiftTargetProd Decimal(18,2) = NULL,
	@ConStdTurnTime Int= NULL,
	@ActualRunandConTurnTime Int= NULL,
	@TargetRunandConTurnTime Int= NULL,
	@ActualRunandTunTurnTime Int= NULL,
	@TargetRunandTunTurnTime Int= NULL,
	@SummationProduction Int,
	@NoOfLoads INT,@prevDay INT,@Rollingcount int = 1        
	,@RowCount int = NULL,@RealDayId Int,@ShiftCount Int = 1,@LabourShift int
	,@EcolabAccountNumber NVARCHAR(25) = NULL
		
	--SELECT * FROM TCD.WeekDay  SELECT DATENAME(dw,GETDATE()) 

    SELECT @DayId = DayId FROM [TCD].WeekDay WITH (NOLOCK) WHERE DayName = DATENAME(dw,GETDATE()) 

    SELECT @prevDay = CASE WHEN @DayId = 1 THEN 7 ELSE @DayId - 1 END
    SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant 

    DECLARE @BatchShiftTable TABLE
						(
						  RowNumber int IDENTITY(1,1),
						  BatchUTCStartDate datetime,
						  BatchUTCEndDate datetime,
						  ShiftId int
						)

    DECLARE @Result TABLE
				    (
				    StartDate Datetime,
				    EndDate Datetime,
				    ShiftId INT,
				    ShiftName Varchar(1000),
				    DayID Int,
				    TargetProduction [decimal](18,2)
				    )

    DECLARE @shiftdata_temp TABLE
						  (
						  SNo INT IDENTITY(1,1),
						  [ShiftId] [int],
						   [ShiftName] [nvarchar](1000) ,
						   [DayId] [int] ,
						   [StartTime] [time](7) ,
						   [EndTime] [time](7) ,
						   [TargetProduction] [decimal](18, 2) ,
						   [Is_Deleted] [bit] ,
						   [EcolabAccountNumber] [nvarchar](1000) ,
						   [LastModifiedByUserId] [int] ,
						   [LastModifiedTime] [datetime] ,
						   [LastSyncTime] [datetime],
						   [TargetProduction_Display] [decimal](18, 2) 
						   )        
    INSERT INTO @shiftdata_temp
     SELECT 
		    [ShiftId] ,           
		    [ShiftName],		
		    [DayId],              
		    [StartTime],          
		    [EndTime],            
		    [TargetProduction] , 
		    [Is_Deleted],        
		    [EcolabAccountNumber],
		    [LastModifiedByUserId],
		    [LastModifiedTime],	
		    [LastSyncTime],
		    [TargetProduction_Display]		
	 FROM TCD.ShiftData WITH (NOLOCK) WHERE (DayId = @DayId OR (DayId = @prevDay AND (EndTime < StartTime OR EndTime = StartTime))) AND IS_Deleted = 0  
	 ORDER BY DayId
	 
	UPDATE @shiftdata_temp SET DayId = CASE WHEN @DayId = 1 THEN 0 ELSE DayId END WHERE DayId = 7
	UPDATE @shiftdata_temp SET DayId = CASE WHEN @DayId = 7 THEN 8 ELSE DayId END WHERE DayId = 1

	 SELECT @RowCount = SNo FROM @shiftdata_temp 

	WHILE(@Rollingcount <=  @RowCount)        
    BEGIN        
			DECLARE @VALIDSTART DATETIME,@VALIDEND DATETIME    
		    SELECT @VALIDSTART = CASE WHEN DayId > @DayId THEN  DATEADD(day, DATEDIFF(day, -1, GETDATE()), CAST(starttime AS datetime))
								 WHEN DayId < @DayId THEN   DATEADD(day, DATEDIFF(day, 1, GETDATE()), CAST(starttime AS datetime)) 
														ELSE
														 DATEADD(day, DATEDIFF(day, 0, GETDATE()), CAST(starttime AS datetime)) END		    ,
				   @VALIDEND =  CASE WHEN ((DayId > @DayId AND EndTime > StartTime) OR (DayId = @DayId AND (EndTime = StartTime OR EndTime < StartTime))) THEN 
													   DATEADD(day, DATEDIFF(day,-1, GETDATE()), CAST(EndTime AS datetime))
								 WHEN (DayId < @DayId AND (EndTime < StartTime OR EndTime = StartTime)) THEN 
													    DATEADD(day, DATEDIFF(day, 0, GETDATE()), CAST(EndTime AS datetime))
								 WHEN (DayId > @DayId AND (EndTime < StartTime OR EndTime = StartTime)) THEN 
												    	  DATEADD(day, DATEDIFF(day,-2, GETDATE()), CAST(EndTime AS datetime))						 
								 					   ELSE
														  DATEADD(day, DATEDIFF(day, 0, GETDATE()), CAST(EndTime AS datetime)) 
														  END,@ShiftId = ShiftId,@ShiftName = ShiftName,@RealDayId = DayId,@ShiftTargetProd = TargetProduction
					    FROM @shiftdata_temp WHERE SNo = @Rollingcount 

					    INSERT INTO @Result(StartDate,EndDate,ShiftId,ShiftName,DayID,TargetProduction)
					    SELECT @VALIDSTART,@VALIDEND,@ShiftId,@ShiftName,@RealDayId,@ShiftTargetProd

		        
			SET @Rollingcount = @Rollingcount + 1        
    END        

	
    SELECT DISTINCT @StartTime = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(StartDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(StartDate AS time)) AS DateTime)),
				@EndTime = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(EndDate AS time)) AS DateTime)),
				@ShiftId = ShiftId,@ShiftName = ShiftName,@DayId = DayID,@ShiftTargetProd = TargetProduction  FROM @Result
	WHERE GETDATE() BETWEEN StartDate AND EndDate

    SELECT @LabourShift = @ShiftId

    IF(@StartTime IS NULL AND @EndTime IS NULL)
    BEGIN
		SELECT @ShiftId = NULL,@ShiftName = NULL,@ShiftTargetProd = NULL
    END
   
	IF(COUNT(@ShiftId) <> 1)      ---NO shift Timings
	BEGIN
		SELECT TOP 1 @StartTime = EndTime FROM [TCD].ShiftData WITH (NOLOCK)
		WHERE DayId = @DayId 
			AND Is_Deleted = 0
			AND EndTime < CONVERT(TIME, CONVERT(VARCHAR(20), GETDATE(), 120)) ORDER BY EndTime DESC
			
		SELECT TOP 1 @EndTime = StartTime  FROM [TCD].ShiftData WITH (NOLOCK)
		WHERE DayId = @DayId 
			AND Is_Deleted = 0
			AND CONVERT(TIME, CONVERT(VARCHAR(20), GETDATE(), 120)) < StartTime ORDER BY StartTime	
					
			IF(COUNT(@StartTime) <> 1)
				BEGIN
					SELECT @StartTime = CAST(dateadd(DAY, datediff(day, 0, getdate()),0) AS dateTime)
				END
					ELSE
				BEGIN
					SELECT @StartTime = DATEADD(day, DATEDIFF(day, 0, GETDATE()),@StartTime)
				END

			IF(COUNT(@EndTime) <> 1)
				BEGIN
					SELECT @EndTime =  CAST(DATEADD(s, -1, DATEADD(day, 1,CONVERT(DATETIME, CONVERT(DATE, GETDATE())))) AS dateTime)
				END
					ELSE
				BEGIN
					SELECT @EndTime = DATEADD(day, DATEDIFF(day, 0, GETDATE()),@EndTime)
				END

		SET @StartTime = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@StartTime AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@StartTime AS time)) AS DateTime))
		SET @EndTime = 	dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndTime AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndTime AS time)) AS DateTime))		  

	END    	    

 	 --SET @ShiftId = CASE WHEN COUNT(@ShiftId) <> 1 THEN 0 ELSE @ShiftId END
	 ----- Inserting the meta data into shift production base table -------

      ----------------/* Getting the Target Production from TargetProduction details if exists else in shift data page */---------------

    IF ((SELECT COUNT(1) FROM TCD.TARGETPRODUCTIONDETAILS AS T WITH (NOLOCK) WHERE DayId = @DayId AND T.ShiftId = @ShiftId) = 1)
	BEGIN
		SELECT @ShiftTargetProd = TPD.TargetProduction FROM TCD.TARGETPRODUCTIONDETAILS TPD  WITH (NOLOCK)
		WHERE DayId = @DayId AND TPD.ShiftId = @ShiftId
	END
	   
		  
	--DELETE FROM TCD.ProductionShiftData WHERE ShiftId = @ShiftId AND CAST(StartDateTime AS date) = CAST(GETDATE() AS date)
	IF NOT EXISTS (SELECT 1 FROM [TCD].ProductionShiftData WITH (NOLOCK) WHERE StartDateTime = @StartTime )
	BEGIN
		--DECLARE @Count INt 
		--SELECT @Count = MAX(ShiftId) FROM [TCD].ProductionShiftData WITH (NOLOCK)

		UPDATE TCD.ProductionShiftData
		SET				        
			TCD.ProductionShiftData.EndDateTime = @StartTime
			WHERE TCD.ProductionShiftData.EndDateTime > @StartTime

		SELECT TOP 1 @RedFlagShiftId=ShiftId FROM [TCD].ProductionShiftData WHERE StartDateTime < @StartTime ORDER BY StartDateTime DESC

		INSERT INTO [TCD].ProductionShiftData (
										-- [ShiftId],
											[ShiftName],
											[StartDateTime],
											[EndDateTime],
											[TargetProduction],
											[EcolabAccountNumber]
										) 
		SELECT  --CASE WHEN COUNT(@Count) <> 1 THEN 1 ELSE @Count + 1 END,
			CASE WHEN COUNT(@ShiftName) <> 1 THEN 'No Shift' ELSE @ShiftName END,
			@StartTime,
			@EndTime,
			ISNULL(@ShiftTargetProd,0),
			@EcolabAccountNumber				    			
	END
	
	IF(@InputShiftId > 0)
	BEGIN
	 INSERT INTO @BatchShiftTable
	 (
	    
	    BatchUTCStartDate,
	    BatchUTCEndDate,
	    ShiftId
	 )
		 SELECT StartDateTime,
			EndDateTime,
			ShiftId	 
			FROM [TCD].ProductionShiftData SD WITH (NOLOCK)  WHERE ShiftId=@InputShiftId
	END
	
	ELSE
	BEGIN		
		 INSERT INTO @BatchShiftTable
		 (
	    
			BatchUTCStartDate,
			BatchUTCEndDate,
			ShiftId
		 )
	 SELECT TOP 2 
		StartDateTime,
		EndDateTime,
		ShiftId	 
			FROM [TCD].ProductionShiftData SD WITH (NOLOCK)  ORDER BY SD.StartDateTime DESC 
    END
	   ------------------******// Inserting the Data into Batch Summary Temp table based on UTC shift timings //******-----------------------
    WHILE (@ShiftCount <= (SELECT COUNT(1) FROM @BatchShiftTable bst))
    BEGIN

     /* Picking up the first record from the top 2 records of production shift data */

	SELECT  @BatchUTCStart = bst.BatchUTCStartDate,
	@BatchUTCEnd =bst.BatchUTCEndDate,  @ShiftId = bst.ShiftId
	FROM @BatchShiftTable bst WHERE bst.RowNumber = @ShiftCount
					  
	DECLARE @BatchSummary TABLE
				(
				   RowNumber Int,
				   BatchId Int,
				   ActualWeight Int,
				   StandardWeight Int,
				   MachineId Int,
				   EcolabWasherId Int,
				   StartDate datetime2,
				   EndDate datetime2,
				   ProgramNumber Int,
				   ProgramMasterId Int,
				   CustomerId Int,
				   PiecesCount int,
				   ManualInputWeight int,
				   TargetTurnTime INT,
				   EcolabTextileId INT,
				   ChainTextileId  INT ,
				   PlantProgaramId INT
				)

    INSERT INTO @BatchSummary
		(
		RowNumber ,
		BatchId ,
		ActualWeight ,
		StandardWeight ,
		MachineId ,
		EcolabWasherId ,
		StartDate ,
		EndDate ,
		ProgramNumber,
		ProgramMasterId ,
		CustomerId ,
		PiecesCount ,
		ManualInputWeight ,
		TargetTurnTime ,
		EcolabTextileId ,
		ChainTextileId  ,
		PlantProgaramId 		
		)
	   SELECT 
				  ROW_NUMBER() OVER(PARTITION BY BD.MachineId ORDER BY BD.StartDate) RowNumber,
				   BD.BatchId,
				   ActualWeight,
				   StandardWeight,
				   MachineId,
				   BD.EcolabWasherId,
				   StartDate,
				   EndDate,
				   ProgramNumber,
				   ProgramMasterId,
				   BCD.CustomerId,
				   BCD.PiecesCount,
				   BD.ManualInputWeight,
				   BD.TargetTurnTime,
				   BD.EcolabTextileCategoryId,
				   BD.ChainTextileCategoryId,
				   BD.PlantProgramId
			 FROM TCD.BatchData BD WITH (NOLOCK)
					   INNER JOIN TCD.MachineSetup MS WITH (NOLOCK) ON MS.WasherId = BD.MachineId 
				    LEFT OUTER JOIN 
				 TCD.BatchCustomerData BCD WITH (NOLOCK) ON BD.BatchId = BCD.BatchId
			  WHERE BD.EndDate >= @BatchUTCStart AND BD.EndDate <= @BatchUTCEnd 

	   
	------------------******// Inserting the Data into Chemical temp table  //******-----------------------

	DECLARE @BatchChemicalSummary TABLE
				(
				   BatchId Int,
				   EcolabWasherId Int,
				   StartDate datetime2,
				   EndDate datetime2,
				   MachineId Int,
				   ProgramMasterId Int,
				   ProductId Int,
				   ActualQuantity Decimal(18,2),
				   StandardQuantity Decimal(18,2),
				   Price Decimal(18,2),
				   CustomerId Int,
				   EcolabTextileId INT,
				   ChainTextileId  INT ,
				   PlantProgaramId INT
				  			   
				)

    INSERT INTO @BatchChemicalSummary
		(
			BatchId,
			EcolabWasherId ,
			StartDate ,
			EndDate ,
			MachineId ,
			ProgramMasterId ,
			ProductId ,
			ActualQuantity ,
			StandardQuantity ,
			Price ,
			CustomerId ,
			EcolabTextileId ,
			ChainTextileId   ,
			PlantProgaramId 
		
		)
	   SELECT 
				   BD.BatchId,
				   BD.EcolabWasherId,
				   StartDate,
				   EndDate,
				   MachineId,
				   ProgramMasterId,
				   BPD.ProductId,
				   BPD.ActualQuantity,
				   BPD.StandardQuantity,
				   BPD.Price,
				   BCD.CustomerId,
				   BD.EcolabTextileCategoryId,
				   BD.ChainTextileCategoryId,
				   BD.PlantProgramId
			 FROM  TCD.BatchProductData BPD	WITH (NOLOCK)				   
					   INNER JOIN TCD.BatchData BD WITH (NOLOCK) ON BD.BatchId = BPD.BatchId
					   INNER JOIN TCD.MachineSetup MS WITH (NOLOCK) ON MS.WasherId = BD.MachineId 
					   LEFT OUTER JOIN TCD.ProductMaster PD WITH (NOLOCK) ON PD.ProductId = BPD.ProductId
					   LEFT OUTER JOIN  TCD.BatchCustomerData BCD WITH (NOLOCK) ON BD.BatchId = BCD.BatchId
					   WHERE BD.EndDate >= @BatchUTCStart AND BD.EndDate <= @BatchUTCEnd

	SELECT @NoOfLoads = COUNT(DISTINCT BatchId) FROM @BatchSummary
  
	------------------******// Inserting the Data into Machine Efficiency Temp table for runtimes based on machines //******-----------------------

	

	DECLARE @MachineEfficency TABLE
					   ( 
						  MachineId INT,
						  ProgramMasterId INT,
						  ActualRunTime INT, 
						  StandardRunTime BIGINT,
						  ActualTurnTime BIGINT,
						  StandardTurnTIme INT
					   )

    INSERT INTO @MachineEfficency
					   ( 
						  MachineId,
						  ProgramMasterId,
						  ActualRunTime , 
						  StandardRunTime,
						  ActualTurnTime,
						  StandardTurnTIme
					   )
	   SELECT 
			DISTINCT
			  CUR.MachineId,CUR.ProgramMasterId,	   
			 CAST(SUM(DATEDIFF(SECOND,CUR.StartDate,CUR.EndDate)) AS decimal(18,2)),
			 ISNULL(SUM(WPS.TotalRunTime),1),--+ @ConStdTurnTime + ISNULL(SUM(WPS.ExtraTime),1),
			 ISNULL(SUM( CASE WHEN DATEDIFF(SECOND,CUR.EndDate,nexting.StartDate) < 0 THEN 0 ELSE  DATEDIFF(SECOND,CUR.EndDate,nexting.StartDate) END),1),
			 ISNULL(SUM(CUR.TargetTurnTime),1)
	    FROM @BatchSummary CUR 
				LEFT OUTER JOIN @BatchSummary nexting ON cur.RowNumber = nexting.RowNumber - 1 AND CUR.MachineId = nexting.MachineId --AND CUR.ProgramMasterId = nexting.ProgramMasterId
				INNER JOIN TCD.MachineSetup MS WITH (NOLOCK) ON MS.WasherId = CUR.MachineId AND MS.IsTunnel = 0 AND MS.IsDeleted = 0
				LEFT JOIN TCD.WasherProgramSetup WPS WITH (NOLOCK) ON WPS.ProgramId = CUR.ProgramMasterId AND MS.GroupId = WPS.WasherGroupId AND WPS.Is_Deleted = 0
				GROUP BY CUR.MachineId,CUR.ProgramMasterId
	   UNION ALL

	   SELECT 
			DISTINCT
			CUR.MachineId,CUR.ProgramMasterId,
			 CAST(SUM(DATEDIFF(SECOND,CUR.StartDate,CUR.EndDate)) AS decimal(18,2)),			
			 ISNULL(SUM(TPS.TotalRunTime),1),
			SUM(COALESCE(3600/NULLIF(COALESCE(DATEDIFF(SECOND,CUR.StartDate,CUR.EndDate)/ NULLIF(MS.NumberOfComp,0),0) ,0), 0)) ,
			 SUM(COALESCE(3600/NULLIF(COALESCE(TPS.TotalRunTime/ NULLIF(MS.NumberOfComp,0),0) ,0), 0)) --+ ISNULL(SUM(TPS.ExtraTime),1)
	   FROM @BatchSummary CUR
				INNER JOIN TCD.MachineSetup MS WITH (NOLOCK) ON MS.WasherId = CUR.MachineId AND MS.IsTunnel = 1 AND MS.IsDeleted = 0
				        LEFT JOIN TCD.TunnelProgramSetup TPS WITH (NOLOCK) ON TPS.ProgramId = CUR.ProgramMasterId AND MS.GroupId = TPS.WasherGroupId AND TPS.Is_Deleted = 0
		  GROUP BY CUR.MachineId,CUR.ProgramMasterId

	--------------------------******// Inserting the Data into production Shift Rollup Data Table //******-------------------
	      		  
		 
	DELETE FROM [TCD].ShiftProductionDataRollup WHERE ShiftId = @ShiftId 
		 
	INSERT INTO [TCD].ShiftProductionDataRollup
							 (
								ShiftId,
								MachineId,
								ProgramMasterId,
								EcolabWasherId,
								NoOfLoads,
								ActualProduction ,
								StandardProduction,
								LoadEfficiency,
								TimeEfficiency,
								PlantTargetProd ,
								ActualRunTime,
								TargetRunTime,
								EcolabTextileId,
								ChainTextileId,
								ChainProgaramId,
								CustomerId,
								NoOfPieces,
								ActualTurnTime,
								TargetTurnTime
							 )	


		  SELECT 
				DISTINCT
					 @ShiftId,
				      CUR.MachineId,
					 CUR.ProgramMasterId,
					 CUR.EcolabWasherId,
					 COUNT(1),
					 SUM(CUR.ActualWeight) + ISNULL(SUM(CUR.ManualInputWeight),0),
					 SUM(CUR.StandardWeight),

					 CAST(COALESCE(((SUM(CUR.[ActualWeight]))/ NULLIF(ISNULL(SUM(CUR.[StandardWeight]),SUM(CUR.[ActualWeight])),0)), 0) AS decimal(18,2)),

					 --CAST(((SUM(CUR.[ActualWeight]))/ISNULL(SUM(CUR.[StandardWeight]),SUM(CUR.[ActualWeight]))) AS decimal(18,2)),

					 CAST(COALESCE(CAST(SUM(ME.StandardRunTime) AS Decimal(18,2))/ NULLIF(ISNULL(CAST(SUM(ME.ActualRunTime) AS decimal(18,2)),CAST(SUM(ME.ActualRunTime) AS Decimal(18,2))),0), 0) AS decimal(18,2)) ,

					 --CAST(CAST(SUM(ME.ActualRunTime) AS Decimal(18,2))/ISNULL(CAST(SUM(ME.StandardRunTime) AS decimal(18,2)),CAST(SUM(ME.ActualRunTime) AS Decimal(18,2))) AS decimal(18,2)) ,
			 		 @ShiftTargetProd * 1000,					 
					 COALESCE(SUM(ME.ActualRunTime) / NULLIF(COUNT(1),0), 0), 
					 COALESCE(ISNULL(SUM(ME.StandardRunTime),SUM(ME.ActualRunTime))/ NULLIF(COUNT(1),0), 0), 

					 CUR.EcolabTextileId,CUR.ChainTextileId,CUR.PlantProgaramId,
					 --ETC.TextileId,CTC.TextileId,PCP.PlantProgramId,
					 CUR.CustomerId,
				      SUM(CUR.PiecesCount),
					 COALESCE(SUM(ME.ActualTurnTime) / NULLIF(COUNT(1),0), 0),
					 COALESCE(ISNULL(SUM(ME.StandardTurnTIme),SUM(ME.ActualTurnTime))/ NULLIF(COUNT(1),0), 0)
							 FROM 
					   @BatchSummary CUR 
						  LEFT JOIN 
								@MachineEfficency ME ON CUR.MachineId = ME.MachineId AND CUR.ProgramMasterId = ME.ProgramMasterId
						  LEFT JOIN 
								 TCD.ProgramMaster PM WITH (NOLOCK) ON PM.ProgramId = CUR.ProgramMasterId
						/*
						  LEFT JOIN
								TCD.EcolabTextileCategory ETC WITH (NOLOCK) ON ETC.TextileId = PM.EcolabTextileCategoryId
						  LEFT JOIN
								TCD.ChainTextileCategory CTC WITH (NOLOCK) ON  CTC.TextileId = PM.ChainTextileId
						  LEFT JOIN
								TCD.PlantChainProgram PCP ON PCP.PlantProgramId = PM.PlantProgramId
						*/
						  GROUP BY CUR.MachineId,CUR.EcolabWasherId,CUR.ProgramMasterId,--ETC.TextileId,CTC.TextileId,PCP.PlantProgramId,
						  CUR.EcolabTextileId,CUR.ChainTextileId,CUR.PlantProgaramId,
						  CUR.CustomerId


	--------------------------******// Inserting the Data into Chemical Shift Rollup Data Table //******-------------------
	  	  
		 
	DELETE FROM [TCD].[ShiftChemicalDataRollup] WHERE ShiftId = @ShiftId 

	INSERT INTO [TCD].[ShiftChemicalDataRollup]
							 (
								 [ShiftId] ,
								 [MachineId],
								 [ProgramMasterId],
								 [EcolabWasherId],
								 [ProductId],
								 [ActualConsumption],
								 [TargetConsumption],
								 [ActualCost],
								 [EcolabTextileId],
								 [ChainTextileId],
								 [ChainProgaramId],
								 [CustomerId],
								 NoOfLoads
							 )
				SELECT
				    DISTINCT 
						  @ShiftId,
						  CUR.MachineId,
						  CUR.ProgramMasterId,
						  CUR.EcolabWasherId,
						  CUR.ProductId,
						  SUM(CUR.ActualQuantity),
						  SUM(CUR.StandardQuantity),
						  SUM(CUR.Price),
						  CUR.EcolabTextileId,
						  CUR.ChainTextileId,
						  CUR.PlantProgaramId,
						  CUR.CustomerId,
						  @NoOfLoads
						  FROM 
						  @BatchChemicalSummary CUR 
						   LEFT JOIN 
								 TCD.ProgramMaster PM WITH (NOLOCK) ON PM.ProgramId = CUR.ProgramMasterId
						  --LEFT JOIN
								--TCD.EcolabTextileCategory ETC WITH (NOLOCK) ON ETC.TextileId = PM.EcolabTextileCategoryId
						  --LEFT JOIN
								--TCD.ChainTextileCategory CTC WITH (NOLOCK) ON  CTC.TextileId = PM.ChainTextileId
						  --LEFT JOIN
								--TCD.PlantChainProgram PCP WITH (NOLOCK) ON PCP.PlantProgramId = PM.PlantProgramId
						  GROUP BY CUR.MachineId,CUR.EcolabWasherId,CUR.ProgramMasterId,CUR.ProductId,CUR.CustomerId,CUR.EcolabTextileId,CUR.ChainTextileId,CUR.PlantProgaramId

		IF NOT EXISTS (SELECT 1 FROM [TCD].[ProductionShiftLaborData] WHERE ShiftId = @ShiftId)
			BEGIN
				INSERT INTO [TCD].[ProductionShiftLaborData]
				SELECT  @ShiftId,
				SLD.LaborTypeId,
				SLD.LaborHours,
				SLD.LaborHours * SLD.PricePerHr
					FROM [TCD].[ShiftLaborData] SLD WITH (NOLOCK) WHERE ShiftId = @LabourShift AND DayId = @DayId
			END
		  
		  DELETE FROM @BatchSummary
		  DELETE FROM @BatchChemicalSummary
		  DELETE FROM @MachineEfficency
		  
	    SET @ShiftCount = @ShiftCount + 1
	END

SET NOCOUNT OFF
END
GO
---------------------------------------------------END Start Production shift rollup temp table (@machineefficiency) changes--------------------
------------------------------------------------Start Conventional Production injection steps query change------------------

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlConventionalData_CompletedBatches]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlConventionalData_CompletedBatches]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessMyControlConventionalData_CompletedBatches](
	@ControllerID   INT,
	@VxML           XML,
	@PLCPointer     INT,
	@ReadPointer    INT,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @MachineNumber           INT,
			  @StartDateTime           DATETIME,
			  @EndDateTime             DATETIME,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @PHValue                 INT,
			  @TemperatureMin          INT,
			  @TemperatureMax          INT,
			  @TempMinStatus           INT,
			  @TempMaxStatus           INT,
			  @BatchNumber             INT,
			  @WasherID                INT,
			  @WasherGroupID           INT,
			  @EcoLabWasherID          INT,
			  @ProgramMasterID         INT,
			  @PlantWasherNumber       INT,
			  @ShiftID                 INT,
			  @BatchID                 INT,
			  @ShiftStartdate          DATETIME,
			  @LastStep                INT,
			  @CurrentStep             INT,
			  @CurrentStepTime         DATETIME,
			  @MinTempParamID          INT,
			  @MaxTempParamID          INT,
			  @MinTempStatuParamID     INT,
			  @MaxTempStatusParamID    INT,
			  @PHStatusParamID         INT,
			  @PHValueParamID          INT,
			  @CurrencyCode            VARCHAR(50),
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @ActualInjSteps          INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @TargetTurnTime          INT,
			  @PreviousShiftId         INT,
			  @CurrentShiftId          INT,
			  @MeterID                 INT,
			  @StepComportment         INT,
			  @Stepno                  INT,
			  @quantity                INT,
			  @productid               INT,
			  @Price                   DECIMAL(18, 4),
			  @StandardQty             DECIMAL(18, 4),
			  @TimeStamp               DATETIME2(7),
			  @MaxWashertGroupCapacity INT,
			  @InjectionNumber         INT,
			  @WaterConsumption1       DECIMAL(10,6),
			  @WaterConsumption2       DECIMAL(10,6),
			  @EnergyCount             INT,
			   @EcolabAccountNumber    NVARCHAR(25),
	           @AlarmGroupMasterId     INT;
	    SELECT
			 @MachineNumber = T.c.value('@MachineNumber', 'INT'),
			 @StartDateTime = T.c.value('@StartDateTime', 'DateTime'),
			 @EndDateTime = T.c.value('@EndDateTime', 'DateTime'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@NominalLoad', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'INT'),
			 @PHStatus = T.c.value('@PHStatus', 'INT'),
			 @PHValue = T.c.value('@PHValue', 'INT'),
			 @TemperatureMin = T.c.value('@TemperatureMin', 'INT'),
			 @TemperatureMax = T.c.value('@TemperatureMax', 'INT'),
			 @TempMaxStatus = T.c.value('@TemperatureMaxStatus', 'INT'),
			 @TempMinStatus = T.c.value('@TemperatreMinStatus', 'INT'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @WaterConsumption1 = T.c.value('@WaterConsumption1','DECIMAL(10,6)'),
			 @WaterConsumption2 = T.c.value('@WaterConsumption2','DECIMAL(10,6)')
	    FROM @VxML.nodes('MyControlConventionalData') T(C);

	    DECLARE @ShiftMapping TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    INSERT INTO @ShiftMapping
	    (
			 ShiftId,
			 ShiftName,
			 ShiftStartdate
	    )
	    EXEC TCD.GetShiftStartDate
		    @StartDateTime;
	    SELECT
			 @ShiftID = ShiftID,
			 @ShiftStartdate = ShiftStartdate
	    FROM @ShiftMapping;
	    SELECT
			 @WasherGroupID = GroupId,
			 @WasherID = WasherID
	    FROM TCD.MachineSetup ms
	    WHERE ControllerID = @ControllerID
			AND MachineInternalId = @MachineNumber
			AND IsTunnel = 0
			AND IsDeleted = 0;
	    IF(@WasherId IS NOT NULL)
		   BEGIN
			  SELECT
				    @ProgramMasterId = Wps.ProgramId
			  FROM TCD.Washer Ws
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws
				  .WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =
				  Mst.GroupId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.
				  ControllerID = Wg.ControllerId
				  INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber =
				  Ws.EcoLabAccountNumber
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wps.Is_Deleted = 0;
			  SELECT
				    @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber,
				    @CurrencyCode = P.CurrencyCode,
				    @TargetTurnTime = w.TargetTurnTime * 60
			  FROM TCD.Washer w
				  INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.
				  EcolabAccountNumber
			  WHERE w.WasherId = @WasherID;
		   END;
	    SELECT
			 @BatchID = BatchID
	    FROM TCD.BatchData
	    WHERE MachineInternalID = @MachineNumber
			AND StartDate = @StartDateTime
			AND ControllerBatchId = @BatchNumber
			AND MachineID = @WasherID;

	    --Start Getting InjectionCount and StepCount

	    SELECT
			 @StdInjectionSteps = COUNT(DISTINCT wdpm.
			 WasherDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) -
			 COUNT(DISTINCT wdpm.WasherDosingSetupId)
	    FROM TCD.WasherDosingProductMapping wdpm
		    RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm.
		    WasherDosingSetupId = wds.WasherDosingSetupId
	    WHERE wds.ControllerID = @ControllerID
			AND wds.ProgramNumber = @ProgramNumber;

	    --End Getting InjectionCount and StepCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT
			 @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramMasterId
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT
				    @EcolabTextileCategoryId = pcp.
				    EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp.
				    ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    IF(@BatchID IS NULL)
		   BEGIN

			  --Start Rollup for previous completed shift
			  IF(CAST(@StartDateTime AS DATE) < CAST(GETUTCDATE() AS
			  DATE))
				 BEGIN
					SELECT TOP 1
						  @PreviousShiftId = ShiftId
					FROM TCD.BatchData
					WHERE MachineId = @WasherId
					ORDER BY
						    StartDate DESC;
					SELECT TOP 1
						  @CurrentShiftId = ShiftId
					FROM @ShiftMapping;
					IF(@CurrentShiftId != @PreviousShiftId)
					    BEGIN
						   EXEC TCD.ProductionShiftDataRollup
							   @PreviousShiftId,
							   @RedFlagShiftId OUTPUT;
						   IF(@RedFlagShiftId IS NULL)
							  BEGIN
								 SET @RedFlagShiftId =
								 @PreviousShiftId;
							  END;
					    END;
				 END;
			  --End Rollup for previous completed shift

			  INSERT INTO TCD.BatchData
			  (
				    ControllerBatchID,
				    EcolabWasherId,
				    GroupId,
				    MachineInternalId,
				    PlantWasherNumber,
				    StartDate,
				    EndDate,
				    ProgramNumber,
				    ProgramMasterId,
				    MachineID,
				    ActualWeight,
				    StandardWeight,
				    CurrencyCode,
				    ShiftId,
				    PartitionOn,
				    StdInjectionSteps,
				    StdWashSteps,
				    EcolabTextileCategoryId,
				    ChainTextileCategoryId,
				    FormulaSegmentId,
				    EcolabSaturationId,
				    PlantProgramId,
				    EndDateFormula,
				    TargetTurnTime
			  )
			  VALUES
			  (
				    @BatchNumber,
				    @EcoLabWasherID,
				    @WasherGroupID,
				    @MachineNumber,
				    @PlantWasherNumber,
				    @StartDateTime,
				    @EndDateTime,
				    @ProgramNumber,
				    @ProgramMasterId,
				    @WasherID,
				    @Load,
				    @NominalLoad,
				    @CurrencyCode,
				    @ShiftID,
				    @ShiftStartdate,
				    @StdInjectionSteps,
				    @StdWashSteps,
				    @EcolabTextileCategoryId,
				    @ChainTextileCategoryId,
				    @FormulaSegmentId,
				    @EcolabSaturationId,
				    @PlantProgramId,
				    @EndDateTime,
				    @TargetTurnTime
			  );
			  SELECT
				    @BatchID = SCOPE_IDENTITY();
			  IF NOT EXISTS
			  (
				 SELECT
					   *
				 FROM TCD.BatchParameters
				 WHERE BatchId = @BatchID
					  AND ParameterID = 38
			  )
				 BEGIN
					IF(@StdWashSteps > 0
					   OR @StdWashSteps <> NULL)
					    INSERT INTO TCD.BatchParameters
					    (
							 BatchId,
							 EcolabWasherId,
							 ParameterId,
							 ParameterValue,
							 PartitionOn
					    )
					    SELECT
							 @BatchID,
							 @EcoLabWasherID,
							 38,
							 @StdWashSteps,
							 @ShiftStartdate;
				 END;
		   END;
	    ELSE
		   BEGIN
			  UPDATE tcd.BatchData
			    SET
				   EndDate = @EndDateTime,
				   EndDateFormula = @EndDateTime,
				   ProgramNumber = @ProgramNumber,
				   ProgramMasterId = @ProgramMasterID,
				   ActualWeight = @Load,
				   SyncReady = 1
			  WHERE
				   BatchID = @BatchID;
		   END;
		      --If the received formula is not configured in enVision then create an alarm 
       IF(@ProgramMasterId is NULL)
       BEGIN
       SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant;
       SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.AlarmGroupMsterVsControllerModelType AGMVCMT
       INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
       WHERE AGMVCMT.AlarmCode = 9000
        INSERT INTO [TCD].[AlarmData] 
           (EcoalabAccountNumber,
           AlarmCode,
           BatchId,
           controllerID,
           StartDate,
           GroupId,
           MachineInternalId,
           ProgramId,   
           IsActive,
           EndDate,
           MachineId,
           AlarmGroupMasterId)
           SELECT
            @ECOLABAccountNumber,
            9000,
            @BatchID,
            @ControllerId,
            @StartDateTime,
            @WasherGroupID,
            @MachineNumber,
            @ProgramNumber,
            0,
            @StartDateTime,
            @WasherId,
            @AlarmGroupMasterId
       END





	    IF NOT EXISTS
	    (
		   SELECT
				1
		   FROM [TCD].[BatchCustomerData]
		   WHERE BatchID = @BatchId
			    AND @CustomerNumber IS NOT NULL
	    )
		   BEGIN
			  INSERT INTO [TCD].[BatchCustomerData]
			  (
				    [BatchId],
				    CustomerID,
				    [Weight],
				    PartitionOn,
				    EcolabWasherId
			  )
			  VALUES
			  (
				    @BatchID,
				    @CustomerNumber,
				    @Load,
				    @ShiftStartdate,
				    @EcolabWasherID
			  );
		   END;
	    ELSE
	    IF(@CustomerNumber > 0)
		   BEGIN
			  UPDATE [TCD].[BatchCustomerData]
			    SET
				   CustomerID = @CustomerNumber,
				   [Weight] = @Load
			  WHERE
				   BatchID = @BatchId;
		   END;
	    CREATE TABLE #Dosing
	    (
		    equipmentNo INT,
		    StepNo      INT,
		    Qty         DECIMAL(10, 6)
	    );
	    INSERT INTO #Dosing
	    SELECT
			 T.c.value('@Equipment', 'INT'),
			 T.c.value('@stepNo', 'INT'),
			 T.c.value('@Qty', 'Decimal(10,6)')
	    FROM @VxML.nodes('MyControlConventionalData/DosingData/Dosing') T
	    (C)
	    WHERE T.c.value('@Qty', 'Decimal(10,6)') > 0;
	    CREATE TABLE #StepTime
	    (
		    Number    INT,
		    [Time]    INT,
		    StartTime DATETIME,
		    EndTime   DATETIME
	    );
	    INSERT INTO #StepTime
	    (
			 Number,
			 [Time]
	    )
	    SELECT
			 T.c.value('@Number', 'INT'),
			 T.c.value('@Time', 'INT')
	    FROM @VxML.nodes('MyControlConventionalData/StepTime/Step') T(C);
	    CREATE TABLE #TimeStamp
	    (
		    Step_Number INT,
		    Time_Stamp  INT
	    );
	
	    --For Calculating TIME_STAMP

	    WITH TempTable
		    AS (SELECT DISTINCT
					Number
			   FROM #StepTime)
		    INSERT INTO #TimeStamp
		    (
				 Step_Number,
				 Time_Stamp
		    )
		    SELECT
				 b.Number,
				 SUM(t.Time) Time_Stamp
		    FROM TempTable b
			    INNER JOIN #StepTime t ON b.Number >= t.Number
		    GROUP BY
				   b.Number;
	    CREATE TABLE #BatchProductData
	    (
		    equipmentNo INT,
		    StepNo      INT,
		    Qty         DECIMAL(10, 6),
		    Time_Stamp  DATETIME2(7),
		    ProductId   INT,
		    Row_No      INT
	    );
	    INSERT INTO #BatchProductData
	    (
			 EquipmentNo,
			 StepNo,
			 Qty,
			 Time_Stamp,
			 ProductId,
			 Row_No
	    )
	    SELECT
			 d.equipmentNo,
			 d.StepNo,
			 d.Qty,
			 DATEADD(ss, ts.Time_Stamp, @StartDateTime),
			 ces.ProductId,
			 ROW_NUMBER() OVER(ORDER BY d.StepNo DESC) AS Row
	    FROM #Dosing d
		    INNER JOIN #TimeStamp ts ON d.StepNo = ts.Step_Number
		    INNER JOIN tcd.ControllerEquipmentSetup ces ON ces.
		    ControllerEquipmentId = d.equipmentNo
	    WHERE d.equipmentNo > 0
			AND d.Qty > 0
			AND ControllerID = @ControllerID
			AND ces.ProductId IS NOT NULL;
	    SELECT
			 @MaxWashertGroupCapacity = MAX(ws.MaxLoad)
	    FROM TCD.Washer WS
		    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.
		    GroupId
	    WHERE Mst.GroupId = @WasherGroupID;
	    DECLARE @Counter INT;
	    SET @counter = 1;
	    WHILE(@counter <=
		    (
			   SELECT
					COUNT(ROW_No)
			   FROM #BatchProductData bpd
		    ))
		   BEGIN
			  SELECT
				    @stepno = bpd.StepNo,
				    @quantity = bpd.Qty,
				    @productid = bpd.ProductId,
				    @timestamp = bpd.Time_Stamp
			  FROM #BatchProductData bpd
			  WHERE bpd.Row_No = @counter
			  ORDER BY
					 bpd.StepNo;
			  SELECT
				    @InjectionNumber = Wdpm.InjectionNumber,
				    @standardqty = ((@NominalLoad / CONVERT( DECIMAL(
				    10, 2), 100)) * Wdpm.Quantity * Ws.MaxLoad) /
				    CONVERT(DECIMAL(10, 2), 100),
				    @price = ((@NominalLoad / CONVERT(       DECIMAL(
				    10, 2), 100)) * Wdpm.Quantity *
				    @MaxWashertGroupCapacity) / CONVERT(DECIMAL(10, 2),
				    100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID)
			  FROM TCD.Washer WS
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws
				  .WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =
				  Mst.GroupId
				  INNER JOIN TCD.WasherGroupType WgT ON WgT.
				  WasherGroupTypeId = Wg.WasherGroupTypeId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.
				  ControllerID = Wg.ControllerId
				  INNER JOIN TCD.WasherDosingSetup Wds ON Wds.
				  WasherProgramSetupId = Wps.WasherProgramSetupId
				  INNER JOIN TCD.WasherDosingProductMapping Wdpm ON
				  Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
				  INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.
				  ProductId = Wdpm.ProductId
				  INNER JOIN TCD.BatchData Bd ON Bd.MachineId = Ws.
				  WasherId
			  WHERE Ws.WasherId = @WasherID
				   AND Wps.ProgramNumber = @ProgramNumber
				   --AND Wdpm.InjectionNumber = @stepno
				   AND Bd.BatchId = @BatchID
				   AND Wps.Is_Deleted = 0
				   AND Pdm.Is_Deleted = 0;
			  INSERT INTO TCD.BatchProductData
			  (
				    BatchId,
				    StepCompartment,
				    ActualQuantity,
				    StandardQuantity,
				    Price,
				    PartitionOn,
				    EcolabWasherId,
				    ProductId,
				    TimeStamp,
				    InjectionNumber
			  )
			  VALUES
			  (
				    @BatchID,
				    @stepno,
				    @quantity,
				    ISNULL(@standardqty,0),
				    ISNULL(@price,0),
				    @ShiftStartdate,
				    @EcolabWasherId,
				    @productid,
				    @timestamp,
				    @InjectionNumber
			  );
			  SET @counter = @counter + 1;
		   END;
	    --END For calculating TIMESTAMP
	    --Start Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
	    SELECT
			 @ActualInjSteps = COUNT(DISTINCT StepNo)
	    FROM #Dosing 
		Where StepNo > 0 ;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE ParameterId = 37
			    AND batchid = @BatchID
			    AND @ActualInjSteps > 0
	    )
		   BEGIN
			  IF(@ActualInjSteps > 0
				OR @ActualInjSteps IS NOT NULL)
				 INSERT INTO TCD.BatchParameters
				 (
					   BatchId,
					   EcolabWasherId,
					   ParameterId,
					   ParameterValue,
					   PartitionOn
				 )
				 SELECT
					   @BatchId,
					   @EcolabWasherId,
					   37,
					   @ActualInjSteps,
					   @ShiftStartDate;
		   END;
	    ELSE
		   BEGIN
			  UPDATE TCD.BatchParameters
			    SET
				   ParameterValue = @ActualInjSteps
			  WHERE
				   ParameterId = 37
				   AND batchid = @BatchID;
		   END;
	    SELECT
			 @LastStep = MAX([Number])
	    FROM #StepTime
	    WHERE [Time] > 0;
	    SELECT
			 @CurrentStep = 1,
			 @CurrentStepTime = @StartDateTime;
	    WHILE(@CurrentStep <= @LastStep)
		   BEGIN
			  UPDATE #StepTime
			    SET
				   StartTime = @CurrentStepTime,
				   EndTime = DATEADD(ss, [time], @CurrentStepTime)
			  WHERE
				   Number = @CurrentStep;
			  SELECT
				    @CurrentStepTime = EndTime
			  FROM #StepTime
			  WHERE Number = @CurrentStep;
			  SELECT
				    @CurrentStep = @CurrentStep + 1;
		   END;
	    INSERT INTO [TCD].[BatchWashStepData]
	    (
			 BatchID,
			 StepCompartment,
			 StartTime,
			 EndTime,
			 PartitionOn,
			 EcolabWasherId
	    )
	    SELECT
			 @BatchID,
			 Number,
			 StartTime,
			 EndTime,
			 @ShiftStartdate,
			 @EcoLabWasherID
	    FROM #StepTime
	    WHERE Number <= @LastStep;
	    SELECT
			 @MinTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Mimum Temperature';
	    SELECT
			 @MaxTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Maximum Temperature';
	    SELECT
			 @MaxTempStatusParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Max Temperature Status';
	    SELECT
			 @MinTempStatuParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Minimum Temperature Status';
	    SELECT
			 @PHValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH';
	    SELECT
			 @PHStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH Status';
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MinTempParamID
	    )
		   BEGIN
			  IF(@TemperatureMin <> 0
				OR @TemperatureMin <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MinTempParamID,
						  @TemperatureMin,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MaxTempParamID
	    )
		   BEGIN
			  IF(@TemperatureMax <> 0
				OR @TemperatureMax <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MaxTempParamID,
						  @TemperatureMax,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MaxTempStatusParamID
	    )
		   BEGIN
			  IF(@TempMaxStatus <> 0
				OR @TempMaxStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MaxTempStatusParamID,
						  @TempMaxStatus,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MinTempStatuParamID
	    )
		   BEGIN
			  IF(@TempMinStatus <> 0
				OR @TempMinStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MinTempStatuParamID,
						  @TempMinStatus,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF(@PHStatus <> 0
		  OR @PHStatus <> NULL)
		   BEGIN
			  INSERT INTO TCD.BatchParameters
			  (
				    BatchId,
				    EcolabWasherId,
				    ParameterId,
				    ParameterValue,
				    PartitionOn
			  )
			  VALUES
			  (
				    @BatchID,
				    @EcoLabWasherID,
				    @PHStatusParamID,
				    @PHStatus,
				    @ShiftStartdate
			  );
		   END;
	    IF(@PHValue <> 0
		  OR @PHValue <> NULL)
		   BEGIN
			  INSERT INTO TCD.BatchParameters
			  (
				    BatchId,
				    EcolabWasherId,
				    ParameterId,
				    ParameterValue,
				    PartitionOn
			  )
			  VALUES
			  (
				    @BatchID,
				    @EcoLabWasherID,
				    @PHValueParamID,
				    @PHValue,
				    @ShiftStartdate
			  );
		   END;
	    EXEC TCD.ProcessMyControlProductionWaterConsumptionData
		    @BatchID,
		    @VxML,
		    @ShiftStartDate;
	    DROP TABLE #BatchProductData;
	    DROP TABLE #Dosing;
	    DROP TABLE #StepTime;
	    DROP TABLE #TimeStamp;

		--Start water consumption per batch

	SELECT @MeterID=MeterId,@StepComportment=MachineCompartment
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@MachineNumber
   AND mt.CounterNum = 1;


   SELECT @EnergyCount=COUNT(1) FROM TCd.BatchStepWaterUsageData bswud WHERE BatchId =@BatchID AND StepCompartment =@StepComportment AND ActualQuantity=@WaterConsumption1
    IF(@EnergyCount=0)
  BEGIN
  IF(ISNULL(@WaterConsumption1,0)>0  AND ISNULL(@MeterID,0)>0  AND ISNULL(@StepComportment,0)>0)
  BEGIN
   INSERT INTO TCD.BatchStepWaterUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
	  EcolabWasherId
     )
     SELECT
     @BatchID,
     @StepComportment,
     @WaterConsumption1,
     @ShiftStartdate,
	 @EcoLabWasherID
	 END
      END  

	 SELECT @MeterID=MeterId,@StepComportment=MachineCompartment
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@MachineNumber
   AND mt.CounterNum = 2;
SELECT @EnergyCount=COUNT(1) FROM TCd.BatchStepWaterUsageData WHERE BatchId =@BatchID AND StepCompartment =@StepComportment AND ActualQuantity=@WaterConsumption2
 IF(@EnergyCount=0)
  BEGIN
  IF(ISNULL(@WaterConsumption2,0)>0  AND ISNULL(@MeterID,0)>0  AND ISNULL(@StepComportment,0)>0)
  BEGIN
   INSERT INTO TCD.BatchStepWaterUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
	  EcolabWasherId
     )
     SELECT
     @BatchID,
     @StepComportment,
     @WaterConsumption2,
     @ShiftStartdate,
	 @EcoLabWasherID
	 END
      END   
	  --End water consumption per batch
	END;
	GO
	------------------------------------------------END Conventional Production injection steps query change------------------