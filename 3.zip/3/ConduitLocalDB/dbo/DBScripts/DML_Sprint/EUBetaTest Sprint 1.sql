﻿IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessConventionalOnlineDataForPLCXL]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessConventionalOnlineDataForPLCXL]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessConventionalOnlineDataForPLCXL]
(
	@ControllerID   INT,
	@VxML           XML,
	@RedFlagShiftId INT OUTPUT
)
AS
	BEGIN
	    DECLARE @MachineNumber           INT,
			  @StepNumber              INT,
			  @StartDateTime           DATETIME,
			  @EndDateTime             DATETIME,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @WaterConsumption1       INT,
			  @PHValue                 INT,
			  @TemperatureMax          INT,
			  @BatchNumber             INT,
			  @WasherID                INT,
			  @WasherGroupID           INT,
			  @EcoLabWasherID          INT,
			  @ProgramMasterID         INT,
			  @PlantWasherNumber       INT,
			  @ShiftID                 INT,
			  @BatchID                 INT,
			  @ShiftStartdate          DATETIME,
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @ActualInjSteps          INT,
			  @CurrencyCode            VARCHAR(50),
			  @PartitionOn             DATETIME2,
			  @TargetTurnTime          SMALLINT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @FrmParameterID          INT;
	    SELECT
			 @MachineNumber = T.c.value('@MachineNumber', 'INT'),
			 @StepNumber = T.c.value('@StepNumber', 'INT'),
			 @StartDateTime = T.c.value('@StartDateTime', 'DATETIME'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'decimal(10,2)'),
			 @NominalLoad = T.c.value('@NominalLoad', 'decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'INT'),
			 @WaterConsumption1 = T.c.value('@WaterConsumption1', 'INT'),
			 @PHValue = T.c.value('@PHValue', 'INT'),
			 @TemperatureMax = T.c.value('@TemperatureMax', 'INT'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT')
	    FROM @VxML.nodes('ConventionalWasherData') T(C);
	    SELECT
			 @FrmParameterID = Id
	    FROM TCD.ConduitPArameters
	    WHERE Name = 'Formula Number';
	    DECLARE @ShiftMapping TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    INSERT INTO @ShiftMapping
	    (
			 ShiftId,
			 ShiftName,
			 ShiftStartdate
	    )
	    EXEC TCD.GetShiftStartDate
		    @StartDateTime;
	    SELECT
			 @ShiftID = ShiftID,
			 @ShiftStartdate = ShiftStartdate,
			 @PartitionOn = ShiftStartdate
	    FROM @ShiftMapping;
	    SELECT
			 @WasherGroupID = GroupId,
			 @WasherID = WasherID
	    FROM TCD.MachineSetup ms
	    WHERE ControllerID = @ControllerID
			AND MachineInternalId = @MachineNumber
			AND IsTunnel = 0
			AND ms.IsDeleted = 0;
	    IF(@EndDateTime = '1/1/1900')
		   SELECT @EndDateTime = NULL;
	    IF(@StartDateTime = '1/1/1900')
		   SELECT @StartDateTime = NULL;
	    IF(@WasherId IS NOT NULL)
		   BEGIN
			  SELECT
				    @ProgramMasterId = Wps.ProgramId
			  FROM TCD.Washer Ws
				  INNER JOIN TCD.MachineSetup Ms ON Ms.WasherId = Ws.WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Ms.GroupId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId  = Wg.WasherGroupId
				  INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber =  Ws.EcoLabAccountNumber
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wps.ControllerID = @ControllerID
				   AND Wps.Is_Deleted = 0
				   AND ms.IsDeleted = 0;
			  SELECT
				    @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber,
				    @CurrencyCode = P.CurrencyCode,
				    @TargetTurnTime = w.TargetTurnTime * 60
			  FROM TCD.Washer w
				  INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.EcolabAccountNumber
			  WHERE w.WasherId = @WasherID
				   AND w.Is_Deleted = 0;
		   END;
	    SELECT
			 @BatchID = BatchID
	    FROM TCD.BatchData
	    WHERE MachineInternalID = @MachineNumber
			AND CAST(StartDate AS DATE) = CAST(@StartDateTime AS DATE)
			AND ControllerBatchId = @BatchNumber
			AND MachineID = @WasherID;
	    --Start Getting InjectionCount and StepCount
	    SELECT
			 @StdInjectionSteps = COUNT(DISTINCT wdpm.WasherDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) - COUNT(DISTINCT wdpm.WasherDosingSetupId)
	    FROM TCD.WasherDosingProductMapping wdpm
		    RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm.WasherDosingSetupId = wds.WasherDosingSetupId
	    WHERE wds.GroupId = @WasherGroupID
			AND wds.ProgramNumber = @ProgramNumber;
	    --End Getting InjectionCount and StepCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT
			 @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramMasterId
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT
				    @EcolabTextileCategoryId = pcp.EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp.ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram
	    IF(@BatchID IS NULL)
		   BEGIN
			  INSERT INTO TCD.BatchData
			  (
				    ControllerBatchID,
				    EcolabWasherId,
				    GroupId,
				    MachineInternalId,
				    PlantWasherNumber,
				    StartDate,
				    EndDate,
				    ProgramNumber,
				    ProgramMasterId,
				    MachineID,
				    ActualWeight,
				    StandardWeight,
				    CurrencyCode,
				    ShiftId,
				    PartitionOn,
				    StdInjectionSteps,
				    StdWashSteps,
				    EcolabTextileCategoryId,
				    ChainTextileCategoryId,
				    FormulaSegmentId,
				    EcolabSaturationId,
				    PlantProgramId,
				    TargetTurnTime
			  )
			  VALUES
			  (
				    @BatchNumber,
				    @EcoLabWasherID,
				    @WasherGroupID,
				    @MachineNumber,
				    @PlantWasherNumber,
				    @StartDateTime,
				    @EndDateTime,
				    @ProgramNumber,
				    @ProgramMasterId,
				    @WasherID,
				    @Load,
				    @NominalLoad,
				    @CurrencyCode,
				    @ShiftID,
				    @PartitionOn,
				    @StdInjectionSteps,
				    @StdWashSteps,
				    @EcolabTextileCategoryId,
				    @ChainTextileCategoryId,
				    @FormulaSegmentId,
				    @EcolabSaturationId,
				    @PlantProgramId,
				    @TargetTurnTime
			  );
			  SELECT
				    @BatchID = SCOPE_IDENTITY();
			  IF NOT EXISTS
			  (
				 SELECT
					   *
				 FROM TCD.BatchParameters
				 WHERE BatchId = @BatchID
					  AND ParameterID = 38
			  )
				 BEGIN
					IF(@StdWashSteps <> 0
					   OR @StdWashSteps <> NULL)
					    BEGIN
						   INSERT INTO TCD.BatchParameters
						   (
								BatchId,
								EcolabWasherId,
								ParameterId,
								ParameterValue,
								PartitionOn
						   )
						   SELECT
								@BatchID,
								@EcoLabWasherID,
								38,
								@StdWashSteps,
								@ShiftStartdate;
					    END;
				 END;
			  --End Date  Time  is Null 
			  UPDATE TCD.BatchData
			    SET
				   EndDate = GETUTCDATE(),
				   EndDateFormula = GETUTCDATE()
			  WHERE
				   MachineInternalID = @MachineNumber
				   AND StartDate <> @StartDateTime
				   AND EndDate IS NULL
				   AND ControllerBatchId <> @BatchNumber
				   AND MachineId = @WasherId;
			  -- Program Number 
			  IF(@ProgramNumber IS NOT NULL
				AND @ProgramNumber > 0)
				 BEGIN
					IF NOT EXISTS
					(
					    SELECT
							 *
					    FROM TCD.WasherReading
					    WHERE WasherId = @WasherID
							AND ParameterID = @FrmParameterID
							AND DateTimeStamp = @StartDateTime
					)
					    BEGIN
						   INSERT INTO TCD.WasherReading
						   (
								WasherID,
								ParameterID,
								ParameterValue,
								DateTimeStamp,
								EcoLabWasherID,
								Partitionon
						   )
						   VALUES
						   (
								@WasherID,
								@FrmParameterID,
								@ProgramNumber,
								@StartDateTime,
								@EcoLabWasherID,
								@ShiftStartdate
						   );
					    END;
				 END;
			  IF NOT EXISTS
			  (
				 SELECT
					   1
				 FROM TCD.BatchCustomerData
				 WHERE BatchID = @BatchId
					  AND @CustomerNumber IS NOT NULL
			  )
				 BEGIN
					INSERT INTO [TCD].[BatchCustomerData]
					(
						  BatchId,
						  CustomerID,
						  Weight,
						  PartitionOn,
						  EcolabWasherId
					)
					VALUES
					(
						  @BatchID,
						  @CustomerNumber,
						  @Load,
						  @ShiftStartdate,
						  @EcolabWasherID
					);
				 END;
			  ELSE
			  IF(@CustomerNumber > 0)
				 BEGIN
					UPDATE TCD.BatchCustomerData
					  SET
						 CustomerID = @CustomerNumber,
						 Weight = @Load
					WHERE
						 BatchID = @BatchId;
				 END;
		   END;
	    EXEC TCD.AddSensorData
		    @ControllerID,
		    @WasherID,
		    @WasherGroupID,
		    1,			  --Temparature
		    @TemperatureMax;
	    EXEC TCD.AddSensorData
		    @ControllerID,
		    @WasherID,
		    @WasherGroupID,
		    2,			  --PH
		    @PHValue;
	    EXEC TCD.AddMeterReading
		    @ControllerID,
		    @WasherID,
		    2,               --Water
		    @WaterConsumption1;
	    CREATE TABLE #Dosing
	    (
		    EquipmentNo INT,
		    StepNo      INT,
		    Qty         DECIMAL(18, 4)
	    );
	    INSERT INTO #Dosing
	    SELECT
			 T.c.value('@Equipment', 'INT'),
			 T.c.value('@stepNo', 'INT'),
			 T.c.value('@Qty', 'decimal(18,4)')
	    FROM @VxML.nodes('ConventionalWasherData/DosingData/Dosing') T(C);
	    --Start Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
	    SELECT
			 @ActualInjSteps = COUNT(DISTINCT StepNo)
	    FROM #Dosing;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE ParameterId = 37
			    AND batchid = @BatchId
			    AND @ActualInjSteps > 0
	    )
		   BEGIN
		   IF(ISNULL(@ActualInjSteps,0) > 0 )
			 BEGIN
			   INSERT INTO TCD.BatchParameters
			   (
				    BatchId,
				    EcolabWasherId,
				    ParameterId,
				    ParameterValue,
				    PartitionOn
			   )
			   SELECT
				    @BatchId,
				    @EcolabWasherID,
				    37,
				    @ActualInjSteps,
				    @ShiftStartDate;
			END;
		   END;
	    ELSE
		   BEGIN
			  UPDATE TCD.BatchParameters
			    SET
				   ParameterValue = @ActualInjSteps
			  WHERE
				   ParameterId = 37
				   AND batchid = @BatchID;
		   END;     
	    --END Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
	    INSERT INTO [TCD].[WasherProductReading]
	    (
			 ControllerId,
			 WasherId,
			 MachineInternalId,
			 ProductId,
			 TheoreticalQty,
			 RealQty,
			 DosingPoint,
			 DosingNumber,
			 ProgramNumber,
			 BatchNumber,
			 ValveNumber,
			 DateTimeStamp
	    )
	    SELECT
			 @ControllerID,
			 @WasherID,
			 @MachineNumber,
			 CE.ProductID,
			 NULL,
			 d.Qty,
			 equipmentNo,
			 equipmentNo,
			 @ProgramNumber,
			 @BatchNumber,
			 NULL,
			 GETDATE()
	    FROM #Dosing d
		    INNER JOIN TCD.ControllerEquipmentSetup CE ON d.equipmentNo = CE.ControllerEquipmentId
												AND d.EquipmentNo > 0
												AND d.Qty > 0
												AND CE.controllerID = @ControllerID
												AND CE.ProductID IS NOT NULL;
	END;
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[AddSensorData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[AddSensorData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[AddSensorData](
	@ControllerID       INT,
	@MachineCompartment INT,
	@MachineGroupId     INT,
	@SensorTypeID       INT,
	@ReadingValue       DECIMAL(18, 4))
AS
	BEGIN
	    DECLARE @SensorID INT;
	    DECLARE @PreviousReading DECIMAL(18, 4);
	    SELECT
			 @SensorID = NULL;
	    SELECT
			 @SensorID = SensorID
	    FROM TCD.Sensor
	    WHERE ControllerID = @ControllerID
			AND MachineCompartment = @MachineCompartment
			AND SensorType = @SensorTypeID
			AND GroupId = @MachineGroupId
			AND is_Deleted = 0;
	    IF(@SensorID IS NOT NULL)
		   BEGIN
			  IF NOT EXISTS
			  (
				 SELECT
					   Reading
				 FROM TCD.SensorReading
				 WHERE SensorID = @SensorID
			  )
				 BEGIN
					INSERT INTO TCD.SensorReading
					(
						  SensorId,
						  Reading,
						  TimeStamp
					)
					VALUES
					(
						  @SensorID,
						  @ReadingValue,
						  GETUTCDATE()
					);
				 END;
		   END;
	END;
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[AddMeterReading]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[AddMeterReading]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[AddMeterReading](
	@ControllerID  INT,
	@WasherID      INT,
	@UtilityTypeID INT,
	@ReadingValue  DECIMAL(18, 4))
AS
	BEGIN
	    DECLARE @MeterID INT = NULL;
	    SELECT
			 @MeterID = MeterID
	    FROM TCD.METER
	    WHERE ControllerID = @ControllerID
			AND UtilityType = @UtilityTypeID
			AND MachineCompartment = @WasherID
			AND Is_deleted = 0;
	    IF(@MeterID IS NOT NULL)
		   BEGIN
		    IF NOT EXISTS
			  (
				 SELECT
				     Reading
			  FROM TCD.ModuleReading
			  WHERE ModuleID = @MeterID
				   AND ModuleTypeID = 2	   --Meter
			  )
				 BEGIN
					INSERT INTO TCD.ModuleReading
					(
						  ModuleId,
						  ModuleTypeId,
						  Reading,
						  TimeStamp
					)
					VALUES
					(
						  @MeterID,
						  2,		    --Meter
						  @ReadingValue,
						  GETUTCDATE()
					);
				 END;
		   END;
	END;
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMitsubishiAccessSaveData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMitsubishiAccessSaveData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[ProcessMitsubishiAccessSaveData]
(
	@ControllerID INT,
	@xmlTags      XML,
	@RedFlagShiftId int output
)
AS
	BEGIN
	    DECLARE @BatchID              INT,
			  @WasherID             INT,
			  @EcolabWasherId       INT,
			  @CurrencyCode         VARCHAR(50),
			  @MachineInternalId    INT,
			  @WasherGroupID        INT,
			  @PlantWasherNumber    INT,
			  @BatchStartTime       DATETIME2,
			  @BatchEndTime         DATETIME2,
			  @ProgramNumber        INT,
			  @Load                 DECIMAL(10, 2),
			  @NominalLoad          DECIMAL(10, 2),
			  @CustomerNumber       INT,
			  @BatchCounter         INT,
			  @IsTunnel             INT,
			  @BatchShiftId         INT,
			  @PartitionOn          DATETIME2,
			  @ShiftName            VARCHAR(50),
			  @ProgramMasterId      INT,
			  @NumberOfCompartments INT,
			  @TargetTurnTime       INT,
			  @EcolabAccountNumber  NVARCHAR(1000) = NULL,
			  @StdInjectionSteps    INT,
			  @StdWashSteps         INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @PreviousShiftId      INT,
			  @CurrentShiftId      INT;

	    SELECT
			 @MachineInternalID = T.c.value('@MachineNumber', 'int'),
			 @BatchCounter = T.c.value('@BatchCounter', 'INT'),
			 @BatchStartTime = T.c.value('@StartDateTime', 'DateTime'),
			 @BatchEndTime = T.c.value('@EndDateTime', 'DateTime'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@NominalLoad', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'int'),
			 @IsTunnel = T.c.value('@IsTunnel', 'int')
	    FROM @xmlTags.nodes('PLCData') T(c);
	    SELECT
			 @EcolabWasherID = EcolabWasherId,
			 @WasherGroupID = Wg.WasherGroupId,
			 @PlantWasherNumber = PlantWasherNumber,
			 @WasherID = ws.WasherId,
			 @CurrencyCode = P.CurrencyCode,
			 @NumberOfCompartments = Mst.NumberofComp
	    FROM TCD.Washer Ws
		    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws. WasherId
		    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
		    INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
		    INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId = Mst.ControllerId
		    INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.EcoLabAccountNumber
	    WHERE Ctrl.ControllerID = @ControllerID
			AND mst.MachineInternalId = @MachineInternalID
			AND mst.IsTunnel = @IsTunnel
			AND Ws.Is_Deleted =0
			AND mst.IsDeleted =0
			AND Ctrl.IsDeleted = 0;
	    IF(@IsTunnel = 1)
		   BEGIN
			  SELECT
				    @ProgramMasterId = ProgramId,
				    @TargetTurnTime = (3600 / (tps.TotalRunTime / @NumberOfCompartments))
			  FROM TCD.TunnelProgramSetup tps
			  WHERE tps.WasherGroupId = @WasherGroupID
				   AND tps.is_deleted = 0
				   AND ProgramNumber = @ProgramNumber
				   AND @ControllerID = @ControllerID;
				    --Start Getting InjectionCount,StepCount And ProductCount
			  SELECT
				    @StdInjectionSteps = COUNT(tdpm. TunnelDosingSetupId),
				    @StdWashSteps = COUNT(DISTINCT tds.TunnelDosingSetupId) - COUNT(tdpm.TunnelDosingSetupId)
			  FROM tcd.TunnelDosingProductMapping tdpm
				  RIGHT JOIN tcd.TunnelDosingSetup tds ON tdpm.
				  TunnelDosingSetupId = tds.TunnelDosingSetupId
			  WHERE tds.GroupId = @WasherGroupID
				   AND tds.ProgramNumber = @ProgramNumber;
			  --End Getting InjectionCount,StepCount And ProductCount
		   END;
	    ELSE
		   BEGIN
			  SELECT DISTINCT
				    @ProgramMasterId = Wps.ProgramId
			  FROM TCD.Washer Ws
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
				  INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps. WasherGroupId = Wg.WasherGroupId
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wps.Is_Deleted = 0
				   AND wps.ControllerID = @ControllerID;
			  SELECT
				    @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber,
				    @CurrencyCode = P.CurrencyCode,
				    @TargetTurnTime = w.TargetTurnTime * 60
			  FROM TCD.Washer w
				  INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.EcolabAccountNumber
			  WHERE w.WasherId = @WasherID;
			   --Start Getting InjectionCount and StepCount
	    SELECT
			 @StdInjectionSteps = COUNT(DISTINCT wdpm.WasherDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) - COUNT(DISTINCT wdpm.WasherDosingSetupId)
	    FROM TCD.WasherDosingProductMapping wdpm
		    RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm. WasherDosingSetupId = wds.WasherDosingSetupId
	    WHERE wds.GroupId = @WasherGroupID
			AND wds.ProgramNumber = @ProgramNumber;
	    --End Getting InjectionCount and StepCount
		   END;
	    SET @BatchID = NULL;
	    SELECT
			 @BatchID = BatchID
	    FROM TCD.BatchData BD
	    WHERE BD.ControllerBatchId = @BatchCounter
			AND BD.MachineInternalId =  @MachineInternalId
			AND BD.MachineId = @WasherID
			AND CAST(StartDate AS DATE) = CAST(@BatchStartTime AS DATE);
	   
	      --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT
			 @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramMasterId
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT
				    @EcolabTextileCategoryId = pcp.EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp.ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram
	    IF(@BatchID IS NULL)
		   BEGIN
			  DECLARE @ShiftStartDateTemp TABLE
			  (
				  ShiftId        INT,
				  ShiftName      NVARCHAR(50),
				  ShiftStartdate DATETIME
			  );
			  INSERT INTO @ShiftStartDateTemp
			  (
				    ShiftId,
				    ShiftName,
				    ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchStartTime;
			  SELECT
				    @BatchShiftId = ShiftID,
				    @PartitionOn = ShiftStartdate
			  FROM @ShiftStartDateTemp;
			  IF(@IsTunnel = 0)
				 BEGIN
					UPDATE TCD.BatchData
					  SET
						 EndDate = GETUTCDATE(),
						 EndDateFormula = GETUTCDATE()
					WHERE
						 MachineInternalID = @MachineInternalID
						 AND StartDate <> @BatchStartTime
						 AND EndDate IS NULL
						 AND ControllerBatchId <> @BatchCounter
						 AND MachineId = @WasherId;
				 END;

			    --Start Rollup for previous completed shift
				IF(CAST(@BatchStartTime as date) < CAST(GETUTCDATE() as date))
				BEGIN
			        SELECT TOP 1 @PreviousShiftId=ShiftId FROM TCD.BatchData WHERE MachineId=@WasherId ORDER BY StartDate DESC    
				    SELECT Top 1 @CurrentShiftId = ShiftId from @ShiftStartDateTemp
					IF(@CurrentShiftId != @PreviousShiftId)
					BEGIN
						EXEC TCD.ProductionShiftDataRollup @PreviousShiftId, @RedFlagShiftId OUTPUT
						SELECT @RedFlagShiftId = isNull(@RedFlagShiftId,@PreviousShiftId)
					END
				END
			--End Rollup for previous completed shift
			  INSERT INTO TCD.BatchData
			  (
				    ControllerBatchId,
				    EcolabWasherId,
				    GroupId,
				    MachineInternalId,
				    PlantWasherNumber,
				    StartDate,
				    EndDate,
				    ProgramNumber,
				    ProgramMasterId,
				    MachineId,
				    ActualWeight,
				    StandardWeight,
				    CurrencyCode,
				    ShiftId,
				    PartitionOn,
				    StdInjectionSteps,
				    StdWashSteps,
				    TargetTurnTime,
				    EcolabTextileCategoryId,
				    ChainTextileCategoryId,
				    FormulaSegmentId,
				    EcolabSaturationId,
				    PlantProgramId
			  )
			  SELECT
				    @BatchCounter,
				    @EcolabWasherID,
				    @WasherGroupID,
				    @MachineInternalID,
				    @PlantWasherNumber,
				    @BatchStartTime,
				    @BatchEndTime,
				    @ProgramNumber,
				    @ProgramMasterId,
				    @WasherID,
				    @Load,
				    @NominalLoad,
				    @CurrencyCode,
				    @BatchShiftId,
				    @PartitionOn,
				    @StdInjectionSteps,
				    @StdWashSteps,
				    @TargetTurnTime,
				    @EcolabTextileCategoryId,
				    @ChainTextileCategoryId,
				    @FormulaSegmentId,
				    @EcolabSaturationId,
				    @PlantProgramId;
			  SELECT
				    @BatchID = SCOPE_IDENTITY();
			  IF(@CustomerNumber IS NOT NULL)
				 BEGIN
					INSERT INTO TCD.BatchCustomerData
					(
						  BatchId,
						  CustomerID,
						  Weight,
						  PartitionOn,
						  EcolabWasherId
					)
					SELECT
						  @BatchID,
						  @CustomerNumber,
						  @Load,
						  @PartitionOn,
						  @EcolabWasherId;
				 END;
		   END;
	    ELSE
		   BEGIN
			  IF(@IsTunnel = 1)
				 BEGIN
					UPDATE TCD.BatchData
					  SET
						 StartDate = @BatchStartTime,
						 StandardWeight = @NominalLoad
					WHERE
						 ControllerBatchId = @BatchCounter
						 AND MachineId = @WasherID
						 AND CAST(StartDate AS DATE) = CAST(@BatchStartTime AS DATE);
				 END;
		   END;
	END;
Go
----------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[UpdateTunnel]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[UpdateTunnel]
END
GO

/*	
Purpose					:	To edit details of a new Tunnel from the Washer-Tunnel (General) setup screen

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version

*/


CREATE	PROCEDURE    [TCD].[UpdateTunnel]
                    @EcoLabAccountNumber                    NVARCHAR(25)
                ,    @WasherId                                INT
                ,    @WasherGroupId                            INT                                    --Not updated, for reference only
                ,    @TunnelName                            NVARCHAR(50)
                ,    @WasherModelName                        NVARCHAR(50)
                ,    @RegionId                                SMALLINT
                --,    @Size                                INT
                ,    @ControllerId                            INT
                ,    @LFSWasherNumber                        INT            =            1        --For tunnels, it will be 1 until a diff. number is passed (as per the scenario)
                ,    @PlantWasherNumber                        SMALLINT
                ,    @WasherMode                            SMALLINT
                ,    @MaxLoad                                SMALLINT
                ,    @AWEActive                            BIT
                ,    @NumberOfTanks                            TINYINT
                ,    @NumberOfComp                            INT                                --though this is INT in the table, we should not require it to be so
                ,    @TransferType                            TINYINT
                ,    @PressExtractor                        TINYINT
                ,    @ProgramNumber                            TINYINT
                ,    @EndOfFormula                            TINYINT
                ,    @Description                            NVARCHAR(1024)    =            NULL
                ,    @UserId                                INT
				--Adding these 3 params as part of re-factoring for integration with Synch/Configurator
                ,    @OutputTunnelId                        INT            =            NULL    OUTPUT
                ,    @LastModifiedTimestampAtCentral            DATETIME    =            NULL            --Nullable for local call; Synch/Central call will have to pass this -
																									--else, it will be treated as a local call
                ,    @OutputLastModifiedTimestampAtLocal        DATETIME    =            NULL    OUTPUT
                ,   @RatioDosingActive                        BIT
                ,   @ControllerModelId                        INT        =        NULL
                ,   @NumberOfCompartmentsConveyorBelt            TINYINT    =        NULL
                ,   @MaxMachineLoad                            SMALLINT    =        NULL
                ,   @MinMachineLoad                            SMALLINT    =        NULL
                ,   @ProgramSelectionByTime                    BIT          =        NULL
                ,   @WeightSelectionByTime                    BIT          =        NULL
                ,   @WeightSelectionByAnalogInput                BIT          =        NULL
                ,   @TunInTomMode                            BIT          =        NULL
                ,   @SignalStopTunActive                        BIT          =        NULL
                ,   @SignalEjectionTunActive                      BIT          =        NULL
                ,   @DelayTimeForTunWashingPrograms            BIT          =        NULL
                ,   @KannegiesserPressSpecialMode                BIT          =        NULL
                ,   @ValveOutputsUsedAsTomSignal                BIT          =        NULL
                ,   @ExtendedClockOrDataProtocol                BIT          =        NULL
                ,   @WeightCorrectionFcc                        BIT          =        NULL
				,	@DateAndTimeWhenBatchEjects					BIT	  		=		NULL
				,	@AutoRinseDesamixAfter						SMALLINT	=		NULL
				,	@AutoRinseDesamix1For						SMALLINT	=		NULL
				,	@AutoRinseDesamix2For						SMALLINT	=		NULL
				,	@TemperatureAlarmProbe1						BIT			=		NULL
				,	@TemperatureAlarmProbe2						BIT			=		NULL
				,	@TemperatureAlarmProbe3						BIT			=		NULL
				,	@UseMe1OfGroup							tinyint					=	NULL
				,	@UseMe2OfGroup							tinyint					=	NULL
				,	@ETechWasherNumber						int					=	NULL
				,	@KannegiesserDosageInPreparationTankMode	bit			=		NULL
				,	@BatchOk									bit			=		NULL
AS
BEGIN

SET    NOCOUNT    ON


DECLARE	
        @ReturnValue                    INT                =            0
    ,    @ErrorId                        INT                =            0
    ,    @ErrorMessage                    NVARCHAR(4000)    =            N''

    ,    @WasherModelId                    SMALLINT        =            NULL

    ,    @CurrentUTCTime                    DATETIME        =            GETUTCDATE()
	,	@ControllerValidate				int				=										   0

--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
SET        @OutputLastModifiedTimestampAtLocal                =            @CurrentUTCTime
SET        @OutputTunnelId                                    =            ISNULL(@OutputTunnelId, NULL)            --SQLEnlight

--If the call is not local, check that the LastModifiedTime matches with the central
IF    (
        @LastModifiedTimestampAtCentral            IS NOT    NULL
    AND    NOT    EXISTS    (    SELECT    1
                        FROM    TCD.[Washer]            W
                        WHERE    W.EcolabAccountNumber    =    @EcolabAccountNumber
                            AND    W.WasherId                =    @WasherId
                            AND    W.LastModifiedTime        =    @LastModifiedTimestampAtCentral
					)
	)
	BEGIN
            SET            @ErrorId                    =    60000
            SET            @ErrorMessage                =    N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
            RAISERROR    (@ErrorMessage, 16, 1)
            SET            @ReturnValue                =    -1
            RETURN        (@ReturnValue)
	END

--Proceed, since it's either a local call or Synch. call with synch. time matching


--Valid Washer - based on Id...
IF    NOT    EXISTS    (    SELECT    1
                    FROM    [TCD].Washer                W
                    JOIN    [TCD].MachineSetup            MS
                        ON    W.WasherId                    =            MS.WasherId
                        AND    W.EcoLabAccountNumber        =            MS.EcoalabAccountNumber
                    WHERE    W.EcoLabAccountNumber        =            @EcoLabAccountNumber
                        AND    W.WasherId                    =            @WasherId
                        AND    MS.GroupId                    =            @WasherGroupId
                        AND    MS.IsTunnel                    =            'TRUE'
                        AND    W.Is_Deleted                =            'FALSE'
                        AND    MS.IsDeleted                =            'FALSE'
				)
			BEGIN
                SET        @ErrorId                        =            51006
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Washer-ID was provided for Updating.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET    @ReturnValue    =    -1
                RETURN    (@ReturnValue)
			END


--Check for uniqueness of PlantWasherNo. and Name
IF    EXISTS        (    SELECT    1
                    FROM    [TCD].Washer                W
                    JOIN    [TCD].MachineSetup            MS
                        ON    W.WasherId                    =            MS.WasherId
                        AND    W.EcoLabAccountNumber        =            MS.EcoalabAccountNumber
                    WHERE    W.EcoLabAccountNumber        =            @EcoLabAccountNumber
                        AND    W.WasherId                    <>            @WasherId
                        AND    (
                            W.PlantWasherNumber            =            @PlantWasherNumber
                            AND
                            MS.MachineName                =            @TunnelName
							)
                        AND    W.Is_Deleted                =            'FALSE'
                        AND    MS.IsDeleted                =            'FALSE'
				)
			BEGIN
                SET        @ErrorId                        =            51002
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Specified Plant Washer #/Name already exists.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET    @ReturnValue    =    -1
                RETURN    (@ReturnValue)
			END


--Check that it's a valid Controller type/model (one that can control a Tunnel)
IF	NOT	EXISTS	(	SELECT	1
					FROM	[TCD].ControllerModelControllerTypeMapping
														CMCTM
					JOIN	[TCD].ConduitController		CC
						ON	CC.ControllerTypeId			=			CMCTM.ControllerTypeId
						AND	CC.ControllerModelId		=			CMCTM.ControllerModelId
					WHERE	CC.EcoalabAccountNumber		=			@EcoLabAccountNumber
						AND	CC.ControllerId				=			@ControllerId
						AND	CC.IsDeleted				=			'FALSE'
						--AND	CMCTM.CanControlTunnel		=			'TRUE'
				)
			BEGIN
				SET		@ErrorId						=			51003
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller was provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END

--IF  (  @ControllerValidate = 1)
--            BEGIN
--                SET        @ErrorId                        =            51003
--                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller was provided.'
--                --GOTO    ErrorHandler
--                RAISERROR    (@ErrorMessage, 16, 1)
--                SET    @ReturnValue    =    -1
--                RETURN    (@ReturnValue)
--            END


--EOF should not be an asocciated formula for the WG...
IF    EXISTS        (    SELECT    1
                    FROM    [TCD].TunnelProgramSetup    TPS
                    WHERE    TPS.EcolabAccountNumber        =            @EcoLabAccountNumber
                        AND    TPS.WasherGroupId            =            @WasherGroupId
                        AND    TPS.ProgramNumber            =            @ProgramNumber
                        AND    TPS.Is_Deleted                =            'FALSE'
				)
			BEGIN
                SET        @ErrorId                        =            51004
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An assoicated formula cannot be specified as End-Of-Formula.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET    @ReturnValue    =    -1
                RETURN    (@ReturnValue)
			END


--WasherMode check
IF    NOT    EXISTS    (    SELECT    1
                    FROM    [TCD].ControllerModelControllerTypeMapping
														CMCTM
                    JOIN    [TCD].ConduitController        CC
                        ON    CC.ControllerTypeId            =            CMCTM.ControllerTypeId
                        AND    CC.ControllerModelId        =            CMCTM.ControllerModelId
                    JOIN    [TCD].[WasherModeMapping]
														CTM2WM
                        ON    CMCTM.Id                    =            CTM2WM.ControllerModelControllerTypeMappingId
                    WHERE    CC.EcoalabAccountNumber        =            @EcoLabAccountNumber
                        AND    CC.ControllerId                =            @ControllerId
                        AND    CC.IsDeleted                =            'FALSE'
                        --AND    CMCTM.CanControlTunnel        =            'TRUE'
                        AND    CTM2WM.WasherModeId            =            @WasherMode
				)
			BEGIN
                SET        @ErrorId                        =            51005
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherMode was provided.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET    @ReturnValue    =    -1
                RETURN    (@ReturnValue)
			END


--select the WasherModelId based on name
SELECT    TOP    1
        @WasherModelId                        =            WMS.WasherModelId
FROM    [TCD].WasherModelSize                WMS
WHERE    WMS.RegionId                        =            @RegionId
    AND    WMS.WasherModelName                    =            @WasherModelName
    AND    WMS.ModelTypeId                    =            2                            --TypeId 2 for Tunnel
    AND    WMS.Is_Deleted                        =            'FALSE'

--LFSWasherNumber duplicate check...
IF    EXISTS    (    SELECT    1
                FROM    [TCD].MachineSetup                    MS
                WHERE    MS.ControllerId                    =            @ControllerId
                    AND    MS.MachineInternalId            =            @LFSWasherNumber
                    AND    MS.IsDeleted                    =            'FALSE'
                    AND    MS.WasherId                        <>            @WasherId
                    AND MS.EcoalabAccountNumber            =            @EcoLabAccountNumber
                    AND MS.IsTunnel                        =            'TRUE'
            )
            BEGIN
                SET        @ErrorId                        =            51010
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate LFSWasher# provided.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET        @ReturnValue    =    -1
                RETURN    (@ReturnValue)
            END
--ETechWasherNumber duplicate check...
IF(@ControllerModelId NOT IN (7,8,9,10,11,14))
BEGIN
IF EXISTS ( SELECT 1
    FROM [TCD].Washer  AS W
    JOIN [TCD].MachineSetup AS MS ON MS.WasherId = W.WasherId 
    where W.ETechWasherNumber = @ETechWasherNumber
	AND W.WasherId = @WasherId
	 AND  MS.IsTunnel                    =            'TRUE'
)  
BEGIN  

SET  @ErrorId      =   51012  
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate ETechWasherNumber# provided.'  
--GOTO ErrorHandler  
RAISERROR (@ErrorMessage, 16, 1)  
SET  @ReturnValue = -1  
RETURN (@ReturnValue)  
END
END

--Now attempt Update...
BEGIN    TRAN

UPDATE    MS
    SET    MS.MachineName                    =            @TunnelName
    ,    MS.ControllerId                =            @ControllerId
    ,    MS.MachineInternalId            =            @LFSWasherNumber
    ,    MS.NumberOfComp                =            @NumberOfComp
    ,    MS.LastModifiedByUserId            =            @UserId
FROM    [TCD].MachineSetup                MS
JOIN    [TCD].Washer                    W
    ON    MS.WasherId                    =            W.WasherId
    AND    MS.EcoalabAccountNumber            =            W.EcolabAccountNumber
WHERE    MS.WasherId                    =            @WasherId
    AND    MS.EcoalabAccountNumber            =            @EcoLabAccountNumber
    AND    MS.IsDeleted                    =            'FALSE'
    AND    W.Is_Deleted                    =            'FALSE'

--check for any error
SET    @ErrorId    =    @@ERROR

IF    (@ErrorId    <>    0)
BEGIN

        IF    @@TRANCOUNT    >    0
		BEGIN
            ROLLBACK    TRAN
		END
	
    SET        @ErrorMessage                =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating washer data.'
    --GOTO    Errorhandler
    RAISERROR    (@ErrorMessage, 16, 1)
    SET    @ReturnValue    =    -1
    RETURN    (@ReturnValue)
END

--else, continue with the rest of the update in the other table...
IF(@ControllerModelId IS NOT NULL AND @ControllerModelId = 7 )
BEGIN
UPDATE    W
    SET    W.ModelId                        =            @WasherModelId
    ,    W.PlantWasherNumber                =            @PlantWasherNumber
    ,    W.WasherMode                    =            @WasherMode
    ,    W.MaxLoad                        =            @MaxLoad
    ,    W.AWEActive                    =            'FALSE'
    ,    W.NumberOfTanks                =            @NumberOfTanks
    ,    W.TransferType                    =            @TransferType
    ,    W.PressExtractor                =            @PressExtractor
    ,    W.EmptyPocketNumber                =            @ProgramNumber
    ,    W.[Description]                =            @Description
    ,    W.LastModifiedByUserId            =            @UserId
    ,    W.LastModifiedTime                =            @CurrentUTCTime
    ,    W.RatioDosingActive                =              NULL    
    ,    W.EndOfFormula                    =            0
    ,    W.NumberOfCompartmentsConveyorBelt     =            @NumberOfCompartmentsConveyorBelt
    ,    W.MinMachineLoad                 =            @MinMachineLoad
    ,    W.MaxMachineLoad                 =            @MaxMachineLoad
    ,    W.ProgramSelectionByTime             =            @ProgramSelectionByTime
    ,    W.WeightSelectionByTime             =            @WeightSelectionByTime
    ,    W.WeightSelectionByAnalogInput     =            @WeightSelectionByAnalogInput
    ,    W.TunInTomMode                     =            @TunInTomMode
    ,    W.SignalStopTunActive             =            @SignalStopTunActive
    ,    W.SignalEjectionTunActive         =            @SignalEjectionTunActive
    ,    W.DelayTimeForTunWashingPrograms     =            @DelayTimeForTunWashingPrograms
    ,    W.KannegiesserPressSpecialMode     =            @KannegiesserPressSpecialMode
    ,    W.ValveOutputsUsedAsTomSignal         =            @ValveOutputsUsedAsTomSignal
    ,    W.ExtendedClockOrDataProtocol         =            @ExtendedClockOrDataProtocol
    ,    W.WeightCorrectionFcc             =            @WeightCorrectionFcc
	,	 W.ETechWasherNumber					=		@ETechWasherNumber
	,	W.KannegiesserDosageInPreparationTankMode = @KannegiesserDosageInPreparationTankMode
	,	W.BatchOk = @BatchOk
FROM    [TCD].Washer                    W
JOIN    [TCD].MachineSetup                MS
    ON    W.WasherId                    =            MS.WasherId
    AND    W.EcoLabAccountNumber            =            MS.EcoalabAccountNumber
WHERE    W.WasherId                    =            @WasherId
    AND    W.EcoLabAccountNumber            =            @EcoLabAccountNumber
    AND    W.Is_Deleted                    =            'FALSE'
    AND    MS.IsDeleted                    =            'FALSE'
END
ELSE IF(@ControllerModelId IS NOT NULL AND ( @ControllerModelId = 8	OR @ControllerModelId = 9	OR @ControllerModelId = 10 OR @ControllerModelId = 11 OR @ControllerModelId = 14))
BEGIN
UPDATE    W
    SET    W.ModelId                        =            @WasherModelId
    ,    W.PlantWasherNumber                =            @PlantWasherNumber
    ,    W.WasherMode                    =            @WasherMode
    ,    W.MaxLoad                        =            @MaxLoad
    ,    W.AWEActive                    =            'FALSE'
    ,    W.NumberOfTanks                =            @NumberOfTanks
    ,    W.TransferType                    =            @TransferType
    ,    W.PressExtractor                =            @PressExtractor
    ,    W.EmptyPocketNumber                =            @ProgramNumber
    ,    W.[Description]                =            @Description
    ,    W.LastModifiedByUserId            =            @UserId
    ,    W.LastModifiedTime                =            @CurrentUTCTime
    ,    W.RatioDosingActive                =              NULL    
    ,    W.EndOfFormula                    =            0
    ,    W.NumberOfCompartmentsConveyorBelt     =            @NumberOfCompartmentsConveyorBelt
    ,    W.MinMachineLoad                 =            @MinMachineLoad
    ,    W.MaxMachineLoad                 =            @MaxMachineLoad
    ,    W.TunInTomMode                     =            @TunInTomMode
    ,    W.DelayTimeForTunWashingPrograms     =            @DelayTimeForTunWashingPrograms
    ,    W.KannegiesserPressSpecialMode     =            @KannegiesserPressSpecialMode
    ,    W.WeightCorrectionFcc             =            @WeightCorrectionFcc
	,	 W.DateAndTimeWhenBatchEjects		=			@DateAndTimeWhenBatchEjects
	,	 W.AutoRinseDesamixAfter			=			@AutoRinseDesamixAfter
	,	 W.AutoRinseDesamix1For				=			@AutoRinseDesamix1For
	,	 W.AutoRinseDesamix2For				=			@AutoRinseDesamix2For
	,	 W.TemperatureAlarmProbe1			=			@TemperatureAlarmProbe1
	,	 W.TemperatureAlarmProbe2			=			@TemperatureAlarmProbe2
	,	 W.TemperatureAlarmProbe3			=			@TemperatureAlarmProbe3
	,	 W.UseMe1OfGroup					=			@UseMe1OfGroup
	,	 W.UseMe2OfGroup					=			@UseMe2OfGroup
	,	 W.ETechWasherNumber					=		@ETechWasherNumber

FROM    [TCD].Washer                    W
JOIN    [TCD].MachineSetup                MS
    ON    W.WasherId                    =            MS.WasherId
    AND    W.EcoLabAccountNumber            =            MS.EcoalabAccountNumber
WHERE    W.WasherId                    =            @WasherId
    AND    W.EcoLabAccountNumber            =            @EcoLabAccountNumber
    AND    W.Is_Deleted                    =            'FALSE'
    AND    MS.IsDeleted                    =            'FALSE'
END
ELSE
BEGIN
UPDATE    W
    SET    W.ModelId                        =            @WasherModelId
    ,    W.PlantWasherNumber                =            @PlantWasherNumber
    ,    W.WasherMode                    =            @WasherMode
    ,    W.MaxLoad                        =            @MaxLoad
    ,    W.AWEActive                    =            @AWEActive
    ,    W.NumberOfTanks                =            @NumberOfTanks
    ,    W.TransferType                    =            @TransferType
    ,    W.PressExtractor                =            @PressExtractor
    ,    W.EmptyPocketNumber                =            @ProgramNumber
    ,    W.[Description]                =            @Description
    ,    W.LastModifiedByUserId            =            @UserId
    ,    W.LastModifiedTime                =            @CurrentUTCTime
    ,   W.RatioDosingActive                =              @RatioDosingActive    
    ,   W.EndOfFormula                    =            @EndOfFormula
    ,    W.LfsWasher                     =            NULL
    ,    W.NumberOfCompartmentsConveyorBelt     =            NULL
    ,    W.MinMachineLoad                 =            NULL
    ,    W.MaxMachineLoad                 =            NULL
    ,    W.ProgramSelectionByTime             =            NULL
    ,    W.WeightSelectionByTime             =            NULL
    ,    W.WeightSelectionByAnalogInput     =            NULL
    ,    W.TunInTomMode                     =            NULL
    ,    W.SignalStopTunActive             =            NULL
    ,    W.SignalEjectionTunActive         =            NULL
    ,    W.DelayTimeForTunWashingPrograms     =            NULL
    ,    W.KannegiesserPressSpecialMode     =            NULL
    ,    W.ValveOutputsUsedAsTomSignal         =            NULL
    ,    W.ExtendedClockOrDataProtocol         =            NULL
    ,    W.WeightCorrectionFcc             =            NULL
	,	 W.ETechWasherNumber					=		@ETechWasherNumber
FROM    [TCD].Washer                    W
JOIN    [TCD].MachineSetup                MS
    ON    W.WasherId                    =            MS.WasherId
    AND    W.EcoLabAccountNumber            =            MS.EcoalabAccountNumber
WHERE    W.WasherId                    =            @WasherId
    AND    W.EcoLabAccountNumber            =            @EcoLabAccountNumber
    AND    W.Is_Deleted                    =            'FALSE'
    AND    MS.IsDeleted                    =            'FALSE'
END
--check for error, if none - commit the tran, else rollback
SET    @ErrorId    =    @@ERROR
IF    (@ErrorId    <>    0)
	BEGIN
        IF    (@@TRANCOUNT    >    0)
			BEGIN
				ROLLBACK
			END

        SET        @ErrorMessage                =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating washer data.'
        --GOTO    Errorhandler
        RAISERROR    (@ErrorMessage, 16, 1)
        SET    @ReturnValue    =    -1
        RETURN    (@ReturnValue)
	END
ELSE
	BEGIN
        IF    (@@TRANCOUNT    >    0)
			BEGIN
				COMMIT
			END

        SET    @OutputTunnelId    =    @WasherId
	END


--IF    (@ErrorId    =    0)
--    BEGIN
--        --GOTO    ExitModule
--        RETURN    (@ReturnValue)
--    END




--ErrorHandler:
--RAISERROR    (@ErrorMessage, 16, 1)
--SET    @ReturnValue    =    -1




--ExitModule:

SET    NOCOUNT    OFF
RETURN    (@ReturnValue)


END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetDeviceModelList]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetDeviceModelList]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [TCD].[GetDeviceModelList](@DeviceTypeId INT = NULL, @RegionId INT = NULL) 
AS 
  BEGIN 
      SET nocount ON; 

     Select  
	 [Id] ,
	 [Description] 	 
     FROM  [TCD].[DeviceModel] 
	 WHERE [DeviceTypeId] = @DeviceTypeId AND [RegionID] = @RegionId
      SET nocount OFF; 	      
  END 
GO

--------------------Etech CustomerCodes intregration dbscript start------------------------------------------------------------------------
--Script to add new record into table TCD.ConduitParameters for CustomerCodes
IF NOT EXISTS(SELECT
					  * FROM TCD.ConduitParameters WHERE TCD.ConduitParameters.Id = 39)
	BEGIN
		INSERT INTO TCD.ConduitParameters(
				TCD.ConduitParameters.Id, 
				TCD.ConduitParameters.Name, 
				TCD.ConduitParameters.Description, 
				TCD.ConduitParameters.MandatoryCol, 
				TCD.ConduitParameters.IsActive, 
				TCD.ConduitParameters.SortOrder, 
				TCD.ConduitParameters.IsTrending)
		VALUES
			   (
				39, 
				-- Id - int
				N'CustomerCodes', 
				-- Name - nvarchar
				N'CustomerCodes', 
				-- Description - nvarchar
				0, 
				-- MandatoryCol - int
				1, 
				-- IsActive - int
				39, 
				-- SortOrder - int
				1 -- IsTrending - bit
			   );
	END;
GO


--Script to add new column ETechCustomerCodesText to TCD.Plant Table
IF NOT EXISTS(SELECT
					  *
				  FROM sys.columns
				  WHERE object_id = OBJECT_ID(N'TCD.Plant')
					AND name = 'ETechCustomerCodesText')
	BEGIN
		ALTER TABLE TCD.Plant
		ADD
				ETechCustomerCodesText VARCHAR(100)NOT NULL
													CONSTRAINT DF_Plant_ETechCustomerCodesText DEFAULT 'CustomerCodes';
	END;
GO


--Procedure GetPlantIndfo updation to get new column value ETechCustomerCodesText
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetPlantInfo]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetPlantInfo;
	END; 
GO 
CREATE PROCEDURE TCD.GetPlantInfo
AS
BEGIN

	SET NOCOUNT ON;

	SELECT
			p.EcolabAccountNumber, 
			p.Name, 
			p.IsETechEnable, 
			p.ETechIpAddress, 
			p.ETechTimeDiff, 
			p.ETechCustomerCodesText
		FROM TCD.plant AS P
		WHERE Is_Deleted = 0;

	SET NOCOUNT OFF;
END;
GO

--SP ProcessConventionalWasherData
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[ProcessConventionalWasherData]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.ProcessConventionalWasherData;
	END; 
GO 
CREATE PROCEDURE TCD.ProcessConventionalWasherData(
	   @Washerid INT, 
	   @Xmltags XML, 
	   @Redflagshiftid INT OUTPUT)
AS
BEGIN
	DECLARE @Batchid INT, 
			@Ecolabwasherid INT, 
			@Currencycode VARCHAR(50), 
			@Machineinternalid INT, 
			@Groupid INT, 
			@Prveformula INT, 
			@Quantity INT, 
			@Maxwashertgroupcapacity INT, 
			@Programmasterid INT, 
			@Nominalload DECIMAL(10, 2), 
			@Maxload DECIMAL(10, 2), 
			@Standardweight DECIMAL(10, 2), 
			@Currentformula INT, 
			@Currentformuladate DATETIME2, 
			@Formulaismodified BIT, 
			@Currentinjection INT, 
			@Currentinjectiondate DATETIME2, 
			@Injectionismodified BIT, 
			@Operationalcount INT, 
			@Operationalismodified BIT, 
			@Currentholdsignal INT, 
			@Currentholdsignaldate DATETIME2, 
			@Holdsignalismodified BIT, 
			@Endofformula INT, 
			@Endofformuladate DATETIME2, 
			@Autoweightentryactive BIT, 
			@Autoweightentryweight DECIMAL(10, 2), 
			@Controllerid INT, 
			@Currentholdsignalvalue INT, 
			@Meterplcaddress INT, 
			@Meterplcaddressismodified INT, 
			@Batchgroupid INT, 
			@Batchformula INT, 
			@Holdtime INT, 
			@Ctetempbatchinjections INT, 
			@Ctetempwaherreadinginjections INT, 
			@Batchstandardwaterusage INT, 
			@Batchactualwaterusage INT, 
			@Batchwaterusageprice DECIMAL(10, 2), 
			@Batchutilityprice DECIMAL(10, 2), 
			@Batchwatertype INT, 
			@Prevgroupid INT, 
			@Washermeterexists BIT, 
			@Extratime INT, 
			@Targetturntime INT, 
			@Ratiodosingenabled BIT, 
			@Ecolabaccountnumber NVARCHAR(25) = NULL, 
			@Previousformuladate DATETIME2, 
			@Previousinjectionstep INT, 
			@Previousinjectionstartdate DATETIME2, 
			@Currentinjectionstep INT, 
			@Washstepbatchid INT, 
			@Prevformulaextratime INT, 
			@Alarmgroupmasterid INT, 
			@Stdwashsteps INT, 
			@Stdinjectionsteps INT, 
			@Ecolabtextilecategoryid INT, 
			@Chaintextilecategoryid INT, 
			@Formulasegmentid INT, 
			@Ecolabsaturationid INT, 
			@Previousshiftid INT, 
			@Currentshiftid INT, 
			@Plantprogramid INT, 
			@Etechlastdroppedat DATETIME2, 
			@Customercodes VARCHAR(100);

	SET @Redflagshiftid = NULL;

	IF EXISTS(SELECT
					  *
				  FROM TEMPDB.DBO.SYSOBJECTS AS o
				  WHERE o.xtype IN('U')
					AND o.id = OBJECT_ID(N'tempdb..#XmlTagsTable'))
		BEGIN
			DROP TABLE
					#XmlTagsTable;
		END;


	CREATE TABLE #XmlTagsTable(
			TagId INT, 
			TagValue NVARCHAR(100), 
			ReceivedTime DATETIME2, 
			TagType NVARCHAR(50), 
			IsModified BIT, 
			ETechLastDropped VARCHAR(100), 
			CustomerCodes VARCHAR(100));


	INSERT INTO #XmlTagsTable(
			TagId, 
			TagValue, 
			ReceivedTime, 
			TagType, 
			IsModified, 
			ETechLastDropped, 
			CustomerCodes)
	SELECT
			T.c.value('@TagId', 'INT')AS TagId, 
			T.c.value('@Value', 'NVARCHAR(100)')AS TagValue, 
			T.c.value('@TimeStamp', 'VARCHAR(100)')AS DateTimeStamp, 
			T.c.value('@TagType', 'VARCHAR(50)')AS TagType, 
			T.c.value('@IsModified', 'BIT')AS TagType, 
			T.c.value('@ETechLastDroppedAt', 'VARCHAR(100)')AS ETechLastDropped, 
			T.c.value('@CustomerCodes', 'VARCHAR(100)')AS CustomerCodes
		FROM @Xmltags.nodes('Tags/Tag')AS T(c)
		WHERE T.c.value('@TagId', 'varchar(100)')IS NOT NULL;

	SELECT
			@Currentformula = TagValue, 
			@Currentformuladate = ReceivedTime, 
			@Formulaismodified = IsModified
		FROM #XmlTagsTable
		WHERE TagType = 'Tag_FRM';

	SELECT
			@Currentinjection = TagValue, 
			@Currentinjectiondate = ReceivedTime, 
			@Injectionismodified = IsModified
		FROM #XmlTagsTable
		WHERE TagType = 'Tag_INJ';

	SELECT
			@Operationalcount = TagValue, 
			@Operationalismodified = IsModified
		FROM #XmlTagsTable
		WHERE TagType = 'Tag_OPC';

	SELECT
			@Endofformula = TagValue, 
			@Endofformuladate = ReceivedTime
		FROM #XmlTagsTable
		WHERE TagType = 'Tag_EOF';

	SELECT
			@Autoweightentryactive = TagValue FROM #XmlTagsTable WHERE TagType = 'Tag_AWEA';

	SELECT
			@Currentholdsignal = TagValue, 
			@Holdsignalismodified = IsModified, 
			@Currentholdsignaldate = ReceivedTime
		FROM #XmlTagsTable
		WHERE TagType = 'Tag_HOLDL';

	SELECT
			@Autoweightentryweight = TagValue, 
			@Etechlastdroppedat = CONVERT(DATETIME, ETechLastDropped), 
			@Customercodes = CustomerCodes
		FROM #XmlTagsTable
		WHERE TagType = 'Tag_AWEW';

	SELECT
			@Meterplcaddress = TagValue, 
			@Meterplcaddressismodified = IsModified
		FROM #XmlTagsTable
		WHERE TagType = 'Tag_MPLC';

	SELECT
			@Ratiodosingenabled = TagValue FROM #XmlTagsTable WHERE TagType = 'Tag_RATA';

	SELECT
			* FROM #XmlTagsTable;

	SELECT
			@Extratime = 0;

	SELECT TOP 1
			@Batchid = BatchId, 
			@Prveformula = ProgramNumber, 
			@Prevgroupid = GroupId, 
			@Previousformuladate = StartDate
		FROM TCD.BatchData
		WHERE MachineId = @Washerid
		  AND EndDate IS NULL
		ORDER BY
			StartDate DESC;

	IF @Previousformuladate IS NOT NULL
		BEGIN
			IF @Currentformuladate < @Previousformuladate
				BEGIN
					RETURN;
				END;
		END;

	IF @Currentformula != @Endofformula
   AND @Currentformula = @Prveformula
   AND @Currentinjection = 0
   AND @Operationalcount = 0
   AND @Currentformuladate <= @Previousformuladate
   AND @Currentinjectiondate > @Previousformuladate
		BEGIN
			--Here means, If the same formula is received without EOF then the timestamp of the formula
			--will be still the old timestamp because value is not changed.
			--In this case assign injection=0 timestamp to formula timestamp
			SELECT
					@Currentformuladate = @Currentinjectiondate;
		END;

	DECLARE @Shiftstartdate TABLE(
			ShiftId INT, 
			ShiftName NVARCHAR(50), 
			ShiftStartdate DATETIME);
	INSERT INTO @Shiftstartdate(
			ShiftId, 
			ShiftName, 
			ShiftStartdate)
	EXEC TCD.GetShiftStartDate @Currentformuladate;

	SELECT DISTINCT
			@Ecolabwasherid = Ws.EcolabWasherId, 
			@Standardweight = Wps.NominalLoad, 
			@Currencycode = Pl.CurrencyCode, 
			@Controllerid = Ctrl.ControllerId, 
			@Targetturntime = Ws.TargetTurnTime * 60
		FROM TCD.Washer AS Ws
			 INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = Ws.WasherId
			 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
			 INNER JOIN TCD.WasherProgramSetup AS Wps ON Wps.WasherGroupId = Wg.WasherGroupId
			 LEFT JOIN TCD.WasherDosingSetup AS Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
			 LEFT JOIN TCD.WasherDosingProductMapping AS Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupId
			 INNER JOIN TCD.Plant AS Pl ON Pl.EcolabAccountNumber = Ws.EcoLabAccountNumber
			 INNER JOIN TCD.ConduitController AS Ctrl ON Ctrl.ControllerId = Mst.ControllerId
		WHERE Ws.WasherId = @Washerid;

	SELECT DISTINCT
			@Machineinternalid = Mst.MachineInternalId, 
			@Groupid = Mst.GroupId
		FROM TCD.Washer AS Ws
			 INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = Ws.WasherId
			 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
			 INNER JOIN TCD.WasherGroupType AS WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
		WHERE Ws.WasherId = @Washerid;

	SELECT DISTINCT
			@Programmasterid = Wps.ProgramId, 
			@Nominalload = Wps.NominalLoad, 
			--Wps.NominalLoad/CONVERT(decimal(10,2), 100) old code
			@Maxload = Ws.MaxLoad, 
			@Extratime = Wps.ExtraTime
		FROM TCD.Washer AS Ws
			 INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = Ws.WasherId
			 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
			 INNER JOIN TCD.WasherGroupType AS WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
			 INNER JOIN TCD.WasherProgramSetup AS Wps ON Wps.WasherGroupId = Wg.WasherGroupId
		WHERE Ws.WasherId = @Washerid
		  AND Wps.ProgramNumber = @Currentformula
		  AND Wps.Is_Deleted = 0;

	IF @Extratime IS NULL
		BEGIN
			SELECT
					@Extratime = 0;
		END;

	SELECT
			@Maxwashertgroupcapacity = MAX(ws.MaxLoad)
		FROM TCD.Washer AS WS
			 INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = ws.WasherId
			 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
		WHERE Mst.GroupId = @Groupid;

	SELECT
			@Washermeterexists = M.MachineCompartment
		FROM Tcd.MachineSetup AS Ms
			 INNER JOIN Tcd.Meter AS M ON M.GroupId = Ms.GroupId
									  AND M.MachineCompartment = Ms.MachineInternalId
		WHERE Ms.WasherId = @Washerid;

	IF @Autoweightentryactive IS NULL
		BEGIN
			SELECT
					@Autoweightentryactive = 0;
		END;

	SELECT
			@Standardweight = @Nominalload * @Maxwashertgroupcapacity / CONVERT(DECIMAL(10, 2), 100);
	SELECT
			@Autoweightentryactive, 
			@Standardweight;
	SELECT
			@Autoweightentryweight = CASE @Autoweightentryactive
										 WHEN 0 THEN @Standardweight
										 ELSE @Autoweightentryweight
									 END;

	SELECT
			@Currentholdsignalvalue = Id FROM TCD.ConduitParameters WHERE Name = 'HoldSignal';

	SELECT
			*
		FROM TCD.BatchData
		WHERE BatchId = @Batchid
		  AND MachineId = @Washerid
		  AND EndDate IS NULL
		ORDER BY
			StartDate DESC;
	IF @Holdsignalismodified != 0
		BEGIN
			IF NOT EXISTS(SELECT TOP 1
								  *
							  FROM TCD.WasherReading
							  WHERE WasherId = @Washerid
								AND DateTimeStamp = @Currentholdsignaldate)
				BEGIN
					INSERT INTO TCD.WasherReading(
							WasherId, 
							ParameterId, 
							ParameterValue, 
							DateTimeStamp, 
							PartitionOn, 
							EcolabWasherId)
					SELECT
							@Washerid, 
							@Currentholdsignalvalue, 
							@Currentholdsignal, 
							@Currentholdsignaldate, 
							(SELECT TOP 1
									 ShiftStartdate FROM @Shiftstartdate), 
							@Ecolabwasherid;
				END;
		END;
	IF @Formulaismodified = 1
	OR @Injectionismodified = 1
	OR @Operationalismodified = 1
		BEGIN
			SELECT
					'IsModified', 
					@Formulaismodified AS FormulaIsModified, 
					@Injectionismodified AS InjectionIsModified, 
					@Operationalismodified AS OperationalIsModified;
			IF @Currentformula != 0
				BEGIN
					DECLARE @Batchshiftid INT, 
							@Batchshiftstartdate DATETIME;

					SELECT
							@Batchshiftstartdate = bd.StartDate
						FROM TCD.BatchData AS bd
						WHERE bd.BatchId = @Batchid;

					IF @Batchshiftstartdate > (SELECT TOP 1
													   [@ShiftStartDate].ShiftStartdate
												   FROM @Shiftstartdate
												   ORDER BY
													   [@ShiftStartDate].ShiftStartdate ASC)
				   AND DATEADD(second, @Extratime, @Currentformuladate) > (SELECT TOP 1
																				   [@ShiftStartDate].ShiftStartdate
																			   FROM @Shiftstartdate
																			   ORDER BY
																				   [@ShiftStartDate].ShiftStartdate DESC)
						BEGIN

							SELECT TOP 1
									@Batchshiftid = ssdt.ShiftId
								FROM @Shiftstartdate AS ssdt
								ORDER BY
									ssdt.ShiftStartdate DESC;
						END;
					ELSE
						BEGIN
							SELECT TOP 1
									@Batchshiftid = ssdt.ShiftId
								FROM @Shiftstartdate AS ssdt
								ORDER BY
									ssdt.ShiftStartdate ASC;
						END;


					SELECT DISTINCT
							@Prevformulaextratime = Wps.ExtraTime
						FROM TCD.Washer AS Ws
							 INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = Ws.WasherId
							 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
							 INNER JOIN TCD.WasherGroupType AS WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
							 INNER JOIN TCD.WasherProgramSetup AS Wps ON Wps.WasherGroupId = Wg.WasherGroupId
						WHERE Ws.WasherId = @Washerid
						  AND Wps.ProgramNumber = @Prveformula
						  AND Wps.Is_Deleted = 0;

					IF @Prevformulaextratime IS NULL
						BEGIN
							SELECT
									@Prevformulaextratime = 0;
						END;

					IF @Currentformula = @Endofformula
						BEGIN
							SELECT
									* FROM #XmlTagsTable;
							IF EXISTS(SELECT TOP 1
											  *
										  FROM TCD.BatchData
										  WHERE BatchId = @Batchid
											AND MachineId = @Washerid
											AND EndDate IS NULL
										  ORDER BY
											  StartDate DESC)
								BEGIN

									UPDATE TCD.BatchData SET
											EndDate = DATEADD(second, @Prevformulaextratime, @Currentformuladate), 
											EndDateFormula = @Currentformuladate, 
											ShiftId = @Batchshiftid
										WHERE
											BatchId = @Batchid
										AND MachineId = @Washerid;   
	   
									--DECLARE @ShiftMapping1 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
									--INSERT INTO @ShiftMapping1(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate,1, @RedFlagShiftId OUTPUT

									SELECT TOP 1
											@Previousinjectionstep = StepCompartment, 
											@Previousinjectionstartdate = StartTime
										FROM TCD.BatchWashStepData
										WHERE BatchId = @Batchid
										  AND EndTime IS NULL
										ORDER BY
											StartTime DESC;
									IF @Previousinjectionstep IS NOT NULL
										BEGIN
											UPDATE TCD.BatchWashStepData SET
													EndTime = DATEADD(second, @Extratime, @Currentformuladate)
												WHERE
													BatchId = @Batchid
												AND StepCompartment = @Previousinjectionstep
												AND StartTime = @Previousinjectionstartdate;
										END;

								END;
						END;
					ELSE
						BEGIN
							IF @Currentformula != @Prveformula
						   AND @Batchid IS NOT NULL
								BEGIN
									IF EXISTS(SELECT TOP 1
													  *
												  FROM TCD.BatchData
												  WHERE BatchId = @Batchid
													AND MachineId = @Washerid
													AND EndDate IS NULL
												  ORDER BY
													  StartDate DESC)
										BEGIN
											UPDATE TCD.BatchData SET
													EndDate = @Currentformuladate, 
													EndDateFormula = @Currentformuladate, 
													ShiftId = @Batchshiftid
												WHERE
													BatchId = @Batchid
												AND MachineId = @Washerid;

											INSERT TCD.BatchParameters(
													BatchId, 
													EcolabWasherId, 
													ParameterId, 
													ParameterValue, 
													PartitionOn)
											SELECT
													@Batchid, 
													@Ecolabwasherid, 
													19, 
													1, 
													(SELECT TOP 1
															 ShiftStartdate FROM @Shiftstartdate); 
		   
											--  DECLARE @ShiftMapping2 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
											--INSERT INTO @ShiftMapping2(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate,1, @RedFlagShiftId OUTPUT

											SELECT TOP 1
													@Previousinjectionstep = StepCompartment, 
													@Previousinjectionstartdate = StartTime
												FROM TCD.BatchWashStepData
												WHERE BatchId = @Batchid
												  AND EndTime IS NULL
												ORDER BY
													StartTime DESC;
											IF @Previousinjectionstep IS NOT NULL
												BEGIN
													UPDATE TCD.BatchWashStepData SET
															EndTime = @Currentformuladate
														WHERE
															BatchId = @Batchid
														AND StepCompartment = @Previousinjectionstep
														AND StartTime = @Previousinjectionstartdate;
												END;

										END;
								END;
							ELSE
								BEGIN
									IF @Currentinjection = 0
								   AND @Operationalcount = 0
								   AND @Currentformuladate != @Previousformuladate
										BEGIN
											IF EXISTS(SELECT TOP 1
															  *
														  FROM TCD.BatchData
														  WHERE BatchId = @Batchid
															AND MachineId = @Washerid
															AND EndDate IS NULL
														  ORDER BY
															  StartDate DESC)
												BEGIN
													UPDATE TCD.BatchData SET
															EndDate = @Currentinjectiondate, 
															ShiftId = @Batchshiftid, 
															EndDateFormula = @Currentinjectiondate
														WHERE
															BatchId = @Batchid
														AND MachineId = @Washerid;

													INSERT TCD.BatchParameters(
															BatchId, 
															EcolabWasherId, 
															ParameterId, 
															ParameterValue, 
															PartitionOn)
													SELECT
															@Batchid, 
															@Ecolabwasherid, 
															19, 
															1, 
															(SELECT TOP 1
																	 ShiftStartdate FROM @Shiftstartdate);

													-- DECLARE @ShiftMapping3 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
													--INSERT INTO @ShiftMapping3(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentInjectionDate,1, @RedFlagShiftId OUTPUT

													SELECT TOP 1
															@Previousinjectionstep = StepCompartment, 
															@Previousinjectionstartdate = StartTime
														FROM TCD.BatchWashStepData
														WHERE BatchId = @Batchid
														  AND EndTime IS NULL
														ORDER BY
															StartTime DESC;
													IF @Previousinjectionstep IS NOT NULL
														BEGIN
															UPDATE TCD.BatchWashStepData SET
																	EndTime = @Currentinjectiondate
																WHERE
																	BatchId = @Batchid
																AND StepCompartment = @Previousinjectionstep
																AND StartTime = @Previousinjectionstartdate;
														END;

												END;
										END;
								END;
						END;
			
					-- Hold Time
					IF EXISTS(SELECT TOP 1
									  *
								  FROM TCD.BatchData
								  WHERE BatchId = @Batchid
									AND MachineId = @Washerid
									AND EndDate IS NOT NULL
								  ORDER BY
									  StartDate DESC)
						BEGIN


							SELECT
									@Holdtime = SUM(Wr.ParameterValue)
								FROM TCD.BatchData AS Bd
									 INNER JOIN TCD.WasherReading AS Wr ON Wr.WasherId = Bd.MachineId
								WHERE Bd.BatchId = @Batchid
								  AND Wr.DateTimeStamp BETWEEN Bd.StartDate AND Bd.EndDate
								  AND Wr.ParameterId = 9; -- Hold Signal value

							INSERT TCD.BatchParameters(
																  BatchId, 
																  EcolabWasherId, 
																  ParameterId, 
																  ParameterValue, 
																  PartitionOn)
							SELECT
									@Batchid, 
									@Ecolabwasherid, 
									17, 
									@Holdtime, 
									(SELECT TOP 1
											 ShiftStartdate FROM @Shiftstartdate);


						END;
					
					-- CapturingMeter Plc Address EndRedaing 
					IF EXISTS(SELECT TOP 1
									  *
								  FROM TCD.BatchData
								  WHERE BatchId = @Batchid
									AND MachineId = @Washerid
									AND EndDate IS NOT NULL
								  ORDER BY
									  StartDate DESC)
						BEGIN
							IF @Washermeterexists IS NOT NULL
						   AND @Meterplcaddress > 0
								BEGIN
									IF @Meterplcaddressismodified != 0
										BEGIN
											IF NOT EXISTS(SELECT TOP 1
																  *
															  FROM TCD.WasherReading
															  WHERE WasherId = @Washerid
																AND DateTimeStamp = @Currentformuladate)
												BEGIN
													INSERT INTO TCD.WasherReading(
															WasherId, 
															ParameterId, 
															ParameterValue, 
															DateTimeStamp, 
															PartitionOn, 
															EcolabWasherId)
													SELECT
															@Washerid, 
															14, 
															--MeterPlcAddress for EndSReading
															@Meterplcaddress, 
															@Currentformuladate, 
															(SELECT TOP 1
																	 ShiftStartdate FROM @Shiftstartdate), 
															@Ecolabwasherid;
												END;

										END;
								END;
						END;
									
					--Start Good or Bad Injection in BatchDataTable
					IF EXISTS(SELECT TOP 1
									  *
								  FROM TCD.BatchData
								  WHERE BatchId = @Batchid
									AND MachineId = @Washerid
									AND EndDate IS NOT NULL
								  ORDER BY
									  StartDate DESC)
						BEGIN
							WITH CteTempWaherReadingInjections(
									InjectionsCount, 
									BatchId, 
									WasherId, 
									ProgramNumber, 
									Injectons)
								AS(SELECT DISTINCT
										   Wr.ParameterValue, 
										   BD.BatchId, 
										   Wr.WasherId, 
										   Bd.ProgramNumber, 
										   Wr.ParameterValue
									   FROM TCD.BatchData AS Bd
											INNER JOIN TCD.WasherReading AS Wr ON Wr.WasherId = Bd.MachineId
									   WHERE Wr.ParameterId = 10
										 AND Wr.ParameterValue <> 0
										 AND Bd.BatchId = @Batchid
										 AND WR.DateTimeStamp BETWEEN BD.StartDate AND BD.EndDate)
								SELECT
										@Ctetempwaherreadinginjections = COUNT(CTE1.InjectionsCount)
									FROM CteTempWaherReadingInjections AS CTE1
										 INNER JOIN TCD.BatchData AS Bd ON Bd.BatchId = CTE1.BatchId
									WHERE Bd.BatchId = @Batchid;

							WITH CteTempBatchInjections(
									InjectionsCount, 
									BatchId, 
									WasherId, 
									ProgramNumber, 
									Injectons)
								AS(SELECT DISTINCT
										   Wdpm.InjectionNumber, 
										   Bd.BatchId, 
										   Wps.ProgramNumber, 
										   Ws.WasherId, 
										   Wdpm.InjectionNumber
									   FROM TCD.Washer AS WS
											INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = WS.WasherId
											INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
											INNER JOIN TCD.WasherProgramSetup AS Wps ON Wps.WasherGroupId = Wg.WasherGroupId
											INNER JOIN TCD.WasherDosingSetup AS Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
											INNER JOIN TCD.WasherDosingProductMapping AS Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
											INNER JOIN TCD.ProductdataMapping AS Pdm ON Pdm.ProductId = Wdpm.ProductId
											INNER JOIN TCD.BatchData AS Bd ON Bd.MachineId = Ws.WasherId
											INNER JOIN TCD.WasherReading AS Wr ON Wr.WasherId = Bd.MachineId
									   WHERE Wps.ProgramNumber = @Prveformula
										 AND Bd.BatchId = @Batchid
										 AND Ws.WasherId = @Washerid)
								SELECT
										@Ctetempbatchinjections = COUNT(CTE2.InjectionsCount)
									FROM CteTempBatchInjections AS CTE2
										 INNER JOIN TCD.BatchData AS Bd ON Bd.BatchId = CTE2.BatchId
									WHERE Bd.BatchId = @Batchid;


							INSERT Tcd.BatchParameters(
									BatchId, 
									EcolabWasherId, 
									ParameterId, 
									ParameterValue, 
									PartitionOn)
							SELECT
									@Batchid, 
									@Ecolabwasherid, 
									18, 
									CASE
										WHEN @Ctetempbatchinjections = @Ctetempwaherreadinginjections THEN 1
										WHEN @Ctetempbatchinjections != @Ctetempwaherreadinginjections THEN 3
									END, 
									(SELECT TOP 1
											 ShiftStartdate FROM @Shiftstartdate);

						END;
					--End Good or Bad Injection in BatchDataTable	
					IF @Operationalcount = 0
				   AND @Currentinjection = 0
				   AND @Currentformula != @Endofformula
						BEGIN
							IF NOT EXISTS(SELECT TOP 1
												  *
											  FROM TCD.BatchData
											  WHERE MachineId = @Washerid
												AND StartDate = @Currentformuladate)
								BEGIN					
	   
									--Start Rollup for previous completed shift
									IF CAST(@Currentformuladate AS DATE) < CAST(GETUTCDATE()AS DATE)
										BEGIN
											SELECT TOP 1
													@Previousshiftid = ShiftId
												FROM TCD.BatchData
												WHERE MachineId = @Washerid
												ORDER BY
													StartDate DESC;
											SELECT TOP 1
													@Currentshiftid = ShiftId FROM @Shiftstartdate;
											IF @Currentshiftid != @Previousshiftid
												BEGIN EXEC TCD.ProductionShiftDataRollup @Previousshiftid, @Redflagshiftid OUTPUT;
													IF @Redflagshiftid IS NULL
														BEGIN
															SET @Redflagshiftid = @Previousshiftid;
														END;
												END;
										END;
									--End Rollup for previous completed shift
	   
									--Start Getting InjectionCount and StepCount
									SELECT
											@Stdinjectionsteps = COUNT(DISTINCT wdpm.WasherDosingSetupId), 
											@Stdwashsteps = COUNT(DISTINCT wds.WasherDosingSetupId) - COUNT(DISTINCT wdpm.WasherDosingSetupId)
										FROM TCD.WasherDosingProductMapping AS wdpm
											 RIGHT JOIN tcd.WasherDosingSetup AS wds ON wdpm.WasherDosingSetupId = wds.WasherDosingSetupId
										WHERE wds.GroupId = @Groupid
										  AND wds.ProgramNumber = @Currentformula;
									--End Getting InjectionCount and StepCount
									--Start-----ProgramMasterID logic for PlantChainProgram
									SELECT
											@Plantprogramid = pm.PlantProgramId, 
											@Ecolabtextilecategoryid = pm.EcolabTextileCategoryId, 
											@Chaintextilecategoryid = pm.ChainTextileId, 
											@Formulasegmentid = pm.FormulaSegmentId, 
											@Ecolabsaturationid = pm.EcolabSaturationId
										FROM TCD.ProgramMaster AS pm
										WHERE pm.ProgramId = @Programmasterid
										  AND pm.Is_Deleted = 0;
									IF @Plantprogramid <> 0
								   AND @Plantprogramid IS NOT NULL
										BEGIN
											--Assign value from plantchainprogram table based on plantprogramId
											SELECT
													@Ecolabtextilecategoryid = pcp.EcolabTextileCategoryId, 
													@Chaintextilecategoryid = pcp.ChainTextileCategoryId, 
													@Formulasegmentid = pcp.FormulaSegmentId, 
													@Ecolabsaturationid = pcp.EcolabSaturationId
												FROM tcd.PlantChainProgram AS pcp
												WHERE pcp.PlantProgramId = @Plantprogramid
												  AND pcp.Is_Deleted = 0;
										END;
									--End-----ProgramMasterID logic for PlantChainProgram

									INSERT INTO TCD.BatchData(
											ControllerBatchId, 
											EcolabWasherId, 
											GroupId, 
											MachineInternalId, 
											PlantWasherNumber, 
											StartDate, 
											EndDate, 
											ProgramNumber, 
											ProgramMasterId, 
											MachineId, 
											ActualWeight, 
											StandardWeight, 
											CurrencyCode, 
											ShiftId, 
											PartitionOn, 
											TargetTurnTime, 
											StdInjectionSteps, 
											StdWashSteps, 
											EcolabTextileCategoryId, 
											ChainTextileCategoryId, 
											FormulaSegmentId, 
											EcolabSaturationId, 
											PlantProgramId, 
											ETechlastDroppedTimeStamp)
									SELECT DISTINCT
											0, 
											@Ecolabwasherid, 
											@Groupid, 
											@Machineinternalid, 
											Ws.PlantWasherNumber, 
											@Currentformuladate, 
											NULL, 
											@Currentformula, 
											@Programmasterid, 
											@Washerid, 
											@Autoweightentryweight, 
											@Standardweight, 
											@Currencycode, 
											(SELECT TOP 1
													 ShiftId FROM @Shiftstartdate), 
											(SELECT TOP 1
													 ShiftStartdate FROM @Shiftstartdate), 
											@Targetturntime, 
											@Stdinjectionsteps, 
											@Stdwashsteps, 
											@Ecolabtextilecategoryid, 
											@Chaintextilecategoryid, 
											@Formulasegmentid, 
											@Ecolabsaturationid, 
											@Plantprogramid, 
											@Etechlastdroppedat
										FROM TCD.Washer AS Ws
											 INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = Ws.WasherId
											 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
											 INNER JOIN TCD.WasherGroupType AS WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
										WHERE Ws.WasherId = @Washerid;

									SET @Batchid = SCOPE_IDENTITY();

									INSERT INTO TCD.BatchParameters(
											BatchId, 
											EcolabWasherId, 
											ParameterId, 
											ParameterValue, 
											PartitionOn)
									SELECT
											@Batchid, 
											@Ecolabwasherid, 
											38, 
											@Stdwashsteps, 
											(SELECT TOP 1
													 ShiftStartdate FROM @Shiftstartdate);

									--If the received formula is not configured in enVision then create an alarm 
									IF @Programmasterid IS NULL
										BEGIN
											SELECT
													@Ecolabaccountnumber = EcolabAccountNumber FROM TCD.Plant;
											SELECT
													@Alarmgroupmasterid = AGM.AlarmGroupMasterId
												FROM TCD.AlarmGroupMsterVsControllerModelType AS AGMVCMT
													 INNER JOIN TCD.AlarmGroupMaster AS AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
												WHERE AGMVCMT.AlarmCode = 9000;
											INSERT INTO TCD.AlarmData(
													EcoalabAccountNumber, 
													AlarmCode, 
													BatchId, 
													controllerID, 
													StartDate, 
													GroupId, 
													MachineInternalId, 
													ProgramId, 
													IsActive, 
													EndDate, 
													MachineId, 
													AlarmGroupMasterId, 
													PartitionOn)
											SELECT
													@Ecolabaccountnumber, 
													9000, 
													@Batchid, 
													@Controllerid, 
													@Currentformuladate, 
													@Groupid, 
													@Machineinternalid, 
													@Currentformula, 
													0, 
													@Currentformuladate, 
													@Washerid, 
													@Alarmgroupmasterid, 
													@Currentformuladate;
										END;


									INSERT INTO TCD.BatchCustomerData(
											BatchId, 
											CustomerId, 
											Weight, 
											PiecesCount, 
											PartitionOn, 
											EcolabWasherId)
									SELECT
											Bd.BatchId,  
											--SELECT @BatchID,
											Pc.ID, 
											@Autoweightentryweight, 
											ROUND(COALESCE(@Autoweightentryweight * Pm.Pieces / NULLIF(Pm.Weight, 0), 0), 0), 
											(SELECT TOP 1
													 ShiftStartdate FROM @Shiftstartdate), 
											@Ecolabwasherid
										FROM TCD.Washer AS WS
											 INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = ws.WasherId
											 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
											 INNER JOIN TCD.WasherProgramSetup AS Wps ON Wps.WasherGroupId = Wg.WasherGroupId
											 INNER JOIN TCD.ProgramMaster AS Pm ON Pm.ProgramId = Wps.ProgramId
											 INNER JOIN TCD.PlantCustomer AS Pc ON Pc.ID = Pm.CustomerId
											 INNER JOIN TCD.BatchData AS Bd ON Bd.MachineId = Ws.WasherId
										WHERE Ws.WasherId = @Washerid
										  AND Wps.ProgramNumber = @Currentformula
										  AND Bd.BatchId = @Batchid
										  AND Pm.CustomerId != -1;

									IF @Washermeterexists IS NOT NULL
								   AND @Meterplcaddress > 0
										BEGIN
											IF @Meterplcaddressismodified != 0
												BEGIN
													INSERT INTO TCD.WasherReading(
															WasherId, 
															ParameterId, 
															ParameterValue, 
															DateTimeStamp, 
															PartitionOn, 
															EcolabWasherId)
													SELECT
															@Washerid, 
															13, 
															--MeterPlcAddress for StartReading
															@Meterplcaddress, 
															@Currentformuladate, 
															(SELECT TOP 1
																	 ShiftStartdate FROM @Shiftstartdate), 
															@Ecolabwasherid;
												END;
										END;
								END;
						END;
					IF @Batchid IS NOT NULL
						BEGIN
							IF @Currentinjection <= 0
								BEGIN
									SET @Currentinjectiondate = @Currentformuladate;
								END;
							IF NOT EXISTS(SELECT TOP 1
												  *
											  FROM TCD.WasherReading
											  WHERE WasherId = @Washerid
												AND DateTimeStamp = @Currentinjectiondate)
								BEGIN
									INSERT INTO TCD.WasherReading(
											WasherId, 
											ParameterId, 
											ParameterValue, 
											DateTimeStamp, 
											PartitionOn, 
											EcolabWasherId)
									SELECT
											@Washerid, 
											CASE TagType
												WHEN 'Tag_FRM' THEN 5
												WHEN 'Tag_INJ' THEN 10
												WHEN 'Tag_OPC' THEN 11
											END, 
											TagValue, 
											@Currentinjectiondate, 
											(SELECT TOP 1
													 ShiftStartdate FROM @Shiftstartdate), 
											@Ecolabwasherid
										FROM #XmlTagsTable
										WHERE Tagtype IN('Tag_FRM', 'Tag_INJ', 'Tag_OPC');
								END;
						END;
					IF @Currentinjection > 0
						BEGIN
							IF @Ratiodosingenabled = 1
								BEGIN
									IF NOT EXISTS(SELECT TOP 1
														  *
													  FROM TCD.BatchProductData
													  WHERE TimeStamp = @Currentinjectiondate
														AND batchid = @Batchid)
										BEGIN
											INSERT INTO TCD.BatchProductData(
													BatchId, 
													StepCompartment, 
													ActualQuantity, 
													StandardQuantity, 
													Price, 
													TimeStamp, 
													PartitionOn, 
													EcolabWasherId, 
													ProductId)
											SELECT
													Bd.BatchId	
													--SELECT @BatchID	
													, 
													Wds.StepNumber, 
													@Nominalload / CONVERT(DECIMAL(10, 2), 100) * Wdpm.Quantity * Ws.MaxLoad / CONVERT(DECIMAL(10, 2),
													100) * @Autoweightentryweight / @Standardweight AS ActualQuantity, 
													@Nominalload / CONVERT(DECIMAL(10, 2), 100) * Wdpm.Quantity * Ws.MaxLoad / CONVERT(DECIMAL(10, 2),
													100) * @Autoweightentryweight / @Standardweight AS StandardQuantity, 
													@Nominalload / CONVERT(DECIMAL(10, 2), 100) * Wdpm.Quantity * @Maxwashertgroupcapacity / CONVERT(
													DECIMAL(10, 2), 100) * tcd.FnChemicalCostInOunce(Pdm.ProductID)AS Price, 
													@Currentinjectiondate, 
													(SELECT TOP 1
															 ShiftStartdate FROM @Shiftstartdate), 
													@Ecolabwasherid, 
													Pdm.ProductID
												FROM TCD.Washer AS WS
													 INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = ws.WasherId
													 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
													 INNER JOIN TCD.WasherGroupType AS WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
													 INNER JOIN TCD.WasherProgramSetup AS Wps ON Wps.WasherGroupId = Wg.WasherGroupId
													 INNER JOIN TCD.WasherDosingSetup AS Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
													 INNER JOIN TCD.WasherDosingProductMapping AS Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
													 INNER JOIN TCD.ProductdataMapping AS Pdm ON Pdm.ProductId = Wdpm.ProductId
													 INNER JOIN TCD.BatchData AS Bd ON Bd.MachineId = Ws.WasherId
												WHERE Ws.WasherId = @Washerid
												  AND Wps.ProgramNumber = @Currentformula
												  AND Wdpm.InjectionNumber = @Currentinjection
												  AND Bd.BatchId = @Batchid
												  AND Wps.Is_Deleted = 0
												  AND Pdm.Is_Deleted = 0;
										END;
								END;
							ELSE
								BEGIN
									IF NOT EXISTS(SELECT TOP 1
														  *
													  FROM TCD.BatchProductData
													  WHERE TimeStamp = @Currentinjectiondate
														AND batchid = @Batchid)
										BEGIN
											INSERT INTO TCD.BatchProductData(
													BatchId, 
													StepCompartment, 
													ActualQuantity, 
													StandardQuantity, 
													Price, 
													TimeStamp, 
													PartitionOn, 
													EcolabWasherId, 
													ProductId)
											SELECT
													Bd.BatchId		
													--SELECT @BatchID
													, 
													Wds.StepNumber, 
													@Nominalload / CONVERT(DECIMAL(10, 2), 100) * Wdpm.Quantity * Ws.MaxLoad / CONVERT(DECIMAL(10, 2),100)AS ActualQuantity, 
													@Nominalload / CONVERT(DECIMAL(10, 2), 100) * Wdpm.Quantity * Ws.MaxLoad / CONVERT(DECIMAL(10, 2),100)AS StandardQuantity, 
													@Nominalload / CONVERT(DECIMAL(10, 2), 100) * Wdpm.Quantity * @Maxwashertgroupcapacity / CONVERT(DECIMAL(10, 2), 100) * tcd.FnChemicalCostInOunce(Pdm.ProductID)AS Price, 
													@Currentinjectiondate, 
													(SELECT TOP 1
															 ShiftStartdate FROM @Shiftstartdate), 
													@Ecolabwasherid, 
													Pdm.ProductID
												FROM TCD.Washer AS WS
													 INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = ws.WasherId
													 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
													 INNER JOIN TCD.WasherGroupType AS WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
													 INNER JOIN TCD.WasherProgramSetup AS Wps ON Wps.WasherGroupId = Wg.WasherGroupId
													 INNER JOIN TCD.WasherDosingSetup AS Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
													 INNER JOIN TCD.WasherDosingProductMapping AS Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
													 INNER JOIN TCD.ProductdataMapping AS Pdm ON Pdm.ProductId = Wdpm.ProductId
													 INNER JOIN TCD.BatchData AS Bd ON Bd.MachineId = Ws.WasherId
												WHERE Ws.WasherId = @Washerid
												  AND Wps.ProgramNumber = @Currentformula
												  AND Wdpm.InjectionNumber = @Currentinjection
												  AND Bd.BatchId = @Batchid
												  AND Wps.Is_Deleted = 0
												  AND Pdm.Is_Deleted = 0;
										END;
								END;	
							
							--Populating BatchWashstepdata
							SELECT TOP 1
									@Previousinjectionstep = StepCompartment, 
									@Previousinjectionstartdate = StartTime
								FROM TCD.BatchWashStepData
								WHERE BatchId = @Batchid
								  AND EndTime IS NULL
								ORDER BY
									StartTime DESC;

							IF NOT EXISTS(SELECT TOP 1
												  *
											  FROM TCD.BatchWashStepData
											  WHERE StartTime = @Currentinjectiondate
												AND batchid = @Batchid)
								BEGIN
									SELECT
											@Currentinjectionstep = Wds.StepNumber, 
											@Washstepbatchid = Bd.BatchId
										FROM TCD.Washer AS WS
											 INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = ws.WasherId
											 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
											 INNER JOIN TCD.WasherGroupType AS WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
											 INNER JOIN TCD.WasherProgramSetup AS Wps ON Wps.WasherGroupId = Wg.WasherGroupId
											 INNER JOIN TCD.WasherDosingSetup AS Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
											 INNER JOIN TCD.WasherDosingProductMapping AS Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
											 INNER JOIN TCD.ProductdataMapping AS Pdm ON Pdm.ProductId = Wdpm.ProductId
											 INNER JOIN TCD.BatchData AS Bd ON Bd.MachineId = Ws.WasherId
										WHERE Ws.WasherId = @Washerid
										  AND Wps.ProgramNumber = @Currentformula
										  AND Wdpm.InjectionNumber = @Currentinjection
										  AND Bd.BatchId = @Batchid
										  AND Wps.Is_Deleted = 0
										  AND Pdm.Is_Deleted = 0;

									IF @Currentinjectionstep IS NOT NULL
										BEGIN
											INSERT INTO TCD.BatchWashStepData(
													BatchId, 
													StepCompartment, 
													StartTime, 
													PartitionOn, 
													EcolabWasherId)
											VALUES
												   (
													@Washstepbatchid, 
													@Currentinjectionstep, 
													@Currentinjectiondate, 
													(SELECT TOP 1
															 ShiftStartdate FROM @Shiftstartdate), 
													@Ecolabwasherid);

											UPDATE TCD.BatchWashStepData SET
													EndTime = @Currentinjectiondate
												WHERE
													BatchId = @Batchid
												AND StepCompartment = @Previousinjectionstep
												AND StartTime = @Previousinjectionstartdate;
										END;

								END;
							--End Populating BatchWashstepdata

							--Start Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
							IF NOT EXISTS(SELECT
												  * FROM TCD.BatchParameters WHERE ParameterId = 37
																			   AND batchid = @Batchid)
								BEGIN
									INSERT INTO TCD.BatchParameters(
											BatchId, 
											EcolabWasherId, 
											ParameterId, 
											ParameterValue, 
											PartitionOn)
									SELECT
											@Batchid, 
											@Ecolabwasherid, 
											37, 
											1, 
											(SELECT TOP 1
													 ShiftStartdate FROM @Shiftstartdate);
								END;
							ELSE
								BEGIN
									UPDATE TCD.BatchParameters SET
											ParameterValue = @Currentinjection
										WHERE
											ParameterId = 37
										AND batchid = @Batchid;
								END;
							--End Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record

							--Start Updating CustomerCodes in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
							IF NOT EXISTS(SELECT
												  * FROM TCD.BatchParameters WHERE ParameterId = 39
																			   AND batchid = @Batchid)
								BEGIN
									INSERT INTO TCD.BatchParameters(
											BatchId, 
											EcolabWasherId, 
											ParameterId, 
											ParameterValue, 
											PartitionOn)
									SELECT
											@Batchid, 
											@Ecolabwasherid, 
											39, 
											@Customercodes, 
											(SELECT TOP 1
													 ShiftStartdate FROM @Shiftstartdate);
								END;
							ELSE
								BEGIN
									UPDATE TCD.BatchParameters SET
											ParameterValue = @Customercodes
										WHERE
											ParameterId = 39
										AND batchid = @Batchid;
								END;
						----Start Updating CustomerCodes in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record

						END;

					UPDATE TCD.ConduitController SET
							LastConnectedTime = GETUTCDATE()
						WHERE
							ControllerId = @Controllerid;
				END;
		END;
END;
GO




--SP ProcessTunnelWasherData
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[ProcessTunnelWasherData]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.ProcessTunnelWasherData;
	END; 
GO 
CREATE PROCEDURE TCD.ProcessTunnelWasherData(
	   @Washerid INT, 
	   @Xmltags XML, 
	   @Redflagshiftid INT OUTPUT)
AS
BEGIN
	DECLARE @Batchid INT, 
			@Ecolabwasherid INT, 
			@Currencycode VARCHAR(50), 
			@Machineinternalid INT, 
			@Groupid INT, 
			@Prveformula INT, 
			@Quantity INT, 
			@Maxwashertgroupcapacity INT, 
			@Prevbatchid INT, 
			@Prevloadid INT, 
			@Existedloadid INT, 
			@Numberofcompartments INT, 
			@Programmasterid INT, 
			@Nominalload DECIMAL(10, 2), 
			@Maxload DECIMAL(10, 2), 
			@Standardweight DECIMAL(10, 2), 
			@Plantwashernumber INT, 
			@Currentday DATE = CAST(GETUTCDATE()AS DATE), 
			@Temptunneltimestamp DATETIME2, 
			@Controllerid INT, 
			@Currentholdsignal INT, 
			@Totalruntime INT, 
			@Batchgroupid INT, 
			@Batchformula INT, 
			@Batchstartdate DATETIME2, 
			@Batchenddate DATETIME2, 
			@Holdtime INT, 
			@Ctetempbatchtunnelwashsteps INT, 
			@Ctetemtunnelwashsetps INT, 
			@Prevformula INT, 
			@Prevstepcompartment INT, 
			@Batchstandardwaterusage INT, 
			@Batchactualwaterusage INT, 
			@Batchwaterusageprice DECIMAL(10, 2), 
			@Batchutilityprice DECIMAL(10, 2), 
			@Batchwatertype INT, 
			@Extratime INT, 
			@Targetturntime INT, 
			@Ecolabaccountnumber NVARCHAR(25) = NULL, 
			@Alarmgroupmasterid INT, 
			@Partitionon SMALLDATETIME, 
			@Stdinjectionsteps INT, 
			@Stdwashsteps INT, 
			@Ecolabtextilecategoryid INT, 
			@Chaintextilecategoryid INT, 
			@Formulasegmentid INT, 
			@Ecolabsaturationid INT, 
			@Plantprogramid INT, 
			@Previousshiftid INT, 
			@Currentshiftid INT, 
			@Etechlastdroppedat DATETIME2, 
			@Customercodes VARCHAR(100);

	SELECT
			@Extratime = 0;

	SELECT DISTINCT
			@Numberofcompartments = MST.NumberOfComp, 
			@Ecolabwasherid = Ws.EcolabWasherId
		FROM TCD.Washer AS Ws
			 INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = Ws.WasherId
		WHERE Ws.WasherId = @Washerid
		  AND Ws.Is_Deleted = 0;


	IF EXISTS(SELECT
					  *
				  FROM TEMPDB.DBO.SYSOBJECTS AS o
				  WHERE o.xtype IN('U')
					AND o.id = OBJECT_ID(N'tempdb..#XmlTagsTable'))
		BEGIN
			DROP TABLE
					#XmlTagsTable;
		END;
	CREATE TABLE #XmlTagsTable(
			CurrentFormula INT, 
			CurretnInjection INT, 
			CurrentOperationCounter INT, 
			Eof INT, 
			TunnelTimeStamp DATETIME2, 
			OnHold BIT, 
			CompartmentId INT, 
			CompartmentLoadId INT, 
			CompartmentFormulaId INT, 
			ReceivedTime DATETIME2, 
			AutoWeightEntryActive VARCHAR(10), 
			AutoWeightEntryWeight INT, 
			IsFormulaModified BIT, 
			IsHoldSignalModified BIT, 
			IsStopSinalModified BIT, 
			StopSignal INT, 
			RatioDosingEnabled INT, 
			ETechLastDropped VARCHAR(100), 
			CustomerCodes VARCHAR(100));
	INSERT INTO #XmlTagsTable(
			CurrentFormula, 
			CurretnInjection, 
			CurrentOperationCounter, 
			Eof, 
			TunnelTimeStamp, 
			OnHold, 
			CompartmentId, 
			CompartmentLoadId, 
			CompartmentFormulaId, 
			ReceivedTime, 
			AutoWeightEntryActive, 
			AutoWeightEntryWeight, 
			IsFormulaModified, 
			IsHoldSignalModified, 
			IsStopSinalModified, 
			StopSignal, 
			RatioDosingEnabled, 
			ETechLastDropped, 
			CustomerCodes)			
		
	-- Populate tempdata from xml
	SELECT
			T.c.value('../@CurrentFormula', 'INT')AS CurrentFormula, 
			T.c.value('../@CurrentInjection', 'INT')AS CurretnInjection, 
			T.c.value('../@CurrentOperationCounter', 'INT')AS CurrentOperationCounter, 
			T.c.value('../@Eof', 'INT')AS EndofFormula, 
			T.c.value('../@TimeStamp', 'VARCHAR(100)')AS TunnelTimeStamp, 
			T.c.value('../@OnHold', 'VARCHAR(100)')AS OnHold, 
			T.c.value('@CompartmentId', 'INT')AS CompartmentId, 
			T.c.value('@LoadId', 'INT')AS CompartmentLoadId, 
			T.c.value('@FormulaId', 'INT')AS CompartmentFormulaId, 
			T.c.value('@TimeStamp', 'VARCHAR(100)')AS DateTimeStamp, 
			T.c.value('../@Awea', 'VARCHAR(10)')AS AutoWeightEntryActive, 
			T.c.value('../@Awew', 'INT')AS AutoWeightEntryWeight, 
			T.c.value('../@IsFormulaModified', 'BIT')AS IsFormulaModified, 
			T.c.value('../@IsHoldSignalModified', 'BIT')AS IsHoldSignalModified, 
			T.c.value('../@IsStopSinalModified', 'BIT')AS IsStopSinalModified, 
			T.c.value('../@StopSignal', 'INT')AS StopSignal, 
			T.c.value('../@RATA', 'INT')AS RatioDosingEnabled, 
			T.c.value('../@ETechLastDroppedAt', 'VARCHAR(100)')AS ETechLastDropped, 
			T.c.value('../@CustomerCodes', 'VARCHAR(100)')AS CustomerCodes
		FROM @Xmltags.nodes('/Tunnel/Compartment')AS T(c)
		WHERE T.c.value('@LoadId', 'VARCHAR(100)') != 0
		  AND T.c.value('@CompartmentId', 'INT') <= @Numberofcompartments;
	--ETech last dropped 
	SELECT
			@Etechlastdroppedat = CONVERT(DATETIME, ETechLastDropped), 
			@Customercodes = CustomerCodes
		FROM #XmlTagsTable;

	IF EXISTS(SELECT
					  1 FROM #XmlTagsTable WHERE IsHoldSignalModified = 1)
		BEGIN
			SELECT
					@Currentholdsignal = Id FROM TCD.ConduitParameters WHERE Name = 'HoldSignal';
			INSERT INTO TCD.WasherReading(
					WasherId, 
					ParameterId, 
					ParameterValue, 
					DateTimeStamp, 
					EcolabWasherId)
			SELECT
					@Washerid, 
					@Currentholdsignal, 
					OnHold, 
					ReceivedTime, 
					@Ecolabwasherid
				FROM #XmlTagsTable;
		END;
	IF EXISTS(SELECT
					  1 FROM #XmlTagsTable WHERE IsStopSinalModified = 1)
		BEGIN
			INSERT INTO TCD.WasherReading(
					WasherId, 
					ParameterId, 
					ParameterValue, 
					DateTimeStamp, 
					EcolabWasherId)
			SELECT
					@Washerid, 
					12, 
					StopSignal, 
					ReceivedTime, 
					@Ecolabwasherid FROM #XmlTagsTable;
		END;
	IF EXISTS(SELECT
					  1 FROM #XmlTagsTable WHERE IsFormulaModified = 1)
		BEGIN
		
			-- Start find missing load id form xml  and set end date for corresponding enddates in the database
			DECLARE @Tempexisitingloadids TABLE(
					ExstingLoadId INT, 
					ExistsBatchId INT);
			INSERT INTO @Tempexisitingloadids(
					ExstingLoadId, 
					ExistsBatchId)
			SELECT
					Bd.ControllerBatchId, 
					Bd.BatchId
				FROM TCD.BatchData AS Bd					
				--INNER JOIN TCD.BatchWashStepData Bwsd on Bwsd.BatchId=Bd.BatchId
				WHERE Bd.MachineId = @Washerid
				  AND Bd.EndDate IS NULL
				ORDER BY
					Bd.StartDate DESC;

			SELECT
					@Temptunneltimestamp = (SELECT
													T.c.value('./@TimeStamp', 'VARCHAR(100)')AS TunnelTimeStamp
												FROM @Xmltags.nodes('/Tunnel')AS T(c));

			DECLARE @Tempbatchstepis TABLE(
					StepBatchId INT);
			INSERT INTO @Tempbatchstepis(
					StepBatchId)
			SELECT
					ExistsBatchId
				FROM @Tempexisitingloadids
				WHERE ExstingLoadId NOT IN(SELECT
												   CompartmentLoadId FROM #XmlTagsTable);

			SELECT
					@Prevstepcompartment = StepCompartment, 
					@Prevbatchid = BatchID
				FROM TCD.BatchWashStepData
				WHERE BatchId IN(SELECT
										 StepBatchId FROM @Tempbatchstepis)
				  AND EndTime IS NULL;

			UPDATE TCD.BatchWashStepData SET
					EndTime = @Temptunneltimestamp
				WHERE
					BatchId IN(SELECT
									   StepBatchId FROM @Tempbatchstepis)
				AND EndTime IS NULL;

			DECLARE @Batchshiftid INT;
			DECLARE @Shiftstartdatetemp TABLE(
					ShiftId INT, 
					ShiftName NVARCHAR(50), 
					ShiftStartdate DATETIME);
			INSERT INTO @Shiftstartdatetemp(
					ShiftId, 
					ShiftName, 
					ShiftStartdate)
			EXEC TCD.GetShiftStartDate @Temptunneltimestamp;
			SELECT
					@Batchshiftid = ssdt.ShiftId
				FROM @Shiftstartdatetemp AS ssdt
				ORDER BY
					ssdt.ShiftStartdate;

			-- Updating Batches moved out of the tunnel
			UPDATE TCD.BatchData SET
					EndDate = @Temptunneltimestamp, 
					EndDateFormula = @Temptunneltimestamp, 
					ShiftId = @Batchshiftid
				WHERE
					BatchId IN(SELECT
									   StepBatchId FROM @Tempbatchstepis);

			--End find missing load id form xml  and set end date for corresponding enddates in the database
		 
			--Start HoldTime Calculation
			SELECT
					@Batchgroupid = GroupId, 
					@Batchformula = ProgramNumber, 
					@Batchstartdate = StartDate, 
					@Batchenddate = EndDate
				FROM TCD.BatchData
				WHERE BatchId IN(SELECT
										 StepBatchId FROM @Tempbatchstepis);

			SELECT
					@Totalruntime = TotalRunTime
				FROM TCD.TunnelProgramSetup
				WHERE WasherGroupId = @Batchgroupid
				  AND ProgramNumber = @Batchformula;


			INSERT TCD.BatchParameters(
					BatchId, 
					EcolabWasherId, 
					ParameterId, 
					ParameterValue, 
					PartitionOn)
			SELECT
					StepBatchId, 
					@Ecolabwasherid, 
					17, 
					DATEDIFF(SECOND, @Batchstartdate, @Batchenddate) - @TotalRunTime, 
					bd.partitionon
				FROM @Tempbatchstepis, TCD.BatchData AS bd
				WHERE bd.BatchId = [@TempBatchStepIs].StepBatchId
				  AND [@TempBatchStepIs].StepBatchId NOT IN(SELECT
																	BATCHID FROM TCD.BatchParameters AS BP WHERE BP.ParameterId = 17);
 
			--End HoldTime Calculation

			--Start Good or Bad Injection in BatchDataTable
			IF EXISTS(SELECT TOP 1
							  *
						  FROM TCD.BatchData
						  WHERE BatchId = @Prevbatchid
							AND MachineId = @Washerid
							AND EndDate IS NOT NULL
						  ORDER BY
							  StartDate DESC)
				BEGIN

					WITH CteTempBatchTunnelStepData(
							InjectionsCount, 
							BatchId, 
							ProgramNumber)
						AS(SELECT DISTINCT
								   Bws.StepCompartment, 
								   BD.BatchId, 
								   Bd.ProgramNumber
							   FROM TCD.BatchData AS Bd
									INNER JOIN TCD.BatchWashStepData AS Bws ON Bws.BatchId = Bd.BatchId
							   WHERE Bd.BatchId = @Prevbatchid)
						SELECT
								@Ctetemtunnelwashsetps = COUNT(CTE1.InjectionsCount)
							FROM CteTempBatchTunnelStepData AS CTE1
								 INNER JOIN TCD.BatchData AS Bd ON Bd.BatchId = CTE1.BatchId
							WHERE Bd.BatchId = @Batchid;

					WITH CteTempBatchInjections(
							InjectionsCount, 
							ProgramNumber)
						AS(SELECT DISTINCT
								   Tds.CompartmentNumber, 
								   Tps.ProgramNumber
							   FROM TCD.TunnelProgramSetup AS Tps
									INNER JOIN TCD.TunnelDosingSetup AS Tds ON Tds.TunnelProgramSetupId = Tps.TunnelProgramSetupId
									INNER JOIN TCD.TunnelDosingProductMapping AS Tdpm ON Tdpm.TunnelDosingSetupId = Tds.TunnelDosingSetupId
									INNER JOIN TCD.ControllerEquipmentSetup AS Ces ON Ces.ControllerEquipmentSetupId = Tdpm.ControllerEquipmentSetupId
							   WHERE Tps.ProgramNumber = @Prevformula)
						SELECT
								@Ctetempbatchtunnelwashsteps = COUNT(CTE2.InjectionsCount)
							FROM CteTempBatchInjections AS CTE2;

					INSERT Tcd.BatchParameters(
							BatchId, 
							EcolabWasherId, 
							ParameterId, 
							ParameterValue, 
							PartitionOn)
					SELECT
							@Prevbatchid, 
							@Ecolabwasherid, 
							18, 
							CASE
								WHEN @Ctetempbatchtunnelwashsteps = @Ctetemtunnelwashsetps THEN 1
								WHEN @Ctetempbatchtunnelwashsteps != @Ctetemtunnelwashsetps THEN 3
							END, 
							(SELECT
									 PartitionOn
								 FROM TCD.BatchData
								 WHERE BatchId = @Prevbatchid
								   AND MachineId = @Washerid);



				END;

			-- End Good or Bad Injection in BatchDataTable


			-- Fetching data from cursor
			DECLARE @Mycursor CURSOR;
			SET @Mycursor = CURSOR FAST_FORWARD
				FOR SELECT
							CurrentFormula, 
							CurretnInjection, 
							CurrentOperationCounter, 
							Eof, 
							TunnelTimeStamp, 
							OnHold, 
							CompartmentId, 
							CompartmentLoadId, 
							CompartmentFormulaId, 
							ReceivedTime, 
							AutoWeightEntryActive, 
							AutoWeightEntryWeight, 
							IsFormulaModified, 
							IsHoldSignalModified, 
							IsStopSinalModified, 
							StopSignal, 
							RatioDosingEnabled
						FROM #XmlTagsTable
						ORDER BY
							CompartmentId ASC;
			DECLARE @Curcurrentformula INT, 
					@Curcurretninjection INT, 
					@Curcurrentoperationcounter INT, 
					@Cureof INT, 
					@Curtunneltimestamp DATETIME2, 
					@Curonhold BIT, 
					@Curcompartmentid INT, 
					@Curcompartmentloadid INT, 
					@Curcompartmentformulaid INT, 
					@Curreceivedtime DATETIME2, 
					@Autoweightentryactive VARCHAR(10), 
					@Autoweightentryweight INT, 
					@Isformulamodified BIT, 
					@Isholdsignalmodified BIT, 
					@Isstopsinalmodified BIT, 
					@Stopsignal INT, 
					@Ratiodosingenabled INT;

			OPEN @Mycursor;
			FETCH NEXT FROM @Mycursor INTO @Curcurrentformula, @Curcurretninjection, @Curcurrentoperationcounter, @Cureof, @Curtunneltimestamp,@Curonhold, @Curcompartmentid, @Curcompartmentloadid, @Curcompartmentformulaid, @Curreceivedtime, @Autoweightentryactive, @Autoweightentryweight,@Isformulamodified, @Isholdsignalmodified, @Isstopsinalmodified, @Stopsignal, @Ratiodosingenabled;
			WHILE @@Fetch_Status = 0
				BEGIN


					IF @Isformulamodified != 0
						BEGIN
							IF @Curcurrentformula != @Cureof
						   AND @Curcurretninjection = 0
						   AND @Curcurrentoperationcounter = 0
								BEGIN

									SELECT DISTINCT
											@Machineinternalid = Mst.MachineInternalId, 
											@Groupid = Mst.GroupId, 
											@Controllerid = Ctrl.ControllerId
										FROM TCD.Washer AS Ws
											 INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = Ws.WasherId
											 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
											 INNER JOIN TCD.WasherGroupType AS WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
											 INNER JOIN TCD.ConduitController AS Ctrl ON Ctrl.ControllerId = Mst.ControllerId
										WHERE Ws.WasherId = @Washerid;

									SELECT DISTINCT
											@Programmasterid = Wps.ProgramId, 
											@Nominalload = Wps.NominalLoad, 
											@Maxload = Ws.MaxLoad, 
											@Currencycode = Pl.CurrencyCode, 
											@Targetturntime = 3600 / Wps.TotalRunTime / Mst.NumberofComp
										FROM TCD.Washer AS Ws
											 INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = Ws.WasherId
											 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
											 INNER JOIN TCD.WasherGroupType AS WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
											 INNER JOIN TCD.TunnelProgramSetup AS Wps ON Wps.WasherGroupId = Wg.WasherGroupId
											 INNER JOIN TCD.Plant AS Pl ON Pl.EcolabAccountNumber = Ws.EcoLabAccountNumber
										WHERE Ws.WasherId = @Washerid
										  AND Wps.ProgramNumber = @Curcurrentformula
										  AND Wps.Is_Deleted = 0;

									SELECT
											@Plantwashernumber = plantwashernumber FROM tcd.washer WHERE washerid = @Washerid;

									SELECT
											@Maxwashertgroupcapacity = MAX(ws.MaxLoad)
										FROM TCD.Washer AS WS
											 INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = ws.WasherId
											 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
										WHERE Mst.GroupId = @Groupid;

									SELECT
											@Standardweight = @Nominalload;
									SELECT
											@Autoweightentryweight = CASE @Autoweightentryactive
																		 WHEN 'False' THEN @Standardweight
																		 ELSE @Autoweightentryweight
																	 END;


									SELECT
											@Machineinternalid, 
											@Groupid, 
											@Programmasterid, 
											@Nominalload, 
											@Washerid, 
											@Curcurrentformula, 
											@Prevbatchid;
									SELECT
											@Curcurrentformula AS CurCurrentFormula, 
											@Curcurretninjection AS CurCurretnInjection, 
											@Curcurrentoperationcounter AS CurCurrentOperationCounter, 
											@Cureof AS CurEof, 
											@Curtunneltimestamp AS CurTunnelTimeStamp, 
											@Curonhold AS CurOnHold, 
											@Curcompartmentid AS CurCompartmentId, 
											@Curcompartmentloadid AS CurCompartmentLoadId, 
											@Curcompartmentformulaid AS CurCompartmentFormulaId, 
											@Curreceivedtime AS CurReceivedTime, 
											@Autoweightentryactive AS AutoWeightEntryActive, 
											@Autoweightentryweight AS AutoWeightEntryWeight, 
											@Isformulamodified AS IsFormulaModified;

									IF @Curcompartmentformulaid > 0
										BEGIN
											UPDATE TCD.ConduitController SET
													LastConnectedTime = GETUTCDATE()
												WHERE
													ControllerId = @Controllerid;
										END;


									IF NOT EXISTS(SELECT TOP 1
														  *
													  FROM TCD.BatchData
													  WHERE MachineId = @Washerid
														AND StartDate = @Curtunneltimestamp)
										BEGIN

											DECLARE @Shiftstartdate TABLE(
													ShiftId INT, 
													ShiftName NVARCHAR(50), 
													ShiftStartdate DATETIME);
											INSERT INTO @Shiftstartdate(
													ShiftId, 
													ShiftName, 
													ShiftStartdate)
											EXEC TCD.GetShiftStartDate @Curtunneltimestamp;


											--Start Rollup for previous completed shift
											IF CAST(@Curtunneltimestamp AS DATE) < CAST(GETUTCDATE()AS DATE)
												BEGIN
													SELECT TOP 1
															@Previousshiftid = ShiftId
														FROM TCD.BatchData
														WHERE MachineId = @Washerid
														ORDER BY
															StartDate DESC;
													SELECT TOP 1
															@Currentshiftid = ShiftId FROM @Shiftstartdate;
													IF @Currentshiftid != @Previousshiftid
														BEGIN EXEC TCD.ProductionShiftDataRollup @Previousshiftid, @Redflagshiftid OUTPUT;
															IF @Redflagshiftid IS NULL
																BEGIN
																	SET @Redflagshiftid = @Previousshiftid;
																END;
														END;
												END;
											--End Rollup for previous completed shift

											--Start Getting InjectionCount,StepCount And ProductCount
											SELECT
													@Stdinjectionsteps = COUNT(tdpm.TunnelDosingSetupId), 
													@Stdwashsteps = COUNT(DISTINCT tds.TunnelDosingSetupId) - COUNT(tdpm.TunnelDosingSetupId)
												FROM TCD.TunnelDosingProductMapping AS tdpm
													 RIGHT JOIN tcd.TunnelDosingSetup AS tds ON tdpm.TunnelDosingSetupId = tds.TunnelDosingSetupId
												WHERE tds.GroupId = @Groupid
												  AND tds.ProgramNumber = @Curcurrentformula;
											--Start-----ProgramMasterID logic for PlantChainProgram
											SELECT
													@Plantprogramid = pm.PlantProgramId, 
													@Ecolabtextilecategoryid = pm.EcolabTextileCategoryId, 
													@Chaintextilecategoryid = pm.ChainTextileId, 
													@Formulasegmentid = pm.FormulaSegmentId, 
													@Ecolabsaturationid = pm.EcolabSaturationId
												FROM TCD.ProgramMaster AS pm
												WHERE pm.ProgramId = @Programmasterid
												  AND pm.Is_Deleted = 0;
											IF @Plantprogramid <> 0
										   AND @Plantprogramid IS NOT NULL
												BEGIN
													--Assign value from plantchainprogram table based on plantprogramId
													SELECT
															@Ecolabtextilecategoryid = pcp.EcolabTextileCategoryId, 
															@Chaintextilecategoryid = pcp.ChainTextileCategoryId, 
															@Formulasegmentid = pcp.FormulaSegmentId, 
															@Ecolabsaturationid = pcp.EcolabSaturationId
														FROM tcd.PlantChainProgram AS pcp
														WHERE pcp.PlantProgramId = @Plantprogramid
														  AND pcp.Is_Deleted = 0;
												END;
											--End-----ProgramMasterID logic for PlantChainProgram
											-- New Batch Creation
											INSERT INTO TCD.BatchData(
													ControllerBatchId, 
													EcolabWasherId, 
													GroupId, 
													MachineInternalId, 
													PlantWasherNumber, 
													StartDate, 
													EndDate, 
													ProgramNumber, 
													ProgramMasterId, 
													MachineId, 
													ActualWeight, 
													StandardWeight, 
													CurrencyCode, 
													ShiftId, 
													PartitionOn, 
													TargetTurnTime, 
													StdInjectionSteps, 
													StdWashSteps, 
													EcolabTextileCategoryId, 
													ChainTextileCategoryId, 
													FormulaSegmentId, 
													EcolabSaturationId, 
													PlantProgramId, 
													ETechlastDroppedTimeStamp)
											SELECT DISTINCT
													@Curcompartmentloadid, 
													@Ecolabwasherid, 
													@Groupid, 
													@Machineinternalid, 
													@Plantwashernumber
													--,@CurReceivedTime
													, 
													@Curtunneltimestamp, 
													NULL, 
													@Curcurrentformula, 
													@Programmasterid, 
													@Washerid, 
													@Autoweightentryweight, 
													@Standardweight, 
													@Currencycode, 
													(SELECT TOP 1
															 ShiftId FROM @Shiftstartdate), 
													(SELECT TOP 1
															 ShiftStartdate FROM @Shiftstartdate), 
													@Targetturntime, 
													@Stdinjectionsteps, 
													@Stdwashsteps, 
													@Ecolabtextilecategoryid, 
													@Chaintextilecategoryid, 
													@Formulasegmentid, 
													@Ecolabsaturationid, 
													@Plantprogramid, 
													@Etechlastdroppedat;


											SET @Batchid = SCOPE_IDENTITY();	

											--Start insert InjectionActualCount and StepActualCount in TCD.BatchParameters
											INSERT INTO TCD.BatchParameters(
													BatchId, 
													EcolabWasherId, 
													ParameterId, 
													ParameterValue, 
													PartitionOn)
											SELECT
													@Batchid, 
													@Ecolabwasherid, 
													37, 
													@Stdinjectionsteps, 
													(SELECT TOP 1
															 ShiftStartdate FROM @Shiftstartdate);
											INSERT INTO TCD.BatchParameters(
													BatchId, 
													EcolabWasherId, 
													ParameterId, 
													ParameterValue, 
													PartitionOn)
											SELECT
													@Batchid, 
													@Ecolabwasherid, 
													38, 
													@Stdwashsteps, 
													(SELECT TOP 1
															 ShiftStartdate FROM @Shiftstartdate);  
											--End insert InjectionActualCount and StepActualCount in TCD.BatchParameters

											--Start Customer Codes coming from ETech in TCD.BatchParameters
											INSERT INTO TCD.BatchParameters(
													BatchId, 
													EcolabWasherId, 
													ParameterId, 
													ParameterValue, 
													PartitionOn)
											SELECT
													@Batchid, 
													@Ecolabwasherid, 
													39, 
													@Customercodes, 
													(SELECT TOP 1
															 ShiftStartdate FROM @Shiftstartdate);
											--End Customer Codes coming from ETech in TCD.BatchParameters

											--If the received formula is not configured in enVision then create an alarm 
											IF @Programmasterid IS NULL
												BEGIN
													SELECT
															@Ecolabaccountnumber = EcolabAccountNumber FROM TCD.Plant;
													SELECT
															@Alarmgroupmasterid = AGM.AlarmGroupMasterId
														FROM TCD.AlarmGroupMsterVsControllerModelType AS AGMVCMT
															 INNER JOIN TCD.AlarmGroupMaster AS AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
														WHERE AGMVCMT.AlarmCode = 9000;
													INSERT INTO TCD.AlarmData(
															EcoalabAccountNumber, 
															AlarmCode, 
															BatchId, 
															controllerID, 
															StartDate, 
															GroupId, 
															MachineInternalId, 
															ProgramId, 
															IsActive, 
															EndDate, 
															MachineId, 
															AlarmGroupMasterId, 
															PartitionOn)
													SELECT
															@Ecolabaccountnumber, 
															9000, 
															@Batchid, 
															@Controllerid, 
															@Curtunneltimestamp, 
															@Groupid, 
															@Machineinternalid, 
															@Curcurrentformula, 
															0, 
															@Curtunneltimestamp, 
															@Washerid, 
															@Alarmgroupmasterid, 
															@Curtunneltimestamp;
												END;


											-- Wash Step Information		
											INSERT INTO TCD.BatchWashStepData(
													BatchId, 
													StepCompartment, 
													StartTime, 
													EndTime, 
													PartitionOn, 
													EcolabWasherId)
											SELECT
													@Batchid, 
													@Curcompartmentid, 
													@Curtunneltimestamp,
													--@CurReceivedTime,
													NULL, 
													(SELECT TOP 1
															 ShiftStartdate FROM @Shiftstartdate), 
													@Ecolabwasherid;
											-- Product Usage
											IF @Ratiodosingenabled = 1
												BEGIN
													INSERT INTO TCD.BatchProductData(
															BatchId, 
															StepCompartment, 
															ActualQuantity, 
															StandardQuantity, 
															Price, 
															TimeStamp, 
															PartitionOn, 
															EcolabWasherId, 
															ProductId)
													SELECT DISTINCT
															@Batchid, 
															@Curcompartmentid, 
															Wps.NominalLoad * Wdpm.Quantity / 100 * @Autoweightentryweight / @Standardweight AS ActualQuantity, 
															Wps.NominalLoad * Wdpm.Quantity / 100 * @Autoweightentryweight / @Standardweight AS StandardQuantity, 
															Wps.NominalLoad * Wdpm.Quantity / 100 * tcd.FnChemicalCostInOunce(Pdm.ProductID)AS Price, 
															@Curtunneltimestamp								
															--,@CurReceivedTime
															, 
															(SELECT TOP 1
																	 ShiftStartdate FROM @Shiftstartdate), 
															@Ecolabwasherid, 
															Pdm.ProductID
														FROM TCD.Washer AS WS
															 INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = ws.WasherId
															 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
															 INNER JOIN TCD.WasherGroupType AS WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
															 INNER JOIN TCD.TunnelProgramSetup AS Wps ON Wps.WasherGroupId = Wg.WasherGroupId
															 INNER JOIN TCD.TunnelDosingSetup AS Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
															 INNER JOIN TCD.TunnelDosingProductMapping AS Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
															 INNER JOIN TCD.ControllerEquipmentSetup AS Ces ON Ces.ControllerEquipmentSetupId = Wdpm.ControllerEquipmentSetupId
															 INNER JOIN TCD.ProductdataMapping AS Pdm ON Pdm.ProductId = Ces.ProductId
														--INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
														WHERE Ws.WasherId = @Washerid
														  AND Wps.ProgramNumber = @Curcurrentformula
														  AND Wds.CompartmentNumber = @Curcompartmentid
														  AND Wps.Is_Deleted = 0
														  AND Pdm.Is_Deleted = 0;
												END;
											ELSE
												BEGIN
													INSERT INTO TCD.BatchProductData(
															BatchId, 
															StepCompartment, 
															ActualQuantity, 
															StandardQuantity, 
															Price, 
															TimeStamp, 
															PartitionOn, 
															EcolabWasherId, 
															ProductId)
													SELECT DISTINCT
															@Batchid, 
															@Curcompartmentid, 
															Wps.NominalLoad * Wdpm.Quantity / 100 AS ActualQuantity, 
															Wps.NominalLoad * Wdpm.Quantity / 100 AS StandardQuantity, 
															Wps.NominalLoad * Wdpm.Quantity / 100 * tcd.FnChemicalCostInOunce(Pdm.ProductID)AS Price, 
															@Curtunneltimestamp									
															--,@CurReceivedTime
															, 
															(SELECT TOP 1
																	 ShiftStartdate FROM @Shiftstartdate), 
															@Ecolabwasherid, 
															Pdm.ProductID
														FROM TCD.Washer AS WS
															 INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = ws.WasherId
															 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
															 INNER JOIN TCD.WasherGroupType AS WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
															 INNER JOIN TCD.TunnelProgramSetup AS Wps ON Wps.WasherGroupId = Wg.WasherGroupId
															 INNER JOIN TCD.TunnelDosingSetup AS Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
															 INNER JOIN TCD.TunnelDosingProductMapping AS Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
															 INNER JOIN TCD.ControllerEquipmentSetup AS Ces ON Ces.ControllerEquipmentSetupId = Wdpm.ControllerEquipmentSetupId
															 INNER JOIN TCD.ProductdataMapping AS Pdm ON Pdm.ProductId = Ces.ProductId
														--INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
														WHERE Ws.WasherId = @Washerid
														  AND Wps.ProgramNumber = @Curcurrentformula
														  AND Wds.CompartmentNumber = @Curcompartmentid
														  AND Wps.Is_Deleted = 0
														  AND Pdm.Is_Deleted = 0;
												END;			
								
								
											-- Transfer Signal		
											INSERT INTO TCD.WasherReading(
													WasherId, 
													ParameterId, 
													ParameterValue, 
													DateTimeStamp, 
													PartitionOn, 
													EcolabWasherId)
											SELECT
													@Washerid, 
													6, 
													1, 
													@Temptunneltimestamp, 
													(SELECT TOP 1
															 ShiftStartdate FROM @Shiftstartdate), 
													@Ecolabwasherid
											UNION ALL
											SELECT
													@Washerid, 
													6, 
													0, 
													GETUTCDATE(), 
													(SELECT TOP 1
															 ShiftStartdate FROM @Shiftstartdate), 
													@Ecolabwasherid;
			
											-- Insert Customer Data
											INSERT INTO TCD.BatchCustomerData(
													BatchId, 
													CustomerId, 
													Weight, 
													PiecesCount, 
													PartitionOn, 
													EcolabWasherId)
											SELECT DISTINCT
													Bd.BatchId, 
													Pc.ID, 
													@Autoweightentryweight, 
													ROUND(COALESCE(@Autoweightentryweight * Pm.Pieces / NULLIF(Pm.Weight, 0), 0), 0), 
													(SELECT TOP 1
															 ShiftStartdate FROM @Shiftstartdate), 
													@Ecolabwasherid
												FROM TCD.Washer AS WS
													 INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = ws.WasherId
													 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
													 INNER JOIN TCD.TunnelProgramSetup AS Tps ON Tps.WasherGroupId = Wg.WasherGroupId
													 INNER JOIN TCD.ProgramMaster AS Pm ON Pm.ProgramId = Tps.ProgramId
													 INNER JOIN TCD.PlantCustomer AS Pc ON Pc.ID = Pm.CustomerId
													 INNER JOIN TCD.BatchData AS Bd ON Bd.MachineId = Ws.WasherId
												WHERE Ws.WasherId = @Washerid
												  AND Tps.ProgramNumber = @Curcompartmentformulaid
												  AND Bd.BatchId = @Batchid
												  AND Pm.CustomerId != -1
												  AND Pm.Weight > 0;
										END;
									ELSE
										BEGIN
											SELECT
													@Batchid = BatchId, 
													@Partitionon = PartitionOn
												FROM TCD.BatchData
												WHERE MachineId = @Washerid
												  AND ControllerBatchId = @Curcompartmentloadid;

											IF @Batchid IS NOT NULL
												BEGIN
													UPDATE TCD.BatchWashStepData SET
															EndTime = @Curtunneltimestamp
														WHERE
															BatchId = @Batchid
														AND StepCompartment = @Curcompartmentid - 1;

													IF NOT EXISTS(SELECT TOP 1
																		  *
																	  FROM TCD.BatchWashStepData
																	  WHERE StartTime = @Curtunneltimestamp
																		AND BatchId = @Batchid)
														BEGIN
															INSERT INTO TCD.BatchWashStepData(
																	BatchId, 
																	StepCompartment, 
																	StartTime, 
																	EndTime, 
																	PartitionOn, 
																	EcolabWasherId)
															SELECT
																	@Batchid, 
																	@Curcompartmentid, 
																	@Curtunneltimestamp,
																	--@CurReceivedTime,
																	NULL, 
																	@Partitionon, 
																	@Ecolabwasherid;
														END;
													IF @Ratiodosingenabled = 1
														BEGIN
															IF NOT EXISTS(SELECT TOP 1
																				  *
																			  FROM TCD.BatchProductData
																			  WHERE TimeStamp = @Curtunneltimestamp
																				AND BatchId = @Batchid)
																BEGIN
																	INSERT INTO TCD.BatchProductData(
																			BatchId, 
																			StepCompartment, 
																			ActualQuantity, 
																			StandardQuantity, 
																			Price, 
																			TimeStamp, 
																			PartitionOn, 
																			EcolabWasherId, 
																			ProductId)
																	SELECT DISTINCT
																			@Batchid, 
																			@Curcompartmentid, 
																			Wps.NominalLoad * Wdpm.Quantity / 100 * @Autoweightentryweight /@Standardweight AS ActualQuantity, 
																			Wps.NominalLoad * Wdpm.Quantity / 100 * @Autoweightentryweight /@Standardweight AS StandardQuantity, 
																			Wps.NominalLoad * Wdpm.Quantity / 100 * tcd.FnChemicalCostInOunce(Pdm.ProductID)AS Price, 
																			@Curtunneltimestamp									
																			--,@CurReceivedTime
																			, 
																			@Partitionon, 
																			@Ecolabwasherid, 
																			Pdm.ProductID
																		FROM TCD.Washer AS WS
																			 INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = ws.WasherId
																			 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
																			 INNER JOIN TCD.WasherGroupType AS WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
																			 INNER JOIN TCD.TunnelProgramSetup AS Wps ON Wps.WasherGroupId = Wg.WasherGroupId
																			 INNER JOIN TCD.TunnelDosingSetup AS Wds ON Wds.TunnelProgramSetupId =Wps.TunnelProgramSetupId
																			 INNER JOIN TCD.TunnelDosingProductMapping AS Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
																			 INNER JOIN TCD.ControllerEquipmentSetup AS Ces ON Ces.ControllerEquipmentSetupId = Wdpm.ControllerEquipmentSetupId
																			 INNER JOIN TCD.ProductdataMapping AS Pdm ON Pdm.ProductId = Ces.ProductId
																		--INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
																		WHERE Ws.WasherId = @Washerid
																		  AND Wps.ProgramNumber = @Curcompartmentformulaid
																		  AND Wds.CompartmentNumber = @Curcompartmentid
																		  AND Wps.Is_Deleted = 0
																		  AND Pdm.Is_Deleted = 0;
																END;
														END -- end of ratio dosing if
													;
													ELSE
														BEGIN
															IF NOT EXISTS(SELECT TOP 1
																				  *
																			  FROM TCD.BatchProductData
																			  WHERE TimeStamp = @Curtunneltimestamp
																				AND BatchId = @Batchid)
																BEGIN
																	INSERT INTO TCD.BatchProductData(
																			BatchId, 
																			StepCompartment, 
																			ActualQuantity, 
																			StandardQuantity, 
																			Price, 
																			TimeStamp, 
																			PartitionOn, 
																			EcolabWasherId, 
																			ProductId)
																	SELECT DISTINCT
																			@Batchid, 
																			@Curcompartmentid, 
																			Wps.NominalLoad * Wdpm.Quantity / 100 AS ActualQuantity, 
																			Wps.NominalLoad * Wdpm.Quantity / 100 AS StandardQuantity, 
																			Wps.NominalLoad * Wdpm.Quantity / 100 * tcd.FnChemicalCostInOunce(Pdm.ProductID)AS Price, 
																			@Curtunneltimestamp									
																			--,@CurReceivedTime
																			, 
																			@Partitionon, 
																			@Ecolabwasherid, 
																			Pdm.ProductID
																		FROM TCD.Washer AS WS
																			 INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = ws.WasherId
																			 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
																			 INNER JOIN TCD.WasherGroupType AS WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
																			 INNER JOIN TCD.TunnelProgramSetup AS Wps ON Wps.WasherGroupId = Wg.WasherGroupId
																			 INNER JOIN TCD.TunnelDosingSetup AS Wds ON Wds.TunnelProgramSetupId =Wps.TunnelProgramSetupId
																			 INNER JOIN TCD.TunnelDosingProductMapping AS Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
																			 INNER JOIN TCD.ControllerEquipmentSetup AS Ces ON Ces.ControllerEquipmentSetupId = Wdpm.ControllerEquipmentSetupId
																			 INNER JOIN TCD.ProductdataMapping AS Pdm ON Pdm.ProductId = Ces.ProductId
																		WHERE Ws.WasherId = @Washerid
																		  AND Wps.ProgramNumber = @Curcompartmentformulaid
																		  AND Wds.CompartmentNumber = @Curcompartmentid
																		  AND Wps.Is_Deleted = 0
																		  AND Pdm.Is_Deleted = 0;
																END;
														END;
												END; -- end of BatchId NULL if
										END; -- end of else
								END;		-- end of IF(@CurCurrentFormula != @CurEof and @CurCurretnInjection = 0 and @CurCurrentOperationCounter = 0)							
						END;		-- end of IF(@IsFormulaModified !=0)	

					FETCH NEXT FROM @Mycursor INTO @Curcurrentformula, @Curcurretninjection, @Curcurrentoperationcounter, @Cureof,@Curtunneltimestamp, @Curonhold, @Curcompartmentid, @Curcompartmentloadid, @Curcompartmentformulaid, @Curreceivedtime, @Autoweightentryactive,@Autoweightentryweight, @Isformulamodified, @Isholdsignalmodified, @Isstopsinalmodified, @Stopsignal, @Ratiodosingenabled;
				END;
			CLOSE @Mycursor;
			DEALLOCATE @Mycursor;


		END;
END;
GO


--------------------------Etech customercodes end------------------------------------------------------------------------------------------
----------------------------------------------------------------Start PLC Step Save Data for PLCXL--------------------------------------------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMitsubishiStepSaveData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMitsubishiStepSaveData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ProcessMitsubishiStepSaveData]
(
	@ControllerID   INT,
	@VxML           XML,
	@RedFlagShiftId INT OUTPUT
)
AS
	BEGIN
	    DECLARE @MachineNumber           INT,
			  @StepNumber              INT,
			  @StartDateTime           DATETIME,
			  @EndDateTime             DATETIME,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @WaterConsumption1       INT,
			  @PHStatus                INT,
			  @PHValue                 INT,
			  @TemperatureMin          INT,
			  @TemperatureMax          INT,
			  @TempStatus			   INT,
			  @BatchNumber             INT,
			  @WasherID                INT,
			  @WasherGroupID           INT,
			  @EcoLabWasherID          INT,
			  @ProgramMasterID         INT,
			  @PlantWasherNumber       INT,
			  @ShiftID                 INT,
			  @ParameterID             INT,
			  @BatchID                 INT,
			  @ShiftStartdate          DATETIME,
			  @ShiftName               NVARCHAR(50),
			  @PreviousStep            INT,
			  @XMLDataID               INT,
			  @LastStep                INT,
			  @CurrentStep             INT,
			  @CurrentStepTime         DATETIME,
			  @MinTempParamID          INT,
			  @MaxTempParamID          INT,
			  @MinTempStatuParamID     INT,
			  @MaxTempStatusParamID    INT,
			  @PHStatusParamID         INT,
			  @PHValueParamID          INT,
			  @Runtime                 INT,
			  @ErrorMessage            NVARCHAR(MAX),
			  @StepDuration            INT,
			  @BatchStartDateTime      DATETIME,
			  @MinStepNo               INT,
			  @StepStartTime           DATETIME,
			  @MaxWashertGroupCapacity INT,
			  @WashStep                INT,
			  @CoolDownFactor          INT;
	    SELECT
			 @XMLDataID = SCOPE_IDENTITY();
	    SELECT
			 @MachineNumber = T.c.value('@MachineNumber', 'INT'),
			 @StepNumber = T.c.value('@StepNumber', 'INT'),
			 @StartDateTime = T.c.value('@StartDateTime', 'DateTime'),
			 @EndDateTime = T.c.value('@EndDateTime', 'DateTime'),
			 @WaterConsumption1 = T.c.value('@WaterConsumption1', 'INT'),
			 @PHStatus = T.c.value('@PHStatus', 'INT'),
			 @PHValue = T.c.value('@PHValue', 'INT'),
			 @TemperatureMin = T.c.value('@TemperatureMin', 'INT'),
			 @TemperatureMax = T.c.value('@TemperatureMax', 'INT'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @Runtime = T.c.value('@Runtime', 'INT'),
			 @StepDuration = T.c.value('@StepDuration', 'INT'),
			 @CoolDownFactor = T.c.value('@CoolDown', 'INT')
	    FROM @VxML.nodes('ConventionalWasherData') T(C);
	    SELECT
			 @WasherGroupID = GroupId,
			 @WasherID = WasherID
	    FROM TCD.MachineSetup ms
	    WHERE ControllerID = @ControllerID
			AND MachineInternalId = @MachineNumber
			AND IsTunnel = 0
			AND ms.IsDeleted = 0;
	    SELECT
			 @BatchID = BatchID,
			 @ShiftID = ShiftId,
			 @BatchStartDateTime = StartDate,
			 @ProgramNumber = ProgramNumber,
			 @ProgramMasterId = ProgramMasterId
	    FROM TCD.BatchData
	    WHERE MachineInternalID = @MachineNumber
			AND YEAR(StartDate) = YEAR(@StartDateTime)
			AND MONTH(StartDate) = MONTH(@StartDateTime)
			AND ABS(DAY(StartDate) - DAY(@StartDateTime)) < 2
			AND ControllerBatchId = @BatchNumber
			AND MachineID = @WasherID;
	    IF(@BatchID IS NULL)
		   BEGIN
			  SELECT
				    @ErrorMessage = 'Batch Missing for Step Save'+ ' Controller ID : ' + CONVERT( NVARCHAR(10),@ControllerID)
				     +' Washer Number  : '+ CONVERT(NVARCHAR(10), @MachineNumber)
					+' Batch Number : '+ CONVERT(NVARCHAR(10), @BatchNumber);
			  INSERT INTO TCD.Logs
			  (
				    Date,
				    Thread,
				    Level,
				   Logger,
				    Message
			  )
			  VALUES
			  (
				    GETUTCDATE(),
				    '1',
				    '1',
				    'ReadStepSave',
				    @ErrorMessage
			  );
			  RETURN;
		   END;
	    IF(@WasherId IS NOT NULL)
		   BEGIN
			  SELECT
				    @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber
			  FROM TCD.Washer Ws
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wps.Is_Deleted = 0
				   AND mst.IsDeleted = 0
				   AND Mst.ControllerId = @ControllerID;
		   END;
	    DECLARE @ShiftMapping TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    INSERT INTO @ShiftMapping
	    (
			 ShiftId,
			 ShiftName,
			 ShiftStartdate
	    )
	    EXEC TCD.GetShiftStartDate
		    @BatchStartDateTime
		   
	    SELECT
			 @ShiftID = ShiftID,
			 @ShiftStartdate = ShiftStartdate
	    FROM @ShiftMapping;
	    CREATE TABLE #Dosing
	    (
		    equipmentNo INT,
		    StepNo      INT,
		    Qty         DECIMAL(18, 4)
	    );
	    INSERT INTO #Dosing
	    SELECT
			 T.c.value('@Equipment', 'INT'),
			 T.c.value('@stepNo', 'INT'),
			 T.c.value('@Qty', 'decimal(18,4)')
	    FROM @VxML.nodes('ConventionalWasherData/DosingData/Dosing') T(C);
	    SELECT
			 @MaxWashertGroupCapacity = MAX(ws.MaxLoad)
	    FROM TCD.Washer WS
		    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
		    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
	    WHERE Mst.GroupId = @WasherGroupID;
	    INSERT INTO TCD.BatchProductData
	    (
			 BatchId,
			 StepCompartment,
			 ActualQuantity,
			 StandardQuantity,
			 Price,
			 TimeStamp,
			 PartitionOn,
			 EcolabWasherId,
			 ProductId,
			 InjectionNumber
	    )
	    SELECT
			 Bd.BatchId,
			 Wds.StepNumber,
			 dosing.Qty,
			 ((Wps.NominalLoad / CONVERT( DECIMAL(10, 2), 100)) * Wdpm.Quantity * Ws.MaxLoad) / CONVERT(DECIMAL(10, 2), 100) AS
			 StandardQuantity,
			 ((Wps.NominalLoad / CONVERT( DECIMAL(10, 2), 100)) * Wdpm.
			 Quantity * @MaxWashertGroupCapacity) / CONVERT(DECIMAL(10,
			 2), 100) * tcd.FnChemicalCostInOunce(Pdm.ProductID) AS
			 Price,
			 @BatchStartDateTime,
			 @ShiftStartdate,
			 @EcolabWasherId,
			 Pdm.ProductID,
			 dosing.StepNo
	    FROM TCD.Washer WS
		    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
		    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
		    INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
		    INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
		    INNER JOIN TCD.WasherDosingSetup Wds ON Wds. WasherProgramSetupId = Wps.WasherProgramSetupId
		    INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
		    INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId = Wdpm.ProductId
		    INNER JOIN TCD.BatchData Bd ON Bd.MachineId = Ws.WasherId
		    INNER JOIN TCD.ControllerEquipmentSetup CES ON CES.ProductId = Pdm.ProductId
												 AND CES.ControllerID = @ControllerID
		    INNER JOIN #Dosing dosing ON CES.ControllerEquipmentId = dosing.equipmentNo
								 --  AND Wdpm.InjectionNumber = dosing.StepNo
	    WHERE Ws.WasherId = @WasherId
			AND Wps.ProgramNumber = @ProgramNumber
			AND Bd.BatchId = @BatchID
			AND WS.Is_Deleted = 0
			AND Mst.IsDeleted = 0
			AND dosing.equipmentNo > 0
			AND dosing.Qty > 0;
	    SELECT
			 @WashStep = StepCompartment
	    FROM TCD.BatchProductData
	    WHERE BatchID = @BatchID
			AND InjectionNumber = @StepNumber;
	    SELECT TOP 1
			 @StepStartTime = EndTime
	    FROM TCD.BatchWashStepData
	    WHERE BatchID = @BatchID
	    ORDER BY
			   StepCompartment DESC;
	    IF(@StepStartTime IS NULL)
		   SELECT
				@StepStartTime = @BatchStartDateTime;
	    INSERT INTO TCD.BatchWashStepData
	    (
			 BatchId,
			 StepCompartment,
			 StartTime,
			 EndTime,
			 PartitionOn,
			 EcolabWasherId
	    )
	    SELECT
			 @BatchID,
			 ISNULL(@WashStep, @StepNumber),
			 @StepStartTime,
			 DATEADD(ss, @StepDuration, @StepStartTime) EndTime,
			 @ShiftStartdate,
			 @EcoLabWasherID;
	    IF(ISNULL(@Runtime, 0) = 0)
		   BEGIN
			  RETURN;
		   END;
	    DELETE FROM @ShiftMapping;
	    INSERT INTO @ShiftMapping
	    (
			 ShiftId,
			 ShiftName,
			 ShiftStartdate
	    )
	    EXEC TCD.GetShiftStartDate
		    @EndDateTime;
	    SELECT
			 @ShiftID = ShiftID,
			 @ShiftStartdate = ShiftStartdate
	    FROM @ShiftMapping;
	    UPDATE TCD.BatchData
		 SET
			EndDate = @EndDateTime,
			TCD.BatchData.EndDateFormula = @EndDateTime,
			ShiftId = @ShiftID
	    WHERE
			BatchID = @BatchID;
	    SELECT
			 @MinTempParamID = Id
	    FROM TCD.ConduitParameters
	    WHERE Name = 'Mimum Temperature';
	    SELECT
			 @MaxTempParamID = Id
	    FROM TCD.ConduitParameters
	    WHERE Name = 'Maximum Temperature';
	    SELECT
			 @MinTempStatuParamID = Id
	    FROM TCD.ConduitParameters
	    WHERE Name = 'Temperature Status';
	    SELECT
			 @PHValueParamID = ID
	    FROM TCD.ConduitParameters
	    WHERE Name = 'PH';
	    SELECT
			 @PHStatusParamID = ID
	    FROM TCD.ConduitParameters
	    WHERE Name = 'PH Status';
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MinTempParamID
	    )
		   BEGIN
			  IF(@TemperatureMin <> 0
				OR @TemperatureMin <> NULL)
				 BEGIN
			 	      INSERT INTO TCD.BatchParameters
			 	      (
			 	    	    BatchId,
			 	    	    EcolabWasherId,
			 	    	    ParameterId,
			 	    	    ParameterValue,
			 	    	    PartitionOn
			 	      )
			 	      VALUES
			 	      (
			 	    	    @BatchID,
			 	    	    @EcoLabWasherID,
			 	    	    @MinTempParamID,
			 	    	    @TemperatureMin,
			 	    	    @ShiftStartdate
			 	      );
			 	  END
		   END;
		    IF NOT EXISTS
		     (
		  	   SELECT
		  			*
		  	   FROM TCD.BatchParameters
		  	   WHERE BatchId = @BatchID
		  		    AND ParameterID = @MaxTempParamID
		     )
		   BEGIN
	    IF(ISNULL(@MaxTempParamID, 0) > 0)
		   BEGIN
			  INSERT INTO TCD.BatchParameters
			  (
				    BatchId,
				    EcolabWasherId,
				    ParameterId,
				    ParameterValue,
				    PartitionOn
			  )
			  VALUES
			  (
				    @BatchID,
				    @EcoLabWasherID,
				    @MaxTempParamID,
				    @TemperatureMax,
				    @ShiftStartdate
			  );
			  END
		   END;
		    IF NOT EXISTS
		     (
		  	   SELECT
		  			*
		  	   FROM TCD.BatchParameters
		  	   WHERE BatchId = @BatchID
		  		    AND ParameterID = @MinTempStatuParamID
		     )
		   BEGIN
	    IF(ISNULL(@TempStatus,0) > 0)
		   BEGIN
			  INSERT INTO TCD.BatchParameters
			  (
				    BatchId,
				    EcolabWasherId,
				    ParameterId,
				    ParameterValue,
				    PartitionOn
			  )
			  VALUES
			  (
				    @BatchID,
				    @EcoLabWasherID,
				    @MinTempStatuParamID,
				    @TempStatus,
				    @ShiftStartdate
			  );
			  END
		   END;
		    IF NOT EXISTS
		     (
		  	   SELECT
		  			*
		  	   FROM TCD.BatchParameters
		  	   WHERE BatchId = @BatchID
		  		    AND ParameterID = @PHStatusParamID
		     )
		   BEGIN
	    IF(ISNULL(@PHStatus,0) > 0)
		   BEGIN
			  INSERT INTO TCD.BatchParameters
			  (
				    BatchId,
				    EcolabWasherId,
				    ParameterId,
				    ParameterValue,
				    PartitionOn
			  )
			  VALUES
			  (
				    @BatchID,
				    @EcoLabWasherID,
				    @PHStatusParamID,
				    @PHStatus,
				    @ShiftStartdate
			  );
			  END
		   END;
		    IF NOT EXISTS
		     (
		  	   SELECT
		  			*
		  	   FROM TCD.BatchParameters
		  	   WHERE BatchId = @BatchID
		  		    AND ParameterID = @PHValueParamID
		     )
		   BEGIN
	    IF(ISNULL(@PHValue, 0) > 0)
		   BEGIN
			  INSERT INTO TCD.BatchParameters
			  (
				    BatchId,
				    EcolabWasherId,
				    ParameterId,
				    ParameterValue,
				    PartitionOn
			  )
			  VALUES
			  (
				    @BatchID,
				    @EcoLabWasherID,
				    @PHValueParamID,
				    @PHValue,
				    @ShiftStartdate
			  );
END
		   END;
	    IF(@WaterConsumption1 > 0)
		   BEGIN
			  INSERT INTO TCD.BatchStepWaterUsageData
			  (
				    BatchId,
				    StepCompartment,
				    ActualQuantity,
				    PartitionOn,
				    EcolabWasherId
			  )
			  SELECT
				    @BatchID,
				    @WashStep,
				    @WaterConsumption1,
				    @ShiftStartdate,
				    @EcoLabWasherID;
		   END;
	END;
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMitsubishiTunnelWasherOnlineData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMitsubishiTunnelWasherOnlineData]
END
GO
CREATE PROCEDURE [TCD].[ProcessMitsubishiTunnelWasherOnlineData]
 (
  @ControllerID INT,
  @xmlTags xML,
  @RedFlagShiftId INT OUTPUT 
 )
AS
BEGIN
   DECLARE 
	   @BatchID      INT,
	   @WasherID      INT,
	   @EcolabWasherId     INT,        
	   @CurrencyCode     VARCHAR(50),  
	   @MachineInternalId    INT,
	   @WasherGroupID     INT,

	   @PlantWasherNumber    INT,
	   @BatchStartDate     DATETIME2,
	   @BatchEndDate     DATETIME2,   
	   @ProgramNumber     INT,
	   @Load       Decimal(10,2),
	   @NominalLoad     Decimal(10,2),
	   @CustomerNumber     INT,
	   --@PHStatus      INT,
	   @PHValue      INT,
	   @PHCompartment     INT,
	   @ConductivityValue    INT,
	   @ConductivityCompartment  INT,
	   @TemperatureValue    INT,
	   @TemperatureCompartment   INT,
	   --@LFStatus      INT,
	   --@LFValue      INT,
	   @EjectionSignal     INT,
	   @TextTileCategory    INT,
	   @BatchNumber     INT,
	   @TargetTurnTime     INT,
	   @ShiftID      INT,
	   @ParameterID     INT,   
	   @ShiftName      VARCHAR(50),
	   @EcolabAccountNumber NVARCHAR(25) = NULL,
	   @PartitionOn DateTime,
	   @BatchStartTime DateTime,
	   @BatchEndTime DateTime,
	   @PorgramParameterID int,
	   @PHParameterID int,
	   @PHParameterStatus int,
	   @ConductivityParamID int,
	   @ConductivityStatusParamID int,
	   @RunTime int,
	   @TextileCategory int,
	   @ProgramID int,
	   @NumberOfCompartments int,
	   @TempParameter int,
	   @CompartmentNoId int,
	   @TransferSignalId int,
	   @TempBatchStartTime DateTime,
	   @ProductId INT,
	   @CompartmentNum INT,
	   @WasherGroupNum INT,
	   @PrevRealQty   INT,
	   @StdInjectionSteps INT,
	   @StdWashSteps INT,
	   @EcolabTextileCategoryId INT,
	   @ChainTextileCategoryId  INT,
	   @FormulaSegmentId        INT,
	   @EcolabSaturationId      INT,
	   @PlantProgramId          INT
    
 --INSERT into MyControlXML (xmlData, BatchType, PLCPointer, ReadPointer, BatchID, comment,LastModified) values (@xmlTags, 'TunnelOnline', null, null, null, '',getDate())

 --   SELECT @PorgramParameterID=ID
 --FROM TCD.ConduitParameters WHERE NAME ='Formula Number'

 --SELECT @PHParameterID=ID
 --FROM TCD.ConduitParameters WHERE NAME ='pH'

 --SELECT @PHParameterStatus=ID
 --FROM TCD.ConduitParameters WHERE NAME ='PH Status'
 
 --SELECT @ConductivityParamID=ID
 --FROM TCD.ConduitParameters WHERE NAME ='Conductivity'

 --SELECT @ConductivityStatusParamID=ID
 --FROM TCD.ConduitParameters WHERE NAME ='LF Status' 
 
 SELECT @CompartmentNoId=ID
 FROM TCD.ConduitParameters WHERE NAME ='StepCompartment No' 

 SELECT @TransferSignalId=ID
 FROM TCD.ConduitParameters WHERE NAME ='Transfer Signal'

 CREATE TABLE #Batches(BatchNumber int,StartDateTime DateTime)   
  

 DECLARE @BatchShiftId int
 DECLARE @ShiftStartDateTemp table(ShiftId INT,ShiftName NVARCHAR(50),ShiftStartdate DATETIME)

 DECLARE @compartmentID int,
   @TunnelXML xml
   
 SET @compartmentID = 20
 
 SELECT @WasherID=null;
    
 WHILE (@compartmentID >=1)
 BEGIN
   
    SELECT @TunnelXML=T.c.query('.') 
  FROM   @xmlTags.nodes('MyControlTunnel/TunnelData') T(c)
  WHERE T.c.value('@CompartmentNumber', 'INT') = @compartmentID


   SELECT   @MachineInternalID=T.c.value('@MachineNumber', 'int'),
      @BatchNumber= T.c.value('@BatchNumber', 'INT'),
      @BatchStartTime=T.c.value('@StartDateTime', 'DateTime'),
      @BatchEndTime=T.c.value('@EndDateTime', 'DateTime'),
      @ProgramNumber=T.c.value('@ProgramNumber', 'INT'),
      @WasherGroupNum=T.c.value('@GroupNumber', 'int'),
      @Load=T.c.value('@Load', 'Decimal(10,2)'),
      @NominalLoad=T.c.value('@Nominalload', 'Decimal(10,2)'),
      @CustomerNumber=T.c.value('@CustomerNumber', 'int'),
      --@PHStatus=T.c.value('@pHStatus', 'int'),
      @PHValue=T.c.value('@pHValue', 'INT'),
      @PHCompartment=T.c.value('@pHCompartment', 'INT'),
      @ConductivityValue=T.c.value('@ConductivityValue', 'INT'),
      @ConductivityCompartment=T.c.value('@ConductivityCompartment', 'INT'),
      @RunTime=T.c.value('@RunTime', 'INT'),
      @EjectionSignal=T.c.value('@EjectionSignal', 'INT'),
      @TextileCategory=T.c.value('@TextileCategory', 'INT')
   FROM @TunnelXML.nodes('TunnelData')  T(c);
   

   IF (@ProgramNumber = 0 OR @BatchNumber=1) 
   BEGIN
      SELECT @compartmentID  = @compartmentID - 1
   Continue;
   END 

   IF (@WasherID is null) 
   BEGIN
   SELECT 
     @EcolabWasherID=EcolabWasherId,
     @WasherGroupID= Wg.WasherGroupId,
     @PlantWasherNumber=PlantWasherNumber,
     @WasherID=ws.WasherId,
     @CurrencyCode=P.CurrencyCode,
     @NumberOfCompartments=Mst.NumberofComp
   FROM TCD.Washer Ws
     INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
     INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
     INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
     INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId = Mst.ControllerId
     INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.EcoLabAccountNumber
   WHERE  Ctrl.ControllerID = @ControllerID
      AND mst.MachineInternalId = @MachineInternalID
      AND mst.IsTunnel = 1

   END 
  

   SELECT @ProgramID=tps.ProgramId,
    @TargetTurnTime= (3600 / (tps.TotalRunTime /@NumberOfCompartments )) 
   FROM TCD.TunnelProgramSetup AS tps 
   WHERE tps.WasherGroupId = @WasherGroupID 
      and tps.is_deleted =0
      and tps.ProgramNumber = @ProgramNumber

   INSERT #Batches(BatchNumber,StartDateTime)
   SELECT @BatchNumber,@BatchStartTime

  SELECT @BatchID = Null

  SELECT @BatchID=BatchID, @PartitionOn=PartitionOn, @TempBatchStartTime=StartDate
  FROM TCD.BatchData BD
  WHERE BD.ControllerBatchId = @BatchNumber
     --AND BD.StartDate= @BatchStartTime
     AND BD.MachineId = @WasherID
     AND CAST(StartDate as date)=CAST(@BatchStartTime as date)
    --Start Getting InjectionCount,StepCount And ProductCount
   SELECT @StdInjectionSteps= count(tdpm.TunnelDosingSetupId) ,
   @StdWashSteps= count(DISTINCT tds.TunnelDosingSetupId)-count(tdpm.TunnelDosingSetupId) 
   FROM tcd.TunnelDosingProductMapping tdpm
   RIGHT JOIN tcd.TunnelDosingSetup tds on tdpm.TunnelDosingSetupId=tds.TunnelDosingSetupId
   WHERE tds.GroupId=@WasherGroupID AND tds.ProgramNumber= @ProgramNumber
   
   --End Getting InjectionCount,StepCount And ProductCount
   SELECT @PlantProgramId = pm.PlantProgramId,
        @EcolabTextileCategoryId = pm.
        EcolabTextileCategoryId,
        @ChainTextileCategoryId = pm.ChainTextileId,
        @FormulaSegmentId = pm.FormulaSegmentId,
        @EcolabSaturationId = pm.EcolabSaturationId
     FROM TCD.ProgramMaster AS pm
     WHERE pm.ProgramId = @ProgramID
       AND pm.Is_Deleted = 0;
     IF(@PlantProgramId <> 0
    OR @PlantProgramId IS NOT NULL)
     BEGIN
     --Assign value from plantchainprogram table based on plantprogramId
     SELECT 
			@EcolabTextileCategoryId = pcp.EcolabTextileCategoryId,
            @ChainTextileCategoryId = pcp.ChainTextileCategoryId,
            @FormulaSegmentId = pcp.FormulaSegmentId,
            @EcolabSaturationId = pcp.EcolabSaturationId
     FROM tcd.PlantChainProgram AS pcp
     WHERE pcp.PlantProgramId = @PlantProgramId
       AND pcp.Is_Deleted = 0;
     END;
  IF (@BatchID is Null) 
    BEGIN

       DELETE FROM  @ShiftStartDateTemp;

        INSERT INTO @ShiftStartDateTemp(ShiftId,ShiftName,ShiftStartdate) 
        EXEC TCD.GetShiftStartDate @BatchStartTime

        SELECT @BatchShiftId = ShiftID,
           @PartitionOn=ShiftStartdate,
           @ShiftName=ShiftName
       FROM @ShiftStartDateTemp


        INSERT INTO TCD.BatchData(
           ControllerBatchId ,
           EcolabWasherId,
           GroupId ,
           MachineInternalId,
           PlantWasherNumber,
           StartDate ,
           ProgramNumber,
           ProgramMasterId,
           MachineId,
           ActualWeight,
           StandardWeight,
           CurrencyCode,
           ShiftId,
           PartitionOn,
           TargetTurnTime,
           StdInjectionSteps,
           StdWashSteps,
		   EcolabTextileCategoryId,
		   ChainTextileCategoryId,
           FormulaSegmentId,
            EcolabSaturationId,
              PlantProgramId
          )
         SELECT @BatchNumber,
          @EcolabWasherID,
          @WasherGroupID,
          @MachineInternalID,
          @PlantWasherNumber,
          @BatchStartTime,
          @ProgramNumber,
          @ProgramID,
          @WasherID,
          @Load,
          @Load,
          @CurrencyCode,
          @BatchShiftId,
          @PartitionOn,
          @TargetTurnTime,
          @StdInjectionSteps,
          @StdWashSteps,
		  @EcolabTextileCategoryId,
          @ChainTextileCategoryId,
          @FormulaSegmentId,
          @EcolabSaturationId,
          @PlantProgramId
       SELECT @BATCHID=Scope_Identity()
       INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue,PartitionOn) SELECT @BatchID,@EcolabWasherId,38,@StdWashSteps, @PartitionOn
       print 'BatchID : ' +Convert(nvarchar(20),@BatchID)

       IF( @CustomerNumber is not null)
       BEGIN
       INSERT INTO [TCD].[BatchCustomerData] ([BatchId],CustomerID,[Weight],PartitionOn,EcolabWasherId)
       SELECT @BatchID,@CustomerNumber,@Load,@PartitionOn,@EcolabWasherId
       END

       END 
  ELSE
  BEGIN
   SET @BatchStartTime = @TempBatchStartTime
  END
  --IF (@BatchEndTime is Not Null and @BatchEndTime !='01/01/1900')
  --BEGIN
  --UPDATE TCD.BatchData
  --SET EndDate = @BatchEndTime
  --WHERE BATCHID = @BatchID
  --END 
  
  -- Transfer Signal
  INSERT INTO TCD.WasherReading(
   WasherId,
   ParameterId,
   ParameterValue,
   DateTimeStamp,
   PartitionOn,
   EcolabWasherId)
   SELECT @WasherID,
   @TransferSignalId,
   1,
   @BatchStartTime,
   @PartitionOn,
   @EcolabWasherId
  UNION ALL
   SELECT @WasherID,
   @TransferSignalId,
   0,
   @BatchStartTime,
   @PartitionOn,
   @EcolabWasherId

  --IF NOT Exists(SELECT 1 FROM [TCD].[BatchCustomerData] 
  --     WHERE BatchID = @BatchID)
  --BEGIN
  --INSERT INTO [TCD].[BatchCustomerData] ([BatchId],CustomerID,[Weight],PartitionOn,EcolabWasherId)
  --SELECT @BatchID,@CustomerNumber,@Load,@PartitionOn,@EcolabWasherId
  --END 

  -- @Program Number
  SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
   WasherId = @WasherID 
   AND ParameterID = @PorgramParameterID 
   AND EcolabWasherId = @EcolabWasherId 
   AND DateTimeStamp = @BatchStartTime
   --AND ParameterValue = @ProgramNumber
   ORDER BY  DateTimeStamp DESC)

  IF (@TempParameter != @ProgramNumber)
  BEGIN
   INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
   SELECT @WasherID,@PorgramParameterID,@ProgramNumber,@BatchStartTime,@PartitionOn,@EcolabWasherId
  END 
  
  ---- PH Value
  --SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
  -- WasherId = @WasherID 
  -- AND ParameterID = @PHParameterID 
  -- AND EcolabWasherId = @EcolabWasherId 
  -- AND DateTimeStamp = @BatchStartTime
  -- --AND ParameterValue = @ProgramNumber
  -- ORDER BY  DateTimeStamp DESC)
  
  --IF (@TempParameter != @PHValue)
  --BEGIN
  -- IF (@PHValue > 0)
  -- BEGIN
  --  INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
  --  SELECT @WasherID,@PHParameterID,@PHValue,@BatchStartTime,@PartitionOn,@EcolabWasherId
  -- END
  --END 

  -- PH Status
  --SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
  -- WasherId = @WasherID 
  -- AND ParameterID = @PHParameterStatus 
  -- AND EcolabWasherId = @EcoLabWasherID 
  -- AND DateTimeStamp = @BatchStartTime
  -- --AND ParameterValue = @ProgramNumber
  -- ORDER BY  DateTimeStamp DESC)

  --IF (@TempParameter != @PHStatus)
  --BEGIN
  -- --IF (@PHStatus > 0)
  -- --BEGIN
  --  INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
  --  SELECT @WasherID,@PHParameterStatus,@PHStatus,@BatchStartTime,@PartitionOn,@EcolabWasherId
  -- --END
  --END 
  
  -- LF Value
  --SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
  -- WasherId = @WasherID 
  -- AND ParameterID = @ConductivityParamID 
  -- AND EcolabWasherId = @EcolabWasherId 
  -- AND DateTimeStamp = @BatchStartTime
  -- --AND ParameterValue = @ProgramNumber
  -- ORDER BY  DateTimeStamp DESC)

  --IF (@TempParameter != @LFValue)
  --BEGIN
  -- IF (@LFValue > 0)
  -- BEGIN
  --  INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
  --  SELECT @WasherID,@ConductivityParamID,@LFValue,@BatchStartTime,@PartitionOn,@EcolabWasherId
  -- END
  --END 
  
  -- LF Status
  --SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
  -- WasherId = @WasherID 
  -- AND ParameterID = @ConductivityStatusParamID 
  -- AND EcolabWasherId = @EcolabWasherId 
  -- AND DateTimeStamp = @BatchStartTime
  -- --AND ParameterValue = @ProgramNumber
  -- ORDER BY  DateTimeStamp DESC)

  --IF (@TempParameter != @LFStatus)
  --BEGIN
  -- --IF (@LFValue > 0)
  -- --BEGIN
  --  INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
  --  SELECT @WasherID,@ConductivityStatusParamID,@LFStatus,@BatchStartTime,@PartitionOn,@EcolabWasherId
  -- --END
  --END 
  
  -- Compartment No  
  SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
   WasherId = @WasherID 
   AND ParameterID = @CompartmentNoId 
   AND EcolabWasherId = @EcolabWasherId 
   AND DateTimeStamp = @BatchStartTime
   --AND ParameterValue = @ProgramNumber
   ORDER BY  DateTimeStamp DESC)

  IF (@TempParameter != @compartmentID)
  BEGIN
   --IF (@LFValue > 0)
   --BEGIN
    INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
    SELECT @WasherID,@CompartmentNoId,@compartmentID,@BatchStartTime,@PartitionOn,@EcolabWasherId
   --END
  END   

 
   EXEC TCD.UPDATEBatchWashStepForTunnel @TunnelXML,@WasherID,@BatchID, @BatchStartTime,@PartitionOn,@EcolabWasherId,@compartmentID
  
 IF(@PHValue is not null)
 BEGIN
   EXEC TCD.AddSensorData @ControllerID,@PHCompartment,@WasherGroupID,2,@PHValue
 END

 IF(@ConductivityValue is not null)
 BEGIN
   EXEC TCD.AddSensorData @ControllerID,@ConductivityCompartment,@WasherGroupID,4,@ConductivityValue
 END

 CREATE TABLE #TemperatureData(Value INT, 
          Compartment INT
         )

 INSERT INTO #TemperatureData(Value,Compartment)
   SELECT 
   T.c.value('@TemperatureValue', 'INT') AS Value, 
   T.c.value('@TemperatureCompartment', 'INT') AS Compartment
   
   FROM @TunnelXML.nodes('TunnelData/TemperatureData') T(c)
   
   -- Fetching data from cursor
   DECLARE @MYCURSOR CURSOR
   SET @MYCURSOR = CURSOR FAST_FORWARD
   FOR
   SELECT  Value,
      Compartment

    FROM #TemperatureData

   DECLARE   @TempValue    INT,
       @TempCompartment  INT

   OPEN @MYCURSOR
   FETCH NEXT FROM @MYCURSOR
      INTO 
       @TempValue,
       @TempCompartment
       
   WHILE @@FETCH_STATUS = 0   
   BEGIN 
    
    IF(@TempValue is not null)
    BEGIN
     EXEC TCD.AddSensorData @ControllerID,@TempCompartment,@WasherGroupID,1,@TempValue
    END

    FETCH NEXT FROM @MYCURSOR
      INTO 
       @TempValue,
       @TempCompartment
   END

   CLOSE @MYCURSOR
   DEALLOCATE @MYCURSOR

   Drop table #TemperatureData


    CREATE TABLE #DosingDetails(Number INT, 
          Quantity Decimal(10,6),
          Point INT,
          IsMainEquioment INT,
          IsDirectDosing INT
         )
    
   INSERT INTO #DosingDetails(Number,Quantity, Point, IsMainEquioment, IsDirectDosing)
   SELECT 
   T.c.value('@Number', 'INT') AS Number, --PumpNumber
   T.c.value('@Quantity', 'Decimal(10,6)') AS Quantity, --Dosing Quanity
   T.c.value('@Point', 'INT') AS Point, --ValveNumber
   T.c.value('@IsMainEquioment', 'INT') AS IsMainEquioment,
   T.c.value('@IsDirectDosing', 'INT') AS IsDirectDosing
     
   FROM @TunnelXML.nodes('TunnelData/Dose') T(c)
   
   -- Fetching data from cursor
   DECLARE @MYCURSOR1 CURSOR
   SET @MYCURSOR1 = CURSOR FAST_FORWARD
   FOR
   SELECT  Number,
      Quantity,          
      Point,
      IsMainEquioment,
      IsDirectDosing

    FROM #DosingDetails

   DECLARE   @Number    INT,
       @Quantity   Decimal(10,6),
       @Point    INT,
       @IsMainEquioment INT,
       @IsDirectDosing  INT

   OPEN @MYCURSOR1
   FETCH NEXT FROM @MYCURSOR1
      INTO 
       @Number,
       @Quantity,
       @Point,
       @IsMainEquioment,
       @IsDirectDosing
       
   WHILE @@FETCH_STATUS = 0   
   BEGIN 
    IF(@IsDirectDosing = 1)
    BEGIN
     SELECT @ProductId=CES.ProductId, @CompartmentNum=TCEVM.CompartmentNumber
     FROM tcd.ControllerEquipmentSetup CES 
     INNER JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM
     ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
     WHERE TCEVM.DirectDosingFlag = 1
        AND CES.ControllerId=@ControllerID 
        AND CES.ControllerEquipmentId=@Number
        AND CES.ControllerEquipmentTypeId=1 
        --AND IsActive=1 
        AND CES.WasherGroupNumber=@WasherGroupNum
    END
    ELSE IF(@IsMainEquioment = 1)
    BEGIN
     SELECT @ProductId=CES.ProductId, @CompartmentNum=TCEVM.CompartmentNumber
        FROM  tcd.ControllerEquipmentSetup CES INNER JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM
     ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
     WHERE CES.ControllerId=@ControllerID AND
        CES.ControllerEquipmentTypeId=2 AND
        --CES.IsActive=1 AND
        CES.WasherGroupNumber=@WasherGroupNum AND
        TCEVM.ValveNumber=@Point AND
        CES.ControllerEquipmentId = @Number
    END
    ELSE
    BEGIN
     SELECT @ProductId=CES.ProductId, @CompartmentNum=TCEVM.CompartmentNumber
        FROM  tcd.ControllerEquipmentSetup CES INNER JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM
     ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
     WHERE CES.ControllerId=@ControllerID AND
        CES.ControllerEquipmentTypeId=1 AND
        --CES.IsActive=1 AND
        CES.WasherGroupNumber = @WasherGroupNum AND
        TCEVM.ValveNumber=@Point      
    END

    IF(@ProductId is not null)
    BEGIN
     SELECT TOP 1 @PrevRealQty = RealQty FROM TCD.WasherProductReading WHERE ControllerId=@ControllerID AND WasherId = @WasherId ORDER BY DateTimeStamp DESC
 
     IF(@PrevRealQty is null OR @PrevRealQty != @Quantity)
     BEGIN
    
      INSERT INTO [TCD].[WasherProductReading] 
          (ControllerId,
        WasherId,
        MachineInternalId,
        ProductId,
        RealQty,
        DosingNumber,
        ProgramNumber,
        BatchNumber,
        ValveNumber,
        DateTimeStamp      
          )
          SELECT
           @ControllerId,
           @WasherId,
           @MachineInternalId,
           @ProductId,
           @Quantity,
           @Number,
           @ProgramNumber,
           @BatchNumber,
           @Point,
           GETUTCDATE()       
     END
    END

    FETCH NEXT FROM @MYCURSOR1
      INTO 
       @Number,
       @Quantity,
       @Point,
       @IsMainEquioment,
       @IsDirectDosing
   END

   CLOSE @MYCURSOR1
   DEALLOCATE @MYCURSOR1

   Drop table #DosingDetails
      
   SELECT @compartmentID= @compartmentID - 1 
 END    

 UPDATE BD
 SET EndDate=GetUTCDate()
 FROM TCD.BatchData BD
 WHERE MachineId =@WasherID
    AND EndDate is Null
    AND CAST(StartDate as date)=CAST(@BatchStartTime as date)
       AND Not Exists(SELECT 1 
       FROM #Batches t
       WHERE t.BatchNumber = BD.ControllerBatchId
          --and t.StartDateTime =BD.StartDate
      )

  --Last Step is not getting closed in Tunnel BatchWashStepData
 UPDATE BWD
 SET EndTime=GetUTCDate()
 FROM TCD.BatchWashStepData BWD
 INNER JOIN TCD.BatchData BD on BWD.BatchId = BD.BatchId
 WHERE BD.MachineId =@WasherID
              AND BWD.EndTime is Null
              AND Not Exists(SELECT 1 FROM #Batches t
                             WHERE t.BatchNumber = BD.ControllerBatchId)
                             --and t.StartDateTime =BD.StartDate)      
END
Go
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMitsubishiTunnelWasherProdData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMitsubishiTunnelWasherProdData]
END
GO
CREATE PROCEDURE [TCD].[ProcessMitsubishiTunnelWasherProdData]
 (
  @ControllerID INT,
  @xmlTags xML
 )
AS
BEGIN
   DECLARE 
   @BatchID      INT,
   @WasherID      INT,
   @EcolabWasherId     INT,
   @CurrencyCode     VARCHAR(50),  
   @MachineInternalId    INT,
   @WasherGroupID     INT,
   @WasherGroupNum     INT,
   @PlantWasherNumber    INT,
   @BatchStartDate     DATETIME2,
   @BatchEndDate     DATETIME2,   
   @ProgramNumber     INT,
   @Load       Decimal(10,2),
   @NominalLoad     Decimal(10,2),
   @CustomerNumber     INT,
   @PHStatus      INT,
   @PHValue      INT,
   @LFStatus      INT,
   @LFValue      INT,
   @EjectionSignal     INT,
   @TextTileCategory    INT,
   @BatchNumber     INT,
   @TargetTurnTime     INT,
   @ShiftID      INT,
   @ParameterID     INT,   
   @ShiftName      VARCHAR(50),
   @EcolabAccountNumber NVARCHAR(25) = NULL,
   @PartitionOn DateTime,
   @BatchStartTime DateTime,
   @BatchEndTime DateTime,
   @PorgramParameterID int,
   @PHParameterID int,
   @ConductivityParamID int,
   @RunTime int,
   @TextileCategory int,
   @ProgramID int,
   @NumberOfCompartments int,
   @TempParameter int,
   @PumpNo   INT, 
   @DosingPoint INT,
   @ProductId INT,
   @CompartmentNum INT,
   @MinTempParamID INT,
   @MaxTempParamID INT,
   @TempStatusParamID INT,
   @PHValueParamID INT,
   @PHStatusParamID INT,
   @ActualInjSteps INT
   
    
 --INSERT into MyControlXML (xmlData, BatchType, PLCPointer, ReadPointer, BatchID, comment,LastModified) values (@xmlTags, 'TunnelCompleted', null, null, null, '',getDate())

    SELECT @PorgramParameterID=ID
 FROM TCD.ConduitParameters WHERE NAME ='Formula Number'

 SELECT @PHParameterID=ID
 FROM TCD.ConduitParameters WHERE NAME ='pH'

 SELECT @ConductivityParamID=ID
 FROM TCD.ConduitParameters WHERE NAME ='Conductivity'

 CREATE TABLE #Batches(BatchNumber int,StartDateTime DateTime)
    
 DECLARE @BatchShiftId int
 DECLARE @ShiftStartDateTemp table(ShiftId INT,ShiftName NVARCHAR(50),ShiftStartdate DATETIME)

 DECLARE @compartmentID int,
   @TunnelXML xml
   
   
 SELECT @compartmentID = 1
 SELECT @WasherID=null;
    
   
    SELECT @TunnelXML=T.c.query('.') 
  FROM   @xmlTags.nodes('MyControlTunnel/TunnelData') T(c)
  WHERE T.c.value('@CompartmentNumber', 'INT') = 20


   SELECT   
      --@MachineInternalID=T.c.value('@MachineNumber', 'int'),
      @BatchNumber= T.c.value('@BatchNumber', 'INT'),
       @BatchStartTime=T.c.value('@StartDateTime', 'DateTime'),
      @BatchEndTime=T.c.value('@EndDateTime', 'DateTime'),
      @ProgramNumber=T.c.value('@ProgramNumber', 'INT'),
      @Load=T.c.value('@Load', 'Decimal(10,2)')/10,
      @NominalLoad=T.c.value('@Nominalload', 'Decimal(10,2)'),
      @WasherGroupNum=T.c.value('@GroupNumber', 'int'),
      @CustomerNumber=T.c.value('@CustomerNumber', 'int'),
      @PHStatus=T.c.value('@pHStatus', 'int'),
      @PHValue=T.c.value('@pHValue', 'INT'),
      @LFStatus=T.c.value('@LFStatus', 'INT'),
      @LFValue=T.c.value('@LFValue', 'INT'),
      @RunTime=T.c.value('@RunTime', 'INT'),
      @EjectionSignal=T.c.value('@EjectionSignal', 'INT'),
      @TextileCategory=T.c.value('@TextileCategory', 'INT')
   FROM @TunnelXML.nodes('TunnelData')  T(c);
   

    
  
  SELECT @WasherGroupID= Wg.WasherGroupId
  FROM TCD.WasherGroup Wg 
  WHERE ControllerID = @ControllerID 
		AND WasherDosingNumber = @WasherGroupNum 
		AND WasherGroupTypeId = 2


   print '@WasherGroupID = ' + isNull(Convert(nvarchar(10),@WasherGroupID),'Null')
   
   
   SELECT @ProgramID=ProgramId,
    @TargetTurnTime= (3600 / (tps.TotalRunTime /@NumberOfCompartments )) 
   FROM TCD.TunnelProgramSetup AS tps 
   WHERE tps.WasherGroupId = @WasherGroupID 
      and tps.is_deleted =0
      and ProgramNumber = @ProgramNumber

 
   print '@ProgramID = ' + isNull(Convert(nvarchar(10),@ProgramID),'Null')
   
       

  SELECT @BatchID = Null

  SELECT @BatchID=BatchID, @WasherID=MachineId, @BatchStartTime=StartDate, @EcolabWasherId=EcolabWasherId
   FROM TCD.BatchData
   WHERE ControllerBatchId = @BatchNumber
     AND GroupId = @WasherGroupID 
     AND CAST(StartDate as date)=CAST(@BatchStartTime as date)

   print '@BatchID = ' + isNull(Convert(nvarchar(10),@BatchID),'Null')
   print '@WasherID/MachineId = ' + isNull(Convert(nvarchar(10),@WasherID),'Null')
   print '@EcolabWasherId/@EcolabWasherId= ' + isNull(Convert(nvarchar(10),@EcolabWasherId),'Null')
   if ( @BatchID is Null) return ;
   	print '*********Batch End Date: ' + Convert(nvarchar(10),@BatchEndTime)
  IF (@BatchID is NOT Null) 
  BEGIN
   IF (@BatchEndTime is Not Null)
   BEGIN
     
    INSERT INTO @ShiftStartDateTemp(ShiftId,ShiftName,ShiftStartdate) 
    EXEC TCD.GetShiftStartDate @BatchEndTime

    SELECT @BatchShiftId = ShiftID, @PartitionOn=ShiftStartdate FROM @ShiftStartDateTemp
	print ' Batch End Date: ' + Convert(nvarchar(10),@BatchEndTime)
    UPDATE TCD.BatchData SET EndDate = @BatchEndTime, ShiftId=@BatchShiftId, PartitionOn=@PartitionOn WHERE BATCHID = @BatchID


    --EXEC TCD.UPDATEBatchWashStepForTunnel @TunnelXML, @WasherID, @BatchID, @BatchStartTime, @PartitionOn, @EcolabWasherId, 20
   END
      
  
   CREATE TABLE #DosingDetails(Number INT, 
          Quantity Decimal(10,6),
          Point INT,
          IsMainEquioment INT,
          IsDirectDosing INT
         )
     
   --IF EXISTS (SELECT  * FROM TEMPDB.DBO.SYSOBJECTS o where o.xtype in ('U') AND o.id = OBJECT_ID(N'tempdb..#DosingDetails'))
   --BEGIN
   --  DROP TABLE #DosingDetails
   --END

   INSERT INTO #DosingDetails(Number,Quantity, Point, IsMainEquioment, IsDirectDosing)
   SELECT 
   T.c.value('@Number', 'INT') AS Number, --PumpNumber
   T.c.value('@Quantity', 'Decimal(10,6)') AS Quantity, --Dosing Quanity
   T.c.value('@Point', 'INT') AS Point, --ValveNumber
   T.c.value('@IsMainEquipment', 'INT') AS IsMainEquioment,
   T.c.value('@IsDirectDosing', 'INT') AS IsDirectDosing
   FROM @TunnelXML.nodes('TunnelData/Dose') T(c)
   
   -- Fetching data from cursor
   DECLARE @MYCURSOR CURSOR
   SET @MYCURSOR = CURSOR FAST_FORWARD
   FOR
   SELECT  Number,
      Quantity,          
      Point,
      IsMainEquioment,
      IsDirectDosing

    FROM #DosingDetails

   DECLARE   @Number    INT,
       @Quantity   Decimal(10,6),
       @Point    INT,
       @IsMainEquioment INT,
       @IsDirectDosing  INT

   OPEN @MYCURSOR
   FETCH NEXT FROM @MYCURSOR
      INTO 
       @Number,
       @Quantity,
       @Point,
       @IsMainEquioment,
       @IsDirectDosing
       
   WHILE @@FETCH_STATUS = 0   
   BEGIN 
    IF(@IsDirectDosing = 1)
    BEGIN
     SELECT @ProductId=CES.ProductId, @CompartmentNum=TCEVM.CompartmentNumber
     FROM tcd.ControllerEquipmentSetup CES 
     INNER JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM
     ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
     WHERE TCEVM.DirectDosingFlag = 1
        AND CES.ControllerId=@ControllerID 
        AND CES.ControllerEquipmentId=@Number
        AND CES.ControllerEquipmentTypeId=1 
        --AND IsActive=1 
        AND CES.WasherGroupNumber=@WasherGroupNum
    END
    ELSE IF(@IsMainEquioment = 1)
    BEGIN
     SELECT @ProductId=CES.ProductId, @CompartmentNum=TCEVM.CompartmentNumber
        FROM  tcd.ControllerEquipmentSetup CES INNER JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM
     ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
     WHERE CES.ControllerId=@ControllerID AND
        CES.ControllerEquipmentTypeId=2 AND
        --CES.IsActive=1 AND
        CES.WasherGroupNumber=@WasherGroupNum AND
        TCEVM.ValveNumber=@Point AND
        CES.ControllerEquipmentId = @Number
    END
    ELSE
    BEGIN
     SELECT @ProductId=CES.ProductId, @CompartmentNum=TCEVM.CompartmentNumber
        FROM  tcd.ControllerEquipmentSetup CES INNER JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM
     ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
     WHERE CES.ControllerId=@ControllerID AND
        CES.ControllerEquipmentTypeId=1 AND
        --CES.IsActive=1 AND
        CES.WasherGroupNumber = @WasherGroupNum AND
        TCEVM.ValveNumber=@Point      
    END

    IF(@ProductId is not null)
    BEGIN
	 print 'Batch Product data is not null'
     INSERT INTO TCD.BatchProductData 
     (BatchId, StepCompartment, ActualQuantity,PartitionOn,EcolabWasherId,ProductId)
     SELECT @BatchID,
      @CompartmentNum,
      @Quantity,
      @PartitionOn,
      @EcolabWasherId,
      @ProductId
    END
	Else 
	BEGIN
	 print 'Batch Product data is null'
	END 

    FETCH NEXT FROM @MYCURSOR
      INTO 
       @Number,
       @Quantity,
       @Point,
       @IsMainEquioment,
       @IsDirectDosing
   END

   CLOSE @MYCURSOR
   DEALLOCATE @MYCURSOR

   Drop table #DosingDetails

   
  SELECT @ActualInjSteps = COUNT(DISTINCT StepCompartment) FROM TCD.BatchProductData WHERE BatchId=@BatchID
  IF NOT EXISTS(SELECT * FROM TCD.BatchParameters WHERE ParameterId =37 and batchid=@BatchID AND @ActualInjSteps > 0)
  BEGIN
   INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,37,@ActualInjSteps, @PartitionOn
  END
  ELSE
  BEGIN
   Update TCD.BatchParameters SET ParameterValue=@ActualInjSteps WHERE ParameterId =37 and batchid=@BatchID
  END
   END 

  SELECT @MinTempParamID=Id 
  FROM [TCD].[ConduitParameters] 
  WHERE Name = 'Mimum Temperature' 
    
  SELECT @MaxTempParamID=Id 
  FROM [TCD].[ConduitParameters] 
  WHERE Name = 'Maximum Temperature'

  SELECT @TempStatusParamID=Id 
  FROM [TCD].[ConduitParameters] 
  WHERE Name = 'Temperature Status'

  SELECT @PHValueParamID=ID
  FROM [TCD].[ConduitParameters] 
  WHERE Name = 'PH'
    
  SELECT @PHStatusParamID=ID
  FROM [TCD].[ConduitParameters] 
  WHERE Name =  'PH Status'  
  
  --pH Status
  INSERT INTO TCD.BatchParameters
  (BatchId,
   EcolabWasherId,
   ParameterId,
   ParameterValue,
   PartitionOn)
  VALUES(@BatchID,
    @EcoLabWasherID,
    @PHStatusParamID,
    @PHStatus,
    @PartitionOn)

  --pH Value
  INSERT INTO TCD.BatchParameters
  (BatchId,
   EcolabWasherId,
   ParameterId,
   ParameterValue,
   PartitionOn)
  VALUES(@BatchID,
    @EcoLabWasherID,
    @PHValueParamID,
    @PHValue,
    @PartitionOn)

  CREATE TABLE #TemperatureDetails(MinimumTemp Decimal(10,2), 
           MaximumTemp Decimal(10,2),
           TempStatus Decimal(10,2)
          )
     
   INSERT INTO #TemperatureDetails(MinimumTemp,MaximumTemp, TempStatus)
   SELECT 
   T.c.value('@MinimumTemp', 'Decimal(10,2)') AS MinimumTemp, 
   T.c.value('@MaximumTemp', 'Decimal(10,2)') AS MaximumTemp,
   T.c.value('@Status', 'Decimal(10,2)') AS Status
   
   FROM @TunnelXML.nodes('TunnelData/TemperatureData') T(c)
   
   -- Fetching data from cursor
   DECLARE @TEMPCURSOR CURSOR
   SET @TEMPCURSOR = CURSOR FAST_FORWARD
   FOR
   SELECT  MinimumTemp,
      MaximumTemp,          
      TempStatus

    FROM #TemperatureDetails

   DECLARE   @MinimumTemp    Decimal(10,2),
       @MaximumTemp   Decimal(10,2),
       @TempStatus    Decimal(10,2)
       
   OPEN @TEMPCURSOR
   FETCH NEXT FROM @TEMPCURSOR
      INTO 
       @MinimumTemp,
       @MaximumTemp,
       @TempStatus
       
   WHILE @@FETCH_STATUS = 0   
   BEGIN 
    --Minimum Temperature
    INSERT INTO TCD.BatchParameters
    (BatchId,
     EcolabWasherId,
     ParameterId,
     ParameterValue,
     PartitionOn)
    VALUES(@BatchID,
      @EcoLabWasherID,
      @MinTempParamID,
      @MinimumTemp,
      @PartitionOn)

    --Maximum Temperature
    INSERT INTO TCD.BatchParameters
    (BatchId,
     EcolabWasherId,
     ParameterId,
     ParameterValue,
     PartitionOn)
    VALUES(@BatchID,
      @EcoLabWasherID,
      @MaxTempParamID,
      @MaximumTemp,
      @PartitionOn)

    --Temperature Status
    INSERT INTO TCD.BatchParameters
    (BatchId,
     EcolabWasherId,
     ParameterId,
     ParameterValue,
     PartitionOn)
    VALUES(@BatchID,
      @EcoLabWasherID,
      @TempStatusParamID,
      @TempStatus,
      @PartitionOn)        

    FETCH NEXT FROM @TEMPCURSOR
      INTO 
       @MinimumTemp,
       @MaximumTemp,
       @TempStatus
   END

   CLOSE @TEMPCURSOR
   DEALLOCATE @TEMPCURSOR

   Drop table #TemperatureDetails
                                            

END
Go
----------------------------------------------------------------END PLC Step Save Data for PLCXL--------------------------------------------------------------------------------------
BEGIN TRY
    IF EXISTS( SELECT *
                 FROM TCD.Field
                 WHERE label LIKE 'IP Address'
                   AND id = 309
             )
        BEGIN
            BEGIN TRAN UPDATEDEFAULTIPADDRESS

		  UPDATE TCD.Field
      SET DefaultValue = '10.255.143.1'
      WHERE label LIKE 'IP Address'
        AND id = 309
	   COMMIT TRAN UPDATEDEFAULTIPADDRESS
        END
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        BEGIN
            ROLLBACK TRAN UPDATEDEFAULTIPADDRESS
        END
END CATCH
GO   

BEGIN TRY
    IF EXISTS(SELECT
                      1 FROM TCD.Field WHERE Label LIKE 'Enable Reset button'
                                         AND id IN(323, 362))
        BEGIN
            BEGIN TRAN ENABLERESETBUTTON;
            UPDATE TCD.Field SET
                    DefaultValue = 'true'
                WHERE
                    Label LIKE 'Enable Reset button'
                AND id IN(323, 362);
            COMMIT TRAN ENABLERESETBUTTON;
        END;
END TRY
BEGIN CATCH
    IF @@Trancount > 0
        BEGIN
            ROLLBACK TRAN ENABLERESETBUTTON;
        END;
END CATCH;
GO  

IF NOT EXISTS (SELECT 1 FROM tcd.ResourceKeyMaster rkm WHERE rkm.KeyName='FIELD_FLOWMETERFLOWSWITCHACTIVATED')
BEGIN
INSERT INTO tcd.ResourceKeyMaster
(
    KeyName,
    KeyDescription
)
VALUES
(
    N'FIELD_FLOWMETERFLOWSWITCHACTIVATED', 
    N'Flow Meter Activated' 
)
END
GO
IF NOT EXISTS (SELECT 1 FROM tcd.ResourceKeyValue rkv WHERE rkv.KeyName='FIELD_FLOWMETERFLOWSWITCHACTIVATED' AND rkv.LanguageID=1)
BEGIN
INSERT INTO tcd.ResourceKeyValue
(
    [Value],
    LanguageID,
    LastModifiedTime,
    KeyName
)
VALUES
(
    N'Flow Meter Activated', -- Value - nvarchar
    1, -- LanguageID - int
    GETDATE(), -- LastModifiedTime - datetime
    N'FIELD_FLOWMETERFLOWSWITCHACTIVATED' -- KeyName - nvarchar
)
END
GO

 


BEGIN TRY
    IF EXISTS( SELECT 1 FROM TCD.Field where Id =371)
        BEGIN
            BEGIN TRAN UPDATEDigitalInput
        END;
   update TCD.Field set Label='Digital Input Card 1 (Signal Machines) Position 0 Rack 1' where Id=371
   COMMIT;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        BEGIN
            ROLLBACK
        END;
END CATCH;
GO   

BEGIN TRY
    IF EXISTS( SELECT 1 FROM TCD.Field where Id  in (216,407,472)
             )
        BEGIN
            BEGIN TRAN UPDATEHysteresisonConnexxlevel
        END;
   update TCD.Field set Label='Hysteresis on Connexx level' where Id  in (216,407,472)
   COMMIT;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        BEGIN
            ROLLBACK
        END;
END CATCH;
GO   

BEGIN TRY
    IF EXISTS( SELECT 1 FROM TCD.Field where id = 362)
        BEGIN
            BEGIN TRAN UPDATEDefaultValue
        END;
    UPDATE TCD.Field SET DefaultValue = 'true' where id = 362;
	  COMMIT;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        BEGIN
            ROLLBACK
        END;
END CATCH;
GO   

BEGIN TRY
    IF EXISTS( select 1 from TCD.ResourceKeyValue WHERE KeyName='FIELD_MAXDOSINGTIME'	AND languageID=1)
        BEGIN
            BEGIN TRAN UPDATEMaximumDosingTime
        END;
    UPDATE TCD.ResourceKeyValue SET Value = 'Maximum Dosing Time' where KeyName='FIELD_MAXDOSINGTIME' and languageID=1;
	  COMMIT;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        BEGIN
            ROLLBACK
        END;
END CATCH;
GO   

BEGIN TRY
    IF EXISTS( SELECT 1 FROM TCD.Field where id = 403)
        BEGIN
            BEGIN TRAN UPDATEDataTypeId
        END;
 update TCD.Field set DataTypeId= 5 where Id=403;
    COMMIT;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        BEGIN
            ROLLBACK
        END;
END CATCH;
GO

--Local Report label Changes
-- Average Daily Cost YTD
IF NOT EXISTS (SELECT 1 FROM tcd.ReportLocalizationColumnMapping rlcm WHERE rlcm.UsageKey='FIELD_AVGDAILYCOSTYTD')
BEGIN
INSERT INTO tcd.ReportLocalizationColumnMapping
(
    --Id - this column value is auto-generated
    ReportColumnId,
    ReportId,
    UsageKey,
    UomKey
)
VALUES
(
    -- Id - int
    20, -- ReportColumnId - int
    6, -- ReportId - int
    'FIELD_AVGDAILYCOSTYTD', -- UsageKey - varchar
    'price_per_weight' -- UomKey - varchar
)
END
ELSE
BEGIN
 UPDATE tcd.ReportLocalizationColumnMapping
 SET
      TCD.ReportLocalizationColumnMapping.UomKey = 'price_per_weight' -- varchar
WHERE tcd.ReportLocalizationColumnMapping.UsageKey='FIELD_AVGDAILYCOSTYTD'
END
GO

-- Actual Energy
IF NOT EXISTS (SELECT 1 FROM tcd.ReportLocalizationColumnMapping rlcm WHERE rlcm.UsageKey='FIELD_ACTUALENERGY')
BEGIN
INSERT INTO tcd.ReportLocalizationColumnMapping
(
    --Id - this column value is auto-generated
    ReportColumnId,
    ReportId,
    UsageKey,
    UomKey
)
VALUES
(
    -- Id - int
    7, -- ReportColumnId - int
    10, -- ReportId - int
    'FIELD_ACTUALENERGY', -- UsageKey - varchar
    'EnergyConsumption_RedFlag' -- UomKey - varchar
)
END
ELSE
BEGIN
 UPDATE tcd.ReportLocalizationColumnMapping
 SET
      TCD.ReportLocalizationColumnMapping.UomKey = 'EnergyConsumption_RedFlag' -- varchar
WHERE tcd.ReportLocalizationColumnMapping.UsageKey='FIELD_ACTUALENERGY'
END
GO

--Start ETechConfigSettings

---Script to add CustomerCodes record in TCD.ConfigSettings table
IF NOT EXISTS(SELECT * FROM TCD.ConfigSettings WHERE TCD.ConfigSettings.KeyName = 'CustomerCodes')
    BEGIN
	INSERT INTO TCD.ConfigSettings
	(
	    TCD.ConfigSettings.KeyName,
	    TCD.ConfigSettings.[Value],
	    TCD.ConfigSettings.Type,
	    TCD.ConfigSettings.Active
	)
	VALUES
	(
	    N'CustomerCodes', -- KeyName - nvarchar
	    N'CustomerCodes', -- Value - nvarchar
	    N'ETech', -- Type - nvarchar
	    1 -- Active - bit
	)
    END
    GO
	
	
--Procedure GetPlantIndfo updation to get new column value ETechCustomerCodesText
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetPlantInfo]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetPlantInfo;
	END; 
GO 
CREATE PROCEDURE TCD.GetPlantInfo
AS
BEGIN

	SET NOCOUNT ON;

	SELECT
			p.EcolabAccountNumber, 
			p.Name, 
			p.IsETechEnable, 
			p.ETechIpAddress, 
			p.ETechTimeDiff
		FROM TCD.plant AS P
		WHERE Is_Deleted = 0;

	SET NOCOUNT OFF;
END;
GO	

--Script to drop constraint DF_Plant_ETechCustomerCodesText of TCD.Plant Table
IF EXISTS(SELECT
					  *
				  FROM sys.default_constraints
				  WHERE parent_object_id = OBJECT_ID(N'TCD.Plant')
					AND name = 'DF_Plant_ETechCustomerCodesText')
	BEGIN
		ALTER TABLE TCD.Plant
		DROP CONSTRAINT
				DF_Plant_ETechCustomerCodesText;
	END;
GO


--Script to drop column ETechCustomerCodesText from TCD.Plant Table
IF EXISTS(SELECT
					  *
				  FROM sys.columns
				  WHERE object_id = OBJECT_ID(N'TCD.Plant')
					AND name = 'ETechCustomerCodesText')
	BEGIN
		ALTER TABLE TCD.Plant
		DROP COLUMN
				ETechCustomerCodesText;
	END;
GO



--SP to Get CustomerCodesText from config settings
IF EXISTS(SELECT
				*
			FROM sys.objects
			WHERE object_id = OBJECT_ID(N'[TCD].[GetETechConfigSettings]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetETechConfigSettings;
	END; 
GO 
CREATE PROCEDURE TCD.GetETechConfigSettings
AS
BEGIN

	SET NOCOUNT ON;

	SELECT
			cs.[Value] FROM TCD.ConfigSettings AS cs WHERE cs.KeyName = 'CustomerCodes';

	SET NOCOUNT OFF;
END;
GO

--SP ProcessConventionalWasherData
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[ProcessConventionalWasherData]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.ProcessConventionalWasherData;
	END; 
GO
CREATE PROCEDURE [TCD].[ProcessConventionalWasherData]
 ( 
 @WasherId INT, 
 @xmlTags XML,
 @RedFlagShiftId INT OUTPUT
)

AS
BEGIN
  DECLARE @BatchID        INT,
    @EcolabWasherId       INT,        
    @CurrencyCode       VARCHAR(50),  
    @MachineInternalId      INT,
    @GroupId        INT,  
    @Prveformula       INT,
    @Quantity        INT,
    @MaxWashertGroupCapacity    INT,

    @ProgramMasterId      INT,
    @NominalLoad       DECIMAL(10,2),
    @MaxLoad        DECIMAL(10,2),
    @StandardWeight       DECIMAL(10,2) ,     

    @CurrentFormula       INT,  
    @CurrentFormulaDate      DATETIME2,
    @FormulaIsModified      BIT,

    @CurrentInjection      INT,
    @CurrentInjectionDate     DATETIME2,
    @InjectionIsModified     BIT,

    @OperationalCount      INT,
    @OperationalIsModified     BIT, 
    
    @CurrentHoldSignal      INT,
    @CurrentHoldSignalDate     DATETIME2,
    @HoldSignalIsModified     BIT,  
             
    @EndofFormula       INT, 
    @EndofFormulaDate      DATETIME2,
    
    @AutoWeightEntryActive     BIT,
    @AutoWeightEntryWeight     DECIMAL(10,2),                                                                                                                              
    @ControllerId       INT,
    @CurrentHoldSignalValue     INT ,
    
    @MeterPlcAddress      INT,
    @MeterPlcAddressIsModified    INT,
    @BatchGroupId       INT,
    @BatchFormula       INT,    
    @HoldTime        INT,
    @CteTempBatchInjections     INT,
    @CteTempWaherReadingInjections   INT,
    @BatchStandardWaterUsage    INT,
    @BatchActualWaterUsage     INT,
    @BatchWaterUsagePrice     Decimal(10,2),
    @BatchUtilityPrice      Decimal(10,2),
    @BatchWaterType       INT,
    @PrevGroupId       INT,
    @WasherMeterExists      BIT,
    @ExtraTime        INT,
    @TargetTurnTime       INT,
    @RatioDosingEnabled      BIT,
 @EcolabAccountNumber NVARCHAR(25) = NULL,
 @PreviousFormulaDate      DATETIME2,
 @PreviousInjectionStep INT,
 @PreviousInjectionStartDate DATETIME2,
 @CurrentInjectionStep INT,
 @WashStepBatchId INT,
 @PrevFormulaExtraTime INT      ,
 @AlarmGroupMasterId INT,
 @StdWashSteps INT,
    @StdInjectionSteps INT,
 @EcolabTextileCategoryId INT,
 @ChainTextileCategoryId INT,
 @FormulaSegmentId INT,
 @EcolabSaturationId INT,
 
 @PreviousShiftId INT,
 @CurrentShiftId INT,                                                                                                              
 @PlantProgramId INT,
 @ETechLastDroppedAt  DATETIME2,
 @CustomerCodes VARCHAR(100)

  SET @RedFlagShiftId = NULL
      
  IF EXISTS (SELECT  * FROM [TEMPDB].[DBO].[SYSOBJECTS] o where o.xtype in ('U') AND o.id = OBJECT_ID(N'tempdb..#XmlTagsTable'))
   BEGIN
     DROP TABLE #XmlTagsTable
   END


  CREATE TABLE  #XmlTagsTable ( TagId INT, 
          TagValue NVARCHAR(100), 
          ReceivedTime DATETIME2,
          TagType NVARCHAR(50),
										IsModified BIT,
										ETechLastDropped VARCHAR(100),
										CustomerCodes VARCHAR(100)
         )

 
  INSERT INTO #XmlTagsTable (
          TagId,
          TagValue,
          ReceivedTime,
          TagType,
										IsModified,
										ETechLastDropped,
										CustomerCodes
         )   
  
  SELECT   
     T.c.value('@TagId', 'INT') as TagId,
     T.c.value('@Value', 'NVARCHAR(100)') TagValue,
     T.c.value('@TimeStamp', 'VARCHAR(100)') DateTimeStamp,
     T.c.value('@TagType', 'VARCHAR(50)') TagType,
					T.c.value('@IsModified', 'BIT') TagType,
					T.c.value('@ETechLastDroppedAt', 'VARCHAR(100)') ETechLastDropped,
					T.c.value('@CustomerCodes', 'VARCHAR(100)') CustomerCodes
  FROM  @xmlTags.nodes('Tags/Tag') T(c)
  WHERE 
     T.c.value('@TagId', 'varchar(100)')  IS NOT NULL
 
  SELECT @CurrentFormula     =  TagValue,  
    @CurrentFormulaDate    =  ReceivedTime,
    @FormulaIsModified     =  IsModified
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_FRM'   
     
  SELECT @CurrentInjection    =  TagValue,
    @CurrentInjectionDate   =  ReceivedTime,
    @InjectionIsModified   =  IsModified   
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_INJ'

  SELECT @OperationalCount    =  TagValue,
    @OperationalIsModified   =  IsModified  
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_OPC'  
   
  SELECT @EndofFormula     =  TagValue,
    @EndofFormulaDate    =  ReceivedTime  
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_EOF' 
  
  SELECT @AutoWeightEntryActive   =  TagValue     
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_AWEA'                 

  SELECT @CurrentHoldSignal    =  TagValue, 
    @HoldSignalIsModified   =  IsModified,  
    @CurrentHoldSignalDate   =  ReceivedTime 
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_HOLDL'

  SELECT @AutoWeightEntryWeight   =  TagValue,
   @ETechLastDroppedAt    =  CONVERT(datetime,ETechLastDropped),
   @CustomerCodes   = CustomerCodes
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_AWEW'

  SELECT @MeterPlcAddress    =  TagValue,
    @MeterPlcAddressIsModified  =       IsModified       
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_MPLC'
  
  SELECT @RatioDosingEnabled    =  TagValue      
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_RATA'
  
  SELECT * FROM #XmlTagsTable
  
  SELECT @ExtraTime      =  0

  SELECT TOP 1 @BatchID=BatchId, @Prveformula=ProgramNumber,@PrevGroupId=GroupId, @PreviousFormulaDate=StartDate FROM TCD.BatchData WHERE MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC

  IF(@PreviousFormulaDate is NOT NULL)
  BEGIN
	IF(@CurrentFormulaDate < @PreviousFormulaDate)
	BEGIN
		return
	END
  END

  IF(@CurrentFormula != @EndofFormula AND
     @CurrentFormula = @Prveformula AND 
  @CurrentInjection = 0 AND
  @OperationalCount = 0 AND
  @CurrentFormulaDate <= @PreviousFormulaDate AND
  @CurrentInjectionDate > @PreviousFormulaDate)
 BEGIN
 --Here means, If the same formula is received without EOF then the timestamp of the formula
 --will be still the old timestamp because value is not changed.
 --In this case assign injection=0 timestamp to formula timestamp
  SELECT @CurrentFormulaDate = @CurrentInjectionDate 
 END

  DECLARE @ShiftStartDate table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
  INSERT INTO @ShiftStartDate(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate

  SELECT DISTINCT 
     @EcolabWasherId    =  Ws.EcolabWasherId,
     @StandardWeight    =  Wps.NominalLoad,
     @CurrencyCode    =  Pl.CurrencyCode,
     @ControllerId    =  Ctrl.ControllerId,
     @TargetTurnTime    =  Ws.TargetTurnTime * 60     
  FROM 
     TCD.Washer Ws  
  INNER JOIN 
     TCD.MachineSetup Mst ON
     Mst.WasherId    =  Ws.WasherId
  INNER JOIN 
     TCD.WasherGroup Wg ON 
     Wg.WasherGroupId   =  Mst.GroupId    
  INNER JOIN 
     TCD.WasherProgramSetup Wps ON 
     Wps.WasherGroupId   =  Wg.WasherGroupId
  LEFT JOIN 
     TCD.WasherDosingSetup Wds ON 
     Wds.WasherProgramSetupId =  Wps.WasherProgramSetupId
  LEFT JOIN 
     TCD.WasherDosingProductMapping Wdpm ON 
     Wdpm.WasherDosingSetupId =  Wds.WasherDosingSetupId
  INNER JOIN 
     TCD.Plant Pl ON 
     Pl.EcolabAccountNumber  =  Ws.EcoLabAccountNumber
  INNER JOIN 
    TCD.ConduitController Ctrl 
    ON Ctrl.ControllerId   =  Mst.ControllerId 
  WHERE Ws.WasherId= @WasherId

  SELECT DISTINCT 
     @MachineInternalId=Mst.MachineInternalId,
     @GroupId=Mst.GroupId     
  FROM TCD.Washer Ws
      INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
      INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
      INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
   WHERE Ws.WasherId=@WasherId  

   SELECT DISTINCT      
     @ProgramMasterId=Wps.ProgramId,
     @NominalLoad=Wps.NominalLoad, --Wps.NominalLoad/CONVERT(decimal(10,2), 100) old code
     @MaxLoad =Ws.MaxLoad,
     @ExtraTime =Wps.ExtraTime
  FROM TCD.Washer Ws
      INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
      INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
      INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
      INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
   WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@CurrentFormula and Wps.Is_Deleted=0

  if(@ExtraTime IS NULL)
  BEGIN
   SELECT @ExtraTime      =  0
  END

  SELECT  @MaxWashertGroupCapacity=Max(ws.MaxLoad)
  FROM TCD.Washer WS
   INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
   INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId  
  WHERE Mst.GroupId=@GroupId

  SELECT @WasherMeterExists = M.MachineCompartment FROM Tcd.MachineSetup Ms
  INNER JOIN Tcd.Meter M ON M.GroupId= Ms.GroupId AND  M.MachineCompartment=Ms.MachineInternalId
  WHERE Ms.WasherId=@WasherId

  if(@AutoWeightEntryActive IS NULL)
  BEGIN
   SELECT @AutoWeightEntryActive = 0
  END

  SELECT @StandardWeight=(@NominalLoad * @MaxWashertGroupCapacity) /CONVERT(decimal(10,2), 100)   
  select @AutoWeightEntryActive,@StandardWeight
  SELECT @AutoWeightEntryWeight=Case @AutoWeightEntryActive WHEN 0 THEN @StandardWeight ELSE  @AutoWeightEntryWeight END  
  
  SELECT @CurrentHoldSignalValue=Id  FROM TCD.ConduitParameters where Name='HoldSignal'
  
   SELECT  * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC
  IF(@HoldSignalIsModified !=0)  
  BEGIN
  IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp =@CurrentHoldSignalDate)
   BEGIN
    INSERT INTO TCD.WasherReading(
         WasherId,
         ParameterId,
         ParameterValue,
         DateTimeStamp,
         PartitionOn,
         EcolabWasherId)
    SELECT    @WasherId,
         @CurrentHoldSignalValue,
         @CurrentHoldSignal,
         @CurrentHoldSignalDate,
         (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
         @EcolabWasherId
   END   
  END
  IF(@FormulaIsModified =1  OR @InjectionIsModified = 1 OR @OperationalIsModified = 1)
  BEGIN
   SELECT 'IsModified',@FormulaIsModified AS FormulaIsModified, 
        @InjectionIsModified AS InjectionIsModified,
        @OperationalIsModified AS OperationalIsModified
   IF(@CurrentFormula != 0)
   BEGIN
       DECLARE @BatchShiftId int,@BatchShiftStartDate datetime
       
       SELECT @BatchShiftStartDate = bd.StartDate FROM TCD.BatchData bd WHERE bd.BatchId = @BatchId

       IF(@BatchShiftStartDate > (SELECT TOP 1 [@ShiftStartDate].ShiftStartdate FROM @ShiftStartDate ORDER BY [@ShiftStartDate].ShiftStartdate ASC)
       AND DATEADD(second,@ExtraTime,@CurrentFormulaDate) > (SELECT TOP 1 [@ShiftStartDate].ShiftStartdate FROM @ShiftStartDate ORDER BY [@ShiftStartDate].ShiftStartdate DESC)
       )
       BEGIN 
         
         SELECT TOP 1  @BatchShiftId = ssdt.ShiftId FROM @ShiftStartDate ssdt ORDER BY ssdt.ShiftStartdate DESC
       END
       ELSE
       BEGIN
        SELECT TOP 1  @BatchShiftId = ssdt.ShiftId FROM @ShiftStartDate ssdt ORDER BY ssdt.ShiftStartdate ASC
       END
       

  SELECT DISTINCT      
   @PrevFormulaExtraTime =Wps.ExtraTime
   FROM TCD.Washer Ws
    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
    INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
    INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
    WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@Prveformula and Wps.Is_Deleted=0

  IF(@PrevFormulaExtraTime IS NULL)
  BEGIN
   SELECT @PrevFormulaExtraTime      =  0
  END

     IF(@CurrentFormula = @EndofFormula)
     BEGIN   
     SELECT * FROM #XmlTagsTable
      IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData 
           WHERE 
           BatchId=@BatchId AND 
           MachineId=@WasherId AND 
           EndDate IS NULL 
           ORDER BY StartDate DESC  )
       BEGIN
                                       
        UPDATE TCD.BatchData 
         SET EndDate = DATEADD(second,@PrevFormulaExtraTime,@CurrentFormulaDate),EndDateFormula = @CurrentFormulaDate,ShiftId = @BatchShiftId 
       WHERE  BatchId = @BatchId AND MachineId=@WasherId   
    
    --DECLARE @ShiftMapping1 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
    --INSERT INTO @ShiftMapping1(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate,1, @RedFlagShiftId OUTPUT

    SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
      IF(@PreviousInjectionStep IS NOT NULL)
      BEGIN
       UPDATE TCD.BatchWashStepData SET EndTime=DATEADD(second,@ExtraTime,@CurrentFormulaDate) WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate
      END
                                                                   
       END 
     END 
     ELSE IF((@CurrentFormula != @Prveformula) AND (@BatchID IS NOT NULL))
     BEGIN  
     IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC  )
        BEGIN                          
         UPDATE TCD.BatchData
          SET EndDate = @CurrentFormulaDate,EndDateFormula = @CurrentFormulaDate,ShiftId = @BatchShiftId 
         WHERE  BatchId = @BatchId AND MachineId=@WasherId  
   
     INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,19,1,(SELECT Top 1 ShiftStartdate from @ShiftStartDate) 
     
   --  DECLARE @ShiftMapping2 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
   --INSERT INTO @ShiftMapping2(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate,1, @RedFlagShiftId OUTPUT
    
    SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
     IF(@PreviousInjectionStep IS NOT NULL)
     BEGIN
      UPDATE TCD.BatchWashStepData SET EndTime=@CurrentFormulaDate WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate
     END
       
        END 
      END
     ELSE IF((@CurrentInjection = 0) AND(@OperationalCount = 0) AND (@CurrentFormulaDate != @PreviousFormulaDate))
     BEGIN  
     IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC)
        BEGIN                           
         UPDATE TCD.BatchData
          SET EndDate = @CurrentInjectionDate,ShiftId = @BatchShiftId,EndDateFormula = @CurrentInjectionDate
         WHERE  BatchId = @BatchId AND MachineId=@WasherId  
   
    INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,19,1,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)

   -- DECLARE @ShiftMapping3 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
   --INSERT INTO @ShiftMapping3(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentInjectionDate,1, @RedFlagShiftId OUTPUT
      
   SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
     IF(@PreviousInjectionStep IS NOT NULL)
     BEGIN
      UPDATE TCD.BatchWashStepData SET EndTime=@CurrentInjectionDate WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate
     END

        END 
      END
   
    -- Hold Time
     IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
      BEGIN

      
      SELECT   @HoldTime=SUM(Wr.ParameterValue) FROM TCD. BatchData Bd
      INNER JOIN TCD.WasherReading Wr ON Wr.WasherId=Bd.MachineId
      WHERE Bd.BatchId=@BatchId  AND Wr.DateTimeStamp BETWEEN Bd.StartDate AND  Bd.EndDate and   Wr.ParameterId=9 -- Hold Signal value

      INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,17,@HoldTime,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)


     END
     
     -- CapturingMeter Plc Address EndRedaing 
     IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
      BEGIN
      IF(@WasherMeterExists IS NOT NULL AND @MeterPlcAddress > 0)
      BEGIN
       IF(@MeterPlcAddressIsModified !=0)  
       BEGIN
       IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp =@CurrentFormulaDate)
       BEGIN
        INSERT INTO TCD.WasherReading(
         WasherId,
         ParameterId,
         ParameterValue,
         DateTimeStamp,
         PartitionOn,
         EcolabWasherId)
        SELECT 
         @WasherId,
         14, --MeterPlcAddress for EndSReading
         @MeterPlcAddress,
         @CurrentFormulaDate,
         (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
         @EcolabWasherId
       END

      END
      END
     END
         
     --Start Good or Bad Injection in BatchDataTable
     IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
      BEGIN
        ;WITH CteTempWaherReadingInjections  ( 
        InjectionsCount,BatchId,WasherId,ProgramNumber,Injectons
       ) AS  
       (
        SELECT DISTINCT Wr.ParameterValue,
            BD.BatchId,
            Wr.WasherId,
            Bd.ProgramNumber,
            Wr.ParameterValue FROM TCD. BatchData Bd
        INNER JOIN 
          TCD.WasherReading Wr ON Wr.WasherId   =  Bd.MachineId 
        WHERE    
              Wr.ParameterId    =  10    AND 
              Wr.ParameterValue   <>  0    AND 
              Bd.BatchId     =  @BatchID AND WR.DateTimeStamp BETWEEN BD.StartDate AND BD.EndDate) 
        SELECT @CteTempWaherReadingInjections=COUNT(CTE1.InjectionsCount)
        FROM CteTempWaherReadingInjections CTE1 
        INNER JOIN TCD.BatchData Bd ON Bd.BatchId=CTE1.BatchId
        WHERE Bd.BatchId=@BatchId

        ;WITH CteTempBatchInjections ( 
        InjectionsCount,BatchId,WasherId,ProgramNumber,Injectons
       ) AS  
       (
        SELECT  DISTINCT Wdpm.InjectionNumber,
            Bd.BatchId,
            Wps.ProgramNumber,
            Ws.WasherId,Wdpm.
            InjectionNumber
         FROM TCD.Washer WS
          INNER JOIN 
             TCD.MachineSetup Mst ON 
             Mst.WasherId     =  WS.WasherId
          INNER JOIN 
             TCD.WasherGroup Wg ON 
             Wg.WasherGroupId    =  Mst.GroupId       
          INNER JOIN 
             TCD.WasherProgramSetup Wps ON 
             Wps.WasherGroupId    =  Wg.WasherGroupId
          INNER JOIN 
             TCD.WasherDosingSetup Wds ON 
             Wds.WasherProgramSetupId  =  Wps.WasherProgramSetupId
          INNER JOIN 
             TCD.WasherDosingProductMapping Wdpm ON 
             Wdpm.WasherDosingSetupId  =  Wds.WasherDosingSetupID
          INNER JOIN 
             TCD.ProductdataMapping Pdm ON 
             Pdm.ProductId     =  Wdpm.ProductId
          INNER JOIN 
             TCD.BatchData Bd ON 
             Bd.MachineId     =  Ws.WasherId 
          INNER JOIN 
             TCD.WasherReading Wr ON 
             Wr.WasherId      =  Bd.MachineId
        WHERE 
        
             Wps.ProgramNumber    =  @Prveformula  AND 
             Bd.BatchId      =  @BatchID   AND 
             Ws.WasherId      =  @WasherId    )
        SELECT @CteTempBatchInjections=COUNT(CTE2.InjectionsCount)
        FROM CteTempBatchInjections CTE2 
        INNER JOIN TCD.BatchData Bd ON Bd.BatchId=CTE2.BatchId 
        WHERE Bd.BatchId=@BatchID


        Insert Tcd.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchID,@EcolabWasherId,18,
          CASE WHEN @CteTempBatchInjections = @CteTempWaherReadingInjections THEN 1
            WHEN @CteTempBatchInjections != @CteTempWaherReadingInjections THEN 3 END,
            (SELECT Top 1 ShiftStartdate from @ShiftStartDate) 
                           
    END
     --End Good or Bad Injection in BatchDataTable 
     IF(@OperationalCount = 0 AND @CurrentInjection = 0) AND (@CurrentFormula != @EndofFormula)
     BEGIN 
      IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchData WHERE MachineId=@WasherId AND StartDate =@CurrentFormulaDate)
      BEGIN     
       
	   --Start Rollup for previous completed shift
	   IF(CAST(@CurrentFormulaDate as date) < CAST(GETUTCDATE() as date))
	   BEGIN
		  SELECT TOP 1 @PreviousShiftId=ShiftId FROM TCD.BatchData WHERE MachineId=@WasherId ORDER BY StartDate DESC	   
		  SELECT Top 1 @CurrentShiftId = ShiftId from @ShiftStartDate
		  IF(@CurrentShiftId != @PreviousShiftId)
		  BEGIN
			 EXEC TCD.ProductionShiftDataRollup @PreviousShiftId, @RedFlagShiftId OUTPUT
			 IF(@RedFlagShiftId IS NULL)
			 BEGIN
				SET @RedFlagShiftId = @PreviousShiftId
			 END
		  END
	   END
	   --End Rollup for previous completed shift

       --Start Getting InjectionCount and StepCount
       SELECT 
       @StdInjectionSteps=count(DISTINCT wdpm.WasherDosingSetupId),
       @StdWashSteps= count(DISTINCT wds.WasherDosingSetupId)-count(DISTINCT wdpm.WasherDosingSetupId)
       FROM TCD.WasherDosingProductMapping wdpm
       RIGHT JOIN tcd.WasherDosingSetup wds on wdpm.WasherDosingSetupId=wds.WasherDosingSetupId
       WHERE wds.GroupId=@GroupId AND wds.ProgramNumber=@CurrentFormula
       --End Getting InjectionCount and StepCount
       --Start-----ProgramMasterID logic for PlantChainProgram
        SELECT 
        @PlantProgramId=pm.PlantProgramId,
        @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
        @ChainTextileCategoryId = pm.ChainTextileId,
        @FormulaSegmentId = pm.FormulaSegmentId,
        @EcolabSaturationId = pm.EcolabSaturationId 
        FROM TCD.ProgramMaster pm WHERE pm.ProgramId=@ProgramMasterId AND pm.Is_Deleted=0
        IF(@PlantProgramId <> 0  AND @PlantProgramId IS NOT NULL)
         BEGIN
            --Assign value from plantchainprogram table based on plantprogramId
            SELECT
             @EcolabTextileCategoryId = pcp.EcolabTextileCategoryId,
             @ChainTextileCategoryId = pcp.ChainTextileCategoryId,
             @FormulaSegmentId = pcp.FormulaSegmentId,
             @EcolabSaturationId = pcp.EcolabSaturationId
             FROM tcd.PlantChainProgram pcp
             WHERE pcp.PlantProgramId=@PlantProgramId AND pcp.Is_Deleted=0
         END
       --End-----ProgramMasterID logic for PlantChainProgram

       INSERT INTO TCD.BatchData(
          ControllerBatchId ,
          EcolabWasherId,
          GroupId ,
          MachineInternalId,
          PlantWasherNumber,
          StartDate ,
          EndDate ,
          ProgramNumber,
          ProgramMasterId,
          MachineId,
          ActualWeight,
          StandardWeight,
          CurrencyCode,
          ShiftId,         
          PartitionOn,
          TargetTurnTime,
          StdInjectionSteps,
          StdWashSteps,
          EcolabTextileCategoryId,
          ChainTextileCategoryId,
          FormulaSegmentId,
          EcolabSaturationId,
										PlantProgramId,
										ETechlastDroppedTimeStamp										
          )


         SELECT DISTINCT 0
          ,@EcolabWasherId
          ,@GroupId
          ,@MachineInternalId
          ,Ws.PlantWasherNumber
          ,@CurrentFormulaDate
          ,NULL
          ,@CurrentFormula
          ,@ProgramMasterId
          ,@WasherId
          ,@AutoWeightEntryWeight
          ,@StandardWeight 
          ,@CurrencyCode
          ,(SELECT Top 1 ShiftId from @ShiftStartDate)         
          ,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
          ,@TargetTurnTime
          ,@StdInjectionSteps
          ,@StdWashSteps
          ,@EcolabTextileCategoryId
          ,@ChainTextileCategoryId
          ,@FormulaSegmentId
          ,@EcolabSaturationId
          ,@PlantProgramId           
										,@ETechLastDroppedAt 											

       FROM TCD.Washer Ws
          INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
          INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
          INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
       WHERE Ws.WasherId=@WasherId 
   
       SET @BatchID=SCOPE_IDENTITY() 
         
       INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,38,@StdWashSteps,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)

       --If the received formula is not configured in enVision then create an alarm 
       IF(@ProgramMasterId is NULL)
       BEGIN
       SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant;
       SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.AlarmGroupMsterVsControllerModelType AGMVCMT
       INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
       WHERE AGMVCMT.AlarmCode = 9000
        INSERT INTO [TCD].[AlarmData] 
           (EcoalabAccountNumber,
           AlarmCode,
           BatchId,
           controllerID,
           StartDate,
           GroupId,
           MachineInternalId,
           ProgramId,   
           IsActive,
           EndDate,
           MachineId,
           AlarmGroupMasterId,
		   PartitionOn)
           SELECT
            @ECOLABAccountNumber,
            9000,
            @BatchID,
            @ControllerId,
            @CurrentFormulaDate,
            @GroupId,
            @MachineInternalId,
            @CurrentFormula,
            0,
            @CurrentFormulaDate,
            @WasherId,
            @AlarmGroupMasterId,
			@CurrentFormulaDate
       END

         
         INSERT INTO TCD.BatchCustomerData
         (
         BatchId,
         CustomerId,
         Weight,
         PiecesCount,
         PartitionOn,
         EcolabWasherId
         )
        SELECT Bd.BatchId,  
        --SELECT @BatchID,
         Pc.ID,
         @AutoWeightEntryWeight,
         ROUND(COALESCE((@AutoWeightEntryWeight * Pm.Pieces) / NULLIF(Pm.Weight,0), 0),0),
         (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
         @EcolabWasherId
        
      
       FROM TCD.Washer WS
        INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
        INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId       
        INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
        INNER JOIN TCD.ProgramMaster Pm ON Pm.ProgramId=Wps.ProgramId
        INNER JOIN TCD.PlantCustomer Pc ON Pc.ID=Pm.CustomerId
        INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
       WHERE 
        Ws.WasherId=@WasherId AND 
        Wps.ProgramNumber=@CurrentFormula AND 
        Bd.BatchId=@BatchID  AND 
        Pm.CustomerId != -1 

       IF(@WasherMeterExists IS NOT NULL AND @MeterPlcAddress > 0)
       BEGIN        
        IF(@MeterPlcAddressIsModified !=0)  
        BEGIN
          INSERT INTO TCD.WasherReading(
           WasherId,
           ParameterId,
           ParameterValue,
           DateTimeStamp,
           PartitionOn,
           EcolabWasherId)
          SELECT 
           @WasherId,
           13, --MeterPlcAddress for StartReading
           @MeterPlcAddress,
           @CurrentFormulaDate,
           (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
           @EcolabWasherId
        END
       END 
      END              
     END      
     IF(@BatchID IS NOT NULL)     
     BEGIN
     IF(@CurrentInjection <= 0)
      BEGIN
       SET @CurrentInjectionDate=@CurrentFormulaDate
      END 
      IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp =@CurrentInjectionDate)
      BEGIN      
      INSERT INTO TCD.WasherReading(
          WasherId,
          ParameterId,
          ParameterValue,
          DateTimeStamp,
          PartitionOn,
          EcolabWasherId)
      SELECT   @WasherId,
          CASE TagType 
          WHEN 'Tag_FRM' THEN  5  
          WHEN 'Tag_INJ' THEN  10 
          WHEN 'Tag_OPC' THEN  11 
          END,
          TagValue,          
          @CurrentInjectionDate,
          (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
          @EcolabWasherId
       FROM  #XmlTagsTable 
       WHERE  Tagtype in ('Tag_FRM','Tag_INJ','Tag_OPC')         
     END
     END
    IF(@CurrentInjection > 0)     
     BEGIN
      IF (@RatioDosingEnabled = 1)
       BEGIN
       IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurrentInjectionDate and batchid=@BatchID)
       BEGIN
        INSERT INTO TCD.BatchProductData(BatchId,StepCompartment,ActualQuantity,StandardQuantity,Price,TimeStamp,PartitionOn,EcolabWasherId,ProductId)
        SELECT Bd.BatchId 
        --SELECT @BatchID 
         ,Wds.StepNumber
         ,(((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100)) * (@AutoWeightEntryWeight/@StandardWeight) AS ActualQuantity  
         ,(((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100)) * (@AutoWeightEntryWeight/@StandardWeight) AS StandardQuantity      
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * @MaxWashertGroupCapacity)/CONVERT(decimal(10,2), 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price         
         ,@CurrentInjectionDate
         ,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
         ,@EcolabWasherId
         ,Pdm.ProductID
        FROM TCD.Washer WS
         INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
         INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
         INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
         INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
         INNER JOIN TCD.WasherDosingSetup Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
         INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
         INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Wdpm.ProductId
         INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
        WHERE 
          Ws.WasherId=@WasherId     AND 
          Wps.ProgramNumber=@CurrentFormula  AND 
          Wdpm.InjectionNumber=@CurrentInjection AND
          Bd.BatchId=@BatchID AND
    Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
       END
       END
      ELSE
       BEGIN
       IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurrentInjectionDate and batchid=@BatchID)
       BEGIN
        INSERT INTO TCD.BatchProductData(BatchId,StepCompartment,ActualQuantity,StandardQuantity,Price,TimeStamp,PartitionOn,EcolabWasherId,ProductId)
        SELECT Bd.BatchId  
        --SELECT @BatchID
         ,Wds.StepNumber
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100) AS ActualQuantity  
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100) AS StandardQuantity      
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * @MaxWashertGroupCapacity)/CONVERT(decimal(10,2), 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price         
         ,@CurrentInjectionDate
         ,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
         ,@EcolabWasherId
         ,Pdm.ProductID
        FROM TCD.Washer WS
         INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
         INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
         INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
         INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
         INNER JOIN TCD.WasherDosingSetup Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
         INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
         INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Wdpm.ProductId
         INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
        WHERE 
          Ws.WasherId=@WasherId     AND 
          Wps.ProgramNumber=@CurrentFormula  AND 
          Wdpm.InjectionNumber=@CurrentInjection AND
          Bd.BatchId=@BatchID AND
    Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
       END  
       END 
       
  --Populating BatchWashstepdata
      SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
      
      IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchWashStepData WHERE StartTime =@CurrentInjectionDate and batchid=@BatchID)
      BEGIN
         SELECT @CurrentInjectionStep=Wds.StepNumber,
             @WashStepBatchId=Bd.BatchId
                 
         FROM TCD.Washer WS
          INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
          INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
          INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
          INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
          INNER JOIN TCD.WasherDosingSetup Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
          INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
          INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Wdpm.ProductId
          INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
         WHERE 
          Ws.WasherId=@WasherId     AND 
          Wps.ProgramNumber=@CurrentFormula  AND 
          Wdpm.InjectionNumber=@CurrentInjection AND
          Bd.BatchId=@BatchID AND
          Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0

         IF(@CurrentInjectionStep IS NOT NULL)
         BEGIN
          INSERT INTO TCD.BatchWashStepData(BatchId,StepCompartment,StartTime,PartitionOn,EcolabWasherId)
          VALUES (@WashStepBatchId,  @CurrentInjectionStep, @CurrentInjectionDate, (SELECT Top 1 ShiftStartdate from @ShiftStartDate), @EcolabWasherId)                
         
          UPDATE TCD.BatchWashStepData SET EndTime=@CurrentInjectionDate WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate         
         END

      END
      --End Populating BatchWashstepdata

      --Start Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
      IF NOT EXISTS(SELECT * FROM TCD.BatchParameters WHERE ParameterId =37 and batchid=@BatchID)
      BEGIN
       INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,37,1,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)       
      END
      ELSE
      BEGIN
       Update TCD.BatchParameters SET ParameterValue=@CurrentInjection WHERE ParameterId =37 and batchid=@BatchID
      END
        --End Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
		--Start Updating CustomerCodes in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
		IF(@Customercodes IS NOT NULL)
		BEGIN
			IF NOT EXISTS(SELECT * FROM TCD.BatchParameters WHERE ParameterId =39 and batchid=@BatchID)
			BEGIN
				INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,39,@CustomerCodes,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)							
			END
			ELSE
			BEGIN
				Update TCD.BatchParameters SET ParameterValue=@CustomerCodes WHERE ParameterId =39 and batchid=@BatchID
			END
		END
		----Start Updating CustomerCodes in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
           
     END

     UPDATE TCD.ConduitController
      SET LastConnectedTime  = GETUTCDATE()
      WHERE ControllerId   = @ControllerId
   END
  END
 END
 GO
 
 --SP ProcessTunnelWasherData
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[ProcessTunnelWasherData]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.ProcessTunnelWasherData;
	END; 
GO 

CREATE PROCEDURE [TCD].[ProcessTunnelWasherData]
	(	
	@WasherId INT,	
	@xmlTags XML,
	@RedFlagShiftId INT OUTPUT
)
AS
BEGIN
		DECLARE @BatchID						INT,
				@EcolabWasherId					INT,								
				@CurrencyCode					VARCHAR(50),		
				@MachineInternalId				INT ,
				@GroupId						INT,		
				@Prveformula					INT,
				@Quantity						INT,
				@MaxWashertGroupCapacity		INT,
				@PrevBatchId					INT,
				@PrevLoadId						INT,
				@ExistedLoadId					INT,
				@NumberOfCompartments			INT,

				@ProgramMasterId				INT,
				@NominalLoad					Decimal(10,2),
				@MaxLoad						Decimal(10,2),
				@StandardWeight					Decimal(10,2) , 				
				@PlantWasherNumber				INT,
											
				@CurrentDay						DATE=CAST(GETUTCDATE() as date),
				@TempTunnelTimeStamp			DATETIME2,

				@ControllerId					INT ,
				@CurrentHoldSignal				INT,
				
				@TotalRunTime					INT,
				@BatchGroupId					INT,
				@BatchFormula					INT,
				@BatchStartDate					DATETIME2,
				@BatchEndDate					DATETIME2,
				@HoldTime						INT,
				@CteTempBatchTunnelWashSteps	INT,
				@CteTemTunnelWashSetps			INT,
				@PrevFormula					INT,
				@PrevStepCompartment			INT,
				@BatchStandardWaterUsage		INT,
				@BatchActualWaterUsage			INT,
				@BatchWaterUsagePrice			Decimal(10,2),
				@BatchUtilityPrice				Decimal(10,2),
				@BatchWaterType					INT,
				@ExtraTime						INT,
				@TargetTurnTime					INT,
				@EcolabAccountNumber NVARCHAR(25) = NULL,
				@AlarmGroupMasterId INT,
				@PartitionOn SMALLDATETIME,
				@StdInjectionSteps INT,
				@StdWashSteps INT,
				@EcolabTextileCategoryId INT,
				@ChainTextileCategoryId INT,
				@FormulaSegmentId INT,
				@EcolabSaturationId INT,
				@PlantProgramId INT,
				@PreviousShiftId INT,
				@CurrentShiftId INT,
				@ETechLastDroppedAt  DATETIME2,
				@Customercodes VARCHAR(100);
		SELECT @ExtraTime = 0

		SELECT DISTINCT 					
					@NumberOfCompartments=MST.NumberOfComp,
					@EcolabWasherId=Ws.EcolabWasherId
			FROM		TCD.Washer Ws
			INNER JOIN 
						TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId					
		WHERE Ws.WasherId=@WasherId and Ws.Is_Deleted=0
		
				
		IF EXISTS (SELECT  * FROM TEMPDB.DBO.SYSOBJECTS o where o.xtype in ('U') AND o.id = OBJECT_ID(N'tempdb..#XmlTagsTable'))
			BEGIN
					DROP TABLE #XmlTagsTable
			END
		CREATE TABLE  #XmlTagsTable (	CurrentFormula				INT,
										CurretnInjection			INT,
										CurrentOperationCounter		INT,
										Eof							INT,
										TunnelTimeStamp				DATETIME2,
										OnHold						BIT,										
										CompartmentId				INT, 
										CompartmentLoadId			INT, 
										CompartmentFormulaId		INT,										
										ReceivedTime				DATETIME2,
										AutoWeightEntryActive		VARCHAR(10),
										AutoWeightEntryWeight		INT,
										IsFormulaModified			BIT,
										IsHoldSignalModified		BIT	,
										IsStopSinalModified			BIT,
										StopSignal					INT,
										RatioDosingEnabled			INT,
										ETechLastDropped			VARCHAR(100),
										CustomerCodes VARCHAR(100)
									)
		INSERT INTO #XmlTagsTable	(
										CurrentFormula	,
										CurretnInjection,										
										CurrentOperationCounter,
										Eof,
										TunnelTimeStamp	,
										OnHold,
										CompartmentId, 
										CompartmentLoadId, 
										CompartmentFormulaId,
										ReceivedTime,
										AutoWeightEntryActive,
										AutoWeightEntryWeight,
										IsFormulaModified,
										IsHoldSignalModified,
										IsStopSinalModified,
										StopSignal,
										RatioDosingEnabled,
										ETechLastDropped,
										CustomerCodes
									)			
		
		-- Populate tempdata from xml
		SELECT	T.c.value('../@CurrentFormula', 'INT') AS CurrentFormula, 
				T.c.value('../@CurrentInjection', 'INT') AS CurretnInjection, 				
				T.c.value('../@CurrentOperationCounter', 'INT') AS CurrentOperationCounter, 						
				T.c.value('../@Eof', 'INT') AS EndofFormula, 
				T.c.value('../@TimeStamp', 'VARCHAR(100)') AS TunnelTimeStamp, 
				T.c.value('../@OnHold', 'VARCHAR(100)') AS OnHold, 
				T.c.value('@CompartmentId', 'INT') AS CompartmentId, 
				T.c.value('@LoadId', 'INT') AS CompartmentLoadId, 
				T.c.value('@FormulaId', 'INT') AS CompartmentFormulaId, 				
				T.c.value('@TimeStamp', 'VARCHAR(100)') DateTimeStamp,
				T.c.value('../@Awea', 'VARCHAR(10)') AS AutoWeightEntryActive, 				
				T.c.value('../@Awew', 'INT') AS AutoWeightEntryWeight,	
				T.c.value('../@IsFormulaModified', 'BIT') AS IsFormulaModified,
				T.c.value('../@IsHoldSignalModified', 'BIT') AS IsHoldSignalModified,
				T.c.value('../@IsStopSinalModified', 'BIT') AS IsStopSinalModified,
				T.c.value('../@StopSignal', 'INT') AS StopSignal,
				T.c.value('../@RATA', 'INT') AS RatioDosingEnabled,
				T.c.value('../@ETechLastDroppedAt', 'VARCHAR(100)') AS ETechLastDropped,
				T.c.value('../@CustomerCodes', 'VARCHAR(100)')AS CustomerCodes
				
				
		
		FROM @xmlTags.nodes('/Tunnel/Compartment')  T(c)

		
		WHERE	
		T.c.value('@LoadId', 'VARCHAR(100)')  != 0
		AND
		T.c.value('@CompartmentId', 'INT')    <= @NumberOfCompartments
		 --ETech last dropped 
		SELECT @ETechLastDroppedAt=CONVERT(datetime,ETechLastDropped), @Customercodes = CustomerCodes from #XmlTagsTable
		
		IF EXISTS (SELECT 1 FROM #XmlTagsTable where IsHoldSignalModified = 1)	 
			BEGIN			
				SELECT	@CurrentHoldSignal = Id  FROM TCD.ConduitParameters where Name='HoldSignal'
				INSERT INTO TCD.WasherReading(
								WasherId,
								ParameterId,
								ParameterValue,
								DateTimeStamp,
								EcolabWasherId)
					SELECT		@WasherId,
								@CurrentHoldSignal,
								OnHold,
								ReceivedTime,
								@EcolabWasherId	
					FROM #XmlTagsTable
			END	
		IF EXISTS (SELECT 1 FROM #XmlTagsTable where IsStopSinalModified = 1)	 
			BEGIN	
				INSERT INTO TCD.WasherReading(
							WasherId,
							ParameterId,
							ParameterValue,
							DateTimeStamp,
							EcolabWasherId)
				SELECT		@WasherId,
							12,
							StopSignal,
							ReceivedTime,
							@EcolabWasherId
				FROM #XmlTagsTable
			END	
		IF EXISTS (SELECT 1 FROM #XmlTagsTable where IsFormulaModified = 1)	 
			BEGIN
		
			-- Start find missing load id form xml  and set end date for corresponding enddates in the database
			DECLARE @TempExisitingLoadIds table(ExstingLoadId INT,ExistsBatchId int)
			INSERT INTO @TempExisitingLoadIds(ExstingLoadId,ExistsBatchId)
				SELECT Bd.ControllerBatchId,Bd.BatchId FROM TCD.BatchData Bd					
					--INNER JOIN TCD.BatchWashStepData Bwsd on Bwsd.BatchId=Bd.BatchId
				WHERE Bd.MachineId=@WasherId AND Bd.EndDate IS NULL ORDER BY Bd.StartDate DESC			
		
			SELECT @TempTunnelTimeStamp =(SELECT T.c.value('./@TimeStamp', 'VARCHAR(100)') AS TunnelTimeStamp	FROM @xmlTags.nodes('/Tunnel')  T(c))
			
			DECLARE @TempBatchStepIs TABLE(StepBatchId INT)
			INSERT INTO @TempBatchStepIs (StepBatchId)
			SELECT ExistsBatchId 
				FROM @TempExisitingLoadIds 
				WHERE ExstingLoadId NOT IN (SELECT CompartmentLoadId FROM #XmlTagsTable)
		
		SELECT @PrevStepCompartment=StepCompartment,@PrevBatchId =BatchID 
		FROM TCD.BatchWashStepData  
		WHERE BatchId in (select StepBatchId from @TempBatchStepIs) AND EndTime IS NULL

		UPDATE 
		TCD.BatchWashStepData 
		SET EndTime = @TempTunnelTimeStamp
		WHERE BatchId in (select StepBatchId from @TempBatchStepIs) AND EndTime IS NULL

		DECLARE @BatchShiftId int
		DECLARE @ShiftStartDateTemp table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
		INSERT INTO @ShiftStartDateTemp(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @TempTunnelTimeStamp
		SELECT @BatchShiftId = ssdt.ShiftId FROM @ShiftStartDateTemp ssdt ORDER BY ssdt.ShiftStartdate

		-- Updating Batches moved out of the tunnel
		UPDATE TCD.BatchData 
		SET		
				EndDate=@TempTunnelTimeStamp
			,	EndDateFormula=@TempTunnelTimeStamp,
			ShiftId = @BatchShiftId
		WHERE BatchId in (select StepBatchId from @TempBatchStepIs)

		--End find missing load id form xml  and set end date for corresponding enddates in the database
		 
		--Start HoldTime Calculation
			SELECT 
					@BatchGroupId=GroupId
				,	@BatchFormula=ProgramNumber
				,	@BatchStartDate=StartDate
				,	@BatchEndDate=EndDate 
			FROM TCD.BatchData 
			WHERE BatchId IN (select		StepBatchId from @TempBatchStepIs)

			SELECT @TotalRunTime=TotalRunTime 
			FROM TCD.TunnelProgramSetup 
			WHERE	WasherGroupId =@BatchGroupId 
				AND ProgramNumber=@BatchFormula

			
			INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) 
			SELECT StepBatchId,@EcolabWasherId,17,(DATEDIFF(SECOND, @BatchStartDate, @BatchEndDate))-@TotalRunTime,bd.partitionon
            FROM @TempBatchStepIs,TCD.BatchData bd WHERE bd.BatchId= [@TempBatchStepIs].StepBatchId  and [@TempBatchStepIs].StepBatchId NOT IN (SELECT BATCHID FROM TCD.BatchParameters AS BP WHERE BP.ParameterId = 17)
 
		--End HoldTime Calculation

			 --Start Good or Bad Injection in BatchDataTable
					IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@PrevBatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
						BEGIN
					
							;WITH CteTempBatchTunnelStepData  (	
								InjectionsCount,BatchId,ProgramNumber
							) AS  
							(
								SELECT DISTINCT Bws.StepCompartment,
												BD.BatchId,												
												Bd.ProgramNumber
												FROM TCD. BatchData Bd
								INNER JOIN 
										TCD.BatchWashStepData Bws 
															ON Bws.BatchId			=		Bd.BatchId 
								WHERE    
														
														Bd.BatchId					=		@PrevBatchId ) 
								SELECT @CteTemTunnelWashSetps=COUNT(CTE1.InjectionsCount)
								FROM CteTempBatchTunnelStepData CTE1 
								INNER JOIN TCD.BatchData Bd ON Bd.BatchId=CTE1.BatchId
								WHERE Bd.BatchId=@BatchId

								;WITH CteTempBatchInjections (	
								InjectionsCount,ProgramNumber
							) AS  
							(
								SELECT  DISTINCT 
												
												Tds.CompartmentNumber,
												Tps.ProgramNumber
									 	FROM TCD.TunnelProgramSetup Tps 
										INNER JOIN 
													TCD.TunnelDosingSetup Tds ON 
														Tds.TunnelProgramSetupId	=		Tps.TunnelProgramSetupId
										INNER JOIN 
													TCD.TunnelDosingProductMapping Tdpm ON 
													Tdpm.TunnelDosingSetupId		=		Tds.TunnelDosingSetupId
										INNER JOIN 
													TCD.ControllerEquipmentSetup Ces ON 
													Ces.ControllerEquipmentSetupId	=		Tdpm.ControllerEquipmentSetupId
													WHERE 																		 								
													Tps.ProgramNumber				=		@PrevFormula )
								SELECT @CteTempBatchTunnelWashSteps=COUNT(CTE2.InjectionsCount)
								FROM CteTempBatchInjections CTE2 

										Insert Tcd.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @PrevBatchId,@EcolabWasherId,18,
										CASE	WHEN @CteTempBatchTunnelWashSteps	=	@CteTemTunnelWashSetps THEN 1
												WHEN @CteTempBatchTunnelWashSteps	!=	@CteTemTunnelWashSetps THEN 3 END,
												(SELECT PartitionOn FROM TCD.BatchData where BatchId=@PrevBatchId and MachineId=@WasherId)
														
														
																
				END

			-- End Good or Bad Injection in BatchDataTable


	-- Fetching data from cursor
			DECLARE @MYCURSOR CURSOR
			SET @MYCURSOR = CURSOR FAST_FORWARD
			FOR
			SELECT		CurrentFormula	,
						CurretnInjection,										
						CurrentOperationCounter,
						Eof,
						TunnelTimeStamp	,
						OnHold,
						CompartmentId, 
						CompartmentLoadId, 
						CompartmentFormulaId,
						ReceivedTime,
						AutoWeightEntryActive,
						AutoWeightEntryWeight,
						IsFormulaModified,
						IsHoldSignalModified,
						IsStopSinalModified,
						StopSignal,
						RatioDosingEnabled

				FROM #XmlTagsTable ORDER BY CompartmentId ASC
			DECLARE			@CurCurrentFormula					INT,
							@CurCurretnInjection			INT,
							@CurCurrentOperationCounter		INT,
							@CurEof							INT,
							@CurTunnelTimeStamp				DATETIME2,
							@CurOnHold						BIT,
							@CurCompartmentId				INT, 
							@CurCompartmentLoadId			INT, 
							@CurCompartmentFormulaId		INT,
							@CurReceivedTime				DATETIME2,
							@AutoWeightEntryActive			VARCHAR(10),
							@AutoWeightEntryWeight			INT,
							@IsFormulaModified				BIT,
							@IsHoldSignalModified			BIT,
							@IsStopSinalModified			BIT,
							@StopSignal						INT,
							@RatioDosingEnabled				INT	

			OPEN @MYCURSOR
			FETCH NEXT FROM @MYCURSOR
							INTO @CurCurrentFormula			,
							@CurCurretnInjection			,
							@CurCurrentOperationCounter		,
							@CurEof							,
							@CurTunnelTimeStamp				,
							@CurOnHold						,
							@CurCompartmentId				, 
							@CurCompartmentLoadId			, 
							@CurCompartmentFormulaId		,
							@CurReceivedTime				,
							@AutoWeightEntryActive			,
							@AutoWeightEntryWeight			,
							@IsFormulaModified				,
							@IsHoldSignalModified			,
							@IsStopSinalModified			,
							@StopSignal						,
							@RatioDosingEnabled
			WHILE @@FETCH_STATUS = 0
			BEGIN
				

			IF(@IsFormulaModified !=0)	
			BEGIN
				IF(@CurCurrentFormula != @CurEof and @CurCurretnInjection = 0 and @CurCurrentOperationCounter = 0)
					BEGIN

			SELECT DISTINCT 							
							@MachineInternalId			=	Mst.MachineInternalId,
							@GroupId					=	Mst.GroupId,
							@ControllerId				=	Ctrl.ControllerId				
					FROM TCD.Washer Ws
						INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
						INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
						INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
						INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId	=	Mst.ControllerId
					WHERE Ws.WasherId=@WasherId 	

				SELECT DISTINCT 
							@ProgramMasterId			=	Wps.ProgramId,
							@NominalLoad				=	Wps.NominalLoad,
							@MaxLoad					=	Ws.MaxLoad,
							@CurrencyCode				=	Pl.CurrencyCode, 
							@TargetTurnTime				=   (3600/(Wps.TotalRunTime/Mst.NumberofComp))

				FROM TCD.Washer Ws
						INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
						INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
						INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
						INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
						INNER JOIN TCD.Plant Pl ON Pl.EcolabAccountNumber	=		Ws.EcoLabAccountNumber
						
				WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@CurCurrentFormula and Wps.Is_Deleted=0

				select @PlantWasherNumber = plantwashernumber from tcd.washer where washerid = @WasherId
	
				SELECT  @MaxWashertGroupCapacity		=	Max(ws.MaxLoad)
				FROM TCD.Washer WS
					INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
					INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId		
				WHERE Mst.GroupId=@GroupId

				SELECT @StandardWeight					=	@NominalLoad  								
				SELECT @AutoWeightEntryWeight=Case @AutoWeightEntryActive WHEN 'False' THEN @StandardWeight ELSE  @AutoWeightEntryWeight END 
				
						
				SELECT @MachineInternalId,@GroupId,@ProgramMasterId,@NominalLoad,@WasherId,@CurCurrentFormula,@PrevBatchId
				SELECT @CurCurrentFormula				AS CurCurrentFormula			,
							@CurCurretnInjection		AS CurCurretnInjection		,
							@CurCurrentOperationCounter	AS CurCurrentOperationCounter	,
							@CurEof						AS CurEof 		,
							@CurTunnelTimeStamp			AS CurTunnelTimeStamp		,
							@CurOnHold					AS CurOnHold			,
							@CurCompartmentId			AS CurCompartmentId			, 
							@CurCompartmentLoadId		AS CurCompartmentLoadId 		, 
							@CurCompartmentFormulaId	AS CurCompartmentFormulaId		,
							@CurReceivedTime			AS CurReceivedTime,
							@AutoWeightEntryActive		AS AutoWeightEntryActive,
							@AutoWeightEntryWeight		AS AutoWeightEntryWeight,
							@IsFormulaModified			AS IsFormulaModified
		
		IF(@CurCompartmentFormulaId > 0)
		BEGIN
					UPDATE TCD.ConduitController
					SET LastConnectedTime		=	GETUTCDATE()
					WHERE ControllerId			=	@ControllerId
		END
		
		
		IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchData WHERE MachineId=@WasherId AND StartDate =@CurTunnelTimeStamp)
		BEGIN

			DECLARE @ShiftStartDate table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
			INSERT INTO @ShiftStartDate(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurTunnelTimeStamp


			 --Start Rollup for previous completed shift
			   IF(CAST(@CurTunnelTimeStamp as date) < CAST(GETUTCDATE() as date))
			   BEGIN
				  SELECT TOP 1 @PreviousShiftId=ShiftId FROM TCD.BatchData WHERE MachineId=@WasherId ORDER BY StartDate DESC	   
				  SELECT Top 1 @CurrentShiftId = ShiftId from @ShiftStartDate
				  IF(@CurrentShiftId != @PreviousShiftId)
				  BEGIN
					 EXEC TCD.ProductionShiftDataRollup @PreviousShiftId, @RedFlagShiftId OUTPUT
					 IF(@RedFlagShiftId IS NULL)
					 BEGIN
						SET @RedFlagShiftId = @PreviousShiftId
					 END
				  END
			   END
			   --End Rollup for previous completed shift

				--Start Getting InjectionCount,StepCount And ProductCount
					SELECT @StdInjectionSteps= count(tdpm.TunnelDosingSetupId) ,
					@StdWashSteps= count(DISTINCT tds.TunnelDosingSetupId)-count(tdpm.TunnelDosingSetupId) 
					FROM TCD.TunnelDosingProductMapping tdpm
					RIGHT JOIN tcd.TunnelDosingSetup tds on tdpm.TunnelDosingSetupId=tds.TunnelDosingSetupId
					WHERE tds.GroupId=@GroupId AND tds.ProgramNumber=@CurCurrentFormula
			    --Start-----ProgramMasterID logic for PlantChainProgram
					SELECT 
					@PlantProgramId=pm.PlantProgramId,
					@EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
					@ChainTextileCategoryId = pm.ChainTextileId,
					@FormulaSegmentId = pm.FormulaSegmentId,
					@EcolabSaturationId = pm.EcolabSaturationId 
					FROM TCD.ProgramMaster pm WHERE pm.ProgramId=@ProgramMasterId AND pm.Is_Deleted=0
					IF(@PlantProgramId <> 0  AND @PlantProgramId IS NOT NULL)
						BEGIN
							--Assign value from plantchainprogram table based on plantprogramId
							SELECT
								@EcolabTextileCategoryId = pcp.EcolabTextileCategoryId,
								@ChainTextileCategoryId = pcp.ChainTextileCategoryId,
								@FormulaSegmentId = pcp.FormulaSegmentId,
								@EcolabSaturationId = pcp.EcolabSaturationId
								FROM tcd.PlantChainProgram pcp
								WHERE pcp.PlantProgramId=@PlantProgramId AND pcp.Is_Deleted=0
						END
				--End-----ProgramMasterID logic for PlantChainProgram
				-- New Batch Creation
							INSERT INTO TCD.BatchData(
											ControllerBatchId ,
											EcolabWasherId,
											GroupId ,
											MachineInternalId,
											PlantWasherNumber,
											StartDate ,
											EndDate ,
											ProgramNumber,
											ProgramMasterId,
											MachineId,
											ActualWeight,
											StandardWeight,
											CurrencyCode,
											ShiftId,
											PartitionOn,
											TargetTurnTime,
											StdInjectionSteps,
											StdWashSteps,
											EcolabTextileCategoryId,
											ChainTextileCategoryId,
											FormulaSegmentId,
											EcolabSaturationId,
											PlantProgramId,
											ETechlastDroppedTimeStamp
											)


										SELECT DISTINCT @CurCompartmentLoadId
											,@EcolabWasherId
											,@GroupId
											,@MachineInternalId
											,@PlantWasherNumber
											--,@CurReceivedTime
											,@CurTunnelTimeStamp
											,NULL
											,@CurCurrentFormula
											,@ProgramMasterId
											,@WasherId
											,@AutoWeightEntryWeight
											,@StandardWeight 
											,@CurrencyCode
											,(SELECT Top 1 ShiftId from @ShiftStartDate)
											,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
											,@TargetTurnTime
											,@StdInjectionSteps
											,@StdWashSteps
											,@EcolabTextileCategoryId
											,@ChainTextileCategoryId
											,@FormulaSegmentId
											,@EcolabSaturationId
											,@PlantProgramId	
											,@ETechLastDroppedAt	
								
			
								SET @BatchID=SCOPE_IDENTITY()	

								--Start insert InjectionActualCount and StepActualCount in TCD.BatchParameters
								INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchID,@EcolabWasherId,37,@StdInjectionSteps,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
								INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchID,@EcolabWasherId,38,@StdWashSteps,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)  
								--End insert InjectionActualCount and StepActualCount in TCD.BatchParameters

								--Start Customer Codes coming from ETech in TCD.BatchParameters
								IF(@Customercodes IS NOT NULL)
								BEGIN
									INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchID,@EcolabWasherId,39,@CustomerCodes,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
								END
								--End Customer Codes coming from ETech in TCD.BatchParameters

								--If the received formula is not configured in enVision then create an alarm 
							IF(@ProgramMasterId is NULL)
							BEGIN
							SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant
							SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.AlarmGroupMsterVsControllerModelType AGMVCMT
							INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
							WHERE AGMVCMT.AlarmCode = 9000
								INSERT INTO [TCD].[AlarmData] 
								   (EcoalabAccountNumber,
								   AlarmCode,
								   BatchId,
								   controllerID,
								   StartDate,
								   GroupId,
								   MachineInternalId,
								   ProgramId,   
								   IsActive,
								   EndDate,
								   MachineId,
								   AlarmGroupMasterId,
								   PartitionOn)
									  SELECT
									   @ECOLABAccountNumber,
									   9000,
									   @BatchID,
									   @ControllerId,
									   @CurTunnelTimeStamp,
									   @GroupId,
									   @MachineInternalId,
									   @CurCurrentFormula,
									   0,
									   @CurTunnelTimeStamp,
									   @WasherId,
									   @AlarmGroupMasterId,
									   @CurTunnelTimeStamp
							END


						-- Wash Step Information		
						INSERT INTO TCD.BatchWashStepData(
											BatchId
											,StepCompartment
											,StartTime
											,EndTime
											,PartitionOn
											,EcolabWasherId) 				
						SELECT	
											@BatchID,
											@CurCompartmentId,
											@CurTunnelTimeStamp,
											--@CurReceivedTime,
											NULL,
											(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
											@EcolabWasherId
						-- Product Usage
				IF (@RatioDosingEnabled = 1)
					BEGIN
						INSERT INTO TCD.BatchProductData(
									BatchId,
									StepCompartment,
									ActualQuantity,
									StandardQuantity,
									Price,
									[TimeStamp],
									PartitionOn,
									EcolabWasherId,
									ProductId
						)					
						SELECT DISTINCT @BatchID	
										,@CurCompartmentId
										,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * (@AutoWeightEntryWeight/@StandardWeight) AS ActualQuantity						
										,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * (@AutoWeightEntryWeight/@StandardWeight) AS StandardQuantity										
										,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price	
										,@CurTunnelTimeStamp								
										--,@CurReceivedTime
										,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
										,@EcolabWasherId
										,Pdm.ProductID
							FROM TCD.Washer WS
							INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
							INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
							INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
							INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
							INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
							INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
							INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId=Wdpm.ControllerEquipmentSetupId
							INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Ces.ProductId
							--INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
						WHERE 
								Ws.WasherId=@WasherId AND 
								Wps.ProgramNumber=@CurCurrentFormula AND 
								Wds.CompartmentNumber=@CurCompartmentId	AND
								Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
					END
				ELSE
					BEGIN
						INSERT INTO TCD.BatchProductData(
									BatchId,
									StepCompartment,
									ActualQuantity,
									StandardQuantity,
									Price,
									[TimeStamp],
									PartitionOn,
									EcolabWasherId,
									ProductId
						)					
						SELECT DISTINCT @BatchID	
										,@CurCompartmentId
										,((Wps.NominalLoad * Wdpm.Quantity)/ 100) AS ActualQuantity						
										,((Wps.NominalLoad * Wdpm.Quantity)/ 100) AS StandardQuantity										
										,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price
										,@CurTunnelTimeStamp									
										--,@CurReceivedTime
										,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
										,@EcolabWasherId
										,Pdm.ProductID
							FROM TCD.Washer WS
							INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
							INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
							INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
							INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
							INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
							INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
							INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId=Wdpm.ControllerEquipmentSetupId
							INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Ces.ProductId
							--INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
						WHERE 
								Ws.WasherId=@WasherId AND 
								Wps.ProgramNumber=@CurCurrentFormula AND 
								Wds.CompartmentNumber=@CurCompartmentId	AND
								Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
					END			
								
								
						-- Transfer Signal		
								INSERT INTO TCD.WasherReading(
															WasherId,
															ParameterId,
															ParameterValue,
															DateTimeStamp,
															PartitionOn,
															EcolabWasherId)
									SELECT @WasherId,
											6,
											1,
											@TempTunnelTimeStamp,
											(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
											@EcolabWasherId
									UNION ALL
									SELECT @WasherId,
											6,
											0,
											GETUTCDATE(),
											(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
											@EcolabWasherId
			
						-- Insert Customer Data
						INSERT INTO TCD.BatchCustomerData(
										BatchId,
										CustomerId,
										Weight,
										PiecesCount,
										PartitionOn,
										EcolabWasherId
										)
						SELECT DISTINCT	
										Bd.BatchId,		
										Pc.ID,
										@AutoWeightEntryWeight,
										ROUND(COALESCE((@AutoWeightEntryWeight * Pm.Pieces) / NULLIF(Pm.Weight,0), 0),0),
										(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
										@EcolabWasherId
						
						FROM TCD.Washer WS
							INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
							INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId							
							INNER JOIN TCD.TunnelProgramSetup Tps ON Tps.WasherGroupId = Wg.WasherGroupId
							INNER JOIN TCD.ProgramMaster Pm ON Pm.ProgramId=Tps.ProgramId
							INNER JOIN TCD.PlantCustomer Pc ON Pc.ID=Pm.CustomerId
							INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
						WHERE 
							Ws.WasherId=@WasherId AND 
							Tps.ProgramNumber=@CurCompartmentFormulaId AND 
							Bd.BatchId=@BatchID	  AND 
							Pm.CustomerId != -1
							AND Pm.[Weight] > 0
		END

		ELSE
		BEGIN
			SELECT @BatchID=BatchId, @PartitionOn=PartitionOn
			FROM TCD.BatchData 
			WHERE MachineId=@WasherId 
			AND ControllerBatchId=@CurCompartmentLoadId
			
			IF(@BatchID IS NOT NULL)
			BEGIN
			UPDATE TCD.BatchWashStepData 
				SET EndTime=@CurTunnelTimeStamp
			WHERE BatchId=@BatchId 
				AND StepCompartment=@CurCompartmentId-1

				IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchWashStepData WHERE StartTime=@CurTunnelTimeStamp and BatchId=@BatchID)
				BEGIN
					INSERT INTO TCD.BatchWashStepData(
											BatchId
											,StepCompartment
											,StartTime
											,EndTime
											,PartitionOn
											,EcolabWasherId) 				
						SELECT	
											@BatchID,
											@CurCompartmentId,
											@CurTunnelTimeStamp,
											--@CurReceivedTime,
											NULL,
											@PartitionOn,
											@EcolabWasherId
				END							
				IF (@RatioDosingEnabled = 1)
					BEGIN
					IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurTunnelTimeStamp and BatchId=@BatchID)
					BEGIN
						INSERT INTO TCD.BatchProductData(
									BatchId,
									StepCompartment,
									ActualQuantity,
									StandardQuantity,
									Price,
									[TimeStamp],
									PartitionOn,
									EcolabWasherId,
									ProductId
									)
						SELECT DISTINCT 
									@BatchID	
									,@CurCompartmentId
									,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * (@AutoWeightEntryWeight/@StandardWeight) AS ActualQuantity							
									,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * (@AutoWeightEntryWeight/@StandardWeight) AS StandardQuantity	
									,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price
									,@CurTunnelTimeStamp									
									--,@CurReceivedTime
									,@PartitionOn
									,@EcolabWasherId
									,Pdm.ProductID
						FROM TCD.Washer WS
						INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
						INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
						INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
						INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
						INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
						INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
						INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId=Wdpm.ControllerEquipmentSetupId
						INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Ces.ProductId
						--INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
						WHERE 
							Ws.WasherId=@WasherId 
							AND Wps.ProgramNumber=@CurCompartmentFormulaId 
							AND Wds.CompartmentNumber=@CurCompartmentId	AND
							Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
					END
				END -- end of ratio dosing if
				ELSE
					BEGIN
					IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurTunnelTimeStamp and BatchId=@BatchID)
					BEGIN
					INSERT INTO TCD.BatchProductData(
									BatchId,
									StepCompartment,
									ActualQuantity,
									StandardQuantity,
									Price,
									[TimeStamp],
									PartitionOn,
									EcolabWasherId,
									ProductId
									)
					SELECT DISTINCT 
									@BatchID	
									,@CurCompartmentId
									,((Wps.NominalLoad * Wdpm.Quantity)/ 100) AS ActualQuantity							
									,((Wps.NominalLoad * Wdpm.Quantity)/ 100) AS StandardQuantity	
									,((Wps.NominalLoad * Wdpm.Quantity)/ 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price
									,@CurTunnelTimeStamp									
									--,@CurReceivedTime
									,@PartitionOn
									,@EcolabWasherId
									,Pdm.ProductID
						FROM TCD.Washer WS
						INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
						INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
						INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
						INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
						INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
						INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
						INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId=Wdpm.ControllerEquipmentSetupId
						INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Ces.ProductId
								
					WHERE 
							Ws.WasherId=@WasherId 
							AND Wps.ProgramNumber=@CurCompartmentFormulaId 
							AND Wds.CompartmentNumber=@CurCompartmentId	AND
								Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0	
			END
			END								
				END -- end of BatchId NULL if
			END -- end of else
		END		-- end of IF(@CurCurrentFormula != @CurEof and @CurCurretnInjection = 0 and @CurCurrentOperationCounter = 0)							
	END		-- end of IF(@IsFormulaModified !=0)	
															
			FETCH NEXT FROM @MYCURSOR
			INTO @CurCurrentFormula			,
							@CurCurretnInjection			,
							@CurCurrentOperationCounter		,
							@CurEof							,
							@CurTunnelTimeStamp				,
							@CurOnHold						,
							@CurCompartmentId				, 
							@CurCompartmentLoadId			, 
							@CurCompartmentFormulaId		,
							@CurReceivedTime				,
							@AutoWeightEntryActive			,
							@AutoWeightEntryWeight			,
							@IsFormulaModified				,
							@IsHoldSignalModified			,
							@IsStopSinalModified			,
							@StopSignal						,
							@RatioDosingEnabled
			END
			CLOSE @MYCURSOR
			DEALLOCATE @MYCURSOR	
			
		
		END
END
GO
--End ETechConfigSettings
---------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[SaveTunnelCompartmentEquipmentValveMapping_XL]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[SaveTunnelCompartmentEquipmentValveMapping_XL]
END
GO

CREATE PROC [TCD].[SaveTunnelCompartmentEquipmentValveMapping_XL] (    
  @ValveCompartmentMappings TCD.TunnelCompartmentEquipmentValveMapping READONLY    
    , @ControllerEquipmentId INT    
    , @ControllerId INT      
    , @EcolabAccountNumber NVARCHAR(25)    
    , @UserId INT    
)    
AS    
BEGIN    
    DECLARE    
     @EquipmentSetupId INT = (SELECT TOP 1 CES.ControllerEquipmentSetupId    
        FROM TCD.ControllerEquipmentSetup CES    
        WHERE CES.ControllerId = @ControllerId    
          AND CES.ControllerEquipmentId = @ControllerEquipmentId ),    
     @PlantId INT = (SELECT TOP 1 PlantId    
  FROM TCD.Plant P    
       WHERE P.EcolabAccountNumber = @EcolabAccountNumber),  
     @DDFlag BIT = CAST(    
     CASE    
     WHEN EXISTS(SELECT 1    
       FROM @ValveCompartmentMappings M    
       WHERE M.DirectDosingFlag = 1) THEN 1    
     ELSE 0    
     END    
     AS BIT);    
    
    /* Delete the values if not necessary */    
    
    IF @DDFlag = 'TRUE'    
    BEGIN    
    DELETE FROM TCD.TunnelCompartmentEquipmentValveMapping    
      WHERE ControllerEquipmentSetupID = @EquipmentSetupId    
    AND DirectDosingFlag = 'FALSE';    
    END;    
    ELSE    
    BEGIN    
    DELETE T    
      FROM TCD.TunnelCompartmentEquipmentValveMapping T    
      WHERE ControllerEquipmentSetupID = @EquipmentSetupId    
    AND T.PlantID = @PlantId    
    AND T.TunnelCompartmentEquipmentValveMappingID NOT IN(    
    SELECT TCEVM.TunnelCompartmentEquipmentValveMappingID    
      FROM TCD.TunnelCompartmentEquipmentValveMapping TCEVM    
       INNER JOIN    
       @ValveCompartmentMappings M ON TCEVM.TunnelNumber = M.TunnelNumber    
             AND TCEVM.DosingPointNumber = M.DosingPointNumber  
			 AND TCEVM.ValveNumber = M.ValveNumber    
             AND TCEVM.ControllerEquipmentSetupID = @EquipmentSetupId    
             AND TCEVM.PlantID = @PlantId);    
    END;   
       
    DECLARE    
     @TempMapping TABLE(    
     RowNumber INT NOT NULL    
   , ControllerEquipmentId TINYINT NOT NULL    
   , TunnelNumber INT NOT NULL    
   , CompartmentNumber TINYINT NOT NULL    
   , DosingPointNumber TINYINT NOT NULL    
   , DirectDosingFlag BIT NOT NULL  
   , ValveNumber TINYINT NOT NULL
   , WasherNumber int NOT NULL);    
    
    /* Create RowNumber inorder to increment and use row by row. */    
    
    WITH CTE_LCM    
    AS (    
    SELECT ROW_NUMBER() OVER (ORDER BY LCM.TunnelNumber, LCM.DosingPointNumber) AS RowNumber    
     , LCM.ControllerEquipmentId  
     , LCM.TunnelNumber  
     , LCM.CompartmentNumber  
     , LCM.DosingPointNumber  
     , LCM.DirectDosingFlag  
     , LCM.ValveNumber  
	 , LCM.WasherNumber
  FROM @ValveCompartmentMappings LCM    
    )    
    INSERT INTO @TempMapping    
    SELECT *    
  FROM CTE_LCM CL;    
    
    /* Loop */    
    
    DECLARE    
     @i INT = 1,    
     @max INT = (SELECT MAX(TM.RowNumber)    
       FROM @TempMapping TM);    
    WHILE @i <= @max    
    BEGIN    
    
    /* Declare and Initialize the current row data */    
    
    DECLARE    
     @TunnelNumber INT,    
     @CompartmentNumber TINYINT,    
     --@DosingpointNumber TINYINT,   
     @ValveNumber TINYINT;  
    SELECT TOP 1 @TunnelNumber = TM.TunnelNumber    
       --, @DosingPointNumber = TM.DosingpointNumber    
       , @CompartmentNumber = TM.CompartmentNumber    
       , @ValveNumber       = TM.ValveNumber  
      FROM @TempMapping TM    
      WHERE TM.RowNumber = @i;    
    --DECLARE    
    -- @ValveNumber INT = 0;    
    --IF @DDFlag = 'FALSE'    
    --BEGIN    
    
    --/* Get Min Available Valve Number */    
    
    --SELECT @ValveNumber = MIN(CEV.ControllerEquipmentValveID)    
    --  FROM TCD.ControllerEquipmentValves CEV    
    --  WHERE ControllerEquipmentValveID <> 0    
    --    AND CEV.ControllerEquipmentValveID  NOT IN (    
    --    SELECT TCEVM.ValveNumber    
    --  FROM TCD.TunnelCompartmentEquipmentValveMapping TCEVM    
    --   JOIN    
    --   TCD.ControllerEquipmentSetup CES ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupID    
    --  WHERE CES.ControllerID = @ControllerId    
    --    AND TCEVM.TunnelNumber = @TunnelNumber);    
    --END;    
    --PRINT @ValveNumber;    
    
    /* Update If Exists else Insert */    
    
    MERGE TCD.TunnelCompartmentEquipmentValveMapping T    
    USING (SELECT TOP 1 *    
     FROM @TempMapping TM    
     WHERE TM.RowNumber = @i) S    
    ON T.ControllerEquipmentSetupID = @EquipmentSetupId    
   --AND T.CompartmentNumber = S.CompartmentNumber    
   AND T.ValveNumber = S.ValveNumber    
    WHEN MATCHED    
      THEN    
      UPDATE SET --T.TunnelNumber = S.TunnelNumber             
        T.CompartmentNumber = S.CompartmentNumber  
       , T.DirectDosingFlag = S.DirectDosingFlag  
       --, T.ValveNumber =  S.ValveNumber  
          
    WHEN NOT MATCHED    
      THEN    
      INSERT (PlantID    
        , ControllerEquipmentSetupID    
        , TunnelNumber    
        , DosingPointNumber    
        , ValveNumber    
        , CompartmentNumber    
        , DirectDosingFlag    
        , LastModifiedByUserID)    
      VALUES (@PlantId,    
      @EquipmentSetupId,    
      S.TunnelNumber,    
      S.DosingPointNumber,    
      S.ValveNumber,    
      S.CompartmentNumber,    
      S.DirectDosingFlag,    
      @UserId);    
    
    /* Increment the row */    
    
    SET @i = @i + 1;    
    END;    
END;
GO

-----------------------------------------------------Start Tunnel Analog reading of MyControl-------------------------------------------------------------

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlAnalogData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlAnalogData]
END
GO
CREATE PROCEDURE [TCD].[ProcessMyControlAnalogData](
 @ControllerID INT,
 @VxML         XML)
AS
 BEGIN
     DECLARE @TimeStamp    DATETIME,
	 @TunnelNo INT,
	@pH1 DECIMAL(18, 4),
    @pH2 DECIMAL(18, 4),
	@LF DECIMAL(18, 4),
	@Weight DECIMAL(18, 4),
	@Temperature1 DECIMAL(18, 4),
	@Temperature2 DECIMAL(18, 4),
	@Temperature3 DECIMAL(18, 4),
	@Temperature4 DECIMAL(18, 4),
	@Temperature5 DECIMAL(18, 4),
	@Temperature6 DECIMAL(18, 4),
     @SensorNumber  INT,
     @MachineCompartment INT,
     @SensorId           INT,
	 @Reading             DECIMAL(18, 4),   
	 @PHNumber           INT,
	 @PHValue            VARCHAR(100),
	 @TempValue          VARCHAR(100),       
     @SensorCount        INT;
     -- Getting the current UTC time 
     SELECT
    @TimeStamp = GETUTCDATE();

     -- 1.Extracting xml data 
     -- 2.And joining with sensor table
     -- 3.Getting specific Sensor id by passing machine id and controller id and is_deleted(active sensor's)
     -- 4.CTE will return table of columns i.e sensorid,sensortype,temparature,ph values
     --Conventional washer sensor readings

     WITH TempData
      AS (SELECT
     s.SensorId,
     s.SensorType,
     T.c.value('@Temperature', 'DECIMAL(18,4)') temparature,
     T.c.value('@pH', 'DECIMAL(18,4)')          ph
      FROM @VxML.nodes('MyControlAnalogData/WEAnalogData') T(c)
       INNER JOIN TCD.Sensor s ON MachineCompartment =
      (
      SELECT TOP 1
         ms.WasherId
      FROM tcd.MachineSetup ms
      WHERE ms.MachineInternalId = T.c.value('@WENumber','INT')
      AND ms.ControllerId = @ControllerID
      AND ms.IsDeleted = 0
      AND ms.IsTunnel = 0
      )
       AND s.ControllerID = @controllerid
       AND s.Is_deleted = 0) 
       


      -- inserting records into sensor reading table using merge statement
      MERGE INTO tcd.sensorreading sr
      USING
      (
      SELECT
     sensorid,
     sensortype,
     CASE
         WHEN SensorType = 1
         THEN Temparature   --Temparature
         WHEN SensorType = 2
         THEN ph     --PH
     END reading
      FROM tempdata
      ) temp
      ON sr.sensorId = temp.sensorid
     AND temp.reading =
      (
      SELECT TOP 1
     reading
      FROM tcd.SensorReading
      WHERE SensorId = temp.sensorid
      ORDER BY
       TimeStamp DESC
      ) 

      -- If records are not in the sensor reading tables
      -- Sensor records are inserted depending on the sensor type 
 
      WHEN NOT MATCHED AND(temp.reading <> NULL
           OR temp.reading <> 0)
      THEN INSERT(
      sensorid,
      reading,
      timestamp) VALUES
      (
            temp.sensorid,
            temp.reading,
            @TimeStamp
      );

	  --tunnel 1 and tunnel 2 analog data


     CREATE TABLE #TunnelAnalogInputData
     (
      TunnelNo   INT,
      pH1 DECIMAL(18, 4),
	  pH2 DECIMAL(18, 4),
	  LF  DECIMAL(18, 4),
	  Weight   DECIMAL(18, 4),
	 Temperature1  DECIMAL(18, 4),
	 Temperature2  DECIMAL(18, 4),
	Temperature3  DECIMAL(18, 4),
	Temperature4  DECIMAL(18, 4),
	Temperature5  DECIMAL(18, 4),
	Temperature6  DECIMAL(18, 4)
     );

	 CREATE TABLE #SensorReading(
	 sensorId INT,
	 Reading DECIMAL(18, 4),
	 TimeStamp DATETIME
	 )

     INSERT INTO #TunnelAnalogInputData
     (
    TunnelNo,
	pH1,
    pH2,
	LF,
	Weight,
	Temperature1,
	Temperature2,
	Temperature3,
	Temperature4,
	Temperature5,
	Temperature6
     )
     SELECT
    T.c.value('@TunnelNo', 'INT') AS TunnelNo, 
    T.c.value('@pH1', 'DECIMAL(18,4)') AS pH1,
	T.c.value('@pH2', 'DECIMAL(18,4)') AS pH2,
	T.c.value('@LF', 'DECIMAL(18,4)') AS LF,
	T.c.value('@Weight', 'DECIMAL(18,4)') AS Weight,
	T.c.value('@Temperature1', 'DECIMAL(18,4)') AS Temperature1,
	T.c.value('@Temperature2', 'DECIMAL(18,4)') AS Temperature2,
	T.c.value('@Temperature3', 'DECIMAL(18,4)') AS Temperature3,
	T.c.value('@Temperature4', 'DECIMAL(18,4)') AS Temperature4,
	T.c.value('@Temperature5', 'DECIMAL(18,4)') AS Temperature5,
	T.c.value('@Temperature6', 'DECIMAL(18,4)') AS Temperature6
     FROM @VxML.nodes('MyControlAnalogData/TunnelAnalogData') T(C);
	 ---Start Tunnel 1 data
	  SELECT
	    @LF=tad.LF,
		@pH1=tad.pH1,
		@pH2=tad.pH2,
		@Temperature1=tad.Temperature1,
		@Temperature2=tad.Temperature2,
		@Temperature3=tad.Temperature3,
		@Temperature4=tad.Temperature4,
		@Temperature5=tad.Temperature5,
		@Temperature6=tad.Temperature6
     FROM #TunnelAnalogInputData tad
     WHERE tad.TunnelNo=1 ;
	SET @MachineCompartment=1;
	WHILE(@MachineCompartment<=22)
	BEGIN
	   SELECT
        @SensorId = sr.SensorId   
     FROM TCD.Sensor sr
     WHERE sr.SensorType=4 AND sr.MachineCompartment=@MachineCompartment
       AND sr.ControllerID = @ControllerID
	    SELECT @SensorCount=COUNT(1) FROM TCD.SensorReading sr WHERE sr.SensorId=@SensorId AND sr.Reading=@LF
		IF(@SensorCount=0)
		BEGIN
		IF(ISNULL(@SensorId,0)>0 AND ISNULL(@LF,0)>0)
		BEGIN
		INSERT INTO #SensorReading(SensorId,Reading,TimeStamp)
		SELECT @SensorId,@LF,GETUTCDATE()
		END
		END
		SET @MachineCompartment=@MachineCompartment+1;
		SET @SensorId=0
		END
		
		---PH reading for tunnel 1
		SET @PHNumber=1;
		WHILE(@PHNumber<=2)
		BEGIN
		 SELECT
        @SensorId = sr.SensorId
     FROM TCD.Sensor sr
     WHERE sr.SensorNum = @PHNumber
	 AND sr.SensorType=2
       AND sr.ControllerID = @ControllerID;
	   SET @PHValue='@pH'+CAST(@PHNumber AS VARCHAR) 
	   IF(@PHValue='@pH1')
	   BEGIN
	     SELECT @SensorCount=COUNT(1) FROM TCD.SensorReading sr WHERE sr.SensorId=@SensorId AND sr.Reading=@pH1
		
	  IF(@SensorCount=0)
	  BEGIN
	  IF(ISNULL(@SensorId,0)>0 AND ISNULL(@pH1,0)>0)
	  BEGIN
	  INSERT INTO #SensorReading(SensorId,Reading,TimeStamp)
	  SELECT @SensorId,@pH1,GETUTCDATE()
	  END
	  END
	   END
	   IF(@PHValue='@pH2')
	   BEGIN
	     SELECT @SensorCount=COUNT(1) FROM TCD.SensorReading sr WHERE sr.SensorId=@SensorId AND sr.Reading=@pH2
		
	  IF(@SensorCount=0)
	  BEGIN
	  IF(ISNULL(@SensorId,0)>0 AND ISNULL(@pH2,0)>0)
	  BEGIN
	  INSERT INTO #SensorReading(SensorId,Reading,TimeStamp)
	  SELECT @SensorId,@pH2,GETUTCDATE()
	  END
	  END
	   END
	  SET @PHNumber=@PHNumber+1
		END
		---Temperature reading for tunnel 1
	  SET @SensorNumber = 1;
     WHILE(@SensorNumber <= 6)
     BEGIN
     SELECT
        @SensorId = sr.SensorId
     FROM TCD.Sensor sr
     WHERE sr.SensorNum = @SensorNumber
	 AND sr.SensorType=1
       AND sr.ControllerID = @ControllerID;
	  SET @TempValue='@Temperature'+CAST(@SensorNumber AS VARCHAR)
	  IF(@TempValue='@Temperature1')
	  BEGIN
	  SELECT @SensorCount=COUNT(1) FROM TCD.SensorReading sr WHERE sr.SensorId=@SensorId AND sr.Reading=@Temperature1
	  
	  IF(@SensorCount=0)
	  BEGIN
	   IF(ISNULL(@sensorId,0)>0 AND ISNULL(@Temperature1,0)>0 )
	   BEGIN
	   INSERT INTO #SensorReading(sensorId,Reading,TimeStamp)
	   SELECT @SensorId,@Temperature1,GETUTCDATE()
	   END
	   END
	   END
	    IF(@TempValue='@Temperature2')
	  BEGIN
	  SELECT @SensorCount=COUNT(1) FROM TCD.SensorReading sr WHERE sr.SensorId=@SensorId AND sr.Reading=@Temperature2
	  
	  IF(@SensorCount=0)
	  BEGIN
	   IF(ISNULL(@sensorId,0)>0 AND ISNULL(@Temperature2,0)>0 )
	   BEGIN
	   INSERT INTO #SensorReading(sensorId,Reading,TimeStamp)
	   SELECT @SensorId,@Temperature2,GETUTCDATE()
	   END
	   END
	   END
	    IF(@TempValue='@Temperature3')
	  BEGIN
	  SELECT @SensorCount=COUNT(1) FROM TCD.SensorReading sr WHERE sr.SensorId=@SensorId AND sr.Reading=@Temperature3
	  
	  IF(@SensorCount=0)
	  BEGIN
	   IF(ISNULL(@sensorId,0)>0 AND ISNULL(@Temperature3,0)>0 )
	   BEGIN
	   INSERT INTO #SensorReading(sensorId,Reading,TimeStamp)
	   SELECT @SensorId,@Temperature3,GETUTCDATE()
	   END
	   END
	   END
	    IF(@TempValue='@Temperature4')
	  BEGIN
	  SELECT @SensorCount=COUNT(1) FROM TCD.SensorReading sr WHERE sr.SensorId=@SensorId AND sr.Reading=@Temperature4
	  
	  IF(@SensorCount=0)
	  BEGIN
	   IF(ISNULL(@sensorId,0)>0 AND ISNULL(@Temperature4,0)>0 )
	   BEGIN
	   INSERT INTO #SensorReading(sensorId,Reading,TimeStamp)
	   SELECT @SensorId,@Temperature4,GETUTCDATE()
	   END
	   END
	   END
	    IF(@TempValue='@Temperature5')
	  BEGIN
	  SELECT @SensorCount=COUNT(1) FROM TCD.SensorReading sr WHERE sr.SensorId=@SensorId AND sr.Reading=@Temperature5
	 
	  IF(@SensorCount=0)
	  BEGIN
	   IF(ISNULL(@sensorId,0)>0 AND ISNULL(@Temperature5,0)>0 )
	   BEGIN
	   INSERT INTO #SensorReading(sensorId,Reading,TimeStamp)
	   SELECT @SensorId,@Temperature5,GETUTCDATE()
	   END
	   END
	    END
	    IF(@TempValue='@Temperature6')
	  BEGIN
	  SELECT @SensorCount=COUNT(1) FROM TCD.SensorReading sr WHERE sr.SensorId=@SensorId AND sr.Reading=@Temperature6
	
	  IF(@SensorCount=0)
	  BEGIN
	   IF(ISNULL(@sensorId,0)>0 AND ISNULL(@Temperature6,0)>0 )
	   BEGIN
	   INSERT INTO #SensorReading(sensorId,Reading,TimeStamp)
	   SELECT @SensorId,@Temperature6,GETUTCDATE()
	   END
	   END
	     END
	   SET @SensorNumber=@SensorNumber+1;
  END  
  --  INSERT INTO TCD.SensorReading(SensorId,Reading,TimeStamp)
  --SELECT *  FROM #SensorReading
  ---Start Tunnel 2 data
   SELECT
        @LF=tad.LF,
		@pH1=tad.pH1,
		@pH2=tad.pH2,
		@Temperature1=tad.Temperature1,
		@Temperature2=tad.Temperature2,
		@Temperature3=tad.Temperature3,
		@Temperature4=tad.Temperature4,
		@Temperature5=tad.Temperature5,
		@Temperature6=tad.Temperature6
     FROM #TunnelAnalogInputData tad
     WHERE tad.TunnelNo=2;
	SET @MachineCompartment=1;
	WHILE(@MachineCompartment<=22)
	BEGIN
	   SELECT
        @SensorId = sr.SensorId   
     FROM TCD.Sensor sr
     WHERE sr.SensorType=4 AND sr.MachineCompartment=@MachineCompartment
       AND sr.ControllerID = @ControllerID;
	  
	   
	    SELECT @SensorCount=COUNT(1) FROM TCD.SensorReading sr WHERE sr.SensorId=@SensorId AND sr.Reading=@LF
		IF(@SensorCount=0)
		BEGIN
		IF(ISNULL(@SensorId,0)>0 AND ISNULL(@LF,0)>0)
		BEGIN
		INSERT INTO #SensorReading(SensorId,Reading,TimeStamp)
		SELECT @SensorId,@LF,GETUTCDATE()
		END
		END
		SET @MachineCompartment=@MachineCompartment+1;
		SET @SensorId=0;
		END
		
		---PH reading for tunnel 2
		SET @PHNumber=1;
		WHILE(@PHNumber<=2)
		BEGIN
		 SELECT
        @SensorId = sr.SensorId
     FROM TCD.Sensor sr
     WHERE sr.SensorNum = @PHNumber
	 AND sr.SensorType=2
       AND sr.ControllerID = @ControllerID;
	   SET @PHValue='@pH'+CAST(@PHNumber AS VARCHAR) 
	   IF(@PHValue='@pH1')
	   BEGIN
	     SELECT @SensorCount=COUNT(1) FROM TCD.SensorReading sr WHERE sr.SensorId=@SensorId AND sr.Reading=@pH1
		
	  IF(@SensorCount=0)
	  BEGIN
	  IF(ISNULL(@SensorId,0)>0 AND ISNULL(@pH1,0)>0)
	  BEGIN
	  INSERT INTO #SensorReading(SensorId,Reading,TimeStamp)
	  SELECT @SensorId,@pH1,GETUTCDATE()
	  END
	  END
	   END
	   IF(@PHValue='@pH2')
	   BEGIN
	     SELECT @SensorCount=COUNT(1) FROM TCD.SensorReading sr WHERE sr.SensorId=@SensorId AND sr.Reading=@pH2
		
	  IF(@SensorCount=0)
	  BEGIN
	  IF(ISNULL(@SensorId,0)>0 AND ISNULL(@pH2,0)>0)
	  BEGIN
	  INSERT INTO #SensorReading(SensorId,Reading,TimeStamp)
	  SELECT @SensorId,@pH2,GETUTCDATE()
	  END
	  END
	   END
	  SET @PHNumber=@PHNumber+1
		END
		---Temperature reading for tunnel 2
	  SET @SensorNumber = 1;
     WHILE(@SensorNumber <= 6)
     BEGIN
     SELECT
        @SensorId = sr.SensorId
     FROM TCD.Sensor sr
     WHERE sr.SensorNum = @SensorNumber
	 AND sr.SensorType=1
       AND sr.ControllerID = @ControllerID;
	  SET @TempValue='@Temperature'+CAST(@SensorNumber AS VARCHAR)
	  IF(@TempValue='@Temperature1')
	  BEGIN
	  SELECT @SensorCount=COUNT(1) FROM TCD.SensorReading sr WHERE sr.SensorId=@SensorId AND sr.Reading=@Temperature1
	  
	  IF(@SensorCount=0)
	  BEGIN
	   IF(ISNULL(@sensorId,0)>0 AND ISNULL(@Temperature1,0)>0 )
	   BEGIN
	   INSERT INTO #SensorReading(sensorId,Reading,TimeStamp)
	   SELECT @SensorId,@Temperature1,GETUTCDATE()
	   END
	   END
	   END
	    IF(@TempValue='@Temperature2')
	  BEGIN
	  SELECT @SensorCount=COUNT(1) FROM TCD.SensorReading sr WHERE sr.SensorId=@SensorId AND sr.Reading=@Temperature2
	  
	  IF(@SensorCount=0)
	  BEGIN
	   IF(ISNULL(@sensorId,0)>0 AND ISNULL(@Temperature2,0)>0 )
	   BEGIN
	   INSERT INTO #SensorReading(sensorId,Reading,TimeStamp)
	   SELECT @SensorId,@Temperature2,GETUTCDATE()
	   END
	   END
	   END
	    IF(@TempValue='@Temperature3')
	  BEGIN
	  SELECT @SensorCount=COUNT(1) FROM TCD.SensorReading sr WHERE sr.SensorId=@SensorId AND sr.Reading=@Temperature3
	  
	  IF(@SensorCount=0)
	  BEGIN
	   IF(ISNULL(@sensorId,0)>0 AND ISNULL(@Temperature3,0)>0 )
	   BEGIN
	   INSERT INTO #SensorReading(sensorId,Reading,TimeStamp)
	   SELECT @SensorId,@Temperature3,GETUTCDATE()
	   END
	   END
	   END
	    IF(@TempValue='@Temperature4')
	  BEGIN
	  SELECT @SensorCount=COUNT(1) FROM TCD.SensorReading sr WHERE sr.SensorId=@SensorId AND sr.Reading=@Temperature4
	  
	  IF(@SensorCount=0)
	  BEGIN
	   IF(ISNULL(@sensorId,0)>0 AND ISNULL(@Temperature4,0)>0 )
	   BEGIN
	   INSERT INTO #SensorReading(sensorId,Reading,TimeStamp)
	   SELECT @SensorId,@Temperature4,GETUTCDATE()
	   END
	   END
	   END
	    IF(@TempValue='@Temperature5')
	  BEGIN
	  SELECT @SensorCount=COUNT(1) FROM TCD.SensorReading sr WHERE sr.SensorId=@SensorId AND sr.Reading=@Temperature5
	 
	  IF(@SensorCount=0)
	  BEGIN
	   IF(ISNULL(@sensorId,0)>0 AND ISNULL(@Temperature5,0)>0 )
	   BEGIN
	   INSERT INTO #SensorReading(sensorId,Reading,TimeStamp)
	   SELECT @SensorId,@Temperature5,GETUTCDATE()
	   END
	   END
	    END
	    IF(@TempValue='@Temperature6')
	  BEGIN
	  SELECT @SensorCount=COUNT(1) FROM TCD.SensorReading sr WHERE sr.SensorId=@SensorId AND sr.Reading=@Temperature6
	
	  IF(@SensorCount=0)
	  BEGIN
	   IF(ISNULL(@sensorId,0)>0 AND ISNULL(@Temperature6,0)>0 )
	   BEGIN
	   INSERT INTO #SensorReading(sensorId,Reading,TimeStamp)
	   SELECT @SensorId,@Temperature6,GETUTCDATE()
	   END
	   END
	     END
	   SET @SensorNumber=@SensorNumber+1;
  END  
  INSERT INTO TCD.SensorReading(SensorId,Reading,TimeStamp)
  SELECT sensorId,Reading,TimeStamp  FROM #SensorReading
 END;

 GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetPrograms]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetPrograms]
END
GO

CREATE  PROCEDURE [TCD].[GetPrograms]
@EcolabAccountNumber                    NVARCHAR(1000)    ,
@IsResync Bit = 'False',
@ProgramId INT
AS 
  BEGIN 
    SET NOCOUNT ON; 

    SET            @EcolabAccountNumber            =            ISNULL(@EcolabAccountNumber, NULL)            --SQLEnlight SA0029
    IF @ProgramId = 0 
       BEGIN 
          SET @ProgramId = NULL
       END


    SELECT	     pm.ProgramId
            ,pm.Name
            ,pm.Pieces
            ,(CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN etc.TextileId 
        ELSE cp.EcolabTextileCategoryId END) AS TextileId
            ,(CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN etc.CategoryName 
        ELSE cp.EcolabTextileCategoryName END) AS CategoryName
            ,(CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN es.EcolabSaturationId 
        ELSE cp.EcolabSaturationId END) AS EcolabSaturationId
            ,(CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN es.EcolabSaturationName 
        ELSE cp.EcolabSaturationName END) AS EcolabSaturationName    
            ,cp.PlantProgramId
            ,cp.PlantProgramName
            ,cp.ChainTextileId
            ,cp.ChainTextileName
            ,(CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN fs.FormulaSegmentId
        ELSE cp.FormulaSegmentId END) AS FormulaSegmentId
            ,(CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN fs.SegmentName
        ELSE cp.SegmentName END) AS FormulaSegmentName
            ,pm.Rewash
            ,pm.[Weight]
            ,COUNT(*) OVER() as TotalCount            
            ,pm.CustomerId
			,pc.CustomerName
            ,pm.LastModifiedTime 
            ,pm.EcolabAccountNumber
            ,pm.Is_Deleted
            ,pm.Weight_Display
        FROM TCD.ProgramMaster pm
	LEFT JOIN TCD.ChainPrograms cp
	ON cp.PlantProgramId = pm.PlantProgramId AND pm.EcolabAccountNumber = cp.EcolabAccountNumber
        LEFT JOIN TCD.EcolabTextileCategory etc
        ON pm.EcolabTextileCategoryId = etc.TextileId
        LEFT JOIN TCD.EcolabSaturation es
        ON pm.EcolabSaturationId = es.EcolabSaturationId
        LEFT JOIN TCD.FormulaSegments fs
        ON pm.FormulaSegmentId = fs.FormulaSegmentID
		LEFT JOIN TCD.PlantCustomer pc
		ON pc.CustomerId = pm.CustomerId AND pc.EcolabAccountNumber = pm.EcolabAccountNumber
        WHERE pm.ProgramId = ISNULL(@ProgramId, pm.ProgramId)
        AND (pm.Is_Deleted = 0 OR pm.Is_Deleted = @IsResync)
        AND pm.EcolabAccountNumber = @EcolabAccountNumber
        ORDER BY pm.Name
    
         
SET NOCOUNT OFF;
 END
GO

IF NOT EXISTS(SELECT
				  1
			  FROM sys.columns
			  WHERE Name = N'LastSyncTime'
				AND Object_ID = OBJECT_ID(N'[TCD].[FormulaSegments]'))
	BEGIN
		ALTER TABLE TCD.FormulaSegments ADD LastSyncTime DATETIME
	END

	Go

IF NOT EXISTS(SELECT
				  1
			  FROM sys.columns
			  WHERE Name = N'ResourceKey'
				AND Object_ID = OBJECT_ID(N'[TCD].[FormulaSegments]'))
	BEGIN
		ALTER TABLE TCD.FormulaSegments ADD ResourceKey NVARCHAR(400)
	END

	Go

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[SaveFormulaSegments]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[SaveFormulaSegments]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

  CREATE PROCEDURE [TCD].[Saveformulasegments] (@FormulaSegmentID INT = NULL,
                                              @SegmentName      VARCHAR(128) =
NULL,
                                              @IsDeleted        BIT = NULL,
                                              @LastModifiedTime DATETIME = NULL,
                                              @LastSyncTime     DATETIME = NULL)
AS
    SET nocount ON

	SET IDENTITY_INSERT tcd.formulasegments ON

  BEGIN
      IF EXISTS(SELECT *
                FROM   tcd.formulasegments
                WHERE  formulasegmentid = @FormulaSegmentID)
        BEGIN
            UPDATE FC
            SET    FC.segmentname = @SegmentName,-- varchar
                   FC.is_deleted = @IsDeleted,-- bit
                   FC.lastmodifiedtime = @LastModifiedTime,-- datetime
                   FC.lastsynctime = @LastSyncTime -- datetime      
            FROM   tcd.formulasegments FC
            WHERE  FC.formulasegmentid = @FormulaSegmentID
        END
      ELSE
        BEGIN
            INSERT INTO tcd.formulasegments
                        (formulasegmentid,
						 segmentname,
                         is_deleted,
                         lastmodifiedtime,
                         lastsynctime)
            SELECT @FormulaSegmentID,
					@SegmentName,
                   @IsDeleted,
                   @LastModifiedTime,
                   @LastSyncTime
        END
  END  

 	SET IDENTITY_INSERT tcd.formulasegments OFF
GO


-----------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ValidateAlarmsSave]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ValidateAlarmsSave]
END
GO

CREATE	PROCEDURE	[TCD].[ValidateAlarmsSave]
		@ControllerModelId							INT
	,	@ControllerTypeId							INT
	,	@MachineNumber								INT
	,	@EcolabAccountNumber						NVARCHAR(25)
	,	@MaxNoOfRec									INT
AS
BEGIN

SET	NOCOUNT	ON


DECLARE	
		@ReturnValue					int				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''


IF (
	(
		SELECT DISTINCT COUNT(*)
		FROM 
		[TCD].AlarmStatus A
		INNER JOIN [TCD].AlarmGroupMsterVsControllerModelType AGMVCMT ON AGMVCMT.AlarmGroupMsterVsControllerModelTypeId = A.[AlarmGroupMsterVsControllerModelTypeId]
		INNER JOIN [TCD].AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
		INNER JOIN TCD.ControllerModelControllerTypeMapping cmctm ON AGMVCMT.ControllerModelTypeId = cmctm.Id
		WHERE		
		--cmctm.ControllerModelId		= @ControllerModelId
		--AND
		--cmctm.ControllerTypeId		= @ControllerTypeId
		--AND 
		--A.MachineNumber				= @MachineNumber
		--AND
		A.EcolabAccountNumber		= @EcolabAccountNumber
		) <> @MaxNoOfRec
	)
	BEGIN
				SET		@ErrorId						=			51030
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record count does not match.'
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
	END

SET	NOCOUNT	OFF

RETURN	(@ReturnValue)

END
GO

---------------------------------------------------------------Start ProgramId issue resolved in ProcessMitsubishiTunnelWasherOnlineDat-----------------------

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMitsubishiTunnelWasherOnlineData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMitsubishiTunnelWasherOnlineData]
END
GO
CREATE PROCEDURE [TCD].[ProcessMitsubishiTunnelWasherOnlineData]
 (
  @ControllerID INT,
  @xmlTags xML,
  @RedFlagShiftId INT OUTPUT 
 )
AS
BEGIN
   DECLARE 
	   @BatchID      INT,
	   @WasherID      INT,
	   @EcolabWasherId     INT,        
	   @CurrencyCode     VARCHAR(50),  
	   @MachineInternalId    INT,
	   @WasherGroupID     INT,

	   @PlantWasherNumber    INT,
	   @BatchStartDate     DATETIME2,
	   @BatchEndDate     DATETIME2,   
	   @ProgramNumber     INT,
	   @Load       Decimal(10,2),
	   @NominalLoad     Decimal(10,2),
	   @CustomerNumber     INT,
	   --@PHStatus      INT,
	   @PHValue      INT,
	   @PHCompartment     INT,
	   @ConductivityValue    INT,
	   @ConductivityCompartment  INT,
	   @TemperatureValue    INT,
	   @TemperatureCompartment   INT,
	   --@LFStatus      INT,
	   --@LFValue      INT,
	   @EjectionSignal     INT,
	   @TextTileCategory    INT,
	   @BatchNumber     INT,
	   @TargetTurnTime     INT,
	   @ShiftID      INT,
	   @ParameterID     INT,   
	   @ShiftName      VARCHAR(50),
	   @EcolabAccountNumber NVARCHAR(25) = NULL,
	   @PartitionOn DateTime,
	   @BatchStartTime DateTime,
	   @BatchEndTime DateTime,
	   @PorgramParameterID int,
	   @PHParameterID int,
	   @PHParameterStatus int,
	   @ConductivityParamID int,
	   @ConductivityStatusParamID int,
	   @RunTime int,
	   @TextileCategory int,
	   @ProgramID int,
	   @NumberOfCompartments int,
	   @TempParameter int,
	   @CompartmentNoId int,
	   @TransferSignalId int,
	   @TempBatchStartTime DateTime,
	   @ProductId INT,
	   @CompartmentNum INT,
	   @WasherGroupNum INT,
	   @PrevRealQty   INT,
	   @StdInjectionSteps INT,
	   @StdWashSteps INT,
	   @EcolabTextileCategoryId INT,
	   @ChainTextileCategoryId  INT,
	   @FormulaSegmentId        INT,
	   @EcolabSaturationId      INT,
	   @PlantProgramId          INT
    
 --INSERT into MyControlXML (xmlData, BatchType, PLCPointer, ReadPointer, BatchID, comment,LastModified) values (@xmlTags, 'TunnelOnline', null, null, null, '',getDate())

 --   SELECT @PorgramParameterID=ID
 --FROM TCD.ConduitParameters WHERE NAME ='Formula Number'

 --SELECT @PHParameterID=ID
 --FROM TCD.ConduitParameters WHERE NAME ='pH'

 --SELECT @PHParameterStatus=ID
 --FROM TCD.ConduitParameters WHERE NAME ='PH Status'
 
 --SELECT @ConductivityParamID=ID
 --FROM TCD.ConduitParameters WHERE NAME ='Conductivity'

 --SELECT @ConductivityStatusParamID=ID
 --FROM TCD.ConduitParameters WHERE NAME ='LF Status' 
 
 SELECT @CompartmentNoId=ID
 FROM TCD.ConduitParameters WHERE NAME ='StepCompartment No' 

 SELECT @TransferSignalId=ID
 FROM TCD.ConduitParameters WHERE NAME ='Transfer Signal'

 CREATE TABLE #Batches(BatchNumber int,StartDateTime DateTime)   
  

 DECLARE @BatchShiftId int
 DECLARE @ShiftStartDateTemp table(ShiftId INT,ShiftName NVARCHAR(50),ShiftStartdate DATETIME)

 DECLARE @compartmentID int,
   @TunnelXML xml
   
 SET @compartmentID = 20
 
 SELECT @WasherID=null;
    
 WHILE (@compartmentID >=1)
 BEGIN
   
    SELECT @TunnelXML=T.c.query('.') 
  FROM   @xmlTags.nodes('MyControlTunnel/TunnelData') T(c)
  WHERE T.c.value('@CompartmentNumber', 'INT') = @compartmentID


   SELECT   @MachineInternalID=T.c.value('@MachineNumber', 'int'),
      @BatchNumber= T.c.value('@BatchNumber', 'INT'),
      @BatchStartTime=T.c.value('@StartDateTime', 'DateTime'),
      @BatchEndTime=T.c.value('@EndDateTime', 'DateTime'),
      @ProgramNumber=T.c.value('@ProgramNumber', 'INT'),
      @WasherGroupNum=T.c.value('@GroupNumber', 'int'),
      @Load=T.c.value('@Load', 'Decimal(10,2)'),
      @NominalLoad=T.c.value('@Nominalload', 'Decimal(10,2)'),
      @CustomerNumber=T.c.value('@CustomerNumber', 'int'),
      --@PHStatus=T.c.value('@pHStatus', 'int'),
      @PHValue=T.c.value('@pHValue', 'INT'),
      @PHCompartment=T.c.value('@pHCompartment', 'INT'),
      @ConductivityValue=T.c.value('@ConductivityValue', 'INT'),
      @ConductivityCompartment=T.c.value('@ConductivityCompartment', 'INT'),
      @RunTime=T.c.value('@RunTime', 'INT'),
      @EjectionSignal=T.c.value('@EjectionSignal', 'INT'),
      @TextileCategory=T.c.value('@TextileCategory', 'INT')
   FROM @TunnelXML.nodes('TunnelData')  T(c);
   

   IF (@ProgramNumber = 0 OR @BatchNumber=1) 
   BEGIN
      SELECT @compartmentID  = @compartmentID - 1
   Continue;
   END 

   IF (@WasherID is null) 
   BEGIN
   SELECT 
     @EcolabWasherID=EcolabWasherId,
     @WasherGroupID= Wg.WasherGroupId,
     @PlantWasherNumber=PlantWasherNumber,
     @WasherID=ws.WasherId,
     @CurrencyCode=P.CurrencyCode,
     @NumberOfCompartments=Mst.NumberofComp
   FROM TCD.Washer Ws
     INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
     INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
     INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
     INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId = Mst.ControllerId
     INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.EcoLabAccountNumber
   WHERE  Ctrl.ControllerID = @ControllerID
      AND mst.MachineInternalId = @MachineInternalID
      AND mst.IsTunnel = 1

   END 
  

   SELECT @ProgramID=tps.ProgramId,
    @TargetTurnTime= (3600 / (tps.TotalRunTime /@NumberOfCompartments )) 
   FROM TCD.TunnelProgramSetup AS tps 
   WHERE tps.WasherGroupId = @WasherGroupID 
      and tps.is_deleted =0
      and tps.ProgramNumber = @ProgramNumber

   INSERT #Batches(BatchNumber,StartDateTime)
   SELECT @BatchNumber,@BatchStartTime

  SELECT @BatchID = Null

  SELECT @BatchID=BatchID, @PartitionOn=PartitionOn, @TempBatchStartTime=StartDate
  FROM TCD.BatchData BD
  WHERE BD.ControllerBatchId = @BatchNumber
     --AND BD.StartDate= @BatchStartTime
     AND BD.MachineId = @WasherID
     AND CAST(StartDate as date)=CAST(@BatchStartTime as date)
    --Start Getting InjectionCount,StepCount And ProductCount
   SELECT @StdInjectionSteps= count(tdpm.TunnelDosingSetupId) ,
   @StdWashSteps= count(DISTINCT tds.TunnelDosingSetupId)-count(tdpm.TunnelDosingSetupId) 
   FROM tcd.TunnelDosingProductMapping tdpm
   RIGHT JOIN tcd.TunnelDosingSetup tds on tdpm.TunnelDosingSetupId=tds.TunnelDosingSetupId
   WHERE tds.GroupId=@WasherGroupID AND tds.ProgramNumber= @ProgramNumber
   
   --End Getting InjectionCount,StepCount And ProductCount
   SELECT @PlantProgramId = pm.PlantProgramId,
        @EcolabTextileCategoryId = pm.
        EcolabTextileCategoryId,
        @ChainTextileCategoryId = pm.ChainTextileId,
        @FormulaSegmentId = pm.FormulaSegmentId,
        @EcolabSaturationId = pm.EcolabSaturationId
     FROM TCD.ProgramMaster AS pm
     WHERE pm.ProgramId = @ProgramID
       AND pm.Is_Deleted = 0;
     IF(@PlantProgramId <> 0
    OR @PlantProgramId IS NOT NULL)
     BEGIN
     --Assign value from plantchainprogram table based on plantprogramId
     SELECT 
			@EcolabTextileCategoryId = pcp.EcolabTextileCategoryId,
            @ChainTextileCategoryId = pcp.ChainTextileCategoryId,
            @FormulaSegmentId = pcp.FormulaSegmentId,
            @EcolabSaturationId = pcp.EcolabSaturationId
     FROM tcd.PlantChainProgram AS pcp
     WHERE pcp.PlantProgramId = @PlantProgramId
       AND pcp.Is_Deleted = 0;
     END;
  IF (@BatchID is Null) 
    BEGIN

       DELETE FROM  @ShiftStartDateTemp;

        INSERT INTO @ShiftStartDateTemp(ShiftId,ShiftName,ShiftStartdate) 
        EXEC TCD.GetShiftStartDate @BatchStartTime

        SELECT @BatchShiftId = ShiftID,
           @PartitionOn=ShiftStartdate,
           @ShiftName=ShiftName
       FROM @ShiftStartDateTemp


        INSERT INTO TCD.BatchData(
           ControllerBatchId ,
           EcolabWasherId,
           GroupId ,
           MachineInternalId,
           PlantWasherNumber,
           StartDate ,
           ProgramNumber,
           ProgramMasterId,
           MachineId,
           ActualWeight,
           StandardWeight,
           CurrencyCode,
           ShiftId,
           PartitionOn,
           TargetTurnTime,
           StdInjectionSteps,
           StdWashSteps,
		   EcolabTextileCategoryId,
		   ChainTextileCategoryId,
           FormulaSegmentId,
            EcolabSaturationId,
              PlantProgramId
          )
         SELECT @BatchNumber,
          @EcolabWasherID,
          @WasherGroupID,
          @MachineInternalID,
          @PlantWasherNumber,
          @BatchStartTime,
          @ProgramNumber,
          @ProgramID,
          @WasherID,
          @Load,
          @Load,
          @CurrencyCode,
          @BatchShiftId,
          @PartitionOn,
          @TargetTurnTime,
          @StdInjectionSteps,
          @StdWashSteps,
		  @EcolabTextileCategoryId,
          @ChainTextileCategoryId,
          @FormulaSegmentId,
          @EcolabSaturationId,
          @PlantProgramId
       SELECT @BATCHID=Scope_Identity()
       INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue,PartitionOn) SELECT @BatchID,@EcolabWasherId,38,@StdWashSteps, @PartitionOn
       print 'BatchID : ' +Convert(nvarchar(20),@BatchID)

       IF( @CustomerNumber is not null)
       BEGIN
       INSERT INTO [TCD].[BatchCustomerData] ([BatchId],CustomerID,[Weight],PartitionOn,EcolabWasherId)
       SELECT @BatchID,@CustomerNumber,@Load,@PartitionOn,@EcolabWasherId
       END

       END 
  ELSE
  BEGIN
   SET @BatchStartTime = @TempBatchStartTime
  END
  --IF (@BatchEndTime is Not Null and @BatchEndTime !='01/01/1900')
  --BEGIN
  --UPDATE TCD.BatchData
  --SET EndDate = @BatchEndTime
  --WHERE BATCHID = @BatchID
  --END 
  
  -- Transfer Signal
  INSERT INTO TCD.WasherReading(
   WasherId,
   ParameterId,
   ParameterValue,
   DateTimeStamp,
   PartitionOn,
   EcolabWasherId)
   SELECT @WasherID,
   @TransferSignalId,
   1,
   @BatchStartTime,
   @PartitionOn,
   @EcolabWasherId
  UNION ALL
   SELECT @WasherID,
   @TransferSignalId,
   0,
   @BatchStartTime,
   @PartitionOn,
   @EcolabWasherId

  --IF NOT Exists(SELECT 1 FROM [TCD].[BatchCustomerData] 
  --     WHERE BatchID = @BatchID)
  --BEGIN
  --INSERT INTO [TCD].[BatchCustomerData] ([BatchId],CustomerID,[Weight],PartitionOn,EcolabWasherId)
  --SELECT @BatchID,@CustomerNumber,@Load,@PartitionOn,@EcolabWasherId
  --END 

  -- @Program Number
  SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
   WasherId = @WasherID 
   AND ParameterID = @PorgramParameterID 
   AND EcolabWasherId = @EcolabWasherId 
   AND DateTimeStamp = @BatchStartTime
   --AND ParameterValue = @ProgramNumber
   ORDER BY  DateTimeStamp DESC)

  IF (@TempParameter != @ProgramNumber)
  BEGIN
   INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
   SELECT @WasherID,@PorgramParameterID,@ProgramNumber,@BatchStartTime,@PartitionOn,@EcolabWasherId
  END 
  
  ---- PH Value
  --SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
  -- WasherId = @WasherID 
  -- AND ParameterID = @PHParameterID 
  -- AND EcolabWasherId = @EcolabWasherId 
  -- AND DateTimeStamp = @BatchStartTime
  -- --AND ParameterValue = @ProgramNumber
  -- ORDER BY  DateTimeStamp DESC)
  
  --IF (@TempParameter != @PHValue)
  --BEGIN
  -- IF (@PHValue > 0)
  -- BEGIN
  --  INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
  --  SELECT @WasherID,@PHParameterID,@PHValue,@BatchStartTime,@PartitionOn,@EcolabWasherId
  -- END
  --END 

  -- PH Status
  --SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
  -- WasherId = @WasherID 
  -- AND ParameterID = @PHParameterStatus 
  -- AND EcolabWasherId = @EcoLabWasherID 
  -- AND DateTimeStamp = @BatchStartTime
  -- --AND ParameterValue = @ProgramNumber
  -- ORDER BY  DateTimeStamp DESC)

  --IF (@TempParameter != @PHStatus)
  --BEGIN
  -- --IF (@PHStatus > 0)
  -- --BEGIN
  --  INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
  --  SELECT @WasherID,@PHParameterStatus,@PHStatus,@BatchStartTime,@PartitionOn,@EcolabWasherId
  -- --END
  --END 
  
  -- LF Value
  --SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
  -- WasherId = @WasherID 
  -- AND ParameterID = @ConductivityParamID 
  -- AND EcolabWasherId = @EcolabWasherId 
  -- AND DateTimeStamp = @BatchStartTime
  -- --AND ParameterValue = @ProgramNumber
  -- ORDER BY  DateTimeStamp DESC)

  --IF (@TempParameter != @LFValue)
  --BEGIN
  -- IF (@LFValue > 0)
  -- BEGIN
  --  INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
  --  SELECT @WasherID,@ConductivityParamID,@LFValue,@BatchStartTime,@PartitionOn,@EcolabWasherId
  -- END
  --END 
  
  -- LF Status
  --SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
  -- WasherId = @WasherID 
  -- AND ParameterID = @ConductivityStatusParamID 
  -- AND EcolabWasherId = @EcolabWasherId 
  -- AND DateTimeStamp = @BatchStartTime
  -- --AND ParameterValue = @ProgramNumber
  -- ORDER BY  DateTimeStamp DESC)

  --IF (@TempParameter != @LFStatus)
  --BEGIN
  -- --IF (@LFValue > 0)
  -- --BEGIN
  --  INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
  --  SELECT @WasherID,@ConductivityStatusParamID,@LFStatus,@BatchStartTime,@PartitionOn,@EcolabWasherId
  -- --END
  --END 
  
  -- Compartment No  
  SELECT @TempParameter = (SELECT TOP 1 ParameterValue FROM TCD.WasherReading WHERE 
   WasherId = @WasherID 
   AND ParameterID = @CompartmentNoId 
   AND EcolabWasherId = @EcolabWasherId 
   AND DateTimeStamp = @BatchStartTime
   --AND ParameterValue = @ProgramNumber
   ORDER BY  DateTimeStamp DESC)

  IF (@TempParameter != @compartmentID)
  BEGIN
   --IF (@LFValue > 0)
   --BEGIN
    INSERT INTO TCD.WasherReading (WasherId,ParameterID,ParameterValue,DateTimeStamp,PartitionOn,EcolabWasherId)
    SELECT @WasherID,@CompartmentNoId,@compartmentID,@BatchStartTime,@PartitionOn,@EcolabWasherId
   --END
  END   

 
   EXEC TCD.UPDATEBatchWashStepForTunnel @TunnelXML,@WasherID,@BatchID, @BatchStartTime,@PartitionOn,@EcolabWasherId,@compartmentID
  
 IF(@PHValue is not null)
 BEGIN
   EXEC TCD.AddSensorData @ControllerID,@PHCompartment,@WasherGroupID,2,@PHValue
 END

 IF(@ConductivityValue is not null)
 BEGIN
   EXEC TCD.AddSensorData @ControllerID,@ConductivityCompartment,@WasherGroupID,4,@ConductivityValue
 END

 CREATE TABLE #TemperatureData(Value INT, 
          Compartment INT
         )

 INSERT INTO #TemperatureData(Value,Compartment)
   SELECT 
   T.c.value('@TemperatureValue', 'INT') AS Value, 
   T.c.value('@TemperatureCompartment', 'INT') AS Compartment
   
   FROM @TunnelXML.nodes('TunnelData/TemperatureData') T(c)
   
   -- Fetching data from cursor
   DECLARE @MYCURSOR CURSOR
   SET @MYCURSOR = CURSOR FAST_FORWARD
   FOR
   SELECT  Value,
      Compartment

    FROM #TemperatureData

   DECLARE   @TempValue    INT,
       @TempCompartment  INT

   OPEN @MYCURSOR
   FETCH NEXT FROM @MYCURSOR
      INTO 
       @TempValue,
       @TempCompartment
       
   WHILE @@FETCH_STATUS = 0   
   BEGIN 
    
    IF(@TempValue is not null)
    BEGIN
     EXEC TCD.AddSensorData @ControllerID,@TempCompartment,@WasherGroupID,1,@TempValue
    END

    FETCH NEXT FROM @MYCURSOR
      INTO 
       @TempValue,
       @TempCompartment
   END

   CLOSE @MYCURSOR
   DEALLOCATE @MYCURSOR

   Drop table #TemperatureData


    CREATE TABLE #DosingDetails(Number INT, 
          Quantity Decimal(10,6),
          Point INT,
          IsMainEquioment INT,
          IsDirectDosing INT
         )
    
   INSERT INTO #DosingDetails(Number,Quantity, Point, IsMainEquioment, IsDirectDosing)
   SELECT 
   T.c.value('@Number', 'INT') AS Number, --PumpNumber
   T.c.value('@Quantity', 'Decimal(10,6)') AS Quantity, --Dosing Quanity
   T.c.value('@Point', 'INT') AS Point, --ValveNumber
   T.c.value('@IsMainEquioment', 'INT') AS IsMainEquioment,
   T.c.value('@IsDirectDosing', 'INT') AS IsDirectDosing
     
   FROM @TunnelXML.nodes('TunnelData/Dose') T(c)
   
   -- Fetching data from cursor
   DECLARE @MYCURSOR1 CURSOR
   SET @MYCURSOR1 = CURSOR FAST_FORWARD
   FOR
   SELECT  Number,
      Quantity,          
      Point,
      IsMainEquioment,
      IsDirectDosing

    FROM #DosingDetails

   DECLARE   @Number    INT,
       @Quantity   Decimal(10,6),
       @Point    INT,
       @IsMainEquioment INT,
       @IsDirectDosing  INT

   OPEN @MYCURSOR1
   FETCH NEXT FROM @MYCURSOR1
      INTO 
       @Number,
       @Quantity,
       @Point,
       @IsMainEquioment,
       @IsDirectDosing
       
   WHILE @@FETCH_STATUS = 0   
   BEGIN 
    IF(@IsDirectDosing = 1)
    BEGIN
     SELECT @ProductId=CES.ProductId, @CompartmentNum=TCEVM.CompartmentNumber
     FROM tcd.ControllerEquipmentSetup CES 
     INNER JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM
     ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
     WHERE TCEVM.DirectDosingFlag = 1
        AND CES.ControllerId=@ControllerID 
        AND CES.ControllerEquipmentId=@Number
        AND CES.ControllerEquipmentTypeId=1 
        --AND IsActive=1 
        AND CES.WasherGroupNumber=@WasherGroupNum
    END
    ELSE IF(@IsMainEquioment = 1)
    BEGIN
     SELECT @ProductId=CES.ProductId, @CompartmentNum=TCEVM.CompartmentNumber
        FROM  tcd.ControllerEquipmentSetup CES INNER JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM
     ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
     WHERE CES.ControllerId=@ControllerID AND
        CES.ControllerEquipmentTypeId=2 AND
        --CES.IsActive=1 AND
        CES.WasherGroupNumber=@WasherGroupNum AND
        TCEVM.ValveNumber=@Point AND
        CES.ControllerEquipmentId = @Number
    END
    ELSE
    BEGIN
     SELECT @ProductId=CES.ProductId, @CompartmentNum=TCEVM.CompartmentNumber
        FROM  tcd.ControllerEquipmentSetup CES INNER JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM
     ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
     WHERE CES.ControllerId=@ControllerID AND
        CES.ControllerEquipmentTypeId=1 AND
        --CES.IsActive=1 AND
        CES.WasherGroupNumber = @WasherGroupNum AND
        TCEVM.ValveNumber=@Point      
    END

    IF(@ProductId is not null)
    BEGIN
     SELECT TOP 1 @PrevRealQty = RealQty FROM TCD.WasherProductReading WHERE ControllerId=@ControllerID AND WasherId = @WasherId ORDER BY DateTimeStamp DESC
 
     IF(@PrevRealQty is null OR @PrevRealQty != @Quantity)
     BEGIN
    
      INSERT INTO [TCD].[WasherProductReading] 
          (ControllerId,
        WasherId,
        MachineInternalId,
        ProductId,
        RealQty,
        DosingNumber,
        ProgramNumber,
        BatchNumber,
        ValveNumber,
        DateTimeStamp      
          )
          SELECT
           @ControllerId,
           @WasherId,
           @MachineInternalId,
           @ProductId,
           @Quantity,
           @Number,
           @ProgramNumber,
           @BatchNumber,
           @Point,
           GETUTCDATE()       
     END
    END

    FETCH NEXT FROM @MYCURSOR1
      INTO 
       @Number,
       @Quantity,
       @Point,
       @IsMainEquioment,
       @IsDirectDosing
   END

   CLOSE @MYCURSOR1
   DEALLOCATE @MYCURSOR1

   Drop table #DosingDetails
      
   SELECT @compartmentID= @compartmentID - 1 
   SET @ProgramID=0;
 END    

 UPDATE BD
 SET EndDate=GetUTCDate()
 FROM TCD.BatchData BD
 WHERE MachineId =@WasherID
    AND EndDate is Null
    AND CAST(StartDate as date)=CAST(@BatchStartTime as date)
       AND Not Exists(SELECT 1 
       FROM #Batches t
       WHERE t.BatchNumber = BD.ControllerBatchId
          --and t.StartDateTime =BD.StartDate
      )

  --Last Step is not getting closed in Tunnel BatchWashStepData
 UPDATE BWD
 SET EndTime=GetUTCDate()
 FROM TCD.BatchWashStepData BWD
 INNER JOIN TCD.BatchData BD on BWD.BatchId = BD.BatchId
 WHERE BD.MachineId =@WasherID
              AND BWD.EndTime is Null
              AND Not Exists(SELECT 1 FROM #Batches t
                             WHERE t.BatchNumber = BD.ControllerBatchId)
                             --and t.StartDateTime =BD.StartDate)      
END

GO

/*Start : Script to add new column EcolabTextileCategory for Formula Category Admin screen*/
IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'RegionId' AND Object_ID = Object_ID(N'[TCD].[EcolabTextileCategory]'))
BEGIN
	ALTER TABLE TCD.EcolabTextileCategory ADD RegionId smallint
END
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[TCD].[FK_EcolabTextileCategory_RegionId]') AND parent_object_id = OBJECT_ID(N'[TCD].[EcolabTextileCategory]'))
ALTER TABLE TCD.EcolabTextileCategory ADD CONSTRAINT FK_EcolabTextileCategory_RegionId FOREIGN KEY (RegionId)
    REFERENCES TCD.RegionMaster(RegionId);
GO
/* End */

/*Start : Script to add new column RegionMaster for Formula Category Admin screen*/
IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'LastModifiedTime' AND Object_ID = Object_ID(N'[TCD].[RegionMaster]'))
BEGIN
	ALTER TABLE TCD.RegionMaster ADD LastModifiedTime Datetime NOT NULL CoNSTRAINT DF_RegionMaster_LastModifiedTime Default GetDate()
END
GO
/* End */

/*Start : Script to add new column PlantChainProgram for Chain Formula Admin screen*/
IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'ResourceKey' AND Object_ID = Object_ID(N'[TCD].[PlantChainProgram]'))
BEGIN
	ALTER TABLE TCD.PlantChainProgram ADD ResourceKey nvarchar(800)
END
GO
IF NOT EXISTS(SELECT * FROM sys.columns WHERE Name = N'LastSyncTime' AND Object_ID = Object_ID(N'[TCD].[PlantChainProgram]'))
BEGIN
	ALTER TABLE TCD.PlantChainProgram ADD LastSyncTime Datetime NOT NULL CoNSTRAINT DF_PlantChainProgram_LastSyncTime Default GetDate()
END
GO
/* End */
--------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetUsedChemicalName]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetUsedChemicalName]
END
GO

CREATE PROCEDURE [TCD].[GetUsedChemicalName]
    @ChemName Varchar(1000)
    ,@EcolabAccountNumber NVARCHAR(25)
    ,@WasherGroupId    INT = NULL
AS     

BEGIN     
    SET NOCOUNT ON    
    
    DECLARE @RegionId            INT =    NULL
        ,    @ControllerId        INT    =    NULL
        ,    @ControllerModelId    INT    =    NULL
        ,    @ControllerTypeId    INT    =    NULL
    
    SELECT 
    @RegionId = RegionID FROM Plant 
    WHERE 
    EcolabAccountNumber = @EcolabAccountNumber

    SELECT @ControllerId =  wg.ControllerId FROM TCD.WasherGroup wg WHERE wg.WasherGroupId = @WasherGroupId AND wg.EcolabAccountNumber = @EcolabAccountNumber

    IF @ControllerId IS NULL OR @Controllerid = 0
    BEGIN
    IF @WasherGroupId IS NULL
    BEGIN
        SELECT 
        Map.ProductId, RTRIM(ISNULL(NULLIF(M.EnvisionDisplayName, ' '), M.Name)) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name
        , M.Cost
        , M.IncludeinCI
        , TCD.FnChemicalCostInOunce(Map.ProductId) AS        Price
    , 0
        FROM ProductMaster M
        INNER JOIN ProductdataMapping Map ON M.ProductId = Map.ProductId AND Map.Is_Deleted=0
        WHERE 
        (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
        AND M.RegionId = @RegionId
        AND M.Is_Deleted =0
    END
    ELSE
    BEGIN
        SELECT DISTINCT
        Map.ProductId, RTRIM(ISNULL(NULLIF(M.EnvisionDisplayName, ' '), M.Name)) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name
        , M.Cost
        , M.IncludeinCI
        , TCD.FnChemicalCostInOunce(Map.ProductId) AS        Price
    , 0
        FROM TCD.ProductMaster M
        INNER JOIN TCD.ProductdataMapping Map ON M.ProductId = Map.ProductId AND Map.Is_Deleted=0
        LEFT JOIN TCD.ControllerEquipmentSetup ces ON ces.ProductId = Map.ProductId AND ces.EcoLabAccountNumber = Map.EcolabAccountNumber
        INNER JOIN TCD.MachineSetup ms ON ms.ControllerId = ces.ControllerId AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber AND ms.IsDeleted = 'False'
        INNER JOIN TCD.WasherGroup wg ON wg.WasherGroupId = ms.GroupId AND wg.EcolabAccountNumber = ms.EcoalabAccountNumber
        WHERE wg.WasherGroupId = ISNULL(@WasherGroupId, wg.WasherGroupId)
        AND (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
        AND M.RegionId = @RegionId
        AND M.Is_Deleted =0
        END
     END
    ELSE
    BEGIN
        SELECT @ControllerModelId = cc.ControllerModelId, @ControllerTypeId = cc.ControllerTypeId FROM TCD.ConduitController cc WHERE cc.ControllerId = @ControllerId

        IF @ControllerModelId = 11
        BEGIN
            SELECT DISTINCT
            Map.ProductId, 
			RTRIM(ISNULL(NULLIF(M.EnvisionDisplayName, ' '), M.Name)) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name
            , M.Cost
            , M.IncludeinCI
            , CAST (ces.ControllerEquipmentTypeId AS int) AS ControllerEquipmentTypeId
            FROM ProductMaster M
            INNER JOIN ProductdataMapping Map ON M.ProductId = Map.ProductId AND Map.Is_Deleted=0  
            INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.EcoLabAccountNumber = Map.EcolabAccountNumber AND ces.ProductId = Map.ProductID
		  AND ces.ConventionalWasherGroupConnection = 1
            LEFT JOIN TCD.TunnelCompartmentEquipmentValveMapping tcevm ON ces.ControllerEquipmentSetupID = tcevm.ControllerEquipmentSetupID AND tcevm.DirectDosingFlag = 1
            WHERE 
            (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
            AND tcevm.ControllerEquipmentSetupID IS NULL
            AND M.RegionId = @RegionId
            AND M.Is_Deleted =0
            AND ces.ControllerId = @ControllerId
            AND ces.WasherGroupNumber =  CASE WHEN @ControllerTypeId = 13 THEN 1 ELSE ces.WasherGroupNumber END
    END
        ELSE
        BEGIN
            SELECT DISTINCT
            Map.ProductId, 
			RTRIM(ISNULL(NULLIF(M.EnvisionDisplayName, ' '), M.Name)) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name
    , M.Cost
    , M.IncludeinCI
    , TCD.FnChemicalCostInOunce(Map.ProductId) AS        Price
            , CAST (ces.ControllerEquipmentTypeId AS int) AS ControllerEquipmentTypeId
    FROM ProductMaster M
    INNER JOIN ProductdataMapping Map ON M.ProductId = Map.ProductId AND Map.Is_Deleted=0     
            INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.EcoLabAccountNumber = Map.EcolabAccountNumber AND ces.ProductId = Map.ProductID 
		  AND CASE WHEN @ControllerModelId IN (7, 10, 8) THEN ces.ConventionalWasherGroupConnection ELSE ISNULL(ces.ConventionalWasherGroupConnection, 0) END = CASE WHEN @ControllerModelId IN (7, 10, 8) THEN 1 ELSE 0 END
            LEFT JOIN TCD.TunnelCompartmentEquipmentValveMapping tcevm ON ces.ControllerEquipmentSetupID = tcevm.ControllerEquipmentSetupID AND tcevm.DirectDosingFlag = 1
    WHERE 
    (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
            AND tcevm.ControllerEquipmentSetupID IS NULL
    AND M.RegionId = @RegionId
    AND M.Is_Deleted =0
            AND ces.ControllerId = @ControllerId
        END
    END
        

    SET NOCOUNT OFF 
 
END
GO

/*Start : Script to add new Fields for PLC XL Advanced screen*/
IF NOT EXISTS(SELECT * FROM TCD.Field WHERE Label = N'Connexx Alarm delay' AND ResourceKey = N'FieldConnexx_Alarm_Delay2' AND Id=474)
BEGIN

SET IDENTITY_INSERT TCD.Field ON 
INSERT INTO TCD.Field (Id, TypeId, Label, [Min], [Max], FieldGroupId, DataSourceId, IsMandatory
								, HelpText, HelpTextURL, DataTypeId, DataCategoryId, CurrencyId, DisplayOrder, ResourceKey
								, DefaultValue, IsEditable, Name, HasFieldTag, DefaultFieldTag, ClassName)
VALUES (474, 10, N'Connexx Alarm delay', 0, 60, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 2, N'FieldConnexx_Alarm_Delay2', N'10', 1, NULL, 'Tag_CAD', 'uint_Connex_Alarm_Delay', NULL)

UPDATE tcd.FieldGroupFieldMapping  set FieldId=474 WHERE Id IN (395,405,447)
SET IDENTITY_INSERT TCD.Field OFF
END
GO


IF NOT EXISTS(SELECT * FROM TCD.Field WHERE ResourceKey = N'FieldHysteresis_on_Connexx_Alarm_Level2' AND ID=475)
BEGIN
SET IDENTITY_INSERT TCD.Field ON
INSERT INTO TCD.Field (Id, TypeId, Label, [Min], [Max], FieldGroupId, DataSourceId, IsMandatory
								, HelpText, HelpTextURL, DataTypeId, DataCategoryId, CurrencyId, DisplayOrder, ResourceKey
								, DefaultValue, IsEditable, Name, HasFieldTag, DefaultFieldTag, ClassName)
VALUES (475, 10, N'Hysteresis on Connexx alarm level', 0, 10, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'FieldHysteresis_on_Connexx_Alarm_Level2', N'2', 1, NULL, 'Tag_HCAL', 'uint_Connex_Level_Delay', NULL)
SET IDENTITY_INSERT TCD.Field OFF
END
ELSE
BEGIN
	UPDATE TCD.Field SET Label = N'Hysteresis on Connexx alarm level' WHERE Id = 475
END
GO

UPDATE tcd.FieldGroupFieldMapping  set FieldId=475 WHERE Id IN (396,406,448)
GO
/* End */



--Start ETech CustomerCodes SP changes
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[ProcessConventionalWasherData]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.ProcessConventionalWasherData;
	END; 
GO
CREATE PROCEDURE [TCD].[ProcessConventionalWasherData]
 ( 
 @WasherId INT, 
 @xmlTags XML,
 @RedFlagShiftId INT OUTPUT
)

AS
BEGIN
  DECLARE @BatchID        INT,
    @EcolabWasherId       INT,        
    @CurrencyCode       VARCHAR(50),  
    @MachineInternalId      INT,
    @GroupId        INT,  
    @Prveformula       INT,
    @Quantity        INT,
    @MaxWashertGroupCapacity    INT,

    @ProgramMasterId      INT,
    @NominalLoad       DECIMAL(10,2),
    @MaxLoad        DECIMAL(10,2),
    @StandardWeight       DECIMAL(10,2) ,     

    @CurrentFormula       INT,  
    @CurrentFormulaDate      DATETIME2,
    @FormulaIsModified      BIT,

    @CurrentInjection      INT,
    @CurrentInjectionDate     DATETIME2,
    @InjectionIsModified     BIT,

    @OperationalCount      INT,
    @OperationalIsModified     BIT, 
    
    @CurrentHoldSignal      INT,
    @CurrentHoldSignalDate     DATETIME2,
    @HoldSignalIsModified     BIT,  
             
    @EndofFormula       INT, 
    @EndofFormulaDate      DATETIME2,
    
    @AutoWeightEntryActive     BIT,
    @AutoWeightEntryWeight     DECIMAL(10,2),                                                                                                                              
    @ControllerId       INT,
    @CurrentHoldSignalValue     INT ,
    
    @MeterPlcAddress      INT,
    @MeterPlcAddressIsModified    INT,
    @BatchGroupId       INT,
    @BatchFormula       INT,    
    @HoldTime        INT,
    @CteTempBatchInjections     INT,
    @CteTempWaherReadingInjections   INT,
    @BatchStandardWaterUsage    INT,
    @BatchActualWaterUsage     INT,
    @BatchWaterUsagePrice     Decimal(10,2),
    @BatchUtilityPrice      Decimal(10,2),
    @BatchWaterType       INT,
    @PrevGroupId       INT,
    @WasherMeterExists      BIT,
    @ExtraTime        INT,
    @TargetTurnTime       INT,
    @RatioDosingEnabled      BIT,
 @EcolabAccountNumber NVARCHAR(25) = NULL,
 @PreviousFormulaDate      DATETIME2,
 @PreviousInjectionStep INT,
 @PreviousInjectionStartDate DATETIME2,
 @CurrentInjectionStep INT,
 @WashStepBatchId INT,
 @PrevFormulaExtraTime INT      ,
 @AlarmGroupMasterId INT,
 @StdWashSteps INT,
    @StdInjectionSteps INT,
 @EcolabTextileCategoryId INT,
 @ChainTextileCategoryId INT,
 @FormulaSegmentId INT,
 @EcolabSaturationId INT,
 
 @PreviousShiftId INT,
 @CurrentShiftId INT,                                                                                                              
 @PlantProgramId INT,
 @ETechLastDroppedAt  DATETIME2,
 @CustomerCodes VARCHAR(100)

  SET @RedFlagShiftId = NULL
      
  IF EXISTS (SELECT  * FROM [TEMPDB].[DBO].[SYSOBJECTS] o where o.xtype in ('U') AND o.id = OBJECT_ID(N'tempdb..#XmlTagsTable'))
   BEGIN
     DROP TABLE #XmlTagsTable
   END


  CREATE TABLE  #XmlTagsTable ( TagId INT, 
          TagValue NVARCHAR(100), 
          ReceivedTime DATETIME2,
          TagType NVARCHAR(50),
										IsModified BIT,
										ETechLastDropped VARCHAR(100),
										CustomerCodes VARCHAR(100)
         )

 
  INSERT INTO #XmlTagsTable (
          TagId,
          TagValue,
          ReceivedTime,
          TagType,
										IsModified,
										ETechLastDropped,
										CustomerCodes
         )   
  
  SELECT   
     T.c.value('@TagId', 'INT') as TagId,
     T.c.value('@Value', 'NVARCHAR(100)') TagValue,
     T.c.value('@TimeStamp', 'VARCHAR(100)') DateTimeStamp,
     T.c.value('@TagType', 'VARCHAR(50)') TagType,
					T.c.value('@IsModified', 'BIT') TagType,
					T.c.value('@ETechLastDroppedAt', 'VARCHAR(100)') ETechLastDropped,
					T.c.value('@CustomerCodes', 'VARCHAR(100)') CustomerCodes
  FROM  @xmlTags.nodes('Tags/Tag') T(c)
  WHERE 
     T.c.value('@TagId', 'varchar(100)')  IS NOT NULL
 
  SELECT @CurrentFormula     =  TagValue,  
    @CurrentFormulaDate    =  ReceivedTime,
    @FormulaIsModified     =  IsModified
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_FRM'   
     
  SELECT @CurrentInjection    =  TagValue,
    @CurrentInjectionDate   =  ReceivedTime,
    @InjectionIsModified   =  IsModified   
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_INJ'

  SELECT @OperationalCount    =  TagValue,
    @OperationalIsModified   =  IsModified  
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_OPC'  
   
  SELECT @EndofFormula     =  TagValue,
    @EndofFormulaDate    =  ReceivedTime  
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_EOF' 
  
  SELECT @AutoWeightEntryActive   =  TagValue     
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_AWEA'                 

  SELECT @CurrentHoldSignal    =  TagValue, 
    @HoldSignalIsModified   =  IsModified,  
    @CurrentHoldSignalDate   =  ReceivedTime 
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_HOLDL'

  SELECT @AutoWeightEntryWeight   =  TagValue,
   @ETechLastDroppedAt    =  CONVERT(datetime,ETechLastDropped),
   @CustomerCodes   = CustomerCodes
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_AWEW'

  SELECT @MeterPlcAddress    =  TagValue,
    @MeterPlcAddressIsModified  =       IsModified       
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_MPLC'
  
  SELECT @RatioDosingEnabled    =  TagValue      
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_RATA'
  
  SELECT * FROM #XmlTagsTable
  
  SELECT @ExtraTime      =  0

  SELECT TOP 1 @BatchID=BatchId, @Prveformula=ProgramNumber,@PrevGroupId=GroupId, @PreviousFormulaDate=StartDate FROM TCD.BatchData WHERE MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC

  IF(@PreviousFormulaDate is NOT NULL)
  BEGIN
	IF(@CurrentFormulaDate < @PreviousFormulaDate)
	BEGIN
		return
	END
  END

  IF(@CurrentFormula != @EndofFormula AND
     @CurrentFormula = @Prveformula AND 
  @CurrentInjection = 0 AND
  @OperationalCount = 0 AND
  @CurrentFormulaDate <= @PreviousFormulaDate AND
  @CurrentInjectionDate > @PreviousFormulaDate)
 BEGIN
 --Here means, If the same formula is received without EOF then the timestamp of the formula
 --will be still the old timestamp because value is not changed.
 --In this case assign injection=0 timestamp to formula timestamp
  SELECT @CurrentFormulaDate = @CurrentInjectionDate 
 END

  DECLARE @ShiftStartDate table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
  INSERT INTO @ShiftStartDate(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate

  SELECT DISTINCT 
     @EcolabWasherId    =  Ws.EcolabWasherId,
     @StandardWeight    =  Wps.NominalLoad,
     @CurrencyCode    =  Pl.CurrencyCode,
     @ControllerId    =  Ctrl.ControllerId,
     @TargetTurnTime    =  Ws.TargetTurnTime * 60     
  FROM 
     TCD.Washer Ws  
  INNER JOIN 
     TCD.MachineSetup Mst ON
     Mst.WasherId    =  Ws.WasherId
  INNER JOIN 
     TCD.WasherGroup Wg ON 
     Wg.WasherGroupId   =  Mst.GroupId    
  INNER JOIN 
     TCD.WasherProgramSetup Wps ON 
     Wps.WasherGroupId   =  Wg.WasherGroupId
  LEFT JOIN 
     TCD.WasherDosingSetup Wds ON 
     Wds.WasherProgramSetupId =  Wps.WasherProgramSetupId
  LEFT JOIN 
     TCD.WasherDosingProductMapping Wdpm ON 
     Wdpm.WasherDosingSetupId =  Wds.WasherDosingSetupId
  INNER JOIN 
     TCD.Plant Pl ON 
     Pl.EcolabAccountNumber  =  Ws.EcoLabAccountNumber
  INNER JOIN 
    TCD.ConduitController Ctrl 
    ON Ctrl.ControllerId   =  Mst.ControllerId 
  WHERE Ws.WasherId= @WasherId

  SELECT DISTINCT 
     @MachineInternalId=Mst.MachineInternalId,
     @GroupId=Mst.GroupId     
  FROM TCD.Washer Ws
      INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
      INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
      INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
   WHERE Ws.WasherId=@WasherId  

   SELECT DISTINCT      
     @ProgramMasterId=Wps.ProgramId,
     @NominalLoad=Wps.NominalLoad, --Wps.NominalLoad/CONVERT(decimal(10,2), 100) old code
     @MaxLoad =Ws.MaxLoad,
     @ExtraTime =Wps.ExtraTime
  FROM TCD.Washer Ws
      INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
      INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
      INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
      INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
   WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@CurrentFormula and Wps.Is_Deleted=0

  if(@ExtraTime IS NULL)
  BEGIN
   SELECT @ExtraTime      =  0
  END

  SELECT  @MaxWashertGroupCapacity=Max(ws.MaxLoad)
  FROM TCD.Washer WS
   INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
   INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId  
  WHERE Mst.GroupId=@GroupId

  SELECT @WasherMeterExists = M.MachineCompartment FROM Tcd.MachineSetup Ms
  INNER JOIN Tcd.Meter M ON M.GroupId= Ms.GroupId AND  M.MachineCompartment=Ms.MachineInternalId
  WHERE Ms.WasherId=@WasherId

  if(@AutoWeightEntryActive IS NULL)
  BEGIN
   SELECT @AutoWeightEntryActive = 0
  END

  SELECT @StandardWeight=(@NominalLoad * @MaxWashertGroupCapacity) /CONVERT(decimal(10,2), 100)   
  select @AutoWeightEntryActive,@StandardWeight
  SELECT @AutoWeightEntryWeight=Case @AutoWeightEntryActive WHEN 0 THEN @StandardWeight ELSE  @AutoWeightEntryWeight END  
  
  SELECT @CurrentHoldSignalValue=Id  FROM TCD.ConduitParameters where Name='HoldSignal'
  
   SELECT  * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC
  IF(@HoldSignalIsModified !=0)  
  BEGIN
  IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp =@CurrentHoldSignalDate)
   BEGIN
    INSERT INTO TCD.WasherReading(
         WasherId,
         ParameterId,
         ParameterValue,
         DateTimeStamp,
         PartitionOn,
         EcolabWasherId)
    SELECT    @WasherId,
         @CurrentHoldSignalValue,
         @CurrentHoldSignal,
         @CurrentHoldSignalDate,
         (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
         @EcolabWasherId
   END   
  END
  IF(@FormulaIsModified =1  OR @InjectionIsModified = 1 OR @OperationalIsModified = 1)
  BEGIN
   SELECT 'IsModified',@FormulaIsModified AS FormulaIsModified, 
        @InjectionIsModified AS InjectionIsModified,
        @OperationalIsModified AS OperationalIsModified
   IF(@CurrentFormula != 0)
   BEGIN
       DECLARE @BatchShiftId int,@BatchShiftStartDate datetime
       
       SELECT @BatchShiftStartDate = bd.StartDate FROM TCD.BatchData bd WHERE bd.BatchId = @BatchId

       IF(@BatchShiftStartDate > (SELECT TOP 1 [@ShiftStartDate].ShiftStartdate FROM @ShiftStartDate ORDER BY [@ShiftStartDate].ShiftStartdate ASC)
       AND DATEADD(second,@ExtraTime,@CurrentFormulaDate) > (SELECT TOP 1 [@ShiftStartDate].ShiftStartdate FROM @ShiftStartDate ORDER BY [@ShiftStartDate].ShiftStartdate DESC)
       )
       BEGIN 
         
         SELECT TOP 1  @BatchShiftId = ssdt.ShiftId FROM @ShiftStartDate ssdt ORDER BY ssdt.ShiftStartdate DESC
       END
       ELSE
       BEGIN
        SELECT TOP 1  @BatchShiftId = ssdt.ShiftId FROM @ShiftStartDate ssdt ORDER BY ssdt.ShiftStartdate ASC
       END
       

  SELECT DISTINCT      
   @PrevFormulaExtraTime =Wps.ExtraTime
   FROM TCD.Washer Ws
    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
    INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
    INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
    WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@Prveformula and Wps.Is_Deleted=0

  IF(@PrevFormulaExtraTime IS NULL)
  BEGIN
   SELECT @PrevFormulaExtraTime      =  0
  END

     IF(@CurrentFormula = @EndofFormula)
     BEGIN   
     SELECT * FROM #XmlTagsTable
      IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData 
           WHERE 
           BatchId=@BatchId AND 
           MachineId=@WasherId AND 
           EndDate IS NULL 
           ORDER BY StartDate DESC  )
       BEGIN
                                       
        UPDATE TCD.BatchData 
         SET EndDate = DATEADD(second,@PrevFormulaExtraTime,@CurrentFormulaDate),EndDateFormula = @CurrentFormulaDate,ShiftId = @BatchShiftId 
       WHERE  BatchId = @BatchId AND MachineId=@WasherId   
    
    --DECLARE @ShiftMapping1 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
    --INSERT INTO @ShiftMapping1(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate,1, @RedFlagShiftId OUTPUT

    SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
      IF(@PreviousInjectionStep IS NOT NULL)
      BEGIN
       UPDATE TCD.BatchWashStepData SET EndTime=DATEADD(second,@ExtraTime,@CurrentFormulaDate) WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate
      END
                                                                   
       END 
     END 
     ELSE IF((@CurrentFormula != @Prveformula) AND (@BatchID IS NOT NULL))
     BEGIN  
     IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC  )
        BEGIN                          
         UPDATE TCD.BatchData
          SET EndDate = @CurrentFormulaDate,EndDateFormula = @CurrentFormulaDate,ShiftId = @BatchShiftId 
         WHERE  BatchId = @BatchId AND MachineId=@WasherId  
   
     INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,19,1,(SELECT Top 1 ShiftStartdate from @ShiftStartDate) 
     
   --  DECLARE @ShiftMapping2 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
   --INSERT INTO @ShiftMapping2(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate,1, @RedFlagShiftId OUTPUT
    
    SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
     IF(@PreviousInjectionStep IS NOT NULL)
     BEGIN
      UPDATE TCD.BatchWashStepData SET EndTime=@CurrentFormulaDate WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate
     END
       
        END 
      END
     ELSE IF((@CurrentInjection = 0) AND(@OperationalCount = 0) AND (@CurrentFormulaDate != @PreviousFormulaDate))
     BEGIN  
     IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC)
        BEGIN                           
         UPDATE TCD.BatchData
          SET EndDate = @CurrentInjectionDate,ShiftId = @BatchShiftId,EndDateFormula = @CurrentInjectionDate
         WHERE  BatchId = @BatchId AND MachineId=@WasherId  
   
    INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,19,1,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)

   -- DECLARE @ShiftMapping3 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
   --INSERT INTO @ShiftMapping3(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentInjectionDate,1, @RedFlagShiftId OUTPUT
      
   SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
     IF(@PreviousInjectionStep IS NOT NULL)
     BEGIN
      UPDATE TCD.BatchWashStepData SET EndTime=@CurrentInjectionDate WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate
     END

        END 
      END
   
    -- Hold Time
     IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
      BEGIN

      
      SELECT   @HoldTime=SUM(Wr.ParameterValue) FROM TCD. BatchData Bd
      INNER JOIN TCD.WasherReading Wr ON Wr.WasherId=Bd.MachineId
      WHERE Bd.BatchId=@BatchId  AND Wr.DateTimeStamp BETWEEN Bd.StartDate AND  Bd.EndDate and   Wr.ParameterId=9 -- Hold Signal value

      INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,17,@HoldTime,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)


     END
     
     -- CapturingMeter Plc Address EndRedaing 
     IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
      BEGIN
      IF(@WasherMeterExists IS NOT NULL AND @MeterPlcAddress > 0)
      BEGIN
       IF(@MeterPlcAddressIsModified !=0)  
       BEGIN
       IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp =@CurrentFormulaDate)
       BEGIN
        INSERT INTO TCD.WasherReading(
         WasherId,
         ParameterId,
         ParameterValue,
         DateTimeStamp,
         PartitionOn,
         EcolabWasherId)
        SELECT 
         @WasherId,
         14, --MeterPlcAddress for EndSReading
         @MeterPlcAddress,
         @CurrentFormulaDate,
         (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
         @EcolabWasherId
       END

      END
      END
     END
         
     --Start Good or Bad Injection in BatchDataTable
     IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
      BEGIN
        ;WITH CteTempWaherReadingInjections  ( 
        InjectionsCount,BatchId,WasherId,ProgramNumber,Injectons
       ) AS  
       (
        SELECT DISTINCT Wr.ParameterValue,
            BD.BatchId,
            Wr.WasherId,
            Bd.ProgramNumber,
            Wr.ParameterValue FROM TCD. BatchData Bd
        INNER JOIN 
          TCD.WasherReading Wr ON Wr.WasherId   =  Bd.MachineId 
        WHERE    
              Wr.ParameterId    =  10    AND 
              Wr.ParameterValue   <>  0    AND 
              Bd.BatchId     =  @BatchID AND WR.DateTimeStamp BETWEEN BD.StartDate AND BD.EndDate) 
        SELECT @CteTempWaherReadingInjections=COUNT(CTE1.InjectionsCount)
        FROM CteTempWaherReadingInjections CTE1 
        INNER JOIN TCD.BatchData Bd ON Bd.BatchId=CTE1.BatchId
        WHERE Bd.BatchId=@BatchId

        ;WITH CteTempBatchInjections ( 
        InjectionsCount,BatchId,WasherId,ProgramNumber,Injectons
       ) AS  
       (
        SELECT  DISTINCT Wdpm.InjectionNumber,
            Bd.BatchId,
            Wps.ProgramNumber,
            Ws.WasherId,Wdpm.
            InjectionNumber
         FROM TCD.Washer WS
          INNER JOIN 
             TCD.MachineSetup Mst ON 
             Mst.WasherId     =  WS.WasherId
          INNER JOIN 
             TCD.WasherGroup Wg ON 
             Wg.WasherGroupId    =  Mst.GroupId       
          INNER JOIN 
             TCD.WasherProgramSetup Wps ON 
             Wps.WasherGroupId    =  Wg.WasherGroupId
          INNER JOIN 
             TCD.WasherDosingSetup Wds ON 
             Wds.WasherProgramSetupId  =  Wps.WasherProgramSetupId
          INNER JOIN 
             TCD.WasherDosingProductMapping Wdpm ON 
             Wdpm.WasherDosingSetupId  =  Wds.WasherDosingSetupID
          INNER JOIN 
             TCD.ProductdataMapping Pdm ON 
             Pdm.ProductId     =  Wdpm.ProductId
          INNER JOIN 
             TCD.BatchData Bd ON 
             Bd.MachineId     =  Ws.WasherId 
          INNER JOIN 
             TCD.WasherReading Wr ON 
             Wr.WasherId      =  Bd.MachineId
        WHERE 
        
             Wps.ProgramNumber    =  @Prveformula  AND 
             Bd.BatchId      =  @BatchID   AND 
             Ws.WasherId      =  @WasherId    )
        SELECT @CteTempBatchInjections=COUNT(CTE2.InjectionsCount)
        FROM CteTempBatchInjections CTE2 
        INNER JOIN TCD.BatchData Bd ON Bd.BatchId=CTE2.BatchId 
        WHERE Bd.BatchId=@BatchID


        Insert Tcd.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchID,@EcolabWasherId,18,
          CASE WHEN @CteTempBatchInjections = @CteTempWaherReadingInjections THEN 1
            WHEN @CteTempBatchInjections != @CteTempWaherReadingInjections THEN 3 END,
            (SELECT Top 1 ShiftStartdate from @ShiftStartDate) 
                           
    END
     --End Good or Bad Injection in BatchDataTable 
     IF(@OperationalCount = 0 AND @CurrentInjection = 0) AND (@CurrentFormula != @EndofFormula)
     BEGIN 
      IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchData WHERE MachineId=@WasherId AND StartDate =@CurrentFormulaDate)
      BEGIN     
       
	   --Start Rollup for previous completed shift
	   IF(CAST(@CurrentFormulaDate as date) < CAST(GETUTCDATE() as date))
	   BEGIN
		  SELECT TOP 1 @PreviousShiftId=ShiftId FROM TCD.BatchData WHERE MachineId=@WasherId ORDER BY StartDate DESC	   
		  SELECT Top 1 @CurrentShiftId = ShiftId from @ShiftStartDate
		  IF(@CurrentShiftId != @PreviousShiftId)
		  BEGIN
			 EXEC TCD.ProductionShiftDataRollup @PreviousShiftId, @RedFlagShiftId OUTPUT
			 IF(@RedFlagShiftId IS NULL)
			 BEGIN
				SET @RedFlagShiftId = @PreviousShiftId
			 END
		  END
	   END
	   --End Rollup for previous completed shift

       --Start Getting InjectionCount and StepCount
       SELECT 
       @StdInjectionSteps=count(DISTINCT wdpm.WasherDosingSetupId),
       @StdWashSteps= count(DISTINCT wds.WasherDosingSetupId)-count(DISTINCT wdpm.WasherDosingSetupId)
       FROM TCD.WasherDosingProductMapping wdpm
       RIGHT JOIN tcd.WasherDosingSetup wds on wdpm.WasherDosingSetupId=wds.WasherDosingSetupId
       WHERE wds.GroupId=@GroupId AND wds.ProgramNumber=@CurrentFormula
       --End Getting InjectionCount and StepCount
       --Start-----ProgramMasterID logic for PlantChainProgram
        SELECT 
        @PlantProgramId=pm.PlantProgramId,
        @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
        @ChainTextileCategoryId = pm.ChainTextileId,
        @FormulaSegmentId = pm.FormulaSegmentId,
        @EcolabSaturationId = pm.EcolabSaturationId 
        FROM TCD.ProgramMaster pm WHERE pm.ProgramId=@ProgramMasterId AND pm.Is_Deleted=0
        IF(@PlantProgramId <> 0  AND @PlantProgramId IS NOT NULL)
         BEGIN
            --Assign value from plantchainprogram table based on plantprogramId
            SELECT
             @EcolabTextileCategoryId = pcp.EcolabTextileCategoryId,
             @ChainTextileCategoryId = pcp.ChainTextileCategoryId,
             @FormulaSegmentId = pcp.FormulaSegmentId,
             @EcolabSaturationId = pcp.EcolabSaturationId
             FROM tcd.PlantChainProgram pcp
             WHERE pcp.PlantProgramId=@PlantProgramId AND pcp.Is_Deleted=0
         END
       --End-----ProgramMasterID logic for PlantChainProgram

       INSERT INTO TCD.BatchData(
          ControllerBatchId ,
          EcolabWasherId,
          GroupId ,
          MachineInternalId,
          PlantWasherNumber,
          StartDate ,
          EndDate ,
          ProgramNumber,
          ProgramMasterId,
          MachineId,
          ActualWeight,
          StandardWeight,
          CurrencyCode,
          ShiftId,         
          PartitionOn,
          TargetTurnTime,
          StdInjectionSteps,
          StdWashSteps,
          EcolabTextileCategoryId,
          ChainTextileCategoryId,
          FormulaSegmentId,
          EcolabSaturationId,
										PlantProgramId,
										ETechlastDroppedTimeStamp										
          )


         SELECT DISTINCT 0
          ,@EcolabWasherId
          ,@GroupId
          ,@MachineInternalId
          ,Ws.PlantWasherNumber
          ,@CurrentFormulaDate
          ,NULL
          ,@CurrentFormula
          ,@ProgramMasterId
          ,@WasherId
          ,@AutoWeightEntryWeight
          ,@StandardWeight 
          ,@CurrencyCode
          ,(SELECT Top 1 ShiftId from @ShiftStartDate)         
          ,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
          ,@TargetTurnTime
          ,@StdInjectionSteps
          ,@StdWashSteps
          ,@EcolabTextileCategoryId
          ,@ChainTextileCategoryId
          ,@FormulaSegmentId
          ,@EcolabSaturationId
          ,@PlantProgramId           
										,@ETechLastDroppedAt 											

       FROM TCD.Washer Ws
          INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
          INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
          INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
       WHERE Ws.WasherId=@WasherId 
   
       SET @BatchID=SCOPE_IDENTITY() 
         
       INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,38,@StdWashSteps,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
	   --Start Updating CustomerCodes in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
	  IF(@Customercodes IS NOT NULL)
	  BEGIN
	   IF NOT EXISTS(SELECT * FROM TCD.BatchParameters WHERE ParameterId =39 and batchid=@BatchID)
	   BEGIN
		INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,39,@CustomerCodes,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)       
	   END
	   ELSE
	   BEGIN
		Update TCD.BatchParameters SET ParameterValue=@CustomerCodes WHERE ParameterId =39 and batchid=@BatchID
	   END
	  END
	  ----Start Updating CustomerCodes in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
       --If the received formula is not configured in enVision then create an alarm 
       IF(@ProgramMasterId is NULL)
       BEGIN
       SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant;
       SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.AlarmGroupMsterVsControllerModelType AGMVCMT
       INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
       WHERE AGMVCMT.AlarmCode = 9000
        INSERT INTO [TCD].[AlarmData] 
           (EcoalabAccountNumber,
           AlarmCode,
           BatchId,
           controllerID,
           StartDate,
           GroupId,
           MachineInternalId,
           ProgramId,   
           IsActive,
           EndDate,
           MachineId,
           AlarmGroupMasterId,
		   PartitionOn)
           SELECT
            @ECOLABAccountNumber,
            9000,
            @BatchID,
            @ControllerId,
            @CurrentFormulaDate,
            @GroupId,
            @MachineInternalId,
            @CurrentFormula,
            0,
            @CurrentFormulaDate,
            @WasherId,
            @AlarmGroupMasterId,
			@CurrentFormulaDate
       END

         
         INSERT INTO TCD.BatchCustomerData
         (
         BatchId,
         CustomerId,
         Weight,
         PiecesCount,
         PartitionOn,
         EcolabWasherId
         )
        SELECT Bd.BatchId,  
        --SELECT @BatchID,
         Pc.ID,
         @AutoWeightEntryWeight,
         ROUND(COALESCE((@AutoWeightEntryWeight * Pm.Pieces) / NULLIF(Pm.Weight,0), 0),0),
         (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
         @EcolabWasherId
        
      
       FROM TCD.Washer WS
        INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
        INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId       
        INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
        INNER JOIN TCD.ProgramMaster Pm ON Pm.ProgramId=Wps.ProgramId
        INNER JOIN TCD.PlantCustomer Pc ON Pc.ID=Pm.CustomerId
        INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
       WHERE 
        Ws.WasherId=@WasherId AND 
        Wps.ProgramNumber=@CurrentFormula AND 
        Bd.BatchId=@BatchID  AND 
        Pm.CustomerId != -1 

       IF(@WasherMeterExists IS NOT NULL AND @MeterPlcAddress > 0)
       BEGIN        
        IF(@MeterPlcAddressIsModified !=0)  
        BEGIN
          INSERT INTO TCD.WasherReading(
           WasherId,
           ParameterId,
           ParameterValue,
           DateTimeStamp,
           PartitionOn,
           EcolabWasherId)
          SELECT 
           @WasherId,
           13, --MeterPlcAddress for StartReading
           @MeterPlcAddress,
           @CurrentFormulaDate,
           (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
           @EcolabWasherId
        END
       END 
      END              
     END      
     IF(@BatchID IS NOT NULL)     
     BEGIN
     IF(@CurrentInjection <= 0)
      BEGIN
       SET @CurrentInjectionDate=@CurrentFormulaDate
      END 
      IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp =@CurrentInjectionDate)
      BEGIN      
      INSERT INTO TCD.WasherReading(
          WasherId,
          ParameterId,
          ParameterValue,
          DateTimeStamp,
          PartitionOn,
          EcolabWasherId)
      SELECT   @WasherId,
          CASE TagType 
          WHEN 'Tag_FRM' THEN  5  
          WHEN 'Tag_INJ' THEN  10 
          WHEN 'Tag_OPC' THEN  11 
          END,
          TagValue,          
          @CurrentInjectionDate,
          (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
          @EcolabWasherId
       FROM  #XmlTagsTable 
       WHERE  Tagtype in ('Tag_FRM','Tag_INJ','Tag_OPC')         
     END
     END
    IF(@CurrentInjection > 0)     
     BEGIN
      IF (@RatioDosingEnabled = 1)
       BEGIN
       IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurrentInjectionDate and batchid=@BatchID)
       BEGIN
        INSERT INTO TCD.BatchProductData(BatchId,StepCompartment,ActualQuantity,StandardQuantity,Price,TimeStamp,PartitionOn,EcolabWasherId,ProductId)
        SELECT Bd.BatchId 
        --SELECT @BatchID 
         ,Wds.StepNumber
         ,(((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100)) * (@AutoWeightEntryWeight/@StandardWeight) AS ActualQuantity  
         ,(((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100)) * (@AutoWeightEntryWeight/@StandardWeight) AS StandardQuantity      
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * @MaxWashertGroupCapacity)/CONVERT(decimal(10,2), 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price         
         ,@CurrentInjectionDate
         ,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
         ,@EcolabWasherId
         ,Pdm.ProductID
        FROM TCD.Washer WS
         INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
         INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
         INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
         INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
         INNER JOIN TCD.WasherDosingSetup Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
         INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
         INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Wdpm.ProductId
         INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
        WHERE 
          Ws.WasherId=@WasherId     AND 
          Wps.ProgramNumber=@CurrentFormula  AND 
          Wdpm.InjectionNumber=@CurrentInjection AND
          Bd.BatchId=@BatchID AND
    Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
       END
       END
      ELSE
       BEGIN
       IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurrentInjectionDate and batchid=@BatchID)
       BEGIN
        INSERT INTO TCD.BatchProductData(BatchId,StepCompartment,ActualQuantity,StandardQuantity,Price,TimeStamp,PartitionOn,EcolabWasherId,ProductId)
        SELECT Bd.BatchId  
        --SELECT @BatchID
         ,Wds.StepNumber
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100) AS ActualQuantity  
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100) AS StandardQuantity      
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * @MaxWashertGroupCapacity)/CONVERT(decimal(10,2), 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price         
         ,@CurrentInjectionDate
         ,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
         ,@EcolabWasherId
         ,Pdm.ProductID
        FROM TCD.Washer WS
         INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
         INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
         INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
         INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
         INNER JOIN TCD.WasherDosingSetup Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
         INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
         INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Wdpm.ProductId
         INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
        WHERE 
          Ws.WasherId=@WasherId     AND 
          Wps.ProgramNumber=@CurrentFormula  AND 
          Wdpm.InjectionNumber=@CurrentInjection AND
          Bd.BatchId=@BatchID AND
    Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
       END  
       END 
       
  --Populating BatchWashstepdata
      SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
      
      IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchWashStepData WHERE StartTime =@CurrentInjectionDate and batchid=@BatchID)
      BEGIN
         SELECT @CurrentInjectionStep=Wds.StepNumber,
             @WashStepBatchId=Bd.BatchId
                 
         FROM TCD.Washer WS
          INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
          INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
          INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
          INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
          INNER JOIN TCD.WasherDosingSetup Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
          INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
          INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Wdpm.ProductId
          INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
         WHERE 
          Ws.WasherId=@WasherId     AND 
          Wps.ProgramNumber=@CurrentFormula  AND 
          Wdpm.InjectionNumber=@CurrentInjection AND
          Bd.BatchId=@BatchID AND
          Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0

         IF(@CurrentInjectionStep IS NOT NULL)
         BEGIN
          INSERT INTO TCD.BatchWashStepData(BatchId,StepCompartment,StartTime,PartitionOn,EcolabWasherId)
          VALUES (@WashStepBatchId,  @CurrentInjectionStep, @CurrentInjectionDate, (SELECT Top 1 ShiftStartdate from @ShiftStartDate), @EcolabWasherId)                
         
          UPDATE TCD.BatchWashStepData SET EndTime=@CurrentInjectionDate WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate         
         END

      END
      --End Populating BatchWashstepdata

      --Start Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
      IF NOT EXISTS(SELECT * FROM TCD.BatchParameters WHERE ParameterId =37 and batchid=@BatchID)
      BEGIN
       INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,37,1,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)       
      END
      ELSE
      BEGIN
       Update TCD.BatchParameters SET ParameterValue=@CurrentInjection WHERE ParameterId =37 and batchid=@BatchID
      END
        --End Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
     END

     UPDATE TCD.ConduitController
      SET LastConnectedTime  = GETUTCDATE()
      WHERE ControllerId   = @ControllerId
   END
  END
 END
 GO
--End ETech CustomerCodes SP changes
--Update default IP for EControl+ -- 
BEGIN TRY
    IF EXISTS( SELECT 1
                 FROM TCD.Field
                 WHERE label LIKE 'IP Address'
                   AND id = 387
             )
        BEGIN
            BEGIN TRAN UPDATEDEFAULTIPADDRESS
        END;
    UPDATE TCD.Field
      SET DefaultValue = '10.225.134.1'
      WHERE label LIKE 'IP Address'
        AND id = 387;

    COMMIT;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        BEGIN
            ROLLBACK
        END;
END CATCH;
GO 
--End Update default IP for EControl+ -- 

-- Update FILED_MAINEQUIPMENT Resource Key
IF EXISTS (SELECT * 
               FROM   tcd.ResourceKeyValue rkv 
               WHERE  rkv.KeyName = 'FILED_MAINEQUIPMENT'
                      AND rkv.LanguageID = 1) 
  BEGIN 
      UPDATE tcd.ResourceKeyValue 
      SET    Value = N'Main Equipment', 
             LastModifiedTime = Getdate() 
      WHERE  KeyName = N'FILED_MAINEQUIPMENT' 
             AND languageID = 1; 
  END
GO
IF EXISTS (SELECT * 
               FROM   tcd.ResourceKeyValue rkv 
               WHERE  rkv.KeyName = 'FIELD_EQUIPMENT' 
                      AND rkv.LanguageID = 1) 
  BEGIN 
      UPDATE tcd.ResourceKeyValue 
      SET    Value = N'Equipment', 
             LastModifiedTime = Getdate() 
      WHERE  KeyName = N'FIELD_EQUIPMENT' 
             AND languageID = 1; 
  END
GO




------------------------------------------------------------------ Dash Board GetBatchTrendingGroupData start------------------------------------------------
IF  EXISTS (SELECT
			*
		FROM sys.objects 
		WHERE object_id = OBJECT_ID(N'[TCD].[GetBatchTrendingGroupData]') 
			AND type IN (N'P', N'PC'))
BEGIN
	DROP PROCEDURE [TCD].[GetBatchTrendingGroupData]
END
GO

CREATE PROCEDURE [TCD].[GetBatchTrendingGroupData] (@GroupId int )
AS 
SET NOCOUNT ON
BEGIN 

DECLARE @DayId Varchar(20) = NULL,
    @StartTime DateTime = NULL,
    @EndTime DateTime = NULL,
    @TransferStarttime Time = NULL,
    @TransferEndtime Time = NULL,
    @MachineId int = NULL,
    @ParameterId int = NULL,
    @ParameterValue  Int = NULL,
    @WasherStatus Int,
 @RegionId  Int = NULL,
 @EcoLabAccountNumber nvarchar(25) = NULL

DECLARE @NoofComp Int = NULL, 
    @Count int = 1

SELECT @NoOfcomp = NumberOfComp FROM [TCD].machinesetup 
  WHERE Groupid = @GroupId and IsTunnel = 1

DECLARE @GET_COMPARTMENT TABLE (
   GroupId INT,
   MachineID INT,
   CompartmentNumber VARCHAR(1000))

WHILE(@count <=  @NoOfcomp) 
BEGIN
   INSERT INTO @GET_COMPARTMENT(GroupId,MachineID,CompartmentNumber)
    SELECT @GroupId,@count,'Compartment'+ cast(@count as Varchar(1000))+''
   SET @count = @count + 1
End

DECLARE @TrendingData TABLE(
    BatchId INT,
    CustomerId INT,
    ProgramId INT,
    ActualLoad DECIMAL(10,2),
    NominalLoad DECIMAL(10,2),
    GroupId INT,
    CompartmentId INT,
    --DupCount INT,
    Efficiency DECIMAL(10,2),
    Temparature  DECIMAL(10,2),
    Conductivity  DECIMAL(10,2),
    PH  DECIMAL(10,2)) 

Declare @DummyTrendingData TABLE(
    BatchId INT,
    CustomerId INT,
    ProgramId INT,
    ActualLoad DECIMAL(10,2),
    NominalLoad DECIMAL(10,2),
    GroupId INT,
    CompartmentId INT,
    --DupCount INT,
    Efficiency DECIMAL(10,2),
    Temparature  DECIMAL(10,2),
    Conductivity  DECIMAL(10,2),
    PH  DECIMAL(10,2)) 
   
INSERT INTO @TrendingData(
    BatchId ,
    CustomerId ,
    ProgramId ,
    ActualLoad,
    NominalLoad ,
    GroupId ,
    CompartmentId ,
    --DupCount INT,
    Efficiency ,
    Temparature ,
    Conductivity,
    PH) 


     SELECT DISTINCT
             BA.BatchId,
             BC.CustomerId,
             BA.ProgramNumber,
             BA.[ActualWeight],
             BA.[StandardWeight],
             BA.GroupId,
             BS.StepCompartment,
             (BA.[ActualWeight]/BA.[StandardWeight]) * 100 AS LoadEfficiency,
             TE.Reading AS Temparature,
             CO.Reading AS Conductivity,
             PH.Reading AS PH

        FROM [TCD].BatchWashStepData AS BS
             INNER JOIN [TCD].BatchData BA ON BA.BatchId = BS.BatchId
             LEFT OUTER JOIN [TCD].BatchCustomerData BC ON BC.BatchId = BA.BatchId
             LEFT OUTER JOIN (SELECT SS.GroupId,
                            SS.MachineCompartment,
                            MR.Reading
                        FROM TCD.ModuleReading MR INNER JOIN TCD.Sensor SS ON MR.ModuleId = SS.SensorId WHERE MR.ModuleTypeId = 3 AND SS.SensorType = 1) TE
             ON BA.GroupId = TE.GroupId AND BS.StepCompartment = TE.MachineCompartment
              LEFT OUTER JOIN (SELECT SS.GroupId,
                            SS.MachineCompartment,
                            MR.Reading
                        FROM TCD.ModuleReading MR INNER JOIN TCD.Sensor SS ON MR.ModuleId = SS.SensorId WHERE MR.ModuleTypeId = 3 AND SS.SensorType = 4) CO
             ON BA.GroupId = CO.GroupId AND BS.StepCompartment = CO.MachineCompartment

    LEFT OUTER JOIN (SELECT SS.GroupId,
                            SS.MachineCompartment,
                            MR.Reading
                        FROM TCD.ModuleReading MR INNER JOIN TCD.Sensor SS ON MR.ModuleId = SS.SensorId WHERE MR.ModuleTypeId = 3 AND SS.SensorType = 2) PH
             ON BA.GroupId = CO.GroupId AND BS.StepCompartment = CO.MachineCompartment

        WHERE BS.EndTime IS NULL AND BA.EndDate IS NULL
        AND BA.GroupId = @GroupId 
		AND BA.StandardWeight > 0  
		AND BA.ActualWeight > 0 

  Select @MachineId = WasherId,@EcoLabAccountNumber=EcoalabAccountNumber from tcd.MachineSetup where GroupId = @GroupId
  Select top 1 @ParameterId =  ParameterId ,@Parametervalue = ParameterValue from TCD.washerReading where WasherId = @MachineId order by DateTimeStamp desc
  select top 1 @RegionId = RegionId from TCD.Plant where EcolabAccountNumber=@EcoLabAccountNumber

  If(@ParameterId = 6 and @Parametervalue = 0)
   BEGIN
    set @WasherStatus = 1
   END
  Else If (@ParameterId = 6 and @Parametervalue = 1)
   BEGIN
    set @WasherStatus = 2
   END
  Else If (@ParameterId = 12)
   BEGIN
    set @WasherStatus = 0
   END

  INSERT INTO @DummyTrendingData(BatchId,CustomerId,ProgramId,ActualLoad,NominalLoad,GroupId,CompartmentId,Efficiency,Temparature,Conductivity,PH)
    SELECT 0,0,0,0,0,GroupId,MachineID,0,0,0,0 FROM @GET_COMPARTMENT

    IF(@WasherStatus != 2)
    BEGIN
    UPDATE  D  SET

      D.BatchId = C.BatchId, 
      D.CustomerId =  CASE WHEN C.ActualLoad = 0 THEN 0
       ELSE 
      C.CustomerId END,
      D.ProgramId = C.ProgramId,
      D.ActualLoad = C.ActualLoad,
      D.NominalLoad = C.NominalLoad,
      D.GroupId = CASE WHEN C.GroupId = 0 THEN C.GroupId ELSE D.GroupId END,
      D.CompartmentId =  CASE WHEN C.CompartmentId IS NOT NULL THEN C.CompartmentId ELSE D.CompartmentId END,
      D.Efficiency = CAST(C.Efficiency AS decimal(10,2)),
      D.Temparature = CAST(C.Temparature AS decimal(10,2)),
      D.Conductivity = CAST(C.Conductivity AS decimal(10,2)),
      D.PH = CAST(C.PH AS decimal(10,2)) 
      FROM @DummyTrendingData D LEFT OUTER JOIN @TrendingData C ON D.CompartmentId = C.CompartmentId

   END
       SELECT 
      ISNULL(BatchId,0) AS BatchId,
      ISNULL(CustomerId,0) AS CustomerId,
      ISNULL(ProgramId,0) AS ProgramId,
   (CASE WHEN (@RegionId=1) THEN ISNULL(ActualLoad,0) ELSE ROUND((ISNULL(ActualLoad,0)*0.453592),0) END) AS ActualLoad,
   (CASE WHEN (@RegionId=1) THEN ISNULL(NominalLoad,0) ELSE ROUND((ISNULL(NominalLoad,0)*0.453592),0) END) AS NominalLoad,
      ISNULL(GroupId,0) AS GroupId,
      ISNULL(CompartmentId,0) AS CompartmentId,
      ISNULL(Efficiency,0) AS Efficiency,
      ISNULL(Temparature,0) AS Temparature,
      ISNULL(Conductivity,0) AS Conductivity,
      ISNULL(PH,0) AS PH
       FROM @DummyTrendingData
  END

  ------------------------------------------------------------------ Dash Board GetBatchTrendingGroupData End------------------------------------------------

  Go

  ----------------------------------------------------------DCS Process Mycontrol Start----------------------------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlConventionalData_Online]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlConventionalData_Online]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ProcessMyControlConventionalData_Online]
(
	@ControllerID   INT,
	@VxML           XML,
	@RedFlagShiftId INT OUTPUT
)
AS
	BEGIN
	    DECLARE @MachineNumber           INT,
			  @StepNumber              INT,
			  @StartDateTime           DATETIME,
			  @EndDateTime             DATETIME,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @PHValue                 INT,
			  @TemperatureMin          INT,
			  @TemperatureMax          INT,
			  @TempMinStatus           INT,
			  @TempMaxStatus           INT,
			  @BatchNumber             INT,
			  @WasherID                INT,
			  @WasherGroupID           INT,
			  @EcoLabWasherID          INT,
			  @ProgramMasterID         INT,
			  @PlantWasherNumber       INT,
			  @ShiftID                 INT,
			  @FrmParameterID          INT,
			  @PHParameterID           INT,
			  @PHParameterStatus       INT,
			  @BatchID                 INT,
			  @ShiftStartdate          DATETIME,
			  @ShiftName               NVARCHAR(50),
			  @XMLDataID               INT,
			  @TempParameter           INT,
			  @TemperatureMinParam     INT,
			  @TemperatureMaxParam     INT,
			  @TempMinStatusParam      INT,
			  @TempMaxStatusParam      INT,
			  @WashStepNo              INT,
			  @CurrencyCode            VARCHAR(50),
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @TargetTurnTime          INT,
			  @MeterID                INT,
			  @WaterConsumption1      DECIMAL(18,4),
			  @WaterConsumption2      DECIMAL(18,4),
			  @ModuleCount			  INT

	    SELECT @MachineNumber = T.c.value('@MachineNumber', 'INT'),
			 @StepNumber = T.c.value('@StepNumber', 'INT'),
			 @StartDateTime = T.c.value('@StartDateTime', 'DATETIME'),
			 @EndDateTime = T.c.value('@EndDateTime', 'DATETIME'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@NominalLoad', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'INT'),
			 @PHStatus = T.c.value('@PHStatus', 'INT'),
			 @PHValue = T.c.value('@PHValue', 'INT'),
			 @TemperatureMin = T.c.value('@TemperatureMin', 'INT'),
			 @TemperatureMax = T.c.value('@TemperatureMax', 'INT'),
			 @TempMaxStatus = T.c.value('@TemperatureMaxStatus', 'INT'),
			 @TempMinStatus = T.c.value('@TemperatreMinStatus', 'INT'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @WaterConsumption1=T.c.value('@WaterConsumption1','DECIMAL(18,4)'),
			 @WaterConsumption2=T.c.value('@WaterConsumption2','DECIMAL(18,4)')
	    FROM @VxML.nodes('MyControlConventionalData') T(C);

		--Check for valid startdatetime
		IF(@StartDateTime <='01/01/1900' OR @StartDateTime > '06/06/2079')
		BEGIN
			return
		END

	    SELECT @PHParameterID = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'pH';
	    SELECT @PHParameterStatus = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'PH Status';
	    SELECT @TemperatureMinParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Mimum Temperature';
	    SELECT @TemperatureMaxParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Maximum Temperature';
	    SELECT @TempMinStatusParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Minimum Temperature Status';
	    SELECT @TempMaxStatusParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Max Temperature Status';
	    SELECT @WashStepNo = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'StepCompartment No';
	    SELECT @FrmParameterID = [Id]
	    FROM TCD.ConduitPArameters
	    WHERE Name = 'Formula Number';
	    DECLARE @ShiftMapping TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    INSERT INTO @ShiftMapping
	    (
		  ShiftId,
		  ShiftName,
		  ShiftStartdate
	    )
	    EXEC TCD.GetShiftStartDate
		    @StartDateTime
	    SELECT @ShiftID = ShiftID,
			 @ShiftStartdate = ShiftStartdate
	    FROM @ShiftMapping;
	    SELECT @WasherGroupID = GroupId,
			 @WasherID = WasherID
	    FROM TCD.MachineSetup ms
	    WHERE ControllerID = @ControllerID
			AND MachineInternalId = @MachineNumber
			AND IsTunnel = 0
			AND IsDeleted = 0;
	    IF(@EndDateTime = '1/1/1900')
		   SELECT @EndDateTime = NULL;
	    IF(@StartDateTime = '1/1/1900')
		   SELECT @StartDateTime = NULL;
	    IF(@WasherId IS NOT NULL)
		   BEGIN
			  SELECT @ProgramMasterId = Wps.ProgramId
			  FROM TCD.Washer Ws
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.ControllerID = Wg.ControllerId
				  INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.EcoLabAccountNumber
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wps.Is_Deleted = 0;
			  SELECT @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber,
				    @CurrencyCode = P.CurrencyCode,
				    @TargetTurnTime = w.TargetTurnTime * 60
			  FROM TCD.Washer w
				  INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.EcolabAccountNumber
			  WHERE w.WasherId = @WasherID;
	   END;
	    SELECT @BatchID = BatchID
	    FROM TCD.BatchData
	    WHERE MachineInternalID = @MachineNumber
			AND StartDate = @StartDateTime
			AND ControllerBatchId = @BatchNumber
			AND MachineID = @WasherID;

	    --Start Getting InjectionCount and StepCount
	    SELECT @StdInjectionSteps = COUNT(DISTINCT wdpm.
	    WasherDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) -
			 COUNT(DISTINCT wdpm.WasherDosingSetupId)
	    FROM TCD.WasherDosingProductMapping wdpm
		    RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm.
		    WasherDosingSetupId = wds.WasherDosingSetupId
	    WHERE wds.ControllerID = @ControllerID
			AND wds.ProgramNumber = @ProgramNumber;
	    --End Getting InjectionCount and StepCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramMasterId
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT @EcolabTextileCategoryId = pcp.
			  EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp.
				    ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    IF(@BatchID IS NULL)
		   BEGIN
			  INSERT INTO TCD.BatchData
			  (ControllerBatchID,
			   EcolabWasherId,
			   GroupId,
			   MachineInternalId,
			   PlantWasherNumber,
			   StartDate,
			   EndDate,
			   ProgramNumber,
			   ProgramMasterId,
			   MachineID,
			   ActualWeight,
			   StandardWeight,
			   CurrencyCode,
			   ShiftId,
			   PartitionOn,
			   StdInjectionSteps,
			   StdWashSteps,
			   EcolabTextileCategoryId,
			   ChainTextileCategoryId,
			   FormulaSegmentId,
			   EcolabSaturationId,
			   PlantProgramId,
			   EndDateFormula,
			   TargetTurnTime
			  )
			  VALUES
			  (
				    @BatchNumber,
				    @EcoLabWasherID,
				    @WasherGroupID,
				    @MachineNumber,
				    @PlantWasherNumber,
				    @StartDateTime,
				    @EndDateTime,
				    @ProgramNumber,
				    @ProgramMasterId,
				    @WasherID,
				    @Load,
				    @NominalLoad,
				    @CurrencyCode,
				    @ShiftID,
				    @ShiftStartdate,
				    @StdInjectionSteps,
				    @StdWashSteps,
				    @EcolabTextileCategoryId,
				    @ChainTextileCategoryId,
				    @FormulaSegmentId,
				    @EcolabSaturationId,
				    @PlantProgramId,
				    @EndDateTime,
				    @TargetTurnTime
			  );
			  SELECT @BatchID = SCOPE_IDENTITY();
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM TCD.BatchParameters
				 WHERE BatchId = @BatchID
					  AND ParameterID = 38
			   )
			   BEGIN
			   IF(@StdWashSteps <> 0
				 OR @StdWashSteps <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
					   BatchId,
					   EcolabWasherId,
					   ParameterId,
					   ParameterValue,
					   PartitionOn
					)
					SELECT @BatchID,
						  @EcoLabWasherID,
						  38,
						  @StdWashSteps,
						  @ShiftStartdate;
				  END
			END;

			  --End Date  Time  is Null 
			  UPDATE TCD.BatchData
			    SET
				   EndDate = GETUTCDATE()
			  WHERE MachineInternalID = @MachineNumber
				   AND StartDate <> @StartDateTime
				   AND EndDate IS NULL
				   AND ControllerBatchId <> @BatchNumber
				   AND MachineId = @WasherId;	
																  		
			  -- Program Number	
			  IF(@ProgramNumber IS NOT NULL
				AND @ProgramNumber > 0)
				 BEGIN
					IF NOT EXISTS
					(
					    SELECT *
					    FROM TCD.WasherReading
					    WHERE WasherId = @WasherID
							AND ParameterID = @FrmParameterID
							AND DateTimeStamp = @StartDateTime
					)
					    BEGIN
						   INSERT INTO TCD.WasherReading
						   (WasherID,
						    ParameterID,
						    ParameterValue,
						    DateTimeStamp,
						    EcoLabWasherID,
						    Partitionon
						   )
						   VALUES
						   (
								@WasherID,
								@FrmParameterID,
								@ProgramNumber,
								@StartDateTime,
								@EcoLabWasherID,
								@ShiftStartdate
						   );
					    END;
				 END;
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM [TCD].[BatchCustomerData]
				 WHERE BatchID = @BatchId
					  AND @CustomerNumber IS NOT NULL
			  )
				 BEGIN
					INSERT INTO [TCD].[BatchCustomerData]
					([BatchId],
					 CustomerID,
					 [Weight],
					 PartitionOn,
					 EcolabWasherId
					)
					VALUES
					(
						  @BatchID,
						  @CustomerNumber,
						  @Load,
						  @ShiftStartdate,
						  @EcolabWasherID
					);
				 END;
		   END;

	    -- PH Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @PHParameterID
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@PHValue <> 0
				OR @PHValue <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @PHParameterID,
							    @PHValue,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 
	 
	    -- PH Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @PHParameterStatus
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@PHStatus <> 0
				OR @PHStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @PHParameterStatus,
							    @PHStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Min Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TemperatureMinParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TemperatureMin <> 0
				OR @TemperatureMin <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TemperatureMinParam,
							    @TemperatureMin,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Max Value
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TemperatureMaxParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TemperatureMax <> 0
				OR @TemperatureMax <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TemperatureMaxParam,
							    @TemperatureMax,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Min Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TempMinStatusParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TempMinStatus <> 0
				OR @TempMinStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TempMinStatusParam,
							    @TempMinStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Max Status
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TempMaxStatusParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TempMaxStatus <> 0
				OR @TempMaxStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TempMaxStatusParam,
							    @TempMaxStatus,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END; 

	    -- StepCompartment No
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @WashStepNo
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@StepNumber <> 0
				OR @StepNumber <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterID,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @WashStepNo,
							    @StepNumber,
							    GETUTCDATE(),
							    @ShiftStartdate,
							    @EcolabWasherId;
				 END;
		   END;
 --Start water consumption per batch

	SELECT @MeterID=MeterId
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@MachineNumber
   AND mt.CounterNum = 1;

   SELECT @ModuleCount= COUNT(1) FROM TCD.ModuleReading WHERE Reading =@WaterConsumption1 AND ModuleId = @MeterID
  IF (@ModuleCount=0)
  BEGIN
  IF(ISNULL(@WaterConsumption1,0) > 0 AND ISNULL(@MeterID,0) > 0)
  BEGIN
   INSERT INTO TCD.ModuleReading
     (ModuleId,
      ModuleTypeId,
      Reading,
      TimeStamp
     )
     SELECT
     @MeterID,
     2,	  --Water Meter
     @WaterConsumption1,
     GETUTCDATE()
  END
 END 
 
 SELECT @MeterID=MeterId
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@MachineNumber
   AND mt.CounterNum = 2; 
 -- set  @ModuleCount=@@ROWCOUNT
  SELECT @ModuleCount= COUNT(1) FROM TCD.ModuleReading WHERE Reading =@WaterConsumption2 AND ModuleId = @MeterID
  IF (@ModuleCount=0)
  BEGIN
  IF(ISNULL(@WaterConsumption2,0) > 0 AND ISNULL(@MeterID,0) > 0)
  BEGIN
   INSERT INTO TCD.ModuleReading
     (ModuleId,
      ModuleTypeId,
      Reading,
      TimeStamp
     )
     SELECT
     @MeterID, 
     2,
     @WaterConsumption2,
     GETUTCDATE()
  END
      END   
	 --End water consumption per batch
 END;
 GO

 IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlConventionalData_CompletedBatches]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlConventionalData_CompletedBatches]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ProcessMyControlConventionalData_CompletedBatches](
	@ControllerID   INT,
	@VxML           XML,
	@PLCPointer     INT,
	@ReadPointer    INT,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @MachineNumber           INT,
			  @StartDateTime           DATETIME,
			  @EndDateTime             DATETIME,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @PHValue                 INT,
			  @TemperatureMin          INT,
			  @TemperatureMax          INT,
			  @TempMinStatus           INT,
			  @TempMaxStatus           INT,
			  @BatchNumber             INT,
			  @WasherID                INT,
			  @WasherGroupID           INT,
			  @EcoLabWasherID          INT,
			  @ProgramMasterID         INT,
			  @PlantWasherNumber       INT,
			  @ShiftID                 INT,
			  @BatchID                 INT,
			  @ShiftStartdate          DATETIME,
			  @LastStep                INT,
			  @CurrentStep             INT,
			  @CurrentStepTime         DATETIME,
			  @MinTempParamID          INT,
			  @MaxTempParamID          INT,
			  @MinTempStatuParamID     INT,
			  @MaxTempStatusParamID    INT,
			  @PHStatusParamID         INT,
			  @PHValueParamID          INT,
			  @CurrencyCode            VARCHAR(50),
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @ActualInjSteps          INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @TargetTurnTime          INT,
			  @PreviousShiftId         INT,
			  @CurrentShiftId          INT,
			  @MeterID                 INT,
			  @StepComportment         INT,
			  @Stepno                  INT,
			  @quantity                INT,
			  @productid               INT,
			  @Price                   DECIMAL(18, 4),
			  @StandardQty             DECIMAL(18, 4),
			  @TimeStamp               DATETIME2(7),
			  @MaxWashertGroupCapacity INT,
			  @InjectionNumber         INT,
			  @WaterConsumption1       DECIMAL(10,6),
			  @WaterConsumption2       DECIMAL(10,6),
			  @EnergyCount             INT,
			   @EcolabAccountNumber    VARCHAR(100),
	           @AlarmGroupMasterId     INT;
	    SELECT
			 @MachineNumber = T.c.value('@MachineNumber', 'INT'),
			 @StartDateTime = T.c.value('@StartDateTime', 'DateTime'),
			 @EndDateTime = T.c.value('@EndDateTime', 'DateTime'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@NominalLoad', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'INT'),
			 @PHStatus = T.c.value('@PHStatus', 'INT'),
			 @PHValue = T.c.value('@PHValue', 'INT'),
			 @TemperatureMin = T.c.value('@TemperatureMin', 'INT'),
			 @TemperatureMax = T.c.value('@TemperatureMax', 'INT'),
			 @TempMaxStatus = T.c.value('@TemperatureMaxStatus', 'INT'),
			 @TempMinStatus = T.c.value('@TemperatreMinStatus', 'INT'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @WaterConsumption1 = T.c.value('@WaterConsumption1','DECIMAL(10,6)'),
			 @WaterConsumption2 = T.c.value('@WaterConsumption2','DECIMAL(10,6)')
	    FROM @VxML.nodes('MyControlConventionalData') T(C);

		--Check for valid startdatetime
		IF(@StartDateTime <='01/01/1900' OR @StartDateTime > '06/06/2079')
		BEGIN
			return
		END

	    DECLARE @ShiftMapping TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    INSERT INTO @ShiftMapping
	    (
			 ShiftId,
			 ShiftName,
			 ShiftStartdate
	    )
	    EXEC TCD.GetShiftStartDate
		    @StartDateTime;
	    SELECT
			 @ShiftID = ShiftID,
			 @ShiftStartdate = ShiftStartdate
	    FROM @ShiftMapping;
	    SELECT
			 @WasherGroupID = GroupId,
			 @WasherID = WasherID
	    FROM TCD.MachineSetup ms
	    WHERE ControllerID = @ControllerID
			AND MachineInternalId = @MachineNumber
			AND IsTunnel = 0
			AND IsDeleted = 0;
	    IF(@WasherId IS NOT NULL)
		   BEGIN
			  SELECT
				    @ProgramMasterId = Wps.ProgramId
			  FROM TCD.Washer Ws
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws
				  .WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =
				  Mst.GroupId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.
				  ControllerID = Wg.ControllerId
				  INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber =
				  Ws.EcoLabAccountNumber
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wps.Is_Deleted = 0;
			  SELECT
				    @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber,
				    @CurrencyCode = P.CurrencyCode,
				    @TargetTurnTime = w.TargetTurnTime * 60
			  FROM TCD.Washer w
				  INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.
				  EcolabAccountNumber
			  WHERE w.WasherId = @WasherID;
		   END;
	    SELECT
			 @BatchID = BatchID
	    FROM TCD.BatchData
	    WHERE MachineInternalID = @MachineNumber
			AND StartDate = @StartDateTime
			AND ControllerBatchId = @BatchNumber
			AND MachineID = @WasherID;

	    --Start Getting InjectionCount and StepCount

	    SELECT
			 @StdInjectionSteps = COUNT(DISTINCT wdpm.
			 WasherDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) -
			 COUNT(DISTINCT wdpm.WasherDosingSetupId)
	    FROM TCD.WasherDosingProductMapping wdpm
		    RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm.
		    WasherDosingSetupId = wds.WasherDosingSetupId
	    WHERE wds.ControllerID = @ControllerID
			AND wds.ProgramNumber = @ProgramNumber;

	    --End Getting InjectionCount and StepCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT
			 @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramMasterId
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT
				    @EcolabTextileCategoryId = pcp.
				    EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp.
				    ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    IF(@BatchID IS NULL)
		   BEGIN

			  --Start Rollup for previous completed shift
			  IF(CAST(@StartDateTime AS DATE) < CAST(GETUTCDATE() AS
			  DATE))
				 BEGIN
					SELECT TOP 1
						  @PreviousShiftId = ShiftId
					FROM TCD.BatchData
					WHERE MachineId = @WasherId
					ORDER BY
						    StartDate DESC;
					SELECT TOP 1
						  @CurrentShiftId = ShiftId
					FROM @ShiftMapping;
					IF(@CurrentShiftId != @PreviousShiftId)
					    BEGIN
						   EXEC TCD.ProductionShiftDataRollup
							   @PreviousShiftId,
							   @RedFlagShiftId OUTPUT;
						   IF(@RedFlagShiftId IS NULL)
							  BEGIN
								 SET @RedFlagShiftId =
								 @PreviousShiftId;
							  END;
					    END;
				 END;
			  --End Rollup for previous completed shift

			  INSERT INTO TCD.BatchData
			  (
				    ControllerBatchID,
				    EcolabWasherId,
				    GroupId,
				    MachineInternalId,
				    PlantWasherNumber,
				    StartDate,
				    EndDate,
				    ProgramNumber,
				    ProgramMasterId,
				    MachineID,
				    ActualWeight,
				    StandardWeight,
				    CurrencyCode,
				    ShiftId,
				    PartitionOn,
				    StdInjectionSteps,
				    StdWashSteps,
				    EcolabTextileCategoryId,
				    ChainTextileCategoryId,
				    FormulaSegmentId,
				    EcolabSaturationId,
				    PlantProgramId,
				    EndDateFormula,
				    TargetTurnTime
			  )
			  VALUES
			  (
				    @BatchNumber,
				    @EcoLabWasherID,
				    @WasherGroupID,
				    @MachineNumber,
				    @PlantWasherNumber,
				    @StartDateTime,
				    @EndDateTime,
				    @ProgramNumber,
				    @ProgramMasterId,
				    @WasherID,
				    @Load,
				    @NominalLoad,
				    @CurrencyCode,
				    @ShiftID,
				    @ShiftStartdate,
				    @StdInjectionSteps,
				    @StdWashSteps,
				    @EcolabTextileCategoryId,
				    @ChainTextileCategoryId,
				    @FormulaSegmentId,
				    @EcolabSaturationId,
				    @PlantProgramId,
				    @EndDateTime,
				    @TargetTurnTime
			  );
			  SELECT
				    @BatchID = SCOPE_IDENTITY();
			  IF NOT EXISTS
			  (
				 SELECT
					   *
				 FROM TCD.BatchParameters
				 WHERE BatchId = @BatchID
					  AND ParameterID = 38
			  )
				 BEGIN
					IF(@StdWashSteps > 0
					   OR @StdWashSteps <> NULL)
					    INSERT INTO TCD.BatchParameters
					    (
							 BatchId,
							 EcolabWasherId,
							 ParameterId,
							 ParameterValue,
							 PartitionOn
					    )
					    SELECT
							 @BatchID,
							 @EcoLabWasherID,
							 38,
							 @StdWashSteps,
							 @ShiftStartdate;
				 END;
		   END;
	    ELSE
		   BEGIN
			  UPDATE tcd.BatchData
			    SET
				   EndDate = @EndDateTime,
				   EndDateFormula = @EndDateTime,
				   ProgramNumber = @ProgramNumber,
				   ProgramMasterId = @ProgramMasterID,
				   ActualWeight = @Load,
				   SyncReady = 1
			  WHERE
				   BatchID = @BatchID;
		   END;
		      --If the received formula is not configured in enVision then create an alarm 
       IF(@ProgramMasterId is NULL)
       BEGIN
       SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant;
       SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.AlarmGroupMsterVsControllerModelType AGMVCMT
       INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
       WHERE AGMVCMT.AlarmCode = 9000
        INSERT INTO [TCD].[AlarmData] 
           (EcoalabAccountNumber,
           AlarmCode,
           BatchId,
           controllerID,
           StartDate,
           GroupId,
           MachineInternalId,
           ProgramId,   
           IsActive,
           EndDate,
           MachineId,
           AlarmGroupMasterId)
           SELECT
            @ECOLABAccountNumber,
            9000,
            @BatchID,
            @ControllerId,
            @StartDateTime,
            @WasherGroupID,
            @MachineNumber,
            @ProgramNumber,
            0,
            @StartDateTime,
            @WasherId,
            @AlarmGroupMasterId
       END





	    IF NOT EXISTS
	    (
		   SELECT
				1
		   FROM [TCD].[BatchCustomerData]
		   WHERE BatchID = @BatchId
			    AND @CustomerNumber IS NOT NULL
	    )
		   BEGIN
			  INSERT INTO [TCD].[BatchCustomerData]
			  (
				    [BatchId],
				    CustomerID,
				    [Weight],
				    PartitionOn,
				    EcolabWasherId
			  )
			  VALUES
			  (
				    @BatchID,
				    @CustomerNumber,
				    @Load,
				    @ShiftStartdate,
				    @EcolabWasherID
			  );
		   END;
	    ELSE
	    IF(@CustomerNumber > 0)
		   BEGIN
			  UPDATE [TCD].[BatchCustomerData]
			    SET
				   CustomerID = @CustomerNumber,
				   [Weight] = @Load
			  WHERE
				   BatchID = @BatchId;
		   END;
	    CREATE TABLE #Dosing
	    (
		    equipmentNo INT,
		    StepNo      INT,
		    Qty         DECIMAL(10, 6)
	    );
	    INSERT INTO #Dosing
	    SELECT
			 T.c.value('@Equipment', 'INT'),
			 T.c.value('@stepNo', 'INT'),
			 T.c.value('@Qty', 'Decimal(10,6)')
	    FROM @VxML.nodes('MyControlConventionalData/DosingData/Dosing') T
	    (C)
	    WHERE T.c.value('@Qty', 'Decimal(10,6)') > 0;
	    CREATE TABLE #StepTime
	    (
		    Number    INT,
		    [Time]    INT,
		    StartTime DATETIME,
		    EndTime   DATETIME
	    );
	    INSERT INTO #StepTime
	    (
			 Number,
			 [Time]
	    )
	    SELECT
			 T.c.value('@Number', 'INT'),
			 T.c.value('@Time', 'INT')
	    FROM @VxML.nodes('MyControlConventionalData/StepTime/Step') T(C);
	    CREATE TABLE #TimeStamp
	    (
		    Step_Number INT,
		    Time_Stamp  INT
	    );
	
	    --For Calculating TIME_STAMP

	    WITH TempTable
		    AS (SELECT DISTINCT
					Number
			   FROM #StepTime)
		    INSERT INTO #TimeStamp
		    (
				 Step_Number,
				 Time_Stamp
		    )
		    SELECT
				 b.Number,
				 SUM(t.Time) Time_Stamp
		    FROM TempTable b
			    INNER JOIN #StepTime t ON b.Number >= t.Number
		    GROUP BY
				   b.Number;
	    CREATE TABLE #BatchProductData
	    (
		    equipmentNo INT,
		    StepNo      INT,
		    Qty         DECIMAL(10, 6),
		    Time_Stamp  DATETIME2(7),
		    ProductId   INT,
		    Row_No      INT
	    );
	    INSERT INTO #BatchProductData
	    (
			 EquipmentNo,
			 StepNo,
			 Qty,
			 Time_Stamp,
			 ProductId,
			 Row_No
	    )
	    SELECT
			 d.equipmentNo,
			 d.StepNo,
			 d.Qty,
			 DATEADD(ss, ts.Time_Stamp, @StartDateTime),
			 ces.ProductId,
			 ROW_NUMBER() OVER(ORDER BY d.StepNo DESC) AS Row
	    FROM #Dosing d
		    INNER JOIN #TimeStamp ts ON d.StepNo = ts.Step_Number
		    INNER JOIN tcd.ControllerEquipmentSetup ces ON ces.
		    ControllerEquipmentId = d.equipmentNo
	    WHERE d.equipmentNo > 0
			AND d.Qty > 0
			AND ControllerID = @ControllerID
			AND ces.ProductId IS NOT NULL;
	    SELECT
			 @MaxWashertGroupCapacity = MAX(ws.MaxLoad)
	    FROM TCD.Washer WS
		    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.
		    GroupId
	    WHERE Mst.GroupId = @WasherGroupID;
	    DECLARE @Counter INT;
	    SET @counter = 1;
	    WHILE(@counter <=
		    (
			   SELECT
					COUNT(ROW_No)
			   FROM #BatchProductData bpd
		    ))
		   BEGIN
			  SELECT
				    @stepno = bpd.StepNo,
				    @quantity = bpd.Qty,
				    @productid = bpd.ProductId,
				    @timestamp = bpd.Time_Stamp
			  FROM #BatchProductData bpd
			  WHERE bpd.Row_No = @counter
			  ORDER BY
					 bpd.StepNo;
			  SELECT
				    @InjectionNumber = Wdpm.InjectionNumber,
				    @standardqty = ((@NominalLoad / CONVERT( DECIMAL(
				    10, 2), 100)) * Wdpm.Quantity * Ws.MaxLoad) /
				    CONVERT(DECIMAL(10, 2), 100),
				    @price = ((@NominalLoad / CONVERT(       DECIMAL(
				    10, 2), 100)) * Wdpm.Quantity *
				    @MaxWashertGroupCapacity) / CONVERT(DECIMAL(10, 2),
				    100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID)
			  FROM TCD.Washer WS
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws
				  .WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =
				  Mst.GroupId
				  INNER JOIN TCD.WasherGroupType WgT ON WgT.
				  WasherGroupTypeId = Wg.WasherGroupTypeId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.
				  ControllerID = Wg.ControllerId
				  INNER JOIN TCD.WasherDosingSetup Wds ON Wds.
				  WasherProgramSetupId = Wps.WasherProgramSetupId
				  INNER JOIN TCD.WasherDosingProductMapping Wdpm ON
				  Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
				  INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.
				  ProductId = Wdpm.ProductId
				  INNER JOIN TCD.BatchData Bd ON Bd.MachineId = Ws.
				  WasherId
			  WHERE Ws.WasherId = @WasherID
				   AND Wps.ProgramNumber = @ProgramNumber
				   --AND Wdpm.InjectionNumber = @stepno
				   AND Bd.BatchId = @BatchID
				   AND Wps.Is_Deleted = 0
				   AND Pdm.Is_Deleted = 0;
			  INSERT INTO TCD.BatchProductData
			  (
				    BatchId,
				    StepCompartment,
				    ActualQuantity,
				    StandardQuantity,
				    Price,
				    PartitionOn,
				    EcolabWasherId,
				    ProductId,
				    TimeStamp,
				    InjectionNumber
			  )
			  VALUES
			  (
				    @BatchID,
				    @stepno,
				    @quantity,
				    ISNULL(@standardqty,0),
				    ISNULL(@price,0),
				    @ShiftStartdate,
				    @EcolabWasherId,
				    @productid,
				    @timestamp,
				    @InjectionNumber
			  );
			  SET @counter = @counter + 1;
		   END;
	    --END For calculating TIMESTAMP
	    --Start Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
	    SELECT
			 @ActualInjSteps = COUNT(DISTINCT StepNo)
	    FROM #Dosing 
		Where StepNo > 0 ;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE ParameterId = 37
			    AND batchid = @BatchID
			    AND @ActualInjSteps > 0
	    )
		   BEGIN
			  IF(@ActualInjSteps > 0
				OR @ActualInjSteps IS NOT NULL)
				 INSERT INTO TCD.BatchParameters
				 (
					   BatchId,
					   EcolabWasherId,
					   ParameterId,
					   ParameterValue,
					   PartitionOn
				 )
				 SELECT
					   @BatchId,
					   @EcolabWasherId,
					   37,
					   @ActualInjSteps,
					   @ShiftStartDate;
		   END;
	    ELSE
		   BEGIN
			  UPDATE TCD.BatchParameters
			    SET
				   ParameterValue = @ActualInjSteps
			  WHERE
				   ParameterId = 37
				   AND batchid = @BatchID;
		   END;
	    SELECT
			 @LastStep = MAX([Number])
	    FROM #StepTime
	    WHERE [Time] > 0;
	    SELECT
			 @CurrentStep = 1,
			 @CurrentStepTime = @StartDateTime;
	    WHILE(@CurrentStep <= @LastStep)
		   BEGIN
			  UPDATE #StepTime
			    SET
				   StartTime = @CurrentStepTime,
				   EndTime = DATEADD(ss, [time], @CurrentStepTime)
			  WHERE
				   Number = @CurrentStep;
			  SELECT
				    @CurrentStepTime = EndTime
			  FROM #StepTime
			  WHERE Number = @CurrentStep;
			  SELECT
				    @CurrentStep = @CurrentStep + 1;
		   END;
	    INSERT INTO [TCD].[BatchWashStepData]
	    (
			 BatchID,
			 StepCompartment,
			 StartTime,
			 EndTime,
			 PartitionOn,
			 EcolabWasherId
	    )
	    SELECT
			 @BatchID,
			 Number,
			 StartTime,
			 EndTime,
			 @ShiftStartdate,
			 @EcoLabWasherID
	    FROM #StepTime
	    WHERE Number <= @LastStep;
	    SELECT
			 @MinTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Mimum Temperature';
	    SELECT
			 @MaxTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Maximum Temperature';
	    SELECT
			 @MaxTempStatusParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Max Temperature Status';
	    SELECT
			 @MinTempStatuParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Minimum Temperature Status';
	    SELECT
			 @PHValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH';
	    SELECT
			 @PHStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH Status';
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MinTempParamID
	    )
		   BEGIN
			  IF(@TemperatureMin <> 0
				OR @TemperatureMin <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MinTempParamID,
						  @TemperatureMin,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MaxTempParamID
	    )
		   BEGIN
			  IF(@TemperatureMax <> 0
				OR @TemperatureMax <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MaxTempParamID,
						  @TemperatureMax,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MaxTempStatusParamID
	    )
		   BEGIN
			  IF(@TempMaxStatus <> 0
				OR @TempMaxStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MaxTempStatusParamID,
						  @TempMaxStatus,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.BatchParameters
		   WHERE BatchId = @BatchID
			    AND ParameterID = @MinTempStatuParamID
	    )
		   BEGIN
			  IF(@TempMinStatus <> 0
				OR @TempMinStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.BatchParameters
					(
						  BatchId,
						  EcolabWasherId,
						  ParameterId,
						  ParameterValue,
						  PartitionOn
					)
					VALUES
					(
						  @BatchID,
						  @EcoLabWasherID,
						  @MinTempStatuParamID,
						  @TempMinStatus,
						  @ShiftStartdate
					);
				 END;
		   END;
	    IF(@PHStatus <> 0
		  OR @PHStatus <> NULL)
		   BEGIN
			  INSERT INTO TCD.BatchParameters
			  (
				    BatchId,
				    EcolabWasherId,
				    ParameterId,
				    ParameterValue,
				    PartitionOn
			  )
			  VALUES
			  (
				    @BatchID,
				    @EcoLabWasherID,
				    @PHStatusParamID,
				    @PHStatus,
				    @ShiftStartdate
			  );
		   END;
	    IF(@PHValue <> 0
		  OR @PHValue <> NULL)
		   BEGIN
			  INSERT INTO TCD.BatchParameters
			  (
				    BatchId,
				    EcolabWasherId,
				    ParameterId,
				    ParameterValue,
				    PartitionOn
			  )
			  VALUES
			  (
				    @BatchID,
				    @EcoLabWasherID,
				    @PHValueParamID,
				    @PHValue,
				    @ShiftStartdate
			  );
		   END;
	    EXEC TCD.ProcessMyControlProductionWaterConsumptionData
		    @BatchID,
		    @VxML,
		    @ShiftStartDate;
	    DROP TABLE #BatchProductData;
	    DROP TABLE #Dosing;
	    DROP TABLE #StepTime;
	    DROP TABLE #TimeStamp;

		--Start water consumption per batch

	SELECT @MeterID=MeterId,@StepComportment=MachineCompartment
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@MachineNumber
   AND mt.CounterNum = 1;


   SELECT @EnergyCount=COUNT(1) FROM TCd.BatchStepWaterUsageData bswud WHERE BatchId =@BatchID AND StepCompartment =@StepComportment AND ActualQuantity=@WaterConsumption1
    IF(@EnergyCount=0)
  BEGIN
  IF(ISNULL(@WaterConsumption1,0)>0  AND ISNULL(@MeterID,0)>0  AND ISNULL(@StepComportment,0)>0)
  BEGIN
   INSERT INTO TCD.BatchStepWaterUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
	  EcolabWasherId
     )
     SELECT
     @BatchID,
     @StepComportment,
     @WaterConsumption1,
     @ShiftStartdate,
	 @EcoLabWasherID
	 END
      END  

	 SELECT @MeterID=MeterId,@StepComportment=MachineCompartment
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@MachineNumber
   AND mt.CounterNum = 2;
SELECT @EnergyCount=COUNT(1) FROM TCd.BatchStepWaterUsageData WHERE BatchId =@BatchID AND StepCompartment =@StepComportment AND ActualQuantity=@WaterConsumption2
 IF(@EnergyCount=0)
  BEGIN
  IF(ISNULL(@WaterConsumption2,0)>0  AND ISNULL(@MeterID,0)>0  AND ISNULL(@StepComportment,0)>0)
  BEGIN
   INSERT INTO TCD.BatchStepWaterUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
	  EcolabWasherId
     )
     SELECT
     @BatchID,
     @StepComportment,
     @WaterConsumption2,
     @ShiftStartdate,
	 @EcoLabWasherID
	 END
      END   
	  --End water consumption per batch
	END;

GO

 IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlTunnelWasherOnlineData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlTunnelWasherOnlineData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ProcessMyControlTunnelWasherOnlineData](
	@ControllerID   INT,
	@xmlTags        XML,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @BatchID                 INT,
			  @WasherID                INT,
			  @EcolabWasherId          INT,
			  @CurrencyCode            VARCHAR(50),
			  @MachineInternalId       INT,
			  @WasherGroupID           INT,
			  @PlantWasherNumber       INT,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @BatchNumber             INT,
			  @TargetTurnTime          INT,
			  @PartitionOn             DATETIME,
			  @BatchStartTime          DATETIME,
			  @ProgramID               INT,
			  @NumberOfCompartments    INT,
			  @TransferSignalId        INT,
			  @BatchShiftId            INT,
			  @compartmentID           INT,
			  @TunnelXML               XML,
			  @TempXML                 XML,
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @CurrentStepComportmentNO INT,
               @CounterNO               INT,
               @MeterID                 INT,
              @ActualQuantity          DECIMAL(10,6),
			  @WasherModuleCount        INT

	    SELECT @TransferSignalId = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Transfer Signal';
	    CREATE TABLE #Batches
	    (
		    BatchNumber   INT,
		    StartDateTime DATETIME
	    );
	    -- SET @compartmentID = 1;

	    SELECT @TempXML = T.c.query('.')
	    FROM @xmlTags.nodes('MyControlTunnel') AS T(c);

	    SELECT @MachineInternalID = T.c.value('@MachineNumber', 'int')
	    FROM @TempXML.nodes('MyControlTunnel') AS T(c);
	    SELECT @EcolabWasherID = EcolabWasherId,
			 @WasherGroupID = Wg.WasherGroupId,
			 @PlantWasherNumber = PlantWasherNumber,
			 @WasherID = ws.WasherId,
			 @CurrencyCode = P.CurrencyCode,
			 @NumberOfCompartments = Mst.NumberofComp
	    FROM TCD.Washer AS Ws
		    INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = Ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.
		    GroupId
		    INNER JOIN TCD.WasherGroupType AS WgT ON WgT.
		    WasherGroupTypeId = Wg.WasherGroupTypeId
		    INNER JOIN TCD.ConduitController AS Ctrl ON Ctrl.
		    ControllerId = Mst.ControllerId
		    INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.
		    EcoLabAccountNumber
	    WHERE Ctrl.ControllerID = @ControllerID
			AND mst.MachineInternalId = @MachineInternalID
			AND Mst.IsTunnel = 1 AND Mst.IsDeleted =0;
	    SET @compartmentID = @NumberOfCompartments;
	    WHILE(@compartmentID <= @NumberOfCompartments
			AND @compartmentID > 0)
		   BEGIN
			  SELECT @TunnelXML = T.c.query('.')
			  FROM @xmlTags.nodes('MyControlTunnel/TunnelData') AS T(c)
			  WHERE T.c.value('@CompartmentNumber', 'INT') =
			  @compartmentID;
			  SELECT @MachineInternalID = T.c.value('@MachineNumber',
			  'int'
										    ),
				    @BatchNumber = T.c.value('@BatchNumber', 'INT'),
				    @BatchStartTime = T.c.value('@StartDateTime',
				    'DateTime'
										 ),
				    @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
				    @Load = T.c.value('@Load', 'Decimal(10,6)'),
				    @NominalLoad = T.c.value('@Nominalload',
				    'Decimal(10,6)'
									   ),
				    @CustomerNumber = T.c.value('@CustomerNumber',
				    'int'
										 ),
				    @PHStatus = T.c.value('@pHStatus', 'int')
			  FROM @TunnelXML.nodes('TunnelData') AS T(c);

			  --Check for valid startdatetime
			IF(@BatchStartTime <='01/01/1900' OR @BatchStartTime > '06/06/2079')
			BEGIN
				return
			END

			  DECLARE @ShiftStartDateTemp TABLE
			  (
				  ShiftId        INT,
				  ShiftName      NVARCHAR(50),
				  ShiftStartdate DATETIME
			  );
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchStartTime
			  SELECT @BatchShiftId = ShiftID,
				    @PartitionOn = ShiftStartdate
			  FROM @ShiftStartDateTemp;
			  IF(@ProgramNumber = 0)
				--OR @BatchNumber = 1)
				 BEGIN
					SELECT @compartmentID = @compartmentID - 1;
					CONTINUE;
				 END;
			  SELECT @ProgramID = ProgramId,
				    @TargetTurnTime = 3600 / (tps.TotalRunTime /
				    @NumberOfCompartments)
			  FROM TCD.TunnelProgramSetup AS tps
			  WHERE tps.WasherGroupId = @WasherGroupID
				   AND tps.is_deleted = 0
				   AND ProgramNumber = @ProgramNumber;
			  INSERT INTO #Batches
			  (BatchNumber,
			   StartDateTime
			  )
				    SELECT @BatchNumber,
						 @BatchStartTime;
			  SELECT @BatchID = NULL;
			  SELECT @BatchID = BatchID
			  FROM TCD.BatchData AS BD
			  WHERE BD.ControllerBatchId = @BatchNumber
				   AND BD.StartDate = @BatchStartTime
				   AND BD.MachineId = @WasherID;
			  --Start Getting InjectionCount,StepCount And ProductCount
			  SELECT @StdInjectionSteps = COUNT(tdpm.
			  TunnelDosingSetupId),
				    @StdWashSteps = COUNT(DISTINCT tds.
				    TunnelDosingSetupId) - COUNT(tdpm.
				    TunnelDosingSetupId)
			  FROM tcd.TunnelDosingProductMapping AS tdpm
				  RIGHT JOIN tcd.TunnelDosingSetup AS tds ON tdpm.
				  TunnelDosingSetupId = tds.TunnelDosingSetupId
			  WHERE tds.GroupId = @WasherGroupID
				   AND tds.ProgramNumber = @ProgramNumber;
			  --End Getting InjectionCount,StepCount And ProductCount
			  --Start-----ProgramMasterID logic for PlantChainProgram
			  SELECT @PlantProgramId = pm.PlantProgramId,
				    @EcolabTextileCategoryId = pm.
				    EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pm.ChainTextileId,
				    @FormulaSegmentId = pm.FormulaSegmentId,
				    @EcolabSaturationId = pm.EcolabSaturationId
			  FROM TCD.ProgramMaster AS pm
			  WHERE pm.ProgramId = @ProgramID
				   AND pm.Is_Deleted = 0;
			  IF(@PlantProgramId <> 0
				OR @PlantProgramId IS NOT NULL)
				 BEGIN
					--Assign value from plantchainprogram table based on plantprogramId
					SELECT @EcolabTextileCategoryId = pcp.
					EcolabTextileCategoryId,
						  @ChainTextileCategoryId = pcp.
						  ChainTextileCategoryId,
						  @FormulaSegmentId = pcp.FormulaSegmentId,
						  @EcolabSaturationId = pcp.
						  EcolabSaturationId
					FROM tcd.PlantChainProgram AS pcp
					WHERE pcp.PlantProgramId = @PlantProgramId
						 AND pcp.Is_Deleted = 0;
				 END;
			  --End-----ProgramMasterID logic for PlantChainProgram
			  IF @BatchID IS NULL
				 BEGIN
					INSERT INTO TCD.BatchData
					(ControllerBatchId,
					 EcolabWasherId,
					 GroupId,
					 MachineInternalId,
					 PlantWasherNumber,
					 StartDate,
					 ProgramNumber,
					 ProgramMasterId,
					 MachineId,
					 ActualWeight,
					 StandardWeight,
					 CurrencyCode,
					 ShiftId,
					 PartitionOn,
					 TargetTurnTime,
					 StdInjectionSteps,
					 StdWashSteps,
					 EcolabTextileCategoryId,
					 ChainTextileCategoryId,
					 FormulaSegmentId,
					 EcolabSaturationId,
					 PlantProgramId
					)
						  SELECT @BatchNumber,
							    @EcolabWasherID,
							    @WasherGroupID,
							    @MachineInternalID,
							    @PlantWasherNumber,
							    @BatchStartTime,
							    @ProgramNumber,
							    @ProgramID,
							    @WasherID,
							    @Load,
							    @NominalLoad,
							    @CurrencyCode,
							    @BatchShiftId,
							    @PartitionOn,
							    @TargetTurnTime,
							    @StdInjectionSteps,
							    @StdWashSteps,
							    @EcolabTextileCategoryId,
							    @ChainTextileCategoryId,
							    @FormulaSegmentId,
							    @EcolabSaturationId,
							    @PlantProgramId;
					SELECT @BatchID = SCOPE_IDENTITY();
					IF(@StdWashSteps > 0
					   OR @StdWashSteps <> NULL)
					    BEGIN
						   INSERT INTO TCD.BatchParameters
						   (BatchId,
						    EcolabWasherId,
						    ParameterId,
						    ParameterValue,
						    PartitionOn
						   )
								SELECT @BatchID,
									  @EcolabWasherId,
									  38,
									  @StdWashSteps,
									  @PartitionOn;
					    END;
					IF @CustomerNumber IS NOT NULL
					    BEGIN
						   IF NOT EXISTS
						   (
							  SELECT 1
							  FROM TCD.BatchCustomerData
							  WHERE BatchID = @BatchID
						   )
							  BEGIN
								 INSERT INTO TCD.BatchCustomerData
								 (BatchId,
								  CustomerID,
								  Weight,
								  PartitionOn,
								  EcolabWasherId
								 )
									   SELECT @BatchID,
											@CustomerNumber,
											@Load,
											@PartitionOn,
											@EcolabWasherId;
							  END;
					    END;
				 END;
			  -- Transfer Signal
			  IF NOT EXISTS
			  (
				 SELECT *
				 FROM tcd.WasherReading wr
				 WHERE wr.WasherId = @WasherID
					  AND wr.ParameterId = @TransferSignalId
					  AND wr.DateTimeStamp = @BatchStartTime
			  )
				 BEGIN
					INSERT INTO TCD.WasherReading
					(WasherId,
					 ParameterId,
					 ParameterValue,
					 DateTimeStamp,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @WasherID,
							    @TransferSignalId,
							    1,
							    @BatchStartTime,
							    @PartitionOn,
							    @EcolabWasherId
						  UNION ALL
						  SELECT @WasherID,
							    @TransferSignalId,
							    0,
							    @BatchStartTime,
							    @PartitionOn,
							    @EcolabWasherId;
				 END;
			  --Start Updating Batch Wash Step Data	 
			  EXEC TCD.UPDATEBatchWashStepForTunnel
				  @TunnelXML,
				  @WasherID,
				  @BatchID,
				  @BatchStartTime,
				  @PartitionOn,
				  @EcolabWasherId,
				  @compartmentID;
			  --End Updating Batch Wash Step Data	 
			  SELECT @compartmentID = @compartmentID - 1;
		   END;


	 --Start water consumption per step


   CREATE TABLE #WaterConsumptionData
     (
      Number          INT,
      Quantity        DECIMAL(10,6),
     );
     INSERT INTO #WaterConsumptionData
     (Number,
  Quantity
     )
    SELECT T.c.value('@Counter', 'INT') AS Number, --PumpNumber
       T.c.value('@Value', 'DECIMAL(10,6)') AS Quantity --Water Quanity
    FROM @xmlTags.nodes('MyControlTunnel/TunnelData/WaterConsumption') T(C);

  SET @CurrentStepComportmentNO=1;
  WHILE(@CurrentStepComportmentNO<=22)
  BEGIN
   SELECT @MeterID=MeterId,@CounterNO=mt.CounterNum
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@CurrentStepComportmentNO;
   SELECT @ActualQuantity=wc.Quantity
  FROM #WaterConsumptionData wc where wc.Number=@CounterNO
  SELECT @WasherModuleCount=COUNT(1) FROM TCD.WasherModuleOnlineUsageData WHERE WasherId = @WasherID AND StepComportment =@CurrentStepComportmentNO AND ModuleId = @MeterID AND ActualQuantity=@ActualQuantity
  IF(@WasherModuleCount=0)
  BEGIN
  IF(ISNULL(@WasherID,0)>0 AND ISNULL(@MeterID,0)>0 AND ISNULL(@ActualQuantity,0)>0 AND ISNULL(@CurrentStepComportmentNO,0)>0)
  BEGIN
   INSERT INTO TCD.WasherModuleOnlineUsageData
     (WasherId,
      StepComportment,
      ModuleId,
      ActualQuantity,
      TimeStamp,
      EcolabWasherId
     )
     SELECT
     @WasherID,
     @CurrentStepComportmentNO,
     @MeterID,
     @ActualQuantity,
     GETUTCDATE(),
     @EcolabWasherId
      END  

	  END
        SET  @CurrentStepComportmentNO=@CurrentStepComportmentNO+1;
   
  END;
 END;
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMyControlTunnelWasherProdData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMyControlTunnelWasherProdData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ProcessMyControlTunnelWasherProdData](
	@ControllerID   INT,
	@xmlTags        XML,
	@PLCPointer     INT,
	@ReadPointer    INT,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @BatchID                 INT,
			  @WasherID                  INT,
			  @EcolabWasherId            INT,
			  @CurrencyCode              VARCHAR(50),
			  @MachineInternalId         INT,
			  @WasherGroupID             INT,
			  @PlantWasherNumber         INT,
			  @ProgramNumber             INT,
			  @Load                      DECIMAL(10, 2),
			  @NominalLoad               DECIMAL(10, 2),
			  @CustomerNumber            INT,
			  @PHStatus                  INT,
			  @PHValue                   INT,
			  @LFStatus                  INT,
			  @LFValue                   INT,
			  @BatchNumber               INT,
			  @TargetTurnTime            INT,
			  @PartitionOn               DATETIME2,
			  @BatchStartTime            DATETIME2,
			  @BatchEndTime              DATETIME2,
			  @ProgramID                 INT,
			  @NumberOfCompartments      INT,
			  @ProductId                 INT,
			  @CompartmentNum            INT,
			  @EquipmentType             INT,
			  @MinTempParamID            INT,
			  @MaxTempParamID            INT,
			  @TempStatusParamID         INT,
			  @PHValueParamID            INT,
			  @PHStatusParamID           INT,
			  @ConductivityValueParamID  INT,
			  @ConductivityStatusParamID INT,
			  @StdInjectionSteps         INT,
			  @StdWashSteps              INT,
			  @ActualInjSteps            INT,
			  @EcolabTextileCategoryId   INT,
			  @ChainTextileCategoryId    INT,
			  @FormulaSegmentId          INT,
			  @EcolabSaturationId        INT,
			  @PlantProgramId            INT,
			  @PreviousShiftId		    INT,
			  @CurrentShiftId		    INT,
			  @CurrentStepComportmentNO INT,
              @CounterNO                INT,
               @MeterID                 INT,
              @ActualQuantity          DECIMAL(10,6),
			  @BatchStepCount         INT,
			  @EcolabAccountNumber   VARCHAR(100),
			  @AlarmGroupMasterId    INT,
			  @StandardQuantity          DECIMAL(18, 4),
			  @Price                     DECIMAL(18, 4);

	    DECLARE @BatchShiftId INT;
	    DECLARE @ShiftStartDateTemp TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    DECLARE @TunnelXML XML;
	    SELECT @TunnelXML = T.c.query('.')
	    FROM @xmlTags.nodes('MyControlTunnel/TunnelData') T(c)
	    WHERE T.c.value('@CompartmentNumber', 'INT') = 0;

		
	    SELECT @MachineInternalID = T.c.value('@MachineNumber', 'int'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @BatchStartTime = T.c.value('@StartDateTime', 'DateTime'),
			 @BatchEndTime = T.c.value('@EndDateTime', 'DateTime'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@Nominalload', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'int'),
			 @PHStatus = T.c.value('@Phstatus', 'int'),
			 @PHValue = T.c.value('@Phvalue', 'INT'),
			 @LFStatus = T.c.value('@LFStatus', 'INT'),
			 @LFValue = T.c.value('@LFValue', 'INT')
	    FROM @xmlTags.nodes('MyControlTunnel/TunnelData') T(c);

		--Check for valid startdatetime
		IF(@BatchStartTime <='01/01/1900' OR @BatchStartTime > '06/06/2079')
		BEGIN
			return
		END

	    SELECT @EcolabWasherID = Ws.EcolabWasherId,
			 @WasherGroupID = Wg.WasherGroupId,
			 @PlantWasherNumber = PlantWasherNumber,
			 @WasherID = ws.WasherId,
			 @CurrencyCode = P.CurrencyCode,
			 @NumberOfCompartments = Mst.NumberofComp
	    FROM TCD.Washer Ws
		    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.
		    GroupId
		    INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId
		    = Wg.WasherGroupTypeId
		    INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId =
		    Mst.ControllerId
		    INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.
		    EcoLabAccountNumber
	    WHERE Ctrl.ControllerID = @ControllerID
			AND Mst.MachineInternalId = @MachineInternalID
			AND Mst.IsTunnel = 1 AND Mst.IsDeleted=0;
	    SELECT @EcolabWasherID;
	    SELECT @ProgramID = ProgramId,
			 @TargetTurnTime = (3600 / (tps.TotalRunTime /
			 @NumberOfCompartments))
	    FROM TCD.TunnelProgramSetup AS tps
	    WHERE tps.WasherGroupId = @WasherGroupID
			AND tps.is_deleted = 0
			AND ProgramNumber = @ProgramNumber;
	    DELETE FROM @ShiftStartDateTemp;
	    IF(@BatchEndTime IS NOT NULL)
		   BEGIN
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchEndTime
		   END;
	    ELSE
		   BEGIN
			  INSERT INTO @ShiftStartDateTemp
			  (ShiftId,
			   ShiftName,
			   ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchStartTime
		   END;
	    SELECT @BatchShiftId = ShiftID,
			 @PartitionOn = ShiftStartdate
	    FROM @ShiftStartDateTemp;


	    --Start Getting InjectionCount,StepCount And ProductCount
	    SELECT @StdInjectionSteps = COUNT(tdpm.TunnelDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT tds.TunnelDosingSetupId) -
			 COUNT(tdpm.TunnelDosingSetupId)
	    FROM tcd.TunnelDosingProductMapping tdpm
		    RIGHT JOIN tcd.TunnelDosingSetup tds ON tdpm.
		    TunnelDosingSetupId = tds.TunnelDosingSetupId
	    WHERE tds.GroupId = @WasherGroupID
			AND tds.ProgramNumber = @ProgramNumber;
	    --End Getting InjectionCount,StepCount And ProductCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramID
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT @EcolabTextileCategoryId = pcp. EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp. ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    SELECT @BatchID = NULL;
	    SELECT @BatchID = BatchID
	    FROM TCD.BatchData BD
	    WHERE BD.ControllerBatchId = @BatchNumber
			AND BD.StartDate = @BatchStartTime
			AND BD.MachineId = @WasherID;
	    --AND BD.MachineInternalID = @MachineInternalID
	    IF(@BatchID IS NULL)
		   BEGIN
		   --Start Rollup for previous completed shift
	   IF(CAST(@BatchStartTime as date) < CAST(GETUTCDATE() as date))
	   BEGIN
		  SELECT TOP 1 @PreviousShiftId=ShiftId FROM TCD.BatchData WHERE MachineId=@WasherId ORDER BY StartDate DESC	   
		  SELECT Top 1 @CurrentShiftId = ShiftId from @ShiftStartDateTemp
		  IF(@CurrentShiftId != @PreviousShiftId)
		  BEGIN
			 EXEC TCD.ProductionShiftDataRollup @PreviousShiftId, @RedFlagShiftId OUTPUT
			 IF(@RedFlagShiftId IS NULL)
			 BEGIN
				SET @RedFlagShiftId = @PreviousShiftId
			 END
		  END
	   END
	   --End Rollup for previous completed shift
			  INSERT INTO TCD.BatchData
			  (ControllerBatchId,
			   EcolabWasherId,
			   GroupId,
			   MachineInternalId,
			   PlantWasherNumber,
			   StartDate,
			   EndDate,
			   ProgramNumber,
			   ProgramMasterId,
			   MachineId,
			   ActualWeight,
			   StandardWeight,
			   CurrencyCode,
			   ShiftId,
			   PartitionOn,
			   TargetTurnTime,
			   StdInjectionSteps,
			   StdWashSteps,
			   EcolabTextileCategoryId,
			   ChainTextileCategoryId,
			   FormulaSegmentId,
			   EcolabSaturationId,
			   PlantProgramId,
			   EndDateFormula
			  )
				    SELECT @BatchNumber,
						 @EcolabWasherID,
						 @WasherGroupID,
						 @MachineInternalID,
						 @PlantWasherNumber,
						 @BatchStartTime,
						 @BatchEndTime,
						 @ProgramNumber,
						 @ProgramID,
						 @WasherID,
						 @Load,
						 @NominalLoad,
						 @CurrencyCode,
						 @BatchShiftId,
						 @PartitionOn,
						 @TargetTurnTime,
						 @StdInjectionSteps,
						 @StdWashSteps,
						 @EcolabTextileCategoryId,
						 @ChainTextileCategoryId,
						 @FormulaSegmentId,
						 @EcolabSaturationId,
						 @PlantProgramId,
						 @BatchEndTime;
			  SELECT @BatchID = SCOPE_IDENTITY();
			  IF(@StdWashSteps > 0
				OR @StdWashSteps <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchID,
							@EcolabWasherId,
							38,
							@StdWashSteps,
							@PartitionOn;
			  EXEC TCD.UPDATEBatchWashStepForTunnel
				  @TunnelXML,
				  @WasherID,
				  @BatchID,
				  @BatchStartTime,
				  @PartitionOn,
				  @EcolabWasherId,
				  @NumberOfCompartments;
		   END;
	    IF(@BatchEndTime IS NOT NULL
		  AND @BatchEndTime != '01/01/1900')
		   BEGIN
			  UPDATE TCD.BatchData
			    SET
				   EndDate = @BatchEndTime,
				   ShiftId = @BatchShiftId,
				   PartitionOn = @PartitionOn,
				   EndDateFormula=@BatchEndTime
			  WHERE BATCHID = @BatchID;
		   END;

		      --If the received formula is not configured in enVision then create an alarm 
       IF(@ProgramID is NULL)
       BEGIN
       SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant;
       SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.AlarmGroupMsterVsControllerModelType AGMVCMT
       INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
       WHERE AGMVCMT.AlarmCode = 9000
        INSERT INTO [TCD].[AlarmData] 
           (EcoalabAccountNumber,
           AlarmCode,
           BatchId,
           controllerID,
           StartDate,
           GroupId,
           MachineInternalId,
           ProgramId,   
           IsActive,
           EndDate,
           MachineId,
           AlarmGroupMasterId)
           SELECT
            @ECOLABAccountNumber,
            9000,
            @BatchID,
            @ControllerId,
            @BatchStartTime,
            @WasherGroupID,
            @MachineInternalID,
            @ProgramNumber,
            0,
            @BatchStartTime,
            @WasherId,
            @AlarmGroupMasterId
       END


	    IF(@CustomerNumber IS NOT NULL)
		   BEGIN
			  IF NOT EXISTS
			  (
				 SELECT 1
				 FROM [TCD].[BatchCustomerData]
				 WHERE BatchID = @BatchID
			  )
				 BEGIN
					INSERT INTO [TCD].[BatchCustomerData]
					([BatchId],
					 CustomerID,
					 [Weight],
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @BatchID,
							    @CustomerNumber,
							    @Load,
							    @PartitionOn,
							    @EcolabWasherId;
				 END;
		   END;
	    CREATE TABLE #DosingDetails
	    (
		    Number          INT,
		    Quantity        DECIMAL(10, 6),
		    Point           INT,
		    IsMainEquioment INT
	    );
	    INSERT INTO #DosingDetails
	    (Number,
		Quantity,
		Point,
		IsMainEquioment
	    )
			 SELECT T.c.value('@Number', 'INT') AS Number, --PumpNumber
				   T.c.value('@Quantity', 'Decimal(10,6)') AS Quantity, --Dosing Quanity
				   T.c.value('@Point', 'INT') AS Point, --Dosing point
				   T.c.value('@IsMainEquioment', 'INT') AS
			 IsMainEquioment
			 FROM @xmlTags.nodes('MyControlTunnel/TunnelData/Dose') T(C)
	    ;
	
	    -- Fetching data from cursor
	    DECLARE @MYCURSOR CURSOR;
	    SET @MYCURSOR = CURSOR FAST_FORWARD
	    FOR SELECT Number,
				Quantity,
				Point,
				IsMainEquioment
		   FROM #DosingDetails;
	    DECLARE @Number          INT,
			  @Quantity        DECIMAL(10, 6),
			  @Point           INT,
			  @IsMainEquioment INT;
	    OPEN @MYCURSOR;
	    FETCH NEXT FROM @MYCURSOR INTO @Number,
								@Quantity,
								@Point,
								@IsMainEquioment;
	    WHILE @@FETCH_STATUS = 0
		   BEGIN
			  IF(@IsMainEquioment = 1)
				 BEGIN
					SET @EquipmentType = 2;
				 END;
			  ELSE
				 BEGIN
					SET @EquipmentType = 1;
				 END;
			  SELECT @ProductId = CES.ProductId,
				    @CompartmentNum = TCEVM.CompartmentNumber
			  FROM tcd.ControllerEquipmentSetup CES
				  INNER JOIN TCD.
				  TunnelCompartmentEquipmentValveMapping TCEVM ON CES.
				  ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
			  WHERE CES.ControllerId = @ControllerID
				   AND CES.ControllerEquipmentTypeId = @EquipmentType
				   AND --CES.IsActive=1 AND
				   --CES.WasherGroupNumber=@WasherGroupNum AND
				   TCEVM.DosingPointNumber = @Point
				   AND CES.ControllerEquipmentId = @Number;
				
			 SELECT DISTINCT
				    @StandardQuantity =((Wps.NominalLoad * Wdpm.Quantity) / 100),
				    @Price = (((Wps.NominalLoad * Wdpm.Quantity) / 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID))
			  FROM TCD.Washer WS
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =Mst.GroupId
				  INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
				  INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
				  INNER JOIN TCD.TunnelDosingSetup Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
				  INNER JOIN TCD.TunnelDosingProductMapping Wdpm ON
				  Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
				  INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId = Wdpm.ControllerEquipmentSetupId
				  INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId = Ces.ProductId
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wds.CompartmentNumber = @CompartmentNum
				   AND Wps.Is_Deleted = 0
				   AND Pdm.Is_Deleted = 0;
				
			  IF(@ProductId IS NOT NULL)
				 BEGIN
					INSERT INTO TCD.BatchProductData
					(
						  BatchId,
						  StepCompartment,
						  ActualQuantity,
						  StandardQuantity,
						  Price,
						  [TimeStamp],
						  PartitionOn,
						  EcolabWasherId,
						  ProductId
					)
					SELECT
						  @BatchID,
						  @CompartmentNum,
						  @Quantity,
						  isnull(@StandardQuantity,0),
						  isnull(@Price,0),
						  @BatchEndTime,
						  @PartitionOn,
						  @EcolabWasherID,
						  @ProductId;
				 END;
			  FETCH NEXT FROM @MYCURSOR INTO @Number,
									   @Quantity,
									   @Point,
									   @IsMainEquioment;
		   END;
	    CLOSE @MYCURSOR;
	    DEALLOCATE @MYCURSOR;
	    DROP TABLE #DosingDetails;
	    SELECT @ActualInjSteps = COUNT(DISTINCT StepCompartment)
	    FROM TCD.BatchProductData
	    WHERE BatchId = @BatchID;
	    IF NOT EXISTS
	    (
		   SELECT *
		   FROM TCD.BatchParameters
		   WHERE ParameterId = 37
			    AND batchid = @BatchID
			    AND @ActualInjSteps > 0
	    )
		   BEGIN
			  IF(@ActualInjSteps > 0
				OR @ActualInjSteps <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
					   SELECT @BatchId,
							@EcolabWasherId,
							37,
							@ActualInjSteps,
							@PartitionOn;
		   END;
	    ELSE
		   BEGIN
			  UPDATE TCD.BatchParameters
			    SET
				   ParameterValue = @ActualInjSteps
			  WHERE ParameterId = 37
				   AND batchid = @BatchID;
		   END;
	    SELECT @MinTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Mimum Temperature';
	    SELECT @MaxTempParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Maximum Temperature';
	    SELECT @TempStatusParamID = Id
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Temperature Status';
	    SELECT @PHValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH';
	    SELECT @PHStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'PH Status';
	    SELECT @ConductivityValueParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'Conductivity';
	    SELECT @ConductivityStatusParamID = ID
	    FROM [TCD].[ConduitParameters]
	    WHERE Name = 'LF Status';
	    IF(@PHValue IS NOT NULL)
		   BEGIN
			  --pH Value
			  IF(@PHValue <> 0
				OR @PHValue <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @PHValueParamID,
					   @PHValue,
					   @PartitionOn
				 );

			  --pH Status
			  IF(@PHStatus <> 0
				OR @PHStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @PHStatusParamID,
					   @PHStatus,
					   @PartitionOn
				 );
		   END;
	    IF(@LFValue IS NOT NULL)
		   BEGIN
			  --Conductivity Value
			  IF(@LFValue <> 0
				OR @LFValue <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @ConductivityValueParamID,
					   @LFValue,
					   @PartitionOn
				 );

			  --Conductivity Status
			  IF(@LFStatus <> 0
				OR @LFStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @ConductivityStatusParamID,
					   @LFStatus,
					   @PartitionOn
				 );
		   END;
	    CREATE TABLE #TemperatureDetails
	    (
		    MinimumTemp DECIMAL(10, 2),
		    MaximumTemp DECIMAL(10, 2),
		    TempStatus  DECIMAL(10, 2)
	    );
	    INSERT INTO #TemperatureDetails
	    (MinimumTemp,
		MaximumTemp,
		TempStatus
	    )
			 SELECT T.c.value('@Minimum', 'Decimal(10,2)') AS
			 MinimumTemp,
				   T.c.value('@Maximum', 'Decimal(10,2)') AS
				   MaximumTemp,
				   T.c.value('@Status', 'Decimal(10,2)') AS TempStatus
			 FROM @xmlTags.nodes(
			 'MyControlTunnel/TunnelData/TemperatureData'
							) T(c);
	  
	    -- Fetching data from cursor
	    DECLARE @TEMPCURSOR CURSOR;
	    SET @TEMPCURSOR = CURSOR FAST_FORWARD
	    FOR SELECT MinimumTemp,
				MaximumTemp,
				TempStatus
		   FROM #TemperatureDetails;
	    DECLARE @MinimumTemp DECIMAL(10, 2),
			  @MaximumTemp DECIMAL(10, 2),
			  @TempStatus  DECIMAL(10, 2);
	    OPEN @TEMPCURSOR;
	    FETCH NEXT FROM @TEMPCURSOR INTO @MinimumTemp,
								  @MaximumTemp,
								  @TempStatus;
	    WHILE @@FETCH_STATUS = 0
		   BEGIN	
			  --Minimum Temperature
			  IF(@MinimumTemp <> 0
				OR @MinimumTemp <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @MinTempParamID,
					   @MinimumTemp,
					   @PartitionOn
				 );

			  --Maximum Temperature
			  IF(@MaximumTemp <> 0
				OR @MaximumTemp <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @MaxTempParamID,
					   @MaximumTemp,
					   @PartitionOn
				 );

			  --Temperature Status
			  IF(@TempStatus <> 0
				OR @TempStatus <> NULL)
				 INSERT INTO TCD.BatchParameters
				 (BatchId,
				  EcolabWasherId,
				  ParameterId,
				  ParameterValue,
				  PartitionOn
				 )
				 VALUES
				 (
					   @BatchID,
					   @EcoLabWasherID,
					   @TempStatusParamID,
					   @TempStatus,
					   @PartitionOn
				 );
			  FETCH NEXT FROM @TEMPCURSOR INTO @MinimumTemp,
										@MaximumTemp,
										@TempStatus;
		   END;
	    CLOSE @TEMPCURSOR;
	    DEALLOCATE @TEMPCURSOR;
	    DROP TABLE #TemperatureDetails;
	    UPDATE TCD.BatchWashStepData
		 SET
			EndTime = DATEADD(ss,
						  (SELECT T.c.value('@Time', 'INT')
							 FROM @TunnelXML.nodes('TunnelData/CompartmentTime') T(c)
							 WHERE T.c.value('@CompartmentNo','INT') =
							 (
								SELECT
									  bwsd.StepCompartment
								FROM tcd.BatchWashStepData bwsd
								WHERE bwsd.BatchId = @BatchID
									 AND bwsd.EndTime IS NULL
							 )
						  ),
						  (
							 SELECT
								   bwsd.StartTime
							 FROM tcd.BatchWashStepData bwsd
							 WHERE bwsd.BatchId = @BatchID
								  AND bwsd.EndTime IS NULL
						  ))
	    WHERE
			BatchId = @BatchID
			AND EndTime IS NULL;
   
   --Start water consumption per batch


    CREATE TABLE #WaterConsumptionData
     (
      Number          INT,
      Quantity        DECIMAL(10,6),
     );
     INSERT INTO #WaterConsumptionData
     (Number,
  Quantity
     )
    SELECT T.c.value('@Counter', 'INT') AS Number, --PumpNumber
       T.c.value('@Value', 'DECIMAL(10,6)') AS Quantity --Water Quanity
    FROM @xmlTags.nodes('MyControlTunnel/TunnelData/WaterConsumption') T(C);

  
  SET @CurrentStepComportmentNO=1;

  WHILE(@CurrentStepComportmentNO<=22)
  BEGIN
  
   SELECT @MeterID=MeterId,@CounterNO=mt.CounterNum
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@CurrentStepComportmentNO

    SELECT @ActualQuantity=wc.Quantity
  FROM #WaterConsumptionData wc where wc.Number=@CounterNo
  SELECT @BatchStepCount=COUNT(1) FROM TCD.BatchStepWaterUsageData WHERE BatchId=@BatchID  AND StepCompartment =@CurrentStepComportmentNO AND ActualQuantity=@ActualQuantity 
  IF (@BatchStepCount=0)
  BEGIN
  IF(ISNULL(@BatchID,0)>0  AND ISNULL(@MeterID,0)>0 AND ISNULL(@ActualQuantity,0)>0)
  BEGIN

   INSERT INTO TCD.BatchStepWaterUsageData
     (BatchId,
      StepCompartment,
      ActualQuantity,
      PartitionOn,
      EcolabWasherId
     )
     SELECT
     @BatchID,
     @CurrentStepComportmentNO,
     @ActualQuantity,
     @PartitionOn,
     @EcolabWasherId
      END 
	  END 
      SET  @CurrentStepComportmentNO=@CurrentStepComportmentNO+1;  
  END;
 END;
Go
  ----------------------------------------------------------DCS Process Mycontrol End----------------------------------------------------------------------

-------------------------------------------PLC XL Batch Product data changes Start--------------------------------------------------------------
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[ProcessMitsubishiTunnelWasherProdData]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessMitsubishiTunnelWasherProdData]
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [TCD].[ProcessMitsubishiTunnelWasherProdData]
 (
  @ControllerID INT,
  @xmlTags xML
 )
AS
BEGIN
   DECLARE 
   @BatchID      INT,
   @WasherID      INT,
   @EcolabWasherId     INT,
   @CurrencyCode     VARCHAR(50),  
   @MachineInternalId    INT,
   @WasherGroupID     INT,
   @WasherGroupNum     INT,
   @PlantWasherNumber    INT,
   @BatchStartDate     DATETIME2,
   @BatchEndDate     DATETIME2,   
   @ProgramNumber     INT,
   @Load       Decimal(10,2),
   @NominalLoad     Decimal(10,2),
   @CustomerNumber     INT,
   @PHStatus      INT,
   @PHValue      INT,
   @LFStatus      INT,
   @LFValue      INT,
   @EjectionSignal     INT,
   @TextTileCategory    INT,
   @BatchNumber     INT,
   @TargetTurnTime     INT,
   @ShiftID      INT,
   @ParameterID     INT,   
   @ShiftName      VARCHAR(50),
   @EcolabAccountNumber NVARCHAR(25) = NULL,
   @PartitionOn DateTime,
   @BatchStartTime DateTime,
   @BatchEndTime DateTime,
   @PorgramParameterID int,
   @PHParameterID int,
   @ConductivityParamID int,
   @RunTime int,
   @TextileCategory int,
   @ProgramID int,
   @NumberOfCompartments int,
   @TempParameter int,
   @PumpNo   INT, 
   @DosingPoint INT,
   @ProductId INT,
   @CompartmentNum INT,
   @MinTempParamID INT,
   @MaxTempParamID INT,
   @TempStatusParamID INT,
   @PHValueParamID INT,
   @PHStatusParamID INT,
   @ActualInjSteps INT
   
    
 --INSERT into MyControlXML (xmlData, BatchType, PLCPointer, ReadPointer, BatchID, comment,LastModified) values (@xmlTags, 'TunnelCompleted', null, null, null, '',getDate())

    SELECT @PorgramParameterID=ID
 FROM TCD.ConduitParameters WHERE NAME ='Formula Number'

 SELECT @PHParameterID=ID
 FROM TCD.ConduitParameters WHERE NAME ='pH'

 SELECT @ConductivityParamID=ID
 FROM TCD.ConduitParameters WHERE NAME ='Conductivity'

 CREATE TABLE #Batches(BatchNumber int,StartDateTime DateTime)
    
 DECLARE @BatchShiftId int
 DECLARE @ShiftStartDateTemp table(ShiftId INT,ShiftName NVARCHAR(50),ShiftStartdate DATETIME)

 DECLARE @compartmentID int,
   @TunnelXML xml
   
   
 SELECT @compartmentID = 1
 SELECT @WasherID=null;
    
   
    SELECT @TunnelXML=T.c.query('.') 
  FROM   @xmlTags.nodes('MyControlTunnel/TunnelData') T(c)
  WHERE T.c.value('@CompartmentNumber', 'INT') = 20


   SELECT   
      --@MachineInternalID=T.c.value('@MachineNumber', 'int'),
      @BatchNumber= T.c.value('@BatchNumber', 'INT'),
       @BatchStartTime=T.c.value('@StartDateTime', 'DateTime'),
      @BatchEndTime=T.c.value('@EndDateTime', 'DateTime'),
      @ProgramNumber=T.c.value('@ProgramNumber', 'INT'),
      @Load=T.c.value('@Load', 'Decimal(10,2)')/10,
      @NominalLoad=T.c.value('@Nominalload', 'Decimal(10,2)'),
      @WasherGroupNum=T.c.value('@GroupNumber', 'int'),
      @CustomerNumber=T.c.value('@CustomerNumber', 'int'),
      @PHStatus=T.c.value('@pHStatus', 'int'),
      @PHValue=T.c.value('@pHValue', 'INT'),
      @LFStatus=T.c.value('@LFStatus', 'INT'),
      @LFValue=T.c.value('@LFValue', 'INT'),
      @RunTime=T.c.value('@RunTime', 'INT'),
      @EjectionSignal=T.c.value('@EjectionSignal', 'INT'),
      @TextileCategory=T.c.value('@TextileCategory', 'INT')
   FROM @TunnelXML.nodes('TunnelData')  T(c);
   

    
  
  SELECT @WasherGroupID= Wg.WasherGroupId
  FROM TCD.WasherGroup Wg 
  WHERE ControllerID = @ControllerID 
		AND WasherDosingNumber = @WasherGroupNum 
		AND WasherGroupTypeId = 2


   print '@WasherGroupID = ' + isNull(Convert(nvarchar(10),@WasherGroupID),'Null')
   
   
   SELECT @ProgramID=ProgramId,
    @TargetTurnTime= (3600 / (tps.TotalRunTime /@NumberOfCompartments )) 
   FROM TCD.TunnelProgramSetup AS tps 
   WHERE tps.WasherGroupId = @WasherGroupID 
      and tps.is_deleted =0
      and ProgramNumber = @ProgramNumber

 
   print '@ProgramID = ' + isNull(Convert(nvarchar(10),@ProgramID),'Null')
   
       

  SELECT @BatchID = Null

  SELECT @BatchID=BatchID, @WasherID=MachineId, @BatchStartTime=StartDate, @EcolabWasherId=EcolabWasherId
   FROM TCD.BatchData
   WHERE ControllerBatchId = @BatchNumber
     AND GroupId = @WasherGroupID 
     AND CAST(StartDate as date)=CAST(@BatchStartTime as date)

   print '@BatchID = ' + isNull(Convert(nvarchar(10),@BatchID),'Null')
   print '@WasherID/MachineId = ' + isNull(Convert(nvarchar(10),@WasherID),'Null')
   print '@EcolabWasherId/@EcolabWasherId= ' + isNull(Convert(nvarchar(10),@EcolabWasherId),'Null')
   if ( @BatchID is Null) return ;
   	print '*********Batch End Date: ' + Convert(nvarchar(10),@BatchEndTime)
  IF (@BatchID is NOT Null) 
  BEGIN
   IF (@BatchEndTime is Not Null)
   BEGIN
     
    INSERT INTO @ShiftStartDateTemp(ShiftId,ShiftName,ShiftStartdate) 
    EXEC TCD.GetShiftStartDate @BatchEndTime

    SELECT @BatchShiftId = ShiftID, @PartitionOn=ShiftStartdate FROM @ShiftStartDateTemp
	print ' Batch End Date: ' + Convert(nvarchar(10),@BatchEndTime)
    UPDATE TCD.BatchData SET EndDate = @BatchEndTime, ShiftId=@BatchShiftId, PartitionOn=@PartitionOn WHERE BATCHID = @BatchID


    --EXEC TCD.UPDATEBatchWashStepForTunnel @TunnelXML, @WasherID, @BatchID, @BatchStartTime, @PartitionOn, @EcolabWasherId, 20
   END
      
  
   CREATE TABLE #DosingDetails(Number INT, 
          Quantity Decimal(10,6),
          Point INT,
          IsMainEquioment INT,
          IsDirectDosing INT
         )
     
   --IF EXISTS (SELECT  * FROM TEMPDB.DBO.SYSOBJECTS o where o.xtype in ('U') AND o.id = OBJECT_ID(N'tempdb..#DosingDetails'))
   --BEGIN
   --  DROP TABLE #DosingDetails
   --END

   INSERT INTO #DosingDetails(Number,Quantity, Point, IsMainEquioment, IsDirectDosing)
   SELECT 
   T.c.value('@Number', 'INT') AS Number, --PumpNumber
   T.c.value('@Quantity', 'Decimal(10,6)') AS Quantity, --Dosing Quanity
   T.c.value('@Point', 'INT') AS Point, --ValveNumber
   T.c.value('@IsMainEquipment', 'INT') AS IsMainEquioment,
   T.c.value('@IsDirectDosing', 'INT') AS IsDirectDosing
   FROM @TunnelXML.nodes('TunnelData/Dose') T(c)
   
   -- Fetching data from cursor
   DECLARE @MYCURSOR CURSOR
   SET @MYCURSOR = CURSOR FAST_FORWARD
   FOR
   SELECT  Number,
      Quantity,          
      Point,
      IsMainEquioment,
      IsDirectDosing

    FROM #DosingDetails

   DECLARE   @Number    INT,
       @Quantity   Decimal(10,6),
       @Point    INT,
       @IsMainEquioment INT,
       @IsDirectDosing  INT

   OPEN @MYCURSOR
   FETCH NEXT FROM @MYCURSOR
      INTO 
       @Number,
       @Quantity,
       @Point,
       @IsMainEquioment,
       @IsDirectDosing
       
   WHILE @@FETCH_STATUS = 0   
   BEGIN 
    IF(@IsDirectDosing = 1)
    BEGIN
     SELECT @ProductId=CES.ProductId, @CompartmentNum=TCEVM.CompartmentNumber
     FROM tcd.ControllerEquipmentSetup CES 
     INNER JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM
     ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
     WHERE TCEVM.DirectDosingFlag = 1
        AND CES.ControllerId=@ControllerID 
        AND CES.ControllerEquipmentId=@Number
        AND CES.ControllerEquipmentTypeId=1 
        --AND IsActive=1 
        AND CES.WasherGroupNumber=@WasherGroupNum

    END
    ELSE IF(@IsMainEquioment = 1)
    BEGIN
     SELECT @ProductId=CES.ProductId, @CompartmentNum=TCEVM.CompartmentNumber
        FROM  tcd.ControllerEquipmentSetup CES INNER JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM
     ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
     WHERE CES.ControllerId=@ControllerID AND
        CES.ControllerEquipmentTypeId=2 AND
        --CES.IsActive=1 AND
        CES.WasherGroupNumber=@WasherGroupNum AND
        TCEVM.ValveNumber=@Point AND
        CES.ControllerEquipmentId = @Number
		AND TCEVM.CompartmentNumber > 0
    END
    ELSE
    BEGIN
     SELECT @ProductId=CES.ProductId, @CompartmentNum=TCEVM.CompartmentNumber
        FROM  tcd.ControllerEquipmentSetup CES INNER JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM
     ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
     WHERE CES.ControllerId=@ControllerID AND
        CES.ControllerEquipmentTypeId=1 AND
        --CES.IsActive=1 AND
        CES.WasherGroupNumber = @WasherGroupNum AND
        TCEVM.ValveNumber=@Point
		AND TCEVM.CompartmentNumber > 0      
    END

    IF(@ProductId is not null)
    BEGIN
	 print 'Batch Product data is not null'
     INSERT INTO TCD.BatchProductData 
     (BatchId, StepCompartment, ActualQuantity,PartitionOn,EcolabWasherId,ProductId)
     SELECT @BatchID,
      @CompartmentNum,
      @Quantity,
      @PartitionOn,
      @EcolabWasherId,
      @ProductId
    END
	Else 
	BEGIN
	 print 'Batch Product data is null'
	END 

    FETCH NEXT FROM @MYCURSOR
      INTO 
       @Number,
       @Quantity,
       @Point,
       @IsMainEquioment,
       @IsDirectDosing
   END

   CLOSE @MYCURSOR
   DEALLOCATE @MYCURSOR

   Drop table #DosingDetails

   
  SELECT @ActualInjSteps = COUNT(DISTINCT StepCompartment) FROM TCD.BatchProductData WHERE BatchId=@BatchID
  IF NOT EXISTS(SELECT * FROM TCD.BatchParameters WHERE ParameterId =37 and batchid=@BatchID AND @ActualInjSteps > 0)
  BEGIN
   INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,37,@ActualInjSteps, @PartitionOn
  END
  ELSE
  BEGIN
   Update TCD.BatchParameters SET ParameterValue=@ActualInjSteps WHERE ParameterId =37 and batchid=@BatchID
  END
   END 

  SELECT @MinTempParamID=Id 
  FROM [TCD].[ConduitParameters] 
  WHERE Name = 'Mimum Temperature' 
    
  SELECT @MaxTempParamID=Id 
  FROM [TCD].[ConduitParameters] 
  WHERE Name = 'Maximum Temperature'

  SELECT @TempStatusParamID=Id 
  FROM [TCD].[ConduitParameters] 
  WHERE Name = 'Temperature Status'

  SELECT @PHValueParamID=ID
  FROM [TCD].[ConduitParameters] 
  WHERE Name = 'PH'
    
  SELECT @PHStatusParamID=ID
  FROM [TCD].[ConduitParameters] 
  WHERE Name =  'PH Status'  
  
  --pH Status
  INSERT INTO TCD.BatchParameters
  (BatchId,
   EcolabWasherId,
   ParameterId,
   ParameterValue,
   PartitionOn)
  VALUES(@BatchID,
    @EcoLabWasherID,
    @PHStatusParamID,
    @PHStatus,
    @PartitionOn)

  --pH Value
  INSERT INTO TCD.BatchParameters
  (BatchId,
   EcolabWasherId,
   ParameterId,
   ParameterValue,
   PartitionOn)
  VALUES(@BatchID,
    @EcoLabWasherID,
    @PHValueParamID,
    @PHValue,
    @PartitionOn)

  CREATE TABLE #TemperatureDetails(MinimumTemp Decimal(10,2), 
           MaximumTemp Decimal(10,2),
           TempStatus Decimal(10,2)
          )
     
   INSERT INTO #TemperatureDetails(MinimumTemp,MaximumTemp, TempStatus)
   SELECT 
   T.c.value('@MinimumTemp', 'Decimal(10,2)') AS MinimumTemp, 
   T.c.value('@MaximumTemp', 'Decimal(10,2)') AS MaximumTemp,
   T.c.value('@Status', 'Decimal(10,2)') AS Status
   
   FROM @TunnelXML.nodes('TunnelData/TemperatureData') T(c)
   
   -- Fetching data from cursor
   DECLARE @TEMPCURSOR CURSOR
   SET @TEMPCURSOR = CURSOR FAST_FORWARD
   FOR
   SELECT  MinimumTemp,
      MaximumTemp,          
      TempStatus

    FROM #TemperatureDetails

   DECLARE   @MinimumTemp    Decimal(10,2),
       @MaximumTemp   Decimal(10,2),
       @TempStatus    Decimal(10,2)
       
   OPEN @TEMPCURSOR
   FETCH NEXT FROM @TEMPCURSOR
      INTO 
       @MinimumTemp,
       @MaximumTemp,
       @TempStatus
       
   WHILE @@FETCH_STATUS = 0   
   BEGIN 
    --Minimum Temperature
    INSERT INTO TCD.BatchParameters
    (BatchId,
     EcolabWasherId,
     ParameterId,
     ParameterValue,
     PartitionOn)
    VALUES(@BatchID,
      @EcoLabWasherID,
      @MinTempParamID,
      @MinimumTemp,
      @PartitionOn)

    --Maximum Temperature
    INSERT INTO TCD.BatchParameters
    (BatchId,
     EcolabWasherId,
     ParameterId,
     ParameterValue,
     PartitionOn)
    VALUES(@BatchID,
      @EcoLabWasherID,
      @MaxTempParamID,
      @MaximumTemp,
      @PartitionOn)

    --Temperature Status
    INSERT INTO TCD.BatchParameters
    (BatchId,
     EcolabWasherId,
     ParameterId,
     ParameterValue,
     PartitionOn)
    VALUES(@BatchID,
      @EcoLabWasherID,
      @TempStatusParamID,
      @TempStatus,
      @PartitionOn)        

    FETCH NEXT FROM @TEMPCURSOR
      INTO 
       @MinimumTemp,
       @MaximumTemp,
       @TempStatus
   END

   CLOSE @TEMPCURSOR
   DEALLOCATE @TEMPCURSOR

   Drop table #TemperatureDetails
                                            

END
GO
-------------------------------------------PLC XL Batch Product data changes END--------------------------------------------------------------

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[AddTunnel]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[AddTunnel]
END
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE	[TCD].[AddTunnel]	
					@MyServiceWasherId						UniqueIdentifier
				,	@EcoLabAccountNumber					NVARCHAR(25)
				,	@WasherGroupId							INT
				,	@TunnelName								NVARCHAR(50)
				,	@WasherModelName						NVARCHAR(50)
				,	@RegionId								SMALLINT
--				,	@Size									INT									--we don't need to save this; ModelId PK determines it
				,	@ControllerId							INT
				,	@LFSWasherNumber						TINYINT			=			1		--For tunnels, it will be 1 until a diff. number is passed (as per the scenario)
				,	@PlantWasherNumber						SMALLINT
				,	@WasherMode								TINYINT
				,	@MaxLoad								SMALLINT
				,	@AWEActive								BIT
				,	@NumberOfTanks							TINYINT
				,	@NumberOfComp							TINYINT								--though this is INT in the table, we should not require it to be so
				,	@TransferType							TINYINT         =			NULL
				,	@PressExtractor							TINYINT       =			NULL
				,	@ProgramNumber							TINYINT
				,	@EndOfFormula							TINYINT
				,	@Description							NVARCHAR(1024)	=			NULL
				,	@UserId									INT

				,	@OutputTunnelId							INT			OUTPUT
				--Adding as part of re-factoring for integration with Synch/Configurator... generated TunnelId (re-named) is already being OUTPUT above
				,	@OutputLastModifiedTimestampAtLocal		DATETIME		=			NULL	OUTPUT
				,   @RatioDosingActive						Bit = 'False'
				,   @ControllerModelId						INT		=		NULL
				,   @NumberOfCompartmentsConveyorBelt			TINYINT	=		NULL
				,   @MaxMachineLoad							TINYINT	=		NULL
				,   @MinMachineLoad							TINYINT	=		NULL
				,   @ProgramSelectionByTime					BIT	  	=		NULL
				,   @WeightSelectionByTime					BIT	  	=		NULL
				,   @WeightSelectionByAnalogInput				BIT	  	=		NULL
				,   @TunInTomMode							BIT	  	=		NULL
				,   @SignalStopTunActive						BIT	  	=		NULL
				,   @SignalEjectionTunActive	  				BIT	  	=		NULL
				,   @DelayTimeForTunWashingPrograms			BIT	  	=		NULL
				,   @KannegiesserPressSpecialMode				BIT	  	=		NULL
				,   @ValveOutputsUsedAsTomSignal				BIT	  	=		NULL
				,   @ExtendedClockOrDataProtocol				BIT	  	=		NULL
				,   @WeightCorrectionFcc						BIT	  	=		NULL
				,	@DateAndTimeWhenBatchEjects					BIT	  		=		NULL
				,	@AutoRinseDesamixAfter						SMALLINT	=		NULL
				,	@AutoRinseDesamix1For						SMALLINT	=		NULL
				,	@AutoRinseDesamix2For						SMALLINT	=		NULL
				,	@TemperatureAlarmProbe1						BIT			=		NULL
				,	@TemperatureAlarmProbe2						BIT			=		NULL
				,	@TemperatureAlarmProbe3						BIT			=		NULL
				, @UseMe1OfGroup			 tinyint =	NULL
				, @UseMe2OfGroup			 tinyint =	NULL
				,	@ETechWasherNumber						    INT			=		NULL
				,	@KannegiesserDosageInPreparationTankMode	bit			=		NULL
				,	@BatchOk									bit			=		NULL

AS
BEGIN

SET	NOCOUNT	ON


DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''

	,	@WasherId						INT				=			NULL
	,	@WasherModelId					SMALLINT		=			NULL
	--Adding for integration with Synch./Central
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()
	,	@ControllerValidate				int				=										   0

--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
SET		@OutputLastModifiedTimestampAtLocal				=			@CurrentUTCTime
SET		@OutputTunnelId									=			ISNULL(@OutputTunnelId, NULL)			--SQLEnlight

--Check that the WasherGroup being associated-to is a valid Tunnel-type WG...
IF	NOT	EXISTS	(	SELECT	1
					FROM	[TCD].WasherGroup			WG
					JOIN	[TCD].WasherGroupType		WGT
						ON	WG.WasherGroupTypeId		=			WGT.WasherGroupTypeId
					JOIN	[TCD].MachineGroup					GT									--this is actually the Groups table and NOT really a Group TYPE
						ON	WG.WasherGroupId			=			GT.Id			--GroupTypeId is actually the Id of the Group
					WHERE	WG.WasherGroupId			=			@WasherGroupId
						AND	GT.EcolabAccountNumber		=			@EcoLabAccountNumber
						AND	GT.GroupTypeId	  			=			2			--select	GroupMaintype	from	GroupType
						AND	WGT.WasherGroupTypeName		=			'Tunnel'				--select	WasherGroupTypeName	from	WasherGroupType
				)
			BEGIN
				SET		@ErrorId						=			51001
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherGroup provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--Check for only 1 tunnel for a WasherGroup
IF	EXISTS		(	SELECT	1
					FROM	[TCD].MachineSetup			MS
					JOIN	[TCD].Washer				W
						ON	MS.WasherId					=			W.WasherId
					WHERE	MS.GroupId					=			@WasherGroupId
						AND	MS.EcoalabAccountNumber		=			@EcoLabAccountNumber
						AND	MS.IsDeleted				=			'FALSE'
						AND	MS.IsTunnel					=			'TRUE'
						AND	W.Is_Deleted				=			'FALSE'
				)
			BEGIN
				SET		@ErrorId						=			51008
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': A Tunnel has already been added to this Washer Group.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--Check for unique PlantWasherNo.
IF	EXISTS		(	SELECT	1
					FROM	[TCD].Washer				W
					JOIN	[TCD].MachineSetup			MS
						ON	W.WasherId					=			MS.WasherId
						AND	W.EcoLabAccountNumber		=			MS.EcoalabAccountNumber
					WHERE	W.EcoLabAccountNumber		=			@EcoLabAccountNumber
						AND	(
							W.PlantWasherNumber			=			@PlantWasherNumber							
							)
						AND	W.Is_Deleted				=			'FALSE'
						AND	MS.IsDeleted				=			'FALSE'
				)
			BEGIN
				SET		@ErrorId						=			51002
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Specified Plant Washer #/ already exists.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--Check that it's a valid Controller type/model (one that can control a Tunnel)

EXEC @ControllerValidate = [TCD].[ValidateController] 2,@ControllerId,@EcoLabAccountNumber

IF(@ControllerValidate = 1)
				
			BEGIN
				SET		@ErrorId						=			51003
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller was provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--EOF should not be an asocciated formula for the WG...
IF	EXISTS		(	SELECT	1
					FROM	[TCD].TunnelProgramSetup	TPS
					WHERE	TPS.EcolabAccountNumber		=			@EcoLabAccountNumber
						AND	TPS.WasherGroupId			=			@WasherGroupId
						AND	TPS.ProgramNumber			=			@ProgramNumber
						AND	TPS.Is_Deleted				=			'FALSE'
				)
			BEGIN
				SET		@ErrorId						=			51004
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An associated formula cannot be specified as End-Of-Formula.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--WasherMode check
IF	NOT	EXISTS	(	SELECT	1
					FROM	[TCD].ControllerModelControllerTypeMapping
														CMCTM
					JOIN	[TCD].ConduitController		CC
						ON	CC.ControllerTypeId			=			CMCTM.ControllerTypeId
						AND	CC.ControllerModelId		=			CMCTM.ControllerModelId
					JOIN	[TCD].[WasherModeMapping]	CTM2WM
						ON	CMCTM.Id					=			CTM2WM.ControllerModelControllerTypeMappingId
					WHERE	CC.EcoalabAccountNumber		=			@EcoLabAccountNumber
						AND	CC.ControllerId				=			@ControllerId
						AND	CC.IsDeleted				=			'FALSE'
						AND	CMCTM.MaxtunnelCount > 0
						AND	CTM2WM.WasherModeId			=			@WasherMode
				)
			BEGIN
				SET		@ErrorId						=			51005
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherMode was provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--select the WasherModelId based on name
SELECT	TOP	1
		@WasherModelId						=			WMS.WasherModelId
FROM	[TCD].WasherModelSize				WMS
WHERE	WMS.RegionId						=			@RegionId
	AND	WMS.WasherModelName					=			@WasherModelName
	AND	WMS.ModelTypeId						=			2							--TypeId 2 for Tunnel
	AND	WMS.Is_Deleted						=			'FALSE'

--LFSWasherNumber duplicate check...
IF	EXISTS	(	SELECT	1
				FROM	[TCD].MachineSetup					MS
				WHERE	MS.ControllerId					=			@ControllerId
					AND	MS.MachineInternalId			=			@LFSWasherNumber
					AND MS.EcoalabAccountNumber			=			@EcoLabAccountNumber
					AND	MS.IsDeleted					=			'FALSE'
					AND MS.IsTunnel						=			'TRUE'
			)
			BEGIN
				SET		@ErrorId						=			51010
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate LFSWasher# provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET		@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END
--ETechWasherNumber duplicate check...
IF(@ControllerModelId NOT IN (7,8,9,10,11,14))
BEGIN
IF EXISTS ( SELECT 1
    FROM [TCD].Washer  AS W
    JOIN [TCD].MachineSetup AS MS ON MS.WasherId = W.WasherId 
    where W.ETechWasherNumber = @ETechWasherNumber
	 AND  MS.IsTunnel                    =            'TRUE'
)  
BEGIN  

SET  @ErrorId      =   51012  
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate ETechWasherNumber# provided.'  
--GOTO ErrorHandler  
RAISERROR (@ErrorMessage, 16, 1)  
SET  @ReturnValue = -1  
RETURN (@ReturnValue)  
END
END

--Now attempt to insert a new row for the tunnel record being created...
BEGIN	TRAN
IF(@ControllerModelId IS NOT NULL AND @ControllerModelId = 7 )
BEGIN
INSERT	[TCD].Washer	(
		 MyServiceCustMchGuid
		,EcoLabAccountNumber
		,PlantWasherNumber
		,ModelId
		,WasherMode
		,MaxLoad
		,[Description]
		,Is_Deleted
		,LastModifiedByUserId
		,NumberOfTanks
		,TransferType
		,PressExtractor
	--Adding for integration with Synch./Central
		,LastModifiedTime
		,EmptyPocketNumber
		,NumberOfCompartmentsConveyorBelt
		,MinMachineLoad
		,MaxMachineLoad
		,ProgramSelectionByTime
		,WeightSelectionByTime
		,WeightSelectionByAnalogInput
		,TunInTomMode
		,SignalStopTunActive
		,SignalEjectionTunActive
		,DelayTimeForTunWashingPrograms
		,KannegiesserPressSpecialMode
		,ValveOutputsUsedAsTomSignal
		,ExtendedClockOrDataProtocol
		,WeightCorrectionFcc
		,AWEActive
		,EndOfFormula
		,ETechWasherNumber
		,KannegiesserDosageInPreparationTankMode
		,BatchOk
	)
SELECT @MyServiceWasherId					AS			MyServiceWasherId	
	,	@EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	@PlantWasherNumber					AS			PlantWasherNumber
	,	@WasherModelId						AS			ModelId
	--,	@Size							AS			Size
	,	@WasherMode						AS			WasherMode
	,	@MaxLoad							AS			MaxLoad
	,	@Description						AS			[Description]
	,	'FALSE'							AS			Is_Deleted
	,	@UserId							AS			LastModifiedByUserId
	,	@NumberOfTanks						AS			NumberOfTanks
	,	@TransferType						AS			TransferType
	,	@PressExtractor					AS			PressExtractor
	,	@CurrentUTCTime					AS			LastModifiedTime
	,	@ProgramNumber						AS			ProgramNumber
	,   @NumberOfCompartmentsConveyorBelt		AS			NumberOfCompartmentsConveyorBelt
	,   @MinMachineLoad						AS			MinMachineLoad
	,   @MaxMachineLoad						AS			MaxMachineLoad
	,   @ProgramSelectionByTime				AS			ProgramSelectionByTime
	,   @WeightSelectionByTime				AS			WeightSelectionByTime
	,   @WeightSelectionByAnalogInput			AS			WeightSelectionByAnalogInput
	,   @TunInTomMode						AS			TunInTomMode
	,   @SignalStopTunActive					AS			SignalStopTunActive
	,   @SignalEjectionTunActive	  			AS			SignalEjectionTunActive
	,   @DelayTimeForTunWashingPrograms		AS			DelayTimeForTunWashingPrograms
	,   @KannegiesserPressSpecialMode			AS			KannegiesserPressSpecialMode
	,   @ValveOutputsUsedAsTomSignal			AS			ValveOutputsUsedAsTomSignal
	,   @ExtendedClockOrDataProtocol			AS			ExtendedClockOrDataProtocol
	,   @WeightCorrectionFcc					AS			WeightCorrectionFcc
	,	'FALSE'							AS			AWEActive
	,	0								AS			EndOfFormula
	,   @ETechWasherNumber			AS			ETechWasherNumber
	,	@KannegiesserDosageInPreparationTankMode	AS KannegiesserDosageInPreparationTankMode
	,	@BatchOk						AS		BatchOk
END
ELSE IF(@ControllerModelId IS NOT NULL AND ( @ControllerModelId = 8	OR @ControllerModelId = 9	OR @ControllerModelId = 10 OR @ControllerModelId = 11 OR @ControllerModelId = 14))
BEGIN
INSERT	[TCD].Washer	(
		 MyServiceCustMchGuid
		,EcoLabAccountNumber
		,PlantWasherNumber
		,ModelId
		,WasherMode
		,MaxLoad
		,[Description]
		,Is_Deleted
		,LastModifiedByUserId
		,NumberOfTanks
		,TransferType
		,PressExtractor
	--Adding for integration with Synch./Central
		,LastModifiedTime
		,EmptyPocketNumber
		,NumberOfCompartmentsConveyorBelt
		,MinMachineLoad
		,MaxMachineLoad
		,ProgramSelectionByTime
		,WeightSelectionByTime
		,WeightSelectionByAnalogInput
		,TunInTomMode
		,SignalStopTunActive
		,SignalEjectionTunActive
		,DelayTimeForTunWashingPrograms
		,KannegiesserPressSpecialMode
		,ValveOutputsUsedAsTomSignal
		,ExtendedClockOrDataProtocol
		,WeightCorrectionFcc
		,AWEActive
		,EndOfFormula
		,AutoRinseDesamixAfter
		,AutoRinseDesamix1For
		,AutoRinseDesamix2For
		,TemperatureAlarmProbe1
		,TemperatureAlarmProbe2
		,TemperatureAlarmProbe3
		,DateAndTimeWhenBatchEjects
		,ETechWasherNumber
		,UseMe1OfGroup
		,UseMe2OfGroup

	)
SELECT @MyServiceWasherId					AS			MyServiceWasherId	
	,	@EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	@PlantWasherNumber					AS			PlantWasherNumber
	,	@WasherModelId						AS			ModelId
	--,	@Size							AS			Size
	,	@WasherMode						AS			WasherMode
	,	@MaxLoad							AS			MaxLoad
	,	@Description						AS			[Description]
	,	'FALSE'							AS			Is_Deleted
	,	@UserId							AS			LastModifiedByUserId
	,	@NumberOfTanks						AS			NumberOfTanks
	,	@TransferType						AS			TransferType
	,	@PressExtractor					AS			PressExtractor
	,	@CurrentUTCTime					AS			LastModifiedTime
	,	@ProgramNumber						AS			ProgramNumber
	,   @NumberOfCompartmentsConveyorBelt		AS			NumberOfCompartmentsConveyorBelt
	,   @MinMachineLoad						AS			MinMachineLoad
	,   @MaxMachineLoad						AS			MaxMachineLoad
	,   @ProgramSelectionByTime				AS			ProgramSelectionByTime
	,   @WeightSelectionByTime				AS			WeightSelectionByTime
	,   @WeightSelectionByAnalogInput			AS			WeightSelectionByAnalogInput
	,   @TunInTomMode						AS			TunInTomMode
	,   @SignalStopTunActive					AS			SignalStopTunActive
	,   @SignalEjectionTunActive	  			AS			SignalEjectionTunActive
	,   @DelayTimeForTunWashingPrograms		AS			DelayTimeForTunWashingPrograms
	,   @KannegiesserPressSpecialMode			AS			KannegiesserPressSpecialMode
	,   @ValveOutputsUsedAsTomSignal			AS			ValveOutputsUsedAsTomSignal
	,   @ExtendedClockOrDataProtocol			AS			ExtendedClockOrDataProtocol
	,   @WeightCorrectionFcc					AS			WeightCorrectionFcc
	,	'FALSE'							AS			AWEActive
	,	0								AS			EndOfFormula
	,	@AutoRinseDesamixAfter
	,	@AutoRinseDesamix1For
	,	@AutoRinseDesamix2For
	,	@TemperatureAlarmProbe1
	,	@TemperatureAlarmProbe2
	,	@TemperatureAlarmProbe3
	,	@DateAndTimeWhenBatchEjects
	,   @ETechWasherNumber						AS			ETechWasherNumber
	, @UseMe1OfGroup AS UseMe1OfGroup
	, @UseMe2OfGroup AS UseMe2OfGroup
END
ELSE
BEGIN
INSERT	[TCD].Washer	(
		MyServiceCustMchGuid
		,EcoLabAccountNumber
		,PlantWasherNumber
		,ModelId
		,WasherMode
		,MaxLoad
		,AWEActive
		,EndOfFormula
		,[Description]
		,Is_Deleted
		,LastModifiedByUserId
		,NumberOfTanks
		,TransferType
		,PressExtractor
	--Adding for integration with Synch./Central
		,LastModifiedTime
		,RatioDosingActive
		,EmptyPocketNumber
	)
SELECT @MyServiceWasherId					AS			MyServiceWasherId	
	,	@EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	@PlantWasherNumber					AS			PlantWasherNumber
	,	@WasherModelId						AS			ModelId
	--,	@Size							AS			Size
	,	@WasherMode						AS			WasherMode
	,	@MaxLoad							AS			MaxLoad
	,	@AWEActive						AS			AWEActive
	,	@EndOfFormula						AS			EndOfFormula
	,	@Description						AS			[Description]
	,	'FALSE'							AS			Is_Deleted
	,	@UserId							AS			LastModifiedByUserId
	,	@NumberOfTanks						AS			NumberOfTanks
	,	@TransferType						AS			TransferType
	,	@PressExtractor					AS			PressExtractor
	,	@CurrentUTCTime					AS			LastModifiedTime
	,   @RatioDosingActive					AS			RatioDosingActive
	,	@ProgramNumber						AS			ProgramNumber 	
END

SET	@ErrorId	=	@@ERROR
	
IF	(@ErrorId	<>	0)
	BEGIN
			IF	@@TRANCOUNT	>	0
			BEGIN
				ROLLBACK	TRAN
			END

			SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred creating new record for tunnel.'
			--GOTO	ErrorHandler
			RAISERROR	(@ErrorMessage, 16, 1)
			SET	@ReturnValue	=	-1
			RETURN	(@ReturnValue)
	END

--if no error, collect the id of the newly generated row...
SELECT	@WasherId	=	SCOPE_IDENTITY()


--insert in MachineSetup
INSERT	[TCD].MachineSetup	(
		WasherId	,GroupId	,MachineInternalId	,EcoalabAccountNumber	,MachineName	,IsTunnel	,ControllerId	,NumberOfComp	,IsDeleted	,LastModifiedByUserId	)
SELECT	@WasherId					AS			WasherId
	,	@WasherGroupId				AS			GroupId
	,	@LFSWasherNumber			AS			MachineInternalId
	,	@EcoLabAccountNumber		AS			EcoalabAccountNumber
	,	@TunnelName					AS			MachineName
	,	'TRUE'						AS			IsTunnel
	,	@ControllerId				AS			ControllerId
	,	@NumberOfComp				AS			NumberOfComp
	,	'FALSE'						AS			IsDeleted
	,	@UserId						AS			LastModifiedByUserId

SET	@ErrorId	=	@@ERROR

IF	(@ErrorId	<>	0)
	BEGIN
			IF	@@TRANCOUNT	>	0
			BEGIN
				ROLLBACK	TRAN
			END

			SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred assoicating new record for tunnel.'
			--GOTO	ErrorHandler
			RAISERROR	(@ErrorMessage, 16, 1)
			SET	@ReturnValue	=	-1
			RETURN	(@ReturnValue)
	END
ELSE
	BEGIN
			IF	@@TRANCOUNT	>	0
			BEGIN
				COMMIT
			END

			--SET the output param to be communicated back...
			SET	@OutputTunnelId	=	@WasherId
	END



--IF	(	@ErrorId	=	0	)
--	BEGIN
--		--GOTO	ExitModule
--		RETURN	(@ReturnValue)
--	END




--ErrorHandler:
--RAISERROR	(@ErrorMessage, 16, 1)
--SET	@ReturnValue	=	-1




--ExitModule:

SET	NOCOUNT	OFF
RETURN	(@ReturnValue)


END
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[TCD].[GetUsedChemicalName]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[GetUsedChemicalName]
END
GO
SET ANSI_NULLS ON
GO

CREATE PROCEDURE [TCD].[GetUsedChemicalName]
    @ChemName Varchar(1000)
    ,@EcolabAccountNumber NVARCHAR(25)
    ,@WasherGroupId    INT = NULL
AS     

BEGIN     
    SET NOCOUNT ON    
    
    DECLARE @RegionId            INT =    NULL
        ,    @ControllerId        INT    =    NULL
        ,    @ControllerModelId    INT    =    NULL
        ,    @ControllerTypeId    INT    =    NULL
		,    @WasherDosingNumber  INT    =    NULL
    
    SELECT 
    @RegionId = RegionID FROM Plant 
    WHERE 
    EcolabAccountNumber = @EcolabAccountNumber
	SELECT @WasherDosingNumber = wg.WasherDosingNumber
           FROM TCD.WasherGroup wg
           WHERE wg.WasherGroupId = @WasherGroupId
             AND wg.EcolabAccountNumber = @EcolabAccountNumber

    SELECT @ControllerId =  wg.ControllerId FROM TCD.WasherGroup wg WHERE wg.WasherGroupId = @WasherGroupId AND wg.EcolabAccountNumber = @EcolabAccountNumber

    IF @ControllerId IS NULL OR @Controllerid = 0
    BEGIN
    IF @WasherGroupId IS NULL
    BEGIN
        SELECT 
        Map.ProductId, RTRIM(ISNULL(NULLIF(M.EnvisionDisplayName, ' '), M.Name)) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name
        , M.Cost
        , M.IncludeinCI
        , TCD.FnChemicalCostInOunce(Map.ProductId) AS        Price
    , 0
        FROM ProductMaster M
        INNER JOIN ProductdataMapping Map ON M.ProductId = Map.ProductId AND Map.Is_Deleted=0
        WHERE 
        (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
        AND M.RegionId = @RegionId
        AND M.Is_Deleted =0
    END
    ELSE
    BEGIN
        SELECT DISTINCT
        Map.ProductId, RTRIM(ISNULL(NULLIF(M.EnvisionDisplayName, ' '), M.Name)) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name
        , M.Cost
        , M.IncludeinCI
        , TCD.FnChemicalCostInOunce(Map.ProductId) AS        Price
    , 0
        FROM TCD.ProductMaster M
        INNER JOIN TCD.ProductdataMapping Map ON M.ProductId = Map.ProductId AND Map.Is_Deleted=0
        LEFT JOIN TCD.ControllerEquipmentSetup ces ON ces.ProductId = Map.ProductId AND ces.EcoLabAccountNumber = Map.EcolabAccountNumber
        INNER JOIN TCD.MachineSetup ms ON ms.ControllerId = ces.ControllerId AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber AND ms.IsDeleted = 'False'
        INNER JOIN TCD.WasherGroup wg ON wg.WasherGroupId = ms.GroupId AND wg.EcolabAccountNumber = ms.EcoalabAccountNumber
        WHERE wg.WasherGroupId = ISNULL(@WasherGroupId, wg.WasherGroupId)
        AND (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
        AND M.RegionId = @RegionId
        AND M.Is_Deleted =0
        END
     END
    ELSE
    BEGIN
        SELECT @ControllerModelId = cc.ControllerModelId, @ControllerTypeId = cc.ControllerTypeId FROM TCD.ConduitController cc WHERE cc.ControllerId = @ControllerId

        IF @ControllerModelId = 11
        BEGIN
            SELECT DISTINCT
            Map.ProductId, 
			RTRIM(ISNULL(NULLIF(M.EnvisionDisplayName, ' '), M.Name)) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name
            , M.Cost
            , M.IncludeinCI
            , CAST (ces.ControllerEquipmentTypeId AS int) AS ControllerEquipmentTypeId
            FROM ProductMaster M
            INNER JOIN ProductdataMapping Map ON M.ProductId = Map.ProductId AND Map.Is_Deleted=0  
            INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.EcoLabAccountNumber = Map.EcolabAccountNumber  AND ces.WasherGroupNumber=@WasherDosingNumber AND ces.ProductId = Map.ProductID
		  AND ces.ConventionalWasherGroupConnection = 1
            LEFT JOIN TCD.TunnelCompartmentEquipmentValveMapping tcevm ON ces.ControllerEquipmentSetupID = tcevm.ControllerEquipmentSetupID AND tcevm.DirectDosingFlag = 1
            WHERE 
            (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
            AND tcevm.ControllerEquipmentSetupID IS NULL
            AND M.RegionId = @RegionId
            AND M.Is_Deleted =0
            AND ces.ControllerId = @ControllerId
            AND ces.WasherGroupNumber =  CASE WHEN @ControllerTypeId = 13 THEN 1 ELSE ces.WasherGroupNumber END
    END
        ELSE
        BEGIN
            SELECT DISTINCT
            Map.ProductId, 
			RTRIM(ISNULL(NULLIF(M.EnvisionDisplayName, ' '), M.Name)) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name
    , M.Cost
    , M.IncludeinCI
    , TCD.FnChemicalCostInOunce(Map.ProductId) AS        Price
            , CAST (ces.ControllerEquipmentTypeId AS int) AS ControllerEquipmentTypeId
    FROM ProductMaster M
    INNER JOIN ProductdataMapping Map ON M.ProductId = Map.ProductId AND Map.Is_Deleted=0     
            INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.EcoLabAccountNumber = Map.EcolabAccountNumber AND ces.ProductId = Map.ProductID 
		  AND CASE WHEN @ControllerModelId IN (7, 10, 8) THEN ces.ConventionalWasherGroupConnection ELSE ISNULL(ces.ConventionalWasherGroupConnection, 0) END = CASE WHEN @ControllerModelId IN (7, 10, 8) THEN 1 ELSE 0 END
            LEFT JOIN TCD.TunnelCompartmentEquipmentValveMapping tcevm ON ces.ControllerEquipmentSetupID = tcevm.ControllerEquipmentSetupID AND tcevm.DirectDosingFlag = 1
    WHERE 
    (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
            AND tcevm.ControllerEquipmentSetupID IS NULL
    AND M.RegionId = @RegionId
    AND M.Is_Deleted =0
            AND ces.ControllerId = @ControllerId
        END
    END
        

    SET NOCOUNT OFF 
 
END

GO
IF  EXISTS (SELECT * FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[TCD].[ProcessModuleTags]') AND type in (N'P', N'PC'))
BEGIN
DROP PROCEDURE [TCD].[ProcessModuleTags]
END
GO

CREATE PROCEDURE [TCD].[ProcessModuleTags]
(	
	@ModuleId INT,
	@ModuleTypeId INT,	
	@Reading DECIMAL(18,4),
	@TimeStamp DATETIME,
	@RollOverPoint INT
)

AS
SET NOCOUNT ON
BEGIN

DECLARE @PlantId int = NULL

SELECT @PlantId = p.PlantId FROM TCD.Plant p

		BEGIN
		
		
		 IF(@ModuleTypeId = 3)
		  BEGIN
		  IF NOT EXISTS(SELECT * FROM TCD.[SensorReading] WHERE SensorId=@ModuleId AND [TimeStamp]=@TimeStamp)
			BEGIN
				INSERT INTO [TCD].[SensorReading](
											  SensorId,
											  [Reading],
											  [TimeStamp]
 										   )
				VALUES
					(	@ModuleId,
						@Reading,
						@TimeStamp					
					)
			END			
		  END
		 ELSE
		  BEGIN
			DECLARE @MaxReading decimal(18,4),
				    @UsageReading decimal(18,4)
				    
			SELECT	@MaxReading  =  max(Reading) FROM TCD.ModuleReading where TimeStamp 
									in (select max(timestamp) from tcd.modulereading 
									where ModuleId = @ModuleId AND ModuleTypeId = @ModuleTypeId)
			IF(@MaxReading = 0.0000 OR @MaxReading IS NULL)
			BEGIN
			    SELECT @UsageReading = 0.0000
			END						
			ELSE IF(@Reading < @MaxReading)
			BEGIN
				SELECT @UsageReading = ((CAST(@RollOverPoint as decimal(18,4)) + @Reading)- @MaxReading)
			END
			ELSE
			BEGIN
				SELECT @UsageReading = (@Reading - @MaxReading)
			END									
			IF NOT EXISTS(SELECT * FROM TCD.[ModuleReading] WHERE [ModuleId]=@ModuleId AND [ModuleTypeId] = @ModuleTypeId AND [TimeStamp]=@TimeStamp)
			BEGIN
				INSERT INTO [TCD].[ModuleReading](
										   [ModuleId],
										   [ModuleTypeId],
										   [Reading],
										   [TimeStamp],
										   [Usage],
										   [PlantId]
										   )
				 VALUES
					(	@ModuleId,
						@ModuleTypeId,
						@Reading,
						@TimeStamp,
						@UsageReading,
						@PlantId
					)
			END			
		  END
			
		END		  		   
END
GO