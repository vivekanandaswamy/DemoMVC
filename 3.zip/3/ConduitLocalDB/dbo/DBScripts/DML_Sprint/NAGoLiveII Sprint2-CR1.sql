-- Remove the Allen Bradly Mapping with dispenser version

DELETE FGM
	FROM tcd.FieldGroupFieldMapping AS FGM
		INNER JOIN tcd.FieldGroup fg ON FGM.FieldGroupId = fg.Id
		INNER JOIN TCD.Field f ON FGM.FieldId = f.ID
	WHERE fg.ControllerTypeId IN (SELECT 
				Id 
			FROM TCD.ControllerType 
			WHERE Name LIKE 'Allen Bradley')
		AND f.Label LIKE '%version%'
GO



--Add ETechEnable and IPAddress in Plant Table

IF NOT EXISTS(SELECT 1 FROM sys.columns
            WHERE Name = N'IsETechEnable' AND Object_ID = Object_ID(N'[TCD].[Plant]'))
BEGIN
ALTER TABLE TCD.Plant ADD IsETechEnable bit NOT NULL CONSTRAINT DF_Plant_IsETechEnable DEFAULT (0)
END
GO

IF NOT EXISTS(SELECT * FROM sys.columns WHERE  object_id = OBJECT_ID(N'TCD.Plant') AND name = 'ETechIpAddress')
BEGIN
	ALTER TABLE TCD.Plant 
	ADD ETechIpAddress varchar(100) NULL
END

--Add ETechWasherNumber in Washer Table

IF NOT EXISTS(SELECT * FROM sys.columns WHERE  object_id = OBJECT_ID(N'TCD.Washer') AND name = 'ETechWasherNumber')
BEGIN
	ALTER TABLE TCD.Washer 
	ADD ETechWasherNumber int NOT NULL CONSTRAINT DF_Plant_ETechWasherNumber DEFAULT (0)
END

GO
--Plant setup Procedures

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetPlantDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetPlantDetails
	END
GO  

CREATE PROCEDURE TCD.GetPlantDetails(
       @Ecolabaccountnumber NVARCHAR(25) = NULL	--(keeping this nullable, since it impacts the service/access layer)
)
AS
BEGIN

    SET NOCOUNT ON;

    SET @Ecolabaccountnumber = ISNULL(@Ecolabaccountnumber, NULL)


    SELECT
            p.EcolabAccountNumber, 
            p.Name, 
            p.TMName, 
            p.TMPhoneNumber, 
            p.DMName, 
            p.DMPhoneNumber, 
            (SELECT
                     PC.PlantChainName
                 FROM TCD.PlantChain AS PC
                 WHERE PC.PlantChainId = P.PlantChainId)AS Chain, 
            p.chainUnitNumber, 
            (SELECT
                     RM.RegionName
                 FROM TCD.PlantChain AS PC
                      JOIN TCD.RegionMaster AS RM ON PC.RegionId = RM.RegionId
                 WHERE PC.PlantChainId = P.PlantChainId)AS ChainRegions, 
            p.CensusPriceKg, 
            p.Remarks, 
            p.LanguageId, 
            p.CurrencyCode, 
            Addr.BillingAddr1, 
            addr.BillingAddr2, 
            addr.City, 
            addr.Country, 
            addr.zip, 
            addr.ShippingAddr1, 
            addr.ShippingAddr2, 
            addr.Shippingcity, 
            addr.Shippingcountry, 
            addr.Shippingzip, 
            p.Rate, 
            p.ExportPath, 
            p.AllowManualRewash, 
            p.DataLiveTime, 
            p.BudgetCustomer, 
            p.UOMId, 
            p.Logo, 
            p.RegionID, 
            (SELECT
                     RegionName FROM TCD.RegionMaster AS R WHERE R.RegionID = P.RegionID)AS RegionName, 
            (SELECT
                     Name FROM TCD.LanguageMaster AS L WHERE L.LanguageId = P.LanguageId)AS LanguageName, 
            (SELECT
                     CurrencyName FROM TCD.CurrencyMaster AS C WHERE c.CurrencyCode = p.CurrencyCode)AS CurrencyName, 
            (SELECT
                     UnitSystem
                 FROM TCD.DimensionalUnitSystems AS DUS
                 WHERE DUS.UnitSystemId = p.UOMId)AS UnitSystem, 
            P.LastModifiedTime AS LastModifiedTime, 
            P.MyServiceLastSynchTime AS MyServiceLastSynchTime, 
            P.LastServiceVisitDate AS LastServiceVisitDate, 
            P.LastArchiveDate AS LastArchiveDate, 
            P.NextServiceVisitDate AS NextServiceVisitDate, 
            P.PlantChainId, 
            P.MyServiceCustGuid AS MyServiceId, 
            P.ConStdTurnTime AS PlantStandardTurnTime, 
            P.PlantContractNumber AS PlantContractNumber, 
            P.PlantId AS PlantId, 
            P.DayId AS DayId, 
            P.StartTime AS StartTime, 
            P.EndTime AS EndTime,
			P.IsETechEnable AS IsETechEnable,
		    P.ETechIpAddress AS ETechIpAddress
        FROM TCD.plant AS P
             INNER JOIN TCD.PlantCustAddress AS ADDR ON p.EcolabAccountNumber = ADDR.EcolabAccountNumber
        WHERE Is_Deleted = 0

    SET NOCOUNT OFF;
END

GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetPlantDetailsByUserId]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetPlantDetailsByUserId
	END
GO  
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




CREATE PROCEDURE TCD.GetPlantDetailsByUserId(
       @Ecolabaccountnumber NVARCHAR(25) = NULL	--(keeping this nullable, since it impacts the service/access layer)
       , 
       @Userid INT)
AS
BEGIN

    SET NOCOUNT ON;

    SET @Ecolabaccountnumber = ISNULL(@Ecolabaccountnumber, NULL)


    SELECT
            p.EcolabAccountNumber, 
            p.Name, 
            p.TMName, 
            p.TMPhoneNumber, 
            p.DMName, 
            p.DMPhoneNumber, 
            (SELECT
                     PC.PlantChainName
                 FROM TCD.PlantChain AS PC
                 WHERE PC.PlantChainId = P.PlantChainId)AS Chain, 
            p.chainUnitNumber, 
            (SELECT
                     RM.RegionName
                 FROM TCD.PlantChain AS PC
                      JOIN TCD.RegionMaster AS RM ON PC.RegionId = RM.RegionId
                 WHERE PC.PlantChainId = P.PlantChainId)AS ChainRegions, 
            p.CensusPriceKg, 
            p.Remarks, 
            CASE
                WHEN(SELECT
                   LanguageId FROM TCD.UserMaster AS UM WHERE UM.UserId = @Userid)IS NULL THEN p.LanguageId
                WHEN(SELECT
                  LanguageId FROM TCD.UserMaster AS UM WHERE UM.UserId = @Userid)IS NOT NULL THEN(SELECT LanguageId FROM TCD.UserMaster AS UM WHERE UM.UserId = @Userid)
            END AS LanguageId,

            CASE
                WHEN(SELECT
                             CurrencyCode FROM TCD.UserMaster AS UM WHERE UM.UserId = @Userid)IS NULL THEN p.CurrencyCode
                WHEN(SELECT
                             CurrencyCode FROM TCD.UserMaster AS UM WHERE UM.UserId = @Userid)IS NOT NULL THEN(SELECT
                                                                                                                       CurrencyCode FROM TCD.UserMaster AS UM WHERE UM.UserId = @Userid)
            END AS CurrencyCode, 
            Addr.BillingAddr1, 
            addr.BillingAddr2, 
            addr.City, 
            addr.Country, 
            addr.zip, 
            addr.ShippingAddr1, 
            addr.ShippingAddr2, 
            addr.Shippingcity, 
            addr.Shippingcountry, 
            addr.Shippingzip, 
            p.Rate, 
            p.ExportPath, 
            p.AllowManualRewash, 
            p.DataLiveTime, 
            p.BudgetCustomer,  
            CASE
                WHEN(SELECT
                             UOMId FROM TCD.UserMaster AS UM WHERE UM.UserId = @Userid)IS NULL THEN p.UOMId
                WHEN(SELECT
                             UOMId FROM TCD.UserMaster AS UM WHERE UM.UserId = @Userid)IS NOT NULL THEN(SELECT
                                                                                                                UOMId FROM TCD.UserMaster AS UM WHERE
UM.UserId = @Userid)
            END AS UOMId, 
            p.Logo, 
            p.RegionID, 
            (SELECT
                     RegionName FROM TCD.RegionMaster AS R WHERE R.RegionID = P.RegionID)AS RegionName, 
            CASE
                WHEN(SELECT
                             LanguageId FROM TCD.UserMaster AS UM WHERE UM.UserId = @Userid)IS NULL THEN(SELECT
                                                                                                                 Name FROM TCD.LanguageMaster AS L
WHERE L.LanguageId = P.LanguageId)
                WHEN(SELECT
                             LanguageId FROM TCD.UserMaster AS UM WHERE UM.UserId = @Userid)IS NOT NULL THEN(SELECT
                                                                                                                     Name
                                                                                                                 FROM TCD.LanguageMaster AS L
                                                                                                                 WHERE L.LanguageId IN(
                                                                                                             SELECT
                                                                                                                     LanguageId FROM TCD.UserMaster
AS UM WHERE UM.UserId = @Userid))
            END AS LanguageName,
   
            --(select Name From LanguageMaster L where L.LanguageId = P.LanguageId) as LanguageName,  
    
            --(select CurrencyName From [TCD].CurrencyMaster C Where c.CurrencyCode=p.CurrencyCode) AS CurrencyName,  

            CASE
                WHEN(SELECT
                             CurrencyCode FROM TCD.UserMaster AS UM WHERE UM.UserId = @Userid)IS NULL THEN(SELECT
                                                                                                                   CurrencyName FROM TCD.
CurrencyMaster AS C WHERE c.CurrencyCode = P.CurrencyCode)
                WHEN(SELECT
                             CurrencyCode FROM TCD.UserMaster AS UM WHERE UM.UserId = @Userid)IS NOT NULL THEN(SELECT
                                                                                                                       CurrencyName
                                                                                                                   FROM TCD.CurrencyMaster AS C
                                                                                                                   WHERE c.CurrencyCode IN(
                                                                                                               SELECT
                                                                                                                       CurrencyCode FROM TCD.
UserMaster AS UM WHERE UM.UserId = @Userid))
            END AS CurrencyName,
   

    
            --(Select UnitSystem From [TCD].DimensionalUnitSystems DUS where DUS.UnitSystemId=p.UOMId) AS UnitSystem      
            CASE
                WHEN(SELECT
                             UOMId FROM TCD.UserMaster AS UM WHERE UM.UserId = @Userid)IS NULL THEN(SELECT
                                                                                                            UnitSystem
                                                                                                        FROM TCD.DimensionalUnitSystems AS DUS
                                                                                                        WHERE DUS.UnitSystemId = p.UOMId)
                WHEN(SELECT
                             UOMId FROM TCD.UserMaster AS UM WHERE UM.UserId = @Userid)IS NOT NULL THEN(SELECT
                                                                                                                UnitSystem
                                                                                                            FROM TCD.DimensionalUnitSystems AS DUS
                                                                                                            WHERE DUS.UnitSystemId IN(
                                                                                                        SELECT
                                                                                                                UOMId FROM TCD.UserMaster AS UM WHERE
UM.UserId = @Userid))
            END AS UOMId, 
            P.LastModifiedTime AS LastModifiedTime, 
            P.MyServiceLastSynchTime AS MyServiceLastSynchTime, 
            P.LastServiceVisitDate AS LastServiceVisitDate, 
            P.LastArchiveDate AS LastArchiveDate, 
            P.NextServiceVisitDate AS NextServiceVisitDate, 
            p.PlantChainId, 
            P.MyServiceCustGuid AS MyServiceId, 
            P.ConStdTurnTime AS PlantStandardTurnTime, 
            P.PlantContractNumber AS PlantContractNumber, 
            P.PlantId AS PlantId, 
            P.DayId AS DayId, 
            P.StartTime AS StartTime, 
            P.EndTime AS EndTime,
			P.IsETechEnable AS IsETechEnable,
		    P.ETechIpAddress AS ETechIpAddress
        FROM TCD.plant AS P
             INNER JOIN TCD.PlantCustAddress AS ADDR ON p.EcolabAccountNumber = ADDR.EcolabAccountNumber
        WHERE Is_Deleted = 0
    SET NOCOUNT OFF;
END

GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[SavePlantDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.SavePlantDetails
	END
GO  
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [TCD].[SavePlantDetails] (
@EcolabAccountNumber NVARCHAR(25)		,			--= NULL,	Making it as NOT-NULLable
@LanguageId          INT = NULL,
@CurrencyCode        NVARCHAR(1000)= NULL,
@Rate                NVARCHAR(100) = NULL,
@ExportPath          NVARCHAR(1000 )= NULL,
@DataLiveTime        INT = NULL,
@BudgetCustomer      BIT = NULL,
@UOMId               INT = NULL,
@Logo                VARBINARY(max) = NULL,
@UserID              INT, -- = NULL    /*Making this NON-NULLable, since we NEED this for audit
@AllowManualRewash   BIT = NULL	,
@DayId				 INT = NULL,
@StartTime			 TIME = NULL,
@EndTime			 TIME = NULL,
@EtechIpAddress			  NVARCHAR(100) = NULL,
@IsETechEnable			 BIT = NULL,
@OutputEcolabAccountNumber			NVARCHAR (1000)		=			NULL	OUTPUT	,
@LastModifiedTimestampAtCentral		DATETIME			=			NULL			,
@OutputLastModifiedTimestampAtLocal	DATETIME			=			NULL	OUTPUT
)
AS
BEGIN
SET nocount ON;


DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()

DECLARE
		@OutputList						AS	TABLE		(
		EcolabAccountNumber				NVARCHAR (1000)
	,	LastModifiedTimestamp			DATETIME
	)

SET		@OutputLastModifiedTimestampAtLocal			=			ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight SA0121
SET		@OutputEcolabAccountNumber					=			ISNULL(@OutputEcolabAccountNumber, NULL)					--SQLEnlight SA0121

IF	(
		@LastModifiedTimestampAtCentral				IS NOT	NULL
	AND
	NOT	EXISTS	(	SELECT	1
					FROM	TCD.Plant				P
					WHERE	P.EcolabAccountNumber	=	@EcolabAccountNumber
						AND	P.LastModifiedTime		=	@LastModifiedTimestampAtCentral
				)
	)
		BEGIN
				SET			@ErrorId				=	60000
				SET			@ErrorMessage			=	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
				RAISERROR	(@ErrorMessage, 16, 1)
				SET			@ReturnValue			=	-1
				RETURN		(@ReturnValue)
		END


--Proceed to update, since it's either a local call or Synch. call with synch. time matching
BEGIN
UPDATE P
SET    LanguageId = @LanguageId,
CurrencyCode =  @CurrencyCode ,
ExportPath =    @ExportPath,

DataLiveTime =@DataLiveTime,
BudgetCustomer = @BudgetCustomer,
UOMId =   @UOMId,

Rate =   @rate
,
Logo = @Logo
,LastModifiedByUserId = @UserID
, AllowManualRewash = @AllowManualRewash
,	P.LastModifiedTime			=			@CurrentUTCTime
,	P.StartTime	= @StartTime
,	P.EndTime = @EndTime
,	P.DayId	= @DayId
,	P.ETechIpAddress	= @EtechIpAddress
,	P.IsETechEnable = @IsETechEnable
OUTPUT
	inserted.EcolabAccountNumber	AS			EcolabAccountNumber
,	inserted.LastModifiedTime		AS			LastModifiedTimestamp
INTO
	@OutputList	(
	EcolabAccountNumber
,	LastModifiedTimestamp
)
FROM   [TCD].plant P
WHERE  p.ecolabaccountnumber = @EcolabAccountNumber
END


--Output the updated Id and the LastModifiedTime
SELECT	TOP 1	
		@OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp
	,	@OutputEcolabAccountNumber			=	O.EcolabAccountNumber
FROM	@OutputList							O




SET NOCOUNT OFF;
END

GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetWasherList]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetWasherList
	END
GO  
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*	
Purpose					:	To populate the grid in the Washer setup --> Washers listing

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version

*/

CREATE	PROCEDURE    [TCD].[GetWasherList] -- '040242802', 4,2
     @EcoLabAccountNumber     NVARCHAR(1000)

    , @WasherGroupId       INT   =   NULL
    , @WasherId        INT   =   NULL
    , @Is_Deleted        bit   =   'FALSE'
AS
BEGIN

SET NOCOUNT ON


SELECT --*
  W.PlantWasherNumber    AS   WasherNumber
 , MS.MachineName     AS   WasherName
 , CASE MS.IsTunnel
   WHEN 'TRUE' THEN 'Tunnel'
   WHEN 'FALSE' THEN 'WasherExtractor'
  END        AS   WasherType
 , MS.IsTunnel      AS   WasherTypeFlag
 , WMS.WasherModelName    AS   WasherModel
 , WMS.WasherModelId    AS   WasherModelId
 , WMS.WasherSize     AS   WasherSize
 , CASE WHEN CC.ControllerId = 0 THEN '' ELSE CC.Name END AS   WasherControllerName
 , W.WasherId      AS   WasherId
 , WG.WasherGroupId    AS   WasherGroupId
 , WG.WasherGroupName    AS   WasherGroupName
 , CC.ControllerId     AS   WasherControllerId

 , W.[Description]     AS   WasherDescription
 , W.MaxLoad      AS   WashermaxLoad

 , W.WasherMode     AS   WasherModeId

 , W.AWEActive      AS   WasherAWEActive
 , MS.NumberOfComp     AS   WasherNumberOfCompartments

 , CAST(W.NumberOfTanks AS SMALLINT)
          AS   WasherNumberOfTanks
 , CAST(W.PressExtractor AS SMALLINT)
          AS   WasherPressExtractorId
 , CAST(W.TransferType  AS SMALLINT)
          AS   WasherTransferTypeId
 , CASE MS.IsTunnel WHEN 1 THEN CAST(W.EmptyPocketNumber AS SMALLINT) ELSE CAST(W.EndOfFormula AS SMALLINT) END AS WasherProgramNumber

 -- Columns for conventionals
 , W.HoldSignal     AS   HoldDelay
 , CAST(W.HoldDelay AS INT)  AS   HoldSignal
 , CAST(W.TargetTurnTime AS INT) AS   TargetTurnTime
 , CAST(W.WaterFlushTime AS INT) AS   WaterFlushTime
 , MS.MachineInternalId   AS   LFSWasherNumber

    --    Cols. for integration with Synch./Central
    ,    W.LastModifiedTime                AS            LastModifiedTime
    ,    W.LastSyncTime                    AS            LastSyncTime
    ,    W.Is_Deleted                    AS            Is_Deleted
    ,    W.EcoLabAccountNumber            AS            EcolabAccountNumber
    ,    (SELECT Count(*) FROM tcd.TunnelProgramSetup wps WHERE wps.WasherGroupId=@WasherGroupId AND wps.Is_Deleted=0) AS FormulaCount
    ,    GT.MyServiceCustMchGrpGuid
    ,    W.MyServiceCustMchGuid
    ,    WMS.MyServiceMCHId
    ,    TPE.Name                        AS            PressExtractorName
    ,    TTT.Name                        AS            TransferTypeName
    ,   W.RatioDosingActive                AS            RatioDosingActive
    ,    W.EcolabWasherId                AS            EcolabWasherNumber
    ,    CAST(W.EndOfFormula AS SMALLINT)     AS            EndOfFormula
    ,    W.MyServiceLastSynchTime             AS            MyServiceLastSynchTime
    ,    CC.ControllerTypeId                 AS            ControllerTypeId
    ,    CT.Name                         AS            ControllerType
    ,    CC.ControllerModelId             AS            ControllerModelId
    ,    CM.Name                         AS            ControllerModel
    ,    W.NumberOfCompartmentsConveyorBelt
    ,    W.MinMachineLoad
    ,    W.MaxMachineLoad
    ,    W.ProgramSelectionByTime
    ,    W.WeightSelectionByTime
    ,    W.WeightSelectionByAnalogInput
    ,    W.TunInTomMode
    ,    COALESCE(W.SignalStopTunActive,'TRUE')        AS          SignalStopTunActive
    ,    COALESCE(W.SignalEjectionTunActive,'TRUE')    AS          SignalEjectionTunActive
    ,    W.DelayTimeForTunWashingPrograms
    ,    W.KannegiesserPressSpecialMode
    ,    W.ValveOutputsUsedAsTomSignal
    ,    W.ExtendedClockOrDataProtocol
    ,    W.WeightCorrectionFcc
    ,    W.FlowSwitchNumber            
    ,    W.WasherStopExternalSignal    
    ,    COALESCE(W.OnHoldWESignalActive,'TRUE')         AS           OnHoldWESignalActive        
    ,    W.WasherOnHoldSignalDelay    
    ,    W.WEInTOMMode                
    ,    W.ManifoldFlushTime            
    ,    W.L1                        
    ,    W.L2                        
    ,    W.L3                        
    ,    W.L4                        
    ,    W.L5                        
    ,    W.L6                        
    ,    W.L7                        
    ,    W.L8                        
    ,    W.L9                        
    ,    W.L10                        
    ,    W.L11                        
    ,    W.L12
    ,   MS.IsPony AS IsPony
    ,    W.PlantId
    ,    W.UseMe1OfGroup
    ,    W.UseMe2OfGroup
    ,    W.UsePumpOfGroup
    ,    W.WasherStopUseFinalExtracting
    ,    W.TemperatureAlarmYesNo
    ,    W.PhProbe
    ,    w.WeightCell
    ,    W.Temperature
    ,    W.WaterCounter    
    ,    W.DateAndTimeWhenBatchEjects            
    ,    W.AutoRinseDesamixAfter            
    ,    W.AutoRinseDesamix1For
    ,    W.AutoRinseDesamix2For
    ,    W.TemperatureAlarmProbe1
    ,    W.TemperatureAlarmProbe2
    ,    W.TemperatureAlarmProbe3
	,   CAST(W.DefaultIdleTime AS INT) AS   DefaultIdleTime
	,   W.ETechWasherNumber AS    ETechWasherNumber 

FROM    [TCD].WasherGroup                    WG
JOIN    [TCD].MachineGroup                    GT
    ON    WG.WasherGroupId                =            GT.Id
    AND    WG.EcolabAccountNumber            =            GT.EcolabAccountNumber
JOIN    [TCD].MachineSetup                    MS
    ON    WG.WasherGroupId                =            MS.GroupId
    AND    WG.EcolabAccountNumber            =            MS.EcoalabAccountNumber
JOIN    [TCD].Washer                        W
    ON    MS.WasherId                        =            W.WasherId
    AND    MS.EcoalabAccountNumber            =            W.EcoLabAccountNumber
JOIN    [TCD].WasherModelSize                WMS
    ON    W.ModelId                        =            WMS.WasherModelId
JOIN    [TCD].ConduitController                CC
    ON    MS.ControllerId                    =            CC.ControllerId
    AND    MS.EcoalabAccountNumber            =            CC.EcoalabAccountNumber
LEFT JOIN TCD.ControllerType CT  ON CT.Id = CC.ControllerTypeId  
LEFT JOIN TCD.ControllerModel CM ON CM.Id = CC.ControllerModelId
LEFT JOIN    [TCD].TunnelPressExtractor            TPE
    ON    W.PressExtractor                =            TPE.TunnelPressExtractorId        
LEFT JOIN    [TCD].TunnelTransferType            TTT
    ON    W.TransferType                    =            TTT.TunnelTransferTypeId
WHERE    GT.EcolabAccountNumber            =            @EcoLabAccountNumber
    AND    GT.GroupTypeId                       =            2
 
 AND (GT.Is_Deleted     =   'FALSE' OR GT.Is_Deleted = @Is_Deleted)
 AND WG.WasherGroupId    =   ISNULL(@WasherGroupId, WG.WasherGroupId)
 AND WG.EcolabAccountNumber   =   @EcoLabAccountNumber
 AND MS.EcoalabAccountNumber   =   @EcoLabAccountNumber
 AND (MS.IsDeleted     =   'FALSE' OR MS.IsDeleted = @Is_Deleted)
 AND (W.Is_Deleted     =   'FALSE' OR W.Is_Deleted = @Is_Deleted)
 AND W.WasherId      =   ISNULL(@WasherId, W.WasherId)
 AND W.EcoLabAccountNumber   =   @EcoLabAccountNumber




SET NOCOUNT OFF

END

GO
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[UpdateConventional]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.UpdateConventional
	END
GO  
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*	
Purpose					:	To update Conventional Washer details from the Washer setup UI - General tab

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version

--sp_helptext	usp_UpdateConventional

*/

CREATE	PROCEDURE	[TCD].[UpdateConventional]
					@EcoLabAccountNumber					NVARCHAR(1000)
				,	@WasherId								INT
				,	@WasherGroupId							INT
				, @NewWasherGroupId							int		=	null
				,	@ConventionalName						NVARCHAR(50)
				,	@ModelId								INT						--(Washer)Model Id for Size
				,	@ControllerId							INT
				,	@LFSWasherNumber						TINYINT
				,	@PlantWasherNumber						SMALLINT
				,	@WasherMode								TINYINT
				,	@MaxLoad								SMALLINT
				,	@AWEActive								BIT
				,	@HoldSignal								BIT
				,	@HoldDelay								SMALLINT															
				,	@TargetTurnTime							SMALLINT
				,	@WaterFlushTime							SMALLINT
				,	@ProgramNumber							TINYINT					--EOF number
				,	@Description							NVARCHAR(1024)	=			NULL
				,	@UserId									INT
				,	@LastModifiedTimestampAtCentral			DATETIME				=	NULL
				,	@OutputLastModifiedTimestampAtLocal		DATETIME				=	NULL	OUTPUT
				,	@RatioDosingActive						BIT			
				,	@IsPony BIT  
				,	@MinMachineLoad							SMALLINT				=	NULL
				,	@MaxMachineLoad							smallint				=	NULL
				,	@ProgramSelectionByTime					bit						=	NULL
				,	@FlowSwitchNumber						int						=	NULL
				,	@WasherStopExternalSignal				bit						=	NULL
				,	@OnHoldWESignalActive					bit						=	NULL
				,	@WasherOnHoldSignalDelay				int						=	NULL
				,	@ValveOutputsUsedAsTomSignal			bit						=	NULL
				,	@WeInTomMode							bit						=	NULL
				,	@ManifoldFlushTime						int						=	NULL
				,	@L1										bit						=	NULL
				,	@L2										bit						=	NULL
				,	@L3										bit						=	NULL
				,	@L4										bit						=	NULL
				,	@L5										bit						=	NULL
				,	@L6										bit						=	NULL
				,	@L7										bit						=	NULL
				,	@L8										bit						=	NULL
				,	@L9										bit						=	NULL
				,	@L10									bit						=	NULL
				,	@L11									bit						=	NULL
				,	@L12									bit						=	NULL
				,	@UseMe1OfGroup							tinyint					=	NULL
				,	@UseMe2OfGroup							tinyint					=	NULL
				,	@UsePumpOfGroup							tinyint					=	NULL
				,	@WasherStopUseFinalExtracting			bit						=	NULL
				,	@TemperatureAlarmYesNo					bit						=	NULL
				, @DefaultIdleTime							INT						=   NULL
				, @ETechWasherNumber						INT						=   NULL
AS
BEGIN

SET NOCOUNT ON


DECLARE 
  @ReturnValue     INT    =   0
 , @ErrorId      INT    =   0
 , @ErrorMessage     NVARCHAR(4000) =   N''
 , @CurrentUTCTime     DATETIME  =   GETUTCDATE()
 , @PlantId		INT			=	NULL
 , @ControllerModelId INT = NULL

DECLARE
   @OutputList      AS TABLE  (
   LastModifiedTimestamp   DATETIME
  )

SET  @OutputLastModifiedTimestampAtLocal    =   ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)   --SQLEnlight
SELECT  @PlantId = PlantId From TCD.Plant WHERE EcolabAccountNumber = @EcoLabAccountNumber
SELECT @ControllerModelId = cmctm.ControllerModelId 
FROM TCD.ControllerModelControllerTypeMapping cmctm 
INNER JOIN TCD.ConduitController cc 
	ON cc.ControllerModelId = cmctm.ControllerModelId
WHERE cc.ControllerId = @ControllerId AND cc.EcoalabAccountNumber = @EcoLabAccountNumber

--Valid Washer-Id check...
IF NOT EXISTS ( SELECT 1
     FROM [TCD].Washer      W
     JOIN [TCD].MachineSetup    MS
      ON W.WasherId     =   MS.WasherId
      AND W.EcoLabAccountNumber  =   MS.EcoalabAccountNumber
     WHERE W.EcoLabAccountNumber  =   @EcoLabAccountNumber
      AND W.WasherId     =   @WasherId
      AND MS.GroupId     =   @WasherGroupId
      AND W.Is_Deleted    =   'FALSE'
      AND MS.IsDeleted    =   'FALSE'
    )
   BEGIN
    SET  @ErrorId      =   51006
    SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Washer-ID was provided for Updating.'
    --GOTO ErrorHandler
    RAISERROR (@ErrorMessage, 16, 1)
    SET  @ReturnValue = -1
    RETURN (@ReturnValue)
   END

--Check for uniqueness of PlantWasherNo. and Name
IF EXISTS  ( SELECT 1
     FROM [TCD].Washer      W
     JOIN [TCD].MachineSetup    MS
      ON W.WasherId     =   MS.WasherId
      AND W.EcoLabAccountNumber  =   MS.EcoalabAccountNumber
     WHERE W.EcoLabAccountNumber  =   @EcoLabAccountNumber
      AND W.WasherId     <>   @WasherId AND W.PlantWasherNumber   =   @PlantWasherNumber
      AND (
       W.PlantWasherNumber   =   @PlantWasherNumber       
       OR
       MS.MachineName    =   @ConventionalName
       )
      AND W.Is_Deleted    =   'FALSE'
      AND MS.IsDeleted    =   'FALSE'
    )
   BEGIN
    SET  @ErrorId      =   51002
    SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Specified Plant Washer #/ already exists.'
    --GOTO ErrorHandler
    RAISERROR (@ErrorMessage, 16, 1)
    SET  @ReturnValue = -1
    RETURN (@ReturnValue)
   END

IF @ControllerId > 0
BEGIN
--Check Max LFSWasher No.
IF NOT EXISTS ( SELECT 1
     FROM [TCD].ControllerModelControllerTypeMapping
              CMCTM
     JOIN [TCD].ConduitController   CC
      ON CC.ControllerTypeId   =   CMCTM.ControllerTypeId
      AND CC.ControllerModelId  =   CMCTM.ControllerModelId
     WHERE CC.EcoalabAccountNumber  =   @EcoLabAccountNumber
      AND CC.ControllerId    =   @ControllerId
      AND CC.IsDeleted    =   'FALSE'
      AND CMCTM.MaximumWasherExtractorCount
              >=   @LFSWasherNumber
    )
   BEGIN
    SET  @ErrorId      =   51003
    SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller/LFSWasher# was provided.'
    --GOTO ErrorHandler
    RAISERROR (@ErrorMessage, 16, 1)
    SET  @ReturnValue = -1
    RETURN (@ReturnValue)
   END

      --ETechWasherNumber duplicate check...
IF(@ControllerModelId NOT IN (7,8,9,10,11,14))
BEGIN 
--ETechWasherNumber duplicate check...
IF  EXISTS ( SELECT 1
    FROM [TCD].Washer  AS W
    JOIN [TCD].MachineSetup AS MS ON MS.WasherId = W.WasherId 
    where W.ETechWasherNumber = @ETechWasherNumber
   AND MS.IsTunnel                    =            'FALSE'
)  
BEGIN  

SET  @ErrorId      =   51012  
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate ETechWasherNumber# provided.'  
--GOTO ErrorHandler  
RAISERROR (@ErrorMessage, 16, 1)  
SET  @ReturnValue = -1  
RETURN (@ReturnValue)  
END
END
END
--EOF should not be an asocciated formula for the WG...
IF EXISTS  ( SELECT 1
     FROM [TCD].WasherProgramSetup   WPS
     WHERE WPS.EcolabAccountNumber  =   @EcoLabAccountNumber
      AND WPS.WasherGroupId   =   @WasherGroupId
      AND WPS.ProgramNumber   =   @ProgramNumber
      AND WPS.Is_Deleted    =   'FALSE'
    )
   BEGIN
    SET  @ErrorId      =   51004
    SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An assoicated formula cannot be specified as End-Of-Formula.'
    --GOTO ErrorHandler
    RAISERROR (@ErrorMessage, 16, 1)
    SET  @ReturnValue = -1
    RETURN (@ReturnValue)
   END

IF @ControllerId > 0
BEGIN
--WasherMode check
IF NOT EXISTS ( SELECT 1
     FROM [TCD].ControllerModelControllerTypeMapping
              CMCTM
					JOIN	[TCD].ConduitController			CC
						ON	CC.ControllerTypeId			=			CMCTM.ControllerTypeId
						AND	CC.ControllerModelId		=			CMCTM.ControllerModelId
					JOIN	[TCD].[WasherModeMapping]
              CTM2WM
      ON CMCTM.Id     =   CTM2WM.ControllerModelControllerTypeMappingId
     WHERE CC.EcoalabAccountNumber  =   @EcoLabAccountNumber
      AND CC.ControllerId    =   @ControllerId
      AND CC.IsDeleted    =   'FALSE'
      AND CTM2WM.WasherModeId   =   @WasherMode
    )
   BEGIN
    SET  @ErrorId      =   51005
    SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherMode was provided.'
    --GOTO ErrorHandler
    RAISERROR (@ErrorMessage, 16, 1)
    SET  @ReturnValue = -1
    RETURN (@ReturnValue)
   END

--LFSWasherNumber duplicate check...
IF	EXISTS	(	SELECT	1
				FROM	[TCD].MachineSetup					MS
				WHERE	MS.ControllerId					=			@ControllerId
					AND	MS.MachineInternalId			=			@LFSWasherNumber
					AND	MS.IsDeleted					=			'FALSE'
					AND	MS.WasherId						<>			@WasherId
					AND MS.EcoalabAccountNumber			=			@EcoLabAccountNumber
					AND MS.IsTunnel						=			'FALSE'
   )
   BEGIN
    SET  @ErrorId      =   51010
    SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate LFSWasher# provided.'
    --GOTO ErrorHandler
    RAISERROR (@ErrorMessage, 16, 1)
    SET  @ReturnValue = -1
    RETURN (@ReturnValue)
   END
END

IF (
   @LastModifiedTimestampAtCentral    IS NOT NULL
   AND
   NOT EXISTS ( SELECT 1
     FROM TCD.Washer  W
     WHERE W.EcolabAccountNumber = @EcolabAccountNumber
      AND W.WasherId    = @WasherId
      AND W.LastModifiedTime  = @LastModifiedTimestampAtCentral
    )
 )
  BEGIN
    SET   @ErrorId    = 60000
    SET   @ErrorMessage   = N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
    RAISERROR (@ErrorMessage, 16, 1)
    SET   @ReturnValue   = -1
    RETURN  (@ReturnValue)
  END


--Now attempt Update...
BEGIN TRAN

UPDATE MS
 SET MS.MachineName     =   @ConventionalName
 , MS.ControllerId     =   @ControllerId
 , MS.MachineInternalId   =   @LFSWasherNumber
 , MS.LastModifiedByUserId   =   @UserId
 ,MS.IsPony = @IsPony
FROM [TCD].MachineSetup     MS
JOIN [TCD].Washer       W
 ON MS.WasherId      =   W.WasherId
 AND MS.EcoalabAccountNumber   =   W.EcolabAccountNumber
WHERE MS.WasherId      =   @WasherId
 AND MS.EcoalabAccountNumber   =   @EcoLabAccountNumber
 AND MS.IsDeleted     =   'FALSE'
 AND W.Is_Deleted     =   'FALSE'

--check for any error
SET @ErrorId = @@ERROR

IF (@ErrorId <> 0)
BEGIN

  IF @@TRANCOUNT > 0
  BEGIN
   ROLLBACK TRAN
  END
 
  SET  @ErrorMessage    =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating washer data.'
  --GOTO ErrorHandler
  RAISERROR (@ErrorMessage, 16, 1)
  SET  @ReturnValue = -1
  RETURN (@ReturnValue)
END

--else, continue with the rest of the update in the other table...
UPDATE	W
	SET	W.ModelId						=			@ModelId
	,	W.PlantWasherNumber				=			@PlantWasherNumber
	,	W.WasherMode					=			@WasherMode
	,	W.MaxLoad						=			@MaxLoad
	,	W.AWEActive						=			@AWEActive
	,	W.HoldSignal					=			@HoldSignal
	,	W.HoldDelay						=			@HoldDelay
	,	W.TargetTurnTime				=			@TargetTurnTime
	,	W.WaterFlushTime				=			@WaterFlushTime
	,	W.EndOfFormula					=			@ProgramNumber
	,	W.[Description]					=			@Description
	,	W.LastModifiedByUserId			=			@UserId
	,	W.LastModifiedTime				=			@CurrentUTCTime
	,   W.RatioDosingActive				=			@RatioDosingActive
	,	W.MinMachineLoad				=			@MinMachineLoad				
	,	W.MaxMachineLoad				=			@MaxMachineLoad				
	,	W.ProgramSelectionByTime		=			@ProgramSelectionByTime		
	,	W.FlowSwitchNumber				=			@FlowSwitchNumber			
	,	W.WasherStopExternalSignal		=			@WasherStopExternalSignal	
	,	W.OnHoldWESignalActive			=			@OnHoldWESignalActive		
	,	W.WasherOnHoldSignalDelay		=			@WasherOnHoldSignalDelay	
	,	W.ValveOutputsUsedAsTomSignal	=			@ValveOutputsUsedAsTomSignal
	,	W.WEInTOMMode					=			@WeInTomMode				
	,	W.ManifoldFlushTime				=			@ManifoldFlushTime			
	,	W.L1							=			@L1
	,	W.L2							=			@L2
	,	W.L3							=			@L3
	,	W.L4							=			@L4
	,	W.L5							=			@L5
	,	W.L6							=			@L6
	,	W.L7							=			@L7
	,	W.L8							=			@L8
	,	W.L9							=			@L9
	,	W.L10							=			@L10
	,	W.L11							=			@L11
	,	W.L12							=			@L12
	,	W.UseMe1OfGroup					=			@UseMe1OfGroup
	,	W.UseMe2OfGroup					=			@UseMe2OfGroup
	,	W.UsePumpOfGroup				=			@UsePumpOfGroup
	,	W.WasherStopUseFinalExtracting	=			@WasherStopUseFinalExtracting
	,	W.TemperatureAlarmYesNo			=			@TemperatureAlarmYesNo
	,	W.PlantId						=			@PlantId
	,   W.DefaultIdleTime               =           @DefaultIdleTime
	,   W.ETechWasherNumber               =         @ETechWasherNumber

OUTPUT
 inserted.LastModifiedTime  AS   LastModifiedTimestamp
INTO
 @OutputList (
 LastModifiedTimestamp
)
FROM [TCD].Washer      W
JOIN [TCD].MachineSetup     MS
 ON W.WasherId      =   MS.WasherId
 AND W.EcoLabAccountNumber   =   MS.EcoalabAccountNumber
WHERE W.WasherId      =   @WasherId
 AND W.EcoLabAccountNumber   =   @EcoLabAccountNumber
 AND W.Is_Deleted     =   'FALSE'
 AND MS.IsDeleted     =   'FALSE'


 IF(@NewWasherGroupId IS NOT NULL AND (@WasherGroupId != @NewWasherGroupId))
 BEGIN
    UPDATE tcd.machinesetup 
    SET GroupId = @NewWasherGroupId
    WHERE WasherId = @WasherId
     
   EXEC TCD.SaveInjectionDetails @WasherGroupId,@NewWasherGroupId,@ControllerId,@WasherId,@EcolabAccountNumber
 END
 ELSE
 BEGIN
   EXEC TCD.SaveInjectionDetails @WasherGroupId,@WasherGroupId,@ControllerId,@WasherId,@EcolabAccountNumber
 END

--check for error, if none - commit the tran, else rollback
SET @ErrorId = @@ERROR
IF (@ErrorId <> 0)
 BEGIN
  IF (@@TRANCOUNT > 0)
   BEGIN
    ROLLBACK
   END

  SET  @ErrorMessage    =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating washer data.'
  --GOTO ErrorHandler
  RAISERROR (@ErrorMessage, 16, 1)
  SET  @ReturnValue = -1
  RETURN (@ReturnValue)
 END
ELSE
 BEGIN
  IF (@@TRANCOUNT > 0)
   BEGIN
				IF (@ControllerModelId = 7)
				BEGIN
					UPDATE TCD.WasherGroup SET ControllerId = @ControllerId WHERE WasherGroupId = @WasherGroupId
				END
    COMMIT
   END
   
   SELECT TOP 1 @OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp FROM @OutputList O
 END


SET NOCOUNT OFF
RETURN (@ReturnValue)


END
GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[AddConventional]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.AddConventional
	END
GO  
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

 
/*
Purpose					:	To add a new Conventional Washer from the Washer setup UI - General tab

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version

--sp_helptext	usp_AddConventional

*/

CREATE PROCEDURE	[TCD].[AddConventional]
					@EcoLabAccountNumber					NVARCHAR(1000)
				,	@WasherGroupId							INT
				, @NewWasherGroupId		int				=	null
				,	@ConventionalName						NVARCHAR(50)
				,	@ModelId								INT						--(Washer)Model Id for Size
				,	@ControllerId							INT
				,	@LFSWasherNumber						TINYINT					=	NULL
				,	@PlantWasherNumber						SMALLINT
				,	@WasherMode								TINYINT
				,	@MaxLoad								SMALLINT
				,	@AWEActive								BIT
				,	@HoldSignal								BIT
				,	@HoldDelay								SMALLINT															
				,	@TargetTurnTime							SMALLINT
				,	@WaterFlushTime							SMALLINT
				,	@ProgramNumber							TINYINT					--EOF number
				,	@Description							NVARCHAR(1024)			=	NULL
				,	@UserId									INT
				,	@ConventionalWasherGuid					UniqueIdentifier
				,	@ConventionalWasherId					INT									OUTPUT
				,	@LastModifiedTimestampAtCentral			DATETIME				=	NULL
				,	@OutputLastModifiedTimestampAtLocal		DATETIME				=	NULL	OUTPUT
				,	@IsDeleted								BIT						=	'FALSE'
				,   @RatioDosingActive						BIT						=	'FALSE'
,   @IsPony      BIT      = 'FALSE'
				,	@MinMachineLoad							SMALLINT				=	NULL
				,	@MaxMachineLoad							smallint				=	NULL
				,	@ProgramSelectionByTime					bit						=	NULL
				,	@FlowSwitchNumber						int						=	NULL
				,	@WasherStopExternalSignal				bit						=	NULL
				,	@OnHoldWESignalActive					bit						=	NULL
				,	@WasherOnHoldSignalDelay				int						=	NULL
				,	@ValveOutputsUsedAsTomSignal			bit						=	NULL
				,	@WeInTomMode							bit						=	NULL
				,	@ManifoldFlushTime						int						=	NULL
				,	@L1										bit						=	NULL
				,	@L2										bit						=	NULL
				,	@L3										bit						=	NULL
				,	@L4										bit						=	NULL
				,	@L5										bit						=	NULL
				,	@L6										bit						=	NULL
				,	@L7										bit						=	NULL
				,	@L8										bit						=	NULL
				,	@L9										bit						=	NULL
				,	@L10									bit						=	NULL
				,	@L11									bit						=	NULL
				,	@L12									bit						=	NULL
				,	@MyServiceLastSyncTime					DATETIME				=	NULL
				,	@UseMe1OfGroup							tinyint					=	NULL
				,	@UseMe2OfGroup							tinyint					=	NULL
				,	@UsePumpOfGroup							tinyint					=	NULL
				,	@WasherStopUseFinalExtracting			bit						=	NULL
				,	@TemperatureAlarmYesNo					bit						=	NULL
				,   @DefaultIdleTime						INT						=   NULL
				,   @ETechWasherNumber						INT						=   NULL


AS
BEGIN

SET NOCOUNT ON


DECLARE
@ReturnValue     INT    =   0
, @ErrorId      INT    =   0
, @ErrorMessage     NVARCHAR(4000) =   N''

, @WasherId      INT    =   NULL
 , @PlantId		 INT	 =	 NULL
 , @ControllerModelId INT = NULL
--, @WasherModelId     SMALLINT  =   NULL
--, @CurrentUTCTime     DATETIME  =   GETUTCDATE()     --SQLEnlight SA0004

DECLARE
@OutputList      AS TABLE  (
WasherId      INT
, LastModifiedTimestamp   DATETIME
)

SET  @ConventionalWasherId = ISNULL(@ConventionalWasherId, NULL)   --SQLEnlight
SET  @OutputLastModifiedTimestampAtLocal   =   ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)   --SQLEnlight
SET  @LastModifiedTimestampAtCentral    =   ISNULL(@LastModifiedTimestampAtCentral, NULL)    --SQLEnlight SA0029
SELECT  @PlantId = PlantId From TCD.Plant WHERE EcolabAccountNumber = @EcoLabAccountNumber
SELECT @ControllerModelId = cmctm.ControllerModelId 
FROM TCD.ControllerModelControllerTypeMapping cmctm 
INNER JOIN TCD.ConduitController cc 
	ON cc.ControllerModelId = cmctm.ControllerModelId
WHERE cc.ControllerId = @ControllerId AND cc.EcoalabAccountNumber = @EcoLabAccountNumber

--Check that the WasherGroup being associated-to is a valid Conventional-type WG...
IF NOT EXISTS ( SELECT 1
FROM [TCD].WasherGroup     WG
JOIN [TCD].WasherGroupType    WGT
ON WG.WasherGroupTypeId  =   WGT.WasherGroupTypeId
JOIN [TCD].MachineGroup     GT         --this is actually the Groups table and NOT really a Group TYPE
ON WG.WasherGroupId   =   GT.Id   --Id is actually the Id of the Group
AND WG.EcolabAccountNumber  =   GT.EcolabAccountNumber
WHERE WG.WasherGroupId   =   @WasherGroupId
AND GT.EcolabAccountNumber  =   @EcoLabAccountNumber
AND GT.GroupTypeId      =   2   --select GroupMaintype from MachineGroup
AND WGT.WasherGroupTypeName  =   'Conventional'   --select WasherGroupTypeName from WasherGroupType
AND GT.Is_Deleted    =   'FALSE'
)
BEGIN
SET  @ErrorId      =   51001
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherGroup provided.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

--Check for unique PlantWasherNo.
IF EXISTS  ( SELECT 1
FROM [TCD].Washer      W
JOIN [TCD].MachineSetup     MS
ON W.WasherId     =   MS.WasherId
AND W.EcoLabAccountNumber  =   MS.EcoalabAccountNumber
WHERE W.EcoLabAccountNumber  =   @EcoLabAccountNumber
AND (
W.PlantWasherNumber   =   @PlantWasherNumber
)
AND W.Is_Deleted    =   'FALSE'
AND MS.IsDeleted    =   'FALSE'
)
BEGIN
SET  @ErrorId      =   51002
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Specified Plant Washer #/ already exists.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

IF @ControllerId > 0
BEGIN
--Check on valid LFSWasher#/Controller type/model...
IF @LFSWasherNumber IS NOT NULL
BEGIN
	IF NOT EXISTS ( SELECT 1
	FROM [TCD].ControllerModelControllerTypeMapping
	CMCTM
	JOIN [TCD].ConduitController   CC
	ON CC.ControllerTypeId   =   CMCTM.ControllerTypeId
	AND CC.ControllerModelId  =   CMCTM.ControllerModelId
	WHERE CC.EcoalabAccountNumber  =   @EcoLabAccountNumber
	AND CC.ControllerId    =   @ControllerId
	AND CC.IsDeleted    =   'FALSE'
	AND CMCTM.MaximumWasherExtractorCount
	>=   @LFSWasherNumber
	)
		BEGIN
			SET  @ErrorId      =   51003
			SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller/LFSWasher# was provided.'
			--GOTO ErrorHandler
			RAISERROR (@ErrorMessage, 16, 1)
			SET  @ReturnValue = -1
			RETURN (@ReturnValue)
		END
END
END
--EOF should not be an asocciated formula for the WG...
IF EXISTS  ( SELECT 1
FROM [TCD].WasherProgramSetup   WPS
WHERE WPS.EcolabAccountNumber  =   @EcoLabAccountNumber
AND WPS.WasherGroupId   =   @WasherGroupId
AND WPS.ProgramNumber   =   @ProgramNumber
AND WPS.Is_Deleted    =   'FALSE'
)
BEGIN
SET  @ErrorId      =   51004
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An assoicated formula cannot be specified as End-Of-Formula.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

IF @ControllerId > 0
BEGIN
--WasherMode check
IF NOT EXISTS ( SELECT 1
FROM [TCD].ControllerModelControllerTypeMapping
CMCTM
					JOIN	[TCD].ConduitController			CC
						ON	CC.ControllerTypeId			=			CMCTM.ControllerTypeId
						AND	CC.ControllerModelId		=			CMCTM.ControllerModelId
					JOIN	[TCD].[WasherModeMapping]			CTM2WM
						ON	CMCTM.Id					=			CTM2WM.ControllerModelControllerTypeMappingId
					WHERE	CC.EcoalabAccountNumber		=			@EcoLabAccountNumber
						AND	CC.ControllerId				=			@ControllerId
						AND	CC.IsDeleted				=			'FALSE'
						AND	CTM2WM.WasherModeId			=			@WasherMode
)
BEGIN
SET  @ErrorId      =   51005
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherMode was provided.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

--LFSWasherNumber duplicate check...
IF	EXISTS	(	SELECT	1
				FROM	[TCD].MachineSetup					MS
				WHERE	MS.ControllerId					=			@ControllerId
					AND	MS.MachineInternalId			=			@LFSWasherNumber
					AND MS.EcoalabAccountNumber			=			@EcoLabAccountNumber
					AND	MS.IsDeleted					=			'FALSE'
					AND MS.IsTunnel						=			'FALSE'

)
BEGIN
SET  @ErrorId      =   51010
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate LFSWasher# provided.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END
END
--Now attempt to insert a new row for the conventional washer being added...
BEGIN TRAN

INSERT	[TCD].Washer	(
	 EcoLabAccountNumber	,PlantWasherNumber			,ModelId				,WasherMode					,MaxLoad						,AWEActive				,EndOfFormula
	,[Description]			,Is_Deleted					,LastModifiedByUserId	,HoldSignal					,HoldDelay						,TargetTurnTime			,WaterFlushTime		
	,MyServiceCustMchGuid	,RatioDosingActive			,MyServiceLastSynchTime	,MinMachineLoad				,MaxMachineLoad					,ProgramSelectionByTime	,FlowSwitchNumber		
	,WasherStopExternalSignal	,OnHoldWESignalActive	, WasherOnHoldSignalDelay	,ValveOutputsUsedAsTomSignal			,WeInTomMode			,ManifoldFlushTime	
	,L1	,L2	,L3	,L4	,L5	,L6	,L7	,L8	,L9	 ,L10 ,L11	,L12 ,UseMe1OfGroup ,UseMe2OfGroup ,UsePumpOfGroup ,WasherStopUseFinalExtracting ,TemperatureAlarmYesNo ,PlantId, DefaultIdleTime,ETechWasherNumber
)
OUTPUT
inserted.WasherId      AS   Id
, inserted.LastModifiedTime  AS   LastModifiedTimestamp
INTO
@OutputList (
WasherId
, LastModifiedTimestamp
)

SELECT	@EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	@PlantWasherNumber					AS			PlantWasherNumber
	,	@ModelId							AS			ModelId
	,	@WasherMode							AS			WasherMode
	,	@MaxLoad							AS			MaxLoad
	,	@AWEActive							AS			AWEActive
	,	@ProgramNumber						AS			ProgramNumber
	,	@Description						AS			[Description]
	,	@IsDeleted							AS			Is_Deleted
	,	@UserId								AS			LastModifiedByUserId
	,	@HoldSignal							AS			HoldSignal
	,	@HoldDelay							AS			HoldDelay
	,	@TargetTurnTime						AS			TargetTurnTime
	,	@WaterFlushTime						AS			WaterFlushTime
	,	@ConventionalWasherGuid				AS			MyServiceCustMchGuid
	,	@RatioDosingActive					AS			RatioDosingActive
	,	@MyServiceLastSyncTime				AS			MyServiceLastSynchTime
	,	@MinMachineLoad						AS			MinimumMachineLoad
	,	@MaxMachineLoad						AS			MaximumMachineLoad
	,	@ProgramSelectionByTime				AS			ProgramSelectionByTime
	,	@FlowSwitchNumber					AS			FlowSwitchNumber
	,	@WasherStopExternalSignal			AS			WasherStopExternalSignal
	,	@OnHoldWESignalActive				AS			OnHoldWESignalActive
	,	@WasherOnHoldSignalDelay			AS			WasherOnHoldSignalDelay
	,	@ValveOutputsUsedAsTomSignal		AS			ValveOutputsUsedAsTomSignal
	,	@WeInTomMode						AS			WeInTomMode			
	,	@ManifoldFlushTime					AS			ManifoldFlushTime			
	,	@L1									AS			L1
	,	@L2									AS			L2
	,	@L3									AS			L3
	,	@L4									AS			L4
	,	@L5									AS			L5
	,	@L6									AS			L6
	,	@L7									AS			L7
	,	@L8									AS			L8
	,	@L9									AS			L9
	,	@L10								AS			L10
	,	@L11								AS			L11
	,	@L12								AS			L12
	,	@UseMe1OfGroup						AS			UseMe1OfGroup
	,	@UseMe2OfGroup						AS			UseMe2OfGroup
	,	@UsePumpOfGroup						AS			UsePumpOfGroup
	,	@WasherStopUseFinalExtracting		AS			WasherStopUseFinalExtracting
	,	@TemperatureAlarmYesNo				AS			TemperatureAlarmYesNo
	,	@PlantId							AS			PlantId
	,   @DefaultIdleTime AS   DefaultIdleTime 
	,   @ETechWasherNumber AS ETechWasherNumber


SET @ErrorId = @@ERROR

IF (@ErrorId <> 0)
BEGIN
IF @@TRANCOUNT > 0
BEGIN
ROLLBACK TRAN
END

SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred creating new record for conventional.'
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

--if no error, collect the id of the newly generated row...
SELECT TOP 1 @WasherId = O.WasherId FROM @OutputList O

--insert in MachineSetup
INSERT [TCD].MachineSetup (
WasherId ,GroupId ,MachineInternalId ,EcoalabAccountNumber ,MachineName ,IsTunnel ,ControllerId , IsDeleted ,LastModifiedByUserId,IsPony )
SELECT @WasherId     AS   WasherId
, @WasherGroupId    AS   GroupId
, @LFSWasherNumber   AS   MachineInternalId
, @EcoLabAccountNumber  AS   EcoalabAccountNumber
, @ConventionalName   AS   MachineName
,@IsDeleted      AS   IsTunnel
, @ControllerId    AS   ControllerId
, 'FALSE'      AS   IsDeleted
, @UserId      AS   LastModifiedByUserId
,@IsPony As IsPony



 IF(ISNULL( @NewWasherGroupId,0)>0 AND (@WasherGroupId != @NewWasherGroupId))
 BEGIN
    UPDATE tcd.machinesetup 
    SET GroupId = @NewWasherGroupId
    WHERE WasherId = @WasherId
     
   EXEC TCD.SaveInjectionDetails @WasherGroupId,@NewWasherGroupId,@ControllerId,@WasherId,@EcolabAccountNumber
 END
 ELSE
 BEGIN
   EXEC TCD.SaveInjectionDetails @WasherGroupId,@WasherGroupId,@ControllerId,@WasherId,@EcolabAccountNumber
 END

SET @ErrorId = @@ERROR

IF (@ErrorId <> 0)
BEGIN
IF @@TRANCOUNT > 0
BEGIN
ROLLBACK TRAN
END

SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred assoicating new record for conventional.'
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END
ELSE
BEGIN
IF @@TRANCOUNT > 0
BEGIN
COMMIT
END

--SET the output param to be communicated back...

SELECT TOP 1
@OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp
, @ConventionalWasherId    = O.WasherId
FROM @OutputList       O

END




IF ( @ErrorId = 0 )
BEGIN
		IF (@ControllerModelId = 7)
			BEGIN
				UPDATE TCD.WasherGroup SET ControllerId = @ControllerId WHERE WasherGroupId = @WasherGroupId
			END
RETURN (@ReturnValue)
END



--ErrorHandler:
--RAISERROR (@ErrorMessage, 16, 1)
--SET @ReturnValue = -1


--ExitModule:

--RETURN (@ReturnValue)

--SET NOCOUNT OFF

END

GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[UpdateTunnel]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.UpdateTunnel
	END
GO  
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*	
Purpose					:	To edit details of a new Tunnel from the Washer-Tunnel (General) setup screen

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version

*/

CREATE	PROCEDURE    [TCD].[UpdateTunnel]
                    @EcoLabAccountNumber                    NVARCHAR(1000)
                ,    @WasherId                                INT
                ,    @WasherGroupId                            INT                                    --Not updated, for reference only
                ,    @TunnelName                            NVARCHAR(50)
                ,    @WasherModelName                        NVARCHAR(50)
                ,    @RegionId                                SMALLINT
                --,    @Size                                INT
                ,    @ControllerId                            INT
                ,    @LFSWasherNumber                        INT            =            1        --For tunnels, it will be 1 until a diff. number is passed (as per the scenario)
                ,    @PlantWasherNumber                        SMALLINT
                ,    @WasherMode                            SMALLINT
                ,    @MaxLoad                                SMALLINT
                ,    @AWEActive                            BIT
                ,    @NumberOfTanks                            TINYINT
                ,    @NumberOfComp                            INT                                --though this is INT in the table, we should not require it to be so
                ,    @TransferType                            TINYINT
                ,    @PressExtractor                        TINYINT
                ,    @ProgramNumber                            TINYINT
                ,    @EndOfFormula                            TINYINT
                ,    @Description                            NVARCHAR(1024)    =            NULL
                ,    @UserId                                INT
				--Adding these 3 params as part of re-factoring for integration with Synch/Configurator
                ,    @OutputTunnelId                        INT            =            NULL    OUTPUT
                ,    @LastModifiedTimestampAtCentral            DATETIME    =            NULL            --Nullable for local call; Synch/Central call will have to pass this -
																									--else, it will be treated as a local call
                ,    @OutputLastModifiedTimestampAtLocal        DATETIME    =            NULL    OUTPUT
                ,   @RatioDosingActive                        BIT
                ,   @ControllerModelId                        INT        =        NULL
                ,   @NumberOfCompartmentsConveyorBelt            TINYINT    =        NULL
                ,   @MaxMachineLoad                            SMALLINT    =        NULL
                ,   @MinMachineLoad                            SMALLINT    =        NULL
                ,   @ProgramSelectionByTime                    BIT          =        NULL
                ,   @WeightSelectionByTime                    BIT          =        NULL
                ,   @WeightSelectionByAnalogInput                BIT          =        NULL
                ,   @TunInTomMode                            BIT          =        NULL
                ,   @SignalStopTunActive                        BIT          =        NULL
                ,   @SignalEjectionTunActive                      BIT          =        NULL
                ,   @DelayTimeForTunWashingPrograms            BIT          =        NULL
                ,   @KannegiesserPressSpecialMode                BIT          =        NULL
                ,   @ValveOutputsUsedAsTomSignal                BIT          =        NULL
                ,   @ExtendedClockOrDataProtocol                BIT          =        NULL
                ,   @WeightCorrectionFcc                        BIT          =        NULL
				,	@DateAndTimeWhenBatchEjects					BIT	  		=		NULL
				,	@AutoRinseDesamixAfter						SMALLINT	=		NULL
				,	@AutoRinseDesamix1For						SMALLINT	=		NULL
				,	@AutoRinseDesamix2For						SMALLINT	=		NULL
				,	@TemperatureAlarmProbe1						BIT			=		NULL
				,	@TemperatureAlarmProbe2						BIT			=		NULL
				,	@TemperatureAlarmProbe3						BIT			=		NULL
				,	@UseMe1OfGroup							tinyint					=	NULL
				,	@UseMe2OfGroup							tinyint					=	NULL
				,	@ETechWasherNumber						int					=	NULL
AS
BEGIN

SET    NOCOUNT    ON


DECLARE	
        @ReturnValue                    INT                =            0
    ,    @ErrorId                        INT                =            0
    ,    @ErrorMessage                    NVARCHAR(4000)    =            N''

    ,    @WasherModelId                    SMALLINT        =            NULL

    ,    @CurrentUTCTime                    DATETIME        =            GETUTCDATE()
	,	@ControllerValidate				int				=										   0

--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
SET        @OutputLastModifiedTimestampAtLocal                =            @CurrentUTCTime
SET        @OutputTunnelId                                    =            ISNULL(@OutputTunnelId, NULL)            --SQLEnlight

--If the call is not local, check that the LastModifiedTime matches with the central
IF    (
        @LastModifiedTimestampAtCentral            IS NOT    NULL
    AND    NOT    EXISTS    (    SELECT    1
                        FROM    TCD.[Washer]            W
                        WHERE    W.EcolabAccountNumber    =    @EcolabAccountNumber
                            AND    W.WasherId                =    @WasherId
                            AND    W.LastModifiedTime        =    @LastModifiedTimestampAtCentral
					)
	)
	BEGIN
            SET            @ErrorId                    =    60000
            SET            @ErrorMessage                =    N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
            RAISERROR    (@ErrorMessage, 16, 1)
            SET            @ReturnValue                =    -1
            RETURN        (@ReturnValue)
	END

--Proceed, since it's either a local call or Synch. call with synch. time matching


--Valid Washer - based on Id...
IF    NOT    EXISTS    (    SELECT    1
                    FROM    [TCD].Washer                W
                    JOIN    [TCD].MachineSetup            MS
                        ON    W.WasherId                    =            MS.WasherId
                        AND    W.EcoLabAccountNumber        =            MS.EcoalabAccountNumber
                    WHERE    W.EcoLabAccountNumber        =            @EcoLabAccountNumber
                        AND    W.WasherId                    =            @WasherId
                        AND    MS.GroupId                    =            @WasherGroupId
                        AND    MS.IsTunnel                    =            'TRUE'
                        AND    W.Is_Deleted                =            'FALSE'
                        AND    MS.IsDeleted                =            'FALSE'
				)
			BEGIN
                SET        @ErrorId                        =            51006
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Washer-ID was provided for Updating.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET    @ReturnValue    =    -1
                RETURN    (@ReturnValue)
			END


--Check for uniqueness of PlantWasherNo. and Name
IF    EXISTS        (    SELECT    1
                    FROM    [TCD].Washer                W
                    JOIN    [TCD].MachineSetup            MS
                        ON    W.WasherId                    =            MS.WasherId
                        AND    W.EcoLabAccountNumber        =            MS.EcoalabAccountNumber
                    WHERE    W.EcoLabAccountNumber        =            @EcoLabAccountNumber
                        AND    W.WasherId                    <>            @WasherId
                        AND    (
                            W.PlantWasherNumber            =            @PlantWasherNumber
                            OR
                            MS.MachineName                =            @TunnelName
							)
                        AND    W.Is_Deleted                =            'FALSE'
                        AND    MS.IsDeleted                =            'FALSE'
				)
			BEGIN
                SET        @ErrorId                        =            51002
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Specified Plant Washer #/Name already exists.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET    @ReturnValue    =    -1
                RETURN    (@ReturnValue)
			END


--Check that it's a valid Controller type/model (one that can control a Tunnel)
IF	NOT	EXISTS	(	SELECT	1
					FROM	[TCD].ControllerModelControllerTypeMapping
														CMCTM
					JOIN	[TCD].ConduitController		CC
						ON	CC.ControllerTypeId			=			CMCTM.ControllerTypeId
						AND	CC.ControllerModelId		=			CMCTM.ControllerModelId
					WHERE	CC.EcoalabAccountNumber		=			@EcoLabAccountNumber
						AND	CC.ControllerId				=			@ControllerId
						AND	CC.IsDeleted				=			'FALSE'
						AND	CMCTM.CanControlTunnel		=			'TRUE'
				)
			BEGIN
				SET		@ErrorId						=			51003
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller was provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END

--IF  (  @ControllerValidate = 1)
--            BEGIN
--                SET        @ErrorId                        =            51003
--                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller was provided.'
--                --GOTO    ErrorHandler
--                RAISERROR    (@ErrorMessage, 16, 1)
--                SET    @ReturnValue    =    -1
--                RETURN    (@ReturnValue)
--            END


--EOF should not be an asocciated formula for the WG...
IF    EXISTS        (    SELECT    1
                    FROM    [TCD].TunnelProgramSetup    TPS
                    WHERE    TPS.EcolabAccountNumber        =            @EcoLabAccountNumber
                        AND    TPS.WasherGroupId            =            @WasherGroupId
                        AND    TPS.ProgramNumber            =            @ProgramNumber
                        AND    TPS.Is_Deleted                =            'FALSE'
				)
			BEGIN
                SET        @ErrorId                        =            51004
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An assoicated formula cannot be specified as End-Of-Formula.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET    @ReturnValue    =    -1
                RETURN    (@ReturnValue)
			END


--WasherMode check
IF    NOT    EXISTS    (    SELECT    1
                    FROM    [TCD].ControllerModelControllerTypeMapping
														CMCTM
                    JOIN    [TCD].ConduitController        CC
                        ON    CC.ControllerTypeId            =            CMCTM.ControllerTypeId
                        AND    CC.ControllerModelId        =            CMCTM.ControllerModelId
                    JOIN    [TCD].[WasherModeMapping]
														CTM2WM
                        ON    CMCTM.Id                    =            CTM2WM.ControllerModelControllerTypeMappingId
                    WHERE    CC.EcoalabAccountNumber        =            @EcoLabAccountNumber
                        AND    CC.ControllerId                =            @ControllerId
                        AND    CC.IsDeleted                =            'FALSE'
                        --AND    CMCTM.CanControlTunnel        =            'TRUE'
                        AND    CTM2WM.WasherModeId            =            @WasherMode
				)
			BEGIN
                SET        @ErrorId                        =            51005
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherMode was provided.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET    @ReturnValue    =    -1
                RETURN    (@ReturnValue)
			END


--select the WasherModelId based on name
SELECT    TOP    1
        @WasherModelId                        =            WMS.WasherModelId
FROM    [TCD].WasherModelSize                WMS
WHERE    WMS.RegionId                        =            @RegionId
    AND    WMS.WasherModelName                    =            @WasherModelName
    AND    WMS.ModelTypeId                    =            2                            --TypeId 2 for Tunnel
    AND    WMS.Is_Deleted                        =            'FALSE'

--LFSWasherNumber duplicate check...
IF    EXISTS    (    SELECT    1
                FROM    [TCD].MachineSetup                    MS
                WHERE    MS.ControllerId                    =            @ControllerId
                    AND    MS.MachineInternalId            =            @LFSWasherNumber
                    AND    MS.IsDeleted                    =            'FALSE'
                    AND    MS.WasherId                        <>            @WasherId
                    AND MS.EcoalabAccountNumber            =            @EcoLabAccountNumber
                    AND MS.IsTunnel                        =            'TRUE'
            )
            BEGIN
                SET        @ErrorId                        =            51010
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate LFSWasher# provided.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET        @ReturnValue    =    -1
                RETURN    (@ReturnValue)
            END
--ETechWasherNumber duplicate check...
IF(@ControllerModelId NOT IN (7,8,9,10,11,14))
BEGIN 
IF EXISTS ( SELECT 1
    FROM [TCD].Washer  AS W
    JOIN [TCD].MachineSetup AS MS ON MS.WasherId = W.WasherId 
    where W.ETechWasherNumber = @ETechWasherNumber
    AND W.WasherId = @WasherId AND
   MS.IsTunnel                    =            'TRUE'
)  
BEGIN  

SET  @ErrorId      =   51012  
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate ETechWasherNumber# provided.'  
--GOTO ErrorHandler  
RAISERROR (@ErrorMessage, 16, 1)  
SET  @ReturnValue = -1  
RETURN (@ReturnValue)  
END
END
--Now attempt Update...
BEGIN    TRAN

UPDATE    MS
    SET    MS.MachineName                    =            @TunnelName
    ,    MS.ControllerId                =            @ControllerId
    ,    MS.MachineInternalId            =            @LFSWasherNumber
    ,    MS.NumberOfComp                =            @NumberOfComp
    ,    MS.LastModifiedByUserId            =            @UserId
FROM    [TCD].MachineSetup                MS
JOIN    [TCD].Washer                    W
    ON    MS.WasherId                    =            W.WasherId
    AND    MS.EcoalabAccountNumber            =            W.EcolabAccountNumber
WHERE    MS.WasherId                    =            @WasherId
    AND    MS.EcoalabAccountNumber            =            @EcoLabAccountNumber
    AND    MS.IsDeleted                    =            'FALSE'
    AND    W.Is_Deleted                    =            'FALSE'

--check for any error
SET    @ErrorId    =    @@ERROR

IF    (@ErrorId    <>    0)
BEGIN

        IF    @@TRANCOUNT    >    0
		BEGIN
            ROLLBACK    TRAN
		END
	
    SET        @ErrorMessage                =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating washer data.'
    --GOTO    Errorhandler
    RAISERROR    (@ErrorMessage, 16, 1)
    SET    @ReturnValue    =    -1
    RETURN    (@ReturnValue)
END

--else, continue with the rest of the update in the other table...
IF(@ControllerModelId IS NOT NULL AND @ControllerModelId = 7 )
BEGIN
UPDATE    W
    SET    W.ModelId                        =            @WasherModelId
    ,    W.PlantWasherNumber                =            @PlantWasherNumber
    ,    W.WasherMode                    =            @WasherMode
    ,    W.MaxLoad                        =            @MaxLoad
    ,    W.AWEActive                    =            'FALSE'
    ,    W.NumberOfTanks                =            @NumberOfTanks
    ,    W.TransferType                    =            @TransferType
    ,    W.PressExtractor                =            @PressExtractor
    ,    W.EmptyPocketNumber                =            @ProgramNumber
    ,    W.[Description]                =            @Description
    ,    W.LastModifiedByUserId            =            @UserId
    ,    W.LastModifiedTime                =            @CurrentUTCTime
    ,    W.RatioDosingActive                =              NULL    
    ,    W.EndOfFormula                    =            0
    ,    W.NumberOfCompartmentsConveyorBelt     =            @NumberOfCompartmentsConveyorBelt
    ,    W.MinMachineLoad                 =            @MinMachineLoad
    ,    W.MaxMachineLoad                 =            @MaxMachineLoad
    ,    W.ProgramSelectionByTime             =            @ProgramSelectionByTime
    ,    W.WeightSelectionByTime             =            @WeightSelectionByTime
    ,    W.WeightSelectionByAnalogInput     =            @WeightSelectionByAnalogInput
    ,    W.TunInTomMode                     =            @TunInTomMode
    ,    W.SignalStopTunActive             =            @SignalStopTunActive
    ,    W.SignalEjectionTunActive         =            @SignalEjectionTunActive
    ,    W.DelayTimeForTunWashingPrograms     =            @DelayTimeForTunWashingPrograms
    ,    W.KannegiesserPressSpecialMode     =            @KannegiesserPressSpecialMode
    ,    W.ValveOutputsUsedAsTomSignal         =            @ValveOutputsUsedAsTomSignal
    ,    W.ExtendedClockOrDataProtocol         =            @ExtendedClockOrDataProtocol
    ,    W.WeightCorrectionFcc             =            @WeightCorrectionFcc
	,	 W.ETechWasherNumber					=		@ETechWasherNumber
FROM    [TCD].Washer                    W
JOIN    [TCD].MachineSetup                MS
    ON    W.WasherId                    =            MS.WasherId
    AND    W.EcoLabAccountNumber            =            MS.EcoalabAccountNumber
WHERE    W.WasherId                    =            @WasherId
    AND    W.EcoLabAccountNumber            =            @EcoLabAccountNumber
    AND    W.Is_Deleted                    =            'FALSE'
    AND    MS.IsDeleted                    =            'FALSE'
END
ELSE IF(@ControllerModelId IS NOT NULL AND ( @ControllerModelId = 8	OR @ControllerModelId = 9	OR @ControllerModelId = 10 OR @ControllerModelId = 11 OR @ControllerModelId = 14))
BEGIN
UPDATE    W
    SET    W.ModelId                        =            @WasherModelId
    ,    W.PlantWasherNumber                =            @PlantWasherNumber
    ,    W.WasherMode                    =            @WasherMode
    ,    W.MaxLoad                        =            @MaxLoad
    ,    W.AWEActive                    =            'FALSE'
    ,    W.NumberOfTanks                =            @NumberOfTanks
    ,    W.TransferType                    =            @TransferType
    ,    W.PressExtractor                =            @PressExtractor
    ,    W.EmptyPocketNumber                =            @ProgramNumber
    ,    W.[Description]                =            @Description
    ,    W.LastModifiedByUserId            =            @UserId
    ,    W.LastModifiedTime                =            @CurrentUTCTime
    ,    W.RatioDosingActive                =              NULL    
    ,    W.EndOfFormula                    =            0
    ,    W.NumberOfCompartmentsConveyorBelt     =            @NumberOfCompartmentsConveyorBelt
    ,    W.MinMachineLoad                 =            @MinMachineLoad
    ,    W.MaxMachineLoad                 =            @MaxMachineLoad
    ,    W.TunInTomMode                     =            @TunInTomMode
    ,    W.DelayTimeForTunWashingPrograms     =            @DelayTimeForTunWashingPrograms
    ,    W.KannegiesserPressSpecialMode     =            @KannegiesserPressSpecialMode
    ,    W.WeightCorrectionFcc             =            @WeightCorrectionFcc
	,	 W.DateAndTimeWhenBatchEjects		=			@DateAndTimeWhenBatchEjects
	,	 W.AutoRinseDesamixAfter			=			@AutoRinseDesamixAfter
	,	 W.AutoRinseDesamix1For				=			@AutoRinseDesamix1For
	,	 W.AutoRinseDesamix2For				=			@AutoRinseDesamix2For
	,	 W.TemperatureAlarmProbe1			=			@TemperatureAlarmProbe1
	,	 W.TemperatureAlarmProbe2			=			@TemperatureAlarmProbe2
	,	 W.TemperatureAlarmProbe3			=			@TemperatureAlarmProbe3
	,	 W.UseMe1OfGroup					=			@UseMe1OfGroup
	,	 W.UseMe2OfGroup					=			@UseMe2OfGroup
	,	 W.ETechWasherNumber					=		@ETechWasherNumber

FROM    [TCD].Washer                    W
JOIN    [TCD].MachineSetup                MS
    ON    W.WasherId                    =            MS.WasherId
    AND    W.EcoLabAccountNumber            =            MS.EcoalabAccountNumber
WHERE    W.WasherId                    =            @WasherId
    AND    W.EcoLabAccountNumber            =            @EcoLabAccountNumber
    AND    W.Is_Deleted                    =            'FALSE'
    AND    MS.IsDeleted                    =            'FALSE'
END
ELSE
BEGIN
UPDATE    W
    SET    W.ModelId                        =            @WasherModelId
    ,    W.PlantWasherNumber                =            @PlantWasherNumber
    ,    W.WasherMode                    =            @WasherMode
    ,    W.MaxLoad                        =            @MaxLoad
    ,    W.AWEActive                    =            @AWEActive
    ,    W.NumberOfTanks                =            @NumberOfTanks
    ,    W.TransferType                    =            @TransferType
    ,    W.PressExtractor                =            @PressExtractor
    ,    W.EmptyPocketNumber                =            @ProgramNumber
    ,    W.[Description]                =            @Description
    ,    W.LastModifiedByUserId            =            @UserId
    ,    W.LastModifiedTime                =            @CurrentUTCTime
    ,   W.RatioDosingActive                =              @RatioDosingActive    
    ,   W.EndOfFormula                    =            @EndOfFormula
    ,    W.LfsWasher                     =            NULL
    ,    W.NumberOfCompartmentsConveyorBelt     =            NULL
    ,    W.MinMachineLoad                 =            NULL
    ,    W.MaxMachineLoad                 =            NULL
    ,    W.ProgramSelectionByTime             =            NULL
    ,    W.WeightSelectionByTime             =            NULL
    ,    W.WeightSelectionByAnalogInput     =            NULL
    ,    W.TunInTomMode                     =            NULL
    ,    W.SignalStopTunActive             =            NULL
    ,    W.SignalEjectionTunActive         =            NULL
    ,    W.DelayTimeForTunWashingPrograms     =            NULL
    ,    W.KannegiesserPressSpecialMode     =            NULL
    ,    W.ValveOutputsUsedAsTomSignal         =            NULL
    ,    W.ExtendedClockOrDataProtocol         =            NULL
    ,    W.WeightCorrectionFcc             =            NULL
	,	 W.ETechWasherNumber					=		@ETechWasherNumber
FROM    [TCD].Washer                    W
JOIN    [TCD].MachineSetup                MS
    ON    W.WasherId                    =            MS.WasherId
    AND    W.EcoLabAccountNumber            =            MS.EcoalabAccountNumber
WHERE    W.WasherId                    =            @WasherId
    AND    W.EcoLabAccountNumber            =            @EcoLabAccountNumber
    AND    W.Is_Deleted                    =            'FALSE'
    AND    MS.IsDeleted                    =            'FALSE'
END
--check for error, if none - commit the tran, else rollback
SET    @ErrorId    =    @@ERROR
IF    (@ErrorId    <>    0)
	BEGIN
        IF    (@@TRANCOUNT    >    0)
			BEGIN
				ROLLBACK
			END

        SET        @ErrorMessage                =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating washer data.'
        --GOTO    Errorhandler
        RAISERROR    (@ErrorMessage, 16, 1)
        SET    @ReturnValue    =    -1
        RETURN    (@ReturnValue)
	END
ELSE
	BEGIN
        IF    (@@TRANCOUNT    >    0)
			BEGIN
				COMMIT
			END

        SET    @OutputTunnelId    =    @WasherId
	END


--IF    (@ErrorId    =    0)
--    BEGIN
--        --GOTO    ExitModule
--        RETURN    (@ReturnValue)
--    END




--ErrorHandler:
--RAISERROR    (@ErrorMessage, 16, 1)
--SET    @ReturnValue    =    -1




--ExitModule:

SET    NOCOUNT    OFF
RETURN    (@ReturnValue)


END


GO
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[AddTunnel]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.AddTunnel
	END
GO  
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*	
Purpose					:	To add a new Tunnel from the Washer-Tunnel (General) setup screen

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version

*/
CREATE PROCEDURE	[TCD].[AddTunnel]	
					@MyServiceWasherId						UniqueIdentifier
				,	@EcoLabAccountNumber					NVARCHAR(1000)
				,	@WasherGroupId							INT
				,	@TunnelName								NVARCHAR(50)
				,	@WasherModelName						NVARCHAR(50)
				,	@RegionId								SMALLINT
--				,	@Size									INT									--we don't need to save this; ModelId PK determines it
				,	@ControllerId							INT
				,	@LFSWasherNumber						TINYINT			=			1		--For tunnels, it will be 1 until a diff. number is passed (as per the scenario)
				,	@PlantWasherNumber						SMALLINT
				,	@WasherMode								TINYINT
				,	@MaxLoad								SMALLINT
				,	@AWEActive								BIT
				,	@NumberOfTanks							TINYINT
				,	@NumberOfComp							TINYINT								--though this is INT in the table, we should not require it to be so
				,	@TransferType							TINYINT         =			NULL
				,	@PressExtractor							TINYINT       =			NULL
				,	@ProgramNumber							TINYINT
				,	@EndOfFormula							TINYINT
				,	@Description							NVARCHAR(1024)	=			NULL
				,	@UserId									INT

				,	@OutputTunnelId							INT			OUTPUT
				--Adding as part of re-factoring for integration with Synch/Configurator... generated TunnelId (re-named) is already being OUTPUT above
				,	@OutputLastModifiedTimestampAtLocal		DATETIME		=			NULL	OUTPUT
				,   @RatioDosingActive						Bit = 'False'
				,   @ControllerModelId						INT		=		NULL
				,   @NumberOfCompartmentsConveyorBelt			TINYINT	=		NULL
				,   @MaxMachineLoad							TINYINT	=		NULL
				,   @MinMachineLoad							TINYINT	=		NULL
				,   @ProgramSelectionByTime					BIT	  	=		NULL
				,   @WeightSelectionByTime					BIT	  	=		NULL
				,   @WeightSelectionByAnalogInput				BIT	  	=		NULL
				,   @TunInTomMode							BIT	  	=		NULL
				,   @SignalStopTunActive						BIT	  	=		NULL
				,   @SignalEjectionTunActive	  				BIT	  	=		NULL
				,   @DelayTimeForTunWashingPrograms			BIT	  	=		NULL
				,   @KannegiesserPressSpecialMode				BIT	  	=		NULL
				,   @ValveOutputsUsedAsTomSignal				BIT	  	=		NULL
				,   @ExtendedClockOrDataProtocol				BIT	  	=		NULL
				,   @WeightCorrectionFcc						BIT	  	=		NULL
				,	@DateAndTimeWhenBatchEjects					BIT	  		=		NULL
				,	@AutoRinseDesamixAfter						SMALLINT	=		NULL
				,	@AutoRinseDesamix1For						SMALLINT	=		NULL
				,	@AutoRinseDesamix2For						SMALLINT	=		NULL
				,	@TemperatureAlarmProbe1						BIT			=		NULL
				,	@TemperatureAlarmProbe2						BIT			=		NULL
				,	@TemperatureAlarmProbe3						BIT			=		NULL
				,	@ETechWasherNumber						    INT			=		NULL


AS
BEGIN

SET	NOCOUNT	ON


DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''

	,	@WasherId						INT				=			NULL
	,	@WasherModelId					SMALLINT		=			NULL
	--Adding for integration with Synch./Central
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()
	,	@ControllerValidate				int				=										   0

--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
SET		@OutputLastModifiedTimestampAtLocal				=			@CurrentUTCTime
SET		@OutputTunnelId									=			ISNULL(@OutputTunnelId, NULL)			--SQLEnlight

--Check that the WasherGroup being associated-to is a valid Tunnel-type WG...
IF	NOT	EXISTS	(	SELECT	1
					FROM	[TCD].WasherGroup			WG
					JOIN	[TCD].WasherGroupType		WGT
						ON	WG.WasherGroupTypeId		=			WGT.WasherGroupTypeId
					JOIN	[TCD].MachineGroup					GT									--this is actually the Groups table and NOT really a Group TYPE
						ON	WG.WasherGroupId			=			GT.Id			--GroupTypeId is actually the Id of the Group
					WHERE	WG.WasherGroupId			=			@WasherGroupId
						AND	GT.EcolabAccountNumber		=			@EcoLabAccountNumber
						AND	GT.GroupTypeId	  			=			2			--select	GroupMaintype	from	GroupType
						AND	WGT.WasherGroupTypeName		=			'Tunnel'				--select	WasherGroupTypeName	from	WasherGroupType
				)
			BEGIN
				SET		@ErrorId						=			51001
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherGroup provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--Check for only 1 tunnel for a WasherGroup
IF	EXISTS		(	SELECT	1
					FROM	[TCD].MachineSetup			MS
					JOIN	[TCD].Washer				W
						ON	MS.WasherId					=			W.WasherId
					WHERE	MS.GroupId					=			@WasherGroupId
						AND	MS.EcoalabAccountNumber		=			@EcoLabAccountNumber
						AND	MS.IsDeleted				=			'FALSE'
						AND	MS.IsTunnel					=			'TRUE'
						AND	W.Is_Deleted				=			'FALSE'
				)
			BEGIN
				SET		@ErrorId						=			51008
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': A Tunnel has already been added to this Washer Group.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--Check for unique PlantWasherNo.
IF	EXISTS		(	SELECT	1
					FROM	[TCD].Washer				W
					JOIN	[TCD].MachineSetup			MS
						ON	W.WasherId					=			MS.WasherId
						AND	W.EcoLabAccountNumber		=			MS.EcoalabAccountNumber
					WHERE	W.EcoLabAccountNumber		=			@EcoLabAccountNumber
						AND	(
							W.PlantWasherNumber			=			@PlantWasherNumber							
							)
						AND	W.Is_Deleted				=			'FALSE'
						AND	MS.IsDeleted				=			'FALSE'
				)
			BEGIN
				SET		@ErrorId						=			51002
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Specified Plant Washer #/ already exists.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--Check that it's a valid Controller type/model (one that can control a Tunnel)

EXEC @ControllerValidate = [TCD].[ValidateController] 2,@ControllerId,@EcoLabAccountNumber

IF(@ControllerValidate = 1)
				
			BEGIN
				SET		@ErrorId						=			51003
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller was provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--EOF should not be an asocciated formula for the WG...
IF	EXISTS		(	SELECT	1
					FROM	[TCD].TunnelProgramSetup	TPS
					WHERE	TPS.EcolabAccountNumber		=			@EcoLabAccountNumber
						AND	TPS.WasherGroupId			=			@WasherGroupId
						AND	TPS.ProgramNumber			=			@ProgramNumber
						AND	TPS.Is_Deleted				=			'FALSE'
				)
			BEGIN
				SET		@ErrorId						=			51004
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An associated formula cannot be specified as End-Of-Formula.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--WasherMode check
IF	NOT	EXISTS	(	SELECT	1
					FROM	[TCD].ControllerModelControllerTypeMapping
														CMCTM
					JOIN	[TCD].ConduitController		CC
						ON	CC.ControllerTypeId			=			CMCTM.ControllerTypeId
						AND	CC.ControllerModelId		=			CMCTM.ControllerModelId
					JOIN	[TCD].[WasherModeMapping]	CTM2WM
						ON	CMCTM.Id					=			CTM2WM.ControllerModelControllerTypeMappingId
					WHERE	CC.EcoalabAccountNumber		=			@EcoLabAccountNumber
						AND	CC.ControllerId				=			@ControllerId
						AND	CC.IsDeleted				=			'FALSE'
						AND	CMCTM.MaxtunnelCount > 0
						AND	CTM2WM.WasherModeId			=			@WasherMode
				)
			BEGIN
				SET		@ErrorId						=			51005
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherMode was provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--select the WasherModelId based on name
SELECT	TOP	1
		@WasherModelId						=			WMS.WasherModelId
FROM	[TCD].WasherModelSize				WMS
WHERE	WMS.RegionId						=			@RegionId
	AND	WMS.WasherModelName					=			@WasherModelName
	AND	WMS.ModelTypeId						=			2							--TypeId 2 for Tunnel
	AND	WMS.Is_Deleted						=			'FALSE'

--LFSWasherNumber duplicate check...
IF	EXISTS	(	SELECT	1
				FROM	[TCD].MachineSetup					MS
				WHERE	MS.ControllerId					=			@ControllerId
					AND	MS.MachineInternalId			=			@LFSWasherNumber
					AND MS.EcoalabAccountNumber			=			@EcoLabAccountNumber
					AND	MS.IsDeleted					=			'FALSE'
					AND MS.IsTunnel						=			'TRUE'
			)
			BEGIN
				SET		@ErrorId						=			51010
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate LFSWasher# provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET		@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END

--Now attempt to insert a new row for the tunnel record being created...
BEGIN	TRAN
IF(@ControllerModelId IS NOT NULL AND @ControllerModelId = 7 )
BEGIN
INSERT	[TCD].Washer	(
		 MyServiceCustMchGuid
		,EcoLabAccountNumber
		,PlantWasherNumber
		,ModelId
		,WasherMode
		,MaxLoad
		,[Description]
		,Is_Deleted
		,LastModifiedByUserId
		,NumberOfTanks
		,TransferType
		,PressExtractor
	--Adding for integration with Synch./Central
		,LastModifiedTime
		,EmptyPocketNumber
		,NumberOfCompartmentsConveyorBelt
		,MinMachineLoad
		,MaxMachineLoad
		,ProgramSelectionByTime
		,WeightSelectionByTime
		,WeightSelectionByAnalogInput
		,TunInTomMode
		,SignalStopTunActive
		,SignalEjectionTunActive
		,DelayTimeForTunWashingPrograms
		,KannegiesserPressSpecialMode
		,ValveOutputsUsedAsTomSignal
		,ExtendedClockOrDataProtocol
		,WeightCorrectionFcc
		,AWEActive
		,EndOfFormula
		,ETechWasherNumber
	)
SELECT @MyServiceWasherId					AS			MyServiceWasherId	
	,	@EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	@PlantWasherNumber					AS			PlantWasherNumber
	,	@WasherModelId						AS			ModelId
	--,	@Size							AS			Size
	,	@WasherMode						AS			WasherMode
	,	@MaxLoad							AS			MaxLoad
	,	@Description						AS			[Description]
	,	'FALSE'							AS			Is_Deleted
	,	@UserId							AS			LastModifiedByUserId
	,	@NumberOfTanks						AS			NumberOfTanks
	,	@TransferType						AS			TransferType
	,	@PressExtractor					AS			PressExtractor
	,	@CurrentUTCTime					AS			LastModifiedTime
	,	@ProgramNumber						AS			ProgramNumber
	,   @NumberOfCompartmentsConveyorBelt		AS			NumberOfCompartmentsConveyorBelt
	,   @MinMachineLoad						AS			MinMachineLoad
	,   @MaxMachineLoad						AS			MaxMachineLoad
	,   @ProgramSelectionByTime				AS			ProgramSelectionByTime
	,   @WeightSelectionByTime				AS			WeightSelectionByTime
	,   @WeightSelectionByAnalogInput			AS			WeightSelectionByAnalogInput
	,   @TunInTomMode						AS			TunInTomMode
	,   @SignalStopTunActive					AS			SignalStopTunActive
	,   @SignalEjectionTunActive	  			AS			SignalEjectionTunActive
	,   @DelayTimeForTunWashingPrograms		AS			DelayTimeForTunWashingPrograms
	,   @KannegiesserPressSpecialMode			AS			KannegiesserPressSpecialMode
	,   @ValveOutputsUsedAsTomSignal			AS			ValveOutputsUsedAsTomSignal
	,   @ExtendedClockOrDataProtocol			AS			ExtendedClockOrDataProtocol
	,   @WeightCorrectionFcc					AS			WeightCorrectionFcc
	,	'FALSE'							AS			AWEActive
	,	0								AS			EndOfFormula
	,   @ETechWasherNumber			AS			ETechWasherNumber
END
ELSE IF(@ControllerModelId IS NOT NULL AND ( @ControllerModelId = 8	OR @ControllerModelId = 9	OR @ControllerModelId = 10 OR @ControllerModelId = 11 OR @ControllerModelId = 14))
BEGIN
INSERT	[TCD].Washer	(
		 MyServiceCustMchGuid
		,EcoLabAccountNumber
		,PlantWasherNumber
		,ModelId
		,WasherMode
		,MaxLoad
		,[Description]
		,Is_Deleted
		,LastModifiedByUserId
		,NumberOfTanks
		,TransferType
		,PressExtractor
	--Adding for integration with Synch./Central
		,LastModifiedTime
		,EmptyPocketNumber
		,NumberOfCompartmentsConveyorBelt
		,MinMachineLoad
		,MaxMachineLoad
		,ProgramSelectionByTime
		,WeightSelectionByTime
		,WeightSelectionByAnalogInput
		,TunInTomMode
		,SignalStopTunActive
		,SignalEjectionTunActive
		,DelayTimeForTunWashingPrograms
		,KannegiesserPressSpecialMode
		,ValveOutputsUsedAsTomSignal
		,ExtendedClockOrDataProtocol
		,WeightCorrectionFcc
		,AWEActive
		,EndOfFormula
		,AutoRinseDesamixAfter
		,AutoRinseDesamix1For
		,AutoRinseDesamix2For
		,TemperatureAlarmProbe1
		,TemperatureAlarmProbe2
		,TemperatureAlarmProbe3
		,DateAndTimeWhenBatchEjects
		,ETechWasherNumber

	)
SELECT @MyServiceWasherId					AS			MyServiceWasherId	
	,	@EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	@PlantWasherNumber					AS			PlantWasherNumber
	,	@WasherModelId						AS			ModelId
	--,	@Size							AS			Size
	,	@WasherMode						AS			WasherMode
	,	@MaxLoad							AS			MaxLoad
	,	@Description						AS			[Description]
	,	'FALSE'							AS			Is_Deleted
	,	@UserId							AS			LastModifiedByUserId
	,	@NumberOfTanks						AS			NumberOfTanks
	,	@TransferType						AS			TransferType
	,	@PressExtractor					AS			PressExtractor
	,	@CurrentUTCTime					AS			LastModifiedTime
	,	@ProgramNumber						AS			ProgramNumber
	,   @NumberOfCompartmentsConveyorBelt		AS			NumberOfCompartmentsConveyorBelt
	,   @MinMachineLoad						AS			MinMachineLoad
	,   @MaxMachineLoad						AS			MaxMachineLoad
	,   @ProgramSelectionByTime				AS			ProgramSelectionByTime
	,   @WeightSelectionByTime				AS			WeightSelectionByTime
	,   @WeightSelectionByAnalogInput			AS			WeightSelectionByAnalogInput
	,   @TunInTomMode						AS			TunInTomMode
	,   @SignalStopTunActive					AS			SignalStopTunActive
	,   @SignalEjectionTunActive	  			AS			SignalEjectionTunActive
	,   @DelayTimeForTunWashingPrograms		AS			DelayTimeForTunWashingPrograms
	,   @KannegiesserPressSpecialMode			AS			KannegiesserPressSpecialMode
	,   @ValveOutputsUsedAsTomSignal			AS			ValveOutputsUsedAsTomSignal
	,   @ExtendedClockOrDataProtocol			AS			ExtendedClockOrDataProtocol
	,   @WeightCorrectionFcc					AS			WeightCorrectionFcc
	,	'FALSE'							AS			AWEActive
	,	0								AS			EndOfFormula
	,	@AutoRinseDesamixAfter
	,	@AutoRinseDesamix1For
	,	@AutoRinseDesamix2For
	,	@TemperatureAlarmProbe1
	,	@TemperatureAlarmProbe2
	,	@TemperatureAlarmProbe3
	,	@DateAndTimeWhenBatchEjects
	,   @ETechWasherNumber						AS			ETechWasherNumber
END
ELSE
BEGIN
INSERT	[TCD].Washer	(
		MyServiceCustMchGuid
		,EcoLabAccountNumber
		,PlantWasherNumber
		,ModelId
		,WasherMode
		,MaxLoad
		,AWEActive
		,EndOfFormula
		,[Description]
		,Is_Deleted
		,LastModifiedByUserId
		,NumberOfTanks
		,TransferType
		,PressExtractor
	--Adding for integration with Synch./Central
		,LastModifiedTime
		,RatioDosingActive
		,EmptyPocketNumber
	)
SELECT @MyServiceWasherId					AS			MyServiceWasherId	
	,	@EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	@PlantWasherNumber					AS			PlantWasherNumber
	,	@WasherModelId						AS			ModelId
	--,	@Size							AS			Size
	,	@WasherMode						AS			WasherMode
	,	@MaxLoad							AS			MaxLoad
	,	@AWEActive						AS			AWEActive
	,	@EndOfFormula						AS			EndOfFormula
	,	@Description						AS			[Description]
	,	'FALSE'							AS			Is_Deleted
	,	@UserId							AS			LastModifiedByUserId
	,	@NumberOfTanks						AS			NumberOfTanks
	,	@TransferType						AS			TransferType
	,	@PressExtractor					AS			PressExtractor
	,	@CurrentUTCTime					AS			LastModifiedTime
	,   @RatioDosingActive					AS			RatioDosingActive
	,	@ProgramNumber						AS			ProgramNumber 	
END

SET	@ErrorId	=	@@ERROR
	
IF	(@ErrorId	<>	0)
	BEGIN
			IF	@@TRANCOUNT	>	0
			BEGIN
				ROLLBACK	TRAN
			END

			SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred creating new record for tunnel.'
			--GOTO	ErrorHandler
			RAISERROR	(@ErrorMessage, 16, 1)
			SET	@ReturnValue	=	-1
			RETURN	(@ReturnValue)
	END

--if no error, collect the id of the newly generated row...
SELECT	@WasherId	=	SCOPE_IDENTITY()


--insert in MachineSetup
INSERT	[TCD].MachineSetup	(
		WasherId	,GroupId	,MachineInternalId	,EcoalabAccountNumber	,MachineName	,IsTunnel	,ControllerId	,NumberOfComp	,IsDeleted	,LastModifiedByUserId	)
SELECT	@WasherId					AS			WasherId
	,	@WasherGroupId				AS			GroupId
	,	@LFSWasherNumber			AS			MachineInternalId
	,	@EcoLabAccountNumber		AS			EcoalabAccountNumber
	,	@TunnelName					AS			MachineName
	,	'TRUE'						AS			IsTunnel
	,	@ControllerId				AS			ControllerId
	,	@NumberOfComp				AS			NumberOfComp
	,	'FALSE'						AS			IsDeleted
	,	@UserId						AS			LastModifiedByUserId

SET	@ErrorId	=	@@ERROR

IF	(@ErrorId	<>	0)
	BEGIN
			IF	@@TRANCOUNT	>	0
			BEGIN
				ROLLBACK	TRAN
			END

			SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred assoicating new record for tunnel.'
			--GOTO	ErrorHandler
			RAISERROR	(@ErrorMessage, 16, 1)
			SET	@ReturnValue	=	-1
			RETURN	(@ReturnValue)
	END
ELSE
	BEGIN
			IF	@@TRANCOUNT	>	0
			BEGIN
				COMMIT
			END

			--SET the output param to be communicated back...
			SET	@OutputTunnelId	=	@WasherId
	END



--IF	(	@ErrorId	=	0	)
--	BEGIN
--		--GOTO	ExitModule
--		RETURN	(@ReturnValue)
--	END




--ErrorHandler:
--RAISERROR	(@ErrorMessage, 16, 1)
--SET	@ReturnValue	=	-1




--ExitModule:

SET	NOCOUNT	OFF
RETURN	(@ReturnValue)


END
GO

IF EXISTS(SELECT
				  1
			  FROM sys.columns
			  WHERE Name = N'RegionId'
				AND Object_ID = OBJECT_ID(N'[TCD].[ControllerModelRegionMapping]'))
	BEGIN
		ALTER TABLE TCD.ControllerModelRegionMapping ALTER COLUMN RegionId SMALLINT NOT NULL
	END
GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetControllerEquipmentList]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetControllerEquipmentList
	END
GO 

CREATE PROCEDURE [TCD].[GetControllerEquipmentList]                  
  @EcoLabAccountNumber     NVARCHAR(1000)                  
    , @ControllerId       INT                  
    , @ControllerEquipmentId     TINYINT = NULL                  
    , @IsActive       BIT = NULL                  
AS
BEGIN
    SET NOCOUNT ON;                  
    DECLARE                  
     @ErrorMessage         NVARCHAR(4000)                  
     ,@PumpValveCount        TINYINT                  
     ,@MECount          TINYINT                  
     ,@ControllerEquipmentTypeId_PumpValve    TINYINT                  
     ,@ControllerEquipmentTypeId_ME      TINYINT                  
     ,@ControllerModelId        INT                  
     ,@ReturnValue         INT = 0                  
     ,@TagTypeLfs         VARCHAR(100) = 'Tag_NML'                  
     ,@TagTypeKfactor         VARCHAR(100) = 'Tag_PPOL'                  
     ,@TagTypeCalibration        VARCHAR(100) = 'Tag_OPSL'            
 ,@ControllerTypeId INT;                  

    CREATE TABLE #Equipment (                  
    ControllerEquipmentId     INT    IDENTITY(1, 1)                  
  , ControllerEquipmentTypeId     TINYINT   NULL                  
  , IsActive        BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , ProductId        INT    NULL                  
  , ProductName       NVARCHAR(255)  NULL                  
  , PumpCalibration       DECIMAL(18, 3)  NULL                  
  , FlowMeterSwitchFlag      BIT    NULL                  
  , FlowMeterCalibration      INT    NULL                  
  , MaximumDosingTime      SMALLINT   NULL                  
  , FlowSwitchTimeOut       decimal(18,1)   NULL                  
  , ControllerEquipmentSetupId    SMALLINT   NULL                  
  , LfsChemicalName       NVARCHAR(200)  NULL                  
  , KFactor        DECIMAL(18, 2)  NULL                  
  , TunnelHold        BIT    NULL                  
  , FlowDetectorType      INT    NULL                  
  , FlowSwitchAlarm       BIT    NULL                  
  , FlowMeterAlarm       BIT    NULL                  
  , FlowMeterType       INT    NULL                  
  , FlowAlarmDelay       DECIMAL(18, 2)    NULL                  
  , FlowMeterPumpDelay      DECIMAL(18, 2)    NULL                  
  , FlowMeterAlarmDelay      DECIMAL(18, 2)    NULL                  
  , LastModifiedTime      DATETIME   NULL                  
  , LastSyncTime       DATETIME   NULL                  
  , ControllerEquipmentTypeModelID    INT    NULL                  
  , ConventionalWasherGroupConnection   BIT    NOT NULL                  
              DEFAULT                  
              0                  
  , AxillaryPumpCalibration     SMALLINT   NULL                  
  , FlowmeterSwitchActivated     BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , FlushWhileDosing      BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , WeightControlledDosage     BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , EquipmentDoseAlone      BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , LowLevelAlarm       BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , LeakageAlarm       BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , FlushTime        SMALLINT   NULL                  
  , PumpingTime       SMALLINT   NULL                  
  , PreFlushTime       SMALLINT   NULL                  
  , NightFlushPauseTime      SMALLINT   NULL                  
  , NightFlushTime       SMALLINT   NULL                  
  , AcceptedDeviation      SMALLINT   NULL                 
  , LineNumber    tinyint NULL DEFAULT 0                
  , DirectDosingFlag      BIT    NULL                  
              DEFAULT                  
              'FALSE'               
  , DirectDosingMachineInternalId    INT    NULL                  
  , DirectDosingTunnelCompartmentId   INT    NULL                  
  , WasherGroupTypeId     INT    NULL                 
  , NumberOfCompartments     INT    NULL                   
  , FlushValveNumber      TINYINT   NULL                
  , CalibrationConductSS_Tank    DECIMAL(18,2)   NULL                
  , BackFlowControl       BIT    NULL                
  , FactorFM_B_FM       SMALLINT         NULL                
  , AcceptedDeviationRingLine    SMALLINT  NULL                
  , UsePumpOfGroup1ForTunnel    BIT    NULL                
  , pHSensorEnabled       BIT    NULL                
  , Concentration    INT    NULL              
  , Deadband              BIT    NULL             
  , WasherGroupNumber    INT     NULL           
  , ValveOutputAsTom  BIT NOT NULL DEFAULT  'FALSE'          
  , FlowSwitchNumber int  NULL           
  , FlushTimeForFlushValve int NULL      
    , MinimumFlowRate INT NULL    
  , ProductDensity DECIMAL(18,2) NULL    
  , MaximumConcentration INT NULL  
  , DosingLineMode INT NULL  
   );                  
    IF NOT EXISTS ( SELECT 1                  
        FROM TCD.ConduitController   CC                  
        WHERE CC.EcoalabAccountNumber = @EcoLabAccountNumber                  
AND CC.ControllerId = @ControllerId                  
    )                  
    BEGIN                  
    SET   @ErrorMessage = 'Invalid Plant/Controller combination specified';                  
    RAISERROR (@ErrorMessage, 16, 1);                  
    SET  @ReturnValue = -1;                  
    RETURN                  
    @ReturnValue;                  
    END;                  
    SET @ControllerTypeId = (SELECT ControllerTypeid            
       FROM TCD.ConduitController CC            
       WHERE CC.ControllerId = @ControllerId);            
    SELECT @ControllerModelId = CC.ControllerModelId                  
  FROM TCD.ConduitController CC                  
  WHERE CC.ControllerId = @ControllerId;                  
    SELECT @ControllerEquipmentTypeId_PumpValve = CASE                  
              WHEN CET.ControllerEquipmentTypeName = 'Pump/Valve'                  
              THEN CET.ControllerEquipmentTypeId                  
              ELSE @ControllerEquipmentTypeId_PumpValve                  
              END                  
     , @ControllerEquipmentTypeId_ME = CASE                  
           WHEN CET.ControllerEquipmentTypeName = 'ME'                  
           THEN CET.ControllerEquipmentTypeId                  
           ELSE @ControllerEquipmentTypeId_ME                  
           END                  
  FROM TCD.ControllerEquipmentType CET                  
  WHERE CET.ControllerEquipmentTypeName   IN   ('Pump/Valve', 'ME');                  
    IF (@ControllerModelId <> 7 AND @ControllerModelId  <> 8 AND @ControllerModelId <> 9 AND @ControllerModelId <> 11      
    AND @ControllerModelId <> 10 AND @ControllerModelId <> 14)                
    BEGIN                  
    SELECT @PumpValveCount = ISNULL(CSD.Value, 0)                  
      FROM TCD.ConduitController CC                  
       JOIN                  
       TCD.ControllerModelControllerTypeMapping CMCTM ON CC.ControllerModelId = CMCTM.ControllerModelId                  
       JOIN                  
       TCD.ControllerSetupData CSD ON CSD.ControllerId = CC.ControllerId                  
          AND CC.ControllerTypeId = CMCTM.ControllerTypeId                  
       JOIN                  
       TCD.FieldGroup FG ON FG.ControllerModelId = CC.ControllerModelId                  
        AND FG.ControllerTypeId = CC.ControllerTypeId                  
        AND FG.TabId = 3                  
       INNER JOIN                  
       TCD.FieldGroupFieldMapping FGM ON FGM.FieldGroupId = FG.Id                  
       INNER JOIN            
       TCD.Field F ON F.Id = FGM.FieldId                  
      AND CSD.FieldId = f.Id                  
      WHERE CC.ControllerId = @ControllerId                  
    AND F.ResourceKey = 'No._of_Chemical_Valves'                  
    AND CSD.EcolabAccountNumber = @EcoLabAccountNumber;                  
    SELECT @MECount = ISNULL(CMCTM.MECount, 0)                  
      FROM TCD.ConduitController CC                  
       JOIN                  
       TCD.ControllerModelControllerTypeMapping CMCTM ON CC.ControllerModelId = CMCTM.ControllerModelId                  
             AND CC.ControllerTypeId = CMCTM.ControllerTypeId                  
      WHERE CC.ControllerId = @ControllerId;                  
    END;         
    ELSE IF(@ControllerModelId = 11)                
    BEGIN                
    SELECT @PumpValveCount = 2*CMCTM.PumpValveCount                
     , @MECount = 2*CMCTM.MECount                
      FROM TCD.ControllerModelControllerTypeMapping CMCTM                
      WHERE CMCTM.ControllerModelId = @ControllerModelId;                
    END;                
  ELSE IF(@ControllerModelId = 7 OR @ControllerModelId = 8 OR @ControllerModelId = 9 OR @ControllerModelId = 10  OR @ControllerModelId = 14)                
  BEGIN                
    SELECT @PumpValveCount = CMCTM.PumpValveCount            
 , @MECount = CMCTM.MECount            
  FROM TCD.ControllerModelControllerTypeMapping CMCTM            
  WHERE CMCTM.ControllerModelId = @ControllerModelId            
    AND CMCTM.ControllerTypeId = @ControllerTypeId;                
    END;                
    IF (SELECT ISNULL(@PumpValveCount, 0)                  
    +                  
    ISNULL(@MECount, 0)) = 0                  
    BEGIN                  
    SELECT                  
    T.ControllerEquipmentId  AS   ControllerEquipmentId                  
  , T.ControllerEquipmentTypeId  AS   ControllerEquipmentTypeId                  
  , T.IsActive     AS   IsActive                  
  , T.ProductId     AS   ProductId                  
  , T.ProductName    AS   ProductName                  
  , T.PumpCalibration    AS   PumpCalibration                  
  , T.FlowMeterSwitchFlag   AS   FlowMeterSwitchFlag                  
  , T.MaximumDosingTime   AS   MaximumDosingTime                  
  , T.FlowSwitchTimeOut   AS   FlowSwitchTimeOut                  
  , T.ControllerEquipmentSetupId AS   ControllerEquipmentSetupId                  
  , @EcoLabAccountNumber   AS   EcoLabAccountNumber                  
  , @ControllerId    AS   ControllerId                  
  , CC.TopicName     AS   ControllerName                  
  , CC.ControllerTypeId   AS   ControllerTypeId                  
  , T.LfsChemicalName    AS   LfsChemicalName                  
  , T.KFactor     AS   KFactor                  
  , T.TunnelHold     AS   TunnelHold                  
  , T.FlowDetectorType   AS   FlowDetectorType                  
  , T.FlowSwitchAlarm    AS   FlowSwitchAlarm                  
  , T.FlowMeterAlarm    AS   FlowMeterAlarm                  
  , T.FlowMeterType    AS   FlowMeterType                  
  , T.FlowAlarmDelay    AS   FlowAlarmDelay                  
  , T.FlowMeterPumpDelay   AS   FlowMeterPumpDelay                  
  , T.FlowMeterAlarmDelay   AS   FlowMeterAlarmDelay                  
  , T.ControllerEquipmentTypeModelID                  
  , T.ConventionalWasherGroupConnection                  
  , T.AxillaryPumpCalibration                  
  , T.FlowmeterSwitchActivated                  
  , T.FlushWhileDosing                  
  , T.WeightControlledDosage                  
  , T.EquipmentDoseAlone                  
  , T.LowLevelAlarm                  
  , T.LeakageAlarm                  
  , T.FlushTime                  
  , T.PumpingTime                  
  , T.PreFlushTime                  
  , T.NightFlushPauseTime                  
  , T.NightFlushTime                  
  , T.AcceptedDeviation                 
  , T.LineNumber                 
  , T.DirectDosingFlag        
  , T.DirectDosingMachineInternalId                  
  , T.DirectDosingTunnelCompartmentId             
  , T.WasherGroupTypeId                     
  , T.NumberOfCompartments                     
  , T.FlushValveNumber                      
  , T.CalibrationConductSS_Tank                   
  , T.BackFlowControl                       
  , T.FactorFM_B_FM                      
  , T.AcceptedDeviationRingLine                    
  , T.UsePumpOfGroup1ForTunnel      
  , T.pHSensorEnabled               
  , T.Concentration                 
  , T.Deadband             
  , T.WasherGroupNumber             
  , T.ValveOutputAsTom            
  , T.FlowSwitchNumber           
  , T.FlushTimeForFlushValve      
   , T.MinimumFlowRate     
  , T.ProductDensity     
  , T.MaximumConcentration  
  ,T.DosingLineMode  
  , (                  
    SELECT MTS.TagAddress                  
      FROM TCD.ModuleTags MTS                  
      WHERE MTS.TagType = @TagTypeLfs                  
    AND MTS.ModuleID = ControllerEquipmentSetupId                  
    AND MTS.ModuleTypeId = 4                  
    AND MTS.Active = 1) AS LfsChemicalNameTag                  
  , (         
    SELECT MTS.TagAddress                  
      FROM TCD.ModuleTags MTS                  
      WHERE MTS.TagType = @TagTypeKfactor                  
    AND MTS.ModuleID = ControllerEquipmentSetupId                  
    AND MTS.ModuleTypeId = 4                  
    AND MTS.Active = 1) AS KfactorTag                  
  , (                  
    SELECT MTS.TagAddress                  
      FROM TCD.ModuleTags MTS                  
      WHERE MTS.TagType = @TagTypeCalibration                  
    AND MTS.ModuleID = ControllerEquipmentSetupId                  
    AND MTS.ModuleTypeId = 4                  
    AND MTS.Active = 1) AS CalibrationTag                  
  , T.LastModifiedTime  AS  LastModifiedTime                  
  , T.LastSyncTime   AS  LastSyncTime                  
      FROM #Equipment  T                  
    JOIN                  
    TCD.ConduitController CC                  
    ON CC.ControllerId = @ControllerId                  
      WHERE T.IsActive = ISNULL(@IsActive, T.IsActive)                  
    AND T.ControllerEquipmentId = ISNULL(@ControllerEquipmentId, T.ControllerEquipmentId);                  
    RETURN                  
    @ReturnValue;               

    END;             
    ELSE          
    BEGIN          
    IF ((SELECT ISNULL(@PumpValveCount, 0)                  
    +                  
    ISNULL(@MECount, 0)) = (SELECT COUNT(*) FROM TCD.ControllerEquipmentSetup CES     WHERE CES.ControllerId    = @ControllerId))          
      BEGIN          
      SET IDENTITY_INSERT #Equipment ON          
      INSERT INTO #Equipment (ControllerEquipmentId, ControllerEquipmentTypeId)             
      SELECT CES.ControllerEquipmentId, CES.ControllerEquipmentTypeId FROM TCD.ControllerEquipmentSetup CES WHERE CES.ControllerId = @ControllerId           
      SET IDENTITY_INSERT #Equipment OFF          
      END
	  ELSE
	  BEGIN
		 IF ISNULL(@PumpValveCount, 0) <> 0                  
    BEGIN                  
    WITH NumCTE (N)                  
    AS(SELECT '*' AS N                  
  UNION ALL                  
       SELECT '*' AS N)                  
    INSERT INTO #Equipment (ControllerEquipmentTypeId)                  
    SELECT TOP (@PumpValveCount) @ControllerEquipmentTypeId_PumpValve                  
      FROM NumCTE N1, NumCTE N2, NumCTE N3, NumCTE N4, NumCTE N5;                  
    END;                  
    IF ISNULL(@MECount, 0) <> 0                  
    BEGIN                  
    WITH NumCTE (N)                  
    AS (SELECT '*' AS N                  
    UNION ALL                  
    SELECT '*' AS N)                  
    INSERT INTO #Equipment(ControllerEquipmentTypeId)                  
    SELECT TOP (@MECount)@ControllerEquipmentTypeId_ME                  
      FROM NumCTE N1, NumCTE N2, NumCTE N3, NumCTE N4, NumCTE N5;                  
    END;   
	  END          
    END           
    UPDATE U                  
  SET U.IsActive = CES.IsActive                  
    , U.ProductId = CES.ProductId                  
    , U.ProductName = (SELECT ISNULL(NULLIF(PM.EnvisionDisplayName, ' '),PM.Name)                  
         FROM TCD.ProductMaster PM                  
         WHERE PM.ProductId = CES.ProductId)                  
    , U.PumpCalibration = CES.PumpCalibration                  
    , U.FlowMeterSwitchFlag = CES.FlowMeterSwitchFlag                  
    , U.MaximumDosingTime = CES.MaximumDosingTime                  
    , U.FlowSwitchTimeOut = CES.FlowSwitchTimeOut                  
    , U.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId                  
    , U.LfsChemicalName = CES.LfsChemicalName                  
    , U.KFactor = CES.KFactor                  
    , U.TunnelHold = CES.TunnelHold                  
    , U.FlowDetectorType = CES.FlowDetectorType                  
    , U.FlowSwitchAlarm = CES.FlowSwitchAlarm                  
    , U.FlowMeterAlarm = CES.FlowMeterAlarm                  
    , U.FlowMeterType = CES.FlowMeterType                  
    , U.FlowAlarmDelay = CES.FlowAlarmDelay                  
    , U.FlowMeterPumpDelay = CES.FlowMeterPumpDelay                  
    , U.FlowMeterAlarmDelay = CES.FlowMeterAlarmDelay                  
    , U.ControllerEquipmentTypeModelID = CES.ControllerEquipmentTypeModelID                  
    , U.ConventionalWasherGroupConnection = CES.ConventionalWasherGroupConnection                  
    , U.AxillaryPumpCalibration = CES.AxillaryPumpCalibration                  
    , U.FlowmeterSwitchActivated = CES.FlowmeterSwitchActivated                  
    , U.FlushWhileDosing = CES.FlushWhileDosing                  
    , U.WeightControlledDosage = CES.WeightControlledDosage                  
    , U.EquipmentDoseAlone = CES.EquipmentDoseAlone                  
    , U.LowLevelAlarm = CES.LowLevelAlarm                  
    , U.LeakageAlarm = CES.LeakageAlarm                  
    , U.FlushTime = CES.FlushTime                  
    , U.PumpingTime = CES.PumpingTime                  
    , U.PreFlushTime = CES.PreFlushTime                  
    , U.NightFlushPauseTime = CES.NightFlushPauseTime                  
    , U.NightFlushTime = CES.NightFlushTime                  
    , U.AcceptedDeviation = CES.AcceptedDeviation                 
    , U.LineNumber = CES.LineNumber                 
    , U.DirectDosingFlag = TCEVM.DirectDosingFlag                  
    , U.DirectDosingMachineInternalId = TCEVM.TunnelNumber                  
    , U.DirectDosingTunnelCompartmentId = TCEVM.CompartmentNumber                
    , U.LastModifiedTime = CES.LastModifiedTime                  
    , U.LastSyncTime = CES.LastSyncTime                
    , U.FlushValveNumber      = CES.FlushValveNumber                
  , U.CalibrationConductSS_Tank    = CES.CalibrationConductSS_Tank              
  , U.BackFlowControl     = CES.BackFlowControl                  
  , U.FactorFM_B_FM       = CES.FactorFM_B_FM               
  , U.AcceptedDeviationRingLine  = CES.AcceptedDeviationRingLine                  
  , U.UsePumpOfGroup1ForTunnel   = CES.UsePumpOfGroup1ForTunnel              
  , U.pHSensorEnabled            = CES.pHSensorEnabled              
  , U.Concentration = CES.Concentration              
  , U.Deadband = CES.Deadband             
  , U.WasherGroupNumber = CES.WasherGroupNumber          
  , U.ValveOutputAsTom = CES.ValveOutputAsTom          
  , U.FlowSwitchNumber = CES.FlowSwitchNumber         
  , U.FlushTimeForFlushValve = CES.FlushTimeForFlushValve      
    , U.MinimumFlowRate = CES.MinimumFlowRate    
  , U.ProductDensity = CES.ProductDensity    
  , U.MaximumConcentration  = CES.MaximumConcentration    
  ,U.DosingLineMode =1 
  FROM #Equipment U                  
   JOIN                  
   TCD.ControllerEquipmentSetup CES                  
  ON U.ControllerEquipmentId = CES.ControllerEquipmentId                  
  AND U.ControllerEquipmentTypeId = CES.ControllerEquipmentTypeId               
  JOIN TCD.ConduitController CC ON CES.ControllerID = CC.ControllerId                
  LEFT JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId                
  LEFT JOIN TCD.WasherGroup WG ON CES.ControllerID = WG.ControllerID                 
  LEFT JOIN TCD.MachineSetup MS ON WG.ControllerId = MS.ControllerId          
  WHERE CES.EcoLabAccountNumber = @EcoLabAccountNumber                  
   AND CES.ControllerId = @ControllerId; 
      IF(@ControllerModelId = 7)  
   BEGIN  
   Declare @DosingLineMode varchar(100) ,@NoOfPumpsConnected  varchar(100), @Counter int  

   select @DosingLineMode =CES.Value  
       FROM TCD.ControllerSetupdata CES  
       INNER JOIN [TCD].[Field] F ON F.Id = CES.FieldId  
       AND EcoLabAccountNumber=@EcoLabAccountNumber  
       AND ControllerId=@ControllerId  
       AND ResourceKey ='Dosing_Line_Mode1'  

--CREATE	TABLE		#Equipment	(
--					ControllerEquipmentId					INT				IDENTITY(1, 1)
--				,	ControllerEquipmentTypeId				TINYINT			NOT	NULL

--				,	IsActive								BIT				NOT	NULL		DEFAULT('FALSE')
--				,	ProductId								INT				NULL
--				,	ProductName								NVARCHAR(255)	NULL			--ProductMaster
--				,	PumpCalibration							DECIMAL(18, 3)	NULL
--				,	FlowMeterSwitchFlag						BIT				NULL			--NULL (not set), 0 for Meter, 1 for Switch
--				,	FlowMeterCalibration					INT				NULL
--				,	MaximumDosingTime						SMALLINT		NULL
--				,	FlowSwitchTimeOut						SMALLINT		NULL

--				,	ControllerEquipmentSetupId				SMALLINT		NULL

--				, LfsChemicalName							NVARCHAR(200)	NULL
--				, KFactor									DECIMAL(18,2)	NULL
--				, TunnelHold								BIT				NULL
--				, FlowDetectorType							INT				NULL
--				, FlowSwitchAlarm							BIT				NULL
--				,	FlowMeterAlarm							BIT				NULL
--				,	FlowMeterType							INT				NULL
--				,	FlowAlarmDelay							DECIMAL(18, 2)	NULL				
--				, FlowMeterPumpDelay						DECIMAL(18, 2)				NULL
--				,	FlowMeterAlarmDelay						DECIMAL(18, 2)				NULL
--				--Synch./Central integration additions
--				,	LastModifiedTime						DATETIME		NULL
--				,	LastSyncTime							DATETIME		NULL
--				)

--select @DosingLineMode  

IF RTRIM( LTRIM(@DosingLineMode)) ='2'  
		BEGIN
 set @Counter = 1;  
       select @NoOfPumpsConnected = CES.Value   
       FROM TCD.ControllerSetupdata CES  
              INNER JOIN [TCD].[Field] F ON F.Id = CES.FieldId  
              AND EcoLabAccountNumber=@EcoLabAccountNumber  
              AND ControllerId=@ControllerId  
              AND ResourceKey ='No_of_Pumps_Connected_to_TCR1'  
       select @NoOfPumpsConnected = cast(@NoOfPumpsConnected as int)  
       update A set A.LineNumber =1,  
       A.DosingLineMode = 2  
       from #Equipment A where   ControllerEquipmentId >= 1 and ControllerEquipmentId <= @NoOfPumpsConnected  
		END


select @DosingLineMode =CES.Value  
       FROM TCD.ControllerSetupdata CES  
       INNER JOIN [TCD].[Field] F ON F.Id = CES.FieldId  
       AND EcoLabAccountNumber=@EcoLabAccountNumber  
       AND ControllerId=@ControllerId  
       AND ResourceKey ='Dosing_Line_Mode2'  

--select @DosingLineMode  

IF RTRIM( LTRIM(@DosingLineMode)) ='2'  
	BEGIN

 set @Counter = 9;  
       select @NoOfPumpsConnected = CES.Value   
       FROM TCD.ControllerSetupdata CES  
              INNER JOIN [TCD].[Field] F ON F.Id = CES.FieldId  
              AND EcoLabAccountNumber=@EcoLabAccountNumber  
              AND ControllerId=@ControllerId  
              AND ResourceKey ='No_of_Pumps_Connected_to_TCR2'  
       SET @NoOfPumpsConnected = cast(@NoOfPumpsConnected as int)  
       SET @NoOfPumpsConnected = @NoOfPumpsConnected + @Counter ;  
       update A set A.LineNumber =2,  
       A.DosingLineMode = 2  
       from #Equipment A where   ControllerEquipmentId BETWEEN  @Counter and  @NoOfPumpsConnected  
	END


select @DosingLineMode =CES.Value  
       FROM TCD.ControllerSetupdata CES  
       INNER JOIN [TCD].[Field] F ON F.Id = CES.FieldId  
       AND EcoLabAccountNumber=@EcoLabAccountNumber  
       AND ControllerId=@ControllerId  
       AND ResourceKey ='Dosing_Line_Mode3'  

--select @DosingLineMode  

IF RTRIM( LTRIM(@DosingLineMode)) ='2'  
BEGIN
 set @Counter = 17;  
       select @NoOfPumpsConnected = CES.Value   
       FROM TCD.ControllerSetupdata CES  
              INNER JOIN [TCD].[Field] F ON F.Id = CES.FieldId  
              AND EcoLabAccountNumber=@EcoLabAccountNumber  
              AND ControllerId=@ControllerId  
              AND ResourceKey ='No_of_Pumps_Connected_to_TCR3'  
       SET @NoOfPumpsConnected = cast(@NoOfPumpsConnected as int)  
       SET @NoOfPumpsConnected = @NoOfPumpsConnected + @Counter ;  
       update A set A.LineNumber =3,  
       A.DosingLineMode = 2  
       from #Equipment A where   ControllerEquipmentId BETWEEN  @Counter and  @NoOfPumpsConnected  
END


   END 

   IF(@ControllerModelId = 11)                
   BEGIN            
   UPDATE U             
   SET U.WasherGroupTypeId = (SELECT MIN(WG.WasherGroupTypeId) FROM TCD.WasherGroup WG WHERE WG.ControllerId = @ControllerId)            
    FROM #Equipment U                  
JOIN                  
   TCD.ControllerEquipmentSetup CES                  
  ON U.ControllerEquipmentId = CES.ControllerEquipmentId                  
  AND U.ControllerEquipmentTypeId = CES.ControllerEquipmentTypeId                
  WHERE CES.EcoLabAccountNumber = @EcoLabAccountNumber                  
   AND CES.ControllerId = @ControllerId            
   AND CES.ControllerEquipmentId IN (select top 14 CES.ControllerEquipmentId FROM  TCD.ControllerEquipmentSetup CES            
   where CES.ControllerId = @ControllerId )            

     UPDATE U             
   SET U.WasherGroupTypeId = (SELECT MAX(WG.WasherGroupTypeId) FROM TCD.WasherGroup WG WHERE WG.ControllerId = @ControllerId)            
    FROM #Equipment U                  
   JOIN                  
   TCD.ControllerEquipmentSetup CES                  
  ON U.ControllerEquipmentId = CES.ControllerEquipmentId                  
  AND U.ControllerEquipmentTypeId = CES.ControllerEquipmentTypeId               
  JOIN TCD.ConduitController CC ON CES.ControllerID = CC.ControllerId         
  WHERE CES.EcoLabAccountNumber = @EcoLabAccountNumber                  
   AND CES.ControllerId = @ControllerId            
   AND CES.ControllerEquipmentId IN (select  CES.ControllerEquipmentId FROM TCD.ControllerEquipmentSetup CES            
    where CES.ControllerId = @ControllerId AND             
    CES.ControllerEquipmentId BETWEEN 15 AND 28 )        

   UPDATE U SET U.NumberOfCompartments = ms.NumberOfComp        
   FROM #Equipment U        
   INNER JOIN TCD.ControllerEquipmentSetup ces        
   ON u.ControllerEquipmentId = ces.ControllerEquipmentId         
   INNER JOIN TCD.WasherGroup wg ON ces.ControllerId = WG.ControllerId        
   INNER JOIN TCD.MachineSetup ms ON ms.ControllerId = ces.ControllerId AND ms.GroupId = WG.WasherGroupId        
   WHERE ces.ControllerId = @ControllerId AND U.WasherGroupTypeId = 2  AND ms.IsTunnel = 1 AND WG.WasherDosingNumber = U.WasherGroupNumber        
   END          

  -- END                
    GOTO ExitModule;                  
ExitModule:
    SELECT                  
    T.ControllerEquipmentId   AS ControllerEquipmentId                  
  , T.ControllerEquipmentTypeId AS ControllerEquipmentTypeId                  
  , T.IsActive      AS IsActive                  
  , T.ProductId     AS ProductId                  
  , T.ProductName     AS ProductName                  
  , T.PumpCalibration    AS PumpCalibration                  
  , T.FlowMeterSwitchFlag   AS FlowMeterSwitchFlag                  
  , T.MaximumDosingTime    AS MaximumDosingTime                  
  , T.FlowSwitchTimeOut    AS FlowSwitchTimeOut                  
  , T.ControllerEquipmentSetupId  AS ControllerEquipmentSetupId                  
  , @EcoLabAccountNumber    AS EcoLabAccountNumber                  
  , @ControllerId     AS ControllerId                  
  , CC.TopicName     AS ControllerName                  
  , CC.ControllerTypeId    AS ControllerTypeId                  
  , T.LfsChemicalName    AS LfsChemicalName                  
  , T.KFactor      AS KFactor                  
  , T.TunnelHold     AS TunnelHold                  
  , T.FlowDetectorType    AS FlowDetectorType                  
, T.FlowSwitchAlarm    AS FlowSwitchAlarm                  
  , T.FlowMeterAlarm    AS FlowMeterAlarm                  
  , T.FlowMeterType     AS FlowMeterType                  
 , T.FlowAlarmDelay    AS FlowAlarmDelay                  
  , T.FlowMeterPumpDelay    AS FlowMeterPumpDelay                  
  , T.FlowMeterAlarmDelay   AS FlowMeterAlarmDelay                  
  , (                  
    SELECT MTS.TagAddress                  
  FROM TCD.ModuleTags MTS                  
  WHERE MTS.TagType = @TagTypeLfs                  
    AND MTS.ModuleID = ControllerEquipmentSetupId                  
    AND MTS.ModuleTypeId = 4                  
    AND MTS.Active = 1) AS LfsChemicalNameTag                  
  , (                  
    SELECT MTS.TagAddress                  
  FROM TCD.ModuleTags MTS                  
  WHERE MTS.TagType = @TagTypeKfactor                  
    AND MTS.ModuleID = ControllerEquipmentSetupId                  
    AND MTS.ModuleTypeId = 4                  
    AND MTS.Active = 1) AS KfactorTag                  
  , (                  
    SELECT MTS.TagAddress                  
  FROM TCD.ModuleTags MTS                  
  WHERE MTS.TagType = @TagTypeCalibration                  
    AND MTS.ModuleID = ControllerEquipmentSetupId                  
    AND MTS.ModuleTypeId = 4                  
    AND MTS.Active = 1) AS CalibrationTag                  
  , T.ControllerEquipmentTypeModelID                  
  , T.ConventionalWasherGroupConnection                  
  , T.AxillaryPumpCalibration                  
  , T.FlowmeterSwitchActivated                  
  , T.FlushWhileDosing                  
  , T.WeightControlledDosage                  
  , T.EquipmentDoseAlone                  
  , T.LowLevelAlarm                  
  , T.LeakageAlarm                  
  , T.FlushTime                  
  , T.PumpingTime                  
  , T.PreFlushTime                  
  , T.NightFlushPauseTime                  
  , T.NightFlushTime                  
  , T.AcceptedDeviation                  
  , T.LineNumber                
  , T.DirectDosingFlag                  
  , T.DirectDosingMachineInternalId                  
  , T.DirectDosingTunnelCompartmentId                  
  , T.LastModifiedTime    AS LastModifiedTime                  
  , T.LastSyncTime     AS LastSyncTime             
  , T.WasherGroupTypeId                     
  , T.NumberOfCompartments                     
  , T.FlushValveNumber                      
  , T.CalibrationConductSS_Tank                   
  , T.BackFlowControl                       
  , T.FactorFM_B_FM                      
  , T.AcceptedDeviationRingLine                    
  , T.UsePumpOfGroup1ForTunnel                    
  , T.pHSensorEnabled                
  , T.Concentration              
  , T.Deadband              
  , T.WasherGroupNumber          
  , T.ValveOutputAsTom          
  , T.FlowSwitchNumber          
  , T.FlushTimeForFlushValve      
    , T.MinimumFlowRate     
  , T.ProductDensity     
  , T.MaximumConcentration   
  , T.DosingLineMode 
  FROM #Equipment T                  
   JOIN                  
   TCD.ConduitController CC ON CC.ControllerId = @ControllerId                  
  WHERE T.IsActive = ISNULL(@IsActive, T.IsActive)                  
   AND T.ControllerEquipmentId = ISNULL(@ControllerEquipmentId, T.ControllerEquipmentId)        
   ORDER BY  T.ControllerEquipmentId;                  
    SET NOCOUNT OFF;                  
    RETURN                  
    @ReturnValue;                  
END;   
GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[SaveControllerEquipment]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.SaveControllerEquipment
	END
GO 

CREATE PROCEDURE [TCD].[SaveControllerEquipment]          
      @EcoLabAccountNumber    NVARCHAR(1000)          
    , @ControllerId     INT          
    , @ControllerEquipmentId    SMALLINT          
    , @ControllerEquipmentTypeId   TINYINT          
    , @ProductId      INT          
    , @PumpCalibration     DECIMAL(18, 3)          
    , @LfsChemicalName     NVARCHAR(200)          
    , @KFactor      DECIMAL(18,2)  = NULL          
    , @TunnelHold      BIT    = NULL          
    , @FlowDetectorType     INT    = NULL      
    , @FlowSwitchNumber        INT        = NULL      
    , @FlowSwitchAlarm     BIT    = NULL          
    , @FlowMeterAlarm     BIT    = NULL          
    , @FlowMeterType     INT    = NULL          
    , @FlowAlarmDelay     DECIMAL(18,2)    = NULL          
    , @FlowMeterPumpDelay    DECIMAL(18,2)    = NULL          
    , @FlowMeterAlarmDelay    DECIMAL(18,2)    = NULL          
    , @LfsChemicalNameTag    NVARCHAR(200)  = NULL          
    , @KfactorTag      NVARCHAR(200)  = NULL          
    , @CalibrationTag     NVARCHAR(200)  = NULL          
    , @ControllerEquipmentTypeModelId  INT = NULL          
    , @ConventionalWasherGroupConnection BIT           
    , @AxillaryPumpCalibration   SMALLINT          
    , @FlowmeterSwitchActivated   BIT          
    , @FlushWhileDosing      BIT          
    , @WeightControlledDosage    BIT          
    , @EquipmentDoseAlone       BIT          
    , @LowLevelAlarm          BIT          
    , @LeakageAlarm          BIT          
    , @FlushTime         SMALLINT          
    , @PumpingTime         SMALLINT          
    , @PreFlushTime        SMALLINT          
    , @NightFlushPauseTime       SMALLINT          
    , @NightFlushTime        SMALLINT          
    , @AcceptedDeviation       SMALLINT          
    , @LineNumber      TINYINT          
    , @MaximumDosingTime    SMALLINT          
    , @FlowSwitchTimeOut    decimal(18,1)          
    , @UserId       INT                 
    , @FlushValveNumber   TINYINT    = NULL      
    , @CalibrationConductSS_Tank DECIMAL(18,2)  = NULL      
    , @BackFlowControl    BIT        
    , @FactorFM_B_FM      SMALLINT = NULL      
    , @AcceptedDeviationRingLine SMALLINT   = NULL       
    , @UsePumpOfGroup1ForTunnel BIT   = NULL         
    , @pHSensorEnabled    BIT   = NULL    
 , @FlushTimeForFlushValve    INT   = NULL      
    , @Concentration      INT     = NULL      
    , @Deadband     BIT   = NULL     
 , @ValveOutputAsTom BIT = NULL   
    ,@MinimumFlowRate INT = NULL
    ,@ProductDensity DECIMAL(18,2) = NULL
    , @MaximumConcentration INT = NULL
				--Adding these 3 param as part of re-factoring for integration with Synch/Configurator
    , @OutputControllerEquipmentSetupId INT   =   NULL OUTPUT          
    , @LastModifiedTimestampAtCentral  DATETIME =   NULL   --Nullable for local call; Synch/Central call will have to pass this -          
																								--else, it will be treated as a local call
    , @OutputLastModifiedTimestampAtLocal DATETIME =   NULL OUTPUT          

AS
BEGIN

SET NOCOUNT ON          

DECLARE @Equipments TABLE (        
ProductId INT,        
EcoLabAccountNumber NVARCHAR(25),        
ControllerId INT        
)        
DECLARE @ReturnValue     INT      =   0          
 , @IsActive      BIT          
 , @ErrorId      INT      =   0          
 --, @ErrorMessage     NVARCHAR(4000)   =   N''          
 --, @ErrorNumber     INT     =   0          
 , @ErrorMessage     NVARCHAR(4000)   =   N''          
 , @ErrorSeverity     INT     =   NULL          
 , @ErrorProcedure     SYSNAME    =   NULL          
 , @MessageString     NVARCHAR(2500)  =   NULL          

 , @MaximumChemicalCount   TINYINT     =   NULL          
 , @DistinctChemicalCount   TINYINT     =   NULL          
 , @ControllerTypeId    INT          
 , @CurrentUTCTime     DATETIME    =   GETUTCDATE()          

--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
SET  @OutputLastModifiedTimestampAtLocal      =   @CurrentUTCTime          
SET  @OutputControllerEquipmentSetupId      =   ISNULL(@OutputControllerEquipmentSetupId, NULL)   --SQLEnlight SA0121          



SELECT @MaximumChemicalCount     =   CMCTM.MaximumChemicalCount          
  ,@ControllerTypeId      =   CC.ControllerTypeId          
FROM [TCD].ConduitController CC          
JOIN [TCD].ControllerModelControllerTypeMapping CMCTM          
 ON CC.ControllerModelId     =   CMCTM.ControllerModelId          
 AND CC.ControllerTypeId      =   CMCTM.ControllerTypeId          
WHERE CC.ControllerId       =   @ControllerId          

set @MaximumChemicalCount = 30 -- Added dummy value by srikanth, at times we are getting this value as 1, so that user is not able to add pumps more than 1. //Lemuel handled how many pumps should display based on the configuration so this check is useles 

    
     
       
         
          
SET  @IsActive        =   CASE WHEN @ProductId IS NULL THEN 'FALSE'          
                 ELSE 'TRUE'          
															END

 DECLARE @ModuleType INT = 4 --select MTy.ModuleTypeId from TCD.ModuleType MTy WHERE ModuleDescription like '%Pump%Valve%'          
					,@DefaultFrequency INT = 60
					,@TagTypeLfs VARCHAR(100) = 'Tag_NML'
					,@TagTypeKfactor VARCHAR(100) = 'Tag_PPOL'
					,@TagTypeCalibration VARCHAR(100) = 'Tag_OPSL'
					,@Result1 INT = NULL
					,@Result2 INT = NULL
					,@Result3 INT = NULL
     ,@Type INT = 4 --@ModuleType          
					,@RoleId INT = (SELECT UR.LevelId FROM TCD.UserMaster UM
														INNER JOIN TCD.UserInRole UIR ON UM.UserId = UIR.UserId
														INNER JOIN TCD.UserRoles UR ON UIR.RoleId = UR.RoleId
														WHERE UM.UserId = @UserId)

DECLARE
  @OutputList      AS TABLE  (          
  ControllerEquipmentSetupId   INT          
 , LastModifiedTimestamp    DATETIME          
	)

IF EXISTS ( SELECT 1          
    FROM [TCD].ControllerEquipmentSetup  CES          
    WHERE CES.ControllerId     =   @ControllerId          
     AND CES.ControllerEquipmentId   =   @ControllerEquipmentId          
     AND CES.EcoLabAccountNumber    =   @EcoLabAccountNumber          
			)
		BEGIN
				--If the call is not local, check that the LastModifiedTime matches with the central
    IF (          
      @LastModifiedTimestampAtCentral   IS NOT NULL          
     AND NOT EXISTS ( SELECT 1          
          FROM TCD.[ControllerEquipmentSetup]          
																		CES
          WHERE CES.EcolabAccountNumber = @EcolabAccountNumber        
           AND CES.ControllerId  = @ControllerId          
           AND CES.ControllerEquipmentId          
                  = @ControllerEquipmentId          
           AND CES.LastModifiedTime = @LastModifiedTimestampAtCentral          
									)
					)
					BEGIN
       SET   @ErrorId      = 60000          
       SET   @ErrorMessage     = N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'          
       RAISERROR (@ErrorMessage, 16, 1)          
       SET   @ReturnValue     = -1          
       RETURN  (@ReturnValue)          
					END
				
				--Proceed, since it's either a local call or Synch. call with synch. time matching
    SELECT @DistinctChemicalCount    =   COUNT(DISTINCT D.ProductId) --distinct count          
    FROM (          
      SELECT @ProductId     AS   ProductId     --being assigned          
						UNION
      SELECT DISTINCT ProductId  AS   ProductId     --already assigned          
      FROM [TCD].ControllerEquipmentSetup          
      WHERE ControllerId    =   @ControllerId          
       AND ControllerEquipmentId  <>   @ControllerEquipmentId          
       AND ProductId     <>   @ProductId          
      ) D          

    IF ( @DistinctChemicalCount > @MaximumChemicalCount )          
				BEGIN
      SET @ErrorId   = 51000          
      SET @ErrorMessage  = N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Maximum chemical count exceeded. Cannot assign new chemical'          
      --GOTO ErrorHandler          
      RAISERROR (@ErrorMessage, 16, 1)          
      SET @ReturnValue = -1          
      RETURN (@ReturnValue)          
				END
				
				--DECLARE @PumpId INT = (SELECT ControllerEquipmentSetupId
    --            FROM [TCD].ControllerEquipmentSetup          
    --            WHERE ControllerId  = @ControllerId           
    --            AND ControllerEquipmentId = @ControllerEquipmentId           
    --            AND EcoLabAccountNumber  = @EcoLabAccountNumber)          

				--IF(@RoleId =8)
    -- BEGIN          
    --   IF(@LfsChemicalNameTag IS NOT NULL AND @LfsChemicalNameTag <> '')          
    --    BEGIN          
    --     EXEC @Result1 = TCD.CheckDuplicateTag @LfsChemicalNameTag, @ControllerID, @PumpId, @Type          
    --     IF(@Result1 = 0)          
    --     BEGIN          
    --     SET @ErrorMessage = '801,'          
    --    END          
    --   END          
    --   IF(@KfactorTag IS NOT NULL AND @KfactorTag <> '')          
    --    BEGIN          
    --     EXEC @Result2 = TCD.CheckDuplicateTag @KfactorTag,@ControllerID, @PumpId, @Type          
    --     IF(@Result2 = 0)          
    --     BEGIN          
    --     SET @ErrorMessage = @ErrorMessage+'802,'          
    --     END          
    --    END          
    --   IF(@CalibrationTag IS NOT NULL AND @CalibrationTag <> '')          
    --   BEGIN          
    --    EXEC @Result3 = TCD.CheckDuplicateTag @CalibrationTag,@ControllerID, @PumpId, @Type          
    --    IF(@Result3 = 0)          
    --    BEGIN          
    --    SET @ErrorMessage = @ErrorMessage+'803,'          
    --    END          
    --   END          
    -- END          

				--SET @ErrorMessage = @ErrorMessage + CONVERT(VARCHAR(100),'')

				--IF(@ErrorMessage <> '')
    -- RAISERROR(@ErrorMessage, 16, 1)          
				--ELSE
					BEGIN
      BEGIN TRY          
        BEGIN TRAN          

        UPDATE [TCD].ControllerEquipmentSetup          
         SET ProductId      =   @ProductId          
         , IsActive      =   @IsActive          
         , LfsChemicalName    =   CASE @IsActive WHEN 'TRUE' THEN @LfsChemicalName   ELSE NULL END          
         , KFactor      =   CASE @IsActive WHEN 'TRUE' THEN @KFactor     ELSE NULL END          
         , PumpCalibration    =   CASE @IsActive WHEN 'TRUE' THEN @PumpCalibration   ELSE NULL END          
				
         , TunnelHold     =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @TunnelHold   ELSE NULL END ELSE NULL END          
         , FlowDetectorType    =   CASE @IsActive WHEN 'TRUE' THEN CASE WHEN @ControllerTypeId IN(2,6,7, 12,10, 14,8, 13,9,11) THEN @FlowDetectorType  ELSE NULL END ELSE NULL END   
         , FlowSwitchNumber    =    @FlowSwitchNumber  
         , FlowSwitchAlarm    =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowSwitchAlarm  ELSE NULL END ELSE NULL END          
         , FlowMeterAlarm     =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterAlarm  ELSE NULL END ELSE NULL END          
         , FlowMeterType     =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterType   ELSE NULL END ELSE NULL END          
         , FlowAlarmDelay     =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowAlarmDelay ELSE NULL END ELSE NULL END          
         , FlowMeterPumpDelay    =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterPumpDelay  ELSE NULL END ELSE NULL END          
         , FlowMeterAlarmDelay    =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterAlarmDelay ELSE NULL END ELSE NULL END          
         , ControllerEquipmentTypeModelId =   CASE @IsActive WHEN 'TRUE' THEN @ControllerEquipmentTypeModelId      ELSE NULL END          
             , ConventionalWasherGroupConnection =   CASE @IsActive WHEN 'TRUE' THEN @ConventionalWasherGroupConnection  ELSE 0 END          
             , AxillaryPumpCalibration   =   CASE @IsActive WHEN 'TRUE' THEN @AxillaryPumpCalibration    ELSE 0 END          
             , FlowmeterSwitchActivated   =   CASE @IsActive WHEN 'TRUE' THEN @FlowmeterSwitchActivated   ELSE 0 END          
             , FlushWhileDosing     =   CASE @IsActive WHEN 'TRUE' THEN @FlushWhileDosing      ELSE 0 END          
             , WeightControlledDosage    =   CASE @IsActive WHEN 'TRUE' THEN @WeightControlledDosage     ELSE 0 END          
             , EquipmentDoseAlone       =   CASE @IsActive WHEN 'TRUE' THEN @EquipmentDoseAlone        ELSE 0 END          
             , LowLevelAlarm          =   CASE @IsActive WHEN 'TRUE' THEN @LowLevelAlarm           ELSE 0 END          
             , LeakageAlarm          =   CASE @IsActive WHEN 'TRUE' THEN @LeakageAlarm           ELSE 0 END          
             , FlushTime         =   CASE @IsActive WHEN 'TRUE' THEN @FlushTime         ELSE NULL END          
             , PumpingTime        =   CASE @IsActive WHEN 'TRUE' THEN @PumpingTime         ELSE NULL END          
             , PreFlushTime        =   CASE @IsActive WHEN 'TRUE' THEN @PreFlushTime         ELSE NULL END          
             , NightFlushPauseTime       =   CASE @IsActive WHEN 'TRUE' THEN @NightFlushPauseTime       ELSE NULL END          
             , NightFlushTime        =   CASE @IsActive WHEN 'TRUE' THEN @NightFlushTime        ELSE NULL END          
             , AcceptedDeviation       =   CASE @IsActive WHEN 'TRUE' THEN @AcceptedDeviation        ELSE NULL END          
             , LineNumber        =   CASE @IsActive WHEN 'TRUE' THEN @LineNumber           ELSE 0 END          
             , MaximumDosingTime    =   CASE @IsActive WHEN 'TRUE' THEN @MaximumDosingTime     ELSE NULL END          
         , FlowSwitchTimeOut    =   CASE @IsActive WHEN 'TRUE' THEN @FlowSwitchTimeOut     ELSE NULL END       
        , ValveOutputAsTom               =   CASE @IsActive WHEN 'TRUE' THEN @ValveOutputAsTom           ELSE 0 END        

         , LastModifiedByUserId   =   @UserId          
        --** Adding a part of integration with Synch./Central -->          
         , LastModifiedTime    =   @CurrentUTCTime                  
       , FlushValveNumber  =   CASE @IsActive WHEN 'TRUE' THEN @FlushValveNumber     ELSE NULL END           
 , CalibrationConductSS_Tank =   CASE @IsActive WHEN 'TRUE' THEN @CalibrationConductSS_Tank     ELSE NULL END         
       , BackFlowControl  =   CASE @IsActive WHEN 'TRUE' THEN @BackFlowControl     ELSE 'False' END            
       , FactorFM_B_FM   =   CASE @IsActive WHEN 'TRUE' THEN @FactorFM_B_FM     ELSE NULL END                
       , AcceptedDeviationRingLine =   CASE @IsActive WHEN 'TRUE' THEN @AcceptedDeviationRingLine     ELSE NULL END           
       , UsePumpOfGroup1ForTunnel =   CASE @IsActive WHEN 'TRUE' THEN @UsePumpOfGroup1ForTunnel     ELSE NULL END             
       , pHSensorEnabled    =   CASE @IsActive WHEN 'TRUE' THEN @pHSensorEnabled     ELSE NULL END        
    , FlushTimeForFlushValve = @FlushTimeForFlushValve   
       , Concentration =   CASE @IsActive WHEN 'TRUE' THEN @Concentration     ELSE NULL END             
       , Deadband    =   CASE @IsActive WHEN 'TRUE' THEN @Deadband     ELSE NULL END          
       , MinimumFlowRate = CASE @IsActive WHEN 'TRUE' THEN @MinimumFlowRate     ELSE NULL END  
       , ProductDensity = CASE @IsActive WHEN 'TRUE' THEN @ProductDensity     ELSE NULL END
       , MaximumConcentration = CASE @IsActive WHEN 'TRUE' THEN @MaximumConcentration     ELSE NULL END
        OUTPUT inserted.ControllerEquipmentSetupId   AS   ControllerEquipmentSetupId          
         , inserted.LastModifiedTime     AS   LastModifiedTime          
        INTO @OutputList (          
										ControllerEquipmentSetupId
         , LastModifiedTimestamp          
									)
        --** <--          
        WHERE ControllerId    =   @ControllerId          
        AND ControllerEquipmentId   =   @ControllerEquipmentId          
        AND EcoLabAccountNumber    =   @EcoLabAccountNumber           

        SET @ErrorId = @@ERROR          

        IF (@ErrorId <> 0)          
									BEGIN
          IF @@TRANCOUNT > 0          
											ROLLBACK

          SET  @ErrorMessage  = N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating Equipment data'          
          --GOTO Errorhandler          
          RAISERROR (@ErrorMessage, 16, 1)          
          SET @ReturnValue = -1          
          RETURN (@ReturnValue)          
									END

								---Tags---
								--IF(@RoleId =8)
								--BEGIN
        --  IF(@IsActive = 'TRUE')          
        --    BEGIN          
        --      --1st if-else...          
        --      IF NOT EXISTS(SELECT 1 FROM TCD.ModuleTags WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND Active = 1 AND TagType = @TagTypeLfs)          
        --        BEGIN          
        --          IF(@LfsChemicalNameTag IS NOT NULL AND @LfsChemicalNameTag <> '')           
        --           INSERT INTO [TCD].ModuleTags (EcolabAccountNumber ,TagType,TagAddress,ModuleTypeId,ModuleID,DeadBand,Active) VALUES(@EcoLabAccountNumber ,@TagTypeLfs,@LfsChemicalNameTag,@ModuleType,@PumpId,@DefaultFrequency,1)          
        --        END          
        --      ELSE          
        --      IF(@LfsChemicalNameTag IS NOT NULL AND @LfsChemicalNameTag <> '')          
        --        UPDATE [TCD].ModuleTags SET TagAddress = @LfsChemicalNameTag WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND TagType = @TagTypeLfs AND Active = 1          
        --      ELSE          
        --        UPDATE [TCD].ModuleTags SET Active = 0 WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND TagType = @TagTypeLfs AND Active = 1          

        --      --2nd if-else...          
        --      IF NOT EXISTS(SELECT 1 FROM TCD.ModuleTags WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND Active = 1 AND TagType = @TagTypeKfactor)          
        --        BEGIN          
        --          IF(@KfactorTag IS NOT NULL AND @KfactorTag <> '')          
        --           INSERT INTO [TCD].ModuleTags (EcolabAccountNumber ,TagType,TagAddress,ModuleTypeId,ModuleID,DeadBand,Active) VALUES(@EcoLabAccountNumber ,@TagTypeKfactor,@KfactorTag,@ModuleType,@PumpId,@DefaultFrequency,1)          
        --        END          
        --      ELSE           
        --      IF(@KfactorTag IS NOT NULL AND @KfactorTag <> '')          
        --        UPDATE [TCD].ModuleTags SET TagAddress = @KfactorTag WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND TagType = @TagTypeKfactor AND Active = 1          
        --      ELSE          
        --        UPDATE [TCD].ModuleTags SET Active = 0 WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND TagType = @TagTypeKfactor AND Active = 1          

        --      --3rd if-else...          
        --      IF NOT EXISTS(SELECT 1 FROM TCD.ModuleTags WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND Active = 1 AND TagType = @TagTypeCalibration)          
        --        BEGIN          
        --          IF(@CalibrationTag IS NOT NULL AND @CalibrationTag <> '')          
        --           INSERT INTO [TCD].ModuleTags (EcolabAccountNumber ,TagType,TagAddress,ModuleTypeId,ModuleID,DeadBand,Active) VALUES(@EcoLabAccountNumber ,@TagTypeCalibration,@CalibrationTag,@ModuleType,@PumpId,@DefaultFrequency,1)          
        --        END          
        --      ELSE           
        --      IF(@CalibrationTag IS NOT NULL AND @CalibrationTag <> '')          
        --        UPDATE [TCD].ModuleTags SET TagAddress = @CalibrationTag WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND TagType = @TagTypeCalibration AND Active = 1          
        --      ELSE          
        --        UPDATE [TCD].ModuleTags SET Active = 0 WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND TagType = @TagTypeCalibration AND Active = 1          
        --    END --@IsActive = 'TRUE'          
        --  ELSE          
        --    BEGIN --Can be combined into 1 update stmt. ...          
        --      UPDATE [TCD].ModuleTags SET Active = 0 WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND TagType = @TagTypeLfs AND Active = 1          
        --      UPDATE [TCD].ModuleTags SET Active = 0 WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND TagType = @TagTypeKfactor AND Active = 1          
        --      UPDATE [TCD].ModuleTags SET Active = 0 WHERE ModuleID = @PumpId AND ModuleTypeId = @ModuleType AND TagType = @TagTypeCalibration AND Active = 1          
        --    END          
								--END
								-----Tags---			
							
        SELECT TOP 1          
          @OutputControllerEquipmentSetupId = O.ControllerEquipmentSetupId          
        FROM @OutputList   O          

        IF @@TRANCOUNT > 0          
									COMMIT
      END TRY          
      BEGIN CATCH          
        IF @@TRANCOUNT > 0          
									ROLLBACK
							
        SELECT /*@ErrorNumber    =  ERROR_NUMBER()          
         , */@ErrorMessage    =  ERROR_MESSAGE()          
         , @ErrorProcedure    =  ERROR_PROCEDURE()          
         , @ErrorSeverity    =  ERROR_SEVERITY()          
							
        SET  @OutputControllerEquipmentSetupId          
                 =  NULL          
        SET  @ReturnValue    =  -1          
        SET  @MessageString    =  N'An error occured while Updating Pump/Valve details. The error is: '          
                 +  @ErrorMessage + ' '          
                 +  'Module: ' + @ErrorProcedure          
							
								RAISERROR(@MessageString, @ErrorSeverity, 1)
      END CATCH          
					END
		END
ELSE
		BEGIN
				DECLARE @NewPumpId INT = NULL
    SELECT @DistinctChemicalCount    =   COUNT(DISTINCT D.ProductId) --distinct count          
    FROM (          
      SELECT @ProductId     AS   ProductId     --being assigned          
						UNION
      SELECT DISTINCT ProductId  AS   ProductId     --already assigned          
      FROM [TCD].ControllerEquipmentSetup          
      WHERE ControllerId    =   @ControllerId          
       AND ProductId     <>   @ProductId          
      ) D          

    IF ( @DistinctChemicalCount > @MaximumChemicalCount )          
				BEGIN
      SET @ErrorId   = 51000          
      SET @ErrorMessage  = N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Maximum chemical count exceeded. Cannot assign new chemical'          
      --GOTO ErrorHandler          
      RAISERROR (@ErrorMessage, 16, 1)          
      SET @ReturnValue = -1          
      RETURN (@ReturnValue)          
				END

				--IF(@RoleId =8)
				--BEGIN
    --  IF(@LfsChemicalNameTag IS NOT NULL AND @LfsChemicalNameTag <> '')          
    --   BEGIN          
    --   EXEC @Result1 = TCD.CheckDuplicateTag @LfsChemicalNameTag, @ControllerID          
    --   IF(@Result1 = 0)          
    --   BEGIN          
    --   SET @ErrorMessage = '801,'          
    --   END          
    --  END          
    --  IF(@KfactorTag IS NOT NULL AND @KfactorTag <> '')          
    --   BEGIN          
    --    EXEC @Result2 = TCD.CheckDuplicateTag @KfactorTag,@ControllerID          
    --    IF(@Result2 = 0)          
    --    BEGIN          
    --    SET @ErrorMessage = @ErrorMessage+'802,'          
    --    END       
    --   END          
    --  IF(@CalibrationTag IS NOT NULL AND @CalibrationTag <> '')          
    --   BEGIN          
    --    EXEC @Result3 = TCD.CheckDuplicateTag @CalibrationTag,@ControllerID          
    --    IF(@Result3 = 0)          
    --    BEGIN          
    --    SET @ErrorMessage = @ErrorMessage+'803,'          
    --    END          
    --   END          
				--END

				--SET @ErrorMessage = @ErrorMessage + CONVERT(VARCHAR(100),'')
				--IF(@ErrorMessage <> '')
    -- RAISERROR(@ErrorMessage, 16, 1)          
				ELSE
					BEGIN
      BEGIN TRY          
        BEGIN TRAN          

        INSERT [TCD].ControllerEquipmentSetup  (          
             EcoLabAccountNumber          
        ,    ControllerId          
        ,    ControllerEquipmentId          
        ,    ControllerEquipmentTypeId          
        ,    ProductId          
        ,    IsActive          
        ,    LfsChemicalName          
        ,    KFactor          
        ,    PumpCalibration          
        ,    TunnelHold          
        ,    FlowDetectorType     
        ,     FlowSwitchNumber       
        ,    FlowSwitchAlarm          
        ,    FlowMeterAlarm          
        ,    FlowMeterType          
        ,    FlowAlarmDelay          
        ,    FlowMeterPumpDelay          
        ,    FlowMeterAlarmDelay          
        , ControllerEquipmentTypeModelId           
        , ConventionalWasherGroupConnection           
        , AxillaryPumpCalibration             
        , FlowmeterSwitchActivated             
        , FlushWhileDosing               
        , WeightControlledDosage              
        , EquipmentDoseAlone                 
        , LowLevelAlarm                    
        , LeakageAlarm                    
        , FlushTime                   
        , PumpingTime                  
        , PreFlushTime                  
        , NightFlushPauseTime                 
        , NightFlushTime                  
        , AcceptedDeviation                 
        , LineNumber                 
        , MaximumDosingTime              
        , FlowSwitchTimeOut   
       , ValveOutputAsTom         
        , LastModifiedByUserId            
       --** Adding a part of integration with Synch./Central -->          
        , LastModifiedTime          
        , FlushValveNumber              
       , CalibrationConductSS_Tank           
       , BackFlowControl                
       , FactorFM_B_FM                    
       , AcceptedDeviationRingLine           
       , UsePumpOfGroup1ForTunnel             
       , pHSensorEnabled      
    , FlushTimeForFlushValve    
       , Concentration       
       , Deadband      
        , MinimumFlowRate 
  , ProductDensity 
  , MaximumConcentration
								)
       OUTPUT inserted.ControllerEquipmentSetupId   AS   ControllerEquipmentSetupId          
        , inserted.LastModifiedTime     AS   LastModifiedTime          
       INTO @OutputList (          
									ControllerEquipmentSetupId
        , LastModifiedTimestamp          
								)
       --** <--          
       SELECT @EcoLabAccountNumber    AS   EcoLabAccountNUmber          
        , @ControllerId      AS   ControllerEquipmentId          
        , @ControllerEquipmentId    AS   ControllerEquipmentId          
        , @ControllerEquipmentTypeId   AS   ControllerEquipmentTypeId          
        , @ProductId      AS   ProductId          
        , @IsActive       AS   IsActive          

        , LfsChemicalName     =   CASE @IsActive WHEN 'TRUE' THEN @LfsChemicalName   ELSE NULL END          
        , KFactor       =   CASE @IsActive WHEN 'TRUE' THEN @KFactor     ELSE NULL END          
        , PumpCalibration     =   CASE @IsActive WHEN 'TRUE' THEN @PumpCalibration   ELSE NULL END          
				
        , TunnelHold      =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @TunnelHold   ELSE NULL END ELSE NULL END          
        , FlowDetectorType     =   CASE @IsActive WHEN 'TRUE' THEN CASE WHEN @ControllerTypeId IN (2,6,7, 12,10, 14,8, 13,9,11) THEN @FlowDetectorType  ELSE NULL END ELSE NULL END          
        , FlowSwitchNumber        =    @FlowSwitchNumber  
        , FlowSwitchAlarm     =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowSwitchAlarm  ELSE NULL END ELSE NULL END          
      , FlowMeterAlarm      =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterAlarm  ELSE NULL END ELSE NULL END          
        , FlowMeterType      =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterType   ELSE NULL END ELSE NULL END          
        , FlowAlarmDelay      =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowAlarmDelay  ELSE NULL END ELSE NULL END          
        , FlowMeterPumpDelay     =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterPumpDelay  ELSE NULL END ELSE NULL END          
        , FlowMeterAlarmDelay     =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterAlarmDelay ELSE NULL END ELSE NULL END          
        , ControllerEquipmentTypeModelId  =   CASE @IsActive WHEN 'TRUE' THEN @ControllerEquipmentTypeModelId      ELSE NULL END          
        , ConventionalWasherGroupConnection      =   CASE @IsActive WHEN 'TRUE' THEN @ConventionalWasherGroupConnection  ELSE 0 END          
        , AxillaryPumpCalibration        =   CASE @IsActive WHEN 'TRUE' THEN @AxillaryPumpCalibration    ELSE 0 END          
        , FlowmeterSwitchActivated        =   CASE @IsActive WHEN 'TRUE' THEN @FlowmeterSwitchActivated   ELSE 0 END          
        , FlushWhileDosing          =   CASE @IsActive WHEN 'TRUE' THEN @FlushWhileDosing      ELSE 0 END          
        , WeightControlledDosage         =   CASE @IsActive WHEN 'TRUE' THEN @WeightControlledDosage     ELSE 0 END          
        , EquipmentDoseAlone            =   CASE @IsActive WHEN 'TRUE' THEN @EquipmentDoseAlone        ELSE 0 END          
        , LowLevelAlarm               =   CASE @IsActive WHEN 'TRUE' THEN @LowLevelAlarm           ELSE 0 END          
        , LeakageAlarm               =   CASE @IsActive WHEN 'TRUE' THEN @LeakageAlarm           ELSE 0 END          
        , FlushTime              =   CASE @IsActive WHEN 'TRUE' THEN @FlushTime         ELSE NULL END          
        , PumpingTime             =   CASE @IsActive WHEN 'TRUE' THEN @PumpingTime         ELSE NULL END          
        , PreFlushTime             =   CASE @IsActive WHEN 'TRUE' THEN @PreFlushTime         ELSE NULL END          
        , NightFlushPauseTime            =   CASE @IsActive WHEN 'TRUE' THEN @NightFlushPauseTime       ELSE NULL END          
        , NightFlushTime             =   CASE @IsActive WHEN 'TRUE' THEN @NightFlushTime  ELSE NULL END          
        , AcceptedDeviation            =   CASE @IsActive WHEN 'TRUE' THEN @AcceptedDeviation        ELSE NULL END          
        , LineNumber           =   CASE @IsActive WHEN 'TRUE' THEN @LineNumber           ELSE NULL END          
        , MaximumDosingTime         =   CASE @IsActive WHEN 'TRUE' THEN @MaximumDosingTime     ELSE NULL END          
        , FlowSwitchTimeOut     =   CASE @IsActive WHEN 'TRUE' THEN @FlowSwitchTimeOut     ELSE NULL END         
       , ValveOutputAsTom               =   CASE @IsActive WHEN 'TRUE' THEN @ValveOutputAsTom           ELSE 0 END     

        --, CASE @IsActive WHEN 'TRUE' THEN @FlowMeterSwitchFlag ELSE NULL END AS FlowMeterSwitchFlag           
        --, CASE @IsActive WHEN 'TRUE' THEN @FlowMeterCalibration ELSE NULL END AS FlowMeterCalibration          
        --, CASE @IsActive WHEN 'TRUE' THEN @MaximumDosingTime ELSE NULL END AS MaximumDosingTime          
        --, CASE @IsActive WHEN 'TRUE' THEN @FlowSwitchTimeOut ELSE NULL END AS FlowSwitchTimeOut          
        , @UserId        AS   LastModifiedByUserId          
								--Synch./Central integration additions
        , @CurrentUTCTime      AS   LastModifiedTime          
       , FlushValveNumber  =   CASE @IsActive WHEN 'TRUE' THEN @FlushValveNumber     ELSE NULL END           
       , CalibrationConductSS_Tank =   CASE @IsActive WHEN 'TRUE' THEN @CalibrationConductSS_Tank     ELSE NULL END         
       , BackFlowControl  =   CASE @IsActive WHEN 'TRUE' THEN @BackFlowControl     ELSE 'False' END            
       , FactorFM_B_FM   =   CASE @IsActive WHEN 'TRUE' THEN @FactorFM_B_FM     ELSE NULL END                
       , AcceptedDeviationRingLine =   CASE @IsActive WHEN 'TRUE' THEN @AcceptedDeviationRingLine     ELSE NULL END           
       , UsePumpOfGroup1ForTunnel =   CASE @IsActive WHEN 'TRUE' THEN @UsePumpOfGroup1ForTunnel     ELSE NULL END             
       , pHSensorEnabled    =   CASE @IsActive WHEN 'TRUE' THEN @pHSensorEnabled     ELSE NULL END    
    , FlushTimeForFlushValve = @FlushTimeForFlushValve     
       , Concentration =   CASE @IsActive WHEN 'TRUE' THEN @Concentration     ELSE NULL END             
       , Deadband    =   CASE @IsActive WHEN 'TRUE' THEN @Deadband     ELSE NULL END       
        , MinimumFlowRate = CASE @IsActive WHEN 'TRUE' THEN @MinimumFlowRate     ELSE NULL END  
       , ProductDensity = CASE @IsActive WHEN 'TRUE' THEN @ProductDensity     ELSE NULL END
       , MaximumConcentration = CASE @IsActive WHEN 'TRUE' THEN @MaximumConcentration     ELSE NULL END 
								SET @NewPumpId = SCOPE_IDENTITY() 
					
								---Tags---
								--IF(@RoleId =8)
        -- BEGIN          
        --   IF(@IsActive = 'TRUE')          
        --    BEGIN          
        --      IF(@LfsChemicalNameTag IS NOT NULL AND @LfsChemicalNameTag <> '')           
        --        INSERT INTO TCD.ModuleTags (EcolabAccountNumber ,TagType,TagAddress,ModuleTypeId,ModuleId,DeadBand,Active)          
        --        VALUES(@EcoLabAccountNumber ,@TagTypeLfs,@LfsChemicalNameTag,@ModuleType,@NewPumpId,@DefaultFrequency,1)          

        --      IF(@KfactorTag IS NOT NULL AND @KfactorTag <> '')           
        --        INSERT INTO TCD.ModuleTags (EcolabAccountNumber ,TagType,TagAddress,ModuleTypeId,ModuleId,DeadBand,Active)          
        --        VALUES(@EcoLabAccountNumber ,@TagTypeKfactor,@KfactorTag,@ModuleType,@NewPumpId,@DefaultFrequency,1)          

        --      IF(@CalibrationTag IS NOT NULL AND @CalibrationTag  <> '')           
        --        INSERT INTO TCD.ModuleTags (EcolabAccountNumber ,TagType,TagAddress,ModuleTypeId,ModuleId,DeadBand,Active)          
        --        VALUES(@EcoLabAccountNumber ,@TagTypeCalibration,@CalibrationTag,@ModuleType,@NewPumpId,@DefaultFrequency,1)          
        --    END          
        -- END          
								-----Tags---
        SET @ErrorId = @@ERROR          
        IF (@ErrorId <> 0)          
									BEGIN
          IF @@TRANCOUNT >0          
											ROLLBACK

          SET  @ErrorMessage  = N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred associating Equipment to Controller'          
          --GOTO Errorhandler          
          RAISERROR (@ErrorMessage, 16, 1)          
          SET @ReturnValue = -1      
         RETURN (@ReturnValue)          
							END

        SELECT TOP 1          
          @OutputControllerEquipmentSetupId = O.ControllerEquipmentSetupId          
        FROM @OutputList   O          

        IF @@TRANCOUNT > 0          
									COMMIT
      END TRY          
      BEGIN CATCH          
        IF @@TRANCOUNT > 0          
									ROLLBACK
							
        SELECT /*@ErrorNumber    =  ERROR_NUMBER()          
         , */@ErrorMessage    =  ERROR_MESSAGE()          
         , @ErrorProcedure    =  ERROR_PROCEDURE()          
         , @ErrorSeverity    =  ERROR_SEVERITY()          
							
        SET  @OutputControllerEquipmentSetupId          
                 =  NULL          
        SET  @ReturnValue    =  -1          
        SET  @MessageString    =  N'An error occured while Updating Pump/Valve details. The error is: '          
                 +  @ErrorMessage + ' '          
                 +  'Module: ' + @ErrorProcedure          
							
								RAISERROR(@MessageString, @ErrorSeverity, 1)
      END CATCH          
     END          
  END          
     
  -------------------------------------------
  IF((SELECT CONTROLLERMODELID FROM TCD.ConduitController WHERE ControllerId=@ControllerId)='11')
  BEGIN
	IF(@ControllerEquipmentTypeId=2 AND @ControllerEquipmentId IN(13,14,27,28))
	BEGIN

		UPDATE TCD.ControllerEquipmentSetup  SET CalibrationConductSS_Tank=@CalibrationConductSS_Tank
		WHERE EcoLabAccountNumber=@EcoLabAccountNumber AND	ControllerId=@ControllerId AND ControllerEquipmentTypeId=@ControllerEquipmentTypeId
		AND ControllerEquipmentId=CASE WHEN @ControllerEquipmentId=13 THEN 27 
								   WHEN @ControllerEquipmentId=27 THEN 13  	
								   WHEN @ControllerEquipmentId=14 THEN 28
								   WHEN @ControllerEquipmentId=28 THEN 14 END 
					END
		END
  -------------------------------------------

  IF ( @ErrorId = 0 )          
	BEGIN
  --GOTO ExitModule          
  RETURN (@ReturnValue)          
	END


		--ErrorHandler:
--RAISERROR (@ErrorMessage, 16, 1)          
--SET @ReturnValue = -1          




--ExitModule:

SET NOCOUNT OFF          
RETURN (@ReturnValue)          


END
GO


IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[AddConventional]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.AddConventional
	END
GO  
 
/*
Purpose					:	To add a new Conventional Washer from the Washer setup UI - General tab

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version

--sp_helptext	usp_AddConventional

*/

CREATE PROCEDURE	[TCD].[AddConventional]
					@EcoLabAccountNumber					NVARCHAR(1000)
				,	@WasherGroupId							INT
				, @NewWasherGroupId		int				=	null
				,	@ConventionalName						NVARCHAR(50)
				,	@ModelId								INT						--(Washer)Model Id for Size
				,	@ControllerId							INT
				,	@LFSWasherNumber						TINYINT					=	NULL
				,	@PlantWasherNumber						SMALLINT
				,	@WasherMode								TINYINT
				,	@MaxLoad								SMALLINT
				,	@AWEActive								BIT
				,	@HoldSignal								BIT
				,	@HoldDelay								SMALLINT															
				,	@TargetTurnTime							SMALLINT
				,	@WaterFlushTime							SMALLINT
				,	@ProgramNumber							TINYINT					--EOF number
				,	@Description							NVARCHAR(1024)			=	NULL
				,	@UserId									INT
				,	@ConventionalWasherGuid					UniqueIdentifier
				,	@ConventionalWasherId					INT									OUTPUT
				,	@LastModifiedTimestampAtCentral			DATETIME				=	NULL
				,	@OutputLastModifiedTimestampAtLocal		DATETIME				=	NULL	OUTPUT
				,	@IsDeleted								BIT						=	'FALSE'
				,   @RatioDosingActive						BIT						=	'FALSE'
,   @IsPony      BIT      = 'FALSE'
				,	@MinMachineLoad							SMALLINT				=	NULL
				,	@MaxMachineLoad							smallint				=	NULL
				,	@ProgramSelectionByTime					bit						=	NULL
				,	@FlowSwitchNumber						int						=	NULL
				,	@WasherStopExternalSignal				bit						=	NULL
				,	@OnHoldWESignalActive					bit						=	NULL
				,	@WasherOnHoldSignalDelay				int						=	NULL
				,	@ValveOutputsUsedAsTomSignal			bit						=	NULL
				,	@WeInTomMode							bit						=	NULL
				,	@ManifoldFlushTime						int						=	NULL
				,	@L1										bit						=	NULL
				,	@L2										bit						=	NULL
				,	@L3										bit						=	NULL
				,	@L4										bit						=	NULL
				,	@L5										bit						=	NULL
				,	@L6										bit						=	NULL
				,	@L7										bit						=	NULL
				,	@L8										bit						=	NULL
				,	@L9										bit						=	NULL
				,	@L10									bit						=	NULL
				,	@L11									bit						=	NULL
				,	@L12									bit						=	NULL
				,	@MyServiceLastSyncTime					DATETIME				=	NULL
				,	@UseMe1OfGroup							tinyint					=	NULL
				,	@UseMe2OfGroup							tinyint					=	NULL
				,	@UsePumpOfGroup							tinyint					=	NULL
				,	@WasherStopUseFinalExtracting			bit						=	NULL
				,	@TemperatureAlarmYesNo					bit						=	NULL
				,   @DefaultIdleTime						INT						=   NULL
				,   @ETechWasherNumber						INT						=   NULL


AS
BEGIN

SET NOCOUNT ON


DECLARE
@ReturnValue     INT    =   0
, @ErrorId      INT    =   0
, @ErrorMessage     NVARCHAR(4000) =   N''

, @WasherId      INT    =   NULL
 , @PlantId		 INT	 =	 NULL
 , @ControllerModelId INT = NULL
--, @WasherModelId     SMALLINT  =   NULL
--, @CurrentUTCTime     DATETIME  =   GETUTCDATE()     --SQLEnlight SA0004

DECLARE
@OutputList      AS TABLE  (
WasherId      INT
, LastModifiedTimestamp   DATETIME
)

SET  @ConventionalWasherId = ISNULL(@ConventionalWasherId, NULL)   --SQLEnlight
SET  @OutputLastModifiedTimestampAtLocal   =   ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)   --SQLEnlight
SET  @LastModifiedTimestampAtCentral    =   ISNULL(@LastModifiedTimestampAtCentral, NULL)    --SQLEnlight SA0029
SELECT  @PlantId = PlantId From TCD.Plant WHERE EcolabAccountNumber = @EcoLabAccountNumber
SELECT @ControllerModelId = cmctm.ControllerModelId 
FROM TCD.ControllerModelControllerTypeMapping cmctm 
INNER JOIN TCD.ConduitController cc 
	ON cc.ControllerModelId = cmctm.ControllerModelId
WHERE cc.ControllerId = @ControllerId AND cc.EcoalabAccountNumber = @EcoLabAccountNumber

--Check that the WasherGroup being associated-to is a valid Conventional-type WG...
IF NOT EXISTS ( SELECT 1
FROM [TCD].WasherGroup     WG
JOIN [TCD].WasherGroupType    WGT
ON WG.WasherGroupTypeId  =   WGT.WasherGroupTypeId
JOIN [TCD].MachineGroup     GT         --this is actually the Groups table and NOT really a Group TYPE
ON WG.WasherGroupId   =   GT.Id   --Id is actually the Id of the Group
AND WG.EcolabAccountNumber  =   GT.EcolabAccountNumber
WHERE WG.WasherGroupId   =   @WasherGroupId
AND GT.EcolabAccountNumber  =   @EcoLabAccountNumber
AND GT.GroupTypeId      =   2   --select GroupMaintype from MachineGroup
AND WGT.WasherGroupTypeName  =   'Conventional'   --select WasherGroupTypeName from WasherGroupType
AND GT.Is_Deleted    =   'FALSE'
)
BEGIN
SET  @ErrorId      =   51001
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherGroup provided.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

--Check for unique PlantWasherNo.
IF EXISTS  ( SELECT 1
FROM [TCD].Washer      W
JOIN [TCD].MachineSetup     MS
ON W.WasherId     =   MS.WasherId
AND W.EcoLabAccountNumber  =   MS.EcoalabAccountNumber
WHERE W.EcoLabAccountNumber  =   @EcoLabAccountNumber
AND (
W.PlantWasherNumber   =   @PlantWasherNumber
)
AND W.Is_Deleted    =   'FALSE'
AND MS.IsDeleted    =   'FALSE'
)
BEGIN
SET  @ErrorId      =   51002
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Specified Plant Washer #/ already exists.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

IF @ControllerId > 0
BEGIN
--Check on valid LFSWasher#/Controller type/model...
IF @LFSWasherNumber IS NOT NULL
BEGIN
	IF NOT EXISTS ( SELECT 1
	FROM [TCD].ControllerModelControllerTypeMapping
	CMCTM
	JOIN [TCD].ConduitController   CC
	ON CC.ControllerTypeId   =   CMCTM.ControllerTypeId
	AND CC.ControllerModelId  =   CMCTM.ControllerModelId
	WHERE CC.EcoalabAccountNumber  =   @EcoLabAccountNumber
	AND CC.ControllerId    =   @ControllerId
	AND CC.IsDeleted    =   'FALSE'
	AND CMCTM.MaximumWasherExtractorCount
	>=   @LFSWasherNumber
	)
		BEGIN
			SET  @ErrorId      =   51003
			SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller/LFSWasher# was provided.'
			--GOTO ErrorHandler
			RAISERROR (@ErrorMessage, 16, 1)
			SET  @ReturnValue = -1
			RETURN (@ReturnValue)
		END
END
END
--EOF should not be an asocciated formula for the WG...
IF EXISTS  ( SELECT 1
FROM [TCD].WasherProgramSetup   WPS
WHERE WPS.EcolabAccountNumber  =   @EcoLabAccountNumber
AND WPS.WasherGroupId   =   @WasherGroupId
AND WPS.ProgramNumber   =   @ProgramNumber
AND WPS.Is_Deleted    =   'FALSE'
)
BEGIN
SET  @ErrorId      =   51004
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An assoicated formula cannot be specified as End-Of-Formula.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

IF @ControllerId > 0
BEGIN
--WasherMode check
IF NOT EXISTS ( SELECT 1
FROM [TCD].ControllerModelControllerTypeMapping
CMCTM
					JOIN	[TCD].ConduitController			CC
						ON	CC.ControllerTypeId			=			CMCTM.ControllerTypeId
						AND	CC.ControllerModelId		=			CMCTM.ControllerModelId
					JOIN	[TCD].[WasherModeMapping]			CTM2WM
						ON	CMCTM.Id					=			CTM2WM.ControllerModelControllerTypeMappingId
					WHERE	CC.EcoalabAccountNumber		=			@EcoLabAccountNumber
						AND	CC.ControllerId				=			@ControllerId
						AND	CC.IsDeleted				=			'FALSE'
						AND	CTM2WM.WasherModeId			=			@WasherMode
)
BEGIN
SET  @ErrorId      =   51005
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherMode was provided.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

--LFSWasherNumber duplicate check...
IF	EXISTS	(	SELECT	1
				FROM	[TCD].MachineSetup					MS
				WHERE	MS.ControllerId					=			@ControllerId
					AND	MS.MachineInternalId			=			@LFSWasherNumber
					AND MS.EcoalabAccountNumber			=			@EcoLabAccountNumber
					AND	MS.IsDeleted					=			'FALSE'
					AND MS.IsTunnel						=			'FALSE'

)
BEGIN
SET  @ErrorId      =   51010
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate LFSWasher# provided.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END
--ETechWasherNumber duplicate check...
IF(@ControllerModelId NOT IN (7,8,9,10,11,14))
BEGIN 
IF EXISTS ( SELECT 1
    FROM [TCD].Washer  AS W
    JOIN [TCD].MachineSetup AS MS ON MS.WasherId = W.WasherId 
    where W.ETechWasherNumber = @ETechWasherNumber
   AND MS.IsTunnel                    =            'FALSE'
)  
BEGIN  

SET  @ErrorId      =   51010  
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate ETechWasherNumber# provided.'  
--GOTO ErrorHandler  
RAISERROR (@ErrorMessage, 16, 1)  
SET  @ReturnValue = -1  
RETURN (@ReturnValue)  
END
END
END
--Now attempt to insert a new row for the conventional washer being added...
BEGIN TRAN

INSERT	[TCD].Washer	(
	 EcoLabAccountNumber	,PlantWasherNumber			,ModelId				,WasherMode					,MaxLoad						,AWEActive				,EndOfFormula
	,[Description]			,Is_Deleted					,LastModifiedByUserId	,HoldSignal					,HoldDelay						,TargetTurnTime			,WaterFlushTime		
	,MyServiceCustMchGuid	,RatioDosingActive			,MyServiceLastSynchTime	,MinMachineLoad				,MaxMachineLoad					,ProgramSelectionByTime	,FlowSwitchNumber		
	,WasherStopExternalSignal	,OnHoldWESignalActive	, WasherOnHoldSignalDelay	,ValveOutputsUsedAsTomSignal			,WeInTomMode			,ManifoldFlushTime	
	,L1	,L2	,L3	,L4	,L5	,L6	,L7	,L8	,L9	 ,L10 ,L11	,L12 ,UseMe1OfGroup ,UseMe2OfGroup ,UsePumpOfGroup ,WasherStopUseFinalExtracting ,TemperatureAlarmYesNo ,PlantId, DefaultIdleTime, ETechWasherNumber
)
OUTPUT
inserted.WasherId      AS   Id
, inserted.LastModifiedTime  AS   LastModifiedTimestamp
INTO
@OutputList (
WasherId
, LastModifiedTimestamp
)

SELECT	@EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	@PlantWasherNumber					AS			PlantWasherNumber
	,	@ModelId							AS			ModelId
	,	@WasherMode							AS			WasherMode
	,	@MaxLoad							AS			MaxLoad
	,	@AWEActive							AS			AWEActive
	,	@ProgramNumber						AS			ProgramNumber
	,	@Description						AS			[Description]
	,	@IsDeleted							AS			Is_Deleted
	,	@UserId								AS			LastModifiedByUserId
	,	@HoldSignal							AS			HoldSignal
	,	@HoldDelay							AS			HoldDelay
	,	@TargetTurnTime						AS			TargetTurnTime
	,	@WaterFlushTime						AS			WaterFlushTime
	,	@ConventionalWasherGuid				AS			MyServiceCustMchGuid
	,	@RatioDosingActive					AS			RatioDosingActive
	,	@MyServiceLastSyncTime				AS			MyServiceLastSynchTime
	,	@MinMachineLoad						AS			MinimumMachineLoad
	,	@MaxMachineLoad						AS			MaximumMachineLoad
	,	@ProgramSelectionByTime				AS			ProgramSelectionByTime
	,	@FlowSwitchNumber					AS			FlowSwitchNumber
	,	@WasherStopExternalSignal			AS			WasherStopExternalSignal
	,	@OnHoldWESignalActive				AS			OnHoldWESignalActive
	,	@WasherOnHoldSignalDelay			AS			WasherOnHoldSignalDelay
	,	@ValveOutputsUsedAsTomSignal		AS			ValveOutputsUsedAsTomSignal
	,	@WeInTomMode						AS			WeInTomMode			
	,	@ManifoldFlushTime					AS			ManifoldFlushTime			
	,	@L1									AS			L1
	,	@L2									AS			L2
	,	@L3									AS			L3
	,	@L4									AS			L4
	,	@L5									AS			L5
	,	@L6									AS			L6
	,	@L7									AS			L7
	,	@L8									AS			L8
	,	@L9									AS			L9
	,	@L10								AS			L10
	,	@L11								AS			L11
	,	@L12								AS			L12
	,	@UseMe1OfGroup						AS			UseMe1OfGroup
	,	@UseMe2OfGroup						AS			UseMe2OfGroup
	,	@UsePumpOfGroup						AS			UsePumpOfGroup
	,	@WasherStopUseFinalExtracting		AS			WasherStopUseFinalExtracting
	,	@TemperatureAlarmYesNo				AS			TemperatureAlarmYesNo
	,	@PlantId							AS			PlantId
	,   @DefaultIdleTime AS   DefaultIdleTime 
	,   @ETechWasherNumber AS ETechWasherNumber


SET @ErrorId = @@ERROR

IF (@ErrorId <> 0)
BEGIN
IF @@TRANCOUNT > 0
BEGIN
ROLLBACK TRAN
END

SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred creating new record for conventional.'
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

--if no error, collect the id of the newly generated row...
SELECT TOP 1 @WasherId = O.WasherId FROM @OutputList O

--insert in MachineSetup
INSERT [TCD].MachineSetup (
WasherId ,GroupId ,MachineInternalId ,EcoalabAccountNumber ,MachineName ,IsTunnel ,ControllerId , IsDeleted ,LastModifiedByUserId,IsPony )
SELECT @WasherId     AS   WasherId
, @WasherGroupId    AS   GroupId
, @LFSWasherNumber   AS   MachineInternalId
, @EcoLabAccountNumber  AS   EcoalabAccountNumber
, @ConventionalName   AS   MachineName
,@IsDeleted      AS   IsTunnel
, @ControllerId    AS   ControllerId
, 'FALSE'      AS   IsDeleted
, @UserId      AS   LastModifiedByUserId
,@IsPony As IsPony



 IF(ISNULL( @NewWasherGroupId,0)>0 AND (@WasherGroupId != @NewWasherGroupId))
 BEGIN
    UPDATE tcd.machinesetup 
    SET GroupId = @NewWasherGroupId
    WHERE WasherId = @WasherId
     
   EXEC TCD.SaveInjectionDetails @WasherGroupId,@NewWasherGroupId,@ControllerId,@WasherId,@EcolabAccountNumber
 END
 ELSE
 BEGIN
   EXEC TCD.SaveInjectionDetails @WasherGroupId,@WasherGroupId,@ControllerId,@WasherId,@EcolabAccountNumber
 END

SET @ErrorId = @@ERROR

IF (@ErrorId <> 0)
BEGIN
IF @@TRANCOUNT > 0
BEGIN
ROLLBACK TRAN
END

SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred assoicating new record for conventional.'
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END
ELSE
BEGIN
IF @@TRANCOUNT > 0
BEGIN
COMMIT
END

--SET the output param to be communicated back...

SELECT TOP 1
@OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp
, @ConventionalWasherId    = O.WasherId
FROM @OutputList       O

END




IF ( @ErrorId = 0 )
BEGIN
		IF (@ControllerModelId = 7)
			BEGIN
				UPDATE TCD.WasherGroup SET ControllerId = @ControllerId WHERE WasherGroupId = @WasherGroupId
			END
RETURN (@ReturnValue)
END



--ErrorHandler:
--RAISERROR (@ErrorMessage, 16, 1)
--SET @ReturnValue = -1


--ExitModule:

--RETURN (@ReturnValue)

--SET NOCOUNT OFF

END
GO


IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[AddTunnel]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.AddTunnel
	END
GO  
/*	
Purpose					:	To add a new Tunnel from the Washer-Tunnel (General) setup screen

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version

*/
CREATE PROCEDURE	[TCD].[AddTunnel]	
					@MyServiceWasherId						UniqueIdentifier
				,	@EcoLabAccountNumber					NVARCHAR(1000)
				,	@WasherGroupId							INT
				,	@TunnelName								NVARCHAR(50)
				,	@WasherModelName						NVARCHAR(50)
				,	@RegionId								SMALLINT
--				,	@Size									INT									--we don't need to save this; ModelId PK determines it
				,	@ControllerId							INT
				,	@LFSWasherNumber						TINYINT			=			1		--For tunnels, it will be 1 until a diff. number is passed (as per the scenario)
				,	@PlantWasherNumber						SMALLINT
				,	@WasherMode								TINYINT
				,	@MaxLoad								SMALLINT
				,	@AWEActive								BIT
				,	@NumberOfTanks							TINYINT
				,	@NumberOfComp							TINYINT								--though this is INT in the table, we should not require it to be so
				,	@TransferType							TINYINT         =			NULL
				,	@PressExtractor							TINYINT       =			NULL
				,	@ProgramNumber							TINYINT
				,	@EndOfFormula							TINYINT
				,	@Description							NVARCHAR(1024)	=			NULL
				,	@UserId									INT

				,	@OutputTunnelId							INT			OUTPUT
				--Adding as part of re-factoring for integration with Synch/Configurator... generated TunnelId (re-named) is already being OUTPUT above
				,	@OutputLastModifiedTimestampAtLocal		DATETIME		=			NULL	OUTPUT
				,   @RatioDosingActive						Bit = 'False'
				,   @ControllerModelId						INT		=		NULL
				,   @NumberOfCompartmentsConveyorBelt			TINYINT	=		NULL
				,   @MaxMachineLoad							TINYINT	=		NULL
				,   @MinMachineLoad							TINYINT	=		NULL
				,   @ProgramSelectionByTime					BIT	  	=		NULL
				,   @WeightSelectionByTime					BIT	  	=		NULL
				,   @WeightSelectionByAnalogInput				BIT	  	=		NULL
				,   @TunInTomMode							BIT	  	=		NULL
				,   @SignalStopTunActive						BIT	  	=		NULL
				,   @SignalEjectionTunActive	  				BIT	  	=		NULL
				,   @DelayTimeForTunWashingPrograms			BIT	  	=		NULL
				,   @KannegiesserPressSpecialMode				BIT	  	=		NULL
				,   @ValveOutputsUsedAsTomSignal				BIT	  	=		NULL
				,   @ExtendedClockOrDataProtocol				BIT	  	=		NULL
				,   @WeightCorrectionFcc						BIT	  	=		NULL
				,	@DateAndTimeWhenBatchEjects					BIT	  		=		NULL
				,	@AutoRinseDesamixAfter						SMALLINT	=		NULL
				,	@AutoRinseDesamix1For						SMALLINT	=		NULL
				,	@AutoRinseDesamix2For						SMALLINT	=		NULL
				,	@TemperatureAlarmProbe1						BIT			=		NULL
				,	@TemperatureAlarmProbe2						BIT			=		NULL
				,	@TemperatureAlarmProbe3						BIT			=		NULL
				,	@ETechWasherNumber						    INT			=		NULL


AS
BEGIN

SET	NOCOUNT	ON


DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''

	,	@WasherId						INT				=			NULL
	,	@WasherModelId					SMALLINT		=			NULL
	--Adding for integration with Synch./Central
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()
	,	@ControllerValidate				int				=										   0

--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
SET		@OutputLastModifiedTimestampAtLocal				=			@CurrentUTCTime
SET		@OutputTunnelId									=			ISNULL(@OutputTunnelId, NULL)			--SQLEnlight

--Check that the WasherGroup being associated-to is a valid Tunnel-type WG...
IF	NOT	EXISTS	(	SELECT	1
					FROM	[TCD].WasherGroup			WG
					JOIN	[TCD].WasherGroupType		WGT
						ON	WG.WasherGroupTypeId		=			WGT.WasherGroupTypeId
					JOIN	[TCD].MachineGroup					GT									--this is actually the Groups table and NOT really a Group TYPE
						ON	WG.WasherGroupId			=			GT.Id			--GroupTypeId is actually the Id of the Group
					WHERE	WG.WasherGroupId			=			@WasherGroupId
						AND	GT.EcolabAccountNumber		=			@EcoLabAccountNumber
						AND	GT.GroupTypeId	  			=			2			--select	GroupMaintype	from	GroupType
						AND	WGT.WasherGroupTypeName		=			'Tunnel'				--select	WasherGroupTypeName	from	WasherGroupType
				)
			BEGIN
				SET		@ErrorId						=			51001
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherGroup provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--Check for only 1 tunnel for a WasherGroup
IF	EXISTS		(	SELECT	1
					FROM	[TCD].MachineSetup			MS
					JOIN	[TCD].Washer				W
						ON	MS.WasherId					=			W.WasherId
					WHERE	MS.GroupId					=			@WasherGroupId
						AND	MS.EcoalabAccountNumber		=			@EcoLabAccountNumber
						AND	MS.IsDeleted				=			'FALSE'
						AND	MS.IsTunnel					=			'TRUE'
						AND	W.Is_Deleted				=			'FALSE'
				)
			BEGIN
				SET		@ErrorId						=			51008
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': A Tunnel has already been added to this Washer Group.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--Check for unique PlantWasherNo.
IF	EXISTS		(	SELECT	1
					FROM	[TCD].Washer				W
					JOIN	[TCD].MachineSetup			MS
						ON	W.WasherId					=			MS.WasherId
						AND	W.EcoLabAccountNumber		=			MS.EcoalabAccountNumber
					WHERE	W.EcoLabAccountNumber		=			@EcoLabAccountNumber
						AND	(
							W.PlantWasherNumber			=			@PlantWasherNumber							
							)
						AND	W.Is_Deleted				=			'FALSE'
						AND	MS.IsDeleted				=			'FALSE'
				)
			BEGIN
				SET		@ErrorId						=			51002
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Specified Plant Washer #/ already exists.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--Check that it's a valid Controller type/model (one that can control a Tunnel)

EXEC @ControllerValidate = [TCD].[ValidateController] 2,@ControllerId,@EcoLabAccountNumber

IF(@ControllerValidate = 1)
				
			BEGIN
				SET		@ErrorId						=			51003
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller was provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--EOF should not be an asocciated formula for the WG...
IF	EXISTS		(	SELECT	1
					FROM	[TCD].TunnelProgramSetup	TPS
					WHERE	TPS.EcolabAccountNumber		=			@EcoLabAccountNumber
						AND	TPS.WasherGroupId			=			@WasherGroupId
						AND	TPS.ProgramNumber			=			@ProgramNumber
						AND	TPS.Is_Deleted				=			'FALSE'
				)
			BEGIN
				SET		@ErrorId						=			51004
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An associated formula cannot be specified as End-Of-Formula.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--WasherMode check
IF	NOT	EXISTS	(	SELECT	1
					FROM	[TCD].ControllerModelControllerTypeMapping
														CMCTM
					JOIN	[TCD].ConduitController		CC
						ON	CC.ControllerTypeId			=			CMCTM.ControllerTypeId
						AND	CC.ControllerModelId		=			CMCTM.ControllerModelId
					JOIN	[TCD].[WasherModeMapping]	CTM2WM
						ON	CMCTM.Id					=			CTM2WM.ControllerModelControllerTypeMappingId
					WHERE	CC.EcoalabAccountNumber		=			@EcoLabAccountNumber
						AND	CC.ControllerId				=			@ControllerId
						AND	CC.IsDeleted				=			'FALSE'
						AND	CMCTM.MaxtunnelCount > 0
						AND	CTM2WM.WasherModeId			=			@WasherMode
				)
			BEGIN
				SET		@ErrorId						=			51005
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherMode was provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--select the WasherModelId based on name
SELECT	TOP	1
		@WasherModelId						=			WMS.WasherModelId
FROM	[TCD].WasherModelSize				WMS
WHERE	WMS.RegionId						=			@RegionId
	AND	WMS.WasherModelName					=			@WasherModelName
	AND	WMS.ModelTypeId						=			2							--TypeId 2 for Tunnel
	AND	WMS.Is_Deleted						=			'FALSE'

--LFSWasherNumber duplicate check...
IF	EXISTS	(	SELECT	1
				FROM	[TCD].MachineSetup					MS
				WHERE	MS.ControllerId					=			@ControllerId
					AND	MS.MachineInternalId			=			@LFSWasherNumber
					AND MS.EcoalabAccountNumber			=			@EcoLabAccountNumber
					AND	MS.IsDeleted					=			'FALSE'
					AND MS.IsTunnel						=			'TRUE'
			)
			BEGIN
				SET		@ErrorId						=			51010
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate LFSWasher# provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET		@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END
IF(@ControllerModelId NOT IN (7,8,9,10,11,14))
BEGIN 
--ETechWasherNumber duplicate check...
IF EXISTS ( SELECT 1
    FROM [TCD].Washer  AS W
    JOIN [TCD].MachineSetup AS MS ON MS.WasherId = W.WasherId 
    where W.ETechWasherNumber = @ETechWasherNumber
	 AND  MS.IsTunnel                    =            'TRUE'
)  
BEGIN  

SET  @ErrorId      =   51010  
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate ETechWasherNumber# provided.'  
--GOTO ErrorHandler  
RAISERROR (@ErrorMessage, 16, 1)  
SET  @ReturnValue = -1  
RETURN (@ReturnValue)  
END
END
--Now attempt to insert a new row for the tunnel record being created...
BEGIN	TRAN
IF(@ControllerModelId IS NOT NULL AND @ControllerModelId = 7 )
BEGIN
INSERT	[TCD].Washer	(
		 MyServiceCustMchGuid
		,EcoLabAccountNumber
		,PlantWasherNumber
		,ModelId
		,WasherMode
		,MaxLoad
		,[Description]
		,Is_Deleted
		,LastModifiedByUserId
		,NumberOfTanks
		,TransferType
		,PressExtractor
	--Adding for integration with Synch./Central
		,LastModifiedTime
		,EmptyPocketNumber
		,NumberOfCompartmentsConveyorBelt
		,MinMachineLoad
		,MaxMachineLoad
		,ProgramSelectionByTime
		,WeightSelectionByTime
		,WeightSelectionByAnalogInput
		,TunInTomMode
		,SignalStopTunActive
		,SignalEjectionTunActive
		,DelayTimeForTunWashingPrograms
		,KannegiesserPressSpecialMode
		,ValveOutputsUsedAsTomSignal
		,ExtendedClockOrDataProtocol
		,WeightCorrectionFcc
		,AWEActive
		,EndOfFormula
		,ETechWasherNumber
	)
SELECT @MyServiceWasherId					AS			MyServiceWasherId	
	,	@EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	@PlantWasherNumber					AS			PlantWasherNumber
	,	@WasherModelId						AS			ModelId
	--,	@Size							AS			Size
	,	@WasherMode						AS			WasherMode
	,	@MaxLoad							AS			MaxLoad
	,	@Description						AS			[Description]
	,	'FALSE'							AS			Is_Deleted
	,	@UserId							AS			LastModifiedByUserId
	,	@NumberOfTanks						AS			NumberOfTanks
	,	@TransferType						AS			TransferType
	,	@PressExtractor					AS			PressExtractor
	,	@CurrentUTCTime					AS			LastModifiedTime
	,	@ProgramNumber						AS			ProgramNumber
	,   @NumberOfCompartmentsConveyorBelt		AS			NumberOfCompartmentsConveyorBelt
	,   @MinMachineLoad						AS			MinMachineLoad
	,   @MaxMachineLoad						AS			MaxMachineLoad
	,   @ProgramSelectionByTime				AS			ProgramSelectionByTime
	,   @WeightSelectionByTime				AS			WeightSelectionByTime
	,   @WeightSelectionByAnalogInput			AS			WeightSelectionByAnalogInput
	,   @TunInTomMode						AS			TunInTomMode
	,   @SignalStopTunActive					AS			SignalStopTunActive
	,   @SignalEjectionTunActive	  			AS			SignalEjectionTunActive
	,   @DelayTimeForTunWashingPrograms		AS			DelayTimeForTunWashingPrograms
	,   @KannegiesserPressSpecialMode			AS			KannegiesserPressSpecialMode
	,   @ValveOutputsUsedAsTomSignal			AS			ValveOutputsUsedAsTomSignal
	,   @ExtendedClockOrDataProtocol			AS			ExtendedClockOrDataProtocol
	,   @WeightCorrectionFcc					AS			WeightCorrectionFcc
	,	'FALSE'							AS			AWEActive
	,	0								AS			EndOfFormula
	,   @ETechWasherNumber			AS			ETechWasherNumber
END
ELSE IF(@ControllerModelId IS NOT NULL AND ( @ControllerModelId = 8	OR @ControllerModelId = 9	OR @ControllerModelId = 10 OR @ControllerModelId = 11 OR @ControllerModelId = 14))
BEGIN
INSERT	[TCD].Washer	(
		 MyServiceCustMchGuid
		,EcoLabAccountNumber
		,PlantWasherNumber
		,ModelId
		,WasherMode
		,MaxLoad
		,[Description]
		,Is_Deleted
		,LastModifiedByUserId
		,NumberOfTanks
		,TransferType
		,PressExtractor
	--Adding for integration with Synch./Central
		,LastModifiedTime
		,EmptyPocketNumber
		,NumberOfCompartmentsConveyorBelt
		,MinMachineLoad
		,MaxMachineLoad
		,ProgramSelectionByTime
		,WeightSelectionByTime
		,WeightSelectionByAnalogInput
		,TunInTomMode
		,SignalStopTunActive
		,SignalEjectionTunActive
		,DelayTimeForTunWashingPrograms
		,KannegiesserPressSpecialMode
		,ValveOutputsUsedAsTomSignal
		,ExtendedClockOrDataProtocol
		,WeightCorrectionFcc
		,AWEActive
		,EndOfFormula
		,AutoRinseDesamixAfter
		,AutoRinseDesamix1For
		,AutoRinseDesamix2For
		,TemperatureAlarmProbe1
		,TemperatureAlarmProbe2
		,TemperatureAlarmProbe3
		,DateAndTimeWhenBatchEjects
		,ETechWasherNumber

	)
SELECT @MyServiceWasherId					AS			MyServiceWasherId	
	,	@EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	@PlantWasherNumber					AS			PlantWasherNumber
	,	@WasherModelId						AS			ModelId
	--,	@Size							AS			Size
	,	@WasherMode						AS			WasherMode
	,	@MaxLoad							AS			MaxLoad
	,	@Description						AS			[Description]
	,	'FALSE'							AS			Is_Deleted
	,	@UserId							AS			LastModifiedByUserId
	,	@NumberOfTanks						AS			NumberOfTanks
	,	@TransferType						AS			TransferType
	,	@PressExtractor					AS			PressExtractor
	,	@CurrentUTCTime					AS			LastModifiedTime
	,	@ProgramNumber						AS			ProgramNumber
	,   @NumberOfCompartmentsConveyorBelt		AS			NumberOfCompartmentsConveyorBelt
	,   @MinMachineLoad						AS			MinMachineLoad
	,   @MaxMachineLoad						AS			MaxMachineLoad
	,   @ProgramSelectionByTime				AS			ProgramSelectionByTime
	,   @WeightSelectionByTime				AS			WeightSelectionByTime
	,   @WeightSelectionByAnalogInput			AS			WeightSelectionByAnalogInput
	,   @TunInTomMode						AS			TunInTomMode
	,   @SignalStopTunActive					AS			SignalStopTunActive
	,   @SignalEjectionTunActive	  			AS			SignalEjectionTunActive
	,   @DelayTimeForTunWashingPrograms		AS			DelayTimeForTunWashingPrograms
	,   @KannegiesserPressSpecialMode			AS			KannegiesserPressSpecialMode
	,   @ValveOutputsUsedAsTomSignal			AS			ValveOutputsUsedAsTomSignal
	,   @ExtendedClockOrDataProtocol			AS			ExtendedClockOrDataProtocol
	,   @WeightCorrectionFcc					AS			WeightCorrectionFcc
	,	'FALSE'							AS			AWEActive
	,	0								AS			EndOfFormula
	,	@AutoRinseDesamixAfter
	,	@AutoRinseDesamix1For
	,	@AutoRinseDesamix2For
	,	@TemperatureAlarmProbe1
	,	@TemperatureAlarmProbe2
	,	@TemperatureAlarmProbe3
	,	@DateAndTimeWhenBatchEjects
	,   @ETechWasherNumber						AS			ETechWasherNumber
END
ELSE
BEGIN
INSERT	[TCD].Washer	(
		MyServiceCustMchGuid
		,EcoLabAccountNumber
		,PlantWasherNumber
		,ModelId
		,WasherMode
		,MaxLoad
		,AWEActive
		,EndOfFormula
		,[Description]
		,Is_Deleted
		,LastModifiedByUserId
		,NumberOfTanks
		,TransferType
		,PressExtractor
	--Adding for integration with Synch./Central
		,LastModifiedTime
		,RatioDosingActive
		,EmptyPocketNumber
	)
SELECT @MyServiceWasherId					AS			MyServiceWasherId	
	,	@EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	@PlantWasherNumber					AS			PlantWasherNumber
	,	@WasherModelId						AS			ModelId
	--,	@Size							AS			Size
	,	@WasherMode						AS			WasherMode
	,	@MaxLoad							AS			MaxLoad
	,	@AWEActive						AS			AWEActive
	,	@EndOfFormula						AS			EndOfFormula
	,	@Description						AS			[Description]
	,	'FALSE'							AS			Is_Deleted
	,	@UserId							AS			LastModifiedByUserId
	,	@NumberOfTanks						AS			NumberOfTanks
	,	@TransferType						AS			TransferType
	,	@PressExtractor					AS			PressExtractor
	,	@CurrentUTCTime					AS			LastModifiedTime
	,   @RatioDosingActive					AS			RatioDosingActive
	,	@ProgramNumber						AS			ProgramNumber 	
END

SET	@ErrorId	=	@@ERROR
	
IF	(@ErrorId	<>	0)
	BEGIN
			IF	@@TRANCOUNT	>	0
			BEGIN
				ROLLBACK	TRAN
			END

			SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred creating new record for tunnel.'
			--GOTO	ErrorHandler
			RAISERROR	(@ErrorMessage, 16, 1)
			SET	@ReturnValue	=	-1
			RETURN	(@ReturnValue)
	END

--if no error, collect the id of the newly generated row...
SELECT	@WasherId	=	SCOPE_IDENTITY()


--insert in MachineSetup
INSERT	[TCD].MachineSetup	(
		WasherId	,GroupId	,MachineInternalId	,EcoalabAccountNumber	,MachineName	,IsTunnel	,ControllerId	,NumberOfComp	,IsDeleted	,LastModifiedByUserId	)
SELECT	@WasherId					AS			WasherId
	,	@WasherGroupId				AS			GroupId
	,	@LFSWasherNumber			AS			MachineInternalId
	,	@EcoLabAccountNumber		AS			EcoalabAccountNumber
	,	@TunnelName					AS			MachineName
	,	'TRUE'						AS			IsTunnel
	,	@ControllerId				AS			ControllerId
	,	@NumberOfComp				AS			NumberOfComp
	,	'FALSE'						AS			IsDeleted
	,	@UserId						AS			LastModifiedByUserId

SET	@ErrorId	=	@@ERROR

IF	(@ErrorId	<>	0)
	BEGIN
			IF	@@TRANCOUNT	>	0
			BEGIN
				ROLLBACK	TRAN
			END

			SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred assoicating new record for tunnel.'
			--GOTO	ErrorHandler
			RAISERROR	(@ErrorMessage, 16, 1)
			SET	@ReturnValue	=	-1
			RETURN	(@ReturnValue)
	END
ELSE
	BEGIN
			IF	@@TRANCOUNT	>	0
			BEGIN
				COMMIT
			END

			--SET the output param to be communicated back...
			SET	@OutputTunnelId	=	@WasherId
	END



--IF	(	@ErrorId	=	0	)
--	BEGIN
--		--GOTO	ExitModule
--		RETURN	(@ReturnValue)
--	END




--ErrorHandler:
--RAISERROR	(@ErrorMessage, 16, 1)
--SET	@ReturnValue	=	-1




--ExitModule:

SET	NOCOUNT	OFF
RETURN	(@ReturnValue)


END
GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetPlantUtilityDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetPlantUtilityDetails
	END
GO 

CREATE PROCEDURE [TCD].[GetPlantUtilityDetails] 
(
@EcolabAccountNumber VARCHAR(100)
)
AS
BEGIN
    SET NOCOUNT ON
IF EXISTS (

SELECT s.* FROM tempdb.sys.sysobjects s WHERE s.xtype IN ('U') AND(s.id=object_id(N'tempdb..#tmpWaterTypesUsed') OR s.id=object_id(N'tempdb..#tmpGasOilTypes'))
)
BEGIN
DROP TABLE #tmpGasOilTypes;
DROP TABLE #tmpWaterTypesUsed;

END

CREATE TABLE #tmpWaterTypesUsed
(
  WaterType INT
 ,WasherMode VARCHAR(1000)
 
)
INSERT INTO #tmpWaterTypesUsed(WaterType,WasherMode)

(SELECT wds.WaterType,'Washer'AS WasherMode FROM TCD.WasherDosingSetup wds WHERE wds.WaterType>0 AND wds.Is_Deleted=0
UNION
SELECT tds.WaterType,'Tunnel'AS WasherMode FROM TCD.TunnelDosingSetup tds WHERE tds.WaterType>0 AND tds.Is_Deleted=0)


    DECLARE @RegionId INT,
    @UsageKey VARCHAR(100)
    SELECT @RegionId=P.RegionID FROM TCD.Plant P WHERE P.EcolabAccountNumber=@EcolabAccountNumber

	CREATE TABLE #tmpGasOilTypes
(
  GasOilType  VARCHAR(100)
 ,EnergyContent DECIMAL(18,4)
 ,UsageKey VARCHAR(100)
 
)
INSERT INTO #tmpGasOilTypes(GasOilType,EnergyContent,UsageKey)
(SELECT gtm.Name,gotm.DefaultValue,gtm.UsageKey	FROM TCD.GasoilTypeMaster gtm 
		INNER JOIN TCD.GasOilTypeMapping gotm	ON gtm.GasoilId=gotm.GasOilId
		WHERE gtm.GasoilId=(SELECT eud.GasOilTypeId FROM TCD.EnergyUtilityDetails eud WHERE eud.EcolabAccountNumber=@EcolabAccountNumber) AND gotm.RegionId=@RegionId)



SELECT distinct @UsageKey=rkv.[Value]
			FROM TCD.DimensionalSubunits ds
			INNER JOIN 			tcd.DimensionalUnits du ON du.Unit = ds.Unit
			INNER JOIN 			TCD.DimensionalUsageKey duk ON duk.Unit = ds.Unit
			INNER JOIN			TCD.DimensionalUnitsDefaults dud ON dud.UsageKey = duk.UsageKey
			INNER JOIN			TCD.ResourceKeyMaster rkm ON rkm.[KeyName]	= dud.Subunit
			INNER JOIN			tcd.ResourceKeyValue rkv ON rkv.[KeyName]=rkm.[KeyName]
			WHERE				duk.UsageKey = (SELECT UsageKey FROM #tmpGasOilTypes tgot)collate Latin1_General_CI_AI
							AND dud.UnitSystemId=(SELECT p.UOMId FROM TCD.Plant p WHERE p.EcolabAccountNumber=@EcolabAccountNumber)




    SELECT  wu.EcolabAccountNumber		AS	   EcolabAccountNumber,
		 wu.WaterFactorTypeId		AS	   WaterFactorTypeId,

		 CASE
		  WHEN wu.WaterFactorTypeId<>0    THEN (SELECT wt.Name FROM TCD.WaterType wt WHERE wt.Id=wu.WaterFactorTypeId) 
		  WHEN wu.WaterFactorTypeId=0	    THEN CONVERT(varchar(350), wu.WaterFactorTypeId) END AS FactorType,
		 					
		 wu.Temperature			AS	   Temperature,
		 wu.Price					AS	   Price,
		 eu.GasOilTypeId			AS	   GasOilTypeId,
		 (SELECT GasOilType FROM #tmpGasOilTypes tgot) AS GasOilType,
		 (SELECT EnergyContent FROM #tmpGasOilTypes tgot) AS EnergyContent,
		 @UsageKey				AS	   EnergyContentUnit,
		 eu.EnergyPrice			AS	   EnergyPrice,
		 eu.EnergySubUnit			AS	   EnergyPriceUnit,
		 eu.ElectricPrice			AS	   ElectricPrice,
		 eu.BolierSteam			AS	   BoilerSteam,
		 eu.BolierType				AS	   BoilerType,
		 eu.Steam					AS	   Steam,
		 eu.Boiler				AS	   Boiler,
		 eu.Stack					AS	   Stack,
		 eu.RewashFactor			AS	   RewashFactor,
		 eu.EvaporationFactor		AS	   EvaporationFactor,
		 
		 CASE 
		  WHEN wu.WaterFactorTypeId<>0 THEN (SELECT wt.MyServiceUtilTypeCode from TCD.WaterType wt WHERE wt.Id=wu.WaterFactorTypeId) 
		  WHEN wu.WaterFactorTypeId=0	 THEN 'V' END AS FreeType,
		  CASE 	
		  WHEN (SELECT COUNT(*) FROM #tmpWaterTypesUsed twtu INNER JOIN TCD.Watertype wt ON twtu.WaterType=wt.Id AND wt.MyServiceUtilTypeCode='V' WHERE twtu.WaterType=wu.WaterFactorTypeId)>0 THEN  'TRUE'

		  WHEN (SELECT COUNT(*) FROM #tmpWaterTypesUsed twtu INNER JOIN TCD.Watertype wt ON twtu.WaterType=wt.Id AND wt.MyServiceUtilTypeCode='V' WHERE twtu.WaterType=wu.WaterFactorTypeId)=0 THEN 'FALSE' END AS IsFactorUsed,
		  eu.LastModifiedTime,
		  wu.MyServiceWtrFctrId,
		  wu.MyServiceLastSyncTime,
		  wu.WaterUtilityDetailsId

	 FROM TCD.WaterUtilityDetails wu
		 INNER JOIN
		 TCD.EnergyUtilityDetails eu ON eu.EcolabAccountNumber = wu.EcolabAccountNumber
	 WHERE wu.EcolabAccountNumber = @EcolabAccountNumber 
	 ORDER BY wu.WaterUtilityDetailsId
    SET NOCOUNT OFF
END
GO


 --Update Display order for Allen Bradley 
UPDATE TCD.Field
	SET 
		DisplayOrder = 5
	WHERE Id IN(SELECT 
				F.ID
			FROM tcd.FieldGroupFieldMapping AS FGM
				INNER JOIN tcd.FieldGroup fg ON FGM.FieldGroupId = fg.Id
				INNER JOIN TCD.Field f ON FGM.FieldId = f.ID
			WHERE fg.ControllerTypeId IN (SELECT 
						Id 
					FROM TCD.ControllerType 
					WHERE Name LIKE 'Allen Bradley')
						AND f.Label LIKE '%OPC%')

UPDATE TCD.Field
	SET 
		DisplayOrder = 7
	WHERE Id IN(SELECT 
				f.id
			FROM tcd.FieldGroupFieldMapping AS FGM
				INNER JOIN tcd.FieldGroup fg ON FGM.FieldGroupId = fg.Id
				INNER JOIN TCD.Field f ON FGM.FieldId = f.ID
			WHERE fg.ControllerTypeId IN (SELECT 
						Id 
					FROM TCD.ControllerType 
					WHERE Name LIKE 'Allen Bradley')
				AND f.Label LIKE '%SERIALNUMBER%')

UPDATE TCD.Field
	SET 
		DisplayOrder = 9
	WHERE Id IN(SELECT 
				f.ID
			FROM tcd.FieldGroupFieldMapping AS FGM
				INNER JOIN tcd.FieldGroup fg ON FGM.FieldGroupId = fg.Id
				INNER JOIN TCD.Field f ON FGM.FieldId = f.ID
			WHERE fg.ControllerTypeId IN (SELECT 
						Id 
					FROM TCD.ControllerType 
					WHERE Name LIKE 'Allen Bradley')
				AND f.Label LIKE '%Webport Ftp Enabled%')

UPDATE TCD.Field
	SET
		DisplayOrder = 13
	WHERE Id IN(SELECT 
				f.ID
			FROM tcd.FieldGroupFieldMapping AS FGM
				INNER JOIN tcd.FieldGroup fg ON FGM.FieldGroupId = fg.Id
				INNER JOIN TCD.Field f ON FGM.FieldId = f.ID
			WHERE fg.ControllerTypeId IN (SELECT 
						Id
					FROM TCD.ControllerType 
					WHERE Name LIKE 'Allen Bradley')
				AND f.Label LIKE '%Webport Login%')
UPDATE TCD.Field
	SET 
		DisplayOrder = 14
	WHERE Id IN(SELECT 
				f.id
			FROM tcd.FieldGroupFieldMapping AS FGM
				INNER JOIN tcd.FieldGroup fg ON FGM.FieldGroupId = fg.Id
				INNER JOIN TCD.Field f ON FGM.FieldId = f.ID
			WHERE fg.ControllerTypeId IN (SELECT 
						Id 
					FROM TCD.ControllerType 
					WHERE Name LIKE 'Allen Bradley')
				AND f.Label LIKE '%Webport Password%')
GO
------------------------------
IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetProductWasherGroups]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetProductWasherGroups
	END
GO 

CREATE PROCEDURE [TCD].[GetProductWasherGroups]
 (
	@EcolabAccountNumber VARCHAR(100)
 )
AS 
  BEGIN      
	 SET NOCOUNT ON
	  SELECT MG.Id,Mg.GroupDescription
      FROM   [TCD].MachineGroup MG
	  INNER JOIN [TCD].MachineSetup  AS MS  ON MG.Id = Ms.GroupId
	  INNER JOIN TCD.Washer w ON w.WasherId = Ms.WasherId
	   WHERE MG.GroupTypeId = 2 AND MG.EcolabAccountNumber = @EcolabAccountNumber AND MG.Is_Deleted <> 1 
	   AND MS.IsDeleted = 0     		
		AND MS.ControllerId = 0
		AND W.WasherMode = 0
		GROUP BY MG.Id,Mg.GroupDescription
  SET NOCOUNT OFF
  END 
  GO

  IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[UpdateMyServicePlantDetails]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.UpdateMyServicePlantDetails
	END
GO  
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*

Stored Procedure	:	[TCD].[UpdateMyServicePlantDetails]

Purpose				:	To update my service plant details in conduit

Parameters			:	@EcolabAccountNumber	 
						@Name					
						@DataLiveTime			
						@BudgetCustomer			
						@ExportPath				
						@LanguageId				
						@CurrencyCode			
						@PlantCategoryId		
						@AcutalIsTarget			
						@PlantChainId			
						@TMName					
						@TMPhoneNumber			
						@DMName					
						@DMPhoneNumber			
						@ChainUnitNumber		
						@CensusPriceKg			
						@Remarks				
						@Rate					
						@UserID					
						@AllowManualRewash		
						@MyServiceCustGuid		
						@RegionCode	
						@RegionId			
						@IsDelete				
						@UOMDesc
						@UOMId				
*/

CREATE PROCEDURE [TCD].[UpdateMyServicePlantDetails]
					@EcolabAccountNumber					NVARCHAR(1000)
				,	@Name									NVARCHAR(150)
				,	@DataLiveTime							INT					=	NULL
				,	@BudgetCustomer							BIT					=	NULL
				,	@ExportPath								NVARCHAR(250)		=	NULL
				,	@LanguageId								INT					=	NULL
				,	@CurrencyCode							NVARCHAR(255)		=	NULL
				,	@PlantCategoryId						INT					=	NULL
				,	@AcutalIsTarget							BIT					=	NULL
				,	@PlantChainId							INT					=	NULL
				,	@TMName									NVARCHAR(1000)		=	NULL
				,	@TMPhoneNumber							NVARCHAR(100)		=	NULL
				,	@DMName									NVARCHAR(1000)		=	NULL
				,	@DMPhoneNumber							NVARCHAR(100)		=	NULL
				,	@ChainUnitNumber						NVARCHAR(100)		=	NULL
				,	@CensusPriceKg							NUMERIC(12, 4)		=	NULL
				,	@Remarks								NVARCHAR(1000)		=	NULL
				,	@Rate									INT					=	NULL
				,	@UserID									INT					=	NULL
				,	@AllowManualRewash						BIT					=	NULL
				,	@MyServiceCustGuid						UNIQUEIDENTIFIER	=	NULL
				,	@RegionCode								NVARCHAR(100)		=	NULL
				,	@RegionId								INT					=	NULL
				,	@IsDelete								BIT					=	NULL
				,	@UOMDesc								NVARCHAR(100)		=	NULL
				,	@UOMId									INT					=	NULL
				,	@PlantContractNumber					NVARCHAR(10)		=	NULL
				,	@PlantId								INT					=	NULL
				,	@DayId									INT					=	NULL
				,	@StartTime								TIME(7)				=	NULL
				,	@IsEtechEnable							BIT					=	NULL
				,	@EtechIpAddress							NVARCHAR(25)		=	NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

DECLARE		@CurrentUtcTime DATETIME	=	GETUTCDATE()
		,	@ErrorId		INT			=	0

IF NOT	EXISTS (SELECT 1 FROM TCD.Plant WHERE EcolabAccountNumber = @EcolabAccountNumber)
	BEGIN
	SET  Identity_Insert tcd.USERMASTER  On
		IF NOT EXISTS (SELECT 1 FROM TCD.UserMaster WHERE UserId = 0)
			
			BEGIN
				
				INSERT INTO [TCD].[UserMaster] ([UserId], [FirstName], [LastName], [FullName], [LoginName], [Password], [Phone], [LanguageId], [UOMId], [Email], [IsActive],
				[LastLoggedIn],[LastModifiedByUserId],[EcolabAccountNumber])
				VALUES (0, N'Default', N'User', N'Default Test', N'Default', N'baloce', N'123456789', 1, 1, N'default@ecolab.com', 0,
				CAST(0x0000A3AB00263AAB AS DateTime),0,@EcolabAccountNumber)
				
				SET @ErrorId = @@ERROR

				IF @ErrorId = 0
					BEGIN
						INSERT INTO [TCD].[UserInRole] ([EcoLabAccountNumber],[UserId],[RoleId],IsDeleted,[LastModifiedByUserId]) 
						VALUES  (@EcolabAccountNumber,0,4,1,0)

						INSERT INTO [TCD].[UserProfile] ([UserId],[EcolabAccountNumber],[LastModifiedByUserId])
						VALUES (0,@EcolabAccountNumber,0)

					SET @ErrorId = @@ERROR
					END
			END
			
		ELSE
			BEGIN
				UPDATE [TCD].[UserMaster]
					SET [Password] = N'baloce',
					EcolabAccountNumber = @EcolabAccountNumber 
				WHERE UserId = 0
			END

		IF NOT EXISTS (SELECT 1 FROM TCD.UserMaster WHERE UserId = 1)
			BEGIN
				INSERT INTO [TCD].[UserMaster] ([UserId], [FirstName], [LastName], [FullName], [LoginName], [Password], [Phone], [LanguageId], [UOMId], [Email], [IsActive],
				[LastLoggedIn],[LastModifiedByUserId],[EcolabAccountNumber])
				VALUES (1, N'Adminstrator', N'User', N'Adminstrator User', N'Admin', N'baloce', N'123456789', 1, 1, N'Admin@ecolab.com', 1,
						CAST(0x0000A3AB00263AAB AS DateTime),0,@EcolabAccountNumber)
				
				SET @ErrorId = @@ERROR

				IF @ErrorId = 0
					BEGIN
						INSERT INTO [TCD].[UserInRole] ([EcoLabAccountNumber],[UserId],[RoleId],IsDeleted,[LastModifiedByUserId]) 
						VALUES  (@EcolabAccountNumber,1,4,0,0)

						INSERT INTO [TCD].[UserProfile] ([UserId],[EcolabAccountNumber],[LastModifiedByUserId])
						VALUES (1,@EcolabAccountNumber,0)
					SET @ErrorId = @@ERROR
					END
			END
		ELSE
			BEGIN
				UPDATE [TCD].[UserMaster]
					SET [Password] = N'baloce',
					EcolabAccountNumber = @EcolabAccountNumber
				WHERE UserId = 1
			END
SET  Identity_Insert tcd.UserMaster Off

			INSERT INTO [TCD].[Plant]
				   ([PlantId]
				   ,[EcolabAccountNumber]
				   ,[Name]
				   ,[DataLiveTime]
				   ,[BudgetCustomer]
				   ,[ExportPath]
				   ,[LanguageId]
				   ,[UOMId]
				   ,[CurrencyCode]
				   ,[PlantCategoryId]
				   ,[AcutalIsTarget]
				   ,[RegionId]
				   ,[PlantChainId]
				   ,[CreatedOn]
				   ,[CreatedBy]
				   ,[ModifiedOn]
				   ,[ModifiedBy]
				   ,[TMName]
				   ,[TMPhoneNumber]
				   ,[DMName]
				   ,[DMPhoneNumber]
				   ,[ChainUnitNumber]
				   ,[CensusPriceKg]
				   ,[Remarks]
				   ,[Rate]
				   ,[Is_Deleted]
				   ,[LastModifiedByUserId]
				   ,[AllowManualRewash]
				   ,[LastModifiedTime]
				   ,[MyServiceCustGuid]
				   ,[MyServiceLastSynchTime]
				   ,[PlantContractNumber]
				   ,[ConStdTurnTime]
				   ,[DayId]
				   ,[StartTime]
				   ,[IsETechEnable]
				   ,[ETechIpAddress])
		 VALUES
			   (@PlantId
			   ,@EcolabAccountNumber
			   ,@Name
			   ,@DataLiveTime
			   ,@BudgetCustomer
			   ,@ExportPath
			   ,@LanguageId
			   ,@UOMId
			   ,@CurrencyCode
			   ,@PlantCategoryId
			   ,@AcutalIsTarget
			   ,@RegionId
			   ,@PlantChainId
			   ,@CurrentUtcTime
			   ,@UserId
			   ,@CurrentUtcTime
			   ,@UserId
			   ,@TMName
			   ,@TMPhoneNumber
			   ,@DMName
			   ,@DMPhoneNumber
			   ,@ChainUnitNumber
			   ,@CensusPriceKg
			   ,@Remarks
			   ,@Rate
			   ,@IsDelete
			   ,@UserId
			   ,@AllowManualRewash
			   ,@CurrentUtcTime
			   ,@MyServiceCustGuid
			   ,@CurrentUtcTime
			   ,@PlantContractNumber
			   ,30
			   ,@DayId 
               ,@StartTime
               ,@IsEtechEnable
               ,@EtechIpAddress
			   )

		SET @ErrorId = @@ERROR
	END
ELSE
	BEGIN 
		UPDATE [TCD].[Plant]
		SET 
		   [Name]					=	@Name
		  ,[TMName]					=	@TMName
		  ,[TMPhoneNumber]			=	@TMPhoneNumber
		  ,[DMName]					=	@DMName
		  ,[DMPhoneNumber]			=	@DMPhoneNumber
		  ,[ChainUnitNumber]		=	@ChainUnitNumber
		  ,[CensusPriceKg]			=	@CensusPriceKg
		  ,[Remarks]				=	@Remarks
		  ,[LanguageId]				=	@LanguageId
		  ,[CurrencyCode]			=	@CurrencyCode
		  ,[RegionId]				=	@RegionId
		  ,[UOMId]					=	@UOMId
		  ,[PlantChainId]			=	@PlantChainId
		  ,[Is_Deleted]				=	@IsDelete
		  ,[MyServiceCustGuid]		=	@MyServiceCustGuid
		  ,[MyServiceLastSynchTime]	=	@CurrentUtcTime
		  ,[PlantContractNumber]	=	@PlantContractNumber
		  ,[DayId]					=	@DayId
          ,[StartTime]				=	@StartTime
          ,[IsETechEnable]			=	@IsEtechEnable
          ,[ETechIpAddress]			=	@EtechIpAddress
		WHERE 
		   [EcolabAccountNumber]	=	@EcolabAccountNumber

		SET @ErrorId = @@ERROR
	END

SELECT @ErrorId
END
GO

 IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[AddTunnel]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.AddTunnel
	END
GO  

CREATE PROCEDURE	[TCD].[AddTunnel]	
					@MyServiceWasherId						UniqueIdentifier
				,	@EcoLabAccountNumber					NVARCHAR(1000)
				,	@WasherGroupId							INT
				,	@TunnelName								NVARCHAR(50)
				,	@WasherModelName						NVARCHAR(50)
				,	@RegionId								SMALLINT
--				,	@Size									INT									--we don't need to save this; ModelId PK determines it
				,	@ControllerId							INT
				,	@LFSWasherNumber						TINYINT			=			1		--For tunnels, it will be 1 until a diff. number is passed (as per the scenario)
				,	@PlantWasherNumber						SMALLINT
				,	@WasherMode								TINYINT
				,	@MaxLoad								SMALLINT
				,	@AWEActive								BIT
				,	@NumberOfTanks							TINYINT
				,	@NumberOfComp							TINYINT								--though this is INT in the table, we should not require it to be so
				,	@TransferType							TINYINT         =			NULL
				,	@PressExtractor							TINYINT       =			NULL
				,	@ProgramNumber							TINYINT
				,	@EndOfFormula							TINYINT
				,	@Description							NVARCHAR(1024)	=			NULL
				,	@UserId									INT

				,	@OutputTunnelId							INT			OUTPUT
				--Adding as part of re-factoring for integration with Synch/Configurator... generated TunnelId (re-named) is already being OUTPUT above
				,	@OutputLastModifiedTimestampAtLocal		DATETIME		=			NULL	OUTPUT
				,   @RatioDosingActive						Bit = 'False'
				,   @ControllerModelId						INT		=		NULL
				,   @NumberOfCompartmentsConveyorBelt			TINYINT	=		NULL
				,   @MaxMachineLoad							TINYINT	=		NULL
				,   @MinMachineLoad							TINYINT	=		NULL
				,   @ProgramSelectionByTime					BIT	  	=		NULL
				,   @WeightSelectionByTime					BIT	  	=		NULL
				,   @WeightSelectionByAnalogInput				BIT	  	=		NULL
				,   @TunInTomMode							BIT	  	=		NULL
				,   @SignalStopTunActive						BIT	  	=		NULL
				,   @SignalEjectionTunActive	  				BIT	  	=		NULL
				,   @DelayTimeForTunWashingPrograms			BIT	  	=		NULL
				,   @KannegiesserPressSpecialMode				BIT	  	=		NULL
				,   @ValveOutputsUsedAsTomSignal				BIT	  	=		NULL
				,   @ExtendedClockOrDataProtocol				BIT	  	=		NULL
				,   @WeightCorrectionFcc						BIT	  	=		NULL
				,	@DateAndTimeWhenBatchEjects					BIT	  		=		NULL
				,	@AutoRinseDesamixAfter						SMALLINT	=		NULL
				,	@AutoRinseDesamix1For						SMALLINT	=		NULL
				,	@AutoRinseDesamix2For						SMALLINT	=		NULL
				,	@TemperatureAlarmProbe1						BIT			=		NULL
				,	@TemperatureAlarmProbe2						BIT			=		NULL
				,	@TemperatureAlarmProbe3						BIT			=		NULL
				,	@ETechWasherNumber						    INT			=		NULL


AS
BEGIN

SET	NOCOUNT	ON


DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''

	,	@WasherId						INT				=			NULL
	,	@WasherModelId					SMALLINT		=			NULL
	--Adding for integration with Synch./Central
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()
	,	@ControllerValidate				int				=										   0

--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
SET		@OutputLastModifiedTimestampAtLocal				=			@CurrentUTCTime
SET		@OutputTunnelId									=			ISNULL(@OutputTunnelId, NULL)			--SQLEnlight

--Check that the WasherGroup being associated-to is a valid Tunnel-type WG...
IF	NOT	EXISTS	(	SELECT	1
					FROM	[TCD].WasherGroup			WG
					JOIN	[TCD].WasherGroupType		WGT
						ON	WG.WasherGroupTypeId		=			WGT.WasherGroupTypeId
					JOIN	[TCD].MachineGroup					GT									--this is actually the Groups table and NOT really a Group TYPE
						ON	WG.WasherGroupId			=			GT.Id			--GroupTypeId is actually the Id of the Group
					WHERE	WG.WasherGroupId			=			@WasherGroupId
						AND	GT.EcolabAccountNumber		=			@EcoLabAccountNumber
						AND	GT.GroupTypeId	  			=			2			--select	GroupMaintype	from	GroupType
						AND	WGT.WasherGroupTypeName		=			'Tunnel'				--select	WasherGroupTypeName	from	WasherGroupType
				)
			BEGIN
				SET		@ErrorId						=			51001
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherGroup provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--Check for only 1 tunnel for a WasherGroup
IF	EXISTS		(	SELECT	1
					FROM	[TCD].MachineSetup			MS
					JOIN	[TCD].Washer				W
						ON	MS.WasherId					=			W.WasherId
					WHERE	MS.GroupId					=			@WasherGroupId
						AND	MS.EcoalabAccountNumber		=			@EcoLabAccountNumber
						AND	MS.IsDeleted				=			'FALSE'
						AND	MS.IsTunnel					=			'TRUE'
						AND	W.Is_Deleted				=			'FALSE'
				)
			BEGIN
				SET		@ErrorId						=			51008
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': A Tunnel has already been added to this Washer Group.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--Check for unique PlantWasherNo.
IF	EXISTS		(	SELECT	1
					FROM	[TCD].Washer				W
					JOIN	[TCD].MachineSetup			MS
						ON	W.WasherId					=			MS.WasherId
						AND	W.EcoLabAccountNumber		=			MS.EcoalabAccountNumber
					WHERE	W.EcoLabAccountNumber		=			@EcoLabAccountNumber
						AND	(
							W.PlantWasherNumber			=			@PlantWasherNumber							
							)
						AND	W.Is_Deleted				=			'FALSE'
						AND	MS.IsDeleted				=			'FALSE'
				)
			BEGIN
				SET		@ErrorId						=			51002
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Specified Plant Washer #/ already exists.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--Check that it's a valid Controller type/model (one that can control a Tunnel)

EXEC @ControllerValidate = [TCD].[ValidateController] 2,@ControllerId,@EcoLabAccountNumber

IF(@ControllerValidate = 1)
				
			BEGIN
				SET		@ErrorId						=			51003
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller was provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--EOF should not be an asocciated formula for the WG...
IF	EXISTS		(	SELECT	1
					FROM	[TCD].TunnelProgramSetup	TPS
					WHERE	TPS.EcolabAccountNumber		=			@EcoLabAccountNumber
						AND	TPS.WasherGroupId			=			@WasherGroupId
						AND	TPS.ProgramNumber			=			@ProgramNumber
						AND	TPS.Is_Deleted				=			'FALSE'
				)
			BEGIN
				SET		@ErrorId						=			51004
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An associated formula cannot be specified as End-Of-Formula.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--WasherMode check
IF	NOT	EXISTS	(	SELECT	1
					FROM	[TCD].ControllerModelControllerTypeMapping
														CMCTM
					JOIN	[TCD].ConduitController		CC
						ON	CC.ControllerTypeId			=			CMCTM.ControllerTypeId
						AND	CC.ControllerModelId		=			CMCTM.ControllerModelId
					JOIN	[TCD].[WasherModeMapping]	CTM2WM
						ON	CMCTM.Id					=			CTM2WM.ControllerModelControllerTypeMappingId
					WHERE	CC.EcoalabAccountNumber		=			@EcoLabAccountNumber
						AND	CC.ControllerId				=			@ControllerId
						AND	CC.IsDeleted				=			'FALSE'
						AND	CMCTM.MaxtunnelCount > 0
						AND	CTM2WM.WasherModeId			=			@WasherMode
				)
			BEGIN
				SET		@ErrorId						=			51005
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherMode was provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--select the WasherModelId based on name
SELECT	TOP	1
		@WasherModelId						=			WMS.WasherModelId
FROM	[TCD].WasherModelSize				WMS
WHERE	WMS.RegionId						=			@RegionId
	AND	WMS.WasherModelName					=			@WasherModelName
	AND	WMS.ModelTypeId						=			2							--TypeId 2 for Tunnel
	AND	WMS.Is_Deleted						=			'FALSE'

--LFSWasherNumber duplicate check...
IF	EXISTS	(	SELECT	1
				FROM	[TCD].MachineSetup					MS
				WHERE	MS.ControllerId					=			@ControllerId
					AND	MS.MachineInternalId			=			@LFSWasherNumber
					AND MS.EcoalabAccountNumber			=			@EcoLabAccountNumber
					AND	MS.IsDeleted					=			'FALSE'
					AND MS.IsTunnel						=			'TRUE'
			)
			BEGIN
				SET		@ErrorId						=			51010
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate LFSWasher# provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET		@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END
--ETechWasherNumber duplicate check...
IF(@ControllerModelId NOT IN (7,8,9,10,11,14))
BEGIN
IF EXISTS ( SELECT 1
    FROM [TCD].Washer  AS W
    JOIN [TCD].MachineSetup AS MS ON MS.WasherId = W.WasherId 
    where W.ETechWasherNumber = @ETechWasherNumber
	 AND  MS.IsTunnel                    =            'TRUE'
)  
BEGIN  

SET  @ErrorId      =   51012  
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate ETechWasherNumber# provided.'  
--GOTO ErrorHandler  
RAISERROR (@ErrorMessage, 16, 1)  
SET  @ReturnValue = -1  
RETURN (@ReturnValue)  
END
END

--Now attempt to insert a new row for the tunnel record being created...
BEGIN	TRAN
IF(@ControllerModelId IS NOT NULL AND @ControllerModelId = 7 )
BEGIN
INSERT	[TCD].Washer	(
		 MyServiceCustMchGuid
		,EcoLabAccountNumber
		,PlantWasherNumber
		,ModelId
		,WasherMode
		,MaxLoad
		,[Description]
		,Is_Deleted
		,LastModifiedByUserId
		,NumberOfTanks
		,TransferType
		,PressExtractor
	--Adding for integration with Synch./Central
		,LastModifiedTime
		,EmptyPocketNumber
		,NumberOfCompartmentsConveyorBelt
		,MinMachineLoad
		,MaxMachineLoad
		,ProgramSelectionByTime
		,WeightSelectionByTime
		,WeightSelectionByAnalogInput
		,TunInTomMode
		,SignalStopTunActive
		,SignalEjectionTunActive
		,DelayTimeForTunWashingPrograms
		,KannegiesserPressSpecialMode
		,ValveOutputsUsedAsTomSignal
		,ExtendedClockOrDataProtocol
		,WeightCorrectionFcc
		,AWEActive
		,EndOfFormula
		,ETechWasherNumber
	)
SELECT @MyServiceWasherId					AS			MyServiceWasherId	
	,	@EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	@PlantWasherNumber					AS			PlantWasherNumber
	,	@WasherModelId						AS			ModelId
	--,	@Size							AS			Size
	,	@WasherMode						AS			WasherMode
	,	@MaxLoad							AS			MaxLoad
	,	@Description						AS			[Description]
	,	'FALSE'							AS			Is_Deleted
	,	@UserId							AS			LastModifiedByUserId
	,	@NumberOfTanks						AS			NumberOfTanks
	,	@TransferType						AS			TransferType
	,	@PressExtractor					AS			PressExtractor
	,	@CurrentUTCTime					AS			LastModifiedTime
	,	@ProgramNumber						AS			ProgramNumber
	,   @NumberOfCompartmentsConveyorBelt		AS			NumberOfCompartmentsConveyorBelt
	,   @MinMachineLoad						AS			MinMachineLoad
	,   @MaxMachineLoad						AS			MaxMachineLoad
	,   @ProgramSelectionByTime				AS			ProgramSelectionByTime
	,   @WeightSelectionByTime				AS			WeightSelectionByTime
	,   @WeightSelectionByAnalogInput			AS			WeightSelectionByAnalogInput
	,   @TunInTomMode						AS			TunInTomMode
	,   @SignalStopTunActive					AS			SignalStopTunActive
	,   @SignalEjectionTunActive	  			AS			SignalEjectionTunActive
	,   @DelayTimeForTunWashingPrograms		AS			DelayTimeForTunWashingPrograms
	,   @KannegiesserPressSpecialMode			AS			KannegiesserPressSpecialMode
	,   @ValveOutputsUsedAsTomSignal			AS			ValveOutputsUsedAsTomSignal
	,   @ExtendedClockOrDataProtocol			AS			ExtendedClockOrDataProtocol
	,   @WeightCorrectionFcc					AS			WeightCorrectionFcc
	,	'FALSE'							AS			AWEActive
	,	0								AS			EndOfFormula
	,   @ETechWasherNumber			AS			ETechWasherNumber
END
ELSE IF(@ControllerModelId IS NOT NULL AND ( @ControllerModelId = 8	OR @ControllerModelId = 9	OR @ControllerModelId = 10 OR @ControllerModelId = 11 OR @ControllerModelId = 14))
BEGIN
INSERT	[TCD].Washer	(
		 MyServiceCustMchGuid
		,EcoLabAccountNumber
		,PlantWasherNumber
		,ModelId
		,WasherMode
		,MaxLoad
		,[Description]
		,Is_Deleted
		,LastModifiedByUserId
		,NumberOfTanks
		,TransferType
		,PressExtractor
	--Adding for integration with Synch./Central
		,LastModifiedTime
		,EmptyPocketNumber
		,NumberOfCompartmentsConveyorBelt
		,MinMachineLoad
		,MaxMachineLoad
		,ProgramSelectionByTime
		,WeightSelectionByTime
		,WeightSelectionByAnalogInput
		,TunInTomMode
		,SignalStopTunActive
		,SignalEjectionTunActive
		,DelayTimeForTunWashingPrograms
		,KannegiesserPressSpecialMode
		,ValveOutputsUsedAsTomSignal
		,ExtendedClockOrDataProtocol
		,WeightCorrectionFcc
		,AWEActive
		,EndOfFormula
		,AutoRinseDesamixAfter
		,AutoRinseDesamix1For
		,AutoRinseDesamix2For
		,TemperatureAlarmProbe1
		,TemperatureAlarmProbe2
		,TemperatureAlarmProbe3
		,DateAndTimeWhenBatchEjects
		,ETechWasherNumber

	)
SELECT @MyServiceWasherId					AS			MyServiceWasherId	
	,	@EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	@PlantWasherNumber					AS			PlantWasherNumber
	,	@WasherModelId						AS			ModelId
	--,	@Size							AS			Size
	,	@WasherMode						AS			WasherMode
	,	@MaxLoad							AS			MaxLoad
	,	@Description						AS			[Description]
	,	'FALSE'							AS			Is_Deleted
	,	@UserId							AS			LastModifiedByUserId
	,	@NumberOfTanks						AS			NumberOfTanks
	,	@TransferType						AS			TransferType
	,	@PressExtractor					AS			PressExtractor
	,	@CurrentUTCTime					AS			LastModifiedTime
	,	@ProgramNumber						AS			ProgramNumber
	,   @NumberOfCompartmentsConveyorBelt		AS			NumberOfCompartmentsConveyorBelt
	,   @MinMachineLoad						AS			MinMachineLoad
	,   @MaxMachineLoad						AS			MaxMachineLoad
	,   @ProgramSelectionByTime				AS			ProgramSelectionByTime
	,   @WeightSelectionByTime				AS			WeightSelectionByTime
	,   @WeightSelectionByAnalogInput			AS			WeightSelectionByAnalogInput
	,   @TunInTomMode						AS			TunInTomMode
	,   @SignalStopTunActive					AS			SignalStopTunActive
	,   @SignalEjectionTunActive	  			AS			SignalEjectionTunActive
	,   @DelayTimeForTunWashingPrograms		AS			DelayTimeForTunWashingPrograms
	,   @KannegiesserPressSpecialMode			AS			KannegiesserPressSpecialMode
	,   @ValveOutputsUsedAsTomSignal			AS			ValveOutputsUsedAsTomSignal
	,   @ExtendedClockOrDataProtocol			AS			ExtendedClockOrDataProtocol
	,   @WeightCorrectionFcc					AS			WeightCorrectionFcc
	,	'FALSE'							AS			AWEActive
	,	0								AS			EndOfFormula
	,	@AutoRinseDesamixAfter
	,	@AutoRinseDesamix1For
	,	@AutoRinseDesamix2For
	,	@TemperatureAlarmProbe1
	,	@TemperatureAlarmProbe2
	,	@TemperatureAlarmProbe3
	,	@DateAndTimeWhenBatchEjects
	,   @ETechWasherNumber						AS			ETechWasherNumber
END
ELSE
BEGIN
INSERT	[TCD].Washer	(
		MyServiceCustMchGuid
		,EcoLabAccountNumber
		,PlantWasherNumber
		,ModelId
		,WasherMode
		,MaxLoad
		,AWEActive
		,EndOfFormula
		,[Description]
		,Is_Deleted
		,LastModifiedByUserId
		,NumberOfTanks
		,TransferType
		,PressExtractor
	--Adding for integration with Synch./Central
		,LastModifiedTime
		,RatioDosingActive
		,EmptyPocketNumber
	)
SELECT @MyServiceWasherId					AS			MyServiceWasherId	
	,	@EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	@PlantWasherNumber					AS			PlantWasherNumber
	,	@WasherModelId						AS			ModelId
	--,	@Size							AS			Size
	,	@WasherMode						AS			WasherMode
	,	@MaxLoad							AS			MaxLoad
	,	@AWEActive						AS			AWEActive
	,	@EndOfFormula						AS			EndOfFormula
	,	@Description						AS			[Description]
	,	'FALSE'							AS			Is_Deleted
	,	@UserId							AS			LastModifiedByUserId
	,	@NumberOfTanks						AS			NumberOfTanks
	,	@TransferType						AS			TransferType
	,	@PressExtractor					AS			PressExtractor
	,	@CurrentUTCTime					AS			LastModifiedTime
	,   @RatioDosingActive					AS			RatioDosingActive
	,	@ProgramNumber						AS			ProgramNumber 	
END

SET	@ErrorId	=	@@ERROR
	
IF	(@ErrorId	<>	0)
	BEGIN
			IF	@@TRANCOUNT	>	0
			BEGIN
				ROLLBACK	TRAN
			END

			SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred creating new record for tunnel.'
			--GOTO	ErrorHandler
			RAISERROR	(@ErrorMessage, 16, 1)
			SET	@ReturnValue	=	-1
			RETURN	(@ReturnValue)
	END

--if no error, collect the id of the newly generated row...
SELECT	@WasherId	=	SCOPE_IDENTITY()


--insert in MachineSetup
INSERT	[TCD].MachineSetup	(
		WasherId	,GroupId	,MachineInternalId	,EcoalabAccountNumber	,MachineName	,IsTunnel	,ControllerId	,NumberOfComp	,IsDeleted	,LastModifiedByUserId	)
SELECT	@WasherId					AS			WasherId
	,	@WasherGroupId				AS			GroupId
	,	@LFSWasherNumber			AS			MachineInternalId
	,	@EcoLabAccountNumber		AS			EcoalabAccountNumber
	,	@TunnelName					AS			MachineName
	,	'TRUE'						AS			IsTunnel
	,	@ControllerId				AS			ControllerId
	,	@NumberOfComp				AS			NumberOfComp
	,	'FALSE'						AS			IsDeleted
	,	@UserId						AS			LastModifiedByUserId

SET	@ErrorId	=	@@ERROR

IF	(@ErrorId	<>	0)
	BEGIN
			IF	@@TRANCOUNT	>	0
			BEGIN
				ROLLBACK	TRAN
			END

			SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred assoicating new record for tunnel.'
			--GOTO	ErrorHandler
			RAISERROR	(@ErrorMessage, 16, 1)
			SET	@ReturnValue	=	-1
			RETURN	(@ReturnValue)
	END
ELSE
	BEGIN
			IF	@@TRANCOUNT	>	0
			BEGIN
				COMMIT
			END

			--SET the output param to be communicated back...
			SET	@OutputTunnelId	=	@WasherId
	END



--IF	(	@ErrorId	=	0	)
--	BEGIN
--		--GOTO	ExitModule
--		RETURN	(@ReturnValue)
--	END




--ErrorHandler:
--RAISERROR	(@ErrorMessage, 16, 1)
--SET	@ReturnValue	=	-1




--ExitModule:

SET	NOCOUNT	OFF
RETURN	(@ReturnValue)


END
GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[UpdateTunnel]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.UpdateTunnel
	END
GO
CREATE	PROCEDURE    [TCD].[UpdateTunnel]
                    @EcoLabAccountNumber                    NVARCHAR(1000)
                ,    @WasherId                                INT
                ,    @WasherGroupId                            INT                                    --Not updated, for reference only
                ,    @TunnelName                            NVARCHAR(50)
                ,    @WasherModelName                        NVARCHAR(50)
                ,    @RegionId                                SMALLINT
                --,    @Size                                INT
                ,    @ControllerId                            INT
                ,    @LFSWasherNumber                        INT            =            1        --For tunnels, it will be 1 until a diff. number is passed (as per the scenario)
                ,    @PlantWasherNumber                        SMALLINT
                ,    @WasherMode                            SMALLINT
                ,    @MaxLoad                                SMALLINT
                ,    @AWEActive                            BIT
                ,    @NumberOfTanks                            TINYINT
                ,    @NumberOfComp                            INT                                --though this is INT in the table, we should not require it to be so
                ,    @TransferType                            TINYINT
                ,    @PressExtractor                        TINYINT
                ,    @ProgramNumber                            TINYINT
                ,    @EndOfFormula                            TINYINT
                ,    @Description                            NVARCHAR(1024)    =            NULL
                ,    @UserId                                INT
				--Adding these 3 params as part of re-factoring for integration with Synch/Configurator
                ,    @OutputTunnelId                        INT            =            NULL    OUTPUT
                ,    @LastModifiedTimestampAtCentral            DATETIME    =            NULL            --Nullable for local call; Synch/Central call will have to pass this -
																									--else, it will be treated as a local call
                ,    @OutputLastModifiedTimestampAtLocal        DATETIME    =            NULL    OUTPUT
                ,   @RatioDosingActive                        BIT
                ,   @ControllerModelId                        INT        =        NULL
                ,   @NumberOfCompartmentsConveyorBelt            TINYINT    =        NULL
                ,   @MaxMachineLoad                            SMALLINT    =        NULL
                ,   @MinMachineLoad                            SMALLINT    =        NULL
                ,   @ProgramSelectionByTime                    BIT          =        NULL
                ,   @WeightSelectionByTime                    BIT          =        NULL
                ,   @WeightSelectionByAnalogInput                BIT          =        NULL
                ,   @TunInTomMode                            BIT          =        NULL
                ,   @SignalStopTunActive                        BIT          =        NULL
                ,   @SignalEjectionTunActive                      BIT          =        NULL
                ,   @DelayTimeForTunWashingPrograms            BIT          =        NULL
                ,   @KannegiesserPressSpecialMode                BIT          =        NULL
                ,   @ValveOutputsUsedAsTomSignal                BIT          =        NULL
                ,   @ExtendedClockOrDataProtocol                BIT          =        NULL
                ,   @WeightCorrectionFcc                        BIT          =        NULL
				,	@DateAndTimeWhenBatchEjects					BIT	  		=		NULL
				,	@AutoRinseDesamixAfter						SMALLINT	=		NULL
				,	@AutoRinseDesamix1For						SMALLINT	=		NULL
				,	@AutoRinseDesamix2For						SMALLINT	=		NULL
				,	@TemperatureAlarmProbe1						BIT			=		NULL
				,	@TemperatureAlarmProbe2						BIT			=		NULL
				,	@TemperatureAlarmProbe3						BIT			=		NULL
				,	@UseMe1OfGroup							tinyint					=	NULL
				,	@UseMe2OfGroup							tinyint					=	NULL
				,	@ETechWasherNumber						int					=	NULL
AS
BEGIN

SET    NOCOUNT    ON


DECLARE	
        @ReturnValue                    INT                =            0
    ,    @ErrorId                        INT                =            0
    ,    @ErrorMessage                    NVARCHAR(4000)    =            N''

    ,    @WasherModelId                    SMALLINT        =            NULL

    ,    @CurrentUTCTime                    DATETIME        =            GETUTCDATE()
	,	@ControllerValidate				int				=										   0

--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
SET        @OutputLastModifiedTimestampAtLocal                =            @CurrentUTCTime
SET        @OutputTunnelId                                    =            ISNULL(@OutputTunnelId, NULL)            --SQLEnlight

--If the call is not local, check that the LastModifiedTime matches with the central
IF    (
        @LastModifiedTimestampAtCentral            IS NOT    NULL
    AND    NOT    EXISTS    (    SELECT    1
                        FROM    TCD.[Washer]            W
                        WHERE    W.EcolabAccountNumber    =    @EcolabAccountNumber
                            AND    W.WasherId                =    @WasherId
                            AND    W.LastModifiedTime        =    @LastModifiedTimestampAtCentral
					)
	)
	BEGIN
            SET            @ErrorId                    =    60000
            SET            @ErrorMessage                =    N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
            RAISERROR    (@ErrorMessage, 16, 1)
            SET            @ReturnValue                =    -1
            RETURN        (@ReturnValue)
	END

--Proceed, since it's either a local call or Synch. call with synch. time matching


--Valid Washer - based on Id...
IF    NOT    EXISTS    (    SELECT    1
                    FROM    [TCD].Washer                W
                    JOIN    [TCD].MachineSetup            MS
                        ON    W.WasherId                    =            MS.WasherId
                        AND    W.EcoLabAccountNumber        =            MS.EcoalabAccountNumber
                    WHERE    W.EcoLabAccountNumber        =            @EcoLabAccountNumber
                        AND    W.WasherId                    =            @WasherId
                        AND    MS.GroupId                    =            @WasherGroupId
                        AND    MS.IsTunnel                    =            'TRUE'
                        AND    W.Is_Deleted                =            'FALSE'
                        AND    MS.IsDeleted                =            'FALSE'
				)
			BEGIN
                SET        @ErrorId                        =            51006
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Washer-ID was provided for Updating.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET    @ReturnValue    =    -1
                RETURN    (@ReturnValue)
			END


--Check for uniqueness of PlantWasherNo. and Name
IF    EXISTS        (    SELECT    1
                    FROM    [TCD].Washer                W
                    JOIN    [TCD].MachineSetup            MS
                        ON    W.WasherId                    =            MS.WasherId
                        AND    W.EcoLabAccountNumber        =            MS.EcoalabAccountNumber
                    WHERE    W.EcoLabAccountNumber        =            @EcoLabAccountNumber
                        AND    W.WasherId                    <>            @WasherId
                        AND    (
                            W.PlantWasherNumber            =            @PlantWasherNumber
                            OR
                            MS.MachineName                =            @TunnelName
							)
                        AND    W.Is_Deleted                =            'FALSE'
                        AND    MS.IsDeleted                =            'FALSE'
				)
			BEGIN
                SET        @ErrorId                        =            51002
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Specified Plant Washer #/Name already exists.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET    @ReturnValue    =    -1
                RETURN    (@ReturnValue)
			END


--Check that it's a valid Controller type/model (one that can control a Tunnel)
IF	NOT	EXISTS	(	SELECT	1
					FROM	[TCD].ControllerModelControllerTypeMapping
														CMCTM
					JOIN	[TCD].ConduitController		CC
						ON	CC.ControllerTypeId			=			CMCTM.ControllerTypeId
						AND	CC.ControllerModelId		=			CMCTM.ControllerModelId
					WHERE	CC.EcoalabAccountNumber		=			@EcoLabAccountNumber
						AND	CC.ControllerId				=			@ControllerId
						AND	CC.IsDeleted				=			'FALSE'
						AND	CMCTM.CanControlTunnel		=			'TRUE'
				)
			BEGIN
				SET		@ErrorId						=			51003
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller was provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END

--IF  (  @ControllerValidate = 1)
--            BEGIN
--                SET        @ErrorId                        =            51003
--                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller was provided.'
--                --GOTO    ErrorHandler
--                RAISERROR    (@ErrorMessage, 16, 1)
--                SET    @ReturnValue    =    -1
--                RETURN    (@ReturnValue)
--            END


--EOF should not be an asocciated formula for the WG...
IF    EXISTS        (    SELECT    1
                    FROM    [TCD].TunnelProgramSetup    TPS
                    WHERE    TPS.EcolabAccountNumber        =            @EcoLabAccountNumber
                        AND    TPS.WasherGroupId            =            @WasherGroupId
                        AND    TPS.ProgramNumber            =            @ProgramNumber
                        AND    TPS.Is_Deleted                =            'FALSE'
				)
			BEGIN
                SET        @ErrorId                        =            51004
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An assoicated formula cannot be specified as End-Of-Formula.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET    @ReturnValue    =    -1
                RETURN    (@ReturnValue)
			END


--WasherMode check
IF    NOT    EXISTS    (    SELECT    1
                    FROM    [TCD].ControllerModelControllerTypeMapping
														CMCTM
                    JOIN    [TCD].ConduitController        CC
                        ON    CC.ControllerTypeId            =            CMCTM.ControllerTypeId
                        AND    CC.ControllerModelId        =            CMCTM.ControllerModelId
                    JOIN    [TCD].[WasherModeMapping]
														CTM2WM
                        ON    CMCTM.Id                    =            CTM2WM.ControllerModelControllerTypeMappingId
                    WHERE    CC.EcoalabAccountNumber        =            @EcoLabAccountNumber
                        AND    CC.ControllerId                =            @ControllerId
                        AND    CC.IsDeleted                =            'FALSE'
                        --AND    CMCTM.CanControlTunnel        =            'TRUE'
                        AND    CTM2WM.WasherModeId            =            @WasherMode
				)
			BEGIN
                SET        @ErrorId                        =            51005
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherMode was provided.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET    @ReturnValue    =    -1
                RETURN    (@ReturnValue)
			END


--select the WasherModelId based on name
SELECT    TOP    1
        @WasherModelId                        =            WMS.WasherModelId
FROM    [TCD].WasherModelSize                WMS
WHERE    WMS.RegionId                        =            @RegionId
    AND    WMS.WasherModelName                    =            @WasherModelName
    AND    WMS.ModelTypeId                    =            2                            --TypeId 2 for Tunnel
    AND    WMS.Is_Deleted                        =            'FALSE'

--LFSWasherNumber duplicate check...
IF    EXISTS    (    SELECT    1
                FROM    [TCD].MachineSetup                    MS
                WHERE    MS.ControllerId                    =            @ControllerId
                    AND    MS.MachineInternalId            =            @LFSWasherNumber
                    AND    MS.IsDeleted                    =            'FALSE'
                    AND    MS.WasherId                        <>            @WasherId
                    AND MS.EcoalabAccountNumber            =            @EcoLabAccountNumber
                    AND MS.IsTunnel                        =            'TRUE'
            )
            BEGIN
                SET        @ErrorId                        =            51010
                SET        @ErrorMessage                    =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate LFSWasher# provided.'
                --GOTO    ErrorHandler
                RAISERROR    (@ErrorMessage, 16, 1)
                SET        @ReturnValue    =    -1
                RETURN    (@ReturnValue)
            END
--ETechWasherNumber duplicate check...
IF(@ControllerModelId NOT IN (7,8,9,10,11,14))
BEGIN
IF  EXISTS ( SELECT 1
    FROM [TCD].Washer  AS W
    JOIN [TCD].MachineSetup AS MS ON MS.WasherId = W.WasherId 
    where W.ETechWasherNumber = @ETechWasherNumber
	AND W.WasherId = @WasherId
	 AND  MS.IsTunnel                    =            'TRUE'
)  
BEGIN  

SET  @ErrorId      =   51012  
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate ETechWasherNumber# provided.'  
--GOTO ErrorHandler  
RAISERROR (@ErrorMessage, 16, 1)  
SET  @ReturnValue = -1  
RETURN (@ReturnValue)  
END
END

--Now attempt Update...
BEGIN    TRAN

UPDATE    MS
    SET    MS.MachineName                    =            @TunnelName
    ,    MS.ControllerId                =            @ControllerId
    ,    MS.MachineInternalId            =            @LFSWasherNumber
    ,    MS.NumberOfComp                =            @NumberOfComp
    ,    MS.LastModifiedByUserId            =            @UserId
FROM    [TCD].MachineSetup                MS
JOIN    [TCD].Washer                    W
    ON    MS.WasherId                    =            W.WasherId
    AND    MS.EcoalabAccountNumber            =            W.EcolabAccountNumber
WHERE    MS.WasherId                    =            @WasherId
    AND    MS.EcoalabAccountNumber            =            @EcoLabAccountNumber
    AND    MS.IsDeleted                    =            'FALSE'
    AND    W.Is_Deleted                    =            'FALSE'

--check for any error
SET    @ErrorId    =    @@ERROR

IF    (@ErrorId    <>    0)
BEGIN

        IF    @@TRANCOUNT    >    0
		BEGIN
            ROLLBACK    TRAN
		END
	
    SET        @ErrorMessage                =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating washer data.'
    --GOTO    Errorhandler
    RAISERROR    (@ErrorMessage, 16, 1)
    SET    @ReturnValue    =    -1
    RETURN    (@ReturnValue)
END

--else, continue with the rest of the update in the other table...
IF(@ControllerModelId IS NOT NULL AND @ControllerModelId = 7 )
BEGIN
UPDATE    W
    SET    W.ModelId                        =            @WasherModelId
    ,    W.PlantWasherNumber                =            @PlantWasherNumber
    ,    W.WasherMode                    =            @WasherMode
    ,    W.MaxLoad                        =            @MaxLoad
    ,    W.AWEActive                    =            'FALSE'
    ,    W.NumberOfTanks                =            @NumberOfTanks
    ,    W.TransferType                    =            @TransferType
    ,    W.PressExtractor                =            @PressExtractor
    ,    W.EmptyPocketNumber                =            @ProgramNumber
    ,    W.[Description]                =            @Description
    ,    W.LastModifiedByUserId            =            @UserId
    ,    W.LastModifiedTime                =            @CurrentUTCTime
    ,    W.RatioDosingActive                =              NULL    
    ,    W.EndOfFormula                    =            0
    ,    W.NumberOfCompartmentsConveyorBelt     =            @NumberOfCompartmentsConveyorBelt
    ,    W.MinMachineLoad                 =            @MinMachineLoad
    ,    W.MaxMachineLoad                 =            @MaxMachineLoad
    ,    W.ProgramSelectionByTime             =            @ProgramSelectionByTime
    ,    W.WeightSelectionByTime             =            @WeightSelectionByTime
    ,    W.WeightSelectionByAnalogInput     =            @WeightSelectionByAnalogInput
    ,    W.TunInTomMode                     =            @TunInTomMode
    ,    W.SignalStopTunActive             =            @SignalStopTunActive
    ,    W.SignalEjectionTunActive         =            @SignalEjectionTunActive
    ,    W.DelayTimeForTunWashingPrograms     =            @DelayTimeForTunWashingPrograms
    ,    W.KannegiesserPressSpecialMode     =            @KannegiesserPressSpecialMode
    ,    W.ValveOutputsUsedAsTomSignal         =            @ValveOutputsUsedAsTomSignal
    ,    W.ExtendedClockOrDataProtocol         =            @ExtendedClockOrDataProtocol
    ,    W.WeightCorrectionFcc             =            @WeightCorrectionFcc
	,	 W.ETechWasherNumber					=		@ETechWasherNumber
FROM    [TCD].Washer                    W
JOIN    [TCD].MachineSetup                MS
    ON    W.WasherId                    =            MS.WasherId
    AND    W.EcoLabAccountNumber            =            MS.EcoalabAccountNumber
WHERE    W.WasherId                    =            @WasherId
    AND    W.EcoLabAccountNumber            =            @EcoLabAccountNumber
    AND    W.Is_Deleted                    =            'FALSE'
    AND    MS.IsDeleted                    =            'FALSE'
END
ELSE IF(@ControllerModelId IS NOT NULL AND ( @ControllerModelId = 8	OR @ControllerModelId = 9	OR @ControllerModelId = 10 OR @ControllerModelId = 11 OR @ControllerModelId = 14))
BEGIN
UPDATE    W
    SET    W.ModelId                        =            @WasherModelId
    ,    W.PlantWasherNumber                =            @PlantWasherNumber
    ,    W.WasherMode                    =            @WasherMode
    ,    W.MaxLoad                        =            @MaxLoad
    ,    W.AWEActive                    =            'FALSE'
    ,    W.NumberOfTanks                =            @NumberOfTanks
    ,    W.TransferType                    =            @TransferType
    ,    W.PressExtractor                =            @PressExtractor
    ,    W.EmptyPocketNumber                =            @ProgramNumber
    ,    W.[Description]                =            @Description
    ,    W.LastModifiedByUserId            =            @UserId
    ,    W.LastModifiedTime                =            @CurrentUTCTime
    ,    W.RatioDosingActive                =              NULL    
    ,    W.EndOfFormula                    =            0
    ,    W.NumberOfCompartmentsConveyorBelt     =            @NumberOfCompartmentsConveyorBelt
    ,    W.MinMachineLoad                 =            @MinMachineLoad
    ,    W.MaxMachineLoad                 =            @MaxMachineLoad
    ,    W.TunInTomMode                     =            @TunInTomMode
    ,    W.DelayTimeForTunWashingPrograms     =            @DelayTimeForTunWashingPrograms
    ,    W.KannegiesserPressSpecialMode     =            @KannegiesserPressSpecialMode
    ,    W.WeightCorrectionFcc             =            @WeightCorrectionFcc
	,	 W.DateAndTimeWhenBatchEjects		=			@DateAndTimeWhenBatchEjects
	,	 W.AutoRinseDesamixAfter			=			@AutoRinseDesamixAfter
	,	 W.AutoRinseDesamix1For				=			@AutoRinseDesamix1For
	,	 W.AutoRinseDesamix2For				=			@AutoRinseDesamix2For
	,	 W.TemperatureAlarmProbe1			=			@TemperatureAlarmProbe1
	,	 W.TemperatureAlarmProbe2			=			@TemperatureAlarmProbe2
	,	 W.TemperatureAlarmProbe3			=			@TemperatureAlarmProbe3
	,	 W.UseMe1OfGroup					=			@UseMe1OfGroup
	,	 W.UseMe2OfGroup					=			@UseMe2OfGroup
	,	 W.ETechWasherNumber					=		@ETechWasherNumber

FROM    [TCD].Washer                    W
JOIN    [TCD].MachineSetup                MS
    ON    W.WasherId                    =            MS.WasherId
    AND    W.EcoLabAccountNumber            =            MS.EcoalabAccountNumber
WHERE    W.WasherId                    =            @WasherId
    AND    W.EcoLabAccountNumber            =            @EcoLabAccountNumber
    AND    W.Is_Deleted                    =            'FALSE'
    AND    MS.IsDeleted                    =            'FALSE'
END
ELSE
BEGIN
UPDATE    W
    SET    W.ModelId                        =            @WasherModelId
    ,    W.PlantWasherNumber                =            @PlantWasherNumber
    ,    W.WasherMode                    =            @WasherMode
    ,    W.MaxLoad                        =            @MaxLoad
    ,    W.AWEActive                    =            @AWEActive
    ,    W.NumberOfTanks                =            @NumberOfTanks
    ,    W.TransferType                    =            @TransferType
    ,    W.PressExtractor                =            @PressExtractor
    ,    W.EmptyPocketNumber                =            @ProgramNumber
    ,    W.[Description]                =            @Description
    ,    W.LastModifiedByUserId            =            @UserId
    ,    W.LastModifiedTime                =            @CurrentUTCTime
    ,   W.RatioDosingActive                =              @RatioDosingActive    
    ,   W.EndOfFormula                    =            @EndOfFormula
    ,    W.LfsWasher                     =            NULL
    ,    W.NumberOfCompartmentsConveyorBelt     =            NULL
    ,    W.MinMachineLoad                 =            NULL
    ,    W.MaxMachineLoad                 =            NULL
    ,    W.ProgramSelectionByTime             =            NULL
    ,    W.WeightSelectionByTime             =            NULL
    ,    W.WeightSelectionByAnalogInput     =            NULL
    ,    W.TunInTomMode                     =            NULL
    ,    W.SignalStopTunActive             =            NULL
    ,    W.SignalEjectionTunActive         =            NULL
    ,    W.DelayTimeForTunWashingPrograms     =            NULL
    ,    W.KannegiesserPressSpecialMode     =            NULL
    ,    W.ValveOutputsUsedAsTomSignal         =            NULL
    ,    W.ExtendedClockOrDataProtocol         =            NULL
    ,    W.WeightCorrectionFcc             =            NULL
	,	 W.ETechWasherNumber					=		@ETechWasherNumber
FROM    [TCD].Washer                    W
JOIN    [TCD].MachineSetup                MS
    ON    W.WasherId                    =            MS.WasherId
    AND    W.EcoLabAccountNumber            =            MS.EcoalabAccountNumber
WHERE    W.WasherId                    =            @WasherId
    AND    W.EcoLabAccountNumber            =            @EcoLabAccountNumber
    AND    W.Is_Deleted                    =            'FALSE'
    AND    MS.IsDeleted                    =            'FALSE'
END
--check for error, if none - commit the tran, else rollback
SET    @ErrorId    =    @@ERROR
IF    (@ErrorId    <>    0)
	BEGIN
        IF    (@@TRANCOUNT    >    0)
			BEGIN
				ROLLBACK
			END

        SET        @ErrorMessage                =            N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating washer data.'
        --GOTO    Errorhandler
        RAISERROR    (@ErrorMessage, 16, 1)
        SET    @ReturnValue    =    -1
        RETURN    (@ReturnValue)
	END
ELSE
	BEGIN
        IF    (@@TRANCOUNT    >    0)
			BEGIN
				COMMIT
			END

        SET    @OutputTunnelId    =    @WasherId
	END


--IF    (@ErrorId    =    0)
--    BEGIN
--        --GOTO    ExitModule
--        RETURN    (@ReturnValue)
--    END




--ErrorHandler:
--RAISERROR    (@ErrorMessage, 16, 1)
--SET    @ReturnValue    =    -1




--ExitModule:

SET    NOCOUNT    OFF
RETURN    (@ReturnValue)


END
GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[AddConventional]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.AddConventional
	END
GO
CREATE PROCEDURE	[TCD].[AddConventional]
					@EcoLabAccountNumber					NVARCHAR(1000)
				,	@WasherGroupId							INT
				, @NewWasherGroupId		int				=	null
				,	@ConventionalName						NVARCHAR(50)
				,	@ModelId								INT						--(Washer)Model Id for Size
				,	@ControllerId							INT
				,	@LFSWasherNumber						TINYINT					=	NULL
				,	@PlantWasherNumber						SMALLINT
				,	@WasherMode								TINYINT
				,	@MaxLoad								SMALLINT
				,	@AWEActive								BIT
				,	@HoldSignal								BIT
				,	@HoldDelay								SMALLINT															
				,	@TargetTurnTime							SMALLINT
				,	@WaterFlushTime							SMALLINT
				,	@ProgramNumber							TINYINT					--EOF number
				,	@Description							NVARCHAR(1024)			=	NULL
				,	@UserId									INT
				,	@ConventionalWasherGuid					UniqueIdentifier
				,	@ConventionalWasherId					INT									OUTPUT
				,	@LastModifiedTimestampAtCentral			DATETIME				=	NULL
				,	@OutputLastModifiedTimestampAtLocal		DATETIME				=	NULL	OUTPUT
				,	@IsDeleted								BIT						=	'FALSE'
				,   @RatioDosingActive						BIT						=	'FALSE'
,   @IsPony      BIT      = 'FALSE'
				,	@MinMachineLoad							SMALLINT				=	NULL
				,	@MaxMachineLoad							smallint				=	NULL
				,	@ProgramSelectionByTime					bit						=	NULL
				,	@FlowSwitchNumber						int						=	NULL
				,	@WasherStopExternalSignal				bit						=	NULL
				,	@OnHoldWESignalActive					bit						=	NULL
				,	@WasherOnHoldSignalDelay				int						=	NULL
				,	@ValveOutputsUsedAsTomSignal			bit						=	NULL
				,	@WeInTomMode							bit						=	NULL
				,	@ManifoldFlushTime						int						=	NULL
				,	@L1										bit						=	NULL
				,	@L2										bit						=	NULL
				,	@L3										bit						=	NULL
				,	@L4										bit						=	NULL
				,	@L5										bit						=	NULL
				,	@L6										bit						=	NULL
				,	@L7										bit						=	NULL
				,	@L8										bit						=	NULL
				,	@L9										bit						=	NULL
				,	@L10									bit						=	NULL
				,	@L11									bit						=	NULL
				,	@L12									bit						=	NULL
				,	@MyServiceLastSyncTime					DATETIME				=	NULL
				,	@UseMe1OfGroup							tinyint					=	NULL
				,	@UseMe2OfGroup							tinyint					=	NULL
				,	@UsePumpOfGroup							tinyint					=	NULL
				,	@WasherStopUseFinalExtracting			bit						=	NULL
				,	@TemperatureAlarmYesNo					bit						=	NULL
				,   @DefaultIdleTime						INT						=   NULL
				,   @ETechWasherNumber						INT						=   NULL


AS
BEGIN

SET NOCOUNT ON


DECLARE
@ReturnValue     INT    =   0
, @ErrorId      INT    =   0
, @ErrorMessage     NVARCHAR(4000) =   N''

, @WasherId      INT    =   NULL
 , @PlantId		 INT	 =	 NULL
 , @ControllerModelId INT = NULL
--, @WasherModelId     SMALLINT  =   NULL
--, @CurrentUTCTime     DATETIME  =   GETUTCDATE()     --SQLEnlight SA0004

DECLARE
@OutputList      AS TABLE  (
WasherId      INT
, LastModifiedTimestamp   DATETIME
)

SET  @ConventionalWasherId = ISNULL(@ConventionalWasherId, NULL)   --SQLEnlight
SET  @OutputLastModifiedTimestampAtLocal   =   ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)   --SQLEnlight
SET  @LastModifiedTimestampAtCentral    =   ISNULL(@LastModifiedTimestampAtCentral, NULL)    --SQLEnlight SA0029
SELECT  @PlantId = PlantId From TCD.Plant WHERE EcolabAccountNumber = @EcoLabAccountNumber
SELECT @ControllerModelId = cmctm.ControllerModelId 
FROM TCD.ControllerModelControllerTypeMapping cmctm 
INNER JOIN TCD.ConduitController cc 
	ON cc.ControllerModelId = cmctm.ControllerModelId
WHERE cc.ControllerId = @ControllerId AND cc.EcoalabAccountNumber = @EcoLabAccountNumber

--Check that the WasherGroup being associated-to is a valid Conventional-type WG...
IF NOT EXISTS ( SELECT 1
FROM [TCD].WasherGroup     WG
JOIN [TCD].WasherGroupType    WGT
ON WG.WasherGroupTypeId  =   WGT.WasherGroupTypeId
JOIN [TCD].MachineGroup     GT         --this is actually the Groups table and NOT really a Group TYPE
ON WG.WasherGroupId   =   GT.Id   --Id is actually the Id of the Group
AND WG.EcolabAccountNumber  =   GT.EcolabAccountNumber
WHERE WG.WasherGroupId   =   @WasherGroupId
AND GT.EcolabAccountNumber  =   @EcoLabAccountNumber
AND GT.GroupTypeId      =   2   --select GroupMaintype from MachineGroup
AND WGT.WasherGroupTypeName  =   'Conventional'   --select WasherGroupTypeName from WasherGroupType
AND GT.Is_Deleted    =   'FALSE'
)
BEGIN
SET  @ErrorId      =   51001
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherGroup provided.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

--Check for unique PlantWasherNo.
IF EXISTS  ( SELECT 1
FROM [TCD].Washer      W
JOIN [TCD].MachineSetup     MS
ON W.WasherId     =   MS.WasherId
AND W.EcoLabAccountNumber  =   MS.EcoalabAccountNumber
WHERE W.EcoLabAccountNumber  =   @EcoLabAccountNumber
AND (
W.PlantWasherNumber   =   @PlantWasherNumber
)
AND W.Is_Deleted    =   'FALSE'
AND MS.IsDeleted    =   'FALSE'
)
BEGIN
SET  @ErrorId      =   51002
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Specified Plant Washer #/ already exists.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

IF @ControllerId > 0
BEGIN
--Check on valid LFSWasher#/Controller type/model...
IF @LFSWasherNumber IS NOT NULL
BEGIN
	IF NOT EXISTS ( SELECT 1
	FROM [TCD].ControllerModelControllerTypeMapping
	CMCTM
	JOIN [TCD].ConduitController   CC
	ON CC.ControllerTypeId   =   CMCTM.ControllerTypeId
	AND CC.ControllerModelId  =   CMCTM.ControllerModelId
	WHERE CC.EcoalabAccountNumber  =   @EcoLabAccountNumber
	AND CC.ControllerId    =   @ControllerId
	AND CC.IsDeleted    =   'FALSE'
	AND CMCTM.MaximumWasherExtractorCount
	>=   @LFSWasherNumber
	)
		BEGIN
			SET  @ErrorId      =   51003
			SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller/LFSWasher# was provided.'
			--GOTO ErrorHandler
			RAISERROR (@ErrorMessage, 16, 1)
			SET  @ReturnValue = -1
			RETURN (@ReturnValue)
		END
END
END
--EOF should not be an asocciated formula for the WG...
IF EXISTS  ( SELECT 1
FROM [TCD].WasherProgramSetup   WPS
WHERE WPS.EcolabAccountNumber  =   @EcoLabAccountNumber
AND WPS.WasherGroupId   =   @WasherGroupId
AND WPS.ProgramNumber   =   @ProgramNumber
AND WPS.Is_Deleted    =   'FALSE'
)
BEGIN
SET  @ErrorId      =   51004
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An assoicated formula cannot be specified as End-Of-Formula.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

IF @ControllerId > 0
BEGIN
--WasherMode check
IF NOT EXISTS ( SELECT 1
FROM [TCD].ControllerModelControllerTypeMapping
CMCTM
					JOIN	[TCD].ConduitController			CC
						ON	CC.ControllerTypeId			=			CMCTM.ControllerTypeId
						AND	CC.ControllerModelId		=			CMCTM.ControllerModelId
					JOIN	[TCD].[WasherModeMapping]			CTM2WM
						ON	CMCTM.Id					=			CTM2WM.ControllerModelControllerTypeMappingId
					WHERE	CC.EcoalabAccountNumber		=			@EcoLabAccountNumber
						AND	CC.ControllerId				=			@ControllerId
						AND	CC.IsDeleted				=			'FALSE'
						AND	CTM2WM.WasherModeId			=			@WasherMode
)
BEGIN
SET  @ErrorId      =   51005
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherMode was provided.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

--LFSWasherNumber duplicate check...
IF	EXISTS	(	SELECT	1
				FROM	[TCD].MachineSetup					MS
				WHERE	MS.ControllerId					=			@ControllerId
					AND	MS.MachineInternalId			=			@LFSWasherNumber
					AND MS.EcoalabAccountNumber			=			@EcoLabAccountNumber
					AND	MS.IsDeleted					=			'FALSE'
					AND MS.IsTunnel						=			'FALSE'

)
BEGIN
SET  @ErrorId      =   51010
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate LFSWasher# provided.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END
--ETechWasherNumber duplicate check...
IF(@ControllerModelId NOT IN (7,8,9,10,11,14))
BEGIN 
--ETechWasherNumber duplicate check...
IF EXISTS ( SELECT 1
    FROM [TCD].Washer  AS W
    JOIN [TCD].MachineSetup AS MS ON MS.WasherId = W.WasherId 
    where W.ETechWasherNumber = @ETechWasherNumber
   AND MS.IsTunnel                    =            'FALSE'
)  
BEGIN  

SET  @ErrorId      =   51012  
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate ETechWasherNumber# provided.'  
--GOTO ErrorHandler  
RAISERROR (@ErrorMessage, 16, 1)  
SET  @ReturnValue = -1  
RETURN (@ReturnValue)  
END
END

END
--Now attempt to insert a new row for the conventional washer being added...
BEGIN TRAN

INSERT	[TCD].Washer	(
	 EcoLabAccountNumber	,PlantWasherNumber			,ModelId				,WasherMode					,MaxLoad						,AWEActive				,EndOfFormula
	,[Description]			,Is_Deleted					,LastModifiedByUserId	,HoldSignal					,HoldDelay						,TargetTurnTime			,WaterFlushTime		
	,MyServiceCustMchGuid	,RatioDosingActive			,MyServiceLastSynchTime	,MinMachineLoad				,MaxMachineLoad					,ProgramSelectionByTime	,FlowSwitchNumber		
	,WasherStopExternalSignal	,OnHoldWESignalActive	, WasherOnHoldSignalDelay	,ValveOutputsUsedAsTomSignal			,WeInTomMode			,ManifoldFlushTime	
	,L1	,L2	,L3	,L4	,L5	,L6	,L7	,L8	,L9	 ,L10 ,L11	,L12 ,UseMe1OfGroup ,UseMe2OfGroup ,UsePumpOfGroup ,WasherStopUseFinalExtracting ,TemperatureAlarmYesNo ,PlantId, DefaultIdleTime, ETechWasherNumber
)
OUTPUT
inserted.WasherId      AS   Id
, inserted.LastModifiedTime  AS   LastModifiedTimestamp
INTO
@OutputList (
WasherId
, LastModifiedTimestamp
)

SELECT	@EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	@PlantWasherNumber					AS			PlantWasherNumber
	,	@ModelId							AS			ModelId
	,	@WasherMode							AS			WasherMode
	,	@MaxLoad							AS			MaxLoad
	,	@AWEActive							AS			AWEActive
	,	@ProgramNumber						AS			ProgramNumber
	,	@Description						AS			[Description]
	,	@IsDeleted							AS			Is_Deleted
	,	@UserId								AS			LastModifiedByUserId
	,	@HoldSignal							AS			HoldSignal
	,	@HoldDelay							AS			HoldDelay
	,	@TargetTurnTime						AS			TargetTurnTime
	,	@WaterFlushTime						AS			WaterFlushTime
	,	@ConventionalWasherGuid				AS			MyServiceCustMchGuid
	,	@RatioDosingActive					AS			RatioDosingActive
	,	@MyServiceLastSyncTime				AS			MyServiceLastSynchTime
	,	@MinMachineLoad						AS			MinimumMachineLoad
	,	@MaxMachineLoad						AS			MaximumMachineLoad
	,	@ProgramSelectionByTime				AS			ProgramSelectionByTime
	,	@FlowSwitchNumber					AS			FlowSwitchNumber
	,	@WasherStopExternalSignal			AS			WasherStopExternalSignal
	,	@OnHoldWESignalActive				AS			OnHoldWESignalActive
	,	@WasherOnHoldSignalDelay			AS			WasherOnHoldSignalDelay
	,	@ValveOutputsUsedAsTomSignal		AS			ValveOutputsUsedAsTomSignal
	,	@WeInTomMode						AS			WeInTomMode			
	,	@ManifoldFlushTime					AS			ManifoldFlushTime			
	,	@L1									AS			L1
	,	@L2									AS			L2
	,	@L3									AS			L3
	,	@L4									AS			L4
	,	@L5									AS			L5
	,	@L6									AS			L6
	,	@L7									AS			L7
	,	@L8									AS			L8
	,	@L9									AS			L9
	,	@L10								AS			L10
	,	@L11								AS			L11
	,	@L12								AS			L12
	,	@UseMe1OfGroup						AS			UseMe1OfGroup
	,	@UseMe2OfGroup						AS			UseMe2OfGroup
	,	@UsePumpOfGroup						AS			UsePumpOfGroup
	,	@WasherStopUseFinalExtracting		AS			WasherStopUseFinalExtracting
	,	@TemperatureAlarmYesNo				AS			TemperatureAlarmYesNo
	,	@PlantId							AS			PlantId
	,   @DefaultIdleTime AS   DefaultIdleTime 
	,   @ETechWasherNumber AS ETechWasherNumber


SET @ErrorId = @@ERROR

IF (@ErrorId <> 0)
BEGIN
IF @@TRANCOUNT > 0
BEGIN
ROLLBACK TRAN
END

SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred creating new record for conventional.'
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

--if no error, collect the id of the newly generated row...
SELECT TOP 1 @WasherId = O.WasherId FROM @OutputList O

--insert in MachineSetup
INSERT [TCD].MachineSetup (
WasherId ,GroupId ,MachineInternalId ,EcoalabAccountNumber ,MachineName ,IsTunnel ,ControllerId , IsDeleted ,LastModifiedByUserId,IsPony )
SELECT @WasherId     AS   WasherId
, @WasherGroupId    AS   GroupId
, @LFSWasherNumber   AS   MachineInternalId
, @EcoLabAccountNumber  AS   EcoalabAccountNumber
, @ConventionalName   AS   MachineName
,@IsDeleted      AS   IsTunnel
, @ControllerId    AS   ControllerId
, 'FALSE'      AS   IsDeleted
, @UserId      AS   LastModifiedByUserId
,@IsPony As IsPony



 IF(ISNULL( @NewWasherGroupId,0)>0 AND (@WasherGroupId != @NewWasherGroupId))
 BEGIN
    UPDATE tcd.machinesetup 
    SET GroupId = @NewWasherGroupId
    WHERE WasherId = @WasherId
     
   EXEC TCD.SaveInjectionDetails @WasherGroupId,@NewWasherGroupId,@ControllerId,@WasherId,@EcolabAccountNumber
 END
 ELSE
 BEGIN
   EXEC TCD.SaveInjectionDetails @WasherGroupId,@WasherGroupId,@ControllerId,@WasherId,@EcolabAccountNumber
 END

SET @ErrorId = @@ERROR

IF (@ErrorId <> 0)
BEGIN
IF @@TRANCOUNT > 0
BEGIN
ROLLBACK TRAN
END

SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred assoicating new record for conventional.'
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END
ELSE
BEGIN
IF @@TRANCOUNT > 0
BEGIN
COMMIT
END

--SET the output param to be communicated back...

SELECT TOP 1
@OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp
, @ConventionalWasherId    = O.WasherId
FROM @OutputList       O

END




IF ( @ErrorId = 0 )
BEGIN
		IF (@ControllerModelId = 7)
			BEGIN
				UPDATE TCD.WasherGroup SET ControllerId = @ControllerId WHERE WasherGroupId = @WasherGroupId
			END
RETURN (@ReturnValue)
END



--ErrorHandler:
--RAISERROR (@ErrorMessage, 16, 1)
--SET @ReturnValue = -1


--ExitModule:

--RETURN (@ReturnValue)

--SET NOCOUNT OFF

END
GO


IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[UpdateConventional]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.UpdateConventional
	END
GO
CREATE	PROCEDURE	[TCD].[UpdateConventional]
					@EcoLabAccountNumber					NVARCHAR(1000)
				,	@WasherId								INT
				,	@WasherGroupId							INT
				, @NewWasherGroupId							int		=	null
				,	@ConventionalName						NVARCHAR(50)
				,	@ModelId								INT						--(Washer)Model Id for Size
				,	@ControllerId							INT
				,	@LFSWasherNumber						TINYINT
				,	@PlantWasherNumber						SMALLINT
				,	@WasherMode								TINYINT
				,	@MaxLoad								SMALLINT
				,	@AWEActive								BIT
				,	@HoldSignal								BIT
				,	@HoldDelay								SMALLINT															
				,	@TargetTurnTime							SMALLINT
				,	@WaterFlushTime							SMALLINT
				,	@ProgramNumber							TINYINT					--EOF number
				,	@Description							NVARCHAR(1024)	=			NULL
				,	@UserId									INT
				,	@LastModifiedTimestampAtCentral			DATETIME				=	NULL
				,	@OutputLastModifiedTimestampAtLocal		DATETIME				=	NULL	OUTPUT
				,	@RatioDosingActive						BIT			
				,	@IsPony BIT  
				,	@MinMachineLoad							SMALLINT				=	NULL
				,	@MaxMachineLoad							smallint				=	NULL
				,	@ProgramSelectionByTime					bit						=	NULL
				,	@FlowSwitchNumber						int						=	NULL
				,	@WasherStopExternalSignal				bit						=	NULL
				,	@OnHoldWESignalActive					bit						=	NULL
				,	@WasherOnHoldSignalDelay				int						=	NULL
				,	@ValveOutputsUsedAsTomSignal			bit						=	NULL
				,	@WeInTomMode							bit						=	NULL
				,	@ManifoldFlushTime						int						=	NULL
				,	@L1										bit						=	NULL
				,	@L2										bit						=	NULL
				,	@L3										bit						=	NULL
				,	@L4										bit						=	NULL
				,	@L5										bit						=	NULL
				,	@L6										bit						=	NULL
				,	@L7										bit						=	NULL
				,	@L8										bit						=	NULL
				,	@L9										bit						=	NULL
				,	@L10									bit						=	NULL
				,	@L11									bit						=	NULL
				,	@L12									bit						=	NULL
				,	@UseMe1OfGroup							tinyint					=	NULL
				,	@UseMe2OfGroup							tinyint					=	NULL
				,	@UsePumpOfGroup							tinyint					=	NULL
				,	@WasherStopUseFinalExtracting			bit						=	NULL
				,	@TemperatureAlarmYesNo					bit						=	NULL
				, @DefaultIdleTime							INT						=   NULL
				, @ETechWasherNumber						INT						=   NULL
AS
BEGIN

SET NOCOUNT ON


DECLARE 
  @ReturnValue     INT    =   0
 , @ErrorId      INT    =   0
 , @ErrorMessage     NVARCHAR(4000) =   N''
 , @CurrentUTCTime     DATETIME  =   GETUTCDATE()
 , @PlantId		INT			=	NULL
 , @ControllerModelId INT = NULL

DECLARE
   @OutputList      AS TABLE  (
   LastModifiedTimestamp   DATETIME
  )

SET  @OutputLastModifiedTimestampAtLocal    =   ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)   --SQLEnlight
SELECT  @PlantId = PlantId From TCD.Plant WHERE EcolabAccountNumber = @EcoLabAccountNumber
SELECT @ControllerModelId = cmctm.ControllerModelId 
FROM TCD.ControllerModelControllerTypeMapping cmctm 
INNER JOIN TCD.ConduitController cc 
	ON cc.ControllerModelId = cmctm.ControllerModelId
WHERE cc.ControllerId = @ControllerId AND cc.EcoalabAccountNumber = @EcoLabAccountNumber

--Valid Washer-Id check...
IF NOT EXISTS ( SELECT 1
     FROM [TCD].Washer      W
     JOIN [TCD].MachineSetup    MS
      ON W.WasherId     =   MS.WasherId
      AND W.EcoLabAccountNumber  =   MS.EcoalabAccountNumber
     WHERE W.EcoLabAccountNumber  =   @EcoLabAccountNumber
      AND W.WasherId     =   @WasherId
      AND MS.GroupId     =   @WasherGroupId
      AND W.Is_Deleted    =   'FALSE'
      AND MS.IsDeleted    =   'FALSE'
    )
   BEGIN
    SET  @ErrorId      =   51006
    SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Washer-ID was provided for Updating.'
    --GOTO ErrorHandler
    RAISERROR (@ErrorMessage, 16, 1)
    SET  @ReturnValue = -1
    RETURN (@ReturnValue)
   END

--Check for uniqueness of PlantWasherNo. and Name
IF EXISTS  ( SELECT 1
     FROM [TCD].Washer      W
     JOIN [TCD].MachineSetup    MS
      ON W.WasherId     =   MS.WasherId
      AND W.EcoLabAccountNumber  =   MS.EcoalabAccountNumber
     WHERE W.EcoLabAccountNumber  =   @EcoLabAccountNumber
      AND W.WasherId     <>   @WasherId AND W.PlantWasherNumber   =   @PlantWasherNumber
      AND (
       W.PlantWasherNumber   =   @PlantWasherNumber       
       OR
       MS.MachineName    =   @ConventionalName
       )
      AND W.Is_Deleted    =   'FALSE'
      AND MS.IsDeleted    =   'FALSE'
    )
   BEGIN
    SET  @ErrorId      =   51002
    SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Specified Plant Washer #/ already exists.'
    --GOTO ErrorHandler
    RAISERROR (@ErrorMessage, 16, 1)
    SET  @ReturnValue = -1
    RETURN (@ReturnValue)
   END

IF @ControllerId > 0
BEGIN
--Check Max LFSWasher No.
IF NOT EXISTS ( SELECT 1
     FROM [TCD].ControllerModelControllerTypeMapping
              CMCTM
     JOIN [TCD].ConduitController   CC
      ON CC.ControllerTypeId   =   CMCTM.ControllerTypeId
      AND CC.ControllerModelId  =   CMCTM.ControllerModelId
     WHERE CC.EcoalabAccountNumber  =   @EcoLabAccountNumber
      AND CC.ControllerId    =   @ControllerId
      AND CC.IsDeleted    =   'FALSE'
      AND CMCTM.MaximumWasherExtractorCount
              >=   @LFSWasherNumber
    )
   BEGIN
    SET  @ErrorId      =   51003
    SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller/LFSWasher# was provided.'
    --GOTO ErrorHandler
    RAISERROR (@ErrorMessage, 16, 1)
    SET  @ReturnValue = -1
    RETURN (@ReturnValue)
   END
END
--EOF should not be an asocciated formula for the WG...
IF EXISTS  ( SELECT 1
     FROM [TCD].WasherProgramSetup   WPS
     WHERE WPS.EcolabAccountNumber  =   @EcoLabAccountNumber
      AND WPS.WasherGroupId   =   @WasherGroupId
      AND WPS.ProgramNumber   =   @ProgramNumber
      AND WPS.Is_Deleted    =   'FALSE'
    )
   BEGIN
    SET  @ErrorId      =   51004
    SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An assoicated formula cannot be specified as End-Of-Formula.'
    --GOTO ErrorHandler
    RAISERROR (@ErrorMessage, 16, 1)
    SET  @ReturnValue = -1
    RETURN (@ReturnValue)
   END

IF @ControllerId > 0
BEGIN
--WasherMode check
IF NOT EXISTS ( SELECT 1
     FROM [TCD].ControllerModelControllerTypeMapping
              CMCTM
					JOIN	[TCD].ConduitController			CC
						ON	CC.ControllerTypeId			=			CMCTM.ControllerTypeId
						AND	CC.ControllerModelId		=			CMCTM.ControllerModelId
					JOIN	[TCD].[WasherModeMapping]
              CTM2WM
      ON CMCTM.Id     =   CTM2WM.ControllerModelControllerTypeMappingId
     WHERE CC.EcoalabAccountNumber  =   @EcoLabAccountNumber
      AND CC.ControllerId    =   @ControllerId
      AND CC.IsDeleted    =   'FALSE'
      AND CTM2WM.WasherModeId   =   @WasherMode
    )
   BEGIN
    SET  @ErrorId      =   51005
    SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherMode was provided.'
    --GOTO ErrorHandler
    RAISERROR (@ErrorMessage, 16, 1)
    SET  @ReturnValue = -1
    RETURN (@ReturnValue)
   END

--LFSWasherNumber duplicate check...
IF	EXISTS	(	SELECT	1
				FROM	[TCD].MachineSetup					MS
				WHERE	MS.ControllerId					=			@ControllerId
					AND	MS.MachineInternalId			=			@LFSWasherNumber
					AND	MS.IsDeleted					=			'FALSE'
					AND	MS.WasherId						<>			@WasherId
					AND MS.EcoalabAccountNumber			=			@EcoLabAccountNumber
					AND MS.IsTunnel						=			'FALSE'
   )
   BEGIN
    SET  @ErrorId      =   51010
    SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate LFSWasher# provided.'
    --GOTO ErrorHandler
    RAISERROR (@ErrorMessage, 16, 1)
    SET  @ReturnValue = -1
    RETURN (@ReturnValue)
   END
   --ETechWasherNumber duplicate check...
IF(@ControllerModelId NOT IN (7,8,9,10,11,14))
BEGIN 
--ETechWasherNumber duplicate check...
IF  EXISTS ( SELECT 1
    FROM [TCD].Washer  AS W
    JOIN [TCD].MachineSetup AS MS ON MS.WasherId = W.WasherId 
    where W.ETechWasherNumber = @ETechWasherNumber
	AND W.WasherId = @WasherId
   AND MS.IsTunnel                    =            'FALSE'
)  
BEGIN  

SET  @ErrorId      =   51012  
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate ETechWasherNumber# provided.'  
--GOTO ErrorHandler  
RAISERROR (@ErrorMessage, 16, 1)  
SET  @ReturnValue = -1  
RETURN (@ReturnValue)  
END
END

END

IF (
   @LastModifiedTimestampAtCentral    IS NOT NULL
   AND
   NOT EXISTS ( SELECT 1
     FROM TCD.Washer  W
     WHERE W.EcolabAccountNumber = @EcolabAccountNumber
      AND W.WasherId    = @WasherId
      AND W.LastModifiedTime  = @LastModifiedTimestampAtCentral
    )
 )
  BEGIN
    SET   @ErrorId    = 60000
    SET   @ErrorMessage   = N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
    RAISERROR (@ErrorMessage, 16, 1)
    SET   @ReturnValue   = -1
    RETURN  (@ReturnValue)
  END


--Now attempt Update...
BEGIN TRAN

UPDATE MS
 SET MS.MachineName     =   @ConventionalName
 , MS.ControllerId     =   @ControllerId
 , MS.MachineInternalId   =   @LFSWasherNumber
 , MS.LastModifiedByUserId   =   @UserId
 ,MS.IsPony = @IsPony
FROM [TCD].MachineSetup     MS
JOIN [TCD].Washer       W
 ON MS.WasherId      =   W.WasherId
 AND MS.EcoalabAccountNumber   =   W.EcolabAccountNumber
WHERE MS.WasherId      =   @WasherId
 AND MS.EcoalabAccountNumber   =   @EcoLabAccountNumber
 AND MS.IsDeleted     =   'FALSE'
 AND W.Is_Deleted     =   'FALSE'

--check for any error
SET @ErrorId = @@ERROR

IF (@ErrorId <> 0)
BEGIN

  IF @@TRANCOUNT > 0
  BEGIN
   ROLLBACK TRAN
  END
 
  SET  @ErrorMessage    =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating washer data.'
  --GOTO ErrorHandler
  RAISERROR (@ErrorMessage, 16, 1)
  SET  @ReturnValue = -1
  RETURN (@ReturnValue)
END

--else, continue with the rest of the update in the other table...
UPDATE	W
	SET	W.ModelId						=			@ModelId
	,	W.PlantWasherNumber				=			@PlantWasherNumber
	,	W.WasherMode					=			@WasherMode
	,	W.MaxLoad						=			@MaxLoad
	,	W.AWEActive						=			@AWEActive
	,	W.HoldSignal					=			@HoldSignal
	,	W.HoldDelay						=			@HoldDelay
	,	W.TargetTurnTime				=			@TargetTurnTime
	,	W.WaterFlushTime				=			@WaterFlushTime
	,	W.EndOfFormula					=			@ProgramNumber
	,	W.[Description]					=			@Description
	,	W.LastModifiedByUserId			=			@UserId
	,	W.LastModifiedTime				=			@CurrentUTCTime
	,   W.RatioDosingActive				=			@RatioDosingActive
	,	W.MinMachineLoad				=			@MinMachineLoad				
	,	W.MaxMachineLoad				=			@MaxMachineLoad				
	,	W.ProgramSelectionByTime		=			@ProgramSelectionByTime		
	,	W.FlowSwitchNumber				=			@FlowSwitchNumber			
	,	W.WasherStopExternalSignal		=			@WasherStopExternalSignal	
	,	W.OnHoldWESignalActive			=			@OnHoldWESignalActive		
	,	W.WasherOnHoldSignalDelay		=			@WasherOnHoldSignalDelay	
	,	W.ValveOutputsUsedAsTomSignal	=			@ValveOutputsUsedAsTomSignal
	,	W.WEInTOMMode					=			@WeInTomMode				
	,	W.ManifoldFlushTime				=			@ManifoldFlushTime			
	,	W.L1							=			@L1
	,	W.L2							=			@L2
	,	W.L3							=			@L3
	,	W.L4							=			@L4
	,	W.L5							=			@L5
	,	W.L6							=			@L6
	,	W.L7							=			@L7
	,	W.L8							=			@L8
	,	W.L9							=			@L9
	,	W.L10							=			@L10
	,	W.L11							=			@L11
	,	W.L12							=			@L12
	,	W.UseMe1OfGroup					=			@UseMe1OfGroup
	,	W.UseMe2OfGroup					=			@UseMe2OfGroup
	,	W.UsePumpOfGroup				=			@UsePumpOfGroup
	,	W.WasherStopUseFinalExtracting	=			@WasherStopUseFinalExtracting
	,	W.TemperatureAlarmYesNo			=			@TemperatureAlarmYesNo
	,	W.PlantId						=			@PlantId
	,   W.DefaultIdleTime               =           @DefaultIdleTime
	,   W.ETechWasherNumber               =         @ETechWasherNumber

OUTPUT
 inserted.LastModifiedTime  AS   LastModifiedTimestamp
INTO
 @OutputList (
 LastModifiedTimestamp
)
FROM [TCD].Washer      W
JOIN [TCD].MachineSetup     MS
 ON W.WasherId      =   MS.WasherId
 AND W.EcoLabAccountNumber   =   MS.EcoalabAccountNumber
WHERE W.WasherId      =   @WasherId
 AND W.EcoLabAccountNumber   =   @EcoLabAccountNumber
 AND W.Is_Deleted     =   'FALSE'
 AND MS.IsDeleted     =   'FALSE'


 IF(@NewWasherGroupId IS NOT NULL AND (@WasherGroupId != @NewWasherGroupId))
 BEGIN
    UPDATE tcd.machinesetup 
    SET GroupId = @NewWasherGroupId
    WHERE WasherId = @WasherId
     
   EXEC TCD.SaveInjectionDetails @WasherGroupId,@NewWasherGroupId,@ControllerId,@WasherId,@EcolabAccountNumber
 END
 ELSE
 BEGIN
   EXEC TCD.SaveInjectionDetails @WasherGroupId,@WasherGroupId,@ControllerId,@WasherId,@EcolabAccountNumber
 END

--check for error, if none - commit the tran, else rollback
SET @ErrorId = @@ERROR
IF (@ErrorId <> 0)
 BEGIN
  IF (@@TRANCOUNT > 0)
   BEGIN
    ROLLBACK
   END

  SET  @ErrorMessage    =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating washer data.'
  --GOTO ErrorHandler
  RAISERROR (@ErrorMessage, 16, 1)
  SET  @ReturnValue = -1
  RETURN (@ReturnValue)
 END
ELSE
 BEGIN
  IF (@@TRANCOUNT > 0)
   BEGIN
				IF (@ControllerModelId = 7)
				BEGIN
					UPDATE TCD.WasherGroup SET ControllerId = @ControllerId WHERE WasherGroupId = @WasherGroupId
				END
    COMMIT
   END
   
   SELECT TOP 1 @OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp FROM @OutputList O
 END


SET NOCOUNT OFF
RETURN (@ReturnValue)


END
GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetCompareFormulaPumpsList]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetCompareFormulaPumpsList
	END
GO  
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*	
Purpose					:	To populate the grid in the ControllerSetup-->Pumps/Valves tab

History					:
Sept. 2014		dfozdar@allianceglobalservice.com		initial version



*/

CREATE	PROCEDURE [TCD].[GetCompareFormulaPumpsList]
       @EcoLabAccountNumber					NVARCHAR( 1000)
       ,@ControllerId							INT	
       ,@WasherProgramSetupId					int 
	  ,@ControllerEquipmentId					  int = null
       ,@IsActive								BIT = NULL
AS
     BEGIN
         SET	NOCOUNT	ON;
         DECLARE	@ErrorMessage										NVARCHAR( 4000
                                                                                        )
                    ,@PumpValveCount										TINYINT
                    ,@MECount											TINYINT
                    ,@ControllerEquipmentTypeId_PumpValve				TINYINT
                    ,@ControllerEquipmentTypeId_ME						TINYINT
                    ,@ReturnValue										INT = 0
                    ,@TagTypeLfs VARCHAR( 100) = 'Tag_NML'
                    ,@TagTypeKfactor VARCHAR( 100) = 'Tag_PPOL'
                    ,@TagTypeCalibration VARCHAR( 100) = 'Tag_OPSL';


         CREATE	TABLE #Equipment	(
         ControllerEquipmentId					INT				IDENTITY( 1, 1)
         ,ControllerEquipmentTypeId				TINYINT			NOT	NULL
         ,IsActive								BIT				NOT	NULL DEFAULT('FALSE')
         ,ProductId								INT				NULL
         ,ProductName								NVARCHAR( 255)	NULL
         --ProductMaster
         ,PumpCalibration							DECIMAL( 18, 3)	NULL
         ,FlowMeterSwitchFlag						BIT				NULL
         --NULL (not set), 0 for Meter, 1 for Switch
         ,FlowMeterCalibration					INT				NULL
         ,MaximumDosingTime						SMALLINT		NULL
         ,FlowSwitchTimeOut						SMALLINT		NULL
         ,ControllerEquipmentSetupId				SMALLINT		NULL
         ,LfsChemicalName							NVARCHAR( 200)	NULL
         ,KFactor									DECIMAL( 18, 2)	NULL
         ,TunnelHold								BIT				NULL
         ,FlowDetectorType							INT				NULL
         ,FlowSwitchAlarm							BIT				NULL
         ,FlowMeterAlarm							BIT				NULL
         ,FlowMeterType							INT				NULL
         ,FlowAlarmDelay							DECIMAL( 18, 2)	NULL
         ,FlowMeterPumpDelay						DECIMAL( 18, 2)				NULL
         ,FlowMeterAlarmDelay						DECIMAL( 18, 2)				NULL

         --Synch./Central integration additions

         ,LastModifiedTime						DATETIME		NULL
         ,LastSyncTime							DATETIME		NULL
                                        );


         IF	NOT	EXISTS	( SELECT	1
                                FROM	[TCD].ConduitController			CC
                                WHERE	CC.EcoalabAccountNumber = @EcoLabAccountNumber
                                    AND CC.ControllerId = @ControllerId
                              )
             BEGIN
                 SET			@ErrorMessage = 'Invalid Plant/Controller combination specified';

                 --GOTO		ErrorHandler

                 RAISERROR	( @ErrorMessage, 16, 1);
                 SET		@ReturnValue = -1;
                 RETURN	(@ReturnValue);
             END;


         SELECT	@ControllerEquipmentTypeId_PumpValve = CASE
                                                               WHEN	CET.ControllerEquipmentTypeName = 'Pump/Valve'
                                                               THEN	CET.ControllerEquipmentTypeId
                                                               ELSE	@ControllerEquipmentTypeId_PumpValve
                                                           END
                    ,@ControllerEquipmentTypeId_ME = CASE
                                                         WHEN	CET.ControllerEquipmentTypeName = 'ME'
                                                         THEN	CET.ControllerEquipmentTypeId
                                                         ELSE	@ControllerEquipmentTypeId_ME
                                                     END
         FROM [TCD].ControllerEquipmentType CET
         WHERE	CET.ControllerEquipmentTypeName			IN			( 'Pump/Valve', 'ME');


         SELECT	@PumpValveCount = ISNULL( CSD.Value, 0)
         FROM [TCD].ConduitController CC JOIN [TCD].ControllerModelControllerTypeMapping CMCTM ON CC.ControllerModelId = CMCTM.ControllerModelId
                                         JOIN [TCD].ControllerSetupData CSD ON CSD.ControllerId = CC.ControllerId
                                                                           AND CC.ControllerTypeId = CMCTM.ControllerTypeId
                                         JOIN [TCD].FieldGroup FG ON FG.ControllerModelId = CC.ControllerModelId
                                                                 AND FG.ControllerTypeId = CC.ControllerTypeId
                                                                 AND FG.TabId = 3
                                         INNER JOIN [TCD].FieldGroupFieldMapping FGM ON FGM.FieldGroupId = FG.Id
                                         INNER JOIN [TCD].Field F ON F.Id = FGM.FieldId
                                                                 AND CSD.FieldId = f.Id
         WHERE	CC.ControllerId = @ControllerId
           AND F.ResourceKey = 'No._of_Chemical_Valves'
           AND CSD.EcolabAccountNumber = @EcoLabAccountNumber;
         SELECT	@MECount = ISNULL( CMCTM.MECount, 0
                                     )
         FROM [TCD].ConduitController CC JOIN [TCD].ControllerModelControllerTypeMapping CMCTM ON CC.ControllerModelId = CMCTM.ControllerModelId
                                                                                              AND CC.ControllerTypeId = CMCTM.ControllerTypeId
         WHERE	CC.ControllerId = @ControllerId;



         IF	(	( SELECT	ISNULL( @PumpValveCount, 0) + ISNULL( @MECount, 0)) = 0)
             BEGIN

                 --GOTO		ExitModule
                 --Return EMPTY result set

                 SELECT

                 --*	--Change this

                 T.ControllerEquipmentId		AS			ControllerEquipmentId
                 ,T.ControllerEquipmentTypeId	AS			ControllerEquipmentTypeId
                 ,T.IsActive					AS			IsActive
                 ,T.ProductId					AS			ProductId
                 ,T.ProductName				AS			ProductName
                 ,T.PumpCalibration			AS			PumpCalibration
                 ,T.FlowMeterSwitchFlag		AS			FlowMeterSwitchFlag
                 ,T.FlowMeterCalibration		AS			FlowMeterCalibration
                 ,T.MaximumDosingTime			AS			MaximumDosingTime
                 ,T.FlowSwitchTimeOut			AS			FlowSwitchTimeOut
                 ,T.ControllerEquipmentSetupId AS			ControllerEquipmentSetupId

                 --	required in the RS for the service layer...

                 ,@EcoLabAccountNumber		AS			EcoLabAccountNumber
                 ,@ControllerId				AS			ControllerId
                 ,CC.TopicName					AS			ControllerName
                 ,CC.ControllerTypeId			AS			ControllerTypeId
                 ,T.LfsChemicalName				AS			LfsChemicalName
                 ,T.KFactor						AS			KFactor
                 ,T.TunnelHold					AS			TunnelHold
                 ,T.FlowDetectorType			AS			FlowDetectorType
                 ,T.FlowSwitchAlarm				AS			FlowSwitchAlarm
                 ,T.FlowMeterAlarm			AS			FlowMeterAlarm
                 ,T.FlowMeterType				AS			FlowMeterType
                 ,T.FlowAlarmDelay			AS			FlowAlarmDelay
                 ,T.FlowMeterPumpDelay			AS			FlowMeterPumpDelay
                 ,T.FlowMeterAlarmDelay		AS			FlowMeterAlarmDelay
                 ,( 
                    SELECT MTS.TagAddress
                    FROM TCD.ModuleTags MTS
                    WHERE MTS.TagType = @TagTypeLfs
                      AND MTS.ModuleID = ControllerEquipmentSetupId
                      AND MTS.ModuleTypeId = 4
                      AND MTS.Active = 1
                  ) AS LfsChemicalNameTag
                 ,( 
                    SELECT MTS.TagAddress
                    FROM TCD.ModuleTags MTS
                    WHERE MTS.TagType = @TagTypeKfactor
                      AND MTS.ModuleID = ControllerEquipmentSetupId
                      AND MTS.ModuleTypeId = 4
                      AND MTS.Active = 1
                  ) AS KfactorTag
                 ,( 
                    SELECT MTS.TagAddress
                    FROM TCD.ModuleTags MTS
                    WHERE MTS.TagType = @TagTypeCalibration
                      AND MTS.ModuleID = ControllerEquipmentSetupId
                      AND MTS.ModuleTypeId = 4
                      AND MTS.Active = 1
                  ) AS CalibrationTag

                 --Synch./Central integration additions

                 ,T.LastModifiedTime			AS			LastModifiedTime
                 ,T.LastSyncTime				AS			LastSyncTime
                 FROM	#Equipment					T JOIN TCD.ConduitController CC
                 ON CC.ControllerId = @ControllerId
                 WHERE	T.IsActive = ISNULL( @IsActive, T.IsActive
                                            )
                     AND T.ControllerEquipmentId = ISNULL( @ControllerEquipmentId, T.ControllerEquipmentId);
                 RETURN	(@ReturnValue);
             END;



         IF	(ISNULL( @PumpValveCount, 0) <> 0)
             BEGIN
                 WITH NumCTE	( N)
                     AS	( SELECT	'*'	AS	N
                           UNION ALL
                           SELECT	'*'	AS	N
                         )
                     INSERT INTO	#Equipment	(ControllerEquipmentTypeId)
                     SELECT	TOP ( @PumpValveCount)
                     @ControllerEquipmentTypeId_PumpValve
                     FROM	NumCTE N1	, NumCTE N2	, NumCTE N3	, NumCTE N4	, NumCTE N5;
             END;
         IF	(ISNULL( @MECount, 0) <> 0)
             BEGIN
                 WITH	NumCTE	( N)
                     AS	( SELECT	'*'	AS	N
                           UNION ALL
                           SELECT	'*'	AS	N
                         )
                     INSERT INTO	#Equipment	(ControllerEquipmentTypeId)
                     SELECT	TOP ( @MECount)
                     @ControllerEquipmentTypeId_ME
                     FROM	NumCTE N1	, NumCTE N2	, NumCTE N3	, NumCTE N4	, NumCTE N5;
             END;
         UPDATE	U
           SET	U.IsActive = CES.IsActive
               ,U.ProductId = CES.ProductId
               ,U.ProductName = PM.Name
               ,U.PumpCalibration = CES.PumpCalibration
               ,U.FlowMeterSwitchFlag = CES.FlowMeterSwitchFlag
               ,U.FlowMeterCalibration = CES.FlowMeterCalibration
               ,U.MaximumDosingTime = CES.MaximumDosingTime
               ,U.FlowSwitchTimeOut = CES.FlowSwitchTimeOut

               --update CESId here; though we are not using this as of now...

               ,U.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId
               ,U.LfsChemicalName = CES.LfsChemicalName
               ,U.KFactor = CES.KFactor
               ,U.TunnelHold = CES.TunnelHold
               ,U.FlowDetectorType = CES.FlowDetectorType
               ,U.FlowSwitchAlarm = CES.FlowSwitchAlarm
               ,U.FlowMeterAlarm = CES.FlowMeterAlarm
               ,U.FlowMeterType = CES.FlowMeterType
               ,U.FlowAlarmDelay = CES.FlowAlarmDelay
               ,U.FlowMeterPumpDelay = CES.FlowMeterPumpDelay
               ,U.FlowMeterAlarmDelay = CES.FlowMeterAlarmDelay

               --Synch./Central integration additions

               ,U.LastModifiedTime = CES.LastModifiedTime
               ,U.LastSyncTime = CES.LastSyncTime
         FROM	#Equipment U 
	    JOIN	[TCD].ControllerEquipmentSetup	CES ON	U.ControllerEquipmentId = CES.ControllerEquipmentId AND U.ControllerEquipmentTypeId = CES.ControllerEquipmentTypeId
          JOIN	[TCD].ProductMaster				PM ON	CES.ProductId = PM.ProductId
		INNER JOIN TCD.MachineSetup MS ON CES.ControllerId =MS.ControllerId AND MS.IsDeleted=0
		INNER JOIN TCD.[WasherProgramSetup] wps ON MS.GroupID =wps.WasherGroupId AND wps.Is_Deleted=0 AND wps.WasherProgramSetupId=@WasherProgramSetupId
		INNER JOIN [TCD].[WasherDosingSetup] wds ON wps.WasherProgramSetupId =wds.WasherProgramSetupId AND wds.Is_Deleted=0
		LEFT JOIN TCD.WasherDosingProductMapping wspm ON wds.WasherDosingSetupId =wspm.WasherDosingSetupId AND PM.ProductId=wspm.ProductId AND wspm.IsDeleted=0
         WHERE	CES.EcoLabAccountNumber = @EcoLabAccountNumber
           AND CES.ControllerId = @ControllerId;
         GOTO	ExitModule;

         --ErrorHandler:
         --RAISERROR	(@ErrorMessage, 16, 1)
         --SET	@ReturnValue	=	-1

         ExitModule:

         --Return result set

         SELECT

         --*	--Change this

         T.ControllerEquipmentId			AS ControllerEquipmentId
         ,T.ControllerEquipmentTypeId		AS ControllerEquipmentTypeId
         ,T.IsActive						AS IsActive
         ,T.ProductId						AS ProductId
         ,T.ProductName					AS ProductName
         ,T.PumpCalibration				AS PumpCalibration
         ,T.FlowMeterSwitchFlag			AS FlowMeterSwitchFlag
         ,T.FlowMeterCalibration			AS FlowMeterCalibration
         ,T.MaximumDosingTime				AS MaximumDosingTime
         ,T.FlowSwitchTimeOut				AS FlowSwitchTimeOut
         ,T.ControllerEquipmentSetupId	AS ControllerEquipmentSetupId

         --	required in the RS for the service layer...

         ,@EcoLabAccountNumber			AS EcoLabAccountNumber
         ,@ControllerId					AS ControllerId
         ,CC.TopicName						AS ControllerName
         ,CC.ControllerTypeId				AS ControllerTypeId
         ,T.LfsChemicalName					AS LfsChemicalName
         ,T.KFactor							AS KFactor
         ,T.TunnelHold						AS TunnelHold
         ,T.FlowDetectorType				AS FlowDetectorType
         ,T.FlowSwitchAlarm					AS FlowSwitchAlarm
         ,T.FlowMeterAlarm				AS FlowMeterAlarm
         ,T.FlowMeterType					AS FlowMeterType
         ,T.FlowAlarmDelay				AS FlowAlarmDelay
         ,T.FlowMeterPumpDelay				AS FlowMeterPumpDelay
         ,T.FlowMeterAlarmDelay			AS FlowMeterAlarmDelay
         ,( 
            SELECT MTS.TagAddress
            FROM TCD.ModuleTags MTS
            WHERE MTS.TagType = @TagTypeLfs
              AND MTS.ModuleID = ControllerEquipmentSetupId
              AND MTS.ModuleTypeId = 4
              AND MTS.Active = 1
          ) AS LfsChemicalNameTag
         ,( 
            SELECT MTS.TagAddress
            FROM TCD.ModuleTags MTS
            WHERE MTS.TagType = @TagTypeKfactor
              AND MTS.ModuleID = ControllerEquipmentSetupId
              AND MTS.ModuleTypeId = 4
              AND MTS.Active = 1
          ) AS KfactorTag
         ,( 
            SELECT MTS.TagAddress
            FROM TCD.ModuleTags MTS
            WHERE MTS.TagType = @TagTypeCalibration
              AND MTS.ModuleID = ControllerEquipmentSetupId
              AND MTS.ModuleTypeId = 4
              AND MTS.Active = 1
          ) AS CalibrationTag

         --Synch./Central integration additions

         ,T.LastModifiedTime				AS LastModifiedTime
         ,T.LastSyncTime					AS LastSyncTime
         FROM #Equipment T JOIN TCD.ConduitController CC ON CC.ControllerId = @ControllerId
         WHERE	T.IsActive = ISNULL( @IsActive, T.IsActive
                                  )
           AND T.ControllerEquipmentId = ISNULL( @ControllerEquipmentId, T.ControllerEquipmentId);

         --exit

         SET	NOCOUNT	OFF;
         RETURN	(@ReturnValue);
     END;
GO
 IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetControllerEquipmentList]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetControllerEquipmentList
	END
GO  
CREATE PROCEDURE [TCD].[GetControllerEquipmentList]                  
  @EcoLabAccountNumber     NVARCHAR(1000)                  
    , @ControllerId       INT                  
    , @ControllerEquipmentId     TINYINT = NULL                  
    , @IsActive       BIT = NULL                  
AS
BEGIN
    SET NOCOUNT ON;                  
    DECLARE                  
     @ErrorMessage         NVARCHAR(4000)                  
     ,@PumpValveCount        TINYINT                  
     ,@MECount          TINYINT                  
     ,@ControllerEquipmentTypeId_PumpValve    TINYINT                  
     ,@ControllerEquipmentTypeId_ME      TINYINT                  
     ,@ControllerModelId        INT                  
     ,@ReturnValue         INT = 0                  
     ,@TagTypeLfs         VARCHAR(100) = 'Tag_NML'                  
     ,@TagTypeKfactor         VARCHAR(100) = 'Tag_PPOL'                  
     ,@TagTypeCalibration        VARCHAR(100) = 'Tag_OPSL'            
 ,@ControllerTypeId INT;                  

    CREATE TABLE #Equipment (                  
    ControllerEquipmentId     INT    IDENTITY(1, 1)                  
  , ControllerEquipmentTypeId     TINYINT   NULL                  
  , IsActive        BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , ProductId        INT    NULL                  
  , ProductName       NVARCHAR(255)  NULL                  
  , PumpCalibration       DECIMAL(18, 3)  NULL                  
  , FlowMeterSwitchFlag      BIT    NULL                  
  , FlowMeterCalibration      INT    NULL                  
  , MaximumDosingTime      SMALLINT   NULL                  
  , FlowSwitchTimeOut       decimal(18,1)   NULL                  
  , ControllerEquipmentSetupId    SMALLINT   NULL                  
  , LfsChemicalName       NVARCHAR(200)  NULL                  
  , KFactor        DECIMAL(18, 2)  NULL                  
  , TunnelHold        BIT    NULL                  
  , FlowDetectorType      INT    NULL                  
  , FlowSwitchAlarm       BIT    NULL                  
  , FlowMeterAlarm       BIT    NULL                  
  , FlowMeterType       INT    NULL                  
  , FlowAlarmDelay       DECIMAL(18, 2)    NULL                  
  , FlowMeterPumpDelay      DECIMAL(18, 2)    NULL                  
  , FlowMeterAlarmDelay      DECIMAL(18, 2)    NULL                  
  , LastModifiedTime      DATETIME   NULL                  
  , LastSyncTime       DATETIME   NULL                  
  , ControllerEquipmentTypeModelID    INT    NULL                  
  , ConventionalWasherGroupConnection   BIT    NOT NULL                  
              DEFAULT                  
              0                  
  , AxillaryPumpCalibration     SMALLINT   NULL                  
  , FlowmeterSwitchActivated     BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , FlushWhileDosing      BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , WeightControlledDosage     BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , EquipmentDoseAlone      BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , LowLevelAlarm       BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , LeakageAlarm       BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , FlushTime        SMALLINT   NULL                  
  , PumpingTime       SMALLINT   NULL                  
  , PreFlushTime       SMALLINT   NULL                  
  , NightFlushPauseTime      SMALLINT   NULL                  
  , NightFlushTime       SMALLINT   NULL                  
  , AcceptedDeviation      SMALLINT   NULL                 
  , LineNumber    tinyint NULL DEFAULT 0                
  , DirectDosingFlag      BIT    NULL                  
              DEFAULT                  
              'FALSE'               
  , DirectDosingMachineInternalId    INT    NULL                  
  , DirectDosingTunnelCompartmentId   INT    NULL                  
  , WasherGroupTypeId     INT    NULL                 
  , NumberOfCompartments     INT    NULL                   
  , FlushValveNumber      TINYINT   NULL                
  , CalibrationConductSS_Tank    DECIMAL(18,2)   NULL                
  , BackFlowControl       BIT    NULL                
  , FactorFM_B_FM       SMALLINT         NULL                
  , AcceptedDeviationRingLine    SMALLINT  NULL                
  , UsePumpOfGroup1ForTunnel    BIT    NULL                
  , pHSensorEnabled       BIT    NULL                
  , Concentration    INT    NULL              
  , Deadband              BIT    NULL             
  , WasherGroupNumber    INT     NULL           
  , ValveOutputAsTom  BIT NOT NULL DEFAULT  'FALSE'          
  , FlowSwitchNumber int  NULL           
  , FlushTimeForFlushValve int NULL      
    , MinimumFlowRate INT NULL    
  , ProductDensity DECIMAL(18,2) NULL    
  , MaximumConcentration INT NULL  
  , DosingLineMode INT NULL  
   );                  
    IF NOT EXISTS ( SELECT 1                  
        FROM TCD.ConduitController   CC                  
        WHERE CC.EcoalabAccountNumber = @EcoLabAccountNumber                  
AND CC.ControllerId = @ControllerId                  
    )                  
    BEGIN                  
    SET   @ErrorMessage = 'Invalid Plant/Controller combination specified';                  
    RAISERROR (@ErrorMessage, 16, 1);                  
    SET  @ReturnValue = -1;                  
    RETURN                  
    @ReturnValue;                  
    END;                  
    SET @ControllerTypeId = (SELECT ControllerTypeid            
       FROM TCD.ConduitController CC            
       WHERE CC.ControllerId = @ControllerId);            
    SELECT @ControllerModelId = CC.ControllerModelId                  
  FROM TCD.ConduitController CC                  
  WHERE CC.ControllerId = @ControllerId;                  
    SELECT @ControllerEquipmentTypeId_PumpValve = CASE                  
              WHEN CET.ControllerEquipmentTypeName = 'Pump/Valve'                  
              THEN CET.ControllerEquipmentTypeId                  
              ELSE @ControllerEquipmentTypeId_PumpValve                  
              END                  
     , @ControllerEquipmentTypeId_ME = CASE                  
           WHEN CET.ControllerEquipmentTypeName = 'ME'                  
           THEN CET.ControllerEquipmentTypeId                  
           ELSE @ControllerEquipmentTypeId_ME                  
           END                  
  FROM TCD.ControllerEquipmentType CET                  
  WHERE CET.ControllerEquipmentTypeName   IN   ('Pump/Valve', 'ME');                  
    IF (@ControllerModelId <> 7 AND @ControllerModelId  <> 8 AND @ControllerModelId <> 9 AND @ControllerModelId <> 11      
    AND @ControllerModelId <> 10 AND @ControllerModelId <> 14)                
    BEGIN                  
    SELECT @PumpValveCount = ISNULL(CSD.Value, 0)                  
      FROM TCD.ConduitController CC                  
       JOIN                  
       TCD.ControllerModelControllerTypeMapping CMCTM ON CC.ControllerModelId = CMCTM.ControllerModelId                  
       JOIN                  
       TCD.ControllerSetupData CSD ON CSD.ControllerId = CC.ControllerId                  
          AND CC.ControllerTypeId = CMCTM.ControllerTypeId                  
       JOIN                  
       TCD.FieldGroup FG ON FG.ControllerModelId = CC.ControllerModelId                  
        AND FG.ControllerTypeId = CC.ControllerTypeId                  
        AND FG.TabId = 3                  
       INNER JOIN                  
       TCD.FieldGroupFieldMapping FGM ON FGM.FieldGroupId = FG.Id                  
       INNER JOIN            
       TCD.Field F ON F.Id = FGM.FieldId                  
      AND CSD.FieldId = f.Id                  
      WHERE CC.ControllerId = @ControllerId                  
    AND F.ResourceKey = 'No._of_Chemical_Valves'                  
    AND CSD.EcolabAccountNumber = @EcoLabAccountNumber;                  
    SELECT @MECount = ISNULL(CMCTM.MECount, 0)                  
      FROM TCD.ConduitController CC                  
       JOIN                  
       TCD.ControllerModelControllerTypeMapping CMCTM ON CC.ControllerModelId = CMCTM.ControllerModelId                  
             AND CC.ControllerTypeId = CMCTM.ControllerTypeId                  
      WHERE CC.ControllerId = @ControllerId;                  
    END;         
    ELSE IF(@ControllerModelId = 11)                
    BEGIN                
    SELECT @PumpValveCount = 2*CMCTM.PumpValveCount                
     , @MECount = 2*CMCTM.MECount                
      FROM TCD.ControllerModelControllerTypeMapping CMCTM                
      WHERE CMCTM.ControllerModelId = @ControllerModelId;                
    END;                
  ELSE IF(@ControllerModelId = 7 OR @ControllerModelId = 8 OR @ControllerModelId = 9 OR @ControllerModelId = 10  OR @ControllerModelId = 14)                
  BEGIN                
    SELECT @PumpValveCount = CMCTM.PumpValveCount            
 , @MECount = CMCTM.MECount            
  FROM TCD.ControllerModelControllerTypeMapping CMCTM            
  WHERE CMCTM.ControllerModelId = @ControllerModelId            
    AND CMCTM.ControllerTypeId = @ControllerTypeId;                
    END;                
    IF (SELECT ISNULL(@PumpValveCount, 0)                  
    +                  
    ISNULL(@MECount, 0)) = 0                  
    BEGIN                  
    SELECT                  
    T.ControllerEquipmentId  AS   ControllerEquipmentId                  
  , T.ControllerEquipmentTypeId  AS   ControllerEquipmentTypeId                  
  , T.IsActive     AS   IsActive                  
  , T.ProductId     AS   ProductId                  
  , T.ProductName    AS   ProductName                  
  , T.PumpCalibration    AS   PumpCalibration                  
  , T.FlowMeterSwitchFlag   AS   FlowMeterSwitchFlag                  
  , T.MaximumDosingTime   AS   MaximumDosingTime                  
  , T.FlowSwitchTimeOut   AS   FlowSwitchTimeOut                  
  , T.ControllerEquipmentSetupId AS   ControllerEquipmentSetupId                  
  , @EcoLabAccountNumber   AS   EcoLabAccountNumber                  
  , @ControllerId    AS   ControllerId                  
  , CC.TopicName     AS   ControllerName                  
  , CC.ControllerTypeId   AS   ControllerTypeId                  
  , T.LfsChemicalName    AS   LfsChemicalName                  
  , T.KFactor     AS   KFactor                  
  , T.TunnelHold     AS   TunnelHold                  
  , T.FlowDetectorType   AS   FlowDetectorType                  
  , T.FlowSwitchAlarm    AS   FlowSwitchAlarm                  
  , T.FlowMeterAlarm    AS   FlowMeterAlarm                  
  , T.FlowMeterType    AS   FlowMeterType                  
  , T.FlowAlarmDelay    AS   FlowAlarmDelay                  
  , T.FlowMeterPumpDelay   AS   FlowMeterPumpDelay                  
  , T.FlowMeterAlarmDelay   AS   FlowMeterAlarmDelay                  
  , T.ControllerEquipmentTypeModelID                  
  , T.ConventionalWasherGroupConnection                  
  , T.AxillaryPumpCalibration                  
  , T.FlowmeterSwitchActivated                  
  , T.FlushWhileDosing                  
  , T.WeightControlledDosage                  
  , T.EquipmentDoseAlone                  
  , T.LowLevelAlarm                  
  , T.LeakageAlarm                  
  , T.FlushTime                  
  , T.PumpingTime                  
  , T.PreFlushTime                  
  , T.NightFlushPauseTime                  
  , T.NightFlushTime                  
  , T.AcceptedDeviation                 
  , T.LineNumber                 
  , T.DirectDosingFlag        
  , T.DirectDosingMachineInternalId                  
  , T.DirectDosingTunnelCompartmentId             
  , T.WasherGroupTypeId                     
  , T.NumberOfCompartments                     
  , T.FlushValveNumber                      
  , T.CalibrationConductSS_Tank                   
  , T.BackFlowControl                       
  , T.FactorFM_B_FM                      
  , T.AcceptedDeviationRingLine                    
  , T.UsePumpOfGroup1ForTunnel      
  , T.pHSensorEnabled               
  , T.Concentration                 
  , T.Deadband             
  , T.WasherGroupNumber             
  , T.ValveOutputAsTom            
  , T.FlowSwitchNumber           
  , T.FlushTimeForFlushValve      
   , T.MinimumFlowRate     
  , T.ProductDensity     
  , T.MaximumConcentration  
  ,T.DosingLineMode  
  , (                  
    SELECT MTS.TagAddress                  
      FROM TCD.ModuleTags MTS                  
      WHERE MTS.TagType = @TagTypeLfs                  
    AND MTS.ModuleID = ControllerEquipmentSetupId                  
    AND MTS.ModuleTypeId = 4                  
    AND MTS.Active = 1) AS LfsChemicalNameTag                  
  , (         
    SELECT MTS.TagAddress                  
      FROM TCD.ModuleTags MTS                  
      WHERE MTS.TagType = @TagTypeKfactor                  
    AND MTS.ModuleID = ControllerEquipmentSetupId                  
    AND MTS.ModuleTypeId = 4                  
    AND MTS.Active = 1) AS KfactorTag                  
  , (                  
    SELECT MTS.TagAddress                  
      FROM TCD.ModuleTags MTS                  
      WHERE MTS.TagType = @TagTypeCalibration                  
    AND MTS.ModuleID = ControllerEquipmentSetupId                  
    AND MTS.ModuleTypeId = 4                  
    AND MTS.Active = 1) AS CalibrationTag                  
  , T.LastModifiedTime  AS  LastModifiedTime                  
  , T.LastSyncTime   AS  LastSyncTime                  
      FROM #Equipment  T                  
    JOIN                  
    TCD.ConduitController CC                  
    ON CC.ControllerId = @ControllerId                  
      WHERE T.IsActive = ISNULL(@IsActive, T.IsActive)                  
    AND T.ControllerEquipmentId = ISNULL(@ControllerEquipmentId, T.ControllerEquipmentId);                  
    RETURN                  
    @ReturnValue;               

    END;             
    ELSE          
    BEGIN          
    IF ((SELECT ISNULL(@PumpValveCount, 0)                  
    +                  
    ISNULL(@MECount, 0)) = (SELECT COUNT(*) FROM TCD.ControllerEquipmentSetup CES     WHERE CES.ControllerId    = @ControllerId))          
      BEGIN          
      SET IDENTITY_INSERT #Equipment ON          
      INSERT INTO #Equipment (ControllerEquipmentId, ControllerEquipmentTypeId)             
      SELECT CES.ControllerEquipmentId, CES.ControllerEquipmentTypeId FROM TCD.ControllerEquipmentSetup CES WHERE CES.ControllerId = @ControllerId           
      SET IDENTITY_INSERT #Equipment OFF          
      END
	  ELSE
	  BEGIN
		 IF ISNULL(@PumpValveCount, 0) <> 0                  
    BEGIN                  
    WITH NumCTE (N)                  
    AS(SELECT '*' AS N                  
  UNION ALL                  
       SELECT '*' AS N)                  
    INSERT INTO #Equipment (ControllerEquipmentTypeId)                  
    SELECT TOP (@PumpValveCount) @ControllerEquipmentTypeId_PumpValve                  
      FROM NumCTE N1, NumCTE N2, NumCTE N3, NumCTE N4, NumCTE N5;                  
    END;                  
    IF ISNULL(@MECount, 0) <> 0                  
    BEGIN                  
    WITH NumCTE (N)                  
    AS (SELECT '*' AS N                  
    UNION ALL                  
    SELECT '*' AS N)                  
    INSERT INTO #Equipment(ControllerEquipmentTypeId)                  
    SELECT TOP (@MECount)@ControllerEquipmentTypeId_ME                  
      FROM NumCTE N1, NumCTE N2, NumCTE N3, NumCTE N4, NumCTE N5;                  
    END;   
	  END          
    END           
    UPDATE U                  
  SET U.IsActive = CES.IsActive                  
    , U.ProductId = CES.ProductId                  
    , U.ProductName = (SELECT ISNULL(NULLIF(PM.EnvisionDisplayName, ' '),PM.Name)                  
         FROM TCD.ProductMaster PM                  
         WHERE PM.ProductId = CES.ProductId)                  
    , U.PumpCalibration = CES.PumpCalibration                  
    , U.FlowMeterSwitchFlag = CES.FlowMeterSwitchFlag                  
    , U.MaximumDosingTime = CES.MaximumDosingTime                  
    , U.FlowSwitchTimeOut = CES.FlowSwitchTimeOut                  
    , U.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId                  
    , U.LfsChemicalName = CES.LfsChemicalName                  
    , U.KFactor = CES.KFactor                  
    , U.TunnelHold = CES.TunnelHold                  
    , U.FlowDetectorType = CES.FlowDetectorType                  
    , U.FlowSwitchAlarm = CES.FlowSwitchAlarm                  
    , U.FlowMeterAlarm = CES.FlowMeterAlarm                  
    , U.FlowMeterType = CES.FlowMeterType                  
    , U.FlowAlarmDelay = CES.FlowAlarmDelay                  
    , U.FlowMeterPumpDelay = CES.FlowMeterPumpDelay                  
    , U.FlowMeterAlarmDelay = CES.FlowMeterAlarmDelay                  
    , U.ControllerEquipmentTypeModelID = CES.ControllerEquipmentTypeModelID                  
    , U.ConventionalWasherGroupConnection = CES.ConventionalWasherGroupConnection                  
    , U.AxillaryPumpCalibration = CES.AxillaryPumpCalibration                  
    , U.FlowmeterSwitchActivated = CES.FlowmeterSwitchActivated                  
    , U.FlushWhileDosing = CES.FlushWhileDosing                  
    , U.WeightControlledDosage = CES.WeightControlledDosage                  
    , U.EquipmentDoseAlone = CES.EquipmentDoseAlone                  
    , U.LowLevelAlarm = CES.LowLevelAlarm                  
    , U.LeakageAlarm = CES.LeakageAlarm                  
    , U.FlushTime = CES.FlushTime                  
    , U.PumpingTime = CES.PumpingTime                  
    , U.PreFlushTime = CES.PreFlushTime                  
    , U.NightFlushPauseTime = CES.NightFlushPauseTime                  
    , U.NightFlushTime = CES.NightFlushTime                  
    , U.AcceptedDeviation = CES.AcceptedDeviation                 
    , U.LineNumber = CES.LineNumber                 
    , U.DirectDosingFlag = TCEVM.DirectDosingFlag                  
    , U.DirectDosingMachineInternalId = TCEVM.TunnelNumber                  
    , U.DirectDosingTunnelCompartmentId = TCEVM.CompartmentNumber                
    , U.LastModifiedTime = CES.LastModifiedTime                  
    , U.LastSyncTime = CES.LastSyncTime                
    , U.FlushValveNumber      = CES.FlushValveNumber                
  , U.CalibrationConductSS_Tank    = CES.CalibrationConductSS_Tank              
  , U.BackFlowControl     = CES.BackFlowControl                  
  , U.FactorFM_B_FM       = CES.FactorFM_B_FM               
  , U.AcceptedDeviationRingLine  = CES.AcceptedDeviationRingLine                  
  , U.UsePumpOfGroup1ForTunnel   = CES.UsePumpOfGroup1ForTunnel              
  , U.pHSensorEnabled            = CES.pHSensorEnabled              
  , U.Concentration = CES.Concentration              
  , U.Deadband = CES.Deadband             
  , U.WasherGroupNumber = CES.WasherGroupNumber          
  , U.ValveOutputAsTom = CES.ValveOutputAsTom          
  , U.FlowSwitchNumber = CES.FlowSwitchNumber         
  , U.FlushTimeForFlushValve = CES.FlushTimeForFlushValve      
    , U.MinimumFlowRate = CES.MinimumFlowRate    
  , U.ProductDensity = CES.ProductDensity    
  , U.MaximumConcentration  = CES.MaximumConcentration    
  ,U.DosingLineMode =1 
  FROM #Equipment U                  
   JOIN                  
   TCD.ControllerEquipmentSetup CES                  
  ON U.ControllerEquipmentId = CES.ControllerEquipmentId                  
  AND U.ControllerEquipmentTypeId = CES.ControllerEquipmentTypeId               
  JOIN TCD.ConduitController CC ON CES.ControllerID = CC.ControllerId                
  LEFT JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId                
  LEFT JOIN TCD.WasherGroup WG ON CES.ControllerID = WG.ControllerID                 
  LEFT JOIN TCD.MachineSetup MS ON WG.ControllerId = MS.ControllerId          
  WHERE CES.EcoLabAccountNumber = @EcoLabAccountNumber                  
   AND CES.ControllerId = @ControllerId; 
      IF(@ControllerModelId = 7)  
   BEGIN  
   Declare @DosingLineMode varchar(100) ,@NoOfPumpsConnected  varchar(100), @Counter int  

   select @DosingLineMode =CES.Value  
       FROM TCD.ControllerSetupdata CES  
       INNER JOIN [TCD].[Field] F ON F.Id = CES.FieldId  
       AND EcoLabAccountNumber=@EcoLabAccountNumber  
       AND ControllerId=@ControllerId  
       AND ResourceKey ='Dosing_Line_Mode1'  

--CREATE	TABLE		#Equipment	(
--					ControllerEquipmentId					INT				IDENTITY(1, 1)
--				,	ControllerEquipmentTypeId				TINYINT			NOT	NULL

--				,	IsActive								BIT				NOT	NULL		DEFAULT('FALSE')
--				,	ProductId								INT				NULL
--				,	ProductName								NVARCHAR(255)	NULL			--ProductMaster
--				,	PumpCalibration							DECIMAL(18, 3)	NULL
--				,	FlowMeterSwitchFlag						BIT				NULL			--NULL (not set), 0 for Meter, 1 for Switch
--				,	FlowMeterCalibration					INT				NULL
--				,	MaximumDosingTime						SMALLINT		NULL
--				,	FlowSwitchTimeOut						SMALLINT		NULL

--				,	ControllerEquipmentSetupId				SMALLINT		NULL

--				, LfsChemicalName							NVARCHAR(200)	NULL
--				, KFactor									DECIMAL(18,2)	NULL
--				, TunnelHold								BIT				NULL
--				, FlowDetectorType							INT				NULL
--				, FlowSwitchAlarm							BIT				NULL
--				,	FlowMeterAlarm							BIT				NULL
--				,	FlowMeterType							INT				NULL
--				,	FlowAlarmDelay							DECIMAL(18, 2)	NULL				
--				, FlowMeterPumpDelay						DECIMAL(18, 2)				NULL
--				,	FlowMeterAlarmDelay						DECIMAL(18, 2)				NULL
--				--Synch./Central integration additions
--				,	LastModifiedTime						DATETIME		NULL
--				,	LastSyncTime							DATETIME		NULL
--				)

--select @DosingLineMode  

IF RTRIM( LTRIM(@DosingLineMode)) ='2'  
		BEGIN
 set @Counter = 1;  
       select @NoOfPumpsConnected = CES.Value   
       FROM TCD.ControllerSetupdata CES  
              INNER JOIN [TCD].[Field] F ON F.Id = CES.FieldId  
              AND EcoLabAccountNumber=@EcoLabAccountNumber  
              AND ControllerId=@ControllerId  
              AND ResourceKey ='No_of_Pumps_Connected_to_TCR1'  
       select @NoOfPumpsConnected = cast(@NoOfPumpsConnected as int)  
       update A set A.LineNumber =1,  
       A.DosingLineMode = 2  
       from #Equipment A where   ControllerEquipmentId >= 1 and ControllerEquipmentId <= @NoOfPumpsConnected  
		END


select @DosingLineMode =CES.Value  
       FROM TCD.ControllerSetupdata CES  
       INNER JOIN [TCD].[Field] F ON F.Id = CES.FieldId  
       AND EcoLabAccountNumber=@EcoLabAccountNumber  
       AND ControllerId=@ControllerId  
       AND ResourceKey ='Dosing_Line_Mode2'  

--select @DosingLineMode  

IF RTRIM( LTRIM(@DosingLineMode)) ='2'  
	BEGIN

 set @Counter = 9;  
       select @NoOfPumpsConnected = CES.Value   
       FROM TCD.ControllerSetupdata CES  
              INNER JOIN [TCD].[Field] F ON F.Id = CES.FieldId  
              AND EcoLabAccountNumber=@EcoLabAccountNumber  
              AND ControllerId=@ControllerId  
              AND ResourceKey ='No_of_Pumps_Connected_to_TCR2'  
       SET @NoOfPumpsConnected = cast(@NoOfPumpsConnected as int)  
       SET @NoOfPumpsConnected = @NoOfPumpsConnected + @Counter ;  
       update A set A.LineNumber =2,  
       A.DosingLineMode = 2  
       from #Equipment A where   ControllerEquipmentId BETWEEN  @Counter and  @NoOfPumpsConnected  
	END


select @DosingLineMode =CES.Value  
       FROM TCD.ControllerSetupdata CES  
       INNER JOIN [TCD].[Field] F ON F.Id = CES.FieldId  
       AND EcoLabAccountNumber=@EcoLabAccountNumber  
       AND ControllerId=@ControllerId  
       AND ResourceKey ='Dosing_Line_Mode3'  

--select @DosingLineMode  

IF RTRIM( LTRIM(@DosingLineMode)) ='2'  
BEGIN
 set @Counter = 17;  
       select @NoOfPumpsConnected = CES.Value   
       FROM TCD.ControllerSetupdata CES  
              INNER JOIN [TCD].[Field] F ON F.Id = CES.FieldId  
              AND EcoLabAccountNumber=@EcoLabAccountNumber  
              AND ControllerId=@ControllerId  
              AND ResourceKey ='No_of_Pumps_Connected_to_TCR3'  
       SET @NoOfPumpsConnected = cast(@NoOfPumpsConnected as int)  
       SET @NoOfPumpsConnected = @NoOfPumpsConnected + @Counter ;  
       update A set A.LineNumber =3,  
       A.DosingLineMode = 2  
       from #Equipment A where   ControllerEquipmentId BETWEEN  @Counter and  @NoOfPumpsConnected  
END


   END 

   IF(@ControllerModelId = 11)                
   BEGIN            
   UPDATE U             
   SET U.WasherGroupTypeId = (SELECT MIN(WG.WasherGroupTypeId) FROM TCD.WasherGroup WG WHERE WG.ControllerId = @ControllerId)            
    FROM #Equipment U                  
JOIN                  
   TCD.ControllerEquipmentSetup CES                  
  ON U.ControllerEquipmentId = CES.ControllerEquipmentId                  
  AND U.ControllerEquipmentTypeId = CES.ControllerEquipmentTypeId                
  WHERE CES.EcoLabAccountNumber = @EcoLabAccountNumber                  
   AND CES.ControllerId = @ControllerId            
   AND CES.ControllerEquipmentId IN (select top 14 CES.ControllerEquipmentId FROM  TCD.ControllerEquipmentSetup CES            
   where CES.ControllerId = @ControllerId )            

     UPDATE U             
   SET U.WasherGroupTypeId = (SELECT MAX(WG.WasherGroupTypeId) FROM TCD.WasherGroup WG WHERE WG.ControllerId = @ControllerId)            
    FROM #Equipment U                  
   JOIN                  
   TCD.ControllerEquipmentSetup CES                  
  ON U.ControllerEquipmentId = CES.ControllerEquipmentId                  
  AND U.ControllerEquipmentTypeId = CES.ControllerEquipmentTypeId               
  JOIN TCD.ConduitController CC ON CES.ControllerID = CC.ControllerId         
  WHERE CES.EcoLabAccountNumber = @EcoLabAccountNumber                  
   AND CES.ControllerId = @ControllerId            
   AND CES.ControllerEquipmentId IN (select  CES.ControllerEquipmentId FROM TCD.ControllerEquipmentSetup CES            
    where CES.ControllerId = @ControllerId AND             
    CES.ControllerEquipmentId BETWEEN 15 AND 28 )        

   UPDATE U SET U.NumberOfCompartments = ms.NumberOfComp        
   FROM #Equipment U        
   INNER JOIN TCD.ControllerEquipmentSetup ces        
   ON u.ControllerEquipmentId = ces.ControllerEquipmentId         
   INNER JOIN TCD.WasherGroup wg ON ces.ControllerId = WG.ControllerId        
   INNER JOIN TCD.MachineSetup ms ON ms.ControllerId = ces.ControllerId AND ms.GroupId = WG.WasherGroupId        
   WHERE ces.ControllerId = @ControllerId AND U.WasherGroupTypeId = 2  AND ms.IsTunnel = 1 AND WG.WasherDosingNumber = U.WasherGroupNumber        
   END          

  -- END                
    GOTO ExitModule;                  
ExitModule:
    SELECT                  
    T.ControllerEquipmentId   AS ControllerEquipmentId                  
  , T.ControllerEquipmentTypeId AS ControllerEquipmentTypeId                  
  , T.IsActive      AS IsActive                  
  , T.ProductId     AS ProductId                  
  , T.ProductName     AS ProductName                  
  , T.PumpCalibration    AS PumpCalibration                  
  , T.FlowMeterSwitchFlag   AS FlowMeterSwitchFlag                  
  , T.MaximumDosingTime    AS MaximumDosingTime                  
  , T.FlowSwitchTimeOut    AS FlowSwitchTimeOut                  
  , T.ControllerEquipmentSetupId  AS ControllerEquipmentSetupId                  
  , @EcoLabAccountNumber    AS EcoLabAccountNumber                  
  , @ControllerId     AS ControllerId                  
  , CC.TopicName     AS ControllerName                  
  , CC.ControllerTypeId    AS ControllerTypeId                  
  , T.LfsChemicalName    AS LfsChemicalName                  
  , T.KFactor      AS KFactor                  
  , T.TunnelHold     AS TunnelHold                  
  , T.FlowDetectorType    AS FlowDetectorType                  
, T.FlowSwitchAlarm    AS FlowSwitchAlarm                  
  , T.FlowMeterAlarm    AS FlowMeterAlarm                  
  , T.FlowMeterType     AS FlowMeterType                  
 , T.FlowAlarmDelay    AS FlowAlarmDelay                  
  , T.FlowMeterPumpDelay    AS FlowMeterPumpDelay                  
  , T.FlowMeterAlarmDelay   AS FlowMeterAlarmDelay                  
  , (                  
    SELECT MTS.TagAddress                  
  FROM TCD.ModuleTags MTS                  
  WHERE MTS.TagType = @TagTypeLfs                  
    AND MTS.ModuleID = ControllerEquipmentSetupId                  
    AND MTS.ModuleTypeId = 4                  
    AND MTS.Active = 1) AS LfsChemicalNameTag                  
  , (                  
    SELECT MTS.TagAddress                  
  FROM TCD.ModuleTags MTS                  
  WHERE MTS.TagType = @TagTypeKfactor                  
    AND MTS.ModuleID = ControllerEquipmentSetupId                  
    AND MTS.ModuleTypeId = 4                  
    AND MTS.Active = 1) AS KfactorTag                  
  , (                  
    SELECT MTS.TagAddress                  
  FROM TCD.ModuleTags MTS                  
  WHERE MTS.TagType = @TagTypeCalibration                  
    AND MTS.ModuleID = ControllerEquipmentSetupId                  
    AND MTS.ModuleTypeId = 4                  
    AND MTS.Active = 1) AS CalibrationTag                  
  , T.ControllerEquipmentTypeModelID                  
  , T.ConventionalWasherGroupConnection                  
  , T.AxillaryPumpCalibration                  
  , T.FlowmeterSwitchActivated                  
  , T.FlushWhileDosing                  
  , T.WeightControlledDosage                  
  , T.EquipmentDoseAlone                  
  , T.LowLevelAlarm                  
  , T.LeakageAlarm                  
  , T.FlushTime                  
  , T.PumpingTime                  
  , T.PreFlushTime                  
  , T.NightFlushPauseTime                  
  , T.NightFlushTime                  
  , T.AcceptedDeviation                  
  , T.LineNumber                
  , T.DirectDosingFlag                  
  , T.DirectDosingMachineInternalId                  
  , T.DirectDosingTunnelCompartmentId                  
  , T.LastModifiedTime    AS LastModifiedTime                  
  , T.LastSyncTime     AS LastSyncTime             
  , T.WasherGroupTypeId                     
  , T.NumberOfCompartments                     
  , T.FlushValveNumber                      
  , T.CalibrationConductSS_Tank                   
  , T.BackFlowControl                       
  , T.FactorFM_B_FM                      
  , T.AcceptedDeviationRingLine                    
  , T.UsePumpOfGroup1ForTunnel                    
  , T.pHSensorEnabled                
  , T.Concentration              
  , T.Deadband              
  , T.WasherGroupNumber          
  , T.ValveOutputAsTom          
  , T.FlowSwitchNumber          
  , T.FlushTimeForFlushValve      
    , T.MinimumFlowRate     
  , T.ProductDensity     
  , T.MaximumConcentration   
  , T.DosingLineMode 
  FROM #Equipment T                  
   JOIN                  
   TCD.ConduitController CC ON CC.ControllerId = @ControllerId                  
  WHERE T.IsActive = ISNULL(@IsActive, T.IsActive)                  
   AND T.ControllerEquipmentId = ISNULL(@ControllerEquipmentId, T.ControllerEquipmentId)        
   ORDER BY  T.ControllerEquipmentId;                  
    SET NOCOUNT OFF;                  
    RETURN                  
    @ReturnValue;                  
END;   

GO
UPDATE TCD.ConfigSettings
SET
    [Value] = N'20'
WHERE KeyName = N'NoOfRecordsToBeProcessed'
    AND [Type] = N'SyncBatchData'
GO

IF EXISTS(SELECT
				  *
			  FROM sys.objects
			  WHERE object_id = OBJECT_ID(N'[TCD].[GetPlantChainProgramByPlantChainId]')
				AND type IN(N'P', N'PC'))
	BEGIN
		DROP PROCEDURE
				TCD.GetPlantChainProgramByPlantChainId
	END
GO

/*

Stored Procedure	:	[TCD].[GetPlantChainProgramByPlantChainId]	in	TRASAR3 Db

Purpose				:	To get plant chain program details for particular palnt chain

Parameters			:	None
							
*/

CREATE PROCEDURE TCD.GetPlantChainProgramByPlantChainId
	   @Plantchainid INT = NULL
AS
BEGIN
	SET NOCOUNT ON;

	SELECT	DISTINCT pcp.PlantProgramId, 
			pcp.PlantProgramName, 
			pcp.ChainTextileCategoryId AS ChainTextileId,
			ctc.Name AS ChainTextileName, 
			etc.TextileId AS EcolabTextileCategoryId, 
			etc.CategoryName AS EcolabTextileCategoryName, 	  
			fs.FormulaSegmentID, 
			fs.SegmentName,
			pcp.LastModifiedTime, 
			pcp.Is_Deleted, 
			pcp.PlantChainId,
			es.EcolabSaturationId, 
			es.EcolabSaturationName
	FROM TCD.PlantChainProgram AS pcp
	INNER JOIN TCD.Plant p ON p.PlantChainId = pcp.PlantChainId 
  LEFT JOIN TCD.ChainTextileCategory ctc
  ON pcp.ChainTextileCategoryId = ctc.TextileId AND ctc.PlantChainId = pcp.PlantChainId
  LEFT JOIN TCD.EcolabTextileCategory etc
  ON pcp.EcolabTextileCategoryId = etc.TextileId
  LEFT JOIN TCD.EcolabSaturation es
  ON pcp.EcolabSaturationId = es.EcolabSaturationId
  LEFT JOIN TCD.FormulaSegments fs
  ON pcp.FormulaSegmentId = fs.FormulaSegmentID
  WHERE pcp.PlantChainId = @Plantchainid

END
GO