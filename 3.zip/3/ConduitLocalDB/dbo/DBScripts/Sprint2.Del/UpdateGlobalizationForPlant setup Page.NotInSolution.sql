﻿/*  
 ==========================================================================================  
 Purpose:  Changes the Feild names as per the Globalization  

 Author:  Neetha Allati

 --------------------------------------------------------------  
 Aug-23-2014 ENT: Initial version.  
 ==========================================================================================  
*/ 

DECLARE @TESTNG INT, @SEERESULT INT

SET @TESTNG = 0 -- 1 FOR ROLLBACK, 0 FOR COMMIT
SET @SEERESULT = 1


BEGIN TRANSACTION

IF @SEERESULT = 1
BEGIN 
	SELECT 'BEFORE INSERT'
	select * From ResourceKeyValue where value in('Ecolab Account Number','Ecolab Account Number','Número de cuenta Ecolab','Ecolab Kontonummer'
												  ,'Budget customer/Flat Fee','Cliente Presupuesto / Flat Fee','Budsjett kunde / Flat Fee','Budget klant / Flat Fee')
												 And languageID in(1,2,3,13)
END

BEGIN TRY
BEGIN
	
			IF EXISTS(SELECT 1 FROM  [dbo].ResourceKeyValue Where languageID = 1 And value = 'Ecolab Account Number')
			BEGIN
				Update ResourceKeyValue Set Value = 'Account Number' Where languageID = 1 And value = 'Ecolab Account Number'		
			END
			IF EXISTS(SELECT 1 FROM  [dbo].ResourceKeyValue Where languageID = 2 And Value = 'Ecolab Account Number')
			BEGIN
				Update ResourceKeyValue Set Value = 'Account Number' Where languageID = 2 And Value = 'Ecolab Account Number'
			END
			IF EXISTS(SELECT 1 FROM  [dbo].ResourceKeyValue Where languageID = 3 And value = 'Número de cuenta Ecolab')
			BEGIN
				Update ResourceKeyValue Set Value = 'número de cuenta' Where languageID = 3 And value = 'Número de cuenta Ecolab'	
			END
			IF EXISTS(SELECT 1 FROM  [dbo].ResourceKeyValue Where languageID = 13 And Value = 'Ecolab Kontonummer')
			BEGIN
				Update ResourceKeyValue Set Value = 'kontonummer' Where languageID = 13 And Value = 'Ecolab Kontonummer'	
			END
			IF EXISTS(SELECT 1 FROM  [dbo].ResourceKeyValue Where languageID = 1 And value = 'Budget customer/Flat Fee'	)
			BEGIN
				Update ResourceKeyValue Set Value = 'Flat Fee' Where languageID = 1 And value = 'Budget customer/Flat Fee'		
			END
			IF EXISTS(SELECT 1 FROM  [dbo].ResourceKeyValue Where languageID = 2 And Value = 'Budget klant / Flat Fee')
			BEGIN
				Update ResourceKeyValue Set Value = 'Flat Fee' Where languageID = 2 And value = 'Budget klant / Flat Fee'
			END
			IF EXISTS(SELECT 1 FROM  [dbo].ResourceKeyValue Where languageID = 3 And value = 'Cliente Presupuesto / Flat Fee')
			BEGIN
				Update ResourceKeyValue Set Value = 'Tarifa plana' Where languageID = 3 And value = 'Cliente Presupuesto / Flat Fee'
			END
			IF EXISTS(SELECT 1 FROM  [dbo].ResourceKeyValue Where languageID = 13 And Value = 'Budsjett kunde / Flat Fee')
			BEGIN
				Update ResourceKeyValue Set Value = 'flat Fee' Where languageID = 13 And value = 'Budsjett kunde / Flat Fee'	
			END
		END
END TRY

BEGIN CATCH
	SELECT
        ERROR_NUMBER() AS ErrorNumber
        ,ERROR_SEVERITY() AS ErrorSeverity
        ,ERROR_STATE() AS ErrorState
        ,ERROR_PROCEDURE() AS ErrorProcedure
        ,ERROR_LINE() AS ErrorLine
        ,ERROR_MESSAGE() AS ErrorMessage;

END CATCH

IF @SEERESULT = 1
BEGIN 
	SELECT 'AFTER INSERT'
	select * From ResourceKeyValue where value in('Account Number','Account Number','número de cuenta','kontonummer','Flat Fee','Flat Fee','Tarifa plana','flat Fee')
			And languageID in(1,2,3,13)

END

IF @@TRANCOUNT > 0
	IF @TESTNG = 0
    COMMIT TRANSACTION;
	ELSE
	ROLLBACK TRANSACTION;
ELSE
 ROLLBACK TRANSACTION;
GO

