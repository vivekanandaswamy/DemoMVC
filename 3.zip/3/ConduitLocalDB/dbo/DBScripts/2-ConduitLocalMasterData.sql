PRINT	'Starting ConduitLocalMasterData script execution...'

DECLARE		@TableName			SYSNAME			--To hold name of the table currently being populated
		,	@EcoLabAccountNumber				NVARCHAR(1000)
		,	@UserId_defaultUser					INT

SET			@EcoLabAccountNumber				=			N'40242802'
SET			@UserId_defaultUser					=			0			--we will use 0 UserId for the defaultuser, which will be a syytem created user

IF	OBJECT_ID('tempdb..#Errors_MyServiceMasterDataSetup')	IS	NULL
BEGIN
CREATE	TABLE	#Errors_ConduitLocalMasterDataSetup	(
Id					INT					IDENTITY(1, 1)
,	TableName			SYSNAME				NOT	NULL
,	ErrorNumber			INT					NOT	NULL
,	ErrorMessage		NVARCHAR(2048)		NOT	NULL
,	ErrorSeverity		INT					NOT	NULL
,	ErrorState			INT					NULL
,	ErrorProcedure		SYSNAME				NULL
,	ErrorLine			INT					NULL
)
END
ELSE
BEGIN
TRUNCATE	TABLE	#Errors_ConduitLocalMasterDataSetup
END

BEGIN	TRY
/*	UnitOfMeasure

No identity column defined.
PRIMARY KEY: UOMId
FK:	NO
Table is referenced by foreign key: UserMaster: FK_UserMaster_UnitOfMeasure

select	*	from	UnitOfMeasure
*/
BEGIN
SET			@TableName				=			'UnitOfMeasure'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempUnitOfMeasure	TABLE	(
TempId					INT				IDENTITY(1, 1)
,	UOMId					INT				NOT	NULL
,	UOM						NVARCHAR(255)
)

--Populate temp table variable with the input data
INSERT	@tempUnitOfMeasure	(
UOMId, UOM	)
VALUES	(1	,N'kWh'	)
,	(2	,N'Hr/day'	)
,	(3	,N'Hr/week'	)
,	(4	,N'Full Time Operators'	)
,	(5	,N'Hr/Vessel'	)
,	(6	,N'Gallons'	)
,	(7	,N'm³'	)
,	(8	,N'per day'	)
,	(9	,N'per week'	)
,	(10	,N'per month'	)
,	(11	,N'per year'	)
,	(12	,N'ppm'	)
,	(13	,N'ml/day'	)
,	(14	,N'm³/hr'	)
,	(15	,N'GPM'	)
,	(16	,N'Hr/event'	)
,	(17	,N'uS/cm'	)
,	(18	,N'per 1000 gallons'	)
,	(19	,N'per 1000 m3'	)
,	(20	,N'lbs/year'	)
,	(21	,N'kg/year'	)
,	(22	,N'Pails'	)
,	(23	,N'Totes'	)
,	(24	,N'Drums'	)
,	(25	,N'Days'	)
,	(26	,N'Weeks'	)
,	(27	,N'Months'	)
,	(28	,N'Years'	)
,	(29	,N'Inch'	)
,	(30	,N'%'	)
,	(31	,N'hours per day'	)
,	(32	,N'GPD'	)
,	(33	,N'm³/day'	)
,	(34	,N'ml/hr'	)
,	(35	,N'l/hr'	)
,	(36	,N'ft'	)
,	(37	,N'm'	)
,	(38	,N'atm'	)
,	(39	,N'psi'	)
,	(40	,N'lbf/ft2'	)
,	(41	,N'Pa'	)
,	(42	,N'KPa'	)
,	(43	,N'MPa'	)
,	(44	,N'torr'	)
,	(45	,N'bar'	)
,	(46	,N'in/Hg'	)
,	(47	,N'ftH2O'	)
,	(48	,N'atm(g)'	)
,	(49	,N'psi(g)'	)
,	(50	,N'lbf/ft2(g)'	)
,	(51	,N'Pa(g)'	)
,	(52	,N'kPa(g)'	)
,	(53	,N'MPa(g)'	)
,	(54	,N'torr(g)'	)
,	(55	,N'bar(g)'	)
,	(56	,N'in/Hg(g)'	)
,	(57	,N'ftH2O(g)'	)
,	(58	,N'm³s⁻¹'	)
,	(59	,N'm³min⁻¹'	)
,	(60	,N'm³h⁻¹'	)
,	(61	,N'l³s⁻¹'	)
,	(62	,N'l³min⁻¹'	)
,	(63	,N'l³h⁻¹'	)
,	(64	,N'ft³s⁻¹'	)
,	(66	,N'ft³h⁻¹'	)
,	(67	,N'gal³s⁻¹'	)
,	(68	,N'gal³min⁻¹'	)
,	(69	,N'gal³h⁻¹'	)
,	(70	,N'm³s⁻¹'	)
,	(71	,N'm³min⁻¹'	)
,	(72	,N'm³h⁻¹'	)
,	(73	,N'l³s⁻¹'	)
,	(74	,N'l³min⁻¹'	)
,	(75	,N'l³h⁻¹'	)
,	(76	,N'ft³s⁻¹'	)
,	(77	,N'ft³min⁻¹'	)
,	(78	,N'ft³h⁻¹'	)
,	(79	,N'gal³s⁻¹'	)
,	(80	,N'gal³min⁻¹'	)
,	(81	,N'gal³h⁻¹'	)
,	(86	,N'kg/sec'	)
,	(87	,N'kg/min'	)
,	(88	,N'kg/hr'	)
,	(89	,N'kg/day'	)
,	(90	,N'g/sec'	)
,	(91	,N'g/min'	)
,	(92	,N'g/hr'	)
,	(93	,N'g/day'	)
,	(94	,N'lbm/sec'	)
,	(95	,N'lbm/min'	)
,	(96	,N'lb/h'	)
,	(97	,N'lbm/day'	)
,	(98	,N'Mlbm/sec'	)
,	(99	,N'Mlbm/min'	)
,	(100	,N'Mlbm/hr'	)
,	(101	,N'Mlbm/day'	)
,	(102	,N'Litres'	)
,	(103	,N'l/day'	)
,	(104	,N'ft3/day'	)
,	(105	,N'gal/day'	)
,	(106	,N'lb/day'	)
,	(107	,N'ppm Ca'	)
,	(108	,N'ppm CaCO3'	)
,	(109	,N'ppb Ca'	)
,	(110	,N'ppb CaCO3'	)
,	(111	,N'Degree C'	)
,	(112	,N'Degree F'	)
,	(113	,N'ppm SiO2'	)
,	(114	,N'ppm Si'	)
,	(115	,N'ppb SiO2'	)
,	(116	,N'ppb Si'	)
,	(117	,N'umho/cm'	)
,	(118	,N'umho/m'	)
,	(119	,N'S'	)
,	(120	,N'mho/m'	)
,	(121	,N'ppb'	)
,	(538	,N'°C'	)
,	(539	,N'°F'	)
,	(540	,N'µg'	)
,	(541	,N'µg/L'	)
,	(542	,N'µg/L as CaCO₃'	)
,	(543	,N'µg/L as N'	)
,	(544	,N'µm'	)
,	(545	,N'µS'	)
,	(546	,N'µS/cm'	)
,	(547	,N'µS/m'	)
,	(548	,N'1/µS'	)
,	(549	,N'1/day'	)
,	(550	,N'1/h'	)
,	(551	,N'1/min'	)
,	(552	,N'1/month'	)
,	(553	,N'1/ms'	)
,	(554	,N'1/ns'	)
,	(555	,N'1/s'	)
,	(556	,N'1/wk'	)
,	(557	,N'1/yr'	)
,	(558	,N'abmho/cm'	)
,	(559	,N'abmho/m'	)
,	(560	,N'bbl'	)
,	(561	,N'bbl/h'	)
,	(562	,N'bbl/min'	)
,	(563	,N'bbl/s'	)
,	(564	,N'Btu(it)/(hr·ft·°F)'	)
,	(565	,N'Btu(it)/(hr·ft²·°F)'	)
,	(566	,N'Btu(it)/(lb·°C)'	)
,	(567	,N'Btu(it)/(lb·°F)'	)
,	(568	,N'Btu(it)/(lb·°R)'	)
,	(569	,N'Btu(it)/(sec·ft²·°F)'	)
,	(570	,N'Btu(it)/h'	)
,	(571	,N'Btu(it)/lbm'	)
,	(572	,N'Btu(it)/s'	)
,	(573	,N'Btu(it)in/(hr·ft·°F)'	)
,	(574	,N'Btu(it)in/(sec·ft²·°F)'	)
,	(575	,N'Btu(th)/(hr·ft²·°F)'	)
,	(576	,N'Btu(th)/(hr·ft²·F)'	)
,	(577	,N'Btu(th)/(lb·°F)'	)
,	(578	,N'Btu(th)/(lb·°R)'	)
,	(579	,N'Btu(th)/(sec·ft²·°F)'	)
,	(580	,N'Btu(th)/h'	)
,	(581	,N'Btu(th)/lbm'	)
,	(582	,N'Btu(th)/s'	)
,	(583	,N'Btu(th)in/(hr·ft²·F)'	)
,	(584	,N'Btu(th)in/(sec·ft²·F)'	)
,	(585	,N'BV'	)
,	(586	,N'cal(it)/(g·°C)'	)
,	(587	,N'cal(it)/(g·°K)'	)
,	(588	,N'cal(it)/(lb·°F)'	)
,	(589	,N'cal(it)/(sec·cm·°C)'	)
,	(590	,N'cal(it)/g'	)
,	(591	,N'cal(it)/h'	)
,	(592	,N'cal(it)/kg'	)
,	(593	,N'cal(it)/s'	)
,	(594	,N'cal(th)/(g·°C)'	)
,	(595	,N'cal(th)/(lb·°F)'	)
,	(596	,N'cal(th)/(sec·cm·C)'	)
,	(597	,N'cal(th)/g'	)
,	(598	,N'cal(th)/h'	)
,	(599	,N'cal(th)/kg'	)
,	(600	,N'cal(th)/s'	)
,	(601	,N'CFU/100mL'	)
,	(602	,N'CFU/mL'	)
,	(603	,N'cm'	)
,	(604	,N'cm/h'	)
,	(605	,N'cm/min'	)
,	(606	,N'cm/s'	)
,	(607	,N'cm²'	)
,	(608	,N'cm³'	)
,	(609	,N'cm³/cm³'	)
,	(610	,N'Color Units'	)
,	(611	,N'cp'	)
,	(612	,N'day'	)
,	(613	,N'dyne'	)
,	(614	,N'fraction'	)
,	(615	,N'ft/h'	)
,	(616	,N'ft/min'	)
,	(617	,N'ft/s'	)
,	(618	,N'ft/s²'	)
,	(619	,N'ft²'	)
,	(620	,N'ft³'	)
,	(621	,N'ft³/ft³'	)
,	(622	,N'ft³/h'	)
,	(623	,N'ft³/lbm'	)
,	(624	,N'ft³/min'	)
,	(625	,N'ft³/s'	)
,	(626	,N'g'	)
,	(627	,N'g/(sec·cm²)'	)
,	(628	,N'g/(sec·m²)'	)
,	(629	,N'g/cm³'	)
,	(630	,N'g/l'	)
,	(631	,N'g/m'	)
,	(632	,N'g/ml'	)
,	(633	,N'g/s'	)
,	(634	,N'gal'	)
,	(636	,N'gal/h'	)
,	(637	,N'gal/min'	)
,	(638	,N'gal/s'	)
,	(639	,N'Gj'	)
,	(640	,N'gpm/Ton'	)
,	(641	,N'h'	)
,	(642	,N'HP'	)
,	(643	,N'in'	)
,	(644	,N'in/h'	)
,	(645	,N'in/min'	)
,	(646	,N'in/s'	)
,	(647	,N'in³'	)
,	(648	,N'in³/h'	)
,	(649	,N'in³/in³'	)
,	(650	,N'in³/min'	)
,	(651	,N'in³/s'	)
,	(652	,N'J/(g·°C)'	)
,	(653	,N'J/(kg·°C)'	)
,	(654	,N'J/(kg-K)'	)
,	(655	,N'J/(sec·m²·°K)'	)
,	(656	,N'J/kg'	)
,	(657	,N'J/s'	)
,	(658	,N'K'	)
,	(659	,N'Kcal(it)/(hr·m·°C)'	)
,	(660	,N'kcal(it)/(kg·°C)'	)
,	(661	,N'kcal(it)/(kg·°K)'	)
,	(662	,N'kcal(it)/h'	)
,	(663	,N'kcal(it)/kg'	)
,	(664	,N'kcal(it)/s'	)
,	(665	,N'kcal(th)(hr·m·°C)'	)
,	(666	,N'Kcal(th)/(hr·ft·°C)'	)
,	(667	,N'kcal(th)/(kg·°C)'	)
,	(668	,N'kcal(th)/(kg·°K)'	)
,	(669	,N'kcal(th)/h'	)
,	(670	,N'kcal(th)/kg'	)
,	(671	,N'kcal(th)/s'	)
,	(672	,N'kg'	)
,	(673	,N'kg(hr·ft²)'	)
,	(674	,N'kg/(m·h)'	)
,	(675	,N'kg/(m·s)'	)
,	(676	,N'Kg/(m²·h)'	)
,	(677	,N'kg/(sec·m²)'	)
,	(678	,N'kg/h'	)
,	(679	,N'kg/m³'	)
,	(680	,N'kg/s'	)
,	(681	,N'kg/yr'	)
,	(682	,N'kg-f-m/(kg·°C)'	)
,	(683	,N'kg-f-m/(kg·°K)'	)
,	(684	,N'kgmole/day'	)
,	(685	,N'kgmole/min'	)
,	(686	,N'kgmole/s'	)
,	(687	,N'kj'	)
,	(688	,N'kJ/(kg·°C)'	)
,	(689	,N'kJ/(kg·°K)'	)
,	(690	,N'kJ/kg'	)
,	(691	,N'kJ/s'	)
,	(692	,N'km'	)
,	(693	,N'km/h'	)
,	(694	,N'km/min'	)
,	(695	,N'km/s'	)
,	(696	,N'km²'	)
,	(697	,N'km³'	)
,	(698	,N'kW'	)
,	(699	,N'kw/(m·°K)'	)
,	(700	,N'l'	)
,	(701	,N'L/(s.kW)'	)
,	(702	,N'L/(s.MW)'	)
,	(703	,N'l/h'	)
,	(704	,N'l/min'	)
,	(705	,N'l/s'	)
,	(706	,N'lb/(hr·ft²)'	)
,	(707	,N'lb/(min·ft²)'	)
,	(708	,N'lb/(sec·ft²)'	)
,	(709	,N'lb/min'	)
,	(710	,N'lb/yr'	)
,	(711	,N'lbf'	)
,	(712	,N'lbf-ft/(lb·f)'	)
,	(713	,N'lbf-s/ft²'	)
,	(714	,N'lbm'	)
,	(715	,N'lbm/(ft-h)'	)
,	(716	,N'lbm/(ft-s)'	)
,	(717	,N'lbm/bbl'	)
,	(718	,N'lbm/ft³'	)
,	(719	,N'lbm/gal'	)
,	(720	,N'lbm/h'	)
,	(721	,N'lbm/s'	)
,	(722	,N'lbmole/day'	)
,	(723	,N'lbmole/min'	)
,	(724	,N'lbmole/s'	)
,	(725	,N'lbs'	)
,	(726	,N'load/day'	)
,	(727	,N'm/h'	)
,	(728	,N'm/min'	)
,	(729	,N'm/s'	)
,	(730	,N'm/s²'	)
,	(731	,N'm²'	)
,	(732	,N'm³/h'	)
,	(733	,N'm³/kg'	)
,	(734	,N'm³/load'	)
,	(735	,N'm³/m³'	)
,	(736	,N'm³/min'	)
,	(737	,N'm³/month'	)
,	(738	,N'm³/s'	)
,	(739	,N'mg'	)
,	(740	,N'mg/L'	)
,	(741	,N'mg/L as CaCO₃'	)
,	(742	,N'mg/L as N'	)
,	(743	,N'mgd'	)
,	(744	,N'mho/cm'	)
,	(746	,N'mile'	)
,	(747	,N'mile/min'	)
,	(748	,N'mile/s'	)
,	(749	,N'mile²'	)
,	(750	,N'mile³'	)
,	(751	,N'min'	)
,	(752	,N'Mj'	)
,	(753	,N'MJ/Kg'	)
,	(754	,N'ml/h'	)
,	(755	,N'ml/min'	)
,	(756	,N'ml/s'	)
,	(757	,N'mm'	)
,	(758	,N'mm/h'	)
,	(759	,N'mm/min'	)
,	(760	,N'mm/s'	)
,	(761	,N'mm³'	)
,	(762	,N'mmole/100 mole H₂O'	)
,	(763	,N'mmole/Kg H₂O'	)
,	(764	,N'mmole/mole H₂O'	)
,	(765	,N'mole/day'	)
,	(766	,N'mole/min'	)
,	(767	,N'mole/s'	)
,	(768	,N'Month'	)
,	(769	,N'mph'	)
,	(770	,N'mpy'	)
,	(771	,N'ms'	)
,	(772	,N'mS/cm'	)
,	(773	,N'mS/m'	)
,	(774	,N'MW'	)
,	(775	,N'mw/(m·°K)'	)
,	(776	,N'MWh'	)
,	(777	,N'N'	)
,	(778	,N'ns'	)
,	(779	,N'NTU'	)
,	(780	,N'pa/s'	)
,	(781	,N'per µs'	)
,	(782	,N'Per bbl'	)
,	(783	,N'Per cm³'	)
,	(784	,N'Per ft³'	)
,	(785	,N'Per g'	)
,	(786	,N'Per gal'	)
,	(787	,N'per hr'	)
,	(788	,N'Per in³'	)
,	(789	,N'Per kg'	)
,	(790	,N'Per km³'	)
,	(791	,N'Per l'	)
,	(792	,N'Per lbm'	)
,	(793	,N'Per m³'	)
,	(794	,N'Per mg'	)
,	(795	,N'Per mile³'	)
,	(796	,N'per min'	)
,	(797	,N'Per ml³'	)
,	(798	,N'per ms'	)
,	(799	,N'per ns'	)
,	(800	,N'per s'	)
,	(801	,N'Per ton'	)
,	(802	,N'Per ug'	)
,	(803	,N'Poise'	)
,	(804	,N'poundal'	)
,	(806	,N'ppb as CaCO₃'	)
,	(807	,N'ppb as HCO₃'	)
,	(808	,N'ppm as CaCO₃'	)
,	(809	,N'ppm as HCO₃'	)
,	(810	,N'pS/m'	)
,	(811	,N'psia'	)
,	(812	,N'psig'	)
,	(813	,N'Pt/Co'	)
,	(814	,N'R'	)
,	(816	,N's.u.'	)
,	(817	,N'S/cm'	)
,	(818	,N'S/m'	)
,	(819	,N'stmho/cm'	)
,	(820	,N'stmho/m'	)
,	(821	,N'Ton'	)
,	(822	,N'Ton/hr'	)
,	(823	,N'Ton/month'	)
,	(824	,N'Tons'	)
,	(825	,N'unit'	)
,	(826	,N'W'	)
,	(827	,N'w/(cm·°K)'	)
,	(828	,N'w/(m·°K)'	)
,	(829	,N'W/(m²·°C)'	)
,	(830	,N'W/(m²·°K)'	)
,	(831	,N'wk'	)
,	(832	,N'yr'	)
,	(833	,N'kg/MJ'	)
,	(834	,N'kg/MMBtu(it)'	)
,	(835	,N'Kg/MMBtu(th)'	)
,	(836	,N'lb/MMBtu(it)'	)
,	(837	,N'lb/MMBtu(th)'	)
,	(838	,N'lb/MJ'	)
,	(839	,N'% as N'	)
,	(840	,N'fraction as N'	)
,	(841	,N'ppb as N'	)
,	(842	,N'ppm as N'	)
,	(843	,N'ppm as Cl₂'	)
,	(844	,N'mm/year'	)
,	(845	,N'lb/hr'	)
,	(846	,N'Amp'	)
,	(847	,N'V'	)
,	(848	,N'Y=1, N=0'	)
,	(849	,N'On=1, Off=0'	)
,	(850	,N'1-5, yellow to purple'	)
,	(851	,N'1-5, poor to excellent'	)
,	(852	,N'RLU'	)
,	(853	,N'mW/cm²'	)
,	(854	,N'w/m²'	)
,	(855	,N'ml'	)
,	(856	,N'kW/Ton'	)
,	(857	,N'1000 gal'	)
,	(858	,N'mil'	)
,	(859	,N'mV'	)
,	(860	,N'gal/month'	)
,	(861	,N'lb/month'	)
,	(862	,N'100 gal'	)
,	(863	,N'lb'	)
,	(864	,N'?'	)
,	(865	,N'Amps'	)
,	(866	,N'g/m³'	)
,	(867	,N'kcal/s'	)
,	(868	,N'MMBtu/h'	)
,	(869	,N'kcal/h'	)
,	(870	,N'bbl/day'	)
,	(871	,N'BWG'	)
,	(872	,N'm³/h per MW'	)
,	(873	,N'gpm/1000 Tons'	)
,	(874	,N'mA'	)
,	(875	,N'pH'	)
,	(876	,N'µg/day'	)
,	(877	,N'MMBtu/Kg'	)
,	(878	,N'MMBtu/lb'	)
,	(879	,N'MMBtu/ton'	)
,	(880	,N'MJ/lb'	)
,	(881	,N'MJ/ton'	)
,	(882	,N'MMBtu/US gal'	)
,	(883	,N'MMBtu/petro barrel'	)
,	(884	,N'MMBtu/Mcf'	)
,	(885	,N'MJ/US gal'	)
,	(886	,N'MJ/petro barrel'	)
,	(887	,N'MJ/Mcf'	)
,	(984	,N'MMBtu/Kg'	)
,	(985	,N'MMBtu/lb'	)
,	(986	,N'MMBtu/ton'	)
,	(987	,N'MJ/lb'	)
,	(988	,N'MJ/ton'	)
,	(989	,N'MMBtu/US gal'	)
,	(990	,N'MMBtu/petro barrel'	)
,	(991	,N'MMBtu/Mcf'	)
,	(992	,N'MJ/US gal'	)
,	(993	,N'MJ/petro barrel'	)
,	(994	,N'MJ/Mcf'	)
,	(995	,N'bbl/day'	)
,	(996	,N'µm/day'	)
,	(997	,N'µm/yr'	)
,	(998	,N'mils/day'	)
,	(999	,N'mm/day'	)
,	(1000	,N'mm/yr'	)
,	(1001	,N'kj/y'	)
,	(1002	,N'kWh/y'	)
,	(1003	,N'--'	)
,	(1004	,N'count'	)
,	(1007	,N'W/ton'	)
,	(1008	,N'MW/ton'	)
,	(1009	,N'HP/ton'	)
,	(1010	,N'(MMBtu/h)/ton'	)
,	(1011	,N'(Btu/s)/ton'	)
,	(1012	,N'(Btu/h)/ton'	)
,	(1013	,N'(kcal/s)/ton'	)
,	(1014	,N'(kcal/h)/ton'	)
,	(1015	,N'lb/s'	)
,	(1016	,N'tons/yr'	)
,	(1017	,N'm³/ton'	)
,	(1018	,N'm³/Mton'	)
,	(1019	,N'gal/ton'	)
,	(1020	,N'kg/ton'	)
,	(1021	,N'g/ton'	)
,	(1022	,N'mm²'	)
,	(1023	,N'Btu/s'	)
,	(1024	,N'Btu/h'	)
,	(1025	,N'cal/kg'	)
,	(1026	,N'cal/g'	)
,	(1027	,N'kcal/kg'	)
,	(1028	,N'Btu/lb'	)
,	(1029	,N'kJ/h'	)
,	(1030	,N'KW/(m²·°K)'	)
,	(1031	,N'Per µg'	)
,	(1032	,N'kg/MMBtu'	)
,	(1033	,N'lb/MMBtu'	)
,	(1034	,N'RT'	)
,	(1035	,N'm²·°C/kW'	)
,	(1036	,N'ft²·°F/BTU/hr'	)
,	(1037	,N'scfm'	)
,	(1038	,N'Nm3/m'	)
,	(1039	,N'in2'	)
,	(1040	,N'in/H2O'	)
,	(1041	,N'kW/(m²·°C)'	)
,	(1042	,N'per 1000 Kgs'	)
,	(1043	,N'per 1000 lbs'	)
,	(1045	,N'per 1000 gal'	)
,	(1046	,N'per 1000 L'	)
,	(1047	,N'gal/year'	)
,	(1048	,N'petro barrel/day'	)
,	(1049	,N'petro barrel/year'	)
,	(1050	,N'Mcf/day'	)
,	(1051	,N'Mcf/year'	)
,	(1052	,N'ppm as P'	)
,	(1053	,N'mg/L as P'	)
,	(1054	,N'ppb as P'	)
,	(1055	,N'µg/L as P'	)
,	(1056	,N'(m²·°K)/KW'	)
,	(1057	,N'(m²·°C)/W'	)
,	(1058	,N'(sec•m²•°C)/J'	)
,	(1059	,N'(sec·ft²·°F)/Btu'	)
,	(1060	,N'(hr·ft²·°F)/Btu'	)
,	(1061	,N'BV/h'	)

MERGE	TCD.UnitOfMeasure			AS TARGET
USING	@tempUnitOfMeasure		AS SOURCE
ON	TARGET.UOMId		=			SOURCE.UOMId
WHEN	NOT MATCHED		THEN
INSERT	(UOMId			,UOM		)
VALUES	(SOURCE.UOMId	,SOURCE.UOM	);
END





/*	UserRoles

No identity column defined.
PRIMARY KEY: RoleId
FK:	NO
Table is referenced by foreign key: None of the master tables

select	*	from	UserRoles
*/
BEGIN
SET			@TableName				=			'UserRoles'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempUserRoles	TABLE	(
TempId					INT				IDENTITY(1, 1)
,	RoleId					INT				NOT	NULL
,	RoleName				NVARCHAR(50)
,	code					VARCHAR(10)
,	LevelId					INT
)

--Populate temp table variable with the input data
INSERT	@tempUserRoles	(
RoleId	,RoleName			,code			,LevelId	)
VALUES	(1	,N'Territory Manager : Basic'	,'TMB'	,6	)
,	(2	,N'Territory Manager : Advanced'	,'TMA'	,7	)
,	(3	,N'Engineer'	,'ENG'	,8	)
,	(4	,N'Adminstrator'	,'ADM'	,9	)
,	(5	,N'Temporary Role for Ecolab'	,'TRE'	,8	)
,	(6	,N'Sales Management'	,'BDM'	,5	)
,	(7	,N'CAM'	,'CAM'	,5	)
,	(8	,N'Temporary Role for Customer'	,'TRC'	,7	)
,	(9	,N'Plant Manager'	,'PM'	,4	)
,	(10	,N'Plant Engineer'	,'PE'	,3	)
,	(11	,N'Operator'	,'OPE'	,2	)

MERGE	TCD.UserRoles				AS TARGET
USING	@tempUserRoles			AS SOURCE
ON	TARGET.RoleId			=			SOURCE.RoleId
WHEN	NOT MATCHED		THEN
INSERT	(RoleId			,RoleName			,code			,LevelId	)
VALUES	(SOURCE.RoleId	,SOURCE.RoleName	,SOURCE.code	,SOURCE.LevelId	);
END

/* Page
PRIMARY KEY: Id
FK:	None
*/
BEGIN
SET			@TableName				=			'Page'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempPage			TABLE	(
TempId					INT					IDENTITY(1, 1)
,	PageId				INT					NOT NULL
,	PageName			nvarchar(500)		NOT NULL
,	PageDescription		nvarchar(500)		NULL
)

--Populate temp table variable with the input data
INSERT	@tempPage	(
PageId, PageName	,PageDescription	)
VALUES

  (1, N'Generic', N'General Keys used in more than screen')
, (2, N'Plant Contact', NULL)
, (3, N'Plant General Setup', NULL)
, (4, N'Plant Chemical', NULL)
, (5, N'Plant Formula', NULL)
, (6, N'Plant Customer', NULL)
, (7, N'Red Flag', NULL)
, (8, N'Plant Shift', NULL)
, (9, N'Target Production', NULL)
, (10, N'Labor Cost', NULL)
, (11, N'Utility Factor/Utility', N'Plant Utility')
, (12, N'Water And Energy', N'Water and energy page')
, (13, N'Meter', NULL)
, (14, N'Sensor', NULL)
, (15, N'Dryers', NULL)
, (16, N'Finnishers', NULL)
, (17, N'User Managment', NULL)
, (18, N'Dashboard Setup', NULL)
, (19, N'Manual Input', N'Manual Input General Page')
, (20, N'Manual Input - Utility', N'Manual Input Utility Page')
, (21, N'Manual Input - Production', NULL)
, (22, N'Manual Input - Batch', NULL)
, (23, N'Manual Input - Labor', NULL)
, (24, N'Manual Input - Rewash', NULL)
, (25, N'Dispensers List', N'')
, (26, N'Dispenser General Page', NULL)
, (27, N'Dispenser Advance Page', NULL)
, (28, N'Pumps and Valves Page', NULL)
, (29, N'Washer Group', NULL)
, (30, N'Washer List', NULL)
, (31, N'Washer Setup', NULL)
, (32, N'Washer Group Formula', NULL)
, (33, N'Storage Tanks', NULL)
, (34, N'Visualisation', NULL)
, (35, N'My Profile', NULL)
, (36, N'Alarms Master Data', N'Alarms Master Data')
, (37, N'Errors', N'Error messages')
, (38, N'Alarms', N'Alarm Screen')
, (39, N'Tag Managment', N'Tag managment screen')
, (40, N'Login', N'Login Page')
, (41, N'Chain Textile Category', N'Master data of chain textile care')
, (42,N'Product Category', N'Master data for product categories')
, (43 ,N'Ecolab Textile Category' ,N'Master data for Ecolab Textile Categories')
, (44,N'Rewash Reason',N'Master data for rewash reason')
, (45,N'Product Display Name' ,N'Master data of products display name')
, (46,N'Flush Time and TOM Setup' ,N'Washer flush Time and Washer time out machine')



MERGE	TCD.Page			AS			TARGET
USING	@tempPage		AS			SOURCE
ON	TARGET.PageId		=			SOURCE.PageId
WHEN	NOT MATCHED		THEN
INSERT	(PageId , PageName, PageDescription)
VALUES	(SOURCE.PageId,SOURCE.PageName	,SOURCE.PageDescription	);


END



/*	UtilityMaster

No identity column defined.
PRIMARY KEY: ResourceId
FK:	NO
Table is referenced by foreign key: No master table refers to this one

select	*	from	UtilityMaster
*/
BEGIN
SET			@TableName				=			'UtilityMaster'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempUtilityMaster	TABLE	(
TempId					INT				IDENTITY(1, 1)
,	ResourceId				INT				NOT	NULL
,	Name					NVARCHAR(255)
,	UOMId					INT
)

--Populate temp table variable with the input data
INSERT    @tempUtilityMaster    (
ResourceId, Name, UOMId    )
VALUES
(1, N'Gas', NULL)
,(2, N'Water', NULL)
,(3, N'Electric', NULL)
,(4, N'Oil', NULL)
,(5, N'Counter', NULL)
,(6, N'Level', NULL)
,(7, N'Flow Totalizer', NULL)
,(8, N'Hours', NULL)

MERGE	TCD.UtilityMaster			AS TARGET
USING	@tempUtilityMaster		AS SOURCE
ON	TARGET.ResourceId		=			SOURCE.ResourceId
WHEN	NOT MATCHED		THEN
INSERT	(ResourceId			,Name			,UOMId			)
VALUES	(SOURCE.ResourceId	,SOURCE.Name	,SOURCE.UOMId	);
END





/*	SensorTypeMaster

No identity column defined.
PRIMARY KEY: ResourceId
FK:	NO
No foreign keys reference table 'SensorTypeMaster', or you do not have permissions on referencing tables.

select	*	from	SensorTypeMaster
*/
BEGIN
SET			@TableName				=			'SensorTypeMaster'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempSensorTypeMaster	TABLE	(
TempId					INT				IDENTITY(1, 1)
,	ResourceId				INT				NOT	NULL
,	Name					NVARCHAR(255)
,	UOMId					INT
,	MappingSensorID				INT
)

--Populate temp table variable with the input data
INSERT	@tempSensorTypeMaster	(
ResourceId	,Name			,UOMId		,MappingSensorID	)
VALUES	(1	,N'Temperature'	,NULL	,2	)
,	(2	,N'pH'	,NULL	,1	)
,	(3	,N'Redox'	,NULL	,NULL	)
,	(4	,N'Conductivity'	,NULL	,3	)
,	(5	,N'Weight'	,NULL	,7	)
,	(6	,N'Water Hardness'	,NULL	,NULL	)
,	(7	,N'others'	,NULL	,NULL	)

MERGE	TCD.SensorTypeMaster			AS TARGET
USING	@tempSensorTypeMaster		AS SOURCE
ON	TARGET.ResourceId		=			SOURCE.ResourceId
WHEN	NOT MATCHED		THEN
INSERT	(ResourceId			,Name			,UOMId			,MappingSensorID	)
VALUES	(SOURCE.ResourceId	,SOURCE.Name	,SOURCE.UOMId	,SOURCE.MappingSensorID	);
END





/*	RedFlagItemList

Identity defined: Id
PRIMARY KEY: Id
FK:	NO
No foreign keys reference table 'RedFlagItemList', or you do not have permissions on referencing tables.


select	*	from	RedFlagItemList
*/
BEGIN
SET			@TableName				=			'RedFlagItemList'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempRedFlagItemList	TABLE	(
TempId					INT				IDENTITY(1, 1)
,	Id						INT				NOT	NULL
,	ItemName				NVARCHAR(500)
,	UOMNA					NVARCHAR(50)
,	UOMEurope				NVARCHAR(50)
)

--Populate temp table variable with the input data
INSERT	@tempRedFlagItemList	(
Id			,ItemName				,UOMNA			,UOMEurope	)
VALUES	(1	,N'Overall Efficiency'	,N'%'	,N'%'	)
,	(2	,N'Runtime Efficiency'	,N'%'	,N'%'	)
,	(3	,N'Turn Time Efficiency'	,N'%'	,N'%'	)
,	(4	,N'Transfer/Hour'	,N'T/H'	,N'T/H'	)
,	(5	,N'Rewash Rate'	,N'%'	,N'%'	)
,	(6	,N'Water usage'	,N'G/CWT'	,N'L/kg'	)
,	(7	,N'Energy consumption'	,N'BTU/CwT'	,N'kWh/kg'	)
,	(8	,N'Gas consumption'	,N'Therms/CWT'	,N'm²/kg'	)
,	(9	,N'Chemical Consumption'	,N'oz/cwt'	,N'gr/kg'	)
,	(10	,N'Drying Efficiency'	,N'%'	,N'%'	)

SET	IDENTITY_INSERT	TCD.RedFlagItemList	ON

MERGE	TCD.RedFlagItemList				AS TARGET
USING	@tempRedFlagItemList		AS SOURCE
ON	TARGET.Id					=			SOURCE.Id
WHEN	NOT MATCHED		THEN
INSERT	(Id			,ItemName			,UOMNA			,UOMEurope			)
VALUES	(SOURCE.Id	,SOURCE.ItemName	,SOURCE.UOMNA	,SOURCE.UOMEurope	);

SET	IDENTITY_INSERT	[TCD].RedFlagItemList	OFF
END





/*	LaborType

No identity column defined.
PRIMARY KEY: LaborTypeId
FK:	NO
No foreign keys reference table 'LaborType', or you do not have permissions on referencing tables.

select	*	from	LaborType					--No IDENTITY, No FKs, NOT REFERENCED
*/
BEGIN
SET			@TableName				=			'LaborType'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempLaborType	TABLE	(
TempId					INT				IDENTITY(1, 1)
,	LaborTypeId				INT				NOT	NULL
,	[Description]			NVARCHAR(255)
)

--Populate temp table variable with the input data
INSERT	@tempLaborType	(
LaborTypeId			,[Description]	)
VALUES	(1	,N'Normal'	)
,	(2	,N'Temporary'	)
,	(3	,N'Specialist'	)
,	(4	,N'Others'	)

MERGE	TCD.LaborType			AS TARGET
USING	@tempLaborType		AS SOURCE
ON	TARGET.LaborTypeId		=			SOURCE.LaborTypeId
WHEN	NOT MATCHED		THEN
INSERT	(LaborTypeId			,[Description]			)
VALUES	(SOURCE.LaborTypeId		,SOURCE.[Description]	);
END




/*	DashboardType

Identity: Id
PRIMARY KEY: Id
FK:	NONE
Table is referenced by foreign key: ConduitDashboard: FK_Dashboard_DashboardType

select	*	from	DashboardType				--Added (and above ConduitDashboard, since it REFERs it); No FKs
*/
BEGIN
SET			@TableName				=			'DashboardType'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempDashboardType		TABLE	(
TempId					INT				IDENTITY(1, 1)
,	Id						INT				NOT	NULL
,	Name					NVARCHAR(250)
)

--Populate temp table variable with the input data
INSERT	@tempDashboardType	(
Id			,Name	)
VALUES	(1	,N'Conduit Dashboard'	)

SET		IDENTITY_INSERT		TCD.DashboardType	ON

MERGE	TCD.DashboardType			AS			TARGET
USING	@tempDashboardType		AS			SOURCE
ON	TARGET.Id				=			SOURCE.Id
WHEN	NOT MATCHED		THEN
INSERT	(Id			,Name			)
VALUES	(SOURCE.Id	,SOURCE.Name	);

SET		IDENTITY_INSERT		[TCD].DashboardType	OFF
END





/*	ConduitDashboard

Identity: Id
PRIMARY KEY: Id
FK:	REFERENCES ConduitLocal.dbo.DashboardType (Id)
Table is referenced by foreign key:
ConduitLocal.dbo.ConduitDashboardDetail: FK_DashboardDetail_Dashboard
ConduitLocal.dbo.DashboardUserPortletMapping: FK_DashboardUserPortletMapping_Dashboard

select	*	from	ConduitDashboard			--Added (and above DashboardUserPortletMapping, since it REFERs it); FK (Refers) - DashboardType
*/
BEGIN
SET			@TableName				=			'ConduitDashboard'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempConduitDashboard	TABLE	(
TempId					INT				IDENTITY(1, 1)
,	Id						INT				NOT	NULL
,	Name					NVARCHAR(250)	NOT	NULL
,	DashboardTypeId			INT				NOT	NULL
,	[Status]				BIT
,	ResourceKey				NVARCHAR(250)
)

--Populate temp table variable with the input data
INSERT	@tempConduitDashboard	(
Id			,Name					,DashboardTypeId	,[Status]	,ResourceKey			)
VALUES	(1			,N'Conduit Dashboard'	,1					,1			,N'CL_Conduitdashboard'	)

SET	IDENTITY_INSERT	TCD.ConduitDashboard	ON

MERGE	TCD.ConduitDashboard			AS			TARGET
USING	@tempConduitDashboard		AS			SOURCE
ON	TARGET.Id					=			SOURCE.Id
WHEN	NOT MATCHED		THEN
INSERT	(Id			,Name			,DashboardTypeId		,[Status]			,ResourceKey		)
VALUES	(SOURCE.Id	,SOURCE.Name	,SOURCE.DashboardTypeId	,SOURCE.[Status]	,SOURCE.ResourceKey	);

SET	IDENTITY_INSERT	[TCD].ConduitDashboard	OFF
END





/*	PortletMaster

Identity: Id
PRIMARY KEY: Id
FK:	NONE
Table is referenced by foreign key: WasherTempSetup:
ConduitLocal.dbo.ConduitDashboardDetail: FK_DashboardDetail_PortletMaster
ConduitLocal.dbo.DashboardUserPortletMapping: FK_DashboardUserPortletMapping_PortletMaster

select	*	from	PortletMaster				--Has IDENTITY, No FKs, REFERENCED by ConduitDashboardDetail, DashboardUserPortletMapping (Populate before that)
*/
BEGIN
SET			@TableName				=			'PortletMaster'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempPortletMaster	TABLE	(
TempId					INT				IDENTITY(1, 1)
,	Id						INT				NOT	NULL
,	Name					NVARCHAR(200)	NOT	NULL
,	ReportId					INT
,	EcolabAccountNumber					NVARCHAR(2000)				NOT	NULL
)

--Populate temp table variable with the input data
INSERT	@tempPortletMaster	(
Id			,Name					,ReportId					,EcolabAccountNumber	)
VALUES	(1	,N'Operations Summary',	10	,1	)
,	(2	,N'Production Summary',	1	,1	)
,	(3	,N'Chemical Consumption',	5	,1	)
,	(4	,N'Production Details',	2	,1	)


MERGE	TCD.PortletMaster			AS			TARGET
USING	@tempPortletMaster		AS			SOURCE
ON	TARGET.Id				=			SOURCE.Id
WHEN	NOT MATCHED		THEN
INSERT	(Id			,Name			,ReportId			,EcolabAccountNumber			)
VALUES	(SOURCE.Id	,SOURCE.Name	,SOURCE.ReportId	,SOURCE.EcolabAccountNumber	);

END




/*	ConduitDashboardDetail

No identity column defined.
PRIMARY KEY: NONE. Will assume DashboardId, PortletId
FK:	REFERENCES ConduitLocal.dbo.ConduitDashboard (Id)
REFERENCES ConduitLocal.dbo.PortletMaster (Id)
No foreign keys reference table 'ConduitDashboardDetail', or you do not have permissions on referencing tables.

select	*	from	ConduitDashboardDetail		--Added (clubbing with Dashboard tables, but is NOT REFERENCED); FK - ConduitDashboard, PortletMaster
*/
BEGIN
SET			@TableName				=			'ConduitDashboardDetail'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@ConduitDashboardDetail	TABLE	(
TempId					INT				IDENTITY(1, 1)
,	DashboardId				INT				NOT	NULL
,	PortletId				INT				NOT	NULL
,	IsMandatory				BIT				NOT	NULL
,	DisplayOrder				INT
)

--Populate temp table variable with the input data
INSERT	@ConduitDashboardDetail	(
DashboardId	,PortletId	,IsMandatory	,DisplayOrder	)
VALUES	(1			,1			,1				,2				)
,	(1			,2			,1				,1				)
,	(1			,3			,0				,3				)
,	(1			,4			,0				,4				)

MERGE	TCD.ConduitDashboardDetail			AS	TARGET
USING	@ConduitDashboardDetail			AS	SOURCE
ON	TARGET.DashboardId		=			SOURCE.DashboardId
AND	TARGET.PortletId		=			SOURCE.PortletId
WHEN	NOT MATCHED		THEN
INSERT	(DashboardId		,PortletId			,IsMandatory		,DisplayOrder			)
VALUES	(SOURCE.DashboardId	,SOURCE.PortletId	,SOURCE.IsMandatory	,SOURCE.DisplayOrder	);
END




/*	ConduitSectionType

No identity column defined.
PRIMARY KEY: SectionType
FK:	NO
Table is referenced by foreign key:
ConduitMenu: FK_UISectionType_UISectionMaster

select	*	from	ConduitSectionType			--Added (abd above ConduitMenu, since it REFERs it); itself has NO FK
*/
BEGIN
SET			@TableName				=			'ConduitSectionType'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempConduitSectionType	TABLE	(
TempId					INT				IDENTITY(1, 1)
,	SectionType				NVARCHAR(50)	NOT	NULL
,	[Description]			NVARCHAR(200)
)

--Populate temp table variable with the input data
INSERT	@tempConduitSectionType	(
SectionType			,[Description]	)
VALUES	(N'Menu'			,N'UI Menu'		)
,	(N'MenuItem'		,N'UI MenuItem'	)
,	(N'Portlet'			,N'UI Portlet'	)
,	(N'Tab'				,N'UI Tab'		)
,	(N'TabItem'			,N'UI TabItem'	)

MERGE	TCD.ConduitSectionType			AS		TARGET
USING	@tempConduitSectionType		AS		SOURCE
ON	TARGET.SectionType			=		SOURCE.SectionType
WHEN	NOT MATCHED		THEN
INSERT	(SectionType			,[Description]			)
VALUES	(SOURCE.SectionType		,SOURCE.[Description]	);
END






/*	ConduitTabType

Identity: Id
PRIMARY KEY: Id
FK:	NONE


Table is referenced by foreign key:
FieldGroup: FK_FieldGroup_TabType

select	*	from	ConduitTabType
*/
BEGIN
SET			@TableName				=			'ConduitTabType'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempConduitTabType		TABLE	(
TempId					INT				IDENTITY(1, 1)
,	Id						INT				NOT	NULL
,	Name					NVARCHAR(250)	NOT	NULL
)

--Populate temp table variable with the input data
INSERT	@tempConduitTabType	(
Id			,Name	)
VALUES	(1	,N'Application Information'	)
,	(2	,N'Value Documentation'		)
--Sprint9 additions
,	(3	,N'Controller Setup Advance'		)

SET		IDENTITY_INSERT	TCD.ConduitTabType	ON

MERGE	TCD.ConduitTabType			AS			TARGET
USING	@tempConduitTabType		AS			SOURCE
ON	TARGET.Id			=			SOURCE.Id
WHEN	NOT MATCHED		THEN
INSERT	(Id			,Name			)
VALUES	(SOURCE.Id	,SOURCE.Name	);

SET		IDENTITY_INSERT	[TCD].ConduitTabType	OFF
END





/*	ConduitMenu

Identity: SectionID
PRIMARY KEY: SectionID; Also has UNIQUE KEY defined (SectionCode)
FK:	REFERENCES ConduitLocal.dbo.ConduitSectionType (SectionType)
Table is referenced by foreign key:
ConduitMenuRoleMapping: FK_UISectionMaster_UISectionSettingsMapping

select	*	from	ConduitMenu					--Has IDENTITY, Has FK (SectionType); Table is referenced by foreign key
*/
BEGIN
SET			@TableName				=			'ConduitMenu'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempConduitMenu		TABLE	(
TempId					INT				IDENTITY(1, 1)
,	SectionID				INT				NOT	NULL
,	SectionName				NVARCHAR(200)	NOT	NULL
,	SectionCode				NCHAR(15)		NOT	NULL
,	ParentID				INT
,	SectionType				NVARCHAR(50)	NOT	NULL
,	ControllerName			NVARCHAR(100)
,	ViewName				NVARCHAR(100)
,	ResourceClass			NVARCHAR(100)
,	ResourceKey				NVARCHAR(100)
)

--Populate temp table variable with the input data
INSERT	@tempConduitMenu	(
SectionID	,SectionName	,SectionCode	,ParentID	,SectionType	,ControllerName	,ViewName	,ResourceClass	,ResourceKey	)
VALUES (1, N'ToolSet', N'TOOLSET        ', NULL, N'Menu', NULL, NULL, NULL, NULL)
,(2, N'Dashboards', N'DASHBOARDS     ', 1, N'MenuItem', NULL, NULL, NULL, N'MENUITEM_DASHBOARD')
,(3, N'Reports', N'REPORTS        ', 1, N'MenuItem', NULL, NULL, NULL, N'MENUITEM_REPORTS')
,(4, N'Visualizations', N'VISUALIZATIONS ', NULL, N'MenuItem', NULL, NULL, NULL, N'MENUITEM_VISUALIZATIONS')
,(6, N'Manual Inputs', N'MANUAL INPUTS  ', 1, N'MenuItem', NULL, NULL, NULL, N'MENITEM_MANUALINPUTS')
,(7, N'Setup', N'SETUP          ', 1, N'MenuItem', NULL, NULL, NULL, N'MENITEM_SETUP')
,(8, N'Plant Setup', N'PLANTSETUP     ', 7, N'MenuItem', NULL, NULL, NULL, N'MENITEM_PLANTSETUP')
,(9, N'Controller Setup', N'CONTROLLERSETUP', 7, N'MenuItem', NULL, NULL, NULL, N'MENITEM_CONTROLLERSETUP')
,(10, N'Meters', N'METERS         ', 8, N'Tab', NULL, NULL, NULL, N'TAB_METERS')
,(11, N'Sensors', N'SENSORS        ', 8, N'Tab', NULL, NULL, NULL, N'TAB_SENSORS')
,(12, N'utility', N'UTILITY        ', 8, N'Tab', NULL, NULL, NULL, N'TAB_UTILITY')
,(13, N'Formulas', N'FORMULAS       ', 8, N'Tab', NULL, NULL, NULL, N'TAB_FORMULA')
,(14, N'Production Chart', N'PRODUCTIONCHART', 4, N'MenuItem', NULL, NULL, NULL, N'MENITEM_PRODUCTIONCHART')
,(15, N'Chemical Chart', N'CHEMICALCHART  ', 4, N'MenuItem', NULL, NULL, NULL, N'MENITEM_CHEMICALCHART')
,(16, N'Washer Groups', N'WASHERGROUPS   ', 7, N'MenuItem', NULL, NULL, NULL, N'MENITEM_WASHERGROUP')
,(17, N'Washers', N'WASHER', 7 ,N'MenuItem' ,NULL, NULL, NULL, N'MENUITEM_WASHER')
,(18, N'Storage Tanks', N'STORAGETANKS   ', 7, N'MenuItem', NULL, NULL, NULL, N'MENUITEM_STORAGETANKS')

SET	IDENTITY_INSERT	TCD.ConduitMenu	ON

MERGE	TCD.ConduitMenu				AS			TARGET
USING	@tempConduitMenu		AS			SOURCE
ON	TARGET.SectionId		=			SOURCE.SectionId
WHEN	NOT MATCHED		THEN
INSERT	(SectionID			,SectionName			,SectionCode		,ParentID			,SectionType		,ControllerName
,	ViewName			,ResourceClass			,ResourceKey		)
VALUES	(SOURCE.SectionID	,SOURCE.SectionName		,SOURCE.SectionCode	,SOURCE.ParentID	,SOURCE.SectionType	,SOURCE.ControllerName
,	SOURCE.ViewName		,SOURCE.ResourceClass	,SOURCE.ResourceKey	);

SET	IDENTITY_INSERT	[TCD].ConduitMenu	OFF
END





/*	ConduitMenuRoleMapping

Identity: SectionID
PRIMARY KEY: MappingID
FK:	REFERENCES ConduitLocal.dbo.ConduitMenu (SectionCode)
No foreign keys reference table 'ConduitMenuRoleMapping', or you do not have permissions on referencing tables.

select	*	from	ConduitMenuRoleMapping		--Has IDENTITY, Has FK (ConduitMenu)
*/
BEGIN
SET			@TableName				=			'ConduitMenuRoleMapping'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempConduitMenuRoleMapping		TABLE	(
TempId					INT				IDENTITY(1, 1)
,	MappingID				INT				NOT	NULL
,	SectionCode				NCHAR(15)		NOT	NULL
,	SettingCode				NCHAR(15)		NOT	NULL
,	SettingValue			NVARCHAR(MAX)
,	UserRole				NVARCHAR(10)
,	UserID					INT
,	TagId					INT
,	TagType					INT
,	UsageUICode				NCHAR(15)
,	UserRoleCode			VARCHAR(10)
)

--Populate temp table variable with the input data
INSERT	@tempConduitMenuRoleMapping	(
MappingID	,SectionCode	,SettingCode	,SettingValue	,UserRole	,UserID	,TagId	,TagType	,UsageUICode	,UserRoleCode	)
VALUES
(1, N'DASHBOARDS     ', N'IS_AVAILABLE   ', N'true', N'6', NULL, NULL, NULL, N'TOOLSET        ', N'TMB')
, (2, N'DASHBOARDS     ', N'IS_AVAILABLE   ', N'true', N'7', NULL, NULL, NULL, N'TOOLSET        ', N'TMA')
, (3, N'DASHBOARDS     ', N'IS_AVAILABLE   ', N'true', N'8', NULL, NULL, NULL, N'TOOLSET        ', N'ENG')
, (4, N'DASHBOARDS     ', N'IS_AVAILABLE   ', N'true', N'9', NULL, NULL, NULL, N'TOOLSET        ', N'ADM')
, (5, N'DASHBOARDS     ', N'IS_AVAILABLE   ', N'true', N'8', NULL, NULL, NULL, N'TOOLSET        ', N'TRE')
, (6, N'DASHBOARDS     ', N'IS_AVAILABLE   ', N'true', N'5', NULL, NULL, NULL, N'TOOLSET        ', N'BDM')
, (7, N'REPORTS        ', N'IS_AVAILABLE   ', N'true', N'6', NULL, NULL, NULL, N'TOOLSET        ', N'TMB')
, (8, N'REPORTS        ', N'IS_AVAILABLE   ', N'true', N'7', NULL, NULL, NULL, N'TOOLSET        ', N'TMA')
, (9, N'REPORTS        ', N'IS_AVAILABLE   ', N'true', N'8', NULL, NULL, NULL, N'TOOLSET        ', N'ENG')
, (10, N'REPORTS        ', N'IS_AVAILABLE   ', N'true', N'9', NULL, NULL, NULL, N'TOOLSET        ', N'ADM')
, (11, N'REPORTS        ', N'IS_AVAILABLE   ', N'true', N'8', NULL, NULL, NULL, N'TOOLSET        ', N'TRE')
, (12, N'REPORTS        ', N'IS_AVAILABLE   ', N'false', N'5', NULL, NULL, NULL, N'TOOLSET        ', N'BDM')
, (13, N'VISUALIZATIONS ', N'IS_AVAILABLE   ', N'true', N'6', NULL, NULL, NULL, N'TOOLSET        ', N'TMB')
, (14, N'VISUALIZATIONS ', N'IS_AVAILABLE   ', N'true', N'7', NULL, NULL, NULL, N'TOOLSET        ', N'TMA')
, (15, N'VISUALIZATIONS ', N'IS_AVAILABLE   ', N'false', N'8', NULL, NULL, NULL, N'TOOLSET        ', N'ENG')
, (16, N'VISUALIZATIONS ', N'IS_AVAILABLE   ', N'true', N'9', NULL, NULL, NULL, N'TOOLSET        ', N'ADM')
, (17, N'VISUALIZATIONS ', N'IS_AVAILABLE   ', N'false', N'8', NULL, NULL, NULL, N'TOOLSET        ', N'TRE')
, (18, N'VISUALIZATIONS ', N'IS_AVAILABLE   ', N'false', N'5', NULL, NULL, NULL, N'TOOLSET        ', N'BDM')
, (25, N'MANUAL INPUTS  ', N'IS_AVAILABLE   ', N'true', N'6', NULL, NULL, NULL, N'TOOLSET        ', N'TMB')
, (26, N'MANUAL INPUTS  ', N'IS_AVAILABLE   ', N'true', N'7', NULL, NULL, NULL, N'TOOLSET        ', N'TMA')
, (27, N'MANUAL INPUTS  ', N'IS_AVAILABLE   ', N'true', N'8', NULL, NULL, NULL, N'TOOLSET        ', N'ENG')
, (28, N'MANUAL INPUTS  ', N'IS_AVAILABLE   ', N'true', N'9', NULL, NULL, NULL, N'TOOLSET        ', N'ADM')
, (29, N'MANUAL INPUTS  ', N'IS_AVAILABLE   ', N'true', N'8', NULL, NULL, NULL, N'TOOLSET        ', N'TRE')
, (30, N'MANUAL INPUTS  ', N'IS_AVAILABLE   ', N'false', N'5', NULL, NULL, NULL, N'TOOLSET        ', N'BDM')
, (31, N'SETUP          ', N'IS_AVAILABLE   ', N'true', N'6', NULL, NULL, NULL, N'TOOLSET        ', N'TMB')
, (32, N'SETUP          ', N'IS_AVAILABLE   ', N'true', N'7', NULL, NULL, NULL, N'TOOLSET        ', N'TMA')
, (33, N'SETUP          ', N'IS_AVAILABLE   ', N'true', N'8', NULL, NULL, NULL, N'TOOLSET        ', N'ENG')
, (34, N'SETUP          ', N'IS_AVAILABLE   ', N'true', N'9', NULL, NULL, NULL, N'TOOLSET        ', N'ADM')
, (35, N'SETUP          ', N'IS_AVAILABLE   ', N'true', N'8', NULL, NULL, NULL, N'TOOLSET        ', N'TRE')
, (36, N'SETUP          ', N'IS_AVAILABLE   ', N'true', N'5', NULL, NULL, NULL, N'TOOLSET        ', N'BDM')
, (37, N'SETUP          ', N'IS_AVAILABLE   ', N'true', N'5', NULL, NULL, NULL, N'TOOLSET        ', N'CAM')
, (38, N'SETUP          ', N'IS_AVAILABLE   ', N'true', N'7', NULL, NULL, NULL, N'TOOLSET        ', N'TRC')
, (39, N'SETUP          ', N'IS_AVAILABLE   ', N'true', N'4', NULL, NULL, NULL, N'TOOLSET        ', N'PM')
, (40, N'SETUP          ', N'IS_AVAILABLE   ', N'true', N'3', NULL, NULL, NULL, N'TOOLSET        ', N'PE')
, (41, N'SETUP          ', N'IS_AVAILABLE   ', N'true', N'2', NULL, NULL, NULL, N'TOOLSET        ', N'OPE')
, (42, N'SETUP          ', N'IS_AVAILABLE   ', N'true', N'1', NULL, NULL, NULL, N'TOOLSET        ', N'ALL')
, (43, N'METERS         ', N'IS_AVAILABLE   ', N'false', N'1', NULL, NULL, NULL, N'TOOLSET        ', N'ALL')
, (44, N'METERS         ', N'IS_AVAILABLE   ', N'false', N'2', NULL, NULL, NULL, N'TOOLSET        ', N'OPE')
, (45, N'METERS         ', N'IS_AVAILABLE   ', N'false', N'3', NULL, NULL, NULL, N'TOOLSET        ', N'PE')
, (46, N'METERS         ', N'IS_AVAILABLE   ', N'false', N'4', NULL, NULL, NULL, N'TOOLSET        ', N'PM')
, (47, N'METERS         ', N'IS_AVAILABLE   ', N'false', N'5', NULL, NULL, NULL, N'TOOLSET        ', N'CAM')
, (48, N'METERS         ', N'IS_AVAILABLE   ', N'false', N'5', NULL, NULL, NULL, N'TOOLSET        ', N'BDM')
, (49, N'METERS         ', N'IS_AVAILABLE   ', N'true', N'7', NULL, NULL, NULL, N'TOOLSET        ', N'TRC')
, (50, N'METERS         ', N'IS_AVAILABLE   ', N'true', N'8', NULL, NULL, NULL, N'TOOLSET        ', N'TRE')
, (51, N'METERS         ', N'IS_AVAILABLE   ', N'true', N'9', NULL, NULL, NULL, N'TOOLSET        ', N'ADM')
, (52, N'METERS         ', N'IS_AVAILABLE   ', N'true', N'8', NULL, NULL, NULL, N'TOOLSET        ', N'ENG')
, (53, N'METERS         ', N'IS_AVAILABLE   ', N'true', N'7', NULL, NULL, NULL, N'TOOLSET        ', N'TMA')
, (54, N'METERS         ', N'IS_AVAILABLE   ', N'true', N'6', NULL, NULL, NULL, N'TOOLSET        ', N'TMB')
, (56, N'SENSORS        ', N'IS_AVAILABLE   ', N'false', N'1', NULL, NULL, NULL, N'TOOLSET        ', N'ALL')
, (57, N'SENSORS        ', N'IS_AVAILABLE   ', N'false', N'2', NULL, NULL, NULL, N'TOOLSET        ', N'OPE')
, (58, N'SENSORS        ', N'IS_AVAILABLE   ', N'false', N'3', NULL, NULL, NULL, N'TOOLSET        ', N'PE')
, (59, N'SENSORS        ', N'IS_AVAILABLE   ', N'false', N'4', NULL, NULL, NULL, N'TOOLSET        ', N'PM')
, (60, N'SENSORS        ', N'IS_AVAILABLE   ', N'false', N'5', NULL, NULL, NULL, N'TOOLSET        ', N'CAM')
, (61, N'SENSORS        ', N'IS_AVAILABLE   ', N'false', N'5', NULL, NULL, NULL, N'TOOLSET        ', N'BDM')
, (62, N'SENSORS        ', N'IS_AVAILABLE   ', N'true', N'7', NULL, NULL, NULL, N'TOOLSET        ', N'TRC')
, (63, N'SENSORS        ', N'IS_AVAILABLE   ', N'true', N'8', NULL, NULL, NULL, N'TOOLSET        ', N'TRE')
, (64, N'SENSORS        ', N'IS_AVAILABLE   ', N'true', N'9', NULL, NULL, NULL, N'TOOLSET        ', N'ADM')
, (65, N'SENSORS        ', N'IS_AVAILABLE   ', N'true', N'8', NULL, NULL, NULL, N'TOOLSET        ', N'ENG')
, (66, N'SENSORS        ', N'IS_AVAILABLE   ', N'true', N'7', NULL, NULL, NULL, N'TOOLSET        ', N'TMA')
, (67, N'SENSORS        ', N'IS_AVAILABLE   ', N'true', N'6', NULL, NULL, NULL, N'TOOLSET        ', N'TMB')
, (68, N'UTILITY        ', N'IS_AVAILABLE   ', N'false', N'1', NULL, NULL, NULL, N'TOOLSET        ', N'ALL')
, (69, N'UTILITY        ', N'IS_AVAILABLE   ', N'false', N'2', NULL, NULL, NULL, N'TOOLSET        ', N'OPE')
, (70, N'UTILITY        ', N'IS_AVAILABLE   ', N'false', N'3', NULL, NULL, NULL, N'TOOLSET        ', N'PE')
, (71, N'UTILITY        ', N'IS_AVAILABLE   ', N'false', N'4', NULL, NULL, NULL, N'TOOLSET        ', N'PM')
, (72, N'UTILITY        ', N'IS_AVAILABLE   ', N'false', N'5', NULL, NULL, NULL, N'TOOLSET        ', N'CAM')
, (73, N'UTILITY        ', N'IS_AVAILABLE   ', N'false', N'5', NULL, NULL, NULL, N'TOOLSET        ', N'BDM')
, (74, N'UTILITY        ', N'IS_AVAILABLE   ', N'true', N'7', NULL, NULL, NULL, N'TOOLSET        ', N'TRC')
, (75, N'UTILITY        ', N'IS_AVAILABLE   ', N'true', N'8', NULL, NULL, NULL, N'TOOLSET        ', N'TRE')
, (76, N'UTILITY        ', N'IS_AVAILABLE   ', N'true', N'9', NULL, NULL, NULL, N'TOOLSET        ', N'ADM')
, (77, N'UTILITY        ', N'IS_AVAILABLE   ', N'true', N'8', NULL, NULL, NULL, N'TOOLSET        ', N'ENG')
, (78, N'UTILITY        ', N'IS_AVAILABLE   ', N'true', N'7', NULL, NULL, NULL, N'TOOLSET        ', N'TMA')
, (79, N'UTILITY        ', N'IS_AVAILABLE   ', N'true', N'6', NULL, NULL, NULL, N'TOOLSET        ', N'TMB')
, (80, N'FORMULAS       ', N'IS_AVAILABLE   ', N'false', N'1', NULL, NULL, NULL, N'TOOLSET        ', N'ALL')
, (81, N'FORMULAS       ', N'IS_AVAILABLE   ', N'false', N'2', NULL, NULL, NULL, N'TOOLSET        ', N'OPE')
, (82, N'FORMULAS       ', N'IS_AVAILABLE   ', N'false', N'3', NULL, NULL, NULL, N'TOOLSET        ', N'PE')
, (83, N'FORMULAS       ', N'IS_AVAILABLE   ', N'false', N'4', NULL, NULL, NULL, N'TOOLSET        ', N'PM')
, (84, N'FORMULAS       ', N'IS_AVAILABLE   ', N'false', N'5', NULL, NULL, NULL, N'TOOLSET        ', N'CAM')
, (85, N'FORMULAS       ', N'IS_AVAILABLE   ', N'false', N'5', NULL, NULL, NULL, N'TOOLSET        ', N'BDM')
, (86, N'FORMULAS       ', N'IS_AVAILABLE   ', N'true', N'7', NULL, NULL, NULL, N'TOOLSET        ', N'TRC')
, (87, N'FORMULAS       ', N'IS_AVAILABLE   ', N'true', N'8', NULL, NULL, NULL, N'TOOLSET        ', N'TRE')
, (88, N'FORMULAS       ', N'IS_AVAILABLE   ', N'true', N'9', NULL, NULL, NULL, N'TOOLSET        ', N'ADM')
, (89, N'FORMULAS       ', N'IS_AVAILABLE   ', N'true', N'8', NULL, NULL, NULL, N'TOOLSET        ', N'ENG')
, (90, N'FORMULAS       ', N'IS_AVAILABLE   ', N'true', N'7', NULL, NULL, NULL, N'TOOLSET        ', N'TMA')
, (91, N'FORMULAS       ', N'IS_AVAILABLE   ', N'true', N'6', NULL, NULL, NULL, N'TOOLSET        ', N'TMB')
, (104, N'CONTROLLERSETUP', N'IS_AVAILABLE   ', N'true', N'6', NULL, NULL, NULL, N'TOOLSET        ', N'TMB')
, (105, N'CONTROLLERSETUP', N'IS_AVAILABLE   ', N'true', N'7', NULL, NULL, NULL, N'TOOLSET        ', N'TMA')
, (106, N'CONTROLLERSETUP', N'IS_AVAILABLE   ', N'true', N'8', NULL, NULL, NULL, N'TOOLSET        ', N'ENG')
, (107, N'CONTROLLERSETUP', N'IS_AVAILABLE   ', N'true', N'9', NULL, NULL, NULL, N'TOOLSET        ', N'ADM')
, (108, N'CONTROLLERSETUP', N'IS_AVAILABLE   ', N'true', N'8', NULL, NULL, NULL, N'TOOLSET        ', N'TRE')
, (109, N'CONTROLLERSETUP', N'IS_AVAILABLE   ', N'false', N'5', NULL, NULL, NULL, N'TOOLSET        ', N'BDM')
, (110, N'CONTROLLERSETUP', N'IS_AVAILABLE   ', N'false', N'5', NULL, NULL, NULL, N'TOOLSET        ', N'CAM')
, (111, N'CONTROLLERSETUP', N'IS_AVAILABLE   ', N'true', N'7', NULL, NULL, NULL, N'TOOLSET        ', N'TRC')
, (112, N'CONTROLLERSETUP', N'IS_AVAILABLE   ', N'false', N'4', NULL, NULL, NULL, N'TOOLSET        ', N'PM')
, (113, N'CONTROLLERSETUP', N'IS_AVAILABLE   ', N'false', N'3', NULL, NULL, NULL, N'TOOLSET        ', N'PE')
, (114, N'CONTROLLERSETUP', N'IS_AVAILABLE   ', N'false', N'2', NULL, NULL, NULL, N'TOOLSET        ', N'OPE')
, (115, N'CONTROLLERSETUP', N'IS_AVAILABLE   ', N'false', N'1', NULL, NULL, NULL, N'TOOLSET        ', N'ALL')
, (116, N'PLANTSETUP     ', N'IS_AVAILABLE   ', N'true', N'6', NULL, NULL, NULL, N'TOOLSET        ', N'TMB')
, (117, N'PLANTSETUP     ', N'IS_AVAILABLE   ', N'true', N'7', NULL, NULL, NULL, N'TOOLSET        ', N'TMA')
, (118, N'PLANTSETUP     ', N'IS_AVAILABLE   ', N'true', N'8', NULL, NULL, NULL, N'TOOLSET        ', N'ENG')
, (119, N'PLANTSETUP     ', N'IS_AVAILABLE   ', N'true', N'9', NULL, NULL, NULL, N'TOOLSET        ', N'ADM')
, (120, N'PLANTSETUP     ', N'IS_AVAILABLE   ', N'true', N'8', NULL, NULL, NULL, N'TOOLSET        ', N'TRE')
, (121, N'PLANTSETUP     ', N'IS_AVAILABLE   ', N'true', N'5', NULL, NULL, NULL, N'TOOLSET        ', N'BDM')
, (122, N'PLANTSETUP     ', N'IS_AVAILABLE   ', N'true', N'5', NULL, NULL, NULL, N'TOOLSET        ', N'CAM')
, (123, N'PLANTSETUP     ', N'IS_AVAILABLE   ', N'true', N'7', NULL, NULL, NULL, N'TOOLSET        ', N'TRC')
, (124, N'PLANTSETUP     ', N'IS_AVAILABLE   ', N'true', N'4', NULL, NULL, NULL, N'TOOLSET        ', N'PM')
, (125, N'PLANTSETUP     ', N'IS_AVAILABLE   ', N'true', N'3', NULL, NULL, NULL, N'TOOLSET        ', N'PE')
, (126, N'PLANTSETUP     ', N'IS_AVAILABLE   ', N'true', N'2', NULL, NULL, NULL, N'TOOLSET        ', N'OPE')
, (127, N'PLANTSETUP     ', N'IS_AVAILABLE   ', N'true', N'1', NULL, NULL, NULL, N'TOOLSET        ', N'ALL')
, (165, N'PRODUCTIONCHART', N'IS_AVAILABLE   ', N'true', N'6', NULL, NULL, NULL, N'TOOLSET        ', N'TMB')
, (166, N'PRODUCTIONCHART', N'IS_AVAILABLE   ', N'true', N'7', NULL, NULL, NULL, N'TOOLSET        ', N'TMA')
, (167, N'PRODUCTIONCHART', N'IS_AVAILABLE   ', N'false', N'8', NULL, NULL, NULL, N'TOOLSET        ', N'ENG')
, (168, N'PRODUCTIONCHART', N'IS_AVAILABLE   ', N'true', N'9', NULL, NULL, NULL, N'TOOLSET        ', N'ADM')
, (169, N'PRODUCTIONCHART', N'IS_AVAILABLE   ', N'false', N'8', NULL, NULL, NULL, N'TOOLSET        ', N'TRE')
, (170, N'PRODUCTIONCHART', N'IS_AVAILABLE   ', N'false', N'5', NULL, NULL, NULL, N'TOOLSET        ', N'BDM')
, (171, N'CHEMICALCHART  ', N'IS_AVAILABLE   ', N'true', N'6', NULL, NULL, NULL, N'TOOLSET        ', N'TMB')
, (172, N'CHEMICALCHART  ', N'IS_AVAILABLE   ', N'true', N'7', NULL, NULL, NULL, N'TOOLSET        ', N'TMA')
, (173, N'CHEMICALCHART  ', N'IS_AVAILABLE   ', N'false', N'8', NULL, NULL, NULL, N'TOOLSET        ', N'ENG')
, (174, N'CHEMICALCHART  ', N'IS_AVAILABLE   ', N'true', N'9', NULL, NULL, NULL, N'TOOLSET        ', N'ADM')
, (175, N'CHEMICALCHART  ', N'IS_AVAILABLE   ', N'false', N'8', NULL, NULL, NULL, N'TOOLSET        ', N'TRE')
, (176, N'CHEMICALCHART  ', N'IS_AVAILABLE   ', N'false', N'5', NULL, NULL, NULL, N'TOOLSET        ', N'BDM')
, (178, N'WASHERGROUPS   ', N'IS_AVAILABLE   ', N'true', N'6', NULL, NULL, NULL, N'TOOLSET        ', N'TMB')
, (179, N'WASHERGROUPS   ', N'IS_AVAILABLE   ', N'true', N'7', NULL, NULL, NULL, N'TOOLSET        ', N'TMA')
, (180, N'WASHERGROUPS   ', N'IS_AVAILABLE   ', N'true', N'8', NULL, NULL, NULL, N'TOOLSET        ', N'ENG')
, (181, N'WASHERGROUPS   ', N'IS_AVAILABLE   ', N'true', N'9', NULL, NULL, NULL, N'TOOLSET        ', N'ADM')
, (182, N'WASHERGROUPS   ', N'IS_AVAILABLE   ', N'false', N'5', NULL, NULL, NULL, N'TOOLSET        ', N'BDM')
, (183, N'WASHERGROUPS   ', N'IS_AVAILABLE   ', N'false', N'5', NULL, NULL, NULL, N'TOOLSET        ', N'CAM')
, (184, N'WASHERGROUPS   ', N'IS_AVAILABLE   ', N'true', N'7', NULL, NULL, NULL, N'TOOLSET        ', N'TRC')
, (185, N'WASHERGROUPS   ', N'IS_AVAILABLE   ', N'false', N'4', NULL, NULL, NULL, N'TOOLSET        ', N'PM')
, (186, N'WASHERGROUPS   ', N'IS_AVAILABLE   ', N'false', N'3', NULL, NULL, NULL, N'TOOLSET        ', N'PE')
, (187, N'WASHERGROUPS   ', N'IS_AVAILABLE   ', N'false', N'2', NULL, NULL, NULL, N'TOOLSET        ', N'OPE')
, (188, N'WASHERGROUPS   ', N'IS_AVAILABLE   ', N'false', N'1', NULL, NULL, NULL, N'TOOLSET        ', N'ALL')
, (190, N'STORAGETANKS   ', N'IS_AVAILABLE   ', N'true', N'6', NULL, NULL, NULL, N'TOOLSET        ', N'TMB')
, (194, N'STORAGETANKS   ', N'IS_AVAILABLE   ', N'true', N'7', NULL, NULL, NULL, N'TOOLSET        ', N'ENG')
, (195, N'STORAGETANKS   ', N'IS_AVAILABLE   ', N'true', N'8', NULL, NULL, NULL, N'TOOLSET        ', N'ADM')
, (196, N'STORAGETANKS   ', N'IS_AVAILABLE   ', N'true', N'9', NULL, NULL, NULL, N'TOOLSET        ', N'TRE')
, (197, N'STORAGETANKS   ', N'IS_AVAILABLE   ', N'flase', N'5', NULL, NULL, NULL, N'TOOLSET        ', N'BDM')
, (198, N'STORAGETANKS   ', N'IS_AVAILABLE   ', N'false', N'5', NULL, NULL, NULL, N'TOOLSET        ', N'CAM')
, (199, N'STORAGETANKS   ', N'IS_AVAILABLE   ', N'true', N'7', NULL, NULL, NULL, N'TOOLSET        ', N'TRC')
, (200, N'STORAGETANKS   ', N'IS_AVAILABLE   ', N'false', N'4', NULL, NULL, NULL, N'TOOLSET        ', N'PM')
, (201, N'STORAGETANKS   ', N'IS_AVAILABLE   ', N'false', N'3', NULL, NULL, NULL, N'TOOLSET        ', N'PE')
, (202, N'STORAGETANKS   ', N'IS_AVAILABLE   ', N'false', N'2', NULL, NULL, NULL, N'TOOLSET        ', N'OPE')
, (203, N'STORAGETANKS   ', N'IS_AVAILABLE   ', N'false', N'1', NULL, NULL, NULL, N'TOOLSET        ', N'ALL')
, (204, N'WASHER         ', N'IS_AVAILABLE   ', N'true', N'6', NULL, NULL, NULL, N'TOOLSET        ', N'ENG')
, (205, N'WASHER         ', N'IS_AVAILABLE   ', N'true', N'7', NULL, NULL, NULL, N'TOOLSET        ', N'ENG')
, (206, N'WASHER         ', N'IS_AVAILABLE   ', N'true', N'8', NULL, NULL, NULL, N'TOOLSET        ', N'ADM')
, (207, N'WASHER         ', N'IS_AVAILABLE   ', N'true', N'9', NULL, NULL, NULL, N'TOOLSET        ', N'TRE')
, (208, N'WASHER         ', N'IS_AVAILABLE   ', N'false', N'5', NULL, NULL, NULL, N'TOOLSET        ', N'BDM')
, (209, N'WASHER         ', N'IS_AVAILABLE   ', N'false', N'5', NULL, NULL, NULL, N'TOOLSET        ', N'CAM')
, (210, N'WASHER         ', N'IS_AVAILABLE   ', N'true', N'7', NULL, NULL, NULL, N'TOOLSET        ', N'TRC')
, (211, N'WASHER         ', N'IS_AVAILABLE   ', N'false', N'4', NULL, NULL, NULL, N'TOOLSET        ', N'PM')
, (212, N'WASHER         ', N'IS_AVAILABLE   ', N'false', N'3', NULL, NULL, NULL, N'TOOLSET        ', N'PE')
, (213, N'WASHER         ', N'IS_AVAILABLE   ', N'false', N'2', NULL, NULL, NULL, N'TOOLSET        ', N'OPE')
, (214, N'WASHER         ', N'IS_AVAILABLE   ', N'false', N'1', NULL, NULL, NULL, N'TOOLSET        ', N'ALL')
, (215, N'MANUAL INPUTS  ', N'IS_AVAILABLE   ', N'true', N'3', NULL, NULL, NULL, N'TOOLSET        ', N'PE')
, (216, N'MANUAL INPUTS  ', N'IS_AVAILABLE   ', N'true', N'4', NULL, NULL, NULL, N'TOOLSET        ', N'PM')
, (217, N'REPORTS        ', N'IS_AVAILABLE   ', N'true', N'5', NULL, NULL, NULL, N'TOOLSET        ', N'CAM')
, (218, N'WASHERGROUPS   ', N'IS_AVAILABLE   ', N'true', N'8', NULL, NULL, NULL, N'TOOLSET        ', N'TRE')
, (219, N'STORAGETANKS   ', N'IS_AVAILABLE   ', N'true', N'7', NULL, NULL, NULL, N'TOOLSET        ', N'TMA')
, (220, N'MANUAL INPUTS  ', N'IS_AVAILABLE   ', N'true', N'7', NULL, NULL, NULL, N'TOOLSET        ', N'TRC')
, (221, N'WASHER         ', N'IS_AVAILABLE   ', N'true', N'7', NULL, NULL, NULL, N'TOOLSET        ', N'TMA')
, (222, N'REPORTS        ', N'IS_AVAILABLE   ', N'true', N'3', NULL, NULL, NULL, N'TOOLSET        ', N'PE')
, (223, N'REPORTS        ', N'IS_AVAILABLE   ', N'true', N'4', NULL, NULL, NULL, N'TOOLSET        ', N'PM')
, (224, N'REPORTS        ', N'IS_AVAILABLE   ', N'true', N'7', NULL, NULL, NULL, N'TOOLSET        ', N'TRC')
, (225, N'REPORTS        ', N'IS_AVAILABLE   ', N'true', N'5', NULL, NULL, NULL, N'TOOLSET        ', N'BDM')
, (226, N'WASHER         ', N'IS_AVAILABLE   ', N'true', N'6', NULL, NULL, NULL, N'TOOLSET        ', N'TMB')
, (227, N'DASHBOARDS'	 , N'IS_AVAILABLE'	 , N'true', N'7', NULL,NULL,NULL,'TOOLSET','TRC')
, (228,'DASHBOARDS','IS_AVAILABLE', 'true',N'4',NULL,NULL,NULL,'TOOLSET','PM')
, (229,'DASHBOARDS','IS_AVAILABLE', 'true',N'3',NULL,NULL,NULL,'TOOLSET','PE')
, (230,'DASHBOARDS','IS_AVAILABLE', 'true',N'2',NULL,NULL,NULL,'TOOLSET','OPE')
, (231,'DASHBOARDS','IS_AVAILABLE', 'true',N'1',NULL,NULL,NULL,'TOOLSET','ALL')
, (240,'DASHBOARDS','IS_AVAILABLE', 'true',N'5',NULL,NULL,NULL,'TOOLSET','CAM')
, (232,'REPORTS','IS_AVAILABLE', 'true',N'7',NULL,NULL,NULL,'TOOLSET','TRC')
, (233,'REPORTS','IS_AVAILABLE', 'true',N'4',NULL,NULL,NULL,'TOOLSET','PM')
, (234,'REPORTS','IS_AVAILABLE', 'true',N'3',NULL,NULL,NULL,'TOOLSET','PE')
, (235,'REPORTS','IS_AVAILABLE', 'true',N'2',NULL,NULL,NULL,'TOOLSET','OPE')
, (236,'REPORTS','IS_AVAILABLE', 'true',N'1',NULL,NULL,NULL,'TOOLSET','ALL')


SET	IDENTITY_INSERT	TCD.ConduitMenuRoleMapping	ON

MERGE	TCD.ConduitMenuRoleMapping				AS			TARGET
USING	@tempConduitMenuRoleMapping			AS			SOURCE
ON	TARGET.MappingId					=			SOURCE.MappingId
WHEN	NOT MATCHED		THEN
INSERT	(MappingID			,SectionCode		,SettingCode		,SettingValue			,UserRole			,UserID
,	TagId				,TagType			,UsageUICode		,UserRoleCode			)
VALUES	(SOURCE.MappingID	,SOURCE.SectionCode	,SOURCE.SettingCode	,SOURCE.SettingValue	,SOURCE.UserRole	,SOURCE.UserID
,	SOURCE.TagId		,SOURCE.TagType		,SOURCE.UsageUICode	,SOURCE.UserRoleCode	);

SET	IDENTITY_INSERT	[TCD].ConduitMenuRoleMapping	OFF
END




/*	DataSource

Identity: Id
PRIMARY KEY: Id
FK:	NONE
Table is referenced by foreign key
ConduitLocal.dbo.Field: FK_Field_DataSource
ConduitLocal.dbo.FieldSource: FK_FieldSource_DataSource

select	*	from	DataSource					--REFERENCED by Field, FieldSource (populate before these); No FKs (does not refer ANY)
*/
BEGIN
SET			@TableName				=			'DataSource'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempDataSource		TABLE	(
TempId					INT				IDENTITY(1, 1)
,	Id						INT				NOT	NULL
,	Name					NVARCHAR(50)
,	[Description]			NVARCHAR(250)
)

--Populate temp table variable with the input data
INSERT	@tempDataSource	(
Id	,Name	,[Description]	)
VALUES	(1	,N'ConduitFieldLabel1'	,N'ConduitFieldLabel1'	)
,	(2	,N'ConduitFieldLabel2'	,N'ConduitFieldLabel2'	)
,	(3	,N'ConduitFieldLabel3'	,N'ConduitFieldLabel3'	)
,	(4	,N'ConduitFieldLabel4'	,N'ConduitFieldLabel4'	)
,	(5	,N'ConduitFieldLabel5'	,N'ConduitFieldLabel5'	)
,	(6	,N'ConduitFieldLabel6'	,N'ConduitFieldLabel6'	)
,	(7	,N'L1 Switch'			,N'L1 Switch')
,	(8, N'Dosing Line Mode', N'Dosing Line Mode')
,	(9, N'External Take Over ME', N'Group Number used for external take over ME in PLC XL 2T')
,	(10, N'Controller Version', N'Controller Version for Central and Decentral General tab')
,	(11, N'Com Ports', N'Com Ports for Central and Decentral General tab');

SET	IDENTITY_INSERT	TCD.DataSource	ON

MERGE	TCD.DataSource					AS			TARGET
USING	@tempDataSource				AS			SOURCE
ON	TARGET.Id					=			SOURCE.Id
WHEN	NOT MATCHED		THEN
INSERT	(Id			,Name			,[Description]			)
VALUES	(SOURCE.Id	,SOURCE.Name	,SOURCE.[Description]	);

SET	IDENTITY_INSERT	[TCD].DataSource	OFF
END




/*	DataType

Identity: Id
PRIMARY KEY: Id
FK:	NONE
Table is referenced by foreign key
ConduitLocal.dbo.Field: FK_Field_DataType

select	*	from	DataType					--REFERENCED by Field (populate before this); No FKs (does not refer ANY)
*/
BEGIN
SET			@TableName				=			'DataType'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempDataType		TABLE	(
TempId					INT				IDENTITY(1, 1)
,	Id						INT				NOT	NULL
,	Name					NVARCHAR(50)	NOT	NULL
)

--Populate temp table variable with the input data
INSERT	@tempDataType	(
Id	,Name		)
VALUES	(1	,N'INT'		)
,	(2	,N'STRING'	)
,	(3	,N'BOOL'	)
,	(4	,N'CHAR'	)
,	(5	,N'DECIMAL'	)

SET	IDENTITY_INSERT	TCD.DataType	ON

MERGE	TCD.DataType					AS			TARGET
USING	@tempDataType				AS			SOURCE
ON	TARGET.Id					=			SOURCE.Id
WHEN	NOT MATCHED		THEN
INSERT	(Id			,Name			)
VALUES	(SOURCE.Id	,SOURCE.Name	);

SET	IDENTITY_INSERT	[TCD].DataType	OFF
END




/*	FieldGroupType

Identity: Id
PRIMARY KEY: Id
FK:	NONE
Table is referenced by foreign key
FieldGroup: FK_FieldGroup_FieldGroupType

select	*	from	FieldGroupType
*/
BEGIN
SET			@TableName				=			'FieldGroupType'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempFieldGroupType		TABLE	(
TempId					INT				IDENTITY(1, 1)
,	Id						INT				NOT	NULL
,	Name					NVARCHAR(50)	NOT	NULL
)

--Populate temp table variable with the input data
INSERT	@tempFieldGroupType	(
Id	,Name			)
VALUES	(1	,N'TABLE'		)
,	(2	,N'PARAMETER'	)
,	(3	,N'FORM'		)
,	(4	,N'WATERUSAGE'	)

SET	IDENTITY_INSERT	TCD.FieldGroupType	ON

MERGE	TCD.FieldGroupType					AS			TARGET
USING	@tempFieldGroupType				AS			SOURCE
ON	TARGET.Id					=			SOURCE.Id
WHEN	NOT MATCHED		THEN
INSERT	(Id			,Name			)
VALUES	(SOURCE.Id	,SOURCE.Name	);

SET	IDENTITY_INSERT	[TCD].FieldGroupType	OFF
END





/*	FieldGroup

No identity column defined.
PRIMARY KEY: Id
FK:
REFERENCES ConduitLocal.dbo.FieldGroupType (Id)
REFERENCES ConduitLocal.dbo.ConduitTabType (Id)
Table is referenced by foreign key:
Field: FK_Field_FieldGroup
FieldGroupFieldMapping: FK_FieldGroupFieldMapping_FieldGroup

select	*	from	FieldGroup
*/
BEGIN
SET			@TableName				=			'FieldGroup'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempFieldGroup			TABLE	(
TempId					INT				IDENTITY(1, 1)
,	Id						INT				NOT	NULL
,	Name					NVARCHAR(250)	NOT	NULL
,	Image_Url				NVARCHAR(250)
,	ControllerModelId		SMALLINT
,	FieldGroupTypeId		INT
,	DisplayOrder			INT
,	HelpText				NVARCHAR(250)
,	TabId					INT
,	ResourceKey				NVARCHAR(250)
,	ControllerTypeId		INT
)

--Populate temp table variable with the input data
INSERT	@tempFieldGroup	(
Id			,Name				,Image_Url		,ControllerModelId	,FieldGroupTypeId		,DisplayOrder
,	HelpText	,TabId				,ResourceKey	,ControllerTypeId)
VALUES	(1	,N'Conduit Field Group1',	NULL	,0	,1	,1,	NULL	,2	,N'FieldGroup_ConduitFieldGroup1'	,NULL	)
,	(2	,N'Conduit Field Group2',	NULL	,0	,1	,2,	NULL	,2	,N'FieldGroup_ConduitFieldGroup2'	,NULL	)
,	(3	,N'Conduit Field Group3',	NULL	,0	,4	,3,	NULL	,2	,N'FieldGroup_ConduitFieldGroup3'	,NULL	)
,	(4	,N'Conduit Field Group4',	NULL	,7	,1	,4,	NULL	,1	,N'FieldGroup_ConduitFieldGroup4'	,2	)
,	(5	,N'Conduit Field Group5',	NULL	,1	,1	,5,	NULL	,1	,N'FieldGroup_ConduitFieldGroup5'	,1	)
,	(6	,N'Conduit Field Group6',	NULL	,1	,1	,6,	NULL	,1	,N'FieldGroup_ConduitFieldGroup6'	,2	)
--Sprint9 additions
,	(7	,N'Conduit Field Group7',	NULL	,1	,1	,7,	null	,3	,N'FieldGroup_ConduitFieldGroup7'	,1	)
,	(8	,N'Conduit Field Group8',	NULL	,1	,1	,8,	null	,3	,N'FieldGroup_ConduitFieldGroup8'	,2	)
,	(9	,N'Conduit Field Group9',	NULL	,3	,1	,9,	NULL	,1	,N'FieldGroup_ConduitFieldGroup9'	,2	)
,	(10	,N'Conduit Field Group10',	NULL	,3	,1	,10,NULL	,3	,N'FieldGroup_ConduitFieldGroup10'	,2	)
,	(11 ,N'Conduit Field Group11',	NULL	,13	,1	,11,NULL	,1	,N'FieldGroup_ConduitFieldGroup11'	,1	)
,	(12 ,N'Conduit Field Group12',	NULL	,13	,1	,12,NULL	,3	,N'FieldGroup_ConduitFieldGroup12'	,1	)
,	(13 ,N'Conduit Field Group13',	NULL	,5	,1	,13,NULL	,1	,N'FieldGroup_ConduitFieldGroup11'	,1	)
,	(14 ,N'Conduit Field Group14',	NULL	,5	,1	,14,NULL	,1	,N'FieldGroup_ConduitFieldGroup12'	,2	)

,   (15,'Conduit Field Group15',NULL,2,1,15,NULL,1,'FieldGroup_ConduitFieldGroup15',1)
,  (16,'Conduit Field Group16',NULL,2,1,16,NULL,1,'FieldGroup_ConduitFieldGroup16',2)
,   (17,'Conduit Field Group17',NULL,2,1,17,NULL,3,'FieldGroup_ConduitFieldGroup17',1)
,   (18,'Conduit Field Group18',NULL,2,1,18,NULL,3,'FieldGroup_ConduitFieldGroup18',2)
-- For My Control Field Groups
,	(19, N'Connexx', NULL, 7, 3, 19, NULL, 3, N'FieldGroup_Connexx', 2)
,	(20, N'my Control Parameters', NULL, 7, 3, 20, NULL, 3, N'FieldGroup_myControlParameters', 2)
,	(21, N'Water flow switches for dosing lines', NULL, 7, 3, 21, NULL, 3, N'FieldGroup_Waterflowswitchesfordosinglines', 2)
,	(22, N'Dosing Line Modes', NULL, 7, 2, 22, NULL, 3, N'FieldGroup_DosingLineModes', 2)
 -- PLC XL
,	(23, N'PLC XL 2T General', NULL, 11, 1, 23, NULL, 1, N'FieldGroup_PLC_XL_2T_General', 14)
,    (24, N'Connexx', NULL, 11, 3, 24, N'Field Group in PLC XL 2T Advance Tab', 3, N'FieldGroup_Connex', 14)
,    (25, N'PLC XL Parameters', NULL, 11, 3, 25, NULL, 3, N'FieldGroup_PLC_XL_Parameters', 14 )
,    (26, N'Input PLC Card Configuration', NULL, 11, 3, 26, NULL, 3, N'FieldGroup_Input_PLC_Card_Configuration', 14 )
,    (27, N'PLC XL 1 T 5 W General', NULL, 11, 1, 27, NULL, 1, N'FieldGroup_PLC_XL_1T_5W_General', 13 )
,    (28, N'Connexx', NULL, 11, 3, 28, N'Field Group in PLC XL 1 T 5 W Advance Tab', 3, N'FieldGroup_Connexx', 13 )
,    (29, N'PLC XL Parameters', NULL, 11, 3, 29, NULL, 3, N'FieldGroup_PLC_XL_Parameters', 13 )
,    (30, N'Input PLC Card Configuration', NULL, 11, 3, 30, NULL, 3, N'FieldGroup_Input_PLC_Card_Configuration', 13 )
,    (31, N'PLC XL 10 W General', NULL, 11, 1, 31, NULL, 1, N'FieldGroup_PLC_XL_10W_General', 12 )
,    (32, N'Connexx', NULL, 11, 3, 32, N'Field Group in PLC XL 10 W Advance Tab', 3, N'FieldGroup_Connexx', 12 )
,    (33, N'PLC XL Parameters', NULL, 11, 3, 33, NULL, 3, N'FieldGroup_PLC_XL_Parameters', 12 )
,    (34, N'Input PLC Card Configuration', NULL, 11, 3, 34, NULL, 3, N'FieldGroup_Input_PLC_Card_Configuration', 12 )
-- EControl Plus
,    (35, N'E Control Plus 8 Washer General', NULL, 8, 1, 35, NULL, 1, N'FieldGroup_E_Control_Plus_8_Washer_General', 6 )
,    (36, N'Connexx', NULL, 8, 3, 36, N'Field Group in E Control Plus Advance Tab', 3, N'FieldGroup_Connexx', 6 )
,    (37, N'E Control Plus Parameters', NULL, 8, 3, 37, NULL, 3, N'FieldGroup_E_Control_Plus_8_Washer_Parameters', 6 )
,    (38, N'E Control Plus 1 Tunnel 6 Washer General', NULL, 8, 1, 38, NULL, 1, N'FieldGroup_E_Control_Plus_1_Tunnel_6_Washer_General', 7 )
,    (39, N'Connexx', NULL, 8, 3, 39, N'Field Group in E Control Plus Advance Tab', 3, N'FieldGroup_Connexx', 7 )
,    (40, N'E Control Plus Parameters', NULL, 8, 3, 40, NULL, 3, N'FieldGroup_E_Control_Plus_1_Tunnel_6_Washer_Parameters', 7 )
-- EControl Central
,    (41, N'EControl Central 6 Washer General', NULL, 9, 1, 41, N'EControl Central 6 Washer General Tab', 1, N'FieldGroup_EControl_Central_6_Washer_General', 8 )
,    (42, N'Connexx', NULL, 9, 3, 42, N'EControl Central 6 Washer Advanced Tab Connex', 3, N'FieldGroup_Connexx', 8 )
,    (43, N'EControl Central Parameters', NULL, 9, 3, 43, N'EControl Central 6 Washer Advanced Tab Parameters', 3, N'FieldGroup_EControl_Central_Parameters', 8 )
,    (44, N'EControl Central 1 Tunnel 4 Washer General', NULL, 9, 1, 44, N'EControl Central 1 Tunnel 4 Washer General Tab', 1, N'FieldGroup_EControl_Central_1_Tunnel_4_Washer_General', 10 )
,    (45, N'Connexx', NULL, 9, 3, 45, N'EControl Central 1 Tunnel 4 Washer Advanced Tab Connex', 3, N'FieldGroup_Connexx', 10 )
,    (46, N'EControl Central Parameters', NULL, 9, 3, 46, N'EControl Central 1 Tunnel 4 Washer Advanced Tab Parameters', 3, N'FieldGroup_EControl_Central_Parameters', 10 )
-- EControl Decentral
,    (47, N'EControl Decentral 4 Washer General', NULL, 14, 1, 47, N'EControl Decentral 4 Washer General Tab', 1, N'FieldGroup_EControl_Decentral_4_Washer_General', 9 )
,    (48, N'Connexx', NULL, 14, 3, 48, N'EControl Decentral 4 Washer Advanced Tab Connex', 3, N'FieldGroup_Connexx', 9 )
,    (49, N'EControl Decentral Parameters', NULL, 14, 3, 49, N'EControl Decentral 4 Washer Advanced Tab Parameters', 3, N'FieldGroup_EControl_Decentral_Parameters', 9 )
,    (50, N'EControl Decentral 1 Tunnel 2 Washer General', NULL, 14, 1, 50, N'EControl Decentral 1 Tunnel 2 Washer General Tab', 1, N'FieldGroup_EControl_Decentral_1_Tunnel_2_Washer_General', 11 )
,    (51, N'Connexx', NULL, 14, 3, 51, N'EControl Central 1 Tunnel 2 Washer Advanced Tab Connex', 3, N'FieldGroup_Connexx', 11 )
,    (52, N'EControl Decentral Parameters', NULL, 14, 3, 52, N'EControl Decentral 1 Tunnel 2 Washer Advanced Tab Parameters', 3, N'FieldGroup_EControl_Decentral_Parameters', 11 )
-- Ecodose
,    (53, N'Ecodose 8 Washers General', NULL, 10, 1, 53, N'Ecodose 8 Washers General Tab', 1, N'FieldGroup_Ecodose_8_Washers_General', 6 )
,    (54, N'Connexx', NULL, 10, 3, 54, N'Ecodose 8 Washers Advanced Tab Connex', 3, N'FieldGroup_Connexx', 6 )
,    (55, N'Ecodose Parameters', NULL, 10, 3, 55, N'Ecodose 8 Washers Advanced Tab Parameters', 3, N'FieldGroup_Ecodose_Parameters', 6)


MERGE	TCD.FieldGroup			AS			TARGET
USING	@tempFieldGroup		AS			SOURCE
ON	TARGET.Id			=			SOURCE.Id
WHEN	NOT MATCHED		THEN
INSERT	(Id				,Name				,Image_Url			,ControllerModelId			,FieldGroupTypeId			,DisplayOrder
,	HelpText		,TabId				,ResourceKey		,ControllerTypeId			)
VALUES	(SOURCE.Id		,SOURCE.Name		,SOURCE.Image_Url	,SOURCE.ControllerModelId	,SOURCE.FieldGroupTypeId	,SOURCE.DisplayOrder
,	SOURCE.HelpText	,SOURCE.TabId		,SOURCE.ResourceKey	,SOURCE.ControllerTypeId	);
END





/*	FieldType

Identity: Id
PRIMARY KEY: Id
FK:NONE
Table is referenced by foreign key:
ConduitLocal.dbo.Field: FK_Field_FieldType

select	*	from	FieldType					--NO FKs (no dependency!); REFERENCED BY Field: FK_Field_FieldType
*/
BEGIN
SET			@TableName				=			'FieldType'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempFieldType			TABLE	(
TempId					INT				IDENTITY(1, 1)
,	Id						INT				NOT	NULL
,	Name					NVARCHAR(50)	NOT	NULL
)

--Populate temp table variable with the input data
INSERT	@tempFieldType	(
Id	,Name		)
VALUES	(1	,N'BUTTON'	)
,	(2	,N'CHECKBOX')
,	(3	,N'FILE'	)
,	(4	,N'HIDDEN'	)
,	(5	,N'IMAGE'	)
,	(6	,N'PASSWORD')
,	(7	,N'RADIO'	)
,	(8	,N'RESET'	)
,	(9	,N'SUBMIT'	)
,	(10	,N'TEXT'	)
,	(11	,N'SELECT'	)
,	(12	,N'DATETIME')
,	(13	,N'EMPTY')

SET	IDENTITY_INSERT	TCD.FieldType	ON

MERGE	TCD.FieldType			AS			TARGET
USING	@tempFieldType		AS			SOURCE
ON	TARGET.Id			=			SOURCE.Id
WHEN	NOT MATCHED		THEN
INSERT	(Id				,Name			)
VALUES	(SOURCE.Id		,SOURCE.Name	);

SET	IDENTITY_INSERT	[TCD].FieldType	OFF
END





/*	Field

Identity: Id
PRIMARY KEY: Id
FK:
REFERENCES REFERENCES ConduitLocal.dbo.DataSource (Id)
REFERENCES ConduitLocal.dbo.DataType (Id)
REFERENCES ConduitLocal.dbo.FieldGroup (Id)
REFERENCES ConduitLocal.dbo.FieldType (Id)
Table is referenced by foreign key:
FieldGroupFieldMapping: FK_FieldGroupFieldMapping_Field

select	*	from	Field
*/
BEGIN
SET			@TableName				=			'Field'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempField				TABLE	(
TempId					INT				IDENTITY(1, 1)
,	Id						INT				NOT	NULL
,	TypeId					INT				NOT	NULL
,	Label					NVARCHAR(200)	NOT	NULL
,	[Min]					NVARCHAR(50)
,	[Max]					NVARCHAR(50)
,	FieldGroupId			INT
,	DataSourceId			INT
,	IsMandatory				BIT
,	HelpText				NVARCHAR(450)
,	HelpTextURL				NVARCHAR(250)
,	DataTypeId				INT
,	DataCategoryId			INT
,	CurrencyId				INT
,	DisplayOrder			INT
,	ResourceKey				NVARCHAR(250)
,	DefaultValue			NVARCHAR(150)
,	IsEditable				BIT
,	Name					VARCHAR(100)
,	HasFieldTag				VARCHAR	(250)	NULL
,	DefaultFieldTag			VARCHAR	(250)	NULL
,	ClassName				VARCHAR	(250)	NULL
)

--Populate temp table variable with the input data
INSERT	@tempField	(
Id	,TypeId	,Label			,[Min]			,[Max]		,FieldGroupId	,DataSourceId	,IsMandatory
,	HelpText			,HelpTextURL		,DataTypeId	,DataCategoryId	,CurrencyId	,DisplayOrder	,ResourceKey
,	DefaultValue		,IsEditable			,Name		,HasFieldTag	,DefaultFieldTag, ClassName)
VALUES (1, 7, N'ConduitFieldLabel1', NULL, NULL, NULL, 1, 1, NULL, NULL, 2, NULL, NULL, 1, N'Field_ConduitFieldLabel1', NULL, 1, NULL, NULL, NULL, NULL)
,(2, 10, N'ConduitFieldLabel2', NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 2, N'Field_ConduitFieldLabel2 ', NULL, 1, NULL, NULL, NULL, NULL)
,(3, 10, N'ConduitFieldLabel3', NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Field_ConduitFieldLabel3', NULL, 1, NULL, NULL, NULL, NULL)
,(4, 10, N'ConduitFieldLabel4', NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 2, N'Field_ConduitFieldLabel4', NULL, 1, NULL, NULL, NULL, NULL)
,(5, 10, N'ConduitFieldLabel5', NULL, NULL,  NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 1, N'Field_ConduitFieldLabel5', NULL, 1, NULL, NULL, NULL, NULL)
,(6, 10, N'ConduitFieldLabel6', NULL, NULL,  NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 1, N'Field_ConduitFieldLabel6', NULL, 1, NULL, NULL, NULL, NULL)
,(11, 10, N'OPC Server', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 7, N'OPC Server', N'RSLinx OPC Server', 1, NULL, NULL, NULL, NULL)
,(12, 10, N'Preflush Time(sec)', N'0', NULL,  NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 4, N'Preflush Time(sec)', N'10', 1, NULL, 'Tag_PREF', N'C5:16.PRE', NULL)
,(13, 10, N'Controller Number', N'0', NULL,  NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', NULL, 0, N'ControllerNumber', NULL, NULL, 'dispNumber')
,(14, 10, N'OPC Object', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 5, N'OPC Object', NULL, 1, NULL, NULL, NULL, NULL)
,(15, 10, N'Postflush Time(sec)', N'0', NULL,  NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 5, N'Postflush Time(sec)',  N'30', 1, NULL, 'Tag_POSF', N'C5:20.PRE', NULL)
,(16, 11, N'Controller Version', NULL, NULL,  NULL, 3, 1, NULL, NULL, 2, NULL, NULL, 5, N'Controller Version', N'1', 1, N'ControllerVersion', NULL, NULL, NULL)
,(17, 10, N'DDE Driver', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 8, N'DDE Driver', NULL, 1, NULL, NULL, NULL, NULL)
,(18, 2, N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 10, N'Active', N'false', 1, N'Active', NULL, NULL, NULL)
,(19, 12, N'Install Date', NULL, NULL,  NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 8, N'Install Date', NULL, 1, N'InstallDate', NULL, NULL, NULL)
,(20, 2, N'Check Water Flow', NULL, NULL,  NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 16, N'Check Water Flow', N'true', 1, NULL, NULL, NULL, NULL)
,(21, 10, N'AMS Net ID Address', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 5, N'AMS Net ID Address', N'10.225.134.21.1.1', 1, NULL, NULL, NULL, NULL)
,(22, 10, N'IP Address', NULL, NULL,  NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 15, N'IP Address', NULL, 1, NULL, NULL, NULL, NULL)
,(23, 10, N'Com port Number', N'0', NULL,  NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 17, N'Com port Number', NULL, 1, NULL, NULL, NULL, NULL)
,(27, 10, N'Preflush Time(sec)', N'0', NULL,  NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 4, N'Preflush Time(sec)', N'5', 1, NULL, 'Tag_PREF', N'L_PREF', NULL)
,(28, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', NULL, 0, N'ControllerNumber', NULL, NULL, 'dispNumber')
,(30, 10, N'Postflush Time(sec)', N'0', NULL,  NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 5, N'Postflush Time(sec)',  N'10', 1, NULL, 'Tag_POSF', N'L_POSF', NULL)
,(31, 11, N'Controller Version', NULL, NULL,  NULL, 3, 1, NULL, NULL, 2, NULL, NULL, 7, N'Controller Version', NULL, 1, N'ControllerVersion', NULL, NULL, NULL)
,(33, 2,  N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 18,  N'Active', N'false', 1, N'Active', NULL, NULL, NULL)
,(34, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 10, N'Install Date', NULL, 1, N'InstallDate', NULL, NULL, NULL)
,(35, 2, N'Check Water Flow', NULL, NULL,  NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 11, N'Check Water Flow', N'true', 1, NULL, NULL, NULL, NULL)
,(47, 10, N'AMS Net ID Address', NULL, NULL,NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 2, N'AMS Net ID Address', N'10.225.134.21.1.1', 1, NULL, NULL, NULL, NULL)
,(48, 10, N'IP Address', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 5, N'IP Address', NULL, 1, NULL, NULL, NULL, NULL)
,(49, 10, N'Com port Number', N'0', NULL,  NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 8, N'Com port Number', NULL, 1, NULL, NULL, NULL, NULL)
,(51, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 4, N'Controller Number', NULL, 0, N'ControllerNumber', NULL, NULL, 'dispNumber')
,(53, 2,  N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 9,  N'Active', N'false', 1, N'Active', NULL, NULL, NULL)
,(54, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 10, N'Install Date', NULL, 1, N'InstallDate', NULL, NULL, NULL)
--Sprint9 additions
,(56, 10, N'Factors Multiplier', N'0', NULL,  NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 2, N'Factors_Multiplier', N'10', 0, NULL, NULL, NULL, NULL)
,(57, 10, N'OZ/Second Multiplier', N'0', NULL,  NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 4, N'OZ/Second_Multiplier', N'10', 0, NULL, NULL, NULL, NULL)
,(58, 10, N'Injection Quantity Multiplier', N'0', NULL, NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 6, N'Injection_Quantity_Multiplier', N'10', 0, NULL, NULL, NULL, NULL)
,(59, 10, N'Max Wash Formulas', N'0', N'127', NULL, NULL, 1, N'Max number of wash formulas due to space restrictions', NULL, 1, NULL, NULL, 1, N'Max_Wash_Formulas', N'127', 1, NULL, 'Tag_MWF', N'L_MWF','WashFormula')
,(60, 10, N'Max Formula Injections', N'0', N'10',  NULL, NULL, 1, N'Max number of injections due to space restrictions', NULL, 1, NULL, NULL, 2, N'Max_Formula_Injections', N'8', 1, NULL, 'Tag_MFI', N'L_MFI','MaxFormulaInjection')
,(61, 10, N'No. of Chemical Valves', N'0', N'16',  NULL, NULL, 1, N'number of chemical valves', NULL, 1, NULL, NULL, 3, N'No._of_Chemical_Valves', N'12', 1, NULL, 'Tag_NCHVLV', N'L_MVLV','ChemicalValves')
,(62, 2, N'Webport Ftp Enabled', NULL, NULL, NULL, 4, 1, N'Is a Webport being used for data buffering', NULL, 4, NULL, NULL, 7, N'Webport_Ftp_Enabled', N'False', 1, NULL, NULL, NULL, 'webportEnable')
,(63, 10, N'Webport IP', N'0', NULL,  NULL, NULL, 1, N'ip address of webport (ex:ftp://192.168.0.240/)', NULL, 2, NULL, NULL, 8, N'Webport_IP', NULL, 1, NULL, NULL, NULL, 'webport webportIp')
,(64, 10, N'Webport Login', NULL, NULL, NULL, NULL, 1, N'Login for webport communication', NULL, 2, NULL, NULL, 8, N'Webport_Login', NULL, 1, NULL, NULL, NULL, 'webport')
,(65, 10, N'Webport Password', NULL, NULL,  NULL, NULL, 1, N'Password for webport communication', NULL, 2, NULL, NULL, 9, N'Webport_Password', NULL, 1, NULL, NULL, NULL, 'webport')
,(66, 10, N'Factors Multiplier', N'0', NULL, NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 2, N'Factors_MultiplieR', N'1', 1, NULL, NULL, NULL, NULL)
,(67, 10, N'OZ/Second Multiplier', N'0', NULL,  NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 4, N'OZ/Second_Multiplier', N'1', 1, NULL, NULL, NULL, NULL)
,(68, 10, N'Injection Quantity Multiplier', N'0', NULL, NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 6, N'Injection_Quantity_Multiplier', N'1', 1, NULL, NULL, NULL, NULL)
,(69, 10, N'Max Wash Formulas', N'0', N'99',  NULL, NULL, 1, N'Max number of wash formulas due to space restrictions', NULL, 1, NULL, NULL, 1, N'Max_Wash_Formulas', N'99', 1, NULL, 'Tag_MWF', N'N7:130','WashFormula')
,(70, 10, N'Max Formula Injections', N'0', N'6', NULL, NULL, 1, N'Max number of injections due to space restrictions', NULL, 1, NULL, NULL, 2, N'Max_Formula_Injections', N'6', 1, NULL, 'Tag_MFI', N'N7:131','MaxFormulaInjection')
,(71, 10, N'No. of Chemical Valves', N'0', N'12',  NULL, NULL, 1, N'number of chemical valves', NULL, 1, NULL, NULL, 3, N'No._of_Chemical_Valves', N'10', 1, NULL, 'Tag_NCHVLV', N'','ChemicalValves')
,(72, 2, N'Webport Ftp Enabled', NULL, NULL,  NULL, 4, 1, N'Is a Webport being used for data buffering', NULL, 4, NULL, NULL, 11, N'Webport_Ftp_Enabled', N'False', 1, NULL, NULL, NULL, 'webportEnable')
,(73, 10, N'Webport IP', N'0', NULL,  NULL, NULL, 1, N'ip address of webport (ex:ftp://192.168.0.240/)', NULL, 2, NULL, NULL, 12, N'Webport_IP', NULL, 1, NULL, NULL, NULL, 'webport webportIp')
,(74, 10, N'Webport Login', NULL, NULL,  NULL, NULL, 1, N'Login for webport communication', NULL, 2, NULL, NULL, 13, N'Webport_Login', NULL, 1, NULL, NULL, NULL, 'webport')
,(75, 6, N'Webport Password', NULL, NULL,  NULL, NULL, 1, N'Password for webport communication', NULL, 2, NULL, NULL, 14, N'Webport_Password', NULL, 1, NULL, NULL, NULL, 'webport')
,(76, 10, N'ControllerName', NULL, NULL,  NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL)
,(77, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 9, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL)
,(78, 10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL)
,(79, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 10, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL)
,(80, 2, N'Set PLC Time', NULL, NULL, NULL, 4, 1, N'SetPLCTime', NULL, 4, NULL, NULL, 9, N'Set_PLC_Time', NULL, 1, NULL, NULL, NULL, N'PLCTime')
,(81, 13, N'Year', NULL, NULL,  NULL, NULL, 0, N'Year', NULL, 2, NULL, NULL, 10, N'Year', NULL, 1, NULL, 'Tag_YEAR', N'S:37', N'PLCTimeStamp')
,(82, 13, N'Month', NULL, NULL,  NULL, NULL, 0, N'Month', NULL, 2, NULL, NULL, 11, N'Month', NULL, 1, NULL, 'Tag_MNTH', N'S:38', N'PLCTimeStamp')
,(83, 13, N'Day', NULL, NULL,  NULL, NULL, 0, N'Day', NULL, 2, NULL, NULL, 12, N'Day', NULL, 1, NULL,'Tag_DAY', N'S:39', N'PLCTimeStamp')
,(84, 13, N'Hour', NULL, NULL, NULL, NULL, 0, N'Hour', NULL, 2, NULL, NULL, 13, N'Hour', NULL, 1, NULL, 'Tag_HOUR', N'S:40', N'PLCTimeStamp')
,(85, 13, N'Minute', NULL, NULL,  NULL, NULL, 0, N'Minute', NULL, 2, NULL, NULL, 14, N'Minute', NULL, 1, NULL, 'Tag_MIN', N'S:41', N'PLCTimeStamp')
,(86, 13, N'Second', NULL, NULL,  NULL, NULL, 0, N'Second', NULL, 2, NULL, NULL, 15, N'Second', NULL, 1, NULL, 'Tag_SC', N'S:42', N'PLCTimeStamp')
,(87, 13, N'Link Integrity Address', NULL, NULL,  NULL, NULL, 0, NULL, NULL, 2, NULL, NULL, 5, N'Link_Integrity_Address', NULL, 1, NULL, 'Tag_LIADD', N'N9:3', NULL)
,(88, 13, N'Name Link', NULL, NULL,  NULL, NULL, 0, NULL, NULL, 2, NULL, NULL, 6, N'Name_Link', NULL, 1, NULL, 'Tag_NLNK', N'ST149:0', NULL)
,(89, 2, N'Automatic Weight Enabled', NULL, NULL,  NULL, NULL, 0, NULL, NULL, 4, NULL, NULL, 7, N'Automatic_weight_Enabled', NULL, 1, NULL, 'Tag_AWEA', N'B3:9/0', N'disableAWEA')
,(90, 2, N'Ratio Dosing Enabled', NULL, NULL,  NULL, NULL, 0, NULL, NULL, 4, NULL, NULL, 8, N'Ratio_Dosing_Enabled', NULL, 1, NULL, 'Tag_RDE', N'B3:10/0', N'disableRatioDosing')
,(91, 2, N'Set PLC Time', NULL, NULL,  NULL, NULL, 1, N'SetPLCTime', NULL, 4, NULL, NULL, 10, N'Set_PLC_Time', NULL, 1, NULL, NULL, NULL, N'PLCTime')
,(92, 13, N'Year', NULL, NULL,  NULL, NULL, 1, N'Year', NULL, 2, NULL, NULL, 11, N'Year', NULL, 1, NULL, 'Tag_YEAR', N'L_YEAR', N'PLCTimeStamp')
,(93, 13, N'Month', NULL, NULL,  NULL, NULL, 0, N'Month', NULL, 2, NULL, NULL, 12, N'Month', NULL, 1, NULL, 'Tag_MNTH', N'L_MNTH', N'PLCTimeStamp')
,(94, 13, N'Day', NULL, NULL, NULL, NULL, 0, N'Day', NULL, 2, NULL, NULL, 13, N'Day', NULL, 1, NULL, 'Tag_DAY', N'L_DAY', N'PLCTimeStamp')
,(95, 13, N'Hour', NULL, NULL,  NULL, NULL, 0, N'Hour', NULL, 2, NULL, NULL, 14, N'Hour', NULL, 1, NULL, 'Tag_HOUR', N'L_HOUR', N'PLCTimeStamp')
,(96, 13, N'Minute', NULL, NULL,  NULL, NULL, 0, N'Minute', NULL, 2, NULL, NULL, 15, N'Minute', NULL, 1, NULL, 'Tag_MIN', N'L_MIN', N'PLCTimeStamp')
,(97, 13, N'Second', NULL, NULL, NULL, NULL, 0, N'Second', NULL, 2, NULL, NULL, 16, N'Second', NULL, 1, NULL, 'Tag_SC', N'L_SEC', N'PLCTimeStamp')
,(98, 13, N'Link Integrity Address', NULL, NULL, NULL, NULL, 0, NULL, NULL, 2, NULL, NULL, 6, N'Link_Integrity_Address', NULL, 1, NULL, 'Tag_LIADD', N'L_LIC', NULL)
,(99, 13, N'Name Link', NULL, NULL, NULL, NULL, 0, NULL, NULL, 2, NULL, NULL, 7, N'Name_Link', NULL, 1, NULL, 'Tag_NLNK', N'L_NAME', NULL)
,(100, 2, N'Automatic Weight Enabled', NULL, NULL, NULL, NULL, 0, NULL, NULL, 4, NULL, NULL, 8, N'Automatic_Weight_Enabled', NULL, 1, NULL, 'Tag_AWEA', N'L_AWEE', N'disableAWEA')
,(101, 2, N'Ratio Dosing Enabled', NULL, NULL,  NULL, NULL, 0, NULL, NULL, 4, NULL, NULL, 9, N'Ratio_Dosing_Enabled', NULL, 1, NULL, 'Tag_RDE', N'L_RATD', N'disableRatioDosing')
-- TDI COntroller
,(102,10, N'OPC Server', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 7, N'OPC Server',  N'RSLinx OPC Server', 1, NULL, NULL, NULL, NULL)
,(103,10, N'Controller Number', N'0', NULL,  NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', NULL, 0, N'ControllerNumber', NULL, NULL, 'dispNumber')
,(104,11, N'Controller Version', NULL, NULL,  NULL, 3, 1, NULL, NULL, 2, NULL, NULL, 5, N'Controller Version', N'1', 1, N'ControllerVersion', NULL, NULL, NULL)
,(105,2, N'Active', NULL, NULL,  NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 10, N'Active', N'false', 1, N'Active', NULL, NULL, NULL)
,(106,12, N'Install Date', NULL, NULL,  NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 8, N'Install Date', NULL, 1, N'InstallDate', NULL, NULL, NULL)
,(107,10, N'Factors Multiplier', N'0', NULL,NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 2, N'Factors_MultiplieR', N'1', 1, NULL, NULL, NULL, NULL)
,(108,10, N'OZ/Second Multiplier', N'0', NULL,  NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 4, N'OZ/Second_Multiplier', N'1', 1, NULL, NULL, NULL, NULL)
,(109,10, N'Injection Quantity Multiplier', N'0', NULL, NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 6, N'Injection_Quantity_Multiplier', N'1', 1, NULL, NULL, NULL, NULL)
,(110,2, N'Webport Ftp Enabled', NULL, NULL, NULL, 4, 1, N'Is a Webport being used for data buffering', NULL, 4, NULL, NULL, 11, N'Webport_Ftp_Enabled', N'False', 1, NULL, NULL, NULL, 'webportEnable')
,(111,10, N'Webport IP', N'0', NULL, NULL, NULL, 1, N'ip address of webport (ex:ftp://192.168.0.240/)', NULL, 2, NULL, NULL, 12, N'Webport_IP', NULL, 1, NULL, NULL, NULL, 'webport webportIp')
,(112,10, N'Webport Login', NULL, NULL,  NULL, NULL, 1, N'Login for webport communication', NULL, 2, NULL, NULL, 13, N'Webport_Login', NULL, 1, NULL, NULL, NULL, 'webport')
,(113,6, N'Webport Password', NULL, NULL, NULL, NULL, 1, N'Password for webport communication', NULL, 2, NULL, NULL, 14, N'Webport_Password', NULL, 1, NULL, NULL, NULL, 'webport')
,(114,10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL)
,(115,10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 9, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL)
,(116,10, N'IP Address', NULL, NULL,  NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 5, N'IP Address', NULL, 1, NULL, NULL, NULL, NULL)
,(117,10, N'Com port Number', N'0', NULL,  NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 8, N'Com port Number', NULL, 1, NULL, NULL, NULL, NULL)
,(118,10, N'Preflush Time(sec)', N'0', NULL,  NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 4, N'Preflush Time(sec)', N'10', 1, NULL, 'Tag_PREF', N'C5:16.PRE', NULL)
,(119,10, N'Postflush Time(sec)', N'0', NULL,  NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 5, N'Postflush Time(sec)', N'30', 1, NULL, 'Tag_POSF', N'C5:20.PRE', NULL)
,(120,10, N'Max Wash Formulas', N'0', N'99',  NULL, NULL, 1, N'Max number of wash formulas due to space restrictions', NULL, 1, NULL, NULL, 1, N'Max_Wash_Formulas', N'99', 1, NULL, 'Tag_MWF', N'N7:130','WashFormula')
,(121,10, N'Max Formula Injections', N'0', N'6', NULL, NULL, 1, N'Max number of injections due to space restrictions', NULL, 1, NULL, NULL, 2, N'Max_Formula_Injections', N'6', 1, NULL, 'Tag_MFI', N'N7:131','MaxFormulaInjection')
,(122,10, N'No. of Chemical Valves', N'0', N'16',  NULL, NULL, 1, N'number of chemical valves', NULL, 1, NULL, NULL, 3, N'No._of_Chemical_Valves', N'10', 1, NULL, 'Tag_NCHVLV', N'','ChemicalValves')
,(123,2, N'Set PLC Time', NULL, NULL, NULL, 4, 1, N'SetPLCTime', NULL, 4, NULL, NULL, 9, N'Set_PLC_Time', NULL, 1, NULL, NULL, NULL, N'PLCTime')
,(124,13, N'Year', NULL, NULL,  NULL, NULL, 0, N'Year', NULL, 2, NULL, NULL, 10, N'Year', NULL, 1, NULL, 'Tag_YEAR', N'S:37', N'PLCTimeStamp')
,(125,13, N'Month', NULL, NULL,  NULL, NULL, 0, N'Month', NULL, 2, NULL, NULL, 11, N'Month', NULL, 1, NULL, 'Tag_MNTH', N'S:38', N'PLCTimeStamp')
,(126,13, N'Day', NULL, NULL,  NULL, NULL, 0, N'Day', NULL, 2, NULL, NULL, 12, N'Day', NULL, 1, NULL,'Tag_DAY', N'S:39', N'PLCTimeStamp')
,(127,13, N'Hour', NULL, NULL, NULL, NULL, 0, N'Hour', NULL, 2, NULL, NULL, 13, N'Hour', NULL, 1, NULL, 'Tag_HOUR', N'S:40', N'PLCTimeStamp')
,(128,13, N'Minute', NULL, NULL,  NULL, NULL, 0, N'Minute', NULL, 2, NULL, NULL, 14, N'Minute', NULL, 1, NULL, 'Tag_MIN', N'S:41', N'PLCTimeStamp')
,(129,13, N'Second', NULL, NULL,  NULL, NULL, 0, N'Second', NULL, 2, NULL, NULL, 15, N'Second', NULL, 1, NULL, 'Tag_SC', N'S:42', N'PLCTimeStamp')
,(130,13, N'Link Integrity Address', NULL, NULL,  NULL, NULL, 0, NULL, NULL, 2, NULL, NULL, 5, N'Link_Integrity_Address', NULL, 1, NULL, 'Tag_LIADD', N'N9:3', NULL)
,(131,13, N'Name Link', NULL, NULL,  NULL, NULL, 0, NULL, NULL, 2, NULL, NULL, 6, N'Name_Link', NULL, 1, NULL, 'Tag_NLNK', N'ST149:0', NULL)
,(132,2, N'Automatic Weight Enabled', NULL, NULL,  NULL, NULL, 0, NULL, NULL, 4, NULL, NULL, 7, N'Automatic_weight_Enabled', NULL, 1, NULL, 'Tag_AWEA', N'B3:9/0', N'disableAWEA')
,(133,2, N'Ratio Dosing Enabled', NULL, NULL,  NULL, NULL, 0, NULL, NULL, 4, NULL, NULL, 8, N'Ratio_Dosing_Enabled', NULL, 1, NULL, 'Tag_RDE', N'B3:10/0', N'disableRatioDosing')
-- UTILITY LOGGER
,(134, 10, N'OPC Server', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 7, N'OPC Server',  N'RSLinx OPC Server', 1, NULL, NULL, NULL, NULL)
,(135, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', NULL, 0, N'ControllerNumber', NULL, NULL, 'dispNumber')
,(136, 11, N'Controller Version', NULL, NULL, NULL, 3, 1, NULL, NULL, 2, NULL, NULL, 5, N'Controller Version', N'1', 1, N'ControllerVersion', NULL, NULL, NULL)
,(137, 2, N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 9, N'Active', N'false', 1, N'Active', NULL, NULL, NULL)
,(138, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 8, N'Install Date', NULL, 1, N'InstallDate', NULL, NULL, NULL)
,(139, 10, N'Factors Multiplier', N'0', NULL, NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 2, N'Factors_Multiplier', N'1', 1, NULL, NULL, NULL, NULL)
,(140, 10, N'OZ/Second Multiplier', N'0', NULL, NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 4, N'OZ/Second_Multiplier ', N'1', 1, NULL, NULL, NULL, NULL)
,(141, 10, N'Injection Quantity Multiplier', N'0', NULL, NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 6, N'Injection_Quantity_Multiplier', N'1', 1, NULL, NULL, NULL, NULL)
,(142, 2, N'Webport Ftp Enabled', NULL, NULL, NULL, 4, 1, N'Is a Webport being used for data buffering', NULL, 4, NULL, NULL, 11, N'Webport_Ftp_Enabled                                                                         ', N'False', 1, NULL, NULL, NULL, 'webportEnable')
,(143, 10, N'Webport IP', N'0', NULL, NULL, NULL, 1, N'ip address of webport (ex:ftp://192.168.0.240/)', NULL, 2, NULL, NULL, 12, N'Webport_IP ', NULL, 1, NULL, NULL, NULL, 'webport webportIp')
,(144, 10, N'Webport Login', NULL, NULL, NULL, NULL, 1, N'Login for webport communication', NULL, 2, NULL, NULL, 13, N'Webport_Login', NULL, 1, NULL, NULL, NULL, 'webport')
,(145, 6, N'Webport Password', NULL, NULL, NULL, NULL, 1, N'Password for webport communication', NULL, 2, NULL, NULL, 14, N'Webport_Password', NULL, 1, NULL, NULL, NULL, 'webport')
,(146, 10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL)
,(147, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 10, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL)
,(148, 10, N'IP Address', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 5, N'IP Address', NULL, 1, NULL, NULL, NULL, NULL)
,(149, 10, N'Com port Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 8, N'Com port Number', NULL, 1, NULL, NULL, NULL, NULL)
,(150, 10, N'AMS Net ID Address', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 5, N'AMS Net ID Address', N'10.225.134.21.1.1', 1, NULL, NULL, NULL, NULL)
,(151, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', NULL, 0, N'ControllerNumber', NULL, NULL, 'dispNumber')
,(152, 11, N'Controller Version', NULL, NULL, NULL, 3, 1, NULL, NULL, 2, NULL, NULL, 5, N'Controller Version', N'1', 1, N'ControllerVersion', NULL, NULL, NULL)
,(153, 2,  N'Active', NULL, NULL, NULL, 4, 0, NULL, NULL, 4, NULL, NULL, 9, N'ConduitEnable', N'false', 1, N'Active', NULL, NULL, NULL)
,(154, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 8, N'Install Date', NULL, 1, N'InstallDate', NULL, NULL, NULL)
,(155, 10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name ', NULL, 1, N'TopicName', NULL, NULL, NULL)
,(156, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 10, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL)

,(157, 10, N'OPC Server', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 7, N'OPC Server', N'RSLinx OPC Server', 1, NULL, NULL, NULL, NULL)

,(158, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', NULL, 0, N'ControllerNumber', NULL, NULL, 'dispNumber')

,(159, 11, N'Controller Version', NULL, NULL, NULL, 3, 1, NULL, NULL, 2, NULL, NULL, 5, N'Controller Version', N'1', 1, N'ControllerVersion', NULL, NULL, NULL)

,(160, 2, N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 10, N'Active', N'false', 1, N'Active', NULL, NULL, NULL)

,(161, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 8, N'Install Date', NULL, 1, N'InstallDate', NULL, NULL, NULL)

,(162, 10, N'Factors Multiplier', N'0', NULL, NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 2, N'Factors_MultiplieR', N'1', 1, NULL, NULL, NULL, NULL)

,(163, 10, N'OZ/Second Multiplier', N'0', NULL, NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 4, N'OZ/Second_Multiplier', N'1', 1, NULL, NULL, NULL, NULL)

,(164, 10, N'Injection Quantity Multiplier', N'0', NULL, NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 6, N'Injection_Quantity_Multiplier', N'1', 1, NULL, NULL, NULL, NULL)

,(165, 2, N'Webport Ftp Enabled', NULL, NULL, NULL, 4, 1, N'Is a Webport being used for data buffering', NULL, 4, NULL, NULL, 11, N'Webport_Ftp_Enabled', N'False', 1, NULL, NULL, NULL, 'webportEnable')

,(166, 10, N'Webport IP', N'0', NULL, NULL, NULL, 1, N'ip address of webport (ex:ftp://192.168.0.240/)', NULL, 2, NULL, NULL, 12, N'Webport_IP', NULL, 1, NULL, NULL, NULL, 'webport webportIp')

,(167, 10, N'Webport Login', NULL, NULL, NULL, NULL, 1, N'Login for webport communication', NULL, 2, NULL, NULL, 13, N'Webport_Login', NULL, 1, NULL, NULL, NULL, 'webport')

,(168, 6, N'Webport Password', NULL, NULL, NULL, NULL, 1, N'Password for webport communication', NULL, 2, NULL, NULL, 14, N'Webport_Password', NULL, 1, NULL, NULL, NULL, 'webport')

,(169, 10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name  ', NULL, 1, N'TopicName', NULL, NULL, NULL)

,(170, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 9, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL)

---16

,(171, 10, N'AMS Net ID Address', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 5, N'AMS Net ID Address', N'10.225.134.21.1.1', 1, NULL, NULL, NULL, NULL)

,(172, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', NULL, 0, N'ControllerNumber', NULL, NULL, 'dispNumber')

,(173, 2, N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 18, N'Active', N'false', 1, N'Active', NULL, NULL, NULL)

,(174, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 10, N'Install Date', NULL, 1, N'InstallDate', NULL, NULL, NULL)

,(175, 10, N'Factors Multiplier', N'0', NULL, NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 2, N'Factors_Multiplier', N'10', 0, NULL, NULL, NULL, NULL)

,(176, 10, N'OZ/Second Multiplier', N'0', NULL, NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 4, N'OZ/Second_Multiplier', N'10', 0, NULL, NULL, NULL, NULL)

,(177, 10, N'Injection Quantity Multiplier', N'0', NULL, NULL, NULL, 1, N'Multiplier to convert to integer', NULL, 1, NULL, NULL, 6, N'Injection_Quantity_Multiplier', N'10', 0, NULL, NULL, NULL, NULL)

,(178, 10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL)

,(179, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 10, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL)

--17

,(180, 10, N'Preflush Time(sec)', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 4, N'Preflush Time(sec)', N'10', 1, NULL, N'Tag_PREF', N'C5:16.PRE', NULL)

,(181, 10, N'Postflush Time(sec)', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 5, N'Postflush Time(sec)', N'30', 1, NULL, N'Tag_POSF', N'C5:20.PRE', NULL)

,(182, 10, N'Max Wash Formulas', N'0', N'99', NULL, NULL, 1, N'Max number of wash formulas due to space restrictions', NULL, 1, NULL, NULL, 1, N'Max_Wash_Formulas', N'99', 1, NULL, N'Tag_MWF', N'N7:130', N'WashFormula')

,(183, 10, N'Max Formula Injections', N'0', N'6', NULL, NULL, 1, N'Max number of injections due to space restrictions', NULL, 1, NULL, NULL, 2, N'Max_Formula_Injections', N'6', 1, NULL, N'Tag_MFI', N'N7:131', N'MaxFormulaInjection')

,(184, 10, N'No. of Chemical Valves', N'0', N'12', NULL, NULL, 1, N'number of chemical valves', NULL, 1, NULL, NULL, 3, N'No._of_Chemical_Valves', N'10', 1, NULL, N'Tag_NCHVLV', N'', N'ChemicalValves')

,(185, 2, N'Set PLC Time', NULL, NULL, NULL, 4, 1, N'SetPLCTime', NULL, 4, NULL, NULL, 9, N'Set_PLC_Time', NULL, 1, NULL, NULL, NULL, N'PLCTime')

,(186, 13, N'Year', NULL, NULL, NULL, NULL, 0, N'Year', NULL, 2, NULL, NULL, 10, N'Year', NULL, 1, NULL, N'Tag_YEAR', N'S:37', N'PLCTimeStamp')

,(187, 13, N'Month', NULL, NULL, NULL, NULL, 0, N'Month', NULL, 2, NULL, NULL, 11, N'Month', NULL, 1, NULL, N'Tag_MNTH', N'S:38', N'PLCTimeStamp')

,(188, 13, N'Day', NULL, NULL, NULL, NULL, 0, N'Day', NULL, 2, NULL, NULL, 12, N'Day', NULL, 1, NULL, N'Tag_DAY', N'S:39', N'PLCTimeStamp')

,(189, 13, N'Hour', NULL, NULL, NULL, NULL, 0, N'Hour', NULL, 2, NULL, NULL, 13, N'Hour', NULL, 1, NULL, N'Tag_HOUR', N'S:40', N'PLCTimeStamp')

,(190, 13, N'Minute', NULL, NULL, NULL, NULL, 0, N'Minute', NULL, 2, NULL, NULL, 14, N'Minute', NULL, 1, NULL, N'Tag_MIN', N'S:41', N'PLCTimeStamp')

,(191, 13, N'Second', NULL, NULL, NULL, NULL, 0, N'Second', NULL, 2, NULL, NULL, 15, N'Second', NULL, 1, NULL, N'Tag_SC', N'S:42', N'PLCTimeStamp')

,(192, 13, N'Link Integrity Address', NULL, NULL, NULL, NULL, 0, NULL, NULL, 2, NULL, NULL, 5, N'Link_Integrity_Address', NULL, 1, NULL, N'Tag_LIADD', N'N9:3', NULL)

,(193, 13, N'Name Link', NULL, NULL, NULL, NULL, 0, NULL, NULL, 2, NULL, NULL, 6, N'Name_Link', NULL, 1, NULL, N'Tag_NLNK', N'ST149:0', NULL)

,(194, 2, N'Automatic Weight Enabled', NULL, NULL, NULL, NULL, 0, NULL, NULL, 4, NULL, NULL, 7, N'Automatic_weight_Enabled', NULL, 1, NULL, N'Tag_AWEA', N'B3:9/0', N'disableAWEA')

,(195, 2, N'Ratio Dosing Enabled', NULL, NULL, NULL, NULL, 0, NULL, NULL, 4, NULL, NULL, 8, N'Ratio_Dosing_Enabled', NULL, 1, NULL, N'Tag_RDE', N'B3:10/0', N'disableRatioDosing')

--18

,(196, 10, N'Preflush Time(sec)', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 4, N'Preflush Time(sec)', N'5', 1, NULL, N'Tag_PREF', N'L_PREF', NULL)

,(197, 10, N'Postflush Time(sec)', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 5, N'Postflush Time(sec)', N'10', 1, NULL, N'Tag_POSF', N'L_POSF', NULL)

,(198, 10, N'Max Wash Formulas', N'0', N'127', NULL, NULL, 1, N'Max number of wash formulas due to space restrictions', NULL, 1, NULL, NULL, 1, N'Max_Wash_Formulas', N'127', 1, NULL, N'Tag_MWF', N'L_MWF', N'WashFormula')

,(199, 10, N'Max Formula Injections', N'0', N'10', NULL, NULL, 1, N'Max number of injections due to space restrictions', NULL, 1, NULL, NULL, 2, N'Max_Formula_Injections ', N'8', 1, NULL, N'Tag_MFI', N'L_MFI', N'MaxFormulaInjection')

,(200, 10, N'No. of Chemical Valves', N'0', N'16', NULL, NULL, 1, N'number of chemical valves', NULL, 1, NULL, NULL, 3, N'No._of_Chemical_Valves', N'16', 1, NULL, N'Tag_NCHVLV', N'L_MVLV', N'ChemicalValves')

,(201, 2, N'SetPLCTime', NULL, NULL, NULL, NULL, 1, N'SetPLCTime', NULL, 4, NULL, NULL, 10, N'Set_PLC_Time', NULL, 1, NULL, NULL, NULL, N'PLCTime')

,(202, 13, N'Year', NULL, NULL, NULL, NULL, 1, N'Year', NULL, 2, NULL, NULL, 11, N'Year', NULL, 1, NULL, N'Tag_YEAR', N'L_YEAR', N'PLCTimeStamp')

,(203, 13, N'Month', NULL, NULL, NULL, NULL, 0, N'Month', NULL, 2, NULL, NULL, 12, N'Month', NULL, 1, NULL, N'Tag_MNTH', N'L_MNTH', N'PLCTimeStamp')

,(204, 13, N'Day', NULL, NULL, NULL, NULL, 0, N'Day', NULL, 2, NULL, NULL, 13, N'Day', NULL, 1, NULL, N'Tag_DAY', N'L_DAY', N'PLCTimeStamp')

,(205, 13, N'Hour', NULL, NULL, NULL, NULL, 0, N'Hour', NULL, 2, NULL, NULL, 14, N'Hour', NULL, 1, NULL, N'Tag_HOUR', N'L_HOUR', N'PLCTimeStamp')

,(206, 13, N'Minute', NULL, NULL, NULL, NULL, 0, N'Minute', NULL, 2, NULL, NULL, 15, N'Minute', NULL, 1, NULL, N'Tag_MIN', N'L_MIN', N'PLCTimeStamp')

,(207, 13, N'Second', NULL, NULL, NULL, NULL, 0, N'Second', NULL, 2, NULL, NULL, 16, N'Second', NULL, 1, NULL, N'Tag_SC', N'L_SEC', N'PLCTimeStamp')

,(208, 13, N'Link Integrity Address', NULL, NULL, NULL, NULL, 0, NULL, NULL, 2, NULL, NULL, 6, N'Link_Integrity_Address', NULL, 1, NULL, N'Tag_LIADD', N'L_LIC', NULL)

,(209, 13, N'Name Link', NULL, NULL, NULL, NULL, 0, NULL, NULL, 2, NULL, NULL, 7, N'Name_Link', NULL, 1, NULL, N'Tag_NLNK', N'L_NAME', NULL)

,(210, 2, N'Automatic Weight Enabled', NULL, NULL, NULL, NULL, 0, NULL, NULL, 4, NULL, NULL, 8, N'Automatic_Weight_Enabled', NULL, 1, NULL, N'Tag_AWEA', N'L_AWEE', N'disableAWEA')

,(211, 2, N'Ratio Dosing Enabled', NULL, NULL, NULL, NULL, 0, NULL, NULL, 4, NULL, NULL, 9, N'Ratio_Dosing_Enabled', NULL, 1, NULL, N'Tag_RDE', N'L_RATD', N'disableRatioDosing')

-- My Control Fields for General & Advance tabs
,(212, 10, N'Controller Name', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL)
,(213, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 7, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL)
,(214, 2, N'Enable Connexx', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 1, N'Enable_Connexx', NULL, 1, NULL, NULL, NULL, NULL)
,(215, 10, N'Connexx Alarm delay', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 2, N'Connexx_Alarm_Delay', N'10', 1, NULL, NULL, NULL, NULL)
,(216, 10, N'Hysteresis on Connexx alarm level', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 3, N'Hysteresis on Connexx_Alarm_Level', N'2', 1, NULL, NULL, NULL, NULL)
,(217, 2, N'enVisionEnable', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 4, N'enVisionEnable', N'1', 1, NULL, NULL, NULL, N'mycontrolparams')
,(218, 2, N'Check Water flow', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 10, N'CheckWaterflow', N'1', 1, NULL, NULL, NULL, NULL)
,(219, 2, N'enVision Time out Enable', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 6, N'enVisionTimeoutEnable', N'1', 1, NULL, NULL, NULL, NULL)
,(220, 2, N'Check flow leakage alarm', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 7, N'CheckFlowLeakageAlarm', N'1', 1, NULL, NULL, NULL, NULL)
,(221, 10, N'enVision Timeout Alarm', N'1', N' 65535', NULL, NULL, 1, N'enVision Timeout Alarm', NULL, 2, NULL, NULL, 8, N'enVision Timeout Alarm', N'10', 1, NULL, NULL, NULL, NULL)
,(222, 2, N'Enable reset button', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 9, N'EnableResetButton', N'1', 1, NULL, NULL, NULL, NULL)
,(223, 2, N'Disable Program not finished alarm', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 10, N'Disable Program not finished alarm', N'false', 0, NULL, NULL, NULL, NULL)

--,(224, 10, N'Alarm Reset Time', N'60', 1, NULL, NULL, NULL, NULL)
,(224, 10, N'Alarm Reset Time', N'0', N'65535', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, 11, N'Alarm_Reset_Time', N'60', 1, NULL, NULL, NULL, NULL )
,(225, 10, N'Stop Time Dubix', N'0', N'99', NULL, NULL, NULL, N'Stop Time Dubix', NULL, 2, NULL, NULL, 12, N'StopTimeDubix', N'0', 1, NULL, NULL, NULL, NULL)
,(226, 2, N'Separate Air Pressure and Emergency stop Alarm', NULL, NULL, NULL, NULL, NULL, N'Separate Air Pressure and Emergency stop Alarm', NULL, 4, NULL, NULL, 13, N'SeparateAirPressureandEmergencystopAlarm', N'True', 1, NULL, NULL, NULL, NULL)
,(227, 10, N'Intermediary Rinse Time', N'0', N'999', NULL, NULL, NULL, N'Intermediary Rinse Time', NULL, 2, NULL, NULL, 14, N'IntermediaryRinseTime', N'3', 1, NULL, NULL, NULL, NULL)
,(228, 2, N'Invert Machine Stop', NULL, NULL, NULL, NULL, NULL, N'Invert Machine Stop', NULL, 2, NULL, NULL, 15, N'InvertMachineStop', NULL, 1, NULL, NULL, NULL, NULL)
,(229, 10, N'Filter to generate alarm on analogue values', N'0', N'999', NULL, NULL, NULL, N'Filter to generate alarm on analogue values', NULL, 2, NULL, NULL, 16, N'FiltertogeneratealarmonAnalogue values', N'2', 1, NULL, NULL, NULL, NULL)
,(230, 2, N'Alarm Deep tray enabled', NULL, NULL, NULL, NULL, NULL, N'Alarm Deep tray enabled', NULL, 2, NULL, NULL, 17, N'Alarm_Deep_Tray_Enabled', NULL, 1, NULL, NULL, NULL, NULL)

,(231, 11, N'L1 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 33, N'L1_Switch', NULL, 1, NULL, NULL, NULL, N'DosingLines')
,(232, 11, N'L2 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 34, N'L2_Switch', NULL, 1, NULL, NULL, NULL, N'DosingLines')
,(233, 11, N'L3 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 35, N'L3_Switch', NULL, 1, NULL, NULL, NULL, N'DosingLines')
,(234, 11, N'L4 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 36, N'L4_Switch', NULL, 1, NULL, NULL, NULL, N'DosingLines')
,(235, 11, N'L5 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 37, N'L5_Switch ', NULL, 1, NULL, NULL, NULL, N'DosingLines')
,(236, 11, N'L6 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 38, N'L6_Switch ', NULL, 1, NULL, NULL, NULL, N'DosingLines')
,(237, 11, N'L7 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 39, N'L7_Switch ', NULL, 1, NULL, NULL, NULL, N'DosingLines')

,(238, 11, N'L8 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 40, N'L8_Switch ', NULL, 1, NULL, NULL, NULL, N'DosingLines')
,(239, 11, N'L9 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 41, N'L9_Switch ', NULL, 1, NULL, NULL, NULL, N'DosingLines')
,(240, 11, N'L10 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 42, N'L10_Switch', NULL, 1, NULL, NULL, NULL, N'DosingLines')
,(241, 11, N'L11 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 43, N'L11_Switch', NULL, 1, NULL, NULL, NULL, N'DosingLines')
,(242, 11, N'L12 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 44, N'L12_Switch', NULL, 1, NULL, NULL, NULL, N'DosingLines')
,(243, 11, N'L13 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 45, N'L13_Switch', NULL, 1, NULL, NULL, NULL, N'DosingLines')
,(244, 11, N'L14 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 46, N'L14_Switch', NULL, 1, NULL, NULL, NULL, N'DosingLines')
,(245, 11, N'L15 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 47, N'L15_Switch', NULL, 1, NULL, NULL, NULL, N'DosingLines')
,(246, 11, N'L16 Switch', NULL, NULL, NULL, 7, NULL, NULL, NULL, 2, NULL, NULL, 48, N'L16_Switch', NULL, 1, NULL, NULL, NULL, N'DosingLines')
,(247, 10, N'Line1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 18, N'Line1', NULL, 1, NULL, NULL, NULL, N'LableDosingLines')

,(248, 11, N'Dosing Line Mode1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 19, N'Dosing_Line_Mode1', NULL, 1, NULL, NULL, NULL, NULL)
,(249, 2, N'Enable Auxiliary pump1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 20, N'Enable_Auxiliary_pump1', N'1', 1, NULL, NULL, NULL, NULL)
,(250, 2, N'Flow-meter for Flow check1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 21, N'Flow-meter_for_Flow_check1', N'1', 1, NULL, NULL, NULL, NULL)
,(251, 10, N'No of Pumps Connected to TCR1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 22, N'No_of_Pumps_Connected_to_TCR1', N'8', 1, NULL, NULL, NULL, NULL)
,(252, 10, N'Line2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 23, N'Line2', NULL, 1, NULL, NULL, NULL, N'LableDosingLines')
,(253, 11, N'Dosing Line Mode2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 24, N'Dosing_Line_Mode2', NULL, 1, NULL, NULL, NULL, NULL)

,(254, 2, N'Enable Auxiliary pump2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 25, N'Enable_Auxiliary_pump2', N'1', 1, NULL, NULL, NULL, NULL)
,(255, 2, N'Flow-meter for Flow check2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 26, N'meter_for_Flow_check2', N'1', 1, NULL, NULL, NULL, NULL)
,(256, 10, N'No of Pumps Connected to TCR2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 27, N'No_of_Pumps_Connected_to_TCR2', N'8', 1, NULL, NULL, NULL, NULL)
,(257, 10, N'Line3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 28, N'Line3', NULL, 1, NULL, NULL, NULL, N'LableDosingLines')

,(258, 11, N'Dosing Line Mode3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 29, N'Dosing_Line_Mode3', NULL, 1, NULL, NULL, NULL, NULL)
,(259, 2, N'Enable Auxiliary pump3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 30, N'Enable_Auxiliary_pump3', N'1', 1, NULL, NULL, NULL, NULL)

,(260, 2, N'Flow-meter for Flow check3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 31, N'meter_for_Flow_check3', N'1', 1, NULL, NULL, NULL, NULL)
,(261, 10, N'No of Pumps Connected to TCR3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, 32, N'No_of_Pumps_Connected_to_TCR3', N'0', 1, NULL, NULL, NULL, NULL)

,(262, 10, N'Controller Version',			 NULL, NULL, NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,7,N'Controller_Version',N'1.3.0',1,NULL,NULL,NULL,NULL)

-- PLC XL
,(263, 10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL )
,(264, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 2, N'Install_Date', NULL, 1, N'InstallDate', NULL, NULL, NULL )
,(265, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', N'1', 0, N'ControllerNumber', NULL, NULL, N'dispNumber' )
,(266, 2, N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 4, N'Active', N'false', 1, N'Active', NULL, NULL, NULL )
,(267, 11, N'Controller Version', NULL, NULL, NULL, 3, 1, NULL, NULL, 2, NULL, NULL, 5, N'Controller Version', N'5', 0, N'ControllerVersion', NULL, NULL, NULL )
,(268, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 6, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL )
,(269, 10, N'IP Address', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 7, N'IP_Address', N'10.225.134.1', 1, NULL, NULL, NULL, NULL )
,(270, 2, N'PMR Enabled', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 4, N'PMR_Enabled', N'true', 1, NULL, NULL, NULL, NULL )
,(271, 2, N'Check Water flow Group1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 5, N'Check_Water_flow_Group1', N'true', 1, NULL, NULL, NULL, NULL )
,(272, 2, N'enVision Time out Enable', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 6, N'enVision_Time_out_Enable', N'true', 1, NULL, NULL, NULL, NULL )
,(273, 2, N'Check Water flow Group2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 7, N'Check_Water_flow_Group2', N'true', 1, NULL, NULL, NULL, NULL )
,(274, 10, N'enVision Timeout Alarm', N'1', N'999', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 8, N'enVision_Timeout_Alarm', N'10', 1, NULL, NULL, NULL, NULL )
,(275, 2, N'Check flow leakage alarm Group1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 9, N'Check_flow_leakage_Alarm_Group1', N'true', 1, NULL, NULL, NULL, NULL )
,(276, 10, N'Stop Time Dubix', N'0', N'99', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL )
,(277, 10, N'Stop Time Dubix', N'0', N'99', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 10, N'Stop_Time_Dubix', N'0', 1, NULL, NULL, NULL, NULL )
,(278, 2, N'Check flow leakage alarm Group2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 11, N'Check_Flow_Leakage_Alarm_Group2', N'true', 1, NULL, NULL, NULL, NULL )
,(279, 2, N'Disable Program not finished Alarm', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 12, N'Disable_Program_Not_Finished_Alarm', N'false', 1, NULL, NULL, NULL, NULL )
,(280, 2, N'Start do not generate First Step', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 13, N'Start_Do_Not_Generate_First_Step', N'false', 1, NULL, NULL, NULL, NULL )
,(281, 2, N'Conductivity Compensation Stock Solution Tank 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 14, N'Conductivity_Compensation_Stock_Solution_Tank_1', N'false', 1, NULL, NULL, NULL, NULL )
,(282, 10, N'Alarm Reset Time', N'0', N'32767', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 15, N'Alarm_Reset_Time', N'60', 1, NULL, NULL, NULL, NULL )
,(283, 2, N'Conductivity Compensation Stock Solution Tank 2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 16, N'Conductivity_Compensation_Stock_Solution_Tank_2', N'false', 1, NULL, NULL, NULL, NULL )
,(284, 2, N'Enable Reset button', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 17, N'Enable_Reset_Button', N'true', 1, NULL, NULL, NULL, NULL )
,(285, 2, N'Internal Take-Over Main Equipment No. 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 18, N'Internal_Take-Over_Main_Equipment_No._1', N'false', 1, NULL, NULL, NULL, NULL )
,(286, 2, N'Switch Over from Stock Solution Tank 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 19, N'Switch_Over_from_Stock_Solution_Tank_1', N'false', 1, NULL, NULL, NULL, NULL )
,(287, 2, N'Internal Take-Over Main Equipment No. 2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 20, N'Internal_Take-Over_Main_Equipment_No._2', N'false', 1, NULL, NULL, NULL, NULL )
,(288, 2, N'Switch Over from Stock Solution Tank 2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 21, N'Switch_Over_from_Stock_Solution_Tank_2', N'false', 1, NULL, NULL, NULL, NULL )
,(289, 11, N'Group Number used for external take over ME 1', NULL, NULL, NULL, 9, NULL, NULL, NULL, 2, NULL, NULL, 22, N'Group_Number_Used_For_External_Take_Over_ME_1', NULL, 1, NULL, NULL, NULL, NULL )
,(290, 10, N'External extra flush time ME1 ', N'0', N'999', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 23, N'External_Extra_Flush_Time_ME1', N'0', 1, NULL, NULL, NULL, NULL )
,(291, 11, N'Group Number used for external take over ME 2', NULL, NULL, NULL, 9, NULL, NULL, NULL, 2, NULL, NULL, 24, N'Group_Number_Used_For_External_Take_Over_ME_2', NULL, 1, NULL, NULL, NULL, NULL )
,(292, 10, N'External extra flush time ME2', N'0', N'999', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 25, N'External_Extra_Flush_Time_ME2', N'0', 1, NULL, NULL, NULL, NULL )
,(293, 2, N'Digital Input Card 1 (Signal Machines) Position 0 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 26, N'Digital_Input_Card_1_Signal_Machines_Position_0_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(294, 2, N'Digital Input Card 6 (ME2 + P 10,11,12) Position 0 Rack 2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 27, N'Digital_Input_Card_6_(ME2 + P 10,11,12)_Position_0_Rack_2', N'false', 1, NULL, NULL, NULL, NULL )
,(295, 2, N'Digital Input Card 2 (Signal Machines) Position 1 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 28, N'Digital_Input_Card_2_(Signal_Machines)_Position_1_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(296, 2, N'Analogue Input Card 1 Position 5 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 29, N'Analogue_Input_Card_1_Position_5_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(297, 2, N'Digital Input Card 3 (Dosing Group 1) Position 2 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 30, N'Digital_Input_Card_3_(Dosing_Group_1)_Position_2_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(298, 2, N'Analogue Input Card 2 Position 6 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 31, N'Analogue_Input_Card_2_Position_6_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(299, 2, N'Digital Input Card 4 (Dosing Group 2) Position 3 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 32, N'Digital_Input_Card_4_(Dosing_Group_2)_Position_3_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(300, 2, N'Analogue Input Card 3 Position 1 Rack 3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 33, N'Analogue_Input_Card_3_Position_1_Rack_3', N'false', 1, NULL, NULL, NULL, NULL )
,(301, 2, N'Digital Input Card 5 (Miniterminal) Position 4 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 34, N'Digital_Input_Card_5_(Miniterminal)_Position_4_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(302, 2, N'Digital Input Card 7 (Transfer Carbonell) Position 7 Rack 3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 35, N'Digital_Input_Card_7_(Transfer_Carbonell)_Position_7_Rack_3', N'false', 1, NULL, NULL, NULL, NULL )
,(303, 10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL )
,(304, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 2, N'Install_Date', NULL, 1, N'InstallDate', NULL, NULL, NULL )
,(305, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', N'1', 0, N'ControllerNumber', NULL, NULL, N'dispNumber' )
,(306, 2, N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 4, N'Active', N'false', 1, N'Active', NULL, NULL, NULL )
,(307, 11, N'Controller Version', NULL, NULL, NULL, 3, 1, NULL, NULL, 2, NULL, NULL, 5, N'Controller Version', N'5', 0, N'ControllerVersion', NULL, NULL, NULL )
,(308, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 6, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL )
,(309, 10, N'IP Address', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 7, N'IP_Address', N'10.225.134.1', 1, NULL, NULL, NULL, NULL )
,(310, 2, N'PMR Enabled', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 4, N'PMR_Enabled', N'true', 1, NULL, NULL, NULL, NULL )
,(311, 2, N'Check Water flow Group1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 5, N'Check_Water_flow_Group1', N'true', 1, NULL, NULL, NULL, NULL )
,(312, 2, N'enVision Time out Enable', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 6, N'enVision_Time_out_Enable', N'true', 1, NULL, NULL, NULL, NULL)
,(313, 2, N'Check Water flow Group2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 7, N'Check_Water_flow_Group2', N'true', 1, NULL, NULL, NULL, NULL )
,(314, 10, N'enVision Timeout Alarm', N'1', N'999', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 8, N'enVision_Timeout_Alarm', N'10', 1, NULL, NULL, NULL, NULL )
,(315, 2, N'Check flow leakage alarm Group1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 9, N'Check_flow_leakage_Alarm_Group1', N'true', 1, NULL, NULL, NULL, NULL )
,(316, 10, N'Stop Time Dubix', N'0', N'99', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 10, N'Stop_Time_Dubix', N'0', 1, NULL, NULL, NULL, NULL )
,(317, 2, N'Check flow leakage alarm Group2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 11, N'Check_Flow_Leakage_Alarm_Group2', N'true', 1, NULL, NULL, NULL, NULL )
,(318, 2, N'Disable Program not finished Alarm', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 12, N'Disable_Program_Not_Finished_Alarm', N'false', 1, NULL, NULL, NULL, NULL )
,(319, 2, N'Start do not generate First Step', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 13, N'Start_Do_Not_Generate_First_Step', N'false', 1, NULL, NULL, NULL, NULL )
,(320, 2, N'Conductivity Compensation Stock Solution Tank 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 14, N'Conductivity_Compensation_Stock_Solution_Tank_1', N'false', 1, NULL, NULL, NULL, NULL )
,(321, 10, N'Alarm Reset Time', N'0', N'32767', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 15, N'Alarm_Reset_Time', N'60', 1, NULL, NULL, NULL, NULL )
,(322, 2, N'Conductivity Compensation Stock Solution Tank 2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 16, N'Conductivity_Compensation_Stock_Solution_Tank_2', N'false', 1, NULL, NULL, NULL, NULL )
,(323, 2, N'Enable Reset button', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 17, N'Enable_Reset_Button', N'false', 1, NULL, NULL, NULL, NULL )
,(324, 2, N'Internal Take-Over Main Equipment No. 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 18, N'Internal_Take-Over_Main_Equipment_No._1', N'false', 1, NULL, NULL, NULL, NULL )
,(325, 2, N'Switch Over from Stock Solution Tank 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 19, N'Switch_Over_from_Stock_Solution_Tank_1', N'false', 1, NULL, NULL, NULL, NULL )
,(326, 2, N'Internal Take-Over Main Equipment No. 2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 20, N'Internal_Take-Over_Main_Equipment_No._2', N'false', 1, NULL, NULL, NULL, NULL )
,(327, 2, N'Switch Over from Stock Solution Tank 2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 21, N'Switch_Over_from_Stock_Solution_Tank_2', N'false', 1, NULL, NULL, NULL, NULL )
,(328, 11, N'Group Number used for external take over ME 1', NULL, NULL, NULL, 9, NULL, NULL, NULL, 2, NULL, NULL, 22, N'Group_Number_Used_For_External_Take_Over_ME_1', NULL, 1, NULL, NULL, NULL, NULL )
,(329, 10, N'External extra flush time ME1 ', N'0', N'999', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 23, N'External_Extra_Flush_Time_ME1', N'0', 1, NULL, NULL, NULL, NULL )
,(330, 11, N'Group Number used for external take over ME 2', NULL, NULL, NULL, 9, NULL, NULL, NULL, 2, NULL, NULL, 24, N'Group_Number_Used_For_External_Take_Over_ME_2', NULL, 1, NULL, NULL, NULL, NULL )
,(331, 10, N'External extra flush time ME2', N'0', N'999', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 25, N'External_Extra_Flush_Time_ME2', N'0', 1, NULL, NULL, NULL, NULL )
,(332, 2, N'Digital Input Card 1 (Signal Machines) Position 0 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 26, N'Digital_Input_Card_1_Signal_Machines_Position_0_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(333, 2, N'Digital Input Card 6 (ME2 + P 10,11,12) Position 0 Rack 2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 27, N'Digital_Input_Card_6_(ME2 + P 10,11,12)_Position_0_Rack_2', N'false', 1, NULL, NULL, NULL, NULL )
,(334, 2, N'Digital Input Card 2 (Signal Machines) Position 1 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 28, N'Digital_Input_Card_2_(Signal_Machines)_Position_1_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(335, 2, N'Analogue Input Card 1 Position 5 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 29, N'Analogue_Input_Card_1_Position_5_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(336, 2, N'Digital Input Card 3 (Dosing Group 1) Position 2 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 30, N'Digital_Input_Card_3_(Dosing_Group_1)_Position_2_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(337, 2, N'Analogue Input Card 2 Position 6 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 31, N'Analogue_Input_Card_2_Position_6_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(338, 2, N'Digital Input Card 4 (Dosing Group 2) Position 3 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 32, N'Digital_Input_Card_4_(Dosing_Group_2)_Position_3_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(339, 2, N'Analogue Input Card 3 Position 1 Rack 3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 33, N'Analogue_Input_Card_3_Position_1_Rack_3', N'false', 1, NULL, NULL, NULL, NULL )
,(340, 2, N'Digital Input Card 5 (Miniterminal) Position 4 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 34, N'Digital_Input_Card_5_(Miniterminal)_Position_4_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(341, 2, N'Digital Input Card 7 (Transfer Carbonell) Position 7 Rack 3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 35, N'Digital_Input_Card_7_(Transfer_Carbonell)_Position_7_Rack_3', N'false', 1, NULL, NULL, NULL, NULL )
,(342, 10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL )
,(343, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 2, N'Install_Date', NULL, 1, N'InstallDate', NULL, NULL, NULL )
,(344, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', N'1', 0, N'ControllerNumber', NULL, NULL, N'dispNumber' )
,(345, 2, N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 4, N'Active', N'false', 1, N'Active', NULL, NULL, NULL )
,(346, 11, N'Controller Version', NULL, NULL, NULL, 3, 1, NULL, NULL, 2, NULL, NULL, 5, N'Controller Version', N'5', 0, N'ControllerVersion', NULL, NULL, NULL )
,(347, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 6, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL )
,(348, 10, N'IP Address', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 7, N'IP_Address', N'10.225.134.1', 1, NULL, NULL, NULL, NULL )
,(349, 2, N'PMR Enabled', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 4, N'PMR_Enabled', N'true', 1, NULL, NULL, NULL, NULL )
,(350, 2, N'Check Water flow Group1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 5, N'Check_Water_flow_Group1', N'true', 1, NULL, NULL, NULL, NULL )
,(351, 2, N'enVision Time out Enable', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 6, N'enVision_Time_out_Enable', N'true', 1, NULL, NULL, NULL, NULL )
,(352, 2, N'Check Water flow Group2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 7, N'Check_Water_flow_Group2', N'true', 1, NULL, NULL, NULL, NULL )
,(353, 10, N'enVision Timeout Alarm', N'1', N'999', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 8, N'enVision_Timeout_Alarm', N'10', 1, NULL, NULL, NULL, NULL )
,(354, 2, N'Check flow leakage alarm Group1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 9, N'Check_flow_leakage_Alarm_Group1', N'true', 1, NULL, NULL, NULL, NULL )
,(355, 10, N'Stop Time Dubix', N'0', N'99', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 10, N'Stop_Time_Dubix', N'0', 1, NULL, NULL, NULL, NULL )
,(356, 2, N'Check flow leakage alarm Group2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 11, N'Check_Flow_Leakage_Alarm_Group2', N'true', 1, NULL, NULL, NULL, NULL )
,(357, 2, N'Disable Program not finished Alarm', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 12, N'Disable_Program_Not_Finished_Alarm', N'false', 1, NULL, NULL, NULL, NULL )
,(358, 2, N'Start do not generate First Step', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 13, N'Start_Do_Not_Generate_First_Step', N'false', 1, NULL, NULL, NULL, NULL )
,(359, 2, N'Conductivity Compensation Stock Solution Tank 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 14, N'Conductivity_Compensation_Stock_Solution_Tank_1', N'false', 1, NULL, NULL, NULL, NULL )
,(360, 10, N'Alarm Reset Time', N'0', N'32767', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 15, N'Alarm_Reset_Time', N'60', 1, NULL, NULL, NULL, NULL)
,(361, 2, N'Conductivity Compensation Stock Solution Tank 2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 16, N'Conductivity_Compensation_Stock_Solution_Tank_2', N'false', 1, NULL, NULL, NULL, NULL )
,(362, 2, N'Enable Reset button', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 17, N'Enable_Reset_Button', N'false', 1, NULL, NULL, NULL, NULL )
,(363, 2, N'Internal Take-Over Main Equipment No. 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 18, N'Internal_Take-Over_Main_Equipment_No._1', N'false', 1, NULL, NULL, NULL, NULL )
,(364, 2, N'Switch Over from Stock Solution Tank 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 19, N'Switch_Over_from_Stock_Solution_Tank_1', N'false', 1, NULL, NULL, NULL, NULL )
,(365, 2, N'Internal Take-Over Main Equipment No. 2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 20, N'Internal_Take-Over_Main_Equipment_No._2', N'false', 1, NULL, NULL, NULL, NULL )
,(366, 2, N'Switch Over from Stock Solution Tank 2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 21, N'Switch_Over_from_Stock_Solution_Tank_2', N'false', 1, NULL, NULL, NULL, NULL )
,(367, 11, N'Group Number used for external take over ME 1', NULL, NULL, NULL, 9, NULL, NULL, NULL, 2, NULL, NULL, 22, N'Group_Number_Used_For_External_Take_Over_ME_1', NULL, 1, NULL, NULL, NULL, NULL )
,(368, 10, N'External extra flush time ME1 ', N'0', N'999', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 23, N'External_Extra_Flush_Time_ME1', N'0', 1, NULL, NULL, NULL, NULL )
,(369, 11, N'Group Number used for external take over ME 2', NULL, NULL, NULL, 9, NULL, NULL, NULL, 2, NULL, NULL, 24, N'Group_Number_Used_For_External_Take_Over_ME_2', NULL, 1, NULL, NULL, NULL, NULL )
,(370, 10, N'External extra flush time ME2', N'0', N'999', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 25, N'External_Extra_Flush_Time_ME2', N'0', 1, NULL, NULL, NULL, NULL )
,(371, 2, N'Digital Input Card 1 Signal Machines Position 0 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 26, N'Digital_Input_Card_1_Signal_Machines_Position_0_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(372, 2, N'Digital Input Card 6 (ME2 + P 10,11,12) Position 0 Rack 2', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 27, N'Digital_Input_Card_6_(ME2 + P 10,11,12)_Position_0_Rack_2', N'false', 1, NULL, NULL, NULL, NULL )
,(373, 2, N'Digital Input Card 2 (Signal Machines) Position 1 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 28, N'Digital_Input_Card_2_(Signal_Machines)_Position_1_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(374, 2, N'Analogue Input Card 1 Position 5 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 29, N'Analogue_Input_Card_1_Position_5_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(375, 2, N'Digital Input Card 3 (Dosing Group 1) Position 2 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 30, N'Digital_Input_Card_3_(Dosing_Group_1)_Position_2_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(376, 2, N'Analogue Input Card 2 Position 6 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 31, N'Analogue_Input_Card_2_Position_6_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(377, 2, N'Digital Input Card 4 (Dosing Group 2) Position 3 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 32, N'Digital_Input_Card_4_(Dosing_Group_2)_Position_3_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(378, 2, N'Analogue Input Card 3 Position 1 Rack 3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 33, N'Analogue_Input_Card_3_Position_1_Rack_3', N'false', 1, NULL, NULL, NULL, NULL )
,(379, 2, N'Digital Input Card 5 (Miniterminal) Position 4 Rack 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 34, N'Digital_Input_Card_5_(Miniterminal)_Position_4_Rack_1', N'false', 1, NULL, NULL, NULL, NULL )
,(380, 2, N'Digital Input Card 7 (Transfer Carbonell) Position 7 Rack 3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 35, N'Digital_Input_Card_7_(Transfer_Carbonell)_Position_7_Rack_3', N'false', 1, NULL, NULL, NULL, NULL )

-- EControl Plus
,(381, 10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL )
,(382, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 2, N'Install_Date', NULL, 1, N'InstallDate', NULL, NULL, NULL )
,(383, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', N'1', 0, N'ControllerNumber', NULL, NULL, N'dispNumber' )
,(384, 2, N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 4, N'Active', N'false', 1, N'Active', NULL, NULL, NULL )
,(385, 11, N'Controller Version', NULL, NULL, NULL, 3, 1, NULL, NULL, 2, NULL, NULL, 5, N'Controller Version', N'4', 0, N'ControllerVersion', NULL, NULL, NULL )
,(386, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 6, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL )
,(387, 10, N'IP Address', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 7, N'IP_Address', N'10.225.134.10', 1, NULL, NULL, NULL, NULL )
,(388, 2, N'Analog Monitoring Enable', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 4, N'Analog_Monitoring_Enable', N'false', 1, NULL, NULL, NULL, NULL )
,(389, 2, N'Check Water Flow', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 5, N'Check_Water_Flow', N'true', 1, NULL, NULL, NULL, NULL )
,(390, 10, N'Stop Time Dubix', N'0', N'9.9', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 6, N'Stop_Time_Dubix', N'0', 1, NULL, NULL, NULL, NULL )
,(391, 2, N'Check Flow Leakage Alarm', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 7, N'Check_Flow_Leakage_Alarm', N'true', 1, NULL, NULL, NULL, NULL )
,(392, 2, N'Enable Reset button', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 8, N'Enable_Reset_Button', N'true', 1, NULL, NULL, NULL, NULL )
,(393, 2, N'Alarm Reverse', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 9, N'Alarm_Reverse', N'false', 1, NULL, NULL, NULL, NULL )
,(394, 10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL )
,(395, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 2, N'Install_Date', NULL, 1, N'InstallDate', NULL, NULL, NULL )
,(396, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', N'1', 0, N'ControllerNumber', NULL, NULL, N'dispNumber' )
,(397, 2, N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 4, N'Active', N'false', 1, N'Active', NULL, NULL, NULL )
,(398, 11, N'Controller Version', NULL, NULL, NULL, 3, 1, NULL, NULL, 2, NULL, NULL, 5, N'Controller Version', N'4', 0, N'ControllerVersion', NULL, NULL, NULL )
,(399, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 6, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL )
,(400, 10, N'IP Address', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 7, N'IP_Address', N'10.225.134.10', 1, NULL, NULL, NULL, NULL )
,(401, 2, N'Analog Monitoring Enable', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 4, N'Analog_Monitoring_Enable', N'false', 1, NULL, NULL, NULL, NULL )
,(402, 2, N'Check Water Flow', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 5, N'Check_Water_Flow', N'true', 1, NULL, NULL, NULL, NULL )
,(403, 10, N'Stop Time Dubix', N'0', N'9.9', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 6, N'Stop_Time_Dubix', N'0', 1, NULL, NULL, NULL, NULL )
,(404, 2, N'Check Flow Leakage Alarm', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 7, N'Check_Flow_Leakage_Alarm', N'true', 1, NULL, NULL, NULL, NULL )
,(405, 2, N'Enable Reset button', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 8, N'Enable_Reset_Button', N'true', 1, NULL, NULL, NULL, NULL )
,(406, 2, N'Alarm Reverse', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 9, N'Alarm_Reverse', N'false', 1, NULL, NULL, NULL, NULL )
,(407, 10, N'Hysteresis on Connexx Alarm Level', N'0', N'9', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Hysteresis_on_Connexx_Alarm_Level', N'2', 1, NULL, NULL, NULL, NULL )

-- EControl Central
,(408, 10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL )
,(409, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 2, N'Install_Date', NULL, 1, N'InstallDate', NULL, NULL, NULL )
,(410, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', N'1', 1, N'ControllerNumber', NULL, NULL, N'dispNumber')
,(411, 2, N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 4, N'Active', N'false', 1, N'Active', NULL, NULL, NULL )
,(412, 11, N'Controller Version', NULL, NULL, NULL, 10, 1, NULL, NULL, 2, NULL, NULL, 5, N'Controller Version', N'3', 1, N'ControllerVersion', NULL, NULL, N'ControllerVersion' )
,(413, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 6, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL )
,(414, 10, N'IP Address', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 7, N'IP_Address', N'10.225.134.10', 1, NULL, NULL, NULL, N'IPAddress' )
,(415, 11, N'Com Port Number', NULL, NULL, NULL, 11, 1, NULL, NULL, 2, NULL, NULL, 8, N'Com_Port_Number', N'0', 1, NULL, NULL, NULL, N'ComPortNumber' )
,(416, 2, N'Skip extension I/O module 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 4, N'Skip_extension_I/O_module_1', N'false', 1, NULL, NULL, NULL, NULL )
,(417, 2, N'Check Water Flow', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 5, N'Check_Water_Flow', N'true', 1, NULL, NULL, NULL, NULL )
,(418, 10, N'Stop Time Dubix', N'0', N'9.9', NULL, NULL, 1, NULL, NULL, 5, NULL, NULL, 6, N'Stop_Time_Dubix', N'0', 1, NULL, NULL, NULL, NULL )
,(419, 2, N'Alarm Reverse', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 7, N'Alarm_Reverse', N'false', 1, NULL, NULL, NULL, NULL )
,(420, 10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL )
,(421, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 2, N'Install_Date', NULL, 1, N'InstallDate', NULL, NULL, NULL )
,(422, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', N'1', 1, N'ControllerNumber', NULL, NULL, N'dispNumber' )
,(423, 2, N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 4, N'Active', N'false', 1, N'Active', NULL, NULL, NULL )
,(424, 11, N'Controller Version', NULL, NULL, NULL, 10, 1, NULL, NULL, 2, NULL, NULL, 5, N'Controller Version', N'3', 1, N'ControllerVersion', NULL, NULL, N'ControllerVersion' )
,(425, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 6, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL )
,(426, 10, N'IP Address', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 7, N'IP_Address', N'10.225.134.10', 1, NULL, NULL, NULL, N'IPAddress' )
,(427, 11, N'Com Port Number', NULL, NULL, NULL, 11, 1, NULL, NULL, 2, NULL, NULL, 8, N'Com_Port_Number', N'0', 1, NULL, NULL, NULL, N'ComPortNumber' )
,(428, 2, N'Skip extension I/O module 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 4, N'Skip_extension_I/O_module_1', N'false', 1, NULL, NULL, NULL, NULL )
,(429, 2, N'Check Water Flow', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 5, N'Check_Water_Flow', N'true', 1, NULL, NULL, NULL, NULL )
,(430, 10, N'Stop Time Dubix', N'0', N'9.9', NULL, NULL, 1, NULL, NULL, 5, NULL, NULL, 6, N'Stop_Time_Dubix', N'0', 1, NULL, NULL, NULL, NULL )
,(431, 2, N'Alarm Reverse', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 7, N'Alarm_Reverse', N'false', 1, NULL, NULL, NULL, NULL )
-- EControl Decentral
,(432, 10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL )
,(433, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 2, N'Install_Date', NULL, 1, N'InstallDate', NULL, NULL, NULL )
,(434, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', N'1', 1, N'ControllerNumber', NULL, NULL, N'dispNumber' )
,(435, 2, N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 4, N'Active', N'false', 1, N'Active', NULL, NULL, NULL )
,(436, 11, N'Controller Version', NULL, NULL, NULL, 10, 1, NULL, NULL, 2, NULL, NULL, 5, N'Controller Version', N'3', 1, N'ControllerVersion', NULL, NULL, N'ControllerVersion' )
,(437, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 6, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL )
,(438, 10, N'IP Address', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 7, N'IP_Address', N'10.225.134.10', 1, NULL, NULL, NULL, N'IPAddress' )
,(439, 11, N'Com Port Number', NULL, NULL, NULL, 11, 1, NULL, NULL, 2, NULL, NULL, 8, N'Com_Port_Number', N'0', 1, NULL, NULL, NULL, N'ComPortNumber' )
,(440, 2, N'Skip extension I/O module 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 4, N'Skip_extension_I/O_module_1', N'false', 1, NULL, NULL, NULL, NULL )
,(441, 2, N'Check Water Flow', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 5, N'Check_Water_Flow', N'true', 1, NULL, NULL, NULL, NULL )
,(442, 2, N'Alarm Reverse', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 6, N'Alarm_Reverse', N'false', 1, NULL, NULL, NULL, NULL )
,(443, 10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL )
,(444, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 2, N'Install_Date', NULL, 1, N'InstallDate', NULL, NULL, NULL )
,(445, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', N'1', 1, N'ControllerNumber', NULL, NULL, N'dispNumber' )
,(446, 2, N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 4, N'Active', N'false', 1, N'Active', NULL, NULL, NULL )
,(447, 11, N'Controller Version', NULL, NULL, NULL, 10, 1, NULL, NULL, 2, NULL, NULL, 5, N'Controller Version', N'3', 1, N'ControllerVersion', NULL, NULL, N'ControllerVersion' )
,(448, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 6, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL )
,(449, 10, N'IP Address', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 7, N'IP_Address', N'10.225.134.10', 1, NULL, NULL, NULL, N'IPAddress' )
,(450, 11, N'Com Port Number', NULL, NULL, NULL, 11, 1, NULL, NULL, 2, NULL, NULL, 8, N'Com_Port_Number', N'0', 1, NULL, NULL, NULL, N'ComPortNumber' )
,(451, 2, N'Skip extension I/O module 1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 4, N'Skip_extension_I/O_module_1', N'false', 1, NULL, NULL, NULL, NULL )
,(452, 2, N'Check Water Flow', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 5, N'Check_Water_Flow', N'true', 1, NULL, NULL, NULL, NULL )
,(453, 2, N'Alarm Reverse', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 6, N'Alarm_Reverse', N'false', 1, NULL, NULL, NULL, NULL )
-- Ecodose
,(454, 10, N'ControllerName', NULL, NULL, NULL, NULL, 1, N'Name for Controller', NULL, 2, NULL, NULL, 1, N'Controller_Name', NULL, 1, N'TopicName', NULL, NULL, NULL )
,(455, 12, N'Install Date', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 2, N'Install_Date', NULL, 1, N'InstallDate', NULL, NULL, NULL )
,(456, 10, N'Controller Number', N'0', NULL, NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 3, N'Controller Number', N'1', 1, N'ControllerNumber', NULL, NULL, N'dispNumber' )
,(457, 2, N'Active', NULL, NULL, NULL, 4, 1, NULL, NULL, 4, NULL, NULL, 4, N'Active', N'false', 1, N'Active', NULL, NULL, NULL )
,(458, 11, N'Controller Version', NULL, NULL, NULL, 10, 1, NULL, NULL, 2, NULL, NULL, 5, N'Controller Version', N'3', 1, N'ControllerVersion', NULL, NULL, N'ControllerVersion' )
,(459, 10, N'SerialNumber', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 6, N'Serial_Number', NULL, 1, NULL, NULL, NULL, NULL )
,(460, 10, N'IP Address', NULL, NULL, NULL, NULL, 1, NULL, NULL, 2, NULL, NULL, 7, N'IP_Address', N'10.225.134.07', 1, NULL, NULL, NULL, N'IPAddress')
,(461, 11, N'Com Port Number', NULL, NULL, NULL, 11, 1, NULL, NULL, 2, NULL, NULL, 8, N'Com_Port_Number', N'0', 1, NULL, NULL, NULL, N'ComPortNumber' )
,(462, 2, N'FX2N COM-ET-10 Used', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 4, N'FX2N_COM-ET-10_Used', N'false', 1, NULL, NULL, NULL, NULL )
,(463, 2, N'Check Water Flow', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 5, N'Check_Water_Flow', N'true', 1, NULL, NULL, NULL, NULL )
,(464, 2, N'Disable Program not finished alarm', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 6, N'Disable_Program_not_finished_alarm', N'false', 1, NULL, NULL, NULL, NULL )
,(465, 2, N'Disable not valid program alarm', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL, 7, N'Disable_not_valid_program_alarm', N'false', 1, NULL, NULL, NULL, NULL)
,(466, 10, N'LFS Injection Classes', N'0', N'6', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 10, N'LFSInjection_Classes', N'6', 1, NULL, N'TAG_MIC', N'N7:132', N'InjectionClasses')
,(467, 10, N'LFS Injection Classes', N'0', N'8', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 10, N'LFSInjection_Classes', N'8', 1, NULL, N'TAG_MIC', N'L_MIC', N'InjectionClasses')
,(468, 10, N'LFS Injection Classes', N'0', N'6', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 10, N'LFSInjection_Classes', N'6', 1, NULL, N'TAG_MIC', N'N7:132', N'InjectionClasses')
,(469, 10, N'LFS Injection Classes', N'0', N'8', NULL, NULL, 1, NULL, NULL, 1, NULL, NULL, 10, N'LFSInjection_Classes', N'8', 1, NULL, N'TAG_MIC', N'L_MIC', N'InjectionClasses')
,(478, 11, N'Controller Version', NULL, NULL, NULL, 10, 2, NULL, NULL, 1, NULL, NULL, 5, N'Controller_Version', N'3', 1, NULL, NULL, NULL, 'ControllerVersion')
SET	IDENTITY_INSERT	TCD.Field	ON

MERGE	TCD.Field				AS			TARGET
USING	@tempField			AS			SOURCE
ON	TARGET.Id			=			SOURCE.Id
WHEN	NOT MATCHED		THEN
INSERT	(Id					,TypeId				,Label					,[Min]				,[Max]			,FieldGroupId
,	DataSourceId		,IsMandatory		,HelpText				,HelpTextURL		,DataTypeId			,DataCategoryId				,CurrencyId
,	DisplayOrder		,ResourceKey		,DefaultValue			,IsEditable			,Name				,HasFieldTag				,DefaultFieldTag		,ClassName)
VALUES	(SOURCE.Id			,SOURCE.TypeId		,SOURCE.Label			,SOURCE.[Min]		,SOURCE.[Max]	,SOURCE.FieldGroupId
,	SOURCE.DataSourceId	,SOURCE.IsMandatory	,SOURCE.HelpText		,SOURCE.HelpTextURL	,SOURCE.DataTypeId	,SOURCE.DataCategoryId		,SOURCE.CurrencyId
,	SOURCE.DisplayOrder	,SOURCE.ResourceKey	,SOURCE.DefaultValue	,SOURCE.IsEditable	,SOURCE.Name		,SOURCE.HasFieldTag			,SOURCE.DefaultFieldTag	,SOURCE.ClassName);

SET	IDENTITY_INSERT	[TCD].Field	OFF
END





/*	FieldSource

No identity column defined.
PRIMARY KEY: NONE defined. Will assume DataSourceId + Name + Value for UNIQUENESS
FK:
REFERENCES ConduitLocal.dbo.DataSource (Id)
No foreign keys reference table 'FieldSource', or you do not have permissions on referencing tables.

select	*	from	FieldSource					--REFERS (FK) - DataSource (is already up the order)
*/
BEGIN
SET			@TableName				=			'FieldSource'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempFieldSource		TABLE	(
TempId					INT				IDENTITY(1, 1)
,	DataSourceId			INT				NOT	NULL
,	Name					NVARCHAR(50)	NOT	NULL
,	Value					NVARCHAR(50)	NOT	NULL
)

--Populate temp table variable with the input data
INSERT	@tempFieldSource	(
DataSourceId		,Name		,Value)
VALUES	(1	,N'process'	,N'1'	)
,	(1	,N'confort'	,N'2'	)
,	(2	,N'Beckhoff'	,N'1'	)
,	(2	,N'Allen Bradley'	,N'2'	)
,	(3	,N'1'	,N'1'	)
,	(3	,N'2'	,N'2'	)
,	(3	,N'3'	,N'3'	)
,	(3	,N'4'	,N'4'	)
,	(3	,N'5'	,N'5'	)
,	(4	,N'Enable'	,N'1'	)
,	(4	,N'Disable'	,N'2'	)
,	(5	,N'Allen Bradley'	,N'1'	)
,	(6	,N'Beckhoff'	,N'1'	)
-- For myControl Dosing Line Datasources
,	(7	,N'1', N'1')
,	(7	,N'2', N'2')
,	(7	,N'3', N'3')
,	(7	,N'4', N'4')
,	(7	,N'5', N'5')
,	(7	,N'6', N'6')
,	(7	,N'7', N'7')
,	(7	,N'8', N'8')
,	(7	,N'9', N'9')
,	(7	,N'10', N'10')
,	(7	,N'11', N'11')
,	(7	,N'12', N'12')
,	(7	,N'13', N'13')
,	(7	,N'14', N'14')
,	(7	,N'15', N'15')
,	(7	,N'16', N'16')
,	(8  ,N'Standard Mode', N'1')
,	(8	,N'Turbo Compact Rack', N'2')
,	(9, N'0', N'0' )
,	(9, N'1', N'1' )
,	(9, N'2', N'2' )
,	(10, N'1', N'1' )
,	(10, N'3', N'2' )
,	(11, N'none', N'0' )
,	(11, N'Com 1', N'1' )
,	(11, N'Com 2', N'2' )
,	(11, N'Com 3', N'3' )
,	(11, N'Com 4', N'4' )
,	(11, N'Com 5', N'5' )
,	(11, N'Com 6', N'6' )
,	(11, N'Com 7', N'7' )
,	(11, N'Com 8', N'8' )
,	(11, N'Com 9', N'9' )
,	(11, N'Com 10', N'10' )
,	(11, N'Com 11', N'11' )
,	(11, N'Com 12', N'12' )
,	(11, N'Com 13', N'13' )
,	(11, N'Com 14', N'14' )
,	(11, N'Com 15', N'15' )
,	(11, N'Com 16', N'16' )

MERGE	TCD.FieldSource				AS			TARGET
USING	@tempFieldSource		AS			SOURCE
ON	TARGET.DataSourceId		=			SOURCE.DataSourceId
AND	TARGET.Name				=			SOURCE.Name
AND	TARGET.Value			=			SOURCE.Value
WHEN	NOT MATCHED		THEN
INSERT	(DataSourceId			,Name			,Value			)
VALUES	(SOURCE.DataSourceId	,SOURCE.Name	,SOURCE.Value	);
END





/*	FieldGroupFieldMapping

Identity: Id
PRIMARY KEY: Id
FK:
REFERENCES ConduitLocal.dbo.Field (Id)
REFERENCES ConduitLocal.dbo.FieldGroup (Id)

No foreign keys reference table 'FieldGroupFieldMapping', or you do not have permissions on referencing tables.

select	*	from	FieldGroupFieldMapping		--REFERS (FK) - F, FG (are already up the order)
*/
BEGIN
SET			@TableName				=			'FieldGroupFieldMapping'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempFieldGroupFieldMapping				TABLE	(
TempId					INT				IDENTITY(1, 1)
,	Id						INT				NOT	NULL
,	FieldGroupId			INT				NOT	NULL
,	FieldId					INT				NOT	NULL
)

--Populate temp table variable with the input data
INSERT	@tempFieldGroupFieldMapping	(
Id	,FieldGroupId	,FieldId)
VALUES	(1, 1, 1)
,(2, 1, 2)
,(3, 1, 3)
,(4, 2, 4)
,(5, 2, 5)
,(6, 3, 6)
,(10, 4, 21)
--,(11, 4, 48)
--,(13, 4, 49)
,(15, 4, 51)
,(16, 4, 53)
,(17, 4, 54)
,(90, 6, 56)
,(91, 6, 57)
,(92, 6, 58)
,(93, 8, 59)
,(94, 8, 60)
,(95, 8, 61)
,(100, 5, 66)
,(101, 5, 67)
,(102, 5, 68)
,(103, 7, 69)
,(104, 7, 70)
,(105, 7, 71)
,(106, 5, 72)
,(107, 5, 73)
,(108, 5, 74)
,(109, 5, 75)
,(110, 9, 21)
,(111, 10, 27)
,(112, 9, 28)
,(113, 10, 30)
,(114, 9, 33)
,(115, 9, 34)
,(117, 9, 56)
,(118, 9, 57)
,(119, 9, 58)
,(120, 10, 59)
,(121, 10, 60)
,(122, 10, 200)
--,(123, 9, 62)
--,(124, 9, 63)
--,(125, 9, 64)
--,(126, 9, 65)
--,(127, 6, 22)
--,(128, 6, 23)
,(129, 5, 11)
,(130, 7, 12)
,(131, 5, 13)
,(133, 7, 15)
,(134, 5, 16)
,(136, 5, 18)
,(137, 5, 19)
,(139, 6, 21)
,(140, 8, 27)
,(141, 6, 28)
,(142, 8, 30)
,(143, 6, 33)
,(144, 6, 34)
,(146, 5, 76)
,(147, 6, 78)
,(148, 5, 77)
,(149, 6, 79)
,(150, 7, 80)
,(151, 7, 81)
,(152, 7, 82)
,(153, 7, 83)
,(154, 7, 84)
,(155, 7, 85)
,(156, 7, 86)
,(158, 7, 87)
,(159, 7, 88)
,(160, 7, 89)
,(161, 7, 90)
,(162, 8, 91)
,(163, 8, 92)
,(164, 8, 93)
,(165, 8, 94)
,(166, 8, 95)
,(167, 8, 96)
,(168, 8, 97)
,(169, 8, 98)
,(170, 8, 99)
,(171, 8, 100)
,(172, 8, 101)
,(173, 9, 79)
,(174, 9, 78)
,(175, 10, 91)
,(176, 10, 92)
,(177, 10, 93)
,(178, 10, 94)
,(179, 10, 95)
,(180, 10, 96)
,(181, 10, 97)
,(182, 10, 98)
,(183, 10, 99)
,(184, 10, 100)
,(185, 10, 101)
,(186, 11, 11)
,(187, 11, 103)
,(188, 11, 104)
,(189, 11, 105)
,(190, 11, 106)
,(191, 11, 107)
,(192, 11, 108)
,(193, 11, 109)
,(194, 11, 110)
,(195, 11, 111)
,(196, 11, 112)
,(197, 11, 113)
,(198, 11, 114)
,(199, 11, 115)
--,(200, 9,  116)
--,(201, 9,  117)
,(202, 12, 118)
,(203, 12, 119)
,(204, 12, 120)
,(205, 12, 121)
,(206, 12, 122)
,(207, 12, 123)
,(208, 12, 124)
,(209, 12, 125)
,(210, 12, 126)
,(211, 12, 127)
,(212, 12, 128)
,(213, 12, 129)
,(214, 12, 130)
,(215, 12,  131)
,(216, 12,  132)
,(217, 12,  133)
,(218, 13	,11)
,(219, 13	,135)
,(220, 13	,136)
,(221, 13	,137)
,(223, 13	,138)
,(226, 13	,143)
,(227, 13	,144)
,(228, 13	,145)
,(229, 13	,146)
,(230, 13	,147)
--,(231, 14	,148)
--,(232, 14	,149)
,(235, 14	,21)
,(236, 14	,151)
,(237, 14	,152)
,(238, 14	,153)
,(239, 14	,154)
,(240, 14	,155)
,(241, 14	,156)
,(243, 13	,142)

,(244,15, 11)

,(245,15, 158)

,(246,15, 159)

,(247,15, 160)

,(248,15, 161)

,(249,15, 162)

,(250,15, 163)

,(251,15, 164)

,(252,15, 165)

,(253,15, 166)

,(254,15, 167)

,(255,15, 168)

,(256,15, 169)

,(257,15, 170)

--16

,(258,16, 171)

,(259,16, 172)

,(260,16, 173)

,(261,16, 174)

,(262,16, 175)

,(263,16, 176)

,(264,16, 177)

,(265,16, 178)

,(266,16, 179)

--17

,(267,17, 180)

,(268,17, 181)

,(269,17, 182)

,(270,17, 183)

,(271,17, 184)

,(272,17, 185)

,(273,17, 186)

,(274,17, 187)

,(275,17, 188)

,(276,17, 189)

,(277,17, 190)

,(278,17, 191)

,(279,17, 192)

,(280,17, 193)

,(281,17, 194)

,(282,17, 195)

--18
,(283,18,196)

,(284,18,197)

,(285,18,198)

,(286,18,199)

,(287,18,61)

,(288,18,201)

,(289,18,202)

,(290,18,203)

,(291,18,204)

,(292,18,205)

,(293,18,206)

,(294,18,207)

,(295,18,208)

,(296,18,209)

,(297,18,210)

,(298,18,211)

-- For MyControl General and Advance fileds mappings
,(299, 4, 212)
,(300, 19, 214)
,(301, 19, 215)
,(302, 19, 216)
,(303, 20, 217)
,(304, 4, 218)
,(305, 20, 219)
,(306, 20, 220)
,(307, 20, 221)
,(308, 20, 222)
,(309, 20, 223)
,(310, 20, 224)
,(311, 20, 225)
,(312, 20, 226)
,(313, 20, 227)
,(314, 20, 228)
,(315, 20, 229)
,(316, 20, 230)
,(317, 21, 231)
,(318, 21, 232)
,(319, 21, 233)
,(320, 21, 234)
,(321, 21, 235)
,(322, 21, 236)
,(323, 21, 237)
,(324, 21, 238)
,(325, 21, 239)
,(326, 21, 240)
,(327, 21, 241)
,(328, 21, 242)
,(329, 21, 243)
,(330, 21, 244)
,(331, 21, 245)
,(332, 21, 246)
,(333, 22, 247)
,(334, 22, 248)
,(335, 22, 249)
,(336, 22, 250)
,(337, 22, 251)
,(338, 22, 252)
,(339, 22, 253)
,(340, 22, 254)
,(341, 22, 255)
,(342, 22, 256)
,(343, 22, 257)
,(344, 22, 258)
,(345, 22, 259)
,(346, 22, 260)
,(347, 22, 261)
,(348, 4, 213)
,(349, 4, 262)
,(355, 25, 270 )
,(356, 25, 271 )
,(357, 25, 272 )
,(358, 25, 273 )
,(359, 25, 274 )
,(360, 25, 275 )
,(361, 25, 277 )
,(362, 25, 278 )
,(363, 25, 279 )
,(364, 25, 280 )
,(365, 25, 281 )
,(366, 25, 282 )
,(367, 25, 283 )
,(368, 25, 284 )
,(369, 25, 285 )
,(370, 25, 286 )
,(371, 25, 287 )
,(372, 25, 288 )
,(373, 25, 289 )
,(374, 25, 290 )
,(375, 25, 291 )
,(376, 25, 292 )
,(377, 26, 293 )
,(378, 26, 294 )
,(379, 26, 295 )
,(380, 26, 296 )
,(381, 26, 297 )
,(382, 26, 298 )
,(383, 26, 299 )
,(384, 26, 300 )
,(385, 26, 301 )
,(387, 23, 263 )
,(388, 23, 264 )
,(389, 23, 265 )
,(390, 23, 266 )
,(391, 23, 267 )
,(392, 23, 268 )
,(393, 23, 269 )
,(394, 24, 214 )
,(395, 24, 215 )
,(396, 24, 216 )
,(397, 27, 303 )
,(398, 27, 304 )
,(399, 27, 305 )
,(400, 27, 306 )
,(401, 27, 307 )
,(402, 27, 308 )
,(403, 27, 309 )
,(404, 28, 214 )
,(405, 28, 215 )
,(406, 28, 216 )
,(407, 29, 310 )
,(408, 29, 311 )
,(409, 29, 312 )
,(410, 29, 313 )
,(411, 29, 314 )
,(412, 29, 315 )
,(413, 29, 316 )
,(414, 29, 317 )
,(415, 29, 318 )
,(416, 29, 319 )
,(417, 29, 320 )
,(418, 29, 321 )
,(419, 29, 322 )
,(420, 29, 323 )
,(421, 29, 324 )
,(422, 29, 325 )
,(423, 29, 326 )
,(424, 29, 327 )
,(425, 29, 328 )
,(426, 29, 329 )
,(427, 29, 330 )
,(428, 29, 331 )
,(429, 30, 332 )
,(430, 30, 333 )
,(431, 30, 334 )
,(432, 30, 335 )
,(433, 30, 336 )
,(434, 30, 337 )
,(435, 30, 338 )
,(436, 30, 339 )
,(437, 30, 340 )
,(439, 31, 342 )
,(440, 31, 343 )
,(441, 31, 344 )
,(442, 31, 345 )
,(443, 31, 346 )
,(444, 31, 347 )
,(445, 31, 348 )
,(446, 32, 214 )
,(447, 32, 215 )
,(448, 32, 216 )
,(449, 33, 349 )
,(450, 33, 350 )
,(451, 33, 351 )
,(452, 33, 352 )
,(453, 33, 353 )
,(454, 33, 354 )
,(455, 33, 355 )
,(456, 33, 356 )
,(457, 33, 357 )
,(458, 33, 358 )
,(459, 33, 359 )
,(460, 33, 360 )
,(461, 33, 361 )
,(462, 33, 362 )
,(463, 33, 363 )
,(464, 33, 364 )
,(465, 33, 365 )
,(466, 33, 366 )
,(467, 33, 367 )
,(468, 33, 368 )
,(469, 33, 369 )
,(470, 33, 370 )
,(471, 34, 371 )
,(472, 34, 372 )
,(473, 34, 373 )
,(474, 34, 374 )
,(475, 34, 375 )
,(476, 34, 376 )
,(477, 34, 377 )
,(478, 34, 378 )
,(479, 34, 379 )
,(481, 35, 381 )
,(482, 35, 382 )
,(483, 35, 383 )
,(484, 35, 384 )
,(485, 35, 385 )
,(486, 35, 386 )
,(487, 35, 387 )
,(488, 36, 214 )
,(489, 36, 215 )
,(490, 36, 407 )
,(491, 37, 388 )
,(492, 37, 389 )
,(493, 37, 390 )
,(494, 37, 391 )
,(495, 37, 392 )
,(496, 37, 393 )
,(497, 38, 394 )
,(498, 38, 395 )
,(499, 38, 396 )
,(500, 38, 397 )
,(501, 38, 398 )
,(502, 38, 399 )
,(503, 38, 400 )
,(504, 39, 214 )
,(505, 39, 215 )
,(506, 39, 407 )
,(507, 40, 401 )
,(508, 40, 402 )
,(509, 40, 403 )
,(510, 40, 404 )
,(511, 40, 405 )
,(512, 40, 406 )
,(513, 41, 408 )
,(514, 41, 409 )
,(515, 41, 410 )
,(516, 41, 411 )
,(517, 41, 412 )
,(518, 41, 413 )
,(519, 41, 414 )
,(520, 41, 415 )
,(521, 42, 214 )
,(522, 42, 215 )
,(523, 42, 407 )
,(524, 43, 416 )
,(525, 43, 417 )
,(526, 43, 418 )
,(527, 43, 419 )
,(528, 44, 420 )
,(529, 44, 421 )
,(530, 44, 422 )
,(531, 44, 423 )
,(532, 44, 424 )
,(533, 44, 425 )
,(534, 44, 426 )
,(535, 44, 427 )
,(536, 45, 214 )
,(537, 45, 215 )
,(538, 45, 407 )
,(539, 46, 428 )
,(540, 46, 429 )
,(541, 46, 430 )
,(542, 46, 431 )
,(543, 47, 432 )
,(544, 47, 433 )
,(545, 47, 434 )
,(546, 47, 435 )
,(547, 47, 436 )
,(548, 47, 437 )
,(549, 47, 438 )
,(550, 47, 439 )
,(551, 48, 214 )
,(552, 48, 215 )
,(553, 48, 407 )
,(554, 49, 440 )
,(555, 49, 441 )
,(556, 49, 442 )
,(557, 50, 443 )
,(558, 50, 444 )
,(559, 50, 445 )
,(560, 50, 446 )
,(561, 50, 447 )
,(562, 50, 448 )
,(563, 50, 449 )
,(564, 50, 450 )
,(565, 51, 214 )
,(566, 51, 215 )
,(567, 51, 407 )
,(568, 52, 451 )
,(569, 52, 452 )
,(570, 52, 453 )
,(571, 53, 454 )
,(572, 53, 455 )
,(573, 53, 456 )
,(574, 53, 457 )
,(575, 53, 458 )
,(576, 53, 459 )
,(577, 53, 460 )
,(578, 53, 461 )
,(579, 54, 214 )
,(580, 54, 215 )
,(581, 54, 407 )
,(582, 55, 462 )
,(583, 55, 463 )
,(584, 55, 464 )
,(585, 55, 465 )
,(586, 7, 466)
,(587, 8, 467)
,(588, 17, 468)
,(589, 18, 469)
,(604, 41, 478)
,(605, 44, 478)
SET	IDENTITY_INSERT	TCD.FieldGroupFieldMapping	ON

MERGE	TCD.FieldGroupFieldMapping				AS			TARGET
USING	@tempFieldGroupFieldMapping			AS			SOURCE
ON	TARGET.Id			=			SOURCE.Id
WHEN	NOT MATCHED		THEN
INSERT	(Id			,FieldGroupId			,FieldId			)
VALUES	(SOURCE.Id	,SOURCE.FieldGroupId	,SOURCE.FieldId		);

SET	IDENTITY_INSERT	TCD.FieldGroupFieldMapping	OFF;
END




/*	FieldRoleMapping

Identity: Id
PRIMARY KEY: Id
FK:
REFERENCES ConduitLocal.dbo.Field (Id)

No foreign keys reference table 'FieldRoleMapping', or you do not have permissions on referencing tables.

*/
BEGIN
SET			@TableName				=			'FieldRoleMapping'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempFieldRoleMapping				TABLE	(
TempId					INT				IDENTITY(1, 1)
,	Id					INT				NOT	NULL
,	FieldId				INT				NOT	NULL
,	RoleId				INT				NOT	NULL
)

--Populate temp table variable with the input data
INSERT	@tempFieldRoleMapping	(
Id	,FieldId	,RoleId)
VALUES
(1	,11	,8	)
,	(2	,14	,8	)
,	(3	,17	,8	)
,	(4	,21	,8	)
,	(5	,22	,8	)
,	(6	,23	,8	)
,	(7	,47	,8	)
,	(8	,102,8	)
,	(9	,116,8	)
,	(10	,117,8	)
,	(11 ,134,8 	)
,	(12 ,150,8  )
,	(13 ,11, 9  )
,	(14 ,21, 9  )
,	(15 ,47, 9  )
,	(16 ,102 ,9 )
,	(17 ,134 ,9 )
,	(18 ,150 ,9 )
SET	IDENTITY_INSERT	TCD.FieldRoleMapping	ON

MERGE	TCD.FieldRoleMapping					AS			TARGET
USING	@tempFieldRoleMapping				AS			SOURCE
ON	TARGET.Id			=			SOURCE.Id
WHEN	NOT MATCHED		THEN
INSERT	(Id			,FieldId			,RoleId			)
VALUES	(SOURCE.Id	,SOURCE.FieldId	,SOURCE.RoleId		);

SET	IDENTITY_INSERT	[TCD].FieldRoleMapping	OFF
END




/*	WasherGroupType

Identity: WasherGroupTypeId
PRIMARY KEY: WasherGroupTypeId
FK:	None

WasherGroup will refer to this table

*/
BEGIN
SET			@TableName				=			'WasherGroupType'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempWasherGroupType	TABLE	(
TempId					INT				IDENTITY(1, 1)
,	WasherGroupTypeId		TINYINT			NOT	NULL
,	WasherGroupTypeName		VARCHAR(30)
)

--Populate temp table variable with the input data
INSERT	@tempWasherGroupType		(
WasherGroupTypeId	,WasherGroupTypeName	)
VALUES	(1	,'Conventional'		)
,	(2	,'Tunnel'		)

--SET		IDENTITY_INSERT		TCD.WasherGroupType		ON

MERGE	TCD.WasherGroupType					AS			TARGET
USING	@tempWasherGroupType			AS			SOURCE
ON	TARGET.WasherGroupTypeId		=			SOURCE.WasherGroupTypeId
WHEN	NOT MATCHED		THEN
INSERT	(WasherGroupTypeId			,WasherGroupTypeName			)
VALUES	(SOURCE.WasherGroupTypeId	,SOURCE.WasherGroupTypeName		);

--SET		IDENTITY_INSERT		[TCD].WasherGroupType		OFF
END




--/* AlarmMaster
--Identity: Id
--PRIMARY KEY: None
--FK:	None
--*/
--BEGIN
--SET			@TableName				=			'AlarmMaster'
--PRINT @TableName

----Declare temp table variable to hold input data
--DECLARE	@tempAlarmMaster			TABLE	(
--TempId					INT				IDENTITY(1, 1)
--,Id						INT				NOT NULL
--,AlarmCode					INT		NULL
--,	[Description]				NVARCHAR(MAX) NULL
--,	ControllerModelTypeId		NVARCHAR(500) NULL
--,	ResourceKey				VARChAR(50)	NULL
--,	IsDefault				BIT	NULL
--,	IsDelete					BIT	NOT	NULL
--, Id						INT				NOT NULL
--, LastModifiedTime datetime null
--, WasherType  nchar(10) null

--)

----Populate temp table variable with the input data
--INSERT	@tempAlarmMaster	(
-- AlarmCode	,[Description]	,ControllerModelTypeId	,ResourceKey	,IsDefault	,IsDelete, Id, LastModifiedTime, WasherType	)
--VALUES
--(1, N'Formula request from Washer 1 is less than or equal to zero', NULL, N'FIELD_ALARM_2', 0, 0, 1, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (2, N'Formula request from Washer 1 is greater than the allowed maximum', NULL, N'FIELD_ALARM_3', 0, 0, 2, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (3, N'Injection request from Washer 1 is greater than the allowed maximum of 6 (asking for 7 or greater)', NULL, N'FIELD_ALARM_4', 0, 0, 3, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (4, N'Washer 1 washer class is less than or equal to zero.', NULL, N'FIELD_ALARM_5', 0, 1, 4, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (5, N'Washer 1 washer class is greater than the allowed maximum of 4.', NULL, N'FIELD_ALARM_6', 0, 0, 5, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (6, N'Washer 1 requested an injection without selecting a formula first.  WASHER WILL NOT GET CHEMICAL!!', NULL, N'FIELD_ALARM_8', 0, 0, 6, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (8, N'Washer 1 has selected a formula number different than what was entered in the poundage screen', NULL, N'FIELD_ALARM_10', 0, 0, 7, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (10, N'Formula request from Washer 2 is less than or equal to zero', NULL, N'FIELD_ALARM_11', 0, 0, 8, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (11, N'Formula request from Washer 2 is greater than the allowed maximum', NULL, N'FIELD_ALARM_12', 0, 0, 9, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (12, N'Injection request from Washer 2 is greater than the allowed maximum of 6 (asking for 7 or greater)', NULL, N'FIELD_ALARM_13', 0, 0, 10, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (13, N'Washer 2 washer class is less than or equal to zero.', NULL, N'FIELD_ALARM_14', 0, 0, 11, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (14, N'Washer 2 washer class is greater than the allowed maximum of 4.', NULL, N'FIELD_ALARM_15', 0, 0, 12, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (15, N'Washer 2 requested an injection without selecting a formula first.  WASHER WILL NOT GET CHEMICAL!!', NULL, N'FIELD_ALARM_16', 0, 0, 13, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (16, N'Washer 2 has selected a formula number different than what was entered in the poundage screen', NULL, N'FIELD_ALARM_20', 0, 0, 14, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (20, N'Formula request from Washer 3 is less than or equal to zero', NULL, N'FIELD_ALARM_21', 0, 0, 15, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (21, N'Formula request from Washer 3 is greater than the allowed maximum', NULL, N'FIELD_ALARM_22', 0, 0, 16, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (22, N'Injection request from Washer 3 is greater than the allowed maximum of 6 (asking for 7 or greater)', NULL, N'FIELD_ALARM_23', 0, 0, 17, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (23, N'Washer 3 washer class is less than or equal to zero.', NULL, N'FIELD_ALARM_24', 0, 0, 18, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (24, N'Washer 3 washer class is greater than the allowed maximum of 4.', NULL, N'FIELD_ALARM_25', 0, 0, 19, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (25, N'Washer 3 requested an injection without selecting a formula first.  WASHER WILL NOT GET CHEMICAL!!', NULL, N'FIELD_ALARM_26', 0, 0, 20, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (26, N'Washer 3 has selected a formula number different than what was entered in the poundage screen', NULL, N'FIELD_ALARM_30', 0, 0, 21, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (30, N'Formula request from Washer 4 is less than or equal to zero', NULL, N'FIELD_ALARM_31', 0, 0, 22, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (31, N'Formula request from Washer 4 is greater than the allowed maximum', NULL, N'FIELD_ALARM_32', 0, 0, 23, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (32, N'Injection request from Washer 4 is greater than the allowed maximum of 6 (asking for 7 or greater)', NULL, N'FIELD_ALARM_33', 0, 0, 24, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (33, N'Washer 4 washer class is less than or equal to zero.', NULL, N'FIELD_ALARM_34', 0, 0, 25, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (34, N'Washer 4 washer class is greater than the allowed maximum of 4.', NULL, N'FIELD_ALARM_35', 0, 0, 26, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (35, N'Washer 4 requested an injection without selecting a formula first.  WASHER WILL NOT GET CHEMICAL!!', NULL, N'FIELD_ALARM_36', 0, 0, 27, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (36, N'Washer 4 has selected a formula number different than what was entered in the poundage screen', NULL, N'FIELD_ALARM_40', 0, 0, 28, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (40, N'Formula request from Washer 5 is less than or equal to zero', NULL, N'FIELD_ALARM_41', 0, 0, 29, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (41, N'Formula request from Washer 5 is greater than the allowed maximum', NULL, N'FIELD_ALARM_42', 0, 0, 30, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (42, N'Injection request from Washer 5 is greater than the allowed maximum of 6 (asking for 7 or greater)', NULL, N'FIELD_ALARM_43', 0, 0, 31, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (43, N'Washer 5 washer class is less than or equal to zero.', NULL, N'FIELD_ALARM_44', 0, 0, 32, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (44, N'Washer 5 washer class is greater than the allowed maximum of 4.', NULL, N'FIELD_ALARM_45', 0, 0, 33, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (45, N'Washer 5 requested an injection without selecting a formula first.  WASHER WILL NOT GET CHEMICAL!!', NULL, N'FIELD_ALARM_46', 0, 0, 34, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (46, N'Washer 5 has selected a formula number different than what was entered in the poundage screen', NULL, N'FIELD_ALARM_50', 0, 0, 35, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (50, N'Formula request from Washer 6 is less than or equal to zero', NULL, N'FIELD_ALARM_51', 0, 0, 36, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (51, N'Formula request from Washer 6 is greater than the allowed maximum', NULL, N'FIELD_ALARM_52', 0, 0, 37, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (52, N'Injection request from Washer 6 is greater than the allowed maximum of 6 (asking for 7 or greater)', NULL, N'FIELD_ALARM_53', 0, 0, 38, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (53, N'Washer 6 washer class is less than or equal to zero.', NULL, N'FIELD_ALARM_54', 0, 0, 39, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (54, N'Washer 6 washer class is greater than the allowed maximum of 4.', NULL, N'FIELD_ALARM_55', 0, 0, 40, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (55, N'Washer 6 requested an injection without selecting a formula first.  WASHER WILL NOT GET CHEMICAL!!', NULL, N'FIELD_ALARM_56', 0, 0, 41, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (56, N'Washer 6 has selected a formula number different than what was entered in the poundage screen', NULL, N'FIELD_ALARM_60', 0, 0, 42, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (60, N'Formula request from Washer 7 is less than or equal to zero', NULL, N'FIELD_ALARM_61', 0, 0, 43, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (61, N'Formula request from Washer 7 is greater than the allowed maximum', NULL, N'FIELD_ALARM_62', 0, 0, 44, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (62, N'Injection request from Washer 7 is greater than the allowed maximum of 6 (asking for 7 or greater)', NULL, N'FIELD_ALARM_63', 0, 0, 45, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (63, N'Washer 7 washer class is less than or equal to zero.', NULL, N'FIELD_ALARM_64', 0, 0, 46, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (64, N'Washer 7 washer class is greater than the allowed maximum of 4.', NULL, N'FIELD_ALARM_141', 0, 0, 47, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (141, N'Loss of chemical flow.  The flowmeter is seeing a flowrate less than 0.3 gallons/minute.', NULL, N'FIELD_ALARM_142', 1, 0, 48, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (142, N'Washer 1 flow switch is not sensing flow during the final flush step (electric pump)', NULL, N'FIELD_ALARM_143', 1, 0, 49, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (143, N'Washer 2 flow switch is not sensing flow during the final flush step (electric pump)', NULL, N'FIELD_ALARM_144', 1, 0, 50, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (144, N'Washer 3 flow switch is not sensing flow during the final flush step (electric pump)', NULL, N'FIELD_ALARM_145', 1, 0, 51, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (145, N'Washer 4 flow switch is not sensing flow during the final flush step (electric pump)', NULL, N'FIELD_ALARM_146', 1, 0, 52, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (146, N'Washer 5 flow switch is not sensing flow during the final flush step (electric pump)', NULL, N'FIELD_ALARM_147', 1, 0, 53, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (147, N'Washer 6 flow switch is not sensing flow during the final flush step (electric pump)', NULL, N'FIELD_ALARM_148', 1, 0, 54, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (148, N'Washer 7 flow switch is not sensing flow during the final flush step (electric pump)', NULL, N'FIELD_ALARM_149', 1, 0, 55, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (149, N'Washer 8 flow switch is not sensing flow during the final flush step (electric pump)', NULL, N'FIELD_ALARM_150', 1, 0, 56, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (150, N'Washer 9 flow switch is not sensing flow during the final flush step (electric pump)', NULL, N'FIELD_ALARM_151', 1, 0, 57, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (151, N'Washer 10 flow switch is not sensing flow during the final flush step (electric pump)', NULL, N'FIELD_ALARM_152', 1, 0, 58, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (152, N'Washer 11 flow switch is not sensing flow during the final flush step (electric pump)', NULL, N'FIELD_ALARM_153', 1, 0, 59, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (153, N'Washer 12 flow switch is not sensing flow during the final flush step (electric pump)', NULL, N'FIELD_ALARM_154', 1, 0, 60, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (154, N'The flow switch is not sensing flow out to the washer number listed to the left.', NULL, N'FIELD_ALARM_155', 1, 0, 61, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (155, N'Washer 1 flow switch is sensing flow when chemical is being pumped to the washer number listed to the left.', NULL, N'FIELD_ALARM_156', 0, 0, 62, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (156, N'Washer 2 flow switch is sensing flow when chemical is being pumped to another washer.', NULL, N'FIELD_ALARM_157', 0, 0, 63, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (157, N'Washer 3 flow switch is sensing flow when chemical is being pumped to another washer.', NULL, N'FIELD_ALARM_158', 0, 0, 64, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (158, N'Washer 4 flow switch is sensing flow when chemical is being pumped to another washer.', NULL, N'FIELD_ALARM_159', 0, 0, 65, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (159, N'Washer 5 flow switch is sensing flow when chemical is being pumped to another washer.', NULL, N'FIELD_ALARM_160', 0, 0, 66, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (160, N'Washer 6 flow switch is sensing flow when chemical is being pumped to another washer.', NULL, N'FIELD_ALARM_161', 0, 0, 67, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (161, N'Washer 7 flow switch is sensing flow when chemical is being pumped to another washer.', NULL, N'FIELD_ALARM_162', 0, 0, 68, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (162, N'Washer 8 flow switch is sensing flow when chemical is being pumped to another washer.', NULL, N'FIELD_ALARM_163', 0, 0, 69, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (163, N'Washer 9 flow switch is sensing flow when chemical is being pumped to another washer.', NULL, N'FIELD_ALARM_164', 0, 0, 70, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (164, N'Washer 10 flow switch is sensing flow when chemical is being pumped to another washer.', NULL, N'FIELD_ALARM_165', 0, 0, 71, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (165, N'Washer 11 flow switch is sensing flow when chemical is being pumped to another washer.', NULL, N'FIELD_ALARM_166', 0, 0, 72, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (166, N'Washer 12 flow switch is sensing flow when chemical is being pumped to another washer.', NULL, N'FIELD_ALARM_168', 0, 0, 73, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (168, N'The water pump electrical overload had been tripped.', NULL, N'FIELD_ALARM_169', 0, 0, 74, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (169, N'Lost 24 volt DC power.', NULL, N'FIELD_ALARM_170', 0, 0, 75, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (170, N'The tempered water tank is out of water.', NULL, N'FIELD_ALARM_175', 1, 0, 76, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (175, N'The PLC tried to pump more than 10 chemicals in the current injection.', NULL, N'FIELD_ALARM_180', 0, 0, 77, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (180, N'Loss of WaterFlow. The Flowmeter is seeing a flowrate less than 0.3 gallons/minute', NULL, N'FIELD_ALARM_185', 0, 0, 78, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (185, N'ChemWatch Reporting is not Responding to the LFS.', NULL, N'FIELD_ALARM_186', 0, 0, 79, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (186, N'Loss of Chemical flow for pump 1', NULL, N'FIELD_ALARM_187', 0, 0, 80, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (187, N'Loss of Chemical flow for pump 2', NULL, N'FIELD_ALARM_188', 0, 0, 81, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (188, N'Loss of Chemical flow for pump 3', NULL, N'FIELD_ALARM_189', 0, 0, 82, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (189, N'Loss of Chemical flow for pump 4', NULL, N'FIELD_ALARM_190', 0, 0, 83, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (190, N'Loss of Chemical flow for pump 5', NULL, N'FIELD_ALARM_191', 0, 0, 84, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (191, N'Loss of Chemical flow for pump 6', NULL, N'FIELD_ALARM_192', 0, 0, 85, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (192, N'Loss of Chemical flow for pump 7', NULL, N'FIELD_ALARM_193', 0, 0, 86, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (193, N'Loss of Chemical flow for pump 8', NULL, N'FIELD_ALARM_194', 0, 0, 87, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (194, N'Loss of Chemical flow for pump 9', NULL, N'FIELD_ALARM_195', 0, 0, 88, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (195, N'Loss of Chemical flow for pump 10', NULL, N'FIELD_ALARM_196', 0, 0, 89, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (196, N'Loss of Chemical flow for pump 11', NULL, N'FIELD_ALARM_197', 0, 0, 90, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (197, N'Loss of Chemical flow for pump 12', NULL, N'FIELD_ALARM_198', 0, 0, 91, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (198, N'Loss of Chemical flow for pump 13', NULL, N'FIELD_ALARM_199', 0, 0, 92, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (199, N'Loss of Chemical flow for pump 14', NULL, N'FIELD_ALARM_200', 0, 0, 93, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (200, N'Loss of Chemical flow for pump 15', NULL, N'FIELD_ALARM_201', 0, 0, 94, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (201, N'Loss of Chemical flow for pump 16', NULL, N'FIELD_ALARM_202', 0, 0, 95, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (202, N'(may be U2000 only?) water flow switch showing flow when pump not on', NULL, N'FIELD_ALARM_7', 0, 0, 96, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (7, N'The maximum allowed injection is set less than or equal to zero. Wrong data stored in PLC.  Call your Service Representative.', NULL, N'FIELD_ALARM_171', 0, 0, 97, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (171, N'The flowmeter is showing flow during system idle time. ', NULL, N'FIELD_ALARM_65', 0, 0, 100, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (65, N'Washer 7 requested an injection without selecting a formula first.  WASHER WILL NOT GET CHEMICAL!!', NULL, N'FIELD_ALARM_66', 0, 0, 101, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (66, N'Washer 7 has selected a formula number different than what was entered in the poundage screen', NULL, N'FIELD_ALARM_70', 0, 0, 102, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (70, N'Formula request from Washer 8 is less than or equal to zero', NULL, N'FIELD_ALARM_71', 0, 0, 103, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (71, N'Formula request from Washer 8 is greater than the allowed maximum', NULL, N'FIELD_ALARM_72', 0, 0, 104, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (72, N'Injection request from Washer 8 is greater than the allowed maximum of 6 (asking for 7 or greater)', NULL, N'FIELD_ALARM_73', 0, 0, 105, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (73, N'Washer 8 washer class is less than or equal to zero.', NULL, N'FIELD_ALARM_74', 0, 0, 106, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (74, N'Washer 8 washer class is greater than the allowed maximum of 4.', NULL, N'FIELD_ALARM_75', 0, 0, 107, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (75, N'Washer 8 requested an injection without selecting a formula first.  WASHER WILL NOT GET CHEMICAL!!', NULL, N'FIELD_ALARM_76', 0, 0, 108, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (76, N'Washer 8 has selected a formula number different than what was entered in the poundage screen', NULL, N'FIELD_ALARM_80', 0, 0, 109, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (80, N'Formula request from Washer 9 is less than or equal to zero', NULL, N'FIELD_ALARM_81', 0, 0, 110, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (81, N'Formula request from Washer 9 is greater than the allowed maximum', NULL, N'FIELD_ALARM_82', 0, 0, 111, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (82, N'Injection request from Washer 9 is greater than the allowed maximum of 6 (asking for 7 or greater)', NULL, N'FIELD_ALARM_83', 0, 0, 112, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (83, N'Washer 9 washer class is less than or equal to zero.', NULL, N'FIELD_ALARM_84', 0, 0, 113, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (84, N'Washer 9 washer class is greater than the allowed maximum of 4.', NULL, N'FIELD_ALARM_85', 0, 0, 114, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (85, N'Washer 9 requested an injection without selecting a formula first.  WASHER WILL NOT GET CHEMICAL!!', NULL, N'FIELD_ALARM_86', 0, 0, 115, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (86, N'Washer 9 has selected a formula number different than what was entered in the poundage screen', NULL, N'FIELD_ALARM_90', 0, 0, 116, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (90, N'Formula request from Washer 10 is less than or equal to zero', NULL, N'FIELD_ALARM_91', 0, 0, 117, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (91, N'Formula request from Washer 10 is greater than the allowed maximum', NULL, N'FIELD_ALARM_92', 0, 0, 118, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (92, N'Injection request from Washer 10 is greater than the allowed maximum of 6 (asking for 7 or greater)', NULL, N'FIELD_ALARM_93', 0, 0, 119, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (93, N'Washer 10 washer class is less than or equal to zero.', NULL, N'FIELD_ALARM_94', 0, 0, 120, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (94, N'Washer 10 washer class is greater than the allowed maximum of 4.', NULL, N'FIELD_ALARM_95', 0, 0, 121, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (95, N'Washer 10 requested an injection without selecting a formula first.  WASHER WILL NOT GET CHEMICAL!!', NULL, N'FIELD_ALARM_96', 0, 0, 122, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (96, N'Washer 10 has selected a formula number different than what was entered in the poundage screen', NULL, N'FIELD_ALARM_100', 0, 0, 123, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (100, N'Formula request from Washer 11 is less than or equal to zero', NULL, N'FIELD_ALARM_101', 0, 0, 124, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (101, N'Formula request from Washer 11 is greater than the allowed maximum', NULL, N'FIELD_ALARM_102', 0, 0, 125, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (102, N'Injection request from Washer 11 is greater than the allowed maximum of 6 (asking for 7 or greater)', NULL, N'FIELD_ALARM_103', 0, 0, 126, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (103, N'Washer 11 washer class is less than or equal to zero.', NULL, N'FIELD_ALARM_104', 0, 0, 127, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (104, N'Washer 11 washer class is greater than the allowed maximum of 4.', NULL, N'FIELD_ALARM_105', 0, 0, 128, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (105, N'Washer 11 requested an injection without selecting a formula first.  WASHER WILL NOT GET CHEMICAL!!', NULL, N'FIELD_ALARM_106', 0, 0, 129, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (106, N'Washer 11 has selected a formula number different than what was entered in the poundage screen', NULL, N'FIELD_ALARM_110', 0, 0, 130, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (110, N'Formula request from Washer 12 is less than or equal to zero', NULL, N'FIELD_ALARM_111', 0, 0, 131, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (111, N'Formula request from Washer 12 is greater than the allowed maximum', NULL, N'FIELD_ALARM_112', 0, 0, 132, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (112, N'Injection request from Washer 12 is greater than the allowed maximum of 6 (asking for 7 or greater)', NULL, N'FIELD_ALARM_113', 0, 0, 133, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (113, N'Washer 12 washer class is less than or equal to zero.', NULL, N'FIELD_ALARM_114', 0, 0, 134, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (114, N'Washer 12 washer class is greater than the allowed maximum of 4.', NULL, N'FIELD_ALARM_115', 0, 0, 135, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (115, N'Washer 12 requested an injection without selecting a formula first.  WASHER WILL NOT GET CHEMICAL!!', NULL, N'FIELD_ALARM_116', 0, 0, 136, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (116, N'Washer 12 has selected a formula number different than what was entered in the poundage screen', NULL, N'FIELD_ALARM_121', 0, 0, 137, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (121, N'QTWFA > 128', NULL, N'FIELD_ALARM_122', 0, 0, 138, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (122, N'The K-factor used for the current injector being pumped is less than zero.', NULL, N'FIELD_ALARM_123', 0, 0, 139, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (123, N'Ultrax CPU battery is low.', NULL, N'FIELD_ALARM_124', 0, 0, 140, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (124, N'The Ultrax did not receive a formula number from the washer listed to the left and WILL NOT GET CHEMICAL!!', NULL, N'FIELD_ALARM_135', 0, 0, 141, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (135, N'The pump has stalled at least 3 times.', NULL, N'FIELD_ALARM_136', 0, 0, 142, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (136, N'The current washer number (left) being pumped to has a value less than or equal to zero.', NULL, N'FIELD_ALARM_137', 0, 0, 143, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (137, N'ther current washer (left) has a formula number less than or equal to zero.', NULL, N'FIELD_ALARM_138', 0, 0, 144, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (138, N'The offset used to search for formula quantity information is less than zero.', NULL, N'FIELD_ALARM_139', 1, 0, 145, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (139, N'The quantity being pumped is less than zero (negative).', NULL, N'FIELD_ALARM_140', 0, 0, 146, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (140, N'The chemical amount requested exceeds the maximum limit.', NULL, N'FIELD_ALARM_999', 1, 0, 147, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (999, N'Washer Disable Button Pressed (E-Stop)', NULL, N'FIELD_ALARM_1234', 1, 0, 149, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (1234, N'Dispenser left in calibration mode', NULL, N'FIELD_ALARM_211', 0, 0, 150, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (211, N'Washer 1 was started with an invalid load weight', NULL, N'FIELD_ALARM_212', 0, 0, 151, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (212, N'Washer 2 was started with an invalid load weight', NULL, N'FIELD_ALARM_213', 0, 0, 152, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (213, N'Washer 3 was started with an invalid load weight', NULL, N'FIELD_ALARM_214', 0, 0, 153, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (214, N'Washer 4 was started with an invalid load weight', NULL, N'FIELD_ALARM_215', 0, 0, 154, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (215, N'Washer 5 was started with an invalid load weight', NULL, N'FIELD_ALARM_216', 0, 0, 155, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (216, N'Washer 6 was started with an invalid load weight', NULL, N'FIELD_ALARM_217', 0, 0, 156, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (217, N'Washer 7 was started with an invalid load weight', NULL, N'FIELD_ALARM_218', 0, 0, 157, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (218, N'Washer 8 was started with an invalid load weight', NULL, N'FIELD_ALARM_219', 0, 0, 158, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (219, N'Washer 9 was started with an invalid load weight', NULL, N'FIELD_ALARM_220', 0, 0, 159, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (220, N'Washer 10 was started with an invalid load weight', NULL, N'FIELD_ALARM_221', 0, 0, 160, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (221, N'Washer 11 was started with an invalid load weight', NULL, N'FIELD_ALARM_222', 0, 0, 161, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (222, N'Washer 12 was started with an invalid load weight', NULL, N'FIELD_ALARM_223', 0, 0, 162, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (223, N'Washer 13 was started with an invalid load weight', NULL, N'FIELD_ALARM_224', 0, 0, 163, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (224, N'Washer 14 was started with an invalid load weight', NULL, N'FIELD_ALARM_225', 0, 0, 164, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (225, N'Washer 15 was started with an invalid load weight', NULL, N'FIELD_ALARM_226', 0, 0, 165, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (226, N'Washer 16 was started with an invalid load weight', NULL, N'FIELD_ALARM_240', 0, 0, 166, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (240, N'Washer 1 formula discrepency', NULL, N'FIELD_ALARM_241', 0, 0, 167, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (241, N'Washer 2 formula discrepency', NULL, N'FIELD_ALARM_242', 0, 0, 168, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (242, N'Washer 3 formula discrepency', NULL, N'FIELD_ALARM_243', 0, 0, 169, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (243, N'Washer 4 formula discrepency', NULL, N'FIELD_ALARM_244', 0, 0, 170, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (244, N'Washer 5 formula discrepency', NULL, N'FIELD_ALARM_245', 0, 0, 171, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (245, N'Washer 6 formula discrepency', NULL, N'FIELD_ALARM_246', 0, 0, 172, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (246, N'Washer 7 formula discrepency', NULL, N'FIELD_ALARM_247', 0, 0, 173, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (247, N'Washer 8 formula discrepency', NULL, N'FIELD_ALARM_248', 0, 0, 174, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (248, N'Washer 9 formula discrepency', NULL, N'FIELD_ALARM_249', 0, 0, 175, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (249, N'Washer 10 formula discrepency', NULL, N'FIELD_ALARM_250', 0, 0, 176, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (250, N'Washer 11 formula discrepency', NULL, N'FIELD_ALARM_251', 0, 0, 177, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (251, N'Washer 12 formula discrepency', NULL, N'FIELD_ALARM_252', 0, 0, 178, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (252, N'Washer 13 formula discrepency', NULL, N'FIELD_ALARM_253', 0, 0, 179, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (253, N'Washer 14 formula discrepency', NULL, N'FIELD_ALARM_254', 0, 0, 180, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (254, N'Washer 15 formula discrepency', NULL, N'FIELD_ALARM_255', 0, 0, 181, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (255, N'Washer 16 formula discrepency', NULL, N'FIELD_ALARM_300', 0, 0, 182, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (300, N'Formula request from Washer 13 is less than or equal to zero', NULL, N'FIELD_ALARM_301', 0, 0, 183, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (301, N'Formula request from Washer 13 is greater than the allowed maximum', NULL, N'FIELD_ALARM_302', 0, 0, 184, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (302, N'Injection request from Washer 13 is greater than the allowed maximum of 6 (asking for 7 or greater)', NULL, N'FIELD_ALARM_303', 0, 0, 185, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (303, N'Washer 13 washer class is less than or equal to zero.', NULL, N'FIELD_ALARM_304', 0, 0, 186, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (304, N'Washer 13 washer class is greater than the allowed maximum of 4.', NULL, N'FIELD_ALARM_305', 0, 0, 187, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (305, N'Washer 13 requested an injection without selecting a formula first.  WASHER WILL NOT GET CHEMICAL!!', NULL, N'FIELD_ALARM_306', 0, 0, 188, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (306, N'Washer 13 has selected a formula number different than what was entered in the poundage screen', NULL, N'FIELD_ALARM_310', 0, 0, 189, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (310, N'Formula request from Washer 14 is less than or equal to zero', NULL, N'FIELD_ALARM_311', 0, 0, 190, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (311, N'Formula request from Washer 14 is greater than the allowed maximum', NULL, N'FIELD_ALARM_312', 0, 0, 191, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (312, N'Injection request from Washer 14 is greater than the allowed maximum of 6 (asking for 7 or greater)', NULL, N'FIELD_ALARM_313', 0, 0, 192, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (313, N'Washer 14 washer class is less than or equal to zero.', NULL, N'FIELD_ALARM_314', 0, 0, 193, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (314, N'Washer 14 washer class is greater than the allowed maximum of 4.', NULL, N'FIELD_ALARM_315', 0, 0, 194, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (315, N'Washer 14 requested an injection without selecting a formula first.  WASHER WILL NOT GET CHEMICAL!!', NULL, N'FIELD_ALARM_316', 0, 0, 195, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (316, N'Washer 14 has selected a formula number different than what was entered in the poundage screen', NULL, N'FIELD_ALARM_320', 0, 0, 196, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (320, N'Formula request from Washer 15 is less than or equal to zero', NULL, N'FIELD_ALARM_321', 0, 0, 197, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (321, N'Formula request from Washer 15 is greater than the allowed maximum', NULL, N'FIELD_ALARM_322', 0, 0, 198, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (322, N'Injection request from Washer 15 is greater than the allowed maximum of 6 (asking for 7 or greater)', NULL, N'FIELD_ALARM_323', 0, 0, 199, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (323, N'Washer 15 washer class is less than or equal to zero.', NULL, N'FIELD_ALARM_324', 0, 0, 200, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (324, N'Washer 15 washer class is greater than the allowed maximum of 4.', NULL, N'FIELD_ALARM_325', 0, 0, 201, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (325, N'Washer 15 requested an injection without selecting a formula first.  WASHER WILL NOT GET CHEMICAL!!', NULL, N'FIELD_ALARM_326', 0, 0, 202, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (326, N'Washer 15 has selected a formula number different than what was entered in the poundage screen', NULL, N'FIELD_ALARM_330', 0, 0, 203, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (330, N'Formula request from Washer 16 is less than or equal to zero', NULL, N'FIELD_ALARM_331', 0, 0, 204, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (331, N'Formula request from Washer 16 is greater than the allowed maximum', NULL, N'FIELD_ALARM_332', 0, 0, 205, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (332, N'Injection request from Washer 16 is greater than the allowed maximum of 6 (asking for 7 or greater)', NULL, N'FIELD_ALARM_333', 0, 0, 206, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (333, N'Washer 16 washer class is less than or equal to zero.', NULL, N'FIELD_ALARM_334', 0, 0, 207, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (334, N'Washer 16 washer class is greater than the allowed maximum of 4.', NULL, N'FIELD_ALARM_335', 0, 0, 208, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (335, N'Washer 16 requested an injection without selecting a formula first.  WASHER WILL NOT GET CHEMICAL!!', NULL, N'FIELD_ALARM_336', 0, 0, 209, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (336, N'Washer 16 has selected a formula number different than what was entered in the poundage screen', NULL, N'FIELD_ALARM_350', 0, 0, 210, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (350, N'Washer 13 flow switch is not sensing flow during the final flush step (electric pump)', NULL, N'FIELD_ALARM_351', 1, 0, 211, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (351, N'Washer 14 flow switch is not sensing flow during the final flush step (electric pump)', NULL, N'FIELD_ALARM_352', 1, 0, 212, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (352, N'Washer 15 flow switch is not sensing flow during the final flush step (electric pump)', NULL, N'FIELD_ALARM_353', 1, 0, 213, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (353, N'Washer 16 flow switch is not sensing flow during the final flush step (electric pump)', NULL, N'FIELD_ALARM_355', 1, 0, 214, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (355, N'Washer 13 flow switch is sensing flow when chemical is being pumped to another washer.', NULL, N'FIELD_ALARM_356', 0, 0, 215, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (356, N'Washer 14 flow switch is sensing flow when chemical is being pumped to another washer.', NULL, N'FIELD_ALARM_357', 0, 0, 216, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (357, N'Washer 15 flow switch is sensing flow when chemical is being pumped to another washer.', NULL, N'FIELD_ALARM_358', 0, 0, 217, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (358, N'Washer 16 flow switch is sensing flow when chemical is being pumped to another washer.', NULL, N'FIELD_ALARM_0', 0, 0, 218, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (0, N'System OK. Manual reset of the Ultrax error using the PanelView display module', NULL, N'FIELD_ALARM_1', 0, 0, 219, CAST(0x0000A4F20070DC19 AS DateTime), N'G         ')
--,
--  (1, N'Emergency / Air pressure / Low voltage alarm', 10, N'FIELD_ALARM_1_myControl(Beckhoff)', 0, 0, 220, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (2, N'Flush water alarm', 10, N'FIELD_ALARM_2_myControl(Beckhoff)', 0, 0, 221, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (3, N'Flush leak alarm', 10, N'FIELD_ALARM_3_myControl(Beckhoff)', 0, 0, 222, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (4, N'Helms communication timout', 10, N'FIELD_ALARM_4_myControl(Beckhoff)', 0, 0, 223, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (5, N'Connex Alarm', 10, N'FIELD_ALARM_5_myControl(Beckhoff)', 0, 0, 224, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (6, N'Flush system max time alarm', 10, N'FIELD_ALARM_6_myControl(Beckhoff)', 0, 0, 225, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (7, N'Flush system low level alarm', 10, N'FIELD_ALARM_7_myControl(Beckhoff)', 0, 0, 226, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (8, N'Air pressure alarm', 10, N'FIELD_ALARM_8_myControl(Beckhoff)', 0, 0, 227, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (9, N'Emergency stop alarm', 10, N'FIELD_ALARM_9_myControl(Beckhoff)', 0, 0, 228, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (10, N'Low level P1', 10, N'FIELD_ALARM_10_myControl(Beckhoff)', 0, 0, 229, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (11, N'Low level P2', 10, N'FIELD_ALARM_11_myControl(Beckhoff)', 0, 0, 230, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (12, N'Low level P3', 10, N'FIELD_ALARM_12_myControl(Beckhoff)', 0, 0, 231, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (13, N'Low level P4', 10, N'FIELD_ALARM_13_myControl(Beckhoff)', 0, 0, 232, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (14, N'Low level P5', 10, N'FIELD_ALARM_14_myControl(Beckhoff)', 0, 0, 233, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (15, N'Low level P6', 10, N'FIELD_ALARM_15_myControl(Beckhoff)', 0, 0, 234, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (16, N'Low level P7', 10, N'FIELD_ALARM_16_myControl(Beckhoff)', 0, 0, 235, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (17, N'Low level P8', 10, N'FIELD_ALARM_17_myControl(Beckhoff)', 0, 0, 236, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (18, N'Low level P9', 10, N'FIELD_ALARM_18_myControl(Beckhoff)', 0, 0, 237, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (19, N'Low level P10', 10, N'FIELD_ALARM_19_myControl(Beckhoff)', 0, 0, 238, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (20, N'Low level P11', 10, N'FIELD_ALARM_20_myControl(Beckhoff)', 0, 0, 239, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (21, N'Low level P12', 10, N'FIELD_ALARM_21_myControl(Beckhoff)', 0, 0, 240, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (22, N'Low level P13', 10, N'FIELD_ALARM_22_myControl(Beckhoff)', 0, 0, 241, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (23, N'Low level P14', 10, N'FIELD_ALARM_23_myControl(Beckhoff)', 0, 0, 242, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (24, N'Low level ME1', 10, N'FIELD_ALARM_24_myControl(Beckhoff)', 0, 0, 243, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (25, N'Low level ME2', 10, N'FIELD_ALARM_25_myControl(Beckhoff)', 0, 0, 244, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (26, N'Maximum dosing time P1', 10, N'FIELD_ALARM_26_myControl(Beckhoff)', 0, 0, 245, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (27, N'Maximum dosing time P2', 10, N'FIELD_ALARM_27_myControl(Beckhoff)', 0, 0, 246, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (28, N'Maximum dosing time P3', 10, N'FIELD_ALARM_28_myControl(Beckhoff)', 0, 0, 247, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (29, N'Maximum dosing time P4', 10, N'FIELD_ALARM_29_myControl(Beckhoff)', 0, 0, 248, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (30, N'Maximum dosing time P5', 10, N'FIELD_ALARM_30_myControl(Beckhoff)', 0, 0, 249, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (31, N'Maximum dosing time P6', 10, N'FIELD_ALARM_31_myControl(Beckhoff)', 0, 0, 250, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (32, N'Maximum dosing time P7', 10, N'FIELD_ALARM_32_myControl(Beckhoff)', 0, 0, 251, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (33, N'Maximum dosing time P8', 10, N'FIELD_ALARM_33_myControl(Beckhoff)', 0, 0, 252, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (34, N'Maximum dosing time P9', 10, N'FIELD_ALARM_34_myControl(Beckhoff)', 0, 0, 253, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (35, N'Maximum dosing time P10', 10, N'FIELD_ALARM_35_myControl(Beckhoff)', 0, 0, 254, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (36, N'Maximum dosing time P11', 10, N'FIELD_ALARM_36_myControl(Beckhoff)', 0, 0, 255, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (37, N'Maximum dosing time P12', 10, N'FIELD_ALARM_37_myControl(Beckhoff)', 0, 0, 256, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (38, N'Maximum dosing time P13', 10, N'FIELD_ALARM_38_myControl(Beckhoff)', 0, 0, 257, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (39, N'Maximum dosing time P14', 10, N'FIELD_ALARM_39_myControl(Beckhoff)', 0, 0, 258, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (40, N'Maximum dosing time P15', 10, N'FIELD_ALARM_40_myControl(Beckhoff)', 0, 0, 259, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (41, N'Maximum dosing time P16', 10, N'FIELD_ALARM_41_myControl(Beckhoff)', 0, 0, 260, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (42, N'Maximum dosing time P17', 10, N'FIELD_ALARM_42_myControl(Beckhoff)', 0, 0, 261, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (43, N'Maximum dosing time P18', 10, N'FIELD_ALARM_43_myControl(Beckhoff)', 0, 0, 262, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (44, N'Maximum dosing time P19', 10, N'FIELD_ALARM_44_myControl(Beckhoff)', 0, 0, 263, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (45, N'Maximum dosing time P20', 10, N'FIELD_ALARM_45_myControl(Beckhoff)', 0, 0, 264, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (46, N'Maximum dosing time P21', 10, N'FIELD_ALARM_46_myControl(Beckhoff)', 0, 0, 265, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (47, N'Maximum dosing time P22', 10, N'FIELD_ALARM_47_myControl(Beckhoff)', 0, 0, 266, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (48, N'Maximum dosing time P23', 10, N'FIELD_ALARM_48_myControl(Beckhoff)', 0, 0, 267, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (49, N'Maximum dosing time P24', 10, N'FIELD_ALARM_49_myControl(Beckhoff)', 0, 0, 268, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (50, N'Maximum dosing time ME1', 10, N'FIELD_ALARM_50_myControl(Beckhoff)', 0, 0, 269, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (51, N'Maximum dosing time ME2', 10, N'FIELD_ALARM_51_myControl(Beckhoff)', 0, 0, 270, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (52, N'Flowswitch alarm P1', 10, N'FIELD_ALARM_52_myControl(Beckhoff)', 0, 0, 271, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (53, N'Flowswitch alarm P2', 10, N'FIELD_ALARM_53_myControl(Beckhoff)', 0, 0, 272, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (54, N'Flowswitch alarm P3', 10, N'FIELD_ALARM_54_myControl(Beckhoff)', 0, 0, 273, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (55, N'Flowswitch alarm P4', 10, N'FIELD_ALARM_55_myControl(Beckhoff)', 0, 0, 274, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (56, N'Flowswitch alarm P5', 10, N'FIELD_ALARM_56_myControl(Beckhoff)', 0, 0, 275, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (57, N'Flowswitch alarm P6', 10, N'FIELD_ALARM_57_myControl(Beckhoff)', 0, 0, 276, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (58, N'Flowswitch alarm P7', 10, N'FIELD_ALARM_58_myControl(Beckhoff)', 0, 0, 277, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (59, N'Flowswitch alarm P8', 10, N'FIELD_ALARM_59_myControl(Beckhoff)', 0, 0, 278, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (60, N'Flowswitch alarm P9', 10, N'FIELD_ALARM_60_myControl(Beckhoff)', 0, 0, 279, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (61, N'Flowswitch alarm P10', 10, N'FIELD_ALARM_61_myControl(Beckhoff)', 0, 0, 280, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (62, N'Flowswitch alarm P11', 10, N'FIELD_ALARM_62_myControl(Beckhoff)', 0, 0, 281, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (63, N'Flowswitch alarm P12', 10, N'FIELD_ALARM_63_myControl(Beckhoff)', 0, 0, 282, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (64, N'Flowswitch alarm P13', 10, N'FIELD_ALARM_64_myControl(Beckhoff)', 0, 0, 283, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (65, N'Flowswitch alarm P14', 10, N'FIELD_ALARM_65_myControl(Beckhoff)', 0, 0, 284, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (66, N'Flowswitch alarm P15', 10, N'FIELD_ALARM_66_myControl(Beckhoff)', 0, 0, 285, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (67, N'Flowswitch alarm P16', 10, N'FIELD_ALARM_67_myControl(Beckhoff)', 0, 0, 286, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (68, N'Flowswitch alarm P17', 10, N'FIELD_ALARM_68_myControl(Beckhoff)', 0, 0, 287, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (69, N'Flowswitch alarm P18', 10, N'FIELD_ALARM_69_myControl(Beckhoff)', 0, 0, 288, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (70, N'Flowswitch alarm P19', 10, N'FIELD_ALARM_70_myControl(Beckhoff)', 0, 0, 289, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (71, N'Flowswitch alarm P20', 10, N'FIELD_ALARM_71_myControl(Beckhoff)', 0, 0, 290, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (72, N'Flowswitch alarm P21', 10, N'FIELD_ALARM_72_myControl(Beckhoff)', 0, 0, 291, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (73, N'Flowswitch alarm P22', 10, N'FIELD_ALARM_73_myControl(Beckhoff)', 0, 0, 292, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (74, N'Flowswitch alarm P23', 10, N'FIELD_ALARM_74_myControl(Beckhoff)', 0, 0, 293, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (75, N'Flowswitch alarm P24', 10, N'FIELD_ALARM_75_myControl(Beckhoff)', 0, 0, 294, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (76, N'Flowswitch alarm ME1', 10, N'FIELD_ALARM_76_myControl(Beckhoff)', 0, 0, 295, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (77, N'Flowswitch alarm ME2', 10, N'FIELD_ALARM_77_myControl(Beckhoff)', 0, 0, 296, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (78, N'Leakage alarm P1', 10, N'FIELD_ALARM_78_myControl(Beckhoff)', 0, 0, 297, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (79, N'Leakage alarm P2', 10, N'FIELD_ALARM_79_myControl(Beckhoff)', 0, 0, 298, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (80, N'Leakage alarm P3', 10, N'FIELD_ALARM_80_myControl(Beckhoff)', 0, 0, 299, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (81, N'Leakage alarm P4', 10, N'FIELD_ALARM_81_myControl(Beckhoff)', 0, 0, 300, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (82, N'Leakage alarm P5', 10, N'FIELD_ALARM_82_myControl(Beckhoff)', 0, 0, 301, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (83, N'Leakage alarm P6', 10, N'FIELD_ALARM_83_myControl(Beckhoff)', 0, 0, 302, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (84, N'Leakage alarm P7', 10, N'FIELD_ALARM_84_myControl(Beckhoff)', 0, 0, 303, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (85, N'Leakage alarm P8', 10, N'FIELD_ALARM_85_myControl(Beckhoff)', 0, 0, 304, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (86, N'Leakage alarm P9', 10, N'FIELD_ALARM_86_myControl(Beckhoff)', 0, 0, 305, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (87, N'Leakage alarm P10', 10, N'FIELD_ALARM_87_myControl(Beckhoff)', 0, 0, 306, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (88, N'Leakage alarm P11', 10, N'FIELD_ALARM_88_myControl(Beckhoff)', 0, 0, 307, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (89, N'Leakage alarm P12', 10, N'FIELD_ALARM_89_myControl(Beckhoff)', 0, 0, 308, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (90, N'Leakage alarm P13', 10, N'FIELD_ALARM_90_myControl(Beckhoff)', 0, 0, 309, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (91, N'Leakage alarm P14', 10, N'FIELD_ALARM_91_myControl(Beckhoff)', 0, 0, 310, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (92, N'Leakage alarm P15', 10, N'FIELD_ALARM_92_myControl(Beckhoff)', 0, 0, 311, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (93, N'Leakage alarm P16', 10, N'FIELD_ALARM_93_myControl(Beckhoff)', 0, 0, 312, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (94, N'Leakage alarm P17', 10, N'FIELD_ALARM_94_myControl(Beckhoff)', 0, 0, 313, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (95, N'Leakage alarm P18', 10, N'FIELD_ALARM_95_myControl(Beckhoff)', 0, 0, 314, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (96, N'Leakage alarm P19', 10, N'FIELD_ALARM_96_myControl(Beckhoff)', 0, 0, 315, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (97, N'Leakage alarm P20', 10, N'FIELD_ALARM_97_myControl(Beckhoff)', 0, 0, 316, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (98, N'Leakage alarm P21', 10, N'FIELD_ALARM_98_myControl(Beckhoff)', 0, 0, 317, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (99, N'Leakage alarm P22', 10, N'FIELD_ALARM_99_myControl(Beckhoff)', 0, 0, 318, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (100, N'Leakage alarm P23', 10, N'FIELD_ALARM_100_myControl(Beckhoff)', 0, 0, 319, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (101, N'Leakage alarm P24', 10, N'FIELD_ALARM_101_myControl(Beckhoff)', 0, 0, 320, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (102, N'Leakage alarm ME1', 10, N'FIELD_ALARM_102_myControl(Beckhoff)', 0, 0, 321, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (103, N'Leakage alarm ME2', 10, N'FIELD_ALARM_103_myControl(Beckhoff)', 0, 0, 322, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (104, N'ME1 main switch off', 10, N'FIELD_ALARM_104_myControl(Beckhoff)', 0, 0, 323, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (105, N'ME1 Pump / Agitator alarm', 10, N'FIELD_ALARM_105_myControl(Beckhoff)', 0, 0, 324, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (106, N'ME1 Water pressure alarm', 10, N'FIELD_ALARM_106_myControl(Beckhoff)', 0, 0, 325, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (107, N'ME1 Overflow', 10, N'FIELD_ALARM_107_myControl(Beckhoff)', 0, 0, 326, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (108, N'ME1 Need to fill', 10, N'FIELD_ALARM_108_myControl(Beckhoff)', 0, 0, 327, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (109, N'ME2 main switch off', 10, N'FIELD_ALARM_109_myControl(Beckhoff)', 0, 0, 328, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (110, N'ME2 Pump / Agitator alarm', 10, N'FIELD_ALARM_110_myControl(Beckhoff)', 0, 0, 329, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (111, N'ME2 Water pressure alarm', 10, N'FIELD_ALARM_111_myControl(Beckhoff)', 0, 0, 330, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (112, N'ME2 Overflow', 10, N'FIELD_ALARM_112_myControl(Beckhoff)', 0, 0, 331, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (113, N'ME2 Need to fill', 10, N'FIELD_ALARM_113_myControl(Beckhoff)', 0, 0, 332, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (114, N'Low level alarm on analog level P1', 10, N'FIELD_ALARM_114_myControl(Beckhoff)', 0, 0, 333, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (115, N'Low level alarm on analog level P2', 10, N'FIELD_ALARM_115_myControl(Beckhoff)', 0, 0, 334, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (116, N'Low level alarm on analog level P3', 10, N'FIELD_ALARM_116_myControl(Beckhoff)', 0, 0, 335, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (117, N'Low level alarm on analog level P4', 10, N'FIELD_ALARM_117_myControl(Beckhoff)', 0, 0, 336, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (118, N'Low level alarm on analog level P5', 10, N'FIELD_ALARM_118_myControl(Beckhoff)', 0, 0, 337, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (119, N'Low level alarm on analog level P6', 10, N'FIELD_ALARM_119_myControl(Beckhoff)', 0, 0, 338, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (120, N'Low level alarm on analog level P7', 10, N'FIELD_ALARM_120_myControl(Beckhoff)', 0, 0, 339, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (121, N'Low level alarm on analog level P8', 10, N'FIELD_ALARM_121_myControl(Beckhoff)', 0, 0, 340, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (122, N'Low level alarm on analog level P9', 10, N'FIELD_ALARM_122_myControl(Beckhoff)', 0, 0, 341, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (123, N'Low level alarm on analog level P10', 10, N'FIELD_ALARM_123_myControl(Beckhoff)', 0, 0, 342, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (124, N'Low level alarm on analog level P11', 10, N'FIELD_ALARM_124_myControl(Beckhoff)', 0, 0, 343, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (125, N'Low level alarm on analog level P12', 10, N'FIELD_ALARM_125_myControl(Beckhoff)', 0, 0, 344, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (126, N'Low level alarm on analog level P13', 10, N'FIELD_ALARM_126_myControl(Beckhoff)', 0, 0, 345, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (127, N'Low level alarm on analog level P14', 10, N'FIELD_ALARM_127_myControl(Beckhoff)', 0, 0, 346, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (128, N'Low level alarm on analog level ME1', 10, N'FIELD_ALARM_128_myControl(Beckhoff)', 0, 0, 347, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (129, N'Low level alarm on analog level ME2', 10, N'FIELD_ALARM_129_myControl(Beckhoff)', 0, 0, 348, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (130, N'High level alarm on analog level P1', 10, N'FIELD_ALARM_130_myControl(Beckhoff)', 0, 0, 349, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (131, N'High level alarm on analog level P2', 10, N'FIELD_ALARM_131_myControl(Beckhoff)', 0, 0, 350, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (132, N'High level alarm on analog level P3', 10, N'FIELD_ALARM_132_myControl(Beckhoff)', 0, 0, 351, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (133, N'High level alarm on analog level P4', 10, N'FIELD_ALARM_133_myControl(Beckhoff)', 0, 0, 352, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (134, N'High level alarm on analog level P5', 10, N'FIELD_ALARM_134_myControl(Beckhoff)', 0, 0, 353, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (135, N'High level alarm on analog level P6', 10, N'FIELD_ALARM_135_myControl(Beckhoff)', 0, 0, 354, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (136, N'High level alarm on analog level P7', 10, N'FIELD_ALARM_136_myControl(Beckhoff)', 0, 0, 355, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (137, N'High level alarm on analog level P8', 10, N'FIELD_ALARM_137_myControl(Beckhoff)', 0, 0, 356, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (138, N'High level alarm on analog level P9', 10, N'FIELD_ALARM_138_myControl(Beckhoff)', 0, 0, 357, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (139, N'High level alarm on analog level P10', 10, N'FIELD_ALARM_139_myControl(Beckhoff)', 0, 0, 358, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (140, N'High level alarm on analog level P11', 10, N'FIELD_ALARM_140_myControl(Beckhoff)', 0, 0, 359, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (141, N'High level alarm on analog level P12', 10, N'FIELD_ALARM_141_myControl(Beckhoff)', 0, 0, 360, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (142, N'High level alarm on analog level P13', 10, N'FIELD_ALARM_142_myControl(Beckhoff)', 0, 0, 361, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (143, N'High level alarm on analog level P14', 10, N'FIELD_ALARM_143_myControl(Beckhoff)', 0, 0, 362, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (144, N'High level alarm on analog level ME1', 10, N'FIELD_ALARM_144_myControl(Beckhoff)', 0, 0, 363, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (145, N'High level alarm on analog level ME2', 10, N'FIELD_ALARM_145_myControl(Beckhoff)', 0, 0, 364, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (146, N'Smtp function error', 10, N'FIELD_ALARM_146_myControl(Beckhoff)', 0, 0, 365, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (147, N'Free', 10, N'FIELD_ALARM_147_myControl(Beckhoff)', 0, 0, 366, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (148, N'No program detection', 10, N'FIELD_ALARM_148_myControl(Beckhoff)', 0, 0, 367, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (149, N'TOM signal alarm', 10, N'FIELD_ALARM_149_myControl(Beckhoff)', 0, 0, 368, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (150, N'pH too low alarm', 10, N'FIELD_ALARM_150_myControl(Beckhoff)', 0, 0, 369, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (151, N'pH too high alarm', 10, N'FIELD_ALARM_151_myControl(Beckhoff)', 0, 0, 370, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (152, N'pH maximum time alarm', 10, N'FIELD_ALARM_152_myControl(Beckhoff)', 0, 0, 371, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (153, N'Temperature 1 too low alarm', 10, N'FIELD_ALARM_153_myControl(Beckhoff)', 0, 0, 372, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (154, N'Temperature 2 too low alarm', 10, N'FIELD_ALARM_154_myControl(Beckhoff)', 0, 0, 373, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (155, N'Temperature 3 too low alarm', 10, N'FIELD_ALARM_155_myControl(Beckhoff)', 0, 0, 374, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (156, N'Temperature 4 too low alarm', 10, N'FIELD_ALARM_156_myControl(Beckhoff)', 0, 0, 375, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (157, N'Temperature 5 too low alarm', 10, N'FIELD_ALARM_157_myControl(Beckhoff)', 0, 0, 376, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (158, N'Temperature 6 too low alarm', 10, N'FIELD_ALARM_158_myControl(Beckhoff)', 0, 0, 377, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (159, N'LF too low alarm', 10, N'FIELD_ALARM_159_myControl(Beckhoff)', 0, 0, 378, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (160, N'LF too high alarm', 10, N'FIELD_ALARM_160_myControl(Beckhoff)', 0, 0, 379, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (161, N'LF maximum time alarm', 10, N'FIELD_ALARM_161_myControl(Beckhoff)', 0, 0, 380, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (162, N'ORP too low alarm', 10, N'FIELD_ALARM_162_myControl(Beckhoff)', 0, 0, 381, CAST(0x0000A4F20070DC19 AS DateTime), N'T         ')
--,
--  (1, N'Emergency / Air pressure / Low voltage alarm', 10, N'FIELD_ALARM_1_myControl(Beckhoff)', 0, 0, 382, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (2, N'Flush water alarm', 10, N'FIELD_ALARM_2_myControl(Beckhoff)', 0, 0, 383, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (3, N'Flush leak alarm', 10, N'FIELD_ALARM_3_myControl(Beckhoff)', 0, 0, 384, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (4, N'Helms communication timout', 10, N'FIELD_ALARM_4_myControl(Beckhoff)', 0, 0, 385, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (5, N'Connex Alarm', 10, N'FIELD_ALARM_5_myControl(Beckhoff)', 0, 0, 386, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (6, N'Flush system max time alarm', 10, N'FIELD_ALARM_6_myControl(Beckhoff)', 0, 0, 387, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (7, N'Flush system low level alarm', 10, N'FIELD_ALARM_7_myControl(Beckhoff)', 0, 0, 388, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (8, N'Air pressure alarm', 10, N'FIELD_ALARM_8_myControl(Beckhoff)', 0, 0, 389, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (9, N'Emergency stop alarm', 10, N'FIELD_ALARM_9_myControl(Beckhoff)', 0, 0, 390, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (10, N'Low level P1', 10, N'FIELD_ALARM_10_myControl(Beckhoff)', 0, 0, 391, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (11, N'Low level P2', 10, N'FIELD_ALARM_11_myControl(Beckhoff)', 0, 0, 392, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (12, N'Low level P3', 10, N'FIELD_ALARM_12_myControl(Beckhoff)', 0, 0, 393, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (13, N'Low level P4', 10, N'FIELD_ALARM_13_myControl(Beckhoff)', 0, 0, 394, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (14, N'Low level P5', 10, N'FIELD_ALARM_14_myControl(Beckhoff)', 0, 0, 395, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (15, N'Low level P6', 10, N'FIELD_ALARM_15_myControl(Beckhoff)', 0, 0, 396, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (16, N'Low level P7', 10, N'FIELD_ALARM_16_myControl(Beckhoff)', 0, 0, 397, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (17, N'Low level P8', 10, N'FIELD_ALARM_17_myControl(Beckhoff)', 0, 0, 398, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (18, N'Low level P9', 10, N'FIELD_ALARM_18_myControl(Beckhoff)', 0, 0, 399, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (19, N'Low level P10', 10, N'FIELD_ALARM_19_myControl(Beckhoff)', 0, 0, 400, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (20, N'Low level P11', 10, N'FIELD_ALARM_20_myControl(Beckhoff)', 0, 0, 401, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (21, N'Low level P12', 10, N'FIELD_ALARM_21_myControl(Beckhoff)', 0, 0, 402, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (22, N'Low level P13', 10, N'FIELD_ALARM_22_myControl(Beckhoff)', 0, 0, 403, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (23, N'Low level P14', 10, N'FIELD_ALARM_23_myControl(Beckhoff)', 0, 0, 404, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (24, N'Low level ME1', 10, N'FIELD_ALARM_24_myControl(Beckhoff)', 0, 0, 405, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (25, N'Low level ME2', 10, N'FIELD_ALARM_25_myControl(Beckhoff)', 0, 0, 406, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (26, N'Maximum dosing time P1', 10, N'FIELD_ALARM_26_myControl(Beckhoff)', 0, 0, 407, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (27, N'Maximum dosing time P2', 10, N'FIELD_ALARM_27_myControl(Beckhoff)', 0, 0, 408, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (28, N'Maximum dosing time P3', 10, N'FIELD_ALARM_28_myControl(Beckhoff)', 0, 0, 409, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (29, N'Maximum dosing time P4', 10, N'FIELD_ALARM_29_myControl(Beckhoff)', 0, 0, 410, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (30, N'Maximum dosing time P5', 10, N'FIELD_ALARM_30_myControl(Beckhoff)', 0, 0, 411, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (31, N'Maximum dosing time P6', 10, N'FIELD_ALARM_31_myControl(Beckhoff)', 0, 0, 412, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (32, N'Maximum dosing time P7', 10, N'FIELD_ALARM_32_myControl(Beckhoff)', 0, 0, 413, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (33, N'Maximum dosing time P8', 10, N'FIELD_ALARM_33_myControl(Beckhoff)', 0, 0, 414, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (34, N'Maximum dosing time P9', 10, N'FIELD_ALARM_34_myControl(Beckhoff)', 0, 0, 415, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (35, N'Maximum dosing time P10', 10, N'FIELD_ALARM_35_myControl(Beckhoff)', 0, 0, 416, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (36, N'Maximum dosing time P11', 10, N'FIELD_ALARM_36_myControl(Beckhoff)', 0, 0, 417, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (37, N'Maximum dosing time P12', 10, N'FIELD_ALARM_37_myControl(Beckhoff)', 0, 0, 418, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (38, N'Maximum dosing time P13', 10, N'FIELD_ALARM_38_myControl(Beckhoff)', 0, 0, 419, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (39, N'Maximum dosing time P14', 10, N'FIELD_ALARM_39_myControl(Beckhoff)', 0, 0, 420, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (40, N'Maximum dosing time P15', 10, N'FIELD_ALARM_40_myControl(Beckhoff)', 0, 0, 421, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (41, N'Maximum dosing time P16', 10, N'FIELD_ALARM_41_myControl(Beckhoff)', 0, 0, 422, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (42, N'Maximum dosing time P17', 10, N'FIELD_ALARM_42_myControl(Beckhoff)', 0, 0, 423, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (43, N'Maximum dosing time P18', 10, N'FIELD_ALARM_43_myControl(Beckhoff)', 0, 0, 424, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (44, N'Maximum dosing time P19', 10, N'FIELD_ALARM_44_myControl(Beckhoff)', 0, 0, 425, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (45, N'Maximum dosing time P20', 10, N'FIELD_ALARM_45_myControl(Beckhoff)', 0, 0, 426, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (46, N'Maximum dosing time P21', 10, N'FIELD_ALARM_46_myControl(Beckhoff)', 0, 0, 427, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (47, N'Maximum dosing time P22', 10, N'FIELD_ALARM_47_myControl(Beckhoff)', 0, 0, 428, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (48, N'Maximum dosing time P23', 10, N'FIELD_ALARM_48_myControl(Beckhoff)', 0, 0, 429, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (49, N'Maximum dosing time P24', 10, N'FIELD_ALARM_49_myControl(Beckhoff)', 0, 0, 430, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (50, N'Maximum dosing time ME1', 10, N'FIELD_ALARM_50_myControl(Beckhoff)', 0, 0, 431, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (51, N'Maximum dosing time ME2', 10, N'FIELD_ALARM_51_myControl(Beckhoff)', 0, 0, 432, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (52, N'Flowswitch alarm P1', 10, N'FIELD_ALARM_52_myControl(Beckhoff)', 0, 0, 433, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (53, N'Flowswitch alarm P2', 10, N'FIELD_ALARM_53_myControl(Beckhoff)', 0, 0, 434, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (54, N'Flowswitch alarm P3', 10, N'FIELD_ALARM_54_myControl(Beckhoff)', 0, 0, 435, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (55, N'Flowswitch alarm P4', 10, N'FIELD_ALARM_55_myControl(Beckhoff)', 0, 0, 436, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (56, N'Flowswitch alarm P5', 10, N'FIELD_ALARM_56_myControl(Beckhoff)', 0, 0, 437, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (57, N'Flowswitch alarm P6', 10, N'FIELD_ALARM_57_myControl(Beckhoff)', 0, 0, 438, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (58, N'Flowswitch alarm P7', 10, N'FIELD_ALARM_58_myControl(Beckhoff)', 0, 0, 439, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (59, N'Flowswitch alarm P8', 10, N'FIELD_ALARM_59_myControl(Beckhoff)', 0, 0, 440, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (60, N'Flowswitch alarm P9', 10, N'FIELD_ALARM_60_myControl(Beckhoff)', 0, 0, 441, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (61, N'Flowswitch alarm P10', 10, N'FIELD_ALARM_61_myControl(Beckhoff)', 0, 0, 442, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (62, N'Flowswitch alarm P11', 10, N'FIELD_ALARM_62_myControl(Beckhoff)', 0, 0, 443, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--,
--  (63, N'Flowswitch alarm P12', 10, N'FIELD_ALARM_63_myControl(Beckhoff)', 0, 0, 444, CAST(0x0000A4F20070DC19 AS DateTime), N'C         ')
--/*
--,

--(64, N'Flowswitch alarm P13', 10, N'FIELD_ALARM_64_myControl(Beckhoff)', 0, 0, 445, N'C         ')
--,
--(65, N'Flowswitch alarm P14', 10, N'FIELD_ALARM_65_myControl(Beckhoff)', 0, 0, 446, N'C         ')
--,
--(66, N'Flowswitch alarm P15', 10, N'FIELD_ALARM_66_myControl(Beckhoff)', 0, 0, 447, N'C         ')
--,
--(67, N'Flowswitch alarm P16', 10, N'FIELD_ALARM_67_myControl(Beckhoff)', 0, 0, 448, N'C         ')
--,
--(68, N'Flowswitch alarm P17', 10, N'FIELD_ALARM_68_myControl(Beckhoff)', 0, 0, 449, N'C         ')
--,
--(69, N'Flowswitch alarm P18', 10, N'FIELD_ALARM_69_myControl(Beckhoff)', 0, 0, 450, N'C         ')
--,
--(70, N'Flowswitch alarm P19', 10, N'FIELD_ALARM_70_myControl(Beckhoff)', 0, 0, 451, N'C         ')
--,
--(71, N'Flowswitch alarm P20', 10, N'FIELD_ALARM_71_myControl(Beckhoff)', 0, 0, 452, N'C         ')
--,
--(72, N'Flowswitch alarm P21', 10, N'FIELD_ALARM_72_myControl(Beckhoff)', 0, 0, 453, N'C         ')
--,
--(73, N'Flowswitch alarm P22', 10, N'FIELD_ALARM_73_myControl(Beckhoff)', 0, 0, 454, N'C         ')
--,
--(74, N'Flowswitch alarm P23', 10, N'FIELD_ALARM_74_myControl(Beckhoff)', 0, 0, 455, N'C         ')
--,
--(75, N'Flowswitch alarm P24', 10, N'FIELD_ALARM_75_myControl(Beckhoff)', 0, 0, 456, N'C         ')
--,
--(76, N'Flowswitch alarm ME1', 10, N'FIELD_ALARM_76_myControl(Beckhoff)', 0, 0, 457, N'C         ')
--,
--(77, N'Flowswitch alarm ME2', 10, N'FIELD_ALARM_77_myControl(Beckhoff)', 0, 0, 458, N'C         ')
--,
--(78, N'Leakage alarm P1', 10, N'FIELD_ALARM_78_myControl(Beckhoff)', 0, 0, 459, N'C         ')
--,
--(79, N'Leakage alarm P2', 10, N'FIELD_ALARM_79_myControl(Beckhoff)', 0, 0, 460, N'C         ')
--,
--(80, N'Leakage alarm P3', 10, N'FIELD_ALARM_80_myControl(Beckhoff)', 0, 0, 461, N'C         ')
--,
--(81, N'Leakage alarm P4', 10, N'FIELD_ALARM_81_myControl(Beckhoff)', 0, 0, 462, N'C         ')
--,
--(82, N'Leakage alarm P5', 10, N'FIELD_ALARM_82_myControl(Beckhoff)', 0, 0, 463, N'C         ')
--,
--(83, N'Leakage alarm P6', 10, N'FIELD_ALARM_83_myControl(Beckhoff)', 0, 0, 464, N'C         ')
--,
--(84, N'Leakage alarm P7', 10, N'FIELD_ALARM_84_myControl(Beckhoff)', 0, 0, 465, N'C         ')
--,
--(85, N'Leakage alarm P8', 10, N'FIELD_ALARM_85_myControl(Beckhoff)', 0, 0, 466, N'C         ')
--,
--(86, N'Leakage alarm P9', 10, N'FIELD_ALARM_86_myControl(Beckhoff)', 0, 0, 467, N'C         ')
--,
--(87, N'Leakage alarm P10', 10, N'FIELD_ALARM_87_myControl(Beckhoff)', 0, 0, 468, N'C         ')
--,
--(88, N'Leakage alarm P11', 10, N'FIELD_ALARM_88_myControl(Beckhoff)', 0, 0, 469, N'C         ')
--,
--(89, N'Leakage alarm P12', 10, N'FIELD_ALARM_89_myControl(Beckhoff)', 0, 0, 470, N'C         ')
--,
--(90, N'Leakage alarm P13', 10, N'FIELD_ALARM_90_myControl(Beckhoff)', 0, 0, 471, N'C         ')
--,
--(91, N'Leakage alarm P14', 10, N'FIELD_ALARM_91_myControl(Beckhoff)', 0, 0, 472, N'C         ')
--,
--(92, N'Leakage alarm P15', 10, N'FIELD_ALARM_92_myControl(Beckhoff)', 0, 0, 473, N'C         ')
--,
--(93, N'Leakage alarm P16', 10, N'FIELD_ALARM_93_myControl(Beckhoff)', 0, 0, 474, N'C         ')
--,
--(94, N'Leakage alarm P17', 10, N'FIELD_ALARM_94_myControl(Beckhoff)', 0, 0, 475, N'C         ')
--,
--(95, N'Leakage alarm P18', 10, N'FIELD_ALARM_95_myControl(Beckhoff)', 0, 0, 476, N'C         ')
--,
--(96, N'Leakage alarm P19', 10, N'FIELD_ALARM_96_myControl(Beckhoff)', 0, 0, 477, N'C         ')
--,
--(97, N'Leakage alarm P20', 10, N'FIELD_ALARM_97_myControl(Beckhoff)', 0, 0, 478, N'C         ')
--,
--(98, N'Leakage alarm P21', 10, N'FIELD_ALARM_98_myControl(Beckhoff)', 0, 0, 479, N'C         ')
--,
--(99, N'Leakage alarm P22', 10, N'FIELD_ALARM_99_myControl(Beckhoff)', 0, 0, 480, N'C         ')
--,
--(100, N'Leakage alarm P23', 10, N'FIELD_ALARM_100_myControl(Beckhoff)', 0, 0, 481, N'C         ')
--,
--(101, N'Leakage alarm P24', 10, N'FIELD_ALARM_101_myControl(Beckhoff)', 0, 0, 482, N'C         ')
--,
--(102, N'Leakage alarm ME1', 10, N'FIELD_ALARM_102_myControl(Beckhoff)', 0, 0, 483, N'C         ')
--,
--(103, N'Leakage alarm ME2', 10, N'FIELD_ALARM_103_myControl(Beckhoff)', 0, 0, 484, N'C         ')
--,
--(104, N'ME1 main switch off', 10, N'FIELD_ALARM_104_myControl(Beckhoff)', 0, 0, 485, N'C         ')
--,
--(105, N'ME1 Pump / Agitator alarm', 10, N'FIELD_ALARM_105_myControl(Beckhoff)', 0, 0, 486, N'C         ')
--,
--(106, N'ME1 Water pressure alarm', 10, N'FIELD_ALARM_106_myControl(Beckhoff)', 0, 0, 487, N'C         ')
--,
--(107, N'ME1 Overflow', 10, N'FIELD_ALARM_107_myControl(Beckhoff)', 0, 0, 488, N'C         ')
--,
--(108, N'ME1 Need to fill', 10, N'FIELD_ALARM_108_myControl(Beckhoff)', 0, 0, 489, N'C         ')
--,
--(109, N'ME2 main switch off', 10, N'FIELD_ALARM_109_myControl(Beckhoff)', 0, 0, 490, N'C         ')
--,
--(110, N'ME2 Pump / Agitator alarm', 10, N'FIELD_ALARM_110_myControl(Beckhoff)', 0, 0, 491, N'C         ')
--,
--(111, N'ME2 Water pressure alarm', 10, N'FIELD_ALARM_111_myControl(Beckhoff)', 0, 0, 492, N'C         ')
--,
--(112, N'ME2 Overflow', 10, N'FIELD_ALARM_112_myControl(Beckhoff)', 0, 0, 493, N'C         ')
--,
--(113, N'ME2 Need to fill', 10, N'FIELD_ALARM_113_myControl(Beckhoff)', 0, 0, 494, N'C         ')
--,
--(114, N'Low level alarm on analog level P1', 10, N'FIELD_ALARM_114_myControl(Beckhoff)', 0, 0, 495, N'C         ')
--,
--(115, N'Low level alarm on analog level P2', 10, N'FIELD_ALARM_115_myControl(Beckhoff)', 0, 0, 496, N'C         ')
--,
--(116, N'Low level alarm on analog level P3', 10, N'FIELD_ALARM_116_myControl(Beckhoff)', 0, 0, 497, N'C         ')
--,
--(117, N'Low level alarm on analog level P4', 10, N'FIELD_ALARM_117_myControl(Beckhoff)', 0, 0, 498, N'C         ')
--,
--(118, N'Low level alarm on analog level P5', 10, N'FIELD_ALARM_118_myControl(Beckhoff)', 0, 0, 499, N'C         ')
--,
--(119, N'Low level alarm on analog level P6', 10, N'FIELD_ALARM_119_myControl(Beckhoff)', 0, 0, 500, N'C         ')
--,
--(120, N'Low level alarm on analog level P7', 10, N'FIELD_ALARM_120_myControl(Beckhoff)', 0, 0, 501, N'C         ')
--,
--(121, N'Low level alarm on analog level P8', 10, N'FIELD_ALARM_121_myControl(Beckhoff)', 0, 0, 502, N'C         ')
--,
--(122, N'Low level alarm on analog level P9', 10, N'FIELD_ALARM_122_myControl(Beckhoff)', 0, 0, 503, N'C         ')
--,
--(123, N'Low level alarm on analog level P10', 10, N'FIELD_ALARM_123_myControl(Beckhoff)', 0, 0, 504, N'C         ')
--,
--(124, N'Low level alarm on analog level P11', 10, N'FIELD_ALARM_124_myControl(Beckhoff)', 0, 0, 505, N'C         ')
--,
--(125, N'Low level alarm on analog level P12', 10, N'FIELD_ALARM_125_myControl(Beckhoff)', 0, 0, 506, N'C         ')
--,
--(126, N'Low level alarm on analog level P13', 10, N'FIELD_ALARM_126_myControl(Beckhoff)', 0, 0, 507, N'C         ')
--,
--(127, N'Low level alarm on analog level P14', 10, N'FIELD_ALARM_127_myControl(Beckhoff)', 0, 0, 508, N'C         ')
--,
--(128, N'Low level alarm on analog level ME1', 10, N'FIELD_ALARM_128_myControl(Beckhoff)', 0, 0, 509, N'C         ')
--,
--(129, N'Low level alarm on analog level ME2', 10, N'FIELD_ALARM_129_myControl(Beckhoff)', 0, 0, 510, N'C         ')
--,
--(130, N'High level alarm on analog level P1', 10, N'FIELD_ALARM_130_myControl(Beckhoff)', 0, 0, 511, N'C         ')
--,
--(131, N'High level alarm on analog level P2', 10, N'FIELD_ALARM_131_myControl(Beckhoff)', 0, 0, 512, N'C         ')
--,
--(132, N'High level alarm on analog level P3', 10, N'FIELD_ALARM_132_myControl(Beckhoff)', 0, 0, 513, N'C         ')
--,
--(133, N'High level alarm on analog level P4', 10, N'FIELD_ALARM_133_myControl(Beckhoff)', 0, 0, 514, N'C         ')
--,
--(134, N'High level alarm on analog level P5', 10, N'FIELD_ALARM_134_myControl(Beckhoff)', 0, 0, 515, N'C         ')
--,
--(135, N'High level alarm on analog level P6', 10, N'FIELD_ALARM_135_myControl(Beckhoff)', 0, 0, 516, N'C         ')
--,
--(136, N'High level alarm on analog level P7', 10, N'FIELD_ALARM_136_myControl(Beckhoff)', 0, 0, 517, N'C         ')
--,
--(137, N'High level alarm on analog level P8', 10, N'FIELD_ALARM_137_myControl(Beckhoff)', 0, 0, 518, N'C         ')
--,
--(138, N'High level alarm on analog level P9', 10, N'FIELD_ALARM_138_myControl(Beckhoff)', 0, 0, 519, N'C         ')
--,
--(139, N'High level alarm on analog level P10', 10, N'FIELD_ALARM_139_myControl(Beckhoff)', 0, 0, 520, N'C         ')
--,
--(140, N'High level alarm on analog level P11', 10, N'FIELD_ALARM_140_myControl(Beckhoff)', 0, 0, 521, N'C         ')
--,
--(141, N'High level alarm on analog level P12', 10, N'FIELD_ALARM_141_myControl(Beckhoff)', 0, 0, 522, N'C         ')
--,
--(142, N'High level alarm on analog level P13', 10, N'FIELD_ALARM_142_myControl(Beckhoff)', 0, 0, 523, N'C         ')
--,
--(143, N'High level alarm on analog level P14', 10, N'FIELD_ALARM_143_myControl(Beckhoff)', 0, 0, 524, N'C         ')
--,
--(144, N'High level alarm on analog level ME1', 10, N'FIELD_ALARM_144_myControl(Beckhoff)', 0, 0, 525, N'C         ')
--,
--(145, N'High level alarm on analog level ME2', 10, N'FIELD_ALARM_145_myControl(Beckhoff)', 0, 0, 526, N'C         ')
--,
--(146, N'Smtp function error', 10, N'FIELD_ALARM_146_myControl(Beckhoff)', 0, 0, 527, N'C         ')
--,
--(147, N'Free', 10, N'FIELD_ALARM_147_myControl(Beckhoff)', 0, 0, 528, N'C         ')
--,
--(148, N'Program not finished', 10, N'FIELD_ALARM_148_myControl(Beckhoff)', 0, 0, 529, N'C         ')
--,
--(149, N'No valid program', 10, N'FIELD_ALARM_149_myControl(Beckhoff)', 0, 0, 530, N'C         ')
--,
--(150, N'TOM signal alarm', 10, N'FIELD_ALARM_150_myControl(Beckhoff)', 0, 0, 531, N'C         ')
--,
--(151, N'pH too low alarm', 10, N'FIELD_ALARM_151_myControl(Beckhoff)', 0, 0, 532, N'C         ')
--,
--(152, N'pH too high alarm', 10, N'FIELD_ALARM_152_myControl(Beckhoff)', 0, 0, 533, N'C         ')
--,
--(153, N'Temperature too low alarm', 10, N'FIELD_ALARM_153_myControl(Beckhoff)', 0, 0, 534, N'C         ')
--,
--(154, N'Flowswitch alarm', 10, N'FIELD_ALARM_154_myControl(Beckhoff)', 0, 0, 535, N'C         ')
--,
--(155, N'Free', 10, N'FIELD_ALARM_155_myControl(Beckhoff)', 0, 0, 536, N'C         ')





--SET	IDENTITY_INSERT	TCD.AlarmMaster	ON

--MERGE	TCD.AlarmMaster			AS			TARGET
--USING	@tempAlarmMaster		AS			SOURCE
--ON	TARGET.Id		=			SOURCE.Id
--WHEN	NOT MATCHED		THEN
--INSERT	( AlarmCode		,Description	,ControllerModelTypeId		,ResourceKey		,IsDefault		,IsDelete, Id, LastModifiedTime, WasherType)
--VALUES	(SOURCE.AlarmCode	,SOURCE.Description	 ,SOURCE.ControllerModelTypeId	,SOURCE.ResourceKey	,SOURCE.IsDefault	,SOURCE.IsDelete,SOURCE.Id,SOURCE.LastModifiedTime, SOURCE.WasherType);
--*/

--SET	IDENTITY_INSERT	[TCD].AlarmMaster	OFF
--END





--/* AlarmMachineMapping
--Identity: Id
--PRIMARY KEY: None
--FK:	None
--*/
--BEGIN
--SET			@TableName				=			'AlarmMachineMapping'
--PRINT @TableName

----Declare temp table variable to hold input data
--DECLARE	@tempAlarmMachineMapping			TABLE	(
--TempId					INT				IDENTITY(1, 1)
--, Id						INT				NOT NULL
--,AlarmCode				INT		NOT NULL
--,	MachineNumber		INT NULL
--,	ControllerModelId	INT	NULL
--,	ControllerTypeId	INT NULL
--,	DisplayOrder		SMALLINT	NULL
--, WasherType    nchar(10) NULL
--)

----Populate temp table variable with the input data
--INSERT	@tempAlarmMachineMapping	(
--Id, AlarmCode	,MachineNumber	,ControllerModelId	,ControllerTypeId	,DisplayOrder, WasherType)
--VALUES
-- (1, 0, NULL, 1, 1, NULL, N'G         ')
--,
--  (2, 0, NULL, 1, 2, NULL, N'G         ')
--,
--  (3, 1, 1, 1, 1, NULL, N'G         ')
--,
--  (4, 1, 1, 1, 2, NULL, N'G         ')
--,
--  (5, 2, 1, 1, 1, NULL, N'G         ')
--,
--  (6, 2, 1, 1, 2, NULL, N'G         ')
--,
--  (7, 3, 1, 1, 1, NULL, N'G         ')
--,
--  (8, 3, 1, 1, 2, NULL, N'G         ')
--,
--  (9, 4, 1, 1, 1, NULL, N'G         ')
--,
--  (10, 4, 1, 1, 2, NULL, N'G         ')
--,
--  (11, 5, 1, 1, 1, NULL, N'G         ')
--,
--  (12, 5, 1, 1, 2, NULL, N'G         ')
--,
--  (13, 6, 1, 1, 1, NULL, N'G         ')
--,
--  (14, 6, 1, 1, 2, NULL, N'G         ')
--,
--  (15, 8, 1, 1, 1, NULL, N'G         ')
--,
--  (16, 8, 1, 1, 2, NULL, N'G         ')
--,
--  (17, 10, 2, 1, 1, NULL, N'G         ')
--,
--  (18, 10, 2, 1, 2, NULL, N'G         ')
--,
--  (19, 11, 2, 1, 1, NULL, N'G         ')
--,
--  (20, 11, 2, 1, 2, NULL, N'G         ')
--,
--  (21, 12, 2, 1, 1, NULL, N'G         ')
--,
--  (22, 12, 2, 1, 2, NULL, N'G         ')
--,
--  (23, 13, 2, 1, 1, NULL, N'G         ')
--,
--  (24, 13, 2, 1, 2, NULL, N'G         ')
--,
--  (25, 14, 2, 1, 1, NULL, N'G         ')
--,
--  (26, 14, 2, 1, 2, NULL, N'G         ')
--,
--  (27, 15, 2, 1, 1, NULL, N'G         ')
--,
--  (28, 15, 2, 1, 2, NULL, N'G         ')
--,
--  (29, 16, 2, 1, 1, NULL, N'G         ')
--,
--  (30, 16, 2, 1, 2, NULL, N'G         ')
--,
--  (31, 20, 3, 1, 1, NULL, N'G         ')
--,
--  (32, 20, 3, 1, 2, NULL, N'G         ')
--,
--  (33, 21, 3, 1, 1, NULL, N'G         ')
--,
--  (34, 21, 3, 1, 2, NULL, N'G         ')
--,
--  (35, 22, 3, 1, 1, NULL, N'G         ')
--,
--  (36, 22, 3, 1, 2, NULL, N'G         ')
--,
--  (37, 23, 3, 1, 1, NULL, N'G         ')
--,
--  (38, 23, 3, 1, 2, NULL, N'G         ')
--,
--  (39, 24, 3, 1, 1, NULL, N'G         ')
--,
--  (40, 24, 3, 1, 2, NULL, N'G         ')
--,
--  (41, 25, 3, 1, 1, NULL, N'G         ')
--,
--  (42, 25, 3, 1, 2, NULL, N'G         ')
--,
--  (43, 26, 3, 1, 1, NULL, N'G         ')
--,
--  (44, 26, 3, 1, 2, NULL, N'G         ')
--,
--  (45, 30, 4, 1, 1, NULL, N'G         ')
--,
--  (46, 30, 4, 1, 2, NULL, N'G         ')
--,
--  (47, 31, 4, 1, 1, NULL, N'G         ')
--,
--  (48, 31, 4, 1, 2, NULL, N'G         ')
--,
--  (49, 32, 4, 1, 1, NULL, N'G         ')
--,
--  (50, 32, 4, 1, 2, NULL, N'G         ')
--,
--  (51, 33, 4, 1, 1, NULL, N'G         ')
--,
--  (52, 33, 4, 1, 2, NULL, N'G         ')
--,
--  (53, 34, 4, 1, 1, NULL, N'G         ')
--,
--  (54, 34, 4, 1, 2, NULL, N'G         ')
--,
--  (55, 35, 4, 1, 1, NULL, N'G         ')
--,
--  (56, 35, 4, 1, 2, NULL, N'G         ')
--,
--  (57, 36, 4, 1, 1, NULL, N'G         ')
--,
--  (58, 36, 4, 1, 2, NULL, N'G         ')
--,
--  (59, 40, 5, 1, 1, NULL, N'G         ')
--,
--  (60, 40, 5, 1, 2, NULL, N'G         ')
--,
--  (61, 41, 5, 1, 1, NULL, N'G         ')
--,
--  (62, 41, 5, 1, 2, NULL, N'G         ')
--,
--  (63, 42, 5, 1, 1, NULL, N'G         ')
--,
--  (64, 42, 5, 1, 2, NULL, N'G         ')
--,
--  (65, 43, 5, 1, 1, NULL, N'G         ')
--,
--  (66, 43, 5, 1, 2, NULL, N'G         ')
--,
--  (67, 44, 5, 1, 1, NULL, N'G         ')
--,
--  (68, 44, 5, 1, 2, NULL, N'G         ')
--,
--  (69, 45, 5, 1, 1, NULL, N'G         ')
--,
--  (70, 45, 5, 1, 2, NULL, N'G         ')
--,
--  (71, 46, 5, 1, 1, NULL, N'G         ')
--,
--  (72, 46, 5, 1, 2, NULL, N'G         ')
--,
--  (73, 50, 6, 1, 1, NULL, N'G         ')
--,
--  (74, 50, 6, 1, 2, NULL, N'G         ')
--,
--  (75, 51, 6, 1, 1, NULL, N'G         ')
--,
--  (76, 51, 6, 1, 2, NULL, N'G         ')
--,
--  (77, 52, 6, 1, 1, NULL, N'G         ')
--,
--  (78, 52, 6, 1, 2, NULL, N'G         ')
--,
--  (79, 53, 6, 1, 1, NULL, N'G         ')
--,
--  (80, 53, 6, 1, 2, NULL, N'G         ')
--,
--  (81, 54, 6, 1, 1, NULL, N'G         ')
--,
--  (82, 54, 6, 1, 2, NULL, N'G         ')
--,
--  (83, 55, 6, 1, 1, NULL, N'G         ')
--,
--  (84, 55, 6, 1, 2, NULL, N'G         ')
--,
--  (85, 56, 6, 1, 1, NULL, N'G         ')
--,
--  (86, 56, 6, 1, 2, NULL, N'G         ')
--,
--  (87, 60, 7, 1, 1, NULL, N'G         ')
--,
--  (88, 60, 7, 1, 2, NULL, N'G         ')
--,
--  (89, 61, 7, 1, 1, NULL, N'G         ')
--,
--  (90, 61, 7, 1, 2, NULL, N'G         ')
--,
--  (91, 62, 7, 1, 1, NULL, N'G         ')
--,
--  (92, 62, 7, 1, 2, NULL, N'G         ')
--,
--  (93, 63, 7, 1, 1, NULL, N'G         ')
--,
--  (94, 63, 7, 1, 2, NULL, N'G         ')
--,
--  (95, 64, 7, 1, 1, NULL, N'G         ')
--,
--  (96, 64, 7, 1, 2, NULL, N'G         ')
--,
--  (97, 65, 7, 1, 1, NULL, N'G         ')
--,
--  (98, 65, 7, 1, 2, NULL, N'G         ')
--,
--  (99, 66, 7, 1, 1, NULL, N'G         ')
--,
--  (100, 66, 7, 1, 2, NULL, N'G         ')
--,
--  (101, 70, 8, 1, 1, NULL, N'G         ')
--,
--  (102, 70, 8, 1, 2, NULL, N'G         ')
--,
--  (103, 71, 8, 1, 1, NULL, N'G         ')
--,
--  (104, 71, 8, 1, 2, NULL, N'G         ')
--,
--  (105, 72, 8, 1, 1, NULL, N'G         ')
--,
--  (106, 72, 8, 1, 2, NULL, N'G         ')
--,
--  (107, 73, 8, 1, 1, NULL, N'G         ')
--,
--  (108, 73, 8, 1, 2, NULL, N'G         ')
--,
--  (109, 74, 8, 1, 1, NULL, N'G         ')
--,
--  (110, 74, 8, 1, 2, NULL, N'G         ')
--,
--  (111, 75, 8, 1, 1, NULL, N'G         ')
--,
--  (112, 75, 8, 1, 2, NULL, N'G         ')
--,
--  (113, 76, 8, 1, 1, NULL, N'G         ')
--,
--  (114, 76, 8, 1, 2, NULL, N'G         ')
--,
--  (115, 80, 9, 1, 1, NULL, N'G         ')
--,
--  (116, 80, 9, 1, 2, NULL, N'G         ')
--,
--  (117, 81, 9, 1, 1, NULL, N'G         ')
--,
--  (118, 81, 9, 1, 2, NULL, N'G         ')
--,
--  (119, 82, 9, 1, 1, NULL, N'G         ')
--,
--  (120, 82, 9, 1, 2, NULL, N'G         ')
--,
--  (121, 83, 9, 1, 1, NULL, N'G         ')
--,
--  (122, 83, 9, 1, 2, NULL, N'G         ')
--,
--  (123, 84, 9, 1, 1, NULL, N'G         ')
--,
--  (124, 84, 9, 1, 2, NULL, N'G         ')
--,
--  (125, 85, 9, 1, 1, NULL, N'G         ')
--,
--  (126, 85, 9, 1, 2, NULL, N'G         ')
--,
--  (127, 86, 9, 1, 1, NULL, N'G         ')
--,
--  (128, 86, 9, 1, 2, NULL, N'G         ')
--,
--  (129, 90, 10, 1, 1, NULL, N'G         ')
--,
--  (130, 90, 10, 1, 2, NULL, N'G         ')
--,
--  (131, 91, 10, 1, 1, NULL, N'G         ')
--,
--  (132, 91, 10, 1, 2, NULL, N'G         ')
--,
--  (133, 92, 10, 1, 1, NULL, N'G         ')
--,
--  (134, 92, 10, 1, 2, NULL, N'G         ')
--,
--  (135, 93, 10, 1, 1, NULL, N'G         ')
--,
--  (136, 93, 10, 1, 2, NULL, N'G         ')
--,
--  (137, 94, 10, 1, 1, NULL, N'G         ')
--,
--  (138, 94, 10, 1, 2, NULL, N'G         ')
--,
--  (139, 95, 10, 1, 1, NULL, N'G         ')
--,
--  (140, 95, 10, 1, 2, NULL, N'G         ')
--,
--  (141, 96, 10, 1, 1, NULL, N'G         ')
--,
--  (142, 96, 10, 1, 2, NULL, N'G         ')
--,
--  (143, 100, 11, 1, 1, NULL, N'G         ')
--,
--  (144, 100, 11, 1, 2, NULL, N'G         ')
--,
--  (145, 101, 11, 1, 1, NULL, N'G         ')
--,
--  (146, 101, 11, 1, 2, NULL, N'G         ')
--,
--  (147, 102, 11, 1, 1, NULL, N'G         ')
--,
--  (148, 102, 11, 1, 2, NULL, N'G         ')
--,
--  (149, 103, 11, 1, 1, NULL, N'G         ')
--,
--  (150, 103, 11, 1, 2, NULL, N'G         ')
--,
--  (151, 104, 11, 1, 1, NULL, N'G         ')
--,
--  (152, 104, 11, 1, 2, NULL, N'G         ')
--,
--  (153, 105, 11, 1, 1, NULL, N'G         ')
--,
--  (154, 105, 11, 1, 2, NULL, N'G         ')
--,
--  (155, 106, 11, 1, 1, NULL, N'G         ')
--,
--  (156, 106, 11, 1, 2, NULL, N'G         ')
--,
--  (157, 110, 12, 1, 1, NULL, N'G         ')
--,
--  (158, 110, 12, 1, 2, NULL, N'G         ')
--,
--  (159, 111, 12, 1, 1, NULL, N'G         ')
--,
--  (160, 111, 12, 1, 2, NULL, N'G         ')
--,
--  (161, 112, 12, 1, 1, NULL, N'G         ')
--,
--  (162, 112, 12, 1, 2, NULL, N'G         ')
--,
--  (163, 113, 12, 1, 1, NULL, N'G         ')
--,
--  (164, 113, 12, 1, 2, NULL, N'G         ')
--,
--  (165, 114, 12, 1, 1, NULL, N'G         ')
--,
--  (166, 114, 12, 1, 2, NULL, N'G         ')
--,
--  (167, 115, 12, 1, 1, NULL, N'G         ')
--,
--  (168, 115, 12, 1, 2, NULL, N'G         ')
--,
--  (169, 116, 12, 1, 1, NULL, N'G         ')
--,
--  (170, 116, 12, 1, 2, NULL, N'G         ')
--,
--  (171, 121, NULL, 1, 1, NULL, N'G         ')
--,
--  (172, 121, NULL, 1, 2, NULL, N'G         ')
--,
--  (173, 122, NULL, 1, 1, NULL, N'G         ')
--,
--  (174, 123, NULL, 1, 1, NULL, N'G         ')
--,
--  (175, 123, NULL, 1, 2, NULL, N'G         ')
--,
--  (176, 124, NULL, 1, 1, NULL, N'G         ')
--,
--  (177, 124, NULL, 1, 2, NULL, N'G         ')
--,
--  (178, 135, NULL, 1, 1, NULL, N'G         ')
--,
--  (179, 136, NULL, 1, 1, NULL, N'G         ')
--,
--  (180, 136, NULL, 1, 2, NULL, N'G         ')
--,
--  (181, 137, NULL, 1, 1, NULL, N'G         ')
--,
--  (182, 137, NULL, 1, 2, NULL, N'G         ')
--,
--  (183, 138, NULL, 1, 1, NULL, N'G         ')
--,
--  (184, 138, NULL, 1, 2, NULL, N'G         ')
--,
--  (185, 139, NULL, 1, 1, NULL, N'G         ')
--,
--  (186, 139, NULL, 1, 2, NULL, N'G         ')
--,
--  (187, 140, NULL, 1, 1, NULL, N'G         ')
--,
--  (188, 140, NULL, 1, 2, NULL, N'G         ')
--,
--  (189, 141, NULL, 1, 1, NULL, N'G         ')
--,
--  (190, 141, NULL, 1, 2, NULL, N'G         ')
--,
--  (191, 142, 1, 1, 1, NULL, N'G         ')
--,
--  (192, 142, 1, 1, 2, NULL, N'G         ')
--,
--  (193, 143, 2, 1, 1, NULL, N'G         ')
--,
--  (194, 143, 2, 1, 2, NULL, N'G         ')
--,
--  (195, 144, 3, 1, 1, NULL, N'G         ')
--,
--  (196, 144, 3, 1, 2, NULL, N'G         ')
--,
--  (197, 145, 4, 1, 1, NULL, N'G         ')
--,
--  (198, 145, 4, 1, 2, NULL, N'G         ')
--,
--  (199, 146, 5, 1, 1, NULL, N'G         ')
--,
--  (200, 146, 5, 1, 2, NULL, N'G         ')
--,
--  (201, 147, 6, 1, 1, NULL, N'G         ')
--,
--  (202, 147, 6, 1, 2, NULL, N'G         ')
--,
--  (203, 148, 7, 1, 1, NULL, N'G         ')
--,
--  (204, 148, 7, 1, 2, NULL, N'G         ')
--,
--  (205, 149, 8, 1, 1, NULL, N'G         ')
--,
--  (206, 149, 8, 1, 2, NULL, N'G         ')
--,
--  (207, 150, 9, 1, 1, NULL, N'G         ')
--,
--  (208, 150, 9, 1, 2, NULL, N'G         ')
--,
--  (209, 151, 10, 1, 1, NULL, N'G         ')
--,
--  (210, 151, 10, 1, 2, NULL, N'G         ')
--,
--  (211, 152, 11, 1, 1, NULL, N'G         ')
--,
--  (212, 152, 11, 1, 2, NULL, N'G         ')
--,
--  (213, 153, 12, 1, 1, NULL, N'G         ')
--,
--  (214, 153, 12, 1, 2, NULL, N'G         ')
--,
--  (215, 154, NULL, 1, 1, NULL, N'G         ')
--,
--  (216, 154, NULL, 1, 2, NULL, N'G         ')
--,
--  (217, 155, 1, 1, 1, NULL, N'G         ')
--,
--  (218, 155, 1, 1, 2, NULL, N'G         ')
--,
--  (219, 156, 2, 1, 1, NULL, N'G         ')
--,
--  (220, 156, 2, 1, 2, NULL, N'G         ')
--,
--  (221, 157, 3, 1, 1, NULL, N'G         ')
--,
--  (222, 157, 3, 1, 2, NULL, N'G         ')
--,
--  (223, 158, 4, 1, 1, NULL, N'G         ')
--,
--  (224, 158, 4, 1, 2, NULL, N'G         ')
--,
--  (225, 159, 5, 1, 1, NULL, N'G         ')
--,
--  (226, 159, 5, 1, 2, NULL, N'G         ')
--,
--  (227, 160, 6, 1, 1, NULL, N'G         ')
--,
--  (228, 160, 6, 1, 2, NULL, N'G         ')
--,
--  (229, 161, 7, 1, 1, NULL, N'G         ')
--,
--  (230, 161, 7, 1, 2, NULL, N'G         ')
--,
--  (231, 162, 8, 1, 1, NULL, N'G         ')
--,
--  (232, 162, 8, 1, 2, NULL, N'G         ')
--,
--  (233, 163, 9, 1, 1, NULL, N'G         ')
--,
--  (234, 163, 9, 1, 2, NULL, N'G         ')
--,
--  (235, 164, 10, 1, 1, NULL, N'G         ')
--,
--  (236, 164, 10, 1, 2, NULL, N'G         ')
--,
--  (237, 165, 11, 1, 1, NULL, N'G         ')
--,
--  (238, 165, 11, 1, 2, NULL, N'G         ')
--,
--  (239, 166, 12, 1, 1, NULL, N'G         ')
--,
--  (240, 166, 12, 1, 2, NULL, N'G         ')
--,
--  (241, 168, NULL, 1, 1, NULL, N'G         ')
--,
--  (242, 168, NULL, 1, 2, NULL, N'G         ')
--,
--  (243, 169, NULL, 1, 1, NULL, N'G         ')
--,
--  (244, 169, NULL, 1, 2, NULL, N'G         ')
--,
--  (245, 170, NULL, 1, 1, NULL, N'G         ')
--,
--  (246, 170, NULL, 1, 2, NULL, N'G         ')
--,
--  (247, 175, NULL, 1, 1, NULL, N'G         ')
--,
--  (248, 175, NULL, 1, 2, NULL, N'G         ')
--,
--  (249, 180, NULL, 1, 1, NULL, N'G         ')
--,
--  (250, 180, NULL, 1, 2, NULL, N'G         ')
--,
--  (251, 185, NULL, 1, 1, NULL, N'G         ')
--,
--  (252, 185, NULL, 1, 2, NULL, N'G         ')
--,
--  (253, 186, NULL, 3, 2, NULL, N'G         ')
--,
--  (254, 187, NULL, 3, 2, NULL, N'G         ')
--,
--  (255, 188, NULL, 3, 2, NULL, N'G         ')
--,
--  (256, 189, NULL, 3, 2, NULL, N'G         ')
--,
--  (257, 190, NULL, 3, 2, NULL, N'G         ')
--,
--  (258, 191, NULL, 3, 2, NULL, N'G         ')
--,
--  (259, 192, NULL, 3, 2, NULL, N'G         ')
--,
--  (260, 193, NULL, 3, 2, NULL, N'G         ')
--,
--  (261, 194, NULL, 3, 2, NULL, N'G         ')
--,
--  (262, 195, NULL, 3, 2, NULL, N'G         ')
--,
--  (263, 196, NULL, 3, 2, NULL, N'G         ')
--,
--  (264, 197, NULL, 3, 2, NULL, N'G         ')
--,
--  (265, 198, NULL, 3, 2, NULL, N'G         ')
--,
--  (266, 199, NULL, 3, 2, NULL, N'G         ')
--,
--  (267, 200, NULL, 3, 2, NULL, N'G         ')
--,
--  (268, 201, NULL, 3, 2, NULL, N'G         ')
--,
--  (269, 202, NULL, 1, 1, NULL, N'G         ')
--,
--  (270, 7, NULL, 1, 1, NULL, N'G         ')
--,
--  (271, 7, NULL, 1, 2, NULL, N'G         ')
--,
--  (272, 171, NULL, 1, 1, NULL, N'G         ')
--,
--  (273, 171, NULL, 1, 2, NULL, N'G         ')
--,
--  (274, 999, NULL, 1, 2, NULL, N'G         ')
--,
--  (275, 999, NULL, 3, 2, NULL, N'G         ')
--,
--  (276, 1234, NULL, 3, 2, NULL, N'G         ')
--,
--  (277, 211, 1, 1, 2, NULL, N'G         ')
--,
--  (278, 212, 2, 1, 2, NULL, N'G         ')
--,
--  (279, 213, 3, 1, 2, NULL, N'G         ')
--,
--  (280, 214, 4, 1, 2, NULL, N'G         ')
--,
--  (281, 215, 5, 1, 2, NULL, N'G         ')
--,
--  (282, 216, 6, 1, 2, NULL, N'G         ')
--,
--  (283, 217, 7, 1, 2, NULL, N'G         ')
--,
--  (284, 218, 8, 1, 2, NULL, N'G         ')
--,
--  (285, 219, 9, 1, 2, NULL, N'G         ')
--,
--  (286, 220, 10, 1, 2, NULL, N'G         ')
--,
--  (287, 221, 11, 1, 2, NULL, N'G         ')
--,
--  (288, 222, 12, 1, 2, NULL, N'G         ')
--,
--  (289, 223, 13, 1, 2, NULL, N'G         ')
--,
--  (290, 224, 14, 1, 2, NULL, N'G         ')
--,
--  (291, 225, 15, 1, 2, NULL, N'G         ')
--,
--  (292, 226, 16, 1, 2, NULL, N'G         ')
--,
--  (293, 240, 1, 1, 2, NULL, N'G         ')
--,
--  (294, 241, 2, 1, 2, NULL, N'G         ')
--,
--  (295, 242, 3, 1, 2, NULL, N'G         ')
--,
--  (296, 243, 4, 1, 2, NULL, N'G         ')
--,
--  (297, 244, 5, 1, 2, NULL, N'G         ')
--,
--  (298, 245, 6, 1, 2, NULL, N'G         ')
--,
--  (299, 246, 7, 1, 2, NULL, N'G         ')
--,
--  (300, 247, 8, 1, 2, NULL, N'G         ')
--,
--  (301, 248, 9, 1, 2, NULL, N'G         ')
--,
--  (302, 249, 10, 1, 2, NULL, N'G         ')
--,
--  (303, 250, 11, 1, 2, NULL, N'G         ')
--,
--  (304, 251, 12, 1, 2, NULL, N'G         ')
--,
--  (305, 252, 13, 1, 2, NULL, N'G         ')
--,
--  (306, 253, 14, 1, 2, NULL, N'G         ')
--,
--  (307, 254, 15, 1, 2, NULL, N'G         ')
--,
--  (308, 255, 16, 1, 2, NULL, N'G         ')
--,
--  (309, 300, 13, 1, 2, NULL, N'G         ')
--,
--  (310, 301, 13, 1, 2, NULL, N'G         ')
--,
--  (311, 302, 13, 1, 2, NULL, N'G         ')
--,
--  (312, 303, 13, 1, 2, NULL, N'G         ')
--,
--  (313, 304, 13, 1, 2, NULL, N'G         ')
--,
--  (314, 305, 13, 1, 2, NULL, N'G         ')
--,
--  (315, 306, 13, 1, 2, NULL, N'G         ')
--,
--  (316, 310, 14, 1, 2, NULL, N'G         ')
--,
--  (317, 311, 14, 1, 2, NULL, N'G         ')
--,
--  (318, 312, 14, 1, 2, NULL, N'G         ')
--,
--  (319, 313, 14, 1, 2, NULL, N'G         ')
--,
--  (320, 314, 14, 1, 2, NULL, N'G         ')
--,
--  (321, 315, 14, 1, 2, NULL, N'G         ')
--,
--  (322, 316, 14, 1, 2, NULL, N'G         ')
--,
--  (323, 320, 15, 1, 2, NULL, N'G         ')
--,
--  (324, 321, 15, 1, 2, NULL, N'G         ')
--,
--  (325, 322, 15, 1, 2, NULL, N'G         ')
--,
--  (326, 323, 15, 1, 2, NULL, N'G         ')
--,
--  (327, 324, 15, 1, 2, NULL, N'G         ')
--,
--  (328, 325, 15, 1, 2, NULL, N'G         ')
--,
--  (329, 326, 15, 1, 2, NULL, N'G         ')
--,
--  (330, 330, 16, 1, 2, NULL, N'G         ')
--,
--  (331, 331, 16, 1, 2, NULL, N'G         ')
--,
--  (332, 332, 16, 1, 2, NULL, N'G         ')
--,
--  (333, 333, 16, 1, 2, NULL, N'G         ')
--,
--  (334, 334, 16, 1, 2, NULL, N'G         ')
--,
--  (335, 335, 16, 1, 2, NULL, N'G         ')
--,
--  (336, 336, 16, 1, 2, NULL, N'G         ')
--,
--  (337, 350, 13, 1, 2, NULL, N'G         ')
--,
--  (338, 351, 14, 1, 2, NULL, N'G         ')
--,
--  (339, 352, 15, 1, 2, NULL, N'G         ')
--,
--  (340, 353, 16, 1, 2, NULL, N'G         ')
--,
--  (341, 355, 13, 1, 2, NULL, N'G         ')
--,
--  (342, 356, 14, 1, 2, NULL, N'G         ')
--,
--  (343, 357, 15, 1, 2, NULL, N'G         ')
--,
--  (344, 358, 16, 1, 2, NULL, N'G         ')
--,
--  (359, 1, NULL, 7, 2, NULL, N'T         ')
--,
--  (360, 2, NULL, 7, 2, NULL, N'T         ')
--,
--  (361, 3, NULL, 7, 2, NULL, N'T         ')
--,
--  (362, 4, NULL, 7, 2, NULL, N'T         ')
--,
--  (363, 5, NULL, 7, 2, NULL, N'T         ')
--,
--  (364, 6, NULL, 7, 2, NULL, N'T         ')
--,
--  (365, 7, NULL, 7, 2, NULL, N'T         ')
--,
--  (366, 8, NULL, 7, 2, NULL, N'T         ')
--,
--  (367, 9, NULL, 7, 2, NULL, N'T         ')
--,
--  (368, 10, NULL, 7, 2, NULL, N'T         ')
--,
--  (369, 11, NULL, 7, 2, NULL, N'T         ')
--,
--  (370, 12, NULL, 7, 2, NULL, N'T         ')
--,
--  (371, 13, NULL, 7, 2, NULL, N'T         ')
--,
--  (372, 14, NULL, 7, 2, NULL, N'T         ')
--,
--  (373, 15, NULL, 7, 2, NULL, N'T         ')
--,
--  (374, 16, NULL, 7, 2, NULL, N'T         ')
--,
--  (375, 17, NULL, 7, 2, NULL, N'T         ')
--,
--  (376, 18, NULL, 7, 2, NULL, N'T         ')
--,
--  (377, 19, NULL, 7, 2, NULL, N'T         ')
--,
--  (378, 20, NULL, 7, 2, NULL, N'T         ')
--,
--  (379, 21, NULL, 7, 2, NULL, N'T         ')
--,
--  (380, 22, NULL, 7, 2, NULL, N'T         ')
--,
--  (381, 23, NULL, 7, 2, NULL, N'T         ')
--,
--  (382, 24, NULL, 7, 2, NULL, N'T         ')
--,
--  (383, 25, NULL, 7, 2, NULL, N'T         ')
--,
--  (384, 26, NULL, 7, 2, NULL, N'T         ')
--,
--  (385, 27, NULL, 7, 2, NULL, N'T         ')
--,
--  (386, 28, NULL, 7, 2, NULL, N'T         ')
--,
--  (387, 29, NULL, 7, 2, NULL, N'T         ')
--,
--  (388, 30, NULL, 7, 2, NULL, N'T         ')
--,
--  (389, 31, NULL, 7, 2, NULL, N'T         ')
--,
--  (390, 32, NULL, 7, 2, NULL, N'T         ')
--,
--  (391, 33, NULL, 7, 2, NULL, N'T         ')
--,
--  (392, 34, NULL, 7, 2, NULL, N'T         ')
--,
--  (393, 35, NULL, 7, 2, NULL, N'T         ')
--,
--  (394, 36, NULL, 7, 2, NULL, N'T         ')
--,
--  (395, 37, NULL, 7, 2, NULL, N'T         ')
--,
--  (396, 38, NULL, 7, 2, NULL, N'T         ')
--,
--  (397, 39, NULL, 7, 2, NULL, N'T         ')
--,
--  (398, 40, NULL, 7, 2, NULL, N'T         ')
--,
--  (399, 41, NULL, 7, 2, NULL, N'T         ')
--,
--  (400, 42, NULL, 7, 2, NULL, N'T         ')
--,
--  (401, 43, NULL, 7, 2, NULL, N'T         ')
--,
--  (402, 44, NULL, 7, 2, NULL, N'T         ')
--,
--  (403, 45, NULL, 7, 2, NULL, N'T         ')
--,
--  (404, 46, NULL, 7, 2, NULL, N'T         ')
--,
--  (405, 47, NULL, 7, 2, NULL, N'T         ')
--,
--  (406, 48, NULL, 7, 2, NULL, N'T         ')
--,
--  (407, 49, NULL, 7, 2, NULL, N'T         ')
--,
--  (408, 50, NULL, 7, 2, NULL, N'T         ')
--,
--  (409, 51, NULL, 7, 2, NULL, N'T         ')
--,
--  (410, 52, NULL, 7, 2, NULL, N'T         ')
--,
--  (411, 53, NULL, 7, 2, NULL, N'T         ')
--,
--  (412, 54, NULL, 7, 2, NULL, N'T         ')
--,
--  (413, 55, NULL, 7, 2, NULL, N'T         ')
--,
--  (414, 56, NULL, 7, 2, NULL, N'T         ')
--,
--  (415, 57, NULL, 7, 2, NULL, N'T         ')
--,
--  (416, 58, NULL, 7, 2, NULL, N'T         ')
--,
--  (417, 59, NULL, 7, 2, NULL, N'T         ')
--,
--  (418, 60, NULL, 7, 2, NULL, N'T         ')
--,
--  (419, 61, NULL, 7, 2, NULL, N'T         ')
--,
--  (420, 62, NULL, 7, 2, NULL, N'T         ')
--,
--  (421, 63, NULL, 7, 2, NULL, N'T         ')
--,
--  (422, 64, NULL, 7, 2, NULL, N'T         ')
--,
--  (423, 65, NULL, 7, 2, NULL, N'T         ')
--,
--  (424, 66, NULL, 7, 2, NULL, N'T         ')
--,
--  (425, 67, NULL, 7, 2, NULL, N'T         ')
--,
--  (426, 68, NULL, 7, 2, NULL, N'T         ')
--,
--  (427, 69, NULL, 7, 2, NULL, N'T         ')
--,
--  (428, 70, NULL, 7, 2, NULL, N'T         ')
--,
--  (429, 71, NULL, 7, 2, NULL, N'T         ')
--,
--  (430, 72, NULL, 7, 2, NULL, N'T         ')
--,
--  (431, 73, NULL, 7, 2, NULL, N'T         ')
--,
--  (432, 74, NULL, 7, 2, NULL, N'T         ')
--,
--  (433, 75, NULL, 7, 2, NULL, N'T         ')
--,
--  (434, 76, NULL, 7, 2, NULL, N'T         ')
--,
--  (435, 77, NULL, 7, 2, NULL, N'T         ')
--,
--  (436, 78, NULL, 7, 2, NULL, N'T         ')
--,
--  (437, 79, NULL, 7, 2, NULL, N'T         ')
--,
--  (438, 80, NULL, 7, 2, NULL, N'T         ')
--,
--  (439, 81, NULL, 7, 2, NULL, N'T         ')
--,
--  (440, 82, NULL, 7, 2, NULL, N'T         ')
--,
--  (441, 83, NULL, 7, 2, NULL, N'T         ')
--,
--  (442, 84, NULL, 7, 2, NULL, N'T         ')
--,
--  (443, 85, NULL, 7, 2, NULL, N'T         ')
--,
--  (444, 86, NULL, 7, 2, NULL, N'T         ')
--,
--  (445, 87, NULL, 7, 2, NULL, N'T         ')
--,
--  (446, 88, NULL, 7, 2, NULL, N'T         ')
--,
--  (447, 89, NULL, 7, 2, NULL, N'T         ')
--,
--  (448, 90, NULL, 7, 2, NULL, N'T         ')
--,
--  (449, 91, NULL, 7, 2, NULL, N'T         ')
--,
--  (450, 92, NULL, 7, 2, NULL, N'T         ')
--,
--  (451, 93, NULL, 7, 2, NULL, N'T         ')
--,
--  (452, 94, NULL, 7, 2, NULL, N'T         ')
--,
--  (453, 95, NULL, 7, 2, NULL, N'T         ')
--,
--  (454, 96, NULL, 7, 2, NULL, N'T         ')
--,
--  (455, 97, NULL, 7, 2, NULL, N'T         ')
--,
--  (456, 98, NULL, 7, 2, NULL, N'T         ')
--,
--  (457, 99, NULL, 7, 2, NULL, N'T         ')
--,
--  (458, 100, NULL, 7, 2, NULL, N'T         ')
--,
--  (459, 101, NULL, 7, 2, NULL, N'T         ')
--,
--  (460, 102, NULL, 7, 2, NULL, N'T         ')
--,
--  (461, 103, NULL, 7, 2, NULL, N'T         ')
--,
--  (462, 104, NULL, 7, 2, NULL, N'T         ')
--,
--  (463, 105, NULL, 7, 2, NULL, N'T         ')
--,
--  (464, 106, NULL, 7, 2, NULL, N'T         ')
--,
--  (465, 107, NULL, 7, 2, NULL, N'T         ')
--,
--  (466, 108, NULL, 7, 2, NULL, N'T         ')
--,
--  (467, 109, NULL, 7, 2, NULL, N'T         ')
--,
--  (468, 110, NULL, 7, 2, NULL, N'T         ')
--,
--  (469, 111, NULL, 7, 2, NULL, N'T         ')
--,
--  (470, 112, NULL, 7, 2, NULL, N'T         ')
--,
--  (471, 113, NULL, 7, 2, NULL, N'T         ')
--,
--  (472, 114, NULL, 7, 2, NULL, N'T         ')
--,
--  (473, 115, NULL, 7, 2, NULL, N'T         ')
--,
--  (474, 116, NULL, 7, 2, NULL, N'T         ')
--,
--  (475, 117, NULL, 7, 2, NULL, N'T         ')
--,
--  (476, 118, NULL, 7, 2, NULL, N'T         ')
--,
--  (477, 119, NULL, 7, 2, NULL, N'T         ')
--,
--  (478, 120, NULL, 7, 2, NULL, N'T         ')
--,
--  (479, 121, NULL, 7, 2, NULL, N'T         ')
--,
--  (480, 122, NULL, 7, 2, NULL, N'T         ')
--,
--  (481, 123, NULL, 7, 2, NULL, N'T         ')
--,
--  (482, 124, NULL, 7, 2, NULL, N'T         ')
--,
--  (483, 125, NULL, 7, 2, NULL, N'T         ')
--,
--  (484, 126, NULL, 7, 2, NULL, N'T         ')
--,
--  (485, 127, NULL, 7, 2, NULL, N'T         ')
--,
--  (486, 128, NULL, 7, 2, NULL, N'T         ')
--,
--  (487, 129, NULL, 7, 2, NULL, N'T         ')
--,
--  (488, 130, NULL, 7, 2, NULL, N'T         ')
--,
--  (489, 131, NULL, 7, 2, NULL, N'T         ')
--,
--  (490, 132, NULL, 7, 2, NULL, N'T         ')
--,
--  (491, 133, NULL, 7, 2, NULL, N'T         ')
--,
--  (492, 134, NULL, 7, 2, NULL, N'T         ')
--,
--  (493, 135, NULL, 7, 2, NULL, N'T         ')
--,
--  (494, 136, NULL, 7, 2, NULL, N'T         ')
--,
--  (495, 137, NULL, 7, 2, NULL, N'T         ')
--,
--  (496, 138, NULL, 7, 2, NULL, N'T         ')
--,
--  (497, 139, NULL, 7, 2, NULL, N'T         ')
--,
--  (498, 140, NULL, 7, 2, NULL, N'T         ')
--,
--  (499, 141, NULL, 7, 2, NULL, N'T         ')
--,
--  (500, 142, NULL, 7, 2, NULL, N'T         ')
--,
--  (501, 143, NULL, 7, 2, NULL, N'T         ')
--,
--  (502, 144, NULL, 7, 2, NULL, N'T         ')
--,
--  (503, 145, NULL, 7, 2, NULL, N'T         ')
--,
--  (504, 146, NULL, 7, 2, NULL, N'T         ')
--,
--  (505, 147, NULL, 7, 2, NULL, N'T         ')
--,
--  (506, 148, NULL, 7, 2, NULL, N'T         ')
--,
--  (507, 149, NULL, 7, 2, NULL, N'T         ')
--,
--  (508, 150, NULL, 7, 2, NULL, N'T         ')
--,
--  (509, 151, NULL, 7, 2, NULL, N'T         ')
--,
--  (510, 152, NULL, 7, 2, NULL, N'T         ')
--,
--  (511, 153, NULL, 7, 2, NULL, N'T         ')
--,
--  (512, 154, NULL, 7, 2, NULL, N'T         ')
--,
--  (513, 155, NULL, 7, 2, NULL, N'T         ')
--,
--  (514, 156, NULL, 7, 2, NULL, N'T         ')
--,
--  (515, 157, NULL, 7, 2, NULL, N'T         ')
--,
--  (516, 158, NULL, 7, 2, NULL, N'T         ')
--,
--  (517, 159, NULL, 7, 2, NULL, N'T         ')
--,
--  (518, 160, NULL, 7, 2, NULL, N'T         ')
--,
--  (519, 161, NULL, 7, 2, NULL, N'T         ')
--,
--  (520, 162, NULL, 7, 2, NULL, N'T         ')
--,
--  (521, 1, NULL, 7, 2, NULL, N'C         ')
--,
--  (522, 2, NULL, 7, 2, NULL, N'C         ')
--,
--  (523, 3, NULL, 7, 2, NULL, N'C         ')
--,
--  (524, 4, NULL, 7, 2, NULL, N'C         ')
--,
--  (525, 5, NULL, 7, 2, NULL, N'C         ')
--,
--  (526, 6, NULL, 7, 2, NULL, N'C         ')
--,
--  (527, 7, NULL, 7, 2, NULL, N'C         ')
--,
--  (528, 8, NULL, 7, 2, NULL, N'C         ')
--,
--  (529, 9, NULL, 7, 2, NULL, N'C         ')
--,
--  (530, 10, NULL, 7, 2, NULL, N'C         ')
--,
--  (531, 11, NULL, 7, 2, NULL, N'C         ')
--,
--  (532, 12, NULL, 7, 2, NULL, N'C         ')
--,
--  (533, 13, NULL, 7, 2, NULL, N'C         ')
--,
--  (534, 14, NULL, 7, 2, NULL, N'C         ')
--,
--  (535, 15, NULL, 7, 2, NULL, N'C         ')
--,
--  (536, 16, NULL, 7, 2, NULL, N'C         ')
--,
--  (537, 17, NULL, 7, 2, NULL, N'C         ')
--,
--  (538, 18, NULL, 7, 2, NULL, N'C         ')
--,
--  (539, 19, NULL, 7, 2, NULL, N'C         ')
--,
--  (540, 20, NULL, 7, 2, NULL, N'C         ')
--,
--  (541, 21, NULL, 7, 2, NULL, N'C         ')
--,
--  (542, 22, NULL, 7, 2, NULL, N'C         ')
--,
--  (543, 23, NULL, 7, 2, NULL, N'C         ')
--,
--  (544, 24, NULL, 7, 2, NULL, N'C         ')
--,
--  (545, 25, NULL, 7, 2, NULL, N'C         ')
--,
--  (546, 26, NULL, 7, 2, NULL, N'C         ')
--,
--  (547, 27, NULL, 7, 2, NULL, N'C         ')
--,
--  (548, 28, NULL, 7, 2, NULL, N'C         ')
--,
--  (549, 29, NULL, 7, 2, NULL, N'C         ')
--,
--  (550, 30, NULL, 7, 2, NULL, N'C         ')
--,
--  (551, 31, NULL, 7, 2, NULL, N'C         ')
--,
--  (552, 32, NULL, 7, 2, NULL, N'C         ')
--,
--  (553, 33, NULL, 7, 2, NULL, N'C         ')
--,
--  (554, 34, NULL, 7, 2, NULL, N'C         ')
--,
--  (555, 35, NULL, 7, 2, NULL, N'C         ')
--,
--  (556, 36, NULL, 7, 2, NULL, N'C         ')
--,
--  (557, 37, NULL, 7, 2, NULL, N'C         ')
--,
--  (558, 38, NULL, 7, 2, NULL, N'C         ')
--,
--  (559, 39, NULL, 7, 2, NULL, N'C         ')
--,
--  (560, 40, NULL, 7, 2, NULL, N'C         ')
--,
--  (561, 41, NULL, 7, 2, NULL, N'C         ')
--,
--  (562, 42, NULL, 7, 2, NULL, N'C         ')
--,
--  (563, 43, NULL, 7, 2, NULL, N'C         ')
--,
--  (564, 44, NULL, 7, 2, NULL, N'C         ')
--,
--  (565, 45, NULL, 7, 2, NULL, N'C         ')
--,
--  (566, 46, NULL, 7, 2, NULL, N'C         ')
--,
--  (567, 47, NULL, 7, 2, NULL, N'C         ')
--,
--  (568, 48, NULL, 7, 2, NULL, N'C         ')
--,
--  (569, 49, NULL, 7, 2, NULL, N'C         ')
--,
--  (570, 50, NULL, 7, 2, NULL, N'C         ')
--,
--  (571, 51, NULL, 7, 2, NULL, N'C         ')
--,
--  (572, 52, NULL, 7, 2, NULL, N'C         ')
--,
--  (573, 53, NULL, 7, 2, NULL, N'C         ')
--,
--  (574, 54, NULL, 7, 2, NULL, N'C         ')
--,
--  (575, 55, NULL, 7, 2, NULL, N'C         ')
--,
--  (576, 56, NULL, 7, 2, NULL, N'C         ')
--,
--  (577, 57, NULL, 7, 2, NULL, N'C         ')
--,
--  (578, 58, NULL, 7, 2, NULL, N'C         ')
--,
--  (579, 59, NULL, 7, 2, NULL, N'C         ')
--,
--  (580, 60, NULL, 7, 2, NULL, N'C         ')
--,
--  (581, 61, NULL, 7, 2, NULL, N'C         ')
--,
--  (582, 62, NULL, 7, 2, NULL, N'C         ')
--,
--  (583, 63, NULL, 7, 2, NULL, N'C         ')
--,
--  (584, 64, NULL, 7, 2, NULL, N'C         ')
--,
--  (585, 65, NULL, 7, 2, NULL, N'C         ')
--,
--  (586, 66, NULL, 7, 2, NULL, N'C         ')
--,
--  (587, 67, NULL, 7, 2, NULL, N'C         ')
--,
--  (588, 68, NULL, 7, 2, NULL, N'C         ')
--,
--  (589, 69, NULL, 7, 2, NULL, N'C         ')
--,
--  (590, 70, NULL, 7, 2, NULL, N'C         ')
--,
--  (591, 71, NULL, 7, 2, NULL, N'C         ')
--,
--  (592, 72, NULL, 7, 2, NULL, N'C         ')
--,
--  (593, 73, NULL, 7, 2, NULL, N'C         ')
--,
--  (594, 74, NULL, 7, 2, NULL, N'C         ')
--,
--  (595, 75, NULL, 7, 2, NULL, N'C         ')
--,
--  (596, 76, NULL, 7, 2, NULL, N'C         ')
--,
--  (597, 77, NULL, 7, 2, NULL, N'C         ')
--,
--  (598, 78, NULL, 7, 2, NULL, N'C         ')
--,
--  (599, 79, NULL, 7, 2, NULL, N'C         ')
--,
--  (600, 80, NULL, 7, 2, NULL, N'C         ')
--,
--  (601, 81, NULL, 7, 2, NULL, N'C         ')
--,
--  (602, 82, NULL, 7, 2, NULL, N'C         ')
--,
--  (603, 83, NULL, 7, 2, NULL, N'C         ')
--,
--  (604, 84, NULL, 7, 2, NULL, N'C         ')
--,
--  (605, 85, NULL, 7, 2, NULL, N'C         ')
--,
--  (606, 86, NULL, 7, 2, NULL, N'C         ')
--,
--  (607, 87, NULL, 7, 2, NULL, N'C         ')
--,
--  (608, 88, NULL, 7, 2, NULL, N'C         ')
--,
--  (609, 89, NULL, 7, 2, NULL, N'C         ')
--,
--  (610, 90, NULL, 7, 2, NULL, N'C         ')
--,
--  (611, 91, NULL, 7, 2, NULL, N'C         ')
--,
--  (612, 92, NULL, 7, 2, NULL, N'C         ')
--,
--  (613, 93, NULL, 7, 2, NULL, N'C         ')
--,
--  (614, 94, NULL, 7, 2, NULL, N'C         ')
--,
--  (615, 95, NULL, 7, 2, NULL, N'C         ')
--,
--  (616, 96, NULL, 7, 2, NULL, N'C         ')
--,
--  (617, 97, NULL, 7, 2, NULL, N'C         ')
--,
--  (618, 98, NULL, 7, 2, NULL, N'C         ')
--,
--  (619, 99, NULL, 7, 2, NULL, N'C         ')
--,
--  (620, 100, NULL, 7, 2, NULL, N'C         ')
--,
--  (621, 101, NULL, 7, 2, NULL, N'C         ')
--,
--  (622, 102, NULL, 7, 2, NULL, N'C         ')
--,
--  (623, 103, NULL, 7, 2, NULL, N'C         ')
--,
--  (624, 104, NULL, 7, 2, NULL, N'C         ')
--,
--  (625, 105, NULL, 7, 2, NULL, N'C         ')
--,
--  (626, 106, NULL, 7, 2, NULL, N'C         ')
--,
--  (627, 107, NULL, 7, 2, NULL, N'C         ')
--,
--  (628, 108, NULL, 7, 2, NULL, N'C         ')
--,
--  (629, 109, NULL, 7, 2, NULL, N'C         ')
--,
--  (630, 110, NULL, 7, 2, NULL, N'C         ')
--,
--  (631, 111, NULL, 7, 2, NULL, N'C         ')
--,
--  (632, 112, NULL, 7, 2, NULL, N'C         ')
--,
--  (633, 113, NULL, 7, 2, NULL, N'C         ')
--,
--  (634, 114, NULL, 7, 2, NULL, N'C         ')
--,
--  (635, 115, NULL, 7, 2, NULL, N'C         ')
--,
--  (636, 116, NULL, 7, 2, NULL, N'C         ')
--,
--  (637, 117, NULL, 7, 2, NULL, N'C         ')
--,
--  (638, 118, NULL, 7, 2, NULL, N'C         ')
--,
--  (639, 119, NULL, 7, 2, NULL, N'C         ')
--,
--  (640, 120, NULL, 7, 2, NULL, N'C         ')
--,
--  (641, 121, NULL, 7, 2, NULL, N'C         ')
--,
--  (642, 122, NULL, 7, 2, NULL, N'C         ')
--,
--  (643, 123, NULL, 7, 2, NULL, N'C         ')
--,
--  (644, 124, NULL, 7, 2, NULL, N'C         ')
--,
--  (645, 125, NULL, 7, 2, NULL, N'C         ')
--,
--  (646, 126, NULL, 7, 2, NULL, N'C         ')
--,
--  (647, 127, NULL, 7, 2, NULL, N'C         ')
--,
--  (648, 128, NULL, 7, 2, NULL, N'C         ')
--,
--  (649, 129, NULL, 7, 2, NULL, N'C         ')
--,
--  (650, 130, NULL, 7, 2, NULL, N'C         ')
--,
--  (651, 131, NULL, 7, 2, NULL, N'C         ')
--,
--  (652, 132, NULL, 7, 2, NULL, N'C         ')
--,
--  (653, 133, NULL, 7, 2, NULL, N'C         ')
--,
--  (654, 134, NULL, 7, 2, NULL, N'C         ')
--,
--  (655, 135, NULL, 7, 2, NULL, N'C         ')
--,
--  (656, 136, NULL, 7, 2, NULL, N'C         ')
--,
--  (657, 137, NULL, 7, 2, NULL, N'C         ')
--,
--  (658, 138, NULL, 7, 2, NULL, N'C         ')
--,
--  (659, 139, NULL, 7, 2, NULL, N'C         ')
--,
--  (660, 140, NULL, 7, 2, NULL, N'C         ')
--,
--  (661, 141, NULL, 7, 2, NULL, N'C         ')
--,
--  (662, 142, NULL, 7, 2, NULL, N'C         ')
--,
--  (663, 143, NULL, 7, 2, NULL, N'C         ')
--,
--  (664, 144, NULL, 7, 2, NULL, N'C         ')
--,
--  (665, 145, NULL, 7, 2, NULL, N'C         ')
--,
--  (666, 146, NULL, 7, 2, NULL, N'C         ')
--,
--  (667, 147, NULL, 7, 2, NULL, N'C         ')
--,
--  (668, 148, NULL, 7, 2, NULL, N'C         ')
--,
--  (669, 149, NULL, 7, 2, NULL, N'C         ')
--,
--  (670, 150, NULL, 7, 2, NULL, N'C         ')
--,
--  (671, 151, NULL, 7, 2, NULL, N'C         ')
--,
--  (672, 152, NULL, 7, 2, NULL, N'C         ')
--,
--  (673, 153, NULL, 7, 2, NULL, N'C         ')
--,
--  (674, 154, NULL, 7, 2, NULL, N'C         ')
--,
--  (675, 155, NULL, 7, 2, NULL, N'C         ')

--MERGE	TCD.AlarmMachineMapping			AS			TARGET
--USING	@tempAlarmMachineMapping		AS			SOURCE
--ON	TARGET.Id		=			SOURCE.Id
--WHEN	NOT MATCHED		THEN
--INSERT	(Id, AlarmCode		,MachineNumber	,ControllerModelId		,ControllerTypeId		,DisplayOrder, WasherType)
--VALUES	(SOURCE.Id,SOURCE.AlarmCode	,SOURCE.MachineNumber	 ,SOURCE.ControllerModelId	,SOURCE.ControllerTypeId	,SOURCE.DisplayOrder, SOURCE.WasherType);

--SET	IDENTITY_INSERT	[TCD].AlarmMachineMapping	OFF
--END





/*	RewashReason

Identity: RewashReasonId
PRIMARY KEY: RewashReasonId
FK:	None

Table is referenced by foreign key:	None

*/
BEGIN
SET			@TableName				=			'RewashReason'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempRewashReason			TABLE	(
TempId						INT				IDENTITY(1, 1)
,	RewashReasonId				INT				PRIMARY	KEY
,	[Description]				[VARCHAR](1000) NULL
)

----Populate temp table variable with the input data
INSERT	@tempRewashReason		(
RewashReasonId	,[Description]	)
VALUES	(1	,'Finishing'	)
,	(2	,'Washing'		)

MERGE	TCD.RewashReason		AS			TARGET
USING	@tempRewashReason		AS			SOURCE
ON	TARGET.RewashReasonId	=			SOURCE.RewashReasonId
WHEN	NOT MATCHED		THEN
INSERT	(RewashReasonId			,[Description],	IsDeleted)
VALUES	(SOURCE.RewashReasonId	,SOURCE.[Description],0	);
END





/*	DryerType

Identity: DryerTypeId
PRIMARY KEY: DryerTypeId
FK:	None

Table is referenced by foreign key:	None

*/
BEGIN
SET			@TableName				=			'DryerType'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempDryerType				TABLE	(
TempId						INT				IDENTITY(1, 1)
,	DryerTypeId					INT				PRIMARY	KEY
,	[Name]						[NVARCHAR](50)	NOT NULL
,	[Is_Deleted]				[BIT]			NOT	NULL	DEFAULT('FALSE')
)

--Populate temp table variable with the input data
INSERT	@tempDryerType		(
DryerTypeId	,[Name]	,Is_Deleted	)
VALUES	(1	,'DryerType 01'	,'FALSE'	)
,	(2	,'DryerType 02'	,'FALSE'	)
,	(3	,'DryerType 03'	,'FALSE'	)
,	(4	,'Others'	,'FALSE'	)
--the above seems to be sample data, unless actual is available... so, update when available...
--add entries here in the above format

SET		IDENTITY_INSERT		TCD.DryerType		ON

MERGE	TCD.DryerType			AS			TARGET
USING	@tempDryerType			AS			SOURCE
ON	TARGET.DryerTypeId		=			SOURCE.DryerTypeId
WHEN	NOT MATCHED		THEN
INSERT	(DryerTypeId		,[Name]			,Is_Deleted			)
VALUES	(SOURCE.DryerTypeId	,SOURCE.[Name]	,SOURCE.Is_Deleted	)

;
SET		IDENTITY_INSERT		TCD.DryerType		OFF
END





/*	FinnisherType

Identity: FinnisherTypeId
PRIMARY KEY: None
FK:	None

Table is referenced by foreign key:	None

*/
BEGIN
SET			@TableName				=			'FinnisherType'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempFinnisherType			TABLE	(
TempId						INT				IDENTITY(1, 1)
,	FinnisherTypeId				INT				PRIMARY	KEY
,	[Name]						[NVARCHAR](50)	NOT NULL
,	[Is_Deleted]				[BIT]			NOT	NULL	DEFAULT('FALSE')
)

--Populate temp table variable with the input data
INSERT	@tempFinnisherType		(
FinnisherTypeId	,[Name]	,Is_Deleted	)
VALUES	(1	,'FinisherType 01'	,'FALSE'	)
,	(2	,'FinisherType 02'	,'FALSE'	)
--the above seems to be sample data, unless actual is available... so, update when available...
--add entries here in the above format

SET		IDENTITY_INSERT		TCD.FinnisherType		ON

MERGE	TCD.FinnisherType			AS			TARGET
USING	@tempFinnisherType			AS			SOURCE
ON	TARGET.FinnisherTypeId		=			SOURCE.FinnisherTypeId
WHEN	NOT MATCHED		THEN
INSERT	(FinnisherTypeId			,[Name]			,Is_Deleted			)
VALUES	(SOURCE.FinnisherTypeId		,SOURCE.[Name]	,SOURCE.Is_Deleted	)

;
SET		IDENTITY_INSERT		TCD.FinnisherType		OFF
END







/*	AuditOperation

select	*	from	AuditOperation
*/
BEGIN
SET			@TableName				=			'AuditOperation'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempAuditOperation	TABLE	(
TempId					INT				IDENTITY(1, 1)
,	OperationId				TINYINT			PRIMARY	KEY
,	OperationCode			NVARCHAR(15)	NOT	NULL			UNIQUE
,	OperationDescription	NVARCHAR(50)	NOT	NULL
,    UsageKey				 NVARCHAR(200) NULL
)

--Populate temp table variable with the input data
INSERT	@tempAuditOperation	(
OperationId	,OperationCode	,OperationDescription,UsageKey)
VALUES	(1	,N'SQLInsert'	,N'Row inserted in database table'				  ,'FIELD_CREATED'			)
,	(2	,N'SQLUpdate'	,N'Row updated in database table'				  ,'FIELD_UPDATED'			)
,	(3	,N'AppDelete'	,N'Record soft-deleted in application'			  ,'FIELD_DELETED'			)
,	(4	,N'UserLogon'	,N'TCD application user logon'				  ,'FIELD_LOGIN'			)
,	(5	,N'UserLogoff'	,N'TCD application user logoff'				  ,'FIELD_LOGOUT'			)
,    (6	,N'ReportGenerated'	,N'Report Generation for Perticular Report'	  ,'FIELD_REPORTGENERATED'	)
,    (7	,N'Manual Entry'	,N'Manual Input On Production'			  ,'FIELD_MANUALENTRY'		)

MERGE	[TCD].AuditOperation			AS TARGET
USING	@tempAuditOperation		AS SOURCE
ON	TARGET.OperationId		=			SOURCE.OperationId
AND	TARGET.OperationCode	=			SOURCE.OperationCode
WHEN	NOT MATCHED		THEN
INSERT	(OperationId		,OperationCode			,OperationDescription, UsageKey)
VALUES	(SOURCE.OperationId	,SOURCE.OperationCode	,SOURCE.OperationDescription ,SOURCE.UsageKey)
;
END





/*	UserMaster

No identity column defined.
PRIMARY KEY: UserId
FK:	REFERENCES ConduitLocal_4thSept.dbo.LanguageMaster (LanguageId)		--Already moved above
REFERENCES ConduitLocal_4thSept.dbo.UnitOfMeasure (UOMId)			--pulled from the other script here above this one

Table is referenced by foreign key:	(Some of these are not 'Master', others are lower in the order...)
dbo.ConduitController: FK_ConduitController_LastModifiedByUserId
dbo.ControllerSetupData: FK_ControllerSetupData_LastModifiedByUserId
dbo.DashboardUserPortletMapping: FK_DashboardUserPortletMapping_UserMaster
dbo.PlantUtilityEnergyProperties: FK_PlantUtilityEnergyProperties_LastModifiedByUserId
dbo.PlantUtilityFactor: FK_PlantUtilityFactor_LastModifiedByUserId
dbo.ProgramMaster: FK_ProgramMaster_LastModifiedByUserId
dbo.ProgramMasterHistory: FK_ProgramMasterHistory_UserId
dbo.UserInRole: FK_UserInRole_UserMaster


select	*	from	UserMaster
*/

	--BEGIN
	--	SET			@TableName				=			'UserMaster'
	--	PRINT @TableName

	--	--Declare temp table variable to hold input data
	--	DECLARE	@tempUserMaster	TABLE	(
	--			TempId					INT				IDENTITY(1, 1)
	--		,	UserId					INT				NOT	NULL
	--		,	FirstName				NVARCHAR(50)
	--		,	LastName				NVARCHAR(50)
	--		,	FullName				NVARCHAR(50)
	--		,	LoginName				NVARCHAR(100)	NOT	NULL
	--		,	[Password]				NVARCHAR(100)	NOT	NULL
	--		,	Phone					NVARCHAR(50)
	--		,	LanguageId				INT
	--		,	UOMId					INT
	--		,	EMail					NVARCHAR(120)
	--		,	IsActive				BIT
	--		,	lastLoggedIn			DATETIME
	--		,	EcoLabAccountNumber		NVARCHAR(1000)					--Adding these 2 cols. that were added for User Mgmt. story (Sprint 10)
	--		,	LastModifiedByUserId	INT
	--		)

BEGIN
SET			@TableName				=			'UserMaster'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempUserMaster	TABLE	(
TempId					INT				IDENTITY(1, 1)
,	UserId					INT				NOT	NULL
,	FirstName				NVARCHAR(50)
,	LastName				NVARCHAR(50)
,	FullName				NVARCHAR(50)
,	LoginName				NVARCHAR(100)	NOT	NULL
,	[Password]				NVARCHAR(100)	NOT	NULL
,	Phone					NVARCHAR(50)
,	LanguageId				INT
,	UOMId					INT
,	EMail					NVARCHAR(120)
,	IsActive				BIT
,	lastLoggedIn			DATETIME
,	EcoLabAccountNumber		NVARCHAR(1000)					--Adding these 2 cols. that were added for User Mgmt. story (Sprint 10)
,	LastModifiedByUserId	INT
)

--Populate temp table variable with the input data				--Addin2 2 new cols. & replacing literals with variables defined above
		INSERT	@tempUserMaster	(
				UserId						,FirstName				,LastName		,FullName								,LoginName			,[Password]
				--Addin2 2 new cols.
			,	EcoLabAccountNumber			,LastModifiedByUserId	)	--rest all will be NULL
		VALUES	(@UserId_defaultUser		,N'DefaultUser'			,N'EcoLab-TCD'	,N'Default user for EcoLab-TCD app.'	,N'defaultuser'		,NEWID()
			,	@EcoLabAccountNumber		,@UserId_defaultUser	)	--replacing literals with variables defined above

		SET	IDENTITY_INSERT	[TCD].UserMaster	ON

		MERGE	[TCD].UserMaster			AS TARGET
		USING	@tempUserMaster		AS SOURCE
			ON	TARGET.UserId		=			SOURCE.UserId
		WHEN	NOT MATCHED		THEN
				INSERT	(UserId						,FirstName						,LastName			,FullName			,LoginName			,[Password]
					,	EcoLabAccountNumber			,LastModifiedByUserId			)	--rest all will be NULL
				VALUES	(SOURCE.UserId				,SOURCE.FirstName				,SOURCE.LastName	,SOURCE.FullName	,SOURCE.LoginName	,SOURCE.[Password]
					,	SOURCE.EcoLabAccountNumber	,SOURCE.LastModifiedByUserId	)
				;
		SET	IDENTITY_INSERT	[TCD].UserMaster	OFF

	END





--SET the default user Id:
	DECLARE	@UserId			INT

	SELECT	@UserId			=			UserId
	FROM	[TCD].UserMaster
	WHERE	LoginName		=			N'defaultuser'

	IF	(@UserId	IS	NULL)
	BEGIN
		INSERT	#Errors_MyServiceMasterDataSetup	(
				TableName			,ErrorNumber	,ErrorMessage										,ErrorProcedure					)	--rest will be NULL
		VALUES	(N'UserMaster'		,50000			,'Could not obtain UserId for the default user'		,'Script-MyServiceMasterData'	)

		--Interrupt the script
		GOTO	ExitScript_ConduitLocalMasterData

	END


/*	MachineGroupType

Identity: None
PRIMARY KEY: Id
FK:	None

Table is referenced by foreign key:	MachineGroup - GroupTypeId

*/
BEGIN
SET			@TableName				=			'MachineGroupType'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempMachineGroupType				TABLE	(
    TempId						INT				IDENTITY(1, 1)
,	Id					INT				PRIMARY	KEY
,	[GroupType]						[NVARCHAR](1000)	NOT NULL
)

--Populate temp table variable with the input data
INSERT	@tempMachineGroupType		(
Id	,[GroupType]		)
VALUES	
    (1	,'Plant'					)
,   (2	,'Washer Group'			)
,   (3	,'Dryer Group'				)
,   (4	,'Finnisher Group'			)
,   (5	,'Water And Energy Device'	)
--the above seems to be sample data, unless actual is available... so, update when available...
--add entries here in the above format

MERGE	TCD.MachineGroupType			AS			TARGET
USING	@tempMachineGroupType			AS			SOURCE
ON	TARGET.Id		=			SOURCE.Id
WHEN	NOT MATCHED		THEN
INSERT	(Id		    ,[GroupType]	    )
VALUES	(SOURCE.Id    ,SOURCE.[GroupType] )
;
END




/*	MachineGroup

Identity: Id
PRIMARY KEY: Id
FK:	FK_MachineGroup_EcoLabAccountNumber,   FK_MachineGroup_GroupTypeId,	 FK_MachineGroup_UserMaster, 

Table is referenced by foreign key:	MachineGroup - GroupTypeId, ManualLabor	-   LocationId,    WasherGroup -	WasherGroupId

*/
BEGIN
SET			@TableName				=			'MachineGroup'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempMachineGroup				TABLE	(
    TempId						INT				IDENTITY(1, 1)
,	Id							INT				PRIMARY	KEY
,	GroupDescription				[NVARCHAR](50)		NOT NULL
,	GroupTypeId					INT				NULL
,	EcolabAccountNumber				NVARCHAR(1000)		NULL
,	Is_Deleted					BIT				NULL		  DEFAULT ((0))
,	LastModifiedByUserId			INT		  		NULL
,	LastModifiedTime				DATETIME			NOT NULL
,	LastSyncTime					DATETIME			NULL
)

--Populate temp table variable with the input data
INSERT	@tempMachineGroup		(
Id	,GroupDescription,GroupTypeId,	LastModifiedByUserId,LastModifiedTime)
VALUES
    (1	,'Plant',					    1,	   0, GETUTCDATE())
,   (2	,'Water And Energy Device',	    5,	   0, GETUTCDATE())

--add entries here in the above format

SET		IDENTITY_INSERT		TCD.MachineGroup		ON

MERGE	TCD.MachineGroup			AS			TARGET
USING	@tempMachineGroup			AS			SOURCE
ON	TARGET.Id		=			SOURCE.Id
WHEN	NOT MATCHED		THEN
INSERT	(
Id,
GroupDescription,
GroupTypeId,
Is_Deleted,
LastModifiedByUserId,
LastModifiedTime
)
VALUES	(SOURCE.Id    ,SOURCE.GroupDescription,	  SOURCE.GroupTypeId,	   SOURCE.Is_Deleted,	  SOURCE.LastModifiedByUserId,	 SOURCE.LastModifiedTime)
;
SET		IDENTITY_INSERT		TCD.MachineGroup		OFF
END





/*	ConfigSettings

Identity: ConfigSettings
PRIMARY KEY: None
FK:	None

Table is referenced by foreign key:	None

*/
BEGIN
	SET			@TableName				=			'ConfigSettings'
	PRINT @TableName

	--Declare temp table variable to hold input data
	DECLARE	@tempSyncConfigSettings			TABLE	(
			TempId				INT				IDENTITY(1, 1)
		,	KeyName				[NVARCHAR](50)  NULL
		,	Value				[NVARCHAR](200)	NULL
		,	[Type]				[NVARCHAR](50)	NULL
		,	Active				[BIT]			NULL
		)

	--Populate temp table variable with the input data
	INSERT @tempSyncConfigSettings (
		KeyName ,Value ,[Type]  ,Active )
		VALUES (N'HostName', N'stg-3dtrasarcontroller.nalco.com', N'PushToLocal', 1)
		,  (N'HostName', N'stg-3dtrasarcontroller.nalco.com', N'SyncQueuedata', 1)
		,  (N'HostName', N'stg-3dtrasarcontroller.nalco.com', N'SyncBatchData', 1)
		,  (N'HostName', N'stg-3dtrasarcontroller.nalco.com', N'TcpHostService', 1)
		,  (N'PortNumber', N'9340', N'SyncBatchData', 1)
		,  (N'PortNumber', N'9340', N'SyncQueuedata', 1)
		,  (N'PortNumber', N'9340', N'TcpHostService', 1)
		,  (N'PortNumber', N'9340', N'PushToLocal', 1)
		,  (N'ReadTimeout', N'300000', N'SyncBatchData', 1)
		,  (N'ReadTimeout', N'300000', N'SyncQueuedata', 1)
		,  (N'ReadTimeout', N'300000', N'TcpHostService', 1)
		,  (N'ReadTimeout', N'300000', N'PushToLocal', 1)
		,  (N'TimerInterval', N'10000', N'SyncQueuedata', 1)
		,  (N'TimerAutoReset', N'True', N'SyncQueuedata', 1)
		,  (N'TimerEnabled', N'True', N'SyncQueuedata', 1)
		,  (N'FolderPath', N'd:\\LogFiles', N'SyncLogFile', 1)
		,  (N'AutoReset', N'True', N'SyncLogFile', 1)
		,  (N'TimerEnabled', N'True', N'SyncLogFile', 1)
		,  (N'TimerInterval', N'900000', N'SyncLogFile', 1)
		,  (N'HostName', N'stg-3dtrasarcontroller.nalco.com', N'SyncLogFile', 1)
		,  (N'ReadTimeout', N'300000', N'SyncLogFile', 1)
		,  (N'PortNumber', N'9340', N'SyncLogFile', 1)
		,  (N'HostName', N'stg-3dtrasarcontroller.nalco.com', N'PushToCentral', 1)
		,  (N'PortNumber', N'9340', N'PushToCentral', 1)
		,  (N'HostName', N'stg-3dtrasarcontroller.nalco.com', N'ResyncEngine', 1)
		,  (N'PortNumber', N'9340', N'ResyncEngine', 1)
		,  (N'ReadTimeOut', N'300000', N'ResyncEngine', 1)
		,  (N'NoOfRecordsToBeProcessed', N'20', N'SyncBatchData', 1)
		,  (N'ReadTimeout', N'300000', N'PushToCentral', 1)
		,  (N'TimerAutoReset', N'True', N'SyncBatchData', 1)
		,  (N'TimerEnabled', N'True', N'SyncBatchData', 1)
		,  (N'TimerInterval', N'900000', N'SyncBatchData', 1)
		,  (N'SocketPort', N'9340', N'LocalTcpHost', 1)
		,  (N'WorkerThreads', N'100', N'TcpHostService', 1)
		,  (N'CompletionPortThreads', N'100', N'TcpHostService', 1)
		,  (N'HostName', N'stg-3dtrasarcontroller.nalco.com', N'PushAllEntities', 1)
		,  (N'PortNumber', N'9340', N'PushAllEntities', 1)
		,  (N'ReadTimeout', N'30000000', N'PushAllEntities', 1)
		,  (N'TimerAutoReset', N'True', N'PushAllEntities', 1)
		,  (N'TimerEnabled', N'True', N'PushAllEntities', 1)
		,  (N'TimerInterval', N'900000', N'PushAllEntities', 1)
		,  (N'FTPUrl', N'ftp.allianceglobalservices.com/MylaundryInstaller/Achal', N'SoftWareUpdate', 1)
		,  (N'FTPUserId', N'agstcd2014', N'SoftWareUpdate', 1)
		,  (N'FTPPassword', N'alliance123', N'SoftWareUpdate', 1)
		,  (N'TransferPerHourRedLevel', N'75', N'DashBoardTransferPerHour', 1)
		,  (N'TransferPerHourGreenLevel', N'90', N'DashBoardTransferPerHour', 1)
		--add entries here in the above format

	;
	MERGE	TCD.ConfigSettings			AS			TARGET
	USING	@tempSyncConfigSettings			AS			SOURCE
		ON	TARGET.KeyName					=			SOURCE.KeyName
		AND	TARGET.Value					=			SOURCE.Value
		ANd	TARGET.[Type]					=			SOURCE.[Type]
	WHEN	NOT MATCHED		THEN
			INSERT	(KeyName			,Value			,[Type]			,Active)
			VALUES	(SOURCE.KeyName		,SOURCE.Value	,SOURCE.[Type]	,SOURCE.Active)
	;
END
   



/*	ConduitParameters

Identity: Id
PRIMARY KEY: Id
FK:	None

*/
BEGIN
SET			@TableName				=			'ConduitParameters'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempConduitParameters	TABLE	(
	TempId					INT				IDENTITY(1, 1)
,	Id						INT				NOT	NULL
,	Name					NVARCHAR(50)	NULL
,	DESCRIPTION				NVARCHAR(50)	NULL
,	MANDATORYCOL			INT				NULL
,	ISACTIVE				INT				NULL
,	SORTORDER				INT				NULL	
,    IsTrending			 BIT				  NULL
)

--Populate temp table variable with the input data
INSERT	@tempConduitParameters		(
Id,Name,Description,MandatoryCol,IsActive,SortOrder,IsTrending	)
VALUES	(1,  N'pH', NULL, 1,1, 2,1)
,(2,N'Temperature', NULL, 1,1, 3,1)
,(3,N'Conductivity', NULL, 1,1, 4,1)
,(4,N'Customer', NULL, 0,0, 1,1)
,(5,N'Formula Number', NULL, 0,1, 5,1)
,(6,N'Transfer Signal', NULL, 0,0, 6,1)
,(7, N'Weight', NULL, 0,1, 7,1)
,(8, N'DosingAmount', NULL, 0,1, 8,1)
,(9, N'HoldSignal', NULL, 0,1, 9,0)
,(10, N'Injection ', NULL, 0,1, 10,0)
,(11, N'Operation Counter ', NULL, 0,1, 11,0)
,(12, N'StopSignal', NULL,	0,1, 12,0)
,(13, N'Water Meter Start',	NULL,	0,1, 13,0)
,(14, N'Water Meter End',	NULL,	0,1, 14,0)
,(15, N'Energy Meter Start',NULL,	0,1, 15,0)
,(16, N'Energy Meter End',	NULL,	0,1, 16,0)
,(17, N'HoldTime',NULL,	0,1, 17,0)
,(18, N'BatchStatus',	NULL,	0,1, 18,0)
,(19, N'EndOfSignal',	NULL,	0,1, 19,0)
,(25,'Mimum Temperature','My Control mimum Temprature',0,1,10,0)
,(26,'Maximum Temperature','My Control Maximum Temprature',0,1,10,0)
,(27,'Minimum Temperature Status','My Control Mimum Temprature',0,1,10,0)
,(28,'Max Temperature Status','My Control Max Temprature Status',0,1,10,0)
,(29,'PH Status','My Control PHStatus',0,1,10,0)
,(30, 'StepCompartment No', 'Step or Compartment No', 0, 1, 30, 1)
,(31, 'LF Status', 'LF Status', 0, 1, 31, 1)
,(32, 'Average Temperature', 'Average Temperature', 0, 1, 32, 1)
,(33, 'Temperature Status', 'Temperature Status', 0, 1, 33, 1)
,(34, 'Maximum Conductivity', 'Maximum Conductivity', 0, 1, 34, 1)
,(35, 'Minimum Conductivity', 'Minimum Conductivity', 0, 1, 35, 1)
,(36, 'Average Conductivity', 'Average Conductivity', 0, 1, 36, 1)
,(37, 'Number of Injection/Dosage Steps', 'Number of Injection/Dosage Steps', 0, 1, 37, 1)
,(38, 'Number of Wash Steps', 'Number of Wash Steps', 0, 1, 38, 1)
,(40, 'Cool Down Step', 'Cool Down Step', 0, 1, 40, 0)







--SET		IDENTITY_INSERT		TCD.ConduitParameters		ON

MERGE	TCD.ConduitParameters					AS			TARGET
USING	@tempConduitParameters			AS			SOURCE
ON	TARGET.Id		=			SOURCE.Id
WHEN	NOT MATCHED		THEN
INSERT	(Id,Name,Description,MandatoryCol,IsActive,SortOrder,IsTrending)
VALUES	(SOURCE.Id	,SOURCE.Name ,SOURCE.Description,SOURCE.MandatoryCol,SOURCE.IsActive,SOURCE.SortOrder,Source.IsTrending);

--SET		IDENTITY_INSERT		[TCD].ConduitParameters		OFF
END



/*	BatchStatus

Identity: Id
PRIMARY KEY: Id
FK:	None

*/
BEGIN
SET			@TableName				=			'BatchStatus'
PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempBatchStatus	TABLE	(
	TempId					INT				IDENTITY(1, 1)
,	BatchStatusId			INT				NOT	NULL
,	BatchStatus				NVARCHAR(50)	NULL
)

--Populate temp table variable with the input data
INSERT	@tempBatchStatus		(
BatchStatusId, BatchStatus)
VALUES	 (1, N'Good')
		,(2, N'Bad due to Injections')
		,(3, N'Bad due to washsteps')

--SET		IDENTITY_INSERT		TCD.ConduitParameters		ON

MERGE	TCD.BatchStatus					AS			TARGET
USING	@tempBatchStatus			AS			SOURCE
ON	TARGET.BatchStatusId		=			SOURCE.BatchStatusId
WHEN	NOT MATCHED		THEN
INSERT	(BatchStatusId			,BatchStatus)
VALUES	(SOURCE.BatchStatusId	,SOURCE.BatchStatus);

--SET		IDENTITY_INSERT		[TCD].ConduitParameters		OFF
END


--Moved from Myservie Master data script file
-------------------------------------------------


/*	LanguageMaster

No identity column defined.
PRIMARY KEY: LanguageId

select	*	from	LanguageMaster
*/
	BEGIN
		SET			@TableName				=			'LanguageMaster'
		PRINT @TableName

		--Declare temp table variable to hold input data
		DECLARE	@tempLanguageMaster	TABLE	(
				TempId						INT				IDENTITY(1, 1)
			,	LanguageId					INT				NOT	NULL
			,	Name						NVARCHAR(50)
			,	MyServiceISOLangCD			CHAR(2)			NULL
			,	MyServiceDialectCD			CHAR(2)			NULL
			,	Locale						VARCHAR(50)		NULL
			,   IsActive					bit				NULL
			)
		--Populate temp table variable with the input data
		INSERT	@tempLanguageMaster	(
				LanguageId			,Name	,MyServiceISOLangCD	,MyServiceDialectCD, Locale,IsActive	)
		VALUES	(1, N'English US', N'EN', N'  ', N'en-US', 1)
, (2, N'Deutsch', N'DE', N'  ', N'nl-BE', 1)
, (3, N'Espa&#241ol', N'ES', N'  ', N'es-MX', 1)
, (4, N'Français', N'FR', N'  ', N'fr-FR', 0)
, (5, N'Italiano', N'IT', N'  ', N'it-IT', 0)
, (6, N'中文', N'ZH', N'  ', N'zh-CN', 0)
, (7, N'English UK', NULL, NULL, N'en-GB', 0)
, (8, N'Nederlands', N'NL', N'  ', N'nl-NL', 0)
, (9, N'한국어', N'KO', N'  ', N'ko-KR', 0)
, (10, N'Português', N'PT', N'  ', N'pt-PT', 0)
, (11, N'Русский язык', N'RU', N'  ', N'ru-RU', 0)
, (12, N'日本語', N'JA', N'  ', N'ja-JP', 0)
, (13, N'nynorsk', N'NO', N'  ', N'no-NO', 1)
, (14, N'Afrikaans', N'AF', N'  ', N'af-AF', 0)
, (15, N'Arabic', N'AR', N'  ', N'ar-AR', 0)
, (16, N'Bulgarian', N'BG', N'  ', N'bg-BG', 0)
, (17, N'Catalan', N'CA', N'  ', N'ca-CA', 0)
, (18, N'Chinese trad.', N'ZF', N'  ', N'zf-ZF', 0)
, (19, N'Croatian', N'HR', N'  ', N'hr-HR', 0)
, (20, N'Customer reserve', N'Z1', N'  ', N'z1-z1', 0)
, (21, N'Czech', N'CS', N'  ', N'cs-CS', 0)
, (22, N'Danish', N'DA', N'  ', N'da-DA', 0)
, (23, N'Estonian', N'ET', N'  ', N'et-ET', 0)
, (24, N'Finnish', N'FI', N'  ', N'fi-FI', 0)
, (25, N'Greek', N'EL', N'  ', N'el-EL', 0)
, (26, N'Hebrew', N'HE', N'  ', N'he-HE', 0)
, (27, N'Hungarian', N'HU', N'  ', N'hu-HU', 0)
, (28, N'Icelandic', N'IS', N'  ', N'is-IS', 0)
, (29, N'Indonesian', N'ID', N'  ', N'id-ID', 0)
, (30, N'Latvian', N'LV', N'  ', N'lv-LV', 0)
, (31, N'Lithuanian', N'LT', N'  ', N'lt-LT', 0)
, (32, N'Malaysian', N'MS', N'  ', N'ms-MS', 0)
, (33, N'Polish', N'PL', N'  ', N'pl-PL', 0)
, (34, N'Romanian', N'RO', N'  ', N'ro-RO', 0)
, (35, N'Serbian', N'SR', N'  ', N'sr-SR', 0)
, (36, N'Serbian (Latin)', N'SH', N'  ', N'sh-SH', 0)
, (37, N'Slovakian', N'SK', N'  ', N'sk-SK', 0)
, (38, N'Slovenian', N'SL', N'  ', N'sl-SL', 0)
, (39, N'Swedish', N'SV', N'  ', N'sv-SV', 0)
, (40, N'Thai', N'TH', N'  ', N'th-TH', 0)
, (41, N'Turkish', N'TR', N'  ', N'tr-TR', 0)
, (42, N'Ukrainian', N'UK', N'  ', N'uk-UK', 0)
, (43, N'French Canadian', N'FC', N'  ', N'fc-FC', 0)


		MERGE	[TCD].LanguageMaster		AS TARGET
		USING	@tempLanguageMaster	AS SOURCE
			ON	TARGET.LanguageId		=			SOURCE.LanguageId
		WHEN	NOT MATCHED		THEN
				INSERT	(LanguageId			,Name			,MyServiceISOLangCD			,MyServiceDialectCD				, Locale	)
				VALUES	(SOURCE.LanguageId	,SOURCE.Name	,SOURCE.MyServiceISOLangCD	,SOURCE.MyServiceDialectCD		, Locale	)
				;
	END
	

/*	WeekDay

*/
	BEGIN
		SET			@TableName				=			'WeekDay'
		PRINT @TableName

		--Declare temp table variable to hold input data
		DECLARE	@tempWeekDay	TABLE	(
				TempId			INT				IDENTITY(1, 1)
			,	DayId			INT				NOT	NULL
			,	[DayName]		NVARCHAR(255)
			)

		--Populate temp table variable with the input data
		INSERT	@tempWeekDay	(
				DayId	,[DayName]	)
		VALUES	(1	,'Sunday'	)
			,	(2	,'Monday'	)
			,	(3	,'Tuesday'	)
			,	(4	,'Wednesday')
			,	(5	,'Thursday'	)
			,	(6	,'Friday'	)
			,	(7	,'Saturday'	)

		MERGE	[TCD].[WeekDay]		AS TARGET
		USING	@tempWeekDay	AS SOURCE
			ON	TARGET.DayId	= SOURCE.DayId
		WHEN	NOT MATCHED		THEN	
				INSERT	(DayId			,[DayName])
				VALUES	(source.DayId	,source.[DayName]);
	END





/*	RegionMaster	

Table is referenced by foreign key:	ConduitLocal.dbo.Plant: FK_Plant_RegionMaster
No identity column defined.
PRIMARY KEY: RegionId

select	*	from	RegionMaster
*/
	BEGIN
		SET			@TableName				=			'RegionMaster'
		PRINT @TableName

		--Declare temp table variable to hold input data
		DECLARE	@tempRegionMaster	TABLE	(
				TempId			INT				IDENTITY(1, 1)
			,	RegionId		INT				NOT	NULL
			,	RegionName		VARCHAR(50)
			,	MyServiceRegionCode	VARCHAR(4)		NULL
			)

		--Populate temp table variable with the input data
		INSERT	@tempRegionMaster	(
				RegionId	,RegionName					,MyServiceRegionCode	)
		VALUES	(1	,'North America'					,'NA'		)
			,	(2	,'Europe / Middle East / Africa'	,'EMEA'		)
			,	(3	,'Asia/Pacific/Latin America'		,'APLA'		)
			--,	(4	,'Latinamerica'					)			--As per myService master data this will be alongwith Pacific region above (also with Asia added)

		MERGE	[TCD].RegionMaster		AS TARGET
		USING	@tempRegionMaster	AS SOURCE
			ON	TARGET.RegionId		=			SOURCE.RegionId
		WHEN	NOT MATCHED		THEN
				INSERT	(RegionId			,RegionName			,MyServiceRegionCode		)
				VALUES	(SOURCE.RegionId	,SOURCE.RegionName	,SOURCE.MyServiceRegionCode	);
	END







/*	CurrencyMaster

No identity column defined.
PRIMARY KEY: NONE. Will use CurrencyCode as UNQIUE key

*/
	BEGIN
		SET			@TableName				=			'CurrencyMaster'
		PRINT @TableName

		--Declare temp table variable to hold input data
		DECLARE	@tempCurrencyMaster	TABLE	(
				TempId			INT				IDENTITY(1, 1)
			,	CurrencyGuid	NVARCHAR(255)
			,	CurrencyName	NVARCHAR(255)
			,	CurrencyCode	NVARCHAR(255)
			,	MyServiceCurrCD			NCHAR(3)			NULL
			)

		--Populate temp table variable with the input data
		INSERT	@tempCurrencyMaster	(
				CurrencyGuid								,CurrencyName		,CurrencyCode	,MyServiceCurrCD		)
		VALUES	('0e1c0024-75fc-de11-b0e0-00155d02c292',	'Algeria (Dinar)',	'DZD',	'DZD'	)
			,	('0f1c0024-75fc-de11-b0e0-00155d02c292',	'Argentina (Peso)',	'ARS',	'ARS'	)
			,	('101c0024-75fc-de11-b0e0-00155d02c292',	'Australia (Dollar)',	'AUD',	'AUD'	)
			,	('111c0024-75fc-de11-b0e0-00155d02c292',	'Brazil (Real)',	'BRL',	'BRL'	)
			,	('121c0024-75fc-de11-b0e0-00155d02c292',	'Britain (Pound)',	'GBP',	'GBP'	)
			,	('131c0024-75fc-de11-b0e0-00155d02c292',	'Brunei Darussalam (Dollar)',	'BND',	'BND'	)
			,	('141c0024-75fc-de11-b0e0-00155d02c292',	'Canada (Dollar)',	'CAD',	'CAD'	)
			,	('151c0024-75fc-de11-b0e0-00155d02c292',	'Chile (Free Rate Peso)',	'CLP',	'CLP'	)
			,	('161c0024-75fc-de11-b0e0-00155d02c292',	'China (Renminbi)',	'CNY',	'CNY'	)
			,	('171c0024-75fc-de11-b0e0-00155d02c292',	'Colombia (Peso)',	'COP',	'COP'	)
			,	('181c0024-75fc-de11-b0e0-00155d02c292',	'Croatia (Kuna) **',	'HRK',	'HRK'	)
			,	('191c0024-75fc-de11-b0e0-00155d02c292',	'Czech Republic (Czech Koruna)',	'CZK',	'CZK'	)
			,	('1a1c0024-75fc-de11-b0e0-00155d02c292',	'Denmark (Krone)',	'DKK',	'DKK'	)
			,	('1c1c0024-75fc-de11-b0e0-00155d02c292',	'Egypt (Pound)',	'EGP',	'EGP'	)
			,	('1e1c0024-75fc-de11-b0e0-00155d02c292',	'Euro',	'EUR',	'EUR'	)
			,	('201c0024-75fc-de11-b0e0-00155d02c292',	'Hong Kong (Dollar)',	'HKD',	'HKD'	)
			,	('211c0024-75fc-de11-b0e0-00155d02c292',	'Hungary (Forint)',	'HUF',	'HUF'	)
			,	('221c0024-75fc-de11-b0e0-00155d02c292',	'India (Rupee)',	'INR',	'INR'	)
			,	('231c0024-75fc-de11-b0e0-00155d02c292',	'Indonesia (Rupiah)',	'IDR',	'IDR'	)
			,	('241c0024-75fc-de11-b0e0-00155d02c292',	'Israel (Shekel)',	'ILS',	'ILS'	)
			,	('251c0024-75fc-de11-b0e0-00155d02c292',	'Japan (Yen)',	'JPY',	'JPY'	)
			,	('261c0024-75fc-de11-b0e0-00155d02c292',	'Kazakhstan (Tengy)',	'KZT',	'KZT'	)
			,	('271c0024-75fc-de11-b0e0-00155d02c292',	'Kuwaiti (Dinar)',	'KWD',	'KWD'	)
			,	('281c0024-75fc-de11-b0e0-00155d02c292',	'Libya (Dinar)',	'LYD',	'LYD'	)
			,	('291c0024-75fc-de11-b0e0-00155d02c292',	'Malaysia (Ringgit)',	'MYR',	'MYR'	)
			,	('2b1c0024-75fc-de11-b0e0-00155d02c292',	'Mexico (Nuevo Peso)',	'MXN',	'MXN'	)
			,	('2c1c0024-75fc-de11-b0e0-00155d02c292',	'Morocco (Dirham)',	'MAD',	'MAD'	)
			,	('2d1c0024-75fc-de11-b0e0-00155d02c292',	'New Zealand (Dollar)',	'NZD',	'NZD'	)
			,	('2e1c0024-75fc-de11-b0e0-00155d02c292',	'Norway (Krone)',	'NOK',	'NOK'	)
			,	('2f1c0024-75fc-de11-b0e0-00155d02c292',	'Oman (Riyal)',	'OMR',	'OMR'	)
			,	('301c0024-75fc-de11-b0e0-00155d02c292',	'Pakistan (Rupee)',	'PKR',	'PKR'	)
			,	('311c0024-75fc-de11-b0e0-00155d02c292',	'Panama (Balboa)',	'PAB',	'PAB'	)
			,	('321c0024-75fc-de11-b0e0-00155d02c292',	'Paraguay (Guarani)',	'PYG',	'PYG'	)
			,	('331c0024-75fc-de11-b0e0-00155d02c292',	'Philippines (Peso)',	'PHP',	'PHP'	)
			,	('351c0024-75fc-de11-b0e0-00155d02c292',	'Poland (Zlotty)',	'PLN',	'PLN'	)
			,	('361c0024-75fc-de11-b0e0-00155d02c292',	'Qatar(Riyal)',	'QAR',	'QAR'	)
			,	('391c0024-75fc-de11-b0e0-00155d02c292',	'Russia (Rouble)',	'RUB',	'RUB'	)
			,	('401c0024-75fc-de11-b0e0-00155d02c292',	'S. Korea (Won)',	'KRW',	'KRW'	)
			,	('3a1c0024-75fc-de11-b0e0-00155d02c292',	'Saudi Arabia (Riyal)',	'SAR',	'SAR'	)
			,	('3c1c0024-75fc-de11-b0e0-00155d02c292',	'Serbia (Serbia Dinar)',	'RSD',	'RSD'	)
			,	('3d1c0024-75fc-de11-b0e0-00155d02c292',	'Singapore (Dollar)',	'SGD',	'SGD'	)
			,	('3f1c0024-75fc-de11-b0e0-00155d02c292',	'South Africa (Rand)',	'ZAR',	'ZAR'	)
			,	('411c0024-75fc-de11-b0e0-00155d02c292',	'Sri Lanka (Rupee)',	'LKR',	'LKR'	)
			,	('421c0024-75fc-de11-b0e0-00155d02c292',	'Sweden (Krona)',	'SEK',	'SEK'	)
			,	('431c0024-75fc-de11-b0e0-00155d02c292',	'Switzerland (Franc)',	'CHF',	'CHF'	)
			,	('441c0024-75fc-de11-b0e0-00155d02c292',	'Taiwan (Dollar)',	'TWD',	'TWD'	)
			,	('451c0024-75fc-de11-b0e0-00155d02c292',	'Thailand (Baht)',	'THB',	'THB'	)
			,	('461c0024-75fc-de11-b0e0-00155d02c292',	'Tunisia (Dinar)',	'TND',	'TND'	)
			,	('481c0024-75fc-de11-b0e0-00155d02c292',	'Turkey (Lira)',	'TRY',	'TRY'	)
			,	('491c0024-75fc-de11-b0e0-00155d02c292',	'Ukraine (Hryvnia)',	'UAH',	'UAH'	)
			,	('4a1c0024-75fc-de11-b0e0-00155d02c292',	'United Arab Emirates (Dirham)',	'AED',	'AED'	)
			,	('34d0daf2-59f6-de11-9ada-00155d02c292',	'US Dollars',	'USD',	'USD'	)
			,	('4c1c0024-75fc-de11-b0e0-00155d02c292',	'Vietnam (Dong)',	'VND',	'VND'	)
			,	('428BE663-CDAA-E411-93F2-000C29632C72',	'Bulgarian lev',	'BGN',	'BGN'	)
			,	('438BE663-CDAA-E411-93F2-000C29632C72',	'Belarus Ruble',	'BYR',	'BYR'	)
			,	('448BE663-CDAA-E411-93F2-000C29632C72',	'Lithuanian litas',	'LTL',	'LTL'	)
			,	('458BE663-CDAA-E411-93F2-000C29632C72',	'Latvia',	'LVL',	'LVL'	)
			,	('468BE663-CDAA-E411-93F2-000C29632C72',	'Romanian New Leu',	'RON',	'RON'	)
			,	('478BE663-CDAA-E411-93F2-000C29632C72',	'Estonian Kroon',	'EEK',	'EEK'	)

		;
		MERGE	[TCD].CurrencyMaster		AS TARGET
		USING	@tempCurrencyMaster			AS SOURCE
			ON	TARGET.CurrencyCode		=			SOURCE.CurrencyCode
		WHEN	NOT MATCHED		THEN
				INSERT	(CurrencyGuid			,CurrencyName			,CurrencyCode			,MyServiceCurrCD		)
				VALUES	(SOURCE.CurrencyGuid	,SOURCE.CurrencyName	,SOURCE.CurrencyCode	,SOURCE.MyServiceCurrCD	)
		;
END




/*	ControllerModel	--ControllerType

No identity column defined.
PRIMARY KEY: ControllerTypeId
NO FKs
No foreign keys reference table 'ControllerType', or you do not have permissions on referencing tables.

select	*	from	ControllerModel	--ControllerType
*/
	BEGIN
		SET			@TableName				=			'ControllerModel'
		PRINT @TableName

		--Declare temp table variable to hold input data
		DECLARE	@tempControllerModel	TABLE	(
				TempId						INT				IDENTITY(1, 1)
			,	Id							INT				NOT	NULL
			,	Name						NVARCHAR(50)
			,	RegionId					INT
			,	Active						BIT
			,	[Version]					INT
			,	DisplayOrder				INT
			)

		--Populate temp table variable with the input data
		INSERT	@tempControllerModel	(
				Id					,Name					,RegionId	,Active	,[Version]	,DisplayOrder	)
		VALUES	(1					,'Ultrax 6/12/16'		,1	,1	,1	,1	)
			,	(2					,'Ultrax 2000'			,1	,1	,1	,2	)
			,	(3					,'Elados Smart'			,1	,1	,1	,3	)
			,	(4					,'Softroll'				,1	,1	,1	,4	)
			,	(5					,'Utilitty logger'		,1	,1	,1	,5	)
			,	(6					,'Tank-controller'		,1	,1	,1	,6	)
			,	(7					,'myControl'			,1	,1	,1	,7	)
			,	(8					,'E-Control Plus'		,1	,1	,1	,8	)
			,	(9					,'E-Control Central'	,1	,1	,1	,9	)
			,	(10					,'Ecodose'				,1	,1	,1	,10	)
			,	(11					,'PLC XL'				,1	,1	,1	,11	)
			,	(12					,'Solumix'				,1	,1	,1	,12	)
			,   (13				    ,'Ultrax TDi'           ,1  ,1  ,1  ,13 )
			,   (14				    ,'EControl Decentral'   ,1  ,1  ,1  ,14 )

		MERGE	[TCD].ControllerModel			AS TARGET
		USING	@tempControllerModel		AS SOURCE
			ON	TARGET.Id				=			SOURCE.Id
		WHEN	NOT MATCHED		THEN
				INSERT	(Id			,Name			,RegionId			,Active			,[Version]			,DisplayOrder			)
				VALUES	(SOURCE.Id	,SOURCE.Name	,SOURCE.RegionId	,SOURCE.Active	,SOURCE.[Version]	,SOURCE.DisplayOrder	);
	END






/*	ControllerType	--New

No identity column defined.
PRIMARY KEY: Id
NO FKs
No foreign keys reference table 'ControllerType', or you do not have permissions on referencing tables.

select	*	from	ControllerType	--New
*/
	BEGIN
		SET			@TableName				=			'ControllerType'
		PRINT @TableName

		--Declare temp table variable to hold input data
		DECLARE	@tempControllerType			TABLE	(
				TempId						INT				IDENTITY(1, 1)
			,	Id							INT				NOT	NULL
			,	Name						NVARCHAR(50)
			)

		--Populate temp table variable with the input data
		INSERT	@tempControllerType	(
				Id					,Name	)
		VALUES	(1	,N'Allen Bradley'		)
			,	(2	,N'Beckhoff'			)
			,	(3	,N'Transactional'		)
			,	(4	,N'Non Transactional'	)
			,	(5	,N'Mitsubishi'			)
			,	(6	,N'8 Washers'			)
			,	(7	,N'1 Tunnel 6 Washers'	)
			,	(8	,N'6 Washers'			)
			,	(9	,N'4 Washers'			)
			,	(10	,N'1 Tunnel 4 Washers'	)
			,	(11	,N'1 Tunnel 2 Washers'	)
			,	(12	,N'10 Washers'			)
			,	(13	,N'1 Tunnel 5 Washers'	)
			,	(14	,N'2 Tunnels'			)

		MERGE	[TCD].ControllerType				AS TARGET
		USING	@tempControllerType			AS SOURCE
			ON	TARGET.Id					=			SOURCE.Id
		WHEN	NOT MATCHED		THEN
				INSERT	(Id			,Name			)
				VALUES	(SOURCE.Id	,SOURCE.Name	);
	END






/*	ControllerEquipmentType
*/
BEGIN
		SET			@TableName				=			'ControllerEquipmentType'
		PRINT @TableName

		--Declare temp table variable to hold input data
		DECLARE	@tempControllerEquipmentType	TABLE	(
				TempId							INT				IDENTITY(1, 1)
			,	ControllerEquipmentTypeId		TINYINT			NOT	NULL
			,	ControllerEquipmentTypeName		VARCHAR(30)
			)

		--Populate temp table variable with the input data
		INSERT	@tempControllerEquipmentType		(
				ControllerEquipmentTypeId	,ControllerEquipmentTypeName	)
		VALUES	(1	,'Pump/Valve'		)
			,	(2	,'ME'		)

		SET		IDENTITY_INSERT		[TCD].ControllerEquipmentType		ON

		MERGE	[TCD].ControllerEquipmentType					AS			TARGET
		USING	@tempControllerEquipmentType			AS			SOURCE
			ON	TARGET.ControllerEquipmentTypeId		=			SOURCE.ControllerEquipmentTypeId
		WHEN	NOT MATCHED		THEN
				INSERT	(ControllerEquipmentTypeId			,ControllerEquipmentTypeName			)
				VALUES	(SOURCE.ControllerEquipmentTypeId	,SOURCE.ControllerEquipmentTypeName	)	;

		SET		IDENTITY_INSERT		[TCD].ControllerEquipmentType		OFF

END





/*	ControllerModelControllerTypeMapping

Identity column: Id
PRIMARY KEY: Id (Not defined)
NO FKs
No foreign keys reference table 'ControllerModelControllerTypeMapping', or you do not have permissions on referencing tables.

select	*	from	ControllerModelControllerTypeMapping
*/
	BEGIN
		SET			@TableName				=			'ControllerModelControllerTypeMapping'
		PRINT @TableName

		--Declare temp table variable to hold input data
		DECLARE	@tempControllerModelControllerTypeMapping			TABLE	(
				TempId												INT				IDENTITY(1, 1)
			,	Id													INT				NOT	NULL
			,	ControllerModelId									INT				NOT	NULL
			,	ControllerTypeId									INT				NOT	NULL
			,	PumpValveCount										TINYINT			NOT	NULL
			,	MECount												TINYINT			NOT	NULL
			,	MaximumChemicalCount								TINYINT			NOT	NULL
			,	CanControlTunnel									BIT				NOT	NULL
			,	MaximumWasherExtractorCount							TINYINT			NULL
			,	[NumOfConvWasherGroups]								TINYINT			NULL
			,	[NumOfTunnelWasherGroups]							TINYINT			NULL
			,	[MaxTunnelCount]									TINYINT			NULL
			,	[MaxConvWasherCount]								TINYINT			NULL
			,	NumOfTunnelDosingLines 								TINYINT			NOT NULL
			,	NumOfConvDosingLines								TINYINT		 	NOT NULL
			,	MaxTunnelDosingPoints								TINYINT	 		NOT NULL
			,	MaxTunnelLineDosingPoints							TINYINT		 	NOT NULL
			,	MaxNumOfValvesForConventional						TINYINT	 		NOT NULL
			,	MaxNumOfValvesForTunnel								TINYINT		 	NOT NULL
			,	MaxNumOfMEForConventional							TINYINT		 	NOT NULL
			,	MaxNumOfMEForTunnel									TINYINT 		NOT NULL
			,	MaxNumOfTOMEquipmentForTunnel						TINYINT		 	NOT NULL
			,	MaxNumOfTOMDosingPointForTunnel						TINYINT 		NOT NULL
			,	MaxNumOfTOMEquipmentForConventional					TINYINT 		NOT NULL
			,	MaxNumOfTOMDosingPointForConventional				TINYINT  		NOT NULL
			,	MaxTunnelCompartmentCount							TINYINT		 	NOT NULL
			,	MaxConvProgramCount									tinyint	  NOT NULL
			,	MaxTunnelProgramCount								tinyint	  NOT NULL
			)

		--Populate temp table variable with the input data
		INSERT	@tempControllerModelControllerTypeMapping	(
				[Id], [ControllerModelId], [ControllerTypeId], [PumpValveCount], [MECount], [MaximumChemicalCount], [CanControlTunnel], [MaximumWasherExtractorCount], [NumOfConvWasherGroups], [NumOfTunnelWasherGroups], [MaxTunnelCount], [MaxConvWasherCount], [NumOfTunnelDosingLines], [NumOfConvDosingLines], [MaxTunnelDosingPoints], [MaxTunnelLineDosingPoints], [MaxNumOfValvesForConventional], [MaxNumOfValvesForTunnel], [MaxNumOfMEForConventional], [MaxNumOfMEForTunnel], [MaxNumOfTOMEquipmentForTunnel], [MaxNumOfTOMDosingPointForTunnel], [MaxNumOfTOMEquipmentForConventional], [MaxNumOfTOMDosingPointForConventional], [MaxTunnelCompartmentCount], [MaxConvProgramCount], [MaxTunnelProgramCount])
		VALUES	(1, 1, 1, 16, 0, 16, 0, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 127, 127)
				,(2, 1, 2, 16, 0, 16, 0, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 127, 127)
				,(3, 2, 1, 1, 0, 1, 0, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 127, 127)
				,(4, 2, 2, 1, 0, 1, 0, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 127, 127)
				,(5, 3, 2, 12, 0, 16, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 127, 127)
				,(6, 4, 3, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 127, 127)
				,(7, 4, 4, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 127, 127)
				,(8, 6, 2, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 127, 127)
				,(9, 6, 5, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 127, 127)
				,(10, 7, 2, 24, 2, 16, 1, 16, 0, 2, 2, 0, 16, 12, 0, 0, 0, 0, 0, 0, 22, 22, 12, 0, 0, 99, 99)
				,(11, 8, 6, 8, 2, 1, 0, 8, 1, 0, 0, 8, 0, 0, 0, 0, 8, 8, 2, 2, 22, 22, 0, 0, 0, 50, 0)
				,(12, 8, 7, 8, 2, 1, 0, 6, 1, 1, 1, 6, 0, 0, 0, 0, 8, 8, 2, 2, 22, 22, 0, 0, 0, 50, 50)
				,(13, 9, 8, 6, 1, 1, 0, 6, 1, 0, 0, 6, 0, 0, 0, 0, 6, 6, 1, 1, 0, 0, 0, 0, 0, 50, 0)
				,(14, 14, 9, 24, 1, 1, 0, 4, 1, 0, 0, 4, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 50, 0)
				,(15, 9, 10, 6, 1, 1, 0, 4, 1, 1, 1, 4, 0, 0, 0, 0, 6, 6, 1, 1, 0, 0, 0, 0, 0, 30, 80)
				,(16, 14, 11, 24, 1, 1, 0, 2, 1, 1, 1, 2, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 30, 129)
				,(17, 10, 6, 8, 1, 1, 0, 8, 1, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 50, 0)
				,(18, 11, 12, 12, 2, 1, 0, 10, 2, 0, 0, 10, 0, 0, 0, 0, 1, 5, 2, 2, 0, 0, 0, 0, 0, 99, 0)
				,(19, 11, 13, 12, 2, 1, 0, 5, 1, 1, 1, 5, 0, 0, 0, 0, 1, 5, 2, 2, 0, 0, 0, 0, 0, 99, 99)
				,(20, 11, 14, 12, 2, 1, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 1, 5, 2, 2, 0, 0, 0, 0, 0, 0, 99)
				,(21, 12, 5, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 127, 127)
				,(22, 13, 1, 16, 0, 16, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 127, 127)
				,(23, 5, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 127, 127)
				,(24, 5, 2, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 127, 127)

		SET		IDENTITY_INSERT		[TCD].ControllerModelControllerTypeMapping	ON

		MERGE	[TCD].ControllerModelControllerTypeMapping			AS			TARGET
		USING	@tempControllerModelControllerTypeMapping		AS			SOURCE
			ON	TARGET.Id										=			SOURCE.Id
		WHEN	NOT MATCHED		THEN
				INSERT	([Id], [ControllerModelId], [ControllerTypeId], [PumpValveCount], [MECount], [MaximumChemicalCount], [CanControlTunnel], [MaximumWasherExtractorCount], [NumOfConvWasherGroups], [NumOfTunnelWasherGroups], [MaxTunnelCount], [MaxConvWasherCount], [NumOfTunnelDosingLines], [NumOfConvDosingLines], [MaxTunnelDosingPoints], [MaxTunnelLineDosingPoints], [MaxNumOfValvesForConventional], [MaxNumOfValvesForTunnel], [MaxNumOfMEForConventional], [MaxNumOfMEForTunnel], [MaxNumOfTOMEquipmentForTunnel], [MaxNumOfTOMDosingPointForTunnel], [MaxNumOfTOMEquipmentForConventional], [MaxNumOfTOMDosingPointForConventional], [MaxTunnelCompartmentCount], MaxConvProgramCount, MaxTunnelProgramCount)
				VALUES	(SOURCE.[Id], SOURCE.[ControllerModelId], SOURCE.[ControllerTypeId], SOURCE.[PumpValveCount], SOURCE.[MECount], SOURCE.[MaximumChemicalCount], SOURCE.[CanControlTunnel], SOURCE.[MaximumWasherExtractorCount], SOURCE.[NumOfConvWasherGroups], SOURCE.[NumOfTunnelWasherGroups], SOURCE.[MaxTunnelCount], SOURCE.[MaxConvWasherCount], SOURCE.[NumOfTunnelDosingLines], SOURCE.[NumOfConvDosingLines], SOURCE.[MaxTunnelDosingPoints], SOURCE.[MaxTunnelLineDosingPoints], SOURCE.[MaxNumOfValvesForConventional], SOURCE.[MaxNumOfValvesForTunnel], SOURCE.[MaxNumOfMEForConventional], SOURCE.[MaxNumOfMEForTunnel], SOURCE.[MaxNumOfTOMEquipmentForTunnel], SOURCE.[MaxNumOfTOMDosingPointForTunnel], SOURCE.[MaxNumOfTOMEquipmentForConventional], SOURCE.[MaxNumOfTOMDosingPointForConventional], SOURCE.[MaxTunnelCompartmentCount], SOURCE.MaxConvProgramCount, SOURCE.MaxTunnelProgramCount)
		WHEN MATCHED THEN
			--UPDATE TCD.ControllerModelControllerTypeMapping SET
			UPDATE  SET
			[ControllerModelId] = SOURCE.[ControllerModelId],
     		[ControllerTypeId]  = SOURCE.[ControllerTypeId], 
			[PumpValveCount]    = SOURCE.[PumpValveCount],
			[MECount] = SOURCE.[MECount],
			[MaximumChemicalCount] = SOURCE.[MaximumChemicalCount],
			[CanControlTunnel] = SOURCE.[CanControlTunnel],
			[MaximumWasherExtractorCount] = SOURCE.[MaximumWasherExtractorCount],
			[NumOfConvWasherGroups] = SOURCE.[NumOfConvWasherGroups],
			[NumOfTunnelWasherGroups] = SOURCE.[NumOfTunnelWasherGroups], 
			[MaxTunnelCount] = SOURCE.[MaxTunnelCount],
			[MaxConvWasherCount] = SOURCE.[MaxConvWasherCount], 
			[NumOfTunnelDosingLines] = SOURCE.[NumOfTunnelDosingLines], 
			[NumOfConvDosingLines] = SOURCE.[NumOfConvDosingLines], 
			[MaxTunnelDosingPoints] = SOURCE.[MaxTunnelDosingPoints], 
			[MaxTunnelLineDosingPoints] = SOURCE.[MaxTunnelLineDosingPoints], 
			[MaxNumOfValvesForConventional] = SOURCE.[MaxNumOfValvesForConventional], 
			[MaxNumOfValvesForTunnel] = SOURCE.[MaxNumOfValvesForTunnel], 
			[MaxNumOfMEForConventional] = SOURCE.[MaxNumOfMEForConventional], 
			[MaxNumOfMEForTunnel] = SOURCE.[MaxNumOfMEForTunnel], 
			[MaxNumOfTOMEquipmentForTunnel] = SOURCE.[MaxNumOfTOMEquipmentForTunnel], 
			[MaxNumOfTOMDosingPointForTunnel] = SOURCE.[MaxNumOfTOMDosingPointForTunnel], 
			[MaxNumOfTOMEquipmentForConventional] = SOURCE.[MaxNumOfTOMEquipmentForConventional], 
			[MaxNumOfTOMDosingPointForConventional] = SOURCE.[MaxNumOfTOMDosingPointForConventional], 
			[MaxTunnelCompartmentCount] = SOURCE.[MaxTunnelCompartmentCount],
			MaxConvProgramCount	= SOURCE.MaxConvProgramCount,	
			MaxTunnelProgramCount = SOURCE.MaxTunnelProgramCount
			--WHERE MaxTunnelProgramCount[Id] = SOURCE.[Id]
			;
		SET		IDENTITY_INSERT		[TCD].ControllerModelControllerTypeMapping	OFF
	END


--/*	uncommenting


/*	WasherMode	-	table renamed later
	ControllerTypeModelToWasherMode			--Sprint addition (Oct-Nov '14)

Identity column: None
PRIMARY KEY: WasherModeId
FKs	: No foreign keys reference table 

*/
	--BEGIN
	--	SET	@TableName				=			'WasherMode'
	--	PRINT @TableName

	--	--Declare temp table variable to hold input data
	--	DECLARE	@tempWasherMode									TABLE	(
	--			TempId											INT				IDENTITY(1, 1)
	--		,	WasherModeId									TINYINT			NOT	NULL
	--		,	WasherModeName									NVARCHAR(200)	NOT	NULL
	--		,	ResourceKey										NVARCHAR(200)	NULL

	--		,	UNIQUE	(WasherModeId)
	--		)

	--	--Populate temp table variable with the input data
	--	INSERT	@tempWasherMode	(WasherModeId	,WasherModeName,	ResourceKey	)
	--	VALUES
	--	(0, N'Off', N'FIELD_OFF')
	--	,(1, N'Binary', N'FIELD_BINARY')
	--	,(2, N'Timed', N'FIELD_TIMED')
	--	,(3, N'Timed & Binary', N'FIELD_TIMED&BINARY')
	--	,(4, N'Timed & Timed', N'FIELD_TIMED&TIMED')
	--	,(5, N'1''s 10''s & 100''s', N'FIELD_1S10S&100S')
	--	,(6, N'Prg = Binary , Step = One Signal , Start generated by first Step', N'FIELD_PRGBINARYSTEPONESIGNALSTARTGENERATEDBYFIRSTSTEP')
	--	,(7, N'Prg and Start = Miniterminal , Step = One Signal', N'FIELD_PRGANDSTARTMINITERMINALSTEPONESIGNAL')
	--	,(8, N'Prg = Miniterminal , Step = One Signal , Start generated by first Step', N'FIELD_PRGMINITERMINALSTEPONESIGNALSTARTGENERATEDBYFIRSTSTEP')
	--	,(9, N'Prg = Miniterminal , Step = Binary , Start generated by first Step', N'FIELD_PRGMINITERMINALSTEPBINARYSTARTGENERATEDBYFIRSTSTEP')
	--	,(10, N'Prg and Start = Binary , Step = One Signal , Start not generated by first Step', N'FIELD_PRGANDSTARTBINARYSTEPONESIGNALSTARTNOTGENERATEDBYFIRSTSTEP')
	--	,(11, N'TOM mode only', N'FIELD_TOMMODEONLY')
	--	,(12, N'Prg = Binary, Step = Binary', N'FIELD_PRGBINARYSTEPBINARY')
	--	,(13, N'Prg = Miniterminal , Step = One Signal', N'FIELD_PRGMINITERMINALSTEPONESIGNAL')
	--	,(14, N'Prg = Miniterminal , Step = Binary', N'FIELD_PRGMINITERMINALSTEPBINARY')	
	--	,(15, N'Prg and Start = Binary , Step = One Signal , Start generate first Step', N'FIELD_PRGANDSTARTBINARYSTEPONESIGNALSTARTGENERATEDBYFIRSTSTEP')
	--	,(16, N'Prg = Binary , Step = One Signal , Start generated by first Step', N'FIELD_PRGBINARYSTEPONESIGNALSTARTGENERATEDBYFIRSTSTEP')
	--	,(17, N'Prg = WTC-Selector , Step = One Signal , Start generated by first Step', N'FIELD_PRGWTCSELECTORSTEPONESIGNALSTARTGENERATEDBYFIRSTSTEP')
	--	,(18, N'Prg and Start = WTC-Selector , Step = One Signal', N'FIELD_PRGANDSTARTWTCSELECTORSTEPONESIGNAL')
	--	,(19, N'Prg = WTC-Selector , Step = Binary , Start generated by firs Step', N'FIELD_PRGWTCSELECTORSTEPBINARYSTARTGENERATEDBYFIRSTSTEP')
	--	,(20, N'Program = Binary, Transfer conveyor = Transfer Tunnel', N'FIELD_PROGRAMBINARYTRANSFERCONVEYORTRANSFERTUNNEL')
	--	,(21, N'Program = Miniterminal, Transfer conveyor = Miniterminal', N'FIELD_PROGRAMMINITERMINALTRANSFERCONVEYORMINITERMINAL')
	--	,(22, N'Program = Binary, Transfer conveyor = Dedicated input', N'FIELD_PROGRAMBINARYTRANSFERCONVEYORDEDICATEDINPUT')
	--	,(23, N'Program = Miniterminal, Transfer conveyor = Transfer Tunnel', N'FIELD_PROGRAMMINITERMINALTRANSFERCONVEYORTRANSFERTUNNEL')
	--	,(24, N'Program = Miniterminal, Transfer conveyor = Dedicated input', N'FIELD_PROGRAMMINITERMINALTRANSFERCONVEYORDEDICATEDINPUT')
	--	,(25, N'Carbonell', N'FIELD_CARBONELL')
	--	,(26, N'Kannegiesser Ethernet communication', N'FIELD_KANNEGIESSERETHERNETCOMMUNICATION')
	--	,(27, N'Senking Ethernet communication', N'FIELD_SENKINGETHERNETCOMMUNICATION')
	--	,(28, N'Program = Miniterminal (including program 0), Transfer conveyor = Miniterminal', N'FIELD_PROGRAMMINITERMINALINCLUDINGPROGRAM0TRANSFERCONVEYORMINITERMINAL')

	--	MERGE	TCD.[WasherMode]				AS			TARGET
	--	USING	@tempWasherMode					AS			SOURCE
	--		ON	TARGET.WasherModeId								=			SOURCE.WasherModeId
	--	WHEN	NOT MATCHED		THEN
	--			INSERT	(WasherModeId			,WasherModeName			,ResourceKey		)
	--			VALUES	(SOURCE.WasherModeId	,SOURCE.WasherModeName	,SOURCE.ResourceKey	);

	--END


	/*	WasherModeMapping	

Identity column: None
PRIMARY KEY: ControllerTypeModelToWasherModeId
FKs	: 

*/
	--BEGIN
	--	SET	@TableName				=			'WasherModeMapping'
	--	PRINT @TableName

	--	--Declare temp table variable to hold input data
	--	DECLARE	@tempWasherModeMapping									TABLE	(
	--			TempId											INT				IDENTITY(1, 1)
	--		,	ControllerTypeModelToWasherModeId				SMALLINT		NOT	NULL
	--		,	ControllerModelControllerTypeMappingId			int				NOT	NULL
	--		,	WasherModeId									int				NULL
	--		,	WasherModeNumber								TINYINT			NULL
	--		,	WasherType										nchar(20)		NULL
	--		,	UNIQUE	(ControllerTypeModelToWasherModeId)
	--		)

	--	--Populate temp table variable with the input data
	--	INSERT	@tempWasherModeMapping	(ControllerTypeModelToWasherModeId	,ControllerModelControllerTypeMappingId	,WasherModeId ,WasherModeNumber ,WasherType)
	--	VALUES
	--	 (1, 1, 0, 1, 'C')
	--	,(2, 1, 1, 2, 'C')
	--	,(3, 1, 2, 3, 'C')
	--	,(4, 1, 3, 4, 'C')
	--	,(5, 1, 4, 5, 'C')
	--	,(6, 2, 0, 1, 'C')
	--	,(7, 2, 1, 2, 'C')
	--	,(8, 2, 2, 3, 'C')
	--	,(9, 2, 3, 4, 'C')
	--	,(10, 2, 4, 5, 'C')
	--	,(11, 2, 5, 6, 'C')
	--	,(12, 3, 0, 1, 'C')
	--	,(13, 3, 1, 2, 'C')
	--	,(14, 3, 2, 3, 'C')
	--	,(15, 3, 3, 4, 'C')
	--	,(16, 3, 4, 5, 'C')
	--	,(17, 4, 0, 1, 'C')
	--	,(18, 4, 1, 2, 'C')
	--	,(19, 4, 2, 3, 'C')
	--	,(20, 4, 3, 4, 'C')
	--	,(21, 4, 4, 5, 'C')
	--	,(22, 4, 5, 6, 'C')
	--	,(23, 5, 0, 1, 'T')
	--	,(24, 5, 1, 2, 'T')
	--	,(25, 5, 2, 3, 'T')
	--	,(26, 5, 3, 4, 'T')
	--	,(27, 5, 4, 5, 'T')
	--	,(28, 10, 0, 0, 'C')
	--	,(29, 10, 6, 1, 'C')
	--	,(30, 10, 7, 2, 'C')
	--	,(31, 10, 8, 3, 'C')
	--	,(32, 10, 9, 4, 'C')
	--	,(33, 10, 10, 5, 'C')
	--	,(34, 10, 11, 6, 'C')
	--	,(35, 10, 0, 0, 'T')
	--	,(36, 10, 20, 1, 'T')
	--	,(37, 10, 21, 2, 'T')
	--	,(38, 10, 22, 3, 'T')
	--	,(39, 10, 23, 4, 'T')
	--	,(40, 10, 24, 5, 'T')
	--	,(41, 10, 25, 6, 'T')
	--	,(42, 10, 26, 7, 'T')
	--	,(43, 11, 0, 0, 'C')
	--	,(44, 11, 15, 1, 'C')
	--	,(45, 11, 7, 2, 'C')
	--	,(46, 11, 8, 3, 'C')
	--	,(47, 11, 9, 4, 'C')
	--	,(48, 11, 16, 5, 'C')
	--	,(49, 11, 17, 6, 'C')
	--	,(50, 11, 18, 7, 'C')
	--	,(51, 11, 10, 8, 'C')
	--	,(52, 11, 11, 9, 'C')
	--	,(53, 12, 0, 0, 'C')
	--	,(54, 12, 15, 1, 'C')
	--	,(55, 12, 7, 2, 'C')
	--	,(56, 12, 8, 3, 'C')
	--	,(57, 12, 9, 4, 'C')
	--	,(58, 12, 16, 5, 'C')
	--	,(59, 12, 17, 6, 'C')
	--	,(60, 12, 18, 7, 'C')
	--	,(61, 12, 10, 8, 'C')
	--	,(62, 12, 11, 9, 'C')
	--	,(63, 12, 19, 0, 'T')
	--	,(64, 12, 20, 1, 'T')
	--	,(65, 12, 21, 2, 'T')
	--	,(66, 12, 22, 3, 'T')
	--	,(67, 12, 23, 4, 'T')
	--	,(68, 13, 0, 0, 'C')
	--	,(69, 13, 15, 1, 'C')
	--	,(70, 13, 7, 2, 'C')
	--	,(71, 13, 8, 3, 'C')
	--	,(72, 13, 9, 4, 'C')
	--	,(73, 13, 16, 5, 'C')
	--	,(74, 13, 17, 6, 'C')
	--	,(75, 13, 18, 7, 'C')
	--	,(76, 13, 10, 8, 'C')
	--	,(77, 13, 11, 9, 'C')
	--	,(78, 14, 0, 0, 'C')
	--	,(79, 14, 15, 1, 'C')
	--	,(80, 14, 7, 2, 'C')
	--	,(81, 14, 8, 3, 'C')
	--	,(82, 14, 9, 4, 'C')
	--	,(83, 14, 16, 5, 'C')
	--	,(84, 14, 17, 6, 'C')
	--	,(85, 14, 18, 7, 'C')
	--	,(86, 14, 10, 8, 'C')
	--	,(87, 14, 11, 9, 'C')
	--	,(88, 15, 19, 0, 'T')
	--	,(89, 15, 20, 1, 'T')
	--	,(90, 15, 21, 2, 'T')
	--	,(91, 15, 22, 3, 'T')
	--	,(92, 15, 23, 4, 'T')
	--	,(93, 16, 19, 0, 'T')
	--	,(94, 16, 20, 1, 'T')
	--	,(95, 16, 21, 2, 'T')
	--	,(96, 16, 22, 3, 'T')
	--	,(97, 16, 23, 4, 'T')
	--	,(98, 17, 0, 0, 'C')
	--	,(99, 17, 15, 1, 'C')
	--	,(100, 17, 7, 2, 'C')
	--	,(101, 17, 8, 3, 'C')
	--	,(102, 17, 9, 4, 'C')
	--	,(103, 17, 16, 5, 'C')
	--	,(104, 17, 17, 6, 'C')
	--	,(105, 17, 18, 7, 'C')
	--	,(106, 17, 10, 8, 'C')
	--	,(107, 18, 10, 0, 'C')
	--	,(108, 18, 12, 1, 'C')
	--	,(109, 18, 13, 2, 'C')
	--	,(110, 18, 14, 3, 'C')
	--	,(111, 18, 7, 4, 'C')
	--	,(112, 19, 10, 0, 'C')
	--	,(113, 19, 12, 1, 'C')
	--	,(114, 19, 13, 2, 'C')
	--	,(115, 19, 14, 3, 'C')
	--	,(116, 19, 7, 4, 'C')
	--	,(117, 19, 19, 0, 'T')
	--	,(118, 19, 20, 1, 'T')
	--	,(119, 19, 21, 2, 'T')
	--	,(120, 19, 22, 3, 'T')
	--	,(121, 19, 23, 4, 'T')
	--	,(122, 19, 25, 5, 'T')
	--	,(123, 19, 26, 6, 'T')
	--	,(124, 19, 27, 7, 'T')
	--	,(125, 19, 24, 8, 'T')
	--	,(126, 20, 19, 0, 'T')
	--	,(127, 20, 20, 1, 'T')
	--	,(128, 20, 21, 2, 'T')
	--	,(129, 20, 22, 3, 'T')
	--	,(130, 20, 23, 4, 'T')
	--	,(131, 20, 25, 5, 'T')
	--	,(132, 20, 26, 6, 'T')
	--	,(133, 20, 27, 7, 'T')
	--	,(134, 20, 24, 8, 'T')

	--	MERGE	TCD.[WasherModeMapping]				AS			TARGET
	--	USING	@tempWasherModeMapping					AS			SOURCE
	--		ON	TARGET.ControllerTypeModelToWasherModeId			=			SOURCE.ControllerTypeModelToWasherModeId
	--	WHEN	NOT MATCHED		THEN
	--			INSERT	(ControllerTypeModelToWasherModeId			,ControllerModelControllerTypeMappingId			,WasherModeId, 		WasherModeNumber, WasherType)
	--			VALUES	(SOURCE.ControllerTypeModelToWasherModeId	,SOURCE.ControllerModelControllerTypeMappingId	,SOURCE.WasherModeId, SOURCE.WasherModeNumber, 	SOURCE.WasherType);

	--END



--	*/	uncommented

/*	ControllerModelRegionMapping

Identity column: Id
PRIMARY KEY: Id (Not defined)
NO FKs	(but has RegionId - which is already higher in the order)
No foreign keys reference table 'ControllerModelControllerTypeMapping', or you do not have permissions on referencing tables.

select	*	from	ControllerModelRegionMapping
*/
	BEGIN
		SET			@TableName				=			'ControllerModelRegionMapping'
		PRINT @TableName

		--Declare temp table variable to hold input data
		DECLARE	@tempControllerModelRegionMapping			TABLE	(
				TempId										INT				IDENTITY(1, 1)
			,	Id											INT				NOT	NULL
			,	ControllerModelId							INT				NOT	NULL
			,	RegionId									INT				NOT	NULL
			,	DisplayOrder								INT				NOT	NULL
			)

		--Populate temp table variable with the input data
		INSERT	@tempControllerModelRegionMapping	(
				Id	,ControllerModelId	,RegionId	,DisplayOrder	)
		VALUES	(3	,1	,1	,1	)
			,	(4	,2	,1	,2	)
			,	(5	,3	,1	,3	)
			,	(6	,4	,1	,4	)
			,	(7	,5	,1	,5	)
			,	(8	,6	,1	,6	)
			,	(9	,7	,1	,7	)
			,	(10	,8	,1	,8	)
			,	(11	,9	,1	,9	)
			,	(12	,10	,1	,10	)
			,	(13	,11	,1	,11	)
			,	(14	,12	,1	,12	)
			,	(24	,7	,2	,1	)
			,	(25	,8	,2	,2	)
			,	(26	,9	,2	,3	)
			,	(27	,10	,2	,4	)
			,	(28	,11	,2	,5	)
			,	(29	,5	,2	,6	)
			,	(30	,6	,2	,7	)
			,	(31	,12	,2	,8	)
			,	(32	,1	,2	,9	)
			,	(33	,2	,2	,10	)
			,	(34	,3	,2	,11	)
			,	(35	,4	,2	,12	)
			,	(36 ,13	,1	,13	)
			,	(37 ,14	,1	,14	)
			,	(38 ,13 ,2	,13 )
			,	(39 ,14 ,2	,7  )

		SET		IDENTITY_INSERT		[TCD].ControllerModelRegionMapping	ON

		MERGE	[TCD].ControllerModelRegionMapping			AS			TARGET
		USING	@tempControllerModelRegionMapping		AS			SOURCE
			ON	TARGET.Id								=			SOURCE.Id
		WHEN	NOT MATCHED		THEN
				INSERT	(Id			,ControllerModelId			,RegionId			,DisplayOrder			)
				VALUES	(SOURCE.Id	,SOURCE.ControllerModelId	,SOURCE.RegionId	,SOURCE.DisplayOrder	);

		SET		IDENTITY_INSERT		[TCD].ControllerModelRegionMapping	OFF
	END

	


/*	PlantCategory

Table is referenced by foreign key:	ConduitLocal.dbo.Plant: FK_Plant_RegionMaster
No identity column defined.
PRIMARY KEY: PlantCategoryId

select	Name + 'A'	from	PlantCategory
*/
	BEGIN
		SET			@TableName				=			'PlantCategory'
		PRINT @TableName

		--Declare temp table variable to hold input data
		DECLARE	@tempPlantCategory	TABLE	(
				TempId			INT				IDENTITY(1, 1)
			,	PlantCategoryId	INT				NOT	NULL
			,	Name			NVARCHAR(255)
			)

		--Populate temp table variable with the input data
		INSERT	@tempPlantCategory	(
				PlantCategoryId	,Name	)
		VALUES	 (0  ,'None')
			,	(1	,'Industrial'	)
			,	(2	,'Food Service'	)
			,	(3	,'Medical'		)
			,	(4	,'Hospitality'	)
			,	(5	,'Clean Room'	)
      

		MERGE	[TCD].PlantCategory		AS TARGET
		USING	@tempPlantCategory	AS SOURCE
			ON	TARGET.PlantCategoryId		=			SOURCE.PlantCategoryId
		WHEN	NOT MATCHED		THEN
				INSERT	(PlantCategoryId			,Name)
				VALUES	(SOURCE.PlantCategoryId		,SOURCE.Name);
	END


	--Source System Code

BEGIN
	SET			@TableName				=			'SourceSystem'
	PRINT @TableName

	--Declare temp table variable to hold input data
	DECLARE	@tempSourceSystem			TABLE	(
			[Id]				INT				--IDENTITY(1, 1)
		,   [Code] 				[NVARCHAR](100)  NULL
		,	[Description]		[NVARCHAR](400)	NULL
		,	[RegionCode]		[NVARCHAR](100)	NULL
		)
		--SET IDENTITY_INSERT  @tempSourceSystemCode.Id ON;
	--Populate temp table variable with the input data
	INSERT	@tempSourceSystem		(
			[Id], [Code], [Description], [RegionCode]	)
	 VALUES (1, N'AUS', N'Australia Master Data', N'EMEA')

   ,(2, N'CAN', N'Canadian Data (AS400)', N'NA')

   ,(3, N'CZE', N'Czech Republic Master Data', N'EMEA')

   ,(4, N'EBS', N'Europe Master Data (SAP/EBS)', N'EMEA')

   ,(5, N'EGB', N'Great Britan Master Data', N'EMEA')

   ,(6, N'EGR', N'Greece Master Data ', N'EMEA')

   ,(7, N'EIE', N'Ireland Master Data', N'EMEA')

   ,(8, N'HRV', N'Croatia Master Data ', N'EMEA')

   ,(9, N'HUN', N'Hungary Master Data', N'EMEA')

   ,(10, N'NZL', N'New Zealand Master Data', N'EMEA')

   ,(11, N'STP', N'St. Paul US Data (IDMS) ', N'NA')

   ,(12, N'SVK', N'Slovakia Master Data ', N'EMEA')

	,(13, N'BGR', N'Bulgaria Master Data', N'EMEA')

	,(14, N'SVN', N'Slovenia Master Data', N'EMEA')

	,(15, N'LAT', N'Latvia Master Data', N'EMEA')

	,(16, N'ROU', N'Romania Master Data', N'EMEA')

	,(17, N'SRB', N'Serbia Master Data', N'EMEA')

		--add entries here in the above format

	;
	SET IDENTITY_INSERT  TCD.SourceSystem ON;
	MERGE	TCD.SourceSystem				AS			TARGET
	USING	@tempSourceSystem				AS			SOURCE
		ON	TARGET.[Id]					=			SOURCE.[Id]
		AND	TARGET.[Code]				=			SOURCE.[Code]
		ANd	TARGET.[Description]		=			SOURCE.[Description]
		ANd	TARGET.[RegionCode]			=			SOURCE.[RegionCode]
	WHEN	NOT MATCHED		THEN
			INSERT	([Id]			,[Code]			,[Description]			,[RegionCode])
			VALUES	(SOURCE.[Id]		,SOURCE.[Code]	,SOURCE.[Description]	,SOURCE.[RegionCode])
	;
	SET IDENTITY_INSERT  TCD.SourceSystem OFF;
END


	/*	WasherFlushType	

Identity column: None
PRIMARY KEY: WasherFlushTypeId
FKs	: 

*/
	BEGIN
		SET	@TableName				=			'WasherFlushType'
		PRINT @TableName

		--Declare temp table variable to hold input data
		DECLARE	@tempWasherFlushType									TABLE	(
				TempId											INT				IDENTITY(1, 1)
			,	WasherFlushTypeId								INT				NOT	NULL
			,	WasherFlushType									Nvarchar(100)	NOT	NULL
			,	UNIQUE	(WasherFlushTypeId)
			)

		--Populate temp table variable with the input data
		INSERT	@tempWasherFlushType	(
				WasherFlushTypeId	,WasherFlushType)
		values	
			(1, N'Water')
			
		,	(2, N'Air')
			
		,	(3, N'Water(Valve)')
			
		,   (4, N'Water(ME)')

		MERGE	TCD.[WasherFlushType]					AS			TARGET
		USING	@tempWasherFlushType					AS			SOURCE
			ON	TARGET.WasherFlushTypeId				=			SOURCE.WasherFlushTypeId
		WHEN	NOT MATCHED		THEN
				INSERT	(WasherFlushTypeId			,WasherFlushType)
				VALUES	(SOURCE.WasherFlushTypeId	,SOURCE.WasherFlushType);
	END

/*
BEGIN
	SET	@TableName	=	'ControllerEquipmentTypeModel'
	PRINT @TableName


SET IDENTITY_INSERT [TCD].[ControllerEquipmentTypeModel] ON;

INSERT INTO [TCD].[ControllerEquipmentTypeModel] (
  [ControllerEquipmentTypeModelID]
, [ControllerEquipmentTypeModelName]
, [ArtNumberLang]
, [TeoreticalCalibration]
, [IsMEType]
)
SELECT X.[ControllerEquipmentTypeModelID]
, X.[ControllerEquipmentTypeModelName]
, X.[ArtNumberLang]
, X.[TeoreticalCalibration]
, X.[IsMEType]
FROM (
    SELECT 0 as [ControllerEquipmentTypeModelID], N'Not Used' as [ControllerEquipmentTypeModelName], N'XXXXXX' as [ArtNumberLang], 0 as [TeoreticalCalibration], 0 as [IsMEType] UNION ALL
    SELECT 1, N'Brightwell LF', N'XXXXXX', 200, 0 UNION ALL
    SELECT 2, N'Brightwell HF', N'XXXXXX', 1200, 0 UNION ALL
    SELECT 3, N'EMP 16 l/h', N'149015', 267, 0 UNION ALL
    SELECT 4, N'EMP 25 l/h', N'149115', 417, 0 UNION ALL
    SELECT 5, N'EMP 54 l/h', N'149215', 900, 0 UNION ALL
    SELECT 6, N'EMP 80 l/h', N'149315', 1333, 0 UNION ALL
    SELECT 7, N'EMP 120 l/h', N'149415', 2000, 0 UNION ALL
    SELECT 8, N'EMP 210 l/h', N'150110', 3500, 0 UNION ALL
    SELECT 9, N'Wilden T1', N'203451', 25000, 0 UNION ALL
    SELECT 10, N'Turbo P. 20 l/h', N'1070', 333, 0 UNION ALL
    SELECT 11, N'Turbo P. 50 l/h', N'815', 833, 0 UNION ALL
    SELECT 12, N'Desamix-PLC', N'103540', 2500, 1 UNION ALL
    SELECT 13, N'Desamix-WTF', N'103545', 2500, 1 UNION ALL
    SELECT 14, N'Compactomix I / II', N'XXXX', 800, 1 UNION ALL
    SELECT 15, N'Compactomix III', N'XXXX', 800, 1 UNION ALL
    SELECT 16, N'Compactomix IV-PLC', N'1053', 800, 1 UNION ALL
    SELECT 17, N'Compactomix IV-WTF', N'105310', 800, 1 UNION ALL
    SELECT 18, N'Stock-Solution ring line', N'XXXX', 5400, 1 UNION ALL
    SELECT 19, N'Stock-Solution Dead-End', N'203451', 2500, 1 UNION ALL
    SELECT 20, N'Washomix', N'103810', 500, 1 UNION ALL
    SELECT 21, N'Examix', N'xxxx', 2500, 1
) X
LEFT JOIN [TCD].[ControllerEquipmentTypeModel] Y
ON X.[ControllerEquipmentTypeModelID] = Y.[ControllerEquipmentTypeModelID]
WHERE Y.[ControllerEquipmentTypeModelID] IS NULL 
SET IDENTITY_INSERT [TCD].[ControllerEquipmentTypeModel] OFF;



END
*/


BEGIN 

	SET	@TableName	=	'ControllerEquipmentValves'
	PRINT @TableName

INSERT INTO [TCD].[ControllerEquipmentValves]([ControllerEquipmentValveID], [ValveName])
SELECT X.[ControllerEquipmentValveID], X.[ValveName]
FROM (
    SELECT 0 AS [ControllerEquipmentValveID], N'Not Used' AS [ValveName] UNION ALL
    SELECT 1, N'Valve 1 Main Equipment 1' UNION ALL
    SELECT 2, N'Valve 2 Main Equipment 1' UNION ALL
    SELECT 3, N'Valve 3 Main Equipment 1' UNION ALL
    SELECT 4, N'Valve 4 Main Equipment 1' UNION ALL
    SELECT 5, N'Valve 5 Main Equipment 1' UNION ALL
    SELECT 6, N'Valve 6 Main Equipment 1' UNION ALL
    SELECT 7, N'Pump 1 direct' UNION ALL
    SELECT 8, N'Pump 2 direct' UNION ALL
    SELECT 9, N'Pump 3 direct' UNION ALL
    SELECT 10, N'Pump 4 direct' UNION ALL
    SELECT 11, N'Pump 5 direct' UNION ALL
    SELECT 12, N'Pump 6 direct' UNION ALL
    SELECT 13, N'Pump 7 direct' UNION ALL
    SELECT 14, N'Pump 8 direct' UNION ALL
    SELECT 15, N'Pump 9 direct' UNION ALL
    SELECT 16, N'Pump 10 direct' UNION ALL
    SELECT 17, N'Pump 11 direct' UNION ALL
    SELECT 18, N'Pump 12 direct' UNION ALL
    SELECT 19, N'Valve 1 Main Equipment 2' UNION ALL
    SELECT 20, N'Valve 2 Main Equipment 2' UNION ALL
    SELECT 21, N'Valve 3 Main Equipment 2' UNION ALL
    SELECT 22, N'Valve 4 Main Equipment 2' UNION ALL
    SELECT 23, N'Valve 5 Main Equipment 2' UNION ALL
    SELECT 24, N'Valve 6 Main Equipment 2' UNION ALL
    SELECT 25, N'Pump X Valve 1' UNION ALL
    SELECT 26, N'Pump X Valve 2' UNION ALL
    SELECT 27, N'Pump X Valve 3' UNION ALL
    SELECT 28, N'Pump X Valve 4' UNION ALL
    SELECT 29, N'Pump X Valve 5' UNION ALL
    SELECT 30, N'Pump X Valve 6' UNION ALL
    SELECT 31, N'Pump X Valve 7' UNION ALL
    SELECT 32, N'Pump X Valve 8'
) X
LEFT JOIN [TCD].[ControllerEquipmentValves] Y
ON X.ControllerEquipmentValveID = Y.ControllerEquipmentValveID
WHERE Y.ControllerEquipmentValveID IS NULL;

END

/*	ControllerEquipmentTypeModel

Identity: FinnisherTypeId
PRIMARY KEY: None
FK:	None

Table is referenced by foreign key:	None

*/

BEGIN
		SET	@TableName 			=			'ControllerEquipmentTypeModel'
		PRINT @TableName

--Declare temp table variable to hold input data
DECLARE	@tempControllerEquipmentTypeModel			TABLE	(
	TempId								INT				IDENTITY(1, 1)
,	ControllerEquipmentTypeModelID		INT				PRIMARY	KEY
,	ControllerEquipmentTypeModelName	NVARCHAR(200)	NOT NULL
,	[ArtNumberLang]						NVARCHAR(50)	NULL
,	TeoreticalCalibration				INT				NULL
,	IsMEType							BIT				NULL  DEFAULT('FALSE')
)

--Populate temp table variable with the input data
INSERT	@tempControllerEquipmentTypeModel		(
ControllerEquipmentTypeModelID	,[ControllerEquipmentTypeModelName]	,ArtNumberLang, TeoreticalCalibration,IsMEType	) VALUES
 (0,	'Not Used',			'XXXXXX',		0,		'False')
,(1,	'Brightwell LF',	'XXXXXX',		200,	'False')
,(2,	'Brightwell HF',	'XXXXXX',		1200,	'False')
,(3,	'EMP 16 l/h',		'149015',		267,	'False')
,(4,	'EMP 25 l/h',		'149115',		417,	'False')
,(5,	'EMP 54 l/h',		'149215',		900,	'False')
,(6,	'EMP 80 l/h',		'149315',		1333,	'False')
,(7,	'EMP 120 l/h',		'149415',		2000,	'False')
,(8,	'EMP 210 l/h',		'150110',		3500,	'False')
,(9,	'Wilden T1',		'203451',		25000,	'False')
,(10,	'Turbo P. 20 l/h',	'1070',			333,	'False')
,(11,	'Turbo P. 50 l/h',	'815',			833,	'False')
,(12,	'Desamix/Examix',	NULL,			NULL,	'True')
,(13,	'Compactomix', 		NULL,			NULL,	'True')
,(14,	'Stock-Solution', 	NULL,			NULL,	'True')
,(15,	'Washomix', 	NULL,			NULL,	'True')
,(16,	'Pump', 	NULL,			NULL,	'True')

SET IDENTITY_INSERT [TCD].[ControllerEquipmentTypeModel] ON;
MERGE	TCD.ControllerEquipmentTypeModel			AS			TARGET
USING	@tempControllerEquipmentTypeModel			AS			SOURCE
ON	TARGET.ControllerEquipmentTypeModelID		=			SOURCE.ControllerEquipmentTypeModelID
WHEN	NOT MATCHED		THEN
INSERT	(ControllerEquipmentTypeModelID			,[ControllerEquipmentTypeModelName]	,ArtNumberLang, TeoreticalCalibration,IsMEType		)
VALUES	(SOURCE.ControllerEquipmentTypeModelID		,[ControllerEquipmentTypeModelName]	,ArtNumberLang, TeoreticalCalibration,IsMEType	)
;
SET IDENTITY_INSERT [TCD].[ControllerEquipmentTypeModel] OFF;
END


-- INSERT WasherMode
BEGIN
		SET	@TableName 				=			'WasherMode'
		PRINT @TableName

		--Declare temp table variable to hold input data
		DECLARE	@tempWasherMode									TABLE	(
				TempId											INT				IDENTITY(1, 1)
			,	WasherModeId									TINYINT			NOT	NULL
			,	WasherModeName									NVARCHAR(200)	NOT	NULL
			,	ResourceKey										NVARCHAR(200)	NULL

			,	UNIQUE	(WasherModeId)
			)

		--Populate temp table variable with the input data
		INSERT	@tempWasherMode	(WasherModeId	,WasherModeName,	ResourceKey	)
		VALUES
		 (0, N'Off', N'FIELD_OFF')
		,(1, N'Binary', N'FIELD_BINARY')
		,(2, N'Timed', N'FIELD_TIMED')
		,(3, N'Timed & Binary', N'FIELD_TIMED&BINARY')
		,(4, N'Timed & Timed', N'FIELD_TIMED&TIMED')	
		,(5, N'1''s 10''s & 100''s', N'FIELD_1S10S&100S')
		,(6, N'Prg = Binary , Step = One Signal , Start generated by first Step', N'FIELD_PRGBINARYSTEPONESIGNALSTARTGENERATEDBYFIRSTSTEP')
		,(7, N'Prg and Start = Miniterminal , Step = One Signal', N'FIELD_PRGANDSTARTMINITERMINALSTEPONESIGNAL')
		,(8, N'Prg = Miniterminal , Step = One Signal , Start generated by first Step', N'FIELD_PRGMINITERMINALSTEPONESIGNALSTARTGENERATEDBYFIRSTSTEP')
		,(9, N'Prg = Miniterminal , Step = Binary , Start generated by first Step', N'FIELD_PRGMINITERMINALSTEPBINARYSTARTGENERATEDBYFIRSTSTEP')
		,(10, N'Prg and Start = Binary , Step = One Signal , Start not generated by first Step', N'FIELD_PRGANDSTARTBINARYSTEPONESIGNALSTARTNOTGENERATEDBYFIRSTSTEP')
		,(11, N'TOM mode only', N'FIELD_TOMMODEONLY')
		,(12, N'Prg = Binary, Step = Binary', N'FIELD_PRGBINARYSTEPBINARY')
		,(13, N'Prg = Miniterminal , Step = One Signal', N'FIELD_PRGMINITERMINALSTEPONESIGNAL')
		,(14, N'Prg = Miniterminal , Step = Binary', N'FIELD_PRGMINITERMINALSTEPBINARY')	
		,(15, N'Prg and Start = Binary , Step = One Signal , Start generate first Step', N'FIELD_PRGANDSTARTBINARYSTEPONESIGNALSTARTGENERATEDBYFIRSTSTEP')
		,(16, N'Prg = Binary , Step = One Signal , Start generated by first Step', N'FIELD_PRGBINARYSTEPONESIGNALSTARTGENERATEDBYFIRSTSTEP')
		,(17, N'Prg = WTC-Selector , Step = One Signal , Start generated by first Step', N'FIELD_PRGWTCSELECTORSTEPONESIGNALSTARTGENERATEDBYFIRSTSTEP')
		,(18, N'Prg and Start = WTC-Selector , Step = One Signal', N'FIELD_PRGANDSTARTWTCSELECTORSTEPONESIGNAL')
		,(19, N'Prg = WTC-Selector , Step = Binary , Start generated by firs Step', N'FIELD_PRGWTCSELECTORSTEPBINARYSTARTGENERATEDBYFIRSTSTEP')
		,(20, N'Program = Binary, Transfer conveyor = Transfer Tunnel', N'FIELD_PROGRAMBINARYTRANSFERCONVEYORTRANSFERTUNNEL')
		,(21, N'Program = Miniterminal, Transfer conveyor = Miniterminal', N'FIELD_PROGRAMMINITERMINALTRANSFERCONVEYORMINITERMINAL')
		,(22, N'Program = Binary, Transfer conveyor = Dedicated input', N'FIELD_PROGRAMBINARYTRANSFERCONVEYORDEDICATEDINPUT')
		,(23, N'Program = Miniterminal, Transfer conveyor = Transfer Tunnel', N'FIELD_PROGRAMMINITERMINALTRANSFERCONVEYORTRANSFERTUNNEL')
		,(24, N'Program = Miniterminal, Transfer conveyor = Dedicated input', N'FIELD_PROGRAMMINITERMINALTRANSFERCONVEYORDEDICATEDINPUT')
		,(25, N'Carbonell', N'FIELD_CARBONELL')
		,(26, N'Kannegiesser Ethernet communication', N'FIELD_KANNEGIESSERETHERNETCOMMUNICATION')
		,(27, N'Senking Ethernet communication', N'FIELD_SENKINGETHERNETCOMMUNICATION')
		,(28, N'Program = Miniterminal (including program 0), Transfer conveyor = Miniterminal', N'FIELD_PROGRAMMINITERMINALINCLUDINGPROGRAM0TRANSFERCONVEYORMINITERMINAL')
		MERGE	TCD.[WasherMode]				AS			TARGET
		USING	@tempWasherMode					AS			SOURCE
			ON	TARGET.WasherModeId								=			SOURCE.WasherModeId
		WHEN	NOT MATCHED		THEN
				INSERT	(WasherModeId			,WasherModeName			,ResourceKey		)
				VALUES	(SOURCE.WasherModeId	,SOURCE.WasherModeName	,SOURCE.ResourceKey	);
END


-- INSERT WasherModeMapping
BEGIN
		SET	@TableName	=			'WasherModeMapping'
		PRINT @TableName

		--Declare temp table variable to hold input data
		DECLARE	@tempWasherModeMapping									TABLE	(
				TempId											INT				IDENTITY(1, 1)
			,	ControllerTypeModelToWasherModeId				SMALLINT		NOT	NULL
			,	ControllerModelControllerTypeMappingId			int				NOT	NULL
			,	WasherModeId									int				NULL
			,	WasherModeNumber								TINYINT			NULL
			,	WasherType										nchar(20)		NULL
			,	UNIQUE	(ControllerTypeModelToWasherModeId)
			)

		--Populate temp table variable with the input data
		INSERT	@tempWasherModeMapping	(ControllerTypeModelToWasherModeId	,ControllerModelControllerTypeMappingId	,WasherModeId ,WasherModeNumber ,WasherType)
		VALUES
		 (1, 1, 0, 1, 'C')
		,(2, 1, 1, 2, 'C')
		,(3, 1, 2, 3, 'C')
		,(4, 1, 3, 4, 'C')
		,(5, 1, 4, 5, 'C')
		,(6, 2, 0, 1, 'C')
		,(7, 2, 1, 2, 'C')
		,(8, 2, 2, 3, 'C')
		,(9, 2, 3, 4, 'C')
		,(10, 2, 4, 5, 'C')
		,(11, 2, 5, 6, 'C')
		,(12, 3, 0, 1, 'C')
		,(13, 3, 1, 2, 'C')
		,(14, 3, 2, 3, 'C')
		,(15, 3, 3, 4, 'C')
		,(16, 3, 4, 5, 'C')
		,(17, 4, 0, 1, 'C')
		,(18, 4, 1, 2, 'C')
		,(19, 4, 2, 3, 'C')
		,(20, 4, 3, 4, 'C')
		,(21, 4, 4, 5, 'C')
		,(22, 4, 5, 6, 'C')
		,(23, 5, 0, 1, 'T')
		,(24, 5, 1, 2, 'T')
		,(25, 5, 2, 3, 'T')
		,(26, 5, 3, 4, 'T')
		,(27, 5, 4, 5, 'T')
		,(28, 10, 0, 0, 'C')
		,(29, 10, 6, 1, 'C')
		,(30, 10, 7, 2, 'C')
		,(31, 10, 8, 3, 'C')
		,(32, 10, 9, 4, 'C')
		,(33, 10, 10, 5, 'C')
		,(34, 10, 11, 6, 'C')
		,(35, 10, 0, 0, 'T')
		,(36, 10, 20, 1, 'T')
		,(37, 10, 21, 2, 'T')
		,(38, 10, 22, 3, 'T')
		,(39, 10, 23, 4, 'T')
		,(40, 10, 24, 5, 'T')
		,(41, 10, 25, 6, 'T')
		,(42, 10, 26, 7, 'T')
		,(43, 11, 0, 0, 'C')
		,(44, 11, 15, 1, 'C')
		,(45, 11, 7, 2, 'C')
		,(46, 11, 8, 3, 'C')
		,(47, 11, 9, 4, 'C')
		,(48, 11, 16, 5, 'C')
		,(49, 11, 17, 6, 'C')
		,(50, 11, 18, 7, 'C')
		,(51, 11, 10, 8, 'C')
		,(52, 11, 11, 9, 'C')
		,(53, 12, 0, 0, 'C')
		,(54, 12, 15, 1, 'C')
		,(55, 12, 7, 2, 'C')
		,(56, 12, 8, 3, 'C')
		,(57, 12, 9, 4, 'C')
		,(58, 12, 16, 5, 'C')
		,(59, 12, 17, 6, 'C')
		,(60, 12, 18, 7, 'C')
		,(61, 12, 10, 8, 'C')
		,(62, 12, 11, 9, 'C')
		,(63, 12, 19, 0, 'T')
		,(64, 12, 20, 1, 'T')
		,(65, 12, 21, 2, 'T')
		,(66, 12, 22, 3, 'T')
		,(67, 12, 23, 4, 'T')
		,(68, 13, 0, 0, 'C')
		,(69, 13, 15, 1, 'C')
		,(70, 13, 7, 2, 'C')
		,(71, 13, 8, 3, 'C')
		,(72, 13, 9, 4, 'C')
		,(73, 13, 16, 5, 'C')
		,(74, 13, 17, 6, 'C')
		,(75, 13, 18, 7, 'C')
		,(76, 13, 10, 8, 'C')
		,(77, 13, 11, 9, 'C')
		,(78, 14, 0, 0, 'C')
		,(79, 14, 15, 1, 'C')
		,(80, 14, 7, 2, 'C')
		,(81, 14, 8, 3, 'C')
		,(82, 14, 9, 4, 'C')
		,(83, 14, 16, 5, 'C')
		,(84, 14, 17, 6, 'C')
		,(85, 14, 18, 7, 'C')
		,(86, 14, 10, 8, 'C')
		,(87, 14, 11, 9, 'C')
		,(88, 15, 0, 0, 'C')
		,(89, 15, 15, 1, 'C')
		,(90, 15, 7, 2, 'C')
		,(91, 15, 8, 3, 'C')
		,(92, 15, 9, 4, 'C')
		,(93, 15, 16, 5, 'C')
		,(94, 15, 17, 6, 'C')
		,(95, 15, 18, 7, 'C')
		,(96, 15, 10, 8, 'C')
		,(97, 15, 11, 9, 'C')
		,(98, 15, 19, 0, 'T')
		,(99, 15, 20, 1, 'T')
		,(100, 15, 21, 2, 'T')
		,(101, 15, 22, 3, 'T')
		,(102, 15, 23, 4, 'T')
		,(103, 16, 0, 0, 'C')
		,(104, 16, 15, 1, 'C')
		,(105, 16, 7, 2, 'C')
		,(106, 16, 8, 3, 'C')
		,(107, 16, 9, 4, 'C')
		,(108, 16, 16, 5, 'C')
		,(109, 16, 17, 6, 'C')
		,(110, 16, 18, 7, 'C')
		,(111, 16, 10, 8, 'C')
		,(112, 16, 11, 9, 'C')
		,(113, 16, 19, 0, 'T')
		,(114, 16, 20, 1, 'T')
		,(115, 16, 21, 2, 'T')
		,(116, 16, 22, 3, 'T')
		,(117, 16, 23, 4, 'T')
		,(118, 17, 0, 0, 'C')
		,(119, 17, 15, 1, 'C')
		,(120, 17, 7, 2, 'C')
		,(121, 17, 8, 3, 'C')
		,(122, 17, 9, 4, 'C')
		,(123, 17, 16, 5, 'C')
		,(124, 17, 17, 6, 'C')
		,(125, 17, 18, 7, 'C')
		,(126, 17, 10, 8, 'C')
		,(127, 18, 10, 0, 'C')
		,(128, 18, 12, 1, 'C')
		,(129, 18, 13, 2, 'C')
		,(130, 18, 14, 3, 'C')
		,(131, 18, 7, 4, 'C')
		,(132, 19, 10, 0, 'C')
		,(133, 19, 12, 1, 'C')
		,(134, 19, 13, 2, 'C')
		,(135, 19, 14, 3, 'C')
		,(136, 19, 7, 4, 'C')
		,(137, 19, 19, 0, 'T')
		,(138, 19, 20, 1, 'T')
		,(139, 19, 21, 2, 'T')
		,(140, 19, 22, 3, 'T')
		,(141, 19, 23, 4, 'T')
		,(142, 19, 25, 5, 'T')
		,(143, 19, 26, 6, 'T')
		,(144, 19, 27, 7, 'T')
		,(145, 19, 24, 8, 'T')
		,(146, 20, 19, 0, 'T')
		,(147, 20, 20, 1, 'T')
		,(148, 20, 21, 2, 'T')
		,(149, 20, 22, 3, 'T')
		,(150, 20, 23, 4, 'T')
		,(151, 20, 25, 5, 'T')
		,(152, 20, 26, 6, 'T')
		,(153, 20, 27, 7, 'T')
		,(154, 20, 24, 8, 'T')
		MERGE	TCD.[WasherModeMapping]				AS			TARGET
		USING	@tempWasherModeMapping					AS			SOURCE
			ON	TARGET.ControllerTypeModelToWasherModeId			=			SOURCE.ControllerTypeModelToWasherModeId
		WHEN	NOT MATCHED		THEN
				INSERT	(ControllerTypeModelToWasherModeId			,ControllerModelControllerTypeMappingId			,WasherModeId, 		WasherModeNumber, WasherType)
				VALUES	(SOURCE.ControllerTypeModelToWasherModeId	,SOURCE.ControllerModelControllerTypeMappingId	,SOURCE.WasherModeId, SOURCE.WasherModeNumber, 	SOURCE.WasherType);

	END


-- INSERT FormulaSegments
BEGIN
		SET	@TableName	=			'FormulaSegments'
		PRINT @TableName

		--Declare temp table variable to hold input data
		DECLARE	@tempFormulaSegments									TABLE	(
				TempId							INT				IDENTITY(1, 1)
			,	[FormulaSegmentID]				[int]			NOT NULL
			,	[SegmentName]					[varchar](128)	NOT NULL
			,	[LastModifiedTime]				[datetime]		NOT NULL
			,	[Is_Deleted]					[bit]			NOT NULL			
			)

		--Populate temp table variable with the input data
		INSERT	@tempFormulaSegments	([FormulaSegmentID]	,[SegmentName], [LastModifiedTime],[Is_Deleted])
		VALUES	(1, N'Health Care', CAST(0x0000A58A009FE3B7 AS DateTime), 0)
		 ,		(2, N'Hospitality', CAST(0x0000A58A009FED45 AS DateTime), 0)
		 ,		(3, N'Food & Beverage', CAST(0x0000A58A009FF819 AS DateTime), 0)
		 SET	IDENTITY_INSERT	TCD.FormulaSegments	ON
		MERGE	TCD.[FormulaSegments]						AS			TARGET
		USING	@tempFormulaSegments						AS			SOURCE
			ON	TARGET.FormulaSegmentID			=			SOURCE.FormulaSegmentID
		WHEN	NOT MATCHED		THEN
				INSERT	([FormulaSegmentID]	,[SegmentName], [LastModifiedTime],[Is_Deleted])
				VALUES	(SOURCE.FormulaSegmentID	,SOURCE.SegmentName	,SOURCE.LastModifiedTime, SOURCE.Is_Deleted);
				SET	IDENTITY_INSERT	TCD.FormulaSegments	ON

	END

END	TRY
BEGIN	CATCH
INSERT	#Errors_ConduitLocalMasterDataSetup
SELECT	@TableName			AS			TableName
,	ERROR_NUMBER()		AS			ErrorNumber
,	ERROR_MESSAGE()		AS			ErrorMessage
,	ERROR_SEVERITY()	AS			ErrorSeverity
,	ERROR_STATE()		AS			ErrorState
,	ERROR_PROCEDURE()	AS			ErrorProcedure
,	ERROR_LINE()		AS			ErrorLine
END	CATCH

ExitScript_ConduitLocalMasterData:
--Select out the errors, if any...
SELECT	*
FROM	#Errors_ConduitLocalMasterDataSetup

--drop	temp	table...
IF	OBJECT_ID('tempdb..#Errors_ConduitLocalMasterDataSetup')	IS NOT	NULL
DROP	TABLE	#Errors_ConduitLocalMasterDataSetup


PRINT	'Exiting ConduitLocalMasterData script execution...'

