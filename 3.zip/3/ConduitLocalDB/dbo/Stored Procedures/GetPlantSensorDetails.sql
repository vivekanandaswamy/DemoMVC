﻿/*      
 ==========================================================================================    
 Purpose:  Fetching the Plant Sensor List.      
	
 Author:  Premchand Yelavarthi      
	
 --------------------------------------------------------------      
 Aug-13-2014 ENT: Initial version.      
 ==========================================================================================    
*/ 
CREATE PROCEDURE [TCD].[GetPlantSensorDetails] (@SensorID            int = NULL, 
												@EcolabAccountNumber nvarchar(1000)) 
AS 
  BEGIN 
	  SET nocount ON; 

	  Declare @ControllerID int = NULL 

	  Select @ControllerID = ControllerID 
	  from   [TCD].Sensor 
	  where  SensorId = @SensorID 

	  DECLARE @WaterandEnergyGroupId INT = (SELECT TOP (1) MG.Id 
		 FROM   TCD.MachineGroup MG 
				INNER JOIN TCD.MachineGroupType MGT 
						ON MGT.Id = MG.GroupTypeId 
		 WHERE  MGT.Id = 5); 

	  Select S.SensorId, 
			 S.Description, 
			 S.SensorType, 
			 (Select Name 
			  from   [TCD].SensorTypemaster rm 
			  where  rm.Resourceid = S.SensorType)     as SensorTypeName, 
			 S.EcolabAccountNumber, 
			 CASE 
			   WHEN S.Machinecompartment IS NULL THEN 
				 CASE 
				   WHEN S.IsPress = 1 THEN 1 
				   ELSE 0 
				 END 
			   ELSE S.Machinecompartment 
			 END                                       AS Machinecompartment, 
			 CASE 
			   WHEN S.MachineCompartment IS NULL 
					AND ( S.IsPress = 0 
						   OR S.IsPress IS NULL ) THEN 'ALL' 
			   WHEN (SELECT DISTINCT Istunnel 
					 FROM   [TCD].machinesetup M 
					 WHERE  M.groupId = S.GroupId) = 1 THEN 
				 CASE 
				   WHEN S.MachineCompartment IS NULL 
						AND S.IsPress = 1 THEN 'Press' 
				   ELSE 'Compartment' 
						+ Cast( S.Machinecompartment AS varchar( 100)) 
				 END 
			   WHEN (SELECT DISTINCT Istunnel 
					 FROM   [TCD].machinesetup M 
					 WHERE  M.groupId = S.GroupId) = 0 THEN (SELECT Cast (WS.PlantWasherNumber AS nvarchar)
																	+ ':' + MachineName 
															 FROM   [TCD].MachineSetup M 
																	INNER JOIN TCD.Washer WS 
																			ON M.WasherId = WS.WasherId
															 WHERE  M.GroupId = S.GroupId 
																	AND M.WasherId = S.MachineCompartment)
			   WHEN (SELECT DISTINCT GroupTypeId 
					 FROM   [TCD].MachineGroup GT 
					 WHERE  GT.Id = S.GroupId) = 3 THEN (SELECT D.Description 
														 FROM   [TCD].Dryers D 
														 WHERE  D.DryerGroupId = S.GroupId 
																AND D.Id = S.MachineCompartment)
			   WHEN (SELECT DISTINCT GroupTypeId 
					 FROM   [TCD].MachineGroup GT 
					 WHERE  GT.Id = S.GroupId) = 4 THEN (SELECT F.Name 
														 FROM   [TCD].Finnishers F 
														 WHERE  F.FinnisherGroupId = S.GroupId
																AND F.FinnisherId = S.MachineCompartment)
			   WHEN (SELECT DISTINCT GroupTypeId 
					 FROM   [TCD].MachineGroup GT 
					 WHERE  GT.Id = S.GroupId) = 5 THEN (SELECT DeviceName 
														 FROM   TCD.WaterAndEnergy WE 
														 WHERE  S.GroupId = @WaterandEnergyGroupId
																AND WE.DeviceNumber = S.MachineCompartment
																AND WE.Is_deleted = 0) 
			   WHEN (SELECT MM.MachineCompartment 
					 FROM   [TCD].Meter MM 
					 WHERE  MM.GroupId = S.GroupId) = 0 THEN 'Press' 
			 END                                       AS MachinecompartmentName, 
			 CC.ControllerID, 
			 CC.Name                                   AS ControllerName, 
			 CC.ControllerModelId, 
			 CM.RegionId                               AS ControllerRegionId, 
			 CT.Id                                     AS ControllerTypeId, 
			 CT.Name                                   AS ControllerType, 
			 S.OutputType, 
			 S.ChemicalforChart, 
			 (Select DISTINCT p.Name 
			  from   [TCD].productmaster P 
			  where  P.productId = S.ChemicalforChart) as ChemicalforChartName, 
			 s.UOM, 
			 'S.UOMName'                               as UOMName, 
			 S.DashboardActualValue, 
			 ( CASE 
				 WHEN S.groupID IS NULL 
					  AND S.IsPlant = 1 THEN 1 
				 ELSE (SELECT G.Id 
					   FROM   [TCD].MachineGroup G 
					   WHERE  G.Id = S.groupID 
							  AND G.EcolabAccountNumber = @EcolabAccountNumber) 
			   END )                                   AS GroupId, 
			 ( CASE 
				 WHEN ( S.groupID IS NULL 
						AND S.MachineCompartment IS NULL 
						AND S.IsPlant = 1 ) THEN 'Plant' 
				 ELSE (SELECT GroupDescription 
					   FROM   [TCD].MachineGroup G 
					   WHERE  G.Id = S.groupID 
							  AND G.EcolabAccountNumber = @EcolabAccountNumber) 
			   END )                                   AS SensorLocation, 
			 (SELECT MTS.TagAddress 
			  FROM   TCD.ModuleTags MTS 
			  WHERE  MTS.TagType = 'Tag_MPLC' 
					 AND MTS.ModuleID = SensorId 
					 AND MTS.ModuleTypeId = 3 
					 AND MTS.Active = 1)               AS AnalogueInputNumber, 
			 S.Calibration4mA, 
			 S.Calibration20mA, 
			 (SELECT MTS.TagAddress 
			  FROM   TCD.ModuleTags MTS 
			  WHERE  MTS.TagType = 'Tag_SC4' 
					 AND MTS.ModuleID = SensorId 
					 AND MTS.ModuleTypeId = 3 
					 AND MTS.Active = 1)               AS CalibrationTag4, 
			 (SELECT MTS.TagAddress 
			  FROM   TCD.ModuleTags MTS 
			  WHERE  MTS.TagType = 'Tag_SC20' 
					 AND MTS.ModuleID = SensorId 
					 AND MTS.ModuleTypeId = 3 
					 AND MTS.Active = 1)               AS CalibrationTag20, 
			 S.LastSyncTime, 
			 S.LastModifiedTime, 
			 s.SensorNum, 
			 s.AlarmEnable, 
			 s.MinimumAlarmValue, 
			 s.MaximumAlarmValue, 
			 s.AnalogueInputNumber, 
			 M.MachineInternalId, 
			 Cast(ISNULL(csd.Value, 0) AS BIT)         AS ISWaterEnergyLogSel, 
			 wg.WasherGroupTypeId ,
			 S.ControllerEquipmentID
	  from   [TCD].Sensor S 
			 LEFT JOIN tcd.WasherGroup wg 
					ON wg.WasherGroupId = S.GroupId 
			 LEFT JOIN [TCD].ConduitController CC 
					ON CC.ControllerId = S.ControllerID 
			 LEFT JOIN [TCD].ControllerModel CM 
					ON CM.Id = CC.ControllerModelId 
			 LEFT JOIN [TCD].ControllerType CT 
					ON CT.Id = CC.ControllerTypeId 
			 LEFT JOIN TCD.ControllerSetupData csd 
					ON csd.ControllerId = S.ControllerID 
					   AND csd.FieldId = 473 
					   AND csd.FieldGroupId = 20 
					   AND csd.EcolabAccountNumber = S.EcolabAccountNumber 
			 LEFT JOIN TCD.MachineSetup M 
					on m.WasherId = s.MachineCompartment 
	  Where  Is_Deleted = 0 

	  SET NOCOUNT OFF; 
  END