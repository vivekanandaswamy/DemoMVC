CREATE PROCEDURE [TCD].[GetReportRibbonDetails] 
(
			@ReportId Int = NULL
)
AS   

BEGIN   
SET NOCOUNT ON
SELECT 
		  RRO.Id,
		  RRO.Name
	    FROM [TCD].ReportRibbonOption RRO
			 INNER JOIN 
			 [TCD].ReportRibbonOptionMapping RRM ON RRO.Id = RRM.RibbonOptionId
	    WHERE RRM.ReportId = @ReportId
SET NOCOUNT OFF
END