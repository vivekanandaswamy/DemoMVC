﻿/*	
Purpose					:	To populate the drop-down (Model-Size) in the Washer setup --> Tunnel-General tab

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version

*/

CREATE	PROCEDURE	[TCD].[GetWasherModelSize]
					@RegionId							SMALLINT
				,	@WasherModelName					NVARCHAR(50)
				,	@ModelType							VARCHAR(30)
				,   @IsDelete							bit				=	'False'
AS
BEGIN

SET	NOCOUNT	ON


DECLARE	@ModelTypeId					TINYINT = NULL

--ModelType to MdelTypeID
IF		@ModelType			=	'Conventional'
	BEGIN
		SET	@ModelTypeId	=	1
	END
ELSE
	BEGIN
		SET	@ModelTypeId	=	2
	END

select	distinct
		t1.WasherModelId
	,	t1.WasherModelName
	,	ISNULL(t1.WasherSize, N'Un-defined')
	,	t1.MyServiceMCHId
from	[TCD].WasherModelSize						t0
join	[TCD].WasherModelSize						t1
	on	t0.WasherModelName					=			t1.WasherModelName
	and	t0.RegionId							=			t1.RegionId
	and	t0.ModelTypeId						=			t1.ModelTypeId
where	t0.RegionId							=			@RegionId
	and	t0.WasherModelName					=			@WasherModelName					--'KANNEGIESSER 169'
	and	t0.ModelTypeId						=			@ModelTypeId
	and (t0.Is_Deleted = 'False' OR t0.Is_Deleted = @IsDelete) 
	and (t1.Is_Deleted = 'False' OR t1.Is_Deleted = @IsDelete)


SET	NOCOUNT	OFF

END
