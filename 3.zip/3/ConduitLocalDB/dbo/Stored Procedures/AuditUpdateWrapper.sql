﻿--sp_who2	'active'
/*
CREATE	TYPE	udttUpdateSet
AS	TABLE	(	ReferenceID					INT
			,	ColumnName					SYSNAME
			,	OldValue					NVARCHAR(1000)
			,	NewValue					NVARCHAR(1000)
			)
GO

DROP	TYPE	udttUpdateSet

*/

CREATE	PROCEDURE	[TCD].AuditUpdateWrapper	(
					@TableName				SYSNAME
				,	@UpdateSetList			[TCD].UpdateSet	READONLY
				,	@UserId					INT
				)
AS
SET NOCOUNT ON
BEGIN

--Local variable declarations:
DECLARE			@ColumnName					SYSNAME
			,	@ReferenceId				INT
			,	@OldValue					NVARCHAR(1000)
			,	@NewValue					NVARCHAR(1000)
			,	@Id							INT

CREATE	TABLE	#UpdateList				(
				Id							INT					IDENTITY(1, 1)
			,	ReferenceID					INT
			,	ColumnName					SYSNAME
			,	OldValue					NVARCHAR(1000)
			,	NewValue					NVARCHAR(1000)
			)


INSERT	#UpdateList	(
		ReferenceID		,ColumnName		,OldValue	,NewValue	)
SELECT	L.ReferenceID	,L.ColumnName	,L.OldValue	,L.NewValue
FROM	@UpdateSetList	L
ORDER BY
		L.ReferenceID,	L.ColumnName

WHILE	EXISTS	(SELECT	1	FROM	#UpdateList)
BEGIN
	   SELECT	@Id							=				L.Id
			,	@ReferenceId				=				L.ReferenceID
			,	@ColumnName					=				L.ColumnName
			,	@OldValue					=				L.OldValue
			,	@NewValue					=				L.NewValue
	   FROM		#UpdateList					L
	   ORDER BY
				L.ReferenceID, L.ColumnName

	   --Call the existing Update-audit SP
	   EXEC		[TCD].[AuditingChangedDetails]
				@table_Name					=				@TableName
			,	@ReferenceID				=				@ReferenceId
			,	@Column_name				=				@ColumnName
			,	@OldValue					=				@OldValue
			,	@Newvalue					=				@NewValue
			,	@UserId						=				@UserId

		DELETE	#UpdateList
		WHERE	Id							=				@Id
END

RETURN	0

END