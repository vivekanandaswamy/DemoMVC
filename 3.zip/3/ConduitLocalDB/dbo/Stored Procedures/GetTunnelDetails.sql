﻿/*  
 ==========================================================================================  
 Purpose:  Fetching the Tunnel Details

 Author:  Premchand Yelavarthi  

 --------------------------------------------------------------  
 August-01-2014 ENT: Initial version.  
 ==========================================================================================  
tcd.[Gettunneldetails]
 */
 CREATE PROCEDURE [TCD].[GetTunnelDetails]
AS 
 BEGIN 
      SET nocount ON; 
	  Select m.WasherId AS GroupId,M.MachineInternalID,m.MachineName,M.NumberOfcomp,
	  Case when IStunnel = 1 then 'Tunnel'
	  else 'Washer' 
	  End as MachineType
	  
	  
	   from [TCD].machinesetup M 
	  End