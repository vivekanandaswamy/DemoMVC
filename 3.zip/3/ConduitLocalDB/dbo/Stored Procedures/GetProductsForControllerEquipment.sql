﻿/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_GetProductsForControllerEquipment]                                         

Purpose:				To get the products for controller equipment.

Parameters:				@EcolabAccountNumber - holds the Ecolab account number.
																														
###################################################################################################                                           
*/
CREATE	PROCEDURE	[TCD].GetProductsForControllerEquipment
					@EcoLabAccountNumber					NVARCHAR(25)
AS
BEGIN

SET	NOCOUNT	ON

SELECT	ISNULL(NULLIF(PM.EnvisionDisplayName, ' '),PM.Name) AS	ProductName
	,	PM.ProductId						AS			ProductId
FROM	[TCD].ProductMaster					PM
JOIN	[TCD].ProductDataMapping			PdM
	ON	PM.ProductId						=			PdM.ProductID
JOIN    [TCD].Plant							P 
	ON	PdM.EcolabAccountNumber				=			P.EcolabAccountNumber 
	AND P.RegionId							=			PM.RegionId
JOIN    [TCD].PlantCustAddress				PCA 
	ON PCA.EcolabAccountNumber = P.EcolabAccountNumber
WHERE	PdM.EcolabAccountNumber				=			@EcoLabAccountNumber
	AND	PM.Is_Deleted						=			0
	AND	PdM.Is_Deleted						=			0
	 AND PM.ProductId NOT IN (SELECT ProductId FROM TCD.PRODUCTMASTER WHERE Name LIKE '%DUMMY PRODUCT%')
SET	NOCOUNT	OFF

END