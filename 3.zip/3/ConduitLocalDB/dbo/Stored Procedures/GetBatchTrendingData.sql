CREATE PROCEDURE [TCD].[GetBatchTrendingdata](@DashBoardId int ,@EcolabAccountNumber NVarchar(25)) 
AS 
SET NOCOUNT ON
BEGIN 

    DECLARE @Id INT = 1,@GroupId VARCHAR(100) = NULL  
    DECLARE @DashboardMachineMapping TABLE( Id INT,GroupId INT)
    DECLARE @BatchTrendingData TABLE(
										BatchId INT,
										CustomerId INT, 
										ProgramId INT,
										ActualLoad INT,
										NominalLoad INT,
										GroupId INT,
										CompartmentId INT,
										Efficiency Decimal(10,2),
										Temparature  DECIMAL(10,2),
										Conductivity  DECIMAL(10,2),
										PH  DECIMAL(10,2)) 

SET			@EcolabAccountNumber			=			ISNULL(@EcolabAccountNumber, NULL)			--SQLEnlight SA0029

INSERT INTO @DashboardMachineMapping( Id,GroupId)

SELECT ROW_NUMBER() OVER(ORDER BY MS.GroupID) AS Id,
		MS.GroupId
FROM TCD.MonitorSetUpMapping DM 
		INNER JOIN TCD.MachineSetup MS ON DM.MachineId = MS.WasherID
		INNER JOIN TCD.Dashboard D on DM.DashBoardId = D.DashBoardId
WHERE DM.DashboardId = @DashBoardId;

WHILE (@Id <= (SELECT TOP 1 MAX(B.Id) FROM @DashboardMachineMapping B GROUP BY Id ORDER BY Id DESC))
BEGIN
    
	SELECT @GroupId = DM.GroupId FROM @DashboardMachineMapping DM  WHERE Id = @Id

	INSERT INTO @BatchTrendingData(
										BatchId,
										CustomerId,
										ProgramId,
										ActualLoad,
										NominalLoad ,
										GroupId,
										CompartmentId,
										Efficiency,
										Temparature ,
										Conductivity ,
										PH  
										)		     

	EXEC [TCD].[GetBatchTrendingGroupData] @GroupId
	
	SET @Id = @Id + 1

	SET @GroupId = ''

END

SELECT DISTINCT CustomerId, ProgramId,ActualLoad,NominalLoad,GroupId,CompartmentId,Temparature,Conductivity,PH FROM @BatchTrendingData BT 

	ORDER BY BT.GroupId,BT.CompartmentId

END

GO