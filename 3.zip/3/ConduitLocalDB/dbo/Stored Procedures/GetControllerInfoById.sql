﻿CREATE PROCEDURE TCD.GetControllerInfoById (
	@ControllerId INT
	,@EcolabAccountNumber nvarchar(25) = NULL
	)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @ControllerModelId INT = (
			SELECT ControllerModelId
			FROM TCD.ConduitController
			WHERE ControllerId = @ControllerId
				AND EcoalabAccountNumber = ISNULL(@EcolabAccountNumber, EcoalabAccountNumber)
			);

	DECLARE @ControllerTypeId INT = (
			SELECT ControllerTypeId
			FROM TCD.ConduitController
			WHERE ControllerId = @ControllerId
				AND EcoalabAccountNumber = ISNULL(@EcolabAccountNumber, EcoalabAccountNumber)
			);
	DECLARE @FieldId INT = NULL;

	IF @ControllerTypeId = 1
	BEGIN
		SET @FieldId = 11
	END;
	ELSE IF @ControllerTypeId = 2
	BEGIN
    IF @ControllerModelId=2
		BEGIN
		   SET @FieldId = 171
		END
    ELSE
		BEGIN
		   SET @FieldId = 21
		END
	END;

	IF @ControllerModelId = 7
	BEGIN
		IF @ControllerTypeId = 2
			BEGIN
				SET @FieldId = 150
			END;
	END

	ELSE IF @ControllerModelId = 8
	BEGIN
		IF @ControllerTypeId = 6
			BEGIN
				SET @FieldId = 387
			END;
		ELSE IF @ControllerTypeId = 7
			BEGIN
				SET @FieldId = 400
			END;
	END

	ELSE IF @ControllerModelId = 9
	BEGIN
		IF @ControllerTypeId = 8
			BEGIN
				SET @FieldId = 414
			END;
		ELSE IF @ControllerTypeId = 10
			BEGIN
				SET @FieldId = 426
			END;
	END

	ELSE IF @ControllerModelId = 10
	BEGIN
		IF @ControllerTypeId = 6
			BEGIN
				SET @FieldId = 460
			END;
	END
	
	ELSE IF @ControllerModelId = 11
	BEGIN
		IF @ControllerTypeId = 12
			BEGIN
				SET @FieldId = 348
			END;
		ELSE IF @ControllerTypeId = 13
			BEGIN
				SET @FieldId = 309
			END;
		ELSE IF @ControllerTypeId = 14
			BEGIN
				SET @FieldId = 269
			END;
	END
	
	ELSE IF @ControllerModelId = 14
	BEGIN
		IF @ControllerTypeId = 9
			BEGIN
				SET @FieldId = 438
			END;
		ELSE IF @ControllerTypeId = 11
			BEGIN
				SET @FieldId = 449
			END;
	END

	SELECT CC.ControllerId
		,CC.TopicName
		,CC.ControllerTypeId
		,CT.NAME AS ControllerType
		,CC.ControllerModelId
		,CM.NAME AS ControllerModel
		,CSD.Value
	FROM TCD.ConduitController CC
	INNER JOIN TCD.ControllerType CT ON CT.Id = CC.ControllerTypeId
	INNER JOIN TCD.ControllerModel CM ON CM.Id = CC.ControllerModelId
	LEFT JOIN TCD.ControllerSetupData CSD ON CC.ControllerId = CSD.ControllerId
	WHERE CC.ControllerId = @ControllerId
		AND CSD.FieldId = @FieldId
		AND EcoalabAccountNumber = ISNULL(@EcolabAccountNumber, EcoalabAccountNumber);

	SET NOCOUNT OFF;
END;