﻿/*Conduit dosent support languages with locale null*/
CREATE PROCEDURE [TCD].[GetLanguages]
AS
BEGIN
SET nocount ON;

SELECT LM.[LanguageId],
LM.[Name],
LM.Locale
FROM   [TCD].LanguageMaster LM where Locale is not null  AND IsActive = 1

SET nocount OFF;
END

