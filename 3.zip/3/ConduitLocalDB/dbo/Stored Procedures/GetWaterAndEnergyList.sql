﻿/*
==========================================================================================
Purpose:  Fetching the Water and Energy list.

Author:  Neetha Allati

--------------------------------------------------------------
August-21-2014 ENT: Initial version.
==========================================================================================
*/

CREATE PROCEDURE [TCD].[GetWaterAndEnergyList]
@EcolabAccountNumber					NVARCHAR(25),
@IsResync Bit = NULL
AS
BEGIN
SET nocount ON;

Select
we.[Id],
we.[DeviceNumber],
we.DeviceName,
we.DeviceTypeId,
(select distinct dt.[Description] from [TCD].DeviceType dt  where we.DeviceTypeId = dt.DeviceTypeId) AS DeviceType,
we.DeviceModelId,
(select distinct dm.[Description] from [TCD].DeviceModel dm  where we.DeviceModelId = dm.Id) AS DeviceModel,
we.DeviceNote,
we.[EcolabAccountNumber],
we.[Comment] ,
we.[InstallDate],
we.LastModifiedTime ,
we.LastSyncTime,
we.Is_deleted,
we.MyServiceCustWtrEnrgDvcGuid
FROM   [TCD].WaterAndEnergy we
WHERE (@IsResync IS NULL AND we.[Is_deleted] != 1) OR	@IsResync	IS NOT NULL order by we.DeviceNumber
SET nocount OFF;
END