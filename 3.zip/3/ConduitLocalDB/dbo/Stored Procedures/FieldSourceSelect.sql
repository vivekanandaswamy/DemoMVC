﻿-- =============================================
-- Author:		Premchand Yelavarthi
-- Create date: 16/Jul/2013
-- Description:	Store Procedure to get all the Field Source.
-- =============================================
CREATE PROCEDURE [TCD].[FieldSourceSelect]
AS
SET NOCOUNT ON 
BEGIN
SELECT [DataSourceId], 
	[Name], 
	[Value]
FROM [TCD].FieldSource
END