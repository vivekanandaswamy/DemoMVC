﻿
CREATE PROCEDURE [TCD].[GetTunnelProductListForFormulaWithInjectionCount]
     @EcoLabAccountNumber      NVARCHAR(25)
    , @GroupId         INT
    , @TunnelProgramSetupId      INT
AS
BEGIN
DECLARE @Count INT = NULL
,  @PlantId INT 
,  @ControllerModelId INT
,  @ControllerId INT
,  @TunnelId INT

SELECT @Count = ms.NumberOfComp, @TunnelId = ms.WasherId FROM TCD.MachineSetup ms WHERE ms.GroupId = @GroupId AND ms.IsDeleted = 'False' AND ms.EcoalabAccountNumber = @EcoLabAccountNumber AND ms.IsTunnel = 1

SELECT @PlantId = PlantId FROM TCD.Plant WHERE EcolabAccountNumber = @EcoLabAccountNumber

 SELECT @ControllerId = ISNULL(WG.ControllerId, - 1)
 FROM [TCD].WasherGroup WG
 WHERE WG.EcolabAccountNumber = @EcoLabAccountNumber
 AND WG.WasherGroupId = @GroupId

SELECT @ControllerModelId = cc.ControllerModelId from tcd.ConduitController cc WHERE cc.ControllerId = @ControllerId AND cc.EcoalabAccountNumber = @EcoLabAccountNumber

SET NOCOUNT ON
IF (@ControllerModelId IS NULL OR @ControllerModelId < 7  OR @ControllerModelId IN (12, 13))
BEGIN
   SELECT TOP (@Count)  TDS.[TunnelDosingSetupId]
   ,TDS.CompartmentNumber
   ,TDS.GroupId
   , (Count(CASE WHEN tcem.Is_Deleted = 1 THEN NULL ELSE CASE WHEN pm.Is_Deleted = 1THEN NULL ELSE tcem.ControllerEquipmentSetupId END END)) AS TotalInjections
  FROM TCD.TunnelDosingSetup tds 
  INNER JOIN TCD.TunnelProgramSetup tps 
  ON tps.TunnelProgramSetupId = tds.TunnelProgramSetupId AND tps.EcolabAccountNumber = tds.EcolabAccountNumber
  INNER JOIN TCD.MachineSetup ms ON ms.GroupId = tps.WasherGroupId AND ms.EcoalabAccountNumber = tps.EcolabAccountNumber 
  LEFT JOIN TCD.TunnelCompartment tc ON tc.CompartmentNumber = tds.CompartmentNumber AND TC.EcoLabAccountNumber = TDS.EcolabAccountNumber 
                     AND tc.WasherId = ms.WasherId AND ms.IsDeleted = 'False'
  LEFT JOIN TCD.TunnelCompartmentEquipmentMapping tcem ON tcem.EcoLabAccountNumber = tc.EcoLabAccountNumber 
  AND tcem.TunnelCompartmentId = tc.TunnelCompartmentId AND tcem.Is_Deleted = 'False'
   LEFT JOIN TCD.ControllerEquipmentSetup CES on CES.ControllerEquipmentSetupId = tcem.ControllerEquipmentSetupId AND CES.EcoLabAccountNumber = tcem.EcoLabAccountNumber
  LEFT JOIN TCD.ProductdataMapping pm ON pm.EcolabAccountNumber = CES.EcoLabAccountNumber AND pm.ProductID = CES.ProductId
  WHERE 
  TDS.EcolabAccountNumber = @EcoLabAccountNumber 
  AND 
  TDS.GroupId = @GroupId
  AND
  TDS.TunnelProgramSetupId = @TunnelProgramSetupId
  AND 
  MS.IsTunnel = 'TRUE'
  AND
  MS.IsDeleted = 'FALSE'
  Group By
     TDS.[TunnelDosingSetupId]
     ,TDS.[CompartmentNumber]
     ,TDS.[GroupId] 

  Order By TDS.CompartmentNumber
END
ELSE
BEGIN
  SELECT 
	 TOP (@Count)  TDS.[TunnelDosingSetupId]
   ,TDS.CompartmentNumber
   ,TDS.GroupId
   , (Count(DISTINCT (CASE WHEN pm.Is_Deleted = 1 THEN NULL ELSE tcevm.TunnelCompartmentEquipmentValveMappingID END))) AS TotalInjections
   FROM TCD.TunnelDosingSetup tds
   INNER JOIN TCD.TunnelProgramSetup tps ON tps.TunnelProgramSetupId = tds.TunnelProgramSetupId
   INNER JOIN TCD.MachineSetup ms ON ms.GroupId = tps.WasherGroupId AND ms.EcoalabAccountNumber = tps.EcolabAccountNumber AND ms.IsDeleted = 0 AND ms.IsTunnel = 1
   INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.ControllerId = ms.ControllerId
   LEFT JOIN TCD.TunnelCompartment tc ON tc.WasherId = ms.WasherId AND tc.EcoLabAccountNumber = ms.EcoalabAccountNumber AND tc.CompartmentNumber = tds.CompartmentNumber
   LEFT JOIN TCD.TunnelCompartmentEquipmentMapping tcem ON tcem.EcoLabAccountNumber = tc.EcoLabAccountNumber AND tcem.TunnelCompartmentId = tc.TunnelCompartmentId 
   AND tcem.Is_Deleted = 0
   LEFT JOIN TCD.TunnelCompartmentEquipmentValveMapping tcevm ON tcevm.ControllerEquipmentSetupID = ces.ControllerEquipmentSetupId AND ms.MachineInternalId = tcevm.TunnelNumber
   AND tcevm.CompartmentNumber = tds.CompartmentNumber
   LEFT JOIN TCD.ProductdataMapping pm ON pm.EcolabAccountNumber = CES.EcoLabAccountNumber AND pm.ProductID = CES.ProductId 
    WHERE MS.GroupId = @GroupId AND TDS.TunnelProgramSetupId = @TunnelProgramSetupId 
	 AND MS.EcoalabAccountNumber = @EcoLabAccountNumber 
	 AND TPS.TunnelProgramSetupId = @TunnelProgramSetupId
	 	 Group By
     TDS.[TunnelDosingSetupId]
     ,TDS.[CompartmentNumber]
     ,TDS.[GroupId] 
	 Order By TDS.CompartmentNumber
	END
	
SET NOCOUNT OFF

END

