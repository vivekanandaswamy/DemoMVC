﻿CREATE PROCEDURE [TCD].[GetPlantSensorDetailsBySensorId] 
  -- Add the parameters for the stored procedure here 
  @SensorId            INT = NULL, 
  @EcolabAccountNumber NVARCHAR(25) 
AS 
  BEGIN 
	  -- SET NOCOUNT ON added to prevent extra result sets from 
	  -- interfering with SELECT statements. 
	  SET NOCOUNT ON; 

	  SELECT S.SensorId                        AS SensorId, 
			 S.[Description]                   AS [Description], 
			 S.SensorType                      AS SensorType, 
			 S.GroupId                         AS GroupId, 
			 S.MachineCompartment              AS MachineCompartment, 
			 S.EcolabAccountNumber             AS EcolabAccountNumber, 
			 S.ControllerID                    AS ControllerID, 
			 S.OutputType                      AS OutputType, 
			 S.Calibration4mA                  AS Calibration4mA, 
			 S.AnalogueInputNumber             AS AnalogueInputNumber, 
			 S.ChemicalforChart                AS ChemicalforChart, 
			 S.UOM                             AS UOM, 
			 S.DashboardActualValue            AS DashboardActualValue, 
			 S.Is_deleted                      AS Is_deleted, 
			 S.Id                              AS Id, 
			 S.LastModifiedByUserId            AS LastModifiedByUserId, 
			 S.IsPlant                         AS IsPlant, 
			 S.IsPress                         AS IsPress, 
			 S.Calibration20mA                 AS Calibration20mA, 
			 S.LastSyncTime                    AS LastSyncTime, 
			 S.LastModifiedTime                AS LastModifiedTime, 
			 s.SensorNum, 
			 s.AlarmEnable, 
			 s.MinimumAlarmValue, 
			 s.MaximumAlarmValue, 
			 s.AnalogueInputNumber, 
			 Cast(ISNULL(csd.Value, 0) AS BIT) AS ISWaterEnergyLogSel, 
			 wg.WasherGroupTypeId, 
			 ms.MachineInternalId              AS LfsWasherNumber, 
			 CAST(ISNULL(S.ControllerEquipmentID, 0) AS tinyint) AS PumpNumber 
	  FROM   TCD.Sensor S 
			 LEFT JOIN TCD.ControllerSetupData csd 
					ON csd.ControllerId = S.ControllerID 
					   AND csd.FieldId = 473 
					   AND csd.FieldGroupId = 20 
					   AND csd.EcolabAccountNumber = S.EcolabAccountNumber 
			 LEFT JOIN tcd.WasherGroup wg 
					ON wg.WasherGroupId = S.GroupId 
					   AND wg.EcolabAccountNumber = S.EcolabAccountNumber 
			 LEFT JOIN tcd.MachineSetup ms 
					ON ms.GroupId = S.GroupId 
					   AND ms.EcoalabAccountNumber = s.EcolabAccountNumber 
					   AND ( CASE wg.WasherGroupTypeId 
							   WHEN 1 THEN ms.WasherId 
							   ELSE 1 
							 END = CASE wg.WasherGroupTypeId 
									 WHEN 1 THEN s.MachineCompartment 
									 ELSE 1 
								   END ) 
			 LEFT JOIN tcd.ControllerEquipmentSetup ces 
					ON ces.ControllerId = s.ControllerID 
					   AND ces.ProductId = s.ChemicalforChart 
					   AND ces.EcoLabAccountNumber = s.EcolabAccountNumber 
	  WHERE  S.SensorId = ISNULL(@SensorId, S.SensorId) 
			 AND S.EcolabAccountNumber = @EcolabAccountNumber 
	  ORDER  BY ces.ControllerEquipmentId 
  END 