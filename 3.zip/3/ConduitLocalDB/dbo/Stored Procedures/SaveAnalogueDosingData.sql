﻿CREATE PROCEDURE [TCD].[SaveAnalogueDosingData] (

				@Level int ,
				@SetPoint float,
				@PreQuantity	float,
				@PrePauseTime int,
				@Quantity float,
				@PauseTime int,
				@MaxTime Int,
				@MinValue float,
				@MaxValue float,
				@ControlDelay	float,
				@DelayAfterTransfer float,
				@AnalogControlLevelId INT,
				@AnalogControlLevelTypeId INT,
				@WasherId INT,
				@EcolabAccNo NVARCHAR(25),
				@UserId INT
			) 
AS 
SET NOCOUNT ON
  BEGIN
      DECLARE @PlantId INT 
		SET @PlantId =	(
					SELECT 
						PlantId 
					FROM 
						TCD.Plant 
					WHERE 
						EcolabAccountNumber = @EcolabAccNo);
		IF EXISTS (SELECT tacl.* FROM TCD.TunnelAnalogControlLevel tacl WHERE tacl.TunnelAnalogControlLevelID = @AnalogControlLevelId AND TunnelAnalogControlLevelTypeID = @AnalogControlLevelTypeId AND WasherId = @WasherId AND PlantId = @PlantId AND LastModifiedUserID = @UserId)
		BEGIN
			UPDATE TCD.TunnelAnalogControlLevel
			SET [Level] = @Level, Setpoint = @SetPoint, FirstDose = @PreQuantity, FirstPause = @PrePauseTime, Pulse = @Quantity,
			[Pause] = @PauseTime, MaxTime = @MaxTime, MinVal = @MinValue, MaxVal = @MaxValue, CtrlDelay = @ControlDelay, DelayTrsf = @DelayAfterTransfer,
			LastModifiedUserID = @UserId, LastModifiedTime = GETUTCDATE(), PlantId = @PlantId
			WHERE TunnelAnalogControlLevelID = @AnalogControlLevelId AND TunnelAnalogControlLevelTypeID = @AnalogControlLevelTypeId AND WasherId = @WasherId;
		END
		ELSE
		BEGIN
			INSERT INTO TCD.TunnelAnalogControlLevel
			([Level],Setpoint,FirstDose,FirstPause,Pulse,[Pause],MaxTime,MinVal,MaxVal,CtrlDelay,DelayTrsf,TunnelAnalogControlLevelTypeID, WasherId, LastModifiedUserID, LastModifiedTime, PlantId)
			VALUES(@Level,@SetPoint,@PreQuantity,@PrePauseTime,@Quantity,@PauseTime,@MaxTime,@MinValue,@MaxValue,@ControlDelay,@DelayAfterTransfer,@AnalogControlLevelTypeId,@WasherId, @UserId, GETUTCDATE(), @PlantId)
		END
		SELECT @@ERROR						
  SET NOCOUNT OFF
   END