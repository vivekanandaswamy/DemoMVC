﻿CREATE Procedure [TCD].[ProcessMyControlAlarmData]
 (
 @ControllerID int, 
 @VxML xML
 )
AS
BEGIN
   DECLARE 
   @StartDateTime   DATETIME2,
   @StopDateTime   DATETIME2,
   @AlarmNumber   INT,
   @MachineNumber   INT,
   @BatchNumber   INT,
   @DesiredValue   INT,
   @MeasuredValue   INT,
   @Status     INT,
   @ProgramNumber   INT,
   @GroupId    INT,
   @MachineId    INT,
   @BatchID    INT,
   @ECOLABAccountNumber NVARCHAR(25),
   @CurrentDay    DATE=CAST(GETUTCDATE() as date),
   @IsActive    INT,
   @IsTunnel    INT,
   @AlarmGroupMasterId  INT;
   
   
 SELECT @MachineNumber=T.c.value('@MachineNumber', 'INT'),
   @StartDateTime=T.c.value('@StartDateTime', 'DATETIME'),
   @StopDateTime=T.c.value('@StopDateTime', 'DATETIME'),
   @ProgramNumber=T.c.value('@ProgramNumber', 'INT'),
   @BatchNumber=T.c.value('@BatchNumber', 'INT'),
   @AlarmNumber=T.c.value('@AlarmNumber', 'INT'),
   @DesiredValue=T.c.value('@DesiredValue', 'INT'),
   @MeasuredValue=T.c.value('@MeasuredValue', 'INT'),
   @Status=T.c.value('@Status', 'INT'),
   @IsTunnel=T.c.value('@IsTunnel', 'INT')

 FROM @VxML.nodes('MyControlAlarmData') T(C)

 SELECT @ECOLABAccountNumber = EcolabAccountNumber FROM TCD.Plant

 IF (@stopdatetime is NULL)
  BEGIN
  SELECT @IsActive = 1
  END
  ElSE
  BEGIN
  SELECT @IsActive = 0
  END
 
 IF NOT EXISTS(SELECT * FROM TCD.AlarmData 
  WHERE StartDate = @StartDateTime AND controllerID = @ControllerId AND AlarmCode = @AlarmNumber AND MachineInternalId = @MachineNumber AND BatchNumber = @BatchNumber)
 BEGIN

 SELECT @GroupId = GroupId, @MachineId = WasherId FROM TCD.MachineSetup WHERE MachineInternalId = @MachineNumber and ControllerId = @ControllerId and IsTunnel = @IsTunnel
 SELECT @BatchID = BatchId FROM TCD.BatchData WHERE MachineId = @MachineId and ControllerBatchId = @BatchNumber and CAST(StartDate as date)= @CurrentDay

 SELECT TOP 1 @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.ConduitController CC 
   INNER JOIN TCD.ControllerModelControllerTypeMapping CMCTM ON CMCTM.ControllerModelId = CC.ControllerModelId AND CMCTM.ControllerTypeId = CC.ControllerTypeId
   INNER JOIN TCD.AlarmGroupMsterVsControllerModelType AGMVCMT ON CMCTM.Id = AGMVCMT.ControllerModelTypeId
   INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
   WHERE AGMVCMT.AlarmCode = @AlarmNumber AND CC.ControllerId = @ControllerId

  INSERT INTO [TCD].[AlarmData] 
     (EcoalabAccountNumber,
     AlarmCode,
     BatchId,
     controllerID,
     StartDate,
	 PartitionOn,
     MachineInternalId,
     ProgramId,
     DesiredQuatity,
     MeasuredQuantity,
     TempStatus,
     GroupId,
     MachineId,
     BatchNumber,
     EndDate,
     IsActive,
     AlarmGroupMasterId
     )
     SELECT
      @ECOLABAccountNumber,
      @AlarmNumber,
      @BatchID,
      @ControllerId,
      @StartDateTime,
	  @StartDateTime,
      @MachineNumber,
      @ProgramNumber,
      @DesiredValue,
      @MeasuredValue,
      @Status,
      @GroupId,
      @MachineId,
      @BatchNumber,
      @StopDateTime,
      @IsActive,
      @AlarmGroupMasterId
 END

 ELSE
 BEGIN
  IF (@StopDateTime is not null)
  BEGIN
  
  UPDATE tcd.AlarmData set EndDate = @StopDateTime, IsActive = 0
   WHERE StartDate = @StartDateTime AND controllerID = @ControllerId AND AlarmCode = @AlarmNumber AND MachineInternalId = @MachineNumber AND BatchNumber = @BatchNumber
  
  END
 END
        
END