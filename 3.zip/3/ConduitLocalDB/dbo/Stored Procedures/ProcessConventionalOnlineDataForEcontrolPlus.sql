﻿CREATE PROCEDURE TCD.ProcessConventionalOnlineDataForEcontrolPlus(
     @Controllerid   INT, 
     @Vxml           XML, 
     @Redflagshiftid INT OUTPUT)
AS
    BEGIN
        DECLARE @Machinenumber           INT, 
                @Stepnumber              INT, 
                @Startdatetime           DATETIME, 
                @Enddatetime             DATETIME, 
                @Programnumber           INT, 
                @Load                    DECIMAL(10, 2), 
                @Nominalload             DECIMAL(10, 2), 
                @Customernumber          INT, 
                @Phvalue                 INT, 
                @Temperaturemax          INT, 
                @Batchnumber             INT, 
                @Washerid                INT, 
                @Washergroupid           INT, 
                @Ecolabwasherid          INT, 
                @Programmasterid         INT, 
                @Plantwashernumber       INT, 
                @Shiftid                 INT, 
                @Batchid                 INT, 
                @Shiftstartdate          DATETIME, 
                @Stdinjectionsteps       INT, 
                @Stdwashsteps            INT, 
                @Actualinjsteps          INT, 
                @Currencycode            VARCHAR(50), 
                @Partitionon             DATETIME2, 
                @Targetturntime          SMALLINT, 
                @Ecolabtextilecategoryid INT, 
                @Chaintextilecategoryid  INT, 
                @Formulasegmentid        INT, 
                @Ecolabsaturationid      INT, 
                @Plantprogramid          INT, 
                @Frmparameterid          INT, 
                @Phparameterid           INT, 
                @Tempparameterid         INT;
        --Declaration of temp tables for table variable
        DECLARE @Shiftmapping TABLE
        (
             ShiftId        INT, 
             ShiftName      NVARCHAR(50), 
             ShiftStartDate DATETIME
        );
        --Declareation of temp tables       
        IF OBJECT_ID('tempdb..#XmlData') IS NOT NULL
            DROP TABLE #XmlData;
        CREATE TABLE #XmlData
        (
             Machine_Number  INT, 
             Batch_Number    INT, 
             Start_DateTime  DATETIME, 
             Program_Number  INT, 
             Load            DECIMAL(10, 2), 
             Step_Number     INT, 
             Customer_Number INT, 
             pH              DECIMAL(10, 2), 
             Temperature     DECIMAL(10, 2)
        );
        IF OBJECT_ID('tempdb..#Dosing') IS NOT NULL
            DROP TABLE #Dosing;
        CREATE TABLE #Dosing
        (
             EquipmentNo INT, 
             StepNo      INT, 
             Qty         DECIMAL(18, 4)
        );
        SELECT 
               @Phparameterid = ID FROM TCD.ConduitParameters WHERE NAME = 'pH';
        SELECT 
               @Tempparameterid = ID FROM TCD.ConduitParameters WHERE NAME = 'Temperature';
        INSERT INTO #XmlData
        (
               Machine_Number, 
               Batch_Number, 
               Start_DateTime, 
               Program_Number, 
               Load, 
               Step_Number, 
               Customer_Number, 
               pH, 
               Temperature
        )
               SELECT 
                      T.c.value('@MachineNumber', 'INT'), 
                      T.c.value('@BatchNumber', 'INT'), 
                      T.c.value('@StartDateTime', 'DATETIME'), 
                      T.c.value('@ProgramNumber', 'INT'), 
                      T.c.value('@Load', 'DECIMAL(10,2)'), 
                      T.c.value('@StepNumber', 'INT'), 
                      T.c.value('@CustomerNumber', 'INT'), 
                      T.c.value('@PHValue', 'DECIMAL(10, 2)'), 
                      T.c.value('@TemperatureMax', 'DECIMAL(10, 2)')
                   FROM @Vxml.nodes('ArrayOfConventionalWasherData/ConventionalWasherData') AS T(C);
        --Declaration of cursor
        DECLARE Get_ShiftData CURSOR
        FOR SELECT 
                   xd.Machine_Number, 
                   xd.Batch_Number, 
                   xd.Start_DateTime, 
                   xd.Program_Number, 
                   xd.Load, 
                   xd.Step_Number, 
                   xd.Customer_Number, 
                   xd.pH, 
                   xd.Temperature
                FROM #XmlData AS xd;
        OPEN Get_ShiftData;
        FETCH NEXT FROM Get_ShiftData INTO @Machinenumber, 
                                           @Batchnumber, 
                                           @Startdatetime, 
                                           @Programnumber, 
                                           @Load, 
                                           @Stepnumber, 
                                           @Customernumber, 
                                           @Phvalue, 
                                           @Temperaturemax;
        WHILE @@Fetch_Status = 0
            BEGIN
                IF @Enddatetime = '1/1/1900'
                    SELECT 
                           @Enddatetime = NULL;
                IF @Startdatetime = '1/1/1900'
                    SELECT 
                           @Startdatetime = NULL;
                INSERT INTO @Shiftmapping
                (
                       ShiftId, 
                       ShiftName, 
                       ShiftStartDate
                )
                EXEC TCD.GetShiftStartDate 
                     @Startdatetime;
                SELECT 
                       @Shiftid = ShiftID, 
                       @Shiftstartdate = ShiftStartdate, 
                       @Partitionon = ShiftStartdate
                    FROM @Shiftmapping;
                SELECT 
                       @Washergroupid = GroupId, 
                       @Washerid = WasherID
                    FROM TCD.MachineSetup AS ms
                    WHERE ControllerID = @Controllerid
                          AND MachineInternalId = @Machinenumber
                          AND ms.IsTunnel = 0
                          AND ms.IsDeleted = 0;
                IF @Washerid IS NOT NULL
                    BEGIN
                        SELECT 
                               @Programmasterid = Wps.ProgramId
                            FROM TCD.Washer AS Ws
                                 INNER JOIN TCD.MachineSetup AS Ms ON Ms.WasherId = Ws.WasherId
                                 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Ms.GroupId
                                 INNER JOIN TCD.WasherProgramSetup AS Wps ON Wps.WasherGroupId = Wg.WasherGroupId
                                 INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.EcoLabAccountNumber
                            WHERE Ws.WasherId = @Washerid
                                  AND Wps.ProgramNumber = @Programnumber
                                  --AND Wps.ControllerID = @ControllerID
                                  AND Wps.Is_Deleted = 0
                                  AND ms.IsDeleted = 0;
                        SELECT 
                               @Ecolabwasherid = EcolabWasherId, 
                               @Plantwashernumber = PlantWasherNumber, 
                               @Currencycode = P.CurrencyCode, 
                               @Targetturntime = w.TargetTurnTime * 60
                            FROM TCD.Washer AS w
                                 INNER JOIN tcd.Plant AS p ON w.EcoLabAccountNumber = p.EcolabAccountNumber
                            WHERE w.WasherId = @Washerid
                                  AND w.Is_Deleted = 0;
                        SELECT 
                               @Batchid = BatchID
                            FROM TCD.BatchData
                            WHERE MachineInternalID = @Machinenumber
                                  AND StartDate = @Startdatetime
                                  AND ControllerBatchId = @Batchnumber
                                  AND MachineID = @Washerid;
                        --Start Getting InjectionCount and StepCount
                        SELECT 
                               @Stdinjectionsteps = COUNT(DISTINCT wdpm.WasherDosingSetupId), 
                               @Stdwashsteps = COUNT(DISTINCT wds.WasherDosingSetupId) - COUNT(DISTINCT wdpm.WasherDosingSetupId)
                            FROM TCD.WasherDosingProductMapping AS wdpm
                                 RIGHT JOIN TCD.WasherDosingSetup AS wds ON wdpm.WasherDosingSetupId = wds.WasherDosingSetupId
                            WHERE wds.GroupId = @Washergroupid
                                  AND wds.ProgramNumber = @Programnumber
                                  AND wds.Is_Deleted = 0;
                        --End Getting InjectionCount and StepCount
                        --Start-----ProgramMasterID logic for PlantChainProgram
                        SELECT 
                               @Plantprogramid = pm.PlantProgramId, 
                               @Ecolabtextilecategoryid = pm.EcolabTextileCategoryId, 
                               @Chaintextilecategoryid = pm.ChainTextileId, 
                               @Formulasegmentid = pm.FormulaSegmentId, 
                               @Ecolabsaturationid = pm.EcolabSaturationId
                            FROM TCD.ProgramMaster AS pm
                            WHERE pm.ProgramId = @Programmasterid
                                  AND pm.Is_Deleted = 0;
                        IF @Plantprogramid <> 0
                           OR @Plantprogramid IS NOT NULL
                            BEGIN
                                --Assign value from plantchainprogram table based on plantprogramId
                                SELECT 
                                       @Ecolabtextilecategoryid = pcp.EcolabTextileCategoryId, 
                                       @Chaintextilecategoryid = pcp.ChainTextileCategoryId, 
                                       @Formulasegmentid = pcp.FormulaSegmentId, 
                                       @Ecolabsaturationid = pcp.EcolabSaturationId
                                    FROM tcd.PlantChainProgram AS pcp
                                    WHERE pcp.PlantProgramId = @Plantprogramid
                                          AND pcp.Is_Deleted = 0;
                            END;
                        --End-----ProgramMasterID logic for PlantChainProgram
                        IF @Batchid IS NULL
                            BEGIN
                                INSERT INTO TCD.BatchData
                                (
                                       ControllerBatchID, 
                                       EcolabWasherId, 
                                       GroupId, 
                                       MachineInternalId, 
                                       PlantWasherNumber, 
                                       StartDate, 
                                       EndDate, 
                                       ProgramNumber, 
                                       ProgramMasterId, 
                                       MachineID, 
                                       ActualWeight, 
                                       StandardWeight, 
                                       CurrencyCode, 
                                       ShiftId, 
                                       PartitionOn, 
                                       StdInjectionSteps, 
                                       StdWashSteps, 
                                       EcolabTextileCategoryId, 
                                       ChainTextileCategoryId, 
                                       FormulaSegmentId, 
                                       EcolabSaturationId, 
                                       PlantProgramId, 
                                       EndDateFormula, 
                                       TargetTurnTime
                                )
                                VALUES
                                (
                                       @Batchnumber, 
                                       @Ecolabwasherid, 
                                       @Washergroupid, 
                                       @Machinenumber, 
                                       @Plantwashernumber, 
                                       @Startdatetime, 
                                       @Enddatetime, 
                                       @Programnumber, 
                                       @Programmasterid, 
                                       @Washerid, 
                                       @Load, 
                                       ISNULL(@Nominalload, 0), 
                                       @Currencycode, 
                                       @Shiftid, 
                                       @Shiftstartdate, 
                                       @Stdinjectionsteps, 
                                       @Stdwashsteps, 
                                       @Ecolabtextilecategoryid, 
                                       @Chaintextilecategoryid, 
                                       @Formulasegmentid, 
                                       @Ecolabsaturationid, 
                                       @Plantprogramid, 
                                       @Enddatetime, 
                                       @Targetturntime
                                );
                                SELECT 
                                       @Batchid = SCOPE_IDENTITY();
                                IF NOT EXISTS
                                             (SELECT 
                                                     * FROM TCD.BatchParameters WHERE BatchId = @Batchid
                                                                                      AND ParameterID = 38
                                             )
                                    BEGIN
                                        IF @Stdwashsteps <> 0
                                           OR @Stdwashsteps <> NULL
                                            BEGIN
                                                INSERT INTO TCD.BatchParameters
                                                (
                                                       BatchId, 
                                                       EcolabWasherId, 
                                                       ParameterId, 
                                                       ParameterValue, 
                                                       PartitionOn
                                                )
                                                       SELECT 
                                                              @Batchid, 
                                                              @Ecolabwasherid, 
                                                              38, 
                                                              @Stdwashsteps, 
                                                              @Shiftstartdate;
                                            END;
                                    END;
                            END;
                        --End Date  Time  is Null 
                        IF EXISTS
                                 (SELECT 
                                         *
                                      FROM TCD.BatchData
                                      WHERE MachineInternalID = @Machinenumber
                                            AND StartDate <> @Startdatetime
                                            AND EndDate IS NULL
                                            AND ControllerBatchId <> @Batchnumber
                                            AND MachineId = @Washerid
                                 )
                            BEGIN
                                DECLARE @Shiftidbyenddate     INT, 
                                        @Partitiononbyenddate DATETIME;
                                DECLARE @Currentutcdate DATETIME;
                                SELECT 
                                       @Currentutcdate = DATEADD(ss, -10, @Startdatetime);
                                DECLARE @Shiftmappingbyenddate TABLE
                                (
                                     ShiftId        INT, 
                                     ShiftName      NVARCHAR(50), 
                                     ShiftStartdate DATETIME
                                );

                                INSERT INTO @Shiftmappingbyenddate
                                (
                                       ShiftId, 
                                       ShiftName, 
                                       ShiftStartdate
                                )
                                EXEC TCD.GetShiftStartDate 
                                     @Currentutcdate;
                                SELECT 
                                       @Shiftidbyenddate = ShiftID, 
                                       @Partitiononbyenddate = ShiftStartdate
                                    FROM @Shiftmappingbyenddate;
                                UPDATE TCD.BatchData
                                  SET 
                                      EndDate = DATEADD(ss, -10, @Startdatetime), 
                                      ShiftId = @Shiftidbyenddate, 
                                      PartitionOn = @Partitiononbyenddate
                                    WHERE 
                                          MachineInternalID = @Machinenumber
                                          AND StartDate <> @Startdatetime
                                          AND EndDate IS NULL
                                          AND ControllerBatchId <> @Batchnumber
                                          AND MachineId = @Washerid;
                            END;
                        --Insert customer details to batch customer table
                        IF NOT EXISTS
                                     (SELECT 
                                             1
                                          FROM TCD.BatchCustomerData
                                          WHERE BatchID = @Batchid
                                                AND @Customernumber IS NOT NULL
                                     )
                            BEGIN
                                INSERT INTO TCD.BatchCustomerData
                                (
                                       BatchId, 
                                       CustomerID, 
                                       Weight, 
                                       piecesCount, 
                                       PartitionOn, 
                                       EcolabWasherId
                                )
                                       SELECT DISTINCT 
                                              Bd.BatchId, 
                                              Pc.ID, 
                                              @Load, 
                                              ROUND(COALESCE((@Load * Pm.Pieces) / NULLIF(Pm.Weight, 0), 0), 0), 
                                              (SELECT TOP 1 
                                                      ShiftStartdate FROM @Shiftmapping
                                              ), 
                                              @Ecolabwasherid
                                           FROM TCD.Washer AS WS
                                                INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = ws.WasherId
                                                INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
                                                INNER JOIN TCD.TunnelProgramSetup AS Tps ON Tps.WasherGroupId = Wg.WasherGroupId
                                                INNER JOIN TCD.ProgramMaster AS Pm ON Pm.ProgramId = Tps.ProgramId
                                                INNER JOIN TCD.PlantCustomer AS Pc ON Pc.ID = Pm.CustomerId
                                                INNER JOIN TCD.BatchData AS Bd ON Bd.MachineId = Ws.WasherId
                                           WHERE Ws.WasherId = @Washerid
                                                 AND Tps.ProgramNumber = @Programnumber
                                                 AND Bd.BatchId = @Batchid
                                                 AND Pm.CustomerId != -1
                                                 AND Pm.Weight > 0;

                            END;
                        ELSE
                        IF @Customernumber > 0
                            BEGIN
                                UPDATE TCD.BatchCustomerData
                                  SET 
                                      CustomerID = @Customernumber, 
                                      Weight = @Load
                                    WHERE 
                                          BatchID = @Batchid;
                            END;
                        -- PH Value
                        IF NOT EXISTS
                                     (SELECT 
                                             *
                                          FROM TCD.WasherReading
                                          WHERE WasherId = @Washerid
                                                AND ParameterID = @Phparameterid
                                                AND ParameterValue =
                                                                     (SELECT TOP 1 
                                                                             ParameterValue
                                                                          FROM tcd.WasherReading
                                                                          WHERE WasherId = @Washerid
                                                                                AND ParameterID = @Phparameterid
                                                                          ORDER BY 
                                                                                   DateTimeStamp DESC
                                                                     )
                                     )
                            BEGIN
                                IF @Phvalue <> 0
                                   OR @Phvalue <> NULL
                                    BEGIN
                                        INSERT INTO TCD.WasherReading
                                        (
                                               WasherId, 
                                               ParameterID, 
                                               ParameterValue, 
                                               DateTimeStamp, 
                                               PartitionOn, 
                                               EcolabWasherId
                                        )
                                               SELECT 
                                                      @Washerid, 
                                                      @Phparameterid, 
                                                      @Phvalue, 
                                                      GETUTCDATE(), 
                                                      @Shiftstartdate, 
                                                      @Ecolabwasherid;
                                    END;
                            END;
                        IF NOT EXISTS
                                     (SELECT 
                                             *
                                          FROM TCD.WasherReading
                                          WHERE WasherId = @Washerid
                                                AND ParameterID = @Tempparameterid
                                                AND ParameterValue =
                                                                     (SELECT TOP 1 
                                                                             ParameterValue
                                                                          FROM tcd.WasherReading
                                                                          WHERE WasherId = @Washerid
                                                                                AND ParameterID = @Tempparameterid
                                                                          ORDER BY 
                                                                                   DateTimeStamp DESC
                                                                     )
                                     )
                            BEGIN
                                IF @Temperaturemax <> 0
                                   OR @Temperaturemax <> NULL
                                    BEGIN
                                        INSERT INTO TCD.WasherReading
                                        (
                                               WasherId, 
                                               ParameterID, 
                                               ParameterValue, 
                                               DateTimeStamp, 
                                               PartitionOn, 
                                               EcolabWasherId
                                        )
                                               SELECT 
                                                      @Washerid, 
                                                      @Tempparameterid, 
                                                      @Temperaturemax, 
                                                      GETUTCDATE(), 
                                                      @Shiftstartdate, 
                                                      @Ecolabwasherid;
                                    END;
                            END;
                    END;

                SELECT 
                       @Machinenumber = NULL, 
                       @Stepnumber = NULL, 
                       @Startdatetime = NULL, 
                       @Enddatetime = NULL, 
                       @Programnumber = NULL, 
                       @Load = NULL, 
                       @Nominalload = NULL, 
                       @Customernumber = NULL, 
                       @Phvalue = NULL, 
                       @Temperaturemax = NULL, 
                       @Batchnumber = NULL, 
                       @Washerid = NULL, 
                       @Washergroupid = NULL, 
                       @Ecolabwasherid = NULL, 
                       @Programmasterid = NULL, 
                       @Plantwashernumber = NULL, 
                       @Shiftid = NULL, 
                       @Batchid = NULL, 
                       @Shiftstartdate = NULL, 
                       @Stdinjectionsteps = NULL, 
                       @Stdwashsteps = NULL, 
                       @Actualinjsteps = NULL, 
                       @Currencycode = NULL, 
                       @Partitionon = NULL, 
                       @Targetturntime = NULL, 
                       @Ecolabtextilecategoryid = NULL, 
                       @Chaintextilecategoryid = NULL, 
                       @Formulasegmentid = NULL, 
                       @Ecolabsaturationid = NULL, 
                       @Plantprogramid = NULL, 
                       @Frmparameterid = NULL;
                FETCH NEXT FROM Get_ShiftData INTO @Machinenumber, 
                                                   @Batchnumber, 
                                                   @Startdatetime, 
                                                   @Programnumber, 
                                                   @Load, 
                                                   @Stepnumber, 
                                                   @Customernumber, 
                                                   @Phvalue, 
                                                   @Temperaturemax;
                DELETE FROM @Shiftmapping;
                DELETE FROM @Shiftmappingbyenddate;
            END;
        CLOSE Get_ShiftData;
        DEALLOCATE Get_ShiftData;
        --Inserting dosing details to WasherProductReading
        WITH TempData
             AS (SELECT 
                        ms.GroupId, 
                        ms.WasherID, 
                        T.c.value('../../@MachineNumber', 'INT') AS MachineNumber, 
                        T.c.value('../../@BatchNumber', 'INT') AS BatchNumber, 
                        T.c.value('../../@ProgramNumber', 'INT') AS ProgramNumber, 
                        T.c.value('@Equipment', 'INT') AS EquipmentNo, 
                        T.c.value('@stepNo', 'INT') AS StepNo, 
                        T.c.value('@Qty', 'DECIMAL(18,4)') AS Qty, 
                        CE.ProductID
                     FROM @Vxml.nodes('ArrayOfConventionalWasherData/ConventionalWasherData/DosingData/Dosing') AS T(C)
                          INNER JOIN tcd.MachineSetup AS ms ON ms.MachineInternalId = T.c.value('../../@MachineNumber', 'INT')
                          INNER JOIN TCD.ControllerEquipmentSetup AS CE ON T.c.value('@Equipment', 'INT') = CE.ControllerEquipmentId
                     WHERE ms.ControllerID = @Controllerid
                           AND CE.ControllerID = @Controllerid
                           AND CE.ProductID IS NOT NULL
                           --AND MachineInternalId = ms
                           AND IsTunnel = 0
                           AND ms.IsDeleted = 0)
             MERGE INTO TCD.WasherProductReading wpr
             USING
                  (SELECT 
                          * FROM TempData AS td
                  ) temp
             ON wpr.BatchNumber = temp.BatchNumber
                AND wpr.WasherId = temp.WasherID
                AND wpr.MachineInternalId = temp.MachineNumber
                AND wpr.ControllerId = @Controllerid
                 WHEN NOT MATCHED
                 THEN INSERT(
                             ControllerId, 
                             WasherId, 
                             MachineInternalId, 
                             ProductId, 
                             TheoreticalQty, 
                             RealQty, 
                             DosingPoint, 
                             DosingNumber, 
                             ProgramNumber, 
                             BatchNumber, 
                             ValveNumber, 
                             DateTimeStamp) VALUES
             (
                                                   @Controllerid, 
                                                   temp.WasherID, 
                                                   temp.MachineNumber, 
                                                   temp.ProductID, 
                                                   NULL,
                                                   CASE
                                                       WHEN temp.EquipmentNo = 9
                                                            OR temp.EquipmentNo = 10
                                                       THEN temp.Qty * 16
                                                       ELSE temp.Qty
                                                   END, 
                                                   temp.EquipmentNo, 
                                                   temp.EquipmentNo, 
                                                   temp.ProgramNumber, 
                                                   temp.BatchNumber, 
                                                   NULL, 
                                                   GETUTCDATE()
             );
    END;