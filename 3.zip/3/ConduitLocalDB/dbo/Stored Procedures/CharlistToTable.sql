CREATE PROCEDURE [TCD].[CharlistToTable] (
									   @List VARCHAR(MAX) = NULL,
									   @Delimitor CHAR(1) = ','
								    )
AS
SET NOCOUNT ON;
BEGIN

DECLARE @CommaSepartedTable TABLE (
							 Item VARCHAR(MAX)
						    )

DECLARE @item VARCHAR(MAX) = NULL,
	   @Pos INT = NULL
SET @List = LTRIM(RTRIM(@List))+ @Delimitor
SET @Pos = CHARINDEX(@Delimitor, @List, 1)
WHILE @Pos > 0
BEGIN
    SET @item = LTRIM(RTRIM(LEFT(@List, @Pos - 1)))
	   IF @item <> ''
		  BEGIN
		  INSERT INTO @CommaSepartedTable (item)
		  VALUES (CAST(@item AS VARCHAR(MAX)))
		  END
SET @List = RIGHT(@List, LEN(@List) - @Pos)
SET @Pos = CHARINDEX(@Delimitor, @List, 1)
END
SELECT * FROM @CommaSepartedTable
SET NOCOUNT OFF;
END
