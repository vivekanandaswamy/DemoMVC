﻿/*	                                   
###################################################################################################                                           

Stored Procedure	:       [TCD].[GetPlantContactdetails]                                         

Purpose				:		To Get the plant contact details.
																												
Parameters			:		None

###################################################################################################                                           
*/
CREATE	PROCEDURE	[TCD].[GetPlantContactDetails] 
	@EcolabAccountNumber	NVARCHAR(25) = NULL
AS   
 BEGIN   

SET	NOCOUNT ON;   

SELECT
		PC.ID						AS		ID			--PlantContactId; but the entity field name might not match, thus ID!
	,	EcolabAccountNumber
	,	ContactFirstName
	,	ContactLastName
	,	ContactTitle
	,	ContactPositionId
	,	PCP.Position_Name			AS			ContactPositionName
	,	ContactEmail
	,	ContactOfficePhone
	,	ContactMobilePhone
	,	ContactFaxNumber
	,	LastModifiedTime
	,	LastSyncTime
	,	PC.Is_Deleted
	,	PC.MyServiceCntctGuid		AS			MyServiceCntctGuid
	,	PC.MyServiceLastSynchTime
	,	PCP.MyServiceCntctPosnId	AS			MyServiceCntctPosnId
FROM	[TCD].PlantContact			PC 
JOIN	TCD.PlantContactPosition	PCP
	ON	PC.ContactPositionId		=			PCP.Id
WHERE	
	EcolabAccountNumber		=			ISNULL(@EcolabAccountNumber, EcolabAccountNumber)

SET	NOCOUNT OFF;


END