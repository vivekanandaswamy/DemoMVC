CREATE PROCEDURE [TCD].GetWashersForNavigationMenu
(
			@EcoalabAccountNumber  NVARCHAR(25) = NULL
)
AS
BEGIN
	
	SET NOCOUNT ON;

			SELECT MS.WasherId, MS.MachineName FROM [TCD].MachineSetup MS
			INNER JOIN [TCD].Washer W on MS.WasherId = W.WasherId
			Where MS.IsDeleted <> 1
			AND MS.ControllerId IS NOT NULL
			AND ControllerId <> 0
			AND MS.EcoalabAccountNumber = '1'
END
GO


