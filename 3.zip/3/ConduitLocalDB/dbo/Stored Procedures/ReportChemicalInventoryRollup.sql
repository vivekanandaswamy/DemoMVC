/*
IF EXISTS(SELECT * FROM SYS.PROCEDURES WHERE NAME = 'ReportChemicalInventoryRollup' AND SCHEMA_ID = SCHEMA_ID('TCD'))
    DROP PROCEDURE [TCD].[ReportChemicalInventoryRollup]
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
*/

CREATE PROCEDURE[TCD].[ReportChemicalInventoryRollup]
	AS
	BEGIN
	/*
	======================================================================================
	CHANGE ID(TFS)  CHANGED BY CHANGED ON     CHANGE DESCRIPTION
	======================================================================================
		PSAJJA    07/09/2015     Scheduled the procedure to run every 15 mins from windows 
				and data get populdated TCD.ChemicalInventoryRollUp table
				to improve ChemicalInventory report performance.
	 PSAJJA 10/09/2015 Added AvgDailyNeedsForInventoryPeriod Column
	 PSAJJA 10/13/2015 DaysBeforeOutOfStock column changed to Int as per client
	======================================================================================
	*/


	 SET NOCOUNT ON;
	 DECLARE @CurrentYearWorkingDays INT    = NULL
		,@PreviousYearWorkingDays INT    = NULL
		,@CurrencyCode   VARCHAR(3)  = NULL

	 SELECT @CurrencyCode = p.CurrencyCode
	 FROM TCD.Plant p

	 SELECT @CurrentYearWorkingDays = COUNT(DISTINCT CAST(PS.StartDateTime AS DATE))
	 FROM TCD.ProductionShiftData PS (NOLOCK) 
	 WHERE PS.StartDateTime >= DATEADD(yy, DATEDIFF(yy,0,getdate()), 0)
	 AND PS.LastSyncTime IS NOT NULL
	 AND EXISTS (SELECT 1 FROM [TCD].ShiftProductionDataRollup SPD (NOLOCK)
		WHERE SPD.ShiftId = PS.ShiftId
		)

	 SELECT @PreviousYearWorkingDays = COUNT(DISTINCT CAST(PS.StartDateTime AS DATE))
	 FROM TCD.ProductionShiftData PS (NOLOCK) 
	 WHERE PS.StartDateTime >= DATEADD(YEAR, DATEDIFF(YEAR, 0,DATEADD(YEAR, -1, GETDATE())), 0)
	 AND PS.StartDateTime <= DATEADD(MILLISECOND, -3, DATEADD(YEAR, DATEDIFF(YEAR, 0, DATEADD(YEAR, -1, GETDATE())) +1, 0))
	 AND PS.LastSyncTime IS NOT NULL
	 AND EXISTS (SELECT 1 FROM [TCD].ShiftProductionDataRollup SPD (NOLOCK) 
		WHERE SPD.ShiftId = PS.ShiftId
		)

	--SELECT @CurrentYearWorkingDays, @PreviousYearWorkingDays


	 DECLARE @ChemicalLastInventory TABLE (
	   ProductId INT
	  ,LastInventoryDate DATETIME
	  ,BeforeLastInventoryDate DATETIME
	  );

	CREATE TABLE #InventoryRollUp (
		ProductID INT PRIMARY KEY,
		ChemicalName VARCHAR(512),
		LastInventory DECIMAL(18,2),
		InventoryBasedConsumption DECIMAL(18,2),
		DispencerBasedConsumption DECIMAL(18,2),
		TodayEstimateInventory DECIMAL(18,2),
		AvgDailyNeedsYTD DECIMAL(18,2),
		AvgDailyCostYTD DECIMAL(18,6),
		AvgDailyCostLoadYTD DECIMAL(18,6),
		AvgDailyNeedsLY DECIMAL(18,2),
		DayBeforeOutOfStock INT,
		InventoryDateRange varchar(70),
		UnitSize VARCHAR(10),
		AvgDailyNeedsForInventoryPeriod DECIMAL(18,2)
		);

	WITH CTE (
	   Rownumber
	  ,ProductId
	  ,InventoryDate
	  )
	 AS (
	  SELECT ROW_NUMBER() OVER (
		PARTITION BY CI.ProductId ORDER BY InventoryDate DESC
		)
	   ,CI.ProductId
	   ,CI.InventoryDate
	  FROM TCD.ChemicalInventory CI (NOLOCK)
	  ),
	 CTE_INV AS (
	 SELECT CT.ProductId
	  , MAX(CT.InventoryDate) AS LastInventoryDate
	  , MIN(CT.InventoryDate) AS BeforeLastInventoryDate
	 FROM CTE CT
	 WHERE CT.Rownumber < 3
	 GROUP BY CT.ProductId
	 )
	 INSERT INTO @ChemicalLastInventory
	 SELECT DISTINCT CT.productid, Inv.LastInventoryDate, Inv.BeforeLastInventoryDate
	 FROM CTE CT
	 JOIN CTE_INV Inv ON CT.productid = Inv.Productid
	 WHERE CT.Rownumber < 2;


	 WITH CTE_dispencer_estimate_Inventory
	AS (
	 SELECT SCD.ProductId
		, SUM(CASE WHEN (CAST(psd.StartDateTime AS DATE) BETWEEN CAST(CLI.BeforeLastInventoryDate AS DATE) AND CAST(CLI.LastInventoryDate AS DATE))
		THEN SCD.ActualConsumption --* 0.0078125
		  END) AS DispencerBasedConsumption
		, SUM(CASE WHEN (CAST(psd.StartDateTime AS DATE) > CAST(CLI.LastInventoryDate AS DATE))
		THEN SCD.ActualConsumption --* 0.0078125
		  END) AS TodayEstimateInventory
	 FROM TCD.ShiftChemicalDataRollup SCD (NOLOCK)
	 INNER JOIN TCD.ProductionShiftData psd ON psd.ShiftId = SCD.ShiftId
	 INNER JOIN @ChemicalLastInventory CLI ON SCD.ProductId = CLI.ProductId
	 WHERE psd.LastSyncTime IS NOT NULL
	 GROUP BY SCD.ProductId
	),
	CTE_YTD
	AS (
	 SELECT ci.ProductId
	 , SUM(CASE WHEN ci.InventoryDate >= DATEADD(yy, DATEDIFF(yy,0,getdate()), 0) 
	  THEN ci.UsedQuantity * CASE LTRIM(RTRIM(ci.UnitSize)) 
				    WHEN 'gal' THEN 128.0
				    WHEN 'lbs' THEN 16.0
				    WHEN 'kg' THEN 35.274
				    WHEN 'L' THEN 33.814
				    ELSE 1
				 END
		ELSE NULL
		END ) AS AvgDailyNeeds
	 , NULL AS AvgDailyCost
	 --, SUM(CASE WHEN ci.InventoryDate >= DATEADD(yy, DATEDIFF(yy,0,getdate()), 0) 
	 -- THEN CASE WHEN ci.UnitSize = 'lbs' THEN (ci.UsedQuantity * 16.00) 
	 --   WHEN ci.UnitSize = 'oz'  THEN ci.UsedQuantity 
	 --   WHEN ci.UnitSize = 'gal' THEN ci.UsedQuantity * 128.00
	 --   ELSE ci.UsedQuantity
	 --   END
	 --   ELSE NULL
	 --   END ) * [TCD].[FnChemicalCostInOunce](ci.ProductId) AS AvgDailyCost
	 , SUM(CASE WHEN (ci.InventoryDate >= DATEADD(YEAR, DATEDIFF(YEAR, 0,DATEADD(YEAR, -1, GETDATE())), 0)
		AND ci.InventoryDate <= DATEADD(MILLISECOND, -3, DATEADD(YEAR, DATEDIFF(YEAR, 0, DATEADD(YEAR, -1, GETDATE())) +1, 0)))
	  THEN ci.UsedQuantity * CASE LTRIM(RTRIM(ci.UnitSize)) 
				    WHEN 'gal' THEN 128.0
				    WHEN 'lbs' THEN 16.0
				    WHEN 'kg' THEN 35.274
				    WHEN 'L' THEN 33.814
				    ELSE 1
				 END
		ELSE NULL
		END ) AS AvgDailyNeedsLY
	 , SUM(CASE WHEN (ci.InventoryDate >= CAST(cli.BeforeLastInventoryDate AS DATE)
		AND ci.InventoryDate <= cli.LastInventoryDate)
	  THEN ci.UsedQuantity * CASE LTRIM(RTRIM(ci.UnitSize)) 
				    WHEN 'gal' THEN 128.0
				    WHEN 'lbs' THEN 16.0
				    WHEN 'kg' THEN 35.274
				    WHEN 'L' THEN 33.814
				    ELSE 1
				 END
		ELSE NULL
		END ) AS AvgDailyNeedsForInventoryPeriod
	FROM TCD.ChemicalInventory ci
	INNER JOIN tcd.ProductdataMapping pm ON ci.ProductId = pm.ProductID
	INNER JOIN @ChemicalLastInventory cli ON cli.ProductId = ci.ProductId
	GROUP BY ci.ProductId
	)
	SELECT   X.ProductId
		, X.DispencerBasedConsumption
		, X.TodayEstimateInventory
		, cy.AvgDailyNeeds
		, cy.AvgDailyCost
		, cy.AvgDailyCost AS AvgDailyCostPerLoad
		, cy.AvgDailyNeedsLY
		, cy.AvgDailyNeedsForInventoryPeriod
	INTO #CI_Data
	FROM CTE_YTD cy
	LEFT JOIN CTE_dispencer_estimate_Inventory X ON X.ProductId = cy.ProductId


	--select * from #CI_Data
	DECLARE @ChemicalInventory TABLE (
	  ProductId INT
	  ,ChemicalName VARCHAR(1000)
	  ,LastInventory DECIMAL(18, 2)
	  ,InventoryDate DATETIME
	  ,InventoryDateRange VARCHAR(70)
	  ,InventorybasedConsumption DECIMAL(18, 2)
	  ,DispencerBasedConsumption DECIMAL(18, 2)
	  ,TodayEstimateInventory DECIMAL(18, 2)
	  ,AvgDailyNeedsYTD DECIMAL(18, 2)
	  ,AvgDailyCostYTD DECIMAL(18, 6)
	  ,AvgDailyCostloadYTD DECIMAL(18, 6)
	  ,AvgDailyNeedsLY DECIMAL(18, 2)
	  ,DayBeforeOutOfStock INT
	  ,UnitSize varchar(10)
	  ,AvgDailyNeedsForInventoryPeriod DECIMAL(18, 2)
	  )

	 INSERT INTO @ChemicalInventory
	 SELECT DISTINCT CI.ProductId
	  , PM.NAME
	  --, COALESCE(pm.EnvisionDisplayName, PM.NAME) 
	  , CI.ClosingQuantity * CASE LTRIM(RTRIM(ci.UnitSize)) 
				    WHEN 'gal' THEN 128.0
				    WHEN 'lbs' THEN 16.0
				    WHEN 'kg' THEN 35.274
				    WHEN 'L' THEN 33.814
				    ELSE 1
				 END AS LastInventory
	  , CIL.LastInventoryDate AS InventoryDate
	  ,(CONVERT(VARCHAR(25),CIL.BeforeLastInventoryDate, 110) + ' - ' + CONVERT(VARCHAR(25), CIL.LastInventoryDate, 110)) AS inventoryDateRange
	  , CI.UsedQuantity * CASE LTRIM(RTRIM(ci.UnitSize)) 
				    WHEN 'gal' THEN 128.0
				    WHEN 'lbs' THEN 16.0
				    WHEN 'kg' THEN 35.274
				    WHEN 'L' THEN 33.814
				    ELSE 1
				 END AS InventorybasedConsumption
	  , CID.DispencerBasedConsumption
	  , ((CI.ClosingQuantity * CASE LTRIM(RTRIM(ci.UnitSize)) 
				    WHEN 'gal' THEN 128.0
				    WHEN 'lbs' THEN 16.0
				    WHEN 'kg' THEN 35.274
				    WHEN 'L' THEN 33.814
				    ELSE 1
				 END) - CID.TodayEstimateInventory) AS TodayEstimateInventory
	  , NULLIF(CID.AvgDailyNeeds,0)/NULLIF(@CurrentYearWorkingDays, 0) AS AvgDailyNeedsYTD
	  , NULLIF(@CurrentYearWorkingDays, 0) AS AvgDailyCostYTD
	  , (SELECT NULLIF(COUNT(DISTINCT bd.batchid),0) FROM TCD.BatchData bd (NOLOCK)
			INNER JOIN tcd.BatchProductData bpd (NOLOCK) ON bpd.BatchId = bd.BatchId
			WHERE bd.StartDate >= DATEADD( yy,DATEDIFF( yy,0,GETDATE()),0 )
			AND bpd.ProductId = CI.ProductId) AS AvgDailyCostloadYTD
	  --, NULLIF(CID.AvgDailyCost,0)/NULLIF(@CurrentYearWorkingDays, 0) AS AvgDailyCostYTD
	  --, CID.AvgDailyCostPerLoad / (SELECT NULLIF(COUNT(DISTINCT bd.batchid),0) FROM TCD.BatchData bd (NOLOCK)
	  --      INNER JOIN tcd.BatchProductData bpd (NOLOCK) ON bpd.BatchId = bd.BatchId
	  --      WHERE bd.StartDate >= DATEADD( yy,DATEDIFF( yy,0,GETDATE()),0 )
	  --      AND bpd.ProductId = CI.ProductId) * 100
	  --, CID.AvgDailyCostPerLoad / (SELECT NULLIF(SUM(DISTINCT scdr.NoOfLoads),0) FROM TCD.ProductionShiftData psd
	  --      INNER JOIN TCD.ShiftChemicalDataRollup scdr ON scdr.ShiftId = psd.ShiftId
	  --      WHERE psd.StartDateTime >= DATEADD(yy, DATEDIFF(yy,0,getdate()), 0) 
	  --      AND scdr.ProductId = CI.ProductId
	  --      ) * 100  
	  , NULLIF(CID.AvgDailyNeedsLY,0) / NULLIF(@PreviousYearWorkingDays, 0)
	  ,((CI.ClosingQuantity * CASE LTRIM(RTRIM(ci.UnitSize)) 
				    WHEN 'gal' THEN 128.0
				    WHEN 'lbs' THEN 16.0
				    WHEN 'kg' THEN 35.274
				    WHEN 'L' THEN 33.814
				    ELSE 1
				 END) - CID.TodayEstimateInventory) / NULLIF((NULLIF(CID.AvgDailyNeeds,0)/NULLIF(@CurrentYearWorkingDays, 0)), 0)
	 , CI.UnitSize
	  , NULLIF(CID.AvgDailyNeedsForInventoryPeriod,0) /(SELECT NULLIF(COUNT(DISTINCT CAST(PS.StartDateTime AS DATE)),0)
				 FROM TCD.ProductionShiftData PS (NOLOCK) 
				 CROSS JOIN @ChemicalLastInventory cli
				 WHERE PS.StartDateTime >= cli.BeforeLastInventoryDate
				 AND PS.StartDateTime <= cli.LastInventoryDate
				 AND cli.ProductId = CIL.ProductId
			 AND PS.LastSyncTime IS NOT NULL
				 AND EXISTS (SELECT 1 FROM [TCD].ShiftProductionDataRollup SPD (NOLOCK) 
				 WHERE SPD.ShiftId = PS.ShiftId)
				 )
	 FROM TCD.ChemicalInventory CI (NOLOCK)
	 INNER JOIN TCD.ProductdataMapping PDM (NOLOCK) ON CI.ProductId = PDM.ProductID
	 INNER JOIN TCD.ProductMaster PM (NOLOCK) ON PM.ProductId = PDM.ProductID
	 INNER JOIN @ChemicalLastInventory CIL ON CI.InventoryDate = CIL.LastInventoryDate AND CI.ProductId = CIL.ProductId
	 LEFT JOIN #CI_Data CID ON CI.ProductId = CID.ProductId

	 INSERT #InventoryRollUp
	 (ProductId,ChemicalName,LastInventory,InventorybasedConsumption,DispencerBasedConsumption,TodayEstimateInventory
	 ,AvgDailyNeedsYTD,AvgDailyCostYTD,AvgDailyCostloadYTD,AvgDailyNeedsLY,DayBeforeOutOfStock,InventoryDateRange,UnitSize
	 ,AvgDailyNeedsForInventoryPeriod)
	 SELECT CI.ProductId
	  ,CI.ChemicalName
	  ,CI.LastInventory
	  ,CI.InventorybasedConsumption
	  ,CI.DispencerBasedConsumption
	  ,CI.TodayEstimateInventory
	  ,CI.AvgDailyNeedsYTD
	  ,CI.AvgDailyCostYTD
	  ,CI.AvgDailyCostloadYTD
	  ,CI.AvgDailyNeedsLY
	  ,CI.DayBeforeOutOfStock
	  ,CI.InventoryDateRange
	  ,CI.UnitSize
	  ,CI.AvgDailyNeedsForInventoryPeriod
	 FROM @ChemicalInventory CI

		UPDATE [Target]
		SET  [Target].ChemicalName = [Source].ChemicalName
		,[Target].LastInventory = [Source].LastInventory 
		,[Target].InventorybasedConsumption = [Source].InventorybasedConsumption
		,[Target].DispencerBasedConsumption = [Source].DispencerBasedConsumption
		,[Target].TodayEstimateInventory = [Source].TodayEstimateInventory
		,[Target].AvgDailyNeedsYTD = [Source].AvgDailyNeedsYTD
		,[Target].AvgDailyCostYTD = [Source].AvgDailyCostYTD
		,[Target].AvgDailyCostloadYTD = [Source].AvgDailyCostloadYTD
		,[Target].AvgDailyNeedsLY = [Source].AvgDailyNeedsLY
		,[Target].DayBeforeOutOfStock = [Source].DayBeforeOutOfStock
		,[Target].InventoryDateRange = [Source].InventoryDateRange
		,[Target].UnitSize = [Source].UnitSize
		,[Target].AvgDailyNeedsForInventoryPeriod = [Source].AvgDailyNeedsForInventoryPeriod
		FROM TCD.ChemicalInventoryRollUp AS [Target]
		JOIN #InventoryRollUp AS [Source]
		ON [Target].ProductID = [Source].ProductID
    
    
		INSERT TCD.ChemicalInventoryRollUp
		(ProductId,ChemicalName,LastInventory,InventorybasedConsumption,DispencerBasedConsumption,TodayEstimateInventory
		 ,AvgDailyNeedsYTD,AvgDailyCostYTD,AvgDailyCostloadYTD,AvgDailyNeedsLY,DayBeforeOutOfStock,InventoryDateRange,UnitSize
		 ,AvgDailyNeedsForInventoryPeriod)
		SELECT [Source].ProductId, [Source].ChemicalName,[Source].LastInventory,[Source].InventorybasedConsumption
		 ,[Source].DispencerBasedConsumption,[Source].TodayEstimateInventory,[Source].AvgDailyNeedsYTD,[Source].AvgDailyCostYTD
		 ,[Source].AvgDailyCostloadYTD,[Source].AvgDailyNeedsLY,[Source].DayBeforeOutOfStock,[Source].InventoryDateRange, [Source].UnitSize
		 ,[Source].AvgDailyNeedsForInventoryPeriod
		FROM #InventoryRollUp AS [Source]
		LEFT OUTER JOIN TCD.ChemicalInventoryRollUp AS [Target] (NOLOCK)
		ON [Target].ProductID = [Source].ProductID
		WHERE [Target].ProductID IS NULL


	-- CleanUp
	DROP TABLE #InventoryRollUp
	DROP TABLE #CI_Data

	END


GO


