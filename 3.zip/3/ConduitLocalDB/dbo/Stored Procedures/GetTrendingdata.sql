﻿/*  
 ==========================================================================================  
 Purpose:  Fetching the Values for Trending data.  
 
 --------------------------------------------------------------  
 August-01-2014 ENT: Initial version.  
 ==========================================================================================  
 Exec [TCD].[GetTrendingdata] 22,1,-1,'2015-04-17 10:30:00','2015-04-17 10:45:00',1,'40242802'    --Tunnel reading
 Exec [TCD].[GetTrendingdata] 7,NULL,1,'2015-04-17 00:30:00','2015-04-17 10:45:00',1,'40242802'

*/
CREATE PROCEDURE [TCD].[GetTrendingData](@WasherId  INT = NULL,
										 @CompId    INT = NULL,
										 @Parameter INT = NULL,
										 @Starttime DATETIME = NULL,
										 @Endtime   DATETIME = NULL,
								 @UserId INT = NULL,
								 @EcolabAccountNumber NVarchar(25) = NULL
								 )
AS
  BEGIN
	  SET NOCOUNT ON;

	  DECLARE @ISTunnel     INT = NULL,
			  @FormulaName  INT = NULL,
			  @DosingAmount INT = NULL,
			  @Weight       INT = NULL,
			@TransferSignal INT=NULL,
			@LanguageID INT = NULL,
			@loclizeFormulaName NVARCHAR(100) = NULL,
			@loclizeWeight NVARCHAR(100) = NULL,
			@loclizeDosingAmount NVARCHAR(100) = NULL,
			@localizeTransferSignal NVARCHAR(100) = NULL

	  SELECT @LanguageID = UM.LanguageId FROM TCD.UserMaster UM WHERE UM.UserId = @UserId
	   IF(@LanguageID IS NULL) 
		  BEGIN
		   SELECT @LanguageID = UM.LanguageId FROM TCD.Plant UM WHERE UM.EcolabAccountNumber = @EcolabAccountNumber
		  END

	  SELECT @loclizeFormulaName = RKV.Value  FROM TCD.ResourceKeyValue RKV INNER JOIN TCD.ResourceKeyMaster RKM ON RKV.KeyName = RKM.KeyName WHERE RKM.KeyName = 'FIELD_FORMULA_NAME' AND languageID = @LanguageID
	  SELECT @loclizeWeight = RKV.Value  FROM TCD.ResourceKeyValue RKV INNER JOIN TCD.ResourceKeyMaster RKM ON RKV.KeyName = RKM.KeyName WHERE RKM.KeyName = 'WEIGHT' AND languageID = @LanguageID
	  SELECT @loclizeDosingAmount = RKV.Value  FROM TCD.ResourceKeyValue RKV INNER JOIN TCD.ResourceKeyMaster RKM ON RKV.KeyName = RKM.KeyName WHERE RKM.KeyName = 'FIELD_DosingAmount' AND languageID = @LanguageID
	  SELECT @localizeTransferSignal = RKV.Value  FROM TCD.ResourceKeyValue RKV INNER JOIN TCD.ResourceKeyMaster RKM ON RKV.KeyName = RKM.KeyName WHERE RKM.KeyName = 'FIELD_TRANSFER_SIGNAL' AND languageID = @LanguageID

	  SELECT @ISTunnel = istunnel
	  FROM   [TCD].machinesetup
	  WHERE  washerid = @WasherId

	  IF( @Parameter = -1 )
		BEGIN
			SET @Parameter = NULL
		END

	  CREATE TABLE #trendingdata
		(
		   groupid       INT,
		   compartmentid INT,
		   actual        DECIMAL(18, 4),
		   id            INT,
		   parametername VARCHAR(1000),
		   [timestamp]   DATETIME,
		   desired       DECIMAL(18, 4)
		)

	  IF(@ISTunnel = 1
		  AND @Parameter IS NULL)
		BEGIN
			INSERT INTO #trendingdata
						  (
							groupid,
							compartmentid,
							actual,
							id,
							parametername,
							[timestamp],
							desired
						  )
			SELECT DISTINCT SE.groupid,
							SE.machinecompartment,
							TR.reading,
							CP.id,
							CP.NAME,
							TR.[timestamp],
							'0.0'
			FROM   [TCD].sensorreading TR
				   LEFT OUTER JOIN [TCD].sensor SE
								ON TR.sensorid = SE.sensorid
				   INNER JOIN tcd.machinesetup MS
						   ON SE.groupid = MS.groupid
							  --AND SE.machinecompartment = MS.machineinternalid
				   INNER JOIN [TCD].sensortypemaster ST
						   ON SE.sensortype = ST.ResourceId
				   INNER JOIN [TCD].conduitparameters CP
						   ON ST.mappingsensorid = CP.id
			WHERE  Cast(TR.[timestamp] AS DATETIME) >= @Starttime
				   AND Cast(TR.[timestamp] AS DATETIME) <= @Endtime
				   AND MS.washerid = @WasherId
					AND SE.MachineCompartment=@CompId AND CP.IsTrending = 1
		END
	  ELSE
		BEGIN
			INSERT INTO #trendingdata
					   (
							groupid,
							compartmentid,
							actual,
							id,
							parametername,
							[timestamp],
							desired
						  )
			SELECT  SE.groupid,
							SE.machinecompartment,
							TR.reading,
							CP.id,
							CP.NAME,
							TR.[timestamp],
							'0.0'
			FROM   [TCD].sensorreading TR
				   INNER JOIN [TCD].sensor SE
								ON TR.sensorid = SE.sensorid
				   INNER JOIN tcd.machinesetup MS
						   ON SE.groupid = MS.groupid
							  AND SE.machinecompartment = MS.machineinternalid
				   INNER JOIN [TCD].sensortypemaster ST
						   ON SE.sensortype = ST.ResourceId
				   INNER JOIN [TCD].conduitparameters CP
						   ON ST.mappingsensorid = CP.id
			WHERE  Cast(TR.[timestamp] AS DATETIME) >= @Starttime
				   AND Cast(TR.[timestamp] AS DATETIME) <= @Endtime
				   AND MS.washerid = @WasherId
				   AND CP.id = @Parameter AND CP.IsTrending = 1
		END

	  INSERT INTO #trendingdata
					(
							groupid,
							compartmentid,
							actual,
							id,
							parametername,
							[timestamp],
							desired
						  )
	  SELECT DISTINCT MS.groupid,
					  MS.machineinternalid,
					  BD.ProgramNumber,
					  @FormulaName   AS Id,
					  @loclizeFormulaName AS NAME,
					  BD.startdate,
					  BD.ProgramNumber
	  FROM   [TCD].batchdata BD
			 LEFT OUTER JOIN tcd.machinesetup MS
						  ON BD.machineid = MS.washerid
	  WHERE  Cast(bd.startdate AS DATETIME) BETWEEN @Starttime
			 AND @Endtime
			 AND BD.machineid = @WasherId
	  UNION ALL
	  SELECT DISTINCT MS.groupid,
					  MS.machineinternalid,
					  BPD.actualquantity,
					  @DosingAmount  AS Id,
					  pm.Name AS NAME,
					  BD.startdate,
					  BPD.StandardQuantity
	  FROM   [TCD].batchdata BD
			 RIGHT OUTER JOIN tcd.batchproductdata BPD
						   ON BD.batchid = BPD.batchid
			 INNER JOIN tcd.machinesetup MS
					 ON BD.machineid = MS.washerid
				 LEFT JOIN TCD.ProductMaster pm ON pm.ProductId = BPD.ProductId
	  WHERE  Cast(bd.startdate AS DATETIME) BETWEEN @Starttime
			 AND @Endtime
			 AND BD.machineid = @WasherId
	  UNION ALL
	  SELECT DISTINCT MS.groupid,
					  MS.machineinternalid,
					  BD.actualweight,
					  @Weight  AS Id,
					  @loclizeWeight AS NAME,
					  BD.startdate,
					  BD.StandardWeight
	  FROM   [TCD].batchdata BD
			 LEFT OUTER JOIN tcd.machinesetup MS
						  ON BD.machineid = MS.washerid
	  WHERE  Cast(bd.startdate AS DATETIME) BETWEEN @Starttime
			 AND @Endtime
			 AND BD.machineid = @WasherId
	 UNION ALL
  
		  SELECT DISTINCT 
		  MS.GroupId,
		 MS.MachineInternalId,
		 Wr.ParameterValue,
		 @TransferSignal AS Id,
		 @localizeTransferSignal AS Name,
		 BD.StartDate,
		Wr.ParameterValue
		  FROM 
		  [TCD].BatchData BD 
		  LEFT OUTER JOIN 
		  TCD.MachineSetup MS ON BD.MachineId = MS.WasherId
		  INNER JOIN Tcd.WasherReading Wr ON wr.WasherId=Bd.MachineId
		  WHERE
		  CAST(bd.StartDate AS datetime) >= @Starttime and CAST(bd.EndDate AS datetime) <= @Endtime and 
		BD.MachineId = @WasherId AND WR.ParameterId IN (SELECT ID FROM TCD.ConduitParameters cp WHERE cp.Id = 6)

	  SELECT DISTINCT TD.id,
					  TD.groupid,
					  TD.compartmentid,
					  Cast(TD.[timestamp] AS DATETIME) AS [TimeStamp],
					  TD.parametername,
					  Cast(Isnull(TD.actual, 0) AS REAL)  AS Actual,
					  Cast(Isnull(TD.desired, 0) AS REAL) AS Desired
	  INTO   #distinctdata
	  FROM   #trendingdata TD
	  ORDER  BY TD.id,
				TD.timestamp

	  SELECT TD.groupid,
			 TD.compartmentid,
			 TD.[timestamp],
			 TD.parametername,
			 TD.actual,
			 TD.desired
		  FROM #distinctdata TD

	  DROP TABLE #trendingdata

	  DROP TABLE #distinctdata

	  SET NOCOUNT OFF;
  END