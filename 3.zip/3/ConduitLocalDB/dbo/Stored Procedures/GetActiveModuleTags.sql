﻿CREATE PROCEDURE [TCD].[GetActiveModuleTags]
(

@ControllerId INT

)

AS
SET NOCOUNT ON
BEGIN
		DECLARE @TempControllerFields TABLE
		(
				ControllerId INT,
				OpcServer INT,
				IpAddress INT,
				ComportNumber INT,
				WebportFtpEnabled INT,
				WebportIP INT,
				WebportLogin INT,
				WebportPassword INT
		)
		INSERT INTO @TempControllerFields
		(		
				ControllerId ,
				OpcServer ,
				IpAddress ,
				ComportNumber ,
				WebportFtpEnabled ,
				WebportIP ,
				WebportLogin ,
				WebportPassword
		)
		SELECT distinct
				Csd.ControllerId,
				max(case when Fld.Label = 'OPC Server' then Fld.Id end) OpcServer,
				max(case when Fld.Label = 'IP Address' then Fld.Id end) IpAddress,
				max(case when Fld.Label = 'Com port Number' then Fld.Id end) ComportNumber,
				max(case when Fld.Label = 'Webport Ftp Enabled' then Fld.Id end) WebportFtpEnabled,
				max(case when Fld.Label = 'Webport IP' then Fld.Id end) WebportIP,
				max(case when Fld.Label = 'Webport Login' then Fld.Id end) WebportLogin,
				max(case when Fld.Label = 'Webport Password' then Fld.Id end) WebportPassword 
		FROM TCD.Field Fld
				INNER JOIN 
						TCD.ControllerSetupData Csd 
						ON Csd.FieldId=Fld.Id
		GROUP BY Csd.ControllerId

;WITH CteModuleTags(	
					ModuleTagId,
					TagAddress,
					DeadBand,
					ModuleDescription,
					ModuleTypeId,
					TagType,
					TagTypeId,
					TagDescription,						
					ModuleId,
					ControllerId,
					Unit,
					RollOverPoint,
					Calibration,
					UtilityType
				) AS  
				(SELECT 
					Mtg.ModuleTagId,
					Mtg.TagAddress,
					Mtg.DeadBand,
					Mt.ModuleDescription,
					Mt.ModuleTypeId,
					Tt.TagType,
					Tt.TagTypeId,
					Tt.TagDescription,						
					Mtg.ModuleId,	
				CASE 
					when Mtg.ModuleTypeId = 1 then T.ControllerId
					when Mtg.ModuleTypeId = 2 then M.ControllerId
					when Mtg.ModuleTypeId = 3 then S.ControllerId
				END
				AS ControllerId,
				CASE 
					when Mtg.ModuleTypeId = 1 then 'Gallons'
					when Mtg.ModuleTypeId = 2 then M.MeterTickUnit		
					when Mtg.ModuleTypeId = 3 then S.UOM			
				END
				AS Unit,
				CASE 	
					when Mtg.ModuleTypeId = 1 then '0'				
					when Mtg.ModuleTypeId = 2 then M.MaxValueLimit								
					when Mtg.ModuleTypeId = 3 then '0'	
				END
				AS RollOverPoint,
				CASE 	
					when Mtg.ModuleTypeId = 1 then '0'				
					when Mtg.ModuleTypeId = 2 then M.Calibration								
					when Mtg.ModuleTypeId = 3 then '0'	
				END
				AS Calibration,
				CASE 	
					when Mtg.ModuleTypeId = 1 then '0'				
					when Mtg.ModuleTypeId = 2 then M.UtilityType								
					when Mtg.ModuleTypeId = 3 then '0'	
				END
				AS UtilityType
							
				FROM TCD.ModuleTags Mtg 		
				INNER JOIN 
						TCD.ModuleType Mt 
						ON Mt.ModuleTypeId				=			Mtg.ModuleTypeId 

				INNER JOIN
						TCD.TagType Tt 
						ON Tt.TagType					=			Mtg.TagType and Tt.Active=1
				LEFT JOIN 
						TCD.Meter M 
						ON M.MeterId					=			Mtg.ModuleId
				LEFT JOIN 
						TCD.TankSetup T 
						ON T.TankId						=			Mtg.ModuleId
				LEFT JOIN 
						TCD.Sensor S
						ON S.SensorId					=			Mtg.ModuleId
		
				WHERE		
						 Mtg.Active						=			1 	
				AND		 Mtg.ModuleTypeId				<>			4
				AND		 Mtg.TagType					in			('Tag_LVL','Tag_MPLC','Tag_SPLC')

				)
				SELECT	Ctg.ModuleTagId,
						Ctg.TagAddress,
						Ctg.DeadBand,
						Ctg.ModuleDescription,
						Ctg.ModuleTypeId,
						Ctg.TagType,
						Ctg.TagTypeId,
						Ctg.TagDescription,							
						Ctg.ModuleId,
						Ctg.ControllerId,							
						Ctrl.TopicName,										
						Ctrl.ControllerTypeId,
						Ctrl.Name,
						CASE WHEN (CsdOpc.Value IS NULL) THEN NULL 
							 ELSE CsdOpc.Value END 
							 AS OpcServerName,
						CASE WHEN (CsdIP.Value IS NULL) THEN NULL 
							 ELSE CsdIP.Value END 
							 AS IpAddress,
						CASE WHEN (CsdComport.Value IS NULL) THEN NULL 
							 ELSE CsdComport.Value END 
							 AS ComportNumber,
						CASE WHEN (CsdWebFtp.Value IS NULL) THEN NULL
							  WHEN CsdWebFtp.Value = 'False' THEN 0 
							 WHEN CsdWebFtp.Value = 'True' THEN 1  
							 END 
							 AS WebportFtpEnabled,
						CASE WHEN (CsdWebIP.Value IS NULL) THEN NULL 
							 ELSE CsdWebIP.Value END 
							 AS WebportIP,
						CASE WHEN (CsdWebLogin.Value IS NULL) THEN NULL 
							 ELSE CsdWebLogin.Value END 
							 AS WebportLogin,
						CASE WHEN (CsdWebPwd.Value IS NULL) THEN NULL 
							 ELSE CsdWebPwd.Value END 
							 AS WebportPassword,
						Ctrl.ControllerModelId,
						Ctg.Unit,
						Ctg.RollOverPoint,
						Ctg.Calibration,
						Ctg.UtilityType
			FROM CteModuleTags Ctg
			INNER JOIN TCD.ConduitController Ctrl	
				ON Ctg.ControllerId=Ctrl.ControllerId
			INNER JOIN 
						@TempControllerFields Tcf 
						ON Tcf.ControllerId=Ctrl.ControllerId
			LEFT JOIN 
						TCD.ControllerSetupData CsdOpc 
						ON	CsdOpc.FieldId	=	Tcf.OPCServer 
						AND CsdOpc.ControllerId = Ctrl.ControllerId
			LEFT JOIN 
						tcd.ControllerSetupData CsdIp 
						ON	CsdIp.FieldId=Tcf.IpAddress 
						AND CsdIp.ControllerId = Ctrl.ControllerId
			LEFT JOIN 
						TCD.ControllerSetupData CsdComport 
						ON	CsdComport.FieldId=Tcf.ComportNumber 
						AND CsdComport.ControllerId = Ctrl.ControllerId
			LEFT JOIN 
						TCD.ControllerSetupData CsdWebFtp 
						ON	CsdWebFtp.FieldId=Tcf.WebportFtpEnabled 
						AND CsdWebFtp.ControllerId = Ctrl.ControllerId
			LEFT JOIN 
						TCD.ControllerSetupData CsdWebIP 
						ON	CsdWebIP.FieldId=Tcf.WebportIP 
						AND CsdWebIP.ControllerId = Ctrl.ControllerId
			LEFT JOIN 
						TCD.ControllerSetupData CsdWebLogin 
						ON	CsdWebLogin.FieldId=Tcf.WebportLogin 
						AND CsdWebLogin.ControllerId = Ctrl.ControllerId
			LEFT JOIN 
						TCD.ControllerSetupData CsdWebPwd 
						ON	CsdWebPwd.FieldId=Tcf.WebportPassword 
						AND CsdWebPwd.ControllerId = Ctrl.ControllerId

			-- Below condition related data does not exists in the db. For testing puporse we commented below lines.
			WHERE	Ctrl.ControllerId				=			@ControllerId
			--			Ctrl.Active=1 
			--AND		Ctrl.IsDeleted=0
			ORDER BY Ctg.ModuleId ASC				
	END