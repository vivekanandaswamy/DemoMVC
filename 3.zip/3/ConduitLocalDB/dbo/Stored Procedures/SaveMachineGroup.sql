﻿CREATE PROCEDURE TCD.SaveMachineGroup
(@GroupDescription VARCHAR(100)
, @GroupTypeId INT
, @EcolabAccountNumber NVARCHAR(25))
AS
BEGIN
	INSERT INTO TCD.MachineGroup (GroupDescription, GroupTypeId, EcolabAccountNumber, Is_Deleted, LastModifiedByUserId, LastModifiedTime, MyServiceCustMchGrpGuid)
		VALUES (@GroupDescription
			, @GroupTypeId
			, @EcolabAccountNumber
			, 0
			, 1
			, GETUTCDATE()
			, NEWID())
END
