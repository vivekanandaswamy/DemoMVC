﻿CREATE PROCEDURE [TCD].[GetPlantCustomerList] 
@EcolabAccountNumber nvarchar(25)
AS 
  BEGIN 
      SET NOCOUNT ON; 

      SELECT 
	  ID
	  ,[CustomerId]
	  , [CustomerName]
	  ,[IS_Deleted]
      ,EcolabAccountNumber
	  ,LastModifiedTime
	  FROM   
	  [TCD].PlantCustomer 
      WHERE  
	  EcolabAccountNumber = @EcolabAccountNumber
  SET NOCOUNT OFF;
  END