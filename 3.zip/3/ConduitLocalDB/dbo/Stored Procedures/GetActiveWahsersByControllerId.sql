﻿CREATE PROCEDURE [TCD].[GetActiveWahsersByControllerId]
(	
		@ControllerId INT
)

AS
SET NOCOUNT ON
BEGIN
		SELECT 
				Wt.WasherTagId as TagId,
				Wt.TagAddress,
				Tt.TagType,
				Tt.TagTypeId,
				Tt.TagDescription,
				Wt.WasherId,
				Wg.WasherGroupName,
				WgT.WasherGroupTypeName,
				Ms.MachineName as WasherName,
				Ctrl.TopicName,
				CAST(Ws.EndOfFormula AS INT) AS EndOfFormula,
				Ws.AWEActive,
				Ws.RatioDosingActive,
				Ws.ETechWasherNumber
		FROM TCD.MachineSetup  Ms 
		INNER JOIN
				TCD.Washer Ws 
				ON Ws.WasherId					=			Ms.WasherId 
		INNER JOIN 
				TCD.WasherTags Wt 
				ON Wt.washerID					=			Ws.washerId and Wt.Active=1
		INNER JOIN
				TCD.TagType Tt 
				ON Tt.TagType					=			Wt.Tagtype and Tt.Active=1
		INNER JOIN 
				TCD.ConduitController Ctrl 
				ON Ctrl.ControllerId			=			Ms.ControllerId and Ctrl.Active=1
		INNER JOIN 
				TCD.Plant Pl 
				ON Pl.EcolabAccountNumber		=			Ctrl.EcoalabAccountNumber 
		INNER JOIN 
				TCD.WasherGroup Wg 
				on Wg.WasherGroupId				=			Ms.GroupId 
		INNER JOIN 
				TCD.WasherGroupType WgT 
				ON WgT.WasherGroupTypeId		=			Wg.WasherGroupTypeId 

		WHERE	Ctrl.ControllerId				=			@ControllerId
		AND		Ctrl.Active						=			1 
		AND		Ctrl.IsDeleted				=			0
		ORDER BY Ws.washerId ASC

		
	END