﻿CREATE PROCEDURE [TCD].[GetActiveMetersByWasherandControllerId]
	(	
		@WasherId INT,
		@ControllerId INT
)

AS
BEGIN

SET	NOCOUNT	ON														--SQLEnlight	SA0017

			SELECT	Mt.ModuleTagId,
											Mt.TagAddress,
											Tt.TagType,
											Tt.TagTypeId,
											Tt.TagDescription,
											Ms.WasherId,
											Wg.WasherGroupName,
											WgT.WasherGroupTypeName,
											Ms.MachineName as WasherName,
											Ctrl.TopicName,
		    CAST(Ws.EndOfFormula AS INT) AS EndOfFormula 			
			FROM Tcd.MachineSetup Ms
						INNER JOIN TCD.Washer Ws 
						ON Ws.WasherId     =   Ms.WasherId 
						INNER JOIN Tcd.Meter M 
						ON			M.GroupId						=			Ms.GroupId				AND
									M.MachineCompartment			=			Ms.MachineInternalId

						INNER JOIN TCD.ConduitController Ctrl
						ON			Ctrl.ControllerID				=			M.ControllerId

						INNER JOIN Tcd.ModuleTags Mt
						ON			Mt.ModuleId						=			M.MeterId				AND 
									Mt.ModuleTypeId					=			2
						INNER JOIN TCD.TagType Tt 
						ON			Tt.TagType						=			Mt.Tagtype				AND 
									Tt.Active						=			1
						INNER JOIN TCD.Plant Pl 
						ON			Pl.EcolabAccountNumber			=			Ctrl.EcoalabAccountNumber 
						INNER JOIN TCD.WasherGroup Wg 
						ON			Wg.WasherGroupId				=			Ms.GroupId 
						INNER JOIN TCD.WasherGroupType WgT 
						ON			WgT.WasherGroupTypeId			=			Wg.WasherGroupTypeId 

		WHERE						Ms.WasherId						=			@WasherId				AND
									Ctrl.ControllerID				=			@ControllerId


		
	END