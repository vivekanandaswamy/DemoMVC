CREATE Procedure [TCD].[ProcessPLCXLAlarmData]
 (
 @ControllerID int, 
 @VxML xML
 )
AS
BEGIN
  DECLARE 
   @StartDateTime   DATETIME2,
   @StopDateTime   DATETIME2,
   @AlarmNumber   INT,
   @MachineNumber   INT,
   @BatchNumber   INT,
   @DesiredValue   INT,
   @MeasuredValue   INT,
   @Status     INT,
   @ProgramNumber   INT,
   @GroupId    INT,
   @MachineId    INT,
   @BatchID    INT,
   @ECOLABAccountNumber NVARCHAR(1000),
   @CurrentDay    DATE=CAST(GETUTCDATE() as date),
   @IsActive    INT,
   @IsTunnel    INT,
   @AlarmGroupMasterId  INT,
   @PumpNbr int,
   @ValveNbr int,
   @CFErrorCode int,
   @CFErrorDetail int,
   @Probe int,
   @ID int,
   @RowID  int,
   @TotalRows int,
   @AlarmType int,
   @GroupNumber int

   
 CREATE TABLE #AlarmList(RowID int IDentity(1,1),
      AlarmNumber int,
      StartDateTime DateTime,
      MachineNumber int,
      MachineID int,
      BatchNumber int,
      ProgramNumber int,
      DesiredValue int,
      MeasuredValue int,
      [Status] int,
      StopDateTime  DateTime,
      IsTunnel int,
      PumpNbr int,
      ValveNbr int,
      CFErrorCode int,
      CFErrorDetail int,
      [Probe] int,
      [AlarmType] int,
   [Group] int
      )


 INSERT INTO #AlarmList (AlarmNumber,
       StartDateTime,
       MachineNumber,
       BatchNumber,
       ProgramNumber,
       DesiredValue,
       MeasuredValue,
       [Status],
       StopDateTime,
       IsTunnel,
       PumpNbr,
       ValveNbr,
       CFErrorCode,
       CFErrorDetail,
       [Probe],
       [AlarmType],
    [Group]
    )
  SELECT T.c.value('@AlarmNumber', 'INT'),
   T.c.value('@StartDateTime', 'DATETIME'),
   T.c.value('@MachineNumber', 'INT'),
   T.c.value('@BatchNumber', 'INT'),
   T.c.value('@ProgramNumber', 'INT'),
   T.c.value('@DesiredValue', 'INT'),
   T.c.value('@MeasuredValue', 'INT'),
   T.c.value('@Status', 'INT'),
   T.c.value('@StopDateTime', 'DateTime'),
   T.c.value('@IsTunnel', 'INT'),
   T.c.value('@PumpNbr', 'INT'),
   T.c.value('@ValveNbr', 'INT'),
   T.c.value('@CFErrorCode', 'INT'),
   T.c.value('@CFErrorDetail', 'INT'),
   T.c.value('@Probe', 'INT'),
   T.c.value('@AlarmType','INT'),
   T.c.value('@Group','INT')
 FROM @VxML.nodes('MyControlAlarmData') T(C)

 SELECT @TotalRows=Count(*) 
 FROM #AlarmList
 SELECT @RowID = 0
 SELECT @ECOLABAccountNumber = EcoalabAccountNumber 
 FROM TCd.ConduitController
 WHERE ControllerID = @ControllerId

 
 WHILE (@RowID<@TotalRows)
 BEGIN
     SELECT @RowID  = @RowID + 1
     SELECT 
     @AlarmNumber=AlarmNumber,
     @StartDateTime=StartDateTime,
     @MachineNumber=MachineNumber,
     @BatchNumber=BatchNumber,
     @ProgramNumber=ProgramNumber,
     @DesiredValue=DesiredValue,
     @MeasuredValue=MeasuredValue,
     @Status=[Status],
     @StopDateTime=StopDateTime,
     @IsTunnel=isTunnel,
     @PumpNbr=PumpNbr,
     @ValveNbr=ValveNbr,
     @CFErrorCode=CFErrorCode,
     @CFErrorDetail=CFErrorDetail,
     @Probe=[Probe],
  @GroupNumber=[Group],
     @AlarmType=[AlarmType]
   FROM  #AlarmList 
   WHERE rowID = @RowID
   SELECT @GroupID =null,
       @MachineID=null,
       @BatchID=null

   IF (@GroupNumber is not null)
   BEGIN
  SELECT @GroupId = WasherGroupId
  FROM TCD.WasherGroup
  WHERE controllerID = @ControllerID
        and WasherGroupTypeId = @GroupNumber
   END
   IF (@MachineNumber  is not Null)
   BEGIN
    SELECT @GroupId = GroupId, 
       @MachineId = WasherId,
       @AlarmGroupMasterId=null
    FROM TCD.MachineSetup 
    WHERE ControllerId = @ControllerId 
      and IsTunnel = isNull(@IsTunnel,0)
   and MachineInternalId= @MachineNumber

    SELECT @BatchID = BatchId 
    FROM TCD.BatchData
    WHERE MachineId = @MachineId 
       and ControllerBatchId = @BatchNumber 
       and CAST(StartDate as date)= CAST(@StartDateTime as date) 
    UPDATE #AlarmList
    SET MachineID=@MachineId
    WHERE RowID = @RowID
   END
   SELECT TOP 1 @AlarmGroupMasterId = AGM.AlarmGroupMasterId 
   FROM TCD.ConduitController CC 
    INNER JOIN TCD.ControllerModelControllerTypeMapping CMCTM ON CMCTM.ControllerModelId = CC.ControllerModelId 
                     AND CMCTM.ControllerTypeId = CC.ControllerTypeId
    INNER JOIN TCD.AlarmGroupMsterVsControllerModelType AGMVCMT ON CMCTM.Id = AGMVCMT.ControllerModelTypeId
    INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
   WHERE AGMVCMT.AlarmCode = @AlarmNumber AND CC.ControllerId = @ControllerId
   SELECT @ID =null
   SELECT @ID = ID 
   FROM TCD.AlarmData
   WHERE AlarmCode=@AlarmNumber
      and ControllerID = @ControllerID
      and( 
    (@AlarmType = 4  and isNull(@MachineNumber,0) =isNull(MachineInternalId,0) and isNull(@Probe,0) =isNull(ProbeNumber,0) )
    OR
    (@AlarmType = 2  and isNull(@MachineNumber,0) =isNull(MachineInternalId,0))
          OR
        (@AlarmType = 3   and ISNULL(PumpNbr,0)= isNull(@PumpNbr,0))
     OR 
     (@AlarmType = 1)
  OR 
   (@AlarmType = 5 and isNull(GroupID,0) =  isNull(@GroupID,0) )

  )
  and StartDate = @StartDateTime
   


  
 IF (@ID is null)
  BEGIN
    Print '**Probe : ' + convert(nvarchar(10), @Probe)
     INSERT INTO [TCD].[AlarmData] 
  (EcoalabAccountNumber,
  AlarmCode,
  BatchId,
  controllerID,
  StartDate,
  PartitionOn,
  MachineInternalId,
  ProgramId,
  DesiredQuatity,
  MeasuredQuantity,
  TempStatus,
  GroupId,
  MachineId,
  BatchNumber,
  EndDate,
  IsActive,
  AlarmGroupMasterId,
  Valve,
  PumpNbr,
  CFErrorCode,
  CFErrorDetail,
  ProbeNumber
  )
  SELECT
   @ECOLABAccountNumber,
   @AlarmNumber,
   @BatchID,
   @ControllerId,
   @StartDateTime,
      @StartDateTime,
   @MachineNumber,
   @ProgramNumber,
   @DesiredValue,
   @MeasuredValue,
   @Status,
   @GroupId,
   @MachineId,
   @BatchNumber,
   @StopDateTime,
   case when @StopDateTime is null then 1 else 0 end,
   @AlarmGroupMasterId,
   @ValveNbr,
   @PumpNbr,
   @CFErrorCode,
   @CFErrorDetail,
   @Probe
    END
 ELSE 
  BEGIN
   IF (@StopDateTime is  not null ) 
   BEGIN

   UPDATE TCD.AlarmData
   SET EndDate = @StopDateTime, IsActive = 0
   WHERE ID = @ID
      
   END 

  END 
 END  
END