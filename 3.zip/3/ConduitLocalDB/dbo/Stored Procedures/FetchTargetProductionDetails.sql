﻿/****** Object:  StoredProcedure [TCD].[FetchTargetProductioDetails]    Script Date: 04-12-2014 12:06:49 ******/
-- =============================================
-- Author:		<Srikanth>
-- Create date: <04-Dec-2014>
-- Description:	<To Get Batch Collection Data>
-- =============================================
Create  PROCEDURE [TCD].[FetchTargetProductionDetails] 
(
		@EcolabAccountNumber nvarchar(25)
)
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE  @TARGETPRODUCTION table(
	ShiftName varchar(100),
	ShiftId int,
	TargetProduction decimal(18,2),
	DayId int,
	StartTime time,
	EndTime Time,
	TargetProduction_display decimal(18,2),
	LastModifiedTime DATETIME
	)
DECLARE @Count int 
	 set  @Count = (select COUNT(1) FROM TCD.TARGETPRODUCTIONDETAILS)
	IF (@Count > 0)
	   BEGIN
	   WITH temp as(
		 (
		   select 
			S.ShiftName, 
			cast(S.ShiftId as int) as ShiftId,
			TPD.TargetProduction,
			TPD.DAYID,
			S.StartTime,
			S.EndTime,
			TPD.TargetProduction_Display,
			TPD.LastModifiedTime
		   from 
		   tcd.ShiftData S left JOIN 
		   TCD.TARGETPRODUCTIONDETAILS TPD ON S.ShiftId = TPD.ShiftId WHERE DATEADD(day, 1, TPD.RECORDEDDATE) > GETDATE() and s.Is_Deleted =0)
		 )
		 INSERT INTO @TARGETPRODUCTION SELECT * FROM temp 
		 --SELECT * FROM @TARGETPRODUCTION
			   END
	     select 
			sd.ShiftName, 
			cast(sd.ShiftId as int) as ShiftId,
			sd.TargetProduction,sd.DAYID,
			sd.StartTime,
			sd.EndTime,
			sd.TargetProduction_Display,
			sd.LastModifiedTime
		  into #TARGETPRODUCTION1 FROM TCD.ShiftData sd 
		  where Is_Deleted <> 1 and EcolabAccountNumber = @EcolabAccountNumber AND sd.ShiftId NOT IN (SELECT ShiftId from @TARGETPRODUCTION)
		  insert  into #TARGETPRODUCTION1  SELECT * from  @TARGETPRODUCTION
		  SELECT * FROM #TARGETPRODUCTION1
		  DROP table #TARGETPRODUCTION1
	SET NOCOUNT OFF;
END


