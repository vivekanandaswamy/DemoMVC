﻿CREATE PROCEDURE [TCD].[SaveProductionShiftManualRewashRollup](
--DECLARE
												@Date datetime = NULL,--'2015-05-26',
												@ManualData int = NULL,--1000,
												@WasherGroupId int = NULL,--3,
												@ProgramMasterId int = NULL--21
												
												
											 )
AS
SET NOCOUNT ON
BEGIN
    DECLARE 
		  @ShiftId Int = NULL,   		  
		  @BatchUTCStart DATETIME= NULL,
		  @BatchUTCEnd DATETIME= NULL,
		  @ShiftTargetProd Decimal(18,2) = NULL,
		  @ShiftCount Int = 1,
		  @validateShiftName varchar(100),
		  @MachineManualRewash int,
		  @Fromdate datetime,
		  @ToDate datetime

    SET @Fromdate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@Date AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@Date AS time)) AS DateTime))
	SET @ToDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(DATEADD(d,1,@Date) AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(DATEADD(d,1,@Date) AS time)) AS DateTime))

    DECLARE @ShiftProductionDataRollup TABLE
				 (
					[ShiftId] [int] NOT NULL,
					[MachineId] [int] NULL,
					[ProgramMasterId] [int] NULL,
					[EcolabWasherId] [int] NULL,
					[NoOfLoads] [int] NULL,
					[ActualProduction] [int] NULL,
					[StandardProduction] [int] NULL,
					[LoadEfficiency] [decimal](18, 2) NULL,
					[TimeEfficiency] [decimal](18, 2) NULL,
					[PlantTargetProd] [int] NULL,
					[ActualRunTime] [int] NULL,
					[TargetRunTime] [int] NULL,
					[EcolabTextileId] [int] NULL,
					[ChainTextileId] [int] NULL,
					[ChainProgaramId] [int] NULL,
					[CustomerId] [int] NULL,
					[NoOfPieces] [int] NULL,
					[ActualTurnTime] [int] NULL,
					[TargetTurnTime] [int] NULL,
					[ManualRewash] [int] NULL
				)
	   
    DECLARE @BatchShiftTable TABLE
						(
						  RowNumber int IDENTITY(1,1),
						  BatchUTCStartDate datetime,
						  BatchUTCEndDate datetime,
						  ShiftId int,
						  ShiftName varchar(100)
						)
  		  
	 INSERT INTO @BatchShiftTable
	 (
	    BatchUTCStartDate,
	    BatchUTCEndDate,
	    ShiftId,
	    ShiftName
	 )
	 SELECT 
		  DISTINCT
			StartDateTime,
			EndDateTime,
			SD.ShiftID,
			ShiftName		   
					FROM [TCD].ProductionShiftData SD WITH (NOLOCK)
									   INNER JOIN TCD.ShiftProductionDataRollup spdr WITH (NOLOCK) ON spdr.ShiftId = SD.ShiftId
					 WHERE sd.StartDateTime >= @Fromdate AND  SD.StartDateTime < @ToDate
					 AND SD.ShiftName <> 'No Shift'
					   ORDER BY SD.ShiftId

    DECLARE @ManualInputData TABLE
			 (
				ManualInput int,
				WasherGroupId int,
				ProgramMasterId int
				
			 )
			 INSERT @ManualInputData
			 (
			     ManualInput,
				WasherGroupId,
			     ProgramMasterId
				
			 )
			
			 SELECT @ManualData/NULLIF((SELECT COUNT(1) FROM @BatchShiftTable bst WHERE bst.ShiftName <> 'No Shift'),0),
				    @WasherGroupId,
				   @ProgramMasterId

	DECLARE @ManualInputWasherLevelData TABLE
			 (
				ManualInput int,
				WasherId int,
				ProgramMasterId int
			 )
	
    			
	   ------------------******// Inserting the Data into Batch Summary Temp table based on UTC shift timings //******-----------------------
    WHILE (@ShiftCount <= (SELECT COUNT(1) FROM @BatchShiftTable bst))
    BEGIN

    SELECT  @BatchUTCStart = 
				    bst.BatchUTCStartDate,
			   @BatchUTCEnd = 
				    bst.BatchUTCEndDate,
			   @ShiftId = bst.ShiftId,
			   @validateShiftName = bst.ShiftName
				FROM @BatchShiftTable bst WHERE bst.RowNumber = @ShiftCount

        
    INSERT INTO @ShiftProductionDataRollup
		  ([ShiftId]
           ,[MachineId]
           ,[ProgramMasterId]
           ,[EcolabWasherId]
           ,[NoOfLoads]
           ,[ActualProduction]
           ,[StandardProduction]
           ,[LoadEfficiency]
           ,[TimeEfficiency]
           ,[PlantTargetProd]
           ,[ActualRunTime]
           ,[TargetRunTime]
           ,[EcolabTextileId]
           ,[ChainTextileId]
           ,[ChainProgaramId]
           ,[CustomerId]
           ,[NoOfPieces]
           ,[ActualTurnTime]
           ,[TargetTurnTime]
		 ,[ManualRewash]
		 )
    SELECT 
		  [ShiftId]
           ,[MachineId]
           ,[ProgramMasterId]
           ,[EcolabWasherId]
           ,[NoOfLoads]
           ,[ActualProduction]
           ,[StandardProduction]
           ,[LoadEfficiency]
           ,[TimeEfficiency]
           ,[PlantTargetProd]
           ,[ActualRunTime]
           ,[TargetRunTime]
           ,[EcolabTextileId]
           ,[ChainTextileId]
           ,[ChainProgaramId]
           ,[CustomerId]
           ,[NoOfPieces]
           ,[ActualTurnTime]
           ,[TargetTurnTime],
		 [ManualRewash] 
				FROM TCD.ShiftProductionDataRollup spdr WHERE spdr.ShiftId = @ShiftId
	  
	--	  SELECT spdr.* FROM @ShiftProductionDataRollup spdr
	

	     INSERT INTO @ManualInputWasherLevelData
	     (
	         ManualInput,
	         WasherId,
	         ProgramMasterId
	     )
	    	 SELECT 
				DISTINCT
				    MID.ManualInput/NULLIF((SELECT COUNT(1) FROM TCD.MachineSetup ms2 WHERE ms2.GroupId = ms.GroupId),0),
				    ms.WasherId,
				    MID.ProgramMasterId
				    FROM
				    @ManualInputData MID INNER JOIN TCD.MachineSetup ms ON mid.WasherGroupId = ms.GroupId
						 INNER JOIN @ShiftProductionDataRollup spdr ON spdr.MachineId = ms.WasherId AND spdr.ProgramMasterId = MID.ProgramMasterId
				    GROUP BY MID.ManualInput,ms.WasherId,MID.ProgramMasterId,ms.GroupId
	
	   --SELECT miwld.* FROM @ManualInputWasherLevelData miwld

	    --------------------------******// Inserting the Data into production Shift Rollup Data Table //******-------------------
	      		  
		 DELETE FROM [TCD].ShiftProductionDataRollup WHERE ShiftId = @ShiftId 
		 
			 INSERT INTO [TCD].ShiftProductionDataRollup
								(
								    ShiftId,
								    MachineId,
								    ProgramMasterId,
								    EcolabWasherId,
								    NoOfLoads,
								    ActualProduction ,
								    StandardProduction,
								    LoadEfficiency,
								    TimeEfficiency,
								    PlantTargetProd ,
								    ActualRunTime,
								    TargetRunTime,
								    EcolabTextileId,
								    ChainTextileId,
								    ChainProgaramId,
								    CustomerId,
								    NoOfPieces,
								    ActualTurnTime,
								    TargetTurnTime,
								    ManualRewash
								)	


			 SELECT 
				    spdr.[ShiftId]
				   ,spdr.[MachineId]
				   ,spdr.[ProgramMasterId]
				   ,spdr.[EcolabWasherId]
				   ,spdr.[NoOfLoads]
				   ,spdr.[ActualProduction]  
				   ,spdr.[StandardProduction]
				   ,spdr.[LoadEfficiency]
				   ,spdr.[TimeEfficiency]
				   ,spdr.[PlantTargetProd]
				   ,spdr.[ActualRunTime]
				   ,spdr.[TargetRunTime]
				   ,spdr.[EcolabTextileId]
				   ,spdr.[ChainTextileId]
				   ,spdr.[ChainProgaramId]
				   ,spdr.[CustomerId]
				   ,spdr.[NoOfPieces]
				   ,spdr.[ActualTurnTime]
				   ,spdr.[TargetTurnTime] 
				   ,ISNULL(spdr.ManualRewash,0) + mid.ManualInput
						  FROM @ShiftProductionDataRollup spdr
							 LEFT JOIN
								    @ManualInputWasherLevelData  mid ON 
								    spdr.ProgramMasterId = mid.ProgramMasterId 
								    AND spdr.MachineId = mid.WasherId --IN (SELECT ms.WasherId FROM @ManualInputData mid INNER JOIN TCD.MachineSetup ms ON mid.WasherGroupId = ms.GroupId)
				   
					

		  IF(@validateShiftName <> 'No Shift')
		  BEGIN
		  IF NOT EXISTS(SELECT DISTINCT spdr.ProgramMasterId,spdr.MachineId FROM TCD.ShiftProductionDataRollup spdr WHERE spdr.ShiftId = @ShiftId
																   AND spdr.ProgramMasterId IN (SELECT mid.ProgramMasterId FROM @ManualInputWasherLevelData mid)
																   AND spdr.MachineId IN (SELECT mid.WasherId FROM @ManualInputWasherLevelData mid))
				BEGIN
				   INSERT INTO [TCD].ShiftProductionDataRollup
								(
								    ShiftId,
								    MachineId,
								    ProgramMasterId,
								    EcolabWasherId,
								    NoOfLoads,
								    ActualProduction ,												
								    PlantTargetProd ,
								    ActualRunTime,
								    TargetRunTime,						
								    ActualTurnTime,
								    TargetTurnTime,
								    ManualRewash
								)	


				SELECT TOP 1 
					   spdr.[ShiftId]
					  ,(SELECT TOP 1 ms.WasherId FROM @ManualInputData mid INNER JOIN TCD.MachineSetup ms ON mid.WasherGroupId = ms.GroupId)
					  ,(SELECT mid.ProgramMasterId FROM @ManualInputData mid)
					  ,(SELECT w.EcolabWasherId FROM TCD.Washer w WHERE W.WasherId IN (SELECT TOP 1 ms.WasherId FROM @ManualInputData mid INNER JOIN TCD.MachineSetup ms ON mid.WasherGroupId = ms.GroupId))
					  ,1
					  ,ISNULL(NULL,0)
					  ,spdr.[PlantTargetProd]
					  ,ISNULL(NULL,0)
					  ,ISNULL(NULL,0)
					  ,ISNULL(NULL,0)
					  ,ISNULL(NULL,0),
					  (SELECT mid.ManualInput FROM @ManualInputData mid)
							 FROM TCD.ShiftProductionDataRollup spdr WHERE spdr.ShiftId = @ShiftId
								
								    
				END
			END
	  	   DELETE FROM @ShiftProductionDataRollup	
		   DELETE FROM @ManualInputWasherLevelData	 
		  SET @ShiftCount = @ShiftCount + 1
	    END	   
	  
END