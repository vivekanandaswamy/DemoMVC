﻿/*
==========================================================================================
Purpose:  FETCHING DRYER DATA BY ITS GROUPID

Author: Venkata Mohan Krishna K


--------------------------------------------------------------
Sep-09-2014 ENT: Initial version.
==========================================================================================
*/

CREATE PROCEDURE [TCD].[GetDryersByGroupId] (@dryerGroupId int,@PageNo int = NULL,@RecordsPerPage int =NULL,@Sortcolumn varchar(100),@SortDirection char)
AS
BEGIN
SET nocount ON;

SET		@Sortcolumn				=			ISNULL(@Sortcolumn, NULL)						--SQLEnlight SA0029
SET		@SortDirection			=			ISNULL(@SortDirection, NULL)					--SQLEnlight SA0029

SELECT
D.DryerNo
, D.[Description]
, D.Model
, D.Capacity
, COUNT(DryerNo) OVER() as TotalCount
FROM   [TCD].Dryers d
Inner Join [TCD].MachineGroup gt on d.DryerGroupId = gt.Id
WHERE D.DryerGroupId = @dryerGroupId and gt.GroupTypeId = 3 and D.Is_Deleted != 1
Order By DryerNo Desc
OFFSET (@PageNo-1)*@RecordsPerPage ROWS
FETCH NEXT @RecordsPerPage ROWS ONLY
END
