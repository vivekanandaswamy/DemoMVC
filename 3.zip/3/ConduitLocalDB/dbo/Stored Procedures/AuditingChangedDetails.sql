﻿CREATE PROCEDURE [TCD].[AuditingChangedDetails] 
--(@ReferenceID Nvarchar(100),@OldValue Nvarchar(100),@NewValue NVARCHAR(100),@Column_name Nvarchar(100),@table_Name  Nvarchar(100),@UserID int
--)						--SQLEnlight	SA0029; Commented-out, since this is a deprecated SP - NOT to be used
As
BEGIN
SET NOCOUNT ON 
				/*	Commenting this out, since we have resorted to a diff. auditing implementation
		      IF(ISNULL(@OldValue,'') <> @NewValue) 
              BEGIN 
                        BEGIN 
                            DECLARE @Audit_InsertID INT 

                            IF NOT EXISTS (SELECT * 
                                           FROM   [TCD].auditcolumns 
                                           WHERE  columnname = @Column_Name 
                                                  AND tablename = @Table_name) 
                              BEGIN 
                                  INSERT INTO [TCD].auditcolumns 
                                  VALUES     (@Column_Name, 
                                              @Table_name) 

                                  SELECT @Audit_InsertID = id 
                                  FROM   [TCD].auditcolumns 
                                  WHERE  columnname = @Column_Name 
                                         AND tablename = @Table_name 

                                  INSERT INTO [TCD].auditcolumnsdetails_New 
                                  SELECT @ReferenceID,@Audit_InsertID, 
                                         @OldValue, 
                                         @NewValue, 
                                         @UserID, 
                                         Getdate() 
                              END 
                            ELSE 
                              BEGIN 
                                  SELECT @Audit_InsertID = id 
                                  FROM   [TCD].auditcolumns 
                                  WHERE  columnname = @Column_name 
                                         AND tablename = @Table_name 

                                  INSERT INTO [TCD].auditcolumnsdetails_New 
                                  SELECT @ReferenceID,@Audit_InsertID, 
                                         @OldValue, 
                                         @NewValue, 
                                         @UserID, 
                                         Getdate() 
                              END 
                        END 
                    End		*/
END