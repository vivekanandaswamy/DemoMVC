﻿/*	
Stored Procedure	:	[TCD].[GetTunnelTransferType]	in	TRASAR3 Db... for use in disconnected scenario

Purpose				:	To populate the drop-down (TransferType) in the Washer setup --> Tunnel-General tab. No changes for Central reqd.

Parameters			:	None

*/
CREATE	PROCEDURE	[TCD].[GetTunnelTransferType]
(
	@EcolabAccNumber NVARCHAR (25) = NULL
)
AS
BEGIN

SET	NOCOUNT	ON

DECLARE @RegionId	INT	
SELECT @RegionId = RegionId FROM TCD.PLANT WHERE EcolabAccountNumber = @EcolabAccNumber

SELECT	TTTy.Name						AS			Name
	,	CAST(TTTy.TunnelTransferTypeId AS INT)
										AS			Id
FROM	[TCD].TunnelTransferType		TTTy
WHERE	TTTy.Is_Deleted					=			'FALSE'
AND		TTTy.RegionId					=			@RegionId

SET	NOCOUNT	OFF

END
