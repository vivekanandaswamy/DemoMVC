﻿CREATE PROCEDURE [TCD].[GetWasherGroupFormulaWashStepsResync]
		@EcoLabAccountNumber					NVARCHAR(25)
				,	@WasherGroupId							INT
				,	@ProgramSetupId							INT
				,	@DosingSetupId							INT				=	NULL			--Null for LIST
AS
BEGIN

SET	NOCOUNT	ON

/*																								--SQLEnlight SA0004
DECLARE
		@WasherGroupNumber						VARCHAR(10)	= NULL
	,	@WasherGroupName						NVARCHAR(50) = NULL
	,	@WasherGroupTypeId						TINYINT	= NULL
	,	@WasherGroupTypeName					VARCHAR(30) = NULL

SELECT	@WasherGroupTypeId			=			WGT.WasherGroupTypeId							--SQLEnlight SA0004
	,	@WasherGroupTypeName		=			WGT.WasherGroupTypeName							--SQLEnlight SA0004
	,	@WasherGroupNumber			=			WG.WasherGroupNumber							--SQLEnlight SA0004
	,	@WasherGroupName			=			WG.WasherGroupName								--SQLEnlight SA0004
FROM	[TCD].WasherGroup					WG
JOIN	[TCD].WasherGroupType				WGT
	ON	WG.WasherGroupTypeId		=			WGT.WasherGroupTypeId
JOIN	[TCD].MachineGroup					GT
	ON	WG.WasherGroupId			=			GT.Id
WHERE	GT.EcolabAccountNumber		=			@EcoLabAccountNumber
	AND	WG.WasherGroupId			=			@WasherGroupId
*/																								--SQLEnlight SA0004

			SELECT
				[WasherDosingSetupId] AS DosingSetupId
				,WPS.WasherProgramSetupId
				,WPS.[ProgramNumber]
				,WPS.[WasherGroupId]
				,[StepNumber]
				,WS.[StepId] AS WashOperationId
				,WS.[StepName] AS WashOperation
				,[StepRunTime] AS RunTime
				,[Temperature]
				,[WaterType]
				,[WaterLevel]
				,DD.[DrainDestinationId] AS DrainDestinationId
				,DD.[DrainDestinationName] AS DrainDestination
				,[pHLevel]
				,[Note]
				,WDS.EcoLabAccountNumber
				,WDS.MyServiceCustFrmulaStpGUID
				,WDS.MyServiceLastSynchTime
			FROM	[TCD].[WasherDosingSetup]			WDS
			INNER JOIN [TCD].[WasherProgramSetup] WPS 
				ON WPS.[WasherProgramSetupId] = WDS.[WasherProgramSetupId]
			LEFT JOIN	[TCD].WashStep				WS
				ON	WS.StepId					=			WDS.StepTypeId
			LEFT JOIN	[TCD].DrainDestination		DD
				ON	DD.DrainDestinationId		=			WDS.DrainDestinationId
			WHERE	
				WDS.WasherProgramSetupId		=			@ProgramSetupId
				AND WDS.EcolabAccountNumber		=			@EcoLabAccountNumber
				AND	WDS.GroupId					=			@WasherGroupId
				AND	WDS.WasherDosingSetupId		=			ISNULL(@DosingSetupId, WDS.WasherDosingSetupId)
				--AND	WDS.Is_Deleted				=			'FALSE'
	
SET	NOCOUNT	OFF

END
