﻿CREATE PROCEDURE [TCD].[GetWasherProductDeviationData](
	 @WasherId INT
	,@controllerId INT
    , @EcolabAccountNumber NVARCHAR(25))
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE
	    @plantId INT = (SELECT P.PlantId
					  FROM TCD.Plant P
					  WHERE P.EcolabAccountNumber = @EcolabAccountNumber);

	DECLARE @WasherProductDeviationCount INT = (Select COUNT(WasherProductDeviationID) from TCD.WasherProductDeviations where ControllerId = @controllerId AND WasherId = @WasherId)
	DECLARE @ControllerEquipmentSetupCount INT = (Select COUNT(ControllerEquipmentSetupId) from TCD.ControllerEquipmentSetup where ControllerId = @controllerId)

IF(@WasherProductDeviationCount = 0)
	BEGIN
		SELECT	WPD.WasherProductDeviationID,
				CES.ControllerEquipmentId,
				PM.Name,
				CASE CES.ConventionalWasherGroupConnection 
						WHEN 0 THEN 0
						WHEN 1 THEN CAST(ISNULL(wpd.ProductDeviation,100) AS int)
						END ProductDeviation,
				ISNULL(CES.ConventionalWasherGroupConnection,0)
				,PM.EnvisionDisplayName
		FROM
						TCD.ControllerEquipmentSetup CES 
			LEFT JOIN	TCD.WasherProductDeviations WPD	ON	WPD.ControllerId = CES.ControllerId
														AND WPD.ControllerEquipmentID = CES.ControllerEquipmentId
														AND wpd.WasherId = @WasherId
			LEFT JOIN	TCD.ProductMaster PM				ON	PM.ProductId = CES.ProductId
		WHERE CES.ControllerId = @controllerId

		ORDER BY WPD.ControllerEquipmentId

	END
ELSE
	BEGIN
		   SELECT 
					WPD.WasherProductDeviationID,
					WPD.ControllerEquipmentId,
					PM.Name,
					CASE CES.ConventionalWasherGroupConnection 
						WHEN 0 THEN 0
						WHEN 1 THEN CAST(ISNULL(wpd.ProductDeviation,100) AS int)
						END ProductDeviation,
					ISNULL(CES.ConventionalWasherGroupConnection,0),
					PM.EnvisionDisplayName
			FROM 
							TCD.WasherProductDeviations WPD
				INNER JOIN	TCD.ControllerEquipmentSetup CES	ON	WPD.ControllerId = CES.ControllerId
																AND WPD.ControllerEquipmentID = CES.ControllerEquipmentId 
																AND wpd.WasherId = @WasherId
				LEFT JOIN	TCD.ProductMaster PM				ON	PM.ProductId = CES.ProductId

		WHERE WPD.ControllerId = @controllerId AND PlantId = @plantId AND wpd.WasherId = @WasherId

		ORDER BY WPD.ControllerEquipmentId
	END
   SET NOCOUNT OFF;
END;
