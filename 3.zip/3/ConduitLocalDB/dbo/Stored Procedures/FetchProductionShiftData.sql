﻿CREATE PROCEDURE [TCD].[FetchProductionShiftData]
	AS
BEGIN
	SET NOCOUNT ON;
	   DECLARE @ShiftId INT
		SELECT @ShiftId = ISNULL(MAX(MessageId),0) FROM tcd.TcpMessageQueue WHERE EntityType = 'Ecolab.Models.PlantSetup.ShiftLabor.ProductionShiftContainer'

		SELECT 
		EcolabAccountNumber
		, ShiftId
		, ShiftName
		, StartDateTime
		, EndDateTime
		, TargetProduction
		, LastSyncTime
		FROM TCD.ProductionShiftData
		WHERE
		LastSyncTime IS NULL AND ShiftId > @ShiftId
		ORDER BY ShiftId
	SET NOCOUNT OFF;
END
