/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_GetTankDetails]                                         

Purpose:				To get the tank details.

Parameters:				@TankId - holds the tank id.
						@EcolabAccountNumber - holds the Ecolab account number.
																																		
###################################################################################################                                           
*/
CREATE PROCEDURE [TCD].[GetTankDetails] (@TankId INT = NULL,
 @EcolabAccountNumber nvarchar(25),
 @IsResync Bit = NULL)
AS 
  BEGIN 
      SET NOCOUNT ON;
	   
	  SELECT ts.TankId,ts.TankName,ts.LowAlarmLevel,ts.EmptyLevel,ts.CalibrationLevel,
				CASE WHEN ISNULL(ts.InputType,'')='' THEN '0-20mA'
				ELSE ts.InputType END AS InputType,
				ts.LevelDeviation,ts.Size,
				cc.ControllerId,cc.Name, pdm.ProductID,CASE  
				WHEN ISNULL(PM.EnvisionDisplayName,'') = '' THEN PM.NAME
				ELSE PM.EnvisionDisplayName 
				END  AS ProductName, 
				(SELECT TagAddress FROM tcd.ModuleTags WHERE ModuleId = TS.TankId AND TagType ='Tag_LVL' AND ModuleTypeId = 1 AND Active = 1) AS LevelAddress,
				(SELECT TagAddress FROM tcd.ModuleTags WHERE ModuleId = TS.TankId AND TagType ='Tag_DEV' AND ModuleTypeId = 1 AND Active = 1) AS DeviationAddress,
				(SELECT TagAddress FROM tcd.ModuleTags WHERE ModuleId = TS.TankId AND TagType ='Tag_SIZ' AND ModuleTypeId = 1 AND Active = 1) AS SizeAddress
				,ts.CurrentLevel, ts.LastModifiedTime,ts.LastSyncTime,ts.EcoalabAccountNumber,
				ts.LowAlarmLevel_Display,ts.EmptyLevel_Display,ts.CalibrationLevel_Display,ts.CurrentLevel_Display,ts.LevelDeviation_Display,ts.Size_Display,ts.Is_Deleted
				FROM [TCD].TankSetup ts INNER JOIN [TCD].ConduitController cc
				ON ts.ControllerId=cc.ControllerId
				INNER JOIN [TCD].ProductdataMapping pdm ON ts.SKU=pdm.SKU
				INNER JOIN [TCD].ProductMaster pm on pm.ProductId = pdm.ProductID
				WHERE	(ts.TankId = @TankId 
						OR	@TankId = 0 
						)
				AND ts.EcoalabAccountNumber=@EcolabAccountNumber
				AND (
						(	ts.Is_Deleted=0		
							AND	@IsResync	IS NULL
						)
						OR	@IsResync	IS NOT NULL
					)

      SET NOCOUNT OFF; 
  END