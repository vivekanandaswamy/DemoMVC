CREATE PROCEDURE [TCD].[GetNavigationMenuDetails]
				
				(@EcoLabAccountNumber				NVARCHAR(25) = NULL,
				 @PassingRoleCode					NVARCHAR(250) = NULL)

AS
BEGIN

SET	NOCOUNT	ON



DECLARE @Eqip_Table TABLE
(
Id INT,
PumpCount INT,
ControllerID INT,
ControllerEquipmentTypeId INT
)
INSERT INTO @Eqip_Table
				    (
					   Id,
					   PumpCount,
					   ControllerID,
					   ControllerEquipmentTypeId
				    )

SELECT	ROW_NUMBER() OVER (ORDER BY ControllerId, A.ControllerEquipmentTypeId) AS Id,PumpCount,ControllerId,ControllerEquipmentTypeId FROM

(SELECT DISTINCT ISNULL(CSD.Value, 0) AS PumpCount,CC.ControllerId,Isnull(CES.ControllerEquipmentTypeId,1) AS ControllerEquipmentTypeId
FROM	[TCD].ConduitController						CC
JOIN	[TCD].ControllerSetupData	CSD
	ON	CC.ControllerId						=			CSD.ControllerId
	AND FieldId in (61,71,122,184,200)
	AND csd.EcolabAccountNumber = cc.EcoalabAccountNumber
LEFT OUTER JOIN TCD.ControllerEquipmentSetup CES ON CC.ControllerId = CES.ControllerId
WHERE CC.ControllerId !=0 AND cc.EcoalabAccountNumber = @EcoLabAccountNumber
UNION 
SELECT CMCTM.PumpValveCount
	, CC.ControllerId
	, 1 AS ControllerEquipmentTypeId
  FROM TCD.ConduitController CC
	  JOIN
	  TCD.ControllerModelControllerTypeMapping CMCTM ON CMCTM.ControllerModelId = CC.ControllerModelId
										   AND CMCTM.ControllerTypeId = CC.ControllerTypeId
										   AND CC.ControllerModelId IN (7,8,9,10,11,14)
  WHERE CC.ControllerId != 0
    AND cc.EcoalabAccountNumber = @EcoLabAccountNumber
    AND CC.IsDeleted = 0
    AND (CMCTM.PumpValveCount > 0 OR CMCTM.MECount  > 0)
    --UNION
--SELECT CMCTM.MECount
--	, CC.ControllerId
--	, 2 AS ControllerEquipmentTypeId
--  FROM TCD.ConduitController CC
--	  JOIN
--	  TCD.ControllerModelControllerTypeMapping CMCTM ON CMCTM.ControllerModelId = CC.ControllerModelId
--										   AND CMCTM.ControllerTypeId = CC.ControllerTypeId
--										   AND CC.ControllerModelId IN (7,8,9,10,11,14)
--  WHERE CC.ControllerId != 0
--    AND cc.EcoalabAccountNumber = @EcoLabAccountNumber
--    AND CMCTM.MECount > 0
--    AND CC.IsDeleted = 0
 ) A

DECLARE @PumpCount TABLE
(
RowNumber INT,
PumpCount INT,
Id INT,
ControllerID INT,
ControllerEquipmentTypeId INT
)

DECLARE @Role_Menu TABLE
(
SectionID INT,
SectionName Varchar(100),
SectionCode  Varchar(100),
SectionType Varchar(100),
ControllerName Varchar(100),
ViewName Varchar(100),
ResourceClass Varchar(100),
ResourceKey Varchar(100),
ParentId INT
)

DECLARE @Id INT = 1,@MaxID int
SELECT @MaxID = COUNT(1) FROM @Eqip_Table


WHILE(@ID <= @MaxID)
BEGIN
DECLARE @Count INT,@ControllerId INT,@ControllerEquipmentTypeId INT, @ControllerModelId INT
SELECT TOP 1 @Count = PumpCount,@ControllerId = ControllerId , @ControllerEquipmentTypeId = ControllerEquipmentTypeId  FROM @Eqip_Table WHERE Id = @Id
SELECT TOP 1 @ControllerModelId = ControllerModelId FROM TCD.ConduitController CC WHERE CC.ControllerId = @ControllerId	
IF(@ControllerModelId  IN (7,8,9,10,11,14))
BEGIN
INSERT INTO @PumpCount
SELECT CES.ControllerEquipmentId AS RowNumber, CASE CES.ControllerEquipmentTypeId WHEN 1 THEN CMCTM.PumpValveCount	 ELSE CMCTM.MECount	END AS PumpCount, @Id AS Id, CES.ControllerId, CES.ControllerEquipmentTypeId 
FROM TCD.ControllerEquipmentSetup CES  
JOIN TCD.ConduitController CC ON CC.EcoalabAccountNumber = CES.EcoLabAccountNumber AND CC.ControllerId = CES.ControllerId 
JOIN TCD.ControllerModelControllerTypeMapping CMCTM ON CMCTM.ControllerModelId = CC.ControllerModelId AND CMCTM.ControllerTypeId = CC.ControllerTypeId
WHERE CES.ControllerId  = @ControllerId AND CES.EcoLabAccountNumber = @EcoLabAccountNumber
END
ELSE
BEGIN
IF	(ISNULL(@Count, 0)	<>	0)
BEGIN
	;
	WITH	NumCTE	(N)
	AS	(	SELECT	'*'	AS	N
			UNION ALL
			SELECT	'*'	AS	N
	)
	INSERT INTO @PumpCount(PumpCount,Id,RowNumber,ControllerId,ControllerEquipmentTypeId)
	SELECT	Top	(@Count)
			@Count,@Id,ROW_NUMBER() OVER(ORDER BY N1.N),@ControllerId,@ControllerEquipmentTypeId
	from	NumCTE N1	,NumCTE N2	,NumCTE N3	,NumCTE N4	,NumCTE N5 
END
END
SET @Id = @Id + 1
END


INSERT INTO @Role_Menu(SectionID,SectionName,SectionCode,SectionType,ControllerName,ViewName,ResourceClass,ResourceKey,ParentId)
EXEC [TCD].[FetchMenuSettingsByRoleCode] @PassingRoleCode

;With menu_CTE (ID,Number,Name,ParentID,TypeId,TypeName,ControllerTypeId,ControllerModelId,WasherGroupId,WasherTypeFlag,WasherGroupTypeId,Hierarchy,SectionCode)
AS
(
--- CONTROLLER DATA--
SELECT 
			0 as ID, 
			Null as Number,
			'Dispensers' as Name, 
			Null as ParentID,
			1  AS TypeId, 
			'Controllers' as TypeName,Null,Null,Null,Null,Null,'Dispensers','CONTROLLERSETUP'

UNION

SELECT 
Distinct 
			ControllerId As ID, 
			ControllerNumber as Number,
			Name, 
			0 as ParentID, 
			1 AS TypeId , 
			'Controllers' as TypeName,ControllerTypeId,ControllerModelId,Null,Null,Null,'Dispensers > '+Name,'CONTROLLERSETUP'

FROM ConduitController
WHERE Name IS NOT NULL AND IsDeleted <> 1 AND EcoalabAccountNumber = @EcolabAccountNumber  AND ControllerId !=0

UNION

(
SELECT DISTINCT
	   PC.RowNumber AS Id,
	   PC.RowNumber as Number,
	   	   (CASE WHEN CC.ControllerModelId='11' AND CAST(PC.RowNumber AS INT) BETWEEN 1 AND 12 AND PC.ControllerEquipmentTypeId = 1  THEN 'Group 1 Pump'
			WHEN CC.ControllerModelId='11' AND PC.RowNumber IN ('13','14') AND PC.ControllerEquipmentTypeId <> 1 THEN 'Group 1 ME'
			WHEN CC.ControllerModelId='11' AND CAST(PC.RowNumber AS INT) BETWEEN 15 AND 26 AND PC.ControllerEquipmentTypeId = 1 THEN 'Group 2 Pump'
			WHEN CC.ControllerModelId='11' AND PC.RowNumber IN ('27','28') AND PC.ControllerEquipmentTypeId <> 1 THEN 'Group 2 ME'
			WHEN CC.ControllerModelId IN ('7','8','9','10','14') AND PC.ControllerEquipmentTypeId = 1  THEN 'Pump ' 
			WHEN CC.ControllerModelId IN ('7','8','9','10','14') AND PC.ControllerEquipmentTypeId <> 1  THEN 'ME ' 
			WHEN CC.ControllerModelId NOT IN ('7','8','9','10','14','11') AND PC.ControllerEquipmentTypeId = 1  THEN 'P/V ' ELSE 'ME ' 
			END)
			+ CONVERT(varchar(10),(
									--case when PC.RowNumber<=12 then PC.RowNumber else PC.RowNumber-12 end)) AS Name,	
									case when CC.ControllerModelId='11' AND  PC.RowNumber<=12 then PC.RowNumber 
										 when CC.ControllerModelId='11' AND  PC.RowNumber<=14 then PC.RowNumber-12
										 when CC.ControllerModelId='11' AND  PC.RowNumber<=26 then PC.RowNumber-14
										 when CC.ControllerModelId='11' AND  PC.RowNumber<=28 then PC.RowNumber-26
										 when CC.ControllerModelId='7' AND  PC.RowNumber<=24 then PC.RowNumber
										 when CC.ControllerModelId='7' AND  PC.RowNumber<=28 then PC.RowNumber-24
										 when CC.ControllerModelId='8' AND  PC.RowNumber<=8 then PC.RowNumber
										 when CC.ControllerModelId='8' AND  PC.RowNumber<=10 then PC.RowNumber-8
										 when CC.ControllerModelId IN ('9','10') AND  PC.RowNumber<=8 then PC.RowNumber
										 when CC.ControllerModelId IN ('9','10') AND  PC.RowNumber<=9 then PC.RowNumber-8
										 when CC.ControllerModelId='14' AND  PC.RowNumber<=24 then PC.RowNumber
										 when CC.ControllerModelId='14' AND  PC.RowNumber<=25 then PC.RowNumber-24

									else PC.RowNumber end)) AS Name,	
	   --CASE WHEN  PC.ControllerEquipmentTypeId = 1  THEN 'Pump ' ELSE 'ME 'END + CONVERT(varchar(10),PC.RowNumber) AS Name,	
	   PC.ControllerID AS ParentID,
		1 AS TypeId,
		'Pumps' as TypeName,
		CC.ControllerTypeId,CC.ControllerModelId
		,Null,Null,Null,'Dispensers > '+ CC.Name +' > Pumps >'+
									(CASE WHEN CC.ControllerModelId='11' AND CAST(PC.RowNumber AS INT) BETWEEN 1 AND 12 AND PC.ControllerEquipmentTypeId = 1  THEN 'Group 1 Pump '
										WHEN CC.ControllerModelId='11' AND PC.RowNumber IN ('13','14') AND PC.ControllerEquipmentTypeId <> 1 THEN 'Group 1 ME '
										WHEN CC.ControllerModelId='11' AND CAST(PC.RowNumber AS INT) BETWEEN 15 AND 26 AND PC.ControllerEquipmentTypeId = 1 THEN 'Group 2 Pump '
										WHEN CC.ControllerModelId='11' AND PC.RowNumber IN ('27','28') AND PC.ControllerEquipmentTypeId <> 1 THEN 'Group 2 ME '
										--WHEN CC.ControllerModelId<>'11' AND PC.ControllerEquipmentTypeId = 1  THEN 'Pump ' 
										WHEN CC.ControllerModelId IN ('7','8','9','10','14') AND PC.ControllerEquipmentTypeId = 1  THEN 'Pump ' 
			WHEN CC.ControllerModelId IN ('7','8','9','10','14') AND PC.ControllerEquipmentTypeId <> 1  THEN 'ME ' 
			WHEN CC.ControllerModelId NOT IN ('7','8','9','10','14','11') AND PC.ControllerEquipmentTypeId = 1  THEN 'P/V ' ELSE 'ME '
			END)+ 
			+ CONVERT(varchar(10),(
									--case when PC.RowNumber<=12 then PC.RowNumber else PC.RowNumber-12 end)) AS Name,	
									case when CC.ControllerModelId='11' AND  PC.RowNumber<=12 then PC.RowNumber 
										 when CC.ControllerModelId='11' AND  PC.RowNumber<=14 then PC.RowNumber-12
										 when CC.ControllerModelId='11' AND  PC.RowNumber<=26 then PC.RowNumber-14
										 when CC.ControllerModelId='11' AND  PC.RowNumber<=28 then PC.RowNumber-26
										 when CC.ControllerModelId='7' AND  PC.RowNumber<=24 then PC.RowNumber
										 when CC.ControllerModelId='7' AND  PC.RowNumber<=28 then PC.RowNumber-24
										 when CC.ControllerModelId='8' AND  PC.RowNumber<=8 then PC.RowNumber
										 when CC.ControllerModelId='8' AND  PC.RowNumber<=10 then PC.RowNumber-8
										 when CC.ControllerModelId IN ('9','10') AND  PC.RowNumber<=8 then PC.RowNumber
										 when CC.ControllerModelId IN ('9','10') AND  PC.RowNumber<=9 then PC.RowNumber-8
										 when CC.ControllerModelId='14' AND  PC.RowNumber<=24 then PC.RowNumber
										 when CC.ControllerModelId='14' AND  PC.RowNumber<=25 then PC.RowNumber-24
									else PC.RowNumber end)),'CONTROLLERSETUP' 
	 
	FROM @PumpCount PC 
	JOIN TCD.ConduitController CC	 ON PC.ControllerID	 = CC.ControllerId 
    WHERE CC.Name IS NOT NULL AND CC.IsDeleted <> 1  AND CC.EcoalabAccountNumber = @EcoLabAccountNumber
	
	)
	
-- END OF CONTROLLER ------
UNION

-- WASHER GROUPS--
SELECT		
			0 as ID, 
			Null as Number,
			'Washer Groups' as Name, 
			Null as ParentID,
			2  AS TypeId, 
			'Washer Groups'  as TypeName,Null,Null,Null,Null,Null,'Washer Groups','WASHERGROUPS'

UNION

SELECT
Distinct	
			WG.WasherGroupId AS ID,
			WG.WasherGroupNumber as Number,
			WG.WasherGroupName AS Name,
			0 as ParentId,
			2  AS TypeId, 
			'Washer Groups'  as TypeName,Null,Null,Null,Null,WG.WasherGroupTypeId,'Washer Groups > '+WG.WasherGroupName,'WASHERGROUPS'

FROM	MachineGroup	GT
		INNER JOIN	WasherGroup	WG ON	GT.Id	= WG.WasherGroupId AND wg.ecolabaccountnumber = gt.ecolabaccountnumber
		INNER JOIN	WasherGroupType	WGT ON	WG.WasherGroupTypeId = WGT.WasherGroupTypeId
WHERE GroupTypeId = 2 AND GT.Is_Deleted <> 1 AND GT.EcolabAccountNumber = @EcolabAccountNumber AND WG.EcolabAccountNumber = @EcolabAccountNumber


UNION
---FORMULA ---
SELECT 
Distinct	WP.WasherProgramSetupId  As ID,
			CAST(WP.ProgramNumber AS INT) as Number,
			P.Name AS Name,
			WG.WasherGroupId  as ParentId,
			2  AS TypeId, 
			'Formula'  as TypeName,Null,Null,Null,Null,WG.WasherGroupTypeId,'Washer Groups > '+WG.WasherGroupName +' > Formulas > '+P.Name,'WASHERGROUPS'

FROM			WasherProgramSetup AS WP 
	INNER JOIN  ProgramMaster AS P ON P.ProgramId = WP.ProgramId AND P.EcolabAccountNumber = WP.EcolabAccountNumber
	INNER JOIN	tcd.WasherGroup	WG ON	(CASE WHEN WP.WasherGroupId IS NULL THEN WP.ControllerID ELSE WP.WasherGroupId END) 	
	= (CASE WHEN WP.WasherGroupId IS NULL THEN WG.ControllerID ELSE WG.WasherGroupId END) AND WG.EcolabAccountNumber = Wp.EcolabAccountNumber
	INNER JOIN  tcd.MachineGroup GT  ON GT.Id = WG.WasherGroupId AND GT.EcolabAccountNumber = WP.EcolabAccountNumber
WHERE GroupTypeId = 2 AND WG.WasherGroupTypeId = 1 AND GT.Is_Deleted <> 1 AND WP.Is_Deleted <> 1 AND GT.EcolabAccountNumber = @EcolabAccountNumber AND
		P.EcolabAccountNumber = @EcolabAccountNumber AND WG.EcolabAccountNumber = @EcolabAccountNumber AND WP.EcolabAccountNumber = @EcolabAccountNumber
		 

UNION
---END OF FORMULA--
SELECT 
Distinct	TP.TunnelProgramSetupId  As ID,
			CAST(TP.ProgramNumber AS INT) as Number,
			P.Name AS Name,
			TP.WasherGroupId  as ParentId,
			2  AS TypeId, 
			'Formula'  as TypeName,Null,Null,Null,Null,WG.WasherGroupTypeId,'Washer Groups > '+WG.WasherGroupName +' > Formulas > '+P.Name,'WASHERGROUPS'

FROM			TunnelProgramSetup AS TP 
	INNER JOIN  ProgramMaster AS P ON P.ProgramId = TP.ProgramId AND P.EcolabAccountNumber = TP.EcolabAccountNumber
	INNER JOIN  MachineGroup GT  ON GT.Id = TP.WasherGroupId AND GT.EcolabAccountNumber = TP.EcolabAccountNumber
	INNER JOIN	tcd.WasherGroup	WG ON	TP.WasherGroupId	= WG.WasherGroupId AND TP.EcolabAccountNumber = WG.EcolabAccountNumber
WHERE GT.EcolabAccountNumber = @EcolabAccountNumber AND TP.Is_Deleted <> 1 AND
		P.EcolabAccountNumber = @EcolabAccountNumber AND WG.EcolabAccountNumber = @EcolabAccountNumber AND TP.EcolabAccountNumber = @EcolabAccountNumber



-- WASHERS--

UNION

SELECT		MS.WasherId As ID,
			W.PlantWasherNumber as Number,
			MS.MachineName AS Name,
			WG.WasherGroupId AS ParentId,
			2  AS TypeId, 
			'Washer'  as TypeName,Null,Null,WG.WasherGroupId,MS.IsTunnel AS WasherTypeFlag,WGT.WasherGroupTypeId,'Washer Groups > '+WG.WasherGroupName +' > Washers > '+MS.MachineName,'WASHERGROUPS'
FROM				WasherGroup WG
		INNER JOIN	MachineGroup			GT	ON	WG.WasherGroupId	=	GT.Id  AND	WG.EcolabAccountNumber	=	GT.EcoLabAccountNumber
		INNER JOIN	MachineSetup		MS	ON	WG.WasherGroupId	=	MS.GroupId AND	WG.EcolabAccountNumber	=	MS.EcoaLabAccountNumber
		INNER JOIN	Washer			W	ON	MS.WasherId			=	W.WasherId		AND	MS.EcoalabAccountNumber	=	W.EcoLabAccountNumber
		INNER JOIN	WasherGroupType	WGT ON	WG.WasherGroupTypeId = WGT.WasherGroupTypeId
		INNER JOIN	WasherModelSize	WMS	ON	W.ModelId			=	WMS.WasherModelId
		INNER JOIN	ConduitController	CC	ON	MS.ControllerId		= CC.ControllerId	AND	MS.EcoalabAccountNumber	=	CC.EcoalabAccountNumber
WHERE GT.GroupTypeId	= 2 AND	GT.Is_Deleted <> 1 AND	MS.IsDeleted <> 1 AND MS.EcoalabAccountNumber = @EcolabAccountNumber
AND		WG.EcolabAccountNumber = @EcolabAccountNumber AND GT.EcolabAccountNumber = @EcolabAccountNumber AND W.EcolabAccountNumber = @EcolabAccountNumber AND
		CC.EcoalabAccountNumber = @EcolabAccountNumber

-- END OF WASHERS ------

-- END OF WASHER GROUPS ------

UNION  


-- WASHERS--

SELECT		
			0 as ID, 
			Null as Number,
			'Washers' as Name, 
			Null as ParentID,
			3  AS TypeId, 
			'Washers'  as TypeName,Null,Null,Null,Null,Null,'Washers','WASHER'

UNION

SELECT		MS.WasherId As ID,
			W.PlantWasherNumber as Number,
			MS.MachineName AS Name,
			0 AS ParentId,
			3  AS TypeId, 
			'Washers'  as TypeName,Null,Null,WG.WasherGroupId,MS.IsTunnel AS WasherTypeFlag,WGT.WasherGroupTypeId,'Washers > '+MS.MachineName,'WASHER'

FROM				WasherGroup WG
		INNER JOIN	MachineGroup		GT	ON	WG.WasherGroupId	=	GT.Id  AND	GT.EcolabAccountNumber	=	WG.EcoLabAccountNumber
		INNER JOIN	MachineSetup		MS	ON	WG.WasherGroupId	=	MS.GroupId  AND	WG.EcolabAccountNumber	=	MS.EcoaLabAccountNumber
		INNER JOIN	Washer			W	ON	MS.WasherId			=	W.WasherId		AND	MS.EcoalabAccountNumber	=	W.EcoLabAccountNumber
		INNER JOIN	WasherGroupType	WGT ON	WG.WasherGroupTypeId = WGT.WasherGroupTypeId
		INNER JOIN	WasherModelSize	WMS	ON	W.ModelId			=	WMS.WasherModelId
		INNER JOIN	ConduitController	CC	ON	MS.ControllerId		= CC.ControllerId	AND	MS.EcoalabAccountNumber	=	CC.EcoalabAccountNumber
WHERE GT.GroupTypeId	= 2 AND	GT.Is_Deleted <> 1 AND	MS.IsDeleted <> 1 AND MS.EcoalabAccountNumber = @EcolabAccountNumber
AND		WG.EcolabAccountNumber = @EcolabAccountNumber AND GT.EcolabAccountNumber = @EcolabAccountNumber AND W.EcolabAccountNumber = @EcolabAccountNumber AND
		CC.EcoalabAccountNumber = @EcolabAccountNumber
-- END OF WASHERS ------


UNION

-- TANKS--
SELECT		
			0 as ID, 
			Null as Number,
			'Storage Tanks' as Name, 
			Null as ParentID,
			4  AS TypeId, 
			'Storage Tanks'  as TypeName,Null,Null,Null,Null,Null,'Storage Tanks','STORAGETANKS'

UNION

SELECT		TankId  As ID,
			Null as Number,
			TankName AS Name,
			0 AS ParentId,
			4  AS TypeId, 
			'Storage Tanks'  as TypeName,Null,Null,Null,Null,Null,'Storage Tanks > '+TankName,'STORAGETANKS'

FROM [TCD].TankSetup ts 
		INNER JOIN [TCD].ConduitController cc	ON ts.ControllerId=cc.ControllerId AND cc.EcoalabAccountNumber = ts.EcoalabAccountNumber
		INNER JOIN [TCD].ProductdataMapping pdm ON ts.SKU=pdm.SKU AND pdm.EcolabAccountNumber = ts.EcoalabAccountNumber
		INNER JOIN [TCD].ProductMaster pm on pm.ProductId = pdm.ProductID 
		WHERE ts.ControllerId IS NOT NULL AND ts.ControllerId <> 0 AND ts.Is_Deleted <> 1 AND ts.EcoalabAccountNumber = @EcolabAccountNumber
		AND cc.EcoalabAccountNumber = @EcoLabAccountNumber AND pdm.EcolabAccountNumber = @EcoLabAccountNumber

-- END OF TANKS ------
)

SELECT MC.ID,MC.Number,MC.Name,MC.ParentID,MC.TypeId,MC.TypeName,MC.ControllerTypeId,MC.ControllerModelId,MC.WasherGroupId,MC.WasherTypeFlag,MC.WasherGroupTypeId,MC.Hierarchy
FROM menu_CTE MC
INNER JOIN @Role_Menu RM on RTRIM(RM.SectionCode) = RTRIM(MC.SectionCode)
order by typeId ,Number

SET nocount OFF;
END