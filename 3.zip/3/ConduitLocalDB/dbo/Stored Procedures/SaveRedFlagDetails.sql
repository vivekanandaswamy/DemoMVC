﻿    
CREATE PROCEDURE [TCD].[SaveRedFlagDetails] (    
@Id INT    
,@ItemID int    
,@MinRange Decimal(18,3)    
,@MaxRange Decimal(18,3)    
,@LocationID int    
,@MachineCompartmentId int    
,@EcolabAccountNumber nvarchar(25)    
,@UserID INT = NULL    
,@Scope varchar(100) OUTPUT    
,@OutputRedFlagId INT = NULL OUTPUT    
,@LastModifiedTimestampAtCentral DATETIME = NULL    
,@OutputLastModifiedTimestampAtLocal DATETIME = NULL OUTPUT    
,@CategoryId int    
,@FormulaId int    
,@ProductId int    
,@MeterId int    
,@SensorId int    
)    
AS    
    
BEGIN    
SET NOCOUNT ON    
IF(@ItemID <> 0)    
BEGIN    
DECLARE    
@OutPut       VARCHAR(100) =   ''    
, @ReturnValue     INT    =   0    
,  @NewId int
--, @ErrorId      INT    =   0     --SQLEnlight SA0004    
--, @ErrorMessage     NVARCHAR(4000) =   N''     --SQLEnlight SA0004    
--, @CurrentUTCTime     DATETIME  =   GETUTCDATE()  --SQLEnlight SA0004    
    
DECLARE    
@OutputList      AS TABLE  (    
RedFlagId      INT    
, LastModifiedTimestamp   DATETIME    
)    
  
 DECLARE @PlantId INT;  
     SET @PlantId = (SELECT PlantId FROM TCD.Plant WHERE EcolabAccountNumber=@EcolabAccountNumber)   
  
DECLARE @MachineGroupId INT = (SELECT MG.Id    
FROM TCD.MachineGroupType MGT    
INNER JOIN    
TCD.MachineGroup MG ON MGT.Id = MG.GroupTypeId    
WHERE MGT.Id = 1    
AND MG.Is_Deleted = 0);    
SET  @Scope         =   ISNULL(@Scope, NULL)         --SQLEnlight SA0121    
SET  @LastModifiedTimestampAtCentral   =   ISNULL(@LastModifiedTimestampAtCentral, NULL)   --SQLEnlight SA0121    
    
IF(@MeterId IS NOT NULL AND @SensorId IS NOT NULL AND @LocationID > 1 AND @MachineCompartmentId IS NULL AND NOT EXISTS (SELECT * FROM tcd.MachineGroup MG    
LEFT JOIN TCD.Meter M ON MG.Id = CASE M.IsPlant WHEN 'TRUE' THEN COALESCE(  M.GroupId ,@MachineGroupId) ELSE M.GroupId END    
LEFT JOIN TCD.Sensor S ON MG.Id = CASE S.IsPlant WHEN 'TRUE' THEN COALESCE(  S.GroupId ,@MachineGroupId) ELSE S.GroupId END    
WHERE ((S.SensorId IS NOT NULL    
AND S.Is_deleted = 0    
AND S.MachineCompartment IS NULL)    
OR (M.MeterId IS NOT NULL    
AND M.Is_deleted = 0    
AND M.MachineCompartment IS NULL))    
AND MG.Id = @LocationID))    
BEGIN    
SET @Scope = '301'    
END    
ELSE    
BEGIN    
IF NOT EXISTS (SELECT 1    
FROM   [TCD].RedFlag    
WHERE  Item = @ItemID AND Location = @LocationID AND Is_Deleted=0)    
BEGIN    
INSERT INTO [TCD].RedFlag(Item,MaximumRange,MinimumRange,Location,EcolabAccountNumber,LastModifiedByUserId,RedFlagCategoryId,FormulaId,ProductId,MeterId,SensorId,PlantId)    
OUTPUT    
inserted.ID      AS   Id    
, inserted.LastModifiedTime  AS   LastModifiedTimestamp    
INTO    
@OutputList (    
RedFlagId    
, LastModifiedTimestamp    
)    
VALUES(@ItemID,@MaxRange,@MinRange,@LocationID,@EcolabAccountNumber,@UserID,@CategoryId,@FormulaId,@ProductId,@MeterId,@SensorId,@PlantId)    
    
SET @NewId  = SCOPE_IDENTITY()    
    
INSERT INTO [TCD].RedFlagMappingData(MappingId,MachineId,EcolabAccountNumber,LastModifiedByUserId)    
VALUES(@NewId,@MachineCompartmentId,@EcolabAccountNumber,@UserID)    
    
SET @OutPut = @NewId    
SET @Scope = @OutPut SELECT @Scope    
    
END      
 ELSE IF (@Itemid = 5 ) 
BEGIN   
IF NOT EXISTS (SELECT 1      
FROM   [TCD].RedFlag      
WHERE  @Itemid = 5 AND Location = @LocationID AND Is_Deleted=0 AND FormulaId = @FormulaId)      
BEGIN      
INSERT INTO [TCD].RedFlag(Item,MaximumRange,MinimumRange,Location,EcolabAccountNumber,LastModifiedByUserId,RedFlagCategoryId,FormulaId,ProductId,MeterId,SensorId,PlantId)      
OUTPUT      
inserted.ID      AS   Id      
, inserted.LastModifiedTime  AS   LastModifiedTimestamp      
INTO      
@OutputList (      
RedFlagId      
, LastModifiedTimestamp      
)      
VALUES(@ItemID,@MaxRange,@MinRange,@LocationID,@EcolabAccountNumber,@UserID,@CategoryId,@FormulaId,@ProductId,@MeterId,@SensorId,@PlantId)      
      
set @NewId  = SCOPE_IDENTITY()      
      
INSERT INTO [TCD].RedFlagMappingData(MappingId,MachineId,EcolabAccountNumber,LastModifiedByUserId)      
VALUES(@NewId,@MachineCompartmentId,@EcolabAccountNumber,@UserID)      
      
SET @OutPut = @NewId      
SET @Scope = @OutPut SELECT @Scope      
 END 
 ELSE      
BEGIN      
SET @OutPut = '401'      
SET @Scope = @OutPut SELECT @Scope      
END    
END     
ELSE      
BEGIN     
--DECLARE @Id INT    
--SELECT @Id = ID FROM RedFlag R WHERE R.Location = @LocationID AND Item = @ItemID    
IF(@Id = -1)    
BEGIN    
IF NOT EXISTS(SELECT 1 FROM [TCD].RedFlagMappingData RM INNER JOIN [TCD].RedFlag RF ON RM.MappingId = RF.Id    
WHERE ISNULL(RM.MachineId,'') = ISNULL(@MachineCompartmentId,'') AND RF.Item = @ItemID AND RF.Location = @LocationID AND RF.Is_Deleted = 0 AND RM.Is_Deleted = 0 )    
BEGIN    
INSERT INTO [TCD].RedFlag(Item,MaximumRange,MinimumRange,Location,EcolabAccountNumber,LastModifiedByUserId,RedFlagCategoryId,FormulaId,ProductId,MeterId,SensorId,PlantId)    
OUTPUT    
inserted.ID      AS   Id    
, inserted.LastModifiedTime  AS   LastModifiedTimestamp    
INTO    
@OutputList (    
RedFlagId    
, LastModifiedTimestamp    
)    
VALUES(@ItemID,@MaxRange,@MinRange,@LocationID,@EcolabAccountNumber,@UserID,@CategoryId,@FormulaId,@ProductId,@MeterId,@SensorId,@PlantId)    
    
DECLARE @NewGroupId int = SCOPE_IDENTITY()    
    
INSERT INTO [TCD].RedFlagMappingData(MappingId,MachineId,EcolabAccountNumber,LastModifiedByUserId)    
VALUES(@NewGroupId,@MachineCompartmentId,@EcolabAccountNumber,@UserID)    
SET @OutPut = @NewGroupId    
SET @Scope = @OutPut SELECT @Scope    
END    
ELSE    
BEGIN    
SET @OutPut = '401'    
SET @Scope = @OutPut SELECT @Scope    
END    
    
END    
ELSE    
IF NOT EXISTS(SELECT MachineId FROM [TCD].RedFlagMappingData WHERE MappingId = @Id AND MachineId = @MachineCompartmentId AND Is_Deleted = 0)    
BEGIN    
INSERT INTO [TCD].RedFlagMappingData(MappingId,MachineId,EcolabAccountNumber,LastModifiedByUserId)    
VALUES(@Id,@MachineCompartmentId,@EcolabAccountNumber,@UserID)    
SET @OutPut = @Id    
SET @Scope = @OutPut SELECT @Scope    
END    
ELSE    
BEGIN    
SET @OutPut = '401'    
SET @Scope = @OutPut SELECT @Scope    
END    
END    
END    
SELECT TOP 1    
@OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp    
, @OutputRedFlagId    = O.RedFlagId    
FROM @OutputList O    
END    
    
SET NOCOUNT OFF    
END 