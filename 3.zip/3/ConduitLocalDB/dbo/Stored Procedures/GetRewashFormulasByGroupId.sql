/*  
 ==========================================================================================  
 Purpose:  Fecthing the Rewash Formulas by group id  

 Author:  Neetha Allati

 --------------------------------------------------------------  
 Sep-30-2014 ENT: Initial version.  
 ==========================================================================================  
*/ 
CREATE PROCEDURE [TCD].[GetRewashFormulasByGroupId] 

(

   @WasherGroupId INT,

   @EcolabAccountNumber VARCHAR(100),
   @RecordedDate DateTime 

  )

 AS 

   BEGIN    

   SET NOCOUNT ON  

   DECLARE   @WasherGroupTypeName   VARCHAR(50)   =   NULL,

     @ControllerID   int     =   NULL,

     @ControllerModelID       INT      =  NULL

   --Determine the WasherGroup type - Conventional/Tunnel

  SELECT @WasherGroupTypeName   =   WGT.WasherGroupTypeName

  FROM  [TCD].WasherGroup       WG

  JOIN  [TCD].WasherGroupType   WGT

  ON   WG.WasherGroupTypeId    =   WGT.WasherGroupTypeId

  JOIN  [TCD].MachineGroup      GT

  ON    WG.WasherGroupId        =   GT.Id

  WHERE GT.EcolabAccountNumber  =   @EcoLabAccountNumber

  AND   WG.WasherGroupId    =   @WasherGroupId

  SELECT  @ControllerID   =  wg.ControllerId 

  FROM TCD.WasherGroup   wg

  WHERE   wg.WasherGroupId  =  @WasherGroupId

 AND   wg.EcolabAccountNumber =  @EcoLabAccountNumber

 SELECT  @ControllerModelID  =  cc.ControllerModelId

  FROM TCD.ConduitController cc

  WHERE cc.ControllerId   =  @ControllerID

 AND   cc.EcoalabAccountNumber =  @EcoLabAccountNumber

IF (@ControllerModelID = 7 and @WasherGroupTypeName != 'Tunnel') -- MyControl

    BEGIN

  SET @WasherGroupId = NULL

    END

    IF ( @WasherGroupTypeName = 'Tunnel' )

  BEGIN

	SELECT DISTINCT bd.ProgramMasterId,pm.Name,
	               Convert(bit, CASE WHEN cast(bd.StartDate AS date) = cast(@RecordedDate AS date) THEN 1
	                ELSE 0 END) AS IsVisibleForFormula  

	FROM TCD.BatchData bd 

	INNER JOIN TCD.ProgramMaster pm 

	ON bd.ProgramMasterId=pm.ProgramId

	INNER JOIN TCD.TunnelProgramSetup wps 

	ON pm.ProgramId=wps.ProgramId

	Where pm.EcolabAccountNumber=@EcolabAccountNumber 

	AND wps.WasherGroupId = @WasherGroupId 

	AND bd.GroupId=@WasherGroupId	

	AND wps.Is_Deleted<>1

  END

  ELSE

   BEGIN

	SELECT DISTINCT bd.ProgramMasterId,pm.Name,
					Convert(bit, CASE WHEN cast(bd.StartDate AS date) = cast(@RecordedDate AS date) THEN 1
	                ELSE 0 END) AS IsVisibleForFormula  

	FROM TCD.BatchData bd 

	INNER JOIN TCD.ProgramMaster pm 

	ON bd.ProgramMasterId=pm.ProgramId

	INNER JOIN TCD.WasherProgramSetup wps 

	on pm.ProgramId=wps.ProgramId  

	WHERE (CASE WHEN @WasherGroupId IS NOT NULL 

	THEN wps.WasherGroupId

	ELSE wps.ControllerID

	END)         = (CASE WHEN @WasherGroupId IS NOT NULL 

      THEN @WasherGroupId

      ELSE @ControllerID

      END)

	AND   wps.EcolabAccountNumber = @EcolabAccountNumber

	AND wps.Is_Deleted <> 1

   END

   SET NOCOUNT OFF

   END