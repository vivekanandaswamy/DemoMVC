﻿/*  
 ==========================================================================================  
 Purpose:  Fetching the Values for Chemical Trending data. 
 --------------------------------------------------------------  
 August-01-2014 ENT: Initial version.  
 ==========================================================================================  
 Exec [tcd].[GetChemicalTrendingdata] 22,1,NULL,'2015-04-17 00:30:00','2015-04-17 10:45:00',1,'40242802'    --Tunnel reading
 Exec [TCD].[GetChemicalTrendingdata] 7,NULL,1,'2015-04-17 00:30:00','2015-04-17 10:45:00',1,'40242802'

*/ 
CREATE PROCEDURE [TCD].[GetChemicalTrendingData](
									   @WasherId int = NULL,
									   @CompId int = NULL,
									   @ChemicalCount int = NULL,
									   @Starttime Datetime = NULL,
									   @Endtime datetime = NULL,
									   @UserId INT = NULL,
									   @EcolabAccountNumber NVarchar(25) = NULL
								 )
AS 
  BEGIN 
	  SET NOCOUNT ON; 
	  DECLARE @ISTunnel Int = NULL,
			@LanguageID INT = NULL,
			@loclizeFormulaName NVARCHAR(100) = NULL,
			@loclizeWeight NVARCHAR(100) = NULL,
			@localizeTransferSignal NVARCHAR(100) = NULL

	   /* Localizing the parameters other than chemicals injected*/

	  SELECT @LanguageID = UM.LanguageId FROM TCD.UserMaster UM WHERE UM.UserId = @UserId
	   IF(@LanguageID IS NULL) 
		  BEGIN
		   SELECT @LanguageID = UM.LanguageId FROM TCD.Plant UM WHERE UM.EcolabAccountNumber = @EcolabAccountNumber
		  END

	  SELECT @loclizeFormulaName = RKV.Value  FROM TCD.ResourceKeyValue RKV INNER JOIN TCD.ResourceKeyMaster RKM ON RKV.KeyName = RKM.KeyName WHERE RKM.KeyName = 'FIELD_FORMULA_NAME' AND languageID = @LanguageID
	  SELECT @loclizeWeight = RKV.Value  FROM TCD.ResourceKeyValue RKV INNER JOIN TCD.ResourceKeyMaster RKM ON RKV.KeyName = RKM.KeyName WHERE RKM.KeyName = 'WEIGHT' AND languageID = @LanguageID
	  SELECT @localizeTransferSignal = RKV.Value  FROM TCD.ResourceKeyValue RKV INNER JOIN TCD.ResourceKeyMaster RKM ON RKV.KeyName = RKM.KeyName WHERE RKM.KeyName = 'FIELD_TRANSFER_SIGNAL' AND languageID = @LanguageID
			
	  SELECT @ISTunnel = Istunnel from [TCD].Machinesetup where WasherId = @WasherId
	  

	CREATE TABLE #Trendingdata
					 (
					   GroupId Int,
					   CompartmentID Int,
					   Actual Decimal(18,4),
					   Id INT,
					   ParameterName Varchar(1000),
					   [TimeStamp] DateTime,				
					   Desired Int
					  )

	/* Creating the temp table for products that has been identified for conventional and Tunnel in that perticular duration*/

	DECLARE @WasherParameters TABLE (RowId INT IDENTITY(1,1),ProductId Int)
	 DECLARE @TunnelParameters TABLE (RowId INT IDENTITY(1,1),ProductId Int)

	INSERT INTO @WasherParameters(ProductId)
		 SELECT 
		DISTINCT
		PM.ProductId AS Id
	FROM  
		TCD.BatchData BD 
		INNER JOIN TCD.BatchProductData BPD ON BD.BatchId = BPD.BatchId
		LEFT JOIN TCD.ProductMaster PM ON PM.ProductId = BPD.ProductId
	WHERE  BD.MachineId = @WasherId AND BPD.TimeStamp BETWEEN @Starttime and @Endtime	 
		
	INSERT INTO @TunnelParameters(ProductId)	 
	 SELECT 
	   DISTINCT
				  PM.ProductId
		  FROM  
		TCD.BatchData BD 
		INNER JOIN TCD.BatchProductData BPD ON BD.BatchId = BPD.BatchId
		LEFT JOIN TCD.ProductMaster PM ON PM.ProductId = BPD.ProductId
	WHERE  BD.MachineId = @WasherId AND BPD.StepCompartment=@CompId	AND BPD.TimeStamp BETWEEN @Starttime and @Endtime 
	/*
		  FROM 
	   TCD.BatchData BD 
	   INNER JOIN TCD.BatchProductData Bdp ON Bdp.BatchId=BD.BatchId	  
	   INNER JOIN TCD.TunnelDosingProductMapping TDP ON BD.GroupId = TDP.GroupId AND Bdp.StepCompartment = TDP.CompartmentNumber
	   INNER JOIN TCD.ControllerEquipmentSetup Ces ON Ces.ControllerEquipmentSetupId=TDP.ControllerEquipmentSetupId
	   INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Ces.ProductId	  
	   WHERE  BD.MachineId = @WasherId AND Bdp.[TimeStamp] >= @Starttime AND Bdp.[TimeStamp] <= @Endtime  and Bdp.StepCompartment=@CompId
	  
	*/

	  DECLARE @FormulaName Int = 100001,
			@Weight Int = 100002,
			@TransferSignal Int = 100003
		  
	IF(@ISTunnel = 1)
	BEGIN
				INSERT INTO #Trendingdata
							  (
								GroupId,
								CompartmentID,
								Actual,
								Id ,
								ParameterName,
								[TimeStamp] ,				
								Desired 
								)
	   
					SELECT 
					DISTINCT 
					BD.GroupId,
					Bdp.StepCompartment,
					Bdp.ActualQuantity,
					PM.ProductId AS Id,
					PM.Name AS Name,
					Bdp.TimeStamp,
					Bdp.StandardQuantity
						   FROM 
						TCD.BatchData BD 	   
					INNER JOIN TCD.BatchProductData Bdp ON Bdp.BatchId=BD.BatchId				  
					INNER JOIN TCD.ProductMaster PM ON  PM.ProductId = Bdp.ProductId
					WHERE  BD.MachineId = @WasherId AND Bdp.TimeStamp >= @Starttime AND Bdp.TimeStamp <= @Endtime AND
						  PM.ProductId in (Select ProductId from @TunnelParameters WHERE RowId < 7) AND Bdp.StepCompartment = @CompId
					
	   END
	   ELSE
	   BEGIN
			 INSERT INTO #Trendingdata
							  (
								GroupId,
								CompartmentID,
								Actual,
								Id ,
								ParameterName,
								[TimeStamp] ,				
								Desired 
								)
			 SELECT 
					DISTINCT
					BD.GroupId,
					BD.MachineInternalId,
					BPD.ActualQuantity,
					PM.ProductId AS Id,
					PM.Name AS Name,
					BPD.TimeStamp,
					BPD.StandardQuantity
						FROM   
					TCD.BatchData BD 
					INNER JOIN TCD.BatchProductData BPD ON BD.BatchId = BPD.BatchId
					INNER JOIN TCD.ProductMaster PM ON PM.ProductId = BPD.ProductId
					 
			  WHERE
				CASE @ChemicalCount 
				WHEN 1 THEN CASE WHEN PM.ProductId in (Select ProductId from @WasherParameters WHERE RowId < 9)  then 'true' end
				WHEN 2 THEN CASE WHEN PM.ProductId in (Select ProductId from @WasherParameters WHERE RowId > 9)  then 'true' end
				END = 'true'
				AND  BD.MachineId = @WasherId AND BPD.TimeStamp BETWEEN @Starttime and @Endtime 
	   END

		  INSERT INTO #Trendingdata
							  (
								GroupId,
								CompartmentID,
								Actual,
								Id ,
								ParameterName,
								[TimeStamp] ,				
								Desired 
								)
		  SELECT DISTINCT MS.GroupId,
		  MS.MachineInternalId,
		  BD.ProgramNumber,
		  @FormulaName AS Id,
		  @loclizeFormulaName AS NAME,
		  BD.StartDate,
		 0
		   FROM 
		   [TCD].BatchData BD 
		   LEFT OUTER JOIN 
		   TCD.MachineSetup MS ON BD.MachineId = MS.WasherId
		   WHERE
		  CAST(bd.StartDate AS datetime) >= @Starttime and CAST(bd.EndDate AS datetime) <= @Endtime and BD.MachineId = @WasherId

		  UNION ALL

		  SELECT DISTINCT MS.GroupId,
		  MS.MachineInternalId,
		  BD.ActualWeight,
		  @Weight AS Id,
		  @loclizeWeight AS NAME,
		  BD.StartDate,
		  BD.StandardWeight
		   FROM 
		   [TCD].BatchData BD 
		   LEFT OUTER JOIN 
		   TCD.MachineSetup MS ON BD.MachineId = MS.WasherId
			WHERE
		  CAST(bd.StartDate AS datetime) >= @Starttime and CAST(bd.EndDate AS datetime) <= @Endtime and BD.MachineId = @WasherId

		  UNION ALL
  
		  SELECT DISTINCT MS.GroupId,
		 MS.MachineInternalId,
		Wr.ParameterValue,
		 @TransferSignal AS Id,
		 @localizeTransferSignal AS Name,
		 BD.StartDate,
		Wr.ParameterValue
		  FROM 
		  [TCD].BatchData BD 
		  LEFT OUTER JOIN 
		  TCD.MachineSetup MS ON BD.MachineId = MS.WasherId
		  INNER JOIN Tcd.WasherReading Wr ON wr.WasherId=Bd.MachineId
		  WHERE
		  CAST(bd.StartDate AS datetime) >= @Starttime and CAST(bd.EndDate AS datetime) <= @Endtime and 
		BD.MachineId = @WasherId AND WR.ParameterId IN (SELECT ID FROM TCD.ConduitParameters cp WHERE cp.Id = 6)

		  SELECT 
				DISTINCT
				TD.Id,
				TD.GroupId,
				TD.CompartmentID,
				 CAST(TD.[TimeStamp] AS datetime) AS [TimeStamp],
				TD.ParameterName,
				 CAST(ISNULL(TD.Actual,0) AS REAL) AS Actual,
				CAST(ISNULL(TD.Desired,0) AS REAL) AS Desired  INTO #DistinctData 
					FROM #Trendingdata TD
		   ORDER BY TD.ID,TD.TimeStamp

			SELECT 
				
				TD.GroupId,
				TD.CompartmentID,
				TD.[TimeStamp],
				TD.ParameterName,
				TD.Actual,
				TD.Desired FROM  #DistinctData TD

		  DROP TABLE #Trendingdata
		  DROP TABLE #DistinctData
SET NOCOUNT OFF;
END