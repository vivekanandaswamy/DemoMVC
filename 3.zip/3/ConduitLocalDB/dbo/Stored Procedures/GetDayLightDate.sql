CREATE PROCEDURE [TCD].[GetDayLightDate]
(
    @Date datetime OUTPUT
)
AS
BEGIN
    DECLARE @Curentdate datetime = GETDATE()
,            @DayLightStartDateForCurrentYear datetime = GETDATE()
,            @DayLightEnddateForCurrentYear  datetime
,            @DayLightStartDate datetime = @Date
,            @DayLightEndDate datetime 

    -- Calculating the DayLight time period of Current year
    EXEC TCD.GetDaylightSavingDates @DayLightStartDateForCurrentYear OUT, @DayLightEnddateForCurrentYear OUT
    EXEC TCD.GetDaylightSavingDates @DayLightStartDate OUT, @DayLightEnddate OUT
        
    IF @Curentdate >= @DayLightStartDateForCurrentYear AND @Curentdate <= @DayLightEnddateForCurrentYear
        BEGIN
            -- Daylight saving time
            IF @Date <= @DayLightStartDate OR @Date >= @DayLightEnddate
                BEGIN
                    SET @Date = DATEADD(hour, 1, @Date)
                END
        END
    ELSE
        BEGIN
            -- Without daylight
            IF @Date >= @DayLightStartDate AND @Date <= @DayLightEnddate
                BEGIN
                    SET @Date = DATEADD(hour, -1, @Date)
                END
        END
END
