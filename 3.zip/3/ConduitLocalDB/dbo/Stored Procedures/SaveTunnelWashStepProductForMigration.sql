﻿/*

Stored Procedure	:	[TCD].[SaveTunnelWashStepProductForMigration]

Purpose				:	To Update Washer group formula wash step from my service

Parameters			:	@EcoLabAccountNumber			
						@WasherGroupId					
						@ProgramNumber					
						@UserId							
						@MyServiceCustFrmulaMchGrpGUID	
						@IsDelete						
						@MyServiceStepTypeId			
						@MyServiceWaterTypeId			
						@MyServiceDrainTypeId			
						@StepNumber						
						@StepRunTime					
						@Temperature					
						@WaterLevel						
						@pHLevel						
						@Note							
						@MyServiceCustFrmulaStpGUID		
*/

CREATE PROCEDURE [TCD].[SaveTunnelWashStepProductForMigration]
					@EcoLabAccountNumber					NVARCHAR(25)
				,	@MyServiceFrmulaStpDsgDvcGUID			UNIQUEIDENTIFIER
				,	@Quantity								DECIMAL(18,3)
				,	@MyServiceCmpmtDsgDvcguid				UNIQUEIDENTIFIER
				,	@MyServiceCusrFrmulaStpGuid				UNIQUEIDENTIFIER
				,	@CompartmentNumber						INT
				,	@DelayTime								INT = NULL
				,	@ControllerEquipmentSetupId				INT = NULL

AS
BEGIN

SET	NOCOUNT	ON

DECLARE	@ErrorId						INT					=			0
,		@CurrentUtc						DATETIME			=			GETUTCDATE()
,		@TunnelDosingSetupId			INT					=			NULL
,		@WasherGroupId					INT					=			NULL
,		@UserId							INT					=			0


SELECT @TunnelDosingSetupId = TunnelDosingSetupId
	 , @WasherGroupId		 = GroupId		
FROM TCD.TunnelDosingSetup WHERE EcolabAccountNumber = @EcoLabAccountNumber AND MyServiceCustFrmulaStpGUID = @MyServiceCusrFrmulaStpGuid

IF @MyServiceCmpmtDsgDvcguid IS NOT NULL
BEGIN
SELECT @ControllerEquipmentSetupId = ControllerEquipmentSetupId FROM TCD.TunnelCompartmentEquipmentMapping WHERE MyServiceCmpmtDsgDvcguid = @MyServiceCmpmtDsgDvcguid AND EcoLabAccountNumber = @EcoLabAccountNumber
END

IF @ControllerEquipmentSetupId = 0 OR @ControllerEquipmentSetupId IS NULL
	RETURN

IF NOT EXISTS (SELECT 1 FROM [TCD].[TunnelDosingProductMapping] WHERE EcolabAccountNumber = @EcoLabAccountNumber AND MyServiceFrmulaStpDsgDvcGuid = @MyServiceFrmulaStpDsgDvcGUID)
	BEGIN
			INSERT INTO [TCD].[TunnelDosingProductMapping]
					   ([EcoLabAccountNumber]
					   ,[TunnelDosingSetupId]
					   ,[GroupId]
					   ,[CompartmentNumber]
					   ,[ControllerEquipmentSetupId]
					   ,[Quantity]
					   ,[LastModifiedByUserId]
					   ,[LastModifiedTime]
					   ,[MyServiceFrmulaStpDsgDvcGuid]
					   ,[MyServiceLastSynchTime]
					   ,[DelayTime]
						)
			VALUES
						(@EcoLabAccountNumber
						,@TunnelDosingSetupId
						,@WasherGroupId
						,@CompartmentNumber
						,@ControllerEquipmentSetupId
						,@Quantity
						,@UserId
						,@CurrentUtc
						,@MyServiceFrmulaStpDsgDvcGUID
						,@CurrentUtc
						,@DelayTime
						)
		
			--check for any error
			SET	@ErrorId	=	@@ERROR
	END

SELECT @ErrorId

END