﻿/*    
 ==========================================================================================    
 Purpose:  Fetching list of DryerGroups.    
  
 Author:  Phani    
  
 --------------------------------------------------------------    
 August-18-2014 ENT: Initial version.    
 ==========================================================================================    
*/ 
CREATE PROCEDURE [TCD].[GetDryerGroups]
@PageNo int,
@RecordsPerPage int
--Adding EcolabAccountNumber also, since it was missing... and we will need it in Central Configurator DB
--,	@EcolabAccountNumber				NVARCHAR(1000)	--Commenting this for now until we know it is used; lest can break some dependent code
AS     
  BEGIN     
      SET nocount ON;     
--Re-writing below in 2008 syntax, since we are not supposed to use 2012 features...
--     SELECT     
--     GT.GroupTypeId    
--   , GT.GroupDescription
--, COUNT(GroupTypeId) OVER() as TotalCount
--    FROM [TCD].GroupType gt
--	WHERE gt.GroupMaintype = 'DryerGroup'
--Order By GroupTypeId Desc
--OFFSET (@PageNo-1)*@RecordsPerPage ROWS
--FETCH NEXT @RecordsPerPage ROWS ONLY

WITH	QSetCTE
AS	(
	SELECT
			GT.Id			AS			GroupId
		,	GT.GroupDescription		AS		GroupDescription
		,	ROW_NUMBER()	OVER	(ORDER BY	Id Desc)
									AS			RowNumber
		,	COUNT(Id) OVER()
									AS			TotalCount
		--,	GT.LastModifiedTime		AS			LastModifiedTime	--Commenting this for now until we know it is used; lest can break some dependent code
	FROM	[TCD].MachineGroup			GT
	WHERE	GT.GroupTypeId		=			3
	--also, adding Is_Deleted condition
		AND	GT.Is_Deleted			=			'FALSE'
	)
SELECT
		CTE.GroupId				AS			GroupId
	,	CTE.GroupDescription		AS			GroupDescription
	,	CTE.TotalCount				AS			TotalCount
	--,	CTE.LastModifiedTime		AS			LastModifiedTime
FROM	QSetCTE						CTE
WHERE	RowNumber					BETWEEN		(		(@PageNo - 1) * @RecordsPerpage		)	+	1
										AND		@PageNo * @RecordsPerpage


  END