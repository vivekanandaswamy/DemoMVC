﻿/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_GetWasherDosingProductMapping]                                           

Purpose:				To get the washer doing product mapping details.

Parameters:				@EcoLabAccountNumber - holds the ecolab account number.
						@WasherDosingSetupId - holds the washer dosing setup id.
																
###################################################################################################                                           
*/
CREATE	PROCEDURE	[TCD].[GetWasherDosingProductMapping]	(
                @EcoLabAccountNumber					NVARCHAR(25)
              ,	@WasherDosingSetupId					INT
			  ,	@Is_Deleted								BIT			=		'FALSE'
)
AS
BEGIN

SET	NOCOUNT	ON

SELECT		WDPM.WasherDosingProductMappingId		AS			WasherDosingProductMappingId
		,	WDPM.WasherDosingSetupId				AS			WasherDosingSetupId		
        ,	WDPM.InjectionNumber					AS			InjectionNUmber
        ,	WDPM.ProductId							AS			ProductId
        ,	ISNULL(NULLIF(PM.EnvisionDisplayName, ' '),PM.Name) 	AS ProductName
        ,	WDPM.Quantity							AS			Quantity
        ,	WDPM.MyServiceFrmulaStpDsgDvcGuid		AS			MyServiceFrmulaStpDsgDvcGuid
		,	WDPM.MyServiceLastSynchTime				AS			MyServiceLastSynchTime
		,	WDPM.IsDeleted							AS			IsDeleted
		,	WDPM.[Delay]							AS			[Delay]
		,	WDPM.ControllerEquipmentSetupId			AS			ControllerEquipmentSetupId
		,	CASE ces.ControllerEquipmentTypeId WHEN 2 THEN 
											   CASE cc.ControllerModelId WHEN 7 THEN 
											   CAST(ces.ControllerEquipmentId-24 AS tinyint) ELSE ces.ControllerEquipmentId END 
											   ELSE ces.ControllerEquipmentId END
FROM [TCD].WasherDosingProductMapping               WDPM  
JOIN [TCD].ProductMaster                          PM  
ON       WDPM.ProductId      =   PM.ProductId  
LEFT JOIN TCD.ControllerEquipmentSetup ces 
ON ces.ControllerEquipmentSetupId = WDPM.ControllerEquipmentSetupId AND ces.EcoLabAccountNumber = WDPM.EcoLabAccountNumber AND ces.ProductId = PM.ProductId
LEFT JOIN TCD.ConduitController cc ON cc.EcoalabAccountNumber = ces.EcoLabAccountNumber AND cc.ControllerId = ces.ControllerId
WHERE   (WDPM.IsDeleted      =   'False' OR WDPM.IsDeleted = @Is_Deleted)  
AND       WDPM.EcoLabAccountNumber   =   @EcoLabAccountNumber  
AND       WDPM.WasherDosingSetupId   =   @WasherDosingSetupId 
SET	NOCOUNT	OFF

END