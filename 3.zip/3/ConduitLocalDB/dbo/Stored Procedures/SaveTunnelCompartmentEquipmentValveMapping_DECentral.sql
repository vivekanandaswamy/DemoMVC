﻿CREATE PROC [TCD].[SaveTunnelCompartmentEquipmentValveMapping_DECentral] (    
	  @WasherCompartmentMappings TCD.TunnelCompartmentEquipmentValveMapping READONLY    
    , @ControllerEquipmentId INT    
    , @ControllerId INT      
    , @EcolabAccountNumber NVARCHAR(25)    
    , @UserId INT    
)    
AS    
BEGIN    
    DECLARE    
     @EquipmentSetupId INT = (SELECT TOP 1 CES.ControllerEquipmentSetupId    
        FROM TCD.ControllerEquipmentSetup CES    
        WHERE CES.ControllerId = @ControllerId    
          AND CES.ControllerEquipmentId = @ControllerEquipmentId ),    

	@EquipmentTypeId INT = (SELECT TOP 1 CES.ControllerEquipmentTypeId    
        FROM TCD.ControllerEquipmentSetup CES    
        WHERE CES.ControllerId = @ControllerId    
          AND CES.ControllerEquipmentId = @ControllerEquipmentId ),    


     @PlantId INT = (SELECT TOP 1 PlantId    
  FROM TCD.Plant P    
       WHERE P.EcolabAccountNumber = @EcolabAccountNumber);  
    
    DECLARE    
     @TempMapping TABLE(    
     RowNumber INT NOT NULL    
   , ControllerEquipmentId TINYINT NOT NULL    
   , TunnelNumber INT NOT NULL    
   , CompartmentNumber TINYINT NOT NULL    
   , DosingPointNumber TINYINT NOT NULL    
   , DirectDosingFlag BIT NOT NULL  
   , ValveNumber TINYINT NOT NULL
   , WasherNumber int NOT NULL);    
    
    /* Create RowNumber inorder to increment and use row by row. */    
    
    WITH CTE_LCM    
    AS (    
    SELECT ROW_NUMBER() OVER (ORDER BY LCM.TunnelNumber, LCM.DosingPointNumber) AS RowNumber    
     , LCM.ControllerEquipmentId  
     , LCM.TunnelNumber  
     , LCM.CompartmentNumber  
     , LCM.DosingPointNumber  
     , LCM.DirectDosingFlag  
     , LCM.ValveNumber  
	 , LCM.WasherNumber
  FROM @WasherCompartmentMappings LCM    
    )    
    INSERT INTO @TempMapping    
    SELECT *    
  FROM CTE_LCM CL;    
    
    /* Loop */    
    
    DECLARE    
     @i INT = 1,    
     @max INT = (SELECT MAX(TM.RowNumber)    
       FROM @TempMapping TM);    
    WHILE @i <= @max    
    BEGIN    
    
    /* Declare and Initialize the current row data */    
    
    DECLARE    
     @TunnelNumber INT,   
	 @CompartmentNumber tinyint, 
     @DosingPointNumber TINYINT,  
     @WasherNumber INT;  
    SELECT TOP 1 @TunnelNumber = TM.TunnelNumber   
		, @CompartmentNumber = TM.CompartmentNumber 
       , @DosingPointNumber = TM.DosingPointNumber    
       , @WasherNumber       = TM.WasherNumber  
      FROM @TempMapping TM    
      WHERE TM.RowNumber = @i;   

    /* Update If Exists else Insert */    
    IF(@EquipmentTypeId = 1)
	BEGIN
	 MERGE TCD.TunnelCompartmentEquipmentValveMapping T    
    USING (SELECT TOP 1 *    
     FROM @TempMapping TM    
     WHERE TM.RowNumber = @i) S    
    ON T.ControllerEquipmentSetupID = @EquipmentSetupId  
    WHEN MATCHED    
      THEN    
      UPDATE SET             
        T.CompartmentNumber = S.CompartmentNumber  
       , T.DosingPointNumber = S.DosingPointNumber
	   , T.TunnelNumber = S.TunnelNumber
	   , T.WasherExtractorNumber = S.WasherNumber
          
    WHEN NOT MATCHED    
      THEN    
      INSERT (PlantID    
        , ControllerEquipmentSetupID    
        , TunnelNumber  
		, WasherExtractorNumber  
        , DosingPointNumber    
        , ValveNumber    
        , CompartmentNumber    
        , DirectDosingFlag    
        , LastModifiedByUserID)    
      VALUES (@PlantId,    
      @EquipmentSetupId,    
      S.TunnelNumber,  
	  S.WasherNumber,  
      S.DosingPointNumber,    
      S.ValveNumber,    
      S.CompartmentNumber,    
      S.DirectDosingFlag,    
      @UserId); 
	END
	ELSE

	BEGIN
	 MERGE TCD.TunnelCompartmentEquipmentValveMapping T    
    USING (SELECT TOP 1 *    
     FROM @TempMapping TM    
     WHERE TM.RowNumber = @i) S    
    ON T.ControllerEquipmentSetupID = @EquipmentSetupId  
	AND T.DosingPointNumber = @DosingPointNumber
    WHEN MATCHED    
      THEN    
      UPDATE SET             
        T.CompartmentNumber = S.CompartmentNumber  
       , T.DosingPointNumber = S.DosingPointNumber
	   , T.TunnelNumber = S.TunnelNumber
	   , T.WasherExtractorNumber = S.WasherNumber
          
    WHEN NOT MATCHED    
      THEN    
      INSERT (PlantID    
        , ControllerEquipmentSetupID    
        , TunnelNumber  
		, WasherExtractorNumber  
        , DosingPointNumber    
        , ValveNumber    
        , CompartmentNumber    
        , DirectDosingFlag    
        , LastModifiedByUserID)    
      VALUES (@PlantId,    
      @EquipmentSetupId,    
      S.TunnelNumber,  
	  S.WasherNumber,  
      S.DosingPointNumber,    
      S.ValveNumber,    
      S.CompartmentNumber,    
      S.DirectDosingFlag,    
      @UserId); 
	END
	
      
    
    /* Increment the row */    
    
    SET @i = @i + 1;    
    END;    
END;