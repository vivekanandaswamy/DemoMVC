﻿  
/*     
 ==========================================================================================    
 Purpose:  ADUITING THE INSERT DATA    
  
 Author:  Premchand Yelavarthi     
  
 --------------------------------------------------------------     
 Sep-05-2014 ENT: Initial version.     
 ==========================================================================================    
*/  
CREATE PROCEDURE [TCD].[AuditingInsertDetails] 
--(@Max_ID Nvarchar(100),@table_Name  Nvarchar(100),@UserID int							--SQLEnlight	SA0029
--)																						--Commented-out, since this is a deprecated SP - NOT to be used
As
SET NOCOUNT ON 
BEGIN

		     DECLARE @Column_name NVARCHAR(1000)   /*
            DECLARE cursor_sample CURSOR FOR   
              SELECT name   
              FROM   sys.all_columns   
              WHERE  Object_name(object_id) = @table_Name   
                     AND name NOT IN ( 'Is_Deleted','ID','GUID' )   
              ORDER  BY name   
  
		  OPEN cursor_sample   
  
            FETCH next FROM cursor_sample INTO @Column_name   
  
            WHILE @@fetch_status = 0   
              BEGIN   
                  DECLARE @ColumnValue NVARCHAR(1000)   
                  DECLARE @sqlCommand NVARCHAR(1000)   
                  DECLARE @ParmDefinition NVARCHAR(500)   
  
                  SET @sqlCommand = 'SELECT @ColumnValue = [' + @Column_Name   
                                    + '] from ' +  @table_Name + ' where ID = ' + @Max_ID   
                                    + ' and is_deleted = 0'   
                  SET @ParmDefinition = N'@ColumnValue NVarchar(1000) OUTPUT';   
  
                  EXEC Sp_executesql   
                    @sqlCommand,   
                    @ParmDefinition,   
                    @ColumnValue output;   
  
                  --SELECT @Column_Name,@ColumnValue   
                  IF( @ColumnValue IS NOT NULL   
                       OR @ColumnValue IS NULL )   
                    BEGIN   
                        BEGIN   
                            DECLARE @Audit_ID8 INT   
  
                            IF NOT EXISTS (SELECT *   
                                           FROM   [TCD].auditcolumns   
                                           WHERE  columnname = @Column_Name   
                                                  AND tablename = @Table_name)   
                              BEGIN   
                                  INSERT INTO [TCD].auditcolumns   
                                  VALUES     (@Column_Name,   
                                              @Table_name)   
  
                                  SELECT @Audit_ID8 = id   
                                  FROM   [TCD].auditcolumns   
                                  WHERE  columnname = @Column_Name   
                                         AND tablename = @Table_name   
  
                                  INSERT INTO [TCD].auditcolumnsdetails_New   
                                  SELECT @Max_ID,@Audit_ID8,   
                                         NULL,   
                                         @ColumnValue,   
                                         @UserID,   
                                         Getdate()   
                              END   
                            ELSE   
                              BEGIN   
                                  SELECT @Audit_ID8 = id   
                                  FROM   [TCD].auditcolumns   
                                  WHERE  columnname = @Column_name   
                                         AND tablename = @Table_name   
  
                                  INSERT INTO [TCD].auditcolumnsdetails_New  
                                  SELECT @Max_ID,@Audit_ID8,   
                                         NULL,   
                                         @ColumnValue,   
                                         @UserID,   
                                         Getdate()   
                              END   
                        END   
                    END   
  
                  FETCH next FROM cursor_sample INTO @Column_name   
              END   
  
            CLOSE cursor_sample   
  
            DEALLOCATE cursor_sample  */
		  END