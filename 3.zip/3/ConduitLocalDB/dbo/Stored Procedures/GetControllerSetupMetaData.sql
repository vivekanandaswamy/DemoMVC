﻿CREATE PROCEDURE [TCD].[GetControllerSetupMetaData]
(
	@TabId INT
	,@ControllerModelId INT
	,@ControllerTypeId INT
	,@RoleId INT
 )
AS
BEGIN     
SET NOCOUNT ON
	SELECT DISTINCT 
		'' AS ControllerName
		,FG.Id AS FieldGroupId
		,FG.[NAME] AS FieldGroupName
		,FG.[image_Url] as FieldGroupImageUrl
		,FG.[helpText] as FieldGroupHelpText
		,FG.[ControllerModelId]
		,FG.[ControllerTypeId]
		,FGT.NAME AS FieldGroupTypeName
		,F.Id AS FieldId
		,F.Name AS FieldName
		,FT.Name AS FieldType
		,F.Label AS FieldLabel
		,F.[Min] AS FieldMinValue
		,F.[Max] AS FieldMaxValue
		,F.IsMandatory AS FieldIsMandatory
		,F.IsEditable AS FieldIsEditable
		,F.HelpText AS FieldHelpText
		, F.HelpTextUrl AS FieldHelpUrl
		,FG.TabId AS TabIndex
		,DT.Name AS ControlType
		,F.DataSourceId AS DataSourceId
		,(Select FS.Value + ':' + FS.Name + ';' FROM [TCD].FieldSource FS where FS.DataSourceId = F.DataSourceId for xml path('')) as DataSourceKeyValue
		,F.DataCategoryId AS DataCategoryId
		,CASE F.Name
			WHEN 'InstallDate' THEN CONVERT(VARCHAR(10), CONVERT(DATETIME, GETDATE(),   1), 101)
			ELSE F.DefaultValue
		END As FieldDefaultValue
		,F.CurrencyId AS FieldCurrencyCode
		,F.ResourceKey AS FieldResourceKey
		,FG.ResourceKey AS FieldGroupResourceKey
		,FG.DisplayOrder AS FieldGroupDO
		,F.DisplayOrder AS FieldDO
		,FRM.RoleId AS AccessToRole
		,'Add' AS Mode
		,F.HasFieldTag AS HasFieldTag
		,F.DefaultFieldTag AS TagDefaultValue
		,F.ClassName AS Classname
		,'' AS ControllerVersion
		,CAST (0 as bit) IsDosingLineConsumed
	 FROM [TCD].[FieldGroup] FG
		INNER JOIN [TCD].[FieldGroupFieldMapping] FGFM ON FG.Id = FGFM.FieldGroupId
		INNER JOIN [TCD].[Field] F ON F.Id = FGFM.FieldId
		LEFT JOIN [TCD].[FieldGroupType] FGT ON FGT.Id = FG.FieldGroupTypeId
		LEFT JOIN [TCD].FieldType FT ON FT.Id = F.TypeId 
		LEFT JOIN [TCD].DataType DT ON DT.Id = F.DataTypeId
		LEFT JOIN [TCD].[FieldRoleMapping] FRM ON FRM.FieldId = F.Id AND FRM.RoleId=@RoleId
	WHERE  
	FG.TabId = @TabId 
	AND 
	FG.[ControllerModelId] = @ControllerModelId
	AND
	FG.[ControllerTypeId] = @ControllerTypeId 
	ORDER BY FG.DisplayOrder , F.DisplayOrder, F.Id   
SET NOCOUNT OFF
END