﻿/*	                                   
###################################################################################################                                           

Stored Procedure:       [TCD].[GetPlantInfo]                                         

Purpose:				To get the plant ETech info.
*/

CREATE PROCEDURE [TCD].[GetPlantInfo]
AS

BEGIN

SET nocount ON;

SELECT 
p.EcolabAccountNumber,
p.Name,
p.IsETechEnable,
p.ETechIpAddress,
p.ETechTimeDiff,
p.ETechCustomerCodesText
FROM   [TCD].plant P WHERE   Is_Deleted      = 0

SET nocount OFF;
END