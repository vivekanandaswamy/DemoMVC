CREATE PROCEDURE [TCD].[GetReportDataByFilterId]

(

@UserId INT = NULL

, @RoleId INT = NULL

, @IsLocal BIT = NULL

, @MachineTye NVARCHAR(1000) = NULL

, @Machinegroup NVARCHAR(1000) = NULL

, @ReportId INT = NULL

, @FilterId INT = NULL

)

AS

SET NOCOUNT ON;

BEGIN

    DECLARE

     @LanguageId INT = (SELECT UM.LanguageId

      FROM TCD.UserMaster UM

      WHERE UserId = @UserId );

    DECLARE

     @MachineTypeTable TABLE(MachineType VARCHAR(100));

    INSERT INTO @MachineTypeTable

    EXEC TCD.CharlistToTable @MachineTye, ',';

    DECLARE

     @MachineGroupTable TABLE(MachineGroup VARCHAR(100));

    INSERT INTO @MachineGroupTable

    EXEC TCD.CharlistToTable @machineGroup, ',';

    DECLARE

     @TypeId INT,

     @FilterTargetId INT;



    DECLARE

     @ResultTable TABLE

     (

     Id NVARCHAR(2000),

     Name NVARCHAR(300),

     TypeId INT

     );
	 

    SELECT @FilterTargetId = RFM.TargetDropDown

  FROM TCD.ReportFilterMapping RFM

  WHERE RFM.FilterId = @FilterId

    AND RFM.ReportId = @ReportId;

    IF @FilterId IS NULL



    --Filter Options for Region and Country filter  



    BEGIN

    SELECT @FilterTargetId = RF.ReportFilterId

      FROM TCD.ReportFilter RF

      WHERE RF.FilterName = 'Machine Types';

    END;

    IF @FilterTargetId = 8



    --Filter Options for machine Types  



    BEGIN

    SELECT @TypeId = RF.ReportFilterId

      FROM TCD.ReportFilter RF

      WHERE RF.FilterName = 'Machine Types';

    INSERT INTO @ResultTable (

    Id,

    Name,

    TypeId

    )

    SELECT DISTINCT

    WGT.WasherGroupTypeId AS Id,

    WGT.WasherGroupTypeName AS Name,

    @TypeId AS TypeId

      FROM

    TCD.WasherGroupType WGT

  END;

    ELSE

    BEGIN IF @FilterTargetId = 5



      --Filter Options for Machine groups based on plant  



      BEGIN

      SELECT @TypeId = RF.ReportFilterId

        FROM TCD.ReportFilter RF

        WHERE RF.FilterName = 'Machine group';

      SELECT @MachineTye = CASE @MachineTye WHEN 3 THEN '' ELSE @MachineTye END;



      --INSERT INTO @ResultTable (

      --Id,

      --Name,

      --TypeId

      --)

      SELECT 
     CAST( WG.WasherGroupId AS VARCHAR(1000)) AS Id ,

      WG.WasherGroupName AS Name,

      @TypeId AS TypeId

      FROM TCD.WasherGroup WG

      WHERE CASE WHEN ISNULL( @MachineTye,'')='' THEN 'TRUE'

       WHEN  @MachineTye='0' THEN 'False'

        ELSE

        CASE

        WHEN WG.WasherGroupTypeId  IN (SELECT MachineType

      FROM @MachineTypeTable) THEN 'TRUE'

        END

        END = 'TRUE'
		ORDER By CAST( WG.WasherGroupNumber as int);

		RETURN

      END;

      ELSE

      BEGIN IF @FilterTargetId = 6



        --Filter Options for Machines based on Group  



        BEGIN

        SELECT @TypeId = RF.ReportFilterId

          FROM TCD.ReportFilter RF

          WHERE RF.FilterName = 'Machine';

        --INSERT INTO @ResultTable (

        --Id,

        --Name,

        --TypeId

        --)



        SELECT 

       cast( W.WasherId AS varchar(2000)) AS Id,

       CAST( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName AS Name,

        @TypeId AS TypeId

          FROM

        TCD.MachineSetup MS

        INNER JOIN TCD.Washer W ON MS.WasherId = W.WasherId

         WHERE  IsNULL(MS.IsPony,0) = 0

         AND (MS.GroupId IN (SELECT MachineGroup

        FROM @MachineGroupTable) or ISNULL(@machineGroup,'')='' )



       ORDER BY cast( W.PlantWasherNumber AS int)

       RETURN;

        END;

      END;

    END;

    IF @FilterId = 21

   AND @ReportId = 30



    --Filter Options for User



    BEGIN

    SELECT @TypeId = RF.ReportFilterId

      FROM TCD.ReportFilter RF

      WHERE RF.FilterName = 'User';

    INSERT INTO @ResultTable (

    Id,

    Name,

    TypeId

    )

    SELECT DISTINCT

    UserId AS Id,

   FirstName +' ' + LastName AS name,

    NULL AS TypeId

      FROM tcd.usermaster;

    END;

    ELSE

    BEGIN

    IF @FilterId = 22

    BEGIN

    SELECT @TypeId = RF.ReportFilterId

      FROM TCD.ReportFilter RF

      WHERE RF.FilterName = 'ActionType';

 INSERT INTO @ResultTable (

    Id,

    Name,

    TypeId

    )

    SELECT DISTINCT

    CAST(AO.OperationId AS INT) AS OperationId,

    RKV.Value AS OperationCode,

    NULL  AS TypeId

      FROM TCD.AuditOperation AO

       LEFT JOIN

       TCD.ResourceKeyMaster RKM

    ON AO.UsageKey = RKM.[KeyName]

       LEFT JOIN

       TCD.ResourceKeyValue RKV

    ON RKV.KeyName = RKM.KeyName

      WHERE RKV.languageID = @LanguageId

      ORDER BY OperationId;

    END;

    END;



    SELECT

    

    Id,

    Name,

    TypeId

  FROM @ResultTable;

END;