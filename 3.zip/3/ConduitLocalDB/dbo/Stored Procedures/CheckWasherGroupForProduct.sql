﻿CREATE PROCEDURE TCD.CheckWasherGroupForProduct
       @Washergroupid INT = NULL, 
       @Ecolabaccountnumber NVARCHAR(25) = NULL
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    DECLARE @Regionid INT = NULL

    SELECT
            @Regionid = RegionID
        FROM TCD.Plant
        WHERE EcolabAccountNumber = @Ecolabaccountnumber

    ;WITH CTE
        AS (SELECT DISTINCT
                    wg.WasherGroupId, 
                    ms.ControllerId, 
                    ControllerWasherGroupID.WasherGroupId AS ChildWGID, 
                    ControllerWasherGroupID.ControllerId AS ChildControllerID
                FROM TCD.WasherGroup AS wg
                     INNER JOIN TCD.MachineGroup AS mg ON mg.Id = wg.WasherGroupId
                                                      AND mg.EcolabAccountNumber = wg.EcolabAccountNumber
                                                      AND mg.Is_Deleted = 'False'
                     INNER JOIN TCD.MachineSetup AS ms ON wg.WasherGroupId = ms.GroupId
                                                      AND ms.EcoalabAccountNumber = wg.EcolabAccountNumber
                                                      AND ms.IsDeleted = 'False'
                     CROSS APPLY(SELECT
                                         wg2.WasherGroupId, 
                                         ms2.ControllerId
                                     FROM TCD.WasherGroup AS wg2
                                          INNER JOIN TCD.MachineGroup AS mg2 ON mg2.Id = wg2.WasherGroupId
                                                                            AND mg2.EcolabAccountNumber = wg2.EcolabAccountNumber
                                                                            AND mg2.Is_Deleted = 'False'
                                          INNER JOIN TCD.MachineSetup AS ms2 ON wg2.WasherGroupId = ms2.GroupId
                                                                            AND wg2.EcolabAccountNumber = ms2.EcoalabAccountNumber
                                                                            AND ms2.IsDeleted = 'False'
                                     WHERE ms2.ControllerId = ms.ControllerId)AS ControllerWasherGroupID
                WHERE wg.WasherGroupId = ISNULL(@Washergroupid, WG.WasherGroupId)
                  AND wg.EcolabAccountNumber = @Ecolabaccountnumber), CTE_Level2
        AS (SELECT DISTINCT
                    wg.WasherGroupId, 
                    ms.ControllerId, 
                    ControllerWasherGroupID.WasherGroupId AS ChildWGID, 
                    ControllerWasherGroupID.ControllerId AS ChildControllerID
                FROM TCD.WasherGroup AS wg
                     INNER JOIN TCD.MachineGroup AS mg ON mg.Id = wg.WasherGroupId
                                                      AND mg.EcolabAccountNumber = wg.EcolabAccountNumber
                                                      AND mg.Is_Deleted = 'False'
                     INNER JOIN TCD.MachineSetup AS ms ON wg.WasherGroupId = ms.GroupId
                                                      AND ms.EcoalabAccountNumber = wg.EcolabAccountNumber
                                                      AND ms.IsDeleted = 'False'
                     CROSS APPLY(SELECT
                                         wg2.WasherGroupId, 
                                         ms2.ControllerId
                                     FROM TCD.WasherGroup AS wg2
                                          INNER JOIN TCD.MachineGroup AS mg2 ON mg2.Id = wg2.WasherGroupId
                                                                            AND mg2.EcolabAccountNumber = wg2.EcolabAccountNumber
                                                                            AND mg2.Is_Deleted = 'False'
                                          INNER JOIN TCD.MachineSetup AS ms2 ON wg2.WasherGroupId = ms2.GroupId
                                                                            AND wg2.EcolabAccountNumber = ms2.EcoalabAccountNumber
                                                                            AND ms2.IsDeleted = 'False'
                                     WHERE ms2.ControllerId = ms.ControllerId)AS ControllerWasherGroupID
                WHERE wg.WasherGroupId IN(SELECT
                                                  ChildWGID FROM CTE)
                  AND wg.EcolabAccountNumber = @Ecolabaccountnumber), CTE_Level3
        AS (SELECT DISTINCT
                    wg.WasherGroupId, 
                    ms.ControllerId, 
                    ControllerWasherGroupID.WasherGroupId AS ChildWGID, 
                    ControllerWasherGroupID.ControllerId AS ChildControllerID
                FROM TCD.WasherGroup AS wg
                     INNER JOIN TCD.MachineGroup AS mg ON mg.Id = wg.WasherGroupId
                                                      AND mg.EcolabAccountNumber = wg.EcolabAccountNumber
                                                      AND mg.Is_Deleted = 'False'
                     INNER JOIN TCD.MachineSetup AS ms ON wg.WasherGroupId = ms.GroupId
                                                      AND ms.EcoalabAccountNumber = wg.EcolabAccountNumber
                                                      AND ms.IsDeleted = 'False'
                     CROSS APPLY(SELECT
                                         wg2.WasherGroupId, 
                                         ms2.ControllerId
                                     FROM TCD.WasherGroup AS wg2
                                          INNER JOIN TCD.MachineGroup AS mg2 ON mg2.Id = wg2.WasherGroupId
                                                                            AND mg2.EcolabAccountNumber = wg2.EcolabAccountNumber
                                                                            AND mg2.Is_Deleted = 'False'
                                          INNER JOIN TCD.MachineSetup AS ms2 ON wg2.WasherGroupId = ms2.GroupId
                                                                            AND wg2.EcolabAccountNumber = ms2.EcoalabAccountNumber
                                                                            AND ms2.IsDeleted = 'False'
                                     WHERE ms2.ControllerId = ms.ControllerId)AS ControllerWasherGroupID
                WHERE wg.WasherGroupId IN(SELECT
                                                  ChildWGID FROM CTE_Level2)
                  AND wg.EcolabAccountNumber = @Ecolabaccountnumber)
        SELECT DISTINCT
                cl.WasherGroupId FROM CTE_Level3 AS cl

    SET NOCOUNT OFF
END
GO