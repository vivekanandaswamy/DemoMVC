﻿CREATE PROCEDURE [TCD].[SaveRewashReasons]
		(
			@RewashReasonId int = NULL,
			@Description Varchar(2000) = NULL,
			@IsDeleted bit = NULL,
			@LastModifiedTime datetime = NULL,
			@LastSyncTime datetime = NULL
		)
AS
SET NOCOUNT ON
BEGIN
	   
	   IF EXISTS(SELECT * FROM TCD.RewashReason WHERE RewashReasonId = @RewashReasonId)
		  BEGIN

			UPDATE RR
			SET
			    --RewashReasonId - this column value is auto-generated
			    Description = @Description, -- varchar
			    IsDeleted = @IsDeleted, -- bit
			    LastModifiedTime = @LastModifiedTime, -- datetime
			    LastSyncTime = @LastSyncTime -- datetime
					   FROM TCD.RewashReason RR WHERE RR.RewashReasonId = @RewashReasonId
		  END
	   ELSE
		  BEGIN
			  INSERT INTO TCD.RewashReason
			 (
					RewashReasonId,
				    Description,
				    IsDeleted,
				    LastModifiedTime,
				    LastSyncTime
			 )
			 SELECT @RewashReasonId,
					@Description,
					@IsDeleted,
					@LastModifiedTime,
					@LastSyncTime
			
		  END
    
END