﻿/*	                                   
###################################################################################################                                           

Stored Procedure:       [[TCD]].[usp_GetFinnisherGroupDetails]                                     

Purpose:				To get the Finnisher group details.

Parameters:				@EcolabAccountNumber - holds the ecolab account number.
																														
###################################################################################################                                           
*/
CREATE PROCEDURE [TCD].[GetFinnisherGroupDetails]
@EcolabAccountNumber nvarchar(25)
AS  
BEGIN  
SET nocount ON;  
WITH CTE AS  
(  
SELECT  
FinnisherId,  
Name,  
FinnisherGroupId,  
FinnisherTypeId,
FinnisherNo  
,	LastModifiedTime
FROM Finnishers F WHERE F.IS_DELETED <> 1  AND EcolabAccountNumber = @EcolabAccountNumber
)  

Select  G.Id  
,F.FinnisherId  
,F.Name  
,G.GroupDescription  
,G.EcolabAccountNumber  
,FT.FinnisherTypeId
,F.FinnisherNo  
,FT.Name AS FinnisherTypeName  
,	G.LastModifiedTime			AS			FinisherGroupLastModifiedTime
,	F.LastModifiedTime			AS			FinisherLastModifiedTime
,   G.Is_Deleted				AS			IsDeleted
from MachineGroup G LEFT OUTER JOIN CTE F ON G.Id = F.FinnisherGROUPID  
Left Join FinnisherType FT on FT.FinnisherTypeId = F.FinnisherTypeId  
WHERE  
G.EcolabAccountNumber = @EcolabAccountNumber
--AND G.IS_DELETED <> 1  
AND G.GroupTypeId = 4
ORDER BY G.Id DESC  

END  
