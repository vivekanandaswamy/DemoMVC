﻿/*      
 ==========================================================================================      
 Purpose:  DELETING THE PLANT SHIFT LABOUR DATA  
    
 Author: PREMCHAND YELAVARTHI

    
 --------------------------------------------------------------      
 Sep-11-2014 ENT: Initial version.      
 ==========================================================================================   
*/
CREATE PROCEDURE [TCD].[DeleteShiftLabourDetails] (
						 @Id Int = NULL,
						 @EcolabAccountNumber NVarchar(25),
						 @UserID INT = NULL,
						 @Scope varchar(100) OUTPUT
					--Adding as part of re-factoring for integration with Synch/Configurator
					,	@LastModifiedTimestampAtCentral		DATETIME			=			NULL			--Nullable for local call; Synch/Central call will have to pass this -
																											--else, it will be treated as a local call
					,	@OutputLastModifiedTimestampAtLocal	DATETIME			=			NULL	OUTPUT
					)
 AS 
SET NOCOUNT ON
  BEGIN
  DECLARE @OutPut VARCHAR(50) = ''

	DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()

	DECLARE
		@OutputList					AS	TABLE		(
		ShiftLaborDataId				INT
	,	LastModifiedTimestamp			DATETIME
	)

	--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
	--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
	SET		@OutputLastModifiedTimestampAtLocal					=			@CurrentUTCTime
	--We thus won't set this output param after the operation
	SET		@Scope			=			ISNULL(@Scope, NULL)			--SQLEnlight SA0121

  BEGIN
		--If the call is not local, check that the LastModifiedTime matches with the central
		IF	(
				@LastModifiedTimestampAtCentral				IS NOT	NULL
			AND
			NOT	EXISTS	(	SELECT	1
							FROM	TCD.ShiftLaborData		SLD
							WHERE	SLD.EcolabAccountNumber	=	@EcolabAccountNumber
								AND	SLD.LaborId				=	@Id
								AND	SLD.LastModifiedTime	=	@LastModifiedTimestampAtCentral
						)
			)
				BEGIN
						SET			@ErrorId				=	60000
						SET			@ErrorMessage			=	N'' + CAST(@ErrorId AS NVARCHAR) + N': Record not in-synch between plant and central.'
						RAISERROR	(@ErrorMessage, 16, 1)
						SET			@ReturnValue			=	-1
						RETURN		(@ReturnValue)
				END

		--Proceed to update, since it's either a local call or Synch. call with synch. time matching
		/*UPDATING THE DATA FOR SHIFT LABOUR DATA*/
				UPDATE SLD SET SLD.IS_Deleted = 1
		,	LastModifiedByUserId	=	@UserId
		--**	Adding as part of re-factoring for integration with Synch./Configurator
		,LastModifiedTime	=	@CurrentUTCTime
		OUTPUT
				inserted.LaborId			AS	ShiftLaborDataId
			,	inserted.LastModifiedTime	AS	LastModifiedTime
		INTO	@OutputList	(
				ShiftLaborDataId
			,	LastModifiedTimestamp
			)
		--**	Adding as part of re-factoring for integration with Synch./Configurator
		FROM [TCD].ShiftLaborData SLD WHERE LaborId = @Id AND EcolabAccountNumber = @EcolabAccountNumber

			SET @OutPut = @Id
			SET @Scope = @OutPut 
			SELECT @Scope  


   END
   END