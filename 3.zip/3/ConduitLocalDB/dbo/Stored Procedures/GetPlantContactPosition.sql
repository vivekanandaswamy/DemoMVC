/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_GetPlantContactPosition]                                          

Purpose:				To get the plant contact position.
																				
Parameters:				None

###################################################################################################                                           
*/
CREATE PROCEDURE [TCD].[GetPlantContactPosition] 

AS   
  BEGIN
  SET NOCOUNT ON
		  SELECT 
				  Id,
				  Position_Name			 
		  FROM [TCD].PlantContactPosition 
	SET NOCOUNT OFF
  END