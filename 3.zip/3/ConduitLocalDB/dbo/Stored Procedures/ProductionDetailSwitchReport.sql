--exec [TCD].[ProductionDetailSwitchReport] @Corporate=N'',@Country=N'',@Region=N'',@EcolabAccountNumber=N'',@Machine=N'',@machineGroup=N'',@Formula=N'',@MachineType=N'',
--@Category=N'',@FromDate='2015-01-01 00:00:00',@ToDate='2015-01-04 00:00:00',@GroupId=N'',@MachineInternalId=N'',
--@FormulaWise=0,@EcolabTextileWise=0,@TextileCareCustomerWise=0,@ChainFormulaWise=1,@SortColumnID = 200,@SortDirection= 'dESC', @UserId = NULL,@IsDrillDown = 0	


CREATE PROCEDURE [TCD].[ProductionDetailSwitchReport] (
											 @Corporate Varchar(max) = '',
											 @Country Varchar(max) = '',
											 @Region Varchar(max) = '',
											 @EcolabAccountNumber Nvarchar(25) = '',
											 @Machine Varchar(max) = '', 
											 @machineGroup Varchar(max) = '',
											 @Formula Varchar(max) = '',
											 @MachineType Varchar(20)= '',
											 @Category Varchar(max) = '',
											 @FromDate Date = '',
											 @ToDate Date = '',
											 @GroupId Varchar(max) = '',
											 @MachineInternalId Varchar(max) = '',
											 --@Customer Varchar(max) = '',
											 @FormulaWise bit = NULL,
											 @EcolabTextileWise bit = NULL,
											 @TextileCareCustomerWise bit = NULL,
											 @ChainFormulaWise bit = NULL,
											 @SortColumnID INT = NULL,
											 @SortDirection Varchar(100) = '',
											 @UserId Int = NULL	,
											 @IsDrillDown	BIT								 
										   )
AS   
BEGIN   
SET NOCOUNT ON;   

DECLARE @ReportGenerated INT = 6, 
	   @SortField Varchar(100) = '',
	   @SQLStatement varchar(max),
	   @TotalRunTime INT

SET		@UserId			=			ISNULL(@UserId, NULL)			--SQLEnlight SA0029
SET		@Country		=			ISNULL(@Country, NULL)			--SQLEnlight SA0029
SET		@Corporate		=			ISNULL(@Corporate, NULL)		--SQLEnlight SA0029


--/* Inserting the record into Report History */

--INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)
--SELECT @EcolabAccountNumber,UM.UserId,
--	  UM.LoginName,
--	  GETUTCDATE(),
--	  @ReportGenerated,
--	  CASE WHEN @ReportGenerated = 6
--		THEN 'Generated Report : ProductiondetailsReport' END
--	  FROM TCD.UserMaster UM
--	    WHERE	UM.EcolabAccountNumber =	@EcolabAccountNumber AND UM.UserId = @UserId

--/* Completed the record insertion into Report History */

 SELECT @SortField =  CASE WHEN @SortColumnID = 66 THEN 'ProductionDiff'
						    WHEN @SortColumnID = 119 THEN 'LoadEfficiency'
						    WHEN @SortColumnID = 84 THEN 'FormulaName'
						    WHEN @SortColumnID = 120 THEN 'ActualProductionperhour'
						    WHEN @SortColumnID = 133 THEN 'NumberOfLoads'
						    WHEN @SortColumnID = 135 THEN 'NumberOfPieces'						
						    WHEN @SortColumnID = 146 THEN 'ProductionMix'
						    WHEN @SortColumnID = 156 THEN 'Rewash'
						    WHEN @SortColumnID = 181 THEN 'TargetLoad'
						    WHEN @SortColumnID = 182 THEN 'TargetProductionperhour'
						    WHEN @SortColumnID = 200 THEN 'TotalLoad'
						    WHEN @SortColumnID = 242 THEN 'DateRange'
						    WHEN @SortColumnID = 244 THEN 'EcolabTextileCategory'
						    WHEN @SortColumnID = 245 THEN 'PlantTextileCategoryName'
						    WHEN @SortColumnID = 246 THEN 'PlantProgramName'
						    WHEN @SortColumnID = 0 THEN 'TotalLoad'
					 END



DECLARE @Month INT = MONTH(GETDATE()),
	   @SummationInMin Int = NULL,@summingActualLoad Decimal(10,2) = NULL

DECLARE @CategoryTable TABLE(Category VARCHAR(100))
INSERT INTO @CategoryTable(Category) EXEC [TCD].[CharlistToTable] @Category,','


DECLARE @MachineTable TABLE(Machine VARCHAR(100))
INSERT INTO @MachineTable(Machine) EXEC [TCD].[CharlistToTable] @Machine,','


DECLARE @GroupMachineTable TABLE(GroupId INT,MachineInternalId INT)  
INSERT INTO @GroupMachineTable(GroupId,MachineInternalId)   
SELECT GroupId,MachineInternalId 
FROM 
TCD.MachineSetup MS 
INNER JOIN TCD.Washer WS ON MS.WasherId = WS.WasherId 
WHERE WS.PlantWasherNumber IN (SELECT Machine FROM @MachineTable);


DECLARE @GroupTable TABLE(GroupId VARCHAR(100))
INSERT INTO @GroupTable(GroupId) EXEC [TCD].[CharlistToTable] @GroupId,','


DECLARE @MachineInternalTable TABLE(MachineInternalId VARCHAR(100))
INSERT INTO @MachineInternalTable(MachineInternalId) EXEC [TCD].[CharlistToTable] @MachineInternalId,','

DECLARE @WasherGroupTable TABLE(MachineGroup VARCHAR(100))
INSERT INTO @WasherGroupTable(MachineGroup) EXEC [TCD].[CharlistToTable] @MachineGroup,','


DECLARE @FormulaTable TABLE(Formula VARCHAR(100))
INSERT INTO @FormulaTable(Formula) EXEC [TCD].[CharlistToTable] @Formula,','


--DECLARE @CustomerTable TABLE(Customer VARCHAR(100))
--INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','


DECLARE @MachineTypeTable TABLE(MachineType VARCHAR(100))
INSERT INTO @MachineTypeTable(MachineType) EXEC [TCD].[CharlistToTable] @MachineType,','

    
			 /* Including the Latest Batch Data */

	   		  IF((CAST(@ToDate AS DATE) = CAST(GETUTCDATE() AS date)))
				    BEGIN				     

					EXEC [TCD].[ProductionDataRollUp] @ToDate

					END

			 /* Ending the Latest Batch Data Logic */


	  DECLARE @ProductionDetailTable TABLE(
								    RecordDate date,
								    ProgramId INT,
								    FormulaName Nvarchar(100),
								    EcolabTextileId INT,
								    EcolabTextileCategory Nvarchar(100),
								    PlantTextileId INT,
								    PlantTextileCategoryName Nvarchar(100),
								    PlantProgramId INT,
								    PlantProgramName Nvarchar(100),
								    TotalLoad Decimal(10,0) ,
								    TargetLoad Decimal(10,0),
								    DifferenceLoad Decimal(10,0),
								    LoadEfficiency DECIMAL(10,0),
								    ProductionMix DECIMAL(10,0),
								    Numberofbatches INT,
								    ActualLoadperhour Decimal(10,2),
								    TargetLoadperhour Decimal(10,2),
								    NumberOfPieces INT,
								    Rewash Decimal(10,0),
								    TotalRunTime Decimal(18,2)
								  )
	   INSERT INTO @ProductionDetailTable(
								    RecordDate ,
								    ProgramId,
								    FormulaName ,
								    EcolabTextileId ,
								    EcolabTextileCategory,
								    PlantTextileId ,
								    PlantTextileCategoryName ,
								    PlantProgramId ,
								    PlantProgramName,
								    TotalLoad,
								    TargetLoad,
								    DifferenceLoad,
								    LoadEfficiency,
								    ProductionMix ,
								    Numberofbatches ,
								    ActualLoadperhour ,
								    TargetLoadperhour ,
								    NumberOfPieces ,
								    Rewash ,
								    TotalRunTime
								  )
	   SELECT 
			 PRT.RecordDate,
			 PRT.ProgramNumber,
			 PM.Name,
			 PRT.EcolabTextileId,
			 PRT.EcolabTextileCategoryName,
			 PRT.PlantTextileId,
			 PRT.PlantTextileCategoryName,
			 PRT.PlantProgramId,
			 PRT.PlantProgramName,
			 PRT.TotalActualLoad + CASE WHEN (SELECT COUNT(1) FROM TCD.ManualProduction MP WHERE PRT.RecordDate = CAST(MP.RecordedDate AS DATE)) > 0 THEN 
			 (SELECT SUM(MP.value) FROM TCD.ManualProduction MP WHERE PRT.RecordDate = CAST(MP.RecordedDate AS DATE)) ELSE 0 END,
			 PRT.TotalStandardLoad,
			 (PRT.TotalStandardLoad - (PRT.TotalActualLoad + CASE WHEN (SELECT COUNT(1) FROM TCD.ManualProduction MP WHERE PRT.RecordDate = CAST(MP.RecordedDate AS DATE)) > 0 THEN 
			 (SELECT SUM(MP.value) FROM TCD.ManualProduction MP WHERE PRT.RecordDate = CAST(MP.RecordedDate AS DATE)) ELSE 0 END)),
			 PRT.LoadEfficiency,
			 PRT.ProductionMix,
			 PRT.NoOfBatches,
			 --+ CASE WHEN (SELECT COUNT(1) FROM TCD.ManualProduction MP WHERE PRT.RecordDate = CAST(MP.RecordedDate AS DATE)) > 0 THEN 
			 --(SELECT COUNT(1) FROM TCD.ManualProduction MP WHERE PRT.RecordDate IN (CAST(MP.RecordedDate AS DATE)))
			 -- ELSE 0 END,
			 PRT.ActualLoadPerHour,
			 PRT.TargetLoadPerHour,
			 PRT.NumberOfPieces,
			 PRT.Rewash,
			 PRT.TotalRunTime
			 	 FROM TCD.ProductionRollUp PRT
					   INNER JOIN 
					   TCD.ProgramMaster PM ON PRT.ProgramNumber = PM.ProgramId
					   LEFT OUTER JOIN TCD.ManualProduction MP ON PRT.RecordDate = CAST(MP.RecordedDate AS DATE)
	   WHERE 
				--CASE @Customer   
                                           
				-- WHEN '' THEN 'TRUE'         
				-- ELSE                                                      
				--  CASE WHEN PRT.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                      
				--END='TRUE' 

				--AND       
				

				CASE @Machine   
				 WHEN '' THEN 'TRUE'         
				 ELSE                                                      
				  CASE WHEN PRT.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
				END='TRUE' 

				AND       

				CASE @machineGroup   
                                           
				 WHEN '' THEN 'TRUE'         
				 ELSE                                                      
				  CASE WHEN PRT.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable) THEN 'TRUE' END                                                      
				END='TRUE' 

				AND    
				
				CASE @Formula   
                                           
				 WHEN '' THEN 'TRUE'         
				 ELSE                                                      
				  CASE WHEN PRT.ProgramNumber IN (SELECT Formula FROM @FormulaTable) THEN 'TRUE' END                                                      
				END='TRUE' 

				AND       
				
				CASE @MachineType   
                                           
				 WHEN '' THEN 'TRUE'         
				 ELSE                                                      
				  CASE WHEN PRT.GroupId IN (SELECT WG.WasherGroupId FROM WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable)) THEN 'TRUE' END                                                      
				END='TRUE' 

				AND       

				  
				CASE @FromDate                                                                                
				    WHEN '' THEN Case WHEN MONTH(PRT.RecordDate) = @Month Then  'true' END                                                                                
				    ELSE CASE WHEN PRT.RecordDate >= @FromDate and PRT.RecordDate <= @TODATE THEN 'true'END                                                        
				 END='true'

				 AND

				 CASE @Category   
                                           
				 WHEN '' THEN 'TRUE'         
				 ELSE                                                      
				  CASE WHEN PRT.EcolabTextileId IN (SELECT Category FROM @CategoryTable) THEN 'TRUE' END                                                      
				END='TRUE' 

				AND

				 CASE @GroupId 
                                           
				 WHEN '' THEN 'TRUE' 
				 ELSE        
				CASE WHEN (PRT.GroupId IN (@GroupId) AND 
				  PRT.MachineInternalId IN (@MachineInternalId)) THEN 'TRUE' END                                                   
				END='TRUE' 

				AND

				 CASE @MachineInternalId 
                                           
				 WHEN '' THEN 'TRUE' 
				 ELSE        
				CASE WHEN (PRT.GroupId IN (@GroupId) AND 
				  PRT.MachineInternalId IN (@MachineInternalId)) THEN 'TRUE' END                                                   
				END='TRUE'  


				/* Including the latest data from batch tables */
		  
				/*

				IF(CAST(@FromDate AS DATE) = CAST(GETDATE() AS date))
				    BEGIN

					EXEC [TCD].[ProductionBatchLatestData] @Corporate,@Country,@Region,@EcolabAccountNumber,@Machine,@machineGroup,@Formula,
												     @MachineType,@Category,@FromDate,@ToDate,@GroupId,@MachineInternalId,@FromDate
				     					
						
					 INSERT INTO @ProductionDetailTable
					  SELECT 
							 PRT.RecordDate,
							 PRT.ProgramNumber,
							 PM.Name,
							 PRT.EcolabTextileId,
							 PRT.EcolabTextileCategoryName,
							 PRT.PlantTextileId,
							 PRT.PlantTextileCategoryName,
							 PRT.PlantProgramId,
							 PRT.PlantProgramName,
							 PRT.TotalActualLoad + CASE WHEN (SELECT COUNT(1) FROM TCD.ManualProduction MP WHERE PRT.RecordDate = CAST(MP.RecordedDate AS DATE)) > 0 THEN 
							 (SELECT SUM(MP.value) FROM TCD.ManualProduction MP WHERE PRT.RecordDate = CAST(MP.RecordedDate AS DATE)) ELSE 0 END,
							 PRT.TotalStandardLoad,
							 (PRT.TotalStandardLoad - (PRT.TotalActualLoad + CASE WHEN (SELECT COUNT(1) FROM TCD.ManualProduction MP WHERE PRT.RecordDate = CAST(MP.RecordedDate AS DATE)) > 0 THEN 
							 (SELECT SUM(MP.value) FROM TCD.ManualProduction MP WHERE PRT.RecordDate = CAST(MP.RecordedDate AS DATE)) ELSE 0 END)),
							 PRT.LoadEfficiency,
							 PRT.ProductionMix,
							 PRT.ActualLoadPerHour,
							 PRT.TargetLoadPerHour,
							 PRT.NoOfBatches + CASE WHEN (SELECT COUNT(1) FROM TCD.ManualProduction MP WHERE PRT.RecordDate = CAST(MP.RecordedDate AS DATE)) > 0 THEN 
							 (SELECT COUNT(1) FROM TCD.ManualProduction MP WHERE PRT.RecordDate = CAST(MP.RecordedDate AS DATE))
							  ELSE 0 END,
							 PRT.NumberOfPieces,
							 PRT.Rewash
			 	 FROM #ProductionRollUpLatest PRT
					   INNER JOIN 
					   TCD.ProgramMaster PM ON PRT.ProgramNumber = PM.ProgramId
					   LEFT OUTER JOIN TCD.ManualProduction MP ON PRT.RecordDate = CAST(MP.RecordedDate AS DATE)

					   DROP TABLE #ProductionRollUpLatest
				    END

				    */

				    /* End of production latest batch data */
		
			 SELECT @summingActualLoad = SUM(TotalLoad)  FROM @ProductionDetailTable
		

			 
				/* Switch Category FormaulaWise */
		  
		  IF(@FormulaWise = 1)
		  BEGIN		  
						
		 	   SELECT 
			     ProgramId,
				Cast(ProgramId AS VARCHAR(1000)) + CHAR(13) + '-' + CHAR(13) +  FormulaName AS FormulaName,
				SUM(TotalLoad) AS TotalLoad,
				SUM(TargetLoad) AS TargetLoad,
				SUM(TargetLoad) - SUM(TotalLoad) AS ProductionDiff,
				CAST((SUM(TotalLoad) * 100 /SUM(TargetLoad)) AS decimal(18,0)) AS LoadEfficiency,
				CAST((SUM(TotalLoad) * 100 /@summingActualLoad) AS decimal(18,0)) AS ProductionMix,
				--CAST((TotalLoad * 100 /(SELECT SUM(TotalLoad)  FROM @ProductionDetailTable GROUP BY ProgramId)) AS decimal(18,2)) AS ProductionMix,
				CAST((SUM(TotalLoad)/SUM(TotalRunTime)) AS decimal(18,2)) AS ActualProductionperhour,
				CAST((SUM(TargetLoad)/SUM(TotalRunTime)) AS decimal(18,2)) AS TargetProductionperhour,
				SUM(Numberofbatches) AS NumberOfLoads,
				SUM(NumberOfPieces) AS NumberOfPieces,
				--SUM(Rewash) AS Rewash
				CAST(((SELECT SUM(MR.VALUE) FROM TCD.ManualRewash MR WHERE PDT.ProgramId = MR.FormulaId GROUP BY MR.FormulaId) * 100 /@summingActualLoad) AS decimal(18,0)) AS Rewash,
				'Formula' AS SwithMode, @IsDrillDown AS IsDrillDown,
				SUM(TotalRunTime) AS TotalRunTime
				INTO #ProdTableFormulaOrder
			 FROM @ProductionDetailTable PDT
			 WHERE PDT.ProgramId IS NOT NULL
			  GROUP BY ProgramId,FormulaName

			  SET @SQLStatement 
					   ='SELECT * FROM #ProdTableFormulaOrder ORDER BY ' + @SortField + ' ' + @SortDirection

	   			EXEC(@SQLStatement)


		  END
				
				
			 /* Switch Category TextileCategory Ecolab */

		  IF(@EcolabTextileWise = 1)
		  BEGIN
			 SELECT 
				EcolabTextileId,
				EcolabTextileCategory,
				SUM(TotalLoad) AS TotalLoad,
				SUM(TargetLoad) AS TargetLoad,
				SUM(TargetLoad) - SUM(TotalLoad) AS ProductionDiff,
				CAST((SUM(TotalLoad) * 100 /SUM(TargetLoad)) AS decimal(18,0)) AS LoadEfficiency,
				CAST((SUM(TotalLoad) * 100 /@summingActualLoad) AS decimal(18,0)) AS ProductionMix,
				--CAST((TotalLoad * 100 /(SELECT SUM(TotalLoad)  FROM @ProductionDetailTable GROUP BY ProgramId)) AS decimal(18,2)) AS ProductionMix,
				CAST((SUM(TotalLoad)/SUM(TotalRunTime)) AS decimal(18,2)) AS ActualProductionperhour,
				CAST((SUM(TargetLoad)/SUM(TotalRunTime)) AS decimal(18,2)) AS TargetProductionperhour,
				SUM(Numberofbatches) AS NumberOfLoads,
				SUM(NumberOfPieces) AS NumberOfPieces,
				--SUM(Rewash) AS Rewash,
				CAST(((SELECT SUM(MR.VALUE) FROM TCD.ManualRewash MR WHERE MR.FormulaId IN 
				(SELECT PM.ProgramId FROM TCD.ProgramMaster PM WHERE PM.EcolabTextileCategoryId = PDT.EcolabTextileId) GROUP BY MR.FormulaId) * 100 /@summingActualLoad) AS decimal(18,0)) AS Rewash,
				'Textile Category' AS SwithMode,@IsDrillDown AS IsDrillDown,
				SUM(TotalRunTime) AS TotalRunTime
				INTO #ProdTableEcoTextileOrder
				FROM @ProductionDetailTable PDT
				WHERE PDT.EcolabTextileId IS NOT NULL
			  GROUP BY EcolabTextileId,EcolabTextileCategory

			   SET @SQLStatement 
					   ='SELECT * FROM #ProdTableEcoTextileOrder ORDER BY ' + @SortField + ' ' + @SortDirection

	   			EXEC(@SQLStatement)

		  END

    
			 /* Switch Category PlantTextileWise */
		  
		  IF(@TextileCareCustomerWise = 1)
		  BEGIN
			 SELECT 
				PlantTextileId,
				PlantTextileCategoryName,
				SUM(TotalLoad) AS TotalLoad,
				SUM(TargetLoad) AS TargetLoad,
				SUM(TargetLoad) - SUM(TotalLoad) AS ProductionDiff,
				CAST((SUM(TotalLoad) * 100 /SUM(TargetLoad)) AS decimal(18,0)) AS LoadEfficiency,
				CAST((SUM(TotalLoad) * 100 /@summingActualLoad) AS decimal(18,0)) AS ProductionMix,
				--CAST((TotalLoad * 100 /(SELECT SUM(TotalLoad)  FROM @ProductionDetailTable GROUP BY ProgramId)) AS decimal(18,2)) AS ProductionMix,
				CAST((SUM(TotalLoad)/SUM(TotalRunTime)) AS decimal(18,2)) AS ActualProductionperhour,
				CAST((SUM(TargetLoad)/SUM(TotalRunTime)) AS decimal(18,2)) AS TargetProductionperhour,
				SUM(Numberofbatches) AS NumberOfLoads,
				SUM(NumberOfPieces) AS NumberOfPieces,
				--SUM(Rewash) AS Rewash,
				CAST(((SELECT SUM(MR.VALUE) FROM TCD.ManualRewash MR WHERE MR.FormulaId IN (SELECT PM.ProgramId FROM TCD.ProgramMaster PM WHERE PM.ChainTextileId = PDT.PlantTextileId) GROUP BY MR.FormulaId) * 100 /@summingActualLoad) AS decimal(18,0)) AS Rewash,
				--CAST(((SELECT SUM(MR.VALUE) FROM TCD.ManualRewash MR WHERE PDT.ProgramId = MR.FormulaId GROUP BY MR.FormulaId) * 100 /@summingActualLoad) AS decimal(18,2)) AS Rewash
				'Texttile Category Customer' AS SwithMode,@IsDrillDown AS IsDrillDown,
				SUM(TotalRunTime) AS TotalRunTime
				
				 INTO #ProdTablePlantTextileOrder
			 FROM @ProductionDetailTable PDT
			 WHERE PDT.PlantTextileId IS NOT NULL
			  GROUP BY PlantTextileId,PlantTextileCategoryName

			    SET @SQLStatement 
					   ='SELECT * FROM #ProdTablePlantTextileOrder ORDER BY ' + @SortField + ' ' + @SortDirection

	   			EXEC(@SQLStatement)

		  END

		  /* Switch Category PlantFormulaWise */
		  
		  IF(@ChainFormulaWise = 1)
		  BEGIN
			 SELECT 
				PlantProgramId,
				PlantProgramName,
				SUM(TotalLoad) AS TotalLoad,
				SUM(TargetLoad) AS TargetLoad,
				SUM(TargetLoad) - SUM(TotalLoad) AS ProductionDiff,
				CAST((SUM(TotalLoad) * 100 /SUM(TargetLoad)) AS decimal(18,0)) AS LoadEfficiency,
				CAST((SUM(TotalLoad) * 100 /@summingActualLoad) AS decimal(18,0)) AS ProductionMix,
				--CAST((TotalLoad * 100 /(SELECT SUM(TotalLoad)  FROM @ProductionDetailTable GROUP BY ProgramId)) AS decimal(18,2)) AS ProductionMix,
				CAST((SUM(TotalLoad)/SUM(TotalRunTime)) AS decimal(18,2)) AS ActualProductionperhour,
				CAST((SUM(TargetLoad)/SUM(TotalRunTime)) AS decimal(18,2)) AS TargetProductionperhour,
				SUM(Numberofbatches) AS NumberOfLoads,
				SUM(NumberOfPieces) AS NumberOfPieces,
				--SUM(Rewash) AS Rewash,
				CAST(((SELECT SUM(MR.VALUE) FROM TCD.ManualRewash MR WHERE MR.FormulaId IN (SELECT PM.ProgramId FROM TCD.ProgramMaster PM WHERE PM.PlantProgramId IN (PDT.PlantProgramId)) GROUP BY MR.FormulaId) * 100 /@summingActualLoad) AS decimal(18,0)) AS Rewash,
				--CAST(((SELECT SUM(MR.VALUE) FROM TCD.ManualRewash MR WHERE PDT.ProgramId = MR.FormulaId GROUP BY MR.FormulaId) * 100 /@summingActualLoad) AS decimal(18,2)) AS Rewash
				'Chain Formula' AS SwithMode,@IsDrillDown AS IsDrillDown,
				SUM(TotalRunTime) AS TotalRunTime
				 INTO #ProdTablePlantChainOrder
			 FROM @ProductionDetailTable PDT
			  WHERE PDT.PlantProgramId IS NOT NULL
			  GROUP BY PlantProgramId,PlantProgramName

			  SET @SQLStatement 
					   ='SELECT * FROM #ProdTablePlantChainOrder ORDER BY ' + @SortField + ' ' + @SortDirection

	   			EXEC(@SQLStatement)


		  END

			
    END

  