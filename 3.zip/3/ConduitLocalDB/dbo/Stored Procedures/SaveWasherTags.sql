CREATE PROCEDURE [TCD].[SaveWasherTags]	
					@EcolabAccountNumber	NVARCHAR(25)
				,	@WasherId			INT
				 ,	@TagDescription		NVARCHAR(100)
				 ,	@TagAddress			NVARCHAR(50)
				 ,	@Count				INT
				 ,	@ConventionalTagId	VARCHAR(100) OUTPUT
				 

AS
BEGIN
SET	NOCOUNT	ON


DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''

	,	@WasherTagId					INT
	,	@TagType						NVARCHAR(50)

SET		@ConventionalTagId			=			ISNULL(@ConventionalTagId, NULL)			--SQLEnlight SA0121
SET		@Count						=			ISNULL(@Count, NULL)						--SQLEnlight SA0029

-- getting the tagtype based on the tag description
SELECT @TagType=(SELECT TagType FROM [TCD].TagType WHERE TagDescription =@TagDescription)
IF(@TagType!='Tag_WSNO')
	BEGIN
		IF EXISTS (SELECT 1 FROM [TCD].WasherTags WT WHERE WT.WasherId=@WasherId AND WT.TagType=@TagType AND WT.EcolabAccountNumber = @EcolabAccountNumber)
			BEGIN
			UPDATE [TCD].WasherTags SET		TagAddress=@TagAddress	WHERE		WasherId=@WasherId		 AND		TagType=@TagType AND EcolabAccountNumber=@EcolabAccountNumber
			
			END
		ELSE
			BEGIN
				IF (SELECT COUNT(*) FROM [TCD].[WasherTags] WHERE EcolabAccountNumber=@EcolabAccountNumber) >0
					SELECT @WasherTagId=(SELECT MAX(WasherTagId)+1 FROM [TCD].WasherTags WHERE EcolabAccountNumber=@EcolabAccountNumber)
				ELSE
					SELECT @WasherTagId=1

				INSERT [TCD].WasherTags (EcolabAccountNumber	,WasherTagId		,WasherId		,TagType		,TagAddress		,Active) 
				VALUES					(@EcolabAccountNumber	,@WasherTagId		,@WasherId		,@TagType		,@TagAddress	,1)
			END
	END

SET	@ErrorId	=	@@ERROR
	
IF	(@ErrorId	<>	0)
	BEGIN
			IF	@@TRANCOUNT	>	0
			BEGIN
				ROLLBACK	TRAN
			END

			SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred creating new washer tags. '
			RAISERROR	(@ErrorMessage, 16, 1)
			SET		@ReturnValue	=	-1
			RETURN	(@ReturnValue)
	END
ELSE
	BEGIN
			SET @ConventionalTagId = '101'         
	END
END
