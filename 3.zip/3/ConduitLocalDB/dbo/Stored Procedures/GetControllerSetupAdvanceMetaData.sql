﻿CREATE PROCEDURE [TCD].[GetControllerSetupAdvanceMetaData]
(
		@TabId INT
	,	@ControllerId INT
	,	@EcolabAccountNumber NVARCHAR(25)
 )
AS
SET NOCOUNT ON
BEGIN
    DECLARE @ControllerModelId INT = NULL, 
		@ControllerTypeId INT = NULL, 
		@ControllerVersion NVARCHAR(10) = NULL,
		@ControllerName NVARCHAR(50) = NULL
	SELECT 
			@ControllerModelId = ControllerModelId
		,	@ControllerTypeId = ControllerTypeId
		,	@ControllerName = Name
		,	@ControllerVersion = ControllerVersion 
	FROM 
		[TCD].ConduitController
	WHERE ControllerId = @ControllerId
		AND EcoalabAccountNumber = @EcolabAccountNumber
	SELECT DISTINCT
			@ControllerName AS ControllerName 
		,	FG.Id AS FieldGroupId
		,	FG.[NAME] AS FieldGroupName
		,	FG.[image_Url] as FieldGroupImageUrl
		,	FG.[helpText] as FieldGroupHelpText
		,	FG.[ControllerModelId]
		,	FG.[ControllerTypeId]
		,	FGT.NAME AS FieldGroupTypeName
		,	F.Id AS FieldId
		,	F.Name AS FieldName
		,	FT.Name AS FieldType
		,	F.Label AS FieldLabel
		,	F.[Min] AS FieldMinValue
		,	F.[Max] AS FieldMaxValue
		,	F.IsMandatory AS FieldIsMandatory
		,	F.IsEditable AS FieldIsEditable
		,	F.HelpText AS FieldHelpText
		,	F.HelpTextUrl AS FieldHelpUrl
		,	FG.TabId AS TabIndex
		,	DT.Name AS ControlType
		,	F.DataSourceId AS DataSourceId
		,	(Select 
					FS.Value + ':' + FS.Name + ';' 
				FROM [TCD].FieldSource FS 
				WHERE FS.DataSourceId = F.DataSourceId for xml path('')) AS DataSourceKeyValue
		,	F.DataCategoryId AS DataCategoryId
		,	F.DefaultValue As FieldDefaultValue
		,	F.CurrencyId AS FieldCurrencyCode
		,	F.ResourceKey AS FieldResourceKey
		,	FG.ResourceKey AS FieldGroupResourceKey
		,	FG.DisplayOrder AS FieldGroupDO
		,	F.DisplayOrder AS FieldDO
		,	FRM.RoleId AS AccessToRole
		,	'Add' AS Mode
		,	F.HasFieldTag AS HasFieldTag
		,	F.DefaultFieldTag As TagDefaultValue
		,	F.ClassName As ClassName
		,	@ControllerVersion
		,CAST (0 as bit) IsDosingLineConsumed
	 FROM [TCD].[FieldGroup] FG
		INNER JOIN [TCD].[FieldGroupFieldMapping] AS FGFM ON FG.Id = FGFM.FieldGroupId
		INNER JOIN [TCD].[Field] AS F ON F.Id = FGFM.FieldId
		LEFT JOIN [TCD].[FieldGroupType] AS FGT ON FGT.Id = FG.FieldGroupTypeId
		LEFT JOIN [TCD].FieldType AS FT ON FT.Id = F.TypeId 
		LEFT JOIN [TCD].DataType  AS DT ON DT.Id = F.DataTypeId
		LEFT JOIN [TCD].[FieldRoleMapping] AS FRM ON FRM.FieldId = F.Id
	WHERE FG.TabId = @TabId 
		AND FG.[ControllerModelId] = @ControllerModelId
		AND FG.[ControllerTypeId] = @ControllerTypeId 
		AND F.Label NOT LIKE
			CASE @ControllerModelId
				WHEN 3 THEN 'Automatic Weight Enabled'
				ELSE  ''
			END
		AND F.Label NOT LIKE
			CASE @ControllerModelId
				WHEN 3 THEN  'Ratio Dosing Enabled'
				ELSE    ''
			END
		ORDER BY FG.DisplayOrder , F.DisplayOrder, F.Id 
SET NOCOUNT OFF  
END