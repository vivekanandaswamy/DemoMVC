﻿CREATE PROCEDURE	[TCD].[GetConventionalWasherTagsByWasherId]
					@EcolabAccountNumber			NVARCHAR(25)	=	NULL			
				 ,	@WasherId						INT
AS
BEGIN

SET	NOCOUNT	ON


SELECT	
		WT.WasherTagId					AS			WasherTagId
	,	WT.TagType						AS			TagType
	,	WT.TagAddress					AS			TagAddress
	,	WT.Active						As			Active
FROM [TCD].WasherTags WT
WHERE WasherId = @WasherId
AND	WT.EcolabAccountNumber			=			ISNULL(@EcolabAccountNumber, EcolabAccountNumber)

RETURN	0
END