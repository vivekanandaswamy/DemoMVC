﻿/*

Stored Procedure	:	[TCD].[GetModuleTagsDetails]

Purpose				:	To get tags data related to an entity (module) to form object in service layer for pushing to Synch. component(s)

Parameters			:	@EcolabAccountNumber					--	EcoLab Plant Id
						@ModuleId								--	Id of the module (entity) - e.g. MeterId, SensorId, etc.
						@ModuleTagId							--	Id of the tag data row in ModuleTags - PK
						@ModuleTypeId							--	ID of the type of Module for which data is to retrieved
							
*/

CREATE PROCEDURE [TCD].[GetModuleTagsDetails] @EcolabAccountNumber NVARCHAR(25), 
											  @ModuleId            INT = NULL, 
											  @ModuleTagId         INT = NULL, 
											  @ModuleTypeId        INT = NULL 
AS 
  BEGIN 
	  SET NOCOUNT ON 

	  SELECT MT.EcolabAccountNumber AS EcolabAccountNumber, 
			 MT.ModuleTagId         AS ModuleTagId, 
			 MT.TagType             AS TagType, 
			 MT.TagAddress          AS TagAddress, 
			 MT.ModuleTypeId        AS ModuleTypeId, 
			 MT.ModuleId            AS ModuleId, 
			 MT.DeadBand            AS DeadBand, 
			 MT.Active              As Active 
	  FROM   TCD.ModuleTags MT 
	  WHERE  MT.EcolabAccountNumber = @EcolabAccountNumber 
			 AND MT.ModuleId = ISNULL(@ModuleId, MT.ModuleId) 
			 AND MT.ModuleTagId = ISNULL(@ModuleTagId, MT.ModuleTagId) 
			 AND MT.ModuleTypeId = ISNULL(@ModuleTypeId, MT.ModuleTypeId) 
	  ORDER  BY MT.ModuleTagId DESC 

	  RETURN 0 
  END
