CREATE PROCEDURE [TCD].[GetBatchFormulasByGroupId] 
(
     @GroupId NVARCHAR(1000) = NULL,
     @EcolabAccountNumber nvarchar(25) 
)
AS 
  BEGIN
  SET NOCOUNT ON

    DECLARE @WahsergroupID INT
     ,          @ControllerID INT
     ,          @ControllerModelID INT
	 ,			@IsTunnel INT

      SELECT @WahsergroupID = ms.GroupId 
            ,@ControllerID = ms.ControllerId
			,@IsTunnel = MS.IsTunnel
      FROM tcd.Washer AS w
        INNER JOIN tcd.MachineSetup AS MS ON w.WasherId = ms.WasherId 
        WHERE  w.WasherId = @GroupId
    
        SELECT @ControllerModelID = cc.ControllerModelId 
            FROM   TCD.ConduitController cc 
            WHERE  cc.ControllerId = @ControllerID 
             AND cc.EcoalabAccountNumber = @EcolabAccountNumber 

              IF @IsTunnel = 0 AND @ControllerModelID = 7 -- MyControl   
              BEGIN 
                  SET @WahsergroupID = NULL 
              END 
            
             SELECT DISTINCT 
             PM.ProgramId,
             PM.Name
       FROM   
             [TCD].WasherProgramSetup WP
             INNER JOIN [TCD].ProgramMaster PM ON WP.ProgramId = PM.ProgramId
        WHERE ( CASE 
                           WHEN @WahsergroupID IS NOT NULL THEN WP.WasherGroupId 
                           ELSE WP.ControllerID 
                         END ) = ( CASE 
                                     WHEN @WahsergroupID IS NOT NULL THEN @WahsergroupID 
                                     ELSE @ControllerID 
                                   END )
             AND
             WP.EcolabAccountNumber = @EcolabAccountNumber
        UNION ALL  
             SELECT DISTINCT 
             PM.ProgramId,
             PM.Name
       FROM   
             [TCD].TunnelProgramSetup tps
             INNER JOIN [TCD].ProgramMaster PM ON tps.ProgramId = PM.ProgramId
       WHERE 
             tps.WasherGroupId = @WahsergroupID
             AND
             tps.EcolabAccountNumber = @EcolabAccountNumber
    
    SET NOCOUNT OFF
    END
GO