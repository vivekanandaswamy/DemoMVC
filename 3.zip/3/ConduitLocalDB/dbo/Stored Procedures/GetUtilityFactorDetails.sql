﻿/*  
 ==========================================================================================  
 Purpose:  Fecthing the utility FACTOR details  

 Author:  Santhosh Mahankali

 --------------------------------------------------------------  
 Aug-22-2014 ENT: Initial version.  
 ==========================================================================================  
*/ 


CREATE PROCEDURE [TCD].[GetUtilityFactorDetails]

AS
SET NOCOUNT ON
BEGIN
SELECT	PUE.BolierSteam,
		PUE.BolierType,
		PUE.Steam AS SteamPercentage,
		PUE.Boiler AS BolierPercentage,
		PUE.Stack AS StackPercentage,
		PUE.RewashFactor

FROM [TCD].PlantUtilityEnergyProperties PUE


END