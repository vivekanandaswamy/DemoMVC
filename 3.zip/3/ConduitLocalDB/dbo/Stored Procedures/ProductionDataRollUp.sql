
CREATE PROCEDURE [TCD].[ProductionDataRollUp](@Date DATETIME)   
AS
SET NOCOUNT ON;
BEGIN
--SET @Date = DATEADD(DAY,-1,@Date)
DECLARE @Fromdate Datetime,@Todate Datetime
SET @Fromdate =  dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@Date AS DATE), 112) + ' ' + CONVERT(Varchar(8), CAST(@Date AS TIME)) AS DateTime))
SET @Todate = DATEADD(DAY,1,@Fromdate)


DELETE FROM TCD.ProductionRollUp WHERE RecordDate = CAST(@Date AS date)


    DECLARE @TotalRunTimesec VARCHAR(100) = NULL,
		  --@Hour INT = NULL,
		  @summingActualLoad Decimal(10,2),@StartTime TIME, @EndTime TIME

    --SELECT @StartTime = CAST(BD.StartDate AS TIME) FROM BatchData BD WHERE BD.StartDate = @Date ORDER BY StartDate

    --SELECT @EndTime = CAST(BD.EndDate AS TIME) FROM BatchData BD WHERE BD.EndDate = @Date ORDER BY EndDate DESC

    --SELECT @Hour = DATEDIFF(HOUR,@StartTime,@EndTime)

    --SELECT SUM(WP.TotalRunTime) FROM [TCD].WasherProgramSetup WP WHERE WP.ProgramId = BD.ProgramNumber
			 -- --IN (SELECT DISTINCT BD.ProgramNumber FROM [TCD].BatchData BD WHERE CAST(StartDate AS date) = CAST(@Date AS date))

     							
    --SELECT (SELECT SUM(WP.TotalRunTime) FROM [TCD].WasherProgramSetup WP WHERE WP.ProgramId = BD.ProgramNumber)/ 3600;

    DECLARE @ProdRollUpTable Table(
								RecordDate DATE,
								MachineId INT,
								GroupId INT,
								MachineInternalId INT,								
								ProgramNumber INT,
								TotalActualLoad DECIMAL(10,2),
								TotalStandardLoad DECIMAL(10,2),
								NoOfBatches INT,
								ActualLoadPerHour DECIMAL(10,2),
								TargetLoadPerHour DECIMAL(10,2),
								NumberOfPieces INT,
								LoadEfficiency DECIMAL(10,2),
								TextileCategoryName VARCHAR(100),
								TextileId INT,
								PlantTextileCategoryName VARCHAR(100),
								PlantTextileId INT,
								PlantProgramName VARCHAR(100),
								PlantProgramId INT,
								TotalRunTime Decimal(18,2)
								
							 )

    INSERT INTO @ProdRollUpTable(
								RecordDate ,
								MachineId ,
								GroupId ,
								MachineInternalId ,								
								ProgramNumber ,
								TotalActualLoad,
								TotalStandardLoad ,
								NoOfBatches ,
								ActualLoadPerHour ,
								TargetLoadPerHour ,
								NumberOfPieces ,
								LoadEfficiency ,
								TextileCategoryName ,
								TextileId ,
								PlantTextileCategoryName ,
								PlantTextileId ,
								PlantProgramName ,
								PlantProgramId ,
								TotalRunTime 								
							 )
    
    SELECT 
	   
	   CAST(@Todate AS DATE) as RecordDate,
	   bd.MachineId,
	   bd.GroupId,
	   BD.MachineInternalId,
	   BD.ProgramMasterId,
	   (SUM(BD.[ActualWeight]) + CASE WHEN SUM(BD.ManualInputWeight) IS NULL THEN 0 ELSE SUM(BD.ManualInputWeight) END) as TotalActualLoad,
	   SUM(BD.[StandardWeight]) as TotalStandardLoad,
	   COUNT(BD.BatchID) AS NoOfBatches,

	   ((SUM(BD.[ActualWeight]) + CASE WHEN SUM(BD.ManualInputWeight) IS NULL THEN 0 ELSE SUM(BD.ManualInputWeight) END)/
	   (SELECT CAST(SUM(DATEDIFF(SECOND,BD.StartDate,BD.EndDate)) AS decimal(18,2))/3600)
	   ) as ActualLoadPerHour,
	  (SUM(BD.[StandardWeight])/(SELECT CAST(SUM(DATEDIFF(SECOND,BD.StartDate,BD.EndDate)) AS decimal(18,2))/3600)) as TargetLoadPerHour,
	   SUM(PiecesCount) AS NumberOfPieces,
	   CAST(((SUM(BD.[ActualWeight]) + CASE WHEN SUM(BD.ManualInputWeight) IS NULL THEN 0 ELSE SUM(BD.ManualInputWeight) END) * 100 /SUM(BD.[StandardWeight])) AS decimal(18,2)) AS LoadEfficiency,
	   ETC.CategoryName AS TextileCategoryName,
	   ETC.TextileId,	  
	   CTC.Name,
	   CTC.TextileId AS ChainTextileId,
	   PCP.PlantProgramName,
	   PCP.PlantProgramId,
	   (SELECT (CAST(SUM(DATEDIFF(SECOND,BD.StartDate,BD.EndDate)) AS decimal(18,2)))/3600.00) AS TotalRunTime

	   FROM TCD.BatchData BD 
			  LEFT OUTER JOIN
			  TCD.BatchCustomerData BCD ON BD.BatchID = BCD.BatchId
			  LEFT OUTER JOIN
			  TCD.ProgramMaster PM ON PM.ProgramId = BD.ProgramMasterId
			  LEFT OUTER JOIN
			  TCD.EcolabTextileCategory ETC ON ETC.TextileId = PM.EcolabTextileCategoryId
			   LEFT OUTER JOIN
			  TCD.ChainTextileCategory CTC ON  CTC.TextileId = PM.ChainTextileId
			   LEFT OUTER JOIN
			  TCD.PlantChainProgram PCP ON PCP.PlantProgramId = PM.PlantProgramId
			 WHERE  BD.EndDate  >= @Fromdate
									AND BD.Enddate <= @Todate
	   GROUP BY BD.MachineId,BD.GroupId,BD.MachineInternalId,BD.ProgramMasterId,ETC.CategoryName,ETC.TextileId,
	    CTC.Name,CTC.TextileId,PCP.PlantProgramName,PCP.PlantProgramId

	 

SELECT @summingActualLoad = SUM(TotalActualLoad)  FROM @ProdRollUpTable
GROUP BY RecordDate


INSERT INTO TCD.ProductionRollUp(
			 [RecordDate]  ,
	[MachineId]  ,
	[GroupId]  ,
	[MachineInternalId] ,
	[ProgramNumber]  ,
	[TotalActualLoad]  ,
	[TotalStandardLoad]  ,
	[NoOfBatches]  ,
	[ActualLoadPerHour]  ,
	[TargetLoadPerHour]  ,
	[NumberOfPieces]  ,
	[LoadEfficiency] ,
	[EcolabTextileCategoryName]  ,
	[EcolabTextileId]  ,
	[PlantTextileCategoryName] ,
	[PlantTextileId]  ,
	[PlantProgramName] ,
	[PlantProgramId]  ,
	[ProductionMix] ,
	[Rewash] ,
	[TotalRunTime] 
	)
SELECT 
	   DISTINCT
		  PRT.RecordDate,
		  prt.MachineId,
		  PRT.GroupId,
		  PRT.MachineInternalId,
		  PRT.ProgramNumber,
		  PRT.TotalActualLoad,
		  PRT.TotalStandardLoad,
		  PRT.NoOfBatches,
		  PRT.ActualLoadPerHour,
		  PRT.TargetLoadPerHour,
	   	  PRT.NumberOfPieces,
	       PRT.LoadEfficiency,
		  PRT.TextileCategoryName,
		  PRT.TextileId,
		  PRT.PlantTextileCategoryName,
		  PRT.PlantTextileId,
		  PRT.PlantProgramName,
		  PRT.PlantProgramId,
		  CAST((PRT.TotalActualLoad * 100 /@summingActualLoad) AS decimal(18,2)) AS ProductionMix,
		  CAST(((SELECT SUM(MR.VALUE) FROM TCD.ManualRewash MR WHERE PRT.ProgramNumber = MR.FormulaId AND CAST(PRT.RecordDate AS date) = CAST(MR.RecordedDate AS date) GROUP BY CAST(MR.RecordedDate AS date),MR.FormulaId) * 100 /PRT.TotalActualLoad) AS decimal(18,2)) AS Rewash,
		   CAST(TotalRunTime AS decimal(18,2)) AS TotalRunTime
	   FROM @ProdRollUpTable PRT



SET NOCOUNT OFF
END