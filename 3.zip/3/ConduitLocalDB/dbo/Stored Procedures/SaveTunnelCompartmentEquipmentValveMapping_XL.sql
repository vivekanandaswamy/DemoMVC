﻿CREATE PROC [TCD].[SaveTunnelCompartmentEquipmentValveMapping_XL] (    
  @ValveCompartmentMappings TCD.TunnelCompartmentEquipmentValveMapping READONLY    
    , @ControllerEquipmentId INT    
    , @ControllerId INT      
    , @EcolabAccountNumber NVARCHAR(25)    
    , @UserId INT    
)    
AS    
BEGIN    
    DECLARE    
     @EquipmentSetupId INT = (SELECT TOP 1 CES.ControllerEquipmentSetupId    
        FROM TCD.ControllerEquipmentSetup CES    
        WHERE CES.ControllerId = @ControllerId    
          AND CES.ControllerEquipmentId = @ControllerEquipmentId ),    
     @PlantId INT = (SELECT TOP 1 PlantId    
  FROM TCD.Plant P    
       WHERE P.EcolabAccountNumber = @EcolabAccountNumber),  
     @DDFlag BIT = CAST(    
     CASE    
     WHEN EXISTS(SELECT 1    
       FROM @ValveCompartmentMappings M    
       WHERE M.DirectDosingFlag = 1) THEN 1    
     ELSE 0    
     END    
     AS BIT);    
    
    /* Delete the values if not necessary */    
    
    IF @DDFlag = 'TRUE'    
    BEGIN    
    DELETE FROM TCD.TunnelCompartmentEquipmentValveMapping    
      WHERE ControllerEquipmentSetupID = @EquipmentSetupId    
    AND DirectDosingFlag = 'FALSE';    
    END;    
    ELSE    
    BEGIN    
    DELETE T    
      FROM TCD.TunnelCompartmentEquipmentValveMapping T    
      WHERE ControllerEquipmentSetupID = @EquipmentSetupId    
    AND T.PlantID = @PlantId    
    AND T.TunnelCompartmentEquipmentValveMappingID NOT IN(    
    SELECT TCEVM.TunnelCompartmentEquipmentValveMappingID    
      FROM TCD.TunnelCompartmentEquipmentValveMapping TCEVM    
       INNER JOIN    
       @ValveCompartmentMappings M ON TCEVM.TunnelNumber = M.TunnelNumber    
             AND TCEVM.DosingPointNumber = M.DosingPointNumber  
			 AND TCEVM.ValveNumber = M.ValveNumber    
             AND TCEVM.ControllerEquipmentSetupID = @EquipmentSetupId    
             AND TCEVM.PlantID = @PlantId);    
    END;   
       
    DECLARE    
     @TempMapping TABLE(    
     RowNumber INT NOT NULL    
   , ControllerEquipmentId TINYINT NOT NULL    
   , TunnelNumber INT NOT NULL    
   , CompartmentNumber TINYINT NOT NULL    
   , DosingPointNumber TINYINT NOT NULL    
   , DirectDosingFlag BIT NOT NULL  
   , ValveNumber TINYINT NOT NULL
   , WasherNumber int NOT NULL);    
    
    /* Create RowNumber inorder to increment and use row by row. */    
    
    WITH CTE_LCM    
    AS (    
    SELECT ROW_NUMBER() OVER (ORDER BY LCM.TunnelNumber, LCM.DosingPointNumber) AS RowNumber    
     , LCM.ControllerEquipmentId  
     , LCM.TunnelNumber  
     , LCM.CompartmentNumber  
     , LCM.DosingPointNumber  
     , LCM.DirectDosingFlag  
     , LCM.ValveNumber  
	 , LCM.WasherNumber
  FROM @ValveCompartmentMappings LCM    
    )    
    INSERT INTO @TempMapping    
    SELECT *    
  FROM CTE_LCM CL;    
    
    /* Loop */    
    
    DECLARE    
     @i INT = 1,    
     @max INT = (SELECT MAX(TM.RowNumber)    
       FROM @TempMapping TM);    
    WHILE @i <= @max    
    BEGIN    
    
    /* Declare and Initialize the current row data */    
    
    DECLARE    
     @TunnelNumber INT,    
     @CompartmentNumber TINYINT,    
     --@DosingpointNumber TINYINT,   
     @ValveNumber TINYINT;  
    SELECT TOP 1 @TunnelNumber = TM.TunnelNumber    
       --, @DosingPointNumber = TM.DosingpointNumber    
       , @CompartmentNumber = TM.CompartmentNumber    
       , @ValveNumber       = TM.ValveNumber  
      FROM @TempMapping TM    
      WHERE TM.RowNumber = @i;    
    --DECLARE    
    -- @ValveNumber INT = 0;    
    --IF @DDFlag = 'FALSE'    
    --BEGIN    
    
    --/* Get Min Available Valve Number */    
    
    --SELECT @ValveNumber = MIN(CEV.ControllerEquipmentValveID)    
    --  FROM TCD.ControllerEquipmentValves CEV    
    --  WHERE ControllerEquipmentValveID <> 0    
    --    AND CEV.ControllerEquipmentValveID  NOT IN (    
    --    SELECT TCEVM.ValveNumber    
    --  FROM TCD.TunnelCompartmentEquipmentValveMapping TCEVM    
    --   JOIN    
    --   TCD.ControllerEquipmentSetup CES ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupID    
    --  WHERE CES.ControllerID = @ControllerId    
    --    AND TCEVM.TunnelNumber = @TunnelNumber);    
    --END;    
    --PRINT @ValveNumber;    
    
    /* Update If Exists else Insert */    
    
    MERGE TCD.TunnelCompartmentEquipmentValveMapping T    
    USING (SELECT TOP 1 *    
     FROM @TempMapping TM    
     WHERE TM.RowNumber = @i) S    
    ON T.ControllerEquipmentSetupID = @EquipmentSetupId    
   --AND T.CompartmentNumber = S.CompartmentNumber    
   AND T.ValveNumber = S.ValveNumber    
    WHEN MATCHED    
      THEN    
      UPDATE SET --T.TunnelNumber = S.TunnelNumber             
        T.CompartmentNumber = S.CompartmentNumber  
       , T.DirectDosingFlag = S.DirectDosingFlag  
       --, T.ValveNumber =  S.ValveNumber  
          
    WHEN NOT MATCHED    
      THEN    
      INSERT (PlantID    
        , ControllerEquipmentSetupID    
        , TunnelNumber    
        , DosingPointNumber    
        , ValveNumber    
        , CompartmentNumber    
        , DirectDosingFlag    
        , LastModifiedByUserID)    
      VALUES (@PlantId,    
      @EquipmentSetupId,    
      S.TunnelNumber,    
      S.DosingPointNumber,    
      S.ValveNumber,    
      S.CompartmentNumber,    
      S.DirectDosingFlag,    
      @UserId);    
    
    /* Increment the row */    
    
    SET @i = @i + 1;    
    END;    
END;