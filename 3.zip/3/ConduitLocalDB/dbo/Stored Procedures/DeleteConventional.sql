﻿/*	
Purpose					:	To delete a Conventional Washer from the Washers grid UI
History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version
*/

CREATE	PROCEDURE	[TCD].[DeleteConventional](
@EcoLabAccountNumber	NVARCHAR(25)
,@WasherId	INT
,@UserId	INT
,@LastModifiedTimestampAtCentral DATETIME =	NULL
,@OutputLastModifiedTimestampAtLocal DATETIME =	NULL OUTPUT)
AS
BEGIN
SET	NOCOUNT	ON
DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()
	,	@WashgroupId					INT				=			NULL
	,	@ControllerId					INT				=			NULL
	,	@ControllerModelId				INT				=			NULL

DECLARE @OutputList AS	TABLE ( LastModifiedTimestamp DATETIME )

SET		@OutputLastModifiedTimestampAtLocal	 =	 ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight


--Valid Washer - Id & Type...
IF	NOT	EXISTS	(	SELECT	1
					FROM	[TCD].Washer						W
					JOIN	[TCD].MachineSetup					MS
						ON	W.WasherId					=			MS.WasherId
						AND	W.EcoLabAccountNumber		=			MS.EcoalabAccountNumber
					WHERE	W.EcoLabAccountNumber		=			@EcoLabAccountNumber
						AND	W.WasherId					=			@WasherId
						AND	W.Is_Deleted				=			'FALSE'
						AND	MS.IsDeleted				=			'FALSE'
				)
			BEGIN
				SET		@ErrorId						=			51007
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Washer-ID or Type was provided.'
				RAISERROR	(@ErrorMessage, 16, 1)
				SET		@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


IF	( @LastModifiedTimestampAtCentral IS NOT NULL
			AND NOT	EXISTS	( SELECT	1 FROM	TCD.Washer W
								WHERE	W.EcolabAccountNumber	=	@EcolabAccountNumber AND	W.WasherId	 =	@WasherId
								AND	W.LastModifiedTime = @LastModifiedTimestampAtCentral )
				)
		BEGIN
				SET			@ErrorId				=	60000
				SET			@ErrorMessage			=	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
				RAISERROR	(@ErrorMessage, 16, 1)
				SET			@ReturnValue			=	-1
				RETURN		(@ReturnValue)
		END


--if valid, attempt to delete now...

--we will need tran, b'coz the data is spread across 2 tables...
BEGIN	TRAN

UPDATE	W
	SET	W.Is_Deleted			=			'TRUE'
	,	W.LastModifiedByUserId	=			@UserId
	,	W.LastModifiedTime		=			@CurrentUTCTime
OUTPUT 	inserted.LastModifiedTime AS LastModifiedTimestamp INTO	@OutputList	(LastModifiedTimestamp)
FROM	[TCD].Washer W
		JOIN [TCD].MachineSetup	MS ON W.WasherId = MS.WasherId 	AND	W.EcoLabAccountNumber	=	MS.EcoalabAccountNumber
WHERE	W.EcoLabAccountNumber	=	@EcoLabAccountNumber
		AND	W.WasherId	=	@WasherId
		AND	W.Is_Deleted = 'FALSE'
		AND	MS.IsDeleted = 'FALSE'
--check for any error
SET		@ErrorId				=			@@ERROR

--if any error, abort...
IF	(@ErrorId	<>	0)
	BEGIN
		--Rollback, if in tran
		IF	(@@TRANCOUNT	>	0)
			BEGIN
				ROLLBACK	TRAN
			END

		--Error-out...
		SET		@ErrorMessage=N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred deleting washer data.'
		RAISERROR	(@ErrorMessage, 16, 1)
		SET		@ReturnValue	=	-1
		RETURN	(@ReturnValue)
	END
--else, continue with the deletion in the 2nd table...

UPDATE	MS 	SET	MS.IsDeleted = 'TRUE'
	,	MS.LastModifiedByUserId	= @UserId
FROM	[TCD].MachineSetup	 MS
JOIN	[TCD].Washer W  ON	MS.WasherId	= W.WasherId AND MS.EcoalabAccountNumber	=	W.EcoLabAccountNumber
WHERE	MS.WasherId = @WasherId
	AND	MS.EcoalabAccountNumber	= @EcoLabAccountNumber
	AND	MS.IsDeleted = 'FALSE'
	AND	W.Is_Deleted = 'TRUE'

SELECT @WashgroupId = MS.GroupId,@ControllerId = MS.ControllerId FROM TCD.MachineSetup AS MS WHERE MS.WasherId = @WasherId AND MS.EcoalabAccountNumber = @EcoLabAccountNumber
EXEC [TCD].[SaveInjectionDetails] @WashgroupId,@WashgroupId,@ControllerId,@WasherId, @EcoLabAccountNumber

SELECT @ControllerModelId = cmctm.ControllerModelId 
FROM TCD.ControllerModelControllerTypeMapping cmctm 
INNER JOIN TCD.ConduitController cc 
	ON cc.ControllerModelId = cmctm.ControllerModelId
WHERE cc.ControllerId = @ControllerId AND cc.EcoalabAccountNumber = @EcoLabAccountNumber

-- Removing Tags Associated to it
UPDATE TCD.WasherTags SET  Active =	0 WHERE  WasherId =	@WasherId

UPDATE A SET Is_Deleted =1
			,LastModifiedByUserId=@UserId
			,LastModifiedTime=@CurrentUTCTime
 FROM tcd.WasherFlushTime A
 WHERE WasherId=@WasherId

  UPDATE A SET Is_Deleted =1
   ,LastModifiedByUserId=@UserId
   ,LastModifiedTime=@CurrentUTCTime
 FROM tcd.WasherTimeOutMachine A
 WHERE WasherId=@WasherId
 --Update Reference Load

UPDATE TCD.Injection
SET Is_Deleted = 1 -- bit
, ReferenceLoad = NULL
WHERE WasherId=@WasherId
AND EcolabAccountNumber = @EcoLabAccountNumber 

DECLARE @MaxLoad int ,@WasherGroupNumber varchar(10)

SELECT @MaxLoad = MAX(w.MaxLoad) FROM TCD.Washer w
INNER JOIN TCD.MachineSetup ms 
ON ms.WasherId = w.WasherId 
AND ms.IsDeleted = w.Is_Deleted
AND ms.EcoalabAccountNumber = w.EcoLabAccountNumber
WHERE ms.GroupId = @WashgroupId
AND ms.IsDeleted = 0
AND ms.EcoalabAccountNumber = @EcoLabAccountNumber


SELECT @WasherGroupNumber=wg.WasherGroupNumber FROM TCD.WasherGroup wg 
JOIN TCD.MachineSetup ms ON ms.GroupId=wg.WasherGroupId
AND ms.EcoalabAccountNumber = wg.EcolabAccountNumber
WHERE ms.WasherId=@WasherId AND ms.EcoalabAccountNumber = @EcoLabAccountNumber

UPDATE TCD.Injection
SET ReferenceLoad = @MaxLoad -- bit
WHERE WasherGroupNumber=@WasherGroupNumber AND Is_Deleted=0 AND EcolabAccountNumber = @EcoLabAccountNumber

--check for any error
SET @ErrorId = @@ERROR

--if any error, abort, else COMMIT the work...
IF	(@ErrorId	<>	0)
	BEGIN
		--Rollback, if in tran
		IF	(@@TRANCOUNT	>	0)
			BEGIN
				ROLLBACK	TRAN
			END

		--Error-out...
		SET		@ErrorMessage =			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred deleting washer data.'
		RAISERROR	(@ErrorMessage, 16, 1)
		SET		@ReturnValue	=	-1
		RETURN	(@ReturnValue)
	END
--else, continue with the deletion in the 2nd table...
ELSE
	BEGIN
		--COMMIT, if in tran
		IF	(@@TRANCOUNT	>	0)
			BEGIN
				COMMIT
			END

			SELECT	TOP 1 @OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp FROM @OutputList O
	END

IF	(@ErrorId	=	0)
	BEGIN
		IF (@ControllerModelId = 7)
			BEGIN
				UPDATE TCD.WasherGroup SET ControllerId = NULL WHERE WasherGroupId = @WashgroupId
			END 
		RETURN	(@ReturnValue)
		
	END

SET	NOCOUNT	OFF
RETURN	(@ReturnValue)
END