﻿/*	
Purpose					:	To Fetch Batch eject Conditions

*/
CREATE PROCEDURE TCD.[GetBatchEjectConditionData]
(
	@ControllerModelId INT,
	@MachineId INT,
	@Userid INT,	
	@EcolabAccNo NVARCHAR(25)
)
AS
BEGIN
	
	DECLARE @PlantId INT;
	SET @PlantId =	(SELECT PlantId 
					FROM TCD.Plant 
					WHERE EcolabAccountNumber = @EcolabAccNo);

	SELECT 
	BEC.BatchEjectConditionId AS BatchEjectConditionId,	
	BEC.ControllerModelId AS [ControllerModelId],
	BEc.Description AS [Description],
	CASE WHEN BECS.BatchEjectConditionId IS NULL THEN CAST (0 AS BIT) ELSE CAST (1 AS BIT) END AS [Active], 	
	BECS.LastModifiedTime
	FROM TCD.BatchEjectCondition BEC
	LEFT JOIN TCD.BatchEjectConditionStatus BECS ON BEC.BatchEjectConditionId = BECS.BatchEjectConditionId AND BECS.MachineId = @MachineId AND PlantId = @PlantId
	WHERE BEC.ControllerModelId = @ControllerModelId;
END 	
