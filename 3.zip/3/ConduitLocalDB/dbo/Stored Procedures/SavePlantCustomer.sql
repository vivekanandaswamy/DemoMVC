﻿  
/*      
 ==========================================================================================    
 Purpose:  insert or delete the Customers .      
  
 Author:  Premchand Yelavarthi      
  
 --------------------------------------------------------------      
 Dec-12-2014 ENT: Initial version.      
 ==========================================================================================    
*/   

CREATE PROCEDURE [TCD].[SavePlantCustomer] 
				@ID											INT						=	NULL
				,@EcolabAccountNumber						NVARCHAR(25)		
				,@Customer_ID								INT						=	NULL
				,@Customer_Name								NVARCHAR(1000)			=	NULL
				,@UserID									INT						=	NULL
				,@Scope										VARCHAR(100)						OUTPUT   
				,@OutputPlantCustomerId						INT						=	NULL	OUTPUT
				,@LastModifiedTimestampAtCentral			DATETIME				=	NULL
				,@OutputLastModifiedTimestampAtLocal		DATETIME				=	NULL	OUTPUT
AS   
BEGIN   
	SET NOCOUNT ON;   

	DECLARE	
		@Output							VARCHAR(100)	=			''  
	,	@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()

	DECLARE
			@OutputList						AS	TABLE		(
			PlantCustomerId					INT
		,	LastModifiedTimestamp			DATETIME
		)

	SET		@Scope			=			ISNULL(@Scope, NULL)			--SQLEnlight	SA0121
	SET		@OutputPlantCustomerId			=			ISNULL(@OutputPlantCustomerId, NULL)			--SQLEnlight	SA0121
	SET		@OutputLastModifiedTimestampAtLocal			=			ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight	SA0121


	IF NOT EXISTS (SELECT 1 FROM [TCD].PlantCustomer WHERE  Id = @ID AND EcolabAccountNumber = @EcolabAccountNumber AND Is_Deleted = 0 )   
		BEGIN
			IF EXISTS(SELECT 1 FROM [TCD].PlantCustomer WHERE CustomerId = @Customer_ID AND EcolabAccountNumber = @EcolabAccountNumber AND Is_Deleted = 0) 
				BEGIN 
					SET @OutPut = '301'   
					SET @Scope = @OutPut SELECT @Scope  
					RAISERROR ('Customer already exist', 16, 1)
				END  
			ELSE  
				BEGIN
					IF EXISTS(SELECT 1 FROM [TCD].PlantCustomer WHERE CustomerId = @Customer_ID AND Is_Deleted = 1  AND EcolabAccountNumber = @EcolabAccountNumber) 
						BEGIN 
							
							IF	(
									@LastModifiedTimestampAtCentral				IS NOT	NULL
									AND
									NOT	EXISTS	(	SELECT	1
											FROM	TCD.PlantCustomer		PC
											WHERE	PC.EcolabAccountNumber	=	@EcolabAccountNumber
												AND	PC.ID					=	@Id
												AND	PC.LastModifiedTime		=	@LastModifiedTimestampAtCentral
										)
							)
								BEGIN
										SET			@ErrorId				=	60000
										SET			@ErrorMessage			=	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
										RAISERROR	(@ErrorMessage, 16, 1)
										SET			@ReturnValue			=	-1
										RETURN		(@ReturnValue)
								END
							
							
							UPDATE P   
								SET    
									P.CustomerName = @Customer_Name  
									,P.CustomerId = @Customer_ID 
									,P.LastModifiedByUserId	= @UserID	
									,P.LastModifiedTime =	@CurrentUTCTime
									,P.Is_Deleted = 0	  
							OUTPUT
								inserted.ID						AS			Id
							,	inserted.LastModifiedTime		AS			LastModifiedTimestamp
							INTO
								@OutputList	(
								PlantCustomerId
							,	LastModifiedTimestamp
							)
							FROM [TCD].PlantCustomer P   
							WHERE 
							CustomerId = @Customer_ID
							AND 
							EcolabAccountNumber = @EcolabAccountNumber  
						END  
					ELSE 
						BEGIN
							INSERT INTO [TCD].PlantCustomer   
										(
											CustomerId
											,CustomerName
											,EcolabAccountNumber
											,LastModifiedByUserId
										)
							OUTPUT
								inserted.ID						AS			Id
							,	inserted.LastModifiedTime		AS			LastModifiedTimestamp
							INTO
								@OutputList	(
								PlantCustomerId
							,	LastModifiedTimestamp
							)   
							VALUES      (
											@Customer_ID
											, @Customer_Name
											, @EcolabAccountNumber
											, @UserID
										)   
						END
           
				END
		END   
    ELSE   
		BEGIN
			IF	(
						@LastModifiedTimestampAtCentral				IS NOT	NULL
						AND
						NOT	EXISTS	(	SELECT	1
								FROM	TCD.PlantCustomer		PC
								WHERE	PC.EcolabAccountNumber	=	@EcolabAccountNumber
									AND	PC.ID					=	@Id
									AND	PC.LastModifiedTime		=	@LastModifiedTimestampAtCentral
							)
				)
					BEGIN
							SET			@ErrorId				=	60000
							SET			@ErrorMessage			=	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
							RAISERROR	(@ErrorMessage, 16, 1)
							SET			@ReturnValue			=	-1
							RETURN		(@ReturnValue)
					END
			
			IF EXISTS(SELECT 1 FROM [TCD].PlantCustomer WHERE CustomerId = @Customer_ID AND Is_Deleted = 0  AND EcolabAccountNumber = @EcolabAccountNumber AND Id <> @ID) 
				BEGIN 
					SET @OutPut = '301'   
					SET @Scope = @OutPut SELECT @Scope  
					RAISERROR ('Customer already exist', 16, 1)
				END  
				ELSE
				BEGIN

					UPDATE P   
					SET    
						P.CustomerName = @Customer_Name
						,P.CustomerId = @Customer_ID 
						,P.LastModifiedByUserId	= @UserID
						,P.LastModifiedTime =	@CurrentUTCTime		  
				
					OUTPUT
									inserted.ID						AS			Id
								,	inserted.LastModifiedTime		AS			LastModifiedTimestamp
								INTO
									@OutputList	(
									PlantCustomerId
								,	LastModifiedTimestamp
								)
					FROM   [TCD].PlantCustomer P   
					WHERE  
					Id = @ID   
					AND
					EcolabAccountNumber = @EcolabAccountNumber  

				END

		END
	SELECT	TOP 1	
		@OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp
	,	@OutputPlantCustomerId				=	O.PlantCustomerId
	FROM	@OutputList							O


	RETURN	(@ReturnValue)
  
	--SET NOCOUNT OFF; 
END  

  /* TEST CASES 
      
  SELECT * FROM AUDITCOLUMNS

  SELECT * FROM AUDITCOLUMNSDETAILS_NEW

  SELECT * FROM PLANTCUSTOMER ORDER BY ID

  [dbo].[usp_savePlantcustomer] NULL,555,'PREMCHAND',1,NULL

  DELETE FROM PLANTCUSTOMER WHERE CUSTOMERID = 555

  */ 