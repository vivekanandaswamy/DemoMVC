﻿/*      
 ==========================================================================================      
 Purpose:  UPDATING THE  SHIFT DATA  

 Author: Premchand Yelavarthi
 Updated By: Neetha Allati
 Changes:
 ** Added Case statements, to avoid to get break details when it was deleted.
    
 --------------------------------------------------------------      
 Sep-08-2014 ENT: Initial version.      
 ==========================================================================================   
*/
CREATE PROCEDURE [TCD].[GetShiftData](@ShiftId Int = Null, @DayId Int = Null, @EcolabAccountNumber NVarchar(25))
AS
SET NOCOUNT ON;
BEGIN


SELECT
		SD.EcolabAccountNumber  
		,SD.ShiftId  
		,ShiftName = (SELECT S.ShiftName FROM [TCD].Shift S WHERE S.ShiftId = SD.ShiftId)  
		,SD.DayId  
		,DayName = (SELECT W.DayName FROM [TCD].WeekDay W WHERE W.DayId = SD.DayId)  
		,ShiftStartTime = SD.StartTime  
		,ShiftEndTime = SD.EndTime  
		,CASE  WHEN SBD.IS_Deleted = 0 THEN SBD.BreakId WHEN SBD.IS_Deleted = 1 THEN Null End As BreakId  
		,CASE  WHEN SBD.IS_Deleted = 0 THEN SBD.ShiftId WHEN SBD.IS_Deleted = 1 THEN Null End As BreakShiftId  
		,CASE  WHEN SBD.IS_Deleted = 0 THEN SBD.DayId WHEN SBD.IS_Deleted = 1 THEN Null End As  BreakDayId  
		,CASE  WHEN SBD.IS_Deleted = 0 THEN SBD.StartTime WHEN SBD.IS_Deleted = 1 THEN Null End As  BreakStartTime  
		,CASE  WHEN SBD.IS_Deleted = 0 THEN SBD.EndTime WHEN SBD.IS_Deleted = 1 THEN Null End As  BreakEndTime  
		,SD.TargetProduction
		,SD.TargetProduction_Display     
		FROM [TCD].ShiftData SD  
		INNER JOIN   
		[TCD].ShiftBreakData SBD ON SD.ShiftId = SBD.ShiftId AND SD.DayId = SBD.DayId      
		INNER JOIN
		TCD.[Shift]					S	ON
		SD.ShiftId					=			S.ShiftId
		WHERE        
		SD.EcolabAccountNumber = @EcolabAccountNumber AND SD.Is_Deleted = 0 AND  
		CASE IsNull(@ShiftId,'') WHEN '' THEN 'true'   
	   WHEN @ShiftId THEN CASE WHEN  SD.ShiftId = @ShiftId THEN 'true' END END = 'true' AND  
		CASE IsNull(@DayId,'') WHEN '' THEN 'true' WHEN @DayId THEN CASE WHEN  SD.DayId = @DayId THEN 'true' END  
		END = 'true'  
END