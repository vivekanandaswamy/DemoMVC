﻿/*	
Stored Procedure	:	[TCD].[GetTunnelPressExtractor]	in	TRASAR3 Db... for use in disconnected scenario

Purpose				:	To populate the drop-down (Press/Extractor) in the Washer setup --> Tunnel-General tab. No changes reqd. in Central

Parameters			:	None

*/
CREATE	PROCEDURE	[TCD].[GetTunnelPressExtractor]
(
	@EcolabAccNumber NVARCHAR (25) = NULL
)
AS
BEGIN

SET	NOCOUNT	ON

DECLARE @RegionId	INT	
SELECT @RegionId = RegionId FROM TCD.PLANT WHERE EcolabAccountNumber = @EcolabAccNumber

SELECT	TPE.Name							AS			Name
	,	CAST(TPE.TunnelPressExtractorId	AS INT)
											AS			Id
FROM	[TCD].TunnelPressExtractor			TPE
WHERE	TPE.Is_Deleted						=			'FALSE'
AND		TPE.RegionId						=			@RegionId

SET	NOCOUNT	OFF

END
