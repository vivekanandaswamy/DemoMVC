﻿CREATE PROCEDURE [TCD].[GetResourceKeyValuesForUom]
                     (
                       @EcolabAccountNumber Nvarchar(25) = NULL,
                       @UserId Int = NULL
                     )   
AS
SET NOCOUNT ON
BEGIN
DECLARE @UOM Int,@LanguageId Int,@CurrencyCode Varchar(20), @CurrencySymbol nvarchar(10) ='$'
SELECT @UOM = UOMId FROM TCD.Plant WHERE EcolabAccountNumber = @EcolabAccountNumber 
SELECT @CurrencyCode = P.CurrencyCode FROM TCD.PLANT P WHERE EcolabAccountNumber = @EcolabAccountNumber
SELECT @LanguageId = ISNULL((SELECT LanguageId FROM TCD.Plant where EcolabAccountNumber = @EcolabAccountNumber), UM.LanguageId) FROM TCD.UserMaster UM
                    WHERE UM.UserId = @UserId AND EcolabAccountNumber = @EcolabAccountNumber
SELECT TOP(1) @CurrencySymbol = cs.CurrencySymbol  FROM TCD.CurrencySymbol cs WHERE cs.CurrencyCode = ( SELECT TOP(1) p.CurrencyCode FROM TCD.Plant p WHERE p.EcolabAccountNumber = @EcolabAccountNumber)

DECLARE @UnitSystem TABLE
                    (
                       UnitSystemId INT,
                       Unit NVARCHAR(200) ,
                       Subunit NVARCHAR(200),
                       UsageKey NVARCHAR(200),
                       [KeyName] NVARCHAR(200),
                       Value NVARCHAR(800),
                       languageID INT
                    )

INSERT INTO @UnitSystem
  SELECT  UnitSystemId, Unit, Subunit,  UsageKey,RKM.[KeyName],ISNULL(RKV.Value,RKVEn.Value) as Value,ISNULL(RKV.languageID,RKVEn.languageID) as LanguageId
  FROM TCD.DimensionalUnitsDefaults DM
  LEFT OUTER JOIN TCD.ResourceKeyMaster RKM ON DM.Subunit = RKM.[KeyName]
  LEFT OUTER JOIN TCD.ResourceKeyValue RKV ON RKM.KeyName = RKV.KeyName AND RKV.languageID = @LanguageId 
  LEFT OUTER JOIN TCD.ResourceKeyValue RKVEn ON RKM.KeyName = RKVEn.KeyName AND RKVEn.languageID = 1
  WHERE UnitSystemId = @UOM and ISNULL(RKV.languageID,RKVEn.languageID) is not null 
      
SELECT 
                      UnitSystemId ,
                       Unit  ,
                       Subunit,
                       UsageKey,
                       [KeyName] ,
                       REPLACE(Value ,'#currency#', @CurrencySymbol),
                       languageID 
                        FROM @UnitSystem
END
GO