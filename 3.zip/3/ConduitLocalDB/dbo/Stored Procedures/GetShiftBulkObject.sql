﻿/*

Stored Procedure	:	[TCD].[GetShiftBulkObject]

Purpose				:	To get shift related data to form object in service layer for pushing to Synch. component(s)

Parameters			:	@EcolabAccountNumber					--	EcoLab Plant Id
						@ShiftId								--	Shift Id of the shift for which details to be retrieved
							
*/

CREATE	PROCEDURE	[TCD].[GetShiftBulkObject]
					@EcolabAccountNumber					NVARCHAR(25)
				,	@ShiftId								INT
AS
BEGIN

SET	NOCOUNT	ON


SELECT	
	--Shift attributes
		S.EcolabAccountNumber		AS			EcolabAccountNumber
	,	S.ShiftId					AS			ShiftId
	,	S.ShiftName					AS			ShiftName
	,	S.Is_Deleted				AS			Is_Deleted
	,	S.LastModifiedTime			AS			LastModifiedTime
	--ShiftData attributes (pre-fixed with 'SD_'	)
	,	SD.DayId					AS			SD_DayId
	,	SD.StartTime				AS			SD_StartTime
	,	SD.EndTime					AS			SD_EndTime
	,	SD.TargetProduction			AS			SD_TargetProduction	
	,	SD.Is_Deleted				AS			SD_Is_Deleted	
	,	SD.TargetProduction_Display			AS			SD_TargetProduction_Display
	--ShiftBreakData attributes (pre-fixed with 'SBD_'	)
	,	SBD.BreakId					AS			SBD_BreakId
	,	SBD.StartTime				AS			SBD_StartTime
	,	SBD.EndTime					AS			SBD_EndTime
	,	SBD.IS_Deleted				AS			SBD_Is_Deleted
	,	SBD.ID						AS			SBD_Id

FROM	TCD.[Shift]					S
LEFT OUTER JOIN
		TCD.ShiftData				SD
	ON	S.EcolabAccountNumber		=			SD.EcolabAccountNumber
	AND	S.ShiftId					=			SD.ShiftId
LEFT OUTER JOIN
		TCD.ShiftBreakData			SBD
	ON	SD.EcolabAccountNumber		=			SBD.EcolabAccountNumber
	AND	SD.ShiftId					=			SBD.ShiftId
	AND	SD.DayId					=			SBD.DayId
WHERE	S.EcolabAccountNumber		=			@EcolabAccountNumber
	AND	S.ShiftId					=			@ShiftId


RETURN 0


END