
CREATE PROCEDURE [TCD].[SavePLCParameterValues]
(	@xml XML
	,@tableName VARCHAR(200)
)

AS

BEGIN
SET NOCOUNT ON
-- Internal Variables
DECLARE @SQLQuery AS NVARCHAR(500) = NULL
,@TableColumns varchar(2000) = NULL

--Check to see if the table already exists. Drop if present
	IF EXISTS (SELECT  * FROM TEMPDB.DBO.SYSOBJECTS o where o.xtype in ('U') AND o.id = OBJECT_ID(N'tempdb..#TagsTable'))
	BEGIN
		 DROP TABLE #TagsTable
	END

--Create Temporary table. This will be used to fill the target tables
	CREATE TABLE  #TagsTable (TagName VARCHAR(200), TagValue VARCHAR(100), ReceivedTime DATETIME)

	SELECT @tableName =   T.c.value('@TableName', 'varchar(100)')
		FROM @xml.nodes('Tables/*') T(c)
		WHERE T.c.value('@TableName', 'varchar(100)') IS NOT NULL

	INSERT INTO #TagsTable(TagName,TagValue,ReceivedTime)
	SELECT 
		T.c.value('@Id', 'INT')
		,T.c.value('@Value', 'varchar(100)')
		,GETDATE()
		FROM @xml.nodes('Tables/Table/*') T(c)
		WHERE T.c.value('@Id', 'varchar(100)')  IS NOT NULL
	
/* Build Transact-SQL String with parameter value */
	SELECT @TableColumns  =  '(' +
			SUBSTRING(
				(SELECT ',' + SC.name 
					FROM SYS.OBJECTS SO
					INNER JOIN SYS.COLUMNS SC  ON SC.object_id = so.object_id
					WHERE SO.name = @tableName AND sc.is_identity = 0
					FOR XML PATH('')),2,200000) + ')'
		FROM SYS.OBJECTS SO
		INNER JOIN SYS.COLUMNS SC  ON SC.object_id = so.object_id
		WHERE SO.name = @tableName AND sc.is_identity = 0

	SET @SQLQuery = 'INSERT INTO ' + @tableName + @TableColumns + ' SELECT * FROM #TagsTable'
		--print @SQLQuery
		EXECUTE(@SQLQuery)

/* Execute Transact-SQL String */
   --Execute sp_Executesql     @SQLQuery,
   -- @ParamDefinition,
   --@TagInsertTable
SET NOCOUNT OFF
END



