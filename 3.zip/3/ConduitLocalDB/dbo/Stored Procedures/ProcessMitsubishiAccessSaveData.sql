﻿CREATE PROCEDURE [TCD].[ProcessMitsubishiAccessSaveData](
	@ControllerID   INT,
	@xmlTags        XML,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @BatchID                 INT,
			  @WasherID                INT,
			  @EcolabWasherId          INT,
			  @CurrencyCode            VARCHAR(50),
			  @MachineInternalId       INT,
			  @WasherGroupID           INT,
			  @PlantWasherNumber       INT,
			  @BatchStartTime          DATETIME2,
			  @BatchEndTime            DATETIME2,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @BatchCounter            INT,
			  @IsTunnel                INT,
			  @BatchShiftId            INT,
			  @PartitionOn             DATETIME2,
			  @ShiftName               VARCHAR(50),
			  @ProgramMasterId         INT,
			  @NumberOfCompartments    INT,
			  @TargetTurnTime          INT,
			  @EcolabAccountNumber     NVARCHAR(1000) = NULL,
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @PreviousShiftId         INT,
			  @CurrentShiftId          INT;
	    SELECT
			 @MachineInternalID = T.c.value('@MachineNumber', 'int'),
			 @BatchCounter = T.c.value('@BatchCounter', 'INT'),
			 @BatchStartTime = T.c.value('@StartDateTime', 'DateTime'),
			 @BatchEndTime = T.c.value('@EndDateTime', 'DateTime'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@NominalLoad', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'int'),
			 @IsTunnel = T.c.value('@IsTunnel', 'int')
	    FROM @xmlTags.nodes('PLCData') T(c);
	    --Check for valid startdatetime
	    IF(@BatchStartTime <= '01/01/1900'
		  OR @BatchStartTime > '06/06/2079')
		   BEGIN
			  RETURN;
		   END;
	    SELECT
			 @EcolabWasherID = EcolabWasherId,
			 @WasherGroupID = Wg.WasherGroupId,
			 @PlantWasherNumber = PlantWasherNumber,
			 @WasherID = ws.WasherId,
			 @CurrencyCode = P.CurrencyCode,
			 @NumberOfCompartments = Mst.NumberofComp
	    FROM TCD.Washer Ws
		    INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.
		    WasherId
		    INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.
		    GroupId
		    INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId
		    = Wg.WasherGroupTypeId
		    INNER JOIN TCD.ConduitController Ctrl ON Ctrl.ControllerId =
		    Mst.ControllerId
		    INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.
		    EcoLabAccountNumber
	    WHERE Ctrl.ControllerID = @ControllerID
			AND mst.MachineInternalId = @MachineInternalID
			AND mst.IsTunnel = @IsTunnel
			AND Ws.Is_Deleted = 0
			AND mst.IsDeleted = 0
			AND Ctrl.IsDeleted = 0;
	    IF(@IsTunnel = 1)
		   BEGIN
			  SELECT
				    @ProgramMasterId = ProgramId,
				    @TargetTurnTime = (3600 / (tps.TotalRunTime /
				    @NumberOfCompartments))
			  FROM TCD.TunnelProgramSetup tps
			  WHERE tps.WasherGroupId = @WasherGroupID
				   AND tps.is_deleted = 0
				   AND ProgramNumber = @ProgramNumber;
			  --Start Getting InjectionCount,StepCount And ProductCount
			  SELECT
				    @StdInjectionSteps = COUNT(tdpm.
				    TunnelDosingSetupId),
				    @StdWashSteps = COUNT(DISTINCT tds.
				    TunnelDosingSetupId) - COUNT(tdpm.
				    TunnelDosingSetupId)
			  FROM tcd.TunnelDosingProductMapping tdpm
				  RIGHT JOIN tcd.TunnelDosingSetup tds ON tdpm.
				  TunnelDosingSetupId = tds.TunnelDosingSetupId
			  WHERE tds.GroupId = @WasherGroupID
				   AND tds.ProgramNumber = @ProgramNumber
				   AND tds.Is_Deleted = 0;
			  --End Getting InjectionCount,StepCount And ProductCount
		   END;
	    ELSE
		   BEGIN
			  SELECT DISTINCT
				    @ProgramMasterId = Wps.ProgramId
			  FROM TCD.Washer Ws
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws .WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
				  INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wps.Is_Deleted = 0;
			  SELECT
				    @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber,
				    @CurrencyCode = P.CurrencyCode,
				    @TargetTurnTime = w.TargetTurnTime * 60
			  FROM TCD.Washer w
				  INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.EcolabAccountNumber
			  WHERE w.WasherId = @WasherID;
			  --Start Getting InjectionCount and StepCount
			  SELECT
				    @StdInjectionSteps = COUNT(DISTINCT wdpm.WasherDosingSetupId),
				    @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) - COUNT(DISTINCT wdpm.WasherDosingSetupId)
			  FROM TCD.WasherDosingProductMapping wdpm
				  RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm.WasherDosingSetupId = wds.WasherDosingSetupId
			  WHERE wds.GroupId = @WasherGroupID
				   AND wds.ProgramNumber = @ProgramNumber;
			  --End Getting InjectionCount and StepCount
		   END;
	    SET @BatchID = NULL;
	    SELECT
			 @BatchID = BatchID
	    FROM TCD.BatchData BD
	    WHERE BD.ControllerBatchId = @BatchCounter
			AND BD.MachineInternalId = @MachineInternalId
			AND BD.MachineId = @WasherID
			AND CAST(StartDate AS DATE) = CAST(@BatchStartTime AS DATE);

    
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT
			 @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramMasterId
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT
				    @EcolabTextileCategoryId = pcp.EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp.ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram
	    IF(@BatchID IS NULL)
		   BEGIN
			  DECLARE @ShiftStartDateTemp TABLE
			  (
				  ShiftId        INT,
				  ShiftName      NVARCHAR(50),
				  ShiftStartdate DATETIME
			  );
			  INSERT INTO @ShiftStartDateTemp
			  (
				    ShiftId,
				    ShiftName,
				    ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchStartTime;
			  SELECT
				    @BatchShiftId = ShiftID,
				    @PartitionOn = ShiftStartdate
			  FROM @ShiftStartDateTemp;
			  --IF(@IsTunnel = 0)
			  --BEGIN
			  --UPDATE TCD.BatchData
			  --  SET
			  --  EndDate = GETUTCDATE(),
			  --  EndDateFormula = GETUTCDATE()
			  --WHERE
			  --  MachineInternalID = @MachineInternalID
			  --  AND StartDate <> @BatchStartTime
			  --  AND EndDate IS NULL
			  --  AND ControllerBatchId <> @BatchCounter
			  --  AND MachineId = @WasherId;
			  --END;
			  --Start Rollup for previous completed shift
			  IF(CAST(@BatchStartTime AS DATE) < CAST(GETUTCDATE() AS
			  DATE))
				 BEGIN
					SELECT TOP 1
						  @PreviousShiftId = ShiftId
					FROM TCD.BatchData
					WHERE MachineId = @WasherId
					ORDER BY
						    StartDate DESC;
					SELECT TOP 1
						  @CurrentShiftId = ShiftId
					FROM @ShiftStartDateTemp;
					IF(@CurrentShiftId != @PreviousShiftId)
					    BEGIN
						   EXEC TCD.ProductionShiftDataRollup
							   @PreviousShiftId,
							   @RedFlagShiftId OUTPUT;
						   SELECT
								@RedFlagShiftId = ISNULL(
								@RedFlagShiftId, @PreviousShiftId)
						   ;
					    END;
				 END;
			  --End Rollup for previous completed shift
			  INSERT INTO TCD.BatchData
			  (
				    ControllerBatchId,
				    EcolabWasherId,
				    GroupId,
				    MachineInternalId,
				    PlantWasherNumber,
				    StartDate,
				    EndDate,
				    ProgramNumber,
				    ProgramMasterId,
				    MachineId,
				    ActualWeight,
				    StandardWeight,
				    CurrencyCode,
				    ShiftId,
				    PartitionOn,
				    StdInjectionSteps,
				    StdWashSteps,
				    TargetTurnTime,
				    EcolabTextileCategoryId,
				    ChainTextileCategoryId,
				    FormulaSegmentId,
				    EcolabSaturationId,
				    PlantProgramId
			  )
			  SELECT
				    @BatchCounter,
				    @EcolabWasherID,
				    @WasherGroupID,
				    @MachineInternalID,
				    @PlantWasherNumber,
				    @BatchStartTime,
				    DATEADD(minute, 10, @BatchStartTime),
				    @ProgramNumber,
				    @ProgramMasterId,
				    @WasherID,
				    @Load,
				    @NominalLoad,
				    @CurrencyCode,
				    @BatchShiftId,
				    @PartitionOn,
				    @StdInjectionSteps,
				    @StdWashSteps,
				    @TargetTurnTime,
				    @EcolabTextileCategoryId,
				    @ChainTextileCategoryId,
				    @FormulaSegmentId,
				    @EcolabSaturationId,
				    @PlantProgramId
			  SELECT
				    @BatchID = SCOPE_IDENTITY();
			  IF(@CustomerNumber IS NOT NULL)
		   BEGIN
			  IF NOT EXISTS
			  (
				 SELECT
					   1
				 FROM [TCD].[BatchCustomerData]
				 WHERE BatchID = @BatchID
			  )
				 BEGIN
					INSERT INTO TCD.BatchCustomerData
					(
						  BatchId,
						  CustomerId,
						  Weight,
						  PiecesCount,
						  PartitionOn,
						  EcolabWasherId
					)
					SELECT DISTINCT
						  Bd.BatchId,
						  Pc.ID,
						  @Load,
						  ROUND(COALESCE((@Load * Pm.Pieces) /
						  NULLIF(Pm.Weight, 0), 0), 0),
					(
					    SELECT TOP 1
							 ShiftStartdate
					    FROM @ShiftStartDateTemp
					),
						  @EcolabWasherId
					FROM TCD.Washer WS
						INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
						INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
						INNER JOIN TCD.TunnelProgramSetup Tps ON Tps.WasherGroupId = Wg.WasherGroupId
						INNER JOIN TCD.ProgramMaster Pm ON Pm.ProgramId = Tps.ProgramId
						INNER JOIN TCD.PlantCustomer Pc ON Pc.ID = Pm.CustomerId
						INNER JOIN TCD.BatchData Bd ON Bd.MachineId = Ws.WasherId
					WHERE Ws.WasherId = @WasherId
						 AND Tps.ProgramNumber = @ProgramNumber
						 AND Bd.BatchId = @BatchID
						 AND Pm.CustomerId != -1
						 AND Pm.[Weight] > 0;
				 END;
		   END;
		   END;
	    ELSE
		   BEGIN
			  IF(@IsTunnel = 1)
				 BEGIN
					UPDATE TCD.BatchData
					  SET
						 StartDate = @BatchStartTime,
						 StandardWeight = @NominalLoad,
						 ShiftId = @BatchShiftId,
						 PartitionOn = @PartitionOn
					WHERE
						 ControllerBatchId = @BatchCounter
						 AND MachineId = @WasherID
						 AND CAST(StartDate AS DATE) = CAST(
						 @BatchStartTime AS DATE);
				 END;
		   END;
	END;