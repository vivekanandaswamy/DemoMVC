CREATE PROCEDURE [TCD].[GetLabourTypeCostByTypeId] 
(
	@LaborTypeId INT = NULL,
	@EcolabAccountNumber nvarchar(25) = NULL
)
AS 
  BEGIN 
SET NOCOUNT ON     
			SELECT LC.LaborTypeId,
				   LC.COST 
			FROM [TCD].LABORCOST LC
				INNER JOIN [TCD].LABORTYPE LT ON LT.LABORTYPEID = LC.LABORTYPEID 
			WHERE LC.LABORTYPEID = @LaborTypeId 
				AND LC.EcolabAccountNumber = @EcolabAccountNumber
SET NOCOUNT OFF
  END 



