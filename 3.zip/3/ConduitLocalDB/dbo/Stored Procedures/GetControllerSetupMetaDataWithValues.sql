﻿CREATE PROCEDURE [TCD].[GetControllerSetupMetaDataWithValues]
(

		@TabId INT

	,	@ControllerId INT

	,	@EcolabAccountNumber NVARCHAR(25)

	,	@RoleId INT
 )

AS

BEGIN  

SET NOCOUNT ON

	IF OBJECT_ID('tempdb..#tmpMetaData') IS NOT NULL

		DROP TABLE #tmpMetaData

	SELECT DISTINCT 

			FG.Id AS FieldGroupId

			,FG.[NAME] AS FieldGroupName

			,FG.[image_Url] as FieldGroupImageUrl

			,FG.[helpText] as FieldGroupHelpText

			,FG.[ControllerModelId]

			,FG.[ControllerTypeId]

			,FGT.NAME AS FieldGroupTypeName

			,F.Id AS FieldId

			,F.Name AS FieldName

			,FT.Name AS FieldType

			,F.Label AS FieldLabel

			,F.[Min] AS FieldMinValue

			,F.[Max] AS FieldMaxValue

			,F.IsMandatory AS FieldIsMandatory

			,F.IsEditable AS FieldIsEditable

			,F.HelpText AS FieldHelpText

			, F.HelpTextUrl AS FieldHelpUrl

			,FG.TabId AS TabIndex

			,DT.Name AS ControlType

			,F.DataSourceId AS DataSourceId

			,(Select FS.Value + ':' + FS.Name + ';' FROM [TCD].FieldSource FS where FS.DataSourceId = F.DataSourceId for xml path('')) as DataSourceKeyValue

			,F.DataCategoryId AS DataCategoryId

			,F.DefaultValue

			,F.CurrencyId AS FieldCurrencyCode

			,F.ResourceKey AS FieldResourceKey

			,FG.ResourceKey AS FieldGroupResourceKey

			,FG.DisplayOrder AS FieldGroupDO

			,F.DisplayOrder AS FieldDO 

			,CSD.ControllerId

			,FRM.RoleId AS AccessToRole

			,F.HasFieldTag AS HasFieldTag

			,F.DefaultFieldTag As TagDefaultValue

			,F.ClassName AS ClassName

			,CC.ControllerVersion

	INTO #tmpMetaData

	FROM [TCD].[FieldGroup] FG

	INNER JOIN [TCD].[FieldGroupFieldMapping] FGFM ON FG.Id = FGFM.FieldGroupId

	INNER JOIN [TCD].[Field] F ON F.Id = FGFM.FieldId

	LEFT JOIN [TCD].[FieldGroupType] FGT ON FGT.Id = FG.FieldGroupTypeId

	LEFT JOIN [TCD].FieldType FT ON FT.Id = F.TypeId 

	LEFT JOIN [TCD].DataType DT ON DT.Id = F.DataTypeId

	LEFT JOIN [TCD].[FieldRoleMapping] FRM ON FRM.FieldId = F.Id AND FRM.RoleId=@RoleId	

	INNER JOIN [TCD].[ConduitController] CC ON CC.ControllerModelId = FG.ControllerModelId AND CC.ControllerTypeId = FG.ControllerTypeId AND CC.EcoalabAccountNumber = @EcolabAccountNumber

	INNER JOIN [TCD].[ControllerSetupData] CSD ON CSD.ControllerId = CC.ControllerId AND CSD.EcolabAccountNumber = @EcolabAccountNumber

	WHERE 
	CC.ControllerId = @ControllerId
	AND
	FG.TabId = @TabId

	UPDATE tmd SET DefaultValue = CSD.Value FROM #tmpMetaData tmd

	INNER JOIN [TCD].ControllerSetupData CSD 

	ON 
	tmd.ControllerId = CSD.ControllerId 

	AND 

	tmd.FieldGroupId = CSD.FieldGroupId 

	AND 

	tmd.FieldId = CSD.FieldId 

	SELECT 

		CC.Name AS ControllerName

		,FieldGroupId

		,FieldGroupName

		,FieldGroupImageUrl

		,FieldGroupHelpText

		,#tmpMetaData.ControllerModelId

		,#tmpMetaData.ControllerTypeId

		,FieldGroupTypeName

		,FieldId

		,FieldName

		,FieldType

		,FieldLabel

		,FieldMinValue

		,FieldMaxValue

		,FieldIsMandatory

		,FieldIsEditable

		,FieldHelpText

		,FieldHelpUrl

		,TabIndex

		,ControlType

		,DataSourceId

		,DataSourceKeyValue

		,DataCategoryId

		,CASE FieldName

			WHEN 'ControllerVersion' THEN CC.ControllerVersion

			WHEN 'ControllerNumber' THEN Cast(CC.ControllerNumber as varchar)

			WHEN 'InstallDate' THEN CONVERT(VARCHAR(10), CONVERT(datetime, CC.InstallDate,   1), 101)

			WHEN 'TopicName' THEN Cast(CC.TopicName as varchar)

			WHEN 'Active'	THEN  CASE  CC.Active WHEN 0 THEN 'false' WHEN 1 THEN 'true' END --cast(CC.Active as char)  


			ELSE #tmpMetaData.DefaultValue

		END As DefaultValue

		,FieldCurrencyCode

		,FieldResourceKey

		,FieldGroupResourceKey

		,FieldGroupDO

		,FieldDO 

		,#tmpMetaData.AccessToRole

		,'Edit' AS Mode

		,HasFieldTag

		,TagDefaultValue

		,ClassName

		,#tmpMetaData.ControllerVersion
		,CAST (0 as bit) IsDosingLineConsumed
	FROM #tmpMetaData

	INNER JOIN [TCD].ConduitController CC on #tmpMetaData.ControllerId = CC.ControllerId AND CC.EcoalabAccountNumber = @EcolabAccountNumber
	
	ORDER BY FieldGroupDO , FieldDO, FieldId 


SET NOCOUNT OFF

END