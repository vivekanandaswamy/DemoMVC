﻿CREATE PROCEDURE [TCD].[GetWasherGroupFormula] @EcoLabAccountNumber NVARCHAR(25), 
											   @WasherGroupId       INT, 
											   @ProgramSetupId      INT = NULL, 
											   @Is_Deleted          BIT = 'FALSE' 
AS 
  BEGIN 
	  SET NOCOUNT ON 

	  DECLARE @WasherGroupNumber      VARCHAR(10) = NULL, 
			  @WasherGroupName        NVARCHAR(50) = NULL, 
			  @WasherGroupTypeName    VARCHAR(30) = NULL, 
			  @NextAvailableStepNo    INT = NULL, 
			  @NextAvailableFormulaNo INT = NULL, 
			  @MyServiceMchGrpGuid    UNIQUEIDENTIFIER = NULL, 
			  @MaxInjectionsCount     INT = 0, 
			  @CanAddInjections       BIT = 0, 
			  @ReferenceLoad          INT = 0, 
			  @ControllerID           INT = NULL, 
			  @ControllerModelID      INT = NULL, 
			  @WasherGroupIdCopy      INT = NULL 

	  CREATE TABLE #SetupDataTemp 
		( 
		   val varchar(32) not null 
		); 

	  SELECT @WasherGroupTypeName = WGT.WasherGroupTypeName, 
			 @WasherGroupNumber = WG.WasherGroupNumber, 
			 @WasherGroupName = WG.WasherGroupName, 
			 @MyServiceMchGrpGuid = GT.MyServiceCustMchGrpGuid 
	  FROM   [TCD].WasherGroup WG (NOLOCK) 
			 JOIN [TCD].WasherGroupType WGT (NOLOCK) 
			   ON WG.WasherGroupTypeId = WGT.WasherGroupTypeId 
			 JOIN [TCD].MachineGroup GT (NOLOCK) 
			   ON WG.WasherGroupId = GT.Id 
				  AND WG.EcolabAccountNumber = GT.EcolabAccountNumber 
	  WHERE  GT.EcolabAccountNumber = @EcoLabAccountNumber 
			 AND WG.WasherGroupId = @WasherGroupId 

	  SELECT @ControllerID = wg.ControllerId 
	  FROM   TCD.WasherGroup wg 
	  WHERE  wg.WasherGroupId = @WasherGroupId 
			 AND wg.EcolabAccountNumber = @EcoLabAccountNumber 

	  SELECT @ControllerModelID = cc.ControllerModelId 
	  FROM   TCD.ConduitController cc 
	  WHERE  cc.ControllerId = @ControllerID 
			 AND cc.EcoalabAccountNumber = @EcoLabAccountNumber 

	  IF ( @WasherGroupTypeName = 'Tunnel' ) --Tunnel/Washer Formula   
		BEGIN 
			SELECT @NextAvailableFormulaNo = ISNULL(Max(ProgramNumber), 0) + 1 
			FROM   [TCD].TunnelProgramSetup 
			WHERE  WasherGroupId = @WasherGroupId 
				   AND Is_Deleted = 0 
				   AND EcolabAccountNumber = @EcoLabAccountNumber 

			SELECT @WasherGroupNumber                                               AS WasherGroupNumber,
				   @WasherGroupName                                                 AS WasherGroupName,
				   @WasherGroupTypeName                                             AS WasherGroupTypeName,
				   TPS.TunnelProgramSetupId                                         AS ProgramSetupId,
				   TPS.ProgramNumber                                                AS ProgramNumber,
				   TPS.ProgramId                                                    AS ProductId,
				   PM.Name                                                          AS ProductName,
				   TPS.NominalLoad                                                  AS NominalLoad,
				   Sum(TDS.StepRunTime)                                             AS TotalRunTime,
				   TPS.ExtraTime                                                    AS ExtraTime,
				   TPS.LoadsPerMonth                                                AS LoadsPerMonth,
				   0                                                                AS NextAvailableStepNo,
				   TPS.LastModifiedTime                                             AS LastModifiedTime,
				   TPS.LastSyncTime                                                 AS LastSyncTime,
				   TPS.EcolabAccountNumber                                          AS EcolabAccountNumber,
				   TPS.WasherGroupId                                                AS WasherGroupId,
				   @NextAvailableFormulaNo                                          AS NextAvailableFormulaNo,
				   TPS.MyServiceCustFrmulaMchGrpGUID                                AS MyServiceCustFrmulaMchGrpGUID,
				   TPS.Is_Deleted                                                   AS Is_Deleted,
				   ( CASE 
					   WHEN pm.PlantProgramId IS NULL 
							 OR pm.PlantProgramId = 0 THEN ETC.MyServiceMstrLnnTypId 
					   ELSE cp.MyServiceEcolabTextileCategoryId 
					 END )                                                          AS MyServiceMstrLnnTypId,
				   @MyServiceMchGrpGuid                                             AS MyServiceMchGrpGuid,
				   @MaxInjectionsCount                                              AS MaxInjectionsCount,
				   @CanAddInjections                                                AS CanAddInjections,
				   TPS.MyServiceLastSynchTime                                       AS MyServiceLastSynchTime,
				   @ReferenceLoad                                                   AS ReferenceLoad,
				   (SELECT Count(DISTINCT tds.TunnelDosingSetupId) 
					FROM   TCD.TunnelDosingSetup tds 
						   INNER JOIN TCD.TunnelDosingProductMapping tdpm 
								   ON tdpm.TunnelDosingSetupId = tds.TunnelDosingSetupId 
									  AND tdpm.EcoLabAccountNumber = tds.EcolabAccountNumber 
						   INNER JOIN TCD.WasherGroup wg 
								   ON wg.WasherGroupId = TPS.WasherGroupId 
									  AND wg.EcolabAccountNumber = TPS.EcolabAccountNumber 
						   INNER JOIN TCD.MachineSetup ms 
								   ON ms.GroupId = wg.WasherGroupId 
									  AND ms.EcoalabAccountNumber = wg.EcolabAccountNumber 
						   INNER JOIN TCD.TunnelCompartment tc 
								   ON tc.EcoLabAccountNumber = ms.EcoalabAccountNumber 
									  AND tc.WasherId = ms.WasherId 
						   INNER JOIN TCD.TunnelCompartmentEquipmentMapping tcem 
								   ON tcem.EcoLabAccountNumber = tc.EcoLabAccountNumber 
									  AND tcem.ControllerEquipmentSetupId = tdpm.ControllerEquipmentSetupId
									  AND tc.TunnelCompartmentId = tcem.TunnelCompartmentId 
									  AND tcem.Is_Deleted = 'False' 
					WHERE  wg.WasherGroupId = @WasherGroupId 
						   AND wg.EcolabAccountNumber = @EcoLabAccountNumber 
						   AND tds.TunnelProgramSetupId = TPS.TunnelProgramSetupId) AS WashStepCount,
				   @ControllerID                                                    as ControllerID,
				   @ControllerModelID                                               as ControllerModelID,
				   ( CASE 
					   WHEN pm.PlantProgramId IS NULL 
							 OR pm.PlantProgramId = 0 THEN ES.MyServiceMstrLnnTypId 
					   ELSE cp.MyServiceEcolabSaturationId 
					 END )                                                          AS MyServiceSaturationTypeId,
					 0                                                              AS CoolDownStep,
					 Sum(TDS.StepRunTime)												AS ExpectedRunTime
			FROM   [TCD].TunnelProgramSetup TPS (NOLOCK) 
				   JOIN [TCD].ProgramMaster PM (NOLOCK) 
					 ON TPS.ProgramId = PM.ProgramId 
						AND PM.EcolabAccountNumber = TPS.EcolabAccountNumber 
				   LEFT JOIN TCD.EcolabTextileCategory ETC (NOLOCK) 
						  ON PM.EcolabTextileCategoryId = ETC.TextileId 
				   LEFT JOIN TCD.EcolabSaturation ES (NOLOCK) 
						  ON PM.EcolabSaturationId = ES.EcolabSaturationId 
				   LEFT JOIN TCD.ChainPrograms cp 
						  ON cp.PlantProgramId = pm.PlantProgramId 
							 AND pm.EcolabAccountNumber = cp.EcolabAccountNumber 
				   LEFT JOIN [TCD].TunnelDosingSetup TDS (NOLOCK) 
						  ON TDS.TunnelProgramSetupId = TPS.TunnelProgramSetupId 
							 AND TDS.EcolabAccountNumber = TPS.EcolabAccountNumber 
							 AND ( TDS.Is_Deleted = 'FALSE' 
									OR TDS.Is_Deleted = @Is_Deleted ) 
			WHERE  TPS.EcolabAccountNumber = @EcoLabAccountNumber 
				   AND TPS.WasherGroupId = @WasherGroupId 
				   AND TPS.TunnelProgramSetupId = ISNULL(@ProgramSetupId, TPS.TunnelProgramSetupId)
				   AND ( TPS.Is_Deleted = 'FALSE' 
						  OR TPS.Is_Deleted = @Is_Deleted ) 
			GROUP  BY TPS.TunnelProgramSetupId, 
					  TPS.ProgramNumber, 
					  TPS.ProgramId, 
					  PM.Name, 
					  TPS.NominalLoad, 
					  TPS.ExtraTime, 
					  TPS.LoadsPerMonth, 
					  TPS.LastModifiedTime, 
					  TPS.LastSyncTime, 
					  TPS.EcolabAccountNumber, 
					  TPS.WasherGroupId, 
					  TPS.MyServiceCustFrmulaMchGrpGUID, 
					  TPS.Is_Deleted, 
					  ETC.MyServiceMstrLnnTypId, 
					  TPS.MyServiceLastSynchTime, 
					  pm.PlantProgramId, 
					  cp.MyServiceEcolabSaturationId, 
					  ES.MyServiceMstrLnnTypId, 
					  cp.MyServiceEcolabTextileCategoryId 
		END 
	  ELSE --Conventional/Washer Formula   
		BEGIN 
			IF @ControllerModelID IS NULL 
				OR @ControllerModelID < 7 
				OR @ControllerModelID IN( 12, 13 ) 
			  BEGIN ; 
				  WITH InjectValues (Value) 
					   AS (SELECT csd.[Value] 
						   FROM   TCD.ControllerSetupData AS csd 
								  INNER JOIN TCD.ConduitController AS cc(NOLOCK) 
										  ON cc.ControllerId = csd.ControllerId 
											 AND cc.EcoalabAccountNumber = csd.EcolabAccountNumber
								  INNER JOIN TCD.FieldGroup AS fg 
										  ON fg.ControllerModelId = cc.ControllerModelId 
											 AND fg.ControllerTypeId = cc.ControllerTypeId 
								  INNER JOIN TCD.FieldGroupFieldMapping AS fgfm 
										  ON fgfm.FieldGroupId = fg.Id 
								  INNER JOIN TCD.Field AS f 
										  ON f.Id = fgfm.FieldId 
											 AND f.ResourceKey = 'Max_Formula_Injections' 
											 AND csd.FieldId = f.Id 
								  INNER JOIN TCD.MachineSetup AS ms(NOLOCK) 
										  ON ms.ControllerId = cc.ControllerId 
											 AND cc.EcoalabAccountNumber = ms.EcoalabAccountNumber
								  INNER JOIN TCD.WasherGroup AS wg(NOLOCK) 
										  ON wg.WasherGroupId = ms.GroupId 
											 AND wg.EcolabAccountNumber = ms.EcoalabAccountNumber
						   WHERE  wg.WasherGroupId = @Washergroupid 
								  AND ms.IsDeleted = 'False' 
								  AND wg.EcolabAccountNumber = @Ecolabaccountnumber) 
				  INSERT INTO #SetupDataTemp 
				  SELECT iv.[Value] 
				  FROM   InjectValues iv 

				  SELECT @MaxInjectionsCount = Min(Cast(t.val AS INT)) 
				  FROM   #SetupDataTemp t 

				  DROP TABLE #SetupDataTemp 
			  END 
			ELSE 
			  BEGIN 
				  SET @MaxInjectionsCount = 20 
			  END 

			DECLARE @MaxInjectionsNumber INT = 0 

			SELECT @MaxInjectionsNumber = ISNULL(Max(wdpm.InjectionNumber), 0) 
			FROM   TCD.WasherDosingProductMapping wdpm (NOLOCK) 
				   INNER JOIN TCD.WasherDosingSetup wds (NOLOCK) 
						   ON wds.WasherDosingSetupId = wdpm.WasherDosingSetupId 
							  AND wds.EcoLabAccountNumber = wdpm.EcoLabAccountNumber 
			WHERE  wds.WasherProgramSetupId = @ProgramSetupId 
				   AND wds.EcoLabAccountNumber = @EcoLabAccountNumber 
				   AND wds.Is_Deleted = 0 
				   AND wdpm.IsDeleted = 0 

			IF @MaxInjectionsNumber < @MaxInjectionsCount 
			  BEGIN 
				  SET @CanAddInjections = 1 
			  END 

			SELECT @NextAvailableStepNo = ISNULL(Max(StepNumber), 0) + 1 
			FROM   [TCD].WasherDosingSetup WDS (NOLOCK) 
			WHERE  WDS.EcolabAccountNumber = @EcoLabAccountNumber 
				   AND WDS.WasherProgramSetupId = @ProgramSetupId 
				   AND Is_Deleted = 'FALSE' 

			SET @WasherGroupIdCopy = @WasherGroupId 

			IF @ControllerModelID = 7 -- MyControl   
			  BEGIN 
				  SET @WasherGroupId = NULL 
			  END 

			SELECT @NextAvailableFormulaNo = ISNULL(Max(ProgramNumber), 0) + 1 
			FROM   [TCD].WasherProgramSetup (NOLOCK) 
			WHERE  ( CASE 
					   WHEN @WasherGroupId IS NOT NULL THEN WasherGroupId 
					   ELSE ControllerID 
					 END ) = ( CASE 
								 WHEN @WasherGroupId IS NOT NULL THEN @WasherGroupId 
								 ELSE @ControllerID 
							   END ) 
				   AND Is_Deleted = 0 
				   AND EcolabAccountNumber = @EcoLabAccountNumber 

			SELECT @ReferenceLoad = Max(i.ReferenceLoad) 
			FROM   TCD.Injection i (NOLOCK) 
				   INNER JOIN TCD.WasherGroup wg (NOLOCK) 
						   ON wg.WasherGroupNumber = i.WasherGroupNumber 
							  AND wg.EcolabAccountNumber = i.EcolabAccountNumber 
				   INNER JOIN TCD.MachineSetup ms (NOLOCK) 
						   ON ms.GroupId = wg.WasherGroupId 
							  AND ms.EcoalabAccountNumber = wg.EcolabAccountNumber 
							  AND ms.IsDeleted = 0 
				   INNER JOIN TCD.Washer w (NOLOCK) 
						   ON w.WasherId = ms.WasherId 
							  AND w.EcoLabAccountNumber = ms.EcoalabAccountNumber 
							  AND w.Is_Deleted = 0 
			WHERE  I.WasherGroupNumber IN (SELECT WasherGroupNumber 
										   FROM   TCD.WasherGroup wg 
										   WHERE  ( CASE 
													  WHEN @WasherGroupId IS NOT NULL THEN WG.WasherGroupId
													  ELSE WG.ControllerId 
													END ) = ( CASE 
																WHEN @WasherGroupId IS NOT NULL THEN @WasherGroupId
																ELSE @ControllerID 
															  END ) 
												  AND wg.EcolabAccountNumber = @EcoLabAccountNumber)
				   AND i.EcolabAccountNumber = @EcoLabAccountNumber 

			SELECT @WasherGroupNumber                                          AS WasherGroupNumber,
				   @WasherGroupName                                            AS WasherGroupName,
				   @WasherGroupTypeName                                        AS WasherGroupTypeName,
				   WPS.WasherProgramSetupId                                    AS ProgramSetupId,
				   WPS.ProgramNumber                                           AS ProgramNumber,
				   WPS.ProgramId                                               AS ProductId, 
				   PM.Name                                                     AS ProductName,
				   WPS.NominalLoad                                             AS NominalLoad,
				   SUM(WDS.StepRunTime)								   AS TotalRunTime,
				   WPS.ExtraTime                                               AS ExtraTime, 
				   WPS.LoadsPerMonth                                           AS LoadsPerMonth,
				   @NextAvailableStepNo                                        AS NextAvailableStepNo,
				   WPS.LastModifiedTime                                        AS LastModifiedTime,
				   WPS.LastSyncTime                                            AS LastSyncTime,
				   WPS.EcolabAccountNumber                                     AS EcolabAccountNumber,
				   @WasherGroupIdCopy                                          AS WasherGroupId,
				   @NextAvailableFormulaNo                                     AS NextAvailableFormulaNo,
				   WPS.MyServiceCustFrmulaMchGrpGUID                           AS MyServiceCustFrmulaMchGrpGUID,
				   WPS.Is_Deleted                                              AS Is_Deleted,
				   ( CASE 
					   WHEN pm.PlantProgramId IS NULL 
							 OR pm.PlantProgramId = 0 THEN ETC.MyServiceMstrLnnTypId 
					   ELSE cp.MyServiceEcolabTextileCategoryId 
					 END )                                                     AS MyServiceMstrLnnTypId,
				   @MyServiceMchGrpGuid                                        AS MyServiceMchGrpGuid,
				   @MaxInjectionsCount                                         AS MaxInjectionsCount,
				   @CanAddInjections                                           AS CanAddInjections,
				   WPS.MyServiceLastSynchTime                                  AS MyServiceLastSynchTime,
				   @ReferenceLoad                                              AS ReferenceLoad,
				   (Select Count(DISTINCT WDS.WasherDosingSetupId) 
					FROM   [TCD].WasherDosingSetup WDS 
						   INNER JOIN TCD.WasherDosingProductMapping WDPM 
								   ON WDS.WasherDosingSetupId = WDPM.WasherDosingSetupId 
									  AND WDS.EcoLabAccountNumber = WDPM.EcoLabAccountNumber 
									  AND WDPM.IsDeleted = 'FALSE' 
					WHERE  WDS.WasherProgramSetupId = WPS.WasherProgramSetupId 
						   AND WDS.Is_Deleted = 'FALSE' 
						   AND WDS.EcoLabAccountNumber = @EcoLabAccountNumber) AS WashStepCount,
				   @ControllerID                                               as ControllerID,
				   @ControllerModelID                                          as ControllerModelID,
				   ( CASE 
					   WHEN pm.PlantProgramId IS NULL 
							 OR pm.PlantProgramId = 0 THEN ES.MyServiceMstrLnnTypId 
					   ELSE cp.MyServiceEcolabSaturationId 
					 END )                                                     AS MyServiceSaturationTypeId,
					 WPS.CoolDownStep                                          AS CoolDownStep,
					 WPS.TotalRunTime											AS ExpectedRunTime
			FROM   [TCD].WasherProgramSetup WPS (NOLOCK) 
				   JOIN [TCD].ProgramMaster PM (NOLOCK) 
					 ON WPS.ProgramId = PM.ProgramId 
				   LEFT JOIN TCD.EcolabTextileCategory ETC (NOLOCK) 
						  ON PM.EcolabTextileCategoryId = ETC.TextileId 
				   LEFT JOIN TCD.EcolabSaturation ES (NOLOCK) 
						  ON PM.EcolabSaturationId = ES.EcolabSaturationId 
				   LEFT JOIN TCD.ChainPrograms cp 
						  ON cp.PlantProgramId = pm.PlantProgramId 
							 AND pm.EcolabAccountNumber = cp.EcolabAccountNumber 
				   LEFT JOIN [TCD].WasherDosingSetup WDS (NOLOCK) 
						  ON WDS.WasherProgramSetupId = WPS.WasherProgramSetupId 
							 AND ( WDS.Is_Deleted = 'FALSE' 
									OR WDS.Is_Deleted = @Is_Deleted ) 
			WHERE  WPS.EcolabAccountNumber = @EcoLabAccountNumber 
				   AND ( CASE 
						   WHEN @WasherGroupId IS NOT NULL THEN WPS.WasherGroupId 
						   ELSE WPS.ControllerID 
						 END ) = ( CASE 
									 WHEN @WasherGroupId IS NOT NULL THEN @WasherGroupId 
									 ELSE @ControllerID 
								   END ) 
				   AND WPS.WasherProgramSetupId = ISNULL(@ProgramSetupId, WPS.WasherProgramSetupId)
				   AND ( WPS.Is_Deleted = 'FALSE' 
						  OR WPS.Is_Deleted = @Is_Deleted ) 
			GROUP  BY WPS.WasherProgramSetupId, 
					  WPS.ProgramNumber, 
					  WPS.ProgramId, 
					  PM.Name, 
					  WPS.NominalLoad, 
					  WPS.ExtraTime, 
					  WPS.LoadsPerMonth, 
					  WPS.LastModifiedTime, 
					  WPS.LastSyncTime, 
					  WPS.EcolabAccountNumber, 
					  WasherGroupId, 
					  WPS.MyServiceCustFrmulaMchGrpGUID, 
					  WPS.Is_Deleted, 
					  ETC.MyServiceMstrLnnTypId, 
					  WPS.MyServiceLastSynchTime, 
					  pm.PlantProgramId, 
					  cp.MyServiceEcolabSaturationId, 
					  ES.MyServiceMstrLnnTypId, 
					  cp.MyServiceEcolabTextileCategoryId,
					  WPS.CoolDownStep,
					  WPS.TotalRunTime
		END 

	  SET NOCOUNT OFF 
  END 