﻿CREATE PROCEDURE [TCD].[GetDashBoards]
	@XBound		INT,
	@YBound		INT
AS
BEGIN
	SELECT 
		DSB.DashBoardId  as DashboardId,
		CAST (
				DSB.TypeId 
				AS INT
			 )  AS TypeId
	FROM	tcd.DashBoard DSB
	INNER JOIN tcd.MonitorSetUpMapping  MS
	ON  DSB.DashboardId = MS.DashboardId		   
	WHERE 
			MS.MonitorId = (
							SELECT MonitorId 
							FROM tcd.Monitor
							WHERE	XBound = @XBound
								AND	YBound = @YBound
						) AND MS.IsDeleted=0
RETURN 0
END
