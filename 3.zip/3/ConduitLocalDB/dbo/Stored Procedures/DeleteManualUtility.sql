CREATE PROCEDURE [TCD].[DeleteManualUtility] 
 (
		@UtilityId  INT,
		@EcolabAccountNumber NVARCHAR(25),
		@UserId INT,
		@Scope VARCHAR(100) OUTPUT
 )
AS
BEGIN 
SET NOCOUNT ON   

			SET	@Scope			=			ISNULL(@Scope, NULL)			--SQLEnlight

			IF EXISTS (SELECT 1  FROM   [TCD].ManualUtility  WHERE  UtilityId  = @UtilityId)
			BEGIN
						UPDATE [TCD].ManualUtility 
						SET 
							IsDeleted = 1,
							LastModifiedByUserId = @UserId  
						WHERE 
							UtilityId = @UtilityId 
							AND EcolabAccountNumber = @EcolabAccountNumber   
							
						SET @Scope = '301' 		
			END
			ELSE
			BEGIN
						SET @Scope = '401' 	
			END
SET NOCOUNT OFF
END