﻿
/*  
 ==========================================================================================  
 Purpose:  Fecthing the Labour Types

 Author:  Premchand yelavarthi

 --------------------------------------------------------------  
 Aug-14-2014 ENT: Initial version.  
 ==========================================================================================  
*/ 
CREATE PROCEDURE [TCD].[GetLabourTypes] 
AS 
  BEGIN 
      SET nocount ON; 
  SELECT LT.LaborTypeId,LT.Description FROM [TCD].LaborType LT     
  END