﻿CREATE PROCEDURE TCD.GetPlantDetailsByUserId(
       @Ecolabaccountnumber NVARCHAR(25) = NULL	--(keeping this nullable, since it impacts the service/access layer)
       , 
       @Userid INT)
AS
BEGIN

    SET NOCOUNT ON;

    SET @Ecolabaccountnumber = ISNULL(@Ecolabaccountnumber, NULL)


    SELECT
            p.EcolabAccountNumber, 
            p.Name, 
            p.TMName, 
            p.TMPhoneNumber, 
            p.DMName, 
            p.DMPhoneNumber, 
            (SELECT
                     PC.PlantChainName
                 FROM TCD.PlantChain AS PC
                 WHERE PC.PlantChainId = P.PlantChainId)AS Chain, 
            p.chainUnitNumber, 
            (SELECT
                     RM.RegionName
                 FROM TCD.PlantChain AS PC
                      JOIN TCD.RegionMaster AS RM ON PC.RegionId = RM.RegionId
                 WHERE PC.PlantChainId = P.PlantChainId)AS ChainRegions, 
            p.CensusPriceKg, 
            p.Remarks, 
            CASE
                WHEN(SELECT
                   LanguageId FROM TCD.UserMaster AS UM WHERE UM.UserId = @Userid)IS NULL THEN p.LanguageId
                WHEN(SELECT
                  LanguageId FROM TCD.UserMaster AS UM WHERE UM.UserId = @Userid)IS NOT NULL THEN(SELECT LanguageId FROM TCD.UserMaster AS UM WHERE UM.UserId = @Userid)
            END AS LanguageId,

            CASE
                WHEN(SELECT
                             CurrencyCode FROM TCD.UserMaster AS UM WHERE UM.UserId = @Userid)IS NULL THEN p.CurrencyCode
                WHEN(SELECT
                             CurrencyCode FROM TCD.UserMaster AS UM WHERE UM.UserId = @Userid)IS NOT NULL THEN(SELECT
                                                                                                                       CurrencyCode FROM TCD.UserMaster AS UM WHERE UM.UserId = @Userid)
            END AS CurrencyCode, 
            Addr.BillingAddr1, 
            addr.BillingAddr2, 
            addr.City, 
            addr.Country, 
            addr.zip, 
            addr.ShippingAddr1, 
            addr.ShippingAddr2, 
            addr.Shippingcity, 
            addr.Shippingcountry, 
            addr.Shippingzip, 
            p.Rate, 
            p.ExportPath, 
            p.AllowManualRewash, 
            p.DataLiveTime, 
            p.BudgetCustomer,  
			p.UOMId AS UOMId,
--            CASE
--                WHEN(SELECT
--                             UOMId FROM TCD.UserMaster AS UM WHERE UM.UserId = @Userid)IS NULL THEN p.UOMId
--                WHEN(SELECT
--                             UOMId FROM TCD.UserMaster AS UM WHERE UM.UserId = @Userid)IS NOT NULL THEN(SELECT
--                                                                                                                UOMId FROM TCD.UserMaster AS UM WHERE
--UM.UserId = @Userid)
--            END AS UOMId, 
            p.Logo, 
            p.RegionID, 
            (SELECT
                     RegionName FROM TCD.RegionMaster AS R WHERE R.RegionID = P.RegionID)AS RegionName, 
					 (select Name From LanguageMaster L where L.LanguageId = P.LanguageId) as LanguageName,  
--            CASE
--                WHEN(SELECT
--                             LanguageId FROM TCD.UserMaster AS UM WHERE UM.UserId = @Userid)IS NULL THEN(SELECT
--                                                                                                                 Name FROM TCD.LanguageMaster AS L
--WHERE L.LanguageId = P.LanguageId)
--                WHEN(SELECT
--                             LanguageId FROM TCD.UserMaster AS UM WHERE UM.UserId = @Userid)IS NOT NULL THEN(SELECT
--                                                                                                                     Name
--                                                                                                                 FROM TCD.LanguageMaster AS L
--                                                                                                                 WHERE L.LanguageId IN(
--                                                                                                             SELECT
--                                                                                                                     LanguageId FROM TCD.UserMaster
--AS UM WHERE UM.UserId = @Userid))
--            END AS LanguageName,
   
            --(select Name From LanguageMaster L where L.LanguageId = P.LanguageId) as LanguageName,  
    
            --(select CurrencyName From [TCD].CurrencyMaster C Where c.CurrencyCode=p.CurrencyCode) AS CurrencyName,  
			(select CurrencyName From [TCD].CurrencyMaster C Where c.CurrencyCode=p.CurrencyCode) AS CurrencyName, 
--            CASE
--                WHEN(SELECT
--                             CurrencyCode FROM TCD.UserMaster AS UM WHERE UM.UserId = @Userid)IS NULL THEN(SELECT
--                                                                                                                   CurrencyName FROM TCD.
--CurrencyMaster AS C WHERE c.CurrencyCode = P.CurrencyCode)
--                WHEN(SELECT
--                             CurrencyCode FROM TCD.UserMaster AS UM WHERE UM.UserId = @Userid)IS NOT NULL THEN(SELECT
--                                                                                                                       CurrencyName
--                                                                                                                   FROM TCD.CurrencyMaster AS C
--                                                                                                                   WHERE c.CurrencyCode IN(
--                                                                                                               SELECT
--                                                                                                                       CurrencyCode FROM TCD.
--UserMaster AS UM WHERE UM.UserId = @Userid))
--            END AS CurrencyName,
   

    
            (Select UnitSystem From [TCD].DimensionalUnitSystems DUS where DUS.UnitSystemId=p.UOMId) AS UnitSystem      
--            CASE
--                WHEN(SELECT
--                             UOMId FROM TCD.UserMaster AS UM WHERE UM.UserId = @Userid)IS NULL THEN(SELECT
--                                                                                                            UnitSystem
--                                                                                                        FROM TCD.DimensionalUnitSystems AS DUS
--                                                                                                        WHERE DUS.UnitSystemId = p.UOMId)
--                WHEN(SELECT
--                             UOMId FROM TCD.UserMaster AS UM WHERE UM.UserId = @Userid)IS NOT NULL THEN(SELECT
--                                                                                                                UnitSystem
--                                                                                                            FROM TCD.DimensionalUnitSystems AS DUS
--                                                                                                            WHERE DUS.UnitSystemId IN(
--                                                                                                        SELECT
--                                                                                                                UOMId FROM TCD.UserMaster AS UM WHERE
--UM.UserId = @Userid))
--            END AS UOMId
			, 
            P.LastModifiedTime AS LastModifiedTime, 
            P.MyServiceLastSynchTime AS MyServiceLastSynchTime, 
            P.LastServiceVisitDate AS LastServiceVisitDate, 
            P.LastArchiveDate AS LastArchiveDate, 
            P.NextServiceVisitDate AS NextServiceVisitDate, 
            p.PlantChainId, 
            P.MyServiceCustGuid AS MyServiceId, 
            P.ConStdTurnTime AS PlantStandardTurnTime, 
            P.PlantContractNumber AS PlantContractNumber, 
            P.PlantId AS PlantId, 
            P.DayId AS DayId, 
            P.StartTime AS StartTime, 
            P.EndTime AS EndTime,
			P.IsETechEnable AS IsETechEnable,
		    P.ETechIpAddress AS ETechIpAddress,
			P.SourceSystemId AS SourceSystemId
        FROM TCD.plant AS P
             INNER JOIN TCD.PlantCustAddress AS ADDR ON p.EcolabAccountNumber = ADDR.EcolabAccountNumber
        WHERE Is_Deleted = 0
    SET NOCOUNT OFF;
END