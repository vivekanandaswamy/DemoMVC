﻿/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_GetWashersByGroupId]                                     

Purpose:				To get the washers by group id.

Parameters:				@WasherGroupId - holds the washer group id.
						@EcolabAccountNumber - holds the ecolab account number.
																																				
###################################################################################################                                           
*/
CREATE PROCEDURE [TCD].[GetWashersByGroupId] 
(
	 @WasherGroupId INT ,
	 @EcolabAccountNumber NVARCHAR(25) 
)
AS 
  BEGIN      
	 SET NOCOUNT ON
	  SELECT 
				  DISTINCT WasherId,
				  MachineName,
				  ControllerId
      FROM   
				[TCD].MachineSetup 
	  WHERE 
				GroupId =  @WasherGroupId 
				AND EcoalabAccountNumber = @EcolabAccountNumber
				AND IsDeleted = 0 
	SET NOCOUNT OFF
  END