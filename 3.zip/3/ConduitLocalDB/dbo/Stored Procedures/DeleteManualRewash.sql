/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_DeleteManualRewash]                                         

Purpose:				To delete the manual rewash.

Parameters:				@RewashId - holds the rewash id to be deleted.
						@EcolabAccountNumber - holds the ecolab account number.
						@UserId - holds the user id.
						@Scope	- holds the scope.
																												
###################################################################################################                                           
*/
CREATE PROCEDURE [TCD].[DeleteManualRewash] 
 (
		@RewashId INT,
		@EcolabAccountNumber NVARCHAR(25),
		@UserId INT,
		@Scope VARCHAR(100) OUTPUT
 )
AS

BEGIN  
SET NOCOUNT ON


DECLARE @Date date,
		@WasherGroupId int,
		@ProgramMasterId int,
		@ManualInputValue int = NULL,
		@LatestManualInputValue int = NULL

  SELECT @Date = CAST(mr.RecordedDate AS date),@WasherGroupId = mr.WasherGroupId,@ProgramMasterId = mr.FormulaId,@ManualInputValue = mr.[Value] FROM TCD.ManualRewash mr WHERE mr.RewashId = @RewashId

    SELECT @LatestManualInputValue = - @ManualInputValue

SET	@Scope			=			ISNULL(@Scope, NULL)

			 IF EXISTS (SELECT 1  FROM   [TCD].ManualRewash  WHERE  RewashId  = @RewashId)
			 BEGIN
						 UPDATE [TCD].ManualRewash 
						 SET IsDeleted = 1,
						 LastModifiedByUserId = @UserId  
						 WHERE RewashId = @RewashId 
							   AND EcolabAccountNumber = @EcolabAccountNumber

			  EXEC [TCD].[UpdateProductionShiftManualRewashRollup]	   @Date  = @Date,--'2015-05-26',
													   @ManualData  = @LatestManualInputValue,--1000,
													   @WasherGroupId  = @WasherGroupId,--3,
													   @ProgramMasterId  = @ProgramMasterId--21

						 SET @Scope = '301' 		
			 END
			 ELSE
			 BEGIN
						 SET @Scope = '401' 	
			 END
			    
SET NOCOUNT OFF
   
END