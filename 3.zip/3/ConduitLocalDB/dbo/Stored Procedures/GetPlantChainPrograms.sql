﻿/*  
 ==========================================================================================  
 Purpose:  Fetching the list of plant chain programs.  

 Author:  Phani  

 --------------------------------------------------------------  
 August-18-2014 ENT: Initial version.  
 ==========================================================================================  
*/ 
CREATE PROCEDURE [TCD].[GetPlantChainPrograms] 
AS 
  BEGIN 
      SET nocount ON; 

      SELECT 
	  cp.PlantProgramId
	  , cp.PlantProgramName
	  FROM   [TCD].PlantChainProgram cp
     
  END 