 CREATE PROCEDURE [TCD].[Saveformulasegments] (@FormulaSegmentID INT = NULL,
                                              @SegmentName      VARCHAR(128) =
NULL,
                                              @IsDeleted        BIT = NULL,
                                              @LastModifiedTime DATETIME = NULL,
                                              @LastSyncTime     DATETIME = NULL)
AS
    SET nocount ON

	SET IDENTITY_INSERT tcd.formulasegments ON

  BEGIN
      IF EXISTS(SELECT *
                FROM   tcd.formulasegments
                WHERE  formulasegmentid = @FormulaSegmentID)
        BEGIN
            UPDATE FC
            SET    FC.segmentname = @SegmentName,-- varchar
                   FC.is_deleted = @IsDeleted,-- bit
                   FC.lastmodifiedtime = @LastModifiedTime,-- datetime
                   FC.lastsynctime = @LastSyncTime -- datetime      
            FROM   tcd.formulasegments FC
            WHERE  FC.formulasegmentid = @FormulaSegmentID
        END
      ELSE
        BEGIN
            INSERT INTO tcd.formulasegments
                        (formulasegmentid,
						 segmentname,
                         is_deleted,
                         lastmodifiedtime,
                         lastsynctime)
            SELECT @FormulaSegmentID,
					@SegmentName,
                   @IsDeleted,
                   @LastModifiedTime,
                   @LastSyncTime
        END
  END  

 	SET IDENTITY_INSERT tcd.formulasegments OFF