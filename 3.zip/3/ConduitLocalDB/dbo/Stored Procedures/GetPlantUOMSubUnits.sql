﻿create PROC [TCD].[GetPlantUOMSubUnits]
(
@USERID INT = NULL
,@UOMID INT = NULL
,@ECOLABACCOUNTNUMBER NVARCHAR(25) = NULL
)
AS
SET NOCOUNT ON

SET	@USERID			=			ISNULL(@USERID, NULL)			--SQLEnlight SA0029

BEGIN
    SELECT DUD.UnitSystemId,DUD.UsageKey,DUD.Unit,DUD1.Subunit AS SOURCE,DUD.Subunit AS TARGET
	 FROM TCD.DimensionalUnitsDefaults DUD
	 JOIN (select Subunit,Unit from TCD.DimensionalUnitsDefaults where UnitSystemId = 1) DUD1
	 ON DUD.Unit = DUD1.Unit
	 WHERE UnitSystemId = @UOMID;
END
SET NOCOUNT OFF