﻿/*  
 ==========================================================================================  
 Purpose:  Fetching the Chemical List.  

 
 --------------------------------------------------------------  
 July-18-2014 ENT: Initial version.  
 ==========================================================================================  
*/ 

CREATE PROCEDURE [TCD].[Getplantchemicals] (@EcolabAccountNumber nvarchar(25),	@Is_Deleted								    BIT			=		'FALSE') 
AS 
  BEGIN 
      SET NOCOUNT ON; 

      DECLARE @RegionId INT = NULL 

      SELECT @RegionId = regionid 
      FROM   [TCD].plant 
      WHERE  ecolabaccountnumber = @EcolabAccountNumber 

      SELECT
			       PD.ID,
             PD.ProductID, 
             PM.sku, 
             ISNULL(NULLIF(PM.EnvisionDisplayName, ' '),PM.Name) AS NAME, 
             CASE 
               WHEN ( pm.sku IN (SELECT sku 
                                 FROM   [TCD].productdatamapping M 
                                 WHERE  M.sku = PM.sku 
                                        AND ecolabaccountnumber = 
                                            @EcolabAccountNumber 
                                        AND (M.is_deleted = 'False' OR M.is_deleted = @Is_Deleted))) THEN 
               (SELECT TOP 1 M.cost 
                FROM   [TCD].productdatamapping M 
                WHERE  M.sku = PM.sku 
                       AND ecolabaccountnumber = @EcolabAccountNumber 
                       AND (M.is_deleted = 'False' OR M.is_deleted = @Is_Deleted)
                ORDER  BY lastmodifiedtime DESC) 
               ELSE PM.cost 
             END     AS Cost, 
             PM.densityfactor, 
             PM.accepteddeviation, 
             PM.productcategoryid, 
             PM.[type], 
             PM.supplier, 
             PD.includeci, 
             PM.packagingsize, 
             PM.[weight], 
             PM.volume, 
             pc.NAME AS ProductCategoryName, 
             PD.ecolabaccountnumber, 
             PD.lastmodifiedtime, 
             PD.lastsynctime, 
			 PM.MyServiceProdId,
			 PD.InventoryExpense,
			 PS.UnitPerPackage,
			 PS.UnitWeightVolume,
			 PS.PackageSizeWeightUOMCode,
			 PD.is_deleted
      FROM   [TCD].productmaster PM 
             INNER JOIN [TCD].productdatamapping PD 
                     ON PM.productid = PD.productid 
             LEFT JOIN [TCD].productcategory pc 
                    ON PM.productcategoryid = PC.categoryid 
			LEFT JOIN	[TCD].PackageSize	PS
					ON	PM.PackageSizeId = PS.packagesizeid
      WHERE  PD.ecolabaccountnumber = @EcolabAccountNumber 
             AND PM.regionid = @RegionId 
             AND (PD.is_deleted = 'False' OR PD.is_deleted = @Is_Deleted)
		    AND PD.SKU NOT IN ('0','-1')
      SET NOCOUNT OFF; 
  END