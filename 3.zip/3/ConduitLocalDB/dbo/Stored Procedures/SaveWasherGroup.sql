﻿CREATE PROCEDURE TCD.SaveWasherGroup

(@EcolabAccountNumber NVARCHAR(25)

, @WasherGroupId INT

, @ControllerId INT

, @WasherGroupTypeId INT

, @WasherGroupName VARCHAR(100)

, @WasherGroupNumber VARCHAR(10)

, @LastModifiedByUserId INT

, @WasherDosingNumber INT  =  NULL)

AS

BEGIN

	INSERT INTO TCD.WasherGroup (EcolabAccountNumber, WasherGroupId, ControllerId, WasherGroupTypeId, WasherGroupName, WasherGroupNumber, LastModifiedByUserId, WasherDosingNumber)

		VALUES (@EcolabAccountNumber

			, @WasherGroupId

			, @ControllerId

			, @WasherGroupTypeId

			, @WasherGroupName

			, @WasherGroupNumber

			, @LastModifiedByUserId

			, @WasherDosingNumber

			)

END