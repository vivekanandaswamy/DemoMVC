﻿CREATE PROCEDURE [TCD].[GetActiveControllerTags]
(	
		@ControllerId INT
)

AS
SET NOCOUNT ON
BEGIN
		SELECT 
				Ct.ControllerId,		
				Ct.TagAddress,
				Tt.TagType,
				Tt.TagTypeId,
				Tt.TagDescription,				
				Ctrl.TopicName,
				Ctrl.ControllerTypeId,
				Ctrl.Active,
				Ctrl.IsDeleted		
		FROM TCD.ConduitController Ctrl 		
		INNER JOIN 
				TCD.ControllerTags Ct 
				ON Ct.ControllerId				=			Ctrl.ControllerId and Ct.Active=1
		INNER JOIN
				TCD.TagType Tt 
				ON Tt.TagType					=			Ct.Tagtype and Tt.Active=1

		WHERE	Ctrl.ControllerId				=			@ControllerId
		AND		Ctrl.Active						=			1 
		AND		Ctrl.IsDeleted					=			0
		ORDER BY Ctrl.ControllerId ASC
				
	END

