
/*   
 ==========================================================================================  
 Purpose:  Delete the Program Details.   

 Author:  Phani   

 --------------------------------------------------------------   
 August-19-2014 ENT: Initial version.   
 ==========================================================================================  
*/ 
CREATE PROCEDURE [TCD].[DeleteProgramDetails] (
			  @ProgramId INT,
			  @UserId INT

			--Adding these 3 param as part of re-factoring for integration with Synch/Configurator
			--Adding EcolabAccountNumber also, since it was missing...
		,	@EcolabAccountNumber				NVARCHAR(25)

		,	@LastModifiedTimestampAtCentral		DATETIME			=			NULL			--Nullable for local call; Synch/Central call will have to pass this -
																								--else, it will be treated as a local call
		,	@OutputLastModifiedTimestampAtLocal	DATETIME			=			NULL	OUTPUT
		) 
AS 
  BEGIN 
      SET nocount ON; 


DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()

DECLARE
		@OutputList						AS	TABLE		(
		LastModifiedTimestamp			DATETIME		)

SET		@OutputLastModifiedTimestampAtLocal			=			ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight SA0121

      IF EXISTS (SELECT 1 FROM [TCD].ProgramMaster WHERE ProgramId = @ProgramId)
	  BEGIN

			--If the call is not local, check that the LastModifiedTime matches with the central
			IF	(
					@LastModifiedTimestampAtCentral				IS NOT	NULL
				AND
				NOT	EXISTS	(	SELECT	1
								FROM	TCD.ProgramMaster		PM
								WHERE	PM.EcolabAccountNumber	=	@EcolabAccountNumber
									AND	PM.ProgramId			=	@ProgramId
									AND	PM.LastModifiedTime		=	@LastModifiedTimestampAtCentral
							)
				)
					BEGIN
							SET			@ErrorId				=	60000
							SET			@ErrorMessage			=	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
							RAISERROR	(@ErrorMessage, 16, 1)
							SET			@ReturnValue			=	-1
							RETURN		(@ReturnValue)
					END

			--Proceed to soft-delete, since it's either a local call or Synch. call with synch. time matching
			UPDATE [TCD].ProgramMaster SET Is_Deleted = 1 
				,	LastModifiedByUserId	=	@UserId
				,	LastModifiedTime		=	@CurrentUTCTime
			OUTPUT
				inserted.LastModifiedTime	AS	LastModifiedTimestamp
			INTO
				@OutputList	(
				LastModifiedTimestamp
			)

			WHERE ProgramId = @ProgramId
	  END

	  SELECT	TOP 1	
				@OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp
		FROM	@OutputList							O
	  
	  RETURN	(@ReturnValue)
  END 
