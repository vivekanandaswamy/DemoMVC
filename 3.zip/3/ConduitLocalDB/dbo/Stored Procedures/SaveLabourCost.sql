CREATE PROCEDURE [TCD].[SaveLabourCost] 
										@LaborCostId INT = NULL,
										@LaborTypeId Int = NULL,
										@LaborCost decimal(10,2) = NULL,				
										@EcolabAccountNumber nvarchar(25),
										@UserID INT ,
										@Scope varchar(100) OUTPUT,
										@OutputLaborCostId						INT						=	NULL	OUTPUT
										,@LastModifiedTimestampAtCentral			DATETIME				=	NULL
										,@OutputLastModifiedTimestampAtLocal		DATETIME				=	NULL	OUTPUT
AS 

SET NOCOUNT ON

		 BEGIN

DECLARE	
		@Output				VARCHAR(100)	=			''  
	,	@ReturnValue		INT				=			0
	,	@ErrorId			INT				=			0
	,	@ErrorMessage		NVARCHAR(4000)	=			N''
	,	@CurrentUTCTime		DATETIME		=			GETUTCDATE()

DECLARE
		@OutputList						AS	TABLE		(
		OutputLaborCostId				INT
		,LastModifiedTimestamp			DATETIME
		)

SET		@OutputLastModifiedTimestampAtLocal			=			ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight SA0121
SET		@Scope										=			ISNULL(@Scope, NULL)										--SQLEnlight SA0121
SET		@OutputLaborCostId							=			ISNULL(@OutputLaborCostId, NULL)							--SQLEnlight SA0121
SET		@LaborCostId								=			ISNULL(@LaborCostId, NULL)									--SQLEnlight SA0029


		 BEGIN

     IF NOT EXISTS (SELECT 1  FROM   [TCD].[LaborCost]  WHERE  LaborTypeId = @LaborTypeId AND EcolabAccountNumber = @EcolabAccountNumber)		  						   
	 
	 BEGIN 
							INSERT INTO [TCD].LaborCost   
										(
											LaborTypeId
											,Cost
											,EcolabAccountNumber
											,LastModifiedByUserId
										)
							OUTPUT
								inserted.LaborCostId			AS			LaborCostId
							,	inserted.LastModifiedTime		AS			LastModifiedTimestamp
							INTO
								@OutputList	(
								OutputLaborCostId
							,	LastModifiedTimestamp
							)   
							VALUES      (
											@LaborTypeId
											, @LaborCost
											, @EcolabAccountNumber
											, @UserID
										)  
				   SET @OutPut = '101'     
				   SET @Scope = @OutPut SELECT @Scope  
	 END

	 ELSE
								IF	(
									@LastModifiedTimestampAtCentral				IS NOT	NULL
									AND
									NOT	EXISTS	(	SELECT	1
											FROM	TCD.LaborCost		LC
											WHERE LC.EcolabAccountNumber = @EcolabAccountNumber
											AND LC.LaborTypeId = @LaborTypeId
											AND LC.LastModifiedTime = @LastModifiedTimestampAtCentral
										)
							)
								BEGIN
										SET			@ErrorId				=	60000
										SET			@ErrorMessage			=	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
										RAISERROR	(@ErrorMessage, 16, 1)
										SET			@ReturnValue			=	-1
										RETURN		(@ReturnValue)
								END
	 BEGIN
	UPDATE L   
								SET    
									L.Cost = @LaborCost,
									L.LaborTypeId = @LaborTypeId ,
									L.LastModifiedByUserId	= @UserID	,
									L.LastModifiedTime =	@CurrentUTCTime	  
							OUTPUT
								inserted.LaborCostId						AS			LaborCostId
							,	inserted.LastModifiedTime		AS			LastModifiedTimestamp
							INTO
								@OutputList	(
								OutputLaborCostId
							,	LastModifiedTimestamp
							)
							FROM [TCD].LaborCost L   
							WHERE 
							LaborTypeId = @LaborTypeId
							AND 
							EcolabAccountNumber = @EcolabAccountNumber 

				  SET @OutPut = '201'     
				  SET @Scope = @OutPut SELECT @Scope  
	 END

	 	SELECT	TOP 1	
		@OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp
	,	@OutputLaborCostId				=	O.OutputLaborCostId
					FROM	@OutputList		O

	RETURN	(@ReturnValue)

   END
   END
