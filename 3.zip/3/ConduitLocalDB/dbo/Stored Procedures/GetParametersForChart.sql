﻿
/*  
 ==========================================================================================  
 Purpose:  Fetching the parameter Values for Trending chart.  

 Author:  Premchand Yelavarthi  

 --------------------------------------------------------------  
 August-01-2014 ENT: Initial version.  
 ==========================================================================================  
 Exec [dbo].[usp_GetParametersforchart] 1
*/ 
CREATE PROCEDURE [TCD].[GetParametersForChart](@CharTypeID Int = NULL) 
AS 
  BEGIN 
      SET nocount ON; 

	  Select parameterID,Parametername,Min_Value,Max_Value from [TCD].ConduitChartparameterMapping where ChartTypeId in (@CharTypeID)
	  END

	  /*
	  select * from [TCD].TunnelReading


	  Truncate table [TCD].Tunnelreading


declare @Lowest_value_temp int = 10
declare @Highest_value_temp int = 90

declare @Lowest_value_pH int = 3
declare @Highest_value_pH int = 8

declare @Lowest_value_Conductivity int = 1
declare @Highest_value_Conductivity int = 3


declare @Lowest_value_Signal int = 1
declare @Highest_value_Signal int = 10


declare @Lowest_value_Weight int = 50
declare @Highest_value_Weight int = 300

Declare @Int1 int
Declare Cursor_sample Cursor
for
select top 10 id from [TCD].id_counter
open cursor_sample
fetch next from cursor_sample  into @int1 
while @@FETCH_STATUS = 0
begin
Insert into [TCD].TunnelReading
select 1,1,getdate(),17,cast(@Lowest_value_pH + (@Highest_value_pH-@Lowest_value_pH)*RAND() as numeric(36,2)),6,0,1,1,1
waitfor delay '00:00:00.01'
Insert into [TCD].TunnelReading
select 1,1,getdate(),15,ceiling(@Lowest_value_temp + (@Highest_value_temp-@Lowest_value_temp)*RAND()),60,0,1,1,1
waitfor delay '00:00:00.01'
Insert into [TCD].TunnelReading
select 1,1,getdate(),16,ceiling(@Lowest_value_Conductivity + (@Highest_value_Conductivity-@Lowest_value_Conductivity)*RAND()),2,0,1,1,1
waitfor delay '00:00:00.01'


Insert into [TCD].TunnelReading
select 1,1,getdate(),16623,ceiling(@Lowest_value_Signal + (@Highest_value_Signal-@Lowest_value_Signal)*RAND()),60,0,1,1,1
waitfor delay '00:00:00.01'
Insert into [TCD].TunnelReading
select 1,1,getdate(),16624,ceiling(@Lowest_value_Weight + (@Highest_value_Weight-@Lowest_value_Weight)*RAND()),60,0,1,1,1
waitfor delay '00:00:00.01'

Insert into [TCD].TunnelReading
select 1,2,getdate(),17,cast(@Lowest_value_pH + (@Highest_value_pH-@Lowest_value_pH)*RAND() as numeric(36,2)),6,0,1,1,1
waitfor delay '00:00:00.01'
Insert into [TCD].TunnelReading
select 1,2,getdate(),15,ceiling(@Lowest_value_temp + (@Highest_value_temp-@Lowest_value_temp)*RAND()),60,0,1,1,1
waitfor delay '00:00:00.01'
Insert into [TCD].TunnelReading
select 1,2,getdate(),16,ceiling(@Lowest_value_Conductivity + (@Highest_value_Conductivity-@Lowest_value_Conductivity)*RAND()),2,0,1,1,1
waitfor delay '00:00:00.01'

Insert into [TCD].TunnelReading
select 1,2,getdate(),16623,ceiling(@Lowest_value_Signal + (@Highest_value_Signal-@Lowest_value_Signal)*RAND()),60,0,1,1,1
waitfor delay '00:00:00.01'
Insert into [TCD].TunnelReading
select 1,2,getdate(),16624,ceiling(@Lowest_value_Weight + (@Highest_value_Weight-@Lowest_value_Weight)*RAND()),60,0,1,1,1
waitfor delay '00:00:00.01'

Insert into [TCD].TunnelReading
select 1,3,getdate(),17,cast(@Lowest_value_pH + (@Highest_value_pH-@Lowest_value_pH)*RAND() as numeric(36,2)),6,0,1,1,1
waitfor delay '00:00:00.01'
Insert into [TCD].TunnelReading
select 1,3,getdate(),15,ceiling(@Lowest_value_temp + (@Highest_value_temp-@Lowest_value_temp)*RAND()),60,0,1,1,1
waitfor delay '00:00:00.01'
Insert into [TCD].TunnelReading
select 1,3,getdate(),16,ceiling(@Lowest_value_Conductivity + (@Highest_value_Conductivity-@Lowest_value_Conductivity)*RAND()),2,0,1,1,1
waitfor delay '00:00:00.01'

Insert into [TCD].TunnelReading
select 1,3,getdate(),16623,ceiling(@Lowest_value_Signal + (@Highest_value_Signal-@Lowest_value_Signal)*RAND()),60,0,1,1,1
waitfor delay '00:00:00.01'
Insert into [TCD].TunnelReading
select 1,3,getdate(),16624,ceiling(@Lowest_value_Weight + (@Highest_value_Weight-@Lowest_value_Weight)*RAND()),60,0,1,1,1
waitfor delay '00:00:00.01'
fetch next from cursor_sample  into @int1
end
Close cursor_sample
Deallocate cursor_sample

*/