﻿CREATE PROCEDURE [TCD].[SaveAbPlcConventionalBatchData]
(
@WasherId INT
,@RecordedTime DATETIME=NULL
,@OperationalCount INT=NULL
,@CurrentFormula INT=NULL
,@CurrentInjection	INT=NULL
,@IsNewBatch BIT = 0 
,@IsEndOfBatch BIT = 0
)
AS
SET NOCOUNT ON
BEGIN
	DECLARE @EcolabWaherId INT,
		@EndofFormula INT=128, -- This value is sent through the application.
		@StandardWeight VARCHAR(100) , 
		@CurrencyCode VARCHAR(50),
		@Batch_ID INT,
		@MachineInternalId INT ,
		@GroupId INT 

		SET		@CurrentInjection			=			ISNULL(@CurrentInjection, NULL)			--SQLEnlight SA0029


		SELECT @EcolabWaherId=EcolabWasherId FROM [TCD].Washer WHERE WasherId= @WasherId
	BEGIN TRY
		SELECT @RecordedTime = COALESCE(@RecordedTime,GETUTCDATE())
		IF (@IsNewBatch = 1 )
		BEGIN		
			SELECT DISTINCT @StandardWeight =  cps.NominalLoad ,
						    @CurrencyCode = Pl.CurrencyCode 

			FROM [TCD].Washer Ws
				INNER JOIN [TCD].MachineSetup MST ON MST.WasherId = Ws.WasherId
				INNER JOIN [TCD].WasherGroup WG ON WG.WasherGroupId = MST.GroupId				
				INNER JOIN [TCD].WasherProgramSetup CPS ON CPS.WasherGroupId = WG.WasherGroupId
				INNER JOIN [TCD].WasherDosingSetup CDS ON CDS.WasherProgramSetupId = CPS.WasherProgramSetupId
				INNER JOIN [TCD].WasherDosingProductMapping CDPM ON CDPM.WasherDosingSetupId = CDS.WasherDosingSetupId
				INNER JOIN [TCD].Plant Pl on Pl.EcolabAccountNumber=Ws.EcoLabAccountNumber
			WHERE Ws.WasherId=@WasherId AND CPS.ProgramNumber=@CurrentFormula

			INSERT INTO [TCD].BatchData(
						ControllerBatchId ,
						EcolabWasherId,
						GroupId ,
						MachineInternalId,
						StartDate ,
						EndDate ,
						ProgramNumber,
						ActualWeight,
						StandardWeight,
						CurrencyCode)


			SELECT DISTINCT 0
						,@EcolabWaherId
						,MST.GroupId
						,Mst.MachineInternalId
						,@RecordedTime AS StartDate
						,NULL
						,@CurrentFormula
						,NULL
						,@StandardWeight[StandardWeight] 
						,@CurrencyCode[CurrencyCode] 

			FROM [TCD].Washer Ws
			INNER JOIN [TCD].MachineSetup MST ON MST.WasherId = Ws.WasherId
			INNER JOIN [TCD].WasherGroup WG ON WG.WasherGroupId = MST.GroupId
			INNER JOIN [TCD].WasherGroupType WGT ON WGT.WasherGroupTypeId = WG.WasherGroupTypeId
			WHERE Ws.WasherId=@WasherId 
			
				SET @Batch_ID=SCOPE_IDENTITY()	
			
			INSERT INTO [TCD].BatchProductData(BatchId,StepCompartment,ProductId,ActualQuantity,StandardQuantity,Price)
			SELECT @Batch_ID		
				,NULL--CDS.StepNumber        
				,CDPM.ProductId
				,NULL
				,CDPM.Quantity AS StandardQuantity
				,NULL
			FROM [TCD].Washer WS
				INNER JOIN [TCD].MachineSetup MST ON MST.WasherId = ws.WasherId
				INNER JOIN [TCD].WasherGroup WG ON WG.WasherGroupId = MST.GroupId
				INNER JOIN [TCD].WasherGroupType WGT ON WGT.WasherGroupTypeId = WG.WasherGroupTypeId
				INNER JOIN [TCD].WasherProgramSetup CPS ON CPS.WasherGroupId = WG.WasherGroupId
				INNER JOIN [TCD].WasherDosingSetup CDS ON CDS.WasherProgramSetupId = CPS.WasherProgramSetupId
				LEFT JOIN [TCD].WasherDosingProductMapping CDPM ON CDPM.WasherDosingSetupId = CDS.WasherDosingSetupID
			WHERE Ws.WasherId=@WasherId AND CPS.ProgramNumber=@CurrentFormula



		END	

		ELSE IF(@IsEndOfBatch = 1 )
		BEGIN
			
			IF EXISTS (SELECT TOP 1 * FROM [TCD].BatchData WHERE  EcolabWasherId =@EcolabWaherId AND EndDate IS NULL ORDER BY StartDate DESC  )
			BEGIN				
				DECLARE @BatchID INT 
				SELECT TOP 1 @BatchID = BatchId FROM [TCD].BatchData WHERE  EcolabWasherId = @EcolabWaherId AND EndDate IS NULL ORDER BY StartDate DESC  
					UPDATE [TCD].BatchData
					SET EndDate= @RecordedTime
					WHERE  BatchId=@BatchId
			END 	
		END
		IF (@IsEndOfBatch <> 1 )
			BEGIN
				SELECT @MachineInternalId=MachineInternalId,@GroupId=GroupId 
				FROM [TCD].MachineSetup WHERE WasherId=@WasherId
				--INSERT INTO [TCD].WasherReading(
				--	GroupId,MachineInternalId,
				--	WasherId,
				--	ProgramNumber,
				--	CurrentInjection,
				--	OperationCounter,
				--	DosingAmount,
				--	CreatedDate) 
				--VALUES(@MachineInternalId ,
				--	@GroupId, 
				--	@WasherId , 
				--	@CurrentFormula,
				--	@CurrentInjection,
				--	@OperationalCount,
				--	NULL,
				--	GETUTCDATE())
			END
	END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;
			SELECT		@ErrorMessage = ERROR_MESSAGE(),
						@ErrorSeverity = ERROR_SEVERITY(),
						@ErrorState = ERROR_STATE();
			RAISERROR ( @ErrorMessage, -- Message text.
						@ErrorSeverity, -- Severity.
						@ErrorState -- State.
					  );
	END CATCH;
END