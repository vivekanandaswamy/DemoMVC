﻿/*	
Purpose					:	To add a new Conventional Washer from the Washer setup UI - General tab

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version

--sp_helptext	usp_AddConventional

*/

CREATE PROCEDURE [TCD].[GetManualRewashProductData]
 (
			@RewashId INT, 
			@EcolabAccountNumber NVARCHAR(25) 
 )
AS 
  BEGIN 
     SET NOCOUNT ON 
	 
	  SELECT  
				  RewashId, 
				  ProductId,
				  Quantity,
				  Price,
				  TotalRewashLoad,
				  CustomerId,
				  [Date]
      FROM   
			 [TCD].RewashProductData 
	  WHERE 
				  
				  RewashId = @RewashId
				  AND EcolabAccountNumber = @EcolabAccountNumber
          ORDER BY RewashId DESC
  SET NOCOUNT OFF
		  END