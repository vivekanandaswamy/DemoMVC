﻿ 
/*
Purpose					:	Generater Red flags for Efficiency

Author: Suresh k
Date:28-Dec-2015

exe TCD.RedFlagGenerationProductionEfficiency 1,'2015-12-1','040242802'

*/
CREATE PROCEDURE [TCD].[RedFlagGenerationProductionEfficiency]( @ShiftId int , 
                                                       @PartitionOn smalldatetime , 
                                                            @EcolabAccountNumber varchar( 1000))
AS
BEGIN

  DECLARE
       @Value decimal( 18 , 3) , 
    @UOMId int,
    @RegionId int,
       @PlantId int;

    SELECT
            @PlantId = PlantId
   ,@UOMId=UOMId
   ,@RegionId=RegionId
      FROM TCD.Plant p
      WHERE p.EcolabAccountNumber = @EcolabAccountNumber;

    DECLARE
       @Redflag TABLE(
            CounterId int IDENTITY( 1 , 1) , 
            Id int , 
            Item int
                     );

    DECLARE
       @MaxId int , 
       @Counter int , 
       @Item int , 
       @ShiftHrs float , 
       @Id int;

    
     DECLARE   --@DashBoardId INT = 2,
        @Efficiencytype INT,
 @OvernightBatchThreshold INT = 7200 -- mins


declare @RedflagTemp TABLE (Id INT,
Item INT,
MaximumRange decimal(18,3),
MinimumRange decimal(18,3),
Location INT,
RedFlagCategoryId INT,
FormulaId INT,
ProductId INT,
MeterId INT,
SensorId INT,
PlantId INT ,
MachineId INT)

INSERT INTO @RedflagTemp (Id ,
 Item ,
 MaximumRange ,
 MinimumRange ,
 Location ,
 RedFlagCategoryId ,
 FormulaId ,
 ProductId ,
 MeterId ,
 SensorId ,
 PlantId  ,
 MachineId )

SELECT rf.Id,
 Item,
 MaximumRange,
 MinimumRange,
 Location,
 RedFlagCategoryId,
 rf.FormulaId,
 ProductId,
 MeterId,
 SensorId,
 PlantId ,
 rfmd.MachineId
 
FROM TCD.RedFlag rf
LEFT JOIN tcd.RedFlagMappingData rfmd ON rfmd.MappingId = rf.Id
LEFT JOIN TCD.MachineSetup ms ON rfmd.MachineId=ms.WasherId
LEFT JOIN TCD.WasherGroup wg ON ms.GroupId= wg.WasherGroupId
LEFT JOIN TCD.ProgramMaster PM ON rf.FormulaId=PM.ProgramID
WHERE rf.Is_Deleted=0 and rfmd.Is_Deleted = 0 



    INSERT INTO @Redflag(Id, Item )
    SELECT
            rf.Id , 
            rf.Item
      FROM TCD.RedFlag rf
      WHERE rf.Is_Deleted = 0
        AND rf.RedFlagCategoryId in (1);

    SELECT
            @MaxId = ISNULL( MAX( CounterId) , 0)
      FROM @Redflag r;

    SET @Counter = 1;

 SELECT bd.*   
 INTO #BatchData  
 FROM tcd.BatchData bd (NOLOCK) 
 INNER JOIN TCD.MachineSetup ms  (NOLOCK)  on bd.MachineId=ms.WasherId AND isnull(ms.IsPony,0)=0
 WHERE bd.ShiftId =@ShiftId 
 --AND bd.StandardWeight > 0  
 --and bd.ActualWeight > 0   
 and bd.EndDate IS NOT NULL

 
 SELECT ms.EcoalabAccountNumber,    
                        ms.WasherId,    
                        ms.GroupId AS WasherGroupID,    
                        mg.WasherGroupTypeId AS WasherGroupTypeID,    
                        w.EcolabWasherId,    
                        ISNULL(ms.NumberOfComp,0) AS NumberOfComp,    
                        CASE    
                        WHEN MG.WASHERGROUPTYPEID = 1 THEN WSP.ProgramNumber    
                            ELSE TPS.ProgramNumber    
                        END AS ProgramNumber,    
                        CASE    
                        WHEN MG.WASHERGROUPTYPEID = 1 THEN WSP.ProgramId    
       ELSE TPS.ProgramId    
                        END AS ProgramId,    
                        CASE    
       WHEN MG.WASHERGROUPTYPEID = 1 
    THEN WSP.TotalRunTime    
                            ELSE TPS.TotalRunTime    
    
   END AS Standardruntime,
   w.PlantWasherNumber AS WasherNumber,
   ms.MachineName AS WasherName,
   mg.WasherGroupName AS MachineGroup,
   ms.IsTunnel
Into #BatchDataTurntime
                    FROM TCD.MachineSetup AS ms (NOLOCK)    
                        INNER JOIN TCD.Washer AS w (NOLOCK) ON w.EcoLabAccountNumber = ms.EcoalabAccountNumber    
                                                    AND w.WasherId = ms.WasherId    
                        INNER JOIN TCD.WasherGroup AS mg (NOLOCK) ON ms.GroupId = mg.WasherGroupId    
                                                        AND w.EcoLabAccountNumber = mg.EcolabAccountNumber    
                        LEFT OUTER JOIN TCD.WasherProgramSetup AS WSP (NOLOCK) ON WSP.WasherGroupId = mg.WasherGroupId    
                                                                    AND WSP.EcolabAccountNumber = mg.EcolabAccountNumber    
                                                                    --AND WSP.WasherGroupId = ms.GroupId    
                 AND WSP.Is_Deleted = 0
                        LEFT OUTER JOIN TCD.TunnelProgramSetup AS TPS (NOLOCK) ON TPS.WasherGroupId = mg.WasherGroupId    
                                                                    AND TPS.EcolabAccountNumber = mg.EcolabAccountNumber    
                                                                    --AND TPS.WasherGroupId = ms.GroupId 
                 AND TPS.Is_Deleted = 0 
   --WHERE ms.IsTunnel = 1
  
  
  SELECT TT.* INTO #Turntime
  FROM #BatchData BD
  LEFT JOIN TCD.Turntime TT
      ON BD.EcolabwasherID = TT.EcolabWasherId
      AND BD.batchid = TT.BatchID 

 SELECT  bd.BatchId,  
  bd.GroupID,
  bd.MachineID,
  bd.ShiftId,
  W_1.WasherNumber,
  W_1.WasherName,
  bd.ProgramNumber,
  bd.EcolabwasherID,
  bd.PartitionOn,
  BD.ProgramMasterId,

  (bd.ActualWeight + ISNULL(BD.ManualInputWeight,0)) AS ActualProduction,
  bd.StandardWeight AS StandardProduction,
  bd.StartDate,
  bd.EndDate,
  W_1.NumberOfComp,
  W_1.WasherGroupTypeID,
  --DATEDIFF(ss,bd.StartDate, bd.EndDate) AS ActualRunTime,
  --CASE WHEN DATEDIFF(mi,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OvernightBatchThreshold 
  CASE WHEN DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @OvernightBatchThreshold 
   THEN W_1.Standardruntime 
       ELSE DATEDIFF(second,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
  END AS ActualRunTime,
  W_1.StandardRunTime StandardRunTime,
  TT.ACTUALTURNTIME AS ActualTurnTime,  
  (CASE WHEN W_1.WasherGroupTypeID = 1 THEN bd.TargetTurnTime ELSE 0 END) AS TargetTurnTime, 
  
    0 AS TimeEfficiency,
  ((CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS FLOAT)/CAST(NULLIF(bd.StandardWeight,0) AS FLOAT)) * 100) AS LoadEfficiency,
  
  0 TransferPerHr,

  0 AS MissedLoads,

  ((CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS decimal(18,6))/  nullif((nullif(CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS FLOAT)
        /nullif(CASE   CAST(NULLIF(bd.StandardWeight,0) AS FLOAT) WHEN 0 THEN 1 ELSE  CAST(NULLIF(bd.StandardWeight,0) AS FLOAT) END,0),0) * 100)   
  * (  CASE WHEN W_1.WasherGroupTypeID = 1   
      -- Conventional  
      THEN (CAST((W_1.Standardruntime + bd.TargetTurnTime)AS FLOAT) / nullif(CAST(CASE WHEN DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > 7200  
                   THEN W_1.StandardRunTime  
                   ELSE DATEDIFF(ss,bd.StartDate, ISNULL(bd.EndDate, GETDATE()))  
                  END + TT.ACTUALTURNTIME AS FLOAT),0) )  
      -- Tunnel  
      ELSE   
   0
                  
    END),0) ) *100 ) - CAST((bd.ActualWeight + ISNULL( BD.ManualInputWeight,0)) AS decimal(18,6)) AS LostLoadsDueToTurnTime,


  0 AS TotalEfficiency


INTO #BatchEfficiency
FROM #BatchData bd  
--FROM TCD.BatchData bd   
LEFT JOIN #BatchDataTurntime AS W_1 ON BD.GroupId = W_1.WasherGroupID    
       AND BD.MachineId = W_1.WasherId    
       AND BD.ProgramMasterId = W_1.ProgramId    
       AND BD.ProgramNumber = W_1.ProgramNumber
LEFT JOIN #Turntime TT
      ON BD.EcolabwasherID = TT.EcolabWasherId
      AND BD.batchid = TT.BatchID
--WHERE bd.ProgramNumber <> 0
  WHERE ISNULL(bd.ProgramMasterId,0) <> 0



/*  looping started*/
    WHILE  @Counter <=  @MaxId
        BEGIN
            SELECT
                    @Id = Id , 
                    @Item = Item
              FROM @Redflag r
              WHERE CounterId = @Counter;
          
            
            
           
              IF @Item = 1
                       BEGIN
    --Overall Efficiency (% per shift) (tatal efficeency)

   
      SELECT @Value = (( ( SUM(bd.ActualProduction) * 1.00 / SUM(ISNULL( bd.StandardProduction,0)) ) * 100 ) * SUM(ISNULL( bd.StandardRunTime, 0) + ISNULL( bd.TargetTurnTime, 0)) * 1.00 / SUM(ISNULL( bd.ActualRunTime, 0) + ISNULL( bd.ActualTurnTime, 0)))
           
      FROM #BatchEfficiency bd 
       LEFT JOIN @RedflagTemp rf ON(rf.Location = bd.GroupId OR rf.Location = 1) AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0 ) = 0)       
      WHERE(bd.MachineId = rf.MachineId  OR rf.MachineId IS NULL)
       AND bd.ShiftId = @ShiftId
          AND rf.Id = @Id;
     
     if (@Value=0)
     BEGIN
      SET @Value = NULL
     END

   END
            ELSE IF @Item = 2
      BEGIN
                --Run Time Efficiency (% per shift)--TimeEfficiency

                SELECT
                      --  @Value = SUM(isnull( TimeEfficiency,0))/100.00
       --@Value=sum(StandardRunTime)/cast( sum(ActualRunTime) as decimal(18,2))*100
	   @Value = SUM(bd.StandardRunTime + bd.TargetTurnTime) / CAST(SUM(bd.ActualRunTime + ISNULL(bd.ActualTurnTime,0)) AS decimal(18,2)) *100
                    FROM
                        #BatchEfficiency  bd 
      INNER JOIN @RedflagTemp rf ON(rf.Location = bd.GroupId  OR rf.Location = 1) AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0 ) = 0)  
                    WHERE(bd.MachineId = rf.MachineId  OR rf.MachineId IS NULL)
                    AND bd.ShiftId = @ShiftId
                   -- AND PartitionOn = @PartitionOn
                    AND rf.Id = @Id;

            END
   
            ELSE IF @Item = 3
                   BEGIN
                    --Turn Time Efficiency (% per shift) -- Turn time only avilble for Conventional
      SELECT
         @Value = sum(TargetTurnTime)/cast( sum(ActualTurnTime) as decimal(18,2)) *100
         FROM
           #BatchEfficiency bd           
           INNER JOIN @RedflagTemp rf ON(rf.Location = bd.GroupId OR rf.Location = 1) 
         WHERE ( bd.MachineId = rf.MachineId or rf.MachineId IS NULL)
        AND bd.ShiftId = @ShiftId
        --AND PartitionOn = @PartitionOn
        AND rf.Id = @Id;
     END
    ELSE IF @Item = 4
                    BEGIN
                    --Transfers / Hour (# per shift) --TransferPerHr
                    SELECT
                            @Value =round( 3600.00/(sum( ActualRunTime)/sum(NumberOfComp)),0)
                        FROM
                            #BatchEfficiency bd 
       INNER JOIN @RedflagTemp rf  ON(rf.Location = bd.GroupId  OR rf.Location = 1)  AND (bd.ProgramMasterId = rf.FormulaId
          OR ISNULL( rf.FormulaId , 0 ) = 0) 
                        WHERE ( bd.MachineId = rf.MachineId or rf.MachineId IS NULL)
                        AND bd.ShiftId = @ShiftId
      and bd.WasherGroupTypeID=2
                       -- AND PartitionOn = @PartitionOn
                        AND rf.Id = @Id;

                END
   IF @Item = 11
                BEGIN
      --Production vs Target (% per shift)
     declare @TargetProduction decimal(18,2) 
     select @TargetProduction=TargetProduction from TCD.ProductionShiftData where ShiftId =@ShiftId

                     SELECT   @Value = (SUM( bd.ActualProduction) /(case @TargetProduction when 0 then 1 else @TargetProduction end))/100.00
                              FROM
                                  #BatchEfficiency bd 
          INNER JOIN @RedflagTemp rf ON(rf.Location = bd.GroupId OR rf.Location = 1)  
                              WHERE bd.ShiftId = @ShiftId
                             --  AND PartitionOn = @PartitionOn
                               AND rf.Id = @Id;

                END
            ELSE IF @Item = 12
                        BEGIN
                            --Lost Capacity (CWT/Kg per shift) --MissedLoads

                            SELECT
                                    @Value = ( sum(bd.ActualProduction) / 
           (((sum(bd.ActualProduction)/sum( bd.StandardProduction))*100 )
           * sum(isnull( bd.StandardRunTime,0) +isnull( bd.TargetTurnTime,0))*1.00/sum(isnull( bd.ActualRunTime,0) +isnull( bd.ActualTurnTime,0) )))*100
           - sum(bd.ActualProduction)
                              FROM
                                  #BatchEfficiency bd 
          INNER JOIN @RedflagTemp rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
            AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0)                                                   
                              WHERE(bd.MachineId = rf.MachineId OR rf.MachineId IS NULL)
                               AND bd.ShiftId = @ShiftId
                             --  AND PartitionOn = @PartitionOn
                               AND rf.Id = @Id;
                        END
            ELSE IF @Item = 13
                        BEGIN
                                    --Production (CWT/Kg per hour)
                                    --SELECT
                                    --        @ShiftHrs = DATEDIFF( ss , sd.StartDateTime , sd.EndDateTime)/360.00
                                    --  FROM TCD.ProductionShiftData sd
                                    --  WHERE sd.ShiftId = @ShiftId;
           -- if EU Convert to lbs to kg
                                    SELECT
                                            @Value =   SUM( bd.ActualProduction) * (case @UOMId when 1 then 1 else 0.453592 end) --/ (case when @ShiftHrs =0 then 1 else @ShiftHrs end)
                                      FROM
                                           #BatchEfficiency bd 
             INNER JOIN @RedflagTemp rf ON(rf.Location = bd.GroupId OR rf.Location = 1)AND (bd.ProgramMasterId = rf.FormulaId
                 OR ISNULL( rf.FormulaId , 0) = 0) 
                                      WHERE(bd.MachineId = rf.MachineId OR rf.MachineId IS NULL)
                                       AND bd.ShiftId = @ShiftId
                                      -- AND PartitionOn = @PartitionOn
                                       AND rf.Id = @Id;
          

                                END
   ELSE IF @Item = 14
                        BEGIN
                        --Production Mix (% per shift)
                       
      SELECT
                            @Value =  convert( float,  sum(CASE  WHEN bd.ProgramMasterId = rf.FormulaId OR  ISNULL( rf.FormulaId , 0) = 0 THEN  bd.ActualProduction end)/convert(float,nullif(sum(sum(bd.ActualProduction))over(),0)))*100.00 
                        FROM
                            #BatchEfficiency bd 
       INNER JOIN @RedflagTemp rf ON(rf.Location = bd.GroupId OR rf.Location = 1) 
                        WHERE(bd.MachineId = rf.MachineId OR rf.MachineId IS NULL)
                        AND bd.ShiftId = @ShiftId
                       -- AND PartitionOn = @PartitionOn
                        AND rf.Id = @Id;
                    END
    ELSE IF @Item = 15
                        BEGIN
                    --Number of Loads (# per shift) (Count of bach ids)
                    --TODO

                    SELECT
                            @Value = COUNT( DISTINCT bd.BatchId )
                        FROM
                            #BatchEfficiency bd 
       INNER JOIN @RedflagTemp rf ON(rf.Location = bd.GroupId OR rf.Location = 1) AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0)
             
                        WHERE(bd.MachineId = rf.MachineId OR rf.MachineId IS NULL)
                        AND bd.ShiftId = @ShiftId
                        --AND PartitionOn = @PartitionOn
                        AND rf.Id = @Id;
                END
    ELSE IF @Item = 16
                        BEGIN
                  -- Load Efficiency (% per shift)

                    SELECT
                            @Value = (SUM(bd.ActualProduction)/cast( SUM(bd.StandardProduction) AS float)) *100.00

                        FROM
                            #BatchEfficiency bd 
       INNER JOIN @RedflagTemp rf ON(rf.Location = bd.GroupId OR rf.Location = 1) AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0)
             
                        WHERE(bd.MachineId = rf.MachineId OR rf.MachineId IS NULL)
                        AND bd.ShiftId = @ShiftId
                      --  AND PartitionOn = @PartitionOn
                        AND rf.Id = @Id;
                END
   ELSE IF @Item = 17
       BEGIN
                           --Average Run Time (time, avg per shift)--RunTime
        SELECT
         @Value = sum ( DATEDIFF(Minute,bd.StartDate, bd.EndDate) )/cast( COUNT(distinct bd.BatchId) as float)
         FROM
           #BatchEfficiency bd 
           INNER JOIN @RedflagTemp rf ON(rf.Location = bd.GroupId OR rf.Location = 1) 
                 AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0) 
         WHERE ( bd.MachineId = rf.MachineId or rf.MachineId IS NULL)
        AND bd.ShiftId = @ShiftId
       -- AND PartitionOn = @PartitionOn
        AND rf.Id = @Id;
                END
             ELSE IF @Item = 18
                  BEGIN
     --Lost Loads due to Turn Time (# per shift)-- Only convetional missed loads
     SELECT
       @Value = SUM(LostLoadsDueToTurnTime)
      FROM
       #BatchEfficiency bd 
       INNER JOIN @RedflagTemp rf  ON(rf.Location = bd.GroupId  OR rf.Location = 1)
             AND (bd.ProgramMasterId = rf.FormulaId  OR ISNULL( rf.FormulaId , 0  ) = 0)        
      WHERE(bd.MachineId = rf.MachineId  OR rf.MachineId IS NULL)
      AND bd.ShiftId = @ShiftId
      --AND PartitionOn = @PartitionOn
      AND rf.Id = @Id;
              END;
              ELSE IF @Item = 19
                   BEGIN
                        --Average Turn Time (time, avg per shift) 
                       SELECT
         @Value = (SUM ( bd.ActualTurnTime )/60)/cast( COUNT(DISTINCT bd.BATCHID) as float)
         FROM
            #BatchEfficiency bd           
           INNER JOIN @RedflagTemp rf ON(rf.Location = bd.GroupId OR rf.Location = 1) 
         WHERE (bd.MachineId = rf.MachineId or rf.MachineId IS NULL)
        AND bd.ShiftId = @ShiftId
       -- AND PartitionOn = @PartitionOn
        AND rf.Id = @Id;
                    END
             
               ELSE  IF @Item = 10
                  BEGIN
                    --Drying Efficiency
                    SET @Value = 0;
     END;
             
            IF @Value IS NOT NULL 
   BEGIN
            IF NOT EXISTS( SELECT
                                   1
                             FROM TCD.RedFlag rf
                             WHERE Id = @Id
                               AND rf.Is_Deleted = 0
                               AND rf.MinimumRange <= @Value
                               AND rf.MaximumRange >= @Value
                         )
                BEGIN

                    IF NOT EXISTS( SELECT
                                           1
                                     FROM TCD.RedFlagData rfd
                                     WHERE rfd.RedFlagId = @Id
                                       AND rfd.ShiftId = @ShiftId
                                             -- AND PartitionOn = @PartitionOn
                                 )
                        BEGIN
                            INSERT INTO TCD.RedFlagData(
                                    RedFlagId , 
                                    PlantId , 
                                    ShiftId , 
                                    RedFlagValue , 
                                    RedFlagMinSetPoint , 
                                    RedFlagMaxSetPoint , 
                                    PartitionOn
                                                       )
                            SELECT
                                    rf.Id , 
                                    @PlantId , 
                                    @ShiftId , 
                                    @Value , 
         rf.MinimumRange , 
                                    rf.MaximumRange ,                                     
                                    @PartitionOn
                              FROM TCD.RedFlag rf
                              WHERE rf.Id = @Id;

                        END;

                END;
   END

            SET @Counter = @Counter + 1;
        END;

DROP TABLE #BatchData
DROP TABLE #BatchEfficiency
DROP TABLE #BatchDataTurntime
DROP TABLE #Turntime
END;
GO

