CREATE PROC TCD.SaveMixingVessels (          
 @MixingVessels TCD.udttMixingVessels READONLY          
    , @ControllerId INT            
    , @EcolabAccountNumber NVARCHAR(25)          
)          
AS          
BEGIN          
    DECLARE          
            
     @PlantId INT = (SELECT TOP 1 PlantId          
     FROM TCD.Plant P          
       WHERE P.EcolabAccountNumber = '@EcolabAccountNumber')        
             
            
    DECLARE          
     @TempMapping TABLE(          
     RowNumber INT NOT NULL  ,       
     [MixingVesselNumber]   [INT],   
 [MinimumLevel] [int]  ,        
 [FlushTime] [SMALLINT] ,        
 [PumpingTime] [SMALLINT] ,        
 [MaxTimeWaterValve] [INT] ,    
 [MaxEmtyingTime] [INT] ,    
 [CalibrationScale] [INT] ,    
 [MaximumVesselCapacity] [INT] ,    
 [WeightCell] [BIT] ,    
 [DirectDose] [BIT]);    
     
          
    /* Create RowNumber inorder to increment and use row by row. */          
          
    WITH CTE_LCM          
    AS (          
    SELECT ROW_NUMBER() OVER (ORDER BY MV.[MixingVesselNumber] ) AS RowNumber    
   , [MixingVesselNumber]       
  , MV.[MinimumLevel]        
     , MV.[FlushTime]        
     , MV.[PumpingTime]        
     , MV.[MaxTimeWaterValve]    
     , MV.[MaxEmtyingTime]     
     , MV.[CalibrationScale]      
     , MV.[MaximumVesselCapacity]    
     , MV.[WeightCell]    
     , MV.[DirectDose]    
  FROM @MixingVessels MV          
    )          
    INSERT INTO @TempMapping          
    SELECT *          
  FROM CTE_LCM CL ;          
          
    /* Loop */          
          
    DECLARE          
     @i INT = 1,          
     @max INT = (SELECT MAX(TM.RowNumber)          
       FROM @TempMapping TM);          
    WHILE @i <= @max          
    BEGIN          
          
    /* Declare and Initialize the current row data */          
          
    DECLARE          
     @MinimumLevel INT         
    SELECT TOP 1 @MinimumLevel = TM.MinimumLevel          
      FROM @TempMapping TM          
      WHERE TM.RowNumber = @i;          
            
          
    /* Update If Exists else Insert */          
          
    MERGE TCD.MixingVessels M          
    USING (SELECT TOP 1 *          
     FROM @TempMapping TM          
     WHERE TM.RowNumber = @i) S          
    ON M.ControllerId = @ControllerId          
   AND M.MixingVesselNumber = S.MixingVesselNumber      
         
   --AND S.ProductId > 0        
    WHEN MATCHED          
      THEN          
      UPDATE SET --T.TunnelNumber = S.TunnelNumber                   
        M.MinimumLevel = S.MinimumLevel        
 , M.FlushTime = S.FlushTime        
 , M.PumpingTime = S.PumpingTime    
 , M.MaxTimeWaterValve = S.MaxTimeWaterValve    
 , M.MaxEmtyingTime = S.MaxEmtyingTime    
 , M.CalibrationScale = S.CalibrationScale    
 , M.MaximumVesselCapacity = S.MaximumVesselCapacity    
 , M.WeightCell = S.WeightCell    
 , M.DirectDose = S.DirectDose        
 , M.ControllerId = @ControllerId        
 , M.EcolabAccountNumber = @EcolabAccountNumber        
                
    WHEN NOT MATCHED          
      THEN          
      INSERT (    
      MixingVesselNumber      
      ,EcolabAccountNumber     
    ,ControllerId        
   ,MinimumLevel        
   ,FlushTime        
   ,PumpingTime        
   ,MaxTimeWaterValve    
   ,MaxEmtyingTime      
   ,CalibrationScale    
   ,MaximumVesselCapacity    
   ,WeightCell    
   ,DirectDose    
   )          
      VALUES (MixingVesselNumber,  
      @EcolabAccountNumber,    
      @ControllerId,          
      S.MinimumLevel,          
      S.FlushTime,          
      S.PumpingTime,          
      S.MaxTimeWaterValve,    
      S.MaxEmtyingTime,    
      S.CalibrationScale,    
      S.MaximumVesselCapacity,    
      S.WeightCell,    
      S.DirectDose    
   );          
          
    /* Increment the row */          
          
    SET @i = @i + 1;          
    END;          
END; 