﻿CREATE PROCEDURE [TCD].[GetAlarmSetupDetails](	@ControllerModelId INT, 
												@ControllerTypeId  INT, 
												@MachineNumber     INT = NULL,-- Null for Getting Alarms associated with ControllerModel and ControllerType   
												@WasherGroupTypeId INT, 
												@WasherId          INT = NULL) 
AS 
BEGIN 
	SET NOCOUNT ON 

	DECLARE @washerType nchar(10)

	IF( @WasherGroupTypeId = 1 )
		BEGIN
			SET @washerType = 'C'
		END
	ELSE IF ( @WasherGroupTypeId = 2 )
		BEGIN
			SET @washerType = 'T'
		END
	ELSE
		BEGIN
			SET @washerType = 'G'
		END

	IF @ControllerModelId = 11
		BEGIN 
			SELECT AGM_V_CMT.AlarmCode,
					AGM.[Description],
					AGM_V_CMT.AlarmGroupMsterVsControllerModelTypeId AS AlarmMachineMappingId,
					AGM_V_CMT.DisplayOrder,
					AGM_V_CMT.IsDefault,
					CASE
					WHEN ALS.Active = 1 
							OR AGM_V_CMT.IsDefault = 1 THEN CAST(1 AS BIT) 
					 ELSE CAST(0 AS BIT) 
					END AS Active, 
					AGM.ResourceKey 
			FROM [TCD].AlarmGroupMaster AGM
					INNER JOIN [TCD].[AlarmGroupMsterVsControllerModelType] AGM_V_CMT
							ON AGM.AlarmGroupMasterId = AGM_V_CMT.AlarmGroupMasterId
					INNER JOIN [TCD].ControllerModelControllerTypeMapping CMTM
							ON CMTM.Id = AGM_V_CMT.ControllerModelTypeId
					LEFT JOIN [TCD].AlarmStatus ALS
							ON ALS.[AlarmGroupMsterVsControllerModelTypeId] = AGM_V_CMT.AlarmGroupMsterVsControllerModelTypeId
								AND ALS.WasherId = @WasherId
			WHERE ( AGM.WasherType = @washerType
						OR AGM.WasherType = 'G' )
					AND AGM.IsDelete = 0 
					AND AGM_V_CMT.IsDelete = 0 
					AND CMTM.ControllerModelId = @ControllerModelId 
					AND CMTM.ControllerTypeId = @ControllerTypeId 
					AND (AGM_V_CMT.MachineNumber IS NULL 
							OR AGM_V_CMT.MachineNumber = @MachineNumber)
					AND AGM.IsHoldCondition = 1
			ORDER BY AlarmMachineMappingId
		END 
	ELSE 
		BEGIN 
			SELECT AGM_V_CMT.AlarmCode,
					AGM.[Description],
					AGM_V_CMT.AlarmGroupMsterVsControllerModelTypeId AS AlarmMachineMappingId,
					AGM_V_CMT.DisplayOrder,
					AGM_V_CMT.IsDefault,
					CASE
					WHEN ALS.Active = 1 
							OR AGM_V_CMT.IsDefault = 1 THEN CAST(1 AS BIT) 
					 ELSE CAST(0 AS BIT) 
					END AS Active, 
					AGM.ResourceKey 
			FROM [TCD].AlarmGroupMaster AGM
					INNER JOIN [TCD].[AlarmGroupMsterVsControllerModelType] AGM_V_CMT
							ON AGM.AlarmGroupMasterId = AGM_V_CMT.AlarmGroupMasterId
					INNER JOIN [TCD].ControllerModelControllerTypeMapping CMTM
							ON CMTM.Id = AGM_V_CMT.ControllerModelTypeId
					LEFT JOIN [TCD].AlarmStatus ALS
							ON ALS.[AlarmGroupMsterVsControllerModelTypeId] = AGM_V_CMT.AlarmGroupMsterVsControllerModelTypeId
								AND ALS.WasherId = @WasherId
			WHERE ( AGM.WasherType = @washerType
						OR AGM.WasherType = 'G' )
					AND AGM.IsDelete = 0 
					AND AGM_V_CMT.IsDelete = 0 
					AND CMTM.ControllerModelId = @ControllerModelId 
					AND CMTM.ControllerTypeId = @ControllerTypeId 
					AND (AGM_V_CMT.MachineNumber IS NULL 
							OR AGM_V_CMT.MachineNumber = @MachineNumber)
					AND AGM.IsHoldCondition = 1
			ORDER BY AGM_V_CMT.AlarmCode
		END

	SET NOCOUNT OFF
END;