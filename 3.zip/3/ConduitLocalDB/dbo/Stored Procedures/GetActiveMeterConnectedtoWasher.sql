﻿CREATE PROCEDURE [TCD].[GetActiveMeterConnectedtoWasher]
(
@WasherId					INT,	
@MeterExists				BIT OUTPUT
)
	AS
BEGIN

SET	NOCOUNT	ON														--SQLEnlight	SA0017


DECLARE	
@MachineInternalId			INT,
@GroupId					INT
		SELECT DISTINCT 
					@MachineInternalId=Mst.MachineInternalId,
					@GroupId=Mst.GroupId					
		FROM TCD.Washer Ws
						INNER JOIN TCD.MachineSetup Mst 
						ON			Mst.WasherId					=			Ws.WasherId
						INNER JOIN TCD.WasherGroup Wg 
						ON			Wg.WasherGroupId				=			Mst.GroupId
						INNER JOIN TCD.WasherGroupType WgT 
						ON			WgT.WasherGroupTypeId			=			Wg.WasherGroupTypeId
		WHERE						Ws.WasherId						=			@WasherId 

		SELECT						@MeterExists				=			M.MachineCompartment 
		FROM Tcd.MachineSetup Ms
						INNER JOIN Tcd.Meter M 
						ON			M.GroupId						=			Ms.GroupId				AND
									M.MachineCompartment			=			Ms.MachineInternalId
		WHERE						Ms.WasherId						=			@WasherId		
END
