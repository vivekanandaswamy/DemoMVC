﻿/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[GetMeterUtilityLocation]                                         

Purpose:				To get the utility details.

###################################################################################################                                           
*/
CREATE PROCEDURE TCD.GetMeterUtilityLocation(@EcolabAccountNumber NVARCHAR(25))
AS
BEGIN
    SET NOCOUNT ON;


SET		@EcolabAccountNumber			=			ISNULL(@EcolabAccountNumber, NULL)			--SQLEnlight SA0029

       SELECT DISTINCT GT.Id,
                GT.GroupDescription,
                GT.GroupTypeId,
                MS.IsTunnel,
				(SELECT cc.ControllerModelId FROM TCD.ConduitController cc WHERE cc.ControllerId = (SELECT wg.ControllerId FROM TCD.WasherGroup wg WHERE wg.WasherGroupId = GT.Id AND wg.EcolabAccountNumber = @EcolabAccountNumber) AND cc.EcoalabAccountNumber = @EcolabAccountNumber ) AS ControllerModelId
     FROM TCD.MachineGroup GT
         LEFT JOIN
         TCD.MachineSetup MS ON GT.Id = MS.GroupId AND GT.EcolabAccountNumber = MS.EcoalabAccountNumber
     WHERE GT.Is_Deleted = 0
       AND COALESCE(MS.IsDeleted, 0) = 0
	   AND GT.EcolabAccountNumber = @EcolabAccountNumber
     ORDER BY    GT.GroupTypeId, GT.Id;

    SET NOCOUNT OFF;
END;