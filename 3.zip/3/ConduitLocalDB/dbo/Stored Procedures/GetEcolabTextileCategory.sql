﻿/*  
 ==========================================================================================  
 Purpose:  Fetching the textile category list defined by Ecolab.  

 Author:  Phani  

 --------------------------------------------------------------  
 August-18-2014 ENT: Initial version.  
 ==========================================================================================  
*/ 
CREATE PROCEDURE [TCD].[GetEcolabTextileCategory] (
	@EcolabAccountNumber NVARCHAR(50) = NULL
)
AS 
  BEGIN 
	  SET nocount ON; 

	  SELECT 
	  etc.TextileId
	  , etc.CategoryName
	  FROM   [TCD].EcolabTextileCategory etc 
	  WHERE etc.IsDeleted=0 AND etc.RegionId IN (SELECT p.RegionId FROM TCD.Plant p WHERE p.EcolabAccountNumber = @EcolabAccountNumber)
	 
  END 