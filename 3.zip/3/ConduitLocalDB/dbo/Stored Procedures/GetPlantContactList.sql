﻿
/* 
 ========================================================================================== 
 Purpose:  Used to get contacts to popuplate in User Management Add.

 Author:  Krishna Gangadhar Thota 

 -------------------------------------------------------------- 
 November-11-2014 ENT: Initial version. 
 ========================================================================================== 
*/

CREATE PROCEDURE TCD.GetPlantContactList (@Contact NVARCHAR(1000)
								, @EcolabAccountNumber NVARCHAR(25))
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN
	   SELECT
	   PC.ID,
	   PC.EcolabAccountNumber ,
	   PC.ContactFirstName,
	   PC.ContactLastName,
	   PC.ContactTitle ,
	   PC.ContactPositionId,
	   (
	    SELECT CP.Position_Name
		 FROM TCD.PlantContactPosition CP
		 WHERE CP.Id = PC.ContactPositionId) AS ContactPositionName,
	   PC.ContactEMail,
	   PC.ContactOfficePhone ,
	   PC.ContactMobilePhone ,
	   PC.ContactFaxNumber,
	   PC.LastModifiedTime,
	   PC.LastSyncTime,
	   PC.Is_Deleted
	   ,PC.MyServiceCntctGuid		AS MyServiceCntctGuid
	   ,PC.MyServiceLastSynchTime
	   ,PCP.MyServiceCntctPosnId	AS MyServiceCntctPosnId
		FROM TCD.PlantContact PC
			JOIN
			TCD.PlantContactPosition PCP ON PC.ContactPositionId = PCP.Id
		WHERE
		(PC.ContactLastName LIKE '%'
							+
							@Contact
							+
							'%'
	   OR PC.ContactFirstName LIKE '%'
							 +
							 @Contact
							 +
							 '%')
	 AND PC.Is_Deleted = 0
	 AND PC.EcolabAccountNumber = @EcolabAccountNumber
	 AND PC.ID not in(select ContactId from TCD.UserMaster where contactId is not null AND IsActive = 1) 
    END;
END;