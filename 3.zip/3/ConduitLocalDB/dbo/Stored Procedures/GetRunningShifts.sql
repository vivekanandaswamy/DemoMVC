﻿Create PROCEDURE TCD.GetRunningShifts
AS 
BEGIN
	 select ShiftName,cast(StartDateTime as time)AS StartTime,cast(EndDateTime  as time)as EndTime from tcd.productionshiftdata  
	 where (StartDateTime in (select  DATEADD(day, DATEDIFF(day,'19000101',GETUTCDATE()), 
	 CAST(DATEADD(second, DATEDIFF(second, GETDATE(), GETUTCDATE()), StartTime) AS DATETIME)) from tcd.shiftdata))
	 or (EndDateTime in (select  DATEADD(day, DATEDIFF(day,'19000101',GETUTCDATE()), 
	 CAST(DATEADD(second, DATEDIFF(second, GETDATE(), GETUTCDATE()), StartTime) AS DATETIME)) from tcd.shiftdata))
END
