--exec [TCD].[ProductionShiftReport] @Corporate=N'',@Country=N'',@Region=N'',@EcolabAccountNumber=N'',@Machine=N'',
--@machineGroup=N'',@Formula=N'',@MachineType=N'',@Category=N'',@FromDate='2015-01-07',
--@ToDate='2015-01-07',@GroupId=N'',@MachineInternalId=N'',@Date = '2015-01-02',@PlantWise = 0,@FormulaId = '171',
--@EcolabTextileId = '',@TextileCareCustomerId = '',@ChainFormulaId = '',@SortColumnID = 0,@SortDirection = 'ASC',@ReportID =2,@IsDrillDown = 0



CREATE PROCEDURE [TCD].[ProductionShiftReport] (
--DECLARE 
											 @Corporate Varchar(max) = '',
											 @Country Varchar(max) = '',
											 @Region Varchar(max) = '',
											 @EcolabAccountNumber Nvarchar(25) = '',
											 @Machine Varchar(max) = '', 
											 @machineGroup Varchar(max) = '',
											 @Formula Varchar(max) = '',
											 @MachineType Varchar(20)= '',
											 @Category Varchar(max) = '',

											 @FromDate Date = '',
											 @ToDate Date = '',

											 @GroupId Varchar(max) = '',
											 @MachineInternalId Varchar(max) = '',
											 @Date Date = NULL,
											 @PlantWise bit = NULL,
											 @FormulaId varchar(100) = '',
											 @EcolabTextileId varchar(100) = '',
											 @TextileCareCustomerId varchar(100) = '',
											 @ChainFormulaId varchar(100) = '',
											 @SortColumnID INT = 0,
											 @SortDirection Varchar(100) = 'asc',
											 @ReportID INT = NULL,
											 @IsDrillDown Bit
										    )
AS
BEGIN   
SET NOCOUNT ON;

DECLARE @Month INT = MONTH(GETDATE()),
	   @SortField Varchar(100) = '',
	   @SummationInMin Int = NULL,
	   @SQLStatement varchar(max),	   
	   @WasherGroupNumber Int = 0

	   SET	@Region					=			ISNULL(@Region, NULL)					--SQLEnlight SA0029
		SET	@EcolabAccountNumber	=			ISNULL(@EcolabAccountNumber, NULL)		--SQLEnlight SA0029
		SET	@Corporate				=			ISNULL(@Corporate, NULL)				--SQLEnlight SA0029

	   SET @Date = @FromDate

    SELECT @SortField =  CASE WHEN @SortColumnID = 120 THEN 'Loadperhour'
						WHEN @SortColumnID = 122 THEN 'MachineName'
						WHEN @SortColumnID = 133 THEN 'Numberofbatches'
						WHEN @SortColumnID = 181 THEN 'TargetLoad'
						WHEN @SortColumnID = 182 THEN 'TargetLoadperhour'
						WHEN @SortColumnID = 200 THEN 'TotalLoad'
						WHEN @SortColumnID = 242 THEN 'DateRange'
						WHEN @SortColumnID = 66  THEN 'ProductionDiff'
						WHEN @SortColumnID = 119 THEN 'LoadEfficiency'
						WHEN @SortColumnID = 135 THEN 'NumberOfPieces'						
						WHEN @SortColumnID = 146 THEN 'ProductionMix'
						WHEN @SortColumnID = 156 THEN 'Rewash'
						WHEN @SortColumnID = 0   THEN 'TotalLoad' END
												
DECLARE @CategoryTable TABLE(Category VARCHAR(100))
INSERT INTO @CategoryTable(Category) EXEC [TCD].[CharlistToTable] @Category,','


DECLARE @MachineTable TABLE(Machine VARCHAR(100))
INSERT INTO @MachineTable(Machine) EXEC [TCD].[CharlistToTable] @Machine,','


DECLARE @GroupMachineTable TABLE(GroupId INT,MachineInternalId INT)  
INSERT INTO @GroupMachineTable(GroupId,MachineInternalId)   
SELECT GroupId,MachineInternalId 
FROM 
TCD.MachineSetup MS 
INNER JOIN TCD.Washer WS ON MS.WasherId = WS.WasherId 
WHERE WS.PlantWasherNumber IN (SELECT Machine FROM @MachineTable);


DECLARE @GroupTable TABLE(GroupId VARCHAR(100))
INSERT INTO @GroupTable(GroupId) EXEC [TCD].[CharlistToTable] @GroupId,','


DECLARE @MachineInternalTable TABLE(MachineInternalId VARCHAR(100))
INSERT INTO @MachineInternalTable(MachineInternalId) EXEC [TCD].[CharlistToTable] @MachineInternalId,','

DECLARE @WasherGroupTable TABLE(MachineGroup VARCHAR(100))
INSERT INTO @WasherGroupTable(MachineGroup) EXEC [TCD].[CharlistToTable] @MachineGroup,','


DECLARE @FormulaTable TABLE(Formula VARCHAR(100))
INSERT INTO @FormulaTable(Formula) EXEC [TCD].[CharlistToTable] @Formula,','


--DECLARE @CustomerTable TABLE(Customer VARCHAR(100))
--INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','


DECLARE @MachineTypeTable TABLE(MachineType VARCHAR(100))
INSERT INTO @MachineTypeTable(MachineType) EXEC [TCD].[CharlistToTable] @MachineType,','

CREATE TABLE #ShiftResultTable  (
							 WasherGroupNumber INT,
							 DateRange Nvarchar(100),
							 TotalLoad Decimal(10,0),
							 TargetLoad Decimal(10,0),
							 Numberofbatches INT,
							 Loadperhour Decimal(10,2),
							 TargetLoadperhour Decimal(10,2),
							 ViewByMode BIT,
							 IsDrillDown BIT,
							 Id INT,
							 ProductionDiff Decimal(10,0),
							 LoadEfficiency Decimal(10,0),
							 ProductionMix Decimal(10,0),
							 NumberOfPieces INT,
							 Rewash Decimal(10,0),
							 SwithMode Nvarchar(100),
							 TotalRunTime Decimal(18,2) 

						  )
  CREATE TABLE #ShiftDataTable
				    (
				    RowNumber INT IDENTITY(1,1),
				    ShiftName Nvarchar(1000),
				    ShiftId INT,
				    StartTime DATETIME,
				    EndTime DATETIME
				    )

	   DECLARE @DayId INT = NULL,@Id INT = 1,@summingActualLoad Decimal(10,2) = NULL,@LastFirstTIme Datetime = NULL,@LastEndTIme Datetime = NULL
	   SELECT @FormulaId = FORMULA FROM @FormulaTable
	   SELECT @summingActualLoad = (SUM(BD.[ActualWeight]) + CASE WHEN SUM(BD.ManualInputWeight) IS NULL THEN 0 ELSE SUM(BD.ManualInputWeight) END)  FROM TCD.BatchData BD 
															 LEFT OUTER JOIN
										   TCD.BatchCustomerData BCD ON BD.BatchID = BCD.BatchId
										   LEFT OUTER JOIN
										   TCD.ProgramMaster PM ON PM.ProgramId = BD.ProgramMasterId
										   LEFT OUTER JOIN
										   TCD.EcolabTextileCategory ETC ON ETC.TextileId = PM.EcolabTextileCategoryId
										    LEFT OUTER JOIN
										   TCD.ChainTextileCategory CTC ON  CTC.TextileId = PM.ChainTextileId
										    LEFT OUTER JOIN
										   TCD.PlantChainProgram PCP ON PCP.PlantProgramId = PM.PlantProgramId
									WHERE  CAST(BD.EndDate AS datetime) >= dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@Date AS DATE), 112) + ' ' + CONVERT(Varchar(8),'00:00:00') AS DateTime))
														  AND BD.Enddate <= DATEADD(DAY,1,dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10),  CAST(@Date AS DATE), 112) + ' ' + CONVERT(Varchar(8),'00:00:00') AS DateTime)))
									AND (BD.ProgramMasterId = @FormulaId OR ETC.TextileId = @EcolabTextileId OR CTC.TextileId = @TextileCareCustomerId OR PCP.PlantProgramId = @ChainFormulaId)
		  
		  
			  SELECT @DayId = DayId from TCD.WeekDay WHERE DayName = DATENAME(dw,CAST(@Date AS DATE)) 

			  INSERT INTO #ShiftDataTable
								(
								ShiftName,
								ShiftId ,
								StartTime ,
								EndTime 
								)
			  SELECT 
				    SD.ShiftName,
				    SD.ShiftId,
				    dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), @Date, 112) + ' ' + CONVERT(Varchar(8), SD.StartTime) AS DateTime)) AS StartTime,
				    dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), @Date, 112) + ' ' + CONVERT(Varchar(8), SD.EndTime) AS DateTime)) AS EndTime
							  
					   FROM TCD.ShiftData SD 
									 WHERE DayId = @DayId AND SD.Is_Deleted = 0


			 SELECT TOP 1 @LastEndTIme = ST.EndTime FROM #ShiftDataTable ST ORDER BY ST.EndTime DESC 
			 SELECT TOP 1 @LastFirstTIme = ST.StartTime FROM #ShiftDataTable ST  ORDER BY ST.StartTime ASC

			 IF(@LastEndTIme < dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(DATEADD(Day, DATEDIFF(Day, 0, @LastEndTIme),1) AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(DATEADD(Day, DATEDIFF(Day, 0, @LastEndTIme),1) AS TIME)) AS DateTime)))
				BEGIN
				INSERT INTO #ShiftDataTable(ShiftName,ShiftId,StartTime,EndTime)
				SELECT TOP 1 
					  'NoShift',
					  SHIFTID + 1,
					  @LastEndTIme,
					  dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(DATEADD(Day, DATEDIFF(Day, 0, @LastEndTIme),1) AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(DATEADD(Day, DATEDIFF(Day, 0, @LastEndTIme),1) AS TIME)) AS DateTime))
							 FROM #ShiftDataTable ORDER BY EndTime DESC
				END
			 IF(DATEADD(DAY,-1,dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(DATEADD(Day, DATEDIFF(Day, 0, @LastEndTIme),1) AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(DATEADD(Day, DATEDIFF(Day, 0, @LastEndTIme),1) AS TIME)) AS DateTime))) < @LastFirstTIme) --AND CAST(@LastFirstTIme AS date) = CAST(@Date AS date))
				BEGIN
				INSERT INTO #ShiftDataTable(ShiftName,ShiftId,StartTime,EndTime)
				SELECT TOP 1 
					   'Noshift',
					   SHIFTID + 1,
					   DATEADD(DAY,-1,dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(DATEADD(Day, DATEDIFF(Day, 0, @LastEndTIme),1) AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(DATEADD(Day, DATEDIFF(Day, 0, @LastEndTIme),1) AS TIME)) AS DateTime))),
					   @LastFirstTIme
							 FROM #ShiftDataTable ORDER BY EndTime DESC
				END

									 			
				WHILE (@Id <= (SELECT COUNT(1) FROM #ShiftDataTable))
				    BEGIN
						  DECLARE @StartTime DATETIME = NULL,
						  @EndTime DATETIME = NULL,
						  @ShiftName Varchar(100) = NULL,
						  @TotalRunTimesec VARCHAR(100) = NULL,
						  @Hour INT = NULL,
						  @BatchStartTime DATETIME = NULL,
						  @BatchEndTime DATETIME = NULL

						  SELECT @StartTime = ST.StartTime,@EndTime = ST.EndTime,@ShiftName = ST.ShiftName FROM #ShiftDataTable ST WHERE RowNumber = @Id


						   SELECT TOP 1 @BatchStartTime = CAST(BD.StartDate AS datetime) FROM TCD.BatchData BD 
						   WHERE CAST(BD.StartDate AS datetime) >= @StartTime AND CAST(BD.EndDate AS datetime) <= @EndTime ORDER BY StartDate

						  SELECT  TOP 1 @BatchEndTime = CAST(BD.EndDate AS datetime) FROM TCD.BatchData BD 
						  WHERE CAST(BD.StartDate AS datetime) >= @StartTime AND CAST(BD.EndDate AS datetime) <= @EndTime  ORDER BY EndDate DESC

						  SELECT @Hour = DATEDIFF(HOUR,@BatchStartTime,@BatchEndTime)
						  	
						

						  INSERT INTO #ShiftResultTable(
							 WasherGroupNumber ,
							 DateRange ,
							 TotalLoad ,
							 TargetLoad,
							 Numberofbatches,
							 Loadperhour,
							 TargetLoadperhour ,
							 ViewByMode ,
							 IsDrillDown ,
							 Id ,
							 ProductionDiff,
							 LoadEfficiency ,
							 ProductionMix ,
							 NumberOfPieces ,
							 Rewash ,
							 SwithMode,
							 TotalRunTime 
						  )
						  SELECT @WasherGroupNumber,
							    @ShiftName As DateRange,
								(SUM(BD.[ActualWeight]) + CASE WHEN SUM(BD.ManualInputWeight) IS NULL THEN 0 ELSE SUM(BD.ManualInputWeight) END) AS TotalLoad,
							     SUM(BD.[StandardWeight]) AS TargetLoad,
							     COUNT(BD.BatchID) AS Numberofbatches,

							    ((SUM(BD.[ActualWeight]) + CASE WHEN SUM(BD.ManualInputWeight) IS NULL THEN 0 ELSE SUM(BD.ManualInputWeight) END)/
							    (SELECT CAST(SUM(DATEDIFF(SECOND,BD.StartDate,BD.EndDate)) AS decimal(18,2))/3600.00)
							    ) AS Loadperhour,


							    (SUM(BD.[StandardWeight])/
							    (SELECT CAST(SUM(DATEDIFF(SECOND,BD.StartDate,BD.EndDate)) AS decimal(18,2))/3600.00)
							    ) AS TargetLoadperhour,
							    @PlantWise AS ViewByMode,

							    @IsDrillDown as IsDrillDown,
							     0 AS Id,
								SUM(BD.[StandardWeight]) - SUM(BD.[ActualWeight]) AS ProductionDiff,

								CASE WHEN SUM(BD.[StandardWeight]) <> 0 THEN
								CAST(((SUM(BD.[ActualWeight]) + CASE WHEN SUM(BD.ManualInputWeight) IS NULL THEN 0 ELSE SUM(BD.ManualInputWeight) END) * 100 /SUM(BD.[StandardWeight])) AS decimal(18,2))
								ELSE 0 END
								AS LoadEfficiency,

								--CAST(((SUM(BD.[ActualWeight]) + CASE WHEN SUM(BD.ManualInputWeight) IS NULL THEN 0 ELSE SUM(BD.ManualInputWeight) END) * 100 /SUM(BD.[StandardWeight])) AS decimal(18,2)) AS LoadEfficiency,



								CAST(((SUM(BD.[ActualWeight]) + CASE WHEN SUM(BD.ManualInputWeight) IS NULL THEN 0 ELSE SUM(BD.ManualInputWeight) END) * 100 /@summingActualLoad) AS decimal(18,2)) AS ProductionMix,
								SUM(BCD.PiecesCount) AS NumberOfPieces,
								 CAST(((SELECT SUM(MR.VALUE) FROM TCD.ManualRewash MR WHERE MR.FormulaId IN 
								(SELECT PM.ProgramId FROM TCD.ProgramMaster PM WHERE 
								(ProgramId = @FormulaId OR EcolabTextileCategoryId = @EcolabTextileId OR ChainTextileId = @TextileCareCustomerId OR PlantProgramId = @ChainFormulaId)
								) GROUP BY MR.FormulaId) * 100 /@summingActualLoad) AS decimal(18,0)) AS Rewash,
								'Shift' AS SwithMode,
								(SELECT CAST(SUM(DATEDIFF(SECOND,BD.StartDate,BD.EndDate)) AS decimal(18,2))/3600.00) AS TotalRunTime

								FROM TCD.BatchData BD 
										   LEFT OUTER JOIN
										   TCD.BatchCustomerData BCD ON BD.BatchID = BCD.BatchId
										   LEFT OUTER JOIN
										   TCD.ProgramMaster PM ON PM.ProgramId = BD.ProgramMasterId
										   LEFT OUTER JOIN
										   TCD.EcolabTextileCategory ETC ON ETC.TextileId = PM.EcolabTextileCategoryId
										    LEFT OUTER JOIN
										   TCD.ChainTextileCategory CTC ON  CTC.TextileId = PM.ChainTextileId
										    LEFT OUTER JOIN
										   TCD.PlantChainProgram PCP ON PCP.PlantProgramId = PM.PlantProgramId
								WHERE  CAST(BD.EndDate AS datetime) >= @StartTime
									AND BD.Enddate <= @EndTime
								AND 
								CASE @Machine   
										   WHEN '' THEN 'TRUE'         
										   ELSE                                                      
										    CASE WHEN BD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
										  END='TRUE' 

								    AND       

								    CASE @machineGroup   
									WHEN '' THEN 'TRUE'         
									ELSE                                                      
									 CASE WHEN BD.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable) THEN 'TRUE' END                                                      
								    END='TRUE' 

								    AND    

								    CASE @Formula   
									WHEN '' THEN 'TRUE'         
									ELSE                                                      
									 CASE WHEN BD.ProgramNumber not in (Select Formula from @FormulaTable)  THEN 'TRUE' END                                                      
								    END='TRUE' 

								    AND       

								    CASE @MachineType   
									WHEN '' THEN 'TRUE'         
									ELSE                                                      
									 CASE WHEN BD.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable)) THEN 'TRUE' END                                                      
								    END='TRUE' 

								    AND       
								   CASE @Category   
									WHEN '' THEN 'TRUE'         
									ELSE                                                      
									 CASE WHEN ETC.TextileId IN (SELECT Category FROM @CategoryTable) THEN 'TRUE' END                                                      
								    END='TRUE' 

								    AND
									CASE @GroupId 
									WHEN '' THEN 'TRUE' 
									ELSE        
								    CASE WHEN (BD.GroupId IN (@GroupId) AND 
									 BD.MachineInternalId IN (@MachineInternalId)) THEN 'TRUE' END                                                   
								    END='TRUE' 
								    AND
									CASE @MachineInternalId 
									WHEN '' THEN 'TRUE' 
									ELSE        
								    CASE WHEN (BD.GroupId IN (@GroupId) AND 
									 BD.MachineInternalId IN (@MachineInternalId)) THEN 'TRUE' END                                                   
								    END='TRUE' 
								AND
								CASE @FormulaId   
								 WHEN '' THEN 'TRUE'         
								 ELSE                 
								 
								  CASE WHEN BD.ProgramMasterId = @FormulaId   THEN 'TRUE' END                                                      
								 END='TRUE' 

								AND       
								
								CASE @EcolabTextileId   
								 WHEN '' THEN 'TRUE'         
								 ELSE                                                      
								  CASE WHEN ETC.TextileId = @EcolabTextileId THEN 'TRUE' END                                                      
								 END='TRUE' 

								AND       
								CASE @TextileCareCustomerId   
								 WHEN '' THEN 'TRUE'         
								 ELSE                                                      
								  CASE WHEN CTC.TextileId = @TextileCareCustomerId THEN 'TRUE' END                                                      
								 END='TRUE' 

								AND    
								
								CASE @ChainFormulaId   
								 WHEN '' THEN 'TRUE'         
								 ELSE                                                      
								  CASE WHEN PCP.PlantProgramId = @ChainFormulaId THEN 'TRUE' END                                                      
								 END='TRUE' 
								
   
						   SET @Id = @Id + 1

						   IF OBJECT_ID('tempdb..#ShiftResultTable1') IS NOT NULL DROP TABLE #ShiftResultTable1
						 
						   SELECT  WasherGroupNumber ,
							 DateRange ,
							 TotalLoad ,
							 TargetLoad,
							 Numberofbatches,
							 Loadperhour,
							 TargetLoadperhour ,
							 ViewByMode ,
							 IsDrillDown ,
							 Id ,
							 ProductionDiff,
							 LoadEfficiency ,
							 ProductionMix ,
							 NumberOfPieces ,
							 Rewash ,
							 SwithMode,
							 TotalRunTime  INTO #ShiftResultTable1 FROM #ShiftResultTable SRT WHERE SRT.DateRange NOT Like '%Noshift%'

						   INSERT INTO #ShiftResultTable1(
												    WasherGroupNumber ,
												    DateRange ,
												    TotalLoad ,
												    TargetLoad,
												    Numberofbatches,
												    Loadperhour,
												    TargetLoadperhour ,
												    ViewByMode ,
												    IsDrillDown ,
												    Id ,
												    ProductionDiff,
												    LoadEfficiency ,
												    ProductionMix ,
												    NumberOfPieces ,
												    Rewash ,
												    SwithMode,
												    TotalRunTime 
												)
						   SELECT 
									 WasherGroupNumber ,
									 DateRange,
									 SUM(TotalLoad),
									 SUM(TargetLoad),
									 SUM(Numberofbatches),
									 SUM(Loadperhour),
									 SUM(TargetLoadperhour),
									 ViewByMode,
									 IsDrillDown,
									 Id,
									 SUM(ProductionDiff) ,
									 SUM(LoadEfficiency),
									 SUM(ProductionMix),
									 SUM(NumberOfPieces),
									 SUM(Rewash),
									 SwithMode,SUM(TotalRunTime)
									 FROM #ShiftResultTable SRT WHERE SRT.DateRange Like '%Noshift%'
									 GROUP BY WasherGroupNumber,DateRange,ViewByMode,IsDrillDown,Id,SwithMode

				    END

				    IF(@ReportID = 1)
				    BEGIN

				    SET @SQLStatement 
					   ='SELECT 
							 WasherGroupNumber,
							 DateRange,
							 TotalLoad,
							 TargetLoad,
							 NumberOfBatches,
							 Loadperhour,
							 TargetLoadperhour,
							 ViewByMode, 
							 IsDrillDown,TotalRunTime
					    FROM #ShiftResultTable1 WHERE TotalLoad IS NOT NULL ORDER BY ' + @SortField + ' ' + @SortDirection

	   			    EXEC(@SQLStatement)
				    END
				    IF(@ReportID = 2)
				    BEGIN

				    SET @SQLStatement 
					   ='SELECT 
							 Id,
							 DateRange,
							 TotalLoad,
							 TargetLoad,
							 ProductionDiff,
							 LoadEfficiency,
							 ProductionMix,
							 Loadperhour AS ActualProductionperhour, 
							 TargetLoadperhour AS TargetProductionperhour,
							 NumberOfBatches AS NumberOfLoads,
							 NumberOfPieces,
							 Rewash,
							 SwithMode,IsDrillDown,TotalRunTime
					    FROM #ShiftResultTable1 WHERE TotalLoad IS NOT NULL ORDER BY ' + @SortField + ' ' + @SortDirection

	   			    EXEC(@SQLStatement)
				    END

				    DROP TABLE #ShiftResultTable
				    DROP TABLE #ShiftDataTable
					DROP TABLE #ShiftResultTable1

END

--SELECT * FROM TCD.ShiftData WHERE DayId =  7



