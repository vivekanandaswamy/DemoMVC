﻿CREATE PROCEDURE [TCD].[GetFinnishers]
(
@EcolabAccountNumber NVARCHAR(25)
)
AS     
  BEGIN     
      SET nocount ON;     
    
     SELECT     
	 f.FinnisherGroupId    
   , f.FinnisherId 
   , f.FinnisherNo    
   , f.Name
   , f.LastModifiedTime
   , f.EcolabAccountNumber
   , f.FinnisherTypeId
   , f.Is_deleted
   , GT.GroupDescription    
    FROM   [TCD].Finnishers f 
	Inner Join [TCD].MachineGroup gt on f.FinnisherGroupId = gt.Id AND gt.EcolabAccountNumber = f.EcolabAccountNumber 
	WHERE gt.GroupTypeId = 4 AND f.EcolabAccountNumber =  @EcolabAccountNumber
  END