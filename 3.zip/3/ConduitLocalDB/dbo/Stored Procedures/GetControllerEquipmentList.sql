﻿CREATE PROCEDURE [TCD].[GetControllerEquipmentList]                  
  @EcoLabAccountNumber     NVARCHAR(25)                  
    , @ControllerId       INT                  
    , @ControllerEquipmentId     TINYINT = NULL                  
    , @IsActive       BIT = NULL                  
AS
BEGIN
    SET NOCOUNT ON;                  
    DECLARE                  
     @ErrorMessage         NVARCHAR(4000)                  
     ,@PumpValveCount        TINYINT                  
     ,@MECount          TINYINT                  
     ,@ControllerEquipmentTypeId_PumpValve    TINYINT                  
     ,@ControllerEquipmentTypeId_ME      TINYINT                  
     ,@ControllerModelId        INT                  
     ,@ReturnValue         INT = 0                  
     ,@TagTypeLfs         VARCHAR(100) = 'Tag_NML'                  
     ,@TagTypeKfactor         VARCHAR(100) = 'Tag_PPOL'                  
     ,@TagTypeCalibration        VARCHAR(100) = 'Tag_OPSL'            
 ,@ControllerTypeId INT;                  

    CREATE TABLE #Equipment (                  
    ControllerEquipmentId     INT    IDENTITY(1, 1)                  
  , ControllerEquipmentTypeId     TINYINT   NULL                  
  , IsActive        BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , ProductId        INT    NULL                  
  , ProductName       NVARCHAR(255)  NULL                  
  , PumpCalibration       DECIMAL(18, 3)  NULL                  
  , FlowMeterSwitchFlag      BIT    NULL                  
  , FlowMeterCalibration      INT    NULL                  
  , MaximumDosingTime      SMALLINT   NULL                  
  , FlowSwitchTimeOut       decimal(18,1)   NULL                  
  , ControllerEquipmentSetupId    SMALLINT   NULL                  
  , LfsChemicalName       NVARCHAR(200)  NULL                  
  , KFactor        DECIMAL(18, 2)  NULL                  
  , TunnelHold        BIT    NULL                  
  , FlowDetectorType      INT    NULL                  
  , FlowSwitchAlarm       BIT    NULL                  
  , FlowMeterAlarm       BIT    NULL                  
  , FlowMeterType       INT    NULL                  
  , FlowAlarmDelay       DECIMAL(18, 2)    NULL                  
  , FlowMeterPumpDelay      DECIMAL(18, 2)    NULL                  
  , FlowMeterAlarmDelay      DECIMAL(18, 2)    NULL                  
  , LastModifiedTime      DATETIME   NULL                  
  , LastSyncTime       DATETIME   NULL                  
  , ControllerEquipmentTypeModelID    INT    NULL                  
  , ConventionalWasherGroupConnection   BIT    NOT NULL                  
              DEFAULT                  
              0                  
  , AxillaryPumpCalibration     SMALLINT   NULL                  
  , FlowmeterSwitchActivated     BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , FlushWhileDosing      BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , WeightControlledDosage     BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , EquipmentDoseAlone      BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , LowLevelAlarm       BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , LeakageAlarm       BIT    NOT NULL                  
              DEFAULT                  
              'FALSE'                  
  , FlushTime        SMALLINT   NULL                  
  , PumpingTime       SMALLINT   NULL                  
  , PreFlushTime       SMALLINT   NULL                  
  , NightFlushPauseTime      SMALLINT   NULL                  
  , NightFlushTime       SMALLINT   NULL                  
  , AcceptedDeviation      SMALLINT   NULL                 
  , LineNumber    tinyint NULL DEFAULT 0                
  , DirectDosingFlag      BIT    NULL                  
              DEFAULT                  
              'FALSE'               
  , DirectDosingMachineInternalId    INT    NULL                  
  , DirectDosingTunnelCompartmentId   INT    NULL                  
  , WasherGroupTypeId     INT    NULL                 
  , NumberOfCompartments     INT    NULL                   
  , FlushValveNumber      TINYINT   NULL                
  , CalibrationConductSS_Tank    DECIMAL(18,2)   NULL                
  , BackFlowControl       BIT    NULL                
  , FactorFM_B_FM       SMALLINT         NULL                
  , AcceptedDeviationRingLine    SMALLINT  NULL                
  , UsePumpOfGroup1ForTunnel    BIT    NULL                
  , pHSensorEnabled       BIT    NULL                
  , Concentration    INT    NULL              
  , Deadband              BIT    NULL             
  , WasherGroupNumber    INT     NULL           
  , ValveOutputAsTom  BIT NOT NULL DEFAULT  'FALSE'          
  , FlowSwitchNumber int  NULL           
  , FlushTimeForFlushValve int NULL      
    , MinimumFlowRate INT NULL    
  , ProductDensity DECIMAL(18,2) NULL    
  , MaximumConcentration INT NULL  
  , DosingLineMode INT NULL  
   );                  
    IF NOT EXISTS ( SELECT 1                  
        FROM TCD.ConduitController   CC                  
        WHERE CC.EcoalabAccountNumber = @EcoLabAccountNumber                  
AND CC.ControllerId = @ControllerId                  
    )                  
    BEGIN                  
    SET   @ErrorMessage = 'Invalid Plant/Controller combination specified';                  
    RAISERROR (@ErrorMessage, 16, 1);                  
    SET  @ReturnValue = -1;                  
    RETURN                  
    @ReturnValue;                  
    END;                  
    SET @ControllerTypeId = (SELECT ControllerTypeid            
       FROM TCD.ConduitController CC            
       WHERE CC.ControllerId = @ControllerId);            
    SELECT @ControllerModelId = CC.ControllerModelId                  
  FROM TCD.ConduitController CC                  
  WHERE CC.ControllerId = @ControllerId;                  
    SELECT @ControllerEquipmentTypeId_PumpValve = CASE                  
              WHEN CET.ControllerEquipmentTypeName = 'Pump/Valve'                  
              THEN CET.ControllerEquipmentTypeId                  
              ELSE @ControllerEquipmentTypeId_PumpValve                  
              END                  
     , @ControllerEquipmentTypeId_ME = CASE                  
           WHEN CET.ControllerEquipmentTypeName = 'ME'                  
           THEN CET.ControllerEquipmentTypeId                  
           ELSE @ControllerEquipmentTypeId_ME                  
           END                  
  FROM TCD.ControllerEquipmentType CET                  
  WHERE CET.ControllerEquipmentTypeName   IN   ('Pump/Valve', 'ME');                  
    IF (@ControllerModelId <> 7 AND @ControllerModelId  <> 8 AND @ControllerModelId <> 9 AND @ControllerModelId <> 11      
    AND @ControllerModelId <> 10 AND @ControllerModelId <> 14)                
    BEGIN                  
    SELECT @PumpValveCount = ISNULL(CSD.Value, 0)                  
      FROM TCD.ConduitController CC                  
       JOIN                  
       TCD.ControllerModelControllerTypeMapping CMCTM ON CC.ControllerModelId = CMCTM.ControllerModelId                  
       JOIN                  
       TCD.ControllerSetupData CSD ON CSD.ControllerId = CC.ControllerId                  
          AND CC.ControllerTypeId = CMCTM.ControllerTypeId                  
       JOIN                  
       TCD.FieldGroup FG ON FG.ControllerModelId = CC.ControllerModelId                  
        AND FG.ControllerTypeId = CC.ControllerTypeId                  
        AND FG.TabId = 3                  
       INNER JOIN                  
       TCD.FieldGroupFieldMapping FGM ON FGM.FieldGroupId = FG.Id                  
       INNER JOIN            
       TCD.Field F ON F.Id = FGM.FieldId                  
      AND CSD.FieldId = f.Id                  
      WHERE CC.ControllerId = @ControllerId                  
    AND F.ResourceKey = 'No._of_Chemical_Valves'                  
    AND CSD.EcolabAccountNumber = @EcoLabAccountNumber;                  
    SELECT @MECount = ISNULL(CMCTM.MECount, 0)                  
      FROM TCD.ConduitController CC                  
       JOIN                  
       TCD.ControllerModelControllerTypeMapping CMCTM ON CC.ControllerModelId = CMCTM.ControllerModelId                  
             AND CC.ControllerTypeId = CMCTM.ControllerTypeId                  
      WHERE CC.ControllerId = @ControllerId;                  
    END;         
    ELSE IF(@ControllerModelId = 11)                
    BEGIN                
    SELECT @PumpValveCount = 2*CMCTM.PumpValveCount                
     , @MECount = 2*CMCTM.MECount                
      FROM TCD.ControllerModelControllerTypeMapping CMCTM                
      WHERE CMCTM.ControllerModelId = @ControllerModelId;                
    END;                
  ELSE IF(@ControllerModelId = 7 OR @ControllerModelId = 8 OR @ControllerModelId = 9 OR @ControllerModelId = 10  OR @ControllerModelId = 14)                
  BEGIN                
    SELECT @PumpValveCount = CMCTM.PumpValveCount            
 , @MECount = CMCTM.MECount            
  FROM TCD.ControllerModelControllerTypeMapping CMCTM            
  WHERE CMCTM.ControllerModelId = @ControllerModelId            
    AND CMCTM.ControllerTypeId = @ControllerTypeId;                
    END;                
    IF (SELECT ISNULL(@PumpValveCount, 0)                  
    +                  
    ISNULL(@MECount, 0)) = 0                  
    BEGIN                  
    SELECT                  
    T.ControllerEquipmentId  AS   ControllerEquipmentId                  
  , T.ControllerEquipmentTypeId  AS   ControllerEquipmentTypeId                  
  , T.IsActive     AS   IsActive                  
  , T.ProductId     AS   ProductId                  
  , T.ProductName    AS   ProductName                  
  , T.PumpCalibration    AS   PumpCalibration                  
  , T.FlowMeterSwitchFlag   AS   FlowMeterSwitchFlag                  
  , T.MaximumDosingTime   AS   MaximumDosingTime                  
  , T.FlowSwitchTimeOut   AS   FlowSwitchTimeOut                  
  , T.ControllerEquipmentSetupId AS   ControllerEquipmentSetupId                  
  , @EcoLabAccountNumber   AS   EcoLabAccountNumber                  
  , @ControllerId    AS   ControllerId                  
  , CC.TopicName     AS   ControllerName                  
  , CC.ControllerTypeId   AS   ControllerTypeId                  
  , T.LfsChemicalName    AS   LfsChemicalName                  
  , T.KFactor     AS   KFactor                  
  , T.TunnelHold     AS   TunnelHold                  
  , T.FlowDetectorType   AS   FlowDetectorType                  
  , T.FlowSwitchAlarm    AS   FlowSwitchAlarm                  
  , T.FlowMeterAlarm    AS   FlowMeterAlarm                  
  , T.FlowMeterType    AS   FlowMeterType                  
  , T.FlowAlarmDelay    AS   FlowAlarmDelay                  
  , T.FlowMeterPumpDelay   AS   FlowMeterPumpDelay                  
  , T.FlowMeterAlarmDelay   AS   FlowMeterAlarmDelay                  
  , T.ControllerEquipmentTypeModelID                  
  , T.ConventionalWasherGroupConnection                  
  , T.AxillaryPumpCalibration                  
  , T.FlowmeterSwitchActivated                  
  , T.FlushWhileDosing                  
  , T.WeightControlledDosage                  
  , T.EquipmentDoseAlone                  
  , T.LowLevelAlarm                  
  , T.LeakageAlarm                  
  , T.FlushTime                  
  , T.PumpingTime                  
  , T.PreFlushTime                  
  , T.NightFlushPauseTime                  
  , T.NightFlushTime                  
  , T.AcceptedDeviation                 
  , T.LineNumber                 
  , T.DirectDosingFlag        
  , T.DirectDosingMachineInternalId                  
  , T.DirectDosingTunnelCompartmentId             
  , T.WasherGroupTypeId                     
  , T.NumberOfCompartments                     
  , T.FlushValveNumber                      
  , T.CalibrationConductSS_Tank                   
  , T.BackFlowControl                       
  , T.FactorFM_B_FM                      
  , T.AcceptedDeviationRingLine                    
  , T.UsePumpOfGroup1ForTunnel      
  , T.pHSensorEnabled               
  , T.Concentration                 
  , T.Deadband             
  , T.WasherGroupNumber             
  , T.ValveOutputAsTom            
  , T.FlowSwitchNumber           
  , T.FlushTimeForFlushValve      
   , T.MinimumFlowRate     
  , T.ProductDensity     
  , T.MaximumConcentration  
  ,T.DosingLineMode  
  , (                  
    SELECT MTS.TagAddress                  
      FROM TCD.ModuleTags MTS                  
      WHERE MTS.TagType = @TagTypeLfs                  
    AND MTS.ModuleID = ControllerEquipmentSetupId                  
    AND MTS.ModuleTypeId = 4                  
    AND MTS.Active = 1) AS LfsChemicalNameTag                  
  , (         
    SELECT MTS.TagAddress                  
      FROM TCD.ModuleTags MTS                  
      WHERE MTS.TagType = @TagTypeKfactor                  
    AND MTS.ModuleID = ControllerEquipmentSetupId                  
    AND MTS.ModuleTypeId = 4                  
    AND MTS.Active = 1) AS KfactorTag                  
  , (                  
    SELECT MTS.TagAddress                  
      FROM TCD.ModuleTags MTS                  
      WHERE MTS.TagType = @TagTypeCalibration                  
    AND MTS.ModuleID = ControllerEquipmentSetupId                  
    AND MTS.ModuleTypeId = 4                  
    AND MTS.Active = 1) AS CalibrationTag                  
  , T.LastModifiedTime  AS  LastModifiedTime                  
  , T.LastSyncTime   AS  LastSyncTime                  
      FROM #Equipment  T                  
    JOIN                  
    TCD.ConduitController CC                  
    ON CC.ControllerId = @ControllerId                  
      WHERE T.IsActive = ISNULL(@IsActive, T.IsActive)                  
    AND T.ControllerEquipmentId = ISNULL(@ControllerEquipmentId, T.ControllerEquipmentId);                  
    RETURN                  
    @ReturnValue;               

    END;             
    ELSE          
    BEGIN          
    IF ((SELECT ISNULL(@PumpValveCount, 0)                  
    +                  
    ISNULL(@MECount, 0)) = (SELECT COUNT(*) FROM TCD.ControllerEquipmentSetup CES     WHERE CES.ControllerId    = @ControllerId))          
      BEGIN          
      SET IDENTITY_INSERT #Equipment ON          
      INSERT INTO #Equipment (ControllerEquipmentId, ControllerEquipmentTypeId)             
      SELECT CES.ControllerEquipmentId, CES.ControllerEquipmentTypeId FROM TCD.ControllerEquipmentSetup CES WHERE CES.ControllerId = @ControllerId           
      SET IDENTITY_INSERT #Equipment OFF          
      END
	  ELSE
	  BEGIN
		 IF ISNULL(@PumpValveCount, 0) <> 0                  
    BEGIN                  
    WITH NumCTE (N)                  
    AS(SELECT '*' AS N                  
  UNION ALL                  
       SELECT '*' AS N)                  
    INSERT INTO #Equipment (ControllerEquipmentTypeId)                  
    SELECT TOP (@PumpValveCount) @ControllerEquipmentTypeId_PumpValve                  
      FROM NumCTE N1, NumCTE N2, NumCTE N3, NumCTE N4, NumCTE N5;                  
    END;                  
    IF ISNULL(@MECount, 0) <> 0                  
    BEGIN                  
    WITH NumCTE (N)                  
    AS (SELECT '*' AS N                  
    UNION ALL                  
    SELECT '*' AS N)                  
    INSERT INTO #Equipment(ControllerEquipmentTypeId)                  
    SELECT TOP (@MECount)@ControllerEquipmentTypeId_ME                  
      FROM NumCTE N1, NumCTE N2, NumCTE N3, NumCTE N4, NumCTE N5;                  
    END;   
	  END          
    END           
    UPDATE U                  
  SET U.IsActive = CES.IsActive                  
    , U.ProductId = CES.ProductId                  
    , U.ProductName = (SELECT ISNULL(NULLIF(PM.EnvisionDisplayName, ' '),PM.Name)                  
         FROM TCD.ProductMaster PM                  
         WHERE PM.ProductId = CES.ProductId)                  
    , U.PumpCalibration = CES.PumpCalibration                  
    , U.FlowMeterSwitchFlag = CES.FlowMeterSwitchFlag                  
    , U.MaximumDosingTime = CES.MaximumDosingTime                  
    , U.FlowSwitchTimeOut = CES.FlowSwitchTimeOut                  
    , U.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId                  
    , U.LfsChemicalName = CES.LfsChemicalName                  
    , U.KFactor = CES.KFactor                  
    , U.TunnelHold = CES.TunnelHold                  
    , U.FlowDetectorType = CES.FlowDetectorType                  
    , U.FlowSwitchAlarm = CES.FlowSwitchAlarm                  
    , U.FlowMeterAlarm = CES.FlowMeterAlarm                  
    , U.FlowMeterType = CES.FlowMeterType                  
    , U.FlowAlarmDelay = CES.FlowAlarmDelay                  
    , U.FlowMeterPumpDelay = CES.FlowMeterPumpDelay                  
    , U.FlowMeterAlarmDelay = CES.FlowMeterAlarmDelay                  
    , U.ControllerEquipmentTypeModelID = CES.ControllerEquipmentTypeModelID                  
    , U.ConventionalWasherGroupConnection = CES.ConventionalWasherGroupConnection                  
    , U.AxillaryPumpCalibration = CES.AxillaryPumpCalibration                  
    , U.FlowmeterSwitchActivated = CES.FlowmeterSwitchActivated                  
    , U.FlushWhileDosing = CES.FlushWhileDosing                  
    , U.WeightControlledDosage = CES.WeightControlledDosage                  
    , U.EquipmentDoseAlone = CES.EquipmentDoseAlone                  
    , U.LowLevelAlarm = CES.LowLevelAlarm                  
    , U.LeakageAlarm = CES.LeakageAlarm                  
    , U.FlushTime = CES.FlushTime                  
    , U.PumpingTime = CES.PumpingTime                  
    , U.PreFlushTime = CES.PreFlushTime                  
    , U.NightFlushPauseTime = CES.NightFlushPauseTime                  
    , U.NightFlushTime = CES.NightFlushTime                  
    , U.AcceptedDeviation = CES.AcceptedDeviation                 
    , U.LineNumber = CES.LineNumber                 
    , U.DirectDosingFlag = TCEVM.DirectDosingFlag                  
    , U.DirectDosingMachineInternalId = TCEVM.TunnelNumber                  
    , U.DirectDosingTunnelCompartmentId = TCEVM.CompartmentNumber                
    , U.LastModifiedTime = CES.LastModifiedTime                  
    , U.LastSyncTime = CES.LastSyncTime                
    , U.FlushValveNumber      = CES.FlushValveNumber                
  , U.CalibrationConductSS_Tank    = CES.CalibrationConductSS_Tank              
  , U.BackFlowControl     = CES.BackFlowControl                  
  , U.FactorFM_B_FM       = CES.FactorFM_B_FM               
  , U.AcceptedDeviationRingLine  = CES.AcceptedDeviationRingLine                  
  , U.UsePumpOfGroup1ForTunnel   = CES.UsePumpOfGroup1ForTunnel              
  , U.pHSensorEnabled            = CES.pHSensorEnabled              
  , U.Concentration = CES.Concentration              
  , U.Deadband = CES.Deadband             
  , U.WasherGroupNumber = CES.WasherGroupNumber          
  , U.ValveOutputAsTom = CES.ValveOutputAsTom          
  , U.FlowSwitchNumber = CES.FlowSwitchNumber         
  , U.FlushTimeForFlushValve = CES.FlushTimeForFlushValve      
    , U.MinimumFlowRate = CES.MinimumFlowRate    
  , U.ProductDensity = CES.ProductDensity    
  , U.MaximumConcentration  = CES.MaximumConcentration    
  ,U.DosingLineMode =1 
  FROM #Equipment U                  
   JOIN                  
   TCD.ControllerEquipmentSetup CES                  
  ON U.ControllerEquipmentId = CES.ControllerEquipmentId                  
  AND U.ControllerEquipmentTypeId = CES.ControllerEquipmentTypeId               
  JOIN TCD.ConduitController CC ON CES.ControllerID = CC.ControllerId                
  LEFT JOIN TCD.TunnelCompartmentEquipmentValveMapping TCEVM ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId                
  LEFT JOIN TCD.WasherGroup WG ON CES.ControllerID = WG.ControllerID                 
  LEFT JOIN TCD.MachineSetup MS ON WG.ControllerId = MS.ControllerId          
  WHERE CES.EcoLabAccountNumber = @EcoLabAccountNumber                  
   AND CES.ControllerId = @ControllerId; 
      

   IF(@ControllerModelId = 11)                
   BEGIN            
   UPDATE U             
   SET U.WasherGroupTypeId = (SELECT MIN(WG.WasherGroupTypeId) FROM TCD.WasherGroup WG WHERE WG.ControllerId = @ControllerId)            
    FROM #Equipment U                  
JOIN                  
   TCD.ControllerEquipmentSetup CES                  
  ON U.ControllerEquipmentId = CES.ControllerEquipmentId                  
  AND U.ControllerEquipmentTypeId = CES.ControllerEquipmentTypeId                
  WHERE CES.EcoLabAccountNumber = @EcoLabAccountNumber                  
   AND CES.ControllerId = @ControllerId            
   AND CES.ControllerEquipmentId IN (select top 14 CES.ControllerEquipmentId FROM  TCD.ControllerEquipmentSetup CES            
   where CES.ControllerId = @ControllerId )            

     UPDATE U             
   SET U.WasherGroupTypeId = (SELECT MAX(WG.WasherGroupTypeId) FROM TCD.WasherGroup WG WHERE WG.ControllerId = @ControllerId)            
    FROM #Equipment U                  
   JOIN                  
   TCD.ControllerEquipmentSetup CES                  
  ON U.ControllerEquipmentId = CES.ControllerEquipmentId                  
  AND U.ControllerEquipmentTypeId = CES.ControllerEquipmentTypeId               
  JOIN TCD.ConduitController CC ON CES.ControllerID = CC.ControllerId         
  WHERE CES.EcoLabAccountNumber = @EcoLabAccountNumber                  
   AND CES.ControllerId = @ControllerId            
   AND CES.ControllerEquipmentId IN (select  CES.ControllerEquipmentId FROM TCD.ControllerEquipmentSetup CES            
    where CES.ControllerId = @ControllerId AND             
    CES.ControllerEquipmentId BETWEEN 15 AND 28 )        

   UPDATE U SET U.NumberOfCompartments = ms.NumberOfComp        
   FROM #Equipment U        
   INNER JOIN TCD.ControllerEquipmentSetup ces        
   ON u.ControllerEquipmentId = ces.ControllerEquipmentId         
   INNER JOIN TCD.WasherGroup wg ON ces.ControllerId = WG.ControllerId        
   INNER JOIN TCD.MachineSetup ms ON ms.ControllerId = ces.ControllerId AND ms.GroupId = WG.WasherGroupId        
   WHERE ces.ControllerId = @ControllerId AND U.WasherGroupTypeId = 2  AND ms.IsTunnel = 1 AND WG.WasherDosingNumber = U.WasherGroupNumber        
   END          

  -- END                
    GOTO ExitModule;                  
ExitModule:
    SELECT                  
    T.ControllerEquipmentId   AS ControllerEquipmentId                  
  , T.ControllerEquipmentTypeId AS ControllerEquipmentTypeId                  
  , T.IsActive      AS IsActive                  
  , T.ProductId     AS ProductId                  
  , T.ProductName     AS ProductName                  
  , T.PumpCalibration    AS PumpCalibration                  
  , T.FlowMeterSwitchFlag   AS FlowMeterSwitchFlag                  
  , T.MaximumDosingTime    AS MaximumDosingTime                  
  , T.FlowSwitchTimeOut    AS FlowSwitchTimeOut                  
  , T.ControllerEquipmentSetupId  AS ControllerEquipmentSetupId                  
  , @EcoLabAccountNumber    AS EcoLabAccountNumber                  
  , @ControllerId     AS ControllerId                  
  , CC.TopicName     AS ControllerName                  
  , CC.ControllerTypeId    AS ControllerTypeId                  
  , T.LfsChemicalName    AS LfsChemicalName                  
  , T.KFactor      AS KFactor                  
  , T.TunnelHold     AS TunnelHold                  
  , T.FlowDetectorType    AS FlowDetectorType                  
, T.FlowSwitchAlarm    AS FlowSwitchAlarm                  
  , T.FlowMeterAlarm    AS FlowMeterAlarm                  
  , T.FlowMeterType     AS FlowMeterType                  
 , T.FlowAlarmDelay    AS FlowAlarmDelay                  
  , T.FlowMeterPumpDelay    AS FlowMeterPumpDelay                  
  , T.FlowMeterAlarmDelay   AS FlowMeterAlarmDelay                  
  , (                  
    SELECT MTS.TagAddress                  
  FROM TCD.ModuleTags MTS                  
  WHERE MTS.TagType = @TagTypeLfs                  
    AND MTS.ModuleID = ControllerEquipmentSetupId                  
    AND MTS.ModuleTypeId = 4                  
    AND MTS.Active = 1) AS LfsChemicalNameTag                  
  , (                  
    SELECT MTS.TagAddress                  
  FROM TCD.ModuleTags MTS                  
  WHERE MTS.TagType = @TagTypeKfactor                  
    AND MTS.ModuleID = ControllerEquipmentSetupId                  
    AND MTS.ModuleTypeId = 4                  
    AND MTS.Active = 1) AS KfactorTag                  
  , (                  
    SELECT MTS.TagAddress                  
  FROM TCD.ModuleTags MTS                  
  WHERE MTS.TagType = @TagTypeCalibration                  
    AND MTS.ModuleID = ControllerEquipmentSetupId                  
    AND MTS.ModuleTypeId = 4                  
    AND MTS.Active = 1) AS CalibrationTag                  
  , T.ControllerEquipmentTypeModelID                  
  , T.ConventionalWasherGroupConnection                  
  , T.AxillaryPumpCalibration                  
  , T.FlowmeterSwitchActivated                  
  , T.FlushWhileDosing                  
  , T.WeightControlledDosage                  
  , T.EquipmentDoseAlone                  
  , T.LowLevelAlarm                  
  , T.LeakageAlarm                  
  , T.FlushTime                  
  , T.PumpingTime                  
  , T.PreFlushTime                  
  , T.NightFlushPauseTime                  
  , T.NightFlushTime                  
  , T.AcceptedDeviation                  
  , T.LineNumber                
  , T.DirectDosingFlag                  
  , T.DirectDosingMachineInternalId                  
  , T.DirectDosingTunnelCompartmentId                  
  , T.LastModifiedTime    AS LastModifiedTime                  
  , T.LastSyncTime     AS LastSyncTime             
  , T.WasherGroupTypeId                     
  , T.NumberOfCompartments                     
  , T.FlushValveNumber                      
  , T.CalibrationConductSS_Tank                   
  , T.BackFlowControl                       
  , T.FactorFM_B_FM                      
  , T.AcceptedDeviationRingLine                    
  , T.UsePumpOfGroup1ForTunnel                    
  , T.pHSensorEnabled                
  , T.Concentration              
  , T.Deadband              
  , T.WasherGroupNumber          
  , T.ValveOutputAsTom          
  , T.FlowSwitchNumber          
  , T.FlushTimeForFlushValve      
    , T.MinimumFlowRate     
  , T.ProductDensity     
  , T.MaximumConcentration   
  , T.DosingLineMode 
  FROM #Equipment T                  
   JOIN                  
   TCD.ConduitController CC ON CC.ControllerId = @ControllerId                  
  WHERE T.IsActive = ISNULL(@IsActive, T.IsActive)                  
   AND T.ControllerEquipmentId = ISNULL(@ControllerEquipmentId, T.ControllerEquipmentId)        
   ORDER BY  T.ControllerEquipmentId;                  
    SET NOCOUNT OFF;                  
    RETURN                  
    @ReturnValue;                  
END;   


/*  
End TCD.GetControllerEquipmentList  

*/  

