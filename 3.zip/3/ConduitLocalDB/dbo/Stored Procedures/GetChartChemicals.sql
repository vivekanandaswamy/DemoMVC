﻿/*  
 ==========================================================================================  
 Purpose:  Fetching the parameter Values for chemical chart.  

 Author:  Premchand Yelavarthi  

 --------------------------------------------------------------  
 August-01-2014 ENT: Initial version.  
 ==========================================================================================  
 Exec [tcd].[GetChartChemicals] 12,3
*/ 
CREATE PROCEDURE [TCD].[GetChartChemicals](@WasherId Int = NULL) 
AS 
SET NOCOUNT ON
BEGIN 


DECLARE @IStunnel INT,@Ispress INT,@GroupId Int
	  SELECT @IStunnel = Istunnel,@Ispress = MS.HasPress,@GroupId = MS.GroupId FROM [TCD].machinesetup MS WHERE WasherId = @WasherId 
	  IF(@IStunnel = 1)
	  BEGIN
	  DECLARE @NoofComp Int = NULL, 
	   @Count int = 1

	   SELECT @NoOfcomp = NumberOfComp FROM [TCD].machinesetup 
		WHERE Groupid = @GroupId and IsTunnel = 1

	  CREATE TABLE #Get_Compartment (
	  Id INT,
	  GroupId INT,
	  MachineID INT,
	  CompartmentNumber VARCHAR(1000),
	  WasherId INT
	  )

	   WHILE(@count <=  @NoOfcomp) 
	   BEGIN
			 INSERT INTO #Get_Compartment(Id,GroupId,MachineID,CompartmentNumber,WasherId)
				SELECT @count + 0,@GroupId,@count,'Compartment'+ cast(@count as Varchar(1000))+'',@WasherId
			SET @count = @count + 1
	   End

	    SELECT 
				    Id ParameterID,
				    CompartmentNumber,
				    GroupId,
				    MachineID,WasherId
					   FROM #Get_Compartment

		   DROP TABLE #GET_COMPARTMENT

	  END
	  ELSE
	   BEGIN  
	   DECLARE @ProductCount int = NULL
	   SELECT @ProductCount = COUNT(1) FROM [TCD].WasherDosingProductMapping WP INNER JOIN [TCD].WasherDosingSetup WD ON WP.WasherDosingSetupId = WD.WasherDosingSetupId  WHERE WD.GroupId = @GroupID
	   IF(@ProductCount <= 8 AND @ProductCount <> 0) BEGIN SELECT 1 as ParameterID,'Chemical injection 1 to 8' AS parametername,null AS GroupId,null AS MachineId,@WasherId AS WasherId END
	   IF(@ProductCount > 8) BEGIN SELECT 1 as ParameterID,'Chemical injection 1 to 8' as parametername,null AS GroupId,null AS MachineId,@WasherId AS WasherId UNION ALL SELECT 2 as ParameterID,'Chemical injection 9 to 16' AS parametername,null AS GroupId,null AS MachineId,@WasherId AS WasherId END 
	   IF(@ProductCount = 0) BEGIN SELECT null as ParameterID,'' as parametername,null AS GroupId,null AS MachineId,null AS WasherId END
	   END
SET NOCOUNT OFF
END