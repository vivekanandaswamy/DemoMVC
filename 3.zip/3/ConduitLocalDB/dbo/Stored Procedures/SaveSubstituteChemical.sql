﻿CREATE PROCEDURE [TCD].[SaveSubstituteChemical]
	@OldProductId            INT                =            NULL
,    @NewProductId            INT                =            NULL
,    @ScalarOption            INT                =            0
,    @ScalarAmountPercent    INT                =            NULL
,    @WasherGroupId            NVARCHAR(1000)    =            NULL
,    @EcolabAccountNumber    NVARCHAR(25)    =            NULL
AS
BEGIN
    DECLARE   
        @ReturnValue        INT                =   0  
     ,    @ErrorId            INT                =   0  
	 ,	@LfsChemicalName	NVARCHAR(4000)		=	NULL
	 ,	@CurrentUTC			DATETIME			=	GETUTCDATE()
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

	SELECT @LfsChemicalName = pm.Name FROM TCD.ProductMaster pm WHERE pm.ProductId = @NewProductId
    -- Update Pump/Product Mapping in ControllerEquipmentSetup table
    UPDATE ces
    SET
        ces.ProductId = @NewProductId
	,	ces.LastModifiedTime = @CurrentUTC
	,	ces.LfsChemicalName = @LfsChemicalName
    FROM TCD.WasherGroup wg
    INNER JOIN TCD.MachineSetup ms 
    ON ms.GroupId = wg.WasherGroupId AND ms.IsDeleted = 'False'
    AND ms.EcoalabAccountNumber = wg.EcolabAccountNumber
    INNER JOIN TCD.ConduitController cc 
    ON cc.ControllerId = ms.ControllerId
    AND cc.EcoalabAccountNumber = ms.EcoalabAccountNumber
    INNER JOIN TCD.ControllerEquipmentSetup ces 
    ON ces.EcoLabAccountNumber = cc.EcoalabAccountNumber 
    AND ces.ControllerId = cc.ControllerId
    WHERE ((@WasherGroupId != '-1' AND @WasherGroupId != '' AND  wg.WasherGroupId IN (SELECT cast(items AS INT) FROM [TCD].[CharacterListToTable] (@WasherGroupId, ','))) OR (@WasherGroupId = '-1' OR @WasherGroupId = ''))
    AND ces.ProductId = @OldProductId AND ces.EcoLabAccountNumber = @EcolabAccountNumber

    SET @ErrorId = @@ERROR  
   
    IF (@ErrorId <> 0)  
     BEGIN  
       IF @@TRANCOUNT > 0  
       BEGIN  
        ROLLBACK TRAN  
       END  
       RAISERROR (@ErrorId, 16, 1)  
       SET  @ReturnValue = -1  
       RETURN (@ReturnValue)  
     END 
    -- Update Formula\Product Mapping in WasherDosingProductMapping
    UPDATE wdpm
    SET 
        wdpm.ProductId    =    @NewProductId
    ,    wdpm.Quantity    =    CASE WHEN @ScalarOption = 1 
                            THEN CASE WHEN (wdpm.Quantity - ((wdpm.Quantity * @ScalarAmountPercent)/100)) < 0 
                                 THEN 0
                                 ELSE  (wdpm.Quantity - ((wdpm.Quantity * @ScalarAmountPercent)/100))
                                 END
                            WHEN @ScalarOption = 2 
                            THEN (wdpm.Quantity + ((wdpm.Quantity * @ScalarAmountPercent)/100)) 
                            ELSE wdpm.Quantity 
                            END
	,	wdpm.LastModifiedTime = @CurrentUTC
    FROM TCD.WasherDosingProductMapping wdpm
    INNER JOIN TCD.WasherDosingSetup wds 
    ON wds.WasherDosingSetupId = wdpm.WasherDosingSetupId
    AND wds.EcoLabAccountNumber = wdpm.EcoLabAccountNumber
    INNER JOIN TCD.WasherProgramSetup wps 
    ON wps.WasherProgramSetupId = wds.WasherProgramSetupId
    AND wps.EcolabAccountNumber = wds.EcoLabAccountNumber
    INNER JOIN TCD.WasherGroup wg 
    ON wg.WasherGroupId = wps.WasherGroupId
    AND wps.EcolabAccountNumber = wg.EcoLabAccountNumber
    WHERE ((@WasherGroupId != '-1' AND @WasherGroupId != '' AND  wg.WasherGroupId IN (SELECT cast(items AS INT) FROM [TCD].[CharacterListToTable] (@WasherGroupId, ','))) OR (@WasherGroupId = '-1' OR @WasherGroupId = ''))
    AND wdpm.ProductId = @OldProductId
    AND wdpm.EcoLabAccountNumber = @EcolabAccountNumber

    SET @ErrorId = @@ERROR  
   
    IF (@ErrorId <> 0)  
     BEGIN  
       IF @@TRANCOUNT > 0  
       BEGIN  
        ROLLBACK TRAN  
       END  
       RAISERROR (@ErrorId, 16, 1)  
       SET  @ReturnValue = -1  
       RETURN (@ReturnValue)  
     END 

         -- Update Formula\Product Mapping in WasherDosingProductMapping With ControllerId
    UPDATE wdpm
    SET 
        wdpm.ProductId    =    @NewProductId
    ,    wdpm.Quantity    =    CASE WHEN @ScalarOption = 1 
                            THEN CASE WHEN (wdpm.Quantity - ((wdpm.Quantity * @ScalarAmountPercent)/100)) < 0 
                                 THEN 0
                                 ELSE  (wdpm.Quantity - ((wdpm.Quantity * @ScalarAmountPercent)/100))
                                 END
                            WHEN @ScalarOption = 2 
                            THEN (wdpm.Quantity + ((wdpm.Quantity * @ScalarAmountPercent)/100)) 
                            ELSE wdpm.Quantity 
                            END
 , wdpm.LastModifiedTime = @CurrentUTC
    FROM TCD.WasherDosingProductMapping wdpm
    INNER JOIN TCD.WasherDosingSetup wds 
    ON wds.WasherDosingSetupId = wdpm.WasherDosingSetupId
    AND wds.EcoLabAccountNumber = wdpm.EcoLabAccountNumber
    INNER JOIN TCD.WasherProgramSetup wps 
    ON wps.WasherProgramSetupId = wds.WasherProgramSetupId
    AND wps.EcolabAccountNumber = wds.EcoLabAccountNumber
    INNER JOIN TCD.WasherGroup wg 
    ON wg.ControllerId = wps.ControllerID
    AND wps.EcolabAccountNumber = wg.EcoLabAccountNumber
    WHERE ((@WasherGroupId != '-1' AND @WasherGroupId != '' AND  wg.WasherGroupId IN (SELECT cast(items AS INT) FROM [TCD].[CharacterListToTable] (@WasherGroupId, ','))) OR (@WasherGroupId = '-1' OR @WasherGroupId = ''))
    AND wdpm.ProductId = @OldProductId
    AND wdpm.EcoLabAccountNumber = @EcolabAccountNumber

    SET @ErrorId = @@ERROR  
   
    IF (@ErrorId <> 0)  
     BEGIN  
       IF @@TRANCOUNT > 0  
       BEGIN  
        ROLLBACK TRAN  
       END  
       RAISERROR (@ErrorId, 16, 1)  
       SET  @ReturnValue = -1  
       RETURN (@ReturnValue)  
     END 

    -- Update Tunnel\Product Mapping
    UPDATE tdpm
    SET 
        tdpm.Quantity    =    CASE WHEN @ScalarOption = 1 
                            THEN CASE WHEN (tdpm.Quantity - ((tdpm.Quantity * @ScalarAmountPercent)/100)) < 0 
                                 THEN 0
                                 ELSE  (tdpm.Quantity - ((tdpm.Quantity * @ScalarAmountPercent)/100))
                                 END
                            WHEN @ScalarOption = 2 
                            THEN (tdpm.Quantity + ((tdpm.Quantity * @ScalarAmountPercent)/100)) 
                            ELSE tdpm.Quantity 
                            END
	,	tdpm.LastModifiedTime = @CurrentUTC
    FROM TCD.TunnelDosingProductMapping tdpm
    INNER JOIN TCD.TunnelDosingSetup tds
    ON tds.TunnelDosingSetupId = tdpm.TunnelDosingSetupId
    AND tds.CompartmentNumber = tdpm.CompartmentNumber
    AND tds.EcolabAccountNumber = tdpm.EcolabAccountNumber
    AND tds.GroupId = tdpm.GroupId
    INNER JOIN TCD.TunnelProgramSetup tps 
    ON tps.TunnelProgramSetupId = tds.TunnelProgramSetupId
    AND tps.EcolabAccountNumber = tds.EcolabAccountNumber
    AND tps.WasherGroupId = tds.GroupId
    INNER JOIN TCD.WasherGroup wg
    ON wg.EcolabAccountNumber = tps.EcolabAccountNumber
    AND wg.WasherGroupId = tps.WasherGroupId
    INNER JOIN TCD.MachineSetup ms
    ON ms.GroupId = wg.WasherGroupId
    AND ms.EcoalabAccountNumber = wg.EcolabAccountNumber
    INNER JOIN TCD.TunnelCompartment tc
    ON tc.EcoLabAccountNumber = tdpm.EcoLabAccountNumber
    AND tc.WasherId = ms.WasherId
    AND tc.EcoLabAccountNumber = ms.EcoalabAccountNumber
    INNER JOIN TCD.ConduitController cc 
    ON cc.ControllerId = ms.ControllerId
    AND cc.EcoalabAccountNumber = ms.EcoalabAccountNumber
    INNER JOIN TCD.ControllerEquipmentSetup ces 
    ON ces.EcoLabAccountNumber = cc.EcoalabAccountNumber 
    AND ces.ControllerId = cc.ControllerId
    WHERE ((@WasherGroupId != '-1' AND @WasherGroupId != '' AND  wg.WasherGroupId IN (SELECT cast(items AS INT) FROM [TCD].[CharacterListToTable] (@WasherGroupId, ','))) OR (@WasherGroupId = '-1' OR @WasherGroupId = ''))
    AND ces.ProductId = @NewProductId
    AND wg.EcolabAccountNumber = @EcolabAccountNumber

    SET @ErrorId = @@ERROR  
   
    IF (@ErrorId <> 0)  
     BEGIN  
           IF @@TRANCOUNT > 0  
           BEGIN  
            ROLLBACK TRAN  
           END  
           RAISERROR (@ErrorId, 16, 1)  
           SET  @ReturnValue = -1  
           RETURN (@ReturnValue)  
     END
    ELSE
    BEGIN
        IF @@TRANCOUNT > 0  
        BEGIN  
            COMMIT  
        END
        RETURN (@ReturnValue)  
    END

END
GO