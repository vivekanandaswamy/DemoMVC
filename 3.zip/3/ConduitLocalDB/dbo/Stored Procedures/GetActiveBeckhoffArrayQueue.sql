﻿CREATE PROCEDURE [TCD].[GetActiveBeckhoffArrayQueue]
( 
  @ControllerId INT,
  @WasherId INT
)
AS
BEGIN

SET NOCOUNT ON              --SQLEnlight SA0017

 SELECT  Controllerid
    ,Washerid
    ,Address
    ,Value
    ,Timestamp
    ,TagType
    ,LoadId
 FROM
    TCD.BeckhoffArrayQueue 
 WHERE  Controllerid  =  @ControllerId AND 
    Washerid   =  @WasherId 
 ORDER BY Timestamp,TagOrder ASC
END
