﻿/*        

==========================================================================================        

Purpose: SOFT DELETING THE FINNISHER.        

Author:  Venkata Mohan Krishna K        

        

--------------------------------------------------------------        

September-25-2014 ENT: Initial version.        

==========================================================================================        

*/        

        

CREATE PROCEDURE [TCD].[DeleteFinnisher](

				@FinnisherId INT,
				@UserId Int,
				@EcolabAccountNumber nvarchar(25),
				@Scope Varchar(100) OUTPUT
			--Adding these 2 params as part of re-factoring for integration with Synch/Configurator
			,	@LastModifiedTimestampAtCentral		DATETIME	=	NULL		--Nullable for local call; Synch/Central call will have to pass this -
																				--else, it will be treated as a local call
			,	@OutputLastModifiedTimestampAtLocal	DATETIME	=	NULL	OUTPUT

)        
AS        
BEGIN        


SET nocount ON;        

Declare @OutPut varchar(100) = ''        

DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()

DECLARE
		@OutputList					AS	TABLE		(
		LastModifiedTimestamp			DATETIME
	)

SET	@Scope			=			ISNULL(@Scope, NULL)			--SQLEnlight SA0121
SET	@OutputLastModifiedTimestampAtLocal			=			ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight SA0121

--IF	NOT EXISTS	(	SELECT 1
--					FROM	METER M
--					JOIN	TCD.MachineGroup GT
--						on	M.GroupId = GT.Id 
--					WHERE	M.MachineCompartment = @FinnisherId 
--						AND GT.EcolabAccountNumber =@EcolabAccountNumber 
--						AND GT.GroupTypeId = 4 
--						AND M.Is_deleted = 0
--				)        
--				BEGIN        
						--If the call is not local, check that the LastModifiedTime matches with the central
						IF	(
								@LastModifiedTimestampAtCentral				IS NOT	NULL
							AND
							NOT	EXISTS	(	SELECT	1
											FROM	TCD.Finnishers				F
											WHERE	F.EcolabAccountNumber	=	@EcolabAccountNumber
												AND	F.FinnisherId			=	@FinnisherId
												AND	F.LastModifiedTime		=	@LastModifiedTimestampAtCentral
										)
							)
								BEGIN
										SET			@ErrorId				=	60000
										SET			@ErrorMessage			=	N'' + CAST(@ErrorId AS NVARCHAR(10))
										RAISERROR	(@ErrorMessage, 16, 1)
										SET			@ReturnValue			=	-1
										RETURN		(@ReturnValue)
								END

						--Proceed to soft-delet, since it's either a local call or Synch. call with synch. time matching
						UPDATE	[TCD].Finnishers
							SET Is_deleted = 1 
							,	LastModifiedByUserId = @UserId 
						--**	Adding as part of Audit re-factor to capture the User info.
							,	LastModifiedTime	=	@CurrentUTCTime
						OUTPUT	inserted.LastModifiedTime
						INTO	@OutputList	(
								LastModifiedTimestamp	)
						--**
						WHERE  FinnisherId = @FinnisherId AND EcolabAccountNumber =@EcolabAccountNumber
		--END
		--		ELSE
		--		BEGIN
		--				Set @OutPut ='501'        
		--				SELECT @Scope = @OutPut SELECT @Scope    
		--				Set @OutPut ='501'        
		--				SELECT @Scope = @OutPut SELECT @Scope    
		--		END

SELECT	TOP 1	
		@OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp
FROM	@OutputList							O


END