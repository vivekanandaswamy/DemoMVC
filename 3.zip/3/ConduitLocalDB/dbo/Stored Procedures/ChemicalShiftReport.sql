--exec [TCD].[ChemicalShiftReport] @Corporate=N'',@Country=N'',@Region=N'',@EcolabAccountNumber=N'',@Machine=N'',
--@machineGroup=N'',@Formula=N'',@MachineType=N'',@Category=N'',@FromDate='2015-01-02 00:00:00',
--@ToDate='2015-01-02 00:00:00',@GroupId=N'',@MachineInternalId=N'',@Date = '2015-01-02',@ProductId = 9894
--,@SortColumnID = 0,@SortDirection = 'ASC',@ReportID = 5,@IsDrillDown = 0

CREATE PROCEDURE [TCD].[ChemicalShiftReport] (
--DECLARE
									   @Corporate Varchar(max) = '',
									    @Country Varchar(max) = '',
									    @Region Varchar(max) = '',
									    @EcolabAccountNumber Nvarchar(25) = '',
									    @Machine Varchar(max) = '', 
									    @machineGroup Varchar(max) = '',
									    @Formula Varchar(max) = '',
									    @MachineType Varchar(20)= '',
									    @Category Varchar(max) = '',
									    @FromDate Date = '',
									    @ToDate Date = '',
									    @GroupId Varchar(max) = '',
									    @MachineInternalId Varchar(max) = '',
									    @Date DATE = NULL,
									    @ProductId VARCHAR(100) = '',
									    @SortColumnID INT = 0,
									    @SortDirection Varchar(100) = '',
									    @ReportID INT = NULL,
									    @IsDrillDown BIT = NULL
									    )

AS
BEGIN   
SET NOCOUNT ON;

DECLARE @Month INT = MONTH(GETDATE()),
	   @SortField Varchar(100) = '',
	   @SummationInMin Int = NULL,
	   @SQLStatement varchar(max)
	  
SET @Date = @FromDate

SET	@EcolabAccountNumber			=			ISNULL(@EcolabAccountNumber, NULL)			--SQLEnlight SA0029

    SELECT @SortField =  CASE WHEN @SortColumnID = 16 THEN 'AverageConsumption'
						    WHEN @SortColumnID = 17 THEN 'AverageDailyConsumption'
						    WHEN @SortColumnID = 47 THEN 'Chemical'
						    WHEN @SortColumnID = 54 THEN 'ActualConsumptionPerLoad'
						    WHEN @SortColumnID = 56 THEN 'Cost'						
						    WHEN @SortColumnID = 57 THEN 'CostExcess'
						    WHEN @SortColumnID = 58 THEN 'CostPerLoad'
						    WHEN @SortColumnID = 176 THEN 'TargetConsumptionPerLoad'
						    WHEN @SortColumnID = 177 THEN 'TargetConsumption'
						    WHEN @SortColumnID = 198 THEN 'TotalConsumption'
						    WHEN @SortColumnID = 242 THEN 'DateRange'
						    WHEN @SortColumnID = 0 THEN 'TotalConsumption'
					 END

DECLARE @CategoryTable TABLE(Category VARCHAR(100))
INSERT INTO @CategoryTable(Category) EXEC [TCD].[CharlistToTable] @Category,','


DECLARE @MachineTable TABLE(Machine VARCHAR(100))
INSERT INTO @MachineTable(Machine) EXEC [TCD].[CharlistToTable] @Machine,','


DECLARE @GroupMachineTable TABLE(GroupId INT,MachineInternalId INT)  
INSERT INTO @GroupMachineTable(GroupId,MachineInternalId)   
SELECT GroupId,MachineInternalId 
FROM 
TCD.MachineSetup MS 
INNER JOIN TCD.Washer WS ON MS.WasherId = WS.WasherId 
WHERE WS.PlantWasherNumber IN (SELECT Machine FROM @MachineTable);


DECLARE @GroupTable TABLE(GroupId VARCHAR(100))
INSERT INTO @GroupTable(GroupId) EXEC [TCD].[CharlistToTable] @GroupId,','


DECLARE @MachineInternalTable TABLE(MachineInternalId VARCHAR(100))
INSERT INTO @MachineInternalTable(MachineInternalId) EXEC [TCD].[CharlistToTable] @MachineInternalId,','

DECLARE @WasherGroupTable TABLE(MachineGroup VARCHAR(100))
INSERT INTO @WasherGroupTable(MachineGroup) EXEC [TCD].[CharlistToTable] @MachineGroup,','


DECLARE @FormulaTable TABLE(Formula VARCHAR(100))
INSERT INTO @FormulaTable(Formula) EXEC [TCD].[CharlistToTable] @Formula,','


--DECLARE @CustomerTable TABLE(Customer VARCHAR(100))
--INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','


DECLARE @MachineTypeTable TABLE(MachineType VARCHAR(100))
INSERT INTO @MachineTypeTable(MachineType) EXEC [TCD].[CharlistToTable] @MachineType,','

CREATE TABLE #ShiftResultTable  (	 
							  DateRange Varchar(100)
							 ,BatchId INT
							 ,ActualWeight DECIMAL(18,2)
							 ,StandardWeight DECIMAL(18,2)
							 ,[MachineId] [int] NULL
							 ,GroupId INT
							 ,MachineInternalId INT
							 ,ProgramNumber INT
							 ,ProductId INT
							 ,NoOfBatches INT
							 ,TotalConsumption DECIMAL(18,2)
							 ,TargetConsumption DECIMAL(18,2)
							 ,AverageConsumption DECIMAL(18,2)
							 ,ActualConsumptionPerLoad DECIMAL(18,2)
							 ,TargetConsumptionPerLoad DECIMAL(18,2)
							 ,Cost DECIMAL(18,2)
							 ,CostPerLoad DECIMAL(18,2)
							 ,CostExcess DECIMAL(18,2)
							 ,EcolabTextileId INT
							 ,EcolabTextileCategoryName VARCHAR(100)
							 ,PlantTextileId INT
							 ,PlantTextileCategoryName VARCHAR(100)
						  )

  CREATE TABLE #ShiftTable
				    (
				    RowNumber INT IDENTITY(1,1),
				    ShiftName Nvarchar(1000),
				    ShiftId INT,
				    StartTime DATETIME,
				    EndTime DATETIME
				    )

	   DECLARE @DayId INT = NULL,@Id INT = 1,@summingActualLoad Decimal(10,2) = NULL,@LastFirstTIme Datetime = NULL,@LastEndTIme Datetime = NULL

	   SELECT @summingActualLoad = (SUM(BD.[ActualWeight]) + CASE WHEN SUM(BD.ManualInputWeight) IS NULL THEN 0 ELSE SUM(BD.ManualInputWeight) END)  FROM TCD.BatchData BD 
													    LEFT OUTER JOIN
													    TCD.BatchCustomerData BCD ON BD.BatchID = BCD.BatchId
												    WHERE  CAST(BD.EndDate AS datetime) >= dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@Date AS DATE), 112) + ' ' + CONVERT(Varchar(8),'00:00:00') AS DateTime))
														  AND BD.Enddate <= DATEADD(DAY,1,dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10),  CAST(@Date AS DATE), 112) + ' ' + CONVERT(Varchar(8),'00:00:00') AS DateTime)))

			  SELECT @DayId = DayId from TCD.WeekDay WHERE DayName = DATENAME(dw,CAST(@Date AS DATE)) 

			  INSERT INTO #ShiftTable
							  (
							   ShiftName,
							   ShiftId ,
								StartTime ,
								EndTime 
							 )
			  SELECT 
				    SD.ShiftName,
				    SD.ShiftId,
				    dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), @Date, 112) + ' ' + CONVERT(Varchar(8), SD.StartTime) AS DateTime)) AS StartTime,
				    dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), @Date, 112) + ' ' + CONVERT(Varchar(8), SD.EndTime) AS DateTime)) AS EndTime
							  
					   FROM TCD.ShiftData SD 
									 WHERE DayId = @DayId AND SD.Is_Deleted = 0

			 SELECT TOP 1 @LastEndTIme = ST.EndTime FROM #ShiftTable ST ORDER BY ST.EndTime DESC 
			 SELECT TOP 1 @LastFirstTIme = ST.StartTime FROM #ShiftTable ST  ORDER BY ST.StartTime Asc 

			 IF(@LastEndTIme < dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(DATEADD(Day, DATEDIFF(Day, 0, @LastEndTIme),1) AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(DATEADD(Day, DATEDIFF(Day, 0, @LastEndTIme),1) AS TIME)) AS DateTime)))
				BEGIN
				INSERT INTO #ShiftTable(ShiftName,ShiftId,StartTime,EndTime)
				SELECT TOP 1 
					  'NoShift',
					  SHIFTID + 1,
					  @LastEndTIme,
					  dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(DATEADD(Day, DATEDIFF(Day, 0, @LastEndTIme),1) AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(DATEADD(Day, DATEDIFF(Day, 0, @LastEndTIme),1) AS TIME)) AS DateTime))
							 FROM #ShiftTable ORDER BY EndTime DESC
				END
			 IF(DATEADD(DAY,-1,dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(DATEADD(Day, DATEDIFF(Day, 0, @LastEndTIme),1) AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(DATEADD(Day, DATEDIFF(Day, 0, @LastEndTIme),1) AS TIME)) AS DateTime))) < @LastFirstTIme) --AND CAST(@LastFirstTIme AS date) = CAST(@Date AS date))
				BEGIN
				INSERT INTO #ShiftTable(ShiftName,ShiftId,StartTime,EndTime)
				SELECT TOP 1 
					   'Noshift',
					   SHIFTID + 1,
					   DATEADD(DAY,-1,dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(DATEADD(Day, DATEDIFF(Day, 0, @LastEndTIme),1) AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(DATEADD(Day, DATEDIFF(Day, 0, @LastEndTIme),1) AS TIME)) AS DateTime))),
					   @LastFirstTIme
							 FROM #ShiftTable ORDER BY EndTime DESC
				END



			 
				WHILE (@Id <= (SELECT COUNT(1) FROM #ShiftTable))
				    BEGIN
						  DECLARE @StartTime Datetime,@EndTime Datetime,@ShiftName Varchar(100),@TotalRunTimesec VARCHAR(100) = NULL
						  SELECT @StartTime = ST.StartTime,@EndTime = ST.EndTime,@ShiftName = ST.ShiftName FROM #ShiftTable ST WHERE RowNumber = @Id

						   INSERT INTO #ShiftResultTable(	 
							  DateRange
							 ,BatchId 
							 ,ActualWeight 
							 ,StandardWeight
							 ,[MachineId]  
							 ,GroupId 
							 ,MachineInternalId 
							 ,ProgramNumber 
							 ,ProductId 
							 ,NoOfBatches 
							 ,TotalConsumption 
							 ,TargetConsumption
							 ,AverageConsumption
							 ,ActualConsumptionPerLoad
							 ,TargetConsumptionPerLoad 
							 ,Cost 
							 ,CostPerLoad
							 ,CostExcess
							 ,EcolabTextileId 
							 ,EcolabTextileCategoryName 
							 ,PlantTextileId 
							 ,PlantTextileCategoryName 
						  )
						   SELECT 
							 @ShiftName
							,bd.BatchId
							,BD.ActualWeight
							,bd.StandardWeight
							,BD.MachineId
							,BD.GroupId
							,BD.MachineInternalId
							,BD.ProgramMasterId
							,(SELECT TOP 1 PRM.ProductId FROM TCD.ProductMaster PRM WHERE PRM.ProductId = BPD.ProductId) AS ProductId
							,COUNT(DISTINCT BD.BatchID) AS NoOfBatches
							,SUM(BPD.[ActualQuantity]) AS TotalConsumption
							,SUM(BPD.[StandardQuantity]) AS TargetConsumption
							 ,CASE WHEN COUNT(BD.ProgramNumber) <> 0 THEN
							 SUM(BPD.[ActualQuantity])/COUNT(BD.ProgramNumber)
							 ELSE 0 END AS AverageConsumption
							--,SUM(BPD.[ActualQuantity])/COUNT(BD.ProgramNumber) AS AverageConsumption
							,SUM(BPD.[ActualQuantity])/SUM(BD.[ActualWeight]) ActualConsumptionPerLoad
							,SUM(BPD.[StandardQuantity])/SUM(BD.[StandardWeight]) TargetConsumptionPerLoad
							,SUM(BPD.Price) AS Cost
							 ,SUM(BPD.Price)/COUNT(BD.BatchID) AS CostPerLoad
							,(CASE WHEN (SUM(BPD.[ActualQuantity]) - SUM(BPD.[StandardQuantity]) < 0) THEN 0 ELSE ABS(SUM(BPD.[ActualQuantity]) - SUM(BPD.[StandardQuantity]))*SUM(BPD.Price) END) CostExcess
							,ETC.TextileId AS EcolabTextileId
							,ETC.CategoryName AS EcolabTextileCategoryName
							,CTC.TextileId AS PlantTextileId
							,CTC.Name AS PlantTextileCategoryName
						FROM 
						TCD.BatchProductData BPD  
						   LEFT JOIN TCD.BatchData BD ON BPD.BatchID = BD.BatchID
						   LEFT OUTER JOIN TCD.ProgramMaster PM ON PM.ProgramId = BD.ProgramMasterId
						   LEFT JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId = PM.EcolabTextileCategoryId
						   LEFT OUTER JOIN TCD.ChainTextileCategory CTC ON  CTC.TextileId = PM.ChainTextileId
						 	WHERE  CAST(BD.EndDate AS datetime) >= @StartTime
									AND BD.Enddate <= @EndTime
								AND 
								CASE @Machine   
									WHEN '' THEN 'TRUE'         
									ELSE                                                      
									 CASE WHEN BD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
								    END='TRUE' 

								    AND       

								    CASE @machineGroup   
									WHEN '' THEN 'TRUE'         
									ELSE                                                      
									 CASE WHEN BD.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable) THEN 'TRUE' END                                                      
								    END='TRUE' 

								    AND    

								    CASE @Formula   
									WHEN '' THEN 'TRUE'         
									ELSE                                                      
									 CASE WHEN BD.ProgramNumber IN (SELECT Formula FROM @FormulaTable) THEN 'TRUE' END                                                      
								    END='TRUE' 

								    AND       

								    CASE @MachineType   
									WHEN '' THEN 'TRUE'         
									ELSE                                                      
									 CASE WHEN BD.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable)) THEN 'TRUE' END                                                      
								    END='TRUE' 

								    AND       
								   CASE @Category   
									WHEN '' THEN 'TRUE'         
									ELSE                                                      
									 CASE WHEN ETC.TextileId IN (SELECT Category FROM @CategoryTable) THEN 'TRUE' END                                                      
								    END='TRUE' 

								    AND
									CASE @GroupId 
									WHEN '' THEN 'TRUE' 
									ELSE        
								    CASE WHEN (BD.GroupId IN (@GroupId) AND 
									 BD.MachineInternalId IN (@MachineInternalId)) THEN 'TRUE' END                                                   
								    END='TRUE' 
								    AND
									CASE @MachineInternalId 
									WHEN '' THEN 'TRUE' 
									ELSE        
								    CASE WHEN (BD.GroupId IN (@GroupId) AND 
									 BD.MachineInternalId IN (@MachineInternalId)) THEN 'TRUE' END                                                   
								    END='TRUE' 
								     GROUP BY 
										    BD.MachineId,BD.BatchId,BD.GroupId,BD.MachineInternalId,BD.ProgramMasterId,ETC.CategoryName,ETC.TextileId
										    ,BPD.ProductId,CTC.Name,CTC.TextileId,BD.ActualWeight,bd.StandardWeight
								    							   
									 SET @Id = @Id + 1
				    END

				   

				    IF(@ReportID = 5)
				    BEGIN
				    SELECT 
							 0 AS Id,
							 DateRange,
							 SUM(CCR.TotalConsumption) AS TotalConsumption,
							 SUM(CCR.TargetConsumption) AS TargetConsumption,
							 CAST(SUM(CCR.TotalConsumption)/COUNT(DISTINCT CCR.ProgramNumber) AS decimal(18,2)) AS AverageConsumption,
							 0.00 AverageDailyConsumption,
							 CAST(SUM(CCR.TotalConsumption)/COUNT(CCR.BatchId) AS decimal(18,2)) AS ActualConsumptionPerLoad,
							 CAST(SUM(CCR.TargetConsumption)/COUNT(CCR.BatchId) AS decimal(18,2)) AS TargetConsumptionPerLoad,
							 SUM(CCR.Cost) AS Cost,
							 CAST(SUM(CCR.Cost)/COUNT(CCR.BatchId) AS decimal(18,2)) AS CostPerLoad,
							 CAST((CASE WHEN (SUM(CCR.TotalConsumption) - SUM(CCR.TargetConsumption) < 0) THEN 0 ELSE ABS(SUM(CCR.TotalConsumption) - SUM(CCR.TargetConsumption))*SUM(CCR.Cost) END) AS decimal(18,2)) AS CostExcess,
							 CAST(1 AS BIT) AS IsDrillDown,
							 COUNT(CCR.BatchId) AS NoOfBatches,
							 COUNT(DISTINCT CCR.ProgramNumber) AS NoOfPrograms,
							 1 NoOfDays
							 INTO #ResultTable
					    FROM #ShiftResultTable CCR INNER JOIN TCD.ProductMaster PM ON CCR.ProductId = PM.ProductId
					    WHERE TotalConsumption IS NOT NULL AND CCR.DateRange NOT Like '%Noshift%' AND
							  CASE @ProductId   
									WHEN '' THEN 'TRUE'         
									ELSE                                                      
									 CASE WHEN PM.ProductID = @ProductId THEN 'TRUE' END                                                      
									END='TRUE' 
					    GROUP BY Name,CCR.ProductId,DateRange--,ProgramNumber

					     INSERT INTO #ResultTable(
											 Id,
											 DateRange,
											 TotalConsumption,
											 TargetConsumption,
											 AverageConsumption,
											 AverageDailyConsumption,
											 ActualConsumptionPerLoad,
											 TargetConsumptionPerLoad,
											 Cost,
											 CostPerLoad,
											 CostExcess,
											 IsDrillDown,
											 NoOfBatches,
											 NoOfPrograms,
											 NoOfDays
											)
						   SELECT 
								0 AS Id,
								DateRange,
								SUM(TotalConsumption) AS TotalConsumption,
								SUM(TargetConsumption) AS TargetConsumption,
								SUM(AverageConsumption) AS AverageConsumption,
								0.00 AverageDailyConsumption,
								SUM(ActualConsumptionPerLoad) AS ActualConsumptionPerLoad,
								SUM(TargetConsumptionPerLoad) AS TargetConsumptionPerLoad,
								SUM(CCR.Cost) AS Cost,
								SUM(CostPerLoad) AS CostPerLoad,
								SUM(CostExcess) AS CostExcess,
								CAST(1 AS BIT) AS IsDrillDown,
								COUNT(CCR.BatchId) AS NoOfBatches,
								COUNT(DISTINCT CCR.ProgramNumber) AS NoOfPrograms,
								1 NoOfDays
								FROM #ShiftResultTable CCR INNER JOIN TCD.ProductMaster PM ON CCR.ProductId = PM.ProductId
					    WHERE TotalConsumption IS NOT NULL AND CCR.DateRange Like '%Noshift%' AND
							  CASE @ProductId   
									WHEN '' THEN 'TRUE'         
									ELSE                                                      
									 CASE WHEN PM.ProductID = @ProductId THEN 'TRUE' END                                                      
									END='TRUE' 
					    GROUP BY Name,CCR.ProductId,DateRange--,ProgramNumber



				    SET @SQLStatement 
					   ='SELECT 
							 Id,
							 DateRange,
							 TotalConsumption,
							 TargetConsumption,
							 AverageConsumption,
							 AverageDailyConsumption,
							 ActualConsumptionPerLoad,
							 TargetConsumptionPerLoad,
							 Cost,
							 CostPerLoad,
							 CostExcess,
							 IsDrillDown,
							 NoOfBatches,
							 NoOfPrograms,
							 NoOfDays
					    FROM #ResultTable ORDER BY ' + @SortField + ' ' + @SortDirection

	   			    EXEC(@SQLStatement)
				    END
				     DROP TABLE #ShiftResultTable
				    DROP TABLE #ShiftTable
				    DROP TABLE #ResultTable

END

--SELECT * FROM TCD.BatchProductData 

