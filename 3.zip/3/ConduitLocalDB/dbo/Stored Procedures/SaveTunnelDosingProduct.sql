﻿/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_SaveTunnelDosingProduct]                                             

Purpose:				To add the tunnel group wash steps formula.

Parameters:				@EcoLabAccountNumber - holds ecolab account number.
						@ControllerEquipmentSetupId - holds the controller equipment setup id.
						@TunnelDosingSetupId - holds the tunnel dosing setup id.
						@WasherGroupId - holds the washer group id.
						@CompartmentNumber - holds the compartment number.
						@Quantity - holds the quantity.
						@DelayTime - holds the delay time.
						@UserId - holds the user id.
						@DeleteFlag	- holds the boolean value weather it is deleted or not
																
###################################################################################################                                           
*/
CREATE	PROCEDURE	[TCD].[SaveTunnelDosingProduct]	(
					@EcoLabAccountNumber					NVARCHAR(25)
				,	@ControllerEquipmentSetupId				INT			= NULL		
				,	@TunnelProgramSetupId					INT	
				,	@TunnelDosingSetupId					INT			= NULL						
				,	@WasherGroupId							INT						--WasherGroupId to which the formula is associated
				,	@CompartmentNumber						INT						--Compartment no. of the tunnel to which the formula will/is(?) associated
				,	@Quantity								DECIMAL(18,3)	= NULL
				,	@DelayTime								INT				= NULL
				,	@UserId									INT
				,	@DeleteFlag								BIT			=			'FALSE'	--DO NOT SET THIS (to TRUE) UNLESS DELETE IS INTENDED
				,	@LastModifiedTimestampAtCentral			DATETIME					=	NULL
				,	@OutputLastModifiedTimestampAtLocal		DATETIME					=	NULL	OUTPUT
				)
AS 
BEGIN 
DECLARE 
@CurrentUTCTime					DATETIME		=			GETUTCDATE(),
@MyServiceFrmulaStpDsgDvcGuid	UNIQUEIDENTIFIER	=			NEWID(),
@ReturnValue					INT				=			0,
@IsDrain						NVARCHAR(100)	=			N''

DECLARE
			@OutputList								AS	TABLE		(
			LastModifiedTimestamp					DATETIME
		)

SELECT @IsDrain	= StepName FROM tcd.WashStep WHERE StepId=(SELECT StepTypeId FROM tcd.TunnelDosingSetup 
		WHERE TunnelDosingSetupId=@TunnelDosingSetupId AND GroupId=@WasherGroupId AND CompartmentNumber= @CompartmentNumber)

IF @IsDrain = 'Drain'
BEGIN
	SET @Quantity = 0
END

IF	(	@DeleteFlag	<>	'TRUE'	)
BEGIN
IF EXISTS(select * from TCD.TunnelDosingProductMapping where TunnelDosingSetupId = @TunnelDosingSetupId AND ControllerEquipmentSetupId = @ControllerEquipmentSetupId)
BEGIN
	UPDATE TCD.TunnelDosingProductMapping
	SET Quantity = @Quantity, DelayTime = @DelayTime where TunnelDosingSetupId = @TunnelDosingSetupId AND ControllerEquipmentSetupId = @ControllerEquipmentSetupId
END
ELSE
BEGIN
	INSERT INTO	[TCD].TunnelDosingProductMapping (
									EcoLabAccountNumber
								,	TunnelDosingSetupId
								,	Quantity
								,	DelayTime
								,	CompartmentNumber
								,	GroupId
								,	ControllerEquipmentSetupId
								,	LastModifiedByuserId
								,	MyServiceFrmulaStpDsgDvcGuid
								)
							SELECT
									@EcoLabAccountNumber			AS			EcoLabAccountNumber
								,	@TunnelDosingSetupId			AS			TunnelDosingSetupId
								,	@Quantity						AS			Quantity
								,	@DelayTime						AS			DelayTime
								,	@CompartmentNumber				AS			CompartmentNumber
								,	@WasherGroupId					AS			GroupId
								,	@ControllerEquipmentSetupId		AS			ControllerEquipmentSetupId
								,	@UserId							AS			UserId
								,	@MyServiceFrmulaStpDsgDvcGuid	AS			MyServiceFrmulaStpDsgDvcGuid

								UPDATE TCD.TunnelProgramSetup
								SET
								LastModifiedTime = @CurrentUTCTime
								OUTPUT
									inserted.LastModifiedTime		AS			LastModifiedTimestamp
								INTO
									@OutputList	(
									LastModifiedTimestamp
								)
								WHERE 
								TunnelProgramSetupId = @TunnelProgramSetupId
								AND
								EcolabAccountNumber = @EcolabAccountNumber
END

SET		@OutputLastModifiedTimestampAtLocal			=			ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight SA0121
SET		@LastModifiedTimestampAtCentral				=			ISNULL(@LastModifiedTimestampAtCentral, NULL)				--SQLEnlight SA0029

SELECT	TOP 1	
		@OutputLastModifiedTimestampAtLocal		=	O.LastModifiedTimestamp
FROM	@OutputList	O




--SET	NOCOUNT	ON

--DECLARE	
--		@ReturnValue					INT				=			0
--	,	@ErrorId						INT				=			0
--	,	@ErrorMessage					NVARCHAR(4000)	=			N''
--	,	@IsDrain						NVARCHAR(100)	=			N''
--	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()
--	,	@MyServiceFrmulaStpDsgDvcGuid	UNIQUEIDENTIFIER	=			NEWID()

--DECLARE
--			@OutputList								AS	TABLE		(
--			LastModifiedTimestamp					DATETIME
--		)

--SET		@OutputLastModifiedTimestampAtLocal			=			ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight SA0121
--SET		@LastModifiedTimestampAtCentral				=			ISNULL(@LastModifiedTimestampAtCentral, NULL)				--SQLEnlight SA0029

--SELECT @IsDrain= StepName FROM tcd.WashStep WHERE StepId=(SELECT StepTypeId FROM tcd.TunnelDosingSetup 
--		WHERE TunnelDosingSetupId=@TunnelDosingSetupId AND GroupId=@WasherGroupId AND CompartmentNumber= @CompartmentNumber)

--IF	(	@DeleteFlag	=	'TRUE'	)
--	BEGIN

--			DELETE	TDPM
--			FROM	[TCD].TunnelDosingProductMapping			TDPM
--			WHERE	TDPM.EcoLabAccountNumber			=			@EcoLabAccountNumber
--				AND	TDPM.GroupId					=			@WasherGroupId
--				AND TDPM.CompartmentNumber			=			@CompartmentNumber
--				AND TDPM.TunnelDosingSetupId		=			@TunnelDosingSetupId
--			--check for any error
--			SET	@ErrorId	=	@@ERROR

--			IF	(@ErrorId	<>	0)
--			BEGIN
--				SET		@ErrorMessage				=			N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred overwriting tunnel PRODUCT data.'
--				RAISERROR	(@ErrorMessage, 16, 1)
--				SET	@ReturnValue	=	-1
--				RETURN	(@ReturnValue)
--			END

--	END

--ELSE IF @IsDrain = 'Drain'
--	BEGIN

--			DELETE	TDPM

--			FROM	[TCD].TunnelDosingProductMapping			TDPM

--			WHERE	TDPM.EcoLabAccountNumber		=			@EcoLabAccountNumber

--				AND	TDPM.GroupId					=			@WasherGroupId

--				AND TDPM.CompartmentNumber			=			@CompartmentNumber

--				AND TDPM.TunnelDosingSetupId		=			@TunnelDosingSetupId

--			--check for any error

--			SET	@ErrorId	=	@@ERROR

--			IF	(@ErrorId	<>	0)

--			BEGIN

--				SET		@ErrorMessage				=			N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred overwriting tunnel PRODUCT data.'

--				RAISERROR	(@ErrorMessage, 16, 1)

--				SET	@ReturnValue	=	-1

--				RETURN	(@ReturnValue)

--			END



--	END

--ELSE
--	BEGIN
--		IF	NOT	EXISTS (SELECT	1
--						FROM	[TCD].TunnelDosingProductMapping TDPM
--						WHERE	TDPM.EcoLabAccountNumber	=			@EcoLabAccountNumber
--						AND	TDPM.GroupId					=			@WasherGroupId
--						AND TDPM.CompartmentNumber			=			@CompartmentNumber
--						AND TDPM.ControllerEquipmentSetupId =			@ControllerEquipmentSetupId
--						)
--				BEGIN
--						INSERT INTO	[TCD].TunnelDosingProductMapping (
--									EcoLabAccountNumber
--								,	TunnelDosingSetupId
--								,	Quantity
--								,	DelayTime
--								,	CompartmentNumber
--								,	GroupId
--								,	ControllerEquipmentSetupId
--								,	LastModifiedByuserId
--								,	MyServiceFrmulaStpDsgDvcGuid
--								)
--							SELECT
--									@EcoLabAccountNumber			AS			EcoLabAccountNumber
--								,	@TunnelDosingSetupId			AS			TunnelDosingSetupId
--								,	@Quantity						AS			Quantity
--								,	@DelayTime						AS			DelayTime
--								,	@CompartmentNumber				AS			CompartmentNumber
--								,	@WasherGroupId					AS			GroupId
--								,	@ControllerEquipmentSetupId		AS			ControllerEquipmentSetupId
--								,	@UserId							AS			UserId
--								,	@MyServiceFrmulaStpDsgDvcGuid	AS			MyServiceFrmulaStpDsgDvcGuid

--								UPDATE TCD.TunnelProgramSetup
--								SET
--								LastModifiedTime = @CurrentUTCTime
--								OUTPUT
--									inserted.LastModifiedTime		AS			LastModifiedTimestamp
--								INTO
--									@OutputList	(
--									LastModifiedTimestamp
--								)
--								WHERE 
--								TunnelProgramSetupId = @TunnelProgramSetupId
--								AND
--								EcolabAccountNumber = @EcolabAccountNumber



--						--check for any error
--						SET	@ErrorId	=	@@ERROR

--						IF	(@ErrorId	<>	0)
--						BEGIN
--							SET		@ErrorMessage			=			N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred overwriting tunnel PRODUCT data.'
--							RAISERROR	(@ErrorMessage, 16, 1)
--							SET	@ReturnValue	=	-1
--							RETURN	(@ReturnValue)
--						END
--				END
--	END

--SELECT	TOP 1	
--		@OutputLastModifiedTimestampAtLocal		=	O.LastModifiedTimestamp
--FROM	@OutputList							O

		
--IF	(	@ErrorId	=	0	)
--BEGIN
--	RETURN	(@ReturnValue)
--END


--SET	NOCOUNT	OFF
--RETURN	(@ReturnValue)

END
RETURN	(@ReturnValue)
END
