CREATE PROCEDURE [TCD].[ReportOperationsSummary] 
/******************************************************************

DESCRIPTION  : Populating Operation Summary Report  data based on filters and views,sub views.


MODIFICATION HISTORY DETAILS: 
 21st Jan 2015 -  Kiran     -  Added Formula hierarchy -->Formula segment-->Formula category-->formula
 06-JUN-2015	PSAJJA Added SortOrder in TimeView to ensure the Dates and Graphs are in Ascending Order


REFERENC TABLES :
  Select * from TCD.Plant --Plant master
  Select * FROM TCD.PlantChain  --Master Plants
  Select * FROM TCD.PlantChainProgram
  Select * FROM TCD.ChainTextileCategory
  Select * FROM #ProgramMaster
  Select * FROM TCD.EcolabTextileCategory  --Masters
  Select * FROM TCD.EcolabSaturation --Masters
  Select * FROM TCD.FormulaSegments --Masters

EXECUTION STATEMENT :

 EXEC [TCD].[ReportOperationsSummary] @startdate = '2015-01-11',@enddate = '2016-01-30',@Viewtype  = '8',@Subview = '22',
          @Drillvalue = '',@EcolabAccountNumber = '040242802',@MachineType = '', @MachineGroup  = '',@Machine  = '', 
          @EcolabCategory  = '',@ChainCategory  = '', @PlantFormula  = '', @ChainFormula = '', @Customer  = '',
          @SortColumnId  = 0,@SortDirection  = '',@CurrencyCode = '', @UserId = 1, @FormulaSegement ='',
          @FormulaCategory='',@Formula=''

		  
*******************************************************************/
     @startdate datetime = '',
     @enddate datetime = '',
     @Viewtype Int = '',
     @Subview Int= '',
     @Drillvalue varchar(100)= '',
     @EcolabAccountNumber Nvarchar(25) = '',
     @MachineType VARCHAR(20)= '',  --Washer Group type
     @MachineGroup VARCHAR(MAX) = '',  --washer Group
     @Machine VARCHAR(MAX) = '',
     @EcolabCategory VARCHAR(MAX) = '', --EcolabcategoritextileID
     @ChainCategory VARCHAR(MAX) = '',  --Chain Texttilecategori ID
     @PlantFormula  VARCHAR(MAX) = '',
     @ChainFormula VARCHAR(MAX) = '',
     @Customer VARCHAR(MAX) = '',
     @SortColumnId int = 0,
     @SortDirection varchar(4) = '',
     @CurrencyCode varchar(3) = '',
     @UserId INT = NULL,
	@FormulaSegement VARCHAR(MAX)='', --Formula segment,
	@FormulaCategory VARCHAR(MAX)='', --Formula category
	@Formula VARCHAR(MAX)='' --Formula
AS   
BEGIN   
SET NOCOUNT ON

    DECLARE @InputStartDate DATETIME = DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),@startdate) ,
    @InputEndDate DATETIME =DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),@Enddate)  

    --SET @startdate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@startdate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@startdate AS time)) AS DateTime))
    --SET @EndDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndDate AS time)) AS DateTime))
 --SELECT @startdate,@enddate

    DECLARE @ReportGenerated INT = 6, @Month INT = MONTH(GETDATE()),@NoOfLoads int
 --SELECT @Month

    --Inserting the record into Report History 
 INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)
 SELECT @EcolabAccountNumber,UM.UserId, UM.LoginName, GETUTCDATE(), @ReportGenerated,
 CASE WHEN @ReportGenerated = 6 THEN 'Generated Report : Operations Summary Report' END
 FROM TCD.UserMaster UM
 WHERE UM.EcolabAccountNumber = @EcolabAccountNumber AND UM.UserId = @UserId
    --Completed the record insertion into Report History */

DECLARE  @ActualEnergyConsumption	 Decimal(18,2)
	   ,@TargetEnergyConsumption	 Decimal(18,2)

	   ,@ActualWaterConsumption	 Decimal(18,2)
	   ,@TargetWaterConsumption	 Decimal(18,2)

	   ,@ActualWaterCost		 Decimal(18,2)
	   ,@ActualEnergyCost		 Decimal(18,2);


 -- Return Table set
    DECLARE @resultSet Table
    (
      ShiftId Int,DateRange varchar(100),TotalLoad Decimal(18,2),Numberofbatches INT,ActualChemicalConsumption Decimal(18,2),
      TargetChemicalConsumption Decimal(18,2),ActualEnergyConsumption  Decimal(18,2),TargetEnergyConsumption Decimal(18,2),
      ActualWaterConsumption  Decimal(18,2),TargetWaterConsumption Decimal(18,2),ActualChemicalCost Decimal(18,2),ActualWaterCost Decimal(18,2),
      ActualEnergyCost Decimal(18,2),Viewtype varchar(100) , Subview varchar(100) , Id int, SortOrder int
    )

 --Machine types 
    DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))
    INSERT INTO @MachineTypeTable EXEC [TCD].[CharlistToTable] @MachineType,','

 --Washergroups 
    DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))
    INSERT INTO @WasherGroupTable EXEC [TCD].[CharlistToTable] @machineGroup,','  

 --Machine list
    DECLARE @MachineTable TABLE(Machine Varchar(100))
    INSERT INTO @MachineTable EXEC [TCD].[CharlistToTable] @Machine,','

 --Ecolab category
    DECLARE @EcolabCategoryTable TABLE(EcolabCategory Varchar(100))
    INSERT INTO @EcolabCategoryTable EXEC [TCD].[CharlistToTable] @EcolabCategory,','

 --Chain category
    DECLARE @ChainCategoryTable TABLE(ChainCategory Varchar(100))
    INSERT INTO @ChainCategoryTable EXEC [TCD].[CharlistToTable] @ChainCategory,','

 --Plant fomula
    DECLARE @PlantFormulaTable TABLE(PlantFormula Varchar(100))
    INSERT INTO @PlantFormulaTable EXEC [TCD].[CharlistToTable] @PlantFormula,','

 --chain formula
    DECLARE @ChainFormulaTable TABLE(ChainFormula Varchar(100))
    INSERT INTO @ChainFormulaTable EXEC [TCD].[CharlistToTable] @ChainFormula,','
 
 --customer 
    DECLARE @CustomerTable TABLE(Customer Varchar(100))
    INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','

 --Formula Segment --added by Kiran
 DECLARE @FormulaSegmentTable TABLE(FormulaSegment Varchar(1000))
    INSERT INTO @FormulaSegmentTable EXEC [TCD].[CharlistToTable] @FormulaSegement,','

 -----Formula category--------Start
 DECLARE @FormulaCategoryTable TABLE(FormulaCategory Varchar(1000),Type CHAR(1))
    INSERT INTO @FormulaCategoryTable(FormulaCategory) EXEC [TCD].[CharlistToTable] @Formulacategory,',' 
 
 --segregating Ecolab/Chain categories
 --UPDATE @FormulaCategoryTable SET TYPE=RIGHT(FormulaCategory,1),FormulaCategory=LEFT(FormulaCategory,LEN(FormulaCategory)-2)
 
 --Below 1000 Ecolab category
 UPDATE @FormulaCategoryTable SET TYPE='E' WHERE FormulaCategory<1000
 --Above 1000 consider as Chain category
 UPDATE @FormulaCategoryTable SET TYPE='C' WHERE FormulaCategory>=1000

 --Rollbacking to actual ID
 UPDATE @FormulaCategoryTable SET FormulaCategory=FormulaCategory-1000 WHERE TYPE='C'
 --SELECT * FROM @FormulaCategoryTable
 
 --SELECT * FROM @FormulaCategoryTable

 INSERT INTO @EcolabCategoryTable(EcolabCategory)
 SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='E' 

 INSERT INTO @ChainCategoryTable(ChainCategory)
 SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='C'

 --Value Assigning
 IF (EXISTS(SELECT * FROM @EcolabCategoryTable) AND @FormulaCategory!='')
 BEGIN
  SET @EcolabCategory=@FormulaCategory
 END
 IF (EXISTS(SELECT * FROM @ChainCategoryTable) AND @FormulaCategory!='')
 BEGIN
  SET @ChainCategory=@FormulaCategory
 END
 ---Formula category-------------------------End

 -----Formula Ecolab/Chain categories
 DECLARE @FormulaTable TABLE(Formula Varchar(1000),Type CHAR(1))
    INSERT INTO @FormulaTable(Formula) EXEC [TCD].[CharlistToTable] @Formula,','

 --segregating Ecolab/Chain categories
 --UPDATE @FormulaTable SET TYPE=RIGHT(Formula,1),Formula=LEFT(Formula,LEN(Formula)-2)
 /*
 --Below 1000 Ecolab category
 UPDATE @FormulaTable SET TYPE='E' WHERE Formula<1000
 --Above 1000 consider as Chain category
 UPDATE @FormulaTable SET TYPE='C' WHERE Formula>=1000

 --Rollbacking to actual ID
 UPDATE @FormulaTable SET Formula=Formula-1000 WHERE TYPE='C'
 */
 --Select * from @FormulaTable
 --Plant fomula   
    INSERT INTO @PlantFormulaTable(PlantFormula) 
 SELECT Formula FROM @FormulaTable --WHERE Type='E'
 --chain formula   
    INSERT INTO @ChainFormulaTable(ChainFormula) 
 SELECT Formula FROM @FormulaTable --WHERE Type='C'
 --SELECT * FROM @PlantFormulaTable
 --SELECT * FROM @ChainFormulaTable

 --Value Assigning
 IF (EXISTS(SELECT * FROM @PlantFormulaTable) AND @Formula!='')
 BEGIN
  SET @PlantFormula=@Formula
 END
 IF (EXISTS(SELECT * FROM @ChainFormulaTable) AND @Formula!='')
 BEGIN
  SET @ChainFormula=@Formula
 END
 --SELECT @PlantFormula,@ChainFormula
 -----Formula Segregation end

    DECLARE @actualproduction int,@uom int
    SELECT @uom =UM.UOMId FROM TCD.UserMaster AS UM WHERE UM.UserId = @UserId

    --Operation summary Table Declaration
    DECLARE @OperationSummaryTable TABLE 
  ( 
  [ShiftId] [int] NULL,[ShiftName] Varchar(100) NULL,RecordDate date,
  [MachineId] [int] NULL,[ProgramMasterId] [int] NULL,[EcolabWasherId] [int] NULL,
  ActualProduction [int] NULL,
  [NoOfLoads] [int] NULL,ActualChemicalConsumption Decimal(18,2),
  TargetChemicalConsumption Decimal(18,2),ActualEnergyConsumption  Decimal(18,2),TargetEnergyConsumption Decimal(18,2),
  ActualWaterConsumption  Decimal(18,2),TargetwaterConsumption Decimal(18,2),
  ActualChemicalCost decimal(18,2),ActualWaterCost decimal(18,2),ActualEnergyCost decimal(18,2),
  EcolabTextileId int,ChainTextileId int,ChainProgaramId int,CustomerId int,FormulaSegmentID INT 
  ,GranularityFlag INT       
        )

CREATE TABLE #ProgramMaster
 (
	[ProgramId]					[INT]	 NOT NULL,
	[Name]						[NVARCHAR](50) NULL,
	[ProgramTargetCost]		  [NCHAR](10) NULL,
	[Pieces]				  [INT] NULL,
	[DepreciationCost]		  [DECIMAL](18, 2) NULL,
	[TargetChemicalCost]	  [DECIMAL](18, 2) NULL,
	[TargetWaterCost]		  [DECIMAL](18, 2) NULL,
	[TargetEnergeyCost]		  [DECIMAL](18, 0) NULL,
	[EcolabTextileCategoryId]  [INT] NULL,
	[Rewash]				  [BIT] NULL,
	[Weight]				  [DECIMAL](18, 0) NULL,
	[EcolabSaturationId]	  [INT] NULL,
	[EcolabAccountNumber]	  [NVARCHAR](25) NULL, 
	[PlantProgramId]		  [INT] NULL,
	[ChainTextileId]		  [INT] NULL,
	[CustomerId]			  [INT] NULL,
	[FormulaSegmentId]		  [INT] NULL,
	[LastModifiedByUserId]	  [INT] NULL,
	[LastSyncTime]			  [DATETIME] NULL,
	[Weight_Display]		  [DECIMAL](18, 0) NULL,
   PRIMARY KEY CLUSTERED 
	(
	[ProgramId] ASC
	--,ChainTextileId,EcolabTextileCategoryId
	
	) 
)

CREATE TABLE #PlantChainProgram(
	[PlantProgramId] [int] NOT NULL,
	[PlantProgramName] [nvarchar](50) NULL,
	[PlantChainId] [int] NULL,
	[ChainTextileCategoryId] [int] NULL,
	[EcolabSaturationId] [int] NULL,
	[EcolabTextileCategoryId] [int] NULL,
	[FormulaSegmentId] [int] NULL,
	[LastModifiedByUserId] [int] NULL,
	[ResourceKey] [nvarchar](800) NULL,
 
 PRIMARY KEY CLUSTERED 
	(
	[PlantProgramId] ASC
	)
)

CREATE TABLE #FormulaSegments(
	[FormulaSegmentID] [int] NOT NULL,
	[SegmentName] [varchar](128) NOT NULL,
	[LastSyncTime] [datetime] NULL,
	[ResourceKey] [nvarchar](400) NULL
 PRIMARY KEY CLUSTERED 
	(
	[FormulaSegmentID] ASC
	)
)

CREATE TABLE #EcolabSaturation(
	[EcolabSaturationId] [int] NOT NULL,
	[EcolabSaturationName] [nvarchar](50) NULL,
	[AbsorbancyFactor] [numeric](5, 2) NULL,
	[SpeedAbsorbancyFactor] [numeric](5, 2) NULL,
	[LowAbsorbancyFactor] [numeric](5, 2) NULL,
	[IntermediateAborbancyFactor] [numeric](5, 2) NULL,
	[HighAbsorbancyFactor] [numeric](5, 2) NULL,
	[MyServiceMstrLnnTypId] [int] NULL,
	[MyServiceLastSynchTime] [datetime] NULL
 PRIMARY KEY CLUSTERED 
	(
	[EcolabSaturationId] ASC
	)
)
 
 INSERT INTO #ProgramMaster
 (
  [ProgramId]			
 ,[Name]				
 ,[ProgramTargetCost]		
 ,[Pieces]				
 ,[DepreciationCost]		
 ,[TargetChemicalCost]	
 ,[TargetWaterCost]		
 ,[TargetEnergeyCost]		
 ,[EcolabTextileCategoryId]
 ,[Rewash]				
 ,[Weight]				
 ,[EcolabSaturationId]	
 ,[EcolabAccountNumber]	
 ,[PlantProgramId]		
 ,[ChainTextileId]		
 ,[CustomerId]			
 ,[FormulaSegmentId]		
 ,[LastModifiedByUserId]	
 ,[LastSyncTime]			
 ,[Weight_Display]		
 )
 SELECT  [ProgramId]			
	    ,[Name]				
	    ,[ProgramTargetCost]		
	    ,[Pieces]				
	    ,[DepreciationCost]		
	    ,[TargetChemicalCost]	
	    ,[TargetWaterCost]		
	    ,[TargetEnergeyCost]		
	    ,[EcolabTextileCategoryId]
	    ,[Rewash]				
	    ,[Weight]				
	    ,[EcolabSaturationId]	
	    ,[EcolabAccountNumber]	
	    ,[PlantProgramId]		
	    ,[ChainTextileId]		
	    ,[CustomerId]			
	    ,[FormulaSegmentId]		
	    ,[LastModifiedByUserId]	
	    ,[LastSyncTime]			
	    ,[Weight_Display]		 
	    FROM  TCD.ProgramMaster
	    UNION ALL		---Adding additional record to project module reading usage
	    SELECT 
					-999 AS ProgramId
					,'UNKNOWN'	AS Name
					,NULL
					,NULL
					,NULL
					,NULL
					,NULL
					,NULL
					,-999
					,NULL
					,NULL
					,-999
					,NULL
					,-999
					,-999
					,-999
					,-999
					,NULL
					,NULL
					,NULL
;
 
INSERT INTO #PlantChainProgram
(
		[PlantProgramId]
      ,[PlantProgramName]
      ,[PlantChainId]
      ,[ChainTextileCategoryId]
      ,[EcolabSaturationId]
      ,[EcolabTextileCategoryId]
      ,[FormulaSegmentId]
      ,[LastModifiedByUserId]
 
 
)
SELECT [PlantProgramId]
      ,[PlantProgramName]
      ,[PlantChainId]
      ,[ChainTextileCategoryId]
      ,[EcolabSaturationId]
      ,[EcolabTextileCategoryId]
      ,[FormulaSegmentId]
      ,[LastModifiedByUserId]
 
 
  FROM TCD.PlantChainProgram
  UNION ALL		---Adding additional record to project module reading usage
      SELECT 
			-999
			,'UNKNOWN'	AS ChaintextileCategoryName
			,-999
			,-999
			,-999
			,-999
			,-999
			,NULL
		 
;
INSERT INTO #FormulaSegments
(
		[FormulaSegmentID]
      ,[SegmentName]
 
      )
SELECT [FormulaSegmentID]
      ,[SegmentName]
  
       FROM TCD.FormulaSegments 
       UNION ALL		---Adding additional record to project module reading usage
       SELECT 
		-999 AS FormulaSegmentId
		,'UNKNOWN'	AS SegmentName
 ;
		
INSERT INTO #EcolabSaturation
(
[EcolabSaturationId]
      ,[EcolabSaturationName]
      ,[AbsorbancyFactor]
      ,[SpeedAbsorbancyFactor]
      ,[LowAbsorbancyFactor]
      ,[IntermediateAborbancyFactor]
      ,[HighAbsorbancyFactor]
      ,[MyServiceMstrLnnTypId]
      ,[MyServiceLastSynchTime]
)
 SELECT [EcolabSaturationId]
      ,[EcolabSaturationName]
      ,[AbsorbancyFactor]
      ,[SpeedAbsorbancyFactor]
      ,[LowAbsorbancyFactor]
      ,[IntermediateAborbancyFactor]
      ,[HighAbsorbancyFactor]
      ,[MyServiceMstrLnnTypId]
      ,[MyServiceLastSynchTime]
  FROM  TCD.EcolabSaturation
  UNION ALL
   SELECT 
		-999 AS TextileId
		,'UNKNOWN'	AS CategoryName
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
;WITH BATCHSTEPWATERUSAGE   ----PLC REPORTED DATA.
	AS
	(
	SELECT  
				 MS.WasherId MachineId
				,BWER.ShiftId  AS ShiftId
				,PS.ShiftName
				,PS.[StartDateTime]
				,BWER.[ProgramMasterId]  AS [ProgramMasterId]
				,BWER.WaterCost AS WaterUsageCost--For NON-PLC reported data..---WATER 
				,NULL EnergyUsageCost
				,NULL  StandardEnergyWeight
				,BWER.StandardWaterWeight  StandardWaterWeight
				
				,NULL  ActualEnergyWeight
				,BWER.ActualWaterWeight  ActualWaterWeight
				
				,MT.MeterId

				,CASE 				
					 WHEN  ISNULL(MT.IsPlant, 0) = 0 AND MT.GROUPID IS NOT NULL AND MS.WasherId=(CASE WHEN MS.IsTunnel=1---Tunnel/CONVENTIONAL
																			 THEN MS.WasherId
																			 ELSE MT.MachineCompartment END)  
						  THEN  3 ---Washer Level Meter.
					 WHEN MT.GROUPID IS NOT NULL AND ISNULL(MT.IsPlant, 0) = 0 AND(CASE WHEN MS.IsTunnel=1
																			 THEN NULL
																			 ELSE 
																			 MT.MachineCompartment END) IS NULL
						  THEN 2	--WG Level Meter
					 WHEN MT.IsPlant=1 --AND MT.GROUPID IS NULL
						  THEN 1 --Plant Level Meter
						  ELSE -1
				  END As GranularityFlag
				,BWER.[EcolabTextileId] EcolabTextileCategoryId
				,BWER.ChainTextilecategoryId
				,BWER.FormulasegmentId
				--INTO #BATCHSTEPINFO
			FROM TCD.BatchWaterandEnergyRollUp  BWER WITH (NOLOCK)
			    INNER JOIN TCD.ProductionShiftData PS WITH (NOLOCK) ON BWER.ShiftId = PS.ShiftId 
				INNER JOIN TCD.MachineSetup MS WITH (NOLOCK) ON MS.GroupId=BWER.GroupId AND BWER.MachineId=MS.WasherId
				INNER JOIN TCD.Meter MT WITH (NOLOCK) ON MT.EcolabAccountNumber=ms.EcoalabAccountNumber
										AND MS.WasherId=CASE WHEN MS.IsTunnel=1---CONVENTIONAL
															   THEN MS.WasherId
																	ELSE MT.MachineCompartment  
															   End
				INNER JOIN TCD.UtilityMaster UM WITH (NOLOCK) ON UM.ResourceId=MT.UtilityType
				 
			 WHERE MT.CounterNum>0 ----PLC REPORTED DATA
					   AND UM.ResourceId =2  --Water
					   AND MT.IncludeInOperationReport=1 AND ISNULL(MS.Ispony,0)=0
					   AND 
						 CASE @StartDate                                                                                
						 WHEN '' THEN 
						  CASE WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
						 ELSE 
						  CASE WHEN PS.[StartDateTime]  >= @startdate AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
						 END='TRUE' 
		),
BATCHSTEPENERGYUSAGE
	   AS
	   (
	   SELECT								
				--  MS.GroupId GroupId
				 MS.WasherId
				,MR.ShiftId  AS ShiftId
				,PS.ShiftName
				,PS.[StartDateTime]
				,-999 ProgramMasterId

				,CASE WHEN MS.IsTunnel=1---CONVENTIONAL
								THEN MS.WasherId
								ELSE MT.MachineCompartment  End MachineId
				,NULL  WaterUsageCost
				,CASE WHEN UM.ResourceId IN (1,4,3) --GAS, OIL, ENERGY/ELECTRIC
						   THEN MR.UsageCost
					 ELSE 0
					END EnergyUsageCost
		 
				,0 StandardEnergyWeight
				,0 StandardWaterWeight
				,NULL ActualWaterWeight
				 ,CASE 
					WHEN UM.ResourceId IN (1,4,3) --  Gas,Oil,Electric
						THEN	MR.Usage
				 END ActualEnergyWeight
				
				,MT.MeterId
				,CASE 				
					   WHEN  ISNULL(MT.IsPlant, 0) = 0 AND MT.GROUPID IS NOT NULL 
													   AND (CASE WHEN MS.IsTunnel=1---CONVENTIONAL
																	 THEN MS.WasherId
																	 ELSE MT.MachineCompartment 
															END) IS NOT NULL  
						  THEN  3 ---Washer Level Meter.
					   WHEN MT.GROUPID IS NOT NULL AND ISNULL(MT.IsPlant, 0) = 0  
												   AND(CASE WHEN MS.IsTunnel=1
																 THEN NULL
																 ELSE 
																 MT.MachineCompartment 
													   END) IS NULL
						  THEN 2	--WG Level Meter
					   WHEN MT.IsPlant=1 --AND MT.GROUPID IS NULL
						  THEN 1 --Plant Level Meter
					   ELSE -1
				 END As GranularityFlag
			--INTO #MODULEREADING
		  FROM   TCD.MachineSetup AS ms(NOLOCK)  
				INNER JOIN  TCD.METER MT ON MT.EcolabAccountNumber=MS.EcoalabAccountNumber 
							AND MS.WasherId=CASE WHEN MS.IsTunnel=1---CONVENTIONAL
											 THEN MS.WasherId
											 ELSE MT.MachineCompartment  End
				INNER JOIN TCD.UtilityMaster UM ON UM.ResourceId=MT.UtilityType
				INNER JOIN TCD.ModuleReadingROLLUP MR  ON MT.METERID=MR.MODULEID
				INNER JOIN TCD.ProductionShiftData PS ON MR.ShiftId = PS.ShiftId 
		  WHERE MT.CounterNum>0 ---NON PLC/ MODULE READING REPORT DATA
				    AND MR.ModuleTypeId=2   --Meter
				    AND UM.ResourceId IN (1,4,3) --Gas,Oil,Electric
				    AND MT.IncludeInOperationReport=1 AND ISNULL(MS.Ispony,0)=0
				    AND 
						 CASE @StartDate                                                                                
						 WHEN '' THEN 
						  CASE WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
						 ELSE 
						  CASE WHEN PS.[StartDateTime]  >= @startdate AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
						 END='TRUE' 

),
 MODULEREADING		---NON PLC DATA.
	   AS(
	    SELECT								
				--  MS.GroupId GroupId
				 MS.WasherId
				,MR.ShiftId  AS ShiftId
				,PS.ShiftName
				,PS.[StartDateTime]
				,-999 ProgramMasterId

				,CASE WHEN MS.IsTunnel=1---CONVENTIONAL
								THEN MS.WasherId
								ELSE MT.MachineCompartment  End MachineId
				,CASE 
						  WHEN  UM.ResourceId =2 --For NON-PLC reported data..---WATER 
						  	THEN MR.UsageCost
						ELSE 0
					END  WaterUsageCost
				,CASE WHEN UM.ResourceId IN (1,4,3) --GAS OR OIL
						   THEN MR.UsageCost
					 ELSE 0
					END EnergyUsageCost
		 
				,0 StandardEnergyWeight
				,0 StandardWaterWeight
				,CASE 
						WHEN UM.ResourceId=2 --  WATER
							THEN	MR.Usage
					 END  ActualWaterWeight
				 ,CASE 
					WHEN UM.ResourceId IN (1,4,3) --  Gas,Oil,Electric
						THEN	MR.Usage
				 END ActualEnergyWeight
				
				,MT.MeterId
				,CASE 				
					   WHEN  ISNULL(MT.IsPlant, 0) = 0 AND MT.GROUPID IS NOT NULL 
													   AND (CASE WHEN MS.IsTunnel=1---CONVENTIONAL
																	 THEN MS.WasherId
																	 ELSE MT.MachineCompartment 
															END) IS NOT NULL  
						  THEN  3 ---Washer Level Meter.
					   WHEN MT.GROUPID IS NOT NULL AND ISNULL(MT.IsPlant, 0) = 0  
												   AND(CASE WHEN MS.IsTunnel=1
																 THEN NULL
																 ELSE 
																 MT.MachineCompartment 
													   END) IS NULL
						  THEN 2	--WG Level Meter
					   WHEN MT.IsPlant=1 --AND MT.GROUPID IS NULL
						  THEN 1 --Plant Level Meter
					   ELSE -1
				 END As GranularityFlag
			--INTO #MODULEREADING
		  FROM   TCD.MachineSetup AS ms(NOLOCK)  
				INNER JOIN  TCD.METER MT ON MT.EcolabAccountNumber=MS.EcoalabAccountNumber 
							AND MS.WasherId=CASE WHEN MS.IsTunnel=1---CONVENTIONAL
											 THEN MS.WasherId
											 ELSE MT.MachineCompartment  End
				INNER JOIN TCD.UtilityMaster UM ON UM.ResourceId=MT.UtilityType
				INNER JOIN TCD.ModuleReadingROLLUP MR  ON MT.METERID=MR.MODULEID
				INNER JOIN TCD.ProductionShiftData PS ON MR.ShiftId = PS.ShiftId 
		  WHERE MT.DigitalInputNumber>0 ---NON PLC/ MODULE READING REPORT DATA
				    AND MR.ModuleTypeId=2   --Meter
				    AND UM.ResourceId IN (1,2,3,4) --Water,Gas,Oil,Electric
				    AND MT.IncludeInOperationReport=1 AND ISNULL(MS.Ispony,0)=0
				    AND 
						 CASE @StartDate                                                                                
						 WHEN '' THEN 
						  CASE WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
						 ELSE 
						  CASE WHEN PS.[StartDateTime]  >= @startdate AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
						 END='TRUE' 
	   ),
 --calculation if MT.IsPlant = 1
 ManualUtilityPlantMeters
	   AS
	   (
	   SELECT	 WasherId	AS MachineId
			,BD.ShiftID
			,BD.ShiftName
			,-999 ProgramMasterId
			,BD.[StartDate]
			
			,CAST(BD.ActualWeight AS FLOAT)
				/ SUM(BD.ActualWeight) OVER(PARTITION BY MU.DateFrom, MU.DateTo)
					* MU.ManualUtilityWaterUsage AS ManualUtilityWaterUsage

			,0 AS StandardWaterUsage

			,CAST(BD.ActualWeight AS FLOAT)
				/ SUM(BD.ActualWeight) OVER(PARTITION BY MU.DateFrom, MU.DateTo)
					* MU.ManualUtilityWaterCost AS ManualUtilityWaterCost

			,CAST(BD.ActualWeight AS FLOAT)
				/ SUM(BD.ActualWeight) OVER(PARTITION BY MU.DateFrom, MU.DateTo)
					* MU.ManualUtilityEnergyUsage AS ManualUtilityEnergyUsage

			,0 AS StandardEnergyUsage

			,CAST(BD.ActualWeight AS FLOAT)
				/ SUM(BD.ActualWeight) OVER(PARTITION BY MU.DateFrom, MU.DateTo)
					* MU.ManualUtilityEnergyCost AS ManualUtilityEnergyCost
			,GranularityFlag
			--INTO #ManualUtilityPlantMeters
	FROM
	(
		SELECT	ISNULL(dt.RecordedDate, DATEADD(DAY, -60, MU.RecordedDate))	AS DateFrom -- 19000101 or 60 days?
				,MU.RecordedDate											AS DateTo
				,MS.WasherId WasherId
				,(CASE 
					WHEN MU.UtilityId = 2 THEN MU.Usage -- Water
				END) AS ManualUtilityWaterUsage

				,(CASE 
					WHEN MU.UtilityId = 2 THEN MU.UsageCost  -- Water
				END) AS ManualUtilityWaterCost

				,(CASE 
					WHEN MU.UtilityId IN (1,3, 4) THEN MU.Usage -- GAS OR OIL or ELECTRIC
				 
				END) AS ManualUtilityEnergyUsage

				,(CASE 
					WHEN MU.UtilityId IN (1, 4,3) THEN MU.UsageCost  
					ELSE 0
				END) AS ManualUtilityEnergyCost

				,1 GranularityFlag --Plant Level Meter

		FROM	TCD.ManualUtility AS MU
				INNER JOIN TCD.Meter AS MT 
					ON	MT.MeterId = MU.MeterId
						AND MT.EcolabAccountNumber = MU.EcolabAccountNumber
				INNER JOIN TCD.MachineSetup AS ms(NOLOCK)  ON MS.EcoalabAccountNumber=MT.EcolabAccountNumber 
						AND MS.WasherId=CASE WHEN MS.IsTunnel=1
										  THEN MS.WasherId
										  ELSE MT.MachineCompartment END
				OUTER APPLY (
					SELECT	TOP 1
							DATEADD(DAY, 1, MUD.RecordedDate) AS RecordedDate --Add a day to recdate
					FROM	TCD.ManualUtility AS MUD
					WHERE	MUD.MeterId = MU.MeterId AND MUD.EcolabAccountNumber=MU.EcolabAccountNumber
							AND MUD.RecordedDate < MU.RecordedDate
							
					ORDER BY
							MUD.RecordedDate DESC
				) AS dt

		WHERE	MT.IsPlant = 1 
				--AND MT.CounterNum=0 AND MT.DigitalInputNumber=0 
				---If meter config. with allow manual i/p then these two fields added with "0"
				  AND MU.UtilityId IN (1,2,3,4) --Water,Gas,Oil,Electric
				  AND MT.IncludeInOperationReport=1
				  AND ISNULL(MS.Ispony,0)=0
				  AND MT.AllowManualentry=1
	) AS MU

	INNER JOIN ( 
		SELECT	BD.ShiftID
				,PS.ShiftName
				,BD.MachineId
				,CAST(BD.StartDate AS DATE) AS [StartDate]
				,SUM(BD.ActualWeight) AS ActualWeight
		FROM	TCD.BatchData AS BD
		INNER JOIN TCD.ProductionShiftData PS ON BD.ShiftId=PS.ShiftId
		WHERE CASE @StartDate                                                                                
						 WHEN '' THEN 
						  CASE WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
						 ELSE 
						  CASE WHEN PS.[StartDateTime]  >= @startdate AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
						 END='TRUE' 
		GROUP BY
				BD.ShiftID,PS.ShiftName
				,BD.MachineId
				,CAST(BD.StartDate AS DATE)
	) AS BD ON BD.[StartDate] BETWEEN MU.DateFrom AND MU.DateTo

) ,
 --calculation if MT.IsPlant = 0
 ManualUtilityMeters
AS
(
	SELECT	DB.MachineId
			,DB.ShiftId
			,DB.ShiftName
			,-999 ProgramMasterId
			,DB.[StartDate]

			,CAST(DB.ActualWeight AS FLOAT)
				/ SUM(DB.ActualWeight) OVER(PARTITION BY CAST(DB.StartDate AS DATE), DB.MachineID)
					* MU.WaterUsage AS ManualUtilityWaterUsage

			,0 AS StandardWaterUsage

			,CAST(DB.ActualWeight AS FLOAT)
				/ SUM(DB.ActualWeight) OVER(PARTITION BY CAST(DB.StartDate AS DATE), DB.MachineID)
					* MU.WaterCost AS ManualUtilityWaterCost

			,CAST(DB.ActualWeight AS FLOAT)
				/ SUM(DB.ActualWeight) OVER(PARTITION BY CAST(DB.StartDate AS DATE), DB.MachineID)
					* MU.EnergyUsage AS ManualUtilityEnergyUsage

			,0 AS StandardEnergyUsage

			,CAST(DB.ActualWeight AS FLOAT)
				/ SUM(DB.ActualWeight) OVER(PARTITION BY CAST(DB.StartDate AS DATE), DB.MachineID)
					* MU.EnergyCost AS ManualUtilityEnergyCost
			,GranularityFlag
			--INTO #ManualUtilityMeters										
	FROM
	(
		SELECT	
				-- MT.EcolabAccountNumber
				--,MT.GroupId

				 (CASE WHEN MS.IsTunnel=1
						  THEN MS.WasherId
						  ELSE MT.MachineCompartment
				END) AS MachineID

				,(CASE 
					WHEN MU.UtilityId = 2 THEN MU.Usage -- Water
				END) AS WaterUsage

				,(CASE 
					WHEN MU.UtilityId = 2 THEN MU.UsageCost -- Water
					
				END) AS WaterCost

				,(CASE 
					WHEN MU.UtilityId IN (1,3,4) THEN MU.Usage -- GAS OR OIL or ELECTRIC
				END) AS EnergyUsage

				,(CASE 
					WHEN MU.UtilityId IN (1, 4,3) THEN MU.UsageCost -- GAS OR OIL,Electric
					ELSE 0 
				END) AS EnergyCost

				,ISNULL(dt.RecordedDate, DATEADD(DAY, -60, MU.RecordedDate))	AS DateFrom -- 19000101 or 60 days?
				--If prev rec. not found in manual utility pref. to consider last 60 days. 
				,MU.RecordedDate												AS DateTo

				,CASE 				---Identify Meter granularity.
					   WHEN  ISNULL(MT.IsPlant, 0) = 0 AND MT.GROUPID IS NOT NULL AND (CASE WHEN MS.IsTunnel=1 
																			 THEN MS.WasherId
																			 ELSE MT.MachineCompartment END) IS NOT NULL  
						  THEN  3 ---Washer Level Meter.
					   WHEN  ISNULL(MT.IsPlant, 0) = 0 AND MT.GROUPID IS NOT NULL AND(CASE WHEN MS.IsTunnel=1
																			 THEN NULL
																			 ELSE 
																			 MT.MachineCompartment END) IS NULL
						  THEN 2	--WG Level Meter
					   WHEN MT.IsPlant=1 AND MT.GROUPID IS NULL
						  THEN 1 --Plant Level Meter
					   ELSE -1
				 END As GranularityFlag

		FROM	TCD.ManualUtility AS MU
				INNER JOIN TCD.Meter AS MT 
					ON	MT.MeterId = MU.MeterId
						AND MT.EcolabAccountNumber = MU.EcolabAccountNumber
				INNER JOIN TCD.MachineSetup MS ON MS.EcoalabAccountNumber=MT.EcolabAccountNumber
											 AND MS.WasherId=CASE WHEN MS.IsTunnel=1
															 THEN MS.WasherId
															 ELSE MT.MachineCompartment END
				OUTER APPLY (
					SELECT	TOP 1
							DATEADD(DAY, 1, MUD.RecordedDate) AS RecordedDate
							--Last Entry Next Day, is start day to distribute
					FROM	TCD.ManualUtility AS MUD
					WHERE	MUD.MeterId = MU.MeterId AND MUD.EcolabAccountNumber=MU.EcolabAccountNumber
							AND MUD.RecordedDate < MU.RecordedDate
					ORDER BY
							MUD.RecordedDate DESC
				) AS dt
		WHERE	ISNULL(MT.IsPlant, 0) = 0
					--AND MT.CounterNum=0 AND MT.DigitalInputNumber=0 
					---If meter config. with allow manual i/p then these two fields added with "0"
					AND MU.UtilityId IN (1,2,3,4) --Water,Gas,Oil,Electric
					AND MT.IncludeInOperationReport=1
					AND ISNULL(MS.ISPONY,0)=0
					AND MT.AllowManualentry=1
	) AS MU
	INNER JOIN ( 
		SELECT	BD.ShiftID
				,PS.ShiftName
				,BD.MachineId AS MachineId
				,CAST(BD.StartDate AS DATE) AS [StartDate]
				,SUM(BD.ActualWeight) AS ActualWeight
		FROM	TCD.BatchData AS BD
		INNER JOIN TCD.ProductionShiftData PS ON BD.ShiftId=PS.ShiftId
		WHERE CASE @StartDate                                                                                
						 WHEN '' THEN 
						  CASE WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
						 ELSE 
						  CASE WHEN PS.[StartDateTime]  >= @startdate AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
						 END='TRUE' 
		GROUP BY
				BD.ShiftID,PS.ShiftName
				,BD.MachineId
				,CAST(BD.StartDate AS DATE)
	) AS DB ON DB.[StartDate] BETWEEN MU.DateFrom AND MU.DateTo
) ,
 --PLC,NONPLC and MIP 
ShiftWaterAndEnergyDataRollUp 
	   AS
	   (
	   SELECT 
			 BSI.MachineId
			,BSI.ShiftId
			,BSI.ShiftName
			,BSI.StartDateTime
			,BSI.[ProgramMasterId]

			,BSI.StandardEnergyWeight 
			,BSI.StandardWaterWeight 
			 
			,BSI.ActualWaterWeight 
			,BSI.WaterUsageCost 

			,BSI.ActualEnergyWeight
			,BSI.EnergyUsageCost 
			
			,BSI.GranularityFlag
			,BSI.EcolabTextileCategoryId
			,BSI.ChainTextilecategoryId
			,BSI.FormulasegmentId

	   FROM BATCHSTEPWATERUSAGE BSI 

	UNION ALL	
	    SELECT 
			 MachineId
			,ShiftId
			,ShiftName
			,StartDateTime
			,[ProgramMasterId]

			,StandardEnergyWeight 
			,StandardWaterWeight 
			 
			,ActualWaterWeight 
			,WaterUsageCost 

			,ActualEnergyWeight
			,EnergyUsageCost 
			
			,GranularityFlag
			,-999 EcolabTextileCategoryId
			,-999 ChainTextilecategoryId
			,-999 FormulasegmentId

	FROM BATCHSTEPENERGYUSAGE 
					 
	UNION ALL				
				
	SELECT 
			 MachineId
			,ShiftId
			,ShiftName
			,StartDateTime
			,[ProgramMasterId]

			,StandardEnergyWeight 
			,StandardWaterWeight 
			 
			,ActualWaterWeight 
			,WaterUsageCost 

			,ActualEnergyWeight
			,EnergyUsageCost 
			
			,GranularityFlag
			,-999 EcolabTextileCategoryId
			,-999 ChainTextilecategoryId
			,-999 FormulasegmentId

	FROM MODULEREADING 
 
	UNION ALL
		SELECT	 
			 MUPM.MachineId
			,MUPM.ShiftId
			,ShiftName
			,StartDate
			,[ProgramMasterId]

			,MUPM.StandardEnergyUsage
			,MUPM.StandardWaterUsage
			
			,MUPM.ManualUtilityWaterUsage
			,MUPM.ManualUtilityWaterCost
			
			,MUPM.ManualUtilityEnergyUsage
			,MUPM.ManualUtilityEnergyCost
			
			,GranularityFlag 
			,-999 EcolabTextileCategoryId
			,-999 ChainTextilecategoryId
			,-999 FormulasegmentId
			
	FROM	ManualUtilityPlantMeters AS MUPM

	UNION ALL

	SELECT	 
			 MUM.MachineId
			,MUM.ShiftId
			,ShiftName
			,StartDate
			,[ProgramMasterId]

			,MUM.StandardEnergyUsage 
			,MUM.StandardWaterUsage 
			
			,MUM.ManualUtilityWaterUsage 
			,MUM.ManualUtilityWaterCost 
			
			,MUM.ManualUtilityEnergyUsage 
			,MUM.ManualUtilityEnergyCost 

			,GranularityFlag
			,-999 EcolabTextileCategoryId
			,-999 ChainTextilecategoryId
			,-999 FormulasegmentId
			
	FROM	ManualUtilityMeters AS MUM
	 
) 

 --Operation summary Table Insertion
    INSERT INTO @OperationSummaryTable
  (
  [ShiftId] ,[ShiftName] ,RecordDate ,
  [MachineId] ,[ProgramMasterId],[EcolabWasherId],
  ActualProduction,
  [NoOfLoads],ActualChemicalConsumption,
  TargetChemicalConsumption,ActualEnergyConsumption ,TargetEnergyConsumption ,
  ActualWaterConsumption  ,TargetwaterConsumption ,
  ActualChemicalCost ,ActualWaterCost ,ActualEnergyCost ,
  EcolabTextileId ,ChainTextileId ,ChainProgaramId ,FormulaSegmentID,CustomerId
  ,GranularityFlag
  )
  SELECT  
					PS.ShiftId
                  ,PS.ShiftName
                  ,CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS DATE) AS RecordDate
                  ,SPD.MachineId
                  ,PM.ProgramId
                  ,SPD.EcolabWasherId
                  ,SPD.ActualProduction
                  ,SPD.NoOfLoads
                  
                  ,ISNULL(SCD.ActualConsumption,0)  AS ActualChemicalConsumption
                  ,ISNULL(SCD.TargetConsumption,0)  AS TargetChemicalConsumption
                  ,NULL AS ActualEnergyConsumption
                  ,NULL AS TargetEnergyConsumption
                  ,NULL AS ActualWaterConsumption
                  ,NULL AS TargetwaterConsumption
                  
                  ,ISNULL(SCD.ActualCost,0) AS ActualChemicalCost
                  ,NULL  AS ActualWaterCost
                  ,NULL  AS ActualEnergyCost
                  
                  ,CASE 
                        WHEN  PM.PlantProgramId  IS NOT NULL AND ChainPlant.EcolabTextileCategoryId IS NOT NULL   
                              THEN ChainPlant.EcolabTextileCategoryId  
                              ELSE ETC1.TextileId   
                  END AS EcolabTextileCategory
                  
                  ,CASE 
                        WHEN PM.PlantProgramId  IS NOT NULL 
                              THEN ChainPlant.ChainTextileCategoryId  
                              ELSE NULL 
                  END AS ChainTextilecategory
                  
                  ,PM.PlantProgramId 
                  
                  ,CASE 
                        WHEN  PM.PlantProgramId  IS NOT NULL 
                              THEN ChainPlant.FormulaSegmentId  
                              ELSE FS1.FormulaSegmentID 
                  END AS Formulasegment
                  
                  ,SPD.CustomerId 
				  ,NULL GranularityFlag         
  FROM  TCD.ShiftProductionDataRollup SPD 
	  INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId 
	  INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId 
	  --Added by Kiran
	  LEFT OUTER JOIN
	   (
	   --IF Chain Plant
	   SELECT PCP.PlantProgramId,PCP.PlantChainId,PCP.ChainTextileCategoryId,PCP.EcolabTextileCategoryId,
	   PCP.FormulaSegmentId,PCP.EcolabSaturationId
	   FROM TCD.PlantChainProgram PCP 
	   LEFT OUTER JOIN TCD.ChainTextileCategory CTC ON CTC.TextileId=NULLIF(PCP.ChainTextileCategoryId,0)
	   LEFT OUTER JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId=NULLIF(PCP.EcolabTextileCategoryId,0)
	   LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=PCP.FormulaSegmentId
	   LEFT OUTER JOIN TCD.EcolabSaturation ES ON ES.EcolabSaturationId=PCP.EcolabSaturationId
	   )ChainPlant ON PM.PlantProgramId=ChainPlant.PlantProgramId

	  LEFT OUTER JOIN TCD.EcolabTextileCategory ETC1 ON ETC1.TextileId=PM.EcolabTextileCategoryId
	  LEFT OUTER JOIN TCD.FormulaSegments FS1 ON FS1.FormulaSegmentID=PM.FormulaSegmentId
	  LEFT OUTER JOIN TCD.EcolabSaturation ES1 ON ES1.EcolabSaturationId=PM.EcolabSaturationId

						     OUTER APPLY (
                                    SELECT      SUM(SCD.ActualCost)                 AS ActualCost
                                                ,SUM(SCD.ActualConsumption)   AS ActualConsumption
                                                ,SUM(SCD.TargetConsumption)   AS TargetConsumption
                                    FROM  TCD.ShiftChemicalDataRollup SCD
                                    WHERE SPD.ShiftId = SCD.ShiftId 
                                                AND SPD.MachineId = SCD.MachineId 
                                                AND SPD.ProgramMasterId = SCD.ProgramMasterId
                              ) AS SCD

 WHERE SPD.MachineId NOT IN (SELECT ms.WasherId FROM TCD.MachineSetup AS ms WHERE ms.IsPony = 1)
  AND 
   CASE @StartDate                                                                                
   WHEN '' THEN 
    CASE WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
   ELSE 
    CASE WHEN PS.[StartDateTime]  >= @startdate AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                        
   END='TRUE'  
  AND
   CASE @MachineType   
   WHEN '' THEN 'TRUE'         
   ELSE                                                      
   CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
   MS.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable))) THEN 'TRUE' END                                                      
   END='TRUE' 
  AND
   CASE @machineGroup   
   WHEN '' THEN 'TRUE'         
   ELSE                                                      
   CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
   MS.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable)) THEN 'TRUE' END                                                      
   END='TRUE' 
  AND
   CASE @Machine   
   WHEN '' THEN 'TRUE'         
   ELSE                                                      
   CASE WHEN SPD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
   END='TRUE'   
  AND 
  
   CASE @Customer   
   WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SPD.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                      
   END='TRUE' 

 
  AND 
   CASE @EcolabCategory   
   WHEN '' THEN 'TRUE' 
   ELSE
    CASE WHEN PM.PlantProgramId IS NOT NULL THEN
      CASE WHEN ChainPlant.EcolabTextileCategoryId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                                                   
    ELSE 
    CASE WHEN ETC1.TextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable)  THEN 'TRUE'END 
   END  
   END='TRUE'                            
  AND 
   CASE @ChainCategory    
   WHEN '' THEN 'TRUE' 
    ELSE 
     CASE WHEN PM.PlantProgramId IS NOT NULL THEN
      CASE WHEN ChainPlant.ChainTextileCategoryId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END 
     ELSE 'TRUE' END                                                                                                                                     
   END='TRUE'
  AND    
   CASE @PlantFormula   
   WHEN '' THEN 'TRUE'         
   ELSE                                                      
   CASE WHEN SPD.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                      
   END='TRUE'
        AND    
   CASE @ChainFormula   
   WHEN '' THEN 'TRUE'         
   ELSE                                                      
    CASE WHEN PM.PlantProgramId IS NOT NULL THEN
      CASE WHEN ChainPlant.ChainTextileCategoryId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END 
    ELSE 'TRUE' END                                                        
   END='TRUE'
        AND 
   CASE @FormulaSegement                                                                                
   WHEN '' THEN  'TRUE'
   ELSE
    CASE WHEN PM.PlantProgramId IS NOT NULL THEN
     CASE WHEN ChainPlant.FormulaSegmentId IN (SELECT FormulaSegment FROM @FormulaSegmentTable) THEN 'TRUE' END                                                                                     
    ELSE 
     CASE WHEN FS1.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)  THEN 'TRUE'END   
    END                                                     
   END='TRUE'
 
 UNION ALL
                SELECT   
					 AD.ShiftId
					,AD.SHIFTNAME 
					,CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),AD.[StartDateTime]) AS DATE) AS RecordDate
					,AD.MachineId
					,AD.ProgramMasterId
					,AD.MACHINEID
					,NULL
					,COUNT(1) NoOfLoads
					,NULL  AS ActualChemicalConsumption
					,NULL AS TargetChemicalConsumption
					,SUM(AD.ActualEnergyWeight)	AS ActualEnergyUsage
					,SUM(AD.StandardEnergyWeight) AS StandardEnergyUsage
					,SUM(AD.ActualWaterWeight)	AS ActualWaterUsage
					,SUM(AD.StandardWaterWeight)	AS StandardWaterUsage
					,NULL  AS ActualChemicalCost
					,SUM(AD.WaterUsageCost)		AS WaterUsageCost 
					,SUM(AD.EnergyUsageCost)		AS EnergyUsageCost
					,AD.EcolabTextileCategoryId
					,AD.ChainTextilecategoryId
					,AD.ProgramMasterId AS ProgramId
					,AD.FormulasegmentId
					,-999 CUSTOMERID
					,GranularityFlag
                                    FROM  ShiftWaterAndEnergyDataRollUp AD 
											GROUP BY  AD.ProgramMasterId,AD.ShiftId,AD.SHIFTNAME,AD.STARTDATETIME
														,AD.MachineId,AD.GranularityFlag,AD.EcolabTextileCategoryId
															,AD.ChainTextilecategoryId,AD.FormulasegmentId  
										
    --SELECT * FROM @OperationSummaryTable --WHERE granularityflag=1;
    
    SELECT @NoOfLoads =  SUM(NoOfLoads) 
  FROM ( SELECT SUM(OST.NoOfLoads) AS NoOfLoads FROM @OperationSummaryTable AS OST GROUP BY OST.ShiftId )  NoOfLoads
 
    IF(@Viewtype = 3) ---Ecolab Categories

    BEGIN
  ---EcoLabCategory
  IF(@Subview = 12)
  BEGIN
    INSERT INTO @resultSet
    (
    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id 
    )
    SELECT DISTINCT
    0
    ,EC.CategoryName
    ,SUM(SPD.ActualProduction)
    ,sum(NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,EC.TextileId
   FROM @OperationSummaryTable SPD LEFT JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
   GROUP BY EC.CategoryName,EC.TextileId
           END
  ---EcoLabFormula
  IF(@Subview = 17)
  BEGIN
   INSERT INTO @resultSet
    (
    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id 
    )
    SELECT 
      DISTINCT
    0, 
    PM.Name
    ,SUM(SPD.ActualProduction)
    ,sum( NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,0
    FROM @OperationSummaryTable SPD INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
      INNER JOIN #ProgramMaster PM ON EC.TextileId = PM.EcolabTextileCategoryId AND SPD.ProgramMasterId = PM.ProgramId
    
   WHERE
    (
    CASE    
     WHEN @drillvalue='' THEN 'TRUE' 
     WHEN @drillvalue IS NULL THEN 'TRUE'  
     ELSE                                                    
      CASE WHEN EC.TextileId IN (@drillvalue) THEN 'TRUE' END            
     END='TRUE'
    )
   GROUP BY  PM.Name
   
  END
 END

 -- ************************ By Textile Category View ************************************************
 IF(@Viewtype = 4)
 BEGIN 
  --TextileCategory
  IF(@Subview = 15)
  BEGIN
    INSERT INTO @resultSet
    (
    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id 
    )
    SELECT DISTINCT
    0,
    CC.Name
    ,SUM(SPD.ActualProduction)
    ,sum( NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,CC.TextileId
    FROM @OperationSummaryTable SPD LEFT JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
    GROUP BY CC.Name,CC.TextileId
  
  END  
  --TextileFormula
  IF(@Subview = 18)
  BEGIN
    INSERT INTO @resultSet
    (
    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id 
    )
    SELECT DISTINCT       
    0, 
    PM.Name
    ,SUM(SPD.ActualProduction)
    ,sum( NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,0
    FROM @OperationSummaryTable SPD INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
      INNER JOIN #ProgramMaster PM ON CC.TextileId = PM.ChainTextileId AND SPD.ProgramMasterId = PM.ProgramId
    
   WHERE
    (
    CASE    
     WHEN @drillvalue='' THEN 'TRUE' 
     WHEN @drillvalue IS NULL THEN 'TRUE'  
     ELSE                                                    
      CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END            
     END='TRUE'
    )
   GROUP BY PM.Name
    
  END
 END

 -- ******************************** Timeline View ***************************************************
 IF(@Viewtype = 1)
 BEGIN
  ---- By TimeLine - Day View
  IF(@Subview = 5)
  BEGIN 

  WITH CTE_DayView (ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id) --, SortOrder)
  AS 
  (
    SELECT 
    SPD.ShiftId,
    SPD.ShiftName
     ,SUM(SPD.ActualProduction)
    ,sum( NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,0
    --,ROW_NUMBER() OVER (ORDER BY SPD.ShiftId ASC)  AS SortOrder
     FROM @OperationSummaryTable SPD
	   WHERE ISNULL(SPD.GranularityFlag,0)=CASE WHEN SPD.GranularityFlag IS NULL THEN 0 ELSE 3 END
    GROUP BY SPD.ShiftId,SPD.ShiftName
 
    )

   INSERT INTO @resultSet
    (
    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id , SortOrder
    )
    SELECT     ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id 
    ,ROW_NUMBER() OVER (ORDER BY ShiftId ASC)  AS SortOrder
    from CTE_DayView


  END  
  ---- By TimeLine - Week View
  IF (@Subview = 4)
  BEGIN
   INSERT INTO @resultSet
    (
    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id, SortOrder
    )
   SELECT DISTINCT
   0,
   --CAST(RecordDate AS nvarchar(100))
    CONVERT(VARCHAR(11),CONVERT(DATE,RecordDate),113)+' ('+LEFT(datename(dw,RecordDate),3)+')'
   ,SUM(SPD.ActualProduction)
   ,sum( NoOfLoads)
   ,SUM(ActualChemicalConsumption)
   ,SUM(TargetChemicalConsumption) 
   ,SUM(ActualEnergyConsumption)
   ,SUM(TargetEnergyConsumption)
   ,SUM(ActualWaterConsumption)
   ,SUM(TargetWaterConsumption)
   ,SUM(ActualChemicalCost)
   ,SUM(ActualWaterCost)
   ,SUM(ActualEnergyCost)
   ,@Viewtype 
   ,@Subview
   ,0
   ,ROW_NUMBER() OVER (ORDER BY CONVERT(DATE,RecordDate) ASC)  AS SortOrder
    FROM @OperationSummaryTable SPD
	   WHERE ISNULL(SPD.GranularityFlag,0)=CASE WHEN SPD.GranularityFlag IS NULL THEN 0 ELSE 3 END
	   GROUP BY DATEPART(weekday,RecordDate),RecordDate
    
  END
  
  ---- By TimeLine - Month View
  IF(@Subview = 3)
   BEGIN

   WITH CTE(DateRange 
   ,TotalLoad,Numberofbatches,ActualChemicalConsumption,TargetChemicalConsumption,
   ActualEnergyConsumption,TargetEnergyConsumption,ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,ActualEnergyCost , SortOrder)
   AS
   (
   SELECT    
   CASE WHEN DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate) >@InputStartDate 
	    THEN CAST(CONVERT(VARCHAR, DATEADD(dd, -(DATEPART(dw,RecordDate) - 1), RecordDate), 101) AS NVARCHAR(100))
	ELSE CAST(CONVERT(VARCHAR, @InputStartDate, 101) AS NVARCHAR(100)) 
    END 
    +  '-' + 
    CASE WHEN DATEADD(dd, (7 - DatePart(dw, RecordDate)),RecordDate) < @InputEndDate 
	    THEN CAST(CONVERT(VARCHAR, DateAdd(dd, (7 - DatePart(dw, RecordDate)),RecordDate), 101) AS nvarchar(100))
	ELSE CAST(Convert(VARCHAR, @InputEndDate, 101) AS nvarchar(100))
    END AS DateRange    
    ,SPD.ActualProduction
    ,SPD.NoOfLoads
    ,ActualChemicalConsumption
    ,TargetChemicalConsumption 
    ,ActualEnergyConsumption
    ,TargetEnergyConsumption
    ,ActualWaterConsumption
    ,TargetWaterConsumption
    ,ActualChemicalCost
    ,ActualWaterCost
    ,ActualEnergyCost
    , DENSE_RANK() OVER (ORDER BY DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate) )AS SortOrder
     FROM @OperationSummaryTable SPD
	   	   WHERE ISNULL(SPD.GranularityFlag,0)=CASE WHEN SPD.GranularityFlag IS NULL THEN 0 ELSE 3 END
     )
    INSERT INTO @resultSet
     (
     ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
     TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
     ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
     ActualEnergyCost ,Viewtype, Subview,Id, SortOrder 
    )
    SELECT 0
	,DateRange
	,SUM(TotalLoad)
	,SUM(Numberofbatches)
	,SUM(ActualChemicalConsumption)
	,SUM(TargetChemicalConsumption)
	,SUM(ActualEnergyConsumption)
	,SUM(TargetEnergyConsumption)
	,SUM(ActualWaterConsumption)
	,SUM(TargetWaterConsumption)
	,SUM(ActualChemicalCost)
	,SUM(ActualWaterCost)
	,SUM(ActualEnergyCost)
	,@Viewtype 
	,@Subview
	,0
	,MAX(SortOrder)
    FROM CTE
    GROUP BY DateRange

        END
  ---- By TimeLine - Quarter View
  IF(@Subview = 2)
  BEGIN
   DECLARE @QuarterYear VARCHAR(100) = YEAR(@enddate);

   WITH CTE_QuarterView (    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id,YearOrder, MonthOrder )
   AS (
      SELECT  DISTINCT
       0,
    DATENAME(MONTH, RecordDate) + ' ' + CAST( YEAR(RecordDate) as varchar) As DateRange,
    SUM(SPD.ActualProduction)
    ,sum( NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption) 
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,0
    ,YEAR(RecordDate) AS YearOrder
    ,DATEPART(MONTH, RecordDate) AS MonthOrder
   FROM @OperationSummaryTable SPD
	   WHERE ISNULL(SPD.GranularityFlag,0)=CASE WHEN SPD.GranularityFlag IS NULL THEN 0 ELSE 3 END
   GROUP BY  DATEPART(MONTH, RecordDate),DATENAME(MONTH, RecordDate),YEAR(RecordDate) 
   
   )

   INSERT INTO @resultSet
    (
    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id, SortOrder
    )
    SELECT ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id
    , ROW_NUMBER() OVER (ORDER BY cqv.YearOrder, cqv.MonthOrder) AS SortOrder
    FROM CTE_QuarterView cqv
 
  END   
  ---- By TimeLine - Year View
  IF(@Subview = 1)
  BEGIN
   DECLARE @Year VARCHAR(100) = RIGHT(YEAR(@enddate),2);


    WITH CTE_YearView (    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id, YearOrder, MonthOrder)
    AS (
       SELECT 
    0,
    CASE 'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10))
    WHEN 'Q1' THEN 'Jan' + RIGHT(YEAR(RecordDate),2) + '- Mar' + RIGHT(YEAR(RecordDate),2)
    WHEN 'Q2' THEN 'Apr' + RIGHT(YEAR(RecordDate),2) + '- Jun' + RIGHT(YEAR(RecordDate),2)
    WHEN 'Q3' THEN 'Jul' + RIGHT(YEAR(RecordDate),2) + '-Sep' + RIGHT(YEAR(RecordDate),2)
    WHEN 'Q4' THEN 'Oct' + RIGHT(YEAR(RecordDate),2) + '- Dec'+ RIGHT(YEAR(RecordDate),2)
    END AS DateRange,
    SUM(SPD.ActualProduction)
    ,sum( NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,0
    ,RIGHT(YEAR(RecordDate),2) AS YearOrder
    , DATEPART(QUARTER, RecordDate) as MonthOrder
   FROM @OperationSummaryTable SPD
	   WHERE ISNULL(SPD.GranularityFlag,0)=CASE WHEN SPD.GranularityFlag IS NULL THEN 0 ELSE 3 END
   GROUP BY DATEPART(QUARTER, RecordDate),RIGHT(YEAR(RecordDate),2)
  --order by cast( cast(RIGHT(YEAR(RecordDate),2) AS varchar ) +cast(  DATEPART(QUARTER, RecordDate) AS varchar) AS int)  
   )


   INSERT INTO @resultSet
    (
    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id, SortOrder
    )
    SELECT 
        ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id
    ,ROW_NUMBER() OVER (ORDER BY YearOrder, MonthOrder) AS SortOrder
    FROM CTE_YearView
 
  END
    END

    -- ******************************** Location View ***************************************************
    IF(@Viewtype = 2)
    BEGIN
  --Plant - WasherGroup
  IF(@Subview = 9)
  BEGIN
   WITH CTE(DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption,TargetChemicalConsumption,ActualEnergyConsumption,
   TargetEnergyConsumption,ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,ActualEnergyCost,WasherGroupId)
   AS
   (
   SELECT 
     WG.WasherGroupName,
     SUM(SPD.ActualProduction)
    ,SUM(NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,WG.WasherGroupId

   FROM @OperationSummaryTable SPD LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId
      LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId 
 	   WHERE ISNULL(SPD.GranularityFlag,0)=CASE WHEN SPD.GranularityFlag IS NULL THEN 0 ELSE 2 END
   GROUP BY WG.WasherGroupName,WG.WasherGroupId--,SPD.ShiftId
 UNION ALL
   SELECT 
	   'Non Allocated Usage',0,NULL,NULL,NULL
	 ,SUM(CASE WHEN GranularityFlag=1 THEN  ActualEnergyConsumption --Plant Usage
			 ELSE 0 END)
			 -
			 SUM(CASE WHEN GranularityFlag=2 THEN  ActualEnergyConsumption --WG Usage
			 ELSE 0 END) ActualEnergyConsumption
	   ,NULL
	   ,SUM(CASE WHEN GranularityFlag=1 THEN  ActualWaterConsumption 
			 ELSE 0 END)
			 -
			 SUM(CASE WHEN GranularityFlag=2 THEN  ActualWaterConsumption 
			 ELSE 0 END) ActualWaterConsumption
	   ,NULL,NULL
	   ,SUM(CASE WHEN GranularityFlag=1 THEN  ActualWaterCost 
			 ELSE 0 END)
			 -
			 SUM(CASE WHEN GranularityFlag=2 THEN  ActualWaterCost 
			 ELSE 0 END) ActualWaterCost
	   ,SUM(CASE WHEN GranularityFlag=1 THEN  ActualEnergyCost 
			 ELSE 0 END)
			 -
			 SUM(CASE WHEN GranularityFlag=2 THEN  ActualEnergyCost 
			 ELSE 0 END) ActualEnergyCost
	   ,NULL
    FROM @OperationSummaryTable SPD
    LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId
    LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId 
   GROUP BY WG.WasherGroupName,WG.WasherGroupId--,SPD.ShiftId
   ) 

    INSERT INTO @resultSet
    (
    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id 
    )
   SELECT 0, 
   DateRange,
   SUM(TotalLoad),
   SUM(Numberofbatches),
   SUM(ActualChemicalConsumption)
   ,SUM(TargetChemicalConsumption) 
   ,SUM(ActualEnergyConsumption)
   ,SUM(TargetEnergyConsumption)
   ,SUM(ActualWaterConsumption)
   ,SUM(TargetWaterConsumption)
   ,SUM(ActualChemicalCost)
   ,SUM(ActualWaterCost)
   ,SUM(ActualEnergyCost)
   ,@Viewtype 
   ,@Subview
   ,WasherGroupId
   FROM CTE 
   WHERE TotalLoad IS NOT NULL       
   GROUP BY DateRange,WasherGroupId
   END
   
  --Washer 
  IF(@Subview = 10)
  BEGIN
    WITH CTE(DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption,TargetChemicalConsumption,ActualEnergyConsumption,
    TargetEnergyConsumption,ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,ActualEnergyCost)
   AS
   (
   SELECT 
    
     CAST( W.PlantWasherNumber AS VARCHAR(20))+':'+ MS.MachineName as MachineName
    ,SUM(SPD.ActualProduction)
    ,SUM(NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)     
   FROM @OperationSummaryTable SPD 
   LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId
   LEFT JOIN TCD.Washer w on MS.WasherId=w.WasherId
   LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId 
   WHERE 
     (
      CASE @drillvalue   
       WHEN '' THEN 'TRUE'         
       ELSE                                                    
     CASE WHEN WG.WasherGroupId IN (@drillvalue) THEN 'TRUE' END            
       END='TRUE'
     ) 
 	 AND ISNULL(SPD.GranularityFlag,0)=CASE WHEN SPD.GranularityFlag IS NULL THEN 0 ELSE 3 END

    GROUP BY CAST( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName--,SPD.ShiftId
    
    UNION ALL
     SELECT 
	   'Non Allocated Usage',0,NULL,NULL,NULL
	 ,SUM(CASE WHEN GranularityFlag=2 THEN  ActualEnergyConsumption --WG Usage
			 ELSE 0 END)
			 -
			 SUM(CASE WHEN GranularityFlag=3 THEN  ActualEnergyConsumption --W Usage
			 ELSE 0 END) ActualEnergyConsumption
	   ,NULL
	   ,SUM(CASE WHEN GranularityFlag=2 THEN  ActualWaterConsumption 
			 ELSE 0 END)
			 -
			 SUM(CASE WHEN GranularityFlag=3 THEN  ActualWaterConsumption 
			 ELSE 0 END) ActualWaterConsumption
	   ,NULL,NULL
	   ,SUM(CASE WHEN GranularityFlag=2 THEN  ActualWaterCost 
			 ELSE 0 END)
			 -
			 SUM(CASE WHEN GranularityFlag=3 THEN  ActualWaterCost 
			 ELSE 0 END) ActualWaterCost
	   ,SUM(CASE WHEN GranularityFlag=2 THEN  ActualEnergyCost 
			 ELSE 0 END)
			 -
			 SUM(CASE WHEN GranularityFlag=3 THEN  ActualEnergyCost 
			 ELSE 0 END) ActualEnergyCost
 
    FROM @OperationSummaryTable SPD
    LEFT JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId
    LEFT JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId 
   GROUP BY WG.WasherGroupId--,SPD.ShiftId
      
    )

    INSERT INTO @resultSet
    (
    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id 
    )
    SELECT  0, 
    DateRange,
    SUM(TotalLoad),
    SUM(Numberofbatches),
    SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,0
     FROM CTE 
    WHERE TotalLoad IS NOT NULL
    GROUP BY DateRange
  END
    END

    -- ******************************** ChainCategory View **********************************************
    IF(@Viewtype = 5)
    BEGIN
  --ChainCategory
  IF(@Subview = 16)
  BEGIN
   -- ToDo : Change this part for chaincategory
    INSERT INTO @resultSet
    (
    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id 
    )
    SELECT DISTINCT
    0,  
    CC.NAME,
    SUM(SPD.ActualProduction)
    ,sum( NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,CC.TextileId
    FROM
    @OperationSummaryTable SPD
    INNER JOIN #ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
    INNER JOIN #PlantChainProgram PCP on PCP.PlantProgramId = PM.PlantProgramId
    INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId 
    Group by  CC.Name,CC.TextileId
  END
     --ChainFormula
  IF(@Subview = 19)
  BEGIN
   -- ToDo : Change this part for chaincategory
    INSERT INTO @resultSet
    (
    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id 
    )
    SELECT  DISTINCT
    0,
    PCP.PlantProgramName,
    SUM(SPD.ActualProduction)
    ,sum( NoOfLoads)
       ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,0
    FROM @OperationSummaryTable SPD
    INNER JOIN #ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
    INNER JOIN #PlantChainProgram PCP on PCP.PlantProgramId = PM.PlantProgramId
    INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = PM.ChainTextileId 
     WHERE
    (
      CASE @drillvalue   
       WHEN '' THEN 'TRUE'         
       ELSE                                                    
       CASE WHEN CC.TextileId IN (@drillvalue) THEN 'TRUE' END            
       END='TRUE'
     )
    Group by  PCP.PlantProgramName,PCP.PlantProgramId
  END
 END

    -- ******************************** Customer View ***************************************************
 IF(@Viewtype = 6)
 BEGIN
  INSERT INTO @resultSet
  (
  ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
  TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
  ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
  ActualEnergyCost ,Viewtype, Subview,Id 
  )
  SELECT DISTINCT
  0,
  PC.CustomerName,
  SUM(SPD.ActualProduction)
  ,sum(NoOfLoads)
  ,SUM(ActualChemicalConsumption)
  ,SUM(TargetChemicalConsumption) 
  ,SUM(ActualEnergyConsumption)
  ,SUM(TargetEnergyConsumption)
  ,SUM(ActualWaterConsumption)
  ,SUM(TargetWaterConsumption)
  ,SUM(ActualChemicalCost)
  ,SUM(ActualWaterCost)
  ,SUM(ActualEnergyCost)
  ,@Viewtype 
  ,@Subview
  ,0
  FROM @OperationSummaryTable SPD  INNER JOIN TCD.PlantCustomer PC on PC.CustomerId = SPD.CustomerId
  GROUP BY PC.CustomerName
   
 END

 -- ******************************** Formula View **************************************************** 
 IF(@Viewtype = 7)
 BEGIN
  INSERT INTO @resultSet
  (
  ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
  TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
  ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
  ActualEnergyCost ,Viewtype, Subview,Id 
  )
  SELECT DISTINCT
  0,
  PM.Name,
  SUM(SPD.ActualProduction)
  ,sum( NoOfLoads)
  ,SUM(ActualChemicalConsumption)
  ,SUM(TargetChemicalConsumption) 
  ,SUM(ActualEnergyConsumption)
  ,SUM(TargetEnergyConsumption)
  ,SUM(ActualWaterConsumption)
  ,SUM(TargetWaterConsumption)
  ,SUM(ActualChemicalCost)
  ,SUM(ActualWaterCost)
  ,SUM(ActualEnergyCost)
  ,@Viewtype 
  ,@Subview
  ,0
  FROM @OperationSummaryTable SPD 
  INNER JOIN #ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
  Group by   PM.Name
    
   END
  
   -- ******************************** Formula Hierarchy**************************************************** 
 IF(@Viewtype = 8) --Formula Hierarchy
 BEGIN
   PRINT 'IN View'
   IF(@Subview =20)-- Formula Segment
   BEGIN
    PRINT 'IN subView'


    SELECT 
 
     @ActualEnergyConsumption=SUM(ActualEnergyConsumption)
    ,@TargetEnergyConsumption=SUM(TargetEnergyConsumption)

    ,@ActualWaterConsumption=SUM(ActualWaterConsumption)
    ,@TargetWaterConsumption=SUM(TargetWaterConsumption)
 
    ,@ActualWaterCost=SUM(ActualWaterCost)
    ,@ActualEnergyCost=SUM(ActualEnergyCost)

     FROM 
    (
    SELECT DISTINCT
     0 AS AB
    ,FS.SegmentName
    ,SUM(SPD.ActualProduction)		ActualProduction
    ,SUM(NoOfLoads)					NoOfLoads
    ,SUM(ActualChemicalConsumption)	ActualChemicalConsumption
    ,SUM(TargetChemicalConsumption)	TargetChemicalConsumption
    ,SUM(ActualEnergyConsumption)		ActualEnergyConsumption
    ,SUM(TargetEnergyConsumption)		TargetEnergyConsumption
    ,SUM(ActualWaterConsumption)		ActualWaterConsumption
    ,SUM(TargetWaterConsumption)		TargetWaterConsumption
    ,SUM(ActualChemicalCost)			ActualChemicalCost
    ,SUM(ActualWaterCost)			ActualWaterCost
    ,SUM(ActualEnergyCost)			ActualEnergyCost
    ,@Viewtype AS Viewtype
    ,@Subview AS Subview
    ,SPD.FormulaSegmentID
    FROM @OperationSummaryTable SPD 
    INNER JOIN #ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
    LEFT OUTER JOIN #FormulaSegments FS ON FS.FormulaSegmentID=SPD.FormulaSegmentID
				WHERE ISNULL(SPD.GranularityFlag,0)=CASE WHEN SPD.GranularityFlag IS NULL THEN 0 ELSE 3 END  
	Group by SPD.FormulaSegmentID,FS.SegmentName
    ) A


    INSERT INTO @resultSet
    (
    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id 
    )
    SELECT DISTINCT
     0
    ,FS.SegmentName
    ,SUM(SPD.ActualProduction)
    ,SUM(NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,SPD.FormulaSegmentID
    FROM @OperationSummaryTable SPD 
    INNER JOIN #ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
    LEFT OUTER JOIN #FormulaSegments FS ON FS.FormulaSegmentID=SPD.FormulaSegmentID
				WHERE ISNULL(SPD.GranularityFlag,0)=CASE WHEN SPD.GranularityFlag IS NULL THEN 0 ELSE 3 END  
    Group by SPD.FormulaSegmentID,FS.SegmentName
    UNION ALL
    
    SELECT TOP 1 ---RETURN NON NULL READINGS 
    0
    ,'Non Allocated Usage'
    ,NULL
    ,NULL

    ,NULL
    ,NULL
    ,SUM(ActualEnergyConsumption)-@ActualEnergyConsumption
    ,SUM(TargetEnergyConsumption)-@TargetEnergyConsumption
    ,SUM(ActualWaterConsumption)-@ActualWaterConsumption
    ,SUM(TargetWaterConsumption)-@TargetWaterConsumption
 
    ,NULL

    ,SUM(ActualWaterCost)-@ActualWaterCost
    ,SUM(ActualEnergyCost)-@ActualEnergyCost
    ,NULL

    ,NULL
    ,NULL
    FROM @OperationSummaryTable SPD 
	   INNER JOIN #ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
	   LEFT OUTER JOIN #FormulaSegments FS ON FS.FormulaSegmentID=SPD.FormulaSegmentID
	   WHERE  SPD.GranularityFlag IS NOT NULL --PLANT, WG, W
	   Group by SPD.GranularityFlag
 
  END
   IF(@Subview = 21)-- Formula Categories
   BEGIN
    INSERT INTO @resultSet
    (
    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id 
    )
    --Chain Textile category
    SELECT DISTINCT
    0,
    CC.Name
    ,SUM(SPD.ActualProduction)
    ,sum( NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,(CASE WHEN CC.TextileId=-999		--To handle the UnKnown ProgramId
				THEN CC.TextileId 
				ELSE 1000+ CC.TextileId
	  END) TextileId
    FROM @OperationSummaryTable SPD 
    LEFT JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
   WHERE SPD.FormulaSegmentID =@drillvalue OR ISNULL( @drillvalue,'')='' --CHain Textilecategory
			--AND SPD.GranularityFlag NOT IN (1,2)--PLANT, WG
		 AND ISNULL(SPD.GranularityFlag,0)=CASE WHEN SPD.GranularityFlag IS NULL THEN 0 ELSE 3 END  

    GROUP BY CC.Name,CC.TextileId

    UNION 
    --Ecolab Textile category
    SELECT DISTINCT
    0
    ,EC.CategoryName
    ,SUM(SPD.ActualProduction)
    ,sum( NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,EC.TextileId
   FROM @OperationSummaryTable SPD 
   LEFT JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
    WHERE SPD.FormulaSegmentID = @drillvalue OR ISNULL( @drillvalue,'')='' ---Ecolab Textile categoriy
		--AND SPD.GranularityFlag NOT IN (1,2)--PLANT, WG
		 AND ISNULL(SPD.GranularityFlag,0)=CASE WHEN SPD.GranularityFlag IS NULL THEN 0 ELSE 3 END  

   GROUP BY EC.CategoryName,EC.TextileId

    END
   
   IF(@Subview=22) -- Formula
   BEGIN   
     DECLARE @ChaincategoryDrillValue INT
			IF(@Drillvalue>1000)
				SET @ChaincategoryDrillValue=@Drillvalue-1000
			 ELSE IF (@Drillvalue <1000)
				SET @ChaincategoryDrillValue=@Drillvalue+1000
			---End 
   
   --SELECT @ChaincategoryDrillValue
   
    INSERT INTO @resultSet
    (
    ShiftId,DateRange,TotalLoad,Numberofbatches,ActualChemicalConsumption ,
    TargetChemicalConsumption,ActualEnergyConsumption,TargetEnergyConsumption,
    ActualWaterConsumption,TargetWaterConsumption,ActualChemicalCost,ActualWaterCost,
    ActualEnergyCost ,Viewtype, Subview,Id 
    )
    --chain TextileFormula
    SELECT DISTINCT       
    0, 
    PM.Name
    ,SUM(SPD.ActualProduction)
    ,SUM( NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,PM.ProgramId
        FROM @OperationSummaryTable SPD     
			 INNER JOIN #ProgramMaster PM ON SPD.ProgramMasterId = PM.ProgramId
			WHERE  SPD.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable) 
			  	--AND SPD.GranularityFlag NOT IN (1,2)--PLANT, WG
					AND ISNULL(SPD.GranularityFlag,0)=CASE WHEN SPD.GranularityFlag IS NULL THEN 0 ELSE 3 END  
				AND
				(  
				CASE      
				WHEN @drillvalue='' THEN 'TRUE'   
				WHEN @drillvalue IS NULL THEN 'TRUE'    
				ELSE                                                      
				CASE WHEN SPD.EcolabTextileId  IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				) --AND PM.NAME IS NOT NULL    
   
   GROUP BY PM.Name,PM.ProgramId
   UNION
   ---EcoLabFormula
   SELECT 
      DISTINCT
    0, 
    PM.Name
    ,SUM(SPD.ActualProduction)
    ,SUM( NoOfLoads)
    ,SUM(ActualChemicalConsumption)
    ,SUM(TargetChemicalConsumption) 
    ,SUM(ActualEnergyConsumption)
    ,SUM(TargetEnergyConsumption)
    ,SUM(ActualWaterConsumption)
    ,SUM(TargetWaterConsumption)
    ,SUM(ActualChemicalCost)
    ,SUM(ActualWaterCost)
    ,SUM(ActualEnergyCost)
    ,@Viewtype 
    ,@Subview
    ,PM.ProgramId
     FROM @OperationSummaryTable SPD 
     INNER JOIN #ProgramMaster PM ON  SPD.ProgramMasterId = PM.ProgramId    
			WHERE  SPD.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)
			    --AND SPD.GranularityFlag NOT IN (1,2)--PLANT, WG
					AND ISNULL(SPD.GranularityFlag,0)=CASE WHEN SPD.GranularityFlag IS NULL THEN 0 ELSE 3 END  
			    AND 
				    (  
				    CASE      
				    WHEN @drillvalue='' THEN 'TRUE'   
				    WHEN @drillvalue IS NULL THEN 'TRUE'    
				    ELSE                                                      
				    CASE WHEN SPD.ChainTextileId IN (@ChaincategoryDrillValue) THEN 'TRUE' END              
				    END='TRUE' 
				    )
   GROUP BY  PM.Name,PM.ProgramId
    END
 END

   --- ********* Return result ********************
        UPDATE 
        @resultSet SET SortOrder=999  --Locate as last record in detail result.
	   WHERE DateRange='Non Allocated Usage';
   --SELECT * FROM @resultSet
 
    SELECT DISTINCT
     ShiftId,
      DateRange,
  --   CASE @uom 
	 --WHEN 1 THEN TotalLoad
	 --WHEN 2 THEN ISNULL([TCD].[FnConsumptionOnMetrics](TotalLoad,'Weight',@UserId),0) 
  --   END 
     ISNULL([TCD].[FnConsumptionOnMetrics](TotalLoad,'Weight',@UserId),0) AS ActualProduction,
      --CAST(TotalLoad AS int) AS ActualProduction,
      Numberofbatches AS NoOfLoads,
      ISNULL([TCD].[FnConsumptionOnMetrics](ActualChemicalConsumption,'Volume',@UserId),0) ActualChemicalConsumption,
      --ActualChemicalConsumption ,
      ISNULL([TCD].[FnConsumptionOnMetrics](TargetChemicalConsumption,'Volume',@UserId),0) TargetChemicalConsumption,
      --TargetChemicalConsumption,
      ActualEnergyConsumption,
      TargetEnergyConsumption,
      ISNULL([TCD].[FnConsumptionOnMetrics](ActualWaterConsumption,'Volume',@UserId),0) ActualWaterConsumption,
      ISNULL([TCD].[FnConsumptionOnMetrics](TargetWaterConsumption,'Volume',@UserId),0) TargetWaterConsumption,
      ActualChemicalCost,
      ActualWaterCost,
      ActualEnergyCost,
      Viewtype,
      Subview ,
      Id,
      --CASE @uom WHEN 1 THEN ActualChemicalConsumption 
      --WHEN 2 THEN ActualChemicalConsumption * 28.3495 END AS ActualChemicalConsumptionMetrics ,
      --CASE @uom WHEN 1 THEN TargetChemicalConsumption 
      --WHEN 2 THEN TargetChemicalConsumption * 28.3495 END AS TargetChemicalConsumption,
     CASE @uom WHEN 1 THEN TotalLoad/100 
            WHEN 2 THEN ISNULL([TCD].[FnConsumptionOnMetrics](TotalLoad,'Weight',@UserId),0) END AS ActualProductionMetrics 
      ,SortOrder
      FROM 
        @resultSet
        WHERE [@resultSet].DateRange IS NOT NULL AND DateRange<>'UNKNOWN'
	ORDER BY SortOrder
    
DROP TABLE #ProgramMaster
DROP TABLE #PlantChainProgram
DROP TABLE #FormulaSegments
DROP TABLE #EcolabSaturation
 
SET NOCOUNT OFF
END