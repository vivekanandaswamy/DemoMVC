﻿    
/*      
 ==========================================================================================      
 Purpose:  DELETEING THE PLANT SHIFT AND BREAK DATA  
    
 Author: Premchand Yelavarthi
 Updated By: Neetha Allati
 Changes:
 ** Id and BreakId was removed
 ** Commented audit log
    
 --------------------------------------------------------------      
 Sep-04-2014 ENT: Initial version.      
 ==========================================================================================   
*/
CREATE PROCEDURE [TCD].[DeleteShiftDetails] (   
    @ShiftId int
   ,@DayId int   
   ,@EcolabAccountNumber NVarchar(25)
   ,@UserID INT = NULL
   --Adding these 3 param as part of re-factoring for integration with Synch/Configurator
--,	@OutputShiftId							INT			=			NULL	OUTPUT	--Removing this, since we don't want this
,	@LastModifiedTimestampAtCentral			DATETIME	=			NULL			--Nullable for local call; Synch/Central call will have to pass this -
																					--else, it will be treated as a local call
,	@OutputLastModifiedTimestampAtLocal		DATETIME	=			NULL	OUTPUT
)
AS
SET NOCOUNT ON
BEGIN
    DECLARE @ShiftTable_name NVARCHAR(1000) = 'ShiftData' 
    DECLARE @BreakTable_name NVARCHAR(1000) = 'ShiftBreakData' 

DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()

DECLARE	@OutputList			AS			TABLE	(
		ShiftId							INT
	)

--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
SET		@OutputLastModifiedTimestampAtLocal				=			@CurrentUTCTime
    
	--If the call is not local, check that the LastModifiedTime matches with the central
	--IF	(
	--		@LastModifiedTimestampAtCentral			IS NOT	NULL
	--	AND																	--	is called by UpdateShifts that is called here)
	--	NOT	EXISTS	(	SELECT	1
	--					FROM	TCD.[Shift]				S
	--					WHERE	S.EcolabAccountNumber	=	@EcolabAccountNumber
	--						AND	S.ShiftId				=	@ShiftId
	--						AND	S.LastModifiedTime		=	@LastModifiedTimestampAtCentral
	--				)
	--	)
	--	BEGIN
	--			SET			@ErrorId					=	60000
	--			SET			@ErrorMessage				=	N'' + CAST(@ErrorId AS NVARCHAR) + N': Record not in-synch between plant and central.'
	--			RAISERROR	(@ErrorMessage, 16, 1)
	--			SET			@ReturnValue				=	-1
	--			RETURN		(@ReturnValue)
	--	END

	--Proceed, since it's either a local call or Synch. call with synch. time matching

    UPDATE [TCD].ShiftData SET Is_Deleted = 1 
	 ,	LastModifiedByUserId	=	@UserId
		OUTPUT	inserted.ShiftId
		INTO	@OutputList	(ShiftId)
	WHERE ShiftId = @ShiftId AND DayId = @DayId AND EcolabAccountNumber = @EcolabAccountNumber
       
    /* Auditing the deleted data in the SHIFT DATA table */
    --EXEC [dbo].[usp_AuditingDeleteDetails] @ShiftTable_name, @UserID

    UPDATE [TCD].ShiftBreakData SET Is_Deleted = 1 
	 ,	LastModifiedByUserId	=	@UserId
		OUTPUT	inserted.ShiftId
		INTO	@OutputList	(ShiftId)
	 WHERE ShiftId = @ShiftId AND DayId = @DayId 

	 UPDATE [TCD].ShiftLaborData SET Is_Deleted = 1 
	 ,	LastModifiedByUserId	=	@UserId
		OUTPUT	inserted.ShiftId
		INTO	@OutputList	(ShiftId)
	 WHERE ShiftId = @ShiftId AND DayId = @DayId 

	-- IF((SELECT COUNT(IS_DELETED) FROM [TCD].SHIFTDATA WHERE IS_DELETED = 0 AND SHIFTID=@ShiftId)=0)
	-- BEGIN
	-- UPDATE [TCD].SHIFT SET IS_DELETED=1 
	--	OUTPUT	inserted.ShiftId
	--	INTO	@OutputList	(ShiftId)
	--		 WHERE IS_DELETED = 0 AND SHIFTID=@ShiftId AND ECOLABACCOUNTNUMBER= @EcolabAccountNumber
	-- END

	--IF	EXISTS	(SELECT	1	FROM	@OutputList)
	--	BEGIN
	--			UPDATE	TCD.[Shift]
	--				SET	LastModifiedTime			=			@CurrentUTCTime
	--			WHERE	EcolabAccountNumber			=			@EcolabAccountNumber
	--				AND	ShiftId						=			@ShiftId

	--			--SELECT	TOP	1
	--			--		@OutputShiftId				=			ShiftId
	--			--FROM	@OutputList
	--	END

    /* Auditing the deleted data in the SHIFT BREAK table */
    --EXEC [dbo].[usp_AuditingDeleteDetails] @BreakTable_name, @UserID
END