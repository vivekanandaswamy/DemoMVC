﻿CREATE PROCEDURE TCD.ProcessMitsubishiTunnelWasherProdData(
 @Controllerid INT, 
 @Xmltags	   XML)
AS
BEGIN
	DECLARE @Batchid			  INT, 
			@Washerid			  INT, 
			@Ecolabwasherid		  INT, 
			@Currencycode		  VARCHAR(50), 
			@Machineinternalid	  INT, 
			@Washergroupid		  INT, 
			@Washergroupnum		  INT, 
			@Plantwashernumber	  INT, 
			@Batchstartdate		  DATETIME2, 
			@Batchenddate		  DATETIME2, 
			@Programnumber		  INT, 
			@Load				  DECIMAL(10, 2), 
			@Nominalload		  DECIMAL(10, 2), 
			@Customernumber		  INT, 
			@Phstatus			  INT, 
			@Phvalue			  INT, 
			@Lfstatus			  INT, 
			@Lfvalue			  INT, 
			@Ejectionsignal		  INT, 
			@Texttilecategory	  INT, 
			@Batchnumber		  INT, 
			@Targetturntime		  INT, 
			@Shiftid			  INT, 
			@Parameterid		  INT, 
			@Shiftname			  VARCHAR(50), 
			@Ecolabaccountnumber  NVARCHAR(1000) = NULL, 
			@Partitionon		  DATETIME, 
			@Batchstarttime		  DATETIME, 
			@Batchendtime		  DATETIME, 
			@Porgramparameterid	  INT, 
			@Phparameterid		  INT, 
			@Conductivityparamid  INT, 
			@Runtime			  INT, 
			@Textilecategory	  INT, 
			@Programid			  INT, 
			@Numberofcompartments INT, 
			@Tempparameter		  INT, 
			@Pumpno				  INT, 
			@Dosingpoint		  INT, 
			@Productid			  INT, 
			@Compartmentnum		  INT, 
			@Mintempparamid		  INT, 
			@Maxtempparamid		  INT, 
			@Tempstatusparamid	  INT, 
			@Phvalueparamid		  INT, 
			@Phstatusparamid	  INT, 
			@Actualinjsteps		  INT, 
			@Alarmgroupmasterid	  INT,
			@TotalInjectsCountFromUI		INT,
			@TotalInjectsCountFromPLC		INT;
	SELECT 
		   @Porgramparameterid = ID FROM TCD.ConduitParameters WHERE NAME = 'Formula Number';
	SELECT 
		   @Phparameterid = ID FROM TCD.ConduitParameters WHERE NAME = 'pH';
	SELECT 
		   @Conductivityparamid = ID FROM TCD.ConduitParameters WHERE NAME = 'Conductivity';
	CREATE TABLE #Batches
	(
		 BatchNumber   INT, 
		 StartDateTime DATETIME
	);
	DECLARE @Batchshiftid INT;
	DECLARE @Shiftstartdatetemp TABLE
	(
		 ShiftId		INT, 
		 ShiftName		NVARCHAR(50), 
		 ShiftStartdate DATETIME
	);
	DECLARE @Compartmentid INT, 
			@Tunnelxml	   XML;
	SELECT 
		   @Compartmentid = 1;
	SELECT 
		   @Washerid = NULL;
	SELECT 
		   @Tunnelxml = T.c.query('.')
		FROM @Xmltags.nodes('MyControlTunnel/TunnelData') AS T(c)
		WHERE T.c.value('@CompartmentNumber', 'INT') = 20;
	SELECT	 
	--@MachineInternalID=T.c.value('@MachineNumber', 'int'),
		   @Batchnumber = T.c.value('@BatchNumber', 'INT'), 
		   @Batchstarttime = T.c.value('@StartDateTime', 'DateTime'), 
		   @Batchendtime = T.c.value('@EndDateTime', 'DateTime'), 
		   @Programnumber = T.c.value('@ProgramNumber', 'INT'), 
		   @Load = T.c.value('@Load', 'Decimal(10,2)')/10, 
		   @Nominalload = T.c.value('@Nominalload', 'Decimal(10,2)'), 
		   @Washergroupnum = T.c.value('@GroupNumber', 'int'), 
		   @Customernumber = T.c.value('@CustomerNumber', 'int'), 
		   @Phstatus = T.c.value('@pHStatus', 'int'), 
		   @Phvalue = T.c.value('@pHValue', 'INT'), 
		   @Lfstatus = T.c.value('@LFStatus', 'INT'), 
		   @Lfvalue = T.c.value('@LFValue', 'INT'), 
		   @Runtime = T.c.value('@RunTime', 'INT'), 
		   @Ejectionsignal = T.c.value('@EjectionSignal', 'INT'), 
		   @Textilecategory = T.c.value('@TextileCategory', 'INT')
		FROM @Tunnelxml.nodes('TunnelData') AS T(c);
	--Check for valid startdatetime
	IF @Batchstarttime <= '01/01/1900'
	   OR @Batchstarttime > '06/06/2079'
		BEGIN
			RETURN;
		END;
	SELECT 
		   @Washergroupid = Wg.WasherGroupId
		FROM TCD.WasherGroup AS Wg
		WHERE ControllerID = @Controllerid
			  AND WasherDosingNumber = @Washergroupnum
			  AND WasherGroupTypeId = 2;
	SELECT 
		   @Programid = ProgramId, 
		   @Targetturntime = 3600 / (tps.TotalRunTime / @Numberofcompartments)
		FROM TCD.TunnelProgramSetup AS tps
		WHERE tps.WasherGroupId = @Washergroupid
			  AND tps.is_deleted = 0
			  AND ProgramNumber = @Programnumber;
	SELECT 
		   @Batchid = NULL;
	SELECT 
		   @Batchid = BatchID, 
		   @Washerid = MachineId, 
		   @Batchstarttime = StartDate, 
		   @Ecolabwasherid = EcolabWasherId
		FROM TCD.BatchData
		WHERE ControllerBatchId = @Batchnumber
			  AND GroupId = @Washergroupid
			  AND CAST(StartDate AS DATE) = CAST(@Batchstarttime AS DATE);
	IF @Batchid IS NULL
		RETURN;
	IF @Batchid IS NOT NULL
		BEGIN
			IF @Batchendtime IS NOT NULL
				BEGIN
					INSERT INTO @Shiftstartdatetemp
					(
						   ShiftId, 
						   ShiftName, 
						   ShiftStartdate
					)
					EXEC TCD.GetShiftStartDate 
						 @Batchendtime;
					SELECT 
						   @Batchshiftid = ShiftID, 
						   @Partitionon = ShiftStartdate FROM @Shiftstartdatetemp;
					UPDATE TCD.BatchData
					  SET 
						  EndDate = @Batchendtime, 
						  EndDateFormula = @Batchendtime, 
						  ShiftId = @Batchshiftid, 
						  PartitionOn = @Partitionon, 
						  SyncReady = 1
						WHERE 
							  BATCHID = @Batchid;
				END;
			SELECT 
				   @Numberofcompartments = Mst.NumberofComp
				FROM TCD.MachineSetup AS Mst
				WHERE Mst.WasherId = @Washerid
					  AND mst.GroupId = @Washergroupid
					  AND Mst.IsDeleted = 0;
			EXEC TCD.UPDATEBatchWashStepForTunnel 
				 @Tunnelxml, 
				 @Washerid, 
				 @Batchid, 
				 @Batchstarttime, 
				 @Partitionon, 
				 @Ecolabwasherid, 
				 @Numberofcompartments;
			CREATE TABLE #DosingDetails
			(
				 Number			 INT, 
				 Quantity		 DECIMAL(10, 6), 
				 Point			 INT, 
				 IsMainEquioment INT, 
				 IsDirectDosing	 INT
			);
			INSERT INTO #DosingDetails
			(
				   Number, 
				   Quantity, 
				   Point, 
				   IsMainEquioment, 
				   IsDirectDosing
			)
				   SELECT 
						  T.c.value('@Number', 'INT') AS Number, --PumpNumber
						  T.c.value('@Quantity', 'Decimal(10,6)') AS Quantity, --Dosing Quanity
						  T.c.value('@Point', 'INT') AS Point, --ValveNumber
						  T.c.value('@IsMainEquipment', 'INT') AS IsMainEquioment, 
						  T.c.value('@IsDirectDosing', 'INT') AS IsDirectDosing
					   FROM @Tunnelxml.nodes('TunnelData/Dose') AS T(c);

			-- Fetching data from cursor
			DECLARE @Mycursor CURSOR;
			SET @Mycursor = CURSOR FAST_FORWARD
			FOR SELECT 
					   Number,
					   CASE
						   WHEN Number = 13
								OR Number = 14
								OR Number = 27
								OR Number = 28
						   THEN Quantity * 16
						   ELSE Quantity
					   END, 
					   Point, 
					   IsMainEquioment, 
					   IsDirectDosing
					FROM #DosingDetails;
			DECLARE @Number			 INT, 
					@Quantity		 DECIMAL(10, 6), 
					@Point			 INT, 
					@Ismainequioment INT, 
					@Isdirectdosing	 INT;
			OPEN @Mycursor;
			FETCH NEXT FROM @Mycursor INTO @Number, 
										   @Quantity, 
										   @Point, 
										   @Ismainequioment, 
										   @Isdirectdosing;
			WHILE @@Fetch_Status = 0
				BEGIN
					IF @Isdirectdosing = 1
						BEGIN
							SELECT 
								   @Productid = CES.ProductId, 
								   @Compartmentnum = TCEVM.CompartmentNumber
								FROM tcd.ControllerEquipmentSetup AS CES
									 INNER JOIN TCD.TunnelCompartmentEquipmentValveMapping AS TCEVM ON CES.ControllerEquipmentSetupId = TCEVM.
									 ControllerEquipmentSetupId
								WHERE TCEVM.DirectDosingFlag = 1
									  AND CES.ControllerId = @Controllerid
									  AND CES.ControllerEquipmentId = @Number
									  AND CES.ControllerEquipmentTypeId = 1 
									  --AND IsActive=1 
									  AND CES.WasherGroupNumber = @Washergroupnum;
						END;
					ELSE
					IF @Ismainequioment = 1
						BEGIN
							SELECT 
								   @Productid = CES.ProductId, 
								   @Compartmentnum = TCEVM.CompartmentNumber
								FROM tcd.ControllerEquipmentSetup AS CES
									 INNER JOIN TCD.TunnelCompartmentEquipmentValveMapping AS TCEVM ON CES.ControllerEquipmentSetupId = TCEVM.
									 ControllerEquipmentSetupId
								WHERE CES.ControllerId = @Controllerid
									  AND CES.ControllerEquipmentTypeId = 2
									  AND --CES.IsActive=1 AND
									  CES.WasherGroupNumber = @Washergroupnum
									  AND TCEVM.ValveNumber = @Point
									  AND CES.ControllerEquipmentId = @Number
									  AND TCEVM.CompartmentNumber > 0;
						END;
					ELSE
						BEGIN
							SELECT 
								   @Productid = CES.ProductId, 
								   @Compartmentnum = TCEVM.CompartmentNumber
								FROM tcd.ControllerEquipmentSetup AS CES
									 INNER JOIN TCD.TunnelCompartmentEquipmentValveMapping AS TCEVM ON CES.ControllerEquipmentSetupId = TCEVM.
									 ControllerEquipmentSetupId
								WHERE CES.ControllerId = @Controllerid
									  AND CES.ControllerEquipmentTypeId = 1
									  AND --CES.IsActive=1 AND
									  CES.WasherGroupNumber = @Washergroupnum
									  AND TCEVM.ValveNumber = @Point
									  AND TCEVM.CompartmentNumber > 0;
						END;;
					IF @Productid IS NOT NULL
						BEGIN
							INSERT INTO TCD.BatchProductData
							(
								   BatchId, 
								   StepCompartment, 
								   ActualQuantity, 
								   PartitionOn, 
								   EcolabWasherId, 
								   ProductId
							)
								   SELECT 
										  @Batchid, 
										  @Compartmentnum, 
										  @Quantity, 
										  @Partitionon, 
										  @Ecolabwasherid, 
										  @Productid;
						END;
					FETCH NEXT FROM @Mycursor INTO @Number, 
												   @Quantity, 
												   @Point, 
												   @Ismainequioment, 
												   @Isdirectdosing;
				END;
			CLOSE @Mycursor;
			DEALLOCATE @Mycursor;
			DROP TABLE #DosingDetails;

			--BatchStatus parametr insertion start
		SELECT DISTINCT 
						 @TotalInjectsCountFromUI = COUNT(1)
					FROM TCD.Washer AS ws
						 INNER JOIN TCD.MachineSetup AS ms ON ms.WasherId = ws.WasherId
						 INNER JOIN TCD.WasherGroup AS wg ON wg.WasherGroupId = ms.GroupId
						 INNER JOIN TCD.WasherGroupType AS WgT ON WgT.WasherGroupTypeId = wg.WasherGroupTypeId
						 INNER JOIN TCD.TunnelProgramSetup AS tps ON tps.WasherGroupId = wg.WasherGroupId
						 INNER JOIN TCD.TunnelDosingSetup AS tds ON tds.TunnelProgramSetupId = tps.TunnelProgramSetupId
						 INNER JOIN TCD.TunnelDosingProductMapping AS tdpm ON tdpm.TunnelDosingSetupId = tds.TunnelDosingSetupId
						 
					WHERE tds.Is_Deleted = 0							
							AND ms.IsTunnel = 1
							AND ms.GroupId = @WasherGroupId
							AND ms.WasherId = @Washerid
							AND ms.ControllerId =@Controllerid
							AND ms.IsDeleted = 0

		SELECT @TotalInjectsCountFromPLC=Count(*) FROM TCD.BatchProductData bpd WHERE bpd.BatchId=@Batchid

		IF NOT EXISTS
					(SELECT 
							* FROM TCD.BatchParameters WHERE BatchId = @Batchid
															AND ParameterID = 18
					)
		BEGIN
				INSERT INTO TCD.BatchParameters
					(
						   BatchId, 
						   EcolabWasherId, 
						   ParameterId, 
						   ParameterValue, 
						   PartitionOn
					)
						   SELECT 
								  @Batchid, 
								  @Ecolabwasherid, 
								  18, 
								  CASE WHEN @TotalInjectsCountFromUI=@TotalInjectsCountFromPLC THEN 1
									   WHEN @TotalInjectsCountFromUI<>@TotalInjectsCountFromPLC THEN 3 END, 
								  @Partitionon;
		END;
		--BatchStatus parameter insertion end

			IF NOT EXISTS
						 (SELECT 
								 * FROM TCD.BatchParameters WHERE ParameterId = 41
																  AND batchid = @Batchid
						 )
				BEGIN
					INSERT INTO Tcd.BatchParameters
					(
						   BatchId, 
						   EcolabWasherId, 
						   ParameterId, 
						   ParameterValue, 
						   PartitionOn
					)
						   SELECT 
								  @Batchid, 
								  @Ecolabwasherid, 
								  41,
								  CASE
									  WHEN SUM(bpd.ActualQuantity) = SUM(bpd.StandardQuantity)
									  THEN 1		--'Approved'
									  WHEN SUM(bpd.ActualQuantity) <> SUM(bpd.StandardQuantity)
									  THEN 2		--'Rejected'
									  ELSE 1		--'Approved'
								  END, 
								  @Partitionon
							   FROM TCD.BatchProductData AS bpd
							   WHERE bpd.BatchId = @Batchid;
				END;
			SELECT 
				   @Actualinjsteps = COUNT(DISTINCT StepCompartment)
				FROM TCD.BatchProductData
				WHERE BatchId = @Batchid;
			IF NOT EXISTS
						 (SELECT 
								 *
							  FROM TCD.BatchParameters
							  WHERE ParameterId = 37
									AND batchid = @Batchid
									AND @Actualinjsteps > 0
						 )
				BEGIN
					INSERT INTO TCD.BatchParameters
					(
						   BatchId, 
						   EcolabWasherId, 
						   ParameterId, 
						   ParameterValue, 
						   PartitionOn
					)
						   SELECT 
								  @Batchid, 
								  @Ecolabwasherid, 
								  37, 
								  @Actualinjsteps, 
								  @Partitionon;
				END;
			ELSE
				BEGIN
					UPDATE TCD.BatchParameters
					  SET 
						  ParameterValue = @Actualinjsteps
						WHERE 
							  ParameterId = 37
							  AND batchid = @Batchid;
				END;
		END;
	SELECT 
		   @Mintempparamid = Id FROM TCD.ConduitParameters WHERE Name = 'Mimum Temperature';
	SELECT 
		   @Maxtempparamid = Id
		FROM TCD.ConduitParameters
		WHERE Name = 'Maximum Temperature';
	SELECT 
		   @Tempstatusparamid = Id
		FROM TCD.ConduitParameters
		WHERE Name = 'Temperature Status';
	SELECT 
		   @Phvalueparamid = ID FROM TCD.ConduitParameters WHERE Name = 'PH';
	SELECT 
		   @Phstatusparamid = ID FROM TCD.ConduitParameters WHERE Name = 'PH Status';  

	--pH Status
	IF NOT EXISTS
				 (SELECT 
						 *
					  FROM TCD.BatchParameters
					  WHERE BatchId = @Batchid
							AND ParameterID = @Phstatusparamid
				 )
		BEGIN
			IF ISNULL(@Phstatus, 0) > 0
				BEGIN
					INSERT INTO TCD.BatchParameters
					(
						   BatchId, 
						   EcolabWasherId, 
						   ParameterId, 
						   ParameterValue, 
						   PartitionOn
					)
					VALUES
					(
						   @Batchid, 
						   @Ecolabwasherid, 
						   @Phstatusparamid, 
						   @Phstatus, 
						   @Partitionon
					);
				END;
		END;
	--pH Value
	IF NOT EXISTS
				 (SELECT 
						 *
					  FROM TCD.BatchParameters
					  WHERE BatchId = @Batchid
							AND ParameterID = @Phvalueparamid
				 )
		BEGIN
			IF ISNULL(@Phvalue, 0) > 0
				BEGIN
					INSERT INTO TCD.BatchParameters
					(
						   BatchId, 
						   EcolabWasherId, 
						   ParameterId, 
						   ParameterValue, 
						   PartitionOn
					)
					VALUES
					(
						   @Batchid, 
						   @Ecolabwasherid, 
						   @Phvalueparamid, 
						   @Phvalue, 
						   @Partitionon
					);
				END;
		END;
	CREATE TABLE #TemperatureDetails
	(
		 MinimumTemp DECIMAL(10, 2), 
		 MaximumTemp DECIMAL(10, 2), 
		 TempStatus	 DECIMAL(10, 2)
	);
	INSERT INTO #TemperatureDetails
	(
		   MinimumTemp, 
		   MaximumTemp, 
		   TempStatus
	)
		   SELECT 
				  T.c.value('@MinimumTemp', 'Decimal(10,2)') AS MinimumTemp, 
				  T.c.value('@MaximumTemp', 'Decimal(10,2)') AS MaximumTemp, 
				  T.c.value('@Status', 'Decimal(10,2)') AS Status
			   FROM @Tunnelxml.nodes('TunnelData/TemperatureData') AS T(c);

	-- Fetching data from cursor
	DECLARE @Tempcursor CURSOR;
	SET @Tempcursor = CURSOR FAST_FORWARD
	FOR SELECT 
			   MinimumTemp, 
			   MaximumTemp, 
			   TempStatus FROM #TemperatureDetails;
	DECLARE @Minimumtemp DECIMAL(10, 2), 
			@Maximumtemp DECIMAL(10, 2), 
			@Tempstatus	 DECIMAL(10, 2);
	OPEN @Tempcursor;
	FETCH NEXT FROM @Tempcursor INTO @Minimumtemp, 
									 @Maximumtemp, 
									 @Tempstatus;
	WHILE @@Fetch_Status = 0
		BEGIN 
			--Minimum Temperature
			INSERT INTO TCD.BatchParameters
			(
				   BatchId, 
				   EcolabWasherId, 
				   ParameterId, 
				   ParameterValue, 
				   PartitionOn
			)
			VALUES
			(
				   @Batchid, 
				   @Ecolabwasherid, 
				   @Mintempparamid, 
				   @Minimumtemp, 
				   @Partitionon
			);
			--Maximum Temperature
			INSERT INTO TCD.BatchParameters
			(
				   BatchId, 
				   EcolabWasherId, 
				   ParameterId, 
				   ParameterValue, 
				   PartitionOn
			)
			VALUES
			(
				   @Batchid, 
				   @Ecolabwasherid, 
				   @Maxtempparamid, 
				   @Maximumtemp, 
				   @Partitionon
			);
			--Temperature Status
			INSERT INTO TCD.BatchParameters
			(
				   BatchId, 
				   EcolabWasherId, 
				   ParameterId, 
				   ParameterValue, 
				   PartitionOn
			)
			VALUES
			(
				   @Batchid, 
				   @Ecolabwasherid, 
				   @Tempstatusparamid, 
				   @Tempstatus, 
				   @Partitionon
			);
			FETCH NEXT FROM @Tempcursor INTO @Minimumtemp, 
											 @Maximumtemp, 
											 @Tempstatus;
		END;
	CLOSE @Tempcursor;
	DEALLOCATE @Tempcursor;
	DROP TABLE #TemperatureDetails;
	--If the received formula is not configured in enVision then create an alarm 
	IF @Programid IS NULL
		BEGIN
			SELECT 
				   @Ecolabaccountnumber = EcolabAccountNumber FROM TCD.Plant;
			SELECT 
				   @Alarmgroupmasterid = AGM.AlarmGroupMasterId
				FROM TCD.AlarmGroupMsterVsControllerModelType AS AGMVCMT
					 INNER JOIN TCD.AlarmGroupMaster AS AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
				WHERE AGMVCMT.AlarmCode = 9000;
			INSERT INTO TCD.AlarmData
			(
				   EcoalabAccountNumber, 
				   AlarmCode, 
				   BatchId, 
				   controllerID, 
				   StartDate, 
				   GroupId, 
				   MachineInternalId, 
				   ProgramId, 
				   IsActive, 
				   EndDate, 
				   MachineId, 
				   AlarmGroupMasterId,
				   PartitionOn
			)
				   SELECT 
						  @Ecolabaccountnumber, 
						  9000, 
						  @Batchid, 
						  @Controllerid, 
						  @Batchstarttime, 
						  @Washergroupid, 
						  @Machineinternalid, 
						  @Programnumber, 
						  0, 
						  @Batchstarttime, 
						  @Washerid, 
						  @Alarmgroupmasterid,
						  @Batchstarttime;

		END;
END;
