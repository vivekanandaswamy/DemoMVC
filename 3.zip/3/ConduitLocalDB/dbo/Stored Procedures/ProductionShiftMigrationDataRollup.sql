﻿CREATE PROCEDURE [TCD].[ProductionShiftMigrationDataRollup](@Date datetime)
AS
BEGIN
SET NOCOUNT ON

    DECLARE @DayId INT = NULL,
		  @ShiftId Int = NULL,
		  @ShiftName Varchar(100) = NULL,
		  @StartTime DateTime = NULL,
		  @EndTime DateTime = NULL,
		  @DateStartTime DATETIME= NULL,
		  @DateEndTime DATETIME= NULL,
		  @BatchUTCStart DATETIME= NULL,
		  @BatchUTCEnd DATETIME= NULL,
		  @ShiftTargetProd Decimal(18,2) = NULL,
		  @ConStdTurnTime Int= NULL,
		  @ActualRunandConTurnTime Int= NULL,
		  @TargetRunandConTurnTime Int= NULL,
		  @ActualRunandTunTurnTime Int= NULL,
		  @TargetRunandTunTurnTime Int= NULL,
		  @SummationProduction Int,
		  @NoOfLoads INT,@prevDay INT,@Rollingcount int = 1        
		 ,@RowCount int = NULL,@RealDayId Int,@ShiftCount Int = 1,@LabourShift int
		 ,@EcolabAccountNumber NVARCHAR(25) = NULL
		
		--SELECT * FROM TCD.WeekDay  SELECT DATENAME(dw,@Date) 

    SELECT @DayId = DayId FROM [TCD].WeekDay WITH (NOLOCK) WHERE DayName = DATENAME(dw,@Date) 

    SELECT @prevDay = CASE WHEN @DayId = 1 THEN 7 ELSE @DayId - 1 END

	SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant 

    DECLARE @BatchShiftTable TABLE
						(
						  RowNumber int IDENTITY(1,1),
						  BatchUTCStartDate datetime,
						  BatchUTCEndDate datetime,
						  ShiftId int
						)

    DECLARE @Result TABLE
				    (
				    StartDate Datetime,
				    EndDate Datetime,
				    ShiftId INT,
				    ShiftName Varchar(1000),
				    DayID Int,
				    TargetProduction [decimal](18,2)
				    )

    DECLARE @shiftdata_temp TABLE
						  (
						  SNo INT IDENTITY(1,1),
						  [ShiftId] [int],
						   [ShiftName] [nvarchar](1000) ,
						   [DayId] [int] ,
						   [StartTime] [time](7) ,
						   [EndTime] [time](7) ,
						   [TargetProduction] [decimal](18, 2) ,
						   [Is_Deleted] [bit] ,
						   [EcolabAccountNumber] [nvarchar](1000) ,
						   [LastModifiedByUserId] [int] ,
						   [LastModifiedTime] [datetime] ,
						   [LastSyncTime] [datetime],
						   [TargetProduction_Display] [decimal](18, 2) 
						   )        
      INSERT INTO @shiftdata_temp
     Select 
		    [ShiftId] ,           
		    [ShiftName],		
		    [DayId],              
		    [StartTime],          
		    [EndTime],            
		    [TargetProduction] , 
		    [Is_Deleted],        
		    [EcolabAccountNumber],
		    [LastModifiedByUserId],
		    [LastModifiedTime],	
		    [LastSyncTime],
		    [TargetProduction_Display]		
	 FROM TCD.ShiftData WITH (NOLOCK) WHERE (DayId = @DayId OR (DayId = @prevDay AND (EndTime < StartTime OR EndTime = StartTime))) AND IS_Deleted = 0  
	 ORDER BY DayId


	 UPDATE @shiftdata_temp SET DayId = CASE WHEN @DayId = 1 THEN 0 ELSE DayId END WHERE DayId = 7
	 UPDATE @shiftdata_temp SET DayId = CASE WHEN @DayId = 7 THEN 8 ELSE DayId END WHERE DayId = 1

	 SELECT @RowCount = SNo FROM @shiftdata_temp 

	 WHILE(@Rollingcount <=  @RowCount)        
    BEGIN        
			DECLARE @VALIDSTART DATETIME,@VALIDEND DATETIME    
		    SELECT @VALIDSTART = CASE WHEN DayId > @DayId THEN  DATEADD(day, DATEDIFF(day, -1, @Date), CAST(starttime AS datetime))
								 WHEN DayId < @DayId THEN   DATEADD(day, DATEDIFF(day, 1, @Date), CAST(starttime AS datetime)) 
														ELSE
														 DATEADD(day, DATEDIFF(day, 0, @Date), CAST(starttime AS datetime)) END		    ,
				   @VALIDEND =  CASE WHEN ((DayId > @DayId AND EndTime > StartTime) OR (DayId = @DayId AND (EndTime = StartTime OR EndTime < StartTime))) THEN 
													   DATEADD(day, DATEDIFF(day,-1, @Date), CAST(EndTime AS datetime))
								 WHEN (DayId < @DayId AND (EndTime < StartTime OR EndTime = StartTime)) THEN 
													    DATEADD(day, DATEDIFF(day, 0, @Date), CAST(EndTime AS datetime))
								 WHEN (DayId > @DayId AND (EndTime < StartTime OR EndTime = StartTime)) THEN 
												    	  DATEADD(day, DATEDIFF(day,-2, @Date), CAST(EndTime AS datetime))						 
								 					   ELSE
														  DATEADD(day, DATEDIFF(day, 0, @Date), CAST(EndTime AS datetime)) 
														  END,@ShiftId = ShiftId,@ShiftName = ShiftName,@RealDayId = DayId,@ShiftTargetProd = TargetProduction
					    FROM @shiftdata_temp WHERE SNo = @Rollingcount 

					    INSERT INTO @Result(StartDate,EndDate,ShiftId,ShiftName,DayID,TargetProduction)
					    SELECT @VALIDSTART,@VALIDEND,@ShiftId,@ShiftName,@RealDayId,@ShiftTargetProd

		        
			SET @Rollingcount = @Rollingcount + 1        
    END        

	
    SELECT DISTINCT @StartTime = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(StartDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(StartDate AS time)) AS DateTime)),
				@EndTime = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(EndDate AS time)) AS DateTime)),
				@ShiftId = ShiftId,@ShiftName = ShiftName,@DayId = DayID,@ShiftTargetProd = TargetProduction  FROM @Result
			WHERE @Date BETWEEN StartDate AND EndDate

    SELECT @LabourShift = @ShiftId

     IF(@StartTime IS NULL AND @EndTime IS NULL)
    BEGIN
	SELECT @ShiftId = NULL,@ShiftName = NULL
    END
   
		  IF(COUNT(@ShiftId) <> 1)      ---NO shift Timings
	   BEGIN
			 SELECT TOP 1 @StartTime = EndTime FROM [TCD].ShiftData WITH (NOLOCK)
				WHERE DayId = @DayId 
					AND Is_Deleted = 0
					AND EndTime < CONVERT(TIME, CONVERT(VARCHAR(20), @Date, 120)) ORDER BY EndTime
			
			 SELECT TOP 1 @EndTime = StartTime  FROM [TCD].ShiftData WITH (NOLOCK)
				WHERE DayId = @DayId 
					AND Is_Deleted = 0
					AND CONVERT(TIME, CONVERT(VARCHAR(20), @Date, 120)) < StartTime ORDER BY StartTime	
					
					IF(COUNT(@StartTime) <> 1)
					   BEGIN
						  SELECT @StartTime = CAST(dateadd(DAY, datediff(day, 0, @Date),0) AS dateTime)
					   END
						  ELSE
					   BEGIN
						  SELECT @StartTime = DATEADD(day, DATEDIFF(day, 0, @Date),@StartTime)
					   END

				    IF(COUNT(@EndTime) <> 1)
					   BEGIN
						  SELECT @EndTime =  CAST(DATEADD(s, -1, DATEADD(day, 1,CONVERT(DATETIME, CONVERT(DATE, @Date)))) AS dateTime)
					   END
						  ELSE
					   BEGIN
						  SELECT @EndTime = DATEADD(day, DATEDIFF(day, 0, @Date),@EndTime)
					   END

		    SET @StartTime = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@StartTime AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@StartTime AS time)) AS DateTime))
		    SET @EndTime = 	dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndTime AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndTime AS time)) AS DateTime))		  

	   END    	    
	   
 		  --SET @ShiftId = CASE WHEN COUNT(@ShiftId) <> 1 THEN 0 ELSE @ShiftId END
		        ----- Inserting the meta data into shift production base table -------

      ----------------/* Getting the Target Production from TargetProduction details if exists else in shift data page */---------------

    IF ((SELECT COUNT(1) FROM TCD.TARGETPRODUCTIONDETAILS AS T WITH (NOLOCK) WHERE DayId = @DayId AND T.ShiftId = @ShiftId) = 1)
	   BEGIN
		  SELECT @ShiftTargetProd = TPD.TargetProduction FROM TCD.TARGETPRODUCTIONDETAILS TPD  WITH (NOLOCK)
					   WHERE DayId = @DayId 
							 AND TPD.ShiftId = @ShiftId
	   END
	   
		 EXEC [TCD].[GetDayLightDate] @StartTime OUT
		 EXEC [TCD].[GetDayLightDate] @EndTime OUT
		
		 IF NOT EXISTS (SELECT 1 FROM [TCD].ProductionShiftData WITH (NOLOCK) WHERE StartDateTime = @StartTime )
		 BEGIN
				--DECLARE @Count INt 
				--SELECT @Count = MAX(ShiftId) FROM [TCD].ProductionShiftData WITH (NOLOCK)

			 INSERT INTO [TCD].ProductionShiftData (
												 --[ShiftId],
												 [ShiftName],
												 [StartDateTime],
												 [EndDateTime],
												 [TargetProduction],
												 [EcolabAccountNumber]
											 ) 
			  SELECT  --CASE WHEN COUNT(@Count) <> 1 THEN 1 ELSE @Count + 1 END,
				    CASE WHEN COUNT(@ShiftName) <> 1 THEN 'No Shift' ELSE @ShiftName END,
				    @StartTime,
				    @EndTime,
				    0,
					@EcolabAccountNumber
				    
				    			
		  END

			
	 SELECT TOP 1
				@BatchUTCStart = StartDateTime,
			    @BatchUTCEnd =  EndDateTime,
			     @ShiftId = ShiftId			   
					FROM [TCD].ProductionShiftData SD WITH (NOLOCK) WHERE CAST(SD.StartDateTime AS DATE) = CAST(@StartTime AS DATE)
					   ORDER BY SD.StartDateTime DESC 
					  


    DECLARE @BatchSummary TABLE
				(
				   RowNumber Int,
				   BatchId Int,
				   ActualWeight float,
				   StandardWeight float,
				   MachineId Int,
				   EcolabWasherId Int,
				   StartDate datetime2,
				   EndDate datetime2,
				   ProgramNumber Int,
				   ProgramMasterId Int,
				   CustomerId Int,
				   PiecesCount int,
				   ManualInputWeight float,
				   TargetTurnTime INT,
				   EcolabTextileId INT,
				   ChainTextileId  INT ,
				   PlantProgaramId INT
				)

    INSERT INTO @BatchSummary
		(
			RowNumber ,
			BatchId ,
			ActualWeight ,
			StandardWeight ,
			MachineId ,
			EcolabWasherId ,
			StartDate ,
			EndDate ,
			ProgramNumber ,
			ProgramMasterId ,
			CustomerId ,
			PiecesCount ,
			ManualInputWeight ,
			TargetTurnTime ,
			EcolabTextileId ,
			ChainTextileId   ,
			PlantProgaramId 
		 )
	   SELECT 
				  ROW_NUMBER() OVER(PARTITION BY BD.MachineId ORDER BY BD.StartDate) RowNumber,
				   BD.BatchId,
				   ActualWeight,
				   StandardWeight,
				   MachineId,
				   BD.EcolabWasherId,
				   StartDate,
				   EndDate,
				   ProgramNumber,
				   ProgramMasterId,
				   BCD.CustomerId,
				   BCD.PiecesCount,
				   BD.ManualInputWeight,
				   BD.TargetTurnTime,
				   BD.EcolabTextileCategoryId,
				   BD.ChainTextileCategoryId,
				   BD.PlantProgramId
			 FROM TCD.BatchData BD WITH (NOLOCK)
					   INNER JOIN TCD.MachineSetup MS WITH (NOLOCK) ON MS.WasherId = BD.MachineId 
				    LEFT OUTER JOIN 
				 TCD.BatchCustomerData BCD WITH (NOLOCK) ON BD.BatchId = BCD.BatchId
			  WHERE BD.EndDate >= @BatchUTCStart AND BD.EndDate <= @BatchUTCEnd 

	   
	------------------******// Inserting the Data into Chemical temp table  //******-----------------------

	 DECLARE @BatchChemicalSummary TABLE
				(
				   BatchId Int,
				   EcolabWasherId Int,
				   StartDate datetime2,
				   EndDate datetime2,
				   MachineId Int,
				   ProgramMasterId Int,
				   ProductId Int,
				   ActualQuantity Decimal(18,2),
				   StandardQuantity Decimal(18,2),
				   Price Decimal(18,2),
				   CustomerId Int,
				   EcolabTextileId INT,
				   ChainTextileId  INT ,
				   PlantProgaramId INT				  			   
				)

    INSERT INTO @BatchChemicalSummary
		(
			BatchId ,
			EcolabWasherId ,
			StartDate ,
			EndDate ,
			MachineId ,
			ProgramMasterId ,
			ProductId ,
			ActualQuantity ,
			StandardQuantity,
			Price ,
			CustomerId ,
			EcolabTextileId ,
			ChainTextileId   ,
			PlantProgaramId 				  			   
		)
	   SELECT 
				   BD.BatchId,
				   BD.EcolabWasherId,
				   StartDate,
				   EndDate,
				   MachineId,
				   ProgramMasterId,
				   BPD.ProductId,
				   BPD.ActualQuantity,
				   BPD.StandardQuantity,
				   BPD.Price,
				   BCD.CustomerId,
				   BD.EcolabTextileCategoryId,
				   BD.ChainTextileCategoryId,
				   BD.PlantProgramId
			 FROM  TCD.BatchProductData BPD	WITH (NOLOCK)				   
					   LEFT JOIN TCD.BatchData BD WITH (NOLOCK) ON BD.BatchId = BPD.BatchId
					   LEFT JOIN TCD.MachineSetup MS WITH (NOLOCK) ON MS.WasherId = BD.MachineId
					   LEFT JOIN TCD.ProductMaster PD WITH (NOLOCK) ON PD.ProductId = BPD.ProductId
					   LEFT JOIN  TCD.BatchCustomerData BCD WITH (NOLOCK) ON BD.BatchId = BCD.BatchId
					   WHERE BD.EndDate >= @BatchUTCStart AND BD.EndDate <= @BatchUTCEnd

	    SELECT @NoOfLoads = COUNT(DISTINCT BatchId) FROM @BatchSummary
  
	------------------******// Inserting the Data into Machine Efficiency Temp table for runtimes based on machines //******-----------------------

	

	DECLARE @MachineEfficency TABLE
					   ( 
						  MachineId INT,
						  ProgramMasterId INT,
						  ActualRunTime INT, 
						  StandardRunTime INT,
						  ActualTurnTime INT,
						  StandardTurnTIme INT
					   )

     INSERT INTO @MachineEfficency
					   ( 
						  MachineId,
						  ProgramMasterId,
						  ActualRunTime , 
						  StandardRunTime,
						  ActualTurnTime,
						  StandardTurnTIme
					   )
	   SELECT 
			DISTINCT
			  CUR.MachineId,CUR.ProgramMasterId,	   
			 CAST(SUM(DATEDIFF(SECOND,CUR.StartDate,CUR.EndDate)) AS decimal(18,2)),
			 ISNULL(SUM(WPS.TotalRunTime),1),--+ @ConStdTurnTime + ISNULL(SUM(WPS.ExtraTime),1),
			 ISNULL(SUM( CASE WHEN DATEDIFF(SECOND,CUR.EndDate,nexting.StartDate) < 0 THEN 0 ELSE  DATEDIFF(SECOND,CUR.EndDate,nexting.StartDate) END),1),
			 ISNULL(SUM(CUR.TargetTurnTime),1)
	    FROM @BatchSummary CUR 
				LEFT OUTER JOIN @BatchSummary nexting ON cur.RowNumber = nexting.RowNumber - 1 AND CUR.MachineId = nexting.MachineId --AND CUR.ProgramMasterId = nexting.ProgramMasterId
				INNER JOIN TCD.MachineSetup MS WITH (NOLOCK) ON MS.WasherId = CUR.MachineId AND MS.IsTunnel = 0 AND MS.IsDeleted = 0
				LEFT JOIN TCD.WasherProgramSetup WPS WITH (NOLOCK) ON WPS.ProgramId = CUR.ProgramMasterId AND MS.GroupId = WPS.WasherGroupId AND WPS.Is_Deleted = 0
				GROUP BY CUR.MachineId,CUR.ProgramMasterId
	   UNION ALL

	   SELECT 
			DISTINCT
			CUR.MachineId,CUR.ProgramMasterId,
			 CAST(SUM(DATEDIFF(SECOND,CUR.StartDate,CUR.EndDate)) AS decimal(18,2)),			
			 ISNULL(SUM(TPS.TotalRunTime),1),
				SUM(COALESCE(3600/NULLIF(COALESCE(DATEDIFF(SECOND,CUR.StartDate,CUR.EndDate)/ NULLIF(MS.NumberOfComp,0),0) ,0), 0)) ,
			 SUM(COALESCE(3600/NULLIF(COALESCE(TPS.TotalRunTime/ NULLIF(MS.NumberOfComp,0),0) ,0), 0)) --+ ISNULL(SUM(TPS.ExtraTime),1)
	   FROM @BatchSummary CUR
				INNER JOIN TCD.MachineSetup MS WITH (NOLOCK) ON MS.WasherId = CUR.MachineId  AND MS.IsTunnel = 1 AND MS.IsDeleted = 0
				        LEFT JOIN TCD.TunnelProgramSetup TPS WITH (NOLOCK) ON TPS.ProgramId = CUR.ProgramMasterId AND MS.GroupId = TPS.WasherGroupId AND TPS.Is_Deleted = 0
		  GROUP BY CUR.MachineId,CUR.ProgramMasterId

	--------------------------******// Inserting the Data into production Shift Rollup Data Table //******-------------------
	      		  
		 
	     DELETE FROM [TCD].ShiftProductionDataRollup WHERE ShiftId = @ShiftId 
		 
		  INSERT INTO [TCD].ShiftProductionDataRollup
							 (
								ShiftId,
								MachineId,
								ProgramMasterId,
								EcolabWasherId,
								NoOfLoads,
								ActualProduction ,
								StandardProduction,
								LoadEfficiency,
								TimeEfficiency,
								PlantTargetProd ,
								ActualRunTime,
								TargetRunTime,
								EcolabTextileId,
								ChainTextileId,
								ChainProgaramId,
								CustomerId,
								NoOfPieces,
								ActualTurnTime,
								TargetTurnTime
							 )	
							 
		  SELECT 
				DISTINCT
					 @ShiftId,
				      CUR.MachineId,
					 CUR.ProgramMasterId,
					 CUR.EcolabWasherId,
					 COUNT(1),
					 SUM(CUR.ActualWeight) + ISNULL(SUM(CUR.ManualInputWeight),0),
					 SUM(CUR.StandardWeight),
					 CAST(COALESCE(((SUM(CUR.[ActualWeight]))/ NULLIF(ISNULL(SUM(CUR.[StandardWeight]),SUM(CUR.[ActualWeight])),0)), 0) AS decimal(18,2)),
					 CAST(COALESCE(CAST(SUM(ME.StandardRunTime) AS Decimal(18,2))/ NULLIF(ISNULL(CAST(SUM(ME.ActualRunTime) AS decimal(18,2)),CAST(SUM(ME.ActualRunTime) AS Decimal(18,2))),0), 0) AS decimal(18,2)) ,
			 		 @ShiftTargetProd * 1000,					 
					 COALESCE(SUM(ME.ActualRunTime) / NULLIF(COUNT(1),0), 0), 
					 COALESCE(ISNULL(SUM(ME.StandardRunTime),SUM(ME.ActualRunTime))/ NULLIF(COUNT(1),0), 0), 
					 --ETC.TextileId,CTC.TextileId,PCP.PlantProgramId,
					 CUR.EcolabTextileId,CUR.ChainTextileId,CUR.PlantProgaramId,
					 CUR.CustomerId,
				      SUM(CUR.PiecesCount),
					 COALESCE(SUM(ME.ActualTurnTime) / NULLIF(COUNT(1),0), 0),
					 COALESCE(ISNULL(SUM(ME.StandardTurnTIme),SUM(ISNULL(ME.ActualRunTime,0)))/ NULLIF(COUNT(1),0), 0)
							 FROM 
					   @BatchSummary CUR 
						  LEFT JOIN 
								@MachineEfficency ME ON CUR.MachineId = ME.MachineId AND CUR.ProgramMasterId = ME.ProgramMasterId
						  LEFT JOIN 
								 TCD.ProgramMaster PM WITH (NOLOCK) ON PM.ProgramId = CUR.ProgramMasterId
						/*
						  LEFT JOIN
								TCD.EcolabTextileCategory ETC WITH (NOLOCK) ON ETC.TextileId = PM.EcolabTextileCategoryId
						  LEFT JOIN
								TCD.ChainTextileCategory CTC WITH (NOLOCK) ON  CTC.TextileId = PM.ChainTextileId
						  LEFT JOIN
								TCD.PlantChainProgram PCP ON PCP.PlantProgramId = PM.PlantProgramId
						*/
						  GROUP BY CUR.MachineId,CUR.EcolabWasherId,CUR.ProgramMasterId,--ETC.TextileId,CTC.TextileId,PCP.PlantProgramId,
						  CUR.EcolabTextileId,CUR.ChainTextileId,CUR.PlantProgaramId,
						  CUR.CustomerId


	   --------------------------******// Inserting the Data into Chemical Shift Rollup Data Table //******-------------------
	  	  
		 
	      DELETE FROM [TCD].[ShiftChemicalDataRollup] WHERE ShiftId = @ShiftId 

		 INSERT INTO [TCD].[ShiftChemicalDataRollup]
							 (
								 [ShiftId] ,
								 [MachineId],
								 [ProgramMasterId],
								 [EcolabWasherId],
								 [ProductId],
								 [ActualConsumption],
								 [TargetConsumption],
								 [ActualCost],
								 [EcolabTextileId],
								 [ChainTextileId],
								 [ChainProgaramId],
								 [CustomerId],
								 NoOfLoads
							 )
				SELECT
				    DISTINCT 
						  @ShiftId,
						  CUR.MachineId,
						  CUR.ProgramMasterId,
						  CUR.EcolabWasherId,
						  CUR.ProductId,
						  SUM(CUR.ActualQuantity),
						  SUM(CUR.StandardQuantity),
						  SUM(CUR.Price),
						  --ETC.TextileId,CTC.TextileId,PCP.PlantProgramId,
						  CUR.EcolabTextileId,
						  CUR.ChainTextileId,
						  CUR.PlantProgaramId,
						  CUR.CustomerId,
						  @NoOfLoads
						  FROM 
						  @BatchChemicalSummary CUR 
						   LEFT JOIN 
								 TCD.ProgramMaster PM WITH (NOLOCK) ON PM.ProgramId = CUR.ProgramMasterId
						  /*
						  LEFT JOIN
								TCD.EcolabTextileCategory ETC WITH (NOLOCK) ON ETC.TextileId = PM.EcolabTextileCategoryId
						  LEFT JOIN
								TCD.ChainTextileCategory CTC WITH (NOLOCK) ON  CTC.TextileId = PM.ChainTextileId
						  LEFT JOIN
								TCD.PlantChainProgram PCP WITH (NOLOCK) ON PCP.PlantProgramId = PM.PlantProgramId
						  */
						  GROUP BY CUR.MachineId,CUR.EcolabWasherId,CUR.ProgramMasterId,CUR.ProductId,CUR.CustomerId,--ETC.TextileId,CTC.TextileId,PCP.PlantProgramId
						  CUR.EcolabTextileId,CUR.ChainTextileId,CUR.PlantProgaramId


			 IF NOT EXISTS (SELECT 1 FROM TCD.[ProductionShiftLaborData] WHERE ShiftId = @ShiftId)
				 BEGIN
				    INSERT INTO [TCD].[ProductionShiftLaborData]
					   SELECT  @ShiftId,
							 SLD.LaborTypeId,
							 SLD.LaborHours,
							 SLD.LaborHours * SLD.PricePerHr
								    FROM [TCD].[ShiftLaborData] SLD WITH (NOLOCK) WHERE ShiftId = @LabourShift AND DayId = @DayId
				END
EXEC [TCD].[ReportBatchStepWaterAndEnergyRollup];
SET NOCOUNT OFF	  
END