﻿CREATE PROCEDURE [TCD].[ProcessMyControlWandEDigitalData](
 @ControllerID   INT,
 @xmlTags        XML,
 @IsOnline       BIT
 )
AS
BEGIN

DECLARE @BatchID  INT,
@MeterId          INT,
@CurrentDayReading  DECIMAL(18,4) = 0.0,
@CurrentDayRunTime  INT,
@PreviousDayReading DECIMAL(18,4),
@PreviousDayRuntime INT,
@CurrentDate        DATETIME,
@PrevoiusDate       DATETIME,
@WasherGroupID    INT,
@DigitalInputNumber  INT,
@CurrentCounter     INT,
@PartitionOn        DATETIME,
@ModuleCount        INT,
@WandECount         INT



 CREATE TABLE #WaterEnergyLoggerData
     (
	   Number                    INT,
      CurrentDayReading          DECIMAL(18,4),
      CurrentDayRunTime          INT,
      PreviousDayReading         DECIMAL(18,4),
      PreviousDayRuntime         INT,
	  CurrentDate                VARCHAR(50),
	  PrevoiusDate               VARCHAR(50)
     );
     INSERT INTO #WaterEnergyLoggerData
     (
	  Number,
	  CurrentDayReading,
      CurrentDayRunTime,
      PreviousDayReading,
      PreviousDayRuntime,
      CurrentDate,
      PrevoiusDate)
    SELECT T.c.value('@InputNumber','INT') AS Number,
	 T.c.value('@CurrentDayReading', 'DECIMAL(18,4)') AS CurrentReading, --CurrentDayReading
       T.c.value('@CurrentDayRunTime', 'INT') AS CurrentTime, --CurrentDayRunTime
       T.c.value('@PreviousDayReading', 'DECIMAL(18,4)') AS PreviousReading, --PreviousDayReading
       T.c.value('@PreviousDayRuntime', 'INT') AS PreviousRuntime, --PreviousDayRuntime
	   T.c.value('@CurrentDate','VARCHAR(50)') AS CurrentDate,
	   T.c.value('@PrevoiusDate','VARCHAR(50)') AS PrevoiusDate
    FROM @xmlTags.nodes('MyControlWaterEnergyLoggerData/DigitalInputData/DigitalData') T(C);

	SET @CurrentCounter=1;
	WHILE(@CurrentCounter<=32)
	BEGIN
	SELECT @MeterID=MeterId
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.ControllerID=@ControllerID 
   AND mt.DigitalInputNumber=@CurrentCounter

   SELECT @DigitalInputNumber=weld.Number,
   @CurrentDayReading=weld.CurrentDayReading,
   @CurrentDayRunTime=weld.CurrentDayRunTime,
   @PreviousDayReading=weld.PreviousDayReading,
   @PreviousDayRuntime=weld.PreviousDayRuntime,
   @CurrentDate=CONVERT(DATETIME,weld.CurrentDate),
   @PrevoiusDate=CONVERT(DATETIME,weld.PrevoiusDate)
   FROM #WaterEnergyLoggerData weld where Number=@CurrentCounter
    DECLARE @ShiftMapping TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    INSERT INTO @ShiftMapping
	    (
		  ShiftId,
		  ShiftName,
		  ShiftStartdate
	    )
	    EXEC TCD.GetShiftStartDate
		    @CurrentDate
	    SELECT 
			 @PartitionOn= ShiftStartdate
	    FROM @ShiftMapping;
	--SET @MeterId=2

		IF ISNULL(@Meterid, 0) > 0
	   AND ISNULL(@Digitalinputnumber, 0) > 0
	   AND ISNULL(@Currentdayreading, 0) > 0
	   AND ISNULL(@Currentdate, 0) > 0
			BEGIN
				SELECT
						@Modulecount = COUNT(1)
					FROM TCD.ModuleReading
					WHERE ModuleId = @Meterid
					  AND Reading = @Currentdayreading;
				IF @Modulecount = 0
				        BEGIN
                            IF @Isonline <> 1
                                BEGIN
                                    INSERT INTO TCD.ModuleReading(
                                            ModuleId, 
                                            ModuleTypeId, 
                                            Reading, 
                                            TimeStamp, 
                                            PartitionOn,
											ShiftId)
                                    SELECT
                                            @Meterid, 
                                            2, 
                                            @Currentdayreading, 
                                            @Currentdate, 
                                            @Partitionon,
											(SELECT DISTINCT TOP 1
                                                     ShiftId FROM @Shiftmapping);
                                END;
                            ELSE
                                BEGIN
                                    DECLARE @Prevreading DECIMAL(18,4) = 0.0;
									DECLARE @Usage DECIMAL(18,4) = 0.0;
                                    DECLARE @Prevreadingdate DATE;
                                    SELECT TOP 1
                                            @Prevreading = ISNULL(mr.Reading,0), 
                                            @Prevreadingdate = mr.TimeStamp
                                        FROM TCD.ModuleReading AS mr
										WHERE mr.ModuleId = @Meterid
                                        ORDER BY
                                            mr.TimeStamp DESC;
									SET @Usage=(@Currentdayreading - @Prevreading)
									--If usage is greater than 0 then only insert a record
									IF (@Usage)>0
									BEGIN
										INSERT INTO TCD.ModuleReading(
												ModuleId, 
												ModuleTypeId, 
												Reading, 
												TimeStamp, 
												Usage, 
												PartitionOn, 
												ShiftId)
										SELECT
												@Meterid, 
												2, 
												@Currentdayreading, 
												@Currentdate, 
												CASE
													WHEN (@Prevreadingdate <> CONVERT(DATE,@CurrentDate)) or @Prevreading IS NULL THEN @Currentdayreading
													ELSE @Currentdayreading - @Prevreading
												END, 
												@Partitionon, 
												(SELECT DISTINCT TOP 1
															ShiftId FROM @Shiftmapping);
									END
                                END;
                        END;
	END;

   IF(ISNULL(@MeterId,0)>0 AND ISNULL(@CurrentDayRunTime,0)>0)
   BEGIN
   SELECT @WandECount=COUNT(1) from TCD.WaterAndEnergyConsumptionLog WHERE MeterId=@MeterId AND Value=@CurrentDayRunTime
   IF(@WandECount=0)
   BEGIN
   INSERT INTO TCD.WaterAndEnergyConsumptionLog
   (MeterId,Value,CreatedDate)
   SELECT @MeterId,@CurrentDayRunTime,GETUTCDATE() 
   END
   END
   IF(ISNULL(@MeterId,0)>0 AND ISNULL(@PreviousDayRuntime,0)>0)
   BEGIN
    SELECT @WandECount=COUNT(1) from TCD.WaterAndEnergyConsumptionLog WHERE MeterId=@MeterId AND Value=@PreviousDayRuntime
   IF(@WandECount=0)
   BEGIN
   INSERT INTO TCD.WaterAndEnergyConsumptionLog
   (MeterId,Value,CreatedDate)
   SELECT @MeterId,@PreviousDayRuntime,GETUTCDATE() 
   END
   END
    SET @CurrentCounter=@CurrentCounter+1;
   END
END