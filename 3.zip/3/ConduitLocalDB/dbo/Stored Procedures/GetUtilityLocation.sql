﻿/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_GetUtilityLocation]                                         

Purpose:				To Get the utility location.
																												
###################################################################################################                                           
*/
CREATE PROCEDURE [TCD].[GetUtilityLocation]
					@EcolabAccountNumber			NVARCHAR(25)	=	NULL		--Only to maintain a consistent signature; we don't use this param in Local
AS
BEGIN
SET nocount ON;

SET		@EcolabAccountNumber			=			ISNULL(@EcolabAccountNumber, NULL)			--SQLEnlight SA0029

SELECT DISTINCT GT.Id,GT.GroupDescription,GT.GroupTypeId,MS.IsTunnel
FROM   [TCD].MachineGroup GT LEFT OUTER JOIN [TCD].MachineSetup MS ON GT.Id = MS.GroupId  
WHERE GroupTypeId in (1,2) AND Is_Deleted = 0
SET nocount OFF;
END
