﻿
/*  
 ==========================================================================================  
 Purpose:  Using the entire application to fetch the specified langauge keys.  

 Author:  Premchand Yelavarthi  

 --------------------------------------------------------------  
 July-08-2014 ENT: Initial version.  
 ==========================================================================================  
*/ 
CREATE PROCEDURE [TCD].[GetSpecifiedLanguage] (
    @UserId int 
,   @Locale [NVARCHAR](50)
,	@EcolabAccountNumber [NVARCHAR](25)
) 
AS 
  BEGIN 
	  SET nocount ON; 

	 IF(@UserId = 0)
	 BEGIN
	SET @Locale = (SELECT lm.Locale FROM TCD.LanguageMaster lm WHERE lm.LanguageId = (SELECT p.LanguageId FROM TCD.Plant p) )
	END

		DECLARE @CurrencySymbol nvarchar(10) ='$'

	   IF @EcolabAccountNumber IS NULL OR @EcolabAccountNumber = ''
		BEGIN
			SELECT top(1) @CurrencySymbol = cs.CurrencySymbol  FROM TCD.CurrencySymbol cs WHERE cs.CurrencyCode = ( SELECT Top(1) p.CurrencyCode FROM TCD.Plant p)
		END
		ELSE
		BEGIN
			SELECT top(1) @CurrencySymbol = cs.CurrencySymbol  FROM TCD.CurrencySymbol cs WHERE cs.CurrencyCode = ( SELECT Top(1) p.CurrencyCode FROM TCD.Plant p WHERE p.EcolabAccountNumber = @EcolabAccountNumber)
		END

	   SELECT DISTINCT KeyMaster.[KeyName], 
			  REPLACE(ValueMaster.[Value], '#currency#',@CurrencySymbol) AS [Value]
	  FROM    [TCD].ResourceKeyMaster KeyMaster 
	  INNER JOIN [TCD].ResourceKeyValue ValueMaster On KeyMaster.[KeyName]=  ValueMaster.[KeyName]
	  INNER JOIN TCD.LanguageMaster lm ON lm.LanguageId = ValueMaster.LanguageId
	  WHERE  lm.Locale = @Locale 
  END 