/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_AddTunnelGroupWashStepFormula]                                             

Purpose:				To add the tunnel group wash steps formula.

Parameters:				@EcoLabAccountNumber - holds ecolab account number.
						@TunnelProgramSetupId - holds the tunnel program setup id.
						@UserId - holds the user id.
																
###################################################################################################                                           
*/
--This is to be called from the Add Formula step (for a Tunnel Washer Group ONLY) and NOT for the Add Wash Step UI/tab.
CREATE	PROCEDURE	[TCD].[AddTunnelGroupWashStepFormula]	(
					@EcoLabAccountNumber					NVARCHAR(25)
				,	@TunnelProgramSetupId					INT
				--,	@WasherGroupId							INT					--will fetch based on
				--,	@ProgramNumber							INT					--TPSId (added above)
				,	@UserId									INT
				,	@CompartmentStandardRunTime			    INT
				,	@LastModifiedTimestampAtCentral			DATETIME					=	NULL
				,	@OutputLastModifiedTimestampAtLocal		DATETIME					=	NULL	OUTPUT
)
AS

BEGIN

SET	NOCOUNT	ON

DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()

	,	@WasherGroupId					INT				=			NULL
	,	@ProgramNumber					INT				=			NULL
	,	@NumberOfCompartments			TINYINT			=			10			--this will be later determined based on one of the step that is missing -
																				--so far in the setup process (MachineSetup)
	,	@Counter						TINYINT			=			1
	,	@MyServiceCustFrmulaStpGUID		UNIQUEIDENTIFIER	=		NULL
	,	@TotalRunTime					INT

DECLARE
	@OutputList								AS	TABLE		(
	LastModifiedTimestamp					DATETIME
)

SET		@OutputLastModifiedTimestampAtLocal				=			ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight SA0121

SET		@LastModifiedTimestampAtCentral					=			ISNULL(@LastModifiedTimestampAtCentral, NULL)				--SQLEnlight SA0029

--TunnelDosingSetup

--Washer setup is now implemented; we can obtain the number of compartments for the tunnel associated to the Washer Group to which the formula is being associated
SELECT	@NumberOfCompartments		=			ISNULL(MS.NumberOfComp, 0)
FROM	[TCD].TunnelProgramSetup			TPS
JOIN	[TCD].MachineSetup				MS
	ON	TPS.WasherGroupId			=			MS.GroupId
WHERE	TPS.TunnelProgramSetupId	=			@TunnelProgramSetupId
	AND	TPS.Is_Deleted				=			'FALSE'
	AND	MS.IsDeleted				=			'FALSE'


--Get the WasherGroupId and ProgramNumber...
SELECT	@WasherGroupId				=			TPS.WasherGroupId
	,	@ProgramNumber				=			TPS.ProgramNumber
FROM	[TCD].TunnelProgramSetup			TPS
WHERE	TPS.EcolabAccountNumber		=			@EcoLabAccountNumber
	AND	TPS.TunnelProgramSetupId	=			@TunnelProgramSetupId


WHILE	(	@Counter	<=	@NumberOfCompartments	)
BEGIN
		SET @MyServiceCustFrmulaStpGUID = NEWID()	

		INSERT	INTO	[TCD].TunnelDosingSetup	(
						EcolabAccountNumber
					,	TunnelProgramSetupId
					,	GroupId
					,	ProgramNumber
					,	CompartmentNumber
					,   StepRunTime
					,	LastModifiedByuserId
					,	MyServiceCustFrmulaStpGUID
					)
			SELECT
						@EcoLabAccountNumber			AS			EcolabAccountNumber
					,	@TunnelProgramSetupId			AS			TunnelProgramSetupId
					,	@WasherGroupId					AS			GroupId
					,	@ProgramNumber					AS			ProgramNumber
					,	@Counter						AS			CompartmentNumber
					,   @CompartmentStandardRunTime		AS		    CompartmentStandardRunTime
					,	@UserId							AS			LastModifiedByuserId
					,	@MyServiceCustFrmulaStpGUID		AS			MyServiceCustFrmulaStpGUID

		SELECT @TotalRunTime=SUM(StepRunTime) FROM [TCD].TunnelDosingSetup WHERE GroupId=@WasherGroupId AND ProgramNumber=@ProgramNumber AND EcolabAccountNumber=@EcoLabAccountNumber AND Is_Deleted=0 

		UPDATE TCD.TunnelProgramSetup
			SET
			TotalRunTime=@TotalRunTime,	
			LastModifiedTime = @CurrentUTCTime
			OUTPUT
				inserted.LastModifiedTime		AS			LastModifiedTimestamp
			INTO
				@OutputList	(
				LastModifiedTimestamp
			)
			WHERE 
			TunnelProgramSetupId = @TunnelProgramSetupId
			AND
			EcolabAccountNumber = @EcolabAccountNumber
		
		--check for any error
		SET	@ErrorId	=	@@ERROR
	
		IF	(@ErrorId	<>	0)
			BEGIN
				SET		@ErrorMessage	=			N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred appending formula steps for the tunnel.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET		@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END

		--move to the next compartment
		SET	@Counter	=	@Counter + 1
END


SELECT	TOP 1	
		@OutputLastModifiedTimestampAtLocal		=	O.LastModifiedTimestamp
FROM	@OutputList							O

IF	(	@ErrorId	=	0	)
	BEGIN
		--GOTO	ExitModule
		RETURN	(@ReturnValue)
	END




--ErrorHandler:
--RAISERROR	(@ErrorMessage, 16, 1)
--SET	@ReturnValue	=	-1


--ExitModule:

SET	NOCOUNT	OFF
RETURN	(@ReturnValue)


END