﻿/*    
==========================================================================================    
Purpose:  INSERTING THE DRYER GROUPS DATA    
    
Author: Venkata Mohan Krishna K    
    
    
--------------------------------------------------------------    
Sep-09-2014 ENT: Initial version.    
==========================================================================================    
*/    
CREATE PROCEDURE [TCD].[SaveDryerGroups] (    
@GroupDescription  varchar(100),    
@EcolabAccountNumber nvarchar(25),    
@UserId Int,    
@Scope varchar(100) OUTPUT
	--Adding these 2 params as part of re-factoring for integration with Synch/Configurator
,	@OutputDryerGroupId					INT					=			NULL	OUTPUT
,	@OutputLastModifiedTimestampAtLocal	DATETIME			=			NULL	OUTPUT
)    
AS    
    
BEGIN    
SET NOCOUNT ON
DECLARE @Output Varchar(100) = ''    
    
DECLARE
		@OutputList						AS	TABLE		(
		DryerGroupId					INT
	,	LastModifiedTimestamp			DATETIME
	)

SET	@Scope										=			ISNULL(@Scope, NULL)								--SQLEnlight SA0121
SET	@OutputLastModifiedTimestampAtLocal			=			ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)	--SQLEnlight SA0121
SET	@OutputDryerGroupId							=			ISNULL(@OutputDryerGroupId, NULL)					--SQLEnlight SA0121


IF NOT EXISTS (SELECT 1    
FROM   [TCD].MachineGroup    
WHERE  GroupDescription = @GroupDescription and GroupTypeId = 3 and IS_DELETED <> 1)    
    
BEGIN    
    
INSERT INTO [TCD].MachineGroup(GroupDescription,GroupTypeId,EcolabAccountNumber,LastModifiedByUserId)    
--**	Adding as part of Audit re-factor to capture the User info.
OUTPUT
	inserted.Id			AS			DryerGroupId
,	inserted.LastModifiedTime		AS			LastModifiedTimestamp
INTO
	@OutputList	(
	DryerGroupId
,	LastModifiedTimestamp
)	--**
Values(@GroupDescription,3,@EcolabAccountNumber,@UserId)    
    
SET @OutPut = '101'    
SET @Scope = @OutPut SELECT @Scope    
    
END    
ELSE    
BEGIN    
SET @OutPut = '301'  
SET @Scope = @OutPut SELECT @Scope    
END    

IF @OutPut = '301'
	BEGIN
		SET		@OutputLastModifiedTimestampAtLocal			=			GETUTCDATE()
	END
ELSE
	BEGIN
		SELECT	TOP 1	
			@OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp
		,	@OutputDryerGroupId					=	O.DryerGroupId
		FROM	@OutputList							O
	END



SET NOCOUNT OFF


END
