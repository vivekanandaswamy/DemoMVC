CREATE PROCEDURE TCD.GetShiftSummaryDetails
AS
BEGIN
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
SET NOCOUNT ON;

DECLARE	@Washerdashboardid		INT,
		@Tunneldashboardid		INT,
		@Shiftname				NVARCHAR(1000) = NULL,
		@Actualloads			FLOAT,
		@Lostloads				FLOAT,
		@Efficiency			FLOAT,
		@Cummulativeefficiency	FLOAT,
		@Timeefficiencymaxcap	FLOAT,
		@Loadefficiencymaxcap	FLOAT,
		@Const_100				FLOAT = 100;

DECLARE	--@DashBoardId	int = 1,
		@Washerid				INT = NULL,
		@Standardturntime		INT = NULL,
		@Machinenamedispalytype	SMALLINT = 0,
		@Overnightbatchthreshold	INT = 7200,--Seconds
		@Efficiencytype			INT,
		@Regionid				INT;
	
SELECT
		@Regionid = RegionId
	FROM TCD.Plant;

SELECT
            @Timeefficiencymaxcap = CAST(Value AS FLOAT)
        FROM tcd.ConfigSettings
        WHERE KeyName = 'TimeEfficiencyMaxCapValue'
          AND TYPE = 'MAXCAP';

    SELECT
            @Loadefficiencymaxcap = CAST(Value AS FLOAT)
        FROM tcd.ConfigSettings
        WHERE KeyName = 'LoadEfficiencyMaxCapValue'
          AND TYPE = 'MAXCAP';


DECLARE	@Dashboardmachinemapping TABLE(
		Id				INT,
		GroupID			INT,
		WasherId		INT,
		WasherName		NVARCHAR(100),
		WasherNumber	INT,
		IsPLCConnected	BIT,
		DispenserName	VARCHAR(250));

DECLARE	@Batchendtimes TABLE(
		GroupID				INT,
		WasherID			INT,
		CurrentBatchEndTime	INT	NULL,
		BatchEndTime		TIME);
DECLARE	@Shiftids TABLE(
		ShiftId			INT,
		ShiftStartDate	DATETIME,
		ShiftEndDate	DATETIME,
		ShiftName		VARCHAR(50));
DECLARE	@Summarizeddata TABLE(
		GroupId			INT,
		MachineId		INT,
		WasherName		NVARCHAR(100),
		WasherNumber	INT,
		TargetLoad		FLOAT,
		ActualLoad		FLOAT,
		LoadEfficiency	FLOAT,
		TimeEfficiency	FLOAT,
		LostLoad		FLOAT,
		OverAllEfficiency	FLOAT);
	
INSERT INTO @Shiftids
		(
		ShiftId,
		ShiftStartDate,
		ShiftEndDate,
		ShiftName
		)
		SELECT DISTINCT
				ShiftId,
				StartDateTime,
				EndDateTime,
				ShiftName
			FROM TCD.ProductionShiftData
			--WHERE ShiftId=1 
			WHERE GETUTCDATE()BETWEEN StartDateTime AND EndDateTime;


SELECT
		* INTO
		#BatchData
	FROM tcd.BatchData AS bd(NOLOCK)
	WHERE bd.ShiftId IN(SELECT
								si.ShiftId FROM @Shiftids AS si)
		AND	bd.StandardWeight > 0
		AND	bd.ActualWeight > 0
		AND	bd.EndDate IS NOT NULL;

CREATE NONCLUSTERED INDEX IX_BatchDatatemp ON #BatchData(GroupId, ProgramNumber, ProgramMasterId, MachineId)INCLUDE(BatchId, EcolabWasherId,
StartDate, EndDate, ActualWeight, StandardWeight, ManualInputWeight, ShiftId, TargetTurnTime);	


--Efficiency for each batch
SELECT
		bd.BatchId,
		W_1.WasherGroupID AS GroupID,
		W_1.WasherId AS MachineID,
		bd.ShiftId,
		W_1.WasherNumber,
		W_1.WasherName,
		(bd.ActualWeight + ISNULL(BD.ManualInputWeight,0)) AS ActualProduction,
		bd.StandardWeight AS StandardProduction,
		CASE
			WHEN DATEDIFF(ss,bd.StartDate,ISNULL(bd.EndDate,GETDATE())) > @Overnightbatchthreshold THEN W_1.StandardRunTime
			ELSE DATEDIFF(ss,bd.StartDate,ISNULL(bd.EndDate,GETDATE()))
		END AS ActualRunTime,
		W_1.StandardRunTime,
		TT.ActualTurnTime,
		bd.TargetTurnTime AS StandardTurnTime,
		CASE
			WHEN W_1.WasherGroupTypeID = 1
		--	Conventional
		THEN CASE
			WHEN(CAST((W_1.Standardruntime + bd.TargetTurnTime) AS FLOAT)
			/ (CAST(CASE
					WHEN DATEDIFF(ss,bd.StartDate,ISNULL(bd.EndDate,GETDATE())) > @Overnightbatchthreshold THEN W_1.StandardRunTime
					ELSE DATEDIFF(ss,bd.StartDate,ISNULL(bd.EndDate,GETDATE()))
				END + CASE
						WHEN TT.ACTUALTURNTIME = 0 THEN ISNULL(bd.TargetTurnTime,0)
						ELSE ISNULL(TT.ACTUALTURNTIME,0)
					END AS FLOAT))) * @Const_100 >= @Timeefficiencymaxcap THEN @Timeefficiencymaxcap / @Const_100
			ELSE(CAST((W_1.Standardruntime + bd.TargetTurnTime) AS FLOAT)
			/	(CAST(CASE
					WHEN DATEDIFF(ss,bd.StartDate,ISNULL(bd.EndDate,GETDATE())) > @Overnightbatchthreshold THEN W_1.StandardRunTime
					ELSE DATEDIFF(ss,bd.StartDate,ISNULL(bd.EndDate,GETDATE()))
				END + CASE
						WHEN TT.ACTUALTURNTIME = 0 THEN ISNULL(bd.TargetTurnTime,0)
						ELSE ISNULL(TT.ACTUALTURNTIME,0)
					END AS FLOAT)))
				END	
		--	Tunnel 
			ELSE CASE
					WHEN((CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT))
			/	(CAST(CASE
								WHEN DATEDIFF(second,bd.StartDate,ISNULL(bd.EndDate,GETDATE())) = 0 THEN W_1.Standardruntime
								WHEN DATEDIFF(ss,bd.StartDate,ISNULL(bd.EndDate,GETDATE())) >@Overnightbatchthreshold THEN W_1.StandardRunTime
								ELSE DATEDIFF(ss,bd.StartDate,ISNULL(bd.EndDate,GETDATE()))
							END AS FLOAT))) * @Const_100 >= @Timeefficiencymaxcap THEN @Timeefficiencymaxcap / @Const_100
					ELSE ((CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT))
			/	(CAST(CASE
								WHEN DATEDIFF(second,bd.StartDate,ISNULL(bd.EndDate,GETDATE())) = 0 THEN W_1.Standardruntime
								WHEN DATEDIFF(ss,bd.StartDate,ISNULL(bd.EndDate,GETDATE())) >@Overnightbatchthreshold THEN W_1.StandardRunTime
								ELSE DATEDIFF(ss,bd.StartDate,ISNULL(bd.EndDate,GETDATE()))
							END AS FLOAT)))
				END
		END AS TimeEfficiency,
		CASE
			WHEN((CAST((bd.ActualWeight + ISNULL(BD.ManualInputWeight,0)) AS FLOAT) / CAST(NULLIF(bd.StandardWeight,0)AS FLOAT)) * 100) >= @Loadefficiencymaxcap THEN @Loadefficiencymaxcap
			ELSE((CAST((bd.ActualWeight + ISNULL(BD.ManualInputWeight,0)) AS FLOAT) / CAST(NULLIF(bd.StandardWeight,0)AS FLOAT)) * 100)
		END AS LoadEfficiency,
		CASE
			WHEN W_1.WasherGroupTypeID = 2 THEN(100 * ((3600.00
	 / (CAST(CASE
						WHEN DATEDIFF(second,bd.StartDate,ISNULL(bd.EndDate,GETDATE())) = 0 THEN NULLIF(W_1.Standardruntime,0)
						ELSE DATEDIFF(second,bd.StartDate,ISNULL(bd.EndDate,GETDATE()))
					END AS FLOAT) / W_1.NumberOfComp)) / (3600.00 / (CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT) / W_1.NumberOfComp))))
			ELSE NULL
		END AS TransferPerHr,
		--missedloads formulae
		--------(((Actual Production/totalefficiency)*100)-actualproduction)
		(CAST(CAST(bd.ActualWeight AS DECIMAL(18,6))
 / ((CASE
				WHEN((CAST((bd.ActualWeight + ISNULL(BD.ManualInputWeight,0)) AS FLOAT)
		 / CAST(NULLIF(bd.StandardWeight,0) AS FLOAT)) * 100) >= @Loadefficiencymaxcap THEN @Loadefficiencymaxcap
				ELSE((CAST((bd.ActualWeight + ISNULL(BD.ManualInputWeight,0)) AS FLOAT)
		 / CAST(NULLIF(bd.StandardWeight,0) AS FLOAT)) * 100)
			END)
	 * 
		(CASE
		WHEN W_1.WasherGroupTypeID = 1
		--	Conventional
	 THEN CASE
			WHEN(CAST((W_1.Standardruntime + bd.TargetTurnTime) AS FLOAT)
			 / (CAST(CASE
					WHEN DATEDIFF(ss,bd.StartDate,ISNULL(bd.EndDate,GETDATE())) > @Overnightbatchthreshold THEN W_1.StandardRunTime
					ELSE DATEDIFF(ss,bd.StartDate,ISNULL(bd.EndDate,GETDATE()))
					END + CASE
						WHEN TT.ACTUALTURNTIME = 0 THEN ISNULL(bd.TargetTurnTime,0)
						ELSE ISNULL(TT.ACTUALTURNTIME,0)
							END AS FLOAT))) * @Const_100 >= @Timeefficiencymaxcap THEN @Timeefficiencymaxcap / @Const_100
			ELSE(CAST((W_1.Standardruntime + bd.TargetTurnTime) AS FLOAT)
			 / (CAST(CASE
					WHEN DATEDIFF(ss,bd.StartDate,ISNULL(bd.EndDate,GETDATE())) > @Overnightbatchthreshold THEN W_1.StandardRunTime
					ELSE DATEDIFF(ss,bd.StartDate,ISNULL(bd.EndDate,GETDATE()))
					END + CASE
						WHEN TT.ACTUALTURNTIME = 0 THEN ISNULL(bd.TargetTurnTime,0)
						ELSE ISNULL(TT.ACTUALTURNTIME,0)
						END AS FLOAT)))
			END
	--	Tunnel
	ELSE CASE
		WHEN((CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT))
		 / (CAST(CASE
				WHEN DATEDIFF(second,bd.StartDate,ISNULL(bd.EndDate,GETDATE()))=0 THEN W_1.Standardruntime
				WHEN DATEDIFF(ss,bd.StartDate,ISNULL(bd.EndDate,GETDATE())) > @Overnightbatchthreshold THEN W_1.StandardRunTime
				ELSE DATEDIFF(ss,bd.StartDate,ISNULL(bd.EndDate,GETDATE()))
				END AS FLOAT))) * @Const_100 >= @Timeefficiencymaxcap THEN @Timeefficiencymaxcap / @Const_100
		ELSE((CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT))
		 / (CAST(CASE
				WHEN DATEDIFF(second,bd.StartDate,ISNULL(bd.EndDate,GETDATE())) = 0 THEN W_1.Standardruntime
				WHEN DATEDIFF(ss,bd.StartDate,ISNULL(bd.EndDate,GETDATE())) > @Overnightbatchthreshold THEN W_1.StandardRunTime
				ELSE DATEDIFF(ss,bd.StartDate,ISNULL(bd.EndDate,GETDATE()))
				END AS FLOAT)))
		END
		END)) AS DECIMAL(18,6)) * 100.0) - CAST(bd.ActualWeight AS DECIMAL(18,6)) AS MissedLoads,
((CASE
				WHEN((CAST((bd.ActualWeight + ISNULL(BD.ManualInputWeight,0)) AS FLOAT)
		 / CAST(NULLIF(bd.StandardWeight,0) AS FLOAT)) * 100) >= @Loadefficiencymaxcap THEN @Loadefficiencymaxcap
				ELSE((CAST((bd.ActualWeight + ISNULL(BD.ManualInputWeight,0)) AS FLOAT)
		 / CAST(NULLIF(bd.StandardWeight,0) AS FLOAT)) * 100)
			END)
	 * 
		(CASE
		WHEN W_1.WasherGroupTypeID = 1
		--Conventional
	 THEN CASE
			WHEN(CAST((W_1.Standardruntime + bd.TargetTurnTime) AS FLOAT)
			 / (CAST(CASE
					WHEN DATEDIFF(ss,bd.StartDate,ISNULL(bd.EndDate,GETDATE())) > @Overnightbatchthreshold THEN W_1.StandardRunTime
					ELSE DATEDIFF(ss,bd.StartDate,ISNULL(bd.EndDate,GETDATE()))
					END + CASE
						WHEN TT.ACTUALTURNTIME = 0 THEN ISNULL(bd.TargetTurnTime,0)
						ELSE ISNULL(TT.ACTUALTURNTIME,0)
							END AS FLOAT))) * @Const_100 >= @Timeefficiencymaxcap THEN @Timeefficiencymaxcap / @Const_100
			ELSE(CAST((W_1.Standardruntime + bd.TargetTurnTime) AS FLOAT) 
			 / (CAST(CASE
					WHEN DATEDIFF(ss,bd.StartDate,ISNULL(bd.EndDate,GETDATE())) > @Overnightbatchthreshold THEN W_1.StandardRunTime
					ELSE DATEDIFF(ss,bd.StartDate,ISNULL(bd.EndDate,GETDATE()))
					END + CASE
						WHEN TT.ACTUALTURNTIME = 0 THEN ISNULL(bd.TargetTurnTime,0)
						ELSE ISNULL(TT.ACTUALTURNTIME,0)
						END AS FLOAT)))
			END
	--	Tunnel
	ELSE CASE
		WHEN((CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT)) 
		 / (CAST(CASE
				WHEN DATEDIFF(second,bd.StartDate,ISNULL(bd.EndDate,GETDATE()))=0 THEN W_1.Standardruntime
				WHEN DATEDIFF(ss,bd.StartDate,ISNULL(bd.EndDate,GETDATE())) > @Overnightbatchthreshold THEN W_1.StandardRunTime
				ELSE DATEDIFF(ss,bd.StartDate,ISNULL(bd.EndDate,GETDATE())) 
				END AS FLOAT))) * @Const_100 >= @Timeefficiencymaxcap THEN @Timeefficiencymaxcap / @Const_100
		ELSE((CAST(NULLIF(W_1.Standardruntime,0) AS FLOAT)) 
		 / (CAST(CASE
				WHEN DATEDIFF(second,bd.StartDate,ISNULL(bd.EndDate,GETDATE())) = 0 THEN W_1.Standardruntime
				WHEN DATEDIFF(ss,bd.StartDate,ISNULL(bd.EndDate,GETDATE())) > @Overnightbatchthreshold THEN W_1.StandardRunTime
				ELSE DATEDIFF(ss,bd.StartDate,ISNULL(bd.EndDate,GETDATE()))
				END AS FLOAT)))
		END
		END)) AS TotalEfficiency,	
		W_1.MaxLoad	INTO
		#BatchEfficiency
	FROM #BatchData AS bd
			INNER JOIN TCD.WasherFormulaRunTimes AS W_1 ON BD.GroupId = W_1.WasherGroupID
															AND ISNULL(BD.EcolabWasherId,0) = ISNULL(W_1.EcolabWasherId,0)
															AND bd.MachineID = W_1.WasherId
															AND BD.ProgramMasterId = W_1.ProgramId
															AND BD.ProgramNumber = W_1.ProgramNumber
			LEFT JOIN [TCD].[Turntime] AS TT ON ISNULL(BD.EcolabwasherID,0) = ISNULL(TT.EcolabWasherId,0)
											AND BD.batchid = TT.BatchID
			LEFT JOIN TCD.ProductionShiftData AS psd ON psd.ShiftId = BD.ShiftId
	WHERE		
	'TRUE' = CASE
						WHEN W_1.WASHERGROUPTYPEID = 1 THEN CASE
																WHEN DATEDIFF(ss,bd.StartDate,bd.EndDate) > (W_1.Standardruntime * 10 / 100) THEN
																'TRUE'
																ELSE 'FALSE'
															END
						ELSE 'TRUE'
					END;

SELECT
		T.GroupID,
		T.MachineID AS MachineID,
		T.WasherNumber,
		T.WasherName,
		CAST(SUM(t.ActualProduction) AS FLOAT) AS ActualProduction,
		CAST(SUM(t.StandardProduction) AS FLOAT) AS StandardProduction,
		SUM(IIF(t.MissedLoads<0,0,t.MissedLoads)) AS MissedLoads,
		(CAST(SUM(t.LoadEfficiency) AS FLOAT) / COUNT(DISTINCT t.BatchId)) AS LoadEfficiency,
		((CAST(SUM(t.TimeEfficiency) AS FLOAT) / COUNT(DISTINCT t.BatchId))) AS TimeEfficiency,
	(CAST(SUM(T.StandardProduction * (T.LoadEfficiency * t.TimeEfficiency)) AS FLOAT) / CAST(SUM(T.StandardProduction) AS FLOAT)) AS TotalEfficiency,
		SUM(IIF(t.MissedLoads<0,0,t.MissedLoads)) / CASE
									WHEN MAX(t.MaxLoad) = 0 THEN 1
									ELSE MAX(t.MaxLoad)
								END AS LostBatches	INTO
		#MachineEfficiency
	FROM #BatchEfficiency AS t
	GROUP BY
		T.GroupID,
		T.MachineID,
		T.WasherNumber,
		T.WasherName;


--SELECT
--	 * FROM	@Shiftids;
--SELECT
--		be.*	FROM	dbo.#BatchEfficiency AS be;
--SELECT
--		me.*	FROM	dbo.#MachineEfficiency AS me;

INSERT INTO @Batchendtimes
		(
		GroupID,
		WasherID,
		CurrentBatchEndTime,
		BatchEndTime
		)
		SELECT
				d.GroupID,
				d.WasherId,
				COUNT(CASE
							WHEN bd.EndDate IS NULL THEN 1
							ELSE NULL
						END) AS CurrentBatchEndTime,
				CAST(MAX(bd.EndDate) AS TIME) AS BatchEndTime
			FROM @Dashboardmachinemapping AS d
				INNER JOIN TCD.BatchData AS bd ON d.GroupID = bd.GroupId
												AND d.WasherId = bd.MachineId
			WHERE bd.ShiftId IN(SELECT
										ShiftId FROM @Shiftids)
			GROUP BY
				d.GroupID,
				d.WasherId;
SELECT
		@Standardturntime = ISNULL(ConStdTurnTime,30) FROM tcd.Plant;
SELECT
		@Standardturntime = @Standardturntime + ISNULL(TargetTurnTime,0)
	FROM tcd.Washer
	WHERE WasherId = @Washerid;
SELECT
		@Machinenamedispalytype = ISNULL(MachineNameDispalyType,0)
	FROM TCD.Dashboard AS D;
--WHERE	D.DashboardId = @DashBoardId;
INSERT INTO @Summarizeddata
		(
		GroupId,
		MachineId,
		WasherName,
		WasherNumber,
		TargetLoad,
		ActualLoad,
		LoadEfficiency,
		TimeEfficiency,
		LostLoad,
		OverAllEfficiency
		)
		SELECT
				me.GroupID,
				me.MachineID,
				me.WasherName,
				me.WasherNumber,
				me.StandardProduction AS TargetLoad,
				me.ActualProduction AS ActulaLoad,
				me.LoadEfficiency,
				me.TimeEfficiency,
				me.MissedLoads AS LostLoad,
				me.TotalEfficiency AS TotalEfficiency
			FROM #MachineEfficiency AS me 
				LEFT JOIN @Batchendtimes AS be ON me.GroupID = be.GroupID
												AND me.MachineID = be.WasherID;


SELECT TOP 1
		@Shiftname = ShiftName FROM @Shiftids ORDER BY
		ShiftId;

DECLARE @Avg_Efficiency FLOAT;
WITH CTE_Avg_Efficiency
AS(
		--SELECT ((SUM(TargetLoad*OverAllEfficiency))/SUM(TargetLoad)) AS AVG_EFF FROM @Summarizeddata)
		SELECT
				((SUM((CASE
						WHEN(@Regionid = 1) THEN ISNULL(TargetLoad,0)
						ELSE ROUND((ISNULL(TargetLoad,0) * 0.453592),0)
					END) * OverAllEfficiency)) / SUM((CASE
															WHEN(@Regionid = 1) THEN ISNULL(TargetLoad,0)
															ELSE ROUND((ISNULL(TargetLoad,0) * 0.453592),0)
														END))) AS AVG_EFF
			FROM @Summarizeddata)
		SELECT
				@Avg_Efficiency = AVG_EFF FROM CTE_Avg_Efficiency;
	
SELECT
		SUM(ActualLoad) AS ActualLoad,
		@Avg_Efficiency AS Efficiency,
		SUM(LostLoad) AS LostLoad,
		ShiftName
	FROM(SELECT
					(CASE
						WHEN(@Regionid = 1) THEN ISNULL(ActualLoad,0)
						ELSE (ISNULL(ActualLoad,0) * 0.453592)
					END) AS ActualLoad,
					OverAllEfficiency AS Efficiency,
					ISNULL(@Shiftname,'No Shift Available') AS ShiftName,
					(CASE
						WHEN (@Regionid = 1) THEN ISNULL(LostLoad,0) 
						ELSE (ISNULL(LostLoad,0) * 0.453592)
				
					END) AS LostLoad
				FROM @Summarizeddata) AS A
	GROUP BY
		ShiftName;
	
----	CleanUp	
DROP TABLE
		#BatchData;
DROP TABLE
		#BatchEfficiency;
DROP TABLE
		#MachineEfficiency;

END;
