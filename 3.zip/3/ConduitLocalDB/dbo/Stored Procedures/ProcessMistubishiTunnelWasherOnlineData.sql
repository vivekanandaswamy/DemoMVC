﻿CREATE PROCEDURE [TCD].[ProcessMitsubishiTunnelWasherOnlineData](
	@ControllerID   INT,
	@xmlTags        XML,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    EXEC TCD.ProcessMitsubishiTunnelOnlineBatchData
		    @ControllerID,
		    @xmlTags;
	    CREATE TABLE #OnlineBatchData
	    (
		    ControllerID      INT,
		    CompartmentNumber INT,
		    BatchNumber       INT,
		    EcolabWasherID    INT,
		    GroupID           INT,
		    MachineInternalID INT,
		    MachineID         INT,
		    PlantWasherNumber INT,
		    StartDate         DATETIME2(7),
		    ProgramNumber     INT,
		    ProgramMasterID   INT,
		    CustomerNumber    NVARCHAR(50),
		    ActualWeight      INT,
		    StandardWeight    INT,
		    TransferSignal    BIT,
		    RunState          BIT,
		    CurrencyCode      VARCHAR(50)
	    );
	    CREATE TABLE #BatchData
	    (
		    CompartmentNO           INT,
		    ControllerBatchId       INT,
		    TargetTurnTime          INT,
		    StdInjectionSteps       INT,
		    StdWashSteps            INT,
		    EcolabTextileCategoryId INT,
		    ChainTextileCategoryId  INT,
		    FormulaSegmentId        INT,
		    EcolabSaturationId      INT,
		    PlantProgramId          INT,
		    ShiftId                 INT,
		    PartitionOn             DATETIME,
		    BatchID                 INT
	    );
	    CREATE TABLE #GetShiftDetails
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    CREATE TABLE #NewBatchIds
	    (
		    Batch_ID        INT,
		    Batch_Number    INT,
		    Machine_Id      INT,
		    Batch_Startdate DATETIME
	    );
	    CREATE TABLE #DosingDetails
	    (
		    Number          INT,
		    Quantity        DECIMAL(10, 6),
		    Point           INT,
		    IsMainEquioment INT,
		    IsDirectDosing  INT,
		    WasherGroupNum  INT,
		    CompartmentNO   INT
	    );
	    INSERT INTO #OnlineBatchData
	    SELECT
			 @ControllerID,
			 T.c.value('@CompartmentNumber', 'INT')     CompartmentNumber,
			 T.c.value('@BatchNumber', 'INT')           BatchNumber,
			 w.EcolabWasherID,
			 wg.WasherGroupId,
			 T.c.value('@MachineNumber', 'INT')         MachineNumber,
			 w.WasherId,
			 w.PlantWasherNumber,
			 T.c.value('@StartDateTime', 'DATETIME')    StartDateTime,
			 T.c.value('@ProgramNumber', 'INT')         ProgramNumber,
	    (
		   SELECT
				ProgramId
		   FROM TCD.TunnelProgramSetup AS tps
		   WHERE tps.WasherGroupId = wg.WasherGroupId
			    AND tps.is_deleted = 0
			    AND ProgramNumber = T.c.value('@ProgramNumber', 'INT')
	    )                                                 ProgramMasterID,
			 T.c.value('@CustomerNumber', 'INT')        CustomerNumber,
			 T.c.value('@Load', 'DECIMAL(18,4)')        Load1,
			 T.c.value('@Nominalload', 'DECIMAL(18,4)') Nominalload,
			 T.c.value('@TransferSignal', 'INT')        TransferSignal,
			 T.c.value('@RunState', 'INT')              RunState,
			 p.CurrencyCode
	    FROM TCD.Washer w
		    INNER JOIN TCD.MachineSetup ms ON ms.WasherId = w.WasherId
									   AND ms.IsTunnel = 1
									   AND ms.IsDeleted = 0
									   AND ms.ControllerId =
									   @ControllerID
		    INNER JOIN TCD.WasherGroup wg ON Wg.WasherGroupId = ms.
		    GroupId
		    INNER JOIN TCD.WasherGroupType wgt ON WgT.WasherGroupTypeId
		    = Wg.WasherGroupTypeId
		    INNER JOIN TCD.ConduitController cc ON cc.ControllerId = ms.
		    ControllerId
		    INNER JOIN TCD.Plant p ON p.EcolabAccountNumber = w.
		    EcoLabAccountNumber
		    RIGHT OUTER JOIN @xmlTags.nodes('MyControlTunnel/TunnelData')
		    T(C) ON T.c.value('@MachineNumber', 'INT') = ms.
		    MachineInternalId;
	    INSERT INTO #BatchData
	    (
			 CompartmentNO,
			 ControllerBatchId,
			 TargetTurnTime,
			 StdInjectionSteps,
			 StdWashSteps,
			 EcolabTextileCategoryId,
			 ChainTextileCategoryId,
			 FormulaSegmentId,
			 EcolabSaturationId,
			 PlantProgramId,
			 BatchID
	    )
	    SELECT
			 obd.CompartmentNumber,
			 obd.BatchNumber,
			 (3600 / (tps.TotalRunTime / ms.NumberOfComp)),
			 COUNT(tdpm.TunnelDosingSetupId),
			 COUNT(DISTINCT tds.TunnelDosingSetupId) - COUNT(tdpm.
			 TunnelDosingSetupId),
			 CASE
				WHEN ISNULL(pm.PlantProgramId, 0) <> 0
				THEN pcp.EcolabTextileCategoryId
				ELSE pm.EcolabTextileCategoryId
			 END EcolabTextileCategoryId,
			 CASE
				WHEN ISNULL(pm.PlantProgramId, 0) <> 0
				THEN pcp.ChainTextileCategoryId
				ELSE pm.ChainTextileId
			 END ChainTextileCategoryId,
			 CASE
				WHEN ISNULL(pm.PlantProgramId, 0) <> 0
				THEN pcp.FormulaSegmentId
				ELSE pm.FormulaSegmentId
			 END FormulaSegmentId,
			 CASE
				WHEN ISNULL(pm.PlantProgramId, 0) <> 0
				THEN pcp.EcolabSaturationId
				ELSE pm.EcolabSaturationId
			 END EcolabSaturationId,
			 pm.PlantProgramId,
			 bd.BatchId
	    FROM #OnlineBatchData obd
		    LEFT OUTER JOIN tcd.MachineSetup ms ON ms.WasherId = obd.
		    MachineID
		    LEFT OUTER JOIN tcd.BatchData bd ON bd.ControllerBatchId =
		    obd.BatchNumber
										AND bd.MachineId = obd.
										MachineID
										AND CAST(bd.StartDate AS
										DATE) = CAST(obd.
										StartDate AS DATE)
		    LEFT OUTER JOIN TCD.TunnelProgramSetup tps ON obd.GroupID =
		    tps.WasherGroupId
												AND tps.
												is_deleted = 0
												AND tps.
												ProgramNumber = obd.ProgramNumber
		    LEFT OUTER JOIN TCD.TunnelDosingSetup tds ON tps.
		    TunnelProgramSetupId = tds.TunnelProgramSetupId
											    AND tds.GroupId
											    = obd.GroupID
											    AND tds.
											    ProgramNumber = obd.ProgramNumber
											    AND tds.
											    Is_Deleted = 0
		    LEFT OUTER JOIN TCD.TunnelDosingProductMapping tdpm ON tdpm.
		    TunnelDosingSetupId = tds.TunnelDosingSetupId
		    LEFT OUTER JOIN TCD.ProgramMaster pm ON pm.ProgramId = obd.
		    ProgramMasterID
										    AND pm.Is_Deleted =
										    0
		    LEFT OUTER JOIN TCD.PlantChainProgram pcp ON pcp.
		    PlantProgramId = pm.PlantProgramId
											    AND pcp.
											    Is_Deleted = 0
	    GROUP BY
			   obd.CompartmentNumber,
			   obd.BatchNumber,
			   obd.PlantWasherNumber,
			   tps.TotalRunTime,
			   ms.NumberOfComp,
			   pm.PlantProgramId,
			   pm.EcolabTextileCategoryId,
			   pcp.EcolabTextileCategoryId,
			   pm.ChainTextileId,
			   pcp.ChainTextileCategoryId,
			   pm.PlantProgramId,
			   pcp.PlantProgramId,
			   pm.FormulaSegmentId,
			   pcp.FormulaSegmentId,
			   pcp.EcolabSaturationId,
			   pm.EcolabSaturationId,
			   bd.BatchId;
	    DECLARE @Compartment    INT      = 0,
			  @BatchStartDate DATETIME,
			  @ShiftId        INT,
			  @ShiftStartDate DATETIME;
	    WHILE(@Compartment <=
		    (
			   SELECT
					COUNT(obd.CompartmentNumber)
			   FROM #OnlineBatchData obd
		    ))
		   BEGIN
			  SELECT
				    @BatchStartDate = obd.StartDate
			  FROM #OnlineBatchData obd
			  WHERE obd.CompartmentNumber = @Compartment;
			  INSERT INTO #GetShiftDetails
			  (
				    ShiftId,
				    ShiftName,
				    ShiftStartdate
			  )
			  EXEC TCD.GetShiftStartDate
				  @BatchStartDate;
			  SELECT
				    @ShiftId = ShiftID,
				    @ShiftStartDate = ShiftStartdate
			  FROM #GetShiftDetails;
			  UPDATE #BatchData
			    SET
				   #BatchData.ShiftId = @ShiftId,
				   #BatchData.PartitionOn = @ShiftStartDate
			  WHERE
				   #BatchData.CompartmentNO = @Compartment;
			  DELETE FROM #GetShiftDetails;
			  SET @Compartment = @Compartment + 1;
		   END;
	    MERGE INTO TCD.BatchData bd
	    USING
	    (
		   SELECT
				*
		   FROM #OnlineBatchData obd
			   LEFT OUTER JOIN #BatchData tbd ON obd.CompartmentNumber
			   = tbd.CompartmentNO
										  AND obd.BatchNumber =
										  tbd.ControllerBatchID
	    ) temp
	    ON bd.BatchId = temp.BatchID
		   WHEN NOT MATCHED
		   THEN INSERT(
					ControllerBatchId,
					EcolabWasherId,
					GroupId,
					MachineInternalId,
					PlantWasherNumber,
					StartDate,
					ProgramNumber,
					ProgramMasterId,
					MachineId,
					ActualWeight,
					StandardWeight,
					CurrencyCode,
					ShiftId,
					PartitionOn,
					TargetTurnTime,
					StdInjectionSteps,
					StdWashSteps,
					EcolabTextileCategoryId,
					ChainTextileCategoryId,
					FormulaSegmentId,
					EcolabSaturationId,
					PlantProgramId) VALUES
	    (
									   temp.BatchNumber,
									   temp.EcolabWasherID,
									   temp.GroupID,
									   temp.MachineInternalID,
									   temp.PlantWasherNumber,
									   temp.StartDate,
									   temp.ProgramNumber,
									   temp.ProgramMasterID,
									   temp.MachineID,
									   temp.ActualWeight,
									   temp.StandardWeight,
									   temp.CurrencyCode,
									   temp.ShiftId,
									   temp.PartitionOn,
									   temp.TargetTurnTime,
									   temp.StdInjectionSteps,
									   temp.StdWashSteps,
									   temp.
									   EcolabTextileCategoryId,
									   temp.
									   ChainTextileCategoryId,
									   temp.FormulaSegmentId,
									   temp.EcolabSaturationId,
									   temp.PlantProgramId
	    )
	    OUTPUT
			 INSERTED.BatchId,
			 INSERTED.ControllerBatchId,
			 INSERTED.MachineId,
			 INSERTED.StartDate
			 INTO #NewBatchIds(
				 Batch_ID,
				 Batch_Number,
				 Machine_Id,
				 Batch_Startdate);
	    MERGE INTO TCD.BatchCustomerData bcd
	    USING
	    (
		   SELECT
				CASE
				    WHEN tbd.BatchID = ISNULL(tbd.BatchID, 0)
				    THEN tbd.BatchID
				    ELSE nbi.Batch_ID
				END                    BatchID,
				pc.ID,
				obd.ActualWeight,
				ROUND(COALESCE((obd.ActualWeight * Pm.Pieces) / NULLIF
				(Pm.Weight, 0), 0), 0) PiecesCount,
				tbd.PartitionOn,
				obd.EcolabWasherId
		   FROM #OnlineBatchData obd
			   LEFT OUTER JOIN #BatchData tbd ON obd.CompartmentNumber
			   = tbd.CompartmentNO
										  AND obd.BatchNumber =
										  tbd.ControllerBatchID
			   LEFT OUTER JOIN #NewBatchIds nbi ON nbi.Batch_Number =
			   tbd.ControllerBatchId
										    AND nbi.
										    Batch_Startdate = obd.StartDate
										    AND nbi.Machine_Id =
										    obd.MachineID
			   INNER JOIN TCD.ProgramMaster Pm ON Pm.ProgramId = obd.
			   ProgramMasterID
			   INNER JOIN TCD.PlantCustomer Pc ON Pc.ID = Pm.CustomerId
		   WHERE Pm.CustomerId != -1
			    AND Pm.[Weight] > 0
	    ) temp
	    ON bcd.BatchId = temp.BatchID
		   WHEN NOT MATCHED AND temp.ID = ISNULL(temp.ID, 0)
		   THEN INSERT(
					BatchId,
					CustomerId,
					Weight,
					PiecesCount,
					PartitionOn,
					EcolabWasherId) VALUES
	    (
									   temp.BatchID,
									   temp.ID,
									   temp.ActualWeight,
									   temp.PiecesCount,
									   temp.PartitionOn,
									   temp.EcolabWasherId
	    );
	    WITH XmlData
		    AS (
		    SELECT
				 XmlData.value('@Value', 'DECIMAL(18,4)') Reading,
				 XmlData.value('@Compartment', 'DECIMAL(18,4)')
				                                          CompartmentNumber,
				 1                                        SType
		    FROM @XmlTags.nodes(
		    '/MyControlTunnel/TunnelData/TemperatureData'
						   ) Data(XmlData)
		    WHERE XmlData.value('@Value', 'DECIMAL(18,4)') > 0
		    UNION ALL
		    SELECT
				 XmlData.value('@Phvalue', 'DECIMAL(18,4)') Reading,
				 XmlData.value('@CompartmentNumber', 'DECIMAL(18,4)')
				                                            CompartmentNumber,
				 2                                          SType
		    FROM @XmlTags.nodes('/MyControlTunnel/TunnelData') Data(
		    XmlData)
		    WHERE XmlData.value('@Phvalue', 'DECIMAL(18,4)') > 0
		    UNION ALL
		    SELECT
				 XmlData.value('@ConductivityValue', 'DECIMAL(18,4)')
				   Reading,
				 XmlData.value('@CompartmentNumber', 'DECIMAL(18,4)')
				   CompartmentNumber,
				 4 SType
		    FROM @XmlTags.nodes('/MyControlTunnel/TunnelData') Data(
		    XmlData)
		    WHERE XmlData.value('@ConductivityValue', 'DECIMAL(18,4)') >
		    0),
		    FormSensorDetails
		    AS (SELECT
					xd.CompartmentNumber,
					xd.SType,
					xd.Reading,
					s.SensorType,
					s.SensorId,
					GETUTCDATE() Time_Stamp
			   FROM XmlData xd
				   LEFT OUTER JOIN #OnlineBatchData obd ON obd.
				   CompartmentNumber = xd.CompartmentNumber
				   INNER JOIN TCD.Sensor s ON s.MachineCompartment =
				   xd.CompartmentNumber
										AND xd.SType = s.
										SensorType
			   WHERE s.GroupID = obd.GroupID
				    AND s.ControllerID = 3
				    AND s.Is_deleted = 0)
		    MERGE INTO tcd.sensorreading sr
		    USING
		    (
			   SELECT
					*
			   FROM FormSensorDetails
		    ) temp
		    ON sr.sensorId = temp.sensorid
			  AND temp.reading =
			  (
				  SELECT TOP 1
				 reading
				  FROM tcd.SensorReading
				  WHERE SensorId = temp.sensorid
				  ORDER BY
				   TimeStamp DESC)
		    -- If records are not in the sensor reading tables
		    -- Sensor records are inserted depending on the sensor type 
			   WHEN NOT MATCHED AND ISNULL(temp.reading, 0) <> 0
			   THEN INSERT(
						sensorid,
						reading,
						timestamp) VALUES
		    (
									   temp.sensorid,
									   temp.reading,
									   temp.Time_Stamp
		    );
	    INSERT INTO #DosingDetails
	    (
			 Number,
			 Quantity,
			 Point,
			 IsMainEquioment,
			 IsDirectDosing,
			 WasherGroupNum,
			 CompartmentNO
	    )
	    SELECT
			 T.c.value('@Number', 'INT') AS             Number, --PumpNumber
			 T.c.value('@Quantity', 'Decimal(10,6)') AS Quantity, --Dosing Quanity
			 T.c.value('@Point', 'INT') AS              Point, --ValveNumber
			 T.c.value('@IsMainEquipment', 'INT') AS    IsMainEquioment,
			 T.c.value('@IsDirectDosing', 'INT') AS     IsDirectDosing,
			 T.c.value('../@GroupNumber', 'int')        WasherGroupNum,
			 T.c.value('../@CompartmentNumber', 'int')  WasherGroupNum
	    FROM @xmlTags.nodes('MyControlTunnel/TunnelData/Dose') T(c);
	    WITH DosingData
		    AS (SELECT
					obd.MachineId,
					obd.MachineInternalId,
					obd.ProgramNumber,
					obd.BatchNumber,
					dd.Number,
					CASE
					    WHEN dd.IsMainEquioment = 1
					    THEN dd.Quantity * 16
					    ELSE dd.Quantity
					END quantity,
					dd.Point,
					CASE
					    WHEN dd.IsDirectDosing = 1
					    THEN
			   (
				  SELECT  Top  1 
					    CES.ProductId
				  FROM tcd.ControllerEquipmentSetup CES
					  INNER JOIN TCD.
					  TunnelCompartmentEquipmentValveMapping TCEVM ON CES.
					  ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
				  WHERE TCEVM.DirectDosingFlag = 1
					   AND CES.ControllerId = @ControllerID
					   AND CES.ControllerEquipmentId = dd.Number
					   AND CES.ControllerEquipmentTypeId = 1
					   AND CES.WasherGroupNumber = dd.WasherGroupNum
			   )
					    WHEN dd.IsMainEquioment = 1
					    THEN
			   (
				  SELECT Top 1 
					    CES.ProductId
				  FROM tcd.ControllerEquipmentSetup CES
					  INNER JOIN TCD.
					  TunnelCompartmentEquipmentValveMapping TCEVM ON CES.
					  ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
				  WHERE CES.ControllerId = @ControllerID
					   AND CES.ControllerEquipmentTypeId = 2
					   AND CES.WasherGroupNumber = dd.WasherGroupNum
					   AND TCEVM.ValveNumber = dd.Point
					   AND CES.ControllerEquipmentId = dd.Number
			   )
					    ELSE
			   (
				  SELECT Top 1 
					    CES.ProductId
				  FROM tcd.ControllerEquipmentSetup CES
					  INNER JOIN TCD.
					  TunnelCompartmentEquipmentValveMapping TCEVM ON CES.
					  ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
				  WHERE CES.ControllerId = @ControllerID
					   AND CES.ControllerEquipmentTypeId = 1
					   AND CES.WasherGroupNumber = dd.WasherGroupNum
					   AND TCEVM.ValveNumber = dd.Point
			   )
					END ProductID
			   FROM #DosingDetails dd
				   LEFT OUTER JOIN #OnlineBatchData obd ON dd.
				   CompartmentNO = obd.CompartmentNumber)
		    MERGE INTO tcd.WasherProductReading wpr
		    USING
		    (
			   SELECT
					*
			   FROM DosingData
		    ) temp
		    ON temp.MachineId = wpr.WasherId
			  AND temp.BatchNumber = wpr.BatchNumber
			  AND temp.ProductID = wpr.ProductID
			  AND wpr.ControllerID = @ControllerID
			  AND temp.Quantity =
		   isnull( (
			   SELECT TOP 1
					RealQty
			   FROM TCD.WasherProductReading wp
			   WHERE temp.MachineId = wp.WasherId
				    AND temp.BatchNumber = wp.BatchNumber
				    AND temp.ProductID = wp.ProductID
				    AND wp.ControllerID = @ControllerID ORDER BY wp.datetimestamp desc
		    ),0)
			   WHEN NOT MATCHED AND(temp.ProductID <> NULL
							    OR temp.ProductID <> 0)
			   THEN INSERT(
						ControllerId,
						WasherId,
						MachineInternalId,
						ProductId,
						RealQty,
						DosingNumber,
						ProgramNumber,
						BatchNumber,
						ValveNumber,
						DateTimeStamp) VALUES
		    (
										  @ControllerID,
										  temp.MachineId,
										  temp.MachineInternalId,
										  temp.ProductID,
										  temp.Quantity,
										  temp.Number,
										  temp.ProgramNumber,
										  temp.BatchNumber,
										  temp.Point,
										  GETUTCDATE()
		    );
	    DROP TABLE #DosingDetails;
	    DROP TABLE #NewBatchIds;
	    DROP TABLE #GetShiftDetails;
	    DROP TABLE #BatchData;
	    DROP TABLE #OnlineBatchData;
	END;