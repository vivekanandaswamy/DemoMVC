﻿CREATE PROCEDURE [TCD].[GetPumpsResync]
				(
				@EcolabAccountNumber			NVARCHAR(25)	=	NULL
			,	@ControllerId					INT				=	NULL
			,	@ControllerEquipmentSetupId		INT				=	NULL
			)
AS     
SET NOCOUNT ON    
BEGIN     
   SELECT [ControllerEquipmentSetupId]
      ,[EcoLabAccountNumber]
      ,[ControllerId]
      ,[ControllerEquipmentId]
      ,[ControllerEquipmentTypeId]
      ,[ControllerEquipmentTypeModelID]
      ,[LineNumber]
      ,[IsActive]
      ,[ProductId]
      ,[PumpCalibration]
      ,[FlowMeterSwitchFlag]
      ,[MaximumDosingTime]
      ,[FlowSwitchTimeOut]
      ,[KFactor]
      ,[TunnelHold]
      ,[FlowSwitchAlarm]
      ,[FlowMeterAlarm]
      ,[FlowMeterType]
      ,[FlowSwitchNumber]
      ,[FlowAlarmDelay]
      ,[FlowMeterPumpDelay]
      ,[FlowMeterAlarmDelay]
      ,[LfsChemicalName]
      ,[FlowDetectorType]
      ,[ConventionalWasherGroupConnection]
      ,[AxillaryPumpCalibration]
      ,[FlowmeterSwitchActivated]
      ,[FlushWhileDosing]
      ,[WeightControlledDosage]
      ,[EquipmentDoseAlone]
      ,[LowLevelAlarm]
      ,[LeakageAlarm]
      ,[FlushTime]
      ,[PumpingTime]
      ,[PreFlushTime]
      ,[NightFlushPauseTime]
      ,[NightFlushTime]
      ,[AcceptedDeviation]
      ,[WasherGroupNumber]
      ,[LastModifiedTime]
      ,[FlushValveNumber]
      ,[CalibrationConductSS_Tank]
      ,[BackFlowControl]
      ,[FactorFM_B_FM]
      ,[AcceptedDeviationRingLine]
      ,[UsePumpOfGroup1ForTunnel]
      ,[pHSensorEnabled]
      ,[Concentration]
      ,[Deadband] 
      ,[ValveOutputAsTom]
  FROM [TCD].[ControllerEquipmentSetup] ces
  WHERE ces.EcoLabAccountNumber =@EcolabAccountNumber 
  AND ces.ControllerId = ISNULL(@ControllerId, ces.ControllerId)
  AND ces.ControllerEquipmentSetupId = ISNULL(@ControllerEquipmentSetupId, ces.ControllerEquipmentSetupId) 
END