﻿CREATE PROCEDURE [TCD].[SaveSensorModuleTags] (
@SensorNumber NVARCHAR(100) = NULL,
@ControllerID  VARCHAR(1000) = NULL,
@AnalogueInputNumber NVARCHAR(100) = NULL,
@Calibration4mA DECIMAL(18, 2) = NULL,
@Calibration20mA DECIMAL(18, 2) = NULL,
@TagAddress4mA NVARCHAR(100) = NULL,
@TagAddress20mA NVARCHAR(100) = NULL,
@EcolabAccountNumber nvarchar(25) = NULL,
@UserID INT,
@Scope VARCHAR(100) OUTPUT
)
AS
BEGIN
SET NOCOUNT ON;
set @Scope = '';

DECLARE
@NewSensorId INT
,@ModuleType INT = 3
,@DefaultFrequency INT = 60
,@TagType VARCHAR(100) = 'Tag_MPLC'
,@TagTypeSC4 VARCHAR(100) = 'Tag_SC4'
,@TagTypeSC20 VARCHAR(100) = 'Tag_SC20'
,@Result1 INT = NULL
,@Result2 INT = NULL
,@Result3 INT = NULL
,@Type INT = 3
,@AllowTagEdit BIT;
SELECT @AllowTagEdit = CASE
WHEN COUNT(*) > 0 THEN 'TRUE'
ELSE 'FALSE'
END
FROM TCD.UserMaster UM
INNER JOIN
TCD.UserInRole UIR ON UM.UserId = UIR.UserId
INNER JOIN
TCD.UserRoles UR ON UIR.RoleId = UR.RoleId
WHERE UM.UserId = @UserID
AND UR.LevelId >= 8
AND UM.EcolabAccountNumber = @EcolabAccountNumber;
--IF NOT EXISTS (SELECT *
--FROM   TCD.Sensor
--WHERE  SensorID = @SensorNumber
--AND EcolabAccountNumber = @EcolabAccountNumber)

-- Begin Validate Tags

IF @AllowTagEdit = 'TRUE'
BEGIN
IF @AnalogueInputNumber IS NOT NULL
AND @AnalogueInputNumber != ''
BEGIN
EXEC @Result1 = TCD.CheckDuplicateTag @AnalogueInputNumber, @ControllerID;
IF @Result1 = 0
BEGIN
SET @AllowTagEdit = 'FALSE'
SET @Scope = @Scope + '804,';
END;
END;
IF @TagAddress4mA IS NOT NULL
AND @TagAddress4mA != ''
BEGIN
EXEC @Result2 = TCD.CheckDuplicateTag @TagAddress4mA, @ControllerID;
IF @Result2 = 0
BEGIN
SET @AllowTagEdit = 'FALSE'
SET @Scope = @Scope + '805,';
END;
END;
IF @TagAddress20mA IS NOT NULL
AND @TagAddress20mA != ''
BEGIN
EXEC @Result3 = TCD.CheckDuplicateTag @TagAddress20mA, @ControllerID;
IF @Result3 = 0
BEGIN
SET @AllowTagEdit = 'FALSE'
SET @Scope = @Scope + '806,';
END;
END;
END;

-- End Validate Tags


IF @AllowTagEdit = 'TRUE'
BEGIN
IF @AnalogueInputNumber IS NOT NULL
BEGIN
INSERT INTO TCD.ModuleTags (EcolabAccountNumber,
TagType,
TagAddress,
ModuleTypeId,
ModuleID,
DeadBand,
Active)
VALUES(@EcolabAccountNumber,
@TagType,
@AnalogueInputNumber,
@ModuleType,
@SensorNumber,
@DefaultFrequency,
1);
END;
IF @TagAddress4mA IS NOT NULL
BEGIN
INSERT INTO TCD.ModuleTags (EcolabAccountNumber,
TagType,
TagAddress,
ModuleTypeId,
ModuleID,
DeadBand,
Active)
VALUES(@EcolabAccountNumber,
@TagTypeSC4,
@TagAddress4mA,
@ModuleType,
@SensorNumber,
@DefaultFrequency,
1);
END;
IF @TagAddress20mA IS NOT NULL
BEGIN
INSERT INTO TCD.ModuleTags (EcolabAccountNumber,
TagType,
TagAddress,
ModuleTypeId,
ModuleID,
DeadBand,
Active)
VALUES(@EcolabAccountNumber,
@TagTypeSC20,
@TagAddress20mA,
@ModuleType,
@SensorNumber,
@DefaultFrequency,
1);
END;
END
ELSE
BEGIN
select @Scope
END
END