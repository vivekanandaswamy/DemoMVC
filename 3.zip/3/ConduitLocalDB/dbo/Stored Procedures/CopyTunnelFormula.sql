﻿CREATE PROCEDURE [TCD].[CopyTunnelFormula]
		 @ToWasherGroupId                            INT								=            NULL
    ,    @FromWasherGroupId                          INT								=            NULL
    ,    @ProgramNumber                              SMALLINT							=            NULL 
    ,    @WasherProgramSetupId                       INT								=            NULL
    ,    @ProgramId                                  INT								=            NULL
    ,    @EcoLabAccountNumber                        NVARCHAR(25)						=            NULL
    ,    @UserId                                     INT								=            NULL
    ,    @ProgramSetupId                             INT								=            NULL   OUTPUT 
	

AS
BEGIN
    SET NOCOUNT ON;

    DECLARE      @TotalNumberOfPrograms      SMALLINT        =       NULL
    ,            @ReturnValue                INT             =       0
    ,            @ErrorId                    INT             =       0
    ,            @ErrorMessage               NVARCHAR(4000)  =       N''
    ,            @MaxNumberOfPrograms        SMALLINT        =       127
	,			 @PlantId INT
	,             @FromControllerID                    INT     =   NULL
    ,             @ToControllerID                    INT     =   NULL    
    ,             @FromControllerModelID                INT     =   NULL
    ,             @ToControllerModelID                INT     =   NULL

	SET @PlantId = (SELECT p.PlantId FROM tcd.Plant p WHERE EcolabAccountNumber = @EcolabAccountNumber)

    DECLARE
                @OutputList                                AS    TABLE        (
                OutputProgramSetupId                       INT
        )

		 SELECT  @FromControllerID   =  wg.ControllerId 
     FROM TCD.WasherGroup   wg
     WHERE   wg.WasherGroupId  =  @FromWasherGroupId
    AND   wg.EcolabAccountNumber =  @EcoLabAccountNumber

    SELECT  @ToControllerID   =  wg.ControllerId 
     FROM TCD.WasherGroup   wg
     WHERE   wg.WasherGroupId  =  @ToWasherGroupId
    AND   wg.EcolabAccountNumber =  @EcoLabAccountNumber

    SELECT  @FromControllerModelID  =  cc.ControllerModelId
     FROM TCD.ConduitController cc
     WHERE cc.ControllerId   =  @FromControllerID
    AND   cc.EcoalabAccountNumber =  @EcoLabAccountNumber

    SELECT  @ToControllerModelID  =  cc.ControllerModelId
     FROM TCD.ConduitController cc
     WHERE cc.ControllerId   =  @ToControllerID
    AND   cc.EcoalabAccountNumber =  @EcoLabAccountNumber

	 IF @ToControllerID IS NOT NULL
    BEGIN
       SELECT @MaxNumberOfPrograms = cmctm.MaxConvProgramCount
       FROM TCD.ControllerModelControllerTypeMapping cmctm
       INNER JOIN TCD.ConduitController cc
       ON cc.ControllerModelId = cmctm.ControllerModelId 
       AND cc.ControllerTypeId = cmctm.ControllerTypeId
       WHERE cc.ControllerId = @ToControllerID
    END
    ELSE
    BEGIN
        SET @MaxNumberOfPrograms = 127
    END

    --ProgramNumber check
    IF    (    @ProgramNumber                >            @MaxNumberOfPrograms)
    BEGIN
            SET        @ErrorId                        =            51012
            SET        @ErrorMessage                    =            N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Invalid ProgramNumber... Aborting.'
            --GOTO    ErrorHandler
            RAISERROR    (@ErrorMessage, 16, 1)
            SET    @ReturnValue    =    -1
            RETURN    (@ReturnValue)
    END

        --Check for unique ProgramNumber
        IF    EXISTS    (        SELECT    1
                            FROM    [TCD].TunnelProgramSetup            TPS
                            WHERE    TPS.EcolabAccountNumber        =            @EcoLabAccountNumber
                                AND    TPS.WasherGroupId            =            @ToWasherGroupId
                                AND    TPS.ProgramNumber            =            @ProgramNumber
                                AND    TPS.Is_Deleted                =            'FALSE'
                    )
                BEGIN
                        SET        @ErrorId            =            51001
                        SET        @ErrorMessage        =            N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Specified ProgramNumber for the WasherGroup already exists for the plant.'
                        --GOTO    ErrorHandler
                        RAISERROR    (@ErrorMessage, 16, 1)
                        SET    @ReturnValue    =    -1
                        RETURN    (@ReturnValue)
                END

        --Check for total number of programs/formulae associated
        SELECT    @TotalNumberOfPrograms        =            COUNT(TPS.ProgramNumber)
        FROM    [TCD].TunnelProgramSetup                        TPS
        WHERE    TPS.EcolabAccountNumber        =            @EcoLabAccountNumber
            AND    TPS.WasherGroupId            =            @ToWasherGroupId
            AND    TPS.Is_Deleted                =            'FALSE'
        
        IF    (    @TotalNumberOfPrograms        =            @MaxNumberOfPrograms    )
            BEGIN
                    SET        @ErrorId        =            51000
                    SET        @ErrorMessage    =            N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Maximum Number of programs that can be associated to a WasherGroup already defined... Aborting.'
                    --GOTO    ErrorHandler
                    RAISERROR    (@ErrorMessage, 16, 1)
                    SET    @ReturnValue    =    -1
                    RETURN    (@ReturnValue)
            END

        INSERT INTO TCD.TunnelProgramSetup
        (
            --TunnelProgramSetupId - this column value is auto-generated
            EcolabAccountNumber,
            WasherGroupId,
            ProgramNumber,
            [Description],
            ProgramId,
            NominalLoad,
            LoadsPerMonth,
            TotalRunTime,
            ExtraTime,
            NumberOfDrains,
            DrainTime,
            Category,
            CleanWt,
            CleanAw,
            CustomerId,
            Rewash,
            Is_Deleted,
            LastModifiedByUserId,
            MyServiceCustFrmulaMchGrpGUID,
            LastModifiedTime
        )
        OUTPUT
            INSERTED.TunnelProgramSetupId    AS    Id
        INTO
            @OutputList(
                    OutputProgramSetupId
                       )
        SELECT    tps.EcolabAccountNumber
        ,        @ToWasherGroupId
        ,        @ProgramNumber
        ,        tps.[Description]
        ,        @ProgramId
        ,        tps.NominalLoad
        ,        tps.LoadsPerMonth
        ,        tps.TotalRunTime
        ,        tps.ExtraTime
        ,        tps.NumberOfDrains
        ,        tps.DrainTime
        ,        tps.Category
        ,        tps.CleanWt
        ,        tps.CleanAw
        ,        tps.CustomerId
        ,        tps.Rewash
        ,        tps.Is_Deleted
        ,        @UserId
        ,        NEWID()
        ,        GETUTCDATE()
        FROM TCD.TunnelProgramSetup tps
        WHERE tps.EcolabAccountNumber    =    @EcoLabAccountNumber
        AND      tps.TunnelProgramSetupId  =    @WasherProgramSetupId
        AND   tps.WasherGroupId            =    @FromWasherGroupId

         --check for any error
            SET    @ErrorId    =    @@ERROR
    
            IF    (@ErrorId    <>    0)
                BEGIN
                        SET        @ErrorMessage    =            N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred associating formula to the conventional washer group.'
                        --GOTO    ErrorHandler
                        RAISERROR    (@ErrorMessage, 16, 1)
                        SET    @ReturnValue    =    -1
                        RETURN    (@ReturnValue)
                END

        SELECT  TOP 1 @ProgramSetupId    =   O.OutputProgramSetupId FROM @OutputList O

        INSERT INTO TCD.TunnelDosingSetup
        (
            --TunnelDosingSetupId - this column value is auto-generated
            EcolabAccountNumber,
            TunnelProgramSetupId,
            GroupId,
            ProgramNumber,
            StepNumber,
            StepTypeId,
            ProductId,
            StepRunTime,
            CompartmentNumber,
            MachineNumber,
            Quantity,
            [Delay],
            DosingNumber,
            Temperature,
            WaterType,
            WaterLevel,
            DrainDestinationId,
            pHLevel,
            WaterInletDrain,
            Note,
            Is_Deleted,
            LastModifiedByUserId,
            MyServiceCustFrmulaStpGUID,
            StandardWaterUsage
        )
        SELECT tds.EcolabAccountNumber
        , @ProgramSetupId
        , @ToWasherGroupId
        , @ProgramNumber
        , tds.StepNumber
        , tds.StepTypeId
        , tds.ProductId
        , tds.StepRunTime
        , tds.CompartmentNumber
        , tds.MachineNumber
        , tds.Quantity
        , tds.[Delay]
        , tds.DosingNumber
        , tds.Temperature
        , tds.WaterType
        , tds.WaterLevel
        , tds.DrainDestinationId
        , tds.pHLevel
        , tds.WaterInletDrain
        , tds.Note
        , 'False'
        , @UserId
        , NEWID()
        , tds.StandardWaterUsage
        FROM TCD.TunnelDosingSetup tds
        WHERE tds.TunnelProgramSetupId = @WasherProgramSetupId
        AND        tds.EcolabAccountNumber = @EcoLabAccountNumber
        AND        tds.Is_Deleted    = 'False'

        --check for any error
            SET    @ErrorId    =    @@ERROR
    
            IF    (@ErrorId    <>    0)
                BEGIN
                        SET        @ErrorMessage    =            N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred associating formula to the conventional washer group.'
                        --GOTO    ErrorHandler
                        RAISERROR    (@ErrorMessage, 16, 1)
                        SET    @ReturnValue    =    -1
                        RETURN    (@ReturnValue)
                END

		CREATE TABLE #Tunnel1(
			CompartmentNumber tinyint,
			ProductId int,
			ControllerEquipmentSetupId int
		)

		IF (@FromControllerModelID IS NULL OR @FromControllerModelID < 7  OR @FromControllerModelID IN (12, 13))
        BEGIN
			INSERT INTO #Tunnel1
			(
			    CompartmentNumber,
			    ProductId,
			    ControllerEquipmentSetupId
			)
			SELECT tc.CompartmentNumber, 
					ces.ProductId, 
					tcem.ControllerEquipmentSetupId 
			FROM TCD.TunnelCompartmentEquipmentMapping tcem
			INNER JOIN TCD.TunnelCompartment tc
			ON tc.TunnelCompartmentId = tcem.TunnelCompartmentId AND tc.EcoLabAccountNumber = tcem.EcoLabAccountNumber AND tcem.Is_Deleted = 0
			INNER JOIN TCD.MachineSetup ms
			ON ms.WasherId = tc.WasherId AND ms.EcoalabAccountNumber = tc.EcoLabAccountNumber AND ms.IsDeleted = 0 AND ms.IsTunnel = 1 
			AND ms.EcoalabAccountNumber = tcem.EcoLabAccountNumber
			INNER JOIN TCD.WasherGroup wg
			ON wg.WasherGroupId = ms.GroupId AND wg.EcolabAccountNumber = ms.EcoalabAccountNumber 
			LEFT JOIN TCD.ControllerEquipmentSetup ces 
			ON ces.ControllerEquipmentSetupId = tcem.ControllerEquipmentSetupId AND ces.EcoLabAccountNumber = tc.EcoLabAccountNumber 
			AND ces.EcoLabAccountNumber = tcem.EcoLabAccountNumber
			WHERE wg.WasherGroupId = @FromWasherGroupId AND wg.EcolabAccountNumber = @EcoLabAccountNumber
		END
		ELSE
		BEGIN
			INSERT INTO #Tunnel1
			(
			    CompartmentNumber,
			    ProductId,
			    ControllerEquipmentSetupId
			)
				SELECT DISTINCT 
						CAST(tcevm.[CompartmentNumber] AS INT) AS CompartmentNumber,
					    ces.ProductId,
					    ces.ControllerEquipmentSetupId 
				FROM TCD.TunnelCompartmentEquipmentValveMapping tcevm
				INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.ControllerEquipmentSetupId = tcevm.ControllerEquipmentSetupId 
				AND tcevm.PlantID = @PlantId
				INNER JOIN TCD.MachineSetup ms ON ms.ControllerId = ces.ControllerId AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber AND ms.MachineInternalId = tcevm.TunnelNumber
				AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber AND ms.MachineInternalId = tcevm.TunnelNumber AND MS.IsTunnel = 'TRUE' AND MS.IsDeleted = 'FALSE'
				INNER JOIN TCD.TunnelProgramSetup TPS on TPS.WasherGroupId = MS.GroupId AND TPS.EcolabAccountNumber = MS.EcoalabAccountNumber
				JOIN TCD.TunnelDosingSetup TDS ON tds.EcolabAccountNumber = TPS.EcolabAccountNumber 
					   AND TDS.TunnelProgramSetupId = TPS.TunnelProgramSetupId AND TDS.CompartmentNumber = tcevm.CompartmentNumber
				LEFT JOIN TCD.TunnelDosingProductMapping TDPM ON TDPM.CompartmentNumber = tcevm.CompartmentNumber AND TDPM.EcoLabAccountNumber = TDS.EcoLabAccountNumber
					   AND TDPM.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId AND TDPM.TunnelDosingSetupId = TDS.TunnelDosingSetupId
				 WHERE MS.GroupId = @FromWasherGroupId  
				 AND MS.EcoalabAccountNumber =  @EcoLabAccountNumber
		END
		
        INSERT TCD.TunnelDosingProductMapping
        (
            --TunnelDosingProductMappingId - this column value is auto-generated
            EcoLabAccountNumber,
            TunnelDosingSetupId,
            GroupId,
            CompartmentNumber,
            ControllerEquipmentSetupId,
            InjectionNumber,
            ProductId,
            Quantity,
            LastModifiedByUserId,
            LastModifiedTime,
            MyServiceFrmulaStpDsgDvcGuid,
            DelayTime
        )
        SELECT tdpm.EcoLabAccountNumber
        , tds2.TunnelDosingSetupId
        , @ToWasherGroupId
        , tdpm.CompartmentNumber
        , (SELECT TOP 1 ces2.ControllerEquipmentSetupId FROM TCD.ControllerEquipmentSetup ces2 WHERE ces2.ProductId = ces.ProductId AND ces2.ControllerId = @ToControllerID AND ces2.ControllerEquipmentId = ces.ControllerEquipmentId AND ces2.EcoLabAccountNumber = @EcoLabAccountNumber)
        , tdpm.InjectionNumber
        , tdpm.ProductId
        , tdpm.Quantity
        , @UserId
        , GETUTCDATE()
        , NEWID()
        , tdpm.DelayTime 
        FROM TCD.TunnelDosingProductMapping tdpm
        INNER JOIN TCD.TunnelDosingSetup tds
        ON tds.TunnelDosingSetupId = tdpm.TunnelDosingSetupId
        AND tds.EcolabAccountNumber = tdpm.EcoLabAccountNumber
        LEFT JOIN TCD.TunnelDosingSetup tds2
        ON tds2.CompartmentNumber = tds.CompartmentNumber
        AND tds2.EcolabAccountNumber = tds.EcolabAccountNumber
        AND tds2.TunnelProgramSetupId = @ProgramSetupId
        INNER JOIN TCD.ControllerEquipmentSetup ces 
        ON ces.ControllerEquipmentSetupId = tdpm.ControllerEquipmentSetupId
        INNER JOIN #Tunnel1 t
        ON t.CompartmentNumber = tdpm.CompartmentNumber
        AND t.ProductId = ces.ProductId
        WHERE tds.TunnelProgramSetupId = @WasherProgramSetupId
        AND tds.Is_Deleted = 'False'
        ORDER BY tds.CompartmentNumber	
		

-- CleanUp
        DROP TABLE #Tunnel1

    IF    (    @ErrorId    =    0    )
    BEGIN
        --GOTO    ExitModule
        RETURN    (@ReturnValue)
    END

    SET    NOCOUNT    OFF
    RETURN    (@ReturnValue)
END
GO