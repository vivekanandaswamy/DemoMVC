﻿/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[SaveControllerEquipment]                                         

Purpose:    To save the controller equipment.  

Parameters:    @EcolabAccountNumber - holds the ecolab account number.  
						@ControllerId - holds the controller Id.
						@ControllerEquipmentId - holds the controller equuipment id.
						@ControllerEquipmentTypeId - holds the controller equipment type id.
						@ProductId - holds the product id.
						@PumpCalibration - holds the pump calibration value.
						@FlowMeterSwitchFlag - holds the flow meteer switch flag value.
						@FlowMeterCalibration - holds the flow meter calibration.
						@MaximumDosingTime - holds the maximum dosing time.
						@FlowSwitchTimeOut - holds the flow switch time out.
						@UserId - holds the user id.
																																		
###################################################################################################                                           
*/
CREATE PROCEDURE [TCD].[SaveControllerEquipment]          
      @EcoLabAccountNumber    NVARCHAR(25)          
    , @ControllerId     INT          
    , @ControllerEquipmentId    SMALLINT          
    , @ControllerEquipmentTypeId   TINYINT          
    , @ProductId      INT          
    , @PumpCalibration     DECIMAL(18, 3)          
    , @LfsChemicalName     NVARCHAR(200)          
    , @KFactor      DECIMAL(18,2)  = NULL          
    , @TunnelHold      BIT    = NULL          
    , @FlowDetectorType     INT    = NULL      
    , @FlowSwitchNumber        INT        = NULL      
    , @FlowSwitchAlarm     BIT    = NULL          
    , @FlowMeterAlarm     BIT    = NULL          
    , @FlowMeterType     INT    = NULL          
    , @FlowAlarmDelay     DECIMAL(18,2)    = NULL          
    , @FlowMeterPumpDelay    DECIMAL(18,2)    = NULL          
    , @FlowMeterAlarmDelay    DECIMAL(18,2)    = NULL          
    , @LfsChemicalNameTag    NVARCHAR(200)  = NULL          
    , @KfactorTag      NVARCHAR(200)  = NULL          
    , @CalibrationTag     NVARCHAR(200)  = NULL          
    , @ControllerEquipmentTypeModelId  INT = NULL          
    , @ConventionalWasherGroupConnection BIT           
    , @AxillaryPumpCalibration   SMALLINT          
    , @FlowmeterSwitchActivated   BIT          
    , @FlushWhileDosing      BIT          
    , @WeightControlledDosage    BIT          
    , @EquipmentDoseAlone       BIT          
    , @LowLevelAlarm          BIT          
    , @LeakageAlarm          BIT          
    , @FlushTime         SMALLINT          
    , @PumpingTime         SMALLINT          
    , @PreFlushTime        SMALLINT          
    , @NightFlushPauseTime       SMALLINT          
    , @NightFlushTime        SMALLINT          
    , @AcceptedDeviation       SMALLINT          
    , @LineNumber      TINYINT          
    , @MaximumDosingTime    SMALLINT          
    , @FlowSwitchTimeOut    decimal(18,1)          
    , @UserId       INT                 
    , @FlushValveNumber   TINYINT    = NULL      
    , @CalibrationConductSS_Tank DECIMAL(18,2)  = NULL      
    , @BackFlowControl    BIT        
    , @FactorFM_B_FM      SMALLINT = NULL      
    , @AcceptedDeviationRingLine SMALLINT   = NULL       
    , @UsePumpOfGroup1ForTunnel BIT   = NULL         
    , @pHSensorEnabled    BIT   = NULL    
 , @FlushTimeForFlushValve    INT   = NULL      
    , @Concentration      INT     = NULL      
    , @Deadband     BIT   = NULL     
 , @ValveOutputAsTom BIT = NULL   
    ,@MinimumFlowRate INT = NULL
    ,@ProductDensity DECIMAL(18,2) = NULL
    , @MaximumConcentration INT = NULL
				--Adding these 3 param as part of re-factoring for integration with Synch/Configurator
    , @OutputControllerEquipmentSetupId INT   =   NULL OUTPUT          
    , @LastModifiedTimestampAtCentral  DATETIME =   NULL   --Nullable for local call; Synch/Central call will have to pass this -          
																								--else, it will be treated as a local call
    , @OutputLastModifiedTimestampAtLocal DATETIME =   NULL OUTPUT          

AS
BEGIN

SET NOCOUNT ON          

DECLARE @Equipments TABLE (        
ProductId INT,        
EcoLabAccountNumber NVARCHAR(25),        
ControllerId INT        
)        
DECLARE @ReturnValue     INT      =   0          
 , @IsActive      BIT          
 , @ErrorId      INT      =   0          
 --, @ErrorMessage     NVARCHAR(4000)   =   N''          
 --, @ErrorNumber     INT     =   0          
 , @ErrorMessage     NVARCHAR(4000)   =   N''          
 , @ErrorSeverity     INT     =   NULL          
 , @ErrorProcedure     SYSNAME    =   NULL          
 , @MessageString     NVARCHAR(2500)  =   NULL          

 , @MaximumChemicalCount   TINYINT     =   NULL          
 , @DistinctChemicalCount   TINYINT     =   NULL          
 , @ControllerTypeId    INT          
 , @CurrentUTCTime     DATETIME    =   GETUTCDATE()          

--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
SET  @OutputLastModifiedTimestampAtLocal      =   @CurrentUTCTime          
SET  @OutputControllerEquipmentSetupId      =   ISNULL(@OutputControllerEquipmentSetupId, NULL)   --SQLEnlight SA0121          



SELECT @MaximumChemicalCount     =   CMCTM.MaximumChemicalCount          
  ,@ControllerTypeId      =   CC.ControllerTypeId          
FROM [TCD].ConduitController CC          
JOIN [TCD].ControllerModelControllerTypeMapping CMCTM          
 ON CC.ControllerModelId     =   CMCTM.ControllerModelId          
 AND CC.ControllerTypeId      =   CMCTM.ControllerTypeId          
WHERE CC.ControllerId       =   @ControllerId          

set @MaximumChemicalCount = 30 -- Added dummy value by srikanth, at times we are getting this value as 1, so that user is not able to add pumps more than 1. //Lemuel handled how many pumps should display based on the configuration so this check is useles 

    
     
       
         
          
SET  @IsActive        =   CASE WHEN @ProductId IS NULL THEN 'FALSE'          
                 ELSE 'TRUE'          
															END

 DECLARE @ModuleType INT = 4 --select MTy.ModuleTypeId from TCD.ModuleType MTy WHERE ModuleDescription like '%Pump%Valve%'          
					,@DefaultFrequency INT = 60
					,@TagTypeLfs VARCHAR(100) = 'Tag_NML'
					,@TagTypeKfactor VARCHAR(100) = 'Tag_PPOL'
					,@TagTypeCalibration VARCHAR(100) = 'Tag_OPSL'
					,@Result1 INT = NULL
					,@Result2 INT = NULL
					,@Result3 INT = NULL
     ,@Type INT = 4 --@ModuleType          
					,@RoleId INT = (SELECT UR.LevelId FROM TCD.UserMaster UM
														INNER JOIN TCD.UserInRole UIR ON UM.UserId = UIR.UserId
														INNER JOIN TCD.UserRoles UR ON UIR.RoleId = UR.RoleId
														WHERE UM.UserId = @UserId)

DECLARE
  @OutputList      AS TABLE  (          
  ControllerEquipmentSetupId   INT          
 , LastModifiedTimestamp    DATETIME          
	)

IF EXISTS ( SELECT 1          
    FROM [TCD].ControllerEquipmentSetup  CES          
    WHERE CES.ControllerId     =   @ControllerId          
     AND CES.ControllerEquipmentId   =   @ControllerEquipmentId          
     AND CES.EcoLabAccountNumber    =   @EcoLabAccountNumber          
			)
		BEGIN
				--If the call is not local, check that the LastModifiedTime matches with the central
    IF (          
      @LastModifiedTimestampAtCentral   IS NOT NULL          
     AND NOT EXISTS ( SELECT 1          
          FROM TCD.[ControllerEquipmentSetup]          
																		CES
          WHERE CES.EcolabAccountNumber = @EcolabAccountNumber        
           AND CES.ControllerId  = @ControllerId          
           AND CES.ControllerEquipmentId          
                  = @ControllerEquipmentId          
           AND CES.LastModifiedTime = @LastModifiedTimestampAtCentral          
									)
					)
					BEGIN
       SET   @ErrorId      = 60000          
       SET   @ErrorMessage     = N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'          
       RAISERROR (@ErrorMessage, 16, 1)          
       SET   @ReturnValue     = -1          
       RETURN  (@ReturnValue)          
					END
				
				--Proceed, since it's either a local call or Synch. call with synch. time matching
    SELECT @DistinctChemicalCount    =   COUNT(DISTINCT D.ProductId) --distinct count          
    FROM (          
      SELECT @ProductId     AS   ProductId     --being assigned          
						UNION
      SELECT DISTINCT ProductId  AS   ProductId     --already assigned          
      FROM [TCD].ControllerEquipmentSetup          
      WHERE ControllerId    =   @ControllerId          
       AND ControllerEquipmentId  <>   @ControllerEquipmentId          
       AND ProductId     <>   @ProductId          
      ) D          

    IF ( @DistinctChemicalCount > @MaximumChemicalCount )          
				BEGIN
      SET @ErrorId   = 51000          
      SET @ErrorMessage  = N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Maximum chemical count exceeded. Cannot assign new chemical'          
      --GOTO ErrorHandler          
      RAISERROR (@ErrorMessage, 16, 1)          
      SET @ReturnValue = -1          
      RETURN (@ReturnValue)          
				END			
				
					BEGIN
      BEGIN TRY          
        BEGIN TRAN

       IF(@IsActive='TRUE' AND @ControllerTypeId IN(1,2,6,7, 12,10, 14,8, 13,9,11))
       BEGIN
       UPDATE [TCD].ControllerEquipmentSetup          
         SET ProductId      =   @ProductId          
         , IsActive      =   @IsActive          
         , LfsChemicalName    =    @LfsChemicalName             
         , KFactor      =    @KFactor               
         , PumpCalibration    =    @PumpCalibration             
				
         , TunnelHold     =     @TunnelHold             
         , FlowDetectorType    = @FlowDetectorType   
         , FlowSwitchNumber    =    @FlowSwitchNumber  
         , FlowSwitchAlarm    =   CASE @ControllerTypeId WHEN 2 THEN @FlowSwitchAlarm  ELSE NULL END          
         , FlowMeterAlarm     =  CASE @ControllerTypeId WHEN 2 THEN @FlowMeterAlarm  ELSE NULL END       
         , FlowMeterType     =   CASE @ControllerTypeId WHEN 2 THEN @FlowMeterType   ELSE NULL END      
         , FlowAlarmDelay     =   CASE @ControllerTypeId WHEN 2 THEN @FlowAlarmDelay ELSE NULL END       
         , FlowMeterPumpDelay    =  CASE @ControllerTypeId WHEN 2 THEN @FlowMeterPumpDelay  ELSE NULL END       
         , FlowMeterAlarmDelay    =   CASE @ControllerTypeId WHEN 2 THEN @FlowMeterAlarmDelay ELSE NULL END 
         , ControllerEquipmentTypeModelId =    @ControllerEquipmentTypeModelId                
             , ConventionalWasherGroupConnection =    @ConventionalWasherGroupConnection            
             , AxillaryPumpCalibration   =    @AxillaryPumpCalibration              
             , FlowmeterSwitchActivated   =    @FlowmeterSwitchActivated             
             , FlushWhileDosing     =    @FlushWhileDosing                
             , WeightControlledDosage    =    @WeightControlledDosage               
             , EquipmentDoseAlone       =    @EquipmentDoseAlone                  
             , LowLevelAlarm          =    @LowLevelAlarm                     
             , LeakageAlarm          =    @LeakageAlarm                     
             , FlushTime         =    @FlushTime                   
             , PumpingTime        =    @PumpingTime                   
             , PreFlushTime        =    @PreFlushTime                   
             , NightFlushPauseTime       =    @NightFlushPauseTime                 
             , NightFlushTime        =    @NightFlushTime                  
             , AcceptedDeviation       =    @AcceptedDeviation                  
             , LineNumber        =    @LineNumber                     
             , MaximumDosingTime    =    @MaximumDosingTime               
         , FlowSwitchTimeOut    =    @FlowSwitchTimeOut            
        , ValveOutputAsTom               =    @ValveOutputAsTom                   

         , LastModifiedByUserId   =   @UserId          
        --** Adding a part of integration with Synch./Central -->          
         , LastModifiedTime    =   @CurrentUTCTime                  
       , FlushValveNumber  =    @FlushValveNumber                
 , CalibrationConductSS_Tank =    @CalibrationConductSS_Tank              
       , BackFlowControl  =    @BackFlowControl      
       , FactorFM_B_FM   =    @FactorFM_B_FM                     
       , AcceptedDeviationRingLine =    @AcceptedDeviationRingLine                
       , UsePumpOfGroup1ForTunnel =    @UsePumpOfGroup1ForTunnel                  
       , pHSensorEnabled    =    @pHSensorEnabled             
    , FlushTimeForFlushValve = @FlushTimeForFlushValve   
       , Concentration =    @Concentration                  
       , Deadband    =    @Deadband               
       , MinimumFlowRate =  @MinimumFlowRate       
       , ProductDensity =  @ProductDensity     
       , MaximumConcentration =  @MaximumConcentration     
        OUTPUT inserted.ControllerEquipmentSetupId   AS   ControllerEquipmentSetupId          
         , inserted.LastModifiedTime     AS   LastModifiedTime          
        INTO @OutputList (          
										ControllerEquipmentSetupId
         , LastModifiedTimestamp          
									)
        --** <--          
        WHERE ControllerId    =   @ControllerId          
        AND ControllerEquipmentId   =   @ControllerEquipmentId          
        AND EcoLabAccountNumber    =   @EcoLabAccountNumber  
        
        END
        
        
         IF(@IsActive='FALSE' AND @ControllerTypeId IN(1,2,6,7, 12,10, 14,8, 13,9,11))
       BEGIN
       UPDATE [TCD].ControllerEquipmentSetup          
         SET ProductId      =   @ProductId          
         , IsActive      =   @IsActive          
         , LfsChemicalName    =   NULL         
         , KFactor      =   NULL   
         , PumpCalibration    =   NULL  
				
         , TunnelHold     =    NULL       
         , FlowDetectorType    = NULL   
         , FlowSwitchNumber    =    @FlowSwitchNumber  
         , FlowSwitchAlarm    =    NULL        
         , FlowMeterAlarm     =    NULL        
         , FlowMeterType     =   NULL           
         , FlowAlarmDelay     =  NULL          
         , FlowMeterPumpDelay    =    NULL          
         , FlowMeterAlarmDelay    =    NULL          
         , ControllerEquipmentTypeModelId =    NULL           
             , ConventionalWasherGroupConnection =   0      
             , AxillaryPumpCalibration   =    0           
             , FlowmeterSwitchActivated   =   0           
             , FlushWhileDosing     =    0           
             , WeightControlledDosage    =  0           
             , EquipmentDoseAlone       =   0           
             , LowLevelAlarm          =    0           
             , LeakageAlarm          =   0           
             , FlushTime         =  NULL           
             , PumpingTime        =    NULL           
             , PreFlushTime        =    NULL           
             , NightFlushPauseTime       =    NULL           
             , NightFlushTime        =     NULL           
             , AcceptedDeviation       =     NULL           
             , LineNumber        =  0           
             , MaximumDosingTime    =   NULL           
         , FlowSwitchTimeOut    =    NULL        
        , ValveOutputAsTom               =   0         

         , LastModifiedByUserId   =   @UserId          
        --** Adding a part of integration with Synch./Central -->          
         , LastModifiedTime    =   @CurrentUTCTime                  
       , FlushValveNumber  =    NULL           
 , CalibrationConductSS_Tank =    NULL         
       , BackFlowControl  =   'False'           
       , FactorFM_B_FM   =    NULL            
       , AcceptedDeviationRingLine =   NULL         
       , UsePumpOfGroup1ForTunnel =   NULL        
       , pHSensorEnabled    =  NULL      
    , FlushTimeForFlushValve = @FlushTimeForFlushValve   
       , Concentration =   NULL        
       , Deadband    =    NULL       
       , MinimumFlowRate =  NULL 
       , ProductDensity =  NULL 
       , MaximumConcentration =  NULL 
        OUTPUT inserted.ControllerEquipmentSetupId   AS   ControllerEquipmentSetupId          
         , inserted.LastModifiedTime     AS   LastModifiedTime          
        INTO @OutputList (          
										ControllerEquipmentSetupId
         , LastModifiedTimestamp          
									)
        --** <--          
        WHERE ControllerId    =   @ControllerId          
        AND ControllerEquipmentId   =   @ControllerEquipmentId          
        AND EcoLabAccountNumber    =   @EcoLabAccountNumber           
        END
        
        SET @ErrorId = @@ERROR          

        IF (@ErrorId <> 0)          
									BEGIN
          IF @@TRANCOUNT > 0          
											ROLLBACK

          SET  @ErrorMessage  = N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating Equipment data'          
          --GOTO Errorhandler          
          RAISERROR (@ErrorMessage, 16, 1)          
          SET @ReturnValue = -1          
          RETURN (@ReturnValue)          
									END							
							
        SELECT TOP 1          
          @OutputControllerEquipmentSetupId = O.ControllerEquipmentSetupId          
        FROM @OutputList   O          

        IF @@TRANCOUNT > 0          
									COMMIT
      END TRY          
      BEGIN CATCH          
        IF @@TRANCOUNT > 0          
									ROLLBACK
							
        SELECT /*@ErrorNumber    =  ERROR_NUMBER()          
         , */@ErrorMessage    =  ERROR_MESSAGE()          
         , @ErrorProcedure    =  ERROR_PROCEDURE()          
         , @ErrorSeverity    =  ERROR_SEVERITY()          
							
        SET  @OutputControllerEquipmentSetupId          
                 =  NULL          
        SET  @ReturnValue    =  -1          
        SET  @MessageString    =  N'An error occured while Updating Pump/Valve details. The error is: '          
                 +  @ErrorMessage + ' '          
                 +  'Module: ' + @ErrorProcedure          
							
								RAISERROR(@MessageString, @ErrorSeverity, 1)
      END CATCH          
					END
		END
ELSE
		BEGIN
				DECLARE @NewPumpId INT = NULL
    SELECT @DistinctChemicalCount    =   COUNT(DISTINCT D.ProductId) --distinct count          
    FROM (          
      SELECT @ProductId     AS   ProductId     --being assigned          
						UNION
      SELECT DISTINCT ProductId  AS   ProductId     --already assigned          
      FROM [TCD].ControllerEquipmentSetup          
      WHERE ControllerId    =   @ControllerId          
       AND ProductId     <>   @ProductId          
      ) D          

    IF ( @DistinctChemicalCount > @MaximumChemicalCount )          
				BEGIN
      SET @ErrorId   = 51000          
      SET @ErrorMessage  = N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Maximum chemical count exceeded. Cannot assign new chemical'          
      --GOTO ErrorHandler          
      RAISERROR (@ErrorMessage, 16, 1)          
      SET @ReturnValue = -1          
      RETURN (@ReturnValue)          
				END				 
				ELSE
					BEGIN
      BEGIN TRY          
        BEGIN TRAN          

        INSERT [TCD].ControllerEquipmentSetup  (          
             EcoLabAccountNumber          
        ,    ControllerId          
        ,    ControllerEquipmentId          
        ,    ControllerEquipmentTypeId          
        ,    ProductId          
        ,    IsActive          
        ,    LfsChemicalName          
        ,    KFactor          
        ,    PumpCalibration          
        ,    TunnelHold          
        ,    FlowDetectorType     
        ,     FlowSwitchNumber       
        ,    FlowSwitchAlarm          
        ,    FlowMeterAlarm          
        ,    FlowMeterType          
        ,    FlowAlarmDelay          
        ,    FlowMeterPumpDelay          
        ,    FlowMeterAlarmDelay          
        , ControllerEquipmentTypeModelId           
        , ConventionalWasherGroupConnection           
        , AxillaryPumpCalibration             
        , FlowmeterSwitchActivated             
        , FlushWhileDosing               
        , WeightControlledDosage              
        , EquipmentDoseAlone                 
        , LowLevelAlarm                    
        , LeakageAlarm                    
        , FlushTime                   
        , PumpingTime                  
        , PreFlushTime                  
        , NightFlushPauseTime                 
        , NightFlushTime                  
        , AcceptedDeviation                 
        , LineNumber                 
        , MaximumDosingTime              
        , FlowSwitchTimeOut   
       , ValveOutputAsTom         
        , LastModifiedByUserId            
       --** Adding a part of integration with Synch./Central -->          
        , LastModifiedTime          
        , FlushValveNumber              
       , CalibrationConductSS_Tank           
       , BackFlowControl                
       , FactorFM_B_FM                    
       , AcceptedDeviationRingLine           
       , UsePumpOfGroup1ForTunnel             
       , pHSensorEnabled      
    , FlushTimeForFlushValve    
       , Concentration       
       , Deadband      
        , MinimumFlowRate 
  , ProductDensity 
  , MaximumConcentration
								)
       OUTPUT inserted.ControllerEquipmentSetupId   AS   ControllerEquipmentSetupId          
        , inserted.LastModifiedTime     AS   LastModifiedTime          
       INTO @OutputList (          
									ControllerEquipmentSetupId
        , LastModifiedTimestamp          
								)
       --** <--          
       SELECT @EcoLabAccountNumber    AS   EcoLabAccountNUmber          
        , @ControllerId      AS   ControllerEquipmentId          
        , @ControllerEquipmentId    AS   ControllerEquipmentId          
        , @ControllerEquipmentTypeId   AS   ControllerEquipmentTypeId          
        , @ProductId      AS   ProductId          
        , @IsActive       AS   IsActive          

        , LfsChemicalName     =   CASE @IsActive WHEN 'TRUE' THEN @LfsChemicalName   ELSE NULL END          
        , KFactor       =   CASE @IsActive WHEN 'TRUE' THEN @KFactor     ELSE NULL END          
        , PumpCalibration     =   CASE @IsActive WHEN 'TRUE' THEN @PumpCalibration   ELSE NULL END          
				
        , TunnelHold      =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @TunnelHold   ELSE NULL END ELSE NULL END          
        , FlowDetectorType     =   CASE @IsActive WHEN 'TRUE' THEN CASE WHEN @ControllerTypeId IN (2,6,7, 12,10, 14,8, 13,9,11) THEN @FlowDetectorType  ELSE NULL END ELSE NULL END          
        , FlowSwitchNumber        =    @FlowSwitchNumber  
        , FlowSwitchAlarm     =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowSwitchAlarm  ELSE NULL END ELSE NULL END          
      , FlowMeterAlarm      =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterAlarm  ELSE NULL END ELSE NULL END          
        , FlowMeterType      =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterType   ELSE NULL END ELSE NULL END          
        , FlowAlarmDelay      =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowAlarmDelay  ELSE NULL END ELSE NULL END          
        , FlowMeterPumpDelay     =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterPumpDelay  ELSE NULL END ELSE NULL END          
        , FlowMeterAlarmDelay     =   CASE @IsActive WHEN 'TRUE' THEN CASE @ControllerTypeId WHEN 2 THEN @FlowMeterAlarmDelay ELSE NULL END ELSE NULL END          
        , ControllerEquipmentTypeModelId  =   CASE @IsActive WHEN 'TRUE' THEN @ControllerEquipmentTypeModelId      ELSE NULL END          
        , ConventionalWasherGroupConnection      =   CASE @IsActive WHEN 'TRUE' THEN @ConventionalWasherGroupConnection  ELSE 0 END          
        , AxillaryPumpCalibration        =   CASE @IsActive WHEN 'TRUE' THEN @AxillaryPumpCalibration    ELSE 0 END          
        , FlowmeterSwitchActivated        =   CASE @IsActive WHEN 'TRUE' THEN @FlowmeterSwitchActivated   ELSE 0 END          
        , FlushWhileDosing          =   CASE @IsActive WHEN 'TRUE' THEN @FlushWhileDosing      ELSE 0 END          
        , WeightControlledDosage         =   CASE @IsActive WHEN 'TRUE' THEN @WeightControlledDosage     ELSE 0 END          
        , EquipmentDoseAlone            =   CASE @IsActive WHEN 'TRUE' THEN @EquipmentDoseAlone        ELSE 0 END          
        , LowLevelAlarm               =   CASE @IsActive WHEN 'TRUE' THEN @LowLevelAlarm           ELSE 0 END          
        , LeakageAlarm               =   CASE @IsActive WHEN 'TRUE' THEN @LeakageAlarm           ELSE 0 END          
        , FlushTime              =   CASE @IsActive WHEN 'TRUE' THEN @FlushTime         ELSE NULL END          
        , PumpingTime             =   CASE @IsActive WHEN 'TRUE' THEN @PumpingTime         ELSE NULL END          
        , PreFlushTime             =   CASE @IsActive WHEN 'TRUE' THEN @PreFlushTime         ELSE NULL END          
        , NightFlushPauseTime            =   CASE @IsActive WHEN 'TRUE' THEN @NightFlushPauseTime       ELSE NULL END          
        , NightFlushTime             =   CASE @IsActive WHEN 'TRUE' THEN @NightFlushTime  ELSE NULL END          
        , AcceptedDeviation            =   CASE @IsActive WHEN 'TRUE' THEN @AcceptedDeviation        ELSE NULL END          
        , LineNumber           =   CASE @IsActive WHEN 'TRUE' THEN @LineNumber           ELSE NULL END          
        , MaximumDosingTime         =   CASE @IsActive WHEN 'TRUE' THEN @MaximumDosingTime     ELSE NULL END          
        , FlowSwitchTimeOut     =   CASE @IsActive WHEN 'TRUE' THEN @FlowSwitchTimeOut     ELSE NULL END         
       , ValveOutputAsTom               =   CASE @IsActive WHEN 'TRUE' THEN @ValveOutputAsTom           ELSE 0 END                       
        , @UserId        AS   LastModifiedByUserId          
								--Synch./Central integration additions
        , @CurrentUTCTime      AS   LastModifiedTime          
       , FlushValveNumber  =   CASE @IsActive WHEN 'TRUE' THEN @FlushValveNumber     ELSE NULL END           
       , CalibrationConductSS_Tank =   CASE @IsActive WHEN 'TRUE' THEN @CalibrationConductSS_Tank     ELSE NULL END         
       , BackFlowControl  =   CASE @IsActive WHEN 'TRUE' THEN @BackFlowControl     ELSE 'False' END            
       , FactorFM_B_FM   =   CASE @IsActive WHEN 'TRUE' THEN @FactorFM_B_FM     ELSE NULL END                
       , AcceptedDeviationRingLine =   CASE @IsActive WHEN 'TRUE' THEN @AcceptedDeviationRingLine     ELSE NULL END           
       , UsePumpOfGroup1ForTunnel =   CASE @IsActive WHEN 'TRUE' THEN @UsePumpOfGroup1ForTunnel     ELSE 'FALSE' END             
       , pHSensorEnabled    =   CASE @IsActive WHEN 'TRUE' THEN @pHSensorEnabled     ELSE 'FALSE' END    
    , FlushTimeForFlushValve = @FlushTimeForFlushValve     
       , Concentration =   CASE @IsActive WHEN 'TRUE' THEN @Concentration     ELSE NULL END             
       , Deadband    =   CASE @IsActive WHEN 'TRUE' THEN @Deadband     ELSE NULL END       
        , MinimumFlowRate = CASE @IsActive WHEN 'TRUE' THEN @MinimumFlowRate     ELSE NULL END  
       , ProductDensity = CASE @IsActive WHEN 'TRUE' THEN @ProductDensity     ELSE NULL END
       , MaximumConcentration = CASE @IsActive WHEN 'TRUE' THEN @MaximumConcentration     ELSE NULL END 
								SET @NewPumpId = SCOPE_IDENTITY() 								
        SET @ErrorId = @@ERROR          
        IF (@ErrorId <> 0)          
									BEGIN
          IF @@TRANCOUNT >0          
											ROLLBACK

          SET  @ErrorMessage  = N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred associating Equipment to Controller'          
          --GOTO Errorhandler          
          RAISERROR (@ErrorMessage, 16, 1)          
          SET @ReturnValue = -1      
         RETURN (@ReturnValue)          
							END

        SELECT TOP 1          
          @OutputControllerEquipmentSetupId = O.ControllerEquipmentSetupId          
        FROM @OutputList   O          

        IF @@TRANCOUNT > 0          
									COMMIT
      END TRY          
      BEGIN CATCH          
        IF @@TRANCOUNT > 0          
									ROLLBACK
							
        SELECT /*@ErrorNumber    =  ERROR_NUMBER()          
         , */@ErrorMessage    =  ERROR_MESSAGE()          
         , @ErrorProcedure    =  ERROR_PROCEDURE()          
         , @ErrorSeverity    =  ERROR_SEVERITY()          
							
        SET  @OutputControllerEquipmentSetupId          
                 =  NULL          
        SET  @ReturnValue    =  -1          
        SET  @MessageString    =  N'An error occured while Updating Pump/Valve details. The error is: '          
                 +  @ErrorMessage + ' '          
                 +  'Module: ' + @ErrorProcedure          
							
								RAISERROR(@MessageString, @ErrorSeverity, 1)
      END CATCH          
     END          
  END          
     
  -------------------------------------------
  IF((SELECT CONTROLLERMODELID FROM TCD.ConduitController WHERE ControllerId=@ControllerId)='11')
  BEGIN
	IF(@ControllerEquipmentTypeId=2 AND @ControllerEquipmentId IN(13,14,27,28))
	BEGIN

		UPDATE TCD.ControllerEquipmentSetup  SET CalibrationConductSS_Tank=@CalibrationConductSS_Tank
		WHERE EcoLabAccountNumber=@EcoLabAccountNumber AND	ControllerId=@ControllerId AND ControllerEquipmentTypeId=@ControllerEquipmentTypeId
		AND ControllerEquipmentId=CASE WHEN @ControllerEquipmentId=13 THEN 27 
								   WHEN @ControllerEquipmentId=27 THEN 13  	
								   WHEN @ControllerEquipmentId=14 THEN 28
								   WHEN @ControllerEquipmentId=28 THEN 14 END 
					END
		END
  -------------------------------------------

  IF ( @ErrorId = 0 )          
	BEGIN
  --GOTO ExitModule          
  RETURN (@ReturnValue)          
	END
SET NOCOUNT OFF          
RETURN (@ReturnValue)
END