﻿/*	                                   
###################################################################################################                                           

Stored Procedure:       [TCD].[GetBatchProductData]                                            

Purpose:				To Get The Batch Product Data.

Parameters:				@BatchID- to get the batch product data of a particular batchId.
																
###################################################################################################                                           
*/
CREATE PROCEDURE [TCD].[GetBatchProductData]
	-- Add the parameters for the stored procedure here
	@BatchID Int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT PD.BatchID, PD.BatchWashStepId,PD.ProductID,PD.ActualQuantity, PD.StandardQuantity, PD.Price FROM BatchProductData PD
	WHERE
	BatchId=@BatchID
END
