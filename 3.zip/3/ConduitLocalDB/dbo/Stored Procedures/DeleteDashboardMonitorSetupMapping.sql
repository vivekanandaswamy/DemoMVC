  
CREATE PROCEDURE [TCD].[DeleteDashboardMonitorSetupMapping]   
(     
   
   @DashboardId INT = NULL,  
   @EcolabAccountNumber nvarchar(25)
   
)   
AS   
BEGIN  
SET NOCOUNT ON		
			DELETE FROM [TCD].MonitorSetUpMapping WHERE DashboardId = @DashboardId AND EcolabAccountNumber = @EcolabAccountNumber  
			DELETE FROM [TCD].Dashboard WHERE DashboardId = @DashboardId AND EcolabAccountNumber = @EcolabAccountNumber  
SET NOCOUNT OFF       
END  


