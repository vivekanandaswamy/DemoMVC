﻿CREATE PROCEDURE [TCD].[GetBatchTrendingGroupData](
	@GroupId INT)
AS
	SET NOCOUNT ON;
	BEGIN
	    DECLARE @DayId               VARCHAR(20) = NULL,
			  @StartTime           DATETIME    = NULL,
			  @EndTime             DATETIME    = NULL,
			  @TransferStarttime   TIME        = NULL,
			  @TransferEndtime     TIME        = NULL,
			  @MachineId           INT         = NULL,
			  @ParameterId         INT         = NULL,
			  @ParameterValue      INT         = NULL,
			  @WasherStatus        INT,
			  @RegionId            INT         = NULL,
			  @EcoLabAccountNumber nvarchar(25) = NULL,
			  @ControllerID        INT,
			  @ControllerModel     INT,
			  @NoofComp            INT         = NULL,
			  @Count               INT         = 1;
	    SELECT
			 @NoOfcomp = NumberOfComp,
			 @ControllerID = ControllerID
	    FROM [TCD].machinesetup
	    WHERE Groupid = @GroupId
			AND IsTunnel = 1;
	    SELECT
			 @ControllerModel = csd.ControllerModelId
	    FROM tcd.ControllerSetupData csd
	    WHERE csd.ControllerId = @ControllerID;
	    DECLARE @GET_COMPARTMENT TABLE
	    (
		    GroupId           INT,
		    MachineID         INT,
		    CompartmentNumber VARCHAR(1000)
	    );
	    WHILE(@count <= @NoOfcomp)
		   BEGIN
			  INSERT INTO @GET_COMPARTMENT
			  (
				    GroupId,
				    MachineID,
				    CompartmentNumber
			  )
			  SELECT
				    @GroupId,
				    @count,
				    'Compartment'+CAST(@count AS VARCHAR(1000))+'';
			  SET @count = @count + 1;
		   END;
	    DECLARE @TrendingData TABLE
	    (
		    BatchId       INT,
		    CustomerId    INT,
		    ProgramId     INT,
		    ActualLoad    DECIMAL(10, 2),
		    NominalLoad   DECIMAL(10, 2),
		    GroupId       INT,
		    CompartmentId INT,
		    --DupCount INT,
		    Efficiency    DECIMAL(10, 2),
		    Temparature   DECIMAL(10, 2),
		    Conductivity  DECIMAL(10, 2),
		    PH            DECIMAL(10, 2)
	    );
	    DECLARE @DummyTrendingData TABLE
	    (
		    BatchId       INT,
		    CustomerId    INT,
		    ProgramId     INT,
		    ActualLoad    DECIMAL(10, 2),
		    NominalLoad   DECIMAL(10, 2),
		    GroupId       INT,
		    CompartmentId INT,
		    --DupCount INT,
		    Efficiency    DECIMAL(10, 2),
		    Temparature   DECIMAL(10, 2),
		    Conductivity  DECIMAL(10, 2),
		    PH            DECIMAL(10, 2)
	    );
	    INSERT INTO @DummyTrendingData
	    (
			 BatchId,
			 CustomerId,
			 ProgramId,
			 ActualLoad,
			 NominalLoad,
			 GroupId,
			 CompartmentId,
			 Efficiency,
			 Temparature,
			 Conductivity,
			 PH
	    )
	    SELECT
			 0,
			 0,
			 0,
			 0,
			 0,
			 GroupId,
			 MachineID,
			 0,
			 0,
			 0,
			 0
	    FROM @GET_COMPARTMENT;
	    SELECT
			 @MachineId = WasherId,
			 @EcoLabAccountNumber = EcoalabAccountNumber
	    FROM tcd.MachineSetup
	    WHERE GroupId = @GroupId;
	    SELECT TOP 1
			 @ParameterId = ParameterId,
			 @Parametervalue = ParameterValue
	    FROM TCD.washerReading
	    WHERE WasherId = @MachineId
	    ORDER BY
			   DateTimeStamp DESC;
	    SELECT TOP 1
			 @RegionId = RegionId
	    FROM TCD.Plant
	    WHERE EcolabAccountNumber = @EcoLabAccountNumber;
	    IF(@ControllerModel <> 7
		  AND @RegionId = 1)   --NA  @ControllerModelID <> 7 AND @RegionId = 1
		   BEGIN
			  INSERT INTO @TrendingData
			  (
				    BatchId,
				    CustomerId,
				    ProgramId,
				    ActualLoad,
				    NominalLoad,
				    GroupId,
				    CompartmentId,
				    --DupCount INT,
				    Efficiency,
				    Temparature,
				    Conductivity,
				    PH
			  )
			  SELECT DISTINCT
				    BA.BatchId,
				    BC.CustomerId,
				    BA.ProgramNumber,
				    BA.[ActualWeight],
				    BA.[StandardWeight],
				    BA.GroupId,
				    BS.StepCompartment,
				    CASE
					   WHEN BA.[StandardWeight] <> 0
					   THEN(BA.[ActualWeight] / BA.[StandardWeight])
					   * 100
					   ELSE 0
				    END AS        LoadEfficiency,
				    --(BA.[ActualWeight]/BA.[StandardWeight]) * 100 AS LoadEfficiency,
				    TE.Reading AS Temparature,
				    CO.Reading AS Conductivity,
				    PH.Reading AS PH
			  FROM [TCD].BatchWashStepData AS BS
				  INNER JOIN [TCD].BatchData BA ON BA.BatchId = BS.
				  BatchId
				  LEFT OUTER JOIN [TCD].BatchCustomerData BC ON BC.
				  BatchId = BA.BatchId
				  LEFT OUTER JOIN
			  (
				 SELECT
					   SS.GroupId,
					   SS.MachineCompartment,
					   MR.Reading
				 FROM TCD.ModuleReading MR
					 INNER JOIN TCD.Sensor SS ON MR.ModuleId = SS.
					 SensorId
				 WHERE MR.ModuleTypeId = 3
					  AND SS.SensorType = 1
			  ) TE ON BA.GroupId = TE.GroupId
					AND BS.StepCompartment = TE.MachineCompartment
				  LEFT OUTER JOIN
			  (
				 SELECT
					   SS.GroupId,
					   SS.MachineCompartment,
					   MR.Reading
				 FROM TCD.ModuleReading MR
					 INNER JOIN TCD.Sensor SS ON MR.ModuleId = SS.
					 SensorId
				 WHERE MR.ModuleTypeId = 3
					  AND SS.SensorType = 4
			  ) CO ON BA.GroupId = CO.GroupId
					AND BS.StepCompartment = CO.MachineCompartment
				  LEFT OUTER JOIN
			  (
				 SELECT
					   SS.GroupId,
					   SS.MachineCompartment,
					   MR.Reading
				 FROM TCD.ModuleReading MR
					 INNER JOIN TCD.Sensor SS ON MR.ModuleId = SS.
					 SensorId
				 WHERE MR.ModuleTypeId = 3
					  AND SS.SensorType = 2
			  ) PH ON BA.GroupId = CO.GroupId
					AND BS.StepCompartment = CO.MachineCompartment
			  WHERE BS.EndTime IS NULL
				   AND BA.EndDate IS NULL
				   AND BA.GroupId = @GroupId; 
			  --AND BA.StandardWeight > 0  
			  --AND BA.ActualWeight > 0 


			  IF(@ParameterId = 6
				AND @Parametervalue = 0)
				 BEGIN
					SET @WasherStatus = 1;
				 END;
			  ELSE
			  IF(@ParameterId = 6
				AND @Parametervalue = 1)
				 BEGIN
					SET @WasherStatus = 2;
				 END;
			  ELSE
			  IF(@ParameterId = 12)
				 BEGIN
					SET @WasherStatus = 0;
				 END;;
			  IF(@WasherStatus != 2)
				 BEGIN
					UPDATE D
					  SET
						 D.BatchId = C.BatchId,
						 D.CustomerId = CASE
										WHEN C.ActualLoad = 0
										THEN 0
										ELSE C.CustomerId
									 END,
						 D.ProgramId = C.ProgramId,
						 D.ActualLoad = C.ActualLoad,
						 D.NominalLoad = C.NominalLoad,
						 D.GroupId = CASE
									  WHEN C.GroupId = 0
									  THEN C.GroupId
									  ELSE D.GroupId
								   END,
						 D.CompartmentId = CASE
										   WHEN C.CompartmentId
										   IS NOT NULL
										   THEN C.CompartmentId
										   ELSE D.CompartmentId
									    END,
						 D.Efficiency = CAST(C.Efficiency AS DECIMAL
						 (10, 2)),
						 D.Temparature = CAST(C.Temparature AS
						 DECIMAL(10, 2)),
						 D.Conductivity = CAST(C.Conductivity AS
						 DECIMAL(10, 2)),
						 D.PH = CAST(C.PH AS DECIMAL(10, 2))
					FROM @DummyTrendingData D
						LEFT OUTER JOIN @TrendingData C ON D.
						CompartmentId = C.CompartmentId;
				 END;
		   END;
	    ELSE --EU   (@ControllerModelID = 7 AND @RegionId = 1) OR (@ControllerModelID <> 7 and @RegionId = 2)
		   BEGIN
			  INSERT INTO @TrendingData
			  (
				    --BatchId,
				    CustomerId,
				    ProgramId,
				    ActualLoad,
				    NominalLoad,
				    GroupId,
				    CompartmentId,
				    --DupCount INT,
				    Efficiency,
				    Temparature,
				    Conductivity,
				    PH
			  )
			  SELECT DISTINCT
				    obd.CustomerNumber,
				    obd.ProgramNumber,
				    obd.ActualWeight,
				    obd.StandardWeight,
				    obd.GroupId,
				    obd.CompartmentNumber,
				    CASE
					   WHEN obd.StandardWeight <> 0
					   THEN(obd.ActualWeight / obd.StandardWeight) *
					   100
					   ELSE 0
				    END AS        LoadEfficiency,
				    TE.Reading AS Temparature,
				    CO.Reading AS Conductivity,
				    PH.Reading AS PH
			  FROM [TCD].OnlineBatchData obd
				  LEFT OUTER JOIN
			  (
				 SELECT
					   SS.GroupId,
					   SS.MachineCompartment,
					   MR.Reading
				 FROM TCD.ModuleReading MR
					 INNER JOIN TCD.Sensor SS ON MR.ModuleId = SS.
					 SensorId
				 WHERE MR.ModuleTypeId = 3
					  AND SS.SensorType = 1
			  ) TE ON obd.GroupId = TE.GroupId
					AND obd.CompartmentNumber = TE.MachineCompartment
				  LEFT OUTER JOIN
			  (
				 SELECT
					   SS.GroupId,
					   SS.MachineCompartment,
					   MR.Reading
				 FROM TCD.ModuleReading MR
					 INNER JOIN TCD.Sensor SS ON MR.ModuleId = SS.
					 SensorId
				 WHERE MR.ModuleTypeId = 3
					  AND SS.SensorType = 4
			  ) CO ON obd.GroupId = CO.GroupId
					AND obd.CompartmentNumber = CO.MachineCompartment
				  LEFT OUTER JOIN
			  (
				 SELECT
					   SS.GroupId,
					   SS.MachineCompartment,
					   MR.Reading
				 FROM TCD.ModuleReading MR
					 INNER JOIN TCD.Sensor SS ON MR.ModuleId = SS.
					 SensorId
				 WHERE MR.ModuleTypeId = 3
					  AND SS.SensorType = 2
			  ) PH ON obd.GroupId = CO.GroupId
					AND obd.CompartmentNumber = CO.MachineCompartment
			  WHERE --BS.EndTime IS NULL
			  obd.GroupId = @GroupId;
			  UPDATE D
			    SET
				   D.BatchId = C.BatchId,
				   D.CustomerId =  C.CustomerId,
				   D.ProgramId = C.ProgramId,
				   D.ActualLoad = C.ActualLoad,
				   D.NominalLoad = C.NominalLoad,
				   D.GroupId = CASE
							    WHEN C.GroupId = 0
							    THEN C.GroupId
							    ELSE D.GroupId
							END,
				   D.CompartmentId = CASE
									WHEN C.CompartmentId IS NOT
									NULL
									THEN C.CompartmentId
									ELSE D.CompartmentId
								 END,
				   D.Efficiency = CAST(C.Efficiency AS DECIMAL(10, 2)),
				   D.Temparature = CAST(C.Temparature AS DECIMAL(10, 2)),
				   D.Conductivity = CAST(C.Conductivity AS DECIMAL(10,
				   2)),
				   D.PH = CAST(C.PH AS DECIMAL(10, 2))
			  FROM @DummyTrendingData D
				  LEFT OUTER JOIN @TrendingData C ON D.CompartmentId =
				  C.CompartmentId;
		   END;
	    SELECT
			 ISNULL(BatchId, 0) AS       BatchId,
			 ISNULL(CustomerId, 0) AS    CustomerId,
			 ISNULL(ProgramId, 0) AS     ProgramId,
			 (CASE
				 WHEN(@RegionId = 1)
				 THEN ISNULL(ActualLoad, 0)
				 ELSE ROUND((ISNULL(ActualLoad, 0) * 0.453592), 0)
			  END) AS                    ActualLoad,
			 (CASE
				 WHEN(@RegionId = 1)
				 THEN ISNULL(NominalLoad, 0)
				 ELSE ROUND((ISNULL(NominalLoad, 0) * 0.453592), 0)
			  END) AS                    NominalLoad,
			 ISNULL(GroupId, 0) AS       GroupId,
			 ISNULL(CompartmentId, 0) AS CompartmentId,
			 ISNULL(Efficiency, 0) AS    Efficiency,
			 ISNULL(Temparature, 0) AS   Temparature,
			 ISNULL(Conductivity, 0) AS  Conductivity,
			 ISNULL(PH, 0) AS            PH
	    FROM @DummyTrendingData;
	END;
	