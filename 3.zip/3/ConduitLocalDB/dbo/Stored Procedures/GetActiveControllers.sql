﻿CREATE PROCEDURE [TCD].[GetActiveControllers]
 AS
BEGIN

SET NOCOUNT ON              --SQLEnlight SA0017

  DECLARE @TempControllerFields TABLE
  (
    ControllerId INT,
    OpcServer INT,
    IpAddress INT,
	AMSNetIDAddress INT,
    ComportNumber INT,
    WebportFtpEnabled INT,
    WebportIP INT,
    WebportLogin INT,
    WebportPassword INT
  )
  INSERT INTO @TempControllerFields
  (  
    ControllerId ,
    OpcServer ,
    IpAddress ,
	AMSNetIDAddress,
    ComportNumber ,
    WebportFtpEnabled ,
    WebportIP ,
    WebportLogin ,
    WebportPassword
  )
  SELECT distinct
    Csd.ControllerId,
    max(case when Fld.Label = 'OPC Server' then Fld.Id end) OpcServer,
	max(case when Fld.Label = 'IP Address' then Fld.Id end) IpAddress,
    max(case when Fld.Label = 'AMS Net ID Address' then Fld.Id end) AMSNetIDAddress,
    max(case when Fld.Label = 'Com port Number' then Fld.Id end) ComportNumber,
    max(case when Fld.Label = 'Webport Ftp Enabled' then Fld.Id end) WebportFtpEnabled,
    max(case when Fld.Label = 'Webport IP' then Fld.Id end) WebportIP,
    max(case when Fld.Label = 'Webport Login' then Fld.Id end) WebportLogin,
    max(case when Fld.Label = 'Webport Password' then Fld.Id end) WebportPassword 
  FROM TCD.Field Fld
    INNER JOIN 
      TCD.ControllerSetupData Csd 
      ON Csd.FieldId=Fld.Id
  GROUP BY Csd.ControllerId

  SELECT DISTINCT 
      P.RegionID as RegionID,      
      Ctrl.ControllerId,
      Ctrl.EcoalabAccountNumber,
      Ctrl.ControllerTypeId,
      Ctrl.Name,
      CASE WHEN (CsdOpc.Value IS NULL) THEN NULL 
        ELSE CsdOpc.Value END 
        AS OpcServerName,
      CASE WHEN (CsdIP.Value IS NULL) THEN NULL 
        ELSE CsdIP.Value END 
        AS IpAddress,
	 CASE WHEN (CsdAMSId.Value IS NULL) THEN NULL 
        ELSE CsdAMSId.Value END 
        AS AMSNetIDAddress,
      CASE WHEN (CsdComport.Value IS NULL) THEN NULL 
        ELSE CsdComport.Value END 
        AS ComportNumber,
      CASE WHEN (CsdWebFtp.Value IS NULL) THEN NULL
         WHEN CsdWebFtp.Value = 'False' THEN 0 
        WHEN CsdWebFtp.Value = 'True' THEN 1  
        END 
        AS WebportFtpEnabled,
      CASE WHEN (CsdWebIP.Value IS NULL) THEN NULL 
        ELSE CsdWebIP.Value END 
        AS WebportIP,
      CASE WHEN (CsdWebLogin.Value IS NULL) THEN NULL 
        ELSE CsdWebLogin.Value END 
        AS WebportLogin,
      CASE WHEN (CsdWebPwd.Value IS NULL) THEN NULL 
        ELSE CsdWebPwd.Value END 
        AS WebportPassword,
      Ctrl.ControllerModelId,
      Ctrl.TopicName,
      Ctrl.WebportReadTime
   FROM  TCD.ConduitController Ctrl 
   INNER JOIN 
      @TempControllerFields Tcf 
      ON Tcf.ControllerId=Ctrl.ControllerId
   INNER JOIN 
      Plant P
      ON P.EcolabAccountNumber=Ctrl.EcoalabAccountNumber
   LEFT JOIN 
      TCD.ControllerSetupData CsdOpc 
      ON CsdOpc.FieldId = Tcf.OPCServer 
      AND CsdOpc.ControllerId = Ctrl.ControllerId
   LEFT JOIN 
      tcd.ControllerSetupData CsdIp 
      ON CsdIp.FieldId=Tcf.IpAddress 
      AND CsdIp.ControllerId = Ctrl.ControllerId
  LEFT JOIN 
      tcd.ControllerSetupData CsdAMSId 
      ON CsdAMSId.FieldId=Tcf.AMSNetIDAddress 
      AND CsdAMSId.ControllerId = Ctrl.ControllerId
   LEFT JOIN 
      TCD.ControllerSetupData CsdComport 
      ON CsdComport.FieldId=Tcf.ComportNumber 
      AND CsdComport.ControllerId = Ctrl.ControllerId
   LEFT JOIN 
      TCD.ControllerSetupData CsdWebFtp 
      ON CsdWebFtp.FieldId=Tcf.WebportFtpEnabled 
      AND CsdWebFtp.ControllerId = Ctrl.ControllerId
   LEFT JOIN 
      TCD.ControllerSetupData CsdWebIP 
      ON CsdWebIP.FieldId=Tcf.WebportIP 
      AND CsdWebIP.ControllerId = Ctrl.ControllerId
   LEFT JOIN 
      TCD.ControllerSetupData CsdWebLogin 
      ON CsdWebLogin.FieldId=Tcf.WebportLogin 
      AND CsdWebLogin.ControllerId = Ctrl.ControllerId
   LEFT JOIN 
      TCD.ControllerSetupData CsdWebPwd 
      ON CsdWebPwd.FieldId=Tcf.WebportPassword 
      AND CsdWebPwd.ControllerId = Ctrl.ControllerId

   WHERE 
      Ctrl.Active=1 
    AND  Ctrl.IsDeleted=0

  
 END