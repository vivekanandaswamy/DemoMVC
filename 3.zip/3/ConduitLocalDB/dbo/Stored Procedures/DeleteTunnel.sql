﻿/*
Purpose	:To delete a Tunnel from the Washers grid UI
History	: Oct. 2014	dfozdar@allianceglobalservice.com initial version
*/
CREATE	PROCEDURE	[TCD].[DeleteTunnel]
					@EcoLabAccountNumber					NVARCHAR(25)
				,	@WasherId								INT
				,	@UserId									INT
				--Adding these 3 params as part of re-factoring for integration with Synch/Configurator
				,	@OutputTunnelId							INT			=			NULL	OUTPUT
				,	@OutputWasherGroupId					INT			=			NULL	OUTPUT	--since this marks t-WG 2 Formula association as deleted
				,	@LastModifiedTimestampAtCentral			DATETIME	=			NULL			--Nullable for local call; Synch/Central call will have to pass this -
																									--else, it will be treated as a local call
				,	@OutputLastModifiedTimestampAtLocal		DATETIME	=			NULL	OUTPUT
AS
BEGIN
SET	NOCOUNT	ON
DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	,	@WasherGroupId					INT				=			0
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()

--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
SET		@OutputLastModifiedTimestampAtLocal				=			@CurrentUTCTime
SET		@OutputTunnelId									=			ISNULL(@OutputTunnelId, NULL)			--SQLEnlight
SET		@OutputWasherGroupId							=			ISNULL(@OutputWasherGroupId, NULL)		--SQLEnlight


--If the call is not local, check that the LastModifiedTime matches with the central
IF	(@LastModifiedTimestampAtCentral IS NOT	NULL
			AND	NOT	EXISTS	(SELECT	1 FROM	TCD.[Washer] W
							WHERE	W.EcolabAccountNumber	=	@EcolabAccountNumber
							AND	W.WasherId				=	@WasherId
							AND	W.LastModifiedTime		=	@LastModifiedTimestampAtCentral )
	)
	BEGIN
			SET			@ErrorId					=	60000
			SET			@ErrorMessage				=	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
			RAISERROR	(@ErrorMessage, 16, 1)
			SET			@ReturnValue				=	-1
			RETURN		(@ReturnValue)
	END

--Proceed, since it's either a local call or Synch. call with synch. time matching

--Valid Washer - Id & Type...
IF	NOT	EXISTS	(	SELECT	1 FROM	[TCD].Washer W 
							JOIN	[TCD].MachineSetup	MS ON	W.WasherId = MS.WasherId AND	W.EcoLabAccountNumber = MS.EcoalabAccountNumber
					WHERE	W.EcoLabAccountNumber		=			@EcoLabAccountNumber
						AND	W.WasherId					=			@WasherId
						AND	MS.IsTunnel					=			'TRUE'
						AND	W.Is_Deleted				=			'FALSE'
						AND	MS.IsDeleted				=			'FALSE'
				)
			BEGIN
				SET		@ErrorId						=			51007
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Washer-ID or Type was provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END

--if valid, attempt to delete now...

--we will need tran, b'coz the data is spread across 2 tables...
SELECT @WasherGroupId = GroupId 
	FROM TCD.MachineSetup 
	Where WasherId = @WasherId

BEGIN	TRAN

UPDATE	W
	SET	W.Is_Deleted			=			'TRUE'
	,	W.LastModifiedByUserId	=			@UserId
	,	W.LastModifiedTime		=			@CurrentUTCTime
FROM	[TCD].Washer			W
JOIN	[TCD].MachineSetup		MS ON	W.WasherId = MS.WasherId
		AND	W.EcoLabAccountNumber	=	 MS.EcoalabAccountNumber
WHERE	W.EcoLabAccountNumber	=			@EcoLabAccountNumber
	AND	W.WasherId				=			@WasherId
	AND	W.Is_Deleted			=			'FALSE'
	AND	MS.IsDeleted			=			'FALSE'

-- Removing associated Formulas for the tunnel
UPDATE	TPS
	SET	Is_Deleted					=			'TRUE'
	,	LastModifiedByUserId		=			@UserId
FROM	[TCD].TunnelProgramSetup	TPS
WHERE	TPS.WasherGroupId			=			@WasherGroupId
	AND	TPS.EcolabAccountNumber		=			@EcoLabAccountNumber
	AND	TPS.Is_Deleted				=			'FALSE'

UPDATE A SET Is_Deleted =1
			,LastModifiedByUserId=@UserId
			,LastModifiedTime=@CurrentUTCTime
 FROM tcd.WasherFlushTime A
 WHERE WasherId=@WasherId

  UPDATE A SET Is_Deleted =1
   ,LastModifiedByUserId=@UserId
   ,LastModifiedTime=@CurrentUTCTime
 FROM tcd.WasherTimeOutMachine A
 WHERE WasherId=@WasherId

--check for any error
SET		@ErrorId				=			@@ERROR

--if any error, abort...
IF	(@ErrorId	<>	0)
	BEGIN
		--Rollback, if in tran
		IF	(@@TRANCOUNT	>	0)
			BEGIN
				ROLLBACK	TRAN
			END

		--Error-out...
		SET		@ErrorMessage				=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred deleting washer data.'
		--GOTO	Errorhandler
		RAISERROR	(@ErrorMessage, 16, 1)
		SET	@ReturnValue	=	-1
		RETURN	(@ReturnValue)
	END
--else, continue with the deletion in the 2nd table...

UPDATE	MS
	SET	MS.IsDeleted			=			'TRUE'
	,	MS.LastModifiedByUserId	=			@UserId
FROM	[TCD].MachineSetup			MS
JOIN	[TCD].Washer					W
	ON	MS.WasherId				=			W.WasherId
	AND	MS.EcoalabAccountNumber	=			W.EcoLabAccountNumber
WHERE	MS.WasherId				=			@WasherId
	AND	MS.EcoalabAccountNumber	=			@EcoLabAccountNumber
	AND	MS.IsDeleted			=			'FALSE'
	AND	W.Is_Deleted			=			'TRUE'


UPDATE TCD.WasherTags	 SET  Active =	0 	WHERE  WasherId		=	@WasherId
--check for any error
SET		@ErrorId				=			@@ERROR

--if any error, abort, else COMMIT the work...
IF	(@ErrorId	<>	0)
	BEGIN
		--Rollback, if in tran
		IF	(@@TRANCOUNT	>	0)
			BEGIN
				ROLLBACK	TRAN
			END

		--Error-out...
		SET		@ErrorMessage				=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred deleting washer data.'
		--GOTO	Errorhandler
		RAISERROR	(@ErrorMessage, 16, 1)
		SET	@ReturnValue	=	-1
		RETURN	(@ReturnValue)
	END
--else, continue with the deletion in the 2nd table...
ELSE
	BEGIN
		--COMMIT, if in tran
		IF	(@@TRANCOUNT	>	0)
			BEGIN
				COMMIT
			END
			--set Output variable for Synch./Central to consume 
		SET	@OutputTunnelId					=	@WasherId
		SET	@OutputWasherGroupId			=	@WasherGroupId
	END

IF	(@ErrorId	=	0)
	BEGIN
		--GOTO	ExitModule
		RETURN	(@ReturnValue)
	END

SET	NOCOUNT	OFF
RETURN	(@ReturnValue)


END
