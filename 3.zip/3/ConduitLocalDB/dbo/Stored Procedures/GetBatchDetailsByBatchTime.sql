CREATE PROCEDURE [TCD].[GetBatchDetailsByBatchTime] 
(
	 @BatchId INT,	 
	 @EcolabAccountNumber NVARCHAR(25) 
)
AS 
  BEGIN
  SET NOCOUNT ON

  SET	@EcolabAccountNumber			=			ISNULL(@EcolabAccountNumber, NULL)			--SQLEnlight SA0029

	  SELECT
				BatchId,				
				CAST(StartDate AS DATE) AS StartDate,
				CAST(StartDate AS TIME) AS StartDate,
				CASE 
						WHEN [ManualInputWeight] IS NOT NULL THEN CAST([ManualInputWeight] AS DECIMAL(18,2))
						ELSE [ActualWeight]
				END
				ActualWeight
      FROM [TCD].BatchData
	  WHERE
				BatchId = @BatchId					
  SET NOCOUNT OFF
  END