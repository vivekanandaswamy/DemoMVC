CREATE PROCEDURE [TCD].[GetInjectionDetails]
								(
								    @WasherGroupId Int = NULL 
								)
AS
SET NOCOUNT ON
BEGIN
DECLARE @WasherGroupNo INT
SELECT @WasherGroupNo = WG.WasherGroupNumber FROM TCD.WasherGroup WG WHERE WG.WasherGroupId = @WasherGroupId;

WITH CTE
AS
(
   SELECT 
			IJ.Id, 
		  IJ.WasherId,
		  IJ.WasherGroupNumber,
		  IJ.InjectionClass,
		  IJ.ControllerId,
		  IJ.ReferenceLoad,
		  WS.MaxLoad,
		  IJ.EcolabAccountNumber,
		  --WT.TagType,
		  (SELECT WT.TagAddress FROM TCD.WasherTags WT WHERE IJ.WasherId = WT.WasherId AND WT.TagType IN ('Tag_ICLAS') AND WT.Active = 1) AS InjectionClassTag,
		  (SELECT WT.TagAddress FROM TCD.WasherTags WT WHERE IJ.WasherId = WT.WasherId AND WT.TagType IN ('Tag_INJRO') AND WT.Active = 1) AS InjectionRatioTag
		  
			 FROM TCD.Injection IJ
			 INNER JOIN TCD.Washer WS ON IJ.WasherId = WS.WasherId
			 INNER JOIN TCD.ConduitController CC ON IJ.ControllerId = CC.ControllerId AND CC.IsDeleted = 0 --AND CC.Active = 1
				    WHERE WasherGroupNumber IS NOT NULL 
								AND WasherGroupNumber = @WasherGroupNo
)
    SELECT Id,
		WasherId,
		 WasherGroupNumber,
		 InjectionClass,
		 ControllerId,
		 ReferenceLoad,
		 MaxLoad, 
		 EcolabAccountNumber	,
		 InjectionClassTag,
		 InjectionRatioTag
				    FROM  CTE
						  WHERE (InjectionClassTag IS NOT NULL OR InjectionRatioTag IS NOT NULL)
END

--[TCD].[GetInjectionDetails] 23