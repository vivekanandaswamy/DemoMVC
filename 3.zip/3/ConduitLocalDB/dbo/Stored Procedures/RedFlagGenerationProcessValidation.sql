﻿ 
/*
Purpose					:	Generater Red flags for validation

Author: Suresh k
Date:28-Dec-2015

exe TCD.RedFlagGenerationProcessValidation 1,'2015-12-1','040242802'

*/
CREATE PROCEDURE [TCD].[RedFlagGenerationProcessValidation]
( @ShiftId int , 
                                                       @PartitionOn smalldatetime , 
                                                       @EcolabAccountNumber nvarchar( 25)
                                                     )
AS
BEGIN
 DECLARE
       @Value decimal( 18 , 3) , 
       @PlantId int;

    SELECT
            @PlantId = PlantId
      FROM TCD.Plant p
      WHERE p.EcolabAccountNumber = @EcolabAccountNumber;

    DECLARE
       @Redflag TABLE(
            CounterId int IDENTITY( 1 , 1) , 
            Id int , 
            Item int,
			MinimumRange decimal(18,2),
			MaximumRange decimal(18,2)
                     );

    DECLARE
       @MaxId int , 
       @Counter int , 
       @Item int , 
       @ShiftHrs int , 
       @Id int;

declare @MinValue decimal(18,2),@MaxValue decimal (18,2)

	

    INSERT INTO @Redflag(Id,
            Item,
			MinimumRange,
			MaximumRange
                        )
    SELECT
            rf.Id , 
            rf.Item,
			MinimumRange,
			MaximumRange
      FROM TCD.RedFlag rf
      WHERE rf.Is_Deleted = 0
        AND rf.RedFlagCategoryId in( 2,5);

    SELECT
            @MaxId = ISNULL( MAX( CounterId) , 0)
      FROM @Redflag r;

	
SELECT bd.*   
	INTO #BatchData  
	FROM tcd.BatchData bd (NOLOCK) 
	INNER JOIN TCD.MachineSetup ms  (NOLOCK)  on bd.MachineId=ms.WasherId AND   isnull(ms.IsPony,0)=0
	WHERE bd.ShiftId =@ShiftId 
	--AND bd.StandardWeight > 0  
	--and bd.ActualWeight > 0   
	and bd.EndDate IS NOT NULL

	declare @ActualWeight int

    SET @Counter = 1;

    WHILE @Counter   <= @MaxId
        BEGIN
            SELECT
                    @Id = Id , 
                    @Item = Item,
					@MinValue =MinimumRange, @MaxValue =MaximumRange
              FROM @Redflag r
              WHERE CounterId = @Counter;
		
			   IF @Item = 5
                BEGIN
				--Rewash Rate (% per shift) 
					
				  SELECT @ActualWeight = sum(bd.ActualWeight)
				  FROM  #BatchData bd 
						INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1) 
														AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0)AND rf.Is_Deleted = 0							
					   LEFT JOIN tcd.RedFlagMappingData rfmd
					   ON rf.Id = rfmd.MappingId
					  AND rfmd.Is_Deleted = 0
				  WHERE (bd.MachineId = rfmd.MachineId OR rfmd.MachineId IS NULL )
					AND bd.ShiftId = @ShiftId
				--	AND bd.PartitionOn = @PartitionOn
					AND rf.Id = 2;

                      SELECT @Value =( sum(cr.TotalRewashLoad)/@ActualWeight)*100.00
				  FROM  TCD.CustomRewash cr 
						INNER JOIN TCD.RedFlag rf ON(rf.Location = cr.GroupId OR rf.Location = 1) 
														AND (cr.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0)AND rf.Is_Deleted = 0						
					   LEFT JOIN tcd.RedFlagMappingData rfmd
					   ON rf.Id = rfmd.MappingId
					  AND rfmd.Is_Deleted = 0
				  WHERE ( cr.EcolabWasherId = rfmd.MachineId  OR rfmd.MachineId IS NULL)
					AND cr.ShiftId = @ShiftId
					--AND cr.PartitionOn = @PartitionOn
					AND rf.Id = @Id;
                END
				ELSE IF @Item = 20
                BEGIN
				--Number Rejected Batches (# per shift)
                    SELECT @Value = count(DISTINCT bp.BatchId)
				  FROM  #BatchData bd 
						INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1) 
														AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0)AND rf.Is_Deleted = 0	
						INNER JOIN TCD.BatchParameters	bp ON bp.BatchId = bd.BatchId 
																AND BP.ParameterId = 18 AND BP.ParameterValue IN(2, 3)
					   LEFT JOIN tcd.RedFlagMappingData rfmd
					   ON rf.Id = rfmd.MappingId
					  AND rfmd.Is_Deleted = 0
				  WHERE ( bd.MachineId = rfmd.MachineId OR rfmd.MachineId IS NULL )
					AND bd.ShiftId = @ShiftId
					--AND bd.PartitionOn = @PartitionOn
					AND rf.Id = @Id;


                END		
				ELSE IF @Item = 21
                BEGIN
				----Number Rejecte Batches (% per shift)
				declare @TotalBatches int=1
				  SELECT
					@TotalBatches = count(DISTINCT bd.BatchId)
				  FROM  #BatchData bd 
						INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1) 
														AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0)AND rf.Is_Deleted = 0							
					   LEFT JOIN tcd.RedFlagMappingData rfmd
					   ON rf.Id = rfmd.MappingId
					  AND rfmd.Is_Deleted = 0
				  WHERE (bd.MachineId = rfmd.MachineId OR rfmd.MachineId IS NULL )
					AND bd.ShiftId = @ShiftId
				--	AND bd.PartitionOn = @PartitionOn
					AND rf.Id = @Id;

                    SELECT
					@Value = (count(DISTINCT bp.BatchId)*1.0000/@TotalBatches)*100.00
				  FROM  #BatchData bd 
						INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1) 
														AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0)AND rf.Is_Deleted = 0	
						INNER JOIN TCD.BatchParameters	bp ON bp.BatchId = bd.BatchId AND bp.PartitionOn = bd.PartitionOn  
																AND BP.ParameterId = 18 AND BP.ParameterValue IN(2, 3)
					   LEFT JOIN tcd.RedFlagMappingData rfmd
					   ON rf.Id = rfmd.MappingId
					  AND rfmd.Is_Deleted = 0
				  WHERE (bd.MachineId = rfmd.MachineId OR rfmd.MachineId IS NULL )
					AND bd.ShiftId = @ShiftId
				--	AND bd.PartitionOn = @PartitionOn
					AND rf.Id = @Id;


                END	
				ELSE IF @Item = 30
                BEGIN
				--pH							 

					SELECT @Value = MAX( sr.Reading )
					FROM TCD.SensorReading sr 
					INNER JOIN TCD.Sensor s ON s.SensorId = sr.SensorId AND s.SensorType=2 
						AND s.Is_deleted=0 AND  (sr.Reading <@MinValue OR sr.Reading>@MaxValue)
						and  CONVERT (DATE, sr.[TimeStamp])  =@PartitionOn				


				END	
				ELSE IF @Item = 31
                BEGIN
				--Conductivity							 

					SELECT @Value = MAX( sr.Reading )
					FROM TCD.SensorReading sr 
					INNER JOIN TCD.Sensor s ON s.SensorId = sr.SensorId AND s.SensorType=4 
						AND s.Is_deleted=0 AND (sr.Reading <@MinValue OR sr.Reading>@MaxValue)
						and  CONVERT (DATE, sr.[TimeStamp])  =@PartitionOn				

				END	
				ELSE IF @Item = 32
                BEGIN
				--Redox
				 SELECT @Value = MAX( sr.Reading )
					FROM TCD.SensorReading sr 
					INNER JOIN TCD.Sensor s ON s.SensorId = sr.SensorId AND s.SensorType=3 
						AND s.Is_deleted=0 AND  (sr.Reading <@MinValue OR sr.Reading>@MaxValue)
						and  CONVERT (DATE, sr.[TimeStamp])  =@PartitionOn	

				END	
				ELSE IF @Item = 33
                BEGIN
				--Temperature
				SELECT @Value = MAX( sr.Reading )
					FROM TCD.SensorReading sr 
					INNER JOIN TCD.Sensor s ON s.SensorId = sr.SensorId AND s.SensorType=1 
						AND s.Is_deleted=0 AND  (sr.Reading <@MinValue OR sr.Reading>@MaxValue)
						and  CONVERT (DATE, sr.[TimeStamp])  =@PartitionOn	

				END	
				ELSE IF @Item = 29
                BEGIN
				--FF Cost Excess
				SELECT  @Value = sum ((bpd.Price/bd.ActualWeight)*100 -
					((CASE WHEN bpd.StandardQuantity=0 THEN 0
					ELSE (bpd.ActualQuantity/bpd.StandardQuantity)*bpd.Price END)/bd.ActualWeight)*100)

					FROM #BatchData bd
					INNER JOIN TCD.BatchProductData bpd ON bpd.BatchId = bd.BatchId AND bpd.EcolabWasherId = bd.EcolabWasherId 
								--AND bpd.PartitionOn = bd.PartitionOn
								AND bd.ActualWeight>0
					INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1) 
														AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0)AND rf.Is_Deleted = 0	
					LEFT JOIN tcd.RedFlagMappingData rfmd
					   ON rf.Id = rfmd.MappingId
					  AND rfmd.Is_Deleted = 0
					 WHERE (bd.MachineId = rfmd.MachineId OR rfmd.MachineId IS NULL)
					AND bd.ShiftId = @ShiftId
					--AND bd.PartitionOn = @PartitionOn
					AND rf.Id = @Id;				

				END	

			IF @Value IS NOT NULL 
			BEGIN
            IF (@MinValue <@Value or @MaxValue >@Value  )
                BEGIN

                    IF NOT EXISTS( SELECT
                                           1
                                     FROM TCD.RedFlagData rfd
                                     WHERE rfd.RedFlagId = @Id
                                       AND rfd.ShiftId = @ShiftId
                                      -- AND PartitionOn = @PartitionOn
                                 )
                        BEGIN
                            INSERT INTO TCD.RedFlagData(
                                    RedFlagId , 
                                    PlantId , 
                                    ShiftId , 
                                    RedFlagValue , 
                                    RedFlagMinSetPoint , 
                                    RedFlagMaxSetPoint , 
                                    PartitionOn
                                                       )
                            SELECT
                                    rf.Id , 
                                    @PlantId , 
                                    @ShiftId , 
                                    @Value , 
									rf.MinimumRange , 
                                    rf.MaximumRange ,                                  
                                    @PartitionOn
                              FROM TCD.RedFlag rf
                              WHERE rf.Id = @Id;

                        END;

                END;
			END

            SET @Counter = @Counter + 1;
		END
END