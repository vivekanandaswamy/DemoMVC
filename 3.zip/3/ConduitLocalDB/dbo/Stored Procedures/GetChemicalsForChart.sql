﻿
/*  
 ==========================================================================================  
 Purpose:  Fetching the Chemicals for chart  

 Author:  Premchand yelavarthi

 --------------------------------------------------------------  
 Aug-13-2014 ENT: Initial version.  
 ==========================================================================================  
*/

CREATE PROCEDURE [TCD].[GetChemicalsForChart] (@GroupId             INT = NULL, 
                                               @MachineId           INT = NULL, 
                                               @ControllerId        INT = NULL, 
                                               @EcolabAccountNumber VARCHAR(1000 
)) 
AS
BEGIN
    SET NOCOUNT ON;

      DECLARE @IStunnel BIT = (SELECT DISTINCT Istunnel 
         FROM   TCD.machinesetup MS 
         WHERE  Ms.GroupId = @GroupId 
						AND EcoalabAccountNumber = @EcolabAccountNumber
                AND MS.IsDeleted = 0); 

	 DECLARE @ControllerModelId int ,	
			@Isna	BIT	=	'FALSE';

    IF @ControllerId IS NULL
	   BEGIN
		  SELECT TOP (1) @ControllerId = ControllerID
            FROM   TCD.ConduitController 
            WHERE  ControllerModelId = 5 
			 AND EcoalabAccountNumber = @EcolabAccountNumber
			 AND TCD.ConduitController.IsDeleted = 0;
	   END;
	   	 
	SELECT @ControllerModelId = cc.ControllerModelId FROM TCD.ConduitController cc WHERE cc.ControllerId = @ControllerId AND cc.EcoalabAccountNumber = @EcolabAccountNumber

	  IF	@Controllermodelid	IS	NULL
	OR	@Controllermodelid	<	7
	OR	@Controllermodelid	IN(12,	13)
		BEGIN
			SET	@Isna	=	'TRUE';
		END;

    IF @IStunnel = 'TRUE'
	   BEGIN
	    IF @Isna	=	'TRUE'
	    BEGIN
		SELECT DISTINCT	 PM.ProductId,
			CES.ControllerEquipmentId,
			CES.ControllerEquipmentTypeId,
			CC.ControllerModelId,
					   CASE  
			WHEN PM2.EnvisionDisplayName IS NULL THEN PM2.NAME 
			ELSE PM2.EnvisionDisplayName 
			END as NAME  FROM TCD.TunnelCompartmentEquipmentMapping tcem
INNER JOIN TCD.TunnelCompartment tc ON tc.TunnelCompartmentId = tcem.TunnelCompartmentId AND tc.EcoLabAccountNumber = tcem.EcoLabAccountNumber
INNER JOIN TCD.MachineSetup ms ON ms.WasherId = tc.WasherId AND ms.EcoalabAccountNumber = tc.EcoLabAccountNumber
INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.ControllerEquipmentSetupId = tcem.ControllerEquipmentSetupId AND ces.ControllerId = ms.ControllerId
AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber AND ces.EcoLabAccountNumber = tc.EcoLabAccountNumber AND ces.EcoLabAccountNumber = tcem.EcoLabAccountNumber
INNER JOIN TCD.ConduitController cc ON cc.ControllerId = ms.ControllerId AND cc.EcoalabAccountNumber = ces.EcoLabAccountNumber
INNER JOIN TCD.ProductdataMapping pm ON pm.EcolabAccountNumber = ces.EcoLabAccountNumber AND pm.ProductID = ces.ProductId
INNER JOIN TCD.ProductMaster pm2 ON pm.ProductID = pm2.ProductId
            WHERE  MS.IsDeleted = 0 
			 AND CC.IsDeleted = 0
			 AND TCEM.Is_Deleted = 0
			 AND CES.IsActive = 1
			 AND pm.Is_Deleted = 0
			 AND TC.EcoLabAccountNumber = @EcolabAccountNumber
                   AND ( MS.GroupId = @GroupId 
			   OR @GroupId IS NULL
                          OR @GroupId = 1 ) 
                   AND ( TC.CompartmentNumber = @MachineId
			    OR @MachineId IS NULL
			    OR @MachineId = 0)
			 AND CC.ControllerId = @ControllerId
			 	AND PM2.Name NOT LIKE '%DUMMY PRODUCT%';
	    END
	    ELSE
	    BEGIN
		 SELECT	DISTINCT	 PM.ProductId,
			CES.ControllerEquipmentId,
			CES.ControllerEquipmentTypeId,
			CC.ControllerModelId,
					   CASE  
			WHEN PM.EnvisionDisplayName IS NULL THEN PM.NAME 
			ELSE PM.EnvisionDisplayName 
			END as NAME 
            FROM   TCD.MachineSetup MS 
                   INNER JOIN TCD.TunnelCompartment TC 
                           ON TC.WasherId = MS.WasherId 
                   INNER JOIN TCD.ConduitController CC 
                           ON CC.ControllerId = MS.ControllerId      
				INNER JOIN TCD.TunnelCompartmentEquipmentMapping TCEM 
                           ON TCEM.TunnelCompartmentId = TC.TunnelCompartmentId               		    
                   INNER JOIN TCD.ControllerEquipmentSetup CES 
                           ON CES.ControllerId = CC.ControllerId
				INNER JOIN tcd.TunnelCompartmentEquipmentValveMapping tcevm 
					   ON tcevm.ControllerEquipmentSetupID = CES.ControllerEquipmentSetupId 
					   AND tcevm.CompartmentNumber = TC.CompartmentNumber
                   INNER JOIN TCD.ProductdataMapping PDM 
                           ON PDM.ProductID = CES.ProductId 
                   INNER JOIN TCD.ProductMaster PM 
                           ON PM.ProductId = PDM.ProductID 
            WHERE  MS.IsDeleted = 0 
			 AND CC.IsDeleted = 0
			 AND TCEM.Is_Deleted = 0
			 AND CES.IsActive = 1
			 AND PDM.Is_Deleted = 0
			 AND MS.EcoalabAccountNumber = @EcolabAccountNumber
			 AND TC.EcoLabAccountNumber = @EcolabAccountNumber
			 AND CC.EcoalabAccountNumber = @EcolabAccountNumber
			 AND TCEM.EcoLabAccountNumber = @EcolabAccountNumber
			 AND CES.EcoLabAccountNumber = @EcolabAccountNumber
			 AND PDM.EcolabAccountNumber = @EcolabAccountNumber
                   AND ( MS.GroupId = @GroupId 
			   OR @GroupId IS NULL
                          OR @GroupId = 1 ) 
                   AND ( TC.CompartmentNumber = @MachineId
			    OR @MachineId IS NULL
			    OR @MachineId = 0)
			 AND CC.ControllerId = @ControllerId
			 	AND PM.Name NOT LIKE '%DUMMY PRODUCT%';
	    END
	   END;
    ELSE
	   BEGIN
			SELECT DISTINCT 
						pm.ProductId, 
						CES.ControllerEquipmentId, 
						CES.ControllerEquipmentTypeId, 
						CC.ControllerModelId,
						CASE
							WHEN PM.EnvisionDisplayName IS NULL
							THEN PM.NAME
							ELSE PM.EnvisionDisplayName
						END AS NAME
					FROM TCD.Washer AS WS
						 INNER JOIN TCD.MachineSetup AS Ms ON ms.WasherId = ws.WasherId
						 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = ms.GroupId
						 INNER JOIN TCD.WasherGroupType AS WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
						 INNER JOIN TCD.WasherProgramSetup AS Wps ON Wps.ControllerID = Wg.ControllerId
																	 OR Wps.WasherGroupId = Wg.WasherGroupId
						 INNER JOIN TCD.WasherDosingSetup AS Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
						 INNER JOIN TCD.WasherDosingProductMapping AS Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
						 INNER JOIN TCD.ControllerEquipmentSetup AS ces ON ces.ControllerEquipmentSetupId = Wdpm.ControllerEquipmentSetupId
						 INNER JOIN TCD.ProductdataMapping AS Pdm ON Pdm.ProductId = Wdpm.ProductId
						 INNER JOIN TCD.ProductMaster AS pm ON pm.ProductId = Pdm.ProductID
						 INNER JOIN TCD.ConduitController AS cc ON CC.ControllerId = ces.ControllerId
					WHERE PDM.Is_Deleted = 0
							AND pm.Is_Deleted = 0
							AND CC.IsDeleted = 0
							AND Wds.Is_Deleted = 0
							AND Wps.Is_Deleted = 0
							AND Wdpm.IsDeleted = 0
							AND ms.IsTunnel = 0
							AND (ms.GroupId = @Groupid
								OR @Groupid IS NULL
								OR @Groupid = 0
								OR @Groupid = 1)
							AND (ms.WasherId = @Machineid
								OR @Machineid IS NULL
								OR @Machineid = 0)
							AND CC.ControllerId = @Controllerid
							AND ces.EcoLabAccountNumber = @Ecolabaccountnumber
							AND PDM.EcolabAccountNumber = @Ecolabaccountnumber
							AND CC.ControllerId = @Controllerid
							AND PM.Name NOT LIKE '%DUMMY PRODUCT%'
			AND ((@Isna	=	'FALSE' AND ces.conventionalwashergroupconnection = 1) OR (@Isna	= 'TRUE'));
	   END;

    SET NOCOUNT OFF;
    END