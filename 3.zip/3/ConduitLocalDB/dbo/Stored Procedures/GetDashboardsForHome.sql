﻿CREATE PROCEDURE [TCD].[GetDashboardsForHome] 
AS   
SET NOCOUNT ON
BEGIN   
				select DashboardId,convert(int,TypeId)as TypeId from [TCD].Dashboard where DisplayOnLogin = 1 AND IsDeleted <> 1 
END