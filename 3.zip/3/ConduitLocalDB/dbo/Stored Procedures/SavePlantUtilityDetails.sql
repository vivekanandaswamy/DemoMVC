﻿CREATE PROCEDURE [TCD].[SavePlantUtilityDetails] 
		@UtilityType INT, 
		@FactorType Nvarchar(100)= null,
		@FactorTypes Nvarchar(Max), 
		@ColdTemprature DECIMAL(18,4),
        @ColdPrice DECIMAL(18,4),
        @HotTemparature DECIMAL(18,4),
        @HotPrice DECIMAL(18,4),
        @TemperedTemprature DECIMAL(18,4),
        @TemperedPrice DECIMAL(18,4),
        @WasteWaterPrice DECIMAL(18,4),
        @Free1Temprature DECIMAL(18,4),
        @Free1Price DECIMAL(18,4),
        @Free2Temprature DECIMAL(18,4),
        @Free2Price DECIMAL(18,4),
        @Free3Temprature DECIMAL(18,4),
        @Free3Price DECIMAL(18,4),
        @Energy DECIMAL(18,4),
        @GasPrice DECIMAL(18,4),
        @ElectricityTarrif  DECIMAL(18,4),
		@Location Nvarchar(100)= null,
		@BolierSteam DECIMAL(18,4),
		@BolierType INT,
		@Steam DECIMAL(18,4),
		@Boiler DECIMAL(18,4),
		@Stack DECIMAL(18,4),
		@RewashFactor DECIMAL(18,4),
		@ColdSoftTemprature DECIMAL(18,4),
        @ColdSoftPrice DECIMAL(18,4),
        @HotHardTemparature DECIMAL(18,4),
        @HotHardPrice DECIMAL(18,4),
		@ColdHardTemprature DECIMAL(18,4),
        @ColdHardPrice DECIMAL(18,4),
        @HotSoftTemparature DECIMAL(18,4),
        @HotSoftPrice DECIMAL(18,4),
		@Free1FactorType  Nvarchar(100)= null,
		@Free2FactorType Nvarchar(100)= null,
		@Free3FactorType Nvarchar(100)= null,
		@GasOilType Nvarchar(100)= null,
		@UserId INT,
		@EnergyContentUnit Nvarchar(100)= null,
		@EnergyPriceUnit Nvarchar(100)= null,
		@EvaporationFactor DECIMAL(18,4)
		--@UtilityId INT
		,	@EcolabAccountNumber			NVARCHAR(25)
		,	@RegionCode						NVARCHAR(1000)				=	NULL
		,	@OutputId						INT							=	NULL	OUTPUT
		,	@LastModifiedTimestampAtCentral			DATETIME					=	NULL
		,	@OutputLastModifiedTimestampAtLocal		DATETIME					=	NULL	OUTPUT
AS
	DECLARE @Scope Int = NULL 
BEGIN

SET NOCOUNT ON;
	
	DECLARE	
		@Output							VARCHAR(100)	=			''  
	,	@ReturnValue					INT				=			0
	--,	@ErrorId						INT				=			0								--SQLEnlight SA0004
	--,	@ErrorMessage					NVARCHAR(4000)	=			N''								--SQLEnlight SA0004
	--,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()					--SQLEnlight SA0004
	
	DECLARE
	@OutputList								AS	TABLE		
		(
			Id								INT			
			, LastModifiedTimestamp			DATETIME
		)

SET	@OutputLastModifiedTimestampAtLocal			=			ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight
SET	@OutputId									=			ISNULL(@OutputId, NULL)										--SQLEnlight

IF(@Location IS NULL)
BEGIN
SELECT @Location = RegionId FROM TCD.RegionMaster WHERE MyServiceRegionCode = @RegionCode
END

IF((SELECT COUNT(*) FROM [TCD].PlantUtilityFactor)>0)
	BEGIN
		Delete From [TCD].PlantUtilityFactor
		Delete From [TCD].PlantUtilityEnergyProperties
	END

	 DECLARE @String    VARCHAR(max)= @FactorTypes, 
              @Delimiter CHAR(1) = ','--, @Output Int

     DECLARE @temptable TABLE 
        ( 
           items VARCHAR(max) 
        ) 

      IF( @String = '' ) 
        BEGIN 
            SELECT @String = 'N' 
        END 
      ELSE 
        SELECT @String = @FactorTypes 
      BEGIN 
          DECLARE @idx INT = NULL
          DECLARE @slice VARCHAR(8000) = NULL
          SELECT @idx = 1 
          IF Len(@String) < 1 
              OR @String IS NULL 
            RETURN 

          WHILE @idx != 0 
            BEGIN 
                SET @idx = Charindex(@Delimiter, @String) 
                IF @idx != 0 
                  SET @slice = LEFT(@String, @idx - 1) 
                ELSE 
                  SET @slice = @String 

                IF( Len(@slice) > 0 ) 
                  INSERT INTO @temptable 
                              (items) 
                  VALUES      (@slice)
				  
                SET @String = RIGHT(@String, Len(@String) - @idx) 

                IF Len(@String) = 0 
                  BREAK 
            END 
      END 

	  DECLARE @factor NVARCHAR(100) = NULL
      DECLARE cursor_sample CURSOR FOR 
        SELECT * 
        FROM   @temptable 

      OPEN cursor_sample 
      FETCH next FROM cursor_sample INTO @factorType  

	   WHILE @@fetch_status = 0 
        BEGIN 
            DECLARE @idx1 INT = 1 
            DECLARE @Delimiter1 CHAR(1) = ':' 
            DECLARE @slice1 VARCHAR(8000) = NULL
            IF Len(@factorType) = 0 
                OR @factorType IS NULL 
              RETURN 

            WHILE @idx1 <> 0 
              BEGIN 
                  SET @idx1 = Charindex(@Delimiter1, @factorType) 
                  IF @idx1 <> 0 
               SET @slice1 = LEFT(@factorType, @idx1 - 1) 
                  ELSE 
                    SET @slice1 = @factorType 

                  IF( Len(@slice) > 0 ) 
                    --select @slice   
                    --select @string  
                    SET @factorType = RIGHT(@factorType, Len(@factorType) - @idx1) 
                  --select @String 
			   
				  IF(@factorType='Cold')
				  BEGIN
				  SELECT  @FactorType=Id FROM TCD.WaterType wt WHERE NAME='Fresh'
					INSERT INTO [TCD].PlantUtilityFactor(UtilityId,UtilityType,FactorType,Temparature,EnergyContent,Price,Location,FreeType,EnergyContentUnit,EnergyPriceUnit,ElectricPriceUnit,LastModifiedByUserId,EcolabAccountNumber) 
					VALUES(1,2,@FactorType,@ColdTemprature,0.00,@ColdPrice,@Location,0,'','','',@UserId,@EcolabAccountNumber) 
				  END

				  ELSE IF(@factorType='Hot')
				  BEGIN
				  SELECT  @FactorType=Id FROM TCD.WaterType wt WHERE NAME=@factorType
					INSERT INTO [TCD].PlantUtilityFactor(UtilityId,UtilityType,FactorType,Temparature,EnergyContent,Price,Location,FreeType,EnergyContentUnit,EnergyPriceUnit,ElectricPriceUnit,LastModifiedByUserId,EcolabAccountNumber) 
					VALUES((SELECT MAX(UtilityId)+1 FROM [TCD].PlantUtilityFactor),2,@FactorType,@HotTemparature,0.00,@HotPrice,@Location,0,'','','',@UserId,@EcolabAccountNumber) 
				  END
				  
				  ELSE IF(@factorType='Cold Soft')
				  BEGIN
				  SELECT  @FactorType=Id FROM TCD.WaterType wt WHERE NAME=@factorType
					INSERT INTO [TCD].PlantUtilityFactor(UtilityId,UtilityType,FactorType,Temparature,EnergyContent,Price,Location,FreeType,EnergyContentUnit,EnergyPriceUnit,ElectricPriceUnit,LastModifiedByUserId,EcolabAccountNumber) 
					VALUES((SELECT MAX(UtilityId)+1 FROM [TCD].PlantUtilityFactor),2,@FactorType,@ColdSoftTemprature,0.00,@ColdSoftPrice,@location,0,'','','',@UserId,@EcolabAccountNumber) 
				  END

				  ELSE IF(@factorType='Cold Hard')
				  BEGIN
				  SELECT  @FactorType=Id FROM TCD.WaterType wt WHERE NAME=@factorType
					INSERT INTO [TCD].PlantUtilityFactor(UtilityId,UtilityType,FactorType,Temparature,EnergyContent,Price,Location,FreeType,EnergyContentUnit,EnergyPriceUnit,ElectricPriceUnit,LastModifiedByUserId,EcolabAccountNumber) 
					VALUES((SELECT MAX(UtilityId)+1 FROM [TCD].PlantUtilityFactor),2,@FactorType,@ColdHardTemprature,0.00,@ColdHardPrice,@location,0,'','','',@UserId,@EcolabAccountNumber) 

				  END

				  ELSE IF(@factorType='Hot Soft')
				  BEGIN
				  SELECT  @FactorType=Id FROM TCD.WaterType wt WHERE NAME=@factorType
					INSERT INTO [TCD].PlantUtilityFactor(UtilityId,UtilityType,FactorType,Temparature,EnergyContent,Price,Location,FreeType,EnergyContentUnit,EnergyPriceUnit,ElectricPriceUnit,LastModifiedByUserId,EcolabAccountNumber) 
					VALUES((SELECT MAX(UtilityId)+1 FROM [TCD].PlantUtilityFactor),2,@FactorType,@HotSoftTemparature,0.00,@HotSoftPrice,@Location,0,'','','',@UserId,@EcolabAccountNumber) 
				  END

				  ELSE IF(@factorType='Hot Hard')
				  BEGIN
				  SELECT  @FactorType=Id FROM TCD.WaterType wt WHERE NAME=@factorType
					INSERT INTO [TCD].PlantUtilityFactor(UtilityId,UtilityType,FactorType,Temparature,EnergyContent,Price,Location,FreeType,EnergyContentUnit,EnergyPriceUnit,ElectricPriceUnit,LastModifiedByUserId,EcolabAccountNumber) 
					VALUES((SELECT MAX(UtilityId)+1 FROM [TCD].PlantUtilityFactor),2,@FactorType,@HotHardTemparature,0.00,@HotHardPrice,@Location,0,'','','',@UserId,@EcolabAccountNumber) 
				  END

				  ELSE IF(@factorType='Tempered')
				  BEGIN
				  SELECT  @FactorType=Id FROM TCD.WaterType wt WHERE NAME=@factorType
					INSERT INTO [TCD].PlantUtilityFactor(UtilityId,UtilityType,FactorType,Temparature,EnergyContent,Price,Location,FreeType,EnergyContentUnit,EnergyPriceUnit,ElectricPriceUnit,LastModifiedByUserId,EcolabAccountNumber) 
					VALUES((SELECT MAX(UtilityId)+1 FROM [TCD].PlantUtilityFactor),2,@FactorType,@TemperedTemprature,0.00,@TemperedPrice,@Location,0,'','','',@UserId,@EcolabAccountNumber) 
				  END

				  ELSE IF(@factorType='Waste/Sewer')
				  BEGIN
				  SELECT  @FactorType=Id FROM TCD.WaterType wt WHERE NAME=@factorType
					INSERT INTO [TCD].PlantUtilityFactor(UtilityId,UtilityType,FactorType,Temparature,EnergyContent,Price,Location,FreeType,EnergyContentUnit,EnergyPriceUnit,ElectricPriceUnit,LastModifiedByUserId,EcolabAccountNumber) 
					VALUES((SELECT MAX(UtilityId)+1 FROM [TCD].PlantUtilityFactor),2,@FactorType,0.00,0.00,@WasteWaterPrice,@Location,0,'','','',@UserId,@EcolabAccountNumber) 
				  END

				  ELSE IF(@factorType='Free1')
				  BEGIN
				  SELECT  @FactorType=Id FROM TCD.WaterType wt WHERE NAME=@Free1FactorType
					INSERT INTO [TCD].PlantUtilityFactor(UtilityId,UtilityType,FactorType,Temparature,EnergyContent,Price,Location,FreeType,EnergyContentUnit,EnergyPriceUnit,ElectricPriceUnit,LastModifiedByUserId,EcolabAccountNumber) 
					VALUES((SELECT MAX(UtilityId)+1 FROM [TCD].PlantUtilityFactor),2,@FactorType,@free1Temprature,0.00,@free1Price,@Location,1,'','','',@UserId,@EcolabAccountNumber) 
				  END

				  ELSE IF(@factorType='Free2')
				  BEGIN
				  SELECT  @FactorType=Id FROM TCD.WaterType wt WHERE NAME=@Free2FactorType
					INSERT INTO [TCD].PlantUtilityFactor(UtilityId,UtilityType,FactorType,Temparature,EnergyContent,Price,Location,FreeType,EnergyContentUnit,EnergyPriceUnit,ElectricPriceUnit,LastModifiedByUserId,EcolabAccountNumber) 
					VALUES((SELECT MAX(UtilityId)+1 FROM [TCD].PlantUtilityFactor),2,@FactorType,@free2Temprature,0.00,@free2Price,@Location,2,'','','',@UserId,@EcolabAccountNumber) 
				  END
				  
				  ELSE IF(@factorType='Free3')				  
				  BEGIN
				  SELECT  @FactorType=Id FROM TCD.WaterType wt WHERE NAME=@Free3FactorType
					INSERT INTO [TCD].PlantUtilityFactor(UtilityId,UtilityType,FactorType,Temparature,EnergyContent,Price,Location,FreeType,EnergyContentUnit,EnergyPriceUnit,ElectricPriceUnit,LastModifiedByUserId,EcolabAccountNumber) 
					VALUES((SELECT MAX(UtilityId)+1 FROM [TCD].PlantUtilityFactor),2,@FactorType,@free3Temprature,0.00,@free3Price,@Location,3,'','','',@UserId,@EcolabAccountNumber) 
				  END
				  
				  ELSE IF(@factorType='Energy')
				  BEGIN
				  SELECT  @FactorType=Id FROM TCD.WaterType wt WHERE NAME=@factorType
					INSERT INTO [TCD].PlantUtilityFactor(UtilityId,UtilityType,FactorType,Temparature,EnergyContent,Price,Location,FreeType,EnergyContentUnit,EnergyPriceUnit,ElectricPriceUnit,LastModifiedByUserId,EcolabAccountNumber) 
					VALUES((SELECT MAX(UtilityId)+1 FROM [TCD].PlantUtilityFactor),1,@GasOilType,0.00,@Energy,@GasPrice,@Location,4,@EnergyContentUnit,@EnergyPriceUnit,'',@UserId,@EcolabAccountNumber) 
				  END
				  
				  ELSE IF(@factorType='Electricity')
				  BEGIN
				  SELECT  @FactorType=Id FROM TCD.WaterType wt WHERE NAME=@factorType
					INSERT INTO [TCD].PlantUtilityFactor(UtilityId,UtilityType,FactorType,Temparature,EnergyContent,Price,Location,FreeType,EnergyContentUnit,EnergyPriceUnit,ElectricPriceUnit,LastModifiedByUserId,EcolabAccountNumber) 
					VALUES((SELECT MAX(UtilityId)+1 FROM [TCD].PlantUtilityFactor),3,@FactorType,0.00,0.00,@ElectricityTarrif,@Location,0,'','','',@UserId,@EcolabAccountNumber) 
				  END
                  BREAK		   
              END 
            FETCH next FROM cursor_sample INTO @factorType 
        END 
		
		      CLOSE cursor_sample 
      DEALLOCATE cursor_sample 

--SELECT @Scope = SCOPE_IDENTITY
INSERT INTO [TCD].PlantUtilityEnergyProperties
		(
			UtilityId,
			BolierSteam,
			BolierType,
			Steam,
			Boiler,
			Stack,
			RewashFactor,
			EvaporationFactor,
			LastModifiedByUserId
		)
		OUTPUT					
			1 AS Id,
			inserted.LastModifiedTime		AS			LastModifiedTimestamp

			INTO
				@OutputList	
				(	
					Id				
					,LastModifiedTimestamp
				)
		VALUES
		(
			1,
			@BolierSteam,
			@BolierType,
			@Steam,
			@Boiler,
			@Stack,
			@RewashFactor,
			@EvaporationFactor,
			@UserId
		)

		SELECT	TOP 1	
		@OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp
		,@OutputId				=	O.Id		
		FROM	@OutputList							O
		
		RETURN	(@ReturnValue)
--SET NOCOUNT OFF;
END