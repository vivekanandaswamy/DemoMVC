﻿CREATE PROCEDURE TCD.GetEquipmentTypeModels
AS
BEGIN
    SELECT CETM.ControllerEquipmentTypeModelID
	    , CETM.ControllerEquipmentTypeModelName
	    , CETM.ArtNumberLang
	    , CETM.TeoreticalCalibration
	    , CETM.IsMEType
	 FROM TCD.ControllerEquipmentTypeModel CETM
	 
END;