﻿CREATE PROCEDURE [TCD].[SaveControllerSetupData] 
(
  @ControllerSetupData     XML
 , @UserId         INT
 , @ControllerId       INT      OUTPUT
 , @LastModifiedTimestampAtCentral   DATETIME = NULL
 , @OutputLastModifiedTimestampAtLocal  DATETIME = NULL OUTPUT
)
AS
BEGIN
      SET NOCOUNT ON
   
--DECLARE @ControllerId INT
DECLARE @ControllerNumber INT = NULL
DECLARE @ControllerModelId INT = NULL
DECLARE @ControllerModelName VARCHAR(50) = NULL
DECLARE @ControllerTypeId INT = NULL
DECLARE @ControllerTypeName VARCHAR(50) = NULL
DECLARE @EcolabAccountNumber nvarchar(25) = NULL
DECLARE @TopicName VARCHAR(1000) = NULL
DECLARE @Active BIT
DECLARE @ErrorMessage VARCHAR(200) = NULL
DECLARE @NumOfConvWasherGroups INT = NULL
DECLARE @NumOfTunnelWasherGroups INT = NULL
DECLARE @LoopCount INT = 0
DECLARE @WasherGroupName VARCHAR(100) = NULL
DECLARE @WasherGroupId INT = NULL
DECLARE @WasherGroupNumber VARCHAR(10) = NULL
DECLARE @OutputList AS TABLE (
ControllerId INT
,LastModifiedTimestamp DATETIME
  )

SET @ControllerId = ISNULL(@ControllerId, NULL) --SQLEnlight SA0121
SET @OutputLastModifiedTimestampAtLocal = ISNULL(@OutputLastModifiedTimestampAtLocal, NULL) --SQLEnlight SA0121

   SELECT @ControllerNumber = Tbl.col.value('@ControllerNumber', 'int')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)

   SELECT @ControllerModelId = Tbl.col.value('@ControllerModelId', 'int')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)

   SELECT @ControllerTypeId = Tbl.col.value('@ControllerTypeId', 'int')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)
   
   SELECT @EcolabAccountNumber = Tbl.col.value('@EcolabAccountNumber', 'varchar(1000)')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)

    SELECT @TopicName = Tbl.col.value('@TopicName', 'varchar(1000)')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)

    SELECT @Active = Tbl.col.value('@Active', 'bit')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)
   
IF EXISTS (
SELECT 1
FROM [TCD].ConduitController WITH (NOLOCK)
WHERE ControllerNumber = @ControllerNumber
AND IsDeleted = 0
AND EcoalabAccountNumber = @EcolabAccountNumber
)
   BEGIN
SET @ErrorMessage = '303 - Controller Number already exists.'

RAISERROR (
@ErrorMessage
,16
,1
)

   RETURN
   END

IF EXISTS (
SELECT 1
FROM [TCD].ConduitController WITH (NOLOCK)
WHERE TopicName = @TopicName
AND IsDeleted = 0
AND EcoalabAccountNumber = @EcolabAccountNumber
)
BEGIN
SET @ErrorMessage = '304 - Controller Name already exists.'

RAISERROR (
@ErrorMessage
,16
,1
        )

RETURN
END




SELECT @ControllerModelName = Name
FROM [TCD].ControllerModel WITH (NOLOCK)
WHERE Id = @ControllerModelId

SELECT @ControllerTypeName = Name
FROM [TCD].ControllerType WITH (NOLOCK)
WHERE Id = @ControllerTypeId

DECLARE @TempMaster TABLE (
EcolabAccountNumber NVARCHAR(25)
,NAME VARCHAR(100)
,ControllerModelId INT
,ControllerNumber INT
,ControllerTypeId INT
,ControllerVersion VARCHAR(10)
,InstallDate DATETIME
,UserId INT
,TopicName VARCHAR(1000)
,Active BIT
        )
DECLARE @TempDynamic TABLE (
EcolabAccountNumber NVARCHAR(25)
,ControllerId INT
,ControllerModelId INT
,FieldGroupId INT
,FieldId INT
,Value VARCHAR(1000)
,UserId INT
)


INSERT INTO @TempDynamic (
EcolabAccountNumber
,ControllerId
,ControllerModelId
,FieldGroupId
,FieldId
,Value
,UserId
)
SELECT @EcolabAccountNumber
,0
,Tbl.col.value('@ControllerModelId', 'int')
,Tbl.col.value('@FieldGroupId', 'int')
,Tbl.col.value('@FieldId', 'int')
,Tbl.col.value('@Value', 'varchar(1000)')
,@UserId
FROM @ControllerSetupData.nodes('/ControllerSetupData/DynamicSetupData/Data') AS Tbl(col)

DECLARE @TempFieldId INT
DECLARE @TempValue VARCHAR(1000)


SELECT @TempFieldId=FieldId,@TempValue=Value FROM @TempDynamic WHERE FieldId in (21,22,47,48,87,98,116,130,148,150,171,192,208,269,309,348,387,400,414,426,438,449,460)


IF EXISTS ( SELECT 1
            FROM  [TCD].ConduitController CC WITH (NOLOCK) 
			INNER JOIN [TCD].ControllerSetupData CSD ON cc.ControllerId=csd.ControllerId 
			AND CC.Active=1
			and CSD.FieldId=@TempFieldId
			and CSD.Value =@TempValue
			and CC.ControllerTypeId=@ControllerTypeId
			and CC.ControllerModelId=@ControllerModelId
			and CC.EcoalabAccountNumber=@EcolabAccountNumber)
BEGIN
SET @ErrorMessage = '305 -IP Address/AMS Net ID Address already exists.'

RAISERROR (
@ErrorMessage
,16
,1
)

RETURN
END

 BEGIN TRANSACTION

  BEGIN TRY
INSERT INTO @TempMaster (
      EcolabAccountNumber
,NAME
,ControllerModelId
,ControllerNumber
,ControllerTypeId
,ControllerVersion
,InstallDate
,UserId
,TopicName
,Active
     )
SELECT @EcolabAccountNumber
,CAST(Tbl.col.value('@ControllerNumber', 'int') AS VARCHAR(10)) + ' (' + Tbl.col.value('@TopicName', 'varchar(100)') + ')'
    ,Tbl.col.value('@ControllerModelId', 'int')
    ,Tbl.col.value('@ControllerNumber', 'int')
    ,Tbl.col.value('@ControllerTypeId', 'varchar(100)')
    ,Tbl.col.value('@ControllerVersion', 'varchar(10)')
    ,CAST(Tbl.col.value('@InstallDate', 'datetime') AS DATETIME)
    ,@UserId
    ,Tbl.col.value('@TopicName', 'varchar(100)')
,Tbl.col.value('@Active', 'bit')
FROM @ControllerSetupData.nodes('/ControllerSetupData/MasterSetupData') AS Tbl(col)

INSERT INTO [TCD].ConduitController (
EcoalabAccountNumber
,Name
,ControllerModelId
,ControllerNumber
,ControllerTypeId
,ControllerVersion
,InstallDate
,TopicName
,Active
,LastModifiedByUserId
    )
OUTPUT inserted.ControllerId AS ControllerId
,inserted.LastModifiedTime AS LastModifiedTimestamp
INTO @OutputList(ControllerId, LastModifiedTimestamp)
SELECT EcolabAccountNumber
,NAME
,ControllerModelId
,ControllerNumber
,ControllerTypeId
,ControllerVersion
,InstallDate
,TopicName
,Active
,UserId
FROM @TempMaster
   
SELECT TOP 1 @ControllerId = O.ControllerId
FROM @OutputList O

update @TempDynamic set ControllerId=@ControllerId

INSERT INTO [TCD].ControllerSetupData (
       EcolabAccountNumber
,ControllerId
,FieldGroupId
,FieldId
,Value
,ControllerModelId
,LastModifiedByUserId
      )
SELECT EcolabAccountNumber
,ControllerId
,FieldGroupId
,FieldId
,Value
,ControllerModelId
,UserId
FROM @TempDynamic

IF @ControllerModelId = 7
OR @ControllerModelId = 8
OR @ControllerModelId = 9
OR @ControllerModelId = 11
OR @ControllerModelId = 10
OR @ControllerModelId = 14
BEGIN
EXEC TCD.SaveDefaultControllerEquipment @ControllerId = @ControllerId
,@EcolabAccountNumber = @EcolabAccountNumber
,@UserId = @UserId;
END;

SELECT @NumOfConvWasherGroups = NumOfConvWasherGroups
,@NumOfTunnelWasherGroups = NumOfTunnelWasherGroups
FROM TCD.ControllerModelControllerTypeMapping
WHERE ControllerModelId = @ControllerModelId
AND ControllerTypeId = @ControllerTypeId

DECLARE @TotalGroupCount INT = 0;
DECLARE @WasherDosingNumber INT = 0;

IF ISNULL(@NumOfConvWasherGroups, 0) > 0
BEGIN
WHILE @LoopCount < @NumOfConvWasherGroups
            BEGIN
                SET @WasherGroupName = @TopicName + ' Dosing Group ' + CAST(@TotalGroupCount + 1 AS VARCHAR(10));
                SET @WasherDosingNumber = @TotalGroupCount + 1;

                EXEC TCD.SaveMachineGroup @GroupDescription = @WasherGroupName
                    ,@GroupTypeId = 2
                    ,@EcolabAccountNumber = @EcolabAccountNumber;

                SELECT @WasherGroupId = Id
                FROM TCD.MachineGroup
                WHERE GroupDescription = @WasherGroupName

                SELECT @WasherGroupNumber = ISNULL(MAX(CAST(WasherGroupNumber AS INT)),0) + 1
                FROM TCD.WasherGroup

                EXEC TCD.SaveWasherGroup @EcolabAccountNumber = @EcolabAccountNumber
                    ,@WasherGroupId = @WasherGroupId
                    ,@ControllerId = @ControllerId
                    ,@WasherGroupTypeId = 1
                    ,@WasherGroupName = @WasherGroupName
                    ,@WasherGroupNumber = @WasherGroupNumber
                    ,@LastModifiedByUserId = 1
                    ,@WasherDosingNumber = @WasherDosingNumber ;

                SET @LoopCount += 1;
                SET @TotalGroupCount += 1;
            END
        END

        SET @LoopCount = 0;

        IF ISNULL(@NumOfTunnelWasherGroups, 0) > 0
        BEGIN
            WHILE @LoopCount < @NumOfTunnelWasherGroups
            BEGIN
                SET @WasherGroupName = @TopicName + ' Dosing Group ' + CAST(@TotalGroupCount + 1 AS VARCHAR(10));
                SET @WasherDosingNumber = @TotalGroupCount + 1;

                EXEC TCD.SaveMachineGroup @GroupDescription = @WasherGroupName
                    ,@GroupTypeId = 2
                    ,@EcolabAccountNumber = @EcolabAccountNumber;

                SELECT @WasherGroupId = Id
                FROM TCD.MachineGroup
                WHERE GroupDescription = @WasherGroupName

                SELECT @WasherGroupNumber = ISNULL(MAX(CAST(WasherGroupNumber AS INT)),0) + 1
                FROM TCD.WasherGroup

                EXEC TCD.SaveWasherGroup @EcolabAccountNumber = @EcolabAccountNumber
                    ,@WasherGroupId = @WasherGroupId
                    ,@ControllerId = @ControllerId
                    ,@WasherGroupTypeId = 2
                    ,@WasherGroupName = @WasherGroupName
                    ,@WasherGroupNumber = @WasherGroupNumber
                    ,@LastModifiedByUserId = 1
                    ,@WasherDosingNumber = @WasherDosingNumber;

                SET @LoopCount += 1;
                SET @TotalGroupCount += 1;
            END
        END

   DECLARE @TempControllerTypeId INT, 
		   @MaxInjectionClasses INT
   SELECT @TempControllerTypeId = ControllerTypeId FROM TCD.ConduitController WHERE ControllerId = @ControllerId

   IF (@TempControllerTypeId = 1)
   BEGIN
	SET @MaxInjectionClasses = 6
   END

    IF (@TempControllerTypeId = 2)
   BEGIN
	SET @MaxInjectionClasses = 8
   END
    
	UPDATE tcd.ConduitController SET LFSInjectionClasses = @MaxInjectionClasses where ControllerId = @ControllerId
 
   COMMIT TRANSACTION

        SELECT TOP 1 @OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp
        FROM @OutputList O
  END TRY

  BEGIN CATCH
        SELECT ERROR_NUMBER() AS ErrorNumber
            ,ERROR_SEVERITY() AS ErrorSeverity
            ,ERROR_STATE() AS ErrorState
            ,ERROR_PROCEDURE() AS ErrorProcedure
            ,ERROR_LINE() AS ErrorLine
            ,ERROR_MESSAGE() AS ErrorMessage

   ROLLBACK TRANSACTION
  END CATCH

SET NOCOUNT OFF
END