﻿CREATE PROCEDURE [TCD].[GetControllerDetails] @CanControlTunnel BIT = NULL
	,@IsDelete BIT = 'False'
	,@EcolabAccountNumber NVARCHAR(25)
AS
BEGIN
	SET NOCOUNT ON

	IF @CanControlTunnel IS NOT NULL OR @CanControlTunnel = 0
	BEGIN
		SET @CanControlTunnel = 0
	END

	SELECT C.ControllerId
		,C.ControllerModelId
		,CM.NAME ControllerModelName
		,C.NAME ControllerName
		,C.ControllerNumber
		,C.ControllerTypeId
		,CT.NAME AS ControllerType
		,C.ControllerVersion
		,C.InstallDate
		,C.EcoalabAccountNumber
		,C.LastModifiedTime
		,C.LastSyncTime
		,C.IsDeleted
		,C.TopicName
		,CMCTM.MaximumWasherExtractorCount WasherExtractorCount
		,CMCTM.MaxTunnelCount tunnelCount
	FROM [TCD].ConduitController C
	INNER JOIN [TCD].ControllerModel CM ON CM.Id = C.ControllerModelId
	INNER JOIN [TCD].ControllerType CT ON CT.Id = C.ControllerTypeId
	INNER JOIN [TCD].ControllerModelControllerTypeMapping CMCTM ON C.ControllerTypeId = CMCTM.ControllerTypeId
		AND C.ControllerModelId = CMCTM.ControllerModelId
	WHERE C.EcoalabAccountNumber = @EcolabAccountNumber
		AND (
			C.IsDeleted = 'False'
			OR C.IsDeleted = @IsDelete
			)
		AND c.ControllerId <> 0
		

	SET NOCOUNT OFF
END
