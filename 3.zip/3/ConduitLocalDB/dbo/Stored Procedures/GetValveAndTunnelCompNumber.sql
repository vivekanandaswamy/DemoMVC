﻿CREATE PROCEDURE [TCD].[GetValveAndTunnelCompNumber]  
    @ControllerEquipmentSetUpId     INT
,	@WasherGroupNumber				int
,	@ControllerEquipmentTypeId		int
AS
BEGIN

DECLARE @ControllerId int 
SET @ControllerId = (SELECT ces.ControllerId FROM tcd.ControllerEquipmentSetup ces WHERE ces.ControllerEquipmentSetupId = @ControllerEquipmentSetUpId AND ces.WasherGroupNumber = @WasherGroupNumber)
SET @ControllerEquipmentTypeId = (SELECT ces.ControllerEquipmentTypeId FROM tcd.ControllerEquipmentSetup ces WHERE ces.ControllerEquipmentSetupId = @ControllerEquipmentSetUpId )

SELECT 
    TCEVM.valveNumber,
    TCEVM.CompartmentNumber,
	TCEVM.ControllerEquipmentSetupID,
	@ControllerEquipmentTypeId
    FROM TCD.TunnelCompartmentEquipmentValveMapping TCEVM
    WHERE TCEVM.ControllerEquipmentSetUpId IN ( SELECT ces.ControllerEquipmentSetupId FROM tcd.ControllerEquipmentSetup ces WHERE ces.ControllerId = @ControllerId AND ces.WasherGroupNumber = @WasherGroupNumber AND ces.ControllerEquipmentTypeId = @ControllerEquipmentTypeId)
END;