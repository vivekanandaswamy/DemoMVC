﻿CREATE PROCEDURE TCD.GetControllerDetailsforTunnel
	 @EcolabAccountNumber NVARCHAR(25)
    , @WasherGroupId INT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE
	    @WasherId INT;

    SELECT @WasherId = ms.WasherId
	 FROM TCD.MachineSetup ms
	 WHERE ms.GroupId = @WasherGroupId AND ms.EcoalabAccountNumber = @EcolabAccountNumber;

    CREATE TABLE #TempControllers
    (
    ControllerId INT
  , ControllerModelId INT
  , ControllerModelName NVARCHAR(100)
  , ControllerName NVARCHAR(100)
  , ControllerNumber INT
  , ControllerTypeId INT
  , ControllerType VARCHAR(100)
  , ControllerVersion VARCHAR(10)
  , InstallDate DATETIME
  , EcoalabAccountNumber NVARCHAR(25)
  , LastModifiedTime DATETIME
  , LastSyncTime DATETIME
  , IsDeleted BIT
  , TopicName VARCHAR(100)
    );
    INSERT INTO #TempControllers
    SELECT C.ControllerId
	    , C.ControllerModelId
	    , CM.Name AS ControllerModelName
	    , C.Name AS ControllerName
	    , C.ControllerNumber
	    , C.ControllerTypeId
	    , CT.Name AS ControllerType
	    , C.ControllerVersion
	    , C.InstallDate
	    , C.EcoalabAccountNumber
	    , C.LastModifiedTime
	    , C.LastSyncTime
	    , C.IsDeleted
	    , C.TopicName
	 FROM TCD.ConduitController C
		 INNER JOIN
		 TCD.ControllerModel CM ON CM.Id = C.ControllerModelId
		 INNER JOIN
		 TCD.ControllerType CT ON CT.Id = C.ControllerTypeId
		 JOIN
		 TCD.ControllerModelControllerTypeMapping CMCTM ON C.ControllerTypeId = CMCTM.ControllerTypeId
											  AND C.ControllerModelId = CMCTM.ControllerModelId
	 WHERE
	 C.EcoalabAccountNumber = @EcolabAccountNumber
  AND CMCTM.MaxtunnelCount > 0
  AND C.IsDeleted = 0
  AND C.ControllerId <> 0
  AND C.ControllerModelId <> 7
  AND C.ControllerId NOT IN (
	 SELECT ms.ControllerId
	   FROM TCD.MachineSetup MS
	   WHERE ms.EcoalabAccountNumber = @EcolabAccountNumber
		AND ms.IsDeleted = 0
		AND ms.IsTunnel = 1);
    INSERT INTO #TempControllers
    SELECT DISTINCT C.ControllerId
			   , C.ControllerModelId
			   , CM.Name ControllerModelName
			   , C.Name ControllerName
			   , C.ControllerNumber
			   , C.ControllerTypeId
			   , CT.Name AS ControllerType
			   , C.ControllerVersion
			   , C.InstallDate
			   , C.EcoalabAccountNumber
			   , C.LastModifiedTime
			   , C.LastSyncTime
			   , C.IsDeleted
			   , C.TopicName
	 FROM TCD.ConduitController C
		 INNER JOIN
		 TCD.ControllerModel CM ON CM.Id = C.ControllerModelId
		 INNER JOIN
		 TCD.ControllerType CT ON CT.Id = C.ControllerTypeId
		 JOIN
		 TCD.ControllerModelControllerTypeMapping CMCTM ON C.ControllerTypeId = CMCTM.ControllerTypeId
											  AND C.ControllerModelId = CMCTM.ControllerModelId
	 WHERE
	 C.EcoalabAccountNumber = @EcolabAccountNumber
  AND (C.ControllerId IN (
	  SELECT ms.ControllerId
	    FROM TCD.MachineSetup ms
	    WHERE ms.EcoalabAccountNumber = @EcolabAccountNumber
		 AND ms.IsDeleted = 0
		 AND ms.IsTunnel = 1
		 AND ms.WasherId = @WasherId)
    OR C.ControllerId IN (
	  SELECT SQ.ControllerId
	    FROM(
	  SELECT CC.ControllerId
		  , COUNT(CC.ControllerId)AS Count
	    FROM TCD.ConduitController CC
		    LEFT JOIN
		    TCD.MachineSetup MS ON CC.ControllerId = MS.ControllerId
						   AND CC.EcoalabAccountNumber = MS.EcoalabAccountNumber
						   AND MS.IsDeleted = 0
						   AND MS.IsTunnel = 1
	    WHERE CC.EcoalabAccountNumber = @EcolabAccountNumber
		 AND CC.ControllerModelId = 7
     AND CC.IsDeleted = 0
	    GROUP BY CC.ControllerId)AS SQ
	    WHERE Count < 2)
      OR C.ControllerId IN (

	  SELECT SQ.ControllerId
	    FROM(

	  SELECT CC.ControllerId
		  , COUNT(CC.ControllerId)AS Count
	    FROM TCD.ConduitController CC
		    LEFT JOIN
		    TCD.MachineSetup MS ON CC.ControllerId = MS.ControllerId
						   AND CC.EcoalabAccountNumber = MS.EcoalabAccountNumber
						   AND MS.IsDeleted = 0
						   AND MS.IsTunnel = 1
	    WHERE CC.EcoalabAccountNumber = @EcolabAccountNumber
		 AND CC.ControllerModelId = 11 AND CC.ControllerTypeId =14
		 AND CC.IsDeleted = 0
	    GROUP BY CC.ControllerId
		
		)AS SQ
	    WHERE Count < 2)
      );
    SELECT *
	 FROM #TempControllers;
    DROP TABLE #TempControllers;
    SET NOCOUNT OFF;
END;