﻿
/*     
 ==========================================================================================  
 Purpose:  soft deleting the Customers List and also Auditing the data.     

 Author:  Premchand Yelavarthi     

 --------------------------------------------------------------     
 July-18-2014 ENT: Initial version.     
 ==========================================================================================  
*/ 

CREATE PROCEDURE [TCD].[DeletePlantCustomer] (
	@ID NVARCHAR(100)
,	@UserID INT
,	@EcolabAccountNumber					NVARCHAR(25) 
,	@LastModifiedTimestampAtCentral			DATETIME		=	NULL
,	@OutputLastModifiedTimestampAtLocal		DATETIME		=	NULL	OUTPUT
)

AS 
  BEGIN 
      SET NOCOUNT ON; 

      --DECLARE @Table_name NVARCHAR(1000) = 'plantcustomer' 
     
	  DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()

	DECLARE
		@OutputList						AS	TABLE		(
		LastModifiedTimestamp			DATETIME		)
	
	SET @OutputLastModifiedTimestampAtLocal			=			ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight SA0121

--If the call is not local, check that the LastModifiedTime matches with the central
IF	(
		@LastModifiedTimestampAtCentral				IS NOT	NULL
	AND
	NOT	EXISTS	(	SELECT	1
					FROM	TCD.PlantCustomer		PC
					WHERE	PC.EcolabAccountNumber	=	@EcolabAccountNumber
						AND	PC.Id					=	@Id
						AND	PC.LastModifiedTime		=	@LastModifiedTimestampAtCentral
				)
	)
		BEGIN
				SET			@ErrorId				=	60000
				SET			@ErrorMessage			=	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
				RAISERROR	(@ErrorMessage, 16, 1)
				SET			@ReturnValue			=	-1
				RETURN		(@ReturnValue)
		END

	--Proceed to soft-delete, since it's either a local call or Synch. call with synch. time matching

	  UPDATE [TCD].PlantCustomer 
	  SET    
	  Is_Deleted = 1 
	  ,	LastModifiedByUserId	=	@UserId
      ,	LastModifiedTime			=	@CurrentUTCTime
	OUTPUT
		inserted.LastModifiedTime	AS	LastModifiedTimestamp
	INTO
		@OutputList	(
		LastModifiedTimestamp
	)
	  WHERE  
	  Id = @ID 
	  AND
	  EcolabAccountNumber	=	@EcolabAccountNumber

	 
	 SELECT	TOP 1	
		@OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp
	FROM	@OutputList							O

	RETURN		(@ReturnValue)
	 
	--SET NOCOUNT OFF; 
	
	 /* Auditing the deleted data in the customer table */

	 --EXEC [TCD].[AuditingDeleteDetails] @ID,@Table_name,@UserID
     
  END 

  
/* -----------TEST CASES --------------
    
  SELECT * FROM AUDITCOLUMNS

  SELECT * FROM AUDITCOLUMNSDETAILS_NEW

    SELECT * FROM plantcustomer ORDER BY ID

  [dbo].[usp_AuditingDeleteDetails] 

DELETE FROM PLANTCONTACT WHERE CONTACTFIRSTNAME = 'PREMCHAND'  


*/ 