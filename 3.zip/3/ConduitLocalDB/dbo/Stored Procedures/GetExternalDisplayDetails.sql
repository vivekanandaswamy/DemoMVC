CREATE PROCEDURE [TCD].[GetExternalDisplayDetails]
AS
BEGIN
SET NOCOUNT ON
	SELECT  DISTINCT
					DB.DashBoardId,
					DB.DashBoardName,
					MN.MonitorName AS MonitorName,
					MN.MONITORID AS MonitorId,
					MN.XBound,
					MN.YBound,
					WGT.WasherGroupTypeName AS DashboardType,
					WGT.WasherGroupTypeId AS TypeId,
					DB.EcolabAccountNumber
		FROM		[TCD].MonitorSetUpMapping MSM
		INNER JOIN [TCD].Monitor MN ON MSM.MonitorId=MN.MONITORID
				INNER JOIN [TCD].Dashboard DB ON DB.DashboardId=MSM.DashboardId
				INNER JOIN [TCD].WasherGroupType WGT ON WGT.WasherGroupTypeId=DB.TypeId
		WHERE	MSM.IsDeleted=0
SET NOCOUNT OFF
END