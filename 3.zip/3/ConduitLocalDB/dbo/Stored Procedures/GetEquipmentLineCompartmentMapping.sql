﻿CREATE PROCEDURE TCD.GetEquipmentLineCompartmentMapping (
	 @LineNumber INT
    , @ControllerId INT
    , @EquipmentId	INT = NULL
    , @EcolabAccountNumber nvarchar(25))
AS
BEGIN
    DECLARE
	    @DDFlag BIT = CAST(
	    CASE
	    WHEN EXISTS(SELECT 1
				   FROM TCD.TunnelCompartmentEquipmentValveMapping TCEVM
					   JOIN
					   TCD.ControllerEquipmentSetup CES ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupID
				   WHERE CES.ControllerEquipmentId = @EquipmentId
					AND TCEVM.DirectDosingFlag = 1) THEN 1
		   ELSE 0
	    END
	    AS BIT);
    SELECT
    TCEVM.TunnelCompartmentEquipmentValveMappingID
  , CES.ControllerEquipmentId
  , CES.ControllerID
  , TCEVM.TunnelNumber
  , CES.LineNumber
  , TCEVM.DosingPointNumber
  , TCEVM.ValveNumber
  , TCEVM.CompartmentNumber
  , TCEVM.DirectDosingFlag
  , TCEVM.WasherExtractorNumber  
  , TCEVM.LastModifiedDate
	 FROM TCD.ControllerEquipmentSetup CES
		 JOIN
		 TCD.TunnelCompartmentEquipmentValveMapping TCEVM ON TCEVM.ControllerEquipmentSetupID = CES.ControllerEquipmentSetupId
	 WHERE
	 @DDFlag = 'TRUE'
  AND CES.ControllerEquipmentId = @EquipmentId
  AND TCEVM.DirectDosingFlag = 1
   OR @DDFlag = 'FALSE'
  AND CES.LineNumber = @LineNumber
  AND CES.ControllerId = @ControllerId;
END;
