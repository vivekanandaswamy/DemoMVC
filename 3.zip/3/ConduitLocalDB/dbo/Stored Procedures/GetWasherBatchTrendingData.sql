
CREATE PROCEDURE [TCD].[GetWasherBatchTrendingData](
	@DashBoardId         INT           = NULL,
	@EcolabAccountNumber NVARCHAR(25) = NULL,
	@StartTimeHrs        DATETIME      = NULL,
	@EndTimeHrs          DATETIME      = NULL)
AS
	BEGIN
	    SET NOCOUNT ON;              --SQLEnlight SA0017
		DECLARE
		@RegionId  Int = NULL

	    SET @EcolabAccountNumber = ISNULL(@EcolabAccountNumber, NULL);   --SQLEnlight SA0029
		select top 1 @RegionId = RegionId from TCD.Plant where EcolabAccountNumber=@EcoLabAccountNumber

	    SELECT DISTINCT
			 MS.GroupId,
			 MS.WasherID,
			 (CASE WHEN (@RegionId=1) THEN  BD.BatchId ELSE BD.ControllerBatchId END) AS BatchId,
			 Bd.ProgramMasterId,
			 PM.Name AS ProgramName,
			 DATEDIFF(SECOND, @StartTimeHrs, BD.StartDate) AS StartTime,
			 DATEDIFF(SECOND, @StartTimeHrs, BD.StartDate) + WPS.
			 TotalRunTime AS StandardEndTime,
			 DATEDIFF(SECOND, @StartTimeHrs, BD.EndDate) AS
			 ActualEndTime,
			 --Isnull(W.TargetTurnTime,10)* 60 as StandardTurnTime,
			 Isnull(BD.TargetTurnTime, 0) AS StandardTurnTime,
			 CASE
				WHEN BD.EndDate IS NULL
				THEN 1
				ELSE 0
			 END AS RunningStatus,
			 D.Formula AS DisplayFormula,
			 WPS.ProgramNumber,
			 D.DisplayFormulaType
	    FROM [TCD].MonitorSetUpMapping DM
		    INNER JOIN [TCD].MachineSetup MS ON DM.MachineId = MS. WasherID
		    INNER JOIN [TCD].Dashboard D ON DM.DashBoardId = D.DashBoardId
		    INNER JOIN [TCD].BatchData BD ON BD.MachineId = MS.WasherID
		    INNER JOIN [TCD].ProgramMaster PM ON PM.ProgramId = BD.ProgramMasterId
		    INNER JOIN [TCD].WasherProgramSetup WPS ON WPS.ProgramNumber = BD.ProgramNumber
											  AND  (WPS.ControllerID = MS.ControllerId 
											 OR WPS.WasherGroupId = MS.GroupId)
		    LEFT OUTER JOIN [TCD].Washer W ON W.WasherId = MS.WasherID
	    WHERE DM.DashboardId = @DashBoardId
			AND ((BD.StartDate >= DATEADD(HOUR, -1, @StartTimeHrs)
				 OR DATEADD(HOUR, -1, @StartTimeHrs) BETWEEN BD.StartDate AND BD.EndDate)
				OR (BD.EndDate IS NULL))
			AND WPS.Is_Deleted = 0
	    ORDER BY MS.WasherId,
			   (CASE WHEN (@RegionId=1) THEN  BD.BatchId ELSE BD.ControllerBatchId END);
	END;