﻿/*	                                   
###################################################################################################                                           

Stored Procedure:       [TCD].[GetBatchCustomerData]                                            

Purpose:				To Get The Batch Customer Data.

Parameters:				@BatchID- to get the batch customer data of a particular batchId.
																
###################################################################################################                                           
*/
CREATE PROCEDURE [TCD].[GetBatchCustomerData]
	-- Add the parameters for the stored procedure here
	@BatchID Int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT BatchId,CustomerId,Load,PiecesCount FROM BatchCustomerData 
	WHERE
	BatchId=@BatchID
END
