﻿/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_GetWasherGroupFormulaWashSteps]                                        

Purpose:				To get the washer group formula wash steps.

Parameters:				@EcoLabAccountNumber - holds the ecolab account number.
						@WasherGroupId	- holds the washer group id.
						@ProgramSetupId - holds the program setup id.
						@DosingSetupId - holds the dosing setup id.
																						
###################################################################################################                                           
*/
CREATE	PROCEDURE	[TCD].[GetWasherGroupFormulaWashSteps]
					@EcoLabAccountNumber					NVARCHAR(25)
				,	@WasherGroupId							INT
				,	@ProgramSetupId							INT
				,	@DosingSetupId							INT				=	NULL			--Null for LIST
				,   @Is_Deleted								BIT			    =	'FALSE'
AS
BEGIN

SET	NOCOUNT	ON

DECLARE
		@ControllerID							INT					=			NULL,
		@WasherGrIdForSensor INT = @WasherGroupId;

	SELECT	@WasherGroupId					=			WasherGroupId
		,	@ControllerID					=			ControllerID
	FROM [TCD].WasherProgramSetup 
	WHERE WasherProgramSetupId = @ProgramSetupId
	AND   EcolabAccountNumber = @EcoLabAccountNumber

	
				SELECT
				[WasherDosingSetupId] AS DosingSetupId
				,WPS.[ProgramNumber]
				,WPS.[WasherGroupId]
				,[StepNumber]
				,WS.[StepId] AS WashOperationId
				,WS.[StepName] AS WashOperation
				,[StepRunTime] AS RunTime
				,[Temperature]
				,[WaterType]
				,[WaterLevel]
				,DD.[DrainDestinationId] AS DrainDestinationId
				,DD.[DrainDestinationName] AS DrainDestination
				,[pHLevel]
				,[Note]
				,WS.MyServiceWshOpId
				,ISNULL((SELECT wt.MyServiceUtilId FROM TCD.WaterType wt WHERE  WDS.WaterType=WT.Id),NULL)
				,DD.DrainDestinationId	AS	MyServiceDrainTypId
				,WDS.Is_Deleted		As	IsDelete
				,WDS.MyserviceCustFrmulaStpGuid
				,WDS.MyServiceLastSynchTime
				,WDS.WasherProgramSetupId
				,WDS.TrackAsDosingStep
				,(SELECT STUFF((SELECT ',' + CAST(S.SensorType AS VARCHAR(2))  
     FROM TCD.Sensor S WHERE  S.GroupId = @WasherGrIdForSensor   
     AND S.EcolabAccountNumber = @EcoLabAccountNumber   
     AND S.Is_deleted = 0 GROUP BY S.SensorType  
     FOR XML PATH('')) ,1,1,'')) AS SensorAttached  
			FROM	[TCD].[WasherDosingSetup]			WDS
			INNER JOIN [TCD].[WasherProgramSetup] WPS 
				ON WPS.[WasherProgramSetupId] = WDS.[WasherProgramSetupId]
			LEFT JOIN	[TCD].WashStep				WS
				ON	WS.StepId					=			WDS.StepTypeId
			LEFT JOIN	[TCD].DrainDestination		DD
				ON	DD.DrainDestinationId		=			WDS.DrainDestinationId
			WHERE	
				WDS.WasherProgramSetupId		=			@ProgramSetupId
				AND WDS.EcolabAccountNumber		=			@EcoLabAccountNumber
				AND	(CASE WHEN @WasherGroupId IS NOT NULL 
						  THEN WDS.GroupId
						  ELSE WDS.ControllerID
					END)									= (CASE WHEN @WasherGroupId IS NOT NULL 
																	THEN @WasherGroupId
																	ELSE @ControllerID
																	END)
				AND	WDS.WasherDosingSetupId		=			ISNULL(@DosingSetupId, WDS.WasherDosingSetupId)
				AND (WDS.Is_Deleted				=			'FALSE' OR WDS.Is_Deleted = @Is_Deleted)
SET	NOCOUNT	OFF

END