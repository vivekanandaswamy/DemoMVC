﻿CREATE PROCEDURE [TCD].[GetCurrencyExchangeRate]
       @Sourcecurrencycode NVARCHAR(50), 
       @Targetcurrencycode NVARCHAR(50)
AS
BEGIN

SET	NOCOUNT	ON														--SQLEnlight	SA0017

    SELECT TOP 1
            ExchangeRateID, 
            CurrencyCode, 
            Rate, 
            TargetCurrencyCode, 
            EffectiveExchangeRateDate, 
            CreatedDate
        FROM TCD.CurrencyExchangeRate
        WHERE CurrencyCode = @Sourcecurrencycode
          AND TargetCurrencyCode = @Targetcurrencycode
        ORDER BY
            CreatedDate DESC;
END;

