﻿CREATE PROCEDURE [TCD].[GetPlantSettings]
	@EcolabAccountNumber NVARCHAR(25)
AS
	BEGIN
	SET NOCOUNT ON;
		SELECT  [PlantId]
		  ,	    [IPAddress]
		  ,		[PortNumber]
		  ,		[ReadTimeout]
		  ,		[PlantVersion]
		  ,		[LastModifiedTime]
		  ,		[FTRLastModifiedTime]
		  ,		[NodeId]
		FROM [TCD].[PlantSettings]
		WHERE [PlantId] = @EcolabAccountNumber
	SET NOCOUNT OFF;
	END 