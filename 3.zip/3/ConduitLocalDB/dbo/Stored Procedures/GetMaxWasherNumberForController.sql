﻿/*	
Purpose					:	To get the max. no. of Washers that can be connected to the Controller in Washer setup --> General tab

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version

*/

CREATE	PROCEDURE	[TCD].[GetMaxWasherNumberForController]
					@EcoLabAccountNumber					NVARCHAR(25)
				,	@ControllerId							INT
AS
BEGIN

SET	NOCOUNT	ON


SELECT
		CAST(CMCTM.MaximumWasherExtractorCount AS SMALLINT)
											AS			MaxWECountForController
FROM	[TCD].ConduitController					CC
JOIN	[TCD].ControllerModelControllerTypeMapping
											CMCTM
	ON	CC.ControllerTypeId					=			CMCTM.ControllerTypeId
	AND	CC.ControllerModelId				=			CMCTM.ControllerModelId
WHERE	CC.ControllerId						=			@ControllerId
	AND	CC.EcoalabAccountNumber				=			@EcoLabAccountNumber
	AND	CC.IsDeleted						=			'FALSE'


SET	NOCOUNT	OFF

END
