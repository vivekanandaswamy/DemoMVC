﻿/*    

==========================================================================================    

    

Purpose:  INSERTING THE FINNISHER DATA    

    

Author: Venkata Mohan Krishna K    

--------------------------------------------------------------    

    

Sep-25-2014 ENT: Initial version.    

    

==========================================================================================    

*/    

CREATE PROCEDURE [TCD].[SaveFinnisher](
@FinnisherGroupId   INT,    
	@Name NVARCHAR(1000),  
	@FinnisherTypeId INT,    
	@EcolabAccountNumber nvarchar(25),    
	@UserId Int,
	@FinnisherNo INT,    
	@Scope varchar(100) OUTPUT
	--Adding these 2 params as part of re-factoring for integration with Synch/Configurator
,	@OutputFinisherId						INT			=	NULL	OUTPUT
,	@OutputLastModifiedTimestampAtLocal		DATETIME	=	NULL	OUTPUT

	)    
AS    
    

SET NOCOUNT ON   
 

BEGIN    

DECLARE @Output Varchar(100) = ''    

DECLARE
		@OutputList					AS	TABLE		(
		FinisherId							INT
	,	LastModifiedTimestamp			DATETIME
	)

SET	@OutputFinisherId							=			ISNULL(@OutputFinisherId, NULL)			--SQLEnlight SA0121
SET	@OutputLastModifiedTimestampAtLocal			=			ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight SA0121
SET	@Scope										=			ISNULL(@Scope, NULL)					--SQLEnlight SA0121


IF	NOT EXISTS	(SELECT	1
				FROM	[TCD].[Finnishers]  
				WHERE	FinnisherNo=@FinnisherNo 
					and IS_DELETED = 0 
				)    
				BEGIN    
						IF	NOT EXISTS	(SELECT	1
										FROM	[TCD].[Finnishers]  
										WHERE	[Name] = @Name 
											and IS_DELETED = 0
										) 
										BEGIN
												INSERT INTO Finnishers	(
															FinnisherGroupId
														,	[Name]
														,	FinnisherNo
														,	FinnisherTypeId
														,	EcolabAccountNumber
														,	LastModifiedByUserId
														)    
												--**	Adding as part of Audit re-factor to capture the User info.
													OUTPUT	inserted.FinnisherId
														,	inserted.LastModifiedTime
													INTO	@OutputList	(
															FinisherId
														,	LastModifiedTimestamp
														)
												--**
												VALUES	(	@FinnisherGroupId
														,	@Name
														,	@FinnisherNo
														,	@FinnisherTypeId
														,	@EcolabAccountNumber
														,	@UserId
														)

												SET @OutPut = '101'    
												SET @Scope = @OutPut SELECT @Scope    
										END
						ELSE
										BEGIN
											SET @OutPut = '301'    
											SET @Scope = @OutPut SELECT @Scope    
										END
				END 
ELSE    
				BEGIN
					SET @OutPut = '302'    
					IF EXISTS(	SELECT 1 FROM [TCD].Finnishers WHERE Name = @Name  AND IS_DELETED = 0)  
						SET @OutPut = '303'  
					SET @Scope = @OutPut SELECT @Scope 
				END

IF @OutPut = '301'
	BEGIN
		SET		@OutputLastModifiedTimestampAtLocal			=			GETUTCDATE()
	END
ELSE IF @OutPut = '302' or @Output = '303'
	BEGIN
		SET		@OutputLastModifiedTimestampAtLocal			=			GETUTCDATE()
	END
ELSE
	BEGIN
		SELECT	TOP 1	
				@OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp
			,	@OutputFinisherId					=	O.FinisherId
		FROM	@OutputList							O

	END





END




