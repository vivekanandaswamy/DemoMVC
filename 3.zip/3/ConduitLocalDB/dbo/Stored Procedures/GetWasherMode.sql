﻿/*	
Purpose					:	To populate the drop-down (Washer Mode) in the Washer setup --> General tab

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version

*/

CREATE PROCEDURE [TCD].[GetWasherMode] 
									@EcoLabAccountNumber NVARCHAR(25) , 
									@ControllerId INT , 
									@WasherType nchar(10)  = 'T'
AS
BEGIN
	SET	NOCOUNT	ON;
	SELECT WM.WasherModeId	AS Id,
			ISNULL(CAST(WasherModeNumber AS VARCHAR),'') + '- ' + WM.WasherModeName AS Name,
			WM.ResourceKey,
			CAST(WMM.WasherModeNumber AS VARCHAR) WasherModeNumber
		FROM TCD.ConduitController AS CC
		JOIN TCD.ControllerModelControllerTypeMapping AS CMCTM ON CC.ControllerTypeId = CMCTM.ControllerTypeId
			AND CC.ControllerModelId = CMCTM.ControllerModelId
		LEFT JOIN TCD.WasherModeMapping AS WMM ON CMCTM.Id = WMM.ControllerModelControllerTypeMappingId
		JOIN TCD.WasherMode AS WM ON WM.WasherModeId = WMM.WasherModeId
		WHERE	CC.ControllerId = @ControllerId
			AND CC.EcoalabAccountNumber = @EcoLabAccountNumber
			AND CC.IsDeleted = 0
			AND WMM.WasherType = @WasherType
		ORDER BY WMM.WasherModeNumber;
	SET	NOCOUNT	OFF;
END;