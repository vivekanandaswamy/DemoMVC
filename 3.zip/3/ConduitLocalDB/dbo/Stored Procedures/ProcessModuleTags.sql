﻿CREATE PROCEDURE [TCD].[ProcessModuleTags]
(	
	@ModuleId INT,
	@ModuleTypeId INT,	
	@Reading DECIMAL(18,4),
	@TimeStamp DATETIME,
	@RollOverPoint INT,
	@Usage DECIMAL(18,4)
)

AS
SET NOCOUNT ON
BEGIN

DECLARE @PlantId int = NULL

DECLARE @ShiftStartDate table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
INSERT INTO @ShiftStartDate(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @TimeStamp

SELECT @PlantId = p.PlantId FROM TCD.Plant p

		BEGIN
		
		
		 IF(@ModuleTypeId = 3)
		  BEGIN
		  IF NOT EXISTS(SELECT * FROM TCD.[SensorReading] WHERE SensorId=@ModuleId AND [TimeStamp]=@TimeStamp)
			BEGIN
				INSERT INTO [TCD].[SensorReading](
											  SensorId,
											  [Reading],
											  [TimeStamp]
 										   )
				VALUES
					(	@ModuleId,
						@Reading,
						@TimeStamp					
					)
			END			
			END
			ELSE
			BEGIN
									
			IF NOT EXISTS(SELECT * FROM TCD.[ModuleReading] WHERE [ModuleId]=@ModuleId AND [ModuleTypeId] = @ModuleTypeId AND [TimeStamp]=@TimeStamp)
			BEGIN
				INSERT INTO [TCD].[ModuleReading](
										   [ModuleId],
										   [ModuleTypeId],
										   [Reading],
										   [TimeStamp],
										   [Usage],
										   [PlantId],
										   [PartitionOn],
										   [ShiftId]
										   )
				 VALUES
					(	@ModuleId,
						@ModuleTypeId,
						@Reading,
						@TimeStamp,
						@Usage,
						@PlantId,
						(SELECT Top 1 ShiftStartdate from @ShiftStartDate),
						(SELECT Top 1 ShiftId from @ShiftStartDate)
					)
			END			
		  END
			
		END		  		   
END