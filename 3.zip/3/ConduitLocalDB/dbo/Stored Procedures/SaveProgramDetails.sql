﻿CREATE PROCEDURE [TCD].[SaveProgramDetails] (
              @ProgramId INT
		    ,@PlantProgramId INT
		    ,@FormulaCategoryId int 
		    ,@EcolabSaturationId INT = NULL
		    ,@CustomerId INT
		    ,@Rewash BIT = NULL
		    ,@Pieces INT = NULL
		    ,@Weight_Display DECIMAL = NULL    
		    ,@Name NVARCHAR(100)
		    ,@FormulaSegmentId INT
            ,@Weight DECIMAL = NULL
            ,@UserID INT       
		    ,@PlantChainId INT
              --Adding these 3 param as part of re-factoring for integration with Synch/Configurator
            ,@OutputProgramId                    INT                    =            NULL    OUTPUT
            ,@LastModifiedTimestampAtCentral        DATETIME            =            NULL            --Nullable for local call; Synch/Central call will have to pass this -
            ,@OutputLastModifiedTimestampAtLocal    DATETIME            =            NULL    OUTPUT
            ,@EcolabAccountNumber                NVARCHAR(25)
            ) 
AS 
  BEGIN 
      SET nocount ON;  --Commented old Audit Technique-- 
	  SET @Weight_Display = @Weight;
DECLARE    
        @ReturnValue                    INT                =            0
    ,    @ErrorId                        INT                =            0
    ,    @ErrorMessage                    NVARCHAR(4000)    =            N''
    ,    @CurrentUTCTime                    DATETIME        =            GETUTCDATE()

DECLARE
        @OutputList                        AS    TABLE        (
        ProgramMasterId                    INT
    ,    LastModifiedTimestamp            DATETIME
    )

    SET        @OutputProgramId                            =            ISNULL(@OutputProgramId, NULL)                        --SQLEnlight SA0121
    SET        @OutputLastModifiedTimestampAtLocal            =            ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)    --SQLEnlight SA0121

      IF NOT EXISTS (SELECT 1 FROM [TCD].ProgramMaster WHERE ProgramId = @ProgramId)
      BEGIN

        IF EXISTS(SELECT 1 FROM [TCD].ProgramMaster Where Name = @Name AND Is_Deleted = 0)
        BEGIN
            SET @ErrorMessage ='303 - Formula Name already exists.'
            RAISERROR(@ErrorMessage, 16, 1)
            RETURN
        END 
        
        SELECT @ProgramId = ISNULL(MAX(ProgramId), 0) + 1 FROM [TCD].ProgramMaster 
      
	  SELECT @PlantChainId = (SELECT PlantChainId FROM tcd.plant WHERE EcolabAccountNumber = @EcolabAccountNumber)

	   IF(@PlantChainId > 0)
		  BEGIN
			 INSERT INTO TCD.ProgramMaster
			 (
				ProgramId,
				Name,
				Pieces,
				Rewash,
				[Weight],
				EcolabSaturationId,
				EcolabAccountNumber,
				FormulaSegmentId,
				PlantProgramId,
				CustomerId,
				LastModifiedByUserId,
				Weight_Display
			 )
			 OUTPUT
				inserted.ProgramId                AS            ProgramMasterId
			 ,   inserted.LastModifiedTime        AS            LastModifiedTimestamp
			 INTO
				@OutputList    (
				    ProgramMasterId
				,   LastModifiedTimestamp
			 ) 
			 VALUES
			 (
			 @ProgramId,
			 @Name,
			 @Pieces,
			 @Rewash,
			 @Weight,
			 @EcolabSaturationId,
			 @EcolabAccountNumber,
			 @FormulaSegmentId,
			 @PlantProgramId,
			 @CustomerId,
			 @UserId,
			 @Weight_Display
			 )

		  END
	   ELSE
		  BEGIN
			 INSERT INTO TCD.ProgramMaster
			 (
			     ProgramId,
			     Name,
			     Pieces,
			     EcolabTextileCategoryId,
			     FormulaSegmentId,
			     Rewash,
			     [Weight],
			     EcolabSaturationId,
			     EcolabAccountNumber,
			     CustomerId,
			     LastModifiedByUserId,
			     Weight_Display
			 )
			 OUTPUT
				inserted.ProgramId                AS            ProgramMasterId
			 ,   inserted.LastModifiedTime        AS            LastModifiedTimestamp
			 INTO
				@OutputList    (
				    ProgramMasterId
				,   LastModifiedTimestamp
			 ) 
			 VALUES
			 (
			      @ProgramId,
				 @Name,
				 @Pieces,
				 @FormulaCategoryId,
				 @FormulaSegmentId,
				 @Rewash,
				 @Weight,
				 @EcolabSaturationId,
				 @EcolabAccountNumber,
				 @CustomerId,
				 @UserID,
				 @Weight_Display
			 )
		  END
      END
    
      ELSE
      BEGIN
      /*Update record if program exists */
      IF EXISTS(SELECT 1 FROM [TCD].ProgramMaster Where Name = @Name AND ProgramId != @ProgramId AND Is_Deleted = 0)
        BEGIN
            SET @ErrorMessage ='303 - Formula Name already exists.'
            RAISERROR(@ErrorMessage, 16, 1)
            RETURN
        END 

            --If the call is not local, check that the LastModifiedTime matches with the central
            IF    (
                    @LastModifiedTimestampAtCentral                IS NOT    NULL
                AND
                NOT    EXISTS    (    SELECT    1
                                FROM    TCD.ProgramMaster        PM
                                WHERE    PM.EcolabAccountNumber    =    @EcolabAccountNumber
                                    AND    PM.ProgramId            =    @ProgramId
                                    AND    PM.LastModifiedTime        =    @LastModifiedTimestampAtCentral
                            )
                )
                    BEGIN
                            SET            @ErrorId                =    60000
                            SET            @ErrorMessage            =    N'' + CAST(@ErrorId AS NVARCHAR) + N': Record not in-synch between plant and central.'
                            RAISERROR    (@ErrorMessage, 16, 1)
                            SET            @ReturnValue            =    -1
                            RETURN        (@ReturnValue)
                    END

				IF (@PlantChainId > 0)
				    BEGIN
				    UPDATE TCD.ProgramMaster
				    SET
				        Name = @Name, 
				        Pieces = @Pieces,
				        Rewash = @Rewash, 
				        [Weight] = @Weight,
				        PlantProgramId = @PlantProgramId,
					    FormulaSegmentId = @FormulaSegmentId,
					    EcolabSaturationId = @EcolabSaturationId,
				        CustomerId = @CustomerId, 
				        LastModifiedByUserId = @UserID, 
				        Weight_Display = @Weight_Display 
					   OUTPUT
							 inserted.ProgramId                AS            ProgramMasterId
						  ,    inserted.LastModifiedTime        AS            LastModifiedTimestamp
					   INTO
							 @OutputList    (
							 ProgramMasterId
						  ,    LastModifiedTimestamp
						  )    
				    WHERE 
					   ProgramId  = @ProgramId 
					  AND 
					   EcolabAccountNumber  = @EcolabAccountNumber
				    END
				ELSE
				    BEGIN
					   UPDATE TCD.ProgramMaster
					   SET
					       Name = @Name,
					       Pieces = @Pieces, 
					       EcolabTextileCategoryId = @FormulaCategoryId, 
					       FormulaSegmentId = @FormulaSegmentId, 
					       Rewash = @Rewash, 
					       [Weight] = @Weight, 
					       EcolabSaturationId = @EcolabSaturationId, 
					       CustomerId = @CustomerId,
					       LastModifiedByUserId = @UserID, 
					       Weight_Display = @Weight 
						   OUTPUT
							 inserted.ProgramId                AS            ProgramMasterId
						  ,    inserted.LastModifiedTime        AS            LastModifiedTimestamp
						  INTO
							 @OutputList    (
							 ProgramMasterId
						  ,    LastModifiedTimestamp
						  )    
					   WHERE 
						  ProgramId = @ProgramId
					   AND
						  EcolabAccountNumber = @EcolabAccountNumber
				    END
      END
    
SELECT    TOP 1    
        @OutputLastModifiedTimestampAtLocal    =    O.LastModifiedTimestamp
    ,    @OutputProgramId                    =    O.ProgramMasterId
FROM    @OutputList                            O

  END