﻿CREATE PROCEDURE [TCD].[GetPlantChainProgramByPlantChainId]
	   @Plantchainid INT = NULL
AS
BEGIN
	SET NOCOUNT ON;

	SELECT	DISTINCT pcp.PlantProgramId, 
			pcp.PlantProgramName, 
			pcp.ChainTextileCategoryId AS ChainTextileId,
			ctc.Name AS ChainTextileName, 
			etc.TextileId AS EcolabTextileCategoryId, 
			etc.CategoryName AS EcolabTextileCategoryName, 	  
			fs.FormulaSegmentID, 
			fs.SegmentName,
			pcp.LastModifiedTime, 
			pcp.Is_Deleted, 
			pcp.PlantChainId,
			es.EcolabSaturationId, 
			es.EcolabSaturationName
	FROM TCD.PlantChainProgram AS pcp
	INNER JOIN TCD.Plant p ON p.PlantChainId = pcp.PlantChainId 
  LEFT JOIN TCD.ChainTextileCategory ctc
  ON pcp.ChainTextileCategoryId = ctc.TextileId AND ctc.PlantChainId = pcp.PlantChainId
  LEFT JOIN TCD.EcolabTextileCategory etc
  ON pcp.EcolabTextileCategoryId = etc.TextileId
  LEFT JOIN TCD.EcolabSaturation es
  ON pcp.EcolabSaturationId = es.EcolabSaturationId
  LEFT JOIN TCD.FormulaSegments fs
  ON pcp.FormulaSegmentId = fs.FormulaSegmentID
  WHERE pcp.PlantChainId = @Plantchainid

END