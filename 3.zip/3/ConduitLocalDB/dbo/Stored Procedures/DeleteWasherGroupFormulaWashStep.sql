﻿/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_DeleteWasherGroupFormulaWashStep]                                          

Purpose:				To delete the washer group formula wash steps.

Parameters:				@EcoLabAccountNumber - holds the ecolab account number.
						@WasherGroupId	- holds the washer group id.
						@DosingSetupId - holds the dosing setup id.
						@UserId - holds the user id.
																						
###################################################################################################                                           
*/
CREATE	PROCEDURE	[TCD].[DeleteWasherGroupFormulaWashStep]
					@EcoLabAccountNumber					NVARCHAR(25)
				,	@WasherGroupId							INT
				,	@ProgramSetupId							SMALLINT
				,	@DosingSetupId							INT
				,	@UserId									INT
				,	@LastModifiedTimestampAtCentral			DATETIME					=	NULL
AS
BEGIN

SET	NOCOUNT	ON


DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()

	--,	@WasherGroupNumber				VARCHAR(10)		=			NULL
	--,	@WasherGroupName				NVARCHAR(50)	=			NULL			--SQLEnlight	SA0004
	--,	@WasherGroupTypeId				TINYINT			=			NULL
	,	@WasherGroupTypeName			VARCHAR(30)		=			NULL
	,	@TotalRunTime					INT
	,	@TotalSteps						INT



--Determine the WasherGroup type - Conventional/Tunnel
SELECT	/*@WasherGroupTypeId			=			WGT.WasherGroupTypeId													--SQLEnlight	SA0004
	,	*/@WasherGroupTypeName		=			WGT.WasherGroupTypeName
	--,	@WasherGroupNumber			=			WG.WasherGroupNumber														--SQLEnlight	SA0004
FROM	[TCD].WasherGroup					WG
JOIN	[TCD].WasherGroupType				WGT
	ON	WG.WasherGroupTypeId		=			WGT.WasherGroupTypeId
JOIN	[TCD].MachineGroup					GT
	ON	WG.WasherGroupId			=			GT.Id
WHERE	GT.EcolabAccountNumber		=			@EcoLabAccountNumber
	AND	WG.WasherGroupId			=			@WasherGroupId

IF	(	@WasherGroupTypeName		IS			NULL)
	BEGIN
			SET		@ErrorId		=			51000
			SET		@ErrorMessage	=			N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Could not determine the WasherGroup Type... Aborting.'
			--GOTO	ErrorHandler
			RAISERROR	(@ErrorMessage, 16, 1)
			SET	@ReturnValue	=	-1
			RETURN	(@ReturnValue)
	END


IF	(	@WasherGroupTypeName	=	'Tunnel'	)
	BEGIN

	IF	(
									@LastModifiedTimestampAtCentral				IS NOT	NULL
									AND
									NOT	EXISTS	(	SELECT	1
											FROM	TCD.TunnelProgramSetup		TPS
											WHERE	TPS.EcolabAccountNumber		=	@EcolabAccountNumber
												AND	TPS.TunnelProgramSetupId	=	@ProgramSetupId
												AND	TPS.LastModifiedTime		=	@LastModifiedTimestampAtCentral
										)
							)
								BEGIN
										SET			@ErrorId				=	60000
										SET			@ErrorMessage			=	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
										RAISERROR	(@ErrorMessage, 16, 1)
										SET			@ReturnValue			=	-1
										RETURN		(@ReturnValue)
								END
	
		SET @WasherGroupTypeName	=	'Tunnel'
		--Soft-delete the record
		UPDATE	[TCD].TunnelDosingSetup
			SET	Is_Deleted					=			'TRUE'
			,	LastModifiedByUserId		=			@UserId
		WHERE	
			EcolabAccountNumber		=			@EcoLabAccountNumber
			AND	TunnelDosingSetupId	=			@DosingSetupId
		
		--check for any error
		SET	@ErrorId	=	@@ERROR
	
		IF	(@ErrorId	<>	0)
			BEGIN
					SET		@ErrorMessage	=			N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred dissociating formula wash step for the tunnel washer group.'
					--GOTO	ErrorHandler
					RAISERROR	(@ErrorMessage, 16, 1)
					SET	@ReturnValue	=	-1
					RETURN	(@ReturnValue)
			END
	END
ELSE	IF	(	@WasherGroupTypeName	=	'Conventional'	)
			BEGIN

			IF	(
									@LastModifiedTimestampAtCentral				IS NOT	NULL
									AND
									NOT	EXISTS	(	SELECT	1
											FROM	TCD.WasherProgramSetup		WPS
											WHERE	WPS.EcolabAccountNumber		=	@EcolabAccountNumber
												AND	WPS.WasherProgramSetupId	=	@ProgramSetupId
												AND	WPS.LastModifiedTime		=	@LastModifiedTimestampAtCentral
										)
							)
								BEGIN
										SET			@ErrorId				=	60000
										SET			@ErrorMessage			=	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
										RAISERROR	(@ErrorMessage, 16, 1)
										SET			@ReturnValue			=	-1
										RETURN		(@ReturnValue)
								END


				--Soft-delete the record
				UPDATE	[TCD].WasherDosingSetup
					SET	Is_Deleted					=			'TRUE'
					,	LastModifiedByUserId		=			@UserId
				WHERE	
					EcolabAccountNumber		=			@EcoLabAccountNumber
					AND	WasherDosingSetupId	=			@DosingSetupId
		
		SELECT @TotalRunTime=sum(wds.StepRunTime), @TotalSteps=COUNT(*) FROM tcd.WasherDosingSetup wds WHERE WasherProgramSetupId = @ProgramSetupId AND wds.GroupId=@WasherGroupId AND wds.EcoLabAccountNumber=@EcoLabAccountNumber AND wds.Is_Deleted=0

				

				-- -- For Reording the washer injection based on the update or insert of the productdosing for the washer.

				EXEC [TCD].[WasherInjectionOrdering] @ProgramSetupId,@EcolabAccountNumber

--------------------------------------------
--- Starting of WashStep ReOrdering 
--------------------------------------------


   DECLARE @ResultTable TABLE
			 (
			 stepNumber Int,
			 NewWashStep int,
			 WasherProgramSetupId int,
			 WasherDosingSetUpId INT
			 )

   INSERT @ResultTable
   (
      stepNumber,
      NewWashStep,
	 WasherProgramSetupId,
	 WasherDosingSetUpId
   )
SELECT  wds.StepNumber,DENSE_RANK() OVER(ORDER BY wds.StepNumber) AS NewWashStep,wds.WasherProgramSetupId,wds.WasherDosingSetupId
 FROM TCD.WasherDosingSetup wds WHERE wds.WasherProgramSetupId=@ProgramSetupId AND wds.StepNumber<>0 AND wds.Is_Deleted=0

UPDATE wds SET wds.StepNumber=rt.NewWashStep
 FROM TCD.WasherDosingSetup wds 
 	   INNER JOIN (SELECT DISTINCT R.stepNumber,R.NewWashStep,R.WasherProgramSetupId,R.WasherDosingSetUpId FROM @ResultTable R) rt
									    ON  wds.WasherProgramSetupId = rt.WasherProgramSetupId AND wds.WasherDosingSetupId=rt.WasherDosingSetUpId
									    WHERE rt.WasherProgramSetupId = @ProgramSetupId AND wds.Is_Deleted = 0

--------------------------------------------
--- END of WashStep ReOrdering 
--------------------------------------------







				--check for any error
				SET	@ErrorId	=	@@ERROR
	
				IF	(@ErrorId	<>	0)
					BEGIN
							SET		@ErrorMessage	=			N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred dissociating formula wash step for the conventional washer group.'
							--GOTO	ErrorHandler
							RAISERROR	(@ErrorMessage, 16, 1)
							SET	@ReturnValue	=	-1
							RETURN	(@ReturnValue)
					END
			END




IF	(	@ErrorId	=	0	)
	BEGIN
		--GOTO	ExitModule
		RETURN	(@ReturnValue)
	END




--ErrorHandler:
--RAISERROR	(@ErrorMessage, 16, 1)
--SET	@ReturnValue	=	-1




--ExitModule:

SET	NOCOUNT	OFF
RETURN	(@ReturnValue)


END