﻿/*
Purpose					:	To populate the drop-down (Pumps/Valves) in the Tunnel setup --> Comaprtments tab

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version


*/

CREATE	PROCEDURE	[TCD].[GetEquipmentListForCompartmentSetup]
					@EcoLabAccountNumber					NVARCHAR(25)
				,	@ControllerId							INT
				,	@TunnelId								INT
AS
BEGIN

SET	NOCOUNT	ON


SELECT	CES.ControllerEquipmentSetupId		AS			ControllerEquipmentSetupId
	,	CES.ControllerEquipmentId			AS			ControllerEquipmentId
	,	CAST(CES.ControllerEquipmentId AS VARCHAR(3))
											AS			ControllerEquipmentIdASCHAR
	,	CES.ControllerEquipmentTypeId		AS			ControllerEquipmentTypeId
	,	CES.LfsChemicalName					AS			ProductName
FROM	[TCD].ControllerEquipmentSetup			CES
JOIN	[TCD].ConduitController					CC
	ON	CES.EcoLabAccountNumber				=			CC.EcoalabAccountNumber
	AND	CES.ControllerId					=			CC.ControllerId
JOIN	[TCD].ControllerModelControllerTypeMapping
											CMCTM
	ON	CC.ControllerModelId				=			CMCTM.ControllerModelId
	AND	CC.ControllerTypeId					=			CMCTM.ControllerTypeId
JOIN	[TCD].ProductMaster						PM
	ON	CES.ProductId						=			PM.ProductId
WHERE	CES.EcoLabAccountNumber				=			@EcoLabAccountNumber
	AND	CES.ControllerId					=			@ControllerId
	AND	CC.IsDeleted						=			'FALSE'
	AND	CES.ProductId						IS	NOT		NULL
	AND	CES.IsActive						=			'TRUE'
	AND	CMCTM.MaxtunnelCount > 0
	AND										EXISTS		(	SELECT	1
															FROM	[TCD].MachineSetup			MS
															WHERE	MS.WasherId				=			@TunnelId
																AND	MS.ControllerId			=			@ControllerId
																AND	MS.IsDeleted			=			'FALSE'
														)
	AND										NOT EXISTS  (   SELECT	 1
											FROM	 TCD.TunnelCompartmentEquipmentMapping		    TCEM
											JOIN	 TCD.TunnelCompartment					    TC
											ON	 TCEM.TunnelCompartmentId				    =		 TC.TunnelCompartmentId
											WHERE	 TC.EcoLabAccountNumber					    =		 @EcoLabAccountNumber
											   AND TC.WasherId							=			  @TunnelId
											   AND TCEM.ControllerEquipmentSetupId			 =			  CES.ControllerEquipmentSetupId
											   AND TCEM.Is_Deleted						 =			  'FALSE'
														)


SET	NOCOUNT	OFF


END
