Create PROCEDURE [TCD].[GetLabourCost] 
(
@LocationId int,
@type int
)

AS 

  BEGIN 
SET NOCOUNT ON;
			SELECT 25
SET NOCOUNT OFF;
  END 
