CREATE PROCEDURE [TCD].[SaveMonitors]
(
@MonitorId nvarchar(MAX),
@EcolabAccountNumber NVARCHAR(25),
@MonitorName NVARCHAR(150),
@XBound INT,
@YBound INT,
@Width INT,
@Height INT,
@Scope VARCHAR(100) OUTPUT
)
AS
BEGIN
SET NOCOUNT ON
	DECLARE @OutPut VARCHAR(50) = ''
	BEGIN
IF NOT EXISTS (SELECT * FROM [TCD].Monitor Where MonitorId=@MonitorId)
Begin
		

	INSERT INTO [TCD].Monitor(
						  MonitorId,
						  EcolabAccountNumber,
						  MonitorName,
						  XBound,
							  YBound,
							  Width,
							  Height
							  ) VALUES(@MonitorId,@EcolabAccountNumber,@MonitorName,@XBound,@YBound,@Width,@Height)
		END
ELSE
	BEGIN
		UPDATE [TCD].Monitor
		SET 
		
				MonitorId	=	@MonitorId,
				MonitorName	=	@MonitorName,
				XBound		=	@XBound,
				YBound		=	@YBound,
				Width		=	@Width,
				Height		=	@Height
		WHERE	MonitorId	=	@MonitorId
	END
	SET @OutPut = '201'     

	SET @Scope = @OutPut SELECT @Scope  
	End
	
SET NOCOUNT OFF
END