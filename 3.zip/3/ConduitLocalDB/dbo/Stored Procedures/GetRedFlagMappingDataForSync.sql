﻿CREATE PROCEDURE [TCD].[GetRedFlagMappingDataForSync]
(
		@MappingId INT = NULL
	,	@EcolabAccountNumber nvarchar(25) 
)
AS
BEGIN
SET NOCOUNT ON;
	SELECT 
		Id, 
		MappingId, 
		MachineId, 
		Is_Deleted 
	FROM 
		TCD.RedFlagMappingData
	WHERE 
		EcolabAccountNumber = @EcolabAccountNumber AND MappingId = @MappingId
SET NOCOUNT OFF;
END
