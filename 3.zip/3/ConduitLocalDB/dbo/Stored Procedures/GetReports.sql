CREATE  PROCEDURE [TCD].[GetReports] 
(			
	@RoleId Varchar(20) = NULL,
	@LanguageId INT  = 1
)
AS   
    SET NOCOUNT ON
    BEGIN   

	Select @RoleId= Max(RoleId) from tcd.UserRoles where LevelId=@RoleId

		SELECT rc.ReportCategoryId,
		   COALESCE((SELECT
					  RKV.[Value]
					  FROM TCD.ResourceKeyMaster AS RKM
					  JOIN TCD.ResourceKeyValue AS RKV ON RKV.KeyName = RKM.KeyName
					  WHERE RKM.[KeyName] = RC.UsageKey
					  AND RKV.LanguageID = @Languageid), 
					 (SELECT TOP (1)
					  RCAT.ReportCategoryName
					  FROM TCD.ReportCategory AS RCAT
					WHERE RCAT.ReportCategoryId = RC.ReportCategoryId))AS ReportCategoryName, 
		   rsc.SubCategoryId,
		   COALESCE((SELECT
					  RKV.[Value]
					  FROM TCD.ResourceKeyMaster AS RKM
					  JOIN TCD.ResourceKeyValue AS RKV ON RKV.KeyName = RKM.KeyName
					  WHERE RKM.KeyName = RSC.UsageKey
					  AND RKV.LanguageID = @Languageid), RSC.SubCategoryName)AS SubCategoryName, 
		   rp.ReportId,
		   COALESCE((SELECT
					  RKV.[Value]
					  FROM TCD.ResourceKeyMaster AS RKM
					  JOIN TCD.ResourceKeyValue AS RKV ON RKV.KeyName = RKM.KeyName
					  WHERE RKM.KeyName = Rp.UsageKey
					  AND RKV.LanguageID = @LanguageId), Rp.ReportName)AS ReportName,	 
		   rp.DisplayTopRecordsCount,
		   rp.ShowOthers,
		   rp.ShowTotal,
		   rp.ChartType,
		   rp.IsPaging,
		   rp.PageSize
		   FROM [TCD].Report rp
				INNER JOIN [TCD].ReportSubCategory rsc ON rsc.SubCategoryId = rp.ReportSubCategoryId		
				INNER JOIN  [TCD].ReportCategory rc ON rc.ReportCategoryId=rsc.CategoryId	
				INNER JOIN [TCD].[ReportRoleMapping]  rm on rm.ReportId = rp.Reportid 
		  WHERE rm.[RoleId] = @RoleId 
		  ORDER BY rc.ReportCategoryId ASC
    END
