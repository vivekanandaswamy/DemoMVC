/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[GetMaxInjectionCount]              
Parameters:				@EcolabAccountNumber - holds the ecolab account number.
																																		
###################################################################################################                                           
*/

CREATE PROCEDURE [TCD].[GetMaxInjectionCount]
            (
            @EcolabAccountNumber nvarchar(25) = NULL,
			@ControllerId Int = NULL
            )
AS
SET NOCOUNT ON
BEGIN

	SELECT			csd.[Value] 
	FROM			TCD.ControllerSetupData csd
	 
    INNER JOIN		TCD.ConduitController cc (NOLOCK) ON cc.ControllerId = csd.ControllerId AND cc.EcoalabAccountNumber = csd.EcolabAccountNumber
    INNER JOIN		TCD.FieldGroup fg ON fg.ControllerModelId = cc.ControllerModelId AND fg.ControllerTypeId = cc.ControllerTypeId
                                            INNER JOIN TCD.FieldGroupFieldMapping fgfm  ON fgfm.FieldGroupId = fg.Id
    INNER JOIN		TCD.Field f ON f.Id = fgfm.FieldId AND f.ResourceKey    = 'Max_Formula_Injections' AND csd.FieldId = f.Id
    WHERE			cc.ControllerId  = @ControllerId
	AND				cc.EcoalabAccountNumber	=	@EcolabAccountNumber

 END
