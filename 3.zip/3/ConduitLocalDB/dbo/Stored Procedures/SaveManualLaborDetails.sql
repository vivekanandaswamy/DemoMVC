﻿/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_SaveManualLaborDetails]                                         

Purpose:				To Save The manual labor details.

Parameters:				@LocationId - holds the location Id.
						@ManHourTypeId - holds the man hours type id.
						@StartDate - holds the Start date.
						@EndDate	- holds the End date.
						@LaborCost - holds the labor cost.
						@AllocatedManHours - holds the Allocated man hours.
						@EcolabAccountNumber - holds the ecolab account number.
						@LastModifiedByUserId	- holds the last modified by user id.
																												
###################################################################################################                                           
*/
CREATE PROCEDURE [TCD].[SaveManualLaborDetails] (

				@LocationId int = NULL,
				@ManHourTypeId Int = NULL,
				@StartDate	datetime = NULL,
				@EndDate datetime = NULL,
				@LaborCost decimal(18,4) = NULL,
				@AllocatedManHours Int = NULL,
				@EcolabAccountNumber nvarchar(25),
				@LastModifiedByUserId INT,
				@OutputManualLaborId	INT					=			NULL	OUTPUT
			) 
AS 
SET NOCOUNT ON
  BEGIN
      --DECLARE @FromDate date = CAST(@StartDate AS date),
		    --@Todate date = CAST(@enddate AS date)


DECLARE
		@OutputList					AS	TABLE		(
		LaborId							INT
	)
    INSERT INTO [TCD].ManualLabor(
						LocationId
						,ManHourTypeId
						,StartDate
						,EndDate
						,LaborCost
						,AllocatedManHours
						,EcolabAccountNumber
						,LastModifiedByUserId
						,IsDeleted
				)
				OUTPUT
									inserted.Id						AS			LaborId
				INTO @OutputList
					(LaborId)
				VALUES(
						@LocationId
						,@ManHourTypeId
						,@StartDate
						,@EndDate
						,@LaborCost
						,@AllocatedManHours
						,@EcolabAccountNumber
						,@LastModifiedByUserId
						,0
						)

    EXEC [TCD].[SaveProductionShiftManualLabourRollup]
											 @FromDate  = @StartDate,
												@Todate  =  @EndDate,
												@LabourType  =  @ManHourTypeId,
												@ManualHours  =  @AllocatedManHours

	SELECT	TOP 1	
				@OutputManualLaborId					=	O.LaborId
		FROM	@OutputList
		
											O
  SET NOCOUNT OFF
   END