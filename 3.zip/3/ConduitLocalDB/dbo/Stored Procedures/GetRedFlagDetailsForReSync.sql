﻿CREATE PROCEDURE [TCD].[GetRedFlagDetailsForReSync]
(
		@Id INT = NULL
	,	@EcolabAccountNumber NVARCHAR(25) 
)
AS
BEGIN
SET NOCOUNT ON;
	SELECT 
			rf.Id, 
			rf.MaximumRange, 
			rf.Location, 
			rf.Item, 
			rf.MinimumRange, 
			rf.Is_Deleted, 
			rf.LastModifiedTime, 
			rf.EcolabAccountNumber ,
			rf.RedFlagCategoryId AS CategoryId  ,
			rf.FormulaId AS FormulaId ,
			rf.ProductId ,  
			rf.MeterId ,
			rf.SensorId   
	FROM TCD.RedFlag rf
	WHERE rf.EcolabAccountNumber = @EcolabAccountNumber AND rf.Id = ISNULL(@Id, rf.Id)
SET NOCOUNT OFF;
END

