﻿/*      
 ==========================================================================================    
 Purpose:  Deleteing the chemicals .      
  
 Author:   Premchand Yelavarthi      
 --------------------------------------------------------------      
 July-18-2014 ENT: Initial version.      
 ==========================================================================================    
*/   

CREATE PROCEDURE [TCD].[DeletePlantChemicals] 
(
		@Id INT
	,	@EcolabAccountNumber nvarchar(25)
	,	@UserID INT = NULL
	,	@OutputChemicalId						INT				=	NULL	OUTPUT
	,	@LastModifiedTimestampAtCentral			DATETIME		=	NULL
	,	@OutputLastModifiedTimestampAtLocal		DATETIME		=	NULL	OUTPUT
)   
AS   
  BEGIN   

	SET NOCOUNT ON; 

	SET	@OutputChemicalId			=			ISNULL(@OutputChemicalId, NULL)				--SQLEnlight SA0121

	DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()

	DECLARE
		@OutputList						AS	TABLE		(
		PlantChemicalId					INT
	,	LastModifiedTimestamp			DATETIME		)

	SET	@OutputLastModifiedTimestampAtLocal			=			ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight SA0121

--    DECLARE @Table_name NVARCHAR(1000) = 'productdatamapping' 

	--If the call is not local, check that the LastModifiedTime matches with the central

	IF	(
		@LastModifiedTimestampAtCentral				IS NOT	NULL
		AND
		NOT	EXISTS	(	SELECT	1
				FROM	TCD.ProductDataMapping		PDM
				WHERE	PDM.EcolabAccountNumber	=	@EcolabAccountNumber
					AND	PDM.ProductID					=	@Id
					AND	PDM.LastModifiedTime		=	@LastModifiedTimestampAtCentral
			)
	)
	BEGIN
			SET			@ErrorId				=	60000
			SET			@ErrorMessage			=	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
			RAISERROR	(@ErrorMessage, 16, 1)
			SET			@ReturnValue			=	-1
			RETURN		(@ReturnValue)
	END

     UPDATE [TCD].ProductdataMapping 
	 SET 
		Is_Deleted = 1
	 ,	LastModifiedByUserId	=	@UserId
	 ,  LastModifiedTime		=	@CurrentUTCTime
	 OUTPUT
		inserted.ID					AS			Id
	,	inserted.LastModifiedTime	AS			LastModifiedTimestamp
	INTO
		@OutputList	(
		PlantChemicalId
	,	LastModifiedTimestamp
	)
	  WHERE 
	  ProductID = @Id 
	  AND 
	  EcolabAccountNumber = @EcolabAccountNumber

	  SELECT	TOP 1	
		@OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp
	,	@OutputChemicalId					=	O.PlantChemicalId
	  FROM	@OutputList							O

	RETURN	(@ReturnValue)
	 
	--SET NOCOUNT OFF;																--SQLEnlight SA0144
  END