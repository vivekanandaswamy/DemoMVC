CREATE PROCEDURE [TCD].[GetWasherTimeLine](@DashboardId INT, @EcolabAccountNumber Nvarchar(25) = NULL)
AS
SET NOCOUNT ON
BEGIN

Declare @CurDate TIME = CAST(GETDATE() AS TIME)
		,@HoursToDisplay INT = NULL
		,@hrsBeforeCurTime INT = NULL
		,@hrsAfterCurTime INT = NULL
		,@TimeLineStartTime Time = NULL
		,@TimeLineEndTime Time = NULL
,@DayId Int = NULL
,@StartTime Time = NULL
		,@ShiftId Int = NULL
		,@TimeLineStartDateTime DateTime = NULL
		,@CurrentDatePart DateTime = NULL
		,@LocalStartDateTime DateTime = NULL
		,@LocalEndDateTime DateTime = NULL
		,@FormatStartDateTime DateTime = NULL

SELECT	@HoursToDisplay = ISNULL(TimelineHours,6) from TCD.[Dashboard] where DashboardId = @DashboardId
Select	@hrsBeforeCurTime = (17 * @HoursToDisplay)/20 
Select	@hrsAfterCurTime = @HoursToDisplay - @hrsBeforeCurTime

SELECT	@TimeLineStartTime = DATEADD(HOUR,- @hrsBeforeCurTime, @CurDate)
SELECT	@TimeLineEndTime = DATEADD(HOUR, ( @HoursToDisplay - @hrsBeforeCurTime), @CurDate)

SELECT	@TimeLineStartTime = 
		Case WHEN DATEPART(MINUTE,@TimeLineStartTime) > 0
				THEN  DATEADD(MINUTE,-DATEPART(MINUTE,@TimeLineStartTime), @TimeLineStartTime)
				ELSE  @TimeLineStartTime
		END

SELECT	@TimeLineEndTime = 
		Case WHEN DATEPART(MINUTE,@TimeLineEndTime) > 0
				THEN  DATEADD(MINUTE,-DATEPART(MINUTE,@TimeLineEndTime), @TimeLineEndTime)
				ELSE  @TimeLineEndTime
		END

SELECT	@TimeLineStartTime = 
		Case WHEN DATEPART(SECOND,@TimeLineStartTime) > 0
				THEN  DATEADD(SECOND,-DATEPART(SECOND,@TimeLineStartTime), @TimeLineStartTime)
				ELSE  @TimeLineStartTime
		END

SELECT	@TimeLineEndTime = 
		Case WHEN DATEPART(SECOND,@TimeLineEndTime) > 0
				THEN  DATEADD(SECOND,-DATEPART(SECOND,@TimeLineEndTime), @TimeLineEndTime)
				ELSE  @TimeLineEndTime
		END

DECLARE @TimeLine TABLE
(
TimeLineType NVARCHAR(100),
StartTime INT,
EndTime INT
)


INSERT INTO @TimeLine (TimeLineType, StartTime, EndTime)
SELECT 'TimeLine',DATEPART(hh,@TimeLineStartTime),DATEPART(hh,@TimeLineEndTime)

-----Break related queries

SELECT @DayId = DayId 
	   FROM [TCD].[WeekDay] WITH (NOLOCK)
	   WHERE DayName = DATENAME(dw,GETDATE())

SELECT @CurrentDatePart = DATEADD(dd, 0, DATEDIFF(dd, 0, GetDate()))
SELECT @TimeLineStartDateTime =	@CurrentDatePart + CONVERT(DATETIME, @TimeLineStartTime, 114)


SELECT DISTINCT @StartTime = StartTime ,@ShiftId = ShiftId
	    FROM [TCD].ShiftData WITH (NOLOCK)
	    WHERE DayId = @DayId 
		  		AND GETDATE() BETWEEN 
						@CurrentDatePart + CONVERT(DATETIME, StartTime, 114)
					AND CASE WHEN @CurrentDatePart + CONVERT(DATETIME, EndTime, 114) < @CurrentDatePart + CONVERT(DATETIME, StartTime, 114)
						THEN DATEADD(dd, 1, @CurrentDatePart) + CONVERT(DATETIME, EndTime, 114)
						ELSE @CurrentDatePart + CONVERT(DATETIME, EndTime, 114) 
					END
				AND Is_Deleted = 0

INSERT INTO @TimeLine (TimeLineType, StartTime, EndTime)
SELECT 'BreakTime',
		CASE WHEN DATEDIFF(SECOND,@TimeLineStartDateTime,@CurrentDatePart + CONVERT(DATETIME, SBD.StartTime, 114)) < 0 THEN 0
						ELSE DATEDIFF(SECOND,@TimeLineStartDateTime,@CurrentDatePart + CONVERT(DATETIME, SBD.StartTime, 114))
				END,
		DATEDIFF(SECOND,@TimeLineStartDateTime,

					CASE WHEN @CurrentDatePart + CONVERT(DATETIME, EndTime, 114) < @CurrentDatePart + CONVERT(DATETIME, StartTime, 114)
						THEN DATEADD(dd, 1, @CurrentDatePart) + CONVERT(DATETIME, EndTime, 114)
						ELSE @CurrentDatePart + CONVERT(DATETIME, EndTime, 114) 
					END
				)
FROM	TCD.ShiftBreakData SBD
	WHERE SBD.ShiftId =	@ShiftId AND DayId = @DayId
	AND (StartTime != '00:00:00.0000000' AND EndTime != '23:59:59.0000000')
	AND SBD.Is_Deleted = 0


SELECT	@LocalStartDateTime = CONVERT(datetime, 
											   SWITCHOFFSET(CONVERT(datetimeoffset, 
																	PSD.StartDateTime), 
															DATENAME(TzOffset, SYSDATETIMEOFFSET()))
									),

		 @LocalEndDateTime = CONVERT(datetime, 
											   SWITCHOFFSET(CONVERT(datetimeoffset, 
																	PSD.EndDateTime), 
															DATENAME(TzOffset, SYSDATETIMEOFFSET()))
									)
FROM TCD.ProductionShiftData PSD
WHERE GETUTCDATE() BETWEEN StartDateTime 
					AND EndDateTime 

Select @FormatStartDateTime = Case WHEN @TimeLineStartDateTime > GETDATE() THEN DATEADD(dd,-1,@TimeLineStartDateTime)
									ELSE @TimeLineStartDateTime
							   END

INSERT INTO @TimeLine (TimeLineType, StartTime, EndTime)

SELECT 'ShiftTime',
		
		DATEDIFF(SECOND,@FormatStartDateTime,@LocalStartDateTime),
		DATEDIFF(SECOND,@FormatStartDateTime,@LocalEndDateTime)

SELECT Distinct TimeLineType, StartTime, EndTime FROM @TimeLine

END