﻿/*	
Purpose					:	To populate the drop-down (Water Flow) in the Tunnel setup --> Compartments tab

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version

usp_GetTunnelCompartmentWaterFlow	2


sp_helptext	usp_GetTunnelCompartmentWaterFlow

*/

CREATE	PROCEDURE	[TCD].[GetTunnelCompartmentWaterFlow]
					@RegionId					INT
AS
BEGIN

SET	NOCOUNT	ON


SELECT	T.TunnelWaterFlowTypeName	AS			Name
	,	CAST(T.TunnelWaterFlowTypeId AS INT)
									AS			Id
FROM	[TCD].TunnelWaterFlowType			T
WHERE	T.RegionId					=			@RegionId
	AND	T.Is_Deleted				=			'FALSE'


SET	NOCOUNT	OFF

END
