CREATE PROCEDURE [TCD].[GetWasherDosingAnalogControl]   
     
    @WasherProgramSetupId       INT      
   ,@StepNumber				INT
   ,@EcoLabAccountNumber     NVARCHAR(1000)      
AS    
BEGIN   
DECLARE  @WasherDosingSetupId INT;
SET @WasherDosingSetupId = (SELECT WasherDosingSetupId FROM [TCD].WasherDosingSetup 
WHERE  WasherProgramSetupId= @WasherProgramSetupId AND StepNumber=@StepNumber)
SELECT     
cast(ACM.WasherDosingAnalogControllerMappingId AS INT) ,    
cast(ACM.WasherDosingSetupId AS INT),    
CAST(ACM.SetPointTemperature AS INT),    
CAST(ACM.MinimumTime AS INT),    
CAST(ACM.StartDelay AS INT),    
CAST(ACM.AcceptedDelay AS INT),    
CAST(ACM.ProductId AS INT),    
ACM.PhControlDuringDrain,    
CAST(ACM.PhDelayTime AS INT),    
CAST(ACM.PhMeasuringTime AS INT),    
ACM.PhMininum,    
ACM.PhMaximum,    
CAST(WDS.StepNumber AS INT)    
 FROM [TCD].WasherDosingAnalogControllerMapping AS ACM    
 JOIN [TCD].WasherDosingSetup AS WDS ON WDS.WasherDosingSetupId = ACM.WasherDosingSetupId    
 WHERE ACM.EcoLabAccountNumber = @EcoLabAccountNumber    
 AND ACM.WasherDosingSetupId = @WasherDosingSetupId    
 END    
     
    
     
  