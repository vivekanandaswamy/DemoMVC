CREATE PROCEDURE [TCD].[GetWasherBatchTrendingGroupData](@GroupId int = NULL ,
											  @machineId int = NULL,
											  @EcolabAccountNumber Nvarchar(25) = NULL,
											  @StartDateTime DateTime = NULL,
											  @EnddateTime DateTime = NULL) 
AS 
SET NOCOUNT ON
BEGIN 
DECLARE	@DayId Varchar(20) = NULL,
		@ShiftStartTime Time = NULL,
		@ShiftEndTime Time = NULL,
		@CurrentTime INT = NULL,
		@EndTimeInMIn INT = NULL,
		@StartTime Time = Null,
		@EndTime Time = Null

	SET @StartTime = CAST(@StartDateTime AS TIME)
	SET @EndTime = CAST(@EnddateTime AS TIME)
    SET @CurrentTime = DATEDIFF(MINUTE,@StartTime,CAST(GETDATE() AS TIME))
    SET @EndTimeInMIn = DATEDIFF(MINUTE,@StartTime,@EndTime)

SELECT @DayId = DayId FROM [TCD].WeekDay WHERE DayName = DATENAME(dw,GETDATE())

SELECT DISTINCT @ShiftStartTime = StartTime FROM [TCD].ShiftData
	    WHERE		DayId = @DayId 
				AND CONVERT(TIME, CONVERT(VARCHAR(20), GETDATE(), 120)) BETWEEN StartTime AND EndTime 
				AND Is_Deleted = 0

SELECT DISTINCT @ShiftEndTime = EndTime FROM [TCD].ShiftData
		WHERE		DayId = @DayId 
				AND CONVERT(TIME, CONVERT(VARCHAR(20), GETDATE(), 120)) BETWEEN StartTime AND EndTime 
				AND Is_Deleted = 0;

 DECLARE @TrendingData TABLE(
						  RowNumber INT,
						  GroupId INT,
						  MachineId int,
						  BatchId INT,
    						  ProgramId INT,
						  ProgramName Nvarchar(100),
    						  StartDate Int,
						  BatchStandardEndDate Int,
						  EndDate Int,
		  				  TurnTime INT,
						  StartTime Time,
						  EndTime Time) 		

 INSERT INTO @TrendingData(
					   RowNumber,
					   GroupId,
					   MachineId,
					   BatchId,
					   ProgramId,
					   ProgramName,
					   StartDate,
					   BatchStandardEndDate,
					   EndDate,
					   TurnTime,
					   StartTime,
					   EndTime
					  )
 SELECT DISTINCT ROW_NUMBER() OVER(PARTITION BY BA.GroupId,BA.MachineId ORDER BY BA.GroupId,BA.MachineId),
				BA.GroupId,
				BA.MachineId,
				BA.BatchId,
				BA.ProgramNumber,
    			     PM.Name,
				DATEDIFF(MINUTE,@StartTime,CAST(BA.StartDate AS TIME)),
				DATEDIFF(MINUTE,@StartTime,
				(SELECT DATEADD(MINUTE,((SELECT TotalRunTime FROM [TCD].WasherProgramSetup WPS WHERE WPS.ProgramNumber = BA.ProgramNumber AND WPS.WasherGroupId = BA.GroupId)/60),CAST(BA.StartDate AS TIME)))), 
				DATEDIFF(MINUTE,@StartTime,CAST(BA.EndDate AS TIME)),
			 	(SELECT ((SELECT ExtraTime FROM TCD.WasherProgramSetup WPS WHERE WPS.ProgramNumber = BA.ProgramNumber AND WPS.WasherGroupId = BA.GroupId)/60)),
				CAST(BA.StartDate AS TIME),
				CAST(BA.EndDate AS TIME)

		FROM					[TCD].BatchData BA  
				LEFT OUTER JOIN	[TCD].MachineSetup MS ON MS.GroupId = BA.GroupId AND MS.WasherId = BA.MachineId
				LEFT OUTER JOIN	[TCD].ProgramMaster PM ON PM.ProgramId = BA.ProgramNumber

		WHERE		((CAST(BA.StartDate AS TIME) >= @StartTime  
				OR	BA.EndDate IS NULL OR (CAST(BA.EndDate AS TIME) >= @StartTime) 
				OR	(@StartTime <= DATEADD(MINUTE,((SELECT ExtraTime FROM [TCD].WasherProgramSetup WPS WHERE WPS.ProgramNumber = BA.ProgramNumber AND WPS.WasherGroupId = BA.GroupId)/60),CAST(BA.EndDate AS TIME)))))
				AND CAST(BA.StartDate AS DATE) = CAST(GETDATE() AS DATE)
				AND BA.GroupId = @GroupId 
				AND BA.MachineId = @machineId

	SELECT	CUR.GroupId ,
			CUR.MachineId ,
			CUR.BatchId,
			CUR.ProgramId,
			CUR.ProgramName,
			CUR.StartDate,
			CASE 
				WHEN CUR.BatchStandardEndDate > @EndTimeInMIn THEN @EndTimeInMIn
				WHEN  CUR.BatchStandardEndDate <= 0 THEN 1 ELSE CUR.BatchStandardEndDate 
			END,
			CUR.EndDate,
			--CUR.TurnTime,
			CASE 
				WHEN (CUR.BatchStandardEndDate + CUR.TurnTime < @EndTimeInMIn) 
					THEN CUR.TurnTime
				WHEN ((SELECT CUR.BatchStandardEndDate + CUR.TurnTime FROM @TrendingData TD WHERE TD.EndDate IS NULL) > @EndTimeInMIn) 
					THEN ( CASE WHEN (@EndTimeInMIn - CUR.BatchStandardEndDate) < 0 THEN 0 
				WHEN (@EndTimeInMIn - CUR.BatchStandardEndDate) > 0 THEN @EndTimeInMIn - CUR.BatchStandardEndDate  ELSE CUR.TurnTime END)ELSE CUR.TurnTime 
			END,
			ActualTurnTime = CASE WHEN (CUR.StartDate < 0 AND CUR.EndDate < 0) THEN 
			DATEDIFF(MINUTE,@StartTime,nexting.StartTime) ELSE nexting.StartDate - CUR.EndDate END,
			--ActualTurnTime =  nexting.StartDate - CUR.EndDate ,
			CASE WHEN CUR.EndDate IS NULL THEN 1 ELSE 0 END,

			ISNULL(convert(DECIMAL(5,1),100 * CUR.EndDate/CASE WHEN CUR.BatchStandardEndDate <= 0 THEN 1 ELSE CUR.BatchStandardEndDate END),

			convert(DECIMAL(5,1),100 * (@CurrentTime -  CASE WHEN CUR.StartDate < 0 THEN 0 ELSE CUR.StartDate END )/(CASE WHEN CUR.BatchStandardEndDate <= 0 THEN 1 ELSE CUR.BatchStandardEndDate END - CASE WHEN CUR.StartDate < 0 THEN 0 ELSE CUR.StartDate END)))

			--CUR.StepNumber

	FROM	 	@TrendingData CUR
		LEFT OUTER JOIN @TrendingData nexting ON cur.RowNumber = nexting.RowNumber - 1

		ORDER BY CUR.StartDate
END
