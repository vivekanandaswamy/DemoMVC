﻿CREATE PROCEDURE [TCD].[GetPumpsTunnelCompartmentEquipmentValveMappingResync]
				(
				@EcolabAccountNumber			NVARCHAR(25)	=	NULL
			,	@ControllerEquipmentSetupId		INT				=	NULL
			)
AS     
SET NOCOUNT ON
	DECLARE @PlantId	INT		=	NULL
	SELECT @PlantId = p.PlantId FROM TCD.Plant p WHERE p.EcolabAccountNumber = @EcolabAccountNumber
	    
BEGIN     
	SELECT [TunnelCompartmentEquipmentValveMappingID]
      ,[PlantID]
      ,[ControllerEquipmentSetupID]
      ,[TunnelNumber]
      ,[DosingPointNumber]
      ,[ValveNumber]
      ,[CompartmentNumber]
      ,[DirectDosingFlag]
      ,[LastModifiedDate]
   FROM [TCD].[TunnelCompartmentEquipmentValveMapping]
   WHERE PlantID = @PlantId
   AND	ControllerEquipmentSetupID = ISNULL(@ControllerEquipmentSetupID, ControllerEquipmentSetupID)
END