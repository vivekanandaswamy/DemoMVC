CREATE PROCEDURE [TCD].[GetReportFiltersByFilterId] 

(
			@FilterId INT,			
			@EcolabAccountNumber nvarchar(25),
			@LanguageId Int = 1
 )
AS
BEGIN
SET	NOCOUNT	ON
			  --Machinegroup
			  IF(@FilterId = 5)
			  BEGIN
						 SELECT CAST(WG.WasherGroupId AS int),
								WG.WasherGroupName
						 FROM TCD.MachineGroup GT 
								INNER JOIN TCD.WasherGroup WG ON GT.Id = WG.WasherGroupId
						 WHERE 
						 --GT.GroupDescription LIKE '%' + @SearchParameter + '%' AND 
						 GT.EcolabAccountNumber = @EcolabAccountNumber
			  END

			  -- Machine
			  ELSE IF(@FilterId = 6)
			  BEGIN
				   SELECT MS.WasherId,
							   MS.MachineName  
						FROM TCD.MachineSetup MS  
								INNER JOIN TCD.Washer WS ON MS.WasherId = WS.WasherId
						WHERE MS.IsDeleted = 0
							 -- AND MS.MachineName LIKE '%' + @SearchParameter + '%'  
			  END

			  --Category
			  ELSE IF(@FilterId = 7)
			  BEGIN
						SELECT CAST(TextileId AS int),
							   CategoryName  
						FROM TCD.EcolabTextileCategory
						--WHERE CategoryName LIKE '%' + @SearchParameter + '%'
			  END 

			  --MachineTypes
			  ELSE IF(@FilterId = 8)
			  BEGIN
						SELECT CAST(WasherGroupTypeId AS int),
							   WasherGroupTypeName 
						FROM TCD.WasherGroupType
					--	WHERE WasherGroupTypeName LIKE '%' + @SearchParameter + '%'			      
			  END 
			  --Customer
			  ELSE IF(@FilterId = 9)
			  BEGIN
						SELECT CAST(CustomerId AS int),
							   CustomerName 
						FROM TCD.PlantCustomer
						--WHERE 
						--CustomerName LIKE '%' + @SearchParameter + '%' AND
						 --Is_Deleted <> 0	
			  END 

			  --Formula
			  ELSE IF(@FilterId = 10)
			  BEGIN
						SELECT CAST(ProgramId AS int),
							   Name
							FROM TCD.ProgramMaster
						--WHERE 
						--Name LIKE '%' + @SearchParameter + '%' AND 
						--Is_Deleted <> 0 AND
						  -- EcolabAccountNumber = @EcolabAccountNumber
			  END 
			  --Controller/Dispencer
			  ELSE IF(@FilterId = 11)
			  BEGIN
						SELECT CAST(ControllerId AS int),
							   Name
						FROM TCD.conduitController
						WHERE
						 --Name LIKE '%' + @SearchParameter + '%' AND 
						 --IsDeleted <> 0 AND
						   EcoalabAccountNumber = @EcolabAccountNumber
			  END

			  --Alarm 
			  ELSE IF(@FilterId = 12)
			  BEGIN
					SELECT DISTINCT CAST(AGMVCMT.AlarmGroupMasterId AS int),
							   AGM.[Description]
				FROM TCD.AlarmGroupMaster AGM
				JOIN TCD.AlarmGroupMsterVsControllerModelType AGMVCMT ON  AGMVCMT.AlarmGroupMasterId = AGM.AlarmGroupMasterId				
				--WHERE 
				--	[Description] LIKE '%' + @SearchParameter + '%' AND 
				--Active <> 0				  
				  END 
			  --DryerGroup
			  ELSE IF(@FilterId = 13)
			  BEGIN
						SELECT CAST(GT.Id AS int),
							   GT.GroupDescription
						FROM TCD.MachineGroup GT 
							INNER JOIN	TCD.DRYERS DR ON GT.Id = DR.DryerGroupId
						WHERE 
						--[Description] LIKE '%' + @SearchParameter + '%' AND 
						--DR.Is_deleted <> 0 AND
							   DR.EcolabAccountNumber = @EcolabAccountNumber
						  AND GT.GroupDescription = 'DryerGroup'
		  END 
			  --Dryer
			  ELSE IF(@FilterId = 14)
			  BEGIN
						SELECT CAST(DR.DryerNo AS int),
							   DR.[Description]
						FROM TCD.Dryers DR
						WHERE
						 --[Description] LIKE '%' + @SearchParameter + '%' AND 
						 --DR.Is_deleted <> 0 AND
						   DR.EcolabAccountNumber = @EcolabAccountNumber				 
			  END
		  --Finisher
			  ELSE IF(@FilterId = 15)
			  BEGIN
						SELECT CAST(FR.FinnisherNo AS int),
							   FR.Name
							FROM TCD.MachineGroup GT 
						INNER JOIN TCD.Finnishers FR ON GT.Id = FR.FinnisherGroupId
						WHERe
						-- FR.Name LIKE '%' + @SearchParameter + '%' AND 
						--FR.Is_deleted <> 0 AND
						   FR.EcolabAccountNumber = @EcolabAccountNumber
			  END 
			  --FinisherGroup
			  ELSE IF(@FilterId = 16)
			  BEGIN
						SELECT CAST(GT.Id AS int),
							   GT.GroupDescription
						FROM TCD.MachineGroup GT 
							INNER JOIN TCD.Finnishers FR ON GT.Id = FR.FinnisherGroupId
						WHERE 
						--GT.GroupDescription LIKE '%' + @SearchParameter + '%' AND 
						--GT.Is_deleted <> 0 AND
							 GT.EcolabAccountNumber = @EcolabAccountNumber
							AND GT.GroupDescription = 'FinnisherGroup'
			  END 
			  --Water and Energy recoveringUnit
			  --ELSE IF(@FilterId = 17)
			  --BEGIN
			  --END
			  --Meter 
			  ELSE IF(@FilterId = 18)
			  BEGIN
						SELECT CAST(MeterId AS int),
							   [Description]	
						FROM TCD.METER
						WHERE 
						--[Description] LIKE '%' + @SearchParameter + '%' AND 
						EcolabAccountNumber = @EcolabAccountNumber
							  --AND Is_deleted <> 0	
			  END 
			  ELSE IF(@FilterId = 21)
			  BEGIN
			   SELECT 
					   UM.UserId,
					   UM.LoginName
						FROM TCD.UserMaster UM
			  END

			  ELSE IF(@FilterId = 22)
			  BEGIN
				SELECT 
					   CAST(AO.OperationId AS int) AS OperationId,
					   CASE	AO.OperationCode 
							WHEN	'SQLInsert'
							THEN	RKV.Value
							WHEN	'SQLUpdate'
							THEN	RKV.Value
							WHEN	'AppDelete'
							THEN	RKV.Value
							WHEN	'UserLogon'
							THEN	RKV.Value
							WHEN	'UserLogoff'
							THEN	RKV.Value
							WHEN 'ReportGenerated'
							THEN	RKV.Value
							WHEN 'Manual Entry' 
							THEN RKV.Value END AS OperationCode
						FROM TCD.AuditOperation AO INNER JOIN TCD.ResourceKeyMaster RKM ON AO.UsageKey = RKM.[KeyName]
											  INNER JOIN TCD.ResourceKeyValue RKV ON RKM.[KeyName] = RKV.[KeyName]
						WHERE RKV.languageID = @languageId
						ORDER BY OperationId
			  END
  END
