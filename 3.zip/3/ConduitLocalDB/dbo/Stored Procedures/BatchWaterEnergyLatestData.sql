CREATE PROCEDURE [TCD].[BatchWaterEnergyLatestData] (
											 @Corporate Varchar(max) = '',
											 @Country Varchar(max) = '',
											 @Region Varchar(max) = '',
											 @EcolabAccountNumber Nvarchar(25) = '',
											 @Machine Varchar(max) = '', 
											 @machineGroup Varchar(max) = '',
											 @Formula Varchar(max) = '',
											 @MachineType Varchar(20)= '',
											 @Category Varchar(max) = '',
											 @FromDate Date = '',
											 @ToDate Date = '',
											 @GroupId Varchar(max) = '',
											 @MachineInternalId Varchar(max) = '',
											 @Date AS date

										  )
AS
SET NOCOUNT ON
BEGIN

SET		@FromDate			=			ISNULL(@FromDate, NULL)			--SQLEnlight SA0029
SET		@ToDate				=			ISNULL(@ToDate, NULL)			--SQLEnlight SA0029
SEt		@EcolabAccountNumber	=		ISNULL(@EcolabAccountNumber, NULL)	--SQLEnlight SA0029

DECLARE @CategoryTable TABLE(Category Varchar(100))
INSERT INTO @CategoryTable(Category) EXEC [TCD].[CharlistToTable] @Category,','

DECLARE @MachineTable TABLE(Machine Varchar(100))
INSERT INTO @MachineTable(Machine) EXEC [TCD].[CharlistToTable] @Machine,','

DECLARE @GroupMachineTable TABLE(GroupId INT,MachineInternalId INT)  
INSERT INTO @GroupMachineTable(GroupId,MachineInternalId) 
SELECT GroupId,MachineInternalId FROM TCD.MachineSetup MS 
									INNER JOIN TCD.Washer WS ON MS.WasherId = WS.WasherId WHERE WS.PlantWasherNumber IN (SELECT Machine FROM @MachineTable);

DECLARE @GroupTable TABLE(GroupId Varchar(100))
INSERT INTO @GroupTable(GroupId) EXEC [TCD].[CharlistToTable] @GroupId,','

DECLARE @MachineInternalTable TABLE(MachineInternalId Varchar(100))
INSERT INTO @MachineInternalTable(MachineInternalId) EXEC [TCD].[CharlistToTable] @MachineInternalId,','

DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))
INSERT INTO @WasherGroupTable(MachineGroup) EXEC [TCD].[CharlistToTable] @machineGroup,','

DECLARE @FormulaTable TABLE(Formula Varchar(100))
INSERT INTO @FormulaTable(Formula) EXEC [TCD].[CharlistToTable] @Formula,','

--DECLARE @CustomerTable TABLE(Customer Varchar(100))
--INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','

DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))
INSERT INTO @MachineTypeTable(MachineType) EXEC [TCD].[CharlistToTable] @MachineType,','

CREATE TABLE WaterEnergyLatestRollUpData
							 (
								 [RecordDate] [date] NULL,
								 [GroupId] [int] NULL,
								 [MachineInternalId] [int] NULL,
								 [ProgramNumber] [int] NULL,
								 [ProductId] [int] NULL,
								 [NoOfBatches] [int] NULL,
								 [TotalConsumption] [decimal](18, 2) NULL,
								 [TargetConsumption] [decimal](18, 2) NULL,
								 [AverageConsumption] [decimal](18, 2) NULL,
								 [ActualConsumptionPerLoad] [decimal](18, 2) NULL,
								 [TargetConsumptionPerLoad] [decimal](18, 2) NULL,
								 [Cost] [decimal](18, 2) NULL,
								 [CostPerLoad] [decimal](18, 2) NULL,
								 [CostExcess] [decimal](18, 2) NULL,
								 [EcolabTextileCategoryName] [varchar](50) NULL,
								 [EcolabTextileId] [int] NULL,
								 [PlantTextileCategoryName] [varchar](50) NULL,
								 [PlantTextileId] [int] NULL
							 )

    INSERT INTO WaterEnergyLatestRollUpData
							 (
								 [RecordDate] ,
								 [GroupId]  ,
								 [MachineInternalId]  ,
								 [ProgramNumber]  ,
								 [ProductId]  ,
								 [NoOfBatches]  ,
								 [TotalConsumption] ,
								 [TargetConsumption] ,
								 [AverageConsumption],
								 [ActualConsumptionPerLoad],
								 [TargetConsumptionPerLoad],
								 [Cost],
								 [CostPerLoad],
								 [CostExcess] ,
								 [EcolabTextileCategoryName],
								 [EcolabTextileId],
								 [PlantTextileCategoryName]  ,
								 [PlantTextileId]  
							 )
    SELECT 
	  CAST(BD.StartDate AS DATE) as RecordDate
	  ,BD.GroupId
	  ,BD.MachineInternalId
	  ,BD.ProgramNumber
	  ,PRM.ProductId
	  ,COUNT(BD.BatchID) AS NoOfBatches
	  ,SUM(BPD.[ActualQuantity]) AS TotalConsumption
	  ,SUM(BPD.[StandardQuantity]) AS TargetConsumption
	  ,SUM(BPD.[ActualQuantity])/COUNT(BD.ProgramNumber) AS AverageConsumption
	  ,SUM(BPD.[ActualQuantity])/SUM(BD.[ActualWeight]) ActualConsumptionPerLoad
	  ,SUM(BPD.[StandardQuantity])/SUM(BD.[StandardWeight]) TargetConsumptionPerLoad
	  ,SUM(BPD.Price) AS Cost
	  ,SUM(BPD.Price)/COUNT(BD.BatchID) AS CostPerLoad
	  ,(CASE WHEN (SUM(BPD.[ActualQuantity]) - SUM(BPD.[StandardQuantity]) < 0) THEN 0 ELSE ABS(SUM(BPD.[ActualQuantity]) - SUM(BPD.[StandardQuantity]))*SUM(BPD.Price) END) CostExcess
	  ,ETC.TextileId AS EcolabTextileId
	  ,ETC.CategoryName AS EcolabTextileCategoryName
	  ,CTC.TextileId AS PlantTextileId
	  ,CTC.Name AS PlantTextileCategoryName
  FROM 
  TCD.BatchData BD 
	LEFT JOIN TCD.BatchProductData BPD ON BPD.BatchID = BD.BatchID
	LEFT OUTER JOIN TCD.ProductMaster PRM ON PRM.ProductId = BPD.ProductId
	LEFT OUTER JOIN TCD.ProgramMaster PM ON PM.ProgramId = BD.ProgramNumber
	LEFT JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId = PM.EcolabTextileCategoryId
	LEFT OUTER JOIN TCD.ChainTextileCategory CTC ON  CTC.TextileId = PM.ChainTextileId
  WHERE CAST(StartDate AS date) = CAST(@Date AS date)
								AND 
								CASE @Machine   
									WHEN '' THEN 'TRUE'         
									ELSE                                                      
									 CASE WHEN BD.GroupId IN (SELECT GroupId FROM @GroupMachineTable) AND 
									 BD.MachineInternalId IN (SELECT MachineInternalId FROM @GroupMachineTable) THEN 'TRUE' END                                                 
								    END='TRUE' 

								    AND       

								    CASE @machineGroup   
									WHEN '' THEN 'TRUE'         
									ELSE                                                      
									 CASE WHEN BD.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable) THEN 'TRUE' END                                                      
								    END='TRUE' 

								    AND    

								    CASE @Formula   
									WHEN '' THEN 'TRUE'         
									ELSE                                                      
									 CASE WHEN BD.ProgramNumber IN (SELECT Formula FROM @FormulaTable) THEN 'TRUE' END                                                      
								    END='TRUE' 

								    AND       

								    CASE @MachineType   
									WHEN '' THEN 'TRUE'         
									ELSE                                                      
									 CASE WHEN BD.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable)) THEN 'TRUE' END                                                      
								    END='TRUE' 

								    AND       
								   CASE @Category   
									WHEN '' THEN 'TRUE'         
									ELSE                                                      
									 CASE WHEN ETC.TextileId IN (SELECT Category FROM @CategoryTable) THEN 'TRUE' END                                                      
								    END='TRUE' 

								    AND
									CASE @GroupId 
									WHEN '' THEN 'TRUE' 
									ELSE        
								    CASE WHEN (BD.GroupId IN (@GroupId) AND 
									 BD.MachineInternalId IN (@MachineInternalId)) THEN 'TRUE' END                                                   
								    END='TRUE' 
								    AND
									CASE @MachineInternalId 
									WHEN '' THEN 'TRUE' 
									ELSE        
								    CASE WHEN (BD.GroupId IN (@GroupId) AND 
									 BD.MachineInternalId IN (@MachineInternalId)) THEN 'TRUE' END                                                   
								    END='TRUE' 
  GROUP BY 
  BD.GroupId
  ,BD.MachineInternalId
  ,BD.ProgramNumber
  ,CAST(bd.StartDate AS DATE)
  ,ETC.CategoryName
  ,ETC.TextileId
  ,PRM.ProductID
  ,CTC.Name
  ,CTC.TextileId

   
SET NOCOUNT OFF
END