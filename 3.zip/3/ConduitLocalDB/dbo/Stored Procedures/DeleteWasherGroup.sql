﻿/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_DeleteWasherGroup]                                         

Purpose:				To delete the washer group.

Parameters:				@EcolabAccountNumber - holds the ecolab account number.
						@WasherGroupId - holds the washer group id.
						@UserId - holds the user id.
																																		
###################################################################################################                                           
*/
CREATE	PROCEDURE	[TCD].[DeleteWasherGroup]
					@EcoLabAccountNumber					NVARCHAR(25)
				,	@WasherGroupId							INT
				,	@UserId									INT
				--Adding these 3 params as part of re-factoring for integration with Synch/Configurator
				,	@OutputWasherGroupId					INT			=			NULL	OUTPUT
				,	@LastModifiedTimestampAtCentral			DATETIME	=			NULL			--Nullable for local call; Synch/Central call will have to pass this -
																									--else, it will be treated as a local call
				,	@OutputLastModifiedTimestampAtLocal		DATETIME	=			NULL	OUTPUT
AS
BEGIN

SET	NOCOUNT	ON


DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()
	,	@WasherGroupTypeId				INT				=			0

--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
SET		@OutputLastModifiedTimestampAtLocal				=			@CurrentUTCTime
SET		@OutputWasherGroupId							=			ISNULL(@OutputWasherGroupId, NULL)			--SQLEnlight SA0121


--If the call is not local, check that the LastModifiedTime matches with the central
IF	(@LastModifiedTimestampAtCentral IS NOT	NULL
		AND	NOT	EXISTS	(SELECT	1 FROM TCD.[MachineGroup]	GT
							WHERE GT.EcolabAccountNumber = @EcolabAccountNumber
							AND	GT.Id=	@WasherGroupId
							AND	GT.LastModifiedTime		=	@LastModifiedTimestampAtCentral)
	)
	BEGIN
			SET			@ErrorId =	60000
			SET			@ErrorMessage =	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
			RAISERROR	(@ErrorMessage, 16, 1)
			SET			@ReturnValue =	-1
			RETURN		(@ReturnValue)
	END

--Proceed, since it's either a local call or Synch. call with synch. time matching


BEGIN	TRAN

UPDATE	GT SET	GT.Is_Deleted = 'TRUE'
		,GT.LastModifiedTime = @CurrentUTCTime
	FROM [TCD].MachineGroup	GT
		JOIN [TCD].WasherGroup WG ON GT.Id = WG.WasherGroupId AND GT.EcolabAccountNumber = WG.EcolabAccountNumber
		WHERE GT.EcolabAccountNumber =@EcoLabAccountNumber
			AND	GT.Id = @WasherGroupId						--Id is the WasherGroupId in WasherGroup table
			AND	GT.Is_Deleted = 'FALSE'

SET @WasherGroupTypeId =(select [TCD].WasherGroup.WasherGroupTypeId FROM [TCD].WasherGroup WHERE WasherGroupId=@WasherGroupId)

IF (@WasherGroupTypeId=1 )
BEGIN
-- Removing associated Formulas for the tunnel

UPDATE TPS

       SET    Is_Deleted                               =                    'TRUE'

       ,      LastModifiedByUserId       =                    @UserId

FROM   [TCD].TunnelProgramSetup   TPS

WHERE  TPS.WasherGroupId                 =                    @WasherGroupId

       AND    TPS.EcolabAccountNumber           =                    @EcoLabAccountNumber

       AND    TPS.Is_Deleted                           =                    'FALSE'
END


update W set W.Is_Deleted =1,
			 W.LastModifiedTime=@CurrentUTCTime,
			 W.LastModifiedByUserId=@UserId
 FROM 
 [TCD].WasherGroup  WG
	JOIN    [TCD].MachineGroup GT ON  WG.WasherGroupId = GT.Id AND WG.EcolabAccountNumber = GT.EcolabAccountNumber
	JOIN    [TCD].MachineSetup MS ON    WG.WasherGroupId = MS.GroupId AND  WG.EcolabAccountNumber = MS.EcoalabAccountNumber
	JOIN    [TCD].Washer W ON    MS.WasherId  = W.WasherId AND    MS.EcoalabAccountNumber = W.EcoLabAccountNumber
	and WG.WasherGroupId=@WasherGroupId
	and GT.EcolabAccountNumber =@EcoLabAccountNumber


UPDATE WT SET  Active =    0
from TCD.WasherTags WT
inner join [TCD].MachineSetup MS on  wt.WasherId=MS.WasherId and MS.GroupId=@WasherGroupId


--check for any error
SET	@ErrorId	=	@@ERROR
IF	(@ErrorId	<>	0)
	BEGIN
		IF	@@TRANCOUNT	>	0
		BEGIN
			ROLLBACK	TRAN
		END

		SET		@ErrorMessage = N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating washer group as DELETED.'
		--GOTO	Errorhandler
		RAISERROR	(@ErrorMessage, 16, 1)
		SET	@ReturnValue	=	-1
		RETURN	(@ReturnValue)
	END
--Else, continue...
UPDATE	WG SET	WG.LastModifiedByUserId	= @UserId
		FROM [TCD].MachineGroup	GT
			JOIN [TCD].WasherGroup WG ON GT.Id = WG.WasherGroupId AND GT.EcolabAccountNumber = WG.EcolabAccountNumber
		WHERE GT.EcolabAccountNumber = @EcoLabAccountNumber
				AND	GT.Id = @WasherGroupId						--Id is the WasherGroupId in WasherGroup table
				AND	GT.Is_Deleted =	'TRUE'
--check for any error
EXEC [TCD].[SaveInjectionDetails] @WashergroupId,@WashergroupId,0,0,@EcolabAccountNumber

SET	@ErrorId	=	@@ERROR
IF	(@ErrorId	<>	0)
	BEGIN
		IF	@@TRANCOUNT	>	0
		BEGIN
			ROLLBACK	TRAN
		END

		SET		@OutputWasherGroupId	=			NULL

		SET		@ErrorMessage			=			N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred updating washer group as DELETED.'
		--GOTO	Errorhandler
		RAISERROR	(@ErrorMessage, 16, 1)
		SET	@ReturnValue	=	-1
		RETURN	(@ReturnValue)
	END
ELSE
	BEGIN
		IF	@@TRANCOUNT	>	0
		BEGIN
			COMMIT
		END

		SET	@OutputWasherGroupId	=	@WasherGroupId
	END

	DECLARE 
	@WasherGroupNumber INT
	SELECT @WasherGroupNumber = WasherGroupNumber FROM TCD.WasherGroup WHERE WasherGroupId = @WasherGroupId

	UPDATE TCD.Injection SET Is_Deleted = 'TRUE' WHERE WasherGroupNumber = @WasherGroupNumber
--Commented, as this is not required now...
--IF	(	@ErrorId	=	0	)
--	BEGIN
--		--GOTO	ExitModule
--		RETURN	(@ReturnValue)
--	END




--ErrorHandler:
--RAISERROR	(@ErrorMessage, 16, 1)
--SET	@ReturnValue	=	-1




--ExitModule:

SET	NOCOUNT	OFF
RETURN	(@ReturnValue)


END