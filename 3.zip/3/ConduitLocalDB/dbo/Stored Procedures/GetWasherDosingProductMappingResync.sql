﻿CREATE PROCEDURE [TCD].[GetWasherDosingProductMappingResync]
	(
					@EcoLabAccountNumber					NVARCHAR(25)
				,	@WasherDosingSetupId					INT
				)
AS
BEGIN

SET	NOCOUNT	ON

SELECT	WDPM.WasherDosingProductMappingId	AS			WasherDosingProductMappingId
	,	WDPM.WasherDosingSetupId			AS			WasherDosingSetupId		
	,	WDPM.InjectionNumber				AS			InjectionNUmber
	,	WDPM.ProductId						AS			ProductId
	,	CASE  
				WHEN PM.EnvisionDisplayName IS NULL THEN PM.NAME 
				ELSE PM.EnvisionDisplayName 
				END 								AS			ProductName
	,	WDPM.Quantity						AS			Quantity
	,	WDPM.MyServiceFrmulaStpDsgDvcGuid	AS			MyServiceFrmulaStpDsgDvcGuid
	,	WDPM.MyServiceLastSynchTime			AS			MyServiceLastSynchTime
FROM	[TCD].WasherDosingProductMapping			WDPM
JOIN	[TCD].ProductMaster						PM
	ON	WDPM.ProductId						=			PM.ProductId
WHERE	WDPM.EcoLabAccountNumber			=			@EcoLabAccountNumber
	AND	WDPM.WasherDosingSetupId			=			@WasherDosingSetupId

SET	NOCOUNT	OFF

END
