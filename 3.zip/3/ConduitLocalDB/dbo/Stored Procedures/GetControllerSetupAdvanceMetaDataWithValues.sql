﻿CREATE PROCEDURE [TCD].[GetControllerSetupAdvanceMetaDataWithValues]
(
		@TabId INT
	,	@ControllerId INT
	,	@EcolabAccountNumber NVARCHAR(25)
 )
AS
BEGIN  
SET NOCOUNT ON
	IF OBJECT_ID('tempdb..#tmpMetaDataAdvance') IS NOT NULL
		DROP TABLE #tmpMetaDataAdvance
	DECLARE @AllowDefaultTagAddress BIT,
			@ControllerModelId NVARCHAR(50) = NULL;
	SELECT 
			@ControllerModelId = ControllerModelId
	FROM 
		[TCD].ConduitController
	WHERE ControllerId = @ControllerId
		AND EcoalabAccountNumber = @EcolabAccountNumber
	IF NOT EXISTS(SELECT 
				1
			FROM TCD.ControllerTags
			WHERE ControllerId = @ControllerId
				AND EcolabAccountNumber = @EcolabAccountNumber)
        BEGIN
            SET @AllowDefaultTagAddress = 'TRUE';
        END;
    ELSE
        BEGIN
            SET @AllowDefaultTagAddress = 'FALSE';
        END;
	SELECT DISTINCT 
			FG.Id AS FieldGroupId
			,FG.[NAME] AS FieldGroupName
			,FG.[image_Url] as FieldGroupImageUrl
			,FG.[helpText] as FieldGroupHelpText
			,FG.[ControllerModelId]
			,FG.[ControllerTypeId]
			,FGT.NAME AS FieldGroupTypeName
			,F.Id AS FieldId
			,F.Name AS FieldName
			,FT.Name AS FieldType
			,F.Label AS FieldLabel
			,F.[Min] AS FieldMinValue
			,F.[Max] AS FieldMaxValue
			,F.IsMandatory AS FieldIsMandatory
			,F.IsEditable AS FieldIsEditable
			,F.HelpText AS FieldHelpText
			, F.HelpTextUrl AS FieldHelpUrl
			,FG.TabId AS TabIndex
			,DT.Name AS ControlType
			,F.DataSourceId AS DataSourceId
			,(SELECT 
						FS.Value + ':' + FS.Name + ';'
					FROM TCD.FieldSource FS
					WHERE FS.DataSourceId = F.DataSourceId
					FOR XML PATH( '' )
            )AS DataSourceKeyValue 
			,F.DataCategoryId AS DataCategoryId
			,F.DefaultValue
			,F.CurrencyId AS FieldCurrencyCode
			,F.ResourceKey AS FieldResourceKey
			,FG.ResourceKey AS FieldGroupResourceKey
			,FG.DisplayOrder AS FieldGroupDO
			,F.DisplayOrder AS FieldDO 
			,CSD.ControllerId
			,FRM.RoleId AS AccessToRole
			,F.HasFieldTag AS HasFieldTag
			, (
				SELECT 
						TagAddress
					FROM TCD.ControllerTags
					WHERE TagType = F.HasFieldTag
						AND ControllerId = @ControllerId
						AND Active = 1
						AND EcolabAccountNumber = @EcolabAccountNumber) AS TagDefaultValue
			,F.ClassName AS ClassName
			,CC.ControllerVersion
			,0 IsDosingLineConsumed
	INTO #tmpMetaDataAdvance
	FROM [TCD].[FieldGroup] FG
	INNER JOIN [TCD].[FieldGroupFieldMapping] FGFM ON FG.Id = FGFM.FieldGroupId
	INNER JOIN [TCD].[Field] F ON F.Id = FGFM.FieldId
	LEFT JOIN [TCD].[FieldGroupType] FGT ON FGT.Id = FG.FieldGroupTypeId
	LEFT JOIN [TCD].FieldType FT ON FT.Id = F.TypeId 
	LEFT JOIN [TCD].DataType DT ON DT.Id = F.DataTypeId
	LEFT JOIN [TCD].[FieldRoleMapping] FRM ON FRM.FieldId = F.Id

    INNER JOIN [TCD].[ConduitController] CC ON CC.ControllerModelId = FG.ControllerModelId AND CC.ControllerTypeId = FG.ControllerTypeId AND cc.EcoalabAccountNumber = @EcolabAccountNumber

	INNER JOIN [TCD].[ControllerSetupData] CSD ON CSD.ControllerId = CC.ControllerId AND CSD.EcolabAccountNumber = @EcolabAccountNumber
	WHERE 
	CC.ControllerId = @ControllerId
	AND
	FG.TabId = @TabId
	AND 
	CC.EcoalabAccountNumber = @EcolabAccountNumber
	AND F.Label NOT LIKE
			CASE @ControllerModelId
				WHEN 3 THEN 'Automatic Weight Enabled'
				ELSE  ''
			END
		AND F.Label NOT LIKE
			CASE @ControllerModelId
				WHEN 3 THEN  'Ratio Dosing Enabled'
				ELSE    ''
			END
		AND F.Label NOT LIKE  
			CASE @ControllerModelId
		WHEN 3 THEN 'Preflush Time(sec)'  
		ELSE  ''  
			END 
		AND F.Label NOT LIKE  
		CASE @ControllerModelId  
		WHEN 3 THEN 'Postflush Time(sec)'  
		ELSE  ''  
	END 

	UPDATE tmd SET DefaultValue = CSD.Value
	 FROM #tmpMetaDataAdvance tmd
		INNER JOIN [TCD].ControllerSetupData CSD ON  tmd.ControllerId = CSD.ControllerId 
			AND CSD.EcolabAccountNumber = @EcolabAccountNumber
			AND tmd.FieldGroupId = CSD.FieldGroupId 
			AND tmd.FieldId = CSD.FieldId 


update MDA set IsDosingLineConsumed =1
FROM  #tmpMetaDataAdvance MDA
inner join [TCD].[ControllerEquipmentSetUp] CES on MDA.ControllerId=CES.ControllerId  and IsActive=1
where  LTRIM(rtrim( FieldResourceKey))='No_of_Pumps_Connected_to_TCR1' 
and CES.LineNumber >= 1 and CES.LineNumber <= (case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)
and CES.ControllerEquipmentId >= 1 and CES.ControllerEquipmentId <= (case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)

	
update MDA set IsDosingLineConsumed =1
FROM  #tmpMetaDataAdvance MDA
inner join [TCD].[ControllerEquipmentSetUp] CES on MDA.ControllerId=CES.ControllerId  and IsActive=1
where  LTRIM(rtrim( FieldResourceKey))='No_of_Pumps_Connected_to_TCR2' 
and CES.LineNumber >= (case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end) and CES.LineNumber <= ((case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)*2)
and CES.ControllerEquipmentId >= (case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end) and CES.ControllerEquipmentId <= ((case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)*2)

update MDA set IsDosingLineConsumed =1
FROM  #tmpMetaDataAdvance MDA
inner join [TCD].[ControllerEquipmentSetUp] CES on MDA.ControllerId=CES.ControllerId  and IsActive=1
where  LTRIM(rtrim( FieldResourceKey))='No_of_Pumps_Connected_to_TCR3' 
and CES.LineNumber >= ((case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)*2) and CES.LineNumber <= ((case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)*3)
and CES.ControllerEquipmentId >=  ((case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)*2) and CES.ControllerEquipmentId <= ((case when ISNUMERIC( MDA.DefaultValue)=1 then convert(int, MDA.DefaultValue ) else 1 end)*3)

update MDA set IsDosingLineConsumed = (select IsDosingLineConsumed from #tmpMetaDataAdvance where  LTRIM(rtrim( FieldResourceKey))='No_of_Pumps_Connected_to_TCR1' )
FROM  #tmpMetaDataAdvance MDA
where  LTRIM(rtrim( FieldResourceKey)) in( 'Dosing_Line_Mode1' ,'Enable_Auxiliary_pump1','Flow-meter_for_Flow_check1')

update MDA set IsDosingLineConsumed = (select IsDosingLineConsumed from #tmpMetaDataAdvance where  LTRIM(rtrim( FieldResourceKey))='No_of_Pumps_Connected_to_TCR2' )
FROM  #tmpMetaDataAdvance MDA
where  LTRIM(rtrim( FieldResourceKey)) in( 'Dosing_Line_Mode2','Enable_Auxiliary_pump2','meter_for_Flow_check2')

update MDA set IsDosingLineConsumed = (select IsDosingLineConsumed from #tmpMetaDataAdvance where  LTRIM(rtrim( FieldResourceKey))='No_of_Pumps_Connected_to_TCR3' )
FROM  #tmpMetaDataAdvance MDA
where  LTRIM(rtrim( FieldResourceKey)) in( 'Dosing_Line_Mode3','Enable_Auxiliary_pump3','meter_for_Flow_check3') 

	SELECT 
		CC.Name AS ControllerName
		,FieldGroupId
		,FieldGroupName
		,FieldGroupImageUrl
		,FieldGroupHelpText
		,#tmpMetaDataAdvance.ControllerModelId
		,#tmpMetaDataAdvance.ControllerTypeId
		,FieldGroupTypeName
		,FieldId
		,FieldName
		,FieldType
		,FieldLabel
		,FieldMinValue
		,FieldMaxValue
		,FieldIsMandatory
		,FieldIsEditable
		,FieldHelpText
		,FieldHelpUrl
		,TabIndex
		,ControlType
		,DataSourceId
		,DataSourceKeyValue
		,DataCategoryId
		,#tmpMetaDataAdvance.DefaultValue As DefaultValue
		,FieldCurrencyCode
		,FieldResourceKey
		,FieldGroupResourceKey
		,FieldGroupDO
		,FieldDO 
		,#tmpMetaDataAdvance.AccessToRole
		,'Edit' AS Mode
		,HasFieldTag
		,TagDefaultValue	
		,ClassName
		,#tmpMetaDataAdvance.ControllerVersion
		,CAST (IsDosingLineConsumed as bit) IsDosingLineConsumed
	FROM #tmpMetaDataAdvance
	INNER JOIN [TCD].ConduitController CC on #tmpMetaDataAdvance.ControllerId = CC.ControllerId  AND CC.EcoalabAccountNumber = @EcolabAccountNumber
	ORDER BY FieldGroupDO , FieldDO, FieldId 
SET NOCOUNT OFF
END

