﻿CREATE PROCEDURE [TCD].[GetActiveSWbyWasherIdANDFormula]
(	
		@WasherId INT,
		@Formula INT
)

AS
SET NOCOUNT ON
BEGIN

DECLARE			@NominalLoad							DECIMAL(10,2),
				@MaxLoad								DECIMAL(10,2),
				@IsTunnel								BIT,
				@StandardWeight							INT
				
	SELECT @IsTunnel =  ISTUNNEL FROM TCD.MACHINESETUP WHERE WASHERID = @WasherId
	IF(@IsTunnel = 0)
	BEGIN
		SELECT DISTINCT 					
					@NominalLoad=Wps.NominalLoad, 
					@MaxLoad =Ws.MaxLoad					
		FROM TCD.Washer Ws
						INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
						INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
						INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
						INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
			WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@Formula
	SELECT @StandardWeight=(@NominalLoad * @MaxLoad) /CONVERT(decimal(10,2), 100) 	
	SELECT @StandardWeight
	END
	ELSE
	BEGIN
		SELECT DISTINCT 					
					@NominalLoad=Wps.NominalLoad					
		FROM TCD.Washer Ws
						INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
						INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
						INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
						INNER JOIN TCD.TunnelProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
			WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@Formula
	SELECT @StandardWeight = @NominalLoad
	SELECT @StandardWeight
	END					
						
END
	