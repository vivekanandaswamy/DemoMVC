﻿CREATE PROCEDURE [TCD].[ProcessConventionalOnlineDataForPLCXL](
 @ControllerID   INT,
 @VxML           XML,
 @RedFlagShiftId INT OUTPUT)
AS
 BEGIN
     DECLARE @MachineNumber           INT,
     @StepNumber              INT,
     @StartDateTime           DATETIME,
     @EndDateTime             DATETIME,
     @ProgramNumber           INT,
     @Load                    DECIMAL(10, 2),
     @NominalLoad             DECIMAL(10, 2),
     @CustomerNumber          INT,
     @WaterConsumption1       INT,
     @PHValue                 INT,
     @TemperatureMax          INT,
     @BatchNumber             INT,
     @WasherID                INT,
     @WasherGroupID           INT,
     @EcoLabWasherID          INT,
     @ProgramMasterID         INT,
     @PlantWasherNumber       INT,
     @ShiftID                 INT,
     @BatchID                 INT,
     @ShiftStartdate          DATETIME,
     @StdInjectionSteps       INT,
     @StdWashSteps            INT,
     @ActualInjSteps          INT,
     @CurrencyCode            VARCHAR(50),
     @PartitionOn             DATETIME2,
     @TargetTurnTime          SMALLINT,
     @EcolabTextileCategoryId INT,
     @ChainTextileCategoryId  INT,
     @FormulaSegmentId        INT,
     @EcolabSaturationId      INT,
     @PlantProgramId          INT,
     @FrmParameterID          INT,
     @PrevRealQty             DECIMAL(16,4);
     SELECT
    @MachineNumber = T.c.value('@MachineNumber', 'INT'),
    @StepNumber = T.c.value('@StepNumber', 'INT'),
    @StartDateTime = T.c.value('@StartDateTime', 'DATETIME'),
    @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
    @Load = T.c.value('@Load', 'decimal(10,2)'),
    @NominalLoad = T.c.value('@NominalLoad', 'decimal(10,2)'),
    @CustomerNumber = T.c.value('@CustomerNumber', 'INT'),
    @WaterConsumption1 = T.c.value('@WaterConsumption1', 'INT'),
    @PHValue = T.c.value('@PHValue', 'INT'),
    @TemperatureMax = T.c.value('@TemperatureMax', 'INT'),
    @BatchNumber = T.c.value('@BatchNumber', 'INT')
     FROM @VxML.nodes('ConventionalWasherData') T(C);
     --Check for valid startdatetime
     IF(@StartDateTime <= '01/01/1900'
    OR @StartDateTime > '06/06/2079')
     BEGIN
     RETURN;
     END;
     SELECT
    @FrmParameterID = Id
     FROM TCD.ConduitPArameters
     WHERE Name = 'Formula Number';
     DECLARE @ShiftMapping TABLE
     (
      ShiftId        INT,
      ShiftName      NVARCHAR(50),
      ShiftStartdate DATETIME
     );
     INSERT INTO @ShiftMapping
     (
    ShiftId,
    ShiftName,
    ShiftStartdate
     )
     EXEC TCD.GetShiftStartDate
      @StartDateTime;
     SELECT
    @ShiftID = ShiftID,
    @ShiftStartdate = ShiftStartdate,
    @PartitionOn = ShiftStartdate
     FROM @ShiftMapping;
     SELECT
    @WasherGroupID = GroupId,
    @WasherID = WasherID
     FROM TCD.MachineSetup ms
     WHERE ControllerID = @ControllerID
   AND MachineInternalId = @MachineNumber
   AND IsTunnel = 0
   AND ms.IsDeleted = 0;
     IF(@EndDateTime = '1/1/1900')
     SELECT
    @EndDateTime = NULL;
     IF(@StartDateTime = '1/1/1900')
     SELECT
    @StartDateTime = NULL;
     IF(@WasherId IS NOT NULL)
     BEGIN
     SELECT
        @ProgramMasterId = Wps.ProgramId
     FROM TCD.Washer Ws
      INNER JOIN TCD.MachineSetup Ms ON Ms.WasherId = Ws.
      WasherId
      INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =
      Ms.GroupId
      INNER JOIN TCD.WasherProgramSetup Wps ON Wps.
      WasherGroupId = Wg.WasherGroupId
      INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber =
      Ws.EcoLabAccountNumber
     WHERE Ws.WasherId = @WasherId
       AND Wps.ProgramNumber = @ProgramNumber
       AND Wps.Is_Deleted = 0
       AND ms.IsDeleted = 0;
     SELECT
        @EcoLabWasherID = EcolabWasherId,
        @PlantWasherNumber = PlantWasherNumber,
        @CurrencyCode = P.CurrencyCode,
        @TargetTurnTime = w.TargetTurnTime * 60
     FROM TCD.Washer w
      INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.
      EcolabAccountNumber
     WHERE w.WasherId = @WasherID
       AND w.Is_Deleted = 0;
     END;
     SELECT
    @BatchID = BatchID
     FROM TCD.BatchData
     WHERE MachineInternalID = @MachineNumber
   AND CAST(StartDate AS DATE) = CAST(@StartDateTime AS DATE)
   AND ControllerBatchId = @BatchNumber
   AND MachineID = @WasherID;
     --Start Getting InjectionCount and StepCount
     SELECT
    @StdInjectionSteps = COUNT(DISTINCT wdpm.
    WasherDosingSetupId),
    @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) -
    COUNT(DISTINCT wdpm.WasherDosingSetupId)
     FROM TCD.WasherDosingProductMapping wdpm
      RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm.
      WasherDosingSetupId = wds.WasherDosingSetupId
     WHERE wds.GroupId = @WasherGroupID
   AND wds.ProgramNumber = @ProgramNumber
   AND wds.Is_Deleted=0;
     --End Getting InjectionCount and StepCount
     --Start-----ProgramMasterID logic for PlantChainProgram
     SELECT
    @PlantProgramId = pm.PlantProgramId,
    @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
    @ChainTextileCategoryId = pm.ChainTextileId,
    @FormulaSegmentId = pm.FormulaSegmentId,
    @EcolabSaturationId = pm.EcolabSaturationId
     FROM TCD.ProgramMaster pm
     WHERE pm.ProgramId = @ProgramMasterId
   AND pm.Is_Deleted = 0;
     IF(@PlantProgramId <> 0
    OR @PlantProgramId IS NOT NULL)
     BEGIN
     --Assign value from plantchainprogram table based on plantprogramId
     SELECT
        @EcolabTextileCategoryId = pcp.
        EcolabTextileCategoryId,
        @ChainTextileCategoryId = pcp.
        ChainTextileCategoryId,
        @FormulaSegmentId = pcp.FormulaSegmentId,
        @EcolabSaturationId = pcp.EcolabSaturationId
     FROM tcd.PlantChainProgram pcp
     WHERE pcp.PlantProgramId = @PlantProgramId
       AND pcp.Is_Deleted = 0;
     END;
     --End-----ProgramMasterID logic for PlantChainProgram
     IF(@BatchID IS NULL)
     BEGIN
     INSERT INTO TCD.BatchData
     (
        ControllerBatchID,
        EcolabWasherId,
        GroupId,
        MachineInternalId,
        PlantWasherNumber,
        StartDate,
        EndDate,
        ProgramNumber,
        ProgramMasterId,
        MachineID,
        ActualWeight,
        StandardWeight,
        CurrencyCode,
        ShiftId,
        PartitionOn,
        StdInjectionSteps,
        StdWashSteps,
        EcolabTextileCategoryId,
        ChainTextileCategoryId,
        FormulaSegmentId,
        EcolabSaturationId,
        PlantProgramId,
        TargetTurnTime
     )
     VALUES
     (
        @BatchNumber,
        @EcoLabWasherID,
        @WasherGroupID,
        @MachineNumber,
        @PlantWasherNumber,
        @StartDateTime,
        @EndDateTime,
        @ProgramNumber,
        @ProgramMasterId,
        @WasherID,
        @Load,
        @NominalLoad,
        @CurrencyCode,
        @ShiftID,
        @PartitionOn,
        @StdInjectionSteps,
        @StdWashSteps,
        @EcolabTextileCategoryId,
        @ChainTextileCategoryId,
        @FormulaSegmentId,
        @EcolabSaturationId,
        @PlantProgramId,
        @TargetTurnTime
     );
     SELECT
        @BatchID = SCOPE_IDENTITY();
     IF NOT EXISTS
     (
     SELECT
        *
     FROM TCD.BatchParameters
     WHERE BatchId = @BatchID
       AND ParameterID = 38
     )
     BEGIN
     IF(@StdWashSteps <> 0
        OR @StdWashSteps <> NULL)
         BEGIN
         INSERT INTO TCD.BatchParameters
         (
        BatchId,
        EcolabWasherId,
        ParameterId,
        ParameterValue,
        PartitionOn
         )
         SELECT
        @BatchID,
        @EcoLabWasherID,
        38,
        @StdWashSteps,
        @ShiftStartdate;
         END;
     END;
     --End Date  Time  is Null 
     IF EXISTS(SELECT
                              *
       FROM TCD.BatchData
                          WHERE
       MachineInternalID = @MachineNumber
       AND StartDate <> @StartDateTime
       AND EndDate IS NULL
       AND ControllerBatchId <> @BatchNumber
       AND MachineId = @WasherId)
                BEGIN
        DECLARE @CurrentUTCDate DATETIME;
        SELECT @CurrentUTCDate=DateAdd(ss,-10,@StartDateTime)
        DECLARE @ShiftIdByEndDate INT,
          @PartitionOnByEndDate DATETIME;
        DECLARE @Shiftmappingbyenddate TABLE(
          ShiftId INT, 
          ShiftName NVARCHAR(50), 
          ShiftStartdate DATETIME);

        INSERT INTO @Shiftmappingbyenddate(
          ShiftId, 
          ShiftName, 
          ShiftStartdate)
        EXEC TCD.GetShiftStartDate @CurrentUTCDate;
        SELECT
          @ShiftIdByEndDate = ShiftID, 
          @PartitionOnByEndDate = ShiftStartdate FROM @Shiftmappingbyenddate;
        UPDATE TCD.BatchData
       SET
          EndDate = DateAdd(ss,-10,@StartDateTime),
          ShiftId = @ShiftIdByEndDate,
          PartitionOn = @PartitionOnByEndDate
        WHERE
          MachineInternalID = @MachineNumber
          AND StartDate <> @StartDateTime
          AND EndDate IS NULL
          AND ControllerBatchId <> @BatchNumber
          AND MachineId = @WasherId;
       END
     -- Program Number 
     IF(@ProgramNumber IS NOT NULL
    AND @ProgramNumber > 0)
     BEGIN
     IF NOT EXISTS
     (
         SELECT
        *
         FROM TCD.WasherReading
         WHERE WasherId = @WasherID
       AND ParameterID = @FrmParameterID
       AND DateTimeStamp = @StartDateTime
     )
         BEGIN
         INSERT INTO TCD.WasherReading
         (
        WasherID,
        ParameterID,
        ParameterValue,
        DateTimeStamp,
        EcoLabWasherID,
        Partitionon
         )
         VALUES
         (
        @WasherID,
        @FrmParameterID,
        @ProgramNumber,
        @StartDateTime,
        @EcoLabWasherID,
        @ShiftStartdate
         );
         END;
     END;
     IF NOT EXISTS
     (
     SELECT
        1
     FROM TCD.BatchCustomerData
     WHERE BatchID = @BatchId
       AND @CustomerNumber IS NOT NULL
     )
     BEGIN
     INSERT INTO [TCD].[BatchCustomerData]
     (
        BatchId,
        CustomerID,
        Weight,
		PiecesCount,
        PartitionOn,
        EcolabWasherId
     )
    SELECT DISTINCT
  Bd.BatchId,
  Pc.ID,
  @Load,
   ROUND(COALESCE((@Load * Pm.Pieces)
  / NULLIF(Pm.Weight, 0), 0), 0),
   (
   SELECT TOP 1
      ShiftStartdate
   FROM @ShiftMapping
   ),
  @EcolabWasherId
  FROM TCD.Washer WS
  INNER JOIN TCD.MachineSetup Mst ON
  Mst.WasherId = ws.WasherId
  INNER JOIN TCD.WasherGroup Wg ON Wg.
  WasherGroupId = Mst.GroupId
  INNER JOIN TCD.TunnelProgramSetup
  Tps ON Tps.WasherGroupId = Wg.WasherGroupId
  INNER JOIN TCD.ProgramMaster Pm ON
  Pm.ProgramId = Tps.ProgramId
  INNER JOIN TCD.PlantCustomer Pc ON
  Pc.ID = Pm.CustomerId
  INNER JOIN TCD.BatchData Bd ON Bd.
  MachineId = Ws.WasherId
  WHERE Ws.WasherId = @WasherId
   AND Tps.ProgramNumber =
   @ProgramNumber
   AND Bd.BatchId = @BatchID
   AND Pm.CustomerId != -1
   AND Pm.[Weight] > 0;
    END;
     ELSE
     IF(@CustomerNumber > 0)
     BEGIN
     UPDATE TCD.BatchCustomerData
       SET
       CustomerID = @CustomerNumber,
       Weight = @Load
     WHERE
       BatchID = @BatchId;
     END;
     END;
     EXEC TCD.AddSensorData
      @ControllerID,
      @WasherID,
      @WasherGroupID,
      1, --Temparature
      @TemperatureMax;
     EXEC TCD.AddSensorData
      @ControllerID,
      @WasherID,
      @WasherGroupID,
      2, --PH
      @PHValue;
     EXEC TCD.AddMeterReading
      @ControllerID,
      @WasherID,
      2, --Water
      @WaterConsumption1;
     CREATE TABLE #Dosing
     (
      EquipmentNo INT,
      StepNo      INT,
      Qty         DECIMAL(18, 4)
     );
     INSERT INTO #Dosing
     SELECT
    T.c.value('@Equipment', 'INT'),
    T.c.value('@stepNo', 'INT'),
    T.c.value('@Qty', 'decimal(18,4)')
     FROM @VxML.nodes('ConventionalWasherData/DosingData/Dosing') T(C)
     ;

     --Start Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
     SELECT
    @ActualInjSteps = COUNT(DISTINCT StepNo)
     FROM #Dosing;
     IF NOT EXISTS
     (
     SELECT
    *
     FROM TCD.BatchParameters
     WHERE ParameterId = 37
       AND batchid = @BatchId
       AND @ActualInjSteps > 0
     )
     BEGIN
     IF(ISNULL(@ActualInjSteps, 0) > 0)
     BEGIN
     INSERT INTO TCD.BatchParameters
     (
        BatchId,
        EcolabWasherId,
        ParameterId,
        ParameterValue,
        PartitionOn
     )
     SELECT
        @BatchId,
        @EcolabWasherID,
        37,
        @ActualInjSteps,
        @ShiftStartDate;
     END;
     END;
     ELSE
     BEGIN
     UPDATE TCD.BatchParameters
       SET
       ParameterValue = @ActualInjSteps
     WHERE
       ParameterId = 37
       AND batchid = @BatchID;
     END;     
     --END Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
          SELECT TOP 1
    @PrevRealQty = RealQty
    FROM TCD.WasherProductReading
    WHERE ControllerId = @ControllerID
    AND WasherId = @WasherId
    ORDER BY
    DateTimeStamp DESC;
     INSERT INTO [TCD].[WasherProductReading]
     (
    ControllerId,
    WasherId,
    MachineInternalId,
    ProductId,
    TheoreticalQty,
    RealQty,
    DosingPoint,
    DosingNumber,
    ProgramNumber,
    BatchNumber,
    ValveNumber,
    DateTimeStamp
     )
     SELECT
    @ControllerID,
    @WasherID,
    @MachineNumber,
    CE.ProductID,
    NULL,
	CASE 
		WHEN equipmentNo =13 OR equipmentNo = 14 OR equipmentNo =27 OR equipmentNo = 28 THEN d.Qty * 16
		ELSE d.Qty
		END,
    equipmentNo,
    equipmentNo,
    @ProgramNumber,
    @BatchNumber,
    NULL,
    GETUTCDATE()
     FROM #Dosing d
      INNER JOIN TCD.ControllerEquipmentSetup CE ON d.equipmentNo
      = CE.ControllerEquipmentId
            AND d.
            EquipmentNo > 0
            AND d.Qty > 0
            AND CE.
            controllerID = @ControllerID
            AND d.Qty!=isnull(@PrevRealQty,0)
            AND CE.
            ProductID IS NOT NULL;
 END;