﻿
/*	                                   
###################################################################################################                                           

Stored Procedure:       [tcd].[GetWasherBatchSummarizedData]                                             

Purpose:				To get the Dashboard results Total LBS, Effiecency, Lost LBS and Lost Loads.

Parameters:				@Dashboardid - holds Dashboard number.

Modified:				Missload load corrected.
																
###################################################################################################                                           
*/

CREATE PROCEDURE TCD.GetWasherBatchSummarizedData(
       @Dashboardid INT = NULL)
AS
BEGIN
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    SET NOCOUNT ON;
    DECLARE   --@DashBoardId int = 1, 
              @Washerid INT = NULL, 
              @Standardturntime INT = NULL, 
              @Machinenamedispalytype SMALLINT = 0, 
              @Overnightbatchthreshold INT = 7200, 
              -- Seconds  
              @Efficiencytype INT, 
              @Regionid INT, 
              @Ecolabaccountnumber NVARCHAR(25), 
              @Timeefficiencymaxcap FLOAT, 
              @Loadefficiencymaxcap FLOAT, 
              @Const_100 FLOAT = 100;

    SELECT
            @Efficiencytype = ISNULL(EfficiencyCalcType, 1), 
            @Ecolabaccountnumber = EcolabAccountNumber
        FROM tcd.Dashboard
        WHERE DashboardId = @Dashboardid;

    SELECT
            @Regionid = RegionId
        FROM TCD.Plant
        WHERE EcolabAccountNumber = @Ecolabaccountnumber;

    SELECT
            @Timeefficiencymaxcap = CAST(Value AS FLOAT)
        FROM tcd.ConfigSettings
        WHERE KeyName = 'TimeEfficiencyMaxCapValue'
          AND TYPE = 'MAXCAP';

    SELECT
            @Loadefficiencymaxcap = CAST(Value AS FLOAT)
        FROM tcd.ConfigSettings
        WHERE KeyName = 'LoadEfficiencyMaxCapValue'
          AND TYPE = 'MAXCAP';



    DECLARE @Dashboardmachinemapping TABLE(
            Id INT, 
            GroupID INT, 
            WasherId INT, 
            WasherName NVARCHAR(100), 
            WasherNumber INT, 
            IsPLCConnected BIT, 
            DispenserName VARCHAR(250), 
            ControllerId INT);
    DECLARE @Alarmbymachine TABLE(
            GroupID INT, 
            WasherID INT, 
            Alarm BIT NULL, 
            AlarmDescription NVARCHAR(250));
    DECLARE @Batchendtimes TABLE(
            GroupID INT, 
            WasherID INT, 
            CurrentBatchEndTime INT NULL, 
            BatchEndTime TIME);
    DECLARE @Shiftids TABLE(
            ShiftId INT, 
            ShiftStartDate DATETIME, 
            ShiftEndDate DATETIME);
    DECLARE @Summarizeddata TABLE(
            GroupId INT, 
            MachineId INT, 
            WasherName NVARCHAR(100), 
            WasherNumber INT, 
            TargetLoad FLOAT, 
            ActualLoad FLOAT, 
            LoadEfficiency FLOAT, 
            TimeEfficiency FLOAT, 
            LostLoad FLOAT, 
            Alarm BIT, 
            AlarmDescription NVARCHAR(250), 
            WasherStatus INT, 
            MachineNameDispalyType SMALLINT, 
            TargetTurnTime INT, 
            DefaultIdleTime INT, 
            IsPLCConnected BIT, 
            DispenserName VARCHAR(250), 
            LostBatches DECIMAL(18, 6), 
            OverAllEfficiency DECIMAL(18, 6));
    INSERT INTO @Dashboardmachinemapping(
            Id, 
            GroupID, 
            WasherId, 
            WasherName, 
            WasherNumber, 
            IsPLCConnected, 
            DispenserName, 
            ControllerId)
    SELECT
            ROW_NUMBER()OVER(ORDER BY MS.GroupID)AS Id, 
            MS.GroupId, 
            MS.WasherID, 
            MS.MachineName, 
            W.PlantWasherNumber AS WasherNumber, 
            CASE
                WHEN ISNULL(AD.IsActive, 0) = 0 THEN CAST(1 AS BIT)
                WHEN ISNULL(AD.IsActive, 0) = 1 THEN CAST(0 AS BIT)
            END AS IsPLCConnected, 
            CAST(CC.ControllerNumber AS NVARCHAR) + ' (' + CC.TopicName + ')' AS DispenserName, 
            CC.ControllerId AS ControllerId
        FROM(SELECT DISTINCT
                     MachineId, 
                     DashboardId FROM TCD.MonitorSetUpMapping)AS DM
            INNER JOIN TCD.MachineSetup AS MS ON DM.MachineId = MS.WasherID
            INNER JOIN tcd.Washer AS W ON MS.WasherId = W.WasherId
            INNER JOIN TCD.Dashboard AS D ON DM.DashBoardId = D.DashBoardId
            INNER JOIN TCD.ConduitController AS CC ON CC.ControllerId = MS.ControllerId
            LEFT JOIN TCD.AlarmData AS AD ON AD.ControllerId = MS.ControllerId
                                         AND IsActive = 1
                                         AND AD.AlarmCode = CASE
                                                                WHEN(SELECT
                                                                             VALUE
                                                                         FROM TCD.controllerSetupData AS CSD
                                                                              LEFT JOIN TCD.Field AS F ON F.Id = CSD.FieldId
                                                                         WHERE F.Label = 'Webport Ftp Enabled'
                                                                           AND CSD.ControllerId = AD.ControllerId
                                                                           AND CC.ControllerTypeId = 1) = 'true' THEN 9002
                                                                ELSE 9001
                                                            END
        WHERE DM.DashboardId = @Dashboardid
          AND MS.IsDeleted = 0
          AND w.Is_Deleted = 0  
              -- Exclude Phony Washers from Efficiency calculation   
          AND ms.WasherId NOT IN(SELECT
                                         w.WasherId
                                     FROM TCD.MachineSetup AS ms
                                          INNER JOIN TCD.Washer AS w ON w.WasherId = ms.WasherId
                                                                    AND ms.EcoalabAccountNumber = w.EcoLabAccountNumber
                                     WHERE NULLIF(ms.ControllerId, 0)IS NULL
                                       AND w.WasherMode = 0
                                        OR MS.IsPony = 1);  
  
  
    -- For efficiency calculations on shift wise  
    IF @Efficiencytype = 1
        BEGIN
            INSERT INTO @Shiftids(
                    ShiftId, 
                    ShiftStartDate, 
                    ShiftEndDate)
            SELECT DISTINCT
                    ShiftId, 
                    StartDateTime, 
                    EndDateTime
                FROM TCD.ProductionShiftData
                WHERE GETUTCDATE()BETWEEN StartDateTime AND EndDateTime;   
        --WHERE ShiftId = --1105
        END;
    ELSE -- For efficiency calculations on Day wise  
        BEGIN
            INSERT INTO @Shiftids(
                    ShiftId, 
                    ShiftStartDate, 
                    ShiftEndDate)
            SELECT
                    ShiftId, 
                    StartDateTime, 
                    EndDateTime
                FROM TCD.ProductionShiftData
                WHERE startdatetime > CAST(GETUTCDATE()AS DATE)
                  AND startdatetime < DATEADD(dd, 1, CAST(GETUTCDATE()AS DATE))
                ORDER BY
                    startdatetime;
        END;
    SELECT
            * INTO
            #BatchData
        FROM tcd.BatchData AS bd(NOLOCK)
        WHERE bd.ShiftId IN(SELECT
                                    si.ShiftId FROM @Shiftids AS si)
          AND bd.StandardWeight > 0
          AND bd.ActualWeight > 0
          AND bd.EndDate IS NOT NULL;

    CREATE NONCLUSTERED INDEX IX_BatchDatatemp ON #BatchData(GroupId, ProgramNumber, ProgramMasterId, MachineId)INCLUDE(BatchId, EcolabWasherId,
StartDate, EndDate, ActualWeight, StandardWeight, ManualInputWeight, ShiftId, TargetTurnTime);

    SELECT
            CASE
                WHEN CAST(bd.ActualWeight + ISNULL(BD.ManualInputWeight, 0)AS FLOAT) / CAST(NULLIF(bd.StandardWeight, 0)AS FLOAT) * 100 >=
@Loadefficiencymaxcap THEN @Loadefficiencymaxcap
                ELSE CAST(bd.ActualWeight + ISNULL(BD.ManualInputWeight, 0)AS FLOAT) / CAST(NULLIF(bd.StandardWeight, 0)AS FLOAT) * 100
            END AS LoadEfficiency, 
            BD.MachineId, 
            BD.GroupId INTO
            #CurrBatch_LEfficiency_PerMachine
        FROM tcd.BatchData AS bd(NOLOCK)
             INNER JOIN @Dashboardmachinemapping AS DMM ON bd.GroupId = DMM.GroupID
                                                       AND bd.MachineId = DMM.WasherId
        WHERE bd.ShiftId IN(SELECT
                                    si.ShiftId FROM @Shiftids AS si)
          AND bd.StandardWeight > 0
          AND bd.ActualWeight > 0
          AND bd.EndDate IS NULL;


    -- Efficiency for each batch   
    SELECT
            bd.BatchId, 
            W_1.WasherGroupID AS GroupID, 
            W_1.WasherId AS MachineID, 
            bd.ShiftId, 
            W_1.WasherNumber, 
            W_1.WasherName, 
            bd.ActualWeight + ISNULL(BD.ManualInputWeight, 0)AS ActualProduction, 
            bd.StandardWeight AS StandardProduction, 
            CASE
                WHEN DATEDIFF(ss, bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @Overnightbatchthreshold THEN W_1.StandardRunTime
                ELSE DATEDIFF(ss, bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
            END AS ActualRunTime, 
            W_1.StandardRunTime, 
            TT.ActualTurnTime, 
            bd.TargetTurnTime AS StandardTurnTime, 
            CASE
                WHEN W_1.WasherGroupTypeID = 1   
            -- Conventional  
            THEN CASE
                     WHEN CAST(W_1.Standardruntime + bd.TargetTurnTime AS FLOAT) / CAST(CASE
                                                                                            WHEN DATEDIFF(ss, bd.StartDate, ISNULL(bd.EndDate,
GETDATE())) > @Overnightbatchthreshold THEN W_1.StandardRunTime
                                                                                            ELSE DATEDIFF(ss, bd.StartDate, ISNULL(bd.EndDate,
GETDATE()))
                                                                                        END + CASE
                                                                                                  WHEN TT.ACTUALTURNTIME = 0 THEN ISNULL(bd.
TargetTurnTime, 0)
                                                                                                  ELSE ISNULL(TT.ACTUALTURNTIME, 0)
                                                                                              END AS FLOAT) * @Const_100 >= @Timeefficiencymaxcap
THEN @Timeefficiencymaxcap / @Const_100
                     ELSE CAST(W_1.Standardruntime + bd.TargetTurnTime AS FLOAT) / CAST(CASE
                                                                                            WHEN DATEDIFF(ss, bd.StartDate, ISNULL(bd.EndDate,
GETDATE())) > @Overnightbatchthreshold THEN W_1.StandardRunTime
                                                                                            ELSE DATEDIFF(ss, bd.StartDate, ISNULL(bd.EndDate,
GETDATE()))
                                                                                        END + CASE
                                                                                                  WHEN TT.ACTUALTURNTIME = 0 THEN ISNULL(bd.
TargetTurnTime, 0)
                                                                                                  ELSE ISNULL(TT.ACTUALTURNTIME, 0)
                                                                                              END AS FLOAT)
                 END
            END AS TimeEfficiency, 
            CASE
                WHEN CAST(bd.ActualWeight + ISNULL(BD.ManualInputWeight, 0)AS FLOAT) / CAST(NULLIF(bd.StandardWeight, 0)AS FLOAT) * 100 >=
@Loadefficiencymaxcap THEN @Loadefficiencymaxcap
                ELSE CAST(bd.ActualWeight + ISNULL(BD.ManualInputWeight, 0)AS FLOAT) / CAST(NULLIF(bd.StandardWeight, 0)AS FLOAT) * 100
            END AS LoadEfficiency,  
            --missedloads formulae
            --------(((Actual Production/totalefficiency)*100)-actualproduction)
            (CAST(bd.ActualWeight AS DECIMAL(18, 6)) / CAST(CASE
                                                                WHEN CAST(bd.ActualWeight + ISNULL(BD.ManualInputWeight, 0)AS FLOAT) / CAST(NULLIF(bd
.StandardWeight, 0)AS FLOAT) * 100 >= @Loadefficiencymaxcap THEN @Loadefficiencymaxcap
                                                                ELSE CAST(bd.ActualWeight + ISNULL(BD.ManualInputWeight, 0)AS FLOAT) / CAST(NULLIF(bd
.StandardWeight, 0)AS FLOAT) * 100
                                                            END * CASE
                                                                      WHEN W_1.WasherGroupTypeID = 1 THEN CASE
                                                                                                              WHEN CAST(W_1.Standardruntime + bd.
TargetTurnTime AS FLOAT) / CAST(CASE
                                    WHEN DATEDIFF(ss, bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @Overnightbatchthreshold THEN W_1.
StandardRunTime
                                    ELSE DATEDIFF(ss, bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
                                END + CASE
                                          WHEN TT.ACTUALTURNTIME = 0 THEN ISNULL(bd.TargetTurnTime, 0)
                                          ELSE ISNULL(TT.ACTUALTURNTIME, 0)
                                      END AS FLOAT) * @Const_100 >= @Timeefficiencymaxcap THEN @Timeefficiencymaxcap / @Const_100
                                                                                                              ELSE CAST(W_1.Standardruntime + bd.
TargetTurnTime AS FLOAT) / CAST(CASE
                                    WHEN DATEDIFF(ss, bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @Overnightbatchthreshold THEN W_1.
StandardRunTime
                                    ELSE DATEDIFF(ss, bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
                                END + CASE
                                          WHEN TT.ACTUALTURNTIME = 0 THEN ISNULL(bd.TargetTurnTime, 0)
                                          ELSE ISNULL(TT.ACTUALTURNTIME, 0)
                                      END AS FLOAT)
                                                                                                          END
                                                                  END AS DECIMAL(18, 6)) * 100.0) - ISNULL(CAST(bd.ActualWeight AS DECIMAL(18, 6)), 0)
AS MissedLoads, 
            --CAST(CAST(bd.ActualWeight AS DECIMAL(18, 6))/ 
            CASE
                WHEN CAST(bd.ActualWeight + ISNULL(BD.ManualInputWeight, 0)AS FLOAT) / CAST(NULLIF(bd.StandardWeight, 0)AS FLOAT) * 100 >=
@Loadefficiencymaxcap THEN @Loadefficiencymaxcap
                ELSE CAST(bd.ActualWeight + ISNULL(BD.ManualInputWeight, 0)AS FLOAT) / CAST(NULLIF(bd.StandardWeight, 0)AS FLOAT) * 100
            END * CASE
                      WHEN W_1.WasherGroupTypeID = 1 THEN CASE
                                                              WHEN CAST(W_1.Standardruntime + bd.TargetTurnTime AS FLOAT) / CAST(CASE
                                                                                                                                     WHEN DATEDIFF(ss,
bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @Overnightbatchthreshold THEN W_1.StandardRunTime
                                                                                                                                     ELSE DATEDIFF(ss,
bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
                                                                                                                                 END + CASE
                                                                                                                                           WHEN TT.
ACTUALTURNTIME = 0 THEN ISNULL(bd.TargetTurnTime, 0)
                                                                                                                                           ELSE
ISNULL(TT.ACTUALTURNTIME, 0)
                                                                                                                                       END AS FLOAT)
* @Const_100 >= @Timeefficiencymaxcap THEN @Timeefficiencymaxcap / @Const_100
                                                              ELSE CAST(W_1.Standardruntime + bd.TargetTurnTime AS FLOAT) / CAST(CASE
                                                                                                                                     WHEN DATEDIFF(ss,
bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @Overnightbatchthreshold THEN W_1.StandardRunTime
                                                                                                                                     ELSE DATEDIFF(ss,
bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
                                                                                                                                 END + CASE
                                                                                                                                           WHEN TT.
ACTUALTURNTIME = 0 THEN ISNULL(bd.TargetTurnTime, 0)
                                                                                                                                           ELSE
ISNULL(TT.ACTUALTURNTIME, 0)
                                                                                                                                       END AS FLOAT)
                                                          END
                  END AS TotalEfficiency, 
            --AS DECIMAL(18, 6))AS TotalEfficiency, 
            W_1.MaxLoad INTO
            #BatchEfficiency
        FROM #BatchData AS bd --FROM TCD.BatchData bd   
             RIGHT OUTER JOIN TCD.WasherFormulaRunTimes AS W_1 ON BD.GroupId = W_1.WasherGroupID
                                                               AND ISNULL(BD.EcolabWasherId, 0) = ISNULL(W_1.EcolabWasherId, 0)
                                                               AND bd.MachineID = W_1.WasherId
                                                               AND BD.ProgramMasterId = W_1.ProgramId
                                                               AND BD.ProgramNumber = W_1.ProgramNumber
             LEFT JOIN TCD.Turntime AS TT ON ISNULL(BD.EcolabwasherID, 0) = ISNULL(TT.EcolabWasherId, 0)
                                         AND BD.batchid = TT.BatchID
        WHERE 
        W_1.IsTunnel = 0 AND
        DATEDIFF(ss, bd.StartDate, bd.EndDate) > W_1.Standardruntime * 10 / 100;


    SELECT
            DM.GroupID, 
            DM.WasherId AS MachineID, 
            DM.WasherNumber, 
            DM.WasherName, 
            CAST(SUM(t.ActualProduction)AS FLOAT)AS ActualProduction, 
            CAST(SUM(t.StandardProduction)AS FLOAT)AS StandardProduction, 
            SUM(t.ActualRunTime)AS ActualRuntime, 
            SUM(t.StandardRunTime)AS StandardRunTime, 
            --ISNULL(SUM(t.MissedLoads),0) AS MissedLoads, 
            ISNULL(SUM(IIF(t.MissedLoads < 0, 0, t.MissedLoads)), 0)AS MissedLoads, 
            CAST(SUM(t.LoadEfficiency)AS FLOAT) / COUNT(DISTINCT t.BatchId)AS LoadEfficiency, 
            CAST(SUM(t.TimeEfficiency)AS FLOAT) / COUNT(DISTINCT t.BatchId)AS TimeEfficiency, 
            CAST(SUM(T.StandardProduction * T.LoadEfficiency * t.TimeEfficiency)AS FLOAT) / CAST(SUM(T.StandardProduction)AS FLOAT)AS TotalEfficiency, 
            DM.IsPLCConnected AS IsPLCConnected, 
            DM.DispenserName, 
            ISNULL(SUM(CASE
                           WHEN @Regionid = 1 THEN ISNULL(t.MissedLoads, 0)
                           ELSE ROUND(ISNULL(t.MissedLoads, 0) * 0.453592, 0)
                       END) / CASE
                                  WHEN MAX(t.MaxLoad) = 0 THEN 1
                                  ELSE MAX(t.MaxLoad)
                              END, 0)AS LostBatches INTO
            #MachineEfficiency
        FROM @Dashboardmachinemapping AS DM
             LEFT JOIN #BatchEfficiency AS t ON DM.GroupID = t.GroupId
                                            AND dm.WasherId = t.MachineId
        GROUP BY
            DM.GroupID, 
            DM.WasherId, 
            DM.WasherNumber, 
            DM.WasherName, 
            DM.IsPLCConnected, 
            DM.DispenserName;

   --select * FROM #BatchEfficiency order by 1
    --select * FROM dbo.#MachineEfficiency me


    INSERT INTO @Alarmbymachine(
            GroupID, 
            WasherID, 
            Alarm, 
            AlarmDescription)
    SELECT
            AlarmByMachine.GroupID, 
            AlarmByMachine.WasherID, 
            AlarmByMachine.Alarm, 
            AlarmByMachine.AlarmDescription
        FROM(SELECT DISTINCT
                     AD.IsActive AS Alarm,
                     --Made AlarmDesc to NULL as it is not required anywhere in dashboard, need to see if it is needed
                     NULL AS AlarmDescription,
                     MS.WasherId AS WasherID,
                     MS.GroupId AS GroupID
                 FROM TCD.AlarmData AS AD
                      INNER JOIN @Dashboardmachinemapping AS D ON D.ControllerId = AD.controllerid
                      INNER JOIN TCD.MachineSetup AS MS ON D.WasherId = MS.WasherId
                                                       AND MS.ControllerId = AD.ControllerId
                                                       AND MS.IsDeleted = 0
                 WHERE(AD.MachineId = D.washerid
                    OR AD.ControllerId = D.ControllerId)
                  AND AD.IsActive = 1
                  AND ISNULL(AD.MachineId, 0) = CASE
                                                    WHEN AD.MachineId IS NOT NULL THEN D.WasherId
                                                    ELSE 0
                                                END)AS AlarmByMachine;
    INSERT INTO @Batchendtimes(
            GroupID, 
            WasherID, 
            CurrentBatchEndTime, 
            BatchEndTime)
    SELECT
            d.GroupID, 
            d.WasherId, 
            COUNT(CASE
                      WHEN bd.EndDate IS NULL THEN 1
                      ELSE NULL
                  END)AS CurrentBatchEndTime, 
            CAST(MAX(bd.EndDate)AS TIME)AS BatchEndTime
        FROM @Dashboardmachinemapping AS d
             INNER JOIN TCD.BatchData AS bd ON d.GroupID = bd.GroupId
                                           AND d.WasherId = bd.MachineId
        WHERE bd.ShiftId IN(SELECT
                                    ShiftId FROM @Shiftids)
        GROUP BY
            d.GroupID, 
            d.WasherId;
    SELECT
            @Standardturntime = ISNULL(ConStdTurnTime, 30)FROM tcd.Plant;
    SELECT
            @Standardturntime = @Standardturntime + ISNULL(TargetTurnTime, 0)
        FROM tcd.Washer
        WHERE WasherId = @Washerid;
    SELECT
            @Machinenamedispalytype = ISNULL(MachineNameDispalyType, 0)
        FROM TCD.Dashboard AS D
        WHERE D.DashboardId = @Dashboardid;
    INSERT INTO @Summarizeddata(
            GroupId, 
            MachineId, 
            WasherName, 
            WasherNumber, 
            TargetLoad, 
            ActualLoad, 
            LoadEfficiency, 
            TimeEfficiency, 
            LostLoad, 
            Alarm, 
            AlarmDescription, 
            WasherStatus, 
            MachineNameDispalyType, 
            TargetTurnTime, 
            DefaultIdleTime, 
            IsPLCConnected, 
            DispenserName, 
            LostBatches, 
            OverAllEfficiency)
    SELECT
            me.GroupID, 
            me.MachineID, 
            me.WasherName, 
            me.WasherNumber, 
            me.StandardProduction AS TargetLoad, 
            me.ActualProduction AS ActulaLoad, 
            me.LoadEfficiency, 
            me.TimeEfficiency, 
            me.MissedLoads AS LostLoad, 
            ISNULL(abm.Alarm, 0)AS Alarm, 
            abm.AlarmDescription, 
            CASE
                WHEN be.CurrentBatchEndTime = 1 THEN 1
                WHEN CAST(GETUTCDATE()AS TIME)BETWEEN be.BatchEndTime AND DATEADD(Minute, @Standardturntime, be.BatchEndTime)THEN 2
                WHEN abm.Alarm = 1 THEN 3
                ELSE 3
            END AS WasherStatus, 
            @Machinenamedispalytype, 
            (SELECT
                     TargetTurnTime FROM TCD.WASHER AS W WHERE W.WasherId = ME.MachineID), 
            (SELECT
                     DefaultIdleTime FROM TCD.WASHER AS W WHERE W.WasherId = ME.MachineID), 
            me.IsPLCConnected, 
            me.DispenserName, 
            me.LostBatches, 
            me.TotalEfficiency
        FROM #MachineEfficiency AS me
             LEFT JOIN @Alarmbymachine AS abm ON ME.GroupID = abm.GroupID
                                             AND ME.MachineID = ABM.WasherID
             LEFT JOIN @Batchendtimes AS be ON me.GroupID = be.GroupID
                                           AND me.MachineID = be.WasherID;

    DECLARE @Avg_Efficiency INT;
    WITH CTE_Avg_Efficiency
        AS (SELECT
                SUM(CASE
                        WHEN @Regionid = 1 THEN ISNULL(TargetLoad, 0)
                        ELSE ROUND(ISNULL(TargetLoad, 0) * 0.453592, 0)
                    END * OverAllEfficiency) / SUM(CASE
                                                       WHEN @Regionid = 1 THEN ISNULL(TargetLoad, 0)
                                                       ELSE ROUND(ISNULL(TargetLoad, 0) * 0.453592, 0)
                                                   END)AS AVG_EFF
            FROM @Summarizeddata)
        SELECT
                @Avg_Efficiency = AVG_EFF FROM CTE_Avg_Efficiency;

    SELECT
            A.GroupId, 
            A.MachineId, 
            CASE @Machinenamedispalytype
                WHEN 0 THEN CAST(WasherNumber AS VARCHAR(20)) + ' ' + WasherName
                WHEN 1 THEN WasherName
                WHEN 2 THEN CAST(WasherNumber AS VARCHAR(20))
            END AS WasherName, 
            WasherNumber, 
            CASE
                WHEN @Regionid = 1 THEN ISNULL(TargetLoad, 0)
                ELSE ROUND(ISNULL(TargetLoad, 0) * 0.453592, 0)
            END AS TargetLoad, 
            CASE
                WHEN @Regionid = 1 THEN ISNULL(ActualLoad, 0)
                ELSE ROUND(ISNULL(ActualLoad, 0) * 0.453592, 0)
            END AS ActualLoad, 
            A.LoadEfficiency, 
            TimeEfficiency, 
            CASE
                WHEN @Regionid = 1 THEN ISNULL(LostLoad, 0)
                ELSE ROUND(ISNULL(LostLoad, 0) * 0.453592, 0)
            END AS LostLoad, 
            Alarm, 
            AlarmDescription, 
            WasherStatus, 
            TargetTurnTime, 
            DefaultIdleTime, 
            IsPLCConnected, 
            DispenserName, 
            CASE
                WHEN ISNULL(LostBatches, 0) < 0 THEN 0
                ELSE LostBatches
            END AS LostBatches, 
            @Avg_Efficiency AS AverageEfficiency, 
            CAST(ISNULL(B.LoadEfficiency, 0)AS INT)AS CurBatchLoadEff
        FROM @Summarizeddata AS A
             LEFT JOIN #CurrBatch_LEfficiency_PerMachine AS B ON A.GroupId = B.GroupID
                                                             AND A.MachineId = B.MachineID
        ORDER BY
            WasherNumber;  
 
    ---- CleanUp  
    DROP TABLE
            #BatchData;
    DROP TABLE
            #BatchEfficiency;
    DROP TABLE
            #MachineEfficiency;
    DROP TABLE
            #CurrBatch_LEfficiency_PerMachine;
END;
