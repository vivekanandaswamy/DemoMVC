﻿/*                                           
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_DeleteWasherGroupFormula]                                             

Purpose:				To dissociate a WasherGroup and a Formula

Parameters:             @EcoLabAccountNumber - param which holds the ecolab account number.
						@WasherGroupId - holds the washer group Id.
						@ProgramSetupId - holds the program setup Id.
						@UserId - holds the user Id.

###################################################################################################                                           
*/

CREATE	PROCEDURE	[TCD].[DeleteWasherGroupFormula]
					@EcoLabAccountNumber					NVARCHAR(25)
				,	@WasherGroupId							INT
				,	@ProgramSetupId							SMALLINT
				,	@UserId									INT
				,	@OutputProgramSetupId						INT							=	NULL	OUTPUT
				,	@LastModifiedTimestampAtCentral			DATETIME					=	NULL
				,	@OutputLastModifiedTimestampAtLocal		DATETIME					=	NULL	OUTPUT
AS
BEGIN

SET	NOCOUNT	ON


DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()											--SQLEnlight SA0004

	--,	@WasherGroupNumber				VARCHAR(10)		=			NULL
	--,	@WasherGroupName				NVARCHAR(50)	=			NULL													--SQLEnlight SA0004
	--,	@WasherGroupTypeId				TINYINT			=			NULL
	,	@WasherGroupTypeName			VARCHAR(30)		=			NULL
	 ,	 @ControllerID								INT						=	 NULL
    ,	 @ControllerModelID							INT						=	 NULL

DECLARE
			@OutputList								AS	TABLE		(
			OutputProgramSetupId					INT
		,	LastModifiedTimestamp					DATETIME
		)

SET		@OutputLastModifiedTimestampAtLocal			=			ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight SA0121
SET		@OutputProgramSetupId						=			ISNULL(@OutputProgramSetupId, NULL)							--SQLEnlight SA0121

SELECT		@ControllerID			=		wg.ControllerId 
	FROM	TCD.WasherGroup			wg
	WHERE   wg.WasherGroupId		=		@WasherGroupId
AND			wg.EcolabAccountNumber	=		@EcoLabAccountNumber

SELECT		@ControllerModelID		=		cc.ControllerModelId
	FROM	TCD.ConduitController	cc
	WHERE	cc.ControllerId			=		@ControllerID
AND			cc.EcoalabAccountNumber =		@EcoLabAccountNumber


--Determine the WasherGroup type - Conventional/Tunnel
SELECT	/*@WasherGroupTypeId			=			WGT.WasherGroupTypeId													--SQLEnlight SA0004
	,	*/@WasherGroupTypeName		=			WGT.WasherGroupTypeName
	--,	@WasherGroupNumber			=			WG.WasherGroupNumber														--SQLEnlight SA0004
FROM	[TCD].WasherGroup					WG
JOIN	[TCD].WasherGroupType				WGT
	ON	WG.WasherGroupTypeId		=			WGT.WasherGroupTypeId
JOIN	[TCD].MachineGroup					GT
	ON	WG.WasherGroupId			=			GT.Id
WHERE	GT.EcolabAccountNumber		=			@EcoLabAccountNumber
	AND	WG.WasherGroupId			=			@WasherGroupId

IF	(	@WasherGroupTypeName		IS			NULL)
	BEGIN
			SET		@ErrorId		=			51000
			SET		@ErrorMessage	=			N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Could not determine the WasherGroup Type... Aborting.'
			--GOTO	ErrorHandler
			RAISERROR	(@ErrorMessage, 16, 1)
			SET	@ReturnValue	=	-1
			RETURN	(@ReturnValue)
	END


IF	(	@WasherGroupTypeName	=	'Tunnel'	)
	BEGIN
		--Soft-delete the record
		IF	(
									@LastModifiedTimestampAtCentral				IS NOT	NULL
									AND
									NOT	EXISTS	(	SELECT	1
											FROM	TCD.TunnelProgramSetup		TPS
											WHERE	TPS.EcolabAccountNumber		=	@EcolabAccountNumber
												AND	TPS.TunnelProgramSetupId	=	@ProgramSetupId
												AND	TPS.LastModifiedTime		=	@LastModifiedTimestampAtCentral
										)
							)
								BEGIN
										SET			@ErrorId				=	60000
										SET			@ErrorMessage			=	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
										RAISERROR	(@ErrorMessage, 16, 1)
										SET			@ReturnValue			=	-1
										RETURN		(@ReturnValue)
								END
		UPDATE	TPS
			SET	Is_Deleted					=			'TRUE'
			,	LastModifiedByUserId		=			@UserId
			,	LastModifiedTime			=			@CurrentUTCTime
			OUTPUT
				inserted.TunnelProgramSetupId					AS			Id
				,	inserted.LastModifiedTime					AS			LastModifiedTimestamp
			INTO
					@OutputList	(
									OutputProgramSetupId
								,	LastModifiedTimestamp
								)
		FROM	[TCD].TunnelProgramSetup			TPS
		WHERE	TPS.WasherGroupId			=			@WasherGroupId
			AND	TPS.EcolabAccountNumber		=			@EcoLabAccountNumber
			AND	TPS.TunnelProgramSetupId	=			@ProgramSetupId
			AND	TPS.Is_Deleted				=			'FALSE'
		
		--check for any error
		SET	@ErrorId	=	@@ERROR
	
		IF	(@ErrorId	<>	0)
			BEGIN
					SET		@ErrorMessage	=			N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred dissociating formula for the tunnel washer group.'
					--GOTO	ErrorHandler
					RAISERROR	(@ErrorMessage, 16, 1)
					SET	@ReturnValue	=	-1
					RETURN	(@ReturnValue)
			END
	END
ELSE	IF	(	@WasherGroupTypeName	=	'Conventional'	)
			BEGIN
				--Soft-delete the record
				
				IF	(
									@LastModifiedTimestampAtCentral				IS NOT	NULL
									AND
									NOT	EXISTS	(	SELECT	1
											FROM	TCD.WasherProgramSetup		WPS
											WHERE	WPS.EcolabAccountNumber		=	@EcolabAccountNumber
												AND	WPS.WasherProgramSetupId	=	@ProgramSetupId
												AND	WPS.LastModifiedTime		=	@LastModifiedTimestampAtCentral
										)
							)
								BEGIN
										SET			@ErrorId				=	60000
										SET			@ErrorMessage			=	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
										RAISERROR	(@ErrorMessage, 16, 1)
										SET			@ReturnValue			=	-1
										RETURN		(@ReturnValue)
								END

				IF @ControllerModelID = 7 -- MyControl
				BEGIN
					SET @WasherGroupId = NULL
				END

				UPDATE	WPS
					SET	Is_Deleted					=			'TRUE'
					,	LastModifiedByUserId		=			@UserId
					,	LastModifiedTime			=			@CurrentUTCTime
					OUTPUT
					inserted.WasherProgramSetupId					AS			Id
				,	inserted.LastModifiedTime					AS			LastModifiedTimestamp
			INTO
					@OutputList	(
									OutputProgramSetupId
								,	LastModifiedTimestamp
								)
				FROM	[TCD].WasherProgramSetup			WPS
				WHERE	(CASE WHEN @WasherGroupId IS NOT NULL 
						  THEN WPS.WasherGroupId
						  ELSE WPS.ControllerID
						END)						=		(CASE WHEN @WasherGroupId IS NOT NULL 
																	THEN @WasherGroupId
																	ELSE @ControllerID
																	END)
					AND	WPS.EcolabAccountNumber		=			@EcoLabAccountNumber
					AND	WPS.WasherProgramSetupId	=			@ProgramSetupId
					AND	WPS.Is_Deleted				=			'FALSE'
		
				--check for any error
				SET	@ErrorId	=	@@ERROR
	
				IF	(@ErrorId	<>	0)
					BEGIN
							SET		@ErrorMessage	=			N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred dissociating formula for the conventional washer group.'
							--GOTO	ErrorHandler
							RAISERROR	(@ErrorMessage, 16, 1)
							SET	@ReturnValue	=	-1
							RETURN	(@ReturnValue)
					END
					
			END


SELECT	TOP 1	
		@OutputLastModifiedTimestampAtLocal		=	O.LastModifiedTimestamp
	,	@OutputProgramSetupId					=	O.OutputProgramSetupId
FROM	@OutputList							O


IF	(	@ErrorId	=	0	)
	BEGIN
		--GOTO	ExitModule
		RETURN	(@ReturnValue)
	END




--ErrorHandler:
--RAISERROR	(@ErrorMessage, 16, 1)
--SET	@ReturnValue	=	-1




--ExitModule:



RETURN	(@ReturnValue)

--SET	NOCOUNT	OFF
--RETURN	(@ReturnValue)


END