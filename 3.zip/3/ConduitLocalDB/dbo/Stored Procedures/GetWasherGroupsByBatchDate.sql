CREATE PROCEDURE [TCD].[GetWasherGroupsByBatchDate] 
(
  @BatchDate DATETIME ,
  @EcolabAccountNumber NVARCHAR(25) 
)
AS 
  BEGIN
  SET NOCOUNT ON

  SET   @EcolabAccountNumber   =   ISNULL(@EcolabAccountNumber, NULL)   --SQLEnlight SA0029

   SELECT 
    Distinct B.GroupId,
    GT.GroupDescription
      FROM   
    [TCD].MachineGroup GT
    INNER JOIN [TCD].BatchData B ON B.GroupId = GT.Id
   WHERE 
     CAST(B.StartDate AS DATE) = CAST(@BatchDate AS DATE)
    
  SET NOCOUNT OFF
  END