﻿/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_GetManualLaborDetails]                                         

Purpose:				To Save The manual labor details.

Parameters:				@RegionId - holds the location Id.
						@EcolabAccountNumber - holds the ecolab account number.
																												
###################################################################################################                                           
*/

CREATE PROCEDURE [TCD].[GetManualLaborDetails] 
(
				@LocationId int = NULL,
				@ManHourTypeId Int = NULL,
				@EcolabAccountNumber nvarchar(25)
)
AS
BEGIN
SET NOCOUNT ON


  SELECT TOP 1	 ML.Id					AS		Id
				,ML.LocationId			AS		LocationId	
				,ML.ManHourTypeId		AS		ManHourTypeId
				,ML.StartDate			As		StartDate
				,ML.EndDate				AS		EndDate
				,ML.LaborCost			AS		LaborCost
				,ML.AllocatedManHours	AS		AllocatedManHours
				,ML.EcolabAccountNumber	AS		EcolabAccountNumber
  FROM			[TCD].ManualLabor ML
  WHERE 		ML.ManHourTypeId			=		@ManHourTypeId 
  AND			ML.LocationId				=		@LocationId 
  AND			ML.EcolabAccountNumber		=		@EcolabAccountNumber
  AND			ML.IsDeleted				=		'FALSE'
  ORDER BY		ML.StartDate DESC,ML.Id			DESC
	
SET NOCOUNT OFF
END