/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_SaveTankDetails]                                          

Purpose:				To save the tank details.

Parameters:				@TankName - holds the tank name.
						@EcoLabAccountNumber - holds the ecolab account number.
						@LowAlarmLevel	- holds the alarm value for low level.
						@Size - holds the tank size.
						@LevelDeviation - holds the deviation level.
						@ControllerId - holds the controller id.
						@EmptyLevel	- holds the empty level value.
						@CalibrationLevel - holds the caribration level.
						@InputType - holds the input type.
						@ProductId - holds the product id.
						@UserId - holds the user id.
						@LowAlarmLevel_Display decimal = null,
						@EmptyLevel_Display decimal = null,
						@CalibrationLevel_Display decimal = null,
						@CurrentLevel_Display decimal = null,
						@LevelDeviation_Display decimal = null,
						@Size_Display decimal = null
																						
###################################################################################################                                           
*/
CREATE PROCEDURE [TCD].[SaveTankDetails] (
	      @TankName				nvarchar(100)= NULL,
				@EcoalabAccountNumber	nvarchar(25),
				@LowAlarmLevel			decimal(18,2)	= NULL,
				@Size					decimal	= NULL,
				@LevelDeviation			decimal	= NULL,
				@ControllerId			int		= NULL,
				@EmptyLevel				decimal(18,2)	= NULL,
				@CalibrationLevel		decimal(18,2)	= NULL,
				@InputType				nvarchar(100)= NULL,
				@ProductId				INT=NULL,
				@UserId	int=NULL,
				@CurrentLevel			decimal	= NULL,
				@SizeAddress			nvarchar(50) = NULL,
				@DeviationAddress		nvarchar(50) = NULL,
				@LevelAddress			nvarchar(50) = NULL
				--Adding these 2 params as part of re-factoring for integration with Synch/Configurator
				,@OutputTankId						INT						=	NULL	OUTPUT
				,@LastModifiedTimestampAtCentral			DATETIME				=	NULL
				,@OutputLastModifiedTimestampAtLocal		DATETIME				=	NULL	OUTPUT,
				-- Adding these params for UOM Conversions
				@LowAlarmLevel_Display decimal(18,2) = null,
						@EmptyLevel_Display decimal(18,2) = null,
						@CalibrationLevel_Display decimal(18,2) = null,
						@CurrentLevel_Display decimal(18,2) = null,
						@LevelDeviation_Display decimal(18,2) = null,
						@Size_Display decimal(18,2) = null
				)
AS 
  
  BEGIN 
      
	  SET NOCOUNT ON;

		  DECLARE	
			@Output							VARCHAR(100)	=			''  
		,	@ReturnValue					INT				=			0
		,	@ErrorId						INT				=			0
		,	@ErrorMessage					NVARCHAR(4000)	=			N''
		,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()

		DECLARE
				@OutputList						AS	TABLE		(
				TankId					INT
			,	LastModifiedTimestamp			DATETIME
			)

	  	SET			@LastModifiedTimestampAtCentral			=			ISNULL(@LastModifiedTimestampAtCentral, NULL)			--SQLEnlight SA0029

		IF ((select count(ControllerId) from TCD.TankSetup where ControllerId = @ControllerId and EcoalabAccountNumber = @EcoalabAccountNumber and Is_Deleted = 0) >= 8)
		BEGIN
				SET @ErrorMessage ='304 - Dispenser cannot have more than 8 Tanks'
				RAISERROR(@ErrorMessage, 16, 1)
				RETURN
		END

	  IF EXISTS (SELECT 1 FROM [TCD].TankSetup WHERE TankName=@TankName AND Is_Deleted=0)
	  BEGIN
			SET @ErrorMessage ='303 - Tank Name already exists.'
			RAISERROR(@ErrorMessage, 16, 1)
			RETURN
	  END

			
				
				BEGIN
					INSERT INTO [TCD].TankSetup 
						(
							TankName,
							EcoalabAccountNumber,
							SKU,
							LowAlarmLevel,
							PurchaseLevel,
							Size,
							LevelDeviation,
							CurrentLevel,
							ControllerId,
							Active,
							MENumber,
							EmptyLevel,
							CalibrationLevel,
							InputType,
							Is_Deleted,
							LastModifiedByUserId,
							LowAlarmLevel_Display ,
							EmptyLevel_Display ,
							CalibrationLevel_Display ,
							CurrentLevel_Display,
							LevelDeviation_Display,
							Size_Display
						) 
							OUTPUT
								inserted.TankId						AS			Id
							,	inserted.LastModifiedTime			AS			LastModifiedTimestamp
							
							INTO
									@OutputList	(
										TankId
									,	LastModifiedTimestamp
									)   
							SELECT  @TankName,
									@EcoalabAccountNumber,
									pdm.SKU,
									@LowAlarmLevel,
									NULL,
									@Size,
									@LevelDeviation,
									@CurrentLevel,
									@ControllerId,
									NULL,
									NULL,
									@EmptyLevel,
									@CalibrationLevel,
									@InputType,
									0,
									@UserId,
									@LowAlarmLevel_Display ,
									@EmptyLevel_Display,
									@CalibrationLevel_Display,
									@CurrentLevel_Display,
									@LevelDeviation_Display,
									@Size_Display
		
		FROM [TCD].ProductdataMapping pdm WHERE pdm.ProductID=@ProductId

				

		END

				SELECT	TOP 1	
						@OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp
					,	@OutputTankId				=	O.TankId
				FROM	@OutputList							O


				RETURN	(@ReturnValue)
       --SET NOCOUNT OFF;
  END