﻿/*      
 ==========================================================================================    
 Purpose:  Insert or Update Production details .      
  
 Author:  Neetha Allati     
  
 --------------------------------------------------------------      
 Sep-26-2014 ENT: Initial version.      
 ==========================================================================================    
*/  

CREATE PROCEDURE [TCD].[SaveManualProduction]
 ( 			
			 @WasherId  INT,  
			 @FormulaId  INT,  
			 @RecordedDate DATETIME,
			 @Value DECIMAL(18, 0),
			 @EcolabAccountNumber NVARCHAR(25),   
			 @UserId  INT,
			 @Scope VARCHAR(100) OUTPUT,
    @OutputProductionId      INT     =   NULL OUTPUT    
)   
AS  
 
  BEGIN     
  SET NOCOUNT ON
  DECLARE @WasherGroupId INT;  
  SET @WasherGroupId =  (SELECT GroupID FROM TCD.MACHINESETUP WHERE WasherId = @WasherId)  
  DECLARE
  @OutputList     AS TABLE  (    
  ProductionId       INT    
	)
			 		  INSERT INTO [TCD].ManualProduction(
																WasherGroupId,
																WasherId,
																FormulaId,
																RecordedDate,
																Value,
																EcolabAccountNumber,
																LastModifiedByUserId
													  )
						OUTPUT
         inserted.ProductionId      AS   ProductionId    
						INTO @OutputList
									(ProductionId)
												VALUES(
																@WasherGroupId,
																@WasherId, 
																@FormulaId,
																@RecordedDate,
																@Value,
																@EcolabAccountNumber,
																@UserID
													)      
  
							SET @Scope = '101' 		 
			 /*Added Code for Rollingup the manual data entered for particular day*/

							DECLARE @ManualRecordDate date 
							SELECT @ManualRecordDate = CASt(@RecordedDate AS date)

    EXEC [TCD].[SaveProductionShiftManualDataRollup]	@Date = @ManualRecordDate,    --'2015-05-26'
										@ManualData  = @Value,  --1000
										@WasherId  = @WasherId,	   --4
										@ProgramMasterId  =@FormulaId   --21	 
										

	SELECT	TOP 1	
				@OutputProductionId						=	O.ProductionId
		FROM	@OutputList									O
	SET NOCOUNT OFF		
END