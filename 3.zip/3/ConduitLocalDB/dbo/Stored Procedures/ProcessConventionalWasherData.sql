﻿CREATE PROCEDURE [TCD].[ProcessConventionalWasherData]
 ( 
 @WasherId INT, 
 @xmlTags XML,
 @RedFlagShiftId INT OUTPUT
)
AS
BEGIN
  DECLARE @BatchID        INT,
    @EcolabWasherId       INT,        
    @CurrencyCode       VARCHAR(50),  
    @MachineInternalId      INT,
    @GroupId        INT,  
    @Prveformula       INT,
    @Quantity        INT,
    @MaxWashertGroupCapacity    INT,

    @ProgramMasterId      INT,
    @NominalLoad       DECIMAL(10,2),
    @MaxLoad        DECIMAL(10,2),
    @StandardWeight       DECIMAL(10,2) ,     

    @CurrentFormula       INT,  
    @CurrentFormulaDate      DATETIME2,
    @FormulaIsModified      BIT,

    @CurrentInjection      INT,
    @CurrentInjectionDate     DATETIME2,
    @InjectionIsModified     BIT,

    @OperationalCount      INT,
    @OperationalIsModified     BIT, 
    
    @CurrentHoldSignal      INT,
    @CurrentHoldSignalDate     DATETIME2,
    @HoldSignalIsModified     BIT,  
             
    @EndofFormula       INT, 
    @EndofFormulaDate      DATETIME2,
    
    @AutoWeightEntryActive     BIT,
    @AutoWeightEntryWeight     DECIMAL(10,2),                                                                                                                              
    @ControllerId       INT,
    @CurrentHoldSignalValue     INT ,
    
    @MeterPlcAddress      INT,
    @MeterPlcAddressIsModified    INT,
    @BatchGroupId       INT,
    @BatchFormula       INT,    
    @HoldTime        INT,
   @CteTempPLCInjections INT,
   @CteTempenVisionInjections INT,
    @BatchStandardWaterUsage    INT,
    @BatchActualWaterUsage     INT,
    @BatchWaterUsagePrice     Decimal(10,2),
    @BatchUtilityPrice      Decimal(10,2),
    @BatchWaterType       INT,
    @PrevGroupId       INT,
    @WasherMeterExists      BIT,
    @ExtraTime        INT,
    @TargetTurnTime       INT,
    @RatioDosingEnabled      BIT,
 @EcolabAccountNumber NVARCHAR(25) = NULL,
 @PreviousFormulaDate      DATETIME2,
 @PreviousInjectionStep INT,
 @PreviousInjectionStartDate DATETIME2,
 @CurrentInjectionStep INT,
 @WashStepBatchId INT,
 @PrevFormulaExtraTime INT      ,
 @AlarmGroupMasterId INT,
 @StdWashSteps INT,
    @StdInjectionSteps INT,
 @EcolabTextileCategoryId INT,
 @ChainTextileCategoryId INT,
 @FormulaSegmentId INT,
 @EcolabSaturationId INT,
 
 @PreviousShiftId INT,
 @CurrentShiftId INT,                                                                                                              
 @PlantProgramId INT,
 @ETechLastDroppedAt  DATETIME2 ,
 @HoldTimePartitionOn datetime2,
 @CustomerCodes VARCHAR(100),
 @IsExtractTimeForEOFSignal INT,
 @EOFDateTime  DATETIME2,
 @PrevEOFDateTime DATETIME2,  
 @DrainStepTypeId  INT,
 @ExtractStepTypeId INT


  SET @RedFlagShiftId = NULL
      
  IF EXISTS (SELECT  * FROM [TEMPDB].[DBO].[SYSOBJECTS] o where o.xtype in ('U') AND o.id = OBJECT_ID(N'tempdb..#XmlTagsTable'))
   BEGIN
     DROP TABLE #XmlTagsTable
   END


  CREATE TABLE  #XmlTagsTable ( TagId INT, 
          TagValue NVARCHAR(100), 
          ReceivedTime DATETIME2,
          TagType NVARCHAR(50),
          IsModified BIT,
          ETechLastDropped VARCHAR(100),
          CustomerCodes VARCHAR(100)
         )

 
  INSERT INTO #XmlTagsTable (
          TagId,
          TagValue,
          ReceivedTime,
          TagType,
          IsModified,
          ETechLastDropped,
          CustomerCodes
         )   
  
  SELECT   
     T.c.value('@TagId', 'INT') as TagId,
     T.c.value('@Value', 'NVARCHAR(100)') TagValue,
     T.c.value('@TimeStamp', 'VARCHAR(100)') DateTimeStamp,
     T.c.value('@TagType', 'VARCHAR(50)') TagType,
     T.c.value('@IsModified', 'BIT') TagType,
     T.c.value('@ETechLastDroppedAt', 'VARCHAR(100)') ETechLastDropped,
     T.c.value('@CustomerCodes', 'VARCHAR(100)') CustomerCodes
  FROM  @xmlTags.nodes('Tags/Tag') T(c)
  WHERE 
     T.c.value('@TagId', 'varchar(100)')  IS NOT NULL
 
  SELECT @CurrentFormula     =  TagValue,  
    @CurrentFormulaDate    =  ReceivedTime,
    @FormulaIsModified     =  IsModified
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_FRM'   
     
  SELECT @CurrentInjection    =  TagValue,
    @CurrentInjectionDate   =  ReceivedTime,
    @InjectionIsModified   =  IsModified   
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_INJ'

  SELECT @OperationalCount    =  TagValue,
    @OperationalIsModified   =  IsModified  
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_OPC'  
   
  SELECT @EndofFormula     =  TagValue,
    @EndofFormulaDate    =  ReceivedTime  
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_EOF' 
  
  SELECT @AutoWeightEntryActive   =  TagValue     
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_AWEA'                 

  SELECT @CurrentHoldSignal    =  TagValue, 
    @HoldSignalIsModified   =  IsModified,  
    @CurrentHoldSignalDate   =  ReceivedTime 
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_HOLDL'

  SELECT @AutoWeightEntryWeight   =  TagValue,
   @ETechLastDroppedAt    =  CONVERT(datetime,ETechLastDropped),
   @CustomerCodes   = CustomerCodes
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_AWEW'

  SELECT @MeterPlcAddress    =  TagValue,
    @MeterPlcAddressIsModified  =       IsModified       
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_MPLC'
  
  SELECT @RatioDosingEnabled    =  TagValue      
  FROM #XmlTagsTable 
  WHERE TagType       =  'Tag_RATA'
  
  SELECT * FROM #XmlTagsTable
  
  SELECT @ExtraTime      =  0

  SELECT TOP 1 @BatchID=BatchId, @Prveformula=ProgramNumber,@PrevGroupId=GroupId, @PreviousFormulaDate=StartDate FROM TCD.BatchData WHERE MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC

  IF(@PreviousFormulaDate is NOT NULL)
  BEGIN
 IF(@CurrentFormulaDate < @PreviousFormulaDate)
 BEGIN
  return
 END
  END

  IF(@CurrentFormula != @EndofFormula AND
     @CurrentFormula = @Prveformula AND 
  @CurrentInjection = 0 AND
  @OperationalCount = 0 AND
  @CurrentFormulaDate <= @PreviousFormulaDate AND
  @CurrentInjectionDate > @PreviousFormulaDate)
 BEGIN
 --Here means, If the same formula is received without EOF then the timestamp of the formula
 --will be still the old timestamp because value is not changed.
 --In this case assign injection=0 timestamp to formula timestamp
  SELECT @CurrentFormulaDate = @CurrentInjectionDate 
 END

  DECLARE @ShiftStartDate table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
  INSERT INTO @ShiftStartDate(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate

  SELECT DISTINCT 
     @EcolabWasherId    =  Ws.EcolabWasherId,
     @StandardWeight    =  Wps.NominalLoad,
     @CurrencyCode    =  Pl.CurrencyCode,
     @ControllerId    =  Ctrl.ControllerId,
     @TargetTurnTime    =  Ws.TargetTurnTime * 60,
  @IsExtractTimeForEOFSignal= ws.ExtractTimeForEOFSignal
  FROM 
     TCD.Washer Ws  
  INNER JOIN 
     TCD.MachineSetup Mst ON
     Mst.WasherId    =  Ws.WasherId
  INNER JOIN 
     TCD.WasherGroup Wg ON 
     Wg.WasherGroupId   =  Mst.GroupId    
  INNER JOIN 
     TCD.WasherProgramSetup Wps ON 
     Wps.WasherGroupId   =  Wg.WasherGroupId
  LEFT JOIN 
     TCD.WasherDosingSetup Wds ON 
     Wds.WasherProgramSetupId =  Wps.WasherProgramSetupId
  LEFT JOIN 
     TCD.WasherDosingProductMapping Wdpm ON 
     Wdpm.WasherDosingSetupId =  Wds.WasherDosingSetupId
  INNER JOIN 
     TCD.Plant Pl ON 
     Pl.EcolabAccountNumber  =  Ws.EcoLabAccountNumber
  INNER JOIN 
    TCD.ConduitController Ctrl 
    ON Ctrl.ControllerId   =  Mst.ControllerId 
  WHERE Ws.WasherId= @WasherId

  SELECT DISTINCT 
     @MachineInternalId=Mst.MachineInternalId,
     @GroupId=Mst.GroupId     
  FROM TCD.Washer Ws
      INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
      INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
      INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
   WHERE Ws.WasherId=@WasherId  

   SELECT DISTINCT      
     @ProgramMasterId=Wps.ProgramId,
     @NominalLoad=Wps.NominalLoad, --Wps.NominalLoad/CONVERT(decimal(10,2), 100) old code
     @MaxLoad =Ws.MaxLoad
     --@ExtraTime =Wps.ExtraTime
  FROM TCD.Washer Ws
      INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
      INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
      INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
      INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
   WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@CurrentFormula and Wps.Is_Deleted=0
   -----Current Formula Extratime
   CREATE TABLE  #ExtratimeTable ( Runtime INT,StepTypeId INT,StepNumber INT)
  INSERT INTO #ExtratimeTable (Runtime,StepTypeId,StepNumber)   
SELECT TOP 2 StepRunTime,StepTypeId,StepNumber FROM tcd.WasherDosingSetup wds
INNER JOIN TCD.WasherProgramSetup Wps ON wds.WasherProgramSetupId=wps.WasherProgramSetupId
 WHERE Wps.WasherGroupId =@GroupId and Wps.ProgramNumber=@CurrentFormula
 AND Wps.Is_Deleted=0 AND wds.Is_Deleted=0 ORDER  BY StepNumber DESC

 SELECT TOP 1 @DrainStepTypeId=StepTypeId  FROM #ExtratimeTable
  IF(@DrainStepTypeId<>47 )
 BEGIN
SET  @DrainStepTypeId=0;
 END
 SELECT TOP 1 @ExtractStepTypeId=StepTypeId  FROM #ExtratimeTable WHERE StepTypeId in(58,77,82,85,92) ORDER  BY StepNumber  DESC
  
  IF(ISNULL(@DrainStepTypeId,0)>0 AND ISNULL(@ExtractStepTypeId,0)>0) 
 BEGIN
  select @ExtraTime=SUM(Runtime) from #ExtratimeTable
 END
 ELSE IF(ISNULL(@ExtractStepTypeId,0)>0  AND ISNULL(@DrainStepTypeId,0)=0)
 BEGIN
 SELECT TOP 1 @ExtraTime=Runtime  FROM #ExtratimeTable WHERE StepTypeId in(58,77,82,85,92) ORDER  BY StepNumber  DESC
 END
  DROP TABLE #ExtratimeTable

  if(@ExtraTime IS NULL)
  BEGIN
   SELECT @ExtraTime      =  0
  END
    ----------Previous FormulaExtraTime.
 CREATE TABLE  #PrevFormulaExtraTimeTable ( Runtime INT,StepTypeId INT,StepNumber INT)
  INSERT INTO #PrevFormulaExtraTimeTable (Runtime,StepTypeId,StepNumber)   
 SELECT TOP 2 StepRunTime,StepTypeId,StepNumber  FROM tcd.WasherDosingSetup wds
INNER JOIN TCD.WasherProgramSetup Wps ON wds.WasherProgramSetupId=wps.WasherProgramSetupId
 where Wps.WasherGroupId =@PrevGroupId and Wps.ProgramNumber=@Prveformula
 and Wps.Is_Deleted=0 and wds.Is_Deleted=0 ORDER  BY StepNumber DESC
 SET @DrainStepTypeId=0;
 SET @ExtractStepTypeId=0;
SELECT TOP 1 @DrainStepTypeId=StepTypeId  FROM #PrevFormulaExtraTimeTable
 IF(@DrainStepTypeId<>47 )
 BEGIN
SET  @DrainStepTypeId=0;
 END
 SELECT TOP 1 @ExtractStepTypeId=StepTypeId FROM #PrevFormulaExtraTimeTable WHERE StepTypeId in(58,77,82,85,92) ORDER  BY StepNumber  DESC

  IF(ISNULL(@DrainStepTypeId,0)>0 AND ISNULL(@ExtractStepTypeId,0)>0) 
 BEGIN
   SELECT @PrevFormulaExtraTime=SUM(Runtime) from #PrevFormulaExtraTimeTable
 END
 ELSE IF(ISNULL(@ExtractStepTypeId,0)>0  AND ISNULL(@DrainStepTypeId,0)=0)
 BEGIN
  SELECT TOP 1 @PrevFormulaExtraTime=Runtime FROM #PrevFormulaExtraTimeTable WHERE StepTypeId in(58,77,82,85,92) ORDER  BY StepNumber  DESC
 END
 DROP TABLE #PrevFormulaExtraTimeTable
  IF(@PrevFormulaExtraTime IS NULL)
  BEGIN
   SELECT @PrevFormulaExtraTime      =  0
  END

  SELECT  @MaxWashertGroupCapacity=Max(ws.MaxLoad)
  FROM TCD.Washer WS
   INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
   INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId  
  WHERE Mst.GroupId=@GroupId

  SELECT @WasherMeterExists = M.MachineCompartment FROM Tcd.MachineSetup Ms
  INNER JOIN Tcd.Meter M ON M.GroupId= Ms.GroupId AND  M.MachineCompartment=Ms.MachineInternalId
  WHERE Ms.WasherId=@WasherId

  if(@AutoWeightEntryActive IS NULL)
  BEGIN
   SELECT @AutoWeightEntryActive = 0
  END

  SELECT @StandardWeight=(@NominalLoad * @MaxWashertGroupCapacity) /CONVERT(decimal(10,2), 100)   
  select @AutoWeightEntryActive,@StandardWeight
  SELECT @AutoWeightEntryWeight=Case @AutoWeightEntryActive WHEN 0 THEN @StandardWeight ELSE  @AutoWeightEntryWeight END  
  
  SELECT @CurrentHoldSignalValue=Id  FROM TCD.ConduitParameters where Name='HoldSignal'
  
   SELECT  * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC
  IF(@HoldSignalIsModified !=0)  
  BEGIN
  IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp =@CurrentHoldSignalDate)
   BEGIN
    INSERT INTO TCD.WasherReading(
         WasherId,
         ParameterId,
         ParameterValue,
         DateTimeStamp,
         PartitionOn,
         EcolabWasherId)
    SELECT    @WasherId,
         @CurrentHoldSignalValue,
         @CurrentHoldSignal,
         @CurrentHoldSignalDate,
         (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
         @EcolabWasherId
   END   
  END
  if(@IsExtractTimeForEOFSignal=1)
  BEGIN
 SET @EOFDateTime=DATEADD(second,@ExtraTime,@CurrentFormulaDate);
 SET @PrevEOFDateTime=DATEADD(second,@PrevFormulaExtraTime,@CurrentFormulaDate); 
  END
  ELSE
  BEGIN
  SET @EOFDateTime=@CurrentFormulaDate;
  SET @PrevEOFDateTime=@CurrentFormulaDate;
  END
  IF(@FormulaIsModified =1  OR @InjectionIsModified = 1 OR @OperationalIsModified = 1)
  BEGIN
   SELECT 'IsModified',@FormulaIsModified AS FormulaIsModified, 
        @InjectionIsModified AS InjectionIsModified,
        @OperationalIsModified AS OperationalIsModified
   IF(@CurrentFormula != 0)
   BEGIN
       DECLARE @BatchShiftId int,@BatchShiftStartDate datetime
       
       SELECT @BatchShiftStartDate = bd.StartDate FROM TCD.BatchData bd WHERE bd.BatchId = @BatchId

       IF(@BatchShiftStartDate > (SELECT TOP 1 [@ShiftStartDate].ShiftStartdate FROM @ShiftStartDate ORDER BY [@ShiftStartDate].ShiftStartdate ASC)
       AND @EOFDateTime> (SELECT TOP 1 [@ShiftStartDate].ShiftStartdate FROM @ShiftStartDate ORDER BY [@ShiftStartDate].ShiftStartdate DESC)
       )
       BEGIN 
         
         SELECT TOP 1  @BatchShiftId = ssdt.ShiftId FROM @ShiftStartDate ssdt ORDER BY ssdt.ShiftStartdate DESC
       END
       ELSE
       BEGIN
        SELECT TOP 1  @BatchShiftId = ssdt.ShiftId FROM @ShiftStartDate ssdt ORDER BY ssdt.ShiftStartdate ASC
       END
       

  --SELECT DISTINCT      
  -- @PrevFormulaExtraTime =Wps.ExtraTime
  -- FROM TCD.Washer Ws
  --  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
  --  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
  --  INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
  --  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
  --  WHERE Ws.WasherId=@WasherId and Wps.ProgramNumber=@Prveformula and Wps.Is_Deleted=0



 SELECT Top 1 @HoldTimePartitionOn=ShiftStartdate from @ShiftStartDate

     IF(@CurrentFormula = @EndofFormula)
     BEGIN   
     SELECT * FROM #XmlTagsTable
      IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData 
           WHERE 
           BatchId=@BatchId AND 
           MachineId=@WasherId AND 
           EndDate IS NULL 
           ORDER BY StartDate DESC  )
       BEGIN
                                       
        UPDATE TCD.BatchData 
         SET EndDate = @PrevEOFDateTime,EndDateFormula = @CurrentFormulaDate,ShiftId = @BatchShiftId,SyncReady=1
       WHERE  BatchId = @BatchId AND MachineId=@WasherId   
    
  EXEC TCD.UpdateBatchParameterHoldTime @BatchId, @PreviousFormulaDate, @CurrentFormulaDate, @WasherId, @HoldTimePartitionOn
    --DECLARE @ShiftMapping1 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
    --INSERT INTO @ShiftMapping1(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate,1, @RedFlagShiftId OUTPUT

    SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
      IF(@PreviousInjectionStep IS NOT NULL)
      BEGIN
       UPDATE TCD.BatchWashStepData SET EndTime=@EOFDateTime WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate
      END
                                                                   
       END 
     END 
     ELSE IF((@CurrentFormula != @Prveformula) AND (@BatchID IS NOT NULL))
     BEGIN  
     IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC  )
        BEGIN                          
         UPDATE TCD.BatchData
          SET EndDate = @CurrentFormulaDate,EndDateFormula = @CurrentFormulaDate,ShiftId = @BatchShiftId,SyncReady=1
         WHERE  BatchId = @BatchId AND MachineId=@WasherId  
   
  EXEC TCD.UpdateBatchParameterHoldTime @BatchId, @PreviousFormulaDate, @CurrentFormulaDate, @WasherId, @HoldTimePartitionOn

     INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,19,1,(SELECT Top 1 ShiftStartdate from @ShiftStartDate) 
     
   --  DECLARE @ShiftMapping2 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
   --INSERT INTO @ShiftMapping2(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentFormulaDate,1, @RedFlagShiftId OUTPUT
    
    SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
     IF(@PreviousInjectionStep IS NOT NULL)
     BEGIN
      UPDATE TCD.BatchWashStepData SET EndTime=@CurrentFormulaDate WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate
     END
       
        END 
      END
     ELSE IF((@CurrentInjection = 0) AND(@OperationalCount = 0) AND (@CurrentFormulaDate != @PreviousFormulaDate))
     BEGIN  
     IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NULL ORDER BY StartDate DESC)
        BEGIN                           
         UPDATE TCD.BatchData
          SET EndDate = @CurrentInjectionDate,ShiftId = @BatchShiftId,EndDateFormula = @CurrentInjectionDate,SyncReady=1
         WHERE  BatchId = @BatchId AND MachineId=@WasherId  
   
    EXEC TCD.UpdateBatchParameterHoldTime @BatchId, @PreviousFormulaDate, @CurrentFormulaDate, @WasherId, @HoldTimePartitionOn
    INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,19,1,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)

   -- DECLARE @ShiftMapping3 table(ShiftId INT,ShiftName nvarchar(50),ShiftStartdate Datetime)
   --INSERT INTO @ShiftMapping3(ShiftId,ShiftName,ShiftStartdate) exec TCD.GetShiftStartDate @CurrentInjectionDate,1, @RedFlagShiftId OUTPUT
      
   SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
     IF(@PreviousInjectionStep IS NOT NULL)
     BEGIN
      UPDATE TCD.BatchWashStepData SET EndTime=@CurrentInjectionDate WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate
     END

        END 
      END
   
    -- Hold Time
     --IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
     -- BEGIN

      
     -- SELECT   @HoldTime=SUM(Wr.ParameterValue) FROM TCD. BatchData Bd
     -- INNER JOIN TCD.WasherReading Wr ON Wr.WasherId=Bd.MachineId
     -- WHERE Bd.BatchId=@BatchId  AND Wr.DateTimeStamp BETWEEN Bd.StartDate AND  Bd.EndDate and   Wr.ParameterId=9 -- Hold Signal value

     -- INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,17,@HoldTime,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)


     --END
     
     -- CapturingMeter Plc Address EndRedaing 
     IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
      BEGIN
      IF(@WasherMeterExists IS NOT NULL AND @MeterPlcAddress > 0)
      BEGIN
       IF(@MeterPlcAddressIsModified !=0)  
       BEGIN
       IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp =@CurrentFormulaDate)
       BEGIN
        INSERT INTO TCD.WasherReading(
         WasherId,
         ParameterId,
         ParameterValue,
         DateTimeStamp,
         PartitionOn,
         EcolabWasherId)
        SELECT 
         @WasherId,
         14, --MeterPlcAddress for EndSReading
         @MeterPlcAddress,
         @CurrentFormulaDate,
         (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
         @EcolabWasherId
       END

      END
      END
     END
         
     --Start Good or Bad Injection in BatchDataTable
     IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE BatchId=@BatchId AND MachineId=@WasherId AND EndDate IS NOT NULL ORDER BY StartDate DESC  )
      BEGIN
	 CREATE TABLE #CteTempPLCInjections
(
		ParameterValue INT,
        BatchId INT,
        WasherId INT,
        ProgramNumber INT
)
INSERT INTO #CteTempPLCInjections
 SELECT DISTINCT Wr.ParameterValue,
            BD.BatchId,
            Wr.WasherId,
            Bd.ProgramNumber FROM TCD. BatchData Bd
        INNER JOIN 
          TCD.WasherReading Wr ON Wr.WasherId   =  Bd.MachineId 
        WHERE    
              Wr.ParameterId    =  10    AND 
              Wr.ParameterValue   <>  0    AND 
              Bd.BatchId     =  @BatchID AND WR.DateTimeStamp BETWEEN BD.StartDate AND BD.EndDateFormula;

		SELECT @CteTempPLCInjections = COUNT(ParameterValue) FROM #CteTempPLCInjections

	 ;with CteTempBatchInjections  AS ( 
        SELECT  DISTINCT  Wdpm.InjectionNumber,
            Bd.BatchId,
            Wps.ProgramNumber,
            Ws.WasherId            
         FROM TCD.Washer WS
          INNER JOIN 
             TCD.MachineSetup Mst ON 
             Mst.WasherId     =  WS.WasherId
          INNER JOIN 
             TCD.WasherGroup Wg ON 
             Wg.WasherGroupId    =  Mst.GroupId       
          INNER JOIN 
             TCD.WasherProgramSetup Wps ON 
             Wps.WasherGroupId    =  Wg.WasherGroupId
          INNER JOIN 
             TCD.WasherDosingSetup Wds ON 
             Wds.WasherProgramSetupId  =  Wps.WasherProgramSetupId
          INNER JOIN 
             TCD.WasherDosingProductMapping Wdpm ON 
             Wdpm.WasherDosingSetupId  =  Wds.WasherDosingSetupID
          INNER JOIN 
             TCD.ProductdataMapping Pdm ON 
             Pdm.ProductId     =  Wdpm.ProductId
          INNER JOIN 
             TCD.BatchData Bd ON 
             Bd.MachineId     =  Ws.WasherId 
          INNER JOIN 
             TCD.WasherReading Wr ON 
             Wr.WasherId      =  Bd.MachineId
        WHERE 
        
             Wps.ProgramNumber    =  @Prveformula  AND 
             Bd.BatchId      =  @BatchID   AND 
             Ws.WasherId      =  @WasherId    )

		SELECT   @CteTempenVisionInjections=COUNT(en.InjectionNumber) FROM CteTempBatchInjections en
		
		 INNER JOIN #CteTempPLCInjections plc ON  en.InjectionNumber =plc.ParameterValue
		 	
		DROP TABLE #CteTempPLCInjections

        INSERT Tcd.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchID,@EcolabWasherId,18,
          CASE WHEN @CteTempenVisionInjections = @CteTempPLCInjections THEN 1
            WHEN @CteTempenVisionInjections != @CteTempPLCInjections THEN 3 END,
            (SELECT Top 1 ShiftStartdate from @ShiftStartDate) 
                           
    END
     --End Good or Bad Injection in BatchDataTable 
     IF(@OperationalCount = 0 AND @CurrentInjection = 0) AND (@CurrentFormula != @EndofFormula)
     BEGIN 
      IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchData WHERE MachineId=@WasherId AND StartDate =@CurrentFormulaDate)
      BEGIN     
       
    --Start Rollup for previous completed shift
    IF(CAST(@CurrentFormulaDate as date) < CAST(GETUTCDATE() as date))
    BEGIN
    SELECT TOP 1 @PreviousShiftId=ShiftId FROM TCD.BatchData WHERE MachineId=@WasherId ORDER BY StartDate DESC    
    SELECT Top 1 @CurrentShiftId = ShiftId from @ShiftStartDate
    IF(@CurrentShiftId != @PreviousShiftId)
    BEGIN
    EXEC TCD.ProductionShiftDataRollup @PreviousShiftId, @RedFlagShiftId OUTPUT
    IF(@RedFlagShiftId IS NULL)
    BEGIN
    SET @RedFlagShiftId = @PreviousShiftId
    END
    END
    END
    --End Rollup for previous completed shift

       --Start Getting InjectionCount and StepCount
       SELECT 
       @StdInjectionSteps=count(DISTINCT wdpm.WasherDosingSetupId),
       @StdWashSteps= count(DISTINCT wds.WasherDosingSetupId)-count(DISTINCT wdpm.WasherDosingSetupId)
       FROM TCD.WasherDosingProductMapping wdpm
       RIGHT JOIN tcd.WasherDosingSetup wds on wdpm.WasherDosingSetupId=wds.WasherDosingSetupId
       WHERE wds.GroupId=@GroupId AND wds.ProgramNumber=@CurrentFormula
       --End Getting InjectionCount and StepCount
       --Start-----ProgramMasterID logic for PlantChainProgram
        SELECT 
        @PlantProgramId=pm.PlantProgramId,
        @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
        @ChainTextileCategoryId = pm.ChainTextileId,
        @FormulaSegmentId = pm.FormulaSegmentId,
        @EcolabSaturationId = pm.EcolabSaturationId 
        FROM TCD.ProgramMaster pm WHERE pm.ProgramId=@ProgramMasterId AND pm.Is_Deleted=0
        IF(@PlantProgramId <> 0  AND @PlantProgramId IS NOT NULL)
         BEGIN
            --Assign value from plantchainprogram table based on plantprogramId
            SELECT
             @EcolabTextileCategoryId = pcp.EcolabTextileCategoryId,
             @ChainTextileCategoryId = pcp.ChainTextileCategoryId,
             @FormulaSegmentId = pcp.FormulaSegmentId,
             @EcolabSaturationId = pcp.EcolabSaturationId
             FROM tcd.PlantChainProgram pcp
             WHERE pcp.PlantProgramId=@PlantProgramId AND pcp.Is_Deleted=0
         END
       --End-----ProgramMasterID logic for PlantChainProgram

       INSERT INTO TCD.BatchData(
          ControllerBatchId ,
          EcolabWasherId,
          GroupId ,
          MachineInternalId,
          PlantWasherNumber,
          StartDate ,
          EndDate ,
          ProgramNumber,
          ProgramMasterId,
          MachineId,
          ActualWeight,
          StandardWeight,
          CurrencyCode,
          ShiftId,         
          PartitionOn,
          TargetTurnTime,
          StdInjectionSteps,
          StdWashSteps,
          EcolabTextileCategoryId,
          ChainTextileCategoryId,
          FormulaSegmentId,
          EcolabSaturationId,
          PlantProgramId,
          ETechlastDroppedTimeStamp          
          )


         SELECT DISTINCT 0
          ,@EcolabWasherId
          ,@GroupId
          ,@MachineInternalId
          ,Ws.PlantWasherNumber
          ,@CurrentFormulaDate
          ,NULL
          ,@CurrentFormula
          ,@ProgramMasterId
          ,@WasherId
          ,@AutoWeightEntryWeight
          ,@StandardWeight 
          ,@CurrencyCode
          ,(SELECT Top 1 ShiftId from @ShiftStartDate)         
          ,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
          ,@TargetTurnTime
          ,@StdInjectionSteps
          ,@StdWashSteps
          ,@EcolabTextileCategoryId
          ,@ChainTextileCategoryId
          ,@FormulaSegmentId
          ,@EcolabSaturationId
          ,@PlantProgramId           
          ,@ETechLastDroppedAt            

       FROM TCD.Washer Ws
          INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws.WasherId
          INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
          INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
       WHERE Ws.WasherId=@WasherId 
   
       SET @BatchID=SCOPE_IDENTITY() 
         
       INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,38,@StdWashSteps,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
    --Start Updating CustomerCodes in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
   IF(@Customercodes IS NOT NULL)
   BEGIN
    IF NOT EXISTS(SELECT * FROM TCD.BatchParameters WHERE ParameterId =39 and batchid=@BatchID)
    BEGIN
  INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,39,@CustomerCodes,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)       
    END
    ELSE
    BEGIN
  Update TCD.BatchParameters SET ParameterValue=@CustomerCodes WHERE ParameterId =39 and batchid=@BatchID
    END
   END
   ----Start Updating CustomerCodes in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
       --If the received formula is not configured in enVision then create an alarm 
       IF(@ProgramMasterId is NULL)
       BEGIN
       SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant;
       SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId FROM TCD.AlarmGroupMsterVsControllerModelType AGMVCMT
       INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
       WHERE AGMVCMT.AlarmCode = 9000
        INSERT INTO [TCD].[AlarmData] 
           (EcoalabAccountNumber,
           AlarmCode,
           BatchId,
           controllerID,
           StartDate,
           GroupId,
           MachineInternalId,
           ProgramId,   
           IsActive,
           EndDate,
           MachineId,
           AlarmGroupMasterId,
     PartitionOn)
           SELECT
            @ECOLABAccountNumber,
            9000,
            @BatchID,
            @ControllerId,
            @CurrentFormulaDate,
            @GroupId,
            @MachineInternalId,
            @CurrentFormula,
            0,
            @CurrentFormulaDate,
            @WasherId,
            @AlarmGroupMasterId,
   @CurrentFormulaDate
       END

         
         INSERT INTO TCD.BatchCustomerData
         (
         BatchId,
         CustomerId,
         Weight,
         PiecesCount,
         PartitionOn,
         EcolabWasherId
         )
        SELECT Bd.BatchId,  
        --SELECT @BatchID,
         Pc.ID,
         @AutoWeightEntryWeight,
         ROUND(COALESCE((@AutoWeightEntryWeight * Pm.Pieces) / NULLIF(Pm.Weight,0), 0),0),
         (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
         @EcolabWasherId
        
      
       FROM TCD.Washer WS
        INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
        INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId       
        INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
        INNER JOIN TCD.ProgramMaster Pm ON Pm.ProgramId=Wps.ProgramId
        INNER JOIN TCD.PlantCustomer Pc ON Pc.ID=Pm.CustomerId
        INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
       WHERE 
        Ws.WasherId=@WasherId AND 
        Wps.ProgramNumber=@CurrentFormula AND 
        Bd.BatchId=@BatchID  AND 
        Pm.CustomerId != -1 

       IF(@WasherMeterExists IS NOT NULL AND @MeterPlcAddress > 0)
       BEGIN        
        IF(@MeterPlcAddressIsModified !=0)  
        BEGIN
          INSERT INTO TCD.WasherReading(
           WasherId,
           ParameterId,
           ParameterValue,
           DateTimeStamp,
           PartitionOn,
           EcolabWasherId)
          SELECT 
           @WasherId,
           13, --MeterPlcAddress for StartReading
           @MeterPlcAddress,
           @CurrentFormulaDate,
           (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
           @EcolabWasherId
        END
       END 
      END              
     END      
     IF(@BatchID IS NOT NULL)     
     BEGIN
     IF(@CurrentInjection <= 0)
      BEGIN
       SET @CurrentInjectionDate=@CurrentFormulaDate
      END 
      IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp =@CurrentInjectionDate)
      BEGIN      
      INSERT INTO TCD.WasherReading(
          WasherId,
          ParameterId,
          ParameterValue,
          DateTimeStamp,
          PartitionOn,
          EcolabWasherId)
      SELECT   @WasherId,
          CASE TagType 
          WHEN 'Tag_FRM' THEN  5  
          WHEN 'Tag_INJ' THEN  10 
          WHEN 'Tag_OPC' THEN  11 
          END,
          TagValue,          
          @CurrentInjectionDate,
          (SELECT Top 1 ShiftStartdate from @ShiftStartDate),
          @EcolabWasherId
       FROM  #XmlTagsTable 
       WHERE  Tagtype in ('Tag_FRM','Tag_INJ','Tag_OPC')         
     END
     END
    IF(@CurrentInjection > 0)     
     BEGIN
      IF (@RatioDosingEnabled = 1)
       BEGIN
       IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurrentInjectionDate and batchid=@BatchID)
       BEGIN
        INSERT INTO TCD.BatchProductData(BatchId,StepCompartment,ActualQuantity,StandardQuantity,Price,TimeStamp,PartitionOn,EcolabWasherId,ProductId)
        SELECT Bd.BatchId 
        --SELECT @BatchID 
         ,Wds.StepNumber
         ,(((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100)) * (bd.ActualWeight/@StandardWeight) AS ActualQuantity 
         ,(((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100)) * (bd.ActualWeight/@StandardWeight) AS StandardQuantity
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * @MaxWashertGroupCapacity)/CONVERT(decimal(10,2), 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price         
         ,@CurrentInjectionDate
         ,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
         ,@EcolabWasherId
         ,Pdm.ProductID
        FROM TCD.Washer WS
         INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
         INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
         INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
         INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
         INNER JOIN TCD.WasherDosingSetup Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
         INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
         INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Wdpm.ProductId
         INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
        WHERE 
          Ws.WasherId=@WasherId     AND 
          Wps.ProgramNumber=@CurrentFormula  AND 
          Wdpm.InjectionNumber=@CurrentInjection AND
          Bd.BatchId=@BatchID AND
    Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
	AND Pdm.ProductID<>1
       END
       END
      ELSE
       BEGIN
       IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchProductData WHERE TimeStamp =@CurrentInjectionDate and batchid=@BatchID)
       BEGIN
        INSERT INTO TCD.BatchProductData(BatchId,StepCompartment,ActualQuantity,StandardQuantity,Price,TimeStamp,PartitionOn,EcolabWasherId,ProductId)
        SELECT Bd.BatchId  
        --SELECT @BatchID
         ,Wds.StepNumber
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100) AS ActualQuantity  
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * Ws.MaxLoad)/CONVERT(decimal(10,2), 100) AS StandardQuantity      
         ,((@NominalLoad/CONVERT(decimal(10,2), 100)) * Wdpm.Quantity * @MaxWashertGroupCapacity)/CONVERT(decimal(10,2), 100) * [tcd].[FnChemicalCostInOunce](Pdm.ProductID) AS Price         
         ,@CurrentInjectionDate
         ,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)
         ,@EcolabWasherId
         ,Pdm.ProductID
        FROM TCD.Washer WS
         INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
         INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
         INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
         INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
         INNER JOIN TCD.WasherDosingSetup Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
         INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
         INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Wdpm.ProductId
         INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
        WHERE 
          Ws.WasherId=@WasherId     AND 
          Wps.ProgramNumber=@CurrentFormula  AND 
          Wdpm.InjectionNumber=@CurrentInjection AND
          Bd.BatchId=@BatchID AND
         Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
	    AND Pdm.ProductID<>1
       END  
       END 
       
  --Populating BatchWashstepdata
      SELECT TOP 1 @PreviousInjectionStep=StepCompartment, @PreviousInjectionStartDate=StartTime FROM TCD.BatchWashStepData WHERE BatchId=@BatchID AND EndTime IS NULL ORDER BY StartTime DESC
      
      IF NOT EXISTS(SELECT TOP 1 * FROM TCD.BatchWashStepData WHERE StartTime =@CurrentInjectionDate and batchid=@BatchID)
      BEGIN
         SELECT @CurrentInjectionStep=Wds.StepNumber,
             @WashStepBatchId=Bd.BatchId
                 
         FROM TCD.Washer WS
          INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = ws.WasherId
          INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId = Mst.GroupId
          INNER JOIN TCD.WasherGroupType WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
          INNER JOIN TCD.WasherProgramSetup Wps ON Wps.WasherGroupId = Wg.WasherGroupId
          INNER JOIN TCD.WasherDosingSetup Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
          INNER JOIN TCD.WasherDosingProductMapping Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
          INNER JOIN TCD.ProductdataMapping Pdm ON Pdm.ProductId=Wdpm.ProductId
          INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
         WHERE 
          Ws.WasherId=@WasherId     AND 
          Wps.ProgramNumber=@CurrentFormula  AND 
          Wdpm.InjectionNumber=@CurrentInjection AND
          Bd.BatchId=@BatchID AND
          Wps.Is_Deleted = 0 AND Pdm.Is_Deleted = 0
		  AND wds.Is_Deleted=0 AND wdpm.IsDeleted=0

         IF(@CurrentInjectionStep IS NOT NULL)
         BEGIN
          INSERT INTO TCD.BatchWashStepData(BatchId,StepCompartment,StartTime,PartitionOn,EcolabWasherId)
          VALUES (@WashStepBatchId,  @CurrentInjectionStep, @CurrentInjectionDate, (SELECT Top 1 ShiftStartdate from @ShiftStartDate), @EcolabWasherId)                
         
          UPDATE TCD.BatchWashStepData SET EndTime=@CurrentInjectionDate WHERE BatchId=@BatchID AND StepCompartment=@PreviousInjectionStep AND StartTime=@PreviousInjectionStartDate         
         END

      END
      --End Populating BatchWashstepdata

      --Start Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
      IF NOT EXISTS(SELECT * FROM TCD.BatchParameters WHERE ParameterId =37 and batchid=@BatchID)
      BEGIN
       INSERT INTO TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) SELECT @BatchId,@EcolabWasherId,37,1,(SELECT Top 1 ShiftStartdate from @ShiftStartDate)       
      END
      ELSE
      BEGIN
       Update TCD.BatchParameters SET ParameterValue=@CurrentInjection WHERE ParameterId =37 and batchid=@BatchID
      END
        --End Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
     END

     UPDATE TCD.ConduitController
      SET LastConnectedTime  = GETUTCDATE()
      WHERE ControllerId   = @ControllerId
   END
  END
 END