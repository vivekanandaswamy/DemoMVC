﻿/*  
 ==========================================================================================  
 Purpose:  Fecthing the Formulas by group id  

 Author:  Neetha Allati

 --------------------------------------------------------------  
 Sep-25-2014 ENT: Initial version.  
 ==========================================================================================  
*/ 
CREATE PROCEDURE [TCD].[GetFormulasByGroupId] 
(
		@WasherGroupId INT,
		@EcolabAccountNumber NVARCHAR(25)
 )
AS 
  BEGIN
  SET NOCOUNT ON
		SELECT 
					Distinct P.ProgramId,
					P.Name
		FROM [TCD].WasherProgramSetup AS WP				
				INNER JOIN [TCD].ProgramMaster AS P ON P.ProgramId = WP.ProgramId
	    WHERE WP.WasherGroupId = @WasherGroupId 				
				AND WP.EcolabAccountNumber = @EcolabAccountNumber 
				AND WP.IS_DELETED = 0 
				AND P.IS_DELETED = 0 					
SET NOCOUNT OFF
  END