    
    
CREATE PROCEDURE [TCD].SaveConventionalWasherAnalogControl    
 @PlantId       INT      
    , @WasherDosingSetupId     INT    
    , @SetPointTemperature      SMALLINT    
    , @MinimumTime      SMALLINT      
    , @StartDelay      SMALLINT      
    , @AcceptedDelay     SMALLINT                
    , @ProductId         INT      
    , @PhControlDuringDrain  BIT    
    , @PhDelayTime     SMALLINT    
    , @PhMeasuringTime SMALLINT    
    , @PhMininum   DECIMAL(18,2)    
    , @PhMaximum   DECIMAL(18,2)    
    , @UserId INT  
   -- , @LastModifiedTime Datetime2  
    , @EcolabAccountNumber NVARCHAR(2000)    
AS      
BEGIN    
IF NOT EXISTS(SELECT * FROM TCD.WasherDosingAnalogControllerMapping     
 WHERE EcolabAccountNumber=@EcolabAccountNumber    
  AND WasherDosingSetupId=@WasherDosingSetupId)    
BEGIN    
INSERT INTO TCD.WasherDosingAnalogControllerMapping     
VALUES (@PlantId,@WasherDosingSetupId,@SetPointTemperature,@MinimumTime,@StartDelay,@AcceptedDelay,@ProductId,    
@PhControlDuringDrain,@PhDelayTime,@PhMeasuringTime,@PhMininum,@PhMaximum,@UserId,GetUtcDate(),@EcolabAccountNumber)    
END    
ELSE    
BEGIN    
UPDATE TCD.WasherDosingAnalogControllerMapping     
SET SetPointTemperature =@SetPointTemperature,    
MinimumTime = @MinimumTime,    
StartDelay = @StartDelay,    
AcceptedDelay = @AcceptedDelay,    
ProductId = @ProductId,    
PhControlDuringDrain = @PhControlDuringDrain,    
PhDelayTime = @PhDelayTime,    
PhMeasuringTime = @PhMeasuringTime,    
PhMininum = @PhMininum,    
PhMaximum = @PhMaximum    
    
WHERE EcolabAccountNumber=@EcolabAccountNumber    
  AND WasherDosingSetupId=@WasherDosingSetupId    
END    
END    
  
--select * from  TCD.WasherDosingAnalogControllerMapping     