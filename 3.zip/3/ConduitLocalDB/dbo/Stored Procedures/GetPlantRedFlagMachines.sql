CREATE PROCEDURE [TCD].[GetPlantRedFlagMachines] (@GroupId INT, @EcolabAccountNumber nvarchar(25))
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE
     @Istunnel INT = NULL,
     @GroupTypeId INT = NULL;
	SELECT @IStunnel = Istunnel
	FROM TCD.machinesetup
	WHERE GroupId = @GroupId AND EcoalabAccountNumber = @EcolabAccountNumber AND IsDeleted = 0;

    SELECT @GroupTypeId = GroupTypeId
	FROM TCD.MachineGroup
	WHERE Id = @GroupId
    AND Is_Deleted = 0
    AND EcolabAccountNumber = @EcolabAccountNumber;

    IF @GroupTypeId = 2
    BEGIN
		IF @IStunnel = 1
		BEGIN
		  SELECT DISTINCT MS.WasherId,  
				CAST( WS.PlantWasherNumber AS NVARCHAR)+ ':'+ MS.MachineName ,      
				MS.ControllerId  
			FROM TCD.machinesetup MS  
			LEFT JOIN TCD.Meter M ON MS.GroupId = M.GroupId  
				AND M.MachineCompartment = MS.WasherId  
			LEFT JOIN TCD.Sensor S ON MS.GroupId = S.GroupId  
				AND S.MachineCompartment = MS.WasherId  
			LEFT JOIN  TCD.Washer WS ON WS.WasherId = MS.WasherId  AND WS.EcoLabAccountNumber = @EcolabAccountNumber
			WHERE  MS.IsDeleted = 0  
				AND MS.GroupId = @GroupId  
				AND MS.EcoalabAccountNumber = @EcolabAccountNumber
				AND MS.IStunnel =1			
		END;
		ELSE
		BEGIN
			SELECT DISTINCT MS.WasherId,
				CAST( WS.PlantWasherNumber AS NVARCHAR)+ ':'+ MS.MachineName ,				
				MS.ControllerId
			  FROM TCD.machinesetup MS
			   LEFT JOIN
			   TCD.Meter M ON MS.GroupId = M.GroupId
				  AND M.MachineCompartment = MS.WasherId
			   LEFT JOIN
			   TCD.Sensor S ON MS.GroupId = S.GroupId
				   AND S.MachineCompartment = MS.WasherId
				LEFT JOIN  TCD.Washer WS ON WS.WasherId = MS.WasherId  AND WS.EcoLabAccountNumber = @EcolabAccountNumber
			  WHERE 
			 -- ( S.SensorId IS NOT NULL
			 -- AND S.Is_deleted = 0
			 -- AND S.EcolabAccountNumber = @EcolabAccountNumber
			 --  OR M.MeterId IS NOT NULL
			 -- AND M.Is_deleted = 0
			 -- AND M.EcolabAccountNumber = @EcolabAccountNumber)
				--AND 
				MS.IsDeleted = 0
				AND MS.GroupId = @GroupId
			 AND MS.EcoalabAccountNumber = @EcolabAccountNumber
			 AND MS.IStunnel =0;
		END;
    END;
    ELSE
    BEGIN 
		IF @GroupTypeId = 3
		BEGIN
		  SELECT DISTINCT D.DryerNo,
			  D.Description,
			  NULL
			FROM TCD.Dryers D			
			WHERE D.Is_deleted = 0
		  AND D.DryerGroupId = @GroupId
		  AND D.EcolabAccountNumber = @EcolabAccountNumber;
		END;
      ELSE
      BEGIN 
		IF @GroupTypeId = 4
        BEGIN
			SELECT DISTINCT F.FinnisherNo,
				F.Name,
				NULL
			  FROM TCD.Finnishers F
			   LEFT JOIN
			   TCD.Meter M ON F.FinnisherGroupId = M.GroupId
			  AND M.MachineCompartment = F.FinnisherId
			   LEFT JOIN
			   TCD.Sensor S ON F.FinnisherGroupId = S.GroupId
			   AND S.MachineCompartment = F.FinnisherId
			  WHERE ( S.SensorId IS NOT NULL
			  AND S.Is_deleted = 0
			  AND S.EcolabAccountNumber = @EcolabAccountNumber
			   OR M.MeterId IS NOT NULL
			  AND M.Is_deleted = 0
			  AND M.EcolabAccountNumber = @EcolabAccountNumber)
			AND F.Is_deleted = 0
			AND F.FinnisherGroupId = @GroupId
			AND F.EcolabAccountNumber =@EcolabAccountNumber;
        END;
        ELSE
        BEGIN 
			IF @GroupTypeId = 5
			BEGIN

			  DECLARE
			   @WaterandEnergyGroupId  INT = (SELECT TOP (1) MG.Id
					FROM TCD.MachineGroup MG
					 INNER JOIN
					 TCD.MachineGroupType MGT ON MGT.Id = MG.GroupTypeId
					WHERE MGT.Id = @GroupTypeId   );

			  SELECT DISTINCT WE.DeviceNumber,
				  WE.DeviceName,
				  NULL
				FROM TCD.WaterAndEnergy WE
				 LEFT JOIN
				 TCD.Meter M ON M.GroupId = @WaterandEnergyGroupId
				AND M.MachineCompartment = WE.DeviceNumber
				 LEFT JOIN
				 TCD.Sensor S ON S.GroupId = @WaterandEnergyGroupId
				 AND S.MachineCompartment = WE.DeviceNumber
				WHERE ( S.SensorId IS NOT NULL
				AND S.Is_deleted = 0
				AND S.EcolabAccountNumber = @EcolabAccountNumber
				 OR M.MeterId IS NOT NULL
				AND M.Is_deleted = 0
				AND M.EcolabAccountNumber = @EcolabAccountNumber)
			  AND WE.Is_deleted = 0
			  AND WE.EcolabAccountNumber = @EcolabAccountNumber;
			END;
        END;
      END;
    END;
    SET NOCOUNT OFF;
END;