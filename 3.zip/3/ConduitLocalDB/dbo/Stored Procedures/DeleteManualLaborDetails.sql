
/****** Object:  StoredProcedure [TCD].[DeleteManualLaborDetails]    Script Date: 21-11-2014 10:07:04 ******/

/*	                                   

###################################################################################################                                           



Stored Procedure:       [tcd].[DeleteManualLaborDetails]                                     



Purpose:				To delete The manual labor details.



Parameters:				@Id - holds the man hours type id.

						
###################################################################################################                                           

*/

CREATE PROCEDURE [TCD].[DeleteManualLaborDetails] (
				@Id int=NULL,
				@LastModifiedByUserId int=NULL
		) 
AS 

SET NOCOUNT ON

  BEGIN

      DECLARE @FromDate date,
	     @Todate date,
		@OldManualHours int,
		@NewManualHours int,@ManHourTypeId int

    SELECT @FromDate = CAST(ml.StartDate AS date),
		 @Todate  = CAST(ml.EndDate AS date),
		 @ManHourTypeId = ml.ManHourTypeId,
		 @OldManualHours = ml.AllocatedManHours
		 FROM TCD.ManualLabor ml WHERE ml.Id = @Id 

    SELECT @NewManualHours = - @OldManualHours
    
    UPDATE	tcd.ManualLabor SET	IsDeleted			=		1	WHERE 		Id			=		@Id  AND LastModifiedByUserId=@LastModifiedByUserId

    
	EXEC [TCD].[UpdateProductionShiftManualLabourRollup]
												@FromDate  = @FromDate,
												@Todate  =  @Todate,
												@LabourType  =  @ManHourTypeId,
												@ManualHours  =  @NewManualHours

  SET NOCOUNT OFF

   END




