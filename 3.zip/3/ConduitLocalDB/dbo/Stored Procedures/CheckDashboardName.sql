﻿CREATE PROCEDURE [TCD].[CheckDashboardName]

(

@DASHBOARDID INT,

@DASHBOARDNAME NVARCHAR(100),

@EcolabAccountNumber NVarchar(25),

@Scope INT OUTPUT 

)

AS
SET NOCOUNT ON
BEGIN

	DECLARE @OutPut INT = 0

	IF(@DASHBOARDID > 0)

		BEGIN

		IF EXISTS(SELECT 1 FROM [TCD].DASHBOARD WHERE DASHBOARDNAME = @DASHBOARDNAME AND EcolabAccountNumber = @EcolabAccountNumber AND ISDELETED=0 AND DASHBOARDID <> @DASHBOARDID)

			BEGIN

				SET @OutPut = 1		

			END

		END

		ELSE

			BEGIN

				IF EXISTS(SELECT 1 FROM [TCD].DASHBOARD WHERE DASHBOARDNAME = @DASHBOARDNAME  AND EcolabAccountNumber = @EcolabAccountNumber AND ISDELETED=0)

					BEGIN

						SET @OutPut = 1		

					END

			END

	SET @Scope = @OutPut SELECT @Scope  

END


