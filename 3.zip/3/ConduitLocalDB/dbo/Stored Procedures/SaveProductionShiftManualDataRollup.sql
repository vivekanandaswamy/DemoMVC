﻿CREATE PROCEDURE [TCD].[SaveProductionShiftManualDataRollup](
--DECLARE
												@Date datetime = NULL,    --'2015-05-26'
												@ManualData int = NULL,  --1000
												@WasherId int = NULL,	   --4
												@ProgramMasterId int =NULL	   --21
												
												
											 )
AS
SET NOCOUNT ON
BEGIN

    DECLARE 
		  @ShiftId Int = NULL,   		  
		  @BatchUTCStart DATETIME= NULL,
		  @BatchUTCEnd DATETIME= NULL,
		  @ShiftTargetProd Decimal(18,2) = NULL,
		  @ShiftCount Int = 1,
		  @validateShiftName varchar(100),
		  @Fromdate datetime,
		  @ToDate datetime

    SET @Fromdate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@Date AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@Date AS time)) AS DateTime))
	SET @ToDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(DATEADD(d,1,@Date) AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(DATEADD(d,1,@Date) AS time)) AS DateTime))

    DECLARE @ShiftProductionDataRollup TABLE
				 (
					[ShiftId] [int] NOT NULL,
					[MachineId] [int] NULL,
					[ProgramMasterId] [int] NULL,
					[EcolabWasherId] [int] NULL,
					[NoOfLoads] [int] NULL,
					[ActualProduction] [int] NULL,
					[StandardProduction] [int] NULL,
					[LoadEfficiency] [decimal](18, 2) NULL,
					[TimeEfficiency] [decimal](18, 2) NULL,
					[PlantTargetProd] [int] NULL,
					[ActualRunTime] [int] NULL,
					[TargetRunTime] [int] NULL,
					[EcolabTextileId] [int] NULL,
					[ChainTextileId] [int] NULL,
					[ChainProgaramId] [int] NULL,
					[CustomerId] [int] NULL,
					[NoOfPieces] [int] NULL,
					[ActualTurnTime] [int] NULL,
					[TargetTurnTime] [int] NULL
				)
	   
    DECLARE @BatchShiftTable TABLE
						(
						  RowNumber int IDENTITY(1,1),
						  BatchUTCStartDate datetime,
						  BatchUTCEndDate datetime,
						  ShiftId int,
						  ShiftName varchar(100)
						)
  		  
	 INSERT INTO @BatchShiftTable
	 (
	    BatchUTCStartDate,
	    BatchUTCEndDate,
	    ShiftId,
	    ShiftName
	 )
	 SELECT 
			StartDateTime,
			EndDateTime,
			ShiftID,
			ShiftName		   
					FROM [TCD].ProductionShiftData SD WITH (NOLOCK) 
					WHERE sd.StartDateTime >= @Fromdate AND  SD.StartDateTime < @ToDate
					   ORDER BY SD.ShiftId



    DECLARE @ManualInputData TABLE
			 (
				ManualInput int,
				WasherId int,
				ProgramMasterId int
			 )
			 INSERT @ManualInputData
			 (
			     ManualInput,
				WasherId,
			     ProgramMasterId
			 )
			
			 SELECT @ManualData/NULLIF((SELECT COUNT(1) FROM @BatchShiftTable bst WHERE bst.ShiftName <> 'No Shift'),0),
				    @WasherId,
				   @ProgramMasterId


    			
	   ------------------******// Inserting the Data into Batch Summary Temp table based on UTC shift timings //******-----------------------
    WHILE (@ShiftCount <= (SELECT COUNT(1) FROM @BatchShiftTable bst))
    BEGIN

    SELECT  @BatchUTCStart = 
				    bst.BatchUTCStartDate,
			   @BatchUTCEnd = 
				    bst.BatchUTCEndDate,
			   @ShiftId = bst.ShiftId,
			   @validateShiftName = bst.ShiftName
				FROM @BatchShiftTable bst WHERE bst.RowNumber = @ShiftCount
    
    INSERT INTO @ShiftProductionDataRollup
		  ([ShiftId]
           ,[MachineId]
           ,[ProgramMasterId]
           ,[EcolabWasherId]
           ,[NoOfLoads]
           ,[ActualProduction]
           ,[StandardProduction]
           ,[LoadEfficiency]
           ,[TimeEfficiency]
           ,[PlantTargetProd]
           ,[ActualRunTime]
           ,[TargetRunTime]
           ,[EcolabTextileId]
           ,[ChainTextileId]
           ,[ChainProgaramId]
           ,[CustomerId]
           ,[NoOfPieces]
           ,[ActualTurnTime]
           ,[TargetTurnTime])
    SELECT 
		  [ShiftId]
           ,[MachineId]
           ,[ProgramMasterId]
           ,[EcolabWasherId]
           ,[NoOfLoads]
           ,[ActualProduction]
           ,[StandardProduction]
           ,[LoadEfficiency]
           ,[TimeEfficiency]
           ,[PlantTargetProd]
           ,[ActualRunTime]
           ,[TargetRunTime]
           ,[EcolabTextileId]
           ,[ChainTextileId]
           ,[ChainProgaramId]
           ,[CustomerId]
           ,[NoOfPieces]
           ,[ActualTurnTime]
           ,[TargetTurnTime] FROM TCD.ShiftProductionDataRollup spdr WHERE spdr.ShiftId = @ShiftId
	  
	  --SELECT spdr.* FROM @ShiftProductionDataRollup spdr

	    --------------------------******// Inserting the Data into production Shift Rollup Data Table //******-------------------
	      		  
		 DELETE FROM [TCD].ShiftProductionDataRollup WHERE ShiftId = @ShiftId 
		 
			 INSERT INTO [TCD].ShiftProductionDataRollup
								(
								    ShiftId,
								    MachineId,
								    ProgramMasterId,
								    EcolabWasherId,
								    NoOfLoads,
								    ActualProduction ,
								    StandardProduction,
								    LoadEfficiency,
								    TimeEfficiency,
								    PlantTargetProd ,
								    ActualRunTime,
								    TargetRunTime,
								    EcolabTextileId,
								    ChainTextileId,
								    ChainProgaramId,
								    CustomerId,
								    NoOfPieces,
								    ActualTurnTime,
								    TargetTurnTime
								)	


			 SELECT 
				    spdr.[ShiftId]
				   ,spdr.[MachineId]
				   ,spdr.[ProgramMasterId]
				   ,spdr.[EcolabWasherId]
				   ,spdr.[NoOfLoads]
				   ,spdr.[ActualProduction]  + ISNULL(mid.ManualInput,0)
				   ,spdr.[StandardProduction]
				   ,spdr.[LoadEfficiency]
				   ,spdr.[TimeEfficiency]
				   ,spdr.[PlantTargetProd]
				   ,spdr.[ActualRunTime]
				   ,spdr.[TargetRunTime]
				   ,spdr.[EcolabTextileId]
				   ,spdr.[ChainTextileId]
				   ,spdr.[ChainProgaramId]
				   ,spdr.[CustomerId]
				   ,spdr.[NoOfPieces]
				   ,spdr.[ActualTurnTime]
				   ,spdr.[TargetTurnTime] 
						  FROM @ShiftProductionDataRollup spdr
							 LEFT JOIN
								    @ManualInputData mid ON spdr.ProgramMasterId = mid.ProgramMasterId AND spdr.MachineId = mid.WasherId

					--SELECT spdr.* FROM TCD.ShiftProductionDataRollup spdr WHERE spdr.ShiftId = @ShiftId 

		  IF(@validateShiftName <> 'No Shift')
		  BEGIN
		  IF NOT EXISTS(SELECT DISTINCT spdr.ProgramMasterId,spdr.MachineId FROM TCD.ShiftProductionDataRollup spdr WHERE spdr.ShiftId = @ShiftId
																   AND spdr.ProgramMasterId IN (SELECT mid.ProgramMasterId FROM @ManualInputData mid)
																   AND spdr.MachineId IN (SELECT mid.WasherId FROM @ManualInputData mid))
				BEGIN
				   INSERT INTO [TCD].ShiftProductionDataRollup
								(
								    ShiftId,
								    MachineId,
								    ProgramMasterId,
								    EcolabWasherId,
								    NoOfLoads,
								    ActualProduction ,												
								    PlantTargetProd ,
								    ActualRunTime,
								    TargetRunTime,						
								    ActualTurnTime,
								    TargetTurnTime
								)	


				SELECT TOP 1 
					   spdr.[ShiftId]
					  ,(SELECT mid.WasherId FROM @ManualInputData mid)
					  ,(SELECT mid.ProgramMasterId FROM @ManualInputData mid)
					  ,(SELECT w.EcolabWasherId FROM TCD.Washer w WHERE W.WasherId IN (SELECT mid.WasherId FROM @ManualInputData mid))
					  ,1
					  ,(SELECT mid.ManualInput FROM @ManualInputData mid)
					  ,spdr.[PlantTargetProd]
					  ,ISNULL(NULL,0)
					  ,ISNULL(NULL,0)
					  ,ISNULL(NULL,0)
					  ,ISNULL(NULL,0)
							 FROM TCD.ShiftProductionDataRollup spdr WHERE spdr.ShiftId = @ShiftId
								
								    
				END
			END
	  	   DELETE FROM @ShiftProductionDataRollup		 
		  SET @ShiftCount = @ShiftCount + 1
	    END	   
	  
END
