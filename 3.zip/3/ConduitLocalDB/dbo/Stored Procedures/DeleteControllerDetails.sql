﻿

/*   
 ==========================================================================================  
 Purpose:  Delete the Controller Details.   

 Author:  Aakriti   

 --------------------------------------------------------------   
			August-19-2014	ENT: Initial version.
 dfozdar:	16-Sep-2014		Changes for Audit re-factor   
 ==========================================================================================  
 */

CREATE PROCEDURE [TCD].[DeleteControllerDetails] 
(
  @ControllerId INT
 , @UserId INT
 , @EcolabAccountNumber     NVARCHAR(25)
 , @LastModifiedTimestampAtCentral   DATETIME     = NULL
 , @OutputLastModifiedTimestampAtLocal  DATETIME     = NULL OUTPUT
 ) 
AS 
  BEGIN 
   SET NOCOUNT ON; 
   DECLARE
   @OutputList      AS TABLE  (
   LastModifiedTimestamp   DATETIME
  )

   
   DECLARE 
  @ErrorId      INT    =   0
 , @ErrorMessage     NVARCHAR(4000) =   N''
 , @CurrentUTCTime     DATETIME  =   GETUTCDATE()

 SET @OutputLastModifiedTimestampAtLocal    =   ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)   --SQLEnlight

   IF EXISTS (SELECT 1 FROM [TCD].ConduitController WHERE ControllerId = @ControllerId AND EcoalabAccountNumber = @EcolabAccountNumber) 
   BEGIN
  
  IF (
         @LastModifiedTimestampAtCentral    IS NOT NULL
         AND
         NOT EXISTS ( SELECT 1
           FROM TCD.ConduitController  CC
           WHERE CC.EcoalabAccountNumber  = @EcolabAccountNumber
            AND CC.ControllerId    = @ControllerId
            AND CC.LastModifiedTime   = @LastModifiedTimestampAtCentral
          )
    )
   BEGIN
     SET   @ErrorId    = 60000
     SET   @ErrorMessage   = N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
     RAISERROR (@ErrorMessage, 16, 1)
   END



  UPDATE [TCD].ConduitController
   SET 
    IsDeleted = 1
   , LastModifiedByUserId = @UserId
   , LastModifiedTime  = @CurrentUTCTime
  OUTPUT
    inserted.LastModifiedTime  AS   LastModifiedTimestamp
  INTO
   @OutputList (
   LastModifiedTimestamp
  )
  WHERE 
  ControllerId = @ControllerId
  AND
  EcoalabAccountNumber = @EcolabAccountNumber
  
  UPDATE [TCD].ControllerTags
   SET 
    Active = 0
  WHERE 
  ControllerId = @ControllerId
  AND
  EcolabAccountNumber = @EcolabAccountNumber
  
  update [tcd].moduletags set active = 0 where ModuleId in (select ControllerEquipmentsetupId from tcd.ControllerEquipmentSetup where ControllerId = @ControllerId and EcoLabAccountNumber = @EcolabAccountNumber) and EcolabAccountNumber = @EcolabAccountNumber

  SELECT TOP 1 @OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp FROM @OutputList O
	
	UPDATE TCD.Injection SET Is_Deleted = 'TRUE' WHERE ControllerId = @ControllerId

  --EXEC usp_AuditingChangedDetails @ControllerId,0,1,@Column_Name,@Table_name,@UserID

  END 
  END