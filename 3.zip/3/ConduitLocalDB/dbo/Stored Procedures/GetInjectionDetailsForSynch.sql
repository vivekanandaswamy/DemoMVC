CREATE PROCEDURE [TCD].[GetInjectionDetailsForSynch]
								(
								    @WasherGroupId Int = NULL 
								)
AS
SET NOCOUNT ON
BEGIN
DECLARE @WasherGroupNo INT
SELECT @WasherGroupNo = WG.WasherGroupNumber FROM TCD.WasherGroup WG WHERE WG.WasherGroupId = @WasherGroupId;

DECLARE @InjectionClassTag nvarchar(1000) = NULL
DECLARE @InjectionRatioTag nvarchar(1000) = NULL

 SELECT @InjectionClassTag = WT.TagAddress
				 FROM TCD.WasherTags WT 
				 inner JOIN tcd.Injection IJ 
				 ON IJ.WasherId = WT.WasherId
				 INNER JOIN TCD.Washer w
				 ON w.WasherId = WT.WasherId 
				 WHERE  IJ.WasherGroupNumber IS NOT NULL 
				 AND IJ.WasherGroupNumber = @WasherGroupNo AND WT.TagType IN ('Tag_ICLAS') AND WT.Active = 1 ;

SELECT @InjectionRatioTag = WT.TagAddress
				 FROM TCD.WasherTags WT 
				 inner JOIN tcd.Injection IJ 
				 ON IJ.WasherId = WT.WasherId
				 INNER JOIN TCD.Washer w
				 ON w.WasherId = WT.WasherId 
				 WHERE  ij.WasherGroupNumber IS NOT NULL 
				 AND IJ.WasherGroupNumber = @WasherGroupNo AND WT.TagType IN ('Tag_INJRO') AND WT.Active = 1 ;


SELECT IJ.Id, 
		  IJ.WasherId,
		  IJ.WasherGroupNumber,
		  IJ.InjectionClass,
		  IJ.ControllerId,
		  IJ.ReferenceLoad,
		  WS.MaxLoad,
		  IJ.EcolabAccountNumber,
		  @InjectionClassTag,
		  @InjectionRatioTag,
		  IJ.Is_Deleted
		  FROM TCD.Injection IJ
					   INNER JOIN 
				TCD.Washer WS ON IJ.WasherId = WS.WasherId
				    WHERE WasherGroupNumber IS NOT NULL 
								AND WasherGroupNumber = @WasherGroupNo

END