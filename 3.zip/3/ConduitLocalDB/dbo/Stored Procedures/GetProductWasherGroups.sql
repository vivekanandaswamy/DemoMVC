﻿/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_GetProductWasherGroups]                                         

Purpose:				To get the products for washer groups.

Parameters:				@EcolabAccountNumber - holds the ecolab account number.
																														
###################################################################################################                                           
*/
CREATE PROCEDURE [TCD].[GetProductWasherGroups]
 (
	@EcolabAccountNumber NVARCHAR(25)
 )
AS 
  BEGIN      
	 SET NOCOUNT ON
	 -- SELECT MG.Id,Mg.GroupDescription
  --    FROM   [TCD].MachineGroup MG
	 -- INNER JOIN [TCD].MachineSetup  AS MS  ON MG.Id = Ms.GroupId
	 -- INNER JOIN TCD.Washer w ON w.WasherId = Ms.WasherId
	 --  WHERE MG.GroupTypeId = 2 AND MG.EcolabAccountNumber = @EcolabAccountNumber AND MG.Is_Deleted <> 1 
	 --  AND MS.IsDeleted = 0     		
		--AND MS.ControllerId = 0
		--AND W.WasherMode = 0
		--GROUP BY MG.Id,Mg.GroupDescription
		 SELECT MG.Id,MG.GroupDescription FROM   [TCD].MachineGroup MG
      INNER JOIN TCD.WasherGroup WG ON MG.Id = WG.WasherGroupId       
      WHERE  MG.GroupTypeId = 2 AND MG.EcolabAccountNumber = @EcolabAccountNumber AND Is_Deleted <> 1 
  SET NOCOUNT OFF
  END