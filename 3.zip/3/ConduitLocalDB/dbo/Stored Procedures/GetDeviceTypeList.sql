﻿/*  
 ==========================================================================================  
 Purpose:  Fetching the Device type list.  

 Author:  Neetha Allati  

 --------------------------------------------------------------  
 August-21-2014 ENT: Initial version.  
 ==========================================================================================  
*/ 

CREATE PROCEDURE [TCD].[GetDeviceTypeList] 
AS 
  BEGIN 
      SET nocount ON; 

     Select  
	 [DeviceTypeId] ,
	 [Description] 	 
     FROM  [TCD].[DeviceType] 
	 WHERE 
		ISDeleted=0     
  END 