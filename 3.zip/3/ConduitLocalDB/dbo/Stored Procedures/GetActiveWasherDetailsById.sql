﻿CREATE PROCEDURE [TCD].[GetActiveWasherDetailsById]
(
	@WasherId							INT

)
AS
BEGIN

SET	NOCOUNT	ON														--SQLEnlight	SA0017


	 SELECT WasherTagId
      ,WasherId
      ,TagType
      ,TagAddress
      FROM TCD.WasherTags WHERE WasherId=@WasherId and Active=1	  

END
