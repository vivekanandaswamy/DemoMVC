CREATE PROCEDURE [TCD].[GetMaxInjectionClass] (
@ControllerId int ,
@EcolabAccountNumber NVARCHAR(25))
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN
	   SELECT	COUNT(DISTINCT InjectionClass)
	   FROM		tcd.Injection 
	   WHERE	ControllerId			=			@ControllerId
	   AND		EcolabAccountNumber		=			@EcolabAccountNumber
	   AND		Is_Deleted				!=			1
    END;	  
END;