﻿CREATE PROCEDURE [TCD].[CopyConventionalFormula]
         @SubstituteMissingChemical                 TCD.SubstituteMissingChemical    READONLY    
    ,    @ToWasherGroupId                            INT                                =            NULL
    ,    @FromWasherGroupId                          INT                                =            NULL
    ,    @ProgramNumber                              SMALLINT                            =            NULL 
    ,    @WasherProgramSetupId                       INT                                =            NULL
    ,    @ProgramId                                  INT                                =            NULL
    ,    @EcoLabAccountNumber                        NVARCHAR(25)                        =            NULL
    ,    @UserId                                     INT                                =            NULL
    ,    @ProgramSetupId                             INT                                =            NULL   OUTPUT 
    

AS
BEGIN
    SET NOCOUNT ON;

    DECLARE      @TotalNumberOfPrograms      SMALLINT        =       NULL
    ,            @ReturnValue                INT             =       0
    ,            @ErrorId                    INT             =       0
    ,            @ErrorMessage               NVARCHAR(4000)  =       N''
    ,            @MaxNumberOfPrograms        SMALLINT        =       NULL
    ,            @PRODUCTEXIST                BIT
    ,            @IsDrain                    BIT
    ,            @trackAsDosingStep            BIT
    ,             @FromControllerID                    INT     =   NULL
    ,             @ToControllerID                    INT     =   NULL    
    ,             @FromControllerModelID                INT     =   NULL
    ,             @ToControllerModelID                INT     =   NULL

    DECLARE
                @OutputList                                AS    TABLE        (
                OutputProgramSetupId                       INT
        )

    SELECT  @FromControllerID   =  wg.ControllerId 
     FROM TCD.WasherGroup   wg
     WHERE   wg.WasherGroupId  =  @FromWasherGroupId
    AND   wg.EcolabAccountNumber =  @EcoLabAccountNumber

    SELECT  @ToControllerID   =  wg.ControllerId 
     FROM TCD.WasherGroup   wg
     WHERE   wg.WasherGroupId  =  @ToWasherGroupId
    AND   wg.EcolabAccountNumber =  @EcoLabAccountNumber

    SELECT  @FromControllerModelID  =  cc.ControllerModelId
     FROM TCD.ConduitController cc
     WHERE cc.ControllerId   =  @FromControllerID
    AND   cc.EcoalabAccountNumber =  @EcoLabAccountNumber

    SELECT  @ToControllerModelID  =  cc.ControllerModelId
     FROM TCD.ConduitController cc
     WHERE cc.ControllerId   =  @ToControllerID
    AND   cc.EcoalabAccountNumber =  @EcoLabAccountNumber

    IF @ToControllerID IS NOT NULL
    BEGIN
       SELECT @MaxNumberOfPrograms = cmctm.MaxConvProgramCount
       FROM TCD.ControllerModelControllerTypeMapping cmctm
       INNER JOIN TCD.ConduitController cc
       ON cc.ControllerModelId = cmctm.ControllerModelId 
       AND cc.ControllerTypeId = cmctm.ControllerTypeId
       WHERE cc.ControllerId = @ToControllerID
    END
    ELSE
    BEGIN
        SET @MaxNumberOfPrograms = 127
    END


    --ProgramNumber check
    IF    (    @ProgramNumber                >            @MaxNumberOfPrograms)
    BEGIN
            SET        @ErrorId                        =            51012
            SET        @ErrorMessage                    =            N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Invalid ProgramNumber... Aborting.'
            --GOTO    ErrorHandler
            RAISERROR    (@ErrorMessage, 16, 1)
            SET    @ReturnValue    =    -1
            RETURN    (@ReturnValue)
    END

        IF @ToControllerModelID = 7
        BEGIN
            SET @ToWasherGroupId = NULL
        END    

        IF @FromControllerModelID = 7
        BEGIN
            SET @FromWasherGroupId = NULL
        END    

        IF    EXISTS    (        SELECT    1
                                FROM    [TCD].WasherProgramSetup            WPS
                                WHERE    WPS.EcolabAccountNumber        =            @EcoLabAccountNumber
                                    AND    (CASE WHEN @ToWasherGroupId IS NOT NULL 
                                             THEN WPS.WasherGroupId
                                             ELSE WPS.ControllerID
                                            END)      = (CASE WHEN @ToWasherGroupId IS NOT NULL 
                                                           THEN @ToWasherGroupId
                                                           ELSE @ToControllerID
                                                          END)
                                    AND    WPS.ProgramNumber            =            @ProgramNumber
                                    AND    WPS.Is_Deleted                =            'FALSE'
                        )
                    BEGIN
                            SET        @ErrorId                        =            51001
                            SET        @ErrorMessage                    =            N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Specified ProgramNumber for the WasherGroup already exists for the plant.'
                            --GOTO    ErrorHandler
                            RAISERROR    (@ErrorMessage, 16, 1)
                            SET    @ReturnValue    =    -1
                            RETURN    (@ReturnValue)
                    END

        SELECT @TotalNumberOfPrograms        =            COUNT(WPS.ProgramNumber)
        FROM   [TCD].WasherProgramSetup      AS           WPS
        WHERE  WPS.EcolabAccountNumber       =            @EcoLabAccountNumber
        AND    (CASE WHEN @ToWasherGroupId IS NOT NULL 
                                             THEN WPS.WasherGroupId
                                             ELSE WPS.ControllerID
                                            END)      = (CASE WHEN @ToWasherGroupId IS NOT NULL 
                                                           THEN @ToWasherGroupId
                                                           ELSE @ToControllerID
                                                          END)
        AND    WPS.Is_Deleted                =            'FALSE'
    
        IF (@TotalNumberOfPrograms           =            @MaxNumberOfPrograms)
            BEGIN
                    SET        @ErrorId        =            51000
                    SET        @ErrorMessage    =            N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Maximum Number of programs that can be associated to a WasherGroup already defined... Aborting.'
                    RAISERROR  (@ErrorMessage, 16, 1)
                    SET            @ReturnValue    =    -1
                    RETURN        (@ReturnValue)
            END

        INSERT INTO TCD.WasherProgramSetup
        (
            EcolabAccountNumber,
            WasherGroupId,
            ProgramNumber,
            ProgramId,
            NominalLoad,
            LoadsPerMonth,
            TotalRunTime,
            ExtraTime,
            TotalSteps,
            CoolDownStep,
            FinalExtractingTime,
            Category,
            CustomProgramName,
            PlantProgramNumber,
            NumberOfDrains,
            DrainTime,
            Rewash,
            CleanWt,
            CleanAw,
            CustomerId,
            Is_Deleted,
            LastModifiedByUserId,
            MyServiceCustFrmulaMchGrpGUID,
            LastModifiedTime,
            ControllerID
        )
        OUTPUT
            inserted.WasherProgramSetupId    AS    Id
        INTO
            @OutputList(
                    OutputProgramSetupId
                       )
        SELECT    wps.EcolabAccountNumber
        ,        @ToWasherGroupId
        ,        @ProgramNumber
        ,        @ProgramId
        ,        wps.NominalLoad
        ,        wps.LoadsPerMonth
        ,        wps.TotalRunTime
        ,        wps.ExtraTime
        ,        wps.TotalSteps
        ,        wps.CoolDownStep
        ,        wps.FinalExtractingTime
        ,        wps.Category
        ,        wps.CustomProgramName
        ,        wps.PlantProgramNumber
        ,        wps.NumberOfDrains
        ,        wps.DrainTime
        ,        wps.Rewash
        ,        wps.CleanWt
        ,        wps.CleanAw
        ,        wps.CustomerId
        ,        'False'
        ,        @UserId
        ,        NEWID()
        ,        GETUTCDATE()
        ,         @ToControllerID
        FROM TCD.WasherProgramSetup wps
        WHERE wps.EcolabAccountNumber    =    @EcoLabAccountNumber
        AND    (CASE WHEN @FromWasherGroupId IS NOT NULL 
                                             THEN WPS.WasherGroupId
                                             ELSE WPS.ControllerID
                                            END)      = (CASE WHEN @FromWasherGroupId IS NOT NULL 
                                                           THEN @FromWasherGroupId
                                                           ELSE @FromControllerID    
                                                          END)
        AND      wps.WasherProgramSetupId    =    @WasherProgramSetupId

        --check for any error
            SET    @ErrorId    =    @@ERROR
    
            IF    (@ErrorId    <>    0)
                BEGIN
                        SET    @ReturnValue    =    -1
                        RETURN    (@ReturnValue)
                END

        SELECT  TOP 1 @ProgramSetupId    =   O.OutputProgramSetupId FROM @OutputList O
        
        INSERT INTO TCD.WasherDosingSetup
        (
            --WasherDosingSetupId - this column value is auto-generated
            EcoLabAccountNumber,
            WasherProgramSetupId,
            GroupId,
            ProgramNumber,
            StepNumber,
            StepTypeId,
            ProductId,
            StepRunTime,
            Quantity,
            [Delay],
            ResourceDetailId,
            MENumber,
            Temperature,
            WaterType,
            WaterLevel,
            DrainDestinationId,
            pHLevel,
            Note,
            Is_Deleted,
            LastModifiedByUserId,
            StandardWeight,
            MyServiceCustFrmulaStpGUID,
            StandardWaterUsage,
            TrackAsDosingStep,
            ControllerID
        )
        SELECT    wds.EcoLabAccountNumber
        ,        @ProgramSetupId
        ,        @ToWasherGroupId
        ,        @ProgramNumber
        ,        wds.StepNumber
        ,        wds.StepTypeId
        ,        wds.ProductId
        ,        wds.StepRunTime
        ,        wds.Quantity
        ,        wds.[Delay]
        ,        wds.ResourceDetailId
        ,        wds.MENumber
        ,        wds.Temperature
        ,        wds.WaterType
        ,        wds.WaterLevel
        ,        wds.DrainDestinationId
        ,        wds.pHLevel
        ,        wds.Note
        ,        wds.Is_Deleted
        ,        @UserId
        ,        wds.StandardWeight
        ,        NEWID()
        ,        wds.StandardWaterUsage
        ,        wds.TrackAsDosingStep
        ,         @ToControllerID
        FROM TCD.WasherDosingSetup wds
        WHERE wds.WasherProgramSetupId = @WasherProgramSetupId
        AND      wds.EcoLabAccountNumber  = @EcoLabAccountNumber
        AND      wds.Is_Deleted           = 'False'

        --check for any error
            SET    @ErrorId    =    @@ERROR
    
            IF    (@ErrorId    <>    0)
                BEGIN
                        SET    @ReturnValue    =    -1
                        RETURN    (@ReturnValue)
                END

                ------dummy
                SET @PRODUCTEXIST = (SELECT PM.Is_Deleted FROM TCD.PRODUCTMASTER PM WHERE PM.ProductId= 1 AND PM.Name LIKE '%DUMMY PRODUCT%');
                   IF(@PRODUCTEXIST = 1)
                       BEGIN
                       UPDATE TCD.PRODUCTMASTER SET Is_Deleted= 0 WHERE  ProductId= 1 AND Name LIKE '%DUMMY PRODUCT%'
                       END

                SET @PRODUCTEXIST = (SELECT Is_Deleted FROM TCD.ProductdataMapping WHERE EcolabAccountNumber=@EcoLabAccountNumber AND ProductId= 1);

                IF(@PRODUCTEXIST IS NULL )
                    BEGIN
                    insert into TCD.ProductdataMapping(EcolabAccountNumber,ProductId,SKU,Cost,Is_Deleted,IncludeCI,InventoryExpense,LastModifiedByUserId,LastModifiedTime,LastSyncTime) values (@EcoLabAccountNumber,1,'0',0,0,0,0,0,getdate(),GETDATE())
                    END
                IF(@PRODUCTEXIST = 1)
                    BEGIN
                    UPDATE TCD.ProductdataMapping SET Is_Deleted = 0 WHERE EcolabAccountNumber=@EcoLabAccountNumber AND ProductId= 1
                    END

                    SELECT @trackAsDosingStep = TrackAsDosingStep,@IsDrain = wds.StepTypeId  FROM TCD.WasherDosingSetup wds WHERE wds.WasherProgramSetupId = @WasherProgramSetupId AND wds.EcoLabAccountNumber  = @EcoLabAccountNumber AND wds.Is_Deleted           = 'False'

                    IF NOT EXISTS(SELECT * FROM TCD.WashStep WHERE StepId = @IsDrain AND StepName LIKE '%Drain%' AND IsActive=1)
                        BEGIN
                        SET @IsDrain = 'FALSE'
                        END
                    

                IF (@IsDrain = 'FALSE' AND @trackAsDosingStep = 'TRUE')
                BEGIN
                INSERT INTO  [TCD].WasherDosingProductMapping (
                    EcoLabAccountNumber
                    , WasherDosingSetupId
                    , InjectionNumber
                    , ProductId
                    , Quantity
                    , LastModifiedByuserId
                    , MyServiceFrmulaStpDsgDvcGuid
                    , IsDeleted
                    , [Delay]
                    ,ControllerEquipmentSetupId)
                    VALUES(    
                    @EcoLabAccountNumber
                    , @ProgramSetupId
                    , 1
                    , 1
                    , 0
                    , @UserId
                    ,null
                    , 0
                    , 0
                    ,null)
                END
                ------dummy


        SELECT    wdpm.EcoLabAccountNumber
        ,        wds2.WasherDosingSetupId
        ,        wdpm.InjectionNumber
        ,        wdpm.ProductId
        ,        wdpm.Quantity
        ,        wdpm.IsDeleted
        ,        wdpm.ControllerEquipmentSetupId
        ,        wdpm.[Delay]
        INTO #tempWasherDosingProductMapping
        FROM TCD.WasherDosingProductMapping wdpm
        INNER JOIN TCD.WasherDosingSetup wds
        ON wds.EcoLabAccountNumber = wdpm.EcoLabAccountNumber
        AND wds.WasherDosingSetupId = wdpm.WasherDosingSetupId
        LEFT JOIN TCD.WasherDosingSetup wds2 
        ON wds.EcoLabAccountNumber = wds2.EcoLabAccountNumber
        AND wds.StepNumber = wds2.StepNumber
        AND wds2.WasherProgramSetupId = @ProgramSetupId
        WHERE wds.WasherProgramSetupId = @WasherProgramSetupId
        AND wds.Is_Deleted = 'False'
        ORDER BY wds.StepNumber 

        UPDATE twdpm
        SET twdpm.ProductId = CASE WHEN udd.NewProductId > 0 THEN udd.NewProductId ELSE twdpm.ProductId END
        ,    twdpm.IsDeleted = CASE WHEN udd.NewProductId > 0 THEN 0 ELSE 1 END
        ,   twdpm.Quantity  = CASE WHEN udd.ScalarOption = 1 
                              THEN CASE WHEN (twdpm.Quantity - ((twdpm.Quantity * udd.ScalarAmountPercent)/100)) < 0 
                                    THEN 0
                                    ELSE  (twdpm.Quantity - ((twdpm.Quantity * udd.ScalarAmountPercent)/100))
                                    END
                                WHEN udd.ScalarOption = 2 
                                THEN (twdpm.Quantity + ((twdpm.Quantity * udd.ScalarAmountPercent)/100)) 
                                ELSE twdpm.Quantity 
                                END
	   ,twdpm.ControllerEquipmentSetupId = (SELECT TOP 1 ces.ControllerEquipmentSetupId FROM TCD.ControllerEquipmentSetup ces WHERE ces.ControllerId = @ToControllerID AND ces.ProductId = udd.NewProductId AND ces.EcoLabAccountNumber = twdpm.EcoLabAccountNumber)
        FROM #tempWasherDosingProductMapping twdpm
        INNER JOIN @SubstituteMissingChemical udd	   
        ON twdpm.ProductId = udd.OldProductId	   
        
        INSERT INTO TCD.WasherDosingProductMapping
        (
            --WasherDosingProductMappingId - this column value is auto-generated
            EcoLabAccountNumber,
            WasherDosingSetupId,
            InjectionNumber,
            ProductId,
            Quantity,
            LastModifiedByUserId,
            MyServiceFrmulaStpDsgDvcGuid,
            LastModifiedTime,
            IsDeleted,
            ControllerEquipmentSetupId,
            [Delay]
        )
        SELECT   td.EcoLabAccountNumber
        ,        td.WasherDosingSetupId
        ,        td.InjectionNumber
        ,        td.ProductId
        ,        td.Quantity
        ,        @UserId
        ,        NEWID()
        ,        GETUTCDATE()
        ,        td.IsDeleted
        ,        td.ControllerEquipmentSetupId
        ,        td.[Delay]
        FROM #tempWasherDosingProductMapping td
        WHERE td.IsDeleted = 'False'
            
        DROP TABLE #tempWasherDosingProductMapping

        -- For Reording the washer injection based on the update or insert of the productdosing for the washer.
        EXEC [TCD].[WasherInjectionOrdering] @ProgramSetupId,@EcolabAccountNumber

        --check for any error
            SET    @ErrorId    =    @@ERROR
    
            IF    (@ErrorId    <>    0)
                BEGIN
                        SET    @ReturnValue    =    -1
                        RETURN    (@ReturnValue)
                END

    IF    (    @ErrorId    =    0    )
    BEGIN
        --GOTO    ExitModule
        RETURN    (@ReturnValue)
    END

    SET    NOCOUNT    OFF
    RETURN    (@ReturnValue)
END
GO