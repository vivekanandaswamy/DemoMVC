﻿/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_GetRedFlagItems]                                           

Purpose:				To get the red flag items.

Parameters:				@ItemId - holds the item Id.
						@EcoLabAccountNumber - holds the ecolab account number.
																						
###################################################################################################                                           
*/
CREATE PROCEDURE [TCD].[GetRedFlagItems](@ItemId INT=NULL,@EcolabAccountNumber nvarchar(25) = NULL)
AS 
SET nocount ON; 
  BEGIN 
      DECLARE @RegionID int = NULL
	 SELECT @RegionID = RegionId FROM [TCD].Plant WHERE EcolabAccountNumber = @EcolabAccountNumber;
	 WITH CTE(Id,ItemName,COU,UOM)
	 AS
	 (
	 SELECT 
	 RF.Id,
	 RF.ItemName,IT.COU,
	 CASE @RegionID WHEN 1 THEN UOMNA WHEN 2 THEN UOMEurope END AS UOM
      FROM   [TCD].RedFlagItemList RF LEFT OUTER JOIN 
	 (SELECT COUNT(1) AS COU,Item AS Id FROM [TCD].RedFlag PRF INNER JOIN [TCD].MachineGroup GT ON PRF.Location = GT.Id GROUP BY ITEM) IT
	 on rf.Id = it.Id
	 )
	 SELECT Id,ItemName,UOM FROM CTE WHERE COU < (SELECT COUNT(1) FROM [TCD].MachineGroup WHERE Id <> 0 AND Is_Deleted = 0) OR COU IS NULL
	 OR ID = @ItemId
	 SET nocount OFF;
  END 


  