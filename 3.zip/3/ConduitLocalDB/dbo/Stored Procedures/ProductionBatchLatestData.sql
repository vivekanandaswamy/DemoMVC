
--EXEC [TCD].[ProductionBatchLatestData] '','','','','','','','','','','','','','2014-12-11'

CREATE PROCEDURE [TCD].[ProductionBatchLatestData] (
											 @Corporate Varchar(max) = '',
											 @Country Varchar(max) = '',
											 @Region Varchar(max) = '',
											 @EcolabAccountNumber Nvarchar(25) = '',
											 @Machine Varchar(max) = '', 
											 @machineGroup Varchar(max) = '',
											 @Formula Varchar(max) = '',
											 @MachineType Varchar(20)= '',
											 @Category Varchar(max) = '',
											 @FromDate Date = '',
											 @ToDate Date = '',
											 @GroupId Varchar(max) = '',
											 @MachineInternalId Varchar(max) = '',
											 @Date AS date

										  )
AS
SET NOCOUNT ON
BEGIN

SET			@ToDate					=			ISNULL(@ToDate, NULL)			--SQLEnlight SA0029
SET			@Corporate				=			ISNULL(@Corporate, NULL)		--SQLEnlight SA0029

DECLARE @CategoryTable TABLE(Category Varchar(100))
INSERT INTO @CategoryTable(Category) EXEC [TCD].[CharlistToTable] @Category,','

DECLARE @MachineTable TABLE(Machine Varchar(100))
INSERT INTO @MachineTable(Machine) EXEC [TCD].[CharlistToTable] @Machine,','

DECLARE @GroupMachineTable TABLE(GroupId INT,MachineInternalId INT)  
INSERT INTO @GroupMachineTable(GroupId,MachineInternalId) 
SELECT GroupId,MachineInternalId FROM TCD.MachineSetup MS 
									INNER JOIN TCD.Washer WS ON MS.WasherId = WS.WasherId WHERE WS.PlantWasherNumber IN (SELECT Machine FROM @MachineTable);

DECLARE @GroupTable TABLE(GroupId Varchar(100))
INSERT INTO @GroupTable(GroupId) EXEC [TCD].[CharlistToTable] @GroupId,','

DECLARE @MachineInternalTable TABLE(MachineInternalId Varchar(100))
INSERT INTO @MachineInternalTable(MachineInternalId) EXEC [TCD].[CharlistToTable] @MachineInternalId,','

DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))
INSERT INTO @WasherGroupTable(MachineGroup) EXEC [TCD].[CharlistToTable] @machineGroup,','

DECLARE @FormulaTable TABLE(Formula Varchar(100))
INSERT INTO @FormulaTable(Formula) EXEC [TCD].[CharlistToTable] @Formula,','

--DECLARE @CustomerTable TABLE(Customer Varchar(100))
--INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','

DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))
INSERT INTO @MachineTypeTable(MachineType) EXEC [TCD].[CharlistToTable] @MachineType,','

 DECLARE @TotalRunTimesec VARCHAR(100) = NULL,
		 @summingActualLoad Decimal(10,2)

CREATE TABLE #ProductionRollUpLatest(
						   [RecordDate] [date] NULL,
						   [GroupId] [int] NULL,
						   [MachineInternalId] [int] NULL,
						   [ProgramNumber] [int] NULL,
						   [TotalActualLoad] [int] NULL,
						   [TotalStandardLoad] [int] NULL,
						   [NoOfBatches] [int] NULL,
						   [ActualLoadPerHour] [int] NULL,
						   [TargetLoadPerHour] [int] NULL,
						   [NumberOfPieces] [int] NULL,
						   [LoadEfficiency] [decimal](18, 2) NULL,
						   [EcolabTextileCategoryName] [nvarchar](50) NULL,
						   [EcolabTextileId] [int] NULL,
						   [PlantTextileCategoryName] [nvarchar](50) NULL,
						   [PlantTextileId] [int] NULL,
						   [PlantProgramName] [nvarchar](50) NULL,
						   [PlantProgramId] [int] NULL,
						   [ProductionMix] [decimal](18, 2) NULL,
						   [Rewash] [decimal](18, 2) NULL,
						   [TotalRunTime] [int] NULL
					   ) 

     DECLARE @ProdRollUpTable Table(
								RecordDate DATE,
								GroupId INT,
								MachineInternalId INT,
								ProgramNumber INT,
								TotalActualLoad DECIMAL(10,2),
								TotalStandardLoad DECIMAL(10,2),
								NoOfBatches INT,
								ActualLoadPerHour DECIMAL(10,2),
								TargetLoadPerHour DECIMAL(10,2),
								NumberOfPieces INT,
								LoadEfficiency DECIMAL(10,2),
								TextileCategoryName VARCHAR(100),
								TextileId INT,
								PlantTextileCategoryName VARCHAR(100),
								PlantTextileId INT,
								PlantProgramName VARCHAR(100),
								PlantProgramId INT
							 )

    INSERT INTO @ProdRollUpTable(
								RecordDate ,
								GroupId ,
								MachineInternalId ,
								ProgramNumber ,
								TotalActualLoad ,
								TotalStandardLoad ,
								NoOfBatches ,
								ActualLoadPerHour ,
								TargetLoadPerHour ,
								NumberOfPieces ,
								LoadEfficiency ,
								TextileCategoryName ,
								TextileId ,
								PlantTextileCategoryName,
								PlantTextileId,
								PlantProgramName ,
								PlantProgramId 
							 )
    
    SELECT 
	   
	   CAST(bd.StartDate AS DATE) as RecordDate,
	   bd.GroupId,
	   BD.MachineInternalId,
	   BD.ProgramNumber,
	   (SUM(BD.[ActualWeight]) + CASE WHEN SUM(BD.ManualInputWeight) IS NULL THEN 0 ELSE SUM(BD.ManualInputWeight) END) as TotalActualLoad,
	   SUM(BD.[StandardWeight]) as TotalStandardLoad,
	   COUNT(BD.BatchID) AS NoOfBatches,

	   ((SUM(BD.[ActualWeight]) + CASE WHEN SUM(BD.ManualInputWeight) IS NULL THEN 0 ELSE SUM(BD.ManualInputWeight) END)/
	   (SELECT CAST(SUM(DATEDIFF(SECOND,BD.StartDate,BD.EndDate)) AS decimal(10,1))/3600)
	   ) as ActualLoadPerHour,

	  (SUM(BD.[StandardWeight])/(SELECT CAST(SUM(DATEDIFF(SECOND,BD.StartDate,BD.EndDate)) AS decimal(10,1))/3600)) as TargetLoadPerHour,



	   SUM(PiecesCount) AS NumberOfPieces,

	   CASE WHEN SUM(BD.[StandardWeight]) <> 0 THEN
	   CAST(((SUM(BD.[ActualWeight]) + CASE WHEN SUM(BD.ManualInputWeight) IS NULL THEN 0 ELSE SUM(BD.ManualInputWeight) END) * 100 /SUM(BD.[StandardWeight])) AS decimal(18,2))
	   ELSE 0 END
	   
	    AS LoadEfficiency,
	   ETC.CategoryName AS TextileCategoryName,
	   ETC.TextileId,	  
	   CTC.Name,
	   CTC.TextileId AS ChainTextileId,
	   PCP.PlantProgramName,
	   PCP.PlantProgramId
	   FROM TCD.BatchData BD 
			  LEFT OUTER JOIN
			  TCD.BatchCustomerData BCD ON BD.BatchID = BCD.BatchId
			  INNER JOIN
			  TCD.ProgramMaster PM ON PM.ProgramId = BD.ProgramMasterId
			  LEFT OUTER JOIN
			  TCD.EcolabTextileCategory ETC ON ETC.TextileId = PM.EcolabTextileCategoryId
			   LEFT OUTER JOIN
			  TCD.ChainTextileCategory CTC ON  CTC.TextileId = PM.ChainTextileId
			   LEFT OUTER JOIN
			  TCD.PlantChainProgram PCP ON PCP.PlantProgramId = PM.PlantProgramId
			  WHERE CAST(StartDate AS date) = CAST(@Date AS date)
								AND 
								CASE @Machine   
									WHEN '' THEN 'TRUE'         
									ELSE                                                      
									 CASE WHEN BD.GroupId IN (SELECT GroupId FROM @GroupMachineTable) AND 
									 BD.MachineInternalId IN (SELECT MachineInternalId FROM @GroupMachineTable) THEN 'TRUE' END                                                 
								    END='TRUE' 

								    AND       

								    CASE @machineGroup   
									WHEN '' THEN 'TRUE'         
									ELSE                                                      
									 CASE WHEN BD.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable) THEN 'TRUE' END                                                      
								    END='TRUE' 

								    AND    

								    CASE @Formula   
									WHEN '' THEN 'TRUE'         
									ELSE                                                      
									 CASE WHEN BD.ProgramNumber IN (SELECT Formula FROM @FormulaTable) THEN 'TRUE' END                                                      
								    END='TRUE' 

								    AND       

								    CASE @MachineType   
									WHEN '' THEN 'TRUE'         
									ELSE                                                      
									 CASE WHEN BD.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable)) THEN 'TRUE' END                                                      
								    END='TRUE' 

								    AND       
								   CASE @Category   
									WHEN '' THEN 'TRUE'         
									ELSE                                                      
									 CASE WHEN ETC.TextileId IN (SELECT Category FROM @CategoryTable) THEN 'TRUE' END                                                      
								    END='TRUE' 

								    AND
									CASE @GroupId 
									WHEN '' THEN 'TRUE' 
									ELSE        
								    CASE WHEN (BD.GroupId IN (@GroupId) AND 
									 BD.MachineInternalId IN (@MachineInternalId)) THEN 'TRUE' END                                                   
								    END='TRUE' 
								    AND
									CASE @MachineInternalId 
									WHEN '' THEN 'TRUE' 
									ELSE        
								    CASE WHEN (BD.GroupId IN (@GroupId) AND 
									 BD.MachineInternalId IN (@MachineInternalId)) THEN 'TRUE' END                                                   
								    END='TRUE' 
				     GROUP BY BD.GroupId,BD.MachineInternalId,BD.ProgramNumber,CAST(bd.StartDate AS DATE),ETC.CategoryName,ETC.TextileId,
	    CTC.Name,CTC.TextileId,PCP.PlantProgramName,PCP.PlantProgramId								


SELECT @summingActualLoad = SUM(TotalActualLoad)  FROM @ProdRollUpTable
GROUP BY RecordDate


INSERT INTO #ProductionRollUpLatest(
						   [RecordDate]  ,
						   [GroupId]  ,
						   [MachineInternalId]  ,
						   [ProgramNumber]  ,
						   [TotalActualLoad]  ,
						   [TotalStandardLoad]  ,
						   [NoOfBatches]  ,
						   [ActualLoadPerHour]  ,
						   [TargetLoadPerHour]  ,
						   [NumberOfPieces]  ,
						   [LoadEfficiency] ,
						   [EcolabTextileCategoryName] ,
						   [EcolabTextileId]  ,
						   [PlantTextileCategoryName] ,
						   [PlantTextileId]  ,
						   [PlantProgramName] ,
						   [PlantProgramId]  ,
						   [ProductionMix] ,
						   [Rewash]  ,
						   [TotalRunTime]  
					   ) 

SELECT 
	   DISTINCT
		  PRT.RecordDate,
		  PRT.GroupId,
		  PRT.MachineInternalId,
		  PRT.ProgramNumber,
		  PRT.TotalActualLoad,
		  PRT.TotalStandardLoad,
		  PRT.NoOfBatches,
		  PRT.ActualLoadPerHour,
		  PRT.TargetLoadPerHour,
	   	  PRT.NumberOfPieces,
	       PRT.LoadEfficiency,
		  PRT.TextileCategoryName,
		  PRT.TextileId,
		  PRT.PlantTextileCategoryName,
		  PRT.PlantTextileId,
		  PRT.PlantProgramName,
		  PRT.PlantProgramId,
		  CAST((PRT.TotalActualLoad * 100 /@summingActualLoad) AS decimal(18,2)) AS ProductionMix,
		  CAST(((SELECT SUM(MR.VALUE) FROM TCD.ManualRewash MR WHERE PRT.ProgramNumber = MR.FormulaId AND CAST(PRT.RecordDate AS date) = CAST(MR.RecordedDate AS date)
		   GROUP BY CAST(MR.RecordedDate AS date),MR.FormulaId) * 100 /PRT.TotalActualLoad) AS decimal(18,2)) AS Rewash,
		  (SELECT SUM(WP.TotalRunTime) FROM TCD.WasherProgramSetup WP WHERE WP.ProgramId = PRT.ProgramNumber GROUP BY ProgramId) AS TotalRunTime
	   FROM @ProdRollUpTable PRT

    
SET NOCOUNT OFF
END