CREATE  PROCEDURE [TCD].[ReportChemicalConsumption]
/********************************************************************************************************


Execution Statement:
 EXECUTE [TCD].[ReportChemicalConsumption]
   @startdate  = '2016-06-01',@enddate  = '2016-06-30',@EcolabAccountNumber = 'P02110023',
   @MachineType = '',@MachineGroup  = '',@Machine  = '',
   @EcolabCategory = '',@ChainCategory  = '',@PlantFormula   = '',@ChainFormula  = '',
   @Customer  = '',@CurrencyCode='',@UserId  = 1,
   @FormulaSegement ='',@FormulaCategory ='',@Formula ='', @View = 11



********************************************************************************************************/ 

 @startdate datetime = '',
 @enddate datetime = '',
 @EcolabAccountNumber Nvarchar(25) = '',
 @MachineType VARCHAR(20)= '',
 @MachineGroup VARCHAR(MAX) = '',
 @Machine VARCHAR(MAX) = '',
 @EcolabCategory VARCHAR(MAX) = '',
 @ChainCategory VARCHAR(MAX) = '',
 @PlantFormula  VARCHAR(MAX) = '',
 @ChainFormula VARCHAR(MAX) = '',
 @Customer VARCHAR(MAX) = '',
 @CurrencyCode varchar(3) = NULL,
 @UserId INT = NULL,
 @FormulaSegement VARCHAR(MAX)='', --Formula segment,
 @FormulaCategory VARCHAR(MAX)='', --Formula category
 @Formula VARCHAR(MAX)='', --Formula
 @View INT = '' -- @View: 10 - by product, 11 - by product category
AS   
BEGIN   
SET NOCOUNT ON 
Declare @uomId int
-- SET @startdate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@startdate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@startdate AS time)) AS DateTime))
 --   SET @EndDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndDate AS time)) AS DateTime))

    SELECT @CurrencyCode = ISNULL(um.CurrencyCode,0) FROM TCD.UserMaster um WHERE um.UserId = @UserId
    IF (COUNT(@CurrencyCode) <> 1)
    BEGIN
  SELECT @CurrencyCode = p.CurrencyCode FROM TCD.Plant P WHERE P.EcolabAccountNumber=@EcolabAccountNumber
    END
    
    SELECT @uomId = ISNULL(um.UOMId,0) FROM TCD.UserMaster um WHERE um.UserId = @UserId
    IF (@uomId < 1)
    BEGIN
  SELECT @uomId = p.UOMId FROM TCD.Plant P WHERE P.EcolabAccountNumber=@EcolabAccountNumber
    END
print @uomid
    DECLARE @ReportGenerated INT = 6,@Month INT = MONTH(GETDATE()),@NoOfLoads INT,@NoOfPrograms INT

 -- Inserting the record into Report History
 INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)
 SELECT @EcolabAccountNumber,UM.UserId,UM.LoginName, GETUTCDATE(),@ReportGenerated,
   CASE WHEN @ReportGenerated = 6
     THEN 'Generated Report : Chemical Consumption Report' 
   END
 FROM TCD.UserMaster UM
 WHERE UM.EcolabAccountNumber = @EcolabAccountNumber AND UM.UserId = @UserId
 
 --Declaraion of table variables
    DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))
    INSERT INTO @MachineTypeTable EXEC [TCD].[CharlistToTable] @MachineType,','

    DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))
    INSERT INTO @WasherGroupTable EXEC [TCD].[CharlistToTable] @machineGroup,','  

    DECLARE @MachineTable TABLE(Machine Varchar(100))
    INSERT INTO @MachineTable EXEC [TCD].[CharlistToTable] @Machine,','

    DECLARE @EcolabCategoryTable TABLE(EcolabCategory Varchar(100))
    INSERT INTO @EcolabCategoryTable EXEC [TCD].[CharlistToTable] @EcolabCategory,','

    DECLARE @ChainCategoryTable TABLE(ChainCategory Varchar(100))
    INSERT INTO @ChainCategoryTable EXEC [TCD].[CharlistToTable] @ChainCategory,','

    DECLARE @PlantFormulaTable TABLE(PlantFormula Varchar(100))
    INSERT INTO @PlantFormulaTable EXEC [TCD].[CharlistToTable] @PlantFormula,','

    DECLARE @ChainFormulaTable TABLE(ChainFormula Varchar(100))
    INSERT INTO @ChainFormulaTable EXEC [TCD].[CharlistToTable] @ChainFormula,','

    DECLARE @CustomerTable TABLE(Customer Varchar(100))
    INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','

 --Formula Segment 
 DECLARE @FormulaSegmentTable TABLE(FormulaSegment Varchar(1000))
    INSERT INTO @FormulaSegmentTable EXEC [TCD].[CharlistToTable] @FormulaSegement,','

 --Formula category
 DECLARE @FormulaCategoryTable TABLE(FormulaCategory Varchar(1000),Type CHAR(1))
    INSERT INTO @FormulaCategoryTable(FormulaCategory) EXEC [TCD].[CharlistToTable] @Formulacategory,',' 
  
  --Assuming Below 1000 Ecolab category --Drop down also they have to listed same way
  UPDATE @FormulaCategoryTable SET TYPE='E' WHERE FormulaCategory<1000
  --Above 1000 consider as Chain category--for chain category they need to Append in Drop down filters
  UPDATE @FormulaCategoryTable SET TYPE='C' WHERE FormulaCategory>=1000

  --Rollbacking to actual ID
  UPDATE @FormulaCategoryTable SET FormulaCategory=FormulaCategory-1000 WHERE TYPE='C'
   
  --SELECT * FROM @FormulaCategoryTable

  INSERT INTO @EcolabCategoryTable(EcolabCategory)
  SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='E' 

  INSERT INTO @ChainCategoryTable(ChainCategory)
  SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='C'

  --Value Assigning
  IF (EXISTS(SELECT * FROM @EcolabCategoryTable) AND @FormulaCategory!='')
  BEGIN
   SET @EcolabCategory=@FormulaCategory
  END
  IF (EXISTS(SELECT * FROM @ChainCategoryTable) AND @FormulaCategory!='')
  BEGIN
   SET @ChainCategory=@FormulaCategory
  END

 
 --Formula Ecolab/Chain categories
 DECLARE @FormulaTable TABLE(Formula Varchar(1000),Type CHAR(1))
    INSERT INTO @FormulaTable(Formula) EXEC [TCD].[CharlistToTable] @Formula,','
  
  --Select * from @FormulaTable
  --Plant fomula   
  INSERT INTO @PlantFormulaTable(PlantFormula) 
  SELECT Formula FROM @FormulaTable 
  --chain formula   
  INSERT INTO @ChainFormulaTable(ChainFormula) 
  SELECT Formula FROM @FormulaTable  

  --Value Assigning
  IF (EXISTS(SELECT * FROM @PlantFormulaTable) AND @Formula!='')
  BEGIN
   SET @PlantFormula=@Formula
  END
  IF (EXISTS(SELECT * FROM @ChainFormulaTable) AND @Formula!='')
  BEGIN
   SET @ChainFormula=@Formula
  END
  --SELECT @PlantFormula,@ChainFormula
 
 DECLARE @actualproduction decimal(18,2),@uom int
    SELECT @uom =UM.UOMId FROM TCD.UserMaster AS UM WHERE UM.UserId = @UserId
 
 --FInding Actual Production
 SELECT @actualproduction =
    CASE @uom 
     WHEN 1 THEN sum(ISNULL(spdr.ActualProduction,0))/100.00 
     WHEN 2 THEN ISNULL([TCD].[FnConsumptionOnMetrics](sum(ISNULL(spdr.ActualProduction,0)),'Weight',@UserId),0) 
    END    
 FROM tcd.ShiftProductionDataRollup spdr
 INNER JOIN TCD.ProductionShiftData AS PS ON PS.ShiftId = spdr.ShiftId 
  INNER JOIN tcd.machinesetup ms ON ms.WasherId=spdr.MachineId
 --Added by Kiran For Formula Hierarchy
 INNER JOIN TCD.ProgramMaster PM on SPDR.ProgramMasterId = PM.ProgramId 
 LEFT OUTER JOIN
   (
   --IF Chain Plant
   SELECT PCP.PlantProgramId,PCP.PlantChainId,PCP.ChainTextileCategoryId,PCP.EcolabTextileCategoryId,
   PCP.FormulaSegmentId,PCP.EcolabSaturationId
   FROM TCD.PlantChainProgram PCP 
   LEFT OUTER JOIN TCD.ChainTextileCategory CTC ON CTC.TextileId=PCP.ChainTextileCategoryId
   LEFT OUTER JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId=PCP.EcolabTextileCategoryId
   LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=PCP.FormulaSegmentId
   LEFT OUTER JOIN TCD.EcolabSaturation ES ON ES.EcolabSaturationId=PCP.EcolabSaturationId
   )ChainPlant ON PM.PlantProgramId=ChainPlant.PlantProgramId

 LEFT OUTER JOIN TCD.EcolabTextileCategory ETC1 ON ETC1.TextileId=PM.EcolabTextileCategoryId
 LEFT OUTER JOIN TCD.FormulaSegments FS1 ON FS1.FormulaSegmentID=PM.FormulaSegmentId
 LEFT OUTER JOIN TCD.EcolabSaturation ES1 ON ES1.EcolabSaturationId=PM.EcolabSaturationId
 ----End

    WHERE isnull(ms.IsPony,0)=0 and

       CASE @StartDate                                                                                
       WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
       ELSE CASE WHEN PS.[StartDateTime] >= @startdate AND PS.[StartDateTime] <=  @enddate THEN 'TRUE'END                                                        
       END='TRUE'
     AND
       CASE @MachineType   
       WHEN '' THEN 'TRUE'         
       ELSE                                                      
       CASE WHEN spdr.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
       MS.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable))) THEN 'TRUE' END                                                      
       END='TRUE'    
    AND    
        CASE @machineGroup   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN spdr.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
        MS.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable)) THEN 'TRUE' END                                                      
        END='TRUE' 
    AND
        CASE @Machine   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN spdr.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
        END='TRUE' 
    AND
  
    
        CASE @Customer   
        WHEN '' THEN 'TRUE'         
           ELSE                                                      
           CASE WHEN spdr.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                      
        END='TRUE' 
  --Added by Kiran
 AND 
  CASE @EcolabCategory   
  WHEN '' THEN 'TRUE' 
  ELSE
   CASE WHEN PM.PlantProgramId IS NOT NULL THEN
     CASE WHEN ChainPlant.EcolabTextileCategoryId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                                                   
   ELSE 
   CASE WHEN ETC1.TextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable)  THEN 'TRUE'END 
  END  
  END='TRUE'                            
 AND 
  CASE @ChainCategory    
  WHEN '' THEN 'TRUE' 
   ELSE 
    CASE WHEN PM.PlantProgramId IS NOT NULL THEN
     CASE WHEN ChainPlant.ChainTextileCategoryId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END 
    ELSE 'TRUE' END                                                                                                                                     
  END='TRUE'
 AND    
  CASE @PlantFormula   
  WHEN '' THEN 'TRUE'         
  ELSE                                                      
  CASE WHEN spdr.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                      
  END='TRUE'
    AND    
  CASE @ChainFormula   
  WHEN '' THEN 'TRUE'         
  ELSE                                                      
   CASE WHEN PM.PlantProgramId IS NOT NULL THEN
     CASE WHEN ChainPlant.ChainTextileCategoryId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END 
   ELSE 'TRUE' END                                                        
  END='TRUE'
    AND 
  CASE @FormulaSegement                                                                                
  WHEN '' THEN  'TRUE'
  ELSE
   CASE WHEN PM.PlantProgramId IS NOT NULL THEN
    CASE WHEN ChainPlant.FormulaSegmentId IN (SELECT FormulaSegment FROM @FormulaSegmentTable) THEN 'TRUE' END                                                                                     
   ELSE 
    CASE WHEN FS1.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)  THEN 'TRUE'END   
   END                                                     
  END='TRUE'

  /**/

  DECLARE @BatchCount int

  SELECT @BatchCount =count( distinct bd.batchid)
  
 FROM tcd.BatchData bd 
 INNER JOIN TCD.ProductionShiftData AS PS ON PS.ShiftId = bd.ShiftId 
  INNER JOIN tcd.machinesetup ms ON ms.WasherId=bd.MachineId
 --Added by Kiran For Formula Hierarchy
 INNER JOIN TCD.ProgramMaster PM on bd.ProgramMasterId = PM.ProgramId 
 LEFT OUTER JOIN
   (
   --IF Chain Plant
   SELECT PCP.PlantProgramId,PCP.PlantChainId,PCP.ChainTextileCategoryId,PCP.EcolabTextileCategoryId,
   PCP.FormulaSegmentId,PCP.EcolabSaturationId
   FROM TCD.PlantChainProgram PCP 
   LEFT OUTER JOIN TCD.ChainTextileCategory CTC ON CTC.TextileId=PCP.ChainTextileCategoryId
   LEFT OUTER JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId=PCP.EcolabTextileCategoryId
   LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=PCP.FormulaSegmentId
   LEFT OUTER JOIN TCD.EcolabSaturation ES ON ES.EcolabSaturationId=PCP.EcolabSaturationId
   )ChainPlant ON PM.PlantProgramId=ChainPlant.PlantProgramId

 LEFT OUTER JOIN TCD.EcolabTextileCategory ETC1 ON ETC1.TextileId=PM.EcolabTextileCategoryId
 LEFT OUTER JOIN TCD.FormulaSegments FS1 ON FS1.FormulaSegmentID=PM.FormulaSegmentId
 LEFT OUTER JOIN TCD.EcolabSaturation ES1 ON ES1.EcolabSaturationId=PM.EcolabSaturationId
 ----End

    WHERE isnull(ms.IsPony,0)=0 and

       CASE @StartDate                                                                                
       WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
       ELSE CASE WHEN PS.[StartDateTime] >= @startdate AND PS.[StartDateTime] <=  @enddate THEN 'TRUE'END                                                        
       END='TRUE'
     AND
       CASE @MachineType   
       WHEN '' THEN 'TRUE'         
       ELSE                                                      
       CASE WHEN bd.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
       MS.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable))) THEN 'TRUE' END                                                      
       END='TRUE'    
    AND    
        CASE @machineGroup   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN bd.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE      
        MS.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable)) THEN 'TRUE' END                                                      
        END='TRUE' 
    AND
        CASE @Machine   
        WHEN '' THEN 'TRUE'         
        ELSE                                                      
        CASE WHEN bd.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
        END='TRUE' 
   
    
  --Added by Kiran
 AND 
  CASE @EcolabCategory   
  WHEN '' THEN 'TRUE' 
  ELSE
   CASE WHEN PM.PlantProgramId IS NOT NULL THEN
     CASE WHEN ChainPlant.EcolabTextileCategoryId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                                                   
   ELSE 
   CASE WHEN ETC1.TextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable)  THEN 'TRUE'END 
  END  
  END='TRUE'                            
 AND 
  CASE @ChainCategory    
  WHEN '' THEN 'TRUE' 
   ELSE 
    CASE WHEN PM.PlantProgramId IS NOT NULL THEN
     CASE WHEN ChainPlant.ChainTextileCategoryId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END 
    ELSE 'TRUE' END                                                                                                                                     
  END='TRUE'
 AND    
  CASE @PlantFormula   
  WHEN '' THEN 'TRUE'         
  ELSE                                                      
  CASE WHEN bd.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                      
  END='TRUE'
    AND    
  CASE @ChainFormula   
  WHEN '' THEN 'TRUE'         
  ELSE                                                      
   CASE WHEN PM.PlantProgramId IS NOT NULL THEN
     CASE WHEN ChainPlant.ChainTextileCategoryId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END 
   ELSE 'TRUE' END                                                        
  END='TRUE'
    AND 
  CASE @FormulaSegement                                                                                
  WHEN '' THEN  'TRUE'
  ELSE
   CASE WHEN PM.PlantProgramId IS NOT NULL THEN
    CASE WHEN ChainPlant.FormulaSegmentId IN (SELECT FormulaSegment FROM @FormulaSegmentTable) THEN 'TRUE' END                                                                                     
   ELSE 
    CASE WHEN FS1.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)  THEN 'TRUE'END   
   END                                                     
  END='TRUE'

 --Result Table
    DECLARE @resultSet TABLE
    (          
        ChemicalCategoryName VARCHAR(100),
		ChemicalName VARCHAR(100),ActualConsumption DECIMAL(18,5),TargetConsumption DECIMAL(18,5),--MachineId INT,
        ProgramMasterId INT,NoOfDays INT,NoOfLoads DECIMAL(18,2),
  Cost DECIMAL(18,5),StartDateTime date,PackageSizeId int,
  UnitWeightVolumeUOMId int,packagesizeweightuomcode varchar(100)
    )
 INSERT INTO @resultSet
 (
  ChemicalCategoryName,
  ChemicalName ,ActualConsumption ,TargetConsumption ,--MachineId ,
  ProgramMasterId ,NoOfDays ,NoOfLoads ,
  Cost,StartDateTime ,PackageSizeId ,
  UnitWeightVolumeUOMId,
  packagesizeweightuomcode 
 )
	SELECT	TCD.RemoveMultipleSpaces(COALESCE(PM.ProductCategoryName, PM.SKU))	AS ChemicalCategoryName,
			TCD.RemoveMultipleSpaces(COALESCE(PM.EnvisionDisplayName, PM.Name)) AS ChemicalName,
			SUM(SCD.ActualConsumption), SUM(SCD.TargetConsumption),--SCD.MachineId,
  SCD.ProgramMasterId,COUNT(DISTINCT CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date)),@actualproduction,
  SUM(SCD.ActualCost),PS.StartDateTime,PM.PackageSizeId, 
  
  CASE WHEN pm.PackageSizeId IS NULL AND type = 'Liquid' THEN isnull(psi.UnitWeightVolumeUOMId, 6) 
    WHEN pm.PackageSizeId IS NULL AND type = 'Powder' THEN isnull(psi.UnitWeightVolumeUOMId, 12) 
    ELSE psi.UnitWeightVolumeUOMId END AS UnitWeightVolumeUOMId, 
    
  CASE 
	WHEN UPPER(type) = 'LIQUID'  AND @uomId=1   THEN 'gal'
	WHEN UPPER(type) = 'SOLID'   AND @uomId=1  THEN  'lbs'
	WHEN UPPER(type) = 'POWDER'  AND @uomId=1   THEN 'lbs'
	WHEN UPPER(type) = 'PASTE'   AND @uomId=1  THEN  'lbs'

	WHEN UPPER(type) = 'LIQUID'  AND @uomId=2   THEN 'L'
	WHEN UPPER(type) = 'SOLID'  AND @uomId=2  THEN  'kg'
	WHEN UPPER(type) = 'POWDER'  AND @uomId=2  THEN  'kg'
	WHEN UPPER(type) = 'PASTE'  AND @uomId=2  THEN  'kg'	

  WHEN @uomId=1  then 'gal'
  WHEN @uomId=2  then 'L'
 END AS packagesizeweightuomcode
    
    -- CASE WHEN pm.Type= 'Liquid' AND @uomId=1 THEN 'gal'
    -- WHEN pm.Type= 'Liquid' AND @uomId=2 THEN 'L'
    --  WHEN pm.Type= 'Powder' AND @uomId=1 THEN 'lbs'
    --   WHEN pm.Type= 'Powder' AND @uomId=2 THEN 'kgs'
    --   WHEN pm.Type Is null AND @uomId=1 THEN 'gal'
    --    WHEN pm.Type Is null AND @uomId=2 THEN 'L'
    --END AS packagesizeweightuomcode
   
 FROM 
 TCD.ShiftChemicalDataRollup SCD 
 --inner join tcd.ShiftProductionDataRollup spd on spd.ShiftId=scd.ShiftId and spd.MachineId=scd.MachineId
 INNER JOIN TCD.ProductionShiftData PS ON SCD.SHIFTID = PS.ShiftId 
 INNER JOIN TCD.ProgramMaster PRM on SCD.ProgramMasterId = PRM.ProgramId
 LEFT OUTER JOIN TCD.ProductMaster PM ON SCD.ProductId = PM.ProductId 
 INNER JOIN TCD.ProductdataMapping AS PDM ON PDM.ProductId = PM.ProductId 
 LEFT OUTER JOIN TCD.PackageSize AS PSi ON PM.PackageSizeId = PSi.PackageSizeId
 --Added by Kiran For Formula Hierarchy 
 LEFT OUTER JOIN
   (
   --IF Chain Plant
   SELECT PCP.PlantProgramId,PCP.PlantChainId,PCP.ChainTextileCategoryId,PCP.EcolabTextileCategoryId,
   PCP.FormulaSegmentId,PCP.EcolabSaturationId
   FROM TCD.PlantChainProgram PCP 
   LEFT OUTER JOIN TCD.ChainTextileCategory CTC ON CTC.TextileId=PCP.ChainTextileCategoryId
   LEFT OUTER JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId=PCP.EcolabTextileCategoryId
   LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=PCP.FormulaSegmentId
   LEFT OUTER JOIN TCD.EcolabSaturation ES ON ES.EcolabSaturationId=PCP.EcolabSaturationId
   )ChainPlant ON PRM.PlantProgramId=ChainPlant.PlantProgramId

 LEFT OUTER JOIN TCD.EcolabTextileCategory ETC1 ON ETC1.TextileId=PRM.EcolabTextileCategoryId
 LEFT OUTER JOIN TCD.FormulaSegments FS1 ON FS1.FormulaSegmentID=PRM.FormulaSegmentId
 LEFT OUTER JOIN TCD.EcolabSaturation ES1 ON ES1.EcolabSaturationId=PRM.EcolabSaturationId
 ----End
 WHERE    
  SCD.machineID IN (SELECT ms.WasherId FROM TCD.MachineSetup AS ms WHERE isNull(ms.IsPony,0) = 0) -- Exclude pony washers
  AND
   CASE @StartDate                                                                                
      WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                
      ELSE CASE WHEN PS.[StartDateTime] >= @startdate AND PS.[StartDateTime] <=  @enddate THEN 'TRUE'END                                                        
      END='TRUE'
  AND
   CASE @MachineType   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SCD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE     
    MS.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable))) THEN 'TRUE' END                                                      
    END='TRUE'     
  AND   
   CASE @machineGroup   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SCD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE   
    MS.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable)) THEN 'TRUE' END                                                      
    END='TRUE' 
  AND
   CASE @Machine   
    WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SCD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
    END='TRUE' 
  AND  
   CASE @EcolabCategory   
   WHEN '' THEN 'TRUE'         
   ELSE                                                      
   CASE WHEN SCD.EcolabTextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                      
   END='TRUE' 
  AND
    
   CASE @ChainCategory   
   WHEN '' THEN 'TRUE'         
   ELSE                                                      
   CASE WHEN SCD.ChainTextileId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END                                                      
   END='TRUE'
  AND

   CASE @PlantFormula   
   WHEN '' THEN 'TRUE'         
   ELSE                                                      
   CASE WHEN SCD.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                      
   END='TRUE'  
  AND
    
   CASE @ChainFormula   
   WHEN '' THEN 'TRUE'         
   ELSE                                                      
   CASE WHEN SCD.ProgramMasterId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END                                                      
   END='TRUE'
  AND
  
   CASE @Customer   
   WHEN '' THEN 'TRUE'         
    ELSE                                                      
    CASE WHEN SCD.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                      
   END='TRUE'
  AND 
   CASE @FormulaSegement                                                                                
   WHEN '' THEN  'TRUE'
   ELSE
    CASE WHEN PRM.PlantProgramId IS NOT NULL THEN
     CASE WHEN ChainPlant.FormulaSegmentId IN (SELECT FormulaSegment FROM @FormulaSegmentTable) THEN 'TRUE' END                                                                                     
    ELSE 
     CASE WHEN FS1.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)  THEN 'TRUE'END   
    END                                                     
   END='TRUE'

	GROUP BY
			COALESCE(PM.ProductCategoryName, PM.SKU),
			COALESCE(PM.EnvisionDisplayName, PM.Name),
			SCD.ProgramMasterId,PS.StartDateTime,pm.PackageSizeId,psi.UnitWeightVolumeUOMId,psi.packagesizeweightuomcode,pm.type


    DECLARE @Exchangerate TABLE (ChemicalName VARCHAR(100), Cost DECIMAL(18,2))  

    INSERT INTO @Exchangerate(ChemicalName,Cost)        
    SELECT ChemicalName,SUM(Cost)
    FROM
        (
   SELECT  ChemicalName AS ChemicalName,
   SUM(ISNULL(Cost,0)) * ISNULL([TCD].[FnCurrencyExchangeRate](@CurrencyCode,StartDateTime),1) AS Cost
   FROM @resultSet
   GROUP BY ChemicalName,StartDateTime
        ) A
         GROUP BY A.ChemicalName

	
	-- View by product
	IF(@View = 10)
             BEGIN
                SELECT
            ChemicalName, 
            SUM(ActualConsumption)AS ActualConsumption, 
            SUM(A.TargetConsumption)AS TargetConsumption, 
            @Batchcount AS ProgramCount, 
            MAX(NoOfLoads)AS NoOfLoads, 
            MAX(A.NoOfDays)AS NoOfDays, 
            SUM(Cost)AS Cost, 
            SUM(TargetCost)AS TargetCost, 
            SUM(ActualConsumptionMetrics)AS ActualConsumptionMetrics, 
            MAX(packagesizeweightuomcode)AS UOM,
	    @view AS ViewType
        FROM(SELECT
                     rs.ChemicalName, 
                     CAST(ISNULL(TCD.UnitConversionbyUserUOM(SUM(rs.ActualConsumption), ISNULL(packagesizeweightuomcode, 'gal'), @Userid), 0)AS
DECIMAL(18, 2))AS ActualConsumption, 
                     CAST(ISNULL(TCD.UnitConversionbyUserUOM(SUM(rs.TargetConsumption), ISNULL(packagesizeweightuomcode, 'gal'), @Userid), 0)AS
DECIMAL(18, 2))AS TargetConsumption, 
                     MAX(NoOfLoads)AS NoOfLoads, 
                     SUM(rs.Cost)AS Cost, 
                     COUNT(ProgramMasterId)AS ProgramCount, 
                     COUNT(DISTINCT rs.StartDateTime)AS NoOfDays, 
                     PackageSizeId, 
                     UnitWeightVolumeUOMId, 
                     packagesizeweightuomcode, 
                     CAST(CAST(SUM(rs.Cost)AS DECIMAL(18, 2)) / CASE
                                                                    WHEN SUM(ActualConsumption) = 0 THEN 1
                                                                    ELSE SUM(ActualConsumption)
                                                                END * ISNULL(SUM(TargetConsumption), 0)AS DECIMAL(18, 2))AS TargetCost, 
                     CASE
                         WHEN @Uom = 2
                          AND packagesizeweightuomcode = 'L' THEN CAST(ISNULL(TCD.UnitConversionbyUserUOM(SUM(ActualConsumption), ISNULL('mL', 'L'),
@Userid), 0)AS DECIMAL(18, 2))
                         WHEN @Uom = 2
                          AND packagesizeweightuomcode = 'kg' THEN CAST(ISNULL(TCD.UnitConversionbyUserUOM(SUM(ActualConsumption), ISNULL('g', 'kg'),
@Userid), 0)AS DECIMAL(18, 2))
                         ELSE SUM(ActualConsumption)
                     END AS ActualConsumptionMetrics,
		     @View AS ViewType
		     
                 FROM @Resultset AS rs
                      INNER JOIN @Exchangerate AS e ON rs.ChemicalName = e.ChemicalName
                 GROUP BY
                     rs.ChemicalName, 
                     PackageSizeId, 
                     UnitWeightVolumeUOMId, 
                     packagesizeweightuomcode)AS A
        GROUP BY
            A.ChemicalName;
             END;

	-- View by product category
	IF(@View = 11)
	BEGIN  
		SELECT
				ChemicalName,
				CAST(ISNULL([TCD].[UnitConversionbyUserUOM](ActualConsumption,isnull(packagesizeweightuomcode,'gal'),@UserId),0)as decimal(18,2)),
				CAST(ISNULL([TCD].[UnitConversionbyUserUOM](TargetConsumption,isnull(packagesizeweightuomcode,'gal'),@UserId),0) as decimal(18,2)),
				@BatchCount ProgramCount,
				NoOfLoads,
				NoOfDays,
				Cost,
				CAST(((cast(Cost AS decimal(18,2))/ (CASE WHEN ActualConsumption =0 THEN 1 ELSE ActualConsumption end)) * ISNULL(TargetConsumption,0)) AS DECIMAL(18,2)) AS TargetCost,
 
				CASE 
					WHEN @uom=2 AND packagesizeweightuomcode='L'  THEN CAST(ISNULL([TCD].[UnitConversionbyUserUOM](ActualConsumption,isnull('mL','L'),@UserId),0) AS DECIMAL(18,2)) 
					WHEN @uom=2 AND packagesizeweightuomcode='kg' THEN CAST(ISNULL([TCD].[UnitConversionbyUserUOM](ActualConsumption,isnull('g','kg'),@UserId),0) AS DECIMAL(18,2))
					ELSE ActualConsumption
				END AS ActualConsumptionMetrics, 

				packagesizeweightuomcode as UOM, ViewType
		FROM (
			SELECT
					COALESCE(r.ChemicalCategoryName, r.ChemicalName) AS ChemicalName,
					SUM(ActualConsumption) AS ActualConsumption,
					SUM(TargetConsumption) AS TargetConsumption,
					COUNT(ProgramMasterId) AS ProgramCount,
					COUNT(DISTINCT r.StartDateTime) AS NoOfDays,
					MAX(NoOfLoads) AS NoOfLoads,
					SUM(r.Cost) AS Cost,
					r.packagesizeweightuomcode, @View AS ViewType
			FROM	@resultSet r
			
			GROUP BY 
					COALESCE(r.ChemicalCategoryName, r.ChemicalName)
					,r.packagesizeweightuomcode
		) A
	END

SET NOCOUNT OFF
END