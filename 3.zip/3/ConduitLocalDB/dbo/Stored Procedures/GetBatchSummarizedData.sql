﻿CREATE PROCEDURE TCD.GetBatchSummarizedData(
       @Dashboardid INT = NULL)
AS
BEGIN

/*	                                   
###################################################################################################                                           

Stored Procedure:       TCD.GetBatchSummarizedData                                            

Purpose:				Dashboard procedure for tunnel

Parameters:				@DashboardID- need to specify the tunnel dashboard id, refer tcd.dashboard
																
###################################################################################################                                           
*/

    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    SET NOCOUNT ON;
    DECLARE   --@DashBoardId INT = 3, 
              @Efficiencytype INT, 
              @Overnightbatchthreshold INT = 7200, 
              --Thershold should be 2hrs
              @Regionid INT, 
              @Ecolabaccountnumber NVARCHAR(25), 
              @Shifthrs INT = 1, 
              @Timeefficiencymaxcap FLOAT, 
              @Loadefficiencymaxcap FLOAT, 
              @Const_100 FLOAT = 100, 
              @Controllermodelid INT;
    DECLARE @Dashboardmachinemapping TABLE(
            Id INT, 
            GroupId INT, 
            WasherId INT, 
            DisplayCustomer BIT, 
            WasherName NVARCHAR(100), 
            WasherNumber INT, 
            IsPLCConnected BIT, 
            DispenserName VARCHAR(250));
    DECLARE @Summarizeddata TABLE(
            GroupId INT, 
            TunnelName NVARCHAR(100), 
            TargetLoad FLOAT, 
            ActualLoad FLOAT, 
            LoadEfficiency FLOAT, 
            TimeEfficiency FLOAT, 
            LostLBS FLOAT, 
            TransferPerHr FLOAT, 
            SignalStatus INT, 
            EmptyPockets INT, 
            Alarm BIT, 
            TransferPercent DECIMAL(10, 2), 
            EndOfFormula INT, 
            DisplayCustomer BIT, 
            WasherNumber INT, 
            IsPLCConnected BIT, 
            DispenserName VARCHAR(250), 
            LostBatches DECIMAL(18, 6), 
            OverAllEfficiency DECIMAL(18, 6));
    DECLARE @Shiftids TABLE(
            ShiftId INT, 
            ShiftStartDate DATETIME, 
            ShiftEndDate DATETIME);
    SELECT
            @Efficiencytype = ISNULL(EfficiencyCalcType, 1), 
            @Ecolabaccountnumber = EcolabAccountNumber
        FROM tcd.Dashboard
        WHERE DashboardId = @Dashboardid;
    SELECT
            @Regionid = RegionId
        FROM TCD.Plant
        WHERE EcolabAccountNumber = @Ecolabaccountnumber;

    SELECT
            @Timeefficiencymaxcap = CAST(Value AS FLOAT)
        FROM tcd.ConfigSettings
        WHERE KeyName = 'TimeEfficiencyMaxCapValue'
          AND TYPE = 'MAXCAP';

    SELECT
            @Loadefficiencymaxcap = CAST(Value AS FLOAT)
        FROM tcd.ConfigSettings
        WHERE KeyName = 'LoadEfficiencyMaxCapValue'
          AND TYPE = 'MAXCAP';


    DECLARE @Formsignalstatusforeu TABLE(
            TransferSignal INT, 
            RunState INT, 
            GroupID INT, 
            WasherID INT);
    SELECT TOP 1
            @Controllermodelid = CC.ControllerModelId
        FROM TCD.MonitorSetUpMapping AS DM
             INNER JOIN TCD.MachineSetup AS MS ON DM.MachineId = MS.WasherID
             INNER JOIN TCD.Dashboard AS D ON DM.DashBoardId = D.DashBoardId --INNER JOIN TCD.Washer w ON ms.WasherId = w.WasherId
             INNER JOIN TCD.ConduitController AS CC ON CC.ControllerId = MS.ControllerId
        WHERE DM.DashboardId = @Dashboardid;
    INSERT INTO @Formsignalstatusforeu(
            TransferSignal, 
            RunState, 
            GroupID, 
            WasherID)
    SELECT DISTINCT
            obd.TransferSignal, 
            obd.RunState, 
            MS.GroupId, 
            MS.WasherId
        FROM TCD.MonitorSetUpMapping AS DM
             INNER JOIN TCD.MachineSetup AS MS ON DM.MachineId = MS.WasherID
             INNER JOIN TCD.Dashboard AS D ON DM.DashBoardId = D.DashBoardId
             INNER JOIN tcd.OnlineBatchData AS obd ON obd.ControllerId = ms.ControllerId
                                                  AND obd.GroupID = ms.GroupId
                                                  AND obd.MachineID = ms.WasherId
        WHERE DM.DashboardId = @Dashboardid
          AND obd.CompartmentNumber = 1;
    INSERT INTO @Dashboardmachinemapping(
            Id, 
            GroupId, 
            WasherId, 
            DisplayCustomer, 
            WasherName, 
            WasherNumber, 
            IsPLCConnected, 
            DispenserName)
    SELECT
            ROW_NUMBER()OVER(ORDER BY GroupID)AS Id, 
            A.GroupId, 
            A.WasherId, 
            A.Customer, 
            A.WasherName, 
            A.WasherNumber, 
            A.IsPLCConnected, 
            DispenserName
        FROM(SELECT DISTINCT
                     MS.GroupId, 
                     MS.WasherId, 
                     D.Customer, 
                     MS.MachineName AS WasherName, 
                     w.PlantWasherNumber AS WasherNumber, 
                     CASE
                         WHEN ISNULL(IsActive, 0) = 0 THEN CAST(1 AS BIT)
                         WHEN ISNULL(IsActive, 0) = 1 THEN CAST(0 AS BIT)
                     END AS IsPLCConnected, 
                     CAST(CC.ControllerNumber AS NVARCHAR) + ' (' + CC.TopicName + ')' AS DispenserName
                 FROM TCD.MonitorSetUpMapping AS DM
                      INNER JOIN TCD.MachineSetup AS MS ON DM.MachineId = MS.WasherID
                      INNER JOIN TCD.Dashboard AS D ON DM.DashBoardId = D.DashBoardId
                      INNER JOIN TCD.Washer AS w ON ms.WasherId = w.WasherId
                      INNER JOIN TCD.ConduitController AS CC ON CC.ControllerId = MS.ControllerId
                      LEFT JOIN TCD.AlarmData AS AD ON AD.ControllerId = MS.ControllerId
                                                   AND IsActive = 1
                                                   AND AD.AlarmCode = CASE
                                                                          WHEN(
             SELECT
                     VALUE
                 FROM TCD.controllerSetupData AS CSD
                      LEFT JOIN TCD.Field AS F ON F.Id = CSD.FieldId
                 WHERE F.Label = 'Webport Ftp Enabled'
                   AND CSD.ControllerId = AD.ControllerId
                   AND CC.ControllerTypeId = 1) = 'true' THEN 9002
                                                                          ELSE 9001
                                                                      END
                 WHERE DM.DashboardId = @Dashboardid
                   AND ms.IsDeleted = 0
                   AND w.Is_Deleted = 0)AS A;  
   
  
  
    -- For efficiency calculations on shift wise  
    IF @Efficiencytype = 1
        BEGIN
            INSERT INTO @Shiftids(
                    shiftId, 
                    ShiftStartDate, 
                    ShiftEndDate)
            SELECT DISTINCT
                    ShiftId, 
                    StartDateTime, 
                    EndDateTime
                FROM TCD.ProductionShiftData  
                --WHERE ShiftId =   1105
                WHERE GETUTCDATE()BETWEEN StartDateTime AND EndDateTime;
        END;
    ELSE -- For efficiency calculations on Day wise  
        BEGIN
            INSERT INTO @Shiftids(
                    ShiftId, 
                    ShiftStartDate, 
                    ShiftEndDate)
            SELECT DISTINCT
                    ShiftId, 
                    StartDateTime, 
                    EndDateTime
                FROM TCD.ProductionShiftData
                WHERE startdatetime > CAST(GETUTCDATE()AS DATE)
                  AND startdatetime < DATEADD(dd, 1, CAST(GETUTCDATE()AS DATE));
        END;
    SELECT
            * INTO
            #BatchData
        FROM tcd.BatchData AS bd(NOLOCK)
        WHERE bd.ShiftId IN(SELECT
                                    si.ShiftId FROM @Shiftids AS si)
          AND bd.StandardWeight > 0
          AND bd.ActualWeight > 0
          AND bd.EndDate IS NOT NULL;


    SELECT
            @Shifthrs = ISNULL(NULLIF(DATEDIFF(hh, (SELECT
                                                            MIN(ShiftStartDate)FROM @Shiftids), MAX(Enddate)), 0), 1)
        FROM #BatchData;
  
    -- Efficiency for each batch   
    SELECT
            bd.BatchId, 
            bd.GroupID, 
            bd.MachineID, 
            bd.ShiftId, 
            W_1.WasherNumber, 
            W_1.WasherName, 
            bd.ActualWeight + ISNULL(BD.ManualInputWeight, 0)AS ActualProduction, 
            bd.StandardWeight AS StandardProduction, 
            CASE
                WHEN DATEDIFF(SS, bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @Overnightbatchthreshold THEN W_1.Standardruntime
                ELSE DATEDIFF(second, bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
            END AS ActualRunTime, 
            W_1.StandardRunTime, 
            NULL AS ActualTurnTime, 
            bd.TargetTurnTime AS StandardTurnTime, 
            CASE
                WHEN W_1.WasherGroupTypeID = 2 THEN CASE
                                                        WHEN CAST(NULLIF(W_1.Standardruntime, 0)AS FLOAT) / CAST(CASE
                                                                                                                     WHEN DATEDIFF(second, bd.
StartDate, ISNULL(bd.EndDate, GETDATE())) = 0 THEN W_1.Standardruntime
                                                                                                                     WHEN DATEDIFF(ss, bd.StartDate,
ISNULL(bd.EndDate, GETDATE())) > @Overnightbatchthreshold THEN W_1.StandardRunTime
                                                                                                                     ELSE DATEDIFF(ss, bd.StartDate,
ISNULL(bd.EndDate, GETDATE()))
                                                                                                                 END AS FLOAT) * 100 >=
@Timeefficiencymaxcap THEN @Timeefficiencymaxcap / 100
                                                        ELSE CAST(NULLIF(W_1.Standardruntime, 0)AS FLOAT) / CAST(CASE
                                                                                                                     WHEN DATEDIFF(second, bd.
StartDate, ISNULL(bd.EndDate, GETDATE())) = 0 THEN W_1.Standardruntime
                                                                                                                     WHEN DATEDIFF(ss, bd.StartDate,
ISNULL(bd.EndDate, GETDATE())) > @Overnightbatchthreshold THEN W_1.StandardRunTime
                                                                                                                     ELSE DATEDIFF(ss, bd.StartDate,
ISNULL(bd.EndDate, GETDATE()))
                                                                                                                 END AS FLOAT)
                                                    END
            END AS TimeEfficiency, 
            CASE
                WHEN CAST(bd.ActualWeight + ISNULL(BD.ManualInputWeight, 0)AS FLOAT) / CAST(NULLIF(bd.StandardWeight, 0)AS FLOAT) * 100 >=
@Loadefficiencymaxcap THEN @Loadefficiencymaxcap
                ELSE CAST(bd.ActualWeight + ISNULL(BD.ManualInputWeight, 0)AS FLOAT) / CAST(NULLIF(bd.StandardWeight, 0)AS FLOAT) * 100
            END AS LoadEfficiency, 
            CASE
                WHEN bd.StartDate BETWEEN psd.StartDateTime AND psd.EndDateTime THEN 1
                ELSE 0
            END AS NoOfLoadsinCurrentShift, 
            --missedloads formulae
            --------(((Actual Production/totalefficiency)*100)-actualproduction)
  
            (CAST(bd.ActualWeight AS DECIMAL(18, 6)) / CAST(CASE
                                                                WHEN CAST(bd.ActualWeight + ISNULL(BD.ManualInputWeight, 0)AS DECIMAL(18, 6)) / CAST(
NULLIF(bd.StandardWeight, 0)AS DECIMAL(18, 2)) * 100.0 >= @Loadefficiencymaxcap THEN @Loadefficiencymaxcap
                                                                ELSE CAST(bd.ActualWeight + ISNULL(BD.ManualInputWeight, 0)AS DECIMAL(18, 6)) / CAST(
NULLIF(bd.StandardWeight, 0)AS DECIMAL(18, 2)) * 100.0
                                                            END * CASE
                                                                      WHEN W_1.WasherGroupTypeID = 2 THEN CASE
                                                                                                              WHEN CAST(NULLIF(W_1.Standardruntime, 0)
AS FLOAT) / CAST(CASE
                     WHEN DATEDIFF(second, bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0 THEN W_1.Standardruntime
                     WHEN DATEDIFF(ss, bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @Overnightbatchthreshold THEN W_1.StandardRunTime
                     ELSE DATEDIFF(ss, bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
                 END AS FLOAT) * 100 >= @Timeefficiencymaxcap THEN @Timeefficiencymaxcap / 100
                                                                                                              ELSE CAST(NULLIF(W_1.Standardruntime, 0)
AS FLOAT) / CAST(CASE
                     WHEN DATEDIFF(second, bd.StartDate, ISNULL(bd.EndDate, GETDATE())) = 0 THEN W_1.Standardruntime
                     WHEN DATEDIFF(ss, bd.StartDate, ISNULL(bd.EndDate, GETDATE())) > @Overnightbatchthreshold THEN W_1.StandardRunTime
                     ELSE DATEDIFF(ss, bd.StartDate, ISNULL(bd.EndDate, GETDATE()))
                 END AS FLOAT)
                                                                                                          END
                                                                  END AS DECIMAL(18, 6)) * 100) - CAST(bd.ActualWeight AS DECIMAL(18, 6))AS
MissedLoads, 
            CASE
                WHEN CAST(bd.ActualWeight + ISNULL(BD.ManualInputWeight, 0)AS FLOAT) / CAST(NULLIF(bd.StandardWeight, 0)AS FLOAT) * 100 >=
@Loadefficiencymaxcap THEN @Loadefficiencymaxcap
                ELSE CAST(bd.ActualWeight + ISNULL(BD.ManualInputWeight, 0)AS FLOAT) / CAST(NULLIF(bd.StandardWeight, 0)AS FLOAT) * 100
            END * CASE
                      WHEN W_1.WasherGroupTypeID = 2 THEN CASE
                                                              WHEN CAST(NULLIF(W_1.Standardruntime, 0)AS FLOAT) / CAST(CASE
                                                                                                                           WHEN DATEDIFF(second, bd.
StartDate, ISNULL(bd.EndDate, GETDATE())) = 0 THEN W_1.Standardruntime
                                                                                                                           WHEN DATEDIFF(ss, bd.
StartDate, ISNULL(bd.EndDate, GETDATE())) > @Overnightbatchthreshold THEN W_1.StandardRunTime
                                                                                                                           ELSE DATEDIFF(ss, bd.
StartDate, ISNULL(bd.EndDate, GETDATE()))
                                                                                                                       END AS FLOAT) * 100 >=
@Timeefficiencymaxcap THEN @Timeefficiencymaxcap / 100
                                                              ELSE CAST(NULLIF(W_1.Standardruntime, 0)AS FLOAT) / CAST(CASE
                                                                                                                           WHEN DATEDIFF(second, bd.
StartDate, ISNULL(bd.EndDate, GETDATE())) = 0 THEN W_1.Standardruntime
                                                                                                                           WHEN DATEDIFF(ss, bd.
StartDate, ISNULL(bd.EndDate, GETDATE())) > @Overnightbatchthreshold THEN W_1.StandardRunTime
                                                                                                                           ELSE DATEDIFF(ss, bd.
StartDate, ISNULL(bd.EndDate, GETDATE()))
                                                                                                                       END AS FLOAT)
                                                          END
                  END AS TotalEfficiency, 
            w_1.maxload INTO
            #BatchEfficiency
        FROM #BatchData AS bd
             INNER JOIN TCD.WasherFormulaRunTimes AS W_1 ON BD.GroupId = W_1.WasherGroupID
                                                        AND BD.MachineId = W_1.WasherId
                                                        AND BD.ProgramMasterId = W_1.ProgramId
                                                        AND BD.ProgramNumber = W_1.ProgramNumber
             LEFT JOIN TCD.ProductionShiftData AS psd ON psd.ShiftId = BD.ShiftId
        WHERE W_1.IsTunnel = 1;

    -- Efficiency by Machine calculation   
    SELECT
            DM.GroupID, 
            DM.WasherId AS MachineID, 
            DM.WasherNumber, 
            DM.WasherName, 
            CAST(SUM(t.ActualProduction)AS FLOAT)AS ActualProduction, 
            CAST(SUM(t.StandardProduction)AS FLOAT)AS StandardProduction, 
            SUM(t.ActualRunTime)AS ActualRuntime, 
            SUM(t.StandardRunTime)AS StandardRunTime, 
            ISNULL(SUM(IIF(t.MissedLoads < 0, 0, t.MissedLoads)), 0)AS MissedLoads, 
            CAST(SUM(t.LoadEfficiency)AS FLOAT) / COUNT(DISTINCT t.BatchId)AS LoadEfficiency, 
            CAST(SUM(t.TimeEfficiency)AS FLOAT) / COUNT(DISTINCT t.BatchId)AS TimeEfficiency, 
            SUM(NoOfLoadsinCurrentShift) / @Shifthrs AS TransferPerHour, 
            CAST(SUM(T.StandardProduction * T.LoadEfficiency * t.TimeEfficiency)AS FLOAT) / CAST(SUM(T.StandardProduction)AS FLOAT)AS TotalEfficiency, 
            DM.IsPLCConnected AS IsPLCConnected, 
            DM.DispenserName, 
            ISNULL(SUM(CASE
                           WHEN @Regionid = 1 THEN ISNULL(IIF(t.MissedLoads < 0, 0, t.MissedLoads), 0)
                           ELSE ROUND(ISNULL(IIF(t.MissedLoads < 0, 0, t.MissedLoads), 0) * 0.453592, 0)
                       END) / CASE
                                  WHEN MAX(t.MaxLoad) = 0 THEN 1
                                  ELSE MAX(t.MaxLoad)
                              END, 0)AS LostBatches INTO
            #MachineEfficiency
        FROM @Dashboardmachinemapping AS DM
             LEFT JOIN #BatchEfficiency AS t ON DM.GroupID = t.GroupId
                                            AND dm.WasherId = t.MachineId
        GROUP BY
            DM.GroupID, 
            DM.WasherId, 
            DM.WasherNumber, 
            DM.WasherName, 
            DM.IsPLCConnected, 
            DM.DispenserName;

    --SELECT s.* FROM @Shiftids s
    --SELECT bd.* FROM dbo.#BatchData bd
    --SELECT be.* FROM dbo.#BatchEfficiency be
    --SELECT be.* FROM dbo.#BatchEfficiency be WHERE be.MissedLoads > 0
    --SELECT me.* FROM dbo.#MachineEfficiency me


    DECLARE @Emptypocketnalarmddata TABLE(
            GroupId INT, 
            WasherID INT, 
            EndOfFormula INT, 
            DisplayCustomer DECIMAL(18, 2), 
            EmptyPockets INT, 
            MachineNameDispalyType INT, 
            EmptyPocketLoad DECIMAL(18, 2), 
            Alarm BIT, 
            WasherStatus INT, 
            ControllerId INT);
    INSERT INTO @Emptypocketnalarmddata(
            GroupId, 
            WasherID, 
            EndOfFormula, 
            DisplayCustomer, 
            EmptyPockets, 
            MachineNameDispalyType, 
            EmptyPocketLoad, 
            Alarm, 
            WasherStatus, 
            ControllerId)
    SELECT
            D.GroupId, 
            D.WasherId, 
            w.EmptyPocketNumber AS EndOfFormula, 
            D.DisplayCustomer, 
            A.EmptyPockets, 
            (SELECT
                     SUM(ISNULL(MachineNameDispalyType, 0))
                 FROM TCD.Dashboard AS D1
                      INNER JOIN TCD.MonitorSetUpMapping AS MSM ON D1.DashboardId = MSM.DashboardId
                 WHERE MSM.MachineId = D.WasherId
                   AND D1.DashboardId = @Dashboardid)AS MachineNameDispalyType, 
            SUM(w.MaxLoad)AS EmptyPocketLoad, 
            NULL AS alarm, 
            CASE
                WHEN @Controllermodelid <> 7
                 AND @Regionid = 1 THEN SUM(CASE
                                                WHEN B.WasherStatus > 0 THEN 1
                                                ELSE 0
                                            END)
                ELSE 
            -- 1 - No Transfer, 2- Transfer, 3- Stop
            (CASE
                 WHEN fssfe.TransferSignal = 0
                  AND fssfe.RunState = 1 THEN 1        --1 - No Transfer
                 WHEN fssfe.TransferSignal = 1
                  AND fssfe.RunState = 1 THEN 2        -- 2 - Transfer
                 WHEN fssfe.RunState = 0 THEN 3       -- 3- Stop
             END)
            END AS WasherStatus, 
            (SELECT
                     MS.ControllerId
                 FROM TCD.MachineSetup AS MS
                 WHERE MS.WasherId = D.washerid
                   AND MS.IsDeleted = 0)
        FROM TCD.Washer AS w
             INNER JOIN @Dashboardmachinemapping AS D ON w.WasherId = d.WasherId
             LEFT OUTER JOIN @Formsignalstatusforeu AS fssfe ON fssfe.WasherID = d.WasherId
             CROSS APPLY(SELECT
                                 COUNT(*)AS EmptyPockets
                             FROM TCD.BatchData AS b
                                  JOIN @Shiftids AS s ON b.ShiftId = s.ShiftId
                             WHERE b.StartDate >= s.ShiftStartDate
                               AND b.GroupId = d.GroupId
                               AND b.ProgramNumber = w.EmptyPocketNumber)AS A
                        CROSS APPLY(SELECT
                                            COUNT(*)AS WasherStatus
                                        FROM tcd.BatchData
                                        WHERE MachineId = d.WasherId
                                          AND GroupId = D.GroupId
                                          AND (EndDate >= DATEADD(mi, -30, GETUTCDATE())
                                            OR EndDate IS NULL))AS B
        GROUP BY
            D.GroupId, 
            D.WasherId, 
            w.EmptyPocketNumber, 
            D.DisplayCustomer, 
            A.EmptyPockets, 
            fssfe.TransferSignal, 
            fssfe.RunState;
    UPDATE X SET
            X.Alarm = ISNULL(Alarm.IsActive, 0)
        FROM @Emptypocketnalarmddata X
             CROSS APPLY(SELECT TOP 1
                                 AD.IsActive
                             FROM TCD.AlarmData AS AD
                             WHERE GroupId = X.GroupId
                                OR AD.ControllerId = X.ControllerId
                             ORDER BY
                                 StartDate DESC)AS Alarm;
    INSERT INTO @Summarizeddata(
            GroupId, 
            TunnelName, 
            TargetLoad, 
            ActualLoad, 
            LoadEfficiency, 
            TimeEfficiency, 
            LostLBS, 
            TransferPerHr, 
            SignalStatus, 
            EmptyPockets, 
            Alarm, 
            TransferPercent, 
            EndOfFormula, 
            DisplayCustomer, 
            WasherNumber, 
            IsPLCConnected, 
            DispenserName, 
            lostbatches, 
            OverAllEfficiency)
    SELECT
            me.GroupID, 
            CASE epn.MachineNameDispalyType
                WHEN 0 THEN CAST(me.WasherNumber AS VARCHAR(20)) + ' ' + me.WasherName
                WHEN 1 THEN me.WasherName
                WHEN 2 THEN CAST(me.WasherNumber AS VARCHAR(20))
            END AS TunnelName, 
            me.StandardProduction, 
            me.ActualProduction, 
            me.LoadEfficiency, 
            me.TimeEfficiency, 
            me.MissedLoads, 
            me.TransferPerHour, 
            epn.WasherStatus, 
            epn.EmptyPockets, 
            ISNULL(epn.Alarm, 0)AS Alarm, 
            0 AS TransferPercent, 
            epn.EndOfFormula, 
            epn.DisplayCustomer, 
            me.WasherNumber, 
            me.IsPLCConnected AS IsPLCConnected, 
            me.DispenserName AS DispenserName, 
            me.LostBatches, 
            me.TotalEfficiency
        FROM #MachineEfficiency AS me
             LEFT JOIN @Emptypocketnalarmddata AS epn ON me.GroupID = epn.GroupId
                                                     AND me.MachineID = epn.WasherID;
    DECLARE @Avg_Efficiency DECIMAL(18, 2);
    WITH CTE_Avg_Efficiency
        AS (SELECT
                    SUM(CASE
                            WHEN @Regionid = 1 THEN ISNULL(TargetLoad, 0)
                            ELSE ROUND(ISNULL(TargetLoad, 0) * 0.453592, 0)
                        END * OverAllEfficiency) / SUM(CASE
                                                           WHEN @Regionid = 1 THEN ISNULL(TargetLoad, 0)
                                                           ELSE ROUND(ISNULL(TargetLoad, 0) * 0.453592, 0)
                                                       END)AS AVG_EFF
                FROM @Summarizeddata)
        SELECT
                @Avg_Efficiency = AVG_EFF FROM CTE_Avg_Efficiency;
    SELECT
            GroupId, 
            TunnelName, 
            CASE
                WHEN @Regionid = 1 THEN ISNULL(TargetLoad, 0)
                ELSE ROUND(ISNULL(TargetLoad, 0) * 0.453592, 0)
            END AS TargetLoad, 
            CASE
                WHEN @Regionid = 1 THEN ISNULL(ActualLoad, 0)
                ELSE ROUND(ISNULL(ActualLoad, 0) * 0.453592, 0)
            END AS ActualLoad, 
            LoadEfficiency, 
            TimeEfficiency, 
            CASE
                WHEN ISNULL(LostLBS, 0) < 0 THEN 0
                ELSE LostLBS
            END AS LostLBS, 
            TransferPerHr, 
            SignalStatus, 
            EmptyPockets, 
            Alarm, 
            TransferPercent, 
            EndOfFormula, 
            DisplayCustomer, 
            WasherNumber, 
            IsPLCConnected, 
            DispenserName, 
            CASE
                WHEN ISNULL(LostBatches, 0) < 0 THEN 0
                ELSE LostBatches
            END AS LostBatches, 
            CAST(@Avg_Efficiency AS INT)AS AverageEfficiency
        FROM @Summarizeddata
        ORDER BY
            WasherNumber;  
 
    -- CleanUp  
    DROP TABLE
            #BatchData;
    DROP TABLE
            #BatchEfficiency;
    DROP TABLE
            #MachineEfficiency;
END;
