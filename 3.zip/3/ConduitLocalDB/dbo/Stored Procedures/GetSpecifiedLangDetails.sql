﻿
/*  
 ==========================================================================================  
 Purpose:  Using the entire application to fetch the specified langauge keys.  

 Author:  Premchand Yelavarthi  

 --------------------------------------------------------------  
 July-08-2014 ENT: Initial version.  
 ==========================================================================================  
*/ 
CREATE PROCEDURE [TCD].[GetSpecifiedLangDetails] (@Locale VARCHAR(50)) 
AS 
  BEGIN 
      SET nocount ON; 

      SELECT resourcekeys.[key], 
             resourcekeys.value 
      FROM   [TCD].resourcekeys 
      WHERE  ResourceId = @Locale 
  END 