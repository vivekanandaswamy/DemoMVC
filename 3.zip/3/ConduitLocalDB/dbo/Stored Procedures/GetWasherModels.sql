﻿/*	
Purpose					:	To populate the drop-down (Model) in the Washer setup --> Tunnel-General tab

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version

*/
CREATE	PROCEDURE	[TCD].[GetWasherModels]
					@RegionId								SMALLINT
				,	@ModelType								VARCHAR(30)
AS
BEGIN

SET	NOCOUNT	ON


DECLARE	@ModelTypeId					TINYINT	= NULL

--ModelType to MdelTypeID
IF		@ModelType			=	'Conventional'
	BEGIN
		SET	@ModelTypeId	=	1
	END
ELSE
	BEGIN
		SET	@ModelTypeId	=	2
	END


SELECT	DISTINCT
		WMS.WasherModelName					AS			WasherModelName
FROM	[TCD].WasherModelSize						WMS
WHERE	WMS.RegionId						=			@RegionId
	AND	WMS.ModelTypeId						=			@ModelTypeId	
	AND	WMS.Is_Deleted						=			'FALSE'


SET	NOCOUNT	OFF

END