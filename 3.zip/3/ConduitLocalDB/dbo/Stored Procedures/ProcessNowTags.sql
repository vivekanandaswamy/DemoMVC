﻿CREATE PROCEDURE [TCD].[ProcessNowTags]
(	
	@ControllerId INT,	
	@xmlTags XML
)

AS
SET NOCOUNT ON
BEGIN
		DECLARE @BatchID INT,
				@AlarmCode INT,				
				@GroupId INT,		
				@Valve INT,
				@ProgramId INT,
				@MachineNumber INT,
				@InjectionNumber INT,
				@WasherId INT,
				@MachineId INT,
				@ECOLABAccountNumber nvarchar(25),
				@AlarmDate DATETIME2,
				@AlarmGroupMasterId INT,
				@AlarmMachineNumber INT,
				@LatestStartDate DATETIME2

						
		IF EXISTS (SELECT  * FROM TEMPDB.DBO.SYSOBJECTS o where o.xtype in ('U') AND o.id = OBJECT_ID(N'tempdb..#XmlTagsTable'))
			BEGIN
					DROP TABLE #XmlTagsTable
			END


		CREATE TABLE  #XmlTagsTable (	TagId INT, 
										TagValue INT, 
										ReceivedTime DATETIME2,
										TagType NVARCHAR(50)
									)

	
		INSERT INTO #XmlTagsTable	(
										TagId,
										TagValue,
										ReceivedTime,
										TagType
									)			
		
		SELECT 		
					T.c.value('@TagId', 'INT') as TagId,
					T.c.value('@Value', 'INT')	TagValue,
					T.c.value('@TimeStamp', 'varchar(100)') DateTimeStamp,
					T.c.value('@TagType', 'varchar(50)') TagType
		FROM		@xmlTags.nodes('Tags/Tag') T(c)
		WHERE	
					T.c.value('@TagId', 'varchar(100)')  IS NOT NULL
				
			
		SELECT	@AlarmCode					=		TagValue,		
				@AlarmDate					=		ReceivedTime
		FROM	#XmlTagsTable 
		WHERE	TagType						=		'NowMessage'			
					
		SELECT @Valve						=		TagValue	    FROM #XmlTagsTable WHERE TagType='NowValve'

		SELECT @ProgramId					=		TagValue		FROM #XmlTagsTable WHERE TagType='NowFormula'	
		
		SELECT @MachineNumber				=		TagValue		FROM #XmlTagsTable WHERE TagType='NowWasher'	
		
		SELECT @WasherId = WasherID, @GroupId = GroupId, @MachineId = WasherId FROM TCD.MachineSetup WHERE MachineInternalId = @MachineNumber and ControllerId = @ControllerId
		
		SELECT @BatchID = BatchId FROM TCD.BatchData WHERE MachineId = @WasherId and EndDate IS NULL ORDER BY StartDate DESC
				
		SELECT @InjectionNumber = MAX(ParameterValue) FROM TCD.WasherReading where ParameterId = 10 --WHERE MachineInternalId = @MachineNumber
		
		SELECT @ECOLABAccountNumber = EcolabAccountNumber FROM TCD.Plant 

																					
		IF(@AlarmCode = 0)
		  BEGIN
			--UPDATE TCD.AlarmData SET IsActive = 0, EndDate = getutcdate() WHERE controllerID = @controllerID
			SELECT TOP 1 @LatestStartDate=StartDate FROM TCD.AlarmData WHERE controllerID = @controllerID AND IsActive=1 AND AlarmCode NOT IN (9000,9001,9002)
			IF(@AlarmDate > @LatestStartDate)
			BEGIN
				UPDATE TCD.AlarmData SET IsActive = 0, EndDate = @AlarmDate WHERE controllerID = @controllerID AND IsActive=1 AND AlarmCode NOT IN (9000,9001,9002)
		  END
		  END
		
		 IF(@AlarmCode is NOT NULL AND @AlarmCode  <> 0)
    
		  BEGIN

		  IF NOT EXISTS(SELECT TOP 1 * FROM TCD.AlarmData WHERE StartDate=@AlarmDate AND ControllerId=@ControllerId AND AlarmCode=@AlarmCode)
		  BEGIN

			SELECT @AlarmGroupMasterId = AGM.AlarmGroupMasterId, @AlarmMachineNumber=MachineNumber FROM TCD.ConduitController CC 
			INNER JOIN TCD.ControllerModelControllerTypeMapping CMCTM ON CMCTM.ControllerModelId = CC.ControllerModelId AND CMCTM.ControllerTypeId = CC.ControllerTypeId
			INNER JOIN TCD.AlarmGroupMsterVsControllerModelType AGMVCMT ON CMCTM.Id = AGMVCMT.ControllerModelTypeId
			INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
			WHERE AGMVCMT.AlarmCode = @AlarmCode AND CC.ControllerId = @ControllerId

			IF(@MachineId IS NULL AND @AlarmMachineNumber IS NOT NULL)
			BEGIN
				SELECT @MachineId=WasherId FROM TCD.MachineSetup WHERE MachineInternalId=@AlarmMachineNumber AND ControllerId=@ControllerId AND IsDeleted=0
			END

			IF(@GroupId IS NULL AND @AlarmMachineNumber IS NOT NULL)
			BEGIN
				SELECT @GroupId=GroupId FROM TCD.MachineSetup WHERE MachineInternalId=@AlarmMachineNumber AND ControllerId=@ControllerId AND IsDeleted=0
			END

			IF(@MachineNumber IS NULL AND @AlarmMachineNumber IS NOT NULL)
			BEGIN
				SET @MachineNumber=@AlarmMachineNumber
			END

			INSERT INTO [TCD].[AlarmData] 
			(EcoalabAccountNumber,
			AlarmCode,
			BatchId,
			controllerID,
			StartDate,
			GroupId,
			MachineInternalId,
			Valve,
			ProgramId,			
			InjectionNumber,
			IsActive,
			MachineId,
			AlarmGroupMasterId,
			PartitionOn)
		    SELECT
			    @ECOLABAccountNumber,
			    @AlarmCode,
			    @BatchID,
			    @ControllerId,
			    @AlarmDate,
			    @GroupId,
			    @MachineNumber,
			    @Valve,
			    @ProgramId,
			    @InjectionNumber,
			    1,
			    @MachineId,
				@AlarmGroupMasterId,
				@AlarmDate
		  END	
		 END	
		  	   
	END

	