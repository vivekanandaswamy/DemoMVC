CREATE   PROCEDURE [TCD].[GetReportLocalizationDetails] 
(
   @ReportId Int = NULL, 
   @LanguageId Int = NULL
)
AS   
BEGIN   
SET NOCOUNT ON
IF(@LanguageId > 2)
BEGIN
	SET @LanguageId=1;
END;
SELECT 
   RL.ReportColumnId,
   RKV.Value
   FROM [TCD].ReportLocalizationColumnMapping RL
   INNER JOIN [TCD].Report R ON R.ReportId = RL.ReportId 
   INNER JOIN 
   [TCD].ResourceKeyMaster RK ON RL.UsageKey=RK.[KeyName]
   INNER JOIN
   [TCD].ResourceKeyValue RKV ON RK.[KeyName]=RKV.[KeyName]
     WHERE RL.ReportId = @ReportId
     AND RKV.LanguageId = @LanguageId
SET NOCOUNT OFF
END