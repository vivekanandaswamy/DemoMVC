CREATE  PROCEDURE [TCD].[SaveManualRewash]
 ( 			
			 @WasherGroupId   INT, 
			 @FormulaId  INT,  
			 @RewashReasonId  INT,  
			 @RecordedDate DATETIME,
			 @Value DECIMAL(18,0),
			 @EcolabAccountNumber NVARCHAR(25),   
			 @UserId  INT,
			 @Scope VARCHAR(10) OUTPUT,
			 @OutputRewashId INT					= NULL	OUTPUT 
)   
AS  
 
   BEGIN     
SET NOCOUNT ON 

DECLARE @ManualRecordedDate date = CAST(@RecordedDate AS date)
 
DECLARE
		@OutputList					AS	TABLE		(
		RewashId							INT
	)
DECLARE @ReWashId	int
			  INSERT INTO [TCD].ManualRewash(
												WasherGroupId,																
												FormulaId,
												RewashReasonId,
												RecordedDate,
												Value,
												EcolabAccountNumber,
												LastModifiedByUserId
										)
								OUTPUT
									inserted.RewashId						AS			RewashId
								INTO @OutputList
										(RewashId)
								VALUES(
												@WasherGroupId,																
												@FormulaId,
												@RewashReasonId,
												@RecordedDate,
												@Value,
												@EcolabAccountNumber,
												@UserID
									)      
  
			SET @Scope = '101'	
			SET @ReWashId = SCOPE_IDENTITY()

			EXEC [TCD].[SaveProductionShiftManualRewashRollup]   @Date  = @ManualRecordedDate,
													   @ManualData  = @Value,
													   @WasherGroupId  = @WasherGroupId,	   
													   @ProgramMasterId  =@FormulaId

			
			DECLARE @TempRewashProductData TABLE(
											RewashId		INT,
											ProductId		INT,
											Quantity		DECIMAL(18,2),
											Cost			DECIMAL(18,2),
											Price			DECIMAL(18,2),
											NominalLoad		INT,
											TotalRewashLoad INT,
											CustomerId		INT,
											ProgramId		INT,
											WasherGroupId	INT,
											RewashDate		DATE
									)

							INSERT INTO @TempRewashProductData(
											Mr.RewashId,
											ProductId,
											Quantity,
											Cost,
											Price,
											NominalLoad,
											TotalRewashLoad,
											CustomerId,
											ProgramId,
											WasherGroupId,
											RewashDate)
							SELECT DISTINCT 
											Mr.RewashId,
											Pdm.ProductId,
											(Mr.Value * Wdpm.Quantity)/(Wps.NominalLoad/CONVERT(decimal(10,2), 100)) as Quantity,
											Pdm.Cost,
											NULL,
											Wps.NominalLoad,
											Mr.Value,													
											Pm.CustomerId,
											Wps.ProgramId,
											Wps.WasherGroupId,
											Mr.RecordedDate

							FROM 
										TCD.WasherProgramSetup Wps
							INNER JOIN 
										TCD.WasherDosingSetup Wds 
									ON	Wds.WasherProgramSetupId							=			Wps.WasherProgramSetupId
							INNER JOIN 
										TCD.WasherDosingProductMapping Wdpm 
									ON	Wdpm.WasherDosingSetupId							=			Wds.WasherDosingSetupID
							INNER JOIN 
										TCD.ProductdataMapping Pdm 
									ON	Pdm.ProductId										=			Wdpm.ProductId
							INNER JOIN 
										TCD.ProgramMaster Pm 
									ON	Pm.ProgramId										=			Wps.ProgramId
							INNER JOIN 
										TCD.PlantCustomer Pc 
									ON	Pc.CustomerId										=			Pm.CustomerId
							INNER JOIN 
										Tcd.ManualRewash Mr 
									ON	Mr.FormulaId										=			Pm.ProgramId				AND 
										Mr.WasherGroupId									=			Wps.WasherGroupId			
							Where 
										Mr.FormulaId										=			@FormulaId					AND 
										Mr.WasherGroupId									=			@WasherGroupId				AND
										Mr.RewashId											=			@ReWashId

						INSERT INTO TCD.RewashProductData(
												RewashId,
												ProductId,
												Quantity,
												Price,
												TotalRewashLoad,
												CustomerId,
												Date,
												EcolabAccountNumber
												)
						SELECT					RewashId,
												ProductId,
												Quantity,
												Price,												
												TotalRewashLoad,
												CustomerId,
												RewashDate ,
												@EcolabAccountNumber
						FROM					@TempRewashProductData

							SET @Scope = '201' 	

SELECT	TOP 1	
				@OutputRewashId	=	O.RewashId
		FROM	@OutputList									O										 		 
SET NOCOUNT OFF
END