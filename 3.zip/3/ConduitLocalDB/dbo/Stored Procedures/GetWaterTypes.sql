﻿
/*  
 ==========================================================================================  
 Purpose:  Fecthing the water Types

 Author:  santhosh Mahankali

 --------------------------------------------------------------  
 Aug-24-2014 ENT: Initial version.  
 ==========================================================================================  
*/ 
CREATE PROCEDURE [TCD].[GetWaterTypes] 
(
	@RegionId int
)
AS 
  BEGIN 
      SET nocount ON; 

     SELECT Id,Name,TCD.WaterType.RegionID,MyServiceUtilTypeCode 
	 FROM [TCD].WaterType 
	 WHERE RegionID= @RegionId AND (Name NOT IN ('Cold Soft', 'Hot Soft')) 
	 ORDER BY Id
     
  END