﻿
/*    
 ==========================================================================================  
 Purpose:  Getting the DimensionalUnitsDefaults.    

 Author:  Premchand Yelavarthi    

 --------------------------------------------------------------    
 July-18-2014 ENT: Initial version.    
 ==========================================================================================  
*/ 
CREATE PROCEDURE [TCD].[GetDimensionalUnitsDefaults](@UnitSystemId INT = NULL)
AS 
  BEGIN 
      SET nocount ON; 
		SELECT 
			    dud.[UnitSystemId],
			    dud.[UsageKey],    
			    dud.[Unit],        
			    dud.[Subunit],     
			    dus.[UnitSystemId],
			    dus.[UnitSystem]  

        FROM [TCD].DimensionalUnitsDefaults dud
        INNER JOIN [TCD].DimensionalUnitSystems dus ON dus.UnitSystemId = dud.UnitSystemId
		WHERE dus.UnitSystemId = @UnitSystemId
        ORDER BY dud.UsageKey,dus.UnitSystemId
  END 