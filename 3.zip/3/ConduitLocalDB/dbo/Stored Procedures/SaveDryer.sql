﻿/*
==========================================================================================

Purpose:  INSERTING THE DRYER DATA

Author: Venkata Mohan Krishna K

Modified: Krishna Gangadhar Thota

--------------------------------------------------------------  
Sep-09-2014 ENT: Initial version.


==========================================================================================
*/

CREATE PROCEDURE [TCD].[SaveDryer] (@DryerGroupId   INT,  
@DryerNo INT,
@Description NVARCHAR(1000) = NULL,
@Capacity NVARCHAR(1000) = NULL,
@DryerTypeId INT = NULL,
@EcolabAccountNumber NVARCHAR(25),
@UserId Int,
@Capacity_Display decimal(18,0),
@Scope varchar(100) OUTPUT
	--Adding these 2 params as part of re-factoring for integration with Synch/Configurator
,	@OutputDryerId						INT					=			NULL	OUTPUT
,	@OutputLastModifiedTimestampAtLocal	DATETIME			=			NULL	OUTPUT

)
AS

SET NOCOUNT ON
BEGIN
DECLARE @Output Varchar(100) = ''

DECLARE
		@OutputList					AS	TABLE		(
		DryerId							INT
	,	LastModifiedTimestamp			DATETIME
	)

SET	@OutputDryerId			=			ISNULL(@OutputDryerId, NULL)		--SQLEnlight SA0121

IF	(NOT EXISTS	(	SELECT *  
					FROM   [TCD].Dryers  
					WHERE  DryerNo = @DryerNo and Is_deleted <> 1)
		)
		BEGIN
				IF NOT EXISTS (	SELECT *
								FROM   [TCD].Dryers
								WHERE  [Description] = @Description and Is_deleted <> 1)  
						BEGIN
								INSERT INTO [TCD].Dryers
											(DryerGroupId,
											DryerNo,
											[Description],
											Capacity,
											DryerTypeId,
											EcolabAccountNumber,
											LastModifiedByUserId,
											Capacity_Display)  
								--**	Adding as part of Audit re-factor to capture the User info.
								OUTPUT
									inserted.Id						AS			DryerId
								,	inserted.LastModifiedTime		AS			LastModifiedTimestamp
								INTO
									@OutputList	(
									DryerId
								,	LastModifiedTimestamp
								)	--**
								VALUES      
											(@DryerGroupId,  
											@DryerNo,
											@Description,
											@Capacity,
											@DryerTypeId,
											@EcolabAccountNumber,
											@UserId,
											@Capacity_Display)  

								DECLARE @NewDryerId int = SCOPE_IDENTITY()
								SET @OutPut = '101'
								SET @Scope = @OutPut SELECT @Scope
						END
				ELSE
						BEGIN
								SET @OutPut = '301'
								SET @Scope = @OutPut SELECT @Scope
						END
		END
ELSE
		BEGIN
				SET @OutPut = '302'  
				IF EXISTS (	SELECT 1  
							FROM   [TCD].Dryers  
							WHERE  [Description] = @Description and Is_deleted <> 1
							) 

							SET @OutPut = '303' 
		END


SET @Scope = @OutPut --SELECT @Scope  

IF @OutPut = '301'
	BEGIN
		SET		@OutputLastModifiedTimestampAtLocal			=			GETUTCDATE()
	END
ELSE IF @OutPut = '302'
	BEGIN
		SET		@OutputLastModifiedTimestampAtLocal			=			GETUTCDATE()
	END
ELSE IF @OutPut = '303'
	BEGIN
		SET		@OutputLastModifiedTimestampAtLocal			=			GETUTCDATE()
	END
ELSE
	BEGIN
		SELECT	TOP 1	
				@OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp
			,	@OutputDryerId						=	O.DryerId
		FROM	@OutputList							O

	END

END