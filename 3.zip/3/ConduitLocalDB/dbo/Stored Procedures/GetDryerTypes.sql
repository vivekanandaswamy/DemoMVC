﻿CREATE PROCEDURE [TCD].GetDryerTypes

AS

BEGIN

SET NOCOUNT ON
Select DryerTypeId,Name from [TCD].DryerType where Is_Deleted <> 1
SET NOCOUNT OFF
END