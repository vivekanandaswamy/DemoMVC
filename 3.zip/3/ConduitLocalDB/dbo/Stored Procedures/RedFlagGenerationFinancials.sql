﻿ 
/*
Purpose					:	Generater Red flags for Financial

Author: Suresh k
Date:28-Dec-2015

exe TCD.RedFlagGenerationFinancials 1,'2015-12-1','040242802'

*/

CREATE PROCEDURE [TCD].[RedFlagGenerationFinancials]
( @ShiftId int , 
                                                       @PartitionOn smalldatetime , 
                                                       @EcolabAccountNumber nvarchar( 25)
                                                     )
AS
BEGIN
 DECLARE
       @Value decimal( 18 , 3) , 
	   @UOMId int,
	   @RegionId int,
       @PlantId int;
	   declare @ActualWeight decimal (18,2);

 SELECT
            @PlantId = PlantId
			,@UOMId=UOMId
			,@RegionId=RegionId
      FROM TCD.Plant p
      WHERE p.EcolabAccountNumber = @EcolabAccountNumber;

    DECLARE
       @Redflag TABLE(
            CounterId int IDENTITY( 1 , 1) , 
            Id int , 
            Item int
                     );

    DECLARE
       @MaxId int , 
       @Counter int , 
       @Item int , 
       @ShiftHrs int , 
       @Id int;


    INSERT INTO @Redflag(Id,
            Item
                        )
    SELECT
            rf.Id , 
            rf.Item
      FROM TCD.RedFlag rf
      WHERE rf.Is_Deleted = 0
        AND rf.RedFlagCategoryId = 4;

    SELECT
            @MaxId = ISNULL( MAX( CounterId) , 0)
      FROM @Redflag r;

SELECT bd.*   
	INTO #BatchData  
	FROM tcd.BatchData bd (NOLOCK) 
	INNER JOIN TCD.MachineSetup ms  (NOLOCK)  on bd.MachineId=ms.WasherId AND   isnull(ms.IsPony,0)=0
	WHERE bd.ShiftId =@ShiftId 
	--AND bd.StandardWeight > 0  
	--and bd.ActualWeight > 0   
	and bd.EndDate IS NOT NULL





    SET @Counter = 1;

    WHILE @Counter <= @MaxId 
        BEGIN
            SELECT
                    @Id = Id , 
                    @Item = Item
              FROM @Redflag r
              WHERE CounterId = @Counter;

			   IF @Item = 22
                BEGIN
				--Water Cost (per CWT/Kg)
				 SELECT   @ActualWeight=  sum( isnull( bd.ActualWeight,0) + isnull( bd.ManualInputWeight,0)) 
						  FROM #BatchData bd
						   INNER JOIN TCD.[BatchStepWaterUsageData] bswud ON bswud.BatchId=bd.BatchId and bswud.EcolabWasherId=bd.EcolabWasherId
							INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
										AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0) AND rf.Is_Deleted = 0
							 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0
						  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
							AND bd.ShiftId = @ShiftId
							--AND BD.PartitionOn = @PartitionOn
							AND rf.Id = @Id

                     SELECT  @Value= ( sum( bswud.[Price])/ @ActualWeight) * (case @RegionId when 1 then 100 else 1 end) * (case @RegionId when 1 then 1 else 3.78541178 end )
						  FROM #BatchData bd
						   INNER JOIN TCD.[BatchStepWaterUsageData] bswud ON bswud.BatchId=bd.BatchId and bswud.EcolabWasherId=bd.EcolabWasherId
							INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
										AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0) AND rf.Is_Deleted = 0
							 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0
						  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
							AND bd.ShiftId = @ShiftId
							--AND BD.PartitionOn = @PartitionOn
							AND rf.Id = @Id
                END
				ELSE   IF @Item = 23
                BEGIN
				--Energy Cost (per CWT/Kg)
				  SELECT  @ActualWeight=  sum( isnull( bd.ActualWeight,0) + isnull( bd.ManualInputWeight,0)) 
					  FROM #BatchData bd
					   INNER JOIN TCD.[BatchEnergyUsageData] beua ON beua.BatchId=bd.BatchId and beua.EcolabWasherId=bd.EcolabWasherId
						INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
									AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0) AND rf.Is_Deleted = 0
						 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0
					  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
						AND bd.ShiftId = @ShiftId
						--AND BD.PartitionOn = @PartitionOn
						AND rf.Id = @Id

				   SELECT  @Value=  sum( beua.Price)/ @ActualWeight * (case @RegionId when 1 then 100 else 1 end) * (case @RegionId when 1 then 1 else 3.78541178 end )
					  FROM #BatchData bd
					   INNER JOIN TCD.[BatchEnergyUsageData] beua ON beua.BatchId=bd.BatchId and beua.EcolabWasherId=bd.EcolabWasherId
						INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
									AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0) AND rf.Is_Deleted = 0
						 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0
					  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
						AND bd.ShiftId = @ShiftId
						--AND BD.PartitionOn = @PartitionOn
						AND rf.Id = @Id

				END
				ELSE   IF @Item = 24
                BEGIN
				--Gas Cost (per CWT/Kg)
				 SELECT  @ActualWeight=  sum( isnull( bd.ActualWeight,0) + isnull( bd.ManualInputWeight,0)) 
					  FROM #BatchData bd
						INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
									AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0) AND rf.Is_Deleted = 0
						 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0
					  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
						AND bd.ShiftId = @ShiftId
					--	AND BD.PartitionOn = @PartitionOn
						AND rf.Id = @Id



				    SELECT  @Value=( sum( beua.Price)/@ActualWeight)* (case @RegionId when 1 then 100 else 1 end) * (case @RegionId when 1 then 1 else 3.78541178 end ) 
					  FROM #BatchData bd
					  INNER JOIN TCD.[BatchEnergyUsageData] beua ON beua.BatchId=bd.BatchId and beua.EcolabWasherId=bd.EcolabWasherId AND beua.GasOilTypeId IN (1,2)
						INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
									AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0) AND rf.Is_Deleted = 0
						 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0
					  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
						AND bd.ShiftId = @ShiftId
					--	AND BD.PartitionOn = @PartitionOn
						AND rf.Id = @Id


				END
				ELSE   IF @Item = 26
                BEGIN
					--Chemical Cost (per CWT/Kg)
				 SELECT  @ActualWeight=  sum( isnull( bd.ActualWeight,0) + isnull( bd.ManualInputWeight,0)) 
					  FROM #BatchData bd					 
						INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
									AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0) AND rf.Is_Deleted = 0
						 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0
					  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
						AND bd.ShiftId = @ShiftId
						--AND BD.PartitionOn = @PartitionOn
						AND rf.Id = @Id
			
				  SELECT  @Value=  (sum( bp.Price)/ @ActualWeight ) * (case @RegionId when 1 then 100 else 1 end) * (case @RegionId when 1 then 1 else 3.78541178 end ) 
					  FROM #BatchData bd
					   INNER JOIN TCD.[BatchProductData] bp  ON bp.BatchId=bd.BatchId and bp.EcolabWasherId=bd.EcolabWasherId --and bp.InjectionNumber=bd.ProgramMasterId
						INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
									AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0) AND rf.Is_Deleted = 0
						 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0
					  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
						AND bd.ShiftId = @ShiftId
						--AND BD.PartitionOn = @PartitionOn
						AND rf.Id = @Id

				END
				ELSE   IF @Item = 28
                BEGIN
				--Total Cost (WEC per CWT/Kg)
				

				 SELECT @ActualWeight=sum( isnull( bd.ActualWeight,0) + isnull( bd.ManualInputWeight,0)) 

				 FROM #BatchData bd
				  INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
								AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0) AND rf.Is_Deleted = 0
					 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0		
	
				  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
					AND bd.ShiftId = @ShiftId				
					AND rf.Id = @Id
					--AND bd.ActualWeight>0 AND bd.StandardWeight>0 

				
				  SELECT  @Value= (sum(ISNULL( bswud.[Price],0)) +sum(ISNULL( beua.Price,0))+sum(ISNULL( bp.Price,0))/ @ActualWeight)
				  *(case @RegionId when 1 then 100 else 1 end) *(case @RegionId when 1 then 1 else 3.78541178 end )
				 

				  FROM #BatchData bd
				  INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
								AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0) AND rf.Is_Deleted = 0
					 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0
				  LEFT JOIN TCD.[BatchEnergyUsageData] beua ON beua.BatchId=bd.BatchId and beua.EcolabWasherId=bd.EcolabWasherId 
				    LEFT JOIN TCD.[BatchProductData] bp  ON bp.BatchId=bd.BatchId and bp.EcolabWasherId=bd.EcolabWasherId --and bp.InjectionNumber=bd.ProgramMasterId
					 LEFT JOIN TCD.[BatchStepWaterUsageData] bswud ON bswud.BatchId=bd.BatchId and bswud.EcolabWasherId=bd.EcolabWasherId
	
				  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
					AND bd.ShiftId = @ShiftId				
					AND rf.Id = @Id

				END				


			IF @Value IS NOT NULL 
			BEGIN
            IF NOT EXISTS( SELECT
                                   1
                             FROM TCD.RedFlag rf
                             WHERE Id = @Id
                               AND rf.Is_Deleted = 0
                               AND rf.MinimumRange <= @Value
                               AND rf.MaximumRange >= @Value
                         )
                BEGIN

                    IF NOT EXISTS( SELECT
                                           1
                                     FROM TCD.RedFlagData rfd
                                     WHERE rfd.RedFlagId = @Id
                                       AND rfd.ShiftId = @ShiftId
                                       AND PartitionOn = @PartitionOn
                                 )
                        BEGIN
                            INSERT INTO TCD.RedFlagData(
                                    RedFlagId , 
                                    PlantId , 
                                    ShiftId , 
                                    RedFlagValue , 
                                    RedFlagMinSetPoint , 
                                    RedFlagMaxSetPoint , 
                                    PartitionOn
                                                       )
                            SELECT
                                    rf.Id , 
                                    @PlantId , 
                                    @ShiftId , 
                                    @Value , 
									 rf.MinimumRange , 
                                    rf.MaximumRange ,                                    
                                    @PartitionOn
                              FROM TCD.RedFlag rf
                              WHERE rf.Id = @Id;

                        END;

                END;
			END

            SET @Counter = @Counter + 1;
		END
END