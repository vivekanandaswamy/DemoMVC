--exec [TCD].[OperationSummaryDrillDownReport] @Corporate=N'',@Country=N'',@Region=N'',@EcolabAccountNumber=N'',@Machine=N'',@machineGroup=N'',@Formula=N'',@MachineType=N'',
--@Category=N'',@FromDate='2015-01-01 00:00:00',@ToDate='2015-01-12 00:00:00',@GroupId=N'',@MachineInternalId=N'',
--@FormulaId=122,@EcolabTextileId ='',@TextileCareCustomerId='',@DayWise=0,@WeekWise=1,
--@MonthWise=0,@QuarterWise=0,@YearWise=0,@Date = '',@SortColumnID = 0,@SortDirection = 'ASC',@UserId = 0,@ReportID =10,@IsDrillDown = 1


CREATE  PROCEDURE [TCD].[OperationSummaryDrillDownReport] (
											 @Corporate Varchar(max) = '',
											 @Country Varchar(max) = '',
											 @Region Varchar(max) = '',
											 @EcolabAccountNumber Nvarchar(25) = '',
											 @Machine Varchar(max) = '', 
											 @machineGroup Varchar(max) = '',
											 @Formula Varchar(max) = '',
											 @MachineType Varchar(20)= '',
											 @Category Varchar(max) = '',
											 @FromDate Date = '',
											 @ToDate Date = '',
											 @GroupId Varchar(max) = '',
											 @MachineInternalId Varchar(max) = '',
											 --@Customer Varchar(max) = '',
											 @FormulaId Varchar(100) = '',
											 @EcolabTextileId Varchar(100) = '',
											 @TextileCareCustomerId Varchar(100) = '',
											 @DayWise bit = NULL,
											 @WeekWise bit = NULL,
											 @MonthWise bit = NULL,
											 @QuarterWise bit = NULL,
											 @YearWise bit = NULL,
											 @Date DATE = NULL,
											 @SortColumnID INT = NULL,
											 @SortDirection Varchar(100) = '',
											 @UserId Int = NULL,
											 @ReportID INT = NULL,
											 @IsDrillDown BIT									 
										   )
AS   
BEGIN   
SET NOCOUNT ON;

DECLARE @ReportGenerated INT = 6, 
	   @SortField Varchar(100) = '',
	   @SQLStatement varchar(max),@PlantWise INT = 0

 SELECT @SortField =  CASE WHEN @SortColumnID = 3 THEN 'ActualChemicalUsageperLoad'
						    WHEN @SortColumnID = 7 THEN 'ActualEnergyUsage'
						    WHEN @SortColumnID = 8 THEN 'ActualEnergyUsagePerLoad'
						    WHEN @SortColumnID = 10 THEN 'ActualWaterUsagePerLoad'
						    WHEN @SortColumnID = 11 THEN 'ActualWaterUsage'
						    WHEN @SortColumnID = 43 THEN 'TargetChemicalUsageperLoad'						
						    WHEN @SortColumnID = 77 THEN 'TargetEnergyUsagePerLoad'
						    WHEN @SortColumnID = 83 THEN 'FormulaName'
						    WHEN @SortColumnID = 127 THEN 'ProductionMix'
						    WHEN @SortColumnID = 133 THEN 'NumberOfLoads'
						    WHEN @SortColumnID = 200 THEN 'TotalLoad'
						    WHEN @SortColumnID = 187 THEN 'TargetWaterUsagePerLoad'
						    WHEN @SortColumnID = 194 THEN 'EcolabTextileCategory'
						    WHEN @SortColumnID = 245 THEN 'PlantTextileCategoryName'
						    WHEN @SortColumnID = 0 THEN 'TotalLoad'
							WHEN @SortColumnID = 242 THEN 'DateRange'
					 END



DECLARE @Month INT = MONTH(GETDATE()),
	   @SummationInMin Int = NULL,@summingActualLoad Decimal(18,2) = NULL

DECLARE @CategoryTable TABLE(Category Varchar(100))
INSERT INTO @CategoryTable(Category) EXEC [TCD].[CharlistToTable] @Category,','

DECLARE @MachineTable TABLE(Machine Varchar(100))
INSERT INTO @MachineTable(Machine) EXEC [TCD].[CharlistToTable] @Machine,','

DECLARE @GroupMachineTable TABLE(GroupId INT,MachineInternalId INT)  
INSERT INTO @GroupMachineTable(GroupId,MachineInternalId) 
SELECT GroupId,MachineInternalId FROM TCD.MachineSetup MS 
									INNER JOIN TCD.Washer WS ON MS.WasherId = WS.WasherId WHERE WS.PlantWasherNumber IN (SELECT Machine FROM @MachineTable);

DECLARE @GroupTable TABLE(GroupId Varchar(100))
INSERT INTO @GroupTable(GroupId) EXEC [TCD].[CharlistToTable] @GroupId,','

DECLARE @MachineInternalTable TABLE(MachineInternalId Varchar(100))
INSERT INTO @MachineInternalTable(MachineInternalId) EXEC [TCD].[CharlistToTable] @MachineInternalId,','

DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))
INSERT INTO @WasherGroupTable(MachineGroup) EXEC [TCD].[CharlistToTable] @machineGroup,','

DECLARE @FormulaTable TABLE(Formula Varchar(100))
INSERT INTO @FormulaTable(Formula) EXEC [TCD].[CharlistToTable] @Formula,','

--DECLARE @CustomerTable TABLE(Customer Varchar(100))
--INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','

DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))
INSERT INTO @MachineTypeTable(MachineType) EXEC [TCD].[CharlistToTable] @MachineType,','

	   /* Including the Latest Batch Data */

	   		  IF((CAST(@ToDate AS DATE) = CAST(GETUTCDATE() AS date)) AND @DayWise <> 1)
				    BEGIN				     

					EXEC [TCD].[WaterAndEnergyDataRollUp] @ToDate

					END

	   /* Ending the Latest Batch Data Logic */


	 DECLARE @OperationsSummaryTable TABLE(
								    [RecordDate] [date] NULL,
								 [BatchId] [int] NULL,
								 [ActualWeight] [decimal](18, 2) NULL,
								 [StandardWeight] [decimal](18, 2) NULL,
								 [MachineId] [int] NULL,
								 [GroupId] [int] NULL,
								 [MachineInternalId] [int] NULL,
								 [ProgramNumber] [int] NULL,
								 [ProductId] [int] NULL,
								 [NoOfBatches] [int] NULL,
								 [ActualChemicalWeight] [decimal](18, 2) NULL,
								 [StandardChemicalWeight] [decimal](18, 2) NULL,
								 [ActualWaterWeight] [decimal](18, 2) NULL,
								 [StandardWaterWeight] [decimal](18, 2) NULL,
								 [ActualEnergyWeight] [decimal](18, 2) NULL,
								 [StandardEnergyWeight] [decimal](18, 2) NULL,
								 [ChemicalCost] [decimal](18, 2) NULL,
								 [WaterCost] [decimal](18, 2) NULL,
								 [EnergyCost] [decimal](18, 2) NULL,
								 [EcolabTextileId] [int] NULL,
								 [EcolabTextileCategoryName] [varchar](100) NULL,
								 [PlantTextileId] [int] NULL,
								 [PlantTextileCategoryName] [varchar](100) NULL
								  )
					   INSERT INTO @OperationsSummaryTable(
								    [RecordDate],
								 [BatchId],
								 [ActualWeight],
								 [StandardWeight] ,
								 [MachineId] ,
								 [GroupId],
								 [MachineInternalId],
								 [ProgramNumber],
								 [ProductId],
								 [NoOfBatches],
								 [ActualChemicalWeight],
								 [StandardChemicalWeight],
								 [ActualWaterWeight],
								 [StandardWaterWeight] ,
								 [ActualEnergyWeight] ,
								 [StandardEnergyWeight] ,
								 [ChemicalCost],
								 [WaterCost],
								 [EnergyCost],
								 [EcolabTextileId],
								 [EcolabTextileCategoryName] ,
								 [PlantTextileId],
								 [PlantTextileCategoryName] 
								  )
	   
									   SELECT  [RecordDate]
										    ,[BatchId]
										    ,[ActualWeight]
										    ,[StandardWeight]
										    ,[MachineId]
										    ,[GroupId]
										    ,[MachineInternalId]
										    ,[ProgramNumber]
										    ,[ProductId]
										    ,[NoOfBatches]
										    ,[ActualChemicalWeight]
										    ,[StandardChemicalWeight]
										    ,[ActualWaterWeight]
										    ,[StandardWaterWeight]
										    ,[ActualEnergyWeight]
										    ,[StandardEnergyWeight]
										    ,[ChemicalCost]
										    ,[WaterCost]
										    ,[EnergyCost]
										    ,[EcolabTextileId]
										    ,[EcolabTextileCategoryName]
										    ,[PlantTextileId]
										    ,[PlantTextileCategoryName]
										FROM [TCD].[BatchWaterandEnergyRollUp] BD
								WHERE
								CASE @Machine   
										   WHEN '' THEN 'TRUE'         
										   ELSE                                                      
										    CASE WHEN BD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
										  END='TRUE'
								    AND       

				    CASE @machineGroup   
					WHEN '' THEN 'TRUE'         
					ELSE                                                      
					 CASE WHEN BD.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable) THEN 'TRUE' END                                                      
				    END='TRUE' 

				    AND    

				    CASE @Formula   
					WHEN '' THEN 'TRUE'         
					ELSE                                                      
					 CASE WHEN BD.ProgramNumber IN (SELECT Formula FROM @FormulaTable) THEN 'TRUE' END                                                      
				    END='TRUE' 

				    AND       
				    CASE @FromDate                                                                                
				    WHEN '' THEN Case WHEN MONTH(BD.RecordDate) = @Month Then  'true' END                                                                                
				    ELSE CASE WHEN BD.RecordDate >= @FromDate and BD.RecordDate<dateadd(dd,1,@ToDate) THEN 'true'END                                                        
				 END='true'

				    AND
				    CASE @MachineType   
					WHEN '' THEN 'TRUE'         
					ELSE                                                      
					 CASE WHEN BD.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable)) THEN 'TRUE' END                                                      
				    END='TRUE' 

				    AND       
				   CASE @Category   
					WHEN '' THEN 'TRUE'         
					ELSE                                                      
					 CASE WHEN BD.EcolabTextileId IN (SELECT Category FROM @CategoryTable) THEN 'TRUE' END                                                      
				    END='TRUE' 

				    AND
					CASE @GroupId 
					WHEN '' THEN 'TRUE' 
					ELSE        
				    CASE WHEN (BD.GroupId IN (@GroupId) AND 
					 BD.MachineInternalId IN (@MachineInternalId)) THEN 'TRUE' END                                                   
				    END='TRUE' 
				    AND
					CASE @MachineInternalId 
					WHEN '' THEN 'TRUE' 
					ELSE        
				    CASE WHEN (BD.GroupId IN (@GroupId) AND 
					 BD.MachineInternalId IN (@MachineInternalId)) THEN 'TRUE' END                                                   
				    END='TRUE' 

				   		  
			SELECT @summingActualLoad=  SUM(ActualWeight)  FROM @OperationsSummaryTable 
		 

		   IF(@DayWise = 1)

	    		  BEGIN
				
				EXEC [TCD].[OperationSummaryShiftReport] @Corporate,@Country,@Region,@EcolabAccountNumber,@Machine,
				@machineGroup,@Formula,@MachineType,@Category,@FromDate,
				@ToDate,@GroupId,@MachineInternalId,@Date,@PlantWise,@FormulaId,
				@EcolabTextileId,@TextileCareCustomerId,@SortColumnID,@SortDirection,@ReportID,@IsDrillDown

				END
				
		  IF(@WeekWise = 1)

	    		  BEGIN

			   SELECT @summingActualLoad = SUM(ActualWeight)  FROM @OperationsSummaryTable 
			 WHERE (ProgramNumber = @FormulaId OR EcolabTextileId = @EcolabTextileId OR PlantTextileId = @TextileCareCustomerId )

				SELECT 
					   0 AS Id,
					   CAST(RecordDate AS nvarchar(100)) As DateRange,
					   SUM(PDT.ActualWeight) AS TotalLoad,
					   CAST(SUM(PDT.ActualWeight) * 100/@summingActualLoad AS DECIMAL(18,2)) AS ProductionMix,
					   COUNT(DISTINCT PDT.BatchId) AS NumberOfLoads,
					   SUM(PDT.ActualWaterWeight) AS ActualWaterUsage,
					   CAST(SUM(PDT.ActualWaterWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS ActualWaterUsagePerLoad,
					   CAST(SUM(PDT.StandardWaterWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS TargetWaterUsagePerLoad,
					   SUM(PDT.ActualEnergyWeight) AS ActualEnergyUsage,
					   CAST(SUM(PDT.ActualEnergyWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS ActualEnergyUsagePerLoad,
					   CAST(SUM(PDT.StandardEnergyWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS TargetEnergyUsagePerLoad,
					   CAST(SUM(PDT.ActualChemicalWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS ActualChemicalUsageperLoad,
					   CAST(SUM(PDT.StandardChemicalWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS TargetChemicalUsageperLoad,
					   'Day' AS SwithMode,@IsDrillDown AS IsDrillDown,
				CAST(SUM([ActualChemicalWeight]) AS Decimal(18,2)) AS ActualChemicalWeight,
				CAST(SUM([ActualWaterWeight]) AS Decimal(18,2)) AS [ActualWaterWeight],
				CAST(SUM([ActualEnergyWeight]) AS Decimal(18,2)) AS [ActualEnergyWeight],
				CAST(SUM([StandardChemicalWeight]) AS Decimal(18,2)) AS StandardChemicalWeight,
				CAST(SUM([StandardWaterWeight]) AS Decimal(18,2)) AS [StandardWaterWeight],
				CAST(SUM([StandardEnergyWeight]) AS Decimal(18,2)) AS [StandardEnergyWeight],
				SUM(ChemicalCost) AS [ChemicalCost],
				SUM(WaterCost) AS WaterCost,
				SUM(EnergyCost) AS EnergyCost
					   INTO #ProdTableDayOrder
				 FROM @OperationsSummaryTable PDT
				 WHERE (ProgramNumber = @FormulaId OR EcolabTextileId = @EcolabTextileId OR PlantTextileId = @TextileCareCustomerId)
				 GROUP BY DATEPART(weekday,RecordDate),RecordDate

				SET @SQLStatement 
					   ='SELECT * FROM #ProdTableDayOrder ORDER BY ' + @SortField + ' ' + @SortDirection

	   			EXEC(@SQLStatement)
				END

     IF(@MonthWise = 1)

		  BEGIN 
		  		  
			   SELECT @summingActualLoad = SUM(ActualWeight)  FROM @OperationsSummaryTable 
			 WHERE (ProgramNumber = @FormulaId OR EcolabTextileId = @EcolabTextileId OR PlantTextileId = @TextileCareCustomerId )

		  DECLARE @FirstDay date = (SELECT TOP 1 RecordDate FROM @OperationsSummaryTable ORDER BY RecordDate)
		  DECLARE @LastDay date = (SELECT TOP 1 RecordDate FROM @OperationsSummaryTable ORDER BY RecordDate DESC)
		  DECLARE @FirstSunday date = NULL,
				@LastSaturday date = NULL

		  
		  SELECT 
				@FirstSunday = CAST(DateAdd(dd, (8-DatePart(WEEKDAY, 
							DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)))%7, 
							DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)) AS DATE) 

		   SELECT
				  @LastSaturday = 
								DATEADD(dd,
									   -DATEPART(WEEKDAY,
											   DATEADD(dd, -DAY(DATEADD(month, 1, @LastDay)),
													 DATEADD(month, 1, @LastDay))) ,
									   DATEADD(dd, -DAY(DATEADD(MONTH, 1, @LastDay)), DATEADD(MONTH, 1, @LastDay)));

		  WITH CTE(DateRange,TotalLoad,ProductionMix,NumberOfLoads,ActualWaterUsage,ActualWaterUsagePerLoad,TargetWaterUsagePerLoad,ActualEnergyUsage,ActualEnergyUsagePerLoad,TargetEnergyUsagePerLoad,ActualChemicalUsageperLoad,TargetChemicalUsageperLoad,SwithMode,
		  ActualChemicalWeight,ActualWaterWeight,ActualEnergyWeight,StandardChemicalWeight,StandardWaterWeight,StandardEnergyWeight,ChemicalCost,WaterCost,EnergyCost)
				AS
				(
				SELECT 
					CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,-1,@FirstSunday)) = 7 
					AND (SELECT COUNT(1) FROM @OperationsSummaryTable WHERE RecordDate < DATEADD(DD,-1,@FirstSunday)) = 0)
					THEN CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100))
					WHEN DATEADD(DD,-1,@FirstSunday) > CAST(GETDATE() AS DATE) 
					THEN
					CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @ToDate, 101) AS nvarchar(100))
					ELSE
					CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) END As DateRange,
					 SUM(PDT.ActualWeight) AS TotalLoad,
				   CAST(SUM(PDT.ActualWeight) * 100/@summingActualLoad AS DECIMAL(18,2)) AS ProductionMix,
				    COUNT(DISTINCT PDT.BatchId) AS NumberOfLoads,
				    SUM(PDT.ActualWaterWeight) AS ActualWaterUsage,
				    	CAST(SUM(PDT.ActualWaterWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS ActualWaterUsagePerLoad,
				    CAST(SUM(PDT.StandardWaterWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS TargetWaterUsagePerLoad,
				    SUM(PDT.ActualEnergyWeight) AS ActualEnergyUsage,
				    CAST(SUM(PDT.ActualEnergyWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS ActualEnergyUsagePerLoad,
				    CAST(SUM(PDT.StandardEnergyWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS TargetEnergyUsagePerLoad,
				    CAST(SUM(PDT.ActualChemicalWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS ActualChemicalUsageperLoad,
				    CAST(SUM(PDT.StandardChemicalWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS TargetChemicalUsageperLoad,
					   'Week' AS SwithMode,
				    CAST(SUM([ActualChemicalWeight]) AS Decimal(18,2)) AS ActualChemicalWeight,
				    CAST(SUM([ActualWaterWeight]) AS Decimal(18,2)) AS [ActualWaterWeight],
				    CAST(SUM([ActualEnergyWeight]) AS Decimal(18,2)) AS [ActualEnergyWeight],
				CAST(SUM([StandardChemicalWeight]) AS Decimal(18,2)) AS StandardChemicalWeight,
				CAST(SUM([StandardWaterWeight]) AS Decimal(18,2)) AS [StandardWaterWeight],
				CAST(SUM([StandardEnergyWeight]) AS Decimal(18,2)) AS [StandardEnergyWeight],
				SUM(ChemicalCost) AS [ChemicalCost],
				SUM(WaterCost) AS WaterCost,
				SUM(EnergyCost) AS EnergyCost
					    FROM @OperationsSummaryTable PDT
							 LEFT OUTER JOIN 
								(SELECT FormulaId FROM TCD.ManualRewash) RR ON PDT.ProgramNumber = RR.FormulaId
					   WHERE RecordDate < @FirstSunday AND RecordDate >= @FirstDay
					   AND 
					   (ProgramNumber = @FormulaId OR EcolabTextileId = @EcolabTextileId OR PlantTextileId = @TextileCareCustomerId)

					   
					   UNION ALL

		
					   SELECT 
						  --CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100)) AS StartDate,
						  --CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) AS EndDate,
						--CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100)) AS StartDate,
						  --CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) AS EndDate,
						  CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100))  + CHAR(13) + '-' +
						   CASE WHEN CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) >
						   CAST(Convert(varchar, DateAdd(dd, (1 - DatePart(dw, @Todate) + 1), @Todate), 101) AS nvarchar(100))
						   THEN  CAST(Convert(varchar, DateAdd(dd, 1-1, @Todate), 101) AS nvarchar(100))
						   ELSE CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) END
						   As DateRange,
						 SUM(PDT.ActualWeight) AS TotalLoad,
						  CAST(SUM(PDT.ActualWeight) * 100/@summingActualLoad AS DECIMAL(18,2)) AS ProductionMix,
						  COUNT(DISTINCT PDT.BatchId) AS NumberOfLoads,
						  SUM(PDT.ActualWaterWeight) AS ActualWaterUsage,
						 	CAST(SUM(PDT.ActualWaterWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS ActualWaterUsagePerLoad,
						  CAST(SUM(PDT.StandardWaterWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS TargetWaterUsagePerLoad,
						  SUM(PDT.ActualEnergyWeight) AS ActualEnergyUsage,
						  CAST(SUM(PDT.ActualEnergyWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS ActualEnergyUsagePerLoad,
						  CAST(SUM(PDT.StandardEnergyWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS TargetEnergyUsagePerLoad,
						  CAST(SUM(PDT.ActualChemicalWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS ActualChemicalUsageperLoad,
						  CAST(SUM(PDT.StandardChemicalWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS TargetChemicalUsageperLoad,
					   'Week' AS SwithMode,
				    CAST(SUM([ActualChemicalWeight]) AS Decimal(18,2)) AS ActualChemicalWeight,
				    CAST(SUM([ActualWaterWeight]) AS Decimal(18,2)) AS [ActualWaterWeight],
				    CAST(SUM([ActualEnergyWeight]) AS Decimal(18,2)) AS [ActualEnergyWeight],
				CAST(SUM([StandardChemicalWeight]) AS Decimal(18,2)) AS StandardChemicalWeight,
				CAST(SUM([StandardWaterWeight]) AS Decimal(18,2)) AS [StandardWaterWeight],
				CAST(SUM([StandardEnergyWeight]) AS Decimal(18,2)) AS [StandardEnergyWeight],
				SUM(ChemicalCost) AS [ChemicalCost],
				SUM(WaterCost) AS WaterCost,
				SUM(EnergyCost) AS EnergyCost
						  FROM @OperationsSummaryTable PDT
				       WHERE RecordDate BETWEEN @FirstSunday AND @LastSaturday
					  AND 
					   (ProgramNumber = @FormulaId OR EcolabTextileId = @EcolabTextileId OR PlantTextileId = @TextileCareCustomerId)
					   GROUP BY Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101),
							  Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101)

					  UNION ALL

					   SELECT 
							 CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,1,@LastSaturday)) = 1 
							 AND (SELECT COUNT(1) FROM @OperationsSummaryTable WHERE RecordDate > DATEADD(DD,1,@LastSaturday)) = 0)
							 THEN 
							 CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) 
							 ELSE
							CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @LastDay, 101) AS nvarchar(100)) END   As DateRange,
							 SUM(PDT.ActualWeight) AS TotalLoad,
							 CAST(SUM(PDT.ActualWeight) * 100/@summingActualLoad AS DECIMAL(18,2)) AS ProductionMix,
							 COUNT(DISTINCT PDT.BatchId) AS NumberOfLoads,
							 SUM(PDT.ActualWaterWeight) AS ActualWaterUsage,
							 CAST(SUM(PDT.ActualWaterWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS ActualWaterUsagePerLoad,
							 CAST(SUM(PDT.StandardWaterWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS TargetWaterUsagePerLoad,
							 SUM(PDT.ActualEnergyWeight) AS ActualEnergyUsage,
							 CAST(SUM(PDT.ActualEnergyWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS ActualEnergyUsagePerLoad,
							 CAST(SUM(PDT.StandardEnergyWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS TargetEnergyUsagePerLoad,
							 CAST(SUM(PDT.ActualChemicalWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS ActualChemicalUsageperLoad,
							 CAST(SUM(PDT.StandardChemicalWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS TargetChemicalUsageperLoad,
							 'Week' AS SwithMode,
				    CAST(SUM([ActualChemicalWeight]) AS Decimal(18,2)) AS ActualChemicalWeight,
				    CAST(SUM([ActualWaterWeight]) AS Decimal(18,2)) AS [ActualWaterWeight],
				    CAST(SUM([ActualEnergyWeight]) AS Decimal(18,2)) AS [ActualEnergyWeight],
				CAST(SUM([StandardChemicalWeight]) AS Decimal(18,2)) AS StandardChemicalWeight,
				CAST(SUM([StandardWaterWeight]) AS Decimal(18,2)) AS [StandardWaterWeight],
				CAST(SUM([StandardEnergyWeight]) AS Decimal(18,2)) AS [StandardEnergyWeight],
				SUM(ChemicalCost) AS [ChemicalCost],
				SUM(WaterCost) AS WaterCost,
				SUM(EnergyCost) AS EnergyCost
							 FROM @OperationsSummaryTable PDT
					   WHERE RecordDate > @LastSaturday AND RecordDate <= @LastDay
					   AND 
					   (ProgramNumber = @FormulaId OR EcolabTextileId = @EcolabTextileId OR PlantTextileId = @TextileCareCustomerId )
					   )
					   SELECT
							0 AS Id,
							DateRange,
							TotalLoad,
							ProductionMix,
							NumberOfLoads,
							ActualWaterUsage,
							ActualWaterUsagePerLoad,
							TargetWaterUsagePerLoad,
							ActualEnergyUsage,
							ActualEnergyUsagePerLoad,
							TargetEnergyUsagePerLoad,
							ActualChemicalUsageperLoad,
							TargetChemicalUsageperLoad,
							SwithMode,@IsDrillDown AS IsDrillDown,
							ActualChemicalWeight,
							ActualWaterWeight,
							ActualEnergyWeight,
							StandardChemicalWeight,
							StandardWaterWeight,
							StandardEnergyWeight,
							[ChemicalCost],
							WaterCost,
							EnergyCost						
							 
							INTO #ProdTableWeekOrder
							  FROM CTE 
								    WHERE TotalLoad IS NOT NULL

					   

					   SET @SQLStatement 
								='SELECT * FROM #ProdTableWeekOrder ORDER BY ' + @SortField + ' ' + @SortDirection

	   				   EXEC(@SQLStatement)
				END
				
		  IF(@QuarterWise = 1)

			 BEGIN 

			 
			   SELECT @summingActualLoad = SUM(ActualWeight)  FROM @OperationsSummaryTable 
			 WHERE (ProgramNumber = @FormulaId OR EcolabTextileId = @EcolabTextileId OR PlantTextileId = @TextileCareCustomerId )

		  		 SELECT 
					    0 AS Id,
					    DATENAME(MONTH, RecordDate) As DateRange ,
					    SUM(PDT.ActualWeight) AS TotalLoad,
						 CAST(SUM(PDT.ActualWeight) * 100/@summingActualLoad AS DECIMAL(18,2)) AS ProductionMix,
						 COUNT(DISTINCT PDT.BatchId) AS NumberOfLoads,
						 SUM(PDT.ActualWaterWeight) AS ActualWaterUsage,
						 	CAST(SUM(PDT.ActualWaterWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS ActualWaterUsagePerLoad,
						  CAST(SUM(PDT.StandardWaterWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS TargetWaterUsagePerLoad,
						  SUM(PDT.ActualEnergyWeight) AS ActualEnergyUsage,
						  CAST(SUM(PDT.ActualEnergyWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS ActualEnergyUsagePerLoad,
						  CAST(SUM(PDT.StandardEnergyWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS TargetEnergyUsagePerLoad,
						  CAST(SUM(PDT.ActualChemicalWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS ActualChemicalUsageperLoad,
						  CAST(SUM(PDT.StandardChemicalWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS TargetChemicalUsageperLoad,
					   'Quarter' AS SwithMode,
					   DATEPART(MONTH, RecordDate) AS SortDateRange,@IsDrillDown AS IsDrillDown,

				    CAST(SUM([ActualChemicalWeight]) AS Decimal(18,2)) AS ActualChemicalWeight,
				    CAST(SUM([ActualWaterWeight]) AS Decimal(18,2)) AS [ActualWaterWeight],
				    CAST(SUM([ActualEnergyWeight]) AS Decimal(18,2)) AS [ActualEnergyWeight],
				CAST(SUM([StandardChemicalWeight]) AS Decimal(18,2)) AS StandardChemicalWeight,
				CAST(SUM([StandardWaterWeight]) AS Decimal(18,2)) AS [StandardWaterWeight],
				CAST(SUM([StandardEnergyWeight]) AS Decimal(18,2)) AS [StandardEnergyWeight],
				SUM(ChemicalCost) AS [ChemicalCost],
				SUM(WaterCost) AS WaterCost,
				SUM(EnergyCost) AS EnergyCost

					    INTO #ProdTableMonthOrder					   

					    FROM @OperationsSummaryTable PDT
				    WHERE (ProgramNumber = @FormulaId OR EcolabTextileId = @EcolabTextileId OR PlantTextileId = @TextileCareCustomerId )
				    GROUP BY DATEPART(MONTH, RecordDate),DATENAME(MONTH, RecordDate)
				
				     SET @SQLStatement 
								='SELECT 
									   Id,
									   DateRange,
									   TotalLoad,
									   ProductionMix,
									   NumberOfLoads,
									   ActualWaterUsage,
									   ActualWaterUsagePerLoad,
									   TargetWaterUsagePerLoad,
									   ActualEnergyUsage,
									   ActualEnergyUsagePerLoad,
									   TargetEnergyUsagePerLoad,
									   ActualChemicalUsageperLoad,
									   TargetChemicalUsageperLoad,
									   SwithMode,IsDrillDown,

									   ActualChemicalWeight,
									   ActualWaterWeight,
									   ActualEnergyWeight,
									   StandardChemicalWeight,
									   StandardWaterWeight,
									   StandardEnergyWeight,
									   ChemicalCost,
									   WaterCost,
									   EnergyCost

									    FROM #ProdTableMonthOrder ORDER BY ' + CASE @SortField WHEN 'DateRange' THEN 'SortDateRange' ELSE @SortField END + ' ' + @SortDirection

	   				   EXEC(@SQLStatement)

		  END
	   IF(@YearWise = 1)

		  BEGIN 

		  
			   SELECT @summingActualLoad = SUM(ActualWeight)  FROM @OperationsSummaryTable 
			 WHERE (ProgramNumber = @FormulaId OR EcolabTextileId = @EcolabTextileId OR PlantTextileId = @TextileCareCustomerId )

				 DECLARE @Year VARCHAR(100) = RIGHT(YEAR(@FromDate),2)

			SELECT 
				  0 AS Id,
				 CASE 'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10))
										 WHEN 'Q1' THEN 'Jan' + @Year + '- Mar' + @Year
										 WHEN 'Q2' THEN 'Apr' + @Year + '- Jun' + @Year
										 WHEN 'Q3' THEN 'Jul' + @Year + '-Sep' + @Year
										 WHEN 'Q4' THEN 'Oct' + @Year + '- Dec'+ @Year
				END as DateRange,
				 SUM(PDT.ActualWeight) AS TotalLoad,
				CAST(SUM(PDT.ActualWeight) * 100/@summingActualLoad AS DECIMAL(18,2)) AS ProductionMix,
				 COUNT(DISTINCT PDT.BatchId) AS NumberOfLoads,
				 SUM(PDT.ActualWaterWeight) AS ActualWaterUsage,
				 CAST(SUM(PDT.ActualWaterWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS ActualWaterUsagePerLoad,
				CAST(SUM(PDT.StandardWaterWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS TargetWaterUsagePerLoad,
				SUM(PDT.ActualEnergyWeight) AS ActualEnergyUsage,
				CAST(SUM(PDT.ActualEnergyWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS ActualEnergyUsagePerLoad,
				CAST(SUM(PDT.StandardEnergyWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS TargetEnergyUsagePerLoad,
				CAST(SUM(PDT.ActualChemicalWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS ActualChemicalUsageperLoad,
				CAST(SUM(PDT.StandardChemicalWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS TargetChemicalUsageperLoad,
				'Year' AS SwithMode,
				'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10)) as SortDateRange,@IsDrillDown AS IsDrillDown,

				   CAST(SUM([ActualChemicalWeight]) AS Decimal(18,2)) AS ActualChemicalWeight,
				    CAST(SUM([ActualWaterWeight]) AS Decimal(18,2)) AS [ActualWaterWeight],
				    CAST(SUM([ActualEnergyWeight]) AS Decimal(18,2)) AS [ActualEnergyWeight],
				CAST(SUM([StandardChemicalWeight]) AS Decimal(18,2)) AS StandardChemicalWeight,
				CAST(SUM([StandardWaterWeight]) AS Decimal(18,2)) AS [StandardWaterWeight],
				CAST(SUM([StandardEnergyWeight]) AS Decimal(18,2)) AS [StandardEnergyWeight],
				SUM(ChemicalCost) AS [ChemicalCost],
				SUM(WaterCost) AS WaterCost,
				SUM(EnergyCost) AS EnergyCost
				 INTO #ProdTableyearOrder

				 FROM @OperationsSummaryTable PDT

			 GROUP BY DATEPART(QUARTER, RecordDate)

			   SET @SQLStatement 
								='SELECT 
									    Id,
									    DateRange,
									    TotalLoad,
									    ProductionMix,
									    NumberOfLoads,
									    ActualWaterUsage,
									    ActualWaterUsagePerLoad,
									    TargetWaterUsagePerLoad,
									    ActualEnergyUsage,
									    ActualEnergyUsagePerLoad,
									    TargetEnergyUsagePerLoad,
									    ActualChemicalUsageperLoad,
									    TargetChemicalUsageperLoad,
									    SwithMode,IsDrillDown,
									    ActualChemicalWeight,
									   ActualWaterWeight,
									   ActualEnergyWeight,
									   StandardChemicalWeight,
									   StandardWaterWeight,
									   StandardEnergyWeight
									   ChemicalCost,
									   WaterCost,
									   EnergyCost

									    FROM #ProdTableyearOrder ORDER BY ' + CASE @SortField WHEN 'DateRange' THEN 'SortDateRange' ELSE @SortField END + ' ' + @SortDirection

	   				   EXEC(@SQLStatement)

		  END			
END