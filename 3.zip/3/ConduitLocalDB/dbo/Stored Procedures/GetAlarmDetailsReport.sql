CREATE PROCEDURE [TCD].[GetAlarmDetailsReport] (
										  @Corporate Varchar(max) = '',
										  @Country Varchar(max) = '',
										  @Region Varchar(max) = '',
										  @EcolabAccountNumber Nvarchar(25) = '',
										  @Controller Varchar(max) = '',
										  @Machine Varchar(max) = '', 
										  @machineGroup Varchar(max) = '',
										  @Formula Varchar(max) = '',
										  @MachineType Varchar(20)= '',
										  @Alarm Varchar(max) = '',
										  @FromDate Datetime = '',
										  @ToDate Datetime = '',
										  @GroupId Varchar(max) = '',
										  @MachineInternalId Varchar(max) = '',
										  @SortColumnID INT = NULL,
										  @SortDirection Varchar(100) = '',
										  @UserId INT = NULL,
										  @PageNo	INT	 = NULL,
										  @RecordsPerPage INT = NULL
									   )
AS   
BEGIN   
SET NOCOUNT ON;   

-- SET @FromDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@FromDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@FromDate AS time)) AS DateTime))
-- SET @ToDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@ToDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@ToDate AS time)) AS DateTime))


DECLARE @ReportGenerated INT = 6
/* Inserting the record into Report History */
SET @PageNo = @PageNo-1
INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)
SELECT @EcolabAccountNumber,UM.UserId,
	  UM.LoginName,
	  GETUTCDATE(),
	  @ReportGenerated,
	  CASE WHEN @ReportGenerated = 6
		THEN 'Generated Report : AlarmDetailsReport' END
	  FROM TCD.UserMaster UM
	    WHERE	UM.EcolabAccountNumber =	@EcolabAccountNumber AND UM.UserId = @UserId

/* Completed the record insertion into Report History */

DECLARE @Month INT = MONTH(GETDATE()),
	   @SortField Varchar(100) = '',
	   @SummationInMin Int = NULL,
	   @SQLStatement varchar(max)

	     SELECT @SortField =  CASE WHEN @SortColumnID = 13 THEN 'AlarmDescription'
						WHEN @SortColumnID = 14 THEN 'AlarmCode'
						WHEN @SortColumnID = 69 THEN 'EndDate'
						WHEN @SortColumnID = 168 THEN 'StartDate'
						WHEN @SortColumnID = 247 THEN 'Controller'
						WHEN @SortColumnID = 248 THEN 'AlarmCode'
						WHEN @SortColumnID = 249 THEN 'WasherNumber'
						WHEN @SortColumnID = 250 THEN 'BatchId'
						WHEN @SortColumnID = 251 THEN 'ValveNumber'
						WHEN @SortColumnID = 252 THEN 'ChemicalName'
						WHEN @SortColumnID = 253 THEN 'InjectionNo'
						WHEN @SortColumnID = 254 THEN 'FormulaNo'
						WHEN @SortColumnID = 255 THEN 'FormulaName'
						WHEN @SortColumnID = 256 THEN 'DesiredValue'
						WHEN @SortColumnID = 257 THEN 'MeasuredValue'
						WHEN @SortColumnID = 258 THEN 'IsActiveStatus'
						WHEN @SortColumnID = 0 THEN 'StartDate'
						 END



DECLARE @ControllerTable TABLE(Controller Varchar(100))
INSERT INTO @ControllerTable(Controller) EXEC [TCD].[charlistToTable] @Controller,','

DECLARE @MachineTable TABLE(Machine Varchar(100))
INSERT INTO @MachineTable(Machine) EXEC [TCD].[charlistToTable] @Machine,','

DECLARE @GroupMachineTable TABLE(GroupId INT,MachineInternalId INT)  
INSERT INTO @GroupMachineTable(GroupId,MachineInternalId) 
SELECT GroupId,MachineInternalId FROM TCD.MachineSetup MS 
									INNER JOIN TCD.Washer WS ON MS.WasherId = WS.WasherId WHERE WS.PlantWasherNumber IN (SELECT Machine FROM @MachineTable);

DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))
INSERT INTO @WasherGroupTable(MachineGroup) EXEC [TCD].[charlistToTable] @machineGroup,','

DECLARE @FormulaTable TABLE(Formula Varchar(100))
INSERT INTO @FormulaTable(Formula) EXEC [TCD].[charlistToTable] @Formula,','

DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))
INSERT INTO @MachineTypeTable(MachineType) EXEC [TCD].[charlistToTable] @MachineType,','

DECLARE @AlarmsTable TABLE(Alarm Varchar(100))
INSERT INTO @AlarmsTable(Alarm) EXEC [TCD].[charlistToTable] @Alarm,','

DECLARE @GroupTable TABLE(GroupId Varchar(100))
INSERT INTO @GroupTable(GroupId) EXEC [TCD].[CharlistToTable] @GroupId,','

DECLARE @MachineInternalTable TABLE(MachineInternalId Varchar(100))
INSERT INTO @MachineInternalTable(MachineInternalId) EXEC [TCD].[CharlistToTable] @MachineInternalId,','

	  DECLARE @AlarmTable TABLE(
							 AlarmCode Int,
							 AlarmDescription NVarchar(2000),
							 Controller Nvarchar(100),
							 StartDate Datetime,
							 EndDate Datetime,
							 SecDuration INT,
							 WasherNumber INT,
							 PlantWasherNumber INT,
							 BatchID INT,
							 ValveNumber INT,
							 ChemicalName Nvarchar(1000),
							 InjectionNo INT,
							 FormulaNo INT,
							 FormulaName Nvarchar(1000),
							 DesiredValue decimal(10,2),
							 MeasuredValue decimal(10,2),
							 IsActiveStatus BIT,
							 ROWNUM bigint
							
    						  )

;WITH NonPonyWashers_CTE (WasherId,
                                 PlantWasherNumber)
              AS (SELECT MS.WasherId,
                         w.PlantWasherNumber
                  FROM TCD.MachineSetup AS MS
                       INNER JOIN TCD.Washer AS w ON w.WasherId = MS.WasherId
                 -- WHERE MS.IsPony = 0  
)

INSERT INTO @AlarmTable(
							 AlarmCode ,
							 AlarmDescription ,
							 Controller ,
							 StartDate ,
							 EndDate ,
							 SecDuration ,
							 WasherNumber ,
							 PlantWasherNumber,
							 BatchID ,
							 ValveNumber ,
							 ChemicalName,
							 InjectionNo ,
							 FormulaNo ,
							 FormulaName ,
							 DesiredValue ,
							 MeasuredValue ,
							 IsActiveStatus ,
							 ROWNUM
    						  )
SELECT 
		  DISTINCT
			  AD.AlarmCode,	
	   		  AM.Description,	
			  cc.Name  AS Controller,	 
			  AD.StartDate,
			  AD.EndDate,
			  DATEDIFF(SECOND,AD.StartDate,AD.EndDate),
			  MS.WasherId,
			  MS.PlantWasherNumber,
			  AD.BatchId,
			  AD.Valve,
			  PM.Name,
			  AD.InjectionNumber,
			  AD.ProgramId,
			  PP.Name,
			  AD.DesiredQuatity,
			  AD.MeasuredQuantity,
			  AD.IsActive
			  ,ROW_NUMBER() OVER (ORDER BY
        CASE WHEN (@SortColumnID = 13 AND @SortDirection='ASC')
                    THEN AM.Description
        END ASC,
         CASE WHEN (@SortColumnID = 13 AND @SortDirection='DESC')
                    THEN AM.Description
        END DESC,

        CASE WHEN (@SortColumnID = 14 AND @SortDirection='ASC')
                  THEN AD.AlarmCode
        END ASC,
        CASE WHEN @SortColumnID = 14  AND @SortDirection='DESC'
                 THEN AD.AlarmCode
        END DESC,

        CASE WHEN @SortColumnID = 69 AND @SortDirection='ASC'
                THEN AD.EndDate
        END ASC,
        CASE WHEN @SortColumnID = 69 AND @SortDirection='DESC'
                THEN AD.EndDate
        END DESC,

        CASE WHEN @SortColumnID = 168 AND @SortDirection='ASC'
                THEN AD.StartDate
        END ASC,
        CASE WHEN @SortColumnID = 168 AND @SortDirection='DESC'
               THEN AD.StartDate
        END DESC,

        CASE WHEN @SortColumnID = 247 AND @SortDirection='ASC'
                THEN cc.Name
        END ASC,
        CASE WHEN @SortColumnID = 247 AND @SortDirection='DESC'
               THEN cc.Name
        END DESC,
		CASE WHEN @SortColumnID = 248 AND @SortDirection='ASC'
                THEN AD.AlarmCode
        END ASC,
        CASE WHEN @SortColumnID = 248 AND @SortDirection='DESC'
               THEN AD.AlarmCode
        END DESC,
		CASE WHEN @SortColumnID = 249 AND @SortDirection='ASC'
                THEN MS.WasherId
        END ASC,
        CASE WHEN @SortColumnID = 249 AND @SortDirection='DESC'
               THEN MS.WasherId
        END DESC,
		CASE WHEN @SortColumnID = 250 AND @SortDirection='ASC'
                THEN  AD.BatchId
        END ASC,
        CASE WHEN @SortColumnID = 250 AND @SortDirection='DESC'
               THEN  AD.BatchId
        END DESC,
		CASE WHEN @SortColumnID = 251 AND @SortDirection='ASC'
                THEN AD.Valve
        END ASC,
        CASE WHEN @SortColumnID = 251 AND @SortDirection='DESC'
               THEN AD.Valve
        END DESC,
		CASE WHEN @SortColumnID = 252 AND @SortDirection='ASC'
                THEN PM.Name
        END ASC,
        CASE WHEN @SortColumnID = 252 AND @SortDirection='DESC'
               THEN PM.Name
        END DESC,
		CASE WHEN @SortColumnID = 253 AND @SortDirection='ASC'
                THEN AD.InjectionNumber
        END ASC,
        CASE WHEN @SortColumnID = 253 AND @SortDirection='DESC'
               THEN AD.InjectionNumber
        END DESC,
		CASE WHEN @SortColumnID = 254 AND @SortDirection='ASC'
                THEN AD.ProgramId
        END ASC,
        CASE WHEN @SortColumnID = 254 AND @SortDirection='DESC'
               THEN AD.ProgramId
        END DESC,
		CASE WHEN @SortColumnID = 255 AND @SortDirection='ASC'
                THEN PP.Name
        END ASC,
        CASE WHEN @SortColumnID = 255 AND @SortDirection='DESC'
               THEN PP.Name
        END DESC,
		CASE WHEN @SortColumnID = 256 AND @SortDirection='ASC'
                THEN AD.DesiredQuatity 
        END ASC,
        CASE WHEN @SortColumnID = 256 AND @SortDirection='DESC'
               THEN AD.DesiredQuatity
        END DESC,
		CASE WHEN @SortColumnID = 257 AND @SortDirection='ASC'
                THEN AD.MeasuredQuantity
        END ASC,
        CASE WHEN @SortColumnID = 257 AND @SortDirection='DESC'
               THEN AD.MeasuredQuantity
        END DESC,
		CASE WHEN @SortColumnID = 258 AND @SortDirection='ASC'
                THEN  AD.IsActive
        END ASC,
        CASE WHEN @SortColumnID = 258 AND @SortDirection='DESC'
               THEN  AD.IsActive
        END DESC,
		CASE WHEN @SortColumnID = 0 AND @SortDirection='ASC'
                THEN StartDate
        END ASC,
        CASE WHEN @SortColumnID = 0 AND @SortDirection='DESC'
               THEN StartDate
        END DESC
		) AS ROWNUM
	FROM [TCD].AlarmData AS AD
		   INNER JOIN [TCD].AlarmGroupMaster AM ON AD.AlarmGroupMasterId = AM.AlarmGroupMasterId
		   LEFT JOIN [TCD].ConduitController cc ON cc.ControllerId = AD.ControllerId
		   LEFT JOIN NonPonyWashers_CTE MS ON MS.WasherId = AD.MachineId		   
		   LEFT JOIN [TCD].ControllerEquipmentSetup CES ON AD.Valve = CES.ControllerEquipmentId AND AD.ControllerId = CES.ControllerId
		   LEFT JOIN [TCD].ProductMaster PM ON CES.ProductId = PM.ProductId
		   LEFT JOIN [TCD].ProgramMaster PP ON AD.ProgramId = PP.ProgramId

		    WHERE  
				CASE @Controller   
				 WHEN '' THEN 'TRUE'         
				 ELSE                                                      
				  CASE WHEN AD.ControllerId IN (SELECT Controller FROM @ControllerTable) THEN 'TRUE' END                                                      
				END='TRUE' 

				AND       
				CASE @Machine   
				WHEN '' THEN 'TRUE'         
				ELSE                                                      
				CASE WHEN AD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
				END='TRUE' 
				AND       

				CASE @machineGroup   
	   			WHEN '' THEN 'TRUE'         
				ELSE                                                      
				CASE WHEN AD.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable) THEN 'TRUE' END                                    
				END='TRUE' 
				AND    

				CASE @Formula   
	     		WHEN '' THEN 'TRUE'         
				ELSE                                                      
				CASE WHEN AD.ProgramId IN (SELECT Formula FROM @FormulaTable) AND AD.AlarmCode NOT IN (9000) THEN 'TRUE' END                                                      
				END='TRUE' 
				AND       

				CASE @MachineType   
				WHEN '' THEN 'TRUE'         
				ELSE                                                      
				cASE WHEN AD.GroupId IN (SELECT WG.WasherGroupId FROM [TCD].WasherGroup WG WHERE WG.WasherGroupTypeId IN (select MachineType from @MachineTypeTable)) THEN 'TRUE' END                                                      
				END='TRUE' 

				AND       
				CASE @FromDate                                                                                
				WHEN '' THEN Case WHEN MONTH(AD.StartDate) = @Month Then  'true' END                                                                                
				ELSE CASE WHEN AD.StartDate >= @FromDate and AD.StartDate<= @ToDate 
				AND AD.EndDate IS NOT NULL AND ISNULL(AD.IsActive,0)=0
				THEN 'true'END                                                        
				END='true'

				AND
				CASE @Alarm   
				WHEN '' THEN 'TRUE'         
				ELSE                                                      
				CASE WHEN AD.AlarmCode IN (SELECT distinct
														AlarmCode FROM TCD.AlarmGroupMsterVsControllerModelType where AlarmGroupMasterId IN (SELECT
														Alarm FROM @Alarmstable)) THEN 'TRUE' END                                                      
				END='TRUE' 

				AND
				CASE @GroupId 
	   			WHEN '' THEN 'TRUE' 
				ELSE        
				CASE WHEN (AD.GroupId IN (@GroupId) AND 
				AD.MachineInternalId  IN (@MachineInternalId)) THEN 'TRUE' END                                                   
				END='TRUE' 
				AND

				CASE @MachineInternalId 
                    WHEN '' THEN 'TRUE' 
				ELSE        
				CASE WHEN (AD.GroupId IN (@GroupId) AND 
				AD.MachineInternalId  IN (@MachineInternalId)) THEN 'TRUE' END                                                   
				END='TRUE' 
				
		
		DECLARE @max int =(SELECT max( ROWNUM) FROM @AlarmTable) 
					
			SELECT   AlarmCode,
						AlarmDescription,
						
						StartDate,  
						EndDate,
						--SecDuration, 
						(SELECT RIGHT('0' + CAST(DATEDIFF(SECOND,C.StartDate,C.EndDate) / 3600 AS VARCHAR),4) + ':' +
							RIGHT('0' + CAST((DATEDIFF(SECOND,C.StartDate,C.EndDate) / 60) % 60 AS VARCHAR),2)  + ':' +
							RIGHT('0' + CAST(DATEDIFF(SECOND,C.StartDate,C.EndDate) % 60 AS VARCHAR),2)) AS AlarmDuration,
							Controller,
						PlantWasherNumber,  
						BatchId, 
						ValveNumber, 
						ChemicalName,
						InjectionNo,
						FormulaNo, 
						FormulaName, 
						DesiredValue, 
						MeasuredValue, 
						IsActiveStatus,
						@max as TotalCount,
						ROWNUM
	   

		             
			FROM @AlarmTable C
			WHERE ROWNUM BETWEEN (@PageNo * @RecordsPerPage)+1 AND (@PageNo+1)*@RecordsPerPage
			ORDER BY ROWNUM



SET nocount OFF;
END
