﻿/*                                            
###################################################################################################                                                   
        
Stored Procedure:       [dbo].[usp_GetManualProductionDetails]                                                   
        
Purpose:    To get the manual production details.        
        
Parameters:    @WasherGroupId - holds the washer group id.        
      @WasherId - holds the washer id.        
      @FormulaId - holds the formula id.        
      @EcoLabAccountNumber - holds the ecolab account number.        
                        
###################################################################################################                                                   
*/      
/*
-- Usage
EXEC [TCD].[GetManualProductionDetails] '3'
,1, 1,'040000361','2015-10-01', 50, 1    


*/  
CREATE PROCEDURE [TCD].[GetManualProductionDetails]        
 (        
 @WasherGroupId NVARCHAR(1000),         
 @WasherId INT,        
 @FormulaId INT,        
 @EcolabAccountNumber NVARCHAR(25)    ,
 @RecordedDate DATETIME
   , @RowsPerPage INT =50
  , @PageNumber INT = 1     
 )        
AS         
  BEGIN         
     SET NOCOUNT ON
	  IF @PageNumber < 1 
	   SET @PageNumber = 1 
	            
    if(@FormulaId = 0)      
    BEGIN      
    set @FormulaId = null      
    END      
   SELECT       
      MP.ProductionId,       
      MP.FormulaId,      
      MP.RecordedDate,         
      MP.Value    ,    
      PM.Name,
	  Count(*) Over() TotalRows    
    FROM  [TCD].ManualProduction  AS MP    
  JOIN [TCD].[ProgramMaster]  AS PM ON MP.FormulaId = PM.ProgramId    
   WHERE         
      MP.WasherGroupId IN( SELECT cast(items as int) FROM [TCD].[CharacterListToTable](@WasherGroupId,','))      
      AND MP.WasherId = @WasherId         
      AND MP.FormulaId = COALESCE(@FormulaId,  FormulaId)       
      AND MP.EcolabAccountNumber = @EcolabAccountNumber      
      AND MP.RecordedDate >= @RecordedDate
      AND MP.IsDeleted <> 1        
   ORDER BY ProductionId DESC
   
   OFFSET (@PageNumber-1)*@RowsPerPage ROWS
   FETCH NEXT @RowsPerPage ROWS ONLY         
  SET NOCOUNT OFF        
  END      
    