﻿CREATE PROCEDURE [TCD].[ProcessMyControlProductionWaterConsumptionData]
(
    @BatchId			   INT,
    @WaterConsumptionXML	   XML,
    @PartitionOn		   DATETIME
)
AS
    BEGIN
	   DECLARE @WaterTypeId		 INT,
			 @StandardQuantity	 INT,
			 @Price			 INT,
			 @EcolabWasherID	 INT


			SELECT   @EcolabWasherID=bd.EcolabWasherId  
			FROM TCD.BatchData bd
			WHERE bd.BatchId=@BatchId 
			 -- 1.Getting xml data  into XmlData with CTE
			 ;WITH XmlData AS 
			 (
				SELECT  T.c.value('@StepNo', 'INT') StepNo,
					   T.c.value('@WCCounter1', 'Decimal(10,2)') + T.c.value('@WCCounter2', 'Decimal(10,2)')  ActualQuantity
				FROM @WaterConsumptionXML.nodes('MyControlConventionalData/WaterConsumptionData/StepConsumption') T(c)
			 )
			 -- inserting records into tcd.BatchStepWaterUsageData table using merge statement
			 MERGE INTO tcd.BatchStepWaterUsageData bswud
			 USING
			 (
				SELECT xd.StepNo,
					  xd.ActualQuantity
				   FROM XmlData xd
			 ) temp 
			 ON bswud.BatchId = @BatchId AND bswud.stepCompartment=temp.stepNo AND bswud.ActualQuantity=temp.ActualQuantity
			 WHEN NOT MATCHED AND
			 (
				temp.ActualQuantity > 0 
			 )
			 THEN 
			 INSERT
			 (
				Batchid,
				StepCompartment,
				WaterTypeId,
				ActualQuantity,
				StandardQuantity,
				Price,
				PartitionOn,
				EcolabWasherId
			 )
			 VALUES
			 (
				@BatchId,
				temp.StepNo,
				NULL,
				temp.ActualQuantity,
				NULL,
				NULL,
				@PartitionOn,
				@EcolabWasherID
			 );
    END