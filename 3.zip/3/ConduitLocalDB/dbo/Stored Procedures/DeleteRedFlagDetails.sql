﻿/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_DeleteRedFlagDetails]                                           

Purpose:				To delete the red flag details.

Parameters:				@ID - holds the Id.
						@EcoLabAccountNumber - holds the ecolab account number.
						@UserID - holds the user id.
																
###################################################################################################                                           
*/

CREATE PROCEDURE [TCD].[DeleteRedFlagDetails] (
@ID int,
@EcolabAccountNumber nvarchar(25),
@UserID INT = NULL,
@LastModifiedTimestampAtCentral			DATETIME		=	NULL,
@OutputLastModifiedTimestampAtLocal		DATETIME		=	NULL	OUTPUT
) 
AS 
SET NOCOUNT ON
BEGIN 
	DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	--,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()				--SQLEnlight SA0004

	DECLARE
		@OutputList						AS	TABLE		(
		LastModifiedTimestamp			DATETIME		)

	SET	@OutputLastModifiedTimestampAtLocal			=			ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight SA0121

   BEGIN   
   IF	(
		@LastModifiedTimestampAtCentral				IS NOT	NULL
		AND
		NOT	EXISTS	(	SELECT	1
				FROM	TCD.RedFlag					RF
				WHERE	RF.EcolabAccountNumber	=	@EcolabAccountNumber
					AND	RF.Id					=	@Id
					AND	RF.LastModifiedTime		=	@LastModifiedTimestampAtCentral
			)
	)
	BEGIN
			SET			@ErrorId				=	60000
			SET			@ErrorMessage			=	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
			RAISERROR	(@ErrorMessage, 16, 1)
			SET			@ReturnValue			=	-1
			RETURN		(@ReturnValue)
	END
     UPDATE [TCD].RedFlag 
		  SET 
				Is_Deleted = 1,
				LastModifiedByUserId =@UserID
				OUTPUT
					inserted.LastModifiedTime	AS	LastModifiedTimestamp
				INTO
					@OutputList	(
					LastModifiedTimestamp
				)
		  FROM [TCD].RedFlag
		  WHERE ID = @Id 
				AND EcolabAccountNumber = @EcolabAccountNumber

	UPDATE [TCD].RedFlagMappingData 
		  SET 
				Is_Deleted = 1,
				LastModifiedByUserId = @UserID
		  FROM [TCD].RedFlagMappingData	
    		  WHERE MappingId = @ID
 
  SELECT	TOP 1	
		@OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp
		FROM	@OutputList							O

	RETURN	(@ReturnValue)
  END
  SET NOCOUNT OFF
END