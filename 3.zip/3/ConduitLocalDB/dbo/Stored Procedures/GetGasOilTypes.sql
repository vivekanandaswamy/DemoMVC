﻿CREATE PROCEDURE [TCD].[GetGasOilTypes] @EcolabAccountNumber NVARCHAR(25)
AS 

BEGIN

SET NOCOUNT ON;

SELECT DISTINCT gtm.[GasoilId]
	  ,[Name]
	  ,gotm.[DefaultValue]
	  ,(SELECT distinct rkv.[Value]
			FROM TCD.DimensionalSubunits ds
			INNER JOIN 			tcd.DimensionalUnits du ON du.Unit = ds.Unit
			INNER JOIN 			TCD.DimensionalUsageKey duk ON duk.Unit = ds.Unit
			INNER JOIN			TCD.DimensionalUnitsDefaults dud ON dud.UsageKey = duk.UsageKey
			INNER JOIN			TCD.ResourceKeyMaster rkm ON rkm.[KeyName]	= dud.Subunit
			INNER JOIN			tcd.ResourceKeyValue rkv ON rkv.[KeyName]=rkm.[KeyName]
			WHERE				duk.UsageKey = gtm.UsageKey
							AND dud.UnitSystemId=(SELECT p.UOMId FROM TCD.Plant p WHERE p.EcolabAccountNumber=@EcolabAccountNumber)) AS [UOM_Code]
	  ,[UOM_Desc]
	 FROM [TCD].GasoilTypeMaster gtm 
INNER JOIN [TCD].GasOilTypeMapping gotm ON gotm.GasOilId=gtm.GasoilId
WHERE gotm.RegionId=(SELECT p.RegionId FROM TCD.Plant p WHERE p.EcolabAccountNumber=@EcolabAccountNumber)
SET NOCOUNT OFF;
END
