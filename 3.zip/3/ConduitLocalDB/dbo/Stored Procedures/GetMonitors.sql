﻿CREATE PROCEDURE [TCD].[GetMonitors]
(
@EcolabAccountNumber  NVARCHAR(25)
)
AS
BEGIN
SET NOCOUNT ON
		SELECT 
			MonitorId,
			MonitorName+' '+'('+Cast(XBound as varchar)+',' + Cast(YBound as varchar) +')'  AS MonitorName,
			XBound,
			YBound,
			Width,
			Height 
		FROM [TCD].MONITOR 
		WHERE EcolabAccountNumber=@EcolabAccountNumber
		ORDER BY MonitorId
SET NOCOUNT OFF
END