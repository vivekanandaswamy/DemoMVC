﻿
/*  
 ==========================================================================================  
 Purpose:  Using the entire application to fetch the specified Currency Codes.  

 Author:  premchand

 --------------------------------------------------------------  
 July-14-2014 ENT: Initial version.  
 ==========================================================================================  
*/ 
CREATE PROCEDURE [TCD].[GetCurrency] 
AS 
  BEGIN 
      SET nocount ON; 

      SELECT CurrencyMaster.[CurrencyCode], 
             CurrencyMaster.[CurrencyName] 
      FROM   [TCD].CurrencyMaster
     
  END 