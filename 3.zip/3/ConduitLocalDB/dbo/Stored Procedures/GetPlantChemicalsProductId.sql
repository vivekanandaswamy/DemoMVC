﻿/*

Stored Procedure	:	[TCD].[GetPlantChemicalsProductId] 

Purpose				:	To Get the product Id from ProductMaster based on Myservice Prod Id

Parameters			:	@MyServiceProdId					
						
*/
CREATE PROCEDURE [TCD].[GetPlantChemicalsProductId] 
			(
				@MyServiceProdId INT
			) 
AS 
  BEGIN 
      SET nocount ON; 

      SELECT
		     
             PM.ProductID, 
             PM.sku
      FROM   [TCD].productmaster PM 
      WHERE  PM.Is_Deleted = 0 
			 AND
			 PM.MyServiceProdId	= @MyServiceProdId

      SET nocount OFF; 
  END