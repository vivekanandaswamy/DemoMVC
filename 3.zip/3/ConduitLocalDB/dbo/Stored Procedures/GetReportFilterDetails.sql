CREATE PROCEDURE [TCD].[GetReportFilterDetails] 
(
			@ReportId Int = NULL
)
AS   

BEGIN   
SET NOCOUNT ON
SELECT 
		  RF.ReportFilterId,
		  RF.FilterName
	    FROM [TCD].ReportFilter RF
			 INNER JOIN 
			 [TCD].ReportFilterMapping RFM ON RF.ReportFilterId = RFM.FilterId
	    WHERE RFM.ReportId = @ReportId
SET NOCOUNT OFF
END