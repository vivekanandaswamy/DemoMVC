﻿
/*
==========================================================================================
Purpose:  Fetching the shift Labour data.

Author:  Premchand Yelavarthi

--------------------------------------------------------------
SEP-04-2014 ENT: Initial version.
==========================================================================================
*/

CREATE PROCEDURE [TCD].[GetShiftLabourData](@EcolabAccountNumber nvarchar(25), @IsDeleted BIT = 'FALSE')
AS
SET NOCOUNT ON;
BEGIN

SELECT
SLD.LaborId
,SLD.ShiftId
,SLD.DayId
,SLD.LaborTypeId
,LaborTypeName = (SELECT L.Description FROM [TCD].LaborType l WHERE L.LaborTypeId = SLD.LaborTypeId)
,SLD.LocationId
,LoactionName = (SELECT G.GroupDescription FROM [TCD].MachineGroup G WHERE G.Id = SLD.LocationId)
,SLD.LaborHours
,LC.Cost
,SLD.LastModifiedTime                AS            LastModifiedTime
,SLD.LastSyncTime                    AS            LastSyncTime
,SLD.EcolabAccountNumber  AS    EcolabAccountNumber
,SLD.IS_Deleted			AS IsDeleted
FROM [TCD].ShiftData SD
INNER JOIN
[TCD].ShiftLaborData SLD ON SD.ShiftId = SLD.ShiftId AND SD.DayId = SLD.DayId
INNER JOIN [TCD].LaborCost LC ON SLD.LaborTypeId = LC.LaborTypeId
WHERE SD.EcolabAccountNumber = @EcolabAccountNumber AND (SD.Is_Deleted = 'FALSE' OR SD.Is_Deleted = @IsDeleted) AND (SLD.IS_Deleted = 'FALSE' OR SLD.IS_Deleted = @IsDeleted)
SET NOCOUNT OFF;
END