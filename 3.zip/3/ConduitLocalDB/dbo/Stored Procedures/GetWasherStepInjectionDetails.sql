CREATE  PROCEDURE [TCD].[GetWasherStepInjectionDetails]
								    (
									   @EcolabAccountNumber nvarchar(25) = NULL,
									   @WasherDosingSetupId	INT = NULL,
									   @ProgramSetupId	INT = NULL,
									   @InjectionNumber	SMALLINT = NULL
								    )
AS
SET NOCOUNT ON
BEGIN
SELECT  
			 DISTINCT
				WDS.WasherDosingSetupId
				,CAST(WPS.ProgramNumber AS INT) AS ProgramId
				,WG.WasherGroupNumber
				,WDP.InjectionNumber
				,CES.ControllerEquipmentId
				,WDP.ProductId
				,PM.Name
				,WDP.Quantity
				,IJ.ReferenceLoad
				,WDS.StepNumber
				,WS.[StepId] AS WashOperationId
				,WS.[StepName] AS WashOperation			
				,IJ.InjectionClass
				,IJ.ControllerId
				,CT.Id AS ControllerType
			FROM	[TCD].[WasherDosingSetup] WDS

			INNER JOIN [TCD].[WasherProgramSetup] WPS 
				ON WPS.[WasherProgramSetupId] = WDS.[WasherProgramSetupId]
			INNER JOIN TCD.WasherGroup WG ON WG.WasherGroupId = WPS.WasherGroupId
			INNER JOIN TCD.Injection IJ ON WG.WasherGroupNumber = IJ.WasherGroupNumber
			INNER JOIN TCD.ConduitController CC ON IJ.ControllerId = CC.ControllerId
			INNER JOIN TCD.ControllerType CT ON CC.ControllerTypeId = CT.Id

			LEFT JOIN TCD.WasherDosingProductMapping WDP ON WDS.WasherDosingSetupId = WDP.WasherDosingSetupId

			LEFT JOIN TCD.ProductMaster PM ON WDP.ProductId = PM.ProductId
			LEFT JOIN TCD.ControllerEquipmentSetup CES ON CES.ProductId = PM.ProductId 

			LEFT JOIN	[TCD].WashStep				WS
				ON	WS.StepId					=			WDS.StepTypeId
				WHERE   
						  WPS.WasherProgramSetupId = @ProgramSetupId  
					   AND WDS.WasherDosingSetupId =  @WasherDosingSetupId
					   AND WDP.InjectionNumber = @InjectionNumber 
					   AND WPS.EcolabAccountNumber = @EcolabAccountNumber
		
			 
 END