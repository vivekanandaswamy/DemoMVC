﻿CREATE PROCEDURE [TCD].[GetResourceKeyValuesForUom_Reports]
                     (
                       @EcolabAccountNumber Nvarchar(25) = NULL,
                       @UserId Int = NULL
                     )   
AS
SET NOCOUNT ON
BEGIN
DECLARE @UOM Int,@LanguageId Int,@CurrencyCode Varchar(20)
SELECT @UOM = UOMId FROM TCD.UserMaster WHERE TCD.UserMaster.EcolabAccountNumber = @EcolabAccountNumber AND UserId =@UserId 
SELECT @CurrencyCode = P.CurrencyCode FROM TCD.PLANT P WHERE EcolabAccountNumber = @EcolabAccountNumber
SELECT @LanguageId = ISNULL(UM.LanguageId,(SELECT LanguageId FROM TCD.Plant where EcolabAccountNumber = @EcolabAccountNumber)) FROM TCD.UserMaster UM
                    WHERE UM.UserId = @UserId AND EcolabAccountNumber = @EcolabAccountNumber


DECLARE @UnitSystem TABLE
                    (
                       UnitSystemId INT,
                       Unit NVARCHAR(200) ,
                       Subunit NVARCHAR(200),
                       UsageKey NVARCHAR(200),
                       [KeyName] NVARCHAR(200),
                       Value NVARCHAR(800),
                       languageID INT
                    )

INSERT INTO @UnitSystem
  SELECT  UnitSystemId, Unit, Subunit,  UsageKey,RKM.[KeyName],ISNULL(RKV.Value,RKVEn.Value) as Value,ISNULL(RKV.languageID,RKVEn.languageID) as LanguageId
  FROM TCD.DimensionalUnitsDefaults DM
  LEFT OUTER JOIN TCD.ResourceKeyMaster RKM ON DM.Subunit = RKM.[KeyName]
  LEFT OUTER JOIN TCD.ResourceKeyValue RKV ON RKM.KeyName = RKV.KeyName AND RKV.languageID = @LanguageId	
  LEFT OUTER JOIN TCD.ResourceKeyValue RKVEn ON RKM.KeyName = RKVEn.KeyName AND RKVEn.languageID = 1
  WHERE UnitSystemId = @UOM and ISNULL(RKV.languageID,RKVEn.languageID) is not null 
       --UNION ALL
       
          --SELECT 
                -- NULL,   
                --'Cuurency',
                --'Cuurency',
                --'Cuurency',
                --'Cuurency',
                --CASE @CurrencyCode WHEN 'USD' THEN '$'
                --                WHEN 'EUR'THEN '�' END,
                --1
SELECT 
                      UnitSystemId ,
                       Unit  ,
                       Subunit,
                       UsageKey,
                       [KeyName] ,
                       Value ,
                       languageID 
                        FROM @UnitSystem
END