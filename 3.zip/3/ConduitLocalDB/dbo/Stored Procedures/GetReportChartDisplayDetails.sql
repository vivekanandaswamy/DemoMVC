CREATE PROCEDURE [TCD].[GetReportChartDisplayDetails] 
    (
			   @ReportId Int = NULL			   
    )
    AS   
    SET NOCOUNT ON
    BEGIN   

				SELECT 
							RAC.Id,
							RAC.Name
				FROM [TCD].ReportColumns RAC 
				INNER JOIN [TCD].[ReportColumnsMapping] RAM
				ON RAC.ID=RAM.ColumnId
				WHERE RAM.ReportId = @ReportId 					
					AND RAM.IsChartDisplay <> 0
    END