﻿CREATE PROCEDURE [TCD].[GetWaterTypesFromUtility]
 @EcolabAccountNumber nvarchar(25)=NULL,
 @RegionId int = NULL
AS
BEGIN

Declare @Count int

SELECT @Count = count(1) from TCD.WaterUtilityDetails

If(@Count > 0)
	BEGIN
SELECT  wt.Id
   , wt.Name 
    FROM   TCD.WaterUtilityDetails wud 
    JOIN  TCD.WaterType wt  
 ON   wt.Id=wud.WaterFactorTypeId
    WHERE		
	    wud.EcolabAccountNumber=@EcolabAccountNumber AND wt.Id <> 2

	END
ELSE
	BEGIN
		SELECT  Id
			   ,Name 
				
		FROM  TCD.WaterType wt
		
		WHERE MyServiceUtilTypeCode = 'S' AND RegionID = @RegionId AND wt.Id <> 2
	END
	
END

