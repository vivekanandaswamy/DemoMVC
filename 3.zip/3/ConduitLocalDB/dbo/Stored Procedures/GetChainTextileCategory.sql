﻿/*  
 ==========================================================================================  
 Purpose:  Fetching the list chain textile category.  

 Author:  Phani  

 --------------------------------------------------------------  
 August-18-2014 ENT: Initial version.  
 ==========================================================================================  
*/ 
CREATE PROCEDURE [TCD].[GetChainTextileCategory] 
(
@EcolabAccountNumber nvarchar(25) = null
)
AS 
  BEGIN 
      SET nocount ON; 
	 DECLARE @PlantChainId int
	 SET @PlantChainId = (SELECT p.PlantChainId FROM TCD.Plant p WHERE p.EcolabAccountNumber = @EcolabAccountNumber)
      SELECT 
      tc.TextileId
      , tc.Name
      FROM   [TCD].ChainTextileCategory tc
	 WHERE tc.PlantChainId = @PlantChainId and tc.IsDeleted=0
     
  END