﻿CREATE PROC [TCD].[SaveTunnelCompartmentEquipmentValveMapping] (
  @lineCompartmentMappings TCD.TunnelCompartmentEquipmentValveMapping READONLY
    , @ControllerEquipmentId INT
    , @ControllerId INT
    , @LineNumber TINYINT
    , @EcolabAccountNumber NVARCHAR(25)
    , @UserId INT
)
AS
BEGIN
    DECLARE
     @ControllerModelId INT,
     @ControllerTypeId INT;
    (SELECT TOP 1 @ControllerModelId = CC.ControllerModelId
    , @ControllerTypeId = CC.ControllerTypeId
   FROM tcd.ConduitController CC
   WHERE ControllerId = @ControllerId);
    DECLARE
     @EquipmentSetupId INT = (SELECT TOP 1 CES.ControllerEquipmentSetupId
        FROM TCD.ControllerEquipmentSetup CES
        WHERE CES.ControllerId = @ControllerId
          AND CES.ControllerEquipmentId = @ControllerEquipmentId ),
     @PlantId INT = (SELECT TOP 1 PlantId
       FROM TCD.Plant P
       WHERE P.EcolabAccountNumber = @EcolabAccountNumber),
     @DDFlag BIT = CAST(
     CASE
     WHEN EXISTS(SELECT 1
       FROM @lineCompartmentMappings M
       WHERE M.DirectDosingFlag = 1) THEN 1
     ELSE 0
     END
     AS BIT);

    /* Delete the values if not necessary */

    IF @DDFlag = 'TRUE'
    BEGIN
    DELETE FROM TCD.TunnelCompartmentEquipmentValveMapping
      WHERE ControllerEquipmentSetupID = @EquipmentSetupId
    END;
    ELSE
    BEGIN

    /* Validation of max 20 Valves per Tunnel */

    /* Looping for two Machine internal Ids*/

    DECLARE
     @TunnelCount INT = (SELECT TOP 1 CMCTM.NumOfTunnelWasherGroups
           FROM TCD.ControllerModelControllerTypeMapping CMCTM
           WHERE CMCTM.ControllerModelId = @ControllerModelId
         AND CMCTM.ControllerTypeId = @ControllerTypeId);
    DECLARE
     @MaxValveCount INT = CASE
          WHEN @ControllerModelId IN (7, 8) THEN 20
          WHEN @ControllerModelId = 9 THEN 12
          END;
 
    
    IF (SELECT  COUNT(*)
      FROM TCD.TunnelCompartmentEquipmentValveMapping TCEVM
       JOIN
       TCD.ControllerEquipmentSetup CES ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupID
      WHERE CES.ControllerId = @ControllerId
        AND TCEVM.DirectDosingFlag = 'FALSE'
        AND CES.ControllerEquipmentId != @ControllerEquipmentId
        )
       +
       (SELECT COUNT(*)
      FROM @lineCompartmentMappings LCM
      ) > @MaxValveCount
        BEGIN
        RAISERROR ('8014', 16, 1);
        DECLARE
         @ReturnValue INT = -1;
        RETURN @ReturnValue;
        END;
    
    
    DELETE T
      FROM TCD.TunnelCompartmentEquipmentValveMapping T
      WHERE T.ControllerEquipmentSetupID = @EquipmentSetupId
    AND T.PlantID = @PlantId
    AND T.TunnelCompartmentEquipmentValveMappingID NOT IN(
    SELECT TCEVM.TunnelCompartmentEquipmentValveMappingID
      FROM TCD.TunnelCompartmentEquipmentValveMapping TCEVM
       INNER JOIN
       @lineCompartmentMappings M ON TCEVM.TunnelNumber = M.TunnelNumber
             AND TCEVM.DosingPointNumber = M.DosingPointNumber
             AND TCEVM.ControllerEquipmentSetupID = @EquipmentSetupId
             AND TCEVM.PlantID = @PlantId);
    END;
    DECLARE
     @TempMapping TABLE(
     RowNumber INT NOT NULL
   , ControllerEquipmentId TINYINT NOT NULL
   , TunnelNumber INT NOT NULL
   , CompartmentNumber TINYINT NOT NULL
   , DosingPointNumber TINYINT NOT NULL
   , DirectDosingFlag BIT NOT NULL
   , VlaveNumber TINYINT NOT NULL
   , WasherNumber int NOT NULL);

    /* Create RowNumber inorder to increment and use row by row. */

    WITH CTE_LCM
    AS (
    SELECT ROW_NUMBER() OVER (ORDER BY LCM.TunnelNumber, LCM.DosingPointNumber) AS RowNumber
     , *
  FROM @lineCompartmentMappings LCM
    )
    INSERT INTO @TempMapping
    SELECT *
  FROM CTE_LCM CL;

    /* Loop */

    DECLARE
     @j INT = 1,
     @max INT = (SELECT MAX(TM.RowNumber)
       FROM @TempMapping TM);
    WHILE @j <= @max
    BEGIN

    /* Declare and Initialize the current row data */

    DECLARE
     @TunnelNumber INT,
     @CompartmentNumber TINYINT,
     @DosingpointNumber TINYINT;
    SELECT TOP 1 @TunnelNumber = TM.TunnelNumber
       , @DosingPointNumber = TM.DosingpointNumber
       , @CompartmentNumber = TM.CompartmentNumber
      FROM @TempMapping TM
      WHERE TM.RowNumber = @j;
    DECLARE
     @ValveNumber INT = 0;
    IF @DDFlag = 'FALSE'
    BEGIN

    /* Get Min Available Valve Number */

    SELECT @ValveNumber = MIN(CEV.ControllerEquipmentValveID)
      FROM TCD.ControllerEquipmentValves CEV
      WHERE ControllerEquipmentValveID <> 0
        AND CEV.ControllerEquipmentValveID  NOT IN (
        SELECT TCEVM.ValveNumber
      FROM TCD.TunnelCompartmentEquipmentValveMapping TCEVM
       JOIN
       TCD.ControllerEquipmentSetup CES ON CES.ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupID
      WHERE CES.ControllerID = @ControllerId);
    END;

    /* Update If Exists else Insert */

    MERGE TCD.TunnelCompartmentEquipmentValveMapping T
    USING (SELECT TOP 1 *
     FROM @TempMapping TM
     WHERE TM.RowNumber = @j) S
    ON T.ControllerEquipmentSetupID = @EquipmentSetupId
   AND T.PlantID = @PlantId
   AND T.TunnelNumber = S.TunnelNumber
   AND T.DosingPointNumber = S.DosingPointNumber
   AND T.DirectDosingFlag = S.DirectDosingFlag
    WHEN MATCHED
      THEN
      UPDATE SET T.CompartmentNumber = S.CompartmentNumber
       , T.ValveNumber = CASE  @DDFlag
         WHEN 'TRUE' THEN 0
             ELSE T.ValveNumber
         END
       , T.WasherExtractorNumber = S.WasherNumber
       , T.LastModifiedByUserID = @UserId
    WHEN NOT MATCHED
      THEN
      INSERT (PlantID
        , ControllerEquipmentSetupID
        , TunnelNumber
        , DosingPointNumber
        , ValveNumber
        , CompartmentNumber
        , DirectDosingFlag
        , LastModifiedByUserID)
      VALUES (@PlantId,
      @EquipmentSetupId,
      S.TunnelNumber,
      S.DosingPointNumber,
      @ValveNumber,
      S.CompartmentNumber,
      S.DirectDosingFlag,
      @UserId);

    /* Increment the row */

    SET @j = @j + 1;
    END;
END;