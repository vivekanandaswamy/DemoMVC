﻿/*

Stored Procedure	:	[TCD].[SavePlantFormulaFromMyService]

Purpose				:	To Update Plant Formula from my services

Parameters			:	@EcolabAccountNumber
@Name
@MyServiceEcolabTextilecategory
@UserId
@Pieces
@Rewash
@Weight
@PlantProgramId
@ChainTextileId
@CustomerId
*/
CREATE PROCEDURE [TCD].[SavePlantFormulaFromMyService]
(
@EcolabAccountNumber					NVARCHAR(25)
,	@Name									NVARCHAR(200)
,	@MyServiceEcolabTextileCategory			INT
,	@UserId									INT
,	@Pieces									INT
,	@Rewash									BIT
,	@Weight									DECIMAL(18,3)
,	@PlantProgramId							INT
,	@ChainTextileId							INT
,	@CustomerId								INT
,	@OutputProgramId						INT							OUTPUT
,	@OutputLastModifiedTimestampAtLocal		DATETIME		=	NULL	OUTPUT

)
AS
BEGIN
SET NOCOUNT ON
DECLARE  @EcolabTextileId	 INT
,@ProgramId			 INT
,@SaturationId		 INT
,@ErrorId			INT
,@RegionCode		NVARCHAR(100)
,@RegionId			INT

DECLARE
@ReturnValue					INT				=			0
,	@ErrorMessage					NVARCHAR(4000)	=			N''
,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()

DECLARE
@OutputList						AS	TABLE		(
ProgramId						INT
,	LastModifiedTimestamp			DATETIME
)

SET		@OutputLastModifiedTimestampAtLocal				=			@CurrentUTCTime
--SET		@OutputFormulaId								=			ISNULL(@OutputFormulaId, NULL)			--SQLEnlight SA0121


SELECT @RegionCode = MyServiceRegionCode from TCD.RegionMaster where RegionId = (SELECT RegionId from TCD.Plant where EcolabAccountNumber  = @EcolabAccountNumber)

IF @RegionCode = 'EMEA'
	BEGIN
		SELECT @EcolabTextileId = ISNULL(TextileId,0) FROM TCD.EcolabTextileCategory WHERE MyServiceMstrLnnTypId = @MyServiceEcolabTextilecategory
		SET @SaturationId = NULL
	END
ELSE IF @RegionCode = 'NA'
	BEGIN
		SELECT @SaturationId = ISNULL(EcolabSaturationId,0) FROM TCD.EcolabSaturation WHERE MyServiceMstrLnnTypId = @MyServiceEcolabTextilecategory
		SET @EcolabTextileId = NULL
	END
SELECT @ProgramId = ISNULL(MAX(ProgramId), 0) + 1 from TCD.ProgramMaster WHERE EcolabAccountNumber = @EcolabAccountNumber
IF NOT EXISTS (SELECT 1 FROM TCD.ProgramMaster WHERE EcolabAccountNumber = @EcolabAccountNumber AND NAME = @Name)

BEGIN

INSERT INTO
[TCD].ProgramMaster
(
EcolabAccountNumber
,	ProgramId
,	Name
,	Pieces
,	EcolabTextileCategoryId
,	Rewash
,	[Weight]
,	EcolabSaturationId
,	PlantProgramId
,	ChainTextileId
,	CustomerId
,	Is_Deleted
,	LastModifiedByUserId
,	LastModifiedTime
)
OUTPUT
@ProgramId								AS			Id
,	inserted.LastModifiedTime				AS			LastModifiedTimestamp

INTO
@OutputList	(
ProgramId
,	LastModifiedTimestamp
)
VALUES
(
@EcolabAccountNumber
,	@ProgramId
,	@Name
,	@Pieces
,	@EcolabTextileId
,	@Rewash
,	@Weight
,	@SaturationId
,	@PlantProgramId
,	@ChainTextileId
,	@CustomerId
,	'false'
,	@UserId
,	@OutputLastModifiedTimestampAtLocal
)
SET @ErrorId = @@ERROR
--SELECT	@OutputFormulaId	=	SCOPE_IDENTITY()
END
--ELSE
--BEGIN
--	--UPDATE [TCD].ProgramMaster
--	--SET
--	--					  Name							=		@Name
--	--				,	  Pieces						=		@Pieces
--	--				,	  EcolabTextileCategoryId		=		@EcolabTextileId
--	--				,	  Rewash						=		@Rewash
--	--				,	  [Weight]						=		@Weight
--	--				,	  EcolabSaturationId			=		@SaturationId
--	--				,	  PlantProgramId				=		@PlantProgramId
--	--				,	  ChainTextileId				=		@ChainTextileId
--	--				,	  CustomerId					=		@CustomerId
--	--				,	  Is_Deleted					=		'FALSE'
--	--				,	  LastModifiedByUserId			=		@UserId
--	--				,	  LastModifiedTime				=		CURRENT_TIMESTAMP
--	--WHERE
--	--  EcolabAccountNumber = @EcolabAccountNumber
--	--AND
--	--  ProgramId = @ProgramId

--	SET @ErrorId = @@ERROR
--END
SELECT	TOP 1
@OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp
,	@OutputProgramId					=	O.ProgramId
FROM	@OutputList							O
SET NOCOUNT OFF
RETURN @ErrorId

END