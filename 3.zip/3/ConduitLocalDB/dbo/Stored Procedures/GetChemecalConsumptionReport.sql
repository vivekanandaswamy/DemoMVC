﻿--exec [TCD].[GetChemecalConsumptionReport] @Corporate=N'',@Country=N'',@Region=N'',@EcolabAccountNumber=N'',@Machine=N'',@machineGroup=N'',@Formula=N'',@MachineType=N'',
--@Category=N'',@FromDate='2014-01-01 00:00:00',@ToDate='2014-09-30 00:00:00',@GroupId=N'',@MachineInternalId=N'',@ProductId = 1,@Date = NULL,@IsdrillDown = 1,
--@DayWise=0,@WeekWise=0,@MonthWise=0,@QuarterWise=1,@YearWise=0,@SortColumnID = 242,@SortDirection = 'ASC',@UserId = 0,@ReportID = 5


CREATE PROCEDURE [TCD].[GetChemecalConsumptionReport] (
											 @Corporate VARCHAR(MAX) = '',
											 @Country VARCHAR(MAX) = '',
											 @Region VARCHAR(MAX) = '',
											 @EcolabAccountNumber NVARCHAR(25) = '',
											 @Machine VARCHAR(MAX) = '', 
											 @MachineGroup VARCHAR(MAX) = '',
											 @Formula VARCHAR(MAX) = '',
											 @MachineType VARCHAR(20)= '',
											 @Category VARCHAR(MAX) = '',
											 @FromDate DATE = '',
											 @ToDate DATE = '',
											 @GroupId VARCHAR(MAX) = '',
											 @MachineInternalId VARCHAR(MAX) = '',
											 @ProductId VARCHAR(100) = '',
											 @Date DATE = NULL,
											 @IsdrillDown BIT = 0,
											 @DayWise BIT = NULL,
											 @WeekWise BIT = NULL,
											 @MonthWise BIT = NULL,
											 @QuarterWise BIT = NULL,
											 @YearWise BIT = NULL,
											 --@Customer VARCHAR(max) = '',
											 @SortColumnID INT = NULL,
											 @SortDirection Varchar(100) = '',
											 @UserID INT = NULL,
											 @ReportID INT = NULL	
										   )
AS   
BEGIN   
SET NOCOUNT ON;   

DECLARE @ReportGenerated INT = 6

/* Inserting the record into Report History */

INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)
SELECT @EcolabAccountNumber,UM.UserId,
	  UM.LoginName,
	  GETUTCDATE(),
	  @ReportGenerated,
	  CASE WHEN @ReportGenerated = 6
		THEN 'Generated Report : ChemicalConsumptionReport' END
	  FROM TCD.UserMaster UM
	    WHERE	UM.EcolabAccountNumber =	@EcolabAccountNumber AND UM.UserId = @UserId

/* Completed the record insertion into Report History */


    IF(@ProductId IS NULL AND @IsDrillDown = 0)
	   BEGIN

	exec [TCD].[ChemecalConsumptionSwitchReport] @Corporate,@Country,@Region,@EcolabAccountNumber,@Machine,@machineGroup,@Formula,@MachineType,
									   @Category,@FromDate,@ToDate,@GroupId,@MachineInternalId,@Date,
									   @DayWise,@WeekWise,@MonthWise,@QuarterWise,@YearWise,@SortColumnID,@SortDirection,@UserId,@ReportID,@IsdrillDown
	   END

    IF(@ProductId IS NOT NULL AND @IsDrillDown = 1)
	   BEGIN
	   
	   EXEC [TCD].[GetChemicalConsumptionDrilDownReport] @Corporate,@Country,@Region,@EcolabAccountNumber,@Machine,@machineGroup,@Formula,@MachineType,
	   @Category,@FromDate,@ToDate,@GroupId,@MachineInternalId,@ProductId,
	   @DayWise,@WeekWise,@MonthWise,@QuarterWise,@YearWise,@Date,@SortColumnID ,@SortDirection,@UserId,@ReportID,@IsdrillDown
	   
	    END

SET NOCOUNT OFF;   
END