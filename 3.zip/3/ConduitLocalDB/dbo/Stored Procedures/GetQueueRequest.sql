﻿CREATE PROCEDURE [TCD].[GetQueueRequest]
	
AS
BEGIN
		SET	NOCOUNT	ON
		DECLARE

					@ReturnValue					INT				=			0
				,	@ErrorId						INT				=			0
				,	@ErrorMessage					NVARCHAR(4000)	=			N''
				BEGIN
						SELECT tmq.Id, tmq.RequestMessage, tmq.EntityType, tmq.MessageId, tmq.ActionType,  
							   tmq.EcolabAccountNumber, tmq.UserId, tmq.FailureCount 
					    FROM TCD.TcpMessageQueue tmq ORDER BY tmq.Id ASC
						--check for any error
						SET	@ErrorId	=	@@ERROR
						IF	(@ErrorId	<>	0)
							BEGIN
								SET		@ErrorMessage	=			N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred appending formula steps for the tunnel.'
								GOTO	ErrorHandler
							END
				END	

		IF	(	@ErrorId	=	0	)
			BEGIN
				GOTO	ExitModule
			END
		ErrorHandler:
		RAISERROR	(@ErrorMessage, 16, 1)
		SET	@ReturnValue	=	-1
		ExitModule:
		SET	NOCOUNT	OFF
		RETURN	(@ReturnValue)
END