﻿/*  
 ==========================================================================================  
 Purpose:  Fecthing the Get UOM for Utility 

 Author:  Santhosh

 --------------------------------------------------------------  
 Sep-01-2014 ENT: Initial version.  
 ==========================================================================================  
*/ 

CREATE Procedure [TCD].[GetUtilityDimensionalUnits] (
     @EcolabAccountNumber    NVARCHAR(25)
    )
AS 
SET NOCOUNT ON
Declare @price NVARCHAR(500)=NULL
Declare @ElectricTariff NVARCHAR(500)=NULL
Declare @gasOilPrice NVARCHAR(500)=NULL
Declare @Temperature NVARCHAR(500)=NULL
Declare @EnergyContent NVARCHAR(500)=NULL
DECLARE @CurrencySymbol nvarchar(10) ='$'
Declare @UOM INT=(select UOMId from [TCD].plant where EcolabAccountNumber=@EcolabAccountNumber) --Remove the EcolabAccountNumber from here and pass it as parameter
Declare @LanguageId INT=(select LanguageId from [TCD].plant where EcolabAccountNumber=@EcolabAccountNumber) --Remove the EcolabAccountNumber from here and pass it as parameter
  BEGIN 
 
 SELECT TOP(1) @CurrencySymbol = cs.CurrencySymbol  FROM TCD.CurrencySymbol cs WHERE cs.CurrencyCode = ( SELECT TOP(1) p.CurrencyCode FROM TCD.Plant p WHERE p.EcolabAccountNumber = @EcolabAccountNumber)

 IF ((SELECT TOP(1) p.CurrencyCode FROM TCD.Plant p WHERE p.EcolabAccountNumber = @EcolabAccountNumber) = 'EUR')
 BEGIN
	SET @CurrencySymbol = REPLACE(@CurrencySymbol, '?', '€')
 END

 Select @price=SubUnit from [TCD].GetDimensionalUnits('Price_tcd',@UOM)
 Select @ElectricTariff=SubUnit from [TCD].GetDimensionalUnits('Price_Electric_Tariff_Tcd',@UOM)
 Select @gasOilPrice=SubUnit from [TCD].GetDimensionalUnits('Price_GasOil_Tcd',@UOM)
 Select @Temperature=SubUnit from [TCD].GetDimensionalUnits('Temperature_CandF',@UOM)
 Select @EnergyContent=SubUnit from [TCD].GetDimensionalUnits('Energy_Content_TCD',@UOM)

 SELECT @price= ResourceKeyValue.Value FROM [TCD].ResourceKeyMaster INNER JOIN [TCD].ResourceKeyValue ON ResourceKeyMaster.KeyName = ResourceKeyValue.KeyName WHERE   ResourceKeyMaster.KeyName=@price and languageID=@LanguageId
 SELECT @ElectricTariff=ResourceKeyValue.Value FROM [TCD].ResourceKeyMaster INNER JOIN [TCD].ResourceKeyValue ON ResourceKeyMaster.KeyName = ResourceKeyValue.KeyName WHERE   ResourceKeyMaster.KeyName=@ElectricTariff and languageID=@LanguageId
 SELECT @gasOilPrice=ResourceKeyValue.Value FROM [TCD].ResourceKeyMaster INNER JOIN [TCD].ResourceKeyValue ON ResourceKeyMaster.KeyName = ResourceKeyValue.KeyName WHERE   ResourceKeyMaster.KeyName=@gasOilPrice and languageID=@LanguageId
 SELECT @Temperature=ResourceKeyValue.Value FROM [TCD].ResourceKeyMaster INNER JOIN [TCD].ResourceKeyValue ON ResourceKeyMaster.KeyName = ResourceKeyValue.KeyName WHERE   ResourceKeyMaster.KeyName=@Temperature and languageID=@LanguageId
 SELECT @EnergyContent=ResourceKeyValue.Value FROM [TCD].ResourceKeyMaster INNER JOIN [TCD].ResourceKeyValue ON ResourceKeyMaster.KeyName = ResourceKeyValue.KeyName WHERE   ResourceKeyMaster.KeyName=@EnergyContent and languageID=@LanguageId

 SELECT REPLACE(@price, '#currency#', @CurrencySymbol) AS Price 
    ,	REPLACE(@ElectricTariff, '#currency#', @CurrencySymbol) AS ElectricPrice
    ,	REPLACE(@gasOilPrice, '#currency#', @CurrencySymbol) AS GasPrice
    ,	@Temperature AS Temperature
    ,	@EnergyContent AS EnergyContent
 
  END
GO