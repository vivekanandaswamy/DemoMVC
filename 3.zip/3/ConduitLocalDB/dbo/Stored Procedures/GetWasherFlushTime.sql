CREATE PROCEDURE [TCD].[GetWasherFlushTime] (
     @WasherId INT
    , @EcolabAccountNumber NVARCHAR(25)
    , @ControllerModelId INT
    , @ControllerTypeId INT
    )
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE
        @plantId INT = (SELECT P.PlantId
                      FROM TCD.Plant P
                      WHERE P.EcolabAccountNumber = @EcolabAccountNumber);
DECLARE @WasherFlushTypeId TABLE (WasherFlushTypeId int NOT NULL)

IF @ControllerModelId = 7 
INSERT INTO @WasherFlushTypeId
(WasherFlushTypeId)
select 1 UNION ALL SELECT 2
ELSE
INSERT INTO @WasherFlushTypeId
(WasherFlushTypeId)
select 3 UNION ALL SELECT 4

DECLARE @WasherTypeId bit = (SELECT ms.IsTunnel FROM TCD.MachineSetup ms  WHERE ms.WasherId = @WasherId)
DECLARE @NoOfDosingLines int
IF(@WasherTypeId = 0)
BEGIN
SET @NoOfDosingLines = (SELECT cmctm.NumOfConvDosingLines FROM TCD.ControllerModelControllerTypeMapping cmctm WHERE cmctm.ControllerModelId = @ControllerModelId AND cmctm.ControllerTypeId = @ControllerTypeId)
END
ELSE
BEGIN
SET @NoOfDosingLines = (SELECT cmctm.NumOfTunnelDosingLines FROM TCD.ControllerModelControllerTypeMapping cmctm WHERE cmctm.ControllerModelId = @ControllerModelId AND cmctm.ControllerTypeId = @ControllerTypeId)
END

IF(@ControllerModelId = 7)
BEGIN
    IF EXISTS (SELECT 1 FROM TCD.WasherFlushTime wft WHERE wft.WasherId = @WasherId AND wft.PlantId = @plantId AND wft.WasherFlushTypeId IN (SELECT WasherFlushTypeId FROM @WasherFlushTypeId))
    BEGIN
        SELECT wft.WasherId,
               wft.LineNumber
             , wft.WasherFlushTypeId
             , wft.FlushTime 
             , wft.LastModifiedTime
             , wft.PlantId
			 , wft.Is_Deleted
        FROM TCD.WasherFlushTime wft 
        WHERE 
                wft.WasherId = @WasherId 
            AND wft.PlantId = @plantId 
            AND wft.WasherFlushTypeId IN (SELECT WasherFlushTypeId FROM @WasherFlushTypeId)
    END
    ELSE
    BEGIN
        SELECT   cmctm.MaxNumOfValvesForConventional
                 ,cmctm.MaxNumOfMEForConventional 
                ,@NoOfDosingLines AS WaterCount
                ,@NoOfDosingLines AS AirCount
        FROM TCD.ControllerModelControllerTypeMapping cmctm 
        WHERE cmctm.ControllerModelId = @ControllerModelId 
        AND  cmctm.ControllerTypeId = @ControllerTypeId
    END
END
ELSE
BEGIN
    IF EXISTS (SELECT 1 FROM TCD.WasherFlushTime wft WHERE wft.WasherId = @WasherId AND wft.PlantId = @plantId AND wft.WasherFlushTypeId IN (SELECT WasherFlushTypeId FROM @WasherFlushTypeId))
    BEGIN
        SELECT wft.WasherId,
               wft.LineNumber
             , wft.WasherFlushTypeId
             , wft.FlushTime 
             , wft.LastModifiedTime
             , wft.PlantId
			 , wft.Is_Deleted
        FROM TCD.WasherFlushTime wft 
        WHERE 
                wft.WasherId = @WasherId 
            AND wft.PlantId = @plantId 
            AND wft.WasherFlushTypeId IN (SELECT WasherFlushTypeId FROM @WasherFlushTypeId)
    END
    ELSE
        IF(@WasherTypeId = 0)
            BEGIN
                SELECT cmctm.MaxNumOfValvesForConventional
                      ,cmctm.MaxNumOfMEForConventional 
                      ,@NoOfDosingLines AS WaterCount
                      ,@NoOfDosingLines AS AirCount
                FROM TCD.ControllerModelControllerTypeMapping cmctm 
                WHERE cmctm.ControllerModelId = @ControllerModelId 
                AND  cmctm.ControllerTypeId = @ControllerTypeId
            END
        ELSE
            BEGIN
                SELECT cmctm.MaxNumOfValvesForTunnel
                      ,cmctm.MaxNumOfMEForConventional 
                      ,@NoOfDosingLines AS WaterCount
                      ,@NoOfDosingLines AS AirCount
                FROM TCD.ControllerModelControllerTypeMapping cmctm 
                WHERE cmctm.ControllerModelId = @ControllerModelId 
                AND  cmctm.ControllerTypeId = @ControllerTypeId
        END
END
    SET NOCOUNT OFF;
END;
