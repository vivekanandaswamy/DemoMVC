﻿CREATE PROCEDURE [TCD].[SaveDashboardDisplaySettings]
(
			@EcolabAccountNumber nvarchar(25)
)
AS   
BEGIN 

SET	NOCOUNT	ON														--SQLEnlight	SA0017


	Select (1000 * ISNULL(DashboardSlideDuration,30))   From TCD.Plant where EcolabAccountNumber = @EcolabAccountNumber

END