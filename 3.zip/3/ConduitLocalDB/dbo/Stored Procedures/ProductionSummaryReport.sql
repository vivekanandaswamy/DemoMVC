﻿--exec [TCD].[ProductionSummaryReport] @Corporate=N'',@Country=N'',@Region=N'',@EcolabAccountNumber=N'',@Machine=N'',@machineGroup=N''
--,@Formula=N'',@MachineType=N'',@Category=N'',@FromDate='2014/11/01 00:00:00',@ToDate='2014/11/30 00:00:00',@GroupId=N'',@MachineInternalId=N''
--,@DayWise=0,@WeekWise=0,@MonthWise=0,@QuarterWise=0,@PlantWise=1,@DrillDownGroupId=0,@SortColumnID = 0,@SortDirection = 'Desc',@UserId = 0


--exec [TCD].[ProductionSummaryReport] @Corporate=N'',@Country=N'',@Region=N'',@EcolabAccountNumber=N'',@Machine=N'',
--@machineGroup=N'',@Formula=N'',@MachineType=N'',@Category=N'',@FromDate='2015-01-11 00:00:00',
--@ToDate='2015-01-12 00:00:00',@GroupId=N'',@MachineInternalId=N'',@DayWise=0,@WeekWise=0,@MonthWise=1,
--@QuarterWise=0,@YearWise=0,@Date = NULL,@PlantWise=0,@DrillDownGroupId=0,@SortColumnID=0,@SortDirection=N'Asc',@UserId=0,@ReportID = 1






CREATE PROCEDURE [TCD].[ProductionSummaryReport] (
											 @Corporate Varchar(max) = '',
											 @Country Varchar(max) = '',
											 @Region Varchar(max) = '',
											 @EcolabAccountNumber Nvarchar(25) = '',
											 @Machine Varchar(max) = '', 
											 @machineGroup Varchar(max) = '',
											 @Formula Varchar(max) = '',
											 @MachineType Varchar(20)= '',
											 @Category Varchar(max) = '',

											 @FromDate Date = '',
											 @ToDate Date = '',

											 @GroupId Varchar(max) = '',
											 @MachineInternalId Varchar(max) = '',
											 @DayWise bit = NULL,
											 @WeekWise bit = NULL,
											 @MonthWise bit = NULL,
											 @QuarterWise bit = NULL,
											 @YearWise bit = NULL,
											 @Date DATE = NULL,
											 @PlantWise bit = NULL,
											 @DrillDownGroupId INT = NULL,
											 @SortColumnID INT = 0,
											 @SortDirection Varchar(100) = '',
											 @UserId INT = NULL,
											 @ReportID INT = NULL,
											 @NeedCurrent BIt = NULL

			 						   )
AS   
BEGIN   
SET NOCOUNT ON;   
DECLARE @ReportGenerated INT = 6

--SELECT @FromDate =  CAST(dateadd(minute, datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10),CAST(@FromDate AS date), 112) + ' ' + 
--CONVERT(Varchar(8), CAST(@FromDate AS time)) AS DateTime)) AS DATE)

/* Inserting the record into Report History */

INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)
SELECT @EcolabAccountNumber,UM.UserId,
	  UM.LoginName,
	  GETUTCDATE(),
	  @ReportGenerated,
	  CASE WHEN @ReportGenerated = 6
		THEN 'Generated Report : Production Summary Report' END
	  FROM TCD.UserMaster UM
	    WHERE	UM.EcolabAccountNumber =	@EcolabAccountNumber AND UM.UserId = @UserId

/* Completed the record insertion into Report History */



DECLARE @Month INT = MONTH(GETDATE()),
	   @SortField Varchar(100) = '',
	   @SummationInMin Int = NULL,
	   @SQLStatement varchar(max),
	   @IsDrillDown Bit = 0,
	   @WasherGroupNumber Int = 0,
	   @FormulaId varchar(100) = '',
	   @EcolabTextileId varchar(100) = '',
	   @TextileCareCustomerId varchar(100) = '',
	   @ChainFormulaId varchar(100) = ''

    SELECT @SortField =  CASE WHEN @SortColumnID = 120 THEN 'Loadperhour'
						WHEN @SortColumnID = 122 THEN 'MachineName'
						WHEN @SortColumnID = 133 THEN 'Numberofbatches'
						WHEN @SortColumnID = 181 THEN 'TargetLoad'
						WHEN @SortColumnID = 182 THEN 'TargetLoadperhour'
						WHEN @SortColumnID = 200 THEN 'TotalLoad'
						WHEN @SortColumnID = 242 THEN 'DateRange'
						WHEN @SortColumnID  =243 THEN 'WasherGroup'
						WHEN @SortColumnID = 0 THEN 'TotalLoad' END

						
DECLARE @CategoryTable TABLE(Category Varchar(100))
INSERT INTO @CategoryTable(Category) EXEC [TCD].[CharlistToTable] @Category,','

DECLARE @MachineTable TABLE(Machine Varchar(100))
INSERT INTO @MachineTable(Machine) EXEC [TCD].[CharlistToTable] @Machine,','

DECLARE @GroupMachineTable TABLE(GroupId INT,MachineInternalId INT)  
INSERT INTO @GroupMachineTable(GroupId,MachineInternalId) 
SELECT GroupId,MachineInternalId FROM TCD.MachineSetup MS 
									INNER JOIN TCD.Washer WS ON MS.WasherId = WS.WasherId WHERE WS.PlantWasherNumber IN (SELECT Machine FROM @MachineTable);

DECLARE @GroupTable TABLE(GroupId Varchar(100))
INSERT INTO @GroupTable(GroupId) EXEC [TCD].[CharlistToTable] @GroupId,','

DECLARE @MachineInternalTable TABLE(MachineInternalId Varchar(100))
INSERT INTO @MachineInternalTable(MachineInternalId) EXEC [TCD].[CharlistToTable] @MachineInternalId,','

DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))
INSERT INTO @WasherGroupTable(MachineGroup) EXEC [TCD].[CharlistToTable] @machineGroup,','

DECLARE @FormulaTable TABLE(Formula Varchar(100))
INSERT INTO @FormulaTable(Formula) EXEC [TCD].[CharlistToTable] @Formula,','

--DECLARE @CustomerTable TABLE(Customer Varchar(100))
--INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','

DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))
INSERT INTO @MachineTypeTable(MachineType) EXEC [TCD].[CharlistToTable] @MachineType,','

	   /* Including the Latest Batch Data */

	   		  IF((CAST(@ToDate AS DATE) = CAST(GETUTCDATE() AS date)) AND @DayWise <> 1)
			 -- IF(@NeedCurrent = 1 AND @DayWise <> 1)
				    BEGIN				    		     
					--DECLARE @NeedCurDate Datetime = GETUTCDATE()
					EXEC [TCD].[ProductionDataRollUp] @ToDate

				    END

			 /* Ending the Latest Batch Data Logic */


 DECLARE @ProductionSummaryTable TABLE(
 								    RecordDate date,
								    MachineId Int,
								    TotalLoad Decimal(10,2) ,
								    TargetLoad Decimal(10,2) ,
								    Numberofbatches INT,
								    Loadperhour Decimal(10,2),
								    TargetLoadperhour Decimal(10,2),
								    GroupId INT,
								    MachineInternalId INT,
								    ProgramNumber INT,
    								    TextileId INT,
								    TotalRunTime Decimal(18,2)
		  					    )

	   INSERT INTO @ProductionSummaryTable(
 								    RecordDate,
								    MachineId,
								    TotalLoad,
								    TargetLoad,
								    Numberofbatches ,
								    Loadperhour ,
								    TargetLoadperhour,
								    GroupId ,
								    MachineInternalId ,
								    ProgramNumber ,
    								    TextileId ,
								    TotalRunTime
		  					    )
	   SELECT 
    			 PRT.RecordDate,
			 prt.MachineId,
			 PRT.TotalActualLoad + CASE WHEN (SELECT COUNT(1) FROM TCD.ManualProduction MP WHERE PRT.RecordDate = CAST(MP.RecordedDate AS DATE)) > 0 THEN 
			 (SELECT SUM(MP.value) FROM TCD.ManualProduction MP WHERE PRT.RecordDate = CAST(MP.RecordedDate AS DATE)) ELSE 0 END,
			 PRT.TotalStandardLoad,
			 PRT.NoOfBatches + CASE WHEN (SELECT COUNT(1) FROM TCD.ManualProduction MP WHERE PRT.RecordDate = CAST(MP.RecordedDate AS DATE)) > 0 THEN 
			 (SELECT COUNT(1) FROM TCD.ManualProduction MP WHERE PRT.RecordDate = CAST(MP.RecordedDate AS DATE))
			  ELSE 0 END,
			 PRT.ActualLoadPerHour,
	   		 PRT.TargetLoadPerHour,
			 PRT.GroupId,
	   		 PRT.MachineInternalId,
			 PRT.ProgramNumber,
			 PRT.EcolabTextileId,
			 PRT.TotalRunTime
			 	 FROM TCD.ProductionRollUp PRT
						  LEFT OUTER JOIN TCD.ManualProduction MP ON PRT.RecordDate = CAST(MP.RecordedDate AS DATE)

	       WHERE 
				--CASE @Customer   
				-- WHEN '' THEN 'TRUE'         
	   			-- ELSE                                                      
	   			--  CASE WHEN PRT.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                      
				--END='TRUE' 
				--AND       
	    			CASE @Machine   
				 WHEN '' THEN 'TRUE'         
				 ELSE                                                      
				  CASE WHEN PRT.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
				END='TRUE' 

				AND       

				CASE @machineGroup   
				 WHEN '' THEN 'TRUE'         
				 ELSE                                                      
				  CASE WHEN PRT.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable) THEN 'TRUE' END                                                      
				END='TRUE' 

				AND    

				CASE @Formula   
				 WHEN '' THEN 'TRUE'         
				 ELSE                                                      
				  CASE WHEN PRT.ProgramNumber IN (SELECT Formula FROM @FormulaTable) THEN 'TRUE' END                                                      
				END='TRUE' 

				AND       

				CASE @MachineType   
				 WHEN '' THEN 'TRUE'         
				 ELSE                                                      
				  CASE WHEN PRT.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable)) THEN 'TRUE' END                                                      
				END='TRUE' 

				AND       
				CASE @FromDate                                                                                
				    WHEN '' THEN Case WHEN MONTH(PRT.RecordDate) = @Month Then  'true' END                                                                                
				    ELSE CASE WHEN PRT.RecordDate >= CAST(@FromDate AS DATE) and PRT.RecordDate<= CAST(@ToDate AS date) THEN 'true'END                                                        
				 END='true'

				 AND
				 CASE @Category   
				 WHEN '' THEN 'TRUE'         
				 ELSE                                                      
				  CASE WHEN PRT.EcolabTextileId IN (SELECT Category FROM @CategoryTable) THEN 'TRUE' END                                                      
				END='TRUE' 

				AND
				 CASE @GroupId 
				 WHEN '' THEN 'TRUE' 
				 ELSE        
				CASE WHEN (PRT.GroupId IN (@GroupId) AND 
				  PRT.MachineInternalId IN (@MachineInternalId)) THEN 'TRUE' END                                                   
				END='TRUE' 
				AND
				 CASE @MachineInternalId 
				 WHEN '' THEN 'TRUE' 
				 ELSE        
				CASE WHEN (PRT.GroupId IN (@GroupId) AND 
				  PRT.MachineInternalId IN (@MachineInternalId)) THEN 'TRUE' END                                                   
				END='TRUE' 

				/* Including the latest data from batch tables */
				/*
				IF((CAST(@FromDate AS DATE) = CAST(GETUTCDATE() AS date)) AND @DayWise <> 1)
				    BEGIN
				     
					 EXEC [TCD].[ProductionBatchLatestData] @Corporate,@Country,@Region,@EcolabAccountNumber,@Machine,@machineGroup,@Formula,
												     @MachineType,@Category,@FromDate,@ToDate,@GroupId,@MachineInternalId,@FromDate
				 INSERT INTO @ProductionSummaryTable
						   SELECT 
    								PRT.RecordDate,
								PRT.TotalActualLoad + CASE WHEN (SELECT COUNT(1) FROM TCD.ManualProduction MP WHERE PRT.RecordDate = CAST(MP.RecordedDate AS DATE)) > 0 THEN 
								(SELECT SUM(MP.value) FROM TCD.ManualProduction MP WHERE PRT.RecordDate = CAST(MP.RecordedDate AS DATE)) ELSE 0 END,
								PRT.TotalStandardLoad,
								PRT.NoOfBatches + CASE WHEN (SELECT COUNT(1) FROM TCD.ManualProduction MP WHERE PRT.RecordDate = CAST(MP.RecordedDate AS DATE)) > 0 THEN 
								(SELECT COUNT(1) FROM TCD.ManualProduction MP WHERE PRT.RecordDate = CAST(MP.RecordedDate AS DATE))
								 ELSE 0 END,
								PRT.ActualLoadPerHour,
	   							PRT.TargetLoadPerHour,
								PRT.GroupId,
	   							PRT.MachineInternalId,
								PRT.ProgramNumber,
								PRT.EcolabTextileId 
			 				  FROM #ProductionRollUpLatest PRT
									   LEFT OUTER JOIN TCD.ManualProduction MP ON PRT.RecordDate = CAST(MP.RecordedDate AS DATE)
				    DROP TABLE #ProductionRollUpLatest
				    
				 END
				 */
				    /* End of production latest batch data */

	   IF(@PlantWise = 0 AND @DrillDownGroupId = 0 )

	   BEGIN
	   
		  IF(@DayWise = 1)
			 BEGIN	
			 
			 SET @Date = CAST(@FromDate AS DATE)
			
			exec [TCD].[ProductionShiftReport] @Corporate,@Country,@Region,@EcolabAccountNumber,@Machine,
			 @machineGroup,@Formula,@MachineType,@Category,@FromDate,
			 @ToDate,@GroupId,@MachineInternalId,@Date,@PlantWise,@FormulaId,
			 @EcolabTextileId,@TextileCareCustomerId,@ChainFormulaId,@SortColumnID,@SortDirection,@ReportID,@IsDrillDown
			 
										
			 END
		
	    IF(@WeekWise = 1)

	    		  BEGIN

			  	SELECT 				
					   @WasherGroupNumber As WasherGroupNumber,
					   CAST(RecordDate AS nvarchar(100)) As DateRange,
					  SUM(TotalLoad) AS TotalLoad,
					  SUM(TargetLoad) AS TargetLoad,
					  SUM(Numberofbatches) AS Numberofbatches,
					  CAST((SUM(TotalLoad)/CASE WHEN SUM(TotalRunTime) = 0 THEN 1 ELSE SUM(TotalRunTime) END) AS decimal(18,2)) AS Loadperhour,
					  CAST((SUM(TargetLoad)/CASE WHEN SUM(TotalRunTime) = 0 THEN 1 ELSE SUM(TotalRunTime) END) AS decimal(18,2)) AS TargetLoadperhour,
					  --SUM(Loadperhour) AS Loadperhour,
					  --SUM(TargetLoadperhour ) AS TargetLoadperhour,
					  @PlantWise AS ViewByMode,@IsDrillDown as IsDrillDown,
					  SUM(TotalRunTime) AS TotalRunTime
					   INTO #ProdTableDayOrder

				FROM @ProductionSummaryTable

					   GROUP BY DATEPART(weekday,RecordDate),RecordDate

				SET @SQLStatement 
					   ='SELECT * FROM #ProdTableDayOrder ORDER BY ' + @SortField + ' ' + @SortDirection

	   			EXEC(@SQLStatement)
				DROP TABLE #ProdTableDayOrder
		  END  
		  
	  IF(@MonthWise = 1)

		  BEGIN 

		  DECLARE @FirstDay date = (SELECT TOP 1 RecordDate FROM @ProductionSummaryTable ORDER BY RecordDate)
		  DECLARE @LastDay date = (SELECT TOP 1 RecordDate FROM @ProductionSummaryTable ORDER BY RecordDate DESC)
		  DECLARE @FirstSunday date = NULL,
				@LastSaturday date = NULL

		  
		  SELECT 
				@FirstSunday = CAST(DateAdd(dd, (8-DatePart(WEEKDAY, 
							DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)))%7, 
							DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)) AS DATE) 

		   SELECT
				  @LastSaturday = 
								DATEADD(dd,
									   -DATEPART(WEEKDAY,
											   DATEADD(dd, -DAY(DATEADD(month, 1, @LastDay)),
													 DATEADD(month, 1, @LastDay))) ,
									   DATEADD(dd, -DAY(DATEADD(MONTH, 1, @LastDay)), DATEADD(MONTH, 1, @LastDay)));
				
				WITH CTE(DateRange,TotalLoad,TargetLoad,Numberofbatches,Loadperhour,TargetLoadperhour,TotalRunTime)
				AS
				(
				SELECT 
							CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,-1,@FirstSunday)) = 7 
							AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate < DATEADD(DD,-1,@FirstSunday)) = 0)
							THEN CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100))
							WHEN DATEADD(DD,-1,@FirstSunday) > CAST(GETDATE() AS DATE) 
							THEN
							CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @ToDate, 101) AS nvarchar(100))
							ELSE
							CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) END As DateRange,
							 SUM(TotalLoad) AS TotalLoad,
							 SUM(TargetLoad) AS TargetLoad ,
							 SUM(Numberofbatches) AS Numberofbatches,
							  CAST((SUM(TotalLoad)/CASE WHEN SUM(TotalRunTime) = 0 THEN 1 ELSE SUM(TotalRunTime) END) AS decimal(18,2)) AS Loadperhour,
							  CAST((SUM(TargetLoad)/CASE WHEN SUM(TotalRunTime) = 0 THEN 1 ELSE SUM(TotalRunTime) END) AS decimal(18,2)) AS TargetLoadperhour,
							  SUM(TotalRunTime) AS TotalRunTime
							 --SUM(Loadperhour) AS Loadperhour,
							 --SUM(TargetLoadperhour ) AS TargetLoadperhour
					   FROM @ProductionSummaryTable
					   WHERE RecordDate < @FirstSunday AND RecordDate >= @FirstDay

					   
					   UNION ALL

		
					   SELECT 
						  --CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100)) AS StartDate,
						  --CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) AS EndDate,
						    CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100))  + CHAR(13) + '-' +
						   CASE WHEN CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) >
						   CAST(Convert(varchar, DateAdd(dd, (1 - DatePart(dw, @Todate) + 1), @Todate), 101) AS nvarchar(100))
						   THEN  CAST(Convert(varchar, DateAdd(dd, 1-1, @Todate), 101) AS nvarchar(100))
						   ELSE CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) END
						   As DateRange,
						  SUM(TotalLoad) AS TotalLoad,
						  SUM(TargetLoad) AS TargetLoad ,
						  SUM(Numberofbatches) AS Numberofbatches,
						  CAST((SUM(TotalLoad)/CASE WHEN SUM(TotalRunTime) = 0 THEN 1 ELSE SUM(TotalRunTime) END) AS decimal(18,2)) AS Loadperhour,
						  CAST((SUM(TargetLoad)/CASE WHEN SUM(TotalRunTime) = 0 THEN 1 ELSE SUM(TotalRunTime) END) AS decimal(18,2)) AS TargetLoadperhour,
						  SUM(TotalRunTime) AS TotalRunTime
						  --SUM(Loadperhour) AS Loadperhour,
						  --SUM(TargetLoadperhour ) AS TargetLoadperhour
					   FROM @ProductionSummaryTable
				       WHERE RecordDate BETWEEN @FirstSunday AND @LastSaturday
					   GROUP BY Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101),
							  Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101)
					  
					  UNION ALL

					   SELECT 
							 CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,1,@LastSaturday)) = 1 
							 AND (SELECT COUNT(1) FROM @ProductionSummaryTable WHERE RecordDate > DATEADD(DD,1,@LastSaturday)) = 0)
							 THEN 
							 CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) 
							 ELSE
							CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @LastDay, 101) AS nvarchar(100)) END   As DateRange,
							 SUM(TotalLoad) AS TotalLoad,
							 SUM(TargetLoad) AS TargetLoad ,
							 SUM(Numberofbatches) AS Numberofbatches,
							 CAST((SUM(TotalLoad)/CASE WHEN SUM(TotalRunTime) = 0 THEN 1 ELSE SUM(TotalRunTime) END) AS decimal(18,2)) AS Loadperhour,
							 CAST((SUM(TargetLoad)/CASE WHEN SUM(TotalRunTime) = 0 THEN 1 ELSE SUM(TotalRunTime) END) AS decimal(18,2)) AS TargetLoadperhour,
							 SUM(TotalRunTime) AS TotalRunTime
							 --SUM(Loadperhour) AS Loadperhour,
							 --SUM(TargetLoadperhour ) AS TargetLoadperhour
					   FROM @ProductionSummaryTable
					   WHERE RecordDate > @LastSaturday AND RecordDate <= @LastDay
					   )
					   SELECT		
								@WasherGroupNumber As WasherGroupNumber,
								DateRange,
								TotalLoad,
								TargetLoad,
								Numberofbatches,
								Loadperhour,
								TargetLoadperhour,
								@PlantWise AS ViewByMode,
								@IsDrillDown as IsDrillDown,
								TotalRunTime
								INTO #ProdTableWeekOrder
							  FROM CTE 
								    WHERE TotalLoad IS NOT NULL
					   SET @SQLStatement 
								='SELECT * FROM #ProdTableWeekOrder ORDER BY ' + @SortField + ' ' + @SortDirection

	   				   EXEC(@SQLStatement)
					   DROP TABLE #ProdTableWeekOrder
		  END

		  
		  IF(@QuarterWise = 1)

			 BEGIN 

		  		 SELECT 
				 
					   @WasherGroupNumber As WasherGroupNumber,
					   DATENAME(MONTH, RecordDate) As DateRange ,
			   	        SUM(TotalLoad) TotalLoad,
		  			   SUM(TargetLoad) TargetLoad,
					   SUM(Numberofbatches) Numberofbatches,
					   CAST((SUM(TotalLoad)/CASE WHEN SUM(TotalRunTime) = 0 THEN 1 ELSE SUM(TotalRunTime) END) AS decimal(18,2)) AS Loadperhour,
					   CAST((SUM(TargetLoad)/CASE WHEN SUM(TotalRunTime) = 0 THEN 1 ELSE SUM(TotalRunTime) END) AS decimal(18,2)) AS TargetLoadperhour,
					   --SUM(Loadperhour) Loadperhour,
					   --SUM(TargetLoadperhour ) TargetLoadperhour,
					   @PlantWise AS ViewByMode,@IsDrillDown as IsDrillDown,
					   DATEPART(MONTH, RecordDate) AS SortDateRange,
					   SUM(TotalRunTime) AS TotalRunTime					   
					   INTO #ProdTableMonthOrder
				    FROM @ProductionSummaryTable
				    GROUP BY  DATEPART(MONTH, RecordDate),DATENAME(MONTH, RecordDate)
				    
				     SET @SQLStatement 
								='SELECT 
									   WasherGroupNumber,
									   DateRange,
									   TotalLoad,
									   TargetLoad,
									   Numberofbatches,
									   Loadperhour,
									   TargetLoadperhour,
									   ViewByMode,
									   IsDrillDown,TotalRunTime							
								 FROM #ProdTableMonthOrder ORDER BY ' + CASE @SortField WHEN 'DateRange' THEN 'SortDateRange' ELSE @SortField END + ' ' + @SortDirection

	   				   EXEC(@SQLStatement)
					   DROP TABLE #ProdTableMonthOrder
		  END
		  
		   IF(@YearWise = 1)

		  BEGIN 
				    DECLARE @Year VARCHAR(100) = RIGHT(YEAR(@FromDate),2)
				    
			SELECT 
			
				 @WasherGroupNumber As WasherGroupNumber,
				 CASE 'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10))
										 WHEN 'Q1' THEN 'Jan' + @Year + '- Mar' + @Year
										 WHEN 'Q2' THEN 'Apr' + @Year + '- Jun' + @Year
										 WHEN 'Q3' THEN 'Jul' + @Year + '-Sep' + @Year
										 WHEN 'Q4' THEN 'Oct' + @Year + '- Dec'+ @Year
				END 
				
				 as DateRange,

				SUM(TotalLoad) TotalLoad,

				SUM(TargetLoad) TargetLoad,

				SUM(Numberofbatches) Numberofbatches,

				CAST((SUM(TotalLoad)/CASE WHEN SUM(TotalRunTime) = 0 THEN 1 ELSE SUM(TotalRunTime) END) AS decimal(18,2)) AS Loadperhour,
				CAST((SUM(TargetLoad)/CASE WHEN SUM(TotalRunTime) = 0 THEN 1 ELSE SUM(TotalRunTime) END) AS decimal(18,2)) AS TargetLoadperhour,

				--SUM(Loadperhour) Loadperhour,

				--SUM(TargetLoadperhour ) TargetLoadperhour,
				
				 @PlantWise AS ViewByMode,@IsDrillDown as IsDrillDown,

				'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10)) as SortDateRange,
				SUM(TotalRunTime) AS TotalRunTime

				 INTO #ProdTableyearOrder

			 FROM @ProductionSummaryTable

			 GROUP BY DATEPART(QUARTER, RecordDate)

			  SET @SQLStatement 
								='SELECT WasherGroupNumber,
									    DateRange,
									    TotalLoad,
									    TargetLoad,
									    Numberofbatches,
									    Loadperhour,
									    TargetLoadperhour,
									    ViewByMode,
									    IsDrillDown,TotalRunTime
									     FROM #ProdTableyearOrder ORDER BY ' + CASE @SortField WHEN 'DateRange' THEN 'SortDateRange' ELSE @SortField END + ' ' + @SortDirection

	   				   EXEC(@SQLStatement)
					    DROP TABLE #ProdTableyearOrder

		  END			
		

	   END
		   IF(@PlantWise = 1)

		  		  BEGIN 

		  			SELECT 
						  WG.WasherGroupId WasherGroupNumber,
						  WG.WasherGroupName WasherGroup,
						  SUM(TotalLoad) TotalLoad,
						  SUM(TargetLoad) TargetLoad,
		  			    	SUM(Numberofbatches) Numberofbatches,						
						CAST((SUM(TotalLoad)/CASE WHEN SUM(TotalRunTime) = 0 THEN 1 ELSE SUM(TotalRunTime) END) AS decimal(18,2)) AS Loadperhour,
					    CAST((SUM(TargetLoad)/CASE WHEN SUM(TotalRunTime) = 0 THEN 1 ELSE SUM(TotalRunTime) END) AS decimal(18,2)) AS TargetLoadperhour,

						--SUM(Loadperhour) Loadperhour,

						--SUM(TargetLoadperhour ) TargetLoadperhour,
						
						@PlantWise AS ViewByMode,@IsDrillDown as IsDrillDown,
						SUM(TotalRunTime) AS TotalRunTime
						
						INTO #ProdTablePlantOrder

					FROM @ProductionSummaryTable PST

						    LEFT OUTER JOIN TCD.WasherGroup WG ON PST.GroupId = WG.WasherGroupId 

				     GROUP BY WG.WasherGroupName,WG.WasherGroupId

				     SET @SQLStatement 
								='SELECT * FROM #ProdTablePlantOrder ORDER BY ' + @SortField + ' ' + @SortDirection

	   				   EXEC(@SQLStatement)
					    DROP TABLE #ProdTablePlantOrder
			 	  END

				  

		  IF(@DrillDownGroupId <> 0)
		  BEGIN 
			 SELECT @IsDrillDown = 1
			SELECT 
			
				@WasherGroupNumber As WasherGroupNumber,
				MS.MachineName MachineName,

				SUM(TotalLoad) TotalLoad,
				SUM(TargetLoad) TargetLoad,
				SUM(Numberofbatches) Numberofbatches,				
				CAST((SUM(TotalLoad)/CASE WHEN SUM(TotalRunTime) = 0 THEN 1 ELSE SUM(TotalRunTime) END) AS decimal(18,2)) AS Loadperhour,
			     CAST((SUM(TargetLoad)/CASE WHEN SUM(TotalRunTime) = 0 THEN 1 ELSE SUM(TotalRunTime) END) AS decimal(18,2)) AS TargetLoadperhour,

				--SUM(Loadperhour) Loadperhour,

				--SUM(TargetLoadperhour ) TargetLoadperhour,
				
				@PlantWise AS ViewByMode,@IsDrillDown as IsDrillDown,
				SUM(TotalRunTime) AS TotalRunTime
				INTO #ProdTableDrillOrder

			 FROM @ProductionSummaryTable PST

				    LEFT OUTER JOIN TCD.MachineSetup MS ON PST.MachineId = MS.WasherId

				    WHERE PST.GroupId = @DrillDownGroupId

			 GROUP BY MS.MachineName

			 SET @SQLStatement 
						    ='SELECT * FROM #ProdTableDrillOrder ORDER BY ' + @SortField + ' ' + @SortDirection

	   				   EXEC(@SQLStatement)
					    DROP TABLE #ProdTableDrillOrder

		  END

		  

 END