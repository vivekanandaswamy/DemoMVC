﻿CREATE PROCEDURE [TCD].[GetWasherGroupFormulaResync]
					@EcoLabAccountNumber					NVARCHAR(25)
				,	@WasherGroupId							INT
				,	@ProgramSetupId							INT				=	NULL			--Null for LIST
AS
BEGIN

SET	NOCOUNT	ON

DECLARE
		@WasherGroupNumber						VARCHAR(10)	=	NULL
	,	@WasherGroupName						NVARCHAR(50)	=	NULL
	--,	@WasherGroupTypeId						TINYINT	=	NULL
	,	@WasherGroupTypeName					VARCHAR(30)	=	NULL
	,	@NextAvailableStepNo					INT	=	NULL
	,	@NextAvailableFormulaNo					INT	=    NULL
	,	@MyServiceMchGrpGuid					UNIQUEIDENTIFIER = NULL
	,	@MaxInjectionsCount						INT = 0
	,	@CanAddInjections						BIT = 0

SELECT	/*@WasherGroupTypeId			=			WGT.WasherGroupTypeId							--SQLEnlight SA0004
	,	*/@WasherGroupTypeName		=			WGT.WasherGroupTypeName
	,	@WasherGroupNumber			=			WG.WasherGroupNumber
	,	@WasherGroupName			=			WG.WasherGroupName
FROM	[TCD].WasherGroup					WG
JOIN	[TCD].WasherGroupType				WGT
	ON	WG.WasherGroupTypeId		=			WGT.WasherGroupTypeId
JOIN	[TCD].MachineGroup					GT
	ON	WG.WasherGroupId			=			GT.Id
WHERE	GT.EcolabAccountNumber		=			@EcoLabAccountNumber
	AND	WG.WasherGroupId			=			@WasherGroupId


IF	(	@WasherGroupTypeName	=	'Tunnel'	)
	BEGIN
			SELECT @NextAvailableFormulaNo = ISNULL(MAX(ProgramNumber), 0) + 1 FROM [TCD].TunnelProgramSetup 
			WHERE 
			WasherGroupId=@WasherGroupId 

			SELECT
					@WasherGroupNumber					AS			WasherGroupNumber
				,	@WasherGroupName					AS			WasherGroupName
				,	@WasherGroupTypeName				AS			WasherGroupTypeName
				,	TPS.TunnelProgramSetupId			AS			ProgramSetupId
				,	TPS.ProgramNumber					AS			ProgramNumber
				,	TPS.ProgramId						AS			ProductId
				,	PM.Name								AS			ProductName
				,	TPS.NominalLoad						AS			NominalLoad
				,	SUM(TDS.StepRunTime)				AS			TotalRunTime
				,	TPS.ExtraTime						AS			ExtraTime
				,	TPS.LoadsPerMonth					AS			LoadsPerMonth
				,	0									AS			NextAvailableStepNo
				,	TPS.LastModifiedTime				AS			LastModifiedTime
				,	TPS.LastSyncTime					AS			LastSyncTime
				,   TPS.EcolabAccountNumber				AS			EcolabAccountNumber 
				,	TPS.WasherGroupId					AS			WasherGroupId
				,	@NextAvailableFormulaNo				AS			NextAvailableFormulaNo
				,	TPS.MyServiceCustFrmulaMchGrpGUID	AS			MyServiceCustFrmulaMchGrpGUID
				,	TPS.Is_Deleted						AS			Is_Deleted
				,	ETC.MyServiceMstrLnnTypId			AS			MyServiceMstrLnnTypId
				,	@MyServiceMchGrpGuid				AS			MyServiceMchGrpGuid
				,	@MaxInjectionsCount					AS			MaxInjectionsCount
				,	@CanAddInjections					AS			CanAddInjections
				,	TPS.MyServiceLastSynchTime			AS			MyServiceLastSynchTime
			FROM	[TCD].TunnelProgramSetup			TPS
			JOIN	[TCD].ProgramMaster				PM
				ON	TPS.ProgramId					=			PM.ProgramId
			LEFT JOIN TCD.EcolabTextileCategory		ETC
				ON	PM.EcolabTextileCategoryId			=			ETC.TextileId
			LEFT JOIN [TCD].TunnelDosingSetup TDS ON TDS.TunnelProgramSetupId = TPS.TunnelProgramSetupId
			--AND TDS.Is_Deleted				=			'FALSE'
			WHERE	TPS.EcolabAccountNumber			=			@EcoLabAccountNumber
				AND	TPS.WasherGroupId				=			@WasherGroupId
				AND	TPS.TunnelProgramSetupId		=			ISNULL(@ProgramSetupId, TPS.TunnelProgramSetupId)
				--AND	TPS.Is_Deleted					=			'FALSE'

			GROUP BY 
				TPS.TunnelProgramSetupId
				,TPS.ProgramNumber
				,TPS.ProgramId
				,PM.Name
				,TPS.NominalLoad
				,TPS.ExtraTime
				,TPS.LoadsPerMonth
				,TPS.LastModifiedTime
				,TPS.LastSyncTime
				,TPS.EcolabAccountNumber
				,TPS.WasherGroupId
				,TPS.MyServiceCustFrmulaMchGrpGUID
				,TPS.Is_Deleted
				,ETC.MyServiceMstrLnnTypId
				,TPS.MyServiceLastSynchTime

	END
ELSE	--Conventional/Washer
	BEGIN
				
			SELECT @MaxInjectionsCount = MIN(csd.[Value]) FROM TCD.ControllerSetupData csd WHERE csd.FieldId IN (SELECT DISTINCT Id FROM TCD.Field f WHERE f.Label LIKE '%max formula%') 
												AND csd.ControllerId in (SELECT DISTINCT ms.ControllerId FROM TCD.WasherGroup wg 
																			INNER JOIN tcd.MachineSetup ms ON ms.GroupId=wg.WasherGroupId
																			INNER JOIN tcd.Washer w ON w.WasherId = ms.WasherId 
																			WHERE wg.WasherGroupId	=	@WasherGroupId)
			DECLARE @MaxInjectionsNumber INT = 0
			SELECT  @MaxInjectionsNumber =  ISNULL(MAX(wdpm.InjectionNumber),0) FROM TCD.WasherDosingProductMapping wdpm 
							INNER JOIN TCD.WasherDosingSetup wds ON wds.WasherDosingSetupId = wdpm.WasherDosingSetupId
							WHERE wds.WasherProgramSetupId = @ProgramSetupId
								AND wds.Is_Deleted = 0

			IF @MaxInjectionsCount > @MaxInjectionsNumber
			BEGIN
				SET @CanAddInjections	=	1
			END

			SELECT @NextAvailableStepNo = ISNULL(MAX(StepNumber), 0) + 1 FROM [TCD].WasherDosingSetup WDS
			WHERE 
			WDS.EcolabAccountNumber	= @EcoLabAccountNumber
			AND
			WDS.WasherProgramSetupId = @ProgramSetupId

			SELECT @NextAvailableFormulaNo = ISNULL(MAX(ProgramNumber), 0) + 1 FROM [TCD].WasherProgramSetup 
			WHERE 
			WasherGroupId=@WasherGroupId 
			
			SELECT
					@WasherGroupNumber					AS			WasherGroupNumber
				,	@WasherGroupName					AS			WasherGroupName
				,	@WasherGroupTypeName				AS			WasherGroupTypeName
				,	WPS.WasherProgramSetupId			AS			ProgramSetupId
				,	WPS.ProgramNumber					AS			ProgramNumber
				,	WPS.ProgramId						AS			ProductId
				,	PM.Name								AS			ProductName
				,	WPS.NominalLoad						AS			NominalLoad
				,	SUM(WDS.StepRunTime)				AS			TotalRunTime
				,	WPS.ExtraTime						AS			ExtraTime
				,	WPS.LoadsPerMonth					AS			LoadsPerMonth
				,	@NextAvailableStepNo				AS			NextAvailableStepNo
				,	WPS.LastModifiedTime				AS			LastModifiedTime
				,	WPS.LastSyncTime					AS			LastSyncTime
				,   WPS.EcolabAccountNumber				AS			EcolabAccountNumber 
				,	WPS.WasherGroupId					AS			WasherGroupId
				,	@NextAvailableFormulaNo				AS			NextAvailableFormulaNo
				,	WPS.MyServiceCustFrmulaMchGrpGUID	AS			MyServiceCustFrmulaMchGrpGUID
				,	WPS.Is_Deleted						AS			Is_Deleted
				,	ETC.MyServiceMstrLnnTypId			AS			MyServiceMstrLnnTypId
				,	@MyServiceMchGrpGuid				AS			MyServiceMchGrpGuid
				,	@MaxInjectionsCount					AS			MaxInjectionsCount
				,	@CanAddInjections					AS			CanAddInjections
				,	WPS.MyServiceLastSynchTime			AS			MyServiceLastSynchTime
			FROM	[TCD].WasherProgramSetup			WPS
			JOIN	[TCD].ProgramMaster				PM			ON	WPS.ProgramId					=			PM.ProgramId
				LEFT JOIN TCD.EcolabTextileCategory		ETC
				ON	PM.EcolabTextileCategoryId			=			ETC.TextileId
			LEFT JOIN [TCD].WasherDosingSetup WDS ON WDS.WasherProgramSetupId = WPS.WasherProgramSetupId
			--AND			WDS.Is_Deleted				=			'FALSE'
			WHERE	
			WPS.EcolabAccountNumber			=			@EcoLabAccountNumber
			AND	
			WPS.WasherGroupId				=			@WasherGroupId
			AND	
			WPS.WasherProgramSetupId		=			ISNULL(@ProgramSetupId, WPS.WasherProgramSetupId)
			--AND	
			--WPS.Is_Deleted					=			'FALSE'
			
			GROUP BY 
				WPS.WasherProgramSetupId
				,WPS.ProgramNumber
				,WPS.ProgramId
				,PM.Name
				,WPS.NominalLoad
				,WPS.ExtraTime
				,WPS.LoadsPerMonth
				,WPS.LastModifiedTime
				,WPS.LastSyncTime
				,WPS.EcolabAccountNumber
				,WPS.WasherGroupId
				,WPS.MyServiceCustFrmulaMchGrpGUID
				,WPS.Is_Deleted
				,ETC.MyServiceMstrLnnTypId
				,WPS.MyServiceLastSynchTime
	END

SET	NOCOUNT	OFF

END
