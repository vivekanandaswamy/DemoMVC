CREATE  PROCEDURE [TCD].[GetWasherGroupFromulaInjectionDetails]

            (

            @EcolabAccountNumber nvarchar(25) = NULL,

            @WasherGroupId INT = NULL,

            @WasherProgramSetupId INT = NULL

            )

AS

SET NOCOUNT ON

BEGIN

   

 SELECT  

 DISTINCT

  WDS.WasherDosingSetupId

  ,CAST(WPS.ProgramNumber AS INT) AS ProgramId

  ,WG.WasherGroupNumber

  ,WDP.InjectionNumber

  ,CES.ControllerEquipmentId

  ,WDP.ProductId

  -- ,PM.Name

  ,WDP.Quantity

  ,IJ.ReferenceLoad

  --,WDS.StepNumber

  --,WS.[StepId] AS WashOperationId

  --,WS.[StepName] AS WashOperation   

  ,IJ.InjectionClass

  ,IJ.ControllerId

  ,CT.Id AS ControllerType

  ,WPS.NominalLoad

 FROM [TCD].[WasherProgramSetup] WPS



  INNER JOIN  [TCD].[WasherDosingSetup] WDS ON WPS.[WasherProgramSetupId] = WDS.[WasherProgramSetupId] AND WDS.Is_Deleted=0 

  INNER JOIN TCD.WasherDosingProductMapping WDP ON WDS.WasherDosingSetupId = WDP.WasherDosingSetupId AND WDP.IsDeleted = 0

  INNER JOIN TCD.WasherGroup WG ON WG.WasherGroupId = WPS.WasherGroupId

  INNER JOIN TCD.Injection IJ ON WG.WasherGroupNumber = IJ.WasherGroupNumber AND IJ.Is_Deleted=0

  INNER JOIN TCD.ConduitController CC ON IJ.ControllerId = CC.ControllerId AND cc.Active = 1 AND cc.IsDeleted =0

  INNER JOIN TCD.ControllerType CT ON CC.ControllerTypeId = CT.Id

  INNER JOIN TCD.ProductMaster PM ON WDP.ProductId = PM.ProductId

  INNER JOIN TCD.ControllerEquipmentSetup CES ON CES.ProductId = PM.ProductId AND CES.ControllerId = CC.ControllerId

  --LEFT JOIN [TCD].WashStep WS  ON WS.StepId     =   WDS.StepTypeId

 WHERE  

  WG.WasherGroupId=@WasherGroupId

  AND WPS.WasherProgramSetupId = @WasherProgramSetupId  

  AND WPS.EcolabAccountNumber = @EcolabAccountNumber AND  IJ.ReferenceLoad IS NOT NULL
     

 END