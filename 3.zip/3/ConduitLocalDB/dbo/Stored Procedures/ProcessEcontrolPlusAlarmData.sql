﻿CREATE  Procedure [TCD].[ProcessEcontrolPlusAlarmData]
 (
 @ControllerID int, 
 @VxML xML
 )
AS
BEGIN
  DECLARE 
   @StartDateTime   DATETIME2,
   @StopDateTime   DATETIME2,
   @AlarmNumber   INT,
   @MachineNumber   INT,
   @BatchNumber   INT,
   @DesiredValue   INT,
   @MeasuredValue   INT,
   @Status     INT,
   @ProgramNumber   INT,
   @GroupId    INT,
   @MachineId    INT,
   @BatchID    INT,
   @ECOLABAccountNumber NVARCHAR(25),
   @CurrentDay    DATE=CAST(GETUTCDATE() as date),
   @IsActive    INT,
   @IsTunnel    INT,
   @AlarmGroupMasterId  INT,
   @PumpNbr int,
   @ValveNbr int,
   @CFErrorCode int,
   @CFErrorDetail int,
   @Probe int,
   @ID int,
   @RowID  int,
   @TotalRows int,
   @AlarmType int

   
 CREATE TABLE #AlarmList(RowID int IDentity(1,1),
      AlarmNumber int,
      StartDateTime DateTime,
      MachineNumber int,
      MachineID int,
      BatchNumber int,
      ProgramNumber int,
      DesiredValue int,
      MeasuredValue int,
      [Status] int,
      StopDateTime  DateTime,
      IsTunnel int,
      PumpNbr int,
      ValveNbr int,
      CFErrorCode int,
      CFErrorDetail int,
      [Probe] int,
	  [AlarmType] int
      )


 INSERT INTO #AlarmList (AlarmNumber,
       StartDateTime,
       MachineNumber,
       BatchNumber,
       ProgramNumber,
       DesiredValue,
       MeasuredValue,
       [Status],
       StopDateTime,
       IsTunnel,
       PumpNbr,
       ValveNbr,
       CFErrorCode,
       CFErrorDetail,
       [Probe],
	   AlarmType
	   )
  SELECT T.c.value('@AlarmNumber', 'INT'),
   T.c.value('@StartDateTime', 'DATETIME'),
   T.c.value('@MachineNumber', 'INT'),
   T.c.value('@BatchNumber', 'INT'),
   T.c.value('@ProgramNumber', 'INT'),
   T.c.value('@DesiredValue', 'INT'),
   T.c.value('@MeasuredValue', 'INT'),
   T.c.value('@Status', 'INT'),
   T.c.value('@StopDateTime', 'DateTime'),
   T.c.value('@IsTunnel', 'INT'),
   T.c.value('@PumpNbr', 'INT'),
   T.c.value('@ValveNbr', 'INT'),
   T.c.value('@CFErrorCode', 'INT'),
   T.c.value('@CFErrorDetail', 'INT'),
   T.c.value('@Probe', 'INT'),
   T.c.value('@AlarmType','INT')
 FROM @VxML.nodes('ArrayOfMyControlAlarmData/MyControlAlarmData') T(C)
 SELECT @TotalRows=Count(*) 
 FROM #AlarmList
 SELECT @RowID = 0
 SELECT @ECOLABAccountNumber = EcoalabAccountNumber 
 FROM TCd.ConduitController
 WHERE ControllerID = @ControllerId

 
 WHILE (@RowID<@TotalRows)
 BEGIN
     SELECT @RowID  = @RowID + 1
     SELECT 
     @AlarmNumber=AlarmNumber,
     @StartDateTime=StartDateTime,
     @MachineNumber=MachineNumber,
     @BatchNumber=BatchNumber,
     @ProgramNumber=ProgramNumber,
     @DesiredValue=DesiredValue,
     @MeasuredValue=MeasuredValue,
     @Status=[Status],
     @StopDateTime=StopDateTime,
     @IsTunnel=isTunnel,
     @PumpNbr=PumpNbr,
     @ValveNbr=ValveNbr,
     @CFErrorCode=CFErrorCode,
     @CFErrorDetail=CFErrorDetail,
     @Probe=[Probe],
	 @AlarmType=[AlarmType]
   FROM  #AlarmList 
   WHERE rowID = @RowID
   SELECT @GroupID =null,
       @MachineID=null,
       @BatchID=null
   IF (@MachineNumber  is not Null)
   BEGIN
    SELECT @GroupId = GroupId, 
       @MachineId = WasherId,
       @AlarmGroupMasterId=null
    FROM TCD.MachineSetup 
    WHERE ControllerId = @ControllerId 
      and IsTunnel = @IsTunnel
	  and MachineInternalId= @MachineNumber

    SELECT @BatchID = BatchId 
    FROM TCD.BatchData
    WHERE MachineId = @MachineId 
       and ControllerBatchId = @BatchNumber 
       and CAST(StartDate as date)= @CurrentDay
    UPDATE #AlarmList
    SET MachineID=@MachineId
    WHERE RowID = @RowID
   END
   SELECT TOP 1 @AlarmGroupMasterId = AGM.AlarmGroupMasterId 
   FROM TCD.ConduitController CC 
    INNER JOIN TCD.ControllerModelControllerTypeMapping CMCTM ON CMCTM.ControllerModelId = CC.ControllerModelId 
                     AND CMCTM.ControllerTypeId = CC.ControllerTypeId
    INNER JOIN TCD.AlarmGroupMsterVsControllerModelType AGMVCMT ON CMCTM.Id = AGMVCMT.ControllerModelTypeId
    INNER JOIN TCD.AlarmGroupMaster AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
   WHERE AGMVCMT.AlarmCode = @AlarmNumber AND CC.ControllerId = @ControllerId
   SELECT @ID =null
   SELECT @ID = ID 
   FROM TCD.AlarmData
   WHERE AlarmCode=@AlarmNumber
      and ControllerID = @ControllerID
      and( 
		  (@AlarmType = 4  and isNull(@MachineNumber,0) =isNull(MachineInternalId,0) and isNull(@Probe,0) =isNull(ProbeNumber,0) )
		  OR
		  (@AlarmType = 2  and isNull(@MachineNumber,0) =isNull(MachineInternalId,0))
	         OR
	       (@AlarmType = 3   and ISNULL(PumpNbr,0)= isNull(@PumpNbr,0))
		   OR 
		   (@AlarmType = 1)

		)
      and EndDate is Null

    SELECT @StopDateTime=Null
  
 IF (@ID is null)
  BEGIN
    Print '**Probe : ' + convert(nvarchar(10), @Probe)
      INSERT INTO [TCD].[AlarmData] 
    (EcoalabAccountNumber,
    AlarmCode,
    BatchId,
    controllerID,
    StartDate,
	PartitionOn,
    MachineInternalId,
    ProgramId,
    DesiredQuatity,
    MeasuredQuantity,
    TempStatus,
    GroupId,
    MachineId,
    BatchNumber,
    EndDate,
    IsActive,
    AlarmGroupMasterId,
    Valve,
    PumpNbr,
    CFErrorCode,
    CFErrorDetail,
    ProbeNumber
    )
    SELECT
     @ECOLABAccountNumber,
     @AlarmNumber,
     @BatchID,
     @ControllerId,
     @StartDateTime,
	 @StartDateTime,
     @MachineNumber,
     @ProgramNumber,
     @DesiredValue,
     @MeasuredValue,
     @Status,
     @GroupId,
     @MachineId,
     @BatchNumber,
     @StopDateTime,
     1,
     @AlarmGroupMasterId,
     @ValveNbr,
     @PumpNbr,
     @CFErrorCode,
     @CFErrorDetail,
     @Probe
    END
 END  

 UPDATE a
 SET EndDate = GETUTCDATE(), 
    IsActive = 0
 FROM tcd.AlarmData a
 WHERE controllerID = @ControllerId 
		AND EndDate is null
		AND NOT Exists(SELECT 1 FROM #AlarmList tmp
                       WHERE a.AlarmCode = tmp.AlarmNumber 
						     and
						 (
						  (tmp.AlarmType = 4  and isNull(MachineNumber,0) =isNull(MachineInternalId,0) 
							 and isNull(Probe,0) =isNull(ProbeNumber,0) 
						   )
							OR
							(tmp.AlarmType = 2  and isNull(MachineNumber,0) =isNull(MachineInternalId,0))
							OR 
							(tmp.AlarmType = 3   and ISNULL(PumpNbr,0)= isNull(a.PumpNbr,0))
							OR
							tmp.AlarmType = 1
						 )
						 )
	        
	

END