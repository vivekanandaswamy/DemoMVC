﻿/*

Stored Procedure	:	TCD.GetUserLogReportData

Purpose				:	To fetch data for UserLog report
Parameters			:	@EcolabAccountNumber					--	EcoLab Plant Id
						@FromDate								--	Start date from which the log is to be retrieved
						@ToDate									--	End date from which the log is to be retrieved
						@UserIDListCSV							--	Comma separated list of UserId as a filter

exec [TCD].[GetUserLogReportData] @EcolabAccountNumber=N'1',@FromDate='2015-01-01 00:00:00',@ToDate='2015-02-19 14:47:59.020',@UserIdListCSV=NULL,
							 @SortColumnID = 0,@SortDirection = 'Desc',@UserId = 3,@ActionTypeListCSV = '1',@PageNo = 1,@RecordsPerPage = 100
							
*/

CREATE PROCEDURE	[TCD].[GetUserLogReportData]	(
					@EcolabAccountNumber					NVARCHAR(25)
				,	@FromDate								DATETIME
				,	@ToDate									DATETIME
				,	@UserIdListCSV							VARCHAR(50)			=			NULL
				,    @SortColumnID							INT				     =		     NULL
				,	@SortDirection							  Varchar(100)           =			  'desc'
	   			,    @UserId								INT				     =			NULL
				,    @ActionTypeListCSV						VARCHAR(50)			=			''
				,    @PageNo								INT					 =			NULL,
					@RecordsPerPage						INT					  =			NULL

)	
AS
BEGIN
-- SET @FromDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@FromDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@FromDate AS time)) AS DateTime))
-- SET @ToDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@ToDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@ToDate AS time)) AS DateTime))



SET	NOCOUNT	ON
DECLARE @ReportGenerated INT = 6
DECLARE @ManualEntry INT = 7
DECLARE @LanguageId INT

SELECT @LanguageId = ISNULL(UM.LanguageId,(SELECT TOP 1 P.LanguageId FROM TCD.Plant P)) FROM TCD.UserMaster UM WHERE UM.UserId = @UserId


/* Inserting the record into Report History */

INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)
SELECT @EcolabAccountNumber,UM.UserId,
	  UM.FullName,
	  GETUTCDATE(),
	  @ReportGenerated,
	  CASE WHEN @ReportGenerated = 6
		THEN 'Generated Report :UserLogReport' END
	  FROM TCD.UserMaster UM
	    WHERE	UM.EcolabAccountNumber =	@EcolabAccountNumber AND UM.UserId = @UserId

/* Completed the record insertion into Report History */


DECLARE		@FromDateAndTime DATETIME
		,	@ToDateAndTime					DATETIME
		,	@SortField Varchar(100) = ''
		,    @SQLStatement varchar(max)

 SELECT @SortField =  CASE WHEN @SortColumnID = 1 THEN 'ActionDescription'
						WHEN @SortColumnID = 239 THEN 'DateAndTime'
						WHEN @SortColumnID = 240 THEN 'UserName'
						WHEN @SortColumnID = 241 THEN 'ActionType'
						WHEN @SortColumnID = 0 THEN 'DateAndTime' END

--table to store UserIds passed as CSList
CREATE	TABLE	#UserIdList	(
				UserId			INT			NOT	NULL
				)
--table to store UserIds passed as CSList
CREATE	TABLE	#ActionTypeList	(
				ActionType			INT			NOT	NULL
				)

SET			@FromDateAndTime				=			@FromDate
--Adjust ToDate...
SET			@ToDateAndTime					=			DATEADD(d, 1, @ToDate)


IF	@UserIdListCSV	IS NOT	NULL
	BEGIN
			INSERT	#UserIdList	(
					UserId	)
			SELECT	DISTINCT
					CAST(items AS INT)
			FROM	[TCD].[CharacterListToTable](@UserIdListCSV, ',')
	END
ELSE
	BEGIN
			INSERT	#UserIdList	(
					UserId	)
			SELECT	UM.UserId
			FROM	TCD.UserMaster			UM
	END
------------------------------------------------------------------------------
IF	@ActionTypeListCSV	IS NOT	NULL
	BEGIN
			INSERT	#ActionTypeList	(
					ActionType	)
			SELECT	DISTINCT
					CAST(items AS INT)
			FROM	[TCD].[CharacterListToTable](@ActionTypeListCSV, ',')
	END





CREATE	TABLE	#tempOutput	(
				UserId						INT
			,	UserName					NVARCHAR(200)
			,	DateAndTime					DATETIME
			,	ActionTypeId				TINYINT
			,	ActionDescription			VARCHAR(1000)
			)


--Start collecting data in the temp table...

--UserAudit
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.ActivityTime					AS			DateAndTime
	,	AT.UserActivityId				AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'UserLogon'
			THEN	UM.FullName 
			WHEN	'UserLogoff'
			THEN	UM.FullName 
		END								AS			ActionDescription
FROM	TCD.UserAudit					AT
JOIN	#UserIdList						UL
	ON	AT.UserId						=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.UserActivityId				=			AO.OperationId
WHERE	AT.EcoLabAccountNumber			=			@EcolabAccountNumber
	AND	AT.ActivityTime					BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime 



--AlarmStatusHistory
--MachineNumber is defined NULLable -- should change

INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Alarm status Created' + ' ' + ISNULL(CAST(AT.MachineNumber AS VARCHAR(5)), '')
			WHEN	'SQLUpdate'
			THEN	'Alarm status Updated' + ' ' + ISNULL(CAST(AT.MachineNumber AS VARCHAR(5)), '')
			WHEN	'AppDelete'
			THEN	'Alarm status Deleted' + ' ' + ISNULL(CAST(AT.MachineNumber AS VARCHAR(5)), '')
		END								AS			ActionDescription
FROM	TCD.AlarmStatusHistory			AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime
/*

--BatchStatusHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Batch Added - BatchId: ' + CAST(AT.BatchId	AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Batch updated - BatchId: ' + CAST(AT.BatchId	AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Batch deleted - BatchId: '  + CAST(AT.BatchId	AS VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.BatchHistory				AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcoalabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime
*/

--ConduitControllerHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	DISTINCT UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	--,	AT.OperationTimestamp			AS			DateAndTime
	, CONVERT(DATETIME, CONVERT(VARCHAR, AT.OperationTimestamp, 120), 120) AS DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Controller Created' + ' ' + CAST(AT.ControllerNumber	AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Controller Updated' + ' ' + CAST(AT.ControllerNumber	AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Controller Deleted' + ' ' + CAST(AT.ControllerNumber	AS VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.ConduitControllerHistory	AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcoalabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--ControllerEquipmentSetupHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Equipment details Created' + ' ' + CAST(CC.ControllerNumber AS VARCHAR(5)) + '/' + CAST(AT.ControllerEquipmentId AS VARCHAR(3))
			WHEN	'SQLUpdate'
			THEN	'Equipment details Updated' + ' ' + CAST(CC.ControllerNumber AS VARCHAR(5)) + '/' + CAST(AT.ControllerEquipmentId AS VARCHAR(3))
			WHEN	'AppDelete'
			THEN	'Equipment details Deleted' + ' ' + CAST(CC.ControllerNumber AS VARCHAR(5)) + '/' + CAST(AT.ControllerEquipmentId AS VARCHAR(3))
		END								AS			ActionDescription
FROM	TCD.ControllerEquipmentSetupHistory
										AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.ConduitController			CC
	ON	AT.ControllerId					=			CC.ControllerId
WHERE	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime



--ControllerSetupDataHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Controller setup data Created' + ' ' + CAST(CC.ControllerNumber AS VARCHAR(5)) + '/' + F.Label
			WHEN	'SQLUpdate'
			THEN	'Controller setup data Updated' + ' ' + CAST(CC.ControllerNumber AS VARCHAR(5)) + '/' + F.Label
			WHEN	'AppDelete'
			THEN	'Controller setup data Deleted' + ' ' + CAST(CC.ControllerNumber AS VARCHAR(5)) + '/' + F.Label
		END								AS			ActionDescription
FROM	TCD.ControllerSetupDataHistory	AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.Field						F
	ON	AT.FieldId						=			F.Id
JOIN	TCD.ConduitController			CC
	ON	AT.ControllerId					=			CC.ControllerId
WHERE	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--DashboardHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Dashboard Created' + ' ' + AT.DashBoardName
			WHEN	'SQLUpdate'
			THEN	'Dashboard Updated' + ' ' + AT.DashBoardName
			WHEN	'AppDelete'
			THEN	'Dashboard Deleted' + ' ' + AT.DashBoardName
		END								AS			ActionDescription
FROM	TCD.DashboardHistory			AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--DryersHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Dryer Created' + ' ' + CAST(AT.DryerNo AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Dryer Updated' + ' ' + CAST(AT.DryerNo AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Dryer Deleted' + ' ' + CAST(AT.DryerNo AS VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.DryersHistory				AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--FinnishersHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Finnisher Created' + ' ' + CAST(AT.FinnisherNo AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Finnisher Updated' + ' ' + CAST(AT.FinnisherNo AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Finnisher Deleted' + ' ' + CAST(AT.FinnisherNo AS VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.FinnishersHistory			AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--GroupTypeHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Group Created' + ' - ' + AT.GroupDescription
			WHEN	'SQLUpdate'
			THEN	'Group Updated' + ' - ' + AT.GroupDescription
			WHEN	'AppDelete'
			THEN	'Group Deleted' + ' - ' + AT.GroupDescription
		END								AS			ActionDescription
FROM	TCD.MachineGroupHistory			AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--LaborCostHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Labor Cost Created' + ' ' + LT.[Description]
			WHEN	'SQLUpdate'
			THEN	'Labor Cost Updated' + ' ' + LT.[Description]
			WHEN	'AppDelete'
			THEN	'Labor Cost Deleted' + ' ' + LT.[Description]
		END								AS			ActionDescription
FROM	TCD.LaborCostHistory			AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.LaborType					LT
	ON	AT.LaborTypeId					=			LT.LaborTypeId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--MachineSetupHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Machine' + ' ' + WG.WasherGroupName + '/' +	CAST(W.PlantWasherNumber AS	VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Machine' + ' ' + CAST(W.PlantWasherNumber AS	VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Machine' + ' ' + WG.WasherGroupName + '/' +	CAST(W.PlantWasherNumber AS	VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.MachineSetupHistory			AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.Washer						W
	ON	AT.WasherId						=			W.WasherId
JOIN	TCD.WasherGroup					WG
	ON	AT.GroupId						=			WG.WasherGroupId
WHERE	AT.EcoalabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime
/*

--ManualLaborHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Manual Labour Entry Created' + WG.WasherGroupName + ', Type: ' + LT.[Description]
			WHEN	'SQLUpdate'
			THEN	'Manual Labour Entry Updated' + WG.WasherGroupName + ', Type: ' + LT.[Description]
			WHEN	'AppDelete'
			THEN	'Manual Labour Entry Deleted' + WG.WasherGroupName + ', Type: ' + LT.[Description]
		END								AS			ActionDescription
FROM	TCD.ManualLaborHistory			AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.WasherGroup					WG
	ON	AT.LocationId					=			WG.WasherGroupId
JOIN	LaborType						LT
	ON	AT.ManHourTypeId				=			LT.LaborTypeId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--ManualProductionHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Added Manual Production entry - Record Date: ' + CAST(CAST(AT.RecordedDate AS DATE) AS VARCHAR(30)) + ', Value: ' + CAST(AT.Value AS	VARCHAR(30))
			WHEN	'SQLUpdate'
			THEN	'Updated Manual Production entry - Record Date: ' + CAST(CAST(AT.RecordedDate AS DATE) AS VARCHAR(30)) + ', Value: ' + CAST(AT.Value AS	VARCHAR(30))
			WHEN	'AppDelete'
			THEN	'Deleted Manual Production entry - Record Date: ' + CAST(CAST(AT.RecordedDate AS DATE) AS VARCHAR(30)) + ', Value: ' + CAST(AT.Value AS	VARCHAR(30))
		END								AS			ActionDescription
FROM	TCD.ManualProductionHistory		AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--ManualRewashHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Added Manual Rewash entry - - Record Date: ' + CAST(CAST(AT.RecordedDate AS DATE) AS VARCHAR(30)) + ', Value: ' + CAST(AT.Value AS	VARCHAR(30))
			WHEN	'SQLUpdate'
			THEN	'Updated Manual Rewash entry - - Record Date: ' + CAST(CAST(AT.RecordedDate AS DATE) AS VARCHAR(30)) + ', Value: ' + CAST(AT.Value AS	VARCHAR(30))
			WHEN	'AppDelete'
			THEN	'Deleted Manual Rewash entry - - Record Date: ' + CAST(CAST(AT.RecordedDate AS DATE) AS VARCHAR(30)) + ', Value: ' + CAST(AT.Value AS	VARCHAR(30))
		END								AS			ActionDescription
FROM	TCD.ManualRewashHistory			AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--ManualUtilityHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Added Manual Utility entry - - Record Date: ' + CAST(CAST(AT.RecordedDate AS DATE) AS VARCHAR(30)) + ', Value: ' + CAST(AT.Value AS	VARCHAR(30))
			WHEN	'SQLUpdate'
			THEN	'Updated Manual Utility entry - - Record Date: ' + CAST(CAST(AT.RecordedDate AS DATE) AS VARCHAR(30)) + ', Value: ' + CAST(AT.Value AS	VARCHAR(30))
			WHEN	'AppDelete'
			THEN	'Deleted Manual Utility entry - - Record Date: ' + CAST(CAST(AT.RecordedDate AS DATE) AS VARCHAR(30)) + ', Value: ' + CAST(AT.Value AS	VARCHAR(30))
		END								AS			ActionDescription
FROM	TCD.ManualUtilityHistory		AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime

*/

--MeterHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Meter Created' + ' ' + ISNULL(AT.[Description], '')
			WHEN	'SQLUpdate'
			THEN	'Meter Updated' + ' ' + ISNULL(AT.[Description], '')
			WHEN	'AppDelete'
			THEN	'Meter Deleted' + ' ' + ISNULL(AT.[Description], '')
		END								AS			ActionDescription
FROM	TCD.MeterHistory				AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--MonitorSetUpMappingHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Monitor setup mapping Created' + D.DashBoardName + ', Monitor : ' + ISNULL(AT.MonitorId, '')
			WHEN	'SQLUpdate'
			THEN	'Monitor setup mapping Updated' + D.DashBoardName + ', Monitor : ' + ISNULL(AT.MonitorId, '')
			WHEN	'AppDelete'
			THEN	'Monitor setup mapping Deleted' + D.DashBoardName + ', Monitor : ' + ISNULL(AT.MonitorId, '')
		END								AS			ActionDescription
FROM	TCD.MonitorSetUpMappingHistory	AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.Dashboard					D
	ON	AT.DashboardId					=			D.DashboardId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--PlantHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLUpdate'
			THEN	'Plant Updated' + ' ' + AT.EcolabAccountNumber
		END								AS			ActionDescription
FROM	TCD.PlantHistory				AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime
	AND	AO.OperationCode				=			'SQLUpdate'


--PlantContactHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Plant Contact Created' + ' ' + ISNULL(PCP.Position_Name, '') + ' , ' + AT.ContactFirstName + AT.ContactLastName
			WHEN	'SQLUpdate'
			THEN	'Plant Contact Updated' + ' ' + ISNULL(PCP.Position_Name, '') + ' , ' + AT.ContactFirstName + AT.ContactLastName
			WHEN	'AppDelete'
			THEN	'Plant Contact Deleted' + ' ' + ISNULL(PCP.Position_Name, '') + ' , ' + AT.ContactFirstName + AT.ContactLastName
		END								AS			ActionDescription
FROM	TCD.PlantContactHistory			AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	PlantContactPosition			PCP
	ON	AT.ContactPositionId			=			PCP.Id
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--PlantCustomerHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Plant Customer Created' + ' ' + AT.CustomerName
			WHEN	'SQLUpdate'
			THEN	'Plant Customer Updated' + ' ' + AT.CustomerName
			WHEN	'AppDelete'
			THEN	'Plant Customer Deleted' + ' ' + AT.CustomerName
		END								AS			ActionDescription
FROM	TCD.PlantCustomerHistory		AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--PlantUtilityEnergyPropertiesHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Plant Energy properties details updated'
		END								AS			ActionDescription
FROM	TCD.PlantUtilityEnergyPropertiesHistory
										AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime
	AND	AO.OperationCode				=			'SQLInsert'


--[TCD].PlantUtilityFactorHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Plant Utility factor details Updated: ' + ISNULL(AT.FactorType, '')
		END								AS			ActionDescription
FROM	TCD.PlantUtilityFactorHistory	AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime
	AND	AO.OperationCode				=			'SQLInsert'


--TCD.ProductDataMappingHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Product Mapping Created' + ' ' + PdM.Name
			WHEN	'SQLUpdate'
			THEN	'Product Mapping Updated' + ' ' + PdM.Name
			WHEN	'AppDelete'
			THEN	'Product Mapping Deleted' + ' ' + PdM.Name
		END								AS			ActionDescription
FROM	TCD.ProductDataMappingHistory	AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.ProductMaster				PdM
	ON	AT.ProductID					=			PdM.ProductId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--TCD.ProgramMasterHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Formula Created' + ' ' + AT.Name
			WHEN	'SQLUpdate'
			THEN	'Formula Updated' + ' ' + AT.Name
			WHEN	'AppDelete'
			THEN	'Formula Deleted' + ' ' + AT.Name
		END								AS			ActionDescription
FROM	TCD.ProgramMasterHistory		AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--TCD.RedFlagHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Red Flag Created' + ' ' + CAST(AT.Item AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Red flag Updated' + ' ' + CAST(AT.Item AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Red flag Deleted' + ' ' + CAST(AT.Item AS VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.RedFlagHistory				AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--TCD.RedFlagMappingDataHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Red flag mapping Created' + ' ' + CAST(ISNULL(AT.MachineId, 0) AS VARCHAR(5)) + ', Item :' + CAST(RF.Item AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Red flag mapping Updated' + ' ' + CAST(ISNULL(AT.MachineId, 0) AS VARCHAR(5)) + ', Item :' + CAST(RF.Item AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Red flag mapping Deleted' + ' ' + CAST(ISNULL(AT.MachineId, 0) AS VARCHAR(5)) + ', Item :' + CAST(RF.Item AS VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.RedFlagMappingDataHistory	AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.RedFlag						RF
	ON	AT.MappingId					=			RF.Id
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--TCD.SensorHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Sensor Created' + ' ' + CAST(AT.SensorId AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Sensor Updated' + ' ' + CAST(AT.SensorId AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Sensor Deleted' + ' ' + CAST(AT.SensorId AS VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.SensorHistory				AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime

/*
--TCD.ShiftHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Shift Created' + ' ' + CAST(ISNULL(AT.ShiftName, '') AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Shift Updated' + ' ' + CAST(ISNULL(AT.ShiftName, '') AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Shift Deleted' + ' ' + CAST(ISNULL(AT.ShiftName, '') AS VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.ShiftHistory				AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime

*/

--TCD.ShiftBreakDataHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Shift break Created' --+ ' ' + CAST(ISNULL(S.ShiftName, '') AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Shift break Updated' --+ ' ' + CAST(ISNULL(S.ShiftName, '') AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Shift break Deleted' --+ ' ' + CAST(ISNULL(S.ShiftName, '') AS VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.ShiftHistory				AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
--JOIN	TCD.[Shift]						S
--	ON	AT.ShiftId						=			S.ShiftId	
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--TCD.ShiftDataHistory
--ShiftId is missing from the history table...
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Shift Data Created'	--+ CAST(ISNULL(S.ShiftName, '') AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Shift Data Updated' --+ CAST(ISNULL(S.ShiftName, '') AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Shift Data Deleted' --+ CAST(ISNULL(S.ShiftName, '') AS VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.ShiftDataHistory			AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
--JOIN	TCD.[Shift]						S
--	ON	AT.ShiftId						=			S.ShiftId	
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--TCD.ShiftLaborDataHistory
--EcoLabAccountNumber is going as NULL in the History table...
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Shift Labour Created' --+ ' ' + CAST(ISNULL(S.ShiftName, '') AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Shift Labour Updated' --+ ' ' + CAST(ISNULL(S.ShiftName, '') AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Shift Labour Deleted' --+ ' ' + CAST(ISNULL(S.ShiftName, '') AS VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.ShiftLaborDataHistory		AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
--JOIN	TCD.[Shift]						S
--	ON	AT.ShiftId						=			S.ShiftId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--TCD.TankSetupHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Tank Created'	+ ' ' + ISNULL(AT.TankName, '')
			WHEN	'SQLUpdate'
			THEN	'Tank Updated'	+ ' ' + ISNULL(AT.TankName, '')
			WHEN	'AppDelete'
			THEN	'Tank Deleted'	+ ' ' + ISNULL(AT.TankName, '')
		END								AS			ActionDescription
FROM	TCD.TankSetupHistory			AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcoalabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--TCD.TunnelCompartmentHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Tunnel compartment Created'	+ ' ' + CAST(W.PlantWasherNumber AS VARCHAR(5)) + ', Compartment# : ' + CAST(AT.CompartmentNumber AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Tunnel compartment Updated'	+ ' ' + CAST(W.PlantWasherNumber AS VARCHAR(5)) + ', Compartment# : ' + CAST(AT.CompartmentNumber AS VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.TunnelCompartmentHistory	AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	Washer							W
	ON	AT.WasherId						=			W.WasherId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime
	AND	AO.OperationCode				IN			('SQLInsert', 'SQLUpdate')


--TCD.TunnelCompartmentEquipmentMappingHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Tunnel Compartment Equipment Created' + ' ' + CAST(W.PlantWasherNumber AS VARCHAR(5)) + '/' + CAST(TC.CompartmentNumber AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Tunnel Compartment Equipment Updated' + ' ' + CAST(W.PlantWasherNumber AS VARCHAR(5)) + '/' + CAST(TC.CompartmentNumber AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Tunnel Compartment Equipment Deleted' + ' ' + CAST(W.PlantWasherNumber AS VARCHAR(5)) + '/' + CAST(TC.CompartmentNumber AS VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.TunnelCompartmentEquipmentMappingHistory
										AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.TunnelCompartment			TC
	ON	AT.TunnelCompartmentId			=			TC.TunnelCompartmentId
JOIN	Washer							W
	ON	TC.WasherId						=			W.WasherId
WHERE	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--TCD.TunnelDosingProductMappingHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Tunnel Dosing Product Created' + ' ' + WG.WasherGroupName + '/' + CAST(AT.CompartmentNumber AS VARCHAR(5)) + '/' + PdM.Name
			WHEN	'SQLUpdate'
			THEN	'Tunnel Dosing Product Updated' + ' ' + WG.WasherGroupName + '/' + CAST(AT.CompartmentNumber AS VARCHAR(5)) + '/' + PdM.Name
			WHEN	'AppDelete'
			THEN	'Tunnel Dosing Product Deleted' + ' ' + WG.WasherGroupName + '/' + CAST(AT.CompartmentNumber AS VARCHAR(5)) + '/' + PdM.Name
		END								AS			ActionDescription
FROM	TCD.TunnelDosingProductMappingHistory
										AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.WasherGroup					WG
	ON	AT.GroupId						=			WG.WasherGroupId
JOIN	TCD.ProductMaster				PdM
	ON	AT.ProductId					=			PdM.ProductId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--[TCD].TunnelDosingSetupHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Tunnel Dosing Created' + ' ' + WG.WasherGroupName + '/' + CAST(AT.CompartmentNumber AS VARCHAR(5)) + '/' + CAST(TPS.ProgramNumber AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Tunnel Dosing Updated' + ' ' + WG.WasherGroupName + '/' + CAST(AT.CompartmentNumber AS VARCHAR(5)) + '/' + CAST(TPS.ProgramNumber AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Tunnel Dosing Deleted' + ' ' + WG.WasherGroupName + '/' + CAST(AT.CompartmentNumber AS VARCHAR(5)) + '/' + CAST(TPS.ProgramNumber AS VARCHAR(5))
		END								AS			ActionDescription
FROM	[TCD].TunnelDosingSetupHistory	AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.TunnelProgramSetup			TPS
	ON	AT.TunnelProgramSetupId			=			TPS.TunnelProgramSetupId
JOIN	TCD.WasherGroup					WG
	ON	TPS.WasherGroupId				=			WG.WasherGroupId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--[TCD].[TunnelProgramSetupHistory]
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Tunnel Program Created' + ' ' + WG.WasherGroupName + '/' + CAST(AT.ProgramNumber AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Tunnel Program Updated' + ' ' + WG.WasherGroupName + '/' + CAST(AT.ProgramNumber AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Tunnel Program Deleted' + ' ' + WG.WasherGroupName + '/' + CAST(AT.ProgramNumber AS VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.TunnelProgramSetupHistory	AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.WasherGroup					WG
	ON	AT.WasherGroupId				=			WG.WasherGroupId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--[TCD].UserInRoleHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'User Role Created' + ' ' + UM1.LoginName + '/' + URs.RoleName
			WHEN	'SQLUpdate'
			THEN	'User Role Updated' + ' ' + UM1.LoginName + '/' + URs.RoleName
			WHEN	'AppDelete'
			THEN	'User Role Deleted' + ' ' + UM1.LoginName + '/' + URs.RoleName
		END								AS			ActionDescription
FROM	[TCD].UserInRoleHistory			AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.UserMaster					UM1
	ON	AT.UserId						=			UM1.UserId
JOIN	TCD.UserRoles					URs
	ON	AT.RoleId						=			URs.RoleId
WHERE	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--[TCD].UserMasterHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'User Created' + ' ' + UM1.LoginName
			WHEN	'SQLUpdate'
			THEN	'User Updated' + ' ' + UM1.LoginName
			WHEN	'AppDelete'
			THEN	'User Deleted' + ' ' + UM1.LoginName
		END								AS			ActionDescription
FROM	[TCD].UserMasterHistory			AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.UserMaster					UM1
	ON	AT.UserId						=			UM1.UserId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--[TCD].WasherHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Washer Created' + ' ' + CAST(AT.PlantWasherNumber AS	VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Washer Updated' + ' ' + CAST(AT.PlantWasherNumber AS	VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Washer Deleted' + ' ' + CAST(AT.PlantWasherNumber AS	VARCHAR(5))
		END								AS			ActionDescription
FROM	[TCD].WasherHistory				AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--[TCD].[WasherDosingProductMappingHistory]
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Washer Dosing Product Created' + ' ' + WG.WasherGroupName + '/' + CAST(WDS.StepNumber AS VARCHAR(5)) + '/' + PdM.Name
			WHEN	'SQLUpdate'
			THEN	'Washer Dosing Product Updated' + ' ' + WG.WasherGroupName + '/' + CAST(WDS.StepNumber AS VARCHAR(5)) + '/' + PdM.Name
			WHEN	'AppDelete'
			THEN	'Washer Dosing Product Deleted' + ' ' + WG.WasherGroupName + '/' + CAST(WDS.StepNumber AS VARCHAR(5)) + '/' + PdM.Name
		END								AS			ActionDescription
FROM	[TCD].[WasherDosingProductMappingHistory]
										AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.WasherDosingSetup			WDS
	ON	AT.WasherDosingSetupId			=			WDS.WasherDosingSetupId
JOIN	TCD.WasherProgramSetup			WPS
	ON	WDS.WasherProgramSetupId		=			WPS.WasherProgramSetupId
JOIN	TCD.WasherGroup					WG
	ON	WPS.WasherGroupId				=			WG.WasherGroupId
JOIN	TCD.ProductMaster				PdM
	ON	AT.ProductId					=			PdM.ProductId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--[TCD].WasherDosingSetupHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Conventional Washer Dosing Created' + ' ' + WG.WasherGroupName + '/' + CAST(AT.StepNumber AS VARCHAR(5)) + '/' + CAST(WPS.ProgramNumber AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Conventional Washer Dosing Updated' + ' ' + WG.WasherGroupName + '/' + CAST(AT.StepNumber AS VARCHAR(5)) + '/' + CAST(WPS.ProgramNumber AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Conventional Washer Dosing Deleted' + ' ' + WG.WasherGroupName + '/' + CAST(AT.StepNumber AS VARCHAR(5)) + '/' + CAST(WPS.ProgramNumber AS VARCHAR(5))
		END								AS			ActionDescription
FROM	[TCD].WasherDosingSetupHistory	AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.WasherProgramSetup			WPS
	ON	AT.WasherProgramSetupId			=			WPS.WasherProgramSetupId
JOIN	TCD.WasherGroup					WG
	ON	WPS.WasherGroupId				=			WG.WasherGroupId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--[TCD].WasherGroupHistory
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Washer Group Created' + ' ' + AT.WasherGroupName
			WHEN	'SQLUpdate'
			THEN	'Washer Group Updated' + ' ' + AT.WasherGroupName
			WHEN	'AppDelete'
			THEN	'Washer Group Deleted' + ' ' + AT.WasherGroupName
		END								AS			ActionDescription
FROM	[TCD].WasherGroupHistory		AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--[TCD].[WasherProgramSetupHistory]
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Conventional Washer Program Created' + ' ' + WG.WasherGroupName + '/' + CAST(AT.ProgramNumber AS VARCHAR(5))
			WHEN	'SQLUpdate'
			THEN	'Conventional Washer Program Updated' + ' ' + WG.WasherGroupName + '/' + CAST(AT.ProgramNumber AS VARCHAR(5))
			WHEN	'AppDelete'
			THEN	'Conventional Washer Program Deleted' + ' ' + WG.WasherGroupName + '/' + CAST(AT.ProgramNumber AS VARCHAR(5))
		END								AS			ActionDescription
FROM	TCD.WasherProgramSetupHistory	AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
JOIN	TCD.WasherGroup					WG
	ON	AT.WasherGroupId				=			WG.WasherGroupId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime


--'[TCD].WaterAndEnergyHistory'
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	AT.OperationId					AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Water & Energy Device Created' + ' ' + AT.DeviceName
			WHEN	'SQLUpdate'
			THEN	'Water & Energy Device Updated' + ' ' + AT.DeviceName
			WHEN	'AppDelete'
			THEN	'Water & Energy Device Deleted' + ' ' + AT.DeviceName
		END								AS			ActionDescription
FROM	[TCD].WaterAndEnergyHistory		AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime

--'[TCD].ReportHistory'
INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.DateAndTime			AS			DateAndTime
	,	AT.ActionTypeId					AS			ActionTypeId
	,	ActionDescription	AS			ActionDescription
FROM	[TCD].ReportHistory		AT
JOIN	#UserIdList						UL
	ON	AT.UserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.ActionTypeId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.DateAndTime			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime
--Manual Entry Rewash

INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	@ManualEntry				AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Manual Rewash Created'
			WHEN	'SQLUpdate'
			THEN	'Manual Rewash Updated'
			WHEN	'AppDelete'
			THEN	'Manual Rewash Deleted'
		END								AS			ActionDescription
FROM	[TCD].ManualRewashHistory		AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime

--Manual Entry Production

INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	@ManualEntry				AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Manual Production Created'
			WHEN	'SQLUpdate'
			THEN	'Manual Production Updated'
			WHEN	'AppDelete'
			THEN	'Manual Production Deleted'
		END								AS			ActionDescription
FROM	[TCD].ManualProductionHistory		AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime
--Manual Entry Labour

INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	@ManualEntry				AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Manual Labour Created'
			WHEN	'SQLUpdate'
			THEN	'Manual Labour Updated'
			WHEN	'AppDelete'
			THEN	'Manual Labour Deleted'
		END								AS			ActionDescription
FROM	[TCD].ManualLaborHistory		AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime		
											
--Manual Entry Utility

INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	@ManualEntry				AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Manual Utility Created'
			WHEN	'SQLUpdate'
			THEN	'Manual Utility Updated'
			WHEN	'AppDelete'
			THEN	'Manual Utility Deleted'
		END								AS			ActionDescription
FROM	[TCD].ManualUtilityHistory		AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	AT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	AT.OperationTimestamp			BETWEEN		@FromDateAndTime
											AND		@ToDateAndTime	
											
--Manual Entry Batch data

INSERT	INTO	#tempOutput	(
				UserId	,UserName	,DateAndTime	,ActionTypeId	,ActionDescription
				)
SELECT	UM.UserId						AS			UserId
	,	UM.FullName					AS			UserName
	,	AT.OperationTimestamp			AS			DateAndTime
	,	@ManualEntry				AS			ActionTypeId
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Manual Batch Created'
			WHEN	'SQLUpdate'
			THEN	'Manual Batch Updated'
			WHEN	'AppDelete'
			THEN	'Manual Batch Deleted'
		END								AS			ActionDescription
FROM	[TCD].BatchDataHistory		AT
JOIN	#UserIdList						UL
	ON	AT.OperationByUserId			=			UL.UserId
JOIN	TCD.UserMaster					UM
	ON	UL.UserId						=			UM.UserId
JOIN	TCD.AuditOperation				AO
	ON	AT.OperationId					=			AO.OperationId
WHERE	--AT.EcolabAccountNumber			=			@EcolabAccountNumber AND
		AT.OperationTimestamp			BETWEEN		@FromDateAndTime
					
					
											AND		@ToDateAndTime									

--Output the collected data

SELECT	T.UserName						AS			UserName
	,	T.DateAndTime					AS			DateAndTime
	,	CASE	AO.OperationCode
			WHEN	'SQLInsert'
			THEN	'Create'
			WHEN	'SQLUpdate'
			THEN	'Updated'
			WHEN	'AppDelete'
			THEN	'Deleted'
			WHEN	'UserLogon'
			THEN	'Logged In'
			WHEN	'UserLogoff'
			THEN	'Logged Out'
			WHEN 'ReportGenerated'
			THEN	'ReportGenerated'
			WHEN 'Manual Entry' 
			THEN 'Manual Entry' 
			--WHEN 'Manual Entry' THEN CASE WHEN T.ActionDescription LIKE 'Added Manual%' THEN 'Manual Entry - Inserted'
			--					     WHEN T.ActionDescription LIKE 'Updated Manual%' THEN 'Manual Entry - Updated'
			--						WHEN T.ActionDescription LIKE 'Deleted Manual%' THEN 'Manual Entry - Deleted' END
			ELSE	AO.OperationCode
		END								AS			ActionType
	,	T.ActionDescription				AS			ActionDescription
		 ,COUNT(*) OVER() as TotalCount
		 ,1 AS ROWNO
	 INTO #UserLogTableOrder
FROM	#tempOutput						T
JOIN	TCD.AuditOperation				AO
	ON	T.ActionTypeId					=			AO.OperationId
	AND
	CASE @ActionTypeListCSV   
				 WHEN '' THEN 'TRUE'         
				 ELSE                                                      
				  CASE WHEN AO.OperationId IN (SELECT * FROM #ActionTypeList) THEN 'TRUE' END                                                      
				END='TRUE' 
	   
	   SELECT * INTO #UserLogTablePaging FROM #UserLogTableOrder WHERE 1=2



		  SET @SQLStatement 
					   ='INSERT INTO #UserLogTablePaging(UserName,DateAndTime,ActionType,ActionDescription,TotalCount,ROWNO) SELECT UserName,
							 DateAndTime,
							 ActionType,
							 ActionDescription,
							 TotalCount,
							 ROW_NUMBER() OVER (ORDER BY ' + @SortField + ' ' + @SortDirection +')
							  FROM #UserLogTableOrder ORDER BY ' + @SortField + ' ' + @SortDirection

			 --PRINT @SQLStatement
			--INSERT INTO #UserLogTablePaging(UserName,DateAndTime,ActionType,ActionDescription,TotalCount,ROWNO)
	   		EXEC(@SQLStatement)

	IF((@PageNo IS NULL) OR (@RecordsPerPage IS NULL))
	BEGIN
		  SELECT 
				UserName,
				DateAndTime,
				ActionType,
				ActionDescription,
				TotalCount,
				ROWNO
		   FROM #UserLogTablePaging
	 END
	  ELSE
	  BEGIN
		SET @PageNo = @PageNo-1
		  SELECT 
				UserName,
				DateAndTime,
				ActionType,
				ActionDescription,
				TotalCount,
				ROWNO
		   FROM #UserLogTablePaging
		   WHERE ROWNO BETWEEN @PageNo * @RecordsPerPage + 1 AND (@PageNo + 1) *  @RecordsPerPage  
	  END

DROP TABLE #UserLogTableOrder
DROP TABLE #UserLogTablePaging
SET NOCOUNT OFF;
END