﻿CREATE PROCEDURE [TCD].[GetWasherTimeOutMachine] (
     @WasherId INT
    , @EcolabAccountNumber NVARCHAR(25)
	, @ControllerModelId INT
	, @ControllerTypeId INT)
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE
        @plantId INT = (SELECT P.PlantId
                      FROM TCD.Plant P
                      WHERE P.EcolabAccountNumber = @EcolabAccountNumber);

DECLARE @WasherTypeId bit = (SELECT ms.IsTunnel FROM TCD.MachineSetup ms  WHERE ms.WasherId = @WasherId)

IF EXISTS(SELECT 1 FROM TCD.WasherTimeOutMachine WHERE WasherId = @WasherId AND PlantId = @plantId)
BEGIN
    SELECT WTOM.WasherId
        , WTOM.SignalNumber
        , WTOM.EquipmentNumber
        , WTOM.DosingPointNumber
        , WTOM.PlantId
        , WTOM.LastModifiedTime
     FROM TCD.WasherTimeOutMachine WTOM
     WHERE WTOM.WasherId = @WasherId
       AND WTOM.PlantId = @plantId
       AND WTOM.Is_Deleted = 'FALSE';
END
ELSE
	IF(@WasherTypeId = 0)
		BEGIN
		SELECT cmctm.MaxNumOfTOMEquipmentForConventional
			,  cmctm.MaxNumOfTOMDosingPointForConventional 
		FROM TCD.ControllerModelControllerTypeMapping cmctm
		WHERE 
		  cmctm.ControllerModelId = @ControllerModelId 
		AND 
		  cmctm.ControllerTypeId  = @ControllerTypeId
		END
	ELSE
		BEGIN
		SELECT cmctm.MaxNumOfTOMEquipmentForTunnel
			,  cmctm.MaxNumOfTOMDosingPointForTunnel 
		FROM TCD.ControllerModelControllerTypeMapping cmctm
		
		WHERE 
		  cmctm.ControllerModelId = @ControllerModelId 
		AND 
		  cmctm.ControllerTypeId  = @ControllerTypeId
		END

    SET NOCOUNT OFF;
END;