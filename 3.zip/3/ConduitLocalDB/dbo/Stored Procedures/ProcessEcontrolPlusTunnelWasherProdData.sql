﻿
CREATE PROCEDURE TCD.ProcessEcontrolPlusTunnelWasherProdData(
 @Controllerid	 INT, 
 @Xmltags		 XML, 
 @Plcpointer	 INT, 
 @Readpointer	 INT, 
 @Redflagshiftid INT OUTPUT)
AS
BEGIN
	DECLARE @Batchid				   INT, 
			@Washerid				   INT, 
			@Ecolabwasherid			   INT, 
			@Currencycode			   VARCHAR(50), 
			@Machineinternalid		   INT, 
			@Washergroupid			   INT, 
			@Plantwashernumber		   INT, 
			@Programnumber			   INT, 
			@Load					   DECIMAL(10, 2), 
			@Nominalload			   DECIMAL(10, 2), 
			@Customernumber			   INT, 
			@Phstatus				   INT, 
			@Phvalue				   INT, 
			@Lfstatus				   INT, 
			@Lfvalue				   INT, 
			@Batchnumber			   INT, 
			@Targetturntime			   INT, 
			@Partitionon			   DATETIME2, 
			@Batchstarttime			   DATETIME2, 
			@Batchendtime			   DATETIME2, 
			@Programid				   INT, 
			@Numberofcompartments	   INT, 
			@Productid				   INT, 
			@Compartmentnum			   INT, 
			@Equipmenttype			   INT, 
			@Mintempparamid			   INT, 
			@Maxtempparamid			   INT, 
			@Tempstatusparamid		   INT, 
			@Phvalueparamid			   INT, 
			@Phstatusparamid		   INT, 
			@Conductivityvalueparamid  INT, 
			@Conductivitystatusparamid INT, 
			@Stdinjectionsteps		   INT, 
			@Stdwashsteps			   INT, 
			@Actualinjsteps			   INT, 
			@Ecolabtextilecategoryid   INT, 
			@Chaintextilecategoryid	   INT, 
			@Formulasegmentid		   INT, 
			@Ecolabsaturationid		   INT, 
			@Plantprogramid			   INT, 
			@Previousshiftid		   INT, 
			@Currentshiftid			   INT, 
			@Currentstepcomportmentno  INT, 
			@Counterno				   INT, 
			@Meterid				   INT, 
			@Actualquantity			   DECIMAL(10, 6), 
			@Batchstepcount			   INT, 
			@Ecolabaccountnumber	   VARCHAR(100), 
			@Alarmgroupmasterid		   INT, 
			@Standardquantity		   DECIMAL(18, 4), 
			@Price					   DECIMAL(18, 4), 
			@Temperaturemin			   INT, 
			@Temperaturemax			   INT,
			@TotalInjectsCountFromUI		INT,
			@TotalInjectsCountFromPLC		INT;
	DECLARE @Batchshiftid INT;
	DECLARE @Shiftstartdatetemp TABLE
	(
		 ShiftId		INT, 
		 ShiftName		NVARCHAR(50), 
		 ShiftStartdate DATETIME
	);
	SELECT 
		   @Machineinternalid = T.c.value('@MachineNumber', 'int'), 
		   @Batchnumber = T.c.value('@BatchNumber', 'INT'), 
		   @Batchstarttime = T.c.value('@StartDateTime', 'DateTime'), 
		   @Batchendtime = T.c.value('@EndDateTime', 'DateTime'), 
		   @Programnumber = T.c.value('@ProgramNumber', 'INT'), 
		   @Load = T.c.value('@Load', 'Decimal(10,2)'), 
		   @Nominalload = T.c.value('@Nominalload', 'Decimal(10,2)'), 
		   @Customernumber = T.c.value('@CustomerNumber', 'int'), 
		   @Temperaturemin = T.c.value('@TemperatureMin', 'INT'), 
		   @Temperaturemax = T.c.value('@TemperatureMax', 'INT'), 
		   @Phvalue = T.c.value('@Phvalue', 'INT')
		FROM @Xmltags.nodes('MyControlTunnel/TunnelData') AS T(c);
	DECLARE @Tunnelxml XML;
	SELECT 
		   @Tunnelxml = T.c.query('.')
		FROM @Xmltags.nodes('MyControlTunnel/TunnelData') AS T(c)
		WHERE T.c.value('@MachineNumber', 'int') = @Machineinternalid;
	--Check for valid startdatetime
	IF @Batchstarttime <= '01/01/1900'
	   OR @Batchstarttime > '06/06/2079'
		BEGIN
			RETURN;
		END;
	SELECT 
		   @Ecolabwasherid = Ws.EcolabWasherId, 
		   @Washergroupid = Wg.WasherGroupId, 
		   @Plantwashernumber = PlantWasherNumber, 
		   @Washerid = ws.WasherId, 
		   @Currencycode = P.CurrencyCode, 
		   @Numberofcompartments = Mst.NumberofComp
		FROM TCD.Washer AS Ws
			 INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = Ws.WasherId
			 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
			 INNER JOIN TCD.WasherGroupType AS WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
			 INNER JOIN TCD.ConduitController AS Ctrl ON Ctrl.ControllerId = Mst.ControllerId
			 INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.EcoLabAccountNumber
		WHERE Ctrl.ControllerID = @Controllerid
			  AND Mst.MachineInternalId = @Machineinternalid
			  AND Mst.IsTunnel = 1
			  AND Mst.IsDeleted = 0;
	SELECT 
		   @Ecolabwasherid;
	SELECT 
		   @Programid = ProgramId, 
		   @Targetturntime = 3600 / (tps.TotalRunTime / @Numberofcompartments)
		FROM TCD.TunnelProgramSetup AS tps
		WHERE tps.WasherGroupId = @Washergroupid
			  AND tps.is_deleted = 0
			  AND ProgramNumber = @Programnumber;
	DELETE FROM @Shiftstartdatetemp;
	IF @Batchendtime IS NOT NULL
		BEGIN
			INSERT INTO @Shiftstartdatetemp
			(
				   ShiftId, 
				   ShiftName, 
				   ShiftStartdate
			)
			EXEC TCD.GetShiftStartDate 
				 @Batchendtime;
		END;
	ELSE
		BEGIN
			INSERT INTO @Shiftstartdatetemp
			(
				   ShiftId, 
				   ShiftName, 
				   ShiftStartdate
			)
			EXEC TCD.GetShiftStartDate 
				 @Batchstarttime;
		END;
	SELECT 
		   @Batchshiftid = ShiftID, 
		   @Partitionon = ShiftStartdate FROM @Shiftstartdatetemp;
	--Start Getting InjectionCount,StepCount And ProductCount
	SELECT 
		   @Stdinjectionsteps = COUNT(tdpm.TunnelDosingSetupId), 
		   @Stdwashsteps = COUNT(DISTINCT tds.TunnelDosingSetupId) - COUNT(tdpm.TunnelDosingSetupId)
		FROM tcd.TunnelDosingProductMapping AS tdpm
			 RIGHT JOIN tcd.TunnelDosingSetup AS tds ON tdpm.TunnelDosingSetupId = tds.TunnelDosingSetupId
		WHERE tds.GroupId = @Washergroupid
			  AND tds.ProgramNumber = @Programnumber
			  AND tds.Is_Deleted = 0;
	--End Getting InjectionCount,StepCount And ProductCount
	--Start-----ProgramMasterID logic for PlantChainProgram
	SELECT 
		   @Plantprogramid = pm.PlantProgramId, 
		   @Ecolabtextilecategoryid = pm.EcolabTextileCategoryId, 
		   @Chaintextilecategoryid = pm.ChainTextileId, 
		   @Formulasegmentid = pm.FormulaSegmentId, 
		   @Ecolabsaturationid = pm.EcolabSaturationId
		FROM TCD.ProgramMaster AS pm
		WHERE pm.ProgramId = @Programid
			  AND pm.Is_Deleted = 0;
	IF @Plantprogramid <> 0
	   OR @Plantprogramid IS NOT NULL
		BEGIN
			--Assign value from plantchainprogram table based on plantprogramId
			SELECT 
				   @Ecolabtextilecategoryid = pcp.EcolabTextileCategoryId, 
				   @Chaintextilecategoryid = pcp.ChainTextileCategoryId, 
				   @Formulasegmentid = pcp.FormulaSegmentId, 
				   @Ecolabsaturationid = pcp.EcolabSaturationId
				FROM tcd.PlantChainProgram AS pcp
				WHERE pcp.PlantProgramId = @Plantprogramid
					  AND pcp.Is_Deleted = 0;
		END;
	--End-----ProgramMasterID logic for PlantChainProgram
	SELECT 
		   @Batchid = NULL;
	SELECT 
		   @Batchid = BatchID
		FROM TCD.BatchData AS BD
		WHERE BD.ControllerBatchId = @Batchnumber
			  AND BD.StartDate = @Batchstarttime
			  AND BD.MachineId = @Washerid;
	--AND BD.MachineInternalID = @MachineInternalID
	IF @Batchid IS NULL
		BEGIN
			--Start Rollup for previous completed shift
			IF CAST(@Batchstarttime AS DATE) < CAST(GETUTCDATE() AS DATE)
				BEGIN
					SELECT TOP 1 
						   @Previousshiftid = ShiftId
						FROM TCD.BatchData
						WHERE MachineId = @Washerid
						ORDER BY 
								 StartDate DESC;
					SELECT TOP 1 
						   @Currentshiftid = ShiftId FROM @Shiftstartdatetemp;
					IF @Currentshiftid != @Previousshiftid
						BEGIN
							EXEC TCD.ProductionShiftDataRollup 
								 @Previousshiftid, 
								 @Redflagshiftid OUTPUT;
							IF @Redflagshiftid IS NULL
								BEGIN
									SET @Redflagshiftid = @Previousshiftid;
								END;
						END;
				END;
			--End Rollup for previous completed shift
			INSERT INTO TCD.BatchData
			(
				   ControllerBatchId, 
				   EcolabWasherId, 
				   GroupId, 
				   MachineInternalId, 
				   PlantWasherNumber, 
				   StartDate, 
				   EndDate, 
				   ProgramNumber, 
				   ProgramMasterId, 
				   MachineId, 
				   ActualWeight, 
				   StandardWeight, 
				   CurrencyCode, 
				   ShiftId, 
				   PartitionOn, 
				   TargetTurnTime, 
				   StdInjectionSteps, 
				   StdWashSteps, 
				   EcolabTextileCategoryId, 
				   ChainTextileCategoryId, 
				   FormulaSegmentId, 
				   EcolabSaturationId, 
				   PlantProgramId, 
				   EndDateFormula,
				   SyncReady
			)
				   SELECT 
						  @Batchnumber, 
						  @Ecolabwasherid, 
						  @Washergroupid, 
						  @Machineinternalid, 
						  @Plantwashernumber, 
						  @Batchstarttime, 
						  @Batchendtime, 
						  @Programnumber, 
						  @Programid, 
						  @Washerid, 
						  @Load, 
						  ISNULL(@Nominalload, 0), 
						  @Currencycode, 
						  @Batchshiftid, 
						  @Partitionon, 
						  @Targetturntime, 
						  @Stdinjectionsteps, 
						  @Stdwashsteps, 
						  @Ecolabtextilecategoryid, 
						  @Chaintextilecategoryid, 
						  @Formulasegmentid, 
						  @Ecolabsaturationid, 
						  @Plantprogramid, 
						  @Batchendtime,
						  1;
			SELECT 
				   @Batchid = SCOPE_IDENTITY();
			IF @Stdwashsteps > 0
			   OR @Stdwashsteps <> NULL
				INSERT INTO TCD.BatchParameters
				(
					   BatchId, 
					   EcolabWasherId, 
					   ParameterId, 
					   ParameterValue, 
					   PartitionOn
				)
					   SELECT 
							  @Batchid, 
							  @Ecolabwasherid, 
							  38, 
							  @Stdwashsteps, 
							  @Partitionon;
		END;
	IF @Batchendtime IS NOT NULL
	   AND @Batchendtime != '01/01/1900'
		BEGIN
			UPDATE TCD.BatchData
			  SET 
				  EndDate = @Batchendtime, 
				  ShiftId = @Batchshiftid, 
				  PartitionOn = @Partitionon, 
				  EndDateFormula = @Batchendtime, 
				  StandardWeight = @Nominalload, 
				  SyncReady = 1
				WHERE 
					  BATCHID = @Batchid;
		END;
	EXEC TCD.UPDATEBatchWashStepForTunnel 
		 @Tunnelxml, 
		 @Washerid, 
		 @Batchid, 
		 @Batchstarttime, 
		 @Partitionon, 
		 @Ecolabwasherid, 
		 @Numberofcompartments;
	--If the received formula is not configured in enVision then create an alarm 
	IF @Programid IS NULL
		BEGIN
			SELECT 
				   @Ecolabaccountnumber = EcolabAccountNumber FROM TCD.Plant;
			SELECT 
				   @Alarmgroupmasterid = AGM.AlarmGroupMasterId
				FROM TCD.AlarmGroupMsterVsControllerModelType AS AGMVCMT
					 INNER JOIN TCD.AlarmGroupMaster AS AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
				WHERE AGMVCMT.AlarmCode = 9000;
			INSERT INTO TCD.AlarmData
			(
				   EcoalabAccountNumber, 
				   AlarmCode, 
				   BatchId, 
				   controllerID, 
				   StartDate, 
				   GroupId, 
				   MachineInternalId, 
				   ProgramId, 
				   IsActive, 
				   EndDate, 
				   MachineId, 
				   AlarmGroupMasterId,
				   PartitionOn
			)
				   SELECT 
						  @Ecolabaccountnumber, 
						  9000, 
						  @Batchid, 
						  @Controllerid, 
						  @Batchstarttime, 
						  @Washergroupid, 
						  @Machineinternalid, 
						  @Programnumber, 
						  0, 
						  @Batchstarttime, 
						  @Washerid, 
						  @Alarmgroupmasterid,
						  @Batchstarttime

		END;
	IF @Customernumber IS NOT NULL
		BEGIN
			IF NOT EXISTS
						 (SELECT 
								 1 FROM TCD.BatchCustomerData WHERE BatchID = @Batchid
						 )
				BEGIN
					INSERT INTO TCD.BatchCustomerData
					(
						   BatchId, 
						   CustomerId, 
						   Weight, 
						   PiecesCount, 
						   PartitionOn, 
						   EcolabWasherId
					)
						   SELECT DISTINCT 
								  Bd.BatchId, 
								  Pc.ID, 
								  @Load, 
								  ROUND(COALESCE((@Load * Pm.Pieces) / NULLIF(Pm.Weight, 0), 0), 0), 
								  (SELECT TOP 1 
										  ShiftStartdate FROM @Shiftstartdatetemp
								  ), 
								  @Ecolabwasherid
							   FROM TCD.Washer AS WS
									INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = ws.WasherId
									INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
									INNER JOIN TCD.TunnelProgramSetup AS Tps ON Tps.WasherGroupId = Wg.WasherGroupId
									INNER JOIN TCD.ProgramMaster AS Pm ON Pm.ProgramId = Tps.ProgramId
									INNER JOIN TCD.PlantCustomer AS Pc ON Pc.ID = Pm.CustomerId
									INNER JOIN TCD.BatchData AS Bd ON Bd.MachineId = Ws.WasherId
							   WHERE Ws.WasherId = @Washerid
									 AND Tps.ProgramNumber = @Programnumber
									 AND Bd.BatchId = @Batchid
									 AND Pm.CustomerId != -1
									 AND Pm.Weight > 0;
				END;
		END;
	CREATE TABLE #DosingDetails
	(
		 Number			 INT, 
		 Quantity		 DECIMAL(10, 6), 
		 Point			 INT, 
		 IsMainEquioment INT
	);
	INSERT INTO #DosingDetails
	(
		   Number, 
		   Quantity, 
		   Point, 
		   IsMainEquioment
	)
		   SELECT 
				  T.c.value('@Number', 'INT') AS Number, --PumpNumber
				  T.c.value('@Quantity', 'Decimal(10,6)') AS Quantity, --Dosing Quanity
				  T.c.value('@Point', 'INT') AS Point, --Dosing point
				  T.c.value('@IsMainEquioment', 'INT') AS IsMainEquioment
			   FROM @Xmltags.nodes('MyControlTunnel/TunnelData/Dose') AS T(C);

	-- Fetching data from cursor
	DECLARE @Mycursor CURSOR;
	SET @Mycursor = CURSOR FAST_FORWARD
	FOR SELECT 
			   Number, 
			   Quantity, 
			   Point, 
			   IsMainEquioment FROM #DosingDetails;
	DECLARE @Number			 INT, 
			@Quantity		 DECIMAL(10, 6), 
			@Point			 INT, 
			@Ismainequioment INT;
	OPEN @Mycursor;
	FETCH NEXT FROM @Mycursor INTO @Number, 
								   @Quantity, 
								   @Point, 
								   @Ismainequioment;
	WHILE @@Fetch_Status = 0
		BEGIN
			IF @Ismainequioment = 1
				BEGIN
					SET @Equipmenttype = 2;
					SET @Quantity = @Quantity * 16;	 --Converting pounds to ounces
				END;
			ELSE
				BEGIN
					SET @Equipmenttype = 1;
				END;
			SELECT 
				   @Productid = CES.ProductId, 
				   @Compartmentnum = TCEVM.CompartmentNumber
				FROM tcd.ControllerEquipmentSetup AS CES
					 INNER JOIN TCD.TunnelCompartmentEquipmentValveMapping AS TCEVM ON CES.ControllerEquipmentSetupId = TCEVM.
					 ControllerEquipmentSetupId
				WHERE CES.ControllerId = @Controllerid
					  AND CES.ControllerEquipmentTypeId = @Equipmenttype
					  AND --CES.IsActive=1 AND
					  --CES.WasherGroupNumber=@WasherGroupNum AND
					  TCEVM.DosingPointNumber = @Point
					  AND CES.ControllerEquipmentId = @Number;
			SELECT DISTINCT 
				   @Standardquantity = (Wps.NominalLoad * Wdpm.Quantity) / 100, 
				   @Price = ((Wps.NominalLoad * Wdpm.Quantity) / 100) * tcd.FnChemicalCostInOunce(Pdm.ProductID)
				FROM TCD.Washer AS WS
					 INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = ws.WasherId
					 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
					 INNER JOIN TCD.WasherGroupType AS WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
					 INNER JOIN TCD.TunnelProgramSetup AS Wps ON Wps.WasherGroupId = Wg.WasherGroupId
					 INNER JOIN TCD.TunnelDosingSetup AS Wds ON Wds.TunnelProgramSetupId = Wps.TunnelProgramSetupId
					 INNER JOIN TCD.TunnelDosingProductMapping AS Wdpm ON Wdpm.TunnelDosingSetupId = Wds.TunnelDosingSetupId
					 INNER JOIN TCD.ControllerEquipmentSetup AS Ces ON Ces.ControllerEquipmentSetupId = Wdpm.ControllerEquipmentSetupId
					 INNER JOIN TCD.ProductdataMapping AS Pdm ON Pdm.ProductId = Ces.ProductId
				WHERE Ws.WasherId = @Washerid
					  AND Wps.ProgramNumber = @Programnumber
					  AND Wds.CompartmentNumber = @Compartmentnum
					  AND Wps.Is_Deleted = 0
					  AND Pdm.Is_Deleted = 0;
			IF @Productid IS NOT NULL
				BEGIN
					INSERT INTO TCD.BatchProductData
					(
						   BatchId, 
						   StepCompartment, 
						   ActualQuantity, 
						   StandardQuantity, 
						   Price, 
						   TimeStamp, 
						   PartitionOn, 
						   EcolabWasherId, 
						   ProductId
					)
						   SELECT 
								  @Batchid, 
								  @Compartmentnum, 
								  @Quantity, 
								  ISNULL(@Standardquantity, 0), 
								  ISNULL(@Price, 0), 
								  @Batchendtime, 
								  @Partitionon, 
								  @Ecolabwasherid, 
								  @Productid;
				END;
			FETCH NEXT FROM @Mycursor INTO @Number, 
										   @Quantity, 
										   @Point, 
										   @Ismainequioment;
		END;
	CLOSE @Mycursor;
	DEALLOCATE @Mycursor;
	DROP TABLE #DosingDetails;

	--BatchStatus parametr insertion start
	SELECT DISTINCT 
						@TotalInjectsCountFromUI = COUNT(1)
				FROM TCD.Washer AS ws
						INNER JOIN TCD.MachineSetup AS ms ON ms.WasherId = ws.WasherId
						INNER JOIN TCD.WasherGroup AS wg ON wg.WasherGroupId = ms.GroupId
						INNER JOIN TCD.WasherGroupType AS WgT ON WgT.WasherGroupTypeId = wg.WasherGroupTypeId
						INNER JOIN TCD.TunnelProgramSetup AS tps ON tps.WasherGroupId = wg.WasherGroupId
						INNER JOIN TCD.TunnelDosingSetup AS tds ON tds.TunnelProgramSetupId = tps.TunnelProgramSetupId
						INNER JOIN TCD.TunnelDosingProductMapping AS tdpm ON tdpm.TunnelDosingSetupId = tds.TunnelDosingSetupId
						 
				WHERE tds.Is_Deleted = 0							
						AND ms.IsTunnel = 1
						AND ms.GroupId = @WasherGroupId
						AND ms.WasherId = @Washerid
						AND ms.ControllerId =@Controllerid
						AND ms.IsDeleted = 0

	SELECT @TotalInjectsCountFromPLC=Count(*) FROM TCD.BatchProductData bpd WHERE bpd.BatchId=@Batchid

	IF NOT EXISTS
				(SELECT 
						* FROM TCD.BatchParameters WHERE BatchId = @Batchid
														AND ParameterID = 18
				)
	BEGIN
			INSERT INTO TCD.BatchParameters
				(
						BatchId, 
						EcolabWasherId, 
						ParameterId, 
						ParameterValue, 
						PartitionOn
				)
						SELECT 
								@Batchid, 
								@Ecolabwasherid, 
								18, 
								CASE WHEN @TotalInjectsCountFromUI=@TotalInjectsCountFromPLC THEN 1
									WHEN @TotalInjectsCountFromUI<>@TotalInjectsCountFromPLC THEN 3 END, 
								@Partitionon;
	END;
	--BatchStatus parameter insertion end

	IF NOT EXISTS
				 (SELECT 
						 * FROM TCD.BatchParameters WHERE ParameterId = 41
														  AND batchid = @Batchid
				 )
		BEGIN
			INSERT INTO Tcd.BatchParameters
			(
				   BatchId, 
				   EcolabWasherId, 
				   ParameterId, 
				   ParameterValue, 
				   PartitionOn
			)
				   SELECT 
						  @Batchid, 
						  @Ecolabwasherid, 
						  41,
						  CASE
							  WHEN SUM(bpd.ActualQuantity) = SUM(bpd.StandardQuantity)
							  THEN 1		--'Approved'
							  WHEN SUM(bpd.ActualQuantity) <> SUM(bpd.StandardQuantity)
							  THEN 2		--'Rejected'
							  ELSE 1		--'Approved'
						  END, 
						  @Partitionon
					   FROM TCD.BatchProductData AS bpd
					   WHERE bpd.BatchId = @Batchid;
		END;
	SELECT 
		   @Actualinjsteps = COUNT(DISTINCT StepCompartment)
		FROM TCD.BatchProductData
		WHERE BatchId = @Batchid;
	IF NOT EXISTS
				 (SELECT 
						 *
					  FROM TCD.BatchParameters
					  WHERE ParameterId = 37
							AND batchid = @Batchid
							AND @Actualinjsteps > 0
				 )
		BEGIN
			IF ISNULL(@Actualinjsteps, 0) > 0
				INSERT INTO TCD.BatchParameters
				(
					   BatchId, 
					   EcolabWasherId, 
					   ParameterId, 
					   ParameterValue, 
					   PartitionOn
				)
					   SELECT 
							  @Batchid, 
							  @Ecolabwasherid, 
							  37, 
							  @Actualinjsteps, 
							  @Partitionon;
		END;
	ELSE
		BEGIN
			UPDATE TCD.BatchParameters
			  SET 
				  ParameterValue = @Actualinjsteps
				WHERE 
					  ParameterId = 37
					  AND batchid = @Batchid;
		END;
	SELECT 
		   @Mintempparamid = Id FROM TCD.ConduitParameters WHERE Name = 'Mimum Temperature';
	SELECT 
		   @Maxtempparamid = Id
		FROM TCD.ConduitParameters
		WHERE Name = 'Maximum Temperature';
	SELECT 
		   @Tempstatusparamid = Id
		FROM TCD.ConduitParameters
		WHERE Name = 'Temperature Status';
	SELECT 
		   @Phvalueparamid = ID FROM TCD.ConduitParameters WHERE Name = 'PH';
	SELECT 
		   @Phstatusparamid = ID FROM TCD.ConduitParameters WHERE Name = 'PH Status';
	SELECT 
		   @Conductivityvalueparamid = ID
		FROM TCD.ConduitParameters
		WHERE Name = 'Conductivity';
	SELECT 
		   @Conductivitystatusparamid = ID
		FROM TCD.ConduitParameters
		WHERE Name = 'LF Status';
	IF @Phvalue IS NOT NULL
		BEGIN
			--pH Value
			IF @Phvalue <> 0
			   OR @Phvalue <> NULL
				INSERT INTO TCD.BatchParameters
				(
					   BatchId, 
					   EcolabWasherId, 
					   ParameterId, 
					   ParameterValue, 
					   PartitionOn
				)
				VALUES
				(
					   @Batchid, 
					   @Ecolabwasherid, 
					   @Phvalueparamid, 
					   @Phvalue, 
					   @Partitionon
				);
		END;
	CREATE TABLE #TemperatureDetails
	(
		 MinimumTemp DECIMAL(10, 2), 
		 MaximumTemp DECIMAL(10, 2), 
		 TempStatus	 DECIMAL(10, 2)
	);
	INSERT INTO #TemperatureDetails
	(
		   MinimumTemp, 
		   MaximumTemp, 
		   TempStatus
	)
		   SELECT 
				  T.c.value('@Minimum', 'Decimal(10,2)') AS MinimumTemp, 
				  T.c.value('@Maximum', 'Decimal(10,2)') AS MaximumTemp, 
				  T.c.value('@Status', 'Decimal(10,2)') AS TempStatus
			   FROM @Xmltags.nodes('MyControlTunnel/TunnelData/TemperatureData') AS T(c);

	-- Fetching data from cursor
	DECLARE @Tempcursor CURSOR;
	SET @Tempcursor = CURSOR FAST_FORWARD
	FOR SELECT 
			   MinimumTemp, 
			   MaximumTemp, 
			   TempStatus FROM #TemperatureDetails;
	DECLARE @Minimumtemp DECIMAL(10, 2), 
			@Maximumtemp DECIMAL(10, 2), 
			@Tempstatus	 DECIMAL(10, 2);
	OPEN @Tempcursor;
	FETCH NEXT FROM @Tempcursor INTO @Minimumtemp, 
									 @Maximumtemp, 
									 @Tempstatus;
	WHILE @@Fetch_Status = 0
		BEGIN 
			--Minimum Temperature
			IF @Minimumtemp <> 0
			   OR @Minimumtemp <> NULL
				INSERT INTO TCD.BatchParameters
				(
					   BatchId, 
					   EcolabWasherId, 
					   ParameterId, 
					   ParameterValue, 
					   PartitionOn
				)
				VALUES
				(
					   @Batchid, 
					   @Ecolabwasherid, 
					   @Mintempparamid, 
					   @Minimumtemp, 
					   @Partitionon
				);
			--Maximum Temperature
			IF @Maximumtemp <> 0
			   OR @Maximumtemp <> NULL
				INSERT INTO TCD.BatchParameters
				(
					   BatchId, 
					   EcolabWasherId, 
					   ParameterId, 
					   ParameterValue, 
					   PartitionOn
				)
				VALUES
				(
					   @Batchid, 
					   @Ecolabwasherid, 
					   @Maxtempparamid, 
					   @Maximumtemp, 
					   @Partitionon
				);
			--Temperature Status
			IF @Tempstatus <> 0
			   OR @Tempstatus <> NULL
				INSERT INTO TCD.BatchParameters
				(
					   BatchId, 
					   EcolabWasherId, 
					   ParameterId, 
					   ParameterValue, 
					   PartitionOn
				)
				VALUES
				(
					   @Batchid, 
					   @Ecolabwasherid, 
					   @Tempstatusparamid, 
					   @Tempstatus, 
					   @Partitionon
				);
			FETCH NEXT FROM @Tempcursor INTO @Minimumtemp, 
											 @Maximumtemp, 
											 @Tempstatus;
		END;
	CLOSE @Tempcursor;
	DEALLOCATE @Tempcursor;
	DROP TABLE #TemperatureDetails;
	UPDATE TCD.BatchWashStepData
	  SET 
		  EndTime = DATEADD(ss,
								(SELECT 
										T.c.value('@Time', 'INT')
									 FROM @Tunnelxml.nodes('TunnelData/CompartmentTime') AS T(c)
									 WHERE T.c.value('@CompartmentNo', 'INT') =
																				(SELECT 
																						bwsd.StepCompartment
																					 FROM tcd.BatchWashStepData AS bwsd
																					 WHERE bwsd.BatchId = @Batchid
																						   AND bwsd.EndTime IS NULL
																				)
								),
								   (SELECT 
										   bwsd.StartTime
										FROM tcd.BatchWashStepData AS bwsd
										WHERE bwsd.BatchId = @Batchid
											  AND bwsd.EndTime IS NULL
								   ))
		WHERE 
			  BatchId = @Batchid
			  AND EndTime IS NULL;
END;