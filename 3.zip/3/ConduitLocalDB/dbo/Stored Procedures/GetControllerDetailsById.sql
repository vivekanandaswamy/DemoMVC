﻿CREATE PROCEDURE [TCD].[GetControllerDetailsById]
(
	@ControllerId INT
,	@EcolabAccountNumber NVARCHAR(25)
)
AS
BEGIN    
SET NOCOUNT ON
	SELECT 
			C.ControllerId
		,	C.ControllerModelId
		,	CM.Name ControllerModelName
		,	C.Name ControllerName
		,	C.ControllerNumber
		,	C.ControllerTypeId
		,	CT.Name AS ControllerType
		,	C.ControllerVersion
		,	C.InstallDate
		,	C.EcoalabAccountNumber
		,	C.LastModifiedTime
		,	C.LastSyncTime 
		,	C.IsDeleted
		 
	FROM 
	[TCD].ConduitController C
	INNER JOIN [TCD].ControllerModel CM ON CM.Id = C.ControllerModelId
	INNER JOIN [TCD].ControllerType CT ON CT.Id = C.ControllerTypeId
	WHERE 
	C.ControllerId = @ControllerId
	AND
	C.EcoalabAccountNumber = @EcolabAccountNumber
SET NOCOUNT OFF
END