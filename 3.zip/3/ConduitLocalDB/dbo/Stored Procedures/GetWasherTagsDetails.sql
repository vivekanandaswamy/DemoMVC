﻿CREATE PROCEDURE	[TCD].[GetWasherTagsDetails]
					@EcolabAccountNumber					NVARCHAR(25)
				,	@WasherId								INT					=			NULL
				,	@WasherTagId							INT					=			NULL
				,	@Active									BIT					=			NULL
AS
BEGIN

SET	NOCOUNT	ON


SELECT	
		WT.WasherTagId					AS			WasherTagId
	,	WT.TagType						AS			TagType
	,	WT.TagAddress					AS			TagAddress
	,	WT.Active						As			Active
FROM	TCD.WasherTags					WT
WHERE	WT.EcolabAccountNumber			=			@EcolabAccountNumber
	AND	WT.WasherId						=			ISNULL(@WasherId ,WT.WasherId)
	AND	WT.WasherTagId					=			ISNULL(@WasherTagId ,WT.WasherTagId)
	AND	WT.Active						=			ISNULL(@Active ,WT.Active)


RETURN	0


END
