﻿/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_GetFinnisherTypes]                                     

Purpose:				To get the finnisher types.

Parameters:				None
																																				
###################################################################################################                                           
*/ 
CREATE PROCEDURE [TCD].GetFinnisherTypes

AS
BEGIN
SET nocount ON;

Select FinnisherTypeId,Name from [TCD].FinnisherType where Is_Deleted <> 1

SET nocount OFF;
END
