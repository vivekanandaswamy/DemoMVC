﻿CREATE PROCEDURE [TCD].[FetchTargetProductionForSync]
	(
		@EcolabAccountNumber nvarchar(25)
	)
AS
BEGIN
	SET NOCOUNT ON;
	     SELECT 
			TPD.ID,
			TPD.ShiftId,
			TPD.DayId,
			TPD.RecordedDate,
			TPD.TargetProduction,
			TPD.EcolabAccountNumber,
			TPD.TargetProduction_Display,
			TPD.LastModifiedTime
		  FROM TCD.TARGETPRODUCTIONDETAILS TPD where EcolabAccountNumber = @EcolabAccountNumber
	SET NOCOUNT OFF;
END