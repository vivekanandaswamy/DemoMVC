﻿/*	                                   
###################################################################################################                                           
GetUsedChemicalName
Stored Procedure:       [TCD].[GetUsedChemicalName]                                             

Purpose:				To get Chemicals.

Parameters:				@EcoLabAccountNumber - holds ecolab account number.
						@ChemName - holds chemical names.
																
###################################################################################################                                           
*/

CREATE PROCEDURE [TCD].[GetUsedChemicalName]
    @ChemName Varchar(1000)
    ,@EcolabAccountNumber nvarchar(25)
    ,@WasherGroupId    INT = NULL
AS     

BEGIN     
    SET NOCOUNT ON    
    
    DECLARE @RegionId            INT =    NULL
        ,    @ControllerId        INT    =    NULL
        ,    @ControllerModelId    INT    =    NULL
        ,    @ControllerTypeId    INT    =    NULL
		,    @WasherDosingNumber  INT    =    NULL
		,	 @ControllerEquipmentId TINYINT = NULL
		,	 @ControllerEquipmentSetupId SMALLINT = NULL
    
    SELECT 
    @RegionId = RegionID FROM Plant 
    WHERE 
    EcolabAccountNumber = @EcolabAccountNumber
	SELECT @WasherDosingNumber = wg.WasherDosingNumber
           FROM TCD.WasherGroup wg
           WHERE wg.WasherGroupId = @WasherGroupId
             AND wg.EcolabAccountNumber = @EcolabAccountNumber

    SELECT @ControllerId =  wg.ControllerId FROM TCD.WasherGroup wg WHERE wg.WasherGroupId = @WasherGroupId AND wg.EcolabAccountNumber = @EcolabAccountNumber

    IF @ControllerId IS NULL OR @Controllerid = 0
    BEGIN
    IF @WasherGroupId IS NULL
    BEGIN
        SELECT 
		@ControllerEquipmentId,
		@ControllerEquipmentSetupId, 
        Map.ProductId, RTRIM(ISNULL(NULLIF(M.EnvisionDisplayName, ' '), M.Name)) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name
        , M.Cost
        , M.IncludeinCI
        , TCD.FnChemicalCostInOunce(Map.ProductId) AS        Price
    , 0
        FROM ProductMaster M
        INNER JOIN ProductdataMapping Map ON M.ProductId = Map.ProductId AND Map.Is_Deleted=0
        WHERE 
        (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
        AND M.RegionId = @RegionId
        AND M.Is_Deleted =0
    END
    ELSE
    BEGIN
        SELECT DISTINCT
		ces.ControllerEquipmentId,
		    ces.ControllerEquipmentSetupId,
        Map.ProductId, RTRIM(ISNULL(NULLIF(M.EnvisionDisplayName, ' '), M.Name)) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name
        , M.Cost
        , M.IncludeinCI
        , TCD.FnChemicalCostInOunce(Map.ProductId) AS        Price
   , CAST (ces.ControllerEquipmentTypeId AS int) AS ControllerEquipmentTypeId
        FROM TCD.ProductMaster M
        INNER JOIN TCD.ProductdataMapping Map ON M.ProductId = Map.ProductId AND Map.Is_Deleted=0
        LEFT JOIN TCD.ControllerEquipmentSetup ces ON ces.ProductId = Map.ProductId AND ces.EcoLabAccountNumber = Map.EcolabAccountNumber
        INNER JOIN TCD.MachineSetup ms ON ms.ControllerId = ces.ControllerId AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber AND ms.IsDeleted = 'False'
        INNER JOIN TCD.WasherGroup wg ON wg.WasherGroupId = ms.GroupId AND wg.EcolabAccountNumber = ms.EcoalabAccountNumber
        WHERE wg.WasherGroupId = ISNULL(@WasherGroupId, wg.WasherGroupId)
        AND (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
        AND M.RegionId = @RegionId
        AND M.Is_Deleted =0
        END
     END
    ELSE
    BEGIN
        SELECT @ControllerModelId = cc.ControllerModelId, @ControllerTypeId = cc.ControllerTypeId FROM TCD.ConduitController cc WHERE cc.ControllerId = @ControllerId

        IF @ControllerModelId = 11
        BEGIN
            SELECT 
			ces.ControllerEquipmentId,
		    ces.ControllerEquipmentSetupId,
            Map.ProductId, 
			RTRIM(ISNULL(NULLIF(M.EnvisionDisplayName, ' '), M.Name)) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name
            , M.Cost
            , M.IncludeinCI
		  , TCD.FnChemicalCostInOunce(Map.ProductId) AS        Price
            , CAST (ces.ControllerEquipmentTypeId AS int) AS ControllerEquipmentTypeId
            FROM ProductMaster M
            INNER JOIN ProductdataMapping Map ON M.ProductId = Map.ProductId AND Map.Is_Deleted=0  
            INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.EcoLabAccountNumber = Map.EcolabAccountNumber  AND ces.WasherGroupNumber=@WasherDosingNumber AND ces.ProductId = Map.ProductID
		  AND ces.ConventionalWasherGroupConnection = 1
            LEFT JOIN TCD.TunnelCompartmentEquipmentValveMapping tcevm ON ces.ControllerEquipmentSetupID = tcevm.ControllerEquipmentSetupID AND tcevm.DirectDosingFlag = 1
            WHERE 
            (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
            AND tcevm.ControllerEquipmentSetupID IS NULL
            AND M.RegionId = @RegionId
            AND M.Is_Deleted =0
            AND ces.ControllerId = @ControllerId
            AND ces.WasherGroupNumber =  CASE WHEN @ControllerTypeId = 13 THEN 1 ELSE ces.WasherGroupNumber END
    END
        ELSE
        BEGIN
            SELECT 
			CASE ces.ControllerEquipmentTypeId WHEN 2 THEN 
											   CASE @ControllerModelId WHEN 7 THEN CAST(ces.ControllerEquipmentId-24 AS tinyint) 
											   ELSE ces.ControllerEquipmentId END 
											   ELSE ces.ControllerEquipmentId END,
		    ces.ControllerEquipmentSetupId,
            Map.ProductId, 
			RTRIM(ISNULL(NULLIF(M.EnvisionDisplayName, ' '), M.Name)) + ' ( ' + RTRIM(Map.SKU) + ' )' as Name
    , M.Cost
    , M.IncludeinCI
    , TCD.FnChemicalCostInOunce(Map.ProductId) AS        Price
            , CAST (ces.ControllerEquipmentTypeId AS int) AS ControllerEquipmentTypeId
    FROM ProductMaster M
    INNER JOIN ProductdataMapping Map ON M.ProductId = Map.ProductId AND Map.Is_Deleted=0     
            INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.EcoLabAccountNumber = Map.EcolabAccountNumber AND ces.ProductId = Map.ProductID 
		  AND CASE WHEN @ControllerModelId IN (7, 10, 8) THEN ces.ConventionalWasherGroupConnection ELSE ISNULL(ces.ConventionalWasherGroupConnection, 0) END = CASE WHEN @ControllerModelId IN (7, 10, 8) THEN 1 ELSE 0 END
            LEFT JOIN TCD.TunnelCompartmentEquipmentValveMapping tcevm ON ces.ControllerEquipmentSetupID = tcevm.ControllerEquipmentSetupID AND tcevm.DirectDosingFlag = 1
    WHERE 
    (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
            AND tcevm.ControllerEquipmentSetupID IS NULL
    AND M.RegionId = @RegionId
    AND M.Is_Deleted =0
            AND ces.ControllerId = @ControllerId
        END
    END
        

    SET NOCOUNT OFF 
 
END