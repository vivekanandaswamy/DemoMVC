CREATE PROCEDURE [TCD].[SaveWasherFlushTime] (
      @WasherFlushTime TCD.WasherFlushTime READONLY 
    , @EcolabAccountNumber NVARCHAR(25)
    , @UserId INT)
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @CurrentUTC DATETIME = GETUTCDATE(),
			@PlantId INT = (SELECT P.PlantId 
							FROM TCD.Plant P 
							WHERE P.EcolabAccountNumber = @EcolabAccountNumber),
			@IsExistingRecord INT = (SELECT COUNT(*) FROM TCD.WasherFlushTime wft
														INNER JOIN @WasherFlushTime uwft
																	ON wft.WasherId = uwft.WasherId
																		AND wft.PlantId = (SELECT P.PlantId FROM TCD.Plant P WHERE P.EcolabAccountNumber = @EcolabAccountNumber)
																		AND wft.LineNumber = uwft.LineNumber
																		AND wft.WasherFlushTypeId = uwft.WasherFlushTypeId )

	IF @IsExistingRecord = 0
		BEGIN
			INSERT INTO TCD.WasherFlushTime
			(
				WasherId,
				PlantId,
				LineNumber,
				WasherFlushTypeId,
				FlushTime,
				LastModifiedByUserId,
				LastModifiedTime
			)
			SELECT uwft.WasherId,
					@PlantId,
					uwft.LineNumber,
					uwft.WasherFlushTypeId,
					uwft.FlushTime,
					@UserId,
					@CurrentUTC
			FROM @WasherFlushTime uwft 
			LEFT JOIN  TCD.WasherFlushTime as wft ON wft.WasherId = uwft.washerId AND wft.LineNumber = uwft.LineNumber AND wft.WasherFlushTypeId = uwft.WasherFlushTypeId AND wft.PlantId = @PlantId
			WHERE wft.washerId IS NULL 
		END

	ELSE
		BEGIN
			UPDATE wft
			SET
				wft.FlushTime = uwft.FlushTime, -- int
				wft.LastModifiedByUserId = @UserId,
				wft.LastModifiedTime = @CurrentUTC
			FROM @WasherFlushTime  uwft
			INNER JOIN TCD.WasherFlushTime wft
			ON wft.WasherId = uwft.WasherId
			AND wft.PlantId = @PlantId
			AND wft.LineNumber = uwft.LineNumber
			AND wft.WasherFlushTypeId = uwft.WasherFlushTypeId
			
		END	
			
END


