﻿CREATE PROCEDURE [TCD].[AddMeterReading](
	@ControllerID  INT,
	@WasherID      INT,
	@UtilityTypeID INT,
	@ReadingValue  DECIMAL(18, 4))
AS
	BEGIN
	    DECLARE @MeterID INT = NULL;
	    SELECT
			 @MeterID = MeterID
	    FROM TCD.METER
	    WHERE ControllerID = @ControllerID
			AND UtilityType = @UtilityTypeID
			AND MachineCompartment = @WasherID
			AND Is_deleted = 0;
	    IF(@MeterID IS NOT NULL)
		   BEGIN
		    IF NOT EXISTS
			  (
				 SELECT
				     Reading
			  FROM TCD.ModuleReading
			  WHERE ModuleID = @MeterID
				   AND ModuleTypeID = 2	   --Meter
			  )
				 BEGIN
					INSERT INTO TCD.ModuleReading
					(
						  ModuleId,
						  ModuleTypeId,
						  Reading,
						  TimeStamp
					)
					VALUES
					(
						  @MeterID,
						  2,		    --Meter
						  @ReadingValue,
						  GETUTCDATE()
					);
				 END;
		   END;
	END;