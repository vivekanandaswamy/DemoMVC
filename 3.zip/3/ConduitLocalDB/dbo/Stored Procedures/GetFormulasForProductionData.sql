﻿/*    
 ==========================================================================================    
 Purpose:  Fecthing the Formulas by group id    
  
 Author:  Neetha Allati  
  
 --------------------------------------------------------------    
 Sep-25-2014 ENT: Initial version.    
 ==========================================================================================    
*/   
CREATE PROCEDURE [TCD].[GetFormulasForProductionData]   
(  
        @WasherGroupId NVARCHAR(1000),  
        @EcolabAccountNumber nvarchar(25)  
 )  
AS   
  BEGIN  
  SET NOCOUNT ON  
  DECLARE @GroupID INT
  ,		  @ControllerID INT
  ,		  @ControllerModelID INT

	  SELECT @GroupID = ms.GroupId
			,@ControllerID = ms.ControllerId
		FROM tcd.Washer AS w
		INNER JOIN tcd.MachineSetup AS MS ON w.WasherId = ms.WasherId 
		WHERE  w.WasherId = @WasherGroupId

		SELECT @ControllerModelID = cc.ControllerModelId 
			FROM   TCD.ConduitController cc 
			WHERE  cc.ControllerId = @ControllerID 
             AND cc.EcoalabAccountNumber = @EcolabAccountNumber 

			  IF @ControllerModelID = 7 -- MyControl   
              BEGIN 
                  SET @GroupID = NULL 
              END 
	
        SELECT   
                    DISTINCT P.ProgramId,  
                    P.Name  
        FROM [TCD].WasherProgramSetup AS WP                  
                INNER JOIN [TCD].ProgramMaster AS P ON P.ProgramId = WP.ProgramId  
        WHERE ( CASE 
                           WHEN @GroupID IS NOT NULL THEN WP.WasherGroupId 
                           ELSE WP.ControllerID 
                         END ) = ( CASE 
                                     WHEN @GroupID IS NOT NULL THEN @GroupID 
                                     ELSE @ControllerID 
                                   END )    
                AND WP.EcolabAccountNumber = @EcolabAccountNumber   
                AND WP.IS_DELETED = 0   
                AND P.IS_DELETED = 0  

    UNION ALL  
     SELECT   
                    Distinct P.ProgramId,  
                    P.Name  
        FROM [TCD].TunnelProgramSetup  AS tps                  
                INNER JOIN [TCD].ProgramMaster AS P ON P.ProgramId = tps.ProgramId  
        WHERE tps.WasherGroupId = @GroupID                
                AND tps.EcolabAccountNumber = @EcolabAccountNumber   
                AND tps.IS_DELETED = 0   
                AND P.IS_DELETED = 0    
                    
SET NOCOUNT OFF  
END