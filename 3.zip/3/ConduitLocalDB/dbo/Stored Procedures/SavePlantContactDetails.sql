﻿/*

Stored Procedure	:	[TCD].[SavePlantContactDetails]

Purpose				:	To add/update plant contact details

Parameters			:	@Id										--	To be passed for updates
						@EcolabAccountNumber					--	EcoLab Plant Id
						@ContactFirstName						--	First name for the contact
						@ContactLastName						--	Last name for the contact
						@ContactTitle							--	Title for the contact
						@ContactPositionId						--	Position lookup Id
						@ContactEmail							--	E-mail for the contact
						@ContactOfficePhone						--	Office phone no. for the contact
						@ContactMobilePhone						--	Mobile phone no. for the contact
						@ContactFaxNumber						--	Fax no. for the contact
						@UserID									--	UserId of the user performing the Op.
						@OutputPlantContactId					--	Output param for passing back the Id of the newly inserted record
						@LastModifiedTimestampAtCentral			--	To be passed for updates from central, NULL for insert and local update
						@OutputLastModifiedTimestampAtLocal		--	Output param for passing back the latest modified time to the Synch. component
						@MyServiceContactGuid					--	Myservice Contact Guid
							
*/

CREATE	PROCEDURE	[TCD].[SavePlantContactDetails]	(
					@Id									NVARCHAR(100)		=			NULL
				,	@EcolabAccountNumber				NVARCHAR(25)		--=			NULL
				,	@ContactFirstName					NVARCHAR(1000)		--=			NULL
				,	@ContactLastName					NVARCHAR(1000)		=			NULL
				,	@ContactTitle						NVARCHAR(1000)		=			NULL
				,	@ContactPositionId					NVARCHAR(1000)		--=			NULL
				,	@ContactEmail						NVARCHAR(1000)		=			NULL
				,	@ContactOfficePhone					NVARCHAR(1000)		=			NULL
				,	@ContactMobilePhone					NVARCHAR(1000)		=			NULL
				,	@ContactFaxNumber					NVARCHAR(1000)		=			NULL
				,	@UserID								INT					--=			NULL
				--,	@Scope								VARCHAR(100)		=			''		OUTPUT
				,	@OutputPlantContactId				INT					=			NULL	OUTPUT
				,	@LastModifiedTimestampAtCentral		DATETIME			=			NULL
				,	@OutputLastModifiedTimestampAtLocal	DATETIME			=			NULL	OUTPUT
				,	@MyServiceContactGuid				UNIQUEIDENTIFIER	=			NULL	
				)   
AS   
BEGIN   

SET	NOCOUNT	ON

--DECLARE			@NewContactId			INT			=			NULL
DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()

DECLARE
		@OutputList						AS	TABLE		(
		PlantContactId					INT
	,	LastModifiedTimestamp			DATETIME
	)

SET		@OutputPlantContactId			=			ISNULL(@OutputPlantContactId, NULL)			--SQLEnlight SA0121
SET		@OutputLastModifiedTimestampAtLocal			=			ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight SA0121


IF	EXISTS	(	SELECT	1   
				FROM	[TCD].PlantContact	PC
				WHERE	PC.ID					=			@ID
					AND	PC.EcolabAccountNumber	=			@EcolabAccountNumber
					AND	PC.Is_Deleted			=			'FALSE'
			)
		BEGIN
			--If the call is not local, check that the LastModifiedTime matches with the central
			IF	(
					@LastModifiedTimestampAtCentral				IS NOT	NULL
				AND
				NOT	EXISTS	(	SELECT	1
								FROM	TCD.PlantContact		PC
								WHERE	PC.EcolabAccountNumber	=	@EcolabAccountNumber
									AND	PC.ID					=	@Id
									AND	PC.LastModifiedTime		=	@LastModifiedTimestampAtCentral
							)
				)
					BEGIN
							SET			@ErrorId				=	60000
							SET			@ErrorMessage			=	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
							RAISERROR	(@ErrorMessage, 16, 1)
							SET			@ReturnValue			=	-1
							RETURN		(@ReturnValue)
					END

			
		IF(@ContactEmail IS NOT NULL AND @ContactEmail <> N'')
			BEGIN
			IF EXISTS (SELECT 1 FROM [TCD].PlantContact WHERE ContactEmail=@ContactEmail AND Is_Deleted=0  AND ID <> @ID AND EcolabAccountNumber = @EcolabAccountNumber)
			 BEGIN
				SET @ErrorMessage ='303 - Email Address already exists.'
				RAISERROR(@ErrorMessage, 16, 1)
				RETURN
			 END
			 END


			--Proceed to update, since it's either a local call or Synch. call with synch. time matching
			/* Updating the value of plant details */   
			UPDATE	P
				SET	ContactFirstName				=			@ContactFirstName
				,   ContactLastName					=			@ContactLastName
				,	ContactTitle					=			@ContactTitle
				,	ContactPositionId				=			@ContactPositionId
				,	ContactEmail					=			@ContactEmail
				,	ContactOfficePhone				=			@ContactOfficePhone
				,	ContactMobilePhone				=			@ContactMobilePhone
				,	ContactFaxNumber				=			@ContactFaxNumber
				,	LastModifiedByUserId			=			@UserID
				,	LastModifiedTime				=			@CurrentUTCTime
				OUTPUT
					inserted.ID						AS			PlantContactId
				,	inserted.LastModifiedTime		AS			LastModifiedTimestamp
				INTO
					@OutputList	(
					PlantContactId
				,	LastModifiedTimestamp
				)
			FROM	[TCD].PlantContact				P   
			WHERE	P.ID							=			@ID   
        END   
ELSE
		BEGIN  

			IF(@ContactEmail IS NOT NULL AND @ContactEmail <> N'')
			BEGIN
			IF EXISTS (SELECT 1 FROM [TCD].PlantContact WHERE ContactEmail=@ContactEmail AND Is_Deleted=0)
			 BEGIN
				SET @ErrorMessage ='303 - Email Address already exists.'
				RAISERROR(@ErrorMessage, 16, 1)
				RETURN
			 END
			 END

			INSERT	INTO	[TCD].plantcontact	(
							EcolabAccountNumber
						,	ContactFirstName
						,	ContactLastName
						,	ContactTitle
						,	ContactPositionId
						,	ContactEMail
						,	ContactOfficePhone
						,	ContactMobilePhone
						,	ContactFaxNumber
						,	LastModifiedByUserId
						,	MyServiceCntctGuid
						,	LastModifiedTime
						)
					OUTPUT
						inserted.ID						AS			PlantContactId
					,	inserted.LastModifiedTime		AS			LastModifiedTimestamp
					INTO
						@OutputList	(
						PlantContactId
					,	LastModifiedTimestamp
					)
			VALUES      (
							@EcolabAccountNumber
						,   @ContactFirstName
						,	@ContactLastName
						,	@ContactTitle
						,	@ContactPositionId
						,	@ContactEmail
						,	@ContactOfficePhone
						,	@ContactMobilePhone
						,	@ContactFaxNumber
						,	@UserID
						,	@MyServiceContactGuid
						,	@CurrentUTCTime
						)
			
		END


SELECT	TOP 1	
		@OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp
	,	@OutputPlantContactId				=	O.PlantContactId
FROM	@OutputList							O


RETURN	(@ReturnValue)


END