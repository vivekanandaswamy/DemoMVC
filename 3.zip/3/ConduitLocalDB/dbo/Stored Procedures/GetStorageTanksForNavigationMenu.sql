CREATE PROCEDURE [TCD].GetStorageTanksForNavigationMenu
(
			@EcolabAccountNumber NVARCHAR(25) = NULL
)
AS
BEGIN
	
	SET NOCOUNT ON;

			SELECT TankId, TankName  
			FROM [TCD].TankSetup 
			WHERE ControllerId IS NOT NULL 
			AND ControllerId <> 0
			AND EcoalabAccountNumber = @EcolabAccountNumber
END
GO
