﻿/*	
Purpose					:	To get washer group(s) for the Washer Group Setup screen

History					:
Sept. 2014		dfozdar@allianceglobalservice.com		initial version
Oct. 2014		dfozdar@allianceglobalservice.com		Removing paging/sorting as per the decision taken...



*/
CREATE	PROCEDURE	[TCD].[GetWasherGroups]
					@EcoLabAccountNumber					NVARCHAR(25)
				,	@WasherGroupId							INT				--Null for LIST
				,   @IsDeleted								BIT				=   'FALSE'
AS
BEGIN

SET	NOCOUNT	ON
IF @Washergroupid = -1
BEGIN
	SET @Washergroupid = NULL
END

SELECT	
		WG.WasherGroupId			AS			WasherGroupId
	,	WG.WasherGroupNumber		AS			WasherGroupNumber
	,	WG.WasherGroupName			AS			WasherGroupName
	,	WG.WasherGroupTypeId		AS			WasherGroupTypeId
	,	WGT.WasherGroupTypeName		AS			WasherGroupTypeName
	,	COUNT(*)	OVER()			AS			TotalCount
	,	GT.LastModifiedTime			AS			LastModifiedTime
	,	GT.LastSyncTime				AS			LastSyncTime
	,	WG.EcolabAccountNumber
	,	GT.Is_Deleted				AS			IsDeleted
	,	GT.MyServiceCustMchGrpGuid  AS			MyServiceWasherGroupGuid
	,    WG.ControllerId            AS          ControllerId
	,    cc.ControllerModelId       AS          ControllerModelId
	,    cc.ControllerTypeId        AS          ControllerTypeId
	,	WG.WasherDosingNumber		AS			WasherDosingNumber
	,	WG.UseGroup1Formulas		AS			UseGroup1Formulas
	,	(SELECT COUNT(1) FROM TCD.MachineSetup ms WHERE ms.GroupId = WG.WasherGroupId AND EcoalabAccountNumber = @EcoLabAccountNumber AND ms.IsDeleted = 'False') AS WasherCount
FROM	[TCD].MachineGroup					GT
JOIN	[TCD].WasherGroup					WG
	ON	GT.Id						=			WG.WasherGroupId
	AND GT.EcolabAccountNumber		=			WG.EcolabAccountNumber
JOIN	[TCD].WasherGroupType				WGT
	ON	WG.WasherGroupTypeId		=			WGT.WasherGroupTypeId
LEFT JOIN TCD.ConduitController cc
	ON cc.ControllerId				=			WG.ControllerId
WHERE	GT.EcolabAccountNumber		=			@EcoLabAccountNumber
	AND	(GT.Is_Deleted				=			'FALSE' or GT.Is_Deleted				=			@IsDeleted)
	AND	WG.WasherGroupId			=			ISNULL(@WasherGroupId, WG.WasherGroupId)




SET	NOCOUNT	OFF

END