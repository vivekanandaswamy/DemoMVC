﻿
/*   
 ==========================================================================================  
 Purpose:  Save the Plant Details.   

 Author:  Premchand Yelavarthi   

 --------------------------------------------------------------   
 July-22-2014 ENT: Initial version.   
 ==========================================================================================  
*/ 

CREATE PROCEDURE [TCD].[FetchMenuSettingsByRole](@PassingRoledID VARCHAR(100) = 
NULL) 
AS 
SET NOCOUNT ON
  BEGIN 
      SELECT sectionid         AS [@SectionID], 
             sectionname       AS [@SectionName], 
             UM.sectioncode    AS [@SectionCode], 
             UM.sectiontype    AS [@SectionType], 
             UM.controllername AS [@ControllerName], 
             UM.viewname       AS [@ViewName], 
             UM.resourceclass  AS [@ResourceClass], 
             UM.resourcekey    AS [@ResourceKey], 
             CASE 
               WHEN UM.parentid IS NULL THEN NULL 
               ELSE (SELECT sectioncode 
                     FROM   [TCD].conduitmenu 
                     WHERE  sectionid = UM.parentid) 
             END               AS [@ParentSectionCode], 
             (SELECT USM.settingcode         AS [@SettingCode], 
                     USM.settingvalue        AS [@SettingValue], 
                     USM.userrole            AS [@UserRole], 
                     Isnull(USM.userid, -1)  AS [@UserId], 
                     Isnull(USM.tagid, -1)   AS [@TagId], 
                     Isnull(USM.tagtype, -1) AS [@TagType], 
                     USM.usageuicode         AS [@UsageUICode] 
              FROM   [TCD].[conduitmenurolemapping] USM 
              WHERE  UM.sectioncode = USM.sectioncode 
                     AND usm.userrole = mr.userrole 
              FOR xml path ('MenuSetting'), type) 
      FROM   [TCD].[conduitmenu] UM 
             LEFT OUTER JOIN [TCD].[conduitmenurolemapping] MR 
                          ON Um.sectioncode = mr.sectioncode 
      WHERE  parentid IS NULL 
              OR ( mr.userrole in ( select * from [TCD].[CharacterListToTable](@PassingRoledID,',')) ) order by mr.userrole
      FOR xml path ('MenuSection'), root ('MenuSections'), type; 
  END 