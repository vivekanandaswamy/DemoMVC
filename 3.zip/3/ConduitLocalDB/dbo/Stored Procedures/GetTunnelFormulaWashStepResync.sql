﻿CREATE PROCEDURE [TCD].[GetTunnelFormulaWashStepResync]
	@EcoLabAccountNumber					NVARCHAR(25)

				,	@ProgramSetupId							INT

				,	@DosingSetupId							INT				=	NULL			--Null for LIST

AS

BEGIN

SET	NOCOUNT	ON
		
		DECLARE @WaterInletDrain VARCHAR(30) = NULL
		SELECT @WaterInletDrain = NAME FROM [TCD].TunnelWaterInletDrainLookup TW WHERE TW.TunnelWaterInletDrainLookupId = 1 

		SELECT TDS.[ProgramNumber]

			  ,TDS.[GroupId]

			  ,TDS.[EcolabAccountNumber]

			  ,TDS.[StepTypeId]

			  ,TDS.[StepRunTime]

			  ,TDS.[CompartmentNumber]

			  ,TDS.[Temperature]

			  ,TDS.[TunnelDosingSetupId]

			  ,TDS.[WaterType]

			  ,TDS.[WaterLevel]

			  ,ISNULL(TWIDL.Name , @WaterInletDrain) AS WaterInletDrain

			  ,TDS.[Note]

			  ,TDS.[TunnelProgramSetupId]

		FROM 
		[TCD].TunnelDosingSetup TDS
		
		INNER JOIN [TCD].MachineSetup MS ON MS.GroupId = TDS.GroupId
		LEFT JOIN [TCD].TunnelCompartment TC ON TC.WasherId = MS.WasherId AND TC.CompartmentNumber = TDS.CompartmentNumber
		LEFT JOIN [TCD].TunnelWaterInletDrainLookup TWIDL ON TWIDL.TunnelWaterInletDrainLookupId = TC.WaterInletDrainId
		
		WHERE 

		TDS.EcolabAccountNumber = @EcoLabAccountNumber 

		AND TDS.TunnelProgramSetupId = @ProgramSetupId

		AND	TDS.TunnelDosingSetupId	=	ISNULL(@DosingSetupId, TDS.TunnelDosingSetupId)

		AND TDS.Is_Deleted = 0

		--AND MS.IsDeleted = 'FALSE'

		ORDER BY TDS.[CompartmentNumber]

SET	NOCOUNT	OFF

END