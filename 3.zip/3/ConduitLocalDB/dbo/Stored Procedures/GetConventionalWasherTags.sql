CREATE PROCEDURE [TCD].[GetConventionalWasherTags] 
					@EcolabAccountNumber			NVARCHAR(25)	=	NULL			
				 ,	@WasherId						INT

AS

BEGIN


SET	NOCOUNT	ON

SET			@EcolabAccountNumber			=			ISNULL(@EcolabAccountNumber, NULL)			--SQLEnlight SA0029


SELECT	CurrentFormula
	,	CurrentInjection
	,	CurrentOperationCounter
	,	[AutoWeightEntry(AWE)Formula]
	,	EOFSignal
	,	Mode
	,	FlushTime
	,	InjectionClass
	,	InjectionRatio
	,	OnHold
	,	[AutoWeightEntry(AWE)Active]
	,	HoldDelay
	,	RatioDosingActive
	,	RatioDosingPercentage
	,	[AutoWeightEntry(AWE)Weight]
FROM	(
			SELECT	TagAddress
				,	TagDescription					AS			TagDescn
			FROM	[TCD].WasherTags				WT
			JOIN	[TCD].TagType					TT
				ON	TT.TagType=wt.TagType 
			WHERE	WasherId						=			@WasherId
				AND	WT.Active						=			1

		)	D
PIVOT
(
  MAX(TagAddress)
	FOR		TagDescn
	in (	CurrentFormula
		,	CurrentInjection
		,	CurrentOperationCounter
		,	[AutoWeightEntry(AWE)Formula]
		,	EOFSignal
		,	Mode
		,	FlushTime
		,	InjectionClass
		,	InjectionRatio
		,	OnHold
		,	[AutoWeightEntry(AWE)Active]
		,	HoldDelay
		,	RatioDosingActive
		,	RatioDosingPercentage
		,	[AutoWeightEntry(AWE)Weight]
		)
)	PIV


END
