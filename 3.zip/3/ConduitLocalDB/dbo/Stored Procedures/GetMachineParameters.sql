﻿----Exec [TCD].[GetMachineParameters] 4
----Exec [TCD].[GetMachineParameters] 22

CREATE PROCEDURE [TCD].[GetMachineParameters](
									   @WasherId Int = NULL
								    ) 
AS 
  BEGIN 
      SET nocount ON; 
	    --DECLARE @WasherId Int = 1


	  DECLARE @IStunnel INT,@Ispress INT,@GroupId Int
	  SELECT @IStunnel = Istunnel,@Ispress = MS.HasPress,@GroupId = MS.GroupId FROM [TCD].machinesetup MS WHERE WasherId = @WasherId 
	  DECLARE @NoofComp Int = NULL,@Count int = 1

	   SELECT @NoOfcomp = NumberOfComp FROM [TCD].machinesetup 
		WHERE Groupid = @GroupId and IsTunnel = 1

	  CREATE TABLE #Get_Compartment (
	  Id INT,
	  GroupId INT,
	  MachineID INT,
	  CompartmentNumber VARCHAR(1000),
	  WasherId INT
	  )

	  IF(@Ispress = 1)
			 BEGIN
			 INSERT INTO #Get_Compartment(Id,GroupId,MachineID,CompartmentNumber,WasherId)
				SELECT @count - 1,@GroupId,@count - 1,'Press',@WasherId
			 END

	   WHILE(@count <=  @NoOfcomp) 
	   BEGIN
			 INSERT INTO #Get_Compartment(Id,GroupId,MachineID,CompartmentNumber,WasherId)
				SELECT @count + 0,@GroupId,@count,'Compartment'+ cast(@count as Varchar(1000))+'',@WasherId
			SET @count = @count + 1
	   End


	  CREATE TABLE #OUTPUT
					   (
						  parameterID INT,
						  ParameterName VARCHAR(1000),
						  GroupId  INT,
						  MappedCompartment INT,
						  WasherId Int,
						  MappingSensorID Int
					   )
	   INSERT INTO #output(ParameterID,ParameterName,GroupId,MappedCompartment,WasherId,MappingSensorID)
	   SELECT DISTINCT CP.Id,CP.Name,SE.GroupId,SE.MachineCompartment,@WasherId,ST.MappingSensorID
	   
				FROM [TCD].Sensor SE 
						 INNER JOIN 
					[TCD].SensorTypeMaster ST ON SE.SensorType = ST.ResourceId
						 INNER JOIN
					[TCD].ConduitParameters CP 
						 ON ST.MappingSensorId = CP.Id  WHERE SE.GroupID = @GroupID AND CP.IsTrending = 1
	  
	   INSERT INTO #output(ParameterID,ParameterName,GroupId,MappedCompartment,WasherId)
	   SELECT DISTINCT 
				    CP.Id,CP.Name,NULL AS GroupId,NULL AS MappedCompartment,@WasherId	
				    FROM		    
					[TCD].SensorTypeMaster ST 
						 RIGHT OUTER JOIN
					[TCD].ConduitParameters CP 
						 ON ST.MappingSensorId = CP.Id
					 WHERE CP.MandatoryCol = 0 AND CP.IsActive = 1 AND CP.Id NOT IN (SELECT O.MappingSensorID FROM #OUTPUT O) AND CP.IsTrending = 1
	    UNION ALL
	   SELECT DISTINCT 
				    CP.Id,CP.Name,NULL,NULL,@WasherId  
					FROM [TCD].ConduitParameters CP 
					 WHERE  CP.Id = 6 AND CP.IsTrending = 1
	   


	  IF(@IStunnel = 1)
	  BEGIN
		  WITH CTE (
				    ParameterId,
				    ParameterName,
				    GroupId,
				    MappedCompartment,
				    WasherId
				    )
		  AS
		  (
    			 SELECT 
				    ParameterID,
				    ParameterName,
				    GroupId,
				    MappedCompartment,WasherId
					   FROM #output 
			 UNION ALL
			 SELECT 
				    Id,
				    CompartmentNumber,
				    GroupId,
				    MachineID,WasherId
					   FROM #Get_Compartment
			 	    
			 )    
			 SELECT ParameterId,
				    ParameterName,
				    GroupId,
				    MappedCompartment,
				    WasherId FROM CTE CT 
	  END
	  ELSE
	  BEGIN
	  	    
			SELECT DISTINCT 
				    CP.Id AS ParameterId,CP.Name AS ParameterName,NULL AS GroupId,NULL AS MappedCompartment,@WasherId AS WasherId			    
					FROM [TCD].ConduitParameters CP 
					 WHERE  CP.IsActive = 1 AND CP.Id <> 6 AND CP.IsTrending = 1

	  END
	    DROP TABLE #OutPut
	    DROP TABLE #Get_Compartment
END