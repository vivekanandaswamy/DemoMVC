﻿CREATE PROCEDURE [TCD].[SaveMeterModuleTags] (
@MeterNumber NVARCHAR(100) = NULL
, @EcolabAccountNumber nvarchar(25) = NULL
, @ControllerID INT
, @DigitalInputNumber NVARCHAR(100) = NULL
, @UserID INT
, @Scope VARCHAR(100) OUTPUT
)
AS
BEGIN
    SET NOCOUNT ON;
	SET @Scope ='';
IF @ControllerID != -1
	   BEGIN
		  DECLARE
			  @NewMeterId INT
			  ,@TagType VARCHAR(50) = 'Tag_MPLC'
			  ,@ModuleTypeId INT = 2
			  ,@Result INT = NULL
			  ,@Type INT = 2
			  ,@AllowTagEdit BIT;
		  SELECT @AllowTagEdit = CASE
							WHEN COUNT(*) > 0 THEN 'TRUE'
							    ELSE 'FALSE'
							END
		    FROM TCD.UserMaster UM
			    INNER JOIN
			    TCD.UserInRole UIR ON UM.UserId = UIR.UserId
			    INNER JOIN
			    TCD.UserRoles UR ON UIR.RoleId = UR.RoleId
		    WHERE UM.UserId = @UserID
			 AND UR.LevelId >= 8;

			 IF @AllowTagEdit = 'TRUE'
				    BEGIN
					   IF @DigitalInputNumber IS NOT NULL AND @DigitalInputNumber <> ''
						  BEGIN
							 EXEC @Result = TCD.CheckDuplicateTag @DigitalInputNumber, @ControllerID, @MeterNumber, @Type;
						  END;
				    END;

				IF (@Result IS NULL OR @Result = 1)
				    BEGIN
						    IF (@AllowTagEdit = 'TRUE')
								BEGIN
								    IF @Result IS NOT NULL
									   BEGIN
										  SET @NewMeterId = SCOPE_IDENTITY();
										  INSERT INTO TCD.ModuleTags (EcolabAccountNumber,
																TagType,
																TagAddress,
																ModuleTypeId,
																ModuleID,
																DeadBand,
																Active)
										  VALUES(@EcolabAccountNumber,
											    @TagType,
											    @DigitalInputNumber,
											    @ModuleTypeId,
											    @MeterNumber,
											    20,
											    1);
									   END;
								END;
								END
				ELSE
					BEGIN

						SET @Scope = @Scope + '802,';
						select @Scope;
					END;
					
					END
END;