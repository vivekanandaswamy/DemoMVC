﻿ 
/*
Purpose					:	To Save Tunnel Analogue Control while saving tunnel Wash Step

--sp_helptext	'[TCD].[SaveTunnelAnalogueControl]'

*/

CREATE PROCEDURE [TCD].[SaveTunnelAnalogueControl]
	@EcolabAccountNumber NVARCHAR(25),
	@TunnelProgramSetupId INT,	
	@TempSetPoint FLOAT,
	@MinTime INT,
	@StartDelay INT,
	@AcceptDelay INT,
	@CompartmentNumber INT,
	@ProductCheck BIT= NULL,
	@PhRegLevel INT = NULL,
	@MonLevel INT = NULL,
	@ConRegLevel INT = NULL,
	@pHMin FLOAT,
	@pHMax FLOAT,
	@pHStartDelay INT = NULL,
	@pHMeasTime INT	 = NULL,
	@ConductivityMin FLOAT,
	@ConductivityMax FLOAT,
	@ConductivityDelayTime INT = NULL,
	@ConductivityMeasTime INT = NULL 
AS
BEGIN

	DECLARE @PlantId INT = ( SELECT p.PlantId FROM TCD.PLANT p WHERE p.EcolabAccountNumber = @EcolabAccountNumber);

	IF EXISTS (SELECT * FROM TCD.TunnelTempSetup tts WHERE tts.TunnelProgramSetupId = @TunnelProgramSetupId AND tts.PlantId = @PlantId AND CompartmentNumber = @CompartmentNumber)
		BEGIN
			UPDATE TCD.TunnelTempSetup
				SET		    
					TCD.TunnelTempSetup.DesiredTemperature = @TempSetPoint,
					TCD.TunnelTempSetup.MinTime = @MinTime, 
					TCD.TunnelTempSetup.StartDelay = @StartDelay,
					TCD.TunnelTempSetup.AcceptDelay = @AcceptDelay,					
					TCD.TunnelTempSetup.ProductCheck = @ProductCheck
				WHERE TunnelProgramSetupId = @TunnelProgramSetupId AND PlantId = @PlantId AND CompartmentNumber = @CompartmentNumber		
		END
	ELSE 
		BEGIN		
			INSERT INTO TCD.TunnelTempSetup
			(
				TunnelProgramSetupId,					    
				DesiredTemperature,
				MinTime,
				StartDelay,
				AcceptDelay,
				CompartmentNumber,
				ProductCheck ,
				PlantId
			)
			VALUES
			(
				@TunnelProgramSetupId, 				
				@TempSetPoint, 
				@MinTime, 
				@StartDelay, 
				@AcceptDelay, 
				@CompartmentNumber,
				@ProductCheck,
				@PlantId	    
			)
		END

		IF EXISTS (select 1 from TCD.TunnelConductivitySetup TC where TC.TunnelProgramSetupId = @TunnelProgramSetupId AND TC.CompartmentNumber = @CompartmentNumber AND TC.EcolabAccountNumber = @EcolabAccountNumber)
		BEGIN
			UPDATE TCD.TunnelConductivitySetup 
			SET
				ConductivityRegulationLevel = @ConRegLevel,
				ConductivityMininum= @ConductivityMin,
				ConductivityMaximum = @ConductivityMax,
				ConductivityDelayTime = @ConductivityDelayTime,
				ConductivityMeasuringTime = @ConductivityMeasTime
				WHERE TunnelProgramSetupId = @TunnelProgramSetupId AND EcolabAccountNumber = @EcolabAccountNumber AND CompartmentNumber = @CompartmentNumber
		END 
		ELSE
		BEGIN
			INSERT INTO TCD.TunnelConductivitySetup
			(
				TunnelProgramSetupId,
				ConductivityRegulationLevel,
				ConductivityMininum,
				ConductivityMaximum,
				ConductivityDelayTime,
				ConductivityMeasuringTime,
				CompartmentNumber,
				EcolabAccountNumber
			) 
			VALUES 
			(
				@TunnelProgramSetupId,
				@ConRegLevel,
				@ConductivityMin,
				@ConductivityMax,
				@ConductivityDelayTime,
				@ConductivityMeasTime,
				@CompartmentNumber,
				@EcolabAccountNumber
			)
		END

	IF EXISTS (SELECT 1 FROM TCD.TunnelPhSetup tds WHERE tds.TunnelProgramSetupId = @TunnelProgramSetupId AND tds.CompartmentNumber = @CompartmentNumber AND tds.EcolabAccountNumber = @EcolabAccountNumber)
			BEGIN
				UPDATE TCD.TunnelPhSetup
				SET		    
					TCD.TunnelPhSetup.pHRegulationLevel = @PhRegLevel,
					TCD.TunnelPhSetup.pHMonitoringLevel = @MonLevel,
					TCD.TunnelPhSetup.pHMinimum = @pHMin,
					TCD.TunnelPhSetup.pHMaximum = @pHMax, 
					TCD.TunnelPhSetup.DelayTime = @pHStartDelay,
					TCD.TunnelPhSetup.MeasuringTime = @pHMeasTime			
				WHERE TunnelProgramSetupId = @TunnelProgramSetupId AND EcolabAccountNumber = @EcolabAccountNumber AND CompartmentNumber = @CompartmentNumber
			END
		ELSE
			BEGIN
				INSERT INTO TCD.TunnelPhSetup 
				(
					TunnelProgramSetupId,
					EcolabAccountNumber,
					CompartmentNumber,
					pHRegulationLevel,
					pHMonitoringLevel,
					pHMinimum,
					pHMaximum,
					DelayTime,
					MeasuringTime
				) 
				VALUES 
				(
					@TunnelProgramSetupId,
					@EcolabAccountNumber,
					@CompartmentNumber,
					@PhRegLevel,
					@MonLevel,
					@pHMin,
					@pHMax,
					@pHStartDelay,
					@pHMeasTime
				)
		END
END;