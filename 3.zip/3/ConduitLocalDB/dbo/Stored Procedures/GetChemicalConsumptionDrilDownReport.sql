--exec [TCD].[GetChemicalConsumptionDrilDownReport] @Corporate=N'',@Country=N'',@Region=N'',@EcolabAccountNumber=N'',@Machine=N'',@machineGroup=N'',@Formula=N'',@MachineType=N'',
--@Category=N'',@FromDate='2014-01-01 00:00:00',@ToDate='2015-01-04 00:00:00',@GroupId=N'',@MachineInternalId=N'',@ProductId = 9904,
--@DayWise=0,@WeekWise=0,@MonthWise=1,@QuarterWise=0,@YearWise=0,@Date = '',@SortColumnID = 0,@SortDirection = 'Desc',@UserId = 0,@ReportID = 5,@IsDrillDown = 0


CREATE PROCEDURE [TCD].[GetChemicalConsumptionDrilDownReport] (
												    @Corporate VARCHAR(MAX) = '',
												    @Country VARCHAR(MAX) = '',
												    @Region VARCHAR(MAX) = '',
												    @EcolabAccountNumber NVARCHAR(25) = '',
												    @Machine VARCHAR(MAX) = '', 
												    @MachineGroup VARCHAR(MAX) = '',
												    @Formula VARCHAR(MAX) = '',
												    @MachineType VARCHAR(20)= '',
												    @Category VARCHAR(MAX) = '',
												    @FromDate DATE = '',
												    @ToDate DATE = '',
												    @GroupId VARCHAR(MAX) = '',
												    @MachineInternalId VARCHAR(MAX) = '',
												    @ProductId INT = NULL,
												    @DayWise bit = NULL,
												    @WeekWise bit = NULL,
												    @MonthWise bit = NULL,
												    @QuarterWise bit = NULL,
												    @YearWise bit = NULL,
												    @Date DATE = NULL,
												    @SortColumnID INT = NULL,
												    @SortDirection Varchar(100) = '',
												    @UserId Int = NULL,
												    @ReportID INT = NULL,
												    @IsDrillDown BIT
												)

AS   
BEGIN   
SET NOCOUNT ON;
DECLARE @Month INT = MONTH(GETDATE()),
	   @SummationInMin Int = NULL,
	   @summingActualLoad Decimal(10,2) = NULL,
	   @SQLStatement varchar(max),
	    @SortField Varchar(100) = ''

 SELECT @SortField =  CASE WHEN @SortColumnID = 16 THEN 'AverageConsumption'
						    WHEN @SortColumnID = 17 THEN 'AverageDailyConsumption'
						    WHEN @SortColumnID = 47 THEN 'Chemical'
						    WHEN @SortColumnID = 54 THEN 'ActualConsumptionPerLoad'
						    WHEN @SortColumnID = 56 THEN 'Cost'						
						    WHEN @SortColumnID = 57 THEN 'CostExcess'
						    WHEN @SortColumnID = 58 THEN 'CostPerLoad'
						    WHEN @SortColumnID = 176 THEN 'TargetConsumptionPerLoad'
						    WHEN @SortColumnID = 177 THEN 'TargetConsumption'
						    WHEN @SortColumnID = 198 THEN 'TotalConsumption'
						    WHEN @SortColumnID = 242 THEN 'DateRange'
						    WHEN @SortColumnID = 0 THEN 'TotalConsumption'
					 END

DECLARE @CategoryTable TABLE(Category Varchar(100))
INSERT INTO @CategoryTable(Category) EXEC [TCD].[CharlistToTable] @Category,','

DECLARE @MachineTable TABLE(Machine Varchar(100))
INSERT INTO @MachineTable(Machine) EXEC [TCD].[CharlistToTable] @Machine,','

DECLARE @GroupMachineTable TABLE(GroupId INT,MachineInternalId INT)  
INSERT INTO @GroupMachineTable(GroupId,MachineInternalId) 
SELECT GroupId,MachineInternalId FROM TCD.MachineSetup MS 
									INNER JOIN TCD.Washer WS ON MS.WasherId = WS.WasherId WHERE WS.PlantWasherNumber IN (SELECT Machine FROM @MachineTable);

DECLARE @GroupTable TABLE(GroupId Varchar(100))
INSERT INTO @GroupTable(GroupId) EXEC [TCD].[CharlistToTable] @GroupId,','

DECLARE @MachineInternalTable TABLE(MachineInternalId Varchar(100))
INSERT INTO @MachineInternalTable(MachineInternalId) EXEC [TCD].[CharlistToTable] @MachineInternalId,','

DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))
INSERT INTO @WasherGroupTable(MachineGroup) EXEC [TCD].[CharlistToTable] @machineGroup,','

DECLARE @FormulaTable TABLE(Formula Varchar(100))
INSERT INTO @FormulaTable(Formula) EXEC [TCD].[CharlistToTable] @Formula,','

--DECLARE @CustomerTable TABLE(Customer Varchar(100))
--INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','

DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))
INSERT INTO @MachineTypeTable(MachineType) EXEC [TCD].[CharlistToTable] @MachineType,','

			  /* Including the Latest Batch Data */

	   					   IF((CAST(@ToDate AS DATE) = CAST(GETUTCDATE() AS date)) AND @DayWise <> 1)
								BEGIN				     

								 EXEC [TCD].[ChemicalConsumptionDataRollUp] @ToDate

								 END

				    /* Ending the Latest Batch Data Logic */

DECLARE @ChemicalConsumptionTable TABLE(
								 [RecordDate] [date] NULL,
								 [BatchId] [int] NULL,
								 [ActualWeight] [decimal](18, 2) NULL,
								 [StandardWeight] [decimal](18, 2) NULL,
								 [MachineId] INT NULL,
								 [GroupId] [int] NULL,
								 [MachineInternalId] [int] NULL,
								 [ProgramNumber] [int] NULL,
								 [ProductId] [int] NULL,
								 [TotalConsumption] [decimal](18, 2) NULL,
								 [TargetConsumption] [decimal](18, 2) NULL,
								 [Cost] [decimal](18, 2) NULL,
								 [CostPerLoad] [decimal](18, 2) NULL,
								 [CostExcess] [decimal](18, 2) NULL,
								 [EcolabTextileCategoryName] [varchar](50) NULL,
								 [EcolabTextileId] [int] NULL,
								 [PlantTextileCategoryName] [varchar](50) NULL,
								 [PlantTextileId] [int] NULL

							    )



	INSERT INTO @ChemicalConsumptionTable(
								 [RecordDate],
								 [BatchId],
								 [ActualWeight] ,
								 [StandardWeight],
								 [MachineId],
								 [GroupId],
								 [MachineInternalId],
								 [ProgramNumber],
								 [ProductId],
								 [TotalConsumption],
								 [TargetConsumption],
								 [Cost],
								 [CostPerLoad],
								 [CostExcess],
								 [EcolabTextileCategoryName],
								 [EcolabTextileId],
								 [PlantTextileCategoryName],
								 [PlantTextileId]
							    )

	SELECT   [RecordDate]
		    ,[BatchId]
		    ,[ActualWeight]
		    ,[StandardWeight]
		    ,MachineId
		    ,[GroupId]
		    ,[MachineInternalId]
		    ,[ProgramNumber]
		    ,[ProductId]
		    ,[TotalConsumption]
		    ,[TargetConsumption]
		    ,[Cost]
		    ,[CostPerLoad]
		    ,[CostExcess]
		    ,[EcolabTextileCategoryName]
		    ,[EcolabTextileId]
		    ,[PlantTextileCategoryName]
		    ,[PlantTextileId]
	   FROM [TCD].[ChemicalConsumptionRollUp] CCR

	WHERE 
		--CASE @Customer
		-- WHEN '' THEN 'TRUE'
		-- ELSE
		--  CASE WHEN CCR.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                      
		--END='TRUE' 
		--AND
		CASE @Machine   
				 WHEN '' THEN 'TRUE'         
				 ELSE                                                      
				  CASE WHEN CCR.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
				END='TRUE' 
		AND       
		CASE @MachineGroup   
			WHEN '' THEN 'TRUE'  
			ELSE             
			CASE WHEN CCR.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable) THEN 'TRUE' END  
		END='TRUE' 
		AND    
		CASE @Formula   
			WHEN '' THEN 'TRUE' 
			ELSE             
			CASE WHEN CCR.ProgramNumber IN (SELECT Formula FROM @FormulaTable) THEN 'TRUE' END  
		END='TRUE' 
		AND       
		CASE @MachineType   
			WHEN '' THEN 'TRUE'   
			ELSE                
			CASE WHEN CCR.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable)) THEN 'TRUE' END                                                      

		END='TRUE' 
		AND       
		CASE @FromDate    
			WHEN '' THEN Case WHEN MONTH(CCR.RecordDate) = @Month Then  'TRUE' END 
			ELSE CASE WHEN CCR.RecordDate >= @FromDate and CCR.RecordDate<dateadd(dd,1,@ToDate) THEN 'TRUE'END   
			END='TRUE'
			AND
			CASE @Category  
			WHEN '' THEN 'TRUE'  
			ELSE              
			CASE WHEN CCR.EcolabTextileId IN (SELECT Category FROM @CategoryTable) THEN 'TRUE' END  
		END='TRUE' 
		AND
			CASE @GroupId 
			WHEN '' THEN 'TRUE' 
			ELSE        
		CASE WHEN (CCR.GroupId IN (@GroupId) AND 
			CCR.MachineInternalId IN (@MachineInternalId)) THEN 'TRUE' END  
		END='TRUE' 
		AND
			CASE @MachineInternalId 
			WHEN '' THEN 'TRUE' 
			ELSE    
		CASE WHEN (CCR.GroupId IN (@GroupId) AND 
			CCR.MachineInternalId IN (@MachineInternalId)) THEN 'TRUE' END   
		END='TRUE' 

		/* Including the latest data from batch tables */
		/*
				IF(CAST(@FromDate AS DATE) = CAST(GETDATE() AS date) AND @DayWise <> 1)
				    BEGIN
				   
					 EXEC [TCD].[BatchChemicalLatestData] @Corporate,@Country,@Region,@EcolabAccountNumber,@Machine,@machineGroup,@Formula,
												     @MachineType,@Category,@FromDate,@ToDate,@GroupId,@MachineInternalId,@FromDate
				
				INSERT INTO @ChemicalConsumptionTable
				 SELECT 
						  CCR.RecordDate,
						  CCR.ProductId,
						  PM.Name AS Chemical,
						  CCR.TotalConsumption,
						  CCR.TargetConsumption,
						  CCR.AverageConsumption,
						  CCR.ActualConsumptionPerLoad,
						  CCR.TargetConsumptionPerLoad,
						  CCR.Cost,
						  CCR.CostPerLoad,
						  CCR.CostExcess,
						  CCR.NoOfBatches,
						  CCR.GroupId,
						  CCR.MachineInternalId,
						  CCR.ProgramNumber,
						  CCR.EcolabTextileId 
				 FROM #ChemicalConsumptionRollUpData CCR
				 INNER JOIN TCD.ProductMaster PM ON PM.ProductId = CCR.ProductId   

				 DROP TABLE #ChemicalConsumptionRollUpData

				 END
				 */
				    /* End of production latest batch data */



     IF(@DayWise = 1)

		  BEGIN		   

			 EXEC [TCD].[ChemicalShiftReport] @Corporate,@Country,@Region,@EcolabAccountNumber,@Machine,
			 @machineGroup,@Formula,@MachineType,@Category,@FromDate,
			 @ToDate,@GroupId,@MachineInternalId,@Date,@ProductId,@SortColumnID,@SortDirection,@ReportID,@IsDrillDown

		  END

	IF(@WeekWise = 1)
		  BEGIN
				SELECT 
					 0 as ProductId,
					 CAST(RecordDate AS nvarchar(100)) As DateRange
					,SUM(TotalConsumption) AS TotalConsumption
					,SUM(TargetConsumption) AS TargetConsumption
					--,SUM(AverageConsumption) AS AverageConsumption
					,CAST(SUM(CCR.TotalConsumption)/COUNT(DISTINCT CCR.ProgramNumber) AS decimal(18,2)) AS AverageConsumption,
				    CAST(SUM(CCR.TotalConsumption)/COUNT(DISTINCT CCR.RecordDate) AS decimal(18,2)) AverageDailyConsumption,
				    CAST(SUM(CCR.TotalConsumption)/COUNT(CCR.BatchId) AS decimal(18,2)) AS ActualConsumptionPerLoad,
				    CAST(SUM(CCR.TargetConsumption)/COUNT(CCR.BatchId) AS decimal(18,2)) AS TargetConsumptionPerLoad,
				    SUM(CCR.Cost) AS Cost,
				    CAST(SUM(CCR.Cost)/COUNT(CCR.BatchId) AS decimal(18,2)) AS CostPerLoad,
				    CAST((CASE WHEN (SUM(CCR.TotalConsumption) - SUM(CCR.TargetConsumption) < 0) THEN 0 ELSE ABS(SUM(CCR.TotalConsumption) - SUM(CCR.TargetConsumption))*SUM(CCR.Cost) END) AS decimal(18,2)) AS CostExcess,
					@IsDrillDown AS IsDrillDown,
					COUNT(CCR.BatchId) AS NoOfBatches,
				    COUNT( DISTINCT CCR.ProgramNumber) AS NoOfPrograms,
				    COUNT(DISTINCT CCR.RecordDate) NoOfDays
					
					INTO #ProdTableDayOrder
					FROM @ChemicalConsumptionTable CCR
					WHERE CCR.ProductId = @ProductId
					GROUP BY DATEPART(weekday,RecordDate),RecordDate

					SET @SQLStatement 
					   ='SELECT * FROM #ProdTableDayOrder ORDER BY ' + @SortField + ' ' + @SortDirection

	   			    EXEC(@SQLStatement)									

		  END  

		  

	   IF(@MonthWise = 1)

		  BEGIN 



		  DECLARE @FirstDay date = (SELECT TOP 1 RecordDate FROM @ChemicalConsumptionTable ORDER BY RecordDate)

		  DECLARE @LastDay date = (SELECT TOP 1 RecordDate FROM @ChemicalConsumptionTable ORDER BY RecordDate DESC)

		  DECLARE @FirstSunday date = NULL,

				@LastSaturday date = NULL



		  

		  SELECT 

				@FirstSunday = CAST(DateAdd(dd, (8-DatePart(WEEKDAY, 

							DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)))%7, 

							DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)) AS DATE) 



		   SELECT

				  @LastSaturday = 

								DATEADD(dd,

									   -DATEPART(WEEKDAY,

											   DATEADD(dd, -DAY(DATEADD(month, 1, @LastDay)),

													 DATEADD(month, 1, @LastDay))) ,

									   DATEADD(dd, -DAY(DATEADD(MONTH, 1, @LastDay)), DATEADD(MONTH, 1, @LastDay)));

				

				WITH CTE(ProductId,DateRange,TotalConsumption,TargetConsumption,AverageConsumption,AverageDailyConsumption,

				ActualConsumptionPerLoad,TargetConsumptionPerLoad,Cost,CostPerLoad,CostExcess,NoOfBatches,NoOfPrograms,NoOfDays)

				AS

				(

				SELECT 
							0 as ProductId,

							CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,-1,@FirstSunday)) = 7 

							AND (SELECT COUNT(1) FROM @ChemicalConsumptionTable WHERE RecordDate < DATEADD(DD,-1,@FirstSunday)) = 0)

							THEN CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100))

							WHEN DATEADD(DD,-1,@FirstSunday) > CAST(GETDATE() AS DATE) 

							THEN

							CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @ToDate, 101) AS nvarchar(100))

							ELSE

							CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) END As DateRange

						   ,SUM(TotalConsumption) AS TotalConsumption
					,SUM(TargetConsumption) AS TargetConsumption
					--,SUM(AverageConsumption) AS AverageConsumption
					,CAST(SUM(CCR.TotalConsumption)/COUNT(DISTINCT CCR.ProgramNumber) AS decimal(18,2)) AS AverageConsumption,
				    CAST(SUM(CCR.TotalConsumption)/COUNT(DISTINCT CCR.RecordDate) AS decimal(18,2)) AverageDailyConsumption,
				    CAST(SUM(CCR.TotalConsumption)/COUNT(CCR.BatchId) AS decimal(18,2)) AS ActualConsumptionPerLoad,
				    CAST(SUM(CCR.TargetConsumption)/COUNT(CCR.BatchId) AS decimal(18,2)) AS TargetConsumptionPerLoad,
				    SUM(CCR.Cost) AS Cost,
				    CAST(SUM(CCR.Cost)/COUNT(CCR.BatchId) AS decimal(18,2)) AS CostPerLoad,
				    CAST((CASE WHEN (SUM(CCR.TotalConsumption) - SUM(CCR.TargetConsumption) < 0) THEN 0 ELSE ABS(SUM(CCR.TotalConsumption) - SUM(CCR.TargetConsumption))*SUM(CCR.Cost) END) AS decimal(18,2)) AS CostExcess,
					COUNT(CCR.BatchId) AS NoOfBatches,
				    COUNT(DISTINCT CCR.ProgramNumber) AS NoOfPrograms,
				    COUNT(DISTINCT CCR.RecordDate) NoOfDays

											FROM @ChemicalConsumptionTable CCR

					   WHERE RecordDate < @FirstSunday AND RecordDate >= @FirstDay AND CCR.ProductId = @ProductId



					   

					   UNION ALL



		

					   SELECT 

						  --CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100)) AS StartDate,

						  --CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) AS EndDate,
						  0 as ProductId,

						 CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100))  + CHAR(13) + '-' +
						   CASE WHEN CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) >
						   CAST(Convert(varchar, DateAdd(dd, (1 - DatePart(dw, @Todate) + 1), @Todate), 101) AS nvarchar(100))
						   THEN  CAST(Convert(varchar, DateAdd(dd, 1-1, @Todate), 101) AS nvarchar(100))
						   ELSE CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) END
						   As DateRange,

							 	   SUM(TotalConsumption) AS TotalConsumption
					,SUM(TargetConsumption) AS TargetConsumption
					--,SUM(AverageConsumption) AS AverageConsumption
					,CAST(SUM(CCR.TotalConsumption)/COUNT(DISTINCT CCR.ProgramNumber) AS decimal(18,2)) AS AverageConsumption,
				    CAST(SUM(CCR.TotalConsumption)/COUNT(DISTINCT CCR.RecordDate) AS decimal(18,2)) AverageDailyConsumption,
				    CAST(SUM(CCR.TotalConsumption)/COUNT(CCR.BatchId) AS decimal(18,2)) AS ActualConsumptionPerLoad,
				    CAST(SUM(CCR.TargetConsumption)/COUNT(CCR.BatchId) AS decimal(18,2)) AS TargetConsumptionPerLoad,
				    SUM(CCR.Cost) AS Cost,
				    CAST(SUM(CCR.Cost)/COUNT(CCR.BatchId) AS decimal(18,2)) AS CostPerLoad,
				    CAST((CASE WHEN (SUM(CCR.TotalConsumption) - SUM(CCR.TargetConsumption) < 0) THEN 0 ELSE ABS(SUM(CCR.TotalConsumption) - SUM(CCR.TargetConsumption))*SUM(CCR.Cost) END) AS decimal(18,2)) AS CostExcess,
					COUNT(CCR.BatchId) AS NoOfBatches,
				    COUNT(DISTINCT CCR.ProgramNumber) AS NoOfPrograms,
				    COUNT(DISTINCT CCR.RecordDate) NoOfDays



					   FROM @ChemicalConsumptionTable CCR 

				       WHERE RecordDate BETWEEN @FirstSunday AND @LastSaturday AND CCR.ProductId = @ProductId

					   GROUP BY Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101),

							  Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101)

					  

					  UNION ALL



					   SELECT 
							 0 as ProductId,
							 CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,1,@LastSaturday)) = 1 
							 AND (SELECT COUNT(1) FROM @ChemicalConsumptionTable WHERE RecordDate > DATEADD(DD,1,@LastSaturday)) = 0)
							 THEN 
							 CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) 

							 ELSE
							CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @LastDay, 101) AS nvarchar(100)) END   As DateRange

						    ,SUM(TotalConsumption) AS TotalConsumption
						   ,SUM(TargetConsumption) AS TargetConsumption
						   --,SUM(AverageConsumption) AS AverageConsumption
						   ,CAST(SUM(CCR.TotalConsumption)/COUNT(DISTINCT CCR.ProgramNumber) AS decimal(18,2)) AS AverageConsumption,
						  CAST(SUM(CCR.TotalConsumption)/COUNT(DISTINCT CCR.RecordDate) AS decimal(18,2)) AverageDailyConsumption,
						  CAST(SUM(CCR.TotalConsumption)/COUNT(CCR.BatchId) AS decimal(18,2)) AS ActualConsumptionPerLoad,
						  CAST(SUM(CCR.TargetConsumption)/COUNT(CCR.BatchId) AS decimal(18,2)) AS TargetConsumptionPerLoad,
						  SUM(CCR.Cost) AS Cost,
						  CAST(SUM(CCR.Cost)/COUNT(CCR.BatchId) AS decimal(18,2)) AS CostPerLoad,
						  CAST((CASE WHEN (SUM(CCR.TotalConsumption) - SUM(CCR.TargetConsumption) < 0) THEN 0 ELSE ABS(SUM(CCR.TotalConsumption) - SUM(CCR.TargetConsumption))*SUM(CCR.Cost) END) AS decimal(18,2)) AS CostExcess,
						   COUNT(CCR.BatchId) AS NoOfBatches,
						  COUNT(DISTINCT CCR.ProgramNumber) AS NoOfPrograms,
						  COUNT(DISTINCT CCR.RecordDate) NoOfDays

					   FROM @ChemicalConsumptionTable CCR

					   WHERE RecordDate > @LastSaturday AND RecordDate <= @LastDay AND CCR.ProductId = @ProductId

					   )

					   SELECT		
							0 as ProductId,

							   DateRange,

							   TotalConsumption,

							   TargetConsumption,

							   AverageConsumption,

							   AverageDailyConsumption

							  ,ActualConsumptionPerLoad

							  ,TargetConsumptionPerLoad

							  ,Cost

							  ,CostPerLoad

							  ,CostExcess
							  ,@IsDrillDown AS IsDrillDown
							  ,NoOfBatches
							  ,NoOfPrograms
							  ,NoOfDays							

								 INTO #ProdTableWeekOrder

							  FROM CTE 

								    WHERE TotalConsumption IS NOT NULL

					   SET @SQLStatement 

								='SELECT * FROM #ProdTableWeekOrder ORDER BY ' + @SortField + ' ' + @SortDirection



	   				   EXEC(@SQLStatement)

					   DROP TABLE #ProdTableWeekOrder

		  END



				  

		  IF(@QuarterWise = 1)

			 BEGIN 

		  		    SELECT 

						0 as ProductId,

						DATENAME(MONTH, RecordDate) As DateRange

							   ,SUM(TotalConsumption) AS TotalConsumption
					,SUM(TargetConsumption) AS TargetConsumption
					--,SUM(AverageConsumption) AS AverageConsumption
					,CAST(SUM(CCR.TotalConsumption)/COUNT(DISTINCT CCR.ProgramNumber) AS decimal(18,2)) AS AverageConsumption,
				    CAST(SUM(CCR.TotalConsumption)/COUNT(DISTINCT CCR.RecordDate) AS decimal(18,2)) AverageDailyConsumption,
				    CAST(SUM(CCR.TotalConsumption)/COUNT(CCR.BatchId) AS decimal(18,2)) AS ActualConsumptionPerLoad,
				    CAST(SUM(CCR.TargetConsumption)/COUNT(CCR.BatchId) AS decimal(18,2)) AS TargetConsumptionPerLoad,
				    SUM(CCR.Cost) AS Cost,
				    CAST(SUM(CCR.Cost)/COUNT(CCR.BatchId) AS decimal(18,2)) AS CostPerLoad,
				    CAST((CASE WHEN (SUM(CCR.TotalConsumption) - SUM(CCR.TargetConsumption) < 0) THEN 0 ELSE ABS(SUM(CCR.TotalConsumption) - SUM(CCR.TargetConsumption))*SUM(CCR.Cost) END) AS decimal(18,2)) AS CostExcess

						,DATEPART(MONTH, RecordDate) AS SortDateRange,@IsDrillDown AS IsDrillDown,
						  COUNT(CCR.BatchId) AS NoOfBatches,
						  COUNT(DISTINCT CCR.ProgramNumber) AS NoOfPrograms,
						  COUNT(DISTINCT CCR.RecordDate) NoOfDays

						INTO #ProdTableMonthOrder

						FROM @ChemicalConsumptionTable CCR 

						WHERE CCR.ProductId = @ProductId

						GROUP BY DATEPART(MONTH, RecordDate),DATENAME(MONTH, RecordDate)



						SET @SQLStatement 

						    ='SELECT 

									0 as ProductId,

								    DateRange,

								    TotalConsumption,

								    TargetConsumption,

								    AverageConsumption,

								    AverageDailyConsumption,

								    ActualConsumptionPerLoad,

								    TargetConsumptionPerLoad,

								    Cost,

								    CostPerLoad,

								    CostExcess,IsDrillDown,NoOfBatches,NoOfPrograms,NoOfDays		    

								 FROM #ProdTableMonthOrder ORDER BY ' + CASE @SortField WHEN 'DateRange' THEN 'SortDateRange' ELSE @SortField END + ' ' + @SortDirection



	   				   EXEC(@SQLStatement)



		  END



		IF(@YearWise = 1)

		  BEGIN 

			 DECLARE @Year VARCHAR(100) = RIGHT(YEAR(@FromDate),2)



			SELECT 

				0 as ProductId,

				 CASE 'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10))

										 WHEN 'Q1' THEN 'Jan' + @Year + '- Mar' + @Year

										 WHEN 'Q2' THEN 'Apr' + @Year + '- Jun' + @Year

										 WHEN 'Q3' THEN 'Jul' + @Year + '-Sep' + @Year

										 WHEN 'Q4' THEN 'Oct' + @Year + '- Dec'+ @Year

										 END as DateRange

					   ,SUM(TotalConsumption) AS TotalConsumption
					,SUM(TargetConsumption) AS TargetConsumption
					--,SUM(AverageConsumption) AS AverageConsumption
					,CAST(SUM(CCR.TotalConsumption)/COUNT(DISTINCT CCR.ProgramNumber) AS decimal(18,2)) AS AverageConsumption,
				    CAST(SUM(CCR.TotalConsumption)/COUNT(DISTINCT CCR.RecordDate) AS decimal(18,2)) AverageDailyConsumption,
				    CAST(SUM(CCR.TotalConsumption)/COUNT(CCR.BatchId) AS decimal(18,2)) AS ActualConsumptionPerLoad,
				    CAST(SUM(CCR.TargetConsumption)/COUNT(CCR.BatchId) AS decimal(18,2)) AS TargetConsumptionPerLoad,
				    SUM(CCR.Cost) AS Cost,
				    CAST(SUM(CCR.Cost)/COUNT(CCR.BatchId) AS decimal(18,2)) AS CostPerLoad,
				    CAST((CASE WHEN (SUM(CCR.TotalConsumption) - SUM(CCR.TargetConsumption) < 0) THEN 0 ELSE ABS(SUM(CCR.TotalConsumption) - SUM(CCR.TargetConsumption))*SUM(CCR.Cost) END) AS decimal(18,2)) AS CostExcess

				,'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10)) as SortDateRange,@IsDrillDown AS IsDrillDown,
				COUNT(CCR.BatchId) AS NoOfBatches,
				 COUNT(DISTINCT CCR.ProgramNumber) AS NoOfPrograms,
				 COUNT(DISTINCT CCR.RecordDate) NoOfDays

				INTO #ProdTableyearOrder

				FROM @ChemicalConsumptionTable CCR 

						WHERE CCR.ProductId = @ProductId

			 GROUP BY DATEPART(QUARTER, RecordDate)



			 SET @SQLStatement 

						    ='SELECT 

									0 as ProductId,

								    DateRange,

								    TotalConsumption,

								    TargetConsumption,

								    AverageConsumption,

								    AverageDailyConsumption,

								    ActualConsumptionPerLoad,

								    TargetConsumptionPerLoad,

								    Cost,

								    CostPerLoad,

								    CostExcess,IsDrillDown,
								    NoOfBatches,
								    NoOfPrograms,
								    NoOfDays   

								 FROM #ProdTableyearOrder ORDER BY ' + CASE @SortField WHEN 'DateRange' THEN 'SortDateRange' ELSE @SortField END + ' ' + @SortDirection



	   				   EXEC(@SQLStatement)

		  END



SET NOCOUNT OFF;   

END