﻿CREATE PROCEDURE [TCD].[SavePlantSensorDetails](@SensorNumber                       NVARCHAR( 100) = NULL, 
												@EcolabAccountNumber                VARCHAR( 1000) = NULL,
												@ControllerID                       VARCHAR( 1000) = NULL,
												@SensorName                         NVARCHAR( 100) = NULL,
												@SensorType                         NVARCHAR( 100) = NULL,
												@SensorLocation                     NVARCHAR( 100) = NULL,
												@MachineCompartment                 NVARCHAR( 100) = NULL,
												@OutputType                         NVARCHAR( 100) = NULL,
												@ChemicalforChart                   NVARCHAR( 100)= NULL,
												@UOM                                NVARCHAR( 100) = NULL,
												@DashboardActualValue               VARCHAR( 100) = NULL,
												@UserID                             INT, 
												@AnalogueInputNumber                NVARCHAR( 100) = NULL,
												@Calibration4mA                     DECIMAL( 18, 2) = NULL,
												@Calibration20mA                    DECIMAL( 18, 2) = NULL,
												@TagAddress4mA                      NVARCHAR( 100) = NULL,
												@TagAddress20mA                     NVARCHAR( 100) = NULL,
												@Scope                              VARCHAR( 100)OUTPUT,
												@OutputSensorId                     INT = NULL OUTPUT,
												@LastModifiedTimestampAtCentral     DATETIME = NULL,
												@OutputLastModifiedTimestampAtLocal DATETIME = NULL OUTPUT,
												@SensorNum                          INT, 
												@AlarmEnable                        BIT, 
												@MinimumAlarmValue                  INT, 
												@MaximumAlarmValue                  INT, 
												@ExternalSensor                     INT,
												@PumpNumber	                     int  = NULL) 
AS 
  BEGIN 
	  SET NOCOUNT ON; 

	  DECLARE @IsPlant  BIT = NULL, 
			  @IsPress  BIT = NULL, 
			  @IStunnel INT = ''; 
	  DECLARE @TypeLimit         INT = NULL, 
			  @TempLimit         INT = NULL, 
			  @pHLimit           INT = NULL, 
			  @ConductivityLimit INT = NULL, 
			  @WeightLimit       INT = NULL, 
			  @RedoxLimit        INT = NULL, 
			  @ControllerModelID INT = NULL; 
	  DECLARE @ReturnValue    INT = 0, 
			  @ErrorId        INT = 0, 
			  @ErrorMessage   NVARCHAR( 4000) = N'', 
			  @CurrentUTCTime DATETIME = Getutcdate(); 
	  DECLARE @OutputList AS TABLE 
		( 
		   SensorId              INT, 
		   LastModifiedTimestamp DATETIME 
		); 

	  SET @OutputLastModifiedTimestampAtLocal = ISNULL(@OutputLastModifiedTimestampAtLocal, NULL);
	  --SQLEnlight 
	  SET @OutputSensorId = ISNULL(@OutputSensorId, NULL); 

	  /*Maximum one Sensor with the same type can be connected to one machine/Compartement */
	  IF @LastModifiedTimestampAtCentral IS NOT NULL 
		 AND NOT EXISTS(SELECT 1 
						FROM   TCD.Sensor AS S 
						WHERE  S.EcolabAccountNumber = @EcolabAccountNumber 
							   AND S.SensorId = @SensorNumber 
							   AND S.LastModifiedTime = @LastModifiedTimestampAtCentral) 
		BEGIN 
			SET @ErrorId = 60000; 
			SET @ErrorMessage = N'' + Cast( @ErrorId AS NVARCHAR); 

			RAISERROR( @ErrorMessage,16,1); 

			SET @ReturnValue = -1; 

			RETURN @ReturnValue; 
		END; 

	  SET @Scope = ''; 

	  SELECT @TypeLimit = Count(1) 
	  FROM   TCD.Sensor AS S 
	  WHERE  GroupId = @SensorLocation 
			 AND S.SensorType = @SensorType 
			 AND ISNULL(MachineCompartment, 0) = @MachineCompartment 
			 AND Is_deleted = 0 
			 AND ControllerID IN(SELECT ControllerId 
								 FROM   TCD.ConduitController 
								 WHERE  ControllerId = @ControllerID 
										AND EcoalabAccountNumber = @EcolabAccountNumber) 
			 AND EcolabAccountNumber = @EcolabAccountNumber; 

	  /*Maximum 6 Temperature sensor can be connected to the same Washter-Tunnel */ 
	  SELECT @TempLimit = Count(1) 
	  FROM   TCD.Sensor AS S 
			 LEFT OUTER JOIN TCD.machinesetup AS MS 
						  ON S.GroupId = MS.groupId 
							 AND S.EcolabAccountNumber = MS.EcoalabAccountNumber 
	  WHERE  S.SensorType = 1 
			 AND S.GroupID = @SensorLocation 
			 AND Ms.Istunnel = 1 
			 AND IS_deleted = 0 
			 AND S.ControllerID IN(SELECT ControllerId 
								   FROM   TCD.ConduitController 
								   WHERE  ControllerModelId = 7 
										  AND EcoalabAccountNumber = @EcolabAccountNumber) 
			 AND S.EcolabAccountNumber = @EcolabAccountNumber; 

	  /* Maximum 2 pH sensor can be connected to the same Washter-Tunnel */ 
	  SELECT @pHLimit = Count(1) 
	  FROM   TCD.Sensor AS S 
			 LEFT OUTER JOIN TCD.machinesetup AS MS 
						  ON S.GroupId = MS.groupId 
							 AND S.EcolabAccountNumber = MS.EcoalabAccountNumber 
	  WHERE  S.SensorType = 2 
			 AND S.GroupID = @SensorLocation 
			 AND Ms.Istunnel = 1 
			 AND IS_deleted = 0 
			 AND S.ControllerID IN(SELECT ControllerId 
								   FROM   TCD.ConduitController 
								   WHERE  ControllerModelId = 7 
										  AND EcoalabAccountNumber = @EcolabAccountNumber) 
			 AND S.EcolabAccountNumber = @EcolabAccountNumber; 

	  /* Maximum 1 Redox sensor can be connected to the same Washter-Tunnel */ 
	  SELECT @RedoxLimit = Count(1) 
	  FROM   TCD.Sensor AS S 
			 LEFT OUTER JOIN TCD.machinesetup AS MS 
						  ON S.GroupId = MS.groupId 
							 AND S.EcolabAccountNumber = MS.EcoalabAccountNumber 
	  WHERE  S.SensorType = 2 
			 AND S.GroupID = @SensorLocation 
			 AND Ms.Istunnel = 1 
			 AND IS_deleted = 0 
			 AND S.ControllerID IN(SELECT ControllerId 
								   FROM   TCD.ConduitController 
								   WHERE  ControllerModelId = 7 
										  AND EcoalabAccountNumber = @EcolabAccountNumber) 
			 AND S.EcolabAccountNumber = @EcolabAccountNumber; 

	  /* Maximum 1 Conductivity sensor can be connected to the same Washter-Tunnel */ 
	  SELECT @ConductivityLimit = Count(1) 
	  FROM   TCD.Sensor AS S 
			 LEFT OUTER JOIN TCD.machinesetup AS MS 
						  ON S.GroupId = MS.groupId 
							 AND S.EcolabAccountNumber = MS.EcoalabAccountNumber 
	  WHERE  S.SensorType = 4 
			 AND S.GroupID = @SensorLocation 
			 AND Ms.Istunnel = 1 
			 AND IS_deleted = 0 
			 AND S.ControllerID IN(SELECT ControllerId 
								   FROM   TCD.ConduitController 
								   WHERE  ControllerModelId = 7 
										  AND EcoalabAccountNumber = @EcolabAccountNumber) 
			 AND S.EcolabAccountNumber = @EcolabAccountNumber; 

	  /* Maximum 1 Weight sensor can be connected to the same Washter-Tunnel */ 
	  SELECT @WeightLimit = Count(1) 
	  FROM   TCD.Sensor AS S 
			 LEFT OUTER JOIN TCD.machinesetup AS MS 
						  ON S.GroupId = MS.groupId 
							 AND S.EcolabAccountNumber = MS.EcoalabAccountNumber 
	  WHERE  S.SensorType = 5 
			 AND S.GroupID = @SensorLocation 
			 AND Ms.Istunnel = 1 
			 AND IS_deleted = 0 
			 AND S.ControllerID IN(SELECT ControllerId 
								   FROM   TCD.ConduitController 
								   WHERE  ControllerModelId = 7 
										  AND EcoalabAccountNumber = @EcolabAccountNumber) 
			 AND S.EcolabAccountNumber = @EcolabAccountNumber; 

	  SELECT @ControllerModelID = ControllerModelId 
	  FROM   TCD.ConduitController 
	  WHERE  ControllerId = @ControllerID 
			 AND EcoalabAccountNumber = @EcolabAccountNumber; 

	  SELECT @IStunnel = Istunnel 
	  FROM   TCD.machinesetup AS MS 
	  WHERE  Ms.GroupId = @SensorLocation 
			 AND MS.EcoalabAccountNumber = @EcolabAccountNumber; 

	  IF @IStunnel = 1 
		BEGIN 
			IF @MachineCompartment = 1 
			  BEGIN 
				  SET @IsPress = 1; 
			  END; 
		END; 

	  IF @MachineCompartment = 0 
		BEGIN 
			SET @MachineCompartment = NULL; 
		END; 

	  IF @SensorLocation = 1 
		BEGIN 
			SET @IsPlant = 1; 
			SET @SensorLocation = NULL; 
			SET @MachineCompartment = NULL; 
		END; 

	  IF @ControllerID = -1 
		BEGIN 
			SELECT TOP ( 1 )@ControllerID = ControllerID 
			FROM   TCD.ConduitController 
			WHERE  ControllerModelId = @ControllerModelID 
				   AND EcoalabAccountNumber = @EcolabAccountNumber; 
		END; 
	  ELSE 
		BEGIN 
			SELECT @ControllerModelID = ControllerModelId 
			FROM   TCD.ConduitController 
			WHERE  ControllerId = @ControllerID 
				   AND EcoalabAccountNumber = @EcolabAccountNumber; 
		END; 

	  IF @ControllerID != -1 
		BEGIN 
			/* Inserting the values in to Sensor table if it is new Sensor */ 
			DECLARE @NewSensorId      INT, 
					@ModuleType       INT = 3, 
					@DefaultFrequency INT = 60, 
					@TagType          VARCHAR( 100) = 'Tag_MPLC', 
					@TagTypeSC4       VARCHAR( 100) = 'Tag_SC4', 
					@TagTypeSC20      VARCHAR( 100) = 'Tag_SC20', 
					@Result1          INT = NULL, 
					@Result2          INT = NULL, 
					@Result3          INT = NULL, 
					@Type             INT = 3, 
					@AllowTagEdit     BIT; 

			SELECT @AllowTagEdit = CASE 
									 WHEN Count(*) > 0 THEN 'TRUE' 
									 ELSE 'FALSE' 
								   END 
			FROM   TCD.UserMaster AS UM 
				   INNER JOIN TCD.UserInRole AS UIR 
						   ON UM.UserId = UIR.UserId 
				   INNER JOIN TCD.UserRoles AS UR 
						   ON UIR.RoleId = UR.RoleId 
			WHERE  UM.UserId = @UserID 
				   AND UR.LevelId >= 8 
				   AND UM.EcolabAccountNumber = @EcolabAccountNumber; 

			IF NOT EXISTS(SELECT * 
						  FROM   TCD.Sensor 
						  WHERE  SensorID = @SensorNumber 
								 AND EcolabAccountNumber = @EcolabAccountNumber) 
			  -- Begin Create Sensor 
			  BEGIN 
				  BEGIN 
					  DECLARE @AllowInsert BIT = 'FALSE'; 

					  IF @TypeLimit < 1 
						BEGIN 
							IF @ControllerModelID = 7 
							  BEGIN 
								  IF @SensorType = 1 
									BEGIN 
										IF @TempLimit < 6 
										  BEGIN 
											  SET @AllowInsert = 'TRUE'; 
										  END; 
										ELSE 
										  BEGIN 
											  SET @SCOPE = @SCOPE + '401,'; 
										  END; 
									END; 
								  ELSE 
									BEGIN 
										IF @SensorType = 2 
										  BEGIN 
											  IF @pHLimit < 2 
												BEGIN 
													SET @AllowInsert = 'TRUE'; 
												END; 
											  ELSE 
												BEGIN 
													SET @SCOPE = @SCOPE + '301,'; 
												END; 
										  END; 
										ELSE 
										  BEGIN 
											  IF @SensorType = 3 
												BEGIN 
													IF @RedoxLimit < 1 
													  BEGIN 
														  SET @AllowInsert = 'TRUE'; 
													  END; 
													ELSE 
													  BEGIN 
														  SET @SCOPE = @SCOPE + '301,'; 
													  END; 
												END; 
											  ELSE 
												BEGIN 
													IF @SensorType = 4 
													  BEGIN 
														  IF @ConductivityLimit < 1 
															BEGIN 
																SET @AllowInsert = 'TRUE'; 
															END; 
														  ELSE 
															BEGIN 
																SET @SCOPE = @SCOPE + '201,';
															END; 
													  END; 
													ELSE 
													  BEGIN 
														  IF @SensorType = 5 
															BEGIN 
																IF @WeightLimit < 1 
																  BEGIN 
																	  SET @AllowInsert = 'TRUE';
																  END; 
																ELSE 
																  BEGIN 
																	  SET @SCOPE = @SCOPE + '101,';
																  END; 
															END; 
													  END; 
												END; 
										  END; 
									END; 
							  END; 
							ELSE 
							  BEGIN 
								  SET @AllowInsert = 'TRUE'; 
							  END; 
						END; 
					  ELSE 
						BEGIN 
							SET @Scope = @Scope + '501,'; 
						END; 

					  -- End Business Validations 
					  -- Begin Insert if Validation Succeeds 
					  IF @AllowInsert = 'TRUE' 
						BEGIN 
							DECLARE @SensorCount INT; 

							SELECT @SensorCount = Max( s.SensorId) + 1 
							FROM   TCD.Sensor AS s WITH ( NOLOCK); 

							INSERT INTO TCD.Sensor 
										(Description, 
										 SensorType, 
										 GroupId, 
										 MachineCompartment, 
										 EcolabAccountNumber, 
										 ControllerID, 
										 OutputType, 
										 ChemicalforChart, 
										 UOM, 
										 DashboardActualValue, 
										 LastModifiedByUserId, 
										 IsPlant, 
										 IsPress, 
										 Calibration4mA, 
										 Calibration20mA, 
										 Id, 
										 SensorNum, 
										 AlarmEnable, 
										 MinimumAlarmValue, 
										 MaximumAlarmValue, 
										 AnalogueInputNumber,
										 ControllerEquipmentID) 
							OUTPUT      inserted.SensorId AS SensorId, 
										inserted.LastModifiedTime AS LastModifiedTimestamp 
							INTO @OutputList( SensorId, LastModifiedTimestamp ) 
							SELECT @SensorName, 
								   @SensorType, 
								   @SensorLocation, 
								   @MachineCompartment, 
								   @EcolabAccountNumber, 
								   @ControllerID, 
								   @OutputType, 
								   @ChemicalforChart, 
								   @UOM, 
								   @DashboardActualValue, 
								   @UserID, 
								   @IsPlant, 
								   @IsPress, 
								   @Calibration4mA, 
								   @Calibration20mA, 
								   @SensorCount, 
								   @SensorNum, 
								   @AlarmEnable, 
								   @MinimumAlarmValue, 
								   @MaximumAlarmValue, 
								   @ExternalSensor,
								   @PumpNumber; 

							SET @NewSensorId = Scope_identity(); 
						END; 
				  END; 
			  END; 
			ELSE 
			  ------------------------------------------------------------------------------------------------------------------ 
			  -- Begin Update Sensor 
			  BEGIN 
				  DECLARE @PlantId INT = (SELECT MG.Id 
					 FROM   TCD.MachineGroupType AS MGT 
							INNER JOIN TCD.MachineGroup AS MG 
									ON MGT.Id = MG.GroupTypeId 
					 WHERE  MGT.Id = 1 
							AND MG.Is_Deleted = 0); 

				  -- Check RedFlag Association and Update Sensor 
				  IF( (SELECT COALESCE(S.GroupId, '') 
					   FROM   TCD.Sensor AS S 
					   WHERE  S.SensorId = @SensorNumber) != COALESCE(@SensorLocation, '') 
					   OR (SELECT COALESCE(S.MachineCompartment, '') 
						   FROM   TCD.Sensor AS S 
						   WHERE  S.SensorId = @SensorNumber) != COALESCE(@MachineCompartment, '') )
					AND EXISTS(SELECT 1 
							   FROM   TCD.RedFlag AS RF 
									  INNER JOIN TCD.RedFlagMappingData AS RFM 
											  ON RF.Id = RFM.MappingId 
												 AND RF.Is_Deleted = 0 
												 AND RFM.Is_Deleted = 0 
									  LEFT JOIN TCD.Sensor AS S 
											 ON RF.Location = CASE S.IsPlant 
																WHEN 'TRUE' THEN COALESCE(S.GroupId, @PlantId)
																ELSE S.GroupId 
															  END 
												AND COALESCE(S.MachineCompartment, 0) = COALESCE(RFM.MachineId, 0)
												AND S.Is_deleted = 0 
							   WHERE  S.SensorId = @SensorNumber) 
					BEGIN 
						SET @Scope = '405,'; 
					END; 
				  ELSE 
					BEGIN 
						IF( @Result1 IS NULL 
							 OR @Result1 <> 0 ) 
						  AND ( @Result2 IS NULL 
								 OR @Result2 <> 0 ) 
						  AND ( @Result3 IS NULL 
								 OR @Result3 <> 0 ) 
						  BEGIN 
							  DECLARE @AllowUpdate BIT = 'FALSE'; 

							  --Begin Get old Sensor Values 
							  BEGIN 
								  DECLARE @uty INT = (SELECT sensortype 
									 FROM   TCD.Sensor 
									 WHERE  SensorID = @SensorNumber 
											AND EcolabAccountNumber = @EcolabAccountNumber); 
								  DECLARE @grpId INT = (SELECT GroupId 
									 FROM   TCD.Sensor 
									 WHERE  SensorID = @SensorNumber 
											AND EcolabAccountNumber = @EcolabAccountNumber); 
								  DECLARE @machId INT = (SELECT MachineCompartment 
									 FROM   TCD.Sensor 
									 WHERE  SensorID = @SensorNumber 
											AND EcolabAccountNumber = @EcolabAccountNumber); 
							  END; 

							  --Begin Get old Sensor Values 
							  IF @uty <> @SensorType 
								  OR @grpId <> @SensorLocation 
								  OR @machId <> @MachineCompartment 
								BEGIN 
									IF @TypeLimit < 1 
									  BEGIN 
										  IF @ControllerModelID = 7 
											BEGIN 
												IF @SensorType = 1 
												  BEGIN 
													  IF @TempLimit <= 6 
														BEGIN 
															SET @AllowUpdate = 'TRUE'; 
														END; 
													  ELSE 
														BEGIN 
															SET @SCOPE = @SCOPE + '401,'; 
														END; 
												  END; 
												ELSE 
												  BEGIN 
													  IF @SensorType = 2 
														BEGIN 
															IF @pHLimit <= 2 
															  BEGIN 
																  SET @AllowUpdate = 'TRUE'; 
															  END; 
															ELSE 
															  BEGIN 
																  SET @SCOPE = @SCOPE + '301,';
															  END; 
														END; 
													  ELSE 
														BEGIN 
															IF @SensorType = 3 
															  BEGIN 
																  IF @RedoxLimit <= 1 
																	BEGIN 
																		SET @AllowUpdate = 'TRUE';
																	END; 
																  ELSE 
																	BEGIN 
																		SET @SCOPE = @SCOPE + '301,';
																	END; 
															  END; 
															ELSE 
															  BEGIN 
																  IF @SensorType = 4 
																	BEGIN 
																		IF @ConductivityLimit <= 1
																		  BEGIN 
																			  SET @AllowUpdate = 'TRUE';
																		  END; 
																		ELSE 
																		  BEGIN 
																			  SET @SCOPE = @SCOPE + '201,';
																		  END; 
																	END; 
																  ELSE 
																	BEGIN 
																		IF @SensorType = 5 
																		  BEGIN 
																			  IF @WeightLimit <= 1
																				BEGIN 
																					SET @AllowUpdate = 'TRUE';
																				END; 
																			  ELSE 
																				BEGIN 
																					SET @SCOPE = @SCOPE + '101,';
																				END; 
																		  END; 
																	END; 
															  END; 
														END; 
												  END; 
											END; 
										  ELSE 
											BEGIN 
												BEGIN 
													SET @AllowUpdate = 'TRUE'; 
												END; 
											END; 
									  END; 
									ELSE 
									  BEGIN 
										  SET @SCOPE = @SCOPE + '501,'; 
									  END; 
								END; 
							  ELSE 
								BEGIN 
									SET @AllowUpdate = 'TRUE'; 
								END; 

							  IF @AllowUpdate = 'TRUE' 
								BEGIN 
									IF @LastModifiedTimestampAtCentral IS NOT NULL 
									   AND NOT EXISTS(SELECT 1 
													  FROM   TCD.Sensor AS S 
													  WHERE  S.EcolabAccountNumber = @EcolabAccountNumber
															 AND S.SensorId = @SensorNumber 
															 AND S.LastModifiedTime = @LastModifiedTimestampAtCentral)
									  BEGIN 
										  SET @ErrorId = 60000; 
										  SET @ErrorMessage = N'' + Cast( @ErrorId AS NVARCHAR )
															  + N': Record not in-synch between plant and central.'; 

										  RAISERROR( @ErrorMessage,16,1 ); 

										  SET @ReturnValue = -1; 

										  RETURN @ReturnValue; 
									  END; 

									UPDATE s 
									SET    Description = @SensorName, 
										   SensorType = @SensorType, 
										   GroupId = @SensorLocation, 
										   MachineCompartment = @MachineCompartment, 
										   S.ControllerID = @ControllerID, 
										   OutputType = @OutputType, 
										   ChemicalforChart = @ChemicalforChart, 
										   UOM = @UOM, 
										   DashboardActualValue = @DashboardActualValue, 
										   LastModifiedByUserId = @UserID, 
										   Calibration4mA = @Calibration4mA, 
										   Calibration20mA = @Calibration20mA, 
										   LastModifiedTime = @CurrentUTCTime, 
										   SensorNum = @SensorNum, 
										   AlarmEnable = @AlarmEnable, 
										   MinimumAlarmValue = @MinimumAlarmValue, 
										   MaximumAlarmValue = @MaximumAlarmValue, 
										   AnalogueInputNumber = @ExternalSensor ,
										   ControllerEquipmentID = @PumpNumber
									OUTPUT inserted.SensorId AS SensorId, 
										   inserted.LastModifiedTime AS LastModifiedTimestamp
									INTO @OutputList( SensorId, LastModifiedTimestamp ) 
									FROM   TCD.Sensor S 
									WHERE  SensorID = @SensorNumber 
										   AND EcolabAccountNumber = @EcolabAccountNumber; 
								END; 
						  END; 
					END; 
			  END; 
		-- End Update Sensor 
		END; 
	  ELSE 
		BEGIN 
			SELECT @Scope = '701,'; 
		END; 

	  SET NOCOUNT OFF; 

	  SELECT TOP 1 @OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp, 
				   @OutputSensorId = O.SensorId 
	  FROM   @OutputList AS O; 

	  RETURN @ReturnValue; 
  END