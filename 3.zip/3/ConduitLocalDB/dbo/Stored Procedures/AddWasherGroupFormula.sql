﻿/*	
Purpose					:	To associate a formula to a washer group from Washer Group --> Formula setup screen

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version



*/
CREATE PROCEDURE [TCD].[AddWasherGroupFormula]
     @EcoLabAccountNumber     NVARCHAR(25)
    , @WasherGroupId       INT
    , @ProgramNumber       SMALLINT
    , @ProgramId        INT
    , @NominalLoad       SMALLINT
    , @LoadsPerMonth       SMALLINT
    , @ExtraTime        INT
	, @CoolDownStep     INT
    , @UserId         INT
    , @ProgramSetupId       SMALLINT   OUTPUT
    , @LastModifiedTimestampAtCentral   DATETIME     = NULL
    , @OutputLastModifiedTimestampAtLocal  DATETIME     = NULL OUTPUT
    , @MyServiceCustFrmulaMchGrpGUID   UNIQUEIDENTIFIER   = NULL
AS
BEGIN

SET NOCOUNT ON


DECLARE 
  @ReturnValue     INT     =   0
 , @ErrorId      INT     =   0
 , @ErrorMessage     NVARCHAR(4000)  =   N''
 --, @CurrentUTCTime     DATETIME   =   GETUTCDATE()  --SQLEnlight SA0004

 --, @WasherGroupNumber    VARCHAR(10)   =   NULL
 --, @WasherGroupName    NVARCHAR(50)  =   NULL    --SQLEnlight SA0004
 --, @WasherGroupTypeId    TINYINT    =   NULL
 , @WasherGroupTypeName   VARCHAR(30)   =   NULL

 , @TotalNumberOfPrograms   SMALLINT   =   NULL
 , @MaxNumberOfPrograms   SMALLINT   =   NULL   --this is the defined number for now
 , @ControllerID     INT     =   NULL
    , @ControllerModelID    INT     =   NULL
 	 ,@Totalruntime INT = NULL

DECLARE
   @OutputList        AS TABLE  (
   OutputProgramSetupId     INT
  , LastModifiedTimestamp     DATETIME
  )

SET  @OutputLastModifiedTimestampAtLocal   =   ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)   --SQLEnlight
SET  @ProgramSetupId        =   ISNULL(@ProgramSetupId, NULL)        --SQLEnlight SA0121
SET  @LastModifiedTimestampAtCentral    =   ISNULL(@LastModifiedTimestampAtCentral, NULL)    --SQLEnlight SA0029


--Determine the WasherGroup type - Conventional/Tunnel
SELECT /*@WasherGroupTypeId   =   WGT.WasherGroupTypeId             --SQLEnlight SA0004
 , */@WasherGroupTypeName  =   WGT.WasherGroupTypeName
 --, @WasherGroupNumber   =   WG.WasherGroupNumber              --SQLEnlight SA0004
FROM [TCD].WasherGroup     WG
JOIN [TCD].WasherGroupType    WGT
 ON WG.WasherGroupTypeId  =   WGT.WasherGroupTypeId
JOIN [TCD].MachineGroup     GT
 ON WG.WasherGroupId   =   GT.Id
WHERE GT.EcolabAccountNumber  =   @EcoLabAccountNumber
 AND WG.WasherGroupId   =   @WasherGroupId

SELECT  @ControllerID   =  wg.ControllerId 
 FROM TCD.WasherGroup   wg
 WHERE   wg.WasherGroupId  =  @WasherGroupId
AND   wg.EcolabAccountNumber =  @EcoLabAccountNumber

SELECT  @ControllerModelID  =  cc.ControllerModelId
 FROM TCD.ConduitController cc
 WHERE cc.ControllerId   =  @ControllerID
AND   cc.EcoalabAccountNumber =  @EcoLabAccountNumber

IF ( @WasherGroupTypeName  IS   NULL)
 BEGIN
   SET  @ErrorId      =   51000
   SET  @ErrorMessage     =   N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Could not determine the WasherGroup Type... Aborting.'
   --GOTO ErrorHandler
   RAISERROR (@ErrorMessage, 16, 1)
   SET @ReturnValue = -1
   RETURN (@ReturnValue)
 END

IF @ControllerID IS NOT NULL
BEGIN
 IF ( @WasherGroupTypeName = 'Tunnel' )
  BEGIN
   SELECT @MaxNumberOfPrograms = cmctm.MaxTunnelProgramCount 
   FROM TCD.ControllerModelControllerTypeMapping cmctm
   INNER JOIN TCD.ConduitController cc
   ON cc.ControllerModelId = cmctm.ControllerModelId 
   AND cc.ControllerTypeId = cmctm.ControllerTypeId
   WHERE cc.ControllerId = @ControllerID
  END
 ELSE
  BEGIN
   SELECT @MaxNumberOfPrograms = cmctm.MaxConvProgramCount
   FROM TCD.ControllerModelControllerTypeMapping cmctm
   INNER JOIN TCD.ConduitController cc
   ON cc.ControllerModelId = cmctm.ControllerModelId 
   AND cc.ControllerTypeId = cmctm.ControllerTypeId
   WHERE cc.ControllerId = @ControllerID
  END
END
ELSE
BEGIN
 SET @MaxNumberOfPrograms = 127
END

--ProgramNumber check
IF ( @ProgramNumber    >   @MaxNumberOfPrograms)
 BEGIN
   SET  @ErrorId      =  51012 -- Changed for tfs ID 155872
   SET  @ErrorMessage     =   N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Invalid ProgramNumber... Aborting.'
   --GOTO ErrorHandler
   RAISERROR (@ErrorMessage, 16, 1)
   SET @ReturnValue = -1
   RETURN (@ReturnValue)
 END

IF ( @WasherGroupTypeName = 'Tunnel' )
 BEGIN
  --Check for unique ProgramNumber
  IF EXISTS (  SELECT 1
       FROM [TCD].TunnelProgramSetup   TPS
       WHERE TPS.EcolabAccountNumber  =   @EcoLabAccountNumber
        AND TPS.WasherGroupId   =   @WasherGroupId
        AND TPS.ProgramNumber   =   @ProgramNumber
        AND TPS.Is_Deleted    =   'FALSE'
     )
    BEGIN
      SET  @ErrorId   =   51000
      SET  @ErrorMessage  =   N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Specified ProgramNumber for the WasherGroup already exists for the plant.'
      --GOTO ErrorHandler
      RAISERROR (@ErrorMessage, 16, 1)
      SET @ReturnValue = -1
      RETURN (@ReturnValue)
    END

  --Check for total number of programs/formulae associated
  SELECT @TotalNumberOfPrograms  =   COUNT(TPS.ProgramNumber)
  FROM [TCD].TunnelProgramSetup      TPS
  WHERE TPS.EcolabAccountNumber  =   @EcoLabAccountNumber
   AND TPS.WasherGroupId   =   @WasherGroupId
   AND TPS.Is_Deleted    =   'FALSE'
  
  IF ( @TotalNumberOfPrograms  =   @MaxNumberOfPrograms )
   BEGIN
     SET  @ErrorId  =   51000
     SET  @ErrorMessage =   N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Maximum Number of programs that can be associated to a WasherGroup already defined... Aborting.'
     --GOTO ErrorHandler
     RAISERROR (@ErrorMessage, 16, 1)
     SET @ReturnValue = -1
     RETURN (@ReturnValue)
   END

  --Now INSERT the new record
  INSERT [TCD].TunnelProgramSetup (
    EcolabAccountNumber  ,WasherGroupId ,ProgramNumber ,ProgramId ,NominalLoad ,LoadsPerMonth ,ExtraTime ,LastModifiedByUserId, MyServiceCustFrmulaMchGrpGUID)
  OUTPUT
     inserted.TunnelProgramSetupId      AS   Id
    , inserted.LastModifiedTime       AS   LastModifiedTimestamp
  INTO
     @OutputList (
     OutputProgramSetupId
    , LastModifiedTimestamp
    )
  VALUES (@EcoLabAccountNumber ,@WasherGroupId ,@ProgramNumber ,@ProgramId ,@NominalLoad ,@LoadsPerMonth ,@ExtraTime ,@UserId, @MyServiceCustFrmulaMchGrpGUID)
  
  --check for any error
  SET @ErrorId = @@ERROR
 
  IF (@ErrorId <> 0)
   BEGIN
     SET  @ErrorMessage =   N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred associating formula to the tunnel group.'
     --GOTO ErrorHandler
     RAISERROR (@ErrorMessage, 16, 1)
     SET @ReturnValue = -1
     RETURN (@ReturnValue)
   END

  --set the output param for the newly inserted record
  SET @ProgramSetupId   =   SCOPE_IDENTITY()
 END
ELSE IF ( @WasherGroupTypeName = 'Conventional' )
  BEGIN
    
   IF @ControllerModelID = 7 -- MyControl
    BEGIN
     SET @WasherGroupId = NULL
    END

   --Check for unique ProgramNumber
   IF EXISTS (  SELECT 1
        FROM [TCD].WasherProgramSetup   WPS
        WHERE WPS.EcolabAccountNumber  =   @EcoLabAccountNumber
        AND  (CASE WHEN @WasherGroupId IS NOT NULL 
             THEN WPS.WasherGroupId
             ELSE WPS.ControllerID
          END)      = (CASE WHEN @WasherGroupId IS NOT NULL 
                   THEN @WasherGroupId
                   ELSE @ControllerID
                  END)
         AND WPS.ProgramNumber   =   @ProgramNumber
         AND WPS.Is_Deleted    =   'FALSE'
      )
     BEGIN
       SET  @ErrorId      =   51000
       SET  @ErrorMessage     =   N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Specified ProgramNumber for the WasherGroup already exists for the plant.'
       --GOTO ErrorHandler
       RAISERROR (@ErrorMessage, 16, 1)
       SET @ReturnValue = -1
       RETURN (@ReturnValue)
     END

   --Check for total number of programs/formulae associated
   SELECT @TotalNumberOfPrograms  =   COUNT(WPS.ProgramNumber)
   FROM [TCD].WasherProgramSetup      WPS
   WHERE WPS.EcolabAccountNumber  =   @EcoLabAccountNumber
   AND  (CASE WHEN @WasherGroupId IS NOT NULL 
        THEN WPS.WasherGroupId
        ELSE WPS.ControllerID
     END)      = (CASE WHEN @WasherGroupId IS NOT NULL 
              THEN @WasherGroupId
              ELSE @ControllerID
             END)
    AND WPS.Is_Deleted    =   'FALSE'
  
   IF ( @TotalNumberOfPrograms  =   @MaxNumberOfPrograms )
    BEGIN
      SET  @ErrorId  =   51000
      SET  @ErrorMessage =   N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Maximum Number of programs that can be associated to a WasherGroup already defined... Aborting.'
      --GOTO ErrorHandler
      RAISERROR (@ErrorMessage, 16, 1)
      SET @ReturnValue = -1
      RETURN (@ReturnValue)
    END

         IF @ControllerModelID  < 3 OR @ControllerModelID IS NULL
    BEGIN
     SET @Totalruntime = @ExtraTime
    END

   --Now INSERT the new record
   INSERT [TCD].WasherProgramSetup (
     EcolabAccountNumber  ,WasherGroupId ,ProgramNumber ,ProgramId ,NominalLoad ,LoadsPerMonth ,ExtraTime, TotalRunTime,CoolDownStep, LastModifiedByUserId, MyServiceCustFrmulaMchGrpGUID, ControllerID)
   OUTPUT
     inserted.WasherProgramSetupId      AS   Id
    , inserted.LastModifiedTime       AS   LastModifiedTimestamp
   INTO
     @OutputList (
     OutputProgramSetupId
    , LastModifiedTimestamp
    )
   VALUES (@EcoLabAccountNumber ,@WasherGroupId ,@ProgramNumber ,@ProgramId ,@NominalLoad ,@LoadsPerMonth ,@ExtraTime, @Totalruntime ,@CoolDownStep, @UserId, @MyServiceCustFrmulaMchGrpGUID, @ControllerID)
  
   --check for any error
   SET @ErrorId = @@ERROR
 
   IF (@ErrorId <> 0)
    BEGIN
      SET  @ErrorMessage =   N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred associating formula to the conventional washer group.'
      --GOTO ErrorHandler
      RAISERROR (@ErrorMessage, 16, 1)
      SET @ReturnValue = -1
      RETURN (@ReturnValue)
    END

   --set the output param for the newly inserted record
    --SELECT TOP 1 @ProgramSetupId   = O.OutputProgramSetupId
    --         FROM @OutputList       O


  END




--ExitModule:

SELECT TOP 1 
  @OutputLastModifiedTimestampAtLocal  = O.LastModifiedTimestamp
 , @ProgramSetupId       = O.OutputProgramSetupId
FROM @OutputList       O


IF ( @ErrorId = 0 )
 BEGIN
  --GOTO ExitModule
  RETURN (@ReturnValue)
 END




--ErrorHandler:
--RAISERROR (@ErrorMessage, 16, 1)
--SET @ReturnValue = -1




--ExitModule:

SET NOCOUNT OFF
RETURN (@ReturnValue)
END