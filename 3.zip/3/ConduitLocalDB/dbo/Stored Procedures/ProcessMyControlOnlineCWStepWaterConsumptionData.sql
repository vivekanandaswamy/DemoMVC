﻿CREATE PROCEDURE [TCD].[ProcessMyControlOnlineCWStepWaterConsumptionData]
(
@ControllerID   INT,
 @VxML       XML
) 
AS
BEGIN
DECLARE @MachineNumber   INT,
  @WasherID INT,
  @MeterID INT,
  @WasherGroupID INT,
  @StepComportmentNO INT,
  @ActualQuantity Decimal(10,6),
  @EcolabWasherId INT,
  @CurrentStepComportmentNO INT,
  @WasherModuleCount        INT

   SELECT @MachineNumber = T.c.value('@MachineNumber', 'INT')
     FROM @VxML.nodes('MyControlConventionalData') T(C);


  CREATE TABLE #StepConsumptionData
  (
      StepNo      INT,
      Qty         DECIMAL(10, 6)
  )
   INSERT INTO #StepConsumptionData 
   SELECT  T.c.value('@StepNo', 'INT'),
         T.c.value('@WCCounter1', 'Decimal(10,2)')+T.c.value('@WCCounter2', 'Decimal(10,2)')
     FROM @VxML.nodes('MyControlConventionalData/WaterConsumptionData/StepConsumption') T(C)
  WHERE T.c.value('@WCCounter1', 'Decimal(10,6)')>0 OR T.c.value('@WCCounter2', 'Decimal(10,6)')>0 ;

  --Getting WasherGroupId,WasherId from MachineSetup
   SELECT @WasherGroupID = GroupId,
    @WasherID = ms.WasherID
     FROM TCD.MachineSetup ms
       WHERE ControllerID = @ControllerID
   AND MachineInternalId = @MachineNumber
   AND IsTunnel = 0
   AND IsDeleted = 0;

   --Getting MeterId,WasherId from Meter
   SELECT @MeterID=MeterId
   FROM tcd.Meter mt
   WHERE mt.UtilityType=2 
   AND mt.GroupId=@WasherGroupID 
   AND mt.ControllerID=@ControllerID 
   AND mt.MachineCompartment=@WasherID

    --Getting @EcolabWasherId from Washer
   SELECT @EcolabWasherId= wr.EcolabWasherId
   FROM TCD.Washer wr
      WHERE wr.WasherId=@WasherID

  
  SET @CurrentStepComportmentNO=1;
  WHILE(@CurrentStepComportmentNO<=25)
  BEGIN
  SELECT @StepComportmentNO=scd.StepNo,@ActualQuantity=scd.Qty
  FROM #StepConsumptionData scd where scd.StepNo=@CurrentStepComportmentNO
  SELECT @WasherModuleCount=COUNT(1) FROM TCD.WasherModuleOnlineUsageData WHERE WasherId = @WasherID AND StepComportment =@StepComportmentNO AND ModuleId = @MeterID AND ActualQuantity=@ActualQuantity 
  IF(@WasherModuleCount=0)
  BEGIN
  IF(@StepComportmentNO IS NOT NULL AND @WasherID IS NOT NULL AND @MeterID IS NOT NULL)
   INSERT INTO TCD.WasherModuleOnlineUsageData
     (WasherId,
      StepComportment,
      ModuleId,
      ActualQuantity,
      TimeStamp,
      EcolabWasherId
     )
     SELECT
     @WasherID,
     @StepComportmentNO,
     @MeterID,
     @ActualQuantity,
     GETUTCDATE(),
     @EcolabWasherId
      END  
        SET  @CurrentStepComportmentNO=@CurrentStepComportmentNO+1;
   
  END;
END;