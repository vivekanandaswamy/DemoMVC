﻿
/*     
 ==========================================================================================  
 Purpose:  soft deleting the plant details and auditing the data.     

 Author:  Premchand Yelavarthi     

 --------------------------------------------------------------     
 July-18-2014 ENT: Initial version.     
 ==========================================================================================  
*/ 
CREATE PROCEDURE [TCD].[DeletePlantDetails] (@EcolabAccountNumber NVARCHAR( 
25) = NULL, 
                                                @UserID              INT) 
AS 
  BEGIN 
      SET nocount ON; 

      --DECLARE @Table_name NVARCHAR(1000) = 'plant'								--SQLEnlight SA0004

      UPDATE [TCD].plant 
      SET    is_deleted = 1 
	  ,	LastModifiedByUserId	=	@UserId
      WHERE  ecolabaccountnumber = @EcolabAccountNumber 

	  /*	Commenting this out, since we have resorted to a diff. auditing implementation
      DECLARE @Column_name NVARCHAR(1000) 
      DECLARE Cursor_columnfetch CURSOR FOR 
        SELECT name 
        FROM   sys.all_columns 
        WHERE  Object_name(object_id) = 'plant' 
               AND name NOT IN ( 'Is_Deleted', 'ID', 'GUID' ) 
        ORDER  BY name 

      OPEN Cursor_columnfetch 

      FETCH next FROM Cursor_columnfetch INTO @Column_name 

      WHILE @@fetch_status = 0 
        BEGIN 
            DECLARE @ColumnValue NVARCHAR(1000) 
            DECLARE @sqlCommand NVARCHAR(1000) 
            DECLARE @ParmDefinition NVARCHAR(500) 

            SET @sqlCommand = 'SELECT @ColumnValue = ' + @Column_Name 
                              + ' from  plant where EcolabAccountNumber = ' 
                              + @EcolabAccountNumber 
                              + ' and is_deleted = 1' 
            SET @ParmDefinition = N'@ColumnValue NVarchar(1000) OUTPUT'; 

            EXEC Sp_executesql 
              @sqlCommand, 
              @ParmDefinition, 
              @ColumnValue output; 

            --SELECT @Column_Name,@ColumnValue 
            IF( @ColumnValue IS NOT NULL 
                 OR @ColumnValue IS NULL ) 
              BEGIN 
                  BEGIN 
                      DECLARE @Audit_ID INT 

                      IF NOT EXISTS (SELECT * 
                                     FROM   [TCD].auditcolumns 
                                     WHERE  columnname = @Column_Name 
                                            AND tablename = @Table_name) 
                        BEGIN 
                            INSERT INTO [TCD].auditcolumns 
                            VALUES     (@Column_Name, 
                                        @Table_name) 

                            SELECT @Audit_ID = id 
                            FROM   [TCD].auditcolumns 
                            WHERE  columnname = @Column_Name 
                                   AND tablename = @Table_name 

                            INSERT INTO [TCD].auditcolumnsdetails_New 
                            SELECT @EcolabAccountNumber,@Audit_ID, 
                                   @ColumnValue, 
                                   NULL, 
                                   @UserID, 
                                   Getdate() 
                        END 
                      ELSE 
                        BEGIN 
                            SELECT @Audit_ID = id 
                            FROM   [TCD].auditcolumns 
                            WHERE  columnname = @Column_name 
                                   AND tablename = @Table_name 

                            INSERT INTO [TCD].auditcolumnsdetails_New 
                            SELECT @EcolabAccountNumber,@Audit_ID, 
                                   @ColumnValue, 
                                   NULL, 
                                   @UserID, 
                                   Getdate() 
                        END 
                  END 
              END 

            FETCH next FROM Cursor_columnfetch INTO @Column_name 
        END 

      CLOSE Cursor_columnfetch 

      DEALLOCATE Cursor_columnfetch 
	  */
  END 