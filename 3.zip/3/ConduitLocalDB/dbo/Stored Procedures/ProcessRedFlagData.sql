﻿ 
/*
Purpose					:	Generater Red flags

Author: Suresh k
Date:28-Dec-2015

exe TCD.ProcessRedFlagData 1

*/

CREATE PROC TCD.ProcessRedFlagData(@ShiftId int  )
AS
BEGIN

DECLARE @PartitionOn smalldatetime, @EcolabAccountNumber nvarchar( 25)

  SELECT @EcolabAccountNumber =EcolabAccountNumber
      FROM TCD.Plant p

IF EXISTS (SELECT 1 FROM TCD.BatchData bd WHERE bd.ShiftId = @ShiftId and bd.EndDate IS NOT NULL)
BEGIN
	select @PartitionOn=MAX( PartitionOn) from TCD.BatchData bd where bd.ShiftId = @ShiftId

	EXEC TCD.RedFlagGenerationProductionEfficiency  @ShiftId  , @PartitionOn  , @EcolabAccountNumber
	EXEC TCD.RedFlagGenerationFinancials  @ShiftId  , @PartitionOn  , @EcolabAccountNumber
	EXEC TCD.RedFlagGenerationResources  @ShiftId  , @PartitionOn  , @EcolabAccountNumber
	EXEC TCD.RedFlagGenerationProcessValidation  @ShiftId  , @PartitionOn  , @EcolabAccountNumber
END
	
END