﻿
CREATE PROCEDURE [TCD].[PagingDuplicateProc] (
			  @ProgramId INT
			  ,@Name NVARCHAR(100)
			  ,@Pieces INT = NULL
			  ,@EcolabTextileCategoryId INT = NULL
			  ,@CategoryName varchar(50) = null
			  ,@EcolabSaturationId INT = NULL
			  ,@EcolabSaturationName varchar(50) = null
			  ,@PlantProgramId INT = NULL
			  ,@PlantProgramName varchar(50) = null
			  ,@TextileId INT = NULL
			  ,@ChainTextileCategory varchar(50) = null
			  ,@Rewash BIT = NULL
			  ,@Weight DECIMAL = NULL
			  ,@UserID INT = NULL
			  ,@Message varchar(100) OUTPUT) 
AS 
  BEGIN 
      SET nocount ON;
	  
	  SET	@PlantProgramName			=			ISNULL(@PlantProgramName, NULL)			--SQLEnlight SA0029
	  SET	@EcolabSaturationName		=			ISNULL(@EcolabSaturationName, NULL)		--SQLEnlight SA0029

		 /*	commenting this out, since we have resorted to a diff. implementation
	   DECLARE @Table_name NVARCHAR(1000) = 'programmaster' 
      --Only single table ussing for customer 
      DECLARE @Column_Name NVARCHAR(1000) = 'Name' 
      DECLARE @Column_name1 NVARCHAR(1000) = 'Pieces' 
	  DECLARE @Column_Name2 NVARCHAR(1000) = 'EcolabTextileCategoryId' 
      DECLARE @Column_name3 NVARCHAR(1000) = 'EcolabSaturationId' 
	  DECLARE @Column_Name4 NVARCHAR(1000) = 'PlantProgramId' 
      DECLARE @Column_name5 NVARCHAR(1000) = 'TextileId' 
	  DECLARE @Column_Name6 NVARCHAR(1000) = 'Rewash' 
      DECLARE @Column_name7 NVARCHAR(1000) = 'Weight' 

	  Declare  @OldName NVARCHAR(100) = NULL
	  Declare  @OldPieces INT = NULL
	  Declare  @OldEcolabTextileCategoryId INT = NULL
	  Declare  @OldEcolabSaturationId INT = NULL
	  Declare  @OldPlantProgramId INT = NULL
	  Declare  @OldTextileId INT = NULL
	  Declare  @OldRewash BIT = NULL
	  Declare  @OldWeight DECIMAL = NULL

	  /*Capture all old values if exists */
	  SELECT @OldName =Name ,
		@OldPieces=Pieces ,
		@OldEcolabTextileCategoryId=EcolabTextileCategoryId ,
		@OldEcolabSaturationId =EcolabSaturationId	,
		@OldPlantProgramId =PlantProgramId ,
		@OldTextileId=ChainTextileId ,
		@OldRewash=Rewash 
		,@OldWeight=[Weight] 
		FROM [TCD].ProgramMaster WHERE ProgramId=@ProgramId
	Deprecated	*/

      SET		@Message			=			ISNULL(@Message, NULL)			--SQLEnlight SA0121

	  IF NOT EXISTS (SELECT 1 FROM [TCD].ProgramMaster WHERE ProgramId = @ProgramId)
	  BEGIN
		SELECT @ProgramId = MAX(ProgramId)+1 FROM [TCD].ProgramMaster 
	  /*Insert record if program not exists */

	  IF exists(select 1 from [TCD].ProgramMaster where Name=@Name)
	  begin
	  Set @Message = 'ALREADYE EXISTED'
SELECT @Message
	  end
	  else
	  begin

		INSERT INTO [TCD].ProgramMaster (ProgramId
			  ,Name
			  ,EcolabAccountNumber
			  ,Pieces
			  ,EcolabTextileCategoryId
			  ,EcolabSaturationId
			  ,PlantProgramId
			  ,ChainTextileId
			  ,Rewash
			  ,[Weight])
		VALUES (@ProgramId
			  ,@Name
			  ,(SELECT TOP 1 EcolabAccountNumber FROM [TCD].Plant WHERE Is_Deleted=0)
			  ,@Pieces
			  ,@EcolabTextileCategoryId
			  ,@EcolabSaturationId
			  ,@PlantProgramId
			  ,@TextileId
			  ,@Rewash
			  ,@Weight)
			  END
	  END
	  ELSE
	  BEGIN
	  /*Update record if program exists */
	  UPDATE [TCD].ProgramMaster SET 
			   Name = @Name
			  ,Pieces = @Pieces
			  ,EcolabTextileCategoryId = @EcolabTextileCategoryId
			  ,EcolabSaturationId = @EcolabSaturationId
			  ,PlantProgramId = @PlantProgramId
			  ,ChainTextileId = @TextileId
			  ,Rewash = @Rewash
			  ,[Weight] = @Weight WHERE ProgramId = @ProgramId
	  END
	
	     /* Audting for Program master insert */ 
		 /*	commenting this out, since we have resorted to a diff. implementation
            IF( @Name IS NOT NULL ) 
              BEGIN 
			  EXEC usp_AuditChangedColumns @Column_Name,@Table_name,@OldName,@Name,@UserID
              END 
			IF( @Pieces IS NOT NULL ) 
              BEGIN 
			  EXEC usp_AuditChangedColumns @Column_Name1,@Table_name,@OldPieces,@Pieces,@UserID
              END 
			IF( @EcolabTextileCategoryId IS NOT NULL ) 
              BEGIN 
			  EXEC usp_AuditChangedColumns @Column_Name2,@Table_name,@OldEcolabTextileCategoryId,@EcolabTextileCategoryId,@UserID
              END 
			IF( @EcolabSaturationId IS NOT NULL) 
              BEGIN 
			  EXEC usp_AuditChangedColumns @Column_Name3,@Table_name,@OldEcolabSaturationId,@EcolabSaturationId,@UserID
			  END
			IF( @PlantProgramId IS NOT NULL ) 
              BEGIN 
			  EXEC usp_AuditChangedColumns @Column_Name4,@Table_name,@OldPlantProgramId,@PlantProgramId,@UserID
              END 
			IF( @TextileId IS NOT NULL ) 
              BEGIN 
			  EXEC usp_AuditChangedColumns @Column_Name5,@Table_name,@OldTextileId,@TextileId,@UserID
              END 
			IF( @Rewash IS NOT NULL ) 
              BEGIN 
			  EXEC usp_AuditChangedColumns @Column_Name6,@Table_name,@OldRewash,@Rewash,@UserID
              END 
			IF( @Weight IS NOT NULL ) 
              BEGIN 
			  EXEC usp_AuditChangedColumns @Column_Name7,@Table_name,@OldWeight,@Weight,@UserID
              END 
	Deprecated	*/

  END