--exec [TCD].[GetOperationSummaryReport] @Corporate=N'',@Country=N'',@Region=N'',@EcolabAccountNumber=N'',@Machine=N'',@machineGroup=N'',@Formula=N'',@MachineType=N'',
--@Category=N'',@FromDate='2014-12-01 00:00:00',@ToDate='2014-12-22 00:00:00',@GroupId=N'',@MachineInternalId=N'',
--@FormulaWise=1,@EcolabTextileWise=0,@TextileCareCustomerWise=0,
--@Id = NULL,@IsDrillDown = 0,@SwitchMode = 1,
----@Id = 5,@IsDrillDown = 1,@SwitchMode = 1,
--@DayWise=0,@WeekWise=0,@MonthWise=1,@QuarterWise=0,@yearWise = 0,@SortColumnID = 0,@SortDirection = 'DESC',@UserId = 0,@ReportId = 10





CREATE PROCEDURE [TCD].[GetOperationSummaryReport] (
											@Corporate Varchar(max) = '',
											 @Country Varchar(max) = '',
											 @Region Varchar(max) = '',
											 @EcolabAccountNumber Nvarchar(25) = '',
											 @Machine Varchar(max) = '', 
											 @machineGroup Varchar(max) = '',
											 @Formula Varchar(max) = '',
											 @MachineType Varchar(20)= '',
											 @Category Varchar(max) = '',
											 @FromDate Date = '',
											 @ToDate Date = '',
											 @GroupId Varchar(max) = '',
											 @MachineInternalId Varchar(max) = '',
											  --@Customer Varchar(max) = '',
											 @FormulaWise bit = NULL,
											 @EcolabTextileWise bit = NULL,
											 @TextileCareCustomerWise bit = NULL,

											 @Id Varchar(100) = '',
											 @IsDrillDown BIT = 0,
											 @SwitchMode INT = NULL,
											 @DayWise bit = NULL,
											 @WeekWise bit = NULL,
											 @MonthWise bit = NULL,
											 @QuarterWise bit = NULL,
											 @yearWise Bit = NULL,

											 @SortColumnID INT = NULL,
											 @SortDirection Varchar(100) = '',
											 @UserId Int = NULL,
											 @ReportID INT = NULL

											 								 
										   )
AS   
BEGIN   
SET NOCOUNT ON;   

DECLARE @ReportGenerated INT = 6, 
	   @SortField Varchar(100) = '',
	   @SQLStatement varchar(max),
@FormulaId Varchar(100) = NULL,
 @EcolabTextileId Varchar(100) = NULL,
 @TextileCareCustomerId Varchar(100) = NULL,
 @ChainFormulaId Varchar(100) = NULL

 SELECT @FormulaId =  CASE WHEN @SwitchMode = 1 THEN @Id ELSE '' END, 
	   @EcolabTextileId =  CASE WHEN @SwitchMode = 2 THEN @Id ELSE '' END,
	   @TextileCareCustomerId = CASE WHEN @SwitchMode = 3 THEN @Id ELSE '' END,
	   @ChainFormulaId = CASE WHEN @SwitchMode = 4 THEN @Id ELSE '' END

/* Inserting the record into Report History */

INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)
SELECT @EcolabAccountNumber,UM.UserId,
	  UM.LoginName,
	  GETUTCDATE(),
	  @ReportGenerated,
	  CASE WHEN @ReportGenerated = 6
		THEN 'Generated Report : OperationSummaryReport' END
	  FROM TCD.UserMaster UM
	    WHERE	UM.EcolabAccountNumber =	@EcolabAccountNumber AND UM.UserId = @UserId

/* Completed the record insertion into Report History */

  IF(@Id IS NULL AND @IsDrillDown = 0)
	   BEGIN
	   
	   exec [TCD].[GetOperationSummarySwitchReport] @Corporate,@Country,@Region,@EcolabAccountNumber,@Machine,@machineGroup,@Formula,@MachineType,
	   @Category,@FromDate,@ToDate,@GroupId,@MachineInternalId,
	   @FormulaWise,@EcolabTextileWise,@TextileCareCustomerWise,@SortColumnID,@SortDirection, @UserId,@IsDrillDown

	   END
    
    IF(@Id IS NOT NULL AND @IsDrillDown = 1)
	   BEGIN
	   DECLARE @Date Date = NULL
	   IF(@DayWise = 1) BEGIN SET @Date = CAST(@FromDate AS DATE) END

	   exec [TCD].[OperationSummaryDrillDownReport] @Corporate ,@Country ,@Region ,@EcolabAccountNumber ,@Machine ,@machineGroup ,@Formula ,@MachineType ,
	   @Category ,@FromDate,@ToDate,@GroupId ,@MachineInternalId ,
	   @FormulaId,@EcolabTextileId,@TextileCareCustomerId,@DayWise,@WeekWise,
	   @MonthWise,@QuarterWise,@YearWise,@Date,@SortColumnID,@SortDirection,@UserId,@ReportID,@IsDrillDown
	  
			
	   END

END