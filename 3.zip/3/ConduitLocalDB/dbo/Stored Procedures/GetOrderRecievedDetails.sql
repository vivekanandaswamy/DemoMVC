﻿/*

Stored Procedure	:	[TCD].[GetOrderRecievedDetails]

Purpose				:	To Get Order recieved details

Parameters			:	@EcolabAccountNumber
*/

CREATE PROCEDURE [TCD].[GetOrderRecievedDetails]
							@EcolabAccountNumber		NVARCHAR(25)			 =	NULL
AS
BEGIN

	SELECT 
		ci.Id						AS			Id
,		ci.EcolabAccountNumber		AS			EcolabAccountNumber
,		ci.ProductId				AS			ProductId
,		ci.InventoryDate			AS			InventoryDate
,		ci.UnitSize					AS			UnitSize
,		ci.OpeningQuantity			AS			OpeningQuantity
,		ci.AdjustedQuantity			AS			AdjustedQuantity
,		ci.PurcharsedQuantity		AS			PurcharsedQuantity
,		ci.ClosingQuantity			AS			ClosingQuantity
,		ci.UsedQuantity				AS			UsedQuantity
,		ci.MyServiceInventoryId		AS			MyServiceInventoryId
	FROM TCD.ChemicalInventory ci WHERE ci.EcolabAccountNumber = @EcolabAccountNumber
END


