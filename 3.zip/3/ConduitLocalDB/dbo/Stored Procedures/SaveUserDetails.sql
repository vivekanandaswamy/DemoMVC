CREATE PROCEDURE [TCD].[SaveUserDetails] (

@ContactId									INT
,@FirstName									NVARCHAR(100)
,@LastName									NVARCHAR(100)
,@LoginName									NVARCHAR(100)
,@Password									NVARCHAR(100)
,@MailId									NVARCHAR(100)			= NULL
,@ContactNo									NVARCHAR(100)			= NULL
,@RoleId									INT
,@UserId									INT
,@EcolabAccountNumber						NVARCHAR(25)
,@CurrencyCode								NVARCHAR(100)
,@UOMID										INT
,@Scope										VARCHAR(100)						OUTPUT
,@OutputUserId								INT						=	NULL	OUTPUT
,@LastModifiedTimestampAtCentral			DATETIME				=	NULL
,@OutputLastModifiedTimestampAtLocal		DATETIME				=	NULL	OUTPUT
)

AS
BEGIN
    SET NOCOUNT ON;
	DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()
	
	DECLARE
			@OutputList						AS	TABLE		(
			UserId							INT
		,	LastModifiedTimestamp			DATETIME
		)
    DECLARE
	    @OUTput VARCHAR(100) = '';

SET		@Scope										=			ISNULL(@Scope, NULL)										--SQLEnlight SA0121
SET		@OutputLastModifiedTimestampAtLocal			=			ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight
SET		@OutputUserId								=			ISNULL(@OutputUserId, NULL)									--SQLEnlight
SET		@LastModifiedTimestampAtCentral				=			ISNULL(@LastModifiedTimestampAtCentral, NULL)				--SQLEnlight SA0029

SELECT	@UOMID = UOMId FROM TCD.Plant WHERE	TCD.Plant.EcolabAccountNumber	=	@EcolabAccountNumber	

SELECT	@CurrencyCode	=  CurrencyCode FROM TCD.Plant  WHERE	EcolabAccountNumber	=	@EcolabAccountNumber	

    IF @ContactId IS NOT NULL
					AND 
					EXISTS(SELECT 1
							 FROM TCD.UserMaster
							 WHERE ContactId = @ContactId
							   AND IsActive = 1
						   )
	   BEGIN
		  SET @OutPut = '302';
		  SET @Scope = @OutPut;
		  SELECT @Scope;
	   END;

    ELSE
	   BEGIN
		  IF EXISTS (SELECT 1
					FROM TCD.UserMaster
					WHERE LoginName = @LoginName
					  AND IsActive = 1)

			 BEGIN
				BEGIN
					 SET @OutPut = '301';
					 SET @Scope = @OutPut;
					 SELECT @Scope;
				END;
			 END;
			   IF EXISTS (SELECT 1 FROM TCD.UserMaster WHERE Email = @MailId AND ISACTIVE=1)
				  BEGIN
					BEGIN Set @OutPut = '501'   
					SET @Scope = @OutPut 
					Select @Scope  
					END
				 END
		  ELSE
			 BEGIN
				IF @ContactId IS NOT NULL
				    BEGIN

					   UPDATE TCD.PlantContact
						SET ContactFirstName = @FirstName,
						    ContactLastName = @LastName,
						    ContactEmail = @MailId,
						    ContactMobilePhone = @ContactNo,
						    LastModifiedByUserId = @UserId
						WHERE ID = @ContactId
						  AND EcolabAccountNumber = @EcolabAccountNumber;

					   INSERT INTO TCD.UserMaster (
					   FirstName,
					   LastName,
					   FullName,
					   LoginName,
					   Password,
					   Email,
					   Phone,
					   LanguageId,
					   IsActive,
					   LastModifiedByUserId,
					   EcolabAccountNumber,
					   ContactId,
					   CurrencyCode,
					   UOMId)
					   	OUTPUT
							inserted.UserId						AS			Id
						,	inserted.LastModifiedTime			AS			LastModifiedTimestamp
						INTO
							@OutputList	(
							UserId
						,	LastModifiedTimestamp
						)
					   VALUES (
						    @FirstName,
						    @LastName,
							@FirstName
							+
							' '
							+
							@LastName,
							@LoginName,
							@Password,
							@MailId,
							@ContactNo,
							(SELECT LanguageId
							   FROM TCD.Plant
							   WHERE EcolabAccountNumber = @EcolabAccountNumber),
							1,
							@UserId,
							@EcolabAccountNumber,
							@ContactId,
							@CurrencyCode,
							@UOMId);
				    END;
				ELSE
				    BEGIN
					   INSERT INTO TCD.UserMaster (FirstName,
											 LastName,
											 FullName,
											 LoginName,
											 Password,
											 Email,
											 Phone,
											 LanguageId,
											 IsActive,
											 LastModifiedByUserId,
											 EcolabAccountNumber,
											 CurrencyCode,
											UOMId)
				OUTPUT
					inserted.UserId						AS			Id
				,	inserted.LastModifiedTime			AS			LastModifiedTimestamp
				INTO
					@OutputList	(
					UserId
				,	LastModifiedTimestamp
				)
					   VALUES (	@FirstName,
								@LastName,
								@FirstName
								+
								' '
								+
								@LastName,
								@LoginName,
								@Password,
								@MailId,
								@ContactNo,
								(SELECT LanguageId
								   FROM TCD.Plant
								   WHERE EcolabAccountNumber = @EcolabAccountNumber),
								1,
								@UserId,
								@EcolabAccountNumber,
								@CurrencyCode,
								@UOMId);
				    END;
				DECLARE
					@NewUserNumber INT = SCOPE_IDENTITY();
				INSERT INTO TCD.UserInRole (
									   EcoLabAccountNumber,
									   UserId,
									   RoleId,
									   LastModifiedByUserId)
				VALUES( 
					   @EcolabAccountNumber,
					   @NewUserNumber,
					   @RoleId,
					   @UserId );
				INSERT INTO TCD.UserProfile (UserId,
									    EcolabAccountNumber)
				VALUES( @NewUserNumber,
					   @EcolabAccountNumber);
			 END;
	   END;
SELECT	TOP 1	
		@OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp
	,	@OutputUserId				=	O.UserId
FROM	@OutputList	O
    SET NOCOUNT OFF;
END;