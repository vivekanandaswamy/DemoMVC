CREATE PROCEDURE [TCD].[ReportProductionSummary]   
/**************************************************************

EXEC [TCD].[ReportProductionSummary] @startdate = '2015-01-01 00:00:00',@enddate = '2016-01-01 00:00:00',@Viewtype  = '8',@Subview = '21',
          @Drillvalue = '',@EcolabAccountNumber = '040242802',@MachineType = '', @MachineGroup  = '',@Machine  = '',   
          @EcolabCategory  = '',@ChainCategory  = '', @PlantFormula  = '', @ChainFormula = '', @Customer  = '',  
          @SortColumnId  = 0,@SortDirection  = 'Desc',@CurrencyCode = '', @UserId = 1, @FormulaSegement ='',  
          @FormulaCategory='',@Formula=''

**************************************************************/

     @startdate datetime = '',  
     @enddate datetime =   '',  
     @Viewtype varchar(30) = '',  
     @Subview varchar(30)= '',  
     @Drillvalue varchar(100)= '',  
     @EcolabAccountNumber Nvarchar(25) = '',  
     @MachineType VARCHAR(20)= '',  
     @MachineGroup VARCHAR(MAX) = '',  
     @Machine VARCHAR(MAX) = '',  
     @EcolabCategory VARCHAR(MAX) = '',  
     @ChainCategory VARCHAR(MAX) = '',  
     @PlantFormula  VARCHAR(MAX) = '',  
     @ChainFormula VARCHAR(MAX) = '',  
     @Customer VARCHAR(MAX) = '',  
     @SortColumnId int = 0,  
     @SortDirection varchar(4) = '',  
     @CurrencyCode varchar(3) = '',  
     @UserId INT = NULL,
	 @FormulaSegement VARCHAR(MAX)='', --Formula segment,
	 @FormulaCategory VARCHAR(MAX)='', --Formula category
	 @Formula VARCHAR(MAX)='' --Formula
AS     
BEGIN     
SET NOCOUNT ON   
  
    DECLARE @InputStartDate DATETIME = DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),@startdate) ,
    @InputEndDate DATETIME =DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),@Enddate)  

    
	--SET @startdate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@startdate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@startdate AS time)) AS DateTime))  
	--SET @EndDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndDate AS time)) AS DateTime))  
	--SELECT @startdate,@enddate 

	DECLARE @ReportGenerated INT = 6,@Month INT = MONTH(GETDATE()),@CorrectionVariable Decimal(18,2),@PlantTargetProduction decimal(18,2)
	,@UomId int  

     	SELECT @UomId= p.UOMId FROM TCD.Plant p 
	-- Inserting the record into Report History   
	INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)  
	SELECT @EcolabAccountNumber,UM.UserId,UM.LoginName,GETUTCDATE(),@ReportGenerated,  
	CASE WHEN @ReportGenerated = 6  
	THEN 'Generated Report : Production Summary Report' END  
	FROM TCD.UserMaster UM  
	WHERE UM.EcolabAccountNumber = @EcolabAccountNumber AND UM.UserId = @UserId  
	-- Completed the record insertion into Report History   
  
    -- Return Table set  
    DECLARE @resultSet Table  
    (  
      ShiftId Int,  
      DateRange varchar(100),  
      TotalLoad Decimal(18,2) ,  
      WasherEfficiency Decimal(18,2),  
      PlantTargetLoad Decimal(18,2) ,  
      Numberofbatches INT,  
      [ActualRunTime] Decimal(30,10) NULL,  
      [TargetRunTime] Decimal(30,10) NULL,  
      Viewtype varchar(100) NULL,  
      Subview varchar(100) NULL,  
      Id int NULL  ,
	 SortOrder  int NULL    
    )  
    DECLARE @CorrectionFactor TABLE   
	(  
	 [ShiftId] [int] NULL,  
	 MachineId INT NULL,  
	 [ActualProduction] [int] NULL,  
	 [StandardProduction] [int] NULL,  
	 [PlantTargetProd] [int] NULL,  
	 [ActualRunTime] [int] NULL,  
	 [TargetRunTime] [int] NULL,  
	 ManualInputWeight INT,  
	 ManulainputsNoofloads INT  
	)  
  
	DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))  
	INSERT INTO @MachineTypeTable EXEC [TCD].[CharlistToTable] @MachineType,','  
  
	DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))  
	INSERT INTO @WasherGroupTable EXEC [TCD].[CharlistToTable] @machineGroup,','    
  
	DECLARE @MachineTable TABLE(Machine Varchar(100))  
	INSERT INTO @MachineTable EXEC [TCD].[CharlistToTable] @Machine,','  
  
	DECLARE @EcolabCategoryTable TABLE(EcolabCategory Varchar(100))  
	INSERT INTO @EcolabCategoryTable EXEC [TCD].[CharlistToTable] @EcolabCategory,','  
  
	DECLARE @ChainCategoryTable TABLE(ChainCategory Varchar(100))  
	INSERT INTO @ChainCategoryTable EXEC [TCD].[CharlistToTable] @ChainCategory,','  
  
	DECLARE @PlantFormulaTable TABLE(PlantFormula Varchar(100))  
	INSERT INTO @PlantFormulaTable EXEC [TCD].[CharlistToTable] @PlantFormula,','  
  
	DECLARE @ChainFormulaTable TABLE(ChainFormula Varchar(100))  
	INSERT INTO @ChainFormulaTable EXEC [TCD].[CharlistToTable] @ChainFormula,','  
  
	DECLARE @CustomerTable TABLE(Customer Varchar(100))  
	INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','  
  	 
	DECLARE @FormulaSegmentTable TABLE(FormulaSegment Varchar(1000))
	INSERT INTO @FormulaSegmentTable EXEC [TCD].[CharlistToTable] @FormulaSegement,','
	  
	DECLARE @FormulaCategoryTable TABLE(FormulaCategory Varchar(1000),Type CHAR(1))
	INSERT INTO @FormulaCategoryTable(FormulaCategory) EXEC [TCD].[CharlistToTable] @Formulacategory,',' 
  
	--Below 1000 Ecolab category
	UPDATE @FormulaCategoryTable SET TYPE='E' WHERE FormulaCategory<1000
	--Above 1000 consider as Chain category
	UPDATE @FormulaCategoryTable SET TYPE='C' WHERE FormulaCategory>=1000
	--Rollbacking to actual ID
	UPDATE @FormulaCategoryTable SET FormulaCategory=FormulaCategory-1000 WHERE TYPE='C'
 

	INSERT INTO @EcolabCategoryTable(EcolabCategory)
	SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='E' 

	INSERT INTO @ChainCategoryTable(ChainCategory)
	SELECT FormulaCategory FROM @FormulaCategoryTable WHERE Type='C'

	--Value Assigning
	IF (EXISTS(SELECT * FROM @EcolabCategoryTable) AND @FormulaCategory!='')
	BEGIN
		SET @EcolabCategory=@FormulaCategory
	END
	IF (EXISTS(SELECT * FROM @ChainCategoryTable) AND @FormulaCategory!='')
	BEGIN
		SET @ChainCategory=@FormulaCategory
	END

 
	DECLARE @FormulaTable TABLE(Formula Varchar(1000),Type CHAR(1))
	INSERT INTO @FormulaTable(Formula) EXEC [TCD].[CharlistToTable] @Formula,',' 
      
	--Plant fomula   
	INSERT INTO @PlantFormulaTable(PlantFormula) 
	SELECT Formula FROM @FormulaTable 
	--chain formula   
	INSERT INTO @ChainFormulaTable(ChainFormula) 
	SELECT Formula FROM @FormulaTable 
  
    --Value Assigning
	IF (EXISTS(SELECT * FROM @PlantFormulaTable) AND @Formula!='')
	BEGIN
		SET @PlantFormula=@Formula
	END
	IF (EXISTS(SELECT * FROM @ChainFormulaTable) AND @Formula!='')
	BEGIN
		SET @ChainFormula=@Formula
	END
	--Formula end

	 DECLARE @ShiftTargetProduction TABLE   
	(  
	 [ShiftId] [int] NULL,  	
	 [TargetProduction] [int] NULL
	
	)  

	INSERT INTO @ShiftTargetProduction([ShiftId],TargetProduction)
	SELECT [ShiftId],(CASE WHEN @UomId =1 THEN ISNULL(PS.TargetProduction*1000,0)	ELSE   ISNULL(PS.TargetProduction,0) * 2204.62 END) 
	FROM TCD.ProductionShiftData PS WHERE PS.[StartDateTime] >= @startdate  AND PS.[StartDateTime] <  @enddate 

	INSERT INTO @CorrectionFactor  
	(  
		[ShiftId],  
		[MachineId] ,  
		[ActualProduction] ,  
		[StandardProduction] ,  
		[PlantTargetProd] ,  
		[ActualRunTime] ,  
		[TargetRunTime],  
		ManualInputWeight,  
		ManulainputsNoofloads     
	)  
	SELECT   
	PS.[ShiftId],  
	SPD.[MachineId],  
	ISNULL(SUM(ISNULL(SPD.[ActualProduction],0))+SUM(ISNULL(MIP.ActualWeight,0)),0), 	
	ISNULL(SUM(SPD.StandardProduction),0), 	  
	ISNULL(max(PS.TargetProduction),0),	
	SUM(SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0)),  
	SUM(SPD.[TargetRunTime] + ISNULL(SPD.TargetTurnTime,0)),  
	SUM(ISNULL(MIP.ActualWeight,0)),SUM(ISNULL(MIP.NoofLoads,0))  
	FROM  TCD.ShiftProductionDataRollup SPD   
	 INNER JOIN TCD.MachineSetup ms ON SPD.MachineId = ms.WasherId 
	INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId  
	INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId   
	LEFT OUTER JOIN --Manual Production Details appending  
	(  
		SELECT WasherId,FormulaId,CONVERT(DATE,RecordedDate) AS LoadDate,SUM(ISNULL(Value,0)) AS ActualWeight,  
		ISNULL(COUNT(CONVERT(DATE,RecordedDate)),0) AS NoofLoads FROM  
		TCD.ManualProduction MP  
		GROUP BY WasherId,FormulaId,CONVERT(DATE,RecordedDate)  
	)MIP ON MIP.WasherId=SPD.EcolabWasherId AND MIP.FormulaId=SPD.ProgramMasterId AND MIP.LoadDate=CONVERT(DATE,PS.StartDateTime)  
	 WHERE  isNull(ms.IsPony,0) = 0  AND 
		CASE @StartDate                                                                                  
		WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                  
		ELSE CASE WHEN PS.[StartDateTime] >= @startdate  AND PS.[StartDateTime] <  @enddate THEN 'TRUE'END                                                          
		END='TRUE'   
	GROUP BY MachineId,PS.ShiftId;  
  
	--WITH CTE (ShiftId,PlantTargetProd) AS  
	--(  
	--	SELECT ShiftId, SUM(DISTINCT SPD.[PlantTargetProd]) FROM @CorrectionFactor SPD GROUP BY ShiftId  
	--)  
	--SELECT @PlantTargetProduction = SUM(PlantTargetProd) FROM CTE;  
    

   
    
	declare @Factor TABLE (MachineId int,ShiftId int,TargetProduction decimal(18,5),CorrectionFactor decimal(18,5)
	,PlantEfficiency decimal(18,5),PlantTargetProduction decimal(18,5))
;	WITH CTE (MachineId,ShiftId,PlantEfficiency)  
	AS  
	(  
		SELECT   
		MachineId,  
		ShiftId,
		CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,4))/   
		NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,4)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,4)),0),1) *   
		COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,4)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,4)),0),0)),0), 1) AS decimal(18,4))     
 
		FROM @CorrectionFactor SPD GROUP BY MachineId,ShiftId  
	) ,
	ShiftWiseEfficiencyCTE(ShiftId,TargetProductionShift) 
	AS(SELECT  ShiftId, sum(PlantEfficiency)
	 
		FROM CTE GROUP BY ShiftId  )

insert into @Factor(MachineId,ShiftId,TargetProduction,CorrectionFactor,PlantEfficiency,PlantTargetProduction)
	
	SELECT c.MachineId,stp.ShiftId, c.PlantEfficiency *  ( ISnull( stp.TargetProduction,0)/cast( ISNULL( sfc.TargetProductionShift,1) AS decimal) ),
	( ISnull( stp.TargetProduction,0)/cast( ISNULL( sfc.TargetProductionShift,1) AS decimal) ),c.PlantEfficiency,stp.TargetProduction
	FROM CTE c 
	INNER JOIN @ShiftTargetProduction stp ON c.ShiftId=stp.ShiftId 
	INNER JOIN ShiftWiseEfficiencyCTE sfc ON c.ShiftId=sfc.ShiftId




	--SELECT @CorrectionVariable = @PlantTargetProduction/NULLIF(SUM(PlantEfficiency),0) FROM CTE  
  
      
	 DECLARE @ProductionSummaryTable TABLE
	 (  
			[ShiftId] [int] NULL,  
			[ShiftName] Varchar(100) NULL,  
			RecordDate date,   
			[StartDateTime] [datetime] NULL,  
			[EndDateTime] [datetime] NULL,  
			[MachineId] [int] NULL,  
			[EcolabWasherId] [int] NULL,  
			[ActualProduction] [int] NULL,  
			[StandardProduction] [int] NULL,  
			[NoOfLoads] [int] NULL,  
			[LoadEfficiency] [decimal](18, 2) NULL,  
			[TimeEfficiency] [decimal](18, 2) NULL,  
			TotalEfficiency [decimal](18, 2) NULL,  
			[PlantTargetProd] [int] NULL,  
			[ActualRunTime] [int] NULL,  
			[TargetRunTime] [int] NULL,  
			[ShiftRunTime] Decimal(30,10)  NULL,  
			RowNumberID INT NULL,  
			ProgramMasterID INT NULL,
			EcolabTextileId int,
			ChainTextileId int,
			ChainProgaramId int,
			FormulaSegmentID INT,
			CustomerId int,
			IndividualShiftRunTime Decimal(30,10) 
	)  
	 INSERT INTO @ProductionSummaryTable  
	 (  
	 [ShiftId] ,[ShiftName] ,RecordDate, [StartDateTime] ,[EndDateTime] ,[MachineId]  ,[EcolabWasherId]  ,  
	 [ActualProduction] ,[StandardProduction] ,[NoOfLoads] ,[LoadEfficiency],[TimeEfficiency] ,TotalEfficiency ,  
	 [PlantTargetProd],[ActualRunTime] ,[TargetRunTime] ,[ShiftRunTime] ,RowNumberID ,ProgramMasterID,
	 EcolabTextileId,ChainTextileId,ChainProgaramId,FormulaSegmentID,CustomerId
	 )  
	 SELECT   
	 SPD.[ShiftId],  
	 PS.ShiftName,  
	 CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date),  
	 DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]),  
	 DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[EndDateTime]),          
	 SPD.[MachineId],  
	 SPD.[EcolabWasherId],  
	 SPD.[ActualProduction],  
	 SPD.StandardProduction,  
	 SPD.[NoOfLoads],  
	 SPD.[LoadEfficiency],  
	 SPD.[TimeEfficiency],  
	 (SPD.[LoadEfficiency] * SPD.TimeEfficiency),  
	 SPD.[PlantTargetProd],  
	 SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0),  
	 SPD.[TargetRunTime] + ISNULL(SPD.TargetTurnTime,0),  
	 DATEDIFF(Second,ps.StartDateTime,PS.EndDateTime) +  
	 ISNULL(  
	 (  
		 SELECT  
		 SUM(SPD.[ActualRunTime] + ISNULL(SPD.ActualTurnTime,0))  
		  FROM TCD.ShiftProductionDataRollup SPD   
		 INNER JOIN TCD.ProductionShiftData PSD ON SPD.ShiftId = PSD.ShiftId  
		 INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId   
		 WHERE   
		 PSD.[StartDateTime] = PS.StartDateTime AND PSD.[StartDateTime] = PS.EndDateTime AND PS.ShiftName = 'No Shift'  
	 ),0),  
	 ROW_NUMBER() OVER(Partition BY SPD.ProgramMasterId, SPD.[EcolabWasherId], CAST(DATEADD(SECOND,DATEDIFF(SECOND,getutcdate(),GETDATE()),PS.[StartDateTime]) AS date)  
	 ORDER BY SPD.ProgramMasterId, SPD.[EcolabWasherId] ),  
	 SPD.ProgramMasterId,
	 SPD.EcolabTextileId,SPD.ChainTextileId,SPD.ChainProgaramId,
	 CASE WHEN SPD.ChainProgaramId IS NOT NULL 
		THEN ChainPlant.FormulaSegmentId ELSE FS1.FormulaSegmentID END AS Formulasegment,
	 SPD.CustomerId
	       
	 FROM TCD.ShiftProductionDataRollup SPD   
	 INNER JOIN TCD.ProductionShiftData PS ON SPD.ShiftId = PS.ShiftId  
	 INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
	 INNER JOIN TCD.MachineSetup ms ON SPD.MachineId = ms.WasherId  
	 LEFT OUTER JOIN
	   (
		   --IF Chain Plant
		   SELECT PCP.PlantProgramId,PCP.PlantChainId,PCP.ChainTextileCategoryId,PCP.EcolabTextileCategoryId,
		   PCP.FormulaSegmentId,PCP.EcolabSaturationId
		   FROM TCD.PlantChainProgram PCP 
		   LEFT OUTER JOIN TCD.ChainTextileCategory CTC ON CTC.TextileId=PCP.ChainTextileCategoryId
		   LEFT OUTER JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId=PCP.EcolabTextileCategoryId
		   LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=PCP.FormulaSegmentId
		   LEFT OUTER JOIN TCD.EcolabSaturation ES ON ES.EcolabSaturationId=PCP.EcolabSaturationId
	   )ChainPlant ON SPD.ChainProgaramId=ChainPlant.PlantProgramId

	 --LEFT OUTER JOIN TCD.EcolabTextileCategory ETC1 ON ETC1.TextileId=PM.EcolabTextileCategoryId
	 LEFT OUTER JOIN TCD.FormulaSegments FS1 ON FS1.FormulaSegmentID=PM.FormulaSegmentId
	--LEFT OUTER JOIN TCD.EcolabSaturation ES1 ON ES1.EcolabSaturationId=PM.EcolabSaturationId
	WHERE isNull(ms.IsPony,0) = 0  
	AND   
		CASE @StartDate                                                                                  
		WHEN '' THEN Case WHEN MONTH(CAST(PS.[StartDateTime] AS DATE)) = @Month Then  'TRUE' END                                                                                  
		ELSE CASE WHEN PS.[StartDateTime] >= @startdate AND PS.[StartDateTime] <=  @enddate THEN 'TRUE'END                                                          
		END='TRUE'   
	AND  
		CASE @MachineType     
		WHEN '' THEN 'TRUE'           
		ELSE                                                        
		CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE        
		MS.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable))) THEN 'TRUE' END                                                        
		END='TRUE'       
	AND   
		CASE @machineGroup     
		WHEN '' THEN 'TRUE'           
		ELSE                                                        
		CASE WHEN SPD.MachineId IN (SELECT MS.WasherId FROM TCD.MachineSetup MS WHERE        
		MS.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable)) THEN 'TRUE' END                                                        
		END='TRUE'   
	AND   
		CASE @Machine     
		WHEN '' THEN 'TRUE'           
		ELSE                                                        
		CASE WHEN SPD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                   
		END='TRUE'   
	AND      
		(CASE @EcolabCategory     
		WHEN '' THEN 'TRUE'           
		ELSE                                                        
		CASE WHEN SPD.EcolabTextileId IN (SELECT EcolabCategory FROM @EcolabCategoryTable) THEN 'TRUE' END                                                        
		END='TRUE'   
	OR       
		CASE @ChainCategory     
		WHEN '' THEN 'TRUE'           
		ELSE                                                        
		CASE WHEN SPD.ChainTextileId IN (SELECT ChainCategory FROM @ChainCategoryTable) THEN 'TRUE' END                                                        
		END='TRUE'  )
	AND    
		CASE @PlantFormula     
		WHEN '' THEN 'TRUE'           
		ELSE                                                        
		CASE WHEN SPD.ProgramMasterId IN (SELECT PlantFormula FROM @PlantFormulaTable) THEN 'TRUE' END                                                        
		END='TRUE'    
	AND        
		CASE @ChainFormula     
		WHEN '' THEN 'TRUE'           
		ELSE                                                        
		CASE WHEN SPD.ProgramMasterId IN (SELECT ChainFormula FROM @ChainFormulaTable) THEN 'TRUE' END                                                      
		END='TRUE'  
	AND       
		CASE @Customer     
		WHEN '' THEN 'TRUE'           
		ELSE                                                        
		CASE WHEN SPD.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                        
		END='TRUE'   	
	AND 
		CASE @FormulaSegement                                                                                
		WHEN '' THEN  'TRUE'
		ELSE
			CASE WHEN SPD.ChainProgaramId  IS NOT NULL THEN
			CASE WHEN ChainPlant.FormulaSegmentId IN (SELECT FormulaSegment FROM @FormulaSegmentTable) THEN 'TRUE' END                                                                                     
			ELSE 
			CASE WHEN FS1.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)  THEN 'TRUE'END   
		END                                                     
		END='TRUE'
 
	
	--SELECT * FROM @ProductionSummaryTable
	--SELECT * FROM @ProductionSummaryTable1
	--@Factor
	--UPDATE ps SET PlantTargetProd=1
	--FROM @ProductionSummaryTable ps
	--INNER JOIN @Factor f ON ps.ShiftId=

	DECLARE @FilterProductionSummeryCount int,@CorrectionFactorCount int,@IsFiltersAppliled bit=0

	SELECT @CorrectionFactorCount=count(1) FROM @Factor 

	;WITH cte AS (SELECT DISTINCT pst.ShiftId,pst.MachineId FROM @ProductionSummaryTable pst)
	SELECT @FilterProductionSummeryCount= count(1) FROM cte

	IF (@CorrectionFactorCount>@FilterProductionSummeryCount)
	BEGIN
	   SET @IsFiltersAppliled=1
	END

	UPDATE  @ProductionSummaryTable SET PlantTargetProd=NULL

	IF( @Viewtype = 1 AND @IsFiltersAppliled=0)
	BEGIN
	     ;WITH cte (ShiftId,PlantTargetProd,rownum)
		as(
	    SELECT ShiftId, PlantTargetProd, ROW_NUMBER() OVER(PARTITION BY ShiftId ORDER BY ShiftId) rownum	
	    FROM @ProductionSummaryTable	
	    )
	    	UPDATE c SET c.PlantTargetProd=f.PlantTargetProduction
	   FROM cte c INNER JOIN @Factor f ON c.ShiftId=f.ShiftId  AND c.rownum=1
	END
	ELSE
	BEGIN
	    ;WITH cte (ShiftId,MachineId,PlantTargetProd,rownum)as(
	    SELECT ShiftId,MachineId, PlantTargetProd, ROW_NUMBER() OVER(PARTITION BY ShiftId,MachineId ORDER BY ShiftId,MachineId) rownum	
	    FROM @ProductionSummaryTable	
	    )
	    	UPDATE c SET c.PlantTargetProd=f.TargetProduction
	   FROM cte c INNER JOIN @Factor f ON c.ShiftId=f.ShiftId AND c.MachineId=f.MachineId AND c.rownum=1
	END



  

	--Updating Actual Production based Manual Production  
	UPDATE S SET ActualProduction=ISNULL(S.ActualProduction,0)+ISNULL(MIP.ManualIPActualWeight,0),S.NoOfLoads=ISNULL(S.NoOfLoads,0)+ISNULL(MIP.NoofLoads,0)  
	FROM  @ProductionSummaryTable S  
	INNER JOIN   
	(  
		SELECT WasherId,FormulaId,CONVERT(DATE,RecordedDate) AS LoadDate,SUM(Value) AS ManualIPActualWeight,  
		COUNT(CONVERT(DATE,RecordedDate)) AS NoofLoads FROM  
		TCD.ManualProduction MP  
		GROUP BY WasherId,FormulaId,CONVERT(DATE,RecordedDate)  
	)MIP ON MIP.WasherId=S.MachineId AND MIP.FormulaId=S.ProgramMasterId AND MIP.LoadDate=S.RecordDate  
	WHERE S.RowNumberID=1  

   

	DECLARE @TableShiftruntime TABLE(ShiftID INT ,ShiftRuntime Decimal(20,10),ID INT,Name VARCHAR(1000))
	DECLARE @MaxShiftruntime1 DECIMAL(30,10),@noofShifts INT
	--FInding  total shiftruntime irrespective of Ecolab AccountnNumber
	--SELECT @MaxShiftruntime1=ISNULL(SUM(A.Shiftruntime),0) ,@noofShifts=COUNT(A.Shiftruntime)  FROM 
	--	(SELECT DISTINCT SHIFTID, ShiftRuntime Shiftruntime,RecordDATE FROM @ProductionSummaryTable1)A
		
    IF(@Viewtype = 1) --Time View  
    BEGIN  
       
		IF(@Subview = 5)  --Day view  
		BEGIN  
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			SPD.ShiftName  
			FROM @ProductionSummaryTable SPD ;

			INSERT INTO @resultSet  
			SELECT   
			0,  
			SPD.ShiftName,  
			SUM(SPD.ActualProduction),  
			COALESCE(SUM(SPD.ActualProduction)/   
			NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),  
			SUM(DISTINCT SPD.PlantTargetProd),  
			SUM([NoOfLoads]),  
			SUM( SPD.ShiftRunTime),  
			SUM( SPD.ShiftRunTime)  
			,@Viewtype   
			,@Subview  
			,0  
			,0  
			FROM @ProductionSummaryTable SPD  
			GROUP BY   
			SPD.ShiftName ;
			
			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name	 
	    END  
  		
		IF (@Subview = 4) --Week View  
		BEGIN  
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			CAST(RecordDate AS nvarchar(100))  
			FROM @ProductionSummaryTable SPD ;
			
			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,SortOrder)  
			AS  
			(  
				SELECT   
				CAST(RecordDate AS nvarchar(100)),  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/   
				NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),  
				SUM(isnull( SPD.PlantTargetProd,0)),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime)  
				,ROW_NUMBER () OVER (ORDER BY RecordDate)  
				FROM @ProductionSummaryTable SPD  
				GROUP BY DATEPART(weekday,RecordDate),cast( RecordDate AS  date)--,SPD.ShiftId
			)  
  
			INSERT INTO @resultSet  
			SELECT    
			0,   
			DateRange,  
			SUM(TotalLoad),  
			SUM(TotalEfficiency),  
			SUM(PlantTargetLoad),  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime)  
			,@Viewtype   
			,@Subview  
			,0  
			,SortOrder
			FROM CTE   
			WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange,SortOrder;
		
			
			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime,
					DateRange=CONVERT(VARCHAR(11),CONVERT(DATE,DateRange),113)+' ('+LEFT(datename(dw,DateRange),3)+')' --Appending DayName in Output	
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name;			
					
			 
		END  
          
		IF(@Subview = 3)  --Month View 
		BEGIN  
		

			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT SPD.ShiftId,SPD.ShiftRunTime AS ShiftRuntime,
				CASE WHEN DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate) >@InputStartDate 
				THEN CAST(CONVERT(VARCHAR, DATEADD(dd, -(DATEPART(dw,RecordDate) - 1), RecordDate), 101) AS NVARCHAR(100))
				ELSE CAST(CONVERT(VARCHAR, @InputStartDate, 101) AS NVARCHAR(100)) 
				END 
				+  '-' + 
				CASE WHEN DATEADD(dd, (7 - DatePart(dw, RecordDate)),RecordDate) < @InputEndDate 
				THEN CAST(CONVERT(VARCHAR, DateAdd(dd, (7 - DatePart(dw, RecordDate)),RecordDate), 101) AS nvarchar(100))
				ELSE CAST(Convert(VARCHAR, @InputEndDate, 101) AS nvarchar(100))
				END AS DateRange   
				FROM @ProductionSummaryTable SPD 
			 
			


			;WITH CTE(DateRange,TotalLoad,StandardProduction,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,rowno)  
			AS  
			(  
			   SELECT          
						CASE WHEN DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate) >@InputStartDate 
				THEN CAST(CONVERT(VARCHAR, DATEADD(dd, -(DATEPART(dw,RecordDate) - 1), RecordDate), 101) AS NVARCHAR(100))
				ELSE CAST(CONVERT(VARCHAR, @InputStartDate, 101) AS NVARCHAR(100)) 
				END 
				+  '-' + 
				CASE WHEN DATEADD(dd, (7 - DatePart(dw, RecordDate)),RecordDate) < @InputEndDate 
				THEN CAST(CONVERT(VARCHAR, DateAdd(dd, (7 - DatePart(dw, RecordDate)),RecordDate), 101) AS nvarchar(100))
				ELSE CAST(Convert(VARCHAR, @InputEndDate, 101) AS nvarchar(100))
				END AS DateRange ,  
				(SPD.ActualProduction),  
				SPD.StandardProduction,
				--COALESCE(SUM(SPD.ActualProduction)/   
				--NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),  
				(isnull( SPD.PlantTargetProd,0)),  
				([NoOfLoads]),  
				( SPD.ShiftRunTime),  
				( SPD.ShiftRunTime),
				DENSE_RANK() OVER (ORDER BY DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate)) as rowno
				
				FROM @ProductionSummaryTable SPD  
				
				)  
				INSERT INTO @resultSet  
				 SELECT    
				 0,   
				 DateRange,  
				 SUM(TotalLoad),  
				 COALESCE(SUM(TotalLoad)/   
				NULLIF((COALESCE(SUM(TotalLoad) / NULLIF(SUM(StandardProduction),0),0) * COALESCE(SUM(ActualRunTime) / NULLIF(SUM(TargetRuntime),0),0)),0) * 100, 0),  
				-- SUM(TotalEfficiency),  
				 SUM(PlantTargetLoad),  
				 SUM(Numberofbatches),  
				 SUM(ActualRunTime),  
				 SUM(TargetRuntime)  
				 ,@Viewtype   
				 ,@Subview  
				  ,0  
				  ,rowno
				 FROM CTE   
				 WHERE TotalLoad IS NOT NULL  
				GROUP BY DateRange,rowno; 
			
			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name 
  
			
		END  
  
		IF(@Subview = 2)  --Year view 
		BEGIN  
			DECLARE @QuarterYear VARCHAR(100) = YEAR(@enddate);  

			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			DATENAME(MONTH, RecordDate) + ' ' +CAST( YEAR(RecordDate) as varchar)  
			FROM @ProductionSummaryTable SPD;

			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,MonthOrder,YearOrder)  
			AS  
			(  
				SELECT          
				DATENAME(MONTH, RecordDate) + ' ' + CAST( YEAR(RecordDate) as varchar)  As DateRange,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/   
				NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime)  ,
				DATEPART(MONTH, RecordDate) ,
				YEAR(RecordDate) 

				FROM @ProductionSummaryTable SPD  
				GROUP BY  DATEPART(MONTH, RecordDate),DATENAME(MONTH, RecordDate),SPD.ShiftId , YEAR(RecordDate) 
			)  
			INSERT INTO @resultSet  
			SELECT    
			0,   
			DateRange,  
			SUM(TotalLoad),  
			SUM(TotalEfficiency),  
			SUM(PlantTargetLoad),  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime)  
			,@Viewtype   
			,@Subview  
			,0  
			,ROW_NUMBER () OVER (ORDER BY YearOrder,MonthOrder)
			FROM CTE   
			WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange,MonthOrder,YearOrder				
			;  
			
			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name;


	  
		END 
     
		IF(@Subview = 1)  --Quarter view 
		BEGIN  
		
			DECLARE @Year VARCHAR(100) = RIGHT(YEAR(@enddate),2);  

			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name,ID)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			CASE 'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10))  
				WHEN 'Q1' THEN 'Jan' + RIGHT(YEAR(RecordDate),2)  + '- Mar' + RIGHT(YEAR(RecordDate),2)   
				WHEN 'Q2' THEN 'Apr' + RIGHT(YEAR(RecordDate),2)  + '- Jun' + RIGHT(YEAR(RecordDate),2)   
				WHEN 'Q3' THEN 'Jul' + RIGHT(YEAR(RecordDate),2)  + '-Sep' + RIGHT(YEAR(RecordDate),2)   
				WHEN 'Q4' THEN 'Oct' + RIGHT(YEAR(RecordDate),2)  + '- Dec'+ RIGHT(YEAR(RecordDate),2)   
				END, 
			cast( cast(RIGHT(YEAR(RecordDate),2) AS varchar ) +cast(  DATEPART(QUARTER, RecordDate) AS varchar) AS int)
			FROM @ProductionSummaryTable SPD ;

			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,RowNo)  
			AS  
			(  
				SELECT   
					CASE 'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10))  
					WHEN 'Q1' THEN 'Jan' + RIGHT(YEAR(RecordDate),2)  + '- Mar' + RIGHT(YEAR(RecordDate),2)  
					WHEN 'Q2' THEN 'Apr' + RIGHT(YEAR(RecordDate),2) + '- Jun' + RIGHT(YEAR(RecordDate),2)  
					WHEN 'Q3' THEN 'Jul' + RIGHT(YEAR(RecordDate),2) + '-Sep' + RIGHT(YEAR(RecordDate),2)  
					WHEN 'Q4' THEN 'Oct' + RIGHT(YEAR(RecordDate),2) + '- Dec'+ RIGHT(YEAR(RecordDate),2)   
				END AS DateRange,  
				SUM(SPD.ActualProduction),  
				COALESCE(SUM(SPD.ActualProduction)/   
				NULLIF((COALESCE(SUM(SPD.ActualProduction) / NULLIF(SUM(SPD.StandardProduction),0),0) * COALESCE(SUM(SPD.[ActualRunTime]) / NULLIF(SUM(SPD.[TargetRunTime]),0),0)),0) * 100, 0),  
				SUM(DISTINCT SPD.PlantTargetProd),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime)  ,
				cast( cast(RIGHT(YEAR(RecordDate),2) AS varchar ) +cast(  DATEPART(QUARTER, RecordDate) AS varchar) AS int)  RowNo
				
				FROM @ProductionSummaryTable SPD  
				GROUP BY DATEPART(QUARTER, RecordDate),SPD.ShiftId,RIGHT(YEAR(RecordDate),2)
			)  
  
		   INSERT INTO @resultSet  
		   SELECT    
				0,   
				DateRange,  
				SUM(TotalLoad),  
				SUM(TotalEfficiency),  
				SUM(PlantTargetLoad),  
				SUM(Numberofbatches),  
				SUM(ActualRunTime),  
				SUM(TargetRuntime)  
				,@Viewtype   
				,@Subview  
				,0  
				,RowNo
				FROM CTE   
			 WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange  ,RowNo
			ORDER BY RowNo;

			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name;

			
		END  
    
	END        
   
    IF(@Viewtype = 2) --Location View 
    BEGIN    
		IF(@Subview = 9)  --Washer group view 
		BEGIN  			
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,ID)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			WG.WasherGroupId  
			FROM @ProductionSummaryTable SPD 
			INNER JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId  
			INNER JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId ;

			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,WasherGroupId)  
			AS  
			(  
				SELECT    
				--SPD.MachineId,      
				WG.WasherGroupName,  
				SUM(SPD.ActualProduction),  
				CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/   
				NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) *   
				COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),  
				SUM(isnull( SPD.PlantTargetProd,0)),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime),  
				WG.WasherGroupId  
				FROM @ProductionSummaryTable SPD 
				INNER JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId  
				INNER JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId   
				GROUP BY WG.WasherGroupName,WG.WasherGroupId,SPD.ShiftId--,SPD.MachineId  
			)  
  
			INSERT INTO @resultSet  
			SELECT    
			0,   
			DateRange,  
			SUM(TotalLoad),  
			SUM(TotalEfficiency),  
			sum(PlantTargetLoad),  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime)  
			,@Viewtype   
			,@Subview  
			,WasherGroupId  
			,0
			FROM CTE   
			WHERE TotalLoad IS NOT NULL         
			GROUP BY DateRange,WasherGroupId ; 
			
			WITH CTE1
			AS
			(
				SELECT SUM(ShiftRuntime) AS Shiftruntime,ID FROM @TableShiftruntime
				GROUP BY ID
			)

			--Update Shiftruntime in Temp table
			UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
			FROM @resultSet  RS
			LEFT OUTER JOIN 
			CTE1 TS ON RS.Id=TS.ID;
		
		END  
  
		IF(@Subview = 10) -- Washer/machine view  
		BEGIN  			
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  SPD.ShiftId,SPD.ShiftRunTime AS ShiftRuntime,         
			cast( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName MachineName
			FROM @ProductionSummaryTable SPD   
			INNER JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId  
			INNER JOIN TCD.Washer w on MS.WasherId=w.WasherId  
			INNER JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId   
			WHERE   
				(  
				CASE @drillvalue     
				WHEN '' THEN 'TRUE'           
				ELSE                                                      
				CASE WHEN WG.WasherGroupId IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				) ;    

			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime)  
		    AS  
		    (  
				SELECT           
				cast( W.PlantWasherNumber as varchar(20))+':'+ MS.MachineName as MachineName,  
				SUM(SPD.ActualProduction),  
				CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/   
				NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) *   
				COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),  
				SUM(isnull( SPD.PlantTargetProd,0)),  
				SUM([NoOfLoads]),  
				SUM( SPD.ShiftRunTime),  
				SUM( SPD.ShiftRunTime)          
				FROM @ProductionSummaryTable SPD   
				INNER JOIN TCD.MachineSetup MS ON SPD.MachineId = MS.WasherId  
				INNER JOIN TCD.Washer w on MS.WasherId=w.WasherId  
				INNER JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId   
				WHERE   
				(  
					CASE @drillvalue     
					WHEN '' THEN 'TRUE'           
					ELSE                                                      
					CASE WHEN WG.WasherGroupId IN (@drillvalue) THEN 'TRUE' END              
					END='TRUE'  
				)  
				GROUP BY cast( W.PlantWasherNumber as varchar(20))+':'+MS.MachineName,SPD.ShiftId             
		   )    
			INSERT INTO @resultSet  
			SELECT   
			0,   
			DateRange,  
			SUM(TotalLoad),  
			SUM(TotalEfficiency),  
			sum( PlantTargetLoad),  
			SUM(Numberofbatches),  
			SUM(ActualRunTime),  
			SUM(TargetRuntime)  
			,@Viewtype   
			,@Subview  
			,0 
			,0 
			FROM CTE   
			WHERE TotalLoad IS NOT NULL  
			GROUP BY DateRange ; 
			
			WITH CTE1
			AS
			(
				SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
				GROUP BY Name 
			)				
			--Update Shiftruntime in Temp table
			UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
			FROM @resultSet  RS
			LEFT OUTER JOIN 
			CTE1 TS ON RS.DateRange=TS.Name;
		END  
  	END  
   
	IF(@Viewtype = 7) --Formula View
	BEGIN
		WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,WasherGroupId)
		AS
		(
		SELECT          
		PM.Name,
		SUM(SPD.ActualProduction),
		CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
		NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
		COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
		SUM(DISTINCT SPD.PlantTargetProd),
		SUM([NoOfLoads]),
		SUM( SPD.ShiftRunTime),
		SUM( SPD.ShiftRunTime),
		PM.ProgramId
		FROM @ProductionSummaryTable SPD
		INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
		Group by PM.Name,PM.ProgramId
		)
		INSERT INTO @resultSet
		SELECT  
			0, 
			DateRange,
			SUM(TotalLoad),
			SUM(TotalEfficiency),
			@PlantTargetProduction,
			SUM(Numberofbatches),
			SUM(ActualRunTime),
			SUM(TargetRuntime)
			,@Viewtype 
			,@Subview
			,WasherGroupId
			,0
		FROM CTE 
		WHERE TotalLoad IS NOT NULL       
		GROUP BY DateRange,WasherGroupId
	END
	
	IF(@Viewtype = 8) --Formula segmentView
	BEGIN
		IF(@Subview =20)-- Formula Segment
		BEGIN 
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			FS.SegmentName    
			FROM @ProductionSummaryTable SPD
			INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
			INNER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=SPD.FormulaSegmentID ;
						
			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,FormulaSegmentID)
			AS
			(
			   SELECT          
			   FS.SegmentName,
			   SUM(SPD.ActualProduction),
			   CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
			   NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
			   COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
			   SUM(DISTINCT SPD.PlantTargetProd),
			   SUM([NoOfLoads]),
			   SUM( SPD.ShiftRunTime),
			   SUM( SPD.ShiftRunTime),
			   SPD.FormulaSegmentID
			   FROM @ProductionSummaryTable SPD
			   INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
			   INNER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=SPD.FormulaSegmentID
			   Group by SPD.FormulaSegmentID,FS.SegmentName   
			)
				INSERT INTO @resultSet
				SELECT  
				0, 
				DateRange,
				SUM(TotalLoad),
				SUM(TotalEfficiency),
				@PlantTargetProduction,
				SUM(Numberofbatches),
				SUM(ActualRunTime),
				SUM(TargetRuntime)
				,@Viewtype 
				,@Subview
				,FormulaSegmentID
				,0
				FROM CTE 
				WHERE TotalLoad IS NOT NULL       
				GROUP BY DateRange,FormulaSegmentID;

			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name	;
		END
		
		IF(@Subview =21)-- Formula Categories
		BEGIN 
		 
		   INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT SPD.ShiftId,SPD.ShiftRunTime AS ShiftRuntime, EC.CategoryName    
				FROM @ProductionSummaryTable SPD
				INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
				WHERE  
					(  
					CASE      
					WHEN @drillvalue='' THEN 'TRUE'   
					WHEN @drillvalue IS NULL THEN 'TRUE'    
					ELSE                                                      
					CASE WHEN SPD.FormulaSegmentID IN (@drillvalue) THEN 'TRUE' END              
					END='TRUE'  
					) --AND EC.CategoryName IS NOT NULL
			UNION 

			SELECT DISTINCT SPD.ShiftId,SPD.ShiftRunTime AS ShiftRuntime, CC.NAME   
			FROM @ProductionSummaryTable SPD
			--INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId  
			--INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = SPD.ChainProgaramId  
			INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
				WHERE  
				(  
				CASE      
				WHEN @drillvalue='' THEN 'TRUE'   
				WHEN @drillvalue IS NULL THEN 'TRUE'    
				ELSE                                                      
				CASE WHEN SPD.FormulaSegmentID IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				) ;
		   	

		   WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,TextileId)
		   AS
		   (
			SELECT EC.CategoryName,SUM(SPD.ActualProduction),
			CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
			NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
			COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
			SUM(DISTINCT SPD.PlantTargetProd),SUM([NoOfLoads]),SUM( SPD.ShiftRunTime),
			SUM( SPD.ShiftRunTime),EC.TextileId
			FROM @ProductionSummaryTable SPD
			INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
			WHERE  
				(  
				CASE      
				WHEN @drillvalue='' THEN 'TRUE'   
				WHEN @drillvalue IS NULL THEN 'TRUE'    
				ELSE                                                      
				CASE WHEN SPD.FormulaSegmentID IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				) --AND EC.CategoryName IS NOT NULL  
				GROUP BY EC.CategoryName,EC.TextileId,SPD.ShiftId 
    
			UNION

			SELECT CC.Name,SUM(SPD.ActualProduction),
			CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
			NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
			COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
			SUM(DISTINCT SPD.PlantTargetProd),SUM([NoOfLoads]),SUM( SPD.ShiftRunTime),
			SUM( SPD.ShiftRunTime),CC.TextileId
			FROM @ProductionSummaryTable SPD
			--INNER JOIN TCD.ProgramMaster PM on SPD.ProgramMasterId = PM.ProgramId
			--INNER JOIN TCD.PlantChainProgram PCP on PCP.PlantProgramId = SPD.ChainProgaramId
			INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId 
			WHERE  
				(  
				CASE      
				WHEN @drillvalue='' THEN 'TRUE'   
				WHEN @drillvalue IS NULL THEN 'TRUE'    
				ELSE                                                      
				CASE WHEN SPD.FormulaSegmentID IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				)   
				Group by CC.Name,cc.TextileId,SPD.ShiftId  
  
		   )
			INSERT INTO @resultSet
			SELECT         
			0, 
			DateRange,  
			SUM(TotalLoad),
			SUM(TotalEfficiency),
			@PlantTargetProduction,
			SUM(Numberofbatches),
			SUM(ActualRunTime),
			SUM(TargetRuntime)
			,@Viewtype 
			,@Subview
			,TextileId
			,0
			FROM CTE 
			WHERE TotalLoad IS NOT NULL       
			GROUP BY DateRange,TextileId;

           WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name
							   
	    END
  
		IF(@Subview=22) --Formula
		BEGIN
			---Checking Drill value Ecolb/chain category
			DECLARE @ChaincategoryDrillValue INT
			IF(@Drillvalue>1000)
				SET @ChaincategoryDrillValue=@Drillvalue-1000
			 ELSE IF (@Drillvalue <1000)
				SET @ChaincategoryDrillValue=@Drillvalue+1000
			---End
			
			INSERT INTO @TableShiftruntime (ShiftID,ShiftRuntime,Name)
			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			PM.Name    
			FROM @ProductionSummaryTable SPD
			--INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId  
			INNER JOIN TCD.ProgramMaster PM ON SPD.ProgramMasterId = PM.ProgramId    
			WHERE SPD.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)
				AND  
				(  
				CASE      
				WHEN @drillvalue='' THEN 'TRUE'   
				WHEN @drillvalue IS NULL THEN 'TRUE'    
				ELSE                                                      
				CASE WHEN SPD.EcolabTextileId IN (@drillvalue) THEN 'TRUE' END              
				END='TRUE'  
				) --AND PM.NAME IS NOT NULL
			
			UNION

			SELECT DISTINCT  		  
			SPD.ShiftId,
			SPD.ShiftRunTime AS ShiftRuntime, 		 
			PM.Name    
			FROM @ProductionSummaryTable SPD
			--INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId  
			INNER JOIN TCD.ProgramMaster PM ON  SPD.ProgramMasterId = PM.ProgramId    
			WHERE SPD.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)
				AND 
				(  
				CASE      
				WHEN @drillvalue='' THEN 'TRUE'   
				WHEN @drillvalue IS NULL THEN 'TRUE'    
				ELSE                                                      
				CASE WHEN SPD.ChainTextileId  IN (@ChaincategoryDrillValue) THEN 'TRUE' END              
				END='TRUE' 
				)
				 ;

			WITH CTE(DateRange,TotalLoad,TotalEfficiency,PlantTargetLoad,Numberofbatches,ActualRunTime,TargetRuntime,WasherGroupId)
			AS
			(
				SELECT PM.Name,SUM(SPD.ActualProduction),
				CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
				NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
				COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
				SUM( SPD.PlantTargetProd),SUM([NoOfLoads]),SUM( SPD.ShiftRunTime),
				SUM( SPD.ShiftRunTime),PM.ProgramId
				FROM @ProductionSummaryTable SPD
				--INNER JOIN TCD.EcolabTextileCategory EC on EC.TextileId = SPD.EcolabTextileId
				INNER JOIN TCD.ProgramMaster PM ON SPD.ProgramMasterId = PM.ProgramId    
				WHERE SPD.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)
				AND
				 (
				 CASE    
				  WHEN @drillvalue='' THEN 'TRUE' 
				  WHEN @drillvalue IS NULL THEN 'TRUE'  
				  ELSE                                                    
				  CASE WHEN SPD.EcolabTextileId IN (@drillvalue) THEN 'TRUE' END            
				  END='TRUE'
				 ) --AND PM.NAME IS NOT NULL
				GROUP BY PM.Name,PM.ProgramId --,SPD.ShiftId 
    
			UNION

				SELECT PM.Name,SUM(SPD.ActualProduction),
				CAST(COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2))/ 
				NULLIF((COALESCE(CAST(SUM(SPD.ActualProduction) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.StandardProduction) AS DECIMAL(18,2)),0),0) * 
				COALESCE(CAST(SUM(SPD.[TargetRunTime]) AS DECIMAL(18,2)) / NULLIF(CAST(SUM(SPD.[ActualRunTime]) AS DECIMAL(18,2)),0),0)),0), 0) AS decimal(18,2)),
				SUM(DISTINCT SPD.PlantTargetProd),SUM([NoOfLoads]),SUM( SPD.ShiftRunTime),
				SUM( SPD.ShiftRunTime),PM.ProgramId
				FROM @ProductionSummaryTable SPD 
				--INNER JOIN TCD.ChainTextileCategory CC on CC.TextileId = SPD.ChainTextileId
				INNER JOIN TCD.ProgramMaster PM ON  SPD.ProgramMasterId = PM.ProgramId  
				WHERE SPD.FormulaSegmentID IN (SELECT FormulaSegment FROM @FormulaSegmentTable)
				AND
				 (
				  CASE    
				  WHEN @drillvalue='' THEN 'TRUE' 
				  WHEN @drillvalue IS NULL THEN 'TRUE'  
				  ELSE                                                    
				  CASE WHEN SPD.ChainTextileId IN (@ChaincategoryDrillValue) THEN 'TRUE' END            
				  END='TRUE'
				 )
				GROUP BY PM.Name,PM.ProgramId--,SPD.ShiftId  
      
			)
			INSERT INTO @resultSet
			SELECT  
			0, 
			DateRange,
			SUM(TotalLoad),
			SUM(TotalEfficiency),
			@PlantTargetProduction,
			SUM(Numberofbatches),
			SUM(ActualRunTime),
			SUM(TargetRuntime)
			,@Viewtype 
			,@Subview
			,WasherGroupId
			,0
			FROM CTE 
			WHERE TotalLoad IS NOT NULL       
			GROUP BY DateRange,WasherGroupId;
			
			WITH CTE1
					AS
					(
						SELECT SUM(ShiftRuntime) AS Shiftruntime,Name FROM @TableShiftruntime
						GROUP BY Name
					)

					--Update Shiftruntime in Temp table
					UPDATE RS  SET RS.ActualRunTime=TS.Shiftruntime,RS.TargetRunTime=TS.Shiftruntime
					FROM @resultSet  RS
					LEFT OUTER JOIN 
					CTE1 TS ON RS.DateRange=TS.Name
END
	END


	DECLARE @MaxShiftruntime DECIMAL(30,10)=NULL
	IF(@Viewtype IN (2,8) ) --for Location and Formula, shift hours will be total shifthours for particular duration
	BEGIN		
		 IF(@Subview IN(9,10,20,21,22))
		 BEGIN
			SELECT @MaxShiftruntime=SUM(A.Shiftruntime)  FROM
				(
				SELECT DISTINCT ShiftID AS ShiftID,MAX(ShiftRuntime) AS Shiftruntime  FROM @TableShiftruntime
				GROUP BY ShiftID
				)A
		 END
	END
	ELSE IF(@Viewtype IN(1))
	BEGIN
		SELECT @MaxShiftruntime= (SELECT SUM(ShiftRuntime) AS Shiftruntime FROM @TableShiftruntime)		
	END

	--Result set
	SELECT DateRange,
	ISNULL([TCD].[FnConsumptionOnMetrics](TotalLoad,'Weight',@UserId),0) AS TotalLoad,       
	ISNULL([TCD].[FnConsumptionOnMetrics](WasherEfficiency,'Weight',@UserId),0) AS Washerefficiency,        
	ISNULL([TCD].[FnConsumptionOnMetrics](PlantTargetLoad,'Weight',@UserId),0)  AS PlantTargetLoad,       
	ISNULL(Numberofbatches,0) AS NumberofBatches,  
	ISNULL([ActualRunTime],0) [ShiftRuntime] ,  
	ISNULL([TargetRunTime],0) [TargetRuntime],  
	Viewtype,Subview,Id,ShiftId,@CorrectionVariable AS CorrectionVariable,@MaxShiftruntime AS Maxshiftruntime,SortOrder
	--@MaxShiftruntime1 AS MaxShiftruntime1, @noofShifts AS NoOfshifts	    
	FROM @resultSet   
			
	  
SET NOCOUNT OFF
END
