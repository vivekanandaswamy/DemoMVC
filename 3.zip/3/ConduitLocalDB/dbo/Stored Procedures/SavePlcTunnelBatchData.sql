﻿CREATE PROCEDURE [TCD].[SavePlcTunnelBatchData]
(
@WasherId INT=NULL
,@RecordedTime DATETIME=NULL
,@OperationalCount INT=NULL
,@CurrentFormula INT=NULL
,@CurrentInjection INT=NULL
,@IsNewBatch BIT = 0 
,@BatchID INT OUT
,@MaxCompartments INT = 0

)
AS
SET NOCOUNT ON
BEGIN

	DECLARE @EcolabWasherId INT,@EndofFormula INT=128 -- This value is sent through the application.
	Declare @StandardWeight varchar(100) , @CurrencyCode varchar(50)
	SELECT @EcolabWasherId=EcolabWasherId FROM  [TCD].Washer WHERE WasherId= @WasherId
	DECLARE @Batch_ID INT
	DECLARE @MachineInternalId INT , @GroupId INT 

	SET		@BatchID			=			ISNULL(@BatchID, NULL)			--SQLEnlight
	SET		@RecordedTime		=			ISNULL(@RecordedTime, NULL)		--SQLEnlight SA0029
	SET		@CurrentInjection	=			ISNULL(@CurrentInjection, NULL)	--SQLEnlight SA0029
	SET		@OperationalCount	=			ISNULL(@OperationalCount, NULL)	--SQLEnlight SA0029


BEGIN TRANSACTION

BEGIN TRY
	SELECT @CurrentFormula , @EndofFormula,@IsNewBatch
IF (@IsNewBatch = 1 )

BEGIN
		SELECT DISTINCT 
						@StandardWeight =  cps.NominalLoad , 
						@CurrencyCode = Pl.CurrencyCode 
		FROM  [TCD].Washer Ws
		INNER JOIN [TCD].MachineSetup MST ON MST.WasherId = Ws.WasherId
		INNER JOIN [TCD].WasherGroup WG ON WG.WasherGroupId = MST.GroupId
		INNER JOIN [TCD].WasherGroupType WGT ON WGT.WasherGroupTypeId = WG.WasherGroupTypeId
		INNER JOIN [TCD].WasherProgramSetup CPS ON CPS.WasherGroupId = WG.WasherGroupId
		INNER JOIN [TCD].WasherDosingSetup CDS ON CDS.WasherProgramSetupId = CPS.WasherProgramSetupId
		INNER JOIN [TCD].WasherDosingProductMapping CDPM ON CDPM.WasherDosingSetupId = CDS.WasherDosingSetupId
		INNER JOIN [TCD].Plant Pl on Pl.EcolabAccountNumber=Ws.EcoLabAccountNumber
		WHERE Ws.WasherId=@WasherId AND CPS.ProgramNumber=@CurrentFormula

		INSERT INTO [TCD].BatchData(
					ControllerBatchId ,
					EcolabWasherId,
					GroupId,
					MachineInternalId,
					StartDate,
					EndDate,
					ProgramNumber,
					ActualWeight,
					StandardWeight,
					CurrencyCode)

		SELECT DISTINCT  0
						,@EcolabWasherId
						,MST.GroupId
						,Mst.MachineInternalId
						,GETUTCDATE()AS StartDate
						,NULL
						,@CurrentFormula
						,NULL
						,@StandardWeight[StandardWeight] 
						,@CurrencyCode[CurrencyCode] 						
		FROM  [TCD].Washer Ws
		INNER JOIN [TCD].MachineSetup MST ON MST.WasherId = Ws.WasherId
		INNER JOIN [TCD].WasherGroup WG ON WG.WasherGroupId = MST.GroupId
		INNER JOIN [TCD].WasherGroupType WGT ON WGT.WasherGroupTypeId = WG.WasherGroupTypeId
		WHERE Ws.WasherId=@WasherId 

	SET @Batch_ID=SCOPE_IDENTITY()
	SET @BatchID = @Batch_ID

		INSERT INTO TCD.BatchProductData(BatchId,StepCompartment,ProductId,ActualQuantity,StandardQuantity,Price)
		SELECT   @Batch_ID
				,NULL--CDS.StepNumber 
				,CDPM.ProductId
				,NULL
				,CDPM.Quantity AS StandardQuantity
				,NULL
		FROM  [TCD].Washer WS
		INNER JOIN [TCD].MachineSetup MST ON MST.WasherId = ws.WasherId
		INNER JOIN [TCD].WasherGroup WG ON WG.WasherGroupId = MST.GroupId
		INNER JOIN [TCD].WasherGroupType WGT ON WGT.WasherGroupTypeId = WG.WasherGroupTypeId
		INNER JOIN [TCD].WasherProgramSetup CPS ON CPS.WasherGroupId = WG.WasherGroupId
		INNER JOIN [TCD].WasherDosingSetup CDS ON CDS.WasherProgramSetupId = CPS.WasherProgramSetupId
		LEFT JOIN [TCD].WasherDosingProductMapping CDPM ON CDPM.WasherDosingSetupId = CDS.WasherDosingSetupID
		WHERE Ws.WasherId=@WasherId AND CPS.ProgramNumber=@CurrentFormula
END

ELSE IF(@CurrentFormula = @EndofFormula)
BEGIN
	IF (SELECT COUNT (*) FROM  [TCD].BatchData WHERE EcolabWasherId = @EcolabWasherId and EndDate IS NULL) > @MaxCompartments 
		BEGIN
			DECLARE @RemoveBtchID INT 
			SELECT TOP 1 @RemoveBtchID =batchid FROM  [TCD].batchdata WHERE EcolabWasherId =@EcolabWasherId AND EndDate IS NULL ORDER BY EndDate ASC 
				UPDATE[TCD].BatchData
				SET EndDate= GETUTCDATE()
				WHERE  BatchId=@RemoveBtchID

	END
END

ELSE IF(@IsNewBatch = 0)
	BEGIN		
		DECLARE  @TeamRowNumber TABLE (TempRowNumber INT,TempBatchId int,TeamWasherId int)
			INSERT INTO @TeamRowNumber
			SELECT ROW_NUMBER() OVER (ORDER BY StartDate DESC) AS ROW ,BatchID,@WasherId FROM  [TCD].batchdata WHERE enddate is null ORDER BY StartDate DESC

			--INSERT INTO TCD.WasherReading(.
			--						MachineInternalId,
			--						GroupId,WasherId,
			--						ProgramNumber,
			--						CurrentInjection,
			--						OperationCounter,
			--						DosingAmount,
			--						CreatedDate) 
			--				VALUES (@MachineInternalId
			--					   ,@GroupId, @WasherId
			--					   ,@CurrentFormula
			--					   ,@CurrentInjection
			--					   ,@OperationalCount
			--					   ,NULL
			--					   ,GETUTCDATE())



			INSERT INTO TCD.BatchStepData(
									BatchId
									,EcoalabAccountNumber
									,StepId
									,ProductId
									,WaterUsed
									,WaterCost
									,WaterTypeId
									,DesiredWaterUsage
									,WashTimeInSec
									,CompartmentId
									,TimeStamp)

			SELECT  DISTINCT Trn.TempBatchId
									,WS.EcoLabAccountNumber
									,TDS.CompartmentNumber
									,TDPM.ProductId
									,NULL
									,NULL
									,NULL
									,NULL
									,NULL
									,Trn.TempRowNumber
									,GETUTCDATE()
									FROM  [TCD].Washer WS

						INNER JOIN [TCD].MachineSetup MST ON MST.WasherId = ws.WasherId
						INNER JOIN [TCD].WasherGroup WG ON WG.WasherGroupId = MST.GroupId
						INNER JOIN [TCD].WasherGroupType WGT ON WGT.WasherGroupTypeId = WG.WasherGroupTypeId
						INNER JOIN [TCD].TunnelProgramSetup TPS ON TPS.WasherGroupId = WG.WasherGroupId
						INNER JOIN [TCD].TunnelDosingSetup TDS ON TDS.TunnelProgramSetupId = TPS.TunnelProgramSetupId
						INNER JOIN @TeamRowNumber Trn ON Trn.TeamWasherId=WS.WasherId
						INNER JOIN [TCD].TunnelDosingProductMapping  TDPM ON TDPM.TunnelDosingSetupId =TDS.TunnelDosingSetupId
						WHERE MST.WasherId = @WasherId

END
	COMMIT TRANSACTION;
END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;
		SELECT  @ErrorMessage = ERROR_MESSAGE(),
				@ErrorSeverity = ERROR_SEVERITY(),
		  		@ErrorState = ERROR_STATE();
		RAISERROR (	@ErrorMessage, -- Message text.
					@ErrorSeverity, -- Severity.
					@ErrorState -- State.
					);

		ROLLBACK TRANSACTION;
	END CATCH;
END
