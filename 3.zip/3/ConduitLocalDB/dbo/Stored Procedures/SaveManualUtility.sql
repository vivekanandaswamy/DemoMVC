CREATE PROCEDURE [TCD].[SaveManualUtility] 
( 			
		@MeterId   INT,   			
		@RecordedDate DATETIME,
		@Value DECIMAL(18,0),
		@Usage DECIMAL(18,0),
		@EcolabAccountNumber NVARCHAR(25),   
		@UserId  INT,
		@Scope VARCHAR(100) OUTPUT,
		@OutputUtilityId						INT					=			NULL	OUTPUT
	)   
AS   
BEGIN 
SET NOCOUNT ON
DECLARE
		@OutputList					AS	TABLE		(
		UtilityId							INT
	)
		INSERT INTO [TCD].ManualUtility (
				MeterId,																
				RecordedDate,
				Value,
				Usage,
				EcolabAccountNumber,
				LastModifiedByUserId
			)
			OUTPUT
									inserted.UtilityId						AS			UtilityId
			INTO @OutputList
					(UtilityId)
			VALUES(
						@MeterId,																
						@RecordedDate,
						@Value,
						@Usage,
						@EcolabAccountNumber,
						@UserID
				)      
  
		SET @Scope = '101' 
SELECT	TOP 1	
				@OutputUtilityId						=	O.UtilityId
		FROM	@OutputList									O
SET NOCOUNT OFF
END