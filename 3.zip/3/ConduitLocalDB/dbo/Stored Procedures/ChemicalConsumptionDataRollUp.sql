﻿CREATE PROCEDURE [TCD].[ChemicalConsumptionDataRollUp](@Date DATETIME)
AS
SET NOCOUNT ON;
BEGIN

DECLARE @Fromdate Datetime,@Todate Datetime
SET @Fromdate =  dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@Date AS DATE), 112) + ' ' + CONVERT(Varchar(8), CAST(@Date AS TIME)) AS DateTime))
SET @Todate = DATEADD(DAY,1,@Fromdate)


DELETE FROM TCD.ChemicalConsumptionRollUp WHERE RecordDate = CAST(@Date AS date)

    DECLARE @ChemConsumptionRollUpTable Table(
								RecordDate DATE
								,BatchId INT
								,ActualWeight DECIMAL(18,2)
								,StandardWeight DECIMAL(18,2)
								,[MachineId] [int] NULL
								,GroupId INT
								,MachineInternalId INT
								,ProgramNumber INT
								,ProductId INT
								,NoOfBatches INT
								,TotalConsumption DECIMAL(18,2)
								,TargetConsumption DECIMAL(18,2)
								,AverageConsumption DECIMAL(18,2)
								,ActualConsumptionPerLoad DECIMAL(18,2)
								,TargetConsumptionPerLoad DECIMAL(18,2)
								,Cost DECIMAL(18,2)
								,CostPerLoad DECIMAL(18,2)
								,CostExcess DECIMAL(18,2)
								,EcolabTextileId INT
								,EcolabTextileCategoryName VARCHAR(100)
								,PlantTextileId INT
								,PlantTextileCategoryName VARCHAR(100)
							 )

    INSERT INTO @ChemConsumptionRollUpTable(
								RecordDate 
								,BatchId 
								,ActualWeight 
								,StandardWeight 
								,[MachineId]  
								,GroupId 
								,MachineInternalId 
								,ProgramNumber 
								,ProductId 
								,NoOfBatches 
								,TotalConsumption 
								,TargetConsumption 
								,AverageConsumption 
								,ActualConsumptionPerLoad 
								,TargetConsumptionPerLoad 
								,Cost
								,CostPerLoad 
								,CostExcess
								,EcolabTextileId 
								,EcolabTextileCategoryName 
								,PlantTextileId 
								,PlantTextileCategoryName 
							 )
    SELECT 
	  CAST(@Todate AS DATE) as RecordDate
	  ,bd.BatchId
	  ,BD.ActualWeight
	  ,bd.StandardWeight
	  ,BD.MachineId
	  ,BD.GroupId
	  ,BD.MachineInternalId
	  ,BD.ProgramMasterId
	  ,(SELECT TOP 1 PRM.ProductId FROM TCD.ProductMaster PRM WHERE PRM.ProductId = BPD.ProductId) AS ProductId
	  ,COUNT(DISTINCT BD.BatchID) AS NoOfBatches
	  ,SUM(BPD.[ActualQuantity]) AS TotalConsumption
	  ,SUM(BPD.[StandardQuantity]) AS TargetConsumption
	   ,CASE WHEN COUNT(BD.ProgramNumber) <> 0 THEN
	   SUM(BPD.[ActualQuantity])/COUNT(BD.ProgramNumber)
	   ELSE 0 END AS AverageConsumption
	  --,SUM(BPD.[ActualQuantity])/COUNT(BD.ProgramNumber) AS AverageConsumption
	  ,SUM(BPD.[ActualQuantity])/SUM(BD.[ActualWeight]) ActualConsumptionPerLoad
	  ,SUM(BPD.[StandardQuantity])/SUM(BD.[StandardWeight]) TargetConsumptionPerLoad
	  ,SUM(BPD.Price) AS Cost
	   ,SUM(BPD.Price)/COUNT(BD.BatchID) AS CostPerLoad
	  ,(CASE WHEN (SUM(BPD.[ActualQuantity]) - SUM(BPD.[StandardQuantity]) < 0) THEN 0 ELSE ABS(SUM(BPD.[ActualQuantity]) - SUM(BPD.[StandardQuantity]))*SUM(BPD.Price) END) CostExcess
	  ,ETC.TextileId AS EcolabTextileId
	  ,ETC.CategoryName AS EcolabTextileCategoryName
	  ,CTC.TextileId AS PlantTextileId
	  ,CTC.Name AS PlantTextileCategoryName
  FROM 
  TCD.BatchProductData BPD  
	LEFT JOIN TCD.BatchData BD ON BPD.BatchID = BD.BatchID
	LEFT OUTER JOIN TCD.ProgramMaster PM ON PM.ProgramId = BD.ProgramMasterId
	LEFT JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId = PM.EcolabTextileCategoryId
	LEFT OUTER JOIN TCD.ChainTextileCategory CTC ON  CTC.TextileId = PM.ChainTextileId
  WHERE  BD.EndDate  >= @Fromdate
					AND BD.Enddate <= @Todate
   GROUP BY 
  BD.MachineId
  ,BD.BatchId
  ,BD.GroupId
  ,BD.MachineInternalId
  ,BD.ProgramMasterId
  ,ETC.CategoryName
  ,ETC.TextileId
  ,BPD.ProductId
  ,CTC.Name
  ,CTC.TextileId
  ,BD.ActualWeight
  ,bd.StandardWeight

   INSERT INTO TCD.ChemicalConsumptionRollUp
   (
		RecordDate
		,BatchId
		,ActualWeight
	     ,StandardWeight
		,[MachineId]
		,GroupId
		,MachineInternalId
		,ProgramNumber
		,ProductId
		,NoOfBatches
		,TotalConsumption
		,TargetConsumption
		,AverageConsumption
		,ActualConsumptionPerLoad
		,TargetConsumptionPerLoad
		,Cost
		,CostPerLoad
		,CostExcess
		,EcolabTextileId
		,EcolabTextileCategoryName
		,PlantTextileId
		,PlantTextileCategoryName
   )
	SELECT 
	   DISTINCT
	  RecordDate
	  ,BatchId
	  ,ActualWeight
	  ,StandardWeight
	  ,[MachineId]
	  ,GroupId
	  ,MachineInternalId
	  ,ProgramNumber
	  ,ProductId
	  ,NoOfBatches
	  ,TotalConsumption
	  ,TargetConsumption
	  ,AverageConsumption
	  ,ActualConsumptionPerLoad
	  ,TargetConsumptionPerLoad
	  ,Cost
	  ,CostPerLoad
	  ,CostExcess
	  ,EcolabTextileId
	  ,EcolabTextileCategoryName
	  ,PlantTextileId
	  ,PlantTextileCategoryName
	FROM @ChemConsumptionRollUpTable
SET NOCOUNT OFF
END