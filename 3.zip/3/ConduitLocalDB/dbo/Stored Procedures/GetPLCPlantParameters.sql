
CREATE PROCEDURE [TCD].[GetPLCPlantParameters]
(	@ecolabAccountNumber NVARCHAR(25)
)

AS
SET NOCOUNT ON
BEGIN
	IF(@ecolabAccountNumber IS NOT NULL )
	BEGIN

	SELECT	CP.TagId
    	,CP.TagAddress
		,CP.TagDescription
		,CP.ResourceKey
		,CP.ControllerTypeID
		,CP.ControllerGroupID
		,CP.EcolabAccountNumber
		,CP.DefaultValue		
		,CP.AllowableDeviation
		,CP.Active
		,CP.CreatedDate
		,CG.GroupName
		,CG.ReadFrequency		
		FROM [TCD].ControllerTagMapping CP
		INNER JOIN [TCD].ControllerGroups CG ON CG.ControllerGroupID = CP.ControllerGroupID
		INNER JOIN [TCD].Plant PL ON PL.EcolabAccountNumber = CP.EcolabAccountNumber
		WHERE CP.EcolabAccountNumber = @ecolabAccountNumber 
		
	END
SET NOCOUNT OFF
END



