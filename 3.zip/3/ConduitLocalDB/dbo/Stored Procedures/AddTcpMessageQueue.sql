﻿CREATE PROCEDURE [TCD].[AddTcpMessageQueue]
(
	@RequestMessage VARCHAR(MAX),
	@EntityType VARCHAR(500),
	@CreatedDate Datetime,
	@UserId	int,
	@MessageId int,
	@ActionType int,
	@EcolabAccountNumber NVARCHAR(25)	
)
AS
BEGIN
		SET	NOCOUNT	ON
		DECLARE
					@ReturnValue					INT				=			0
				,	@ErrorId						INT				=			0
				,	@ErrorMessage					NVARCHAR(4000)	=			N''
	
				BEGIN
						INSERT	INTO	[TCD].TcpMessageQueue(RequestMessage,EntityType,CreatedDate,[UserId],[ActionType],[EcolabAccountNumber],MessageId)
								VALUES(@RequestMessage,@EntityType,@CreatedDate,@UserId,@ActionType,@EcolabAccountNumber,@MessageId)	
			
						--check for any error
						SET	@ErrorId	=	@@ERROR
						IF	(@ErrorId	<>	0)
							BEGIN
								SET		@ErrorMessage	=			N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred appending formula steps for the tunnel.'
								GOTO	ErrorHandler
							END
				END	

		IF	(	@ErrorId	=	0	)
			BEGIN
				GOTO	ExitModule
			END

		ErrorHandler:
		RAISERROR	(@ErrorMessage, 16, 1)
		SET	@ReturnValue	=	-1

		ExitModule:

		SET	NOCOUNT	OFF
		RETURN	(@ReturnValue)
END