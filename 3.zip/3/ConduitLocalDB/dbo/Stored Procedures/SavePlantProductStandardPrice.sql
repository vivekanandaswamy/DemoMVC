﻿/*      
 ==========================================================================================      
 Purpose:  Save the Standard Price 
    
 Author:  Suresh kanchamreddy

    
 --------------------------------------------------------------      
 Dec-11-2015 ENT: Initial version.      
 ==========================================================================================   
*/

CREATE PROCEDURE [TCD].[SavePlantProductStandardPrice] 
(		
		@Id										INT						=	NULL
		,@EcolabAccountNumber					NVARCHAR(25)
		,@ProductId									INT	
		,@ListPrice									FLOAT
		,@ContractPrice								FLOAT
		,@CountryPrice								FLOAT
		,@UserID									INT
	,	@OutputStandardPriceId							INT						=	NULL	OUTPUT
	,	@LastModifiedTimestampAtCentral				DATETIME				=	NULL
	,	@OutputLastModifiedTimestampAtLocal			DATETIME				=	NULL	OUTPUT
) 
AS 
SET NOCOUNT ON
  
  BEGIN 
	
	DECLARE	
		@Output							VARCHAR(100)	=			''  
	,	@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()
	
	DECLARE
			@OutputList						AS	TABLE		(
			StandardPriceId					INT
		,	LastModifiedTimestamp			DATETIME
		)

SET		@OutputLastModifiedTimestampAtLocal			=			ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight
SET		@OutputStandardPriceId							=			ISNULL(@OutputStandardPriceId, NULL)								--SQLEnlight

	
	IF EXISTS (SELECT 1 FROM [TCD].ProductStandardPrice WHERE  ProductID = @ProductId AND EcolabAccountNumber = @EcolabAccountNumber)
		BEGIN
			  
					
						  UPDATE 
							[TCD].ProductStandardPrice 
							SET 
								ListPrice = @ListPrice 
							,	ContractPrice = @ContractPrice
							,	CountryPrice = @CountryPrice
							,	LastModifiedByUserId	=	@UserID
							,	LastModifiedTime		=	@CurrentUTCTime							
							OUTPUT
								inserted.Id	AS	 StandardPriceId
							,	inserted.LastModifiedTime		AS	LastModifiedTimestamp
							INTO
								@OutputList	(
								StandardPriceId
							,	LastModifiedTimestamp
							)
							WHERE ProductID = @ProductId AND  EcolabAccountNumber = @EcolabAccountNumber 
		END
	ELSE
	IF NOT EXISTS (SELECT 1 FROM [TCD].ProductStandardPrice WHERE  ProductID = @ProductId AND EcolabAccountNumber = @EcolabAccountNumber)   
		BEGIN
			
			INSERT INTO [TCD].ProductStandardPrice(EcolabAccountNumber,ProductId,ListPrice,ContractPrice,CountryPrice,LastModifiedByUserId)
			OUTPUT
					inserted.Id						AS			StandardPriceId
				,	inserted.LastModifiedTime		AS			LastModifiedTimestamp
				INTO
					@OutputList	(
					StandardPriceId
				,	LastModifiedTimestamp
				)
			values( @EcolabAccountNumber, @ProductId, @ListPrice, @ContractPrice, @CountryPrice, @UserID )

		END

	SELECT	TOP 1	
		@OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp
	,	@OutputStandardPriceId				=	O.StandardPriceId
FROM	@OutputList							O


RETURN	(@ReturnValue)

--SET NOCOUNT OFF;
END