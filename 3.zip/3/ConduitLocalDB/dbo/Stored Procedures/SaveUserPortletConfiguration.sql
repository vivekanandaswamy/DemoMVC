﻿CREATE PROCEDURE [TCD].[SaveUserPortletConfiguration]
(
@UserId int,
@PortletId int,
@DisplayOrder int,
@IsEnabled bit,
@EcolabAccountNumber NVARCHAR(25),
@count int,
@Scope varchar(100) OUTPUT)
AS
SET NOCOUNT ON
BEGIN
	
	DECLARE @OutPut VARCHAR(50) = ''

	if(@count = 0)
		BEGIN
			Delete from [TCD].[DashboardUserPortletMapping] where UserId = @UserId and EcolabAccountNumber = @EcolabAccountNumber
		END

	BEGIN
	INSERT INTO [TCD].[DashboardUserPortletMapping]
					(UserId,PortletId,DisplayOrder,EcolabAccountNumber,IsEnabled) 
			VALUES(@UserId,@PortletId,@DisplayOrder,@EcolabAccountNumber,@IsEnabled)

	SET @OutPut = '101'     

	SET @Scope = @OutPut SELECT @Scope  

	END
END
GO