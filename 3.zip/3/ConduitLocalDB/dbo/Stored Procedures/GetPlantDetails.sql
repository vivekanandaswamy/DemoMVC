﻿CREATE PROCEDURE TCD.GetPlantDetails(
       @Ecolabaccountnumber NVARCHAR(25) = NULL	--(keeping this nullable, since it impacts the service/access layer)
)
AS
BEGIN

    SET NOCOUNT ON;

    SET @Ecolabaccountnumber = ISNULL(@Ecolabaccountnumber, NULL)


    SELECT
            p.EcolabAccountNumber, 
            p.Name, 
            p.TMName, 
            p.TMPhoneNumber, 
            p.DMName, 
            p.DMPhoneNumber, 
            (SELECT
                     PC.PlantChainName
                 FROM TCD.PlantChain AS PC
                 WHERE PC.PlantChainId = P.PlantChainId)AS Chain, 
            p.chainUnitNumber, 
            (SELECT
                     RM.RegionName
                 FROM TCD.PlantChain AS PC
                      JOIN TCD.RegionMaster AS RM ON PC.RegionId = RM.RegionId
                 WHERE PC.PlantChainId = P.PlantChainId)AS ChainRegions, 
            p.CensusPriceKg, 
            p.Remarks, 
            p.LanguageId, 
            p.CurrencyCode, 
            Addr.BillingAddr1, 
            addr.BillingAddr2, 
            addr.City, 
            addr.Country, 
            addr.zip, 
            addr.ShippingAddr1, 
            addr.ShippingAddr2, 
            addr.Shippingcity, 
            addr.Shippingcountry, 
            addr.Shippingzip, 
            p.Rate, 
            p.ExportPath, 
            p.AllowManualRewash, 
            p.DataLiveTime, 
            p.BudgetCustomer, 
            p.UOMId, 
            p.Logo, 
            p.RegionID, 
            (SELECT
                     RegionName FROM TCD.RegionMaster AS R WHERE R.RegionID = P.RegionID)AS RegionName, 
            (SELECT
                     Name FROM TCD.LanguageMaster AS L WHERE L.LanguageId = P.LanguageId)AS LanguageName, 
            (SELECT
                     CurrencyName FROM TCD.CurrencyMaster AS C WHERE c.CurrencyCode = p.CurrencyCode)AS CurrencyName, 
            (SELECT
                     UnitSystem
                 FROM TCD.DimensionalUnitSystems AS DUS
                 WHERE DUS.UnitSystemId = p.UOMId)AS UnitSystem, 
            P.LastModifiedTime AS LastModifiedTime, 
            P.MyServiceLastSynchTime AS MyServiceLastSynchTime, 
            P.LastServiceVisitDate AS LastServiceVisitDate, 
            P.LastArchiveDate AS LastArchiveDate, 
            P.NextServiceVisitDate AS NextServiceVisitDate, 
            P.PlantChainId, 
            P.MyServiceCustGuid AS MyServiceId, 
            P.ConStdTurnTime AS PlantStandardTurnTime, 
            P.PlantContractNumber AS PlantContractNumber, 
            P.PlantId AS PlantId, 
            P.DayId AS DayId, 
            P.StartTime AS StartTime, 
            P.EndTime AS EndTime,
			P.IsETechEnable AS IsETechEnable,
		    P.ETechIpAddress AS ETechIpAddress,
			P.SourceSystemId AS SourceSystemId
        FROM TCD.plant AS P
             INNER JOIN TCD.PlantCustAddress AS ADDR ON p.EcolabAccountNumber = ADDR.EcolabAccountNumber
        WHERE Is_Deleted = 0

    SET NOCOUNT OFF;
END