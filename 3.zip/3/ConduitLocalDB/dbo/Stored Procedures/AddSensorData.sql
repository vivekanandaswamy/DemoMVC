﻿CREATE PROCEDURE [TCD].[AddSensorData](
	@ControllerID       INT,
	@MachineCompartment INT,
	@MachineGroupId     INT,
	@SensorTypeID       INT,
	@ReadingValue       DECIMAL(18, 4))
AS
	BEGIN
	    DECLARE @SensorID INT;
	    DECLARE @PreviousReading DECIMAL(18, 4);
	    SELECT
			 @SensorID = NULL;
	    SELECT
			 @SensorID = SensorID
	    FROM TCD.Sensor
	    WHERE ControllerID = @ControllerID
			AND MachineCompartment = @MachineCompartment
			AND SensorType = @SensorTypeID
			AND GroupId = @MachineGroupId
			AND is_Deleted = 0;
	    IF(@SensorID IS NOT NULL)
		   BEGIN
			  IF NOT EXISTS
			  (
				 SELECT
					   Reading
				 FROM TCD.SensorReading
				 WHERE SensorID = @SensorID
			  )
				 BEGIN
					INSERT INTO TCD.SensorReading
					(
						  SensorId,
						  Reading,
						  TimeStamp
					)
					VALUES
					(
						  @SensorID,
						  @ReadingValue,
						  GETUTCDATE()
					);
				 END;
		   END;
	END;