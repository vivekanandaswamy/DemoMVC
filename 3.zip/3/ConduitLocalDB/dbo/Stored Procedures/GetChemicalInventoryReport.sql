--[TCD].[GetChemicalInventoryReport] '','','',0,'','',1,6

CREATE PROCEDURE [TCD].[GetChemicalInventoryReport] (
--DECLARE 
											 @Corporate VARCHAR(MAX) = '',
											 @Country VARCHAR(MAX) = '',
											 @Region VARCHAR(MAX) = '',
											 @EcolabAccountNumber nvarchar(25) = '',
											 @SortColumnID INT = NULL,
											 @SortDirection Varchar(100) = '',
											 @UserId Int = NULL,
											 @ReportID INT = NULL		
										   )
AS   
BEGIN   
SET NOCOUNT ON;   
/*
DECLARE @ReportGenerated INT = 6, @SortField Varchar(100) = '',@ProductId Varchar(100) = '',
@SQLStatement varchar(max), @year Int = YEAR(GETUTCDATE()),@CurrentYearWorkingDays Int = NULL,@PreviousYearWorkingDays Int = NULL,
@PrevYearConsumption Decimal(10,2),@LastInventoryWorkingDays Int = NULL,@LastInventoryFirstDay DATE = NULL,@FromDate DATETIME = GETUTCDATE()

SET	@Country			=			ISNULL(@Country, NULL)			--SQLEnlight SA0029
SET	@ReportID			=			ISNULL(@ReportID, NULL)			--SQLEnlight SA0029

/* Inserting the record into Report History */
INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)
SELECT @EcolabAccountNumber,UM.UserId,
	  UM.LoginName,
	  GETUTCDATE(),
	  @ReportGenerated,
	  CASE WHEN @ReportGenerated = 6
		THEN 'Generated Report : ChemicalInventoryReport' END
	  FROM TCD.UserMaster UM
	    WHERE	UM.EcolabAccountNumber =	@EcolabAccountNumber AND UM.UserId = @UserId

/* Completed the record insertion into Report History */

SELECT @SortField =  CASE WHEN @SortColumnID = 20 THEN 'AvgDailyCost'
	     			 WHEN @SortColumnID = 21 THEN 'AvgDailyCostPerLoad'
					 WHEN @SortColumnID = 22 THEN 'AvgDailyNeedsLY'
					 WHEN @SortColumnID = 23 THEN 'AvgDailyNeeds'
					 WHEN @SortColumnID = 47 THEN 'ChemicalName'						
					 WHEN @SortColumnID = 53 THEN 'Consumption'
					 WHEN @SortColumnID = 64 THEN 'DayBeforeLastInventory'
					 WHEN @SortColumnID = 78 THEN 'EstimateInventory'
					 WHEN @SortColumnID = 116 THEN 'LastActualInventory'
					 WHEN @SortColumnID = 117 THEN 'LastInventoryDate'
					 WHEN @SortColumnID = 138 THEN 'OrdersReceived'
					 WHEN @SortColumnID = 259 THEN 'AvgConsumptionPerDay'
					 WHEN @SortColumnID = 260 THEN 'AvgConsumptionPerWeek'
					 WHEN @SortColumnID = 261 THEN 'AvgConsumptionPerMonth'
					 WHEN @SortColumnID = 0 THEN 'ProductId'
					 END

SELECT @CurrentYearWorkingDays = CASE COUNT(RecordDate) WHEN 0 THEN NULL ELSE COUNT(RecordDate) END FROM 
		  (SELECT DISTINCT RecordDate AS RecordDate FROM
	   [TCD].[ChemicalConsumptionRollUp] WHERE YEAR(RECORDDATE) = YEAR(GETUTCDATE())) as P

  SELECT @PreviousYearWorkingDays = CASE COUNT(RecordDate) WHEN 0 THEN NULL ELSE COUNT(RecordDate) END  FROM 
		  (SELECT DISTINCT RecordDate AS RecordDate FROM
	   [TCD].[ChemicalConsumptionRollUp] WHERE YEAR(RECORDDATE) = YEAR(GETUTCDATE()) - 1) as P

  SELECT @LastInventoryWorkingDays = CASE COUNT(RecordDate) WHEN 0 THEN NULL ELSE COUNT(RecordDate) END FROM 
		  (SELECT DISTINCT RecordDate AS RecordDate FROM
	   [TCD].[ChemicalConsumptionRollUp] CCR INNER JOIN [TCD].[ChemicalInventory] CI ON CCR.ProductId = CI.ProductId WHERE CCR.RecordDate > CI.LastInventoryDate) as P

  SELECT TOP 1 @LastInventoryFirstDay = CCR.RecordDate FROM
	   [TCD].[ChemicalConsumptionRollUp] CCR INNER JOIN [TCD].[ChemicalInventory] CI ON CCR.ProductId = CI.ProductId WHERE CCR.RecordDate > CI.LastInventoryDate ORDER BY CCR.RecordDate

  SELECT @PrevYearConsumption = CASE SUM(CCR.TotalConsumption) WHEN 0 THEN NULL ELSE SUM(CCR.TotalConsumption)  END FROM [TCD].[ChemicalConsumptionRollUp] CCR WHERE YEAR(RECORDDATE) = YEAR(GETUTCDATE()) - 1

    
--CREATE TABLE #ChemicalConsumptionRollUp
--							 (
--								 [RecordDate] [date] NULL,
--								 [GroupId] [int] NULL,
--								 [MachineInternalId] [int] NULL,
--								 [ProgramNumber] [int] NULL,
--								 [ProductId] [int] NULL,
--								 [NoOfBatches] [int] NULL,
--								 [TotalConsumption] [decimal](18, 2) NULL,
--								 [TargetConsumption] [decimal](18, 2) NULL,
--								 [AverageConsumption] [decimal](18, 2) NULL,
--								 [ActualConsumptionPerLoad] [decimal](18, 2) NULL,
--								 [TargetConsumptionPerLoad] [decimal](18, 2) NULL,
--								 [Cost] [decimal](18, 2) NULL,
--								 [CostPerLoad] [decimal](18, 2) NULL,
--								 [CostExcess] [decimal](18, 2) NULL,
--								 [EcolabTextileCategoryName] [varchar](50) NULL,
--								 [EcolabTextileId] [int] NULL,
--								 [PlantTextileCategoryName] [varchar](50) NULL,
--								 [PlantTextileId] [int] NULL
--							 )


   DECLARE @ChemicalConsumption Table(
									   ProductId Int,
									   ChemicalName Varchar(1000),
									   LastActualInventory Decimal(10,0),
									   LastInventoryDate DATE,
									   OrdersReceived Decimal(10,0),
									   Consumption Decimal(10,0),
									   EstimateInventory Decimal(10,0),
									   AvgDailyNeeds Decimal(10,0),
									   AvgDailyCost Decimal(10,0),
									   AvgDailyCostPerLoad Decimal(10,0),
									   AvgDailyNeedsLY Decimal(10,0),
									   AvgConsumptionPerDay Decimal(10,0),
									   AvgConsumptionPerWeek Decimal(10,0),
									   AvgConsumptionPerMonth Decimal(10,0)								
									)
  
INSERT INTO @ChemicalConsumption(
									   ProductId,
									   ChemicalName,
									   LastActualInventory ,
									   LastInventoryDate ,
									   OrdersReceived,
									   Consumption ,
									   EstimateInventory,
									   AvgDailyNeeds,
									   AvgDailyCost ,
									   AvgDailyCostPerLoad,
									   AvgDailyNeedsLY ,
									   AvgConsumptionPerDay,
									   AvgConsumptionPerWeek ,
									   AvgConsumptionPerMonth								
									)
    SELECT 
	   CCR.ProductId,
	   PM.Name,
	   CI.LastActualInventory,
	   CI.LastInventoryDate,
	   CI.OrdersReceived,
	   SUM(CCR.TotalConsumption),
	   (CI.LastActualInventory + CI.OrdersReceived) - SUM(CCR.TotalConsumption) AS EstimateInventory,
	   SUM(CCR.TotalConsumption)/@CurrentYearWorkingDays,
	   SUM(CCR.Cost)/@CurrentYearWorkingDays,
	   SUM(CCR.Cost)/SUM(CCR.NoOfBatches),
	   @PrevYearConsumption/@PreviousYearWorkingDays,
	   SUM(CCR.TotalConsumption)/@LastInventoryWorkingDays,
	  CASE DATEDIFF(WEEK,@LastInventoryFirstDay,CAST(GETUTCDATE() AS date)) WHEN 0 THEN NULL ELSE
	   SUM(CCR.TotalConsumption)/DATEDIFF(WEEK,@LastInventoryFirstDay,CAST(GETUTCDATE() AS date)) END,
	   CASE DATEDIFF(MONTH,@LastInventoryFirstDay,CAST(GETUTCDATE() AS date)) WHEN 0 THEN NULL ELSE
	   SUM(CCR.TotalConsumption)/DATEDIFF(MONTH,@LastInventoryFirstDay,CAST(GETUTCDATE() AS date)) END
    FROM [TCD].[ChemicalConsumptionRollUp] CCR INNER JOIN
		  [TCD].[ChemicalInventory] CI ON CCR.ProductId = CI.ProductId LEFT OUTER JOIN
		      TCD.ProductMaster PM ON PM.ProductId = CCR.ProductId
	   GROUP BY CCR.ProductId,PM.Name,CI.LastActualInventory,CI.LastInventoryDate,CI.OrdersReceived
/*
	   /* Including the latest data from batch tables */

				INSERT INTO #ChemicalConsumptionRollUp
					 EXEC [TCD].[BatchChemicalLatestData] @Corporate,@Country,@Region,@EcolabAccountNumber,'','','',
												     '','','','','','',@FromDate
				
				INSERT INTO @ChemicalConsumption
				  SELECT 
					   CCR.ProductId,
					   PM.Name,
					   CI.LastActualInventory,
					   CI.LastInventoryDate,
					   CI.OrdersReceived,
					   SUM(CCR.TotalConsumption),
					   (CI.LastActualInventory + CI.OrdersReceived) - SUM(CCR.TotalConsumption) AS EstimateInventory,
					   SUM(CCR.TotalConsumption)/@CurrentYearWorkingDays,
					   SUM(CCR.Cost)/@CurrentYearWorkingDays,
					   SUM(CCR.Cost)/SUM(CCR.NoOfBatches),
					   @PrevYearConsumption/@PreviousYearWorkingDays,
					   SUM(CCR.TotalConsumption)/@LastInventoryWorkingDays,
					   SUM(CCR.TotalConsumption)/DATEDIFF(WEEK,@LastInventoryFirstDay,CAST(GETUTCDATE() AS date)),
					   SUM(CCR.TotalConsumption)/DATEDIFF(MONTH,@LastInventoryFirstDay,CAST(GETUTCDATE() AS date))
				    FROM #ChemicalConsumptionRollUp CCR INNER JOIN
						  [TCD].[ChemicalInventory] CI ON CCR.ProductId = CI.ProductId LEFT OUTER JOIN
							 TCD.ProductMaster PM ON PM.ProductId = CCR.ProductId
				    GROUP BY CCR.ProductId,PM.Name,CI.LastActualInventory,CI.LastInventoryDate,CI.OrdersReceived

								    /* End of production latest batch data */
*/
SELECT 
	   CC.ProductId, 
	   CC.ChemicalName,
	   CC.LastActualInventory,
	   CAST(CC.LastInventoryDate AS DATE) AS LastInventoryDate,
	   CC.OrdersReceived,
	   CC.Consumption,
	   cc.EstimateInventory,
	   CC.AvgDailyNeeds,
	   CC.AvgDailyCost,
	   CC.AvgDailyCostPerLoad,
	   CC.AvgDailyNeedsLY,
	   CAST((CC.EstimateInventory/CC.AvgDailyNeeds) AS INT) AS DayBeforeLastInventory,
	   CC.AvgConsumptionPerDay,
	   CC.AvgConsumptionPerWeek,
	   CC.AvgConsumptionPerMonth
	    INTO #ChemicalInventoryOrder
			 FROM @ChemicalConsumption CC 

    --    SET @SQLStatement 
				--	   ='SELECT * FROM #ChemicalInventoryOrder'
    --EXEC(@SQLStatement)

    SET @SQLStatement 
					   ='SELECT * FROM #ChemicalInventoryOrder ORDER BY ' + @SortField + ' ' + @SortDirection
    EXEC(@SQLStatement)
    */
END