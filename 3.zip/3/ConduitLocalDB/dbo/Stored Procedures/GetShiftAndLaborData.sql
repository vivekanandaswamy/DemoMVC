

CREATE PROCEDURE [TCD].[GetShiftAndLaborData](@ShiftId Int = Null, @DayId Int = Null, @EcolabAccountNumber nvarchar(25), @IsDeleted BIT = 'FALSE')  

AS

BEGIN  

SET NOCOUNT ON; 
  

  
SELECT 

    SD.EcolabAccountNumber  

    ,SD.ShiftId  

    ,ShiftName

    ,SD.DayId  

    ,DayName = (SELECT W.DayName FROM [TCD].WeekDay W WHERE W.DayId = SD.DayId)  

    ,ShiftStartTime = SD.StartTime  
    
    ,ShiftEndTime = SD.EndTime  

	,CASE  WHEN (SBD.IS_Deleted = 0 OR @IsDeleted = 'True') THEN SBD.BreakId WHEN SBD.IS_Deleted = 1 THEN Null End As BreakId  

    ,CASE  WHEN (SBD.IS_Deleted = 0 OR @IsDeleted = 'True') THEN SBD.ShiftId WHEN SBD.IS_Deleted = 1 THEN Null End As BreakShiftId  

    ,CASE  WHEN (SBD.IS_Deleted = 0 OR @IsDeleted = 'True') THEN SBD.DayId WHEN SBD.IS_Deleted = 1 THEN Null End As  BreakDayId  

    ,CASE  WHEN (SBD.IS_Deleted = 0 OR @IsDeleted = 'True') THEN SBD.StartTime WHEN SBD.IS_Deleted = 1 THEN Null End As  BreakStartTime  

    ,CASE  WHEN (SBD.IS_Deleted = 0 OR @IsDeleted = 'True') THEN SBD.EndTime WHEN SBD.IS_Deleted = 1 THEN Null End As  BreakEndTime  
	
	,CASE  WHEN (SBD.IS_Deleted = 0 OR @IsDeleted = 'True') THEN SBD.IS_Deleted WHEN SBD.IS_Deleted = 1 THEN Null End As  IsDeleted

    ,SD.TargetProduction     
    ,    SD.LastModifiedTime                    AS            LastModifiedTime
    ,    SD.LastSyncTime                        AS            LastSyncTime
    ,    SD.TargetProduction_Display            As            TargetProduction_Display
	, SD.Is_Deleted								AS			  IsDeleted
    FROM [TCD].ShiftData SD  

    LEFT JOIN   

    [TCD].ShiftBreakData SBD ON SD.ShiftId = SBD.ShiftId AND SD.DayId = SBD.DayId      
    
    WHERE        

    SD.EcolabAccountNumber = @EcolabAccountNumber AND (SD.Is_Deleted = 'FALSE' OR SD.Is_Deleted = @IsDeleted) AND  

    CASE IsNull(@ShiftId,'') WHEN '' THEN 'true'   

   WHEN @ShiftId THEN CASE WHEN  SD.ShiftId = @ShiftId THEN 'true' END END = 'true' AND  

    CASE IsNull(@DayId,'') WHEN '' THEN 'true' WHEN @DayId THEN CASE WHEN  SD.DayId = @DayId THEN 'true' END  

    END = 'true'  

    Order by SD.DayId, SD.StartTime Asc

SET NOCOUNT OFF; 
END