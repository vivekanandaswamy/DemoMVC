﻿/*	                                   
###################################################################################################                                           

User-defined Fn.	:       [TCD].[GetDryerGroupDetails]

Purpose				:		Get Dryer Groups and associated Dryer details in Dryers tab
							Ported from ConduitLocalDB as-is.
																												
Parameters			:		@UsageKey
							@UnitSystemId

###################################################################################################                                           
*/

CREATE	PROCEDURE	[TCD].[GetDryerGroupDetails]
					@EcolabAccountNumber					NVARCHAR(25)
AS
BEGIN


SET nocount ON;

;
WITH	CTE
AS
(
	SELECT
			Id
		,	DryerNo
		,	[Description]
		,	Capacity
		,	DryerGroupId
		,	DryerTypeId
		,	D.LastModifiedTime			AS			DryerLastModifiedTime,
		Capacity_Display
	FROM	[TCD].Dryers				D
	WHERE	D.EcolabAccountNumber		=			@EcolabAccountNumber
		AND	D.Is_Deleted				=			'FALSE'
)

Select  G.Id
,D.Id
,D.DryerNo
,D.Description
,D.Capacity
, G.GroupDescription
, G.EcolabAccountNumber
, DT.DryerTypeId
, DT.Name AS DryerTypeName
,	G.LastModifiedTime			AS			DryerGroupLastModifiedTime
,   G.Is_Deleted	        AS          IsDeleted
,	D.DryerLastModifiedTime		AS			DryerLastModifiedTime,
D.Capacity_Display
from [TCD].MachineGroup G LEFT OUTER JOIN CTE D ON G.Id = D.DryerGroupId
Left Join [TCD].DryerType DT on DT.DryerTypeId = D.DryerTypeId

WHERE
G.EcolabAccountNumber = @EcolabAccountNumber
--AND G.Is_Deleted = 0
AND G.GroupTypeId = 3

ORDER BY G.Id DESC

END


