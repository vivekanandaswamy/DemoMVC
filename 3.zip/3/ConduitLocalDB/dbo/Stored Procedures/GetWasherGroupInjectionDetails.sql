CREATE  PROCEDURE [TCD].[GetWasherGroupInjectionDetails]
            (
            @EcolabAccountNumber nvarchar(25) = NULL,
            @WasherGroupId Int = NULL,
			@ControllerId Int = NULL
            )
AS
SET NOCOUNT ON
BEGIN

SELECT  
    DISTINCT
    WDS.WasherDosingSetupId
    ,WPS.ProgramNumber
    ,WG.WasherGroupNumber
    ,WDP.InjectionNumber
    ,CES.ControllerEquipmentId
    ,WDP.ProductId
    ,PM.Name
    ,WDP.Quantity
    ,IJ.ReferenceLoad
    ,WDS.StepNumber
    ,WS.[StepId] AS WashOperationId
    ,WS.[StepName] AS WashOperation
    ,IJ.InjectionClass
    ,IJ.ControllerId
    ,CT.Id AS ControllerType
	,WPS.NominalLoad
	,WPS.WasherProgramSetupId
   FROM [TCD].[WasherDosingSetup]   WDS

   INNER JOIN [TCD].[WasherProgramSetup] WPS 
    ON WPS.[WasherProgramSetupId] = WDS.[WasherProgramSetupId] AND WDS.Is_Deleted = 0
   INNER JOIN TCD.WasherGroup WG ON WG.WasherGroupId = WPS.WasherGroupId AND WPS.Is_Deleted =0
   INNER JOIN TCD.Injection IJ ON WG.WasherGroupNumber = IJ.WasherGroupNumber AND IJ.Is_Deleted =0
   INNER JOIN TCD.ConduitController CC ON IJ.ControllerId = CC.ControllerId AND CC.IsDeleted = 0 AND CC.Active = 1
   INNER JOIN TCD.ControllerType CT ON CC.ControllerTypeId = CT.Id  
   LEFT JOIN TCD.WasherDosingProductMapping WDP ON WDS.WasherDosingSetupId = WDP.WasherDosingSetupId AND WDP.IsDeleted = 0

   LEFT JOIN TCD.ProductMaster PM ON WDP.ProductId = PM.ProductId and pm.Is_Deleted =0
   INNER JOIN TCD.ControllerEquipmentSetup CES ON CES.ProductId = PM.ProductId and CES.IsActive = 1 and CES.CONTROLLERID=CC.ControllerId

   LEFT JOIN [TCD].WashStep    WS
    ON WS.StepId     =   WDS.StepTypeId AND WS.IsActive =1

    WHERE WG.WasherGroupId = @WasherGroupId AND WG.EcolabAccountNumber = @EcolabAccountNumber AND cc.ControllerId = @ControllerId 
    AND WDP.InjectionNumber IS NOT NULL
 END