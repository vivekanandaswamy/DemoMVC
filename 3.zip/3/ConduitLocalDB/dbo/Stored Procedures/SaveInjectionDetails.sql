CREATE  PROCEDURE [TCD].[SaveInjectionDetails](
            @WasherGroupId Int = NULL,
	    @NewWasherGroupId INT = NULL,
            @ControllerId Int = NULL,
            @WasherId Int = NULL,
            @EcolabAccountNumber nvarchar(25)
          )
AS
SET NOCOUNT ON
BEGIN 
IF(@WasherGroupId IS NOT NULL AND @NewWasherGroupId IS NOT NULL AND @WasherId IS NOT NULL AND @WasherId <> 0 AND @ControllerId <> 0)
    BEGIN
	DECLARE @MaxRefLoad SMALLINT,@NewMaxRefLoad SMALLINT,@WasherGroupNo Int, @NewWasherGroupNo INT, @InjectionClass Int,@IsDeleted Int,@WasherGroupIsDeleted Int

	SELECT @WasherGroupNo = WG.WasherGroupNumber FROM TCD.WasherGroup WG WHERE WG.WasherGroupId = @WasherGroupId 
	SELECT @NewWasherGroupNo = WG.WasherGroupNumber FROM TCD.WasherGroup WG WHERE WG.WasherGroupId = @NewWasherGroupId 

	SELECT @MaxRefLoad = MAX(WS.MaxLoad) FROM TCD.MachineSetup MS 
        JOIN TCD.Washer WS ON MS.WasherId = WS.WasherId
        JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId 
        WHERE WG.WasherGroupNumber = @WasherGroupNo AND MS.IsDeleted = 0

	SELECT @NewMaxRefLoad = MAX(WS.MaxLoad) FROM TCD.MachineSetup MS 
        JOIN TCD.Washer WS ON MS.WasherId = WS.WasherId
        JOIN TCD.WasherGroup WG ON MS.GroupId = WG.WasherGroupId 
        WHERE WG.WasherGroupNumber = @NewWasherGroupNo AND MS.IsDeleted = 0

	SELECT @WasherGroupIsDeleted = MG.Is_Deleted FROM TCD.MachineGroup MG WHERE MG.Id = @NewWasherGroupId 

	SELECT @IsDeleted = MS.Is_Deleted From TCD.Washer MS Where MS.WasherId = @WasherId

	DECLARE @MissingWGno TABLE
		    (
		    ControllerId int,
		    InjectionClass int
		    )

	IF @WasherGroupId = @NewWasherGroupId
	BEGIN
	    IF NOT EXISTS (SELECT 1 FROM TCD.Injection I WHERE I.WasherId = @WasherId AND I.WasherGroupNumber = @WasherGroupNo AND Is_Deleted = 0)
	    BEGIN
		IF NOT EXISTS(SELECT 1 FROM TCD.Injection AS I WHERE I.ControllerId = @ControllerId AND Is_Deleted = 0)
		BEGIN
		    SET @InjectionClass = 1  
		END
		ELSE
		BEGIN
		    IF EXISTS(SELECT 1 FROM TCD.Injection AS I WHERE I.ControllerId = @ControllerId AND I.WasherGroupNumber = @WasherGroupNo AND Is_Deleted = 0)
		    BEGIN
			SELECT @InjectionClass = I.InjectionClass FROM TCD.Injection AS I WHERE I.ControllerId = @ControllerId AND I.WasherGroupNumber = @WasherGroupNo AND Is_Deleted = 0
		    END
		    ELSE
		    BEGIN
			INSERT INTO @MissingWGno
			SELECT DISTINCT I.ControllerId,I.InjectionClass FROM TCD.Injection AS I WHERE I.ControllerId = @ControllerId AND Is_Deleted = 0

			SELECT @InjectionClass =  (SELECT isnull(max(InjectionClass)+1,1) FROM @MissingWGno WHERE InjectionClass < md.InjectionClass)   
			FROM @MissingWGno AS  md
			WHERE md.InjectionClass <> 1 and not exists (
			SELECT 1 FROM @MissingWGno md2 where md2.InjectionClass = md.InjectionClass - 1)

			IF (COUNT(@InjectionClass) <> 1)
			BEGIN
				SELECT @InjectionClass = MAX(InjectionClass) + 1  FROM @MissingWGno AS MW GROUP BY MW.ControllerId
			END
    		    END        
		END
		
		INSERT INTO TCD.Injection(WasherId,WasherGroupNumber,InjectionClass,ControllerId,ReferenceLoad,EcolabAccountNumber)
		VALUES	(@WasherId,
			@WasherGroupNo,
			@InjectionClass,
			@ControllerId,
			@MaxRefLoad,
			@EcolabAccountNumber)
           
            END
	END
	ELSE
	BEGIN
	    IF EXISTS (SELECT 1 FROM TCD.Injection I WHERE I.WasherId = @WasherId AND I.WasherGroupNumber = @WasherGroupNo AND Is_Deleted = 0)
	    BEGIN
		IF EXISTS(SELECT 1 FROM TCD.Injection AS I WHERE I.ControllerId = @ControllerId AND I.WasherGroupNumber = @NewWasherGroupNo AND Is_Deleted = 0)
		BEGIN
		    SELECT @InjectionClass = I.InjectionClass FROM TCD.Injection AS I WHERE I.ControllerId = @ControllerId AND I.WasherGroupNumber = @NewWasherGroupNo AND Is_Deleted = 0
		END
		ELSE
		BEGIN
		    
		    INSERT INTO @MissingWGno
		    SELECT DISTINCT I.ControllerId,I.InjectionClass FROM TCD.Injection AS I WHERE I.ControllerId = @ControllerId AND Is_Deleted = 0

		    SELECT @InjectionClass =  (SELECT isnull(max(InjectionClass)+1,1) FROM @MissingWGno WHERE InjectionClass < md.InjectionClass)   
		    FROM @MissingWGno AS  md
		    WHERE md.InjectionClass <> 1 and not exists (
		    SELECT 1 FROM @MissingWGno md2 where md2.InjectionClass = md.InjectionClass - 1)
		    SELECT @InjectionClass = MAX(InjectionClass) FROM @MissingWGno AS MW GROUP BY MW.ControllerId

		    IF ((SELECT COUNT(1) FROM TCD.Injection i WHERE i.WasherGroupNumber = @WasherGroupNo AND i.ControllerId = @ControllerId) > 1)
		    BEGIN
		       SELECT @InjectionClass = MAX(InjectionClass) + 1  FROM @MissingWGno AS MW GROUP BY MW.ControllerId
		    END
		    ELSE
		    BEGIN
			SELECT @InjectionClass = MAX(InjectionClass) FROM @MissingWGno AS MW GROUP BY MW.ControllerId
		    END
	       END
	       
	        UPDATE TCD.Injection
		SET
		    WasherGroupNumber = @NewWasherGroupNo,
		    InjectionClass = @InjectionClass,
		    ReferenceLoad = @MaxRefLoad
		WHERE WasherGroupNumber = @WasherGroupNo
		AND ControllerId = @ControllerId
		AND EcolabAccountNumber = @EcolabAccountNumber
		AND WasherId = @WasherId        
	    END

	    UPDATE TCD.Injection SET ReferenceLoad = @MaxRefLoad WHERE WasherGroupNumber = @WasherGroupNo AND Is_Deleted = 0 
	END

	BEGIN 
		UPDATE TCD.Injection SET ReferenceLoad = @NewMaxRefLoad WHERE WasherGroupNumber = @NewWasherGroupNo AND Is_Deleted = 0
		IF(@WasherId = 0 AND @ControllerId =0)
		BEGIN
		UPDATE TCD.Injection SET Is_Deleted = @WasherGroupIsDeleted WHERE WasherGroupNumber = @NewWasherGroupNo AND Is_Deleted = 0
		END
		UPDATE TCD.Injection SET Is_Deleted = @IsDeleted,ControllerId = @ControllerId WHERE WasherId = @WasherId AND Is_Deleted = 0
	END 
 END 
END