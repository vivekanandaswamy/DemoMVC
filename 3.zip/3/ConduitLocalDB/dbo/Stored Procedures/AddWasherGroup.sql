﻿/*	
Purpose					:	To add a new washer group from Washer setup screen

History					:
Sept. 2014		dfozdar@allianceglobalservice.com		initial version



*/
CREATE	PROCEDURE	[TCD].AddWasherGroup
					@MyServiceWasherGroupGuid			    UNIQUEIDENTIFIER
				,	@EcoLabAccountNumber					NVARCHAR(25)
				,	@WasherGroupNumber						VARCHAR(10)
				,	@WasherGroupName						NVARCHAR(50)
				,	@WasherGroupTypeId						TINYINT
				,	@OutputWasherGroupId					INT					OUTPUT								--Id of the newly inserted WasherGroup (as GroupType.GroupTypeId)
				,	@UserId									INT
				,	@IsDeleted								BIT			
				--Adding this params as part of re-factoring for integration with Synch/Configurator... generated WasherGroupId is already being OUTPUT
				,	@OutputLastModifiedTimestampAtLocal		DATETIME	=	NULL	OUTPUT
				,	@MyServiceLastSyncTime					DATETIME				=	NULL
AS
BEGIN

SET	NOCOUNT	ON


DECLARE	
		@GroupTypeId					INT			    =			2
	,	@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()

--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
SET		@OutputLastModifiedTimestampAtLocal				=			@CurrentUTCTime
SET		@OutputWasherGroupId							=			ISNULL(@OutputWasherGroupId, NULL)			--SQLEnlight SA0121

--Since data for WasherGroup is across 2 tables... we will need to check for the uniqueness of WasherGroupNumber/Name here...
IF	EXISTS	(		SELECT	1
					FROM	[TCD].MachineGroup					GT									--the master table for 'Groups'
					JOIN	[TCD].WasherGroup				WG
						ON	GT.Id				=			WG.WasherGroupId
						AND	GT.EcolabAccountNumber		=			WG.EcolabAccountNumber
					WHERE	GT.EcolabAccountNumber		=			@EcoLabAccountNumber
						AND	(
							WG.WasherGroupNumber		=			@WasherGroupNumber
							OR
							WG.WasherGroupName			=			@WasherGroupName
							)
						AND	GT.Is_Deleted				=			@IsDeleted
			)
		BEGIN
				SET		@ErrorId						=			51000
				SET		@ErrorMessage					=			N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Specified WasherGroup NUMBER/NAME already exists for the plant.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
		END


--We can now INSERT the new record
	BEGIN	TRAN

	INSERT	[TCD].MachineGroup	(MyServiceCustMchGrpGuid, EcolabAccountNumber	,GroupDescription	,GroupTypeId		,Is_Deleted	,LastModifiedByUserId, [MyServiceLastSynchTime])
	VALUES				(@MyServiceWasherGroupGuid, @EcoLabAccountNumber	,@WasherGroupName		,@GroupTypeId		,@IsDeleted	,@UserId, @MyServiceLastSyncTime)
	--check for any error
	SET	@ErrorId	=	@@ERROR
	
	IF	(@ErrorId	<>	0)
		BEGIN
				IF	@@TRANCOUNT	>	0
				BEGIN
					ROLLBACK	TRAN
				END

				SET		@ErrorMessage					=			N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred creating new record for washer group.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
		END
	--Else, continue inserting the remaining part of the record in the split table...
	--Get the Id of the newly created record in the GroupType table
	SELECT	@OutputWasherGroupId	=	SCOPE_IDENTITY()

	--now actual insert of the remaining part...
	INSERT	[TCD].WasherGroup	(	EcolabAccountNumber		,WasherGroupId			,WasherGroupNumber	,WasherGroupName	,WasherGroupTypeId	,ControllerId	,LastModifiedByUserId		)
	VALUES						(	@EcoLabAccountNumber	,@OutputWasherGroupId	,@WasherGroupNumber	,@WasherGroupName	,@WasherGroupTypeId	,NULL			,@UserId					)
	--check for any error
	SET	@ErrorId	=	@@ERROR

	IF	(@ErrorId	<>	0)
		BEGIN
				IF	@@TRANCOUNT	>	0
				BEGIN
					ROLLBACK	TRAN
				END

				SET		@OutputWasherGroupId			=			NULL

				SET		@ErrorMessage					=			N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred creating new record for washer group.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
		END
	ELSE
		BEGIN
				IF	@@TRANCOUNT	>	0
				BEGIN
					COMMIT
				END
		END


--Commenting, as this is not reqd....
--IF	(	@ErrorId	=	0	)
--	BEGIN
--		--GOTO	ExitModule
--		RETURN	(@ReturnValue)
--	END




--ErrorHandler:
--RAISERROR	(@ErrorMessage, 16, 1)
--SET	@ReturnValue	=	-1




--ExitModule:

SET	NOCOUNT	OFF
RETURN	(@ReturnValue)


END
