﻿CREATE PROCEDURE [TCD].[GetReportFilters]
	 (
		@UserId INT = NULL, --needed for localization                       --58183
		@RoleId INT = NULL, -- Needed for Ecolab category filters Etc...    --4
		@IsLocal BIT = NULL, -- Needed for local filters 
		@ReportId INT = NULL, -- Needed for Report level filters
		@LanguageId INT = 1
	 )
AS
SET NOCOUNT ON
BEGIN
DECLARE @EcolabAccountNumber Nvarchar(25), @ChainName VARCHAR(1000)
SELECT @EcolabAccountNumber = P.EcolabAccountNumber FROM TCD.Plant P
SELECT @ChainName = PC.PlantChainName FROM TCD.PlantChain PC INNER JOIN 
									   TCD.plant P ON P.PlantChainId = PC.PlantChainId WHERE P.EcolabAccountNumber = @EcolabAccountNumber
IF(@LanguageId > 2)
BEGIN
	SET @LanguageId = 1;
END
    DECLARE @FilterTable TABLE
	  (
		ReportFilterId Int,
		FilterName Varchar(1000),
		Name Varchar(1000),
		IsDefault BIT,
		GroupType Int,
		SortOrder int
	  )
    INSERT INTO @FilterTable
	   (
		ReportFilterId,
		FilterName,
		Name,
		IsDefault,
		GroupType,
		SortOrder 
	   )					
    SELECT 
		  RF.ReportFilterId,
		  RF.FilterName,
		  RKV.Value,
		  RFM.IsDefault	,
		  CASE WHEN RF.Filtername In ('Country','Region') THEN 1 ELSE 0 END,
		  RFM.SortOrder 	 
	    FROM [TCD].ReportFilter RF
		INNER JOIN 
		[TCD].ReportFilterMapping RFM ON RF.ReportFilterId = RFM.FilterId
		INNER JOIN
		[TCD].ReportLocalizationFilterMapping RLF ON RLF.ReportFilterId = RFM.FilterId 
		INNER JOIN 
		[TCD].ReportFilterRoleMapping RRM ON RRM.ReportFilterId = RF.ReportFilterId
		INNER JOIN 
		[TCD].ResourceKeyMaster RK ON RLF.UsageKey=RK.[KeyName]
		INNER JOIN
		[TCD].ResourceKeyValue RKV ON RK.[KeyName]=RKV.[KeyName]
	    WHERE RFM.ReportId = @ReportId AND RRM.SettingValue = 1 AND RRM.RoleId = @RoleId
				AND RFM.sortOrder IS NOT NULL AND RF.IsLocal = 1 AND RKV.languageID=@LanguageId
				 ORDER BY RFM.sortOrder
	   SELECT 
		 ReportFilterId,
		 FilterName,
		 CASE ReportFilterId WHEN 23 THEN ISNULL( @ChainName,'') + ' ' + Name
						 WHEN 24 THEN ISNULL( @ChainName,'') + ' ' + Name
						 ELSE Name END AS Name,
		 IsDefault,
		 GroupType
		FROM @FilterTable order by SortOrder
END
