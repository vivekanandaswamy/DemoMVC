﻿CREATE PROCEDURE [TCD].[ProcessMyControlOnlineProductDosing](
	@ControllerID INT,
	@VxML         XML)
AS
	BEGIN
	    DECLARE @TheoreticalQty    DECIMAL(10, 6),
			  @RealQty           DECIMAL(10, 6),
			  @BatchNumber       INT,
			  @DosingPoint       INT,
			  @DosingNumber      INT,
			  @ValveNumber       INT,
			  @ProgramNumber     INT,
			  @WasherId          INT,
			  @MachineInternalId INT,
			  @PrevRealQty       DECIMAL(10, 6),
			  @ProductId         INT,
			  @PumpNum           INT,
			  @EquipmentType     INT,
			  @CompartmentNum    INT;
	    SELECT @TheoreticalQty = T.c.value('@TheoreticalQty','Decimal(10,6)'),
			 @RealQty = T.c.value('@RealQty', 'Decimal(10,6)'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @DosingPoint = T.c.value('@DosingPoint', 'INT'),
			 @DosingNumber = T.c.value('@DoseNumber', 'INT'),
			 @PumpNum = T.c.value('@PumpNum', 'INT'),
			 @ValveNumber = T.c.value('@ValveNumber', 'INT')
	    FROM @VxML.nodes('MyControlOnlineProductDosing') T(C);
	    IF(@PumpNum >= 25
		  AND @PumpNum <= 26)
		   BEGIN
			  SET @EquipmentType = 2;
			  SET @RealQty = @RealQty * 16  --Converting pounds to ounces
			  SET @TheoreticalQty = @TheoreticalQty * 16
		   END;
	    ELSE
		   BEGIN
			  SET @EquipmentType = 1;
		   END;
	    IF(@DosingPoint >= 17
		  AND @DosingPoint <= 20)
		   BEGIN
			  SET @MachineInternalId = 1;
		   END;
	    ELSE
	    IF(@DosingPoint >= 21
		  AND @DosingPoint <= 24)
		   BEGIN
			  SET @MachineInternalId = 2;
		   END;
	    IF(@DosingPoint >= 1
		  AND @DosingPoint <= 16)
		   BEGIN
			  SET @MachineInternalId = @DosingPoint;
			  SELECT @WasherId = WasherId
			  FROM TCD.MachineSetup
			  WHERE ControllerID = @ControllerID
				   AND MachineInternalId = @MachineInternalId
				   AND IsTunnel = 0
				   AND IsDeleted = 0;
			  SELECT @ProductId = ProductId
			  FROM TCD.ControllerEquipmentSetup
			  WHERE ControllerEquipmentId = @PumpNum
				   AND ControllerID = @ControllerID;
		   END;
	    ELSE
	    IF(@DosingPoint >= 17
		  AND @DosingPoint <= 24)
		   BEGIN
			  SELECT @WasherId = WasherId
			  FROM TCD.MachineSetup
			  WHERE ControllerID = @ControllerID
				   AND MachineInternalId = @MachineInternalId
				   AND IsTunnel = 1
				   AND IsDeleted = 0;
			  SELECT @ProductId = CES.ProductId,
				    @CompartmentNum = TCEVM.CompartmentNumber
			  FROM tcd.ControllerEquipmentSetup CES
				  INNER JOIN TCD.
				  TunnelCompartmentEquipmentValveMapping TCEVM ON CES.
				  ControllerEquipmentSetupId = TCEVM.ControllerEquipmentSetupId
			  WHERE CES.ControllerId = @ControllerID
				   AND CES.ControllerEquipmentTypeId = @EquipmentType
				   AND TCEVM.ValveNumber = @ValveNumber
				   AND CES.ControllerEquipmentId = @PumpNum;
		   END;
	    SELECT TOP 1 @PrevRealQty = RealQty
	    FROM TCD.WasherProductReading
	    WHERE ControllerId = @ControllerID
			AND WasherId = @WasherId
	    ORDER BY DateTimeStamp DESC;
	    IF(@ProductId IS NOT NULL)
		   BEGIN
			  IF(@PrevRealQty IS NULL
				OR @PrevRealQty != @RealQty)
				 BEGIN
					INSERT INTO [TCD].[WasherProductReading]
					(ControllerId,
					 WasherId,
					 MachineInternalId,
					 ProductId,
					 TheoreticalQty,
					 RealQty,
					 DosingPoint,
					 DosingNumber,
					 ProgramNumber,
					 BatchNumber,
					 ValveNumber,
					 DateTimeStamp
					)
						  SELECT @ControllerId,
							    @WasherId,
							    @MachineInternalId,
							    @ProductId,
							    @TheoreticalQty,
							    @RealQty,
							    @DosingPoint,
							    @DosingNumber,
							    @ProgramNumber,
							    @BatchNumber,
							    @ValveNumber,
							    GETUTCDATE();
				 END;
		   END;
	END