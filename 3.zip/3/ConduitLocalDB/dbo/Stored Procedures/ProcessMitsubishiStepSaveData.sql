﻿CREATE PROCEDURE TCD.ProcessMitsubishiStepSaveData(
 @Controllerid	 INT, 
 @Vxml			 XML, 
 @Redflagshiftid INT OUTPUT)
AS
BEGIN
	DECLARE @Machinenumber			 INT, 
			@Stepnumber				 INT, 
			@Startdatetime			 DATETIME, 
			@Enddatetime			 DATETIME, 
			@Programnumber			 INT, 
			@Load					 DECIMAL(10, 2), 
			@Nominalload			 DECIMAL(10, 2), 
			@Customernumber			 INT, 
			@Waterconsumption1		 INT, 
			@Phstatus				 INT, 
			@Phvalue				 INT, 
			@Temperaturemin			 INT, 
			@Temperaturemax			 INT, 
			@Tempstatus				 INT, 
			@Batchnumber			 INT, 
			@Washerid				 INT, 
			@Washergroupid			 INT, 
			@Ecolabwasherid			 INT, 
			@Programmasterid		 INT, 
			@Plantwashernumber		 INT, 
			@Shiftid				 INT, 
			@Parameterid			 INT, 
			@Batchid				 INT, 
			@Shiftstartdate			 DATETIME, 
			@Shiftname				 NVARCHAR(50), 
			@Previousstep			 INT, 
			@Xmldataid				 INT, 
			@Laststep				 INT, 
			@Currentstep			 INT, 
			@Currentsteptime		 DATETIME, 
			@Mintempparamid			 INT, 
			@Maxtempparamid			 INT, 
			@Mintempstatuparamid	 INT, 
			@Maxtempstatusparamid	 INT, 
			@Phstatusparamid		 INT, 
			@Phvalueparamid			 INT, 
			@Runtime				 INT, 
			@Errormessage			 NVARCHAR(MAX), 
			@Stepduration			 INT, 
			@Batchstartdatetime		 DATETIME, 
			@Minstepno				 INT, 
			@Stepstarttime			 DATETIME, 
			@Maxwashertgroupcapacity INT, 
			@Washstep				 INT, 
			@Cooldownfactor			 INT, 
			@Ecolabaccountnumber	 VARCHAR(100), 
			@Alarmgroupmasterid		 INT,
			@TotalInjectsCountFromUI		INT,
			@TotalInjectsCountFromPLC		INT;;
	SELECT 
		   @Xmldataid = SCOPE_IDENTITY();
	SELECT 
		   @Machinenumber = T.c.value('@MachineNumber', 'INT'), 
		   @Stepnumber = T.c.value('@StepNumber', 'INT'), 
		   @Startdatetime = T.c.value('@StartDateTime', 'DateTime'), 
		   @Enddatetime = T.c.value('@EndDateTime', 'DateTime'), 
		   @Waterconsumption1 = T.c.value('@WaterConsumption1', 'INT'), 
		   @Phstatus = T.c.value('@PHStatus', 'INT'), 
		   @Phvalue = T.c.value('@PHValue', 'INT'), 
		   @Temperaturemin = T.c.value('@TemperatureMin', 'INT'), 
		   @Temperaturemax = T.c.value('@TemperatureMax', 'INT'), 
		   @Batchnumber = T.c.value('@BatchNumber', 'INT'), 
		   @Runtime = T.c.value('@Runtime', 'INT'), 
		   @Stepduration = T.c.value('@StepDuration', 'INT'), 
		   @Cooldownfactor = T.c.value('@CoolDown', 'INT')
		FROM @Vxml.nodes('ConventionalWasherData') AS T(C);
	--Check for valid startdatetime
	IF @Startdatetime <= '01/01/1900'
	   OR @Startdatetime > '06/06/2079'
		BEGIN
			RETURN;
		END;
	SELECT 
		   @Washergroupid = GroupId, 
		   @Washerid = WasherID
		FROM TCD.MachineSetup AS ms
		WHERE ControllerID = @Controllerid
			  AND MachineInternalId = @Machinenumber
			  AND IsTunnel = 0
			  AND ms.IsDeleted = 0;
	SELECT 
		   @Batchid = BatchID, 
		   @Shiftid = ShiftId, 
		   @Batchstartdatetime = StartDate, 
		   @Programnumber = ProgramNumber, 
		   @Programmasterid = ProgramMasterId
		FROM TCD.BatchData
		WHERE MachineInternalID = @Machinenumber
			  AND YEAR(StartDate) = YEAR(@Startdatetime)
			  AND MONTH(StartDate) = MONTH(@Startdatetime)
			  AND ABS(DAY(StartDate) - DAY(@Startdatetime)) < 2
			  AND ControllerBatchId = @Batchnumber
			  AND MachineID = @Washerid;
	IF @Batchid IS NULL
		BEGIN
			SELECT 
				   @Errormessage = 'Batch Missing for Step Save'+' Controller ID : '+CONVERT( NVARCHAR(10), @Controllerid)+' Washer Number	: '+
				   CONVERT(NVARCHAR(10), @Machinenumber)+' Batch Number : '+CONVERT(NVARCHAR(10), @Batchnumber);
			INSERT INTO TCD.Logs
			(
				   Date, 
				   Thread, 
				   Level, 
				   Logger, 
				   Message
			)
			VALUES
			(
				   GETUTCDATE(), 
				   '1', 
				   '1', 
				   'ReadStepSave', 
				   @Errormessage
			);
			RETURN;
		END;
	IF @Washerid IS NOT NULL
		BEGIN
			SELECT 
				   @Ecolabwasherid = EcolabWasherId, 
				   @Plantwashernumber = PlantWasherNumber
				FROM TCD.Washer AS Ws
					 INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = Ws.WasherId
					 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
					 INNER JOIN TCD.WasherProgramSetup AS Wps ON Wps.WasherGroupId = Wg.WasherGroupId
				WHERE Ws.WasherId = @Washerid
					  AND Wps.ProgramNumber = @Programnumber
					  AND Wps.Is_Deleted = 0
					  AND mst.IsDeleted = 0
					  AND Mst.ControllerId = @Controllerid;
		END;
	DECLARE @Shiftmapping TABLE
	(
		 ShiftId		INT, 
		 ShiftName		NVARCHAR(50), 
		 ShiftStartdate DATETIME
	);
	INSERT INTO @Shiftmapping
	(
		   ShiftId, 
		   ShiftName, 
		   ShiftStartdate
	)
	EXEC TCD.GetShiftStartDate 
		 @Batchstartdatetime;
	SELECT 
		   @Shiftid = ShiftID, 
		   @Shiftstartdate = ShiftStartdate FROM @Shiftmapping;
	CREATE TABLE #Dosing
	(
		 equipmentNo INT, 
		 StepNo		 INT, 
		 Qty		 DECIMAL(18, 4)
	);
	INSERT INTO #Dosing
		   SELECT 
				  T.c.value('@Equipment', 'INT'), 
				  T.c.value('@stepNo', 'INT'), 
				  T.c.value('@Qty', 'decimal(18,4)')
			   FROM @Vxml.nodes('ConventionalWasherData/DosingData/Dosing') AS T(C);
	SELECT 
		   @Maxwashertgroupcapacity = MAX(ws.MaxLoad)
		FROM TCD.Washer AS WS
			 INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = ws.WasherId
			 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
		WHERE Mst.GroupId = @Washergroupid;
	INSERT INTO TCD.BatchProductData
	(
		   BatchId, 
		   StepCompartment, 
		   ActualQuantity, 
		   StandardQuantity, 
		   Price, 
		   TimeStamp, 
		   PartitionOn, 
		   EcolabWasherId, 
		   ProductId, 
		   InjectionNumber
	)
		   SELECT 
				  Bd.BatchId, 
				  Wds.StepNumber, 
				  dosing.Qty, 
				  ((Wps.NominalLoad / CONVERT( DECIMAL(10, 2), 100)) * Wdpm.Quantity * Ws.MaxLoad) / CONVERT(DECIMAL(10, 2), 100) AS
				  StandardQuantity, 
				  ((Wps.NominalLoad / CONVERT( DECIMAL(10, 2), 100)) * Wdpm.Quantity * @Maxwashertgroupcapacity) / CONVERT(DECIMAL(10, 2), 100) *
				  tcd.FnChemicalCostInOunce(Pdm.ProductID) AS Price, 
				  @Batchstartdatetime, 
				  @Shiftstartdate, 
				  @Ecolabwasherid, 
				  Pdm.ProductID, 
				  dosing.StepNo
			   FROM TCD.Washer AS WS
					INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = ws.WasherId
					INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
					INNER JOIN TCD.WasherGroupType AS WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
					INNER JOIN TCD.WasherProgramSetup AS Wps ON Wps.WasherGroupId = Wg.WasherGroupId
					INNER JOIN TCD.WasherDosingSetup AS Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
					INNER JOIN TCD.WasherDosingProductMapping AS Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
					INNER JOIN TCD.ProductdataMapping AS Pdm ON Pdm.ProductId = Wdpm.ProductId
					INNER JOIN TCD.BatchData AS Bd ON Bd.MachineId = Ws.WasherId
					INNER JOIN TCD.ControllerEquipmentSetup AS CES ON CES.ProductId = Pdm.ProductId
																	  AND CES.ControllerID = @Controllerid
					INNER JOIN #Dosing AS dosing ON CES.ControllerEquipmentId = dosing.equipmentNo
			   --  AND Wdpm.InjectionNumber = dosing.StepNo
			   WHERE Ws.WasherId = @Washerid
					 AND Wps.ProgramNumber = @Programnumber
					 AND Bd.BatchId = @Batchid
					 AND WS.Is_Deleted = 0
					 AND Mst.IsDeleted = 0
					 AND dosing.equipmentNo > 0
					 AND dosing.Qty > 0
					 AND dosing.Qty != ISNULL(
											  (SELECT TOP 1 
													  bpd.ActualQuantity
												   FROM tcd.BatchProductData AS bpd
												   WHERE bpd.StepCompartment = dosing.StepNo
														 AND bpd.BatchId = @Batchid
														 AND bpd.ProductId = Pdm.ProductId
											  ), 0);
	IF NOT EXISTS
				 (SELECT 
						 * FROM TCD.BatchParameters WHERE ParameterId = 41
														  AND batchid = @Batchid
				 )
		BEGIN
			INSERT INTO Tcd.BatchParameters
			(
				   BatchId, 
				   EcolabWasherId, 
				   ParameterId, 
				   ParameterValue, 
				   PartitionOn
			)
				   SELECT 
						  @Batchid, 
						  @Ecolabwasherid, 
						  41,
						  CASE
							  WHEN SUM(bpd.ActualQuantity) = SUM(bpd.StandardQuantity)
							  THEN 1		--'Approved'
							  WHEN SUM(bpd.ActualQuantity) <> SUM(bpd.StandardQuantity)
							  THEN 2		--'Rejected'
							  ELSE 1		--'Approved'
						  END, 
						  @Shiftstartdate
					   FROM TCD.BatchProductData AS bpd
					   WHERE bpd.BatchId = @Batchid;
		END;

		--BatchStatus parametr insertion start
					SELECT DISTINCT 
						@TotalInjectsCountFromUI = COUNT(1)
					FROM TCD.Washer AS WS
						 INNER JOIN TCD.MachineSetup AS Ms ON ms.WasherId = ws.WasherId
						 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = ms.GroupId
						 INNER JOIN TCD.WasherGroupType AS WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
						 INNER JOIN TCD.WasherProgramSetup AS Wps ON Wps.ControllerID = Wg.ControllerId
						 INNER JOIN TCD.WasherDosingSetup AS Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
						 INNER JOIN TCD.WasherDosingProductMapping AS Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
					WHERE Wds.Is_Deleted = 0
							AND Wdpm.IsDeleted = 0
							AND ms.IsTunnel = 0
							AND ms.GroupId = @Washergroupid
							AND ms.WasherId = @Washerid
							AND ms.ControllerId = @Controllerid
							And ms.IsDeleted = 0

						SELECT @TotalInjectsCountFromPLC=Count(*) FROM TCD.BatchProductData bpd WHERE bpd.BatchId=@Batchid

					IF NOT EXISTS
							 (SELECT 
									 * FROM TCD.BatchParameters WHERE BatchId = @Batchid
																	  AND ParameterID = 18
							 )
					BEGIN
							INSERT INTO TCD.BatchParameters
							(
								   BatchId, 
								   EcolabWasherId, 
								   ParameterId, 
								   ParameterValue, 
								   PartitionOn
							)
								   SELECT 
										  @Batchid, 
										  @Ecolabwasherid, 
										  18, 
										  CASE WHEN @TotalInjectsCountFromUI=@TotalInjectsCountFromPLC THEN 1
										  WHEN @TotalInjectsCountFromUI<>@TotalInjectsCountFromPLC THEN 3 END,
										  @Shiftstartdate;
					END;
					--BatchStatus parametr insertion end

	SELECT 
		   @Washstep = StepCompartment
		FROM TCD.BatchProductData
		WHERE BatchID = @Batchid
			  AND InjectionNumber = @Stepnumber;
	SELECT TOP 1 
		   @Stepstarttime = EndTime
		FROM TCD.BatchWashStepData
		WHERE BatchID = @Batchid
		ORDER BY 
				 StepCompartment DESC;
	IF @Stepstarttime IS NULL
		SELECT 
			   @Stepstarttime = @Batchstartdatetime;
	INSERT INTO TCD.BatchWashStepData
	(
		   BatchId, 
		   StepCompartment, 
		   StartTime, 
		   EndTime, 
		   PartitionOn, 
		   EcolabWasherId
	)
		   SELECT 
				  @Batchid, 
				  ISNULL(@Washstep, @Stepnumber), 
				  @Stepstarttime, 
				  DATEADD(ss, @Stepduration, @Stepstarttime) AS EndTime, 
				  @Shiftstartdate, 
				  @Ecolabwasherid;
	IF ISNULL(@Runtime, 0) = 0
		BEGIN
			RETURN;
		END;
	DELETE FROM @Shiftmapping;
	INSERT INTO @Shiftmapping
	(
		   ShiftId, 
		   ShiftName, 
		   ShiftStartdate
	)
	EXEC TCD.GetShiftStartDate 
		 @Enddatetime;
	SELECT 
		   @Shiftid = ShiftID, 
		   @Shiftstartdate = ShiftStartdate FROM @Shiftmapping;
	UPDATE TCD.BatchData
	  SET 
		  EndDate = @Enddatetime, 
		  TCD.BatchData.EndDateFormula = @Enddatetime, 
		  ShiftId = @Shiftid, 
		  SyncReady = 1
		WHERE 
			  BatchID = @Batchid;
	SELECT 
		   @Mintempparamid = Id FROM TCD.ConduitParameters WHERE Name = 'Mimum Temperature';
	SELECT 
		   @Maxtempparamid = Id
		FROM TCD.ConduitParameters
		WHERE Name = 'Maximum Temperature';
	SELECT 
		   @Mintempstatuparamid = Id
		FROM TCD.ConduitParameters
		WHERE Name = 'Temperature Status';
	SELECT 
		   @Phvalueparamid = ID FROM TCD.ConduitParameters WHERE Name = 'PH';
	SELECT 
		   @Phstatusparamid = ID FROM TCD.ConduitParameters WHERE Name = 'PH Status';
	IF NOT EXISTS
				 (SELECT 
						 *
					  FROM TCD.BatchParameters
					  WHERE BatchId = @Batchid
							AND ParameterID = @Mintempparamid
				 )
		BEGIN
			IF @Temperaturemin <> 0
			   OR @Temperaturemin <> NULL
				BEGIN
					INSERT INTO TCD.BatchParameters
					(
						   BatchId, 
						   EcolabWasherId, 
						   ParameterId, 
						   ParameterValue, 
						   PartitionOn
					)
					VALUES
					(
						   @Batchid, 
						   @Ecolabwasherid, 
						   @Mintempparamid, 
						   @Temperaturemin, 
						   @Shiftstartdate
					);
				END;
		END;
	IF NOT EXISTS
				 (SELECT 
						 *
					  FROM TCD.BatchParameters
					  WHERE BatchId = @Batchid
							AND ParameterID = @Maxtempparamid
				 )
		BEGIN
			IF ISNULL(@Maxtempparamid, 0) > 0
				BEGIN
					INSERT INTO TCD.BatchParameters
					(
						   BatchId, 
						   EcolabWasherId, 
						   ParameterId, 
						   ParameterValue, 
						   PartitionOn
					)
					VALUES
					(
						   @Batchid, 
						   @Ecolabwasherid, 
						   @Maxtempparamid, 
						   @Temperaturemax, 
						   @Shiftstartdate
					);
				END;
		END;
	IF NOT EXISTS
				 (SELECT 
						 *
					  FROM TCD.BatchParameters
					  WHERE BatchId = @Batchid
							AND ParameterID = @Mintempstatuparamid
				 )
		BEGIN
			IF ISNULL(@Tempstatus, 0) > 0
				BEGIN
					INSERT INTO TCD.BatchParameters
					(
						   BatchId, 
						   EcolabWasherId, 
						   ParameterId, 
						   ParameterValue, 
						   PartitionOn
					)
					VALUES
					(
						   @Batchid, 
						   @Ecolabwasherid, 
						   @Mintempstatuparamid, 
						   @Tempstatus, 
						   @Shiftstartdate
					);
				END;
		END;
	IF NOT EXISTS
				 (SELECT 
						 *
					  FROM TCD.BatchParameters
					  WHERE BatchId = @Batchid
							AND ParameterID = @Phstatusparamid
				 )
		BEGIN
			IF ISNULL(@Phstatus, 0) > 0
				BEGIN
					INSERT INTO TCD.BatchParameters
					(
						   BatchId, 
						   EcolabWasherId, 
						   ParameterId, 
						   ParameterValue, 
						   PartitionOn
					)
					VALUES
					(
						   @Batchid, 
						   @Ecolabwasherid, 
						   @Phstatusparamid, 
						   @Phstatus, 
						   @Shiftstartdate
					);
				END;
		END;
	IF NOT EXISTS
				 (SELECT 
						 *
					  FROM TCD.BatchParameters
					  WHERE BatchId = @Batchid
							AND ParameterID = @Phvalueparamid
				 )
		BEGIN
			IF ISNULL(@Phvalue, 0) > 0
				BEGIN
					INSERT INTO TCD.BatchParameters
					(
						   BatchId, 
						   EcolabWasherId, 
						   ParameterId, 
						   ParameterValue, 
						   PartitionOn
					)
					VALUES
					(
						   @Batchid, 
						   @Ecolabwasherid, 
						   @Phvalueparamid, 
						   @Phvalue, 
						   @Shiftstartdate
					);
				END;
		END;
	IF @Waterconsumption1 > 0
		BEGIN
			INSERT INTO TCD.BatchStepWaterUsageData
			(
				   BatchId, 
				   StepCompartment, 
				   ActualQuantity, 
				   PartitionOn, 
				   EcolabWasherId
			)
				   SELECT 
						  @Batchid, 
						  @Washstep, 
						  @Waterconsumption1, 
						  @Shiftstartdate, 
						  @Ecolabwasherid;
		END;
	--If the received formula is not configured in enVision then create an alarm 
	IF @Programmasterid IS NULL
		BEGIN
			SELECT 
				   @Ecolabaccountnumber = EcolabAccountNumber FROM TCD.Plant;
			SELECT 
				   @Alarmgroupmasterid = AGM.AlarmGroupMasterId
				FROM TCD.AlarmGroupMsterVsControllerModelType AS AGMVCMT
					 INNER JOIN TCD.AlarmGroupMaster AS AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
				WHERE AGMVCMT.AlarmCode = 9000;
			INSERT INTO TCD.AlarmData
			(
				   EcoalabAccountNumber, 
				   AlarmCode, 
				   BatchId, 
				   controllerID, 
				   StartDate, 
				   GroupId, 
				   MachineInternalId, 
				   ProgramId, 
				   IsActive, 
				   EndDate, 
				   MachineId, 
				   AlarmGroupMasterId,
				   PartitionOn
			)
				   SELECT 
						  @Ecolabaccountnumber, 
						  9000, 
						  @Batchid, 
						  @Controllerid, 
						  @Startdatetime, 
						  @Washergroupid, 
						  @Machinenumber, 
						  @Programnumber, 
						  0, 
						  @Startdatetime, 
						  @Washerid, 
						  @Alarmgroupmasterid,
						  @Startdatetime;

		END;
END;