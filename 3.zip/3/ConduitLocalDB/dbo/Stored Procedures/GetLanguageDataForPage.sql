 /*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_GetLanguageDataForPage]                                             

Purpose:				To get the language data for page

Parameters:             @PageName -	holds the page name. 
						@PlantId - holds the plant id.
												
###################################################################################################                                           
*/
 CREATE PROCEDURE [TCD].GetLanguageDataForPage (@PageName [NVARCHAR](1000),@PlantId [NVARCHAR](1000))
  AS
  BEGIN
  SET NOCOUNT ON
	SELECT 
		DISTINCT KeyMaster.[KeyName], 
		ValueMaster.value
	FROM [TCD].ResourceKeyMaster KeyMaster
		 INNER JOIN [TCD].ResourceKeyValue ValueMaster ON KeyMaster.[KeyName]=  ValueMaster.[KeyName]
		 INNER JOIN [TCD].Plant plant ON plant.LanguageId=ValueMaster.languageID
		 INNER JOIN TCD.ResourceKeyPageMapping rkpm ON ValueMaster.[KeyName] = rkpm.[KeyName]
		 INNER JOIN [TCD].[Page] PG ON PG.PageId=rkpm.PageId
	WHERE Plant.EcolabAccountNumber=@PlantId 
	      AND PG.PageName=@PageName 
	SET NOCOUNT OFF
  END