﻿CREATE PROCEDURE [TCD].[SaveDefaultControllerEquipment] (    
  @ControllerId INT    
    , @EcolabAccountNumber NVARCHAR(25)    
    , @UserId INT)    
AS    
BEGIN    
    DECLARE    
     @TempEquipments TABLE (EcolabAccountNumber NVARCHAR (25)    
      , ControllerId INT    
      , ControllerEquipmentId TINYINT    
      , ControllerEquipmentTypeId TINYINT    
      , IsActive BIT    
      , LastModifiedByUserId INT  
      , WasherGroupNumber INT
      , kfactor	INT
      , AcceptedDeviation INT);    
    DECLARE    
     @MeCount INT,    
     @PumpCount INT,    
     @InsertedEquipmentCount INT,    
     @ControllerModelId INT = (SELECT ControllerModelId    
         FROM TCD.ConduitController CC    
         WHERE CC.ControllerId = @ControllerId);    
    SELECT TOP 1 @PumpCount = CMCTM.PumpValveCount    
   , @MeCount = CMCTM.MECount    
  FROM TCD.ControllerModelControllerTypeMapping CMCTM    
  WHERE CMCTM.ControllerModelId = @ControllerModelId;    
    SET @InsertedEquipmentCount = 0;    
    
    DECLARE    
     @i INT = 1;    
    IF @ControllerModelId = 11    
    BEGIN    
    SET @PumpCount = @PumpCount * 2;    
    SET @MeCount = @MeCount * 2;    
    END;    
    WHILE @i <= @PumpCount    
    BEGIN    
    SET @InsertedEquipmentCount = @InsertedEquipmentCount    
          +    
          1;    
    INSERT INTO @TempEquipments ( EcolabAccountNumber    
        , ControllerId    
        , ControllerEquipmentId    
        , ControllerEquipmentTypeId    
        , IsActive    
        , LastModifiedByUserId   
        , WasherGroupNumber
        , kfactor 
        , AcceptedDeviation)    
    VALUES ( @EcolabAccountNumber,    
     @ControllerId,    
     @InsertedEquipmentCount,    
     1,    
     'FALSE',    
     @UserId ,  
     1 ,
     200 ,
     5 );    
    SET @i = @i + 1;    
    END;    
    IF @ControllerModelId = 8    

    BEGIN 
	SET @i = 1;    
    WHILE @i <= @MeCount    
    BEGIN  
	   
    INSERT INTO @TempEquipments ( EcolabAccountNumber    
        , ControllerId    
        , ControllerEquipmentId    
        , ControllerEquipmentTypeId    
        , IsActive    
        , LastModifiedByUserId   
        , WasherGroupNumber 
        , kfactor
        , AcceptedDeviation )    
    VALUES ( @EcolabAccountNumber,    
     @ControllerId,    
     @InsertedEquipmentCount    
     +    
     1,    
     2,    
     'FALSE',    
     @UserId ,  
     1 ,
     200 ,
     5 );    
    SET @InsertedEquipmentCount = @InsertedEquipmentCount    
          +    
          1;   
	 SET @i = @i + 1;  
    END; 
	END;   
    ELSE    
    BEGIN    
    SET @i = 1;    
    WHILE @i <= @MeCount    
    BEGIN    
    INSERT INTO @TempEquipments ( EcolabAccountNumber    
            , ControllerId    
            , ControllerEquipmentId    
            , ControllerEquipmentTypeId    
            , IsActive    
            , LastModifiedByUserId  
            , WasherGroupNumber
            , kfactor
            , AcceptedDeviation )    
    VALUES ( @EcolabAccountNumber,    
         @ControllerId,    
         @PumpCount + @i,    
         2,    
         'FALSE',    
         @UserId ,  
         1 ,
         200 ,
         5);    
    SET @InsertedEquipmentCount = @InsertedEquipmentCount    
          +    
          1;    
    SET @i = @i + 1;    
    END;    
    END;    
    -- start  
   
    --end  
    MERGE INTO TCD.ControllerEquipmentSetup    CES    
    USING @TempEquipments AS TE    
    ON TE.ControllerId = CES.ControllerId    
    WHEN MATCHED    
  THEN    
  UPDATE SET    
  CES.EcolabAccountNumber = TE.EcoLabAccountNumber    
    , CES.ControllerId = TE.ControllerId    
    , CES.ControllerEquipmentId = TE.ControllerEquipmentId    
    , CES.ControllerEquipmentTypeId = TE.ControllerEquipmentTypeId    
    , CES.IsActive = TE.IsActive    
    , CES.LastModifiedByUserId = TE.LastModifiedByUserId    
    , CES.WasherGroupNumber = TE.WasherGroupNumber  
    WHEN NOT MATCHED    
  THEN    
  INSERT (EcolabAccountNumber    
    , ControllerId    
    , ControllerEquipmentId    
    , ControllerEquipmentTypeId    
    , IsActive    
    , LastModifiedByUserId  
    , WasherGroupNumber  
    , kfactor
    , AcceptedDeviation
    )    
  VALUES (TE.EcoLabAccountNumber,    
      TE.ControllerId,    
      TE.ControllerEquipmentId,    
      TE.ControllerEquipmentTypeId,    
      TE.IsActive,    
      TE.LastModifiedByUserId,  
      TE.WasherGroupNumber,
      TE.kfactor,
      TE.AcceptedDeviation);   
      
           IF(@ControllerModelId = 11)            
   BEGIN  
   UPDATE CES     
   SET CES.WasherGroupNumber = 1 
    FROM TCD.ControllerEquipmentSetup CES      
  WHERE CES.EcoLabAccountNumber = @EcoLabAccountNumber          
   AND CES.ControllerId = @ControllerId    
   AND CES.ControllerEquipmentId IN (select top 14 CES.ControllerEquipmentId FROM  TCD.ControllerEquipmentSetup CES    
   where CES.ControllerId = @ControllerId   ) 
      
     UPDATE CES     
   SET CES.WasherGroupNumber = 2   
    FROM TCD.ControllerEquipmentSetup CES         
  WHERE CES.EcoLabAccountNumber = @EcoLabAccountNumber          
   AND CES.ControllerId = @ControllerId    
   AND CES.ControllerEquipmentId IN (select  CES.ControllerEquipmentId FROM TCD.ControllerEquipmentSetup CES    
    where CES.ControllerId = @ControllerId AND     
    CES.ControllerEquipmentId BETWEEN 15 AND 28  )   
   
         
   UPDATE CES     
  SET  CES.ControllerEquipmentTypeId = 1  
    FROM TCD.ControllerEquipmentSetup CES          
  WHERE CES.EcoLabAccountNumber = @EcoLabAccountNumber              
   AND CES.ControllerId = @ControllerId        
   AND CES.ControllerEquipmentId IN (select top 28 CES.ControllerEquipmentId FROM  TCD.ControllerEquipmentSetup CES        
   where CES.ControllerId = @ControllerId    )      
          
     UPDATE CES         
   SET  CES.ControllerEquipmentTypeId = 2   
    FROM TCD.ControllerEquipmentSetup CES             
  WHERE CES.EcoLabAccountNumber = @EcoLabAccountNumber              
   AND CES.ControllerId = @ControllerId        
   AND CES.ControllerEquipmentId IN (select  CES.ControllerEquipmentId FROM TCD.ControllerEquipmentSetup CES        
    where CES.ControllerId = @ControllerId AND         
    CES.ControllerEquipmentId IN (13,14,27,28) )    
   END     
END; 