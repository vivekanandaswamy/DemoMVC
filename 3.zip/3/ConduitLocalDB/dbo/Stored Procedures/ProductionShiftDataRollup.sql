CREATE PROCEDURE [TCD].[ProductionShiftDataRollup](@InputShiftId INT, @RedFlagShiftId INT OUTPUT)
AS
BEGIN
	SET NOCOUNT ON
    DECLARE @DayId INT = NULL,
	@ShiftId Int = NULL,
	@ShiftName Varchar(100) = NULL,
	@StartTime DateTime = NULL,
	@EndTime DateTime = NULL,
	@DateStartTime DATETIME= NULL,
	@DateEndTime DATETIME= NULL,
	@BatchUTCStart DATETIME= NULL,
	@BatchUTCEnd DATETIME= NULL,
	@ShiftTargetProd Decimal(18,2) = NULL,
	@ConStdTurnTime Int= NULL,
	@ActualRunandConTurnTime Int= NULL,
	@TargetRunandConTurnTime Int= NULL,
	@ActualRunandTunTurnTime Int= NULL,
	@TargetRunandTunTurnTime Int= NULL,
	@SummationProduction Int,
	@NoOfLoads INT,@prevDay INT,@Rollingcount int = 1        
	,@RowCount int = NULL,@RealDayId Int,@ShiftCount Int = 1,@LabourShift int
	,@EcolabAccountNumber NVARCHAR(25) = NULL
		
	--SELECT * FROM TCD.WeekDay  SELECT DATENAME(dw,GETDATE()) 

    SELECT @DayId = DayId FROM [TCD].WeekDay WITH (NOLOCK) WHERE DayName = DATENAME(dw,GETDATE()) 

    SELECT @prevDay = CASE WHEN @DayId = 1 THEN 7 ELSE @DayId - 1 END
    SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant 

    DECLARE @BatchShiftTable TABLE
						(
						  RowNumber int IDENTITY(1,1),
						  BatchUTCStartDate datetime,
						  BatchUTCEndDate datetime,
						  ShiftId int
						)



   
	IF(@InputShiftId > 0)
	BEGIN
	 INSERT INTO @BatchShiftTable
	 (
	    
	    BatchUTCStartDate,
	    BatchUTCEndDate,
	    ShiftId
	 )
		 SELECT StartDateTime,
			EndDateTime,
			ShiftId	 
			FROM [TCD].ProductionShiftData SD WITH (NOLOCK)  WHERE ShiftId=@InputShiftId
	END
	
	ELSE
	BEGIN		
		 INSERT INTO @BatchShiftTable
		 (
	    
			BatchUTCStartDate,
			BatchUTCEndDate,
			ShiftId
		 )
	 SELECT TOP 2 
		StartDateTime,
		EndDateTime,
		ShiftId	 
			FROM [TCD].ProductionShiftData SD WITH (NOLOCK)  ORDER BY SD.StartDateTime DESC 
    END
	   ------------------******// Inserting the Data into Batch Summary Temp table based on UTC shift timings //******-----------------------
    WHILE (@ShiftCount <= (SELECT COUNT(1) FROM @BatchShiftTable bst))
    BEGIN

     /* Picking up the first record from the top 2 records of production shift data */

	SELECT  @BatchUTCStart = bst.BatchUTCStartDate,
	@BatchUTCEnd =bst.BatchUTCEndDate,  @ShiftId = bst.ShiftId
	FROM @BatchShiftTable bst WHERE bst.RowNumber = @ShiftCount
					  
	DECLARE @BatchSummary TABLE
				(
				   RowNumber Int,
				   BatchId Int,
				   ActualWeight float,
				   StandardWeight float,
				   MachineId Int,
				   EcolabWasherId Int,
				   StartDate datetime2,
				   EndDate datetime2,
				   ProgramNumber Int,
				   ProgramMasterId Int,
				   CustomerId Int,
				   PiecesCount int,
				   ManualInputWeight float,
				   TargetTurnTime INT,
				   EcolabTextileId INT,
				   ChainTextileId  INT ,
				   PlantProgaramId INT
				)

    INSERT INTO @BatchSummary
		(
		RowNumber ,
		BatchId ,
		ActualWeight ,
		StandardWeight ,
		MachineId ,
		EcolabWasherId ,
		StartDate ,
		EndDate ,
		ProgramNumber,
		ProgramMasterId ,
		CustomerId ,
		PiecesCount ,
		ManualInputWeight ,
		TargetTurnTime ,
		EcolabTextileId ,
		ChainTextileId  ,
		PlantProgaramId 		
		)
	   SELECT 
				  ROW_NUMBER() OVER(PARTITION BY BD.MachineId ORDER BY BD.StartDate) RowNumber,
				   BD.BatchId,
				   ActualWeight,
				   StandardWeight,
				   MachineId,
				   BD.EcolabWasherId,
				   StartDate,
				   EndDate,
				   ProgramNumber,
				   ProgramMasterId,
				   BCD.CustomerId,
				   BCD.PiecesCount,
				   BD.ManualInputWeight,
				   BD.TargetTurnTime,
				   BD.EcolabTextileCategoryId,
				   BD.ChainTextileCategoryId,
				   BD.PlantProgramId
			 FROM TCD.BatchData BD WITH (NOLOCK)
					   INNER JOIN TCD.MachineSetup MS WITH (NOLOCK) ON MS.WasherId = BD.MachineId 
				    LEFT OUTER JOIN 
				 TCD.BatchCustomerData BCD WITH (NOLOCK) ON BD.BatchId = BCD.BatchId
			  WHERE Bd.ShiftId =@ShiftId and BD.EndDate IS NOT NULL

	   
	------------------******// Inserting the Data into Chemical temp table  //******-----------------------

	DECLARE @BatchChemicalSummary TABLE
				(
				   BatchId Int,
				   EcolabWasherId Int,
				   StartDate datetime2,
				   EndDate datetime2,
				   MachineId Int,
				   ProgramMasterId Int,
				   ProductId Int,
				   ActualQuantity float,
				   StandardQuantity float,
				   Price Decimal(18,2),
				   CustomerId Int,
				   EcolabTextileId INT,
				   ChainTextileId  INT ,
				   PlantProgaramId INT
				  			   
				)

    INSERT INTO @BatchChemicalSummary
		(
			BatchId,
			EcolabWasherId ,
			StartDate ,
			EndDate ,
			MachineId ,
			ProgramMasterId ,
			ProductId ,
			ActualQuantity ,
			StandardQuantity ,
			Price ,
			CustomerId ,
			EcolabTextileId ,
			ChainTextileId   ,
			PlantProgaramId 
		
		)
	   SELECT 
				   BD.BatchId,
				   BD.EcolabWasherId,
				   StartDate,
				   EndDate,
				   MachineId,
				   ProgramMasterId,
				   BPD.ProductId,
				   BPD.ActualQuantity,
				   BPD.StandardQuantity,
				   BPD.Price,
				   BCD.CustomerId,
				   BD.EcolabTextileCategoryId,
				   BD.ChainTextileCategoryId,
				   BD.PlantProgramId
			 FROM  TCD.BatchProductData BPD	WITH (NOLOCK)				   
					   INNER JOIN TCD.BatchData BD WITH (NOLOCK) ON BD.BatchId = BPD.BatchId
					   INNER JOIN TCD.MachineSetup MS WITH (NOLOCK) ON MS.WasherId = BD.MachineId 
					   LEFT OUTER JOIN TCD.ProductMaster PD WITH (NOLOCK) ON PD.ProductId = BPD.ProductId
					   LEFT OUTER JOIN  TCD.BatchCustomerData BCD WITH (NOLOCK) ON BD.BatchId = BCD.BatchId
					   WHERE  Bd.ShiftId =@ShiftId and BD.EndDate IS NOT NULL

	SELECT @NoOfLoads = COUNT(DISTINCT BatchId) FROM @BatchSummary
  
	------------------******// Inserting the Data into Machine Efficiency Temp table for runtimes based on machines //******-----------------------

	

	DECLARE @MachineEfficency TABLE
					   ( 
						  MachineId INT,
						  ProgramMasterId INT,
						  ActualRunTime INT, 
						  StandardRunTime BIGINT,
						  ActualTurnTime BIGINT,
						  StandardTurnTIme INT
					   )

    INSERT INTO @MachineEfficency
					   ( 
						  MachineId,
						  ProgramMasterId,
						  ActualRunTime , 
						  StandardRunTime,
						  ActualTurnTime,
						  StandardTurnTIme
					   )
	   SELECT 
			  CUR.MachineId,
			  CUR.ProgramMasterId,	   
			  --0 ActualRunTime,
			  SUM( DATEDIFF(SECOND,CUR.StartDate,CUR.EndDate)) AS ActualRunTime,
			  ISNULL(SUM(WPS.TotalRunTime),1) AS StandardRunTime,
			  --0 AS ActualTurnTime,
			  ISNULL( SUM(t.ActualTurnTime),0) ActualTurnTime,
			  ISNULL(SUM(CUR.TargetTurnTime),1) AS StandardTurnTIme
	    FROM @BatchSummary CUR 
	    INNER JOIN [TCD].[Turntime] t ON CUR.BATCHID=t.BATCHID 
	    --LEFT OUTER JOIN #BatchSummary nexting ON cur.RowNumber = nexting.RowNumber - 1 AND CUR.MachineId = nexting.MachineId
	    INNER JOIN TCD.MachineSetup MS WITH (NOLOCK) ON MS.WasherId = CUR.MachineId AND MS.IsTunnel = 0 AND MS.IsDeleted = 0
	    LEFT JOIN TCD.WasherProgramSetup WPS WITH (NOLOCK) ON WPS.ProgramId = CUR.ProgramMasterId 
								AND WPS.ProgramNumber=cur.ProgramNumber	
								AND MS.GroupId = WPS.WasherGroupId 
								AND WPS.Is_Deleted = 0
	    GROUP BY CUR.MachineId,CUR.ProgramMasterId
	   UNION ALL

	   SELECT 
			CUR.MachineId,
			CUR.ProgramMasterId,
			--0 ActualRunTime,			
			SUM( DATEDIFF(SECOND,CUR.StartDate,CUR.EndDate)) AS ActualRunTime,
			ISNULL(SUM(TPS.TotalRunTime),1) AS StandardRunTime,
			NULL AS ActualTurnTime,
			NULL AS StandardTurnTIme
	   FROM @BatchSummary CUR
	    INNER JOIN TCD.MachineSetup MS WITH (NOLOCK) ON MS.WasherId = CUR.MachineId AND MS.IsTunnel = 1 AND MS.IsDeleted = 0
	    LEFT JOIN TCD.TunnelProgramSetup TPS WITH (NOLOCK) ON TPS.ProgramId = CUR.ProgramMasterId AND TPS.ProgramNumber=CUR.ProgramNumber
			    AND MS.GroupId = TPS.WasherGroupId AND TPS.Is_Deleted = 0
	    GROUP BY CUR.MachineId,CUR.ProgramMasterId

/*
	 ;WITH cte AS (SELECT  MachineId,ProgramMasterId, SUM( DATEDIFF(SECOND,B.StartDate,B.EndDate)) ActualRunTime
				    from @BatchSummary B GROUP BY MachineId,ProgramMasterId)
		  UPDATE M  SET ActualRunTime=CTE.ActualRunTime
		  from @MachineEfficency m 
		  INNER JOIN cte ON M.MachineId=cte.MachineId AND M.ProgramMasterId=CTE.ProgramMasterId

		
		  ;WITH cte AS (SELECT B.MachineId,B.ProgramMasterId,isnull( sum( t.ActualTurnTime),0) ActualTurnTime
		  FROM @BatchSummary B 
		  INNER JOIN  [TCD].[Turntime] t ON B.BATCHID=t.BATCHID AND B.MachineId=t.MachineId AND B.ProgramMasterId=t.ProgramMasterId 
		  GROUP BY B.MachineId,B.ProgramMasterId
		  )
		  UPDATE m SET ActualTurnTime= c.ActualTurnTime
		  from @MachineEfficency m 
		  INNER join cte c ON c.MachineId=m.MachineId AND c.ProgramMasterId=m.ProgramMasterId 
*/

	--------------------------******// Inserting the Data into production Shift Rollup Data Table //******-------------------
	      		  
		 
	DELETE FROM [TCD].ShiftProductionDataRollup WHERE ShiftId = @ShiftId 

	IF EXISTS(SELECT COUNT(1) FROM TCD.ProductionShiftData psd WHERE ShiftId = @ShiftId )
	BEGIN
		SELECT @ShiftTargetProd= isnull( TargetProduction,0) FROM TCD.ProductionShiftData psd WHERE ShiftId = @ShiftId 
	END

	DECLARE @RegionId int  
	SELECT @RegionId= p.PlantId FROM TCD.Plant p 

	select @RedFlagShiftId=@ShiftId

	INSERT INTO [TCD].ShiftProductionDataRollup
							 (
								ShiftId,
								MachineId,
								ProgramMasterId,
								EcolabWasherId,
								NoOfLoads,
								ActualProduction ,
								StandardProduction,
								LoadEfficiency,
								TimeEfficiency,
								PlantTargetProd ,
								ActualRunTime,
								TargetRunTime,
								EcolabTextileId,
								ChainTextileId,
								ChainProgaramId,
								CustomerId,
								NoOfPieces,
								ActualTurnTime,
								TargetTurnTime
							 )	


		  SELECT 
				--DISTINCT
					 @ShiftId,
				      CUR.MachineId,
					 CUR.ProgramMasterId,
					 CUR.EcolabWasherId,
					 COUNT(1),
					 SUM(CUR.ActualWeight) + ISNULL(SUM(CUR.ManualInputWeight),0),
					 SUM(CUR.StandardWeight),

					 CAST(COALESCE(((SUM(CUR.[ActualWeight]))/ NULLIF(ISNULL(SUM(CUR.[StandardWeight]),SUM(CUR.[ActualWeight])),0)), 0) AS decimal(18,2)),

					 --CAST(((SUM(CUR.[ActualWeight]))/ISNULL(SUM(CUR.[StandardWeight]),SUM(CUR.[ActualWeight]))) AS decimal(18,2)),

					 CAST(COALESCE(CAST(SUM(ME.StandardRunTime) AS Decimal(18,2))/ NULLIF(ISNULL(CAST(SUM(ME.ActualRunTime) AS decimal(18,2)),CAST(SUM(ME.ActualRunTime) AS Decimal(18,2))),0), 0) AS decimal(18,2)) ,

					 --CAST(CAST(SUM(ME.ActualRunTime) AS Decimal(18,2))/ISNULL(CAST(SUM(ME.StandardRunTime) AS decimal(18,2)),CAST(SUM(ME.ActualRunTime) AS Decimal(18,2))) AS decimal(18,2)) ,
			 		 @ShiftTargetProd * (case when @RegionId=1 then 1000 else 1 end),					 
					 COALESCE(SUM(ME.ActualRunTime) / NULLIF(COUNT(1),0), 0), 
					 COALESCE(ISNULL(SUM(ME.StandardRunTime),SUM(ME.ActualRunTime))/ NULLIF(COUNT(1),0), 0), 

					 CUR.EcolabTextileId,CUR.ChainTextileId,CUR.PlantProgaramId,
					 --ETC.TextileId,CTC.TextileId,PCP.PlantProgramId,
					 CUR.CustomerId,
				      SUM(CUR.PiecesCount),
					 COALESCE(SUM(ME.ActualTurnTime) / NULLIF(COUNT(1),0), 0),
					 COALESCE(ISNULL(SUM(ME.StandardTurnTIme),SUM(ME.ActualTurnTime))/ NULLIF(COUNT(1),0), 0)
							 FROM 
					   @BatchSummary CUR 
						  LEFT JOIN 
								@MachineEfficency ME ON CUR.MachineId = ME.MachineId AND CUR.ProgramMasterId = ME.ProgramMasterId
						  LEFT JOIN 
								 TCD.ProgramMaster PM WITH (NOLOCK) ON PM.ProgramId = CUR.ProgramMasterId
						/*
						  LEFT JOIN
								TCD.EcolabTextileCategory ETC WITH (NOLOCK) ON ETC.TextileId = PM.EcolabTextileCategoryId
						  LEFT JOIN
								TCD.ChainTextileCategory CTC WITH (NOLOCK) ON  CTC.TextileId = PM.ChainTextileId
						  LEFT JOIN
								TCD.PlantChainProgram PCP ON PCP.PlantProgramId = PM.PlantProgramId
						*/
						  GROUP BY CUR.MachineId,CUR.EcolabWasherId,CUR.ProgramMasterId,--ETC.TextileId,CTC.TextileId,PCP.PlantProgramId,
						  CUR.EcolabTextileId,CUR.ChainTextileId,CUR.PlantProgaramId,
						  CUR.CustomerId


	--------------------------******// Inserting the Data into Chemical Shift Rollup Data Table //******-------------------
	  	  
		 
	DELETE FROM [TCD].[ShiftChemicalDataRollup] WHERE ShiftId = @ShiftId 

	INSERT INTO [TCD].[ShiftChemicalDataRollup]
							 (
								 [ShiftId] ,
								 [MachineId],
								 [ProgramMasterId],
								 [EcolabWasherId],
								 [ProductId],
								 [ActualConsumption],
								 [TargetConsumption],
								 [ActualCost],
								 [EcolabTextileId],
								 [ChainTextileId],
								 [ChainProgaramId],
								 [CustomerId],
								 NoOfLoads
							 )
				SELECT
				    --DISTINCT 
						  @ShiftId,
						  CUR.MachineId,
						  CUR.ProgramMasterId,
						  CUR.EcolabWasherId,
						  CUR.ProductId,
						  SUM(CUR.ActualQuantity),
						  SUM(CUR.StandardQuantity),
						  SUM(CUR.Price),
						  CUR.EcolabTextileId,
						  CUR.ChainTextileId,
						  CUR.PlantProgaramId,
						  CUR.CustomerId,
						  @NoOfLoads
						  FROM 
						  @BatchChemicalSummary CUR 
						   LEFT JOIN 
								 TCD.ProgramMaster PM WITH (NOLOCK) ON PM.ProgramId = CUR.ProgramMasterId
						  --LEFT JOIN
								--TCD.EcolabTextileCategory ETC WITH (NOLOCK) ON ETC.TextileId = PM.EcolabTextileCategoryId
						  --LEFT JOIN
								--TCD.ChainTextileCategory CTC WITH (NOLOCK) ON  CTC.TextileId = PM.ChainTextileId
						  --LEFT JOIN
								--TCD.PlantChainProgram PCP WITH (NOLOCK) ON PCP.PlantProgramId = PM.PlantProgramId
						  GROUP BY CUR.MachineId,CUR.EcolabWasherId,CUR.ProgramMasterId,CUR.ProductId,CUR.CustomerId,CUR.EcolabTextileId,CUR.ChainTextileId,CUR.PlantProgaramId

		IF NOT EXISTS (SELECT 1 FROM [TCD].[ProductionShiftLaborData] WHERE ShiftId = @ShiftId)
			BEGIN
				INSERT INTO [TCD].[ProductionShiftLaborData]
				SELECT  @ShiftId,
				SLD.LaborTypeId,
				SLD.LaborHours,
				SLD.LaborHours * SLD.PricePerHr
					FROM [TCD].[ShiftLaborData] SLD WITH (NOLOCK) WHERE ShiftId = @LabourShift AND DayId = @DayId
			END
		  
		  DELETE FROM @BatchSummary
		  DELETE FROM @BatchChemicalSummary
		  DELETE FROM @MachineEfficency
		  
	    SET @ShiftCount = @ShiftCount + 1
	END
	EXEC [TCD].[ReportBatchStepWaterAndEnergyRollup];
SET NOCOUNT OFF
END

