CREATE PROCEDURE [TCD].[DeleteMonitorSetupMapping]    
(   
			@DashboardId INT = NULL,  
			@DashBoardName Varchar(100),
			@TypeId INT = NULL,
			@EnableParameter BIT = NULL,		
			@EcolabAccountNumber NVarchar(25),
			@UserID INT ,
			@Customer BIT,
			@Formula BIT,
			@Load BIT,
			@DisplayOnLogin BIT,
			@TimelineHours INT,
			@FormulaDisplayType INT,
			@EfficiencyCalcType INT
)   
AS 
SET NOCOUNT ON  
BEGIN  
  DECLARE @OutPut INT  
BEGIN       
				UPDATE [TCD].[Dashboard] 
					SET DashBoardName = @DashBoardName,							
					TypeId=@TypeId,
					IsEnableParameters=@EnableParameter,		
					LastModifiedByUser=@UserID,
					Customer=@Customer,
					Formula=@Formula ,
					TimelineHours = @TimelineHours,
					DisplayFormulaType = @FormulaDisplayType,
					[Load]=@Load ,
					DisplayOnLogin=@DisplayOnLogin,
					EfficiencyCalcType=@EfficiencyCalcType
				WHERE DashboardId = @DashboardId AND EcolabAccountNumber=@EcolabAccountNumber
				DELETE FROM [TCD].MonitorSetUpMapping WHERE DashboardId=@DashboardId AND EcolabAccountNumber=@EcolabAccountNumber
END  
END