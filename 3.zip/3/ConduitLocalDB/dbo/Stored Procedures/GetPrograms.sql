﻿/*  
 ==========================================================================================  
 Purpose:  Fetching list of programs for the plant.  

 Author:  Prashant  

 --------------------------------------------------------------  
 August-18-2014 ENT: Initial version.  
 ==========================================================================================  
*/ 

CREATE  PROCEDURE [TCD].[GetPrograms]
@EcolabAccountNumber                    NVARCHAR(25)    ,
@IsResync Bit = 'False',
@ProgramId INT
AS 
  BEGIN 
    SET NOCOUNT ON; 

    SET            @EcolabAccountNumber            =            ISNULL(@EcolabAccountNumber, NULL)            --SQLEnlight SA0029
    IF @ProgramId = 0 
       BEGIN 
          SET @ProgramId = NULL
       END


    SELECT	     pm.ProgramId
            ,pm.Name
            ,pm.Pieces
            ,(CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN etc.TextileId 
        ELSE cp.EcolabTextileCategoryId END) AS TextileId
            ,(CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN etc.CategoryName 
        ELSE cp.EcolabTextileCategoryName END) AS CategoryName
            ,(CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN es.EcolabSaturationId 
        ELSE cp.EcolabSaturationId END) AS EcolabSaturationId
            ,(CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN es.EcolabSaturationName 
        ELSE cp.EcolabSaturationName END) AS EcolabSaturationName    
            ,cp.PlantProgramId
            ,cp.PlantProgramName
            ,cp.ChainTextileId
            ,cp.ChainTextileName
            ,(CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN fs.FormulaSegmentId
        ELSE cp.FormulaSegmentId END) AS FormulaSegmentId
            ,(CASE WHEN pm.PlantProgramId IS NULL OR pm.PlantProgramId = 0 THEN fs.SegmentName
        ELSE cp.SegmentName END) AS FormulaSegmentName
            ,pm.Rewash
            ,pm.[Weight]
            ,COUNT(*) OVER() as TotalCount            
            ,pm.CustomerId
			,pc.CustomerName
            ,pm.LastModifiedTime 
            ,pm.EcolabAccountNumber
            ,pm.Is_Deleted
            ,pm.Weight_Display
        FROM TCD.ProgramMaster pm
	LEFT JOIN TCD.ChainPrograms cp
	ON cp.PlantProgramId = pm.PlantProgramId AND pm.EcolabAccountNumber = cp.EcolabAccountNumber
        LEFT JOIN TCD.EcolabTextileCategory etc
        ON pm.EcolabTextileCategoryId = etc.TextileId
        LEFT JOIN TCD.EcolabSaturation es
        ON pm.EcolabSaturationId = es.EcolabSaturationId
        LEFT JOIN TCD.FormulaSegments fs
        ON pm.FormulaSegmentId = fs.FormulaSegmentID
		LEFT JOIN TCD.PlantCustomer pc
		ON pc.CustomerId = pm.CustomerId AND pc.EcolabAccountNumber = pm.EcolabAccountNumber
        WHERE pm.ProgramId = ISNULL(@ProgramId, pm.ProgramId)
        AND (pm.Is_Deleted = 0 OR pm.Is_Deleted = @IsResync)
        AND pm.EcolabAccountNumber = @EcolabAccountNumber
        ORDER BY pm.Name
    
         
SET NOCOUNT OFF;
 END
