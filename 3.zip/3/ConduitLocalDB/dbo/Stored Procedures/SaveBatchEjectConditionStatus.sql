﻿/*	
Purpose					:	To save batch eject condition

*/
CREATE	PROCEDURE	[TCD].[SaveBatchEjectConditionStatus]	(
					@AlarmMachineMappingId					INT
				,	@ControllerModelId						INT				
				,	@MachineId						INT					
				,	@DeleteFlag								BIT			=			'FALSE'	--DO NOT SET THIS (to TRUE) UNLESS DELETE IS INTENDED
				,	@UserId									INT			=			NULL
				,	@EcolabAccountNumber					NVARCHAR(25)
				,	@LastModifiedTime						DATETIME
				)
AS 
BEGIN 


SET	NOCOUNT	ON

DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	,	@PlantId						INT							

	SET @PlantId =	(SELECT PlantId 
					FROM TCD.Plant 
					WHERE EcolabAccountNumber = @EcolabAccountNumber);
IF	(	@DeleteFlag	=	'TRUE'	)
	BEGIN
			DELETE BECS
			FROM [TCD].BatchEjectConditionStatus BECS
			INNER JOIN [TCD].BatchEjectCondition BEC ON BEC.BatchEjectConditionId = BECS.BatchEjectConditionId		
			WHERE
			BEC.ControllerModelId		= @ControllerModelId
			AND
			BECS.LastModifiedUserId = @UserId		
			AND
			BECS.MachineId				= @MachineId
			AND
			BECS.PlantId		= @PlantId
			
			SET	@ErrorId	=	@@ERROR

			IF	(@ErrorId	<>	0)
			BEGIN
				SET		@ErrorMessage				=			N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred overwriting alarm data.'
				--GOTO	Errorhandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END

	END
ELSE
	BEGIN
		INSERT INTO	[TCD].BatchEjectConditionStatus (
					BatchEjectConditionId
				,	MachineId
				,	LastModifiedUserId
				,	PlantId				
				,	LastModifiedTime				
				)
			SELECT
					@AlarmMachineMappingId	AS			BatchEjectConditionId
				,	@MachineId				AS				MachineId				
				,	@UserId					AS			UserId
				,	@PlantId				AS			PlantId
				,	@LastModifiedTime
				
				
		--check for any error
		SET	@ErrorId	=	@@ERROR

		IF	(@ErrorId	<>	0)
		BEGIN
			SET		@ErrorMessage			=			N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred overswriting alarm data.'
			--GOTO	Errorhandler
			RAISERROR	(@ErrorMessage, 16, 1)
			SET	@ReturnValue	=	-1
			RETURN	(@ReturnValue)
		END
	END


IF	(	@ErrorId	=	0	)
	BEGIN
		--GOTO	ExitModule
		RETURN	(@ReturnValue)
	END

SET	NOCOUNT	OFF
RETURN	(@ReturnValue)

END
