--exec [TCD].[ChemecalConsumptionSwitchReport] @Corporate=N'',@Country=N'',@Region=N'',@EcolabAccountNumber=N'',@Machine=N'',@machineGroup=N'',@Formula=N'',@MachineType=N'',
--@Category=N'',@FromDate='2014-01-01 00:00:00',@ToDate='2014-09-30 00:00:00',@GroupId=N'',@MachineInternalId=N'',@Date = NULL,
--@DayWise=0,@WeekWise=0,@MonthWise=0,@QuarterWise=1,@YearWise=0,@SortColumnID = 0,@SortDirection = 'ASC',@UserId = 0,@ReportID = 5


CREATE PROCEDURE [TCD].[ChemecalConsumptionSwitchReport] (
											 @Corporate VARCHAR(MAX) = '',
											 @Country VARCHAR(MAX) = '',
											 @Region VARCHAR(MAX) = '',
											 @EcolabAccountNumber NVARCHAR(25) = '',
											 @Machine VARCHAR(MAX) = '', 
											 @MachineGroup VARCHAR(MAX) = '',
											 @Formula VARCHAR(MAX) = '',
											 @MachineType VARCHAR(20)= '',
											 @Category VARCHAR(MAX) = '',
											 @FromDate DATE = '',
											 @ToDate DATE = '',
											 @GroupId VARCHAR(MAX) = '',
											 @MachineInternalId VARCHAR(MAX) = '',
											 @Date DATE = NULL,
											 @DayWise BIT = NULL,
											 @WeekWise BIT = NULL,
											 @MonthWise BIT = NULL,
											 @QuarterWise BIT = NULL,
											 @yearwise BIT = NULL,
											 @SortColumnID INT = NULL,
											 @SortDirection Varchar(100) = '',
											 @UserId Int = NULL,
											 @ReportID INT = NULL,
											 @IsDrillDown BIT		

										   )

AS   

BEGIN   
SET NOCOUNT ON; 

DECLARE @ReportGenerated INT = 6, @SortField Varchar(100) = '',@ProductId Varchar(100) = '',
@SQLStatement varchar(max)

SET		@Country						=			ISNULL(@Country, NULL)						--SQLEnlight SA0029
SET		@EcolabAccountNumber			=			ISNULL(@EcolabAccountNumber, NULL)			--SQLEnlight SA0029
SET		@Region							=			ISNULL(@Region, NULL)						--SQLEnlight SA0029
SET		@ReportID						=			ISNULL(@ReportID, NULL)						--SQLEnlight SA0029

--/* Inserting the record into Report History */

--INSERT INTO TCD.ReportHistory(EcolabAccountNumber,UserId,UserName,DateAndTime,ActionTypeId,ActionDescription)
--SELECT
--	  @EcolabAccountNumber,
--	  UM.UserId,
--	  UM.LoginName,
--	  GETUTCDATE(),
--	  @ReportGenerated,
--	  CASE WHEN @ReportGenerated = 6
--		THEN 'Generated Report : ChemicalComsumptionReport' END
--	  FROM TCD.UserMaster UM
--	    WHERE	UM.EcolabAccountNumber =	@EcolabAccountNumber AND UM.UserId = @UserId

--/* Completed the record insertion into Report History */



 SELECT @SortField =  CASE WHEN @SortColumnID = 16 THEN 'AverageConsumption'
						    WHEN @SortColumnID = 17 THEN 'AverageDailyConsumption'
						    WHEN @SortColumnID = 47 THEN 'Chemical'
						    WHEN @SortColumnID = 54 THEN 'ActualConsumptionPerLoad'
						    WHEN @SortColumnID = 56 THEN 'Cost'			

						    WHEN @SortColumnID = 57 THEN 'CostExcess'
						    WHEN @SortColumnID = 58 THEN 'CostPerLoad'
						    WHEN @SortColumnID = 176 THEN 'TargetConsumptionPerLoad'
						    WHEN @SortColumnID = 177 THEN 'TargetConsumption'
						    WHEN @SortColumnID = 198 THEN 'TotalConsumption'
						    WHEN @SortColumnID = 0 THEN 'TotalConsumption'
					 END



DECLARE @Month INT = MONTH(GETDATE())	   

DECLARE @CategoryTable TABLE(Category VARCHAR(100))
INSERT INTO @CategoryTable(Category) EXEC [TCD].[CharlistToTable] @Category,','


DECLARE @MachineTable TABLE(Machine VARCHAR(100))
INSERT INTO @MachineTable(Machine) EXEC [TCD].[CharlistToTable] @Machine,','


DECLARE @GroupMachineTable TABLE(GroupId INT,MachineInternalId INT)  
INSERT INTO @GroupMachineTable(GroupId,MachineInternalId)   
SELECT GroupId,MachineInternalId 
FROM 
TCD.MachineSetup MS 
INNER JOIN TCD.Washer WS ON MS.WasherId = WS.WasherId 
WHERE WS.PlantWasherNumber IN (SELECT Machine FROM @MachineTable);


DECLARE @GroupTable TABLE(GroupId VARCHAR(100))
INSERT INTO @GroupTable(GroupId) EXEC [TCD].[CharlistToTable] @GroupId,','


DECLARE @MachineInternalTable TABLE(MachineInternalId VARCHAR(100))
INSERT INTO @MachineInternalTable(MachineInternalId) EXEC [TCD].[CharlistToTable] @MachineInternalId,','

DECLARE @WasherGroupTable TABLE(MachineGroup VARCHAR(100))
INSERT INTO @WasherGroupTable(MachineGroup) EXEC [TCD].[CharlistToTable] @MachineGroup,','


DECLARE @FormulaTable TABLE(Formula VARCHAR(100))
INSERT INTO @FormulaTable(Formula) EXEC [TCD].[CharlistToTable] @Formula,','


--DECLARE @CustomerTable TABLE(Customer VARCHAR(100))
--INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','


DECLARE @MachineTypeTable TABLE(MachineType VARCHAR(100))
INSERT INTO @MachineTypeTable(MachineType) EXEC [TCD].[CharlistToTable] @MachineType,','

				    /* Including the Latest Batch Data */

	   					   IF((CAST(@ToDate AS DATE) = CAST(GETUTCDATE() AS date)) AND @DayWise <> 1)
								BEGIN				     

								 EXEC [TCD].[ChemicalConsumptionDataRollUp] @ToDate

								 END

				    /* Ending the Latest Batch Data Logic */



DECLARE @ChemicalConsumptionTable TABLE(
								 [RecordDate] [date] NULL,
								 [BatchId] [int] NULL,
								 [ActualWeight] [decimal](18, 2) NULL,
								 [StandardWeight] [decimal](18, 2) NULL,
								 [MachineId] INT NULL,
								 [GroupId] [int] NULL,
								 [MachineInternalId] [int] NULL,
								 [ProgramNumber] [int] NULL,
								 [ProductId] [int] NULL,
								 [TotalConsumption] [decimal](18, 2) NULL,
								 [TargetConsumption] [decimal](18, 2) NULL,
								 [Cost] [decimal](18, 2) NULL,
								 [CostPerLoad] [decimal](18, 2) NULL,
								 [CostExcess] [decimal](18, 2) NULL,
								 [EcolabTextileCategoryName] [varchar](50) NULL,
								 [EcolabTextileId] [int] NULL,
								 [PlantTextileCategoryName] [varchar](50) NULL,
								 [PlantTextileId] [int] NULL

							    )



	INSERT INTO @ChemicalConsumptionTable(
								 [RecordDate],
								 [BatchId] ,
								 [ActualWeight] ,
								 [StandardWeight] ,
								 [MachineId]  ,
								 [GroupId]  ,
								 [MachineInternalId]  ,
								 [ProgramNumber]  ,
								 [ProductId]  ,
								 [TotalConsumption],
								 [TargetConsumption] ,
								 [Cost],
								 [CostPerLoad] ,
								 [CostExcess],
								 [EcolabTextileCategoryName],
								 [EcolabTextileId],
								 [PlantTextileCategoryName] ,
								 [PlantTextileId] 
							    )

	SELECT   [RecordDate]
		    ,[BatchId]
		    ,[ActualWeight]
		    ,[StandardWeight]
		    ,MachineId
		    ,[GroupId]
		    ,[MachineInternalId]
		    ,[ProgramNumber]
		    ,[ProductId]
		    ,[TotalConsumption]
		    ,[TargetConsumption]
		    ,[Cost]
		    ,[CostPerLoad]
		    ,[CostExcess]
		    ,[EcolabTextileCategoryName]
		    ,[EcolabTextileId]
		    ,[PlantTextileCategoryName]
		    ,[PlantTextileId]
	   FROM [TCD].[ChemicalConsumptionRollUp] CCR

	WHERE 
		--CASE @Customer
		-- WHEN '' THEN 'TRUE'
		-- ELSE
		--  CASE WHEN CCR.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                      
		--END='TRUE' 
		--AND
		CASE @Machine   
				 WHEN '' THEN 'TRUE'         
				 ELSE                                                      
				  CASE WHEN CCR.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
				END='TRUE' 

		AND    
		CASE @MachineGroup   
			WHEN '' THEN 'TRUE'   
			ELSE      
			CASE WHEN CCR.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable) THEN 'TRUE' END  
		END='TRUE' 
		AND    
		CASE @Formula   
			WHEN '' THEN 'TRUE'  
			ELSE           
			CASE WHEN CCR.ProgramNumber IN (SELECT Formula FROM @FormulaTable) THEN 'TRUE' END   
		END='TRUE' 

		AND       
		CASE @MachineType   
			WHEN '' THEN 'TRUE'   
			ELSE          
			CASE WHEN CCR.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable)) THEN 'TRUE' END                                                      
		END='TRUE' 
		AND       
		CASE @FromDate 
			WHEN '' THEN Case WHEN MONTH(CCR.RecordDate) = @Month Then  'TRUE' END  
			ELSE CASE WHEN CCR.RecordDate >= @FromDate and CCR.RecordDate<=@ToDate  THEN 'TRUE'END  
			END='TRUE'
			AND
		CASE @Category  
			WHEN '' THEN 'TRUE'  
			ELSE                
			CASE WHEN CCR.EcolabTextileId IN (SELECT Category FROM @CategoryTable) THEN 'TRUE' END  
		END='TRUE' 
		AND
			CASE @GroupId 
			WHEN '' THEN 'TRUE' 
			ELSE        
		CASE WHEN (CCR.GroupId IN (@GroupId) AND 
			CCR.MachineInternalId IN (@MachineInternalId)) THEN 'TRUE' END  
		END='TRUE' 
		AND
		CASE @MachineInternalId  
			WHEN '' THEN 'TRUE' 
			ELSE        
		CASE WHEN (CCR.GroupId IN (@GroupId) AND 
			CCR.MachineInternalId IN (@MachineInternalId)) THEN 'TRUE' END   
		END='TRUE' 

		/* Including the latest data from batch tables */
		/*
				IF(CAST(@FromDate AS DATE) = CAST(GETDATE() AS date) AND @DayWise <> 1)
				    BEGIN
				     
					 EXEC [TCD].[BatchChemicalLatestData] @Corporate,@Country,@Region,@EcolabAccountNumber,@Machine,@machineGroup,@Formula,
												     @MachineType,@Category,@FromDate,@ToDate,@GroupId,@MachineInternalId,@FromDate
				
				INSERT INTO @ChemicalConsumptionTable
				 SELECT 
						  CCR.ProductId,
						  CCR.RecordDate,
						  PM.Name AS Chemical,
						  CCR.TotalConsumption,
						  CCR.TargetConsumption,
						  CCR.AverageConsumption,
						  CCR.ActualConsumptionPerLoad,
						  CCR.TargetConsumptionPerLoad,
						  CCR.Cost,
						  CCR.CostPerLoad,
						  CCR.CostExcess,
						  CCR.NoOfBatches,
						  CCR.GroupId,
						  CCR.MachineInternalId,
						  CCR.ProgramNumber,
						  CCR.EcolabTextileId 
				 FROM #ChemicalConsumptionRollUpData CCR
				 INNER JOIN TCD.ProductMaster PM ON PM.ProductId = CCR.ProductId   

				 DROP TABLE #ChemicalConsumptionRollUpData

				 END
				 */
				    /* End of production latest batch data */

				   
     IF(@DayWise = 1)
	   BEGIN

		  SELECT 
					CCR.ProductId,
					PM.SKU + '-' + PM.Name AS chemical
					,SUM(TotalConsumption) AS TotalConsumption
					,SUM(TargetConsumption) AS TargetConsumption
					--,SUM(AverageConsumption) AS AverageConsumption
					,CAST(SUM(CCR.TotalConsumption)/COUNT(DISTINCT CCR.ProgramNumber) AS decimal(18,2)) AS AverageConsumption,
				    CAST(SUM(CCR.TotalConsumption)/COUNT(DISTINCT CCR.RecordDate) AS decimal(18,2)) AverageDailyConsumption,
				    CAST(SUM(CCR.TotalConsumption)/COUNT(CCR.BatchId) AS decimal(18,2)) AS ActualConsumptionPerLoad,
				    CAST(SUM(CCR.TargetConsumption)/COUNT(CCR.BatchId) AS decimal(18,2)) AS TargetConsumptionPerLoad,
				    SUM(CCR.Cost) AS Cost,
				    CAST(SUM(CCR.Cost)/COUNT(CCR.BatchId) AS decimal(18,2)) AS CostPerLoad,
				    CAST((CASE WHEN (SUM(CCR.TotalConsumption) - SUM(CCR.TargetConsumption) < 0) THEN 0 ELSE ABS(SUM(CCR.TotalConsumption) - SUM(CCR.TargetConsumption))*SUM(CCR.Cost) END) AS decimal(18,2)) AS CostExcess,
					@IsDrillDown AS IsDrillDown ,
					COUNT(CCR.BatchId) AS NoOfBatches,
				    COUNT(DISTINCT CCR.ProgramNumber) AS NoOfPrograms,
				    COUNT(DISTINCT CCR.RecordDate) NoOfDays			
					
					
					INTO #ProdTableDayOrder
					FROM @ChemicalConsumptionTable CCR INNER JOIN TCD.ProductMaster PM ON CCR.ProductId = PM.ProductId
					GROUP BY  Name,CCR.ProductId,PM.SKU --,DATEPART(WEEKDAY,RecordDate)				

					SET @SQLStatement 
					   ='SELECT * FROM #ProdTableDayOrder ORDER BY ' + @SortField + ' ' + @SortDirection
	   			EXEC(@SQLStatement)

	   END
	   
	IF(@WeekWise = 1)
		  BEGIN
			 SELECT 
					CCR.ProductId,
					PM.SKU + '-' + PM.Name AS chemical
					,SUM(TotalConsumption) AS TotalConsumption
					,SUM(TargetConsumption) AS TargetConsumption
					--,SUM(AverageConsumption) AS AverageConsumption
					,CAST(SUM(CCR.TotalConsumption)/COUNT(DISTINCT CCR.ProgramNumber) AS decimal(18,2)) AS AverageConsumption,
				    CAST(SUM(CCR.TotalConsumption)/COUNT(DISTINCT CCR.RecordDate) AS decimal(18,2)) AverageDailyConsumption,
				    CAST(SUM(CCR.TotalConsumption)/COUNT(CCR.BatchId) AS decimal(18,2)) AS ActualConsumptionPerLoad,
				    CAST(SUM(CCR.TargetConsumption)/COUNT(CCR.BatchId) AS decimal(18,2)) AS TargetConsumptionPerLoad,
				    SUM(CCR.Cost) AS Cost,
				    CAST(SUM(CCR.Cost)/COUNT(CCR.BatchId) AS decimal(18,2)) AS CostPerLoad,
				    CAST((CASE WHEN (SUM(CCR.TotalConsumption) - SUM(CCR.TargetConsumption) < 0) THEN 0 ELSE ABS(SUM(CCR.TotalConsumption) - SUM(CCR.TargetConsumption))*SUM(CCR.Cost) END) AS decimal(18,2)) AS CostExcess,
					@IsDrillDown AS IsDrillDown,
					COUNT(CCR.BatchId) AS NoOfBatches,
				    COUNT(DISTINCT CCR.ProgramNumber) AS NoOfPrograms,
				    COUNT(DISTINCT CCR.RecordDate) NoOfDays					
					
					INTO #ProdTableweekOrder
					FROM @ChemicalConsumptionTable CCR INNER JOIN TCD.ProductMaster PM ON CCR.ProductId = PM.ProductId
					GROUP BY  Name,CCR.ProductId,PM.SKU --,DATEPART(WEEKDAY,RecordDate)				

					SET @SQLStatement 

					   ='SELECT * FROM #ProdTableweekOrder ORDER BY ' + @SortField + ' ' + @SortDirection
	   			EXEC(@SQLStatement)						

		  END  		  

	   IF(@MonthWise = 1)
		  BEGIN 
			 SELECT 
					CCR.ProductId,
					PM.SKU + '-' + PM.Name AS chemical
					,SUM(TotalConsumption) AS TotalConsumption
					,SUM(TargetConsumption) AS TargetConsumption
					--,SUM(AverageConsumption) AS AverageConsumption
					,CAST(SUM(CCR.TotalConsumption)/COUNT(DISTINCT CCR.ProgramNumber) AS decimal(18,2)) AS AverageConsumption,
				    CAST(SUM(CCR.TotalConsumption)/COUNT(DISTINCT CCR.RecordDate) AS decimal(18,2)) AverageDailyConsumption,
				    CAST(SUM(CCR.TotalConsumption)/COUNT(CCR.BatchId) AS decimal(18,2)) AS ActualConsumptionPerLoad,
				    CAST(SUM(CCR.TargetConsumption)/COUNT(CCR.BatchId) AS decimal(18,2)) AS TargetConsumptionPerLoad,
				    SUM(CCR.Cost) AS Cost,
				    CAST(SUM(CCR.Cost)/COUNT(CCR.BatchId) AS decimal(18,2)) AS CostPerLoad,
				    CAST((CASE WHEN (SUM(CCR.TotalConsumption) - SUM(CCR.TargetConsumption) < 0) THEN 0 ELSE ABS(SUM(CCR.TotalConsumption) - SUM(CCR.TargetConsumption))*SUM(CCR.Cost) END) AS decimal(18,2)) AS CostExcess,
					@IsDrillDown AS IsDrillDown,
					COUNT(CCR.BatchId) AS NoOfBatches,
				    COUNT(DISTINCT CCR.ProgramNumber) AS NoOfPrograms,
				    COUNT(DISTINCT CCR.RecordDate) NoOfDays
					
					 INTO #ProdTableMonthOrder
					FROM @ChemicalConsumptionTable CCR INNER JOIN TCD.ProductMaster PM ON CCR.ProductId = PM.ProductId
					GROUP BY  Name,CCR.ProductId,PM.SKU --,DATEPART(WEEKDAY,RecordDate)	

					SET @SQLStatement 

					   ='SELECT * FROM #ProdTableMonthOrder ORDER BY ' + @SortField + ' ' + @SortDirection
	   			EXEC(@SQLStatement)

		  END

		  IF(@QuarterWise = 1)
			 BEGIN 
		  		    SELECT 
					CCR.ProductId,
					PM.SKU + '-' + PM.Name AS chemical
					,SUM(TotalConsumption) AS TotalConsumption
					,SUM(TargetConsumption) AS TargetConsumption
					--,SUM(AverageConsumption) AS AverageConsumption
					,CAST(SUM(CCR.TotalConsumption)/COUNT(DISTINCT CCR.ProgramNumber) AS decimal(18,2)) AS AverageConsumption,
				    CAST(SUM(CCR.TotalConsumption)/COUNT(DISTINCT CCR.RecordDate) AS decimal(18,2)) AverageDailyConsumption,
				    CAST(SUM(CCR.TotalConsumption)/COUNT(CCR.BatchId) AS decimal(18,2)) AS ActualConsumptionPerLoad,
				    CAST(SUM(CCR.TargetConsumption)/COUNT(CCR.BatchId) AS decimal(18,2)) AS TargetConsumptionPerLoad,
				    SUM(CCR.Cost) AS Cost,
				    CAST(SUM(CCR.Cost)/COUNT(CCR.BatchId) AS decimal(18,2)) AS CostPerLoad,
				    CAST((CASE WHEN (SUM(CCR.TotalConsumption) - SUM(CCR.TargetConsumption) < 0) THEN 0 ELSE ABS(SUM(CCR.TotalConsumption) - SUM(CCR.TargetConsumption))*SUM(CCR.Cost) END) AS decimal(18,2)) AS CostExcess,
					@IsDrillDown AS IsDrillDown,
					COUNT(CCR.BatchId) AS NoOfBatches,
				    COUNT(DISTINCT  CCR.ProgramNumber) AS NoOfPrograms,
				    COUNT(DISTINCT CCR.RecordDate) NoOfDays				
					
					 INTO #ProdTableQuarterOrder
					FROM @ChemicalConsumptionTable CCR INNER JOIN TCD.ProductMaster PM ON CCR.ProductId = PM.ProductId
					GROUP BY  Name,CCR.ProductId,PM.SKU --,DATEPART(WEEKDAY,RecordDate)	

				 SET @SQLStatement 
						    ='SELECT 
									ProductId,
								    Chemical,
								    TotalConsumption,
								    TargetConsumption,
								    AverageConsumption,
								    AverageDailyConsumption,
								    ActualConsumptionPerLoad,
								    TargetConsumptionPerLoad,
								    Cost,
								    CostPerLoad,
								    CostExcess,								    
								    IsDrillDown,
								    NoOfBatches,
								    NoOfPrograms,
								    NoOfDays
								 FROM #ProdTableQuarterOrder ORDER BY ' + @SortField + ' ' + @SortDirection
	   				   EXEC(@SQLStatement)
		  END

		IF(@yearwise = 1)
		  BEGIN 
			 SELECT 
					CCR.ProductId,
					PM.SKU + '-' + PM.Name AS chemical
					,SUM(TotalConsumption) AS TotalConsumption
					,SUM(TargetConsumption) AS TargetConsumption
					--,SUM(AverageConsumption) AS AverageConsumption
					,CAST(SUM(CCR.TotalConsumption)/COUNT(DISTINCT CCR.ProgramNumber) AS decimal(18,2)) AS AverageConsumption,
				    CAST(SUM(CCR.TotalConsumption)/COUNT(DISTINCT CCR.RecordDate) AS decimal(18,2)) AverageDailyConsumption,
				    CAST(SUM(CCR.TotalConsumption)/COUNT(CCR.BatchId) AS decimal(18,2)) AS ActualConsumptionPerLoad,
				    CAST(SUM(CCR.TargetConsumption)/COUNT(CCR.BatchId) AS decimal(18,2)) AS TargetConsumptionPerLoad,
				    SUM(CCR.Cost) AS Cost,
				    CAST(SUM(CCR.Cost)/COUNT(CCR.BatchId) AS decimal(18,2)) AS CostPerLoad,
				    CAST((CASE WHEN (SUM(CCR.TotalConsumption) - SUM(CCR.TargetConsumption) < 0) THEN 0 ELSE ABS(SUM(CCR.TotalConsumption) - SUM(CCR.TargetConsumption))*SUM(CCR.Cost) END) AS decimal(18,2)) AS CostExcess,
					@IsDrillDown AS IsDrillDown,
					COUNT(CCR.BatchId) AS NoOfBatches,
				    COUNT(DISTINCT CCR.ProgramNumber) AS NoOfPrograms,
				    COUNT(DISTINCT CCR.RecordDate) NoOfDays
					
					INTO #ProdTableyearOrder
					FROM @ChemicalConsumptionTable CCR INNER JOIN TCD.ProductMaster PM ON CCR.ProductId = PM.ProductId
					GROUP BY  Name,CCR.ProductId,PM.SKU --,DATEPART(WEEKDAY,RecordDate)	
			 
			  SET @SQLStatement 
						    ='SELECT 
									ProductId,									
								    Chemical,
								    TotalConsumption,
								    TargetConsumption,
								    AverageConsumption,
								    AverageDailyConsumption,
								    ActualConsumptionPerLoad,
								    TargetConsumptionPerLoad,
								    Cost,
								    CostPerLoad,
								    CostExcess	,								    
								    IsDrillDown,
								    NoOfBatches,
								    NoOfPrograms,
								    NoOfDays
								 FROM #ProdTableyearOrder ORDER BY ' + @SortField + ' ' + @SortDirection
	   				   EXEC(@SQLStatement)

		END
		SET NOCOUNT OFF;   

END