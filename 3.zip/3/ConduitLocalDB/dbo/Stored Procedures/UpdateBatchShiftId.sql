﻿CREATE PROCEDURE TCD.UpdateBatchShiftId
AS
BEGIN
  Update tcd.BatchData set ShiftId = PSD.ShiftId FROM
  [TCD].[ProductionShiftData] PSD
  WHERE EndDate between StartDateTime AND EndDateTime
  AND tcd.BatchData.ShiftId IS NULL

  ---- Soft delete the created dummy Shift
  --Update tcd.shiftData SET Is_Deleted = 1 
		--	WHERE SHIFTNAME = 'Full Day Shift'  
END