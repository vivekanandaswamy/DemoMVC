﻿CREATE PROCEDURE TCD.GetPlantUtilityDetails(
       @Ecolabaccountnumber nvarchar(25))
AS
BEGIN
    SET NOCOUNT ON
    IF EXISTS(SELECT
                      s.*
                  FROM tempdb.sys.sysobjects AS s
                  WHERE s.xtype IN('U')
                    AND (s.id = OBJECT_ID(N'tempdb..#tmpWaterTypesUsed')
                      OR s.id = OBJECT_ID(N'tempdb..#tmpGasOilTypes')))
BEGIN
            DROP TABLE
                    #tmpGasOilTypes;
            DROP TABLE
                    #tmpWaterTypesUsed;

END

    CREATE TABLE #tmpWaterTypesUsed(
            WaterType INT, 
            WasherMode VARCHAR(1000))
    INSERT INTO #tmpWaterTypesUsed(
            WaterType, 
            WasherMode)
    (SELECT
             wds.WaterType, 
             'Washer' AS WasherMode
         FROM TCD.WasherDosingSetup AS wds
         WHERE wds.WaterType > 0
           AND wds.Is_Deleted = 0
UNION
     SELECT
             tds.WaterType, 
             'Tunnel' AS WasherMode
         FROM TCD.TunnelDosingSetup AS tds
         WHERE tds.WaterType > 0
           AND tds.Is_Deleted = 0)


    DECLARE @Regionid INT, 
            @Usagekey VARCHAR(100)
    SELECT
            @Regionid = P.RegionID
        FROM TCD.Plant AS P
        WHERE P.EcolabAccountNumber = @Ecolabaccountnumber

    CREATE TABLE #tmpGasOilTypes(
            GasOilType VARCHAR(100), 
            EnergyContent DECIMAL(18, 4), 
            UsageKey VARCHAR(100))
    INSERT INTO #tmpGasOilTypes(
            GasOilType, 
            EnergyContent, 
            UsageKey)
    (SELECT
             gtm.Name, 
             gotm.DefaultValue, 
             gtm.UsageKey
         FROM TCD.GasoilTypeMaster AS gtm
              INNER JOIN TCD.GasOilTypeMapping AS gotm ON gtm.GasoilId = gotm.GasOilId
         WHERE gtm.GasoilId = (SELECT
                                       eud.GasOilTypeId
                                   FROM TCD.EnergyUtilityDetails AS eud
                                   WHERE eud.EcolabAccountNumber = @Ecolabaccountnumber)
           AND gotm.RegionId = @Regionid)
 


    SELECT DISTINCT
            @Usagekey = rkv.[Value]
        FROM TCD.DimensionalSubunits AS ds
             INNER JOIN tcd.DimensionalUnits AS du ON du.Unit = ds.Unit
             INNER JOIN TCD.DimensionalUsageKey AS duk ON duk.Unit = ds.Unit
             INNER JOIN TCD.DimensionalUnitsDefaults AS dud ON dud.UsageKey = duk.UsageKey
             INNER JOIN TCD.ResourceKeyMaster AS rkm ON rkm.KeyName = dud.Subunit
             INNER JOIN tcd.ResourceKeyValue AS rkv ON rkv.KeyName = rkm.KeyName
        WHERE duk.UsageKey = (SELECT
                                      UsageKey FROM #tmpGasOilTypes AS tgot)COLLATE Latin1_General_CI_AI
          AND dud.UnitSystemId = (SELECT
                                          p.UOMId FROM TCD.Plant AS p WHERE p.EcolabAccountNumber = @Ecolabaccountnumber)




    SELECT
            wu.EcolabAccountNumber AS EcolabAccountNumber, 
            wu.WaterFactorTypeId AS WaterFactorTypeId, 
		 CASE
                WHEN wu.WaterFactorTypeId <> 0 THEN(SELECT DISTINCT
                                                            wt.Name
                                                        FROM TCD.WaterUtilityDetails AS wud
                                                             INNER JOIN TCD.WaterType AS wt ON wt.Id = wud.WaterFactorTypeId
                                                        WHERE wt.Id = wu.WaterFactorTypeId)
                WHEN wu.WaterFactorTypeId = 0 THEN CONVERT(VARCHAR(350), wu.WaterFactorTypeId)
            END AS FactorType, 
            wu.Temperature AS Temperature, 
            wu.Price AS Price, 
            eu.GasOilTypeId AS GasOilTypeId, 
            (SELECT
                     GasOilType FROM #tmpGasOilTypes AS tgot)AS GasOilType, 
            (SELECT
                     EnergyContent FROM #tmpGasOilTypes AS tgot)AS EnergyContent, 
            @Usagekey AS EnergyContentUnit, 
            eu.EnergyPrice AS EnergyPrice, 
            eu.EnergySubUnit AS EnergyPriceUnit, 
            eu.ElectricPrice AS ElectricPrice, 
            eu.BolierSteam AS BoilerSteam, 
            eu.BolierType AS BoilerType, 
            eu.Steam AS Steam, 
            eu.Boiler AS Boiler, 
            eu.Stack AS Stack, 
            eu.RewashFactor AS RewashFactor, 
            eu.EvaporationFactor AS EvaporationFactor, 
		 CASE 
                WHEN wu.WaterFactorTypeId <> 0 THEN(SELECT DISTINCT
                                                            wt.MyServiceUtilTypeCode
                                                        FROM TCD.WaterUtilityDetails AS wud
                                                             INNER JOIN TCD.WaterType AS wt ON wt.Id = wud.WaterFactorTypeId
                                                        WHERE wt.Id = wu.WaterFactorTypeId)
                WHEN wu.WaterFactorTypeId = 0 THEN 'V'
            END AS FreeType, 
		  CASE 	
                WHEN(SELECT
                             COUNT(*)
                         FROM #tmpWaterTypesUsed AS twtu
                              INNER JOIN TCD.Watertype AS wt ON twtu.WaterType = wt.Id
                                                            AND wt.MyServiceUtilTypeCode = 'V'
                         WHERE twtu.WaterType = wu.WaterFactorTypeId) > 0 THEN 'TRUE'
                WHEN(SELECT
                             COUNT(*)
                         FROM #tmpWaterTypesUsed AS twtu
                              INNER JOIN TCD.Watertype AS wt ON twtu.WaterType = wt.Id
                                                            AND wt.MyServiceUtilTypeCode = 'V'
                         WHERE twtu.WaterType = wu.WaterFactorTypeId) = 0 THEN 'FALSE'
            END AS IsFactorUsed, 
		  eu.LastModifiedTime,
		  wu.MyServiceWtrFctrId,
		  wu.MyServiceLastSyncTime,
		  wu.WaterUtilityDetailsId
        FROM TCD.WaterUtilityDetails AS wu
             INNER JOIN TCD.EnergyUtilityDetails AS eu ON eu.EcolabAccountNumber = wu.EcolabAccountNumber
        WHERE wu.EcolabAccountNumber = @Ecolabaccountnumber
        ORDER BY
            wu.WaterUtilityDetailsId
    SET NOCOUNT OFF
END