﻿CREATE PROCEDURE [TCD].[SaveProductionShiftManualLabourRollup](
--DECLARE
												@FromDate datetime = NULL,--'2015-05-13',
												@Todate datetime = NULL,-- '2015-05-13',
												@LabourType int = NULL,-- 1,
												@ManualHours int = NULL-- 100 							
																				
												
											 )
AS
SET NOCOUNT ON
BEGIN

    DECLARE 
		  @ShiftId Int = NULL,   		  
		  @BatchUTCStart DATETIME= NULL,
		  @BatchUTCEnd DATETIME= NULL,
		  @ShiftTargetProd Decimal(18,2) = NULL,
		  @ShiftCount Int = 1,
		  @validateShiftName varchar(100)

    DECLARE @ProductionShiftLaborData TABLE
				 (
					[ShiftId] [int] NULL,
					[LaborType] [int] NULL,
					[LaborHours] [int] NULL,
					[LaborCost] [decimal](18, 2) 
				)
	   
    DECLARE @BatchShiftTable TABLE
						(
						  RowNumber int IDENTITY(1,1),
						  BatchUTCStartDate datetime,
						  BatchUTCEndDate datetime,
						  ShiftId int,
						  ShiftName varchar(100)
						)

    IF(@FromDate = @Todate)
    BEGIN
     INSERT INTO @BatchShiftTable
	 (
	    BatchUTCStartDate,
	    BatchUTCEndDate,
	    ShiftId,
	    ShiftName
	 )
	 SELECT 
		  DISTINCT
			StartDateTime,
			EndDateTime,
			sd.ShiftID,
			ShiftName		   
					FROM [TCD].ProductionShiftData SD WITH (NOLOCK) 
						 WHERE CAST(SD.StartDateTime AS date) = CAST( DATEADD(hh, DATEDIFF(hh, GETDATE(), GETUTCDATE()), @FromDate) AS date)  AND SD.ShiftName <> 'No Shift'
					   ORDER BY SD.ShiftId
    END
    ELSE
    BEGIN  		  
	 INSERT INTO @BatchShiftTable
	 (
	    BatchUTCStartDate,
	    BatchUTCEndDate,
	    ShiftId,
	    ShiftName
	 )
	 SELECT 
		  DISTINCT
			StartDateTime,
			EndDateTime,
			sd.ShiftID,
			ShiftName		   
					FROM [TCD].ProductionShiftData SD WITH (NOLOCK) 
						 WHERE CAST(SD.StartDateTime AS date) >= CAST( DATEADD(hh, DATEDIFF(hh, GETDATE(), GETUTCDATE()), @FromDate) AS date)
						 AND CAST(sd.StartDateTime AS date) <= CAST( DATEADD(hh, DATEDIFF(hh, GETDATE(), GETUTCDATE()), @Todate) as date) AND SD.ShiftName <> 'No Shift'
					   ORDER BY SD.ShiftId
	END




	  --SELECT bst.* FROM @BatchShiftTable bst

    DECLARE @ManualInputData TABLE
			 (
				ManualHours int,
				LabourType int
			)
			 INSERT @ManualInputData
			 (
			     ManualHours,
				LabourType
			)
			
			 SELECT @ManualHours/NULLIF((SELECT COUNT(1) FROM @BatchShiftTable bst WHERE bst.ShiftName <> 'No Shift'),0),
				   @LabourType
				   
			   
   			--SELECT mid.* FROM @ManualInputData mid
	   ------------------******// Inserting the Data into Batch Summary Temp table based on UTC shift timings //******-----------------------
    WHILE (@ShiftCount <= (SELECT COUNT(1) FROM @BatchShiftTable bst))
    BEGIN

    SELECT  @BatchUTCStart = 
				    bst.BatchUTCStartDate,
			   @BatchUTCEnd = 
				    bst.BatchUTCEndDate,
			   @ShiftId = bst.ShiftId,
			   @validateShiftName = bst.ShiftName
				FROM @BatchShiftTable bst WHERE bst.RowNumber = @ShiftCount
    
    INSERT INTO @ProductionShiftLaborData
		  (
			 [ShiftId],
			 [LaborType],
			 [LaborHours],
			 [LaborCost]
			 )
    SELECT 
		   [ShiftId],
			 [LaborType],
			 [LaborHours],
			 [LaborCost] FROM TCD.ProductionShiftLaborData spdr WHERE spdr.ShiftId = @ShiftId
	  
	    --------------------------******// Inserting the Data into production Shift Rollup Data Table //******-------------------
	      		  
		 DELETE FROM [TCD].ProductionShiftLaborData WHERE ShiftId = @ShiftId 
		 
			 INSERT INTO [TCD].ProductionShiftLaborData
								  (
								    [ShiftId],
								    [LaborType],
								    [LaborHours],
								    [LaborCost]
								  )

			 SELECT 
				    
				    [ShiftId],
				    [LaborType],
				    [LaborHours] + ISNULL((SELECT mid.ManualHours FROM @ManualInputData mid WHERE mid.LabourType = spdr.LaborType),0),
				    [LaborCost] + ISNULL((SELECT mid.ManualHours * lc.Cost FROM @ManualInputData mid INNER JOIN TCD.LaborCost lc ON mid.LabourType = lc.LaborTypeId
				     WHERE mid.LabourType = spdr.LaborType),0)		 
						  FROM @ProductionShiftLaborData spdr
				
		  IF(@validateShiftName <> 'No Shift')
		  BEGIN
		  IF NOT EXISTS(SELECT DISTINCT * FROM TCD.ProductionShiftLaborData spdr WHERE spdr.ShiftId = @ShiftId
																   AND spdr.LaborType IN (SELECT mid.LabourType FROM @ManualInputData mid)
																   )
				BEGIN
				   INSERT INTO [TCD].ProductionShiftLaborData
								 (
								    [ShiftId],
								    [LaborType],
								    [LaborHours],
								    [LaborCost]
								  )


				SELECT TOP 1 
					   @ShiftId
					  ,(SELECT mid.LabourType FROM @ManualInputData mid)
					  ,(SELECT mid.ManualHours FROM @ManualInputData mid)
					  ,(SELECT mid.ManualHours * lc.Cost FROM @ManualInputData mid INNER JOIN TCD.LaborCost lc ON mid.LabourType = lc.LaborTypeId)
					  		-- FROM TCD.ShiftProductionDataRollup spdr WHERE spdr.ShiftId = @ShiftId
								
		    
				END
			END
	  	   DELETE FROM @ProductionShiftLaborData		 
		  SET @ShiftCount = @ShiftCount + 1
	    END	   
	  
END



