﻿/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_deleteDryerGroup]                                    

Purpose:				To delete the dryer group.

Parameters:				@GroupTypeId - holds the group id.
						@UserId - holds the user id.
						@Scope - holds the scope.
																																									
###################################################################################################                                           
*/ 
CREATE PROCEDURE [TCD].[DeleteDryerGroup] (@GroupTypeId INT,@UserId Int,@Scope Varchar(100) OUTPUT

--Adding these 3 param as part of re-factoring for integration with Synch/Configurator
--Adding EcolabAccountNumber also, since it was missing...
,	@EcolabAccountNumber				NVARCHAR(25)
,	@LastModifiedTimestampAtCentral		DATETIME			=			NULL		--Nullable for local call; Synch/Central call will have to pass this -
																					--else, it will be treated as a local call
,	@OutputLastModifiedTimestampAtLocal	DATETIME			=			NULL	OUTPUT
)
AS
BEGIN

SET nocount ON;
Declare @OutPut varchar(100) = ''

DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()

DECLARE
		@OutputList						AS	TABLE		(
		LastModifiedTimestamp			DATETIME
	)

SET		@OutputLastModifiedTimestampAtLocal			=			ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight SA0121
SET		@Scope										=			ISNULL(@Scope, NULL)										--SQLEnlight SA0121


--IF NOT EXISTS(SELECT 1 FROM [TCD].METER WHERE GroupId = @GroupTypeId AND Is_deleted = 0)
--BEGIN

		--If the call is not local, check that the LastModifiedTime matches with the central
		IF	(
				@LastModifiedTimestampAtCentral				IS NOT	NULL
			AND
			NOT	EXISTS	(	SELECT	1
							FROM	TCD.MachineGroup			GT
							WHERE	GT.EcolabAccountNumber	=	@EcolabAccountNumber
								AND	GT.Id				=	@GroupTypeId
								AND	GT.LastModifiedTime		=	@LastModifiedTimestampAtCentral
						)
			)
				BEGIN
						SET			@ErrorId				=	60000
						SET			@ErrorMessage			=	N'' + CAST(@ErrorId AS NVARCHAR(10))
						RAISERROR	(@ErrorMessage, 16, 1)
						SET			@ReturnValue			=	-1
						RETURN		(@ReturnValue)
				END

		--Proceed to soft-delete, since it's either a local call or Synch. call with synch. time matching
		UPDATE [TCD].MachineGroup SET is_deleted = 1 
		--**	Adding as part of Audit re-factor to capture the User info.
		,	LastModifiedTime				=			@CurrentUTCTime
		OUTPUT
			inserted.LastModifiedTime		AS			LastModifiedTimestamp
		INTO
			@OutputList	(
			LastModifiedTimestamp
		)	--**
		WHERE  Id = @GroupTypeId

		UPDATE	[TCD].Dryers 
			  SET is_deleted = 1 
			  ,	LastModifiedByUserId = @UserId  
			  ,	LastModifiedTime	=	@CurrentUTCTime			
		  WHERE  DryerGroupId = @GroupTypeId
--END
--ELSE
--BEGIN
--Set @OutPut ='501'

--SELECT @Scope = @OutPut SELECT @Scope
--END


SELECT	TOP 1	
		@OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp
FROM	@OutputList							O


SET nocount ON;
END