﻿/*      
 ==========================================================================================      
 Purpose:  Save the Chemical 
    
 Author:  Krishna Gangadhar Thota  
 Modified : Prashant Sharma
    
 --------------------------------------------------------------      
 Sep-04-2014 ENT: Initial version.      
 ==========================================================================================   
*/

CREATE PROCEDURE [TCD].[SavePlantChemicals] 
(		
		@Id											INT						=	NULL
	,	@ProductId									INT
	,	@Cost										FLOAT
	,	@IncludeCI									BIT
	,	@EcolabAccountNumber						NVARCHAR(25)
	,	@UserID										INT						= NULL
	,	@InventoryExpense							NVARCHAR(1)				= NULL
	,	@IsDeleted									BIT
	,	@OutputChemicalId							INT						=	NULL	OUTPUT
	,	@LastModifiedTimestampAtCentral				DATETIME				=	NULL
	,	@OutputLastModifiedTimestampAtLocal			DATETIME				=	NULL	OUTPUT
) 
AS 
SET NOCOUNT ON
  
  BEGIN 
	
	DECLARE	
		@Output							VARCHAR(100)	=			''  
	,	@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()
	
	DECLARE
			@OutputList						AS	TABLE		(
			PlantChemicalId					INT
		,	LastModifiedTimestamp			DATETIME
		)

SET		@OutputLastModifiedTimestampAtLocal			=			ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight
SET		@OutputChemicalId							=			ISNULL(@OutputChemicalId, NULL)								--SQLEnlight

	
	IF EXISTS (SELECT 1 FROM [TCD].ProductdataMapping WHERE  ProductID = @ProductId AND EcolabAccountNumber = @EcolabAccountNumber)
		BEGIN
			  
						IF	(
									@LastModifiedTimestampAtCentral				IS NOT	NULL
									AND
									NOT	EXISTS	(	SELECT	1
											FROM	TCD.ProductDataMapping		PDM
											WHERE	PDM.EcolabAccountNumber	=	@EcolabAccountNumber
												AND	PDM.ID					=	@Id
												AND	PDM.LastModifiedTime		=	@LastModifiedTimestampAtCentral
										)
							)
								BEGIN
										SET			@ErrorId				=	60000
										SET			@ErrorMessage			=	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
										RAISERROR	(@ErrorMessage, 16, 1)
										SET			@ReturnValue			=	-1
										RETURN		(@ReturnValue)
								END
			  
						  UPDATE 
							[TCD].ProductdataMapping 
							SET 
								Cost = @Cost 
							,	IncludeCI = @IncludeCI
							,	InventoryExpense = @InventoryExpense
							,	LastModifiedByUserId	=	@UserID
							,	LastModifiedTime		=	@CurrentUTCTime
							,	Is_Deleted = @IsDeleted	
							OUTPUT
								inserted.ID						AS			Id
							,	inserted.LastModifiedTime		AS			LastModifiedTimestamp
							INTO
								@OutputList	(
								PlantChemicalId
							,	LastModifiedTimestamp
							)
							WHERE 
							ProductID = @ProductId 
							AND 
							EcolabAccountNumber = @EcolabAccountNumber 
		END
	ELSE
	IF NOT EXISTS (SELECT 1 FROM [TCD].ProductdataMapping WHERE  ProductID = @ProductId AND Is_Deleted = 0 AND EcolabAccountNumber = @EcolabAccountNumber)   
		BEGIN
			
			INSERT INTO [TCD].ProductdataMapping(ProductID,SKU,Cost,IncludeCI,InventoryExpense,EcolabAccountNumber,LastModifiedByUserId,Is_Deleted)
			OUTPUT
					inserted.ID						AS			Id
				,	inserted.LastModifiedTime		AS			LastModifiedTimestamp
				INTO
					@OutputList	(
					PlantChemicalId
				,	LastModifiedTimestamp
				)
			SELECT ProductId,SKU,@Cost,@IncludeCI,@InventoryExpense,@EcolabAccountNumber,@UserID,@IsDeleted FROM [TCD].ProductMaster WHERE ProductId = @ProductId 

		END

	SELECT	TOP 1	
		@OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp
	,	@OutputChemicalId				=	O.PlantChemicalId
FROM	@OutputList							O


RETURN	(@ReturnValue)

--SET NOCOUNT OFF;
END