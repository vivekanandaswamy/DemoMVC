/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_GetAlarmDetails]                                         

Purpose:				To get the alarms details.

Parameters:				@EcolabAccountNumber - holds the ecolab account number.
																																		
###################################################################################################                                           
*/

CREATE PROCEDURE [TCD].GetAlarmDetails (
@EcolabAccountNumber NVARCHAR(25))
AS
BEGIN
    SET NOCOUNT ON;

	SET		@EcolabAccountNumber			=			ISNULL(@EcolabAccountNumber, NULL)			--SQLEnlight SA0029

    BEGIN
	   SELECT DISTINCT
	   'DateTime' = (
				  SELECT CONVERT(VARCHAR(10), CAST(AD.StartDate AS DATE), 101)
					    +
					    ' '
					    +
					    CONVERT(VARCHAR(8), AD.StartDate, 108)),
	   'Alarm Number' = AD.AlarmCode,
	   'Source' = CC.Name,
	   AlarmDescription = AM.Description
		FROM [TCD].AlarmData AD
			LEFT OUTER JOIN
			[TCD].AlarmGroupMaster AM ON AM.AlarmGroupMasterId = AD.AlarmGroupMasterId
			INNER JOIN TCD.AlarmGroupMsterVsControllerModelType AGMVCMT ON AM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId AND AGMVCMT.AlarmCode = AD.AlarmCode
			LEFT OUTER JOIN
			[TCD].ConduitController CC ON CC.ControllerId = AD.ControllerId AND AD.EcoalabAccountNumber = CC.EcoalabAccountNumber
		WHERE AGMVCMT.AlarmCode IS NOT NULL AND AGMVCMT.AlarmCode != 0 AND AD.AlarmCode IS NOT NULL AND AD.AlarmCode != 0
		  AND AD.IsActive = 1 ORDER BY DateTime DESC
    END;	  
END;
