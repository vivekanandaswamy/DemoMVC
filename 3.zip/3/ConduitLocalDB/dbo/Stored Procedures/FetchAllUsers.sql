﻿
/*   
 ==========================================================================================  
 Purpose:  Save the Plant Details.   

 Author:  Premchand Yelavarthi   

 --------------------------------------------------------------   
 July-22-2014 ENT: Initial version.   
 ==========================================================================================  
*/ 
CREATE PROCEDURE [TCD].[FetchAllUsers]

AS 
SET NOCOUNT ON

  BEGIN

SELECT distinct um.FirstName,um.LastName,um.Email,um.UserId,

(select u.RoleName from [TCD].UserRoles u where u.RoleId = ur.RoleId) as RoleName,

(select u.LevelId from [TCD].UserRoles u where u.RoleId = ur.RoleId) as LevelID

  FROM [TCD].[UserMaster] um

  Inner join

  [TCD].UserInRole ur on um.UserId = ur.UserId END