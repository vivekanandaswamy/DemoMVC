﻿CREATE PROCEDURE TCD.ProcessEControlPlusBatchConventionalProdData(
 @Controllerid	 INT, 
 @Vxml			 XML, 
 @Plcpointer	 INT, 
 @Readpointer	 INT, 
 @Redflagshiftid INT OUTPUT)
AS
BEGIN
	DECLARE @Machinenumber			 INT, 
			@Startdatetime			 DATETIME, 
			@Enddatetime			 DATETIME, 
			@Programnumber			 INT, 
			@Load					 DECIMAL(10, 2), 
			@Nominalload			 DECIMAL(10, 2), 
			@Customernumber			 INT, 
			@Phstatus				 INT, 
			@Phvalue				 INT, 
			@Temperaturemin			 INT, 
			@Temperaturemax			 INT, 
			@Tempminstatus			 INT, 
			@Tempmaxstatus			 INT, 
			@Batchnumber			 INT, 
			@Washerid				 INT, 
			@Washergroupid			 INT, 
			@Ecolabwasherid			 INT, 
			@Programmasterid		 INT, 
			@Plantwashernumber		 INT, 
			@Shiftid				 INT, 
			@Batchid				 INT, 
			@Shiftstartdate			 DATETIME, 
			@Laststep				 INT, 
			@Currentstep			 INT, 
			@Currentsteptime		 DATETIME, 
			@Mintempparamid			 INT, 
			@Maxtempparamid			 INT, 
			@Mintempstatuparamid	 INT, 
			@Maxtempstatusparamid	 INT, 
			@Phstatusparamid		 INT, 
			@Phvalueparamid			 INT, 
			@Currencycode			 VARCHAR(50), 
			@Stdinjectionsteps		 INT, 
			@Stdwashsteps			 INT, 
			@Actualinjsteps			 INT, 
			@Ecolabtextilecategoryid INT, 
			@Chaintextilecategoryid	 INT, 
			@Formulasegmentid		 INT, 
			@Ecolabsaturationid		 INT, 
			@Plantprogramid			 INT, 
			@Targetturntime			 INT, 
			@Previousshiftid		 INT, 
			@Currentshiftid			 INT, 
			@Meterid				 INT, 
			@Stepcomportment		 INT, 
			@Stepno					 INT, 
			@Quantity				 INT, 
			@Productid				 INT, 
			@Price					 DECIMAL(18, 4), 
			@Standardqty			 DECIMAL(18, 4), 
			@Timestamp				 DATETIME2(7), 
			@Maxwashertgroupcapacity INT, 
			@Injectionnumber		 INT, 
			@Waterconsumption1		 DECIMAL(10, 6), 
			@Waterconsumption2		 DECIMAL(10, 6), 
			@Energycount			 INT, 
			@Ecolabaccountnumber	 VARCHAR(100), 
			@Alarmgroupmasterid		 INT,
			@TotalInjectsCountFromUI		INT,
			@TotalInjectsCountFromPLC		INT;
	SELECT 
		   @Machinenumber = T.c.value('@MachineNumber', 'INT'), 
		   @Startdatetime = T.c.value('@StartDateTime', 'DateTime'), 
		   @Enddatetime = T.c.value('@EndDateTime', 'DateTime'), 
		   @Programnumber = T.c.value('@ProgramNumber', 'INT'), 
		   @Load = T.c.value('@Load', 'Decimal(10,2)'), 
		   @Nominalload = T.c.value('@NominalLoad', 'Decimal(10,2)'), 
		   @Customernumber = T.c.value('@CustomerNumber', 'INT'), 
		   @Phvalue = T.c.value('@PHValue', 'INT'), 
		   @Temperaturemin = T.c.value('@TemperatureMin', 'INT'), 
		   @Temperaturemax = T.c.value('@TemperatureMax', 'INT'), 
		   @Batchnumber = T.c.value('@BatchNumber', 'INT')
		FROM @Vxml.nodes('ConventionalWasherData') AS T(C);
	--Check for valid startdatetime
	IF @Startdatetime <= '01/01/1900'
	   OR @Startdatetime > '06/06/2079'
		BEGIN
			RETURN;
		END;
	DECLARE @Shiftmapping TABLE
	(
		 ShiftId		INT, 
		 ShiftName		NVARCHAR(50), 
		 ShiftStartdate DATETIME
	);
	DELETE FROM @Shiftmapping;
	IF @Enddatetime IS NOT NULL
		BEGIN
			INSERT INTO @Shiftmapping
			(
				   ShiftId, 
				   ShiftName, 
				   ShiftStartdate
			)
			EXEC TCD.GetShiftStartDate 
				 @Enddatetime;
		END;
	ELSE
		BEGIN
			INSERT INTO @Shiftmapping
			(
				   ShiftId, 
				   ShiftName, 
				   ShiftStartdate
			)
			EXEC TCD.GetShiftStartDate 
				 @Startdatetime;
		END;
	SELECT 
		   @Shiftid = ShiftID, 
		   @Shiftstartdate = ShiftStartdate FROM @Shiftmapping;
	SELECT 
		   @Washergroupid = GroupId, 
		   @Washerid = WasherID
		FROM TCD.MachineSetup AS ms
		WHERE ControllerID = @Controllerid
			  AND MachineInternalId = @Machinenumber
			  AND IsTunnel = 0
			  AND IsDeleted = 0;
	IF @Washerid IS NOT NULL
		BEGIN
			SELECT 
				   @Programmasterid = Wps.ProgramId
				FROM TCD.Washer AS Ws
					 INNER JOIN TCD.MachineSetup AS Ms ON Ms.WasherId = Ws.WasherId
					 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Ms.GroupId
					 INNER JOIN TCD.WasherProgramSetup AS Wps ON Wps.WasherGroupId = Wg.WasherGroupId
					 INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber = Ws.EcoLabAccountNumber
				WHERE Ws.WasherId = @Washerid
					  AND Wps.ProgramNumber = @Programnumber
					  --AND Wps.ControllerID = @ControllerID
					  AND Wps.Is_Deleted = 0
					  AND ms.IsDeleted = 0;
			SELECT 
				   @Ecolabwasherid = EcolabWasherId, 
				   @Plantwashernumber = PlantWasherNumber, 
				   @Currencycode = P.CurrencyCode, 
				   @Targetturntime = w.TargetTurnTime * 60
				FROM TCD.Washer AS w
					 INNER JOIN tcd.Plant AS p ON w.EcoLabAccountNumber = p.EcolabAccountNumber
				WHERE w.WasherId = @Washerid;
		END;
	SELECT 
		   @Batchid = BatchID
		FROM TCD.BatchData
		WHERE MachineInternalID = @Machinenumber
			  AND StartDate = @Startdatetime
			  AND ControllerBatchId = @Batchnumber
			  AND MachineID = @Washerid;
	--Start Getting InjectionCount and StepCount
	SELECT 
		   @Stdinjectionsteps = COUNT(DISTINCT wdpm.WasherDosingSetupId), 
		   @Stdwashsteps = COUNT(DISTINCT wds.WasherDosingSetupId) - COUNT(DISTINCT wdpm.WasherDosingSetupId)
		FROM TCD.WasherDosingProductMapping AS wdpm
			 RIGHT JOIN TCD.WasherDosingSetup AS wds ON wdpm.WasherDosingSetupId = wds.WasherDosingSetupId
		WHERE wds.GroupId = @Washergroupid
			  AND wds.ProgramNumber = @Programnumber
			  AND wds.Is_Deleted = 0;
	--End Getting InjectionCount and StepCount
	--Start-----ProgramMasterID logic for PlantChainProgram
	SELECT 
		   @Plantprogramid = pm.PlantProgramId, 
		   @Ecolabtextilecategoryid = pm.EcolabTextileCategoryId, 
		   @Chaintextilecategoryid = pm.ChainTextileId, 
		   @Formulasegmentid = pm.FormulaSegmentId, 
		   @Ecolabsaturationid = pm.EcolabSaturationId
		FROM TCD.ProgramMaster AS pm
		WHERE pm.ProgramId = @Programmasterid
			  AND pm.Is_Deleted = 0;
	IF @Plantprogramid <> 0
	   OR @Plantprogramid IS NOT NULL
		BEGIN
			--Assign value from plantchainprogram table based on plantprogramId
			SELECT 
				   @Ecolabtextilecategoryid = pcp.EcolabTextileCategoryId, 
				   @Chaintextilecategoryid = pcp.ChainTextileCategoryId, 
				   @Formulasegmentid = pcp.FormulaSegmentId, 
				   @Ecolabsaturationid = pcp.EcolabSaturationId
				FROM tcd.PlantChainProgram AS pcp
				WHERE pcp.PlantProgramId = @Plantprogramid
					  AND pcp.Is_Deleted = 0;
		END;
	--End-----ProgramMasterID logic for PlantChainProgram
	IF @Batchid IS NULL
		BEGIN
			--Start Rollup for previous completed shift
			IF CAST(@Startdatetime AS DATE) < CAST(GETUTCDATE() AS DATE)
				BEGIN
					SELECT TOP 1 
						   @Previousshiftid = ShiftId
						FROM TCD.BatchData
						WHERE MachineId = @Washerid
						ORDER BY 
								 StartDate DESC;
					SELECT TOP 1 
						   @Currentshiftid = ShiftId FROM @Shiftmapping;
					IF @Currentshiftid != @Previousshiftid
						BEGIN
							EXEC TCD.ProductionShiftDataRollup 
								 @Previousshiftid, 
								 @Redflagshiftid OUTPUT;
							IF @Redflagshiftid IS NULL
								BEGIN
									SET @Redflagshiftid = @Previousshiftid;
								END;
						END;
				END;
			--End Rollup for previous completed shift
			INSERT INTO TCD.BatchData
			(
				   ControllerBatchID, 
				   EcolabWasherId, 
				   GroupId, 
				   MachineInternalId, 
				   PlantWasherNumber, 
				   StartDate, 
				   EndDate, 
				   ProgramNumber, 
				   ProgramMasterId, 
				   MachineID, 
				   ActualWeight, 
				   StandardWeight, 
				   CurrencyCode, 
				   ShiftId, 
				   PartitionOn, 
				   StdInjectionSteps, 
				   StdWashSteps, 
				   EcolabTextileCategoryId, 
				   ChainTextileCategoryId, 
				   FormulaSegmentId, 
				   EcolabSaturationId, 
				   PlantProgramId, 
				   EndDateFormula, 
				   TargetTurnTime,
				   SyncReady
			)
			VALUES
			(
				   @Batchnumber, 
				   @Ecolabwasherid, 
				   @Washergroupid, 
				   @Machinenumber, 
				   @Plantwashernumber, 
				   @Startdatetime, 
				   @Enddatetime, 
				   @Programnumber, 
				   @Programmasterid, 
				   @Washerid, 
				   @Load, 
				   ISNULL(@Nominalload, 0), 
				   @Currencycode, 
				   @Shiftid, 
				   @Shiftstartdate, 
				   @Stdinjectionsteps, 
				   @Stdwashsteps, 
				   @Ecolabtextilecategoryid, 
				   @Chaintextilecategoryid, 
				   @Formulasegmentid, 
				   @Ecolabsaturationid, 
				   @Plantprogramid, 
				   @Enddatetime, 
				   @Targetturntime,
				   1
			);
			SELECT 
				   @Batchid = SCOPE_IDENTITY();
			IF NOT EXISTS
						 (SELECT 
								 * FROM TCD.BatchParameters WHERE BatchId = @Batchid
																  AND ParameterID = 38
						 )
				BEGIN
					IF @Stdwashsteps > 0
					   OR @Stdwashsteps <> NULL
						INSERT INTO TCD.BatchParameters
						(
							   BatchId, 
							   EcolabWasherId, 
							   ParameterId, 
							   ParameterValue, 
							   PartitionOn
						)
							   SELECT 
									  @Batchid, 
									  @Ecolabwasherid, 
									  38, 
									  @Stdwashsteps, 
									  @Shiftstartdate;
				END;
		END;
	ELSE
		BEGIN
			UPDATE tcd.BatchData
			  SET 
				  EndDate = @Enddatetime, 
				  EndDateFormula = @Enddatetime, 
				  ProgramNumber = @Programnumber, 
				  ProgramMasterId = @Programmasterid, 
				  ActualWeight = @Load, 
				  ShiftId = @Shiftid, 
				  PartitionOn = @Shiftstartdate, 
				  SyncReady = 1, 
				  StandardWeight = @Nominalload
				WHERE 
					  BatchID = @Batchid;
		END;
	--If the received formula is not configured in enVision then create an alarm 
	IF @Programmasterid IS NULL
		BEGIN
			SELECT 
				   @Ecolabaccountnumber = EcolabAccountNumber FROM TCD.Plant;
			SELECT 
				   @Alarmgroupmasterid = AGM.AlarmGroupMasterId
				FROM TCD.AlarmGroupMsterVsControllerModelType AS AGMVCMT
					 INNER JOIN TCD.AlarmGroupMaster AS AGM ON AGM.AlarmGroupMasterId = AGMVCMT.AlarmGroupMasterId
				WHERE AGMVCMT.AlarmCode = 9000;
			INSERT INTO TCD.AlarmData
			(
				   EcoalabAccountNumber, 
				   AlarmCode, 
				   BatchId, 
				   controllerID, 
				   StartDate, 
				   GroupId, 
				   MachineInternalId, 
				   ProgramId, 
				   IsActive, 
				   EndDate, 
				   MachineId, 
				   AlarmGroupMasterId,
				   PartitionOn
			)
				   SELECT 
						  @Ecolabaccountnumber, 
						  9000, 
						  @Batchid, 
						  @Controllerid, 
						  @Startdatetime, 
						  @Washergroupid, 
						  @Machinenumber, 
						  @Programnumber, 
						  0, 
						  @Startdatetime, 
						  @Washerid, 
						  @Alarmgroupmasterid,
						  @Startdatetime
		END;
	IF NOT EXISTS
				 (SELECT 
						 1
					  FROM TCD.BatchCustomerData
					  WHERE BatchID = @Batchid
							AND @Customernumber IS NOT NULL
				 )
		BEGIN
			INSERT INTO TCD.BatchCustomerData
			(
				   BatchId, 
				   CustomerID, 
				   Weight, 
				   PiecesCount, 
				   PartitionOn, 
				   EcolabWasherId
			)
				   SELECT DISTINCT 
						  Bd.BatchId, 
						  Pc.ID, 
						  @Load, 
						  ROUND(COALESCE((@Load * Pm.Pieces) / NULLIF(Pm.Weight, 0), 0), 0), 
						  (SELECT TOP 1 
								  ShiftStartdate FROM @Shiftmapping
						  ), 
						  @Ecolabwasherid
					   FROM TCD.Washer AS WS
							INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = ws.WasherId
							INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
							INNER JOIN TCD.TunnelProgramSetup AS Tps ON Tps.WasherGroupId = Wg.WasherGroupId
							INNER JOIN TCD.ProgramMaster AS Pm ON Pm.ProgramId = Tps.ProgramId
							INNER JOIN TCD.PlantCustomer AS Pc ON Pc.ID = Pm.CustomerId
							INNER JOIN TCD.BatchData AS Bd ON Bd.MachineId = Ws.WasherId
					   WHERE Ws.WasherId = @Washerid
							 AND Tps.ProgramNumber = @Programnumber
							 AND Bd.BatchId = @Batchid
							 AND Pm.CustomerId != -1
							 AND Pm.Weight > 0;
		END;
	ELSE
	IF @Customernumber > 0
		BEGIN
			UPDATE TCD.BatchCustomerData
			  SET 
				  CustomerID = @Customernumber, 
				  Weight = @Load
				WHERE 
					  BatchID = @Batchid;
		END;
	CREATE TABLE #Dosing
	(
		 equipmentNo INT, 
		 StepNo		 INT, 
		 Qty		 DECIMAL(10, 6)
	);
	INSERT INTO #Dosing
		   SELECT 
				  T.c.value('@Equipment', 'INT'), 
				  T.c.value('@stepNo', 'INT'), 
				  T.c.value('@Qty', 'Decimal(10,6)')
			   FROM @Vxml.nodes('ConventionalWasherData/DosingData/Dosing') AS T(C)
			   WHERE T.c.value('@Qty', 'Decimal(10,6)') > 0;
	CREATE TABLE #StepTime
	(
		 Number	   INT, 
		 [Time]	   INT, 
		 StartTime DATETIME, 
		 EndTime   DATETIME
	);
	INSERT INTO #StepTime
	(
		   Number, 
		   [Time]
	)
		   SELECT 
				  T.c.value('@Number', 'INT'), 
				  T.c.value('@Time', 'INT')
			   FROM @Vxml.nodes('ConventionalWasherData/StepTime/Step') AS T(C);
	CREATE TABLE #TimeStamp
	(
		 Step_Number INT, 
		 Time_Stamp	 INT
	);

	--For Calculating TIME_STAMP
	WITH TempTable
		 AS (SELECT DISTINCT 
					Number FROM #StepTime)
		 INSERT INTO #TimeStamp
		 (
				Step_Number, 
				Time_Stamp
		 )
				SELECT 
					   b.Number, 
					   SUM(t.Time) AS Time_Stamp
					FROM TempTable AS b
						 INNER JOIN #StepTime AS t ON b.Number >= t.Number
					GROUP BY 
							 b.Number;
	CREATE TABLE #BatchProductData
	(
		 equipmentNo INT, 
		 StepNo		 INT, 
		 Qty		 DECIMAL(10, 6), 
		 Time_Stamp	 DATETIME2(7), 
		 ProductId	 INT, 
		 Row_No		 INT
	);
	INSERT INTO #BatchProductData
	(
		   EquipmentNo, 
		   StepNo, 
		   Qty, 
		   Time_Stamp, 
		   ProductId, 
		   Row_No
	)
		   SELECT 
				  d.equipmentNo, 
				  d.StepNo,
				  CASE
					  WHEN d.equipmentNo = 9
						   OR d.equipmentNo = 10
					  THEN d.Qty * 16
					  ELSE d.Qty
				  END, 
				  DATEADD(ss, ts.Time_Stamp, @Startdatetime), 
				  ces.ProductId, 
				  ROW_NUMBER() OVER(ORDER BY d.StepNo DESC) AS Row
			   FROM #Dosing AS d
					INNER JOIN #TimeStamp AS ts ON d.StepNo = ts.Step_Number
					INNER JOIN tcd.ControllerEquipmentSetup AS ces ON ces.ControllerEquipmentId = d.equipmentNo
			   WHERE d.equipmentNo > 0
					 AND d.Qty > 0
					 AND ControllerID = @Controllerid
					 AND ces.ProductId IS NOT NULL;
	SELECT 
		   @Maxwashertgroupcapacity = MAX(ws.MaxLoad)
		FROM TCD.Washer AS WS
			 INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = ws.WasherId
			 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
		WHERE Mst.GroupId = @Washergroupid;
	DECLARE @Counter INT;
	SET @Counter = 1;
	WHILE @Counter <=
					  (SELECT 
							  COUNT(ROW_No) FROM #BatchProductData AS bpd
					  )
		BEGIN
			SELECT 
				   @Stepno = bpd.StepNo, 
				   @Quantity = bpd.Qty, 
				   @Productid = bpd.ProductId, 
				   @Timestamp = bpd.Time_Stamp
				FROM #BatchProductData AS bpd
				WHERE bpd.Row_No = @Counter
				ORDER BY 
						 bpd.StepNo;
			SELECT 
				   @Injectionnumber = Wdpm.InjectionNumber, 
				   @Standardqty = ((@Nominalload / CONVERT( DECIMAL(10, 2), 100)) * Wdpm.Quantity * Ws.MaxLoad) / CONVERT(DECIMAL(10, 2), 100), 
				   @Price = ((@Nominalload / CONVERT(		DECIMAL(10, 2), 100)) * Wdpm.Quantity * @Maxwashertgroupcapacity) / CONVERT(DECIMAL(
				   10, 2), 100) * tcd.FnChemicalCostInOunce(Pdm.ProductID)
				FROM TCD.Washer AS WS
					 INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = ws.WasherId
					 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
					 INNER JOIN TCD.WasherGroupType AS WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
					 INNER JOIN TCD.WasherProgramSetup AS Wps ON Wps.ControllerID = Wg.ControllerId
					 INNER JOIN TCD.WasherDosingSetup AS Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
					 INNER JOIN TCD.WasherDosingProductMapping AS Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
					 INNER JOIN TCD.ProductdataMapping AS Pdm ON Pdm.ProductId = Wdpm.ProductId
					 INNER JOIN TCD.BatchData AS Bd ON Bd.MachineId = Ws.WasherId
				WHERE Ws.WasherId = @Washerid
					  AND Wps.ProgramNumber = @Programnumber
					  --AND Wdpm.InjectionNumber = @stepno
					  AND Bd.BatchId = @Batchid
					  AND Wps.Is_Deleted = 0
					  AND Pdm.Is_Deleted = 0;
			INSERT INTO TCD.BatchProductData
			(
				   BatchId, 
				   StepCompartment, 
				   ActualQuantity, 
				   StandardQuantity, 
				   Price, 
				   PartitionOn, 
				   EcolabWasherId, 
				   ProductId, 
				   TimeStamp, 
				   InjectionNumber
			)
			VALUES
			(
				   @Batchid, 
				   @Stepno, 
				   @Quantity, 
				   ISNULL(@Standardqty, 0), 
				   ISNULL(@Price, 0), 
				   @Shiftstartdate, 
				   @Ecolabwasherid, 
				   @Productid, 
				   @Timestamp, 
				   @Injectionnumber
			);
			SET @Counter = @Counter + 1;
		END;

--BatchStatus parametr insertion start
	SELECT DISTINCT 
		@TotalInjectsCountFromUI = COUNT(1)
	FROM TCD.Washer AS WS
			INNER JOIN TCD.MachineSetup AS Ms ON ms.WasherId = ws.WasherId
			INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = ms.GroupId
			INNER JOIN TCD.WasherGroupType AS WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
			INNER JOIN TCD.WasherProgramSetup AS Wps ON Wps.ControllerID = Wg.ControllerId
			INNER JOIN TCD.WasherDosingSetup AS Wds ON Wds.WasherProgramSetupId = Wps.WasherProgramSetupId
			INNER JOIN TCD.WasherDosingProductMapping AS Wdpm ON Wdpm.WasherDosingSetupId = Wds.WasherDosingSetupID
	WHERE Wds.Is_Deleted = 0
			AND Wdpm.IsDeleted = 0
			AND ms.IsTunnel = 0
			AND ms.GroupId = @Washergroupid
			AND ms.WasherId = @Washerid
			AND ms.ControllerId = @Controllerid
			And ms.IsDeleted = 0

		SELECT @TotalInjectsCountFromPLC=Count(*) FROM TCD.BatchProductData bpd WHERE bpd.BatchId=@Batchid
					
	IF NOT EXISTS
				(SELECT 
						* FROM TCD.BatchParameters WHERE BatchId = @Batchid
														AND ParameterID = 18
				)
	BEGIN
			INSERT INTO TCD.BatchParameters
			(
					BatchId, 
					EcolabWasherId, 
					ParameterId, 
					ParameterValue, 
					PartitionOn
			)
					SELECT 
							@Batchid, 
							@Ecolabwasherid, 
							18, 
							CASE WHEN @TotalInjectsCountFromUI=@TotalInjectsCountFromPLC THEN 1
							WHEN @TotalInjectsCountFromUI<>@TotalInjectsCountFromPLC THEN 3 END,
							@Shiftstartdate;
	END;
	--BatchStatus parametr insertion end
				
	IF NOT EXISTS
				 (SELECT 
						 * FROM TCD.BatchParameters WHERE ParameterId = 41
														  AND batchid = @Batchid
				 )
		BEGIN
			INSERT INTO Tcd.BatchParameters
			(
				   BatchId, 
				   EcolabWasherId, 
				   ParameterId, 
				   ParameterValue, 
				   PartitionOn
			)
				   SELECT 
						  @Batchid, 
						  @Ecolabwasherid, 
						  41,
						  CASE
							  WHEN SUM(bpd.ActualQuantity) = SUM(bpd.StandardQuantity)
							  THEN 1		--'Approved'
							  WHEN SUM(bpd.ActualQuantity) <> SUM(bpd.StandardQuantity)
							  THEN 2		--'Rejected'
							  ELSE 1		--'Approved'
						  END, 
						  @Shiftstartdate
					   FROM TCD.BatchProductData AS bpd
					   WHERE bpd.BatchId = @Batchid;
		END;
	--END For calculating TIMESTAMP
	--Start Updating InjectionCount in TCD.BatchParameters if  record is available with ParameterId and batchid else insert new record
	SELECT 
		   @Actualinjsteps = COUNT(DISTINCT StepNo) FROM #Dosing WHERE StepNo > 0;
	IF NOT EXISTS
				 (SELECT 
						 *
					  FROM TCD.BatchParameters
					  WHERE ParameterId = 37
							AND batchid = @Batchid
							AND @Actualinjsteps > 0
				 )
		BEGIN
			IF ISNULL(@Actualinjsteps, 0) > 0
				BEGIN
					INSERT INTO TCD.BatchParameters
					(
						   BatchId, 
						   EcolabWasherId, 
						   ParameterId, 
						   ParameterValue, 
						   PartitionOn
					)
						   SELECT 
								  @Batchid, 
								  @Ecolabwasherid, 
								  37, 
								  @Actualinjsteps, 
								  @Shiftstartdate;
				END;
		END;
	SELECT 
		   @Laststep = MAX(Number) FROM #StepTime WHERE [Time] > 0;
	SELECT 
		   @Currentstep = 1, 
		   @Currentsteptime = @Startdatetime;
	WHILE @Currentstep <= @Laststep
		BEGIN
			UPDATE #StepTime
			  SET 
				  StartTime = @Currentsteptime, 
				  EndTime = DATEADD(ss, [time], @Currentsteptime)
				WHERE 
					  Number = @Currentstep;
			SELECT 
				   @Currentsteptime = EndTime FROM #StepTime WHERE Number = @Currentstep;
			SELECT 
				   @Currentstep = @Currentstep + 1;
		END;
	INSERT INTO TCD.BatchWashStepData
	(
		   BatchID, 
		   StepCompartment, 
		   StartTime, 
		   EndTime, 
		   PartitionOn, 
		   EcolabWasherId
	)
		   SELECT 
				  @Batchid, 
				  Number, 
				  StartTime, 
				  EndTime, 
				  @Shiftstartdate, 
				  @Ecolabwasherid
			   FROM #StepTime
			   WHERE Number <= @Laststep;
	SELECT 
		   @Mintempparamid = Id FROM TCD.ConduitParameters WHERE Name = 'Mimum Temperature';
	SELECT 
		   @Maxtempparamid = Id
		FROM TCD.ConduitParameters
		WHERE Name = 'Maximum Temperature';
	SELECT 
		   @Phvalueparamid = ID FROM TCD.ConduitParameters WHERE Name = 'PH';
	IF NOT EXISTS
				 (SELECT 
						 *
					  FROM TCD.BatchParameters
					  WHERE BatchId = @Batchid
							AND ParameterID = @Mintempparamid
				 )
		BEGIN
			IF @Temperaturemin <> 0
			   OR @Temperaturemin <> NULL
				BEGIN
					INSERT INTO TCD.BatchParameters
					(
						   BatchId, 
						   EcolabWasherId, 
						   ParameterId, 
						   ParameterValue, 
						   PartitionOn
					)
					VALUES
					(
						   @Batchid, 
						   @Ecolabwasherid, 
						   @Mintempparamid, 
						   @Temperaturemin, 
						   @Shiftstartdate
					);
				END;
		END;
	IF NOT EXISTS
				 (SELECT 
						 *
					  FROM TCD.BatchParameters
					  WHERE BatchId = @Batchid
							AND ParameterID = @Maxtempparamid
				 )
		BEGIN
			IF @Temperaturemax <> 0
			   OR @Temperaturemax <> NULL
				BEGIN
					INSERT INTO TCD.BatchParameters
					(
						   BatchId, 
						   EcolabWasherId, 
						   ParameterId, 
						   ParameterValue, 
						   PartitionOn
					)
					VALUES
					(
						   @Batchid, 
						   @Ecolabwasherid, 
						   @Maxtempparamid, 
						   @Temperaturemax, 
						   @Shiftstartdate
					);
				END;
		END;
	IF @Phvalue <> 0
	   OR @Phvalue <> NULL
		BEGIN
			INSERT INTO TCD.BatchParameters
			(
				   BatchId, 
				   EcolabWasherId, 
				   ParameterId, 
				   ParameterValue, 
				   PartitionOn
			)
			VALUES
			(
				   @Batchid, 
				   @Ecolabwasherid, 
				   @Phvalueparamid, 
				   @Phvalue, 
				   @Shiftstartdate
			);
		END;
	EXEC TCD.ProcessMyControlProductionWaterConsumptionData 
		 @Batchid, 
		 @Vxml, 
		 @Shiftstartdate;
	DROP TABLE #BatchProductData;
	DROP TABLE #Dosing;
	DROP TABLE #StepTime;
	DROP TABLE #TimeStamp;
END;
