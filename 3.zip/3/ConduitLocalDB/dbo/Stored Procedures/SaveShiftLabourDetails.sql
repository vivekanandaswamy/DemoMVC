﻿/*      
 ==========================================================================================      
 Purpose:  INSERTING THE PLANT SHIFT LABOUR DATA  
    
 Author: PREMCHAND YELAVARTHI

    
 --------------------------------------------------------------      
 Sep-11-2014 ENT: Initial version.      
 ==========================================================================================   
*/
CREATE PROCEDURE [TCD].[SaveShiftLabourDetails] (
				@ShiftId int,
				@DayId int = NULL,
				@LaborHours Int = NULL,
				@PricePerHr decimal(18,2) = NULL,
				@LaborTypeId Int = NULL,
				@LaborCount Int = NULL,
				@locationId Int = NULL,
				@EcolabAccountNumber NVarchar(25),
				@UserID INT = NULL,
				@Scope varchar(100) OUTPUT
				--Adding these 2 params as part of re-factoring for integration with Synch/Configurator
			,	@OutputShiftLaborDataId				INT					=			NULL	OUTPUT
			,	@OutputLastModifiedTimestampAtLocal	DATETIME			=			NULL	OUTPUT
			) 
AS 
SET NOCOUNT ON
  BEGIN
  DECLARE @OutPut VARCHAR(50) = ''

DECLARE	@CurrentUTCTime						DATETIME		=			GETUTCDATE()
--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
SET		@OutputLastModifiedTimestampAtLocal					=			@CurrentUTCTime
SET		@Scope					=				ISNULL(@Scope, NULL)			--SQLEnlight SA0121

DECLARE
		@OutputList					AS	TABLE		(
		ShiftLaborDataId				INT
	,	LastModifiedTimestamp			DATETIME
	)

  BEGIN
      /*INSERTING THE DATA FOR SHIFT LABOUR DATA*/
	  IF NOT EXISTS(SELECT 1 FROM [TCD].ShiftLaborData 
					WHERE LaborTypeId = @LaborTypeId 
						 AND LocationId = @locationId
						 AND IS_Deleted <> 1
						 AND ShiftId = @ShiftId)
		BEGIN
				INSERT INTO [TCD].ShiftLaborData(
									ShiftId
									,DayId
									,LaborHours
									,PricePerHr
									,LaborTypeId
									,LocationId
									,EcolabAccountNumber
									 ,LastModifiedByUserId
									 ,LastModifiedTime
							)
					--**	Adding as part of re-factor for integration with Synch./Central 
					OUTPUT
						inserted.LaborId				AS			ShiftLaborDataId
					,	inserted.LastModifiedTime		AS			LastModifiedTimestamp
					INTO
						@OutputList	(
						ShiftLaborDataId
					,	LastModifiedTimestamp
					)	--**
							VALUES(
										@ShiftId
										,@DayId
										,@LaborHours
										,@PricePerHr
										,@LaborTypeId
										,@locationId
										,@EcolabAccountNumber
										,@UserID
										,@CurrentUTCTime
									)

   
				 SET @OutPut = '101'     
				 SET @Scope = @OutPut SELECT @Scope  
	 END
	 ELSE
	 BEGIN 
			 SET @OutPut = '301'     
     SET @Scope = @OutPut SELECT @Scope  
	 END 

SELECT	TOP 1	
		@OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp
	,	@OutputShiftLaborDataId				=	O.ShiftLaborDataId
FROM	@OutputList							O

   END
   END