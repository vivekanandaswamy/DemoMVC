﻿/*

Stored Procedure	:	[TCD].[GetTunnelCompartmentEquipmentAssociation]

Purpose				:	To get equipment association details for a Tunnel's compartment

Parameters			:	@EcolabAccountNumber					--	EcoLab Plant Id
						@TunnelCompartmentId					--	Id of Compartment in TunnelCompartment table
*/

CREATE	PROCEDURE	[TCD].[GetTunnelCompartmentEquipmentAssociation]
					@EcolabAccountNumber					NVARCHAR(25)
				,	@TunnelCompartmentId					INT			=			NULL	--To be set, if details sought for a particular TC, else NULL
AS
BEGIN


SET	NOCOUNT	ON


SELECT	TCEM.EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	TCEM.ControllerEquipmentSetupId			AS			ControllerEquipmentSetupId
	,	TCEM.Is_Deleted							AS			Is_Deleted
FROM	TCD.TunnelCompartmentEquipmentMapping	TCEM
WHERE	TCEM.EcoLabAccountNumber				=			@EcolabAccountNumber
	AND	TCEM.TunnelCompartmentId				=			@TunnelCompartmentId


SET	NOCOUNT	OFF


END
