﻿CREATE PROCEDURE [TCD].[IsControllerSetupAdvanceDataExist]
(
		@TabId INT
	,	@ControllerId INT
	,	@EcolabAccountNumber NVARCHAR(25)
)
AS
BEGIN
SET NOCOUNT ON
	DECLARE @IsTrue BIT = NULL    
	IF EXISTS(SELECT 1 FROM [TCD].ControllerSetupData CSD
				INNER JOIN [TCD].FieldGroup FG on FG.Id = CSD.FieldGroupId
				WHERE 
				CSD.ControllerId = @ControllerId 
				AND 
				FG.TabId = @TabId
				AND
				CSD.EcolabAccountNumber = @EcolabAccountNumber
			)
		SET @IsTrue = 1
	ELSE
		SET @IsTrue = 0

	SELECT @IsTrue
SET NOCOUNT OFF
END