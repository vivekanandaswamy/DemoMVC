﻿CREATE PROCEDURE TCD.GenerateShiftData(@EcolabAccountNumber nvarchar(25))
AS
BEGIN
IF NOT EXISTS (SELECT 1 FROM TCD.ShiftData sd WHERE sd.ShiftName = N'Full Day Shift' AND sd.DayId = 1)
BEGIN
	INSERT INTO TCD.SHIFTDATA
	Select 'Full Day Shift',1,'00:00:00.0000000','23:59:59.0000000','0',0,@EcolabAccountNumber,1,GetDate(),NULL,0
END
IF NOT EXISTS (SELECT 1 FROM TCD.ShiftData sd WHERE sd.ShiftName = N'Full Day Shift' AND sd.DayId = 2)
BEGIN
	INSERT INTO TCD.SHIFTDATA
	Select 'Full Day Shift',2,'00:00:00.0000000','23:59:59.0000000','0',0,@EcolabAccountNumber,1,GetDate(),NULL,0
END
IF NOT EXISTS (SELECT 1 FROM TCD.ShiftData sd WHERE sd.ShiftName = N'Full Day Shift' AND sd.DayId = 3)
BEGIN
	INSERT INTO TCD.SHIFTDATA
	Select 'Full Day Shift',3,'00:00:00.0000000','23:59:59.0000000','0',0,@EcolabAccountNumber,1,GetDate(),NULL,0
END
IF NOT EXISTS (SELECT 1 FROM TCD.ShiftData sd WHERE sd.ShiftName = N'Full Day Shift' AND sd.DayId = 4)
BEGIN
	INSERT INTO TCD.SHIFTDATA
	Select 'Full Day Shift',4,'00:00:00.0000000','23:59:59.0000000','0',0,@EcolabAccountNumber,1,GetDate(),NULL,0
END
IF NOT EXISTS (SELECT 1 FROM TCD.ShiftData sd WHERE sd.ShiftName = N'Full Day Shift' AND sd.DayId = 5)
BEGIN
	INSERT INTO TCD.SHIFTDATA
	Select 'Full Day Shift',5,'00:00:00.0000000','23:59:59.0000000','0',0,@EcolabAccountNumber,1,GetDate(),NULL,0
END
IF NOT EXISTS (SELECT 1 FROM TCD.ShiftData sd WHERE sd.ShiftName = N'Full Day Shift' AND sd.DayId = 6)
BEGIN
	INSERT INTO TCD.SHIFTDATA
	Select 'Full Day Shift',6,'00:00:00.0000000','23:59:59.0000000','0',0,@EcolabAccountNumber,1,GetDate(),NULL,0
END
IF NOT EXISTS (SELECT 1 FROM TCD.ShiftData sd WHERE sd.ShiftName = N'Full Day Shift' AND sd.DayId = 7)
BEGIN
	INSERT INTO TCD.SHIFTDATA
	Select 'Full Day Shift',7,'00:00:00.0000000','23:59:59.0000000','0',0,@EcolabAccountNumber,1,GetDate(),NULL,0
END
END