﻿/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_SaveWasherDosingProduct]                                             

Purpose:				To save the washer doing product

Parameters:				@EcoLabAccountNumber - holds ecolab account number.
						@WasherDosingSetupId - holds the washer dosing setup id.
						@InjectionNumber - holds the injection number.
						@ProductId - holds the product id.
						@Quantity - Holds the quantity of product.
						@DeleteFlag - holds the boolean value for delete.
						@UserId - holds the user id.
										
###################################################################################################                                           
*/
CREATE	PROCEDURE	[TCD].[SaveWasherDosingProduct]	(
@EcoLabAccountNumber					NVARCHAR(25)
,	@WasherDosingSetupId					INT
,	@ProgramSetupId							INT
,	@InjectionNumber						SMALLINT	=			NULL
,	@ProductId								INT			=			NULL
,	@Quantity								DECIMAL(18,2)=			NULL
,	@IsDeleted								BIT			=			'FALSE'	--DO NOT SET THIS (to TRUE) UNLESS DELETE IS INTENDED
,	@UserId									INT			=			NULL
,	@LastModifiedTimestampAtCentral			DATETIME					=	NULL
,	@MyServiceFrmulaStpDsgDvcGuid			UNIQUEIDENTIFIER	=		NULL
,   @WasherDosingProductMapId				INT						=	NULL
,	@Delay									SMALLINT				=	NULL
,	@ControllerEquipmentSetupId				SMALLINT				=	NULL
)
AS
BEGIN

SET	NOCOUNT	ON

DECLARE
@ReturnValue					INT					=			0
,	@ErrorId						INT					=			0
,	@ErrorMessage					NVARCHAR(4000)		=			N''
,	@CurrentUTCTime					DATETIME			=			GETUTCDATE()
,   @trackasdosingstep	bit
,	@Productcount		INT	= 0

SET	@LastModifiedTimestampAtCentral						=			ISNULL(@LastModifiedTimestampAtCentral, NULL)				--SQLEnlight SA0029

IF @ControllerEquipmentSetupId = 0
BEGIN
	SET @ControllerEquipmentSetupId = NULL
END

IF	NOT	EXISTS (SELECT	1
FROM	[TCD].WasherDosingProductMapping
WHERE	WasherDosingSetupId			=			@WasherDosingSetupId
AND	ProductId					=			@ProductId
AND WasherDosingProductMappingId = @WasherDosingProductMapId
AND EcoLabAccountNumber=@EcoLabAccountNumber
)
BEGIN

IF @IsDeleted = 'False'
BEGIN
-- For setting the next available injection number.
DECLARE @AvailableInjectionNumber int
DECLARE @WasherDosingProductMappingId INT

INSERT INTO	[TCD].WasherDosingProductMapping (
EcoLabAccountNumber
,	WasherDosingSetupId
,	InjectionNumber
,	ProductId
,	Quantity
,	LastModifiedByuserId
,	MyServiceFrmulaStpDsgDvcGuid
,	IsDeleted
,	[Delay]
,	[ControllerEquipmentSetupId]
)

SELECT
@EcoLabAccountNumber			AS			EcoLabAccountNumber
,	@WasherDosingSetupId			AS			WasherDosingSetupId
,	@InjectionNumber				AS			InjectionNumber
,	@ProductId						AS			ProductId
,	@Quantity						AS			Quantity
,	@UserId							AS			UserId
,	@MyServiceFrmulaStpDsgDvcGuid	AS			MyServiceFrmulaStpDsgDvcGuid
,	@IsDeleted						AS			IsDeleted
,	@Delay							AS			[Delay]
,	@ControllerEquipmentSetupId		AS			ControllerEquipmentSetupId


SET @WasherDosingProductMappingId=SCOPE_IDENTITY()

IF @InjectionNumber = 0 AND (SELECT COUNT(WasherDosingSetupId) FROM [TCD].WasherDosingProductMapping WHERE WasherDosingSetupId=@WasherDosingSetupId AND IsDeleted<>'True' AND InjectionNumber<>0)=0
BEGIN
SELECT @AvailableInjectionNumber= MAX(wdpm.InjectionNumber)+1 FROM TCD.WasherDosingProductMapping wdpm INNER JOIN TCD.WasherDosingSetup wds
ON wds.WasherDosingSetupId = wdpm.WasherDosingSetupId
WHERE  wds.WasherProgramSetupId = @ProgramSetupId AND wdpm.EcoLabAccountNumber=@EcoLabAccountNumber --AND wdpm.IsDeleted='False'
END
ELSE
BEGIN
SELECT TOP 1 @AvailableInjectionNumber= wdpm.InjectionNumber FROM TCD.WasherDosingProductMapping wdpm WHERE WasherDosingSetupId=@WasherDosingSetupId
END


IF @AvailableInjectionNumber>0
BEGIN
UPDATE TCD.WasherDosingProductMapping
SET	   InjectionNumber=@AvailableInjectionNumber
WHERE   WasherDosingProductMappingId=@WasherDosingProductMappingId
END






--check for any error
SET	@ErrorId	=	@@ERROR

IF	(@ErrorId	<>	0)
BEGIN
SET		@ErrorMessage			=			N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred overswriting wash step PRODUCT data.'
--GOTO	Errorhandler
RAISERROR	(@ErrorMessage, 16, 1)
SET	@ReturnValue	=	-1
RETURN	(@ReturnValue)
END
END
END
ELSE
BEGIN
-- UPDate

UPDATE [TCD].WasherDosingProductMapping
SET
InjectionNumber					=		@InjectionNumber
,	ProductId						=		@ProductId
,	Quantity						=		@Quantity
,	LastModifiedByuserId			=		@UserId
,	IsDeleted						=		@IsDeleted
,	[Delay]							=		@Delay
,	LastModifiedTime				=		GETUTCDATE()
,	ControllerEquipmentSetupId		=		@ControllerEquipmentSetupId
WHERE   WasherDosingSetupId				=		@WasherDosingSetupId
AND		EcolabAccountNumber				=		@EcolabAccountNumber
AND		WasherDosingProductMappingId	=		@WasherDosingProductMapId
AND		IsDeleted						=		0



END

select @trackasdosingstep = TrackAsDosingStep from TCD.WasherDosingSetup WHERE WasherDosingSetupId = @WasherDosingSetupId
SELECT	@Productcount = COUNT(*) FROM	[TCD].WasherDosingProductMapping WHERE	WasherDosingSetupId	=@WasherDosingSetupId AND ProductId	!= 1 AND EcoLabAccountNumber=@EcoLabAccountNumber AND IsDeleted = 0
	IF((@trackasdosingstep = 1 AND  @Productcount > 0) OR @trackasdosingstep = 0)
		BEGIN
		UPDATE [TCD].WasherDosingProductMapping SET IsDeleted= 1 WHERE WasherDosingSetupId = @WasherDosingSetupId AND ProductId = 1 AND EcoLabAccountNumber=@EcoLabAccountNumber
		END
	IF(@trackasdosingstep = 1 AND @Productcount = 0)
		BEGIN
		UPDATE [TCD].WasherDosingProductMapping SET IsDeleted= 0 WHERE WasherDosingSetupId = @WasherDosingSetupId AND ProductId = 1 AND EcoLabAccountNumber=@EcoLabAccountNumber
		END

-- For Reording the washer injection based on the update or insert of the productdosing for the washer.
EXEC [TCD].[WasherInjectionOrdering] @ProgramSetupId,@EcolabAccountNumber




IF	(	@ErrorId	=	0	)
BEGIN
--GOTO	ExitModule
RETURN	(@ReturnValue)
END


--ErrorHandler:
--RAISERROR	(@ErrorMessage, 16, 1)
--SET	@ReturnValue	=	-1


--ExitModule:

SET	NOCOUNT	OFF
RETURN	(@ReturnValue)


END