﻿/*	                                   
###################################################################################################                                           

Stored Procedure:       [TCD].[GetBatchData]                                            

Purpose:				To Get The Batch Data.

Parameters:				None
																
###################################################################################################                                           
*/
CREATE PROCEDURE [TCD].[GetBatchData] 
	-- Add the parameters for the stored procedure here
	
AS
BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
    -- Insert statements for procedure here
	SELECT BD.BatchID,BD.ControllerBatchId,BD.EcoalabAccountNumber,BD.GroupId,BD.MachineInternalId,BD.StartDate,BD.EndDate,BD.ProgramNumber,BD.ActualWeight,BD.StandardWeight,BD.CurrencyTypeId,BD.LastSyncTime
	
	 FROM dbo.BatchData BD --INNER JOIN dbo.BatchCustomerData BCD ON BD.BatchID=BCD.BatchId
	--INNER JOIN dbo.BatchProductData BPD ON BD.BatchID=BPD.BatchID
	--INNER JOIN dbo.BatchWashStepData BWSD ON BD.BatchID=BWSD.BatchId
	--INNER JOIN dbo.BatchStepWaterUsageData BSWU ON BWSD.BatchWashStepId=BSWU.BatchWashStepId
	WHERE BD.EndDate IS NOT NULL AND BD.LastSyncTime IS NULL
END