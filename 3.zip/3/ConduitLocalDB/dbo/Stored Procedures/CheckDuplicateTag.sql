/* 
			Parameters
			@TagAddress		- Tag address to check duplication
			@ControllerId	-	Controller Id on which the duplicate check has to be done
			@Id				- Id of either meter or sensor or tank or pump or washer or controller
			@Type			-	1	-	Storage Tank
								2	-	Meter
								3	-	Sensor
								4	-	Pumps & Valves
								11	-	Washers
								12	-	Controllers								
 */

CREATE	PROCEDURE	[TCD].[CheckDuplicateTag]	(
					@TagAddress					VARCHAR(200)
				,	@ControllerId				INT
				,	@Id							INT				=	NULL
				,	@Type						INT				=	NULL
				,	@EcolabAccountNumber		VARCHAR(25)	=	NULL
				)
AS
BEGIN																		
SET NOCOUNT ON												

SET		@EcolabAccountNumber			=			ISNULL(@EcolabAccountNumber, NULL)			--SQLEnlight SA0029

IF(@Type IS NULL OR @Type = 1 OR @Type = 2 OR @Type = 3 OR @Type = 4)
	BEGIN
			IF(	(	SELECT		COUNT(1)
					FROM		TCD.ModuleTags					MT
					LEFT JOIN	TCD.TankSetup					TS
						ON		MT.ModuleID						=			TS.TankId 
						AND		MT.ModuleTypeId					=			1
					LEFT JOIN	TCD.Meter						M
						ON		MT.ModuleID						=			M.MeterId 
						AND		MT.ModuleTypeId					=			2
					LEFT JOIN	TCD.Sensor						S
						ON		MT.ModuleID						=			S.SensorId 
						AND		MT.ModuleTypeId					=			3
					LEFT JOIN	TCD.ControllerEquipmentSetup	CES 
						ON		MT.ModuleID						=			CES.ControllerEquipmentSetupId 
						AND		MT.ModuleTypeId					=			4
					LEFT JOIN	TCD.ConduitController			CC 
						ON		M.ControllerId					=			CC.ControllerId
							OR	S.ControllerId					=			CC.ControllerId 
							OR	TS.ControllerId					=			CC.ControllerId 
							OR	CES.ControllerId				=			CC.ControllerId
					WHERE		(	M.ControllerId				=			@ControllerId 
									OR
									S.ControllerId				=			@ControllerId 
									OR
									TS.ControllerId				=			@ControllerId 
									OR
									CES.ControllerId			=			@ControllerId
								)
						AND		MT.Active						=			1 
						AND		MT.TagAddress					=			@TagAddress
						AND		(	(	@Id						IS NULL 
										AND
										@Type					IS NULL
									)
									OR
									(	@Id						!=			CASE	WHEN @Type = 1 THEN ISNULL(TS.TankId,'')
																					WHEN @Type = 2 THEN ISNULL(M.MeterId,'')
																					WHEN @Type = 3 THEN ISNULL(S.SensorId,'')
																					WHEN @Type = 4 THEN ISNULL(CES.ControllerEquipmentSetupId,'')
																			END
									)
								)
				)
				>	0
			)

			RETURN (0);


			IF(	(	SELECT		COUNT(1)
					FROM		TCD.WasherTags					WT
					LEFT JOIN	TCD.MachineSetup				MS 
						ON		MS.WasherId						=			WT.WasherId
					WHERE		MS.ControllerId					=			@ControllerId 
						AND		WT.TagAddress					=			@TagAddress 
						AND		MS.IsDeleted					=			0 
						AND		WT.Active = 1
				)
				>	0
			)

			RETURN (0);


			IF(	(	SELECT		COUNT(1)
					FROM		TCD.ControllerTags				CT
					LEFT JOIN	TCD.ConduitController			CC 
						ON		CT.ControllerID					=			CC.ControllerId
					WHERE		CC.ControllerId					=			@ControllerId 
						AND		CT.TagAddress					=			@TagAddress 
						AND		CC.IsDeleted					=			0 
						AND		CT.Active						=			1
				)
				>	0
			)

			RETURN (0);

	END
ELSE IF(@Type IS NULL OR @Type = 11)
	BEGIN
			IF(	(	SELECT		COUNT(1)
					FROM		TCD.ModuleTags					MT
					LEFT JOIN	TCD.TankSetup					TS 
						ON		MT.ModuleID						=			TS.TankId 
						AND		MT.ModuleTypeId					=			1
					LEFT JOIN	TCD.Meter						M 
						ON		MT.ModuleID						=			M.MeterId 
						AND		MT.ModuleTypeId					=			2
					LEFT JOIN	TCD.Sensor						S 
						ON		MT.ModuleID						=			S.SensorId 
						AND		MT.ModuleTypeId					=			3
					LEFT JOIN	TCD.ControllerEquipmentSetup	CES 
						ON		MT.ModuleID						=			CES.ControllerEquipmentId 
						AND		MT.ModuleTypeId					=			4
					LEFT JOIN	TCD.ConduitController			CC 
						ON		M.ControllerId					=			CC.ControllerId 
							OR	S.ControllerId					=			CC.ControllerId 
							OR	TS.ControllerId					=			CC.ControllerId 
							OR	CES.ControllerId				=			CC.ControllerId
					WHERE		(	M.ControllerId				=			@ControllerId 
									OR 
									S.ControllerId				=			@ControllerId 
									OR 
									TS.ControllerId				=			@ControllerId 
									OR 
									CES.ControllerId			= @ControllerId
								)
						AND		MT.Active						=			1 
						AND		MT.TagAddress					=			@TagAddress
				)
				>	0
			)

			RETURN (0);


			IF(	(	SELECT		COUNT(1) 
					FROM		TCD.WasherTags					WT
					LEFT JOIN	TCD.MachineSetup				MS 
						ON		MS.WasherId						=			WT.WasherId
					WHERE		MS.ControllerId					=			@ControllerId 
						AND		WT.TagAddress					=			@TagAddress 
						AND		MS.IsDeleted					=			0 
						AND		WT.Active						=			1 
						AND		(	(	@Id						IS NULL 
										AND
										@Type					IS NULL
									)
									OR
									WT.WasherId					!=			@Id
								)
				)
				>	0
			)

			RETURN (0);


			IF(	(	SELECT		COUNT(1) 
					FROM		TCD.ControllerTags				CT
					LEFT JOIN	TCD.ConduitController			CC 
						ON		CT.ControllerID					=			CC.ControllerId
					WHERE		CC.ControllerId					=			@ControllerId 
						AND		CT.TagAddress					=			@TagAddress 
						AND		CC.IsDeleted					=			0 
						AND		CT.Active						=			1
				)
				>	0
			)

			RETURN (0);
	END
ELSE IF(@Type IS NULL OR @Type = 12)
	BEGIN
			IF(	(	SELECT		COUNT(1) 
					FROM		TCD.ModuleTags					MT
					LEFT JOIN	TCD.TankSetup					TS 
						ON		MT.ModuleID						=			TS.TankId 
						AND		MT.ModuleTypeId					=			1
					LEFT JOIN	TCD.Meter						M 
						ON		MT.ModuleID						=			M.MeterId 
						AND		MT.ModuleTypeId					=			2
					LEFT JOIN	TCD.Sensor						S 
						ON		MT.ModuleID						=			S.SensorId 
						AND		MT.ModuleTypeId					=			3
					LEFT JOIN	TCD.ControllerEquipmentSetup	CES 
						ON		MT.ModuleID						=			CES.ControllerEquipmentId 
						AND		MT.ModuleTypeId					=			4
					LEFT JOIN	TCD.ConduitController			CC 
						ON		M.ControllerId					=			CC.ControllerId 
							OR	S.ControllerId					=			CC.ControllerId 
							OR	TS.ControllerId					=			CC.ControllerId 
							OR	CES.ControllerId				=			CC.ControllerId
					WHERE		(	M.ControllerId				=			@ControllerId
									OR 
									S.ControllerId				=			@ControllerId 
									OR 
									TS.ControllerId				=			@ControllerId 
									OR
									CES.ControllerId			=			@ControllerId
								)
						AND	MT.Active							=			1 
						AND MT.TagAddress						=			@TagAddress
				)
				>	0
			)

			RETURN (0);


			IF(	(	SELECT		COUNT(1) 
					FROM		TCD.WasherTags					WT
					LEFT JOIN	TCD.MachineSetup				MS 
						ON		MS.WasherId						=			WT.WasherId
					WHERE		MS.ControllerId					=			@ControllerId 
						AND		WT.TagAddress					=			@TagAddress 
						AND		MS.IsDeleted					=			0 
						AND		WT.Active = 1
				)
				>	0
			)

			RETURN (0);


			IF(	(	SELECT		COUNT(1) 
					FROM		TCD.ControllerTags				CT
					LEFT JOIN	TCD.ConduitController			CC 
						ON		CT.ControllerID					=			CC.ControllerId
					WHERE		CC.ControllerId					=			@ControllerId 
						AND		CT.TagAddress					=			@TagAddress 
						AND		CC.IsDeleted					=			0 
						AND		CT.Active						=			1 
						AND		(	(@Id						IS			NULL
									AND
									@Type						IS NULL
									)
									OR
									CT.ControllerID				!=			@Id
								)
				)
				>	0
			)

			RETURN (0);
END


RETURN (1);

--SET NOCOUNT OFF;
END
