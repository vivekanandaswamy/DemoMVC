﻿CREATE PROCEDURE [TCD].[ProcessAllenBradleyArrayQueue]
 ( 
 @Controllerid INT
      ,@Washerid INT
      ,@Address  NVARCHAR(50)
      ,@Value  NVARCHAR(50)
      ,@Timestamp DATETIME2
)

AS
BEGIN

SET NOCOUNT ON              --SQLEnlight SA0017

 DECLARE @TagType  NVARCHAR(50)
  DECLARE @IsTunnel bit
  DECLARE @TagOrder INT

  SELECT @TagType   =  TagType 
  FROM tcd.WasherTags 
  WHERE TagAddress   =  @Address and WasherId = @Washerid
    
  SELECT @IsTunnel   =  IsTunnel  
  FROM TCD.MachineSetup 
  WHERE washerid   =  @WasherId and ControllerId = @ControllerId

 IF NOT EXISTS(
    SELECT TOP 1  * FROM 
       [TCD].[AllenBradleyArrayQueue_Shadow] 
    WHERE 
       Controllerid  =  @Controllerid AND 
       Washerid   =  @Washerid AND 
       Address    =  @Address  AND 
       Value    =  @Value AND 
       Timestamp   =  @Timestamp AND 
       TagType    =  @TagType
    )
 BEGIN

 IF @TagType != 'Tag_AWEF' 
 BEGIN

	IF @TagType = 'Tag_FRM'
	BEGIN
	 SET @TagOrder = 1
	END
	IF @TagType = 'Tag_INJ'
	BEGIN
	 SET @TagOrder = 2
	END
	IF @TagType = 'Tag_OPC'
	BEGIN
	 SET @TagOrder = 3
	END
	IF @TagType = 'Tag_AWEW'
	BEGIN
	 SET @TagOrder = 4
	END

    INSERT INTO  
       [TCD].[AllenBradleyArrayQueue] 
       (
         Controllerid,
         Washerid,
         Address,
         Value,
         Timestamp,
         TagType,
         IsTunnel,
	    TagOrder
       )
    VALUES  ( @Controllerid,
        @Washerid,
        @Address ,
        @Value,
        @Timestamp,
        @TagType,
        @IsTunnel,
	   @TagOrder
       )
 END
 END
END