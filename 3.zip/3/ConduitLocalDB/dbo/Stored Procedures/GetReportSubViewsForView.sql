CREATE PROC [TCD].[GetReportSubViewsForView]

@ViewModeId INT,
@LanguageId Int = NULL

AS

BEGIN

 SELECT RSV.[Id],Name, ISNULL( RKV.Value,RKVEn.Value) as LocallizedName,DrillupView,DrilldownView,CASE WHEN [DrilldownView]=0 THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT) END  IsLast

  FROM [TCD].[ReportSubView] RSV INNER JOIN 
   [TCD].ResourceKeyMaster RK ON RSV.UsageKey=RK.[KeyName]
   LEFT JOIN [TCD].ResourceKeyValue RKV ON RK.[KeyName]=RKV.[KeyName] AND RKV.languageID=@LanguageId
   LEFT JOIN [TCD].ResourceKeyValue RKVEn ON RK.[KeyName]=RKVEn.[KeyName] and RKVEn.languageID=1

  WHERE ViewModeId=@ViewModeId 
  

END