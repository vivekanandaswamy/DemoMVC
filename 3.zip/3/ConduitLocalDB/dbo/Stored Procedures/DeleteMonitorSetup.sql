CREATE PROCEDURE [TCD].[DeleteMonitorSetup] 
(					

			@DashboardId INT = NULL,	
			@EcolabAccountNumber NVARCHAR(25),
			@UserID INT,
			@Scope VARCHAR(100) OUTPUT
) 

AS 

BEGIN
SET NOCOUNT ON
			DECLARE @OutPut VARCHAR(50) = ''
BEGIN     

							UPDATE [TCD].[Dashboard]
							SET	IsDeleted = 1,								
								LastModifiedByUser = @UserID
							WHERE DashboardId = @DashboardId 

							UPDATE [TCD].[MonitorSetUpMapping]
							SET	IsDeleted = 1,				
								LastModifiedByUser = @UserID
							WHERE DashboardId = @DashboardId 
								AND EcolabAccountNumber = @EcolabAccountNumber

			SET @OutPut = '301'     
			SET @Scope = @OutPut SELECT @Scope  

END
SET NOCOUNT OFF
END
