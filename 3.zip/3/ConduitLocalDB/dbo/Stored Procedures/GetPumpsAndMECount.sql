﻿CREATE PROCEDURE [TCD].[GetPumpsAndMECount](@controllerId INT
								  , @EcolabAccountNumber NVARCHAR(25))
AS
BEGIN
	
	SET NOCOUNT ON;

		DECLARE
			@plantId INT = (SELECT P.PlantId
						  FROM TCD.Plant P
						  WHERE P.EcolabAccountNumber = @EcolabAccountNumber);

		DECLARE @controllerModelId INT
		DECLARE @controllerTypeId INT

		SELECT 
			@controllerModelId = CC.ControllerModelId , 
			@controllerTypeId = CC.ControllerTypeId 
	FROM TCD.ConduitController CC 
	WHERE CC.ControllerId = @controllerId

	SELECT	PumpValveCount as Pumps,
			MECount as equipments
	FROM 
			TCD.ControllerModelControllerTypeMapping CMCTM
	WHERE	CMCTM.ControllerModelId = @controllerModelId 
		AND	CMCTM.ControllerTypeId	= @controllerTypeId

	SET NOCOUNT OFF;
END