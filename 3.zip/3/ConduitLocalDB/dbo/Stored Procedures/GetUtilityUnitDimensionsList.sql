﻿/*  

 ==========================================================================================  

 Purpose:  Getting the Units based on the usage key for drop downlistd



 Author:  Santhosh



 --------------------------------------------------------------  

 Sep-10-2014 ENT: Initial version.  

 ==========================================================================================  

*/ 



CREATE PROCEDURE [TCD].[GetUtilityUnitDimensionsList]

	@EcolabAccountNumber					NVARCHAR(25)
,	@UsageKey NVARCHAR(200)=NULL

AS
SET NOCOUNT ON
Declare @LanguageId INT=(select LanguageId from [TCD].plant where EcolabAccountNumber=@EcolabAccountNumber) --Need to Remove the EcolabAccountNumber from here and pass it as parameter

BEGIN
	BEGIN
IF @UsageKey = 'TCD_GasOil_Price' OR @UsageKey = 'TCD_GasOil_Price_EMEA'
BEGIN
	   SELECT ds.Unit,
			ds.Subunit,
			ds.Subunit AS Value
		FROM TCD.DimensionalSubunits ds
			INNER JOIN
			tcd.DimensionalUnits du ON du.Unit = ds.Unit
			INNER JOIN
			TCD.DimensionalDisplayUnits ddu ON ddu.Unit = ds.Unit
									 AND ddu.Subunit = ds.Subunit
			INNER JOIN
			TCD.DimensionalUsageKey duk ON duk.DisplayUnitID = ddu.DisplayUnitID
			INNER JOIN
			TCD.DimensionalUnitsDefaults dud ON dud.UsageKey = duk.UsageKey
		WHERE duk.UsageKey = @UsageKey
END
ELSE
BEGIN
		 SELECT   DISTINCT Unit,
				 Subunit,
				 RV.Value
	   FROM TCD.DimensionalUnitsDefaults DU
		JOIN
		TCD.ResourceKeyMaster RM ON DU.Subunit = RM.[KeyName]
		JOIN
		TCD.ResourceKeyValue RV ON RM.[KeyName] = RV.[KeyName]
	   WHERE      UsageKey LIKE '%'
						+
						@UsageKey
						+
						'%'
		  AND RV.languageID = @LanguageId;
END
	   SET NOCOUNT OFF
	END

SET NOCOUNT OFF

END








