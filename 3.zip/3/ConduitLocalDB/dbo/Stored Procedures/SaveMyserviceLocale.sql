﻿CREATE PROCEDURE TCD.SaveMyserviceLocale(
@Key	NVARCHAR(1000),
@English	NVARCHAR(1000),
@Spanish	NVARCHAR(1000),
@Norweign	NVARCHAR(1000),
@Dutch	NVARCHAR(1000)
)
AS
BEGIN
	IF NOT EXISTS (SELECT 1 FROM TCD.ResourceKeyMaster WHERE [KeyName] = @Key)
	BEGIN
		INSERT INTO TCD.ResourceKeyMaster([KeyName]) VALUES (@Key)
		INSERT INTO TCD.ResourceKeyValue(KeyName, Value, languageID) VALUES (@Key, @English, 1)
		if @Spanish is not null
		INSERT INTO TCD.ResourceKeyValue(KeyName, Value, languageID) VALUES (@Key, @Spanish, 3)
		if @Norweign is not null
		INSERT INTO TCD.ResourceKeyValue(KeyName, Value, languageID) VALUES (@Key, @Norweign, 13)
		if @Dutch is not null
		INSERT INTO TCD.ResourceKeyValue(KeyName, Value, languageID) VALUES (@Key, @Dutch, 2)
	END
END