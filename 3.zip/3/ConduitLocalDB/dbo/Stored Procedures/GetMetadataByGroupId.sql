﻿-- ==========================================================================================   
-- Author:  premchand  
-- Create date: 15/jul/2014
-- Description: Stored Procedure for fetching all labels based on lables Group
-- ==========================================================================================   


CREATE PROCEDURE [TCD].[GetMetadataByGroupId]
(
	@Tab nVarchar(100)
 )
AS
SET NOCOUNT ON
BEGIN     
SELECT DISTINCT 
FG.Id AS FieldGroupId,FG.[NAME] AS FieldGroupName,FG.[image_Url] as FieldGroupImageUrl,FG.[helpText] as FieldGroupHelpText,FGT.NAME AS FieldGroupTypeName,
F.Id AS FieldId,FT.Name AS FieldType,F.Label AS FieldLabel,F.Min AS FieldMinValue,     
      F.Max AS FieldMaxValue, F.IsMandatory AS FieldIsMandatory,F.HelpText AS FieldHelpText, F.HelpTextUrl AS FieldHelpUrl,FG.TabId AS TabIndex,
	  DT.Name AS ControlType,    
      F.DataSourceId AS DataSourceId,     
      F.DataCategoryId AS DataCategoryId,F.DefaultValue AS FieldDefaultValue, F.CurrencyId AS FieldCurrencyCode,
      F.ResourceKey AS FieldResourceKey,FG.ResourceKey AS FieldGroupResourceKey, FG.DisplayOrder AS FieldGroupDO, F.DisplayOrder AS FieldDO 

 FROM [TCD].[FieldGroup] FG
						INNER JOIN
						[TCD].[FieldGroupFieldMapping] FGFM ON FG.Id = FGFM.FieldGroupId
						INNER JOIN
						[TCD].[Field] F ON F.Id = FGFM.FieldId
						LEFT JOIN [TCD].[FieldGroupType] FGT ON FGT.Id = FG.FieldGroupTypeId
						LEFT JOIN [TCD].FieldType FT ON FT.Id = F.TypeId 
						 LEFT JOIN [TCD].DataType DT ON DT.Id = F.DataTypeId 

						WHERE  FG.TabId = @Tab
						  ORDER BY FG.DisplayOrder , F.DisplayOrder, F.Id   end