CREATE PROCEDURE [TCD].[GetMixingVesselsData](  
 @ControllerId INT,  
 @EcolabAccountNumber nvarchar(25))         
AS         
SET NOCOUNT ON        
BEGIN         
      
 SELECT   
   MV.MixingVesselsId,    
   MV.EcoLabAccountNumber,    
   MV.ControllerId,    
   MV.MinimumLevel,    
   MV.FlushTime,    
   MV.PumpingTime,    
   MV.MaxTimeWaterValve,  
   MV.MaxEmtyingTime,  
   MV.CalibrationScale,  
   MV.MaximumVesselCapacity,  
   MV.WeightCell,  
   MV.DirectDose ,
   MV.MixingVesselNumber
  FROM tcd.MixingVessels MV      
  WHERE MV.ControllerId = @ControllerId     
   AND MV.EcolabAccountNumber = @EcolabAccountNumber    
  END  
  
