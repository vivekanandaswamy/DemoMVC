 
CREATE PROCEDURE [TCD].[DeleteUserDetails] (
	@UserNumber INT,
	@UserId		int,
	@EcolabAccountNumber nvarchar(25),
	@LastModifiedTimestampAtCentral			DATETIME		=	NULL,
	@OutputLastModifiedTimestampAtLocal		DATETIME		=	NULL	OUTPUT)
AS 
  BEGIN 
      SET NOCOUNT ON;
	  DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	--,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()					--SQLEnlight SA0004

	DECLARE
		@OutputList						AS	TABLE		(
		LastModifiedTimestamp			DATETIME		)

SET		@OutputLastModifiedTimestampAtLocal			=			ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight SA0121

IF	(
		@LastModifiedTimestampAtCentral				IS NOT	NULL
		AND
		NOT	EXISTS	(	SELECT	1
				FROM	TCD.UserMaster		UM
				WHERE	UM.EcolabAccountNumber	=	@EcolabAccountNumber
					AND	UM.UserId				=	@UserNumber
					AND	UM.LastModifiedTime		=	@LastModifiedTimestampAtCentral
					)
	)
	BEGIN
			SET			@ErrorId				=	60000
			SET			@ErrorMessage			=	N'' + CAST(@ErrorId AS NVARCHAR)
			RAISERROR	(@ErrorMessage, 16, 1)
			SET			@ReturnValue			=	-1
			RETURN		(@ReturnValue)
	END

	 UPDATE [TCD].UserMaster
					 SET IsActive = 0,
					   	 LastModifiedByUserId = @UserId
	OUTPUT
			inserted.LastModifiedTime	AS	LastModifiedTimestamp
	INTO
			@OutputList	(
				LastModifiedTimestamp
						)
	 WHERE UserId = @UserNumber

	 UPDATE [TCD].UserInRole 
					 SET IsDeleted = 1,
						  LastModifiedByUserId = @UserId

	 WHERE UserId = @UserNumber

SELECT	TOP 1	
		@OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp
		FROM	@OutputList							O

      SET NOCOUNT OFF;
   END		