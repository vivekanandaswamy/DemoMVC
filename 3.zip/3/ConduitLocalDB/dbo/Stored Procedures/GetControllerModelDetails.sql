﻿CREATE PROCEDURE [TCD].[GetControllerModelDetails] (@RegionId INT)
AS
SET NOCOUNT ON

BEGIN
	SELECT DISTINCT CM.Id
			,CM.NAME
			,CMRM.RegionId
			,CM.[Version]
			,CMRM.DisplayOrder
		FROM [TCD].[ControllerModel] CM
		INNER JOIN [TCD].ControllerModelRegionMapping CMRM ON CMRM.ControllerModelId = CM.Id
		WHERE CM.Active = 1 AND CMRM.RegionId = @RegionId
		ORDER BY CMRM.DisplayOrder
END