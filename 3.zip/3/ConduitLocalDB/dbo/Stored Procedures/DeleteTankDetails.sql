/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_DeleteTankDetails]                                     

Purpose:				To delete the tank details.

Parameters:				@TankId - holds the tank id.
						@EcolabAccountNumber - holds the ecolab account number.
						@UserId - holds the useer id.
																														
###################################################################################################                                           
*/ 
CREATE PROCEDURE [TCD].[DeleteTankDetails] (
	@TankId					int		= NULL,
			@EcoalabAccountNumber	nvarchar(25),
			@UserId					INT
			,	@LastModifiedTimestampAtCentral			DATETIME		=	NULL
			,	@OutputLastModifiedTimestampAtLocal		DATETIME		=	NULL	OUTPUT)
AS 
  
  BEGIN 
     
	  SET nocount ON;
	  
			  DECLARE	
					@ReturnValue					INT				=			0
				,	@ErrorId						INT				=			0
				,	@ErrorMessage					NVARCHAR(4000)	=			N''
				,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()					--SQLEnlight SA0004

			DECLARE
					@OutputList						AS	TABLE		(
					LastModifiedTimestamp			DATETIME		)

			SET		@OutputLastModifiedTimestampAtLocal			=			ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight SA0121

			IF	(
											@LastModifiedTimestampAtCentral				IS NOT	NULL
											AND
											NOT	EXISTS	(	SELECT	1
													FROM	TCD.TankSetup		TS
													WHERE	TS.EcoalabAccountNumber		=	@EcoalabAccountNumber
														AND	TS.TankId					=	@TankId
														AND	TS.LastModifiedTime			=	@LastModifiedTimestampAtCentral
												)
									)
										BEGIN
												SET			@ErrorId				=	60000
												SET			@ErrorMessage			=	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
												RAISERROR	(@ErrorMessage, 16, 1)
												SET			@ReturnValue			=	-1
												RETURN		(@ReturnValue)
										END

			UPDATE [TCD].TankSetup SET 
					Is_Deleted = 1,
					LastModifiedByUserId = @UserId,
					LastModifiedTime = @CurrentUTCTime

			 OUTPUT
					inserted.LastModifiedTime	AS	LastModifiedTimestamp
			 
			 INTO
					@OutputList	(
					LastModifiedTimestamp
				)
			
			WHERE TankId = @TankId AND EcoalabAccountNumber = @EcoalabAccountNumber

			UPDATE [TCD].ModuleTags SET Active = 0 WHERE ModuleID = @TankId AND ModuleTypeId = 1 AND EcolabAccountNumber = @EcoalabAccountNumber

			 SELECT	TOP 1	
					@OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp
			FROM	@OutputList							O

			RETURN	(@ReturnValue)
	 
     --SET nocount OFF; 
  END