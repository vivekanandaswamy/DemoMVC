CREATE PROCEDURE [TCD].[UPDATEBatchWashStepForTunnel](
	@TunnelXML      XML,
	@WasherID       INT,
	@BatchID        INT,
	@BatchStartTime DATETIME,
	@PartitionOn    DATETIME,
	@EcolabWasherId INT,
	@CurrentStep    INT)
AS
	BEGIN
	    DECLARE @StepStart     DATETIME,
			  @StepEnd       DATETIME,
			  @CompartmentNo INT,
			  @Duration      INT,
			  @LaspStep      INT,
			  @RowCount      INT,
			  @EndDateTime	  DATETIME;
	    CREATE TABLE #BatchStep
	    (
		    CompartmentNo INT,
		    TimeStep      INT,
		    StartDateTime DATETIME,
		    EndDateTime   DATETIME
	    );
	    INSERT INTO #BatchStep
	    (
			 CompartmentNo,
			 TimeStep
	    )
	    SELECT T.c.value('@CompartmentNo', 'INT') AS CompartmentNo,
			 T.c.value('@Time', 'INT') AS [Time]
	    FROM @TunnelXML.nodes('TunnelData/CompartmentTime') T(c)
	    ORDER BY 1;
	    SELECT @EndDateTime=T.c.value('@EndDateTime', 'DateTime') FROM @TunnelXML.nodes('MyControlTunnel/TunnelData') T(c);
	    SELECT @CompartmentNo = 1,
			 @StepStart = @BatchStartTime;
	    WHILE(@CompartmentNo <= @CurrentStep AND @CompartmentNo > 0)
		   BEGIN
			  SELECT @Duration = TimeStep
			  FROM #BatchStep
			  WHERE CompartmentNo = @CompartmentNo;
			  SELECT @StepEnd = DATEADD(ss, @Duration, @StepStart);
	   IF(@CompartmentNo = @CurrentStep)
	   BEGIN
		  if(@EndDateTime IS NOT NULL)
		  SELECT @StepEnd = @StepEnd
	   ELSE
		  SELECT @StepEnd = NULL;
	   END
			  UPDATE BWS
			    SET
				   StartTime = @StepStart,
				   EndTime = @StepEnd
			  FROM TCD.BatchWashStepData BWS
			  WHERE BatchId = @BatchID
				   AND StepCompartment = @CompartmentNo;
			  SELECT @RowCount = @@RowCount;
			  IF(@RowCount = 0 AND @Duration > 0)
				 BEGIN
					INSERT INTO TCD.BatchWashStepData
					(BatchId,
					 StepCompartment,
					 StartTime,
					 EndTime,
					 PartitionOn,
					 EcolabWasherId
					)
						  SELECT @BatchID,
							    @CompartmentNo,
							    @StepStart,
							    @StepEnd,
							    @PartitionOn,
							    @EcolabWasherId;
				 END; --IF (@RowCount = 0)
			  SELECT @CompartmentNo = @CompartmentNo + 1;
			  SELECT @StepStart = @StepEnd;
		   END; --WHILE (@CompartmentNo <=@LaspStep)
	    DROP TABLE #BatchStep;
	END;