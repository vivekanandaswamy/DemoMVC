
CREATE PROCEDURE[TCD].[ReportBatchStepWaterAndEnergyRollup]
AS
BEGIN
/*
==================================================================================================
CHANGE ID(TFS)  CHANGED BY CHANGED ON     CHANGE DESCRIPTION
==================================================================================================
    ASWINI.K.TUMMALA    08/Sep/2016     Scheduled this procedure to run every 15 mins from windows 
            and data get populdated TCD.BatchStepWaterAndEnergyRollUp table
            to improve OperationSummary report performance.
 
==================================================================================================
*/

 SET NOCOUNT ON;
 DECLARE @LastShiftId INT=NULL

DECLARE @BatchStepWaterAndEnergyRollup TABLE(
	[PartitionOn] [smalldatetime] NULL,
	[BatchId] [int] NULL,
	[ActualWeight] [int] NULL,
	[StandardWeight] [int] NULL,
	[MachineId] [int] NULL,
	[GroupId] [int] NULL,
	[MachineInternalId] [tinyint] NULL,
	[ProgramMasterId] [int] NULL,
	[ProductId] [int] NULL,
	[NoOfLoads] [int] NULL,
	[ActualChemicalQuantity] [int] NULL,
	[StandardChemicalQuantity] [int] NULL,
	[WaterActualQuantity] [float] NULL,
	[WaterStandardQuantity] [float] NULL,
	[EnergyActualQuantity] [float] NULL,
	[EnergyStandardQuantity] [float] NULL,
	[ChemicalPrice] [int] NULL,
	[WaterPrice] [float] NULL,
	[EnergyPrice] [float] NULL,
	[EcolabTextileCategoryId] [int] NULL,
	[EcolabTextileCategoryName] [int] NULL,
	[PlantTextileId] [int] NULL,
	[PlantTextileCategoryName] [int] NULL,
	ChainTextilecategoryId	INT NULL,
	FormulasegmentId		INT NULL,
	[ShiftId] [int] NULL,
	ShiftName				VARCHAR(50) NULL
);


 SELECT @LastShiftId=  MAX(SHIFTID) FROM TCD.BatchWaterandEnergyRollUp;

 INSERT INTO @BatchStepWaterAndEnergyRollup


SELECT  A.[PartitionOn]
      ,A.[BatchId]
      ,A.[ActualWeight]
      ,A.[StandardWeight]
      ,A.[MachineId]
      ,A.[GroupId]
      ,A.[MachineInternalId]
      ,A.[ProgramMasterId]
      ,A.[ProductId]
      ,A.[NoOfLoads]
      ,A.[ActualChemicalQuantity]
      ,A.[StandardChemicalQuantity]
      ,A.[WaterActualQuantity]
      ,A.[WaterStandardQuantity]
      ,A.[EnergyActualQuantity]
      ,A.[EnergyStandardQuantity]
      ,A.[ChemicalPrice]
      ,A.[WaterPrice]
      ,A.[EnergyPrice]
     ,CASE 
			WHEN  PM.PlantProgramId  IS NOT NULL AND ChainPlant.EcolabTextileCategoryId IS NOT NULL   
				  THEN ChainPlant.EcolabTextileCategoryId  
				  ELSE ETC1.TextileId   
       END AS EcolabTextileCategoryId
      ,A.[EcolabTextileCategoryName]
      ,A.[PlantTextileId]
      ,A.[PlantTextileCategoryName]
      ,CASE 
			 WHEN PM.PlantProgramId  IS NOT NULL 
					  THEN ChainPlant.ChainTextileCategoryId  
					  ELSE NULL 
       END AS ChainTextilecategoryId
              
       ,CASE 
            WHEN  PM.PlantProgramId  IS NOT NULL 
                  THEN ChainPlant.FormulaSegmentId  
                  ELSE FS1.FormulaSegmentID 
         END AS FormulasegmentId
      ,A.[ShiftId] 
      ,A.ShiftName
      
FROM 
      (SELECT 
				  BSWUD.PartitionOn ,BSWUD.BatchId,SUM(bd.ActualWeight)ActualWeight,SUM(bd.StandardWeight)StandardWeight,BD.MachineId,BD.GroupId
					,BD.MachineInternalId
			--,bd.ProgramMasterId,BPD.ProductId 
			,bd.ProgramMasterId ProgramMasterId,NULL ProductId
			,COUNT(1) AS NoOfLoads,NULL AS ActualChemicalQuantity,NULL StandardChemicalQuantity,
			SUM(BSWUD.ActualQuantity)WaterActualQuantity,SUM(BSWUD.StandardQuantity)WaterStandardQuantity,
			SUM(BEUD.ActualQuantity)EnergyActualQuantity,SUM(BEUD.StandardQuantity)EnergyStandardQuantity
			,NULL AS ChemicalPrice,SUM(BSWUD.Price)WaterPrice,SUM(BEUD.Price)EnergyPrice
			,NULL EcolabTextileCategoryId,NULL AS [EcolabTextileCategoryName]
			,NULL [PlantTextileId],NULL [PlantTextileCategoryName]
			,BD.ShiftId
			,PSD.ShiftName 
		FROM TCD.ProductionShiftData PSD 
		INNER JOIN TCD.BatchData BD ON BD.ShiftId=PSD.ShiftId
		INNER JOIN  TCD.BatchStepWaterUsageData BSWUD  ON BSWUD.BatchId=BD.BatchId
		LEFT JOIN TCD.BatchEnergyUsageData BEUD ON BEUD.BatchId=BD.BatchId
		--LEFT JOIN tcd.BatchProductData BPD ON BPD.BatchId=BD.BatchId AND ISNULL(BPD.EcolabWasherId,'')=ISNULL(BD.EcolabWasherId,'')
		INNER JOIN TCD.MachineSetup MS 
			ON MS.GroupId = BD.GroupId AND MS.WasherId=BD.MachineId
		INNER JOIN TCD.Washer W 
			ON (W.EcoLabAccountNumber=MS.EcoalabAccountNumber AND ISNULL(W.EcolabWasherId,'')=ISNULL(BD.EcolabWasherId,'')) AND W.WasherId=MS.WasherId
		   
			WHERE BSWUD.BatchId IS NOT NULL OR BEUD.BatchId IS NOT NULL AND ISNULL(MS.ISPONY,0)=0
					GROUP BY BSWUD.PartitionOn ,BSWUD.BatchId,BD.MachineId,BD.GroupId,BD.MachineInternalId,bd.ProgramMasterId,BD.ShiftId,PSD.ShiftName,EcolabTextileCategoryId
	  )A 
	INNER JOIN TCD.ProgramMaster PM ON PM.ProgramId=A.ProgramMasterId				
	LEFT OUTER JOIN
	(
	--IF Chain Plant
	SELECT PCP.PlantProgramId,PCP.PlantChainId,PCP.ChainTextileCategoryId,PCP.EcolabTextileCategoryId,
	PCP.FormulaSegmentId,PCP.EcolabSaturationId
	FROM TCD.PlantChainProgram PCP 
	LEFT OUTER JOIN TCD.ChainTextileCategory CTC ON CTC.TextileId=NULLIF(PCP.ChainTextileCategoryId,0)
	LEFT OUTER JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId=NULLIF(PCP.EcolabTextileCategoryId,0)
	LEFT OUTER JOIN TCD.FormulaSegments FS ON FS.FormulaSegmentID=PCP.FormulaSegmentId
	LEFT OUTER JOIN TCD.EcolabSaturation ES ON ES.EcolabSaturationId=PCP.EcolabSaturationId
	)ChainPlant ON PM.PlantProgramId=ChainPlant.PlantProgramId

	LEFT OUTER JOIN TCD.EcolabTextileCategory ETC1 ON ETC1.TextileId=PM.EcolabTextileCategoryId
	LEFT OUTER JOIN TCD.FormulaSegments FS1 ON FS1.FormulaSegmentID=PM.FormulaSegmentId
	LEFT OUTER JOIN TCD.EcolabSaturation ES1 ON ES1.EcolabSaturationId=PM.EcolabSaturationId
  
				WHERE A.ShiftId>=@LastShiftId;
				

 ---IF DATA ALREADY EXISTS, UPDATE WITH CURRENT DATA. 

 
UPDATE DEST SET 
		 DEST.RecordDate=		  	 SRC.[PartitionOn]	 
		,DEST.BatchId		=		 SRC.[BatchId]		 
		,DEST.ActualWeight	=		 SRC.[ActualWeight]	 
		,DEST.StandardWeight	=	 SRC.[StandardWeight]	  
		,DEST.MachineId	=		 SRC.[MachineId]		 
		,DEST.GroupId			=	 SRC.[GroupId]		  
		,DEST.MachineInternalId	=	 SRC.[MachineInternalId]   
		,DEST.ProgramMasterId	=	 SRC.[ProgramMasterId]	  
		,DEST.ProductId		=	 SRC.[ProductId]		  
		,DEST.NoOfBatches		=	 SRC.[NoOfLoads]		  
		,DEST.ActualChemicalWeight	=    SRC.[ActualChemicalQuantity]	 
		,DEST.StandardChemicalWeight	=    SRC.[StandardChemicalQuantity] 
		,DEST.ActualWaterWeight		=    SRC.[WaterActualQuantity]		 
		,DEST.StandardWaterWeight	=    SRC.[WaterStandardQuantity]	 
		,DEST.ActualEnergyWeight	=    SRC.[EnergyActualQuantity]		 
		,DEST.StandardEnergyWeight	 =   SRC.[EnergyStandardQuantity]	 
		,DEST.ChemicalCost			 =   SRC.[ChemicalPrice]			 
		,DEST.WaterCost			=   SRC.[WaterPrice]		 
		,DEST.EnergyCost			=   SRC.[EnergyPrice]		 
		,DEST.EcolabTextileId			 =   SRC.[EcolabTextileCategoryId]	
		,DEST.EcolabTextileCategoryName	=    SRC.[EcolabTextileCategoryName]	
		,DEST.PlantTextileId			 =   SRC.[PlantTextileId]			
		,DEST.PlantTextileCategoryName	 =   SRC.[PlantTextileCategoryName]	
		,DEST.ChainTextilecategoryId	=	SRC.ChainTextilecategoryId
		,DEST.FormulasegmentId		=	SRC.FormulasegmentId
		,DEST.SHIFTID					=    SRC.[ShiftId]				
		,DEST.ShiftName	 =SRC.ShiftName
	 
	 FROM @BatchStepWaterAndEnergyRollup SRC 
					   INNER JOIN TCD.BatchWaterandEnergyRollUp DEST 
					   ON SRC.BatchId=DEST.BatchId;   --  MATCHED RECORDS
	
	 
--IF DATA IS NOT EXISTS IN DESTINATION TABLE "INSERT" THE RECORDS INTO DESTINATION.

INSERT INTO TCD.BatchWaterandEnergyRollUp
(
	  [RecordDate]
      ,[BatchId]
      ,[ActualWeight]
      ,[StandardWeight]
      ,[MachineId]
      ,[GroupId]
      ,[MachineInternalId]
      ,[ProgramMasterId]
      ,[ProductId]
      ,[NoOfBatches]
      ,[ActualChemicalWeight]
      ,[StandardChemicalWeight]
      ,[ActualWaterWeight]
      ,[StandardWaterWeight]
      ,[ActualEnergyWeight]
      ,[StandardEnergyWeight]
      ,[ChemicalCost]
      ,[WaterCost]
      ,[EnergyCost]
      ,[EcolabTextileId]
      ,[EcolabTextileCategoryName]
      ,[PlantTextileId]
      ,[PlantTextileCategoryName]
      ,[ChainTextilecategoryId]
      ,[FormulasegmentId]
      ,[ShiftId]
      ,[ShiftName]
)
SELECT SRC.[PartitionOn]
      ,SRC.[BatchId]
      ,SRC.[ActualWeight]
      ,SRC.[StandardWeight]
      ,SRC.[MachineId]
      ,SRC.[GroupId]
      ,SRC.[MachineInternalId]
      ,SRC.[ProgramMasterId]
      ,SRC.[ProductId]
      ,SRC.[NoOfLoads]
      ,SRC.[ActualChemicalQuantity]
      ,SRC.[StandardChemicalQuantity]
      ,SRC.[WaterActualQuantity]
      ,SRC.[WaterStandardQuantity]
      ,SRC.[EnergyActualQuantity]
      ,SRC.[EnergyStandardQuantity]
      ,SRC.[ChemicalPrice]
      ,SRC.[WaterPrice]
      ,SRC.[EnergyPrice]
      ,SRC.[EcolabTextileCategoryId]
      ,SRC.[EcolabTextileCategoryName]
      ,SRC.[PlantTextileId]
      ,SRC.[PlantTextileCategoryName]
      ,SRC.[ChainTextilecategoryId]
      ,SRC.[FormulasegmentId]
      ,SRC.[ShiftId] 
      ,SRC.ShiftName
      
      
      FROM @BatchStepWaterAndEnergyRollup SRC 
					   LEFT JOIN TCD.BatchWaterandEnergyRollUp DEST ON SRC.BatchId=DEST.BatchId
							 WHERE DEST.BatchId IS NULL; --NON MATCHED RECORDS
		END	 
		GO
 







