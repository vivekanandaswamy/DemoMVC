﻿/*      
 ==========================================================================================    
 Stored Procedure	:	SaveUserAudit
 Purpose			:	Save User loon/logoff activity .      
  
 Parameters:			@UserId					---- Login/LogOut UserID 
						@EcolabAccountNumber	---- EcoLab Account Number
						@IPAddress				---- Server IP Address
						@UserActivityId			---- Activity Type Id
  
 --------------------------------------------------------------      
 NOV-20-2014 ENT: Initial version.      
 ==========================================================================================    
*/   
CREATE Proc [TCD].[SaveUserAudit]
(
	@UserId	 INT,
	@EcolabAccountNumber NVARCHAR(25),
	@IPAddress VARCHAR(200),
	@UserActivityId TINYINT)
AS
BEGIN
SET NOCOUNT ON;

	INSERT INTO [TCD].[UserAudit](
				EcoLabAccountNumber,
				UserId,
				IPAddress,
				UserActivityId)
	VALUES(		@EcolabAccountNumber,
				@UserId,
				@IPAddress,
				@UserActivityId)

SET NOCOUNT OFF;

END