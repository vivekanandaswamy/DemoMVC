﻿CREATE PROCEDURE [TCD].[GetPortletsByUser]
(
	@UserId INT,
	@EcolabAccountNumber Nvarchar(25)
 )
AS
SET NOCOUNT ON
BEGIN
Declare @count int
Select @count =  Count(*) from [TCD].DashboardUserPortletMapping where UserId=@UserId AND EcolabAccountNumber = @EcolabAccountNumber;
 
if(@count > 0)
	BEGIN
		SELECT DISTINCT 
	  
		  DUP.[PortletId],
		  PM.[Name],
		  DUP.[DisplayOrder],
		  DUP.[IsEnabled],
		  PM.[ReportId]
			  
			FROM [TCD].PortletMaster PM
			INNER JOIN [TCD].DashboardUserPortletMapping DUP
			ON PM.Id = DUP.PortletId 
			Where UserId=@UserId 
				AND DUP.EcolabAccountNumber = @EcolabAccountNumber
			ORDER BY [DisplayOrder] ASC
	END
ELSE
	BEGIN

	SELECT DISTINCT PM.[Id],
					PM.[Name],
					PM.[Id],
					Convert(bit,1) AS IsEnabled,
					PM.[ReportId]
			FROM [TCD].PortletMaster PM

	END
	  
END