﻿/*     
 ==========================================================================================    
 Purpose:  GET SYNC CONFIG SETTINGS  
  
 Author:  Manohar B    
  
 --------------------------------------------------------------     
 Nov-18-2014 ENT: Initial version.     
 ==========================================================================================    
*/ 

CREATE PROCEDURE [TCD].[GetSyncConfigSettings]
	@Type NVARCHAR(50)	
	
AS
SET NOCOUNT ON
	SELECT SCS.KEYNAME,SCS.VALUE  from TCD.ConfigSettings SCS
	WHERE SCS.Type=@Type AND SCS.Active=1
RETURN 0
