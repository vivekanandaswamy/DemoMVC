﻿CREATE PROCEDURE [TCD].[GetCompartmentCount]
(
@TunnelId INT
, @WasherGroupId int
, @EcolabAccountNumber NVARCHAR(25) = NULL
)
AS
BEGIN
    SET NOCOUNT ON;
    
	SELECT	tc.CompartmentNumber 
			, tc.TunnelCompartmentId
	FROM	TCD.TunnelCompartment tc 
	WHERE	tc.WasherId				=			@TunnelId
	AND		tc.EcoLabAccountNumber  =			@EcolabAccountNumber
    SET NOCOUNT OFF;
END;