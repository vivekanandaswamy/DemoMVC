﻿CREATE PROCEDURE [TCD].[ProcessDeleteBeckhoffArrayQueue]
(	
	@Controllerid		INT
      ,@Washerid		INT
      ,@Address			NVARCHAR(50)
      ,@Value			NVARCHAR(50)
      ,@Timestamp		DATETIME2
	  ,@IsTunnel		bit
)

AS
BEGIN

SET	NOCOUNT	ON														--SQLEnlight	SA0017

	DELETE FROM	[TCD].[BeckhoffArrayQueue] 
	WHERE 
			Controllerid		=		@Controllerid	AND 
			Washerid			=		@Washerid		AND 
			Address				=		@Address		AND 
			Value				=		@Value			AND
			Timestamp			=		@Timestamp		AND
			IsTunnel            =		@IsTunnel
END