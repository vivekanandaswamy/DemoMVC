﻿/*
==========================================================================================
Purpose:  Fetching the Plant Red Flag Details

Author:  PREMCHAND YELAVARTHI

--------------------------------------------------------------
Aug-13-2014 ENT: Initial version.
==========================================================================================

--[tcd].[GetRedFlagDetails] 21,'P03810001'
*/
CREATE PROCEDURE [TCD].[GetRedFlagDetails](
      @Id INT = NULL, 
      @Ecolabaccountnumber nvarchar(25))
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Plantid INT, 
            @Regionid INT, 
            @Languageid INT, 
            @Uomendpart VARCHAR(100), 
            @Uom7 NVARCHAR(1000), 
            @Uom8 NVARCHAR(1000);
    SELECT
            @Plantid = PlantId, 
            @Regionid = RegionId, 
            @Languageid = LanguageId
        FROM TCD.Plant
        WHERE EcolabAccountNumber = @Ecolabaccountnumber;
    IF @Regionid = 1
        BEGIN
            SET @Uomendpart = 'CWT';
        END;
    ELSE
        BEGIN
            SET @Uomendpart = 'kg';
        END;

    SELECT
            @Uom7 = rkv.[Value]
        FROM TCD.Meter AS m
             LEFT JOIN tcd.ResourceKeyValue AS rkv ON m.MeterTickUnit = rkv.KeyName
                                                  AND LanguageId = @Languageid
        WHERE m.GroupId IS NULL
          AND m.UtilityType IN(1, 2);

    SELECT
            @Uom8 = rkv.[Value]
        FROM TCD.Meter AS m
             LEFT JOIN tcd.ResourceKeyValue AS rkv ON m.MeterTickUnit = rkv.KeyName
                                                  AND LanguageId = @Languageid
        WHERE m.GroupId IS NULL
          AND m.UtilityType IN(1);

    SELECT Distinct 
            PR.Id, 
            ItemID = PR.Item, 
            IL.ItemName, 
            PR.MinimumRange, 
            PR.MaximumRange, 
            CASE
                WHEN PR.Item IN(7, 8)THEN CASE
                                              WHEN ISNULL(PR.MeterId, 0) != 0 THEN rkv.[Value] + '/' + @Uomendpart
                                              WHEN PR.Item = 7 THEN @Uom7 + '/' + @Uomendpart
                                              WHEN PR.Item = 8 THEN @Uom8 + '/' + @Uomendpart
                                          END
                ELSE CASE @Regionid
                         WHEN 1 THEN IL.UOMNA
                         WHEN 2 THEN IL.UOMEurope
                     END
            END AS UOM, 
            LocationID = PR.Location, 
            CASE
                WHEN GT.Is_Deleted = 0 THEN GT.GroupDescription
                ELSE CAST('' AS NVARCHAR)
            END AS LocationName, 
            PR.EcolabAccountNumber, 
            (SELECT
                     STUFF((
             SELECT DISTINCT
                     ',' + CAST(ISNULL(MachineId, -1)AS VARCHAR(1000))
                 FROM TCD.RedFlagMappingData AS MD
                 WHERE MD.MappingID = PR.ID
                   AND MD.Is_Deleted = 0
                 FOR
                 XML PATH('')), 1, 1, ''))AS MachineID, 
            (SELECT
                     LTRIM(ISNULL(STUFF((
             SELECT DISTINCT
                     ', ' + (
             SELECT
                     CASE
                         WHEN(
             SELECT DISTINCT
                     Istunnel
                 FROM TCD.machinesetup AS S
                 WHERE S.groupId = PR.Location
                   AND S.Washerid = MD.MachineId) = 1 THEN CASE
                                                               WHEN(
             SELECT
                     RD.MachineId
                 FROM TCD.RedFlag AS MM
                      INNER JOIN TCD.RedFlagMappingData AS RD ON MM.Id = RD.MappingId
                 WHERE RD.MachineId = MD.MachineId
                   AND RD.MachineId = 0
                   AND RD.Is_Deleted = 0) = 0 THEN 'Press'
                                                               ELSE CASE
                                                                        WHEN(
             SELECT TOP 1
                     MS.IsDeleted
                 FROM TCD.MachineSetup AS MS
                 WHERE MS.GroupId = PR.Location
                   AND MS.WasherId = MD.MachineId
                   AND MS.IsDeleted = 0)IS NOT NULL THEN (SELECT TOP(1) CAST(WS.PlantWasherNumber AS nvarchar)+':'+MS.MachineName FROM TCD.MachineSetup MS INNER JOIN TCD.Washer WS ON MS.WasherId = WS.WasherId WHERE MS.GroupId = PR.Location AND MS.WasherId = MD.MachineId) ELSE '0'
                                                                    END
      
                                                           END
                         WHEN(
             SELECT DISTINCT
                     Istunnel
                 FROM TCD.machinesetup AS S
                 WHERE S.groupId = PR.Location
                   AND S.Washerid = MD.MachineId) = 0 THEN ISNULL((
             SELECT TOP (1)
                     CAST(WS.PlantWasherNumber AS NVARCHAR) + ':' + MS.MachineName
                 FROM TCD.MachineSetup AS MS
                      INNER JOIN TCD.Washer AS WS ON MS.WasherId = WS.WasherId
                 WHERE MS.GroupId = PR.Location
                   AND MS.WasherId = MD.MachineId
                   AND MS.IsDeleted = 0), '0')
                         WHEN(
             SELECT DISTINCT
                     GroupTypeId FROM TCD.MachineGroup AS GT WHERE GT.Id = PR.Location) = 3 THEN(
             SELECT
                     Description
                 FROM TCD.Dryers AS D
                 WHERE D.DryerGroupId = PR.Location
                   AND D.DryerNo = MD.MachineId
                   AND D.Is_deleted = 0)
                         WHEN(
             SELECT DISTINCT
                     GroupTypeId FROM TCD.MachineGroup AS GT WHERE GT.Id = PR.Location) = 4 THEN(
             SELECT
                     Name
                 FROM TCD.Finnishers AS F
                 WHERE F.FinnisherGroupId = PR.Location
                   AND F.FinnisherNo = MD.MachineId
                   AND F.Is_deleted = 0)
                     END)
                 FROM TCD.RedFlagMappingData AS MD
                      LEFT OUTER JOIN TCD.Machinesetup AS MSP ON MSP.WasherId = MD.MachineId
                 WHERE MD.MappingID = PR.ID
                   AND MD.Is_Deleted = 0
                 FOR
                 XML PATH('')), 1, 1, ''), 'ALL')))AS MachineName, 
            PR.RedFlagCategoryId AS CategoryId, 
            PR.FormulaId AS FormulaId, 
            PM.Name AS FormulaName, 
            PR.ProductId, 
            PRM.Name AS ProductName, 
            ISNULL(PR.MeterId, s.SensorId)AS MeterId, 
            CASE
                WHEN ISNULL(PR.MeterId, 0) != 0 THEN ME.Description
                ELSE s.Description
            END AS MeterName, 
            PR.LastModifiedTime, 
            PR.LastSyncTime, 
            PR.Is_Deleted, 
            Pr.SensorId
        FROM TCD.RedFlag AS PR
             INNER JOIN TCD.RedFlagItemList AS IL ON PR.Item = IL.Id
             LEFT JOIN TCD.WasherProgramSetup AS WPS ON CASE PR.Location WHEN 1 THEN 1 ELSE PR.Location END  =  CASE PR.Location WHEN 1 THEN 1 ELSE WPS.WasherGroupId END 
                                                    AND WPS.ProgramID = PR.FormulaId
                                                    AND WPS.Ecolabaccountnumber = @Ecolabaccountnumber
             LEFT JOIN TCD.TunnelProgramSetup AS TPS ON CASE PR.Location WHEN 1 THEN 1 ELSE PR.Location END  =  CASE PR.Location WHEN 1 THEN 1 ELSE TPS.WasherGroupId END 
                                                    AND TPS.ProgramID = PR.FormulaId
                                                    AND TPS.Ecolabaccountnumber = @Ecolabaccountnumber
             LEFT JOIN tcd.ProgramMaster AS PM ON PM.ProgramId = CASE
                                                                     WHEN WPS.WasherProgramSetupId IS NOT NULL THEN WPS.ProgramId
                                                                     ELSE TPS.ProgramId
                                                                 END --Identify whether its tunnel or washer formula
             LEFT JOIN TCD.ProductMaster AS PRM ON PRM.ProductId = PR.ProductId
             LEFT JOIN TCD.Meter AS ME ON ME.MeterId = PR.MeterId
                                      AND ME.EcolabAccountNumber = @Ecolabaccountnumber
             LEFT JOIN TCD.RedFlagCategory AS RFC ON RFC.RedFlagCategoryId = PR.RedFlagCategoryId
             INNER JOIN TCD.MachineGroup AS GT ON PR.Location = GT.Id
             LEFT JOIN tcd.ResourceKeyValue AS rkv ON ME.MeterTickUnit = rkv.KeyName
                                                  AND LanguageId = @Languageid
             LEFT JOIN TCD.Sensor AS s ON s.SensorId = PR.SensorId
        WHERE PR.PlantId = @Plantid
          AND PR.Is_Deleted = 0 
              --AND GT.Is_Deleted = 0
          AND CASE ISNULL(@Id, '')
                  WHEN '' THEN 'TRUE'
                  ELSE CASE
                           WHEN PR.Id = @Id THEN 'TRUE'
                       END
              END = 'TRUE';
    SET NOCOUNT OFF;
END;