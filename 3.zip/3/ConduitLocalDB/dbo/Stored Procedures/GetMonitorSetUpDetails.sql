CREATE PROCEDURE [TCD].[GetMonitorSetUpDetails] 
(
			@EcolabAccountNumber NVARCHAR(25)
)
AS   
BEGIN   

SET	NOCOUNT	ON														--SQLEnlight	SA0017

				SELECT 
								 MM.Id,
								 D.DashboardId,
								 D.DashBoardName,
								 MS.WasherId as MACHINEID,
								 WGT.WasherGroupTypeId,
								 WGT.WasherGroupTypeName,
								 CAST( PlantWasherNumber as varchar(20)) +' '+ MS.MACHINENAME MACHINENAME,
								 MM.MonitorId,
								 D.IsEnableParameters,
								 D.Customer,
								 D.Formula,
								 D.[Load],
								 D.DisplayOnLogin,
								 D.TimelineHours,
								  ISNULL(D.DisplayFormulaType,1),
								 CASE ISNULL(D.DisplayFormulaType,1)  
										  WHEN 1 THEN 'Formula No'  
										  WHEN 2 THEN 'Formula Name'
								END AS DisplayFormulaTypeName,
								P.DashboardSlideDuration,
								 ISNULL(D.EfficiencyCalcType,1),
								 CASE ISNULL(D.EfficiencyCalcType,1)  
										  WHEN 1 THEN 'Shift Wise'  
										  WHEN 2 THEN 'Day Wise'
								END AS EfficiencyCalcTypeName,
								MachineNameDispalyType
				FROM [TCD].Dashboard D
					INNER JOIN [TCD].MonitorSetUpMapping MM ON MM.DashboardId = D.DashboardId 
					INNER JOIN [TCD].WasherGroupType WGT ON WGT.WasherGroupTypeId = D.TypeId   					
					INNER JOIN [TCD].MACHINESETUP MS ON MM.MachineId=MS.WasherId	
					INNER JOIN TCD.Washer W on MS.WasherId=W.WasherId	
					INNER JOIN [TCD].PLANT P ON P.EcolabAccountNumber=@EcolabAccountNumber		
				WHERE D.IsDeleted = 0 
					AND MM.IsDeleted = 0
					AND MS.IsDeleted = 0
					AND D.EcolabAccountNumber = @EcolabAccountNumber
					order by D.DashboardId
END