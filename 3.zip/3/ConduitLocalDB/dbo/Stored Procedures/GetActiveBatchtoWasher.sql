﻿CREATE PROCEDURE [TCD].[GetActiveBatchtoWasher]
(
@WasherId     INT, 
@CurrentFormula       INT,  
@CurrentFormulaDate      DATETIME2,
@BatchExists    INT OUTPUT
)
 AS
BEGIN

SET NOCOUNT ON              --SQLEnlight SA0017


  SELECT     @BatchExists    =   bd.BatchId 
  FROM Tcd.BatchData bd
  WHERE  MachineId=@WasherId AND StartDate=@CurrentFormulaDate AND ProgramNumber=@CurrentFormula
END