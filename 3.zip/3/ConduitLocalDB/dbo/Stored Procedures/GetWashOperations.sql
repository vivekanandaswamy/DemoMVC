﻿--Need a header here...
CREATE PROCEDURE [TCD].[GetWashOperations]	(
			 @RegionId					INT
		    ,@IsTunnel					BIT
)
AS
SET NOCOUNT ON
BEGIN
	SELECT    
		[StepId]
		,[StepName] 
	FROM 
	[TCD].[WashStep] 
	WHERE	 [IsActive]  =	  1
	AND		 ([StepName] IS NOT NULL AND [StepName] <> '')
	AND		 RegionId	   =	  @RegionId
	AND		 Istunnel	   =	  @IsTunnel
	AND		 MyServiceWshOpId IS NOT NULL
	ORDER BY StepName
END