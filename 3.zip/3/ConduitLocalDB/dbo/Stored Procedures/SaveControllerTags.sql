﻿CREATE PROCEDURE [TCD].[SaveControllerTags]
				@ControllerId		INT
				,	@FieldTagValue		NVARCHAR(100)
				,	@FieldTagAddress	NVARCHAR(100)
				,	@EcolabAccountNumber	NVARCHAR(25)
As

BEGIN
SET	NOCOUNT	ON


DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''

	,	@WasherTagId					INT
	,	@TagType						NVARCHAR(50)
	,	@COntrollerTagId				INT 


	IF(@FieldTagAddress IS NULL OR  @FieldTagAddress = '')
	BEGIN 
		IF EXISTS(SELECT 1 FROM [TCD].[ControllerTags] CT WHERE CT.ControllerID=@ControllerId AND CT.TagType=@FieldTagValue AND CT.Active = 1 AND CT.EcolabAccountNumber =	@EcolabAccountNumber)
		BEGIN
			UPDATE	[TCD].[ControllerTags]		SET			Active = 0		
											WHERE		ControllerID	=	@ControllerId	
											AND			TagType			=	@FieldTagValue
											AND			EcolabAccountNumber =	@EcolabAccountNumber
		END
	END
	ELSE
	BEGIN
		IF NOT EXISTS (SELECT 1 FROM [TCD].[ControllerTags] CT WHERE CT.ControllerID=@ControllerId AND CT.TagType=@FieldTagValue AND Active =1 AND CT.EcolabAccountNumber = @EcolabAccountNumber)
	BEGIN
		IF (SELECT COUNT(*) FROM [TCD].[ControllerTags]  WHERE EcolabAccountNumber = @EcolabAccountNumber) >0
			SELECT @COntrollerTagId= (SELECT MAX(ControllerTagId)+1 FROM [TCD].[ControllerTags] WHERE EcolabAccountNumber = @EcolabAccountNumber)
		ELSE
			SELECT @COntrollerTagId=1
	
		INSERT	[TCD].[ControllerTags]	(ControllerTagId		,ControllerID		,TagType			,TagAddress			,Active, EcolabAccountNumber)
								VALUES	(@COntrollerTagId		,@ControllerId		,@FieldTagValue		,@FieldTagAddress	,1, @EcolabAccountNumber)

	END
ELSE IF EXISTS (SELECT 1 FROM [TCD].[ControllerTags] CT WHERE CT.ControllerID=@ControllerId AND CT.TagType=@FieldTagValue AND Active =1 AND EcolabAccountNumber=@EcolabAccountNumber)
	BEGIN

		UPDATE	[TCD].[ControllerTags]		SET			TagAddress		=	@FieldTagAddress			
											WHERE		ControllerID	=	@ControllerId	
											AND			TagType			=	@FieldTagValue
											AND			EcolabAccountNumber = @EcolabAccountNumber

	END
	END

SET	@ErrorId	=	@@ERROR
	
IF	(@ErrorId	<>	0)
	BEGIN
			IF	@@TRANCOUNT	>	0
			BEGIN
				ROLLBACK	TRAN
			END

			SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR) + N': Error occurred deleting controller tags. '
			RAISERROR	(@ErrorMessage, 16, 1)
			SET		@ReturnValue	=	-1
			RETURN	(@ReturnValue)
	END

END