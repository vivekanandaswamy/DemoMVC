﻿
/*	
Purpose					:	To populate the grid in the Washer setup --> Washers listing

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version

*/

CREATE	PROCEDURE    [TCD].[GetWasherList] -- '040242802', 4,2
     @EcoLabAccountNumber     NVARCHAR(25)

    , @WasherGroupId       INT   =   NULL
    , @WasherId        INT   =   NULL
    , @Is_Deleted        bit   =   'FALSE'
AS
BEGIN

SET NOCOUNT ON


SELECT --*
  W.PlantWasherNumber    AS   WasherNumber
 , MS.MachineName     AS   WasherName
 , CASE MS.IsTunnel
   WHEN 'TRUE' THEN 'Tunnel'
   WHEN 'FALSE' THEN 'WasherExtractor'
  END        AS   WasherType
 , MS.IsTunnel      AS   WasherTypeFlag
 , WMS.WasherModelName    AS   WasherModel
 , WMS.WasherModelId    AS   WasherModelId
 , WMS.WasherSize     AS   WasherSize
 , CASE WHEN CC.ControllerId = 0 THEN '' ELSE CC.Name END AS   WasherControllerName
 , W.WasherId      AS   WasherId
 , WG.WasherGroupId    AS   WasherGroupId
 , WG.WasherGroupName    AS   WasherGroupName
 , CC.ControllerId     AS   WasherControllerId

 , W.[Description]     AS   WasherDescription
 , W.MaxLoad      AS   WashermaxLoad

 , W.WasherMode     AS   WasherModeId

 , W.AWEActive      AS   WasherAWEActive
 , MS.NumberOfComp     AS   WasherNumberOfCompartments

 , CAST(W.NumberOfTanks AS SMALLINT)
          AS   WasherNumberOfTanks
 , CAST(W.PressExtractor AS SMALLINT)
          AS   WasherPressExtractorId
 , CAST(W.TransferType  AS SMALLINT)
          AS   WasherTransferTypeId
 , CASE MS.IsTunnel WHEN 1 THEN CAST(W.EmptyPocketNumber AS SMALLINT) ELSE CAST(W.EndOfFormula AS SMALLINT) END AS WasherProgramNumber

 -- Columns for conventionals
 , W.HoldSignal     AS   HoldDelay
 , CAST(W.HoldDelay AS INT)  AS   HoldSignal
 , CAST(W.TargetTurnTime AS INT) AS   TargetTurnTime
 , CAST(W.WaterFlushTime AS INT) AS   WaterFlushTime
 , MS.MachineInternalId   AS   LFSWasherNumber

    --    Cols. for integration with Synch./Central
    ,    W.LastModifiedTime                AS            LastModifiedTime
    ,    W.LastSyncTime                    AS            LastSyncTime
    ,    W.Is_Deleted                    AS            Is_Deleted
    ,    W.EcoLabAccountNumber            AS            EcolabAccountNumber
    ,    (SELECT Count(*) FROM tcd.TunnelProgramSetup wps WHERE wps.WasherGroupId=@WasherGroupId AND wps.Is_Deleted=0) AS FormulaCount
    ,    GT.MyServiceCustMchGrpGuid
    ,    W.MyServiceCustMchGuid
    ,    WMS.MyServiceMCHId
    ,    TPE.Name                        AS            PressExtractorName
    ,    TTT.Name                        AS            TransferTypeName
    ,   W.RatioDosingActive                AS            RatioDosingActive
    ,    W.EcolabWasherId                AS            EcolabWasherNumber
    ,    CAST(W.EndOfFormula AS SMALLINT)     AS            EndOfFormula
    ,    W.MyServiceLastSynchTime             AS            MyServiceLastSynchTime
    ,    CC.ControllerTypeId                 AS            ControllerTypeId
    ,    CT.Name                         AS            ControllerType
    ,    CC.ControllerModelId             AS            ControllerModelId
    ,    CM.Name                         AS            ControllerModel
    ,    W.NumberOfCompartmentsConveyorBelt
    ,    W.MinMachineLoad
    ,    W.MaxMachineLoad
    ,    W.ProgramSelectionByTime
    ,    W.WeightSelectionByTime
    ,    W.WeightSelectionByAnalogInput
    ,    W.TunInTomMode
    ,    COALESCE(W.SignalStopTunActive,'TRUE')        AS          SignalStopTunActive
    ,    COALESCE(W.SignalEjectionTunActive,'TRUE')    AS          SignalEjectionTunActive
    ,    W.DelayTimeForTunWashingPrograms
    ,    W.KannegiesserPressSpecialMode
    ,    W.ValveOutputsUsedAsTomSignal
    ,    W.ExtendedClockOrDataProtocol
    ,    W.WeightCorrectionFcc
    ,    W.FlowSwitchNumber            
    ,    W.WasherStopExternalSignal    
    ,    COALESCE(W.OnHoldWESignalActive,'TRUE')         AS           OnHoldWESignalActive        
    ,    W.WasherOnHoldSignalDelay    
    ,    W.WEInTOMMode                
    ,    W.ManifoldFlushTime            
    ,    W.L1                        
    ,    W.L2                        
    ,    W.L3                        
    ,    W.L4                        
    ,    W.L5                        
    ,    W.L6                        
    ,    W.L7                        
    ,    W.L8                        
    ,    W.L9                        
    ,    W.L10                        
    ,    W.L11                        
    ,    W.L12
    ,   MS.IsPony AS IsPony
    ,    W.PlantId
    ,    W.UseMe1OfGroup
    ,    W.UseMe2OfGroup
    ,    W.UsePumpOfGroup
    ,    W.WasherStopUseFinalExtracting
    ,    W.TemperatureAlarmYesNo
    ,    W.PhProbe
    ,    w.WeightCell
    ,    W.Temperature
    ,    W.WaterCounter    
    ,    W.DateAndTimeWhenBatchEjects            
    ,    W.AutoRinseDesamixAfter            
    ,    W.AutoRinseDesamix1For
    ,    W.AutoRinseDesamix2For
    ,    W.TemperatureAlarmProbe1
    ,    W.TemperatureAlarmProbe2
    ,    W.TemperatureAlarmProbe3
	,   CAST(W.DefaultIdleTime AS INT) AS   DefaultIdleTime
	,   W.ETechWasherNumber AS    ETechWasherNumber 
	,	W.SignalAcceptanceTime AS SignalAcceptanceTime
	,	W.KannegiesserDosageInPreparationTankMode	AS KannegiesserDosageInPreparationTankMode
	,	W.BatchOk AS BatchOk
	,	W.ExtractTimeForEOFSignal AS ExtractTimeForEOFSignal
	,	W.TargetTransferPerHour	 AS TransferPerHour

FROM    [TCD].WasherGroup                    WG
JOIN    [TCD].MachineGroup                    GT
    ON    WG.WasherGroupId                =            GT.Id
    AND    WG.EcolabAccountNumber            =            GT.EcolabAccountNumber
JOIN    [TCD].MachineSetup                    MS
    ON    WG.WasherGroupId                =            MS.GroupId
    AND    WG.EcolabAccountNumber            =            MS.EcoalabAccountNumber
JOIN    [TCD].Washer                        W
    ON    MS.WasherId                        =            W.WasherId
    AND    MS.EcoalabAccountNumber            =            W.EcoLabAccountNumber
JOIN    [TCD].WasherModelSize                WMS
    ON    W.ModelId                        =            WMS.WasherModelId
JOIN    [TCD].ConduitController                CC
    ON    MS.ControllerId                    =            CC.ControllerId
    AND    MS.EcoalabAccountNumber            =            CC.EcoalabAccountNumber
LEFT JOIN TCD.ControllerType CT  ON CT.Id = CC.ControllerTypeId  
LEFT JOIN TCD.ControllerModel CM ON CM.Id = CC.ControllerModelId
LEFT JOIN    [TCD].TunnelPressExtractor            TPE
    ON    W.PressExtractor                =            TPE.TunnelPressExtractorId        
LEFT JOIN    [TCD].TunnelTransferType            TTT
    ON    W.TransferType                    =            TTT.TunnelTransferTypeId
WHERE    GT.EcolabAccountNumber            =            @EcoLabAccountNumber
    AND    GT.GroupTypeId                       =            2
 
 AND (GT.Is_Deleted     =   'FALSE' OR GT.Is_Deleted = @Is_Deleted)
 AND WG.WasherGroupId    =   ISNULL(@WasherGroupId, WG.WasherGroupId)
 AND WG.EcolabAccountNumber   =   @EcoLabAccountNumber
 AND MS.EcoalabAccountNumber   =   @EcoLabAccountNumber
 AND (MS.IsDeleted     =   'FALSE' OR MS.IsDeleted = @Is_Deleted)
 AND (W.Is_Deleted     =   'FALSE' OR W.Is_Deleted = @Is_Deleted)
 AND W.WasherId      =   ISNULL(@WasherId, W.WasherId)
 AND W.EcoLabAccountNumber   =   @EcoLabAccountNumber




SET NOCOUNT OFF

END