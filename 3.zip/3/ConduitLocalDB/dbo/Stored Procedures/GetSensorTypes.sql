﻿
/*  
 ==========================================================================================  
 Purpose:  Fecthing the utility Types

 Author:  Premchand yelavarthi

 --------------------------------------------------------------  
 Aug-14-2014 ENT: Initial version.  
 ==========================================================================================  
*/ 
CREATE PROCEDURE [TCD].[GetSensorTypes]
AS  
  BEGIN 
      SET nocount ON; 

      SELECT Resourceid,name
      FROM   [TCD].[SensorTypeMaster]

  END 