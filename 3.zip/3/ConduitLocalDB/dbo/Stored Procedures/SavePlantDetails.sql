﻿CREATE PROCEDURE [TCD].[SavePlantDetails] (
@EcolabAccountNumber NVARCHAR(25)		,			--= NULL,	Making it as NOT-NULLable
@LanguageId          INT = NULL,
@CurrencyCode        NVARCHAR(1000)= NULL,
@Rate                NVARCHAR(100) = NULL,
@ExportPath          NVARCHAR(1000 )= NULL,
@DataLiveTime        INT = NULL,
@BudgetCustomer      BIT = NULL,
@UOMId               INT = NULL,
@Logo                VARBINARY(max) = NULL,
@UserID              INT, -- = NULL    /*Making this NON-NULLable, since we NEED this for audit
@AllowManualRewash   BIT = NULL	,
@DayId				 INT = NULL,
@StartTime			 TIME = NULL,
@EndTime			 TIME = NULL,
@EtechIpAddress			  NVARCHAR(100) = NULL,
@IsETechEnable			 BIT = NULL,
@OutputEcolabAccountNumber			NVARCHAR (1000)		=			NULL	OUTPUT	,
@LastModifiedTimestampAtCentral		DATETIME			=			NULL			,
@OutputLastModifiedTimestampAtLocal	DATETIME			=			NULL	OUTPUT
)
AS
BEGIN
SET nocount ON;


DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()

DECLARE
		@OutputList						AS	TABLE		(
		EcolabAccountNumber				NVARCHAR (1000)
	,	LastModifiedTimestamp			DATETIME
	)

SET		@OutputLastModifiedTimestampAtLocal			=			ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight SA0121
SET		@OutputEcolabAccountNumber					=			ISNULL(@OutputEcolabAccountNumber, NULL)					--SQLEnlight SA0121

IF	(
		@LastModifiedTimestampAtCentral				IS NOT	NULL
	AND
	NOT	EXISTS	(	SELECT	1
					FROM	TCD.Plant				P
					WHERE	P.EcolabAccountNumber	=	@EcolabAccountNumber
						AND	P.LastModifiedTime		=	@LastModifiedTimestampAtCentral
				)
	)
		BEGIN
				SET			@ErrorId				=	60000
				SET			@ErrorMessage			=	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
				RAISERROR	(@ErrorMessage, 16, 1)
				SET			@ReturnValue			=	-1
				RETURN		(@ReturnValue)
		END


--Proceed to update, since it's either a local call or Synch. call with synch. time matching
BEGIN
UPDATE P
SET    LanguageId = @LanguageId,
CurrencyCode =  @CurrencyCode ,
ExportPath =    @ExportPath,

DataLiveTime =@DataLiveTime,
BudgetCustomer = @BudgetCustomer,
UOMId =   @UOMId,

Rate =   @rate
,
Logo = @Logo
,LastModifiedByUserId = @UserID
, AllowManualRewash = @AllowManualRewash
,	P.LastModifiedTime			=			@CurrentUTCTime
,	P.StartTime	= @StartTime
,	P.EndTime = @EndTime
,	P.DayId	= @DayId
,	P.ETechIpAddress	= @EtechIpAddress
,	P.IsETechEnable = @IsETechEnable
OUTPUT
	inserted.EcolabAccountNumber	AS			EcolabAccountNumber
,	inserted.LastModifiedTime		AS			LastModifiedTimestamp
INTO
	@OutputList	(
	EcolabAccountNumber
,	LastModifiedTimestamp
)
FROM   [TCD].plant P
WHERE  p.ecolabaccountnumber = @EcolabAccountNumber
END


--Output the updated Id and the LastModifiedTime
SELECT	TOP 1	
		@OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp
	,	@OutputEcolabAccountNumber			=	O.EcolabAccountNumber
FROM	@OutputList							O




SET NOCOUNT OFF;
END