﻿/*  
 ==========================================================================================  
 Purpose:  Fetching the Device model list.  

 Author:  Neetha Allati  

 --------------------------------------------------------------  
 August-21-2014 ENT: Initial version.  
 ==========================================================================================  
*/ 

CREATE PROCEDURE [TCD].[GetDeviceModelList](@DeviceTypeId        INT = NULL, 
											@EcolabAccountNumber nvarchar(25)) 
AS 
  BEGIN 
	  SET nocount ON; 

	  Select [Id], 
			 [Description] 
	  FROM   [TCD].[DeviceModel] DM 
			 INNER JOIN TCD.RegionMaster RM 
					 ON DM.RegionID = RM.RegionId 
	  WHERE  [DeviceTypeId] = @DeviceTypeId 
			 AND IsDeleted = 0 
			 AND RM.RegionId IN (SELECT distinct RegionID 
								 from   TCD.Plant 
								 where  EcolabAccountNumber = @EcolabAccountNumber) 

	  SET nocount OFF; 
  END