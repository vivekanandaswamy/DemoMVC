﻿CREATE PROCEDURE TCD.GetMissingFields
(

@EcolabAccNumber NVARCHAR(25) = NULL

)

AS

BEGIN

       SELECT

       'Home > Setup > Dispenser Setup > ' + CC.TopicName AS [PathName]

       ,Replace(F.Label, 'SerialNumber', 'Serial Number') AS [FieldName]

       FROM 

       TCD.ControllerSetupData AS CSD

       INNER JOIN TCD.Field AS F ON F.Id = CSD.FieldId 

       INNER JOIN TCD.ConduitController CC ON CC.ControllerId = CSD.ControllerId

       WHERE
	    F.Label = 'SerialNumber' AND

      ( CSD.Value IS NULL OR CSD.Value = '')

       AND CC.IsDeleted <> 1 AND cc.ControllerId <> 0

       AND ( @EcolabAccNumber IS NULL OR CSD.EcolabAccountNumber = @EcolabAccNumber);

END