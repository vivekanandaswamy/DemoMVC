﻿CREATE PROCEDURE [TCD].[SaveSyncLoggingRequestDetails]
(
	@RequestData NVARCHAR(250),
	@RequestLabel NVARCHAR(100),
	@RequestType NVARCHAR(100),
	@NoOfRecords INT,
	@PlantId INT
)
AS
BEGIN
		INSERT INTO TCD.SyncLogRequests 
		(PlantId,RequestLabel,SyncLogParameterId,SyncLogParameterValue)
		VALUES(@PlantId, @RequestLabel, 1, @RequestType)

		INSERT INTO TCD.SyncLogRequests 
		(PlantId,RequestLabel,SyncLogParameterId,SyncLogParameterValue)
		VALUES(@PlantId, @RequestLabel, 2, @NoOfRecords)

		INSERT INTO TCD.SyncLogRequests 
		(PlantId,RequestLabel,SyncLogParameterId,SyncLogParameterValue)
		VALUES(@PlantId, @RequestLabel, 8, @RequestData)
END