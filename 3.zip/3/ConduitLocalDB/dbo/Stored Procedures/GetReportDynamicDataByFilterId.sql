
--exec [TCD].[GetReportDynamicDataByFilterId] @FilterId=10
CREATE PROCEDURE [TCD].[GetReportDynamicDataByFilterId]
        (
            @UserId INT = NULL,
            @RoleId INT = NULL,
            @RegionId Nvarchar(1000) = NULL,
            @CountryId Nvarchar(1000) = NULL,
            @IsLocal BIT = NULL,
            @PlantID Nvarchar(1000) = NULL,
            @IsCountry BIT = 0,
            @FilterId INT = NULL
        )   
AS 
SET NOCOUNT ON
BEGIN

    SELECT @PlantID = P.EcolabAccountNumber FROM TCD.Plant P

    DECLARE @PlantTable TABLE(PlantID Varchar(100))
    INSERT INTO @PlantTable EXEC [TCD].[CharlistToTable] @PlantID,','
    
      DECLARE @ResultTable TABLE
        (
        Id nvarchar(2000),
        Name nvarchar(300),
        TypeId Int
        )

    IF(@FilterId = 7)    --Filter Options for Ecolab Category
    BEGIN
    
    INSERT INTO @ResultTable (
            Id,
            Name,
            TypeId
             )
   SELECT CAST(FormulaSegmentID AS int) AS FormulaSegmentID,SegmentName AS FormulaSegmentName,7
  FROM TCD.FormulaSegments --WHERE Is_Deleted=0
    
    END

    IF(@FilterId = 9)   --Filter Options for Customers
    BEGIN
    INSERT INTO @ResultTable (
            Id,
            Name,
            TypeId
             )   
    SELECT 
    PC.CustomerId AS Id,
    PC.CustomerName AS Name,
    @FilterId
    FROM [TCD].[PlantCustomer] PC 
    WHERE PC.EcolabAccountNumber IN (SELECT PlantID FROM @PlantTable)
    
    END


     IF(@FilterId = 10)   --Filter Options for plant formulas
    BEGIN
   
    INSERT INTO @ResultTable (
            Id,
            Name,
            TypeId
             )  
      ----Append chain category+1000
  SELECT DISTINCT PM.ProgramID AS Formula,PM.Name AS Name ,10
  FROM TCD.ProgramMaster PM
  --INNER JOIN
  -- (
  -- --Chain plant
  -- SELECT PCP.PlantProgramId,PCP.PlantChainId,PCP.ChainTextileCategoryId,PCP.EcolabTextileCategoryId,
  -- PCP.FormulaSegmentId,PCP.EcolabSaturationId,CTC.TextileID,CTC.Name AS CategoryName
  -- FROM TCD.PlantChainProgram PCP 
  -- LEFT OUTER JOIN TCD.ChainTextileCategory CTC ON CTC.TextileId=PCP.ChainTextileCategoryId
  -- LEFT OUTER JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId=PCP.EcolabTextileCategoryId    
  -- )ChainPlant ON PM.PlantProgramID=ChainPlant.PlantProgramId
  --UNION
  --SELECT DISTINCT PM.ProgramID AS Formula,PM.Name AS Name ,10
  --FROM TCD.ProgramMaster PM
  --INNER JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId=PM.EcolabtextilecategoryID
    
    END
    
    IF(@FilterId = 23)   --Filter Options for Plant chain categories
      BEGIN

    --  --Append chain category+1000
     INSERT INTO @ResultTable (
            Id,
            Name,
            TypeId
             )  
   SELECT DISTINCT 
  CASE WHEN ChainPlant.TextileID IS NOT NULL 
	THEN ChainPlant.TextileID+1000
	ELSE ChainPlant.EcolabTextileCategoryId
  END AS ID,
  CASE WHEN ChainPlant.CategoryName IS NOT NULL 
	THEN ChainPlant.CategoryName
	ELSE ChainPlant.ECOLabCategoryName
  END AS Name, 
  23 AS TypeID
  --ChainPlant.TextileID+1000 AS ID 
  --,ChainPlant.CategoryName Name,23
   FROM TCD.ProgramMaster PM
   INNER JOIN
    (
    --Chain plant
    SELECT PCP.PlantProgramId,PCP.PlantChainId,PCP.ChainTextileCategoryId,PCP.EcolabTextileCategoryId,
    PCP.FormulaSegmentId,PCP.EcolabSaturationId,CTC.TextileID,CTC.Name AS CategoryName, ETC.CategoryName AS ECOLabCategoryName
    FROM TCD.PlantChainProgram PCP 
    LEFT OUTER JOIN TCD.ChainTextileCategory CTC ON ISnull( CTC.TextileId,0)=ISnull(PCP.ChainTextileCategoryId,0)
    LEFT OUTER JOIN TCD.EcolabTextileCategory ETC ON ISnull(ETC.TextileId,0)=ISnull(PCP.EcolabTextileCategoryId,0)
    )ChainPlant ON PM.PlantProgramID=ChainPlant.PlantProgramId
   UNION
   SELECT DISTINCT ETC.TextileID AS FormulaCategoryID,ETC.CategoryName ,23
   FROM TCD.ProgramMaster PM
   INNER JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId=PM.EcolabtextilecategoryID
      END

     IF(@FilterId = 24)   --Filter Options for plant chain programs
      BEGIN

   INSERT INTO @ResultTable (
            Id,
            Name,
            TypeId
             )  
    SELECT 
    PC.PlantProgramId AS Id,
    PC.PlantProgramName AS Name,
    @FilterId
    FROM [TCD].[PlantChainProgram] PC
        WHERE PC.PlantChainId IN (SELECT P.PlantChainId FROM TCD.PLANT P WHERE P.EcolabAccountNumber IN (SELECT PlantID FROM @PlantTable))     
     OR PC.PlantChainId IS NULL
      END

      IF(@FilterId = 11)   --Filter Options for dispencer
      BEGIN
  
      INSERT INTO @ResultTable (
            Id,
            Name,
            TypeId
             )
   SELECT 
        PC.ControllerId AS Id,
        PC.Name AS Name,
        @FilterId
    FROM TCD.ConduitController PC
        WHERE PC.EcoalabAccountNumber IN (SELECT PlantID FROM @PlantTable)
     END  

     IF(@FilterId = 12)   --Filter Options for ALARM
      BEGIN
  
      INSERT INTO @ResultTable (
            Id,
            Name,
            TypeId
             )
   SELECT DISTINCT
        AGMVCMT.AlarmGroupMasterId AS Id,
        AGM.Description AS Name,
        @FilterId
    FROM TCD.AlarmGroupMaster AGM
    JOIN TCD.AlarmGroupMsterVsControllerModelType AGMVCMT ON  AGMVCMT.AlarmGroupMasterId = AGM.AlarmGroupMasterId
        
     END  


       SELECT
        DISTINCT
      Id,
      Name,
      TypeId
       FROM @ResultTable


END