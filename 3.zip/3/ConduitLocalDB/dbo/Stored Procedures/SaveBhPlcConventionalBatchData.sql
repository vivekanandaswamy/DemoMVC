﻿CREATE PROCEDURE [TCD].[SaveBhPlcConventionalBatchData]
(
@WasherId INT=NULL											
,@OperationalCount INT=NULL
,@CurrentFormula int=NULL
,@CurrentInjection	int=NULL
,@DateTimeStamp VARCHAR(50)=NULL
,@IsNewBatch bit = 0 
,@BatchId INT OUTPUT
)
AS
SET NOCOUNT ON
BEGIN

	DECLARE @EcolabWaherId INT
			,@EndofFormula INT=128 -- This value is sent through the application.
			,@StandardWeight VARCHAR(100)
			,@CurrencyCode VARCHAR(50)					
			,@MachineInternalId INT
			,@GroupId INT	
	
	SET		@BatchId			=			ISNULL(@BatchId, NULL)			--SQLEnlight SA0121
	SET		@CurrentInjection	=			ISNULL(@CurrentInjection, NULL)	--SQLEnlight SA0029

	SELECT @EcolabWaherId=WasherId FROM TCD.Washer WHERE WasherId= @WasherId
	
BEGIN TRANSACTION
	BEGIN TRY
	IF (@IsNewBatch = 1 )
			BEGIN					
			SELECT DISTINCT @StandardWeight =  cps.NominalLoad 
							,@CurrencyCode = Pl.CurrencyCode 

			FROM TCD.Washer Ws
				INNER JOIN TCD.MachineSetup MST ON MST.WasherId = Ws.WasherId
				INNER JOIN TCD.WasherGroup WG ON WG.WasherGroupId = MST.GroupId
				INNER JOIN TCD.WasherGroupType WGT ON WGT.WasherGroupTypeId = WG.WasherGroupTypeId
				INNER JOIN TCD.WasherProgramSetup CPS ON CPS.WasherGroupId = WG.WasherGroupId
				INNER JOIN TCD.WasherDosingSetup CDS ON CDS.WasherProgramSetupId = CPS.WasherProgramSetupId
				INNER JOIN TCD.WasherDosingProductMapping CDPM ON CDPM.WasherDosingSetupId = CDS.WasherDosingSetupId
				INNER JOIN TCD.Plant Pl on Pl.EcolabAccountNumber=Ws.EcoLabAccountNumber
			WHERE Ws.WasherId=@WasherId AND CPS.ProgramNumber=@CurrentFormula

			INSERT INTO TCD.BatchData(
					ControllerBatchId ,
					EcolabWasherId,
					GroupId,
					MachineInternalId,
					StartDate,
					EndDate,
					ProgramNumber,
					ActualWeight,
					StandardWeight,
					CurrencyCode)

		SELECT DISTINCT  0
						,@EcolabWaherId
						,MST.GroupId
						,Mst.MachineInternalId
						,@DateTimeStamp
						,NULL
						,@CurrentFormula
						,NULL
						,@StandardWeight[StandardWeight] 
						,@CurrencyCode[CurrencyCode] 						
		FROM  [TCD].Washer Ws
		INNER JOIN [TCD].MachineSetup MST ON MST.WasherId = Ws.WasherId
		INNER JOIN [TCD].WasherGroup WG ON WG.WasherGroupId = MST.GroupId
		INNER JOIN [TCD].WasherGroupType WGT ON WGT.WasherGroupTypeId = WG.WasherGroupTypeId
		WHERE Ws.WasherId=@WasherId 

	SET @BatchId=SCOPE_IdENTITY()	

		INSERT INTO TCD.BatchProductData(BatchId,StepCompartment,ProductId,ActualQuantity,StandardQuantity,Price)
		SELECT   @BatchId
				,NULL--CDS.StepNumber 
				,CDPM.ProductId
				,NULL
				,CDPM.Quantity AS StandardQuantity
				,NULL
		FROM  [TCD].Washer WS
		INNER JOIN [TCD].MachineSetup MST ON MST.WasherId = ws.WasherId
		INNER JOIN [TCD].WasherGroup WG ON WG.WasherGroupId = MST.GroupId
		INNER JOIN [TCD].WasherGroupType WGT ON WGT.WasherGroupTypeId = WG.WasherGroupTypeId
		INNER JOIN [TCD].WasherProgramSetup CPS ON CPS.WasherGroupId = WG.WasherGroupId
		INNER JOIN [TCD].WasherDosingSetup CDS ON CDS.WasherProgramSetupId = CPS.WasherProgramSetupId
		LEFT JOIN [TCD].WasherDosingProductMapping CDPM ON CDPM.WasherDosingSetupId = CDS.WasherDosingSetupId
		WHERE Ws.WasherId=@WasherId AND CPS.ProgramNumber=@CurrentFormula
	END	

	ELSE IF(@CurrentFormula = @EndofFormula)
		BEGIN
			IF EXISTS (SELECT TOP 1 * FROM TCD.BatchData WHERE  EcolabWasherId =@EcolabWaherId AND EndDate IS NULL ORDER BY StartDate DESC  )
				BEGIN
					DECLARE @RemoveBtchId INT 
					SELECT TOP 1 @RemoveBtchId =batchId FROM  [TCD].batchdata WHERE EcolabWasherId =@EcolabWaherId AND EndDate IS NULL ORDER BY EndDate ASC 
						UPDATE TCD.BatchData
						SET EndDate= @DateTimeStamp
						WHERE  BatchId=@RemoveBtchId

			END
	END

			SELECT @MachineInternalId=MachineInternalId,@GroupId=GroupId FROM TCD.MachineSetup WHERE WasherId=@WasherId
			--INSERT INTO TCD.WasherReading(GroupId,MachineInternalId,WasherId,ProgramNumber,CurrentInjection,OperationCounter,DosingAmount,CreatedDate) VALUES(
			--@MachineInternalId , @GroupId, @WasherId , @CurrentFormula,@CurrentInjection,@OperationalCount, NULL,@DateTimeStamp )

		COMMIT TRANSACTION;
	END TRY

	BEGIN CATCH
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;
		SELECT  @ErrorMessage = ERROR_MESSAGE(),
				@ErrorSeverity = ERROR_SEVERITY(),
		  		@ErrorState = ERROR_STATE();
		RAISERROR (	@ErrorMessage, -- Message text.
					@ErrorSeverity, -- Severity.
					@ErrorState -- State.
					);

		ROLLBACK TRANSACTION;
	END CATCH;
END