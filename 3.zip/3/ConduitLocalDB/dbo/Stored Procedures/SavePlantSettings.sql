﻿CREATE PROCEDURE [TCD].[SavePlantSettings]
(
@PlantId			 NVARCHAR(1000)		,
@IPAddress	         NVARCHAR(1000)		,
@PortNumber		     NVARCHAR(1000)		,
@PlantVersion		 NVARCHAR(25)		
)
AS
BEGIN
SET nocount ON;
DECLARE @UpdateFlag BIT = 1

IF @IPAddress IS NULL OR @IPAddress = '' OR @PortNumber IS NULL OR @PortNumber = ''
BEGIN
	SET @UpdateFlag = 0
END
ELSE
BEGIN
IF NOT EXISTS (SELECT 1 FROM TCD.PlantSettings WHERE PlantId=@PlantId)
	BEGIN
		INSERT INTO TCD.PlantSettings
		(PlantId, IPAddress, PortNumber, PlantVersion)
		VALUES(@PlantId,@IPAddress, @PortNumber, @PlantVersion)
	END
ELSE
	BEGIN
		IF EXISTS(SELECT 1 FROM TCD.PlantSettings WHERE PlantId=@PlantId AND IpAddress = @IPAddress AND NodeId IS NOT NULL)
			BEGIN
				SET @UpdateFlag = 0
			END

		UPDATE TCD.PlantSettings 
		SET IPAddress=@IPAddress, PortNumber=@PortNumber 
		WHERE PlantId=@PlantId
	END
END	
	SELECT @UpdateFlag

SET NOCOUNT OFF;
END
