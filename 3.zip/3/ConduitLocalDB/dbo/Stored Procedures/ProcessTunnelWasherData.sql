﻿CREATE PROCEDURE TCD.ProcessTunnelWasherData(
 @Washerid		 INT, 
 @Xmltags		 XML, 
 @Redflagshiftid INT OUTPUT)
AS
BEGIN
	DECLARE @Batchid					 INT, 
			@Ecolabwasherid				 INT, 
			@Currencycode				 VARCHAR(50), 
			@Machineinternalid			 INT, 
			@Groupid					 INT, 
			@Prveformula				 INT, 
			@Quantity					 INT, 
			@Maxwashertgroupcapacity	 INT, 
			@Prevbatchid				 INT, 
			@Prevloadid					 INT, 
			@Existedloadid				 INT, 
			@Numberofcompartments		 INT, 
			@Programmasterid			 INT, 
			@Nominalload				 DECIMAL(10, 2), 
			@Maxload					 DECIMAL(10, 2), 
			@Standardweight				 DECIMAL(10, 2), 
			@Plantwashernumber			 INT, 
			@Currentday					 DATE			= CAST(GETUTCDATE() AS DATE), 
			@Temptunneltimestamp		 DATETIME2, 
			@Controllerid				 INT, 
			@Currentholdsignal			 INT, 
			@Totalruntime				 INT, 
			@Batchgroupid				 INT, 
			@Batchformula				 INT, 
			@Batchstartdate				 DATETIME2, 
			@Batchenddate				 DATETIME2, 
			@Holdtime					 INT, 
			@Ctetempbatchtunnelwashsteps INT, 
			@Ctetemtunnelwashsetps		 INT, 
			@Prevformula				 INT, 
			@Prevstepcompartment		 INT, 
			@Batchstandardwaterusage	 INT, 
			@Batchactualwaterusage		 INT, 
			@Batchwaterusageprice		 DECIMAL(10, 2), 
			@Batchutilityprice			 DECIMAL(10, 2), 
			@Batchwatertype				 INT, 
			@Extratime					 INT, 
			@Targetturntime				 INT, 
			@Ecolabaccountnumber		 NVARCHAR(25)	= NULL, 
			@Alarmgroupmasterid			 INT, 
			@Partitionon				 SMALLDATETIME, 
			@Stdinjectionsteps			 INT, 
			@Stdwashsteps				 INT, 
			@Ecolabtextilecategoryid	 INT, 
			@Chaintextilecategoryid		 INT, 
			@Formulasegmentid			 INT, 
			@Ecolabsaturationid			 INT, 
			@Plantprogramid				 INT, 
			@Previousshiftid			 INT, 
			@Currentshiftid				 INT, 
			@Etechlastdroppedat			 DATETIME2, 
			@Customercodes				 VARCHAR(100);
	SELECT 
		   @Extratime = 0;
	SELECT DISTINCT 
		   @Numberofcompartments = MST.NumberOfComp, 
		   @Ecolabwasherid = Ws.EcolabWasherId
		FROM TCD.Washer AS Ws
			 INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = Ws.WasherId
		WHERE Ws.WasherId = @Washerid
			  AND Ws.Is_Deleted = 0;
	IF EXISTS
			 (SELECT 
					 *
				  FROM TEMPDB.DBO.SYSOBJECTS AS o
				  WHERE o.xtype IN('U')
			  AND o.id = OBJECT_ID(N'tempdb..#XmlTagsTable')
			 )
		BEGIN
			DROP TABLE #XmlTagsTable;
		END;
	CREATE TABLE #XmlTagsTable
	(
		 CurrentFormula			 INT, 
		 CurretnInjection		 INT, 
		 CurrentOperationCounter INT, 
		 Eof					 INT, 
		 TunnelTimeStamp		 DATETIME2, 
		 OnHold					 BIT, 
		 CompartmentId			 INT, 
		 CompartmentLoadId		 INT, 
		 CompartmentFormulaId	 INT, 
		 ReceivedTime			 DATETIME2, 
		 AutoWeightEntryActive	 VARCHAR(10), 
		 AutoWeightEntryWeight	 INT, 
		 IsFormulaModified		 BIT, 
		 IsHoldSignalModified	 BIT, 
		 IsStopSinalModified	 BIT, 
		 StopSignal				 INT, 
		 RatioDosingEnabled		 INT, 
		 ETechLastDropped		 VARCHAR(100), 
		 CustomerCodes			 VARCHAR(100)
	);
	INSERT INTO #XmlTagsTable
	(
		   CurrentFormula, 
		   CurretnInjection, 
		   CurrentOperationCounter, 
		   Eof, 
		   TunnelTimeStamp, 
		   OnHold, 
		   CompartmentId, 
		   CompartmentLoadId, 
		   CompartmentFormulaId, 
		   ReceivedTime, 
		   AutoWeightEntryActive, 
		   AutoWeightEntryWeight, 
		   IsFormulaModified, 
		   IsHoldSignalModified, 
		   IsStopSinalModified, 
		   StopSignal, 
		   RatioDosingEnabled, 
		   ETechLastDropped, 
		   CustomerCodes
	)			
	
		   -- Populate tempdata from xml
		   SELECT 
				  T.c.value('../@CurrentFormula', 'INT') AS CurrentFormula, 
				  T.c.value('../@CurrentInjection', 'INT') AS CurretnInjection, 
				  T.c.value('../@CurrentOperationCounter', 'INT') AS CurrentOperationCounter, 
				  T.c.value('../@Eof', 'INT') AS EndofFormula, 
				  T.c.value('../@TimeStamp', 'VARCHAR(100)') AS TunnelTimeStamp, 
				  T.c.value('../@OnHold', 'VARCHAR(100)') AS OnHold, 
				  T.c.value('@CompartmentId', 'INT') AS CompartmentId, 
				  T.c.value('@LoadId', 'INT') AS CompartmentLoadId, 
				  T.c.value('@FormulaId', 'INT') AS CompartmentFormulaId, 
				  T.c.value('@TimeStamp', 'VARCHAR(100)') AS DateTimeStamp, 
				  T.c.value('../@Awea', 'VARCHAR(10)') AS AutoWeightEntryActive, 
				  T.c.value('../@Awew', 'INT') AS AutoWeightEntryWeight, 
				  T.c.value('../@IsFormulaModified', 'BIT') AS IsFormulaModified, 
				  T.c.value('../@IsHoldSignalModified', 'BIT') AS IsHoldSignalModified, 
				  T.c.value('../@IsStopSinalModified', 'BIT') AS IsStopSinalModified, 
				  T.c.value('../@StopSignal', 'INT') AS StopSignal, 
				  T.c.value('../@RATA', 'INT') AS RatioDosingEnabled, 
				  T.c.value('../@ETechLastDroppedAt', 'VARCHAR(100)') AS ETechLastDropped, 
				  T.c.value('../@CustomerCodes', 'VARCHAR(100)') AS CustomerCodes
			   FROM @Xmltags.nodes('/Tunnel/Compartment') AS T(c)
			   WHERE T.c.value('@LoadId', 'VARCHAR(100)') != 0
AND T.c.value('@CompartmentId', 'INT') <= @Numberofcompartments;
	--ETech last dropped 
	SELECT 
		   @Etechlastdroppedat = CONVERT( DATETIME, ETechLastDropped), 
		   @Customercodes = CustomerCodes
		FROM #XmlTagsTable;
	IF EXISTS
			 (SELECT 
					 1 FROM #XmlTagsTable WHERE IsHoldSignalModified = 1
			 )
		BEGIN
			SELECT 
				   @Currentholdsignal = Id FROM TCD.ConduitParameters WHERE Name = 'HoldSignal';
			INSERT INTO TCD.WasherReading
			(
				   WasherId, 
				   ParameterId, 
				   ParameterValue, 
				   DateTimeStamp, 
				   EcolabWasherId
			)
				   SELECT 
						  @Washerid, 
						  @Currentholdsignal, 
						  OnHold, 
						  ReceivedTime, 
						  @Ecolabwasherid
					   FROM #XmlTagsTable;
		END;
	IF EXISTS
			 (SELECT 
					 1 FROM #XmlTagsTable WHERE IsStopSinalModified = 1
			 )
		BEGIN
			INSERT INTO TCD.WasherReading
			(
				   WasherId, 
				   ParameterId, 
				   ParameterValue, 
				   DateTimeStamp, 
				   EcolabWasherId
			)
				   SELECT 
						  @Washerid, 
						  12, 
						  StopSignal, 
						  ReceivedTime, 
						  @Ecolabwasherid FROM #XmlTagsTable;
		END;
	IF EXISTS
			 (SELECT 
					 1 FROM #XmlTagsTable WHERE IsFormulaModified = 1
			 )
		BEGIN
	
			-- Start find missing load id form xml	and set end date for corresponding enddates in the database
			DECLARE @Tempexisitingloadids TABLE
			(
				 ExstingLoadId INT, 
				 ExistsBatchId INT
			);
			INSERT INTO @Tempexisitingloadids
			(
				   ExstingLoadId, 
				   ExistsBatchId
			)
				   SELECT 
						  Bd.ControllerBatchId, 
						  Bd.BatchId
					   FROM TCD.BatchData AS Bd					
					   --INNER JOIN TCD.BatchWashStepData Bwsd on Bwsd.BatchId=Bd.BatchId
					   WHERE Bd.MachineId = @Washerid
							 AND Bd.EndDate IS NULL
					   ORDER BY 
								Bd.StartDate DESC;
			SELECT 
				   @Temptunneltimestamp =
										  (SELECT 
												  T.c.value('./@TimeStamp', 'VARCHAR(100)') AS TunnelTimeStamp
											   FROM @Xmltags.nodes('/Tunnel') AS T(c)
										  );
			DECLARE @Tempbatchstepis TABLE
			(
				 StepBatchId INT
			);
			INSERT INTO @Tempbatchstepis
			(
				   StepBatchId
			)
				   SELECT 
						  ExistsBatchId
					   FROM @Tempexisitingloadids
					   WHERE ExstingLoadId NOT IN
												 (SELECT 
														 CompartmentLoadId FROM #XmlTagsTable
												 );
			SELECT 
				   @Prevstepcompartment = StepCompartment, 
				   @Prevbatchid = BatchID
				FROM TCD.BatchWashStepData
				WHERE BatchId IN
								(SELECT 
										StepBatchId FROM @Tempbatchstepis
								)
					  AND EndTime IS NULL;
			UPDATE TCD.BatchWashStepData
			  SET 
				  EndTime = @Temptunneltimestamp
				WHERE 
					  BatchId IN
								(SELECT 
										StepBatchId FROM @Tempbatchstepis
								)
					  AND EndTime IS NULL;
			DECLARE @Batchshiftid INT;
			DECLARE @Shiftstartdatetemp TABLE
			(
				 ShiftId		INT, 
				 ShiftName		NVARCHAR(50), 
				 ShiftStartdate DATETIME
			);
			INSERT INTO @Shiftstartdatetemp
			(
				   ShiftId, 
				   ShiftName, 
				   ShiftStartdate
			)
			EXEC TCD.GetShiftStartDate 
				 @Temptunneltimestamp;
			SELECT 
				   @Batchshiftid = ssdt.ShiftId
				FROM @Shiftstartdatetemp AS ssdt
				ORDER BY 
						 ssdt.ShiftStartdate;
			-- Updating Batches moved out of the tunnel
			UPDATE TCD.BatchData
			  SET 
				  EndDate = @Temptunneltimestamp, 
				  EndDateFormula = @Temptunneltimestamp, 
				  ShiftId = @Batchshiftid, 
				  SyncReady = 1
				WHERE 
					  BatchId IN
								(SELECT 
										StepBatchId FROM @Tempbatchstepis
								);
			--End find missing load id form xml	 and set end date for corresponding enddates in the database
	 
			--Start HoldTime Calculation
			SELECT 
				   @Batchgroupid = GroupId, 
				   @Batchformula = ProgramNumber, 
				   @Batchstartdate = StartDate, 
				   @Batchenddate = EndDate
				FROM TCD.BatchData
				WHERE BatchId IN
								(SELECT 
										StepBatchId FROM @Tempbatchstepis
								);
			SELECT 
				   @Totalruntime = TotalRunTime
				FROM TCD.TunnelProgramSetup
				WHERE WasherGroupId = @Batchgroupid
					  AND ProgramNumber = @Batchformula;
			INSERT TCD.BatchParameters
			(
				   BatchId, 
				   EcolabWasherId, 
				   ParameterId, 
				   ParameterValue, 
				   PartitionOn
			)
				   SELECT 
						  StepBatchId, 
						  @Ecolabwasherid, 
						  17, 
						  DATEDIFF(SECOND, @Batchstartdate, @Batchenddate) - @Totalruntime, 
						  bd.partitionon
					   FROM @Tempbatchstepis, 
							TCD.BatchData AS bd
					   WHERE bd.BatchId = [@TempBatchStepIs].StepBatchId
							 AND [@TempBatchStepIs].StepBatchId NOT IN
																	  (SELECT 
																			  BATCHID FROM TCD.BatchParameters AS BP WHERE BP.ParameterId = 17
																	  );

			--End HoldTime Calculation
			--Start Good or Bad Injection in BatchDataTable
			IF EXISTS
					 (SELECT TOP 1 
							 *
						  FROM TCD.BatchData
						  WHERE BatchId = @Prevbatchid
								AND MachineId = @Washerid
								AND EndDate IS NOT NULL
						  ORDER BY 
								   StartDate DESC
					 )
				BEGIN
					WITH CteTempBatchTunnelStepData(
						 InjectionsCount, 
						 BatchId, 
						 ProgramNumber)
						 AS(SELECT DISTINCT 
								   Bws.StepCompartment, 
								   BD.BatchId, 
								   Bd.ProgramNumber
								FROM TCD.BatchData AS Bd
									 INNER JOIN TCD.BatchWashStepData AS Bws ON Bws.BatchId = Bd.BatchId
								WHERE Bd.BatchId = @Prevbatchid)
						 SELECT 
								@Ctetemtunnelwashsetps = COUNT(CTE1.InjectionsCount)
							 FROM CteTempBatchTunnelStepData AS CTE1
								  INNER JOIN TCD.BatchData AS Bd ON Bd.BatchId = CTE1.BatchId
							 WHERE Bd.BatchId = @Batchid;
					WITH CteTempBatchInjections(
						 InjectionsCount, 
						 ProgramNumber)
						 AS(SELECT DISTINCT 
								   Tds.CompartmentNumber, 
								   Tps.ProgramNumber
								FROM TCD.TunnelProgramSetup AS Tps
									 INNER JOIN TCD.TunnelDosingSetup AS Tds ON Tds.TunnelProgramSetupId = Tps.TunnelProgramSetupId
									 INNER JOIN TCD.TunnelDosingProductMapping AS Tdpm ON Tdpm.TunnelDosingSetupId = Tds.TunnelDosingSetupId
									 INNER JOIN TCD.ControllerEquipmentSetup AS Ces ON Ces.ControllerEquipmentSetupId = Tdpm.
									 ControllerEquipmentSetupId
								WHERE Tps.ProgramNumber = @Prevformula)
						 SELECT 
								@Ctetempbatchtunnelwashsteps = COUNT(CTE2.InjectionsCount)
							 FROM CteTempBatchInjections AS CTE2;
					INSERT Tcd.BatchParameters
					(
						   BatchId, 
						   EcolabWasherId, 
						   ParameterId, 
						   ParameterValue, 
						   PartitionOn
					)
						   SELECT 
								  @Prevbatchid, 
								  @Ecolabwasherid, 
								  18,
								  CASE
									  WHEN @Ctetempbatchtunnelwashsteps = @Ctetemtunnelwashsetps
									  THEN 1
									  WHEN @Ctetempbatchtunnelwashsteps != @Ctetemtunnelwashsetps
									  THEN 3
								  END, 
								  (SELECT 
										  PartitionOn
									   FROM TCD.BatchData
									   WHERE BatchId = @Prevbatchid
											 AND MachineId = @Washerid
								  );
				END;
			-- End Good or Bad Injection in BatchDataTable
			-- Fetching data from cursor
			DECLARE @Mycursor CURSOR;
			SET @Mycursor = CURSOR FAST_FORWARD
			FOR SELECT 
					   CurrentFormula, 
					   CurretnInjection, 
					   CurrentOperationCounter, 
					   Eof, 
					   TunnelTimeStamp, 
					   OnHold, 
					   CompartmentId, 
					   CompartmentLoadId, 
					   CompartmentFormulaId, 
					   ReceivedTime, 
					   AutoWeightEntryActive, 
					   AutoWeightEntryWeight, 
					   IsFormulaModified, 
					   IsHoldSignalModified, 
					   IsStopSinalModified, 
					   StopSignal, 
					   RatioDosingEnabled
					FROM #XmlTagsTable
					ORDER BY 
							 CompartmentId ASC;
			DECLARE @Curcurrentformula			INT, 
					@Curcurretninjection		INT, 
					@Curcurrentoperationcounter INT, 
					@Cureof						INT, 
					@Curtunneltimestamp			DATETIME2, 
					@Curonhold					BIT, 
					@Curcompartmentid			INT, 
					@Curcompartmentloadid		INT, 
					@Curcompartmentformulaid	INT, 
					@Curreceivedtime			DATETIME2, 
					@Autoweightentryactive		VARCHAR(10), 
					@Autoweightentryweight		INT, 
					@Isformulamodified			BIT, 
					@Isholdsignalmodified		BIT, 
					@Isstopsinalmodified		BIT, 
					@Stopsignal					INT, 
					@Ratiodosingenabled			INT;
			OPEN @Mycursor;
			FETCH NEXT FROM @Mycursor INTO @Curcurrentformula, 
										   @Curcurretninjection, 
										   @Curcurrentoperationcounter, 
										   @Cureof, 
										   @Curtunneltimestamp, 
										   @Curonhold, 
										   @Curcompartmentid, 
										   @Curcompartmentloadid, 
										   @Curcompartmentformulaid, 
										   @Curreceivedtime, 
										   @Autoweightentryactive, 
										   @Autoweightentryweight, 
										   @Isformulamodified, 
										   @Isholdsignalmodified, 
										   @Isstopsinalmodified, 
										   @Stopsignal, 
										   @Ratiodosingenabled;
			WHILE @@Fetch_Status = 0
				BEGIN
					IF @Isformulamodified != 0
						BEGIN
							IF @Curcurrentformula != @Cureof
							   AND @Curcurretninjection = 0
							   AND @Curcurrentoperationcounter = 0
								BEGIN
									SELECT DISTINCT 
										   @Machineinternalid = Mst.MachineInternalId, 
										   @Groupid = Mst.GroupId, 
										   @Controllerid = Ctrl.ControllerId
										FROM TCD.Washer AS Ws
											 INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = Ws.WasherId
											 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
											 INNER JOIN TCD.WasherGroupType AS WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
											 INNER JOIN TCD.ConduitController AS Ctrl ON Ctrl.ControllerId = Mst.ControllerId
										WHERE Ws.WasherId = @Washerid;
									SELECT DISTINCT 
										   @Programmasterid = Wps.ProgramId, 
										   @Nominalload = Wps.NominalLoad, 
										   @Maxload = Ws.MaxLoad, 										    
										   @Targetturntime = 3600 / (Wps.TotalRunTime / Mst.NumberofComp)
										FROM TCD.Washer AS Ws
											 INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = Ws.WasherId
											 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
											 INNER JOIN TCD.WasherGroupType AS WgT ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
											 INNER JOIN TCD.TunnelProgramSetup AS Wps ON Wps.WasherGroupId = Wg.WasherGroupId
											 INNER JOIN TCD.Plant AS Pl ON Pl.EcolabAccountNumber = Ws.EcoLabAccountNumber
										WHERE Ws.WasherId = @Washerid
											  AND Wps.ProgramNumber = @Curcurrentformula
											  AND Wps.Is_Deleted = 0;
									SELECT @CurrencyCode = Pl.CurrencyCode FROM TCD.Plant Pl
									SELECT 
										   @Plantwashernumber = plantwashernumber FROM tcd.washer WHERE washerid = @Washerid;
									SELECT 
										   @Maxwashertgroupcapacity = MAX(ws.MaxLoad)
										FROM TCD.Washer AS WS
											 INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = ws.WasherId
											 INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
										WHERE Mst.GroupId = @Groupid;
									SELECT 
										   @Standardweight = @Nominalload;
									SELECT 
										   @Autoweightentryweight = CASE @Autoweightentryactive
																		WHEN 'False'
																		THEN @Standardweight
																		ELSE @Autoweightentryweight
																	END;
									SELECT 
										   @Machineinternalid, 
										   @Groupid, 
										   @Programmasterid, 
										   @Nominalload, 
										   @Washerid, 
										   @Curcurrentformula, 
										   @Prevbatchid;
									SELECT 
										   @Curcurrentformula AS CurCurrentFormula, 
										   @Curcurretninjection AS CurCurretnInjection, 
										   @Curcurrentoperationcounter AS CurCurrentOperationCounter, 
										   @Cureof AS CurEof, 
										   @Curtunneltimestamp AS CurTunnelTimeStamp, 
										   @Curonhold AS CurOnHold, 
										   @Curcompartmentid AS CurCompartmentId, 
										   @Curcompartmentloadid AS CurCompartmentLoadId, 
										   @Curcompartmentformulaid AS CurCompartmentFormulaId, 
										   @Curreceivedtime AS CurReceivedTime, 
										   @Autoweightentryactive AS AutoWeightEntryActive, 
										   @Autoweightentryweight AS AutoWeightEntryWeight, 
										   @Isformulamodified AS IsFormulaModified;
									IF @Curcompartmentformulaid > 0
										BEGIN
											UPDATE TCD.ConduitController
											  SET 
												  LastConnectedTime = GETUTCDATE()
												WHERE 
													  ControllerId = @Controllerid;
										END;
									IF NOT EXISTS
												 (SELECT TOP 1 
														 *
													  FROM TCD.BatchData
													  WHERE MachineId = @Washerid
															AND StartDate = @Curtunneltimestamp
												 )
										BEGIN
											DECLARE @Shiftstartdate TABLE
											(
												 ShiftId		INT, 
												 ShiftName		NVARCHAR(50), 
												 ShiftStartdate DATETIME
											);
											INSERT INTO @Shiftstartdate
											(
												   ShiftId, 
												   ShiftName, 
												   ShiftStartdate
											)
											EXEC TCD.GetShiftStartDate 
												 @Curtunneltimestamp;
											--Start Rollup for previous completed shift
											IF CAST(@Curtunneltimestamp AS DATE) < CAST(GETUTCDATE() AS DATE)
												BEGIN
													SELECT TOP 1 
														   @Previousshiftid = ShiftId
														FROM TCD.BatchData
														WHERE MachineId = @Washerid
														ORDER BY 
																 StartDate DESC;
													SELECT TOP 1 
														   @Currentshiftid = ShiftId FROM @Shiftstartdate;
													IF @Currentshiftid != @Previousshiftid
														BEGIN
															EXEC TCD.ProductionShiftDataRollup 
																 @Previousshiftid, 
																 @Redflagshiftid OUTPUT;
															IF @Redflagshiftid IS NULL
																BEGIN
																	SET @Redflagshiftid = @Previousshiftid;
																END;
														END;
												END;
											--End Rollup for previous completed shift
											--Start Getting InjectionCount,StepCount And ProductCount
											SELECT 
												   @Stdinjectionsteps = COUNT(tdpm.TunnelDosingSetupId), 
												   @Stdwashsteps = COUNT(DISTINCT tds.TunnelDosingSetupId) - COUNT(tdpm.TunnelDosingSetupId)
												FROM TCD.TunnelDosingProductMapping AS tdpm
													 RIGHT JOIN tcd.TunnelDosingSetup AS tds ON tdpm.TunnelDosingSetupId = tds.
													 TunnelDosingSetupId
												WHERE tds.GroupId = @Groupid
													  AND tds.ProgramNumber = @Curcurrentformula;
											--Start-----ProgramMasterID logic for PlantChainProgram
											SELECT 
												   @Plantprogramid = pm.PlantProgramId, 
												   @Ecolabtextilecategoryid = pm.EcolabTextileCategoryId, 
												   @Chaintextilecategoryid = pm.ChainTextileId, 
												   @Formulasegmentid = pm.FormulaSegmentId, 
												   @Ecolabsaturationid = pm.EcolabSaturationId
												FROM TCD.ProgramMaster AS pm
												WHERE pm.ProgramId = @Programmasterid
													  AND pm.Is_Deleted = 0;
											IF @Plantprogramid <> 0
											   AND @Plantprogramid IS NOT NULL
												BEGIN
													--Assign value from plantchainprogram table based on plantprogramId
													SELECT 
														   @Ecolabtextilecategoryid = pcp.EcolabTextileCategoryId, 
														   @Chaintextilecategoryid = pcp.ChainTextileCategoryId, 
														   @Formulasegmentid = pcp.FormulaSegmentId, 
														   @Ecolabsaturationid = pcp.EcolabSaturationId
														FROM tcd.PlantChainProgram AS pcp
														WHERE pcp.PlantProgramId = @Plantprogramid
															  AND pcp.Is_Deleted = 0;
												END;
											--End-----ProgramMasterID logic for PlantChainProgram
											-- New Batch Creation
											INSERT INTO TCD.BatchData
											(
												   ControllerBatchId, 
												   EcolabWasherId, 
												   GroupId, 
												   MachineInternalId, 
												   PlantWasherNumber, 
												   StartDate, 
												   EndDate, 
												   ProgramNumber, 
												   ProgramMasterId, 
												   MachineId, 
												   ActualWeight, 
												   StandardWeight, 
												   CurrencyCode, 
												   ShiftId, 
												   PartitionOn, 
												   TargetTurnTime, 
												   StdInjectionSteps, 
												   StdWashSteps, 
												   EcolabTextileCategoryId, 
												   ChainTextileCategoryId, 
												   FormulaSegmentId, 
												   EcolabSaturationId, 
												   PlantProgramId, 
												   ETechlastDroppedTimeStamp
											)
												   SELECT DISTINCT 
														  @Curcompartmentloadid, 
														  @Ecolabwasherid, 
														  @Groupid, 
														  @Machineinternalid, 
														  @Plantwashernumber,
														  --,@CurReceivedTime
														  @Curtunneltimestamp, 
														  NULL, 
														  @Curcurrentformula, 
														  @Programmasterid, 
														  @Washerid, 
														  @Autoweightentryweight, 
														  @Standardweight, 
														  @Currencycode, 
														  (SELECT TOP 1 
																  ShiftId FROM @Shiftstartdate
														  ), 
														  (SELECT TOP 1 
																  ShiftStartdate FROM @Shiftstartdate
														  ), 
														  @Targetturntime, 
														  @Stdinjectionsteps, 
														  @Stdwashsteps, 
														  @Ecolabtextilecategoryid, 
														  @Chaintextilecategoryid, 
														  @Formulasegmentid, 
														  @Ecolabsaturationid, 
														  @Plantprogramid, 
														  @Etechlastdroppedat;
											SET @Batchid = SCOPE_IDENTITY();	
											--Start insert InjectionActualCount and StepActualCount in TCD.BatchParameters
											INSERT INTO TCD.BatchParameters
											(
												   BatchId, 
												   EcolabWasherId, 
												   ParameterId, 
												   ParameterValue, 
												   PartitionOn
											)
												   SELECT 
														  @Batchid, 
														  @Ecolabwasherid, 
														  37, 
														  @Stdinjectionsteps, 
														  (SELECT TOP 1 
																  ShiftStartdate FROM @Shiftstartdate
														  );
											INSERT INTO TCD.BatchParameters
											(
												   BatchId, 
												   EcolabWasherId, 
												   ParameterId, 
												   ParameterValue, 
												   PartitionOn
											)
												   SELECT 
														  @Batchid, 
														  @Ecolabwasherid, 
														  38, 
														  @Stdwashsteps, 
														  (SELECT TOP 1 
																  ShiftStartdate FROM @Shiftstartdate
														  );	
											--End insert InjectionActualCount and StepActualCount in TCD.BatchParameters
											--Start Customer Codes coming from ETech in TCD.BatchParameters
											IF @Customercodes IS NOT NULL
												BEGIN
													INSERT INTO TCD.BatchParameters
													(
														   BatchId, 
														   EcolabWasherId, 
														   ParameterId, 
														   ParameterValue, 
														   PartitionOn
													)
														   SELECT 
																  @Batchid, 
																  @Ecolabwasherid, 
																  39, 
																  @Customercodes, 
																  (SELECT TOP 1 
																		  ShiftStartdate FROM @Shiftstartdate
																  );
												END;
											--End Customer Codes coming from ETech in TCD.BatchParameters
											--If the received formula is not configured in enVision then create an alarm 
											IF @Programmasterid IS NULL
												BEGIN
													SELECT 
														   @Ecolabaccountnumber = EcolabAccountNumber FROM TCD.Plant;
													SELECT 
														   @Alarmgroupmasterid = AGM.AlarmGroupMasterId
														FROM TCD.AlarmGroupMsterVsControllerModelType AS AGMVCMT
															 INNER JOIN TCD.AlarmGroupMaster AS AGM ON AGM.AlarmGroupMasterId = AGMVCMT.
															 AlarmGroupMasterId
														WHERE AGMVCMT.AlarmCode = 9000;
													INSERT INTO TCD.AlarmData
													(
														   EcoalabAccountNumber, 
														   AlarmCode, 
														   BatchId, 
														   controllerID, 
														   StartDate, 
														   GroupId, 
														   MachineInternalId, 
														   ProgramId, 
														   IsActive, 
														   EndDate, 
														   MachineId, 
														   AlarmGroupMasterId, 
														   PartitionOn
													)
														   SELECT 
																  @Ecolabaccountnumber, 
																  9000, 
																  @Batchid, 
																  @Controllerid, 
																  @Curtunneltimestamp, 
																  @Groupid, 
																  @Machineinternalid, 
																  @Curcurrentformula, 
																  0, 
																  @Curtunneltimestamp, 
																  @Washerid, 
																  @Alarmgroupmasterid, 
																  @Curtunneltimestamp;
												END;
											-- Wash Step Information		
											INSERT INTO TCD.BatchWashStepData
											(
												   BatchId, 
												   StepCompartment, 
												   StartTime, 
												   EndTime, 
												   PartitionOn, 
												   EcolabWasherId
											)
												   SELECT 
														  @Batchid, 
														  @Curcompartmentid, 
														  @Curtunneltimestamp,
														  --@CurReceivedTime,
														  NULL, 
														  (SELECT TOP 1 
																  ShiftStartdate FROM @Shiftstartdate
														  ), 
														  @Ecolabwasherid;
											-- Product Usage
											IF @Ratiodosingenabled = 1
												BEGIN
													INSERT INTO TCD.BatchProductData
													(
														   BatchId, 
														   StepCompartment, 
														   ActualQuantity, 
														   StandardQuantity, 
														   Price, 
														   TimeStamp, 
														   PartitionOn, 
														   EcolabWasherId, 
														   ProductId
													)
														   SELECT DISTINCT 
																  @Batchid, 
																  @Curcompartmentid, 
																  ((Wps.NominalLoad * Wdpm.Quantity) / 100) * @Autoweightentryweight /
																  @Standardweight AS ActualQuantity, 
																  ((Wps.NominalLoad * Wdpm.Quantity) / 100) * @Autoweightentryweight /
																  @Standardweight AS StandardQuantity, 
																  ((Wps.NominalLoad * Wdpm.Quantity) / 100) * tcd.FnChemicalCostInOunce(Pdm.
																  ProductID
																																	   ) AS Price, 
																  @Curtunneltimestamp,								
																  --,@CurReceivedTime
																  (SELECT TOP 1 
																		  ShiftStartdate FROM @Shiftstartdate
																  ), 
																  @Ecolabwasherid, 
																  Pdm.ProductID
															   FROM TCD.Washer AS WS
																	INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = ws.WasherId
																	INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
																	INNER JOIN TCD.WasherGroupType AS WgT ON WgT.WasherGroupTypeId = Wg.
																	WasherGroupTypeId
																	INNER JOIN TCD.TunnelProgramSetup AS Wps ON Wps.WasherGroupId = Wg.
																	WasherGroupId
																	INNER JOIN TCD.TunnelDosingSetup AS Wds ON Wds.TunnelProgramSetupId = Wps.
																	TunnelProgramSetupId
																	INNER JOIN TCD.TunnelDosingProductMapping AS Wdpm ON Wdpm.TunnelDosingSetupId
																	= Wds.TunnelDosingSetupId
																	INNER JOIN TCD.ControllerEquipmentSetup AS Ces ON Ces.
																	ControllerEquipmentSetupId = Wdpm.ControllerEquipmentSetupId
																	INNER JOIN TCD.ProductdataMapping AS Pdm ON Pdm.ProductId = Ces.ProductId
															   --INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
															   WHERE Ws.WasherId = @Washerid
																	 AND Wps.ProgramNumber = @Curcurrentformula
																	 AND Wds.CompartmentNumber = @Curcompartmentid
																	 AND Wps.Is_Deleted = 0
																	 AND Pdm.Is_Deleted = 0;
												END;
											ELSE
												BEGIN
													INSERT INTO TCD.BatchProductData
													(
														   BatchId, 
														   StepCompartment, 
														   ActualQuantity, 
														   StandardQuantity, 
														   Price, 
														   TimeStamp, 
														   PartitionOn, 
														   EcolabWasherId, 
														   ProductId
													)
														   SELECT DISTINCT 
																  @Batchid, 
																  @Curcompartmentid, 
																  (Wps.NominalLoad * Wdpm.Quantity) / 100 AS ActualQuantity, 
																  (Wps.NominalLoad * Wdpm.Quantity) / 100 AS StandardQuantity, 
																  ((Wps.NominalLoad * Wdpm.Quantity) / 100) * tcd.FnChemicalCostInOunce(Pdm.
																  ProductID
																																	   ) AS Price, 
																  @Curtunneltimestamp,									
																  --,@CurReceivedTime
																  (SELECT TOP 1 
																		  ShiftStartdate FROM @Shiftstartdate
																  ), 
																  @Ecolabwasherid, 
																  Pdm.ProductID
															   FROM TCD.Washer AS WS
																	INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = ws.WasherId
																	INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
																	INNER JOIN TCD.WasherGroupType AS WgT ON WgT.WasherGroupTypeId = Wg.
																	WasherGroupTypeId
																	INNER JOIN TCD.TunnelProgramSetup AS Wps ON Wps.WasherGroupId = Wg.
																	WasherGroupId
																	INNER JOIN TCD.TunnelDosingSetup AS Wds ON Wds.TunnelProgramSetupId = Wps.
																	TunnelProgramSetupId
																	INNER JOIN TCD.TunnelDosingProductMapping AS Wdpm ON Wdpm.TunnelDosingSetupId
																	= Wds.TunnelDosingSetupId
																	INNER JOIN TCD.ControllerEquipmentSetup AS Ces ON Ces.
																	ControllerEquipmentSetupId = Wdpm.ControllerEquipmentSetupId
																	INNER JOIN TCD.ProductdataMapping AS Pdm ON Pdm.ProductId = Ces.ProductId
															   --INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
															   WHERE Ws.WasherId = @Washerid
																	 AND Wps.ProgramNumber = @Curcurrentformula
																	 AND Wds.CompartmentNumber = @Curcompartmentid
																	 AND Wps.Is_Deleted = 0
																	 AND Pdm.Is_Deleted = 0;
												END;			
							
							
											-- Transfer Signal		
											INSERT INTO TCD.WasherReading
											(
												   WasherId, 
												   ParameterId, 
												   ParameterValue, 
												   DateTimeStamp, 
												   PartitionOn, 
												   EcolabWasherId
											)
												   SELECT 
														  @Washerid, 
														  6, 
														  1, 
														  @Temptunneltimestamp, 
														  (SELECT TOP 1 
																  ShiftStartdate FROM @Shiftstartdate
														  ), 
														  @Ecolabwasherid
												   UNION ALL
												   SELECT 
														  @Washerid, 
														  6, 
														  0, 
														  GETUTCDATE(), 
														  (SELECT TOP 1 
																  ShiftStartdate FROM @Shiftstartdate
														  ), 
														  @Ecolabwasherid;
		
											-- Insert Customer Data
											INSERT INTO TCD.BatchCustomerData
											(
												   BatchId, 
												   CustomerId, 
												   Weight, 
												   PiecesCount, 
												   PartitionOn, 
												   EcolabWasherId
											)
												   SELECT DISTINCT 
														  Bd.BatchId, 
														  Pc.ID, 
														  @Autoweightentryweight, 
														  ROUND(COALESCE((@Autoweightentryweight * Pm.Pieces) / NULLIF(Pm.Weight, 0), 0), 0), 
														  (SELECT TOP 1 
																  ShiftStartdate FROM @Shiftstartdate
														  ), 
														  @Ecolabwasherid
													   FROM TCD.Washer AS WS
															INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = ws.WasherId
															INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.GroupId
															INNER JOIN TCD.TunnelProgramSetup AS Tps ON Tps.WasherGroupId = Wg.WasherGroupId
															INNER JOIN TCD.ProgramMaster AS Pm ON Pm.ProgramId = Tps.ProgramId
															INNER JOIN TCD.PlantCustomer AS Pc ON Pc.ID = Pm.CustomerId
															INNER JOIN TCD.BatchData AS Bd ON Bd.MachineId = Ws.WasherId
													   WHERE Ws.WasherId = @Washerid
															 AND Tps.ProgramNumber = @Curcompartmentformulaid
															 AND Bd.BatchId = @Batchid
															 AND Pm.CustomerId != -1
															 AND Pm.Weight > 0;
										END;
									ELSE
										BEGIN
											SELECT 
												   @Batchid = BatchId, 
												   @Partitionon = PartitionOn
												FROM TCD.BatchData
												WHERE MachineId = @Washerid
													  AND ControllerBatchId = @Curcompartmentloadid;
											IF @Batchid IS NOT NULL
												BEGIN
													UPDATE TCD.BatchWashStepData
													  SET 
														  EndTime = @Curtunneltimestamp
														WHERE 
															  BatchId = @Batchid
															  AND StepCompartment = @Curcompartmentid - 1;
													IF NOT EXISTS
																 (SELECT TOP 1 
																		 *
																	  FROM TCD.BatchWashStepData
																	  WHERE StartTime = @Curtunneltimestamp
																			AND BatchId = @Batchid
																 )
														BEGIN
															INSERT INTO TCD.BatchWashStepData
															(
																   BatchId, 
																   StepCompartment, 
																   StartTime, 
																   EndTime, 
																   PartitionOn, 
																   EcolabWasherId
															)
																   SELECT 
																		  @Batchid, 
																		  @Curcompartmentid, 
																		  @Curtunneltimestamp,
																		  --@CurReceivedTime,
																		  NULL, 
																		  @Partitionon, 
																		  @Ecolabwasherid;
														END;
													IF @Ratiodosingenabled = 1
														BEGIN
															IF NOT EXISTS
																		 (SELECT TOP 1 
																				 *
																			  FROM TCD.BatchProductData
																			  WHERE TimeStamp = @Curtunneltimestamp
																					AND BatchId = @Batchid
																		 )
																BEGIN
																	INSERT INTO TCD.BatchProductData
																	(
																		   BatchId, 
																		   StepCompartment, 
																		   ActualQuantity, 
																		   StandardQuantity, 
																		   Price, 
																		   TimeStamp, 
																		   PartitionOn, 
																		   EcolabWasherId, 
																		   ProductId
																	)
																		   SELECT DISTINCT 
																				  @Batchid, 
																				  @Curcompartmentid, 
																				  ((Wps.NominalLoad * Wdpm.Quantity) / 100) *
																				  @Autoweightentryweight / @Standardweight AS ActualQuantity, 
																				  ((Wps.NominalLoad * Wdpm.Quantity) / 100) *
																				  @Autoweightentryweight / @Standardweight AS StandardQuantity, 
																				  ((Wps.NominalLoad * Wdpm.Quantity) / 100) * tcd.
																				  FnChemicalCostInOunce(Pdm.ProductID) AS Price, 
																				  @Curtunneltimestamp,									
																		   --,@CurReceivedTime
																				  @Partitionon, 
																				  @Ecolabwasherid, 
																				  Pdm.ProductID
																			   FROM TCD.Washer AS WS
																					INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = ws.
																					WasherId
																					INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.
																					GroupId
																					INNER JOIN TCD.WasherGroupType AS WgT ON WgT.
																					WasherGroupTypeId = Wg.WasherGroupTypeId
																					INNER JOIN TCD.TunnelProgramSetup AS Wps ON Wps.WasherGroupId
																					= Wg.WasherGroupId
																					INNER JOIN TCD.TunnelDosingSetup AS Wds ON Wds.
																					TunnelProgramSetupId = Wps.TunnelProgramSetupId
																					INNER JOIN TCD.TunnelDosingProductMapping AS Wdpm ON Wdpm.
																					TunnelDosingSetupId = Wds.TunnelDosingSetupId
																					INNER JOIN TCD.ControllerEquipmentSetup AS Ces ON Ces.
																					ControllerEquipmentSetupId = Wdpm.
																					ControllerEquipmentSetupId
																					INNER JOIN TCD.ProductdataMapping AS Pdm ON Pdm.ProductId =
																					Ces.ProductId
																			   --INNER JOIN TCD.BatchData Bd ON Bd.MachineId=Ws.WasherId
																			   WHERE Ws.WasherId = @Washerid
																					 AND Wps.ProgramNumber = @Curcompartmentformulaid
																					 AND Wds.CompartmentNumber = @Curcompartmentid
																					 AND Wps.Is_Deleted = 0
																					 AND Pdm.Is_Deleted = 0
																					 AND Pdm.ProductID <> 1;
																END;
														END; -- end of ratio dosing if
													ELSE
														BEGIN
															IF NOT EXISTS
																		 (SELECT TOP 1 
																				 *
																			  FROM TCD.BatchProductData
																			  WHERE TimeStamp = @Curtunneltimestamp
																					AND BatchId = @Batchid
																		 )
																BEGIN
																	INSERT INTO TCD.BatchProductData
																	(
																		   BatchId, 
																		   StepCompartment, 
																		   ActualQuantity, 
																		   StandardQuantity, 
																		   Price, 
																		   TimeStamp, 
																		   PartitionOn, 
																		   EcolabWasherId, 
																		   ProductId
																	)
																		   SELECT DISTINCT 
																				  @Batchid, 
																				  @Curcompartmentid, 
																				  (Wps.NominalLoad * Wdpm.Quantity) / 100 AS ActualQuantity, 
																				  (Wps.NominalLoad * Wdpm.Quantity) / 100 AS StandardQuantity, 
																				  ((Wps.NominalLoad * Wdpm.Quantity) / 100) * tcd.
																				  FnChemicalCostInOunce(Pdm.ProductID) AS Price, 
																				  @Curtunneltimestamp,									
																		   --,@CurReceivedTime
																				  @Partitionon, 
																				  @Ecolabwasherid, 
																				  Pdm.ProductID
																			   FROM TCD.Washer AS WS
																					INNER JOIN TCD.MachineSetup AS Mst ON Mst.WasherId = ws.
																					WasherId
																					INNER JOIN TCD.WasherGroup AS Wg ON Wg.WasherGroupId = Mst.
																					GroupId
																					INNER JOIN TCD.WasherGroupType AS WgT ON WgT.
																					WasherGroupTypeId = Wg.WasherGroupTypeId
																					INNER JOIN TCD.TunnelProgramSetup AS Wps ON Wps.WasherGroupId
																					= Wg.WasherGroupId
																					INNER JOIN TCD.TunnelDosingSetup AS Wds ON Wds.
																					TunnelProgramSetupId = Wps.TunnelProgramSetupId
																					INNER JOIN TCD.TunnelDosingProductMapping AS Wdpm ON Wdpm.
																					TunnelDosingSetupId = Wds.TunnelDosingSetupId
																					INNER JOIN TCD.ControllerEquipmentSetup AS Ces ON Ces.
																					ControllerEquipmentSetupId = Wdpm.
																					ControllerEquipmentSetupId
																					INNER JOIN TCD.ProductdataMapping AS Pdm ON Pdm.ProductId =
																					Ces.ProductId
																			   WHERE Ws.WasherId = @Washerid
																					 AND Wps.ProgramNumber = @Curcompartmentformulaid
																					 AND Wds.CompartmentNumber = @Curcompartmentid
																					 AND Wps.Is_Deleted = 0
																					 AND Pdm.Is_Deleted = 0
																					 AND Pdm.ProductID <> 1;
																END;
														END;
													IF NOT EXISTS
																 (SELECT 
																		 * FROM TCD.BatchParameters WHERE ParameterId = 41
																										  AND batchid = @Batchid
																 )
														BEGIN
															INSERT INTO Tcd.BatchParameters
															(
																   BatchId, 
																   EcolabWasherId, 
																   ParameterId, 
																   ParameterValue, 
																   PartitionOn
															)
																   SELECT 
																		  @Batchid, 
																		  @Ecolabwasherid, 
																		  41,
																		  CASE
																			  WHEN SUM(bpd.ActualQuantity) = SUM(bpd.StandardQuantity)
																			  THEN 1		--'Approved'
																			  WHEN SUM(bpd.ActualQuantity) <> SUM(bpd.StandardQuantity)
																			  THEN 2		--'Rejected'
																			  ELSE 1		--'Approved'
																		  END, 
																		  (SELECT TOP 1 
																				  ShiftStartdate FROM @Shiftstartdate
																		  )
																	   FROM TCD.BatchProductData AS bpd
																	   WHERE bpd.BatchId = @Batchid;
														END;
												END; -- end of BatchId NULL if
										END; -- end of else
								END;		-- end of IF(@CurCurrentFormula != @CurEof and @CurCurretnInjection = 0 and @CurCurrentOperationCounter = 0)							
						END;		-- end of IF(@IsFormulaModified !=0)	
					FETCH NEXT FROM @Mycursor INTO @Curcurrentformula, 
												   @Curcurretninjection, 
												   @Curcurrentoperationcounter, 
												   @Cureof, 
												   @Curtunneltimestamp, 
												   @Curonhold, 
												   @Curcompartmentid, 
												   @Curcompartmentloadid, 
												   @Curcompartmentformulaid, 
												   @Curreceivedtime, 
												   @Autoweightentryactive, 
												   @Autoweightentryweight, 
												   @Isformulamodified, 
												   @Isholdsignalmodified, 
												   @Isstopsinalmodified, 
												   @Stopsignal, 
												   @Ratiodosingenabled;
				END;
			CLOSE @Mycursor;
			DEALLOCATE @Mycursor;
		END;
END;