﻿


CREATE PROCEDURE [TCD].[SavePlantWaterEnergyUtilityDetails]

(

@EcolabAccountNumber			 NVARCHAR(25),

@WaterFactorType				 NVARCHAR(200),

@Temperature					 DECIMAL(18,4),

@Price						 DECIMAL(18,4),

@GasOilTypeId					 INT,

@EnergyPrice					 DECIMAL(18,4),

@EnergyPriceSubUnit				 NVARCHAR(150),

@BoilerSteam					 DECIMAL(18,4),

@ElectricalPrice				 DECIMAL(18,4),

@BoilerType					 INT,

@Steam						 DECIMAL(18,4),

@Boiler						 DECIMAL(18,4),

@Stack						 DECIMAL(18,4),

@RewashFactor					 DECIMAL(18,4),

@EvaporationFactor				 DECIMAL(18,4),

@UserId						 INT,

@Count						 INT=0,

@MyServiceWtrFctrId			INT = NULL,

@MyServiceLastSyncTime		DATETIME = NULL

)

AS

BEGIN



DECLARE @UsageKey NVARCHAR(100)

DECLARE @WaterFactorTypeId INT = 0

DECLARE @WaterUtilityDetailsId INT;

-- To get the usage key for gasoil type 

SET @UsageKey='TCD_GasOil_Price'



-- To get the water factor Id 

IF @WaterFactorType <> 'None'

BEGIN

SELECT @WaterFactorTypeId=wt.Id FROM TCD.WaterType wt WHERE Name=@WaterFactorType AND wt.RegionID=(SELECT P.RegionID FROM TCD.Plant P WHERE P.EcolabAccountNumber=@EcolabAccountNumber)

END

-- Insert for water utilities

IF ((SELECT COUNT(*) FROM TCD.WaterUtilityDetails WHERE EcolabAccountNumber=@EcolabAccountNumber)<8)
BEGIN
	SET @WaterUtilityDetailsId = (SELECT ISNULL(MAX(WaterUtilityDetailsId),0) + 1 FROM TCD.WaterUtilityDetails WHERE EcolabAccountNumber = @EcolabAccountNumber);

INSERT INTO TCD.WaterUtilityDetails

	   (WaterUtilityDetailsId, EcolabAccountNumber,    WaterFactorTypeId,    Temperature,    Price,    LastModifiedByUserId, LastModifiedTime, MyServiceLastSyncTime, MyServiceWtrFctrId)

VALUES

	   (@WaterUtilityDetailsId, @EcolabAccountNumber,    @WaterFactorTypeId,    @Temperature,    @Price,    @UserId, GETUTCDATE(), @MyServiceLastSyncTime, @MyServiceWtrFctrId)
END






IF(@Count=1 AND (SELECT COUNT(*) FROM TCD.EnergyUtilityDetails WHERE EcolabAccountNumber=@EcolabAccountNumber)=0)

BEGIN

-- Insert for Energy Utilities.

    INSERT INTO TCD.EnergyUtilityDetails 

    (EcolabAccountNumber,	   GasOilTypeId,	   EnergyPrice,	   EnergyPriceUsageKey,	   EnergySubUnit,	    ElectricPrice,	   BolierSteam,	   BolierType,	   Steam,	   Boiler,

	Stack,	   RewashFactor,	   EvaporationFactor,	   LastModifiedByUserId,   MyServiceLastSyncTime  )

    VALUES

    (@EcolabAccountNumber, -- EcolabAccountNumber - nvarchar

	   @GasOilTypeId, -- GasOilTypeId - int

	   @EnergyPrice, -- EnergyPrice - decimal

	   @UsageKey, -- EnergyPriceUsageKey - nvarchar

	   @EnergyPriceSubUnit,

	   @ElectricalPrice, -- ElectricPrice - decimal

	   @BoilerSteam, -- BolierSteam - bit

	   @BoilerType, -- BolierType - int

	   @Steam, -- Steam - decimal

	   @Boiler, -- Boiler - decimal

	   @Stack, -- Stack - decimal

	   @RewashFactor, -- RewashFactor - decimal

	   @EvaporationFactor, -- EvaporationFactor - decimal

	   @UserId, -- LastModifiedByUserId - int

	   @MyServiceLastSyncTime
	   )

    END

END