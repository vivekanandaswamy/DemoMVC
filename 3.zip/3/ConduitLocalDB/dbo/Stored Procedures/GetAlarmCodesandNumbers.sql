﻿
/* 
 ========================================================================================== 
 Purpose:  Used in the login page where a user login and password are entered. 

 Author:  Nagesh Patibandla 

 -------------------------------------------------------------- 
 March-16-2015 : Initial version. 
 ========================================================================================== 
*/ 
CREATE PROCEDURE [TCD].[GetAlarmCodesandNumbers](@AlarmMachineMappingIds VARCHAR(MAX)
                                                ,@IsBatchEjectCondition BIT
                                                ,@washerid INT
                                                ,@OutputIsTunnel BIT OUTPUT
                                                ,@OutputControllerId INT OUTPUT)
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE
       @sql NVARCHAR(MAX)
    SET @sql=''
    IF(@IsBatchEjectCondition=1)
        BEGIN
            SET @sql='SELECT AlarmNumber FROM tcd.BatchEjectCondition AS bec WHERE bec.BatchEjectConditionId IN ('+@AlarmMachineMappingIds+')'
        END
    ELSE
        BEGIN
            SET @sql='SELECT AlarmCode FROM tcd.AlarmGroupMsterVsControllerModelType agmvcmt WHERE agmvcmt.AlarmGroupMsterVsControllerModelTypeId in ('+@AlarmMachineMappingIds+')'
        END
    EXECUTE sp_executesql
            @sql

    SELECT
           @OutputIsTunnel=ms.IsTunnel,
           @OutputControllerId=ms.ControllerId
    FROM tcd.MachineSetup AS ms
    WHERE washerid=@washerid
      AND ms.IsDeleted=0
END;