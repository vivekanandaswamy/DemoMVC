﻿/*    

==========================================================================================    

Purpose:  INSERTING THE FINNISHER GROUPS DATA    

    

Author: Venkata Mohan Krishna K    

    

--------------------------------------------------------------    

Sep-25-2014 ENT: Initial version.    

==========================================================================================    

*/    

CREATE PROCEDURE [TCD].[SaveFinnisherGroups] (    
@GroupDescription  varchar(100),    
@EcolabAccountNumber nvarchar(25),    
@UserId Int,    
@Scope varchar(100) OUTPUT
--Adding these 2 params as part of re-factoring for integration with Synch/Configurator
,	@OutputFinisherGroupId					INT			=	NULL	OUTPUT
,	@OutputLastModifiedTimestampAtLocal		DATETIME	=	NULL	OUTPUT
)    

AS    
BEGIN    


SET NOCOUNT ON  


DECLARE @Output Varchar(100) = ''    

DECLARE
		@OutputList						AS	TABLE		(
		FinisherGroupId					INT
	,	LastModifiedTimestamp			DATETIME
	)

SET		@OutputFinisherGroupId						=			ISNULL(@OutputFinisherGroupId, NULL)				--SQLEnlight SA0121
SET		@OutputLastModifiedTimestampAtLocal			=			ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)	--SQLEnlight SA0121
SET		@Scope										=			ISNULL(@Scope, NULL)								--SQLEnlight SA0121

IF	NOT EXISTS	(	SELECT	1    
					FROM	[TCD].MachineGroup    
					WHERE	GroupDescription = @GroupDescription
						and GroupTypeId = 4
						and EcolabAccountNumber = @EcolabAccountNumber
						and IS_DELETED <> 1
				)    
		BEGIN    
				INSERT	INTO	[TCD].MachineGroup	(
								GroupDescription
							,	GroupTypeId
							,	EcolabAccountNumber
							,	LastModifiedByUserId
							)
					--**	Adding as part of Audit re-factor to capture the User info.
					OUTPUT		inserted.Id
							,	inserted.LastModifiedTime
						INTO	@OutputList	(
								FinisherGroupId
							,	LastModifiedTimestamp
							)    
					--**
					Values	(	@GroupDescription
							,	4
							,	@EcolabAccountNumber
							,	@UserId
							)    

				SET @OutPut = '101'    
				SET @Scope = @OutPut SELECT @Scope    
		END    
ELSE    
		BEGIN    
				SET @OutPut = '301'    
				SET @Scope = @OutPut --SELECT @Scope    
		END    


IF @OutPut = '301'
	BEGIN
		SET		@OutputLastModifiedTimestampAtLocal			=			GETUTCDATE()
	END
ELSE
	BEGIN
		SELECT	TOP 1	
			@OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp
		,	@OutputFinisherGroupId				=	O.FinisherGroupId
		FROM	@OutputList							O

	END



END
