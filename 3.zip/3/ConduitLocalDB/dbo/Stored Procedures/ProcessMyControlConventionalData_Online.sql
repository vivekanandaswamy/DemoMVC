﻿CREATE PROCEDURE [TCD].[ProcessMyControlConventionalData_Online](
	@ControllerID   INT,
	@VxML           XML,
	@RedFlagShiftId INT OUTPUT)
AS
	BEGIN
	    DECLARE @MachineNumber           INT,
			  @StepNumber              INT,
			  @StartDateTime           DATETIME,
			  @EndDateTime             DATETIME,
			  @ProgramNumber           INT,
			  @Load                    DECIMAL(10, 2),
			  @NominalLoad             DECIMAL(10, 2),
			  @CustomerNumber          INT,
			  @PHStatus                INT,
			  @PHValue                 INT,
			  @TemperatureMin          INT,
			  @TemperatureMax          INT,
			  @TempMinStatus           INT,
			  @TempMaxStatus           INT,
			  @BatchNumber             INT,
			  @WasherID                INT,
			  @WasherGroupID           INT,
			  @EcoLabWasherID          INT,
			  @ProgramMasterID         INT,
			  @PlantWasherNumber       INT,
			  @ShiftID                 INT,
			  @FrmParameterID          INT,
			  @PHParameterID           INT,
			  @PHParameterStatus       INT,
			  @BatchID                 INT,
			  @ShiftStartdate          DATETIME,
			  @ShiftName               NVARCHAR(50),
			  @XMLDataID               INT,
			  @TempParameter           INT,
			  @TemperatureMinParam     INT,
			  @TemperatureMaxParam     INT,
			  @TempMinStatusParam      INT,
			  @TempMaxStatusParam      INT,
			  @WashStepNo              INT,
			  @CurrencyCode            VARCHAR(50),
			  @StdInjectionSteps       INT,
			  @StdWashSteps            INT,
			  @EcolabTextileCategoryId INT,
			  @ChainTextileCategoryId  INT,
			  @FormulaSegmentId        INT,
			  @EcolabSaturationId      INT,
			  @PlantProgramId          INT,
			  @TargetTurnTime          INT,
			  @MeterID                 INT,
			  @WaterConsumption1       DECIMAL(18, 4),
			  @WaterConsumption2       DECIMAL(18, 4),
			  @ModuleCount             INT;
	    SELECT
			 @MachineNumber = T.c.value('@MachineNumber', 'INT'),
			 @StepNumber = T.c.value('@StepNumber', 'INT'),
			 @StartDateTime = T.c.value('@StartDateTime', 'DATETIME'),
			 @EndDateTime = T.c.value('@EndDateTime', 'DATETIME'),
			 @ProgramNumber = T.c.value('@ProgramNumber', 'INT'),
			 @Load = T.c.value('@Load', 'Decimal(10,2)'),
			 @NominalLoad = T.c.value('@NominalLoad', 'Decimal(10,2)'),
			 @CustomerNumber = T.c.value('@CustomerNumber', 'INT'),
			 @PHStatus = T.c.value('@PHStatus', 'INT'),
			 @PHValue = T.c.value('@PHValue', 'INT'),
			 @TemperatureMin = T.c.value('@TemperatureMin', 'INT'),
			 @TemperatureMax = T.c.value('@TemperatureMax', 'INT'),
			 @TempMaxStatus = T.c.value('@TemperatureMaxStatus', 'INT'),
			 @TempMinStatus = T.c.value('@TemperatreMinStatus', 'INT'),
			 @BatchNumber = T.c.value('@BatchNumber', 'INT'),
			 @WaterConsumption1 = T.c.value('@WaterConsumption1',
			 'DECIMAL(18,4)'
									 ),
			 @WaterConsumption2 = T.c.value('@WaterConsumption2',
			 'DECIMAL(18,4)'
									 )
	    FROM @VxML.nodes('MyControlConventionalData') T(C);

	    --Check for valid startdatetime
	    IF(@StartDateTime <= '01/01/1899'
		  OR @StartDateTime > '06/06/2079')
		   BEGIN
			  RETURN;
		   END;
	    SELECT
			 @PHParameterID = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'pH';
	    SELECT
			 @PHParameterStatus = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'PH Status';
	    SELECT
			 @TemperatureMinParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Mimum Temperature';
	    SELECT
			 @TemperatureMaxParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Maximum Temperature';
	    SELECT
			 @TempMinStatusParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Minimum Temperature Status';
	    SELECT
			 @TempMaxStatusParam = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'Max Temperature Status';
	    SELECT
			 @WashStepNo = ID
	    FROM TCD.ConduitParameters
	    WHERE NAME = 'StepCompartment No';
	    SELECT
			 @FrmParameterID = [Id]
	    FROM TCD.ConduitPArameters
	    WHERE Name = 'Formula Number';
	    DECLARE @ShiftMapping TABLE
	    (
		    ShiftId        INT,
		    ShiftName      NVARCHAR(50),
		    ShiftStartdate DATETIME
	    );
	    INSERT INTO @ShiftMapping
	    (
			 ShiftId,
			 ShiftName,
			 ShiftStartdate
	    )
	    EXEC TCD.GetShiftStartDate
		    @StartDateTime;
	    SELECT
			 @ShiftID = ShiftID,
			 @ShiftStartdate = ShiftStartdate
	    FROM @ShiftMapping;
	    SELECT
			 @WasherGroupID = GroupId,
			 @WasherID = WasherID
	    FROM TCD.MachineSetup ms
	    WHERE ControllerID = @ControllerID
			AND MachineInternalId = @MachineNumber
			AND IsTunnel = 0
			AND IsDeleted = 0;
	    IF(@EndDateTime = '1/1/1900')
		   SELECT
				@EndDateTime = NULL;
	    IF(@StartDateTime = '1/1/1900')
		   SELECT
				@StartDateTime = NULL;
	    IF(@WasherId IS NOT NULL)
		   BEGIN
			  SELECT
				    @ProgramMasterId = Wps.ProgramId
			  FROM TCD.Washer Ws
				  INNER JOIN TCD.MachineSetup Mst ON Mst.WasherId = Ws
				  .WasherId
				  INNER JOIN TCD.WasherGroup Wg ON Wg.WasherGroupId =
				  Mst.GroupId
				  INNER JOIN TCD.WasherProgramSetup Wps ON Wps.
				  ControllerID = Wg.ControllerId
				  INNER JOIN TCD.Plant AS p ON p.EcolabAccountNumber =
				  Ws.EcoLabAccountNumber
			  WHERE Ws.WasherId = @WasherId
				   AND Wps.ProgramNumber = @ProgramNumber
				   AND Wps.Is_Deleted = 0;
			  SELECT
				    @EcoLabWasherID = EcolabWasherId,
				    @PlantWasherNumber = PlantWasherNumber,
				    @CurrencyCode = P.CurrencyCode,
				    @TargetTurnTime = w.TargetTurnTime * 60
			  FROM TCD.Washer w
				  INNER JOIN tcd.Plant p ON w.EcoLabAccountNumber = p.
				  EcolabAccountNumber
			  WHERE w.WasherId = @WasherID;
		   END;
	    SELECT
			 @BatchID = BatchID
	    FROM TCD.BatchData
	    WHERE MachineInternalID = @MachineNumber
			AND StartDate = @StartDateTime
			AND ControllerBatchId = @BatchNumber
			AND MachineID = @WasherID;

	    --Start Getting InjectionCount and StepCount
	    SELECT
			 @StdInjectionSteps = COUNT(DISTINCT wdpm.
			 WasherDosingSetupId),
			 @StdWashSteps = COUNT(DISTINCT wds.WasherDosingSetupId) -
			 COUNT(DISTINCT wdpm.WasherDosingSetupId)
	    FROM TCD.WasherDosingProductMapping wdpm
		    RIGHT JOIN TCD.WasherDosingSetup wds ON wdpm.
		    WasherDosingSetupId = wds.WasherDosingSetupId
	    WHERE wds.ControllerID = @ControllerID
			AND wds.ProgramNumber = @ProgramNumber;
	    --End Getting InjectionCount and StepCount
	    --Start-----ProgramMasterID logic for PlantChainProgram
	    SELECT
			 @PlantProgramId = pm.PlantProgramId,
			 @EcolabTextileCategoryId = pm.EcolabTextileCategoryId,
			 @ChainTextileCategoryId = pm.ChainTextileId,
			 @FormulaSegmentId = pm.FormulaSegmentId,
			 @EcolabSaturationId = pm.EcolabSaturationId
	    FROM TCD.ProgramMaster pm
	    WHERE pm.ProgramId = @ProgramMasterId
			AND pm.Is_Deleted = 0;
	    IF(@PlantProgramId <> 0
		  OR @PlantProgramId IS NOT NULL)
		   BEGIN
			  --Assign value from plantchainprogram table based on plantprogramId
			  SELECT
				    @EcolabTextileCategoryId = pcp.
				    EcolabTextileCategoryId,
				    @ChainTextileCategoryId = pcp.
				    ChainTextileCategoryId,
				    @FormulaSegmentId = pcp.FormulaSegmentId,
				    @EcolabSaturationId = pcp.EcolabSaturationId
			  FROM tcd.PlantChainProgram pcp
			  WHERE pcp.PlantProgramId = @PlantProgramId
				   AND pcp.Is_Deleted = 0;
		   END;
	    --End-----ProgramMasterID logic for PlantChainProgram

	    IF(@BatchID IS NULL)
		   BEGIN
			  INSERT INTO TCD.BatchData
			  (
				    ControllerBatchID,
				    EcolabWasherId,
				    GroupId,
				    MachineInternalId,
				    PlantWasherNumber,
				    StartDate,
				    EndDate,
				    ProgramNumber,
				    ProgramMasterId,
				    MachineID,
				    ActualWeight,
				    StandardWeight,
				    CurrencyCode,
				    ShiftId,
				    PartitionOn,
				    StdInjectionSteps,
				    StdWashSteps,
				    EcolabTextileCategoryId,
				    ChainTextileCategoryId,
				    FormulaSegmentId,
				    EcolabSaturationId,
				    PlantProgramId,
				    EndDateFormula,
				    TargetTurnTime
			  )
			  VALUES
			  (
				    @BatchNumber,
				    @EcoLabWasherID,
				    @WasherGroupID,
				    @MachineNumber,
				    @PlantWasherNumber,
				    @StartDateTime,
				    @EndDateTime,
				    @ProgramNumber,
				    @ProgramMasterId,
				    @WasherID,
				    @Load,
				    @NominalLoad,
				    @CurrencyCode,
				    @ShiftID,
				    @ShiftStartdate,
				    @StdInjectionSteps,
				    @StdWashSteps,
				    @EcolabTextileCategoryId,
				    @ChainTextileCategoryId,
				    @FormulaSegmentId,
				    @EcolabSaturationId,
				    @PlantProgramId,
				    @EndDateTime,
				    @TargetTurnTime
			  );
			  SELECT
				    @BatchID = SCOPE_IDENTITY();
			  IF NOT EXISTS
			  (
				 SELECT
					   *
				 FROM TCD.BatchParameters
				 WHERE BatchId = @BatchID
					  AND ParameterID = 38
			  )
				 BEGIN
					IF(@StdWashSteps <> 0
					   OR @StdWashSteps <> NULL)
					    BEGIN
						   INSERT INTO TCD.BatchParameters
						   (
								BatchId,
								EcolabWasherId,
								ParameterId,
								ParameterValue,
								PartitionOn
						   )
						   SELECT
								@BatchID,
								@EcoLabWasherID,
								38,
								@StdWashSteps,
								@ShiftStartdate;
					    END;
				 END;

			  --End Date  Time  is Null 
			  IF EXISTS(SELECT
                              *
			    FROM TCD.BatchData
                          WHERE MachineInternalID = @Machinenumber
                            AND StartDate <> @Startdatetime
                            AND EndDate IS NULL
                            AND ControllerBatchId <> @Batchnumber
                            AND MachineId = @Washerid)
                BEGIN
					DECLARE @ShiftIDByEndDate INT
					DECLARE @CurrentUTCDate DATETIME;
					SELECT @CurrentUTCDate=GETUTCDATE()
                    DECLARE @Shiftmappingbyenddate TABLE(
                            ShiftId INT, 
                            ShiftName NVARCHAR(50), 
                            ShiftStartdate DATETIME);
							
                    INSERT INTO @Shiftmappingbyenddate(
                            ShiftId, 
                            ShiftName, 
                            ShiftStartdate)
                    EXEC TCD.GetShiftStartDate @CurrentUTCDate
                    SELECT
                            @ShiftIDByEndDate = ShiftID,
							@ShiftStartdate = ShiftStartdate
                            FROM @Shiftmappingbyenddate;
					UPDATE TCD.BatchData
					SET
						EndDate = DateAdd(ss,-10,@StartDateTime),
						ShiftId=@ShiftIDByEndDate,
						PartitionOn = @ShiftStartdate
						
					WHERE
						MachineInternalID = @MachineNumber
						AND StartDate <> @StartDateTime
						AND EndDate IS NULL
						AND ControllerBatchId <> @BatchNumber
						AND MachineId = @WasherId;	
				END
																  		
			  -- Program Number	
			  IF(@ProgramNumber IS NOT NULL
				AND @ProgramNumber > 0)
				 BEGIN
					IF NOT EXISTS
					(
					    SELECT
							 *
					    FROM TCD.WasherReading
					    WHERE WasherId = @WasherID
							AND ParameterID = @FrmParameterID
							AND DateTimeStamp = @StartDateTime
					)
					    BEGIN
						   INSERT INTO TCD.WasherReading
						   (
								WasherID,
								ParameterID,
								ParameterValue,
								DateTimeStamp,
								EcoLabWasherID,
								Partitionon
						   )
						   VALUES
						   (
								@WasherID,
								@FrmParameterID,
								@ProgramNumber,
								@StartDateTime,
								@EcoLabWasherID,
								@ShiftStartdate
						   );
					    END;
				 END;
			  IF(@CustomerNumber IS NOT NULL)
				 BEGIN
					IF NOT EXISTS
					(
					    SELECT
							 1
					    FROM [TCD].[BatchCustomerData]
					    WHERE BatchID = @BatchID
					)
					    BEGIN
						   INSERT INTO TCD.BatchCustomerData
						   (
								BatchId,
								CustomerId,
								Weight,
								PiecesCount,
								PartitionOn,
								EcolabWasherId
						   )
						   SELECT DISTINCT
								Bd.BatchId,
								Pc.ID,
								@Load,
								ROUND(COALESCE((@Load * Pm.Pieces)
								/ NULLIF(Pm.Weight, 0), 0), 0),
						   (
							  SELECT TOP 1
								    ShiftStartdate
							  FROM @ShiftMapping
						   ),
								@EcolabWasherId
						   FROM TCD.Washer WS
							   INNER JOIN TCD.MachineSetup Mst ON
							   Mst.WasherId = ws.WasherId
							   INNER JOIN TCD.WasherGroup Wg ON Wg.
							   WasherGroupId = Mst.GroupId
							   INNER JOIN TCD.TunnelProgramSetup
							   Tps ON Tps.WasherGroupId = Wg.WasherGroupId
							   INNER JOIN TCD.ProgramMaster Pm ON
							   Pm.ProgramId = Tps.ProgramId
							   INNER JOIN TCD.PlantCustomer Pc ON
							   Pc.ID = Pm.CustomerId
							   INNER JOIN TCD.BatchData Bd ON Bd.
							   MachineId = Ws.WasherId
						   WHERE Ws.WasherId = @WasherId
							    AND Tps.ProgramNumber =
							    @ProgramNumber
							    AND Bd.BatchId = @BatchID
							    AND Pm.CustomerId != -1
							    AND Pm.[Weight] > 0;
					    END;
				 END;
		   END;

	    -- PH Value
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @PHParameterID
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@PHValue <> 0
				OR @PHValue <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(
						  WasherId,
						  ParameterID,
						  ParameterValue,
						  DateTimeStamp,
						  PartitionOn,
						  EcolabWasherId
					)
					SELECT
						  @WasherID,
						  @PHParameterID,
						  @PHValue,
						  GETUTCDATE(),
						  @ShiftStartdate,
						  @EcolabWasherId;
				 END;
		   END; 
	 
	    -- PH Status
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @PHParameterStatus
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@PHStatus <> 0
				OR @PHStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(
						  WasherId,
						  ParameterID,
						  ParameterValue,
						  DateTimeStamp,
						  PartitionOn,
						  EcolabWasherId
					)
					SELECT
						  @WasherID,
						  @PHParameterStatus,
						  @PHStatus,
						  GETUTCDATE(),
						  @ShiftStartdate,
						  @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Min Value
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TemperatureMinParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TemperatureMin <> 0
				OR @TemperatureMin <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(
						  WasherId,
						  ParameterID,
						  ParameterValue,
						  DateTimeStamp,
						  PartitionOn,
						  EcolabWasherId
					)
					SELECT
						  @WasherID,
						  @TemperatureMinParam,
						  @TemperatureMin,
						  GETUTCDATE(),
						  @ShiftStartdate,
						  @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Max Value
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TemperatureMaxParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TemperatureMax <> 0
				OR @TemperatureMax <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(
						  WasherId,
						  ParameterID,
						  ParameterValue,
						  DateTimeStamp,
						  PartitionOn,
						  EcolabWasherId
					)
					SELECT
						  @WasherID,
						  @TemperatureMaxParam,
						  @TemperatureMax,
						  GETUTCDATE(),
						  @ShiftStartdate,
						  @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Min Status
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TempMinStatusParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TempMinStatus <> 0
				OR @TempMinStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(
						  WasherId,
						  ParameterID,
						  ParameterValue,
						  DateTimeStamp,
						  PartitionOn,
						  EcolabWasherId
					)
					SELECT
						  @WasherID,
						  @TempMinStatusParam,
						  @TempMinStatus,
						  GETUTCDATE(),
						  @ShiftStartdate,
						  @EcolabWasherId;
				 END;
		   END; 

	    -- Temperature Max Status
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @TempMaxStatusParam
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@TempMaxStatus <> 0
				OR @TempMaxStatus <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(
						  WasherId,
						  ParameterID,
						  ParameterValue,
						  DateTimeStamp,
						  PartitionOn,
						  EcolabWasherId
					)
					SELECT
						  @WasherID,
						  @TempMaxStatusParam,
						  @TempMaxStatus,
						  GETUTCDATE(),
						  @ShiftStartdate,
						  @EcolabWasherId;
				 END;
		   END; 

	    -- StepCompartment No
	    IF NOT EXISTS
	    (
		   SELECT
				*
		   FROM TCD.WasherReading
		   WHERE WasherId = @WasherID
			    AND ParameterID = @WashStepNo
			    AND DateTimeStamp = @StartDateTime
	    )
		   BEGIN
			  IF(@StepNumber <> 0
				OR @StepNumber <> NULL)
				 BEGIN
					INSERT INTO TCD.WasherReading
					(
						  WasherId,
						  ParameterID,
						  ParameterValue,
						  DateTimeStamp,
						  PartitionOn,
						  EcolabWasherId
					)
					SELECT
						  @WasherID,
						  @WashStepNo,
						  @StepNumber,
						  GETUTCDATE(),
						  @ShiftStartdate,
						  @EcolabWasherId;
				 END;
		   END;
	    --Start water consumption per batch

	    SELECT
			 @MeterID = MeterId
	    FROM tcd.Meter mt
	    WHERE mt.UtilityType = 2
			AND mt.GroupId = @WasherGroupID
			AND mt.ControllerID = @ControllerID
			AND mt.MachineCompartment = @MachineNumber
			AND mt.CounterNum = 1;
	    SELECT
			 @ModuleCount = COUNT(1)
	    FROM TCD.ModuleReading
	    WHERE Reading = @WaterConsumption1
			AND ModuleId = @MeterID;
	    IF(@ModuleCount = 0)
		   BEGIN
			  IF(ISNULL(@WaterConsumption1, 0) > 0
				AND ISNULL(@MeterID, 0) > 0)
				 BEGIN
					INSERT INTO TCD.ModuleReading
					(
						  ModuleId,
						  ModuleTypeId,
						  Reading,
						  TimeStamp
					)
					SELECT
						  @MeterID,
						  2, --Water Meter
						  @WaterConsumption1,
						  GETUTCDATE();
				 END;
		   END;
	    SELECT
			 @MeterID = MeterId
	    FROM tcd.Meter mt
	    WHERE mt.UtilityType = 2
			AND mt.GroupId = @WasherGroupID
			AND mt.ControllerID = @ControllerID
			AND mt.MachineCompartment = @MachineNumber
			AND mt.CounterNum = 2; 
	    -- set  @ModuleCount=@@ROWCOUNT
	    SELECT
			 @ModuleCount = COUNT(1)
	    FROM TCD.ModuleReading
	    WHERE Reading = @WaterConsumption2
			AND ModuleId = @MeterID;
	    IF(@ModuleCount = 0)
		   BEGIN
			  IF(ISNULL(@WaterConsumption2, 0) > 0
				AND ISNULL(@MeterID, 0) > 0)
				 BEGIN
					INSERT INTO TCD.ModuleReading
					(
						  ModuleId,
						  ModuleTypeId,
						  Reading,
						  TimeStamp
					)
					SELECT
						  @MeterID,
						  2,
						  @WaterConsumption2,
						  GETUTCDATE();
				 END;
		   END;   
	    --End water consumption per batch
	END;