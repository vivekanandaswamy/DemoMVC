﻿/*     
 ==========================================================================================  
 Purpose:  soft deleting the WaterAndEnergy details.     

 Author:  Neetha Allati     

 --------------------------------------------------------------     
 August-21-2014 ENT: Initial version.     
 ==========================================================================================  
*/ 

CREATE PROCEDURE [TCD].[DeleteWaterAndEnergyDetails] (@ID     NVARCHAR(100) = NULL
										 ,@UserID INT
										 , @EcolabAccountNumber					NVARCHAR(25)
										 , @LastModifiedTimestampAtCentral			DATETIME = NULL
										 , @OutputLastModifiedTimestampAtLocal		DATETIME = NULL	OUTPUT)
AS 
 BEGIN 
    SET NOCOUNT ON;
      --DECLARE	
	    --@Table_name NVARCHAR(1000) = 'WaterAndEnergy';									--SQLEnlight SA0004
	    DECLARE
	    @ReturnValue					INT = 0
	    ,@ErrorId						INT = 0
	    ,@ErrorMessage					NVARCHAR(4000) = N''
	    ,@CurrentUTCTime					DATETIME = GETUTCDATE();
    DECLARE
		        @OutputList						AS	TABLE		(
	    LastModifiedTimestamp			DATETIME		);
SET			@OutputLastModifiedTimestampAtLocal			=			ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)			--SQLEnlight SA0121

--If the call is not local, check that the LastModifiedTime matches with the central

IF	(
		    @LastModifiedTimestampAtCentral				IS NOT	NULL
AND NOT	EXISTS	(	SELECT	1
						    FROM	TCD.WaterAndEnergy		WE
					  WHERE	WE.EcolabAccountNumber = @EcolabAccountNumber
						 AND WE.DeviceNumber = @ID
						 AND WE.LastModifiedTime = @LastModifiedTimestampAtCentral
					    )
	  )
		    BEGIN
		  SET			@ErrorId = 60000;
		  SET			@ErrorMessage = N''
									 +
									 CAST(@ErrorId AS NVARCHAR(10))
									 +
									 N': Record not in-synch between plant and central.';
		  RAISERROR	(@ErrorMessage, 16, 1);
		  SET			@ReturnValue = -1;
		  RETURN		(@ReturnValue);
	   END;
      UPDATE [TCD].[WaterAndEnergy] 
      SET    is_deleted = 1 
		   ,LastModifiedByUserId = @UserID
		   ,LastModifiedTime = @CurrentUTCTime
      OUTPUT
    inserted.LastModifiedTime	AS LastModifiedTimestamp
	    INTO
		        @OutputList	(
		        LastModifiedTimestamp
	         )
	 WHERE  DeviceNumber = @ID;
     SELECT	TOP 1	
		        @OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp
	   FROM	@OutputList							O

	   RETURN		(@ReturnValue)
	 
 --SET nocount OFF; 
  END