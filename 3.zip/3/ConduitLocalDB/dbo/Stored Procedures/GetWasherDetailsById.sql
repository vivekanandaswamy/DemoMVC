﻿CREATE PROCEDURE [TCD].[GetWasherDetailsById]
(
	@WasherId							INT

)
AS
BEGIN
SET NOCOUNT ON
	 SELECT WasherTagId
      ,WasherId
      ,TagType
      ,TagAddress
      ,Active FROM TCD.WasherTags WHERE WasherId=@WasherId

SET	NOCOUNT	OFF
END