﻿
/*	
Purpose					:	To populate the grid in the ControllerSetup-->Pumps/Valves tab

History					:
Sept. 2014		dfozdar@allianceglobalservice.com		initial version



*/

CREATE	PROCEDURE [TCD].[GetCompareFormulaPumpsList]
       @EcoLabAccountNumber					NVARCHAR( 25)
       ,@ControllerId							INT	
       ,@WasherProgramSetupId					int 
	  ,@ControllerEquipmentId					  int = null
       ,@IsActive								BIT = NULL
AS
     BEGIN
         SET	NOCOUNT	ON;
         DECLARE	@ErrorMessage										NVARCHAR( 4000
                                                                                        )
                    ,@PumpValveCount										TINYINT
                    ,@MECount											TINYINT
                    ,@ControllerEquipmentTypeId_PumpValve				TINYINT
                    ,@ControllerEquipmentTypeId_ME						TINYINT
                    ,@ReturnValue										INT = 0
                    ,@TagTypeLfs VARCHAR( 100) = 'Tag_NML'
                    ,@TagTypeKfactor VARCHAR( 100) = 'Tag_PPOL'
                    ,@TagTypeCalibration VARCHAR( 100) = 'Tag_OPSL';


         CREATE	TABLE #Equipment	(
         ControllerEquipmentId					INT				IDENTITY( 1, 1)
         ,ControllerEquipmentTypeId				TINYINT			NOT	NULL
         ,IsActive								BIT				NOT	NULL DEFAULT('FALSE')
         ,ProductId								INT				NULL
         ,ProductName								NVARCHAR( 255)	NULL
         --ProductMaster
         ,PumpCalibration							DECIMAL( 18, 3)	NULL
         ,FlowMeterSwitchFlag						BIT				NULL
         --NULL (not set), 0 for Meter, 1 for Switch
         ,FlowMeterCalibration					INT				NULL
         ,MaximumDosingTime						SMALLINT		NULL
         ,FlowSwitchTimeOut						SMALLINT		NULL
         ,ControllerEquipmentSetupId				SMALLINT		NULL
         ,LfsChemicalName							NVARCHAR( 200)	NULL
         ,KFactor									DECIMAL( 18, 2)	NULL
         ,TunnelHold								BIT				NULL
         ,FlowDetectorType							INT				NULL
         ,FlowSwitchAlarm							BIT				NULL
         ,FlowMeterAlarm							BIT				NULL
         ,FlowMeterType							INT				NULL
         ,FlowAlarmDelay							DECIMAL( 18, 2)	NULL
         ,FlowMeterPumpDelay						DECIMAL( 18, 2)				NULL
         ,FlowMeterAlarmDelay						DECIMAL( 18, 2)				NULL

         --Synch./Central integration additions

         ,LastModifiedTime						DATETIME		NULL
         ,LastSyncTime							DATETIME		NULL
                                        );


         IF	NOT	EXISTS	( SELECT	1
                                FROM	[TCD].ConduitController			CC
                                WHERE	CC.EcoalabAccountNumber = @EcoLabAccountNumber
                                    AND CC.ControllerId = @ControllerId
                              )
             BEGIN
                 SET			@ErrorMessage = 'Invalid Plant/Controller combination specified';

                 --GOTO		ErrorHandler

                 RAISERROR	( @ErrorMessage, 16, 1);
                 SET		@ReturnValue = -1;
                 RETURN	(@ReturnValue);
             END;


         SELECT	@ControllerEquipmentTypeId_PumpValve = CASE
                                                               WHEN	CET.ControllerEquipmentTypeName = 'Pump/Valve'
                                                               THEN	CET.ControllerEquipmentTypeId
                                                               ELSE	@ControllerEquipmentTypeId_PumpValve
                                                           END
                    ,@ControllerEquipmentTypeId_ME = CASE
                                                         WHEN	CET.ControllerEquipmentTypeName = 'ME'
                                                         THEN	CET.ControllerEquipmentTypeId
                                                         ELSE	@ControllerEquipmentTypeId_ME
                                                     END
         FROM [TCD].ControllerEquipmentType CET
         WHERE	CET.ControllerEquipmentTypeName			IN			( 'Pump/Valve', 'ME');


         SELECT	@PumpValveCount = ISNULL( CSD.Value, 0)
         FROM [TCD].ConduitController CC JOIN [TCD].ControllerModelControllerTypeMapping CMCTM ON CC.ControllerModelId = CMCTM.ControllerModelId
                                         JOIN [TCD].ControllerSetupData CSD ON CSD.ControllerId = CC.ControllerId
                                                                           AND CC.ControllerTypeId = CMCTM.ControllerTypeId
                                         JOIN [TCD].FieldGroup FG ON FG.ControllerModelId = CC.ControllerModelId
                                                                 AND FG.ControllerTypeId = CC.ControllerTypeId
                                                                 AND FG.TabId = 3
                                         INNER JOIN [TCD].FieldGroupFieldMapping FGM ON FGM.FieldGroupId = FG.Id
                                         INNER JOIN [TCD].Field F ON F.Id = FGM.FieldId
                                                                 AND CSD.FieldId = f.Id
         WHERE	CC.ControllerId = @ControllerId
           AND F.ResourceKey = 'No._of_Chemical_Valves'
           AND CSD.EcolabAccountNumber = @EcoLabAccountNumber;
         SELECT	@MECount = ISNULL( CMCTM.MECount, 0
                                     )
         FROM [TCD].ConduitController CC JOIN [TCD].ControllerModelControllerTypeMapping CMCTM ON CC.ControllerModelId = CMCTM.ControllerModelId
                                                                                              AND CC.ControllerTypeId = CMCTM.ControllerTypeId
         WHERE	CC.ControllerId = @ControllerId;



         IF	(	( SELECT	ISNULL( @PumpValveCount, 0) + ISNULL( @MECount, 0)) = 0)
             BEGIN

                 --GOTO		ExitModule
                 --Return EMPTY result set

                 SELECT

                 --*	--Change this

                 T.ControllerEquipmentId		AS			ControllerEquipmentId
                 ,T.ControllerEquipmentTypeId	AS			ControllerEquipmentTypeId
                 ,T.IsActive					AS			IsActive
                 ,T.ProductId					AS			ProductId
                 ,T.ProductName				AS			ProductName
                 ,T.PumpCalibration			AS			PumpCalibration
                 ,T.FlowMeterSwitchFlag		AS			FlowMeterSwitchFlag
                 ,T.FlowMeterCalibration		AS			FlowMeterCalibration
                 ,T.MaximumDosingTime			AS			MaximumDosingTime
                 ,T.FlowSwitchTimeOut			AS			FlowSwitchTimeOut
                 ,T.ControllerEquipmentSetupId AS			ControllerEquipmentSetupId

                 --	required in the RS for the service layer...

                 ,@EcoLabAccountNumber		AS			EcoLabAccountNumber
                 ,@ControllerId				AS			ControllerId
                 ,CC.TopicName					AS			ControllerName
                 ,CC.ControllerTypeId			AS			ControllerTypeId
                 ,T.LfsChemicalName				AS			LfsChemicalName
                 ,T.KFactor						AS			KFactor
                 ,T.TunnelHold					AS			TunnelHold
                 ,T.FlowDetectorType			AS			FlowDetectorType
                 ,T.FlowSwitchAlarm				AS			FlowSwitchAlarm
                 ,T.FlowMeterAlarm			AS			FlowMeterAlarm
                 ,T.FlowMeterType				AS			FlowMeterType
                 ,T.FlowAlarmDelay			AS			FlowAlarmDelay
                 ,T.FlowMeterPumpDelay			AS			FlowMeterPumpDelay
                 ,T.FlowMeterAlarmDelay		AS			FlowMeterAlarmDelay
                 ,( 
                    SELECT MTS.TagAddress
                    FROM TCD.ModuleTags MTS
                    WHERE MTS.TagType = @TagTypeLfs
                      AND MTS.ModuleID = ControllerEquipmentSetupId
                      AND MTS.ModuleTypeId = 4
                      AND MTS.Active = 1
                  ) AS LfsChemicalNameTag
                 ,( 
                    SELECT MTS.TagAddress
                    FROM TCD.ModuleTags MTS
                    WHERE MTS.TagType = @TagTypeKfactor
                      AND MTS.ModuleID = ControllerEquipmentSetupId
                      AND MTS.ModuleTypeId = 4
                      AND MTS.Active = 1
                  ) AS KfactorTag
                 ,( 
                    SELECT MTS.TagAddress
                    FROM TCD.ModuleTags MTS
                    WHERE MTS.TagType = @TagTypeCalibration
                      AND MTS.ModuleID = ControllerEquipmentSetupId
                      AND MTS.ModuleTypeId = 4
                      AND MTS.Active = 1
                  ) AS CalibrationTag

                 --Synch./Central integration additions

                 ,T.LastModifiedTime			AS			LastModifiedTime
                 ,T.LastSyncTime				AS			LastSyncTime
                 FROM	#Equipment					T JOIN TCD.ConduitController CC
                 ON CC.ControllerId = @ControllerId
                 WHERE	T.IsActive = ISNULL( @IsActive, T.IsActive
                                            )
                     AND T.ControllerEquipmentId = ISNULL( @ControllerEquipmentId, T.ControllerEquipmentId);
                 RETURN	(@ReturnValue);
             END;



         IF	(ISNULL( @PumpValveCount, 0) <> 0)
             BEGIN
                 WITH NumCTE	( N)
                     AS	( SELECT	'*'	AS	N
                           UNION ALL
                           SELECT	'*'	AS	N
                         )
                     INSERT INTO	#Equipment	(ControllerEquipmentTypeId)
                     SELECT	TOP ( @PumpValveCount)
                     @ControllerEquipmentTypeId_PumpValve
                     FROM	NumCTE N1	, NumCTE N2	, NumCTE N3	, NumCTE N4	, NumCTE N5;
             END;
         IF	(ISNULL( @MECount, 0) <> 0)
             BEGIN
                 WITH	NumCTE	( N)
                     AS	( SELECT	'*'	AS	N
                           UNION ALL
                           SELECT	'*'	AS	N
                         )
                     INSERT INTO	#Equipment	(ControllerEquipmentTypeId)
                     SELECT	TOP ( @MECount)
                     @ControllerEquipmentTypeId_ME
                     FROM	NumCTE N1	, NumCTE N2	, NumCTE N3	, NumCTE N4	, NumCTE N5;
             END;
         UPDATE	U
           SET	U.IsActive = CES.IsActive
               ,U.ProductId = CES.ProductId
               ,U.ProductName = PM.Name
               ,U.PumpCalibration = CES.PumpCalibration
               ,U.FlowMeterSwitchFlag = CES.FlowMeterSwitchFlag
               ,U.FlowMeterCalibration = CES.FlowMeterCalibration
               ,U.MaximumDosingTime = CES.MaximumDosingTime
               ,U.FlowSwitchTimeOut = CES.FlowSwitchTimeOut

               --update CESId here; though we are not using this as of now...

               ,U.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId
               ,U.LfsChemicalName = CES.LfsChemicalName
               ,U.KFactor = CES.KFactor
               ,U.TunnelHold = CES.TunnelHold
               ,U.FlowDetectorType = CES.FlowDetectorType
               ,U.FlowSwitchAlarm = CES.FlowSwitchAlarm
               ,U.FlowMeterAlarm = CES.FlowMeterAlarm
               ,U.FlowMeterType = CES.FlowMeterType
               ,U.FlowAlarmDelay = CES.FlowAlarmDelay
               ,U.FlowMeterPumpDelay = CES.FlowMeterPumpDelay
               ,U.FlowMeterAlarmDelay = CES.FlowMeterAlarmDelay

               --Synch./Central integration additions

               ,U.LastModifiedTime = CES.LastModifiedTime
               ,U.LastSyncTime = CES.LastSyncTime
         FROM	#Equipment U 
	    JOIN	[TCD].ControllerEquipmentSetup	CES ON	U.ControllerEquipmentId = CES.ControllerEquipmentId AND U.ControllerEquipmentTypeId = CES.ControllerEquipmentTypeId
          JOIN	[TCD].ProductMaster				PM ON	CES.ProductId = PM.ProductId
		INNER JOIN TCD.MachineSetup MS ON CES.ControllerId =MS.ControllerId AND MS.IsDeleted=0
		INNER JOIN TCD.[WasherProgramSetup] wps ON MS.GroupID =wps.WasherGroupId AND wps.Is_Deleted=0 AND wps.WasherProgramSetupId=@WasherProgramSetupId
		INNER JOIN [TCD].[WasherDosingSetup] wds ON wps.WasherProgramSetupId =wds.WasherProgramSetupId AND wds.Is_Deleted=0
		LEFT JOIN TCD.WasherDosingProductMapping wspm ON wds.WasherDosingSetupId =wspm.WasherDosingSetupId AND PM.ProductId=wspm.ProductId AND wspm.IsDeleted=0
         WHERE	CES.EcoLabAccountNumber = @EcoLabAccountNumber
           AND CES.ControllerId = @ControllerId;
         GOTO	ExitModule;

         --ErrorHandler:
         --RAISERROR	(@ErrorMessage, 16, 1)
         --SET	@ReturnValue	=	-1

         ExitModule:

         --Return result set

         SELECT

         --*	--Change this

         T.ControllerEquipmentId			AS ControllerEquipmentId
         ,T.ControllerEquipmentTypeId		AS ControllerEquipmentTypeId
         ,T.IsActive						AS IsActive
         ,T.ProductId						AS ProductId
         ,T.ProductName					AS ProductName
         ,T.PumpCalibration				AS PumpCalibration
         ,T.FlowMeterSwitchFlag			AS FlowMeterSwitchFlag
         ,T.FlowMeterCalibration			AS FlowMeterCalibration
         ,T.MaximumDosingTime				AS MaximumDosingTime
         ,T.FlowSwitchTimeOut				AS FlowSwitchTimeOut
         ,T.ControllerEquipmentSetupId	AS ControllerEquipmentSetupId

         --	required in the RS for the service layer...

         ,@EcoLabAccountNumber			AS EcoLabAccountNumber
         ,@ControllerId					AS ControllerId
         ,CC.TopicName						AS ControllerName
         ,CC.ControllerTypeId				AS ControllerTypeId
         ,T.LfsChemicalName					AS LfsChemicalName
         ,T.KFactor							AS KFactor
         ,T.TunnelHold						AS TunnelHold
         ,T.FlowDetectorType				AS FlowDetectorType
         ,T.FlowSwitchAlarm					AS FlowSwitchAlarm
         ,T.FlowMeterAlarm				AS FlowMeterAlarm
         ,T.FlowMeterType					AS FlowMeterType
         ,T.FlowAlarmDelay				AS FlowAlarmDelay
         ,T.FlowMeterPumpDelay				AS FlowMeterPumpDelay
         ,T.FlowMeterAlarmDelay			AS FlowMeterAlarmDelay
         ,( 
            SELECT MTS.TagAddress
            FROM TCD.ModuleTags MTS
            WHERE MTS.TagType = @TagTypeLfs
              AND MTS.ModuleID = ControllerEquipmentSetupId
              AND MTS.ModuleTypeId = 4
              AND MTS.Active = 1
          ) AS LfsChemicalNameTag
         ,( 
            SELECT MTS.TagAddress
            FROM TCD.ModuleTags MTS
            WHERE MTS.TagType = @TagTypeKfactor
              AND MTS.ModuleID = ControllerEquipmentSetupId
              AND MTS.ModuleTypeId = 4
              AND MTS.Active = 1
          ) AS KfactorTag
         ,( 
            SELECT MTS.TagAddress
            FROM TCD.ModuleTags MTS
            WHERE MTS.TagType = @TagTypeCalibration
              AND MTS.ModuleID = ControllerEquipmentSetupId
              AND MTS.ModuleTypeId = 4
              AND MTS.Active = 1
          ) AS CalibrationTag

         --Synch./Central integration additions

         ,T.LastModifiedTime				AS LastModifiedTime
         ,T.LastSyncTime					AS LastSyncTime
         FROM #Equipment T JOIN TCD.ConduitController CC ON CC.ControllerId = @ControllerId
         WHERE	T.IsActive = ISNULL( @IsActive, T.IsActive
                                  )
           AND T.ControllerEquipmentId = ISNULL( @ControllerEquipmentId, T.ControllerEquipmentId);

         --exit

         SET	NOCOUNT	OFF;
         RETURN	(@ReturnValue);
     END;