﻿
/*  
 ==========================================================================================  
 Purpose:  Fetching the list of ecolab saturation.  

 Author:  Phani  

 --------------------------------------------------------------  
 August-18-2014 ENT: Initial version.  
 ==========================================================================================  
*/ 
CREATE PROCEDURE [TCD].[GetEcolabSaturation] 
@TextileId INT
AS 
  BEGIN 
      SET nocount ON; 
	 IF @TextileId>0
	 BEGIN
		SELECT es.EcolabSaturationId,es.EcolabSaturationName, es.AbsorbancyFactor, es.SpeedAbsorbancyFactor, es.LowAbsorbancyFactor, es.IntermediateAborbancyFactor, es.HighAbsorbancyFactor, es.MyServiceMstrLnnTypId FROM TCD.EcolabSaturation es 
		
     END
	ELSE
	BEGIN
		SELECT es.EcolabSaturationId,es.EcolabSaturationName, es.AbsorbancyFactor, es.SpeedAbsorbancyFactor, es.LowAbsorbancyFactor, es.IntermediateAborbancyFactor, es.HighAbsorbancyFactor, es.MyServiceMstrLnnTypId FROM TCD.EcolabSaturation es 
	END
  END