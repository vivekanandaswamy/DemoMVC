CREATE PROC [TCD].[SavePumpsProducts] (
@PumpProducts TCD.udttPumpsProducts READONLY
, @ControllerId INT
, @EcolabAccountNumber NVARCHAR(25)
)
AS
BEGIN
DECLARE

@PlantId INT = (SELECT TOP 1 PlantId
FROM TCD.Plant P
WHERE P.EcolabAccountNumber = @EcolabAccountNumber)



DECLARE
@TempMapping TABLE(
RowNumber INT NOT NULL  ,
[ChemicalNumber] [int] NOT NULL,
[ProductId] [int] NOT NULL,
[LowLevelAlarm] [bit] NOT NULL,
[WeightControlledDosage] [bit] NOT NULL);

/* Create RowNumber inorder to increment and use row by row. */

WITH CTE_LCM
AS (
SELECT ROW_NUMBER() OVER (ORDER BY PP.[ChemicalNumber]) AS RowNumber
, PP.[ChemicalNumber]
, PP.[ProductId]
, PP.[LowLevelAlarm]
, PP.[WeightControlledDosage]
FROM @PumpProducts PP
)
INSERT INTO @TempMapping
SELECT *
FROM CTE_LCM CL where cl.ProductId>0;

/* Loop */

DECLARE
@i INT = 1,
@max INT = (SELECT MAX(TM.RowNumber)
FROM @TempMapping TM);
WHILE @i <= @max
BEGIN

/* Declare and Initialize the current row data */

DECLARE
@ChemicalNumber INT
SELECT TOP 1 @ChemicalNumber = TM.ChemicalNumber
FROM @TempMapping TM
WHERE TM.RowNumber = @i;


/* Update If Exists else Insert */

MERGE TCD.ControllerProductMapping P
USING (SELECT TOP 1 *
FROM @TempMapping TM
WHERE TM.RowNumber = @i) S
ON P.ControllerId = @ControllerId
AND P.ChemicalNumber = S.ChemicalNumber
AND S.ProductId > 0
WHEN MATCHED
THEN
UPDATE SET --T.TunnelNumber = S.TunnelNumber
P.ProductId = S.ProductId
, P.LowLevelAlarm = S.LowLevelAlarm
, P.WeightControlledDosage = S.WeightControlledDosage
, P.ControllerId = @ControllerId
, P.EcolabAccountNumber = @EcolabAccountNumber

WHEN NOT MATCHED
THEN
INSERT (
ControllerId
,ChemicalNumber
,ProductId
,LowLevelAlarm
,WeightControlledDosage
,EcolabAccountNumber
)
VALUES (@ControllerId,
S.ChemicalNumber,
S.ProductId,
S.LowLevelAlarm,
S.WeightControlledDosage,
@EcolabAccountNumber);

/* Increment the row */

SET @i = @i + 1;
END;
END;
