﻿ 
/*
Purpose					:	To add a new Conventional Washer from the Washer setup UI - General tab

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version

--sp_helptext	usp_AddConventional

*/

CREATE PROCEDURE	[TCD].[AddConventional]
					@EcoLabAccountNumber					NVARCHAR(25)
				,	@WasherGroupId							INT
				, @NewWasherGroupId		int				=	null
				,	@ConventionalName						NVARCHAR(50)
				,	@ModelId								INT						--(Washer)Model Id for Size
				,	@ControllerId							INT
				,	@LFSWasherNumber						TINYINT					=	NULL
				,	@PlantWasherNumber						SMALLINT
				,	@WasherMode								TINYINT
				,	@MaxLoad								SMALLINT
				,	@AWEActive								BIT
				,	@HoldSignal								BIT
				,	@HoldDelay								SMALLINT															
				,	@TargetTurnTime							SMALLINT
				,	@WaterFlushTime							SMALLINT
				,	@ProgramNumber							TINYINT					--EOF number
				,	@Description							NVARCHAR(1024)			=	NULL
				,	@UserId									INT
				,	@ConventionalWasherGuid					UniqueIdentifier
				,	@ConventionalWasherId					INT									OUTPUT
				,	@LastModifiedTimestampAtCentral			DATETIME				=	NULL
				,	@OutputLastModifiedTimestampAtLocal		DATETIME				=	NULL	OUTPUT
				,	@IsDeleted								BIT						=	'FALSE'
				,   @RatioDosingActive						BIT						=	'FALSE'
,   @IsPony      BIT      = 'FALSE'
				,	@MinMachineLoad							SMALLINT				=	NULL
				,	@MaxMachineLoad							smallint				=	NULL
				,	@ProgramSelectionByTime					bit						=	NULL
				,	@FlowSwitchNumber						int						=	NULL
				,	@WasherStopExternalSignal				bit						=	NULL
				,	@OnHoldWESignalActive					bit						=	NULL
				,	@WasherOnHoldSignalDelay				int						=	NULL
				,	@ValveOutputsUsedAsTomSignal			bit						=	NULL
				,	@WeInTomMode							bit						=	NULL
				,	@ManifoldFlushTime						int						=	NULL
				,	@L1										bit						=	NULL
				,	@L2										bit						=	NULL
				,	@L3										bit						=	NULL
				,	@L4										bit						=	NULL
				,	@L5										bit						=	NULL
				,	@L6										bit						=	NULL
				,	@L7										bit						=	NULL
				,	@L8										bit						=	NULL
				,	@L9										bit						=	NULL
				,	@L10									bit						=	NULL
				,	@L11									bit						=	NULL
				,	@L12									bit						=	NULL
				,	@MyServiceLastSyncTime					DATETIME				=	NULL
				,	@UseMe1OfGroup							tinyint					=	NULL
				,	@UseMe2OfGroup							tinyint					=	NULL
				,	@UsePumpOfGroup							tinyint					=	NULL
				,	@WasherStopUseFinalExtracting			bit						=	NULL
				,	@TemperatureAlarmYesNo					bit						=	NULL
				,   @DefaultIdleTime						INT						=   NULL
				,   @ETechWasherNumber						INT						=   NULL
				,	@SignalAcceptanceTime					int						=	NULL
				,	@ExtractTimeForEOFSignal				bit						=	'FALSE'

AS
BEGIN

SET NOCOUNT ON


DECLARE
@ReturnValue     INT    =   0
, @ErrorId      INT    =   0
, @ErrorMessage     NVARCHAR(4000) =   N''

, @WasherId      INT    =   NULL
 , @PlantId		 INT	 =	 NULL
 , @ControllerModelId INT = NULL
--, @WasherModelId     SMALLINT  =   NULL
--, @CurrentUTCTime     DATETIME  =   GETUTCDATE()     --SQLEnlight SA0004

DECLARE
@OutputList      AS TABLE  (
WasherId      INT
, LastModifiedTimestamp   DATETIME
)

SET  @ConventionalWasherId = ISNULL(@ConventionalWasherId, NULL)   --SQLEnlight
SET  @OutputLastModifiedTimestampAtLocal   =   ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)   --SQLEnlight
SET  @LastModifiedTimestampAtCentral    =   ISNULL(@LastModifiedTimestampAtCentral, NULL)    --SQLEnlight SA0029
SELECT  @PlantId = PlantId From TCD.Plant WHERE EcolabAccountNumber = @EcoLabAccountNumber
SELECT @ControllerModelId = cmctm.ControllerModelId 
FROM TCD.ControllerModelControllerTypeMapping cmctm 
INNER JOIN TCD.ConduitController cc 
	ON cc.ControllerModelId = cmctm.ControllerModelId
WHERE cc.ControllerId = @ControllerId AND cc.EcoalabAccountNumber = @EcoLabAccountNumber

--Check that the WasherGroup being associated-to is a valid Conventional-type WG...
IF NOT EXISTS ( SELECT 1
FROM [TCD].WasherGroup     WG
JOIN [TCD].WasherGroupType    WGT
ON WG.WasherGroupTypeId  =   WGT.WasherGroupTypeId
JOIN [TCD].MachineGroup     GT         --this is actually the Groups table and NOT really a Group TYPE
ON WG.WasherGroupId   =   GT.Id   --Id is actually the Id of the Group
AND WG.EcolabAccountNumber  =   GT.EcolabAccountNumber
WHERE WG.WasherGroupId   =   @WasherGroupId
AND GT.EcolabAccountNumber  =   @EcoLabAccountNumber
AND GT.GroupTypeId      =   2   --select GroupMaintype from MachineGroup
AND WGT.WasherGroupTypeName  =   'Conventional'   --select WasherGroupTypeName from WasherGroupType
AND GT.Is_Deleted    =   'FALSE'
)
BEGIN
SET  @ErrorId      =   51001
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherGroup provided.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

--Check for unique PlantWasherNo.
IF EXISTS  ( SELECT 1
FROM [TCD].Washer      W
JOIN [TCD].MachineSetup     MS
ON W.WasherId     =   MS.WasherId
AND W.EcoLabAccountNumber  =   MS.EcoalabAccountNumber
WHERE W.EcoLabAccountNumber  =   @EcoLabAccountNumber
AND (
W.PlantWasherNumber   =   @PlantWasherNumber
)
AND W.Is_Deleted    =   'FALSE'
AND MS.IsDeleted    =   'FALSE'
)
BEGIN
SET  @ErrorId      =   51002
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Specified Plant Washer #/ already exists.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

IF @ControllerId > 0
BEGIN
--Check on valid LFSWasher#/Controller type/model...
IF @LFSWasherNumber IS NOT NULL
BEGIN
	IF NOT EXISTS ( SELECT 1
	FROM [TCD].ControllerModelControllerTypeMapping
	CMCTM
	JOIN [TCD].ConduitController   CC
	ON CC.ControllerTypeId   =   CMCTM.ControllerTypeId
	AND CC.ControllerModelId  =   CMCTM.ControllerModelId
	WHERE CC.EcoalabAccountNumber  =   @EcoLabAccountNumber
	AND CC.ControllerId    =   @ControllerId
	AND CC.IsDeleted    =   'FALSE'
	AND CMCTM.MaximumWasherExtractorCount
	>=   @LFSWasherNumber
	)
		BEGIN
			SET  @ErrorId      =   51003
			SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller/LFSWasher# was provided.'
			--GOTO ErrorHandler
			RAISERROR (@ErrorMessage, 16, 1)
			SET  @ReturnValue = -1
			RETURN (@ReturnValue)
		END
END
END
--EOF should not be an asocciated formula for the WG...
IF EXISTS  ( SELECT 1
FROM [TCD].WasherProgramSetup   WPS
WHERE WPS.EcolabAccountNumber  =   @EcoLabAccountNumber
AND WPS.WasherGroupId   =   @WasherGroupId
AND WPS.ProgramNumber   =   @ProgramNumber
AND WPS.Is_Deleted    =   'FALSE'
)
BEGIN
SET  @ErrorId      =   51004
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An assoicated formula cannot be specified as End-Of-Formula.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

IF @ControllerId > 0
BEGIN
--WasherMode check
IF NOT EXISTS ( SELECT 1
FROM [TCD].ControllerModelControllerTypeMapping
CMCTM
					JOIN	[TCD].ConduitController			CC
						ON	CC.ControllerTypeId			=			CMCTM.ControllerTypeId
						AND	CC.ControllerModelId		=			CMCTM.ControllerModelId
					JOIN	[TCD].[WasherModeMapping]			CTM2WM
						ON	CMCTM.Id					=			CTM2WM.ControllerModelControllerTypeMappingId
					WHERE	CC.EcoalabAccountNumber		=			@EcoLabAccountNumber
						AND	CC.ControllerId				=			@ControllerId
						AND	CC.IsDeleted				=			'FALSE'
						AND	CTM2WM.WasherModeId			=			@WasherMode
)
BEGIN
SET  @ErrorId      =   51005
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherMode was provided.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

--LFSWasherNumber duplicate check...
IF	EXISTS	(	SELECT	1
				FROM	[TCD].MachineSetup					MS
				WHERE	MS.ControllerId					=			@ControllerId
					AND	MS.MachineInternalId			=			@LFSWasherNumber
					AND MS.EcoalabAccountNumber			=			@EcoLabAccountNumber
					AND	MS.IsDeleted					=			'FALSE'
					AND MS.IsTunnel						=			'FALSE'

)
BEGIN
SET  @ErrorId      =   51010
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate LFSWasher# provided.'
--GOTO ErrorHandler
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END
--ETechWasherNumber duplicate check...
IF(@ControllerModelId NOT IN (8,9,10,11,14))
BEGIN
IF @ETechWasherNumber > 0
BEGIN 
--ETechWasherNumber duplicate check...
IF EXISTS ( SELECT 1
    FROM [TCD].Washer  AS W
    JOIN [TCD].MachineSetup AS MS ON MS.WasherId = W.WasherId 
    where W.ETechWasherNumber = @ETechWasherNumber
   
   AND W.Is_Deleted = 0
   AND W.ETechWasherNumber <> 0
)  
BEGIN  

SET  @ErrorId      =   51012  
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate ETechWasherNumber# provided.'  
--GOTO ErrorHandler  
RAISERROR (@ErrorMessage, 16, 1)  
SET  @ReturnValue = -1  
RETURN (@ReturnValue)  
END
END
END

END
--Now attempt to insert a new row for the conventional washer being added...
BEGIN TRAN

INSERT	[TCD].Washer	(
	 EcoLabAccountNumber	,PlantWasherNumber			,ModelId				,WasherMode					,MaxLoad						,AWEActive				,EndOfFormula
	,[Description]			,Is_Deleted					,LastModifiedByUserId	,HoldSignal					,HoldDelay						,TargetTurnTime			,WaterFlushTime		
	,MyServiceCustMchGuid	,RatioDosingActive			,MyServiceLastSynchTime	,MinMachineLoad				,MaxMachineLoad					,ProgramSelectionByTime	,FlowSwitchNumber		
	,WasherStopExternalSignal	,OnHoldWESignalActive	, WasherOnHoldSignalDelay	,ValveOutputsUsedAsTomSignal			,WeInTomMode			,ManifoldFlushTime	
	,L1	,L2	,L3	,L4	,L5	,L6	,L7	,L8	,L9	 ,L10 ,L11	,L12 ,UseMe1OfGroup ,UseMe2OfGroup ,UsePumpOfGroup ,WasherStopUseFinalExtracting ,TemperatureAlarmYesNo ,PlantId, DefaultIdleTime, ETechWasherNumber,SignalAcceptanceTime
	,ExtractTimeForEOFSignal
)
OUTPUT
inserted.WasherId      AS   Id
, inserted.LastModifiedTime  AS   LastModifiedTimestamp
INTO
@OutputList (
WasherId
, LastModifiedTimestamp
)

SELECT	@EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	@PlantWasherNumber					AS			PlantWasherNumber
	,	@ModelId							AS			ModelId
	,	@WasherMode							AS			WasherMode
	,	@MaxLoad							AS			MaxLoad
	,	@AWEActive							AS			AWEActive
	,	@ProgramNumber						AS			ProgramNumber
	,	@Description						AS			[Description]
	,	@IsDeleted							AS			Is_Deleted
	,	@UserId								AS			LastModifiedByUserId
	,	@HoldSignal							AS			HoldSignal
	,	@HoldDelay							AS			HoldDelay
	,	@TargetTurnTime						AS			TargetTurnTime
	,	@WaterFlushTime						AS			WaterFlushTime
	,	@ConventionalWasherGuid				AS			MyServiceCustMchGuid
	,	@RatioDosingActive					AS			RatioDosingActive
	,	@MyServiceLastSyncTime				AS			MyServiceLastSynchTime
	,	@MinMachineLoad						AS			MinimumMachineLoad
	,	@MaxMachineLoad						AS			MaximumMachineLoad
	,	@ProgramSelectionByTime				AS			ProgramSelectionByTime
	,	@FlowSwitchNumber					AS			FlowSwitchNumber
	,	@WasherStopExternalSignal			AS			WasherStopExternalSignal
	,	@OnHoldWESignalActive				AS			OnHoldWESignalActive
	,	@WasherOnHoldSignalDelay			AS			WasherOnHoldSignalDelay
	,	@ValveOutputsUsedAsTomSignal		AS			ValveOutputsUsedAsTomSignal
	,	@WeInTomMode						AS			WeInTomMode			
	,	@ManifoldFlushTime					AS			ManifoldFlushTime			
	,	@L1									AS			L1
	,	@L2									AS			L2
	,	@L3									AS			L3
	,	@L4									AS			L4
	,	@L5									AS			L5
	,	@L6									AS			L6
	,	@L7									AS			L7
	,	@L8									AS			L8
	,	@L9									AS			L9
	,	@L10								AS			L10
	,	@L11								AS			L11
	,	@L12								AS			L12
	,	@UseMe1OfGroup						AS			UseMe1OfGroup
	,	@UseMe2OfGroup						AS			UseMe2OfGroup
	,	@UsePumpOfGroup						AS			UsePumpOfGroup
	,	@WasherStopUseFinalExtracting		AS			WasherStopUseFinalExtracting
	,	@TemperatureAlarmYesNo				AS			TemperatureAlarmYesNo
	,	@PlantId							AS			PlantId
	,   @DefaultIdleTime AS   DefaultIdleTime 
	,   @ETechWasherNumber AS ETechWasherNumber
	,	@SignalAcceptanceTime				AS			SignalAcceptanceTime
	,	@ExtractTimeForEOFSignal		AS			ExtractTimeForEOFSignal

SET @ErrorId = @@ERROR

IF (@ErrorId <> 0)
BEGIN
IF @@TRANCOUNT > 0
BEGIN
ROLLBACK TRAN
END

SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred creating new record for conventional.'
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END

--if no error, collect the id of the newly generated row...
SELECT TOP 1 @WasherId = O.WasherId FROM @OutputList O

--insert in MachineSetup
INSERT [TCD].MachineSetup (
WasherId ,GroupId ,MachineInternalId ,EcoalabAccountNumber ,MachineName ,IsTunnel ,ControllerId , IsDeleted ,LastModifiedByUserId,IsPony )
SELECT @WasherId     AS   WasherId
, @WasherGroupId    AS   GroupId
, @LFSWasherNumber   AS   MachineInternalId
, @EcoLabAccountNumber  AS   EcoalabAccountNumber
, @ConventionalName   AS   MachineName
, 'FALSE'     AS   IsTunnel 
, @ControllerId    AS   ControllerId
, @IsDeleted      AS   IsDeleted
, @UserId      AS   LastModifiedByUserId
,@IsPony As IsPony



 IF(ISNULL( @NewWasherGroupId,0)>0 AND (@WasherGroupId != @NewWasherGroupId))
 BEGIN
    UPDATE tcd.machinesetup 
    SET GroupId = @NewWasherGroupId
    WHERE WasherId = @WasherId
     
   EXEC TCD.SaveInjectionDetails @WasherGroupId,@NewWasherGroupId,@ControllerId,@WasherId,@EcolabAccountNumber
 END
 ELSE
 BEGIN
   EXEC TCD.SaveInjectionDetails @WasherGroupId,@WasherGroupId,@ControllerId,@WasherId,@EcolabAccountNumber
 END

SET @ErrorId = @@ERROR

IF (@ErrorId <> 0)
BEGIN
IF @@TRANCOUNT > 0
BEGIN
ROLLBACK TRAN
END

SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred assoicating new record for conventional.'
RAISERROR (@ErrorMessage, 16, 1)
SET  @ReturnValue = -1
RETURN (@ReturnValue)
END
ELSE
BEGIN
IF @@TRANCOUNT > 0
BEGIN
COMMIT
END

--SET the output param to be communicated back...

SELECT TOP 1
@OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp
, @ConventionalWasherId    = O.WasherId
FROM @OutputList       O

END




IF ( @ErrorId = 0 )
BEGIN
		IF (@ControllerModelId = 7)
			BEGIN
				UPDATE TCD.WasherGroup SET ControllerId = @ControllerId WHERE WasherGroupId = @WasherGroupId
			END
RETURN (@ReturnValue)
END



--ErrorHandler:
--RAISERROR (@ErrorMessage, 16, 1)
--SET @ReturnValue = -1


--ExitModule:

--RETURN (@ReturnValue)

--SET NOCOUNT OFF

END