﻿/*      
 ==========================================================================================      
 Purpose:  Fecthing the Chemical Names from product Master    
    
 Author:  Krishna Gangadhar Thota  
    
 --------------------------------------------------------------      
 Sep-04-2014 ENT: Initial version.      
 ==========================================================================================  
  [dbo].[usp_GetChemicalName],    
*/     
CREATE PROCEDURE [TCD].[GetChemicalName](@ChemName Varchar(1000),@EcolabAccountNumber nvarchar(25))     
AS     
SET NOCOUNT ON    
  BEGIN     
  DECLARE @RegionId int
  DECLARE @Country VARCHAR(250)
  SELECT @RegionId = RegionID from [TCD].Plant WHERE EcolabAccountNumber = @EcolabAccountNumber
  SELECT @Country = ISNULL(NULLIF(PLA.Country, ''), PLA.Shippingcountry) FROM [TCD].Plant P JOIN [TCD].PlantCustAddress PLA ON P.EcolabAccountNumber = PLA.EcolabAccountNumber 
	   WHERE P.EcolabAccountNumber = @EcolabAccountNumber

IF @RegionId = 1

BEGIN
SELECT M.ProductId, RTRIM(Name) + ' ( ' + RTRIM(SKU) + ' )' as Name, 
 (CASE WHEN ISNULL( M.Cost,0)>0 then M.Cost 
		WHEN ISNULL(PSP.ListPrice,0)>0 THEN PSP.ListPrice
		WHEN ISNULL(PSP.ContractPrice,0)>0 THEN PSP.ContractPrice
		WHEN ISNULL(PSP.CountryPrice,0)>0 THEN PSP.CountryPrice
		ELSE M.Cost 
 END) Cost
 
 ,M.IncludeinCI
 FROM [TCD].ProductMaster M    
 LEFT JOIN TCD.ProductStandardPrice PSP on M.ProductId=PSP.ProductId and PSP.EcolabAccountNumber=@EcolabAccountNumber
 WHERE (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
 AND M.RegionId = @RegionId
 AND M.Country IS NOT NULL
 AND M.Is_Deleted =0
 AND NOT EXISTS (SELECT ProductId     
     FROM   [TCD].ProductdataMapping Map     
                 WHERE  M.ProductId = Map.ProductId AND Map.Is_Deleted=0)  
				 Order By M.Name
END

ELSE IF @RegionId = 2

BEGIN
SELECT * FROM (

 SELECT M.ProductId, RTRIM(Name) + ' ( ' + RTRIM(SKU) + ' )' as Name, 
 (CASE WHEN ISNULL( M.Cost,0)>0 then M.Cost 
		WHEN ISNULL(PSP.ListPrice,0)>0 THEN PSP.ListPrice
		WHEN ISNULL(PSP.ContractPrice,0)>0 THEN PSP.ContractPrice
		WHEN ISNULL(PSP.CountryPrice,0)>0 THEN PSP.CountryPrice
		ELSE M.Cost 
 END) Cost
 
 ,M.IncludeinCI
 FROM [TCD].ProductMaster M    
 LEFT JOIN TCD.ProductStandardPrice PSP on M.ProductId=PSP.ProductId and PSP.EcolabAccountNumber=@EcolabAccountNumber
 WHERE (M.SKU LIKE '%' + @ChemName + '%' OR M.Name LIKE '%' + @ChemName + '%') 
 AND M.RegionId = @RegionId
 AND M.Country IS NOT NULL
 AND M.Is_Deleted =0
 AND NOT EXISTS (SELECT ProductId     
     FROM   [TCD].ProductdataMapping Map     
                 WHERE  M.ProductId = Map.ProductId AND Map.Is_Deleted=0)  
 AND M.SourceSystemId = (SELECT p.SourceSystemId FROM TCD.Plant p)
--Order By M.Name  
) a 
WHERE a.Cost > 0 and a.Cost is not null ORDER BY a.Name
  END
END
GO
