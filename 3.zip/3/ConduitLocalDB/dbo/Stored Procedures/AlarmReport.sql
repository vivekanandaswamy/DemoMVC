
--exec [TCD].[AlarmReport] '','','','','','','','','','','','','2014-10-01','2014-10-31',1
--EXEC [TCD].[AlarmReport] '','','','','','','','','','','2014-10-01','2014-10-31','','',1  -- Alarm Summary Report

--EXEC [TCD].[AlarmReport] '','','','','','','','','','','2014-10-01','2014-10-31','','',2  -- Alarm Details Report



CREATE PROCEDURE [TCD].[AlarmReport] (

										  @Corporate Varchar(max) = '',

										  @Country Varchar(max) = '',

										  @Region Varchar(max) = '',

										  @EcolabAccountNumber Nvarchar(25) = '',

										  @Controller Varchar(max) = '',

										  @Machine Varchar(max) = '', 

										  @machineGroup Varchar(max) = '',

										  @Formula Varchar(max) = '',

										  @MachineType Varchar(20)= '',

										  @Alarm Varchar(max) = '',

										  @FromDate Date = '',

										  @ToDate Date = '',

										  @GroupId Varchar(max) = '',

										  @MachineInternalId Varchar(max) = '',

										  @ReportType Int = NULL

									   )

AS   

BEGIN   

SET nocount ON;   

DECLARE @Month INT = MONTH(GETDATE()),
	   @SummationInMin Int = NULL

SET		@Region			=			ISNULL(@Region, NULL)			--SQLEnlight SA0029


DECLARE @ControllerTable TABLE(Controller Varchar(100))
INSERT INTO @ControllerTable(Controller) EXEC [TCD].[charlistToTable] @Controller,','


DECLARE @MachineTable TABLE(Machine Varchar(100))
INSERT INTO @MachineTable(Machine) EXEC [TCD].[charlistToTable] @Machine,','


DECLARE @GroupMachineTable TABLE(GroupId INT,MachineInternalId INT)  
INSERT INTO @GroupMachineTable(GroupId,MachineInternalId)
SELECT GroupId,MachineInternalId FROM TCD.MachineSetup MS 
INNER JOIN TCD.Washer WS ON MS.WasherId = WS.WasherId WHERE WS.PlantWasherNumber IN (SELECT Machine FROM @MachineTable);

									
DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))
INSERT INTO @WasherGroupTable(MachineGroup) EXEC [TCD].[charlistToTable] @machineGroup,','

DECLARE @FormulaTable TABLE(Formula Varchar(100))
INSERT INTO @FormulaTable(Formula) EXEC [TCD].[charlistToTable] @Formula,','

DECLARE @AlarmsTable TABLE(Alarm Varchar(100))
INSERT INTO @AlarmsTable(Alarm) EXEC [TCD].[charlistToTable] @Alarm,','

DECLARE @GroupTable TABLE(GroupId Varchar(100))
INSERT INTO @GroupTable(GroupId) EXEC [TCD].[CharlistToTable] @GroupId,','

DECLARE @MachineInternalTable TABLE(MachineInternalId Varchar(100))
INSERT INTO @MachineInternalTable(MachineInternalId) EXEC [TCD].[CharlistToTable] @MachineInternalId,','


	  DECLARE @AlarmTable TABLE(
	  						 AlarmDescription NVarchar(2000),
							 Controller Nvarchar(100),
							 -- Name Nvarchar(100),

							-- MachineName Nvarchar(100),

							 --ProgramNumber Nvarchar(1000),

							 StartDate Datetime,

							 EndDate Datetime,

							 SecDuration INT

						  )

INSERT INTO @AlarmTable(
					 AlarmDescription,
					 Controller,
					 StartDate,
					 EndDate,
					 SecDuration  
				    )
SELECT 
		  DISTINCT
		  AM.Description,	
		  (SELECT cc.Name FROM [TCD].ConduitController CC  WHERE cc.ControllerId = AD.ControllerId) AS Controller,
		  --pm.Name,
		  --MS.MachineName,
		  --(SELECT PG.Name FROM [TCD].ProgramMaster PG WHERE PG.ProgramId = AD.ProgramId) AS ProgramNumber,
		  AD.StartDate,
		  AD.EndDate,
		  DATEDIFF(SECOND,AD.StartDate,AD.EndDate)

	  FROM [TCD].AlarmData AS AD
		   INNER JOIN [TCD].AlarmGroupMaster AM ON AD.AlarmGroupMasterId = AM.AlarmGroupMasterId
		   --LEFT OUTER JOIN [TCD].BatchProductData BPD ON AD.BatchId = BPD.BatchID
		   --LEFT OUTER JOIN [TCD].ProductMaster PM ON BPD.ProductID = PM.ProductId
		   --INNER JOIN [TCD].MachineSetup MS ON AD.GroupId = MS.GroupId AND AD.MachineNumber = MS.MachineInternalId

		   

		   WHERE 

				CASE @Controller   

                                           

				 WHEN '' THEN 'TRUE'         

				 ELSE                                                      

				  CASE WHEN AD.ControllerId IN (SELECT Controller FROM @ControllerTable) THEN 'TRUE' END                                                      

				END='TRUE' 



				AND       

				

				CASE @Machine   

                                           

				 WHEN '' THEN 'TRUE'         

				 ELSE                                                      

				  CASE WHEN AD.GroupId IN (SELECT GroupId FROM @GroupMachineTable) AND AD.MachineInternalId  IN (SELECT MachineInternalId FROM @GroupMachineTable) THEN 'TRUE' END                                                      

				END='TRUE' 



				AND       



				CASE @machineGroup   

                                           

				 WHEN '' THEN 'TRUE'         

				 ELSE                                                      

				  CASE WHEN AD.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable) THEN 'TRUE' END                                    

				END='TRUE' 



				AND    

				

				CASE @Formula   

                                           

				 WHEN '' THEN 'TRUE'         

				 ELSE                                                      

				  CASE WHEN AD.ProgramId IN (SELECT Formula FROM @FormulaTable) THEN 'TRUE' END                                                      

				END='TRUE' 



				AND       

				

				CASE @MachineType   

                                           

				 WHEN '' THEN 'TRUE'         

				 ELSE                                                      

				  CASE WHEN AD.GroupId IN (SELECT WG.WasherGroupId FROM [TCD].WasherGroup WG WHERE WG.WasherGroupTypeId = @MachineType) THEN 'TRUE' END                                                      

				END='TRUE' 

				AND       

				CASE @FromDate                                                                                

				    WHEN '' THEN Case WHEN MONTH(AD.StartDate) = @Month Then  'true' END                                                                                

				    ELSE CASE WHEN AD.StartDate >= @FromDate and AD.EndDate<=dateadd(dd,1,@ToDate) THEN 'true'END                                                        

				 END='true'


				 AND

				 CASE @Alarm   

				 WHEN '' THEN 'TRUE'         

				 ELSE                                                      

				  CASE WHEN AD.AlarmCode IN (SELECT Alarm FROM @AlarmsTable) THEN 'TRUE' END                                                      

				END='TRUE' 

				AND

				 CASE @GroupId 
                                           
				 WHEN '' THEN 'TRUE' 
				 ELSE        
				CASE WHEN (AD.GroupId IN (@GroupId) AND 
				  AD.MachineInternalId  IN (@MachineInternalId)) THEN 'TRUE' END                                                   
				END='TRUE' 

				AND

				 CASE @MachineInternalId 
                                           
				 WHEN '' THEN 'TRUE' 
				 ELSE        
				CASE WHEN (AD.GroupId IN (@GroupId) AND 
				  AD.MachineInternalId  IN (@MachineInternalId)) THEN 'TRUE' END                                                   
				END='TRUE' 


    IF(@ReportType = 1)   --Alarm Summary Report Condition

    BEGIN

		  SELECT	
		  	    DISTINCT

				    C.AlarmDescription,

				    COUNT(1) AS NumberOfAlarms,

				    (SELECT RIGHT('0' + CAST(SUM(SecDuration) / 3600 AS VARCHAR),2) + ':' +

						  RIGHT('0' + CAST((SUM(SecDuration) / 60) % 60 AS VARCHAR),2)  + ':' +

						  RIGHT('0' + CAST(SUM(SecDuration) % 60 AS VARCHAR),2)) AS AlarmDuration,

				    C.Controller 

			    FROM @AlarmTable C 

			    GROUP BY C.alarmDescription,

					   C.Controller

    END

    IF(@ReportType = 2) --Alarm Details Report Condition

    BEGIN

		   SELECT 

				    DISTINCT 

				    C.AlarmDescription,

				    C.StartDate,

				    C.EndDate,

				    (SELECT RIGHT('0' + CAST(DATEDIFF(SECOND,C.StartDate,C.EndDate) / 3600 AS VARCHAR),2) + ':' +

						  RIGHT('0' + CAST((DATEDIFF(SECOND,C.StartDate,C.EndDate) / 60) % 60 AS VARCHAR),2)  + ':' +

						  RIGHT('0' + CAST(DATEDIFF(SECOND,C.StartDate,C.EndDate) % 60 AS VARCHAR),2)) AS AlarmDuration,

				    C.Controller

			    FROM @AlarmTable C 

			    

    END

SET nocount OFF;

END