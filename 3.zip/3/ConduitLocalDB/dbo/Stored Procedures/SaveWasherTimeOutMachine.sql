CREATE PROCEDURE TCD.SaveWasherTimeOutMachine (
     @WasherTimeOutMachine TCD.WasherTimeOutMachine READONLY 
    , @EcolabAccountNumber NVARCHAR(25)
    , @UserId INT)
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @CurrentUTC DATETIME = GETUTCDATE()
        ,      @PlantId INT = (SELECT P.PlantId 
                       FROM TCD.Plant P 
                      WHERE P.EcolabAccountNumber = @EcolabAccountNumber)

INSERT INTO TCD.WasherTimeOutMachine
(
    WasherId,
    PlantId,
    SignalNumber,
    EquipmentNumber,
    DosingPointNumber,
    LastModifiedByUserId,
    LastModifiedTime
)
SELECT uwtom.WasherId,
      @PlantId,
      uwtom.SignalNumber,
      uwtom.EquipmentNumber,
      uwtom.DosingPointNumber,
      @UserId,
      @CurrentUTC
FROM @WasherTimeOutMachine AS uwtom 
LEFT JOIN  TCD.WasherTimeOutMachine AS wtom 
ON 
	wtom.WasherId = uwtom.washerId 
AND wtom.SignalNumber = uwtom.SignalNumber 
AND wtom.PlantId = @PlantId
WHERE 
wtom.washerId IS NULL  



UPDATE wtom
SET
    wtom.EquipmentNumber = uwtom.EquipmentNumber, -- int
    wtom.DosingPointNumber = uwtom.DosingPointNumber,
    wtom.LastModifiedByUserId = @UserId,
    wtom.LastModifiedTime = @CurrentUTC
FROM TCD.WasherTimeOutMachine wtom
INNER JOIN @WasherTimeOutMachine uwtom
ON wtom.WasherId = uwtom.WasherId
AND wtom.PlantId = @PlantId
AND wtom.SignalNumber = uwtom.SignalNumber
END