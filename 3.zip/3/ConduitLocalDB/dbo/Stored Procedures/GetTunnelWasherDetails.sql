﻿CREATE PROCEDURE [TCD].[GetTunnelWasherDetails]
(
	@washerID INT
)
AS
BEGIN

	 SELECT  DISTINCT ws.WasherId
					,TPS.NominalLoad [Standard Weight]
					,MST.NumberOfComp [NumberOfCompartments]
					,TPS.ProgramNumber		
	FROM [TCD].Washer WS
	INNER JOIN [TCD].MachineSetup MST ON MST.WasherId = ws.WasherId
	INNER JOIN [TCD].WasherGroup WG ON WG.WasherGroupId = MST.GroupId
	INNER JOIN [TCD].WasherGroupType WGT ON WGT.WasherGroupTypeId = WG.WasherGroupTypeId
	INNER JOIN [TCD].TunnelProgramSetup TPS ON TPS.WasherGroupId = WG.WasherGroupId
	INNER JOIN [TCD].TunnelDosingSetup TDS ON TDS.TunnelProgramSetupId = TPS.TunnelProgramSetupId
	LEFT JOIN [TCD].TunnelDosingProductMapping  TDPM ON TDPM.TunnelDosingSetupId =TDS.TunnelDosingSetupId
	WHERE MST.WasherId = @washerId

END