﻿/*	

Purpose					:	To get the Tunnel Connections - Connections tab

*/

CREATE PROCEDURE	[TCD].[GetTunnelConnections]
					
	@Machineid INT,
	@Controllerid INT,
	@EcolabAccNumber NVARCHAR(25)= NULL
AS
BEGIN

SELECT 
CES.ControllerId AS ControllerId
,CAST(CES.LineNumber AS int) AS DosingLineNumber
,CAST(TCEVM.DosingPointNumber AS int) AS DosingPointNumber
,CAST(TCEVM.ValveNumber AS int) AS ValveNumber
,CAST(TCEVM.TunnelNumber AS int) AS MachineInternalId
,CAST(TCEVM.CompartmentNumber AS int) AS TunnelCompartmentNumber
,CAST(CC.ControllerModelId AS int) AS ControllerModelId
,CASE WHEN CES.ControllerEquipmentTypeId = 2 AND (CES.ControllerEquipmentId = 13 OR CES.ControllerEquipmentId = 27) THEN 'ME1'
		WHEN CES.ControllerEquipmentTypeId = 2 AND (CES.ControllerEquipmentId = 14 OR CES.ControllerEquipmentId = 28) THEN 'ME2'
		ELSE 'PUMP' END AS ControllerEquipmentType
FROM TCD.TunnelCompartmentEquipmentValveMapping AS TCEVM
INNER JOIN TCD.ControllerEquipmentSetup CES ON TCEVM.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId
INNER JOIN TCD.MachineSetup AS MS ON TCEVM.TunnelNumber = MS.MachineInternalId AND CES.ControllerId = MS.ControllerId
INNER JOIN TCD.ConduitController CC ON CC.ControllerId = CES.ControllerId
WHERE MS.WASHERID = @Machineid AND CES.CONTROLLERID = @Controllerid

END


