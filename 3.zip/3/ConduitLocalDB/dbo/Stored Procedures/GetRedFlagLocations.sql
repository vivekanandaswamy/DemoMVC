CREATE PROCEDURE [TCD].[GetRedFlagLocations](@ItemId INT, @EcolabAccountNumber nvarchar(25))
AS

BEGIN
SET nocount ON;

SET			@EcolabAccountNumber			=			ISNULL(@EcolabAccountNumber, NULL)			--SQLEnlight SA0029

Declare @LocationTable Table(
Id INT,
GroupDescription nvarchar(100),
GroupTypeId INT
)


If (@ItemId IN (1,2,5,12,13,14,15,16,17,20,21,22,23,24,25,26,28,29,30,31,32,33))
begin
	INSERT INTO @LocationTable	(Id,GroupDescription,GroupTypeId)

	SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.GroupTypeId = 1 AND GT.Is_Deleted = 0
	UNION ALL
		SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT INNER JOIN [TCD].MachineSetup MS
		ON GT.Id = MS.GroupId WHERE GT.Is_Deleted = 0
		
		
END
ELSE IF (@ItemId IN (11))
BEGIN
	INSERT INTO @LocationTable	(Id,GroupDescription,GroupTypeId)
	SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.GroupTypeId = 1 AND GT.Is_Deleted = 0
END
ELSE IF(@ItemId IN (3,18,19))
BEGIN
	INSERT INTO @LocationTable	(Id,GroupDescription,GroupTypeId)
	SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.GroupTypeId = 1 AND GT.Is_Deleted = 0
	UNION ALL
	SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT INNER JOIN [TCD].MachineSetup MS
	ON GT.Id = MS.GroupId WHERE GT.Is_Deleted = 0 AND MS.IsTunnel = 0
	
END
ELSE IF(@ItemId = 4)
BEGIN
	INSERT INTO @LocationTable	(Id,GroupDescription,GroupTypeId)
		
	SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.GroupTypeId = 1 AND GT.Is_Deleted = 0
	UNION ALL
	SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT INNER JOIN [TCD].MachineSetup MS
	ON GT.Id = MS.GroupId WHERE GT.Is_Deleted = 0 AND MS.IsTunnel = 1

END


ELSE IF(@ItemId = 6)
BEGIN
INSERT INTO @LocationTable	(Id,GroupDescription,GroupTypeId)
SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.GroupTypeId = 1 AND GT.Is_Deleted = 0
UNION ALL
SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT INNER JOIN [TCD].Meter M ON GT.Id = M.GroupId AND M.utilityType = 2 AND GT.Is_deleted = 0 AND M.Is_deleted = 0


END

ELSE IF(@ItemId = 7)
BEGIN
INSERT INTO @LocationTable	(Id,GroupDescription,GroupTypeId)
SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.GroupTypeId = 1 AND GT.Is_Deleted = 0
UNION ALL
SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT INNER JOIN [TCD].Meter M ON GT.Id = M.GroupId AND M.utilityType in (1,3,4) AND GT.Is_deleted = 0 AND M.Is_deleted = 0


END

ELSE IF(@ItemId = 8)
BEGIN
INSERT INTO @LocationTable	(Id,GroupDescription,GroupTypeId)
SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.GroupTypeId = 1 AND GT.Is_Deleted = 0
UNION ALL
SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT INNER JOIN [TCD].Meter M ON GT.Id = M.GroupId AND M.utilityType in (1) AND GT.Is_deleted = 0 AND M.Is_deleted = 0


END

ELSE IF(@ItemId = 9)
BEGIN
	INSERT INTO @LocationTable	(Id,GroupDescription,GroupTypeId)
	SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.GroupTypeId = 1 AND GT.Is_Deleted = 0
	UNION ALL
	SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT WHERE (GroupTypeId = 2 OR gt.Id = 0) AND GT.Is_Deleted = 0
	
	
END

ELSE IF(@ItemId = 10)
BEGIN
	INSERT INTO @LocationTable	(Id,GroupDescription,GroupTypeId)
	SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.GroupTypeId = 1 AND GT.Is_Deleted = 0
	UNION ALL
	SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT INNER JOIN [TCD].Dryers D ON GT.Id = D.DryerGroupId
	WHERE (GroupTypeId = 3 OR gt.Id = 0) AND GT.Is_Deleted = 0
	
	
END

ELSE IF(@ItemId = 27)
BEGIN
		INSERT INTO @LocationTable	(Id,GroupDescription,GroupTypeId)

	SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.GroupTypeId = 1 AND GT.Is_Deleted = 0
END

--DECLARE
--	@PlantId INT = (SELECT MG.Id
--				   FROM TCD.MachineGroupType MGT
--					   INNER JOIN
--					   TCD.MachineGroup MG ON MGT.Id = MG.GroupTypeId
--				   WHERE MGT.Id = 1
--					AND MG.Is_Deleted = 0);
--/*For The following Items, The Machine Dropdown should not be displayed. 
--  So for others we need not display locations which are pointing to Location Level*/
--IF(@ItemId = 2 OR @ItemId = 6 OR @ItemId = 7 OR @ItemId = 8 OR @ItemId = 9)
--BEGIN
--SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.Is_Deleted = 0 AND GT.Id=1 
--UNION
--SELECT DISTINCT L.Id,L.GroupDescription,L.GroupTypeId FROM @LocationTable L
--LEFT JOIN	TCD.Meter M ON L.Id = CASE M.IsPlant WHEN 'TRUE' THEN COALESCE(  M.GroupId ,@PlantId) ELSE M.GroupId END
--LEFT JOIN	TCD.Sensor S ON L.Id = CASE S.IsPlant WHEN 'TRUE' THEN COALESCE(  S.GroupId ,@PlantId) ELSE S.GroupId END
--WHERE ((S.SensorId	IS NOT NULL
--    AND S.Is_deleted = 0)
--	OR (M.MeterId	IS NOT NULL
--    AND M.Is_deleted = 0))
--END 
--ELSE
--BEGIN
----SELECT GT.Id,GT.GroupDescription,GT.GroupTypeId FROM [TCD].MachineGroup GT WHERE GT.Is_Deleted = 0 AND GT.Id=1 
----UNION
--SELECT DISTINCT L.Id,L.GroupDescription,L.GroupTypeId FROM @LocationTable L
----LEFT JOIN	TCD.Meter M ON L.Id = CASE M.IsPlant WHEN 'TRUE' THEN COALESCE(  M.GroupId ,@PlantId) ELSE M.GroupId END
----LEFT JOIN	TCD.Sensor S ON L.Id = CASE S.IsPlant WHEN 'TRUE' THEN COALESCE(  S.GroupId ,@PlantId) ELSE S.GroupId END
----WHERE ((S.SensorId	IS NOT NULL
----    AND S.Is_deleted = 0
----    AND S.MachineCompartment	IS NULL)
----	OR (M.MeterId	IS NOT NULL
----    AND M.Is_deleted = 0
----    AND M.MachineCompartment	IS NULL))
--END
SELECT DISTINCT L.Id,L.GroupDescription,L.GroupTypeId FROM @LocationTable L
SET nocount OFF;
END