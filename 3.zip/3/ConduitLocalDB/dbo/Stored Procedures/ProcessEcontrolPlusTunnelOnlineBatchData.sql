﻿CREATE PROCEDURE [TCD].[ProcessEcontrolPlusTunnelOnlineBatchData]
(
	@ControllerID   INT,
	@xmlTags        XML
)
AS
    BEGIN
	   CREATE TABLE #OnlineBatchData
	   (
		  ControllerID int,
		  CompartmentNumber int,
		  BatchNumber int,
		  EcolabWasherID int,
		  GroupID int,
		  MachineInternalID int,
		  MachineID int,
		  PlantWasherNumber int,
		  StartDate datetime2(7),
		  ProgramNumber int,
		  ProgramMasterID int,
		  CustomerNumber nvarchar(50),
		  ActualWeight int,
		  StandardWeight int,
		  PHValue decimal(18, 4),
		  PHStatus smallint,
		  LFValue decimal(18, 4),
		  LFStatus smallint,
		  Temp1Max decimal(18, 0),
		  Temp1Min decimal(18, 0),
		  Temp1MinStatus smallint,
		  Temp2Max decimal(18, 4),
		  Temp2Min decimal(18, 4),
		  Temp2MinStatus smallint,
		  Temp3Max decimal(18, 4),
		  Temp3Min decimal(18, 4),
		  Temp3MinStatus smallint,
		  Temp4Max decimal(18, 4),
		  Temp4Min decimal(18, 4),
		  Temp4MinStatus smallint,
		  Temp5Max decimal(18, 4),
		  Temp5Min decimal(18, 4),
		  Temp5MinStatus smallint,
		  Temp6Max decimal(18, 4),
		  Temp6Min decimal(18, 4),
		  Temp6MinStatus smallint,
		  WaterConsumptionCounter1 float,
		  WaterConsumptionCounter2 float,
		  WaterConsumptionCounter3 float,
		  WaterConsumptionCounter4 float,
		  WaterConsumptionCounter5 float,
		  WaterConsumptionCounter6 float,
		  TransferSignal bit,
		  RunState bit
	   )
	   INSERT INTO #OnlineBatchData
	   SELECT
			 @ControllerID,
			 T.c.value('@CompartmentNumber', 'INT') CompartmentNumber,
			 T.c.value('@BatchNumber', 'INT') BatchNumber,
			 w.EcolabWasherID,
			 wg.WasherGroupId,
			 T.c.value('@MachineNumber', 'INT') MachineNumber,
			 w.WasherId,
			 w.PlantWasherNumber,
			 T.c.value('@StartDateTime', 'DATETIME') StartDateTime,
			 T.c.value('@ProgramNumber', 'INT') ProgramNumber,
			 (	
				SELECT ProgramId 
				FROM TCD.TunnelProgramSetup AS tps
			 	WHERE tps.WasherGroupId = wg.WasherGroupId
					 AND tps.is_deleted = 0
			 		 AND ProgramNumber = T.c.value('@ProgramNumber', 'INT')
			 ) ProgramMasterID,
			 T.c.value('@CustomerNumber', 'INT') CustomerNumber,
			 T.c.value('@Load', 'DECIMAL(18,4)') Load,
			 T.c.value('@Nominalload', 'DECIMAL(18,4)') Nominalload,
			 T.c.value('@Phvalue', 'DECIMAL(18,4)') PHValue,
			 T.c.value('@Phstatus', 'DECIMAL(18,4)') PHStatus,
			 T.c.value('@LFValue', 'DECIMAL(18,4)') LFValue,
			 T.c.value('@LFStatus', 'DECIMAL(18,4)') LFStatus,
			 T.c.value('TemperatureData[1]/@Maximum', 'DECIMAL(18,4)') Temp1Max,
			 T.c.value('TemperatureData[1]/@Minimum', 'DECIMAL(18,4)') Temp1Min,
			 T.c.value('TemperatureData[1]/@Status', 'DECIMAL(18,4)') Temp1MinStatus,
			 T.c.value('TemperatureData[2]/@Maximum', 'DECIMAL(18,4)') Temp2Max,
			 T.c.value('TemperatureData[2]/@Minimum', 'DECIMAL(18,4)') Temp2Min,
			 T.c.value('TemperatureData[2]/@Status', 'DECIMAL(18,4)') Temp2MinStatus,
			 T.c.value('TemperatureData[3]/@Maximum', 'DECIMAL(18,4)') Temp3Max,
			 T.c.value('TemperatureData[3]/@Minimum', 'DECIMAL(18,4)') Temp3Min,
			 T.c.value('TemperatureData[3]/@Status', 'DECIMAL(18,4)') Temp3MinStatus,
			 T.c.value('TemperatureData[4]/@Maximum', 'DECIMAL(18,4)') Temp4Max,
			 T.c.value('TemperatureData[4]/@Minimum', 'DECIMAL(18,4)') Temp4Min,
			 T.c.value('TemperatureData[4]/@Status', 'DECIMAL(18,4)') Temp4MinStatus,
			 T.c.value('TemperatureData[5]/@Maximum', 'DECIMAL(18,4)') Temp5Max,
			 T.c.value('TemperatureData[5]/@Minimum', 'DECIMAL(18,4)') Temp5Min,
			 T.c.value('TemperatureData[5]/@Status', 'DECIMAL(18,4)') Temp5MinStatus,
			 T.c.value('TemperatureData[6]/@Maximum', 'DECIMAL(18,4)') Temp6Max,
			 T.c.value('TemperatureData[6]/@Minimum', 'DECIMAL(18,4)') Temp6Min,
			 T.c.value('TemperatureData[6]/@Status', 'DECIMAL(18,4)') Temp6MinStatus,
			 T.c.value('WaterConsumption[1]/@Value', 'DECIMAL(18,4)') WaterConsumptionCounter1,
			 T.c.value('WaterConsumption[2]/@Value', 'DECIMAL(18,4)') WaterConsumptionCounter2,
			 T.c.value('WaterConsumption[3]/@Value', 'DECIMAL(18,4)') WaterConsumptionCounter3,
			 T.c.value('WaterConsumption[4]/@Value', 'DECIMAL(18,4)') WaterConsumptionCounter4,
			 T.c.value('WaterConsumption[5]/@Value', 'DECIMAL(18,4)') WaterConsumptionCounter5,
			 T.c.value('WaterConsumption[6]/@Value', 'DECIMAL(18,4)') WaterConsumptionCounter6,
			 T.c.value('@TransferSignal', 'INT') TransferSignal,
			 T.c.value('@RunState', 'INT') RunState
	   FROM TCD.Washer w 
		  INNER JOIN TCD.MachineSetup ms ON ms.WasherId = w.WasherId 
									 AND ms.IsTunnel = 1 
									 AND ms.IsDeleted = 0 
									 AND ms.ControllerId = @ControllerID
		  INNER JOIN TCD.WasherGroup wg ON Wg.WasherGroupId = ms.GroupId
		  INNER JOIN TCD.WasherGroupType wgt ON WgT.WasherGroupTypeId = Wg.WasherGroupTypeId
		  INNER JOIN TCD.ConduitController cc ON cc.ControllerId = ms.ControllerId
		  INNER JOIN TCD.Plant p ON p.EcolabAccountNumber = w.EcoLabAccountNumber
		  RIGHT OUTER JOIN @xmlTags.nodes('MyControlTunnel/TunnelData') T(C) ON T.c.value('@MachineNumber', 'INT') = ms.MachineInternalId;
	   --Insert Online Batchdata
	   MERGE INTO TCD.OnlineBatchData obd
	   USING
	   (
		  SELECT * FROM #OnlineBatchData
	   ) temp 
	   ON obd.CompartmentNumber = temp.CompartmentNumber
	   AND obd.ControllerID = temp.ControllerID
	   AND obd.MachineInternalID = temp.MachineInternalID
	   WHEN NOT MATCHED 
	   THEN INSERT
	   (
		  ControllerId,
		  CompartmentNumber,
		  BatchNumber,
		  EcolabWasherID,
		  GroupID,
		  MachineInternalID,
		  MachineID,
		  PlantWasherNumber,
		  StartDate,
		  ProgramNumber,
		  ProgramMasterID,
		  CustomerNumber,
		  ActualWeight,
		  StandardWeight,
		  TransferSignal,
		  RunState
	   )
	   VALUES
	   (
		  temp.ControllerID,
		  temp.CompartmentNumber,
		  temp.BatchNumber,
		  temp.EcolabWasherID,
		  temp.GroupID,
		  temp.MachineInternalID,
		  temp.MachineID,
		  temp.PlantWasherNumber,
		  temp.StartDate,
		  temp.ProgramNumber,
		  temp.ProgramMasterID,
		  temp.CustomerNumber,
		  temp.ActualWeight,
		  temp.StandardWeight,
		  temp.TransferSignal,
		  temp.RunState
	   )
	   WHEN MATCHED THEN 
	   UPDATE SET	ControllerId			   =	 temp.ControllerID,
				CompartmentNumber		   =	 temp.CompartmentNumber,
				BatchNumber			   =	 temp.BatchNumber,
				EcolabWasherID		 	   =	 temp.EcolabWasherID,
				GroupID				   =	 temp.GroupID,
				MachineInternalID		   =	 temp.MachineInternalID,
				MachineID			 	   =	 temp.MachineID,
				PlantWasherNumber		   =	 temp.PlantWasherNumber,
				StartDate			 	   =	 temp.StartDate,
				ProgramNumber			   =	 temp.ProgramNumber,
				ProgramMasterID		   =	 temp.ProgramMasterID,
				CustomerNumber		 	   =	 temp.CustomerNumber,
				ActualWeight			   =	 temp.ActualWeight,
				StandardWeight		 	   =	 temp.StandardWeight,
				TransferSignal			   =	 temp.TransferSignal,
				RunState				   = temp.RunState;
	  
		   -- Transfer Signal
		  DECLARE @ShiftStartDateTemp TABLE
            (
			 ShiftId        INT,
			 ShiftName      NVARCHAR(50),
			 ShiftStartdate DATETIME
             );
		   DECLARE @CompNum			INT,
				 @StartDate		DATETIME,
				 @TransferSignalID	INT,
				 @WasherId		INT,
				 @TransferSignal	INT,
				 @EcolabWasherID	INT;
		   SELECT @TransferSignalID =  id FROM tcd.ConduitParameters cp WHERE cp.Name ='Transfer Signal';
		   SELECT TOP 1 @CompNum =obd.CompartmentNumber,
					 @StartDate = obd.StartDate,
					 @WasherId = obd.MachineID,
					 @EcolabWasherID = obd.EcolabWasherID,
					 @TransferSignal = obd.TransferSignal
		   FROM #OnlineBatchData obd ORDER BY obd.CompartmentNumber;
		   INSERT INTO @ShiftStartDateTemp
		   (
				ShiftId,
				ShiftName,
				ShiftStartdate
	        )
		  EXEC TCD.GetShiftStartDate @StartDate
		  IF NOT EXISTS
            (
                 SELECT
				    TOP 1 wr.WasherId
                 FROM tcd.WasherReading wr
                 WHERE wr.WasherId = @WasherId
                       AND wr.ParameterId = @TransferSignalID
                       AND (SELECT TOP 1 wr2.DateTimeStamp FROM tcd.WasherReading wr2 WHERE wr2.WasherId = @WasherId
														AND wr2.ParameterId = @TransferSignalID ORDER BY wr2.DateTimeStamp DESC) = @StartDate
             )
             BEGIN
                    INSERT INTO TCD.WasherReading
                    (
                             WasherId,
                             ParameterId,
                             ParameterValue,
                             DateTimeStamp,
                             PartitionOn,
                             EcolabWasherId
                    )
				  SELECT @WasherId,
					    @TransferSignalID,
					    @TransferSignal,
					    @StartDate,
					    (
						  SELECT
							 ShiftStartdate
						  FROM @ShiftStartDateTemp
					    ),
					   @EcolabWasherID
            END;
		  DROP TABLE #OnlineBatchData
END;