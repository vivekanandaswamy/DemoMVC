﻿/*	
Purpose					:	To add a new Tunnel from the Washer-Tunnel (General) setup screen

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version

*/
CREATE PROCEDURE	[TCD].[AddTunnel]	
					@MyServiceWasherId						UniqueIdentifier
				,	@EcoLabAccountNumber					NVARCHAR(25)
				,	@WasherGroupId							INT
				,	@TunnelName								NVARCHAR(50)
				,	@WasherModelName						NVARCHAR(50)
				,	@RegionId								SMALLINT
--				,	@Size									INT									--we don't need to save this; ModelId PK determines it
				,	@ControllerId							INT
				,	@LFSWasherNumber						TINYINT			=			1		--For tunnels, it will be 1 until a diff. number is passed (as per the scenario)
				,	@PlantWasherNumber						SMALLINT
				,	@WasherMode								TINYINT
				,	@MaxLoad								SMALLINT
				,	@AWEActive								BIT
				,	@NumberOfTanks							TINYINT
				,	@NumberOfComp							TINYINT								--though this is INT in the table, we should not require it to be so
				,	@TransferType							TINYINT         =			NULL
				,	@PressExtractor							TINYINT       =			NULL
				,	@ProgramNumber							TINYINT
				,	@EndOfFormula							TINYINT
				,	@Description							NVARCHAR(1024)	=			NULL
				,	@UserId									INT

				,	@OutputTunnelId							INT			OUTPUT
				--Adding as part of re-factoring for integration with Synch/Configurator... generated TunnelId (re-named) is already being OUTPUT above
				,	@OutputLastModifiedTimestampAtLocal		DATETIME		=			NULL	OUTPUT
				,   @RatioDosingActive						Bit = 'False'
				,   @ControllerModelId						INT		=		NULL
				,   @NumberOfCompartmentsConveyorBelt			TINYINT	=		NULL
				,   @MaxMachineLoad							TINYINT	=		NULL
				,   @MinMachineLoad							TINYINT	=		NULL
				,   @ProgramSelectionByTime					BIT	  	=		NULL
				,   @WeightSelectionByTime					BIT	  	=		NULL
				,   @WeightSelectionByAnalogInput				BIT	  	=		NULL
				,   @TunInTomMode							BIT	  	=		NULL
				,   @SignalStopTunActive						BIT	  	=		NULL
				,   @SignalEjectionTunActive	  				BIT	  	=		NULL
				,   @DelayTimeForTunWashingPrograms			BIT	  	=		NULL
				,   @KannegiesserPressSpecialMode				BIT	  	=		NULL
				,   @ValveOutputsUsedAsTomSignal				BIT	  	=		NULL
				,   @ExtendedClockOrDataProtocol				BIT	  	=		NULL
				,   @WeightCorrectionFcc						BIT	  	=		NULL
				,	@DateAndTimeWhenBatchEjects					BIT	  		=		NULL
				,	@AutoRinseDesamixAfter						SMALLINT	=		NULL
				,	@AutoRinseDesamix1For						SMALLINT	=		NULL
				,	@AutoRinseDesamix2For						SMALLINT	=		NULL
				,	@TemperatureAlarmProbe1						BIT			=		NULL
				,	@TemperatureAlarmProbe2						BIT			=		NULL
				,	@TemperatureAlarmProbe3						BIT			=		NULL
				, @UseMe1OfGroup			 tinyint =	NULL
				, @UseMe2OfGroup			 tinyint =	NULL
				,	@ETechWasherNumber						    INT			=		NULL
				,	@KannegiesserDosageInPreparationTankMode	bit			=		NULL
				,	@BatchOk									bit			=		NULL
				,	@TransferPerHour							INT			=		NULL

AS
BEGIN

SET	NOCOUNT	ON


DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''

	,	@WasherId						INT				=			NULL
	,	@WasherModelId					SMALLINT		=			NULL
	--Adding for integration with Synch./Central
	,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()
	,	@ControllerValidate				int				=										   0

--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
SET		@OutputLastModifiedTimestampAtLocal				=			@CurrentUTCTime
SET		@OutputTunnelId									=			ISNULL(@OutputTunnelId, NULL)			--SQLEnlight

--Check that the WasherGroup being associated-to is a valid Tunnel-type WG...
IF	NOT	EXISTS	(	SELECT	1
					FROM	[TCD].WasherGroup			WG
					JOIN	[TCD].WasherGroupType		WGT
						ON	WG.WasherGroupTypeId		=			WGT.WasherGroupTypeId
					JOIN	[TCD].MachineGroup					GT									--this is actually the Groups table and NOT really a Group TYPE
						ON	WG.WasherGroupId			=			GT.Id			--GroupTypeId is actually the Id of the Group
					WHERE	WG.WasherGroupId			=			@WasherGroupId
						AND	GT.EcolabAccountNumber		=			@EcoLabAccountNumber
						AND	GT.GroupTypeId	  			=			2			--select	GroupMaintype	from	GroupType
						AND	WGT.WasherGroupTypeName		=			'Tunnel'				--select	WasherGroupTypeName	from	WasherGroupType
				)
			BEGIN
				SET		@ErrorId						=			51001
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherGroup provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--Check for only 1 tunnel for a WasherGroup
IF	EXISTS		(	SELECT	1
					FROM	[TCD].MachineSetup			MS
					JOIN	[TCD].Washer				W
						ON	MS.WasherId					=			W.WasherId
					WHERE	MS.GroupId					=			@WasherGroupId
						AND	MS.EcoalabAccountNumber		=			@EcoLabAccountNumber
						AND	MS.IsDeleted				=			'FALSE'
						AND	MS.IsTunnel					=			'TRUE'
						AND	W.Is_Deleted				=			'FALSE'
				)
			BEGIN
				SET		@ErrorId						=			51008
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': A Tunnel has already been added to this Washer Group.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--Check for unique PlantWasherNo.
IF	EXISTS		(	SELECT	1
					FROM	[TCD].Washer				W
					JOIN	[TCD].MachineSetup			MS
						ON	W.WasherId					=			MS.WasherId
						AND	W.EcoLabAccountNumber		=			MS.EcoalabAccountNumber
					WHERE	W.EcoLabAccountNumber		=			@EcoLabAccountNumber
						AND	(
							W.PlantWasherNumber			=			@PlantWasherNumber							
							)
						AND	W.Is_Deleted				=			'FALSE'
						AND	MS.IsDeleted				=			'FALSE'
				)
			BEGIN
				SET		@ErrorId						=			51002
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Specified Plant Washer #/ already exists.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--Check that it's a valid Controller type/model (one that can control a Tunnel)

EXEC @ControllerValidate = [TCD].[ValidateController] 2,@ControllerId,@EcoLabAccountNumber

IF(@ControllerValidate = 1)
				
			BEGIN
				SET		@ErrorId						=			51003
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid Controller was provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--EOF should not be an asocciated formula for the WG...
IF	EXISTS		(	SELECT	1
					FROM	[TCD].TunnelProgramSetup	TPS
					WHERE	TPS.EcolabAccountNumber		=			@EcoLabAccountNumber
						AND	TPS.WasherGroupId			=			@WasherGroupId
						AND	TPS.ProgramNumber			=			@ProgramNumber
						AND	TPS.Is_Deleted				=			'FALSE'
				)
			BEGIN
				SET		@ErrorId						=			51004
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An associated formula cannot be specified as End-Of-Formula.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--WasherMode check
IF	NOT	EXISTS	(	SELECT	1
					FROM	[TCD].ControllerModelControllerTypeMapping
														CMCTM
					JOIN	[TCD].ConduitController		CC
						ON	CC.ControllerTypeId			=			CMCTM.ControllerTypeId
						AND	CC.ControllerModelId		=			CMCTM.ControllerModelId
					JOIN	[TCD].[WasherModeMapping]	CTM2WM
						ON	CMCTM.Id					=			CTM2WM.ControllerModelControllerTypeMappingId
					WHERE	CC.EcoalabAccountNumber		=			@EcoLabAccountNumber
						AND	CC.ControllerId				=			@ControllerId
						AND	CC.IsDeleted				=			'FALSE'
						AND	CMCTM.MaxtunnelCount > 0
						AND	CTM2WM.WasherModeId			=			@WasherMode
				)
			BEGIN
				SET		@ErrorId						=			51005
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': An invalid WasherMode was provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END


--select the WasherModelId based on name
SELECT	TOP	1
		@WasherModelId						=			WMS.WasherModelId
FROM	[TCD].WasherModelSize				WMS
WHERE	WMS.RegionId						=			@RegionId
	AND	WMS.WasherModelName					=			@WasherModelName
	AND	WMS.ModelTypeId						=			2							--TypeId 2 for Tunnel
	AND	WMS.Is_Deleted						=			'FALSE'

--LFSWasherNumber duplicate check...
IF	EXISTS	(	SELECT	1
				FROM	[TCD].MachineSetup					MS
				WHERE	MS.ControllerId					=			@ControllerId
					AND	MS.MachineInternalId			=			@LFSWasherNumber
					AND MS.EcoalabAccountNumber			=			@EcoLabAccountNumber
					AND	MS.IsDeleted					=			'FALSE'
					AND MS.IsTunnel						=			'TRUE'
			)
			BEGIN
				SET		@ErrorId						=			51010
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate LFSWasher# provided.'
				--GOTO	ErrorHandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET		@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END
--ETechWasherNumber duplicate check...
IF(@ControllerModelId NOT IN (8,9,10,11,14))
BEGIN
IF EXISTS ( SELECT 1
    FROM [TCD].Washer  AS W
    JOIN [TCD].MachineSetup AS MS ON MS.WasherId = W.WasherId 
    where W.ETechWasherNumber = @ETechWasherNumber
	 AND W.Is_Deleted = 0
	 AND W.ETechWasherNumber <> 0
)  
BEGIN  

SET  @ErrorId      =   51012  
SET  @ErrorMessage     =   N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Duplicate ETechWasherNumber# provided.'  
--GOTO ErrorHandler  
RAISERROR (@ErrorMessage, 16, 1)  
SET  @ReturnValue = -1  
RETURN (@ReturnValue)  
END
END

--Now attempt to insert a new row for the tunnel record being created...
BEGIN	TRAN
IF(@ControllerModelId IS NOT NULL AND @ControllerModelId = 7 )
BEGIN
INSERT	[TCD].Washer	(
		 MyServiceCustMchGuid
		,EcoLabAccountNumber
		,PlantWasherNumber
		,ModelId
		,WasherMode
		,MaxLoad
		,[Description]
		,Is_Deleted
		,LastModifiedByUserId
		,NumberOfTanks
		,TransferType
		,PressExtractor
	--Adding for integration with Synch./Central
		,LastModifiedTime
		,EmptyPocketNumber
		,NumberOfCompartmentsConveyorBelt
		,MinMachineLoad
		,MaxMachineLoad
		,ProgramSelectionByTime
		,WeightSelectionByTime
		,WeightSelectionByAnalogInput
		,TunInTomMode
		,SignalStopTunActive
		,SignalEjectionTunActive
		,DelayTimeForTunWashingPrograms
		,KannegiesserPressSpecialMode
		,ValveOutputsUsedAsTomSignal
		,ExtendedClockOrDataProtocol
		,WeightCorrectionFcc
		,AWEActive
		,EndOfFormula
		,ETechWasherNumber
		,KannegiesserDosageInPreparationTankMode
		,BatchOk
		,TargetTransferPerHour
	)
SELECT @MyServiceWasherId					AS			MyServiceWasherId	
	,	@EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	@PlantWasherNumber					AS			PlantWasherNumber
	,	@WasherModelId						AS			ModelId
	--,	@Size							AS			Size
	,	@WasherMode						AS			WasherMode
	,	@MaxLoad							AS			MaxLoad
	,	@Description						AS			[Description]
	,	'FALSE'							AS			Is_Deleted
	,	@UserId							AS			LastModifiedByUserId
	,	@NumberOfTanks						AS			NumberOfTanks
	,	@TransferType						AS			TransferType
	,	@PressExtractor					AS			PressExtractor
	,	@CurrentUTCTime					AS			LastModifiedTime
	,	@ProgramNumber						AS			ProgramNumber
	,   @NumberOfCompartmentsConveyorBelt		AS			NumberOfCompartmentsConveyorBelt
	,   @MinMachineLoad						AS			MinMachineLoad
	,   @MaxMachineLoad						AS			MaxMachineLoad
	,   @ProgramSelectionByTime				AS			ProgramSelectionByTime
	,   @WeightSelectionByTime				AS			WeightSelectionByTime
	,   @WeightSelectionByAnalogInput			AS			WeightSelectionByAnalogInput
	,   @TunInTomMode						AS			TunInTomMode
	,   @SignalStopTunActive					AS			SignalStopTunActive
	,   @SignalEjectionTunActive	  			AS			SignalEjectionTunActive
	,   @DelayTimeForTunWashingPrograms		AS			DelayTimeForTunWashingPrograms
	,   @KannegiesserPressSpecialMode			AS			KannegiesserPressSpecialMode
	,   @ValveOutputsUsedAsTomSignal			AS			ValveOutputsUsedAsTomSignal
	,   @ExtendedClockOrDataProtocol			AS			ExtendedClockOrDataProtocol
	,   @WeightCorrectionFcc					AS			WeightCorrectionFcc
	,	'FALSE'							AS			AWEActive
	,	0								AS			EndOfFormula
	,   @ETechWasherNumber			AS			ETechWasherNumber
	,	@KannegiesserDosageInPreparationTankMode	AS KannegiesserDosageInPreparationTankMode
	,	@BatchOk						AS		BatchOk
	,	@TransferPerHour				AS			TargetTransferPerHour
END
ELSE IF(@ControllerModelId IS NOT NULL AND ( @ControllerModelId = 8	OR @ControllerModelId = 9	OR @ControllerModelId = 10 OR @ControllerModelId = 11 OR @ControllerModelId = 14))
BEGIN
INSERT	[TCD].Washer	(
		 MyServiceCustMchGuid
		,EcoLabAccountNumber
		,PlantWasherNumber
		,ModelId
		,WasherMode
		,MaxLoad
		,[Description]
		,Is_Deleted
		,LastModifiedByUserId
		,NumberOfTanks
		,TransferType
		,PressExtractor
	--Adding for integration with Synch./Central
		,LastModifiedTime
		,EmptyPocketNumber
		,NumberOfCompartmentsConveyorBelt
		,MinMachineLoad
		,MaxMachineLoad
		,ProgramSelectionByTime
		,WeightSelectionByTime
		,WeightSelectionByAnalogInput
		,TunInTomMode
		,SignalStopTunActive
		,SignalEjectionTunActive
		,DelayTimeForTunWashingPrograms
		,KannegiesserPressSpecialMode
		,ValveOutputsUsedAsTomSignal
		,ExtendedClockOrDataProtocol
		,WeightCorrectionFcc
		,AWEActive
		,EndOfFormula
		,AutoRinseDesamixAfter
		,AutoRinseDesamix1For
		,AutoRinseDesamix2For
		,TemperatureAlarmProbe1
		,TemperatureAlarmProbe2
		,TemperatureAlarmProbe3
		,DateAndTimeWhenBatchEjects
		,ETechWasherNumber
		,UseMe1OfGroup
		,UseMe2OfGroup
		,TargetTransferPerHour
	)
SELECT @MyServiceWasherId					AS			MyServiceWasherId	
	,	@EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	@PlantWasherNumber					AS			PlantWasherNumber
	,	@WasherModelId						AS			ModelId
	--,	@Size							AS			Size
	,	@WasherMode						AS			WasherMode
	,	@MaxLoad							AS			MaxLoad
	,	@Description						AS			[Description]
	,	'FALSE'							AS			Is_Deleted
	,	@UserId							AS			LastModifiedByUserId
	,	@NumberOfTanks						AS			NumberOfTanks
	,	@TransferType						AS			TransferType
	,	@PressExtractor					AS			PressExtractor
	,	@CurrentUTCTime					AS			LastModifiedTime
	,	@ProgramNumber						AS			ProgramNumber
	,   @NumberOfCompartmentsConveyorBelt		AS			NumberOfCompartmentsConveyorBelt
	,   @MinMachineLoad						AS			MinMachineLoad
	,   @MaxMachineLoad						AS			MaxMachineLoad
	,   @ProgramSelectionByTime				AS			ProgramSelectionByTime
	,   @WeightSelectionByTime				AS			WeightSelectionByTime
	,   @WeightSelectionByAnalogInput			AS			WeightSelectionByAnalogInput
	,   @TunInTomMode						AS			TunInTomMode
	,   @SignalStopTunActive					AS			SignalStopTunActive
	,   @SignalEjectionTunActive	  			AS			SignalEjectionTunActive
	,   @DelayTimeForTunWashingPrograms		AS			DelayTimeForTunWashingPrograms
	,   @KannegiesserPressSpecialMode			AS			KannegiesserPressSpecialMode
	,   @ValveOutputsUsedAsTomSignal			AS			ValveOutputsUsedAsTomSignal
	,   @ExtendedClockOrDataProtocol			AS			ExtendedClockOrDataProtocol
	,   @WeightCorrectionFcc					AS			WeightCorrectionFcc
	,	'FALSE'							AS			AWEActive
	,	0								AS			EndOfFormula
	,	@AutoRinseDesamixAfter
	,	@AutoRinseDesamix1For
	,	@AutoRinseDesamix2For
	,	@TemperatureAlarmProbe1
	,	@TemperatureAlarmProbe2
	,	@TemperatureAlarmProbe3
	,	@DateAndTimeWhenBatchEjects
	,   @ETechWasherNumber						AS			ETechWasherNumber
	, @UseMe1OfGroup AS UseMe1OfGroup
	, @UseMe2OfGroup AS UseMe2OfGroup
	,	@TransferPerHour					AS			TargetTransferPerHour
END
ELSE
BEGIN
INSERT	[TCD].Washer	(
		MyServiceCustMchGuid
		,EcoLabAccountNumber
		,PlantWasherNumber
		,ModelId
		,WasherMode
		,MaxLoad
		,AWEActive
		,EndOfFormula
		,[Description]
		,Is_Deleted
		,LastModifiedByUserId
		,NumberOfTanks
		,TransferType
		,PressExtractor
	--Adding for integration with Synch./Central
		,LastModifiedTime
		,RatioDosingActive
		,EmptyPocketNumber
		,ETechWasherNumber
		,TargetTransferPerHour
	)
SELECT @MyServiceWasherId					AS			MyServiceWasherId	
	,	@EcoLabAccountNumber				AS			EcoLabAccountNumber
	,	@PlantWasherNumber					AS			PlantWasherNumber
	,	@WasherModelId						AS			ModelId
	--,	@Size							AS			Size
	,	@WasherMode						AS			WasherMode
	,	@MaxLoad							AS			MaxLoad
	,	@AWEActive						AS			AWEActive
	,	@EndOfFormula						AS			EndOfFormula
	,	@Description						AS			[Description]
	,	'FALSE'							AS			Is_Deleted
	,	@UserId							AS			LastModifiedByUserId
	,	@NumberOfTanks						AS			NumberOfTanks
	,	@TransferType						AS			TransferType
	,	@PressExtractor					AS			PressExtractor
	,	@CurrentUTCTime					AS			LastModifiedTime
	,	@RatioDosingActive					AS			RatioDosingActive
	,	@ProgramNumber						AS			ProgramNumber 	
	,	@ETechWasherNumber					AS			ETechWasherNumber
	,	@TransferPerHour					AS			TargetTransferPerHour
END

SET	@ErrorId	=	@@ERROR
	
IF	(@ErrorId	<>	0)
	BEGIN
			IF	@@TRANCOUNT	>	0
			BEGIN
				ROLLBACK	TRAN
			END

			SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred creating new record for tunnel.'
			--GOTO	ErrorHandler
			RAISERROR	(@ErrorMessage, 16, 1)
			SET	@ReturnValue	=	-1
			RETURN	(@ReturnValue)
	END

--if no error, collect the id of the newly generated row...
SELECT	@WasherId	=	SCOPE_IDENTITY()


--insert in MachineSetup
INSERT	[TCD].MachineSetup	(
		WasherId	,GroupId	,MachineInternalId	,EcoalabAccountNumber	,MachineName	,IsTunnel	,ControllerId	,NumberOfComp	,IsDeleted	,LastModifiedByUserId	)
SELECT	@WasherId					AS			WasherId
	,	@WasherGroupId				AS			GroupId
	,	@LFSWasherNumber			AS			MachineInternalId
	,	@EcoLabAccountNumber		AS			EcoalabAccountNumber
	,	@TunnelName					AS			MachineName
	,	'TRUE'						AS			IsTunnel
	,	@ControllerId				AS			ControllerId
	,	@NumberOfComp				AS			NumberOfComp
	,	'FALSE'						AS			IsDeleted
	,	@UserId						AS			LastModifiedByUserId

SET	@ErrorId	=	@@ERROR

IF	(@ErrorId	<>	0)
	BEGIN
			IF	@@TRANCOUNT	>	0
			BEGIN
				ROLLBACK	TRAN
			END

			SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Error occurred assoicating new record for tunnel.'
			--GOTO	ErrorHandler
			RAISERROR	(@ErrorMessage, 16, 1)
			SET	@ReturnValue	=	-1
			RETURN	(@ReturnValue)
	END
ELSE
	BEGIN
			IF	@@TRANCOUNT	>	0
			BEGIN
			IF (@ControllerModelId = 7)
				BEGIN
					UPDATE TCD.WasherGroup 
					SET	  ControllerId = @ControllerId ,
						  WasherDosingNumber = @LFSWasherNumber
					WHERE  WasherGroupId = @WasherGroupId
				END
				COMMIT
			END

			--SET the output param to be communicated back...
			SET	@OutputTunnelId	=	@WasherId
	END



--IF	(	@ErrorId	=	0	)
--	BEGIN
--		--GOTO	ExitModule
--		RETURN	(@ReturnValue)
--	END




--ErrorHandler:
--RAISERROR	(@ErrorMessage, 16, 1)
--SET	@ReturnValue	=	-1




--ExitModule:

SET	NOCOUNT	OFF
RETURN	(@ReturnValue)


END