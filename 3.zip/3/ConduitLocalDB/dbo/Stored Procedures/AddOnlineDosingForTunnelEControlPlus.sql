CREATE PROCEDURE TCD.AddOnlineDosingForTunnelEControlPlus(
@ControllerID int,
@TunnelXML XML,
@WasherId int,
@MachineInternalId int,
@BatchNumber int,
@ProgramNumber int
)
AS
BEGIN
   DECLARE @Number int
   DECLARE @dosingPoint int
   DECLARE @isMainEquipment int
   DECLARE @Quantity Decimal(10,6)
   DECLARE @ID int=1
   DECLARE @ValveNumber int
   DECLARE @ProductID int
	 CREATE TABLE #DosingDetails(
	      ID int Identity(1,1),
		  Number INT, 
          Quantity Decimal(10,6),
          dosingPoint INT,
          IsMainEquipment INT,
          IsDirectDosing INT
         )
    
   INSERT INTO #DosingDetails(Number,
							  Quantity, 
							  dosingPoint, 
							  IsMainEquipment, 
							  IsDirectDosing)
   SELECT 
   T.c.value('@Number', 'INT') AS Number, --PumpNumber
   T.c.value('@Quantity', 'Decimal(10,6)') AS Quantity, --Dosing Quanity
   T.c.value('@Point', 'INT') AS Point, --Dosing Point
   T.c.value('@IsMainEquipment', 'INT') AS IsMainEquioment,
   T.c.value('@IsDirectDosing', 'INT') AS IsDirectDosing
   FROM @TunnelXML.nodes('TunnelData/Dose') T(c)

   
   WHILE (@ID >0)
   BEGIN
        IF Not Exists(SELECT 1 FROM #DosingDetails WHERE ID = @ID) break;
		SELECT @Number= [Number],
		       @Quantity=Quantity,
			   @IsMainEquipment=IsMainEquipment,
			   @dosingPoint=dosingPoint
		FROM #DosingDetails 
		WHERE ID = @ID
		IF @Quantity = 0 
		BEGIN
			SELECT @ID = @ID + 1
			CONTINUE;
		END
		SELECT @ProductID = null
		SELECT @ProductID=ProductID,
		       @ValveNumber=ValveNumber
		FROM TCd.ControllerEquipmentSetup CES
			 INNER JOIN TCD.TunnelCompartmentEquipmentValveMapping TCE on CES.ControllerEquipmentSetupId = TCE.ControllerEquipmentSetupID
	                                          AND CES.isActive = 1                                
		WHERE ControllerID=@ControllerID
			  AND TCE.DosingPointNumber = @dosingPoint
			  AND CES.ControllerEquipmentID = @Number

	 INSERT INTO TCd.WasherProductReading
	 (ControllerId,
	  WasherId,
	  MachineInternalId,
	  ProductId,
	  RealQty,
	  DosingPoint,
	  DosingNumber,
	  ProgramNumber,
	  BatchNumber,
	  ValveNumber,
	  DateTimeStamp
	  )
	  SELECT @ControllerID,
	         @WasherID,
			 @MachineInternalId,
			 @ProductID,
			 @Quantity,
			 @dosingPoint,
			 @Number,
			 @ProgramNumber,
			 @BatchNumber,
			 @ValveNumber,
			 GetUTCDate()
	 WHERE @ProductID is not null
     SELECT @ID = @ID + 1
   END
END 
