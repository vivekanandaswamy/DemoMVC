CREATE PROCEDURE [TCD].[GetPumpsProductsData](@ControllerId int,@EcolabAccountNumber nvarchar(25))
AS
SET NOCOUNT ON
BEGIN

SELECT cpm.Id,
cpm.ControllerId,
cpm.ChemicalNumber,
cpm.ProductId,
pm.Name,
cpm.LowLevelAlarm,
cpm.WeightControlledDosage
FROM tcd.ControllerProductMapping cpm
INNER JOIN tcd.ProductMaster pm ON pm.ProductID = cpm.ProductId
WHERE cpm.ControllerId = @ControllerId
AND cpm.EcolabAccountNumber = @EcolabAccountNumber
END