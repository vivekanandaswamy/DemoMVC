﻿
/*    
 ==========================================================================================  
 Purpose:  Getting the DimensionalUnitSystems.    

 Author:  Premchand Yelavarthi    

 --------------------------------------------------------------    
 July-18-2014 ENT: Initial version.    
 ==========================================================================================  
*/ 
CREATE PROCEDURE [TCD].[GetDimensionalUnitSystems] 
AS 
SET nocount ON; 
  BEGIN 
      SELECT [UnitSystemId] , [UnitSystem] FROM [TCD].DimensionalUnitSystems where unitsystemID <> 0
  END 