CREATE PROCEDURE [TCD].[ReportChemicalInventory] (
    @EcolabAccountNumber NVARCHAR(25) = NULL
    ,@UserId INT = NULL
    ,@ReportID INT = NULL
    )
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @ReportGenerated INT = 6,
	    @UserCurrency NCHAR(3),
	    @BatchCurrency NCHAR(3),
	    @UOMId INT;
    /* Inserting the record into Report History */
    INSERT INTO TCD.ReportHistory (
    EcolabAccountNumber
    ,UserId
    ,UserName
    ,DateAndTime
    ,ActionTypeId
    ,ActionDescription
    )
    SELECT @EcolabAccountNumber
    ,UM.UserId
    ,UM.LoginName
    ,GETUTCDATE()
    ,@ReportGenerated
    ,CASE 
    WHEN @ReportGenerated = 6
	THEN 'Generated Report : ChemicalInventoryReport'
    END
    FROM TCD.UserMaster UM (NOLOCK)
    WHERE UM.EcolabAccountNumber = @EcolabAccountNumber
    AND UM.UserId = @UserId
  
    SELECT @UOMId=UOMId FROM TCD.UserMaster UM WHERE UM.userId=@UserId

    SELECT @BatchCurrency = (SELECT TOP 1 bd.CurrencyCode FROM TCD.BatchData bd);

    SELECT @UserCurrency = ISNULL(um.CurrencyCode, @BatchCurrency)
    FROM TCD.UserMaster um 
    WHERE um.UserId = @UserId;

    WITH CTE_CostConversion (ProductID, AvgDailyCost, CurrentYearWorkingDays,CurrentYearNoOfLoads)
    AS (
	SELECT   CIR.[ProductID]
	, SUM(CASE WHEN ci.InventoryDate >= DATEADD(yy, DATEDIFF(yy,0,getdate()), 0) 
		    THEN (CASE WHEN ci.UnitSize = 'lbs' THEN (ci.UsedQuantity * 16.00) 
			    WHEN ci.UnitSize = 'oz'  THEN ci.UsedQuantity 
			    WHEN ci.UnitSize = 'gal' THEN ci.UsedQuantity * 128.00
			    WHEN ci.UnitSize = 'kg' THEN ci.UsedQuantity * 35.274
			    WHEN ci.UnitSize = 'L' THEN ci.UsedQuantity * 33.814
			    ELSE ci.UsedQuantity
			END  * [TCD].[FnChemicalCostInOunce](ci.ProductId)
			) 
			* (CASE 
				WHEN @BatchCurrency = @UserCurrency 
				    THEN 1
				WHEN @BatchCurrency <> @UserCurrency 
				    THEN TCD.FnCurrencyExchangeRate(@UserCurrency,ci.InventoryDate)
			    END)
	    ELSE NULL
	    END )  AS AvgDailyCost
	    ,MAX(CIR.[AvgDailyCostYTD]) As CurrentYearWorkingDays
	    ,MAX(CIR.[AvgDailyCostLoadYTD]) AS CurrentYearNoOfLoads
	FROM [TCD].[ChemicalInventoryRollUp] AS CIR
	INNER JOIN TCD.ChemicalInventory AS CI (NOLOCK) ON CIR.ProductID = CI.ProductId
	INNER JOIN TCD.ProductdataMapping PDM (NOLOCK) ON CI.ProductId = PDM.ProductID
	GROUP BY CIR.[ProductID]
    )

    SELECT   CIR.[ProductID]
	,CIR.[ChemicalName]
	,CIR.[InventoryDateRange]
	,[TCD].[UnitConversionbyUserUOM](CIR.[LastInventory],[UnitSize],@UserId) AS [LastInventory]
	--,IIF(@UOMId=2, [TCD].[UnitConversionbyUserUOM](CIR.[LastInventory],[UnitSize],@UserId),CIR.[LastInventory]) AS [LastInventory]
	--,CIR.[LastInventory]
	,[TCD].[UnitConversionbyUserUOM](CIR.[InventoryBasedConsumption],[UnitSize],@UserId) AS [InventoryBasedConsumption]
	--,IIF(@UOMId=2, [TCD].[UnitConversionbyUserUOM](CIR.[InventoryBasedConsumption],[UnitSize],@UserId),CIR.[InventoryBasedConsumption]) AS [InventoryBasedConsumption]
	--,CIR.[InventoryBasedConsumption]
	,[TCD].[UnitConversionbyUserUOM](CIR.[DispencerBasedConsumption],[UnitSize],@UserId) AS [DispencerBasedConsumption]
	--,IIF(@UOMId=2, [TCD].[UnitConversionbyUserUOM](CIR.[DispencerBasedConsumption],[UnitSize],@UserId),CIR.[DispencerBasedConsumption]) AS [DispencerBasedConsumption]
	--,CIR.[DispencerBasedConsumption]
	,[TCD].[UnitConversionbyUserUOM](CIR.[TodayEstimateInventory],[UnitSize],@UserId) AS [TodayEstimateInventory]
	--,IIF(@UOMId=2, [TCD].[UnitConversionbyUserUOM](CIR.[TodayEstimateInventory],[UnitSize],@UserId),CIR.[TodayEstimateInventory]) AS [TodayEstimateInventory]
	--,CIR.[TodayEstimateInventory]
	,[TCD].[UnitConversionbyUserUOM](CIR.[AvgDailyNeedsYTD],[UnitSize],@UserId) AS [AvgDailyNeedsYTD]
	--,IIF(@UOMId=2, [TCD].[UnitConversionbyUserUOM](CIR.[AvgDailyNeedsYTD],[UnitSize],@UserId),CIR.[AvgDailyNeedsYTD]) AS [AvgDailyNeedsYTD]
	--,CIR.[AvgDailyNeedsYTD]
	, CAST((CC.AvgDailyCost / NULLIF(CC.CurrentYearWorkingDays, 0)) as decimal) AS AvgDailyCostYTD
	, CAST(((CC.AvgDailyCost / CC.CurrentYearNoOfLoads) * 100) as decimal) AS [AvgDailyCostLoadYTD]
	,[TCD].[UnitConversionbyUserUOM](CIR.[AvgDailyNeedsLY],[UnitSize],@UserId) AS [AvgDailyNeedsLY]
	--,IIF(@UOMId=2, [TCD].[UnitConversionbyUserUOM](CIR.[AvgDailyNeedsLY],[UnitSize],@UserId),CIR.[AvgDailyNeedsLY]) AS [AvgDailyNeedsLY]
	--,CIR.[AvgDailyNeedsLY]
	,CIR.[DayBeforeOutOfStock]
	,CASE WHEN @UOMId=2 AND [UnitSize]='lbs' THEN 'kg'
		WHEN @UOMId=2 AND [UnitSize]='gal' THEN 'L'
		ELSE [UnitSize]
	END AS [UnitSize]
	--,CIR.[UnitSize]
	,[TCD].[UnitConversionbyUserUOM](CIR.[AvgDailyNeedsForInventoryPeriod],[UnitSize],@UserId) AS [AvgDailyNeedsForInventoryPeriod]
	--,IIF(@UOMId=2, [TCD].[UnitConversionbyUserUOM](CIR.[AvgDailyNeedsForInventoryPeriod],[UnitSize],@UserId),CIR.[AvgDailyNeedsForInventoryPeriod]) AS [AvgDailyNeedsForInventoryPeriod]
	--,CIR.[AvgDailyNeedsForInventoryPeriod]
    FROM [TCD].[ChemicalInventoryRollUp] AS CIR
    INNER JOIN CTE_CostConversion AS CC ON CC.ProductID = CIR.ProductID
    /*
    SELECT   [ProductID]
	    ,[ChemicalName]
	    ,[InventoryDateRange]
		,Case When  @UOMId=2 Then [TCD].[UnitConversionbyUserUOM]([LastInventory],[UnitSize],@UserId)
		--When @UOMId=2 AND [UnitSize]='gal' Then [TCD].[UnitConversionbyUserUOM]([LastInventory],[UnitSize],@UserId)
		Else [LastInventory]
		End

		,Case When  @UOMId=2 Then [TCD].[UnitConversionbyUserUOM]([InventoryBasedConsumption],[UnitSize],@UserId)
		--When @UOMId=2 AND [UnitSize]='gal' Then [TCD].[UnitConversionbyUserUOM]([InventoryBasedConsumption],[UnitSize],@UserId)
		Else [InventoryBasedConsumption]
		End
		
		,Case When  @UOMId=2  Then [TCD].[UnitConversionbyUserUOM]([DispencerBasedConsumption],[UnitSize],@UserId)
		--When @UOMId=2 AND [UnitSize]='gal' Then [TCD].[UnitConversionbyUserUOM]([DispencerBasedConsumption],[UnitSize],@UserId)
		Else [DispencerBasedConsumption]
		End
		
		,Case When  @UOMId=2 AND [UnitSize]='lbs' Then [TCD].[UnitConversionbyUserUOM]([TodayEstimateInventory],[UnitSize],@UserId)
		When @UOMId=2 AND [UnitSize]='gal' Then [TCD].[UnitConversionbyUserUOM]([TodayEstimateInventory],[UnitSize],@UserId)
		Else [TodayEstimateInventory]
		End
		
		,Case When  @UOMId=2  Then [TCD].[UnitConversionbyUserUOM]([AvgDailyNeedsYTD],[UnitSize],@UserId)
		--When @UOMId=2 AND [UnitSize]='gal' Then [TCD].[UnitConversionbyUserUOM]([AvgDailyNeedsYTD],[UnitSize],@UserId)
		Else [AvgDailyNeedsYTD]
		End
		,[AvgDailyCostYTD]
		,[AvgDailyCostLoadYTD]
		,Case When  @UOMId=2  Then [TCD].[UnitConversionbyUserUOM]([AvgDailyNeedsLY],[UnitSize],@UserId)
		--When @UOMId=2 AND [UnitSize]='gal' Then [TCD].[UnitConversionbyUserUOM]([AvgDailyNeedsLY],[UnitSize],@UserId)
		Else [AvgDailyNeedsLY]
		End
		,[DayBeforeOutOfStock]

		,Case When @UOMId=2 AND [UnitSize]='lbs' Then 'kg'
		When @UOMId=2 AND [UnitSize]='gal' Then 'L'
		Else [UnitSize]
		End

		,Case When  @UOMId=2  Then [TCD].[UnitConversionbyUserUOM]([AvgDailyNeedsForInventoryPeriod],[UnitSize],@UserId)
		--When @UOMId=2 AND [UnitSize]='gal' Then [TCD].[UnitConversionbyUserUOM]([AvgDailyNeedsForInventoryPeriod],[UnitSize],@UserId)
		Else [AvgDailyNeedsForInventoryPeriod]
		End
    FROM [TCD].[ChemicalInventoryRollUp] (NOLOCK)
*/
END

GO


