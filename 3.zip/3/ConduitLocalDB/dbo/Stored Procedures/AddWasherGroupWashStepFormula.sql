﻿/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_AddWasherGroupWashStepFormula]                                             

Purpose:				To add washer group wash step formula

Parameters:				@EcoLabAccountNumber - holds ecolab account number.
						@StepNumber - holds the step number.
						@StepTypeId - holds the step type id.
						@StepRunTime - holds the step run time.
						@Temperature - Holds the temperature.
						@WaterType - holds the water type.
						@WaterLevel - holds the value of water level
						@DrainDestinationId - holds the value of drain destination id
						@pHLevel - holds the ph level
						@Note - holds the note.
						@ProgramSetupId	- holds the program setup id.
						@UserId - holds the user id.
						@RegionId - holds the region id.
						@IsDrain - holds the bit for isdrain or not.
						@DosingSetupId - holds the dosing setup id.
												
###################################################################################################                                           
*/
CREATE PROCEDURE [TCD].[AddWasherGroupWashStepFormula]
 (     
	  @EcoLabAccountNumber NVARCHAR(25)
	  ,@StepNumber INT
      ,@StepTypeId INT
      ,@StepRunTime INT 
      ,@Temperature INT
      ,@WaterType VARCHAR(50)	
      ,@WaterLevel DECIMAL(18, 2)
      ,@DrainDestinationId SMALLINT
      ,@pHLevel SMALLINT
      ,@Note NVARCHAR(1000)
	  ,@ProgramSetupId	INT
	  ,@UserId INT
	  ,@RegionId INT
	  ,@IsDrain BIT =	'FALSE'
    --,@CurrentWashStep	INT
	  ,@DosingSetupId INT OUTPUT
	  ,	@LastModifiedTimestampAtCentral			DATETIME					=	NULL
	  ,	@MyServiceCustFrmulaStpGUID				UNIQUEIDENTIFIER			=	NULL
	  ,@trackAsDosingStep BIT
)
AS
BEGIN

SET	NOCOUNT	ON

DECLARE
		@WasherGroupId							INT					=			NULL
	,	@ProgramNumber							SMALLINT			=			NULL
	,	@ReturnValue							INT					=			0
	,	@ErrorId								INT					=			0
	,	@ErrorMessage							NVARCHAR(4000)		=			N''
	,	@CurrentUTCTime							DATETIME			=			GETUTCDATE()
	,	@TotalRunTime							INT
	,	@TotalSteps								INT
	,	@ControllerModelId						INT					=			NULL
	,	@MaxWashStep							INT					=			NULL
	,	@ControllerID							INT					=			NULL
	,	@PRODUCTEXIST							BIT


SET	@DosingSetupId								=			ISNULL(@DosingSetupId, NULL)						--SQLEnlight SA0121
SET	@LastModifiedTimestampAtCentral				=			ISNULL(@LastModifiedTimestampAtCentral, NULL)		--SQLEnlight SA0029

SELECT	@WasherGroupId				=			WasherGroupId
		,@ProgramNumber				=			ProgramNumber
		,@ControllerID				=			ControllerID
FROM [TCD].WasherProgramSetup 
WHERE WasherProgramSetupId = @ProgramSetupId
AND   EcolabAccountNumber = @EcoLabAccountNumber

IF @ControllerID IS NULL
	BEGIN
		SELECT @ControllerID = wg.ControllerId FROM TCD.WasherGroup wg WHERE wg.WasherGroupId = @WasherGroupId
	END

	SELECT	@ControllerModelId		=		cc.ControllerModelId
	FROM	TCD.ConduitController	cc
	WHERE	cc.ControllerId			=		@ControllerID
	AND		cc.EcoalabAccountNumber =		@EcoLabAccountNumber 

	IF @ControllerModelId > 6 AND @ControllerModelId NOT IN (12, 13)
		BEGIN
			SELECT @TotalSteps =  COUNT(1) FROM TCD.WasherDosingSetup wds WHERE wds.WasherProgramSetupId = @ProgramSetupId AND wds.EcoLabAccountNumber = @EcoLabAccountNumber AND wds.Is_Deleted = 'False'
			SET @MaxWashStep = 25

			IF	(	@TotalSteps		=			@MaxWashStep	)
				BEGIN
						SET		@ErrorId		=			51000
						SET		@ErrorMessage	=			N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Maximum Number of washstep that can be associated to a program already defined... Aborting.'
						--GOTO	ErrorHandler
						RAISERROR	(@ErrorMessage, 16, 1)
						SET	@ReturnValue	=	-1
						RETURN	(@ReturnValue)
				END
		END

			--Check for unique
			IF	EXISTS	(		SELECT	1
								FROM	[TCD].WasherDosingSetup			WDS
								WHERE	WDS.EcolabAccountNumber		=			@EcoLabAccountNumber
									AND WDS.WasherProgramSetupId	=			@ProgramSetupId
									AND	WDS.StepNumber				=			@StepNumber
									AND	WDS.Is_Deleted				=			'FALSE'
						)
					BEGIN
							SET		@ErrorId						=			51000
							SET		@ErrorMessage					=			N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Specified WasherStep already exists for the plant.'
							--GOTO	ErrorHandler
							RAISERROR	(@ErrorMessage, 16, 1)
							SET	@ReturnValue	=	-1
							RETURN	(@ReturnValue)
					END
			
			IF	(	@IsDrain	=	'TRUE'	)
			BEGIN
				SELECT TOP 1 @StepTypeId = [StepId] FROM [TCD].[WashStep]
				WHERE StepName = 'Drain' AND RegionId = @RegionId AND IsActive = 'TRUE'
				
				SELECT TOP 1 @DrainDestinationId = [DrainDestinationId] FROM [TCD].[DrainDestination]
				WHERE [DrainDestinationName] = 'Sewer'
				
			END

			--Now INSERT the new record
			INSERT	[TCD].WasherDosingSetup	
			(
					EcolabAccountNumber
					, GroupId 
					, ProgramNumber
					, StepNumber
					, StepTypeId
					, StepRunTime
					, Temperature
					, WaterType
					, WaterLevel
					, DrainDestinationId
					, pHLevel
					, Note
					, WasherProgramSetupId
					, LastModifiedByuserId
					, MyServiceCustFrmulaStpGUID
					, ControllerID
					,TrackAsDosingStep
			)
			VALUES
			(
				  @EcoLabAccountNumber
				, CASE WHEN @ControllerModelId = 7 THEN NULL ELSE @WasherGroupId END
				, @ProgramNumber
				, @StepNumber	
				, @StepTypeId
				, @StepRunTime
				, @Temperature
				, @WaterType
				, @WaterLevel
				, CASE WHEN @DrainDestinationId = 0 THEN NULL ELSE @DrainDestinationId END
				, @pHLevel
				, @Note
				, @ProgramSetupId
				, @UserId
				, @MyServiceCustFrmulaStpGUID
				, CASE WHEN @ControllerModelId = 7 THEN @ControllerID ELSE NULL END
				,@trackAsDosingStep
			)
		
			--check for any error
			SET	@ErrorId	=	@@ERROR
	
			IF	(@ErrorId	<>	0)
				BEGIN
						SET		@ErrorMessage	=			N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred associating formula wash step.'
						--GOTO	ErrorHandler
						RAISERROR	(@ErrorMessage, 16, 1)
						SET	@ReturnValue	=	-1
						RETURN	(@ReturnValue)
				END

			--set the output param for the newly inserted record
			SET	@DosingSetupId			=			SCOPE_IDENTITY()

			 SET @PRODUCTEXIST = (SELECT PM.Is_Deleted FROM TCD.PRODUCTMASTER PM WHERE PM.ProductId= 1 AND PM.Name LIKE '%DUMMY PRODUCT%');
			   IF(@PRODUCTEXIST = 1)
				   BEGIN
				   UPDATE TCD.PRODUCTMASTER SET Is_Deleted= 0 WHERE  ProductId= 1 AND Name LIKE '%DUMMY PRODUCT%'
				   END

			SET @PRODUCTEXIST = (SELECT Is_Deleted FROM TCD.ProductdataMapping WHERE EcolabAccountNumber=@EcoLabAccountNumber AND ProductId= 1);

			IF(@PRODUCTEXIST IS NULL )
				BEGIN
				insert into TCD.ProductdataMapping(EcolabAccountNumber,ProductId,SKU,Cost,Is_Deleted,IncludeCI,InventoryExpense,LastModifiedByUserId,LastModifiedTime,LastSyncTime) values (@EcoLabAccountNumber,1,'0',0,0,0,0,0,getdate(),GETDATE())
				END
			IF(@PRODUCTEXIST = 1)
				BEGIN
				UPDATE TCD.ProductdataMapping SET Is_Deleted = 0 WHERE EcolabAccountNumber=@EcoLabAccountNumber AND ProductId= 1
				END


			IF (@IsDrain = 'FALSE' AND @trackAsDosingStep = 'TRUE')
				BEGIN
				INSERT INTO  [TCD].WasherDosingProductMapping (
					EcoLabAccountNumber
					, WasherDosingSetupId
					, InjectionNumber
					, ProductId
					, Quantity
					, LastModifiedByuserId
					, MyServiceFrmulaStpDsgDvcGuid
					, IsDeleted
					, [Delay])
					VALUES(	
					@EcoLabAccountNumber
					, @DosingSetupId
					, 1
					, 1
					, 0
					, @UserId
					,null
					, 0
					, 0)
				END

		
		
	SELECT @TotalRunTime= sum(wds.StepRunTime),@TotalSteps=COUNT(*) FROM tcd.WasherDosingSetup wds WHERE WasherProgramSetupId = @ProgramSetupId  AND wds.EcoLabAccountNumber=@EcoLabAccountNumber AND wds.Is_Deleted=0
	UPDATE TCD.WasherProgramSetup
		SET
		TotalSteps=@TotalSteps
		WHERE 
		WasherProgramSetupId = @ProgramSetupId
		AND
		EcolabAccountNumber = @EcolabAccountNumber


	IF @ControllerModelId  > 2 AND @ControllerModelId IS NOT NULL
    BEGIN
		UPDATE TCD.WasherProgramSetup
		SET
		TotalRunTime= @TotalRunTime
		WHERE 
		WasherProgramSetupId = @ProgramSetupId
		AND
		EcolabAccountNumber = @EcolabAccountNumber
	END
 
		





IF	(	@ErrorId	=	0	)
	BEGIN
		--GOTO	ExitModule
		RETURN	(@ReturnValue)
	END


--ErrorHandler:
--RAISERROR	(@ErrorMessage, 16, 1)
--SET	@ReturnValue	=	-1


--ExitModule:

SET	NOCOUNT	OFF
RETURN	(@ReturnValue)


END
