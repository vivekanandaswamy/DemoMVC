create PROCEDURE [TCD].[SaveMonitorSetup] 
(			
			@Id Int = Null,
			@DashboardId INT = NULL,
			@DashBoardName Varchar(100),
			@TypeId INT = NULL,
			@MachineId Int = NULL,
			@MonitorId Varchar(50) = NULL,		
			@EnableParameter BIT = NULL,		
			@EcolabAccountNumber NVarchar(25),
			@UserID INT ,
			@IsInLineEdit BIT,
			@Customer BIT,
			@Formula BIT,
			@Load BIT,
			@DisplayOnLogin Bit,
			@TimelineHours INT,
			@FormulaDisplayType INT,
			@EfficiencyCalcType INT,
			@MachineNameDispalyType SMALLINT,
			@Scope INT OUTPUT
)
AS 
BEGIN

SET	NOCOUNT	ON														--SQLEnlight	SA0017
SET	@Id					=				ISNULL(@Id, NULL)			--SQLEnlight	SA0029


			DECLARE @OutPut INT = NULL
				IF(@IsInLineEdit=1)  
				BEGIN   
					UPDATE TCD.[Dashboard] 
						SET DashBoardName = @DashBoardName,Customer = @Customer,Formula=@Formula,[Load]=@Load,DisplayOnLogin=@DisplayOnLogin,TimelineHours = @TimelineHours
						,MachineNameDispalyType=@MachineNameDispalyType
				    WHERE DashboardId = @DashboardId 
						AND EcolabAccountNumber = @EcolabAccountNumber  
				END  
				IF(@IsInLineEdit = 0)  
				BEGIN  
					IF NOT EXISTS(SELECT 1 FROM TCD.Dashboard WHERE DashboardId = @DashboardId AND EcolabAccountNumber = @EcolabAccountNumber)  
				BEGIN 
					INSERT INTO [Dashboard](
														DashBoardName,
														TypeId,
														IsEnableParameters,
														EcolabAccountNumber,
														LastModifiedByUser,
														Customer,
														Formula,
														[Load],
														DisplayOnLogin,
														TimelineHours,
														DisplayFormulaType,
														EfficiencyCalcType,
														MachineNameDispalyType
											)
									  VALUES(				
														@DashBoardName,									
														@TypeId,						
														@EnableParameter,
														@EcolabAccountNumber,
														@UserID,
														@Customer,
														@Formula,
														@Load,
														@DisplayOnLogin,
														@TimelineHours,
														@FormulaDisplayType,
														@EfficiencyCalcType,
														@MachineNameDispalyType
											)
				SET @DashboardId = SCOPE_IDENTITY()
				END
				ELSE
				BEGIN
					UPDATE TCD.[Dashboard] 
						SET DashBoardName = @DashBoardName,Customer = @Customer,Formula=@Formula,[Load]=@Load,DisplayOnLogin=@DisplayOnLogin,TimelineHours = @TimelineHours
						,MachineNameDispalyType=@MachineNameDispalyType
				    WHERE DashboardId = @DashboardId 
						AND EcolabAccountNumber = @EcolabAccountNumber  
				END
				INSERT INTO [MonitorSetUpMapping](
														DashboardId,
														MachineId,
														MonitorId,
														EcolabAccountNumber,
														LastModifiedByUser
												 )
										   VALUES(
															@DashboardId,
															@MachineId,						
															@MonitorId,
															@EcolabAccountNumber,
															@UserID
												 )
				END
			SET @OutPut = @DashboardId     
			SET @Scope = @OutPut SELECT @Scope  
END