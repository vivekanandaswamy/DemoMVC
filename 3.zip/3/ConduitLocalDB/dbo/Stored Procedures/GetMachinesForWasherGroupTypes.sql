CREATE PROC [TCD].[GetMachinesForWasherGroupTypes](@EcolabAccountNumber Nvarchar(25),@WasherGroupTypeId Int)

AS
SET NOCOUNT ON
BEGIN

SELECT MS.WasherId as MACHINEID
		,CAST( PlantWasherNumber as varchar(20)) +' '+ MACHINENAME MACHINENAME
FROM [TCD].WASHERGROUPTYPE WGT INNER JOIN

	[TCD].WASHERGROUP WG ON WG.WasherGroupTypeId =WGT.WasherGroupTypeId

	INNER JOIN [TCD].MACHINESETUP MS ON WG.WasherGroupId=MS.GroupId
	INNER JOIN TCD.Washer W on MS.WasherId=W.WasherId
	INNER JOIN [TCD].MachineGroup GT ON GT.Id=WG.WasherGroupId

	WHERE GT.EcolabAccountNumber=@EcolabAccountNumber
		and WGT.WASHERGROUPTYPEID=@WasherGroupTypeId
		AND MS.IsDeleted = 0
		AND ISNULL(MS.ControllerId,0) != 0
	ORDER BY W.PlantWasherNumber 


END