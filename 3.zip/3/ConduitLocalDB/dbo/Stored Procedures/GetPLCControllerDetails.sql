
CREATE PROCEDURE [TCD].[GetPLCControllerDetails]
(	@controllerId INT
)

AS
BEGIN
	SET NOCOUNT ON

	SELECT CP.ResourceKey
		,CTRL.Name
		,CG.GroupName
		FROM [TCD].ConduitController CTRL
		INNER JOIN [TCD].ControllerTagMapping CP ON CP.ControllerTypeID = CTRL.ControllerTypeId
		INNER JOIN [TCD].ControllerType CT on CT.Id = CTRl.ControllerTypeId
		INNER JOIN [TCD].Plant PL ON PL.EcolabAccountNumber = CTRL.EcoalabAccountNumber
		INNER JOIN [TCD].ControllerGroups CG ON cg.ControllerGroupID=CP.ControllerGroupID
		WHERE CTRL.ControllerId = @controllerId
	SET NOCOUNT OFF

END



