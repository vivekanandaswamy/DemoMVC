﻿CREATE PROCEDURE [TCD].[ProcessMyControlAnalogData](
	@ControllerID INT,
	@VxML         XML)
AS
	BEGIN
	    DECLARE @TimeStamp          DATETIME,
			  @TunnelNo           INT,
			  @pH1                DECIMAL(18, 4),
			  @pH2                DECIMAL(18, 4),
			  @LF                 DECIMAL(18, 4),
			  @Weight             DECIMAL(18, 4),
			  @Temperature1       DECIMAL(18, 4),
			  @Temperature2       DECIMAL(18, 4),
			  @Temperature3       DECIMAL(18, 4),
			  @Temperature4       DECIMAL(18, 4),
			  @Temperature5       DECIMAL(18, 4),
			  @Temperature6       DECIMAL(18, 4),
			  @SensorNumber       INT,
			  @MachineCompartment INT,
			  @SensorId           INT,
			  @Reading            DECIMAL(18, 4),
			  @PHNumber           INT,
			  @PHValue            VARCHAR(100),
			  @TempValue          VARCHAR(100),
			  @SensorCount        INT,
			  @TopReading         DECIMAL(18, 4);
	    -- Getting the current UTC time 
	    SELECT
			 @TimeStamp = GETUTCDATE();

	    -- 1.Extracting xml data 
	    -- 2.And joining with sensor table
	    -- 3.Getting specific Sensor id by passing machine id and controller id and is_deleted(active sensor's)
	    -- 4.CTE will return table of columns i.e sensorid,sensortype,temparature,ph values
	    --Conventional washer sensor readings

	    WITH XmlData
		    AS (
		    SELECT
				 XmlData.value('@Temperature', 'DECIMAL(18,4)')
				                                   Reading,
				 XmlData.value('@WENumber', 'int') WENumber,
				 1                                 SType
		    FROM @VxML.nodes('MyControlAnalogData/WEAnalogData') Data(
		    XmlData)
		    WHERE XmlData.value('@Temperature', 'DECIMAL(18,4)') > 0
		    UNION ALL
		    SELECT
				 XmlData.value('@pH', 'DECIMAL(18,4)') Reading,
				 XmlData.value('@WENumber', 'int')     WENumber,
				 2                                     SType
		    FROM @VxML.nodes('MyControlAnalogData/WEAnalogData') Data(
		    XmlData)
		    WHERE XmlData.value('@pH', 'DECIMAL(18,4)') > 0),
		    FormSensorDetails
		    AS (SELECT
					xd.WENumber,
					xd.SType,
					xd.Reading,
					s.SensorType,
					s.SensorId,
					GETUTCDATE() Time_Stamp
			   FROM XmlData xd
				   INNER JOIN TCD.Sensor s ON s.MachineCompartment =
				   xd.WENumber
										AND xd.SType = s.
										SensorType
				   LEFT OUTER JOIN TCD.MachineSetup ms ON ms.GroupId =
				   s.GroupId
												  AND s.
												  MachineCompartment = ms.WasherId
												  AND ms.
												  MachineInternalId = xd.WENumber
			   WHERE s.ControllerID = @ControllerID
				    AND s.Is_deleted = 0
				    AND ms.IsDeleted = 0
				    AND ms.IsTunnel = 0)
		    -- inserting records into sensor reading table using merge statement
		    MERGE INTO tcd.sensorreading sr
		    USING
		    (
			   SELECT
					*
			   FROM FormSensorDetails
		    ) temp
		    ON sr.sensorId = temp.sensorid
			  AND temp.reading =
		    (
			   SELECT TOP 1
					reading
			   FROM tcd.SensorReading
			   WHERE SensorId = temp.sensorid
			   ORDER BY
					  TimeStamp DESC
		    ) 
		    -- If records are not in the sensor reading tables
		    -- Sensor records are inserted depending on the sensor type 
			   WHEN NOT MATCHED AND ISNULL(temp.reading, 0) <> 0
			   THEN INSERT(
						sensorid,
						reading,
						timestamp) VALUES
		    (
									   temp.sensorid,
									   temp.reading,
									   temp.Time_Stamp
		    );

	    --tunnel 1 and tunnel 2 analog data


	    CREATE TABLE #TunnelAnalogInputData
	    (
		    TunnelNo     INT,
		    pH1          DECIMAL(18, 4),
		    pH2          DECIMAL(18, 4),
		    LF           DECIMAL(18, 4),
		    Weight       DECIMAL(18, 4),
		    Temperature1 DECIMAL(18, 4),
		    Temperature2 DECIMAL(18, 4),
		    Temperature3 DECIMAL(18, 4),
		    Temperature4 DECIMAL(18, 4),
		    Temperature5 DECIMAL(18, 4),
		    Temperature6 DECIMAL(18, 4)
	    );
	    CREATE TABLE #SensorReading
	    (
		    sensorId  INT,
		    Reading   DECIMAL(18, 4),
		    TimeStamp DATETIME
	    );
	    INSERT INTO #TunnelAnalogInputData
	    (
			 TunnelNo,
			 pH1,
			 pH2,
			 LF,
			 Weight,
			 Temperature1,
			 Temperature2,
			 Temperature3,
			 Temperature4,
			 Temperature5,
			 Temperature6
	    )
	    SELECT
			 T.c.value('@TunnelNo', 'INT') AS         TunnelNo,
			 T.c.value('@pH1', 'DECIMAL(18,4)') AS    pH1,
			 T.c.value('@pH2', 'DECIMAL(18,4)') AS    pH2,
			 T.c.value('@LF', 'DECIMAL(18,4)') AS     LF,
			 T.c.value('@Weight', 'DECIMAL(18,4)') AS Weight,
			 T.c.value('@Temperature1', 'DECIMAL(18,4)') AS
			                                          Temperature1,
			 T.c.value('@Temperature2', 'DECIMAL(18,4)') AS
			                                          Temperature2,
			 T.c.value('@Temperature3', 'DECIMAL(18,4)') AS
			                                          Temperature3,
			 T.c.value('@Temperature4', 'DECIMAL(18,4)') AS
			                                          Temperature4,
			 T.c.value('@Temperature5', 'DECIMAL(18,4)') AS
			                                          Temperature5,
			 T.c.value('@Temperature6', 'DECIMAL(18,4)') AS
			                                          Temperature6
	    FROM @VxML.nodes('MyControlAnalogData/TunnelAnalogData') T(C);
	    ---Start Tunnel 1 data
	    SELECT
			 @LF = tad.LF,
			 @pH1 = tad.pH1,
			 @pH2 = tad.pH2,
			 @Temperature1 = tad.Temperature1,
			 @Temperature2 = tad.Temperature2,
			 @Temperature3 = tad.Temperature3,
			 @Temperature4 = tad.Temperature4,
			 @Temperature5 = tad.Temperature5,
			 @Temperature6 = tad.Temperature6
	    FROM #TunnelAnalogInputData tad
	    WHERE tad.TunnelNo = 1;
	    SET @MachineCompartment = 1;
	    WHILE(@MachineCompartment <= 22)
		   BEGIN
			  SELECT
				    @SensorId = sr.SensorId
			  FROM TCD.Sensor sr
				  INNER JOIN TCD.MachineSetup ms ON ms.GroupId = sr.
				  GroupId
			  WHERE sr.SensorType = 4
				   AND sr.MachineCompartment = @MachineCompartment
				   AND sr.ControllerID = @ControllerID
				   AND ms.IsTunnel = 1
				   AND ms.IsDeleted = 0
				   AND ms.MachineInternalId = 1;
			  SELECT
				    @SensorCount = COUNT(1)
			  FROM TCD.SensorReading sr
			  WHERE sr.SensorId = @SensorId
				   AND sr.Reading = @LF;
			  SELECT TOP 1
				    @TopReading = sr.Reading
			  FROM TCD.SensorReading sr
			  WHERE sr.SensorId = @SensorId
			  ORDER BY
					 sr.TimeStamp DESC;
			  IF(@SensorCount = 0
				OR @TopReading != @LF)
				 BEGIN
					IF(ISNULL(@SensorId, 0) > 0
					   AND ISNULL(@LF, 0) > 0)
					    BEGIN
						   INSERT INTO #SensorReading
						   (
								SensorId,
								Reading,
								TimeStamp
						   )
						   SELECT
								@SensorId,
								@LF,
								GETUTCDATE();
					    END;
				 END;
			  SET @MachineCompartment = @MachineCompartment + 1;
			  SET @SensorId = 0;
			  SET @TopReading = 0;
		   END;
  
	    ---PH reading for tunnel 1
	    SET @PHNumber = 1;
	    WHILE(@PHNumber <= 2)
		   BEGIN
			  SELECT
				    @SensorId = sr.SensorId
			  FROM TCD.Sensor sr
				  INNER JOIN TCD.MachineSetup ms ON ms.GroupId = sr.
				  GroupId
			  WHERE sr.SensorNum = @PHNumber
				   AND sr.SensorType = 2
				   AND sr.ControllerID = @ControllerID
				   AND ms.IsTunnel = 1
				   AND ms.IsDeleted = 0
				   AND ms.MachineInternalId = 1;
			  SELECT TOP 1
				    @TopReading = sr.Reading
			  FROM TCD.SensorReading sr
			  WHERE sr.SensorId = @SensorId ORDER BY
					 sr.TimeStamp DESC;
			  SET @PHValue = '@pH'+CAST(@PHNumber AS VARCHAR);
			  IF(@PHValue = '@pH1')
				 BEGIN
					SELECT
						  @SensorCount = COUNT(1)
					FROM TCD.SensorReading sr
					WHERE sr.SensorId = @SensorId
						 AND sr.Reading = @pH1;
					IF(@SensorCount = 0
					   OR @TopReading != @pH1)
					    BEGIN
						   IF(ISNULL(@SensorId, 0) > 0
							 AND ISNULL(@pH1, 0) > 0)
							  BEGIN
								 INSERT INTO #SensorReading
								 (
									   SensorId,
									   Reading,
									   TimeStamp
								 )
								 SELECT
									   @SensorId,
									   @pH1,
									   GETUTCDATE();
							  END;
					    END;
				 END;
			  IF(@PHValue = '@pH2')
				 BEGIN
					SELECT
						  @SensorCount = COUNT(1)
					FROM TCD.SensorReading sr
					WHERE sr.SensorId = @SensorId
						 AND sr.Reading = @pH2;
					IF(@SensorCount = 0
					   OR @TopReading != @pH2)
					    BEGIN
						   IF(ISNULL(@SensorId, 0) > 0
							 AND ISNULL(@pH2, 0) > 0)
							  BEGIN
								 INSERT INTO #SensorReading
								 (
									   SensorId,
									   Reading,
									   TimeStamp
								 )
								 SELECT
									   @SensorId,
									   @pH2,
									   GETUTCDATE();
							  END;
					    END;
				 END;
			  SET @PHNumber = @PHNumber + 1;
			  SET @SensorId = 0;
			  SET @PHValue = 0;
			  SET @TopReading = 0;
		   END;
	    ---Temperature reading for tunnel 1
	    SET @SensorNumber = 1;
	    WHILE(@SensorNumber <= 6)
		   BEGIN
			  SELECT
				    @SensorId = sr.SensorId
			  FROM TCD.Sensor sr
				  INNER JOIN TCD.MachineSetup ms ON ms.GroupId = sr.
				  GroupId
			  WHERE sr.SensorNum = @SensorNumber
				   AND sr.SensorType = 1
				   AND sr.ControllerID = @ControllerID
				   AND ms.IsTunnel = 1
				   AND ms.IsDeleted = 0
				   AND ms.MachineInternalId = 1;
			  SELECT TOP 1
				    @TopReading = sr.Reading
			  FROM TCD.SensorReading sr
			  WHERE sr.SensorId = @SensorId ORDER BY
					 sr.TimeStamp DESC;
			  SET @TempValue = '@Temperature'+CAST(@SensorNumber AS
			  VARCHAR);
			  IF(@TempValue = '@Temperature1')
				 BEGIN
					SELECT
						  @SensorCount = COUNT(1)
					FROM TCD.SensorReading sr
					WHERE sr.SensorId = @SensorId
						 AND sr.Reading = @Temperature1;
					IF(@SensorCount = 0
					   OR @TopReading != @Temperature1)
					    BEGIN
						   IF(ISNULL(@sensorId, 0) > 0
							 AND ISNULL(@Temperature1, 0) > 0)
							  BEGIN
								 INSERT INTO #SensorReading
								 (
									   sensorId,
									   Reading,
									   TimeStamp
								 )
								 SELECT
									   @SensorId,
									   @Temperature1,
									   GETUTCDATE();
							  END;
					    END;
				 END;
			  IF(@TempValue = '@Temperature2')
				 BEGIN
					SELECT
						  @SensorCount = COUNT(1)
					FROM TCD.SensorReading sr
					WHERE sr.SensorId = @SensorId
						 AND sr.Reading = @Temperature2;
					IF(@SensorCount = 0
					   OR @TopReading != @Temperature2)
					    BEGIN
						   IF(ISNULL(@sensorId, 0) > 0
							 AND ISNULL(@Temperature2, 0) > 0)
							  BEGIN
								 INSERT INTO #SensorReading
								 (
									   sensorId,
									   Reading,
									   TimeStamp
								 )
								 SELECT
									   @SensorId,
									   @Temperature2,
									   GETUTCDATE();
							  END;
					    END;
				 END;
			  IF(@TempValue = '@Temperature3')
				 BEGIN
					SELECT
						  @SensorCount = COUNT(1)
					FROM TCD.SensorReading sr
					WHERE sr.SensorId = @SensorId
						 AND sr.Reading = @Temperature3;
					IF(@SensorCount = 0
					   OR @TopReading != @Temperature3)
					    BEGIN
						   IF(ISNULL(@sensorId, 0) > 0
							 AND ISNULL(@Temperature3, 0) > 0)
							  BEGIN
								 INSERT INTO #SensorReading
								 (
									   sensorId,
									   Reading,
									   TimeStamp
								 )
								 SELECT
									   @SensorId,
									   @Temperature3,
									   GETUTCDATE();
							  END;
					    END;
				 END;
			  IF(@TempValue = '@Temperature4')
				 BEGIN
					SELECT
						  @SensorCount = COUNT(1)
					FROM TCD.SensorReading sr
					WHERE sr.SensorId = @SensorId
						 AND sr.Reading = @Temperature4;
					IF(@SensorCount = 0
					   OR @TopReading != @Temperature4)
					    BEGIN
						   IF(ISNULL(@sensorId, 0) > 0
							 AND ISNULL(@Temperature4, 0) > 0)
							  BEGIN
								 INSERT INTO #SensorReading
								 (
									   sensorId,
									   Reading,
									   TimeStamp
								 )
								 SELECT
									   @SensorId,
									   @Temperature4,
									   GETUTCDATE();
							  END;
					    END;
				 END;
			  IF(@TempValue = '@Temperature5')
				 BEGIN
					SELECT
						  @SensorCount = COUNT(1)
					FROM TCD.SensorReading sr
					WHERE sr.SensorId = @SensorId
						 AND sr.Reading = @Temperature5;
					IF(@SensorCount = 0
					   OR @TopReading != @Temperature5)
					    BEGIN
						   IF(ISNULL(@sensorId, 0) > 0
							 AND ISNULL(@Temperature5, 0) > 0)
							  BEGIN
								 INSERT INTO #SensorReading
								 (
									   sensorId,
									   Reading,
									   TimeStamp
								 )
								 SELECT
									   @SensorId,
									   @Temperature5,
									   GETUTCDATE();
							  END;
					    END;
				 END;
			  IF(@TempValue = '@Temperature6')
				 BEGIN
					SELECT
						  @SensorCount = COUNT(1)
					FROM TCD.SensorReading sr
					WHERE sr.SensorId = @SensorId
						 AND sr.Reading = @Temperature6;
					IF(@SensorCount = 0
					   OR @TopReading != @Temperature6)
					    BEGIN
						   IF(ISNULL(@sensorId, 0) > 0
							 AND ISNULL(@Temperature6, 0) > 0)
							  BEGIN
								 INSERT INTO #SensorReading
								 (
									   sensorId,
									   Reading,
									   TimeStamp
								 )
								 SELECT
									   @SensorId,
									   @Temperature6,
									   GETUTCDATE();
							  END;
					    END;
				 END;
			  SET @SensorNumber = @SensorNumber + 1;
			  SET @SensorId = 0;
			  SET @TempValue = 0;
			  SET @TopReading = 0;
		   END;  
	    --  INSERT INTO TCD.SensorReading(SensorId,Reading,TimeStamp)
	    --SELECT *  FROM #SensorReading
	    ---Start Tunnel 2 data
	    SELECT
			 @LF = tad.LF,
			 @pH1 = tad.pH1,
			 @pH2 = tad.pH2,
			 @Temperature1 = tad.Temperature1,
			 @Temperature2 = tad.Temperature2,
			 @Temperature3 = tad.Temperature3,
			 @Temperature4 = tad.Temperature4,
			 @Temperature5 = tad.Temperature5,
			 @Temperature6 = tad.Temperature6
	    FROM #TunnelAnalogInputData tad
	    WHERE tad.TunnelNo = 2;
	    SET @MachineCompartment = 1;
	    WHILE(@MachineCompartment <= 22)
		   BEGIN
			  SELECT
				    @SensorId = sr.SensorId
			  FROM TCD.Sensor sr
				  INNER JOIN TCD.MachineSetup ms ON ms.GroupId = sr.
				  GroupId
			  WHERE sr.SensorType = 4
				   AND sr.MachineCompartment = @MachineCompartment
				   AND sr.ControllerID = @ControllerID
				   AND ms.IsTunnel = 1
				   AND ms.IsDeleted = 0
				   AND ms.MachineInternalId = 2;
			  SELECT
				    @SensorCount = COUNT(1)
			  FROM TCD.SensorReading sr
			  WHERE sr.SensorId = @SensorId
				   AND sr.Reading = @LF;
			SELECT TOP 1
				    @TopReading = sr.Reading
			  FROM TCD.SensorReading sr
			  WHERE sr.SensorId = @SensorId
			  ORDER BY
					 sr.TimeStamp DESC;
			  IF(@SensorCount = 0
				OR @TopReading != @LF)
				 BEGIN
					IF(ISNULL(@SensorId, 0) > 0
					   AND ISNULL(@LF, 0) > 0)
					    BEGIN
						   INSERT INTO #SensorReading
						   (
								SensorId,
								Reading,
								TimeStamp
						   )
						   SELECT
								@SensorId,
								@LF,
								GETUTCDATE();
					    END;
				 END;
			  SET @MachineCompartment = @MachineCompartment + 1;
			  SET @SensorId = 0;
			  SET @TopReading = 0;
		   END;
  
	    ---PH reading for tunnel 2
	    SET @PHNumber = 1;
	    WHILE(@PHNumber <= 2)
		   BEGIN
			  SELECT
				    @SensorId = sr.SensorId
			  FROM TCD.Sensor sr
				  INNER JOIN TCD.MachineSetup ms ON ms.GroupId = sr.
				  GroupId
			  WHERE sr.SensorNum = @PHNumber
				   AND sr.SensorType = 2
				   AND sr.ControllerID = @ControllerID
				   AND ms.IsTunnel = 1
				   AND ms.IsDeleted = 0
				   AND ms.MachineInternalId = 2;
			  SELECT TOP 1
				    @TopReading = sr.Reading
			  FROM TCD.SensorReading sr
			  WHERE sr.SensorId = @SensorId ORDER BY
					 sr.TimeStamp DESC;
			  SET @PHValue = '@pH'+CAST(@PHNumber AS VARCHAR);
			  IF(@PHValue = '@pH1')
				 BEGIN
					SELECT
						  @SensorCount = COUNT(1)
					FROM TCD.SensorReading sr
					WHERE sr.SensorId = @SensorId
						 AND sr.Reading = @pH1;
					IF(@SensorCount = 0
					   OR @TopReading != @pH1)
					    BEGIN
						   IF(ISNULL(@SensorId, 0) > 0
							 AND ISNULL(@pH1, 0) > 0)
							  BEGIN
								 INSERT INTO #SensorReading
								 (
									   SensorId,
									   Reading,
									   TimeStamp
								 )
								 SELECT
									   @SensorId,
									   @pH1,
									   GETUTCDATE();
							  END;
					    END;
				 END;
			  IF(@PHValue = '@pH2')
				 BEGIN
					SELECT
						  @SensorCount = COUNT(1)
					FROM TCD.SensorReading sr
					WHERE sr.SensorId = @SensorId
						 AND sr.Reading = @pH2;
					IF(@SensorCount = 0
					   OR @TopReading != @pH2)
					    BEGIN
						   IF(ISNULL(@SensorId, 0) > 0
							 AND ISNULL(@pH2, 0) > 0)
							  BEGIN
								 INSERT INTO #SensorReading
								 (
									   SensorId,
									   Reading,
									   TimeStamp
								 )
								 SELECT
									   @SensorId,
									   @pH2,
									   GETUTCDATE();
							  END;
					    END;
				 END;
			  SET @PHNumber = @PHNumber + 1;
			  SET @SensorId = 0;
			  SET @PHValue = 0;
			  SET @TopReading = 0;
		   END;
	    ---Temperature reading for tunnel 2
	    SET @SensorNumber = 1;
	    WHILE(@SensorNumber <= 6)
		   BEGIN
			  SELECT
				    @SensorId = sr.SensorId
			  FROM TCD.Sensor sr
				  INNER JOIN TCD.MachineSetup ms ON ms.GroupId = sr.
				  GroupId
			  WHERE sr.SensorNum = @SensorNumber
				   AND sr.SensorType = 1
				   AND sr.ControllerID = @ControllerID
				   AND ms.IsTunnel = 1
				   AND ms.IsDeleted = 0
				   AND ms.MachineInternalId = 2;
			  SELECT TOP 1
				    @TopReading = sr.Reading
			  FROM TCD.SensorReading sr
			  WHERE sr.SensorId = @SensorId ORDER BY
					 sr.TimeStamp DESC;
			  SET @TempValue = '@Temperature'+CAST(@SensorNumber AS
			  VARCHAR);
			  IF(@TempValue = '@Temperature1')
				 BEGIN
					SELECT
						  @SensorCount = COUNT(1)
					FROM TCD.SensorReading sr
					WHERE sr.SensorId = @SensorId
						 AND sr.Reading = @Temperature1;
					IF(@SensorCount = 0
					   OR @TopReading != @Temperature1)
					    BEGIN
						   IF(ISNULL(@sensorId, 0) > 0
							 AND ISNULL(@Temperature1, 0) > 0)
							  BEGIN
								 INSERT INTO #SensorReading
								 (
									   sensorId,
									   Reading,
									   TimeStamp
								 )
								 SELECT
									   @SensorId,
									   @Temperature1,
									   GETUTCDATE();
							  END;
					    END;
				 END;
			  IF(@TempValue = '@Temperature2')
				 BEGIN
					SELECT
						  @SensorCount = COUNT(1)
					FROM TCD.SensorReading sr
					WHERE sr.SensorId = @SensorId
						 AND sr.Reading = @Temperature2;
					IF(@SensorCount = 0
					   OR @TopReading != @Temperature2)
					    BEGIN
						   IF(ISNULL(@sensorId, 0) > 0
							 AND ISNULL(@Temperature2, 0) > 0)
							  BEGIN
								 INSERT INTO #SensorReading
								 (
									   sensorId,
									   Reading,
									   TimeStamp
								 )
								 SELECT
									   @SensorId,
									   @Temperature2,
									   GETUTCDATE();
							  END;
					    END;
				 END;
			  IF(@TempValue = '@Temperature3')
				 BEGIN
					SELECT
						  @SensorCount = COUNT(1)
					FROM TCD.SensorReading sr
					WHERE sr.SensorId = @SensorId
						 AND sr.Reading = @Temperature3;
					IF(@SensorCount = 0
					   OR @TopReading != @Temperature3)
					    BEGIN
						   IF(ISNULL(@sensorId, 0) > 0
							 AND ISNULL(@Temperature3, 0) > 0)
							  BEGIN
								 INSERT INTO #SensorReading
								 (
									   sensorId,
									   Reading,
									   TimeStamp
								 )
								 SELECT
									   @SensorId,
									   @Temperature3,
									   GETUTCDATE();
							  END;
					    END;
				 END;
			  IF(@TempValue = '@Temperature4')
				 BEGIN
					SELECT
						  @SensorCount = COUNT(1)
					FROM TCD.SensorReading sr
					WHERE sr.SensorId = @SensorId
						 AND sr.Reading = @Temperature4;
					IF(@SensorCount = 0
					   OR @TopReading != @Temperature4)
					    BEGIN
						   IF(ISNULL(@sensorId, 0) > 0
							 AND ISNULL(@Temperature4, 0) > 0)
							  BEGIN
								 INSERT INTO #SensorReading
								 (
									   sensorId,
									   Reading,
									   TimeStamp
								 )
								 SELECT
									   @SensorId,
									   @Temperature4,
									   GETUTCDATE();
							  END;
					    END;
				 END;
			  IF(@TempValue = '@Temperature5')
				 BEGIN
					SELECT
						  @SensorCount = COUNT(1)
					FROM TCD.SensorReading sr
					WHERE sr.SensorId = @SensorId
						 AND sr.Reading = @Temperature5;
					IF(@SensorCount = 0
					   OR @TopReading != @Temperature5)
					    BEGIN
						   IF(ISNULL(@sensorId, 0) > 0
							 AND ISNULL(@Temperature5, 0) > 0)
							  BEGIN
								 INSERT INTO #SensorReading
								 (
									   sensorId,
									   Reading,
									   TimeStamp
								 )
								 SELECT
									   @SensorId,
									   @Temperature5,
									   GETUTCDATE();
							  END;
					    END;
				 END;
			  IF(@TempValue = '@Temperature6')
				 BEGIN
					SELECT
						  @SensorCount = COUNT(1)
					FROM TCD.SensorReading sr
					WHERE sr.SensorId = @SensorId
						 AND sr.Reading = @Temperature6;
					IF(@SensorCount = 0
					   OR @TopReading != @Temperature6)
					    BEGIN
						   IF(ISNULL(@sensorId, 0) > 0
							 AND ISNULL(@Temperature6, 0) > 0)
							  BEGIN
								 INSERT INTO #SensorReading
								 (
									   sensorId,
									   Reading,
									   TimeStamp
								 )
								 SELECT
									   @SensorId,
									   @Temperature6,
									   GETUTCDATE();
							  END;
					    END;
				 END;
			  SET @SensorNumber = @SensorNumber + 1;
			  SET @SensorId = 0;
			  SET @TempValue = 0;
			  SET @TopReading = 0;
		   END;
	    INSERT INTO TCD.SensorReading
	    (
			 SensorId,
			 Reading,
			 TimeStamp
	    )
	    SELECT
			 sensorId,
			 Reading,
			 TimeStamp
	    FROM #SensorReading;
	    DROP TABLE #SensorReading;
	END;