﻿CREATE PROCEDURE [TCD].[SaveControllerSetupAdvanceData] 
(
  @ControllerSetupData XML
 , @UserId     INT
 , @LastModifiedTimestampAtCentral   DATETIME = NULL
 , @OutputLastModifiedTimestampAtLocal  DATETIME = NULL OUTPUT
)
AS
BEGIN
      SET NOCOUNT ON

   DECLARE 
   @ControllerId     INT     = NULL
   ,  @EcolabAccountNumber   NVARCHAR(25)  = NULL
   ,  @LFSInjectionClasses nvarchar(50) = NULL
   ,  @ErrorId      INT     = 0
   ,  @ErrorMessage     VARCHAR(200)  = NULL
   ,  @CurrentUTCTime     DATETIME   = GETUTCDATE()

   DECLARE
   @OutputList      AS TABLE  (
   LastModifiedTimestamp   DATETIME
  )

 SET  @OutputLastModifiedTimestampAtLocal   =   ISNULL(@OutputLastModifiedTimestampAtLocal, NULL)   --SQLEnlight

   SELECT @ControllerId = Tbl.col.value('@ControllerId', 'int')
     FROM   @ControllerSetupData.nodes('/ControllerSetupData/DynamicSetupData/Data') AS Tbl (col)

   SELECT @EcolabAccountNumber = Tbl.col.value('@EcolabAccountNumber', 'varchar(1000)')
     FROM   @ControllerSetupData.nodes('/ControllerSetupData/DynamicSetupData/Data') AS Tbl (col)

 SELECT @LFSInjectionClasses = Tbl.col.value('@Value', 'int')
     FROM   @ControllerSetupData.nodes('/ControllerSetupData/DynamicSetupData/Data') AS Tbl (col)
	 WHERE  Tbl.col.value('@FieldId', 'int') IN (219, 220, 221,222,223,224)

   DECLARE @TempDynamic TABLE
        (
    EcolabAccountNumber  NVARCHAR(1000)
   , ControllerId   INT
   , ControllerModelId  INT
   , FieldGroupId   INT
   , FieldId     INT
   , Value     VARCHAR(1000)
   , FieldTagValue    VARCHAR(1000)
   , UserId     INT
        )

 BEGIN TRANSACTION
  BEGIN TRY
   INSERT INTO @TempDynamic
      (
       EcolabAccountNumber
      , ControllerId
      , ControllerModelId
      , FieldGroupId
      , FieldId
      , Value
	  , FieldTagValue
      , UserId
      )
   SELECT
     @EcolabAccountNumber 
    , @ControllerId
    , Tbl.col.value('@ControllerModelId', 'int')
    , Tbl.col.value('@FieldGroupId', 'int')
    , Tbl.col.value('@FieldId', 'int')
    , Tbl.col.value('@Value', 'varchar(1000)')
	, Tbl.col.value('@FieldTagValue','varchar(1000)')
    , @UserId
   FROM   @ControllerSetupData.nodes('/ControllerSetupData/DynamicSetupData/Data') AS Tbl (col)

   IF (
         @LastModifiedTimestampAtCentral    IS NOT NULL
         AND
         NOT EXISTS ( SELECT 1
           FROM TCD.ConduitController  CC
           WHERE CC.EcoalabAccountNumber  = @EcolabAccountNumber
            AND CC.ControllerId    = @ControllerId
            AND CC.LastModifiedTime   = @LastModifiedTimestampAtCentral
          )
    )
   BEGIN
     SET   @ErrorId    = 60000
     SET   @ErrorMessage   = N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
     RAISERROR (@ErrorMessage, 16, 1)
     RETURN
   END
   
   
   INSERT INTO [TCD].ControllerSetupData(EcolabAccountNumber, ControllerId, FieldGroupId, FieldId, Value, ControllerModelId, LastModifiedByUserId,FieldTagValue)
   SELECT @EcolabAccountNumber, ControllerId,FieldGroupId,FieldId,Value,ControllerModelId,UserId,FieldTagValue FROM @TempDynamic
 
   IF ((SELECT COUNT (*) from @TempDynamic where FieldTagValue='TAG_MIC')>0 AND (ISNULL((Select  [Value] from @TempDynamic where FieldTagValue='TAG_MIC'),0)>0))
			 BEGIN
			   UPDATE TCD.ConduitController
			   SET
			   LFSInjectionClasses = (Select TOP 1 [Value] from @TempDynamic where FieldTagValue='TAG_MIC')
			   WHERE 
			   ControllerId = @ControllerId
			   AND
			   EcoalabAccountNumber = @EcolabAccountNumber
			END

			UPDATE TCD.ConduitController
			   SET
			   LastModifiedTime = @CurrentUTCTime
			   OUTPUT
			    inserted.LastModifiedTime  AS   LastModifiedTimestamp
			   INTO
			    @OutputList (
			    LastModifiedTimestamp
			   )
			   WHERE 
			   ControllerId = @ControllerId
			   AND
			   EcoalabAccountNumber = @EcolabAccountNumber


   SELECT TOP 1 @OutputLastModifiedTimestampAtLocal = O.LastModifiedTimestamp FROM @OutputList O

   COMMIT TRANSACTION
  END TRY
  BEGIN CATCH
   SELECT 
    ERROR_NUMBER() AS ErrorNumber,
    ERROR_SEVERITY() AS ErrorSeverity,
    ERROR_STATE() AS ErrorState,
    ERROR_PROCEDURE() AS ErrorProcedure,
    ERROR_LINE() AS ErrorLine,
    ERROR_MESSAGE() AS ErrorMessage

   ROLLBACK TRANSACTION
  END CATCH
SET NOCOUNT OFF
END
