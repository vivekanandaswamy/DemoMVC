﻿CREATE PROCEDURE [TCD].[ProcessMyControlWAndEAnalogData](
	@ControllerID INT,
	@xmlTags      XML)
AS
	BEGIN
	    DECLARE @Reading            DECIMAL(10, 6),
			  @AnalogInputNumber  INT,
			  @MachineCompartment INT,
			  @SensorId           INT,
			  @AnalogCount        INT;
	    CREATE TABLE #AnalogInputData
	    (
		    Number   INT,
		    Quantity DECIMAL(10, 6),
	    );
	    INSERT INTO #AnalogInputData
	    (
			 Number,
			 Quantity
	    )
	    SELECT
			 T.c.value('@CounterNo', 'INT') AS         Number, --AnalogNumber
			 T.c.value('@Reading', 'DECIMAL(10,6)') AS Quantity --Water Quanity
	    FROM @xmlTags.nodes(
			 'MyControlWaterEnergyLoggerAnalogData/AnalogInputData/AnalogData'
					   ) T(C);
	    SET @AnalogInputNumber = 1;
	    WHILE(@AnalogInputNumber <= 8)
		   BEGIN
			  SELECT
				    @SensorId = sr.SensorId,
				    @MachineCompartment = sr.MachineCompartment
			  FROM TCD.Sensor sr
			  WHERE sr.AnalogueInputNumber = @AnalogInputNumber
				   AND sr.ControllerID = @ControllerID;
			  SELECT
				    @Reading = wc.Quantity
			  FROM #AnalogInputData wc
			  WHERE wc.Number = @AnalogInputNumber;
			  --SET @SensorId=1
			  --SET @MachineCompartment=2
			  SELECT
				    @AnalogCount = COUNT(1)
			  FROM TCD.SensorReading
			  WHERE Reading = @Reading
				   AND SensorId = @SensorId;
			  IF(@AnalogCount = 0)
				 BEGIN
					IF(ISNULL(@Reading, 0) > 0
					   AND ISNULL(@SensorId, 0) > 0
					   AND ISNULL(@MachineCompartment, 0) > 0)
					    BEGIN
						   INSERT INTO TCD.SensorReading
						   (
								SensorId,
								Reading,
								TimeStamp
						   )
						   SELECT
								@SensorId,
								@Reading,
								GETUTCDATE();
					    END;
				 END;
				 SET @AnalogInputNumber = @AnalogInputNumber + 1;
		   END;
	END;