﻿CREATE PROCEDURE [TCD].[GetControllerTypeDetail](@ControllerModelId Int)
AS
SET NOCOUNT ON
BEGIN    
	SELECT 
	CT.Id
	,CT.Name
	FROM 
	[TCD].[ControllerType] CT
	INNER JOIN [TCD].[ControllerModelControllerTypeMapping] CMCT 
	ON CMCT.ControllerTypeId = CT.Id
	WHERE
	CMCT.ControllerModelId = @ControllerModelId
END