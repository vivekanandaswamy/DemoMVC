﻿/*	
Purpose					:	To populate the drop-down (Water Inlet/Drain) in the Tunnel setup --> Compartments tab

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version

usp_GetTunnelWaterInletDrainLookup
*/

CREATE	PROCEDURE	[TCD].[GetTunnelWaterInletDrainLookup]
	@EcoLabAccountNumber					nvarchar(25)
	AS
BEGIN

	SET	NOCOUNT	ON
	DECLARE @RegionId INT
		SELECT @RegionId = RegionId from tcd.Plant WHERE EcolabAccountNumber = @EcoLabAccountNumber  
		 

	SELECT	T.Name  AS Name
			,CAST(T.TunnelWaterInletDrainLookupId AS INT)	AS	Id
	FROM	[TCD].TunnelWaterInletDrainLookup			T
	WHERE T.RegionId					=			@RegionId
		AND	T.Is_Deleted				=			0

	SET	NOCOUNT	OFF
END