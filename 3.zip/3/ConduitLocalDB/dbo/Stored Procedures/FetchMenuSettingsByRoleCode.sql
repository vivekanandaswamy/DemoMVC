﻿
/*   
 ==========================================================================================  
 Purpose:  Save the Plant Details.   

 Author:  Premchand Yelavarthi   

 --------------------------------------------------------------   
 July-22-2014 ENT: Initial version.   
 ==========================================================================================  

 [dbo].[usp_tcd_FetchMenuSettingsByRoleCode] 'ADM'

 Select top 1 * from conduitmenu

 Select top 1 * from [conduitmenurolemapping]
*/

CREATE PROCEDURE [TCD].FetchMenuSettingsByRoleCode(@PassingRoleCode
											  VARCHAR(100) = NULL)
AS
SET NOCOUNT ON
BEGIN

    --DECLARE @PassingRoleCode VARCHAR(100) = 'TMB'

    DECLARE
	    @String    VARCHAR(MAX) = @PassingRoleCode,
	    @Delimiter CHAR(1) = ',' ,
	    @Row_Count INT,
	    @ParentID INT;
    DECLARE
	    @temptable TABLE
	    (
	    items VARCHAR(MAX)
	    );
    IF @String = ''
	   BEGIN SELECT @String = 'N';
	   END;
    ELSE
	   BEGIN SELECT @String = @PassingRoleCode;
	   END;
    BEGIN
	   DECLARE
		   @idx INT;
	   DECLARE
		   @slice VARCHAR(8000);
	   SELECT @idx = 1;
	   IF LEN(@String) < 1
	   OR @String IS NULL
		  BEGIN
			 RETURN;
		  END;
	   WHILE @idx != 0
		  BEGIN
			 SET @idx = CHARINDEX(@Delimiter, @String);
			 IF @idx != 0
				BEGIN
				    SET @slice = LEFT(@String, @idx - 1);
				END;
			 ELSE
				BEGIN
				    SET @slice = @String;
				END;
			 IF LEN(@slice) > 0
				BEGIN
				    INSERT INTO @temptable
				    (items)
				    VALUES      (@slice);
				END;
			 SET @String = RIGHT(@String, LEN(@String)
									-
									@idx);
			 IF LEN(@String) = 0
				BEGIN
				    BREAK;
				END;
		  END;

	   --Select @Row_Count = COUNT(1) from @temptable
	   --if(@Row_Count = 0) insert into @temptable values(' ')

	   BEGIN
		  SELECT sectionid         AS SectionID,
			    sectionname       AS SectionName,
			    UM.sectioncode    AS SectionCode,
			    UM.sectiontype    AS SectionType,
			    UM.controllername AS ControllerName,
			    UM.viewname       AS ViewName,
			    UM.resourceclass  AS ResourceClass,
			    UM.resourcekey    AS ResourceKey,
			    UM.parentid       AS ParentId

		  --CASE 
		  --  WHEN UM.parentid IS NULL THEN NULL 
		  --  ELSE (SELECT sectioncode 
		  --        FROM   dbo.conduitmenu 
		  --        WHERE  sectionid = UM.parentid) 
		  --END               AS [ParentSectionCode] 
		  --mr.userrolecode 

		  INTO #Role_Menu
		    FROM [TCD].conduitmenu UM
			    INNER JOIN
			    [TCD].conduitmenurolemapping MR ON Um.sectioncode = mr.sectioncode
		    WHERE  parentid IS NULL
			   OR mr.userrolecode IN (
				 SELECT items
				   FROM @temptable)
			  AND mr.settingvalue = 'true';

		  SELECT DISTINCT 
					   SectionID,
					   SectionName,
					   SectionCode,
					   SectionType,
					   ControllerName,
					   ViewName,
					   ResourceClass,
					   ResourceKey,
					   ParentId

		    FROM #Role_Menu;

		  --Union all
		  --SELECT distinct sectionid         AS [SectionID], 
		  --              sectionname       AS [SectionName], 
		  --              UM.sectioncode    AS [SectionCode], 
		  --              UM.sectiontype    AS [SectionType], 
		  --              UM.controllername AS [ControllerName], 
		  --              UM.viewname       AS [ViewName], 
		  --              UM.resourceclass  AS [ResourceClass], 
		  --              UM.resourcekey    AS [ResourceKey], 
		  --	 UM.parentid       AS [ParentId]
		  --              --CASE 
		  --              --  WHEN UM.parentid IS NULL THEN NULL 
		  --              --  ELSE (SELECT sectioncode 
		  --              --        FROM   dbo.conduitmenu 
		  --              --        WHERE  sectionid = UM.parentid) 
		  --              --END               AS [ParentSectionCode]
		  --              --mr.userrolecode 
		  --	 from ConduitMenu UM 
		  --              Left Join [dbo].[conduitmenurolemapping] MR 
		  --                  ON Um.sectioncode = mr.sectioncode
		  --	 where UM.ParentID in (Select SectionID AS SECTIONID from #Role_Menu)
		  --	 and mr.settingvalue = 'true' 

		  DROP TABLE #Role_Menu;
	   END;
    END;
END;