﻿CREATE PROCEDURE [TCD].[GetReferenceLoad] @EcolabAccountNumber NVARCHAR(25), 
              @WasherGroupId       INT
AS 
  BEGIN 
   SET NOCOUNT ON 

   
   SELECT Max(i.ReferenceLoad) 
   FROM   TCD.Injection i (NOLOCK) 
       INNER JOIN TCD.WasherGroup wg (NOLOCK) 
         ON wg.WasherGroupNumber = i.WasherGroupNumber 
         AND wg.EcolabAccountNumber = i.EcolabAccountNumber 
       INNER JOIN TCD.MachineSetup ms (NOLOCK) 
         ON ms.GroupId = wg.WasherGroupId 
         AND ms.EcoalabAccountNumber = wg.EcolabAccountNumber 
         AND ms.IsDeleted = 0 
       INNER JOIN TCD.Washer w (NOLOCK) 
         ON w.WasherId = ms.WasherId 
         AND w.EcoLabAccountNumber = ms.EcoalabAccountNumber 
         AND w.Is_Deleted = 0 
   WHERE  I.WasherGroupNumber IN (SELECT WasherGroupNumber 
             FROM   TCD.WasherGroup wg 
             WHERE  wg.WasherGroupId = @WasherGroupId               
              AND wg.EcolabAccountNumber = @EcolabAccountNumber
	      )
       AND i.EcolabAccountNumber = @EcolabAccountNumber 

   SET NOCOUNT OFF
   END;