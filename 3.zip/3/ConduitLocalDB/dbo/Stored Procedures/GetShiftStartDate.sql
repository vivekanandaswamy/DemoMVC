﻿CREATE PROCEDURE [TCD].[GetShiftStartDate](@BatchDate datetime)
AS

BEGIN
declare @BatchDateWithOutUTC datetime

IF (@BatchDate is NOT NULL)
BEGIN
	--SET @BatchDateWithOutUTC=@BatchDate
 SELECT @BatchDateWithOutUTC = DATEADD(MILLISECOND,+DATEDIFF(MILLISECOND,getutcdate(),GETDATE()),@BatchDate) 
IF NOT EXISTS(SELECT TCD.productionshiftdata.ShiftId,TCD.productionshiftdata.ShiftName,TCD.productionshiftdata.StartDateTime
     FROM tcd.productionshiftdata 
     where @BatchDate between StartDateTime AND EndDateTime)
 BEGIN
 DECLARE @DayId INT = NULL,
    @ShiftId Int = NULL,
    @ShiftName Varchar(100) = NULL,
    @StartTime DateTime = NULL,
    @EndTime DateTime = NULL,
    @DateStartTime DATETIME= NULL,
    @DateEndTime DATETIME= NULL,
    @BatchUTCStart DATETIME= NULL,
    @BatchUTCEnd DATETIME= NULL,
    @ShiftTargetProd Decimal(18,2) = NULL,
    @ConStdTurnTime Int= NULL,
    @ActualRunandConTurnTime Int= NULL,
    @TargetRunandConTurnTime Int= NULL,
    @ActualRunandTunTurnTime Int= NULL,
    @TargetRunandTunTurnTime Int= NULL,
    @SummationProduction Int,
    @NoOfLoads INT,@prevDay INT,@Rollingcount int = 1        
  ,@RowCount int = NULL,@RealDayId Int,@ShiftCount Int = 1,@LabourShift int
  ,@EcolabAccountNumber NVARCHAR(25) = NULL
  ,@IsBackdate bit=0

 if(cast( getdate() AS date) != cast( @BatchDateWithOutUTC AS date))
 BEGIN
  SET  @IsBackdate =1
 END

  SELECT @DayId = DayId FROM [TCD].WeekDay WITH (NOLOCK) WHERE DayName = DATENAME(dw,@BatchDateWithOutUTC) 

  SELECT @EcolabAccountNumber = EcolabAccountNumber FROM TCD.Plant

    DECLARE @BatchShiftTable TABLE
      (
        RowNumber int IDENTITY(1,1),
        BatchUTCStartDate datetime,
        BatchUTCEndDate datetime,
        ShiftId int
      )

    DECLARE @Result TABLE
        (
        StartDate Datetime,
        EndDate Datetime,
        ShiftId INT,
        ShiftName Varchar(1000),
        DayID Int,
        TargetProduction [decimal](18,2)
        )

    DECLARE @shiftdata_temp TABLE
        (
        SNo INT IDENTITY(1,1),
        [ShiftId] [int],
         [ShiftName] [nvarchar](1000) ,
         [DayId] [int] ,
         [StartTime] [time](7) ,
         [EndTime] [time](7) ,
         [TargetProduction] [decimal](18, 2)
    
         )        
	    /* FOR BACK DATE BACHES LIKE WEB PORT READING*/
    IF(@IsBackdate=1)
    BEGIN
		INSERT INTO @shiftdata_temp
	    SELECT TOP 1  
		SDH.[ShiftId] ,           
		SD.[ShiftName],  
		SDH.[DayId],              
		SDH.[StartTime],          
		SDH.[EndTime],            
		SDH.[TargetProduction]
      
	 FROM TCD.ShiftDataHistory SDH WITH (NOLOCK) 
	 INNER JOIN TCD.ShiftData SD WITH (NOLOCK) ON SDH.DayId = SD.DayId AND SDH.ShiftId = SD.ShiftId
	   WHERE  @BatchDateWithOutUTC  between  cast (  DATEADD(dd, 0, DATEDIFF(dd, 0, @BatchDateWithOutUTC)) AS datetime) + cast(  sd.StartTime as datetime)
			 AND cast (  DATEADD(dd, 0, DATEDIFF(dd, 0, @BatchDateWithOutUTC)) AS datetime)+ cast(    sd.StartTime as datetime)
				 + cast( CONVERT(time(7),DATEADD(s, DATEDIFF(s,sd.StartTime,sd.EndTime),'00:00:00')) as datetime) 
	   AND SDH.DayId = @DayId and  sd.Is_Deleted=0 and SDH.Is_Deleted=0
	   AND SDH.OperationTimestamp <=@BatchDateWithOutUTC
	 ORDER BY SDH.OperationTimestamp DESC
  END
  ELSE
  BEGIN
    INSERT INTO @shiftdata_temp
	    SELECT TOP 1  
		SD.[ShiftId] ,           
		SD.[ShiftName],  
		SD.[DayId],              
		SD.[StartTime],          
		SD.[EndTime],            
		SD.[TargetProduction]      
	 FROM  TCD.ShiftData SD WITH (NOLOCK) 
	   WHERE  @BatchDateWithOutUTC  between  cast (  DATEADD(dd, 0, DATEDIFF(dd, 0, @BatchDateWithOutUTC)) AS datetime) + cast(  sd.StartTime as datetime)
			 AND cast (  DATEADD(dd, 0, DATEDIFF(dd, 0, @BatchDateWithOutUTC)) AS datetime)+ cast(    sd.StartTime as datetime)
				 + cast( CONVERT(time(7),DATEADD(s, DATEDIFF(s,sd.StartTime,sd.EndTime),'00:00:00')) as datetime)
	   AND SD.DayId = @DayId and  sd.Is_Deleted=0 
  END

  UPDATE @shiftdata_temp SET DayId = CASE WHEN @DayId = 1 THEN 0 ELSE DayId END WHERE DayId = 7
  UPDATE @shiftdata_temp SET DayId = CASE WHEN @DayId = 7 THEN 8 ELSE DayId END WHERE DayId = 1

       
   DECLARE @VALIDSTART DATETIME,@VALIDEND DATETIME    
      SELECT @VALIDSTART = CASE WHEN DayId > @DayId THEN  DATEADD(day, DATEDIFF(day, -1, @BatchDate), CAST(starttime AS datetime))
         WHEN DayId < @DayId THEN   DATEADD(day, DATEDIFF(day, 1, @BatchDate), CAST(starttime AS datetime)) 
              ELSE
               DATEADD(day, DATEDIFF(day, 0, @BatchDate), CAST(starttime AS datetime)) END      ,
       @VALIDEND =  CASE WHEN ((DayId > @DayId AND EndTime > StartTime) OR (DayId = @DayId AND (EndTime = StartTime OR EndTime < StartTime))) THEN 
                DATEADD(day, DATEDIFF(day,-1, @BatchDate), CAST(EndTime AS datetime))
         WHEN (DayId < @DayId AND (EndTime < StartTime OR EndTime = StartTime)) THEN 
                 DATEADD(day, DATEDIFF(day, 0, @BatchDate), CAST(EndTime AS datetime))
         WHEN (DayId > @DayId AND (EndTime < StartTime OR EndTime = StartTime)) THEN 
                   DATEADD(day, DATEDIFF(day,-2, @BatchDate), CAST(EndTime AS datetime))       
                 ELSE
                DATEADD(day, DATEDIFF(day, 0, @BatchDate), CAST(EndTime AS datetime)) 
                END,@ShiftId = ShiftId,@ShiftName = ShiftName,@RealDayId = DayId,@ShiftTargetProd = TargetProduction
         FROM @shiftdata_temp WHERE SNo = @Rollingcount 

         INSERT INTO @Result(StartDate,EndDate,ShiftId,ShiftName,DayID,TargetProduction)
         SELECT @VALIDSTART,@VALIDEND,@ShiftId,@ShiftName,@RealDayId,@ShiftTargetProd

          
  

 
    SELECT DISTINCT @StartTime = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(StartDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(StartDate AS time)) AS DateTime)),
    @EndTime = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(EndDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(EndDate AS time)) AS DateTime)),
    @ShiftId = ShiftId,@ShiftName = ShiftName,@DayId = DayID,@ShiftTargetProd = TargetProduction  FROM @Result
   WHERE @BatchDateWithOutUTC BETWEEN StartDate AND EndDate

    SELECT @LabourShift = @ShiftId

     IF(@StartTime IS NULL AND @EndTime IS NULL)
    BEGIN
 SELECT @ShiftId = NULL,@ShiftName = NULL
    END
   
    IF(COUNT(@ShiftId) <> 1)      ---NO shift Timings
    BEGIN
 
     SELECT TOP 1 @StartTime = SD.StartTime, @EndTime= SD.EndTime FROM 
	 TCD.ShiftData SD WITH (NOLOCK)  
    WHERE SD.DayId = @DayId AND sd.Is_Deleted=0 
     AND   cast(@BatchDateWithOutUTC  AS time) BETWEEN SD.StartTime AND SD.EndTime
  ORDER BY SD.StartTime DESC
   
IF( @StartTime IS NULL)
	BEGIN
	    SELECT TOP 1 @StartTime = SD.EndTime FROM 
	   TCD.ShiftData SD WITH (NOLOCK)  
	   WHERE SD.DayId = @DayId AND sd.Is_Deleted=0 
	   AND  SD.EndTime <= cast(@BatchDateWithOutUTC  AS time)
	   ORDER BY SD.StartTime DESC

	  IF (@StartTime IS NULL)
	   BEGIN
		  SET @StartTime= CAST ( '00:00:00.000' AS TIME)
		   
	   END
	END
     
	IF (@EndTime IS  NULL)
	BEGIN
	     SELECT TOP 1 @EndTime = SD.StartTime FROM 
	   TCD.ShiftData SD WITH (NOLOCK)  
	   WHERE SD.DayId = @DayId AND sd.Is_Deleted=0 
	   AND  SD.StartTime>= cast(@BatchDateWithOutUTC  AS time)  
	   ORDER BY SD.StartTime ASC

	   IF (@EndTime IS NULL)
	   BEGIN
	    SET @EndTime = CAST ( '23:59:59.999' AS TIME)
	   END	   

	END

     
     IF(COUNT(@StartTime) <> 1)
        BEGIN
        SELECT @StartTime = CAST(dateadd(DAY, datediff(day, 0, @BatchDateWithOutUTC),0) AS dateTime)
        END
        ELSE
        BEGIN
        SELECT @StartTime = DATEADD(day, DATEDIFF(day, 0, @BatchDateWithOutUTC),@StartTime)
        END

        IF(COUNT(@EndTime) <> 1)
        BEGIN
        SELECT @EndTime =  CAST(DATEADD(s, -1, DATEADD(day, 1,CONVERT(DATETIME, CONVERT(DATE, @BatchDateWithOutUTC)))) AS dateTime)
        END
        ELSE
        BEGIN
        SELECT @EndTime = DATEADD(day, DATEDIFF(day, 0, @BatchDateWithOutUTC),@EndTime)
        END

      SET @StartTime = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@StartTime AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@StartTime AS time)) AS DateTime))
      SET @EndTime =  dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@EndTime AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@EndTime AS time)) AS DateTime))    

    END     
    
	IF EXISTS (SELECT COUNT(1) FROM TCD.TARGETPRODUCTIONDETAILS AS T WITH (NOLOCK) 
	INNER JOIN  tcd.shiftdata sd on T.ShiftId=sd.ShiftId and T.DayId=sd.DayId and  sd.Is_Deleted=0
	WHERE T.DayId = @DayId AND T.ShiftId = @ShiftId
	  AND  cast(T.RecordedDate AS date) =CAST( @BatchDateWithOutUTC AS DATE)
	 AND @BatchDateWithOutUTC  BETWEEN  cast (  DATEADD(dd, 0, DATEDIFF(dd, 0, @BatchDateWithOutUTC)) AS datetime) + cast(  sd.StartTime as datetime)
			 and cast (  DATEADD(dd, 0, DATEDIFF(dd, 0, @BatchDateWithOutUTC)) AS datetime)+ cast(    sd.StartTime as datetime)
				 + cast( CONVERT(time(7),DATEADD(s, DATEDIFF(s,sd.StartTime,sd.EndTime),'00:00:00')) as datetime))
    BEGIN
    SELECT @ShiftTargetProd = T.TargetProduction 
		FROM TCD.TARGETPRODUCTIONDETAILS T  WITH (NOLOCK)
		  INNER JOIN  tcd.shiftdata sd on T.ShiftId=sd.ShiftId and T.DayId=sd.DayId and  sd.Is_Deleted=0
		WHERE T.DayId = @DayId AND T.ShiftId = @ShiftId
		  AND  cast(T.RecordedDate AS date) =CAST( @BatchDateWithOutUTC AS DATE)
		  AND @BatchDateWithOutUTC  between  cast (  DATEADD(dd, 0, DATEDIFF(dd, 0, @BatchDateWithOutUTC)) AS datetime) + cast(  sd.StartTime as datetime)
			 AND cast (  DATEADD(dd, 0, DATEDIFF(dd, 0, @BatchDateWithOutUTC)) AS datetime)+ cast(    sd.StartTime as datetime)
				 + cast( CONVERT(time(7),DATEADD(s, DATEDIFF(s,sd.StartTime,sd.EndTime),'00:00:00')) as datetime)
    END
    
    
   IF NOT EXISTS (SELECT 1 FROM [TCD].ProductionShiftData WITH (NOLOCK) WHERE StartDateTime = @StartTime )
   BEGIN
    
    INSERT INTO [TCD].ProductionShiftData (
             [ShiftName],
             [StartDateTime],
             [EndDateTime],
             [TargetProduction],
    [EcolabAccountNumber]
            ) 
     SELECT  --CASE WHEN COUNT(@Count) <> 1 THEN 1 ELSE @Count + 1 END,
        CASE WHEN COUNT(@ShiftName) <> 1 THEN 'No Shift' ELSE @ShiftName END,
        @StartTime,
        @EndTime,
       isnull( @ShiftTargetProd,0),
  @EcolabAccountNumber

 -- SET @BatchDate = dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@BatchDate AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(@BatchDate AS time)) AS DateTime))
 END
END


SELECT TCD.productionshiftdata.ShiftId,TCD.productionshiftdata.ShiftName,TCD.productionshiftdata.StartDateTime
  FROM tcd.productionshiftdata 
  where @BatchDate between StartDateTime AND EndDateTime

  END 

END