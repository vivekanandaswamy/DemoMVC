CREATE PROCEDURE [TCD].GetFomulasForNavigationMenu
(
			@EcoalabAccountNumber  NVARCHAR(25) = NULL
)
AS
BEGIN
	
	SET NOCOUNT ON;

			SELECT ProgramId, Name 
			FROM [TCD].ProgramMaster 
			WHERE Is_Deleted <> 1
			AND EcolabAccountNumber = '1'
END
GO
