﻿/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_DeleteTcpMessage]                                         

Purpose:				To delete the tcp message

Parameters:				@Id - holds the particular id to be deleted.
																																		
###################################################################################################                                           
*/
CREATE PROCEDURE [TCD].[DeleteTcpMessage]
	@Id int	
AS
BEGIN
	SET NOCOUNT ON
	 IF EXISTS (SELECT 1 FROM [TCD].[TcpMessageQueue] WHERE Id = @Id) 
	  BEGIN
  
		DELETE FROM [TCD].[TcpMessageQueue] WHERE Id =@Id
	
	SET NOCOUNT OFF
	END
END
