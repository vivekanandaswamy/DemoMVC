﻿CREATE PROCEDURE [TCD].[GetUnUsedPlantChemicalListByGroupId] 
    @WasherGroupId            int                =        NULL
,    @EcolabAccountNumber    nvarchar(25)    =        NULL
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

	DECLARE @RegionId INT = NULL
	
	SELECT 
	@RegionId = RegionID FROM Plant 
	WHERE 
	EcolabAccountNumber = @EcolabAccountNumber;

	IF @WasherGroupId = 0
	BEGIN
		SET @WasherGroupId = NULL
	END

   ;with CTE
	AS (
	SELECT distinct wg.WasherGroupId, ms.ControllerId, ControllerWasherGroupID.WasherGroupId AS ChildWGID
	, ControllerWasherGroupID.ControllerId AS ChildControllerID
	FROM TCD.WasherGroup wg
	INNER JOIN TCD.MachineGroup mg 
	ON mg.Id = wg.WasherGroupId
	AND mg.EcolabAccountNumber = wg.EcolabAccountNumber
	AND mg.Is_Deleted = 'False'
	INNER JOIN TCD.MachineSetup ms 
	ON wg.WasherGroupId = ms.GroupId
	AND ms.EcoalabAccountNumber = wg.EcolabAccountNumber
	AND ms.IsDeleted = 'False'
	CROSS APPLY
	(SELECT  wg2.WasherGroupId, ms2.ControllerId 
	FROM TCD.WasherGroup wg2
	INNER JOIN TCD.MachineGroup mg2 
	ON mg2.Id = wg2.WasherGroupId
	AND mg2.EcolabAccountNumber = wg2.EcolabAccountNumber
	AND mg2.Is_Deleted = 'False'
	INNER JOIN TCD.MachineSetup ms2 
	ON wg2.WasherGroupId = ms2.GroupId
	AND wg2.EcolabAccountNumber = ms2.EcoalabAccountNumber
	AND ms2.IsDeleted = 'False'
	WHERE ms2.ControllerId = ms.ControllerId
	) AS ControllerWasherGroupID
	WHERE wg.WasherGroupId = ISNULL(@WasherGroupId, WG.WasherGroupId)
	AND wg.EcolabAccountNumber = @EcolabAccountNumber
	)
	,
	CTE_Level2 AS (
	SELECT distinct wg.WasherGroupId, ms.ControllerId, ControllerWasherGroupID.WasherGroupId AS ChildWGID
	, ControllerWasherGroupID.ControllerId AS ChildControllerID
	FROM TCD.WasherGroup wg
	INNER JOIN TCD.MachineGroup mg 
	ON mg.Id = wg.WasherGroupId
	AND mg.EcolabAccountNumber = wg.EcolabAccountNumber
	AND mg.Is_Deleted = 'False'
	INNER JOIN TCD.MachineSetup ms 
	ON wg.WasherGroupId = ms.GroupId
	AND ms.EcoalabAccountNumber = wg.EcolabAccountNumber
	AND ms.IsDeleted = 'False'
	CROSS APPLY
	(SELECT  wg2.WasherGroupId, ms2.ControllerId 
	FROM TCD.WasherGroup wg2
	INNER JOIN TCD.MachineGroup mg2 
	ON mg2.Id = wg2.WasherGroupId
	AND mg2.EcolabAccountNumber = wg2.EcolabAccountNumber
	AND mg2.Is_Deleted = 'False'
	INNER JOIN TCD.MachineSetup ms2 
	ON wg2.WasherGroupId = ms2.GroupId
	AND wg2.EcolabAccountNumber = ms2.EcoalabAccountNumber
	AND ms2.IsDeleted = 'False'
	WHERE ms2.ControllerId = ms.ControllerId
	) AS ControllerWasherGroupID
	WHERE wg.WasherGroupId IN (
	select ChildWGID from CTE)
	AND wg.EcolabAccountNumber = @EcolabAccountNumber
	)
	,
	CTE_Level3 AS (
	SELECT distinct wg.WasherGroupId, ms.ControllerId, ControllerWasherGroupID.WasherGroupId AS ChildWGID
	, ControllerWasherGroupID.ControllerId AS ChildControllerID
	FROM TCD.WasherGroup wg
	INNER JOIN TCD.MachineGroup mg 
	ON mg.Id = wg.WasherGroupId
	AND mg.EcolabAccountNumber = wg.EcolabAccountNumber
	AND mg.Is_Deleted = 'False'
	INNER JOIN TCD.MachineSetup ms 
	ON wg.WasherGroupId = ms.GroupId
	AND ms.EcoalabAccountNumber = wg.EcolabAccountNumber
	AND ms.IsDeleted = 'False'
	CROSS APPLY
	(SELECT  wg2.WasherGroupId, ms2.ControllerId 
	FROM TCD.WasherGroup wg2
	INNER JOIN TCD.MachineGroup mg2 
	ON mg2.Id = wg2.WasherGroupId
	AND mg2.EcolabAccountNumber = wg2.EcolabAccountNumber
	AND mg2.Is_Deleted = 'False'
	INNER JOIN TCD.MachineSetup ms2 
	ON wg2.WasherGroupId = ms2.GroupId
	AND wg2.EcolabAccountNumber = ms2.EcoalabAccountNumber
	AND ms2.IsDeleted = 'False'
	WHERE ms2.ControllerId = ms.ControllerId
	) AS ControllerWasherGroupID
	WHERE wg.WasherGroupId IN (
	select ChildWGID from CTE_Level2)
	AND wg.EcolabAccountNumber = @EcolabAccountNumber
	)
 
	SELECT DISTINCT pm.ProductId, 
			pm2.Name,
			pm.Cost,
			pm.IncludeCI
	from CTE_Level3 WG
	INNER JOIN TCD.ConduitController cc ON WG.ChildControllerID = cc.ControllerId AND cc.IsDeleted = 'False'
	INNER JOIN tcd.ControllerEquipmentSetup ces ON cc.ControllerId = ces.ControllerId
	RIGHT JOIN tcd.ProductdataMapping pm ON ces.ProductId = pm.ProductID AND pm.EcolabAccountNumber = ces.EcoLabAccountNumber
	INNER JOIN TCD.ProductMaster pm2 ON pm2.ProductId = pm.ProductId
	WHERE ces.ProductId IS NULL
	AND pm.EcolabAccountNumber = @EcolabAccountNumber
	AND pm2.SKU NOT IN ('0', '-1')
	AND pm.Is_Deleted = 'False'
	AND pm2.RegionId = @RegionId
	ORDER BY pm.ProductID

    SET NOCOUNT OFF
END
GO