﻿CREATE PROCEDURE [TCD].[GetLocalizationData]
	-- Add the parameters for the stored procedure here
	 @KEY Varchar(200), @LANGUAGEID INT, @RESOURCEID INT = NULL, @VALUE VARCHAR(200), @LOCALE VARCHAR(200)
	
AS
BEGIN 
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
		
	If Not Exists(Select 1 From [TCD].ResourceKeyMaster Where KeyName = @KEY)
	Begin
		Insert Into [TCD].ResourceKeyMaster(KeyName)  Values(@KEY)
	End

	If Not Exists(Select 1 From [TCD].ResourceKeyValue Where KeyName = @KEY AND languageID = @LANGUAGEID)
	Begin
		Insert Into [TCD].ResourceKeyValue(KeyName, Value, languageID) Values(@KEY, @VALUE, @LANGUAGEID)
	End
	ELSE
	BEGIN
		Update [TCD].ResourceKeyValue Set Value = @VALUE Where KeyName = @KEY AND languageID = @LANGUAGEID 
	END

	select * from [TCD].ResourceKeyValue Where KeyName = @KEY AND languageID = @LANGUAGEID
END