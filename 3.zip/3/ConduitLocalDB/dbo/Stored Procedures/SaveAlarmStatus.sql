﻿CREATE	PROCEDURE	[TCD].[SaveAlarmStatus]	(
					@AlarmMachineMappingId					INT
				,	@ControllerModelId						INT
				,	@ControllerTypeId						INT
				,	@MachineNumber							INT		
				,	@Active									BIT
				
				,	@DeleteFlag								BIT			=			'FALSE'	--DO NOT SET THIS (to TRUE) UNLESS DELETE IS INTENDED
				,	@UserId									INT			=			NULL
				,	@EcolabAccountNumber					NVARCHAR(25)
				,	@WasherId								INT
				)
AS 
BEGIN 


SET	NOCOUNT	ON

DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''



IF	(	@DeleteFlag	=	'TRUE'	)
	BEGIN
			DELETE A
			FROM [TCD].AlarmStatus A
			INNER JOIN [TCD].[AlarmGroupMsterVsControllerModelType] AGM_V_CMT ON AGM_V_CMT.AlarmGroupMsterVsControllerModelTypeId = A.AlarmGroupMsterVsControllerModelTypeId
			INNER JOIN [TCD].[ControllerModelControllerTypeMapping] CMCTM ON CMCTM.Id = AGM_V_CMT.ControllerModelTypeId
			WHERE
			CMCTM.ControllerModelId		= @ControllerModelId
			AND
			CMCTM.ControllerTypeId		= @ControllerTypeId
			AND
			A.MachineNumber				= @MachineNumber
			AND
			A.EcolabAccountNumber		= @EcolabAccountNumber
			AND 
			A.WasherId					= @WasherId
			SET	@ErrorId	=	@@ERROR

			IF	(@ErrorId	<>	0)
			BEGIN
				SET		@ErrorMessage				=			N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred overwriting alarm data.'
				--GOTO	Errorhandler
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
			END

	END
ELSE
	BEGIN
		INSERT INTO	[TCD].AlarmStatus (
					AlarmGroupMsterVsControllerModelTypeId
				,	MachineNumber
				,	Active
				,	LastModifiedByuserId
				,	EcolabAccountNumber
				,	WasherId
				)
			SELECT
					@AlarmMachineMappingId	AS			AlarmGroupMsterVsControllerModelTypeId
				,	@MachineNumber			AS			MachineNumber
				,	@Active					AS			Active
				,	@UserId					AS			UserId
				,	@EcolabAccountNumber	AS			EcolabAccountNumber
				,	@WasherId				AS			WasherId
		--check for any error
		SET	@ErrorId	=	@@ERROR

		IF	(@ErrorId	<>	0)
		BEGIN
			SET		@ErrorMessage			=			N'ErrorId: ' + CAST(@ErrorId AS NVARCHAR(10)) + N' Error occurred overswriting alarm data.'
			--GOTO	Errorhandler
			RAISERROR	(@ErrorMessage, 16, 1)
			SET	@ReturnValue	=	-1
			RETURN	(@ReturnValue)
		END
	END


IF	(	@ErrorId	=	0	)
	BEGIN
		--GOTO	ExitModule
		RETURN	(@ReturnValue)
	END

SET	NOCOUNT	OFF
RETURN	(@ReturnValue)

END