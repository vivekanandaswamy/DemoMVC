﻿/*	
Purpose					:	To save details of a tunnel compartment from the Tunnel setup screen --> compartments tab...

History					:
Oct. 2014		dfozdar@allianceglobalservice.com		initial version

*/

CREATE	PROCEDURE	[TCD].[SaveTunnelCompartment]
					@EcoLabAccountNumber					NVARCHAR(25)
				,	@TunnelId								INT
				,	@CompartmentNumber						TINYINT

				,	@WashStepId								INT					=			NULL
				,	@WaterinletDrainId						TINYINT
				,	@WaterFlowId							SMALLINT
				,	@WaterLevel								NUMERIC(8, 2)
				,	@TemperatureControlByPMR				BIT
				,	@UsePressExtractWater					BIT
				,	@SplitCompartment						BIT
				,	@RecycledWaterInlet						BIT
				,	@Steam									BIT
				,	@IterationPoint							BIT

				,	@EquipmentAssociation					[TCD].ControllerEquipment			READONLY

				,	@UserId									INT
				--	Adding these 3 param as part of re-factoring for integration with Synch/Configurator
				,	@OutputTunnelCompartmentId				INT			=			NULL	OUTPUT
				,	@LastModifiedTimestampAtCentral			DATETIME	=			NULL		--Nullable for local call; Synch/Central call will have to pass this -
																								--else, it will be treated as a local call
				,	@OutputLastModifiedTimestampAtLocal		DATETIME	=			NULL	OUTPUT

AS
BEGIN

SET	NOCOUNT	ON


DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''

	,	@ControllerId					INT				=			NULL
	,	@NumberOfComp					TINYINT			=			NULL
	,	@TunnelCompartmentId			SMALLINT		=			NULL

	,	@CurrentUTCTime					DATETIME				=			GETUTCDATE()
--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
SET		@OutputLastModifiedTimestampAtLocal						=			@CurrentUTCTime
SET		@OutputTunnelCompartmentId								=			ISNULL(@OutputTunnelCompartmentId, NULL)			--SQLEnlight

DECLARE
		@OutputList						AS	TABLE		(
		TunnelCompartmentId					INT
	,	LastModifiedTimestamp				DATETIME
	)

--Get the ControllerId for the Tunnel...
SELECT	@ControllerId					=			ISNULL(MS.ControllerId, -1)
	,	@NumberOfComp					=			ISNULL(MS.NumberOfComp, -1)
FROM	[TCD].MachineSetup					MS
JOIN	[TCD].ConduitController				CC												--join on valid controller
	ON	MS.ControllerId					=			CC.ControllerId
	AND	MS.EcoalabAccountNumber			=			CC.EcoalabAccountNumber
WHERE	MS.EcoalabAccountNumber			=			@EcoLabAccountNumber
	AND	MS.WasherId						=			@TunnelId
	AND	MS.IsTunnel						=			'TRUE'
	AND	MS.IsDeleted					=			'FALSE'
	AND	CC.IsDeleted					=			'FALSE'

--if we didn't get a valid Controller, error-out
IF	(@ControllerId	=	-1)
	BEGIN
				SET		@ErrorId						=			51020
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Could not determine the Controller for the specified tunnel.'
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
	END


--CompartmentNumber
IF	(@CompartmentNumber	>	@NumberOfComp)
	BEGIN
				SET		@ErrorId						=			51021
				SET		@ErrorMessage					=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Invalid Compartment Number specified for the tunnel.'
				RAISERROR	(@ErrorMessage, 16, 1)
				SET	@ReturnValue	=	-1
				RETURN	(@ReturnValue)
	END


--Add, if not already defined
IF	NOT	EXISTS	(	SELECT	1	FROM	[TCD].TunnelCompartment	WHERE	WasherId	=	@TunnelId	AND	CompartmentNumber	=	@CompartmentNumber	)
	BEGIN
			BEGIN	TRAN

			BEGIN	TRY
						INSERT	[TCD].TunnelCompartment	(
								WasherId					,EcoLabAccountNumber	,CompartmentNumber	,WashStepId				,WaterInletDrainId	,WaterFlowId			,WaterLevel
							,	TemperatureControlByPMR		,UsePressExtractWater	,SplitCompartment	,RecycledWaterInlet		,Steam				,IterationPoint			,LastModifiedByUserId
						--**	Adding a part of integration with Synch./Central	-->
						,	LastModifiedTime, MyServiceLastSynchTime
						)
						OUTPUT	inserted.TunnelCompartmentId			AS			TunnelCompartmentId
							,	inserted.LastModifiedTime				AS			LastModifiedTime
						INTO	@OutputList	(
								TunnelCompartmentId
							,	LastModifiedTimestamp
							)
						--**	<--
						VALUES	(@TunnelId					,@EcoLabAccountNumber	,@CompartmentNumber	,@WashStepId			,@WaterinletDrainId	,@WaterFlowId	,@WaterLevel
							,	@TemperatureControlByPMR	,@UsePressExtractWater	,@SplitCompartment	,@RecycledWaterInlet	,@Steam				,@IterationPoint,@UserId
							--Synch./Central integration additions
							,	@CurrentUTCTime	, @CurrentUTCTime
							)

						--get the TCId of the newly generated record
						SET	@TunnelCompartmentId	=	SCOPE_IDENTITY()
			END	TRY
			BEGIN	CATCH
						SET	@ErrorId				=	ERROR_NUMBER()
						SET	@ErrorMessage			=	ERROR_MESSAGE()

						IF	(@@TRANCOUNT	>	0)
							BEGIN
								ROLLBACK
							END

						SET		@ErrorMessage		=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + ISNULL(@ErrorMessage,	N': Error occurred saving Compartment details .')
						RAISERROR	(@ErrorMessage, 16, 1)
						SET	@ReturnValue	=	-1
						RETURN	(@ReturnValue)
			END	CATCH

			--save Equipment association
			IF	EXISTS	(SELECT	1	FROM	@EquipmentAssociation)
				BEGIN
					BEGIN	TRY
								INSERT	[TCD].TunnelCompartmentEquipmentMapping	(
										EcoLabAccountNumber	,TunnelCompartmentId	,ControllerEquipmentSetupId	,Is_Deleted	,LastModifiedByUserId , MyServiceCmpmtDsgDvcguid	)
								SELECT	@EcoLabAccountNumber					AS			EcoLabAccountNumber
									,	@TunnelCompartmentId					AS			TunnelCompartmentId
									,	A.ControllerEquipmentSetupId			AS			ControllerEquipmentSetupId
									,	'FALSE'									AS			Is_Deleted
									,	@UserId									AS			LastModifiedByUserId
									,	A.MyServiceCmpmtDsgDvcguid				As			MyServiceCmpmtDsgDvcguid
								FROM	@EquipmentAssociation					A
								WHERE	A.DeleteFlag							=			'FALSE'

								--commit the tran now and exit module
								COMMIT

								SELECT	TOP	1
										@OutputTunnelCompartmentId			=			O.TunnelCompartmentId
								FROM	@OutputList							O

								RETURN	0
					END	TRY
					BEGIN	CATCH
								SET	@ErrorId				=	ERROR_NUMBER()
								SET	@ErrorMessage			=	ERROR_MESSAGE()

								IF	(@@TRANCOUNT	>	0)
									BEGIN
										ROLLBACK
									END

								SET		@ErrorMessage		=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + ISNULL(@ErrorMessage,	N': Error occurred saving Compartment-Equipment details .')
								RAISERROR	(@ErrorMessage, 16, 1)
								SET	@ReturnValue	=	-1
								RETURN	(@ReturnValue)
					END	CATCH
				END
			ELSE	--If no Equipment association to be saved, commit the INSERT above
				BEGIN
					IF	(@@TRANCOUNT	>	0)
						BEGIN
							COMMIT

							SELECT	TOP	1
									@OutputTunnelCompartmentId			=			O.TunnelCompartmentId
							FROM	@OutputList							O

							RETURN	0
						END
				END

	END
ELSE		--Update already defined Compartment details
	BEGIN
			--Get the TCId first...
			SELECT	@TunnelCompartmentId					=			TC.TunnelCompartmentId
			FROM	[TCD].TunnelCompartment					TC
			WHERE	TC.EcoLabAccountNumber					=			@EcoLabAccountNumber
				AND	TC.WasherId								=			@TunnelId
				AND	TC.CompartmentNumber					=			@CompartmentNumber

			IF	(@TunnelCompartmentId	IS	NULL)
				BEGIN
						SET		@ErrorId					=			51022
						SET		@ErrorMessage				=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Could not determine the Compartment provided for the specified tunnel.'
						RAISERROR	(@ErrorMessage, 16, 1)
						SET	@ReturnValue	=	-1
						RETURN	(@ReturnValue)
				END


			--If the call is not local, check that the LastModifiedTime matches with the central
			IF	(
					@LastModifiedTimestampAtCentral			IS NOT	NULL
				AND	NOT	EXISTS	(	SELECT	1
									FROM	TCD.[TunnelCompartment]	TC
									WHERE	TC.EcolabAccountNumber	=	@EcolabAccountNumber
										AND	TC.TunnelCompartmentId	=	@TunnelCompartmentId
										AND	TC.LastModifiedTime		=	@LastModifiedTimestampAtCentral
								)
				)
				BEGIN
						SET			@ErrorId						=	60000
						SET			@ErrorMessage					=	N'' + CAST(@ErrorId AS NVARCHAR(10)) + N': Record not in-synch between plant and central.'
						RAISERROR	(@ErrorMessage, 16, 1)
						SET			@ReturnValue					=	-1
						RETURN		(@ReturnValue)
				END
				
			--Proceed, since it's either a local call or Synch. call with synch. time matching
			BEGIN	TRAN

			BEGIN	TRY
						UPDATE	TC
							SET	TC.WashStepId					=			@WashStepId
							,	TC.WaterInletDrainId			=			@WaterinletDrainId
							,	TC.WaterFlowId					=			@WaterFlowId
							,	TC.WaterLevel					=			@WaterLevel
							,	TC.TemperatureControlByPMR		=			@TemperatureControlByPMR
							,	TC.UsePressExtractWater			=			@UsePressExtractWater
							,	TC.SplitCompartment				=			@SplitCompartment
							,	TC.RecycledWaterInlet			=			@RecycledWaterInlet
							,	TC.Steam						=			@Steam
							,	TC.IterationPoint				=			@IterationPoint
							,	TC.LastModifiedByUserId			=			@UserId
						--**	Adding a part of integration with Synch./Central	-->
							,	TC.LastModifiedTime				=			@CurrentUTCTime
							,	TC.MyServiceLastSynchTime		=			@CurrentUTCTime
						OUTPUT	inserted.TunnelCompartmentId	AS			TunnelCompartmentId
							,	inserted.LastModifiedTime		AS			LastModifiedTime
						INTO	@OutputList	(
								TunnelCompartmentId
							,	LastModifiedTimestamp
							)
						--**	<--
						FROM	[TCD].TunnelCompartment			TC
            WHERE	TC.WasherId						=			@TunnelId
            AND	TC.CompartmentNumber			=			@CompartmentNumber
            END	TRY
            BEGIN	CATCH
            SET	@ErrorId						=			ERROR_NUMBER()
            SET	@ErrorMessage					=			ERROR_MESSAGE()

            IF	(@@TRANCOUNT	>	0)
            BEGIN
            ROLLBACK
            END

            SET		@ErrorMessage				=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + ISNULL(@ErrorMessage,	N': Error occurred saving Compartment details .')
            RAISERROR	(@ErrorMessage, 16, 1)
            SET	@ReturnValue	=	-1
            RETURN	(@ReturnValue)
            END	CATCH


            --save Equipment association
            IF	EXISTS	(SELECT	1	FROM	@EquipmentAssociation)
            BEGIN
            BEGIN	TRY
            --first soft-delete...
            --UPDATE	TCEM
            --	SET	TCEM.Is_Deleted							=			'TRUE'
            --	,	TCEM.LastModifiedByUserId				=			@UserId
            --FROM	[TCD].TunnelCompartmentEquipmentMapping		TCEM
            --JOIN	@EquipmentAssociation					EA
            --	ON	TCEM.ControllerEquipmentSetupId			=			EA.ControllerEquipmentSetupId
            --WHERE	TCEM.TunnelCompartmentId				=			@TunnelCompartmentId
            --	AND	TCEM.Is_Deleted							=			'FALSE'
            --	AND	EA.DeleteFlag							=			'TRUE'

            --INSERT	[TCD].TunnelCompartmentEquipmentMapping	(
            --		EcoLabAccountNumber	,TunnelCompartmentId	,ControllerEquipmentSetupId	,Is_Deleted	,LastModifiedByUserId	)
            --SELECT	@EcoLabAccountNumber					AS			EcoLabAccountNumber
            --	,	@TunnelCompartmentId					AS			TunnelCompartmentId
            --	,	EA.ControllerEquipmentSetupId			AS			ControllerEquipmentSetupId
            --	,	'FALSE'									AS			Is_Deleted
            --	,	@UserId									AS			LastModifiedByUserId
            --FROM	@EquipmentAssociation					EA
            --LEFT JOIN
            --		[TCD].TunnelCompartmentEquipmentMapping		TCEM
            --	ON	TCEM.TunnelCompartmentId				=			@TunnelCompartmentId
            --	AND	TCEM.Is_Deleted							=			'FALSE'
            --	AND	TCEM.ControllerEquipmentSetupId			=			EA.ControllerEquipmentSetupId
            --WHERE	EA.DeleteFlag							=			'FALSE'
            --	AND	TCEM.ControllerEquipmentSetupId			IS			NULL


            --commit the tran now and exit module

            ;
            MERGE	[TCD].TunnelCompartmentEquipmentMapping		AS			TARGET
            USING	@EquipmentAssociation						AS			SOURCE
            ON	TARGET.ControllerEquipmentSetupId			=			SOURCE.ControllerEquipmentSetupId
            AND	TARGET.TunnelCompartmentId					=			@TunnelCompartmentId
            AND	TARGET.EcolabAccountNumber					=			@EcolabAccountNumber
            WHEN	MATCHED	THEN
            UPDATE
            SET	TARGET.Is_Deleted					=			SOURCE.DeleteFlag,
				Target.MyServiceCmpmtDsgDvcguid		=			 SOURCE.MyServiceCmpmtDsgDvcguid
            WHEN	NOT MATCHED	BY	TARGET	THEN
            INSERT	(EcolabAccountNumber	,TunnelCompartmentId	,ControllerEquipmentSetupId			,Is_Deleted	,LastModifiedByUserId	,MyServiceCmpmtDsgDvcguid		)
            VALUES	(@EcolabAccountNumber	,@TunnelCompartmentId	,SOURCE.ControllerEquipmentSetupId	,'FALSE'	,@UserId		, SOURCE.MyServiceCmpmtDsgDvcguid				)
            ;


            UPDATE tdpm
            SET tdpm.Quantity = 0
            FROM TCD.TunnelDosingSetup tds
            INNER JOIN TCD.TunnelDosingProductMapping tdpm
            ON tdpm.TunnelDosingSetupId = tds.TunnelDosingSetupId
            AND tdpm.EcoLabAccountNumber = tds.EcolabAccountNumber
            INNER JOIN TCD.TunnelProgramSetup tps
            ON tps.TunnelProgramSetupId = tds.TunnelProgramSetupId
            AND tps.EcolabAccountNumber = tds.EcolabAccountNumber
            AND tps.WasherGroupId = tds.GroupId
            INNER JOIN TCD.WasherGroup wg
            ON wg.WasherGroupId = TPS.WasherGroupId
            AND wg.EcolabAccountNumber = TPS.EcolabAccountNumber
            INNER JOIN TCD.MachineSetup ms
            ON ms.GroupId = wg.WasherGroupId
            AND ms.EcoalabAccountNumber = wg.EcolabAccountNumber
            INNER JOIN TCD.TunnelCompartment tc
            ON tc.EcoLabAccountNumber = ms.EcoalabAccountNumber
            AND tc.WasherId = ms.WasherId
            INNER JOIN TCD.TunnelCompartmentEquipmentMapping tcem
            ON tcem.EcoLabAccountNumber = tc.EcoLabAccountNumber
            AND tcem.ControllerEquipmentSetupId = tdpm.ControllerEquipmentSetupId
            AND tc.TunnelCompartmentId = tcem.TunnelCompartmentId
            AND tcem.Is_Deleted = 'True'
            WHERE ms.WasherId = @TunnelId
            AND wg.EcolabAccountNumber = @EcoLabAccountNumber

            COMMIT

            SELECT	TOP	1
            @OutputTunnelCompartmentId			=			O.TunnelCompartmentId
            FROM	@OutputList							O

            RETURN	0
            END	TRY
            BEGIN	CATCH
            SET	@ErrorId				=	ERROR_NUMBER()
            SET	@ErrorMessage			=	ERROR_MESSAGE()

            IF	(@@TRANCOUNT	>	0)
            BEGIN
            ROLLBACK
            END

            SET		@ErrorMessage		=			N'' + CAST(@ErrorId AS NVARCHAR(10)) + ISNULL(@ErrorMessage,	N': Error occurred saving Compartment-Equipment details .')
            RAISERROR	(@ErrorMessage, 16, 1)
            SET	@ReturnValue	=	-1
            RETURN	(@ReturnValue)
            END	CATCH
            END
            ELSE	--If no Equipment association to be saved, commit the INSERT above
            BEGIN
            IF	(@@TRANCOUNT	>	0)
            BEGIN
            COMMIT

            SELECT	TOP	1
            @OutputTunnelCompartmentId			=			O.TunnelCompartmentId
            FROM	@OutputList							O

            RETURN	0
            END
            END
            END



            RETURN	(@ReturnValue)

            END
            