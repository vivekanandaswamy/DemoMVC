﻿CREATE PROCEDURE [TCD].[GetTunnelWashStepProductsResync]
					@EcoLabAccountNumber					NVARCHAR(25)

				,	@CompartmentNumber							INT

				,	@GroupId									INT

				,	@DosingSetupId								INT

AS

BEGIN

SET	NOCOUNT	ON
DECLARE @ProgramNumber INT

IF EXISTS (SELECT 1 FROM TCD.TunnelDosingProductMapping tdpm WHERE tdpm.TunnelDosingSetupId = @DosingSetupId AND tdpm.EcoLabAccountNumber = @EcoLabAccountNumber)
BEGIN
	SELECT 
			 tdpm.TunnelDosingProductMappingId 
		  ,	 tdpm.EcoLabAccountNumber
		  ,   tdpm.TunnelDosingSetupId
		  ,	 tdpm.ControllerEquipmentSetupId
		  ,	 tdpm.ProductId 
		 ,	 pm.Name
		  ,	 tdpm.Quantity 
		  ,	 tdpm.DelayTime
		  ,	 tdpm.CompartmentNumber
		  ,	 tdpm.GroupId
		  ,	 tdpm.LastModifiedTime
		  ,	 tdpm.MyServiceFrmulaStpDsgDvcGuid
	FROM TCD.TunnelDosingProductMapping tdpm 
	INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.ControllerEquipmentSetupId = tdpm.ControllerEquipmentSetupId AND ces.EcoLabAccountNumber = tdpm.EcoLabAccountNumber

	INNER JOIN tcd.ProductMaster pm ON pm.ProductId = ces.ProductId
	WHERE tdpm.EcoLabAccountNumber = @EcoLabAccountNumber AND tdpm.GroupId = @GroupId AND tdpm.TunnelDosingSetupId = @DosingSetupId
END	

SET	NOCOUNT	OFF

END