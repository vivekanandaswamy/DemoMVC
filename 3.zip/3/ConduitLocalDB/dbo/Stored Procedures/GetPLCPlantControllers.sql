CREATE PROCEDURE [TCD].[GetPLCPlantControllers]

(@ecolabAccountNumber NVARCHAR(25)
)

AS

BEGIN
SET NOCOUNT ON
		SELECT	Ctrl.ControllerId
			,Ctrl.EcoalabAccountNumber
			,CT.Name[ControllerType]
			,Ctrl.Name
			,Ctrl.Description
			,Ctrl.LastConnectedTime
			,Ctrl.Active
			,Ctrl.InstallDate
			,'Matrikon.OPC.Simulation' as OPCServerName 
			,CPN.Node
			FROM   [TCD].[ConduitController] Ctrl
			INNER JOIN [TCD].ControllerType CT ON Ctrl.ControllerTypeId = CT.Id	
			INNER JOIN [TCD].Plant PL ON PL.EcolabAccountNumber = Ctrl.EcoalabAccountNumber	
			LEFT JOIN [TCD].ControllerTagNode CPN ON CPN.ControllerID = Ctrl.ControllerId
			WHERE EcoalabAccountNumber =@ecolabAccountNumber

SET NOCOUNT OFF
END



