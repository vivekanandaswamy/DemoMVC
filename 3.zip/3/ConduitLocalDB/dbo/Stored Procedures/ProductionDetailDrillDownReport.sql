--exec [TCD].[ProductionDetailDrillDownReport] @Corporate=N'',@Country=N'',@Region=N'',@EcolabAccountNumber=N'',@Machine=N'',@machineGroup=N'',@Formula=N'',@MachineType=N'',
--@Category=N'',@FromDate='2015-01-01 00:00:00',@ToDate='2015-01-12 00:00:00',@GroupId=N'',@MachineInternalId=N'',
--@FormulaId=171,@EcolabTextileId ='',@TextileCareCustomerId='',@ChainFormulaId='',@DayWise=0,@WeekWise=0,
--@MonthWise=1,@QuarterWise=0,@YearWise=0,@Date = '',@SortColumnID = 0,@SortDirection = 'ASC',@UserId = 0,@ReportID = 2,@IsDrillDown = 0



CREATE PROCEDURE [TCD].[ProductionDetailDrillDownReport] (
											 @Corporate Varchar(max) = '',
											 @Country Varchar(max) = '',
											 @Region Varchar(max) = '',
											 @EcolabAccountNumber Nvarchar(25) = '',
											 @Machine Varchar(max) = '', 
											 @machineGroup Varchar(max) = '',
											 @Formula Varchar(max) = '',
											 @MachineType Varchar(20)= '',
											 @Category Varchar(max) = '',
											 @FromDate Date = '',
											 @ToDate Date = '',
											 @GroupId Varchar(max) = '',
											 @MachineInternalId Varchar(max) = '',
											 --@Customer Varchar(max) = '',
											 @FormulaId Varchar(100) = '',
											 @EcolabTextileId Varchar(100) = '',
											 @TextileCareCustomerId Varchar(100) = '',
											 @ChainFormulaId Varchar(100) = '',
											 @DayWise bit = NULL,
											 @WeekWise bit = NULL,
											 @MonthWise bit = NULL,
											 @QuarterWise bit = NULL,
											 @YearWise bit = NULL,
											 @Date DATE = NULL,
											 @SortColumnID INT = NULL,
											 @SortDirection Varchar(100) = '',
											 @UserId Int = NULL,
											 @ReportID INT = NULL,
											 @IsDrillDown BIT									 
										   )
AS   
BEGIN   
SET NOCOUNT ON;

DECLARE @Month INT = MONTH(GETDATE()),
	   @SummationInMin Int = NULL,
	   @summingActualLoad Decimal(10,2) = NULL,
	   @SQLStatement varchar(max),
	    @SortField Varchar(100) = '',@PlantWise INT = 0


	     SELECT @SortField =  CASE WHEN @SortColumnID = 66 THEN 'ProductionDiff'
						    WHEN @SortColumnID = 119 THEN 'LoadEfficiency'
						    WHEN @SortColumnID = 120 THEN 'ActualProductionperhour'
						    WHEN @SortColumnID = 133 THEN 'NumberOfLoads'
						    WHEN @SortColumnID = 135 THEN 'NumberOfPieces'						
						    WHEN @SortColumnID = 146 THEN 'ProductionMix'
						    WHEN @SortColumnID = 156 THEN 'Rewash'
						    WHEN @SortColumnID = 181 THEN 'TargetLoad'
						    WHEN @SortColumnID = 182 THEN 'TargetProductionperhour'
						    WHEN @SortColumnID = 200 THEN 'TotalLoad'
						    WHEN @SortColumnID = 242 THEN 'DateRange'
						    WHEN @SortColumnID = 0 THEN 'TotalLoad'
					 END

DECLARE @CategoryTable TABLE(Category VARCHAR(100))
INSERT INTO @CategoryTable(Category) EXEC [TCD].[CharlistToTable] @Category,','


DECLARE @MachineTable TABLE(Machine VARCHAR(100))
INSERT INTO @MachineTable(Machine) EXEC [TCD].[CharlistToTable] @Machine,','


DECLARE @GroupMachineTable TABLE(GroupId INT,MachineInternalId INT)  
INSERT INTO @GroupMachineTable(GroupId,MachineInternalId)   
SELECT GroupId,MachineInternalId 
FROM 
TCD.MachineSetup MS 
INNER JOIN TCD.Washer WS ON MS.WasherId = WS.WasherId 
WHERE WS.PlantWasherNumber IN (SELECT Machine FROM @MachineTable);


DECLARE @GroupTable TABLE(GroupId VARCHAR(100))
INSERT INTO @GroupTable(GroupId) EXEC [TCD].[CharlistToTable] @GroupId,','


DECLARE @MachineInternalTable TABLE(MachineInternalId VARCHAR(100))
INSERT INTO @MachineInternalTable(MachineInternalId) EXEC [TCD].[CharlistToTable] @MachineInternalId,','

DECLARE @WasherGroupTable TABLE(MachineGroup VARCHAR(100))
INSERT INTO @WasherGroupTable(MachineGroup) EXEC [TCD].[CharlistToTable] @MachineGroup,','


DECLARE @FormulaTable TABLE(Formula VARCHAR(100))
INSERT INTO @FormulaTable(Formula) EXEC [TCD].[CharlistToTable] @Formula,','


--DECLARE @CustomerTable TABLE(Customer VARCHAR(100))
--INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','


DECLARE @MachineTypeTable TABLE(MachineType VARCHAR(100))
INSERT INTO @MachineTypeTable(MachineType) EXEC [TCD].[CharlistToTable] @MachineType,','

	    /* Including the Latest Batch Data */

	   		  IF((CAST(@ToDate AS DATE) = CAST(GETUTCDATE() AS date)) AND @DayWise <> 1)
				    BEGIN				     

					EXEC [TCD].[ProductionDataRollUp] @ToDate

					END

	   /* Ending the Latest Batch Data Logic */


	  DECLARE @ProductionDetailTable TABLE(
								    RecordDate date,
								    ProgramId INT,
								    FormulaName Nvarchar(100),
								    EcolabTextileId INT,
								    EcolabTextileCategory Nvarchar(100),
								    PlantTextileId INT,
								    PlantTextileCategoryName Nvarchar(100),
								    PlantProgramId INT,
								    PlantProgramName Nvarchar(100),
								    TotalLoad Decimal(10,0) ,
								    TargetLoad Decimal(10,0),
								    DifferenceLoad Decimal(10,0),
								    LoadEfficiency DECIMAL(10,0),
								    ProductionMix DECIMAL(10,0),
								    Numberofbatches INT,
								    ActualLoadperhour Decimal(10,2),
								    TargetLoadperhour Decimal(10,2),
								    NumberOfPieces INT,
								    Rewash Decimal(10,0),
								    TotalRunTime Decimal(18,2)
								  )
	   INSERT INTO @ProductionDetailTable(
								    RecordDate ,
								    ProgramId ,
								    FormulaName ,
								    EcolabTextileId ,
								    EcolabTextileCategory,
								    PlantTextileId ,
								    PlantTextileCategoryName ,
								    PlantProgramId ,
								    PlantProgramName,
								    TotalLoad ,
								    TargetLoad,
								    DifferenceLoad ,
								    LoadEfficiency,
								    ProductionMix ,
								    Numberofbatches,
								    ActualLoadperhour,
								    TargetLoadperhour,
								    NumberOfPieces,
								    Rewash,
								    TotalRunTime
								  )
	   SELECT 
			 PRT.RecordDate,
			 PRT.ProgramNumber,
			 PM.Name,
			 PRT.EcolabTextileId,
			 PRT.EcolabTextileCategoryName,
			 PRT.PlantTextileId,
			 PRT.PlantTextileCategoryName,
			 PRT.PlantProgramId,
			 PRT.PlantProgramName,
			 PRT.TotalActualLoad + CASE WHEN (SELECT COUNT(1) FROM TCD.ManualProduction MP WHERE PRT.RecordDate = CAST(MP.RecordedDate AS DATE)) > 0 THEN 
			 (SELECT SUM(MP.value) FROM TCD.ManualProduction MP WHERE PRT.RecordDate = CAST(MP.RecordedDate AS DATE)) ELSE 0 END,
			 PRT.TotalStandardLoad,
			 (PRT.TotalStandardLoad - (PRT.TotalActualLoad +CASE WHEN (SELECT COUNT(1) FROM TCD.ManualProduction MP WHERE PRT.RecordDate = CAST(MP.RecordedDate AS DATE)) > 0 THEN 
			 (SELECT SUM(MP.value) FROM TCD.ManualProduction MP WHERE PRT.RecordDate = CAST(MP.RecordedDate AS DATE)) ELSE 0 END)),
			 PRT.LoadEfficiency,
			  PRT.ProductionMix,
			 PRT.NoOfBatches
			 + CASE WHEN (SELECT COUNT(1) FROM TCD.ManualProduction MP WHERE PRT.RecordDate = CAST(MP.RecordedDate AS DATE)) > 0 THEN 
			 (SELECT COUNT(1) FROM TCD.ManualProduction MP WHERE PRT.RecordDate = CAST(MP.RecordedDate AS DATE))
			  ELSE 0 END,			
			 PRT.ActualLoadPerHour,
			 PRT.TargetLoadPerHour,			 
			 PRT.NumberOfPieces,
			 PRT.Rewash,
			 prt.TotalRunTime
			 	 FROM TCD.ProductionRollUp PRT
					   LEFT OUTER JOIN 
					   TCD.ProgramMaster PM ON PRT.ProgramNumber = PM.ProgramId
					   LEFT OUTER JOIN TCD.ManualProduction MP ON PRT.RecordDate = CAST(MP.RecordedDate AS DATE)
	   WHERE 
				--CASE @Customer   
                                           
				-- WHEN '' THEN 'TRUE'         
				-- ELSE                                                      
				--  CASE WHEN PRT.CustomerId IN (SELECT Customer FROM @CustomerTable) THEN 'TRUE' END                                                      
				--END='TRUE' 

				--AND       
				

				CASE @Machine   
				 WHEN '' THEN 'TRUE'         
				 ELSE                                                      
				  CASE WHEN PRT.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
				END='TRUE' 

				AND       

				CASE @machineGroup   
                                           
				 WHEN '' THEN 'TRUE'         
				 ELSE                                                      
				  CASE WHEN PRT.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable) THEN 'TRUE' END                                                      
				END='TRUE' 

				AND    
				
				CASE @Formula   
                                           
				 WHEN '' THEN 'TRUE'         
				 ELSE                                                      
				  CASE WHEN PRT.ProgramNumber IN (SELECT Formula FROM @FormulaTable) THEN 'TRUE' END                                                      
				END='TRUE' 

				AND       
				
				CASE @MachineType   
                                           
				 WHEN '' THEN 'TRUE'         
				 ELSE                                                      
				  CASE WHEN PRT.GroupId IN (SELECT WG.WasherGroupId FROM WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable)) THEN 'TRUE' END                                                      
				END='TRUE' 

				AND       

				  
				CASE @FromDate                                                                                
				    WHEN '' THEN Case WHEN MONTH(PRT.RecordDate) = @Month Then  'true' END                                                                                
				    ELSE CASE WHEN PRT.RecordDate >= @FromDate and PRT.RecordDate<= @ToDate THEN 'true'END                                                        
				 END='true'

				 AND

				 CASE @Category   
                                           
				 WHEN '' THEN 'TRUE'         
				 ELSE                                                      
				  CASE WHEN PRT.EcolabTextileId IN (SELECT Category FROM @CategoryTable) THEN 'TRUE' END                                                      
				END='TRUE' 

				AND

				 CASE @GroupId 
                                           
				 WHEN '' THEN 'TRUE' 
				 ELSE        
				CASE WHEN (PRT.GroupId IN (@GroupId) AND 
				  PRT.MachineInternalId IN (@MachineInternalId)) THEN 'TRUE' END                                                   
				END='TRUE' 

				AND

				 CASE @MachineInternalId 
                                           
				 WHEN '' THEN 'TRUE' 
				 ELSE        
				CASE WHEN (PRT.GroupId IN (@GroupId) AND 
				  PRT.MachineInternalId IN (@MachineInternalId)) THEN 'TRUE' END                                                   
				END='TRUE'  

				/* Including the latest data from batch tables */
				/*
				IF((CAST(@FromDate AS DATE) = CAST(GETDATE() AS date)) AND @DayWise <> 1)
				    BEGIN
				     
					 EXEC [TCD].[ProductionBatchLatestData] @Corporate,@Country,@Region,@EcolabAccountNumber,@Machine,@machineGroup,@Formula,
												     @MachineType,@Category,@FromDate,@ToDate,@GroupId,@MachineInternalId,@FromDate

					 INSERT INTO @ProductionDetailTable
					  SELECT 
								PRT.RecordDate,
								PRT.ProgramNumber,
								PM.Name,
								PRT.EcolabTextileId,
								PRT.EcolabTextileCategoryName,
								PRT.PlantTextileId,
								PRT.PlantTextileCategoryName,
								PRT.PlantProgramId,
								PRT.PlantProgramName,
								PRT.TotalActualLoad + CASE WHEN (SELECT COUNT(1) FROM TCD.ManualProduction MP WHERE PRT.RecordDate = CAST(MP.RecordedDate AS DATE)) > 0 THEN 
								(SELECT SUM(MP.value) FROM TCD.ManualProduction MP WHERE PRT.RecordDate = CAST(MP.RecordedDate AS DATE)) ELSE 0 END,
								PRT.TotalStandardLoad,
								(PRT.TotalStandardLoad - (PRT.TotalActualLoad +CASE WHEN (SELECT COUNT(1) FROM TCD.ManualProduction MP WHERE PRT.RecordDate = CAST(MP.RecordedDate AS DATE)) > 0 THEN 
								(SELECT SUM(MP.value) FROM TCD.ManualProduction MP WHERE PRT.RecordDate = CAST(MP.RecordedDate AS DATE)) ELSE 0 END)),
								PRT.LoadEfficiency,
								PRT.ProductionMix,
								PRT.ActualLoadPerHour,
								PRT.TargetLoadPerHour,
								PRT.NoOfBatches + CASE WHEN (SELECT COUNT(1) FROM TCD.ManualProduction MP WHERE PRT.RecordDate = CAST(MP.RecordedDate AS DATE)) > 0 THEN 
								(SELECT COUNT(1) FROM TCD.ManualProduction MP WHERE PRT.RecordDate = CAST(MP.RecordedDate AS DATE))
								 ELSE 0 END,
								PRT.NumberOfPieces,
								PRT.Rewash
			 		    FROM #ProductionRollUpLatest PRT
					   LEFT OUTER JOIN 
					   TCD.ProgramMaster PM ON PRT.ProgramNumber = PM.ProgramId
					   LEFT OUTER JOIN TCD.ManualProduction MP ON PRT.RecordDate = CAST(MP.RecordedDate AS DATE)

					    DROP TABLE #ProductionRollUpLatest

				    END
				    */
				    /* End of production latest batch data */

				 
		   SELECT @summingActualLoad = SUM(TotalLoad)  FROM @ProductionDetailTable

		 --SELECT @summingActualLoad

		  
		   --SELECT @summingActualLoad

		   IF(@DayWise = 1)

	    		  BEGIN
				
				exec [TCD].[ProductionShiftReport] @Corporate,@Country,@Region,@EcolabAccountNumber,@Machine,
			 @machineGroup,@Formula,@MachineType,@Category,@FromDate,
			 @ToDate,@GroupId,@MachineInternalId,@Date,@PlantWise,@FormulaId,
			 @EcolabTextileId,@TextileCareCustomerId,@ChainFormulaId,@SortColumnID,@SortDirection,@ReportID,@IsDrillDown

				END




    IF(@WeekWise = 1)

	    		  BEGIN

			 SELECT @summingActualLoad = SUM(TotalLoad)  FROM @ProductionDetailTable 
			 WHERE (ProgramId = @FormulaId OR EcolabTextileId = @EcolabTextileId OR PlantTextileId = @TextileCareCustomerId OR PlantProgramId = @ChainFormulaId)

			 


				SELECT 
					   0 AS Id,
					   CAST(RecordDate AS nvarchar(100)) As DateRange,
					   SUM(TotalLoad) AS TotalLoad,
					   SUM(TargetLoad) AS TargetLoad,
					   SUM(TargetLoad) - SUM(TotalLoad) AS ProductionDiff,
					   CAST((SUM(TotalLoad) * 100 /SUM(TargetLoad)) AS decimal(18,0)) AS LoadEfficiency,
					   --CAST(SUM(ProductionMix)/COUNT(1) AS decimal(18,2)) AS ProductionMix,
					   CAST((SUM(TotalLoad) * 100 /@summingActualLoad) AS decimal(18,0)) AS ProductionMix,
					   --CAST((TotalLoad * 100 /(SELECT SUM(TotalLoad)  FROM @ProductionDetailTable GROUP BY ProgramId)) AS decimal(18,2)) AS ProductionMix,
					   CAST((SUM(TotalLoad)/SUM(TotalRunTime)) AS decimal(18,2)) AS ActualProductionperhour,
					   CAST((SUM(TargetLoad)/SUM(TotalRunTime)) AS decimal(18,2)) AS TargetProductionperhour,
					   SUM(Numberofbatches) AS NumberOfLoads,
					   SUM(NumberOfPieces) AS NumberOfPieces,
					   --SUM(Rewash) AS Rewash
					   CAST(((SELECT SUM(MR.VALUE) FROM TCD.ManualRewash MR WHERE MR.FormulaId IN 
					   (SELECT PM.ProgramId FROM TCD.ProgramMaster PM WHERE 
					   (ProgramId = @FormulaId OR EcolabTextileCategoryId = @EcolabTextileId OR ChainTextileId = @TextileCareCustomerId OR PlantProgramId = @ChainFormulaId)
					   ) GROUP BY MR.FormulaId) * 100 /@summingActualLoad) AS decimal(18,0)) AS Rewash,
					   'Day' AS SwithMode,@IsDrillDown AS IsDrillDown,
					   SUM(TotalRunTime) AS TotalRunTime 
					   INTO #ProdTableDayOrder
				 FROM @ProductionDetailTable PDT
				 WHERE (ProgramId = @FormulaId OR EcolabTextileId = @EcolabTextileId OR PlantTextileId = @TextileCareCustomerId OR PlantProgramId = @ChainFormulaId)
				 GROUP BY DATEPART(weekday,RecordDate),RecordDate

				SET @SQLStatement 
					   ='SELECT * FROM #ProdTableDayOrder ORDER BY ' + @SortField + ' ' + @SortDirection

	   			EXEC(@SQLStatement)
				END

     IF(@MonthWise = 1)

		 BEGIN  

		  SELECT @summingActualLoad = SUM(TotalLoad)  FROM @ProductionDetailTable 
			 WHERE (ProgramId = @FormulaId OR EcolabTextileId = @EcolabTextileId OR PlantTextileId = @TextileCareCustomerId OR PlantProgramId = @ChainFormulaId)

			
		  DECLARE @FirstDay date = (SELECT TOP 1 RecordDate FROM @ProductionDetailTable ORDER BY RecordDate)
		  DECLARE @LastDay date = (SELECT TOP 1 RecordDate FROM @ProductionDetailTable ORDER BY RecordDate DESC)
		  DECLARE @FirstSunday date = NULL,
				@LastSaturday date = NULL

		  
		  SELECT 
				@FirstSunday = CAST(DateAdd(dd, (8-DatePart(WEEKDAY, 
							DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)))%7, 
							DateAdd(Month, DateDiff(Month, 0, @FirstDay), 0)) AS DATE) 

		   SELECT
				  @LastSaturday = 
								DATEADD(dd,
									   -DATEPART(WEEKDAY,
											   DATEADD(dd, -DAY(DATEADD(month, 1, @LastDay)),
													 DATEADD(month, 1, @LastDay))) ,
									   DATEADD(dd, -DAY(DATEADD(MONTH, 1, @LastDay)), DATEADD(MONTH, 1, @LastDay)));
/*
					DECLARE @GrandTotal TABLE 
						(
							DateRange VARCHAR(1000),
							GrandTotal decimal(18,2)
						)

					INSERT INTO @GrandTotal

			SELECT
					CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,-1,@FirstSunday)) = 7 
							AND (SELECT COUNT(1) FROM @ProductionDetailTable WHERE RecordDate < DATEADD(DD,-1,@FirstSunday)) = 0)
							THEN CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100))
							WHEN DATEADD(DD,-1,@FirstSunday) > CAST(GETDATE() AS DATE) 
							THEN
							CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @ToDate, 101) AS nvarchar(100))
							ELSE
							CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) END As DateRange,
							SUM(TotalLoad)
			
			 FROM @ProductionDetailTable PDT
							 LEFT OUTER JOIN 
								(SELECT FormulaId FROM TCD.ManualRewash) RR ON PDT.ProgramId = RR.FormulaId
					   WHERE RecordDate < @FirstSunday AND RecordDate >= @FirstDay
				UNION ALL
			SELECT 						
			CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100))  + CHAR(13) + '-' +
						   CASE WHEN CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) >
						   CAST(Convert(varchar, DateAdd(dd, (1 - DatePart(dw, @Todate) + 1), @Todate), 101) AS nvarchar(100))
						   THEN  CAST(Convert(varchar, DateAdd(dd, 1-1, @Todate), 101) AS nvarchar(100))
						   ELSE CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) END
						   As DateRange,
						  SUM(TotalLoad) AS TotalLoad
					   FROM @ProductionDetailTable PDT
				       WHERE RecordDate BETWEEN @FirstSunday AND @LastSaturday
					   GROUP BY Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101),
							  Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101)
				UNION ALL
			SELECT 
						 CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,1,@LastSaturday)) = 1 
							 AND (SELECT COUNT(1) FROM @ProductionDetailTable WHERE RecordDate > DATEADD(DD,1,@LastSaturday)) = 0)
							 THEN 
							 CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) 
							 ELSE
							CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @LastDay, 101) AS nvarchar(100)) END   As DateRange,
							 SUM(TotalLoad) AS TotalLoad
					   FROM @ProductionDetailTable PDT
					   WHERE RecordDate > @LastSaturday AND RecordDate <= @LastDay;

					   */


		  WITH CTE(DateRange,TotalLoad,TargetLoad,ProductionDiff,LoadEfficiency,ProductionMix,ActualProductionperhour,TargetProductionperhour,NumberOfLoads,NumberOfPieces,Rewash,SwithMode,TotalRunTime)
				AS
				(
				SELECT 
							CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,-1,@FirstSunday)) = 7 
							AND (SELECT COUNT(1) FROM @ProductionDetailTable WHERE RecordDate < DATEADD(DD,-1,@FirstSunday)) = 0)
							THEN CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100))
							WHEN DATEADD(DD,-1,@FirstSunday) > CAST(GETDATE() AS DATE) 
							THEN
							CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @ToDate, 101) AS nvarchar(100))
							ELSE
							CAST(Convert(varchar, @FirstDay, 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,-1,@FirstSunday), 101) AS nvarchar(100)) END As DateRange,
					 SUM(TotalLoad) AS TotalLoad,
					   SUM(TargetLoad) AS TargetLoad,
					   SUM(TargetLoad) - SUM(TotalLoad) AS ProductionDiff,
					   CAST((SUM(TotalLoad) * 100 /SUM(TargetLoad)) AS decimal(18,0)) AS LoadEfficiency,
					   --CAST(SUM(ProductionMix)/COUNT(DISTINCT RecordDate) AS decimal(18,2)) AS ProductionMix,
					   CAST((SUM(TotalLoad) * 100 /@summingActualLoad) AS decimal(18,0)) AS ProductionMix,
					   --CAST((TotalLoad * 100 /(SELECT SUM(TotalLoad)  FROM @ProductionDetailTable GROUP BY ProgramId)) AS decimal(18,2)) AS ProductionMix,
					   CAST((SUM(TotalLoad)/SUM(TotalRunTime)) AS decimal(18,2)) AS ActualProductionperhour,
					   CAST((SUM(TargetLoad)/SUM(TotalRunTime)) AS decimal(18,2)) AS TargetProductionperhour,
					   SUM(Numberofbatches) AS NumberOfLoads,
					   SUM(NumberOfPieces) AS NumberOfPieces,
					   --SUM(Rewash) AS Rewash
					   CAST(((SELECT SUM(MR.VALUE) FROM TCD.ManualRewash MR WHERE MR.FormulaId IN 
					   (SELECT PM.ProgramId FROM TCD.ProgramMaster PM WHERE 
					   (ProgramId = @FormulaId OR EcolabTextileCategoryId = @EcolabTextileId OR ChainTextileId = @TextileCareCustomerId OR PlantProgramId = @ChainFormulaId)
					   ) GROUP BY MR.FormulaId) * 100 /@summingActualLoad) AS decimal(18,0)) AS Rewash,
					   'Week' AS SwithMode,
					   SUM(TotalRunTime) AS TotalRunTime
					    FROM @ProductionDetailTable PDT
							 LEFT OUTER JOIN 
								(SELECT FormulaId FROM TCD.ManualRewash) RR ON PDT.ProgramId = RR.FormulaId
					   WHERE RecordDate < @FirstSunday AND RecordDate >= @FirstDay
					   AND 
					   (ProgramId = @FormulaId OR EcolabTextileId = @EcolabTextileId OR PlantTextileId = @TextileCareCustomerId OR PlantProgramId = @ChainFormulaId)

					   
					   UNION ALL

		
					   SELECT 
						
						  CAST(Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101) AS nvarchar(100))  + CHAR(13) + '-' +
						   CASE WHEN CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) >
						   CAST(Convert(varchar, DateAdd(dd, (1 - DatePart(dw, @Todate) + 1), @Todate), 101) AS nvarchar(100))
						   THEN  CAST(Convert(varchar, DateAdd(dd, 1-1, @Todate), 101) AS nvarchar(100))
						   ELSE CAST(Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101) AS nvarchar(100)) END
						   As DateRange,
						  SUM(TotalLoad) AS TotalLoad,
					   SUM(TargetLoad) AS TargetLoad,
					   SUM(TargetLoad) - SUM(TotalLoad) AS ProductionDiff,
					   CAST((SUM(TotalLoad) * 100 /SUM(TargetLoad)) AS decimal(18,0)) AS LoadEfficiency,
					   --CAST(SUM(ProductionMix)/COUNT(DISTINCT RecordDate) AS decimal(18,2)) AS ProductionMix,
					   CAST((SUM(TotalLoad) * 100 /@summingActualLoad) AS decimal(18,0)) AS ProductionMix,
					   --CAST((TotalLoad * 100 /(SELECT SUM(TotalLoad)  FROM @ProductionDetailTable GROUP BY ProgramId)) AS decimal(18,2)) AS ProductionMix,
					    CAST((SUM(TotalLoad)/SUM(TotalRunTime)) AS decimal(18,2)) AS ActualProductionperhour,
					   CAST((SUM(TargetLoad)/SUM(TotalRunTime)) AS decimal(18,2)) AS TargetProductionperhour,
					   SUM(Numberofbatches) AS NumberOfLoads,
					   SUM(NumberOfPieces) AS NumberOfPieces,
					   --SUM(Rewash) AS Rewash
					   CAST(((SELECT SUM(MR.VALUE) FROM TCD.ManualRewash MR WHERE MR.FormulaId IN 
					   (SELECT PM.ProgramId FROM TCD.ProgramMaster PM WHERE 
					   (ProgramId = @FormulaId OR EcolabTextileCategoryId = @EcolabTextileId OR ChainTextileId = @TextileCareCustomerId OR PlantProgramId = @ChainFormulaId)
					   ) GROUP BY MR.FormulaId) * 100 /@summingActualLoad) AS decimal(18,0)) AS Rewash,
					   'Week' AS SwithMode,
					   SUM(TotalRunTime) AS TotalRunTime
						  FROM @ProductionDetailTable PDT
				       WHERE RecordDate BETWEEN @FirstSunday AND @LastSaturday
					  AND 
					   (ProgramId = @FormulaId OR EcolabTextileId = @EcolabTextileId OR PlantTextileId = @TextileCareCustomerId OR PlantProgramId = @ChainFormulaId)
					   GROUP BY Convert(varchar, DateAdd(dd, -(DatePart(dw,RecordDate) - 1), RecordDate), 101),
							  Convert(varchar, DateAdd(dd, (7 - DatePart(dw, RecordDate)), RecordDate), 101)

					  UNION ALL

					   SELECT 
							 CASE WHEN (DATEPART(WEEKDAY,DATEADD(DD,1,@LastSaturday)) = 1 
							 AND (SELECT COUNT(1) FROM @ProductionDetailTable WHERE RecordDate > DATEADD(DD,1,@LastSaturday)) = 0)
							 THEN 
							 CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) 
							 ELSE
							CAST(Convert(varchar,DATEADD(DD,1,@LastSaturday), 101) AS nvarchar(100)) + CHAR(13) + '-' + CAST(Convert(varchar, @LastDay, 101) AS nvarchar(100)) END   As DateRange,
							 SUM(TotalLoad) AS TotalLoad,
							 SUM(TargetLoad) AS TargetLoad,
							 SUM(TargetLoad) - SUM(TotalLoad) AS ProductionDiff,
							 CAST((SUM(TotalLoad) * 100 /SUM(TargetLoad)) AS decimal(18,0)) AS LoadEfficiency,
							 --CAST(SUM(ProductionMix)/COUNT(DISTINCT RecordDate) AS decimal(18,2)) AS ProductionMix,
							 CAST((SUM(TotalLoad) * 100 /@summingActualLoad) AS decimal(18,0)) AS ProductionMix,
							 --CAST((TotalLoad * 100 /(SELECT SUM(TotalLoad)  FROM @ProductionDetailTable GROUP BY ProgramId)) AS decimal(18,2)) AS ProductionMix,
							  CAST((SUM(TotalLoad)/SUM(TotalRunTime)) AS decimal(18,2)) AS ActualProductionperhour,
							 CAST((SUM(TargetLoad)/SUM(TotalRunTime)) AS decimal(18,2)) AS TargetProductionperhour,
							 SUM(Numberofbatches) AS NumberOfLoads,
							 SUM(NumberOfPieces) AS NumberOfPieces,
							 --SUM(Rewash) AS Rewash
							  CAST(((SELECT SUM(MR.VALUE) FROM TCD.ManualRewash MR WHERE MR.FormulaId IN 
							 (SELECT PM.ProgramId FROM TCD.ProgramMaster PM WHERE 
							 (ProgramId = @FormulaId OR EcolabTextileCategoryId = @EcolabTextileId OR ChainTextileId = @TextileCareCustomerId OR PlantProgramId = @ChainFormulaId)
							 ) GROUP BY MR.FormulaId) * 100 /@summingActualLoad) AS decimal(18,0)) AS Rewash,
							 'Week' AS SwithMode,
							 SUM(TotalRunTime) AS TotalRunTime
							 FROM @ProductionDetailTable PDT
					   WHERE RecordDate > @LastSaturday AND RecordDate <= @LastDay
					   AND 
					   (ProgramId = @FormulaId OR EcolabTextileId = @EcolabTextileId OR PlantTextileId = @TextileCareCustomerId OR PlantProgramId = @ChainFormulaId)
					   )
					   SELECT
							0 AS Id,
							CT.DateRange,
							CT.TotalLoad,
							CT.TargetLoad,
							CT.ProductionDiff,
							CT.LoadEfficiency,
							CT.productionMix,							
							 --CAST((SUM(TotalLoad) * 100 /@summingActualLoad) AS decimal(18,2)) AS productionMix,
							CT.ActualProductionperhour,
							CT.TargetProductionperhour,
							CT.NumberOfLoads,
							CT.NumberOfPieces,
							CT.Rewash,
							CT.SwithMode,@IsDrillDown AS IsDrillDown,
							CT.TotalRunTime
							INTO #ProdTableWeekOrder
							  FROM CTE CT 
								    WHERE TotalLoad IS NOT NULL
									--GROUP BY DateRange,TotalLoad,TargetLoad,ProductionDiff,LoadEfficiency,ActualProductionperhour,TargetProductionperhour,NumberOfLoads,NumberOfPieces,
									--Rewash,SwithMode,TotalRunTime

					   

					   SET @SQLStatement 
								='SELECT * FROM #ProdTableWeekOrder ORDER BY ' + @SortField + ' ' + @SortDirection

	   				   EXEC(@SQLStatement)
				END
				
		  IF(@QuarterWise = 1)

			 BEGIN 

			  SELECT @summingActualLoad = SUM(TotalLoad)  FROM @ProductionDetailTable 
			 WHERE (ProgramId = @FormulaId OR EcolabTextileId = @EcolabTextileId OR PlantTextileId = @TextileCareCustomerId OR PlantProgramId = @ChainFormulaId)

		  		 SELECT 
					    0 AS Id,
					    DATENAME(MONTH, RecordDate) As DateRange ,
					    SUM(TotalLoad) AS TotalLoad,
					   SUM(TargetLoad) AS TargetLoad,
					   SUM(TargetLoad) - SUM(TotalLoad) AS ProductionDiff,
					   CAST((SUM(TotalLoad) * 100 /SUM(TargetLoad)) AS decimal(18,0)) AS LoadEfficiency,
					   CAST(SUM(ProductionMix)/COUNT(1) AS decimal(18,0)) AS ProductionMix,
					   ----CAST((SUM(TotalLoad) * 100 /@summingActualLoad) AS decimal(18,2)) AS ProductionMix,
					   --CAST((TotalLoad * 100 /(SELECT SUM(TotalLoad)  FROM @ProductionDetailTable GROUP BY ProgramId)) AS decimal(18,2)) AS ProductionMix,
					    CAST((SUM(TotalLoad)/SUM(TotalRunTime)) AS decimal(18,2)) AS ActualProductionperhour,
					   CAST((SUM(TargetLoad)/SUM(TotalRunTime)) AS decimal(18,2)) AS TargetProductionperhour,
					   SUM(Numberofbatches) AS NumberOfLoads,
					   SUM(NumberOfPieces) AS NumberOfPieces,
					   --SUM(Rewash) AS Rewash
					    CAST(((SELECT SUM(MR.VALUE) FROM TCD.ManualRewash MR WHERE MR.FormulaId IN 
					   (SELECT PM.ProgramId FROM TCD.ProgramMaster PM WHERE 
					   (ProgramId = @FormulaId OR EcolabTextileCategoryId = @EcolabTextileId OR ChainTextileId = @TextileCareCustomerId OR PlantProgramId = @ChainFormulaId)
					   ) GROUP BY MR.FormulaId) * 100 /@summingActualLoad) AS decimal(18,0)) AS Rewash,
					   'Quarter' AS SwithMode,
					   DATEPART(MONTH, RecordDate) AS SortDateRange,@IsDrillDown AS IsDrillDown,
					   SUM(TotalRunTime) AS TotalRunTime
					    INTO #ProdTableMonthOrder
					   

					    FROM @ProductionDetailTable PDT
				    WHERE (ProgramId = @FormulaId OR EcolabTextileId = @EcolabTextileId OR PlantTextileId = @TextileCareCustomerId OR PlantProgramId = @ChainFormulaId)
				    GROUP BY DATEPART(MONTH, RecordDate),DATENAME(MONTH, RecordDate)
				
				     SET @SQLStatement 
								='SELECT 
									   Id,
									   DateRange,
									   TotalLoad,
									   TargetLoad,
									   ProductionDiff,
									   LoadEfficiency,
									   ProductionMix,
									   ActualProductionperhour,
									   TargetProductionperhour,
									   NumberOfLoads,
									   NumberOfPieces,
									   Rewash,
									   SwithMode,IsDrillDown,TotalRunTime
									    FROM #ProdTableMonthOrder ORDER BY ' + CASE @SortField WHEN 'DateRange' THEN 'SortDateRange' ELSE @SortField END + ' ' + @SortDirection

	   				   EXEC(@SQLStatement)

		  END
	   IF(@YearWise = 1)

		  BEGIN 

				 SELECT @summingActualLoad = SUM(TotalLoad)  FROM @ProductionDetailTable 
			 WHERE (ProgramId = @FormulaId OR EcolabTextileId = @EcolabTextileId OR PlantTextileId = @TextileCareCustomerId OR PlantProgramId = @ChainFormulaId)

				 DECLARE @Year VARCHAR(100) = RIGHT(YEAR(@FromDate),2)

			SELECT 
				  0 AS Id,
				 CASE 'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10))
										 WHEN 'Q1' THEN 'Jan' + @Year + '- Mar' + @Year
										 WHEN 'Q2' THEN 'Apr' + @Year + '- Jun' + @Year
										 WHEN 'Q3' THEN 'Jul' + @Year + '-Sep' + @Year
										 WHEN 'Q4' THEN 'Oct' + @Year + '- Dec'+ @Year
				END as DateRange,
				 SUM(TotalLoad) AS TotalLoad,
				SUM(TargetLoad) AS TargetLoad,
				SUM(TargetLoad) - SUM(TotalLoad) AS ProductionDiff,
				CAST((SUM(TotalLoad) * 100 /SUM(TargetLoad)) AS decimal(18,0)) AS LoadEfficiency,
				CAST(SUM(ProductionMix)/COUNT(1) AS decimal(18,0)) AS ProductionMix,
				--CAST((SUM(TotalLoad) * 100 /@summingActualLoad) AS decimal(18,2)) AS ProductionMix,
				--CAST((TotalLoad * 100 /(SELECT SUM(TotalLoad)  FROM @ProductionDetailTable GROUP BY ProgramId)) AS decimal(18,2)) AS ProductionMix,
				 CAST((SUM(TotalLoad)/SUM(TotalRunTime)) AS decimal(18,2)) AS ActualProductionperhour,
				 CAST((SUM(TargetLoad)/SUM(TotalRunTime)) AS decimal(18,2)) AS TargetProductionperhour,
				SUM(Numberofbatches) AS NumberOfLoads,
				SUM(NumberOfPieces) AS NumberOfPieces,
				--SUM(Rewash) AS Rewash
				 CAST(((SELECT SUM(MR.VALUE) FROM TCD.ManualRewash MR WHERE MR.FormulaId IN 
				(SELECT PM.ProgramId FROM TCD.ProgramMaster PM WHERE 
				(ProgramId = @FormulaId OR EcolabTextileCategoryId = @EcolabTextileId OR ChainTextileId = @TextileCareCustomerId OR PlantProgramId = @ChainFormulaId)
				) GROUP BY MR.FormulaId) * 100 /@summingActualLoad) AS decimal(18,0)) AS Rewash,
				'Year' AS SwithMode,
				'Q' + CAST(DATEPART(QUARTER, RecordDate) AS varchar(10)) as SortDateRange,@IsDrillDown AS IsDrillDown,
				SUM(TotalRunTime) AS TotalRunTime
				 INTO #ProdTableyearOrder

				 FROM @ProductionDetailTable PDT

			 GROUP BY DATEPART(QUARTER, RecordDate)

			   SET @SQLStatement 
								='SELECT 
									   Id,
									   DateRange,
									   TotalLoad,
									   TargetLoad,
									   ProductionDiff,
									   LoadEfficiency,
									   ProductionMix,
									   ActualProductionperhour,
									   TargetProductionperhour,
									   NumberOfLoads,
									   NumberOfPieces,
									   Rewash,
									   SwithMode,IsDrillDown,TotalRunTime
									    FROM #ProdTableyearOrder ORDER BY ' + CASE @SortField WHEN 'DateRange' THEN 'SortDateRange' ELSE @SortField END + ' ' + @SortDirection

	   				   EXEC(@SQLStatement)

		  END			
END




--SELECT Sum(TotalActualLoad) FROM TCD.ProductionRollUp WHERE RecordDate = '2015-01-03' and ProgramNumber = 171

