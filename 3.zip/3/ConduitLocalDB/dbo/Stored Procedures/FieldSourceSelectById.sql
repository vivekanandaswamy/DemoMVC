﻿-- =============================================
-- Author:		Premchand yelavarthi
-- Create date: 15/jul/2014
-- Description:	Store Procedure to get all the Field Source by Id.
-- =============================================
CREATE PROCEDURE [TCD].[FieldSourceSelectById]
	@DataSourceId int
AS
SET NOCOUNT ON
BEGIN
SELECT [DataSourceId], 
	[Name], 
	[Value]
FROM [TCD].FieldSource
WHERE [DataSourceId] = @DataSourceId END