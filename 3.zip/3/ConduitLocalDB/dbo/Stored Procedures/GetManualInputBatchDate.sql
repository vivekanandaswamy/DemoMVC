﻿/*	
Purpose					:	To get latest batch date processed date.

History					:




*/
CREATE	PROCEDURE	[TCD].[GetManualInputBatchDate]
					@EcoalabWasherId					NVARCHAR(25)

AS
BEGIN

SET	NOCOUNT	ON

SELECT		CAST(BD.StartDate as date)					AS		BatchDate,

			CAST(BD.StartDate AS TIME)					AS		BatchTime

FROM		[TCD].BatchData BD

where		EcolabWasherId								=		@EcoalabWasherId 

AND			BatchId										=		(select max(BatchId) from TCD.BatchData)


SET	NOCOUNT	OFF

END
