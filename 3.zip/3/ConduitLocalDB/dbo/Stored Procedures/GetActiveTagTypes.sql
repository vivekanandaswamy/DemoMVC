create PROCEDURE [TCD].[GetActiveTagTypes]
AS 
BEGIN
	SELECT	TagTypeId,
			TagType,
			TagDescription,
			DataType,
			Active 
	FROM [TCD].[TagType]
END
