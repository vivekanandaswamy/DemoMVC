﻿create procedure [TCD].[SaveTankModuleTags] 
(
 @TankId					int		= NULL,
				@TankName				nvarchar(100)= NULL,
				@EcoalabAccountNumber	nvarchar(25),
				@ControllerId			int		= NULL,
				@UserId					INT,
				@SizeAddress			nvarchar(100) = NULL,
				@DeviationAddress		nvarchar(100)= NULL,
				@LevelAddress			nvarchar(100)= NULL,
					
				--Adding these 2 params as part of re-factoring for integration with Synch/Configurator
				@Scope NVARCHAR(4000) output
			
				
	)
AS 
  BEGIN 
      SET NOCOUNT ON;
	  Declare
	  	@Output							VARCHAR(100)	=			''  
		,	@ReturnValue					INT				=			0
		,	@ErrorId						INT				=			0
		,	@ErrorMessage					NVARCHAR(4000)	=			N''
		,	@CurrentUTCTime					DATETIME		=			GETUTCDATE()
		
		set @Scope = '';
DECLARE @ModuleType INT = 1
			DECLARE @DefaultFrequency INT = 60
			DECLARE @TagTypeCL VARCHAR(100) = 'Tag_LVL'
			DECLARE @TagTypeDev VARCHAR(100) = 'Tag_DEV'
			DECLARE @TagTypeSize VARCHAR(100) = 'Tag_SIZ'
			DECLARE @Result1 INT = NULL
							,@Result2 INT = NULL
							,@Result3 INT = NULL
							,@Type INT = 1
							,@NewTankId INT = NULL
							,@RoleId INT = (SELECT UR.LevelId FROM TCD.UserMaster UM
															INNER JOIN TCD.UserInRole UIR ON UM.UserId = UIR.UserId
															INNER JOIN TCD.UserRoles UR ON UIR.RoleId = UR.RoleId
															WHERE UM.UserId = @UserId)

		IF(@RoleId >=8)
		BEGIN
						IF(@SizeAddress IS NOT NULL AND @SizeAddress <> '')
								BEGIN
								EXEC @Result1 = TCD.CheckDuplicateTag @SizeAddress, @ControllerID
								IF(@Result1 = 0)
								BEGIN
								SET @ErrorMessage = '801,'
								END
						END
						IF(@DeviationAddress IS NOT NULL AND @DeviationAddress <> '')
								BEGIN
									EXEC @Result2 = TCD.CheckDuplicateTag @DeviationAddress,@ControllerID
									IF(@Result2 = 0)
									BEGIN
									SET @ErrorMessage = @ErrorMessage+'802,'
									END
						END
						IF(@LevelAddress IS NOT NULL AND @LevelAddress <> '')
								BEGIN
									EXEC @Result3 = TCD.CheckDuplicateTag @LevelAddress,@ControllerID
									IF(@Result3 = 0)
									BEGIN
									SET @ErrorMessage = @ErrorMessage+'803,'
									END
								END
						END
				SET @ErrorMessage = @ErrorMessage + CONVERT(VARCHAR(100),'')
				
				IF(@ErrorMessage = '')
					begin
					IF(@RoleId >=8)
					BEGIN
									SET @NewTankId = SCOPE_IDENTITY() 
							
								IF(@LevelAddress IS NOT NULL AND @LevelAddress <> '') 
								INSERT INTO TCD.ModuleTags (EcolabAccountNumber,TagType,TagAddress,ModuleTypeId,ModuleId,DeadBand,Active)
									VALUES(@EcoalabAccountNumber,@TagTypeCL,@LevelAddress,@Type,@TankId,@DefaultFrequency,1)

								IF(@SizeAddress IS NOT NULL AND @SizeAddress <> '') 
								INSERT INTO TCD.ModuleTags (EcolabAccountNumber,TagType,TagAddress,ModuleTypeId,ModuleId,DeadBand,Active)
									VALUES(@EcoalabAccountNumber,@TagTypeSize,@SizeAddress,@Type,@TankId,@DefaultFrequency,1)

								IF(@DeviationAddress IS NOT NULL AND @DeviationAddress  <> '') 
								INSERT INTO TCD.ModuleTags (EcolabAccountNumber,TagType,TagAddress,ModuleTypeId,ModuleId,DeadBand,Active)
									VALUES(@EcoalabAccountNumber,@TagTypeDev,@DeviationAddress,@Type,@TankId,@DefaultFrequency,1)
				
					END
					
					end
					else
					begin
					select @scope = @ErrorMessage;
					end
					end