﻿CREATE PROCEDURE	[TCD].[MovePump]	(
					@TunnelCompartmentId					smallint
				,	@NewTunnelCompartmentId					smallint
				,	@ControllerSetupId						smallint
				,	@CompartmentNumber						int
				,	@NewCompartmentNumber					int
				,	@WasherGroupId							int
				,	@UserId									INT					=			NULL
				,	@EcolabAccountNumber					NVARCHAR(25)
				,	@LastModifiedTimeStampAtCentral			DATETIME			=			NULL
				)
AS 
BEGIN 


SET	NOCOUNT	ON

DECLARE	
		@ReturnValue					INT				=			0
	,	@ErrorId						INT				=			0
	,	@ErrorMessage					NVARCHAR(4000)	=			N''


IF	(
									@LastModifiedTimestampAtCentral				IS NOT	NULL
									AND
									NOT	EXISTS	(	SELECT	1
													FROM	TCD.TunnelCompartment		tc				
													WHERE	tc.EcolabAccountNumber	=	@EcolabAccountNumber
														AND	tc.TunnelCompartmentId	=	@TunnelCompartmentId
														AND	tc.LastModifiedTime		=	@LastModifiedTimestampAtCentral
												)
									)
										BEGIN
												SET			@ErrorId				=	60000
												SET			@ErrorMessage			=	N'' + CAST(@ErrorId AS NVARCHAR)
												RAISERROR	(@ErrorMessage, 16, 1)
												SET			@ReturnValue			=	-1
												RETURN		(@ReturnValue)
										END

UPDATE tcd.TunnelCompartmentEquipmentMapping
SET
		TunnelCompartmentId				=		@NewTunnelCompartmentId
	,	LastModifiedByUserId			=		@UserId
--
WHERE
		ControllerEquipmentSetupId		=		@ControllerSetupId
AND		EcoLabAccountNumber				=		@EcolabAccountNumber

UPDATE	tdpm
SET		tdpm.CompartmentNumber			=		@NewCompartmentNumber

	,	tdpm.TunnelDosingSetupId		=		tds.TunnelDosingSetupId
FROM	tcd.TunnelDosingProductMapping tdpm 

INNER JOIN TCD.TunnelDosingSetup		tds 
ON			tds.TunnelDosingSetupId		=		tdpm.TunnelDosingSetupId
AND			tds.EcolabAccountNumber		=		tdpm.EcoLabAccountNumber
INNER JOIN tcd.TunnelProgramSetup		tps 
ON			tps.TunnelProgramSetupId	=		tds.TunnelProgramSetupId
AND			tps.EcolabAccountNumber		=		tds.EcolabAccountNumber
WHERE		tdpm.GroupId				=		@WasherGroupId
AND			tdpm.CompartmentNumber		=		@CompartmentNumber
AND			tdpm.EcoLabAccountNumber	=		@EcolabAccountNumber
--AND			tdpm.TunnelDosingSetupId	=		@CompartmentNumber

AND			tdpm.ControllerEquipmentSetupId = @ControllerSetupId

;WITH CTE AS (SELECT tps.TunnelProgramSetupId,tds.TunnelDosingSetupId FROM TCD.TunnelProgramSetup tps	
					INNER JOIN TCD.TunnelDosingSetup tds	ON tps.TunnelProgramSetupId	=tds.TunnelProgramSetupId	
					AND tps.EcolabAccountNumber	= tds.EcolabAccountNumber	
					WHERE tps.WasherGroupId	= @WasherGroupId	
					AND tds.CompartmentNumber	= @NewCompartmentNumber	) 
UPDATE	tdpm
SET		tdpm.TunnelDosingSetupId		=		ct.TunnelDosingSetupId
FROM	tcd.TunnelDosingProductMapping tdpm 

INNER JOIN TCD.TunnelDosingSetup		tds 
ON			tds.TunnelDosingSetupId		=		tdpm.TunnelDosingSetupId
AND			tds.EcolabAccountNumber		=		tdpm.EcoLabAccountNumber
INNER JOIN tcd.TunnelProgramSetup		tps 
ON			tps.TunnelProgramSetupId	=		tds.TunnelProgramSetupId
AND			tps.EcolabAccountNumber		=		tds.EcolabAccountNumber
INNER JOIN CTE ct ON ct.TunnelProgramSetupId	= tps.TunnelProgramSetupId	
WHERE		tdpm.GroupId				=		@WasherGroupId
AND			tdpm.CompartmentNumber		=		@NewCompartmentNumber
AND			tdpm.EcoLabAccountNumber	=		@EcolabAccountNumber
--AND			tdpm.TunnelDosingSetupId	=		@CompartmentNumber

AND			tdpm.ControllerEquipmentSetupId = @ControllerSetupId

UPDATE TCD.TunnelCompartment
SET
   LastModifiedTime = GETUTCDATE() 
   WHERE 
   TunnelCompartmentId = @TunnelCompartmentId
   AND
   EcoLabAccountNumber = @EcolabAccountNumber

END
