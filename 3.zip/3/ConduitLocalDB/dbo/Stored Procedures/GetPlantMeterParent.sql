﻿
/*  
 ==========================================================================================  
 Purpose:  Fecthing the Meter parent details  

 Author:  Premchand yelavarthi

 --------------------------------------------------------------  
 Aug-13-2014 ENT: Initial version.  
 ==========================================================================================  
*/

CREATE PROCEDURE TCD.GetPlantMeterParent(@UtilityTypeId INT
							    , @MeterID INT = NULL
							    , @EcolabAccountNumber NVARCHAR(25))
AS
BEGIN
    SET NOCOUNT ON;
    
	  SET		@EcolabAccountNumber			=			ISNULL(@EcolabAccountNumber, NULL)			--SQLEnlight SA0029

	IF @MeterID IS NULL
	   BEGIN
		  SELECT MeterID,
			    Description
		    FROM	TCD.Meter
		    WHERE UtilityType = @UtilityTypeId
			 AND IS_deleted = 0 AND EcolabAccountNumber = @EcolabAccountNumber;
	   END;
    ELSE
	   BEGIN
		  SELECT MeterID,
			    Description
		    FROM   TCD.Meter
		    WHERE UtilityType = @UtilityTypeId
			 AND MeterID <> @MeterID
			 AND MeterID NOT IN (
				SELECT MeterID
				  FROM TCD.Meter
				  WHERE parent IN (@MeterID) AND EcolabAccountNumber = @EcolabAccountNumber)
			 AND IS_deleted = 0
			 AND EcolabAccountNumber = @EcolabAccountNumber;
	   END;
END;