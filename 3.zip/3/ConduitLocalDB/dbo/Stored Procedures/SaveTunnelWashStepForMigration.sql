﻿/*

Stored Procedure	:	[TCD].[SaveTunnelWashStepForMigration]

Purpose				:	To Update Washer group formula wash step from my service

Parameters			:	@EcoLabAccountNumber			
						@WasherGroupId					
						@ProgramNumber					
						@UserId							
						@MyServiceCustFrmulaMchGrpGUID	
						@IsDelete						
						@MyServiceStepTypeId			
						@MyServiceWaterTypeId			
						@MyServiceDrainTypeId			
						@StepNumber						
						@StepRunTime					
						@Temperature					
						@WaterLevel						
						@pHLevel						
						@Note							
						@MyServiceCustFrmulaStpGUID		
*/

CREATE PROCEDURE [TCD].[SaveTunnelWashStepForMigration]
					@EcoLabAccountNumber					NVARCHAR(25)
				,	@MyServiceCustFrmulaMchGrpGUID			UNIQUEIDENTIFIER
				,	@IsDelete								BIT
				,	@MyServiceStepTypeId					INT
				,	@MyServiceWaterTypeId					INT
				,	@MyServiceDrainTypeId					INT
				,	@CompartmentNumber						INT
				,	@StepRunTime							INT
				,	@Temperature							INT
				,	@WaterLevel								DECIMAL(18,2)
				,	@Note									NVARCHAR(1000)
				,	@MyServiceCustFrmulaStpGUID				UNIQUEIDENTIFIER
				,	@WaterInletDrain						NVARCHAR(1000)


AS
BEGIN

SET	NOCOUNT	ON

DECLARE	@ErrorId						INT					=			0
,		@CurrentUtc						DATETIME			=			GETUTCDATE()
,		@TunnelProgramSetupId			INT					=			NULL
,		@StepTypeId						INT					=			NULL
,		@WaterType						VARCHAR(50)			=			NULL
,		@DrainDestinationId				INT					=			NULL
,		@WasherGroupId					INT					=			NULL
,		@ProgramNumber					SMALLINT			=			NULL
,		@UserId							INT					=			0


SELECT @TunnelProgramSetupId = TunnelProgramSetupId
	 , @WasherGroupId		 = WasherGroupId		
	 , @ProgramNumber		 = ProgramNumber
FROM TCD.TunnelProgramSetup WHERE EcolabAccountNumber = @EcoLabAccountNumber AND MyServiceCustFrmulaMchGrpGUID = @MyServiceCustFrmulaMchGrpGUID

SELECT @StepTypeId = StepId FROM TCD.WashStep WHERE MyServiceWshOpId =  @MyServiceStepTypeId

SELECT @WaterType = Id FROM TCD.WaterType WHERE MyServiceUtilId =  @MyServiceWaterTypeId

SELECT @DrainDestinationId = DrainDestinationId FROM TCD.DrainDestination WHERE MyServiceDrainTypeId =  @MyServiceDrainTypeId

IF @TunnelProgramSetupId = 0 OR @TunnelProgramSetupId IS NULL
   RETURN
  
IF NOT EXISTS (SELECT 1 FROM [TCD].[TunnelDosingSetup] WHERE EcolabAccountNumber = @EcoLabAccountNumber AND MyServiceCustFrmulaStpGUID = @MyServiceCustFrmulaStpGUID)
	BEGIN
			INSERT INTO [TCD].[TunnelDosingSetup]
					   ([EcoLabAccountNumber]
					   ,[TunnelProgramSetupId]
					   ,[GroupId]
					   ,[ProgramNumber]
					   ,[CompartmentNumber]
					   ,[StepTypeId]
					   ,[StepRunTime]
					   ,[Temperature]
					   ,[WaterType]
					   ,[WaterLevel]
					   ,[WaterInletDrain]
					   ,[DrainDestinationId]
					   ,[Note]
					   ,[Is_Deleted]
					   ,[LastModifiedByUserId]
					   ,[MyServiceCustFrmulaStpGUID]
					   ,[MyServiceLastSynchTime])
			VALUES
						(@EcoLabAccountNumber
						,@TunnelProgramSetupId
						,@WasherGroupId
						,@ProgramNumber
						,@CompartmentNumber
						,@StepTypeId
						,@StepRunTime
						,@Temperature
						,@WaterType
						,@WaterLevel
						,@WaterInletDrain
						,@DrainDestinationId
						,@Note
						,@IsDelete
						,@UserId
						,@MyServiceCustFrmulaStpGUID
						,@CurrentUtc)
		
			--check for any error
			SET	@ErrorId	=	@@ERROR
	END

SELECT @ErrorId

END
