﻿/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_GetTunnelFormulaWashStep]                                             

Purpose:				To get the tunnel formula wash step.

Parameters:				@EcoLabAccountNumber - holds ecolab account number.
						@ProgramSetupId - holds the program setup id.
						@DosingSetupId - holds the dosing setup id.
																
###################################################################################################                                           
*/

CREATE	PROCEDURE	[TCD].[GetTunnelFormulaWashStep]

					@EcoLabAccountNumber					NVARCHAR(25)

				,	@ProgramSetupId							INT

				,	@DosingSetupId							INT				=	NULL			--Null for LIST
        
				,	@Is_Deleted								BIT				=  'FALSE'

AS

BEGIN

SET	NOCOUNT	ON
		
		DECLARE @WaterInletDrain VARCHAR(30) = NULL;
		SELECT @WaterInletDrain = NAME FROM [TCD].TunnelWaterInletDrainLookup TW WHERE TW.TunnelWaterInletDrainLookupId = 1;		

		SELECT		   TDS.[ProgramNumber]

			  ,TDS.[GroupId]

			  ,TDS.[EcolabAccountNumber]

			  ,ISNULL(TDS.StepTypeId, TC.WashStepId) AS StepTypeId

			  ,TDS.[StepRunTime]

			  ,TDS.[CompartmentNumber]

			  ,TDS.[Temperature]

			  ,TDS.[TunnelDosingSetupId]

			  ,TDS.[WaterType]

			  ,ISNULL(TDS.WaterLevel, TC.WaterLevel) AS WaterLevel

			  ,ISNULL(TWIDL.Name , @WaterInletDrain) AS WaterInletDrain

			  ,TDS.[Note]

			  ,TDS.[TunnelProgramSetupId]

			  ,(SELECT TunnelWaterFlowTypeName
				FROM TCD.TunnelWaterFlowType twft
				WHERE twft.TunnelWaterFlowTypeId = TC.WaterFlowId) AS WaterFlow
			  ,(SELECT WS.MyServiceWshOpId
				FROM TCD.WashStep ws
				WHERE ws.StepId	 = TC.WashStepId) AS MyServiceWshOpId
			  ,(SELECT WT.MyServiceUtilId
				FROM TCD.WaterType WT
				WHERE WT.Id	 = TDS.WaterType) AS MyServiceUtilId
			  ,(SELECT DD.MyServiceDrainTypeId
				FROM TCD.DrainDestination DD
				WHERE DD.DrainDestinationId = TDS.DrainDestinationId) AS MyServiceDrainTypId
			  ,TDS.Is_Deleted		As	IsDelete
			  ,TDS.MyServiceCustFrmulaStpGUID			  
			  ,(SELECT TOP 1 STUFF((SELECT ',' + CAST(S.SensorType AS VARCHAR(2))
					FROM TCD.Sensor S WHERE (S.MachineCompartment = TDS.CompartmentNumber OR S.MachineCompartment IS NULL)
						AND S.GroupId = MS.GroupId AND S.EcolabAccountNumber = @EcoLabAccountNumber AND S.Is_deleted = 0 GROUP BY S.SensorType
					FOR XML PATH('')) ,1,1,'')) AS SensorAttached
			  ,(SELECT TOP 1 SensorNum FROM TCD.Sensor S WHERE (S.MachineCompartment = TDS.CompartmentNumber OR S.MachineCompartment IS NULL)
					AND S.GroupId = MS.GroupId AND S.EcolabAccountNumber = @EcoLabAccountNumber AND S.Is_deleted = 0  AND S.SensorType=1
					) AS Probenumber
			  ,(SELECT TOP 1 SensorNum FROM TCD.Sensor S WHERE (S.MachineCompartment = TDS.CompartmentNumber OR S.MachineCompartment IS NULL)
					AND S.GroupId = MS.GroupId AND S.EcolabAccountNumber = @EcoLabAccountNumber AND S.Is_deleted = 0 AND S.SensorType=2
					) AS PhSensorNumber
		FROM 
		[TCD].TunnelDosingSetup TDS
		INNER JOIN [TCD].MachineSetup MS ON MS.GroupId = TDS.GroupId
		AND MS.EcoalabAccountNumber = TDS.EcolabAccountNumber	
		LEFT JOIN [TCD].TunnelCompartment TC ON TC.WasherId = MS.WasherId AND TC.CompartmentNumber = TDS.CompartmentNumber AND TC.EcoLabAccountNumber = TDS.EcolabAccountNumber
		LEFT JOIN [TCD].TunnelWaterInletDrainLookup TWIDL ON TWIDL.TunnelWaterInletDrainLookupId = TC.WaterInletDrainId			
		WHERE 

		TDS.EcolabAccountNumber = @EcoLabAccountNumber 

		AND TDS.TunnelProgramSetupId = @ProgramSetupId

		AND	TDS.TunnelDosingSetupId	=	ISNULL(@DosingSetupId, TDS.TunnelDosingSetupId)

		AND (TDS.Is_Deleted						=			'False' OR TDS.Is_Deleted = @Is_Deleted)
    
		AND (MS.IsDeleted						  =			'False')

		ORDER BY TDS.[CompartmentNumber]

SET	NOCOUNT	OFF

END
