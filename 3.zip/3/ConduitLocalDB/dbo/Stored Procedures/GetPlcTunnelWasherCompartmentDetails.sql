﻿CREATE PROCEDURE [TCD].[GetPlcTunnelWasherCompartmentDetails]
	( 

  @washerID INT

, @compartmentID INT

)

AS
SET NOCOUNT ON
BEGIN

SET		@washerID			=			ISNULL(@washerID, NULL)					--SQLEnlight SA0029
SET		@compartmentID		=			ISNULL(@compartmentID, NULL)			--SQLEnlight SA0029

 SELECT   TDS.CompartmentNumber

,TDPM.ProductId

,TDPM.Quantity AS StandardQuantity

,ws.WasherId

,TPS.NominalLoad [Standard Quantity]

,MST.NumberOfComp [NumberOfCompartments]

,TPS.ProgramNumber 

,TDPM.InjectionNumber

,TDS.StepRunTime

FROM [TCD].Washer WS

INNER JOIN [TCD].MachineSetup MST ON MST.WasherId = ws.WasherId

INNER JOIN [TCD].WasherGroup WG ON WG.WasherGroupId = MST.GroupId

INNER JOIN [TCD].WasherGroupType WGT ON WGT.WasherGroupTypeId = WG.WasherGroupTypeId

INNER JOIN [TCD].TunnelProgramSetup TPS ON TPS.WasherGroupId = WG.WasherGroupId

INNER JOIN [TCD].TunnelDosingSetup TDS ON TDS.TunnelProgramSetupId = TPS.TunnelProgramSetupId

LEFT JOIN [TCD].TunnelDosingProductMapping  TDPM ON TDPM.TunnelDosingSetupId =TDS.TunnelDosingSetupId

WHERE MST.WasherId = 110 AND TDS.CompartmentNumber = 1



END
