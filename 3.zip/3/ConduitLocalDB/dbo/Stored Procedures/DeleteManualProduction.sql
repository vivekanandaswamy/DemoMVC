﻿CREATE PROCEDURE [TCD].[DeleteManualProduction] 
 (
		@ProductionId INT,
		@EcolabAccountNumber NVARCHAR(25),
		@UserId INT,
		@Scope VARCHAR(100) OUTPUT
 )
AS

BEGIN    
SET NOCOUNT ON

DECLARE @WasherId int = NULL,
	   @FormulaId int = NULL,
	   @ManualRecordDate date = NULL,
	   @ManualInputValue int = NULL,
	   @LatestManualInputValue int = NULL

  SELECT @WasherId = mp.WasherId,@FormulaId = mp.FormulaId,@ManualInputValue = mp.[Value],@ManualRecordDate = CAST(mp.RecordedDate AS date) 
					   FROM TCD.ManualProduction mp 
					   WHERE mp.ProductionId = @ProductionId

  SELECT @LatestManualInputValue = - @ManualInputValue


SET	@Scope			=			ISNULL(@Scope, NULL)			--SQLEnlight SA0121

			 IF EXISTS (SELECT 1  FROM   [TCD].ManualProduction  WHERE  ProductionId  = @ProductionId)
			 BEGIN
						 UPDATE [TCD].ManualProduction 
						 SET IsDeleted = 1,
						 LastModifiedByUserId = @UserId  
						 WHERE ProductionId = @ProductionId 
							   AND EcolabAccountNumber = @EcolabAccountNumber   							   

			   EXEC [TCD].[UpdateProductionShiftManualDataRollup]	@Date = @ManualRecordDate,    --'2015-05-26'
												  @ManualData  = @LatestManualInputValue,  --1000
												  @WasherId  = @WasherId,	   --4
												  @ProgramMasterId  =@FormulaId	   --21	

						 SET @Scope = '301' 		
			 END
			 ELSE
			 BEGIN
						 SET @Scope = '401' 	
			 END
			    
SET NOCOUNT OFF
   
END