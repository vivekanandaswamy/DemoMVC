﻿CREATE PROCEDURE [TCD].[SaveWasherProductDeviationData](
	  @ProductDeviationData TCD.ProductDeviationData READONLY,
	  @isNewRecord int,
	  @EcolabAccountNumber NVARCHAR(25))
AS
BEGIN

DECLARE @PlantId INT = (SELECT P.PlantId 
                       FROM TCD.Plant P 
                       WHERE P.EcolabAccountNumber = @EcolabAccountNumber),
		@ExistingRecords INT = (SELECT count(*) FROM TCD.WasherProductDeviations WHERE TCD.WasherProductDeviations.WasherId=(SELECT TOP 1 (WasherId) FROM @ProductDeviationData) and TCD.WasherProductDeviations.ControllerID=(SELECT TOP 1 (ControllerID) FROM @ProductDeviationData))

	If(@ExistingRecords = 0)
		BEGIN
			INSERT INTO TCD.WasherProductDeviations
			(
				WasherId,
				ControllerEquipmentID,
				ControllerID,
				ProductDeviation,
				PlantId
			)
			SELECT 
				udtt.WasherId, 
				udtt.ControllerEquipmentID,
				udtt.ControllerID,
				udtt.Deviation,
				@PlantId
				FROM
				@ProductDeviationData udtt 
		END
	ELSE
		BEGIN
	
	UPDATE WPD 
		SET	WPD.ProductDeviation = udtt.Deviation
	FROM TCD.WasherProductDeviations WPD
	
	INNER JOIN @ProductDeviationData udtt 
			ON WPD.WasherProductDeviationID = udtt.WasherProductDeviationId
		END
END