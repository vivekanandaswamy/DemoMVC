﻿/*
Procedure to get AWE Active and Ratio Dosing enabled count from all the washers connected to a dispenser to send to PLC from
Controller setup advanced screen
*/

CREATE PROCEDURE [TCD].[GetAWEandRatioDosing]
@ControllerId INT,
@EcolabAccountNumber nvarchar(25)
AS
BEGIN
DECLARE @tempResult TABLE(
RatioDosingActive int, AWEActive INT,ControllerTypeId INT
)
DECLARE @RatioDosingActive INT, @AWEActive INT,@ControllerTypeId INT

SET @RatioDosingActive = (SELECT count(w.RatioDosingActive) FROM tcd.Washer w join
tcd.MachineSetup ms ON w.WasherId= ms.WasherId and ms.ControllerId = @ControllerId and w.RatioDosingActive = 1 and w.Is_Deleted = 0
and w.EcoLabAccountNumber = @EcolabAccountNumber AND    ms.EcoalabAccountNumber =  @EcolabAccountNumber)

SET @AWEActive = (SELECT count(w.AWEActive) FROM tcd.Washer w join
tcd.MachineSetup ms ON w.WasherId= ms.WasherId and ms.ControllerId = @ControllerId and w.AWEActive = 1 and w.Is_Deleted = 0
and w.EcoLabAccountNumber = @EcolabAccountNumber AND    ms.EcoalabAccountNumber =  @EcolabAccountNumber)

SET @ControllerTypeId =(SELECT  ControllerTypeId FROM tcd.ConduitController WHERE ControllerId=@ControllerId AND EcoalabAccountNumber = @EcolabAccountNumber)

INSERT INTO @tempResult VALUES(@RatioDosingActive,@AWEActive,@ControllerTypeId)

SELECT * FROM @tempResult
END