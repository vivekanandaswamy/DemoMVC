﻿CREATE PROCEDURE [TCD].[UpdateBatchParameterHoldTime]
(
	@BatchId			INT,
	@BatchStartDate		DATETIME2,
	@BatchEndDate		DATETIME2,
	@WasherId			INT,
	@HoldTimePartitionOn DATETIME
)
AS

BEGIN

	SET	NOCOUNT	ON

	DECLARE @HoldTime INT,
			@HoldTimeParameterId INT,
			@EcolabWasherId INT

	SELECT DISTINCT @EcolabWasherId=Ws.EcolabWasherId FROM TCD.Washer Ws WHERE Ws.WasherId=@WasherId AND Ws.Is_Deleted=0

	IF EXISTS(SELECT TOP 1 * FROM TCD.WasherReading wr WHERE wr.WasherId=@WasherId AND wr.DateTimeStamp BETWEEN @BatchStartDate AND @BatchEndDate)
	BEGIN
		SELECT  ROW_NUMBER() OVER(ORDER BY wr.DateTimeStamp) as Row_Number, wr.ParameterId, wr.ParameterValue, wr.DateTimeStamp FROM TCD.WasherReading wr 
		WHERE wr.DateTimeStamp BETWEEN @BatchStartDate AND @BatchEndDate AND wr.WasherId=@WasherId AND wr.ParameterId=9
		  ;WITH TempTable AS
		  (
			  SELECT  ROW_NUMBER() OVER(ORDER BY wr.DateTimeStamp) as Row_Number,wr.ParameterId, wr.ParameterValue, wr.DateTimeStamp FROM TCD.WasherReading wr 
			  WHERE wr.DateTimeStamp BETWEEN @BatchStartDate AND @BatchEndDate AND wr.WasherId=@WasherId AND wr.ParameterId=9
		   )
		   SELECT tt.ParameterId, tt.ParameterValue, tt.DateTimeStamp, tt2.DateTimeStamp,DATEDIFF(second,tt2.DateTimeStamp, tt.DateTimeStamp) 
		   FROM TempTable tt INNER JOIN TempTable tt2 ON tt.Row_Number = tt2.Row_Number+1
			WHERE tt.ParameterValue = 0


		  ;WITH TempTable AS
		  (
			  SELECT  ROW_NUMBER() OVER(ORDER BY wr.DateTimeStamp) as Row_Number, wr.ParameterId, wr.ParameterValue, wr.DateTimeStamp FROM TCD.WasherReading wr 
			  WHERE wr.DateTimeStamp BETWEEN @BatchStartDate AND @BatchEndDate AND wr.WasherId=@WasherId AND wr.ParameterId=9
		   )
		   SELECT @HoldTime = sum(DATEDIFF(second,tt2.DateTimeStamp, tt.DateTimeStamp)) FROM TempTable tt INNER JOIN TempTable tt2 ON tt.Row_Number = tt2.Row_Number+1
			WHERE tt.ParameterValue = 0

			SELECT @HoldTimeParameterId=Id  FROM TCD.ConduitParameters where Name='HoldTime'
			INSERT TCD.BatchParameters (BatchId, EcolabWasherId, ParameterId, ParameterValue, PartitionOn) 
			SELECT @BatchId, @EcolabWasherId, @HoldTimeParameterId, @HoldTime, @HoldTimePartitionOn
	END
END	