﻿
/* 
 ========================================================================================== 
 Purpose:  Used in the login page where a user login and password are entered. 

 Author:  Premchand Yelavarthi 

 -------------------------------------------------------------- 
 July-02-2014 ENT: Initial version. 
 ========================================================================================== 
*/ 
CREATE PROCEDURE [TCD].[GetAuthenticateUser] (@UserLogin NVARCHAR(50), @Password  NVARCHAR(50)) 
AS 
  BEGIN 
      SET NOCOUNT ON; 

      /* Yes, there are multiple records in the UserMaster for a UserLogin.  This should be corrected.  */
      DECLARE @UserID INT;

      SELECT TOP 1 @UserID = UM.UserId FROM [TCD].UserMaster UM WITH (READUNCOMMITTED) 
      WHERE  
      UM.[LoginName] = @UserLogin
	  AND 
	  BINARY_CHECKSUM(UM.[Password]) = BINARY_CHECKSUM(@Password)
      AND 
      UM.[IsActive] = 1

      IF ( @@ROWCOUNT = 0 ) 
        BEGIN 
             SELECT 0                      UserID, 
			       'First Name'            FirstName,
				   'Last Name'			   LastName,										    
                   'Authentication Failed' FullName, 
				   'Login Name'			   LoginName,				  									   			                
                   1                       LanguageID, 
                   'English'               Name, 
                   000000                  Phone, 
                   0                       UOMID, 
                   'No Email'              Email,
				   0					   EcolabAccountNumber,
				   0				       RegionId,
				   'False'                 IsActive ,
				   'Authentication Failed' as ErrorMessage,
				   'en-US' as Locale
        END; 
      ELSE 
        BEGIN 
            
			UPDATE [TCD].UserMaster SET UserMaster.LastLoggedin = GETUTCDATE() WHERE UserMaster.UserId = @UserID 

            SELECT UM.UserId
			       ,UM.FirstName
				   ,UM.LastName
                   ,UM.FirstName + ' ' + UM.LastName FullName
				   ,UM.LoginName			   
                   ,UM.LanguageId
                   ,LM.Name 
                   ,UM.Phone 
                   ,UM.UOMID 
                   ,UM.Email
				   ,P.EcolabAccountNumber
				   ,P.RegionId
				   ,UM.IsActive
				   ,'' as  ErrorMessage
				   ,ISNULL(LM.Locale,(select top 1 Locale from TCD.LanguageMaster where LanguageId = P.LanguageId)) as Locale

            FROM [TCD].UserMaster UM WITH (READUNCOMMITTED) 
            INNER JOIN [TCD].LanguageMaster LM WITH (READUNCOMMITTED) ON LM.LanguageId = UM.LanguageId 
            INNER JOIN [TCD].UserProfile UP WITH (READUNCOMMITTED) ON UP.UserId = UM.UserId 
            INNER JOIN [TCD].Plant P WITH (READUNCOMMITTED) ON P.EcolabAccountNumber = UP.EcolabAccountNumber
            WHERE
            UM.UserId = @UserID
        END
  END;