﻿/*  
 ==========================================================================================  
 Purpose:  Fecthing the utility details  

 Author:  Santhosh Mahankali

 --------------------------------------------------------------  
 Aug-22-2014 ENT: Initial version.  
 ==========================================================================================  
*/ 


CREATE PROCEDURE [TCD].[GetUtilityDetails]
@EcolabAccountNumber nvarchar(25)
AS
	--CREATE TABLE #UomList
	--(
	--Unit VARCHAR(125),
	--SubUnit VARCHAR(125),
	--UnitSystemId INT
	--)

	---- Inserting UOM Values into temp table from procedure
	--INSERT INTO #UomList
	--(
	--Unit,
	--SubUnit,
	--UnitSystemId
	--)
	--EXEC usp_GetDimensionalUnits'Energy_Content_TCD',1 

BEGIN
SET NOCOUNT ON;
SELECT	PU.UtilityId, 
		PU.UtilityType, 
		CASE 
		  WHEN PU.UtilityType<>2 THEN PU.FactorType 
		  WHEN PU.UtilityType=2 THEN (SELECT wt.Name FROM TCD.WaterType wt WHERE WT.Id=pu.FactorType) END AS FactorType,
		PU.Temparature,
		PU.EnergyContent,
		PU.Price,
		PU.Location,
		PUE.BolierSteam,
		PUE.BolierType,
		CASE
			WHEN PUE.BolierType = 1 THEN 'Boiler'  
			WHEN PUE.BolierType = 1 THEN 'Direct Fire'  
		ELSE ''
		END AS BoilerTypeName,
		PUE.Steam AS SteamPercentage,
		PUE.Boiler AS BolierPercentage,
		PUE.Stack AS StackPercentage,
		PUE.RewashFactor,
		PU.FreeType,
		PU.EnergyContentUnit,
		PU.EnergyPriceUnit,
		PUE.EvaporationFactor,
		PU.LastModifiedTime,
		PU.LastSyncTime,
		PU.EcolabAccountNumber
FROM [TCD].PlantUtilityFactor PU LEFT JOIN [TCD].PlantUtilityEnergyProperties PUE
ON PU.UtilityId=PUE.EnergyUtilityId
Where EcolabAccountNumber = @EcolabAccountNumber
 order by PU.UtilityId

--DROP TABLE #UomList;
SET NOCOUNT OFF;
END


