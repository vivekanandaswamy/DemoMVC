﻿
CREATE PROCEDURE [TCD].[FetchUISettingsBySectionCode](@TopParentSectionCode Int = NULL)
AS

BEGIN
SET NOCOUNT ON

SET		@TopParentSectionCode			=			ISNULL(@TopParentSectionCode, NULL)			--SQLEnlight SA0029

SELECT
	SectionID AS [@SectionID],
	SectionName AS [@SectionName],
	UM.SectionCode AS [@SectionCode],
	UM.SectionType AS [@SectionType],
	UM.ControllerName AS [@ControllerName],
	UM.ViewName AS [@ViewName],
	UM.ResourceClass AS [@ResourceClass],
	UM.ResourceKey AS [@ResourceKey],
	CASE
		WHEN UM.ParentID IS NULL THEN NULL
		ELSE (SELECT SectionCode from [TCD].ConduitMenu   where SectionID=UM.ParentID)
	END AS [@ParentSectionCode],

	(SELECT
		USM.SettingCode AS [@SettingCode],
		USM.SettingValue AS [@SettingValue],
		USM.UserRole AS [@UserRole],
		ISNULL(USM.UserID, -1) AS [@UserId],
		ISNULL(USM.TagId, -1) AS [@TagId],
		ISNULL(USM.TagType, -1) AS [@TagType],
		USM.UsageUICode AS [@UsageUICode]
	FROM  [TCD].[ConduitMenuRoleMapping] USM
	WHERE UM.SectionCode = USM.SectionCode
	FOR
	xml PATH ('SectionSetting'), TYPE
	),
	 [TCD].[TCDUISectionHierarchyNode](um.SectionID)
FROM [TCD].[ConduitMenu] UM --Inner Join [dbo].[ConduitMenuRoleMapping] MR on Um.SectionCode = mr.SectionCode
WHERE ParentId IS NULL 
--and mr.UserRole = @TopParentSectionCode
--AND (ISNULL(@TopParentSectionCode, '') = um.SectionCode
--OR ISNULL(@TopParentSectionCode, '') = '')
FOR
xml PATH ('UiSection'), ROOT ('UiSections'), TYPE;
END;
