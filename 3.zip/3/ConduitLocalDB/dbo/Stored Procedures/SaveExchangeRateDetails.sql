﻿/*

Stored Procedure	:	[TCD].[SaveExchangeRateDetails]

Purpose				:	To Update ExchangeRate Details from my service

Parameters			:	@ExchangeRateId				
						@CurrencyCode				
						@Rate						
						@TargetCurrencyCode			
						@EffectiveExchangeRateDate	
						@CreatedDate		
						@OutputExchangeRateId
*/										
								
CREATE PROCEDURE [TCD].[SaveExchangeRateDetails]
				@ExchangeRateId							INT					=  NULL
		   ,	@CurrencyCode							NVARCHAR(252)		=	NULL
		   ,	@Rate									FLOAT				=	NULL
		   ,	@TargetCurrencyCode						NVARCHAR(252)		=	NULL
		   ,	@EffectiveExchangeRateDate				DATETIME			=	NULL
		   ,	@CreatedDate							DATETIME			=	NULL
		   ,	@OutputExchangeRateId					INT					=	NULL	OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE		@CurrentUtcTime DATETIME	=	GETUTCDATE()

	DECLARE
			@OutputList						AS	TABLE		(
			CurrencyExchangeRateId					INT
		)

IF EXISTS(select 1 from TCD.CurrencyExchangeRate where ExchangeRateId = @ExchangeRateId)

	BEGIN

	UPDATE [TCD].[CurrencyExchangeRate]
		SET CurrencyCode	=	@CurrencyCode,
			Rate			=	@Rate,
			TargetCurrencyCode		=	@TargetCurrencyCode,
			EffectiveExchangeRateDate		=	@EffectiveExchangeRateDate,
			CreatedDate		=	@CreatedDate
		OUTPUT
			inserted.ExchangeRateId	AS	ExchangeRateId
		INTO
			@OutputList	( CurrencyExchangeRateId )
		WHERE ExchangeRateId = @ExchangeRateId
	END

ELSE

	BEGIN
		INSERT INTO [TCD].[CurrencyExchangeRate]
           ([ExchangeRateId]
		   ,[CurrencyCode]
		   ,[Rate]
		   ,[TargetCurrencyCode]
		   ,[EffectiveExchangeRateDate]
		   ,[CreatedDate]
           )
		OUTPUT
			inserted.ExchangeRateId	AS	ExchangeRateId
		INTO
			@OutputList	( CurrencyExchangeRateId )
		SELECT
				@ExchangeRateId
			,	@CurrencyCode
			,	@Rate
			,	@TargetCurrencyCode
			,	@EffectiveExchangeRateDate
			,	@CreatedDate
	END
SELECT	TOP 1	
		@OutputExchangeRateId				=	O.CurrencyExchangeRateId
FROM	@OutputList							O

END