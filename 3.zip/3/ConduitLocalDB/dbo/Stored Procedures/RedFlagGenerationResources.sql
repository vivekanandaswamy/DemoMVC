﻿/*
Purpose					:	Generater Red flags for Resource

Author: Suresh k
Date:28-Dec-2015

exe TCD.RedFlagGenerationResources 1,'2015-12-1','040242802'

*/
CREATE PROCEDURE [TCD].[RedFlagGenerationResources]
( @ShiftId int , 
                                                       @PartitionOn smalldatetime , 
                                                       @EcolabAccountNumber nvarchar( 25)
                                                     )
AS
BEGIN
 DECLARE
       @Value decimal( 18 , 3) , 
	   @UOMId int,
	   @RegionId int,
	   @PlantUOM varchar(100),
       @PlantId int;
 
    SELECT
            @PlantId = PlantId
			,@UOMId=UOMId
			,@RegionId=RegionId
      FROM TCD.Plant p
      WHERE p.EcolabAccountNumber = @EcolabAccountNumber;

    DECLARE
       @Redflag TABLE(
            CounterId int IDENTITY( 1 , 1) , 
            Id int , 
            Item int
                     );

    DECLARE
       @MaxId int , 
       @Counter int , 
       @Item int , 
       @ShiftHrs int , 
       @Id int;


    INSERT INTO @Redflag(Id,
            Item
                        )
    SELECT
            rf.Id , 
            rf.Item
      FROM TCD.RedFlag rf
      WHERE rf.Is_Deleted = 0
        AND rf.RedFlagCategoryId = 3;

    SELECT
            @MaxId = ISNULL( MAX( CounterId) , 0)
      FROM @Redflag r;

SELECT bd.*   
	INTO #BatchData  
	FROM tcd.BatchData bd (NOLOCK) 
	INNER JOIN TCD.MachineSetup ms  (NOLOCK)  on bd.MachineId=ms.WasherId AND   isnull(ms.IsPony,0)=0
	WHERE bd.ShiftId =@ShiftId 
	--AND bd.StandardWeight > 0  
	--and bd.ActualWeight > 0   
	and bd.EndDate IS NOT NULL



    SET @Counter = 1;

    WHILE @Counter  <= @MaxId
        BEGIN
            SELECT
                    @Id = Id , 
                    @Item = Item
              FROM @Redflag r
              WHERE CounterId = @Counter;

			   IF @Item = 6
                BEGIN
				--Water Usage (per CWT/Kg)
				-- if EU region convert gal to Liter 1 gal =3.78541178
				-- if EU region covert CWT to Kg( 1 cwt == 50.8023 KG)
                    SELECT  @Value=  sum( (bwe.ActualQuantity/(case bd.ActualWeight when 0 then 1 else bd.ActualWeight end))* (case @RegionId when 2 then 50.8023 else 1 end) * (case @RegionId when 2 then 1 else 3.78541178 end ))
					  FROM #BatchData bd
					   INNER JOIN TCD.[BatchStepWaterUsageData] bwe ON bd.BatchId=bwe.BatchId and bwe.EcolabWasherId=bd.EcolabWasherId
						INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
									--AND (bd.ProgramNumber = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0) AND rf.Is_Deleted = 0
						 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0
					  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
						AND bd.ShiftId = @ShiftId
						AND BD.PartitionOn = @PartitionOn
						AND rf.Id = @Id
                END
				ELSE   IF @Item = 7
                BEGIN
				--Energy Consumption (per CWT/Kg)
				/* utility type 1: gas 4: oil*/
				/* atual weight stored in data base is btu/cwt
				Oil:-(gallon(0.000008007), kilo_gallon, cubic_foot, cubic_meter,	liter(0.0000413))

				GAS:-(therm :therm(1.0002e-5),deca_therm:DTH(1.00024e-6),cubic_foot:ft³(0.001),btu:btu,cubic_meter:m³(0.00002746573))
				 */
				
				select @PlantUOM = m.AllowManualentry from TCD.Meter m where m.UtilityType in (1,4)

				   SELECT  @Value=  sum( ( case isnull(m.AllowManualentry,@PlantUOM) 
											when 'gallon' then (beud.ActualQuantity/(case ISNULL( bd.ActualWeight,0) when 0 then 1 else bd.ActualWeight end)) * 0.000008007
											when 'kilo_gallon' then (beud.ActualQuantity/(case ISNULL( bd.ActualWeight,0) when 0 then 1 else bd.ActualWeight end)) * 0.008007
											when 'cubic_foot' then (beud.ActualQuantity/(case ISNULL( bd.ActualWeight,0) when 0 then 1 else bd.ActualWeight end)) * 0.001
											when 'cubic_meter' then (beud.ActualQuantity/(case ISNULL( bd.ActualWeight,0) when 0 then 1 else bd.ActualWeight end)) * 0.00002746573
											when 'therm' then (beud.ActualQuantity/(case ISNULL( bd.ActualWeight,0) when 0 then 1 else bd.ActualWeight end)) * 1.0002e-5
											when 'deca_therm' then (beud.ActualQuantity/(case ISNULL( bd.ActualWeight,0) when 0 then 1 else bd.ActualWeight end)) * 1.00024e-6	
											else	(beud.ActualQuantity/(case ISNULL( bd.ActualWeight,0) when 0 then 1 else bd.ActualWeight end))									
											end)
				   
									* (case @RegionId when 1 then 100 else 1 end))
					  FROM #BatchData bd
					   INNER JOIN TCD.[BatchEnergyUsageData] beud ON beud.BatchId=bd.BatchId and beud.EcolabWasherId=bd.EcolabWasherId 
						INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
									--AND (bd.ProgramNumber = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0) AND rf.Is_Deleted = 0
						 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0
						 LEFT JOIN TCD.Meter m ON m.MeterId = RF.MeterId
					  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
						AND bd.ShiftId = @ShiftId
						AND BD.PartitionOn = @PartitionOn
						AND rf.Id = @Id

				END
				ELSE   IF @Item = 8
                BEGIN
				--Gas consumption
				--GasOilTypeId=1:Natural Gas,2:Propane
				/*
				GAS:-(therm :therm(1.0002e-5),deca_therm:DTH(1.00024e-6),cubic_foot:ft³(0.001),btu:btu,cubic_meter:m³(0.00002746573))
				*/
			
				select @PlantUOM = m.AllowManualentry from TCD.Meter m where m.UtilityType in (1)

				   SELECT  @Value=  sum( ( case isnull(m.AllowManualentry,@PlantUOM) 
											when 'gallon' then (beud.ActualQuantity/(case ISNULL( bd.ActualWeight,0) when 0 then 1 else bd.ActualWeight end)) * 0.000008007
											when 'kilo_gallon' then (beud.ActualQuantity/(case ISNULL( bd.ActualWeight,0) when 0 then 1 else bd.ActualWeight end)) * 0.008007
											when 'cubic_foot' then (beud.ActualQuantity/(case ISNULL( bd.ActualWeight,0) when 0 then 1 else bd.ActualWeight end)) * 0.001
											when 'cubic_meter' then (beud.ActualQuantity/(case ISNULL( bd.ActualWeight,0) when 0 then 1 else bd.ActualWeight end)) * 0.00002746573
											when 'therm' then (beud.ActualQuantity/(case ISNULL( bd.ActualWeight,0) when 0 then 1 else bd.ActualWeight end)) * 1.0002e-5
											when 'deca_therm' then (beud.ActualQuantity/(case ISNULL( bd.ActualWeight,0) when 0 then 1 else bd.ActualWeight end)) * 1.00024e-6	
											else	(beud.ActualQuantity/(case ISNULL( bd.ActualWeight,0) when 0 then 1 else bd.ActualWeight end))									
											end)
				   
									* (case @RegionId when 1 then 100 else 1 end))
						  FROM #BatchData bd
						   INNER JOIN TCD.[BatchEnergyUsageData] beud ON beud.BatchId=bd.BatchId and beud.EcolabWasherId=bd.EcolabWasherId  AND beud.GasOilTypeId IN (1,2)
							INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
										--AND (bd.ProgramNumber = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0) AND rf.Is_Deleted = 0
							 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0
							 LEFT JOIN TCD.Meter m ON m.MeterId = RF.MeterId
						  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
							AND bd.ShiftId = @ShiftId
							--AND BD.PartitionOn = @PartitionOn
							AND rf.Id = @Id

				END
				ELSE   IF @Item = 9
                BEGIN
				--Chemical Consumption (per CWT/Kg)
				DECLARE @actualproduction  decimal(18,2)
				 SELECT  @actualproduction= CASE @UOMId 
				 WHEN 1 THEN sum(ISNULL(BD.ActualWeight,0) )/100.00 
				 WHEN 2 THEN ISNULL([TCD].[FnConsumptionOnMetrics](sum(ISNULL(BD.ActualWeight,0)),'Weight',1),0) 
				END  
					  FROM #BatchData bd
					 
						INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
									AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0)									
									 AND rf.Is_Deleted = 0
						 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0
					  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
						AND bd.ShiftId = @ShiftId
						AND rf.Id = @Id

				   SELECT  @Value= sum (bpd.ActualQuantity)/@actualproduction
					  FROM #BatchData bd
					   INNER JOIN TCD.[BatchProductData] bpd ON bpd.BatchId=bd.BatchId and bpd.EcolabWasherId=bd.EcolabWasherId --and bpd.InjectionNumber=bd.ProgramMasterId
						INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
									AND (bd.ProgramMasterId = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0)
									AND (bpd.ProductId = rf.ProductId OR ISNULL( rf.ProductId , 0) = 0)
									 AND rf.Is_Deleted = 0
						 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0
					  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
						AND bd.ShiftId = @ShiftId
						--AND BD.PartitionOn = @PartitionOn
						AND rf.Id = @Id

				END
				ELSE   IF @Item = 25
                BEGIN
				--Chemical Consumption deviation  (%) measured >< standard
				 SELECT  @Value=  sum (bpd.ActualQuantity-bpd.StandardQuantity)/100.00
					  FROM #BatchData bd
					   INNER JOIN TCD.[BatchProductData] bpd ON bpd.BatchId=bd.BatchId and bpd.EcolabWasherId=bd.EcolabWasherId --and bpd.InjectionNumber=bd.ProgramMasterId
						INNER JOIN TCD.RedFlag rf ON(rf.Location = bd.GroupId OR rf.Location = 1)
									--AND (bd.ProgramNumber = rf.FormulaId OR ISNULL( rf.FormulaId , 0) = 0) AND rf.Is_Deleted = 0
						 LEFT JOIN tcd.RedFlagMappingData rfmd ON rf.Id = rfmd.MappingId AND rfmd.Is_Deleted = 0
					  WHERE ( bd.MachineId = rfmd.MachineId     OR rfmd.MachineId IS NULL)
						AND bd.ShiftId = @ShiftId
						--AND BD.PartitionOn = @PartitionOn
						AND rf.Id = @Id

					IF @Value=0
					BEGIN
						SET @Value= null
					END

				END
				ELSE   IF @Item = 27
                BEGIN
				--Chemicals C&I
				    SELECT  @Value=  CI.DayBeforeOutOfStock
				  FROM [TCD].[ChemicalInventoryRollUp] CI 
					INNER JOIN TCD.RedFlag rf ON CI.ProductID = rf.ProductId
				  WHERE  rf.Id = @Id

				END


			IF @Value IS NOT NULL 
			BEGIN
            IF NOT EXISTS( SELECT
                                   1
                             FROM TCD.RedFlag rf
                             WHERE Id = @Id
                               AND rf.Is_Deleted = 0
                               AND rf.MinimumRange <= @Value
                               AND rf.MaximumRange >= @Value
                         )
                BEGIN

                    IF NOT EXISTS( SELECT
                                           1
                                     FROM TCD.RedFlagData rfd
                                     WHERE rfd.RedFlagId = @Id
                                       AND rfd.ShiftId = @ShiftId
                                       AND PartitionOn = @PartitionOn
                                 )
                        BEGIN
                            INSERT INTO TCD.RedFlagData(
                                    RedFlagId , 
                                    PlantId , 
                                    ShiftId , 
                                    RedFlagValue , 
                                    RedFlagMinSetPoint , 
                                    RedFlagMaxSetPoint , 
                                    PartitionOn
                                                       )
                            SELECT
                                    rf.Id , 
                                    @PlantId , 
                                    @ShiftId , 
                                    @Value , 
									rf.MinimumRange , 
                                    rf.MaximumRange ,                                    
                                    @PartitionOn
                              FROM TCD.RedFlag rf
                              WHERE rf.Id = @Id;

                        END;

                END;
			END

            SET @Counter = @Counter + 1;
		END
END