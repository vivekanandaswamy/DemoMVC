﻿CREATE PROCEDURE [TCD].[ProcessHoldSignal]
	(	
	   @Controllerid INT
      ,@Washerid INT
      ,@Address		NVARCHAR(50)
      ,@Value		NVARCHAR(50)
      ,@Timestamp	DATETIME2
	)

AS
BEGIN

SET	NOCOUNT	ON														--SQLEnlight	SA0017

	DECLARE @HoldSignalParameterId  INT,
			@EcolabWasherId			INT			
	
	SELECT DISTINCT @EcolabWasherId=Ws.EcolabWasherId FROM TCD.Washer Ws WHERE Ws.WasherId=@WasherId AND Ws.Is_Deleted=0
	SELECT @HoldSignalParameterId=Id  FROM TCD.ConduitParameters where Name='HoldSignal'
	
IF NOT EXISTS(SELECT TOP 1 * FROM TCD.WasherReading WHERE WasherId=@WasherId AND DateTimeStamp=@Timestamp)
   BEGIN
    INSERT INTO TCD.WasherReading(
         WasherId,
         ParameterId,
         ParameterValue,
         DateTimeStamp,
         PartitionOn,
         EcolabWasherId)
    SELECT    
		 @WasherId,
         @HoldSignalParameterId,
         @Value,
         @Timestamp,
         @Timestamp,
         @EcolabWasherId
   END   
END