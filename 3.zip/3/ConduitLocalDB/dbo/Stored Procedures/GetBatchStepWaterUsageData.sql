﻿/*	                                   
###################################################################################################                                           

Stored Procedure:       [TCD].[GetBatchStepWaterUsageData]                                            

Purpose:				To Get The Batch step water usage Data.

Parameters:				@BatchWashStepId - to get the batch step water usage Data of a particular batchwashstep id.
																
###################################################################################################                                           
*/
Create PROCEDURE [TCD].[GetBatchStepWaterUsageData]
	-- Add the parameters for the stored procedure here
	@BatchWashStepId Int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT SWU.BatchWashStepId, SWU.WaterTypeId, SWU.AcutalQuantity, SWU.StandardQuantity, SWU.Price FROM BatchStepWaterUsageData SWU
	WHERE
	BatchWashStepId = @BatchWashStepId
END