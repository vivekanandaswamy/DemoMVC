﻿/*

Stored Procedure	:	[TCD].[SaveWaterAndEnergyDetails]

Purpose				:	To Save water and energy devices

Parameters			:	@DeviceNumber						
						@DeviceName									
						@DeviceTypeId						
						@DeviceModelId						
						@DeviceNote							
						@EcolabAccountNumber				
						@Comment							
						@InstallDate						
						@Is_deleted							
						@UserID								
						@Scope								
						@OutputDeviceNumber					
						@LastModifiedTimestampAtCentral		
						@MyServiceCustWtrEnrgDvcGuid		
						@OutputLastModifiedTimestampAtLocal
*/

CREATE PROCEDURE [TCD].[SaveWaterAndEnergyDetails] (
									   @ID INT = NULL
									 , @DeviceNumber INT = NULL
									 , @DeviceName NVARCHAR(200) = NULL
									 , @DeviceTypeId INT = NULL
									 , @DeviceModelId INT = NULL
									 , @DeviceNote NVARCHAR(1000) = NULL
									 , @EcolabAccountNumber NVARCHAR(25) = NULL
									 , @Comment NVARCHAR(1000) = NULL
									 , @InstallDate DATETIME = NULL
									 , @Is_deleted BIT = NULL
									 , @UserID INT = NULL
									 , @Scope INT = NULL OUTPUT
									 , @OutputDeviceNumber						INT = NULL	OUTPUT
									 , @LastModifiedTimestampAtCentral			DATETIME = NULL
									 , @MyServiceCustWtrEnrgDvcGuid			UNIQUEIDENTIFIER
									 , @OutputLastModifiedTimestampAtLocal		DATETIME = NULL	OUTPUT
									 , @MyServiceLastSyncTime					DATETIME				=	NULL
) 
AS 
  BEGIN 
      SET NOCOUNT ON; 
	  	DECLARE	
	    @ReturnValue					INT = 0
	    ,@ErrorId						INT = 0
	    ,@ErrorMessage					NVARCHAR(4000) = N''
	    ,@CurrentUTCTime					DATETIME = GETUTCDATE();
	DECLARE
			@OutputList						AS	TABLE		(
			OutputDeviceNumber					INT
	    ,LastModifiedTimestamp			DATETIME
	    );

		/* Inserting the values in to WaterAndEnergy table if it is new meter */

	SET	@OutputDeviceNumber			=			ISNULL(@OutputDeviceNumber, NULL)			--SQLEnlight SA0121
	SET	@Scope						=			ISNULL(@Scope, NULL)						--SQLEnlight SA0121


      IF NOT EXISTS (SELECT * 
				 FROM   TCD.WaterAndEnergy
                 WHERE  Id = @ID) 
			 BEGIN 
			 IF NOT EXISTS (SELECT 1 
					    FROM   TCD.WaterAndEnergy
                 WHERE  DeviceName = @DeviceName 
						AND DeviceTypeId = @DeviceTypeId 
						AND DeviceModelId = @DeviceModelId
						  AND Is_deleted = 'FALSE'
						) 
			 BEGIN 

			 /* Inserting the Details of Water and Energy  in to WaterAndEnergy table if it is new device */

				INSERT INTO TCD.WaterAndEnergy
												(DeviceNumber,
												 DeviceName,
												DeviceTypeId, 
												DeviceModelId, 
												DeviceNote, 
												EcolabAccountNumber, 
												Comment, 
												InstallDate, 
												Is_deleted,
												LastModifiedByUserId,
												MyServiceCustWtrEnrgDvcGuid,
												MyServiceLastSynchTime
												) 
							OUTPUT
								inserted.Id						AS			OutputDeviceNumber
				,inserted.LastModifiedTime					AS			LastModifiedTimestamp
							INTO
								@OutputList	(
								OutputDeviceNumber
					  ,LastModifiedTimestamp
							)   
				SELECT
												@DeviceNumber,
												@DeviceName,
												@DeviceTypeId,
												@DeviceModelId, 
												@DeviceNote, 
												@EcolabAccountNumber,
												@Comment,
												@InstallDate, 
												@Is_deleted,
												@UserID,
												@MyServiceCustWtrEnrgDvcGuid,
												@MyServiceLastSyncTime	
			 END;
			  ELSE
			  BEGIN 
				SET @ErrorMessage = '401';
				RAISERROR(@ErrorMessage, 16, 1);
				RETURN;
			 END;
	   END;
    ELSE
		  BEGIN 
		  IF	@LastModifiedTimestampAtCentral				IS NOT	NULL
		 AND NOT	EXISTS	(	SELECT	1
									FROM	TCD.WaterAndEnergy		WE
							  WHERE	WE.EcolabAccountNumber = @EcolabAccountNumber
								 AND WE.Id = @ID
								 AND WE.LastModifiedTime = @LastModifiedTimestampAtCentral
					)
								BEGIN
				SET			@ErrorId = 60000;
				SET			@ErrorMessage = N''
										 +
										 CAST(@ErrorId AS NVARCHAR)
										 +
										 N': Record not in-synch between plant and central.';
				RAISERROR	(@ErrorMessage, 16, 1);
				SET			@ReturnValue = -1;
				RETURN @ReturnValue;
			 END;
				 IF NOT EXISTS (SELECT 1 
					    FROM   TCD.WaterAndEnergy
                 WHERE  DeviceName = @DeviceName 
						AND DeviceTypeId = @DeviceTypeId 
						  AND DeviceModelId = @DeviceModelId
						  AND Id != @ID 
						  AND Is_deleted = 'FALSE')
				BEGIN 

            /* Updating the value of Water And Energy details */              

                UPDATE WE 
                SET    
				DeviceNumber = @DeviceNumber,
				DeviceName = @DeviceName,
				DeviceTypeId = @DeviceTypeId ,
				DeviceModelId = @DeviceModelId ,
									Comment = @Comment , 
									InstallDate = @InstallDate,
									DeviceNote = @DeviceNote,
				LastModifiedByUserId = @UserID	,
				LastModifiedTime = @CurrentUTCTime
				OUTPUT
						inserted.Id						AS			OutputDeviceNumber
				,inserted.LastModifiedTime					AS			LastModifiedTimestamp
				INTO
						@OutputList	(
						OutputDeviceNumber
					  ,LastModifiedTimestamp
				)   
				  FROM   TCD.WaterAndEnergy WE
				  WHERE Id = @ID;
				SELECT @Scope = @DeviceNumber;
			 END;
				 ELSE
				 BEGIN 
				SET @ErrorMessage = '401';
				RAISERROR(@ErrorMessage, 16, 1);
				RETURN;
			 END;
	   END;
	SELECT	TOP 1	

		@OutputLastModifiedTimestampAtLocal	=	O.LastModifiedTimestamp

	,	@OutputDeviceNumber				=		O.OutputDeviceNumber

	FROM	@OutputList							O





	RETURN	(@ReturnValue)

--SET NOCOUNT OFF;

END

