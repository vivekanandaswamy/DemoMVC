﻿/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_GetTunnelWashStepProducts]                                             

Purpose:				To get the tunnel wash step products.

Parameters:				@EcoLabAccountNumber - holds ecolab account number.
						@CompartmentNumber - holds the compartment number.
						@GroupId - holds the group id.
																
###################################################################################################                                           
*/


CREATE PROCEDURE [TCD].[GetTunnelWashStepProducts]

     @EcoLabAccountNumber     NVARCHAR(25)

    , @CompartmentNumber       INT

    , @GroupId         INT

    , @DosingSetupId        INT

AS

BEGIN

SET NOCOUNT ON
DECLARE @TunnelProgramSetupId INT
,  @LastModifiedTime DATETIME  = NULL
,  @MyServiceFrmulaStpDsgDvcGuid UNIQUEIDENTIFIER = NULL
,  @RegionId INT
,  @PlantId INT 
,  @ControllerModelId INT
,  @ControllerId INT
,  @TunnelId INT
,  @ControllerEquipmentId TINYINT = NULL
SELECT @RegionId = RegionId, @PlantId = PlantId FROM TCD.Plant WHERE EcolabAccountNumber = @EcoLabAccountNumber

SELECT @TunnelId = ms.WasherId FROM TCD.MachineSetup ms Where ms.GroupId = @GroupId AND ms.EcoalabAccountNumber = @EcoLabAccountNumber AND ms.IsTunnel = 1 AND ms.IsDeleted = 0

SELECT @TunnelProgramSetupId = tds.TunnelProgramSetupId FROM TCD.TunnelDosingSetup tds WHERE tds.TunnelDosingSetupId = @DosingSetupId AND tds.EcolabAccountNumber = @EcoLabAccountNumber

 SELECT @ControllerId = ISNULL(WG.ControllerId, - 1)
 FROM [TCD].WasherGroup WG
 WHERE WG.EcolabAccountNumber = @EcoLabAccountNumber
 AND WG.WasherGroupId = @GroupId

SELECT @ControllerModelId = cc.ControllerModelId from tcd.ConduitController cc WHERE cc.ControllerId = @ControllerId AND cc.EcoalabAccountNumber = @EcoLabAccountNumber

IF (@ControllerModelId IS NULL OR @ControllerModelId < 7  OR @ControllerModelId IN (12, 13))
BEGIN
 IF NOT EXISTS (SELECT 1 FROM TCD.TunnelDosingProductMapping tdpm WHERE tdpm.TunnelDosingSetupId = @DosingSetupId AND tdpm.EcoLabAccountNumber = @EcoLabAccountNumber)
  BEGIN
   SELECT 
   0           AS  TunnelDosingProductMappingId,
   TC.EcoLabAccountNumber      AS  EcoalabAccountNumber, 
   CES.ControllerEquipmentSetupId    AS  ControllerEquipmentSetupId, 
   PM.ProductId        AS  ProductId, 
   ISNULL(NULLIF(PM.EnvisionDisplayName, ' '),PM.Name)  AS ProductName,
   0.0           AS  Quantity,
   0           AS  DelayTime,  
   CAST(TC.[CompartmentNumber] AS INT)   AS  CompartmentNumber, 
   MS.GroupId         AS  GroupId,
   @LastModifiedTime       AS  LastModifiedTime,
   @MyServiceFrmulaStpDsgDvcGuid    AS  MyServiceFrmulaStpDsgDvcGuid,
   TCD.FnChemicalCostInOunce(PM.ProductId)  AS  Price,
   GETUTCDATE()        AS  MyServiceLastSynchTime,
   CAST(CES.ControllerEquipmentTypeId AS INT)    AS  ControllerEquipmentSetupTypeId,
   @ControllerEquipmentId
 FROM TCD.TunnelCompartment TC 
 JOIN TCD.MachineSetup MS ON TC.WasherId = MS.WasherId AND TC.EcoLabAccountNumber = MS.EcoalabAccountNumber AND ms.IsDeleted = 'False' 
 JOIN TCD.TunnelCompartmentEquipmentMapping TCE ON TCE.TunnelCompartmentId = TC.TunnelCompartmentId AND TCE.EcoLabAccountNumber = TC.EcoLabAccountNumber AND TCE.Is_Deleted = 'False'
 JOIN TCD.ControllerEquipmentSetup CES on CES.ControllerEquipmentSetupId = TCE.ControllerEquipmentSetupId AND CES.EcoLabAccountNumber = TCE.EcoLabAccountNumber
 JOIN TCD.ProductMaster PM on PM.ProductId = CES.ProductId
 JOIN TCD.ProductdataMapping pm2 ON pm2.EcolabAccountNumber = CES.EcoLabAccountNumber AND pm2.ProductID = CES.ProductId AND pm.ProductId = pm2.ProductID AND pm2.Is_Deleted = 0 
 JOIN TCD.TunnelProgramSetup TPS on TPS.WasherGroupId = MS.GroupId AND TPS.EcolabAccountNumber = MS.EcoalabAccountNumber
  WHERE TC.CompartmentNumber = @CompartmentNumber AND MS.GroupId = @GroupId 
  AND MS.EcoalabAccountNumber = @EcoLabAccountNumber 
  AND TPS.TunnelProgramSetupId = @TunnelProgramSetupId
 END
 ELSE
 BEGIN
 SELECT 
   ISNULL(TDPM.TunnelDosingProductMappingId,0)   AS  TunnelDosingProductMappingId,
   TC.EcoLabAccountNumber      AS  EcoalabAccountNumber, 
   CES.ControllerEquipmentSetupId    AS  ControllerEquipmentSetupId, 
   PM.ProductId        AS  ProductId, 
   ISNULL(NULLIF(PM.EnvisionDisplayName, ' '),PM.Name)  AS ProductName,
   ISNULL(TDPM.Quantity,0.0) AS Quantity,
   ISNULL(TDPM.DelayTime,0) AS DelayTime,   
   CAST(TC.[CompartmentNumber] AS INT)   AS  CompartmentNumber, 
   MS.GroupId         AS  GroupId,
   TDPM.LastModifiedTime      AS  LastModifiedTime,
   TDPM.MyServiceFrmulaStpDsgDvcGuid   AS  MyServiceFrmulaStpDsgDvcGuid,
   TCD.FnChemicalCostInOunce(PM.ProductId)  AS  Price,
   TDPM.MyServiceLastSynchTime     AS  MyServiceLastSynchTime,
   CAST(CES.ControllerEquipmentTypeId AS INT)     AS  ControllerEquipmentSetupTypeId,
   @ControllerEquipmentId
 FROM TCD.TunnelCompartment TC 
 JOIN TCD.MachineSetup MS ON TC.WasherId = MS.WasherId AND TC.EcoLabAccountNumber = MS.EcoalabAccountNumber AND ms.IsDeleted = 'False' 
 JOIN TCD.TunnelCompartmentEquipmentMapping TCE ON TCE.TunnelCompartmentId = TC.TunnelCompartmentId AND TCE.EcoLabAccountNumber = TC.EcoLabAccountNumber AND TCE.Is_Deleted = 'False'
 JOIN TCD.ControllerEquipmentSetup CES ON CES.ControllerEquipmentSetupId = TCE.ControllerEquipmentSetupId AND CES.EcoLabAccountNumber = TCE.EcoLabAccountNumber
 JOIN TCD.ProductMaster PM ON PM.ProductId = CES.ProductId
 JOIN TCD.ProductdataMapping pm2 ON pm2.EcolabAccountNumber = CES.EcoLabAccountNumber AND pm2.ProductID = CES.ProductId AND pm.ProductId = pm2.ProductID AND pm2.Is_Deleted = 0  
 JOIN TCD.TunnelProgramSetup TPS ON TPS.WasherGroupId = MS.GroupId AND TPS.EcolabAccountNumber = MS.EcoalabAccountNumber
 JOIN TCD.TunnelDosingSetup TDS ON tds.EcolabAccountNumber = TPS.EcolabAccountNumber 
     AND TDS.TunnelProgramSetupId = TPS.TunnelProgramSetupId AND TDS.CompartmentNumber = TC.CompartmentNumber
 LEFT JOIN TCD.TunnelDosingProductMapping TDPM ON TDPM.CompartmentNumber = TC.CompartmentNumber AND TDPM.EcoLabAccountNumber = TDS.EcoLabAccountNumber
     AND TDPM.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId AND TDPM.TunnelDosingSetupId = TDS.TunnelDosingSetupId
  WHERE TC.CompartmentNumber = @CompartmentNumber AND MS.GroupId = @GroupId AND TDS.TunnelDosingSetupId = @DosingSetupId 
  AND MS.EcoalabAccountNumber = @EcoLabAccountNumber 
  AND TPS.TunnelProgramSetupId = @TunnelProgramSetupId
 END 
END
ELSE
BEGIN
 IF EXISTS (SELECT 1 FROM TCD.TunnelCompartment tc WHERE tc.WasherId = @TunnelId AND tc.CompartmentNumber = @CompartmentNumber AND tc.EcoLabAccountNumber = @EcoLabAccountNumber)
 BEGIN
 IF NOT EXISTS (SELECT 1 FROM TCD.TunnelDosingProductMapping tdpm WHERE tdpm.TunnelDosingSetupId = @DosingSetupId AND tdpm.EcoLabAccountNumber = @EcoLabAccountNumber)
  BEGIN
   SELECT 
   0           AS  TunnelDosingProductMappingId,
   TC.EcoLabAccountNumber      AS  EcoalabAccountNumber, 
   CES.ControllerEquipmentSetupId    AS  ControllerEquipmentSetupId, 
   PM.ProductId        AS  ProductId, 
   ISNULL(NULLIF(pm2.EnvisionDisplayName, ' '),pm2.Name)  AS ProductName,
   0.0           AS  Quantity,
   0           AS  DelayTime,  
   CAST(TC.[CompartmentNumber] AS INT)   AS  CompartmentNumber, 
   MS.GroupId         AS  GroupId,
   @LastModifiedTime       AS  LastModifiedTime,
   @MyServiceFrmulaStpDsgDvcGuid    AS  MyServiceFrmulaStpDsgDvcGuid,
   TCD.FnChemicalCostInOunce(PM.ProductId)  AS  Price,
   GETUTCDATE()        AS  MyServiceLastSynchTime,
   CAST(CES.ControllerEquipmentTypeId AS INT)    AS  ControllerEquipmentSetupTypeId,
    CES.ControllerEquipmentId
 FROM TCD.TunnelCompartmentEquipmentValveMapping tcevm
    INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.ControllerEquipmentSetupId = tcevm.ControllerEquipmentSetupId 
    AND tcevm.PlantID = @PlantId
 INNER JOIN TCD.TunnelCompartment TC ON  tc.CompartmentNumber = tcevm.CompartmentNumber AND tc.EcoLabAccountNumber = ces.EcoLabAccountNumber
 LEFT JOIN TCD.TunnelCompartmentEquipmentMapping tcem ON tcevm.ControllerEquipmentSetupID = tcem.ControllerEquipmentSetupId
    AND tc.TunnelCompartmentId = tcem.TunnelCompartmentId AND tcem.Is_Deleted = 'False'
    AND tcem.EcoLabAccountNumber = tc.EcoLabAccountNumber AND tcem.EcoLabAccountNumber = ces.EcoLabAccountNumber
 INNER JOIN TCD.MachineSetup ms ON ms.WasherId = tc.WasherId AND ms.ControllerId = ces.ControllerId AND ms.EcoalabAccountNumber = tc.EcoLabAccountNumber
    AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber AND ms.MachineInternalId = tcevm.TunnelNumber AND MS.IsTunnel = 'TRUE' AND MS.IsDeleted = 'FALSE'
 INNER JOIN TCD.ProductdataMapping pm ON pm.EcolabAccountNumber = ces.EcoLabAccountNumber AND pm.ProductID = ces.ProductId AND pm.Is_Deleted = 0
    INNER JOIN TCD.ProductMaster pm2 ON pm2.ProductId = pm.ProductID
 INNER JOIN TCD.TunnelProgramSetup TPS on TPS.WasherGroupId = MS.GroupId AND TPS.EcolabAccountNumber = MS.EcoalabAccountNumber
  WHERE TC.CompartmentNumber = @CompartmentNumber AND MS.GroupId = @GroupId 
  AND MS.EcoalabAccountNumber = @EcoLabAccountNumber 
  AND TPS.TunnelProgramSetupId = @TunnelProgramSetupId
  END
 ELSE
 BEGIN
 SELECT 
   ISNULL(TDPM.TunnelDosingProductMappingId,0)   AS  TunnelDosingProductMappingId,
   TC.EcoLabAccountNumber      AS  EcoalabAccountNumber, 
   CES.ControllerEquipmentSetupId    AS  ControllerEquipmentSetupId, 
   PM.ProductId        AS  ProductId, 
   ISNULL(NULLIF(pm2.EnvisionDisplayName, ' '),pm2.Name)  AS ProductName,
   ISNULL(TDPM.Quantity,0.0) AS Quantity,
   ISNULL(TDPM.DelayTime,0) AS DelayTime,   
   CAST(TC.[CompartmentNumber] AS INT)   AS  CompartmentNumber, 
   MS.GroupId         AS  GroupId,
   TDPM.LastModifiedTime      AS  LastModifiedTime,
   TDPM.MyServiceFrmulaStpDsgDvcGuid   AS  MyServiceFrmulaStpDsgDvcGuid,
   TCD.FnChemicalCostInOunce(PM.ProductId)  AS  Price,
   TDPM.MyServiceLastSynchTime     AS  MyServiceLastSynchTime,
   CAST(CES.ControllerEquipmentTypeId AS INT)     AS  ControllerEquipmentSetupTypeId,
    CES.ControllerEquipmentId
 FROM TCD.TunnelCompartmentEquipmentValveMapping tcevm
    INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.ControllerEquipmentSetupId = tcevm.ControllerEquipmentSetupId 
    AND tcevm.PlantID = @PlantId
 INNER JOIN TCD.TunnelCompartment TC ON  tc.CompartmentNumber = tcevm.CompartmentNumber AND tc.EcoLabAccountNumber = ces.EcoLabAccountNumber
 LEFT JOIN TCD.TunnelCompartmentEquipmentMapping tcem ON tcevm.ControllerEquipmentSetupID = tcem.ControllerEquipmentSetupId
    AND tc.TunnelCompartmentId = tcem.TunnelCompartmentId AND tcem.Is_Deleted = 'False'
    AND tcem.EcoLabAccountNumber = tc.EcoLabAccountNumber AND tcem.EcoLabAccountNumber = ces.EcoLabAccountNumber
 INNER JOIN TCD.MachineSetup ms ON ms.WasherId = tc.WasherId AND ms.ControllerId = ces.ControllerId AND ms.EcoalabAccountNumber = tc.EcoLabAccountNumber
    AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber AND ms.MachineInternalId = tcevm.TunnelNumber AND MS.IsTunnel = 'TRUE' AND MS.IsDeleted = 'FALSE'
 INNER JOIN TCD.ProductdataMapping pm ON pm.EcolabAccountNumber = ces.EcoLabAccountNumber AND pm.ProductID = ces.ProductId  AND pm.Is_Deleted = 0
    INNER JOIN TCD.ProductMaster pm2 ON pm2.ProductId = pm.ProductID
 INNER JOIN TCD.TunnelProgramSetup TPS on TPS.WasherGroupId = MS.GroupId AND TPS.EcolabAccountNumber = MS.EcoalabAccountNumber
 JOIN TCD.TunnelDosingSetup TDS ON tds.EcolabAccountNumber = TPS.EcolabAccountNumber 
     AND TDS.TunnelProgramSetupId = TPS.TunnelProgramSetupId AND TDS.CompartmentNumber = TC.CompartmentNumber
 LEFT JOIN TCD.TunnelDosingProductMapping TDPM ON TDPM.CompartmentNumber = TC.CompartmentNumber AND TDPM.EcoLabAccountNumber = TDS.EcoLabAccountNumber
     AND TDPM.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId AND TDPM.TunnelDosingSetupId = TDS.TunnelDosingSetupId
  WHERE TC.CompartmentNumber = @CompartmentNumber AND MS.GroupId = @GroupId AND TDS.TunnelDosingSetupId = @DosingSetupId 
  AND MS.EcoalabAccountNumber = @EcoLabAccountNumber 
  AND TPS.TunnelProgramSetupId = @TunnelProgramSetupId
 END 
 END
 ELSE
 BEGIN
 IF NOT EXISTS (SELECT 1 FROM TCD.TunnelDosingProductMapping tdpm WHERE tdpm.TunnelDosingSetupId = @DosingSetupId AND tdpm.EcoLabAccountNumber = @EcoLabAccountNumber)
  BEGIN
  SELECT 
   0           AS  TunnelDosingProductMappingId,
   @EcoLabAccountNumber      AS  EcoalabAccountNumber, 
   CES.ControllerEquipmentSetupId    AS  ControllerEquipmentSetupId, 
   PM.ProductId        AS  ProductId, 
   ISNULL(NULLIF(pm2.EnvisionDisplayName, ' '),pm2.Name)  AS ProductName,
   0.0           AS  Quantity,
   0           AS  DelayTime,  
   CAST(tcevm.CompartmentNumber AS INT)   AS  CompartmentNumber, 
   MS.GroupId         AS  GroupId,
   @LastModifiedTime       AS  LastModifiedTime,
   @MyServiceFrmulaStpDsgDvcGuid    AS  MyServiceFrmulaStpDsgDvcGuid,
   TCD.FnChemicalCostInOunce(PM.ProductId)  AS  Price,
   GETUTCDATE()        AS  MyServiceLastSynchTime,
   CAST(CES.ControllerEquipmentTypeId AS INT)    AS  ControllerEquipmentSetupTypeId ,
    CES.ControllerEquipmentId
 FROM TCD.TunnelCompartmentEquipmentValveMapping tcevm
 INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.ControllerEquipmentSetupId = tcevm.ControllerEquipmentSetupID
 INNER JOIN TCD.MachineSetup ms ON ms.ControllerId = ces.ControllerId AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber AND ms.MachineInternalId = tcevm.TunnelNumber
 INNER JOIN TCD.ProductdataMapping pm ON pm.EcolabAccountNumber = ces.EcoLabAccountNumber AND pm.ProductID = ces.ProductId AND pm.Is_Deleted = 0
 INNER JOIN TCD.ProductMaster pm2 ON pm2.ProductId = pm.ProductId
 WHERE (PM.Is_Deleted = 'FALSE' OR PM.Is_Deleted = 0)
 AND tcevm.CompartmentNumber = @CompartmentNumber
    AND tcevm.PlantID = @PlantId
 AND ms.WasherId = @TunnelId  AND ms.EcoalabAccountNumber =  @EcoLabAccountNumber
    AND MS.IsTunnel = 'TRUE' AND (MS.IsDeleted = 'FALSE' OR MS.IsDeleted = 0) 
 END
 ELSE
 BEGIN
  SELECT 
   ISNULL(TDPM.TunnelDosingProductMappingId,0)   AS  TunnelDosingProductMappingId,
   @EcoLabAccountNumber      AS  EcoalabAccountNumber, 
   CES.ControllerEquipmentSetupId    AS  ControllerEquipmentSetupId, 
   PM.ProductId        AS  ProductId, 
   ISNULL(NULLIF(pm2.EnvisionDisplayName, ' '),pm2.Name)  AS ProductName,
   ISNULL(TDPM.Quantity,0.0) AS Quantity,
   ISNULL(TDPM.DelayTime,0) AS DelayTime,   
   CAST(tcevm.[CompartmentNumber] AS INT)   AS  CompartmentNumber, 
   MS.GroupId         AS  GroupId,
   TDPM.LastModifiedTime      AS  LastModifiedTime,
   TDPM.MyServiceFrmulaStpDsgDvcGuid   AS  MyServiceFrmulaStpDsgDvcGuid,
   TCD.FnChemicalCostInOunce(PM.ProductId)  AS  Price,
   TDPM.MyServiceLastSynchTime     AS  MyServiceLastSynchTime,
   CAST(CES.ControllerEquipmentTypeId AS INT)     AS  ControllerEquipmentSetupTypeId,
    CES.ControllerEquipmentId
 FROM TCD.TunnelCompartmentEquipmentValveMapping tcevm
    INNER JOIN TCD.ControllerEquipmentSetup ces ON ces.ControllerEquipmentSetupId = tcevm.ControllerEquipmentSetupId 
    AND tcevm.PlantID = @PlantId
 INNER JOIN TCD.MachineSetup ms ON ms.ControllerId = ces.ControllerId AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber AND ms.MachineInternalId = tcevm.TunnelNumber
    AND ms.EcoalabAccountNumber = ces.EcoLabAccountNumber AND ms.MachineInternalId = tcevm.TunnelNumber AND MS.IsTunnel = 'TRUE' AND MS.IsDeleted = 'FALSE'
 INNER JOIN TCD.ProductdataMapping pm ON pm.EcolabAccountNumber = ces.EcoLabAccountNumber AND pm.ProductID = ces.ProductId  AND pm.Is_Deleted = 0
    INNER JOIN TCD.ProductMaster pm2 ON pm2.ProductId = pm.ProductID
 INNER JOIN TCD.TunnelProgramSetup TPS on TPS.WasherGroupId = MS.GroupId AND TPS.EcolabAccountNumber = MS.EcoalabAccountNumber
 JOIN TCD.TunnelDosingSetup TDS ON tds.EcolabAccountNumber = TPS.EcolabAccountNumber 
     AND TDS.TunnelProgramSetupId = TPS.TunnelProgramSetupId AND TDS.CompartmentNumber = tcevm.CompartmentNumber
 LEFT JOIN TCD.TunnelDosingProductMapping TDPM ON TDPM.CompartmentNumber = tcevm.CompartmentNumber AND TDPM.EcoLabAccountNumber = TDS.EcoLabAccountNumber
     AND TDPM.ControllerEquipmentSetupId = CES.ControllerEquipmentSetupId AND TDPM.TunnelDosingSetupId = TDS.TunnelDosingSetupId
  WHERE tcevm.CompartmentNumber = @CompartmentNumber AND MS.GroupId = @GroupId AND TDS.TunnelDosingSetupId = @DosingSetupId 
  AND MS.EcoalabAccountNumber = @EcoLabAccountNumber 
  AND TPS.TunnelProgramSetupId = @TunnelProgramSetupId 
 END
 END
END 

 
SET NOCOUNT OFF

END