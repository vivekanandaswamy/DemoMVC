﻿CREATE PROCEDURE [TCD].[SaveShiftBreakDetails] (      
 @ShiftId int        
,@ShiftName varchar(100)        
,@DayId int = NULL          
,@StartTime DATETIME = NULL          
,@EndTime DATETIME = NULL          
,@TargetProd decimal(18,2) = NULL          
,@BreakStartTime Time = NULL          
,@BreakEndTime Time = NULL          
,@EcolabAccountNumber nvarchar(25)        
,@Count INT        
,@UserID INT 
,@TargetProdDisplay decimal(18,2) = NULL  
,@Scope varchar(100) OUTPUT
--Adding these 2 params as part of re-factoring for integration with Synch/Configurator
,	@OutputShiftId							INT			=	NULL	OUTPUT
,	@OutputLastModifiedTimestampAtLocal		DATETIME	=	NULL	OUTPUT
)           
        
AS           
SET NOCOUNT ON          
  BEGIN           
           
  DECLARE @Output Varchar(100) = '',@Rollingcount int = 1        
,@RowCount int = NULL, @DateStartTime DATETIME,@DateEndTime DATETIME,@prevDay INT,@NextDay INT

SET		@OutputShiftId			=			ISNULL(@OutputShiftId, NULL)			--SQLEnlight SA0121

 /* SHIFT OVERLAPPING OF TIMINGS */ 
 
  SELECT @prevDay = CASE WHEN @DayId = 1 THEN 7 ELSE @DayId - 1 END,
	    @NextDay = CASE WHEN @DayId = 7 THEN 1 ELSE @DayId + 1 END 
  
  IF(@EndTime < @StartTime OR @EndTime = @StartTime)
    BEGIN
		SELECT @DateStartTime =  DATEADD(day, DATEDIFF(day, 0, GETDATE()),@StartTime )
		SET @DateEndTime = DATEADD(day, DATEDIFF(day, -1, GETDATE()), @EndTime)
		--SELECT @DateStartTime,@DateEndTime  
    END
    ELSE
    BEGIN
		   SET @DateStartTime = DATEADD(day, DATEDIFF(day, 0, GETDATE()),@StartTime )
		SET @DateEndTime = DATEADD(day, DATEDIFF(day, 0, GETDATE()), @EndTime)
		--SELECT @DateStartTime,@DateEndTime
    END     

   DECLARE @result_table table (Result int)  
	     CREATE TABLE #shiftdata_temp
						  (
						  SNo INT IDENTITY(1,1),
						  [ShiftId] [int],
						   [ShiftName] [nvarchar](1000) ,
						   [DayId] [int] ,
						   [StartTime] [time](7) ,
						   [EndTime] [time](7) ,
						   [TargetProduction] [decimal](18, 2) ,
						   [Is_Deleted] [bit] ,
						   [EcolabAccountNumber] [nvarchar](1000) ,
						   [LastModifiedByUserId] [int] ,
						   [LastModifiedTime] [datetime] ,
						   [LastSyncTime] [datetime],
						   [TargetProduction_Display] [decimal](18, 2) 
						   )        
      INSERT INTO #shiftdata_temp
     Select 
		    [ShiftId] ,           
		    [ShiftName],		
		    [DayId],              
		    [StartTime],          
		    [EndTime],            
		    [TargetProduction] , 
		    [Is_Deleted],        
		    [EcolabAccountNumber],
		    [LastModifiedByUserId],
		    [LastModifiedTime],	
		    [LastSyncTime],
		    [TargetProduction_Display]		
	 FROM ShiftData WHERE (DayId = @DayId OR ( DayId = @prevDay AND (EndTime < StartTime OR EndTime = StartTime) ) OR (DayId = @NextDay)) AND IS_Deleted = 0   

	  UPDATE #shiftdata_temp SET DayId = CASE WHEN @DayId = 1 THEN 0 ELSE DayId END WHERE DayId = 7
	 UPDATE #shiftdata_temp SET DayId = CASE WHEN @DayId = 7 THEN 8 ELSE DayId END WHERE DayId = 1
	  
     SELECT @RowCount = SNo FROM #shiftdata_temp        
         
    WHILE(@Rollingcount <=  @RowCount)        
    BEGIN        
			DECLARE @VALIDSTART DATETIME,@VALIDEND DATETIME,@Result varchar(10) = ''        
		    SELECT @VALIDSTART = CASE WHEN DayId > @DayId THEN  DATEADD(day, DATEDIFF(day, -1, GETDATE()), CAST(starttime AS datetime))
								 WHEN DayId < @DayId THEN   DATEADD(day, DATEDIFF(day, 1, GETDATE()), CAST(starttime AS datetime)) 
														ELSE
														 DATEADD(day, DATEDIFF(day, 0, GETDATE()), CAST(starttime AS datetime)) END		    ,
				   @VALIDEND =  CASE WHEN ((DayId > @DayId AND EndTime > StartTime) OR (DayId = @DayId AND (EndTime = StartTime OR EndTime < StartTime))) THEN 
													   DATEADD(day, DATEDIFF(day,-1, GETDATE()), CAST(EndTime AS datetime))
								 WHEN (DayId < @DayId AND (EndTime < StartTime OR EndTime = StartTime)) THEN 
													    DATEADD(day, DATEDIFF(day, 0, GETDATE()), CAST(EndTime AS datetime))
								 WHEN (DayId > @DayId AND (EndTime < StartTime OR EndTime = StartTime)) THEN 
												    	  DATEADD(day, DATEDIFF(day,-2, GETDATE()), CAST(EndTime AS datetime))						 
								 					   ELSE
														  DATEADD(day, DATEDIFF(day, 0, GETDATE()), CAST(EndTime AS datetime)) 
														  END
					    FROM #shiftdata_temp WHERE SNo = @Rollingcount 

		   IF((@DateStartTime > @VALIDSTART AND @DateStartTime < @VALIDEND) OR
			 (@DateEndTime > @VALIDSTART AND @DateEndTime < @VALIDEND) OR
			 (@DateStartTime = @VALIDSTART AND @DateEndTime > @VALIDEND) OR
			 (@DateStartTime < @VALIDSTART AND @DateEndTime = @VALIDEND) OR
			 (@DateStartTime < @VALIDSTART AND @DateEndTime > @VALIDEND) )
		   BEGIN        
					INSERT INTO @result_table(Result) VALUES(1)        
		   END        
		   ELSE     
		   BEGIN        
					INSERT INTO @result_table(Result) VALUES(0)     
		   END        
        		 
        
			SET @Rollingcount = @Rollingcount + 1        
    END        
    DROP TABLE #shiftdata_temp       
    /* COMPLETED LOGIC FOR VALIDATION */          
        
DECLARE	@CurrentUTCTime						DATETIME		=			GETUTCDATE()
--We set the below OUTPUT variable here, since the service layer requires a NON-NULL value in an output variable of datetime datatype
--this however, should ONLY be used in conjunction with the OUTPUT Id i.e. if there has been an IUD action; else, it's value should be discarded
SET		@OutputLastModifiedTimestampAtLocal					=			@CurrentUTCTime

DECLARE	
		@ErrorNumber					INT					=			0
	,	@ErrorMessage					NVARCHAR(2048)		=			NULL
	,	@ErrorSeverity					INT					=			NULL
	,	@ErrorProcedure					SYSNAME				=			NULL
	,	@MessageString					NVARCHAR(2500)		=			NULL

	IF NOT EXISTS(SELECT 1 FROM [TCD].ShiftData SD WHERE SD.DayId						=				@DayId
								AND				 SD.Is_Deleted					=				0
								AND				 SD.ShiftName					=			    @ShiftName 
							) 
								BEGIN

			IF NOT EXISTS (SELECT 1 FROM @result_table WHERE Result = 1)    
			    
				BEGIN   		

					IF NOT EXISTS(	SELECT 1 FROM [TCD].ShiftData SD 
									WHERE 			 SD.StartTime					=				CAST(@StartTime AS time)
									AND				 SD.EndTime						=				CAST(@EndTime AS time)
									AND				 SD.DayId						=				@DayId
									AND				 SD.Is_Deleted					=				0
									)
									BEGIN

											INSERT INTO [TCD].ShiftData(ShiftName,DayId,StartTime,EndTime,EcolabAccountNumber,TargetProduction, LastModifiedByUserId,TargetProduction_Display)          
											VALUES(@ShiftName,@DayId,CAST(@StartTime AS time),CAST(@EndTime AS time),@EcolabAccountNumber,@TargetProd,@UserID,@TargetProdDisplay)     

											SELECT @ShiftId = ShiftId From [TCD].[ShiftData] S WHERE S.ShiftName = @ShiftName AND S.IS_DELETED <> 1   AND DayId = @DayId 

																																																						
														--IF NOT EXISTS(	SELECT 1 FROM [TCD].ShiftBreakData SBD 
														--WHERE 			SBD.StartTime					=				@BreakStartTime
														--AND				SBD.EndTime						=				@BreakEndTime
														--AND				SBD.DayId						=				@DayId
														--AND				SBD.Is_Deleted					=				0
														--AND				SBD.ShiftId						=				@ShiftId
														--)
														--Begin
															
																			INSERT INTO [TCD].ShiftBreakData(ShiftId,DayId,StartTime,EndTime,EcolabAccountNumber, LastModifiedByUserId)          
																			VALUES(@ShiftId,@DayId,@BreakStartTime,@BreakEndTime,@EcolabAccountNumber,@UserID)   

																			--UPDATE [TCD].ShiftBreakData SET Id = SCOPE_IDENTITY()         

																		
															
																SET @OutPut = '101'         
																SET @Scope = @OutPut SELECT @Scope ,LastModifiedByUserId = @UserID    
														--END
										END
											 
											else
														Begin
																SET @OutPut = '501' + '_' + Cast(@DayId as Varchar(10))        
																SET @Scope = @OutPut SELECT @Scope           
																,LastModifiedByUserId = @UserID   
														END
														--END
														
									
					--Else
					--				Begin
					--						SET @OutPut = '501' + '_' + Cast(@DayId as Varchar(10))       
					--						SET @Scope = @OutPut SELECT @Scope           
					--						,LastModifiedByUserId = @UserID 
					--				End
			END	
			ELSE

			BEGIN
						SET @OutPut = '501' + '_' + Cast(@DayId as Varchar(10))       
						SET @Scope = @OutPut SELECT @Scope           
						,LastModifiedByUserId = @UserID 
			    END		
				
					

				
		End
	ELSE IF(@Count <> 0)

											BEGIN
											
							SELECT TOP 1 @ShiftId = sd.ShiftId FROM [TCD].ShiftData SD 
									WHERE 			 SD.StartTime					=				CAST(@StartTime AS time)
									AND				 SD.EndTime						=				CAST(@EndTime AS time)
									AND				 SD.DayId						=				@DayId
									AND				 SD.Is_Deleted					=				0


									INSERT INTO [TCD].ShiftBreakData(ShiftId,DayId,StartTime,EndTime,EcolabAccountNumber, LastModifiedByUserId)          
									VALUES(@ShiftId,@DayId,@BreakStartTime,@BreakEndTime,@EcolabAccountNumber,@UserID)  
									 
									--UPDATE [TCD].ShiftBreakData SET Id = SCOPE_IDENTITY()  
							SET @OutPut = '101'
																SET @Scope = @OutPut SELECT @Scope ,LastModifiedByUserId = @UserID    
					
											END



ELSE
	BEGIN
			SET @OutPut = '301_'+ Cast(@DayId as Varchar(10))           
			SET @Scope = @OutPut SELECT @Scope           
			,LastModifiedByUserId = @UserID  
	END
   
	SET	@Scope	=	ISNULL(@Scope, NULL)
End