/*  
 ==========================================================================================  
 Purpose:  Fecthing the Manual Rewash details  

 Author:  Neetha Allati

 --------------------------------------------------------------  
 Sep-30-2014 ENT: Initial version.  
 ==========================================================================================  
*/ 
CREATE PROCEDURE [TCD].[GetManualRewashDetails]
 (
   @WasherGroupId INT,
   @EcolabAccountNumber NVARCHAR(25) 
 )
AS 
  BEGIN 
     SET NOCOUNT ON 
   SELECT
      RewashId,
      RecordedDate,
	  FormulaId,
	  RewashReasonId,
      Value
      FROM 
    [TCD].ManualRewash 
   WHERE 
      WasherGroupId = @WasherGroupId
	  AND EcolabAccountNumber = @EcolabAccountNumber
      AND IsDeleted <> 1
	  AND RecordedDate > DATEADD(d,-60,GETDATE())
      ORDER BY RewashId DESC
  SET NOCOUNT OFF
  END