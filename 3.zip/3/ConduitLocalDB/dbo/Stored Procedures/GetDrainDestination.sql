﻿CREATE PROCEDURE [TCD].[GetDrainDestination]
AS
BEGIN
	SELECT dd.DrainDestinationId,dd.DrainDestinationName 
	   FROM TCD.DrainDestination dd 
	   WHERE dd.Is_Deleted=0
END
