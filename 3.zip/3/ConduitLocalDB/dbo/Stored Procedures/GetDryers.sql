﻿CREATE PROCEDURE [TCD].[GetDryers]
(
@EcolabAccountNumber NVARCHAR(25)
)
AS     
  BEGIN     
      SET nocount ON;     
    
     SELECT     
     D.DryerGroupId    
	 , D.Id 
   , D.DryerNo    
   , D.[Description]    
   , D.Model    
   , D.Capacity    
   , D.LastModifiedTime
   , D.EcolabAccountNumber
   , D.DryerTypeId
   , D.Is_deleted
   , GT.GroupDescription      
   , d.Capacity_Display  
    FROM   [TCD].Dryers d 
	Inner Join [TCD].MachineGroup gt on d.DryerGroupId = gt.Id AND  gt.EcolabAccountNumber = D.EcolabAccountNumber 
	WHERE gt.GroupTypeId = 3 AND D.EcolabAccountNumber = @EcolabAccountNumber
  END