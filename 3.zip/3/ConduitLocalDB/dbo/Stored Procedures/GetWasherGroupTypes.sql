﻿/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_GetWasherGroupTypes]                                         

Purpose:				To get the washer group types.
																														
Parameters:				None

###################################################################################################                                           
*/
CREATE	PROCEDURE	[TCD].GetWasherGroupTypes
AS
BEGIN

SET	NOCOUNT	ON

SELECT	WasherGroupTypeId			AS			WasherGroupTypeId
	,	WasherGroupTypeName			AS			WasherGroupTypeName
FROM	[TCD].WasherGroupType

SET	NOCOUNT	OFF


END
