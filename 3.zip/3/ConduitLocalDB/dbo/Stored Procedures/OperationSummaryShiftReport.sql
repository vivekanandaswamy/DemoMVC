


--exec [TCD].[OperationSummaryShiftReport] @Corporate=N'',@Country=N'',@Region=N'',@EcolabAccountNumber=N'',@Machine=N'',
--@machineGroup=N'',@Formula=N'',@MachineType=N'',@Category=N'',@FromDate='2015-01-02 00:00:00',
--@ToDate='2015-01-02 00:00:00',@GroupId=N'',@MachineInternalId=N'',@Date = '',@PlantWise = 0,@FormulaId = '122',
--@EcolabTextileId = '',@TextileCareCustomerId = '',@SortColumnID = 0,@SortDirection = 'ASC',@ReportID = 10,@IsDrillDown = 0

CREATE PROCEDURE [TCD].[OperationSummaryShiftReport] (
--DECLARE 
											 @Corporate Varchar(max) = '',
											 @Country Varchar(max) = '',
											 @Region Varchar(max) = '',
											 @EcolabAccountNumber Nvarchar(25) = '',
											 @Machine Varchar(max) = '', 
											 @machineGroup Varchar(max) = '',
											 @Formula Varchar(max) = '',
											 @MachineType Varchar(20)= '',
											 @Category Varchar(max) = '',
											 @FromDate Date = '',
											 @ToDate Date = '',
											 @GroupId Varchar(max) = '',
											 @MachineInternalId Varchar(max) = '',
											 @Date DATE = NULL,
											 @PlantWise bit = NULL,
											 @FormulaId varchar(100) = '',
											 @EcolabTextileId varchar(100) = '',
											 @TextileCareCustomerId varchar(100) = '',
											 @SortColumnID INT = 0,
											 @SortDirection Varchar(100) = 'asc',
											 @ReportID INT = NULL,
											 @IsDrillDown Bit
										    )
AS
BEGIN   
SET NOCOUNT ON;

DECLARE @ReportGenerated INT = 6, 
	   @SortField Varchar(100) = '',
	   @SQLStatement varchar(max)
	   
	   SET @Date = @FromDate

	   SET	@EcolabAccountNumber			=			ISNULL(@EcolabAccountNumber, NULL)			--SQLEnlight SA0029
	   SET	@Region							=			ISNULL(@Region, NULL)						--SQLEnlight SA0029
	   SET	@ToDate							=			ISNULL(@ToDate, NULL)						--SQLEnlight SA0029


 SELECT @SortField =  CASE WHEN @SortColumnID = 3 THEN 'ActualChemicalUsageperLoad'
						    WHEN @SortColumnID = 7 THEN 'ActualEnergyUsage'
						    WHEN @SortColumnID = 8 THEN 'ActualEnergyUsagePerLoad'
						    WHEN @SortColumnID = 10 THEN 'ActualWaterUsagePerLoad'
						    WHEN @SortColumnID = 11 THEN 'ActualWaterUsage'
						    WHEN @SortColumnID = 43 THEN 'TargetChemicalUsageperLoad'						
						    WHEN @SortColumnID = 77 THEN 'TargetEnergyUsagePerLoad'
						    WHEN @SortColumnID = 83 THEN 'FormulaName'
						    WHEN @SortColumnID = 127 THEN 'ProductionMix'
						    WHEN @SortColumnID = 133 THEN 'NumberOfLoads'
						    WHEN @SortColumnID = 200 THEN 'TotalLoad'
						    WHEN @SortColumnID = 187 THEN 'TargetWaterUsagePerLoad'
						    WHEN @SortColumnID = 194 THEN 'EcolabTextileCategory'
						    WHEN @SortColumnID = 245 THEN 'PlantTextileCategoryName'
						    WHEN @SortColumnID = 0 THEN 'TotalLoad'
					 END
												
DECLARE @CategoryTable TABLE(Category Varchar(100))
INSERT INTO @CategoryTable EXEC [TCD].[CharlistToTable] @Category,','

DECLARE @MachineTable TABLE(Machine Varchar(100))
INSERT INTO @MachineTable EXEC [TCD].[CharlistToTable] @Machine,','

DECLARE @GroupMachineTable TABLE(GroupId INT,MachineInternalId INT)  
INSERT INTO @GroupMachineTable 
SELECT GroupId,MachineInternalId FROM TCD.MachineSetup MS 
									INNER JOIN TCD.Washer WS ON MS.WasherId = WS.WasherId WHERE WS.PlantWasherNumber IN (SELECT Machine FROM @MachineTable);

DECLARE @GroupTable TABLE(GroupId Varchar(100))
INSERT INTO @GroupTable EXEC [TCD].[CharlistToTable] @GroupId,','

DECLARE @MachineInternalTable TABLE(MachineInternalId Varchar(100))
INSERT INTO @MachineInternalTable EXEC [TCD].[CharlistToTable] @MachineInternalId,','

DECLARE @WasherGroupTable TABLE(MachineGroup Varchar(100))
INSERT INTO @WasherGroupTable EXEC [TCD].[CharlistToTable] @machineGroup,','

DECLARE @FormulaTable TABLE(Formula Varchar(100))
INSERT INTO @FormulaTable EXEC [TCD].[CharlistToTable] @Formula,','

--DECLARE @CustomerTable TABLE(Customer Varchar(100))
--INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','

DECLARE @MachineTypeTable TABLE(MachineType Varchar(100))
INSERT INTO @MachineTypeTable EXEC [TCD].[CharlistToTable] @MachineType,','


CREATE TABLE #OperationSummaryShiftTable 
								(
								 [DateRange] Varchar(100) NULL,
								 [BatchId] [int] NULL,
								 [ActualWeight] [decimal](18, 2) NULL,
								 [StandardWeight] [decimal](18, 2) NULL,
								 [MachineId] [int] NULL,
								 [GroupId] [int] NULL,
								 [MachineInternalId] [int] NULL,
								 [ProgramNumber] [int] NULL,
								 [ProductId] [int] NULL,
								 [NoOfBatches] [int] NULL,
								 [ActualChemicalWeight] [decimal](18, 2) NULL,
								 [StandardChemicalWeight] [decimal](18, 2) NULL,
								 [ActualWaterWeight] [decimal](18, 2) NULL,
								 [StandardWaterWeight] [decimal](18, 2) NULL,
								 [ActualEnergyWeight] [decimal](18, 2) NULL,
								 [StandardEnergyWeight] [decimal](18, 2) NULL,
								 [ChemicalCost] [decimal](18, 2) NULL,
								 [WaterCost] [decimal](18, 2) NULL,
								 [EnergyCost] [decimal](18, 2) NULL,
								 [EcolabTextileId] [int] NULL,
								 [EcolabTextileCategoryName] [varchar](100) NULL,
								 [PlantTextileId] [int] NULL,
								 [PlantTextileCategoryName] [varchar](100) NULL,
								 summingActualLoad [decimal](18, 2) NULL,
								 )
 --CREATE TABLE #ShiftResultTable  (
							
	--						Id int,
	--						 DateRange Nvarchar(100),
	--						 TotalLoad [decimal](18, 2) NULL,
	--					   ProductionMix [decimal](18, 2) NULL,
	--					    NumberOfLoads [int] NULL,
	--					    [ActualWaterUsage] [decimal](18, 2) NULL,
	--					   [ActualWaterUsagePerLoad] [decimal](18, 2) NULL,
	--					   [TargetWaterUsagePerLoad] [decimal](18, 2) NULL,
	--					   [ActualEnergyUsage] [decimal](18, 2) NULL,
	--					   [ActualEnergyUsagePerLoad] [decimal](18, 2) NULL,
	--					   [TargetEnergyUsagePerLoad] [decimal](18, 2) NULL,
	--					   [ActualChemicalperLoad] [decimal](18, 2) NULL,
	--					   [TargetChemicalperLoad] [decimal](18, 2) NULL,
	--					  IsDrilldown BIT,
	--						 SwithMode Nvarchar(100)	

	--					  )

CREATE TABLE #ShiftDataTable
				    (
				    RowNumber INT IDENTITY(1,1),
				    ShiftName Nvarchar(1000),
				    ShiftId INT,
				    StartTime DATETIME,
				    EndTime DATETIME
				    )

	   DECLARE @DayId INT = NULL,@Id INT = 1,@summingActualLoad Decimal(10,2) = NULL,@LastFirstTIme Datetime = NULL,@LastEndTIme Datetime = NULL

	    SELECT @summingActualLoad = (SUM(BD.[ActualWeight]) + CASE WHEN SUM(BD.ManualInputWeight) IS NULL THEN 0 ELSE SUM(BD.ManualInputWeight) END)  FROM TCD.BatchData BD 
															 LEFT OUTER JOIN
										   TCD.BatchCustomerData BCD ON BD.BatchID = BCD.BatchId
										   LEFT OUTER JOIN
										   TCD.ProgramMaster PM ON PM.ProgramId = BD.ProgramMasterId
										   LEFT OUTER JOIN
										   TCD.EcolabTextileCategory ETC ON ETC.TextileId = PM.EcolabTextileCategoryId
										    LEFT OUTER JOIN
										   TCD.ChainTextileCategory CTC ON  CTC.TextileId = PM.ChainTextileId
										    LEFT OUTER JOIN
										   TCD.PlantChainProgram PCP ON PCP.PlantProgramId = PM.PlantProgramId
									WHERE  BD.EndDate  >= dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(@Date AS DATE), 112) + ' ' + CONVERT(Varchar(8),'00:00:00') AS DateTime))
														  AND BD.Enddate <= DATEADD(DAY,1,dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10),  CAST(@Date AS DATE), 112) + ' ' + CONVERT(Varchar(8),'00:00:00') AS DateTime)))
									AND (BD.ProgramMasterId = @FormulaId OR ETC.TextileId = @EcolabTextileId OR CTC.TextileId = @TextileCareCustomerId)

			  SELECT @DayId = DayId from TCD.WeekDay WHERE DayName = DATENAME(dw,CAST(@Date AS DATE)) 

			  INSERT INTO #ShiftDataTable
			  SELECT 
				    SD.ShiftName,
				    SD.ShiftId,
				    dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), @Date, 112) + ' ' + CONVERT(Varchar(8), SD.StartTime) AS DateTime)) AS StartTime,
				    dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), @Date, 112) + ' ' + CONVERT(Varchar(8), SD.EndTime) AS DateTime)) AS EndTime
							  
					   FROM TCD.ShiftData SD 
									 WHERE DayId = @DayId AND SD.Is_Deleted = 0

				

			 SELECT TOP 1 @LastEndTIme = ST.EndTime FROM #ShiftDataTable ST ORDER BY ST.EndTime DESC 
			 SELECT TOP 1 @LastFirstTIme = ST.StartTime FROM #ShiftDataTable ST  ORDER BY ST.StartTime Asc

			 
			 IF(@LastEndTIme < dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(DATEADD(Day, DATEDIFF(Day, 0, @LastEndTIme),1) AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(DATEADD(Day, DATEDIFF(Day, 0, @LastEndTIme),1) AS TIME)) AS DateTime)))
				BEGIN
				INSERT INTO #ShiftDataTable(ShiftName,ShiftId,StartTime,EndTime)
				SELECT TOP 1 
					  'NoShift',
					  SHIFTID + 1,
					  @LastEndTIme,
					  dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(DATEADD(Day, DATEDIFF(Day, 0, @LastEndTIme),1) AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(DATEADD(Day, DATEDIFF(Day, 0, @LastEndTIme),1) AS TIME)) AS DateTime))
							 FROM #ShiftDataTable ORDER BY EndTime DESC
				END

			 IF(DATEADD(DAY,-1,dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(DATEADD(Day, DATEDIFF(Day, 0, @LastEndTIme),1) AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(DATEADD(Day, DATEDIFF(Day, 0, @LastEndTIme),1) AS TIME)) AS DateTime))) < @LastFirstTIme) --AND CAST(@LastFirstTIme AS date) = CAST(@Date AS date))
				BEGIN
				INSERT INTO #ShiftDataTable(ShiftName,ShiftId,StartTime,EndTime)
				SELECT TOP 1 
					   'Noshift',
					   SHIFTID + 1,
					   DATEADD(DAY,-1,dateadd(minute, -datediff(minute, sysutcdatetime(), sysdatetime()),  CAST(CONVERT(Varchar(10), CAST(DATEADD(Day, DATEDIFF(Day, 0, @LastEndTIme),1) AS date), 112) + ' ' + CONVERT(Varchar(8), CAST(DATEADD(Day, DATEDIFF(Day, 0, @LastEndTIme),1) AS TIME)) AS DateTime))),
					   @LastFirstTIme
							 FROM #ShiftDataTable ORDER BY EndTime DESC
				END

					 			
				WHILE (@Id <= (SELECT COUNT(1) FROM #ShiftDataTable))
				    BEGIN
						 DECLARE @StartTime DATETIME = NULL,
						  @EndTime DATETIME = NULL,
						  @ShiftName Varchar(100) = NULL,
						  @TotalRunTimesec VARCHAR(100) = NULL,
						  @Hour INT = NULL,
						  @BatchStartTime DATETIME = NULL,
						  @BatchEndTime DATETIME = NULL

						  SELECT @StartTime = ST.StartTime,@EndTime = ST.EndTime,@ShiftName = ST.ShiftName FROM #ShiftDataTable ST WHERE RowNumber = @Id


						   SELECT TOP 1 @BatchStartTime = CAST(BD.StartDate AS datetime) FROM TCD.BatchData BD 
						   WHERE CAST(BD.StartDate AS datetime) >= @StartTime AND CAST(BD.EndDate AS datetime) <= @EndTime ORDER BY StartDate

						  SELECT  TOP 1 @BatchEndTime = CAST(BD.EndDate AS datetime) FROM TCD.BatchData BD 
						  WHERE CAST(BD.StartDate AS datetime) >= @StartTime AND CAST(BD.EndDate AS datetime) <= @EndTime  ORDER BY EndDate DESC

						  SELECT @Hour = DATEDIFF(HOUR,@BatchStartTime,@BatchEndTime)

							
						  INSERT INTO #OperationSummaryShiftTable
						  SELECT 
							 @ShiftName AS ShiftName
							,bd.BatchId
							,BD.ActualWeight
							,bd.StandardWeight
							,BD.MachineId
							,BD.GroupId
							,BD.MachineInternalId
							,BD.ProgramMasterId
							,(SELECT TOP 1 PRM.ProductId FROM TCD.ProductMaster PRM WHERE PRM.ProductId = BPD.ProductId) AS ProductId
							,COUNT(DISTINCT BD.BatchID) AS NoOfBatches,
							SUM(BPD.ActualQuantity),
							SUM(BPD.StandardQuantity),
							SUM(BWD.ActualQuantity),
							SUM(BWD.StandardQuantity),
							SUM(BED.ActualQuantity),
							SUM(BED.StandardQuantity),
			   				SUM(BPD.Price) AS [ChemicalCost],
							 SUM(BWD.Price) AS WaterCost,
							 SUM(BED.Price) AS EnergyCost						   
						    ,ETC.TextileId AS EcolabTextileId
							,ETC.CategoryName AS EcolabTextileCategoryName
							,CTC.TextileId AS PlantTextileId
							,CTC.Name AS PlantTextileCategoryName,
							@summingActualLoad
						     FROM 
							   TCD.BatchProductData BPD  
								 LEFT JOIN TCD.BatchData BD ON BPD.BatchID = BD.BatchID
								 LEFT OUTER JOIN
				                    TCD.BatchStepWaterUsageData BWD ON BD.BatchID = BWD.BatchID
				                    LEFT OUTER JOIN
				                    TCD.BatchEnergyUsageData BED ON BD.BatchID = BED.BatchID
								 LEFT OUTER JOIN TCD.ProgramMaster PM ON PM.ProgramId = BD.ProgramMasterId
								 LEFT JOIN TCD.EcolabTextileCategory ETC ON ETC.TextileId = PM.EcolabTextileCategoryId
								 LEFT OUTER JOIN TCD.ChainTextileCategory CTC ON  CTC.TextileId = PM.ChainTextileId
							   WHERE  BD.EndDate  >= @StartTime
												 AND BD.Enddate <= @EndTime
												 AND
								(BD.ProgramMasterId = @FormulaId OR ETC.TextileId = @EcolabTextileId OR CTC.TextileId = @TextileCareCustomerId)
								AND 
								CASE @Machine   
										   WHEN '' THEN 'TRUE'         
										   ELSE                                                      
										    CASE WHEN BD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
										  END='TRUE'
								    AND       

								          

								    CASE @machineGroup   
									WHEN '' THEN 'TRUE'         
									ELSE                                                      
									 CASE WHEN BD.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable) THEN 'TRUE' END                                                      
								    END='TRUE' 

								    AND    

								    CASE @Formula   
									WHEN '' THEN 'TRUE'         
									ELSE                                                      
									 CASE WHEN BD.ProgramNumber IN (SELECT Formula FROM @FormulaTable) THEN 'TRUE' END                                                      
								    END='TRUE' 

								    AND       

								    CASE @MachineType   
									WHEN '' THEN 'TRUE'         
									ELSE                                                      
									 CASE WHEN BD.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable)) THEN 'TRUE' END                                                      
								    END='TRUE' 

								    AND       
								   CASE @Category   
									WHEN '' THEN 'TRUE'         
									ELSE                                                      
									 CASE WHEN ETC.TextileId IN (SELECT Category FROM @CategoryTable) THEN 'TRUE' END                                                      
								    END='TRUE' 

								    AND
									CASE @GroupId 
									WHEN '' THEN 'TRUE' 
									ELSE        
								    CASE WHEN (BD.GroupId IN (@GroupId) AND 
									 BD.MachineInternalId IN (@MachineInternalId)) THEN 'TRUE' END                                                   
								    END='TRUE' 
								    AND
									CASE @MachineInternalId 
									WHEN '' THEN 'TRUE' 
									ELSE        
								    CASE WHEN (BD.GroupId IN (@GroupId) AND 
									 BD.MachineInternalId IN (@MachineInternalId)) THEN 'TRUE' END                                                   
								    END='TRUE' 
								--AND
								--CASE @FormulaId   
								-- WHEN '' THEN 'TRUE'         
								-- ELSE                                                      
								--  CASE WHEN BD.ProgramMasterId = @FormulaId THEN 'TRUE' END                                                      
								-- END='TRUE' 

								--AND       
								
								--CASE @EcolabTextileId   
								-- WHEN '' THEN 'TRUE'         
								-- ELSE                                                      
								--  CASE WHEN ETC.TextileId = @EcolabTextileId THEN 'TRUE' END                                                      
								-- END='TRUE' 

								--AND       
								--CASE @TextileCareCustomerId   
								-- WHEN '' THEN 'TRUE'         
								-- ELSE                                                      
								--  CASE WHEN CTC.TextileId = @TextileCareCustomerId THEN 'TRUE' END                                                      
								-- END='TRUE' 
								 
						GROUP BY  BD.MachineId,BD.BatchId,BD.GroupId,BD.MachineInternalId,BD.ProgramMasterId,ETC.CategoryName,ETC.TextileId
						    ,BPD.ProductId,CTC.Name,CTC.TextileId,BD.ActualWeight,bd.StandardWeight								
						   SET @Id = @Id + 1
				    END

						       
				    IF(@ReportID = 10)
				    BEGIN

				   	   SELECT 
							 0 AS Id,
							 DateRange AS DateRange,
							 SUM([ActualWeight]) AS TotalLoad,
							 SUM([ActualWeight]) * 100/ summingActualLoad AS ProductionMix,
							 COUNT(DISTINCT PDT.BatchId) AS NumberOfLoads,
							  SUM(PDT.ActualWaterWeight) AS ActualWaterUsage,
							   CAST(SUM(PDT.ActualWaterWeight)/COUNT(PDT.BatchId) AS decimal(18,2)) AS ActualWaterUsagePerLoad,
							 CAST(SUM(PDT.StandardWaterWeight)/COUNT(PDT.BatchId) AS decimal(18,2)) AS TargetWaterUsagePerLoad,
							 SUM(PDT.ActualEnergyWeight) AS ActualEnergyUsage,
							 CAST(SUM(PDT.ActualEnergyWeight)/COUNT(PDT.BatchId) AS decimal(18,2)) AS ActualEnergyUsagePerLoad,
							 CAST(SUM(PDT.StandardEnergyWeight)/COUNT(PDT.BatchId) AS decimal(18,2)) AS TargetEnergyUsagePerLoad,
							 CAST(SUM(PDT.ActualChemicalWeight)/COUNT(PDT.BatchId) AS decimal(18,2)) AS ActualChemicalUsageperLoad,
							 CAST(SUM(PDT.StandardChemicalWeight)/COUNT(PDT.BatchId) AS decimal(18,2)) AS TargetChemicalUsageperLoad,
							  @IsDrillDown AS IsDrillDown,
							 'Shift' AS SwithMode,
							 CAST(SUM(PDT.[ActualChemicalWeight]) AS Decimal(18,2)) AS ActualChemicalWeight,
							 CAST(SUM(PDT.[ActualWaterWeight]) AS Decimal(18,2)) AS ActualWaterWeight,
							 CAST(SUM(PDT.[ActualEnergyWeight]) AS Decimal(18,2)) AS ActualEnergyWeight,
							 CAST(SUM(PDT.[StandardChemicalWeight]) AS Decimal(18,2)) AS StandardChemicalWeight,
							 CAST(SUM(PDT.[StandardWaterWeight]) AS Decimal(18,2)) AS StandardWaterWeight,
							 CAST(SUM(PDT.[StandardEnergyWeight]) AS Decimal(18,2)) AS StandardEnergyWeight,
							 SUM(ChemicalCost) AS [ChemicalCost],
							 SUM(WaterCost) AS WaterCost,
							 SUM(EnergyCost) AS EnergyCost
							 
							  INTO #ShiftResultTable							
							 FROM #OperationSummaryShiftTable PDT
							 WHERE PDT.DateRange NOT Like '%Noshift%' AND
							 CASE @FormulaId   
								 WHEN '' THEN 'TRUE'         
								 ELSE                                                      
								  CASE WHEN PDT.ProgramNumber = @FormulaId THEN 'TRUE' END                                                   
								 END='TRUE' 
								AND    
								
								CASE @EcolabTextileId   
								 WHEN '' THEN 'TRUE'         
								 ELSE                                                      
								  CASE WHEN PDT.EcolabTextileId = @EcolabTextileId THEN 'TRUE' END                                                      
								 END='TRUE' 

								AND       
								CASE @TextileCareCustomerId   
								 WHEN '' THEN 'TRUE'         
								 ELSE                                                      
								  CASE WHEN PDT.PlantTextileId = @TextileCareCustomerId THEN 'TRUE' END                                                      
								 END='TRUE' 
							 GROUP BY DateRange,summingActualLoad
							
							INSERT INTO #ShiftResultTable
							  SELECT 
							 0 AS Id,
							 DateRange,
							 SUM([ActualWeight]) AS TotalLoad,
							 SUM([ActualWeight]) * 100/ summingActualLoad AS ProductionMix,
							 COUNT(DISTINCT PDT.BatchId) AS NumberOfLoads,
							  SUM(PDT.ActualWaterWeight) AS ActualWaterUsage,
							   CAST(SUM(PDT.ActualWaterWeight)/COUNT(PDT.BatchId) AS decimal(18,2)) AS ActualWaterUsagePerLoad,
							 CAST(SUM(PDT.StandardWaterWeight)/COUNT(PDT.BatchId) AS decimal(18,2)) AS TargetWaterUsagePerLoad,
							 SUM(PDT.ActualEnergyWeight) AS ActualEnergyUsage,
							 CAST(SUM(PDT.ActualEnergyWeight)/COUNT(PDT.BatchId) AS decimal(18,2)) AS ActualEnergyUsagePerLoad,
							 CAST(SUM(PDT.StandardEnergyWeight)/COUNT(PDT.BatchId) AS decimal(18,2)) AS TargetEnergyUsagePerLoad,
							 CAST(SUM(PDT.ActualChemicalWeight)/COUNT(PDT.BatchId) AS decimal(18,2)) AS ActualChemicalUsageperLoad,
							 CAST(SUM(PDT.StandardChemicalWeight)/COUNT(PDT.BatchId) AS decimal(18,2)) AS TargetChemicalUsageperLoad,
							  @IsDrillDown AS IsDrillDown,
							 'Shift' AS SwithMode,
							 CAST(SUM(PDT.[ActualChemicalWeight]) AS Decimal(18,2)) AS ActualChemicalWeight,
							 CAST(SUM(PDT.[ActualWaterWeight]) AS Decimal(18,2)) AS ActualWaterWeight,
							 CAST(SUM(PDT.[ActualEnergyWeight]) AS Decimal(18,2)) AS ActualEnergyWeight,
							 CAST(SUM(PDT.[StandardChemicalWeight]) AS Decimal(18,2)) AS StandardChemicalWeight,
							 CAST(SUM(PDT.[StandardWaterWeight]) AS Decimal(18,2)) AS StandardWaterWeight,
							 CAST(SUM(PDT.[StandardEnergyWeight]) AS Decimal(18,2)) AS StandardEnergyWeight,
							 SUM(ChemicalCost) AS [ChemicalCost],
							 SUM(WaterCost) AS WaterCost,
							 SUM(EnergyCost) AS EnergyCost							
							 FROM #OperationSummaryShiftTable PDT
							 WHERE PDT.DateRange Like '%Noshift%' AND
							 CASE @FormulaId   
								 WHEN '' THEN 'TRUE'         
								 ELSE                                                      
								  CASE WHEN PDT.ProgramNumber = @FormulaId THEN 'TRUE' END                                                   
								 END='TRUE' 
								AND    
								
								CASE @EcolabTextileId   
								 WHEN '' THEN 'TRUE'         
								 ELSE                                                      
								  CASE WHEN PDT.EcolabTextileId = @EcolabTextileId THEN 'TRUE' END                                                      
								 END='TRUE' 

								AND       
								CASE @TextileCareCustomerId   
								 WHEN '' THEN 'TRUE'         
								 ELSE                                                      
								  CASE WHEN PDT.PlantTextileId = @TextileCareCustomerId THEN 'TRUE' END                                                      
								 END='TRUE' 
							 GROUP BY DateRange,summingActualLoad


				    SET @SQLStatement 
					   ='SELECT 
							Id,
							DateRange,
							TotalLoad,
							ProductionMix,
							NumberOfLoads,
							ActualWaterUsage,
							ActualWaterUsagePerLoad,
							TargetWaterUsagePerLoad,
							ActualEnergyUsage,
							ActualEnergyUsagePerLoad,
							TargetEnergyUsagePerLoad,
							ActualChemicalUsageperLoad,
							TargetChemicalUsageperLoad,
							SwithMode,IsDrillDown,
							ActualChemicalWeight,
							ActualWaterWeight,
							 ActualEnergyWeight,
							 StandardChemicalWeight,
							 StandardWaterWeight,
							  StandardEnergyWeight,
							  ChemicalCost,
							  WaterCost,
							   EnergyCost
					    FROM #ShiftResultTable WHERE TotalLoad IS NOT NULL ORDER BY ' + @SortField + ' ' + @SortDirection

	   			    EXEC(@SQLStatement)
				    END
				   
				    DROP TABLE #ShiftResultTable
				    DROP TABLE #ShiftDataTable
				  

END
