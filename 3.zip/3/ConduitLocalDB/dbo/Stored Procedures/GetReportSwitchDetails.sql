CREATE PROCEDURE [TCD].[GetReportSwitchDetails] 
(
			@ReportId Int = NULL		
)
AS   

BEGIN   
SET NOCOUNT ON
SELECT 
		 RS.SwitchModeId,
		 RS.SwitchName
	    FROM [TCD].ReportSwitchMode RS
			INNER JOIN [TCD].ReportSwitchModemAPPING RSM ON RS.SwitchModeId = RSM.SwitchModeId 
	    WHERE RSM.ReportId = @ReportId			  
SET NOCOUNT OFF
END