--exec [TCD].[GetOperationSummarySwitchReport] @Corporate=N'',@Country=N'',@Region=N'',@EcolabAccountNumber=N'',@Machine=N'',@machineGroup=N'',@Formula=N'',@MachineType=N'',
--@Category=N'',@FromDate='2015-01-01 00:00:00',@ToDate='2015-01-12 00:00:00',@GroupId=N'',@MachineInternalId=N'',
--@FormulaWise=1,@EcolabTextileWise=0,@TextileCareCustomerWise=0,@SortColumnID = 0,@SortDirection= 'dESC', @UserId = NULL,@IsDrillDown = 0


CREATE PROCEDURE [TCD].[GetOperationSummarySwitchReport] (
											    @Corporate Varchar(max) = '',
												@Country Varchar(max) = '',
												@Region Varchar(max) = '',
												@EcolabAccountNumber Nvarchar(25) = '',
												@Machine Varchar(max) = '', 
												@machineGroup Varchar(max) = '',
												@Formula Varchar(max) = '',
												@MachineType Varchar(20)= '',
												@Category Varchar(max) = '',
												@FromDate Date = '',
												@ToDate Date = '',
												@GroupId Varchar(max) = '',
												@MachineInternalId Varchar(max) = '',
												 --@Customer Varchar(max) = '',
												@FormulaWise bit = NULL,
												@EcolabTextileWise bit = NULL,
												@TextileCareCustomerWise bit = NULL,
												@SortColumnID INT = NULL,
												@SortDirection Varchar(100) = '',
												@UserId Int = NULL,
												@IsDrillDown BIT										 
											  )
AS   
BEGIN   
SET NOCOUNT ON;   

DECLARE @ReportGenerated INT = 6, 
	   @SortField Varchar(100) = '',
	   @SQLStatement varchar(max)
	  
 SET	@Corporate			=			ISNULL(@Corporate, NULL)			--SQLEnlight SA0029
 SET	@Country			=			ISNULL(@Country, NULL)				--SQLEnlight SA0029

 SELECT @SortField =  CASE WHEN @SortColumnID = 3 THEN 'ActualChemicalUsageperLoad'
						    WHEN @SortColumnID = 7 THEN 'ActualEnergyUsage'
						    WHEN @SortColumnID = 8 THEN 'ActualEnergyUsagePerLoad'
						    WHEN @SortColumnID = 10 THEN 'ActualWaterUsagePerLoad'
						    WHEN @SortColumnID = 11 THEN 'ActualWaterUsage'
						    WHEN @SortColumnID = 43 THEN 'TargetChemicalUsageperLoad'						
						    WHEN @SortColumnID = 77 THEN 'TargetEnergyUsagePerLoad'
						    WHEN @SortColumnID = 83 THEN 'FormulaName'
						    WHEN @SortColumnID = 127 THEN 'ProductionMix'
						    WHEN @SortColumnID = 133 THEN 'NumberOfLoads'
						    WHEN @SortColumnID = 200 THEN 'TotalLoad'
						    WHEN @SortColumnID = 187 THEN 'TargetWaterUsagePerLoad'
						    WHEN @SortColumnID = 194 THEN 'EcolabTextileCategory'
						    WHEN @SortColumnID = 245 THEN 'PlantTextileCategoryName'
						    WHEN @SortColumnID = 0 THEN 'TotalLoad'
					 END



DECLARE @Month INT = MONTH(GETDATE()),
	   @SummationInMin Int = NULL,@summingActualLoad Decimal(18,2) = NULL

DECLARE @CategoryTable TABLE(Category VARCHAR(100))
INSERT INTO @CategoryTable(Category) EXEC [TCD].[CharlistToTable] @Category,','


DECLARE @MachineTable TABLE(Machine VARCHAR(100))
INSERT INTO @MachineTable(Machine) EXEC [TCD].[CharlistToTable] @Machine,','


DECLARE @GroupMachineTable TABLE(GroupId INT,MachineInternalId INT)  
INSERT INTO @GroupMachineTable(GroupId,MachineInternalId)   
SELECT GroupId,MachineInternalId 
FROM 
TCD.MachineSetup MS 
INNER JOIN TCD.Washer WS ON MS.WasherId = WS.WasherId 
WHERE WS.PlantWasherNumber IN (SELECT Machine FROM @MachineTable);


DECLARE @GroupTable TABLE(GroupId VARCHAR(100))
INSERT INTO @GroupTable(GroupId) EXEC [TCD].[CharlistToTable] @GroupId,','


DECLARE @MachineInternalTable TABLE(MachineInternalId VARCHAR(100))
INSERT INTO @MachineInternalTable(MachineInternalId) EXEC [TCD].[CharlistToTable] @MachineInternalId,','

DECLARE @WasherGroupTable TABLE(MachineGroup VARCHAR(100))
INSERT INTO @WasherGroupTable(MachineGroup) EXEC [TCD].[CharlistToTable] @MachineGroup,','


DECLARE @FormulaTable TABLE(Formula VARCHAR(100))
INSERT INTO @FormulaTable(Formula) EXEC [TCD].[CharlistToTable] @Formula,','


--DECLARE @CustomerTable TABLE(Customer VARCHAR(100))
--INSERT INTO @CustomerTable EXEC [TCD].[CharlistToTable] @Customer,','


DECLARE @MachineTypeTable TABLE(MachineType VARCHAR(100))
INSERT INTO @MachineTypeTable(MachineType) EXEC [TCD].[CharlistToTable] @MachineType,','


	  DECLARE @OperationsSummaryTable TABLE(
								 [RecordDate] [date] NULL,
								 [BatchId] [int] NULL,
								 [ActualWeight] [decimal](18, 2) NULL,
								 [StandardWeight] [decimal](18, 2) NULL,
								 [MachineId] [int] NULL,
								 [GroupId] [int] NULL,
								 [MachineInternalId] [int] NULL,
								 [ProgramNumber] [int] NULL,
								 [ProductId] [int] NULL,
								 [NoOfBatches] [int] NULL,
								 [ActualChemicalWeight] [decimal](18, 2) NULL,
								 [StandardChemicalWeight] [decimal](18, 2) NULL,
								 [ActualWaterWeight] [decimal](18, 2) NULL,
								 [StandardWaterWeight] [decimal](18, 2) NULL,
								 [ActualEnergyWeight] [decimal](18, 2) NULL,
								 [StandardEnergyWeight] [decimal](18, 2) NULL,
								 [ChemicalCost] [decimal](18, 2) NULL,
								 [WaterCost] [decimal](18, 2) NULL,
								 [EnergyCost] [decimal](18, 2) NULL,
								 [EcolabTextileId] [int] NULL,
								 [EcolabTextileCategoryName] [varchar](100) NULL,
								 [PlantTextileId] [int] NULL,
								 [PlantTextileCategoryName] [varchar](100) NULL			    
								  )


			  /* Including the Latest Batch Data */

	   		  IF((CAST(@ToDate AS DATE) = CAST(GETUTCDATE() AS date)))
				    BEGIN				     

					EXEC [TCD].[WaterAndEnergyDataRollUp] @ToDate

					END

			 /* Ending the Latest Batch Data Logic */


	   INSERT INTO @OperationsSummaryTable(
								 [RecordDate],
								 [BatchId],
								 [ActualWeight] ,
								 [StandardWeight],
								 [MachineId],
								 [GroupId],
								 [MachineInternalId],
								 [ProgramNumber],
								 [ProductId],
								 [NoOfBatches] ,
								 [ActualChemicalWeight],
								 [StandardChemicalWeight],
								 [ActualWaterWeight],
								 [StandardWaterWeight],
								 [ActualEnergyWeight],
								 [StandardEnergyWeight] ,
								 [ChemicalCost] ,
								 [WaterCost],
								 [EnergyCost],
								 [EcolabTextileId],
								 [EcolabTextileCategoryName],
								 [PlantTextileId],
								 [PlantTextileCategoryName]		    
								  )
	  
									   SELECT [RecordDate]
										    ,[BatchId]
										    ,[ActualWeight]
										    ,[StandardWeight]
										    ,[MachineId]
										    ,[GroupId]
										    ,[MachineInternalId]
										    ,[ProgramNumber]
										    ,[ProductId]
										    ,[NoOfBatches]
										    ,[ActualChemicalWeight]
										    ,[StandardChemicalWeight]
										    ,[ActualWaterWeight]
										    ,[StandardWaterWeight]
										    ,[ActualEnergyWeight]
										    ,[StandardEnergyWeight]
										    ,[ChemicalCost]
										    ,[WaterCost]
										    ,[EnergyCost]
										    ,[EcolabTextileId]
										    ,[EcolabTextileCategoryName]
										    ,[PlantTextileId]
										    ,[PlantTextileCategoryName]
										FROM [TCD].[BatchWaterandEnergyRollUp] BD
								WHERE
								CASE @Machine   
										   WHEN '' THEN 'TRUE'         
										   ELSE                                                      
										    CASE WHEN BD.MachineId IN (SELECT Machine FROM @MachineTable) THEN 'TRUE' END                                                 
										  END='TRUE'
								    AND       

								    CASE @machineGroup   
									WHEN '' THEN 'TRUE'         
									ELSE                                                      
									 CASE WHEN BD.GroupId IN (SELECT MachineGroup FROM  @WasherGroupTable) THEN 'TRUE' END                                                      
								    END='TRUE' 

								    AND    

								    CASE @Formula   
									WHEN '' THEN 'TRUE'         
									ELSE                                                      
									 CASE WHEN BD.ProgramNumber IN (SELECT Formula FROM @FormulaTable) THEN 'TRUE' END                                                      
								    END='TRUE' 

								    AND     
								           
								    CASE @FromDate                                                                                
								    WHEN '' THEN Case WHEN MONTH(BD.RecordDate) = @Month Then  'true' END                                                                                
								    ELSE CASE WHEN BD.RecordDate >= @FromDate and BD.RecordDate<dateadd(dd,1,@ToDate) THEN 'true'END                                                        
								    END='true'

								    AND  

								    CASE @MachineType   
									WHEN '' THEN 'TRUE'         
									ELSE                                                      
									 CASE WHEN BD.GroupId IN (SELECT WG.WasherGroupId FROM TCD.WasherGroup WG WHERE WG.WasherGroupTypeId IN (SELECT MachineType FROM @MachineTypeTable)) THEN 'TRUE' END                                                      
								    END='TRUE' 

								    AND       
								   CASE @Category   
									WHEN '' THEN 'TRUE'         
									ELSE                                                      
									 CASE WHEN BD.EcolabTextileId IN (SELECT Category FROM @CategoryTable) THEN 'TRUE' END                                                      
								    END='TRUE' 

								    AND
									CASE @GroupId 
									WHEN '' THEN 'TRUE' 
									ELSE        
								    CASE WHEN (BD.GroupId IN (@GroupId) AND 
									 BD.MachineInternalId IN (@MachineInternalId)) THEN 'TRUE' END                                                   
								    END='TRUE' 
								    AND
									CASE @MachineInternalId 
									WHEN '' THEN 'TRUE' 
									ELSE        
								    CASE WHEN (BD.GroupId IN (@GroupId) AND 
									 BD.MachineInternalId IN (@MachineInternalId)) THEN 'TRUE' END                                                   
								    END='TRUE' 
							
		   SELECT @summingActualLoad=  SUM(ActualWeight)  FROM @OperationsSummaryTable 
		  
			 	/* Switch Category FormaulaWise */
		  
		  IF(@FormulaWise = 1)
		  BEGIN		  
		 
		    SELECT 
			     PDT.ProgramNumber,
				Cast(PDT.ProgramNumber AS VARCHAR(1000)) + CHAR(13) + CHAR(13) + PM.Name AS FormulaName,
				SUM(PDT.ActualWeight) AS TotalLoad,
				CAST(SUM(PDT.ActualWeight) * 100/@summingActualLoad AS DECIMAL(18,2)) AS ProductionMix,
				COUNT(DISTINCT PDT.BatchId) AS NumberOfLoads,
				SUM(PDT.ActualWaterWeight) AS ActualWaterUsage,
				CAST(SUM(PDT.ActualWaterWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS ActualWaterUsagePerLoad,
				CAST(SUM(PDT.StandardWaterWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS TargetWaterUsagePerLoad,
				SUM(PDT.ActualEnergyWeight) AS ActualEnergyUsage,
				CAST(SUM(PDT.ActualEnergyWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS ActualEnergyUsagePerLoad,
				CAST(SUM(PDT.StandardEnergyWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS TargetEnergyUsagePerLoad,
				CAST(SUM(PDT.ActualChemicalWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS ActualChemicalUsageperLoad,
				CAST(SUM(PDT.StandardChemicalWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS TargetChemicalUsageperLoad,
				'Formula' AS SwithMode,
				@IsDrillDown AS IsDrillDown,
				CAST(SUM([ActualChemicalWeight]) AS Decimal(18,2)) AS ActualChemicalWeight,
				CAST(SUM([ActualWaterWeight]) AS Decimal(18,2)) AS [ActualWaterWeight],
				CAST(SUM([ActualEnergyWeight]) AS Decimal(18,2)) AS [ActualEnergyWeight],
				CAST(SUM([StandardChemicalWeight]) AS Decimal(18,2)) AS StandardChemicalWeight,
				CAST(SUM([StandardWaterWeight]) AS Decimal(18,2)) AS [StandardWaterWeight],
				CAST(SUM([StandardEnergyWeight]) AS Decimal(18,2)) AS [StandardEnergyWeight],
				SUM(ChemicalCost) AS [ChemicalCost],
				SUM(WaterCost) AS WaterCost,
				SUM(EnergyCost) AS EnergyCost

				INTO #ProdTableFormulaOrder
			 FROM @OperationsSummaryTable PDT INNER JOIN TCD.ProgramMaster PM ON PDT.ProgramNumber = pm.ProgramId
			 WHERE (PDT.ProgramNumber IS NOT NULL OR PM.Name IS NOT NULL)
			  GROUP BY PDT.ProgramNumber,Name

			  SET @SQLStatement 
					   ='SELECT * FROM #ProdTableFormulaOrder ORDER BY ' + @SortField + ' ' + @SortDirection

	   			EXEC(@SQLStatement)
		  END
				
				
			 /* Switch Category TextileCategory Ecolab */

		  IF(@EcolabTextileWise = 1)
		  BEGIN

							
			 SELECT 
				EcolabTextileId,
				EcolabTextileCategoryName AS EcolabTextileCategory,
				SUM(PDT.ActualWeight) AS TotalLoad,
			CAST(SUM(PDT.ActualWeight) * 100/@summingActualLoad AS DECIMAL(18,2)) AS ProductionMix,
				COUNT(DISTINCT PDT.BatchId) AS NumberOfLoads,
				SUM(PDT.ActualWaterWeight) AS ActualWaterUsage,
				CAST(SUM(PDT.ActualWaterWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS ActualWaterUsagePerLoad,
				CAST(SUM(PDT.StandardWaterWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS TargetWaterUsagePerLoad,
				SUM(PDT.ActualEnergyWeight) AS ActualEnergyUsage,
				CAST(SUM(PDT.ActualEnergyWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS ActualEnergyUsagePerLoad,
				CAST(SUM(PDT.StandardEnergyWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS TargetEnergyUsagePerLoad,
				CAST(SUM(PDT.ActualChemicalWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS ActualChemicalUsageperLoad,
				CAST(SUM(PDT.StandardChemicalWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS TargetChemicalUsageperLoad,
				'Textile Category' AS SwithMode,@IsDrillDown AS IsDrillDown,
				CAST(SUM([ActualChemicalWeight]) AS Decimal(18,2)) AS ActualChemicalWeight,
				CAST(SUM([ActualWaterWeight]) AS Decimal(18,2)) AS [ActualWaterWeight],
				CAST(SUM([ActualEnergyWeight]) AS Decimal(18,2)) AS [ActualEnergyWeight],
				CAST(SUM([StandardChemicalWeight]) AS Decimal(18,2)) AS StandardChemicalWeight,
				CAST(SUM([StandardWaterWeight]) AS Decimal(18,2)) AS [StandardWaterWeight],
				CAST(SUM([StandardEnergyWeight]) AS Decimal(18,2)) AS [StandardEnergyWeight],
				SUM(ChemicalCost) AS [ChemicalCost],
				SUM(WaterCost) AS WaterCost,
				SUM(EnergyCost) AS EnergyCost				
				
				 INTO #ProdTableEcoTextileOrder
				FROM @OperationsSummaryTable PDT
				WHERE (PDT.EcolabTextileId IS NOT NULL OR PDT.EcolabTextileCategoryName IS NOT NULL) 
			  GROUP BY EcolabTextileId,EcolabTextileCategoryName

			   SET @SQLStatement 
					   ='SELECT * FROM #ProdTableEcoTextileOrder ORDER BY ' + @SortField + ' ' + @SortDirection

	   			EXEC(@SQLStatement)

		  END

    
			 /* Switch Category PlantTextileWise */
		  
		  IF(@TextileCareCustomerWise = 1)
		  BEGIN
			 SELECT 
				PlantTextileId,
				PlantTextileCategoryName,
				SUM(PDT.ActualWeight) AS TotalLoad,
				CAST(SUM(PDT.ActualWeight) * 100/@summingActualLoad AS DECIMAL(18,2)) AS ProductionMix,
				COUNT(DISTINCT PDT.BatchId) AS NumberOfLoads,
				SUM(PDT.ActualWaterWeight) AS ActualWaterUsage,
				CAST(SUM(PDT.ActualWaterWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS ActualWaterUsagePerLoad,
				CAST(SUM(PDT.StandardWaterWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS TargetWaterUsagePerLoad,
				SUM(PDT.ActualEnergyWeight) AS ActualEnergyUsage,
				CAST(SUM(PDT.ActualEnergyWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS ActualEnergyUsagePerLoad,
				CAST(SUM(PDT.StandardEnergyWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS TargetEnergyUsagePerLoad,
				CAST(SUM(PDT.ActualChemicalWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS ActualChemicalUsageperLoad,
				CAST(SUM(PDT.StandardChemicalWeight)/COUNT(DISTINCT PDT.BatchId) AS decimal(18,2)) AS TargetChemicalUsageperLoad,
				'Texttile Category Customer' AS SwithMode,@IsDrillDown AS IsDrillDown,
				CAST(SUM([ActualChemicalWeight]) AS Decimal(18,2)) AS ActualChemicalWeight,
				CAST(SUM([ActualWaterWeight]) AS Decimal(18,2)) AS [ActualWaterWeight],
				CAST(SUM([ActualEnergyWeight]) AS Decimal(18,2)) AS [ActualEnergyWeight],
				CAST(SUM([StandardChemicalWeight]) AS Decimal(18,2)) AS StandardChemicalWeight,
				CAST(SUM([StandardWaterWeight]) AS Decimal(18,2)) AS [StandardWaterWeight],
				CAST(SUM([StandardEnergyWeight]) AS Decimal(18,2)) AS [StandardEnergyWeight],
				SUM(ChemicalCost) AS [ChemicalCost],
				SUM(WaterCost) AS WaterCost,
				SUM(EnergyCost) AS EnergyCost
				
				INTO #ProdTablePlantTextileOrder
			 FROM @OperationsSummaryTable PDT
			 WHERE (PDT.PlantTextileId IS NOT NULL OR PDT.PlantTextileCategoryName IS NOT NULL)
			  GROUP BY PlantTextileId,PlantTextileCategoryName

			    SET @SQLStatement 
					   ='SELECT * FROM #ProdTablePlantTextileOrder ORDER BY ' + @SortField + ' ' + @SortDirection

	   			EXEC(@SQLStatement)

		  END

					
    END