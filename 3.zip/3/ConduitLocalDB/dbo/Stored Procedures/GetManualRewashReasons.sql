/*	                                   
###################################################################################################                                           

Stored Procedure:       [dbo].[usp_GetManualRewashReasons]                                        

Purpose:				To get the manual rewash reasons.

Parameters:				None
																																		
###################################################################################################                                           
*/
CREATE PROCEDURE [TCD].[GetManualRewashReasons] 
AS 
  BEGIN 
      SET NOCOUNT ON;
	 
	  SELECT 
				  RewashReasonId,
				  [Description]
      FROM   
				[TCD].RewashReason WHERE IsDeleted = 0
       SET NOCOUNT OFF;
  END