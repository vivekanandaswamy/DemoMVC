﻿CREATE FUNCTION [TCD].[FnConsumptionOnMetrics]
(
--DECLARE
								@ValueTobeConverted decimal(18,2) = NULL,
								@Unit  varchar(100) = NULL,
								@UserId int = NULL
							)
	RETURNS decimal(18,4)
	AS 
	BEGIN
	   DECLARE @Result float,@UOMId int
		  
			 SELECT @UOMId =  UM.UOMId FROM TCD.UserMaster AS UM WHERE UM.UserId = @UserId

			 SELECT @Result = CASE @Unit WHEN 'Volume' THEN CASE @UOMId WHEN 1 THEN @ValueTobeConverted * 0.0078125  -- to be converted to gal as db saving in ounce
													WHEN 2 THEN @ValueTobeConverted * 0.0295735 END
						    WHEN 'Weight' THEN CASE @UOMId WHEN 1 THEN @ValueTobeConverted		     -- to be converted to gal as db saving in ounce
													WHEN 2 THEN @ValueTobeConverted * 0.453592 END
														        
						   END		  
			
		   RETURN(@Result)

    END
