﻿CREATE FUNCTION [TCD].[FnUtf8ToNvarchar](
				@In VARCHAR(MAX))
RETURNS NVARCHAR(MAX)
AS
BEGIN
	DECLARE @Out NVARCHAR(MAX), 
			@I INT, 
			@C INT, 
			@C2 INT, 
			@C3 INT, 
			@Nc INT;

	SELECT
			@I = 1, 
			@Out = '';

	WHILE @I <= LEN(@In)
		BEGIN
			SET @C = ASCII(SUBSTRING(@In, @I, 1));

			IF @C < 128
				BEGIN
					SET @Nc = @C;
					SET @I = @I + 1;
				END;
			ELSE
				BEGIN
					IF @C > 191
				   AND @C < 224
						BEGIN
							SET @C2 = ASCII(SUBSTRING(@In, @I + 1, 1));

							SET @Nc = ((@C&31) * 64 

							/* << 6 */

							)|(@C2&63);
							SET @I = @I + 2;
						END;
					ELSE
						BEGIN
							SET @C2 = ASCII(SUBSTRING(@In, @I + 1, 1));
							SET @C3 = ASCII(SUBSTRING(@In, @I + 2, 1));

							SET @Nc = ((@C&15) * 4096 

							/* << 12 */

							)|((@C2&63) * 64 

							/* << 6 */

							)|(@C3&63);
							SET @I = @I + 3;
						END;;
				END;

			SET @Out = @Out + NCHAR(@Nc);
			END;
			IF (@out='' OR @out IS NULL)
					BEGIN
						RETURN @in
					END;		
	RETURN @Out;
END;
GO