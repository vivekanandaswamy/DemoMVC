CREATE FUNCTION [TCD].[FnChemicalCostInOunce]
(
        @ProductId INT
       )
 RETURNS fLOAT
 AS 
 BEGIN
 DECLARE @OunceCal Float
 DECLARE @ProductCal TABLE
      (
       ProductId INT,
       PackageSizeWeightUOMCode VARCHAR(20),
       UnitWeightVolumeUOMId INT,
       TotalVolume INT,
       Cost float
      )

 INSERT INTO @ProductCal
 SELECT 
   p.ProductId,
   s.PackageSizeWeightUOMCode,
   s.UnitWeightVolumeUOMId ,
   s.UnitPerPackage * s.UnitWeightVolume /( CASE WHEN isnull( p.Type,'Liquid')='Liquid' AND s.UnitWeightVolumeUOMId=1 THEN p.DensityFactor ELSE 1 END),
   m.Cost
   FROM tcd.PackageSize s JOIN tcd.ProductMaster p ON s.PackageSizeId = p.PackageSizeId
           JOIN tcd.ProductdataMapping m ON m.ProductID = p.ProductId
           WHERE P.ProductID = @ProductId
    
    SELECT @OunceCal = 
    COALESCE(Cost / NULLIF(
    TotalVolume * 
    (CASE UnitWeightVolumeUOMId WHEN 1 THEN 35.274--kg 
     WHEN  2 THEN 0.035274--g
     WHEN  5 THEN 1--oz
     WHEN  6 THEN 16--lbs
     WHEN  8 THEN 33.814 --L
     WHEN  10 THEN 0.033814--mL
     WHEN  12 THEN 128 --gal
     WHEN  13 THEN 32 END),0),0)   --qt(quart) 
     FROM @ProductCal PC

  if(@OunceCal IS NULL)
   BEGIN
    RETURN(0)
   END
  ELSE
   BEGIN
    RETURN(@OunceCal)
   END
   RETURN(@OunceCal)
  END


	

	  