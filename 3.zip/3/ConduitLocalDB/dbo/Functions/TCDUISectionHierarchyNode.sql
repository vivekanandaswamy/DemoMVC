﻿CREATE FUNCTION [TCD].[TCDUISectionHierarchyNode](@SectionId int)
RETURNS xml
    WITH RETURNS NULL ON NULL INPUT
BEGIN
    RETURN (SELECT
	SectionID AS [@SectionID],
	SectionName AS [@SectionName],
	UM.SectionCode AS [@SectionCode],
	UM.SectionType AS [@SectionType],
	UM.ControllerName AS [@ControllerName],
	UM.ViewName AS [@ViewName],
	UM.ResourceClass AS [@ResourceClass],
	UM.ResourceKey AS [@ResourceKey],
	CASE
		WHEN UM.ParentID IS NULL THEN NULL
		ELSE (SELECT SectionCode from [TCD].ConduitMenu   where SectionID=UM.ParentID)
	END AS [@ParentSectionCode],
	(SELECT
		USM.SettingCode AS [@SettingCode],
		USM.SettingValue AS [@SettingValue],
		USM.UserRole AS [@UserRole],
		ISNULL(USM.UserID, -1) AS [@UserId],
		ISNULL(USM.TagId, -1) AS [@TagId],
		ISNULL(USM.TagType, -1) AS [@TagType],
		USM.UsageUICode AS [@UsageUICode]
	FROM [TCD].[ConduitMenuRoleMapping] USM
	WHERE UM.SectionCode = USM.SectionCode
	FOR
	xml PATH ('SectionSetting'), TYPE)
	--dbo.ufn_enV_UiSectionHierarchyNode(SectionID)
FROM [TCD].[ConduitMenu] UM
WHERE ParentID = @SectionId
FOR
xml PATH ('UiSection'), TYPE);
END;

