﻿CREATE FUNCTION [TCD].[FnCurrencyExchangeRate]
       (  
        @CurrencyCode nvarchar(100) = NULL,  
        @dtDate datetime  
       
       )  
RETURNS float  
AS   
BEGIN  
  
DECLARE 
  @ExchangeRate FLOAT  
  
 IF @CurrencyCode IS NULL  
  SET @CurrencyCode = ISNULL(@CurrencyCode,'USD')  
  
-- SET @dtDate = DATETIMEFROMPARTS(@year,@Month,1, 23, 59, 59, 0 )  
  
SELECT top 1 @ExchangeRate = RATE  
FROM TCD.CurrencyExchangeRate  
WHERE currencyCode = @CurrencyCode  and TargetCurrencyCode='USD' 
AND EffectiveExchangeRateDate <= @dtDate  order by EffectiveExchangeRateDate  desc
--AND EffectiveExchangeRateDate IN (  
--SELECT MAX(EffectiveExchangeRateDate) FROM TCD.CurrencyExchangeRate  
--WHERE currencyCode = @CurrencyCode  
--AND EffectiveExchangeRateDate <= @dtDate  
--)  
  
SET @ExchangeRate = ISNULL(NULLIF(@ExchangeRate, 0.00),1)  
  
  
RETURN (COALESCE(1/ NULLIF(@ExchangeRate,0), 0))  
  
END
GO
