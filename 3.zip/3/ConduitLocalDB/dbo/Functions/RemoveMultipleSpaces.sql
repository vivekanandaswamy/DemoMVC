﻿CREATE FUNCTION [TCD].[RemoveMultipleSpaces](
				@Str NVARCHAR(MAX))
RETURNS NVARCHAR(MAX)
AS
BEGIN
	IF CHARINDEX('  ', @Str) = 0
		BEGIN
			RETURN @Str
		END;

	RETURN tcd.RemoveMultipleSpaces(REPLACE(@Str, '  ', ' '));
END;
GO 