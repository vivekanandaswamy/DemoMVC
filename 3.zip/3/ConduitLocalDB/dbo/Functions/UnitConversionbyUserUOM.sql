CREATE FUNCTION TCD.UnitConversionbyUserUOM(
                @Valuetobeconverted DECIMAL(18, 2) = NULL, 
                @Uomcode VARCHAR(100) = NULL, 
                @Userid INT = NULL)
RETURNS DECIMAL(18, 2)
AS
BEGIN
    DECLARE @Result FLOAT, 
            @Uomid INT;

    SELECT
            @Uomid = UM.UOMId FROM TCD.UserMaster AS UM WHERE UM.UserId = ISNULL(@Userid,1);

    SELECT
            @Result = @Valuetobeconverted * CASE
                                                WHEN @Uomid = 1 THEN CASE @Uomcode
                                                                         WHEN 'gal' THEN 0.0078125
                                                                         WHEN 'lbs' THEN 0.0625
                                                                         WHEN 'kg' THEN 0.0283495
                                                                         WHEN 'mL' THEN 29.5735
                                                                         WHEN 'qt' THEN 0.03125
                                                                         WHEN 'CAN' THEN 0.033814
                                                                         WHEN 'impgal' THEN 0.00650527
                                                                         WHEN 'L' THEN 0.0295735
                                                                         WHEN 'g' THEN 28.3495
                                                                     END
                                                WHEN @Uomid = 2 THEN CASE @Uomcode
                                                                         WHEN 'gal' THEN 0.0295735
                                                                         WHEN 'lbs' THEN 0.0283495
                                                                         WHEN 'kg' THEN 0.0283495
                                                                         WHEN 'mL' THEN 29.5735
                                                                         WHEN 'qt' THEN 0.03125
                                                                         WHEN 'CAN' THEN 0.033814
                                                                         WHEN 'impgal' THEN 0.00650527
                                                                         WHEN 'L' THEN 0.0295735
                                                                         WHEN 'g' THEN 28.3495
                                                                     END
                                            END;
  	  


    RETURN @Result;

END;
