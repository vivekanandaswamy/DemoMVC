﻿/*  
 ==========================================================================================  
 Purpose:  Fecthing the Get UOM for Utility 

 Author:  Santhosh

 --------------------------------------------------------------  
 Sep-01-2014 ENT: Initial version.  
 ==========================================================================================  
*/ 
CREATE FUNCTION [TCD].GetDimensionalUnits (@UsageKey NVARCHAR(500),@UnitSystemId INT)
RETURNS  @SubUnit TABLE 
(
    Subunit nvarchar(1000)
)
AS BEGIN
     Insert into @SubUnit select Subunit from [TCD].DimensionalUnitsDefaults where UsageKey = @UsageKey and UnitSystemId=@UnitSystemId

Return
END