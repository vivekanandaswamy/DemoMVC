﻿/*  
 ==========================================================================================  
 Purpose:  Insertion of Units and resource keys for plant utility setup.

 Author:  Santhosh 

 --------------------------------------------------------------  
 Sept-09-2014 ENT: Initial version.  
 ==========================================================================================  
*/ 

--------------------------
--- DimensionalUnits
--------------------------
Insert Into DimensionalUnits(Unit) Values('ElectricTariff')
GO
Insert into DimensionalUnits(Unit) Values('Price')
------------------------------------
-- DimensionalSubunits
------------------------------------

-- Electric Tariff Subunits
GO
Insert into DimensionalSubunits(Unit,Subunit)Values('ElectricTariff','dollar_per_unit')
GO
Insert into DimensionalSubunits(Unit,Subunit)Values('ElectricTariff','euro_per_unit')
GO
Insert into DimensionalSubunits(Unit,Subunit)Values('ElectricTariff','kilo_watt_hour_cubic_meter')

-- Price Subunits
GO
Insert into DimensionalSubunits(Unit,Subunit)Values('Price','dollar')
GO
Insert into DimensionalSubunits(Unit,Subunit)Values('Price','euro')
GO
Insert into DimensionalSubunits(Unit,Subunit)Values('Price','dollar_per_unit')
GO
Insert into DimensionalSubunits(Unit,Subunit)Values('Price','dollar_per_lbs')
GO
Insert into DimensionalSubunits(Unit,Subunit)Values('Price','euro_per_unit')
GO
Insert into DimensionalSubunits(Unit,Subunit)Values('Price','euro_per_lbs')

-----------------------------------------
-- DimensionalDisplayUnits
-----------------------------------------
-- Electric tariff
GO
Insert into DimensionalDisplayUnits(DisplayUnitID,Unit,Subunit,OrderID)Values(35,'ElectricTariff','kilo_watt_hour_cubic_meter',1)

-- Price
GO
Insert into DimensionalDisplayUnits(DisplayUnitID,Unit,Subunit,OrderID)Values(36,'Price','dollar',1)
GO
Insert into DimensionalDisplayUnits(DisplayUnitID,Unit,Subunit,OrderID)Values(36,'Price','euro',2)
GO
Insert into DimensionalDisplayUnits(DisplayUnitID,Unit,Subunit,OrderID)Values(36,'Price','dollar_per_unit',3)
GO
Insert into DimensionalDisplayUnits(DisplayUnitID,Unit,Subunit,OrderID)Values(36,'Price','dollar_per_lbs',4)
GO
Insert into DimensionalDisplayUnits(DisplayUnitID,Unit,Subunit,OrderID)Values(36,'Price','euro_per_unit',5)
GO
Insert into DimensionalDisplayUnits(DisplayUnitID,Unit,Subunit,OrderID)Values(36,'Price','euro_per_lbs',6)

-------------------------------
--- DimensionalUsageKey
-------------------------------
-- Electric Tariff
GO
Insert into DimensionalUsageKey(UsageKey,Unit,DisplayUnitID)Values('Energy_Content_TCD','ElectricTariff',35)		

-- Price
GO
Insert into DimensionalUsageKey(UsageKey,Unit,DisplayUnitID)Values('Price_Tcd','Price',36)
GO
Insert into DimensionalUsageKey(UsageKey,Unit,DisplayUnitID)Values('Price_Electric_Tariff_Tcd','Price',36)
GO
Insert into DimensionalUsageKey(UsageKey,Unit,DisplayUnitID)Values('Price_GasOil_Tcd','Price',36)

-------------------------------------------------------
--DimensionalUnitsDefaults
-------------------------------------------------------
	----------------------------
	 -- SystemId=1
	---------------------------

-- Electric Tariff
GO
Insert into DimensionalUnitsDefaults(UnitSystemId,UsageKey,Unit,Subunit)Values(1,'Energy_Content_TCD','ElectricTariff','kilo_watt_hour_cubic_meter')		

-- Price
GO
Insert into DimensionalUnitsDefaults(UnitSystemId,UsageKey,Unit,Subunit)Values(1,'Price_Tcd','Price','dollar')
GO
Insert into DimensionalUnitsDefaults(UnitSystemId,UsageKey,Unit,Subunit)Values(1,'Price_Electric_Tariff_Tcd','Price','dollar_per_unit')
GO
Insert into DimensionalUnitsDefaults(UnitSystemId,UsageKey,Unit,Subunit)Values(1,'Price_GasOil_Tcd','Price','dollar_per_lbs')
GO

	----------------------------
	 -- SystemId=2
	---------------------------

-- Electric Tariff
Insert into DimensionalUnitsDefaults(UnitSystemId,UsageKey,Unit,Subunit)Values(2,'Energy_Content_TCD','ElectricTariff','kilo_watt_hour_cubic_meter')		

-- Price
GO
Insert into DimensionalUnitsDefaults(UnitSystemId,UsageKey,Unit,Subunit)Values(2,'Price_Tcd','Price','euro')
GO
Insert into DimensionalUnitsDefaults(UnitSystemId,UsageKey,Unit,Subunit)Values(2,'Price_Electric_Tariff_Tcd','Price','euro_per_unit')
GO
Insert into DimensionalUnitsDefaults(UnitSystemId,UsageKey,Unit,Subunit)Values(2,'Price_GasOil_Tcd','Price','euro_per_lbs')


---------------------------------------------------
-- Resource Keys Insertion
---------------------------------------------------

----------------------------------------------
---- Resources keys in master table
----------------------------------------------
GO
Insert into ResourceKeyMaster([Key])values('DOLLAR_PER_UNIT')
GO
Insert into ResourceKeyMaster([Key])values('DOLLAR_PER_LBS')
GO
Insert into ResourceKeyMaster([Key])values('KILO_WATT_HOUR_CUBIC_METER')
GO
Insert into ResourceKeyMaster([Key])values('DOLLAR')
GO
Insert into ResourceKeyMaster([Key])values('FAHRENHEIT')
GO
Insert into ResourceKeyMaster([Key])values('EURO')
GO
Insert into ResourceKeyMaster([Key])values('EURO_PER_UNIT')
GO
Insert into ResourceKeyMaster([Key])values('EURO_PER_LBS')
GO
Insert into ResourceKeyMaster([Key])values('CELSIUS')

-----------------------------------------------
------ Resource key Values 
-----------------------------------------------

-- DOLLAR_PER_UNIT Key 
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(277,'$/Unit','en-EN',1)
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(277,'€/Unit','sp-SP',3)
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(277,'kr/Unit','nr-NR',13)
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(277,'€/Unit','nl-BE',2)
GO

-- DOLLAR_PER_LBS
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(278,'$/Lbs','en-EN',1)
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(278,'€/Kgs','sp-SP',3)
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(278,'kr/Kgs','nr-NR',13)
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(278,'€/Kgs','nl-BE',2)

-- KILO_WATT_HOUR_CUBIC_METER
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(279,'Kwh/m3','en-EN',1)
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(279,'Kwh/m3','sp-SP',3)
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(279,'Kwh/m3','nr-NR',13)
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(279,'Kwh/m3','nl-BE',2)

-- DOLLAR
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(280,'$','en-EN',1)
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(280,'€','sp-SP',3)
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(280,'kr','nr-NR',13)
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(280,'€','nl-BE',2)

-- FAHRENHEIT
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(281,'F','en-EN',1)
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(281,'C','sp-SP',3)
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(281,'C','nr-NR',13)
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(281,'C','nl-BE',2)

-- EURO
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(280,'$','en-EN',1)
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(280,'€','sp-SP',3)
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(280,'kr','nr-NR',13)
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(280,'€','nl-BE',2)

-- EURO_PER_UNIT
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(277,'$/Unit','en-EN',1)
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(277,'€/Unit','sp-SP',3)
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(277,'kr/Unit','nr-NR',13)
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(277,'€/Unit','nl-BE',2)

-- EURO_PER_LBS
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(278,'$/Lbs','en-EN',1)
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(278,'€/Kgs','sp-SP',3)
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(278,'kr/Kgs','nr-NR',13)
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(278,'€/Kgs','nl-BE',2)

-- CELSIUS
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(281,'F','en-EN',1)
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(281,'C','sp-SP',3)
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(281,'C','nr-NR',13)
GO
INSERT INTO ResourceKeyValue (ResourceID, Value, Locale, languageID) values(281,'C','nl-BE',2)
