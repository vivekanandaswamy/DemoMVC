	/****** Object:  Table [TCD].[CWsrwfwashers]    Script Date: 11/20/2014 17:05:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [TCD].[CWsrwfwashers](
	[srid] [int] NOT NULL,
	[washer] [nvarchar](4) NULL,
	[wdescription] [nvarchar](30) NULL,
	[capacity] [int] NULL,
	[tunnel] [bit] NOT NULL,
	[hot_inlet] [bit] NOT NULL,
	[cold_inlet] [bit] NOT NULL,
	[reuse_valve] [bit] NOT NULL,
	[drain] [bit] NOT NULL,
	[steam_inlet] [bit] NOT NULL,
	[controller] [bit] NOT NULL,
	[level_control] [bit] NOT NULL,
	[temp_control] [bit] NOT NULL,
	[brakes] [bit] NOT NULL,
	[doors] [bit] NOT NULL,
	[rpm] [bit] NOT NULL,
	[extract] [bit] NOT NULL,
	[safety] [bit] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [TCD].[CWsrwater]    Script Date: 11/20/2014 17:05:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [TCD].[CWsrwater](
	[srid] [int] NOT NULL,
	[watertype] [nvarchar](10) NOT NULL,
	[temperature] [int] NULL,
	[hardness] [decimal](4, 2) NULL,
	[bicarb] [decimal](4, 2) NULL,
	[iron] [nvarchar](8) NULL,
	[chlorine] [nvarchar](8) NULL,
	[turbidity] [decimal](4, 2) NULL,
	[tds] [decimal](4, 2) NULL,
	[ph] [decimal](4, 2) NULL,
	[odor] [bit] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [TCD].[CWsrtunchkhd]    Script Date: 11/20/2014 17:05:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [TCD].[CWsrtunchkhd](
	[srid] [int] NOT NULL,
	[washer1] [nvarchar](4) NULL,
	[wdescr1] [nvarchar](30) NULL,
	[washer2] [nvarchar](4) NULL,
	[wdescr2] [nvarchar](30) NULL,
	[washer3] [nvarchar](4) NULL,
	[wdescr3] [nvarchar](30) NULL,
	[washer4] [nvarchar](4) NULL,
	[wdescr4] [nvarchar](30) NULL,
	[washer5] [nvarchar](4) NULL,
	[wdescr5] [nvarchar](30) NULL,
	[washer6] [nvarchar](4) NULL,
	[wdescr6] [nvarchar](30) NULL,
	[washer7] [nvarchar](4) NULL,
	[wdescr7] [nvarchar](30) NULL,
	[washer8] [nvarchar](4) NULL,
	[wdescr8] [nvarchar](30) NULL,
	[washer9] [nvarchar](4) NULL,
	[wdescr9] [nvarchar](30) NULL,
	[washer10] [nvarchar](4) NULL,
	[wdescr10] [nvarchar](30) NULL,
	[numofwash] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [TCD].[CWsrtunchkdet]    Script Date: 11/20/2014 17:05:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [TCD].[CWsrtunchkdet](
	[srid] [int] NOT NULL,
	[nseq1] [int] NOT NULL,
	[nseq2] [int] NOT NULL,
	[condition1] [nvarchar](50) NOT NULL,
	[ltunnel1] [bit] NOT NULL,
	[ltunnel2] [bit] NOT NULL,
	[ltunnel3] [bit] NOT NULL,
	[ltunnel4] [bit] NOT NULL,
	[ltunnel5] [bit] NOT NULL,
	[ltunnel6] [bit] NOT NULL,
	[ltunnel7] [bit] NOT NULL,
	[ltunnel8] [bit] NOT NULL,
	[ltunnel9] [bit] NOT NULL,
	[ltunnel10] [bit] NOT NULL,
	[cfldtype] [nvarchar](1) NOT NULL,
	[cdp_date] [datetime] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [TCD].[CWsrtunchkdes_ini]    Script Date: 11/20/2014 17:05:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [TCD].[CWsrtunchkdes_ini](
	[nseq1] [int] NOT NULL,
	[nseq2] [int] NOT NULL,
	[condition] [nvarchar](50) NOT NULL,
	[crectype] [nvarchar](1) NOT NULL,
	[cfldtype] [nvarchar](1) NOT NULL,
	[mod_date] [datetime] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [TCD].[CWsrtunchkdes]    Script Date: 11/20/2014 17:05:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [TCD].[CWsrtunchkdes](
	[nseq1] [int] NOT NULL,
	[nseq2] [int] NOT NULL,
	[condition] [nvarchar](50) NOT NULL,
	[crectype] [nvarchar](1) NOT NULL,
	[cfldtype] [nvarchar](1) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [TCD].[CWsrttsteps]    Script Date: 11/20/2014 17:05:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [TCD].[CWsrttsteps](
	[ttid] [int] NOT NULL,
	[step] [nvarchar](3) NOT NULL,
	[operation] [nvarchar](9) NULL,
	[time] [decimal](4, 2) NULL,
	[water_temp] [nvarchar](5) NULL,
	[actual_temp] [nvarchar](5) NULL,
	[water_level] [int] NULL,
	[actual_levelt] [int] NULL,
	[chemicals] [nvarchar](128) NULL,
	[ph] [decimal](4, 1) NULL,
	[alk_drops] [decimal](4, 1) NULL,
	[alk_ppm] [int] NULL,
	[chlor_drops] [decimal](4, 1) NULL,
	[chlor_ppm] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [TCD].[CWsrttform]    Script Date: 11/20/2014 17:05:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [TCD].[CWsrttform](
	[srid] [int] NOT NULL,
	[ttid] [int] NOT NULL,
	[washer] [nvarchar](4) NULL,
	[wdescription] [nvarchar](30) NULL,
	[op_class] [nvarchar](3) NULL,
	[formula] [nvarchar](3) NULL,
	[fdescription] [nvarchar](30) NULL,
	[target_weight] [int] NULL,
	[actual_weight] [int] NULL,
	[dt] [datetime] NULL,
	[current] [bit] NOT NULL,
	[revised] [bit] NOT NULL,
	[bleachfactor] [decimal](5, 2) NULL,
	[reportprint] [bit] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [TCD].[CWsrttcheck]    Script Date: 11/20/2014 17:05:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [TCD].[CWsrttcheck](
	[srid] [int] NOT NULL,
	[washer] [nvarchar](4) NULL,
	[formdesc] [nvarchar](30) NULL,
	[step] [nvarchar](20) NULL,
	[tunnelmod] [int] NOT NULL,
	[status] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [TCD].[CWsrtitrthd]    Script Date: 11/20/2014 17:05:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [TCD].[CWsrtitrthd](
	[washer] [nvarchar](4) NOT NULL,
	[wt_target] [int] NOT NULL,
	[wdescription] [nvarchar](30) NOT NULL,
	[wt_actual] [int] NULL,
	[dt] [datetime] NULL,
	[current] [bit] NULL,
	[revised] [bit] NULL,
	[runtime_gt] [decimal](4, 2) NULL,
	[waterrate] [decimal](9, 2) NULL,
	[waterused] [decimal](9, 2) NULL,
	[bleachfactor] [decimal](5, 2) NULL,
	[op_class] [nvarchar](3) NULL,
	[formula] [nvarchar](3) NULL,
	[nchambers] [int] NULL,
	[nchems] [int] NULL,
	[chemsku01] [nvarchar](15) NULL,
	[chemsku02] [nvarchar](15) NULL,
	[chemsku03] [nvarchar](15) NULL,
	[chemsku04] [nvarchar](15) NULL,
	[chemsku05] [nvarchar](15) NULL,
	[chemsku06] [nvarchar](15) NULL,
	[chemsku07] [nvarchar](15) NULL,
	[chemsku08] [nvarchar](15) NULL,
	[chemsku09] [nvarchar](15) NULL,
	[chemsku10] [nvarchar](15) NULL,
	[chemsku11] [nvarchar](15) NULL,
	[chemsku12] [nvarchar](15) NULL,
	[chemsku13] [nvarchar](15) NULL,
	[chemsku14] [nvarchar](15) NULL,
	[chemsku15] [nvarchar](15) NULL,
	[chemdes01] [nvarchar](30) NULL,
	[chemdes02] [nvarchar](30) NULL,
	[chemdes03] [nvarchar](30) NULL,
	[chemdes04] [nvarchar](30) NULL,
	[chemdes05] [nvarchar](30) NULL,
	[chemdes06] [nvarchar](30) NULL,
	[chemdes07] [nvarchar](30) NULL,
	[chemdes08] [nvarchar](30) NULL,
	[chemdes09] [nvarchar](30) NULL,
	[chemdes10] [nvarchar](30) NULL,
	[chemdes11] [nvarchar](30) NULL,
	[chemdes12] [nvarchar](30) NULL,
	[chemdes13] [nvarchar](30) NULL,
	[chemdes14] [nvarchar](30) NULL,
	[chemdes15] [nvarchar](30) NULL,
	[srid] [int] NOT NULL,
	[ttid] [int] NOT NULL,
	[reportprint] [bit] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [TCD].[CWsrtitrtdet]    Script Date: 11/20/2014 17:05:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [TCD].[CWsrtitrtdet](
	[module] [int] NOT NULL,
	[class_form] [nvarchar](6) NULL,
	[alky_drops] [int] NULL,
	[alyy_ppm] [decimal](4, 1) NULL,
	[ph] [decimal](4, 2) NULL,
	[bleachdrop] [decimal](4, 2) NULL,
	[bleachppm] [decimal](4, 1) NULL,
	[act_temp] [int] NULL,
	[target_tmp] [int] NULL,
	[drain] [int] NULL,
	[waterlvl] [decimal](4, 1) NULL,
	[chem01] [decimal](3, 1) NULL,
	[chem02] [decimal](3, 1) NULL,
	[chem03] [decimal](3, 1) NULL,
	[chem04] [decimal](3, 1) NULL,
	[chem05] [decimal](3, 1) NULL,
	[chem06] [decimal](3, 1) NULL,
	[chem07] [decimal](3, 1) NULL,
	[chem08] [decimal](3, 1) NULL,
	[chem09] [decimal](3, 1) NULL,
	[chem10] [decimal](3, 1) NULL,
	[chem11] [decimal](3, 1) NULL,
	[chem12] [decimal](3, 1) NULL,
	[chem13] [decimal](3, 1) NULL,
	[chem14] [decimal](3, 1) NULL,
	[chem15] [decimal](3, 1) NULL,
	[srid] [int] NOT NULL,
	[ttid] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [TCD].[CWsrsteam]    Script Date: 11/20/2014 17:05:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [TCD].[CWsrsteam](
	[srid] [int] NOT NULL,
	[module] [int] NOT NULL,
	[description] [nvarchar](40) NOT NULL,
	[poor_quality] [bit] NOT NULL,
	[temp_set_point] [int] NULL,
	[temp_fabric] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [TCD].[CWsrlfsparts]    Script Date: 11/20/2014 17:05:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [TCD].[CWsrlfsparts](
	[srid] [int] NOT NULL,
	[lfs_unit] [nvarchar](8) NULL,
	[part] [nvarchar](15) NULL,
	[replacedate] [date] NULL,
	[reason] [nvarchar](50) NULL,
	[diverter] [nvarchar](9) NULL,
	[flush_washer] [nvarchar](9) NULL,
	[valve] [nvarchar](11) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [TCD].[CWsrlfschkhd]    Script Date: 11/20/2014 17:05:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [TCD].[CWsrlfschkhd](
	[srid] [int] NOT NULL,
	[lfsname1] [nvarchar](8) NULL,
	[lfsdes1] [nvarchar](30) NULL,
	[lfsname2] [nvarchar](8) NULL,
	[lfsdes2] [nvarchar](30) NULL,
	[lfsname3] [nvarchar](8) NULL,
	[lfsdes3] [nvarchar](30) NULL,
	[lfsname4] [nvarchar](8) NULL,
	[lfsdes4] [nvarchar](30) NULL,
	[lfsname5] [nvarchar](8) NULL,
	[lfsdes5] [nvarchar](30) NULL,
	[lfsname6] [nvarchar](8) NULL,
	[lfsdes6] [nvarchar](30) NULL,
	[lfsname7] [nvarchar](8) NULL,
	[lfsdes7] [nvarchar](30) NULL,
	[lfsname8] [nvarchar](8) NULL,
	[lfsdes8] [nvarchar](30) NULL,
	[lfsname9] [nvarchar](8) NULL,
	[lfsdes9] [nvarchar](30) NULL,
	[lfsname10] [nvarchar](8) NULL,
	[lfsdes10] [nvarchar](30) NULL,
	[numoflfs] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [TCD].[CWsrlfschkdet]    Script Date: 11/20/2014 17:05:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [TCD].[CWsrlfschkdet](
	[srid] [int] NOT NULL,
	[nseq1] [int] NOT NULL,
	[nseq2] [int] NOT NULL,
	[condition1] [nvarchar](50) NOT NULL,
	[lfs1] [bit] NULL,
	[lfs2] [bit] NULL,
	[lfs3] [bit] NULL,
	[lfs4] [bit] NULL,
	[lfs5] [bit] NULL,
	[lfs6] [bit] NULL,
	[lfs7] [bit] NULL,
	[lfs8] [bit] NULL,
	[lfs9] [bit] NULL,
	[lfs10] [bit] NULL,
	[cfldtype] [nvarchar](1) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [TCD].[CWsrironers]    Script Date: 11/20/2014 17:05:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [TCD].[CWsrironers](
	[srid] [int] NOT NULL,
	[module] [int] NOT NULL,
	[description] [nvarchar](40) NOT NULL,
	[poor_quality] [bit] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [TCD].[CWsrheatrec]    Script Date: 11/20/2014 17:05:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [TCD].[CWsrheatrec](
	[srid] [int] NOT NULL,
	[description] [nvarchar](20) NOT NULL,
	[operating] [bit] NULL,
	[readtime] [datetime] NULL,
	[wastein] [int] NULL,
	[wasteout] [int] NULL,
	[freshin] [int] NULL,
	[freshout] [int] NULL,
	[rise] [int] NULL,
	[approach] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [TCD].[CWsrheader]    Script Date: 11/20/2014 17:05:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [TCD].[CWsrheader](
	[srid] [int] NOT NULL,
	[company] [nvarchar](40) NULL,
	[address] [nvarchar](max) NULL,
	[contact] [nvarchar](30) NULL,
	[contact_phone] [nvarchar](10) NULL,
	[tsn_no] [int] NULL,
	[tsn_name] [nvarchar](30) NULL,
	[start_date] [datetime] NOT NULL,
	[duration] [int] NOT NULL,
	[last_date] [datetime] NULL,
	[onsite] [bit] NOT NULL,
	[next_date] [datetime] NULL,
	[next_onsite] [bit] NOT NULL,
	[entrance_interview] [nvarchar](max) NULL,
	[follow_up] [nvarchar](max) NULL,
	[opportunities] [nvarchar](max) NULL,
	[nonroutine_service] [nvarchar](max) NULL,
	[exit_name] [nvarchar](30) NULL,
	[exit_position] [nvarchar](20) NULL,
	[exit_date] [datetime] NULL,
	[logo_file] [nvarchar](64) NULL,
	[inv_rep_start] [datetime] NULL,
	[inv_rep_stop] [datetime] NULL,
	[report_start] [datetime] NULL,
	[report_stop] [datetime] NULL,
	[target_lbs] [int] NULL,
	[target_clean_lbs] [int] NULL,
	[actual_lbs] [int] NULL,
	[actual_clean_lbs] [int] NULL,
	[use_soiled_lbs] [bit] NOT NULL,
	[op_eff] [int] NULL,
	[op_eff_ll] [int] NULL,
	[load_eff] [int] NULL,
	[load_eff_ll] [int] NULL,
	[inc_ponies] [bit] NOT NULL,
	[op_eff_tunnel] [int] NULL,
	[op_eff_ll_tunnel] [int] NULL,
	[load_eff_tunnel] [int] NULL,
	[load_eff_ll_tunnel] [int] NULL,
	[chem_tgt_cwt] [decimal](4, 2) NULL,
	[chem_act_cwt] [decimal](4, 2) NULL,
	[water_usage] [int] NULL,
	[gas_usage] [int] NULL,
	[electric_usage] [int] NULL,
	[lfs_procparm] [int] NOT NULL,
	[lfs_proctext] [nvarchar](max) NULL,
	[washer_procparm] [int] NOT NULL,
	[washer_proctext] [nvarchar](max) NULL,
	[soil_procparm] [int] NOT NULL,
	[soil_proctext] [nvarchar](max) NULL,
	[garmtunnel_procparm] [int] NOT NULL,
	[garmtunnel_proctext] [nvarchar](max) NULL,
	[flatwork_procparm] [int] NOT NULL,
	[flatwork_proctext] [nvarchar](max) NULL,
	[bulkitems_procparm] [int] NOT NULL,
	[bulkitems_proctext] [nvarchar](max) NULL,
	[water_procparm] [int] NOT NULL,
	[water_proctext] [nvarchar](max) NULL,
	[titration_procparm] [int] NOT NULL,
	[titration_proctext] [nvarchar](max) NULL,
	[bleach_pct] [decimal](5, 2) NULL,
	[prt_conv_loadeff] [bit] NOT NULL,
	[prt_conv_opeff] [bit] NOT NULL,
	[prt_tunnel_loadeff] [bit] NOT NULL,
	[prt_tunnel_opeff] [bit] NOT NULL,
	[prt_total_opeff] [bit] NOT NULL,
	[prt_total_loadeff] [bit] NOT NULL,
	[prt_overall_eff] [bit] NOT NULL,
	[prt_actual_cwt] [bit] NOT NULL,
	[prt_target_cwt] [bit] NOT NULL,
	[prt_gas] [bit] NOT NULL,
	[prt_water] [bit] NOT NULL,
	[prt_electric] [bit] NOT NULL,
	[prt_convloadeff_rep] [bit] NOT NULL,
	[prt_convopeff_rep] [bit] NOT NULL,
	[prt_tunloadeff_rep] [bit] NOT NULL,
	[prt_tunopeff_rep] [bit] NOT NULL,
	[prt_allloadeff_rep] [bit] NOT NULL,
	[prt_inv_rep] [bit] NOT NULL,
	[closed] [bit] NOT NULL,
	[pdf_report] [nvarchar](max) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [TCD].[CWsrcttcheck]    Script Date: 11/20/2014 17:05:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [TCD].[CWsrcttcheck](
	[srid] [int] NOT NULL,
	[washer] [nvarchar](4) NOT NULL,
	[formdesc] [nvarchar](30) NULL,
	[step] [nvarchar](20) NULL,
	[status] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [TCD].[CWextra_dde_data]    Script Date: 11/20/2014 17:05:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [TCD].[CWextra_dde_data](
	[ultrax] [nvarchar](8) NOT NULL,
	[address] [nvarchar](10) NOT NULL,
	[datetime] [datetime] NOT NULL,
	[value] [nvarchar](10) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [TCD].[CWextra_dde_addr]    Script Date: 11/20/2014 17:05:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [TCD].[CWextra_dde_addr](
	[ultrax] [nvarchar](8) NOT NULL,
	[address] [nvarchar](10) NOT NULL
) ON [PRIMARY]
GO

/****** Object:  Table [TCD].[CWetech_settings]    Script Date: 12/04/2014 16:04:31 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [TCD].[CWetech_settings](
	[Active] [bit] NOT NULL,
	[Server] [nvarchar](64) NOT NULL,
	[Topic] [nvarchar](32) NOT NULL,
	[ReadInterval] [int] NOT NULL,
	[CWUpdateInterval] [int] NOT NULL,
	[Rp_Sql] [bit] NOT NULL,
	[Rp_Dsn] [nvarchar](20) NULL,
	[Rp_User] [nvarchar](20) NULL,
	[Rp_PW] [nvarchar](20) NULL,
	[Rp_Read_Mode] [int] NOT NULL
) ON [PRIMARY]

GO
/****** Object:  Table [TCD].[CWdailyactuals]    Script Date: 12/04/2014 16:04:26 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [TCD].[CWdailyactuals](
	[Date] [datetime] NOT NULL,
	[GasMeter] [decimal](11, 2) NULL,
	[Gas] [decimal](11, 2) NULL,
	[WaterMeter] [decimal](11, 2) NULL,
	[Water] [decimal](11, 2) NULL,
	[ElectricMeter] [decimal](11, 2) NULL,
	[Electric] [decimal](11, 2) NULL,
	[MeterGroup] [int] NOT NULL
) ON [PRIMARY]

GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [TCD].[WasherReadings](
	[WasherReadingId] [int] IDENTITY(1,1) NOT NULL,
	[BatchId] [int] NULL,
	[WasherId] [int] NULL,
	[GroupId] [int] NULL,
	[Step/CompartmentId] [int] NULL,
	[Formula] [int] NULL,
	[InjectionNumber] [int] NULL,
	[OpCounter] [int] NULL,
	[TimeStamp] [datetime] NULL
) ON [PRIMARY]

GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [TCD].[WasherChemicalReadings](
	[BatchId] [int] NULL,
	[WasherReadingId] [int] IDENTITY(1,1) NOT NULL,
	[SKU] [nvarchar](15) NULL,
	[ActualDosage] [decimal](10, 5) NULL,
	[DesiredDosage] [decimal](10, 5) NULL,
	[ActualCost] [decimal](10, 5) NULL,
	[DesiredCost] [decimal](10, 5) NULL,
	[TimeStamp] [datetime] NULL
) ON [PRIMARY]

GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [TCD].[CWBatchData](
	[BatchId] [int] NOT NULL,
	[Loads] [int] NOT NULL,
	[Origin] [nvarchar](5) NOT NULL,
	[InjClass] [nvarchar](5) NOT NULL,
	[UFDesc] [nvarchar](30) NOT NULL,
	[LFPlantf] [nvarchar](5) NOT NULL,
	[LFInjf] [nvarchar](5) NOT NULL,
	[LfWtTarget] [int] NOT NULL,
	[LfRtTarget] [decimal](6, 2) NOT NULL,
	[LfRtGt] [decimal](6, 2) NOT NULL,
	[TunnelId] [nvarchar](5) NOT NULL,
	[LfCleanWeight] [int] NOT NULL,
	[LfCleanAw] [decimal](3, 2) NOT NULL,
	[NextBofDate] [datetime] NULL,
	Wr_id int NULL,
	IsCompressedBatch bit default (0),
) ON [PRIMARY]

GO

/****** Object:  Table [dbo].[T_SetupResHelp]    Script Date: 05/25/2016 17:26:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [TCD].[HLMSetupProductsCategory](
	[PD_Category] [int],
	[PD_CategoryDescription] [nvarchar](50) NULL,
) ON [PRIMARY]

GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [TCD].[HLMSetupResHelp](
	[REH_Number] [int] NOT NULL,
	[RE_Number] [int] NULL,
	[REH_Name] [nvarchar](50) NULL,
	[REH_Price] [float] NULL,
	[REH_Factor] [float] NULL,
	[REH_AmountInput] [int] NULL,
	[REH_AnalougeInput] [int] NULL,
	[int_EOP_AQMC_Used] [int] NULL,
	[int_HT_Favorites] [int] NULL,
	[int_HT_Selected] [int] NULL,
) ON [PRIMARY]

GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [TCD].[HLMSetupRessources](
	[RE_Number] [int] NOT NULL,
	[RE_Name] [nvarchar](50) NULL,
	[RE_Unit] [nvarchar](50) NULL,
) ON [PRIMARY]

GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [TCD].[HLMInPersonal](
	[IP_Number] [int],
	[IP_Date] [datetime] NULL,
	[IP_ManHoures] [int] NULL,
	[IP_Cost] [float] NULL,
) ON [PRIMARY]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [TCD].[HLMInManual](
	[IM_Number] [int],
	[REH_Number] [int] NULL,
	[IM_Date] [datetime] NULL,
	[IM_Quantity] [float] NULL,
	[IM_Price] [float] NULL,
	[Scor_Updated] [bit] NULL,
) ON [PRIMARY]

GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [TCD].[HLMCbwRunTime](
	[GR_Number] [int] NOT NULL,
	[PGH_ProgramNumber] [int] NOT NULL,
	[Cb_Compartement] [int] NOT NULL,
	[CRT_Time] [smallint] NULL,
) ON [PRIMARY]
GO