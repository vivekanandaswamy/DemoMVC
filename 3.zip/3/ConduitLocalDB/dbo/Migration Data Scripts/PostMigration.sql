UPDATE    tcd.WasherTags
 SET       TagAddress = REPLACE(REPLACE(TagAddress, '.PR', ''), '', '')
 WHERE     TagAddress like '%.PR'

UPDATE    tcd.WasherTags
 SET       TagAddress = REPLACE(REPLACE(TagAddress, '.PRE', ''), '', '')
 WHERE     TagAddress like '%.PRE'




update tcd.controllersetupdata set value = 'Matrikon.OPC.Simulation.1' where value = 'RSLinx OPC Server'

update tcd.PlantCustAddress set Country = 'USA'
