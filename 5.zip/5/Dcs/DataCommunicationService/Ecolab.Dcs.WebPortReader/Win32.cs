﻿// -----------------------------------------------------------------------
// <copyright file="Win32.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Win32</summary>
// -----------------------------------------------------------------------

/* 
 * TODO - There is an issue with some of the WebPort filenames that include forward slashes (/) in the 
 * filename. Allen Bradley bit level addresses, S:5/0 for example, include a forward slash (/) to delimit
 * the word address from the bit position.  Unfortunately, the .NET and Win32 FTP methods interpret 
 * forward slashes (/) to delimit paths, and, when a filename includes a forward slash (/) the methods
 * assume the filename to be a relative file specification, i.e. include a path under the FTP URL and
 * default path.  For example, the file ftp://192.168.0.240/s_5/0.txt is considered by .NET and Win23 
 * to be the file 0.txt at URL ftp://192.168.0.240/s_5/ rather than file s_5/0.txt at ftp://192.168.0.240/, 
 * which is the case with Allen Bradly addresses in WebPort.  Somehow there is a way to include a forward 
 * slash in the  file name or use method that only accept an absolute path as the filename as there are 
 * many FTP clients that handle this situation.
 */

namespace Ecolab.Dcs.WebPortReader
{
    using System;
    using System.ComponentModel;
    using System.Runtime.InteropServices;
    using System.Text;
    using FILETIME = System.Runtime.InteropServices.ComTypes.FILETIME;

    /// <summary>
    ///     Provides Win32 platform invoke methods to read the FTP server on a WebPort.
    /// </summary>
    /// <remarks>
    ///     This class is meant as an alternative to the .NET FTP methods but proved
    ///     to have similar functionality and limitations, i.e. forward slashes (/).
    /// </remarks>
    internal static class Win32
    {
        /// <summary>
        ///     Retrieves the proxy or direct configuration from the registry.
        /// </summary>
        private const int INTERNET_OPEN_TYPE_PRECONFIG = 0; // use registry configuration

        /// <summary>
        ///     Resolves all host names locally.
        /// </summary>
        private const int INTERNET_OPEN_TYPE_DIRECT = 1; // direct to net

        /// <summary>
        ///     Passes requests to the proxy unless a proxy bypass list is supplied and the name to be resolved
        ///     bypasses the proxy. In this case, the function uses INTERNET_OPEN_TYPE_DIRECT.
        /// </summary>
        private const int INTERNET_OPEN_TYPE_PROXY = 3; // via named proxy

        /// <summary>
        ///     Retrieves the proxy or direct configuration from the registry and prevents the use of a startup
        ///     Microsoft JScript or Internet Setup (INS) file.
        /// </summary>
        private const int INTERNET_OPEN_TYPE_PRECONFIG_WITH_NO_AUTOPROXY = 4; // prevent using java/script/INS

        /// <summary>
        ///     INTERNET_DEFAULT_FTP_PORT uses the default FTP port, but the service type still must be set.
        /// </summary>
        private const ushort INTERNET_DEFAULT_FTP_PORT = 21;

        /// <summary>
        ///     Specifies FTP service.
        /// </summary>
        private const uint INTERNET_SERVICE_FTP = 1;

        /// <summary>
        ///     Uses passive FTP semantics. Only InternetConnect and InternetOpenUrl use this flag. InternetConnect
        ///     uses this flag for FTP requests, and InternetOpenUrl uses this flag for FTP files and directories.
        /// </summary>
        private const uint INTERNET_FLAG_PASSIVE = 0x08000000;

        /// <summary>
        ///     A file that does not have other attributes set. This attribute is valid only when used alone.
        /// </summary>
        private const uint FILE_ATTRIBUTE_NORMAL = 128;

        /// <summary>
        ///     Provides a log buffer for this class.
        /// </summary>
        private static readonly StringBuilder sLogBuffer = new StringBuilder();

        /// <summary>
        ///     Retrieves the log for this class.
        /// </summary>
        public static string Log
        {
            get { return sLogBuffer.ToString(); }
        }

        /// <summary>
        /// Internets the open.
        /// </summary>
        /// <param name="lpszAgent">Specifies the name of the application or entity calling the WinINet functions.This name is used as the user agent in the HTTP protocol.</param>
        /// <param name="dwAccessType">Type of access required.</param>
        /// <param name="lpszProxyName">Specifies the name of the proxy server(s) to use when proxy access is specified by setting dwAccessType to INTERNET_OPEN_TYPE_PROXY. Do not use an empty string, because InternetOpen will use it as the proxy name. The WinINet functions recognize only CERN type proxies (HTTP only) and the TIS FTP gateway (FTP only). If Microsoft Internet Explorer is installed, these functions also support SOCKS proxies. FTP requests can be made through a CERN type proxy either by changing them to an HTTP request or by using InternetOpenUrl. If dwAccessType is not set to INTERNET_OPEN_TYPE_PROXY, this parameter is ignored and should be NULL.</param>
        /// <param name="lpszProxyBypass">Specifies an optional list of host names or IP addresses, or both, that should not be routed through the proxy when dwAccessType is set to INTERNET_OPEN_TYPE_PROXY. The list can contain wildcards. Do not use an empty string, because InternetOpen will use it as the proxy bypass list. If this parameter specifies the  macro, the function bypasses the proxy for any host name that does not contain a period.</param>
        /// <param name="dwFlags">The dw flags.</param>
        /// <returns>Returns a valid handle that the application passes to subsequent WinINet functions. If InternetOpen fails, it returns NULL. To retrieve a specific error message, call GetLastError.</returns>
        [DllImport("wininet.dll", EntryPoint = "InternetOpen", SetLastError = true, CharSet = CharSet.Auto)]
        private static extern IntPtr InternetOpen(string lpszAgent, int dwAccessType, string lpszProxyName, string lpszProxyBypass, int dwFlags);

        /// <summary>
        ///     Opens an File Transfer Protocol (FTP) or HTTP session for a given site.
        /// </summary>
        /// <param name="hInternet">Handle returned by a previous call to InternetOpen.</param>
        /// <param name="lpszServerName">
        ///     Specifies the host name of an Internet server. Alternately, the string
        ///     can contain the IP number of the site, in ASCII dotted-decimal format (for example, 11.0.1.45).
        /// </param>
        /// <param name="nServerPort">
        ///     Transmission Control Protocol/Internet Protocol (TCP/IP) port on the server.
        ///     These flags set only the port that is used. The service is set by the value of dwService.
        /// </param>
        /// <param name="lpszUsername">
        ///     Specifies the name of the user to log on. If this parameter is NULL, the
        ///     function uses an appropriate default. For the FTP protocol, the default is "anonymous".
        /// </param>
        /// <param name="lpszPassword">
        ///     Contains the password to use to log on. If both lpszPassword and lpszUsername
        ///     are NULL, the function uses the default "anonymous" password. In the case of FTP, the default password
        ///     is the user's email name. If lpszPassword is NULL, but lpszUsername is not NULL, the function uses a
        ///     blank password.
        /// </param>
        /// <param name="dwService">Type of service to access.</param>
        /// <param name="dwFlags">
        ///     Options specific to the service used. If dwService is INTERNET_SERVICE_FTP,
        ///     INTERNET_FLAG_PASSIVE causes the application to use passive FTP semantics.
        /// </param>
        /// <param name="dwContext">
        ///     Contains an application-defined value that is used to identify the application
        ///     context for the returned handle in callbacks.
        /// </param>
        /// <returns>
        ///     Returns a valid handle to the session if the connection is successful, or NULL otherwise. To
        ///     retrieve extended error information, call GetLastError. An application can also use
        ///     InternetGetLastResponseInfo to determine why access to the service was denied.
        /// </returns>
        [DllImport("wininet.dll", EntryPoint = "InternetConnect", SetLastError = true, CharSet = CharSet.Auto)]
        private static extern IntPtr InternetConnect(IntPtr hInternet, string lpszServerName, int nServerPort, string lpszUsername, string lpszPassword, uint dwService, uint dwFlags, uint dwContext);

        /// <summary>
        ///     Searches the specified directory of the given FTP session. File and directory entries are returned to
        ///     the application in the WIN32_FIND_DATA structure.
        /// </summary>
        /// <param name="hConnect">Handle to an FTP session returned from InternetConnect.</param>
        /// <param name="searchFile">
        ///     Specifies a valid directory path or file name for the FTP server's file system.
        ///     The string can contain wildcards, but no blank spaces are allowed. If the value of lpszSearchFile is NULL
        ///     or if it is an empty string, the function finds the first file in the current directory on the server.
        /// </param>
        /// <param name="findFileData">
        ///     A WIN32_FIND_DATA structure that receives information about the found file
        ///     or directory.
        /// </param>
        /// <param name="flags">
        ///     Controls the behavior of this function. This parameter can be a combination of the
        ///     following values: INTERNET_FLAG_HYPERLINK, INTERNET_FLAG_NEED_FILE, INTERNET_FLAG_NO_CACHE_WRITE,\
        ///     INTERNET_FLAG_RELOAD, INTERNET_FLAG_RESYNCHRONIZE.
        /// </param>
        /// <param name="context">
        ///     Specifies the application-defined value that associates this search with any
        ///     application data. This parameter is used only if the application has already called InternetSetStatusCallback
        ///     to set up a status callback function.
        /// </param>
        /// <returns>
        ///     Returns a valid handle for the request if the directory enumeration was started successfully,
        ///     or returns NULL otherwise. To get a specific error message, call GetLastError. If GetLastError returns
        ///     ERROR_INTERNET_EXTENDED_ERROR, as in the case where the function finds no matching files, call the
        ///     InternetGetLastResponseInfo function to retrieve the extended error text, as documented in Handling
        ///     Errors.
        /// </returns>
        [DllImport("wininet.dll", EntryPoint = "FtpFindFirstFile", SetLastError = true, CharSet = CharSet.Auto)]
        private static extern IntPtr FtpFindFirstFile(IntPtr hConnect, string searchFile, out WIN32_FIND_DATA findFileData, int flags, IntPtr context);

        /// <summary>
        ///     Continues a file search started as a result of a previous call to FtpFindFirstFile.
        /// </summary>
        /// <param name="hFind">
        ///     Handle returned from either FtpFindFirstFile or InternetOpenUrl (directories only).
        /// </param>
        /// <param name="findFileData">
        ///     Buffer that receives information about the file or directory. The format
        ///     of the information placed in the buffer depends on the protocol in use. The FTP protocol returns a
        ///     WIN32_FIND_DATA structure.
        /// </param>
        /// <returns>
        ///     Returns a valid handle for the request if the directory enumeration was started successfully,
        ///     or returns NULL otherwise. To get a specific error message, call GetLastError. If GetLastError returns
        ///     ERROR_INTERNET_EXTENDED_ERROR, as in the case where the function finds no matching files, call the
        ///     InternetGetLastResponseInfo function to retrieve the extended error text, as documented in Handling
        ///     Errors.
        /// </returns>
        [DllImport("wininet.dll", SetLastError = true, CharSet = CharSet.Auto)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool InternetFindNextFile(IntPtr hFind, out WIN32_FIND_DATA findFileData);

        /// <summary>
        ///     Retrieves a file from the FTP server and stores it under the specified file name, creating a new
        ///     local file in the process.
        /// </summary>
        /// <param name="hFtpConn">Handle to an FTP session.</param>
        /// <param name="strSource">Contains the name of the file to be retrieved.</param>
        /// <param name="strTarget">Contains the name of the file to be created on the local system.</param>
        /// <param name="bFailIfExists">
        ///     Indicates whether the function should proceed if a local file of the
        ///     specified name already exists. If fFailIfExists is TRUE and the local file exists, FtpGetFile fails.
        /// </param>
        /// <param name="nFlagsAndAtrribute">
        ///     File attributes for the new file. This parameter can be any
        ///     combination of the FILE_ATTRIBUTE_* flags used by the CreateFile function.
        /// </param>
        /// <param name="nFlags">
        ///     Controls how the function will handle the file download. The first set of flag
        ///     values indicates the conditions under which the transfer occurs. These transfer type flags can be
        ///     used in combination with the second set of flags that control caching.
        /// </param>
        /// <param name="nContext">
        ///     Contains the application-defined value that associates this search with any
        ///     application data. This is used only if the application has already called InternetSetStatusCallback
        ///     to set up a status callback function.
        /// </param>
        /// <returns></returns>
        [DllImport("wininet.dll", EntryPoint = "FtpGetFile", SetLastError = true, CharSet = CharSet.Auto)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool FtpGetFile(IntPtr hFtpConn, string strSource, string strTarget, [MarshalAs(UnmanagedType.Bool)] bool bFailIfExists, uint nFlagsAndAtrribute, uint nFlags, uint nContext);

        /// <summary>
        ///     Closes a single Internet handle or a subtree of Internet handles.
        /// </summary>
        /// <param name="hInternet">Valid Internet handle to be closed.</param>
        /// <returns>
        ///     Returns TRUE if the handle is successfully closed, or FALSE otherwise. To get extended error
        ///     information, call GetLastError.
        /// </returns>
        [DllImport("wininet.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool InternetCloseHandle(IntPtr hInternet);

        /// <summary>
        ///     Gets one or more files from the given server, using the given credentials, matching
        ///     the given filename.
        /// </summary>
        /// <param name="server">The FTP server name.</param>
        /// <param name="username">The username.</param>
        /// <param name="password">The password.</param>
        /// <param name="filename">The filename.  Wild card characters are allowed.</param>
        /// <exception cref="System.ComponentModel.Win32Exception">
        /// </exception>
        public static void GetFtpFiles(string server, string username, string password, string filename)
        {
            // Clears the log buffer.
            sLogBuffer.Clear();

            // Logs getting files from FTP.
            sLogBuffer.AppendLine("Getting files from FTP.");

            // Contains information about the file that is found.
            WIN32_FIND_DATA find = new WIN32_FIND_DATA();

            // Initializes an application's use of the WinINet functions.
            IntPtr hInternet = InternetOpen("browser", INTERNET_OPEN_TYPE_DIRECT, null, null, 0);
            if (hInternet == IntPtr.Zero)
            {
                throw new Win32Exception(Marshal.GetLastWin32Error());
            }

            // Opens an File Transfer Protocol (FTP) or HTTP session for a given site.
            IntPtr hFTPhandle = InternetConnect(hInternet, server, INTERNET_DEFAULT_FTP_PORT, username, password, INTERNET_SERVICE_FTP, INTERNET_FLAG_PASSIVE, 0);
            if (hFTPhandle == IntPtr.Zero)
            {
                throw new Win32Exception(Marshal.GetLastWin32Error());
            }

            // Logs downloading...
            sLogBuffer.AppendLine("Downloading files from FTP...");

            // Searches the specified directory of the given FTP session. File and directory entries are returned to 
            // the application in the WIN32_FIND_DATA structure.
            IntPtr hFind = FtpFindFirstFile(hFTPhandle, HistoricalReader.WebPortPlcTagFilenamePattern, out find, 0, IntPtr.Zero);
            sLogBuffer.AppendLine("\t" + find.FileName);
            if (!FtpGetFile(hFTPhandle, find.FileName, Reader.NormalizeWebPortFileName(find.FileName), false, FILE_ATTRIBUTE_NORMAL, 0, 0))
            {
                sLogBuffer.AppendLine("\t" + "Failed to FtpGet " + find.FileName);
            }

            // Continues the file search started as a result of a previous call to FtpFindFirstFile.
            while (InternetFindNextFile(hFind, out find))
            {
                if (find.FileName.IndexOf("/") != -1)
                {
                    sLogBuffer.AppendLine("\t" + "Can't FtpGet " + find.FileName + " due to filename '/' character.");
                }
                else
                {
                    sLogBuffer.AppendLine("\t" + find.FileName);
                    if (!FtpGetFile(hFTPhandle, find.FileName, Reader.NormalizeWebPortFileName(find.FileName), false, FILE_ATTRIBUTE_NORMAL, 0, 0))
                    {
                        sLogBuffer.AppendLine("\t" + "Failed to FtpGet " + find.FileName);
                    }
                }
            }

            // Closes a single Internet handle or a subtree of Internet handles.
            if (!InternetCloseHandle(hFTPhandle))
            {
                throw new Win32Exception(Marshal.GetLastWin32Error());
            }
        }

        /// <summary>
        ///     Contains information about the file that is found by the FindFirstFile, FindFirstFileEx, or FindNextFile
        ///     function.
        /// </summary>
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        private struct WIN32_FIND_DATA
        {
            /// <summary>
            ///     The file attributes of a file. For possible values and their descriptions, see File Attribute
            ///     Constants. The FILE_ATTRIBUTE_SPARSE_FILE attribute on the file is set if any of the streams of the
            ///     file have ever been sparse.
            /// </summary>
            public readonly uint FileAttributes;

            /// <summary>
            ///     A FILETIME structure that specifies when a file or directory was created. If the underlying file
            ///     system does not support creation time, this member is zero.
            /// </summary>
            public readonly FILETIME CreationTime;

            /// <summary>
            ///     A FILETIME structure. For a file, the structure specifies when the file was last read from, written
            ///     to, or for executable files, run. For a directory, the structure specifies when the directory is
            ///     created. If the underlying file system does not support last access time, this member is zero. On
            ///     the FAT file system, the specified date for both files and directories is correct, but the time of
            ///     day is always set to midnight.
            /// </summary>
            public readonly FILETIME LastAccessTime;

            /// <summary>
            ///     A FILETIME structure. For a file, the structure specifies when the file was last written to, truncated,
            ///     or overwritten, for example, when WriteFile or SetEndOfFile are used. The date and time are not updated
            ///     when file attributes or security descriptors are changed. For a directory, the structure specifies when
            ///     the directory is created. If the underlying file system does not support last write time, this member
            ///     is zero.
            /// </summary>
            public readonly FILETIME LastWriteTime;

            /// <summary>
            ///     The high-order DWORD value of the file size, in bytes. This value is zero unless the file size is greater
            ///     than MAXDWORD. The size of the file is equal to (nFileSizeHigh * (MAXDWORD+1)) + nFileSizeLow.
            /// </summary>
            public readonly uint FileSizeHigh;

            /// <summary>
            ///     The low-order DWORD value of the file size, in bytes.
            /// </summary>
            public readonly uint FileSizeLow;

            /// <summary>
            ///     If the dwFileAttributes member includes the FILE_ATTRIBUTE_REPARSE_POINT attribute, this member specifies
            ///     the reparse point tag. Otherwise, this value is undefined and should not be used.
            /// </summary>
            public readonly uint Reserved0;

            /// <summary>
            ///     Reserved for future use.
            /// </summary>
            public readonly uint Reserved1;

            /// <summary>
            ///     The name of the file.
            /// </summary>
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)] public readonly string FileName;

            /// <summary>
            ///     An alternative name for the file. This name is in the classic 8.3 file name format.
            /// </summary>
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 14)] public readonly string AlternateFileName;
        }
    }
}