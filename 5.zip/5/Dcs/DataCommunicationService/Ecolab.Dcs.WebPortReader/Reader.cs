﻿// -----------------------------------------------------------------------
// <copyright file="Reader.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Reader</summary>
// -----------------------------------------------------------------------

/* 
 * TODO - There is an issue with some of the WebPort filenames that include forward slashes (/) in the 
 * filename. Allen Bradley bit level addresses, S:5/0 for example, include a forward slash (/) to delimit
 * the word address from the bit position.  Unfortunately, the .NET and Win32 FTP methods interpret 
 * forward slashes (/) to delimit paths, and, when a filename includes a forward slash (/) the methods
 * assume the filename to be a relative file specification, i.e. include a path under the FTP URL and
 * default path.  For example, the file ftp://192.168.0.240/s_5/0.txt is considered by .NET and Win23 
 * to be the file 0.txt at URL ftp://192.168.0.240/s_5/ rather than file s_5/0.txt at ftp://192.168.0.240/, 
 * which is the case with Allen Bradly addresses in WebPort.  Somehow there is a way to include a forward 
 * slash in the  file name or use method that only accept an absolute path as the filename as there are 
 * many FTP clients that handle this situation.
 */

namespace Ecolab.Dcs.WebPortReader
{
    using System;
    using System.Collections.Concurrent;
    using System.Collections.Generic;
    using System.Net;

    /// <summary>
    ///     Provides an abstract class for reading a WebPort device.
    /// </summary>
    public abstract class Reader
    {
        #region Cancel

        /// <summary>
        ///     Cancels a WebPort read in progress.
        /// </summary>
        public abstract void Cancel();

        #endregion Cancel

        #region Constructor

        /// <summary>
        ///     Initializes a new instance of the <see cref="Reader" /> class.
        /// </summary>
        public Reader()
        {
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="Reader" /> class specifying the URI.
        /// </summary>
        /// <param name="uri">The URI.</param>
        public Reader(string uri) : this()
        {
            m_Uri = uri;
            m_Uri = string.Empty;
            m_ConnectionLimit = 3;
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="Reader" /> class specifying the URI,
        ///     username and password.
        /// </summary>
        /// <param name="uri">The URI.</param>
        /// <param name="userName">The username.</param>
        /// <param name="password">The password.</param>
        public Reader(string uri, string userName, string password) : this(uri)
        {
            m_UserName = userName;
            m_Password = password;
            m_Uri = string.Empty;
            m_ConnectionLimit = 3;
        }

        #endregion Constructor

        #region Fields

        /// <summary>
        ///     The URI.
        /// </summary>
        internal string m_Uri;

        /// <summary>
        ///     Gets or sets the URI.
        /// </summary>
        public string Uri
        {
            get { return m_Uri; }
            set { m_Uri = value; }
        }

        /// <summary>
        ///     The Username.
        /// </summary>
        internal string m_UserName;

        /// <summary>
        ///     Gets or sets the Username.
        /// </summary>
        public string Username
        {
            get { return m_UserName; }
            set { m_UserName = value; }
        }

        /// <summary>
        ///     The Password.
        /// </summary>
        internal string m_Password;

        /// <summary>
        ///     Gets or sets the Password.
        /// </summary>
        public string Password
        {
            get { return m_Password; }
            set { m_Password = value; }
        }

        public int Timeout { get; set; }
        /// <summary>
        ///     The maximum number of concurrent connections.
        /// </summary>
        /// <remarks>The default value is 3.</remarks>
        internal int m_ConnectionLimit = 3;

        /// <summary>
        ///     Gets or sets the maximum number of concurrent connections.
        /// </summary>
        /// <remarks>The default value is 3.</remarks>
        public int ConnectionLimit
        {
            get { return m_ConnectionLimit; }
            set { m_ConnectionLimit = value; }
        }

        //public int Timeout { get; set; }
        #endregion Fields

        #region Read

        /// <summary>
        /// Collection of most recent tags.
        /// </summary>
        private static ConcurrentDictionary<string, TagValue> m_TagsValue = new ConcurrentDictionary<string, TagValue>();

        /// <summary>
        /// Gets or sets the m_ tags.
        /// </summary>
        /// <value>
        /// The m_ tags value.
        /// </value>
        public static ConcurrentDictionary<string, TagValue> m_Tags
        {
            get { return m_TagsValue; }
            set { m_TagsValue = value; }
        }

        /// <summary>
        /// The m_ web port tags value
        /// </summary>
        private static List<WebPortTags> m_WebPortTagsValue = new List<WebPortTags>();

        /// <summary>
        /// Gets or sets the m_ web port tags.
        /// </summary>
        /// <value>
        /// The m_ web port tags.
        /// </value>
        public static List<WebPortTags> m_WebPortTags
        {
            get { return m_WebPortTagsValue; }
            set { m_WebPortTagsValue = value; }
        }

        /// <summary>
        /// The m_ bad web port tags value
        /// </summary>
        private static List<WebPortTags> m_BadWebPortTagsValue = new List<WebPortTags>();

        /// <summary>
        /// Gets or sets the m_ bad web port tags.
        /// </summary>
        /// <value>
        /// The m_ bad web port tags.
        /// </value>
        public static List<WebPortTags> m_BadWebPortTags
        {
            get { return m_BadWebPortTagsValue; }
            set { m_BadWebPortTagsValue = value; }
        }

        /// <summary>
        ///     Downloads the resource with the specified URI as a System.Byte array.
        /// </summary>
        /// <param name="address">The URI from which to download data.</param>
        /// <returns>A System.Byte array containing the downloaded resource.</returns>
        internal byte[] DownloadData(string address)
        {
			using(CustomWebClient webClient = new CustomWebClient())
            {
                webClient.Credentials = new NetworkCredential(m_UserName, m_Password);
				                return webClient.DownloadData(address);
            }
        }

        /// <summary>
        ///     Reads the WebPort device.
        /// </summary>
        public abstract void Read(DateTime webportdatetime, List<string> lastDownloadFileList);

        /// <summary>
        ///     Normalize a WebPort filename.
        /// </summary>
        /// <param name="fileName">The filename.</param>
        /// <returns>A valid Windows filename.</returns>
        /// <remarks>
        ///     WebPort filenames can contain characters that are not valid for Windows
        ///     filenames. This method replaces reserved characters with a placeholder.
        /// </remarks>
        public static string NormalizeWebPortFileName(string fileName)
        {
            // These chars are not allowed in Windows filenames.
            char[] reservedChars = { '<', '>', ':', '"', '/', '\\', '|', '?', '*' };
            // Reserved chars will be replaced with a placeholder char.
            const char placeholder = '_';
            // Replaces all reserved chars with a placeholder char.
            foreach (char reservedChar in reservedChars)
            {
                fileName = fileName.Replace(reservedChar, placeholder);
            }
            // Returns a valid filename.
            return fileName;
        }

        #endregion Read

        #region Started Event

        /// <summary>
        ///     Occurs when the WebPort.Reader.Read has started.
        /// </summary>
        /// <remarks>Use this event for positive feedback the WebPort reader started.</remarks>
        public event EventHandler StartedEvent;

        /// <summary>
        ///     Raises the WebPort.Reader Started event.
        /// </summary>
        /// <remarks>Use this event for positive feedback the WebPort reader started.</remarks>
        protected virtual void OnStarted()
        {
            if (StartedEvent != null)
            {
                StartedEvent(this, EventArgs.Empty);
            }
        }

        #endregion Started Event

        #region Status Message Event

        /// <summary>
        ///     Provides arguments for a status message event.
        /// </summary>
        public class StatusMessageEventArgs : EventArgs
        {
            /// <summary>
            ///     The status message.
            /// </summary>
            private readonly string mStausMessage;

            /// <summary>
            ///     Initializes a new instance of the <see cref="StatusMessageEventArgs" /> class.
            /// </summary>
            /// <param name="statusMessage">The status message.</param>
            public StatusMessageEventArgs(string statusMessage)
            {
                mStausMessage = statusMessage;
            }

            /// <summary>
            ///     Gets the status message.
            /// </summary>
            public string StatusMessage
            {
                get { return mStausMessage; }
            }
        }

        /// <summary>
        ///     Provides a delegate for a WebPort.Reader status message.
        /// </summary>
        /// <param name="sender">The object that originated the event.</param>
        /// <param name="e">The <see cref="StatusMessageEventArgs" /> instance containing the event data.</param>
        public delegate void StatusMessageEventHandler(object sender, StatusMessageEventArgs e);

        /// <summary>
        ///     Occurs when the WebPort.Reader sends a status message.
        /// </summary>
        public event StatusMessageEventHandler StatusMessageEvent;

        /// <summary>
        ///     Raises the WebPort.Reader status message event.
        /// </summary>
        /// <param name="statusMessage">The status message.</param>
        protected virtual void OnStatusMessage(string statusMessage)
        {
            if (StatusMessageEvent != null)
            {
                StatusMessageEvent(this, new StatusMessageEventArgs(statusMessage));
            }
        }

        #endregion Status Message Event

        #region Communication Event

        /// <summary>
        ///     Occurs when the WebPort.Reader receives communication from the WebPort.
        /// </summary>
        public event EventHandler CommunicationEvent;

        /// <summary>
        ///     Raises the WebPort.Reader communication event.
        /// </summary>
        /// <remarks>Use this event for positive feedback that communication is okay.</remarks>
        protected virtual void OnCommunication()
        {
            if (CommunicationEvent != null)
            {
                CommunicationEvent(this, EventArgs.Empty);
            }
        }

        #endregion Communication Event

        #region Tag Value Event

        /// <summary>
        ///     Provides arguments for a tag value event.
        /// </summary>
        public class TagValueEventArgs : EventArgs
        {
            /// <summary>
            ///     The tag name.
            /// </summary>
            private readonly string mName;

            /// <summary>
            ///     The timestamp of the tag value.
            /// </summary>
            private readonly DateTime mTimestamp;

            /// <summary>
            ///     The tag value.
            /// </summary>
            private readonly string mValue;

            /// <summary>
            ///     Initializes a new instance of the <see cref="TagValueEventArgs" /> class.
            /// </summary>
            /// <param name="name">The tag name.</param>
            /// <param name="timestamp">The timestamp.</param>
            /// <param name="value">The tag value.</param>
            public TagValueEventArgs(string name, DateTime timestamp, string value)
            {
                mName = name;
                mTimestamp = timestamp;
                mValue = value;
            }

            /// <summary>
            ///     Gets the tag name.
            /// </summary>
            public string Name
            {
                get { return mName; }
            }

            /// <summary>
            ///     Gets the timestamp of the tag value.
            /// </summary>
            public DateTime Timestamp
            {
                get { return mTimestamp; }
            }

            /// <summary>
            ///     Gets the tag value.
            /// </summary>
            public string Value
            {
                get { return mValue; }
            }
        }

        /// <summary>
        ///     Provides a delegate for a WebPort tag value event.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="TagValueEventArgs" /> instance containing the event data.</param>
        public delegate bool TagValueEventHandler(object sender, TagValueEventArgs e);

        /// <summary>
        ///     Occurs when an tag value is received.
        /// </summary>
        public event TagValueEventHandler TagValueEvent;

        /// <summary>
        ///     Raises the tag value event.
        /// </summary>
        /// <param name="name">The tag name.</param>
        /// <param name="timestamp">The timestamp.</param>
        /// <param name="value">The tag value.</param>
        /// <returns>
        ///     When used in a derived class, returns <c>true</c>to indicate processing need continue
        ///     because last read timestamp has not yet reached, <c>false</c> indicates last read timestamp has
        ///     been reached so processing can stop.
        /// </returns>
        /// <remarks>
        ///     This method will accept a return value from subscriber's event handlers, however, in
        ///     the case there are more than one subscribers on the last subscriber's event handler will be able
        ///     to effectively pass a return value.
        /// </remarks>
        protected virtual bool OnTagValue(string name, DateTime timestamp, string value)
        {
            bool _continue = true;
            if (TagValueEvent != null)
            {
                _continue = TagValueEvent(this, new TagValueEventArgs(name, timestamp, value));
            }
            return _continue;
        }

        #endregion Tag Value Event

        #region Exception Event

        /// <summary>
        ///     Provides arguments for an exception event.
        /// </summary>
        public class ExceptionEventArgs : EventArgs
        {
            /// <summary>
            ///     The System.Exception.
            /// </summary>
            private readonly Exception mException;

            /// <summary>
            ///     Initializes a new instance of the <see cref="ExceptionEventArgs" /> class.
            /// </summary>
            /// <param name="exception">The exception.</param>
            public ExceptionEventArgs(Exception exception)
            {
                mException = exception;
            }

            /// <summary>
            ///     Gets the System.Exception.
            /// </summary>
            public Exception Exception
            {
                get { return mException; }
            }
        }

        /// <summary>
        ///     Provides a delegate for an exception event.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="ExceptionEventArgs" /> instance containing the event data.</param>
        public delegate void ExceptionEventHandler(object sender, ExceptionEventArgs e);

        /// <summary>
        ///     Occurs when an exception occurs.
        /// </summary>
        public event ExceptionEventHandler ExceptionEvent;

        /// <summary>
        ///     Raises the exception event.
        /// </summary>
        /// <param name="exception">The exception.</param>
        protected virtual void OnException(Exception exception)
        {
            if (ExceptionEvent != null)
            {
                ExceptionEvent(this, new ExceptionEventArgs(exception));
            }
        }

        #endregion Exception Event

        #region Completion Event

        /// <summary>
        ///     Occurs when the WebPort.Reader.Read is complete.
        /// </summary>
        /// <remarks>Use this event for positive feedback the read is complete.</remarks>
        public event EventHandler CompletionEvent;

        /// <summary>
        ///     Raises the WebPort.Reader Completion event.
        /// </summary>
        /// <remarks>Use this event for positive feedback the read is complete.</remarks>
        protected virtual void OnCompletion()
        {
            if (CompletionEvent != null)
            {
                CompletionEvent(this, EventArgs.Empty);
            }
        }

        #endregion Completion Event

        #region Canceled Event

        /// <summary>
        ///     Occurs when the WebPort.Reader.Read is canceled.
        /// </summary>
        /// <remarks>Use this event for positive feedback the cancel is complete.</remarks>
        public event EventHandler CanceledEvent;

        /// <summary>
        ///     Raises the WebPort.Reader Canceled event.
        /// </summary>
        /// <remarks>Use this event for positive feedback the cancel is complete.</remarks>
        protected virtual void OnCanceled()
        {
            if (CanceledEvent != null)
            {
                CanceledEvent(this, EventArgs.Empty);
            }
        }

        #endregion Canceled Event
    }
}