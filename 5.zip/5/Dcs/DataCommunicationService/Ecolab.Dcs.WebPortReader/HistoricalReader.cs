﻿// -----------------------------------------------------------------------
// <copyright file="HistoricalReader.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Historical Reader</summary>
// -----------------------------------------------------------------------

/* 
 * TODO - There is an issue with some of the WebPort filenames that include forward slashes (/) in the 
 * filename. Allen Bradley bit level addresses, S:5/0 for example, include a forward slash (/) to delimit
 * the word address from the bit position.  Unfortunately, the .NET and Win32 FTP methods interpret 
 * forward slashes (/) to delimit paths, and, when a filename includes a forward slash (/) the methods
 * assume the filename to be a relative file specification, i.e. include a path under the FTP URL and
 * default path.  For example, the file ftp://192.168.0.240/s_5/0.txt is considered by .NET and Win23 
 * to be the file 0.txt at URL ftp://192.168.0.240/s_5/ rather than file s_5/0.txt at ftp://192.168.0.240/, 
 * which is the case with Allen Bradly addresses in WebPort.  Somehow there is a way to include a forward 
 * slash in the  file name or use method that only accept an absolute path as the filename as there are 
 * many FTP clients that handle this situation.
 */

namespace Ecolab.Dcs.WebPortReader
{
    using System;
    using System.Collections.Concurrent;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Net;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
  
    /// <summary>
    ///     Provides a class for reading historical tag values from a WebPort device.
    /// </summary>
    public class HistoricalReader : Reader
    {
        #region Exception Event

        /// <summary>
        ///     Raises the exception event.
        /// </summary>
        /// <param name="exception">The exception.</param>
        protected override void OnException(Exception exception)
        {
            base.OnException(exception);
        }

        #endregion Exception Event

        #region Completion Event

        /// <summary>
        ///     Raises the WebPort.Reader Completion event.
        /// </summary>
        /// <remarks>Use this event for positive feedback the read is complete.</remarks>
        protected override void OnCompletion()
        {
            base.OnCompletion();
        }

        #endregion Completion Event

        #region Canceled Event

        /// <summary>
        ///     Raises the WebPort.Reader Canceled event.
        /// </summary>
        /// <remarks>Use this event for positive feedback the cancel is complete.</remarks>
        protected override void OnCanceled()
        {
            base.OnCanceled();
        }

        #endregion Canceled Event

        #region Historical Timestamp

        /// <summary>
        ///     The historical timestamp that delineates new data.
        /// </summary>
        /// <remarks>After a read the reader keeps track of last read timestamp for each tag.</remarks>
        private DateTime historicalTimestamp = DateTime.MinValue;

        /// <summary>
        ///     Gets the historical timestamp that delineates new data.
        /// </summary>
        /// <remarks>
        ///     After a read the reader keeps track of last read timestamp for each tag. This value
        ///     is essentially used for unread tags.
        /// </remarks>
        public DateTime HistoricalTimestamp
        {
            get { return historicalTimestamp; }
        }

        /// <summary>
        ///     Sets a historical timestamp that delineates new data.
        /// </summary>
        /// <param name="timestamp">The timestamp to set.</param>
        /// <remarks>
        ///     This method can be executed while reading a WebPort however it would then be possible
        ///     for the reader to update a tag value and overwrite the timestamp. Best to stop the reader, set
        ///     the timestamp and then start a new read.
        /// </remarks>
        public void SetHistoricalTimestamp(DateTime timestamp)
        {
            historicalTimestamp = timestamp;
            Parallel.ForEach(m_Tags.Values, tagValue => tagValue.Timestamp = timestamp);
        }

        #endregion Historical Timestamp

        #region Read

        /// <summary>
        ///     Threadsafe collection of tasks.
        /// </summary>
        private ConcurrentBag<Task> m_Tasks;

        /// <summary>
        ///     Keeps track of number of filenames.
        /// </summary>
        private int m_FilenamesCount;

        /// <summary>
        ///     Keeps track of the number of files processed.
        /// </summary>
        private int m_ProcessCount;

        /// <summary>
        ///     Reads WebPort PLC tag files.
        /// </summary>
        public override void Read(DateTime webportdatetime, List<string> lastDownloadFileList)
        {
            try
            {
               m_WebPortTags = new List<WebPortTags>();
                // Inform subscribers the read has started.
                OnStarted();

                // Initialize
                m_Cancel = false;
                ServicePointManager.DefaultConnectionLimit = m_ConnectionLimit;
                m_CancellationTokenSource = new CancellationTokenSource();
                m_Tasks = new ConcurrentBag<Task>();

                /*
                 * First step, get a list of tag historical files on the WebPort.
                 */

                OnStatusMessage("Opening FTP connection: " + m_Uri);
                FtpWebRequest ftpRequest = (FtpWebRequest)WebRequest.Create(new Uri(m_Uri));
                ftpRequest.UsePassive = true;
                ftpRequest.UseBinary = true;
                ftpRequest.KeepAlive = true;
                ftpRequest.Timeout = Timeout;
                ftpRequest.Credentials = new NetworkCredential(m_UserName, m_Password);

                // Aborts if canceled.
                if (m_Cancel)
                {
                    OnStatusMessage("Read canceled");
                    OnCanceled();
                    return;
                }

                // Creates a collection of filenames of files in the WebPort.
                var filenames = new List<string>();

                OnStatusMessage("Retrieving directory listing from FTP");
                ftpRequest.Method = WebRequestMethods.Ftp.ListDirectory;
                using (FtpWebResponse ftpResponse = (FtpWebResponse)ftpRequest.GetResponse())
                {
                    // Aborts if canceled.
                    if (m_Cancel)
                    {
                        OnStatusMessage("Read canceled");
                        OnCanceled();
                        return;
                    }

                    // Lets the subscriber know communication is okay.
                    OnCommunication();

                    OnStatusMessage("Reading directory listing from FTP");
                    using (StreamReader streamReader = new StreamReader(ftpResponse.GetResponseStream()))
                    {
                        // Aborts if canceled.
                        if (m_Cancel)
                        {
                            OnStatusMessage("Read canceled");
                            OnCanceled();
                            return;
                        }

                        string line = streamReader.ReadLine();
                        List<string> tempList = new List<string>();
                        while (!string.IsNullOrEmpty(line))
                        {
                            // Aborts if canceled.
                            if (m_Cancel)
                            {
                                OnStatusMessage("Read canceled");
                                OnCanceled();
                                return;
                            }

                            // Retrieve a filename from the WebPort directory listing.
                            string filename = line.Trim();
                            if (FilePattern.Match(WebPortPlcTagFilenamePattern, filename))
                            {
                                if (lastDownloadFileList.Contains(filename))
                                {
                                    tempList.Add(filename); //Adding the files which are to be downloaded at the begining
                                }
                                else
                                {
                                    filenames.Add(filename);
                                }
                            }
                            line = streamReader.ReadLine();
                        }
                        foreach (string tempFile in tempList)
                        {
                            filenames.Insert(0, tempFile);
                        }
                    }
                }

                // Aborts if canceled.
                if (m_Cancel)
                {
                    OnStatusMessage("Read canceled");
                    OnCanceled();
                    return;
                }

                /*
                 * Second, with the list of filenames, download and parse each file.
                 */

                OnStatusMessage("Downloading & parsing tag data...");                                

                // Initializes the file count.
                m_ProcessCount = 0;
                m_FilenamesCount = filenames.Count;

                // Reads the specified WebPort file.
                foreach (string filename in filenames)
                {
                    if (m_Cancel)
                    {
                        OnStatusMessage("Read canceled");
                        OnCanceled();
                        return;
                    }

                    // Queue a filename to read as a task.
                    Task item = Task.Run(() => ReadFile(filename, webportdatetime), m_CancellationTokenSource.Token);
                    m_Tasks.Add(item);
                }

                // Wait for all tasks to complete.
                Task.WaitAll(m_Tasks.ToArray());

                // End of read
                if (m_Cancel)
                {
                    OnStatusMessage("Read canceled");
                    OnCanceled();
                }
                else
                {
                    // Having gone through the list of files once then the historical read is complete.
                    if (!m_HistoricalReadComplete)
                    {
                        m_HistoricalReadComplete = true;
                        OnHistoricalReadProgress(100);
                        OnHistoricalReadComplete(m_HistoricalReadComplete);
                    }
                    // Completion
                    OnStatusMessage("Read Completed");
                    OnCompletion();
                }
            }
            catch (AggregateException ex)
            {
                // Looks for a cancel.
                if (ex.InnerException is TaskCanceledException)
                {
                    OnStatusMessage("Read canceled");
                    OnCanceled();
                }
                else
                {
                    // Not a cancel, something else, so handle as error.
                    OnException(new Exception("Read error: " + ex.Message, ex));
                }
            }
            catch (TaskCanceledException)
            {
                OnStatusMessage("Read canceled");
                OnCanceled();
            }
            catch (Exception ex)
            {
                if (m_Cancel)
                {
                    OnStatusMessage("Read canceled");
                    OnCanceled();
                }
                else
                {
                    OnException(new Exception("Read error: " + ex.Message, ex));
                    throw ex;
                }
            }
            finally
            {
                if (m_CancellationTokenSource != null)
                {
                    m_CancellationTokenSource.Dispose();
                    m_CancellationTokenSource = null;
                }
                DisposeAllTasks();
            }
        }

        /// <summary>
        ///     Reads and parses the specified WebPort file.
        /// </summary>
        /// <param name="filename">The WebPort filename.</param>
        private void ReadFile(string filename, DateTime webportdatetime)
        {
            try
            {
                // Can't handle filenames with a backslash (/) character.
                if (filename.IndexOf("/") != -1)
                {
                    OnStatusMessage("\t" + "Can't FtpGet " + filename + " due to '/' character in filename.");
                }
                else
                {
                    // Assemble a Uri for file.
                    string ftpPath = m_Uri + System.Uri.EscapeDataString(filename);
                    NormalizeWebPortFileName(filename);

                    //  Gets the tag name from the WebPort filename.
                    string name = GetTagName(filename);

                    // Downloads the file's data from WebPort
                    byte[] data = DownloadData(ftpPath);

                    // Check for cancel.
                    if (m_Cancel)
                    {
                        return;
                    }

                    // Lets the subscriber know communication is okay.
                    OnCommunication();

                    // Processes the data.
                    Task item = Task.Run(() => ProcessData(name, Encoding.UTF8.GetString(data), webportdatetime), m_CancellationTokenSource.Token);
                    m_Tasks.Add(item);
                }
            }
            catch (Exception ex)
            {
                if (!m_Cancel)
                {
                    OnException(new Exception("ReadFile error: " + filename + ". " + ex.Message, ex));
                }
            }
        }

        /// <summary>
        ///     Processes WebPort historical data.
        /// </summary>
        /// <param name="name">The tag name.</param>
        /// <param name="data">The WebPort historical file data.</param>
        /// <remarks>
        ///     This method processes the file from the bottom to the top.  The idea is that
        ///     processing from the bottom processes new data first until previously process data is
        ///     reached at which the processing can stop.
        /// </remarks>
        private void ProcessData(string name, string data, DateTime webportdatetime)
        {
            try
            {
                // Get the last timestamp of the read.
                DateTime timestampLast;                
                // Defaults to the historical timestamp for new reads.
                timestampLast = historicalTimestamp;                

                int length = data.Length;
                int end = data.IndexOf("\r\n"); // Finds the end of the header.
                if (length > end + 2)
                {
                    int start = data.Length - 1;
                    int count = start - end - 1;
                    int curCrLf = data.LastIndexOf("\r\n", start, count);
                    int prevCrLf = curCrLf;
                    bool timestampLastNotYet = true;
                    while (timestampLastNotYet && (curCrLf > -1))
                    {
                        if (m_Cancel)
                        {
                            return;
                        }
                        curCrLf = data.LastIndexOf("\r\n", prevCrLf - 2, prevCrLf - end);
                        if (curCrLf > -1)
                        {
                            string line = data.Substring(curCrLf + 2, prevCrLf - curCrLf - 2);
                            timestampLastNotYet = ParseLine(name, timestampLast, line, webportdatetime);
                            prevCrLf = curCrLf;
                        }
                    }
                }

                // Calculate a historical read percent complete value.
                if (!m_HistoricalReadComplete)
                {
                    OnHistoricalReadProgress((++m_ProcessCount) * 100 / m_FilenamesCount);
                }
                // Update tag name on completion.
                OnStatusMessage("\t" + name);
            }
            catch (Exception ex)
            {
                OnException(new Exception("ProcessData error: " + name + ". " + ex.Message, ex));
            }
        }

        /// <summary>
        ///     Parses one line of a WebPort historical file.
        /// </summary>
        /// <param name="name">The tag name being parsed.</param>
        /// <param name="timestamp">The timestamp of the last read.</param>
        /// <param name="line">One line of WebPort historical text.</param>
        /// <returns>
        ///     <c>true</c> to indicate processing need continue because last read
        ///     timestamp has not yet reached, <c>false</c> indicates last timestamp
        ///     reached so processing can stop.
        /// </returns>
        private bool ParseLine(string name, DateTime timestamp, string line, DateTime webportdatetime)
        {
            if (name == "N7:60")
            { 
            
            }
            /* 
            * Example WebPort file format:
            * 
            * "TimeInt";"TimeStr";"IsInitValue";"Value";"IQuality"
            * 1407329568;"06/08/2014 12:52:48";0;695;3
            * 1407330047;"06/08/2014 13:00:47";0;0;3
            * 1407335596;"06/08/2014 14:33:16";0;680;3
            * 1407336038;"06/08/2014 14:40:38";0;0;3
            * 1407386880;"07/08/2014 04:48:00";1;0;0
            * 1407418271;"07/08/2014 13:31:11";0;675;3
            * 1407418399;"07/08/2014 13:33:19";0;0;3
            * 1407421066;"07/08/2014 14:17:46";1;0;0
            * 1407422748;"07/08/2014 14:45:48";0;1198;3
            * 1407423869;"07/08/2014 15:04:29";0;0;3
            * 1407424846;"07/08/2014 15:20:46";0;1198;3
            * 1407425316;"07/08/2014 15:28:36";0;0;3
            * 1407432604;"07/08/2014 17:30:04";0;1170;3
            */

            const int fieldsNumTimeInt = 0;
            const int fieldsNumTimeStr = 1;
            const int fieldsNumIsInitValue = 2;
            const int fieldsNumValue = 3;
            const int fieldsNumIQuality = 4;
            const int fieldsNumMin = fieldsNumTimeInt;
            const int fieldsNumMax = fieldsNumIQuality;
            const int fieldsNumLength = fieldsNumMax - fieldsNumMin + 1;

            // WebPort PLC tag file formate is as a semicolon (;) separated file.
            char[] separator = { ';' };

            string[] fields = line.Split(separator);
            if (fields.Length < fieldsNumLength)
            {
                OnStatusMessage("Error: ParseLine - Tag: " + name + ", line: " + line);
                return true;
            }

            //string fieldTimeInt = fields[fieldsNumTimeInt];
            string fieldTimeStr = fields[fieldsNumTimeStr].Replace("\"", string.Empty);
            string fieldIsInitValue = fields[fieldsNumIsInitValue];
            string fieldValue = fields[fieldsNumValue];
            string fieldIQuality = fields[fieldsNumIQuality];

            // Parse the WebPort time string into a DataTime.
            const string format = "dd/MM/yyyy HH:mm:ss"; // Example WebPort timestamp: "06/08/2014 12:52:48"
            CultureInfo provider = CultureInfo.InvariantCulture;
            DateTime fieldDateTime = DateTime.ParseExact(fieldTimeStr, format, provider);

            // Adds new data, ignores data already processed based on timestamp.//Hanuma Commented as we need to get data from one timestamp to another timestamp
            //m_Tags.AddOrUpdate(name,
            //    (tag) => new TagValue(fieldDateTime, fieldValue),
            //    (tag, tagValue) =>
            //    {
            //        if (fieldDateTime > tagValue.Timestamp)
            //        {
            //            tagValue.Timestamp = fieldDateTime;
            //            tagValue.Value = fieldValue;
            //        }
            //        return tagValue;
            //    });

            if (fieldDateTime > webportdatetime)
            {
                if (name != null && fieldValue != null)
                {
                    if (fieldIQuality == "3" && fieldIsInitValue == "0")
                    {
                        m_WebPortTags.Add(new WebPortTags(name, new TagValue(fieldDateTime, fieldValue)));
                    }
                    else
                    {
                        m_BadWebPortTags.Add(new WebPortTags(name, new TagValue(fieldDateTime, line)));
                    }
                }
            }

            // A true indicates processing need continue because last read 
            // timestamp has not yet been reached. i.e. new values, false  
            // indicates last read timestamp has been reached, i.e. already 
            // processed values, so processing can stop.
            bool notAtTimestamp = fieldDateTime > timestamp;
            if (notAtTimestamp)
            {
                // Updates historical tag value.  A false indicates the subscriber 
                // has signaled to stop further processing of historical values.
                notAtTimestamp = OnTagValue(name, fieldDateTime, fieldValue);
            }

            // Returns true to indicate processing need continue because last read 
            // timestamp has not yet been reached. i.e. new values, false indicates 
            // last read timestamp has been reached, i.e. already processed, so 
            // processing can stop.
            return notAtTimestamp;
        }

        /// <summary>
        ///     The WebPort PLC tag file's filename prefix.
        /// </summary>
        public const string WebPortPlcTagFilenamePrefix = "irc_";

        /// <summary>
        ///     The WebPort PLC tag file's extension.
        /// </summary>
        public const string WebPortPlcTagFileExtension = ".txt";

        /// <summary>
        ///     TheWebPort PLC tag file's filename pattern.
        /// </summary>
        public const string WebPortPlcTagFilenamePattern = WebPortPlcTagFilenamePrefix + "*" + WebPortPlcTagFileExtension;

        /// <summary>
        ///     Gets the tag name from a WebPort historical filename.
        /// </summary>
        /// <param name="path">The path a WebPort historical file.</param>
        /// <returns>The tag name from a WebPort historical filename.</returns>
        public static string GetTagName(string path)
        {
            // Removes the leading WebPortPlcTagFilenamePrefix, irc_
            string name = path.Remove(0, WebPortPlcTagFilenamePrefix.Length);
            // Removes the trailing WebPortPlcTagFileExtension, .txt
            return name.Remove(name.IndexOf(WebPortPlcTagFileExtension), WebPortPlcTagFileExtension.Length);
        }

        /// <summary>
        ///     An object that can be used to synchronize access to the <see cref="HistoricalReader" /> class.
        /// </summary>
        private readonly object m_SyncRoot = new object();

        /// <summary>
        ///     Removes all tasks out of the tasks collection and Dispose them.
        /// </summary>
        private void DisposeAllTasks()
        {
            lock (m_SyncRoot)
            {
                if (m_Tasks != null)
                {
                    // Removes all tasks.
                    while (!m_Tasks.IsEmpty)
                    {
                        Task task;
                        if (m_Tasks.TryTake(out task))
                        {
                            try
                            {
                                if (task != null)
                                {
                                    if (task.IsCompleted || task.IsFaulted || task.IsCanceled)
                                    {
                                        task.Dispose();
                                    }
                                }
                            }
                            catch (Exception)
                            {
                                // Swallow the exception because the task is being removed and disposed anyway.
                            }
                        }
                    }

                    // Removes the reference to the tasks collection.
                    m_Tasks = null;
                }
            }
        }

        #endregion Read

        #region Cancel

        /// <summary>
        ///     The cancel flag.
        /// </summary>
        private bool m_Cancel;

        /// <summary>
        ///     The thread cancellation token source.
        /// </summary>
        private CancellationTokenSource m_CancellationTokenSource;

        /// <summary>
        ///     Cancels a WebPort read in progress.
        /// </summary>
        public override void Cancel()
        {
            m_Cancel = true;
            if (m_CancellationTokenSource != null && !m_CancellationTokenSource.IsCancellationRequested)
            {
                try
                {
                    m_CancellationTokenSource.Cancel();
                }
                catch (ObjectDisposedException)
                {
                    // Swallows the ObjectDisposedException
                }
                catch (NullReferenceException)
                {
                    // Swallows the NullReferenceException
                }
            }
        }

        #endregion Cancel

        #region Historical Read Progress Event

        /// <summary>
        ///     Provides arguments for a historical read progress event.
        /// </summary>
        public class HistoricalReadProgressEventArgs : EventArgs
        {
            /// <summary>
            ///     The completion progress, 0 to 100.
            /// </summary>
            private readonly int mProgress;

            /// <summary>
            ///     Initializes a new instance of the <see cref="HistoricalReadProgressEventArgs" /> class.
            /// </summary>
            /// <param name="progress">The progress as a percent, 0 to 100.</param>
            public HistoricalReadProgressEventArgs(int progress)
            {
                mProgress = progress;
            }

            /// <summary>
            ///     Gets the completion progress, 0 to 100..
            /// </summary>
            public int Progress
            {
                get { return mProgress; }
            }
        }

        /// <summary>
        ///     Provides a delegate for a WebPort historical progress event.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="HistoricalProgressEventArgs" /> instance containing the event data.</param>
        public delegate void HistoricalReadProgressEventHandler(object sender, HistoricalReadProgressEventArgs e);

        /// <summary>
        ///     Occurs to update on historical data reading progress.
        /// </summary>
        public event HistoricalReadProgressEventHandler HistoricalReadProgressEvent;

        /// <summary>
        ///     Raises the historical progress event.
        /// </summary>
        /// <param name="progress">The historical read progress.</param>
        /// <remarks>Historical read progress values range from 0 to 100%.</remarks>
        protected virtual void OnHistoricalReadProgress(int progress)
        {
            if (HistoricalReadProgressEvent != null)
            {
                HistoricalReadProgressEvent(this, new HistoricalReadProgressEventArgs(progress));
            }
        }

        #endregion Historical Progress Event

        #region Historical Read Complete Event

        /// <summary>
        ///     Provides arguments for a historical read complete event.
        /// </summary>
        public class HistoricalReadCompleteEventArgs : EventArgs
        {
            /// <summary>
            ///     The indicates the completion state of the historical read.
            /// </summary>
            private readonly bool mComplete;

            /// <summary>
            ///     Initializes a new instance of the <see cref="HistoricalReadCompleteEventArgs" /> class.
            /// </summary>
            /// <param name="complete">if set to <c>true</c> [complete].</param>
            public HistoricalReadCompleteEventArgs(bool complete)
            {
                mComplete = complete;
            }

            /// <summary>
            ///     Gets a value indicating the completion state of the historical read.
            /// </summary>
            /// <value>
            ///     <c>true</c> if complete; otherwise, <c>false</c>.
            /// </value>
            public bool Complete
            {
                get { return mComplete; }
            }
        }

        /// <summary>
        ///     Indicates the historical read is complete.
        /// </summary>
        private bool m_HistoricalReadComplete;

        /// <summary>
        ///     Gets a value indicating whether the historical read is complete.
        /// </summary>
        /// <value>
        ///     <c>true</c> if the historical read is complete; otherwise, <c>false</c>.
        /// </value>
        public bool HistoricalReadComplete
        {
            get { return m_HistoricalReadComplete; }
        }

        /// <summary>
        ///     Provides a delegate for the WebPort historical read completion event.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="HistoricalReadCompleteEventArgs" /> instance containing the event data.</param>
        public delegate void HistoricalReadCompleteEventHandler(object sender, HistoricalReadCompleteEventArgs e);

        /// <summary>
        ///     Occurs on the WebPort historical read completion.
        /// </summary>
        public event HistoricalReadCompleteEventHandler HistoricalReadCompleteEvent;

        /// <summary>
        ///     Raises the historical read complete event.
        /// </summary>
        /// <param name="complete">if set to <c>true</c> [complete].</param>
        protected virtual void OnHistoricalReadComplete(bool complete)
        {
            if (HistoricalReadCompleteEvent != null)
            {
                HistoricalReadCompleteEvent(this, new HistoricalReadCompleteEventArgs(complete));
            }
        }

        #endregion Historical Read Complete Event
    }
}