﻿// -----------------------------------------------------------------------
// <copyright file="TagValue.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The TagValue</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Dcs.WebPortReader
{
    using System;

    /// <summary>
    /// Provides a class to contain a tag's value.
    /// </summary>
    public class TagValue
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TagValue" /> class.
        /// </summary>
        /// <param name="timestamp">The timestamp.</param>
        /// <param name="value">The value for Tags.</param>
        public TagValue(DateTime timestamp, string value)
        {
            mTimestamp = timestamp;
            mValue = value;
        }

        /// <summary>
        ///     The time stamp.
        /// </summary>
        private DateTime mTimestamp;

        /// <summary>
        /// Gets or sets the timestamp.
        /// </summary>
        /// <value>
        /// The time stamp.
        /// </value>
        public DateTime Timestamp
        {
            get { return mTimestamp; }
            set { mTimestamp = value; }
        }

        /// <summary>
        /// The value for Tags.
        /// </summary>
        private string mValue;

        /// <summary>
        /// Gets or sets the value for Tags.
        /// </summary>
        /// <value>
        /// The value for Tags.
        /// </value>
        public string Value
        {
            get { return mValue; }
            set { mValue = value; }
        }
    }
}