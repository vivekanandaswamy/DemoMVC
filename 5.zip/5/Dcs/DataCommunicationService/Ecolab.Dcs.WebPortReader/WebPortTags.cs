﻿// -----------------------------------------------------------------------
// <copyright file="WebPortTags.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The WebPortTags</summary>
// -----------------------------------------------------------------------

namespace Ecolab.Dcs.WebPortReader
{
    using System;

    /// <summary>
    /// Class for Web Port Tags
    /// </summary>
    public class WebPortTags
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="WebPortTags"/> class.
        /// </summary>
        /// <param name="key">The key for WebPortTags.</param>
        /// <param name="value">The value for WebPortTags.</param>
        public WebPortTags(string key, TagValue value)
        {
            mKey = key;
            mValue = value;
        }

        /// <summary>
        /// The key for WebPortTags.
        /// </summary>
        private string mKey;

        /// <summary>
        /// Gets or sets the key.
        /// </summary>
        /// <value>
        /// The key for WebPortTags.
        /// </value>
        public string Key
        {
            get { return mKey; }
            set { mKey = value; }
        }

        /// <summary>
        /// The value for WebPortTags.
        /// </summary>
        private TagValue mValue;

        /// <summary>
        /// Gets the value.
        /// </summary>
        /// <value>
        /// The value for WebPortTags.
        /// </value>
        public TagValue Value
        {
            get { return mValue; }
            set { mValue = value; }
        }
    }
}
