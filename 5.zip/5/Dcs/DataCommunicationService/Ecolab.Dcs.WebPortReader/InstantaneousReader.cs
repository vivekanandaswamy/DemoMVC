﻿// -----------------------------------------------------------------------
// <copyright file="InstantaneousReader.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Instantaneous Reader</summary>
// -----------------------------------------------------------------------

/* 
 * TODO - There is an issue with some of the WebPort filenames that include forward slashes (/) in the 
 * filename. Allen Bradley bit level addresses, S:5/0 for example, include a forward slash (/) to delimit
 * the word address from the bit position.  Unfortunately, the .NET and Win32 FTP methods interpret 
 * forward slashes (/) to delimit paths, and, when a filename includes a forward slash (/) the methods
 * assume the filename to be a relative file specification, i.e. include a path under the FTP URL and
 * default path.  For example, the file ftp://192.168.0.240/s_5/0.txt is considered by .NET and Win23 
 * to be the file 0.txt at URL ftp://192.168.0.240/s_5/ rather than file s_5/0.txt at ftp://192.168.0.240/, 
 * which is the case with Allen Bradly addresses in WebPort.  Somehow there is a way to include a forward 
 * slash in the  file name or use method that only accept an absolute path as the filename as there are 
 * many FTP clients that handle this situation.
 */

namespace Ecolab.Dcs.WebPortReader
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Text;

    /// <summary>
    ///     Provides a class for reading instantaneous tag values from a WebPort device.
    /// </summary>
    public class InstantaneousReader : Reader
    {
        #region Read

        /// <summary>
        ///     Reads the WebPort instantaneous values file.
        /// </summary>
        public override void Read(DateTime webportdatetime, List<string> lastDownloadFileList)
        {
            try
            {
                // Inform subscribers the read has started.
                OnStarted();

                // Initialize
                m_Cancel = false;
                ServicePointManager.DefaultConnectionLimit = m_ConnectionLimit;

                // Assemble a Uri for file.
                const string filename = "inst_val.txt";
                string ftpPath = m_Uri + System.Uri.EscapeDataString(filename);
                string filePath = NormalizeWebPortFileName(filename);

                // Downloads the file's data from WebPort
                OnStatusMessage("Downloading: " + ftpPath);
                byte[] data = DownloadData(ftpPath);

                // Aborts if canceled.
                if (m_Cancel)
                {
                    OnStatusMessage("Read canceled");
                    OnCanceled();
                    return;
                }

                // Lets the subscriber know communication is okay.
                OnCommunication();

                // Current time is the timestamp.
                DateTime timestamp = DateTime.Now;

                /*
                 * "TagId";"TagName";"Value";"AlStatus";"AlType";"Quality"
                 * 1;"N7:0";0;0;0;24
                 * 2;"N7:1";0;0;0;24
                 * 3;"N7:2";0;0;0;24
                 * 4;"N10:120";0;0;0;0
                 * 5;"N10:121";0;0;0;0
                 * 6;"N7:150";0;0;0;0
                 * 7;"N7:10";0;0;0;24
                 * 8;"N7:20";0;0;0;0
                 * 9;"N7:30";0;0;0;0
                 * 10;"N7:40";0;0;0;0
                 */

                OnStatusMessage("Reading: " + filePath);
                string contents = Encoding.UTF8.GetString(data);
                int startIndex = 0;
                int endIndex = contents.IndexOf("\r\n", startIndex);
                int length = endIndex - startIndex;
                string line = contents.Substring(startIndex, length);
                startIndex = endIndex + 2;
                while (startIndex < contents.Length)
                {
                    // Aborts if canceled.
                    if (m_Cancel)
                    {
                        OnStatusMessage("Read canceled");
                        OnCanceled();
                        return;
                    }

                    endIndex = contents.IndexOf("\r\n", startIndex);
                    length = endIndex - startIndex;
                    line = contents.Substring(startIndex, length);
                    startIndex = endIndex + 2;

#pragma warning disable 219
                    const int fieldsNumTagId = 0;
                    const int fieldsNumTagName = 1;
                    const int fieldsNumValue = 2;
                    const int fieldsNumAlStatus = 3;
                    const int fieldsNumAlType = 4;
                    const int fieldsNumQuality = 5;
                    const int fieldsNumMin = fieldsNumTagId;
                    const int fieldsNumMax = fieldsNumQuality;
                    const int fieldsNumLength = fieldsNumMax - fieldsNumMin + 1;
#pragma warning restore 219

                    // WebPort PLC tag file formate is as a semicolon (;) separated file.
                    char[] separator = { ';' };
                    string[] fields = line.Split(separator);

                    string name = fields[fieldsNumTagName].Replace("\"", string.Empty);
                    string value = fields[fieldsNumValue];

                    // Adds new tags or tags with changed values.
                    m_Tags.AddOrUpdate(name, tag =>
                    {
                        OnTagValue(name, timestamp, value); // Ignores return value from OnTagValue
                        return new TagValue(timestamp, value);
                    }, (tag, tagValue) =>
                    {
                        if (value != tagValue.Value)
                        {
                            tagValue.Timestamp = timestamp;
                            tagValue.Value = value;
                            OnTagValue(name, timestamp, value); // Ignores return value from OnTagValue
                        }
                        return tagValue;
                    });
                }

                // End of read
                if (m_Cancel)
                {
                    OnStatusMessage("Read canceled");
                    OnCanceled();
                }
                else
                {
                    OnStatusMessage("Completed");
                    OnCompletion();
                }
            }
            catch (Exception ex)
            {
                if (m_Cancel)
                {
                    OnStatusMessage("Read canceled");
                    OnCanceled();
                }
                else
                {
                    OnException(ex);
                }
            }
        }

        #endregion Read

        #region Cancel

        /// <summary>
        ///     The cancel flag.
        /// </summary>
        private bool m_Cancel;

        /// <summary>
        ///     Cancels a WebPort read in progress.
        /// </summary>
        public override void Cancel()
        {
            m_Cancel = true;
        }

        #endregion Cancel
    }
}