﻿// -----------------------------------------------------------------------
// <copyright file="CustomWebClient.cs" company="Ecolab">
//  ©2014 Ecolab All rights reserved.
// </copyright>
// <summary>The Custom Web Client</summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Ecolab.Dcs.WebPortReader
{
	class CustomWebClient : WebClient
	{
		protected override WebRequest GetWebRequest(Uri uri)
		{
			WebRequest webRequest = base.GetWebRequest(uri);
			if (webRequest != null)
			{
				webRequest.Timeout = 20 * 60 * 1000;
				return webRequest;
			}
			return null;
		}
	}
}
