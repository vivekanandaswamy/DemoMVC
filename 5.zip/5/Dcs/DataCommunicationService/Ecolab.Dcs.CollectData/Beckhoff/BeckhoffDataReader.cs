﻿// -----------------------------------------------------------------------
// <copyright file="BeckhoffDataReader.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The BeckhoffDataReader </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Dcs.CollectData.Beckhoff
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using Access.DataReader;
    using Entities;
    using log4net;
    using TwinCAT.Ads;
    public class BeckhoffDataReader : DataReader<BeckhoffTag>
    {
        #region Variables
        private const string FormatString = ".{0}";
        public delegate void BeckhoffValueChanged(IList<BeckhoffTag> beckhoffTags, object valData);
        private static readonly ILog Log = LogManager.GetLogger(typeof(BeckhoffDataReader));
        private readonly string RslinxItemFormat = ".{0}";
        private AdsStream activeStream;
        private TcAdsClient adsClient;
        private TcAdsSymbolInfoLoader symbolLoader;
        private static int WasherId;
        private string AmsNetAddress;
        private int Port;
        private int ControllerId;
        private bool IsReaderConnected;
        #endregion

        #region Properties
        public bool IsConnected
        {
            get
            {
                return IsReaderConnected;
            }
        }
        #endregion

        #region Methods
        public BeckhoffDataReader(BeckhoffController controller, string beckhoffItemFormat, string amsNetAddress, int port)
            : base(controller)
        {
            RslinxItemFormat = beckhoffItemFormat;
            AmsNetAddress = amsNetAddress;
            Port = port;
            ControllerId = controller.ControllerId;
        }

        public string MRslinxItemFormat
        {
            get { return RslinxItemFormat; }
        }

        public bool ConnectToPlc(string beckhoffIpAddr, int beckhoffPort)
        {
            try
            {
                adsClient = new TcAdsClient();

                if (beckhoffIpAddr.Trim().Length > 0 && beckhoffPort > 0)
                {
                    adsClient.Connect(beckhoffIpAddr, beckhoffPort);
                    symbolLoader = adsClient.CreateSymbolInfoLoader();
                    bool deviceState = (adsClient.RouterState == AmsRouterState.Start) && (adsClient.ReadState().DeviceState == 0);
                    if (deviceState)
                    {
                        DataReaderAccess.UpdateControllerConnectivityAlarm(ControllerId, false, 9001);
                    IsReaderConnected = true;
                }
                    return deviceState;
                }

                return true;
            }
            catch (Exception ex)
            {
                DataReaderAccess.UpdateControllerConnectivityAlarm(ControllerId, true, 9001);
                IsReaderConnected = false;
                Log.Error(ex.Message);
                return false;
            }
        }

        public override IList<BeckhoffTag> ValidateTags(IList<BeckhoffTag> tags)
        {
            try
            {
                if (adsClient == null || adsClient.Disposed)
                {
                    ConnectToPlc(AmsNetAddress, Port);
                }

                if (adsClient != null)
                {
                    foreach (BeckhoffTag tag in tags)
                    {
                        TcAdsSymbolInfo sym = symbolLoader.FindSymbol(String.Format(FormatString, tag.Address));
                        tag.IsValid = sym != null;
                        if (tag.IsValid)
                        {
                            int varHandle = adsClient.CreateVariableHandle(String.Format(FormatString, tag.Address));
                            ReadTagfromPLC(varHandle, tag);

                            adsClient.DeleteVariableHandle(varHandle);
                            DataReaderAccess.UpdateControllerConnectivityAlarm(ControllerId, false, 9001);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                IsReaderConnected = false;
                Log.Error(ex.Message);
                DataReaderAccess.UpdateControllerConnectivityAlarm(ControllerId, true, 9001);
                throw new Exception(ex.Message);
            }
            return tags;
        }

        public IList<BeckhoffTag> ValidateMyControlTags(IList<BeckhoffTag> readTags)
        {
            try
            {
                if (adsClient == null)
                {
                    ConnectToPlc(AmsNetAddress, Port);
                }

                if (adsClient != null && ((adsClient.RouterState == AmsRouterState.Start) && (adsClient.ReadState().DeviceState == 0)))
                {
                    foreach (BeckhoffTag tags in readTags)
                    {
                        TcAdsSymbolInfo sym = symbolLoader.FindSymbol(tags.Address);
                        tags.IsValid = sym != null;
                        if (tags.IsValid)
                        {
                            int varHandle = adsClient.CreateVariableHandle(tags.Address);
                            ReadTagfromPLC(varHandle, tags);
                            adsClient.DeleteVariableHandle(varHandle);
                        }
                    }
                }
                else
                {
                    throw new Exception("Port is disabled");
                }
            }
            catch (Exception ex)
            {
                IsReaderConnected = false;
                Log.Error(ex.Message);
                throw new Exception(ex.Message);
            }
            return readTags;
        }
        private void ReadTagfromPLC(int tagHandle, BeckhoffTag beckhofftag)
        {
            string quality = "Good";
            if (beckhofftag.TagItemType == UIInputType.TypeXml)
            {
                AdsStream dataStream = new AdsStream(beckhofftag.SizetoRead);
                BinaryReader binRead = new BinaryReader(dataStream);

                //Array komplett auslesen			
                adsClient.Read(tagHandle, dataStream);

                var bytes = new byte[beckhofftag.SizetoRead];
                dataStream.Position = 0;
                for (int j = 0; j < beckhofftag.SizetoRead; j++)
                {
                    bytes[j] = binRead.ReadByte();
                }
                string xml = Encoding.UTF8.GetString(bytes);
                beckhofftag.Value = xml;
                beckhofftag.Quality = quality;
            }
            else if (beckhofftag.TagItemType == UIInputType.TypeInt)
            {
                beckhofftag.Value = adsClient.ReadAny(tagHandle, typeof(int)).ToString();
                beckhofftag.Quality = quality;
            }
            else if (beckhofftag.TagItemType == UIInputType.TypeUInt16)
            {
                beckhofftag.Value = adsClient.ReadAny(tagHandle, typeof(UInt16)).ToString();
                beckhofftag.Quality = quality;
            }
            else if (beckhofftag.TagItemType == UIInputType.TypeBool)
            {
                beckhofftag.Value = adsClient.ReadAny(tagHandle, typeof(bool)).ToString().ToLower(CultureInfo.InvariantCulture);
                beckhofftag.Quality = quality;
            }
            else if (beckhofftag.TagItemType == UIInputType.TypeString)
            {
                beckhofftag.Value = adsClient.ReadAny(tagHandle, typeof(string), new int[] { 80 }).ToString();
                beckhofftag.Quality = quality;
            }
            else if (beckhofftag.TagItemType == UIInputType.TypeFloat)
            {
                beckhofftag.Value = adsClient.ReadAny(tagHandle, typeof(float)).ToString();
                beckhofftag.Quality = quality;
            }
            else if (beckhofftag.TagItemType == UIInputType.TypeArray)
            {
                // AdsStream which gets the data
                AdsStream dataStream = new AdsStream(beckhofftag.SizetoRead);
                BinaryReader binRead = new BinaryReader(dataStream);

                //read comlpete Array 
                adsClient.Read(tagHandle, dataStream);
                dataStream.Position = 0;
                for (int i = 0; i < beckhofftag.SizetoRead / 2; i++)
                {
                    beckhofftag.BatchData[i] = (ushort)binRead.ReadInt16();

                }
                beckhofftag.Quality = quality;
            }
            else if (beckhofftag.TagItemType == UIInputType.TypeU32Array)
            {
                // AdsStream which gets the data
                AdsStream dataStream = new AdsStream(beckhofftag.SizetoRead);
                BinaryReader binRead = new BinaryReader(dataStream);
                //read comlpete Array 
                adsClient.Read(tagHandle, dataStream);
                dataStream.Position = 0;
                for (int i = 0; i < 128; i++)
                {
                    beckhofftag.WAndEData[i] = binRead.ReadUInt32();
                }
                beckhofftag.Quality = quality;
            }
            else if (beckhofftag.TagItemType == UIInputType.TypeArrayBoolean)
            {
                // AdsStream which gets the data
                AdsStream dataStream = new AdsStream(beckhofftag.SizetoRead);
                BinaryReader binRead = new BinaryReader(dataStream);
                adsClient.Read(tagHandle, dataStream);
                dataStream.Position = 0;
                for (int i = 0; i < beckhofftag.SizetoRead / 2; i++)
                {
                    beckhofftag.arrayDataBoolean[i] = binRead.ReadBoolean();
                }
                beckhofftag.Quality = quality;
            }
            else if (beckhofftag.TagItemType == UIInputType.TypeObject)
            {

                Type type = Type.GetType(beckhofftag.ComplexObjectType);

                beckhofftag.ComplexObject = adsClient.ReadAny(tagHandle, type);
                beckhofftag.Quality = quality;
            }
        }

        public bool ReadTagsContinuously(IList<BeckhoffTag> tagNames, BeckhoffValueChanged invoker, object persistData)
        {
            try
            {
                activeStream = new AdsStream(tagNames.Count + 5);
                string tagAddress;

                tagNames = ValidateTags(tagNames).Where(tl => tl.IsValid).ToList();
                for (int i = 0; i < tagNames.Count; i++)
                {
                    if (tagNames[i].Address.Contains(".")) tagAddress = tagNames[i].Address;
                    else tagAddress = String.Format(FormatString, tagNames[i].Address);

                    int varHandle = adsClient.CreateVariableHandle(tagAddress);
                    object data = adsClient.ReadAny(varHandle, typeof(int));
                    BeckhoffTag tag = tagNames[i];
                    tag.Value = data.ToString();
                    tag.NotificationHandle = adsClient.AddDeviceNotification(tagAddress, activeStream, i, i + 1, AdsTransMode.OnChange, 0, 0, true);
                }
                adsClient.AdsNotification += (sender, e) => adsClient_AdsNotification(sender, e, persistData, tagNames, invoker);
                return true;
            }
            catch (Exception ex)
            {
                IsReaderConnected = false;
                Log.Error(ex.Message);
                throw new Exception(ex.Message);
            }
            }

        private void adsClient_AdsNotification(object sender, AdsNotificationEventArgs e, object clientData, IList<BeckhoffTag> tagVaues, BeckhoffValueChanged serverValueChanged)
        {
            bool isNowTag = false;
            string nowTag = string.Empty;
            foreach (var isNowTags in tagVaues)
            {
                if (isNowTags.Address.Contains("_NVLV") || isNowTags.Address.Contains("_LVL"))
                {
                    isNowTag = true;
                    nowTag = isNowTags.Address;
                }
            }

            try
            {
                if (adsClient == null)
                {
                    ConnectToPlc(((TcAdsClient)sender).ClientNetID, ((TcAdsClient)sender).ServerPort);
                }
                if (adsClient != null && ((adsClient.RouterState == AmsRouterState.Start) && (adsClient.ReadState().DeviceState == 0)))
                {
                    BeckhoffTag tagVal = tagVaues.FirstOrDefault(at => at.NotificationHandle == e.NotificationHandle);

                    if (tagVal != null)
                    {
                        TcAdsSymbolInfo sym = symbolLoader.FindSymbol(String.Format(FormatString, tagVal.Address));
                        if (tagVal.IsValid)
                        {
                            tagVal.IsValid = sym != null;
                            if (!isNowTag)
                            {
                                Washer washer = (Washer)clientData;
                                WasherId = washer.WasherId;
                                if (!washer.IsTunnel)
                                {
                                    string washerFrmTag = string.Empty;
                                    string washerOpcTag = string.Empty;
                                    string washerInjTag = string.Empty;
                                    if (WasherId > 0)
                                    {
                                        var washerDetailList = DataReaderAccess.GetWasherDetailsById(WasherId);
                                        foreach (var wash in washerDetailList)
                                        {
                                            if (wash.TagType.Contains("_OPC"))
                                            {
                                                washerOpcTag = wash.TagType;
                                            }
                                            else if (wash.TagType.Contains("_INJ"))
                                            {
                                                washerInjTag = wash.TagType;
                                            }
                                            else if (wash.TagType.Contains("_FRM"))
                                            {
                                                washerFrmTag = wash.TagType;
                                            }
                                        }
                                    }

                                    int varHandle = adsClient.CreateVariableHandle(String.Format(FormatString, tagVal.Address));
                                    AdsStream adsStream = new AdsStream(tagVal.SizetoRead);
                                    adsClient.Read(varHandle, adsStream);
                                    tagVal.Value = adsClient.ReadAny(varHandle, typeof(int)).ToString();

                                    DateTime dt = new DateTime(1601, 01, 01).AddTicks(e.TimeStamp);
                                    tagVal.TimeStamp = dt;
                                    if (tagVal.Address == washerInjTag || tagVal.Address == washerFrmTag)
                                    {
                                        foreach (var washerCount in tagVaues)
                                            {
                                            washerCount.IsModified = true;
                                        }
                                        serverValueChanged(tagVaues, clientData);
                                    }
                                    //Remove the handle 
                                    adsClient.DeleteVariableHandle(varHandle);
                                }
                            }
                            else
                            {
                                int varHandle = adsClient.CreateVariableHandle(String.Format(FormatString, tagVal.Address));
                                AdsStream adsStream = new AdsStream(tagVal.SizetoRead);
                                adsClient.Read(varHandle, adsStream);
                                tagVal.Value = adsClient.ReadAny(varHandle, typeof(int)).ToString();
                                DateTime dt = new DateTime(1601, 01, 01).AddTicks(e.TimeStamp);
                                tagVal.TimeStamp = dt;
                                if (tagVal.Address == nowTag)
                                {
                                    serverValueChanged(tagVaues, clientData);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                IsReaderConnected = false;
                Log.Error(ex.Message);
            }
        }
        public override BeckhoffTag ValidateTag(BeckhoffTag tag)
        {
            var tags = new List<BeckhoffTag> { tag };
            return ValidateTags(tags).First();
        }

        public override BeckhoffTag ReadTag(BeckhoffTag tag)
        {
            var tags = new List<BeckhoffTag> { tag };
            return ReadTags(tags).First();
        }

        public override IList<BeckhoffTag> ReadTags(IList<BeckhoffTag> tagNames)
        {
            string tagAddress;
            try
            {
                tagNames = ValidateTags(tagNames).Where(tl => tl.IsValid).ToList();

                foreach (BeckhoffTag tags in tagNames)
                {
                    if (tags.Address.Contains(".")) tagAddress = tags.Address;
                    else tagAddress = String.Format(FormatString, tags.Address);
                    int varHandle = adsClient.CreateVariableHandle(tagAddress);
                    ReadTagfromPLC(varHandle, tags);
                    //Remove the handle 
                    adsClient.DeleteVariableHandle(varHandle);
                    DataReaderAccess.UpdateControllerConnectivityAlarm(ControllerId, false, 9001);
                }
                return tagNames;
            }
            catch (AdsException ex)
            {
                IsReaderConnected = false;
                Log.Error(ex.Message);
                DataReaderAccess.UpdateControllerConnectivityAlarm(ControllerId, true, 9001);
                throw ex;
            }
        }

        public IList<BeckhoffTag> ReadMyControlTags(IList<BeckhoffTag> tagNames)
        {
            try
            {
                tagNames = ValidateMyControlTags(tagNames).Where(tl => tl.IsValid).ToList();
                foreach (BeckhoffTag tags in tagNames)
                {
                    int varHandle = adsClient.CreateVariableHandle(tags.Address);
                    ReadTagfromPLC(varHandle, tags);
                    adsClient.DeleteVariableHandle(varHandle);
                }
                return tagNames;
            }
            catch (AdsException ex)
            {
                IsReaderConnected = false;
                Log.Error(ex.Message);
                DataReaderAccess.UpdateControllerConnectivityAlarm(ControllerId, true, 9001);
                throw ex;
            }
        }
        public override BeckhoffTag ReadTagExt(BeckhoffTag tag)
            {
            throw new NotImplementedException();
            }
        public override IList<BeckhoffTag> ReadTagsExt(IList<BeckhoffTag> tagNames)
        {
            throw new NotImplementedException();
        }

        public bool StopPlcRead()
        {
            if (adsClient != null)
            {
                adsClient.Dispose();
                return true;
            }
            return false;
        }

        public override object ReadArrayTags()
        {
            ComplexStruct result = new ComplexStruct();
            try
            {
                if (adsClient == null)
                {
                    ConnectToPlc(AmsNetAddress, Port);
                }

                if (adsClient != null && ((adsClient.RouterState == AmsRouterState.Start) && (adsClient.ReadState().DeviceState == 0)))
                {
                    int hcomplexStruct = adsClient.CreateVariableHandle("MAIN.complexStruct1");
                    result = (ComplexStruct)adsClient.ReadAny(hcomplexStruct, typeof(ComplexStruct));

                    adsClient.DeleteVariableHandle(hcomplexStruct);
                }
            }
            catch (Exception ex)
            {
                IsReaderConnected = false;
                Log.Error(ex.Message);
                return null;
            }
            return result;
        }
        public override int ReadArrayPos(int pos)
        {
            int result = 0;
            try
            {
                if (adsClient == null || adsClient.Disposed)
                {
                    ConnectToPlc(AmsNetAddress, Port);
                }

                if (adsClient != null)
                {
                    int hcomplexStruct = adsClient.CreateVariableHandle("MAIN.complexStruct1.dintArr[" + pos + "]");
                    result = (int)adsClient.ReadAny(hcomplexStruct, typeof(int));

                    adsClient.DeleteVariableHandle(hcomplexStruct);
                }
            }
            catch (AdsException ex)
            {
                IsReaderConnected = false;
                Log.Error(ex.Message);
                return 0;
            }
            return result;
        }

        ~BeckhoffDataReader()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            try
            {
                if (adsClient != null)
                {
                    adsClient.Dispose();

                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
            }

        }
        #endregion
    }
}