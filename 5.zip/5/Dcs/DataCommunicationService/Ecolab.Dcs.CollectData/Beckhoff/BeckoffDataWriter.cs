﻿// -----------------------------------------------------------------------
// <copyright file="BeckoffDataWriter.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The BeckoffDataWriter </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Dcs.CollectData.Beckhoff
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Entities;
    using TwinCAT.Ads;
    using Access.DataReader;

    /// <summary>
    /// Class for BeckoffDataWriter
    /// </summary>
    /// <seealso cref="Ecolab.Dcs.CollectData.DataWriter{Ecolab.Dcs.Entities.BeckhoffTag}" />
    public class BeckoffDataWriter : DataWriter<BeckhoffTag>
    {
        #region Variables
        private const string FormatString = ".{0}";
        private readonly string RslinxItemFormat = ".{0}";
        private TcAdsClient adsClient;
        private string AmsNetAddress;
        private int Port;
        private int ControllerId;
        private bool IsWriterConnected;
        #endregion

        #region Properties
        /// <summary>
        /// Gets a value indicating whether this instance is connected.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is connected; otherwise, <c>false</c>.
        /// </value>
        public bool IsConnected
        {
            get
            {
                return IsWriterConnected;
            }
        }
        #endregion

        #region Methods
        /// <summary>
        /// Initializes a new instance of the <see cref="BeckoffDataWriter"/> class.
        /// </summary>
        /// <param name="controller">The controller.</param>
        /// <param name="beckhoffItemFormat">The beckhoff item format.</param>
        /// <param name="amsNetAddress">The ams net address.</param>
        /// <param name="port">The port value.</param>
        public BeckoffDataWriter(BeckhoffController controller, string beckhoffItemFormat, string amsNetAddress, int port)
            : base(controller)
        {
            RslinxItemFormat = beckhoffItemFormat;
            AmsNetAddress = amsNetAddress;
            Port = port;
            ControllerId = controller.ControllerId;
        }

        /// <summary>
        /// Gets the m rslinx item format.
        /// </summary>
        /// <value>
        /// The m rslinx item format.
        /// </value>
        public string MRslinxItemFormat
        {
            get { return RslinxItemFormat; }
        }

        /// <summary>
        /// Writes the tags.
        /// </summary>
        /// <param name="writeTags">The write tags.</param>
        /// <returns>List of beckhofftags</returns>
        public override IList<BeckhoffTag> WriteTags(IList<BeckhoffTag> writeTags)
        {
            try
            {
                string tagAddress;
                if (adsClient == null || adsClient.Disposed)
                {
                    ConnectToPlc(AmsNetAddress, Port);
                }

                foreach (BeckhoffTag tags in writeTags)
                {
                    if (adsClient != null)
                    {
                        if (!string.IsNullOrWhiteSpace(tags.Value) && !string.IsNullOrEmpty(tags.Address))
                        {
                                tagAddress = String.Format(FormatString, tags.Address);
                            
                            int varHandle = adsClient.CreateVariableHandle(tagAddress);
                            
                            tags.indexGroup = (int)AdsReservedIndexGroups.SymbolValueByHandle;
                            tags.indexOffset = varHandle;

                            WriteTagtoPLC(varHandle, tags);

                            adsClient.DeleteVariableHandle(varHandle);
                            DataReaderAccess.UpdateControllerConnectivityAlarm(ControllerId, false, 9001);
                        }
                    }
                }
                return writeTags;
            }
            catch (Exception ex)
            {
                IsWriterConnected = false;
                DataReaderAccess.UpdateControllerConnectivityAlarm(ControllerId, true, 9001);
                throw ex;
            }

            }

        /// <summary>
        /// Writes my control tags.
        /// </summary>
        /// <param name="writeTags">The write tags.</param>
        /// <returns>List of BeckhoffTags</returns>
        public IList<BeckhoffTag> WriteMyControlTags(IList<BeckhoffTag> writeTags)
        {
            try
            {
                string tagAddress;
                if (adsClient == null || adsClient.Disposed)
                {
                    ConnectToPlc(AmsNetAddress, Port);
                }

                foreach (BeckhoffTag tags in writeTags)
                {
                    if (adsClient != null)
                    {
                        tagAddress = tags.Address;
                            int varHandle = adsClient.CreateVariableHandle(tagAddress);
                            tags.indexGroup = (int)AdsReservedIndexGroups.SymbolValueByHandle;
                            tags.indexOffset = varHandle;
                            WriteTagtoPLC(varHandle, tags);
                            adsClient.DeleteVariableHandle(varHandle);
                    }
                }
                return writeTags;
            }
            catch (Exception ex)
            {
                IsWriterConnected = false;
                DataReaderAccess.UpdateControllerConnectivityAlarm(ControllerId, true, 9001);
                throw ex;
            }

            }

        /// <summary>
        /// Writes the tagto PLC.
        /// </summary>
        /// <param name="varHandle">The variable handle.</param>
        /// <param name="tags">The tags values for plc.</param>
        private void WriteTagtoPLC(int varHandle, BeckhoffTag tags)
        {
            try
            {
                if (tags.Address == "L_HSTREQ")
                {
                    AdsStream adsDateStream = new AdsStream(tags.SizetoRead);
                    AdsBinaryWriter dateWriter = new AdsBinaryWriter(adsDateStream);
                    dateWriter.WritePlcString(tags.Value, tags.SizetoRead);
                    adsClient.Write(varHandle, adsDateStream);
                }
                else
                {
                    if (tags.TagItemType == UIInputType.TypeInt)
                    {
                        adsClient.WriteAny(varHandle, GetValue(tags.Value));
                        tags.Value = adsClient.ReadAny(varHandle, typeof(int)).ToString();
                    }
                    else if (tags.TagItemType == UIInputType.TypeUInt16)
                    {
                        adsClient.WriteAny(varHandle, (UInt16)GetValue(tags.Value));
                        tags.Value = adsClient.ReadAny(varHandle, typeof(UInt16)).ToString();
                    }
                    else if (tags.TagItemType == UIInputType.TypeString)
                    {
                        adsClient.WriteAny(varHandle, GetValue(tags.Value), new int[] { tags.SizetoRead });
                        tags.Value = adsClient.ReadAny(varHandle, typeof(string), new int[] { tags.SizetoRead }).ToString();
                    }
                    else if (tags.TagItemType == UIInputType.TypeBool)
                    {
                        adsClient.WriteAny(varHandle, bool.Parse(tags.Value));
                        tags.Value = adsClient.ReadAny(varHandle, typeof(bool)).ToString();
                    }
                    else if (tags.TagItemType == UIInputType.TypeFloat)
                    {
                        adsClient.WriteAny(varHandle, float.Parse(tags.Value));
                        tags.Value = adsClient.ReadAny(varHandle, typeof(float)).ToString();
                    }
                    else if (tags.TagItemType == UIInputType.TypeArray)
                    {
                        AdsStream dataStream = new AdsStream();
                        byte[] byteArray = new byte[tags.BatchData.Count * 2];
                        Buffer.BlockCopy(tags.BatchData.ToArray(), 0, byteArray, 0, tags.BatchData.Count * 2);
                        dataStream.Write(byteArray, 0, byteArray.Length);
                        adsClient.Write(varHandle,dataStream);
                    }
                }
                if (tags.TagItemType == UIInputType.TypeObject)
                {

                    adsClient.WriteAny(varHandle, tags.ComplexObject);
                }
            }
            catch (Exception ex)
            {
                IsWriterConnected = false;
                throw ex;
            }
        }

        /// <summary>
        /// Writes the tag.
        /// </summary>
        /// <param name="tag">The tag values for plc.</param>
        /// <returns>The BeckhoffTag</returns>
        public override BeckhoffTag WriteTag(BeckhoffTag tag)
        {
            var tags = new List<BeckhoffTag> { tag };
            return WriteTags(tags).First();
        }
        /// <summary>
        /// Writes the tags ext.
        /// </summary>
        /// <param name="tags">The tags for plc.</param>
        /// <returns>List of BeckhoffTags</returns>
        /// <exception cref="System.NotImplementedException"></exception>
        public override IList<BeckhoffTag> WriteTagsExt(IList<BeckhoffTag> tags)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// Writes the tag ext.
        /// </summary>
        /// <param name="tag">The tag for plc.</param>
        /// <returns>The BeckhoffTags</returns>
        /// <exception cref="System.NotImplementedException"></exception>
        public override BeckhoffTag WriteTagExt(BeckhoffTag tag)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// Connects to PLC.
        /// </summary>
        /// <param name="beckhoffIpAddr">The beckhoff ip addr.</param>
        /// <param name="beckhoffPort">The beckhoff port.</param>
        /// <returns>Returns the boolean value</returns>
        public bool ConnectToPlc(string beckhoffIpAddr, int beckhoffPort)
        {
            try
            {
                adsClient = new TcAdsClient();

                if (beckhoffIpAddr.Trim().Length > 0 && beckhoffPort > 0)
                {
                    adsClient.Connect(beckhoffIpAddr, beckhoffPort);
                    adsClient.CreateSymbolInfoLoader();
                    int devicestate = adsClient.ReadState().DeviceState;
                    bool boolDeviceState = (adsClient.RouterState == AmsRouterState.Start) && (devicestate == 0);
                    if (boolDeviceState)
                    {
                        DataReaderAccess.UpdateControllerConnectivityAlarm(ControllerId, false, 9001);
                    IsWriterConnected = true;
                    }
                    return boolDeviceState;
                }

                return true;
            }
            catch (Exception)
            {
                IsWriterConnected = false;
                DataReaderAccess.UpdateControllerConnectivityAlarm(ControllerId, true, 9001);
                return false;
            }
        }

        /// <summary>
        /// Gets the value.
        /// </summary>
        /// <param name="value">The value for plc.</param>
        /// <returns>Returns the dynamic values</returns>
        private static dynamic GetValue(dynamic value)
        {
            short shortValue;
            bool boolValue;
            int intValue;
            DateTime datetimeValue;
            int decimalValue;
            decimal decimalVal;

            if (short.TryParse(value, out shortValue))
            {
                return shortValue;
            }
            if (bool.TryParse(value, out boolValue))
            {
                return boolValue;
            }
            if (int.TryParse(value, out intValue))
            {
                return intValue;
            }
            if (int.TryParse(value, out decimalValue))
            {
                return Convert.ToInt32(decimalValue);
            }
            if (decimal.TryParse(value, out decimalVal))
            {
                return Convert.ToInt32(decimalValue);
            }
            if (DateTime.TryParse(value, out datetimeValue))
            {
                return datetimeValue;
            }
            return value;
        }

        /// <summary>
        /// Writes the array tags.
        /// </summary>
        /// <param name="tagStruct">The tag structure.</param>
        /// <returns>Returns the ComplexStruct</returns>
        public override ComplexStruct WriteArrayTags(ComplexStruct tagStruct)
        {
            try
            {
                if (adsClient == null || adsClient.Disposed)
                {
                    ConnectToPlc(AmsNetAddress, Port);
                }

                if (adsClient != null)
                {
                    int hcomplexStruct = adsClient.CreateVariableHandle("MAIN.complexStruct1");

                    try
                    {
                        adsClient.WriteAny(hcomplexStruct, tagStruct);
                    }
                    catch (Exception)
                    {
                    }

                    adsClient.DeleteVariableHandle(hcomplexStruct);
                }

                return tagStruct;
            }
            catch (Exception ex)
            {
                IsWriterConnected = false;
                throw ex;
            }
        }

        /// <summary>
        /// Writes the array position.
        /// </summary>
        /// <param name="tagPos">The tag position.</param>
        /// <param name="tagVal">The tag value.</param>
        /// <returns>Returns the integer value</returns>
        public override int WriteArrayPos(int tagPos, int tagVal)
        {
            try
            {
                if (adsClient == null || adsClient.Disposed)
                {
                    ConnectToPlc(AmsNetAddress, Port);
                }

                if (adsClient != null)
                {
                    int hdint1 = adsClient.CreateVariableHandle("MAIN.complexStruct1.dintArr[" + tagPos + "]");

                    try
                    {
                        adsClient.WriteAny(hdint1, tagVal);
                    }
                    catch (Exception)
                    {
                    }
                    adsClient.DeleteVariableHandle(hdint1);
                }

                return tagVal;
            }
            catch (Exception ex)
            {
                IsWriterConnected = false;
                throw ex;
            }
        }

        /// <summary>
        /// Stops the PLC write.
        /// </summary>
        /// <returns>Returns the boolean value</returns>
        public bool StopPlcWrite()
        {
            if (adsClient != null)
            {
                adsClient.Dispose();
                return true;
            }
            return false;
        }

        /// <summary>
        /// Finalizes an instance of the <see cref="BeckoffDataWriter"/> class.
        /// </summary>
        ~BeckoffDataWriter()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            try
            {
                if (adsClient != null)
                {
                    adsClient.Dispose();

                }
            }
            catch (Exception ex)
            { }
        }
        #endregion
    }
}