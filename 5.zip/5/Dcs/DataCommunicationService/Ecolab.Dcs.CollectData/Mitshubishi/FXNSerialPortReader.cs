﻿// -----------------------------------------------------------------------
// <copyright file="FXSerialPortReader.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The FXSerialPortReader </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using Access.DataReader;
using ACTETHERLib;
using Ecolab.Dcs.Entities;
using Entities;
using log4net;

namespace Ecolab.Dcs.CollectData.Mitsubishi
{
    public class FXSerialPortReader : DataReader<MitsubishiTag>, IDisposable
    {
        private ACTPCCOMLibCtl.ActFXCPU ComFXCPU;
        private bool isPLCConnected;
        private static readonly ILog Log = LogManager.GetLogger(typeof(A1SHEthernetReader));
        public FXSerialPortReader(MitsubishiController controller)
            : base(controller)
        {
            isPLCConnected = false;
        }

        public override MitsubishiTag ValidateTag(MitsubishiTag tag)
        {
            throw new NotImplementedException();
        }
        private void ReadTagfromPLC(MitsubishiTag tag)
        {
            int returnCode;
            int dataValue;
            short plcYear, plcMonth, plcDay, plcDayOfWeek, plcHour;
            short plcMinute, plcSecond;
            int intYear;

            ConnectToPLC();

            if (tag.Address == "DateTime")
            {
                ComFXCPU.GetClockData(out plcYear, out plcMonth, out plcDay, out plcDayOfWeek, out plcHour, out plcMinute, out plcSecond);
                intYear = plcYear + 2000;
                DateTime dateTime = new DateTime(intYear, plcMonth, plcDay, plcHour, plcMinute, plcSecond);
                tag.Value = dateTime.ToString("MM/dd/yyyy HH:mm:ss");
            }
            else if (tag.TagItemType == UIInputType.TypeArray)
            {

                tag.IntArrayData = new int[tag.ArrayLength];
                returnCode = ComFXCPU.ReadDeviceBlock(tag.Address, tag.ArrayLength, out tag.IntArrayData[0]);
                if (returnCode > 0) throw new COMException("Read array Failed", returnCode);

            }
            else if (tag.TagItemType == UIInputType.TypeInt || tag.TagItemType == UIInputType.TypeBool)
            {
                returnCode = ComFXCPU.GetDevice(tag.Address, out dataValue);
                if (returnCode > 0) throw new COMException("Read value Failed", returnCode);
                tag.Value = dataValue.ToString();
            }
            else if (tag.TagItemType == UIInputType.TypeRandomArray)
            {

                tag.IntArrayData = new int[tag.ArrayLength];
                returnCode = ComFXCPU.ReadDeviceRandom(tag.Address, tag.ArrayLength, out tag.IntArrayData[0]);
                if (returnCode > 0) throw new COMException("Read array Failed", returnCode);

            }
        }
        public override MitsubishiTag ReadTag(MitsubishiTag tag)
        {
            IList<MitsubishiTag> tagList = new List<MitsubishiTag>();
            tagList.Add(tag);
            return ReadTags(tagList).First();
        }
        public override MitsubishiTag ReadTagExt(MitsubishiTag tag)
        {
            throw new NotImplementedException();
        }
        public override IList<MitsubishiTag> ReadTagsExt(IList<MitsubishiTag> tagNames)
        {
            throw new NotImplementedException();
        }
        public override IList<MitsubishiTag> ValidateTags(IList<MitsubishiTag> tags)
        {
            ConnectToPLC();
            int value;
            int returnValue;

            if (isPLCConnected == true)
            {
                foreach (MitsubishiTag tag in tags)
                {
                    returnValue = ComFXCPU.GetDevice(tag.Address, out value);
                    if (returnValue > 0)
                        tag.IsValid = false;
                    else
                        tag.IsValid = true;
                }
            }
            else throw new InvalidOperationException("PLC is not Open");
            return tags;
        }

        public override IList<MitsubishiTag> ReadTags(IList<MitsubishiTag> tagNames)
        {
            foreach (MitsubishiTag tag in tagNames)
            {
                ReadTagfromPLC(tag);

            }
            return tagNames;
        }

        public override object ReadArrayTags()
        {
            throw new NotImplementedException();
        }

        public override int ReadArrayPos(int pos)
        {
            throw new NotImplementedException();
        }

        private void ConnectToPLC()
        {
            if (isPLCConnected == false)
            {
                MitsubishiController controller = (MitsubishiController)mController;
                if (controller.PLCType == MitsubishiPLCType.EControl)
                    ComFXCPU = MitsubishiPLCConnect.ConnectFX3USerialPort(controller);
                else
                    ComFXCPU = MitsubishiPLCConnect.ConnectFX2NSerialPort(controller);
                isPLCConnected = true;
            }
        }

        public void Dispose()
        {
            //Dispose(true);
            //GC.SuppressFinalize(this);
        }
    }
}