﻿// -----------------------------------------------------------------------
// <copyright file="FX3UEthernetWriter.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The FX3UEthernetWriter </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using Access.DataReader;
using ACTETHERLib;
using ACTMULTILib;
using Ecolab.Dcs.Entities;
using Entities;
using log4net;

namespace Ecolab.Dcs.CollectData.Mitsubishi
{
    /// <summary>
    /// Class for Ethernet details
    /// </summary>
    /// <seealso cref="Ecolab.Dcs.CollectData.DataWriter{Ecolab.Dcs.Entities.MitsubishiTag}" />
    /// <seealso cref="System.IDisposable" />
    public class FX3UEthernetWriter : DataWriter<MitsubishiTag>, IDisposable
    {
        /// <summary>
        /// The COM fxenettcp
        /// </summary>
        private ACTETHERLib.ActFXENETTCP ComFXENETTCP;
        /// <summary>
        /// The is PLC connected
        /// </summary>
        private bool isPLCConnected;
        /// <summary>
        /// The log value for logger
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger(typeof(FX3UEthernetWriter));
        /// <summary>
        /// Initializes a new instance of the <see cref="FX3UEthernetWriter"/> class.
        /// </summary>
        /// <param name="controller">The controller.</param>
        public FX3UEthernetWriter(MitsubishiController controller)
            : base(controller)
        {
            isPLCConnected = false;
        }

        /// <summary>
        /// Writes the tag.
        /// </summary>
        /// <param name="tag">The tag values for plc.</param>
        /// <returns>Returns MitsubishiTag</returns>
        public override MitsubishiTag WriteTag(MitsubishiTag tag)
        {
            IList<MitsubishiTag> tagList = new List<MitsubishiTag>();
            tagList.Add(tag);
            MitsubishiTag tag1 = WriteTags(tagList).First();
            return tag1;
        }

        /// <summary>
        /// Writes the tags ext.
        /// </summary>
        /// <param name="tags">The tags for plc.</param>
        /// <returns>Returns list of MitsubishiTag</returns>
        public override IList<MitsubishiTag> WriteTagsExt(IList<MitsubishiTag> tags)
        {
            ConnectToPLC();
            try
            {
                foreach (MitsubishiTag tag in tags)
                {
                    WriteTagtoPLC(tag);
                }
            }
            catch
            {
                isPLCConnected = false;
            }
            finally
            {
                ClosePLC();
            }
            return tags;
        }
        /// <summary>
        /// Writes the tag ext.
        /// </summary>
        /// <param name="tag">The tag values for plc.</param>
        /// <returns>Returns MitsubishiTag</returns>
        public override MitsubishiTag WriteTagExt(MitsubishiTag tag)
        {
            IList<MitsubishiTag> tagList = new List<MitsubishiTag>();
            tagList.Add(tag);
            MitsubishiTag tag1 = WriteTagsExt(tagList).First();
            return tag1;
        }
        /// <summary>
        /// Writes the tags.
        /// </summary>
        /// <param name="tags">The tags for plc.</param>
        /// <returns>Returns list of MitsubishiTag</returns>
        /// <exception cref="System.Exception">Unable to Connect</exception>
        public override IList<MitsubishiTag> WriteTags(IList<MitsubishiTag> tags)
        {
            var signals = new List<ManualResetEvent>();
            bool exp = false;
            try
            {
                using (var signal = new ManualResetEvent(false))
                {
                    signals.Add(signal);
                    var thread = new Thread(() =>
                    {
                        try
                        {
                            ConnectRetryonFailure();
                            foreach (MitsubishiTag tag in tags)
                            {
                                try
                                {
                                    WriteTagtoPLC(tag);
                                }
                                catch
                                {
                                    throw;
                                }
                            }
                            signal.Set();
                        }
                        catch
                        {
                            exp = true;
                            signal.Set();
                        }
                        finally
                        {
                            ClosePLC();
                        }
                    });
                    thread.SetApartmentState(ApartmentState.STA);
                    thread.Start();
                    WaitHandle.WaitAll(signals.ToArray());
                }
                if (exp == true) throw new Exception("Unable to Connect to PLC");

                return tags;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// Writes the array tags.
        /// </summary>
        /// <param name="tagStruct">The tag structure.</param>
        /// <returns>Complex Struct</returns>
        /// <exception cref="System.NotImplementedException"></exception>
        public override ComplexStruct WriteArrayTags(ComplexStruct tagStruct)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// Writes the array position.
        /// </summary>
        /// <param name="tagPos">The tag position.</param>
        /// <param name="tagVal">The tag value.</param>
        /// <returns>Returns integer</returns>
        /// <exception cref="System.NotImplementedException"></exception>
        public override int WriteArrayPos(int tagPos, int tagVal)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// Writes the tagto PLC.
        /// </summary>
        /// <param name="tag">The tag Value for PLC.</param>
        /// <exception cref="System.Runtime.InteropServices.COMException">
        /// Write Array Failed
        /// or
        /// Read array Failed
        /// or
        /// Write value failed
        /// </exception>
        private void WriteTagtoPLC(MitsubishiTag tag)
        {
            int returnCode;
            int dataValue;
            DateTime plcDate;
            short plcYear, plcMonth, plcDay, plcHour, plcMinute, plcSecond;
            int intYear;
            if (tag.Address == "DateTime")
            {
                plcDate = DateTime.Now;
                plcYear = (short)(plcDate.Year - 2000);
                plcMonth = (short)plcDate.Month;
                intYear = plcYear + 2000;
                plcDay = (short)plcDate.Day;
                plcHour = (short)plcDate.Hour;
                plcMinute = (short)plcDate.Minute;
                plcSecond = (short)plcDate.Second;
                DateTime dateTime = new DateTime(intYear, plcMonth, plcDay, plcHour, plcMinute, plcSecond);
                tag.Value = dateTime.ToString("MM/dd/yyyy HH:mm:ss");
            }
            else if (tag.TagItemType == UIInputType.TypeArray)
            {

                returnCode = ComFXENETTCP.WriteDeviceBlock(tag.Address, tag.ArrayLength, ref tag.IntArrayData[0]);
                if (returnCode > 0) throw new COMException("Write Array Failed", returnCode);

            }
            else if (tag.TagItemType == UIInputType.TypeRandomArray)
            {
                returnCode = ComFXENETTCP.WriteDeviceRandom(tag.Address, tag.ArrayLength, ref tag.IntArrayData[0]);
                if (returnCode > 0) throw new COMException("Read array Failed", returnCode);

            }
            else if (tag.TagItemType == UIInputType.TypeInt || tag.TagItemType == UIInputType.TypeBool)
            {
                dataValue = Convert.ToInt32(tag.Value);
                returnCode = ComFXENETTCP.SetDevice(tag.Address, dataValue);
                if (returnCode > 0) throw new COMException("Write value failed", returnCode);
                tag.Value = dataValue.ToString();
            }
        }
        /// <summary>
        /// Closes the PLC.
        /// </summary>
        public void ClosePLC()
        {
            try
            {
                if (isPLCConnected == true)
                {
                    MitsubishiController controller = (MitsubishiController)mController;
                    MitsubishiPLCConnect.CloseFX3UEthernet(controller);
                    isPLCConnected = false;
                    DataReaderAccess.UpdateControllerConnectivityAlarm(mController.ControllerId, false, 9001);
                }
            }
            catch (Exception exp)
            {

                DataReaderAccess.UpdateControllerConnectivityAlarm(mController.ControllerId, true, 9001);
                throw exp;
            }
        }
        /// <summary>
        /// Connects to PLC.
        /// </summary>
        private void ConnectToPLC()
        {
            if (isPLCConnected == false)
            {
                MitsubishiController controller = (MitsubishiController)mController;
                ComFXENETTCP = MitsubishiPLCConnect.ConnectFX3UEthernet(controller,isPLCConnected);
                isPLCConnected = true;
            }
        }
        /// <summary>
        /// Connects the retryon failure.
        /// </summary>
        private void ConnectRetryonFailure()
        {
            System.Configuration.AppSettingsReader appSettingsReader = new System.Configuration.AppSettingsReader();
            int retryCount = (int)appSettingsReader.GetValue("EcontrolPlusRetryCount", typeof(int));

            for (int index = 1; index <= retryCount; index++)
            {
                try
                {
                    if (!isPLCConnected)
                    {
                        MitsubishiController controller = (MitsubishiController)mController;
                        ComFXENETTCP = MitsubishiPLCConnect.ConnectFX3UEthernet(controller,isPLCConnected);
                        isPLCConnected = true;
                        break;
                    }
                }
                catch (Exception exp)
                {
                    if (index == retryCount) throw exp;
                }
            }
        }
        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            //ToDo
        }
    }
}