﻿// -----------------------------------------------------------------------
// <copyright file="MitsubishiFactory.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The MitsubishiFactory </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using Access.DataReader;
using Ecolab.Dcs.Entities;
using Entities;
using log4net;

namespace Ecolab.Dcs.CollectData.Mitsubishi
{
    public class MitsubishiFactory
    {
        public static DataReader<MitsubishiTag> GetDataReader(MitsubishiController controller)
        {
            if (controller.PLCType == MitsubishiPLCType.PLCXL10W ||
                controller.PLCType == MitsubishiPLCType.PLCXL2Cbw ||
                controller.PLCType == MitsubishiPLCType.PLCXL5W1C)
            {
                if (!string.IsNullOrEmpty(controller.HostAdress))
                {
                    return new PLCXLEthernetReader(controller);
                }
                else
                {
                    return new PLCXLSerialPortReader(controller);
                }
            }
            else if (controller.PLCType == MitsubishiPLCType.A1SH)
            {
                return new A1SHEthernetReader(controller);
            }
            else if (controller.PLCType == MitsubishiPLCType.EControlPlus
                || controller.PLCType == MitsubishiPLCType.EControlPlus6W1T
                || controller.PLCType == MitsubishiPLCType.EControlPlus8W)
            {

                if (!string.IsNullOrEmpty(controller.HostAdress))
                {
                    return new FX3UEthernetReader(controller);
                }
                else
                {
                    return new FXSerialPortReader(controller);
                }

            }
            else if (controller.PLCType == MitsubishiPLCType.EControl)
            {

                return new FXSerialPortReader(controller);

            }
            else
            {
                throw new NotImplementedException();
            }

        }
        public static DataWriter<MitsubishiTag> GetDataWriter(MitsubishiController controller)
        {
            if (controller.PLCType == MitsubishiPLCType.PLCXL10W ||
                controller.PLCType == MitsubishiPLCType.PLCXL2Cbw ||
                controller.PLCType == MitsubishiPLCType.PLCXL5W1C)
            {
                if (!string.IsNullOrEmpty(controller.HostAdress))
                {
                    return new PLCXLEthernetWriter(controller);
                }
                else
                {
                    return new PLCXLSerialPortWriter(controller);
                }
            }
            else if (controller.PLCType == MitsubishiPLCType.A1SH)
            {
                return new A1SHEthernetWriter(controller);
            }
            else if (controller.PLCType == MitsubishiPLCType.EControlPlus
                || controller.PLCType == MitsubishiPLCType.EControlPlus6W1T
                || controller.PLCType == MitsubishiPLCType.EControlPlus8W)
            {

                if (!string.IsNullOrEmpty(controller.HostAdress))
                {
                    return new FX3UEthernetWriter (controller);
                }
                else
                {
                    return new FXSerialPortWriter(controller);
                }

            }
            else
            {
                throw new NotImplementedException();
            }

        }

    }
}
