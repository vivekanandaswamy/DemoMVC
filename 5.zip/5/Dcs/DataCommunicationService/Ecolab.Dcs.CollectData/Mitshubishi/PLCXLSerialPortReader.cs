﻿// -----------------------------------------------------------------------
// <copyright file="PLCXLSerialPortReader.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The PLCXLSerialPortReader </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using Access.DataReader;
using ACTPCCOMLibCtl;
using Ecolab.Dcs.Entities;
using Entities;
using log4net;

namespace Ecolab.Dcs.CollectData.Mitsubishi
{
    public class PLCXLSerialPortReader : DataReader<MitsubishiTag>, IDisposable
    {
        
        private ACTPCCOMLibCtl.ActQnACPU ComRefSerial;
        private bool isPLCConnected;
        private static readonly ILog Log = LogManager.GetLogger(typeof(PLCXLSerialPortReader));
        public PLCXLSerialPortReader(MitsubishiController controller)
            : base(controller)
        {
            isPLCConnected = false;
        }

        public override MitsubishiTag ValidateTag(MitsubishiTag tag)
        {
            throw new NotImplementedException();
        }
        private void ReadTagfromPLC(MitsubishiTag tag)
        {

            int returnCode;
            int dataValue;
            short plcYear, plcMonth, plcDay, plcDayOfWeek, plcHour;
            short plcMinute, plcSecond;
            int intYear;

            ConnectToPLC();

            if (tag.Address == "DateTime")
            {
                ComRefSerial.GetClockData(out plcYear, out plcMonth, out plcDay, out plcDayOfWeek, out plcHour, out plcMinute, out plcSecond);
                intYear = plcYear + 2000;
                DateTime dateTime = new DateTime(intYear, plcMonth, plcDay, plcHour, plcMinute, plcSecond);
                tag.Value = dateTime.ToString("MM/dd/yyyy HH:mm:ss");
            }
            else if (tag.TagItemType == UIInputType.TypeArray)
            {

                tag.IntArrayData = new int[tag.ArrayLength];
                returnCode = ComRefSerial.ReadDeviceBlock(tag.Address, tag.ArrayLength, out tag.IntArrayData[0]);
                if (returnCode > 0) throw new COMException("Read array Failed", returnCode);

            }
            else if (tag.TagItemType == UIInputType.TypeInt || tag.TagItemType == UIInputType.TypeBool)
            {
                returnCode = ComRefSerial.GetDevice(tag.Address, out dataValue);
                if (returnCode > 0) throw new COMException("Read value Failed", returnCode);
                tag.Value = dataValue.ToString();
            }

        }
        public override MitsubishiTag ReadTag(MitsubishiTag tag)
        {
            IList<MitsubishiTag> tagList = new List<MitsubishiTag>();
            tagList.Add(tag);
            return ReadTags(tagList).First();

        }

        public override IList<MitsubishiTag> ValidateTags(IList<MitsubishiTag> tags)
        {
            ConnectToPLC();
            int value;
            int returnValue;

            if (isPLCConnected == true)
            {
                foreach (MitsubishiTag tag in tags)
                {
                    returnValue = ComRefSerial.GetDevice(tag.Address, out value);
                    if (returnValue > 0)
                        tag.IsValid = false;
                    else
                        tag.IsValid = true;
                }
            }
            else throw new InvalidOperationException("PLC is not Open");
            return tags;
        }

        public override IList<MitsubishiTag> ReadTags(IList<MitsubishiTag> tagNames)
        {
            foreach (MitsubishiTag tag in tagNames)
            {
                ReadTagfromPLC(tag);

            }
            return tagNames;
        }

        public override object ReadArrayTags()
        {
            throw new NotImplementedException();
        }

        public override int ReadArrayPos(int pos)
        {
            throw new NotImplementedException();
        }

        private void ConnectToPLC()
        {
            if (isPLCConnected == false)
            {
                MitsubishiController controller = (MitsubishiController)mController;
                ComRefSerial = MitsubishiPLCConnect.ConnectPLCXLSerialPort(controller);
                isPLCConnected = true;
            }
          
        }

        public override MitsubishiTag ReadTagExt(MitsubishiTag tag)
        {
            throw new NotImplementedException();
        }
        public override IList<MitsubishiTag> ReadTagsExt(IList<MitsubishiTag> tagNames)
        {
            throw new NotImplementedException();

        }

        public void Dispose()
        {
            //To Do
        }

    }
    
}
