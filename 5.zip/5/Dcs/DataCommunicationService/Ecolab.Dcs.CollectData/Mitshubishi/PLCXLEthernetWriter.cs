﻿// -----------------------------------------------------------------------
// <copyright file="PLCXLEthernetWriter.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The PLCXLEthernetWriter </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using Access.DataReader;
using ACTETHERLib;
using Ecolab.Dcs.Entities;
using Entities;
using log4net;

namespace Ecolab.Dcs.CollectData.Mitsubishi
{
    public class PLCXLEthernetWriter: DataWriter<MitsubishiTag>, IDisposable
    {
        private ACTETHERLib.ActQJ71E71UDP ComRefUDP;
        private bool isPLCConnected;
        private static readonly ILog Log = LogManager.GetLogger(typeof(PLCXLEthernetWriter));
        public PLCXLEthernetWriter(MitsubishiController controller)
            : base(controller)
        {
            isPLCConnected = false;
        }

        public override MitsubishiTag WriteTag(MitsubishiTag tag)
        {
             IList<MitsubishiTag> tagList = new List<MitsubishiTag>();
            tagList.Add(tag);
            return WriteTags(tagList).First();
        }

        public override IList<MitsubishiTag> WriteTags(IList<MitsubishiTag> tags)
        {
            foreach (MitsubishiTag tag in tags)
            {
                WriteTagtoPLC(tag);

            }
            return tags;
        }

        public override ComplexStruct WriteArrayTags(ComplexStruct tagStruct)
        {
            throw new NotImplementedException();
        }

        public override int WriteArrayPos(int tagPos, int tagVal)
        {
            throw new NotImplementedException();
        }
        public override IList<MitsubishiTag> WriteTagsExt(IList<MitsubishiTag> tags)
        {
            throw new NotImplementedException();
        }
        public override MitsubishiTag WriteTagExt(MitsubishiTag tag)
        {
            throw new NotImplementedException();
        }
        private void WriteTagtoPLC(MitsubishiTag tag)
        {

            int returnCode;
            int dataValue;
            DateTime plcDate;
            short plcYear, plcMonth, plcDay, plcHour, plcMinute, plcSecond;
            int intYear;
            try
            {
                ConnectToPLC();

                if (tag.Address == "DateTime")
                {
                    plcDate = DateTime.Now;
                    plcYear = (short)(plcDate.Year - 2000);
                    plcMonth = (short)plcDate.Month;
                    intYear = plcYear + 2000;
                    plcDay = (short)plcDate.Day;
                    plcHour = (short)plcDate.Hour;
                    plcMinute = (short)plcDate.Minute;
                    plcSecond = (short)plcDate.Second;
                    DateTime dateTime = new DateTime(intYear, plcMonth, plcDay, plcHour, plcMinute, plcSecond);
                    tag.Value = dateTime.ToString("MM/dd/yyyy HH:mm:ss");
                }
                else if (tag.TagItemType == UIInputType.TypeArray)
                {
                    returnCode = ComRefUDP.WriteDeviceBlock(tag.Address, tag.ArrayLength, ref tag.IntArrayData[0]);
                    if (returnCode > 0) throw new COMException("Write Array Failed", returnCode);

                }
                else if (tag.TagItemType == UIInputType.TypeRandomArray)
                {
                    returnCode = ComRefUDP.WriteDeviceRandom(tag.Address, tag.ArrayLength, ref tag.IntArrayData[0]);
                    if (returnCode > 0) throw new COMException("Read array Failed", returnCode);

                }
                else if (tag.TagItemType == UIInputType.TypeInt || tag.TagItemType == UIInputType.TypeBool)
                {
                    dataValue = Convert.ToInt32(tag.Value);
                    returnCode = ComRefUDP.SetDevice(tag.Address, dataValue);
                    if (returnCode > 0) throw new COMException("Write value failed", returnCode);
                    tag.Value = dataValue.ToString();
                }
            }
            catch (Exception exp)
            {
                if (ComRefUDP != null)
                {
                    ComRefUDP.Close();
                }
                isPLCConnected = false;
                throw exp;
            }
        }
      
        private void ConnectToPLC()
        {
            try
            {
                if (isPLCConnected == false)
                {
                    MitsubishiController controller = (MitsubishiController)mController;
                    ComRefUDP = MitsubishiPLCConnect.ConnnectPLCXLEthernet(controller);
                    isPLCConnected = true;
                    DataReaderAccess.UpdateControllerConnectivityAlarm(mController.ControllerId, false, 9001);
                }
            }
            catch (Exception exp)
            {
                
                DataReaderAccess.UpdateControllerConnectivityAlarm(mController.ControllerId, true, 9001);
                throw exp;
            }
        }
        public bool IsConnected()
        {
            return isPLCConnected;
        }
        public void Dispose()
        {

            if (ComRefUDP != null) ComRefUDP.Close();
            isPLCConnected = false;
            //Dispose(true);
            //GC.SuppressFinalize(this);
        }
    }
}
