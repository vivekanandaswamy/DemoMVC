﻿// -----------------------------------------------------------------------
// <copyright file="FX3UEthernetReader.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The FX3UEthernetReader </summary>
// -----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using Access.DataReader;
using Ecolab.Dcs.Entities;
using log4net;

namespace Ecolab.Dcs.CollectData.Mitsubishi
{
    /// <summary>
    /// Class for Ethernet details
    /// </summary>
    /// <seealso cref="Ecolab.Dcs.CollectData.DataReader{Ecolab.Dcs.Entities.MitsubishiTag}" />
    /// <seealso cref="System.IDisposable" />
    public class FX3UEthernetReader : DataReader<MitsubishiTag>, IDisposable
    {
        //private ACTMULTILib.ActEasyIF 
        /// <summary>
        /// The COM fxenettcp
        /// </summary>
        private ACTETHERLib.ActFXENETTCP ComFXENETTCP;
        /// <summary>
        /// The is PLC connected
        /// </summary>
        private bool isPLCConnected;
        /// <summary>
        /// The log value for logger
        /// </summary>
        private static readonly ILog Log = LogManager.GetLogger(typeof(A1SHEthernetReader));
        /// <summary>
        /// Initializes a new instance of the <see cref="FX3UEthernetReader"/> class.
        /// </summary>
        /// <param name="controller">The controller.</param>
        public FX3UEthernetReader(MitsubishiController controller)
            : base(controller)
        {
            isPLCConnected = false;
        }

        /// <summary>
        /// Validates the tag.
        /// </summary>
        /// <param name="tag">The tag values from plc.</param>
        /// <returns>Returns MitsubishiTag</returns>
        /// <exception cref="System.NotImplementedException"></exception>
        public override MitsubishiTag ValidateTag(MitsubishiTag tag)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Reads the tagfrom PLC.
        /// </summary>
        /// <param name="tag">The tag values from plc.</param>
        /// <exception cref="System.Runtime.InteropServices.COMException">
        /// Read array Failed
        /// or
        /// Read value Failed
        /// or
        /// Read array Failed
        /// </exception>
        private void ReadTagfromPLC(MitsubishiTag tag)
        {
            int returnCode;
            int dataValue;
            short plcYear, plcMonth, plcDay, plcDayOfWeek, plcHour;
            short plcMinute, plcSecond;
            int intYear;

            try
            {
                if (tag.Address == "DateTime")
                {
                    ComFXENETTCP.GetClockData(out plcYear, out plcMonth, out plcDay, out plcDayOfWeek, out plcHour, out plcMinute, out plcSecond);
                    intYear = plcYear + 2000;
                    DateTime dateTime = new DateTime(intYear, plcMonth, plcDay, plcHour, plcMinute, plcSecond);
                    tag.Value = dateTime.ToString("MM/dd/yyyy HH:mm:ss");
                }
                else if (tag.TagItemType == UIInputType.TypeArray)
                {

                    tag.IntArrayData = new int[tag.ArrayLength];

                    returnCode = ComFXENETTCP.ReadDeviceBlock(tag.Address, tag.ArrayLength, out tag.IntArrayData[0]);
                    if (returnCode > 0) throw new COMException("Read array Failed", returnCode);

                }
                else if (tag.TagItemType == UIInputType.TypeInt || tag.TagItemType == UIInputType.TypeBool)
                {
                    returnCode = ComFXENETTCP.GetDevice(tag.Address, out dataValue);
                    if (returnCode > 0) throw new COMException("Read value Failed", returnCode);
                    tag.Value = dataValue.ToString();
                }
                else if (tag.TagItemType == UIInputType.TypeRandomArray)
                {

                    tag.IntArrayData = new int[tag.ArrayLength];
                    returnCode = ComFXENETTCP.ReadDeviceRandom(tag.Address, tag.ArrayLength, out tag.IntArrayData[0]);
                    if (returnCode > 0) throw new COMException("Read array Failed", returnCode);
                }
                //DataReaderAccess.UpdateControllerConnectivityAlarm(mController.ControllerId, false, 9001);
            }
            catch (Exception exception)
            {
                //DataReaderAccess.UpdateControllerConnectivityAlarm(mController.ControllerId, true, 9001);
                isPLCConnected = false;
                throw exception;
            }
        }

        /// <summary>
        /// Reads the tag ext.
        /// </summary>
        /// <param name="tag">The tag values from plc.</param>
        /// <returns>Returns MitsubishiTag</returns>
        public override MitsubishiTag ReadTagExt(MitsubishiTag tag)
        {
            IList<MitsubishiTag> tagList = new List<MitsubishiTag>();
            tagList.Add(tag);
            MitsubishiTag tag1;
            tag1 = ReadTagsExt(tagList).First();
            return tag1;
        }

        /// <summary>
        /// Reads the tag.
        /// </summary>
        /// <param name="tag">The tag values from plc.</param>
        /// <returns>Returns MitsubishiTag</returns>
        public override MitsubishiTag ReadTag(MitsubishiTag tag)
        {
            IList<MitsubishiTag> tagList = new List<MitsubishiTag>();
            tagList.Add(tag);
            MitsubishiTag tag1;
            tag1 = ReadTags(tagList).First();
            return tag1;
        }

        /// <summary>
        /// Validates the tags.
        /// </summary>
        /// <param name="tags">The tags values from plc.</param>
        /// <returns>Returns list of MitsubishiTag</returns>
        /// <exception cref="System.InvalidOperationException">PLC is not Open</exception>
        public override IList<MitsubishiTag> ValidateTags(IList<MitsubishiTag> tags)
        {
            ConnectToPLC();
            int value;
            int returnValue;

            if (isPLCConnected == true)
            {
                foreach (MitsubishiTag tag in tags)
                {
                    returnValue = ComFXENETTCP.GetDevice(tag.Address, out value);
                    if (returnValue > 0)
                        tag.IsValid = false;
                    else
                        tag.IsValid = true;
                }
            }
            else throw new InvalidOperationException("PLC is not Open");
            return tags;
        }

        /// <summary>
        /// Reads the tags ext.
        /// </summary>
        /// <param name="tagNames">The tag names.</param>
        /// <returns>Returns list of MitsubishiTag</returns>
        public override IList<MitsubishiTag> ReadTagsExt(IList<MitsubishiTag> tagNames)
        {
            ConnectToPLC();
            try
            {
                foreach (MitsubishiTag tag in tagNames)
                {
                    ReadTagfromPLC(tag);
                }
            }
            finally
            {
                ClosePLC();
            }

            return tagNames;
        }

        /// <summary>
        /// Reads the tags.
        /// </summary>
        /// <param name="tagNames">The tag names.</param>
        /// <returns>Returns list of MitsubishiTag</returns>
        /// <exception cref="System.Exception">Unable to Connect</exception>
        public override IList<MitsubishiTag> ReadTags(IList<MitsubishiTag> tagNames)
        {
            bool exp = false;
            try
            {
                var signals = new List<ManualResetEvent>();
                using (var signal = new ManualResetEvent(false))
                {
                    signals.Add(signal);
                    var thread = new Thread(() =>
                    {
                        try
                        {
                            ConnectRetryonFailure();
                            foreach (MitsubishiTag tag in tagNames)
                            {
                                try
                                {
                                    ReadTagfromPLC(tag);
                                }
                                catch
                                {
                                    throw;
                                }
                            }
                            signal.Set();
                        }
                        catch
                        {
                            exp = true;
                            signal.Set();
                        }
                        finally
                        {
                            ClosePLC();
                        }
                    });
                    thread.SetApartmentState(ApartmentState.STA);
                    thread.Start();
                    WaitHandle.WaitAll(signals.ToArray());
                }
                if (exp == true) throw new Exception("Unable to Connect to PLC");

                return tagNames;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// Reads the array tags.
        /// </summary>
        /// <returns>Returns MitsubishiTags</returns>
        /// <exception cref="System.NotImplementedException"></exception>
        public override object ReadArrayTags()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Reads the array position.
        /// </summary>
        /// <param name="pos">The position.</param>
        /// <returns>Returns MitsubishiTags</returns>
        /// <exception cref="System.NotImplementedException"></exception>
        public override int ReadArrayPos(int pos)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Closes the PLC.
        /// </summary>
        public void ClosePLC()
        {
            try
            {
                if (isPLCConnected == true)
                {
                    MitsubishiController controller = (MitsubishiController)mController;
                    MitsubishiPLCConnect.CloseFX3UEthernet(controller);
                    isPLCConnected = false;
                    //DataReaderAccess.UpdateControllerConnectivityAlarm(mController.ControllerId, false, 9001);
                }
            }
            catch (Exception exp)
            {

                //DataReaderAccess.UpdateControllerConnectivityAlarm(mController.ControllerId, true, 9001);
                throw exp;
            }
        }

        /// <summary>
        /// Connects to PLC.
        /// </summary>
        private void ConnectToPLC()
        {
            try
            {
                if (isPLCConnected == false)
                {
                    MitsubishiController controller = (MitsubishiController)mController;
                    ComFXENETTCP = MitsubishiPLCConnect.ConnectFX3UEthernet(controller,isPLCConnected);
                    isPLCConnected = true;
                    DataReaderAccess.UpdateControllerConnectivityAlarm(mController.ControllerId, false, 9001);
                }
            }
            catch
            {
                DataReaderAccess.UpdateControllerConnectivityAlarm(mController.ControllerId, true, 9001);
                throw;
            }
        }
        /// <summary>
        /// Connects the retryon failure.
        /// </summary>
        private void ConnectRetryonFailure()
        {
            System.Configuration.AppSettingsReader appSettingsReader = new System.Configuration.AppSettingsReader();
            int retryCount = (int)appSettingsReader.GetValue("EcontrolPlusRetryCount", typeof(int));

            for (int index = 1; index <= retryCount; index++)
            {
                try
                {
                    if (!isPLCConnected)
                    {
                        MitsubishiController controller = (MitsubishiController)mController;
                        ComFXENETTCP = MitsubishiPLCConnect.ConnectFX3UEthernet(controller,isPLCConnected);
                        isPLCConnected = true;
                        break;
                    }
                }
                catch (Exception exp)
                {
                    if (index == retryCount) throw exp;
                }
            }
        }
        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            //to do

        }
    }
}