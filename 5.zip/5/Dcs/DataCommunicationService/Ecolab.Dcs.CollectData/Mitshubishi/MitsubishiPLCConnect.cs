﻿// -----------------------------------------------------------------------
// <copyright file="MitsubishiPLCConnect.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The MitsubishiPLCConnect </summary>
// -----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Ecolab.Dcs.Entities;

namespace Ecolab.Dcs.CollectData.Mitsubishi
{
    /// <summary>
    /// Class for MitsubishiPLCConnect
    /// </summary>
    public class MitsubishiPLCConnect
    {
        /// <summary>
        /// The PLC connections
        /// </summary>
        private static IDictionary<string, object> PLCConnections = new Dictionary<string,object>();

        /// <summary>
        /// Connnects the PLCXL ethernet.
        /// </summary>
        /// <param name="controller">The controller.</param>
        /// <returns>Returns Ethernet Details</returns>
        /// <exception cref="System.Runtime.InteropServices.COMException">Open Failed</exception>
        public static ACTETHERLib.ActQJ71E71UDP ConnnectPLCXLEthernet(MitsubishiController controller)
        {
            ACTETHERLib.ActQJ71E71UDP ComRefUDP = null;
            
                string[] ip = controller.HostAdress.Split('.');
                ComRefUDP = new ACTETHERLib.ActQJ71E71UDP();
                ComRefUDP.ActHostAddress = controller.HostAdress;
                ComRefUDP.ActNetworkNumber = 1;
                ComRefUDP.ActStationNumber = Convert.ToInt32(ip[3]);
                ComRefUDP.ActUnitNumber = 0;
                ComRefUDP.ActIONumber = 1023;
                ComRefUDP.ActCpuType = 18;
                ComRefUDP.ActPortNumber = 5001;// this.PortNumber;
                ComRefUDP.ActSourceNetworkNumber = 1;
                ComRefUDP.ActSourceStationNumber = 2;
                int returnCode = ComRefUDP.Open();
                if (returnCode > 0) throw new COMException("Open Failed", returnCode);
                return ComRefUDP;
        }
       
        /// <summary>
        /// Connects the PLCXL serial port.
        /// </summary>
        /// <param name="controller">The controller.</param>
        /// <returns>Returns SerialPort</returns>
        /// <exception cref="System.Runtime.InteropServices.COMException">Open Failed</exception>
        public static ACTPCCOMLibCtl.ActQnACPU ConnectPLCXLSerialPort(MitsubishiController controller)
        {
            ACTPCCOMLibCtl.ActQnACPU ComRefSerial;

           
                ComRefSerial = new ACTPCCOMLibCtl.ActQnACPU();
                ComRefSerial.ActPortNumber = controller.PortNumber;
                ComRefSerial.ActIONumber = 1023;
                ComRefSerial.ActNetworkNumber = 0;
                ComRefSerial.ActStationNumber = 255;
                ComRefSerial.ActTimeOut = 10000;
                ComRefSerial.ActCpuType = 18;

                int returnCode = ComRefSerial.Open();
                if (returnCode > 0) throw new COMException("Open Failed", returnCode);
                return ComRefSerial;
        }
        /// <summary>
        /// Connects the a1 sh ethernet.
        /// </summary>
        /// <param name="controller">The controller.</param>
        /// <returns>Returns Ethernet Details</returns>
        /// <exception cref="System.Runtime.InteropServices.COMException">Open Failed</exception>
        public static ACTETHERLib.ActAJ71E71TCP ConnectA1SHEthernet(MitsubishiController controller)
        {

            ACTETHERLib.ActAJ71E71TCP ComRefTCP;

            if (PLCConnections.ContainsKey(controller.ControllerId.ToString()))
            {
                ComRefTCP = (ACTETHERLib.ActAJ71E71TCP)PLCConnections[controller.ControllerId.ToString()];
            }
            else
            {
                ComRefTCP =  new ACTETHERLib.ActAJ71E71TCP();
                ComRefTCP.ActHostAddress = controller.HostAdress;
                ComRefTCP.ActDestinationPortNumber = 1282;
                ComRefTCP.ActPacketType  = 1;
                ComRefTCP.ActStationNumber =255;
                ComRefTCP.ActCpuType = 261;
                ComRefTCP.ActTimeOut = 10000;
                int returnCode =  ComRefTCP.Open();
                if (returnCode > 0) throw new COMException("Open Failed", returnCode);
                PLCConnections.Add(controller.ControllerId.ToString(), ComRefTCP);
            }
            return ComRefTCP;
        }
        /// <summary>
        /// Connects the f x3 u ethernet.
        /// </summary>
        /// <param name="controller">The controller.</param>
        /// <returns>Returns Ethernet Details</returns>
        /// <exception cref="System.Exception">Open Failed</exception>
        public static ACTETHERLib.ActFXENETTCP ConnectFX3UEthernet(MitsubishiController controller, bool isConnected)
        {
            ACTETHERLib.ActFXENETTCP ComFXENETTCP=null;
            if (!isConnected && PLCConnections.ContainsKey(controller.ControllerId.ToString()))
            {
                PLCConnections.Remove(controller.HostAdress);
            }
            if (PLCConnections.ContainsKey(controller.ControllerId.ToString()))
            {
                ComFXENETTCP = (ACTETHERLib.ActFXENETTCP)PLCConnections[controller.ControllerId.ToString()];
            }
            else
            {
                ComFXENETTCP = new ACTETHERLib.ActFXENETTCP();
                ComFXENETTCP.ActHostAddress = controller.HostAdress;
                ComFXENETTCP.ActDestinationPortNumber = 1024;
                ComFXENETTCP.ActCpuType = 514;
                ComFXENETTCP.ActTimeOut = 10000;
                int returnCode = ComFXENETTCP.Open();
                if (returnCode > 0)
                    throw new Exception("Open Failed");//, returnCode);
                PLCConnections.Add(controller.ControllerId.ToString(), ComFXENETTCP);
            }
            return ComFXENETTCP;
        }
        /// <summary>
        /// Closes the f x3 u ethernet.
        /// </summary>
        /// <param name="controller">The controller.</param>
        /// <exception cref="System.Runtime.InteropServices.COMException">Open Failed</exception>
        public static void CloseFX3UEthernet(MitsubishiController controller)
        {

            ACTETHERLib.ActFXENETTCP obj;
            obj = (ACTETHERLib.ActFXENETTCP)PLCConnections[controller.ControllerId.ToString()];
            if (obj != null)
            {
                int ret = obj.Close();
                if (ret > 0)
                    throw new COMException("Open Failed", ret);
                PLCConnections.Remove(controller.ControllerId.ToString());
            }
        }
        
        
        /// <summary>
        /// Connects the f x3 u serial port.
        /// </summary>
        /// <param name="controller">The controller.</param>
        /// <returns>Returns Serial Port</returns>
        /// <exception cref="System.Runtime.InteropServices.COMException">Open Failed</exception>
        public static ACTPCCOMLibCtl.ActFXCPU ConnectFX3USerialPort(MitsubishiController controller)
        {
            ACTPCCOMLibCtl.ActFXCPU ComFXCPU;

            if (PLCConnections.ContainsKey(controller.ControllerId.ToString()))
            {
                ComFXCPU = (ACTPCCOMLibCtl.ActFXCPU)PLCConnections[controller.ControllerId.ToString()];
            }
            else
            {
                ComFXCPU = new ACTPCCOMLibCtl.ActFXCPU();
                ComFXCPU.ActPortNumber = controller.PortNumber;
                ComFXCPU.ActCpuType = 514;
                ComFXCPU.ActBaudRate = 9600;
                ComFXCPU.ActControl = 8;
                ComFXCPU.ActTimeOut = 10000;
                int returnCode = ComFXCPU.Open();
                if (returnCode > 0) throw new COMException("Open Failed", returnCode);
                PLCConnections.Add(controller.ControllerId.ToString(), ComFXCPU);
            }
            return ComFXCPU;
        }

        /// <summary>
        /// Connects the f x2 n serial port.
        /// </summary>
        /// <param name="controller">The controller.</param>
        /// <returns>Returns Serial Port</returns>
        /// <exception cref="System.Runtime.InteropServices.COMException">Open Failed</exception>
        public static ACTPCCOMLibCtl.ActFXCPU ConnectFX2NSerialPort(MitsubishiController controller)
        {
            ACTPCCOMLibCtl.ActFXCPU ComFXCPU;

            if (PLCConnections.ContainsKey(controller.ControllerId.ToString()))
            {
                ComFXCPU = (ACTPCCOMLibCtl.ActFXCPU)PLCConnections[controller.ControllerId.ToString()];
            }
            else
            {
                ComFXCPU = new ACTPCCOMLibCtl.ActFXCPU();
                ComFXCPU.ActPortNumber = controller.PortNumber;
                ComFXCPU.ActCpuType = 513;
                ComFXCPU.ActBaudRate = 9600;
                ComFXCPU.ActControl = 8;
                ComFXCPU.ActTimeOut = 10000;
                int returnCode = ComFXCPU.Open();
                if (returnCode > 0) throw new COMException("Open Failed", returnCode);
                PLCConnections.Add(controller.ControllerId.ToString(), ComFXCPU);
            }
            return ComFXCPU;
        }
    }
}
