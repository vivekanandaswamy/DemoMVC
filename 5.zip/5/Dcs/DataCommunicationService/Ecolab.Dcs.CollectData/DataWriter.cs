﻿// -----------------------------------------------------------------------
// <copyright file="DataWriter.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The DataWriter </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Dcs.CollectData
{
    using System.Collections.Generic;
    using Entities;   

    public abstract class DataWriter<T> where T : Tag
    {
        protected Controller mController { get; set; }

        protected DataWriter(Controller controller)
        {
            mController = controller;
        }

        public abstract T WriteTag(T tag);
        public abstract IList<T> WriteTags(IList<T> tags);
        public abstract ComplexStruct WriteArrayTags(ComplexStruct tagStruct);
        public abstract int WriteArrayPos(int tagPos, int tagVal);

        public abstract T WriteTagExt(T tag);
        public abstract IList<T> WriteTagsExt(IList<T> tags);
    }
}