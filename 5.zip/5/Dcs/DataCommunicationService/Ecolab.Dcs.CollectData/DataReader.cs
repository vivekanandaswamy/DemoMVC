﻿// -----------------------------------------------------------------------
// <copyright file="DataReader.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The DataReader </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Dcs.CollectData
{
    using System.Collections.Generic;
    using Entities;

    public abstract class DataReader<T> where T : Tag
    {
        protected Controller mController { get; set; }

        protected DataReader(Controller controller)
        {
            mController = controller;
        }

        public abstract T ValidateTag(T tag);
        public abstract T ReadTag(T tag);
        public abstract IList<T> ValidateTags(IList<T> tags);
        public abstract IList<T> ReadTags(IList<T> tagNames);
        public abstract object ReadArrayTags();
        public abstract int ReadArrayPos(int pos);

        public abstract T ReadTagExt(T tag);
        public abstract IList<T> ReadTagsExt(IList<T> tagNames);
    }
}