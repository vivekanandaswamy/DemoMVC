﻿// -----------------------------------------------------------------------
// <copyright file="OpcDataWriter.cs" company="Ecolab">
// ©2014 Ecolab All rights reserved
// </copyright>
// <summary>The Opc Data Writer </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Dcs.CollectData.Opc
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Entities;
    using log4net;
    using OPCAutomation;
    using Access.DataReader;

    /// <summary>
    ///     Opc Data Writer
    /// </summary>
    public class OpcDataWriter : DataWriter<OpcTag>
    {
        private static readonly ILog Log = LogManager.GetLogger(typeof(OpcDataWriter));
        private readonly AllenBradleyController mAllenBradleyController;
        private readonly OPCServer mOpcServer;
        private readonly string mRslinxItemFormat = "[{0}].{1}";

        /// <summary>
        ///     Opc Data Writer
        /// </summary>
        /// <param name="controller">controller</param>
        /// <param name="opcItemFormat">opc Item Format</param>
        public OpcDataWriter(AllenBradleyController controller, string opcItemFormat)
            : base(controller)
        {
            mAllenBradleyController = controller;
            mOpcServer = new OPCServer();
            mRslinxItemFormat = opcItemFormat;
        }

        /// <summary>
        ///     Connect
        /// </summary>
        /// <returns>Returns boolean</returns>
        private bool Connect()
        {
            try
            {
                mOpcServer.Connect(mAllenBradleyController.OpcServer);
                DataReaderAccess.UpdateControllerConnectivityAlarm(mAllenBradleyController.ControllerId, false, 9001);
                return true;
            }
            catch (Exception ex)
            {
                DataReaderAccess.UpdateControllerConnectivityAlarm(mAllenBradleyController.ControllerId, true, 9001);
                Log.InfoFormat("Failed to connect to server {0} with error {1}", mAllenBradleyController.OpcServer, ex);
                throw new ApplicationException("Invalid_Server", ex);
            }
        }

        /// <summary>
        ///     Disconnect
        /// </summary>
        /// <returns>Returns boolean</returns>
        private bool Disconnect()
        {
            Log.InfoFormat("Disconnecting the sever {0}", mOpcServer.ServerName);
            try
            {
                Log.InfoFormat("Current sever state {0}", mOpcServer.ServerState);
                mOpcServer.Disconnect();
                Log.Info("Disconnected the sever");
                return true;
            }
            catch (Exception ex)
            {
                Log.InfoFormat("Failed to disconnect {0}", ex);
                return false;
            }
        }

        /// <summary>
        ///     Write Tag
        /// </summary>
        /// <param name="tag">tag</param>
        /// <returns>Returns boolean OpcTag</returns>
        public override OpcTag WriteTag(OpcTag tag)
        {
            var tags = new List<OpcTag> { tag };
            return WriteTags(tags).First();
        }

        /// <summary>
        ///     Write Tags
        /// </summary>
        /// <param name="tags">tags</param>
        /// <returns>Returns List of OpcTag</returns>
        public override IList<OpcTag> WriteTags(IList<OpcTag> tags)
        {
            if (!Connect())
            {
                return tags;
            }
            OPCGroup connectedGroup = null;
            Array syncItemServerHandles = null;
            string groupName = Guid.NewGuid().ToString();
            try
            {
                mOpcServer.Connect(mAllenBradleyController.OpcServer);
                connectedGroup = mOpcServer.OPCGroups.Add(groupName);
                Array opcItems = new string[tags.Count + 1];
                Array clientHandles = new int[tags.Count + 1];
                Log.InfoFormat("OpcServer ", mOpcServer.ToString());
                for (int i = 0; i < tags.Count; i++)
                {
                    opcItems.SetValue(String.Format(mRslinxItemFormat, tags[i].Topic, tags[i].Address), i + 1);
                    clientHandles.SetValue(i + 1, i + 1);
                }
                Log.InfoFormat("opcItems are", opcItems.ToString());
                Array serverHandles;
                Array serverErrors;
                connectedGroup.OPCItems.AddItems(tags.Count, opcItems, ref clientHandles, out serverHandles, out serverErrors);
                Log.InfoFormat("ConnectedGroup ", connectedGroup);
                for (int i = 1; i <= serverErrors.Length; i++)
                {
                    tags[i - 1].IsValid = (int)serverErrors.GetValue(i) == 0;
                    tags[i - 1].ClientHandle = (int)clientHandles.GetValue(i);
                    tags[i - 1].ServerHandle = (int)serverHandles.GetValue(i);
                }
                Log.InfoFormat("Tags are", tags.ToString());
                OpcTag[] validTags = tags.Where(s => s.IsValid).ToArray();
                syncItemServerHandles = new int[validTags.Count() + 1];
                Array syncItemValues = new object[validTags.Count() + 1];
                Array removeServerHandles = new int[validTags.Count() + 1];
                for (int i = 1; i <= validTags.Count(); i++)
                {
                    syncItemServerHandles.SetValue(validTags[i - 1].ServerHandle, i);
                    removeServerHandles.SetValue(validTags[i - 1].ServerHandle, i);
                    syncItemValues.SetValue(validTags[i - 1].Value, i);
                }
                Array syncItemErrors;
                Log.InfoFormat("Valid Tags are", validTags.ToString());
                connectedGroup.SyncWrite(validTags.Count(), ref syncItemServerHandles, ref syncItemValues, out syncItemErrors);
                for (int i = 1; i <= syncItemErrors.Length; i++)
                {
                    tags[i - 1].IsValid = (int)syncItemErrors.GetValue(i) == 0;
                }
            }
            catch(Exception ex)
            {
                Log.InfoFormat("Failed to Write {0}", ex);                
            }            
            return tags;
        }

        public override IList<OpcTag> WriteTagsExt(IList<OpcTag> tags)
        {
            throw new NotImplementedException();
        }
        public override OpcTag WriteTagExt(OpcTag tag)
        {
            throw new NotImplementedException();
        }
     
        public override ComplexStruct WriteArrayTags(ComplexStruct tagStruct)
        {
            return tagStruct;
        }
        public override int WriteArrayPos(int tagPos, int tagVal)
        {
            return tagVal;
        }
    }
}