﻿// -----------------------------------------------------------------------
// <copyright file="OpcDataReader.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The OpcDataReader </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Dcs.CollectData.Opc
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Entities;
    using log4net;
    using OPCAutomation;
    using Access.DataReader;

    public class OpcDataReader : DataReader<OpcTag>
    {
        public delegate void DataChanged(IList<OpcTag> tags, object callbackData);
        public delegate void NotifyShutDown(int ControllerID, string reason);

        public NotifyShutDown ServerShutDownCallBack { get; set; }

        private static readonly ILog Log = LogManager.GetLogger(typeof(OpcDataReader));
        public readonly AllenBradleyController AllenBradleyController;
        private readonly Dictionary<string, OPCGroup> mConnectedGroups = new Dictionary<string, OPCGroup>();
        private readonly OPCServer mOpcServer;
        private readonly string mRslinxItemFormat = "[{0}].{1}";
        public string TrackingType { get; set; }
        private static int RatioDosingActive = int.Parse(System.Configuration.ConfigurationManager.AppSettings["RatioDosingActive"]);

        
        public OpcDataReader(AllenBradleyController controller, string opcItemFormat, NotifyShutDown shutdownCallBack=null)
            : base(controller)
        {
            AllenBradleyController = controller;
            mOpcServer = new OPCServer();
            mOpcServer.ServerShutDown += HandleServerShutDown;
            mRslinxItemFormat = opcItemFormat;
            this.ServerShutDownCallBack = shutdownCallBack;
        }
        private void HandleServerShutDown(string reason)
        {
            if (ServerShutDownCallBack !=null)
                ServerShutDownCallBack(AllenBradleyController.ControllerId, reason);

        }
        private bool Connect()
        {
            try
            {
                mOpcServer.Connect(AllenBradleyController.OpcServer);
                DataReaderAccess.UpdateControllerConnectivityAlarm(AllenBradleyController.ControllerId, false, 9001);
                
                return true;
            }
            catch (Exception ex)
            {
                DataReaderAccess.UpdateControllerConnectivityAlarm(AllenBradleyController.ControllerId, true, 9001);
                Log.InfoFormat("Failed to connect to server {0} with error {1}", AllenBradleyController.OpcServer, ex);
                throw new ApplicationException("Invalid_Server", ex);
            }
        }

        private bool Disconnect()
        {
            Log.InfoFormat("Disconnecting the sever {0}", mOpcServer.ServerName);
            try
            {
                Log.InfoFormat("Current sever state {0}", mOpcServer.ServerState);
                mOpcServer.Disconnect();
                Log.Info("Disconnected the sever");
                return true;
            }
            catch (Exception ex)
            {
                Log.InfoFormat("Failed to disconnect {0}", ex);
                return false;
            }
        }

        public override OpcTag ValidateTag(OpcTag tag)
        {
            var tags = new List<OpcTag> { tag };
            return ValidateTags(tags).First();
        }

        public override OpcTag ReadTag(OpcTag tag)
        {
            var tags = new List<OpcTag> { tag };
            return ReadTags(tags).First();
        }

        public override IList<OpcTag> ValidateTags(IList<OpcTag> tags)
        {
            if (!Connect())
            {
                return tags;
            }
            OPCGroup connectedGroup = null;
            string groupName = "ValidateTag" + Guid.NewGuid();
            try
            {
                connectedGroup = mOpcServer.OPCGroups.Add(groupName);
                connectedGroup.OPCItems.DefaultIsActive = true;
                Array opcItems = new string[tags.Count + 1];
                Array clientHandles = new int[tags.Count];
                for (int i = 0; i < tags.Count; i++)
                {
                    opcItems.SetValue(String.Format(mRslinxItemFormat, tags[i].Topic, tags[i].Address), i + 1);
                    clientHandles.SetValue(i, i);
                }
                Array serverErrors;
                connectedGroup.OPCItems.Validate(tags.Count, ref opcItems, out serverErrors);
                for (int i = 1; i <= serverErrors.Length; i++)
                {
                    tags[i - 1].IsValid = (int)serverErrors.GetValue(i) == 0;
                }
            }
            finally
            {
                if (connectedGroup != null)
                {
                    mOpcServer.OPCGroups.Remove(groupName);
                }
                Disconnect();
            }
            return tags;
        }

        public override IList<OpcTag> ReadTags(IList<OpcTag> tagNames)
        {
            if (!Connect())
            {
                return tagNames;
            }
            OPCGroup connectedGroup = null;
            Array syncItemServerHandles = null;
            string groupName = "ValidateTag" + Guid.NewGuid();
            try
            {
                mOpcServer.Connect(AllenBradleyController.OpcServer);
                connectedGroup = mOpcServer.OPCGroups.Add(groupName);
                Array opcItems = new string[tagNames.Count + 1];
                Array clientHandles = new int[tagNames.Count + 1];
                for (int i = 0; i < tagNames.Count; i++)
                {
                    opcItems.SetValue(String.Format(mRslinxItemFormat, tagNames[i].Topic, tagNames[i].Address), i + 1);
                    clientHandles.SetValue(i + 1, i + 1);
                }
                Array serverHandles;
                Array serverErrors;
                object itemQualities;
                object itemTimeStamps;
                connectedGroup.OPCItems.AddItems(tagNames.Count, opcItems, ref clientHandles, out serverHandles, out serverErrors);
                for (int i = 1; i <= serverErrors.Length; i++)
                {
                    tagNames[i - 1].IsValid = (int)serverErrors.GetValue(i) == 0;
                    tagNames[i - 1].ClientHandle = (int)clientHandles.GetValue(i);
                    tagNames[i - 1].ServerHandle = (int)serverHandles.GetValue(i);
                }
                OpcTag[] validTags = tagNames.Where(s => s.IsValid).ToArray();
                syncItemServerHandles = new int[validTags.Count() + 1];
                Array removeServerHandles = new int[validTags.Count() + 1];
                for (int i = 1; i <= validTags.Count(); i++)
                {
                    syncItemServerHandles.SetValue(validTags[i - 1].ServerHandle, i);
                    removeServerHandles.SetValue(validTags[i - 1].ServerHandle, i);
                }
                Array syncItemValues;
                Array syncItemErrors;
                if (!validTags.Any())
                {
                    return tagNames;
                }
                connectedGroup.SyncRead((short)OPCDataSource.OPCDevice, validTags.Count(), ref syncItemServerHandles, out syncItemValues, out syncItemErrors, out itemQualities, out itemTimeStamps);

                for (int i = 1; i <= validTags.Count(); i++)
                {
                    if ((int)syncItemErrors.GetValue(i) != 0)
                    {
                        continue;
                    }
                    OpcTag tag = tagNames.First(o => o.ServerHandle == validTags[i - 1].ServerHandle);
                    if (tag == null)
                    {
                        continue;
                    }
                    tag.Value = syncItemValues.GetValue(i).ToString();
                    tag.Quality = OpcQuality((short)((Array)itemQualities).GetValue(i));
                    tag.TimeStamp = (DateTime)((Array)itemTimeStamps).GetValue(i);
                }
            }
           
            finally
            {
                if (connectedGroup != null)
                {
                    if (syncItemServerHandles != null && syncItemServerHandles.Length > 1)
                    {
                        Array removeServerErrors;
                        connectedGroup.OPCItems.Remove(syncItemServerHandles.Length - 1, ref syncItemServerHandles, out removeServerErrors);
                    }
                    mOpcServer.OPCGroups.Remove(groupName);
                }
                Disconnect();
            }
            return tagNames;
        }

        public override OpcTag ReadTagExt(OpcTag tag)
        {
            throw new NotImplementedException();
        }
        public override IList<OpcTag> ReadTagsExt(IList<OpcTag> tagNames)
        {
            throw new NotImplementedException();

        }

        public bool ReadTagContinuously(OpcTag tag, string node, DataChanged onDataChanged, object callbackData = null, double deadBand = 0)
        {
            var tags = new List<OpcTag> { tag };
            return ReadTagsContinuously(tags, node, onDataChanged, callbackData, deadBand);
        }

        public bool ReadTagsContinuously(IList<OpcTag> tags, string node, DataChanged onDataChanged, object callbackData = null, double deadBand = 0)
        {
            node = node + Guid.NewGuid();
            Log.InfoFormat("Adding group : {0}", node);
            bool addedSuccessfully = false;
            try
            {
                if (mOpcServer.ServerState == (int)OPCServerState.OPCDisconnected)
                {
                    if (!Connect())
                    {
                        return addedSuccessfully;
                    }
                    mOpcServer.OPCGroups.DefaultGroupIsActive = true;
                    mOpcServer.OPCGroups.DefaultGroupDeadband = 0;
                }

                OPCGroup connectedGroup = mOpcServer.OPCGroups.Add(node);
                connectedGroup.IsSubscribed = true;
                connectedGroup.DeadBand = (float)deadBand;
                Array opcItems = new string[tags.Count + 1];
                Array clientHandles = new int[tags.Count + 1];
                for (int i = 0; i < tags.Count; i++)
                {
                    opcItems.SetValue(String.Format(mRslinxItemFormat, tags[i].Topic, tags[i].Address), i + 1);
                    clientHandles.SetValue(i + 1, i + 1);
                }
                Array serverHandles;
                Array serverErrors;
                connectedGroup.OPCItems.AddItems(tags.Count, opcItems, ref clientHandles, out serverHandles, out serverErrors);
                for (int i = 1; i <= serverErrors.Length; i++)
                {
                    tags[i - 1].IsValid = (int)serverErrors.GetValue(i) == 0;
                    tags[i - 1].ClientHandle = (int)clientHandles.GetValue(i);
                    tags[i - 1].ServerHandle = (int)serverHandles.GetValue(i);
                }
                OpcTag[] validTags = tags.Where(s => s.IsValid).ToArray();
                if (validTags.Count() == tags.Count)
                {
                    Array syncItemServerHandles = new int[validTags.Count() + 1];
                    Array removeServerHandles = new int[validTags.Count() + 1];
                    for (int i = 1; i <= validTags.Count(); i++)
                    {
                        syncItemServerHandles.SetValue(validTags[i - 1].ServerHandle, i);
                        removeServerHandles.SetValue(validTags[i - 1].ServerHandle, i);
                    }

                    connectedGroup.DataChange += (int id, int items, ref Array handles, ref Array values, ref Array qualities, ref Array stamps) => connectedGroup_DataChange(handles, values, qualities, stamps, tags, onDataChanged, callbackData);
                    addedSuccessfully = true;
                    mConnectedGroups.Add(node, connectedGroup);
                    Log.InfoFormat("Added group successfully : {0}", node);
                }
                else
                {
                    Log.ErrorFormat("Failed to add the gorup {0}", node);
                    //Log the invalid tags
                    Log.ErrorFormat(string.Empty);
                }
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Failed to add group  : {0} with error {1}", node, ex);
                addedSuccessfully = false;
            }
            return addedSuccessfully;
        }

        private void connectedGroup_DataChange(Array clientHandles, Array itemValues, Array qualities, Array timeStamps, IList<OpcTag> tags, DataChanged onDataChanged, object callbackData)
        {
            for (int i = 1; i <= clientHandles.Length; i++)
            {
                int index = i;
                OpcTag tag = tags.First(t => t.ClientHandle == (int)clientHandles.GetValue(index));
                tag.Value = itemValues.GetValue(index).ToString();
                tag.TimeStamp = (DateTime)timeStamps.GetValue(index);
                tag.Quality = OpcQuality((int)qualities.GetValue(i));
            }
            for (int i = 1; i <= tags.Count; i++)
            {
                tags[i - 1].IsModified = IsTagModified(i, clientHandles);
            }
            onDataChanged(tags, callbackData);

            if (callbackData.GetType().Name == "Washer")
            {
                Washer washer = (Washer)callbackData;

                OpcDataWriter allenBradleyDataWriter = new OpcDataWriter(AllenBradleyController, mRslinxItemFormat);

                var rata = tags.FirstOrDefault(opc => opc.TagType == "Tag_RATA");
                if (rata != null && rata.Value == "1" && RatioDosingActive == 1) //RatioDosingActive is an configurable parameter from app settings
                {
                    var formula = tags.FirstOrDefault(opc => opc.TagType == "Tag_FRM");
                    var aweww = tags.FirstOrDefault(opc => opc.TagType == "Tag_AWEW");
                    IEnumerable<global::Entities.DataReader.RatioDosing> lRatioDosingInputs = Access.DataReader.DataReaderAccess.GetActiveSWbyWasherIdAndFormula(washer.WasherId, Convert.ToInt32(formula.Value));
                    OpcTag tagsRd = (OpcTag)tags.FirstOrDefault(opc => opc.TagType == "Tag_RATP");
                    List<OpcTag> lopctags = new List<OpcTag>();
                    if (aweww != null)
                    {
                        int actualWeight = Convert.ToInt32(aweww.Value);

                        if (actualWeight != 0 && lRatioDosingInputs != null && tagsRd != null)
                        {
                            var dosing = lRatioDosingInputs.FirstOrDefault();
                            if (dosing != null)
                            {
                                tagsRd.Value =
                                    Convert.ToString(
                                        Convert.ToInt32((actualWeight /
                                                         dosing.StandardWeight) * 10000));
                            }
                        }
                    }
                    lopctags.Add(tagsRd);
                    allenBradleyDataWriter.WriteTags(lopctags);
                }
            }

        }

        private static bool IsTagModified(int itemIndex, Array clientHandles)
        {
            bool isModified = false;
            for (int i = 1; i <= clientHandles.Length; i++)
            {
                if ((int)clientHandles.GetValue(i) != itemIndex)
                {
                    continue;
                }
                isModified = true;
                break;
            }
            return isModified;
        }

        private static string OpcQuality(int p)
        {
            switch (p)
            {
                case 192:
                    return "Good";
                case 64:
                    return "UnCertain";
                default:
                    return "Bad";
            }
        }

        private static string OpcQuality(short quality)
        {
            switch (quality)
            {
                case 192:
                    return "Good";
                case 64:
                    return "UnCertain";
                default:
                    return "Bad";
            }
        }

        public bool Shutdown()
        {
            bool isShutdownSuccessfull = true;
            foreach (KeyValuePair<string, OPCGroup> connectedGroup in mConnectedGroups)
            {
                try
                {
                    Log.InfoFormat("Removing group {0}", connectedGroup.Key);
                    mOpcServer.OPCGroups.Remove(connectedGroup.Key);
                }
                catch (Exception ex)
                {
                    isShutdownSuccessfull = false;
                    Log.ErrorFormat("Failed to remove the group {0} with error {1}", connectedGroup.Key, ex);
                }
            }
            try
            {

                if (mOpcServer.ServerName != null)
                {
                    Log.InfoFormat("Disconnecting connection to {0}", mOpcServer.ServerName);
                    mOpcServer.Disconnect();
                }
            }
            catch (Exception ex)
            {
                isShutdownSuccessfull = false;
                Log.ErrorFormat("Failed to disconnect from the server {0} with error {1}", mOpcServer.ServerName, ex);
            }
            return isShutdownSuccessfull;
        }

        public void Deregister(string entityName)
        {
            for (int index = 0; index < mConnectedGroups.Count; index++)
            {
                string group = null;
                try
                {
                    var item = mConnectedGroups.ElementAt(index);
                    group = item.Key;
                    if (group.Contains(entityName))
                    {
                        mOpcServer.OPCGroups.Remove(group);
                        mConnectedGroups.Remove(group);
                    }
                }
                catch (Exception ex)
                {
                    Log.ErrorFormat("Failed to remove the group {0} with error {1}", group, ex);
                }
            }
        }

        public void DeregisterController()
        {
            for (int index = 0; index < mConnectedGroups.Count; index++)
            {
                string group = null;
                try
                {
                    var item = mConnectedGroups.ElementAt(index);
                    group = item.Key;
                    mOpcServer.OPCGroups.Remove(group);
                    mConnectedGroups.Remove(group);
                    index--;
                }
                catch (Exception ex)
                {
                    Log.ErrorFormat("Failed to remove the group {0} with error {1}", group, ex);
                }
            }
        }

        public override object ReadArrayTags()
        {
            throw new NotImplementedException();
        }

        public override int ReadArrayPos(int pos)
        {
            throw new NotImplementedException();
        }
    }
}