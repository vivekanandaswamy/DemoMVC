﻿// -----------------------------------------------------------------------
// <copyright file="TagProcessor.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The TagProcessor </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Dcs.PlcDataReader
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Threading;
    using System.Xml;
    using System.Xml.Serialization;
    using Access.DataReader;
    using Ecolab.Dcs.CollectData;
    using Entities;
    using log4net;
    using Nalco.Numerics.SI;
    using Properties;

    /// <summary>
    /// Class for TagProcessor
    /// </summary>
    public class TagProcessor
    {
        private static readonly ILog Log = LogManager.GetLogger(typeof(TagProcessor));

        private List<Tuple<int, string, string>> length = new List<Tuple<int, string, string>>();

        public static void ProcessNowTags<T>(IEnumerable<T> tags, object callbackData) where T : new()
        {
            var opcTag = (IEnumerable<Tag>)tags;
            IEnumerable<Tag> opcTags = opcTag as IList<Tag> ?? opcTag.ToList();
            string xml = SerializeTags(opcTags);
            try
            {
                Controller controller = (Controller)callbackData;
                DataReaderAccess.ProcessNowTags(controller.ControllerId, xml);
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Unable to process xml data {0} due to error {1} ", xml, ex);
            }
            Log.Info(xml);
        }

        //This function will be called for AllenBradley
        public static void ProcessWasherTags<T>(IEnumerable<T> tags, object callbackData) where T : new()
        {
            try
            {
                Washer washer = (Washer)callbackData;
                var opcTag = (IEnumerable<Tag>)tags;
                IEnumerable<Tag> opcTags = opcTag as IList<Tag> ?? opcTag.ToList();
                if (!RequiredTagsModified(opcTags))
                {
                    return;
                }
                // Process ETech TotalWeight...................
                var thread = new Thread(() => ProcessEtechWeight(opcTags, washer));
                thread.Start();
                }
            catch (Exception ex)
            {
                Log.ErrorFormat("Unable to process tags data {0} due to error {1} ", tags, ex);
            }
        }

        //This function is called for Beckoff and Webport
        public static void ProcessWasherBatchTags<T>(IEnumerable<T> tags, object callbackData) where T : new()
        {
            try
            {
                Washer washer = (Washer)callbackData;
                int RedFlagShiftId = 0;

                var opcTag = (IEnumerable<Tag>)tags;
                IEnumerable<Tag> opcTags = opcTag as IList<Tag> ?? opcTag.ToList();
                if (!RequiredTagsModified(opcTags))
                {
                    return;
                }

                if (washer.IsTunnel)
                {
                    Tunnel tunnel = ProcessTunnelWasherTags(opcTags, washer);
                    string tunnelXml = SerializeTunnel(tunnel);
                    Log.InfoFormat("Processing Tunnel Washer : {0} with XML : {1}", washer.WasherId, tunnelXml);
                    RedFlagShiftId = DataReaderAccess.ProcessTunnelWasherTags(washer.WasherId, tunnelXml, RedFlagShiftId);

                }
                else
                {
                    string convXml = SerializeTags(opcTags);
                    Log.InfoFormat("Processing Conv Washer : {0} with XML : {1}", washer.WasherId, convXml);
                    RedFlagShiftId = DataReaderAccess.ProcessWasherTags(washer.WasherId, convXml, RedFlagShiftId);
                }

                if (RedFlagShiftId > 0)
                {
                    DataReaderAccess.ProcessRedFlagData(RedFlagShiftId);
                }
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Unable to process tags data {0} due to error {1} ", tags, ex);
            }
        }

        private static bool RequiredTagsModified(IEnumerable<Tag> tags)
        {
            return tags.Where(opcTag => opcTag.TagType == "Tag_FRM" || opcTag.TagType == "Tag_INJ" || opcTag.TagType == "Tag_OPC" || opcTag.TagType == "Tag_HOLDL" || opcTag.TagType == "Tag_MPLC").Any(opcTag => opcTag.IsModified);
        }

        public static void ProcessModuleTags<T>(IEnumerable<T> tags, object callbackData) where T : new()
        {
            try
            {
                Module module = (Module)callbackData;
                //First tag will have the value

                var opcTag = (IEnumerable<Tag>)tags;
                IEnumerable<Tag> opcTags = opcTag as IList<Tag> ?? opcTag.ToList();

                Tag readingTag = opcTags.First();

                double usage;
                double readingValue= Convert.ToDouble(readingTag.Value);
                double prevreadingValue;

                // Get the previous reading from module reading......
                prevreadingValue = CommonDataOperations.GetPreviousReading(module.ModuleId,module.ModuleTypeId);
                usage = readingValue - prevreadingValue;//430800.0000
                // Get the difference between current reading and previous reading
                if (usage >= 0)
                {
                    usage = GetUomReading(module.Unit, module.Calibration, Convert.ToString(usage), module.UtilityType);
                }
                else
                {
                    // Consider Rollover point here....
                    double readingValue1 = module.RollOverPoint - prevreadingValue;
                    readingValue = readingValue1 + readingValue;
                    usage = GetUomReading(module.Unit, module.Calibration, Convert.ToString(readingValue), module.UtilityType);

                }

                Log.InfoFormat("ProcessModuleTags : ModuleId-{0} : ModuleTypeId-{1} : Current Reading-{2} : Previous Reading-{3} : TimeStamp-{4} : RollOverPoint-{5} : Usage-{6} : TagAddress-{7} ", module.ModuleId,module.ModuleTypeId, Convert.ToDouble(readingTag.Value),prevreadingValue, readingTag.TimeStamp,module.RollOverPoint,usage,readingTag.Address);
                if ((module.ModuleTypeId == 2 || module.ModuleTypeId == 1) && Convert.ToDouble(readingTag.Value) == 0d)
                {
                    Log.InfoFormat("Skipping the zero reading for meter : ModuleId-{0} : Current Reading-{1}", module.ModuleId,readingTag.Value);
                }
                else
                {
                    DataReaderAccess.ProcessModuleTags(module.ModuleId, module.ModuleTypeId, Convert.ToDouble(readingTag.Value), readingTag.TimeStamp, module.RollOverPoint, usage);
                }
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Unable to process data {0} due to error {1} ", tags, ex);
            }
        }

        private static double GetUomReading(string unit,decimal Calibration,string tagvalue,string UtilityType)
        {
            double readingValue;
            switch (unit)
            {
                    case "cubic_foot":

                    if (UtilityType == "1")
                        {
                        readingValue = Calibration != 0
                            ? Convert.ToDouble(tagvalue) * double.Parse(Calibration.ToString(CultureInfo.InvariantCulture)) * 0.01
                            : Convert.ToDouble(tagvalue) * 0.01;
                        }
                        else
                        {
                        readingValue = Calibration != 0
                            ? Convert.ToDouble(tagvalue) * double.Parse(Calibration.ToString(CultureInfo.InvariantCulture)) * 7.48052
                            : Convert.ToDouble(tagvalue) * 7.48052;
                        }
                        break;
                    case "KwH":
                    readingValue = Convert.ToDouble(tagvalue);
                        break;
                    case "kilo_gallon":
                    readingValue = Calibration != 0
                        ? Convert.ToDouble(tagvalue) * 1000 * double.Parse(Calibration.ToString(CultureInfo.InvariantCulture))
                        : Convert.ToDouble(tagvalue) * 1000;
                        break;
                    case "liter":
                    readingValue = Convert.ToDouble(tagvalue) * 0.264172; // To convert to Gallons
                        break;
                    case "kilogram":
                    readingValue = Convert.ToDouble(tagvalue) * 2.20462; // To convert to Pounds
                        break;
                    case "deca_therm":
                    readingValue = Convert.ToDouble(tagvalue) * 10; // To convert to Therms
                        break;
                    case "btu":
                    readingValue = Convert.ToDouble(tagvalue) * 0.0000100023877; // To convert to Therms
                        break;
                    case "cubic_meter":
                    if (UtilityType == "1")
                        {
                            // To convert to Therms
                        readingValue = Calibration != 0
                               ? Convert.ToDouble(tagvalue) * double.Parse(Calibration.ToString(CultureInfo.InvariantCulture)) * 0.3639924
                               : Convert.ToDouble(tagvalue) * 0.3639924;
                        }
                        else
                        {
                            // To convert to Gallons
                        readingValue = Calibration != 0
                            ? Convert.ToDouble(tagvalue) * 264.172 * double.Parse(Calibration.ToString(CultureInfo.InvariantCulture))
                            : Convert.ToDouble(tagvalue) * 264.172;
                        }                        
                        break;
                    case "minute":
                    readingValue = Convert.ToDouble(tagvalue);
                        break;
                    case "hour":
                    readingValue = Convert.ToDouble(tagvalue) * 60; // To Convert to Mins
                        break;
                    case "Celsius":
                    readingValue = (Convert.ToDouble(tagvalue) * 9) / 5 + 32; // To Convert to Fahrenheit
                        break;
                    case "gallon_per_day":
                    readingValue = Convert.ToDouble(tagvalue) * 1440; // To Convert to Gallons per min
                        break;
                    case "cubic_foot_per_hour":
                    readingValue = Convert.ToDouble(tagvalue) * 7.48052 * 60; // To Convert to Gallons per min
                        break;
                    case "cubic_meter_per_hour":
                    readingValue = Convert.ToDouble(tagvalue) * 264.172 * 60; // To Convert to Gallons per min
                        break;
                    case "cubic_meter_per_second":
                    readingValue = Convert.ToDouble(tagvalue) * 264.172 / 60; // To Convert to Gallons per min
                        break;
                    case "cubic_meter_per_minute":
                    readingValue = Convert.ToDouble(tagvalue) * 264.172; // To Convert to Gallons per min
                        break;
                    case "cubic_meter_per_day":
                    readingValue = Convert.ToDouble(tagvalue) * 264.172 * 1440; // To Convert to Gallons per min
                        break;
                    case "liter_per_hour":
                    readingValue = Convert.ToDouble(tagvalue) * 0.264172 * 60; // To Convert to Gallons per min
                        break;
                    case "parts_per_million":
                    readingValue = Convert.ToDouble(tagvalue) * 0.058; // To Convert to Grains
                        break;
                    case "gallon":
                    readingValue = Calibration != 0
                        ? Convert.ToDouble(tagvalue) *
                          double.Parse(Calibration.ToString(CultureInfo.InvariantCulture))
                        : Convert.ToDouble(tagvalue);
                        break;
                    default:
                    readingValue = Convert.ToDouble(tagvalue);
                        break;
                }

            return readingValue;
        }
        private static Tunnel ProcessTunnelWasherTags(IEnumerable<Tag> tags, Washer washer)
        {
            IEnumerable<Tag> enumerable = tags as IList<Tag> ?? tags.ToList();
            var opcTags = tags as Tag[] ?? enumerable.ToArray();
            Tunnel tunnel = new Tunnel
            {
                Id = washer.WasherId,
                CurrentFormula = opcTags.Any(t => t.TagType != null && t.TagType == "Tag_FRM") ? Convert.ToInt32(opcTags.First(t => t.TagType != null && t.TagType == "Tag_FRM").Value) : 0,
                CurrentInjection = opcTags.Any(t => t.TagType != null && t.TagType == "Tag_INJ") ? Convert.ToInt32(opcTags.First(t => t.TagType != null && t.TagType == "Tag_INJ").Value) : 0,
                CurrentOperationCounter = opcTags.Any(t => t.TagType != null && t.TagType == "Tag_OPC") ? Convert.ToInt32(opcTags.First(t => t.TagType != null && t.TagType == "Tag_OPC").Value) : 0,
                Eof = opcTags.Any(t => t.TagType != null && t.TagType == "Tag_EOF") ? Convert.ToInt32(opcTags.First(t => t.TagType != null && t.TagType == "Tag_EOF").Value) : 0,
                OnHold = opcTags.Any(t => t.TagType != null && t.TagType == "Tag_HOLDL") && opcTags.First(t => t.TagType != null && t.TagType == "Tag_HOLDL").Value != "0",

                TimeStamp = opcTags.Any(t => t.TagType != null && t.TagType == "Tag_FRM") ? opcTags.First(t => t.TagType != null && t.TagType == "Tag_FRM").TimeStamp : DateTime.UtcNow,
                IsFormulaModified = opcTags.Any(t => t.TagType != null && t.TagType == "Tag_FRM") && enumerable.Where(opcTag => opcTag.TagType != null && opcTag.TagType == "Tag_FRM").Any(opcTag => opcTag.IsModified),
                IsHoldSignalModified = opcTags.Any(t => t.TagType != null && t.TagType == "Tag_HOLDL") && enumerable.Where(opcTag => opcTag.TagType != null && opcTag.TagType == "Tag_HOLDL").Any(opcTag => opcTag.IsModified)
            };
            if (opcTags.Any(t => t.TagType != null && t.TagType == "Tag_AWEA"))
            {
                tunnel.Awea = Convert.ToBoolean(opcTags.First(t => t.TagType == "Tag_AWEA").Value);
                tunnel.Awew = int.Parse(opcTags.First(t => t.TagType != null && t.TagType == "Tag_AWEW").Value);
                tunnel.RATA = int.Parse(opcTags.First(t => t.TagType != null && t.TagType == "Tag_RATA").Value);
            }
            if (opcTags.Any(t => t.TagType != null && t.TagType == "Tag_RATA"))
            {
                tunnel.RATA = int.Parse(opcTags.First(t => t.TagType != null && t.TagType == "Tag_RATA").Value);
            }
            var compartments = new List<Compartment>();
            for (int i = 0; i < 20; i++)
            {
                compartments.Add(new Compartment { CompartmentId = i + 1, FormulaId = Convert.ToInt32(opcTags.First(t => t.TagType == string.Format("Formula_Mod_{0}", i + 1)).Value), LoadId = Convert.ToInt32(opcTags.First(t => t.TagType == string.Format("Load_Mod_{0}", i + 1)).Value), TimeStamp = opcTags.First(t => t.TagType == string.Format("Formula_Mod_{0}", i + 1)).TimeStamp });
            }
            tunnel.Comparments = compartments;
            return tunnel;
        }

        private static string SerializeTags(IEnumerable<Tag> tags)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(TagCollection));
            TagCollection vtags = new TagCollection { Tags = new List<Tag>(tags) };
            StringWriter stringWriter = new StringWriter();
            using (XmlWriter xmlWriter = new XmlTextWriter(stringWriter))
            {
                xmlSerializer.Serialize(xmlWriter, vtags);
                return stringWriter.ToString();
            }
        }

        private static string SerializeTunnel(Tunnel tunnel)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(Tunnel));
            StringWriter stringWriter = new StringWriter();
            using (XmlWriter xmlWriter = new XmlTextWriter(stringWriter))
            {
                xmlSerializer.Serialize(xmlWriter, tunnel);
                return stringWriter.ToString();
            }
        }

        public double ConvertToUnit(string unit, string sourceUnit, string destinationUnit, double paramValue)
        {
            sourceUnit = sourceUnit.Trim();
            destinationUnit = destinationUnit.Trim();
            double result = 0.0;
            switch (unit)
            {
                case "Volume":
                    length = Volume.Conversions.GetSubunits();
                    result = Volume.Conversions.Convert(paramValue, GetUnitNumber(sourceUnit), GetUnitNumber(destinationUnit));
                    break;
                case "Temperature":
                    length = Temperature.Conversions.GetSubunits();
                    result = Temperature.Conversions.Convert(paramValue, GetUnitNumber(sourceUnit), GetUnitNumber(destinationUnit));
                    break;
                case "Time":
                    length = Time.Conversions.GetSubunits();
                    result = Time.Conversions.Convert(paramValue, GetUnitNumber(sourceUnit), GetUnitNumber(destinationUnit));
                    break;
            }
            return result;
        }

        private int GetUnitNumber(string abbreviation)
        {
            if (string.IsNullOrWhiteSpace(abbreviation))
            {
                return 0;
            }
            abbreviation = abbreviation.Trim();
            Tuple<int, string, string> tpl = length.FirstOrDefault(x => x.Item2 == abbreviation);
            return tpl != null ? tpl.Item1 : 0;
        }

		/// <summary>
		///     GetTunnelStatus
		/// </summary>
		/// <param name="washerId">fetching data through washer id</param>
		/// <returns>returns a list.</returns>
		public static Queue<BeckhoffQueueItem> GetTunnelStatus(int washerId)
		{
			var compartments = DataReaderAccess.GetTunnelStatus(washerId);
			Queue<BeckhoffQueueItem> queue = new Queue<BeckhoffQueueItem>();
			foreach(var comp in compartments.Reverse())
			{
				queue.Enqueue(new BeckhoffQueueItem
				{
					FormulaId = comp.ProgramNumber,
					LoadId = comp.ControllerBatchId,
					TimeStamp = comp.StartTime
				});
			}
			return queue;
		}

        private static void ProcessEtechWeight(IEnumerable<Tag> opcTags, Washer lwasher)
        {
            try
            {
                //check if Etech is enabled in the plant
                if (lwasher.AWEAActive && lwasher.ETechWasherNumber > 0)
                {
                    bool ETechEnable = false;
                    string ETechIPAddress = string.Empty;
                    string EtechCustomerCodesText = string.Empty;

                    #region Get Plant Details
                    global::Entities.Plant plantInfo = DataReaderAccess.GetPlantInfo();
                    EtechCustomerCodesText = DataReaderAccess.GetETechConfigSettings();
                    if (plantInfo != null)
                    {
                        ETechEnable = plantInfo.IsETechEnable;
                        ETechIPAddress = plantInfo.EtechIpAddress;
                    }
                    #endregion

                    if (ETechEnable)
                    {
                        var FRM = int.Parse(opcTags.First(t => t.TagType != null && t.TagType == "Tag_FRM").Value);
                        var OPC = int.Parse(opcTags.First(t => t.TagType != null && t.TagType == "Tag_OPC").Value);
                        var INJ = int.Parse(opcTags.First(t => t.TagType != null && t.TagType == "Tag_INJ").Value);

                        if (FRM > 0 && OPC == 0 && INJ == 0)
                        {
                            string ETechURL = string.Format(Settings.Default.ETechURL, ETechIPAddress, lwasher.ETechWasherNumber);
                            //string ETechURL = ETechIPAddress + "/" + Convert.ToString(lwasher.ETechWasherNumber);

                            DFLastDropped ETechdata = CommonDataOperations.GetETechTotalWeight(ETechURL, EtechCustomerCodesText);
                            if (ETechdata != null && ETechdata.record.Count > 0 && Convert.ToInt32(ETechdata.record[0].totalWeight) > 0)
                            {
                                if (opcTags.Any(t => t.TagType != null && t.TagType == "Tag_AWEW"))
                                {
                                    var AWEW = opcTags.First(t => t.TagType == "Tag_AWEW");
                                    AWEW.Value = ETechdata.record[0].totalWeight;
                                    AWEW.ETechLastDroppedAt = DateTime.Parse(ETechdata.record[0].lastDroppedAt).ToUniversalTime().ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss");
                                    AWEW.CustomerCodes = ETechdata.record[0].customerCodes;
                                }
                                else
                                {
                                    string AWEWAddress = string.Empty;
                                    if (lwasher.Tags.Any(t => t.TagType != null && t.TagType == "Tag_AWEW"))
                                    {
                                        AWEWAddress = lwasher.Tags.First(t => t.TagType == "Tag_AWEW").Address;
                                    }
                                    var AWEWTagTimeStamp = opcTags.First(t => t.TagType != null && t.TagType == "Tag_FRM").TimeStamp;
                                    //Convert to list.
                                    List<Tag> list = opcTags.ToList();
                                    //Add new item to list.
                                    list.Add(new OpcTag { Address = AWEWAddress, Value = ETechdata.record[0].totalWeight, TimeStamp = AWEWTagTimeStamp, TagType = "Tag_AWEW", TagId = 0, IsModified = true, Quality = "Good", ETechLastDroppedAt = DateTime.Parse(ETechdata.record[0].lastDroppedAt).ToUniversalTime().ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss"), CustomerCodes=ETechdata.record[0].customerCodes });
                                    opcTags = (IEnumerable<Tag>)list;
                                }
                                if (opcTags.Any(t => t.TagType != null && t.TagType == "Tag_AWEA"))
                                {
                                    var AWEA = opcTags.First(t => t.TagType == "Tag_AWEA");
                                    AWEA.Value = "1";
                                }
                                else
                                {
                                    string AWEAAddress = string.Empty;
                                    if (lwasher.Tags.Any(t => t.TagType != null && t.TagType == "Tag_AWEA"))
                                    {
                                        AWEAAddress = lwasher.Tags.First(t => t.TagType == "Tag_AWEA").Address;
                                    }
                                    var AWEATagTimeStamp = opcTags.First(t => t.TagType != null && t.TagType == "Tag_FRM").TimeStamp;
                                    //Convert to list.
                                    List<Tag> list = opcTags.ToList();
                                    //Add new item to list.
                                    list.Add(new OpcTag { Address = AWEAAddress, Value = "1", TimeStamp = AWEATagTimeStamp, TagType = "Tag_AWEA", TagId = 0, IsModified = true, Quality = "Good" });
                                    opcTags = (IEnumerable<Tag>)list;
                                }
                            }
                        }
                    }
                }
                else
                {
                    Log.InfoFormat("Check AWEA/EtechWasherNumber parameter(s) for washer ID:{0}", Convert.ToString(lwasher.WasherId));
                }
                int RedFlagShiftId = 0;
                if (lwasher.IsTunnel)
                {
                    Tunnel tunnel = ProcessTunnelWasherTags(opcTags, lwasher);
                    string tunnelXml = SerializeTunnel(tunnel);
                    Log.InfoFormat("Processing Tunnel Washer : {0} with XML : {1}", lwasher.WasherId, tunnelXml);
                    RedFlagShiftId = DataReaderAccess.ProcessTunnelWasherTags(lwasher.WasherId, tunnelXml, RedFlagShiftId);
                }
                else
                {
                    string convXml = SerializeTags(opcTags);
                    Log.InfoFormat("Processing Conv Washer : {0} with XML : {1}", lwasher.WasherId, convXml);

                    //Code for handling INJ and OPC reset scenario - start
                    Tag inj = null;
                    Tag opc = null;
                    Tag nowMessage = null;

                    if (opcTags.Any(t => t.TagType != null && t.TagType == "Tag_INJ"))
                    {
                        inj = opcTags.First(t => t.TagType == "Tag_INJ");                       
                    }
                    if (opcTags.Any(t => t.TagType != null && t.TagType == "Tag_OPC"))
                    {
                        opc = opcTags.First(t => t.TagType == "Tag_OPC");
                    }
                    if (opcTags.Any(t => t.TagType != null && t.TagType == "NowMessage"))
                    {
                        nowMessage = opcTags.First(t => t.TagType == "NowMessage");
                    }
                    if (inj != null && inj.Value == "0" && inj.TimeStamp == nowMessage.TimeStamp)
                    {
                        Log.InfoFormat("Notification: INJ/OPC {0} reset and alarm {1} received at the same timestamp {2}", inj.Address, Convert.ToInt32(nowMessage.Value), nowMessage.TimeStamp);
                        int machineInternalId = CommonDataOperations.GetMachineInternalIdByWasherId(lwasher.WasherId);
                        if (!TagProcessor.ValidAlarmToExcludeForInjectionAndOPCReset(machineInternalId, Convert.ToInt32(nowMessage.Value), 1))
                        {
                            RedFlagShiftId = DataReaderAccess.ProcessWasherTags(lwasher.WasherId, convXml, RedFlagShiftId);
                        }
                        else
                        {
                            //Received valid alarm at INJ and OPC reset so ignoring them by not processing it.
                            Log.InfoFormat("Notification: Ignoring INJ/OPC {0} reset because alarm {1} received at the same timestamp {2}", inj.Address, Convert.ToInt32(nowMessage.Value), nowMessage.TimeStamp);
                        }
                    }
                    //Code for handling INJ and OPC reset scenario - end
                    else
                    {                        
                        RedFlagShiftId = DataReaderAccess.ProcessWasherTags(lwasher.WasherId, convXml, RedFlagShiftId);
                    }
                }

                ProcessRollup processRollup = new ProcessRollup();
                processRollup.Rollup();

                if (RedFlagShiftId > 0)
                {
                    DataReaderAccess.ProcessRedFlagData(RedFlagShiftId);
                }
            }
            catch (Exception ex)
            {
                Log.Error("Error occured: ProcessEtechWeight: ", ex);
            }
        } //End of ProcessEtechWeight function

        /// <summary>
		///     ValidAlarmToExcludeForInjectionAndOPCReset
		/// </summary>
		/// <param name="plantWasherNumber">plantWasherNumber</param>
        /// <param name="alarmCode">alarmCode</param>
        /// <param name="plcType">plc type 1. AllenBradley and 2. Beckhoff</param>
		/// <returns>returns a list.</returns>
        public static bool ValidAlarmToExcludeForInjectionAndOPCReset(int plantWasherNumber, int alarmCode, int plcType)
        {
            //plcType 1 = AllenBradley and 2 = Beckhoff
            bool alarmFound = false;
            switch (plantWasherNumber)
            {
                case 1:
                    if (alarmCode == 1 || alarmCode == 2 || alarmCode == 8 || alarmCode == 211 || alarmCode == 240)
                        alarmFound = true;
                    break;
                case 2:
                    if (alarmCode == 10 || alarmCode == 11 || alarmCode == 16 || alarmCode == 212 || alarmCode == 241)
                        alarmFound = true;
                    break;
                case 3:
                    if (alarmCode == 20 || alarmCode == 21 || alarmCode == 26 || alarmCode == 213 || alarmCode == 242)
                        alarmFound = true;
                    break;
                case 4:
                    if (alarmCode == 30 || alarmCode == 31 || alarmCode == 36 || alarmCode == 214 || alarmCode == 243)
                        alarmFound = true;
                    break;
                case 5:
                    if (alarmCode == 40 || alarmCode == 41 || alarmCode == 46 || alarmCode == 215 || alarmCode == 244)
                        alarmFound = true;
                    break;
                case 6:
                    if (alarmCode == 50 || alarmCode == 51 || alarmCode == 56 || alarmCode == 216 || alarmCode == 245)
                        alarmFound = true;
                    break;
                case 7:
                    if (alarmCode == 60 || alarmCode == 61 || alarmCode == 66 || alarmCode == 217 || alarmCode == 246)
                        alarmFound = true;
                    break;
                case 8:
                    if (alarmCode == 70 || alarmCode == 71 || alarmCode == 76 || alarmCode == 218 || alarmCode == 247)
                        alarmFound = true;
                    break;
                case 9:
                    if (alarmCode == 80 || alarmCode == 81 || alarmCode == 86 || alarmCode == 219 || alarmCode == 248)
                        alarmFound = true;
                    break;
                case 10:
                    if (alarmCode == 90 || alarmCode == 91 || alarmCode == 96 || alarmCode == 220 || alarmCode == 249)
                        alarmFound = true;
                    break;
                case 11:
                    if (alarmCode == 100 || alarmCode == 101 || alarmCode == 106 || alarmCode == 221 || alarmCode == 250)
                        alarmFound = true;
                    break;
                case 12:
                    if (alarmCode == 110 || alarmCode == 111 || alarmCode == 116 || alarmCode == 222 || alarmCode == 251)
                        alarmFound = true;
                    break;
                case 13:
                    if (plcType == 1 && (alarmCode == 223 || alarmCode == 252))
                    {
                        alarmFound = true;
                    }
                    else if (plcType == 2 && (alarmCode == 223 || alarmCode == 252 || alarmCode == 300 || alarmCode == 301 || alarmCode == 306))
                    {
                        alarmFound = true;
                    }
                    break;
                case 14:
                    if (plcType == 1 && (alarmCode == 224 || alarmCode == 253))
                    {
                        alarmFound = true;
                    }
                    else if (plcType == 2 && (alarmCode == 224 || alarmCode == 253 || alarmCode == 310 || alarmCode == 311 || alarmCode == 316))
                    {
                        alarmFound = true;
                    }
                    break;
                case 15:
                    if (plcType == 1 && (alarmCode == 225 || alarmCode == 254))
                    {
                        alarmFound = true;
                    }
                    else if (plcType == 2 && (alarmCode == 225 || alarmCode == 254 || alarmCode == 320 || alarmCode == 321 || alarmCode == 326))
                    {
                        alarmFound = true;
                    }
                    break;
                case 16:
                    if (plcType == 1 && (alarmCode == 226 || alarmCode == 255))
                    {
                        alarmFound = true;
                    }
                    else if (plcType == 2 && (alarmCode == 226 || alarmCode == 255 || alarmCode == 330 || alarmCode == 331 || alarmCode == 336))
                    {
                        alarmFound = true;
                    }
                    break;
            }
            return alarmFound;
        }
	}
}