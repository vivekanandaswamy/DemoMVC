﻿// -----------------------------------------------------------------------
// <copyright file="ProcessRollup.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The ProcessRollup </summary>
// -----------------------------------------------------------------------

namespace Ecolab.Dcs.PlcDataReader
{
    using Access.DataReader;
    using Access.PlantSetup.ShiftLabor;
    using log4net;

    public class ProcessRollup
    {
        private static readonly ILog Log = LogManager.GetLogger(typeof(ProcessRollup));        

        public void Rollup()
        {
            int RedFlagShiftId = 0;
            int status = ShiftAccess.RollupDataForReports(ref RedFlagShiftId);
            if (RedFlagShiftId > 0)
            {
                DataReaderAccess.ProcessRedFlagData(RedFlagShiftId);
            }

        }        
    }
}
