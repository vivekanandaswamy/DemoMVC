﻿// -----------------------------------------------------------------------
// <copyright file="DataReader.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The DataReader </summary>
// -----------------------------------------------------------------------

using System;
using DbEntities = Entities.DataReader;

namespace Ecolab.Dcs.PlcDataReader
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using Access.DataReader;
    using Entities;
    using log4net;

    /// <summary>
    /// Class for DataReader
    /// </summary>
    public class DataReader
    {
        private static readonly ILog Log = LogManager.GetLogger(typeof(DataReader));
        private readonly OpcService mAllenBradleyService;
        private readonly WebPortService mWebPortService;
        private readonly BeckhoffXmlService mBeckhoffXmlService;
        private readonly MyControlService mMyControlService;
        private readonly PLCXLService mPLCXLService;
        private readonly EControlPlusService mEControlPlusService;

        /// <summary>
        /// Initializes a new instance of the <see cref="DataReader"/> class.
        /// </summary>
        /// <param name="cancellationTokenSource">The cancellation token source.</param>
        public DataReader(CancellationTokenSource cancellationTokenSource)
        {
            IEnumerable<DbEntities.Controller> dbControllers = DataReaderAccess.GetActiveControllers();
            List<Controller> controllers = dbControllers.Select(EntityConverter.Convert).ToList();
            try
            {
                mAllenBradleyService = new OpcService(controllers.FindAll(c => c is AllenBradleyController).Select(c => (AllenBradleyController)c).ToList());
                mAllenBradleyService.Start();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
            }

            try
            {
                mWebPortService = new WebPortService();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
            }

            try
            {
                mBeckhoffXmlService = new BeckhoffXmlService();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
            }

            try
            {
                mMyControlService = new MyControlService();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
            }

            try
            {
                mPLCXLService = new PLCXLService();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
            }
            try
            {
                mEControlPlusService = new EControlPlusService(cancellationTokenSource);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
            }
        }

        /// <summary>
        /// Stops this instance.
        /// </summary>
        internal void Stop()
        {
            mAllenBradleyService.Stop();
            mWebPortService.Stop();
            mBeckhoffXmlService.Stop();
            mMyControlService.Stop();
            mPLCXLService.Stop();
        }
    }
}