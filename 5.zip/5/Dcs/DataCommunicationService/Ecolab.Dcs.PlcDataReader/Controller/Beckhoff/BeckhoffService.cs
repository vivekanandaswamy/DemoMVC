﻿// -----------------------------------------------------------------------
// <copyright file="BeckhoffService.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The BeckhoffService </summary>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Timers;
using Access.DataReader;
using Ecolab.Dcs.CollectData.Beckhoff;
using Ecolab.Dcs.Entities;
using Ecolab.Dcs.PlcDataReader.Properties;
using Entities.DataReader;
using log4net;
using DbEntities = Entities.DataReader;
using Module = Ecolab.Dcs.Entities.Module;
using Timer = System.Timers.Timer;
using Washer = Entities.DataReader.Washer;

namespace Ecolab.Dcs.PlcDataReader
{
    public class BeckhoffService
    {
        private readonly List<BeckhoffController> beckhoffControllers;
        private readonly List<BeckhoffDataReader> beckhoffDataReaders = new List<BeckhoffDataReader>();
        private static readonly ILog Log = LogManager.GetLogger(typeof(BeckhoffService));
        private static readonly string MBeckhoffItemFormat = Settings.Default.BeckhoffItemFormat;

        public BeckhoffService(List<BeckhoffController> controllers)
        {
            beckhoffControllers = controllers;
        }

        public void Start()
        {
            Log.InfoFormat("Started Tracking AllenBradley {0} controller(s)", beckhoffControllers.Count);

            foreach (var controller in beckhoffControllers)
            {
                RegisterModuleTags(controller);
            }
        }

        #region <<<Commented>>>

        //private void RegisterWashers(BeckhoffController controller)
        //{
        //    if (string.IsNullOrEmpty(controller.AmsNetAddress))
        //    {
        //        Log.Error("IPAddress not defined. Unable to connect");
        //        return;
        //    }
        //    Log.Info("Strated reading values from Beckhoff -> " + controller);
        //    var beckhoffDataReader = new BeckhoffDataReader(controller, MBeckhoffItemFormat);
        //    var controllerWashersTags = DataReaderAccess.GetActiveWashers(controller.ControllerId);
        //    var results = controllerWashersTags.GroupBy(p => new { p.WasherId, p.WasherName, p.WasherGroupTypeName }).Select(g => new Entities.Washer
        //    {
        //        WasherId = g.Key.WasherId,
        //        Name = g.Key.WasherName,
        //        IsTunnel = g.Key.WasherGroupTypeName == "Tunnel",//TODO:Need to get this property from database.
        //        Tags = g.Select(m => new BeckhoffTag
        //        {
        //            Address = m.TagAddress,
        //            Topic = m.TopicName,
        //            TagType = m.TagType,
        //            TagTypeId = m.TagTypeId,
        //            TagId = m.TagId
        //        }).ToList<Tag>()
        //    });
        //    foreach (var washer in results)
        //    {
        //        Log.InfoFormat("Registering washer {0} tags", washer.WasherId);
        //        bool tracking = beckhoffDataReader.ReadTagsContinuously(!washer.IsTunnel ?
        //            washer.Tags.Select(t => (BeckhoffTag)t).ToList() :
        //            UpdateTunnelTags(washer.Tags.Select(t => (BeckhoffTag)t).ToList(), controller.TopicName), controller.AmsNetAddress, controller.Comport, TagProcessor.ProcessWasherTags, washer, true);

        //        if (!tracking)
        //        {
        //            Log.ErrorFormat("Unable to track the washer:{0}", washer);
        //        }
        //    }
        //    mBeckhoffDataReaders.Add(beckhoffDataReader);
        //}

        //private List<BeckhoffTag> UpdateTunnelTags(List<BeckhoffTag> list, string topicName)
        //{
        //    for (int i = 1; i <= 22; i++)
        //    {
        //        list.Add(new BeckhoffTag
        //        {
        //            Address = string.Format("STTUNNELCOMPARTMENTFIFO[{0}].FORMULA", i),
        //            TagType = string.Format("Formula_Mod_{0}", i),
        //            Topic = topicName
        //        });
        //    }

        //    return list;
        //}

        ///// <summary>
        /////     N7:150	Error Message #	int
        /////     N9:183	"Now" Washer	int
        /////     N9:181	"Now" Formula	int
        /////     N/A		"Now" Injection	int
        /////     N9:191	"Now" Valve		int
        ///// </summary>
        ///// <param name="controller"></param>
        //private static void RegisterNowTags(BeckhoffController controller)
        //{
        //    var tags = new List<BeckhoffTag> { 
        //        new BeckhoffTag { Address = "​L_EMSG", TagType = "NowMessage", Topic = controller.TopicName }, 
        //        new BeckhoffTag { Address = "L_NWSH", TagType = "NowWasher", Topic = controller.TopicName },                
        //        new BeckhoffTag { Address = "L_NFRM", TagType = "NowFormula", Topic = controller.TopicName }, 
        //        new BeckhoffTag { Address = "L_NVLV", TagType = "NowValve", Topic = controller.TopicName } // Conventional Only
        //    };
        //    BeckhoffDataReader beckhoffDataReader = new BeckhoffDataReader(controller, MBeckhoffItemFormat);
        //    bool tracking = beckhoffDataReader.ReadTagsContinuously(tags, controller.AmsNetAddress, controller.Comport, TagProcessor.ProcessNowTags, controller, true);
        //    if (!tracking)
        //    {
        //        Log.ErrorFormat("Unable to track the now tags for controller :{0}", controller);
        //    }
        //}

        #endregion

        public void Stop()
        {
            foreach (var beckhoffDataReader in beckhoffDataReaders)
            {
                beckhoffDataReader.StopPlcRead();
            }
        }

        private void RegisterModuleTags(BeckhoffController controller)
        {
            IEnumerable<ModuleTag> moduleTags = DataReaderAccess.GetActiveModuleTags(controller.ControllerId);
            BeckhoffDataReader beckhoffDataReader = new BeckhoffDataReader(controller, MBeckhoffItemFormat, controller.AmsNetAddress, controller.Comport);
            IEnumerable<Module> results = moduleTags.GroupBy(p => new { p.ModuleId, p.ModuleTypeId, p.DeadBand, p.Unit, RollOverPoint = p.Rolloverpoint, p.Calibration, p.UtilityType }).Select(g => new Module { ModuleId = g.Key.ModuleId, ModuleTypeId = g.Key.ModuleTypeId, Deadband = g.Key.DeadBand, Unit = g.Key.Unit, RollOverPoint = g.Key.RollOverPoint, Calibration = g.Key.Calibration, UtilityType = g.Key.UtilityType, Tags = g.Select(m => new OpcTag { Address = m.TagAddress, Topic = m.TopicName, TagType = m.TagType, TagTypeId = m.TagTypeId, TagId = m.ModuleTagId }).ToList<Tag>() });

            foreach (Module module in results)
            {
                var tags = new List<BeckhoffTag>
                {
                    new BeckhoffTag
                    {
                        Address = module.Tags.First().Address,
                        TagType = module.Tags.First().TagType,
                        Topic = controller.TopicName,
                        TagTypeId = module.Tags.First().TagTypeId
                    }
                };
                bool tracking = beckhoffDataReader.ReadTagsContinuously(tags, TagProcessor.ProcessModuleTags, module);
                if (!tracking)
                {
                    Log.ErrorFormat("Unable to track the module:{0}", module);
                }
            }

            beckhoffDataReaders.Add(beckhoffDataReader);
        }

    }

}
