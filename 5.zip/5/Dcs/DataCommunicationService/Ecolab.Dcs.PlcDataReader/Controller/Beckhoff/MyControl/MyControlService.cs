﻿// -----------------------------------------------------------------------
// <copyright file="MyControlService.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The MyControlService </summary>
// -----------------------------------------------------------------------
using Entities.DataReader;
using Controller = Ecolab.Dcs.Entities.Controller;
using Timer = System.Timers.Timer;
using Washer = Ecolab.Dcs.Entities.Washer;
namespace Ecolab.Dcs.PlcDataReader
{
    using System;
    using System.Collections.Concurrent;
    using System.Collections.Generic;
    using System.Data;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.Text;
    using System.Threading;
    using System.Timers;
    using System.Xml;
    using System.Xml.Serialization;
    using Access.DataReader;
    using Ecolab.Dcs.CollectData;
    using Ecolab.Dcs.CollectData.Beckhoff;
    using Entities;
    using log4net;
    using Microsoft.VisualBasic.FileIO;
    using Properties;
    using Controller = Controller;
    using Timer = Timer;
    public class MyControlService
    {
        #region Variables
        private const string MyControlServiceLogFile = "MyControlServiceLog";
        private static readonly ILog Log = LogManager.GetLogger(MyControlServiceLogFile);
        private static List<ushort> tunOnlineRes = new List<ushort>();
        private static ConcurrentDictionary<string, BeckhoffDataReader> objreader = new ConcurrentDictionary<string, BeckhoffDataReader>();
        private static ConcurrentDictionary<string, BeckoffDataWriter> objwriter = new ConcurrentDictionary<string, BeckoffDataWriter>();
        private static readonly string BeckhoffFormatedItem = Settings.Default.BeckhoffItemFormat;
        const string DateFormat = "yyyy-MM-ddTHH:mm:ss";
        private List<BeckhoffController> BeckhoffControllers;
        object locker = new object();
        ManualResetEvent timerDead = new ManualResetEvent(false);
        private bool DcsServiceStopping;
        private Timer DcsTimer;
        readonly ProcessRollup processRollup = new ProcessRollup();
        #endregion
        #region Constants - Addresses and pointers
        //Address        
        private const string StorePointerWE = "uint_StorePointerWE";
        private const string StorePointerWER = "uint_StorePointerWE_R";
        private const string StoreDataWe = "uint_StoreDataWe";
        private const string StoreProdDataWe = "uint_StoreProdDataWe";
        private const string StoreAlarmData = "uint_StoreAlarmData";
        private const string StorePointerAlarm = "uint_StorePointerAlarm";
        private const string StorePointerAlarmR = "uint_StorePointerAlarm_R";
        private const string StoreDataTun = "uint_StoreDataTun";
        private const string StoreProdDataTun = "uint_StoreProdDataTun";
        private const string StorePointerTUN = "uint_StorePointerTUN";
        private const string StorePointerTUNR = "uint_StorePointerTUN_R";
        private const string AlarmGeneral = "x_AlarmGeneral";
        private const string AlarmDataGeneral = "uint_AlarmDataGeneral";
        private const string AlarmWE = "x_AlarmWE";
        private const string AlarmDataWE = "uint_AlarmDataWE";
        private const string AlarmTUN = "x_AlarmTUN";
        private const string AlarmDataTUN = "uint_AlarmDataTUN";
        private const string EquipmentControl = "uint_EquipmentControl";
        private const string InputAnaConv = "uint_InputAna_Conv";
        private const string OnlineWEWater = "uint_OnlineWEWater";
        private const string StoreWEWater = "uint_StoreWEWater";
        private const string WandEDigInpVisu = "udint_WandE_DigInp_Visu";
        private const string WandEDateCounter1 = "str_WandE_DateCounter[1]";
        private const string WandEDateCounter2 = "str_WandE_DateCounter[2]";
        private const string WandEDigInpAlarm = "x_WandE_DigInp_Alarm";
        private const string AlarmDataWandEDig = "uint_AlarmDataWandEDig";
        private const string WandEenVisionHChk = "uint_WandE_enVision_HChk";
        private const string WandEAnaInpVisu = "uint_WandE_AnaInp_Visu";
        private const string WandEAnaInpFactor = "uint_WandE_AnaInp_Factor";
        private const string WandEAnaInpAlarm = "x_WandE_AnaInp_Alarm";
        private const string AlarmDataWandEAna = "uint_AlarmDataWandEAna";
        // Array size
        private const int SizeStorePointerWE = 16;
        private const int SizeStorePointerWER = 16;
        private const int SizeStoreDataWe = 82 * 16 * 2;
        private const int SizeStoreProdDataWe = 82 * 16 * 2;
        private const int SizeStoreAlarmData = 100 * 11 * 2;
        private const int SizeStorePointerAlarm = 16;
        private const int SizeStorePointerAlarmR = 16;
        private const int SizeStoreDataTun = 16700;
        private const int SizeStoreProdDataTun = 10 * 167 * 2;
        private const int SizeStorePointerTUN = 16;
        private const int SizeStorePointerTUNR = 16;
        private const int SizeAlarmGeneral = 200 * 2;
        private const int SizeAlarmDataGeneral = 200 * 8 * 2;
        private const int SizeAlarmWE = 16 * 15 * 2;
        private const int SizeAlarmDataWE = 16 * 15 * 8 * 2;
        private const int SizeAlarmTUN = 2 * 25 * 2;
        private const int SizeAlarmDataTUN = 2 * 25 * 8 * 2;
        private const int SizeEquipmentControl = 2 * 26 * 8;
        private const int SizeInputAnaConv = 10 * 8 * 2;
        private const int SizeOnlineWEWater = 16 * 50 * 2;
        private const int SizeStoreWEWater = 16 * 156 * 2;
        private const int SizeWandEDigInpVisu = 32 * 4 * 16;
        private const int SizeWandEDateCounter = 10;
        private const int SizeWandEDigInpAlarm = 32 * 2 * 2;
        private const int SizeAlarmDataWandEDig = 32 * 2 * 8;
        private const int SizeWandEenVisionHChk = 16;
        private const int SizeWandEAnaInpVisu = 8 * 2;
        private const int SizeWandEAnaInpFactor = 8 * 2;
        private const int SizeWandEAnaInpAlarm = 8 * 2;
        private const int SizeAlarmDataWandEAna = 8 * 8 * 2;
        private readonly XmlSerializer ConventionalXmlSerializer = new XmlSerializer(typeof(MyControlConventionalData));
        private readonly XmlSerializer EngergyDataXmlSerializer = new XmlSerializer(typeof(MyControlWaterEnergyLoggerData));
        private readonly XmlSerializer WAndAlarmDataXMLSerializer = new XmlSerializer(typeof(MyControlWandEAlarmData));
        private readonly XmlSerializer EnergyLoggerAnalogDataSerializer = new XmlSerializer(typeof(MyControlWaterEnergyLoggerAnalogData));
        private readonly XmlSerializer TunnelSerializer = new XmlSerializer(typeof(MyControlTunnel), new XmlRootAttribute("MyControlTunnel"));
        private readonly XmlSerializer AlarmDataSerializer = new XmlSerializer(typeof(MyControlAlarmData));
        private readonly XmlSerializer ProductDosingSerilzer = new XmlSerializer(typeof(MyControlOnlineProductDosing));
        private readonly XmlSerializer AnalogDataSerializer = new XmlSerializer(typeof(AnalogReadings), new XmlRootAttribute("MyControlAnalogData"));
        #endregion
        #region Methods
        public MyControlService()
        {
            DcsTimer = new Timer(Int32.Parse(Settings.Default.WebportReadInterval))
            {
                AutoReset = false
            };
            DcsTimer.Elapsed += OnTimedEvent;
            DcsTimer.Enabled = true;
        }
        public void Start()
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
            IEnumerable<global::Entities.DataReader.Controller> activeControllers = DataReaderAccess.GetActiveControllers();
            activeControllers = activeControllers.Where(c => c.ControllerTypeId == 2 && c.ControllerModelId == 7).ToList();
            List<Controller> controllers = activeControllers.Select(EntityConverter.Convert).ToList();
            BeckhoffControllers = controllers.FindAll(c => c is BeckhoffController).Select(c => (BeckhoffController)c).ToList();
            Log.InfoFormat("Started Tracking MyControl {0} controller(s)", BeckhoffControllers.Count);
            #region Mycontrol PLC connection management
            foreach (BeckhoffController controller in BeckhoffControllers)
            {
                if (!String.IsNullOrEmpty(controller.AmsNetAddress))
                {
                    if (!objreader.ContainsKey(controller.AmsNetAddress))
                    {
                        objreader.GetOrAdd(controller.AmsNetAddress, new BeckhoffDataReader(controller, BeckhoffFormatedItem, controller.AmsNetAddress, controller.Comport));
                    }
                    if (!objwriter.ContainsKey(controller.AmsNetAddress))
                    {
                        objwriter.GetOrAdd(controller.AmsNetAddress, new BeckoffDataWriter(controller, BeckhoffFormatedItem, controller.AmsNetAddress, controller.Comport));
                    }
                    if (objreader.Count > 0 && objwriter.Count > 0)
                    {
                        InitializePlcContinuousRead(controller, objreader[controller.AmsNetAddress], objwriter[controller.AmsNetAddress]);
                    }
                }
                else
                {
                    Log.ErrorFormat("Invalid AMSNet Address,Can't connect to PLC:{0} with ASMNet Address:{1}",
                        controller.TopicName, controller.AmsNetAddress);
                }
            }
            #endregion
        }
        public void Stop()
        {
            try
            {
                Log.Info("MyControl : Stopping Data Communication Service...");
                DcsServiceStopping = true;
                timerDead.WaitOne();
            }
            catch (Exception ex)
            {
                Log.Error("Failed to stop Data Communcation Service", ex);
            }
            finally
            {
                Log.InfoFormat("{0}: Service has been stopped.", "Data Communication Service");
            }
        }
        private void OnTimedEvent(Object source, ElapsedEventArgs e)
        {
            try
            {
                timerDead.Reset();
                Start();

            }
            catch (Exception ex)
            {
                Log.Error("Failed to run Data Communcation Service", ex);
            }
            finally
            {
                lock (locker)
                {
                    timerDead.Set(); // allow service to stop
                    Log.Info("Signal set to indicate elapsed event to continue");
                }
                if (!DcsServiceStopping)	// restart the timer
                    DcsTimer.Start();
            }
        }
        private void ProcessConventionalBatchData(BeckhoffController controller, BeckhoffDataReader reader, BeckoffDataWriter dataWriter)
        {
            if (String.IsNullOrEmpty(controller.AmsNetAddress))
                return;
            List<BeckhoffTag> myControlPointerTags = new List<BeckhoffTag>
            {
                new BeckhoffTag
                {
                    Address = StorePointerWE, SizetoRead = 16, TagItemType = UIInputType.TypeInt,TagType = "uint"
                },
                new BeckhoffTag
                {
                    Address = StorePointerWER, SizetoRead = 16, TagItemType = UIInputType.TypeInt,TagType = "uint"
                },
            };
            List<BeckhoffTag> writetags = new List<BeckhoffTag> { new BeckhoffTag { Address = StorePointerWER } };
            List<BeckhoffTag> myControlBatchDataTag = new List<BeckhoffTag> { new BeckhoffTag { Address = StoreProdDataWe, SizetoRead = SizeStoreProdDataWe, TagItemType = UIInputType.TypeArray } };
            myControlBatchDataTag[0].BatchData = new List<ushort>(new ushort[82 * 16]); //new ushort[82 * 16];
            IList<BeckhoffTag> myControlPointerData = reader.ReadTags(myControlPointerTags);
            MyControlConventionalData conventionalData;
            int PLCPointer = Convert.ToInt32(myControlPointerData[0].Value);
            int dcsPointer = Convert.ToInt32(myControlPointerData[1].Value);
            if (PLCPointer != dcsPointer)
            {
                if (dcsPointer == 0)
                {
                    if (PLCPointer == 16)
                    {
                        dcsPointer = 1;
                    }
                    else
                    {
                        dcsPointer = PLCPointer + 1;
                    }
                }
                else
                {
                    if (dcsPointer < 16)
                    {
                        dcsPointer++;
                    }
                    else
                    {
                        dcsPointer = 1;
                    }
                }
                IList<BeckhoffTag> myControlBatchData = reader.ReadTags(myControlBatchDataTag);
                conventionalData = CopyConventionalDataFromArray(controller.RegionID, myControlBatchData[0].BatchData, dcsPointer, false);
                if (conventionalData != null)
                {
                    #region Production water consumption
                    conventionalData.StepWaterConsumption = ReadWaterConsumptionData(controller.RegionID, dcsPointer);
                    #endregion End Production water consumption
                    string xmlString = string.Empty;
                    int RedFlagShiftId = 0;
                    xmlString = SerializeXMLData(ConventionalXmlSerializer, conventionalData);
                    Log.Info("DataReaderAccess.ProcessMyControlBatchConventionalData - Call Start " + controller.ControllerId.ToString());
                    RedFlagShiftId = DataReaderAccess.ProcessMyControlBatchConventionalData(controller.ControllerId, xmlString, PLCPointer, dcsPointer, RedFlagShiftId);
                    Log.Info("DataReaderAccess.ProcessMyControlBatchConventionalData - Call End " + controller.ControllerId.ToString());
                    if (RedFlagShiftId > 0)
                    {
                        DataReaderAccess.ProcessRedFlagData(RedFlagShiftId);
                    }
                    writetags[0].Value = dcsPointer.ToString();
                    dataWriter.WriteTags(writetags);
                    Log.Info("Completed Processing Batches Array " + controller.ControllerId.ToString());
                }
            }
        }
        private string SerializeXMLData(XmlSerializer serilizer, object objectData)
        {
            StringWriter stringWriter = new StringWriter();
            using (XmlWriter xmlWriter = new XmlTextWriter(stringWriter))
            {
                serilizer.Serialize(xmlWriter, objectData);
                return stringWriter.ToString();
            }
        }
        private void ProcessConventionalOnlineData(BeckhoffController controller, BeckhoffDataReader reader)
        {
            if (String.IsNullOrEmpty(controller.AmsNetAddress))
                return;
            List<BeckhoffTag> myControlOnlineTag = new List<BeckhoffTag> { new BeckhoffTag { Address = StoreDataWe, SizetoRead = SizeStoreDataWe, TagItemType = UIInputType.TypeArray } };
            myControlOnlineTag[0].BatchData = new List<ushort>(new ushort[82 * 16]);
            reader.ReadTags(myControlOnlineTag);
            MyControlConventionalData myControlConventionalData;
            for (int washerNo = 1; washerNo <= 16; washerNo++)
            {
                string xmlString = string.Empty;
                myControlConventionalData = CopyConventionalDataFromArray(controller.RegionID, myControlOnlineTag[0].BatchData, washerNo);
                if (myControlConventionalData == null)
                    continue;
                xmlString = SerializeXMLData(ConventionalXmlSerializer, myControlConventionalData);
                int RedFlagShiftId = 0;
                Log.InfoFormat("Processing ProcessMyControlOnlineConventionalData and XML Data {0} {1}", controller.ControllerId, xmlString);
                RedFlagShiftId = DataReaderAccess.ProcessMyControlOnlineConventionalData(controller.ControllerId, xmlString, RedFlagShiftId);
                Log.Info("DataReaderAccess.ProcessMyControlOnlineConventionalData - Call End " + controller.ControllerId.ToString());
                if (RedFlagShiftId > 0)
                {
                    DataReaderAccess.ProcessRedFlagData(RedFlagShiftId);
                }
                Log.Info("Completed Processing Online Array " + controller.ControllerId.ToString());
            }
        }
        private static MyControlConventionalData CopyConventionalDataFromArray(int regionId, List<ushort> batchData, int batchIndex, bool onlineArray = true)
        {
            MyControlConventionalData washerData = new MyControlConventionalData();
            int washerNo;
            int offset;
            offset = (batchIndex - 1) * 82;
            if (onlineArray == true)
            {
                washerNo = batchIndex;
                washerData.StepNumber = batchData[offset].ToString();
            }
            else
            {
                washerNo = batchData[offset];
                washerData.StepNumber = string.Empty;
            }
            if (batchData[offset] == 0)
                return null;
            washerData.MachineNumber = washerNo.ToString();
            washerData.StartDateTime = string.Empty;
            if (batchData[offset + 1] > 0)
                washerData.StartDateTime = ConvertPlcDateTime(batchData[offset + 1], batchData[offset + 2]);
            washerData.EndDateTime = string.Empty;
            if (batchData[offset + 3] > 0)
                washerData.EndDateTime = ConvertPlcDateTime(batchData[offset + 3], batchData[offset + 4]);
            washerData.ProgramNumber = batchData[offset + 5].ToString();
            if (regionId == 1) //North America
            {
                washerData.Load = (batchData[offset + 6]).ToString();
                washerData.NominalLoad = (batchData[offset + 7]).ToString();
            }
            else if (regionId == 2) //Europe / Middle East / Africa
            {
                washerData.Load = UnitConversion.ConvertUnit(UnitConversion.Units.Kilogram, (Convert.ToUInt16(batchData[offset + 6]))).ToString();
                washerData.NominalLoad = UnitConversion.ConvertUnit(UnitConversion.Units.Kilogram, (Convert.ToUInt16(batchData[offset + 7]))).ToString();
            }
            Int32 CustomerNumber;
            CustomerNumber = batchData[offset + 8] * 10000;
            CustomerNumber = CustomerNumber + batchData[offset + 9];
            washerData.CustomerNumber = CustomerNumber.ToString();
            washerData.BatchNumber = batchData[offset + 10].ToString();
            washerData.DosingData = new List<ConventionalDosingData>(new ConventionalDosingData[20]);
            int doseOffset = offset + 11;
            int tempOffset;
            int doseStep;
            int doseFirstElement;
            int doseEquipment;
            int doseQuantity;
            for (int index = 1; index <= 20; index++)
            {
                tempOffset = doseOffset + ((index - 1) * 2);
                doseFirstElement = batchData[tempOffset];
                doseStep = doseFirstElement / 100;
                doseEquipment = doseFirstElement % 100;
                doseQuantity = batchData[tempOffset + 1];
                washerData.DosingData[index - 1] = new ConventionalDosingData();
                washerData.DosingData[index - 1].Equipment = doseEquipment.ToString();
                if (regionId == 1) //North America
                {
                    washerData.DosingData[index - 1].Qty = doseQuantity.ToString();
                }
                else if (regionId == 2) //Europe / Middle East / Africa
                {
                    if (doseEquipment >= 1 && doseEquipment <= 24)
                        washerData.DosingData[index - 1].Qty = UnitConversion.ConvertUnit(UnitConversion.Units.MilliLitre, (Convert.ToUInt16(doseQuantity))).ToString();
                    else if (doseEquipment >= 25 && doseEquipment <= 26)
                        washerData.DosingData[index - 1].Qty = UnitConversion.ConvertUnit(UnitConversion.Units.Gram, (Convert.ToUInt16(doseQuantity))).ToString();
                }
                washerData.DosingData[index - 1].stepNo = doseStep.ToString();
            }
            if (regionId == 1) //North America
            {
                washerData.WaterConsumption1 = batchData[offset + 51].ToString();
                washerData.WaterConsumption2 = batchData[offset + 52].ToString();
            }
            else if (regionId == 2) //Europe / Middle East / Africa
            {
                washerData.WaterConsumption1 = UnitConversion.ConvertUnit(UnitConversion.Units.Litre, batchData[offset + 51]).ToString();
                washerData.WaterConsumption2 = UnitConversion.ConvertUnit(UnitConversion.Units.Litre, batchData[offset + 52]).ToString();
            }
            washerData.StepTime = new List<ConventionalStepData>(new ConventionalStepData[25]);
            for (int index = 1; index <= 25; index++)
            {
                tempOffset = offset + 53 + (index - 1);
                washerData.StepTime[index - 1] = new ConventionalStepData();
                washerData.StepTime[index - 1].Number = index.ToString();
                washerData.StepTime[index - 1].Time = batchData[tempOffset].ToString();
            }
            ushort PHData = batchData[offset + 78];
            int tempphData;
            if (PHData >= 10000)
            {
                tempphData = PHData / 10000;
                washerData.PHStatus = tempphData.ToString();
                tempphData = tempphData * 10000;
                tempphData = PHData - tempphData;
                washerData.PHValue = tempphData.ToString();
            }
            else
            {
                washerData.PHStatus = "0";
                washerData.PHValue = PHData.ToString();
            }
            ushort tempratureMinData = batchData[offset + 79];
            int tempData;
            if (tempratureMinData >= 10000)
            {
                tempData = tempratureMinData / 10000;
                washerData.TemperatureMinStatus = tempData.ToString();
                tempData = tempData * 10000;
                tempData = tempratureMinData - tempData;
                if (regionId == 1) //North America
                {
                    washerData.TemperatureMin = tempratureMinData.ToString();
                }
                else if (regionId == 2) //Europe / Middle East / Africa
                {
                    if (tempratureMinData > 0)
                        washerData.TemperatureMin = UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, tempratureMinData).ToString();
                }
            }
            else
            {
                washerData.TemperatureMinStatus = "0";
                if (regionId == 1) //North America
                {
                    washerData.TemperatureMin = tempratureMinData.ToString();
                }
                else if (regionId == 2) //Europe / Middle East / Africa
                {
                    if (tempratureMinData > 0)
                        washerData.TemperatureMin = UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, tempratureMinData).ToString();
                }
            }
            ushort tempMaxData = batchData[offset + 80];
            int CoolDownValueTempDiff = 0;
            if (tempMaxData > tempratureMinData)
            {
                CoolDownValueTempDiff = tempMaxData - tempratureMinData;
            }
            if (regionId == 1) //North America
            {
                washerData.TemperatureMax = tempMaxData.ToString();
            }
            else if (regionId == 2) //Europe / Middle East / Africa
            {
                if (tempMaxData > 0)
                    washerData.TemperatureMax = UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, tempMaxData).ToString();
            }
            washerData.TemperatureMaxStatus = CoolDownValueTempDiff.ToString();
            return washerData;
        }
        /// <summary>
        /// Initilalize plc reader and writer
        /// </summary>
        /// <param name="controller"></param>
        /// <param name="reader"></param>
        /// <param name="writer"></param>
        public void InitializePlcContinuousRead(BeckhoffController controller, BeckhoffDataReader reader, BeckoffDataWriter writer)
        {
            try
            {
                try
                {
                    ProcessConventionalOnlineData(controller, reader);
                }
                catch (Exception ex)
                {
                    DisposeReadWrite(reader, writer, controller);
                    Log.Error("Error occured:ProcessConventionalOnlineData:" + controller.TopicName, ex);
                }
                try
                {
                    ProcessConventionalBatchData(controller, reader, writer);
                }
                catch (Exception ex)
                {
                    DisposeReadWrite(reader, writer, controller);
                    Log.Error("Error occured:ProcessConventionalBatchData:" + controller.TopicName, ex);
                }
                try
                {
                    ProcessConventionalWaterConsumptionPerStep(controller,reader);
                }
                catch (Exception ex)
                {
                    DisposeReadWrite(reader, writer, controller);
                    Log.Error("Error occured:ProcessConventionalWaterConsumptionPerStep:" + controller.TopicName, ex);
                }
                try
                {
                    //Read online tunnel washer data
                    ReadOnlineData(controller, reader);
                }
                catch (Exception ex)
                {
                    DisposeReadWrite(reader, writer, controller);
                    Log.Error("Error occured:ReadOnlineData:" + controller.TopicName, ex);
                }
                try
                {
                    //Read Production tunnel washer data
                    ReadProductionData(controller, reader, writer);
                }
                catch (Exception ex)
                {
                    DisposeReadWrite(reader, writer, controller);
                    Log.Error("Error occured:ReadProductionData:" + controller.TopicName, ex);
                }
                try
                {
                    ReadAndProcessOnlineAlarmData(controller, reader);
                }
                catch (Exception ex)
                {
                    DisposeReadWrite(reader, writer, controller);
                    Log.Error("Error occured:ReadAndProcessOnlineAlarmData:" + controller.TopicName, ex);
                }
                try
                {
                    ReadAlarmProdData(controller, reader, writer);
                }
                catch (Exception ex)
                {
                    DisposeReadWrite(reader, writer, controller);
                    Log.Error("Error occured:ReadAlarmProdData:" + controller.TopicName, ex);
                }
                try
                {
                    ReadAndProcessOnlineProductDosing(controller, reader);
                }
                catch (Exception ex)
                {
                    DisposeReadWrite(reader, writer, controller);
                    Log.Error("Error occured:ReadAndProcessOnlineProductDosing:" + controller.TopicName, ex);
                }
                try
                {
                    ReadAnalogData(controller, reader);
                }
                catch (Exception ex)
                {
                    DisposeReadWrite(reader, writer, controller);
                    Log.Error("Error occured:ReadAnalogData:" + controller.TopicName, ex);
                }
                try
                {
                    ReadWaterEnergyLoggerDigitalData(controller, reader, writer);
                }
                catch (Exception ex)
                {
                    DisposeReadWrite(reader, writer, controller);
                    Log.Error("Error occured:ReadWaterEnergyLoggerDigitalData:" + controller.TopicName, ex);
                }
                try
                {
                    ReadWaterEnergyLoggerAnalogData(controller, reader, writer);
                }
                catch (Exception ex)
                {
                    DisposeReadWrite(reader, writer, controller);
                    Log.Error("Error occured:ReadWaterEnergyLoggerAnalogData:" + controller.TopicName, ex);
                }
                // ReadWaterEnergyLoggerDigitalAlarmsData(controller, reader);
                try
                {
                    processRollup.Rollup();
                }
                catch (Exception ex)
                {
                    Log.Error("Error occured:processRollup:" + controller.TopicName, ex);
                }
            }
            catch (Exception ex)
            {
                Log.Error("Error occured:InitializePlcContinuousRead:" + controller.TopicName, ex);
            }
        }
        private void DisposeReadWrite(BeckhoffDataReader reader, BeckoffDataWriter writer, BeckhoffController controller)
        {
            #region Dispose reader/writer
            if (!reader.IsConnected && objreader.ContainsKey(controller.AmsNetAddress))
            {
                BeckhoffDataReader tempreader;
                objreader.TryRemove(controller.AmsNetAddress, out tempreader);
                tempreader.StopPlcRead();
            }
            if (!writer.IsConnected && objwriter.ContainsKey(controller.AmsNetAddress))
            {
                BeckoffDataWriter tempwriter;
                objwriter.TryRemove(controller.AmsNetAddress, out tempwriter);
                tempwriter.StopPlcWrite();
            }
            #endregion
        }
        private void ReadWaterEnergyLoggerDigitalData(BeckhoffController controller, BeckhoffDataReader reader, BeckoffDataWriter writer)
        {
            //read handcheck value 
            //if value is 65535,call ProcessFTPCSVFiles method
            List<BeckhoffTag> readtags = new List<BeckhoffTag> { new BeckhoffTag { Address = WandEenVisionHChk, TagItemType = UIInputType.TypeUInt16 } };
            reader.ReadTags(readtags);
            int hndchk = Convert.ToInt32(readtags[0].Value);
            if (hndchk == 65535 && (!string.IsNullOrEmpty(controller.IpAddress)))
            {
                ProcessFTPCSVFiles(controller);
            }
            int offset = 0;
            if (String.IsNullOrEmpty(controller.AmsNetAddress))
                return;
            BeckhoffTag myControlOnlineTag = new BeckhoffTag { Address = WandEDigInpVisu, SizetoRead = SizeWandEDigInpVisu, TagItemType = UIInputType.TypeU32Array };
            myControlOnlineTag.WAndEData = new List<UInt32>(new UInt32[32 * 4]);
            BeckhoffTag Tag_WandE_DateCounter1 = new BeckhoffTag { Address = WandEDateCounter1, SizetoRead = SizeWandEDateCounter, TagItemType = UIInputType.TypeString };
            BeckhoffTag Tag_WandE_DateCounter2 = new BeckhoffTag { Address = WandEDateCounter2, SizetoRead = SizeWandEDateCounter, TagItemType = UIInputType.TypeString };
            IList<BeckhoffTag> onlineTags = new List<BeckhoffTag>() { myControlOnlineTag, Tag_WandE_DateCounter1, Tag_WandE_DateCounter2 };
            IList<BeckhoffTag> myControlOnlineData = reader.ReadTags(onlineTags);
            MyControlWaterEnergyLoggerData WaterEnergyLoggerData = new MyControlWaterEnergyLoggerData();
            MyControlDigitalInputData myControlDigitalData;
            WaterEnergyLoggerData.DigitalInputData = new List<MyControlDigitalInputData>(new MyControlDigitalInputData[32]);
            for (int Counter = 1; Counter <= 32; Counter++)
            {
                myControlDigitalData = new MyControlDigitalInputData();
                if (controller.RegionID == 1)
                {
                    myControlDigitalData.CurrentDayReading = myControlOnlineTag.WAndEData[offset].ToString();
                    myControlDigitalData.PreviousDayReading = myControlOnlineTag.WAndEData[offset + 2].ToString();
                }
                else if (controller.RegionID == 2)
                {
                    myControlDigitalData.CurrentDayReading = UnitConversion.ConvertUnit(UnitConversion.Units.Litre, (int)myControlOnlineTag.WAndEData[offset]).ToString();
                    myControlDigitalData.PreviousDayReading = UnitConversion.ConvertUnit(UnitConversion.Units.Litre, (int)myControlOnlineTag.WAndEData[offset + 2]).ToString();
                }
                myControlDigitalData.CurrentDayRunTime = myControlOnlineTag.WAndEData[offset + 1].ToString();
                myControlDigitalData.PreviousDayRuntime = myControlOnlineTag.WAndEData[offset + 3].ToString();
                if (!string.IsNullOrEmpty(Tag_WandE_DateCounter1.Value))
                {
                    string inddate = Tag_WandE_DateCounter1.Value.Substring(2, 1);
                    if (inddate == ".")
                    {
                        string[] scdate = Tag_WandE_DateCounter1.Value.Split('.');
                        string currdate = scdate[1] + "." + scdate[0] + "." + scdate[2] + DateTime.Now.ToString(" HH:mm:ss");
                        myControlDigitalData.CurrentDate = DateTime.Parse(currdate).ToUniversalTime().ToString();
                    }
                    else
                    {
                        string currdate = Tag_WandE_DateCounter1.Value + DateTime.Now.ToString(" HH:mm:ss");
                        myControlDigitalData.CurrentDate = DateTime.Parse(currdate).ToUniversalTime().ToString();
                    }
                }
                if (!string.IsNullOrEmpty(Tag_WandE_DateCounter2.Value))
                {
                    string inddate = Tag_WandE_DateCounter2.Value.Substring(2, 1);
                    if (inddate == ".")
                    {
                        string[] spdate = Tag_WandE_DateCounter2.Value.Split('.');
                        string Predate = spdate[1] + "." + spdate[0] + "." + spdate[2];
                        myControlDigitalData.PrevoiusDate = Predate;
                    }
                    else
                    {
                        myControlDigitalData.PrevoiusDate = Tag_WandE_DateCounter2.Value;
                    }
                }
                myControlDigitalData.InputNumber = Counter.ToString();
                WaterEnergyLoggerData.DigitalInputData[Counter - 1] = myControlDigitalData;
                offset = offset + 4;
            }
            string xmlString;
            xmlString = SerializeXMLData(EngergyDataXmlSerializer, WaterEnergyLoggerData);
            #region Write handshake value(65534) to PLC
            List<BeckhoffTag> writetags = new List<BeckhoffTag> { new BeckhoffTag { Address = WandEenVisionHChk, TagItemType = UIInputType.TypeUInt16 } };
            writetags[0].Value = Convert.ToString(65534);
            writer.WriteTags(writetags);
            #endregion
            Log.InfoFormat("DataReaderAccess.ProcessMyControlW&EDigitalData - Call Start " + controller.ControllerId.ToString() + "{0}",xmlString);
            DataReaderAccess.ProcessMyControlWandEDigitalData(controller.ControllerId, xmlString,true);
            Log.InfoFormat("DataReaderAccess.ProcessMyControlW&EDigitalData - Call End " + controller.ControllerId.ToString(), xmlString);
        }
        public void ProcessFTPCSVFiles(BeckhoffController controller)
        {
            string[] filenames = GetFTPFilesList(controller.IpAddress);
            if (filenames != null && filenames.Any() == true)
            {
                foreach (string file in filenames)
                {
                    DownloadFTPFile(controller, file);
                    DeleteFTPFile(file, controller.IpAddress);
                }
            }
        }
        private void ProcessWandEDigitalActiveAlarmData(ushort[] batchData, int offset, int alarmNumber, int controllerId)
        {
            MyControlWandEAlarmData myControlWandEAlarmData = new MyControlWandEAlarmData();
            MyControlAlarmData myControlAlarmData;
            myControlWandEAlarmData.WandEAlarmData = new List<MyControlAlarmData>(new MyControlAlarmData[2]);
            if (batchData[offset] > 0)
                for (int i = 1; i <= 2; i++)
                {
                    myControlAlarmData = new MyControlAlarmData();
                    if (i == 1)
                    {
                        myControlAlarmData.AlarmType = "1";
                    }
                    else
                    {
                        myControlAlarmData.AlarmType = "2";
                    }
                    myControlAlarmData.StartDateTime = ConvertPlcDateTime(batchData[offset], batchData[offset + 1]);
                    myControlAlarmData.MachineNumber = batchData[offset + 2].ToString();
                    myControlAlarmData.BatchNumber = batchData[offset + 3].ToString();
                    myControlAlarmData.ProgramNumber = batchData[offset + 4].ToString();
                    myControlAlarmData.DesiredValue = batchData[offset + 5].ToString();
                    myControlAlarmData.MeasuredValue = batchData[offset + 6].ToString();
                    myControlAlarmData.Status = batchData[offset + 7].ToString();
                    myControlAlarmData.AlarmNumber = alarmNumber.ToString();
                    myControlWandEAlarmData.WandEAlarmData[i - 1] = myControlAlarmData;
                    offset = offset + 8;
                }
            string xmlString = SerializeXMLData(WAndAlarmDataXMLSerializer, myControlWandEAlarmData);
            Log.InfoFormat("Inserting WAndE Logger digital alarms for controller: {0} - xml : {1}", controllerId, xmlString);
            //Calling the SP to insert general alarm details in alarmdata table
            DataReaderAccess.ProcessMyControlWandEDigitalAlarmData(controllerId, xmlString);
            Log.Info("Inserting WANdE Logger digital alarms for controller - Call End " + controllerId.ToString());
        }
        private void ReadWaterEnergyLoggerAnalogData(BeckhoffController controller, BeckhoffDataReader reader, BeckoffDataWriter writer)
        {
            List<BeckhoffTag> myControlOnlineTag = new List<BeckhoffTag> { new BeckhoffTag { Address = WandEAnaInpVisu, SizetoRead = SizeWandEAnaInpVisu, TagItemType = UIInputType.TypeArray } };
            myControlOnlineTag[0].BatchData = new List<ushort>(new ushort[8]);
            List<BeckhoffTag> myControlOnlineFactorTag = new List<BeckhoffTag> { new BeckhoffTag { Address = WandEAnaInpFactor, SizetoRead = SizeWandEAnaInpFactor, TagItemType = UIInputType.TypeArray } };
            myControlOnlineFactorTag[0].BatchData = new List<ushort>(new ushort[8]);
            IList<BeckhoffTag> myControlOnlineData = reader.ReadTags(myControlOnlineTag);
            IList<BeckhoffTag> myControlOnlineFactorData = reader.ReadTags(myControlOnlineFactorTag);
            MyControlWaterEnergyLoggerAnalogData WaterEnergyLoggerData = new MyControlWaterEnergyLoggerAnalogData();
            MyControlAnalogInputData myControlAnalogData;
            WaterEnergyLoggerData.AnalogInputData = new List<MyControlAnalogInputData>(new MyControlAnalogInputData[8]);
            int offset = 0;
            int offfactorset = 0;
            for (int i = 1; i <= 8; i++)
            {
                myControlAnalogData = new MyControlAnalogInputData();
                if (myControlOnlineData[0].BatchData[offset] <= 1)
                {
                    myControlAnalogData.CounterNo = i.ToString();
                    double val1 = (myControlOnlineData[0].BatchData[offset] / myControlOnlineFactorData[0].BatchData[offfactorset]);
                    myControlAnalogData.Reading = String.Format("{0:0.000}", val1); //Convert.ToDecimal(val1).ToString("x.xxx");
                }
                else if (myControlOnlineData[0].BatchData[offset] > 1 && myControlOnlineData[0].BatchData[offset] <= 10)
                {
                    myControlAnalogData.CounterNo = i.ToString();
                    double val2 = (myControlOnlineData[0].BatchData[offset]) / (myControlOnlineFactorData[0].BatchData[offfactorset]);
                    myControlAnalogData.Reading = String.Format("{0:00.00}", val2);
                }
                else if (myControlOnlineData[0].BatchData[offset] > 10 && myControlOnlineData[0].BatchData[offset] <= 1000)
                {
                    myControlAnalogData.CounterNo = i.ToString();
                    double val3 = (myControlOnlineData[0].BatchData[offset]) / (myControlOnlineFactorData[0].BatchData[offfactorset]);
                    myControlAnalogData.Reading = String.Format("{0:000.0}", val3);
                }
                else
                {
                    myControlAnalogData.CounterNo = i.ToString();
                    myControlAnalogData.Reading = myControlOnlineData[0].BatchData[offset].ToString();
                }
                WaterEnergyLoggerData.AnalogInputData[i - 1] = myControlAnalogData;
                offset = offset + 1;
                offfactorset = offfactorset + 1;
            }
            string xmlString = SerializeXMLData(EnergyLoggerAnalogDataSerializer, WaterEnergyLoggerData);
            Log.InfoFormat("DataReaderAccess.ProcessMyControlW&EAnalogData - Call Start " + controller.ControllerId.ToString(),xmlString);
            DataReaderAccess.ProcessMyControlWandEAnalogData(controller.ControllerId, xmlString);
            Log.InfoFormat("DataReaderAccess.ProcessMyControlW&EAnalogData - Call End " + controller.ControllerId.ToString(),xmlString);
        }
        private static string[] GetFTPFilesList(string ipAddress)
        {
            try
            {
                List<string> fileList = new List<string>();
                StringBuilder HtmlResult = new StringBuilder();
                string url = "ftp://ecolab:24042404@" + ipAddress + "/Hard Disk2/WELogger/";
                // ftp://ecolab:24042404@172.16.104.202/Hard Disk2/WELogger/
                FtpWebRequest request = (FtpWebRequest)WebRequest.Create(url);
                if (Convert.ToBoolean(CommonDataOperations.IsEtechProxyEnabled))
                {
                    WebProxy proxy = new WebProxy(CommonDataOperations.ETechProxyAddress, Convert.ToBoolean(CommonDataOperations.ETechProxyBypassOnLocal));
                    request.Credentials = new NetworkCredential("ecolab", "24042404");
                    request.Proxy = proxy;
                }
                request.Method = WebRequestMethods.Ftp.ListDirectory;
                WebResponse response = request.GetResponse();

                using (Stream responsestream = response.GetResponseStream())
                {
                    using (StreamReader reader = new StreamReader(responsestream))
                    {
                        while (!reader.EndOfStream)
                        {
                            HtmlResult.AppendLine(reader.ReadLine());
                        }
                    }
                }
                //parse html output
                HtmlAgilityPack.HtmlDocument doc = new HtmlAgilityPack.HtmlDocument();
                doc.LoadHtml(HtmlResult.ToString());
                foreach (HtmlAgilityPack.HtmlNode node in doc.DocumentNode.Descendants())
                {
                    if (node.InnerText.Contains("WandE_2") && node.InnerText.Length == 18 && !fileList.Contains(node.InnerText))
                    {
                        fileList.Add(node.InnerText);
                    }
                }
                return fileList.ToArray();
            }
            catch (Exception ex)
            {
                Log.Error("ProcessMyControlW&EDigitalDataCSV WebResponse error" + ex.Message);
                return null;
            }
        }
        private void DownloadFTPFile(BeckhoffController controller, string file)
        {
            try
            {
                string fileContents = string.Empty;
                MyControlDigitalInputData myControlDigitalInputData;
                MyControlWaterEnergyLoggerData myControlWaterEnergyLoggerDataCSV = new MyControlWaterEnergyLoggerData();
                string[] Date = null;
                string uri = "ftp://ecolab:24042404@" + controller.IpAddress + "/Hard Disk2/WELogger/" + file;
                FtpWebRequest request = (FtpWebRequest)WebRequest.Create(uri);
                if (Convert.ToBoolean(CommonDataOperations.IsEtechProxyEnabled))
                {
                    WebProxy proxy = new WebProxy(CommonDataOperations.ETechProxyAddress, Convert.ToBoolean(CommonDataOperations.ETechProxyBypassOnLocal));
                    request.Credentials = new NetworkCredential("ecolab", "24042404");
                    request.Proxy = proxy;
                }
                request.Method = WebRequestMethods.Ftp.DownloadFile;
                WebResponse response = request.GetResponse();
                Stream responseStream = response.GetResponseStream();
                using (System.IO.TextReader tmpReader = new System.IO.StreamReader(responseStream))
                {
                    using (TextFieldParser csvReader = new TextFieldParser(tmpReader))
                    {
                        fileContents = csvReader.ReadLine();
                        string delim = Convert.ToString(fileContents[0]);
                        Date = csvReader.ReadLine().Split(Convert.ToChar(delim));
                        string DateString = Date[1];
                        csvReader.SetDelimiters(new string[] { delim });
                        csvReader.HasFieldsEnclosedInQuotes = false;
                        myControlWaterEnergyLoggerDataCSV.DigitalInputData = new List<MyControlDigitalInputData>();
                        int index = 0;
                        while (!csvReader.EndOfData)
                        {
                            string[] fieldData = csvReader.ReadFields();
                            if (index != 0)
                            {
                                myControlDigitalInputData = new MyControlDigitalInputData();
                                myControlDigitalInputData.InputNumber = fieldData[0].ToString();
                                myControlDigitalInputData.CurrentDayReading = fieldData[2].ToString();
                                myControlDigitalInputData.CurrentDayRunTime = fieldData[3].ToString();
                                if (!string.IsNullOrEmpty(DateString))
                                {
                                    string inddate = DateString.Substring(2, 1);
                                    if (inddate == ".")
                                    {
                                        string[] scdate = DateString.Split('.');
                                        string currdate = scdate[1] + "." + scdate[0] + "." + scdate[2] + " 23:59:59";
                                        myControlDigitalInputData.CurrentDate = DateTime.Parse(currdate).ToUniversalTime().ToString();
                                    }
                                    else
                                    {
                                        myControlDigitalInputData.CurrentDate = DateTime.Parse(DateString + " 23:59:59").ToUniversalTime().ToString();
                                    }
                                }
                                myControlWaterEnergyLoggerDataCSV.DigitalInputData.Add(myControlDigitalInputData);
                            }
                            index++;
                        }
                    }
                }
                response.Close();
                responseStream.Close();
                string xmlString = SerializeXMLData(EngergyDataXmlSerializer, myControlWaterEnergyLoggerDataCSV);
                Log.Info("DataReaderAccess.ProcessMyControlW&EDigitalDataCSV - Call Start " + controller.ControllerId.ToString());
                DataReaderAccess.ProcessMyControlWandEDigitalData(controller.ControllerId, xmlString, false);
                Log.Info("DataReaderAccess.ProcessMyControlW&EDigitalDataCSV - Call End " + controller.ControllerId.ToString());
            }
            catch (Exception ex)
            {
                Log.Error("ProcessMyControlW&EDigitalDataCSV TextFieldParser error" + ex.Message);
            }
        }
        private static void DeleteFTPFile(string file, string ipAddress)
        {
            try
            {
                string url = "ftp://ecolab:24042404@" + ipAddress + "/Hard Disk2/WELogger/" + file;
                FtpWebRequest request = (FtpWebRequest)WebRequest.Create(url);
                request.Method = WebRequestMethods.Ftp.DeleteFile;
                request.Proxy = null;
                using (FtpWebResponse response = (FtpWebResponse)request.GetResponse())
                {
                    string str = response.StatusDescription;
                }
            }
            catch (Exception)
            {
                ///write lof information
                Log.Error("Delete WAndE Logger  Digital File Failed" + file);
            }
        }

        private void ProcessWandEAnalogActiveAlarmData(ushort[] batchData, int offset, int alarmNumber, int controllerId)
        {
            MyControlWandEAlarmData myControlWandEAlarmData = new MyControlWandEAlarmData();
            MyControlAlarmData myControlAlarmData;
            myControlWandEAlarmData.WandEAlarmData = new List<MyControlAlarmData>(new MyControlAlarmData[2]);
            if (batchData[offset] > 0)
            {
                myControlAlarmData = new MyControlAlarmData();
                myControlAlarmData.StartDateTime = ConvertPlcDateTime(batchData[offset], batchData[offset + 1]);
                myControlAlarmData.MachineNumber = batchData[offset + 2].ToString();
                myControlAlarmData.BatchNumber = batchData[offset + 3].ToString();
                myControlAlarmData.ProgramNumber = batchData[offset + 4].ToString();
                myControlAlarmData.DesiredValue = batchData[offset + 5].ToString();
                myControlAlarmData.MeasuredValue = batchData[offset + 6].ToString();
                myControlAlarmData.Status = batchData[offset + 7].ToString();
                myControlAlarmData.AlarmNumber = alarmNumber.ToString();
                myControlWandEAlarmData.WandEAlarmData[offset] = myControlAlarmData;
            }
            string xmlString = SerializeXMLData(WAndAlarmDataXMLSerializer, myControlWandEAlarmData);
            Log.InfoFormat("Inserting WAndE Logger Analog alarms for controller: {0} - xml : {1}", controllerId, xmlString);
            //Calling the SP to insert general alarm details in alarmdata table
            DataReaderAccess.ProcessMyControlWandEAnalogAlarmData(controllerId, xmlString);
            Log.Info("Inserting WANdE Logger Analog alarms for controller - Call End " + controllerId.ToString());
        }
        private void ProcessConventionalWaterConsumptionPerStep(BeckhoffController controller, BeckhoffDataReader reader)
        {
            int offset = 0;
            if (String.IsNullOrEmpty(controller.AmsNetAddress))
                return;
            List<BeckhoffTag> myControlOnlineTag = new List<BeckhoffTag> { new BeckhoffTag { Address = OnlineWEWater, SizetoRead = SizeOnlineWEWater, TagItemType = UIInputType.TypeArray } };
            myControlOnlineTag[0].BatchData = new List<ushort>(new ushort[16 * 50]);
            reader.ReadTags(myControlOnlineTag);
            MyControlConventionalData myControlConventionalData = new MyControlConventionalData();
            ConventionalStepWaterUsageData conventionalStepWaterUsageData;
            myControlConventionalData.StepWaterConsumption = new List<ConventionalStepWaterUsageData>(new ConventionalStepWaterUsageData[25]);
            for (int washerNo = 1; washerNo <= 16; washerNo++)
            {
                for (int stepNo = 1; stepNo <= 25; stepNo++)
                {
                    conventionalStepWaterUsageData = new ConventionalStepWaterUsageData();
                    if (controller.RegionID == 1) //North America
                    {
                        conventionalStepWaterUsageData.WCCounter1 = myControlOnlineTag[0].BatchData[offset].ToString();
                        conventionalStepWaterUsageData.WCCounter2 = myControlOnlineTag[0].BatchData[offset + 1].ToString();
                    }
                    else if (controller.RegionID == 2) //Europe / Middle East / Africa
                    {
                        conventionalStepWaterUsageData.WCCounter1 = UnitConversion.ConvertUnit(UnitConversion.Units.Litre, myControlOnlineTag[0].BatchData[offset]).ToString();
                        conventionalStepWaterUsageData.WCCounter2 = UnitConversion.ConvertUnit(UnitConversion.Units.Litre, myControlOnlineTag[0].BatchData[offset + 1]).ToString();
                    }
                    conventionalStepWaterUsageData.StepNo = stepNo.ToString();
                    myControlConventionalData.StepWaterConsumption[stepNo - 1] = conventionalStepWaterUsageData;
                    offset = offset + 2;
                }
                myControlConventionalData.MachineNumber = washerNo.ToString();
                string xmlString = string.Empty;
                if (myControlConventionalData == null)
                    continue;
                xmlString = SerializeXMLData(ConventionalXmlSerializer, myControlConventionalData);
                Log.Info("DataReaderAccess.ProcessMyControlOnlineCWStepWaterConsumptionData - Call Start " + controller.ControllerId.ToString() +" -xml :"+ xmlString);
                DataReaderAccess.ProcessMyControlOnlineCWWaterPerStepData(controller.ControllerId, xmlString);
                Log.Info("DataReaderAccess.ProcessMyControlOnlineCWStepWaterConsumptionData - Call End " + controller.ControllerId.ToString());
            }
        }
        private static List<ConventionalStepWaterUsageData> ReadWaterConsumptionData(int regionId, int batchIndex)
        {
            List<BeckhoffTag> myControlWaterConsumptionTag = new List<BeckhoffTag> { new BeckhoffTag { Address = StoreWEWater, SizetoRead = SizeStoreWEWater, TagItemType = UIInputType.TypeArray } };
            myControlWaterConsumptionTag[0].BatchData = new List<ushort>(new ushort[16 * 156]);
            List<ConventionalStepWaterUsageData> waterConsumption = new List<ConventionalStepWaterUsageData>(new ConventionalStepWaterUsageData[25]);
            int offset = 0;
            offset = (batchIndex - 1) * 156;
            for (int i = 0; i < 25; i++)
            {
                waterConsumption[i] = new ConventionalStepWaterUsageData();
                waterConsumption[i].StepNo = (i + 1).ToString();
                if (regionId == 1) //North America
                {
                    waterConsumption[i].WCCounter1 = myControlWaterConsumptionTag[0].BatchData[offset].ToString();
                    waterConsumption[i].WCCounter2 = myControlWaterConsumptionTag[0].BatchData[offset + 1].ToString();
                }
                else if (regionId == 2) //Europe / Middle East / Africa
                {
                    waterConsumption[i].WCCounter1 = UnitConversion.ConvertUnit(UnitConversion.Units.Litre, myControlWaterConsumptionTag[0].BatchData[offset]).ToString();
                    waterConsumption[i].WCCounter2 = UnitConversion.ConvertUnit(UnitConversion.Units.Litre, myControlWaterConsumptionTag[0].BatchData[offset + 1]).ToString();
                }
                offset = offset + 2;
            }
            return waterConsumption;
        }
        private void ReadAnalogData(BeckhoffController controller, BeckhoffDataReader reader)
        {
            try
            {
                List<BeckhoffTag> tunOnlineTags = new List<BeckhoffTag>
                {
                    new BeckhoffTag { Address = InputAnaConv, TagItemType = UIInputType.TypeArray, TagType = "uint", SizetoRead = SizeInputAnaConv }
                };
                tunOnlineTags[0].BatchData = new List<ushort>(new ushort[160]); //new ushort[160];
                AnalogReadings readings = new AnalogReadings();
                readings.WEData = new List<WEAnalogData>();
                WEAnalogData analog;
                readings.TunnelData = new List<TunnelAnalogData>();
                TunnelAnalogData tunnelAnalog;
                readings.LPData = new List<LevelProduct>();
                LevelProduct lp;
                IList<BeckhoffTag> tunOnlineBatch = reader.ReadTags(tunOnlineTags);
                if (tunOnlineBatch != null)
                {
                    Log.InfoFormat("Reading analog data for myControl Controller {0}", controller.ControllerId);
                    //Fetching Analog readings
                    for (int j = 0; j < 72; j++)
                    {
                        //Analog Module 1 and 2
                        //Fetching Analog readings for WE 1 to 8
                        if (j < 8)
                        {
                            analog = new WEAnalogData();
                            analog.WENumber = (j + 1).ToString();
                            if (controller.RegionID == 1)  //North America
                            {
                                if (tunOnlineBatch[0].BatchData[j] > 0)
                                    analog.Temperature = (tunOnlineBatch[0].BatchData[j]).ToString();
                            }
                            else if (controller.RegionID == 2) //Europe / Middle East / Africa
                            {
                                 if (tunOnlineBatch[0].BatchData[j] > 0)
                                    analog.Temperature = Convert.ToString(UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, tunOnlineBatch[0].BatchData[j]));
                            }
                            analog.pH = (tunOnlineBatch[0].BatchData[j + 8]).ToString();
                            readings.WEData.Add(analog);
                        }
                        //Analog Module 3 and 4
                        //Fetching Analog readings for WE 9 to 16
                        else if ((j >= 8) && (j < 16))
                        {
                            analog = new WEAnalogData();
                            analog.WENumber = (j + 1).ToString();
                            if (controller.RegionID == 1)  //North America
                            {
                                if (tunOnlineBatch[0].BatchData[j + 8] > 0)
                                    analog.Temperature = (tunOnlineBatch[0].BatchData[j + 8]).ToString();
                            }
                            else if (controller.RegionID == 2) //Europe / Middle East / Africa
                            {
                                if (tunOnlineBatch[0].BatchData[j + 8] > 0)
                                    analog.Temperature = Convert.ToString(UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, tunOnlineBatch[0].BatchData[j + 8]));
                            }
                            analog.pH = (tunOnlineBatch[0].BatchData[j + 16]).ToString();
                            readings.WEData.Add(analog);
                        }
                        //Analog Module 5 and 7
                        //Fetching Analog readings for TUN 1
                        else if (j == 32)
                        {
                            tunnelAnalog = new TunnelAnalogData();
                            tunnelAnalog.TunnelNo = Convert.ToString(1);
                            tunnelAnalog.pH1 = (tunOnlineBatch[0].BatchData[j]).ToString();
                            tunnelAnalog.pH2 = (tunOnlineBatch[0].BatchData[j + 1]).ToString();
                            tunnelAnalog.LF = (tunOnlineBatch[0].BatchData[j + 2]).ToString();

                            if (controller.RegionID == 1)  //North America
                            {
                                tunnelAnalog.Temperature1 = (tunOnlineBatch[0].BatchData[j + 4]).ToString();
                                tunnelAnalog.Temperature2 = (tunOnlineBatch[0].BatchData[j + 5]).ToString();
                                tunnelAnalog.Temperature3 = (tunOnlineBatch[0].BatchData[j + 6]).ToString();
                                tunnelAnalog.Temperature4 = (tunOnlineBatch[0].BatchData[j + 7]).ToString();
                                tunnelAnalog.Temperature5 = (tunOnlineBatch[0].BatchData[j + 16]).ToString();
                                tunnelAnalog.Temperature6 = (tunOnlineBatch[0].BatchData[j + 17]).ToString();
                                tunnelAnalog.Weight = (tunOnlineBatch[0].BatchData[j + 3]).ToString();
                            }
                            else if (controller.RegionID == 2) //Europe / Middle East / Africa
                            {
                                if (tunOnlineBatch[0].BatchData[j + 4] > 0)
                                    tunnelAnalog.Temperature1 = Convert.ToString(UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, tunOnlineBatch[0].BatchData[j + 4]));
                                if (tunOnlineBatch[0].BatchData[j + 5] > 0)
                                    tunnelAnalog.Temperature2 = Convert.ToString(UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, tunOnlineBatch[0].BatchData[j + 5]));
                                if (tunOnlineBatch[0].BatchData[j + 6] > 0)
                                    tunnelAnalog.Temperature3 = Convert.ToString(UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, tunOnlineBatch[0].BatchData[j + 6]));
                                if (tunOnlineBatch[0].BatchData[j + 7] > 0)
                                    tunnelAnalog.Temperature4 = Convert.ToString(UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, tunOnlineBatch[0].BatchData[j + 7]));
                                if (tunOnlineBatch[0].BatchData[j + 16] > 0)
                                    tunnelAnalog.Temperature5 = Convert.ToString(UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, tunOnlineBatch[0].BatchData[j + 16]));
                                if (tunOnlineBatch[0].BatchData[j + 17] > 0)
                                    tunnelAnalog.Temperature6 = Convert.ToString(UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, tunOnlineBatch[0].BatchData[j + 17]));
                                if (tunOnlineBatch[0].BatchData[j + 3] > 0)
                                    tunnelAnalog.Weight = Convert.ToString(UnitConversion.ConvertUnit(UnitConversion.Units.Kilogram, tunOnlineBatch[0].BatchData[j + 3]));
                            }
                            readings.TunnelData.Add(tunnelAnalog);
                        }
                        //Analog Module 6 and 7
                        //Fetching Analog readings for TUN 2
                        else if (j == 40)
                        {
                            tunnelAnalog = new TunnelAnalogData();
                            tunnelAnalog.TunnelNo = Convert.ToString(2);
                            tunnelAnalog.pH1 = (tunOnlineBatch[0].BatchData[j]).ToString();
                            tunnelAnalog.pH2 = (tunOnlineBatch[0].BatchData[j + 1]).ToString();
                            tunnelAnalog.LF = (tunOnlineBatch[0].BatchData[j + 2]).ToString();

                            if (controller.RegionID == 1)  //North America
                            {
                                tunnelAnalog.Temperature1 = (tunOnlineBatch[0].BatchData[j + 4]).ToString();
                                tunnelAnalog.Temperature2 = (tunOnlineBatch[0].BatchData[j + 5]).ToString();
                                tunnelAnalog.Temperature3 = (tunOnlineBatch[0].BatchData[j + 6]).ToString();
                                tunnelAnalog.Temperature4 = (tunOnlineBatch[0].BatchData[j + 7]).ToString();
                                tunnelAnalog.Temperature5 = (tunOnlineBatch[0].BatchData[j + 10]).ToString();
                                tunnelAnalog.Temperature6 = (tunOnlineBatch[0].BatchData[j + 11]).ToString();
                                tunnelAnalog.Weight = (tunOnlineBatch[0].BatchData[j + 3]).ToString();
                            }
                            else if (controller.RegionID == 2) //Europe / Middle East / Africa
                            {
                                if (tunOnlineBatch[0].BatchData[j + 4] > 0)
                                    tunnelAnalog.Temperature1 = Convert.ToString(UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, tunOnlineBatch[0].BatchData[j + 4]));
                                if (tunOnlineBatch[0].BatchData[j + 5] > 0)
                                    tunnelAnalog.Temperature2 = Convert.ToString(UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, tunOnlineBatch[0].BatchData[j + 5]));
                                if (tunOnlineBatch[0].BatchData[j + 6] > 0)
                                    tunnelAnalog.Temperature3 = Convert.ToString(UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, tunOnlineBatch[0].BatchData[j + 6]));
                                if (tunOnlineBatch[0].BatchData[j + 7] > 0)
                                    tunnelAnalog.Temperature4 = Convert.ToString(UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, tunOnlineBatch[0].BatchData[j + 7]));
                                if (tunOnlineBatch[0].BatchData[j + 10] > 0)
                                    tunnelAnalog.Temperature5 = Convert.ToString(UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, tunOnlineBatch[0].BatchData[j + 10]));
                                if (tunOnlineBatch[0].BatchData[j + 11] > 0)
                                    tunnelAnalog.Temperature6 = Convert.ToString(UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, tunOnlineBatch[0].BatchData[j + 11]));
                                if (tunOnlineBatch[0].BatchData[j + 3] > 0)
                                    tunnelAnalog.Weight = Convert.ToString(UnitConversion.ConvertUnit(UnitConversion.Units.Kilogram, tunOnlineBatch[0].BatchData[j + 3]));
                            }
                            readings.TunnelData.Add(tunnelAnalog);
                        }
                        //Analog Module 8 and 9
                        else if ((j >= 56) && (j < 70))
                        {
                            lp = new LevelProduct();
                            lp.LPNumber = (j - 55).ToString();
                            lp.MENumber = "0";
                            lp.LPValue = j.ToString();
                            readings.LPData.Add(lp);
                        }
                        //Analog Module 9
                        else if (j >= 70)
                        {
                            lp = new LevelProduct();
                            lp.LPNumber = "0";
                            lp.MENumber = (j - 69).ToString();
                            lp.LPValue = j.ToString();
                            readings.LPData.Add(lp);
                        }
                    }
                }
                string strTunnel = SerializeXMLData(AnalogDataSerializer, readings);
                Log.InfoFormat("Recording Analog Readings {0} {1}", controller.ControllerId, strTunnel);
                DataReaderAccess.ProcessMyControlAnalogData(controller.ControllerId, strTunnel);
            }
            catch (Exception ex)
            {
                Log.Error("Error occured:" + controller.TopicName, ex);
            }
        }
        /// <summary>
        /// This function will read production alarm data from PLC
        /// </summary>
        /// <param name="controller">The controller.</param>
        private void ReadAlarmProdData(BeckhoffController controller, BeckhoffDataReader reader, BeckoffDataWriter dataWriter)
        {
            try
            {
                int startReadPos = 0;
                int endReadPos = 0;
                int offset = 0;
                List<BeckhoffTag> readAlarmProdTags = new List<BeckhoffTag> { new BeckhoffTag { Address = "uint_StoreAlarmData", TagItemType = UIInputType.TypeArray, TagType = "uint", SizetoRead = 100 * 11 * 2 } };
                readAlarmProdTags[0].BatchData = new List<ushort>(new ushort[1100]); //new ushort[1100];
                //Read the Production Tunnel data from MyControl Controller
                //Read Production Pointer and Read Pointer from MyControl Controller
                var alarmProdTags = new List<BeckhoffTag>
                {
                    new BeckhoffTag
                    {
                        Address = StorePointerAlarm, TagItemType = UIInputType.TypeInt, TagType = "uint", SizetoRead = SizeStorePointerAlarm
                    },
                    new BeckhoffTag
                    {
                        Address = StorePointerAlarmR, TagItemType = UIInputType.TypeInt, TagType = "uint", SizetoRead =  SizeStorePointerAlarmR
                    }
                };
                IList<BeckhoffTag> plcPtrs = reader.ReadTags(alarmProdTags);
                if (plcPtrs != null)
                {
                    int plcPtr = Convert.ToInt16(plcPtrs[0].Value);
                    int readPtr = Convert.ToInt16(plcPtrs[1].Value);
                    List<ushort> alarmProdData = new List<ushort>(new ushort[11]); //new ushort[11];
                    IList<BeckhoffTag> alarmProdBatch = new List<BeckhoffTag>();
                    BeckhoffTag tag = new BeckhoffTag() { BatchData = new List<ushort>(1100) }; //new ushort[1100] };
                    alarmProdBatch.Add(tag);
                    //Read Production Tunnel Batch Data                    
                    while (plcPtr != readPtr)
                    {
                        if (readPtr == 0) //read all the alarms upto 100
                        {
                            if (plcPtr == 100)
                            {
                                startReadPos = 1;
                                endReadPos = 100;
                                readPtr = 100;
                                alarmProdBatch = reader.ReadTags(readAlarmProdTags);
                                Log.InfoFormat("Reading Tunnel Washer Production Tag {0} data at PLC Pointer {1} and Read Pointer {2} for myControl Controller {3}", alarmProdBatch[0].BatchData, plcPtr, readPtr, controller.ControllerId);
                                offset = (startReadPos - 1) * 11;
                                for (int k = startReadPos - 1; k < endReadPos; k++)
                                {
                                    for (int j = offset, l = 0; j < (offset + 11); j++, l++)
                                    {
                                        alarmProdData[l] = alarmProdBatch[0].BatchData[offset + l];
                                    }
                                    ProcessActiveAlarmData(alarmProdData, 1, alarmProdData[0], controller.ControllerId);
                                    offset = offset + 11;
                                }
                                //Update read pointer to PLC
                                WriteandReadAlarmPtrs(readPtr, dataWriter, controller.ControllerId);
                            }
                            else
                            {
                                startReadPos = plcPtr + 1;
                                endReadPos = 100 - plcPtr - 1;
                                readPtr = 100;
                                alarmProdBatch = reader.ReadTags(readAlarmProdTags);
                                Log.InfoFormat("Reading Tunnel Washer Production Tag {0} data at PLC Pointer {1} and Read Pointer {2} for myControl Controller {3}", alarmProdBatch[0].BatchData, plcPtr, readPtr, controller.ControllerId);
                                offset = (startReadPos - 1) * 11;
                                for (int k = startReadPos - 1; k < readPtr; k++)
                                {
                                    for (int j = offset, l = 0; j < (offset + 11); j++, l++)
                                    {
                                        alarmProdData[l] = alarmProdBatch[0].BatchData[offset + l];
                                    }
                                    ProcessActiveAlarmData(alarmProdData, 1, alarmProdData[0], controller.ControllerId);
                                    offset = offset + 11;
                                }
                                //Update read pointer to PLC
                                WriteandReadAlarmPtrs(readPtr, dataWriter, controller.ControllerId);
                            }
                        }
                        else
                        {
                            if (readPtr > plcPtr)
                            {
                                if (readPtr == 100)
                                {
                                    startReadPos = 1;
                                    endReadPos = plcPtr;
                                    readPtr = plcPtr;
                                    alarmProdBatch = reader.ReadTags(readAlarmProdTags);
                                    Log.InfoFormat("Reading Tunnel Washer Production Tag {0} data at PLC Pointer {1} and Read Pointer {2} for myControl Controller {3}", alarmProdBatch[0].BatchData, plcPtr, readPtr, controller.ControllerId);

                                    offset = (startReadPos - 1) * 11;
                                    for (int k = startReadPos - 1; k < plcPtr; k++)
                                    {
                                        for (int j = offset, l = 0; j < (offset + 11); j++, l++)
                                        {
                                            alarmProdData[l] = alarmProdBatch[0].BatchData[offset + l];
                                        }
                                        ProcessActiveAlarmData(alarmProdData, 1, alarmProdData[0], controller.ControllerId);
                                        offset = offset + 11;
                                    }
                                    //Update read pointer to PLC
                                    WriteandReadAlarmPtrs(readPtr, dataWriter, controller.ControllerId);
                                }
                                else
                                {
                                    startReadPos = readPtr + 1;
                                    endReadPos = 100 - readPtr;
                                    readPtr = 100;
                                    alarmProdBatch = reader.ReadTags(readAlarmProdTags);
                                    Log.InfoFormat("Reading Tunnel Washer Production Tag {0} data at PLC Pointer {1} and Read Pointer {2} for myControl Controller {3}", alarmProdBatch[0].BatchData, plcPtr, readPtr, controller.ControllerId);
                                    offset = (startReadPos - 1) * 11;
                                    for (int k = startReadPos - 1; k < readPtr; k++)
                                    {
                                        for (int j = offset, l = 0; j < (offset + 11); j++, l++)
                                        {
                                            alarmProdData[l] = alarmProdBatch[0].BatchData[offset + l];
                                        }
                                        ProcessActiveAlarmData(alarmProdData, 1, alarmProdData[0], controller.ControllerId);
                                        offset = offset + 11;
                                    }
                                    //Update read pointer to PLC
                                    WriteandReadAlarmPtrs(readPtr, dataWriter, controller.ControllerId);
                                }
                            }
                            else
                            {
                                startReadPos = readPtr + 1;
                                endReadPos = plcPtr - readPtr;
                                readPtr = plcPtr;
                                alarmProdBatch = reader.ReadTags(readAlarmProdTags);
                                Log.InfoFormat("Reading Tunnel Washer Production Tag {0} data at PLC Pointer {1} and Read Pointer {2} for myControl Controller {3}", alarmProdBatch[0].BatchData, plcPtr, readPtr, controller.ControllerId);
                                offset = (startReadPos - 1) * 11;
                                for (int k = startReadPos - 1; k < plcPtr; k++)
                                {
                                    for (int j = offset, l = 0; j < (offset + 11); j++, l++)
                                    {
                                        alarmProdData[l] = alarmProdBatch[0].BatchData[offset + l];
                                    }
                                    ProcessActiveAlarmData(alarmProdData, 1, alarmProdData[0], controller.ControllerId);
                                    offset = offset + 11;
                                }
                                //Update read pointer to PLC
                                WriteandReadAlarmPtrs(readPtr, dataWriter, controller.ControllerId);
                            }
                        }
                        if (plcPtr == readPtr)
                        {
                            Log.InfoFormat("No Historical Batches to read from PLC");
                        }
                    }
                }
            }
            catch (Exception)
            {

            }
        }
        /// <summary>
        /// This function will process the batch data read from PLC machine wise
        /// </summary>
        /// <param name="controller">The controller for Washer.</param>
        /// <param name="TunnelNumber">The tunnel number.</param>
        /// <param name="tunOnlineData">The tun online data.</param>
        /// <param name="isOnline">if set to <c>true</c> [is online].</param>
        /// <param name="plcPtr">The PLC PTR for Washer.</param>
        /// <param name="readPtr">The read PTR for Washer.</param>
        /// <param name="reader">The reade for Washerr.</param>
        private void RegisterWasher(BeckhoffController controller, int TunnelNumber, ushort[] tunOnlineData, bool isOnline, int plcPtr, int readPtr, BeckhoffDataReader reader)
        {
            MyControlTunnel tunnelWasher = new MyControlTunnel();
            tunnelWasher.Tunnels = new List<TunnelData>();
            ushort[] batch = new ushort[167];
            int CompartmentNo = 0;
            int offset = 0;
            int NoOfCompartments = 25;
            TunnelData tunnel;
            #region Read Transfer signal and Runsate
            List<BeckhoffTag> tunnelTransferTags = new List<BeckhoffTag>
            {
                    new BeckhoffTag
                    {
                        Address = "Helms_Info.uint_Helms_HT.uint_Transfer_TUN", TagItemType = UIInputType.TypeObject, ComplexObjectType = typeof(uints_Helms_HT).AssemblyQualifiedName
                    }
            };
            reader.ReadMyControlTags(tunnelTransferTags);
            uints_Helms_HT uint_Transfer_HT = (uints_Helms_HT)tunnelTransferTags[0].ComplexObject;
            #endregion
            #region Tunnel
            //Processes Online data
            if (isOnline)
            {
                #region Process online data
                //Online Bacthes for Tunnel 1
                if (TunnelNumber == 1)
                {
                    #region Read Runsate data
                    BeckhoffTag tunnelRunStateTags = new BeckhoffTag
                    {
                        Address = "x_RunState_TUN[" + TunnelNumber.ToString() + "]",
                        TagItemType = UIInputType.TypeUInt16,
                        TagType = "uint",
                        SizetoRead = 2
                    };
                    BeckhoffTag tunnelRunStateData = reader.ReadTag(tunnelRunStateTags);
                    #endregion
                    NoOfCompartments = CommonDataOperations.GetNoOfCompartmentsByMachineInternalId(1, controller.ControllerId);
                    if (NoOfCompartments < 1)
                        NoOfCompartments = 25;
                    for (int k = 0; k < NoOfCompartments; k++)
                    {
                        for (int j = 0; j < 167; j++)
                        {
                            batch[j] = tunOnlineData[offset + j];
                        }
                        CompartmentNo++;
                        tunnel = ProcessTunnelBatchData(controller.RegionID, batch, TunnelNumber, CompartmentNo);
                        tunnel.TransferSignal = Convert.ToString(uint_Transfer_HT.Uint_Transfer_TUN[0]);
                        tunnel.RunState = tunnelRunStateData.Value.ToString();
                        tunnel.MachineNumber = TunnelNumber.ToString();
                        tunnelWasher.MachineNumber = TunnelNumber.ToString();
                        tunnelWasher.Tunnels.Add(tunnel);
                        offset = offset + 167;
                        if (offset == 4175)
                            CompartmentNo = 0;
                    }
                }
                else if (TunnelNumber == 2)
                {
                    //Online Bacthes for Tunnel 2
                    #region Read Runsate
                    BeckhoffTag tunnelRunStateTags = new BeckhoffTag { Address = "x_RunState_TUN[" + TunnelNumber.ToString() + "]", TagItemType = UIInputType.TypeUInt16, TagType = "uint", SizetoRead = 2 };
                    BeckhoffTag tunnelRunStateData = reader.ReadTag(tunnelRunStateTags);
                    #endregion
                    NoOfCompartments = CommonDataOperations.GetNoOfCompartmentsByMachineInternalId(2, controller.ControllerId);
                    if (NoOfCompartments < 1)
                        NoOfCompartments = 25;
                    for (int k = 0; k < NoOfCompartments; k++)
                    {
                        for (int j = offset, l = 0; j < (offset + 167); j++, l++)
                        {
                            batch[l] = tunOnlineData[offset + l];
                        }
                        CompartmentNo++;
                        tunnel = ProcessTunnelBatchData(controller.RegionID, batch, TunnelNumber, CompartmentNo);
                        tunnel.TransferSignal = Convert.ToString(uint_Transfer_HT.Uint_Transfer_TUN[1]);
                        tunnel.RunState = tunnelRunStateData.Value.ToString();
                        tunnel.MachineNumber = TunnelNumber.ToString();
                        tunnelWasher.MachineNumber = TunnelNumber.ToString();
                        tunnelWasher.Tunnels.Add(tunnel);
                        offset = offset + 167;
                        if (offset == 8351)
                            CompartmentNo = 0;
                    }
                }
                string strTunnel = SerializeXMLData(TunnelSerializer, tunnelWasher);
                int RedFlagShiftId = 0;
                Log.InfoFormat("Processing Tunnel WasherId and XML Data {0} {1}", controller.ControllerId, strTunnel);
                RedFlagShiftId = DataReaderAccess.ProcessMyControlTunnelWasherOnlineData(controller.ControllerId, strTunnel, RedFlagShiftId);
                if (RedFlagShiftId > 0)
                {
                    DataReaderAccess.ProcessRedFlagData(RedFlagShiftId);
                }
                #endregion
            }
            else
            {
                //Processes Production data
                #region Process production data
                for (int j = 0; j < 167; j++)
                {
                    batch[j] = tunOnlineData[j];
                }
                tunnel = ProcessTunnelBatchData(controller.RegionID, batch, TunnelNumber, CompartmentNo);
                tunnelWasher.MachineNumber = tunnel.MachineNumber;
                tunnelWasher.Tunnels.Add(tunnel);
                string strTunnel = SerializeXMLData(TunnelSerializer, tunnelWasher);
                int RedFlagShiftId = 0;
                Log.InfoFormat("Processing Tunnel WasherId and XML Data {0} {1}", controller.ControllerId, strTunnel);
                RedFlagShiftId = DataReaderAccess.ProcessMyControlTunnelWasherProdData(controller.ControllerId, strTunnel, plcPtr, readPtr, RedFlagShiftId);
                if (RedFlagShiftId > 0)
                {
                    DataReaderAccess.ProcessRedFlagData(RedFlagShiftId);
                }
                #endregion
            }
            #endregion            
        }
        /// <summary>
        /// This function will update poinetrs to PLC after batch data has been read
        /// </summary>
        /// <param name="Ptr">The PTR for Mycontrol services.</param>
        /// <param name="dataWriter">The data writer for Mycontrol services.</param>
        /// <param name="ControllerId">The controller identifier.</param>
        private void WriteandReadPtrs(int Ptr, BeckoffDataWriter dataWriter, int ControllerId)
        {
            //Write Read Pointer to PLC
            List<BeckhoffTag> writetags = new List<BeckhoffTag> { new BeckhoffTag { Address = "uint_StorePointerTUN_R", TagItemType = UIInputType.TypeInt, TagType = "uint", Value = Ptr.ToString() } };
            Log.InfoFormat("Writing Read Pointer {0} to Tag {1} for Controller {1}", "uint_StorePointerTUN_R", Ptr, ControllerId);
            dataWriter.WriteTags(writetags);
        }
        /// <summary>
        /// This function will update poinetrs to PLC after alarm data has been read
        /// </summary>
        /// <param name="Ptr">The PTR for Alarm.</param>
        /// <param name="dataWriter">The data writer for Alarm.</param>
        /// <param name="ControllerId">The controller identifier.</param>
        private void WriteandReadAlarmPtrs(int Ptr, BeckoffDataWriter dataWriter, int ControllerId)
        {
            //Write Read Pointer to PLC
            List<BeckhoffTag> writetags = new List<BeckhoffTag> { new BeckhoffTag { Address = "uint_StorePointerAlarm_R", TagItemType = UIInputType.TypeInt, TagType = "uint", Value = Ptr.ToString() } };
            Log.InfoFormat("Writing Read Pointer {0} to Tag {1} for Controller {1}", "uint_StorePointerAlarm_R", Ptr, ControllerId);
            dataWriter.WriteTags(writetags);
        }
        /// <summary>
        /// This function will fetch batch array data into batch object
        /// </summary>
        /// <param name="regionId">The region identifier.</param>
        /// <param name="batchData">The batch data.</param>
        /// <param name="tunnelNumber">The tunnel number.</param>
        /// <param name="compartmentNo">The compartment no.</param>
        /// <returns>TunnelData.</returns>
        private static TunnelData ProcessTunnelBatchData(int regionId, ushort[] batchData, int tunnelNumber, int compartmentNo)
        {
            TunnelData tunnelProd = new TunnelData();
            tunnelProd.dose = new List<Dose>();//[104];
            tunnelProd.TimeCompartment = new List<CompartmentTime>();
            tunnelProd.WaterConsumption = new List<WaterConsumption>();
            tunnelProd.temperature = new List<TemperatureData>();
            TunnelData objrettunneldata = null;
            int offset = 0;
            try
            {
                tunnelProd.TunnelNumber = tunnelNumber.ToString();
                //tunnelProd.MachineNumber = tunnelNumber.ToString();
                tunnelProd.CompartmentNumber = compartmentNo.ToString();
                if (offset < 167)
                {
                    #region offset < 167
                    tunnelProd.MachineNumber = batchData[offset].ToString();
                    if (batchData[offset + 1] != 0)
                    {
                        //Format the date time based on the value read from PLC and format datetime in one parameter
                        tunnelProd.StartDate = batchData[offset + 1].ToString();
                        tunnelProd.StartTime = batchData[offset + 2].ToString();
                        tunnelProd.StartDateTime = ConvertPlcDateTime(batchData[offset + 1], batchData[offset + 2]);
                    }
                    else
                    {
                        tunnelProd.StartDate = null;
                        tunnelProd.StartTime = null;
                        tunnelProd.StartDateTime = string.Empty;
                    }
                    if (batchData[offset + 3] == 0)
                    {
                        tunnelProd.StopDate = null;
                        tunnelProd.StopTime = null;
                        tunnelProd.EndDateTime = string.Empty;
                    }
                    else
                    {
                        tunnelProd.StopDate = batchData[offset + 3].ToString();
                        tunnelProd.StopTime = batchData[offset + 4].ToString();
                        tunnelProd.EndDateTime = ConvertPlcDateTime(batchData[offset + 3], batchData[offset + 4]);
                    }
                    tunnelProd.ProgramNumber = batchData[offset + 5].ToString();
                    if (regionId == 1) //North America
                    {
                        tunnelProd.Load = (batchData[offset + 6] / 10).ToString();
                        //tunnelProd.Nominalload = (batchData[offset + 7] / 10).ToString(); 
                        tunnelProd.Nominalload = (batchData[offset + 7]).ToString();
                    }
                    else if (regionId == 2) //Europe / Middle East / Africa
                    {
                        tunnelProd.Load = UnitConversion.ConvertUnit(UnitConversion.Units.Kilogram, (Convert.ToUInt16(batchData[offset + 6] / 10))).ToString();
                        //tunnelProd.Nominalload = ConvertUOM("kilogram", (Convert.ToUInt16(batchData[offset + 7] / 10))).ToString();
                        tunnelProd.Nominalload = UnitConversion.ConvertUnit(UnitConversion.Units.Kilogram, (Convert.ToUInt16(batchData[offset + 7]))).ToString();
                    }
                    //CustomerNumberHB and CustomerNumberLB calculations
                    tunnelProd.CustomerNumberHB = (batchData[offset + 8] * 10000).ToString();
                    tunnelProd.CustomerNumberLB = tunnelProd.CustomerNumberHB + batchData[offset + 9].ToString();
                    tunnelProd.CustomerNumber = tunnelProd.CustomerNumberLB;
                    tunnelProd.BatchNumber = batchData[offset + 10].ToString();
                    //Process Dose Data
                    ProcessTunnelDoseData(regionId, batchData, tunnelProd);
                    //Process water consumption data
                    objrettunneldata = ProcessTunnelWasherConsumptionData(regionId, batchData, tunnelProd);
                    #endregion
                }
                return objrettunneldata;
            }
            catch (Exception ex)
            {
            }
            return tunnelProd;
        }
        /// <summary>
        /// This function will fetch batch tunnel dose data into batch object
        /// </summary>
        private static void ProcessTunnelDoseData(int regionId, ushort[] batchData, TunnelData tunnelProd)
        {
            //Process Dose data
            int dosingPoint = 1;
            int dosingPump = 1;
            int dosingRange = 1;
            int offset = 0;
            for (offset = 11; offset <= 114; offset++)
            {
                Dose dose = new Dose();
                if (batchData[offset] > 0)
                {
                    if (regionId == 1) //North America
                    {
                        dose.Quantity = batchData[offset].ToString();
                    }
                    else if (regionId == 2) //Europe / Middle East / Africa
                    {
                        if (offset >= 11 && offset <= 106)
                        {
                            dose.Quantity = UnitConversion.ConvertUnit(UnitConversion.Units.MilliLitre, batchData[offset]).ToString();
                            dose.IsMainEquipment = "0";
                        }
                        else if (offset >= 107 && offset <= 114)
                        {
                            dose.Quantity = UnitConversion.ConvertUnit(UnitConversion.Units.Gram, batchData[offset]).ToString();
                            dose.IsMainEquipment = "1";
                        }
                    }
                    //dose.Time = (Convert.ToInt16(str.Substring(0, 2))).ToString();
                    dose.Number = dosingPump.ToString();
                    dose.Point = dosingPoint.ToString();
                    tunnelProd.dose.Add(dose);
                }
                dosingRange++;
                dosingPoint++;
                if (dosingRange == 5)
                {
                    dosingRange = 1;
                    dosingPoint = 1;
                    dosingPump++;
                }
            }
        }
        /// <summary>
        /// This function will fetch batch water consumption data into batch object
        /// </summary>
        private static TunnelData ProcessTunnelWasherConsumptionData(int regionId, ushort[] batchData, TunnelData tunnelProd)
        {
            int waterConsumptionCounter = 1;
            int offset;
            //Process Water Consumption data
            for (offset = 119; offset <= 124; offset++)
            {
                WaterConsumption wc = new WaterConsumption();
                wc.Counter = waterConsumptionCounter.ToString();
                wc.Value = "0";
                if (batchData[offset] > 0)
                {
                    if (regionId == 1) //North America
                    {
                        wc.Value = batchData[offset].ToString();
                    }
                    else if (regionId == 2) //Europe / Middle East / Africa
                    {
                        wc.Value = UnitConversion.ConvertUnit(UnitConversion.Units.Litre, batchData[offset]).ToString();
                    }
                }
                tunnelProd.WaterConsumption.Add(wc);
                waterConsumptionCounter++;
            }
            waterConsumptionCounter = 1;
            tunnelProd.RunTime = 0;
            for (offset = 125; offset <= 149; offset++)
            {
                CompartmentTime ct = new CompartmentTime();
                ct.CompartmentNo = waterConsumptionCounter.ToString();
                ct.Time = batchData[offset].ToString();
                tunnelProd.TimeCompartment.Add(ct);
                tunnelProd.RunTime = tunnelProd.RunTime + Convert.ToInt64(tunnelProd.TimeCompartment[waterConsumptionCounter - 1].Time);
                waterConsumptionCounter++;
            }
            if (tunnelProd.RunTime <= 0)
            {
                TimeSpan diff = Convert.ToDateTime(tunnelProd.EndDateTime) - Convert.ToDateTime(tunnelProd.StartDateTime);
                tunnelProd.RunTime = Convert.ToInt64(diff.TotalSeconds);
            }
            if (tunnelProd.RunTime > 350000)
                tunnelProd.RunTime = 350000;
            if (batchData[150] != 0)
            {
                tunnelProd.Phstatus = (Convert.ToInt32(batchData[151] / 10000)).ToString();
                tunnelProd.Phvalue = (batchData[151] - (Convert.ToInt64(tunnelProd.Phstatus) * 10000)).ToString();
                tunnelProd.Phvalue = (Convert.ToInt32(tunnelProd.Phvalue) / 10).ToString();
            }
            else
            {
                tunnelProd.Phstatus = null;
                tunnelProd.Phvalue = null;
            }
            if (batchData[151] != 0)
            {
                string strLF = GetWordfromInt(batchData[152]).ToString();
                //tunnelProd.LFStatus = Convert.ToInt32(strLF.Substring(7)).ToString();
                //tunnelProd.LFValue = Convert.ToInt32(strLF.Substring(0, 7)).ToString();
                tunnelProd.LFStatus = Convert.ToInt32(strLF.Substring(strLF.Length - 1)).ToString();
                tunnelProd.LFValue = Convert.ToInt32(strLF.Substring(0, strLF.Length - 1)).ToString();
            }
            else
            {
                tunnelProd.LFStatus = null;
                tunnelProd.LFValue = null;
            }
            waterConsumptionCounter = 1;
            for (offset = 152; offset <= 163; offset = offset + 2)
            {
                string strTemp = GetWordfromInt(batchData[offset]);
                TemperatureData td = new TemperatureData();
                if (!String.IsNullOrEmpty(strTemp))
                {
                    if (regionId == 1) //North America
                    {
                        td.Status = (Convert.ToInt32(batchData[offset] / 10000)).ToString();
                        td.Minimum = ((batchData[offset] - (Convert.ToInt64(td.Status) * 10000)) / 10).ToString();
                        td.Maximum = (batchData[offset + 1] / 10).ToString();
                    }
                    else if (regionId == 2) //Europe / Middle East / Africa
                    {
                        td.Status = (Convert.ToInt32(batchData[offset] / 10000)).ToString();
                        if (batchData[offset] > 0)
                            td.Minimum = UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, Convert.ToUInt16((batchData[offset] - Convert.ToInt64(td.Status) * 10000) / 10)).ToString();
                        if (batchData[offset + 1] > 0)
                            td.Maximum = UnitConversion.ConvertUnit(UnitConversion.Units.Celsius, Convert.ToUInt16(batchData[offset + 1] / 10)).ToString();
                    }
                }
                else
                {
                    td.Status = null;
                    td.Minimum = null;
                    td.Maximum = null;
                }
                waterConsumptionCounter++;
                tunnelProd.temperature.Add(td);
            }
            return tunnelProd;
        }
        /// <summary>
        /// This function will convert from decimal value to binary
        /// </summary>
        /// <param name="val">The value.</param>
        /// <returns></returns>
        public static string GetWordfromInt(UInt16 val)
        {
            string word = Convert.ToString(val, 2);
            return word;
        }
        public static void SetPlcTime(BeckhoffController controller, BeckoffDataWriter dataWriter)
        {
            if (!String.IsNullOrEmpty(controller.AmsNetAddress))
            {
                //DataWriter<BeckhoffTag> dataWriter = new BeckoffDataWriter(new BeckhoffController { ControllerId = controller.ControllerId, Name = controller.TopicName }, mBeckhoffItemFormat, controller.AmsNetAddress, 801);
                List<BeckhoffTag> writetags = new List<BeckhoffTag>();
                BeckhoffTag opcTagYear = new BeckhoffTag { Address = "L_YEAR", Value = DateTime.Now.Year.ToString() };
                writetags.Add(opcTagYear);
                BeckhoffTag opcTagMonth = new BeckhoffTag { Address = "L_MNTH", Value = DateTime.Now.Month.ToString() };
                writetags.Add(opcTagMonth);
                BeckhoffTag opcTagDay = new BeckhoffTag { Address = "L_DAY", Value = DateTime.Now.Day.ToString() };
                writetags.Add(opcTagDay);
                BeckhoffTag opcTagHour = new BeckhoffTag { Address = "L_HOUR", Value = DateTime.Now.Hour.ToString() };
                writetags.Add(opcTagHour);
                BeckhoffTag opcTagMinute = new BeckhoffTag { Address = "L_MIN", Value = DateTime.Now.Minute.ToString() };
                writetags.Add(opcTagMinute);
                BeckhoffTag opcTagSec = new BeckhoffTag { Address = "L_SEC", Value = DateTime.Now.Second.ToString() };
                writetags.Add(opcTagSec);

                dataWriter.WriteTags(writetags);
            }
        }
        public static string GetPlcTime(BeckhoffController controller)
        {
            string plcDatetime = string.Empty;
            if (!String.IsNullOrEmpty(controller.AmsNetAddress))
            {
                DataReader<BeckhoffTag> dataReader = new Ecolab.Dcs.CollectData.Beckhoff.BeckhoffDataReader(new BeckhoffController { ControllerId = controller.ControllerId, Name = controller.TopicName }, BeckhoffFormatedItem, controller.AmsNetAddress, 801);
                List<BeckhoffTag> readtags = new List<BeckhoffTag>();
                BeckhoffTag opcTagDay = new BeckhoffTag { Address = "L_DAY", SizetoRead = 80 };
                readtags.Add(opcTagDay);
                BeckhoffTag opcTagMonth = new BeckhoffTag { Address = "L_MNTH", SizetoRead = 80 };
                readtags.Add(opcTagMonth);
                BeckhoffTag opcTagYear = new BeckhoffTag { Address = "L_YEAR", SizetoRead = 80 };
                readtags.Add(opcTagYear);
                BeckhoffTag opcTagHour = new BeckhoffTag { Address = "L_HOUR", SizetoRead = 80 };
                readtags.Add(opcTagHour);
                BeckhoffTag opcTagMinute = new BeckhoffTag { Address = "L_MIN", SizetoRead = 80 };
                readtags.Add(opcTagMinute);
                BeckhoffTag opcTagSec = new BeckhoffTag { Address = "L_SEC", SizetoRead = 80 };
                readtags.Add(opcTagSec);
                BeckhoffTag[] resultread = dataReader.ReadTags(readtags).ToArray();
                if (int.Parse(resultread[0].Value) < 10)
                {
                    resultread[0].Value = "0" + resultread[0].Value;
                }
                if (int.Parse(resultread[1].Value) < 10)
                {
                    resultread[1].Value = "0" + resultread[1].Value;
                }
                plcDatetime = resultread[0].Value + "-" + resultread[1].Value + "-" + resultread[2].Value;
            }
            return plcDatetime;
        }
        /// <summary>
        /// This function will serialize mycontrol tunnel batch data
        /// </summary>
        /// <param name="PlcDate">The PLC date.</param>
        /// <param name="PlcTime">The PLC time.</param>
        /// <returns>Returns Converted Plc Date Time</returns>
        public static string ConvertPlcDateTime(ushort PlcDate, ushort PlcTime)
        {
            if (PlcDate == 0) return string.Empty;
            int intDay = PlcDate & 31; //&H1F
            int intHelp = PlcDate >> 5;
            int intMonth = intHelp & 15;// &HF   //intMonth = intHelp And &HF
            int intYear = PlcDate >> 9;
            if (intYear >= 0 && intYear <= 29) intYear += 2000;
            else if (intYear >= 30 && intYear <= 99) intYear += 1900;
            int intSecond = PlcTime & 31;// &H1F
            intHelp = PlcTime >> 5;
            int intMinute = intHelp & 63; // &H3F
            int intHour = PlcTime >> 11;
            DateTime dateValue = new DateTime(intYear, intMonth, intDay, intHour, intMinute, intSecond);
            dateValue = TimeZoneInfo.ConvertTimeToUtc(dateValue);
            string datestring = dateValue.ToString("MM/dd/yyyy HH:mm:ss", new System.Globalization.CultureInfo("en-US"));
            return datestring;
        }
        public static string ConvertPlcDateTime(ushort PlcDate)
        {
            if (PlcDate == 0) return string.Empty;
            int intDay = PlcDate & 31; //&H1F
            int intHelp = PlcDate >> 5;
            int intMonth = intHelp & 15;// &HF   //intMonth = intHelp And &HF
            int intYear = PlcDate >> 9;
            if (intYear >= 0 && intYear <= 29) intYear += 2000;
            else if (intYear >= 30 && intYear <= 99) intYear += 1900;
            DateTime dateValue = new DateTime(intYear, intMonth, intDay);
            dateValue = TimeZoneInfo.ConvertTimeToUtc(dateValue);
            string datestring = dateValue.ToString("DD.MM.yyyy", new System.Globalization.CultureInfo("en-US"));
            return datestring;
        }
        /// <summary>
        /// This function will read online batch data from PLC
        /// </summary>
        /// <param name="controller">The controller.</param>
        public void ReadOnlineData(BeckhoffController controller, BeckhoffDataReader reader)
        {
            try
            {
                int TunnelNumber = 0;
                List<BeckhoffTag> tunOnlineTags = new List<BeckhoffTag> { new BeckhoffTag { Address = StoreDataTun, TagItemType = UIInputType.TypeArray, TagType = "uint", SizetoRead = SizeStoreDataTun } };
                tunOnlineTags[0].BatchData = new List<ushort>(new ushort[8350]); //new ushort[8350];
                IList<BeckhoffTag> tunOnlineBatch = reader.ReadTags(tunOnlineTags);
                if (tunOnlineBatch != null)
                {
                    Log.InfoFormat("Reading Tunnel Washer Online batch data for myControl Controller {0}", controller.ControllerId);
                    ushort[] tunOnlineData = new ushort[4175];
                    int offset = 0;
                    //Fetching first tunnel washer readings
                    for (int j = offset; j < 4175; j++)
                    {
                        tunOnlineData[j] = tunOnlineBatch[0].BatchData[j];
                    }
                    TunnelNumber = 1;
                    try
                    {
                    RegisterWasher(controller, TunnelNumber, tunOnlineData, true, 0, 0, reader);
                    }
                    catch(Exception ex) {
                        Log.Error("Error occured" + controller.TopicName, ex);

                    }
                    offset = 0;
                    int k = 0;
                    //Fetching second tunnel washer readings
                    for (int j = 4175; j < 8350; j++)
                    {
                        tunOnlineData[k] = tunOnlineBatch[0].BatchData[j];
                        k++;
                    }
                    TunnelNumber = 2;
                    RegisterWasher(controller, TunnelNumber, tunOnlineData, true, 0, 0, reader);
                }
            }
            catch (Exception ex)
            {
                Log.Error("Error occured:" + controller.TopicName, ex);
            }
        }
        /// <summary>
        /// This function will read production batch data from PLC
        /// </summary>
        /// <param name="controller">The controller.</param>
        public void ReadProductionData(BeckhoffController controller, BeckhoffDataReader reader, BeckoffDataWriter dataWriter)
        {
            try
            {
                int TunnelNumber = 0;
                int index = 0;
                List<BeckhoffTag> readTunProdTags = new List<BeckhoffTag> { new BeckhoffTag { Address = StoreProdDataTun, TagItemType = UIInputType.TypeArray, TagType = "uint", SizetoRead = SizeStoreProdDataTun } };
                readTunProdTags[0].BatchData = new List<ushort>(new ushort[1670]); //new ushort[1670];
                //Read the Production Tunnel data from MyControl Controller
                //Read Production Pointer and Read Pointer from MyControl Controller
                var tunProdTags = new List<BeckhoffTag>
                {
                    new BeckhoffTag { Address = StorePointerTUN, TagItemType = UIInputType.TypeInt, TagType = "uint", SizetoRead = SizeStorePointerTUN },
                    new BeckhoffTag { Address = StorePointerTUNR, TagItemType = UIInputType.TypeInt, TagType = "uint", SizetoRead =  SizeStorePointerTUNR }
                };
                IList<BeckhoffTag> plcPtrs = reader.ReadTags(tunProdTags);
                if (plcPtrs != null)
                {
                    //Log.InfoFormat("Reading PLC Pointer {0} and Read Pointer {1] for myControl Controller {2}", plcPtrs[0].Value, plcPtrs[1].Value, controller.ControllerId);
                    int plcPtr = Convert.ToInt16(plcPtrs[0].Value);
                    int readPtr = Convert.ToInt16(plcPtrs[1].Value);
                    ushort[] tunProdData = new ushort[167];
                    IList<BeckhoffTag> tunProdBatch = new List<BeckhoffTag>();
                    BeckhoffTag tag = new BeckhoffTag() { BatchData = new List<ushort>(167) }; //new ushort[167] };
                    tunProdBatch.Add(tag);
                    //Read Production Tunnel Batch Data                    
                        #region Read production tunnel batch data   
                        if (readPtr == 0) //read all the batches upto 10
                        {
                            if (plcPtr == 10)
                            {
                                readPtr = 1;
                                tunProdBatch = reader.ReadTags(readTunProdTags);
                                Log.InfoFormat("Reading Tunnel Washer Production Tag {0} data at PLC Pointer {1} and Read Pointer {2} for myControl Controller {3}", tunProdBatch[0].BatchData, plcPtr, readPtr, controller.ControllerId);
                                for (int j = 0; j < 167; j++)
                                {
                                    tunProdData[j] = tunProdBatch[0].BatchData[j];
                                }
                                RegisterWasher(controller, TunnelNumber, tunProdData, false, plcPtr, readPtr, reader);

                                WriteandReadPtrs(readPtr, dataWriter, controller.ControllerId);
                            }
                            else
                            {
                                readPtr = plcPtr + 1;
                                tunProdBatch = reader.ReadTags(readTunProdTags);
                                Log.InfoFormat("Reading Tunnel Washer Production Tag {0} data at PLC Pointer {1} and Read Pointer {2} for myControl Controller {3}", tunProdBatch[0].BatchData, plcPtr, readPtr, controller.ControllerId);
                                index = readPtr * 167;
                                for (int j = index; j < (index + 167); j++)
                                {
                                    tunProdData[j - index] = tunProdBatch[0].BatchData[j];
                                }
                                RegisterWasher(controller, TunnelNumber, tunProdData, false, plcPtr, readPtr, reader);
                                //Update read pointer to PLC
                                WriteandReadPtrs(readPtr, dataWriter, controller.ControllerId);
                            }
                        }
                        else
                        {
                            if (readPtr < 10)
                            {
                                readPtr = readPtr + 1; //read the next one
                                tunProdBatch = reader.ReadTags(readTunProdTags);
                                Log.InfoFormat("Reading Tunnel Washer Production Tag {0} data at PLC Pointer {1} and Read Pointer {2} for myControl Controller {3}", tunProdBatch[0].BatchData, plcPtr, readPtr, controller.ControllerId);
                                index = (readPtr - 1) * 167;
                                for (int j = index; j < (index + 167); j++)
                                {
                                    tunProdData[j - index] = tunProdBatch[0].BatchData[j];
                                }
                                RegisterWasher(controller, TunnelNumber, tunProdData, false, plcPtr, readPtr, reader);

                                //Update read pointer to PLC
                                WriteandReadPtrs(readPtr, dataWriter, controller.ControllerId);
                            }
                            else
                            {
                                readPtr = 1;
                                tunProdBatch = reader.ReadTags(readTunProdTags);
                                Log.InfoFormat("Reading Tunnel Washer Production Tag {0} data at PLC Pointer {1} and Read Pointer {2} for myControl Controller {3}", tunProdBatch[0].BatchData, plcPtr, readPtr, controller.ControllerId);
                                for (int j = 0; j < 167; j++)
                                {
                                    tunProdData[j] = tunProdBatch[0].BatchData[j];
                                }
                                RegisterWasher(controller, TunnelNumber, tunProdData, false, plcPtr, readPtr, reader);
                                //Update read pointer to PLC
                                WriteandReadPtrs(readPtr, dataWriter, controller.ControllerId);
                            }
                        }
                        #endregion
                    if (plcPtr == readPtr)
                    {
                        //Log.InfoFormat("Reading PLC Pointer {0} and Read Pointer {1] for myControl Controller {2}", plcPtrs[0].Value, plcPtrs[1].Value, controller.ControllerId);
                        Log.InfoFormat("No Historical Batches to read from PLC");
                    }
                }
            }
            catch (Exception)
            {
            }
        }
        /// <summary>
        /// This is the top level function for processing all online alarms for my control plc
        /// </summary>
        /// <param name="controller">The controller.</param>
        private void ReadAndProcessOnlineAlarmData(BeckhoffController controller, BeckhoffDataReader reader)
        {
            ReadAndProcessGeneralAlarms(controller, reader);
            ReadAndProcessWEAlarms(controller, reader);
            ReadAndProcessTunnelAlarms(controller, reader);
        }
        /// <summary>
        /// Reads the general alarms from my control PLC for the given
        /// controller and gets the active alarm details. Then prepares
        /// alarm detail xml for each active alarm and calls the
        /// stored procedure for populating it in alarmdata table.
        /// There are two arrays to read these alarm details.
        /// I. x_AlarmGeneral[147]: This array holds all the possible 147 alarms (alarm numbers from 1 to 147).
        /// Whenever any alarm is active then that particular alarm in the array will be set to true
        /// II. uint_AlarmDataGeneral[147,8]: Each alarm will contain following 8 parameters which will give the information about the alarm.
        /// 1.	Start Date
        /// 2.	Start Time
        /// 3.	Machine number
        /// 4.	Batch number
        /// 5.	Program number
        /// 6.	Desired value
        /// 7.	Measured value
        /// 8.	Status
        /// This function will read the active alarms from first array, and for each active alarm will get the
        /// all the above 8 parameters and create an alarm in enVision system.
        /// </summary>
        /// <param name="controller">The Beckhoff Controller.</param>
        /// <param name="reader">The Beckhoff DataReader.</param>
        private void ReadAndProcessGeneralAlarms(BeckhoffController controller, BeckhoffDataReader reader)
        {
            if (String.IsNullOrEmpty(controller.AmsNetAddress)) return;
            List<BeckhoffTag> activeAlarmTag = new List<BeckhoffTag> { new BeckhoffTag { Address = AlarmGeneral, SizetoRead = SizeAlarmGeneral, TagItemType = UIInputType.TypeArrayBoolean } };
            activeAlarmTag[0].arrayDataBoolean = new List<Boolean>(new Boolean[200]); //new Boolean[200];
            IList<BeckhoffTag> alarmData = reader.ReadTags(activeAlarmTag);
            List<BeckhoffTag> alarmDetailTag = new List<BeckhoffTag> { new BeckhoffTag { Address = AlarmDataGeneral, SizetoRead = SizeAlarmDataGeneral, TagItemType = UIInputType.TypeArray } };
            alarmDetailTag[0].BatchData = new List<ushort>(new ushort[200 * 8]); //new ushort[200 * 8];
            IList<BeckhoffTag> alarmDetailsData = reader.ReadTags(alarmDetailTag);
            for (int index = 0; index < alarmData[0].arrayDataBoolean.Count(); index++)
            {
                //Get only active alarms
                if (alarmData[0].arrayDataBoolean[index] == true)
                {
                    int offset;
                    //each alarm will contain 8 parameters
                    //so the offset of each alarm will be index of alarm * 8.
                    //Suppose alarm 1 and 20 are active, then
                    //for alarm 1, the offset to read 8 parameters will be 0 * 8 = 0, so from 0 to 7
                    //for alarm 10, the offset to read 8 parameters will be 9 * 8 = 72, so from 72 to 79
                    offset = index * 8;
                    int AlarmID = ConvertAlarmNb(index + 1);
                    //int AlarmID_HELMS = ConvertAlarmNb_myControl(AlarmID);
                    ProcessActiveAlarmData(alarmDetailsData[0].BatchData, offset, AlarmID, controller.ControllerId, false, false);
                }
            }
        }
        /// <summary>
        /// Reads the Washer extracter alarms from my control PLC for the given
        /// controller and gets the active alarm details. Then prepares
        /// alarm detail xml for each active WE alarm and calls the
        /// stored procedure for populating it in alarmdata table.
        /// There are two arrays to read these alarm details.
        /// I. x_AlarmWE[1..16,8]: This array holds all the possible 8 alarms for 16 washers (alarm numbers from 1 to 8).
        /// Whenever any WE alarm is active then that particular alarm in the array will be set to true
        /// II. uint_AlarmDataWE[16,8,8]: Each alarm will contain following 8 parameters which will give the information about the alarm.
        /// 1.	Start Date
        /// 2.	Start Time
        /// 3.	Machine number
        /// 4.	Batch number
        /// 5.  Program number
        /// 6.	Desired value
        /// 7.	Measured value
        /// 8.	Status
        /// This function will read the active WE alarms from first array, and for each active WE alarm will get the
        /// all the above 8 parameters and create an alarm in enVision system.
        /// </summary>
        /// <param name="controller">The controller Value for WEAlarms.</param>
        /// <param name="reader">The reader Value for WEAlarms.</param>
        private void ReadAndProcessWEAlarms(BeckhoffController controller, BeckhoffDataReader reader)
        {
            if (String.IsNullOrEmpty(controller.AmsNetAddress))
                return;
            List<BeckhoffTag> activeAlarmTag = new List<BeckhoffTag> { new BeckhoffTag { Address = AlarmWE, SizetoRead = SizeAlarmWE, TagItemType = UIInputType.TypeArrayBoolean } };
            activeAlarmTag[0].arrayDataBoolean = new List<Boolean>(new Boolean[16 * 15]); //new Boolean[16 * 15];
            IList<BeckhoffTag> alarmData = reader.ReadTags(activeAlarmTag);
            List<BeckhoffTag> alarmDetailTag = new List<BeckhoffTag> { new BeckhoffTag { Address = AlarmDataWE, SizetoRead = SizeAlarmDataWE, TagItemType = UIInputType.TypeArray } };
            alarmDetailTag[0].BatchData = new List<ushort>(new ushort[16 * 15 * 8]); //new ushort[16 * 15 * 8];
            IList<BeckhoffTag> alarmDetailsData = reader.ReadTags(alarmDetailTag);
            int alarmIndex = 251;
            for (int washerNo = 0; washerNo < 16; washerNo++)
            {
                //Get only active alarms
                int washerOffset, activeAlarmOffset;
                //There are 16 washers and each washer is having 8 alarms
                //so for each washer offset starts at washerNo * 8
                washerOffset = washerNo * 8;
                for (int activeIndex = 0; activeIndex < 15; activeIndex++)
                {
                    if (alarmData[0].arrayDataBoolean[washerOffset + activeIndex] == true)
                    {
                        //There are 16 washers, and each washer has 8 alarms
                        //and each alarm has 8 parameters.
                        //For Ex: For washer 2 (array index will be 1 since index starts from 0), the active alarms are 1, 3 then 
                        //for alarm 1, activeAlarmOffset = (8 + 0) * 8 = 64 (the position to read is 64, so alarm parameters are from 64 to 71)
                        //for alarm 3, activeAlarmOffset = (8 + 2) * 8 = 80 (the position to read is 80, so alarm parameters are from 80 to 87)
                        activeAlarmOffset = (washerOffset + activeIndex) * 8;
                        int AlarmID = ConvertAlarmNb(alarmIndex);
                        //int AlarmID_HELMS = ConvertAlarmNb_myControl(AlarmID);
                        ProcessActiveAlarmData(alarmDetailsData[0].BatchData, activeAlarmOffset, AlarmID, controller.ControllerId, false, false);
                    }
                    alarmIndex++;
                }
            }
        }
        /// <summary>
        /// Reads the Tunnel alarms from my control PLC for the given
        /// controller and gets the active alarm details. Then prepares
        /// alarm detail xml for each active Tunnel alarm and calls the
        /// stored procedure for populating it in alarmdata table.
        /// There are two arrays to read these alarm details.
        /// I. x_AlarmTUN[1..2,15]: This array holds all the possible 15 alarms for 2 tunnels(alarm numbers from 1 to 15).
        /// Whenever any Tunnel alarm is active then that particular alarm in the array will be set to true
        /// II. uint_AlarmDataTUN[2,15,8]: Each alarm will contain following 8 parameters which will give the information about the alarm.
        /// 1.	Start Date
        /// 2.	Start Time
        /// 3.	Machine number
        /// 4.	Batch number
        /// \    5.	Program number
        /// 6.	Desired value
        /// 7.	Measured value
        /// 8.	Status
        /// This function will read the active Tunnel alarms from first array, and for each active Tunnel alarm will get the
        /// all the above 8 parameters and create an alarm in enVision system.
        /// </summary>
        /// <param name="controller">The controller Value for TunnelAlarms.</param>
        /// <param name="reader">The reader Value for TunnelAlarms.</param>
        private void ReadAndProcessTunnelAlarms(BeckhoffController controller, BeckhoffDataReader reader)
        {
            if (String.IsNullOrEmpty(controller.AmsNetAddress))
                return;
            List<BeckhoffTag> activeAlarmTag = new List<BeckhoffTag> { new BeckhoffTag { Address = AlarmTUN, SizetoRead = SizeAlarmTUN, TagItemType = UIInputType.TypeArrayBoolean } };
            activeAlarmTag[0].arrayDataBoolean = new List<Boolean>(new Boolean[2 * 25]); //new Boolean[2 * 25];
            IList<BeckhoffTag> alarmData = reader.ReadTags(activeAlarmTag);
            List<BeckhoffTag> alarmDetailTag = new List<BeckhoffTag> { new BeckhoffTag { Address = AlarmDataTUN, SizetoRead = SizeAlarmDataTUN, TagItemType = UIInputType.TypeArray } };
            alarmDetailTag[0].BatchData = new List<ushort>(new ushort[2 * 25 * 8]); //new ushort[2 * 25 * 8];
            IList<BeckhoffTag> alarmDetailsData = reader.ReadTags(alarmDetailTag);
            int alarmIndex = 201;
            for (int washerNo = 0; washerNo < 2; washerNo++)
            {
                //Get only active alarms
                int washerOffset, activeAlarmOffset;
                //There are 2 washers(tunnels) and each washer is having 15 alarms
                //so for each washer offset starts at washerNo * 15
                washerOffset = washerNo * 25;
                for (int activeIndex = 0; activeIndex < 25; activeIndex++)
                {
                    if (alarmData[0].arrayDataBoolean[washerOffset + activeIndex] == true)
                    {
                        //There are 2 washers(tunnels), and each washer has 15 alarms
                        //and each alarm has 8 parameters.
                        //For Ex: For washer 2 (array index will be 1 since index starts from 0), the active alarms are 1, 3 then 
                        //for alarm 1, activeAlarmOffset = (15 + 0) * 8 = 120 (the position to read is 120, so alarm parameters are from 120 to 127)
                        //for alarm 3, activeAlarmOffset = (15 + 2) * 8 = 136 (the position to read is 136, so alarm parameters are from 136 to 143)
                        activeAlarmOffset = (washerOffset + activeIndex) * 8;
                        int AlarmID = ConvertAlarmNb(alarmIndex);
                        //int AlarmID_HELMS = ConvertAlarmNb_myControl(AlarmID);
                        ProcessActiveAlarmData(alarmDetailsData[0].BatchData, activeAlarmOffset, AlarmID, controller.ControllerId, false, true);
                    }
                    alarmIndex++;
                }
            }
        }
        /// <summary>
        /// This function will prepares the xml based on alarm details and
        /// calls the stored procedure for creating an alarm in enVision system.
        /// </summary>
        /// <param name="batchData">The batch data.</param>
        /// <param name="offset">The offset for Alarm.</param>
        /// <param name="alarmNumber">The alarm number.</param>
        /// <param name="controllerId">The controller identifier.</param>
        /// <param name="prod">if set to <c>true</c> [product].</param>
        /// <param name="isTunnel">if set to <c>true</c> [is tunnel].</param>
        private void ProcessActiveAlarmData(List<ushort> batchData, int offset, int alarmNumber, int controllerId, Boolean prod = true, Boolean isTunnel = false)
        {
            MyControlAlarmData myControlAlarmData = new MyControlAlarmData();
            if (batchData[offset] > 0)
                myControlAlarmData.StartDateTime = ConvertPlcDateTime(batchData[offset], batchData[offset + 1]);
            myControlAlarmData.MachineNumber = batchData[offset + 2].ToString();
            myControlAlarmData.BatchNumber = batchData[offset + 3].ToString();
            myControlAlarmData.ProgramNumber = batchData[offset + 4].ToString();
            myControlAlarmData.DesiredValue = batchData[offset + 5].ToString();
            myControlAlarmData.MeasuredValue = batchData[offset + 6].ToString();
            myControlAlarmData.Status = batchData[offset + 7].ToString();
            if (prod)
            {
                if (batchData[offset + 8] > 0)
                    myControlAlarmData.StopDateTime = ConvertPlcDateTime(batchData[offset + 8], batchData[offset + 9]);
            }
            if (isTunnel)
            {
                myControlAlarmData.IsTunnel = "1";
            }
            else
            {
                myControlAlarmData.IsTunnel = "0";
            }
            myControlAlarmData.AlarmNumber = alarmNumber.ToString();
            string xmlString = string.Empty;
            xmlString = SerializeXMLData(AlarmDataSerializer, myControlAlarmData);
            Log.InfoFormat("Inserting general alarms for controller: {0} - xml : {1}", controllerId, xmlString);
            //Calling the SP to insert general alarm details in alarmdata table
            DataReaderAccess.ProcessMyControlAlarmData(controllerId, xmlString);
        }
        private static int ConvertAlarmNb(int AlarmNb)
        {
            int ConvertAlarmNb;
            int int_Diff;
            int int_Merker = 0;
            if (AlarmNb <= 200) //General Alarms
            {
                ConvertAlarmNb = AlarmNb;
            }
            else if (AlarmNb <= 250) //Tunnel Alarms
            {
                int_Diff = AlarmNb - 200;
                int_Merker = (int)(int_Diff / 31);
                int_Merker = int_Diff - (int_Merker * 31);
                ConvertAlarmNb = 300 + int_Merker;
            }
            else //Washer Extracter Alarms
            {
                int_Diff = AlarmNb - 250;
                int_Merker = (int)(int_Diff / 8);
                int_Merker = int_Diff - (int_Merker * 8);
                ConvertAlarmNb = 200 + int_Merker;
            }
            return ConvertAlarmNb;
        }
        //private int ConvertAlarmNb_myControl(int AlarmNb)
        //{
        //    int ConvertAlarmNb_myControl = 0;
        //    switch (AlarmNb)
        //    {
        //        case 1:
        //            ConvertAlarmNb_myControl = 178;
        //            break;
        //        case 2:
        //            ConvertAlarmNb_myControl = 143;
        //            break;
        //        case 3:
        //            ConvertAlarmNb_myControl = 164;
        //            break;
        //        case 4:
        //            ConvertAlarmNb_myControl = 152;
        //            break;
        //        case 5:
        //            ConvertAlarmNb_myControl = 163;
        //            break;
        //        case 6:
        //            ConvertAlarmNb_myControl = 179;
        //            break;
        //        case 7:
        //            ConvertAlarmNb_myControl = 180;
        //            break;
        //        case 8:
        //            ConvertAlarmNb_myControl = 121;
        //            break;
        //        case 9:
        //            ConvertAlarmNb_myControl = 120;
        //            break;
        //        case 104:
        //        case 109:
        //            ConvertAlarmNb_myControl = 104;
        //            break;
        //        case 105:
        //        case 110:
        //            ConvertAlarmNb_myControl = 105;
        //            break;
        //        case 106:
        //        case 111:
        //            ConvertAlarmNb_myControl = 107;
        //            break;
        //        case 107:
        //        case 112:
        //            ConvertAlarmNb_myControl = 108;
        //            break;
        //        case 108:
        //        case 113:
        //            ConvertAlarmNb_myControl = 181;
        //            break;
        //        //WE Alarms
        //        case 201:
        //            ConvertAlarmNb_myControl = 162;
        //            break;
        //        case 202:
        //            ConvertAlarmNb_myControl = 15;
        //            break;
        //        case 203:
        //            ConvertAlarmNb_myControl = 184;
        //            break;
        //        case 204:
        //            ConvertAlarmNb_myControl = 157;
        //            break;
        //        case 205:
        //            ConvertAlarmNb_myControl = 158;
        //            break;
        //        case 206:
        //            ConvertAlarmNb_myControl = 404;
        //            break;
        //        //TUN Alarms
        //        case 301:
        //            ConvertAlarmNb_myControl = 149;
        //            break;
        //        case 302:
        //            ConvertAlarmNb_myControl = 174;
        //            break;
        //        case 303:
        //            ConvertAlarmNb_myControl = 400;
        //            break;
        //        case 304:
        //            ConvertAlarmNb_myControl = 401;
        //            break;
        //        case 305:
        //            ConvertAlarmNb_myControl = 142;
        //            break;
        //        case 306:
        //        case 307:
        //        case 308:
        //        case 309:
        //        case 310:
        //        case 311:
        //            ConvertAlarmNb_myControl = 153;
        //            break;
        //        case 312:
        //            ConvertAlarmNb_myControl = 402;
        //            break;
        //        case 313:
        //            ConvertAlarmNb_myControl = 403;
        //            break;
        //        case 314:
        //            ConvertAlarmNb_myControl = 141;
        //            break;
        //        case 315:
        //            ConvertAlarmNb_myControl = 185;
        //            break;
        //    }
        //    if(AlarmNb >= 10 && AlarmNb <= 23)
        //    {
        //        ConvertAlarmNb_myControl = 103;
        //    }
        //    else if(AlarmNb >= 24 && AlarmNb <= 25)
        //    {
        //        ConvertAlarmNb_myControl = 109;
        //    }
        //    else if(AlarmNb >= 26 && AlarmNb <= 51)
        //    {
        //        ConvertAlarmNb_myControl = 101;
        //    }
        //    else if(AlarmNb >= 52 && AlarmNb <= 77)
        //    {
        //        ConvertAlarmNb_myControl = 156;
        //    }
        //    else if(AlarmNb >= 78 && AlarmNb <= 103)
        //    {
        //        ConvertAlarmNb_myControl = 155;
        //    }
        //    if(ConvertAlarmNb_myControl == 0)
        //    {
        //        ConvertAlarmNb_myControl = AlarmNb;
        //    }
        //    return ConvertAlarmNb_myControl;
        //}
        private void ReadAndProcessOnlineProductDosing(BeckhoffController controller, BeckhoffDataReader reader)
        {
            if (String.IsNullOrEmpty(controller.AmsNetAddress)) return;
            List<BeckhoffTag> equipmentControlTag = new List<BeckhoffTag> { new BeckhoffTag { Address = EquipmentControl, SizetoRead = SizeEquipmentControl, TagItemType = UIInputType.TypeArray } };
            equipmentControlTag[0].BatchData = new List<ushort>(new ushort[26 * 8]); //new ushort[26 * 8];
            IList<BeckhoffTag> equipmentControlData = reader.ReadTags(equipmentControlTag);
            MyControlOnlineProductDosing myControlProductDosing = new MyControlOnlineProductDosing();
            for (int pumpNum = 0; pumpNum < 26; pumpNum++)
            {
                int pumpOffset = pumpNum * 8;
                if (equipmentControlData[0].BatchData[pumpOffset] > 0)
                {
                    myControlProductDosing.Time = equipmentControlData[0].BatchData[pumpOffset].ToString();
                    myControlProductDosing.DosingPoint = equipmentControlData[0].BatchData[pumpOffset + 2].ToString();
                    myControlProductDosing.DoseNumber = equipmentControlData[0].BatchData[pumpOffset + 3].ToString();
                    myControlProductDosing.ProgramNumber = equipmentControlData[0].BatchData[pumpOffset + 4].ToString();
                    myControlProductDosing.BatchNumber = equipmentControlData[0].BatchData[pumpOffset + 5].ToString();
                    myControlProductDosing.ValveNumber = equipmentControlData[0].BatchData[pumpOffset + 6].ToString();
                    myControlProductDosing.PumpNum = (pumpNum + 1).ToString();
                    if (controller.RegionID == 1)
                    {
                        myControlProductDosing.TheoreticalQty = equipmentControlData[0].BatchData[pumpOffset + 1].ToString();
                        myControlProductDosing.RealQty = equipmentControlData[0].BatchData[pumpOffset + 7].ToString();
                    }
                    else if (controller.RegionID == 2)
                    {
                        if (pumpNum >= 24 && pumpNum <= 25) //Main Equipment
                        {
                            myControlProductDosing.TheoreticalQty = UnitConversion.ConvertUnit(UnitConversion.Units.Gram, equipmentControlData[0].BatchData[pumpOffset + 1]).ToString();
                            myControlProductDosing.RealQty = UnitConversion.ConvertUnit(UnitConversion.Units.Gram, equipmentControlData[0].BatchData[pumpOffset + 7]).ToString();
                        }
                        else
                        {
                            myControlProductDosing.TheoreticalQty = UnitConversion.ConvertUnit(UnitConversion.Units.MilliLitre, equipmentControlData[0].BatchData[pumpOffset + 1]).ToString();
                            myControlProductDosing.RealQty = UnitConversion.ConvertUnit(UnitConversion.Units.MilliLitre, equipmentControlData[0].BatchData[pumpOffset + 7]).ToString();
                        }
                    }
                    string xmlString = string.Empty;
                    xmlString = SerializeXMLData(ProductDosingSerilzer, myControlProductDosing);
                    Log.InfoFormat("Inserting online dosing information for controller: {0} - xml : {1}", controller.ControllerId, xmlString);
                    DataReaderAccess.ProcessMyControlOnlineProductDosing(controller.ControllerId, xmlString);
                }
            }
        }
        #endregion
    }
}