﻿// -----------------------------------------------------------------------
// <copyright file="BeckhoffXmlService.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The BeckhoffXmlService </summary>
// -----------------------------------------------------------------------

using Entities.DataReader;
using Controller = Ecolab.Dcs.Entities.Controller;
using Timer = System.Timers.Timer;
using Washer = Ecolab.Dcs.Entities.Washer;

namespace Ecolab.Dcs.PlcDataReader
{
    using System;
    using System.Collections.Concurrent;
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.Threading;
    using System.Timers;
    using System.Xml;
    using System.Xml.Serialization;
    using Access.DataReader;
    using CollectData;
    using CollectData.Beckhoff;
    using Entities;
    using log4net;
    using Properties;
    using BeckhoffXmlTag = BeckhoffXmlTag;
    using Controller = Controller;
    using Timer = Timer;
    using Washer = Washer;

    public class BeckhoffXmlService
    {
        #region Variables
        private static readonly ILog Log = LogManager.GetLogger(typeof(BeckhoffXmlService));
        private List<BeckhoffController> beckhoffController;
        private static readonly string beckhoffItemFormat = Settings.Default.BeckhoffItemFormat;
        const string DateFormat = "yyyy-MM-ddTHH:mm:ss";
        private static readonly Dictionary<int, Queue<BeckhoffQueueItem>> QueueList = new Dictionary<int, Queue<BeckhoffQueueItem>>();
        object locker = new object();
        ManualResetEvent timerDead = new ManualResetEvent(false);
        private static bool isServiceStopping = false;
        private Timer timer;
        readonly ProcessRollup processRollup = new ProcessRollup();
        private static ConcurrentDictionary<string, BeckhoffDataReader> objreader = new ConcurrentDictionary<string, BeckhoffDataReader>();
        private static ConcurrentDictionary<string, BeckoffDataWriter> objwriter = new ConcurrentDictionary<string, BeckoffDataWriter>();
        private static bool ETechEnable;
        private static string ETechIPAddress;
        private static int ETechTimeDiff;
        private static string EtechCustomerCodesText;
        private static int FRMAWEFTimeDiff = Int32.Parse(Settings.Default.FRMAWEFDiff);
        #endregion

        #region Methods
        /// <summary>
        /// Initializes a new instance of the <see cref="BeckhoffXmlService"/> class.
        /// </summary>
        public BeckhoffXmlService()
        {
            //Get ETech default time from App config....
            timer = new Timer(Int32.Parse(Settings.Default.WebportReadInterval))
            {
                AutoReset = false
            };
            timer.Elapsed += OnTimedEvent;
            timer.Enabled = true;
        }

        /// <summary>
        /// Starts this instance.
        /// </summary>
        public void Start()
        {
            IEnumerable<global::Entities.DataReader.Controller> dbControllers = DataReaderAccess.GetActiveControllers();
            dbControllers = dbControllers.Where(c => c.ControllerTypeId == 2 && c.ControllerModelId != 7).ToList();
            List<Controller> controllers = dbControllers.Select(EntityConverter.Convert).ToList();
            beckhoffController = controllers.FindAll(c => c is BeckhoffController).Select(c => (BeckhoffController)c).ToList();
            Log.InfoFormat("Started Tracking Beckhoff {0} controller(s)", beckhoffController.Count);

            #region Get Plant Details
            global::Entities.Plant plantInfo = DataReaderAccess.GetPlantInfo();
            EtechCustomerCodesText = DataReaderAccess.GetETechConfigSettings();
            if (plantInfo != null)
            {
                ETechEnable = plantInfo.IsETechEnable;
                ETechIPAddress = plantInfo.EtechIpAddress;
                if (plantInfo.ETechTimeDiff > 0)
                {
                    ETechTimeDiff = plantInfo.ETechTimeDiff;
                }
                else
                {
                    ETechTimeDiff = Int32.Parse(Settings.Default.ETechDefaultTimeInterval);
                }
            }
            #endregion

            #region Beckhoff PLC connection management
            foreach (BeckhoffController controller in beckhoffController)
            {
                try
                {
                    if (isServiceStopping)
                    {
                        Log.Info("Service Stopped. Exiting BeckhOff XML Service.");
                        return;
                    }
                    if (!String.IsNullOrEmpty(controller.AmsNetAddress))
                    {

                        if (!objreader.ContainsKey(controller.AmsNetAddress))
                        {
                            objreader.GetOrAdd(controller.AmsNetAddress, new BeckhoffDataReader(controller, beckhoffItemFormat, controller.AmsNetAddress, controller.Comport));
                        }
                        if (!objwriter.ContainsKey(controller.AmsNetAddress))
                        {
                            objwriter.GetOrAdd(controller.AmsNetAddress, new BeckoffDataWriter(controller, beckhoffItemFormat, controller.AmsNetAddress, controller.Comport));
                        }
                        if (objreader.Count > 0 && objwriter.Count > 0)
                        {
                            InitializePlcContinuousRead(controller, objreader[controller.AmsNetAddress], objwriter[controller.AmsNetAddress]);
                        }
                    }
                    else
                    {
                        Log.ErrorFormat("Invalid AMSNet Address,Can't connect to PLC:{0} with ASMNet Address:{1}",
                            controller.TopicName, controller.AmsNetAddress);
                    }
                }
                catch (Exception ex)
                {
                    Log.InfoFormat("Failed to connect to IP Address {0} for Controller Id {1} and error is {2}", controller.AmsNetAddress, controller.ControllerId, ex.Message);
                    continue;
                }
            }
            #endregion
        }

        /// <summary>
        /// Stops this instance.
        /// </summary>
        public void Stop()
        {
            try
            {
                Log.Info("Beckhoff : Stopping Data Communication Service...");
                isServiceStopping = true;
                timerDead.WaitOne();
            }
            catch (Exception ex)
            {
                Log.Error("Failed to stop Data Communcation Service", ex);
            }
            finally
            {
                Log.InfoFormat("{0}: Service has been stopped.", "Data Communication Service");
            }
        }

        /// <summary>
        /// Called when [timed event].
        /// </summary>
        /// <param name="source">The source for OnTimedEvent.</param>
        /// <param name="e">The <see cref="ElapsedEventArgs"/> instance containing the event data.</param>
        private void OnTimedEvent(Object source, ElapsedEventArgs e)
        {
            try
            {
                timerDead.Reset();
                Start();
            }
            catch (Exception ex)
            {
                Log.Error("Failed to run Data Communcation Service", ex);
            }
            finally
            {
                lock (locker)
                {
                    timerDead.Set(); // allow service to stop
                    Log.Info("Signal set to indicate elapsed event to continue");
                }
                if (!isServiceStopping)	// restart the timer
                    timer.Start();
            }
        }

        /// <summary>
        /// Initializes the PLC continuous read.
        /// </summary>
        /// <param name="controller">The controller for InitializePlcContinuousRead.</param>
        /// <param name="dataReader">The data reader for InitializePlcContinuousRead.</param>
        /// <param name="dataWriter">The data writer for InitializePlcContinuousRead.</param>
        public void InitializePlcContinuousRead(BeckhoffController controller, BeckhoffDataReader dataReader, BeckoffDataWriter dataWriter)
        {
            try
            {
                SetPlcTime(controller, dataWriter);// set plc date and time

                //Writing time to L_HSTREQ to Beckhoff Controller
                List<BeckhoffTag> writetags = new List<BeckhoffTag>();
                if (controller.XmlDateTime == DateTime.MinValue)
                {
                    controller.XmlDateTime = DateTime.Now.AddHours(-6);
                }
                BeckhoffTag tagToWrite = new BeckhoffTag { Address = "L_HSTREQ", Value = controller.XmlDateTime.AddMinutes(-1).ToString("yyyy-MM-ddTHH:mm:ss"), SizetoRead = 80 };
                Log.InfoFormat("Writing datetime to L_HSTREQ Tag {0} for Controller {1}", controller.XmlDateTime.AddMinutes(-1), controller.ControllerId);
                writetags.Add(tagToWrite);
                dataWriter.WriteTags(writetags);
                //Read the XML from the Beckhoff Controller
                List<BeckhoffTag> readtags = new List<BeckhoffTag>();
                BeckhoffTag beckhoffTag = new BeckhoffTag { Address = "L_HSTXML", SizetoRead = 20000, TagItemType = UIInputType.TypeXml };
                readtags.Add(beckhoffTag);
                var reader = dataReader.ReadTags(readtags);

                if (reader != null)
                {
                    BeckhoffTag[] resultread = reader.ToArray();
                    string xml = resultread[0].Value;
                    Log.InfoFormat("Reading XML to L_HSTXML Tag {0} for Controller {1}", xml, controller.ControllerId);

                    List<BeckhoffXmlTag> totalXmlTags = GetBeckhoffXmlTags(xml);

                    if (totalXmlTags.Count != 0)
                    {
                        RegisterNowTags(controller, totalXmlTags);
                        RegisterWasher(controller, totalXmlTags, dataReader, dataWriter);
                        if (!isServiceStopping)
                        {
                            CommonDataOperations.UpdateWebportdatetime(controller.ControllerId, totalXmlTags.Last().DateTimestamp.ToLocalTime());
                        }
                        processRollup.Rollup();
                    }
                }
            }
            catch (Exception ex)
            {
                #region Dispose reader/writer
                if (!dataReader.IsConnected)
                {
                    BeckhoffDataReader tempreader;
                    objreader.TryRemove(controller.AmsNetAddress, out tempreader);
                    tempreader.StopPlcRead();
                }

                if (!dataWriter.IsConnected)
                {
                    BeckoffDataWriter tempwriter;
                    objwriter.TryRemove(controller.AmsNetAddress, out tempwriter);
                    tempwriter.StopPlcWrite();
                }
                #endregion
                Log.Error("Error occured:" + controller.TopicName, ex);
            }
        }

        /// <summary>
        /// Registers the now tags.
        /// </summary>
        /// <param name="controller">The controller.</param>
        /// <param name="beckhoffxmlTags">The beckhoffxml tags.</param>
        private static void RegisterNowTags(BeckhoffController controller, List<BeckhoffXmlTag> beckhoffxmlTags)
        {
            var lnowTagValues = GetAlarmTagsFromXML(controller,beckhoffxmlTags);
            
            var groupedNowTagValues =
                  lnowTagValues.OrderBy(t => t.TimeStamp).GroupBy(u => u.TimeStamp).Select(grp => new { nowList = grp.ToList() }).ToList();
            for (int p = 0; p < groupedNowTagValues.ToList().Count; p++)
            {
                TagProcessor.ProcessNowTags(groupedNowTagValues[p].nowList, controller);
            }
        }

        /// <summary>
        /// Sets the PLC time.
        /// </summary>
        /// <param name="controller">The controller .</param>
        /// <param name="dataWriter">The data writer .</param>
        public static void SetPlcTime(BeckhoffController controller, BeckoffDataWriter dataWriter)
        {
            if (!String.IsNullOrEmpty(controller.AmsNetAddress))
            {
                List<BeckhoffTag> writetags = new List<BeckhoffTag>();
                BeckhoffTag opcTagYear = new BeckhoffTag { Address = "L_YEAR", Value = DateTime.Now.Year.ToString() };
                writetags.Add(opcTagYear);
                BeckhoffTag opcTagMonth = new BeckhoffTag { Address = "L_MNTH", Value = DateTime.Now.Month.ToString() };
                writetags.Add(opcTagMonth);
                BeckhoffTag opcTagDay = new BeckhoffTag { Address = "L_DAY", Value = DateTime.Now.Day.ToString() };
                writetags.Add(opcTagDay);
                BeckhoffTag opcTagHour = new BeckhoffTag { Address = "L_HOUR", Value = DateTime.Now.Hour.ToString() };
                writetags.Add(opcTagHour);
                BeckhoffTag opcTagMinute = new BeckhoffTag { Address = "L_MIN", Value = DateTime.Now.Minute.ToString() };
                writetags.Add(opcTagMinute);
                BeckhoffTag opcTagSec = new BeckhoffTag { Address = "L_SEC", Value = DateTime.Now.Second.ToString() };
                writetags.Add(opcTagSec);

                dataWriter.WriteTags(writetags);
            }
        }

        /// <summary>
        /// Gets the PLC time.
        /// </summary>
        /// <param name="controller">The controller.</param>
        /// <returns>Returns the Plc Time</returns>
        public string GetPlcTime(BeckhoffController controller)
        {
            string plcDatetime = string.Empty;
            if (!String.IsNullOrEmpty(controller.AmsNetAddress))
            {
                DataReader<BeckhoffTag> dataReader = new BeckhoffDataReader(new BeckhoffController { ControllerId = controller.ControllerId, Name = controller.TopicName }, beckhoffItemFormat, controller.AmsNetAddress, 801);
                List<BeckhoffTag> readtags = new List<BeckhoffTag>();

                BeckhoffTag opcTagDay = new BeckhoffTag { Address = "L_DAY", SizetoRead = 80 };
                readtags.Add(opcTagDay);
                BeckhoffTag opcTagMonth = new BeckhoffTag { Address = "L_MNTH", SizetoRead = 80 };
                readtags.Add(opcTagMonth);
                BeckhoffTag opcTagYear = new BeckhoffTag { Address = "L_YEAR", SizetoRead = 80 };
                readtags.Add(opcTagYear);
                BeckhoffTag opcTagHour = new BeckhoffTag { Address = "L_HOUR", SizetoRead = 80 };
                readtags.Add(opcTagHour);
                BeckhoffTag opcTagMinute = new BeckhoffTag { Address = "L_MIN", SizetoRead = 80 };
                readtags.Add(opcTagMinute);
                BeckhoffTag opcTagSec = new BeckhoffTag { Address = "L_SEC", SizetoRead = 80 };
                readtags.Add(opcTagSec);

                BeckhoffTag[] resultread = dataReader.ReadTags(readtags).ToArray();
                if (int.Parse(resultread[0].Value) < 10)
                {
                    resultread[0].Value = "0" + resultread[0].Value;
                }
                if (int.Parse(resultread[1].Value) < 10)
                {
                    resultread[1].Value = "0" + resultread[1].Value;
                }
                plcDatetime = resultread[0].Value + "-" + resultread[1].Value + "-" + resultread[2].Value;
            }
            return plcDatetime;
        }

        /// <summary>
        /// Registers the washer.
        /// </summary>
        /// <param name="controller">The controller.</param>
        /// <param name="beckhoffxmlTags">The beckhoffxml tags.</param>
        /// <param name="dataReader">The data reader.</param>
        /// <param name="dataWriter">The data writer.</param>
        private static void RegisterWasher(BeckhoffController controller, List<BeckhoffXmlTag> beckhoffxmlTags, BeckhoffDataReader dataReader, BeckoffDataWriter dataWriter)
        {
            var controllerWashersTags = DataReaderAccess.GetActiveWashers(controller.ControllerId);
            IEnumerable<Washer> results = controllerWashersTags.GroupBy(p => new { p.WasherId, p.WasherName, p.WasherGroupTypeName, p.EndOfFormula, p.ETechWasherNumber, p.AWEAActive }).
                Select(g => new Washer
                {
                    WasherId = g.Key.WasherId,
                    Name = g.Key.WasherName,
                    IsTunnel = g.Key.WasherGroupTypeName == "Tunnel",
                    EndOFFormula = g.Key.EndOfFormula,
                    ETechWasherNumber = g.Key.ETechWasherNumber,
                    AWEAActive = g.Key.AWEAActive,
                    Tags = g.Select(m => new OpcTag
                    {
                        Address = m.TagAddress,
                        Topic = m.TopicName,
                        TagType = m.TagType,
                        TagId = m.TagId,
                        TagTypeId = m.TagTypeId
                    }).ToList<Tag>()
                });

            Washer[] enumerable = results as Washer[] ?? results.ToArray();
            for (int i = 0; i < enumerable.ToList().Count(); i++)
            {
                var lwasherTagValues = new List<BeckhoffTag>(); //To send details in BeckhoffTag Format XML

                Washer lwasher = new Washer
                {
                    WasherId = enumerable.ToList()[i].WasherId,
                    IsTunnel = enumerable.ToList()[i].IsTunnel,
                    EndOFFormula = enumerable.ToList()[i].EndOFFormula,
                    ETechWasherNumber = enumerable.ToList()[i].ETechWasherNumber,
                    AWEAActive = enumerable.ToList()[i].AWEAActive,
                };

                if (lwasher.IsTunnel)
                {
                    #region Tunnel
                    Queue<BeckhoffQueueItem> queue = null;
                    if (!QueueList.ContainsKey(lwasher.WasherId))
                    {
                        var tunnelStatusQueue = TagProcessor.GetTunnelStatus(lwasher.WasherId);
                        QueueList.Add(lwasher.WasherId, tunnelStatusQueue);
                    }
                    queue = QueueList[lwasher.WasherId];
                    var noOfCompartments = CommonDataOperations.GetNoOfCompartments(lwasher.WasherId, controller.ControllerId);
                    beckhoffxmlTags.RemoveAll(m => m.TagAddress == "L_NFRM");
                    for (int j = 0; j < enumerable.ToList()[i].Tags.Count(); j++)
                    {
                        for (int k = 0; k < beckhoffxmlTags.Count; k++)
                        {
                            if (beckhoffxmlTags[k].TagAddress == enumerable.ToList()[i].Tags[j].Address)
                            {
                                lwasherTagValues.Add(new BeckhoffTag
                                {
                                    Address = beckhoffxmlTags[k].TagAddress,
                                    Value = beckhoffxmlTags[k].Value,
                                    TimeStamp = beckhoffxmlTags[k].DateTimestamp.ToUniversalTime(),
                                    Topic = controller.TopicName,
                                    TagType = enumerable.ToList()[i].Tags[j].TagType,
                                    TagId = enumerable.ToList()[i].Tags[j].TagId,
                                    IsModified = true,
                                    Quality = "Good",
                                    ETechLastDroppedAt = enumerable.ToList()[i].Tags[j].ETechLastDroppedAt,
                                    CustomerCodes = enumerable.ToList()[i].Tags[j].CustomerCodes
                                });
                            }
                        }
                    }

                    foreach (BeckhoffTag tag in lwasherTagValues)
                    {
                        if (tag.TagType == "Tag_FRM" || tag.TagType == "Tag_AWEW")
                        {
                            if (tag.TagType == "Tag_FRM" && Convert.ToInt32(tag.Value) == lwasher.EndOFFormula)
                            {
                                continue;
                            }
                            Log.InfoFormat("ControllerId {0} WasherId {1} Address {2} Value {3} TimeStamp {4}", controller.ControllerId, lwasher.WasherId, tag.Address, tag.Value, tag.TimeStamp);
                            DataReaderAccess.ProcessBeckhoffArrayQueue(controller.ControllerId, lwasher.WasherId, tag.Address, tag.Value, tag.TimeStamp);
                            Log.InfoFormat("Storing Tunnel Washer tags to database table beckhoffarrayqueue {0}", lwasher.WasherId);
                        }
                    }

                    IEnumerable<BeckhoffXmlTag> getActiveBeckhofftagsgroup = DataReaderAccess.GetActiveBeckhoffArrayQueue(controller.ControllerId, lwasher.WasherId);
                    var lbeckhoffTagvalues = new List<BeckhoffTag>();
                    var lbeckhoffTagstoDelete = new List<BeckhoffTag>();
                    IEnumerable<BeckhoffXmlTag> beckhoffXmlTags = getActiveBeckhofftagsgroup as IList<BeckhoffXmlTag> ?? getActiveBeckhofftagsgroup.ToList();
                    for (int m = 0; m < beckhoffXmlTags.ToList().Count; m++)
                    {
                        lbeckhoffTagvalues.Add(new BeckhoffTag
                        {
                            Address = beckhoffXmlTags.ToList()[m].TagAddress,
                            Value = beckhoffXmlTags.ToList()[m].Value,
                            TimeStamp = beckhoffXmlTags.ToList()[m].DateTimestamp,
                            Topic = controller.TopicName,
                            TagType = beckhoffXmlTags.ToList()[m].TagType,
                            TagId = 0,
                            IsModified = true,
                            Quality = "Good",
                            LoadId = beckhoffXmlTags.ToList()[m].LoadId
                        });
                    }
                    //Grouping based on timestamp and inserting the data
                    var groupedWasherTagValues = lbeckhoffTagvalues.OrderBy(x => x.TimeStamp).GroupBy(u => new { u.TimeStamp }).Select(grp => new { washerList = grp.ToList() }).ToList();
                    string eofTag = string.Empty;
                    if (lbeckhoffTagvalues.Count > 0)
                    {
                        string[] tagsArray = Tags(lbeckhoffTagvalues[0].Address);
                        eofTag = tagsArray[0];
                    }
                    foreach (var taggrouped in groupedWasherTagValues)
                    {
                        var lbeckhoffTempTags = taggrouped.washerList.Select(t => new BeckhoffTag
                        {
                            Address = t.Address,
                            Value = t.Value,
                            TimeStamp = t.TimeStamp,
                            Topic = controller.TopicName,
                            TagType = t.TagType,
                            TagId = 0,
                            IsModified = true,
                            Quality = "Good",
                            LoadId = t.LoadId
                        }).ToList();

                        lbeckhoffTempTags.Add(new BeckhoffTag { Address = eofTag + "_EOF", Value = lwasher.EndOFFormula.ToString(), TimeStamp = lbeckhoffTempTags[0].TimeStamp, Topic = controller.TopicName, TagType = "Tag_EOF", TagId = 0, IsModified = true, Quality = "Good" });
                        if (lbeckhoffTempTags.Count >= 2)
                        {
                            var tagFrm = from m in taggrouped.washerList where m.TagType == "Tag_FRM" select m;
                            if (tagFrm.ToList().Count != 0)
                            {
                                var b = lbeckhoffTempTags.Find(m => m.TagType == "Tag_FRM");
                                if (queue.Count >= noOfCompartments)
                                {
                                    queue.Dequeue();
                                }
                                queue.Enqueue(new BeckhoffQueueItem { FormulaId = Convert.ToInt32(b.Value), LoadId = b.LoadId, TimeStamp = b.TimeStamp });
                                Tunnel a = ProcessTunnelWasherTags(lbeckhoffTempTags, lwasher, queue.Reverse(), noOfCompartments);

                                if (a.Awea == false)
                                {
                                    //Read the XML from the Beckhoff Controller
                                    List<BeckhoffTag> readtags = new List<BeckhoffTag>();
                                    string aweaAddress = eofTag + "_AWEA";
                                    BeckhoffTag beckhoffTag = new BeckhoffTag { Address = aweaAddress, SizetoRead = 80 };
                                    readtags.Add(beckhoffTag);
                                    BeckhoffTag[] resultread = dataReader.ReadTags(readtags).ToArray();
                                    a.Awea = (resultread[0].Value != "1" ? false : true);
                                    Log.InfoFormat("aweaAddress Tag {0} for Controller {1}", a.Awea, controller.ControllerId);
                                }
                                ProcessEtechTotalWeight(lwasher, a);/// Get Total weight and CustomerCode from Etech REST service
                                string strTunnel = SerializeTunnel(a);
                                int RedFlagShiftId = 0;
                                Log.InfoFormat("Processing Tunnel WasherId and XML Data {0} {1}", lwasher.WasherId, strTunnel);
                                RedFlagShiftId = DataReaderAccess.ProcessTunnelWasherTags(lwasher.WasherId, strTunnel, RedFlagShiftId);

                                try
                                {
                                    if (RedFlagShiftId > 0)
                                    {
                                        DataReaderAccess.ProcessRedFlagData(RedFlagShiftId);
                                    }
                                }
                                catch (Exception ex)
                                {
                                    Log.Error("Error occured while processing Red flag data for Shift: " + RedFlagShiftId, ex);
                                }

                                lbeckhoffTagstoDelete.AddRange(lbeckhoffTempTags.Select(t1 => new BeckhoffTag { Address = t1.Address, Value = t1.Value, TagType = t1.TagType, TimeStamp = t1.TimeStamp }));
                            }
                            else
                            {
                                lbeckhoffTagstoDelete.AddRange(lbeckhoffTempTags.Select(t1 => new BeckhoffTag { Address = t1.Address, Value = t1.Value, TagType = t1.TagType, TimeStamp = t1.TimeStamp }));
                            }
                        }
                    }
                    foreach (BeckhoffTag tag in lbeckhoffTagstoDelete)
                    {
                        DataReaderAccess.ProcessDeleteBeckhoffArrayQueue(controller.ControllerId, lwasher.WasherId, tag.Address, tag.Value, tag.TimeStamp, true);
                        Log.InfoFormat("deleting Tunnel Washer tags from database table beckhoffarrayqueue {0} {1}", tag.Address, lwasher.WasherId);
                    }
                    #endregion
                }
                else
                {
                    #region Conv
                    for (int k = 0; k < beckhoffxmlTags.Count(); k++)
                    {

                        for (int j = 0; j < enumerable.ToList()[i].Tags.Count(); j++)
                        {
                            if (beckhoffxmlTags[k].TagAddress == enumerable.ToList()[i].Tags[j].Address)
                            {
                                lwasherTagValues.Add(new BeckhoffTag { Address = beckhoffxmlTags[k].TagAddress, Value = beckhoffxmlTags[k].Value, TimeStamp = beckhoffxmlTags[k].DateTimestamp, Topic = controller.TopicName, TagType = enumerable.ToList()[i].Tags[j].TagType, TagId = enumerable.ToList()[i].Tags[j].TagId, IsModified = true, Quality = "Good", ETechLastDroppedAt = enumerable.ToList()[i].Tags[j].ETechLastDroppedAt, CustomerCodes = enumerable.ToList()[i].Tags[j].CustomerCodes });
                            }
                        }
                    }
                    lwasherTagValues = lwasherTagValues.OrderBy(e => e.TimeStamp).ToList();

                    string eofTag = string.Empty;
                    string PlcAwea = "0";
                    string PLCRATA = "0";

                    if (lwasherTagValues.Count > 0)
                    {
                        string[] tagsArray = Tags(lwasherTagValues[0].Address);
                        eofTag = tagsArray[0];

                        List<BeckhoffTag> readtags = new List<BeckhoffTag>();
                        string aweaAddress = eofTag + "_AWEA";
                        BeckhoffTag beckhoffTag = new BeckhoffTag { Address = aweaAddress };
                        readtags.Add(beckhoffTag);

                        string rataAddress = eofTag + "_RATA";
                        BeckhoffTag beckhoffTagRata = new BeckhoffTag { Address = rataAddress };
                        readtags.Add(beckhoffTagRata);

                        var result = dataReader.ReadTags(readtags);
                        if (result != null)
                        {
                            BeckhoffTag[] resultread = result.ToArray();
                            PlcAwea = resultread[0].Value;
                            PLCRATA = resultread[1].Value;
                        }

                        Log.InfoFormat("aweaAddress Tag {0} for Controller {1} and washer {2}", PlcAwea, controller.ControllerId, aweaAddress);
                    }

                    foreach (BeckhoffTag tag in lwasherTagValues)
                    {
                        if ((tag.TagType == "Tag_FRM" || tag.TagType == "Tag_AWEF") && Convert.ToInt32(tag.Value) == 0)
                        {
                            continue;
                        }
                        //if (PlcAwea == "1" && tag.TagType == "Tag_AWEF")
                        //{
                        //    tag.Address = eofTag + "_FRM";
                        //}

                        if (tag.TagType == "Tag_HOLD" || tag.TagType == "Tag_HOLDL")
                        {
                            //Hold signal so process it seperately and do not insert into the queue
                            DataReaderAccess.ProcessHoldSignal(controller.ControllerId, lwasher.WasherId, tag.Address, tag.Value, tag.TimeStamp);
                            continue;
                        }

                        //Code for handling INJ and OPC reset scenario - start
                        if ((tag.TagType == "Tag_INJ" && Convert.ToInt32(tag.Value) == 0) || (tag.TagType == "Tag_OPC" && Convert.ToInt32(tag.Value) == 0))
                        {
                            //Handling INJ and OPC reset case
                            //Check if there is any alarm at the same timestamp of INJ and OPC reset
                            var lnowTagValues = GetAlarmTagsFromXML(controller, beckhoffxmlTags);
                            var foundAlarmObj = lnowTagValues.Find(l => l.TimeStamp == tag.TimeStamp && l.TagType == "NowMessage");
                            if (foundAlarmObj != null)
                            {
                                //If there is an alarm at the same timestamp of inj and opc reset
                                //then check if the alarm is a valid for this particulat washer
                                Log.InfoFormat("Beckhoff: INJ/OPC {0} is reset and alarm {1} received at the same timestamp {2}", tag.Address, Convert.ToInt32(foundAlarmObj.Value), foundAlarmObj.TimeStamp);
                                int machineInternalId = CommonDataOperations.GetMachineInternalIdByWasherId(lwasher.WasherId);
                                if (!TagProcessor.ValidAlarmToExcludeForInjectionAndOPCReset(machineInternalId, Convert.ToInt32(foundAlarmObj.Value), 2))
                                {
                                    //Received alarm at the same time, but it is not a valid alarm so not ignoring it.
                                    DataReaderAccess.ProcessBeckhoffArrayQueue(controller.ControllerId, lwasher.WasherId, tag.Address, tag.Value, tag.TimeStamp);
                                    Log.InfoFormat("Store Conv Washer tags to beckhoffarrayqueue {0} {1} {2}", tag.Address, lwasher.WasherId,tag.TimeStamp);
                                }
                                else
                                {
                                    //Received valid alarm at INJ and OPC reset so ignoring them by not inserting to queue.
                                    Log.InfoFormat("Beckhoff: INJ/OPC {0} is reset and ignoring it because alarm {1} received at the same timestamp {2}", tag.Address, Convert.ToInt32(foundAlarmObj.Value), foundAlarmObj.TimeStamp);
                                }
                            }
                            else
                            {
                                DataReaderAccess.ProcessBeckhoffArrayQueue(controller.ControllerId, lwasher.WasherId, tag.Address, tag.Value, tag.TimeStamp);
                                Log.InfoFormat("Store Conv Washer tags to beckhoffarrayqueue {0} {1} {2}", tag.Address, lwasher.WasherId, tag.TimeStamp);
                            }
                        }
                        //Code for handling INJ and OPC reset scenario - end
                        else
                        {
                            DataReaderAccess.ProcessBeckhoffArrayQueue(controller.ControllerId, lwasher.WasherId, tag.Address, tag.Value, tag.TimeStamp);
                            Log.InfoFormat("Storing Conv Washer tags to database table beckhoffarrayqueue {0} {1} {2}", tag.Address, lwasher.WasherId, tag.TimeStamp);
                        }
                    }

                    IEnumerable<BeckhoffXmlTag> getActiveBeckhofftagsgroup = DataReaderAccess.GetActiveBeckhoffArrayQueue(controller.ControllerId, lwasher.WasherId);
                    var lbeckhoffTagvalues = new List<BeckhoffTag>();
                    var lbeckhoffTagstoDelete = new List<BeckhoffTag>();
                    IEnumerable<BeckhoffXmlTag> beckhoffXmlTags = getActiveBeckhofftagsgroup as IList<BeckhoffXmlTag> ?? getActiveBeckhofftagsgroup.ToList();
                    for (int m = 0; m < beckhoffXmlTags.ToList().Count; m++)
                    {
                        if (PlcAwea == "1" && beckhoffXmlTags.ToList()[m].TagType == "Tag_AWEF")
                        {
                            beckhoffXmlTags.ToList()[m].TagAddress = eofTag + "_FRM";
                            beckhoffXmlTags.ToList()[m].TagIdentifier = "AWEF";
                            beckhoffXmlTags.ToList()[m].TagType = "Tag_FRM";

                        }
                        lbeckhoffTagvalues.Add(new BeckhoffTag { Address = beckhoffXmlTags.ToList()[m].TagAddress, Value = beckhoffXmlTags.ToList()[m].Value, TimeStamp = beckhoffXmlTags.ToList()[m].DateTimestamp, Topic = controller.TopicName, TagType = beckhoffXmlTags.ToList()[m].TagType, TagId = 0, IsModified = true, Quality = "Good", LoadId = beckhoffXmlTags.ToList()[m].LoadId, TagIdentifier= beckhoffXmlTags.ToList()[m].TagIdentifier });
                    }

                    for (int p = 0; p < lbeckhoffTagvalues.Count; p++)
                    {
                        if (isServiceStopping)
                        {
                            Log.Info("Service Stopped. Exiting BeckhOff XML Service.");
                            return;
                        }
                        p = 0;
                        if (lbeckhoffTagvalues.Count < 2)
                        {
                            break;
                        }
                        bool isBatchWithoutInjAndOpc = false;
                        if (lbeckhoffTagvalues[p].TagType == "Tag_FRM")
                        {
                            if (lbeckhoffTagvalues[p + 1].TagType == "Tag_FRM" || (lbeckhoffTagvalues[p+1].TagType == "Tag_INJ" && Convert.ToInt32(lbeckhoffTagvalues[p + 1].Value) > 0)
                                || (lbeckhoffTagvalues[p + 1].TagType == "Tag_OPC" && Convert.ToInt32(lbeckhoffTagvalues[p + 1].Value) > 0)
                                || (lbeckhoffTagvalues[p + 1].TagType == "Tag_AWEW"))
                            {
                                bool isBatchExists = DataReaderAccess.GetActiveBatchtoWasher(lwasher.WasherId, Convert.ToInt32(lbeckhoffTagvalues[p].Value), lbeckhoffTagvalues[p].TimeStamp);
                                if (isBatchExists || Convert.ToInt32(lbeckhoffTagvalues[p].Value) == lwasher.EndOFFormula || Convert.ToInt32(lbeckhoffTagvalues[p].Value) == 0)
                                {
                                    if (lbeckhoffTagvalues[p+1].TagType == "Tag_FRM")
                                    {
                                        if (lbeckhoffTagvalues[p].TagIdentifier == "AWEF")
                                        {
                                            //Ignoring AWEF.
                                            lbeckhoffTagvalues[p].Address = eofTag + "_AWEF";
                                            lbeckhoffTagvalues[p].TagType = "Tag_AWEF";
                                        }
                                        lbeckhoffTagstoDelete.Add(new BeckhoffTag { Address = lbeckhoffTagvalues[p].Address, Value = lbeckhoffTagvalues[p].Value, TagType = lbeckhoffTagvalues[p].TagType, TimeStamp = lbeckhoffTagvalues[p].TimeStamp });
                                        lbeckhoffTagvalues.RemoveAt(p);
                                        continue;
                                    }
                                }
                                else
                                {
                                    isBatchWithoutInjAndOpc = true;
                                }
                            }

                            var lbeckhoffTempTags = new List<BeckhoffTag>
                        {
                            new BeckhoffTag
                            {
                                Address = lbeckhoffTagvalues[p].Address,
                                Value = lbeckhoffTagvalues[p].Value,
                                TimeStamp = lbeckhoffTagvalues[p].TimeStamp,
                                Topic = controller.TopicName,
                                TagType = lbeckhoffTagvalues[p].TagType,
                                TagId = 0,
                                IsModified = true,
                                Quality = "Good",
                                LoadId = beckhoffXmlTags.ToList()[p].LoadId,
                                TagIdentifier = beckhoffXmlTags.ToList()[p].TagIdentifier
                            }
                        };
                            for (int q = p + 1; q < lbeckhoffTagvalues.Count; q++)
                            {
                                if (isServiceStopping)
                                {
                                    Log.Info("Service Stopped. Exiting BeckhOff XML Service.");
                                    return;
                                }
                                #region <<AWEF Scenario>>
                                if (PlcAwea == "1" && lbeckhoffTagvalues[q].TagType == "Tag_FRM" && lbeckhoffTagvalues[q].TagIdentifier == "AWEF")
                                {
                                    //compare timestamps of FRM and AWEF
                                    if ((lbeckhoffTagvalues[q].TimeStamp - lbeckhoffTempTags[p].TimeStamp).TotalSeconds <= FRMAWEFTimeDiff)
                                    {
                                        //Ignoring AWEF.
                                        lbeckhoffTagvalues[q].Address = eofTag + "_AWEF";
                                        lbeckhoffTagvalues[q].TagType = "Tag_AWEF";
                                        lbeckhoffTagstoDelete.Add(new BeckhoffTag { Address = lbeckhoffTagvalues[q].Address, Value = lbeckhoffTagvalues[q].Value, TagType = lbeckhoffTagvalues[q].TagType, TimeStamp = lbeckhoffTagvalues[q].TimeStamp });
                                        Log.InfoFormat("Skipping AWEF based on time diff between FRM:{0} and AWEF:{1}", lbeckhoffTempTags[p].TimeStamp, lbeckhoffTagvalues[q].TimeStamp);
                                        continue;
                                    }
                                }
                                #endregion
                                if (lbeckhoffTagvalues[q].TagType == "Tag_FRM")
                                {
                                    //Here means, received next formula so all the signals are formed for the previous formula.
                                    //Hence break the loop and process the previous formula with all the remaining signals.
                                    Log.InfoFormat("Done with signal formation for formula:{0}", lbeckhoffTempTags[p].Value);
                                    break;
                                }

                                for (int r = 0; r < lbeckhoffTempTags.Count; r++)
                                {
                                    int q1 = q;
                                    var query = lbeckhoffTempTags.Where(k => k.TagType == lbeckhoffTagvalues[q1].TagType);
                                    if (query.ToList().Count == 0)
                                    {
                                        if (lbeckhoffTempTags.Count > 1)
                                        {
                                            if (lbeckhoffTempTags[1].TimeStamp == lbeckhoffTagvalues[q].TimeStamp || (PlcAwea == "1" && lbeckhoffTagvalues[q].TagType=="Tag_AWEW" && (lbeckhoffTagvalues[q].TimeStamp - lbeckhoffTempTags[p].TimeStamp).TotalSeconds <= FRMAWEFTimeDiff))
                                            {
                                                lbeckhoffTempTags.Add(new BeckhoffTag { Address = lbeckhoffTagvalues[q].Address, Value = lbeckhoffTagvalues[q].Value, TimeStamp = lbeckhoffTagvalues[q].TimeStamp, Topic = controller.TopicName, TagType = lbeckhoffTagvalues[q].TagType, TagId = 0, IsModified = true, Quality = "Good" });
                                            }
                                        }
                                        else
                                        {
                                            bool isBatchExists = DataReaderAccess.GetActiveBatchtoWasher(lwasher.WasherId, Convert.ToInt32(lbeckhoffTagvalues[p].Value), lbeckhoffTagvalues[p].TimeStamp);

                                            if (!isBatchExists)
                                            {
                                                if(lbeckhoffTagvalues[q].TagType == "Tag_AWEW")
                                                {
                                                    lbeckhoffTempTags.Add(new BeckhoffTag { Address = lbeckhoffTagvalues[q].Address, Value = lbeckhoffTagvalues[q].Value, TimeStamp = lbeckhoffTagvalues[q].TimeStamp, Topic = controller.TopicName, TagType = lbeckhoffTagvalues[q].TagType, TagId = 0, IsModified = true, Quality = "Good" });
                                                }
                                                if ((lbeckhoffTagvalues[q].TagType == "Tag_INJ" || lbeckhoffTagvalues[q].TagType == "Tag_OPC") && Convert.ToInt32(lbeckhoffTagvalues[q].Value) == 0)
                                                {
                                                    lbeckhoffTempTags.Add(new BeckhoffTag { Address = lbeckhoffTagvalues[q].Address, Value = lbeckhoffTagvalues[q].Value, TimeStamp = lbeckhoffTagvalues[q].TimeStamp, Topic = controller.TopicName, TagType = lbeckhoffTagvalues[q].TagType, TagId = 0, IsModified = true, Quality = "Good" });
                                                }
                                            }
                                            else
                                            {
                                                lbeckhoffTempTags.Add(new BeckhoffTag { Address = lbeckhoffTagvalues[q].Address, Value = lbeckhoffTagvalues[q].Value, TimeStamp = lbeckhoffTagvalues[q].TimeStamp, Topic = controller.TopicName, TagType = lbeckhoffTagvalues[q].TagType, TagId = 0, IsModified = true, Quality = "Good" });
                                            }
                                        }
                                        break;
                                    }
                                }
                            }

                            if (PlcAwea == "1")
                            {
                                //For the starting signal, check if we received AWEW or not from PLC, even though AWEA is enabled.
                                //AWEW is considered only while starting the batch means the timestamp of FRM, OPC=0 and INJ=0
                                //should be same as AWEW, if not ignore AWEW (if it is different time stamp)
                                //If next injection or formula is present then form the signal with manual AWEW and then insert the batch
                                int intOpc = -1;
                                int intInj = -1;
                                var opc = lbeckhoffTempTags.Find(l => l.TagType == "Tag_OPC");
                                var inj = lbeckhoffTempTags.Find(l => l.TagType == "Tag_INJ");

                                if (opc != null)
                                    intOpc = int.Parse(lbeckhoffTempTags.Find(l => l.TagType == "Tag_OPC").Value);
                                if (inj != null)
                                    intInj = int.Parse(lbeckhoffTempTags.Find(l => l.TagType == "Tag_INJ").Value);

                                if (intOpc == 0 && intInj == 0)
                                {
                                    var lbeckhoffTagsToVerify = new List<BeckhoffTag>();
                                    bool nextFrmFound = false;
                                    var nextInjFound = false;

                                    for (int counter = lbeckhoffTempTags.Count; counter < lbeckhoffTagvalues.Count; counter++)
                                    {
                                        if (lbeckhoffTagvalues[counter].TagType == "Tag_FRM")
                                        {
                                            nextFrmFound = true;
                                            break;
                                        }
                                        lbeckhoffTagsToVerify.Add(new BeckhoffTag { Address = lbeckhoffTagvalues[counter].Address, Value = lbeckhoffTagvalues[counter].Value, TimeStamp = lbeckhoffTagvalues[counter].TimeStamp, Topic = controller.TopicName, TagType = lbeckhoffTagvalues[counter].TagType, TagId = 0, IsModified = true, Quality = "Good" });
                                    }

                                    var IsAwewPresent = lbeckhoffTempTags.Find(l => l.TagType == "Tag_AWEW");

                                    if (lbeckhoffTagsToVerify.Count > 0 &&
                                        (lbeckhoffTagsToVerify.Find(l => l.TagType == "Tag_OPC") != null || lbeckhoffTagsToVerify.Find(l => l.TagType == "Tag_INJ") != null))
                                    {
                                        nextInjFound = true;
                                    }

                                    if (IsAwewPresent == null && (nextInjFound || nextFrmFound))
                                    {
                                        //AWEW is not received from PLC even though AWEA is enabled. So adding AWEW as zero manually.
                                        string PlcAwewAddress = eofTag + "_AWEW";
                                        lbeckhoffTempTags.Add(new BeckhoffTag { Address = PlcAwewAddress, Value = "0", TimeStamp = lbeckhoffTempTags[p].TimeStamp, Topic = controller.TopicName, TagType = "Tag_AWEW", TagId = 0, IsModified = true, Quality = "Good" });
                                        Log.InfoFormat("Setting AWEW as zero since AWEW tag : {0} is not received for washer : {1}", PlcAwewAddress, lwasher.WasherId);
                                    }
                                }
                            }

                            //if (lbeckhoffTempTags.Count <=2 && lbeckhoffTempTags[0].TagType == "Tag_FRM")
                            //{
                            //    bool isBatchExists = DataReaderAccess.GetActiveBatchtoWasher(lwasher.WasherId, Convert.ToInt32(lbeckhoffTempTags[0].Value), lbeckhoffTempTags[0].TimeStamp);
                            //    if (!isBatchExists)
                            //    {
                            //        isBatchWithoutInjAndOpc = true;
                            //    }
                            //}

                            int minBatchCount;

                            if (PlcAwea == "1")
                            {
                                minBatchCount = 4;
                                if (!IsNotNewFormula(lbeckhoffTempTags, lwasher.EndOFFormula))
                                {
                                    minBatchCount = 3;
                                }
                            }
                            else
                            {
                                minBatchCount = 3;
                            }

                            if (isBatchWithoutInjAndOpc)
                            {
                                minBatchCount = 3;
                                lbeckhoffTempTags.Add(new BeckhoffTag { Address = eofTag + "_INJ", Value = "0", TimeStamp = lbeckhoffTempTags[0].TimeStamp, Topic = controller.TopicName, TagType = "Tag_INJ", TagId = 0, IsModified = true, Quality = "Good" });
                                lbeckhoffTempTags.Add(new BeckhoffTag { Address = eofTag + "_OPC", Value = "0", TimeStamp = lbeckhoffTempTags[0].TimeStamp, Topic = controller.TopicName, TagType = "Tag_OPC", TagId = 0, IsModified = true, Quality = "Good" });
                                if (PlcAwea == "1")
                                {
                                    minBatchCount = 4;
                                    var AWEW = lbeckhoffTempTags.Find(l => l.TagType == "Tag_AWEW");
                                    if (AWEW == null)
                                    {
                                        lbeckhoffTempTags.Add(new BeckhoffTag { Address = eofTag + "_AWEW", Value = "0", TimeStamp = lbeckhoffTempTags[0].TimeStamp, Topic = controller.TopicName, TagType = "Tag_AWEW", TagId = 0, IsModified = true, Quality = "Good" });
                                    }
                                }
                                Log.InfoFormat("Missing INJ and OPC for the formula :{0}", lbeckhoffTempTags[p].Value);
                            }

                            if (lbeckhoffTempTags.Count >= minBatchCount)
                            {
                                //Handling INJ and OPC reset scenario - start
                                //The below logic is for handling INJ and OPC reset received in first xml
                                //and alarm is received in the next xml. In this case, we are waiting for next 
                                //alarm signal and if it is not received we will check for the next signal, if
                                //received then we assume that alarm is not received
                                List<BeckhoffTag> lresetList = lbeckhoffTagvalues;
                                var inj = lbeckhoffTempTags.Find(l => l.TagType == "Tag_INJ");
                                if (inj != null && Convert.ToInt32(inj.Value) == 0 && inj.TimeStamp > lbeckhoffTempTags[0].TimeStamp)
                                {
                                    foreach (BeckhoffTag tag in lbeckhoffTempTags)
                                    {
                                        lresetList.RemoveAll(x => x.TagType != "Tag_FRM" && x.TimeStamp == tag.TimeStamp);
                                    }
                                    if (lresetList.Count <= 1)
                                    {
                                        foreach (BeckhoffTag t1 in lbeckhoffTempTags)
                                        {
                                            if (t1.TagType != "Tag_FRM")
                                            {
                                                lbeckhoffTagstoDelete.Add(new BeckhoffTag { Address = t1.Address, Value = t1.Value, TagType = t1.TagType, TimeStamp = t1.TimeStamp });
                                                CommonDataOperations.DeleteBeckhoffArrayQueueShadow(controller.ControllerId, lwasher.WasherId, t1.Address, t1.Value, t1.TimeStamp, false);
                                            }
                                        }
                                        break;
                                    }
                                }
                                //Handling INJ and OPC reset scenario - end
                                lbeckhoffTempTags.Add(new BeckhoffTag { Address = eofTag + "_EOF", Value = lwasher.EndOFFormula.ToString(), TimeStamp = lbeckhoffTempTags[0].TimeStamp, Topic = controller.TopicName, TagType = "Tag_EOF", TagId = 0, IsModified = true, Quality = "Good" });
                                lbeckhoffTempTags.Add(new BeckhoffTag { Address = eofTag + "_AWEA", Value = PlcAwea, TimeStamp = lbeckhoffTempTags[0].TimeStamp, Topic = controller.TopicName, TagType = "Tag_AWEA", TagId = 0, IsModified = true, Quality = "Good" });
                                //Write Ratio Dosing Percentage to PLC into W#_RATP Tag address
                                WriteRatioDosingPercentage(lwasher.WasherId, lbeckhoffTempTags, dataWriter, PLCRATA, eofTag);
                                //ETech REST Service call
                                ProcessEtechTotalWeight(lwasher, lbeckhoffTempTags, eofTag, controller);
                                Log.InfoFormat("Process Conv Washer tags to database {0} {1}", lbeckhoffTempTags, lwasher.WasherId);
                                TagProcessor.ProcessWasherBatchTags(lbeckhoffTempTags, lwasher);
                                foreach (BeckhoffTag t1 in lbeckhoffTempTags)
                                {
                                    bool check = false;
                                    if (lbeckhoffTagstoDelete.Count == 0 && t1.TagType != "Tag_FRM")
                                    {
                                        lbeckhoffTagstoDelete.Add(new BeckhoffTag { Address = t1.Address, Value = t1.Value, TagType = t1.TagType, TimeStamp = t1.TimeStamp });
                                    }
                                    else
                                    {
                                        if (lbeckhoffTagstoDelete.Any(t => t1.Address == t.Address && t1.Value == t.Value && t1.TagType == t.TagType && t1.TimeStamp == t.TimeStamp && t1.TagType != "Tag_FRM"))
                                        {
                                            check = true;
                                        }
                                        if (check == false && t1.TagType != "Tag_FRM")
                                        {
                                            lbeckhoffTagstoDelete.Add(new BeckhoffTag { Address = t1.Address, Value = t1.Value, TagType = t1.TagType, TimeStamp = t1.TimeStamp });
                                        }
                                    }
                                }
                            }

                            foreach (BeckhoffTag tag in lbeckhoffTempTags)
                            {
                                lbeckhoffTagvalues.RemoveAll(x => x.TagType != "Tag_FRM" && x.TimeStamp == tag.TimeStamp);
                            }
                        }
                        else
                        {
                            
                            lbeckhoffTagstoDelete.Add(new BeckhoffTag { Address = lbeckhoffTagvalues[p].Address, Value = lbeckhoffTagvalues[p].Value, TagType = lbeckhoffTagvalues[p].TagType, TimeStamp = lbeckhoffTagvalues[p].TimeStamp });
                            lbeckhoffTagvalues.RemoveAt(p);
                        }
                    }
                    foreach (BeckhoffTag tag in lbeckhoffTagstoDelete)
                    {
                        DataReaderAccess.ProcessDeleteBeckhoffArrayQueue(controller.ControllerId, lwasher.WasherId, tag.Address, tag.Value, tag.TimeStamp, false);
                        Log.InfoFormat("deleting Conv Washer tags from database table beckhoffarrayqueue {0} {1}", tag.Address, lwasher.WasherId);
                    }
                    #endregion
                }
            }
        }

        /// <summary>
        /// Writes the ratio dosing percentage.
        /// </summary>
        /// <param name="washerId">The washer identifier.</param>
        /// <param name="Tags">The tags for RatioDosingPercentage.</param>
        /// <param name="dataWriter">The data writer for RatioDosingPercentage.</param>
        /// <param name="PLCRATA">The plcrata for RatioDosingPercentage.</param>
        /// <param name="TagPrefix">The tag prefix for RatioDosingPercentage.</param>
        private static void WriteRatioDosingPercentage(int washerId, List<BeckhoffTag> Tags, BeckoffDataWriter dataWriter, string PLCRATA, string TagPrefix)
        {
            #region Write Ratio Dosing Percentage to PLC into W#_RATP Tag address
            var FRM = Tags.Find(l => l.TagType == "Tag_FRM");
            var AWEA = Tags.Find(l => l.TagType == "Tag_AWEA");
            var AWEW = Tags.Find(l => l.TagType == "Tag_AWEW");

            if (FRM != null && AWEA != null && AWEW != null)
            {
                if (AWEA.Value == "1" && PLCRATA == "1")
                {
                    ///Dosing percentage
                    IEnumerable<global::Entities.DataReader.RatioDosing> ratioDosingInputs = Access.DataReader.DataReaderAccess.GetActiveSWbyWasherIdAndFormula(washerId, Convert.ToInt32(FRM.Value));
                    int actualWeight = Convert.ToInt32(AWEW.Value);
                    if (actualWeight != 0 && ratioDosingInputs != null)
                    {
                        var dosing = ratioDosingInputs.FirstOrDefault();
                        if (dosing != null)
                        {
                            double d1 = Convert.ToDouble(actualWeight);
                            double d2 = Convert.ToDouble(dosing.StandardWeight);
                            string PLCRATP = Convert.ToString(Convert.ToInt32((d1 / d2) * 10000));
                            // Write RATP value to W#_RATP Tag
                            List<BeckhoffTag> writetags = new List<BeckhoffTag>();
                            BeckhoffTag tagToWrite = new BeckhoffTag { Address = TagPrefix + "_RATP", Value = PLCRATP };
                            writetags.Add(tagToWrite);
                            dataWriter.WriteTags(writetags);
                        }
                    }
                }
            }
            #endregion
        }

        /// <summary>
        /// Processes the etech total weight.
        /// </summary>
        /// <param name="lwasher">The lwasher for EtechTotalWeight.</param>
        /// <param name="Tags">The tags for EtechTotalWeight.</param>
        /// <param name="eofTag">The EOF tag for EtechTotalWeight.</param>
        /// <param name="controller">The controller for EtechTotalWeight.</param>
        private static void ProcessEtechTotalWeight(Washer lwasher, List<BeckhoffTag> Tags, string eofTag, BeckhoffController controller)
        {
            try
            {
                //check if Etech is enabled in the plant
                if (ETechEnable && lwasher.AWEAActive && lwasher.ETechWasherNumber > 0)
                {
                    //Get Total weight from ETech service.
                    //Append the ETech washer number to the Etech URL
                    var FRM = Tags.Find(l => l.TagType == "Tag_FRM");
                    var OPC = Tags.Find(l => l.TagType == "Tag_OPC");
                    var INJ = Tags.Find(l => l.TagType == "Tag_INJ");

                    if (FRM != null && OPC != null && INJ != null && Convert.ToInt32(OPC.Value) == 0 && Convert.ToInt32(INJ.Value) == 0)
                    {
                        if (!string.IsNullOrEmpty(ETechIPAddress))
                        {
                            //Get Total weight value from ETech
                            string ETechURL = string.Format(Settings.Default.ETechURLBeckhoff, ETechIPAddress, lwasher.ETechWasherNumber);
                            //string ETechURL = ETechIPAddress + "/" + Convert.ToString(lwasher.ETechWasherNumber);
                            DFLastDropped ETechdata = CommonDataOperations.GetETechTotalWeightBechkoff(ETechURL, EtechCustomerCodesText, FRM.TimeStamp, ETechTimeDiff);
                            if (ETechdata != null && ETechdata.record.Count > 0 && Convert.ToInt32(ETechdata.record[0].soiledWeight) >= 0)
                            {
                                var AWEW = Tags.Find(l => l.TagType == "Tag_AWEW");
                                if (AWEW != null)
                                {
                                    AWEW.Value = ETechdata.record[0].soiledWeight;
                                    AWEW.ETechLastDroppedAt = DateTime.Parse(ETechdata.record[0].endTime).ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss");
                                    AWEW.CustomerCodes = ETechdata.record[0].customerCodes;
                                }
                                else
                                {
                                    Tags.Add(new BeckhoffTag { Address = eofTag + "_AWEW", Value = ETechdata.record[0].soiledWeight, TimeStamp = Tags[0].TimeStamp, Topic = controller.TopicName, TagType = "Tag_AWEW", TagId = 0, IsModified = true, Quality = "Good", ETechLastDroppedAt = DateTime.Parse(ETechdata.record[0].endTime).ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss"), CustomerCodes = ETechdata.record[0].customerCodes });
                                }
                                var AWEA = Tags.Find(l => l.TagType == "Tag_AWEA");
                                if (AWEA != null)
                                {
                                    AWEA.Value = "1";
                                }
                                else
                                {
                                    Tags.Add(new BeckhoffTag { Address = eofTag + "_AWEA", Value = "1", TimeStamp = Tags[0].TimeStamp, Topic = controller.TopicName, TagType = "Tag_AWEA", TagId = 0, IsModified = true, Quality = "Good" });
                                }
                            }
                        }
                    }
                }
                else
                {
                    Log.InfoFormat("Check AWEA/EtechWasherNumber parameter(s) for washer ID:{0}", Convert.ToString(lwasher.WasherId));
                }
            }
            catch (Exception ex)
            {
                Log.Error("Error occured: ProcessEtechTotalWeight - (Conventional): ", ex);
            }
        }

        /// <summary>
        /// Processes the etech total weight.
        /// </summary>
        /// <param name="lwasher">The lwasher for EtechTotalWeight.</param>
        /// <param name="tunnel">The tunnel for EtechTotalWeight.</param>
        private static void ProcessEtechTotalWeight(Washer lwasher, Tunnel tunnel)
        {
            try
            {
                //check if Etech is enabled in the plant
                if (ETechEnable && lwasher.AWEAActive && lwasher.ETechWasherNumber > 0)
                {
                    //Get Totalweight value from ETech service.
                    if (!string.IsNullOrEmpty(ETechIPAddress))
                    {
                        //Append the ETech washer number to the Etech URL
                        string ETechURL = string.Format(Settings.Default.ETechURLBeckhoff, ETechIPAddress, lwasher.ETechWasherNumber);
                        //ETechURL = ETechIPAddress + "/" + Convert.ToString(lwasher.ETechWasherNumber);
                        DFLastDropped ETechdata = CommonDataOperations.GetETechTotalWeightBechkoff(ETechURL, EtechCustomerCodesText, tunnel.TimeStamp, ETechTimeDiff);
                        if (ETechdata != null && ETechdata.record.Count > 0 && Convert.ToInt32(ETechdata.record[0].soiledWeight) >= 0)
                        {
                            tunnel.Awew = Convert.ToInt32(ETechdata.record[0].soiledWeight);
                            tunnel.Awea = true;
                            tunnel.ETechLastDroppedAt = DateTime.Parse(ETechdata.record[0].endTime).ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss");
                            tunnel.CustomerCodes = ETechdata.record[0].customerCodes;
                        }
                    }
                }
                else
                {
                    Log.InfoFormat("Check AWEA/EtechWasherNumber parameter(s) for washer ID:{0}", Convert.ToString(lwasher.WasherId));
                }
            }
            catch (Exception ex)
            {
                Log.Error("Error occured: ProcessEtechTotalWeight - (Tunnel): ", ex);
            }
        }

        /// <summary>
        /// Determines whether [is not new formula] [the specified lbeckhoff tagvalues].
        /// </summary>
        /// <param name="lbeckhoffTagvalues">The lbeckhoff tagvalues.</param>
        /// <param name="endOfFormula">The end of formula.</param>
        /// <returns>Returns true or false</returns>
        private static bool IsNotNewFormula(List<BeckhoffTag> lbeckhoffTagvalues, int endOfFormula)
        {
            try
            {
                if (lbeckhoffTagvalues.Count < 3)
                {
                    return true;
                }

                int formula = int.Parse(lbeckhoffTagvalues.Find(l => l.TagType == "Tag_FRM").Value);
                int opc = int.Parse(lbeckhoffTagvalues.Find(l => l.TagType == "Tag_OPC").Value);
                int inj = int.Parse(lbeckhoffTagvalues.Find(l => l.TagType == "Tag_INJ").Value);

                return (formula != endOfFormula && opc == 0 && inj == 0);
            }
            catch(Exception ex)
            {
                Log.Error("Error occured in IsNotNewFormula method...", ex);
                return true;
            }
        }

        /// <summary>
        /// Tagses the specified tabobject.
        /// </summary>
        /// <param name="tabobject">The tab object.</param>
        /// <returns>Returns string array</returns>
        public static string[] Tags(string tabobject)
        {
            return tabobject.Split(new[] { '_' }, 2);
        }

        /// <summary>
        /// GetBeckhoffXmlTags method will reading the xml tags 
        /// </summary>
        /// <param name="xmlString">The XML string.</param>
        /// <returns>Returns List of BeckhoffXmlTag</returns>
        private static List<BeckhoffXmlTag> GetBeckhoffXmlTags(string xmlString)
        {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(xmlString);
            List<BeckhoffXmlTag> beckHoffXmlReadTags = new List<BeckhoffXmlTag>();
            XmlNodeList xmlnodeList = xmlDoc.SelectNodes("/MyRoot/Entry");
            if (xmlnodeList == null)
            {
                Log.InfoFormat("Invalid XML : {0}", xmlString);
                return beckHoffXmlReadTags.ToList();
            }
            foreach (XmlNode xn in xmlnodeList)
            {
                DateTime beckDateTime;
                if (xn["tag"] != null && xn["desc"] != null && xn["data"] != null &&
                    xn["ts"] != null &&
                    DateTime.TryParseExact(xn["ts"].InnerText, DateFormat, null,
                        DateTimeStyles.None, out beckDateTime))
                {
                    beckHoffXmlReadTags.Add(new BeckhoffXmlTag(xn["tag"].InnerText.Trim(),
                        xn["desc"].InnerText, xn["data"].InnerText, beckDateTime.ToUniversalTime()));
                }
            }
            return beckHoffXmlReadTags.ToList();
        }

        /// <summary>
        /// Processes the tunnel washer tags.
        /// </summary>
        /// <param name="tags">The tags for TunnelWashers.</param>
        /// <param name="washer">The washer TunnelWashers.</param>
        /// <param name="items">The items TunnelWashers.</param>
        /// <param name="numberOfComp">The number of comp.</param>
        /// <returns>Returns Tunnel Data</returns>
        private static Tunnel ProcessTunnelWasherTags(IEnumerable<Tag> tags, Washer washer, IEnumerable<BeckhoffQueueItem> items, int numberOfComp)
        {
            IEnumerable<Tag> enumerable = tags as IList<Tag> ?? tags.ToList();
            var opcTags = tags as Tag[] ?? enumerable.ToArray();
            Tunnel tunnel = new Tunnel
            {
                Id = washer.WasherId,
                CurrentFormula = opcTags.Any(t => t.TagType != null && t.TagType == "Tag_FRM") ? Convert.ToInt32(opcTags.First(t => t.TagType != null && t.TagType == "Tag_FRM").Value) : 0,
                CurrentInjection = opcTags.Any(t => t.TagType != null && t.TagType == "Tag_INJ") ? Convert.ToInt32(opcTags.First(t => t.TagType != null && t.TagType == "Tag_INJ").Value) : 0,
                CurrentOperationCounter = opcTags.Any(t => t.TagType != null && t.TagType == "Tag_OPC") ? Convert.ToInt32(opcTags.First(t => t.TagType != null && t.TagType == "Tag_OPC").Value) : 0,
                Eof = opcTags.Any(t => t.TagType != null && t.TagType == "Tag_EOF") ? Convert.ToInt32(opcTags.First(t => t.TagType != null && t.TagType == "Tag_EOF").Value) : 0,
                OnHold = opcTags.Any(t => t.TagType != null && t.TagType == "Tag_HOLDL") && opcTags.First(t => t.TagType != null && t.TagType == "Tag_HOLDL").Value != "0",

                TimeStamp = opcTags.Any(t => t.TagType != null && t.TagType == "Tag_FRM") ? opcTags.First(t => t.TagType != null && t.TagType == "Tag_FRM").TimeStamp : DateTime.Now,
                IsFormulaModified = opcTags.Any(t => t.TagType != null && t.TagType == "Tag_FRM") && enumerable.Where(opcTag => opcTag.TagType != null && opcTag.TagType == "Tag_FRM").Any(opcTag => opcTag.IsModified),
                IsHoldSignalModified = opcTags.Any(t => t.TagType != null && t.TagType == "Tag_HOLDL") && enumerable.Where(opcTag => opcTag.TagType != null && opcTag.TagType == "Tag_HOLDL").Any(opcTag => opcTag.IsModified)
            };
            if (opcTags.Any(t => t.TagType != null && t.TagType == "Tag_AWEA"))
            {
                tunnel.Awea = Convert.ToBoolean(opcTags.First(t => t.TagType == "Tag_AWEA").Value);
                tunnel.Awew = int.Parse(opcTags.First(t => t.TagType != null && t.TagType == "Tag_AWEW").Value);
            }
            if (opcTags.Any(t => t.TagType != null && t.TagType == "Tag_RATA"))
            {
                tunnel.RATA = int.Parse(opcTags.First(t => t.TagType != null && t.TagType == "Tag_RATA").Value);
            }

            var compartments = new List<Compartment>();
            var a = items.ToList();
            int n = 0;

            while (n < numberOfComp)
            {
                if (a.Count < numberOfComp)
                {
                    a.Add(new BeckhoffQueueItem { FormulaId = 0, LoadId = 0, TimeStamp = a[0].TimeStamp });
                }
                n++;
            }

            for (int i = 0; i < numberOfComp; i++)
            {
                compartments.Add(
                    new Compartment
                    {
                        CompartmentId = i + 1,
                        FormulaId = a[i].FormulaId,
                        LoadId = a[i].LoadId,
                        TimeStamp = a[i].TimeStamp
                    });
            }
            tunnel.Comparments = compartments;
            return tunnel;
        }

        /// <summary>
        /// Serializes the tunnel.
        /// </summary>
        /// <param name="tunnel">The tunnel data.</param>
        /// <returns>Returns string serialize data</returns>
        private static string SerializeTunnel(Tunnel tunnel)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(Tunnel));
            StringWriter stringWriter = new StringWriter();
            using (XmlWriter xmlWriter = new XmlTextWriter(stringWriter))
            {
                xmlSerializer.Serialize(xmlWriter, tunnel);
                return stringWriter.ToString();
            }
        }

        /// <summary>
        ///     Read Alarm Tags From XML
        /// </summary>
        /// <param name="controller">Controller object</param>
        /// <param name="beckhoffxmlTags">beckhoffxmlTags list</param>
        /// <returns>returns a list.</returns>
        private static List<BeckhoffTag> GetAlarmTagsFromXML(BeckhoffController controller, List<BeckhoffXmlTag> beckhoffxmlTags)
        {
            var tags = new List<BeckhoffTag>
            {
                new BeckhoffTag {Address = "L_EMSG", TagType = "NowMessage", Topic = controller.TopicName},
                new BeckhoffTag {Address = "L_NWSH", TagType = "NowWasher", Topic = controller.TopicName},
                new BeckhoffTag {Address = "L_NFRM", TagType = "NowFormula", Topic = controller.TopicName},
                new BeckhoffTag {Address = "L_NVLV", TagType = "NowValve", Topic = controller.TopicName} // Conventional Only
            };
            var lnowTagValues = new List<BeckhoffTag>();
            for (int i = 0; i < tags.Count; i++)
            {
                for (int k = 0; k < beckhoffxmlTags.Count; k++)
                {
                    if (beckhoffxmlTags[k].TagAddress == tags.ToList()[i].Address)
                    {
                        lnowTagValues.Add(new BeckhoffTag
                        {
                            Address = beckhoffxmlTags[k].TagAddress,
                            Value = beckhoffxmlTags[k].Value,
                            TimeStamp = beckhoffxmlTags[k].DateTimestamp,
                            TagId = tags.ToList()[i].TagId,
                            TagType = tags.ToList()[i].TagType,
                            TagTypeId = tags.ToList()[i].TagTypeId,
                            Topic = controller.TopicName,
                            IsModified = true,
                            Quality = "Good"
                        });
                    }
                }
            }
            return lnowTagValues;
        }
            #endregion
        }
}
