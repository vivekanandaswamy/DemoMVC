﻿// -----------------------------------------------------------------------
// <copyright file="BeckhoffQueueItem.cs" company="Ecolab">
// ©2015 Ecolab All rights reserved.
// </copyright>
// <summary>The BeckhoffQueueItem </summary>
// -----------------------------------------------------------------------

using Entities.DataReader;
using Controller = Ecolab.Dcs.Entities.Controller;
using Timer = System.Timers.Timer;
using Washer = Ecolab.Dcs.Entities.Washer;

namespace Ecolab.Dcs.PlcDataReader
{
    using System;
    using System.Collections.Concurrent;
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.Threading;
    using System.Timers;
    using System.Xml;
    using System.Xml.Serialization;
    using Access.DataReader;
    using CollectData;
    using CollectData.Beckhoff;
    using Entities;
    using log4net;
    using Properties;
    using BeckhoffXmlTag = BeckhoffXmlTag;
    using Controller = Controller;
    using Timer = Timer;
    using Washer = Washer;

    /// <summary>
    /// Class for Beckhoff Queue Item
    /// </summary>
    public class BeckhoffQueueItem
    {
        /// <summary>
        /// Gets or sets the formula identifier.
        /// </summary>
        /// <value>
        /// The formula identifier.
        /// </value>
        public int FormulaId { get; set; }

        /// <summary>
        /// Gets or sets the load identifier.
        /// </summary>
        /// <value>
        /// The load identifier.
        /// </value>
        public int LoadId { get; set; }

        /// <summary>
        /// Gets or sets the time stamp.
        /// </summary>
        /// <value>
        /// The time stamp.
        /// </value>
        public DateTime TimeStamp { get; set; }
    }
}
